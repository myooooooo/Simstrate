; ================================================================
; seg16_CODE  (31424 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	10 00                	adc    BYTE PTR [bx+si],al
       2:	55                   	push   bp
       3:	0b b1 02 b2          	or     si,WORD PTR [bx+di-0x4dfe]
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 9e 00 13          	add    BYTE PTR [bp+0x1300],bl
       d:	04 fb                	add    al,0xfb
       f:	04 70                	add    al,0x70
      11:	0b 39                	or     di,WORD PTR [bx+di]
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 83 0b cb       	call   0xcb0b:0x831f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 c7                	adc    bh,al
      2d:	0e                   	push   cs
      2e:	d6                   	(bad)
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 06                	sbb    al,0x6
      61:	0d e2 2f             	or     ax,0x2fe2
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	13 54 46             	adc    dx,WORD PTR [si+0x46]
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	45                   	inc    bp
      a6:	44                   	inc    sp
      a7:	44                   	inc    sp
      a8:	5f                   	pop    di
      a9:	44                   	inc    sp
      aa:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
      ae:	69 6f 6e 73 1c       	imul   bp,WORD PTR [bx+0x6e],0x1c73
      b3:	00 94 10 c4          	add    BYTE PTR [si-0x3bf0],dl
      b7:	00 09                	add    BYTE PTR [bx+di],cl
      b9:	46                   	inc    si
      ba:	6f                   	outs   dx,WORD PTR ds:[si]
      bb:	72 6d                	jb     0x12a
      bd:	43                   	inc    bx
      be:	6c                   	ins    BYTE PTR es:[di],dx
      bf:	6f                   	outs   dx,WORD PTR ds:[si]
      c0:	73 65                	jae    0x127
      c2:	94                   	xchg   sp,ax
      c3:	14 d9                	adc    al,0xd9
      c5:	00 10                	add    BYTE PTR [bx+si],dl
      c7:	53                   	push   bx
      c8:	70 69                	jo     0x133
      ca:	6e                   	outs   dx,BYTE PTR ds:[si]
      cb:	45                   	inc    bp
      cc:	64 69 74 50 31 43    	imul   si,WORD PTR fs:[si+0x50],0x4331
      d2:	68 61 6e             	push   0x6e61
      d5:	67 65 b2 78          	addr32 gs mov dl,0x78
      d9:	ea 00 0c 54 65       	jmp    0x6554:0xc00
      de:	73 74                	jae    0x154
      e0:	42                   	inc    dx
      e1:	74 6e                	je     0x151
      e3:	43                   	inc    bx
      e4:	6c                   	ins    BYTE PTR es:[di],dx
      e5:	69 63 6b c2 0d       	imul   sp,WORD PTR [bp+di+0x6b],0xdc2
      ea:	f9                   	stc
      eb:	00 0a                	add    BYTE PTR [bp+si],cl
      ed:	46                   	inc    si
      ee:	6f                   	outs   dx,WORD PTR ds:[si]
      ef:	72 6d                	jb     0x15e
      f1:	43                   	inc    bx
      f2:	72 65                	jb     0x159
      f4:	61                   	popa
      f5:	74 65                	je     0x15c
      f7:	36 16                	ss push ss
      f9:	08 01                	or     BYTE PTR [bx+di],al
      fb:	0a 4f 4b             	or     cl,BYTE PTR [bx+0x4b]
      fe:	42                   	inc    dx
      ff:	74 6e                	je     0x16f
     101:	43                   	inc    bx
     102:	6c                   	ins    BYTE PTR es:[di],dx
     103:	69 63 6b 6a 16       	imul   sp,WORD PTR [bp+di+0x6b],0x166a
     108:	1c 01                	sbb    al,0x1
     10a:	0f 42 61 73          	cmovb  sp,WORD PTR [bx+di+0x73]
     10e:	63 75 6c             	arpl   WORD PTR [di+0x6c],si
     111:	65 42                	gs inc dx
     113:	74 6e                	je     0x183
     115:	43                   	inc    bx
     116:	6c                   	ins    BYTE PTR es:[di],dx
     117:	69 63 6b ba 2f       	imul   sp,WORD PTR [bp+di+0x6b],0x2fba
     11c:	31 01                	xor    WORD PTR [bx+di],ax
     11e:	10 56 65             	adc    BYTE PTR [bp+0x65],dl
     121:	72 69                	jb     0x18c
     123:	66 69 65 72 42 74 6e 	imul   esp,DWORD PTR [di+0x72],0x436e7442
     12a:	43 
     12b:	6c                   	ins    BYTE PTR es:[di],dx
     12c:	69 63 6b 97 18       	imul   sp,WORD PTR [bp+di+0x6b],0x1897
     131:	43                   	inc    bx
     132:	01 0d                	add    WORD PTR [di],cx
     134:	50                   	push   ax
     135:	72 69                	jb     0x1a0
     137:	6e                   	outs   dx,BYTE PTR ds:[si]
     138:	74 42                	je     0x17c
     13a:	74 6e                	je     0x1aa
     13c:	43                   	inc    bx
     13d:	6c                   	ins    BYTE PTR es:[di],dx
     13e:	69 63 6b c3 63       	imul   sp,WORD PTR [bp+di+0x6b],0x63c3
     143:	54                   	push   sp
     144:	01 0c                	add    WORD PTR [si],cx
     146:	48                   	dec    ax
     147:	65 6c                	gs ins BYTE PTR es:[di],dx
     149:	70 42                	jo     0x18d
     14b:	74 6e                	je     0x1bb
     14d:	43                   	inc    bx
     14e:	6c                   	ins    BYTE PTR es:[di],dx
     14f:	69 63 6b 1b 11       	imul   sp,WORD PTR [bp+di+0x6b],0x111b
     154:	67 01 0e             	add    WORD PTR [esi],cx
     157:	46                   	inc    si
     158:	6f                   	outs   dx,WORD PTR ds:[si]
     159:	72 6d                	jb     0x1c8
     15b:	43                   	inc    bx
     15c:	6c                   	ins    BYTE PTR es:[di],dx
     15d:	6f                   	outs   dx,WORD PTR ds:[si]
     15e:	73 65                	jae    0x1c5
     160:	51                   	push   cx
     161:	75 65                	jne    0x1c8
     163:	72 79                	jb     0x1de
     165:	02 30                	add    dh,BYTE PTR [bx+si]
     167:	7a 01                	jp     0x16a
     169:	0e                   	push   cs
     16a:	44                   	inc    sp
     16b:	65 66 61             	gs popad
     16e:	75 74                	jne    0x1e4
     170:	42                   	inc    dx
     171:	74 6e                	je     0x1e1
     173:	43                   	inc    bx
     174:	6c                   	ins    BYTE PTR es:[di],dx
     175:	69 63 6b f6 14       	imul   sp,WORD PTR [bp+di+0x6b],0x14f6
     17a:	8f 01                	pop    WORD PTR [bx+di]
     17c:	10 53 70             	adc    BYTE PTR [bp+di+0x70],dl
     17f:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     184:	74 45                	je     0x1cb
     186:	31 43 68             	xor    WORD PTR [bp+di+0x68],ax
     189:	61                   	popa
     18a:	6e                   	outs   dx,BYTE PTR ds:[si]
     18b:	67 65 4e             	addr32 gs dec si
     18e:	1e                   	push   ds
     18f:	a0 01 0c             	mov    al,ds:0xc01
     192:	44                   	inc    sp
     193:	42                   	inc    dx
     194:	45                   	inc    bp
     195:	64 69 74 31 45 6e    	imul   si,WORD PTR fs:[si+0x31],0x6e45
     19b:	74 65                	je     0x202
     19d:	72 e1                	jb     0x180
     19f:	21 b0 01 0b          	and    WORD PTR [bx+si+0xb01],si
     1a3:	44                   	inc    sp
     1a4:	42                   	inc    dx
     1a5:	45                   	inc    bp
     1a6:	64 69 74 31 45 78    	imul   si,WORD PTR fs:[si+0x31],0x7845
     1ac:	69 74 78 26 c3       	imul   si,WORD PTR [si+0x78],0xc326
     1b1:	01 0e 44 42          	add    WORD PTR ds:0x4244,cx
     1b5:	45                   	inc    bp
     1b6:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     1bc:	79 44                	jns    0x202
     1be:	6f                   	outs   dx,WORD PTR ds:[si]
     1bf:	77 6e                	ja     0x22f
     1c1:	cf                   	iret
     1c2:	25 d4 01             	and    ax,0x1d4
     1c5:	0c 44                	or     al,0x44
     1c7:	42                   	inc    dx
     1c8:	45                   	inc    bp
     1c9:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     1cf:	79 55                	jns    0x226
     1d1:	70 d2                	jo     0x1a5
     1d3:	2f                   	das
     1d4:	ec                   	in     al,dx
     1d5:	01 13                	add    WORD PTR [bp+di],dx
     1d7:	45                   	inc    bp
     1d8:	6e                   	outs   dx,BYTE PTR ds:[si]
     1d9:	72 65                	jb     0x240
     1db:	67 69 73 74 72 65    	imul   si,WORD PTR [ebx+0x74],0x6572
     1e1:	72 42                	jb     0x225
     1e3:	74 6e                	je     0x253
     1e5:	43                   	inc    bx
     1e6:	6c                   	ins    BYTE PTR es:[di],dx
     1e7:	69 63 6b 1a 30       	imul   sp,WORD PTR [bp+di+0x6b],0x301a
     1ec:	00 02                	add    BYTE PTR [bp+si],al
     1ee:	0f 49 6e 69          	cmovns bp,WORD PTR [bp+0x69]
     1f2:	74 69                	je     0x25d
     1f4:	61                   	popa
     1f5:	6c                   	ins    BYTE PTR es:[di],dx
     1f6:	42                   	inc    dx
     1f7:	74 6e                	je     0x267
     1f9:	43                   	inc    bx
     1fa:	6c                   	ins    BYTE PTR es:[di],dx
     1fb:	69 63 6b 69 63       	imul   sp,WORD PTR [bp+di+0x6b],0x6369
     200:	11 02                	adc    WORD PTR [bp+si],ax
     202:	0c 46                	or     al,0x46
     204:	6f                   	outs   dx,WORD PTR ds:[si]
     205:	72 6d                	jb     0x274
     207:	4b                   	dec    bx
     208:	65 79 50             	gs jns 0x25b
     20b:	72 65                	jb     0x272
     20d:	73 73                	jae    0x282
     20f:	8a 62 21             	mov    ah,BYTE PTR [bp+si+0x21]
     212:	02 0b                	add    cl,BYTE PTR [bp+di]
     214:	54                   	push   sp
     215:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     21a:	54                   	push   sp
     21b:	69 6d 65 72 84       	imul   bp,WORD PTR [di+0x65],0x8472
     220:	63 31                	arpl   WORD PTR [bx+di],si
     222:	02 0b                	add    cl,BYTE PTR [bp+di]
     224:	46                   	inc    si
     225:	6f                   	outs   dx,WORD PTR ds:[si]
     226:	72 6d                	jb     0x295
     228:	4b                   	dec    bx
     229:	65 79 44             	gs jns 0x270
     22c:	6f                   	outs   dx,WORD PTR ds:[si]
     22d:	77 6e                	ja     0x29d
     22f:	6b 64 46 02          	imul   sp,WORD PTR [si+0x46],0x2
     233:	10 44 42             	adc    BYTE PTR [si+0x42],al
     236:	45                   	inc    bp
     237:	64 69 74 31 4d 6f    	imul   si,WORD PTR fs:[si+0x31],0x6f4d
     23d:	75 73                	jne    0x2b2
     23f:	65 44                	gs inc sp
     241:	6f                   	outs   dx,WORD PTR ds:[si]
     242:	77 6e                	ja     0x2b2
     244:	b6 69                	mov    dh,0x69
     246:	59                   	pop    cx
     247:	02 0e 43 6f          	add    cl,BYTE PTR ds:0x6f43
     24b:	70 69                	jo     0x2b6
     24d:	65 72 42             	gs jb  0x292
     250:	74 6e                	je     0x2c0
     252:	43                   	inc    bx
     253:	6c                   	ins    BYTE PTR es:[di],dx
     254:	69 63 6b 2c 79       	imul   sp,WORD PTR [bp+di+0x6b],0x792c
     259:	69 02 0b 50          	imul   ax,WORD PTR [bp+si],0x500b
     25d:	72 69                	jb     0x2c8
     25f:	6e                   	outs   dx,BYTE PTR ds:[si]
     260:	74 31                	je     0x293
     262:	43                   	inc    bx
     263:	6c                   	ins    BYTE PTR es:[di],dx
     264:	69 63 6b 6f 79       	imul   sp,WORD PTR [bp+di+0x6b],0x796f
     269:	78 02                	js     0x26d
     26b:	0a 43 6f             	or     al,BYTE PTR [bp+di+0x6f]
     26e:	70 79                	jo     0x2e9
     270:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     273:	69 63 6b f9 64       	imul   sp,WORD PTR [bp+di+0x6b],0x64f9
     278:	8d 02                	lea    ax,[bp+si]
     27a:	10 50 61             	adc    BYTE PTR [bx+si+0x61],dl
     27d:	6e                   	outs   dx,BYTE PTR ds:[si]
     27e:	65 6c                	gs ins BYTE PTR es:[di],dx
     280:	31 36 4d 6f          	xor    WORD PTR ds:0x6f4d,si
     284:	75 73                	jne    0x2f9
     286:	65 44                	gs inc sp
     288:	6f                   	outs   dx,WORD PTR ds:[si]
     289:	77 6e                	ja     0x2f9
     28b:	79 10                	jns    0x29d
     28d:	9a 02 08 46 6f       	call   0x6f46:0x802
     292:	72 6d                	jb     0x301
     294:	53                   	push   bx
     295:	68 6f 77             	push   0x776f
     298:	54                   	push   sp
     299:	19 6c 0b             	sbb    WORD PTR [si+0xb],bp
     29c:	14 50                	adc    al,0x50
     29e:	72 69                	jb     0x309
     2a0:	6e                   	outs   dx,BYTE PTR ds:[si]
     2a1:	74 52                	je     0x2f5
     2a3:	61                   	popa
     2a4:	70 69                	jo     0x30f
     2a6:	64 65 42             	fs gs inc dx
     2a9:	74 6e                	je     0x319
     2ab:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     2ae:	69 63 6b a2 00       	imul   sp,WORD PTR [bp+di+0x6b],0xa2
     2b3:	07                   	pop    es
     2b4:	0b 7c 01             	or     di,WORD PTR [si+0x1]
     2b7:	00 00                	add    BYTE PTR [bx+si],al
     2b9:	07                   	pop    es
     2ba:	54                   	push   sp
     2bb:	61                   	popa
     2bc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2bf:	44                   	inc    sp
     2c0:	47                   	inc    di
     2c1:	80 01 04             	add    BYTE PTR [bx+di],0x4
     2c4:	00 0c                	add    BYTE PTR [si],cl
     2c6:	44                   	inc    sp
     2c7:	61                   	popa
     2c8:	74 61                	je     0x32b
     2ca:	53                   	push   bx
     2cb:	6f                   	outs   dx,WORD PTR ds:[si]
     2cc:	75 72                	jne    0x340
     2ce:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     2d1:	47                   	inc    di
     2d2:	84 01                	test   BYTE PTR [bx+di],al
     2d4:	04 00                	add    al,0x0
     2d6:	0d 44 61             	or     ax,0x6144
     2d9:	74 61                	je     0x33c
     2db:	53                   	push   bx
     2dc:	6f                   	outs   dx,WORD PTR ds:[si]
     2dd:	75 72                	jne    0x351
     2df:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     2e2:	50                   	push   ax
     2e3:	32 88 01 00          	xor    cl,BYTE PTR [bx+si+0x1]
     2e7:	00 07                	add    BYTE PTR [bx],al
     2e9:	54                   	push   sp
     2ea:	61                   	popa
     2eb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2ee:	44                   	inc    sp
     2ef:	4d                   	dec    bp
     2f0:	8c 01                	mov    WORD PTR [bx+di],es
     2f2:	04 00                	add    al,0x0
     2f4:	0c 44                	or     al,0x44
     2f6:	61                   	popa
     2f7:	74 61                	je     0x35a
     2f9:	53                   	push   bx
     2fa:	6f                   	outs   dx,WORD PTR ds:[si]
     2fb:	75 72                	jne    0x36f
     2fd:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     300:	4d                   	dec    bp
     301:	90                   	nop
     302:	01 04                	add    WORD PTR [si],ax
     304:	00 0d                	add    BYTE PTR [di],cl
     306:	44                   	inc    sp
     307:	61                   	popa
     308:	74 61                	je     0x36b
     30a:	53                   	push   bx
     30b:	6f                   	outs   dx,WORD PTR ds:[si]
     30c:	75 72                	jne    0x380
     30e:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     311:	50                   	push   ax
     312:	31 94 01 08          	xor    WORD PTR [si+0x801],dx
     316:	00 0f                	add    BYTE PTR [bx],cl
     318:	54                   	push   sp
     319:	61                   	popa
     31a:	62 62 65             	bound  sp,DWORD PTR [bp+si+0x65]
     31d:	64 4e                	fs dec si
     31f:	6f                   	outs   dx,WORD PTR ds:[si]
     320:	74 65                	je     0x387
     322:	62 6f 6f             	bound  bp,DWORD PTR [bx+0x6f]
     325:	6b 31 98             	imul   si,WORD PTR [bx+di],0xff98
     328:	01 0c                	add    WORD PTR [si],cx
     32a:	00 09                	add    BYTE PTR [bx+di],cl
     32c:	47                   	inc    di
     32d:	72 6f                	jb     0x39e
     32f:	75 70                	jne    0x3a1
     331:	42                   	inc    dx
     332:	6f                   	outs   dx,WORD PTR ds:[si]
     333:	78 32                	js     0x367
     335:	9c                   	pushf
     336:	01 0c                	add    WORD PTR [si],cx
     338:	00 09                	add    BYTE PTR [bx+di],cl
     33a:	47                   	inc    di
     33b:	72 6f                	jb     0x3ac
     33d:	75 70                	jne    0x3af
     33f:	42                   	inc    dx
     340:	6f                   	outs   dx,WORD PTR ds:[si]
     341:	78 31                	js     0x374
     343:	a0 01 0c             	mov    al,ds:0xc01
     346:	00 09                	add    BYTE PTR [bx+di],cl
     348:	47                   	inc    di
     349:	72 6f                	jb     0x3ba
     34b:	75 70                	jne    0x3bd
     34d:	42                   	inc    dx
     34e:	6f                   	outs   dx,WORD PTR ds:[si]
     34f:	78 34                	js     0x385
     351:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     352:	01 0c                	add    WORD PTR [si],cx
     354:	00 09                	add    BYTE PTR [bx+di],cl
     356:	47                   	inc    di
     357:	72 6f                	jb     0x3c8
     359:	75 70                	jne    0x3cb
     35b:	42                   	inc    dx
     35c:	6f                   	outs   dx,WORD PTR ds:[si]
     35d:	78 35                	js     0x394
     35f:	a8 01                	test   al,0x1
     361:	0c 00                	or     al,0x0
     363:	09 47 72             	or     WORD PTR [bx+0x72],ax
     366:	6f                   	outs   dx,WORD PTR ds:[si]
     367:	75 70                	jne    0x3d9
     369:	42                   	inc    dx
     36a:	6f                   	outs   dx,WORD PTR ds:[si]
     36b:	78 36                	js     0x3a3
     36d:	ac                   	lods   al,BYTE PTR ds:[si]
     36e:	01 0c                	add    WORD PTR [si],cx
     370:	00 09                	add    BYTE PTR [bx+di],cl
     372:	47                   	inc    di
     373:	72 6f                	jb     0x3e4
     375:	75 70                	jne    0x3e7
     377:	42                   	inc    dx
     378:	6f                   	outs   dx,WORD PTR ds:[si]
     379:	78 37                	js     0x3b2
     37b:	b0 01                	mov    al,0x1
     37d:	0c 00                	or     al,0x0
     37f:	09 47 72             	or     WORD PTR [bx+0x72],ax
     382:	6f                   	outs   dx,WORD PTR ds:[si]
     383:	75 70                	jne    0x3f5
     385:	42                   	inc    dx
     386:	6f                   	outs   dx,WORD PTR ds:[si]
     387:	78 38                	js     0x3c1
     389:	b4 01                	mov    ah,0x1
     38b:	10 00                	adc    BYTE PTR [bx+si],al
     38d:	06                   	push   es
     38e:	50                   	push   ax
     38f:	61                   	popa
     390:	6e                   	outs   dx,BYTE PTR ds:[si]
     391:	65 6c                	gs ins BYTE PTR es:[di],dx
     393:	32 b8 01 14          	xor    bh,BYTE PTR [bx+si+0x1401]
     397:	00 07                	add    BYTE PTR [bx],al
     399:	4c                   	dec    sp
     39a:	61                   	popa
     39b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     39e:	50                   	push   ax
     39f:	31 bc 01 14          	xor    WORD PTR [si+0x1401],di
     3a3:	00 07                	add    BYTE PTR [bx],al
     3a5:	4c                   	dec    sp
     3a6:	61                   	popa
     3a7:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3aa:	32 33                	xor    dh,BYTE PTR [bp+di]
     3ac:	c0 01 18             	rol    BYTE PTR [bx+di],0x18
     3af:	00 0a                	add    BYTE PTR [bp+si],cl
     3b1:	53                   	push   bx
     3b2:	70 69                	jo     0x41d
     3b4:	6e                   	outs   dx,BYTE PTR ds:[si]
     3b5:	45                   	inc    bp
     3b6:	64 69 74 45 31 c4    	imul   si,WORD PTR fs:[si+0x45],0xc431
     3bc:	01 1c                	add    WORD PTR [si],bx
     3be:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
     3c2:	69 74 45 31 c8       	imul   si,WORD PTR [si+0x45],0xc831
     3c7:	01 14                	add    WORD PTR [si],dx
     3c9:	00 07                	add    BYTE PTR [bx],al
     3cb:	4c                   	dec    sp
     3cc:	61                   	popa
     3cd:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3d0:	32 39                	xor    bh,BYTE PTR [bx+di]
     3d2:	cc                   	int3
     3d3:	01 18                	add    WORD PTR [bx+si],bx
     3d5:	00 0a                	add    BYTE PTR [bp+si],cl
     3d7:	53                   	push   bx
     3d8:	70 69                	jo     0x443
     3da:	6e                   	outs   dx,BYTE PTR ds:[si]
     3db:	45                   	inc    bp
     3dc:	64 69 74 50 31 d0    	imul   si,WORD PTR fs:[si+0x50],0xd031
     3e2:	01 1c                	add    WORD PTR [si],bx
     3e4:	00 06 45 64          	add    BYTE PTR ds:0x6445,al
     3e8:	69 74 50 31 d4       	imul   si,WORD PTR [si+0x50],0xd431
     3ed:	01 20                	add    WORD PTR [bx+si],sp
     3ef:	00 07                	add    BYTE PTR [bx],al
     3f1:	54                   	push   sp
     3f2:	65 73 74             	gs jae 0x469
     3f5:	42                   	inc    dx
     3f6:	74 6e                	je     0x466
     3f8:	d8 01                	fadd   DWORD PTR [bx+di]
     3fa:	24 00                	and    al,0x0
     3fc:	0c 50                	or     al,0x50
     3fe:	72 69                	jb     0x469
     400:	6e                   	outs   dx,BYTE PTR ds:[si]
     401:	74 44                	je     0x447
     403:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     408:	31 dc                	xor    sp,bx
     40a:	01 00                	add    WORD PTR [bx+si],ax
     40c:	00 08                	add    BYTE PTR [bx+si],cl
     40e:	54                   	push   sp
     40f:	61                   	popa
     410:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     413:	44                   	inc    sp
     414:	50                   	push   ax
     415:	31 e0                	xor    ax,sp
     417:	01 00                	add    WORD PTR [bx+si],ax
     419:	00 08                	add    BYTE PTR [bx+si],cl
     41b:	54                   	push   sp
     41c:	61                   	popa
     41d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     420:	44                   	inc    sp
     421:	50                   	push   ax
     422:	32 e4                	xor    ah,ah
     424:	01 00                	add    WORD PTR [bx+si],ax
     426:	00 0a                	add    BYTE PTR [bp+si],cl
     428:	54                   	push   sp
     429:	61                   	popa
     42a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     42d:	44                   	inc    sp
     42e:	47                   	inc    di
     42f:	42                   	inc    dx
     430:	69 73 e8 01 00       	imul   si,WORD PTR [bp+di-0x18],0x1
     435:	00 0a                	add    BYTE PTR [bp+si],cl
     437:	54                   	push   sp
     438:	61                   	popa
     439:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     43c:	44                   	inc    sp
     43d:	4d                   	dec    bp
     43e:	42                   	inc    dx
     43f:	69 73 ec 01 00       	imul   si,WORD PTR [bp+di-0x14],0x1
     444:	00 0a                	add    BYTE PTR [bp+si],cl
     446:	54                   	push   sp
     447:	61                   	popa
     448:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     44b:	44                   	inc    sp
     44c:	50                   	push   ax
     44d:	42                   	inc    dx
     44e:	69 73 f0 01 00       	imul   si,WORD PTR [bp+di-0x10],0x1
     453:	00 0b                	add    BYTE PTR [bp+di],cl
     455:	54                   	push   sp
     456:	61                   	popa
     457:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     45a:	45                   	inc    bp
     45b:	52                   	push   dx
     45c:	47                   	inc    di
     45d:	4f                   	dec    di
     45e:	6c                   	ins    BYTE PTR es:[di],dx
     45f:	64 f4                	fs hlt
     461:	01 00                	add    WORD PTR [bx+si],ax
     463:	00 08                	add    BYTE PTR [bx+si],cl
     465:	54                   	push   sp
     466:	61                   	popa
     467:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     46a:	41                   	inc    cx
     46b:	44                   	inc    sp
     46c:	50                   	push   ax
     46d:	f8                   	clc
     46e:	01 00                	add    WORD PTR [bx+si],ax
     470:	00 0b                	add    BYTE PTR [bp+di],cl
     472:	54                   	push   sp
     473:	61                   	popa
     474:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     477:	45                   	inc    bp
     478:	52                   	push   dx
     479:	50                   	push   ax
     47a:	4f                   	dec    di
     47b:	6c                   	ins    BYTE PTR es:[di],dx
     47c:	64 fc                	fs cld
     47e:	01 10                	add    WORD PTR [bx+si],dx
     480:	00 0a                	add    BYTE PTR [bp+si],cl
     482:	50                   	push   ax
     483:	61                   	popa
     484:	6e                   	outs   dx,BYTE PTR ds:[si]
     485:	65 6c                	gs ins BYTE PTR es:[di],dx
     487:	4c                   	dec    sp
     488:	4f                   	dec    di
     489:	55                   	push   bp
     48a:	50                   	push   ax
     48b:	45                   	inc    bp
     48c:	00 02                	add    BYTE PTR [bp+si],al
     48e:	00 00                	add    BYTE PTR [bx+si],al
     490:	08 54 61             	or     BYTE PTR [si+0x61],dl
     493:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     496:	41                   	inc    cx
     497:	44                   	inc    sp
     498:	47                   	inc    di
     499:	04 02                	add    al,0x2
     49b:	28 00                	sub    BYTE PTR [bx+si],al
     49d:	06                   	push   es
     49e:	54                   	push   sp
     49f:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     4a4:	08 02                	or     BYTE PTR [bp+si],al
     4a6:	0c 00                	or     al,0x0
     4a8:	09 47 72             	or     WORD PTR [bx+0x72],ax
     4ab:	6f                   	outs   dx,WORD PTR ds:[si]
     4ac:	75 70                	jne    0x51e
     4ae:	42                   	inc    dx
     4af:	6f                   	outs   dx,WORD PTR ds:[si]
     4b0:	78 33                	js     0x4e5
     4b2:	0c 02                	or     al,0x2
     4b4:	0c 00                	or     al,0x0
     4b6:	09 47 72             	or     WORD PTR [bx+0x72],ax
     4b9:	6f                   	outs   dx,WORD PTR ds:[si]
     4ba:	75 70                	jne    0x52c
     4bc:	42                   	inc    dx
     4bd:	6f                   	outs   dx,WORD PTR ds:[si]
     4be:	78 39                	js     0x4f9
     4c0:	10 02                	adc    BYTE PTR [bp+si],al
     4c2:	0c 00                	or     al,0x0
     4c4:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     4c7:	6f                   	outs   dx,WORD PTR ds:[si]
     4c8:	75 70                	jne    0x53a
     4ca:	42                   	inc    dx
     4cb:	6f                   	outs   dx,WORD PTR ds:[si]
     4cc:	78 31                	js     0x4ff
     4ce:	30 14                	xor    BYTE PTR [si],dl
     4d0:	02 0c                	add    cl,BYTE PTR [si]
     4d2:	00 0a                	add    BYTE PTR [bp+si],cl
     4d4:	47                   	inc    di
     4d5:	72 6f                	jb     0x546
     4d7:	75 70                	jne    0x549
     4d9:	42                   	inc    dx
     4da:	6f                   	outs   dx,WORD PTR ds:[si]
     4db:	78 31                	js     0x50e
     4dd:	31 18                	xor    WORD PTR [bx+si],bx
     4df:	02 00                	add    al,BYTE PTR [bx+si]
     4e1:	00 08                	add    BYTE PTR [bx+si],cl
     4e3:	54                   	push   sp
     4e4:	61                   	popa
     4e5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4e8:	41                   	inc    cx
     4e9:	43                   	inc    bx
     4ea:	47                   	inc    di
     4eb:	1c 02                	sbb    al,0x2
     4ed:	10 00                	adc    BYTE PTR [bx+si],al
     4ef:	06                   	push   es
     4f0:	50                   	push   ax
     4f1:	61                   	popa
     4f2:	6e                   	outs   dx,BYTE PTR ds:[si]
     4f3:	65 6c                	gs ins BYTE PTR es:[di],dx
     4f5:	31 20                	xor    WORD PTR [bx+si],sp
     4f7:	02 14                	add    dl,BYTE PTR [si]
     4f9:	00 07                	add    BYTE PTR [bx],al
     4fb:	4c                   	dec    sp
     4fc:	61                   	popa
     4fd:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     500:	31 30                	xor    WORD PTR [bx+si],si
     502:	24 02                	and    al,0x2
     504:	2c 00                	sub    al,0x0
     506:	09 44 42             	or     WORD PTR [si+0x42],ax
     509:	45                   	inc    bp
     50a:	64 69 74 32 31 31    	imul   si,WORD PTR fs:[si+0x32],0x3131
     510:	28 02                	sub    BYTE PTR [bp+si],al
     512:	2c 00                	sub    al,0x0
     514:	09 44 42             	or     WORD PTR [si+0x42],ax
     517:	45                   	inc    bp
     518:	64 69 74 32 31 32    	imul   si,WORD PTR fs:[si+0x32],0x3231
     51e:	2c 02                	sub    al,0x2
     520:	2c 00                	sub    al,0x0
     522:	07                   	pop    es
     523:	44                   	inc    sp
     524:	42                   	inc    dx
     525:	45                   	inc    bp
     526:	64 69 74 39 30 02    	imul   si,WORD PTR fs:[si+0x39],0x230
     52c:	2c 00                	sub    al,0x0
     52e:	08 44 42             	or     BYTE PTR [si+0x42],al
     531:	45                   	inc    bp
     532:	64 69 74 31 30 34    	imul   si,WORD PTR fs:[si+0x31],0x3430
     538:	02 10                	add    dl,BYTE PTR [bx+si]
     53a:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     53e:	6e                   	outs   dx,BYTE PTR ds:[si]
     53f:	65 6c                	gs ins BYTE PTR es:[di],dx
     541:	35 38 02             	xor    ax,0x238
     544:	14 00                	adc    al,0x0
     546:	07                   	pop    es
     547:	4c                   	dec    sp
     548:	61                   	popa
     549:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     54c:	31 31                	xor    WORD PTR [bx+di],si
     54e:	3c 02                	cmp    al,0x2
     550:	2c 00                	sub    al,0x0
     552:	09 44 42             	or     WORD PTR [si+0x42],ax
     555:	45                   	inc    bp
     556:	64 69 74 32 32 31    	imul   si,WORD PTR fs:[si+0x32],0x3132
     55c:	40                   	inc    ax
     55d:	02 2c                	add    ch,BYTE PTR [si]
     55f:	00 09                	add    BYTE PTR [bx+di],cl
     561:	44                   	inc    sp
     562:	42                   	inc    dx
     563:	45                   	inc    bp
     564:	64 69 74 32 32 32    	imul   si,WORD PTR fs:[si+0x32],0x3232
     56a:	44                   	inc    sp
     56b:	02 2c                	add    ch,BYTE PTR [si]
     56d:	00 08                	add    BYTE PTR [bx+si],cl
     56f:	44                   	inc    sp
     570:	42                   	inc    dx
     571:	45                   	inc    bp
     572:	64 69 74 31 31 48    	imul   si,WORD PTR fs:[si+0x31],0x4831
     578:	02 2c                	add    ch,BYTE PTR [si]
     57a:	00 08                	add    BYTE PTR [bx+si],cl
     57c:	44                   	inc    sp
     57d:	42                   	inc    dx
     57e:	45                   	inc    bp
     57f:	64 69 74 31 32 4c    	imul   si,WORD PTR fs:[si+0x31],0x4c32
     585:	02 10                	add    dl,BYTE PTR [bx+si]
     587:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     58b:	6e                   	outs   dx,BYTE PTR ds:[si]
     58c:	65 6c                	gs ins BYTE PTR es:[di],dx
     58e:	36 50                	ss push ax
     590:	02 14                	add    dl,BYTE PTR [si]
     592:	00 07                	add    BYTE PTR [bx],al
     594:	4c                   	dec    sp
     595:	61                   	popa
     596:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     599:	31 36 54 02          	xor    WORD PTR ds:0x254,si
     59d:	2c 00                	sub    al,0x0
     59f:	09 44 42             	or     WORD PTR [si+0x42],ax
     5a2:	45                   	inc    bp
     5a3:	64 69 74 32 31 33    	imul   si,WORD PTR fs:[si+0x32],0x3331
     5a9:	58                   	pop    ax
     5aa:	02 2c                	add    ch,BYTE PTR [si]
     5ac:	00 09                	add    BYTE PTR [bx+di],cl
     5ae:	44                   	inc    sp
     5af:	42                   	inc    dx
     5b0:	45                   	inc    bp
     5b1:	64 69 74 32 31 34    	imul   si,WORD PTR fs:[si+0x32],0x3431
     5b7:	5c                   	pop    sp
     5b8:	02 2c                	add    ch,BYTE PTR [si]
     5ba:	00 09                	add    BYTE PTR [bx+di],cl
     5bc:	44                   	inc    sp
     5bd:	42                   	inc    dx
     5be:	45                   	inc    bp
     5bf:	64 69 74 32 31 35    	imul   si,WORD PTR fs:[si+0x32],0x3531
     5c5:	60                   	pusha
     5c6:	02 30                	add    dh,BYTE PTR [bx+si]
     5c8:	00 0d                	add    BYTE PTR [di],cl
     5ca:	44                   	inc    sp
     5cb:	42                   	inc    dx
     5cc:	43                   	inc    bx
     5cd:	6f                   	outs   dx,WORD PTR ds:[si]
     5ce:	6d                   	ins    WORD PTR es:[di],dx
     5cf:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     5d2:	6f                   	outs   dx,WORD PTR ds:[si]
     5d3:	78 32                	js     0x607
     5d5:	31 31                	xor    WORD PTR [bx+di],si
     5d7:	64 02 10             	add    dl,BYTE PTR fs:[bx+si]
     5da:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     5de:	6e                   	outs   dx,BYTE PTR ds:[si]
     5df:	65 6c                	gs ins BYTE PTR es:[di],dx
     5e1:	37                   	aaa
     5e2:	68 02 14             	push   0x1402
     5e5:	00 07                	add    BYTE PTR [bx],al
     5e7:	4c                   	dec    sp
     5e8:	61                   	popa
     5e9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5ec:	31 37                	xor    WORD PTR [bx],si
     5ee:	6c                   	ins    BYTE PTR es:[di],dx
     5ef:	02 2c                	add    ch,BYTE PTR [si]
     5f1:	00 09                	add    BYTE PTR [bx+di],cl
     5f3:	44                   	inc    sp
     5f4:	42                   	inc    dx
     5f5:	45                   	inc    bp
     5f6:	64 69 74 32 32 33    	imul   si,WORD PTR fs:[si+0x32],0x3332
     5fc:	70 02                	jo     0x600
     5fe:	2c 00                	sub    al,0x0
     600:	09 44 42             	or     WORD PTR [si+0x42],ax
     603:	45                   	inc    bp
     604:	64 69 74 32 32 34    	imul   si,WORD PTR fs:[si+0x32],0x3432
     60a:	74 02                	je     0x60e
     60c:	2c 00                	sub    al,0x0
     60e:	09 44 42             	or     WORD PTR [si+0x42],ax
     611:	45                   	inc    bp
     612:	64 69 74 32 32 35    	imul   si,WORD PTR fs:[si+0x32],0x3532
     618:	78 02                	js     0x61c
     61a:	30 00                	xor    BYTE PTR [bx+si],al
     61c:	0d 44 42             	or     ax,0x4244
     61f:	43                   	inc    bx
     620:	6f                   	outs   dx,WORD PTR ds:[si]
     621:	6d                   	ins    WORD PTR es:[di],dx
     622:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     625:	6f                   	outs   dx,WORD PTR ds:[si]
     626:	78 32                	js     0x65a
     628:	32 31                	xor    dh,BYTE PTR [bx+di]
     62a:	7c 02                	jl     0x62e
     62c:	10 00                	adc    BYTE PTR [bx+si],al
     62e:	06                   	push   es
     62f:	50                   	push   ax
     630:	61                   	popa
     631:	6e                   	outs   dx,BYTE PTR ds:[si]
     632:	65 6c                	gs ins BYTE PTR es:[di],dx
     634:	38 80 02 14          	cmp    BYTE PTR [bx+si+0x1402],al
     638:	00 07                	add    BYTE PTR [bx],al
     63a:	4c                   	dec    sp
     63b:	61                   	popa
     63c:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     63f:	32 38                	xor    bh,BYTE PTR [bx+si]
     641:	84 02                	test   BYTE PTR [bp+si],al
     643:	2c 00                	sub    al,0x0
     645:	08 44 42             	or     BYTE PTR [si+0x42],al
     648:	45                   	inc    bp
     649:	64 69 74 32 30 88    	imul   si,WORD PTR fs:[si+0x32],0x8830
     64f:	02 10                	add    dl,BYTE PTR [bx+si]
     651:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     655:	6e                   	outs   dx,BYTE PTR ds:[si]
     656:	65 6c                	gs ins BYTE PTR es:[di],dx
     658:	39 8c 02 2c          	cmp    WORD PTR [si+0x2c02],cx
     65c:	00 08                	add    BYTE PTR [bx+si],cl
     65e:	44                   	inc    sp
     65f:	42                   	inc    dx
     660:	45                   	inc    bp
     661:	64 69 74 32 31 90    	imul   si,WORD PTR fs:[si+0x32],0x9031
     667:	02 14                	add    dl,BYTE PTR [si]
     669:	00 07                	add    BYTE PTR [bx],al
     66b:	4c                   	dec    sp
     66c:	61                   	popa
     66d:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     670:	33 30                	xor    si,WORD PTR [bx+si]
     672:	94                   	xchg   sp,ax
     673:	02 10                	add    dl,BYTE PTR [bx+si]
     675:	00 07                	add    BYTE PTR [bx],al
     677:	50                   	push   ax
     678:	61                   	popa
     679:	6e                   	outs   dx,BYTE PTR ds:[si]
     67a:	65 6c                	gs ins BYTE PTR es:[di],dx
     67c:	31 30                	xor    WORD PTR [bx+si],si
     67e:	98                   	cbw
     67f:	02 14                	add    dl,BYTE PTR [si]
     681:	00 07                	add    BYTE PTR [bx],al
     683:	4c                   	dec    sp
     684:	61                   	popa
     685:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     688:	33 32                	xor    si,WORD PTR [bp+si]
     68a:	9c                   	pushf
     68b:	02 2c                	add    ch,BYTE PTR [si]
     68d:	00 08                	add    BYTE PTR [bx+si],cl
     68f:	44                   	inc    sp
     690:	42                   	inc    dx
     691:	45                   	inc    bp
     692:	64 69 74 32 32 a0    	imul   si,WORD PTR fs:[si+0x32],0xa032
     698:	02 2c                	add    ch,BYTE PTR [si]
     69a:	00 08                	add    BYTE PTR [bx+si],cl
     69c:	44                   	inc    sp
     69d:	42                   	inc    dx
     69e:	45                   	inc    bp
     69f:	64 69 74 32 34 a4    	imul   si,WORD PTR fs:[si+0x32],0xa434
     6a5:	02 10                	add    dl,BYTE PTR [bx+si]
     6a7:	00 07                	add    BYTE PTR [bx],al
     6a9:	50                   	push   ax
     6aa:	61                   	popa
     6ab:	6e                   	outs   dx,BYTE PTR ds:[si]
     6ac:	65 6c                	gs ins BYTE PTR es:[di],dx
     6ae:	31 31                	xor    WORD PTR [bx+di],si
     6b0:	a8 02                	test   al,0x2
     6b2:	14 00                	adc    al,0x0
     6b4:	07                   	pop    es
     6b5:	4c                   	dec    sp
     6b6:	61                   	popa
     6b7:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6ba:	33 33                	xor    si,WORD PTR [bp+di]
     6bc:	ac                   	lods   al,BYTE PTR ds:[si]
     6bd:	02 2c                	add    ch,BYTE PTR [si]
     6bf:	00 08                	add    BYTE PTR [bx+si],cl
     6c1:	44                   	inc    sp
     6c2:	42                   	inc    dx
     6c3:	45                   	inc    bp
     6c4:	64 69 74 32 33 b0    	imul   si,WORD PTR fs:[si+0x32],0xb033
     6ca:	02 2c                	add    ch,BYTE PTR [si]
     6cc:	00 08                	add    BYTE PTR [bx+si],cl
     6ce:	44                   	inc    sp
     6cf:	42                   	inc    dx
     6d0:	45                   	inc    bp
     6d1:	64 69 74 32 35 b4    	imul   si,WORD PTR fs:[si+0x32],0xb435
     6d7:	02 0c                	add    cl,BYTE PTR [si]
     6d9:	00 0a                	add    BYTE PTR [bp+si],cl
     6db:	47                   	inc    di
     6dc:	72 6f                	jb     0x74d
     6de:	75 70                	jne    0x750
     6e0:	42                   	inc    dx
     6e1:	6f                   	outs   dx,WORD PTR ds:[si]
     6e2:	78 31                	js     0x715
     6e4:	32 b8 02 10          	xor    bh,BYTE PTR [bx+si+0x1002]
     6e8:	00 07                	add    BYTE PTR [bx],al
     6ea:	50                   	push   ax
     6eb:	61                   	popa
     6ec:	6e                   	outs   dx,BYTE PTR ds:[si]
     6ed:	65 6c                	gs ins BYTE PTR es:[di],dx
     6ef:	31 32                	xor    WORD PTR [bp+si],si
     6f1:	bc 02 10             	mov    sp,0x1002
     6f4:	00 07                	add    BYTE PTR [bx],al
     6f6:	50                   	push   ax
     6f7:	61                   	popa
     6f8:	6e                   	outs   dx,BYTE PTR ds:[si]
     6f9:	65 6c                	gs ins BYTE PTR es:[di],dx
     6fb:	31 33                	xor    WORD PTR [bp+di],si
     6fd:	c0 02 10             	rol    BYTE PTR [bp+si],0x10
     700:	00 07                	add    BYTE PTR [bx],al
     702:	50                   	push   ax
     703:	61                   	popa
     704:	6e                   	outs   dx,BYTE PTR ds:[si]
     705:	65 6c                	gs ins BYTE PTR es:[di],dx
     707:	31 34                	xor    WORD PTR [si],si
     709:	c4 02                	les    ax,DWORD PTR [bp+si]
     70b:	2c 00                	sub    al,0x0
     70d:	08 44 42             	or     BYTE PTR [si+0x42],al
     710:	45                   	inc    bp
     711:	64 69 74 31 33 c8    	imul   si,WORD PTR fs:[si+0x31],0xc833
     717:	02 2c                	add    ch,BYTE PTR [si]
     719:	00 08                	add    BYTE PTR [bx+si],cl
     71b:	44                   	inc    sp
     71c:	42                   	inc    dx
     71d:	45                   	inc    bp
     71e:	64 69 74 31 34 cc    	imul   si,WORD PTR fs:[si+0x31],0xcc34
     724:	02 34                	add    dh,BYTE PTR [si]
     726:	00 05                	add    BYTE PTR [di],al
     728:	4d                   	dec    bp
     729:	65 6d                	gs ins WORD PTR es:[di],dx
     72b:	6f                   	outs   dx,WORD PTR ds:[si]
     72c:	31 d0                	xor    ax,dx
     72e:	02 38                	add    bh,BYTE PTR [bx+si]
     730:	00 0a                	add    BYTE PTR [bp+si],cl
     732:	50                   	push   ax
     733:	6f                   	outs   dx,WORD PTR ds:[si]
     734:	70 75                	jo     0x7ab
     736:	70 4d                	jo     0x785
     738:	65 6e                	outs   dx,BYTE PTR gs:[si]
     73a:	75 31                	jne    0x76d
     73c:	d4 02                	aam    0x2
     73e:	3c 00                	cmp    al,0x0
     740:	06                   	push   es
     741:	50                   	push   ax
     742:	72 69                	jb     0x7ad
     744:	6e                   	outs   dx,BYTE PTR ds:[si]
     745:	74 31                	je     0x778
     747:	d8 02                	fadd   DWORD PTR [bp+si]
     749:	3c 00                	cmp    al,0x0
     74b:	05 43 6f             	add    ax,0x6f43
     74e:	70 79                	jo     0x7c9
     750:	31 dc                	xor    sp,bx
     752:	02 40 00             	add    al,BYTE PTR [bx+si+0x0]
     755:	06                   	push   es
     756:	49                   	dec    cx
     757:	6d                   	ins    WORD PTR es:[di],dx
     758:	61                   	popa
     759:	67 65 31 e0          	addr32 gs xor ax,sp
     75d:	02 10                	add    dl,BYTE PTR [bx+si]
     75f:	00 07                	add    BYTE PTR [bx],al
     761:	50                   	push   ax
     762:	61                   	popa
     763:	6e                   	outs   dx,BYTE PTR ds:[si]
     764:	65 6c                	gs ins BYTE PTR es:[di],dx
     766:	31 36 e4 02          	xor    WORD PTR ds:0x2e4,si
     76a:	2c 00                	sub    al,0x0
     76c:	07                   	pop    es
     76d:	44                   	inc    sp
     76e:	42                   	inc    dx
     76f:	45                   	inc    bp
     770:	64 69 74 31 e8 02    	imul   si,WORD PTR fs:[si+0x31],0x2e8
     776:	10 00                	adc    BYTE PTR [bx+si],al
     778:	07                   	pop    es
     779:	50                   	push   ax
     77a:	61                   	popa
     77b:	6e                   	outs   dx,BYTE PTR ds:[si]
     77c:	65 6c                	gs ins BYTE PTR es:[di],dx
     77e:	31 37                	xor    WORD PTR [bx],si
     780:	ec                   	in     al,dx
     781:	02 2c                	add    ch,BYTE PTR [si]
     783:	00 07                	add    BYTE PTR [bx],al
     785:	44                   	inc    sp
     786:	42                   	inc    dx
     787:	45                   	inc    bp
     788:	64 69 74 32 f0 02    	imul   si,WORD PTR fs:[si+0x32],0x2f0
     78e:	10 00                	adc    BYTE PTR [bx+si],al
     790:	07                   	pop    es
     791:	50                   	push   ax
     792:	61                   	popa
     793:	6e                   	outs   dx,BYTE PTR ds:[si]
     794:	65 6c                	gs ins BYTE PTR es:[di],dx
     796:	31 38                	xor    WORD PTR [bx+si],di
     798:	f4                   	hlt
     799:	02 2c                	add    ch,BYTE PTR [si]
     79b:	00 07                	add    BYTE PTR [bx],al
     79d:	44                   	inc    sp
     79e:	42                   	inc    dx
     79f:	45                   	inc    bp
     7a0:	64 69 74 33 f8 02    	imul   si,WORD PTR fs:[si+0x33],0x2f8
     7a6:	10 00                	adc    BYTE PTR [bx+si],al
     7a8:	07                   	pop    es
     7a9:	50                   	push   ax
     7aa:	61                   	popa
     7ab:	6e                   	outs   dx,BYTE PTR ds:[si]
     7ac:	65 6c                	gs ins BYTE PTR es:[di],dx
     7ae:	31 39                	xor    WORD PTR [bx+di],di
     7b0:	fc                   	cld
     7b1:	02 2c                	add    ch,BYTE PTR [si]
     7b3:	00 07                	add    BYTE PTR [bx],al
     7b5:	44                   	inc    sp
     7b6:	42                   	inc    dx
     7b7:	45                   	inc    bp
     7b8:	64 69 74 34 00 03    	imul   si,WORD PTR fs:[si+0x34],0x300
     7be:	10 00                	adc    BYTE PTR [bx+si],al
     7c0:	07                   	pop    es
     7c1:	50                   	push   ax
     7c2:	61                   	popa
     7c3:	6e                   	outs   dx,BYTE PTR ds:[si]
     7c4:	65 6c                	gs ins BYTE PTR es:[di],dx
     7c6:	32 30                	xor    dh,BYTE PTR [bx+si]
     7c8:	04 03                	add    al,0x3
     7ca:	2c 00                	sub    al,0x0
     7cc:	07                   	pop    es
     7cd:	44                   	inc    sp
     7ce:	42                   	inc    dx
     7cf:	45                   	inc    bp
     7d0:	64 69 74 38 08 03    	imul   si,WORD PTR fs:[si+0x38],0x308
     7d6:	10 00                	adc    BYTE PTR [bx+si],al
     7d8:	07                   	pop    es
     7d9:	50                   	push   ax
     7da:	61                   	popa
     7db:	6e                   	outs   dx,BYTE PTR ds:[si]
     7dc:	65 6c                	gs ins BYTE PTR es:[di],dx
     7de:	32 31                	xor    dh,BYTE PTR [bx+di]
     7e0:	0c 03                	or     al,0x3
     7e2:	2c 00                	sub    al,0x0
     7e4:	07                   	pop    es
     7e5:	44                   	inc    sp
     7e6:	42                   	inc    dx
     7e7:	45                   	inc    bp
     7e8:	64 69 74 35 10 03    	imul   si,WORD PTR fs:[si+0x35],0x310
     7ee:	10 00                	adc    BYTE PTR [bx+si],al
     7f0:	07                   	pop    es
     7f1:	50                   	push   ax
     7f2:	61                   	popa
     7f3:	6e                   	outs   dx,BYTE PTR ds:[si]
     7f4:	65 6c                	gs ins BYTE PTR es:[di],dx
     7f6:	32 32                	xor    dh,BYTE PTR [bp+si]
     7f8:	14 03                	adc    al,0x3
     7fa:	2c 00                	sub    al,0x0
     7fc:	07                   	pop    es
     7fd:	44                   	inc    sp
     7fe:	42                   	inc    dx
     7ff:	45                   	inc    bp
     800:	64 69 74 36 18 03    	imul   si,WORD PTR fs:[si+0x36],0x318
     806:	10 00                	adc    BYTE PTR [bx+si],al
     808:	07                   	pop    es
     809:	50                   	push   ax
     80a:	61                   	popa
     80b:	6e                   	outs   dx,BYTE PTR ds:[si]
     80c:	65 6c                	gs ins BYTE PTR es:[di],dx
     80e:	32 33                	xor    dh,BYTE PTR [bp+di]
     810:	1c 03                	sbb    al,0x3
     812:	18 00                	sbb    BYTE PTR [bx+si],al
     814:	09 53 70             	or     WORD PTR [bp+di+0x70],dx
     817:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     81c:	74 31                	je     0x84f
     81e:	20 03                	and    BYTE PTR [bp+di],al
     820:	10 00                	adc    BYTE PTR [bx+si],al
     822:	07                   	pop    es
     823:	50                   	push   ax
     824:	61                   	popa
     825:	6e                   	outs   dx,BYTE PTR ds:[si]
     826:	65 6c                	gs ins BYTE PTR es:[di],dx
     828:	32 34                	xor    dh,BYTE PTR [si]
     82a:	24 03                	and    al,0x3
     82c:	10 00                	adc    BYTE PTR [bx+si],al
     82e:	07                   	pop    es
     82f:	50                   	push   ax
     830:	61                   	popa
     831:	6e                   	outs   dx,BYTE PTR ds:[si]
     832:	65 6c                	gs ins BYTE PTR es:[di],dx
     834:	32 35                	xor    dh,BYTE PTR [di]
     836:	28 03                	sub    BYTE PTR [bp+di],al
     838:	10 00                	adc    BYTE PTR [bx+si],al
     83a:	07                   	pop    es
     83b:	50                   	push   ax
     83c:	61                   	popa
     83d:	6e                   	outs   dx,BYTE PTR ds:[si]
     83e:	65 6c                	gs ins BYTE PTR es:[di],dx
     840:	32 36 2c 03          	xor    dh,BYTE PTR ds:0x32c
     844:	10 00                	adc    BYTE PTR [bx+si],al
     846:	07                   	pop    es
     847:	50                   	push   ax
     848:	61                   	popa
     849:	6e                   	outs   dx,BYTE PTR ds:[si]
     84a:	65 6c                	gs ins BYTE PTR es:[di],dx
     84c:	32 37                	xor    dh,BYTE PTR [bx]
     84e:	30 03                	xor    BYTE PTR [bp+di],al
     850:	10 00                	adc    BYTE PTR [bx+si],al
     852:	07                   	pop    es
     853:	50                   	push   ax
     854:	61                   	popa
     855:	6e                   	outs   dx,BYTE PTR ds:[si]
     856:	65 6c                	gs ins BYTE PTR es:[di],dx
     858:	32 38                	xor    bh,BYTE PTR [bx+si]
     85a:	34 03                	xor    al,0x3
     85c:	10 00                	adc    BYTE PTR [bx+si],al
     85e:	07                   	pop    es
     85f:	50                   	push   ax
     860:	61                   	popa
     861:	6e                   	outs   dx,BYTE PTR ds:[si]
     862:	65 6c                	gs ins BYTE PTR es:[di],dx
     864:	32 39                	xor    bh,BYTE PTR [bx+di]
     866:	38 03                	cmp    BYTE PTR [bp+di],al
     868:	10 00                	adc    BYTE PTR [bx+si],al
     86a:	07                   	pop    es
     86b:	50                   	push   ax
     86c:	61                   	popa
     86d:	6e                   	outs   dx,BYTE PTR ds:[si]
     86e:	65 6c                	gs ins BYTE PTR es:[di],dx
     870:	33 30                	xor    si,WORD PTR [bx+si]
     872:	3c 03                	cmp    al,0x3
     874:	10 00                	adc    BYTE PTR [bx+si],al
     876:	07                   	pop    es
     877:	50                   	push   ax
     878:	61                   	popa
     879:	6e                   	outs   dx,BYTE PTR ds:[si]
     87a:	65 6c                	gs ins BYTE PTR es:[di],dx
     87c:	33 31                	xor    si,WORD PTR [bx+di]
     87e:	40                   	inc    ax
     87f:	03 10                	add    dx,WORD PTR [bx+si]
     881:	00 07                	add    BYTE PTR [bx],al
     883:	50                   	push   ax
     884:	61                   	popa
     885:	6e                   	outs   dx,BYTE PTR ds:[si]
     886:	65 6c                	gs ins BYTE PTR es:[di],dx
     888:	33 32                	xor    si,WORD PTR [bp+si]
     88a:	44                   	inc    sp
     88b:	03 10                	add    dx,WORD PTR [bx+si]
     88d:	00 07                	add    BYTE PTR [bx],al
     88f:	50                   	push   ax
     890:	61                   	popa
     891:	6e                   	outs   dx,BYTE PTR ds:[si]
     892:	65 6c                	gs ins BYTE PTR es:[di],dx
     894:	33 33                	xor    si,WORD PTR [bp+di]
     896:	48                   	dec    ax
     897:	03 2c                	add    bp,WORD PTR [si]
     899:	00 08                	add    BYTE PTR [bx+si],cl
     89b:	44                   	inc    sp
     89c:	42                   	inc    dx
     89d:	45                   	inc    bp
     89e:	64 69 74 31 37 4c    	imul   si,WORD PTR fs:[si+0x31],0x4c37
     8a4:	03 10                	add    dx,WORD PTR [bx+si]
     8a6:	00 07                	add    BYTE PTR [bx],al
     8a8:	50                   	push   ax
     8a9:	61                   	popa
     8aa:	6e                   	outs   dx,BYTE PTR ds:[si]
     8ab:	65 6c                	gs ins BYTE PTR es:[di],dx
     8ad:	33 34                	xor    si,WORD PTR [si]
     8af:	50                   	push   ax
     8b0:	03 2c                	add    bp,WORD PTR [si]
     8b2:	00 08                	add    BYTE PTR [bx+si],cl
     8b4:	44                   	inc    sp
     8b5:	42                   	inc    dx
     8b6:	45                   	inc    bp
     8b7:	64 69 74 31 38 54    	imul   si,WORD PTR fs:[si+0x31],0x5438
     8bd:	03 10                	add    dx,WORD PTR [bx+si]
     8bf:	00 07                	add    BYTE PTR [bx],al
     8c1:	50                   	push   ax
     8c2:	61                   	popa
     8c3:	6e                   	outs   dx,BYTE PTR ds:[si]
     8c4:	65 6c                	gs ins BYTE PTR es:[di],dx
     8c6:	33 35                	xor    si,WORD PTR [di]
     8c8:	58                   	pop    ax
     8c9:	03 2c                	add    bp,WORD PTR [si]
     8cb:	00 08                	add    BYTE PTR [bx+si],cl
     8cd:	44                   	inc    sp
     8ce:	42                   	inc    dx
     8cf:	45                   	inc    bp
     8d0:	64 69 74 31 39 5c    	imul   si,WORD PTR fs:[si+0x31],0x5c39
     8d6:	03 10                	add    dx,WORD PTR [bx+si]
     8d8:	00 07                	add    BYTE PTR [bx],al
     8da:	50                   	push   ax
     8db:	61                   	popa
     8dc:	6e                   	outs   dx,BYTE PTR ds:[si]
     8dd:	65 6c                	gs ins BYTE PTR es:[di],dx
     8df:	33 36 60 03          	xor    si,WORD PTR ds:0x360
     8e3:	2c 00                	sub    al,0x0
     8e5:	08 44 42             	or     BYTE PTR [si+0x42],al
     8e8:	45                   	inc    bp
     8e9:	64 69 74 31 35 64    	imul   si,WORD PTR fs:[si+0x31],0x6435
     8ef:	03 10                	add    dx,WORD PTR [bx+si]
     8f1:	00 07                	add    BYTE PTR [bx],al
     8f3:	50                   	push   ax
     8f4:	61                   	popa
     8f5:	6e                   	outs   dx,BYTE PTR ds:[si]
     8f6:	65 6c                	gs ins BYTE PTR es:[di],dx
     8f8:	33 37                	xor    si,WORD PTR [bx]
     8fa:	68 03 2c             	push   0x2c03
     8fd:	00 08                	add    BYTE PTR [bx+si],cl
     8ff:	44                   	inc    sp
     900:	42                   	inc    dx
     901:	45                   	inc    bp
     902:	64 69 74 31 36 6c    	imul   si,WORD PTR fs:[si+0x31],0x6c36
     908:	03 10                	add    dx,WORD PTR [bx+si]
     90a:	00 07                	add    BYTE PTR [bx],al
     90c:	50                   	push   ax
     90d:	61                   	popa
     90e:	6e                   	outs   dx,BYTE PTR ds:[si]
     90f:	65 6c                	gs ins BYTE PTR es:[di],dx
     911:	33 38                	xor    di,WORD PTR [bx+si]
     913:	70 03                	jo     0x918
     915:	44                   	inc    sp
     916:	00 0b                	add    BYTE PTR [bp+di],cl
     918:	44                   	inc    sp
     919:	42                   	inc    dx
     91a:	43                   	inc    bx
     91b:	68 65 63             	push   0x6365
     91e:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     922:	31 74 03             	xor    WORD PTR [si+0x3],si
     925:	10 00                	adc    BYTE PTR [bx+si],al
     927:	07                   	pop    es
     928:	50                   	push   ax
     929:	61                   	popa
     92a:	6e                   	outs   dx,BYTE PTR ds:[si]
     92b:	65 6c                	gs ins BYTE PTR es:[di],dx
     92d:	33 39                	xor    di,WORD PTR [bx+di]
     92f:	78 03                	js     0x934
     931:	44                   	inc    sp
     932:	00 0b                	add    BYTE PTR [bp+di],cl
     934:	44                   	inc    sp
     935:	42                   	inc    dx
     936:	43                   	inc    bx
     937:	68 65 63             	push   0x6365
     93a:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     93e:	32 7c 03             	xor    bh,BYTE PTR [si+0x3]
     941:	10 00                	adc    BYTE PTR [bx+si],al
     943:	07                   	pop    es
     944:	50                   	push   ax
     945:	61                   	popa
     946:	6e                   	outs   dx,BYTE PTR ds:[si]
     947:	65 6c                	gs ins BYTE PTR es:[di],dx
     949:	34 30                	xor    al,0x30
     94b:	80 03 44             	add    BYTE PTR [bp+di],0x44
     94e:	00 0b                	add    BYTE PTR [bp+di],cl
     950:	44                   	inc    sp
     951:	42                   	inc    dx
     952:	43                   	inc    bx
     953:	68 65 63             	push   0x6365
     956:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     95a:	33 84 03 10          	xor    ax,WORD PTR [si+0x1003]
     95e:	00 07                	add    BYTE PTR [bx],al
     960:	50                   	push   ax
     961:	61                   	popa
     962:	6e                   	outs   dx,BYTE PTR ds:[si]
     963:	65 6c                	gs ins BYTE PTR es:[di],dx
     965:	34 31                	xor    al,0x31
     967:	88 03                	mov    BYTE PTR [bp+di],al
     969:	44                   	inc    sp
     96a:	00 0b                	add    BYTE PTR [bp+di],cl
     96c:	44                   	inc    sp
     96d:	42                   	inc    dx
     96e:	43                   	inc    bx
     96f:	68 65 63             	push   0x6365
     972:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     976:	34 8c                	xor    al,0x8c
     978:	03 10                	add    dx,WORD PTR [bx+si]
     97a:	00 07                	add    BYTE PTR [bx],al
     97c:	50                   	push   ax
     97d:	61                   	popa
     97e:	6e                   	outs   dx,BYTE PTR ds:[si]
     97f:	65 6c                	gs ins BYTE PTR es:[di],dx
     981:	34 32                	xor    al,0x32
     983:	90                   	nop
     984:	03 44 00             	add    ax,WORD PTR [si+0x0]
     987:	0b 44 42             	or     ax,WORD PTR [si+0x42]
     98a:	43                   	inc    bx
     98b:	68 65 63             	push   0x6365
     98e:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     992:	35 94 03             	xor    ax,0x394
     995:	10 00                	adc    BYTE PTR [bx+si],al
     997:	07                   	pop    es
     998:	50                   	push   ax
     999:	61                   	popa
     99a:	6e                   	outs   dx,BYTE PTR ds:[si]
     99b:	65 6c                	gs ins BYTE PTR es:[di],dx
     99d:	34 33                	xor    al,0x33
     99f:	98                   	cbw
     9a0:	03 44 00             	add    ax,WORD PTR [si+0x0]
     9a3:	0b 44 42             	or     ax,WORD PTR [si+0x42]
     9a6:	43                   	inc    bx
     9a7:	68 65 63             	push   0x6365
     9aa:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     9ae:	36 9c                	ss pushf
     9b0:	03 10                	add    dx,WORD PTR [bx+si]
     9b2:	00 07                	add    BYTE PTR [bx],al
     9b4:	50                   	push   ax
     9b5:	61                   	popa
     9b6:	6e                   	outs   dx,BYTE PTR ds:[si]
     9b7:	65 6c                	gs ins BYTE PTR es:[di],dx
     9b9:	34 34                	xor    al,0x34
     9bb:	a0 03 44             	mov    al,ds:0x4403
     9be:	00 0b                	add    BYTE PTR [bp+di],cl
     9c0:	44                   	inc    sp
     9c1:	42                   	inc    dx
     9c2:	43                   	inc    bx
     9c3:	68 65 63             	push   0x6365
     9c6:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     9ca:	37                   	aaa
     9cb:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     9cc:	03 10                	add    dx,WORD PTR [bx+si]
     9ce:	00 07                	add    BYTE PTR [bx],al
     9d0:	50                   	push   ax
     9d1:	61                   	popa
     9d2:	6e                   	outs   dx,BYTE PTR ds:[si]
     9d3:	65 6c                	gs ins BYTE PTR es:[di],dx
     9d5:	34 35                	xor    al,0x35
     9d7:	a8 03                	test   al,0x3
     9d9:	2c 00                	sub    al,0x0
     9db:	07                   	pop    es
     9dc:	44                   	inc    sp
     9dd:	42                   	inc    dx
     9de:	45                   	inc    bp
     9df:	64 69 74 37 ac 03    	imul   si,WORD PTR fs:[si+0x37],0x3ac
     9e5:	10 00                	adc    BYTE PTR [bx+si],al
     9e7:	07                   	pop    es
     9e8:	50                   	push   ax
     9e9:	61                   	popa
     9ea:	6e                   	outs   dx,BYTE PTR ds:[si]
     9eb:	65 6c                	gs ins BYTE PTR es:[di],dx
     9ed:	34 36                	xor    al,0x36
     9ef:	b0 03                	mov    al,0x3
     9f1:	10 00                	adc    BYTE PTR [bx+si],al
     9f3:	07                   	pop    es
     9f4:	50                   	push   ax
     9f5:	61                   	popa
     9f6:	6e                   	outs   dx,BYTE PTR ds:[si]
     9f7:	65 6c                	gs ins BYTE PTR es:[di],dx
     9f9:	34 37                	xor    al,0x37
     9fb:	b4 03                	mov    ah,0x3
     9fd:	10 00                	adc    BYTE PTR [bx+si],al
     9ff:	07                   	pop    es
     a00:	50                   	push   ax
     a01:	61                   	popa
     a02:	6e                   	outs   dx,BYTE PTR ds:[si]
     a03:	65 6c                	gs ins BYTE PTR es:[di],dx
     a05:	34 38                	xor    al,0x38
     a07:	b8 03 10             	mov    ax,0x1003
     a0a:	00 07                	add    BYTE PTR [bx],al
     a0c:	50                   	push   ax
     a0d:	61                   	popa
     a0e:	6e                   	outs   dx,BYTE PTR ds:[si]
     a0f:	65 6c                	gs ins BYTE PTR es:[di],dx
     a11:	31 35                	xor    WORD PTR [di],si
     a13:	bc 03 1c             	mov    sp,0x1c03
     a16:	00 05                	add    BYTE PTR [di],al
     a18:	45                   	inc    bp
     a19:	64 69 74 31 c0 03    	imul   si,WORD PTR fs:[si+0x31],0x3c0
     a1f:	10 00                	adc    BYTE PTR [bx+si],al
     a21:	07                   	pop    es
     a22:	50                   	push   ax
     a23:	61                   	popa
     a24:	6e                   	outs   dx,BYTE PTR ds:[si]
     a25:	65 6c                	gs ins BYTE PTR es:[di],dx
     a27:	36 36 c4 03          	ss les ax,DWORD PTR ss:[bp+di]
     a2b:	10 00                	adc    BYTE PTR [bx+si],al
     a2d:	07                   	pop    es
     a2e:	50                   	push   ax
     a2f:	61                   	popa
     a30:	6e                   	outs   dx,BYTE PTR ds:[si]
     a31:	65 6c                	gs ins BYTE PTR es:[di],dx
     a33:	34 39                	xor    al,0x39
     a35:	c8 03 10 00          	enter  0x1003,0x0
     a39:	06                   	push   es
     a3a:	50                   	push   ax
     a3b:	61                   	popa
     a3c:	6e                   	outs   dx,BYTE PTR ds:[si]
     a3d:	65 6c                	gs ins BYTE PTR es:[di],dx
     a3f:	33 cc                	xor    cx,sp
     a41:	03 20                	add    sp,WORD PTR [bx+si]
     a43:	00 0e 45 6e          	add    BYTE PTR ds:0x6e45,cl
     a47:	72 65                	jb     0xaae
     a49:	67 69 73 74 72 65    	imul   si,WORD PTR [ebx+0x74],0x6572
     a4f:	72 42                	jb     0xa93
     a51:	74 6e                	je     0xac1
     a53:	d0 03                	rol    BYTE PTR [bp+di],1
     a55:	20 00                	and    BYTE PTR [bx+si],al
     a57:	09 44 65             	or     WORD PTR [si+0x65],ax
     a5a:	66 61                	popad
     a5c:	75 74                	jne    0xad2
     a5e:	42                   	inc    dx
     a5f:	74 6e                	je     0xacf
     a61:	d4 03                	aam    0x3
     a63:	20 00                	and    BYTE PTR [bx+si],al
     a65:	0a 49 6e             	or     cl,BYTE PTR [bx+di+0x6e]
     a68:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
     a6d:	42                   	inc    dx
     a6e:	74 6e                	je     0xade
     a70:	d8 03                	fadd   DWORD PTR [bp+di]
     a72:	10 00                	adc    BYTE PTR [bx+si],al
     a74:	07                   	pop    es
     a75:	50                   	push   ax
     a76:	61                   	popa
     a77:	6e                   	outs   dx,BYTE PTR ds:[si]
     a78:	65 6c                	gs ins BYTE PTR es:[di],dx
     a7a:	35 30 dc             	xor    ax,0xdc30
     a7d:	03 10                	add    dx,WORD PTR [bx+si]
     a7f:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     a83:	6e                   	outs   dx,BYTE PTR ds:[si]
     a84:	65 6c                	gs ins BYTE PTR es:[di],dx
     a86:	34 e0                	xor    al,0xe0
     a88:	03 48 00             	add    cx,WORD PTR [bx+si+0x0]
     a8b:	0a 43 68             	or     al,BYTE PTR [bp+di+0x68]
     a8e:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     a92:	6f                   	outs   dx,WORD PTR ds:[si]
     a93:	78 56                	js     0xaeb
     a95:	31 e4                	xor    sp,sp
     a97:	03 20                	add    sp,WORD PTR [bx+si]
     a99:	00 0b                	add    BYTE PTR [bp+di],cl
     a9b:	56                   	push   si
     a9c:	65 72 69             	gs jb  0xb08
     a9f:	66 69 65 72 42 74 6e 	imul   esp,DWORD PTR [di+0x72],0xe86e7442
     aa6:	e8 
     aa7:	03 20                	add    sp,WORD PTR [bx+si]
     aa9:	00 05                	add    BYTE PTR [di],al
     aab:	4f                   	dec    di
     aac:	4b                   	dec    bx
     aad:	42                   	inc    dx
     aae:	74 6e                	je     0xb1e
     ab0:	ec                   	in     al,dx
     ab1:	03 20                	add    sp,WORD PTR [bx+si]
     ab3:	00 07                	add    BYTE PTR [bx],al
     ab5:	48                   	dec    ax
     ab6:	65 6c                	gs ins BYTE PTR es:[di],dx
     ab8:	70 42                	jo     0xafc
     aba:	74 6e                	je     0xb2a
     abc:	f0 03 20             	lock add sp,WORD PTR [bx+si]
     abf:	00 08                	add    BYTE PTR [bx+si],cl
     ac1:	50                   	push   ax
     ac2:	72 69                	jb     0xb2d
     ac4:	6e                   	outs   dx,BYTE PTR ds:[si]
     ac5:	74 42                	je     0xb09
     ac7:	74 6e                	je     0xb37
     ac9:	f4                   	hlt
     aca:	03 20                	add    sp,WORD PTR [bx+si]
     acc:	00 09                	add    BYTE PTR [bx+di],cl
     ace:	43                   	inc    bx
     acf:	6f                   	outs   dx,WORD PTR ds:[si]
     ad0:	70 69                	jo     0xb3b
     ad2:	65 72 42             	gs jb  0xb17
     ad5:	74 6e                	je     0xb45
     ad7:	f8                   	clc
     ad8:	03 20                	add    sp,WORD PTR [bx+si]
     ada:	00 0f                	add    BYTE PTR [bx],cl
     adc:	50                   	push   ax
     add:	72 69                	jb     0xb48
     adf:	6e                   	outs   dx,BYTE PTR ds:[si]
     ae0:	74 52                	je     0xb34
     ae2:	61                   	popa
     ae3:	70 69                	jo     0xb4e
     ae5:	64 65 42             	fs gs inc dx
     ae8:	74 6e                	je     0xb58
     aea:	31 fc                	xor    sp,di
     aec:	03 20                	add    sp,WORD PTR [bx+si]
     aee:	00 0a                	add    BYTE PTR [bp+si],cl
     af0:	42                   	inc    dx
     af1:	61                   	popa
     af2:	73 63                	jae    0xb57
     af4:	75 6c                	jne    0xb62
     af6:	65 42                	gs inc dx
     af8:	74 6e                	je     0xb68
     afa:	00 04                	add    BYTE PTR [si],al
     afc:	2c 00                	sub    al,0x0
     afe:	08 44 42             	or     BYTE PTR [si+0x42],al
     b01:	45                   	inc    bp
     b02:	64 69 74 32 36 13    	imul   si,WORD PTR fs:[si+0x32],0x1336
     b08:	00 38                	add    BYTE PTR [bx+si],bh
     b0a:	01 92 0f c8          	add    WORD PTR [bp+si-0x37f1],dx
     b0e:	08 46 1a             	or     BYTE PTR [bp+0x1a],al
     b11:	ed                   	in     ax,dx
     b12:	01 40 0e             	add    WORD PTR [bx+si+0xe],ax
     b15:	0c 01                	or     al,0x1
     b17:	1f                   	pop    ds
     b18:	0b ad 0d 33          	or     bp,WORD PTR [di+0x330d]
     b1c:	0b 17                	or     dx,WORD PTR [bx]
     b1e:	06                   	push   es
     b1f:	27                   	daa
     b20:	0b eb                	or     bp,bx
     b22:	03 32                	add    si,WORD PTR [bp+si]
     b24:	14 90                	adc    al,0x90
     b26:	0b 3f                	or     di,WORD PTR [bx]
     b28:	0b ac 04 ca          	or     bp,WORD PTR [si-0x35fc]
     b2c:	78 7e                	js     0xbac
     b2e:	08 c8                	or     al,cl
     b30:	18 8b 0b 4b          	sbb    BYTE PTR [bp+di+0x4b0b],cl
     b34:	0b 22                	or     sp,WORD PTR [bp+si]
     b36:	00 3b                	add    BYTE PTR [bp+di],bh
     b38:	0b a2 0b 4f          	or     sp,WORD PTR [bp+si+0x4f0b]
     b3c:	0b 91 12 53          	or     dx,WORD PTR [bx+di+0x5312]
     b40:	0b c6                	or     ax,si
     b42:	03 47 0b             	add    ax,WORD PTR [bx+0xb]
     b45:	94                   	xchg   sp,ax
     b46:	00 ff                	add    bh,bh
     b48:	ff 65 06             	jmp    WORD PTR [di+0x6]
     b4b:	28 66 26             	sub    BYTE PTR [bp+0x26],ah
     b4e:	06                   	push   es
     b4f:	2c 1a                	sub    al,0x1a
     b51:	22 27                	and    ah,BYTE PTR [bx]
     b53:	8f                   	(bad)
     b54:	21 07                	and    WORD PTR [bx],ax
     b56:	13 54 46             	adc    dx,WORD PTR [si+0x46]
     b59:	6f                   	outs   dx,WORD PTR ds:[si]
     b5a:	72 6d                	jb     0xbc9
     b5c:	53                   	push   bx
     b5d:	45                   	inc    bp
     b5e:	44                   	inc    sp
     b5f:	44                   	inc    sp
     b60:	5f                   	pop    di
     b61:	44                   	inc    sp
     b62:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     b66:	69 6f 6e 73 22       	imul   bp,WORD PTR [bx+0x6e],0x2273
     b6b:	00 95 0b 7b          	add    BYTE PTR [di+0x7b0b],dl
     b6f:	06                   	push   es
     b70:	bf 0b 38             	mov    di,0x380b
     b73:	00 04                	add    BYTE PTR [si],al
     b75:	53                   	push   bx
     b76:	65 64 64 00 00       	gs fs add BYTE PTR fs:[bx+si],al
     b7b:	55                   	push   bp
     b7c:	89 e5                	mov    bp,sp
     b7e:	31 c0                	xor    ax,ax
     b80:	9a 44 04 d2 0b       	call   0xbd2:0x444
     b85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b88:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
     b8e:	75 09                	jne    0xb99
     b90:	06                   	push   es
     b91:	57                   	push   di
     b92:	9a ca 0b e8 0b       	call   0xbe8:0xbca
     b97:	eb 2d                	jmp    0xbc6
     b99:	c6 06 66 02 01       	mov    BYTE PTR ds:0x266,0x1
     b9e:	6a 01                	push   0x1
     ba0:	9a c2 38 d9 0b       	call   0xbd9:0x38c2
     ba5:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     ba9:	06                   	push   es
     baa:	57                   	push   di
     bab:	9a c7 28 4b 62       	call   0x624b:0x28c7
     bb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bb3:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     bba:	06                   	push   es
     bbb:	57                   	push   di
     bbc:	9a 56 55 0e 0c       	call   0xc0e:0x5556
     bc1:	9a c3 28 de 0b       	call   0xbde:0x28c3
     bc6:	c9                   	leave
     bc7:	ca 04 00             	retf   0x4
     bca:	55                   	push   bp
     bcb:	89 e5                	mov    bp,sp
     bcd:	31 c0                	xor    ax,ax
     bcf:	9a 44 04 f3 0b       	call   0xbf3:0x444
     bd4:	6a 00                	push   0x0
     bd6:	9a c2 38 67 11       	call   0x1167:0x38c2
     bdb:	9a c3 28 0c 14       	call   0x140c:0x28c3
     be0:	c9                   	leave
     be1:	ca 04 00             	retf   0x4
     be4:	00 00                	add    BYTE PTR [bx+si],al
     be6:	8c 0c                	mov    WORD PTR [si],cs
     be8:	07                   	pop    es
     be9:	0c 55                	or     al,0x55
     beb:	89 e5                	mov    bp,sp
     bed:	b8 08 00             	mov    ax,0x8
     bf0:	9a 44 04 aa 0c       	call   0xcaa:0x444
     bf5:	83 ec 08             	sub    sp,0x8
     bf8:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     bfc:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     c00:	b0 01                	mov    al,0x1
     c02:	50                   	push   ax
     c03:	b8 22 00             	mov    ax,0x22
     c06:	ba 34 0c             	mov    dx,0xc34
     c09:	52                   	push   dx
     c0a:	50                   	push   ax
     c0b:	9a 53 25 7e 0c       	call   0xc7e:0x2553
     c10:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c13:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     c16:	b8 e4 0b             	mov    ax,0xbe4
     c19:	0e                   	push   cs
     c1a:	50                   	push   ax
     c1b:	55                   	push   bp
     c1c:	ff 36 58 18          	push   WORD PTR ds:0x1858
     c20:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     c24:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     c27:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     c2a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     c2d:	6a 01                	push   0x1
     c2f:	06                   	push   es
     c30:	57                   	push   di
     c31:	9a af 11 3e 0c       	call   0xc3e:0x11af
     c36:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     c39:	06                   	push   es
     c3a:	57                   	push   di
     c3b:	9a d4 31 53 0c       	call   0xc53:0x31d4
     c40:	a1 4c 01             	mov    ax,ds:0x14c
     c43:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     c46:	26 89 85 0c 04       	mov    WORD PTR es:[di+0x40c],ax
     c4b:	ff 76 06             	push   WORD PTR [bp+0x6]
     c4e:	06                   	push   es
     c4f:	57                   	push   di
     c50:	9a 52 13 65 0c       	call   0xc65:0x1352
     c55:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     c59:	75 0e                	jne    0xc69
     c5b:	6a 01                	push   0x1
     c5d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     c60:	06                   	push   es
     c61:	57                   	push   di
     c62:	9a be 13 74 0c       	call   0xc74:0x13be
     c67:	eb 0d                	jmp    0xc76
     c69:	ff 76 06             	push   WORD PTR [bp+0x6]
     c6c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     c6f:	06                   	push   es
     c70:	57                   	push   di
     c71:	9a be 13 9f 0c       	call   0xc9f:0x13be
     c76:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     c79:	06                   	push   es
     c7a:	57                   	push   di
     c7b:	9a 45 5d 94 0c       	call   0xc94:0x5d45
     c80:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     c84:	83 c4 06             	add    sp,0x6
     c87:	b8 97 0c             	mov    ax,0xc97
     c8a:	0e                   	push   cs
     c8b:	50                   	push   ax
     c8c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     c8f:	06                   	push   es
     c90:	57                   	push   di
     c91:	9a 1d 5f c5 0c       	call   0xcc5:0x5f1d
     c96:	cb                   	retf
     c97:	c9                   	leave
     c98:	ca 02 00             	retf   0x2
     c9b:	00 00                	add    BYTE PTR [bx+si],al
     c9d:	a3 0d be             	mov    ds:0xbe0d,ax
     ca0:	0c 55                	or     al,0x55
     ca2:	89 e5                	mov    bp,sp
     ca4:	b8 08 00             	mov    ax,0x8
     ca7:	9a 44 04 80 0d       	call   0xd80:0x444
     cac:	83 ec 08             	sub    sp,0x8
     caf:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     cb3:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     cb7:	b0 01                	mov    al,0x1
     cb9:	50                   	push   ax
     cba:	b8 22 00             	mov    ax,0x22
     cbd:	ba eb 0c             	mov    dx,0xceb
     cc0:	52                   	push   dx
     cc1:	50                   	push   ax
     cc2:	9a 53 25 95 0d       	call   0xd95:0x2553
     cc7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cca:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     ccd:	b8 9b 0c             	mov    ax,0xc9b
     cd0:	0e                   	push   cs
     cd1:	50                   	push   ax
     cd2:	55                   	push   bp
     cd3:	ff 36 58 18          	push   WORD PTR ds:0x1858
     cd7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     cdb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     cde:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     ce1:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     ce4:	6a 00                	push   0x0
     ce6:	06                   	push   es
     ce7:	57                   	push   di
     ce8:	9a af 11 f5 0c       	call   0xcf5:0x11af
     ced:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     cf0:	06                   	push   es
     cf1:	57                   	push   di
     cf2:	9a d4 31 1b 0d       	call   0xd1b:0x31d4
     cf7:	6a 01                	push   0x1
     cf9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     cfc:	26 c4 bd f4 03       	les    di,DWORD PTR es:[di+0x3f4]
     d01:	06                   	push   es
     d02:	57                   	push   di
     d03:	9a 77 1c ec 0d       	call   0xdec:0x1c77
     d08:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     d0b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d0e:	26 89 85 0c 04       	mov    WORD PTR es:[di+0x40c],ax
     d13:	ff 76 0a             	push   WORD PTR [bp+0xa]
     d16:	06                   	push   es
     d17:	57                   	push   di
     d18:	9a 52 13 41 0d       	call   0xd41:0x1352
     d1d:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     d21:	b0 00                	mov    al,0x0
     d23:	75 01                	jne    0xd26
     d25:	40                   	inc    ax
     d26:	8a d0                	mov    dl,al
     d28:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
     d2c:	b0 00                	mov    al,0x0
     d2e:	75 01                	jne    0xd31
     d30:	40                   	inc    ax
     d31:	22 c2                	and    al,dl
     d33:	08 c0                	or     al,al
     d35:	74 0e                	je     0xd45
     d37:	6a 01                	push   0x1
     d39:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d3c:	06                   	push   es
     d3d:	57                   	push   di
     d3e:	9a be 13 50 0d       	call   0xd50:0x13be
     d43:	eb 0d                	jmp    0xd52
     d45:	ff 76 06             	push   WORD PTR [bp+0x6]
     d48:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d4b:	06                   	push   es
     d4c:	57                   	push   di
     d4d:	9a be 13 8b 0d       	call   0xd8b:0x13be
     d52:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d55:	26 80 bd 10 04 00    	cmp    BYTE PTR es:[di+0x410],0x0
     d5b:	b0 00                	mov    al,0x0
     d5d:	75 01                	jne    0xd60
     d5f:	40                   	inc    ax
     d60:	8a d0                	mov    dl,al
     d62:	26 83 bd 0c 04 01    	cmp    WORD PTR es:[di+0x40c],0x1
     d68:	b0 00                	mov    al,0x0
     d6a:	7e 01                	jle    0xd6d
     d6c:	40                   	inc    ax
     d6d:	22 c2                	and    al,dl
     d6f:	08 c0                	or     al,al
     d71:	74 1a                	je     0xd8d
     d73:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
     d78:	2d 01 00             	sub    ax,0x1
     d7b:	71 05                	jno    0xd82
     d7d:	9a 3e 04 cb 0d       	call   0xdcb:0x43e
     d82:	50                   	push   ax
     d83:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d86:	06                   	push   es
     d87:	57                   	push   di
     d88:	9a 9e 13 d7 10       	call   0x10d7:0x139e
     d8d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d90:	06                   	push   es
     d91:	57                   	push   di
     d92:	9a 45 5d ab 0d       	call   0xdab:0x5d45
     d97:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     d9b:	83 c4 06             	add    sp,0x6
     d9e:	b8 ae 0d             	mov    ax,0xdae
     da1:	0e                   	push   cs
     da2:	50                   	push   ax
     da3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     da6:	06                   	push   es
     da7:	57                   	push   di
     da8:	9a 1d 5f 8e 10       	call   0x108e:0x5f1d
     dad:	cb                   	retf
     dae:	c9                   	leave
     daf:	ca 06 00             	retf   0x6
     db2:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
     db5:	6d                   	ins    WORD PTR es:[di],dx
     db6:	73 74                	jae    0xe2c
     db8:	72 61                	jb     0xe1b
     dba:	74 20                	je     0xddc
     dbc:	2d 20 03             	sub    ax,0x320
     dbf:	20 2d                	and    BYTE PTR [di],ch
     dc1:	20 55 89             	and    BYTE PTR [di-0x77],dl
     dc4:	e5 b8                	in     ax,0xb8
     dc6:	02 02                	add    al,BYTE PTR [bp+si]
     dc8:	9a 44 04 fc 0d       	call   0xdfc:0x444
     dcd:	81 ec 02 02          	sub    sp,0x202
     dd1:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     dd5:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
     dda:	26 8a 45 31          	mov    al,BYTE PTR es:[di+0x31]
     dde:	50                   	push   ax
     ddf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     de2:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
     de7:	06                   	push   es
     de8:	57                   	push   di
     de9:	9a 77 1c 20 0e       	call   0xe20:0x1c77
     dee:	8d be fe fe          	lea    di,[bp-0x102]
     df2:	16                   	push   ss
     df3:	57                   	push   di
     df4:	bf b2 0d             	mov    di,0xdb2
     df7:	0e                   	push   cs
     df8:	57                   	push   di
     df9:	9a cd 17 06 0e       	call   0xe06:0x17cd
     dfe:	bf fa 1d             	mov    di,0x1dfa
     e01:	1e                   	push   ds
     e02:	57                   	push   di
     e03:	9a 4c 18 10 0e       	call   0xe10:0x184c
     e08:	bf be 0d             	mov    di,0xdbe
     e0b:	0e                   	push   cs
     e0c:	57                   	push   di
     e0d:	9a 4c 18 25 0e       	call   0xe25:0x184c
     e12:	8d be fe fd          	lea    di,[bp-0x202]
     e16:	16                   	push   ss
     e17:	57                   	push   di
     e18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e1b:	06                   	push   es
     e1c:	57                   	push   di
     e1d:	9a 53 1d 2f 0e       	call   0xe2f:0x1d53
     e22:	9a 4c 18 d1 0e       	call   0xed1:0x184c
     e27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e2a:	06                   	push   es
     e2b:	57                   	push   di
     e2c:	9a 8c 1d 96 0e       	call   0xe96:0x1d8c
     e31:	6a 00                	push   0x0
     e33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e36:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     e3b:	06                   	push   es
     e3c:	57                   	push   di
     e3d:	9a 6f 24 19 18       	call   0x1819:0x246f
     e42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e45:	26 c6 85 04 04 00    	mov    BYTE PTR es:[di+0x404],0x0
     e4b:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
     e50:	89 7e fa             	mov    WORD PTR [bp-0x6],di
     e53:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
     e56:	26 c7 85 ec 00 01 00 	mov    WORD PTR es:[di+0xec],0x1
     e5d:	26 c7 85 ee 00 00 00 	mov    WORD PTR es:[di+0xee],0x0
     e64:	a1 4c 01             	mov    ax,ds:0x14c
     e67:	99                   	cwd
     e68:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
     e6d:	26 89 95 f2 00       	mov    WORD PTR es:[di+0xf2],dx
     e72:	26 8b 85 f0 00       	mov    ax,WORD PTR es:[di+0xf0]
     e77:	26 8b 95 f2 00       	mov    dx,WORD PTR es:[di+0xf2]
     e7c:	26 3b 95 ee 00       	cmp    dx,WORD PTR es:[di+0xee]
     e81:	7c 09                	jl     0xe8c
     e83:	7f 13                	jg     0xe98
     e85:	26 3b 85 ec 00       	cmp    ax,WORD PTR es:[di+0xec]
     e8a:	77 0c                	ja     0xe98
     e8c:	6a 00                	push   0x0
     e8e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     e91:	06                   	push   es
     e92:	57                   	push   di
     e93:	9a b8 1c bd 0e       	call   0xebd:0x1cb8
     e98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e9b:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
     ea0:	a1 4e 01             	mov    ax,ds:0x14e
     ea3:	99                   	cwd
     ea4:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
     ea9:	26 89 95 f2 00       	mov    WORD PTR es:[di+0xf2],dx
     eae:	6a 00                	push   0x0
     eb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eb3:	26 c4 bd f4 03       	les    di,DWORD PTR es:[di+0x3f4]
     eb8:	06                   	push   es
     eb9:	57                   	push   di
     eba:	9a 77 1c fb 0e       	call   0xefb:0x1c77
     ebf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ec2:	06                   	push   es
     ec3:	57                   	push   di
     ec4:	9a 7d 52 f3 0e       	call   0xef3:0x527d
     ec9:	2d 01 00             	sub    ax,0x1
     ecc:	71 05                	jno    0xed3
     ece:	9a 3e 04 02 0f       	call   0xf02:0x43e
     ed3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ed6:	31 c0                	xor    ax,ax
     ed8:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     edb:	7e 03                	jle    0xee0
     edd:	e9 a0 00             	jmp    0xf80
     ee0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     ee3:	eb 03                	jmp    0xee8
     ee5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     ee8:	ff 76 fe             	push   WORD PTR [bp-0x2]
     eeb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eee:	06                   	push   es
     eef:	57                   	push   di
     ef0:	9a 46 52 13 0f       	call   0xf13:0x5246
     ef5:	52                   	push   dx
     ef6:	50                   	push   ax
     ef7:	bf 99 03             	mov    di,0x399
     efa:	b8 1b 0f             	mov    ax,0xf1b
     efd:	50                   	push   ax
     efe:	57                   	push   di
     eff:	9a 55 22 22 0f       	call   0xf22:0x2255
     f04:	08 c0                	or     al,al
     f06:	74 6d                	je     0xf75
     f08:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f0e:	06                   	push   es
     f0f:	57                   	push   di
     f10:	9a 46 52 02 21       	call   0x2102:0x5246
     f15:	52                   	push   dx
     f16:	50                   	push   ax
     f17:	bf 99 03             	mov    di,0x399
     f1a:	b8 73 0f             	mov    ax,0xf73
     f1d:	50                   	push   ax
     f1e:	57                   	push   di
     f1f:	9a 73 22 58 0f       	call   0xf58:0x2273
     f24:	89 c7                	mov    di,ax
     f26:	8e c2                	mov    es,dx
     f28:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     f2b:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     f2e:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     f32:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
     f36:	74 3d                	je     0xf75
     f38:	a1 06 1e             	mov    ax,ds:0x1e06
     f3b:	99                   	cwd
     f3c:	8b c8                	mov    cx,ax
     f3e:	8b da                	mov    bx,dx
     f40:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     f44:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
     f48:	09 d2                	or     dx,dx
     f4a:	79 07                	jns    0xf53
     f4c:	f7 d2                	not    dx
     f4e:	f7 d8                	neg    ax
     f50:	83 da ff             	sbb    dx,0xffff
     f53:	71 05                	jno    0xf5a
     f55:	9a 3e 04 81 10       	call   0x1081:0x43e
     f5a:	3b d3                	cmp    dx,bx
     f5c:	7c 0a                	jl     0xf68
     f5e:	7f 04                	jg     0xf64
     f60:	3b c1                	cmp    ax,cx
     f62:	76 04                	jbe    0xf68
     f64:	b0 00                	mov    al,0x0
     f66:	eb 02                	jmp    0xf6a
     f68:	b0 01                	mov    al,0x1
     f6a:	50                   	push   ax
     f6b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     f6e:	06                   	push   es
     f6f:	57                   	push   di
     f70:	9a 77 1c e7 11       	call   0x11e7:0x1c77
     f75:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f78:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     f7b:	74 03                	je     0xf80
     f7d:	e9 65 ff             	jmp    0xee5
     f80:	bf 4e 1e             	mov    di,0x1e4e
     f83:	1e                   	push   ds
     f84:	57                   	push   di
     f85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f88:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     f8d:	06                   	push   es
     f8e:	57                   	push   di
     f8f:	9a 17 30 a6 0f       	call   0xfa6:0x3017
     f94:	bf 5c 1e             	mov    di,0x1e5c
     f97:	1e                   	push   ds
     f98:	57                   	push   di
     f99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f9c:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
     fa1:	06                   	push   es
     fa2:	57                   	push   di
     fa3:	9a 17 30 ba 0f       	call   0xfba:0x3017
     fa8:	bf 5c 1e             	mov    di,0x1e5c
     fab:	1e                   	push   ds
     fac:	57                   	push   di
     fad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fb0:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
     fb5:	06                   	push   es
     fb6:	57                   	push   di
     fb7:	9a 17 30 ce 0f       	call   0xfce:0x3017
     fbc:	bf 6a 1e             	mov    di,0x1e6a
     fbf:	1e                   	push   ds
     fc0:	57                   	push   di
     fc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fc4:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
     fc9:	06                   	push   es
     fca:	57                   	push   di
     fcb:	9a 17 30 e2 0f       	call   0xfe2:0x3017
     fd0:	bf 4e 1e             	mov    di,0x1e4e
     fd3:	1e                   	push   ds
     fd4:	57                   	push   di
     fd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fd8:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
     fdd:	06                   	push   es
     fde:	57                   	push   di
     fdf:	9a 17 30 f6 0f       	call   0xff6:0x3017
     fe4:	bf 5c 1e             	mov    di,0x1e5c
     fe7:	1e                   	push   ds
     fe8:	57                   	push   di
     fe9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fec:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
     ff1:	06                   	push   es
     ff2:	57                   	push   di
     ff3:	9a 17 30 0a 10       	call   0x100a:0x3017
     ff8:	bf 6a 1e             	mov    di,0x1e6a
     ffb:	1e                   	push   ds
     ffc:	57                   	push   di
     ffd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1000:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    1005:	06                   	push   es
    1006:	57                   	push   di
    1007:	9a 17 30 1e 10       	call   0x101e:0x3017
    100c:	bf 78 1e             	mov    di,0x1e78
    100f:	1e                   	push   ds
    1010:	57                   	push   di
    1011:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1014:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    1019:	06                   	push   es
    101a:	57                   	push   di
    101b:	9a 17 30 32 10       	call   0x1032:0x3017
    1020:	bf 86 1e             	mov    di,0x1e86
    1023:	1e                   	push   ds
    1024:	57                   	push   di
    1025:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1028:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    102d:	06                   	push   es
    102e:	57                   	push   di
    102f:	9a 17 30 46 10       	call   0x1046:0x3017
    1034:	bf 16 1e             	mov    di,0x1e16
    1037:	1e                   	push   ds
    1038:	57                   	push   di
    1039:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    103c:	26 c4 bd 18 02       	les    di,DWORD PTR es:[di+0x218]
    1041:	06                   	push   es
    1042:	57                   	push   di
    1043:	9a 17 30 5a 10       	call   0x105a:0x3017
    1048:	bf 32 1e             	mov    di,0x1e32
    104b:	1e                   	push   ds
    104c:	57                   	push   di
    104d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1050:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    1055:	06                   	push   es
    1056:	57                   	push   di
    1057:	9a 17 30 6e 10       	call   0x106e:0x3017
    105c:	bf 40 1e             	mov    di,0x1e40
    105f:	1e                   	push   ds
    1060:	57                   	push   di
    1061:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1064:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    1069:	06                   	push   es
    106a:	57                   	push   di
    106b:	9a 17 30 58 1a       	call   0x1a58:0x3017
    1070:	c6 06 66 02 00       	mov    BYTE PTR ds:0x266,0x0
    1075:	c9                   	leave
    1076:	ca 08 00             	retf   0x8
    1079:	55                   	push   bp
    107a:	89 e5                	mov    bp,sp
    107c:	31 c0                	xor    ax,ax
    107e:	9a 44 04 9d 10       	call   0x109d:0x444
    1083:	6a fe                	push   0xfffe
    1085:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    1089:	06                   	push   es
    108a:	57                   	push   di
    108b:	9a a9 63 b7 10       	call   0x10b7:0x63a9
    1090:	c9                   	leave
    1091:	ca 08 00             	retf   0x8
    1094:	55                   	push   bp
    1095:	89 e5                	mov    bp,sp
    1097:	b8 04 00             	mov    ax,0x4
    109a:	9a 44 04 de 10       	call   0x10de:0x444
    109f:	83 ec 04             	sub    sp,0x4
    10a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10a5:	26 80 bd 04 04 00    	cmp    BYTE PTR es:[di+0x404],0x0
    10ab:	74 1b                	je     0x10c8
    10ad:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    10b2:	06                   	push   es
    10b3:	57                   	push   di
    10b4:	9a 56 55 c6 10       	call   0x10c6:0x5556
    10b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10bc:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    10c1:	06                   	push   es
    10c2:	57                   	push   di
    10c3:	9a 1d 5f f6 13       	call   0x13f6:0x5f1d
    10c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10cb:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    10cf:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    10d3:	bf 22 00             	mov    di,0x22
    10d6:	b8 f3 10             	mov    ax,0x10f3
    10d9:	50                   	push   ax
    10da:	57                   	push   di
    10db:	9a 55 22 fa 10       	call   0x10fa:0x2255
    10e0:	08 c0                	or     al,al
    10e2:	74 22                	je     0x1106
    10e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10e7:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    10eb:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    10ef:	bf 22 00             	mov    di,0x22
    10f2:	b8 0e 11             	mov    ax,0x110e
    10f5:	50                   	push   ax
    10f6:	57                   	push   di
    10f7:	9a 73 22 23 11       	call   0x1123:0x2273
    10fc:	89 c7                	mov    di,ax
    10fe:	8e c2                	mov    es,dx
    1100:	26 c6 85 04 04 00    	mov    BYTE PTR es:[di+0x404],0x0
    1106:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1109:	06                   	push   es
    110a:	57                   	push   di
    110b:	9a 06 31 47 11       	call   0x1147:0x3106
    1110:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1113:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    1117:	c9                   	leave
    1118:	ca 0c 00             	retf   0xc
    111b:	55                   	push   bp
    111c:	89 e5                	mov    bp,sp
    111e:	31 c0                	xor    ax,ax
    1120:	9a 44 04 b8 11       	call   0x11b8:0x444
    1125:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1128:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    112c:	80 3e 66 02 00       	cmp    BYTE PTR ds:0x266,0x0
    1131:	b0 00                	mov    al,0x0
    1133:	75 01                	jne    0x1136
    1135:	40                   	inc    ax
    1136:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1139:	26 22 85 09 04       	and    al,BYTE PTR es:[di+0x409]
    113e:	08 c0                	or     al,al
    1140:	74 65                	je     0x11a7
    1142:	06                   	push   es
    1143:	57                   	push   di
    1144:	9a 26 37 76 11       	call   0x1176:0x3726
    1149:	8a d0                	mov    dl,al
    114b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    114e:	26 80 bd 10 04 00    	cmp    BYTE PTR es:[di+0x410],0x0
    1154:	b0 00                	mov    al,0x0
    1156:	75 01                	jne    0x1159
    1158:	40                   	inc    ax
    1159:	0a c2                	or     al,dl
    115b:	08 c0                	or     al,al
    115d:	74 38                	je     0x1197
    115f:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    1164:	9a f6 3d 91 15       	call   0x1591:0x3df6
    1169:	3d 06 00             	cmp    ax,0x6
    116c:	75 12                	jne    0x1180
    116e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1171:	06                   	push   es
    1172:	57                   	push   di
    1173:	9a 25 3a 9f 11       	call   0x119f:0x3a25
    1178:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    117b:	26 88 05             	mov    BYTE PTR es:[di],al
    117e:	eb 15                	jmp    0x1195
    1180:	3d 07 00             	cmp    ax,0x7
    1183:	75 02                	jne    0x1187
    1185:	eb 0e                	jmp    0x1195
    1187:	3d 02 00             	cmp    ax,0x2
    118a:	75 09                	jne    0x1195
    118c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    118f:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1193:	eb 00                	jmp    0x1195
    1195:	eb 10                	jmp    0x11a7
    1197:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    119a:	06                   	push   es
    119b:	57                   	push   di
    119c:	9a 0b 62 6e 12       	call   0x126e:0x620b
    11a1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    11a4:	26 88 05             	mov    BYTE PTR es:[di],al
    11a7:	c9                   	leave
    11a8:	ca 0c 00             	retf   0xc
    11ab:	03 20                	add    sp,WORD PTR [bx+si]
    11ad:	2d 20 55             	sub    ax,0x5520
    11b0:	89 e5                	mov    bp,sp
    11b2:	b8 00 02             	mov    ax,0x200
    11b5:	9a 44 04 f5 11       	call   0x11f5:0x444
    11ba:	81 ec 00 02          	sub    sp,0x200
    11be:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    11c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11c4:	26 88 85 09 04       	mov    BYTE PTR es:[di+0x409],al
    11c9:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    11cf:	74 03                	je     0x11d4
    11d1:	e9 8b 00             	jmp    0x125f
    11d4:	8d be 00 fe          	lea    di,[bp-0x200]
    11d8:	16                   	push   ss
    11d9:	57                   	push   di
    11da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11dd:	26 c4 bd fc 03       	les    di,DWORD PTR es:[di+0x3fc]
    11e2:	06                   	push   es
    11e3:	57                   	push   di
    11e4:	9a 53 1d 0a 12       	call   0x120a:0x1d53
    11e9:	8d be 00 ff          	lea    di,[bp-0x100]
    11ed:	16                   	push   ss
    11ee:	57                   	push   di
    11ef:	68 ff 00             	push   0xff
    11f2:	9a e7 17 48 12       	call   0x1248:0x17e7
    11f7:	8d be 00 fe          	lea    di,[bp-0x200]
    11fb:	16                   	push   ss
    11fc:	57                   	push   di
    11fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1200:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    1205:	06                   	push   es
    1206:	57                   	push   di
    1207:	9a 53 1d 19 12       	call   0x1219:0x1d53
    120c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    120f:	26 c4 bd fc 03       	les    di,DWORD PTR es:[di+0x3fc]
    1214:	06                   	push   es
    1215:	57                   	push   di
    1216:	9a 8c 1d 2e 12       	call   0x122e:0x1d8c
    121b:	8d be 00 ff          	lea    di,[bp-0x100]
    121f:	16                   	push   ss
    1220:	57                   	push   di
    1221:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1224:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    1229:	06                   	push   es
    122a:	57                   	push   di
    122b:	9a 8c 1d 3e 12       	call   0x123e:0x1d8c
    1230:	8d be 00 fe          	lea    di,[bp-0x200]
    1234:	16                   	push   ss
    1235:	57                   	push   di
    1236:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1239:	06                   	push   es
    123a:	57                   	push   di
    123b:	9a 53 1d 5d 12       	call   0x125d:0x1d53
    1240:	bf ab 11             	mov    di,0x11ab
    1243:	0e                   	push   cs
    1244:	57                   	push   di
    1245:	9a 4c 18 53 12       	call   0x1253:0x184c
    124a:	8d be 00 ff          	lea    di,[bp-0x100]
    124e:	16                   	push   ss
    124f:	57                   	push   di
    1250:	9a 4c 18 75 12       	call   0x1275:0x184c
    1255:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1258:	06                   	push   es
    1259:	57                   	push   di
    125a:	9a 8c 1d 8a 12       	call   0x128a:0x1d8c
    125f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1262:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1266:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    126a:	bf 22 00             	mov    di,0x22
    126d:	b8 26 13             	mov    ax,0x1326
    1270:	50                   	push   ax
    1271:	57                   	push   di
    1272:	9a 55 22 35 13       	call   0x1335:0x2255
    1277:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    127a:	26 0a 85 09 04       	or     al,BYTE PTR es:[di+0x409]
    127f:	50                   	push   ax
    1280:	26 c4 bd fc 03       	les    di,DWORD PTR es:[di+0x3fc]
    1285:	06                   	push   es
    1286:	57                   	push   di
    1287:	9a 77 1c 9f 12       	call   0x129f:0x1c77
    128c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    128f:	26 8a 85 09 04       	mov    al,BYTE PTR es:[di+0x409]
    1294:	50                   	push   ax
    1295:	26 c4 bd c8 03       	les    di,DWORD PTR es:[di+0x3c8]
    129a:	06                   	push   es
    129b:	57                   	push   di
    129c:	9a 77 1c b0 12       	call   0x12b0:0x1c77
    12a1:	6a 00                	push   0x0
    12a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12a6:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    12ab:	06                   	push   es
    12ac:	57                   	push   di
    12ad:	9a 77 1c c5 12       	call   0x12c5:0x1c77
    12b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12b5:	26 8a 85 09 04       	mov    al,BYTE PTR es:[di+0x409]
    12ba:	50                   	push   ax
    12bb:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    12c0:	06                   	push   es
    12c1:	57                   	push   di
    12c2:	9a 77 1c e0 12       	call   0x12e0:0x1c77
    12c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12ca:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    12d0:	b0 00                	mov    al,0x0
    12d2:	75 01                	jne    0x12d5
    12d4:	40                   	inc    ax
    12d5:	50                   	push   ax
    12d6:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    12db:	06                   	push   es
    12dc:	57                   	push   di
    12dd:	9a 77 1c f5 12       	call   0x12f5:0x1c77
    12e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12e5:	26 8a 85 09 04       	mov    al,BYTE PTR es:[di+0x409]
    12ea:	50                   	push   ax
    12eb:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    12f0:	06                   	push   es
    12f1:	57                   	push   di
    12f2:	9a 77 1c 10 13       	call   0x1310:0x1c77
    12f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12fa:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    1300:	b0 00                	mov    al,0x0
    1302:	75 01                	jne    0x1305
    1304:	40                   	inc    ax
    1305:	50                   	push   ax
    1306:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    130b:	06                   	push   es
    130c:	57                   	push   di
    130d:	9a 77 1c 7d 13       	call   0x137d:0x1c77
    1312:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1315:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    131b:	b0 00                	mov    al,0x0
    131d:	75 01                	jne    0x1320
    131f:	40                   	inc    ax
    1320:	50                   	push   ax
    1321:	06                   	push   es
    1322:	57                   	push   di
    1323:	9a 8e 2e b8 13       	call   0x13b8:0x2e8e
    1328:	c9                   	leave
    1329:	ca 06 00             	retf   0x6
    132c:	55                   	push   bp
    132d:	89 e5                	mov    bp,sp
    132f:	b8 02 00             	mov    ax,0x2
    1332:	9a 44 04 5a 13       	call   0x135a:0x444
    1337:	83 ec 02             	sub    sp,0x2
    133a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    133d:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    1343:	b0 00                	mov    al,0x0
    1345:	75 01                	jne    0x1348
    1347:	40                   	inc    ax
    1348:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    134b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    134e:	c9                   	leave
    134f:	ca 04 00             	retf   0x4
    1352:	55                   	push   bp
    1353:	89 e5                	mov    bp,sp
    1355:	31 c0                	xor    ax,ax
    1357:	9a 44 04 a6 13       	call   0x13a6:0x444
    135c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    135f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1362:	26 89 85 0a 04       	mov    WORD PTR es:[di+0x40a],ax
    1367:	26 83 bd 0a 04 00    	cmp    WORD PTR es:[di+0x40a],0x0
    136d:	b0 00                	mov    al,0x0
    136f:	75 01                	jne    0x1372
    1371:	40                   	inc    ax
    1372:	50                   	push   ax
    1373:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    1378:	06                   	push   es
    1379:	57                   	push   di
    137a:	9a 77 1c 98 13       	call   0x1398:0x1c77
    137f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1382:	26 83 bd 0a 04 00    	cmp    WORD PTR es:[di+0x40a],0x0
    1388:	b0 00                	mov    al,0x0
    138a:	74 01                	je     0x138d
    138c:	40                   	inc    ax
    138d:	50                   	push   ax
    138e:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    1393:	06                   	push   es
    1394:	57                   	push   di
    1395:	9a 77 1c 1b 14       	call   0x141b:0x1c77
    139a:	c9                   	leave
    139b:	ca 06 00             	retf   0x6
    139e:	55                   	push   bp
    139f:	89 e5                	mov    bp,sp
    13a1:	31 c0                	xor    ax,ax
    13a3:	9a 44 04 c6 13       	call   0x13c6:0x444
    13a8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    13ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ae:	26 89 85 0c 04       	mov    WORD PTR es:[di+0x40c],ax
    13b3:	06                   	push   es
    13b4:	57                   	push   di
    13b5:	9a de 13 d8 13       	call   0x13d8:0x13de
    13ba:	c9                   	leave
    13bb:	ca 06 00             	retf   0x6
    13be:	55                   	push   bp
    13bf:	89 e5                	mov    bp,sp
    13c1:	31 c0                	xor    ax,ax
    13c3:	9a 44 04 e7 13       	call   0x13e7:0x444
    13c8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    13cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ce:	26 89 85 0e 04       	mov    WORD PTR es:[di+0x40e],ax
    13d3:	06                   	push   es
    13d4:	57                   	push   di
    13d5:	9a de 13 78 14       	call   0x1478:0x13de
    13da:	c9                   	leave
    13db:	ca 06 00             	retf   0x6
    13de:	55                   	push   bp
    13df:	89 e5                	mov    bp,sp
    13e1:	b8 00 01             	mov    ax,0x100
    13e4:	9a 44 04 9d 14       	call   0x149d:0x444
    13e9:	81 ec 00 01          	sub    sp,0x100
    13ed:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    13f1:	06                   	push   es
    13f2:	57                   	push   di
    13f3:	9a 03 73 64 16       	call   0x1664:0x7303
    13f8:	8d be 00 ff          	lea    di,[bp-0x100]
    13fc:	16                   	push   ss
    13fd:	57                   	push   di
    13fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1401:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    1406:	99                   	cwd
    1407:	52                   	push   dx
    1408:	50                   	push   ax
    1409:	9a a9 08 48 14       	call   0x1448:0x8a9
    140e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1411:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    1416:	06                   	push   es
    1417:	57                   	push   di
    1418:	9a 8c 1d 57 14       	call   0x1457:0x1d8c
    141d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1420:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    1425:	99                   	cwd
    1426:	52                   	push   dx
    1427:	50                   	push   ax
    1428:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    142d:	06                   	push   es
    142e:	57                   	push   di
    142f:	9a 8b 17 6e 14       	call   0x146e:0x178b
    1434:	8d be 00 ff          	lea    di,[bp-0x100]
    1438:	16                   	push   ss
    1439:	57                   	push   di
    143a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    143d:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    1442:	99                   	cwd
    1443:	52                   	push   dx
    1444:	50                   	push   ax
    1445:	9a a9 08 c1 1a       	call   0x1ac1:0x8a9
    144a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    144d:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    1452:	06                   	push   es
    1453:	57                   	push   di
    1454:	9a 8c 1d 14 17       	call   0x1714:0x1d8c
    1459:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    145c:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    1461:	99                   	cwd
    1462:	52                   	push   dx
    1463:	50                   	push   ax
    1464:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    1469:	06                   	push   es
    146a:	57                   	push   di
    146b:	9a 8b 17 ac 14       	call   0x14ac:0x178b
    1470:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1473:	06                   	push   es
    1474:	57                   	push   di
    1475:	9a f1 33 86 14       	call   0x1486:0x33f1
    147a:	6a ff                	push   0xffff
    147c:	6a fa                	push   0xfffa
    147e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1481:	06                   	push   es
    1482:	57                   	push   di
    1483:	9a af 2b e8 14       	call   0x14e8:0x2baf
    1488:	c9                   	leave
    1489:	ca 04 00             	retf   0x4
    148c:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1490:	ff                   	(bad)
    1491:	7f 00                	jg     0x1493
    1493:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1496:	e5 b8                	in     ax,0xb8
    1498:	04 00                	add    al,0x0
    149a:	9a 44 04 b3 14       	call   0x14b3:0x444
    149f:	83 ec 04             	sub    sp,0x4
    14a2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    14a5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    14a8:	bf eb 03             	mov    di,0x3eb
    14ab:	b8 c3 14             	mov    ax,0x14c3
    14ae:	50                   	push   ax
    14af:	57                   	push   di
    14b0:	9a 55 22 ca 14       	call   0x14ca:0x2255
    14b5:	08 c0                	or     al,al
    14b7:	74 31                	je     0x14ea
    14b9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    14bc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    14bf:	bf eb 03             	mov    di,0x3eb
    14c2:	b8 d5 14             	mov    ax,0x14d5
    14c5:	50                   	push   ax
    14c6:	57                   	push   di
    14c7:	9a 73 22 dd 14       	call   0x14dd:0x2273
    14cc:	89 c7                	mov    di,ax
    14ce:	8e c2                	mov    es,dx
    14d0:	06                   	push   es
    14d1:	57                   	push   di
    14d2:	9a 33 17 0e 15       	call   0x150e:0x1733
    14d7:	bf 8c 14             	mov    di,0x148c
    14da:	9a 16 04 ff 14       	call   0x14ff:0x416
    14df:	50                   	push   ax
    14e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14e3:	06                   	push   es
    14e4:	57                   	push   di
    14e5:	9a 9e 13 71 15       	call   0x1571:0x139e
    14ea:	c9                   	leave
    14eb:	ca 08 00             	retf   0x8
    14ee:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    14f2:	ff                   	(bad)
    14f3:	7f 00                	jg     0x14f5
    14f5:	00 55 89             	add    BYTE PTR [di-0x77],dl
    14f8:	e5 b8                	in     ax,0xb8
    14fa:	04 00                	add    al,0x0
    14fc:	9a 44 04 15 15       	call   0x1515:0x444
    1501:	83 ec 04             	sub    sp,0x4
    1504:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1507:	ff 76 0a             	push   WORD PTR [bp+0xa]
    150a:	bf eb 03             	mov    di,0x3eb
    150d:	b8 28 15             	mov    ax,0x1528
    1510:	50                   	push   ax
    1511:	57                   	push   di
    1512:	9a 55 22 2f 15       	call   0x152f:0x2255
    1517:	08 c0                	or     al,al
    1519:	75 03                	jne    0x151e
    151b:	e9 14 01             	jmp    0x1632
    151e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1521:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1524:	bf eb 03             	mov    di,0x3eb
    1527:	b8 40 15             	mov    ax,0x1540
    152a:	50                   	push   ax
    152b:	57                   	push   di
    152c:	9a 73 22 25 16       	call   0x1625:0x2273
    1531:	89 c7                	mov    di,ax
    1533:	8e c2                	mov    es,dx
    1535:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1538:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    153b:	06                   	push   es
    153c:	57                   	push   di
    153d:	9a 33 17 b9 15       	call   0x15b9:0x1733
    1542:	8b c8                	mov    cx,ax
    1544:	8b da                	mov    bx,dx
    1546:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1549:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    154e:	99                   	cwd
    154f:	3b d3                	cmp    dx,bx
    1551:	75 08                	jne    0x155b
    1553:	3b c1                	cmp    ax,cx
    1555:	75 04                	jne    0x155b
    1557:	b0 00                	mov    al,0x0
    1559:	eb 02                	jmp    0x155d
    155b:	b0 01                	mov    al,0x1
    155d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1560:	26 22 85 09 04       	and    al,BYTE PTR es:[di+0x409]
    1565:	08 c0                	or     al,al
    1567:	75 03                	jne    0x156c
    1569:	e9 8a 00             	jmp    0x15f6
    156c:	06                   	push   es
    156d:	57                   	push   di
    156e:	9a 26 37 a0 15       	call   0x15a0:0x3726
    1573:	8a d0                	mov    dl,al
    1575:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1578:	26 80 bd 10 04 00    	cmp    BYTE PTR es:[di+0x410],0x0
    157e:	b0 00                	mov    al,0x0
    1580:	75 01                	jne    0x1583
    1582:	40                   	inc    ax
    1583:	0a c2                	or     al,dl
    1585:	08 c0                	or     al,al
    1587:	74 63                	je     0x15ec
    1589:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    158e:	9a 23 3e b6 18       	call   0x18b6:0x3e23
    1593:	3d 06 00             	cmp    ax,0x6
    1596:	75 25                	jne    0x15bd
    1598:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    159b:	06                   	push   es
    159c:	57                   	push   di
    159d:	9a 25 3a ca 15       	call   0x15ca:0x3a25
    15a2:	08 c0                	or     al,al
    15a4:	75 15                	jne    0x15bb
    15a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15a9:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    15ae:	99                   	cwd
    15af:	52                   	push   dx
    15b0:	50                   	push   ax
    15b1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    15b4:	06                   	push   es
    15b5:	57                   	push   di
    15b6:	9a 8b 17 e6 15       	call   0x15e6:0x178b
    15bb:	eb 2d                	jmp    0x15ea
    15bd:	3d 07 00             	cmp    ax,0x7
    15c0:	75 0c                	jne    0x15ce
    15c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15c5:	06                   	push   es
    15c6:	57                   	push   di
    15c7:	9a de 37 f4 15       	call   0x15f4:0x37de
    15cc:	eb 1c                	jmp    0x15ea
    15ce:	3d 02 00             	cmp    ax,0x2
    15d1:	75 17                	jne    0x15ea
    15d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15d6:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    15db:	99                   	cwd
    15dc:	52                   	push   dx
    15dd:	50                   	push   ax
    15de:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    15e1:	06                   	push   es
    15e2:	57                   	push   di
    15e3:	9a 8b 17 fe 15       	call   0x15fe:0x178b
    15e8:	eb 00                	jmp    0x15ea
    15ea:	eb 0a                	jmp    0x15f6
    15ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15ef:	06                   	push   es
    15f0:	57                   	push   di
    15f1:	9a 0b 62 30 16       	call   0x1630:0x620b
    15f6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    15f9:	06                   	push   es
    15fa:	57                   	push   di
    15fb:	9a 33 17 1d 16       	call   0x161d:0x1733
    1600:	8b c8                	mov    cx,ax
    1602:	8b da                	mov    bx,dx
    1604:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1607:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    160c:	99                   	cwd
    160d:	3b d3                	cmp    dx,bx
    160f:	75 04                	jne    0x1615
    1611:	3b c1                	cmp    ax,cx
    1613:	74 1d                	je     0x1632
    1615:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1618:	06                   	push   es
    1619:	57                   	push   di
    161a:	9a 33 17 7c 25       	call   0x257c:0x1733
    161f:	bf ee 14             	mov    di,0x14ee
    1622:	9a 16 04 3e 16       	call   0x163e:0x416
    1627:	50                   	push   ax
    1628:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    162b:	06                   	push   es
    162c:	57                   	push   di
    162d:	9a be 13 4f 16       	call   0x164f:0x13be
    1632:	c9                   	leave
    1633:	ca 08 00             	retf   0x8
    1636:	55                   	push   bp
    1637:	89 e5                	mov    bp,sp
    1639:	31 c0                	xor    ax,ax
    163b:	9a 44 04 56 16       	call   0x1656:0x444
    1640:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1643:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1647:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    164b:	bf 22 00             	mov    di,0x22
    164e:	b8 9e 16             	mov    ax,0x169e
    1651:	50                   	push   ax
    1652:	57                   	push   di
    1653:	9a 55 22 73 16       	call   0x1673:0x2255
    1658:	08 c0                	or     al,al
    165a:	74 0a                	je     0x1666
    165c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    165f:	06                   	push   es
    1660:	57                   	push   di
    1661:	9a 56 55 a5 16       	call   0x16a5:0x5556
    1666:	c9                   	leave
    1667:	ca 08 00             	retf   0x8
    166a:	55                   	push   bp
    166b:	89 e5                	mov    bp,sp
    166d:	b8 08 00             	mov    ax,0x8
    1670:	9a 44 04 f4 16       	call   0x16f4:0x444
    1675:	83 ec 08             	sub    sp,0x8
    1678:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    167b:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    1681:	75 03                	jne    0x1686
    1683:	e9 a6 01             	jmp    0x182c
    1686:	26 80 bd 04 04 00    	cmp    BYTE PTR es:[di+0x404],0x0
    168c:	74 03                	je     0x1691
    168e:	e9 69 01             	jmp    0x17fa
    1691:	ff 76 08             	push   WORD PTR [bp+0x8]
    1694:	ff 76 06             	push   WORD PTR [bp+0x6]
    1697:	b0 01                	mov    al,0x1
    1699:	50                   	push   ax
    169a:	b8 22 00             	mov    ax,0x22
    169d:	ba c6 16             	mov    dx,0x16c6
    16a0:	52                   	push   dx
    16a1:	50                   	push   ax
    16a2:	9a 53 25 dc 16       	call   0x16dc:0x2553
    16a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16aa:	26 89 85 05 04       	mov    WORD PTR es:[di+0x405],ax
    16af:	26 89 95 07 04       	mov    WORD PTR es:[di+0x407],dx
    16b4:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    16b9:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    16bc:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    16bf:	6a 00                	push   0x0
    16c1:	06                   	push   es
    16c2:	57                   	push   di
    16c3:	9a af 11 d0 16       	call   0x16d0:0x11af
    16c8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    16cb:	06                   	push   es
    16cc:	57                   	push   di
    16cd:	9a d4 31 68 17       	call   0x1768:0x31d4
    16d2:	6a 00                	push   0x0
    16d4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    16d7:	06                   	push   es
    16d8:	57                   	push   di
    16d9:	9a 65 38 ed 16       	call   0x16ed:0x3865
    16de:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    16e1:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    16e5:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    16e9:	bf fb 04             	mov    di,0x4fb
    16ec:	b8 25 17             	mov    ax,0x1725
    16ef:	50                   	push   ax
    16f0:	57                   	push   di
    16f1:	9a 73 22 2c 17       	call   0x172c:0x2273
    16f6:	89 c7                	mov    di,ax
    16f8:	8e c2                	mov    es,dx
    16fa:	06                   	push   es
    16fb:	57                   	push   di
    16fc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16ff:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    1703:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1706:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1709:	ff 76 fa             	push   WORD PTR [bp-0x6]
    170c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    170f:	06                   	push   es
    1710:	57                   	push   di
    1711:	9a 9d 17 57 17       	call   0x1757:0x179d
    1716:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1719:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    171d:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1721:	bf fb 04             	mov    di,0x4fb
    1724:	b8 28 18             	mov    ax,0x1828
    1727:	50                   	push   ax
    1728:	57                   	push   di
    1729:	9a 73 22 4c 17       	call   0x174c:0x2273
    172e:	89 c7                	mov    di,ax
    1730:	8e c2                	mov    es,dx
    1732:	06                   	push   es
    1733:	57                   	push   di
    1734:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1737:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    173b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    173e:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1741:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1744:	05 1e 00             	add    ax,0x1e
    1747:	71 05                	jno    0x174e
    1749:	9a 3e 04 6f 17       	call   0x176f:0x43e
    174e:	50                   	push   ax
    174f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1752:	06                   	push   es
    1753:	57                   	push   di
    1754:	9a 7b 17 2b 1f       	call   0x1f2b:0x177b
    1759:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    175c:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1760:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1764:	bf 22 00             	mov    di,0x22
    1767:	b8 ce 17             	mov    ax,0x17ce
    176a:	50                   	push   ax
    176b:	57                   	push   di
    176c:	9a 73 22 93 17       	call   0x1793:0x2273
    1771:	89 c7                	mov    di,ax
    1773:	8e c2                	mov    es,dx
    1775:	26 c6 85 04 04 01    	mov    BYTE PTR es:[di+0x404],0x1
    177b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    177e:	26 83 bd 0c 04 01    	cmp    WORD PTR es:[di+0x40c],0x1
    1784:	7e 1e                	jle    0x17a4
    1786:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    178b:	2d 01 00             	sub    ax,0x1
    178e:	71 05                	jno    0x1795
    1790:	9a 3e 04 42 18       	call   0x1842:0x43e
    1795:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1798:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    179d:	26 89 85 0c 04       	mov    WORD PTR es:[di+0x40c],ax
    17a2:	eb 12                	jmp    0x17b6
    17a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17a7:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    17ac:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    17b1:	26 89 85 0c 04       	mov    WORD PTR es:[di+0x40c],ax
    17b6:	83 3e 50 01 00       	cmp    WORD PTR ds:0x150,0x0
    17bb:	75 15                	jne    0x17d2
    17bd:	ff 36 50 01          	push   WORD PTR ds:0x150
    17c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17c4:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    17c9:	06                   	push   es
    17ca:	57                   	push   di
    17cb:	9a 52 13 e4 17       	call   0x17e4:0x1352
    17d0:	eb 14                	jmp    0x17e6
    17d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17d5:	26 ff b5 0a 04       	push   WORD PTR es:[di+0x40a]
    17da:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    17df:	06                   	push   es
    17e0:	57                   	push   di
    17e1:	9a 52 13 f8 17       	call   0x17f8:0x1352
    17e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e9:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    17ee:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    17f3:	06                   	push   es
    17f4:	57                   	push   di
    17f5:	9a be 13 3b 18       	call   0x183b:0x13be
    17fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17fd:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    1802:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    1807:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    180a:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    180f:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    1814:	06                   	push   es
    1815:	57                   	push   di
    1816:	9a 6f 24 ff ff       	call   0xffff:0x246f
    181b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    181e:	26 c4 bd 05 04       	les    di,DWORD PTR es:[di+0x405]
    1823:	06                   	push   es
    1824:	57                   	push   di
    1825:	9a cc 5c 69 18       	call   0x1869:0x5ccc
    182a:	eb 3f                	jmp    0x186b
    182c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    182f:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    1833:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1837:	bf 22 00             	mov    di,0x22
    183a:	b8 57 18             	mov    ax,0x1857
    183d:	50                   	push   ax
    183e:	57                   	push   di
    183f:	9a 55 22 5e 18       	call   0x185e:0x2255
    1844:	08 c0                	or     al,al
    1846:	74 23                	je     0x186b
    1848:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    184b:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    184f:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1853:	bf 22 00             	mov    di,0x22
    1856:	b8 95 18             	mov    ax,0x1895
    1859:	50                   	push   ax
    185a:	57                   	push   di
    185b:	9a 73 22 77 18       	call   0x1877:0x2273
    1860:	89 c7                	mov    di,ax
    1862:	8e c2                	mov    es,dx
    1864:	06                   	push   es
    1865:	57                   	push   di
    1866:	9a cc 5c e5 18       	call   0x18e5:0x5ccc
    186b:	c9                   	leave
    186c:	ca 08 00             	retf   0x8
    186f:	55                   	push   bp
    1870:	89 e5                	mov    bp,sp
    1872:	31 c0                	xor    ax,ax
    1874:	9a 44 04 a0 18       	call   0x18a0:0x444
    1879:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    187c:	26 ff b5 0c 04       	push   WORD PTR es:[di+0x40c]
    1881:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    1886:	6a 00                	push   0x0
    1888:	9a b8 11 98 19       	call   0x1998:0x11b8
    188d:	c9                   	leave
    188e:	ca 08 00             	retf   0x8
    1891:	00 00                	add    BYTE PTR [bx+si],al
    1893:	44                   	inc    sp
    1894:	19 ad 18 55          	sbb    WORD PTR [di+0x5518],bp
    1898:	89 e5                	mov    bp,sp
    189a:	b8 04 00             	mov    ax,0x4
    189d:	9a 44 04 5c 19       	call   0x195c:0x444
    18a2:	83 ec 04             	sub    sp,0x4
    18a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18a8:	06                   	push   es
    18a9:	57                   	push   di
    18aa:	9a 26 37 18 19       	call   0x1918:0x3726
    18af:	08 c0                	or     al,al
    18b1:	74 08                	je     0x18bb
    18b3:	9a d1 37 de 18       	call   0x18de:0x37d1
    18b8:	e9 95 00             	jmp    0x1950
    18bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18be:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    18c3:	06                   	push   es
    18c4:	57                   	push   di
    18c5:	9a 17 2f 80 19       	call   0x1980:0x2f17
    18ca:	08 c0                	or     al,al
    18cc:	75 03                	jne    0x18d1
    18ce:	e9 7f 00             	jmp    0x1950
    18d1:	ff 76 08             	push   WORD PTR [bp+0x8]
    18d4:	ff 76 06             	push   WORD PTR [bp+0x6]
    18d7:	b0 01                	mov    al,0x1
    18d9:	50                   	push   ax
    18da:	b8 b4 25             	mov    ax,0x25b4
    18dd:	ba 0d 19             	mov    dx,0x190d
    18e0:	52                   	push   dx
    18e1:	50                   	push   ax
    18e2:	9a 53 25 36 19       	call   0x1936:0x2553
    18e7:	a3 04 20             	mov    ds:0x2004,ax
    18ea:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    18ee:	b8 91 18             	mov    ax,0x1891
    18f1:	0e                   	push   cs
    18f2:	50                   	push   ax
    18f3:	55                   	push   bp
    18f4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    18f8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    18fc:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1900:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1903:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1906:	6a 01                	push   0x1
    1908:	06                   	push   es
    1909:	57                   	push   di
    190a:	9a 8d 2f 6f 19       	call   0x196f:0x2f8d
    190f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1912:	06                   	push   es
    1913:	57                   	push   di
    1914:	b8 6f 18             	mov    ax,0x186f
    1917:	ba 66 19             	mov    dx,0x1966
    191a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    191d:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    1922:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    1927:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    192c:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    1931:	06                   	push   es
    1932:	57                   	push   di
    1933:	9a 45 5d 4d 19       	call   0x194d:0x5d45
    1938:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    193c:	83 c4 06             	add    sp,0x6
    193f:	b8 50 19             	mov    ax,0x1950
    1942:	0e                   	push   cs
    1943:	50                   	push   ax
    1944:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1948:	06                   	push   es
    1949:	57                   	push   di
    194a:	9a 1d 5f e6 19       	call   0x19e6:0x5f1d
    194f:	cb                   	retf
    1950:	c9                   	leave
    1951:	ca 08 00             	retf   0x8
    1954:	55                   	push   bp
    1955:	89 e5                	mov    bp,sp
    1957:	31 c0                	xor    ax,ax
    1959:	9a 44 04 cd 19       	call   0x19cd:0x444
    195e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1961:	06                   	push   es
    1962:	57                   	push   di
    1963:	9a 26 37 d8 23       	call   0x23d8:0x3726
    1968:	08 c0                	or     al,al
    196a:	74 07                	je     0x1973
    196c:	9a d1 37 ed 2f       	call   0x2fed:0x37d1
    1971:	eb 27                	jmp    0x199a
    1973:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1976:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    197b:	06                   	push   es
    197c:	57                   	push   di
    197d:	9a 17 2f ff ff       	call   0xffff:0x2f17
    1982:	08 c0                	or     al,al
    1984:	74 14                	je     0x199a
    1986:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1989:	26 ff b5 0c 04       	push   WORD PTR es:[di+0x40c]
    198e:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    1993:	6a 01                	push   0x1
    1995:	9a b8 11 da 36       	call   0x36da:0x11b8
    199a:	c9                   	leave
    199b:	ca 08 00             	retf   0x8
    199e:	0a 23                	or     ah,BYTE PTR [bp+di]
    19a0:	2c 23                	sub    al,0x23
    19a2:	23 30                	and    si,WORD PTR [bx+si]
    19a4:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    19a7:	23 23                	and    sp,WORD PTR [bp+di]
    19a9:	07                   	pop    es
    19aa:	23 30                	and    si,WORD PTR [bx+si]
    19ac:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    19af:	23 23                	and    sp,WORD PTR [bp+di]
    19b1:	07                   	pop    es
    19b2:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    19b6:	2b 30                	sub    si,WORD PTR [bx+si]
    19b8:	30 01                	xor    BYTE PTR [bx+di],al
    19ba:	30 05                	xor    BYTE PTR [di],al
    19bc:	23 2c                	and    bp,WORD PTR [si]
    19be:	23 23                	and    sp,WORD PTR [bp+di]
    19c0:	30 02                	xor    BYTE PTR [bp+si],al
    19c2:	23 30                	and    si,WORD PTR [bx+si]
    19c4:	55                   	push   bp
    19c5:	89 e5                	mov    bp,sp
    19c7:	b8 14 03             	mov    ax,0x314
    19ca:	9a 44 04 5f 1a       	call   0x1a5f:0x444
    19cf:	81 ec 14 03          	sub    sp,0x314
    19d3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19d6:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    19da:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    19de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19e1:	06                   	push   es
    19e2:	57                   	push   di
    19e3:	9a d5 33 10 1a       	call   0x1a10:0x33d5
    19e8:	89 c7                	mov    di,ax
    19ea:	8e c2                	mov    es,dx
    19ec:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    19f0:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    19f4:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    19f8:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    19fc:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1a00:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1a04:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1a08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a0b:	06                   	push   es
    1a0c:	57                   	push   di
    1a0d:	9a d5 33 df 1a       	call   0x1adf:0x33d5
    1a12:	89 c7                	mov    di,ax
    1a14:	8e c2                	mov    es,dx
    1a16:	06                   	push   es
    1a17:	57                   	push   di
    1a18:	9a 99 20 ea 1a       	call   0x1aea:0x2099
    1a1d:	8d be f4 fc          	lea    di,[bp-0x30c]
    1a21:	16                   	push   ss
    1a22:	57                   	push   di
    1a23:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1a27:	06                   	push   es
    1a28:	57                   	push   di
    1a29:	9a 9f 1a 37 1a       	call   0x1a37:0x1a9f
    1a2e:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1a32:	06                   	push   es
    1a33:	57                   	push   di
    1a34:	9a 5f 1a 67 1e       	call   0x1e67:0x1a5f
    1a39:	89 c7                	mov    di,ax
    1a3b:	8e c2                	mov    es,dx
    1a3d:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1a41:	06                   	push   es
    1a42:	57                   	push   di
    1a43:	9a 9b 3b bb 1e       	call   0x1ebb:0x3b9b
    1a48:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1a4b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1a4e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a51:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1a54:	bf 58 0a             	mov    di,0xa58
    1a57:	b8 72 1a             	mov    ax,0x1a72
    1a5a:	50                   	push   ax
    1a5b:	57                   	push   di
    1a5c:	9a 55 22 79 1a       	call   0x1a79:0x2255
    1a61:	08 c0                	or     al,al
    1a63:	75 03                	jne    0x1a68
    1a65:	e9 bb 01             	jmp    0x1c23
    1a68:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a6b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1a6e:	bf 58 0a             	mov    di,0xa58
    1a71:	b8 1e 1c             	mov    ax,0x1c1e
    1a74:	50                   	push   ax
    1a75:	57                   	push   di
    1a76:	9a 73 22 98 1a       	call   0x1a98:0x2273
    1a7b:	89 c7                	mov    di,ax
    1a7d:	8e c2                	mov    es,dx
    1a7f:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    1a83:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    1a87:	bf 9e 19             	mov    di,0x199e
    1a8a:	0e                   	push   cs
    1a8b:	57                   	push   di
    1a8c:	8d be fc fd          	lea    di,[bp-0x204]
    1a90:	16                   	push   ss
    1a91:	57                   	push   di
    1a92:	68 ff 00             	push   0xff
    1a95:	9a e7 17 cf 1a       	call   0x1acf:0x17e7
    1a9a:	8d be f0 fc          	lea    di,[bp-0x310]
    1a9e:	16                   	push   ss
    1a9f:	57                   	push   di
    1aa0:	8d be fc fd          	lea    di,[bp-0x204]
    1aa4:	16                   	push   ss
    1aa5:	57                   	push   di
    1aa6:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1aaa:	06                   	push   es
    1aab:	57                   	push   di
    1aac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1aaf:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1ab3:	83 ec 0a             	sub    sp,0xa
    1ab6:	89 e3                	mov    bx,sp
    1ab8:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1abc:	90                   	nop
    1abd:	9b                   	fwait
    1abe:	9a d4 10 41 1b       	call   0x1b41:0x10d4
    1ac3:	8d be fc fe          	lea    di,[bp-0x104]
    1ac7:	16                   	push   ss
    1ac8:	57                   	push   di
    1ac9:	68 ff 00             	push   0xff
    1acc:	9a e7 17 fe 1a       	call   0x1afe:0x17e7
    1ad1:	8d be fc fe          	lea    di,[bp-0x104]
    1ad5:	16                   	push   ss
    1ad6:	57                   	push   di
    1ad7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ada:	06                   	push   es
    1adb:	57                   	push   di
    1adc:	9a d5 33 5f 1b       	call   0x1b5f:0x33d5
    1ae1:	89 c7                	mov    di,ax
    1ae3:	8e c2                	mov    es,dx
    1ae5:	06                   	push   es
    1ae6:	57                   	push   di
    1ae7:	9a 03 20 6a 1b       	call   0x1b6a:0x2003
    1aec:	8b d0                	mov    dx,ax
    1aee:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1af2:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1af6:	2d 05 00             	sub    ax,0x5
    1af9:	71 05                	jno    0x1b00
    1afb:	9a 3e 04 18 1b       	call   0x1b18:0x43e
    1b00:	3b c2                	cmp    ax,dx
    1b02:	7e 03                	jle    0x1b07
    1b04:	e9 08 01             	jmp    0x1c0f
    1b07:	bf a9 19             	mov    di,0x19a9
    1b0a:	0e                   	push   cs
    1b0b:	57                   	push   di
    1b0c:	8d be fc fd          	lea    di,[bp-0x204]
    1b10:	16                   	push   ss
    1b11:	57                   	push   di
    1b12:	68 ff 00             	push   0xff
    1b15:	9a e7 17 4f 1b       	call   0x1b4f:0x17e7
    1b1a:	8d be f0 fc          	lea    di,[bp-0x310]
    1b1e:	16                   	push   ss
    1b1f:	57                   	push   di
    1b20:	8d be fc fd          	lea    di,[bp-0x204]
    1b24:	16                   	push   ss
    1b25:	57                   	push   di
    1b26:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1b2a:	06                   	push   es
    1b2b:	57                   	push   di
    1b2c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b2f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1b33:	83 ec 0a             	sub    sp,0xa
    1b36:	89 e3                	mov    bx,sp
    1b38:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1b3c:	90                   	nop
    1b3d:	9b                   	fwait
    1b3e:	9a d4 10 a3 1c       	call   0x1ca3:0x10d4
    1b43:	8d be fc fe          	lea    di,[bp-0x104]
    1b47:	16                   	push   ss
    1b48:	57                   	push   di
    1b49:	68 ff 00             	push   0xff
    1b4c:	9a e7 17 7e 1b       	call   0x1b7e:0x17e7
    1b51:	8d be fc fe          	lea    di,[bp-0x104]
    1b55:	16                   	push   ss
    1b56:	57                   	push   di
    1b57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b5a:	06                   	push   es
    1b5b:	57                   	push   di
    1b5c:	9a d5 33 a8 1b       	call   0x1ba8:0x33d5
    1b61:	89 c7                	mov    di,ax
    1b63:	8e c2                	mov    es,dx
    1b65:	06                   	push   es
    1b66:	57                   	push   di
    1b67:	9a 03 20 b3 1b       	call   0x1bb3:0x2003
    1b6c:	8b d0                	mov    dx,ax
    1b6e:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1b72:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1b76:	2d 05 00             	sub    ax,0x5
    1b79:	71 05                	jno    0x1b80
    1b7b:	9a 3e 04 98 1b       	call   0x1b98:0x43e
    1b80:	3b c2                	cmp    ax,dx
    1b82:	7e 03                	jle    0x1b87
    1b84:	e9 88 00             	jmp    0x1c0f
    1b87:	bf b1 19             	mov    di,0x19b1
    1b8a:	0e                   	push   cs
    1b8b:	57                   	push   di
    1b8c:	8d be fc fd          	lea    di,[bp-0x204]
    1b90:	16                   	push   ss
    1b91:	57                   	push   di
    1b92:	68 ff 00             	push   0xff
    1b95:	9a e7 17 c7 1b       	call   0x1bc7:0x17e7
    1b9a:	8d be fc fd          	lea    di,[bp-0x204]
    1b9e:	16                   	push   ss
    1b9f:	57                   	push   di
    1ba0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ba3:	06                   	push   es
    1ba4:	57                   	push   di
    1ba5:	9a d5 33 c1 1c       	call   0x1cc1:0x33d5
    1baa:	89 c7                	mov    di,ax
    1bac:	8e c2                	mov    es,dx
    1bae:	06                   	push   es
    1baf:	57                   	push   di
    1bb0:	9a 03 20 cc 1c       	call   0x1ccc:0x2003
    1bb5:	8b d0                	mov    dx,ax
    1bb7:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1bbb:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1bbf:	2d 05 00             	sub    ax,0x5
    1bc2:	71 05                	jno    0x1bc9
    1bc4:	9a 3e 04 f5 1b       	call   0x1bf5:0x43e
    1bc9:	3b c2                	cmp    ax,dx
    1bcb:	b0 00                	mov    al,0x0
    1bcd:	7e 01                	jle    0x1bd0
    1bcf:	40                   	inc    ax
    1bd0:	8a d0                	mov    dl,al
    1bd2:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1bd7:	b0 00                	mov    al,0x0
    1bd9:	73 01                	jae    0x1bdc
    1bdb:	40                   	inc    ax
    1bdc:	22 c2                	and    al,dl
    1bde:	08 c0                	or     al,al
    1be0:	74 17                	je     0x1bf9
    1be2:	bf b9 19             	mov    di,0x19b9
    1be5:	0e                   	push   cs
    1be6:	57                   	push   di
    1be7:	8d be fc fd          	lea    di,[bp-0x204]
    1beb:	16                   	push   ss
    1bec:	57                   	push   di
    1bed:	68 ff 00             	push   0xff
    1bf0:	6a 03                	push   0x3
    1bf2:	9a 16 19 0d 1c       	call   0x1c0d:0x1916
    1bf7:	eb a1                	jmp    0x1b9a
    1bf9:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1bfe:	76 0f                	jbe    0x1c0f
    1c00:	8d be fc fd          	lea    di,[bp-0x204]
    1c04:	16                   	push   ss
    1c05:	57                   	push   di
    1c06:	6a 03                	push   0x3
    1c08:	6a 01                	push   0x1
    1c0a:	9a 75 19 34 1c       	call   0x1c34:0x1975
    1c0f:	8d be fc fd          	lea    di,[bp-0x204]
    1c13:	16                   	push   ss
    1c14:	57                   	push   di
    1c15:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1c19:	06                   	push   es
    1c1a:	57                   	push   di
    1c1b:	9a f9 60 2d 1c       	call   0x1c2d:0x60f9
    1c20:	e9 ec 01             	jmp    0x1e0f
    1c23:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c26:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c29:	bf c8 07             	mov    di,0x7c8
    1c2c:	b8 47 1c             	mov    ax,0x1c47
    1c2f:	50                   	push   ax
    1c30:	57                   	push   di
    1c31:	9a 55 22 4e 1c       	call   0x1c4e:0x2255
    1c36:	08 c0                	or     al,al
    1c38:	75 03                	jne    0x1c3d
    1c3a:	e9 d2 01             	jmp    0x1e0f
    1c3d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c40:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c43:	bf c8 07             	mov    di,0x7c8
    1c46:	b8 0d 1e             	mov    ax,0x1e0d
    1c49:	50                   	push   ax
    1c4a:	57                   	push   di
    1c4b:	9a 73 22 6d 1c       	call   0x1c6d:0x2273
    1c50:	89 c7                	mov    di,ax
    1c52:	8e c2                	mov    es,dx
    1c54:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    1c58:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    1c5c:	bf bb 19             	mov    di,0x19bb
    1c5f:	0e                   	push   cs
    1c60:	57                   	push   di
    1c61:	8d be fc fd          	lea    di,[bp-0x204]
    1c65:	16                   	push   ss
    1c66:	57                   	push   di
    1c67:	68 ff 00             	push   0xff
    1c6a:	9a e7 17 b1 1c       	call   0x1cb1:0x17e7
    1c6f:	8d be ec fc          	lea    di,[bp-0x314]
    1c73:	16                   	push   ss
    1c74:	57                   	push   di
    1c75:	8d be fc fd          	lea    di,[bp-0x204]
    1c79:	16                   	push   ss
    1c7a:	57                   	push   di
    1c7b:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1c7f:	06                   	push   es
    1c80:	57                   	push   di
    1c81:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c84:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1c88:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    1c8c:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1c90:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1c95:	83 ec 0a             	sub    sp,0xa
    1c98:	89 e3                	mov    bx,sp
    1c9a:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1c9e:	90                   	nop
    1c9f:	9b                   	fwait
    1ca0:	9a d4 10 30 1d       	call   0x1d30:0x10d4
    1ca5:	8d be fc fe          	lea    di,[bp-0x104]
    1ca9:	16                   	push   ss
    1caa:	57                   	push   di
    1cab:	68 ff 00             	push   0xff
    1cae:	9a e7 17 e0 1c       	call   0x1ce0:0x17e7
    1cb3:	8d be fc fe          	lea    di,[bp-0x104]
    1cb7:	16                   	push   ss
    1cb8:	57                   	push   di
    1cb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cbc:	06                   	push   es
    1cbd:	57                   	push   di
    1cbe:	9a d5 33 4e 1d       	call   0x1d4e:0x33d5
    1cc3:	89 c7                	mov    di,ax
    1cc5:	8e c2                	mov    es,dx
    1cc7:	06                   	push   es
    1cc8:	57                   	push   di
    1cc9:	9a 03 20 59 1d       	call   0x1d59:0x2003
    1cce:	8b d0                	mov    dx,ax
    1cd0:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1cd4:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1cd8:	2d 05 00             	sub    ax,0x5
    1cdb:	71 05                	jno    0x1ce2
    1cdd:	9a 3e 04 fa 1c       	call   0x1cfa:0x43e
    1ce2:	3b c2                	cmp    ax,dx
    1ce4:	7e 03                	jle    0x1ce9
    1ce6:	e9 15 01             	jmp    0x1dfe
    1ce9:	bf c1 19             	mov    di,0x19c1
    1cec:	0e                   	push   cs
    1ced:	57                   	push   di
    1cee:	8d be fc fd          	lea    di,[bp-0x204]
    1cf2:	16                   	push   ss
    1cf3:	57                   	push   di
    1cf4:	68 ff 00             	push   0xff
    1cf7:	9a e7 17 3e 1d       	call   0x1d3e:0x17e7
    1cfc:	8d be ec fc          	lea    di,[bp-0x314]
    1d00:	16                   	push   ss
    1d01:	57                   	push   di
    1d02:	8d be fc fd          	lea    di,[bp-0x204]
    1d06:	16                   	push   ss
    1d07:	57                   	push   di
    1d08:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1d0c:	06                   	push   es
    1d0d:	57                   	push   di
    1d0e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d11:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1d15:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    1d19:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1d1d:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1d22:	83 ec 0a             	sub    sp,0xa
    1d25:	89 e3                	mov    bx,sp
    1d27:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1d2b:	90                   	nop
    1d2c:	9b                   	fwait
    1d2d:	9a d4 10 1c 1f       	call   0x1f1c:0x10d4
    1d32:	8d be fc fe          	lea    di,[bp-0x104]
    1d36:	16                   	push   ss
    1d37:	57                   	push   di
    1d38:	68 ff 00             	push   0xff
    1d3b:	9a e7 17 6d 1d       	call   0x1d6d:0x17e7
    1d40:	8d be fc fe          	lea    di,[bp-0x104]
    1d44:	16                   	push   ss
    1d45:	57                   	push   di
    1d46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d49:	06                   	push   es
    1d4a:	57                   	push   di
    1d4b:	9a d5 33 97 1d       	call   0x1d97:0x33d5
    1d50:	89 c7                	mov    di,ax
    1d52:	8e c2                	mov    es,dx
    1d54:	06                   	push   es
    1d55:	57                   	push   di
    1d56:	9a 03 20 a2 1d       	call   0x1da2:0x2003
    1d5b:	8b d0                	mov    dx,ax
    1d5d:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1d61:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1d65:	2d 05 00             	sub    ax,0x5
    1d68:	71 05                	jno    0x1d6f
    1d6a:	9a 3e 04 87 1d       	call   0x1d87:0x43e
    1d6f:	3b c2                	cmp    ax,dx
    1d71:	7e 03                	jle    0x1d76
    1d73:	e9 88 00             	jmp    0x1dfe
    1d76:	bf b1 19             	mov    di,0x19b1
    1d79:	0e                   	push   cs
    1d7a:	57                   	push   di
    1d7b:	8d be fc fd          	lea    di,[bp-0x204]
    1d7f:	16                   	push   ss
    1d80:	57                   	push   di
    1d81:	68 ff 00             	push   0xff
    1d84:	9a e7 17 b6 1d       	call   0x1db6:0x17e7
    1d89:	8d be fc fd          	lea    di,[bp-0x204]
    1d8d:	16                   	push   ss
    1d8e:	57                   	push   di
    1d8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d92:	06                   	push   es
    1d93:	57                   	push   di
    1d94:	9a d5 33 23 1e       	call   0x1e23:0x33d5
    1d99:	89 c7                	mov    di,ax
    1d9b:	8e c2                	mov    es,dx
    1d9d:	06                   	push   es
    1d9e:	57                   	push   di
    1d9f:	9a 03 20 2e 1e       	call   0x1e2e:0x2003
    1da4:	8b d0                	mov    dx,ax
    1da6:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1daa:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1dae:	2d 05 00             	sub    ax,0x5
    1db1:	71 05                	jno    0x1db8
    1db3:	9a 3e 04 e4 1d       	call   0x1de4:0x43e
    1db8:	3b c2                	cmp    ax,dx
    1dba:	b0 00                	mov    al,0x0
    1dbc:	7e 01                	jle    0x1dbf
    1dbe:	40                   	inc    ax
    1dbf:	8a d0                	mov    dl,al
    1dc1:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1dc6:	b0 00                	mov    al,0x0
    1dc8:	73 01                	jae    0x1dcb
    1dca:	40                   	inc    ax
    1dcb:	22 c2                	and    al,dl
    1dcd:	08 c0                	or     al,al
    1dcf:	74 17                	je     0x1de8
    1dd1:	bf b9 19             	mov    di,0x19b9
    1dd4:	0e                   	push   cs
    1dd5:	57                   	push   di
    1dd6:	8d be fc fd          	lea    di,[bp-0x204]
    1dda:	16                   	push   ss
    1ddb:	57                   	push   di
    1ddc:	68 ff 00             	push   0xff
    1ddf:	6a 03                	push   0x3
    1de1:	9a 16 19 fc 1d       	call   0x1dfc:0x1916
    1de6:	eb a1                	jmp    0x1d89
    1de8:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1ded:	76 0f                	jbe    0x1dfe
    1def:	8d be fc fd          	lea    di,[bp-0x204]
    1df3:	16                   	push   ss
    1df4:	57                   	push   di
    1df5:	6a 03                	push   0x3
    1df7:	6a 01                	push   0x1
    1df9:	9a 75 19 57 1e       	call   0x1e57:0x1975
    1dfe:	8d be fc fd          	lea    di,[bp-0x204]
    1e02:	16                   	push   ss
    1e03:	57                   	push   di
    1e04:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1e08:	06                   	push   es
    1e09:	57                   	push   di
    1e0a:	9a f9 60 cd 1e       	call   0x1ecd:0x60f9
    1e0f:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1e13:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1e17:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1e1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e1e:	06                   	push   es
    1e1f:	57                   	push   di
    1e20:	9a d5 33 db 26       	call   0x26db:0x33d5
    1e25:	89 c7                	mov    di,ax
    1e27:	8e c2                	mov    es,dx
    1e29:	06                   	push   es
    1e2a:	57                   	push   di
    1e2b:	9a 99 20 5a 2a       	call   0x2a5a:0x2099
    1e30:	c9                   	leave
    1e31:	ca 08 00             	retf   0x8
    1e34:	0a 23                	or     ah,BYTE PTR [bp+di]
    1e36:	2c 23                	sub    al,0x23
    1e38:	23 30                	and    si,WORD PTR [bx+si]
    1e3a:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1e3d:	23 23                	and    sp,WORD PTR [bp+di]
    1e3f:	05 23 2c             	add    ax,0x2c23
    1e42:	23 23                	and    sp,WORD PTR [bp+di]
    1e44:	30 05                	xor    BYTE PTR [di],al
    1e46:	23 30                	and    si,WORD PTR [bx+si]
    1e48:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1e4b:	02 23                	add    ah,BYTE PTR [bp+di]
    1e4d:	30 55 89             	xor    BYTE PTR [di-0x77],dl
    1e50:	e5 b8                	in     ax,0xb8
    1e52:	10 01                	adc    BYTE PTR [bx+di],al
    1e54:	9a 44 04 6e 1e       	call   0x1e6e:0x444
    1e59:	81 ec 10 01          	sub    sp,0x110
    1e5d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e60:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e63:	bf 22 00             	mov    di,0x22
    1e66:	b8 81 1e             	mov    ax,0x1e81
    1e69:	50                   	push   ax
    1e6a:	57                   	push   di
    1e6b:	9a 55 22 88 1e       	call   0x1e88:0x2255
    1e70:	08 c0                	or     al,al
    1e72:	75 03                	jne    0x1e77
    1e74:	e9 4e 01             	jmp    0x1fc5
    1e77:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e7a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e7d:	bf 22 00             	mov    di,0x22
    1e80:	b8 a2 1e             	mov    ax,0x1ea2
    1e83:	50                   	push   ax
    1e84:	57                   	push   di
    1e85:	9a 73 22 d4 1e       	call   0x1ed4:0x2273
    1e8a:	89 c7                	mov    di,ax
    1e8c:	8e c2                	mov    es,dx
    1e8e:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1e91:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1e94:	8d be f8 fe          	lea    di,[bp-0x108]
    1e98:	16                   	push   ss
    1e99:	57                   	push   di
    1e9a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1e9d:	06                   	push   es
    1e9e:	57                   	push   di
    1e9f:	9a 9f 1a ac 1e       	call   0x1eac:0x1a9f
    1ea4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ea7:	06                   	push   es
    1ea8:	57                   	push   di
    1ea9:	9a 5f 1a cf 1f       	call   0x1fcf:0x1a5f
    1eae:	89 c7                	mov    di,ax
    1eb0:	8e c2                	mov    es,dx
    1eb2:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1eb6:	06                   	push   es
    1eb7:	57                   	push   di
    1eb8:	9a 9b 3b 23 20       	call   0x2023:0x3b9b
    1ebd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1ec0:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1ec3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ec6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ec9:	bf 58 0a             	mov    di,0xa58
    1ecc:	b8 e4 1e             	mov    ax,0x1ee4
    1ecf:	50                   	push   ax
    1ed0:	57                   	push   di
    1ed1:	9a 55 22 eb 1e       	call   0x1eeb:0x2255
    1ed6:	08 c0                	or     al,al
    1ed8:	74 56                	je     0x1f30
    1eda:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1edd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ee0:	bf 58 0a             	mov    di,0xa58
    1ee3:	b8 3a 1f             	mov    ax,0x1f3a
    1ee6:	50                   	push   ax
    1ee7:	57                   	push   di
    1ee8:	9a 73 22 41 1f       	call   0x1f41:0x2273
    1eed:	89 c7                	mov    di,ax
    1eef:	8e c2                	mov    es,dx
    1ef1:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1ef4:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1ef7:	8d be f4 fe          	lea    di,[bp-0x10c]
    1efb:	16                   	push   ss
    1efc:	57                   	push   di
    1efd:	bf 34 1e             	mov    di,0x1e34
    1f00:	0e                   	push   cs
    1f01:	57                   	push   di
    1f02:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f05:	06                   	push   es
    1f06:	57                   	push   di
    1f07:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f0a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1f0e:	83 ec 0a             	sub    sp,0xa
    1f11:	89 e3                	mov    bx,sp
    1f13:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1f17:	90                   	nop
    1f18:	9b                   	fwait
    1f19:	9a d4 10 93 1f       	call   0x1f93:0x10d4
    1f1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f21:	26 c4 bd bc 03       	les    di,DWORD PTR es:[di+0x3bc]
    1f26:	06                   	push   es
    1f27:	57                   	push   di
    1f28:	9a 8c 1d a2 1f       	call   0x1fa2:0x1d8c
    1f2d:	e9 95 00             	jmp    0x1fc5
    1f30:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f33:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1f36:	bf c8 07             	mov    di,0x7c8
    1f39:	b8 51 1f             	mov    ax,0x1f51
    1f3c:	50                   	push   ax
    1f3d:	57                   	push   di
    1f3e:	9a 55 22 58 1f       	call   0x1f58:0x2255
    1f43:	08 c0                	or     al,al
    1f45:	74 5f                	je     0x1fa6
    1f47:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f4a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1f4d:	bf c8 07             	mov    di,0x7c8
    1f50:	b8 35 20             	mov    ax,0x2035
    1f53:	50                   	push   ax
    1f54:	57                   	push   di
    1f55:	9a 73 22 d6 1f       	call   0x1fd6:0x2273
    1f5a:	89 c7                	mov    di,ax
    1f5c:	8e c2                	mov    es,dx
    1f5e:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1f61:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1f64:	8d be f0 fe          	lea    di,[bp-0x110]
    1f68:	16                   	push   ss
    1f69:	57                   	push   di
    1f6a:	bf 3f 1e             	mov    di,0x1e3f
    1f6d:	0e                   	push   cs
    1f6e:	57                   	push   di
    1f6f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f72:	06                   	push   es
    1f73:	57                   	push   di
    1f74:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f77:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1f7b:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    1f7e:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    1f81:	9b db 46 f0          	fild   DWORD PTR [bp-0x10]
    1f85:	83 ec 0a             	sub    sp,0xa
    1f88:	89 e3                	mov    bx,sp
    1f8a:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1f8e:	90                   	nop
    1f8f:	9b                   	fwait
    1f90:	9a d4 10 c6 27       	call   0x27c6:0x10d4
    1f95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f98:	26 c4 bd bc 03       	les    di,DWORD PTR es:[di+0x3bc]
    1f9d:	06                   	push   es
    1f9e:	57                   	push   di
    1f9f:	9a 8c 1d c3 1f       	call   0x1fc3:0x1d8c
    1fa4:	eb 1f                	jmp    0x1fc5
    1fa6:	8d be f8 fe          	lea    di,[bp-0x108]
    1faa:	16                   	push   ss
    1fab:	57                   	push   di
    1fac:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1faf:	06                   	push   es
    1fb0:	57                   	push   di
    1fb1:	9a 24 15 76 22       	call   0x2276:0x1524
    1fb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb9:	26 c4 bd bc 03       	les    di,DWORD PTR es:[di+0x3bc]
    1fbe:	06                   	push   es
    1fbf:	57                   	push   di
    1fc0:	9a 8c 1d 85 21       	call   0x2185:0x1d8c
    1fc5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1fc8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1fcb:	bf 22 00             	mov    di,0x22
    1fce:	b8 e9 1f             	mov    ax,0x1fe9
    1fd1:	50                   	push   ax
    1fd2:	57                   	push   di
    1fd3:	9a 55 22 f0 1f       	call   0x1ff0:0x2255
    1fd8:	08 c0                	or     al,al
    1fda:	75 03                	jne    0x1fdf
    1fdc:	e9 d4 00             	jmp    0x20b3
    1fdf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1fe2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1fe5:	bf 22 00             	mov    di,0x22
    1fe8:	b8 0a 20             	mov    ax,0x200a
    1feb:	50                   	push   ax
    1fec:	57                   	push   di
    1fed:	9a 73 22 3c 20       	call   0x203c:0x2273
    1ff2:	89 c7                	mov    di,ax
    1ff4:	8e c2                	mov    es,dx
    1ff6:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1ff9:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1ffc:	8d be f8 fe          	lea    di,[bp-0x108]
    2000:	16                   	push   ss
    2001:	57                   	push   di
    2002:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2005:	06                   	push   es
    2006:	57                   	push   di
    2007:	9a 9f 1a 14 20       	call   0x2014:0x1a9f
    200c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    200f:	06                   	push   es
    2010:	57                   	push   di
    2011:	9a 5f 1a bd 20       	call   0x20bd:0x1a5f
    2016:	89 c7                	mov    di,ax
    2018:	8e c2                	mov    es,dx
    201a:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    201e:	06                   	push   es
    201f:	57                   	push   di
    2020:	9a 9b 3b ac 22       	call   0x22ac:0x3b9b
    2025:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2028:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    202b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    202e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2031:	bf 58 0a             	mov    di,0xa58
    2034:	b8 4c 20             	mov    ax,0x204c
    2037:	50                   	push   ax
    2038:	57                   	push   di
    2039:	9a 55 22 53 20       	call   0x2053:0x2255
    203e:	08 c0                	or     al,al
    2040:	74 2e                	je     0x2070
    2042:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2045:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2048:	bf 58 0a             	mov    di,0xa58
    204b:	b8 6c 20             	mov    ax,0x206c
    204e:	50                   	push   ax
    204f:	57                   	push   di
    2050:	9a 73 22 81 20       	call   0x2081:0x2273
    2055:	89 c7                	mov    di,ax
    2057:	8e c2                	mov    es,dx
    2059:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    205c:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    205f:	bf 45 1e             	mov    di,0x1e45
    2062:	0e                   	push   cs
    2063:	57                   	push   di
    2064:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2067:	06                   	push   es
    2068:	57                   	push   di
    2069:	9a f9 60 7a 20       	call   0x207a:0x60f9
    206e:	eb 43                	jmp    0x20b3
    2070:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2073:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2076:	bf c8 07             	mov    di,0x7c8
    2079:	b8 91 20             	mov    ax,0x2091
    207c:	50                   	push   ax
    207d:	57                   	push   di
    207e:	9a 55 22 98 20       	call   0x2098:0x2255
    2083:	08 c0                	or     al,al
    2085:	74 2c                	je     0x20b3
    2087:	ff 76 fe             	push   WORD PTR [bp-0x2]
    208a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    208d:	bf c8 07             	mov    di,0x7c8
    2090:	b8 b1 20             	mov    ax,0x20b1
    2093:	50                   	push   ax
    2094:	57                   	push   di
    2095:	9a 73 22 c4 20       	call   0x20c4:0x2273
    209a:	89 c7                	mov    di,ax
    209c:	8e c2                	mov    es,dx
    209e:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    20a1:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    20a4:	bf 4b 1e             	mov    di,0x1e4b
    20a7:	0e                   	push   cs
    20a8:	57                   	push   di
    20a9:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    20ac:	06                   	push   es
    20ad:	57                   	push   di
    20ae:	9a f9 60 be 22       	call   0x22be:0x60f9
    20b3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20b6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20b9:	bf 26 06             	mov    di,0x626
    20bc:	b8 d1 20             	mov    ax,0x20d1
    20bf:	50                   	push   ax
    20c0:	57                   	push   di
    20c1:	9a 55 22 d8 20       	call   0x20d8:0x2255
    20c6:	50                   	push   ax
    20c7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20ca:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20cd:	bf a2 0b             	mov    di,0xba2
    20d0:	b8 e5 20             	mov    ax,0x20e5
    20d3:	50                   	push   ax
    20d4:	57                   	push   di
    20d5:	9a 55 22 ec 20       	call   0x20ec:0x2255
    20da:	50                   	push   ax
    20db:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20de:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20e1:	bf 22 00             	mov    di,0x22
    20e4:	b8 52 21             	mov    ax,0x2152
    20e7:	50                   	push   ax
    20e8:	57                   	push   di
    20e9:	9a 55 22 09 21       	call   0x2109:0x2255
    20ee:	5a                   	pop    dx
    20ef:	0a c2                	or     al,dl
    20f1:	5a                   	pop    dx
    20f2:	0a c2                	or     al,dl
    20f4:	08 c0                	or     al,al
    20f6:	74 50                	je     0x2148
    20f8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20fb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20fe:	bf da 05             	mov    di,0x5da
    2101:	b8 c5 2b             	mov    ax,0x2bc5
    2104:	50                   	push   ax
    2105:	57                   	push   di
    2106:	9a 73 22 2d 21       	call   0x212d:0x2273
    210b:	89 c7                	mov    di,ax
    210d:	8e c2                	mov    es,dx
    210f:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2112:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2115:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2119:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    211d:	09 d2                	or     dx,dx
    211f:	79 07                	jns    0x2128
    2121:	f7 d2                	not    dx
    2123:	f7 d8                	neg    ax
    2125:	83 da ff             	sbb    dx,0xffff
    2128:	71 05                	jno    0x212f
    212a:	9a 3e 04 3b 21       	call   0x213b:0x43e
    212f:	f7 d2                	not    dx
    2131:	f7 d8                	neg    ax
    2133:	83 da ff             	sbb    dx,0xffff
    2136:	71 05                	jno    0x213d
    2138:	9a 3e 04 59 21       	call   0x2159:0x43e
    213d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2140:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2144:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    2148:	ff 76 0c             	push   WORD PTR [bp+0xc]
    214b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    214e:	bf 22 00             	mov    di,0x22
    2151:	b8 69 21             	mov    ax,0x2169
    2154:	50                   	push   ax
    2155:	57                   	push   di
    2156:	9a 55 22 70 21       	call   0x2170:0x2255
    215b:	08 c0                	or     al,al
    215d:	74 34                	je     0x2193
    215f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2162:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2165:	bf 22 00             	mov    di,0x22
    2168:	b8 9d 21             	mov    ax,0x219d
    216b:	50                   	push   ax
    216c:	57                   	push   di
    216d:	9a 73 22 a4 21       	call   0x21a4:0x2273
    2172:	89 c7                	mov    di,ax
    2174:	8e c2                	mov    es,dx
    2176:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2179:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    217c:	6a ff                	push   0xffff
    217e:	6a fa                	push   0xfffa
    2180:	06                   	push   es
    2181:	57                   	push   di
    2182:	9a d5 1e d0 21       	call   0x21d0:0x1ed5
    2187:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    218a:	06                   	push   es
    218b:	57                   	push   di
    218c:	9a 3f 4a da 21       	call   0x21da:0x4a3f
    2191:	eb 49                	jmp    0x21dc
    2193:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2196:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2199:	bf a2 0b             	mov    di,0xba2
    219c:	b8 b4 21             	mov    ax,0x21b4
    219f:	50                   	push   ax
    21a0:	57                   	push   di
    21a1:	9a 55 22 bb 21       	call   0x21bb:0x2255
    21a6:	08 c0                	or     al,al
    21a8:	74 32                	je     0x21dc
    21aa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    21ad:	ff 76 0a             	push   WORD PTR [bp+0xa]
    21b0:	bf a2 0b             	mov    di,0xba2
    21b3:	b8 2d 22             	mov    ax,0x222d
    21b6:	50                   	push   ax
    21b7:	57                   	push   di
    21b8:	9a 73 22 ea 21       	call   0x21ea:0x2273
    21bd:	89 c7                	mov    di,ax
    21bf:	8e c2                	mov    es,dx
    21c1:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    21c4:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    21c7:	6a ff                	push   0xffff
    21c9:	6a fa                	push   0xfffa
    21cb:	06                   	push   es
    21cc:	57                   	push   di
    21cd:	9a d5 1e ff 21       	call   0x21ff:0x1ed5
    21d2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    21d5:	06                   	push   es
    21d6:	57                   	push   di
    21d7:	9a e7 5b d5 37       	call   0x37d5:0x5be7
    21dc:	c9                   	leave
    21dd:	ca 08 00             	retf   0x8
    21e0:	00 55 89             	add    BYTE PTR [di-0x77],dl
    21e3:	e5 b8                	in     ax,0xb8
    21e5:	08 02                	or     BYTE PTR [bp+si],al
    21e7:	9a 44 04 34 22       	call   0x2234:0x444
    21ec:	81 ec 08 02          	sub    sp,0x208
    21f0:	6a 00                	push   0x0
    21f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21f5:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    21fa:	06                   	push   es
    21fb:	57                   	push   di
    21fc:	9a 77 1c 13 22       	call   0x2213:0x1c77
    2201:	bf e0 21             	mov    di,0x21e0
    2204:	0e                   	push   cs
    2205:	57                   	push   di
    2206:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2209:	26 c4 bd bc 03       	les    di,DWORD PTR es:[di+0x3bc]
    220e:	06                   	push   es
    220f:	57                   	push   di
    2210:	9a 8c 1d 2d 24       	call   0x242d:0x1d8c
    2215:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2218:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    221e:	75 03                	jne    0x2223
    2220:	e9 9e 03             	jmp    0x25c1
    2223:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2226:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2229:	bf 22 00             	mov    di,0x22
    222c:	b8 47 22             	mov    ax,0x2247
    222f:	50                   	push   ax
    2230:	57                   	push   di
    2231:	9a 55 22 4e 22       	call   0x224e:0x2255
    2236:	08 c0                	or     al,al
    2238:	75 03                	jne    0x223d
    223a:	e9 9d 01             	jmp    0x23da
    223d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2240:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2243:	bf 22 00             	mov    di,0x22
    2246:	b8 5f 22             	mov    ax,0x225f
    2249:	50                   	push   ax
    224a:	57                   	push   di
    224b:	9a 73 22 c5 22       	call   0x22c5:0x2273
    2250:	89 c7                	mov    di,ax
    2252:	8e c2                	mov    es,dx
    2254:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2257:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    225a:	06                   	push   es
    225b:	57                   	push   di
    225c:	9a e4 1a 93 22       	call   0x2293:0x1ae4
    2261:	08 c0                	or     al,al
    2263:	74 03                	je     0x2268
    2265:	e9 72 01             	jmp    0x23da
    2268:	8d be f8 fe          	lea    di,[bp-0x108]
    226c:	16                   	push   ss
    226d:	57                   	push   di
    226e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2271:	06                   	push   es
    2272:	57                   	push   di
    2273:	9a d8 14 50 26       	call   0x2650:0x14d8
    2278:	83 c4 04             	add    sp,0x4
    227b:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    2280:	74 03                	je     0x2285
    2282:	e9 36 01             	jmp    0x23bb
    2285:	8d be f8 fd          	lea    di,[bp-0x208]
    2289:	16                   	push   ss
    228a:	57                   	push   di
    228b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    228e:	06                   	push   es
    228f:	57                   	push   di
    2290:	9a 9f 1a 9d 22       	call   0x229d:0x1a9f
    2295:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2298:	06                   	push   es
    2299:	57                   	push   di
    229a:	9a 5f 1a fe 22       	call   0x22fe:0x1a5f
    229f:	89 c7                	mov    di,ax
    22a1:	8e c2                	mov    es,dx
    22a3:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    22a7:	06                   	push   es
    22a8:	57                   	push   di
    22a9:	9a 9b 3b 63 24       	call   0x2463:0x3b9b
    22ae:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    22b1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    22b4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    22b7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    22ba:	bf 58 0a             	mov    di,0xa58
    22bd:	b8 d5 22             	mov    ax,0x22d5
    22c0:	50                   	push   ax
    22c1:	57                   	push   di
    22c2:	9a 55 22 dc 22       	call   0x22dc:0x2255
    22c7:	08 c0                	or     al,al
    22c9:	74 45                	je     0x2310
    22cb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    22ce:	ff 76 fc             	push   WORD PTR [bp-0x4]
    22d1:	bf 58 0a             	mov    di,0xa58
    22d4:	b8 1a 23             	mov    ax,0x231a
    22d7:	50                   	push   ax
    22d8:	57                   	push   di
    22d9:	9a 73 22 21 23       	call   0x2321:0x2273
    22de:	89 c7                	mov    di,ax
    22e0:	8e c2                	mov    es,dx
    22e2:	06                   	push   es
    22e3:	57                   	push   di
    22e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22e7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    22eb:	83 ec 08             	sub    sp,0x8
    22ee:	89 e3                	mov    bx,sp
    22f0:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    22f4:	90                   	nop
    22f5:	9b                   	fwait
    22f6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    22f9:	06                   	push   es
    22fa:	57                   	push   di
    22fb:	9a 18 1b 5a 23       	call   0x235a:0x1b18
    2300:	89 c7                	mov    di,ax
    2302:	8e c2                	mov    es,dx
    2304:	06                   	push   es
    2305:	57                   	push   di
    2306:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2309:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    230d:	e9 ab 00             	jmp    0x23bb
    2310:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2313:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2316:	bf 67 0c             	mov    di,0xc67
    2319:	b8 31 23             	mov    ax,0x2331
    231c:	50                   	push   ax
    231d:	57                   	push   di
    231e:	9a 55 22 38 23       	call   0x2338:0x2255
    2323:	08 c0                	or     al,al
    2325:	74 44                	je     0x236b
    2327:	ff 76 fe             	push   WORD PTR [bp-0x2]
    232a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    232d:	bf 67 0c             	mov    di,0xc67
    2330:	b8 75 23             	mov    ax,0x2375
    2333:	50                   	push   ax
    2334:	57                   	push   di
    2335:	9a 73 22 7c 23       	call   0x237c:0x2273
    233a:	89 c7                	mov    di,ax
    233c:	8e c2                	mov    es,dx
    233e:	06                   	push   es
    233f:	57                   	push   di
    2340:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2343:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2347:	83 ec 08             	sub    sp,0x8
    234a:	89 e3                	mov    bx,sp
    234c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2350:	90                   	nop
    2351:	9b                   	fwait
    2352:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2355:	06                   	push   es
    2356:	57                   	push   di
    2357:	9a 18 1b ac 23       	call   0x23ac:0x1b18
    235c:	89 c7                	mov    di,ax
    235e:	8e c2                	mov    es,dx
    2360:	06                   	push   es
    2361:	57                   	push   di
    2362:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2365:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2369:	eb 50                	jmp    0x23bb
    236b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    236e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2371:	bf c8 07             	mov    di,0x7c8
    2374:	b8 8c 23             	mov    ax,0x238c
    2377:	50                   	push   ax
    2378:	57                   	push   di
    2379:	9a 55 22 93 23       	call   0x2393:0x2255
    237e:	08 c0                	or     al,al
    2380:	74 39                	je     0x23bb
    2382:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2385:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2388:	bf c8 07             	mov    di,0x7c8
    238b:	b8 75 24             	mov    ax,0x2475
    238e:	50                   	push   ax
    238f:	57                   	push   di
    2390:	9a 73 22 cc 23       	call   0x23cc:0x2273
    2395:	89 c7                	mov    di,ax
    2397:	8e c2                	mov    es,dx
    2399:	06                   	push   es
    239a:	57                   	push   di
    239b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    239e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    23a2:	52                   	push   dx
    23a3:	50                   	push   ax
    23a4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23a7:	06                   	push   es
    23a8:	57                   	push   di
    23a9:	9a 18 1b c5 23       	call   0x23c5:0x1b18
    23ae:	89 c7                	mov    di,ax
    23b0:	8e c2                	mov    es,dx
    23b2:	06                   	push   es
    23b3:	57                   	push   di
    23b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23b7:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    23bb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23be:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23c1:	bf 22 00             	mov    di,0x22
    23c4:	b8 e4 23             	mov    ax,0x23e4
    23c7:	50                   	push   ax
    23c8:	57                   	push   di
    23c9:	9a 73 22 eb 23       	call   0x23eb:0x2273
    23ce:	52                   	push   dx
    23cf:	50                   	push   ax
    23d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d3:	06                   	push   es
    23d4:	57                   	push   di
    23d5:	9a c4 19 c9 25       	call   0x25c9:0x19c4
    23da:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23dd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23e0:	bf a2 0b             	mov    di,0xba2
    23e3:	b8 fe 23             	mov    ax,0x23fe
    23e6:	50                   	push   ax
    23e7:	57                   	push   di
    23e8:	9a 55 22 05 24       	call   0x2405:0x2255
    23ed:	08 c0                	or     al,al
    23ef:	75 03                	jne    0x23f4
    23f1:	e9 7e 01             	jmp    0x2572
    23f4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23f7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23fa:	bf a2 0b             	mov    di,0xba2
    23fd:	b8 16 24             	mov    ax,0x2416
    2400:	50                   	push   ax
    2401:	57                   	push   di
    2402:	9a 73 22 7c 24       	call   0x247c:0x2273
    2407:	89 c7                	mov    di,ax
    2409:	8e c2                	mov    es,dx
    240b:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    240e:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2411:	06                   	push   es
    2412:	57                   	push   di
    2413:	9a d7 2a 4a 24       	call   0x244a:0x2ad7
    2418:	08 c0                	or     al,al
    241a:	74 03                	je     0x241f
    241c:	e9 53 01             	jmp    0x2572
    241f:	8d be f8 fe          	lea    di,[bp-0x108]
    2423:	16                   	push   ss
    2424:	57                   	push   di
    2425:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2428:	06                   	push   es
    2429:	57                   	push   di
    242a:	9a 53 1d f6 25       	call   0x25f6:0x1d53
    242f:	83 c4 04             	add    sp,0x4
    2432:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    2437:	74 03                	je     0x243c
    2439:	e9 36 01             	jmp    0x2572
    243c:	8d be f8 fd          	lea    di,[bp-0x208]
    2440:	16                   	push   ss
    2441:	57                   	push   di
    2442:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2445:	06                   	push   es
    2446:	57                   	push   di
    2447:	9a 92 2a 54 24       	call   0x2454:0x2a92
    244c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    244f:	06                   	push   es
    2450:	57                   	push   di
    2451:	9a 52 2a b5 24       	call   0x24b5:0x2a52
    2456:	89 c7                	mov    di,ax
    2458:	8e c2                	mov    es,dx
    245a:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    245e:	06                   	push   es
    245f:	57                   	push   di
    2460:	9a 9b 3b 62 27       	call   0x2762:0x3b9b
    2465:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2468:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    246b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    246e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2471:	bf 58 0a             	mov    di,0xa58
    2474:	b8 8c 24             	mov    ax,0x248c
    2477:	50                   	push   ax
    2478:	57                   	push   di
    2479:	9a 55 22 93 24       	call   0x2493:0x2255
    247e:	08 c0                	or     al,al
    2480:	74 45                	je     0x24c7
    2482:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2485:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2488:	bf 58 0a             	mov    di,0xa58
    248b:	b8 d1 24             	mov    ax,0x24d1
    248e:	50                   	push   ax
    248f:	57                   	push   di
    2490:	9a 73 22 d8 24       	call   0x24d8:0x2273
    2495:	89 c7                	mov    di,ax
    2497:	8e c2                	mov    es,dx
    2499:	06                   	push   es
    249a:	57                   	push   di
    249b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    249e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    24a2:	83 ec 08             	sub    sp,0x8
    24a5:	89 e3                	mov    bx,sp
    24a7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    24ab:	90                   	nop
    24ac:	9b                   	fwait
    24ad:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    24b0:	06                   	push   es
    24b1:	57                   	push   di
    24b2:	9a 0b 2b 11 25       	call   0x2511:0x2b0b
    24b7:	89 c7                	mov    di,ax
    24b9:	8e c2                	mov    es,dx
    24bb:	06                   	push   es
    24bc:	57                   	push   di
    24bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24c0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    24c4:	e9 ab 00             	jmp    0x2572
    24c7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    24ca:	ff 76 fc             	push   WORD PTR [bp-0x4]
    24cd:	bf 67 0c             	mov    di,0xc67
    24d0:	b8 e8 24             	mov    ax,0x24e8
    24d3:	50                   	push   ax
    24d4:	57                   	push   di
    24d5:	9a 55 22 ef 24       	call   0x24ef:0x2255
    24da:	08 c0                	or     al,al
    24dc:	74 44                	je     0x2522
    24de:	ff 76 fe             	push   WORD PTR [bp-0x2]
    24e1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    24e4:	bf 67 0c             	mov    di,0xc67
    24e7:	b8 2c 25             	mov    ax,0x252c
    24ea:	50                   	push   ax
    24eb:	57                   	push   di
    24ec:	9a 73 22 33 25       	call   0x2533:0x2273
    24f1:	89 c7                	mov    di,ax
    24f3:	8e c2                	mov    es,dx
    24f5:	06                   	push   es
    24f6:	57                   	push   di
    24f7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24fa:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    24fe:	83 ec 08             	sub    sp,0x8
    2501:	89 e3                	mov    bx,sp
    2503:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2507:	90                   	nop
    2508:	9b                   	fwait
    2509:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    250c:	06                   	push   es
    250d:	57                   	push   di
    250e:	9a 0b 2b 63 25       	call   0x2563:0x2b0b
    2513:	89 c7                	mov    di,ax
    2515:	8e c2                	mov    es,dx
    2517:	06                   	push   es
    2518:	57                   	push   di
    2519:	26 c4 3d             	les    di,DWORD PTR es:[di]
    251c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2520:	eb 50                	jmp    0x2572
    2522:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2525:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2528:	bf c8 07             	mov    di,0x7c8
    252b:	b8 43 25             	mov    ax,0x2543
    252e:	50                   	push   ax
    252f:	57                   	push   di
    2530:	9a 55 22 4a 25       	call   0x254a:0x2255
    2535:	08 c0                	or     al,al
    2537:	74 39                	je     0x2572
    2539:	ff 76 fe             	push   WORD PTR [bp-0x2]
    253c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    253f:	bf c8 07             	mov    di,0x7c8
    2542:	b8 74 27             	mov    ax,0x2774
    2545:	50                   	push   ax
    2546:	57                   	push   di
    2547:	9a 73 22 83 25       	call   0x2583:0x2273
    254c:	89 c7                	mov    di,ax
    254e:	8e c2                	mov    es,dx
    2550:	06                   	push   es
    2551:	57                   	push   di
    2552:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2555:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2559:	52                   	push   dx
    255a:	50                   	push   ax
    255b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    255e:	06                   	push   es
    255f:	57                   	push   di
    2560:	9a 0b 2b 0d 26       	call   0x260d:0x2b0b
    2565:	89 c7                	mov    di,ax
    2567:	8e c2                	mov    es,dx
    2569:	06                   	push   es
    256a:	57                   	push   di
    256b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    256e:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    2572:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2575:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2578:	bf eb 03             	mov    di,0x3eb
    257b:	b8 93 25             	mov    ax,0x2593
    257e:	50                   	push   ax
    257f:	57                   	push   di
    2580:	9a 55 22 9a 25       	call   0x259a:0x2255
    2585:	08 c0                	or     al,al
    2587:	74 38                	je     0x25c1
    2589:	ff 76 0c             	push   WORD PTR [bp+0xc]
    258c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    258f:	bf eb 03             	mov    di,0x3eb
    2592:	b8 b3 25             	mov    ax,0x25b3
    2595:	50                   	push   ax
    2596:	57                   	push   di
    2597:	9a 73 22 d8 25       	call   0x25d8:0x2273
    259c:	89 c7                	mov    di,ax
    259e:	8e c2                	mov    es,dx
    25a0:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    25a3:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    25a6:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    25ac:	75 13                	jne    0x25c1
    25ae:	06                   	push   es
    25af:	57                   	push   di
    25b0:	9a 33 17 bf 25       	call   0x25bf:0x1733
    25b5:	52                   	push   dx
    25b6:	50                   	push   ax
    25b7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    25ba:	06                   	push   es
    25bb:	57                   	push   di
    25bc:	9a 8b 17 57 29       	call   0x2957:0x178b
    25c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c4:	06                   	push   es
    25c5:	57                   	push   di
    25c6:	9a 26 37 80 2e       	call   0x2e80:0x3726
    25cb:	c9                   	leave
    25cc:	ca 08 00             	retf   0x8
    25cf:	55                   	push   bp
    25d0:	89 e5                	mov    bp,sp
    25d2:	b8 04 01             	mov    ax,0x104
    25d5:	9a 44 04 14 26       	call   0x2614:0x444
    25da:	81 ec 04 01          	sub    sp,0x104
    25de:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    25e1:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    25e5:	75 13                	jne    0x25fa
    25e7:	6a 00                	push   0x0
    25e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25ec:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    25f1:	06                   	push   es
    25f2:	57                   	push   di
    25f3:	9a 77 1c 5f 26       	call   0x265f:0x1c77
    25f8:	eb 67                	jmp    0x2661
    25fa:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    25fd:	26 83 3d 09          	cmp    WORD PTR es:[di],0x9
    2601:	74 5e                	je     0x2661
    2603:	ff 76 12             	push   WORD PTR [bp+0x12]
    2606:	ff 76 10             	push   WORD PTR [bp+0x10]
    2609:	bf 22 00             	mov    di,0x22
    260c:	b8 24 26             	mov    ax,0x2624
    260f:	50                   	push   ax
    2610:	57                   	push   di
    2611:	9a 55 22 2b 26       	call   0x262b:0x2255
    2616:	08 c0                	or     al,al
    2618:	74 47                	je     0x2661
    261a:	ff 76 12             	push   WORD PTR [bp+0x12]
    261d:	ff 76 10             	push   WORD PTR [bp+0x10]
    2620:	bf 22 00             	mov    di,0x22
    2623:	b8 3c 26             	mov    ax,0x263c
    2626:	50                   	push   ax
    2627:	57                   	push   di
    2628:	9a 73 22 81 26       	call   0x2681:0x2273
    262d:	89 c7                	mov    di,ax
    262f:	8e c2                	mov    es,dx
    2631:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2634:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2637:	06                   	push   es
    2638:	57                   	push   di
    2639:	9a e4 1a 0a 27       	call   0x270a:0x1ae4
    263e:	08 c0                	or     al,al
    2640:	75 1f                	jne    0x2661
    2642:	8d be fc fe          	lea    di,[bp-0x104]
    2646:	16                   	push   ss
    2647:	57                   	push   di
    2648:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    264b:	06                   	push   es
    264c:	57                   	push   di
    264d:	9a 24 15 63 28       	call   0x2863:0x1524
    2652:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2655:	26 c4 bd bc 03       	les    di,DWORD PTR es:[di+0x3bc]
    265a:	06                   	push   es
    265b:	57                   	push   di
    265c:	9a 8c 1d 9a 26       	call   0x269a:0x1d8c
    2661:	c9                   	leave
    2662:	ca 0e 00             	retf   0xe
    2665:	0a 23                	or     ah,BYTE PTR [bp+di]
    2667:	2c 23                	sub    al,0x23
    2669:	23 30                	and    si,WORD PTR [bx+si]
    266b:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    266e:	23 23                	and    sp,WORD PTR [bp+di]
    2670:	05 23 2c             	add    ax,0x2c23
    2673:	23 23                	and    sp,WORD PTR [bp+di]
    2675:	30 01                	xor    BYTE PTR [bx+di],al
    2677:	20 55 89             	and    BYTE PTR [di-0x77],dl
    267a:	e5 b8                	in     ax,0xb8
    267c:	14 02                	adc    al,0x2
    267e:	9a 44 04 a1 26       	call   0x26a1:0x444
    2683:	81 ec 14 02          	sub    sp,0x214
    2687:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    268a:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    268e:	75 4d                	jne    0x26dd
    2690:	ff 76 12             	push   WORD PTR [bp+0x12]
    2693:	ff 76 10             	push   WORD PTR [bp+0x10]
    2696:	bf c1 05             	mov    di,0x5c1
    2699:	b8 bb 26             	mov    ax,0x26bb
    269c:	50                   	push   ax
    269d:	57                   	push   di
    269e:	9a 55 22 c2 26       	call   0x26c2:0x2255
    26a3:	08 c0                	or     al,al
    26a5:	74 36                	je     0x26dd
    26a7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    26aa:	31 c0                	xor    ax,ax
    26ac:	26 89 05             	mov    WORD PTR es:[di],ax
    26af:	6a 08                	push   0x8
    26b1:	ff 76 12             	push   WORD PTR [bp+0x12]
    26b4:	ff 76 10             	push   WORD PTR [bp+0x10]
    26b7:	bf c1 05             	mov    di,0x5c1
    26ba:	b8 ac 28             	mov    ax,0x28ac
    26bd:	50                   	push   ax
    26be:	57                   	push   di
    26bf:	9a 73 22 11 27       	call   0x2711:0x2273
    26c4:	89 c7                	mov    di,ax
    26c6:	8e c2                	mov    es,dx
    26c8:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    26cd:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    26d2:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    26d6:	06                   	push   es
    26d7:	57                   	push   di
    26d8:	9a b2 77 33 2a       	call   0x2a33:0x77b2
    26dd:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    26e0:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    26e4:	74 03                	je     0x26e9
    26e6:	e9 ba 04             	jmp    0x2ba3
    26e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ec:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    26f1:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    26f6:	74 03                	je     0x26fb
    26f8:	e9 a8 04             	jmp    0x2ba3
    26fb:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    2700:	ff 76 12             	push   WORD PTR [bp+0x12]
    2703:	ff 76 10             	push   WORD PTR [bp+0x10]
    2706:	bf 22 00             	mov    di,0x22
    2709:	b8 24 27             	mov    ax,0x2724
    270c:	50                   	push   ax
    270d:	57                   	push   di
    270e:	9a 55 22 2b 27       	call   0x272b:0x2255
    2713:	08 c0                	or     al,al
    2715:	75 03                	jne    0x271a
    2717:	e9 9a 01             	jmp    0x28b4
    271a:	ff 76 12             	push   WORD PTR [bp+0x12]
    271d:	ff 76 10             	push   WORD PTR [bp+0x10]
    2720:	bf 22 00             	mov    di,0x22
    2723:	b8 48 27             	mov    ax,0x2748
    2726:	50                   	push   ax
    2727:	57                   	push   di
    2728:	9a 73 22 7b 27       	call   0x277b:0x2273
    272d:	89 c7                	mov    di,ax
    272f:	8e c2                	mov    es,dx
    2731:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2735:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2739:	8d be f4 fd          	lea    di,[bp-0x20c]
    273d:	16                   	push   ss
    273e:	57                   	push   di
    273f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2743:	06                   	push   es
    2744:	57                   	push   di
    2745:	9a 9f 1a 53 27       	call   0x2753:0x1a9f
    274a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    274e:	06                   	push   es
    274f:	57                   	push   di
    2750:	9a 5f 1a be 28       	call   0x28be:0x1a5f
    2755:	89 c7                	mov    di,ax
    2757:	8e c2                	mov    es,dx
    2759:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    275d:	06                   	push   es
    275e:	57                   	push   di
    275f:	9a 9b 3b 43 30       	call   0x3043:0x3b9b
    2764:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2767:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    276a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    276d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2770:	bf 58 0a             	mov    di,0xa58
    2773:	b8 8b 27             	mov    ax,0x278b
    2776:	50                   	push   ax
    2777:	57                   	push   di
    2778:	9a 55 22 92 27       	call   0x2792:0x2255
    277d:	08 c0                	or     al,al
    277f:	74 58                	je     0x27d9
    2781:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2784:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2787:	bf 58 0a             	mov    di,0xa58
    278a:	b8 e3 27             	mov    ax,0x27e3
    278d:	50                   	push   ax
    278e:	57                   	push   di
    278f:	9a 73 22 d4 27       	call   0x27d4:0x2273
    2794:	89 c7                	mov    di,ax
    2796:	8e c2                	mov    es,dx
    2798:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    279c:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    27a0:	8d be f0 fd          	lea    di,[bp-0x210]
    27a4:	16                   	push   ss
    27a5:	57                   	push   di
    27a6:	bf 65 26             	mov    di,0x2665
    27a9:	0e                   	push   cs
    27aa:	57                   	push   di
    27ab:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    27af:	06                   	push   es
    27b0:	57                   	push   di
    27b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    27b4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    27b8:	83 ec 0a             	sub    sp,0xa
    27bb:	89 e3                	mov    bx,sp
    27bd:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    27c1:	90                   	nop
    27c2:	9b                   	fwait
    27c3:	9a d4 10 42 28       	call   0x2842:0x10d4
    27c8:	8d be f8 fe          	lea    di,[bp-0x108]
    27cc:	16                   	push   ss
    27cd:	57                   	push   di
    27ce:	68 ff 00             	push   0xff
    27d1:	9a e7 17 ea 27       	call   0x27ea:0x17e7
    27d6:	e9 9a 00             	jmp    0x2873
    27d9:	ff 76 fa             	push   WORD PTR [bp-0x6]
    27dc:	ff 76 f8             	push   WORD PTR [bp-0x8]
    27df:	bf c8 07             	mov    di,0x7c8
    27e2:	b8 fa 27             	mov    ax,0x27fa
    27e5:	50                   	push   ax
    27e6:	57                   	push   di
    27e7:	9a 55 22 01 28       	call   0x2801:0x2255
    27ec:	08 c0                	or     al,al
    27ee:	74 64                	je     0x2854
    27f0:	ff 76 fa             	push   WORD PTR [bp-0x6]
    27f3:	ff 76 f8             	push   WORD PTR [bp-0x8]
    27f6:	bf c8 07             	mov    di,0x7c8
    27f9:	b8 41 31             	mov    ax,0x3141
    27fc:	50                   	push   ax
    27fd:	57                   	push   di
    27fe:	9a 73 22 50 28       	call   0x2850:0x2273
    2803:	89 c7                	mov    di,ax
    2805:	8e c2                	mov    es,dx
    2807:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    280b:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    280f:	8d be ec fd          	lea    di,[bp-0x214]
    2813:	16                   	push   ss
    2814:	57                   	push   di
    2815:	bf 70 26             	mov    di,0x2670
    2818:	0e                   	push   cs
    2819:	57                   	push   di
    281a:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    281e:	06                   	push   es
    281f:	57                   	push   di
    2820:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2823:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2827:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    282b:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    282f:	9b db 86 ec fe       	fild   DWORD PTR [bp-0x114]
    2834:	83 ec 0a             	sub    sp,0xa
    2837:	89 e3                	mov    bx,sp
    2839:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    283d:	90                   	nop
    283e:	9b                   	fwait
    283f:	9a d4 10 9c 29       	call   0x299c:0x10d4
    2844:	8d be f8 fe          	lea    di,[bp-0x108]
    2848:	16                   	push   ss
    2849:	57                   	push   di
    284a:	68 ff 00             	push   0xff
    284d:	9a e7 17 71 28       	call   0x2871:0x17e7
    2852:	eb 1f                	jmp    0x2873
    2854:	8d be f4 fd          	lea    di,[bp-0x20c]
    2858:	16                   	push   ss
    2859:	57                   	push   di
    285a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    285e:	06                   	push   es
    285f:	57                   	push   di
    2860:	9a 24 15 ff ff       	call   0xffff:0x1524
    2865:	8d be f8 fe          	lea    di,[bp-0x108]
    2869:	16                   	push   ss
    286a:	57                   	push   di
    286b:	68 ff 00             	push   0xff
    286e:	9a e7 17 83 28       	call   0x2883:0x17e7
    2873:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2877:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    287b:	2d 04 00             	sub    ax,0x4
    287e:	71 05                	jno    0x2885
    2880:	9a 3e 04 98 28       	call   0x2898:0x43e
    2885:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2888:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    288c:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2890:	2d 04 00             	sub    ax,0x4
    2893:	71 05                	jno    0x289a
    2895:	9a 3e 04 c5 28       	call   0x28c5:0x43e
    289a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    289d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    28a0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    28a3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28a7:	06                   	push   es
    28a8:	57                   	push   di
    28a9:	9a d4 19 fc 28       	call   0x28fc:0x19d4
    28ae:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    28b1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    28b4:	ff 76 12             	push   WORD PTR [bp+0x12]
    28b7:	ff 76 10             	push   WORD PTR [bp+0x10]
    28ba:	bf a2 0b             	mov    di,0xba2
    28bd:	b8 d8 28             	mov    ax,0x28d8
    28c0:	50                   	push   ax
    28c1:	57                   	push   di
    28c2:	9a 55 22 df 28       	call   0x28df:0x2255
    28c7:	08 c0                	or     al,al
    28c9:	75 03                	jne    0x28ce
    28cb:	e9 7f 00             	jmp    0x294d
    28ce:	ff 76 12             	push   WORD PTR [bp+0x12]
    28d1:	ff 76 10             	push   WORD PTR [bp+0x10]
    28d4:	bf a2 0b             	mov    di,0xba2
    28d7:	b8 f9 2b             	mov    ax,0x2bf9
    28da:	50                   	push   ax
    28db:	57                   	push   di
    28dc:	9a 73 22 0a 29       	call   0x290a:0x2273
    28e1:	89 c7                	mov    di,ax
    28e3:	8e c2                	mov    es,dx
    28e5:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    28e9:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    28ed:	8d be f4 fd          	lea    di,[bp-0x20c]
    28f1:	16                   	push   ss
    28f2:	57                   	push   di
    28f3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    28f7:	06                   	push   es
    28f8:	57                   	push   di
    28f9:	9a 53 1d 45 29       	call   0x2945:0x1d53
    28fe:	8d be f8 fe          	lea    di,[bp-0x108]
    2902:	16                   	push   ss
    2903:	57                   	push   di
    2904:	68 ff 00             	push   0xff
    2907:	9a e7 17 1c 29       	call   0x291c:0x17e7
    290c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2910:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2914:	2d 04 00             	sub    ax,0x4
    2917:	71 05                	jno    0x291e
    2919:	9a 3e 04 31 29       	call   0x2931:0x43e
    291e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2921:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2925:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2929:	2d 04 00             	sub    ax,0x4
    292c:	71 05                	jno    0x2933
    292e:	9a 3e 04 5e 29       	call   0x295e:0x43e
    2933:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2936:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2939:	ff 76 fc             	push   WORD PTR [bp-0x4]
    293c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2940:	06                   	push   es
    2941:	57                   	push   di
    2942:	9a d4 19 e5 29       	call   0x29e5:0x19d4
    2947:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    294a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    294d:	ff 76 12             	push   WORD PTR [bp+0x12]
    2950:	ff 76 10             	push   WORD PTR [bp+0x10]
    2953:	bf eb 03             	mov    di,0x3eb
    2956:	b8 71 29             	mov    ax,0x2971
    2959:	50                   	push   ax
    295a:	57                   	push   di
    295b:	9a 55 22 78 29       	call   0x2978:0x2255
    2960:	08 c0                	or     al,al
    2962:	75 03                	jne    0x2967
    2964:	e9 86 00             	jmp    0x29ed
    2967:	ff 76 12             	push   WORD PTR [bp+0x12]
    296a:	ff 76 10             	push   WORD PTR [bp+0x10]
    296d:	bf eb 03             	mov    di,0x3eb
    2970:	b8 95 29             	mov    ax,0x2995
    2973:	50                   	push   ax
    2974:	57                   	push   di
    2975:	9a 73 22 aa 29       	call   0x29aa:0x2273
    297a:	89 c7                	mov    di,ax
    297c:	8e c2                	mov    es,dx
    297e:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2982:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2986:	8d be f4 fd          	lea    di,[bp-0x20c]
    298a:	16                   	push   ss
    298b:	57                   	push   di
    298c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2990:	06                   	push   es
    2991:	57                   	push   di
    2992:	9a 33 17 41 69       	call   0x6941:0x1733
    2997:	52                   	push   dx
    2998:	50                   	push   ax
    2999:	9a a9 08 e3 33       	call   0x33e3:0x8a9
    299e:	8d be f8 fe          	lea    di,[bp-0x108]
    29a2:	16                   	push   ss
    29a3:	57                   	push   di
    29a4:	68 ff 00             	push   0xff
    29a7:	9a e7 17 bc 29       	call   0x29bc:0x17e7
    29ac:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    29b0:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    29b4:	2d 04 00             	sub    ax,0x4
    29b7:	71 05                	jno    0x29be
    29b9:	9a 3e 04 d1 29       	call   0x29d1:0x43e
    29be:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    29c1:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    29c5:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    29c9:	2d 04 00             	sub    ax,0x4
    29cc:	71 05                	jno    0x29d3
    29ce:	9a 3e 04 05 2a       	call   0x2a05:0x43e
    29d3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    29d6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29d9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    29dc:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    29e0:	06                   	push   es
    29e1:	57                   	push   di
    29e2:	9a d4 19 29 2a       	call   0x2a29:0x19d4
    29e7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    29ea:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    29ed:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    29f2:	77 03                	ja     0x29f7
    29f4:	e9 ac 01             	jmp    0x2ba3
    29f7:	8d be f8 fd          	lea    di,[bp-0x208]
    29fb:	16                   	push   ss
    29fc:	57                   	push   di
    29fd:	bf 76 26             	mov    di,0x2676
    2a00:	0e                   	push   cs
    2a01:	57                   	push   di
    2a02:	9a cd 17 10 2a       	call   0x2a10:0x17cd
    2a07:	8d be f8 fe          	lea    di,[bp-0x108]
    2a0b:	16                   	push   ss
    2a0c:	57                   	push   di
    2a0d:	9a 4c 18 1a 2a       	call   0x2a1a:0x184c
    2a12:	bf 76 26             	mov    di,0x2676
    2a15:	0e                   	push   cs
    2a16:	57                   	push   di
    2a17:	9a 4c 18 b6 2a       	call   0x2ab6:0x184c
    2a1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a1f:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2a24:	06                   	push   es
    2a25:	57                   	push   di
    2a26:	9a 8c 1d 6f 2a       	call   0x2a6f:0x1d8c
    2a2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a2e:	06                   	push   es
    2a2f:	57                   	push   di
    2a30:	9a d5 33 0b 37       	call   0x370b:0x33d5
    2a35:	89 c7                	mov    di,ax
    2a37:	8e c2                	mov    es,dx
    2a39:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2a3d:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2a41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a44:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2a49:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2a4d:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2a51:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2a55:	06                   	push   es
    2a56:	57                   	push   di
    2a57:	9a 99 20 7a 2a       	call   0x2a7a:0x2099
    2a5c:	8d be f4 fd          	lea    di,[bp-0x20c]
    2a60:	16                   	push   ss
    2a61:	57                   	push   di
    2a62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a65:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2a6a:	06                   	push   es
    2a6b:	57                   	push   di
    2a6c:	9a 53 1d 8a 2a       	call   0x2a8a:0x1d53
    2a71:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2a75:	06                   	push   es
    2a76:	57                   	push   di
    2a77:	9a 03 20 aa 2a       	call   0x2aaa:0x2003
    2a7c:	50                   	push   ax
    2a7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a80:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2a85:	06                   	push   es
    2a86:	57                   	push   di
    2a87:	9a bf 17 9f 2a       	call   0x2a9f:0x17bf
    2a8c:	8d be f4 fd          	lea    di,[bp-0x20c]
    2a90:	16                   	push   ss
    2a91:	57                   	push   di
    2a92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a95:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2a9a:	06                   	push   es
    2a9b:	57                   	push   di
    2a9c:	9a 53 1d cc 2a       	call   0x2acc:0x1d53
    2aa1:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2aa5:	06                   	push   es
    2aa6:	57                   	push   di
    2aa7:	9a 4e 20 b6 62       	call   0x62b6:0x204e
    2aac:	b9 03 00             	mov    cx,0x3
    2aaf:	f7 e9                	imul   cx
    2ab1:	71 05                	jno    0x2ab8
    2ab3:	9a 3e 04 29 2b       	call   0x2b29:0x43e
    2ab8:	99                   	cwd
    2ab9:	b9 02 00             	mov    cx,0x2
    2abc:	f7 f9                	idiv   cx
    2abe:	50                   	push   ax
    2abf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac2:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2ac7:	06                   	push   es
    2ac8:	57                   	push   di
    2ac9:	9a e1 17 dc 2a       	call   0x2adc:0x17e1
    2ace:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ad1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2ad4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad7:	06                   	push   es
    2ad8:	57                   	push   di
    2ad9:	9a 06 1a fc 2a       	call   0x2afc:0x1a06
    2ade:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2ae1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2ae4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae7:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2aec:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2af0:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2af4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2af7:	06                   	push   es
    2af8:	57                   	push   di
    2af9:	9a 7b 17 0a 2b       	call   0x2b0a:0x177b
    2afe:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2b01:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b05:	06                   	push   es
    2b06:	57                   	push   di
    2b07:	9a 9d 17 14 2b       	call   0x2b14:0x179d
    2b0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b0f:	06                   	push   es
    2b10:	57                   	push   di
    2b11:	9a a9 18 4b 2b       	call   0x2b4b:0x18a9
    2b16:	8b d0                	mov    dx,ax
    2b18:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b1c:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2b20:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    2b24:	71 05                	jno    0x2b2b
    2b26:	9a 3e 04 3f 2b       	call   0x2b3f:0x43e
    2b2b:	3b c2                	cmp    ax,dx
    2b2d:	7e 20                	jle    0x2b4f
    2b2f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b33:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2b37:	2d 08 00             	sub    ax,0x8
    2b3a:	71 05                	jno    0x2b41
    2b3c:	9a 3e 04 6c 2b       	call   0x2b6c:0x43e
    2b41:	50                   	push   ax
    2b42:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b46:	06                   	push   es
    2b47:	57                   	push   di
    2b48:	9a 7b 17 57 2b       	call   0x2b57:0x177b
    2b4d:	eb bd                	jmp    0x2b0c
    2b4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b52:	06                   	push   es
    2b53:	57                   	push   di
    2b54:	9a f4 18 8e 2b       	call   0x2b8e:0x18f4
    2b59:	8b d0                	mov    dx,ax
    2b5b:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b5f:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2b63:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    2b67:	71 05                	jno    0x2b6e
    2b69:	9a 3e 04 82 2b       	call   0x2b82:0x43e
    2b6e:	3b c2                	cmp    ax,dx
    2b70:	7e 20                	jle    0x2b92
    2b72:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b76:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2b7a:	2d 08 00             	sub    ax,0x8
    2b7d:	71 05                	jno    0x2b84
    2b7f:	9a 3e 04 b8 2b       	call   0x2bb8:0x43e
    2b84:	50                   	push   ax
    2b85:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2b89:	06                   	push   es
    2b8a:	57                   	push   di
    2b8b:	9a 9d 17 a1 2b       	call   0x2ba1:0x179d
    2b90:	eb bd                	jmp    0x2b4f
    2b92:	6a 01                	push   0x1
    2b94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b97:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    2b9c:	06                   	push   es
    2b9d:	57                   	push   di
    2b9e:	9a 77 1c 44 2c       	call   0x2c44:0x1c77
    2ba3:	c9                   	leave
    2ba4:	ca 0e 00             	retf   0xe
    2ba7:	eb ff                	jmp    0x2ba8
    2ba9:	ff                   	(bad)
    2baa:	ff                   	(bad)
    2bab:	ff                   	(bad)
    2bac:	ff                   	(bad)
    2bad:	ff 02                	inc    WORD PTR [bp+si]
    2baf:	55                   	push   bp
    2bb0:	89 e5                	mov    bp,sp
    2bb2:	b8 08 00             	mov    ax,0x8
    2bb5:	9a 44 04 cf 2b       	call   0x2bcf:0x444
    2bba:	83 ec 08             	sub    sp,0x8
    2bbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bc0:	06                   	push   es
    2bc1:	57                   	push   di
    2bc2:	9a 7d 52 f1 2b       	call   0x2bf1:0x527d
    2bc7:	2d 01 00             	sub    ax,0x1
    2bca:	71 05                	jno    0x2bd1
    2bcc:	9a 3e 04 00 2c       	call   0x2c00:0x43e
    2bd1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2bd4:	31 c0                	xor    ax,ax
    2bd6:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2bd9:	7e 03                	jle    0x2bde
    2bdb:	e9 d5 00             	jmp    0x2cb3
    2bde:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2be1:	eb 03                	jmp    0x2be6
    2be3:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2be6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2be9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bec:	06                   	push   es
    2bed:	57                   	push   di
    2bee:	9a 46 52 11 2c       	call   0x2c11:0x5246
    2bf3:	52                   	push   dx
    2bf4:	50                   	push   ax
    2bf5:	bf 22 00             	mov    di,0x22
    2bf8:	b8 19 2c             	mov    ax,0x2c19
    2bfb:	50                   	push   ax
    2bfc:	57                   	push   di
    2bfd:	9a 55 22 20 2c       	call   0x2c20:0x2255
    2c02:	08 c0                	or     al,al
    2c04:	74 42                	je     0x2c48
    2c06:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2c09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c0c:	06                   	push   es
    2c0d:	57                   	push   di
    2c0e:	9a 46 52 53 2c       	call   0x2c53:0x5246
    2c13:	52                   	push   dx
    2c14:	50                   	push   ax
    2c15:	bf 22 00             	mov    di,0x22
    2c18:	b8 5b 2c             	mov    ax,0x2c5b
    2c1b:	50                   	push   ax
    2c1c:	57                   	push   di
    2c1d:	9a 73 22 38 2c       	call   0x2c38:0x2273
    2c22:	89 c7                	mov    di,ax
    2c24:	8e c2                	mov    es,dx
    2c26:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2c29:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2c2c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2c2f:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2c32:	bf a7 2b             	mov    di,0x2ba7
    2c35:	9a 16 04 62 2c       	call   0x2c62:0x416
    2c3a:	52                   	push   dx
    2c3b:	50                   	push   ax
    2c3c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2c3f:	06                   	push   es
    2c40:	57                   	push   di
    2c41:	9a d5 1e a6 2c       	call   0x2ca6:0x1ed5
    2c46:	eb 60                	jmp    0x2ca8
    2c48:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2c4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c4e:	06                   	push   es
    2c4f:	57                   	push   di
    2c50:	9a 46 52 73 2c       	call   0x2c73:0x5246
    2c55:	52                   	push   dx
    2c56:	50                   	push   ax
    2c57:	bf a2 0b             	mov    di,0xba2
    2c5a:	b8 7b 2c             	mov    ax,0x2c7b
    2c5d:	50                   	push   ax
    2c5e:	57                   	push   di
    2c5f:	9a 55 22 82 2c       	call   0x2c82:0x2255
    2c64:	08 c0                	or     al,al
    2c66:	74 40                	je     0x2ca8
    2c68:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2c6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c6e:	06                   	push   es
    2c6f:	57                   	push   di
    2c70:	9a 46 52 cd 2c       	call   0x2ccd:0x5246
    2c75:	52                   	push   dx
    2c76:	50                   	push   ax
    2c77:	bf a2 0b             	mov    di,0xba2
    2c7a:	b8 01 2d             	mov    ax,0x2d01
    2c7d:	50                   	push   ax
    2c7e:	57                   	push   di
    2c7f:	9a 73 22 9a 2c       	call   0x2c9a:0x2273
    2c84:	89 c7                	mov    di,ax
    2c86:	8e c2                	mov    es,dx
    2c88:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2c8b:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2c8e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2c91:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2c94:	bf a7 2b             	mov    di,0x2ba7
    2c97:	9a 16 04 c0 2c       	call   0x2cc0:0x416
    2c9c:	52                   	push   dx
    2c9d:	50                   	push   ax
    2c9e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2ca1:	06                   	push   es
    2ca2:	57                   	push   di
    2ca3:	9a d5 1e ba 37       	call   0x37ba:0x1ed5
    2ca8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2cab:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2cae:	74 03                	je     0x2cb3
    2cb0:	e9 30 ff             	jmp    0x2be3
    2cb3:	c9                   	leave
    2cb4:	ca 08 00             	retf   0x8
    2cb7:	55                   	push   bp
    2cb8:	89 e5                	mov    bp,sp
    2cba:	b8 04 00             	mov    ax,0x4
    2cbd:	9a 44 04 d7 2c       	call   0x2cd7:0x444
    2cc2:	83 ec 04             	sub    sp,0x4
    2cc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cc8:	06                   	push   es
    2cc9:	57                   	push   di
    2cca:	9a 7d 52 f9 2c       	call   0x2cf9:0x527d
    2ccf:	2d 01 00             	sub    ax,0x1
    2cd2:	71 05                	jno    0x2cd9
    2cd4:	9a 3e 04 08 2d       	call   0x2d08:0x43e
    2cd9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2cdc:	31 c0                	xor    ax,ax
    2cde:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2ce1:	7e 03                	jle    0x2ce6
    2ce3:	e9 1c 01             	jmp    0x2e02
    2ce6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2ce9:	eb 03                	jmp    0x2cee
    2ceb:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2cee:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2cf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cf4:	06                   	push   es
    2cf5:	57                   	push   di
    2cf6:	9a 46 52 16 2d       	call   0x2d16:0x5246
    2cfb:	52                   	push   dx
    2cfc:	50                   	push   ax
    2cfd:	bf 26 06             	mov    di,0x626
    2d00:	b8 1e 2d             	mov    ax,0x2d1e
    2d03:	50                   	push   ax
    2d04:	57                   	push   di
    2d05:	9a 55 22 25 2d       	call   0x2d25:0x2255
    2d0a:	50                   	push   ax
    2d0b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d11:	06                   	push   es
    2d12:	57                   	push   di
    2d13:	9a 46 52 33 2d       	call   0x2d33:0x5246
    2d18:	52                   	push   dx
    2d19:	50                   	push   ax
    2d1a:	bf a2 0b             	mov    di,0xba2
    2d1d:	b8 3b 2d             	mov    ax,0x2d3b
    2d20:	50                   	push   ax
    2d21:	57                   	push   di
    2d22:	9a 55 22 42 2d       	call   0x2d42:0x2255
    2d27:	50                   	push   ax
    2d28:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d2e:	06                   	push   es
    2d2f:	57                   	push   di
    2d30:	9a 46 52 62 2d       	call   0x2d62:0x5246
    2d35:	52                   	push   dx
    2d36:	50                   	push   ax
    2d37:	bf 22 00             	mov    di,0x22
    2d3a:	b8 4d 2e             	mov    ax,0x2e4d
    2d3d:	50                   	push   ax
    2d3e:	57                   	push   di
    2d3f:	9a 55 22 80 2d       	call   0x2d80:0x2255
    2d44:	5a                   	pop    dx
    2d45:	0a c2                	or     al,dl
    2d47:	5a                   	pop    dx
    2d48:	0a c2                	or     al,dl
    2d4a:	08 c0                	or     al,al
    2d4c:	75 03                	jne    0x2d51
    2d4e:	e9 a6 00             	jmp    0x2df7
    2d51:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2d55:	74 58                	je     0x2daf
    2d57:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d5d:	06                   	push   es
    2d5e:	57                   	push   di
    2d5f:	9a 46 52 9d 2d       	call   0x2d9d:0x5246
    2d64:	89 c7                	mov    di,ax
    2d66:	8e c2                	mov    es,dx
    2d68:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2d6c:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    2d70:	09 d2                	or     dx,dx
    2d72:	79 07                	jns    0x2d7b
    2d74:	f7 d2                	not    dx
    2d76:	f7 d8                	neg    ax
    2d78:	83 da ff             	sbb    dx,0xffff
    2d7b:	71 05                	jno    0x2d82
    2d7d:	9a 3e 04 8e 2d       	call   0x2d8e:0x43e
    2d82:	f7 d2                	not    dx
    2d84:	f7 d8                	neg    ax
    2d86:	83 da ff             	sbb    dx,0xffff
    2d89:	71 05                	jno    0x2d90
    2d8b:	9a 3e 04 d8 2d       	call   0x2dd8:0x43e
    2d90:	52                   	push   dx
    2d91:	50                   	push   ax
    2d92:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d98:	06                   	push   es
    2d99:	57                   	push   di
    2d9a:	9a 46 52 ba 2d       	call   0x2dba:0x5246
    2d9f:	89 c7                	mov    di,ax
    2da1:	8e c2                	mov    es,dx
    2da3:	58                   	pop    ax
    2da4:	5a                   	pop    dx
    2da5:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2da9:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    2dad:	eb 48                	jmp    0x2df7
    2daf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2db2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2db5:	06                   	push   es
    2db6:	57                   	push   di
    2db7:	9a 46 52 e7 2d       	call   0x2de7:0x5246
    2dbc:	89 c7                	mov    di,ax
    2dbe:	8e c2                	mov    es,dx
    2dc0:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2dc4:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    2dc8:	09 d2                	or     dx,dx
    2dca:	79 07                	jns    0x2dd3
    2dcc:	f7 d2                	not    dx
    2dce:	f7 d8                	neg    ax
    2dd0:	83 da ff             	sbb    dx,0xffff
    2dd3:	71 05                	jno    0x2dda
    2dd5:	9a 3e 04 0f 2e       	call   0x2e0f:0x43e
    2dda:	52                   	push   dx
    2ddb:	50                   	push   ax
    2ddc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ddf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2de2:	06                   	push   es
    2de3:	57                   	push   di
    2de4:	9a 46 52 1c 2e       	call   0x2e1c:0x5246
    2de9:	89 c7                	mov    di,ax
    2deb:	8e c2                	mov    es,dx
    2ded:	58                   	pop    ax
    2dee:	5a                   	pop    dx
    2def:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2df3:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    2df7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2dfa:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2dfd:	74 03                	je     0x2e02
    2dff:	e9 e9 fe             	jmp    0x2ceb
    2e02:	c9                   	leave
    2e03:	ca 06 00             	retf   0x6
    2e06:	55                   	push   bp
    2e07:	89 e5                	mov    bp,sp
    2e09:	b8 04 00             	mov    ax,0x4
    2e0c:	9a 44 04 26 2e       	call   0x2e26:0x444
    2e11:	83 ec 04             	sub    sp,0x4
    2e14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e17:	06                   	push   es
    2e18:	57                   	push   di
    2e19:	9a 7d 52 45 2e       	call   0x2e45:0x527d
    2e1e:	2d 01 00             	sub    ax,0x1
    2e21:	71 05                	jno    0x2e28
    2e23:	9a 3e 04 54 2e       	call   0x2e54:0x43e
    2e28:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2e2b:	31 c0                	xor    ax,ax
    2e2d:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2e30:	7f 58                	jg     0x2e8a
    2e32:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e35:	eb 03                	jmp    0x2e3a
    2e37:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2e3a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e40:	06                   	push   es
    2e41:	57                   	push   di
    2e42:	9a 46 52 65 2e       	call   0x2e65:0x5246
    2e47:	52                   	push   dx
    2e48:	50                   	push   ax
    2e49:	bf 22 00             	mov    di,0x22
    2e4c:	b8 6d 2e             	mov    ax,0x2e6d
    2e4f:	50                   	push   ax
    2e50:	57                   	push   di
    2e51:	9a 55 22 74 2e       	call   0x2e74:0x2255
    2e56:	08 c0                	or     al,al
    2e58:	74 28                	je     0x2e82
    2e5a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e60:	06                   	push   es
    2e61:	57                   	push   di
    2e62:	9a 46 52 a4 2e       	call   0x2ea4:0x5246
    2e67:	52                   	push   dx
    2e68:	50                   	push   ax
    2e69:	bf 22 00             	mov    di,0x22
    2e6c:	b8 d8 2e             	mov    ax,0x2ed8
    2e6f:	50                   	push   ax
    2e70:	57                   	push   di
    2e71:	9a 73 22 97 2e       	call   0x2e97:0x2273
    2e76:	52                   	push   dx
    2e77:	50                   	push   ax
    2e78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e7b:	06                   	push   es
    2e7c:	57                   	push   di
    2e7d:	9a c4 19 cc 2f       	call   0x2fcc:0x19c4
    2e82:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e85:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2e88:	75 ad                	jne    0x2e37
    2e8a:	c9                   	leave
    2e8b:	ca 04 00             	retf   0x4
    2e8e:	55                   	push   bp
    2e8f:	89 e5                	mov    bp,sp
    2e91:	b8 08 00             	mov    ax,0x8
    2e94:	9a 44 04 ae 2e       	call   0x2eae:0x444
    2e99:	83 ec 08             	sub    sp,0x8
    2e9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e9f:	06                   	push   es
    2ea0:	57                   	push   di
    2ea1:	9a 7d 52 d0 2e       	call   0x2ed0:0x527d
    2ea6:	2d 01 00             	sub    ax,0x1
    2ea9:	71 05                	jno    0x2eb0
    2eab:	9a 3e 04 df 2e       	call   0x2edf:0x43e
    2eb0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2eb3:	31 c0                	xor    ax,ax
    2eb5:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2eb8:	7e 03                	jle    0x2ebd
    2eba:	e9 f9 00             	jmp    0x2fb6
    2ebd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2ec0:	eb 03                	jmp    0x2ec5
    2ec2:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2ec5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ec8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ecb:	06                   	push   es
    2ecc:	57                   	push   di
    2ecd:	9a 46 52 f0 2e       	call   0x2ef0:0x5246
    2ed2:	52                   	push   dx
    2ed3:	50                   	push   ax
    2ed4:	bf 22 00             	mov    di,0x22
    2ed7:	b8 f8 2e             	mov    ax,0x2ef8
    2eda:	50                   	push   ax
    2edb:	57                   	push   di
    2edc:	9a 55 22 ff 2e       	call   0x2eff:0x2255
    2ee1:	08 c0                	or     al,al
    2ee3:	74 2e                	je     0x2f13
    2ee5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ee8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eeb:	06                   	push   es
    2eec:	57                   	push   di
    2eed:	9a 46 52 1e 2f       	call   0x2f1e:0x5246
    2ef2:	52                   	push   dx
    2ef3:	50                   	push   ax
    2ef4:	bf 22 00             	mov    di,0x22
    2ef7:	b8 0e 2f             	mov    ax,0x2f0e
    2efa:	50                   	push   ax
    2efb:	57                   	push   di
    2efc:	9a 73 22 2d 2f       	call   0x2f2d:0x2273
    2f01:	89 c7                	mov    di,ax
    2f03:	8e c2                	mov    es,dx
    2f05:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f08:	50                   	push   ax
    2f09:	06                   	push   es
    2f0a:	57                   	push   di
    2f0b:	9a fe 1a 26 2f       	call   0x2f26:0x1afe
    2f10:	e9 98 00             	jmp    0x2fab
    2f13:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f19:	06                   	push   es
    2f1a:	57                   	push   di
    2f1b:	9a 46 52 3e 2f       	call   0x2f3e:0x5246
    2f20:	52                   	push   dx
    2f21:	50                   	push   ax
    2f22:	bf a2 0b             	mov    di,0xba2
    2f25:	b8 46 2f             	mov    ax,0x2f46
    2f28:	50                   	push   ax
    2f29:	57                   	push   di
    2f2a:	9a 55 22 4d 2f       	call   0x2f4d:0x2255
    2f2f:	08 c0                	or     al,al
    2f31:	74 2d                	je     0x2f60
    2f33:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f39:	06                   	push   es
    2f3a:	57                   	push   di
    2f3b:	9a 46 52 6b 2f       	call   0x2f6b:0x5246
    2f40:	52                   	push   dx
    2f41:	50                   	push   ax
    2f42:	bf a2 0b             	mov    di,0xba2
    2f45:	b8 5c 2f             	mov    ax,0x2f5c
    2f48:	50                   	push   ax
    2f49:	57                   	push   di
    2f4a:	9a 73 22 7a 2f       	call   0x2f7a:0x2273
    2f4f:	89 c7                	mov    di,ax
    2f51:	8e c2                	mov    es,dx
    2f53:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f56:	50                   	push   ax
    2f57:	06                   	push   es
    2f58:	57                   	push   di
    2f59:	9a f1 2a 73 2f       	call   0x2f73:0x2af1
    2f5e:	eb 4b                	jmp    0x2fab
    2f60:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f66:	06                   	push   es
    2f67:	57                   	push   di
    2f68:	9a 46 52 8b 2f       	call   0x2f8b:0x5246
    2f6d:	52                   	push   dx
    2f6e:	50                   	push   ax
    2f6f:	bf 26 06             	mov    di,0x626
    2f72:	b8 93 2f             	mov    ax,0x2f93
    2f75:	50                   	push   ax
    2f76:	57                   	push   di
    2f77:	9a 55 22 9a 2f       	call   0x2f9a:0x2255
    2f7c:	08 c0                	or     al,al
    2f7e:	74 2b                	je     0x2fab
    2f80:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f86:	06                   	push   es
    2f87:	57                   	push   di
    2f88:	9a 46 52 28 5e       	call   0x5e28:0x5246
    2f8d:	52                   	push   dx
    2f8e:	50                   	push   ax
    2f8f:	bf 26 06             	mov    di,0x626
    2f92:	b8 a9 2f             	mov    ax,0x2fa9
    2f95:	50                   	push   ax
    2f96:	57                   	push   di
    2f97:	9a 73 22 c2 2f       	call   0x2fc2:0x2273
    2f9c:	89 c7                	mov    di,ax
    2f9e:	8e c2                	mov    es,dx
    2fa0:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2fa3:	50                   	push   ax
    2fa4:	06                   	push   es
    2fa5:	57                   	push   di
    2fa6:	9a 70 25 e9 5e       	call   0x5ee9:0x2570
    2fab:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2fae:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2fb1:	74 03                	je     0x2fb6
    2fb3:	e9 0c ff             	jmp    0x2ec2
    2fb6:	c9                   	leave
    2fb7:	ca 06 00             	retf   0x6
    2fba:	55                   	push   bp
    2fbb:	89 e5                	mov    bp,sp
    2fbd:	31 c0                	xor    ax,ax
    2fbf:	9a 44 04 da 2f       	call   0x2fda:0x444
    2fc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc7:	06                   	push   es
    2fc8:	57                   	push   di
    2fc9:	9a 0b 62 fc 2f       	call   0x2ffc:0x620b
    2fce:	c9                   	leave
    2fcf:	ca 08 00             	retf   0x8
    2fd2:	55                   	push   bp
    2fd3:	89 e5                	mov    bp,sp
    2fd5:	31 c0                	xor    ax,ax
    2fd7:	9a 44 04 0a 30       	call   0x300a:0x444
    2fdc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fdf:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    2fe4:	26 8a 85 10 04       	mov    al,BYTE PTR es:[di+0x410]
    2fe9:	50                   	push   ax
    2fea:	9a 91 3e 35 62       	call   0x6235:0x3e91
    2fef:	3d 06 00             	cmp    ax,0x6
    2ff2:	75 0a                	jne    0x2ffe
    2ff4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ff7:	06                   	push   es
    2ff8:	57                   	push   di
    2ff9:	9a df 38 14 30       	call   0x3014:0x38df
    2ffe:	c9                   	leave
    2fff:	ca 08 00             	retf   0x8
    3002:	55                   	push   bp
    3003:	89 e5                	mov    bp,sp
    3005:	31 c0                	xor    ax,ax
    3007:	9a 44 04 23 30       	call   0x3023:0x444
    300c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    300f:	06                   	push   es
    3010:	57                   	push   di
    3011:	9a 11 3c cc 30       	call   0x30cc:0x3c11
    3016:	c9                   	leave
    3017:	ca 08 00             	retf   0x8
    301a:	55                   	push   bp
    301b:	89 e5                	mov    bp,sp
    301d:	b8 04 00             	mov    ax,0x4
    3020:	9a 44 04 0f 31       	call   0x310f:0x444
    3025:	83 ec 04             	sub    sp,0x4
    3028:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    302b:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3030:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3033:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3036:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    303c:	75 11                	jne    0x304f
    303e:	06                   	push   es
    303f:	57                   	push   di
    3040:	9a 8b 55 4d 30       	call   0x304d:0x558b
    3045:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3048:	06                   	push   es
    3049:	57                   	push   di
    304a:	9a 3c 53 6a 30       	call   0x306a:0x533c
    304f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3052:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3057:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    305a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    305d:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3063:	75 11                	jne    0x3076
    3065:	06                   	push   es
    3066:	57                   	push   di
    3067:	9a 8b 55 74 30       	call   0x3074:0x558b
    306c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    306f:	06                   	push   es
    3070:	57                   	push   di
    3071:	9a 3c 53 91 30       	call   0x3091:0x533c
    3076:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3079:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    307e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3081:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3084:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    308a:	75 11                	jne    0x309d
    308c:	06                   	push   es
    308d:	57                   	push   di
    308e:	9a 8b 55 9b 30       	call   0x309b:0x558b
    3093:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3096:	06                   	push   es
    3097:	57                   	push   di
    3098:	9a 3c 53 b8 30       	call   0x30b8:0x533c
    309d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30a0:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    30a5:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    30a8:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    30ab:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    30b1:	75 11                	jne    0x30c4
    30b3:	06                   	push   es
    30b4:	57                   	push   di
    30b5:	9a 8b 55 c2 30       	call   0x30c2:0x558b
    30ba:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    30bd:	06                   	push   es
    30be:	57                   	push   di
    30bf:	9a 3c 53 27 31       	call   0x3127:0x533c
    30c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30c7:	06                   	push   es
    30c8:	57                   	push   di
    30c9:	9a 9a 33 dc 30       	call   0x30dc:0x339a
    30ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30d1:	26 c6 85 12 04 00    	mov    BYTE PTR es:[di+0x412],0x0
    30d7:	06                   	push   es
    30d8:	57                   	push   di
    30d9:	9a 06 2e ea 30       	call   0x30ea:0x2e06
    30de:	6a ff                	push   0xffff
    30e0:	6a fa                	push   0xfffa
    30e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30e5:	06                   	push   es
    30e6:	57                   	push   di
    30e7:	9a af 2b f6 30       	call   0x30f6:0x2baf
    30ec:	6a 00                	push   0x0
    30ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30f1:	06                   	push   es
    30f2:	57                   	push   di
    30f3:	9a b7 2c 00 31       	call   0x3100:0x2cb7
    30f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30fb:	06                   	push   es
    30fc:	57                   	push   di
    30fd:	9a 26 37 43 32       	call   0x3243:0x3726
    3102:	c9                   	leave
    3103:	ca 08 00             	retf   0x8
    3106:	55                   	push   bp
    3107:	89 e5                	mov    bp,sp
    3109:	b8 04 00             	mov    ax,0x4
    310c:	9a 44 04 dd 31       	call   0x31dd:0x444
    3111:	83 ec 04             	sub    sp,0x4
    3114:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3117:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    311c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    311f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3122:	06                   	push   es
    3123:	57                   	push   di
    3124:	9a 02 32 35 31       	call   0x3135:0x3202
    3129:	08 c0                	or     al,al
    312b:	74 16                	je     0x3143
    312d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3130:	06                   	push   es
    3131:	57                   	push   di
    3132:	9a d2 31 56 31       	call   0x3156:0x31d2
    3137:	6a 00                	push   0x0
    3139:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    313c:	06                   	push   es
    313d:	57                   	push   di
    313e:	9a d2 2e 70 31       	call   0x3170:0x2ed2
    3143:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3146:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    314b:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    314e:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3151:	06                   	push   es
    3152:	57                   	push   di
    3153:	9a 02 32 64 31       	call   0x3164:0x3202
    3158:	08 c0                	or     al,al
    315a:	74 16                	je     0x3172
    315c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    315f:	06                   	push   es
    3160:	57                   	push   di
    3161:	9a d2 31 85 31       	call   0x3185:0x31d2
    3166:	6a 00                	push   0x0
    3168:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    316b:	06                   	push   es
    316c:	57                   	push   di
    316d:	9a d2 2e 9f 31       	call   0x319f:0x2ed2
    3172:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3175:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    317a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    317d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3180:	06                   	push   es
    3181:	57                   	push   di
    3182:	9a 02 32 93 31       	call   0x3193:0x3202
    3187:	08 c0                	or     al,al
    3189:	74 16                	je     0x31a1
    318b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    318e:	06                   	push   es
    318f:	57                   	push   di
    3190:	9a d2 31 b4 31       	call   0x31b4:0x31d2
    3195:	6a 00                	push   0x0
    3197:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    319a:	06                   	push   es
    319b:	57                   	push   di
    319c:	9a d2 2e ce 31       	call   0x31ce:0x2ed2
    31a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31a4:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    31a9:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    31ac:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    31af:	06                   	push   es
    31b0:	57                   	push   di
    31b1:	9a 02 32 c2 31       	call   0x31c2:0x3202
    31b6:	08 c0                	or     al,al
    31b8:	74 16                	je     0x31d0
    31ba:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31bd:	06                   	push   es
    31be:	57                   	push   di
    31bf:	9a d2 31 39 32       	call   0x3239:0x31d2
    31c4:	6a 00                	push   0x0
    31c6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31c9:	06                   	push   es
    31ca:	57                   	push   di
    31cb:	9a d2 2e 4e 32       	call   0x324e:0x2ed2
    31d0:	c9                   	leave
    31d1:	ca 04 00             	retf   0x4
    31d4:	55                   	push   bp
    31d5:	89 e5                	mov    bp,sp
    31d7:	b8 04 00             	mov    ax,0x4
    31da:	9a 44 04 a3 33       	call   0x33a3:0x444
    31df:	83 ec 04             	sub    sp,0x4
    31e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e5:	26 8a 85 09 04       	mov    al,BYTE PTR es:[di+0x409]
    31ea:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    31ef:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    31f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31f6:	26 8a 85 09 04       	mov    al,BYTE PTR es:[di+0x409]
    31fb:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3200:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    3204:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3207:	26 8a 85 09 04       	mov    al,BYTE PTR es:[di+0x409]
    320c:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3211:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    3215:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3218:	26 8a 85 09 04       	mov    al,BYTE PTR es:[di+0x409]
    321d:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    3222:	26 88 45 23          	mov    BYTE PTR es:[di+0x23],al
    3226:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3229:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    322e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3231:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3234:	06                   	push   es
    3235:	57                   	push   di
    3236:	9a d2 31 80 32       	call   0x3280:0x31d2
    323b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    323e:	06                   	push   es
    323f:	57                   	push   di
    3240:	9a 2c 13 58 32       	call   0x3258:0x132c
    3245:	50                   	push   ax
    3246:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3249:	06                   	push   es
    324a:	57                   	push   di
    324b:	9a fb 2f 68 32       	call   0x3268:0x2ffb
    3250:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3253:	06                   	push   es
    3254:	57                   	push   di
    3255:	9a 2c 13 9f 32       	call   0x329f:0x132c
    325a:	08 c0                	or     al,al
    325c:	75 0e                	jne    0x326c
    325e:	6a 01                	push   0x1
    3260:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3263:	06                   	push   es
    3264:	57                   	push   di
    3265:	9a d2 2e 76 32       	call   0x3276:0x2ed2
    326a:	eb 0c                	jmp    0x3278
    326c:	6a 00                	push   0x0
    326e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3271:	06                   	push   es
    3272:	57                   	push   di
    3273:	9a d2 2e aa 32       	call   0x32aa:0x2ed2
    3278:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    327b:	06                   	push   es
    327c:	57                   	push   di
    327d:	9a bf 31 95 32       	call   0x3295:0x31bf
    3282:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3285:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    328a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    328d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3290:	06                   	push   es
    3291:	57                   	push   di
    3292:	9a d2 31 dc 32       	call   0x32dc:0x31d2
    3297:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    329a:	06                   	push   es
    329b:	57                   	push   di
    329c:	9a 2c 13 b4 32       	call   0x32b4:0x132c
    32a1:	50                   	push   ax
    32a2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32a5:	06                   	push   es
    32a6:	57                   	push   di
    32a7:	9a fb 2f c4 32       	call   0x32c4:0x2ffb
    32ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32af:	06                   	push   es
    32b0:	57                   	push   di
    32b1:	9a 2c 13 fb 32       	call   0x32fb:0x132c
    32b6:	08 c0                	or     al,al
    32b8:	75 0e                	jne    0x32c8
    32ba:	6a 01                	push   0x1
    32bc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32bf:	06                   	push   es
    32c0:	57                   	push   di
    32c1:	9a d2 2e d2 32       	call   0x32d2:0x2ed2
    32c6:	eb 0c                	jmp    0x32d4
    32c8:	6a 00                	push   0x0
    32ca:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32cd:	06                   	push   es
    32ce:	57                   	push   di
    32cf:	9a d2 2e 06 33       	call   0x3306:0x2ed2
    32d4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32d7:	06                   	push   es
    32d8:	57                   	push   di
    32d9:	9a bf 31 f1 32       	call   0x32f1:0x31bf
    32de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32e1:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    32e6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    32e9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    32ec:	06                   	push   es
    32ed:	57                   	push   di
    32ee:	9a d2 31 38 33       	call   0x3338:0x31d2
    32f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32f6:	06                   	push   es
    32f7:	57                   	push   di
    32f8:	9a 2c 13 10 33       	call   0x3310:0x132c
    32fd:	50                   	push   ax
    32fe:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3301:	06                   	push   es
    3302:	57                   	push   di
    3303:	9a fb 2f 20 33       	call   0x3320:0x2ffb
    3308:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    330b:	06                   	push   es
    330c:	57                   	push   di
    330d:	9a 2c 13 57 33       	call   0x3357:0x132c
    3312:	08 c0                	or     al,al
    3314:	75 0e                	jne    0x3324
    3316:	6a 01                	push   0x1
    3318:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    331b:	06                   	push   es
    331c:	57                   	push   di
    331d:	9a d2 2e 2e 33       	call   0x332e:0x2ed2
    3322:	eb 0c                	jmp    0x3330
    3324:	6a 00                	push   0x0
    3326:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3329:	06                   	push   es
    332a:	57                   	push   di
    332b:	9a d2 2e 62 33       	call   0x3362:0x2ed2
    3330:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3333:	06                   	push   es
    3334:	57                   	push   di
    3335:	9a bf 31 4d 33       	call   0x334d:0x31bf
    333a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    333d:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3342:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3345:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3348:	06                   	push   es
    3349:	57                   	push   di
    334a:	9a d2 31 94 33       	call   0x3394:0x31d2
    334f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3352:	06                   	push   es
    3353:	57                   	push   di
    3354:	9a 2c 13 6c 33       	call   0x336c:0x132c
    3359:	50                   	push   ax
    335a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    335d:	06                   	push   es
    335e:	57                   	push   di
    335f:	9a fb 2f 7c 33       	call   0x337c:0x2ffb
    3364:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3367:	06                   	push   es
    3368:	57                   	push   di
    3369:	9a 2c 13 dd 33       	call   0x33dd:0x132c
    336e:	08 c0                	or     al,al
    3370:	75 0e                	jne    0x3380
    3372:	6a 01                	push   0x1
    3374:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3377:	06                   	push   es
    3378:	57                   	push   di
    3379:	9a d2 2e 8a 33       	call   0x338a:0x2ed2
    337e:	eb 0c                	jmp    0x338c
    3380:	6a 00                	push   0x0
    3382:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3385:	06                   	push   es
    3386:	57                   	push   di
    3387:	9a d2 2e 5b 34       	call   0x345b:0x2ed2
    338c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    338f:	06                   	push   es
    3390:	57                   	push   di
    3391:	9a bf 31 d9 33       	call   0x33d9:0x31bf
    3396:	c9                   	leave
    3397:	ca 04 00             	retf   0x4
    339a:	55                   	push   bp
    339b:	89 e5                	mov    bp,sp
    339d:	b8 04 00             	mov    ax,0x4
    33a0:	9a 44 04 bd 33       	call   0x33bd:0x444
    33a5:	83 ec 04             	sub    sp,0x4
    33a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33ab:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    33b0:	c9                   	leave
    33b1:	ca 04 00             	retf   0x4
    33b4:	55                   	push   bp
    33b5:	89 e5                	mov    bp,sp
    33b7:	b8 04 00             	mov    ax,0x4
    33ba:	9a 44 04 fa 33       	call   0x33fa:0x444
    33bf:	83 ec 04             	sub    sp,0x4
    33c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33c5:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    33ca:	26 80 7d 3a 00       	cmp    BYTE PTR es:[di+0x3a],0x0
    33cf:	74 00                	je     0x33d1
    33d1:	c9                   	leave
    33d2:	ca 04 00             	retf   0x4
    33d5:	01 00                	add    WORD PTR [bx+si],ax
    33d7:	2f                   	das
    33d8:	00 9e 35 cb          	add    BYTE PTR [bp-0x34cb],bl
    33dc:	36 e7 33             	ss out 0x33,ax
    33df:	02 00                	add    al,BYTE PTR [bx+si]
    33e1:	d8 00                	fadd   DWORD PTR [bx+si]
    33e3:	10 37                	adc    BYTE PTR [bx],dh
    33e5:	ef                   	out    dx,ax
    33e6:	36 ef                	ss out dx,ax
    33e8:	33 00                	xor    ax,WORD PTR [bx+si]
    33ea:	00 00                	add    BYTE PTR [bx+si],al
    33ec:	00 f7                	add    bh,dh
    33ee:	36 69 34 55 89       	imul   si,WORD PTR ss:[si],0x8955
    33f3:	e5 b8                	in     ax,0xb8
    33f5:	1c 00                	sbb    al,0x0
    33f7:	9a 44 04 df 36       	call   0x36df:0x444
    33fc:	83 ec 1c             	sub    sp,0x1c
    33ff:	b8 df 33             	mov    ax,0x33df
    3402:	0e                   	push   cs
    3403:	50                   	push   ax
    3404:	55                   	push   bp
    3405:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3409:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    340d:	b8 d5 33             	mov    ax,0x33d5
    3410:	0e                   	push   cs
    3411:	50                   	push   ax
    3412:	55                   	push   bp
    3413:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3417:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    341b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    341e:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3423:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3426:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3429:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    342c:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    3431:	99                   	cwd
    3432:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3435:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    3438:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    343c:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    3441:	99                   	cwd
    3442:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3445:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3448:	c6 46 f8 00          	mov    BYTE PTR [bp-0x8],0x0
    344c:	8d 7e ec             	lea    di,[bp-0x14]
    344f:	16                   	push   ss
    3450:	57                   	push   di
    3451:	6a 01                	push   0x1
    3453:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3456:	06                   	push   es
    3457:	57                   	push   di
    3458:	9a 95 28 c3 34       	call   0x34c3:0x2895
    345d:	08 c0                	or     al,al
    345f:	75 0a                	jne    0x346b
    3461:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3464:	06                   	push   es
    3465:	57                   	push   di
    3466:	9a 7b 0b 73 34       	call   0x3473:0xb7b
    346b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    346e:	06                   	push   es
    346f:	57                   	push   di
    3470:	9a 9a 33 d1 34       	call   0x34d1:0x339a
    3475:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3478:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    347d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3480:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3483:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3486:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    348b:	99                   	cwd
    348c:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    348f:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    3492:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    3496:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    349b:	99                   	cwd
    349c:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    349f:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    34a2:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    34a6:	c7 46 f4 01 00       	mov    WORD PTR [bp-0xc],0x1
    34ab:	c7 46 f6 00 00       	mov    WORD PTR [bp-0xa],0x0
    34b0:	c6 46 f8 00          	mov    BYTE PTR [bp-0x8],0x0
    34b4:	8d 7e e4             	lea    di,[bp-0x1c]
    34b7:	16                   	push   ss
    34b8:	57                   	push   di
    34b9:	6a 02                	push   0x2
    34bb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    34be:	06                   	push   es
    34bf:	57                   	push   di
    34c0:	9a 95 28 21 35       	call   0x3521:0x2895
    34c5:	08 c0                	or     al,al
    34c7:	75 0a                	jne    0x34d3
    34c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34cc:	06                   	push   es
    34cd:	57                   	push   di
    34ce:	9a 7b 0b 2f 35       	call   0x352f:0xb7b
    34d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34d6:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    34db:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    34de:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    34e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34e4:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    34e9:	99                   	cwd
    34ea:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    34ed:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    34f0:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    34f4:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    34f9:	99                   	cwd
    34fa:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    34fd:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    3500:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    3504:	c7 46 f4 02 00       	mov    WORD PTR [bp-0xc],0x2
    3509:	c7 46 f6 00 00       	mov    WORD PTR [bp-0xa],0x0
    350e:	c6 46 f8 00          	mov    BYTE PTR [bp-0x8],0x0
    3512:	8d 7e e4             	lea    di,[bp-0x1c]
    3515:	16                   	push   ss
    3516:	57                   	push   di
    3517:	6a 02                	push   0x2
    3519:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    351c:	06                   	push   es
    351d:	57                   	push   di
    351e:	9a 95 28 71 35       	call   0x3571:0x2895
    3523:	08 c0                	or     al,al
    3525:	75 0a                	jne    0x3531
    3527:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    352a:	06                   	push   es
    352b:	57                   	push   di
    352c:	9a 7b 0b 7f 35       	call   0x357f:0xb7b
    3531:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3534:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3539:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    353c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    353f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3542:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    3547:	99                   	cwd
    3548:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    354b:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    354e:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    3552:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    3557:	99                   	cwd
    3558:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    355b:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    355e:	c6 46 f8 00          	mov    BYTE PTR [bp-0x8],0x0
    3562:	8d 7e ec             	lea    di,[bp-0x14]
    3565:	16                   	push   ss
    3566:	57                   	push   di
    3567:	6a 01                	push   0x1
    3569:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    356c:	06                   	push   es
    356d:	57                   	push   di
    356e:	9a 95 28 68 3c       	call   0x3c68:0x2895
    3573:	08 c0                	or     al,al
    3575:	75 0a                	jne    0x3581
    3577:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    357a:	06                   	push   es
    357b:	57                   	push   di
    357c:	9a 7b 0b 8c 36       	call   0x368c:0xb7b
    3581:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3584:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    358a:	74 5c                	je     0x35e8
    358c:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3591:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3597:	75 07                	jne    0x35a0
    3599:	06                   	push   es
    359a:	57                   	push   di
    359b:	9a 3c 53 b5 35       	call   0x35b5:0x533c
    35a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35a3:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    35a8:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    35ae:	75 07                	jne    0x35b7
    35b0:	06                   	push   es
    35b1:	57                   	push   di
    35b2:	9a 3c 53 cc 35       	call   0x35cc:0x533c
    35b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35ba:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    35bf:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    35c5:	75 07                	jne    0x35ce
    35c7:	06                   	push   es
    35c8:	57                   	push   di
    35c9:	9a 3c 53 e3 35       	call   0x35e3:0x533c
    35ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35d1:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    35d6:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    35dc:	75 07                	jne    0x35e5
    35de:	06                   	push   es
    35df:	57                   	push   di
    35e0:	9a 3c 53 03 36       	call   0x3603:0x533c
    35e5:	e9 9c 00             	jmp    0x3684
    35e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35eb:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    35f0:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    35f3:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    35f6:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    35fc:	75 11                	jne    0x360f
    35fe:	06                   	push   es
    35ff:	57                   	push   di
    3600:	9a 3c 53 0d 36       	call   0x360d:0x533c
    3605:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3608:	06                   	push   es
    3609:	57                   	push   di
    360a:	9a 8b 55 2a 36       	call   0x362a:0x558b
    360f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3612:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3617:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    361a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    361d:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3623:	75 11                	jne    0x3636
    3625:	06                   	push   es
    3626:	57                   	push   di
    3627:	9a 3c 53 34 36       	call   0x3634:0x533c
    362c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    362f:	06                   	push   es
    3630:	57                   	push   di
    3631:	9a 8b 55 51 36       	call   0x3651:0x558b
    3636:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3639:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    363e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3641:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3644:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    364a:	75 11                	jne    0x365d
    364c:	06                   	push   es
    364d:	57                   	push   di
    364e:	9a 3c 53 5b 36       	call   0x365b:0x533c
    3653:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3656:	06                   	push   es
    3657:	57                   	push   di
    3658:	9a 8b 55 78 36       	call   0x3678:0x558b
    365d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3660:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3665:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3668:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    366b:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3671:	75 11                	jne    0x3684
    3673:	06                   	push   es
    3674:	57                   	push   di
    3675:	9a 3c 53 82 36       	call   0x3682:0x533c
    367a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    367d:	06                   	push   es
    367e:	57                   	push   di
    367f:	9a 8b 55 46 37       	call   0x3746:0x558b
    3684:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3687:	06                   	push   es
    3688:	57                   	push   di
    3689:	9a 9a 33 9c 36       	call   0x369c:0x339a
    368e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3691:	26 c6 85 12 04 00    	mov    BYTE PTR es:[di+0x412],0x0
    3697:	06                   	push   es
    3698:	57                   	push   di
    3699:	9a 06 2e aa 36       	call   0x36aa:0x2e06
    369e:	6a ff                	push   0xffff
    36a0:	6a fa                	push   0xfffa
    36a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36a5:	06                   	push   es
    36a6:	57                   	push   di
    36a7:	9a af 2b b6 36       	call   0x36b6:0x2baf
    36ac:	6a 00                	push   0x0
    36ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36b1:	06                   	push   es
    36b2:	57                   	push   di
    36b3:	9a b7 2c c0 36       	call   0x36c0:0x2cb7
    36b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36bb:	06                   	push   es
    36bc:	57                   	push   di
    36bd:	9a 26 37 90 38       	call   0x3890:0x3726
    36c2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    36c6:	83 c4 06             	add    sp,0x6
    36c9:	eb 1b                	jmp    0x36e6
    36cb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    36ce:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    36d1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    36d4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    36d7:	9a 2d 34 bf 39       	call   0x39bf:0x342d
    36dc:	ea 85 13 e4 36       	jmp    0x36e4:0x1385
    36e1:	9a 34 14 15 37       	call   0x3715:0x1434
    36e6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    36ea:	83 c4 06             	add    sp,0x6
    36ed:	eb 28                	jmp    0x3717
    36ef:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    36f2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    36f5:	eb 1b                	jmp    0x3712
    36f7:	c6 06 66 02 01       	mov    BYTE PTR ds:0x266,0x1
    36fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36ff:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
    3706:	06                   	push   es
    3707:	57                   	push   di
    3708:	9a 56 55 ea 63       	call   0x63ea:0x5556
    370d:	9a c3 28 87 42       	call   0x4287:0x28c3
    3712:	9a 34 14 2f 37       	call   0x372f:0x1434
    3717:	c9                   	leave
    3718:	ca 04 00             	retf   0x4
    371b:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    371e:	6c                   	ins    BYTE PTR es:[di],dx
    371f:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    3724:	6f                   	outs   dx,WORD PTR ds:[si]
    3725:	6e                   	outs   dx,BYTE PTR ds:[si]
    3726:	55                   	push   bp
    3727:	89 e5                	mov    bp,sp
    3729:	b8 02 00             	mov    ax,0x2
    372c:	9a 44 04 e7 37       	call   0x37e7:0x444
    3731:	83 ec 02             	sub    sp,0x2
    3734:	bf 1b 37             	mov    di,0x371b
    3737:	0e                   	push   cs
    3738:	57                   	push   di
    3739:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    373c:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3741:	06                   	push   es
    3742:	57                   	push   di
    3743:	9a 9b 3b 07 38       	call   0x3807:0x3b9b
    3748:	89 c7                	mov    di,ax
    374a:	8e c2                	mov    es,dx
    374c:	06                   	push   es
    374d:	57                   	push   di
    374e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3751:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    3755:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3758:	26 88 85 10 04       	mov    BYTE PTR es:[di+0x410],al
    375d:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    3763:	74 59                	je     0x37be
    3765:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    376a:	26 8a 45 3e          	mov    al,BYTE PTR es:[di+0x3e]
    376e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3771:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3776:	26 0a 45 3e          	or     al,BYTE PTR es:[di+0x3e]
    377a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    377d:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3782:	26 0a 45 3e          	or     al,BYTE PTR es:[di+0x3e]
    3786:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3789:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    378e:	26 0a 45 3e          	or     al,BYTE PTR es:[di+0x3e]
    3792:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3795:	26 0a 85 12 04       	or     al,BYTE PTR es:[di+0x412]
    379a:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    379d:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    37a1:	74 06                	je     0x37a9
    37a3:	26 c6 85 10 04 00    	mov    BYTE PTR es:[di+0x410],0x0
    37a9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    37ac:	50                   	push   ax
    37ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37b0:	26 c4 bd d4 03       	les    di,DWORD PTR es:[di+0x3d4]
    37b5:	06                   	push   es
    37b6:	57                   	push   di
    37b7:	9a 77 1c 84 5e       	call   0x5e84:0x1c77
    37bc:	eb 04                	jmp    0x37c2
    37be:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    37c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37c5:	26 8a 85 10 04       	mov    al,BYTE PTR es:[di+0x410]
    37ca:	50                   	push   ax
    37cb:	26 c4 bd e0 03       	les    di,DWORD PTR es:[di+0x3e0]
    37d0:	06                   	push   es
    37d1:	57                   	push   di
    37d2:	9a 11 6e ef 61       	call   0x61ef:0x6e11
    37d7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    37da:	c9                   	leave
    37db:	ca 04 00             	retf   0x4
    37de:	55                   	push   bp
    37df:	89 e5                	mov    bp,sp
    37e1:	b8 04 00             	mov    ax,0x4
    37e4:	9a 44 04 e8 38       	call   0x38e8:0x444
    37e9:	83 ec 04             	sub    sp,0x4
    37ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37ef:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    37f4:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    37f7:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    37fa:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3800:	75 11                	jne    0x3813
    3802:	06                   	push   es
    3803:	57                   	push   di
    3804:	9a 3c 53 11 38       	call   0x3811:0x533c
    3809:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    380c:	06                   	push   es
    380d:	57                   	push   di
    380e:	9a 8b 55 2e 38       	call   0x382e:0x558b
    3813:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3816:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    381b:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    381e:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3821:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3827:	75 11                	jne    0x383a
    3829:	06                   	push   es
    382a:	57                   	push   di
    382b:	9a 3c 53 38 38       	call   0x3838:0x533c
    3830:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3833:	06                   	push   es
    3834:	57                   	push   di
    3835:	9a 8b 55 55 38       	call   0x3855:0x558b
    383a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    383d:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3842:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3845:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3848:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    384e:	75 11                	jne    0x3861
    3850:	06                   	push   es
    3851:	57                   	push   di
    3852:	9a 3c 53 5f 38       	call   0x385f:0x533c
    3857:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    385a:	06                   	push   es
    385b:	57                   	push   di
    385c:	9a 8b 55 7c 38       	call   0x387c:0x558b
    3861:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3864:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3869:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    386c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    386f:	26 80 bd 81 01 00    	cmp    BYTE PTR es:[di+0x181],0x0
    3875:	75 11                	jne    0x3888
    3877:	06                   	push   es
    3878:	57                   	push   di
    3879:	9a 3c 53 86 38       	call   0x3886:0x533c
    387e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3881:	06                   	push   es
    3882:	57                   	push   di
    3883:	9a 8b 55 d9 38       	call   0x38d9:0x558b
    3888:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    388b:	06                   	push   es
    388c:	57                   	push   di
    388d:	9a 9a 33 a0 38       	call   0x38a0:0x339a
    3892:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3895:	26 c6 85 12 04 00    	mov    BYTE PTR es:[di+0x412],0x0
    389b:	06                   	push   es
    389c:	57                   	push   di
    389d:	9a 06 2e ae 38       	call   0x38ae:0x2e06
    38a2:	6a ff                	push   0xffff
    38a4:	6a fa                	push   0xfffa
    38a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38a9:	06                   	push   es
    38aa:	57                   	push   di
    38ab:	9a af 2b ba 38       	call   0x38ba:0x2baf
    38b0:	6a 00                	push   0x0
    38b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38b5:	06                   	push   es
    38b6:	57                   	push   di
    38b7:	9a b7 2c c4 38       	call   0x38c4:0x2cb7
    38bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38bf:	06                   	push   es
    38c0:	57                   	push   di
    38c1:	9a 26 37 dd 38       	call   0x38dd:0x3726
    38c6:	c9                   	leave
    38c7:	ca 04 00             	retf   0x4
    38ca:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    38cd:	6c                   	ins    BYTE PTR es:[di],dx
    38ce:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    38d3:	6f                   	outs   dx,WORD PTR ds:[si]
    38d4:	6e                   	outs   dx,BYTE PTR ds:[si]
    38d5:	01 00                	add    WORD PTR [bx+si],ax
    38d7:	2f                   	das
    38d8:	00 fa                	add    dl,bh
    38da:	38 b0 39 5b          	cmp    BYTE PTR [bx+si+0x5b39],dh
    38de:	39 55 89             	cmp    WORD PTR [di-0x77],dx
    38e1:	e5 b8                	in     ax,0xb8
    38e3:	04 00                	add    al,0x0
    38e5:	9a 44 04 c4 39       	call   0x39c4:0x444
    38ea:	83 ec 04             	sub    sp,0x4
    38ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38f0:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    38f5:	06                   	push   es
    38f6:	57                   	push   di
    38f7:	9a 3c 53 09 39       	call   0x3909:0x533c
    38fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38ff:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3904:	06                   	push   es
    3905:	57                   	push   di
    3906:	9a 3c 53 18 39       	call   0x3918:0x533c
    390b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    390e:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3913:	06                   	push   es
    3914:	57                   	push   di
    3915:	9a 3c 53 27 39       	call   0x3927:0x533c
    391a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    391d:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3922:	06                   	push   es
    3923:	57                   	push   di
    3924:	9a 3c 53 44 39       	call   0x3944:0x533c
    3929:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    392c:	26 8a 85 10 04       	mov    al,BYTE PTR es:[di+0x410]
    3931:	50                   	push   ax
    3932:	bf ca 38             	mov    di,0x38ca
    3935:	0e                   	push   cs
    3936:	57                   	push   di
    3937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    393a:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    393f:	06                   	push   es
    3940:	57                   	push   di
    3941:	9a 9b 3b 78 39       	call   0x3978:0x3b9b
    3946:	89 c7                	mov    di,ax
    3948:	8e c2                	mov    es,dx
    394a:	06                   	push   es
    394b:	57                   	push   di
    394c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    394f:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    3953:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3956:	06                   	push   es
    3957:	57                   	push   di
    3958:	9a b4 33 0a 3a       	call   0x3a0a:0x33b4
    395d:	b8 d5 38             	mov    ax,0x38d5
    3960:	0e                   	push   cs
    3961:	50                   	push   ax
    3962:	55                   	push   bp
    3963:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3967:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    396b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    396e:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3973:	06                   	push   es
    3974:	57                   	push   di
    3975:	9a a0 54 87 39       	call   0x3987:0x54a0
    397a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    397d:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3982:	06                   	push   es
    3983:	57                   	push   di
    3984:	9a a0 54 96 39       	call   0x3996:0x54a0
    3989:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    398c:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3991:	06                   	push   es
    3992:	57                   	push   di
    3993:	9a a0 54 a5 39       	call   0x39a5:0x54a0
    3998:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    399b:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    39a0:	06                   	push   es
    39a1:	57                   	push   di
    39a2:	9a a0 54 d3 39       	call   0x39d3:0x54a0
    39a7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    39ab:	83 c4 06             	add    sp,0x6
    39ae:	eb 16                	jmp    0x39c6
    39b0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    39b3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    39b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    39b9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    39bc:	9a 2d 34 1e 3b       	call   0x3b1e:0x342d
    39c1:	9a 34 14 2e 3a       	call   0x3a2e:0x1434
    39c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39c9:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    39ce:	06                   	push   es
    39cf:	57                   	push   di
    39d0:	9a 3c 53 e2 39       	call   0x39e2:0x533c
    39d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39d8:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    39dd:	06                   	push   es
    39de:	57                   	push   di
    39df:	9a 3c 53 f1 39       	call   0x39f1:0x533c
    39e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39e7:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    39ec:	06                   	push   es
    39ed:	57                   	push   di
    39ee:	9a 3c 53 00 3a       	call   0x3a00:0x533c
    39f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39f6:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    39fb:	06                   	push   es
    39fc:	57                   	push   di
    39fd:	9a 3c 53 1f 3a       	call   0x3a1f:0x533c
    3a02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a05:	06                   	push   es
    3a06:	57                   	push   di
    3a07:	9a 26 37 23 3a       	call   0x3a23:0x3726
    3a0c:	c9                   	leave
    3a0d:	ca 04 00             	retf   0x4
    3a10:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    3a13:	6c                   	ins    BYTE PTR es:[di],dx
    3a14:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    3a19:	6f                   	outs   dx,WORD PTR ds:[si]
    3a1a:	6e                   	outs   dx,BYTE PTR ds:[si]
    3a1b:	01 00                	add    WORD PTR [bx+si],ax
    3a1d:	2f                   	das
    3a1e:	00 55 3a             	add    BYTE PTR [di+0x3a],dl
    3a21:	0f 3b                	(bad)
    3a23:	3f                   	aas
    3a24:	3a 55 89             	cmp    dl,BYTE PTR [di-0x77]
    3a27:	e5 b8                	in     ax,0xb8
    3a29:	06                   	push   es
    3a2a:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    3a2e:	23 3b                	and    di,WORD PTR [bp+di]
    3a30:	83 ec 06             	sub    sp,0x6
    3a33:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    3a37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a3a:	06                   	push   es
    3a3b:	57                   	push   di
    3a3c:	9a 0b 62 b6 3a       	call   0x3ab6:0x620b
    3a41:	08 c0                	or     al,al
    3a43:	75 03                	jne    0x3a48
    3a45:	e9 dd 00             	jmp    0x3b25
    3a48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a4b:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3a50:	06                   	push   es
    3a51:	57                   	push   di
    3a52:	9a 3c 53 64 3a       	call   0x3a64:0x533c
    3a57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a5a:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3a5f:	06                   	push   es
    3a60:	57                   	push   di
    3a61:	9a 3c 53 73 3a       	call   0x3a73:0x533c
    3a66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a69:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3a6e:	06                   	push   es
    3a6f:	57                   	push   di
    3a70:	9a 3c 53 82 3a       	call   0x3a82:0x533c
    3a75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a78:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3a7d:	06                   	push   es
    3a7e:	57                   	push   di
    3a7f:	9a 3c 53 9f 3a       	call   0x3a9f:0x533c
    3a84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a87:	26 8a 85 10 04       	mov    al,BYTE PTR es:[di+0x410]
    3a8c:	50                   	push   ax
    3a8d:	bf 10 3a             	mov    di,0x3a10
    3a90:	0e                   	push   cs
    3a91:	57                   	push   di
    3a92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a95:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3a9a:	06                   	push   es
    3a9b:	57                   	push   di
    3a9c:	9a 9b 3b d3 3a       	call   0x3ad3:0x3b9b
    3aa1:	89 c7                	mov    di,ax
    3aa3:	8e c2                	mov    es,dx
    3aa5:	06                   	push   es
    3aa6:	57                   	push   di
    3aa7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3aaa:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    3aae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ab1:	06                   	push   es
    3ab2:	57                   	push   di
    3ab3:	9a b4 33 ff 3b       	call   0x3bff:0x33b4
    3ab8:	b8 1b 3a             	mov    ax,0x3a1b
    3abb:	0e                   	push   cs
    3abc:	50                   	push   ax
    3abd:	55                   	push   bp
    3abe:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3ac2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3ac6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ac9:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3ace:	06                   	push   es
    3acf:	57                   	push   di
    3ad0:	9a a0 54 e2 3a       	call   0x3ae2:0x54a0
    3ad5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ad8:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3add:	06                   	push   es
    3ade:	57                   	push   di
    3adf:	9a a0 54 f1 3a       	call   0x3af1:0x54a0
    3ae4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ae7:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3aec:	06                   	push   es
    3aed:	57                   	push   di
    3aee:	9a a0 54 00 3b       	call   0x3b00:0x54a0
    3af3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3af6:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3afb:	06                   	push   es
    3afc:	57                   	push   di
    3afd:	9a a0 54 fb 3b       	call   0x3bfb:0x54a0
    3b02:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    3b06:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3b0a:	83 c4 06             	add    sp,0x6
    3b0d:	eb 16                	jmp    0x3b25
    3b0f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3b12:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    3b15:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3b18:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3b1b:	9a 2d 34 82 42       	call   0x4282:0x342d
    3b20:	9a 34 14 1a 3c       	call   0x3c1a:0x1434
    3b25:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3b28:	c9                   	leave
    3b29:	ca 04 00             	retf   0x4
    3b2c:	10 56 61             	adc    BYTE PTR [bp+0x61],dl
    3b2f:	72 69                	jb     0x3b9a
    3b31:	61                   	popa
    3b32:	74 69                	je     0x3b9d
    3b34:	6f                   	outs   dx,WORD PTR ds:[si]
    3b35:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b36:	43                   	inc    bx
    3b37:	61                   	popa
    3b38:	70 69                	jo     0x3ba3
    3b3a:	74 61                	je     0x3b9d
    3b3c:	6c                   	ins    BYTE PTR es:[di],dx
    3b3d:	0a 44 69             	or     al,BYTE PTR [si+0x69]
    3b40:	76 69                	jbe    0x3bab
    3b42:	64 65 6e             	fs outs dx,BYTE PTR gs:[si]
    3b45:	64 65 73 10          	fs gs jae 0x3b59
    3b49:	56                   	push   si
    3b4a:	61                   	popa
    3b4b:	72 69                	jb     0x3bb6
    3b4d:	61                   	popa
    3b4e:	74 69                	je     0x3bb9
    3b50:	6f                   	outs   dx,WORD PTR ds:[si]
    3b51:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b52:	45                   	inc    bp
    3b53:	6d                   	ins    WORD PTR es:[di],dx
    3b54:	70 72                	jo     0x3bc8
    3b56:	75 6e                	jne    0x3bc6
    3b58:	74 0b                	je     0x3b65
    3b5a:	53                   	push   bx
    3b5b:	75 62                	jne    0x3bbf
    3b5d:	76 65                	jbe    0x3bc4
    3b5f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b60:	74 69                	je     0x3bcb
    3b62:	6f                   	outs   dx,WORD PTR ds:[si]
    3b63:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b64:	73 13                	jae    0x3b79
    3b66:	50                   	push   ax
    3b67:	72 6f                	jb     0x3bd8
    3b69:	64 75 69             	fs jne 0x3bd5
    3b6c:	74 73                	je     0x3be1
    3b6e:	4f                   	dec    di
    3b6f:	75 43                	jne    0x3bb4
    3b71:	68 61 72             	push   0x7261
    3b74:	67 65 73 45          	addr32 gs jae 0x3bbd
    3b78:	78 0d                	js     0x3b87
    3b7a:	41                   	inc    cx
    3b7b:	63 68 61             	arpl   WORD PTR [bx+si+0x61],bp
    3b7e:	74 4d                	je     0x3bcd
    3b80:	61                   	popa
    3b81:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    3b84:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b85:	65 73 0d             	gs jae 0x3b95
    3b88:	56                   	push   si
    3b89:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3b8b:	74 65                	je     0x3bf2
    3b8d:	4d                   	dec    bp
    3b8e:	61                   	popa
    3b8f:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    3b92:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b93:	65 73 13             	gs jae 0x3ba9
    3b96:	45                   	inc    bp
    3b97:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b98:	74 72                	je     0x3c0c
    3b9a:	65 74 69             	gs je  0x3c06
    3b9d:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3b9f:	4d                   	dec    bp
    3ba0:	61                   	popa
    3ba1:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    3ba4:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ba5:	65 73 50             	gs jae 0x3bf8
    3ba8:	63 0f                	arpl   WORD PTR [bx],cx
    3baa:	43                   	inc    bx
    3bab:	61                   	popa
    3bac:	64 72 65             	fs jb  0x3c14
    3baf:	73 45                	jae    0x3bf6
    3bb1:	6d                   	ins    WORD PTR es:[di],dx
    3bb2:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    3bb5:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    3bb8:	73 0f                	jae    0x3bc9
    3bba:	43                   	inc    bx
    3bbb:	61                   	popa
    3bbc:	64 72 65             	fs jb  0x3c24
    3bbf:	73 4c                	jae    0x3c0d
    3bc1:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    3bc6:	69 65 73 0b 4c       	imul   sp,WORD PTR [di+0x73],0x4c0b
    3bcb:	69 71 75 69 64       	imul   si,WORD PTR [bx+di+0x75],0x6469
    3bd0:	61                   	popa
    3bd1:	74 69                	je     0x3c3c
    3bd3:	6f                   	outs   dx,WORD PTR ds:[si]
    3bd4:	6e                   	outs   dx,BYTE PTR ds:[si]
    3bd5:	12 53 6f             	adc    dl,BYTE PTR [bp+di+0x6f]
    3bd8:	75 6d                	jne    0x3c47
    3bda:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    3bdf:	6e                   	outs   dx,BYTE PTR ds:[si]
    3be0:	51                   	push   cx
    3be1:	75 61                	jne    0x3c44
    3be3:	6e                   	outs   dx,BYTE PTR ds:[si]
    3be4:	74 69                	je     0x3c4f
    3be6:	74 65                	je     0x3c4d
    3be8:	0e                   	push   cs
    3be9:	53                   	push   bx
    3bea:	6f                   	outs   dx,WORD PTR ds:[si]
    3beb:	75 6d                	jne    0x3c5a
    3bed:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    3bf2:	6e                   	outs   dx,BYTE PTR ds:[si]
    3bf3:	50                   	push   ax
    3bf4:	72 69                	jb     0x3c5f
    3bf6:	78 01                	js     0x3bf9
    3bf8:	00 2f                	add    BYTE PTR [bx],ch
    3bfa:	00 5c 3c             	add    BYTE PTR [si+0x3c],bl
    3bfd:	73 42                	jae    0x3c41
    3bff:	09 3c                	or     WORD PTR [si],di
    3c01:	01 00                	add    WORD PTR [bx+si],ax
    3c03:	00 00                	add    BYTE PTR [bx+si],al
    3c05:	00 00                	add    BYTE PTR [bx+si],al
    3c07:	97                   	xchg   di,ax
    3c08:	42                   	inc    dx
    3c09:	0f 3c                	(bad)
    3c0b:	00 00                	add    BYTE PTR [bx+si],al
    3c0d:	b2 42                	mov    dl,0x42
    3c0f:	cd 3c                	int    0x3c
    3c11:	55                   	push   bp
    3c12:	89 e5                	mov    bp,sp
    3c14:	b8 1a 00             	mov    ax,0x1a
    3c17:	9a 44 04 90 3c       	call   0x3c90:0x444
    3c1c:	83 ec 1a             	sub    sp,0x1a
    3c1f:	b8 0b 3c             	mov    ax,0x3c0b
    3c22:	0e                   	push   cs
    3c23:	50                   	push   ax
    3c24:	55                   	push   bp
    3c25:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3c29:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3c2d:	b8 01 3c             	mov    ax,0x3c01
    3c30:	0e                   	push   cs
    3c31:	50                   	push   ax
    3c32:	55                   	push   bp
    3c33:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3c37:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3c3b:	b8 f7 3b             	mov    ax,0x3bf7
    3c3e:	0e                   	push   cs
    3c3f:	50                   	push   ax
    3c40:	55                   	push   bp
    3c41:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3c45:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3c49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c4c:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    3c51:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3c54:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3c57:	06                   	push   es
    3c58:	57                   	push   di
    3c59:	9a d2 31 7e 3c       	call   0x3c7e:0x31d2
    3c5e:	6a 01                	push   0x1
    3c60:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3c63:	06                   	push   es
    3c64:	57                   	push   di
    3c65:	9a fb 2f 74 3c       	call   0x3c74:0x2ffb
    3c6a:	6a 00                	push   0x0
    3c6c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3c6f:	06                   	push   es
    3c70:	57                   	push   di
    3c71:	9a d2 2e bf 3c       	call   0x3cbf:0x2ed2
    3c76:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3c79:	06                   	push   es
    3c7a:	57                   	push   di
    3c7b:	9a bf 31 e2 3c       	call   0x3ce2:0x31bf
    3c80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c83:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    3c88:	2d 01 00             	sub    ax,0x1
    3c8b:	71 05                	jno    0x3c92
    3c8d:	9a 3e 04 f6 3c       	call   0x3cf6:0x43e
    3c92:	99                   	cwd
    3c93:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    3c96:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    3c99:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    3c9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ca0:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    3ca5:	99                   	cwd
    3ca6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3ca9:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    3cac:	c6 46 f6 00          	mov    BYTE PTR [bp-0xa],0x0
    3cb0:	8d 7e ea             	lea    di,[bp-0x16]
    3cb3:	16                   	push   ss
    3cb4:	57                   	push   di
    3cb5:	6a 01                	push   0x1
    3cb7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3cba:	06                   	push   es
    3cbb:	57                   	push   di
    3cbc:	9a 95 28 b8 3e       	call   0x3eb8:0x2895
    3cc1:	08 c0                	or     al,al
    3cc3:	75 0a                	jne    0x3ccf
    3cc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cc8:	06                   	push   es
    3cc9:	57                   	push   di
    3cca:	9a ca 0b 30 3f       	call   0x3f30:0xbca
    3ccf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cd2:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3cd7:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3cda:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3cdd:	06                   	push   es
    3cde:	57                   	push   di
    3cdf:	9a 3c 53 ec 3c       	call   0x3cec:0x533c
    3ce4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ce7:	06                   	push   es
    3ce8:	57                   	push   di
    3ce9:	9a 32 3b 03 3d       	call   0x3d03:0x3b32
    3cee:	2d 01 00             	sub    ax,0x1
    3cf1:	71 05                	jno    0x3cf8
    3cf3:	9a 3e 04 e0 3e       	call   0x3ee0:0x43e
    3cf8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3cfb:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3cfe:	06                   	push   es
    3cff:	57                   	push   di
    3d00:	9a af 3d 25 3d       	call   0x3d25:0x3daf
    3d05:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3d08:	7f 31                	jg     0x3d3b
    3d0a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3d0d:	eb 03                	jmp    0x3d12
    3d0f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3d12:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3d15:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3d18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d1b:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    3d20:	06                   	push   es
    3d21:	57                   	push   di
    3d22:	9a 4b 3b 31 3d       	call   0x3d31:0x3b4b
    3d27:	52                   	push   dx
    3d28:	50                   	push   ax
    3d29:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3d2c:	06                   	push   es
    3d2d:	57                   	push   di
    3d2e:	9a 70 3b 50 3d       	call   0x3d50:0x3b70
    3d33:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3d36:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3d39:	75 d4                	jne    0x3d0f
    3d3b:	6a 00                	push   0x0
    3d3d:	6a 00                	push   0x0
    3d3f:	6a 00                	push   0x0
    3d41:	6a 00                	push   0x0
    3d43:	bf 2c 3b             	mov    di,0x3b2c
    3d46:	0e                   	push   cs
    3d47:	57                   	push   di
    3d48:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3d4b:	06                   	push   es
    3d4c:	57                   	push   di
    3d4d:	9a 9b 3b 74 3d       	call   0x3d74:0x3b9b
    3d52:	89 c7                	mov    di,ax
    3d54:	8e c2                	mov    es,dx
    3d56:	06                   	push   es
    3d57:	57                   	push   di
    3d58:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d5b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3d5f:	6a 00                	push   0x0
    3d61:	6a 00                	push   0x0
    3d63:	6a 00                	push   0x0
    3d65:	6a 00                	push   0x0
    3d67:	bf 3d 3b             	mov    di,0x3b3d
    3d6a:	0e                   	push   cs
    3d6b:	57                   	push   di
    3d6c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3d6f:	06                   	push   es
    3d70:	57                   	push   di
    3d71:	9a 9b 3b 98 3d       	call   0x3d98:0x3b9b
    3d76:	89 c7                	mov    di,ax
    3d78:	8e c2                	mov    es,dx
    3d7a:	06                   	push   es
    3d7b:	57                   	push   di
    3d7c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d7f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3d83:	6a 00                	push   0x0
    3d85:	6a 00                	push   0x0
    3d87:	6a 00                	push   0x0
    3d89:	6a 00                	push   0x0
    3d8b:	bf 48 3b             	mov    di,0x3b48
    3d8e:	0e                   	push   cs
    3d8f:	57                   	push   di
    3d90:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3d93:	06                   	push   es
    3d94:	57                   	push   di
    3d95:	9a 9b 3b bc 3d       	call   0x3dbc:0x3b9b
    3d9a:	89 c7                	mov    di,ax
    3d9c:	8e c2                	mov    es,dx
    3d9e:	06                   	push   es
    3d9f:	57                   	push   di
    3da0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3da3:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3da7:	6a 00                	push   0x0
    3da9:	6a 00                	push   0x0
    3dab:	6a 00                	push   0x0
    3dad:	6a 00                	push   0x0
    3daf:	bf 59 3b             	mov    di,0x3b59
    3db2:	0e                   	push   cs
    3db3:	57                   	push   di
    3db4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3db7:	06                   	push   es
    3db8:	57                   	push   di
    3db9:	9a 9b 3b e0 3d       	call   0x3de0:0x3b9b
    3dbe:	89 c7                	mov    di,ax
    3dc0:	8e c2                	mov    es,dx
    3dc2:	06                   	push   es
    3dc3:	57                   	push   di
    3dc4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3dc7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3dcb:	6a 00                	push   0x0
    3dcd:	6a 00                	push   0x0
    3dcf:	6a 00                	push   0x0
    3dd1:	6a 00                	push   0x0
    3dd3:	bf 65 3b             	mov    di,0x3b65
    3dd6:	0e                   	push   cs
    3dd7:	57                   	push   di
    3dd8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ddb:	06                   	push   es
    3ddc:	57                   	push   di
    3ddd:	9a 9b 3b 00 3e       	call   0x3e00:0x3b9b
    3de2:	89 c7                	mov    di,ax
    3de4:	8e c2                	mov    es,dx
    3de6:	06                   	push   es
    3de7:	57                   	push   di
    3de8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3deb:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3def:	6a 00                	push   0x0
    3df1:	6a 00                	push   0x0
    3df3:	bf 79 3b             	mov    di,0x3b79
    3df6:	0e                   	push   cs
    3df7:	57                   	push   di
    3df8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3dfb:	06                   	push   es
    3dfc:	57                   	push   di
    3dfd:	9a 9b 3b 20 3e       	call   0x3e20:0x3b9b
    3e02:	89 c7                	mov    di,ax
    3e04:	8e c2                	mov    es,dx
    3e06:	06                   	push   es
    3e07:	57                   	push   di
    3e08:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e0b:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3e0f:	6a 00                	push   0x0
    3e11:	6a 00                	push   0x0
    3e13:	bf 87 3b             	mov    di,0x3b87
    3e16:	0e                   	push   cs
    3e17:	57                   	push   di
    3e18:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3e1b:	06                   	push   es
    3e1c:	57                   	push   di
    3e1d:	9a 9b 3b 40 3e       	call   0x3e40:0x3b9b
    3e22:	89 c7                	mov    di,ax
    3e24:	8e c2                	mov    es,dx
    3e26:	06                   	push   es
    3e27:	57                   	push   di
    3e28:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e2b:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3e2f:	6a 00                	push   0x0
    3e31:	6a 00                	push   0x0
    3e33:	bf 95 3b             	mov    di,0x3b95
    3e36:	0e                   	push   cs
    3e37:	57                   	push   di
    3e38:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3e3b:	06                   	push   es
    3e3c:	57                   	push   di
    3e3d:	9a 9b 3b 60 3e       	call   0x3e60:0x3b9b
    3e42:	89 c7                	mov    di,ax
    3e44:	8e c2                	mov    es,dx
    3e46:	06                   	push   es
    3e47:	57                   	push   di
    3e48:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e4b:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3e4f:	6a 00                	push   0x0
    3e51:	6a 00                	push   0x0
    3e53:	bf a9 3b             	mov    di,0x3ba9
    3e56:	0e                   	push   cs
    3e57:	57                   	push   di
    3e58:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3e5b:	06                   	push   es
    3e5c:	57                   	push   di
    3e5d:	9a 9b 3b 80 3e       	call   0x3e80:0x3b9b
    3e62:	89 c7                	mov    di,ax
    3e64:	8e c2                	mov    es,dx
    3e66:	06                   	push   es
    3e67:	57                   	push   di
    3e68:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e6b:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3e6f:	6a 00                	push   0x0
    3e71:	6a 00                	push   0x0
    3e73:	bf b9 3b             	mov    di,0x3bb9
    3e76:	0e                   	push   cs
    3e77:	57                   	push   di
    3e78:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3e7b:	06                   	push   es
    3e7c:	57                   	push   di
    3e7d:	9a 9b 3b 97 3e       	call   0x3e97:0x3b9b
    3e82:	89 c7                	mov    di,ax
    3e84:	8e c2                	mov    es,dx
    3e86:	06                   	push   es
    3e87:	57                   	push   di
    3e88:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e8b:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3e8f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3e92:	06                   	push   es
    3e93:	57                   	push   di
    3e94:	9a be 44 ac 3e       	call   0x3eac:0x44be
    3e99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e9c:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3ea1:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3ea4:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3ea7:	06                   	push   es
    3ea8:	57                   	push   di
    3ea9:	9a d2 31 ce 3e       	call   0x3ece:0x31d2
    3eae:	6a 01                	push   0x1
    3eb0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3eb3:	06                   	push   es
    3eb4:	57                   	push   di
    3eb5:	9a fb 2f c4 3e       	call   0x3ec4:0x2ffb
    3eba:	6a 00                	push   0x0
    3ebc:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ebf:	06                   	push   es
    3ec0:	57                   	push   di
    3ec1:	9a d2 2e 22 3f       	call   0x3f22:0x2ed2
    3ec6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ec9:	06                   	push   es
    3eca:	57                   	push   di
    3ecb:	9a bf 31 45 3f       	call   0x3f45:0x31bf
    3ed0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ed3:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    3ed8:	2d 01 00             	sub    ax,0x1
    3edb:	71 05                	jno    0x3ee2
    3edd:	9a 3e 04 59 3f       	call   0x3f59:0x43e
    3ee2:	99                   	cwd
    3ee3:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    3ee6:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    3ee9:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    3eed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ef0:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    3ef5:	99                   	cwd
    3ef6:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    3ef9:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    3efc:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    3f00:	c7 46 f6 01 00       	mov    WORD PTR [bp-0xa],0x1
    3f05:	c7 46 f8 00 00       	mov    WORD PTR [bp-0x8],0x0
    3f0a:	c6 46 fa 00          	mov    BYTE PTR [bp-0x6],0x0
    3f0e:	8d 7e e6             	lea    di,[bp-0x1a]
    3f11:	16                   	push   ss
    3f12:	57                   	push   di
    3f13:	6a 02                	push   0x2
    3f15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f18:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3f1d:	06                   	push   es
    3f1e:	57                   	push   di
    3f1f:	9a 95 28 5a 40       	call   0x405a:0x2895
    3f24:	08 c0                	or     al,al
    3f26:	75 0a                	jne    0x3f32
    3f28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f2b:	06                   	push   es
    3f2c:	57                   	push   di
    3f2d:	9a ca 0b 68 40       	call   0x4068:0xbca
    3f32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f35:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3f3a:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3f3d:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3f40:	06                   	push   es
    3f41:	57                   	push   di
    3f42:	9a 3c 53 4f 3f       	call   0x3f4f:0x533c
    3f47:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3f4a:	06                   	push   es
    3f4b:	57                   	push   di
    3f4c:	9a 32 3b 66 3f       	call   0x3f66:0x3b32
    3f51:	2d 01 00             	sub    ax,0x1
    3f54:	71 05                	jno    0x3f5b
    3f56:	9a 3e 04 18 40       	call   0x4018:0x43e
    3f5b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3f5e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3f61:	06                   	push   es
    3f62:	57                   	push   di
    3f63:	9a af 3d 88 3f       	call   0x3f88:0x3daf
    3f68:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3f6b:	7f 31                	jg     0x3f9e
    3f6d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3f70:	eb 03                	jmp    0x3f75
    3f72:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3f75:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3f78:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3f7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f7e:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3f83:	06                   	push   es
    3f84:	57                   	push   di
    3f85:	9a 4b 3b 94 3f       	call   0x3f94:0x3b4b
    3f8a:	52                   	push   dx
    3f8b:	50                   	push   ax
    3f8c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3f8f:	06                   	push   es
    3f90:	57                   	push   di
    3f91:	9a 70 3b af 3f       	call   0x3faf:0x3b70
    3f96:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f99:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3f9c:	75 d4                	jne    0x3f72
    3f9e:	6a 00                	push   0x0
    3fa0:	6a 00                	push   0x0
    3fa2:	bf c9 3b             	mov    di,0x3bc9
    3fa5:	0e                   	push   cs
    3fa6:	57                   	push   di
    3fa7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3faa:	06                   	push   es
    3fab:	57                   	push   di
    3fac:	9a 9b 3b cf 3f       	call   0x3fcf:0x3b9b
    3fb1:	89 c7                	mov    di,ax
    3fb3:	8e c2                	mov    es,dx
    3fb5:	06                   	push   es
    3fb6:	57                   	push   di
    3fb7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3fba:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3fbe:	6a 00                	push   0x0
    3fc0:	6a 00                	push   0x0
    3fc2:	bf d5 3b             	mov    di,0x3bd5
    3fc5:	0e                   	push   cs
    3fc6:	57                   	push   di
    3fc7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3fca:	06                   	push   es
    3fcb:	57                   	push   di
    3fcc:	9a 9b 3b ef 3f       	call   0x3fef:0x3b9b
    3fd1:	89 c7                	mov    di,ax
    3fd3:	8e c2                	mov    es,dx
    3fd5:	06                   	push   es
    3fd6:	57                   	push   di
    3fd7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3fda:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3fde:	6a 00                	push   0x0
    3fe0:	6a 00                	push   0x0
    3fe2:	bf e8 3b             	mov    di,0x3be8
    3fe5:	0e                   	push   cs
    3fe6:	57                   	push   di
    3fe7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3fea:	06                   	push   es
    3feb:	57                   	push   di
    3fec:	9a 9b 3b 06 40       	call   0x4006:0x3b9b
    3ff1:	89 c7                	mov    di,ax
    3ff3:	8e c2                	mov    es,dx
    3ff5:	06                   	push   es
    3ff6:	57                   	push   di
    3ff7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ffa:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    3ffe:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4001:	06                   	push   es
    4002:	57                   	push   di
    4003:	9a be 44 7d 40       	call   0x407d:0x44be
    4008:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    400b:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    4010:	2d 01 00             	sub    ax,0x1
    4013:	71 05                	jno    0x401a
    4015:	9a 3e 04 91 40       	call   0x4091:0x43e
    401a:	99                   	cwd
    401b:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    401e:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    4021:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    4025:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4028:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    402d:	99                   	cwd
    402e:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    4031:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    4034:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    4038:	c7 46 f6 02 00       	mov    WORD PTR [bp-0xa],0x2
    403d:	c7 46 f8 00 00       	mov    WORD PTR [bp-0x8],0x0
    4042:	c6 46 fa 00          	mov    BYTE PTR [bp-0x6],0x0
    4046:	8d 7e e6             	lea    di,[bp-0x1a]
    4049:	16                   	push   ss
    404a:	57                   	push   di
    404b:	6a 02                	push   0x2
    404d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4050:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    4055:	06                   	push   es
    4056:	57                   	push   di
    4057:	9a 95 28 5f 41       	call   0x415f:0x2895
    405c:	08 c0                	or     al,al
    405e:	75 0a                	jne    0x406a
    4060:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4063:	06                   	push   es
    4064:	57                   	push   di
    4065:	9a ca 0b c4 41       	call   0x41c4:0xbca
    406a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    406d:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    4072:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    4075:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    4078:	06                   	push   es
    4079:	57                   	push   di
    407a:	9a 3c 53 87 40       	call   0x4087:0x533c
    407f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4082:	06                   	push   es
    4083:	57                   	push   di
    4084:	9a 32 3b 9e 40       	call   0x409e:0x3b32
    4089:	2d 01 00             	sub    ax,0x1
    408c:	71 05                	jno    0x4093
    408e:	9a 3e 04 87 41       	call   0x4187:0x43e
    4093:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4096:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4099:	06                   	push   es
    409a:	57                   	push   di
    409b:	9a af 3d c0 40       	call   0x40c0:0x3daf
    40a0:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    40a3:	7f 31                	jg     0x40d6
    40a5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    40a8:	eb 03                	jmp    0x40ad
    40aa:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    40ad:	ff 76 fe             	push   WORD PTR [bp-0x2]
    40b0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    40b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40b6:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    40bb:	06                   	push   es
    40bc:	57                   	push   di
    40bd:	9a 4b 3b cc 40       	call   0x40cc:0x3b4b
    40c2:	52                   	push   dx
    40c3:	50                   	push   ax
    40c4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    40c7:	06                   	push   es
    40c8:	57                   	push   di
    40c9:	9a 70 3b e7 40       	call   0x40e7:0x3b70
    40ce:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    40d1:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    40d4:	75 d4                	jne    0x40aa
    40d6:	6a 00                	push   0x0
    40d8:	6a 00                	push   0x0
    40da:	bf c9 3b             	mov    di,0x3bc9
    40dd:	0e                   	push   cs
    40de:	57                   	push   di
    40df:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    40e2:	06                   	push   es
    40e3:	57                   	push   di
    40e4:	9a 9b 3b 07 41       	call   0x4107:0x3b9b
    40e9:	89 c7                	mov    di,ax
    40eb:	8e c2                	mov    es,dx
    40ed:	06                   	push   es
    40ee:	57                   	push   di
    40ef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40f2:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    40f6:	6a 00                	push   0x0
    40f8:	6a 00                	push   0x0
    40fa:	bf d5 3b             	mov    di,0x3bd5
    40fd:	0e                   	push   cs
    40fe:	57                   	push   di
    40ff:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4102:	06                   	push   es
    4103:	57                   	push   di
    4104:	9a 9b 3b 27 41       	call   0x4127:0x3b9b
    4109:	89 c7                	mov    di,ax
    410b:	8e c2                	mov    es,dx
    410d:	06                   	push   es
    410e:	57                   	push   di
    410f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4112:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    4116:	6a 00                	push   0x0
    4118:	6a 00                	push   0x0
    411a:	bf e8 3b             	mov    di,0x3be8
    411d:	0e                   	push   cs
    411e:	57                   	push   di
    411f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4122:	06                   	push   es
    4123:	57                   	push   di
    4124:	9a 9b 3b 3e 41       	call   0x413e:0x3b9b
    4129:	89 c7                	mov    di,ax
    412b:	8e c2                	mov    es,dx
    412d:	06                   	push   es
    412e:	57                   	push   di
    412f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4132:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    4136:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4139:	06                   	push   es
    413a:	57                   	push   di
    413b:	9a be 44 53 41       	call   0x4153:0x44be
    4140:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4143:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    4148:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    414b:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    414e:	06                   	push   es
    414f:	57                   	push   di
    4150:	9a d2 31 75 41       	call   0x4175:0x31d2
    4155:	6a 01                	push   0x1
    4157:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    415a:	06                   	push   es
    415b:	57                   	push   di
    415c:	9a fb 2f 6b 41       	call   0x416b:0x2ffb
    4161:	6a 00                	push   0x0
    4163:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4166:	06                   	push   es
    4167:	57                   	push   di
    4168:	9a d2 2e b6 41       	call   0x41b6:0x2ed2
    416d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4170:	06                   	push   es
    4171:	57                   	push   di
    4172:	9a bf 31 d9 41       	call   0x41d9:0x31bf
    4177:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    417a:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    417f:	2d 01 00             	sub    ax,0x1
    4182:	71 05                	jno    0x4189
    4184:	9a 3e 04 ed 41       	call   0x41ed:0x43e
    4189:	99                   	cwd
    418a:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    418d:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    4190:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    4194:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4197:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    419c:	99                   	cwd
    419d:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    41a0:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    41a3:	c6 46 f6 00          	mov    BYTE PTR [bp-0xa],0x0
    41a7:	8d 7e ea             	lea    di,[bp-0x16]
    41aa:	16                   	push   ss
    41ab:	57                   	push   di
    41ac:	6a 01                	push   0x1
    41ae:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    41b1:	06                   	push   es
    41b2:	57                   	push   di
    41b3:	9a 95 28 b3 45       	call   0x45b3:0x2895
    41b8:	08 c0                	or     al,al
    41ba:	75 0a                	jne    0x41c6
    41bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41bf:	06                   	push   es
    41c0:	57                   	push   di
    41c1:	9a ca 0b 44 42       	call   0x4244:0xbca
    41c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41c9:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    41ce:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    41d1:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    41d4:	06                   	push   es
    41d5:	57                   	push   di
    41d6:	9a 3c 53 e3 41       	call   0x41e3:0x533c
    41db:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    41de:	06                   	push   es
    41df:	57                   	push   di
    41e0:	9a 32 3b fa 41       	call   0x41fa:0x3b32
    41e5:	2d 01 00             	sub    ax,0x1
    41e8:	71 05                	jno    0x41ef
    41ea:	9a 3e 04 8c 42       	call   0x428c:0x43e
    41ef:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    41f2:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    41f5:	06                   	push   es
    41f6:	57                   	push   di
    41f7:	9a af 3d 1c 42       	call   0x421c:0x3daf
    41fc:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    41ff:	7f 31                	jg     0x4232
    4201:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4204:	eb 03                	jmp    0x4209
    4206:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4209:	ff 76 fe             	push   WORD PTR [bp-0x2]
    420c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    420f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4212:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    4217:	06                   	push   es
    4218:	57                   	push   di
    4219:	9a 4b 3b 28 42       	call   0x4228:0x3b4b
    421e:	52                   	push   dx
    421f:	50                   	push   ax
    4220:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4223:	06                   	push   es
    4224:	57                   	push   di
    4225:	9a 70 3b 3a 42       	call   0x423a:0x3b70
    422a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    422d:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    4230:	75 d4                	jne    0x4206
    4232:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4235:	06                   	push   es
    4236:	57                   	push   di
    4237:	9a be 44 bf 42       	call   0x42bf:0x44be
    423c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    423f:	06                   	push   es
    4240:	57                   	push   di
    4241:	9a 06 2e 52 42       	call   0x4252:0x2e06
    4246:	6a ff                	push   0xffff
    4248:	6a fa                	push   0xfffa
    424a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    424d:	06                   	push   es
    424e:	57                   	push   di
    424f:	9a af 2b 5e 42       	call   0x425e:0x2baf
    4254:	6a 00                	push   0x0
    4256:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4259:	06                   	push   es
    425a:	57                   	push   di
    425b:	9a b7 2c 68 42       	call   0x4268:0x2cb7
    4260:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4263:	06                   	push   es
    4264:	57                   	push   di
    4265:	9a 26 37 9f 42       	call   0x429f:0x3726
    426a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    426e:	83 c4 06             	add    sp,0x6
    4271:	eb 1b                	jmp    0x428e
    4273:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4276:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    4279:	ff 76 fc             	push   WORD PTR [bp-0x4]
    427c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    427f:	9a 2d 34 9e 52       	call   0x529e:0x342d
    4284:	9a c3 28 33 63       	call   0x6333:0x28c3
    4289:	9a 34 14 a4 42       	call   0x42a4:0x1434
    428e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4292:	83 c4 06             	add    sp,0x6
    4295:	eb 0f                	jmp    0x42a6
    4297:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    429a:	06                   	push   es
    429b:	57                   	push   di
    429c:	9a de 37 f3 42       	call   0x42f3:0x37de
    42a1:	9a 34 14 58 45       	call   0x4558:0x1434
    42a6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    42aa:	83 c4 06             	add    sp,0x6
    42ad:	b8 e0 42             	mov    ax,0x42e0
    42b0:	0e                   	push   cs
    42b1:	50                   	push   ax
    42b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42b5:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    42ba:	06                   	push   es
    42bb:	57                   	push   di
    42bc:	9a d2 31 ce 42       	call   0x42ce:0x31d2
    42c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42c4:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    42c9:	06                   	push   es
    42ca:	57                   	push   di
    42cb:	9a d2 31 dd 42       	call   0x42dd:0x31d2
    42d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42d3:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    42d8:	06                   	push   es
    42d9:	57                   	push   di
    42da:	9a d2 31 a6 45       	call   0x45a6:0x31d2
    42df:	cb                   	retf
    42e0:	c9                   	leave
    42e1:	ca 04 00             	retf   0x4
    42e4:	0a 48 53             	or     cl,BYTE PTR [bx+si+0x53]
    42e7:	56                   	push   si
    42e8:	6f                   	outs   dx,WORD PTR ds:[si]
    42e9:	6c                   	ins    BYTE PTR es:[di],dx
    42ea:	75 6d                	jne    0x4359
    42ec:	65 50                	gs push ax
    42ee:	43                   	inc    bx
    42ef:	00 00                	add    BYTE PTR [bx+si],al
    42f1:	3f                   	aas
    42f2:	46                   	inc    si
    42f3:	48                   	dec    ax
    42f4:	43                   	inc    bx
    42f5:	10 48 65             	adc    BYTE PTR [bx+si+0x65],cl
    42f8:	75 72                	jne    0x436c
    42fa:	65 73 50             	gs jae 0x434d
    42fd:	61                   	popa
    42fe:	72 4d                	jb     0x434d
    4300:	61                   	popa
    4301:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4304:	6e                   	outs   dx,BYTE PTR ds:[si]
    4305:	65 12 48 65          	adc    cl,BYTE PTR gs:[bx+si+0x65]
    4309:	75 72                	jne    0x437d
    430b:	65 73 50             	gs jae 0x435e
    430e:	61                   	popa
    430f:	72 50                	jb     0x4361
    4311:	72 6f                	jb     0x4382
    4313:	64 75 63             	fs jne 0x4379
    4316:	74 69                	je     0x4381
    4318:	66 0f 46 6f 72       	cmovbe ebp,DWORD PTR [bx+0x72]
    431d:	6d                   	ins    WORD PTR es:[di],dx
    431e:	61                   	popa
    431f:	74 69                	je     0x438a
    4321:	6f                   	outs   dx,WORD PTR ds:[si]
    4322:	6e                   	outs   dx,BYTE PTR ds:[si]
    4323:	4d                   	dec    bp
    4324:	69 6e 69 50 63       	imul   bp,WORD PTR [bp+0x69],0x6350
    4329:	12 50 72             	adc    dl,BYTE PTR [bx+si+0x72]
    432c:	6f                   	outs   dx,WORD PTR ds:[si]
    432d:	64 75 63             	fs jne 0x4393
    4330:	74 69                	je     0x439b
    4332:	66 73 50             	data32 jae 0x4385
    4335:	61                   	popa
    4336:	72 43                	jb     0x437b
    4338:	61                   	popa
    4339:	64 72 65             	fs jb  0x43a1
    433c:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    4340:	ff                   	(bad)
    4341:	7f 00                	jg     0x4343
    4343:	00 00                	add    BYTE PTR [bx+si],al
    4345:	00 6f 47             	add    BYTE PTR [bx+0x47],ch
    4348:	87 43 01             	xchg   WORD PTR [bp+di+0x1],ax
    434b:	00 00                	add    BYTE PTR [bx+si],al
    434d:	00 02                	add    BYTE PTR [bp+si],al
    434f:	00 00                	add    BYTE PTR [bx+si],al
    4351:	00 0b                	add    BYTE PTR [bp+di],cl
    4353:	50                   	push   ax
    4354:	72 69                	jb     0x43bf
    4356:	78 4d                	js     0x43a5
    4358:	61                   	popa
    4359:	78 69                	js     0x43c4
    435b:	6d                   	ins    WORD PTR es:[di],dx
    435c:	75 6d                	jne    0x43cb
    435e:	12 41 70             	adc    al,BYTE PTR [bx+di+0x70]
    4361:	70 65                	jo     0x43c8
    4363:	6c                   	ins    BYTE PTR es:[di],dx
    4364:	4f                   	dec    di
    4365:	66 66 72 65          	data32 data32 jb 0x43ce
    4369:	51                   	push   cx
    436a:	75 61                	jne    0x43cd
    436c:	6e                   	outs   dx,BYTE PTR ds:[si]
    436d:	74 69                	je     0x43d8
    436f:	74 65                	je     0x43d6
    4371:	11 41 70             	adc    WORD PTR [bx+di+0x70],ax
    4374:	70 65                	jo     0x43db
    4376:	6c                   	ins    BYTE PTR es:[di],dx
    4377:	4f                   	dec    di
    4378:	66 66 72 65          	data32 data32 jb 0x43e1
    437c:	50                   	push   ax
    437d:	72 69                	jb     0x43e8
    437f:	78 4d                	js     0x43ce
    4381:	61                   	popa
    4382:	78 00                	js     0x4384
    4384:	00 e7                	add    bh,ah
    4386:	48                   	dec    ax
    4387:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    4388:	43                   	inc    bx
    4389:	08 4d 61             	or     BYTE PTR [di+0x61],cl
    438c:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    438f:	6e                   	outs   dx,BYTE PTR ds:[si]
    4390:	65 73 07             	gs jae 0x439a
    4393:	45                   	inc    bp
    4394:	6d                   	ins    WORD PTR es:[di],dx
    4395:	70 72                	jo     0x4409
    4397:	75 6e                	jne    0x4407
    4399:	74 06                	je     0x43a1
    439b:	43                   	inc    bx
    439c:	61                   	popa
    439d:	64 72 65             	fs jb  0x4405
    43a0:	73 00                	jae    0x43a2
    43a2:	00 10                	add    BYTE PTR [bx+si],dl
    43a4:	4a                   	dec    dx
    43a5:	d2 43 01             	rol    BYTE PTR [bp+di+0x1],cl
    43a8:	00 00                	add    BYTE PTR [bx+si],al
    43aa:	00 02                	add    BYTE PTR [bp+si],al
    43ac:	00 00                	add    BYTE PTR [bx+si],al
    43ae:	00 15                	add    BYTE PTR [di],dl
    43b0:	54                   	push   sp
    43b1:	65 6d                	gs ins WORD PTR es:[di],dx
    43b3:	70 73                	jo     0x4428
    43b5:	46                   	inc    si
    43b6:	61                   	popa
    43b7:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    43ba:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    43bd:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    43c2:	74 75                	je     0x4439
    43c4:	72 08                	jb     0x43ce
    43c6:	51                   	push   cx
    43c7:	74 65                	je     0x442e
    43c9:	53                   	push   bx
    43ca:	74 6f                	je     0x443b
    43cc:	63 6b 00             	arpl   WORD PTR [bp+di+0x0],bp
    43cf:	00 72 4b             	add    BYTE PTR [bp+si+0x4b],dh
    43d2:	0b 46 0a             	or     ax,WORD PTR [bp+0xa]
    43d5:	44                   	inc    sp
    43d6:	69 76 69 64 65       	imul   si,WORD PTR [bp+0x69],0x6564
    43db:	6e                   	outs   dx,BYTE PTR ds:[si]
    43dc:	64 65 73 00          	fs gs jae 0x43e0
    43e0:	00 00                	add    BYTE PTR [bx+si],al
    43e2:	00 10                	add    BYTE PTR [bx+si],dl
    43e4:	56                   	push   si
    43e5:	61                   	popa
    43e6:	72 69                	jb     0x4451
    43e8:	61                   	popa
    43e9:	74 69                	je     0x4454
    43eb:	6f                   	outs   dx,WORD PTR ds:[si]
    43ec:	6e                   	outs   dx,BYTE PTR ds:[si]
    43ed:	45                   	inc    bp
    43ee:	6d                   	ins    WORD PTR es:[di],dx
    43ef:	70 72                	jo     0x4463
    43f1:	75 6e                	jne    0x4461
    43f3:	74 0b                	je     0x4400
    43f5:	53                   	push   bx
    43f6:	75 62                	jne    0x445a
    43f8:	76 65                	jbe    0x445f
    43fa:	6e                   	outs   dx,BYTE PTR ds:[si]
    43fb:	74 69                	je     0x4466
    43fd:	6f                   	outs   dx,WORD PTR ds:[si]
    43fe:	6e                   	outs   dx,BYTE PTR ds:[si]
    43ff:	73 0d                	jae    0x440e
    4401:	41                   	inc    cx
    4402:	63 68 61             	arpl   WORD PTR [bx+si+0x61],bp
    4405:	74 4d                	je     0x4454
    4407:	61                   	popa
    4408:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    440b:	6e                   	outs   dx,BYTE PTR ds:[si]
    440c:	65 73 0d             	gs jae 0x441c
    440f:	56                   	push   si
    4410:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4412:	74 65                	je     0x4479
    4414:	4d                   	dec    bp
    4415:	61                   	popa
    4416:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4419:	6e                   	outs   dx,BYTE PTR ds:[si]
    441a:	65 73 13             	gs jae 0x4430
    441d:	45                   	inc    bp
    441e:	6e                   	outs   dx,BYTE PTR ds:[si]
    441f:	74 72                	je     0x4493
    4421:	65 74 69             	gs je  0x448d
    4424:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4426:	4d                   	dec    bp
    4427:	61                   	popa
    4428:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    442b:	6e                   	outs   dx,BYTE PTR ds:[si]
    442c:	65 73 50             	gs jae 0x447f
    442f:	63 00                	arpl   WORD PTR [bx+si],ax
    4431:	00 c8                	add    al,cl
    4433:	42                   	inc    dx
    4434:	0f 43 61 64          	cmovae sp,WORD PTR [bx+di+0x64]
    4438:	72 65                	jb     0x449f
    443a:	73 45                	jae    0x4481
    443c:	6d                   	ins    WORD PTR es:[di],dx
    443d:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    4440:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    4443:	73 0f                	jae    0x4454
    4445:	43                   	inc    bx
    4446:	61                   	popa
    4447:	64 72 65             	fs jb  0x44af
    444a:	73 4c                	jae    0x4498
    444c:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    4451:	69 65 73 01 00       	imul   sp,WORD PTR [di+0x73],0x1
    4456:	00 00                	add    BYTE PTR [bx+si],al
    4458:	02 00                	add    al,BYTE PTR [bx+si]
    445a:	00 00                	add    BYTE PTR [bx+si],al
    445c:	0e                   	push   cs
    445d:	49                   	dec    cx
    445e:	6e                   	outs   dx,BYTE PTR ds:[si]
    445f:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    4465:	6c                   	ins    BYTE PTR es:[di],dx
    4466:	61                   	popa
    4467:	69 72 65 73 00       	imul   si,WORD PTR [bp+si+0x65],0x73
    446c:	00 80 3f 00          	add    BYTE PTR [bx+si+0x3f],al
    4470:	50                   	push   ax
    4471:	c3                   	ret
    4472:	47                   	inc    di
    4473:	0e                   	push   cs
    4474:	43                   	inc    bx
    4475:	6f                   	outs   dx,WORD PTR ds:[si]
    4476:	6d                   	ins    WORD PTR es:[di],dx
    4477:	6d                   	ins    WORD PTR es:[di],dx
    4478:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    447d:	6e                   	outs   dx,BYTE PTR ds:[si]
    447e:	46                   	inc    si
    447f:	56                   	push   si
    4480:	70 63                	jo     0x44e5
    4482:	00 00                	add    BYTE PTR [bx+si],al
    4484:	70 41                	jo     0x44c7
    4486:	0b 46 6f             	or     ax,WORD PTR [bp+0x6f]
    4489:	72 6d                	jb     0x44f8
    448b:	61                   	popa
    448c:	74 69                	je     0x44f7
    448e:	6f                   	outs   dx,WORD PTR ds:[si]
    448f:	6e                   	outs   dx,BYTE PTR ds:[si]
    4490:	50                   	push   ax
    4491:	63 06 45 74          	arpl   WORD PTR ds:0x7445,ax
    4495:	75 64                	jne    0x44fb
    4497:	65 73 11             	gs jae 0x44ab
    449a:	4d                   	dec    bp
    449b:	61                   	popa
    449c:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    449f:	6e                   	outs   dx,BYTE PTR ds:[si]
    44a0:	65 73 41             	gs jae 0x44e4
    44a3:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    44a9:	65 73 12             	gs jae 0x44be
    44ac:	50                   	push   ax
    44ad:	72 6f                	jb     0x451e
    44af:	64 75 63             	fs jne 0x4515
    44b2:	74 69                	je     0x451d
    44b4:	66 73 41             	data32 jae 0x44f8
    44b7:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    44bd:	73 0a                	jae    0x44c9
    44bf:	50                   	push   ax
    44c0:	72 6f                	jb     0x4531
    44c2:	64 75 63             	fs jne 0x4528
    44c5:	74 69                	je     0x4530
    44c7:	6f                   	outs   dx,WORD PTR ds:[si]
    44c8:	6e                   	outs   dx,BYTE PTR ds:[si]
    44c9:	04 50                	add    al,0x50
    44cb:	72 69                	jb     0x4536
    44cd:	78 00                	js     0x44cf
    44cf:	00 00                	add    BYTE PTR [bx+si],al
    44d1:	40                   	inc    ax
    44d2:	09 50 75             	or     WORD PTR [bx+si+0x75],dx
    44d5:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
    44d8:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    44db:	65 11 41 63          	adc    WORD PTR gs:[bx+di+0x63],ax
    44df:	74 69                	je     0x454a
    44e1:	6f                   	outs   dx,WORD PTR ds:[si]
    44e2:	6e                   	outs   dx,BYTE PTR ds:[si]
    44e3:	43                   	inc    bx
    44e4:	6f                   	outs   dx,WORD PTR ds:[si]
    44e5:	6d                   	ins    WORD PTR es:[di],dx
    44e6:	6d                   	ins    WORD PTR es:[di],dx
    44e7:	65 72 63             	gs jb  0x454d
    44ea:	69 61 6c 65 10       	imul   sp,WORD PTR [bx+di+0x6c],0x1065
    44ef:	56                   	push   si
    44f0:	65 6e                	outs   dx,BYTE PTR gs:[si]
    44f2:	64 65 75 72          	fs gs jne 0x4568
    44f6:	73 41                	jae    0x4539
    44f8:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    44fe:	73 11                	jae    0x4511
    4500:	44                   	inc    sp
    4501:	75 72                	jne    0x4575
    4503:	65 65 43             	gs gs inc bx
    4506:	72 65                	jb     0x456d
    4508:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    450e:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4510:	74 0b                	je     0x451d
    4512:	4c                   	dec    sp
    4513:	69 71 75 69 64       	imul   si,WORD PTR [bx+di+0x75],0x6469
    4518:	61                   	popa
    4519:	74 69                	je     0x4584
    451b:	6f                   	outs   dx,WORD PTR ds:[si]
    451c:	6e                   	outs   dx,BYTE PTR ds:[si]
    451d:	12 53 6f             	adc    dl,BYTE PTR [bp+di+0x6f]
    4520:	75 6d                	jne    0x458f
    4522:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    4527:	6e                   	outs   dx,BYTE PTR ds:[si]
    4528:	51                   	push   cx
    4529:	75 61                	jne    0x458c
    452b:	6e                   	outs   dx,BYTE PTR ds:[si]
    452c:	74 69                	je     0x4597
    452e:	74 65                	je     0x4595
    4530:	0e                   	push   cs
    4531:	53                   	push   bx
    4532:	6f                   	outs   dx,WORD PTR ds:[si]
    4533:	75 6d                	jne    0x45a2
    4535:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    453a:	6e                   	outs   dx,BYTE PTR ds:[si]
    453b:	50                   	push   ax
    453c:	72 69                	jb     0x45a7
    453e:	78 00                	js     0x4540
    4540:	80 ff ff             	cmp    bh,0xff
    4543:	ff                   	(bad)
    4544:	7f 00                	jg     0x4546
    4546:	00 eb                	add    bl,ch
    4548:	ff                   	(bad)
    4549:	ff                   	(bad)
    454a:	ff                   	(bad)
    454b:	ff                   	(bad)
    454c:	ff                   	(bad)
    454d:	ff 02                	inc    WORD PTR [bp+si]
    454f:	55                   	push   bp
    4550:	89 e5                	mov    bp,sp
    4552:	b8 10 02             	mov    ax,0x210
    4555:	9a 44 04 5e 47       	call   0x475e:0x444
    455a:	81 ec 10 02          	sub    sp,0x210
    455e:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    4563:	7c 07                	jl     0x456c
    4565:	c7 46 92 02 00       	mov    WORD PTR [bp-0x6e],0x2
    456a:	eb 05                	jmp    0x4571
    456c:	c7 46 92 01 00       	mov    WORD PTR [bp-0x6e],0x1
    4571:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4574:	26 8b 85 dc 01       	mov    ax,WORD PTR es:[di+0x1dc]
    4579:	26 8b 95 de 01       	mov    dx,WORD PTR es:[di+0x1de]
    457e:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    4581:	89 56 d0             	mov    WORD PTR [bp-0x30],dx
    4584:	26 8b 85 e0 01       	mov    ax,WORD PTR es:[di+0x1e0]
    4589:	26 8b 95 e2 01       	mov    dx,WORD PTR es:[di+0x1e2]
    458e:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    4591:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    4594:	26 c4 bd 18 02       	les    di,DWORD PTR es:[di+0x218]
    4599:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    459d:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    45a1:	06                   	push   es
    45a2:	57                   	push   di
    45a3:	9a d2 31 cb 45       	call   0x45cb:0x31d2
    45a8:	6a 01                	push   0x1
    45aa:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    45ae:	06                   	push   es
    45af:	57                   	push   di
    45b0:	9a fb 2f c0 45       	call   0x45c0:0x2ffb
    45b5:	6a 00                	push   0x0
    45b7:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    45bb:	06                   	push   es
    45bc:	57                   	push   di
    45bd:	9a d2 2e fd 45       	call   0x45fd:0x2ed2
    45c2:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    45c6:	06                   	push   es
    45c7:	57                   	push   di
    45c8:	9a bf 31 1d 46       	call   0x461d:0x31bf
    45cd:	b8 ef 42             	mov    ax,0x42ef
    45d0:	0e                   	push   cs
    45d1:	50                   	push   ax
    45d2:	55                   	push   bp
    45d3:	ff 36 58 18          	push   WORD PTR ds:0x1858
    45d7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    45db:	c7 86 ec fe 01 00    	mov    WORD PTR [bp-0x114],0x1
    45e1:	c7 86 ee fe 00 00    	mov    WORD PTR [bp-0x112],0x0
    45e7:	c6 86 f0 fe 00       	mov    BYTE PTR [bp-0x110],0x0
    45ec:	8d be ec fe          	lea    di,[bp-0x114]
    45f0:	16                   	push   ss
    45f1:	57                   	push   di
    45f2:	6a 00                	push   0x0
    45f4:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    45f8:	06                   	push   es
    45f9:	57                   	push   di
    45fa:	9a 95 28 6d 46       	call   0x466d:0x2895
    45ff:	08 c0                	or     al,al
    4601:	75 0c                	jne    0x460f
    4603:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4606:	06                   	push   es
    4607:	57                   	push   di
    4608:	9a 7b 0b ca 46       	call   0x46ca:0xb7b
    460d:	eb 24                	jmp    0x4633
    460f:	bf e4 42             	mov    di,0x42e4
    4612:	0e                   	push   cs
    4613:	57                   	push   di
    4614:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4618:	06                   	push   es
    4619:	57                   	push   di
    461a:	9a 9b 3b 48 46       	call   0x4648:0x3b9b
    461f:	89 c7                	mov    di,ax
    4621:	8e c2                	mov    es,dx
    4623:	06                   	push   es
    4624:	57                   	push   di
    4625:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4628:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    462c:	9b dd 9e 44 ff       	fstp   QWORD PTR [bp-0xbc]
    4631:	90                   	nop
    4632:	9b                   	fwait
    4633:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4637:	83 c4 06             	add    sp,0x6
    463a:	b8 4b 46             	mov    ax,0x464b
    463d:	0e                   	push   cs
    463e:	50                   	push   ax
    463f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4643:	06                   	push   es
    4644:	57                   	push   di
    4645:	9a d2 31 60 46       	call   0x4660:0x31d2
    464a:	cb                   	retf
    464b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    464e:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    4653:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    4657:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    465b:	06                   	push   es
    465c:	57                   	push   di
    465d:	9a d2 31 85 46       	call   0x4685:0x31d2
    4662:	6a 01                	push   0x1
    4664:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4668:	06                   	push   es
    4669:	57                   	push   di
    466a:	9a fb 2f 7a 46       	call   0x467a:0x2ffb
    466f:	6a 00                	push   0x0
    4671:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4675:	06                   	push   es
    4676:	57                   	push   di
    4677:	9a d2 2e bc 46       	call   0x46bc:0x2ed2
    467c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4680:	06                   	push   es
    4681:	57                   	push   di
    4682:	9a bf 31 dd 46       	call   0x46dd:0x31bf
    4687:	b8 44 43             	mov    ax,0x4344
    468a:	0e                   	push   cs
    468b:	50                   	push   ax
    468c:	55                   	push   bp
    468d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4691:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4695:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4698:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    469d:	99                   	cwd
    469e:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    46a2:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    46a6:	c6 86 f0 fe 00       	mov    BYTE PTR [bp-0x110],0x0
    46ab:	8d be ec fe          	lea    di,[bp-0x114]
    46af:	16                   	push   ss
    46b0:	57                   	push   di
    46b1:	6a 00                	push   0x0
    46b3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    46b7:	06                   	push   es
    46b8:	57                   	push   di
    46b9:	9a 95 28 9d 47       	call   0x479d:0x2895
    46be:	08 c0                	or     al,al
    46c0:	75 0d                	jne    0x46cf
    46c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46c5:	06                   	push   es
    46c6:	57                   	push   di
    46c7:	9a 7b 0b 26 48       	call   0x4826:0xb7b
    46cc:	e9 94 00             	jmp    0x4763
    46cf:	bf f5 42             	mov    di,0x42f5
    46d2:	0e                   	push   cs
    46d3:	57                   	push   di
    46d4:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    46d8:	06                   	push   es
    46d9:	57                   	push   di
    46da:	9a 9b 3b 01 47       	call   0x4701:0x3b9b
    46df:	89 c7                	mov    di,ax
    46e1:	8e c2                	mov    es,dx
    46e3:	06                   	push   es
    46e4:	57                   	push   di
    46e5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46e8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    46ec:	9b dd 9e 54 ff       	fstp   QWORD PTR [bp-0xac]
    46f1:	90                   	nop
    46f2:	9b                   	fwait
    46f3:	bf 06 43             	mov    di,0x4306
    46f6:	0e                   	push   cs
    46f7:	57                   	push   di
    46f8:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    46fc:	06                   	push   es
    46fd:	57                   	push   di
    46fe:	9a 9b 3b 25 47       	call   0x4725:0x3b9b
    4703:	89 c7                	mov    di,ax
    4705:	8e c2                	mov    es,dx
    4707:	06                   	push   es
    4708:	57                   	push   di
    4709:	26 c4 3d             	les    di,DWORD PTR es:[di]
    470c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4710:	9b dd 9e 4c ff       	fstp   QWORD PTR [bp-0xb4]
    4715:	90                   	nop
    4716:	9b                   	fwait
    4717:	bf 19 43             	mov    di,0x4319
    471a:	0e                   	push   cs
    471b:	57                   	push   di
    471c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4720:	06                   	push   es
    4721:	57                   	push   di
    4722:	9a 9b 3b 49 47       	call   0x4749:0x3b9b
    4727:	89 c7                	mov    di,ax
    4729:	8e c2                	mov    es,dx
    472b:	06                   	push   es
    472c:	57                   	push   di
    472d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4730:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4734:	9b dd 9e 78 ff       	fstp   QWORD PTR [bp-0x88]
    4739:	90                   	nop
    473a:	9b                   	fwait
    473b:	bf 29 43             	mov    di,0x4329
    473e:	0e                   	push   cs
    473f:	57                   	push   di
    4740:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4744:	06                   	push   es
    4745:	57                   	push   di
    4746:	9a 9b 3b 78 47       	call   0x4778:0x3b9b
    474b:	89 c7                	mov    di,ax
    474d:	8e c2                	mov    es,dx
    474f:	06                   	push   es
    4750:	57                   	push   di
    4751:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4754:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4758:	bf 3c 43             	mov    di,0x433c
    475b:	9a 16 04 52 48       	call   0x4852:0x416
    4760:	89 46 94             	mov    WORD PTR [bp-0x6c],ax
    4763:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4767:	83 c4 06             	add    sp,0x6
    476a:	b8 7b 47             	mov    ax,0x477b
    476d:	0e                   	push   cs
    476e:	50                   	push   ax
    476f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4773:	06                   	push   es
    4774:	57                   	push   di
    4775:	9a d2 31 90 47       	call   0x4790:0x31d2
    477a:	cb                   	retf
    477b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    477e:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    4783:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    4787:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    478b:	06                   	push   es
    478c:	57                   	push   di
    478d:	9a d2 31 b5 47       	call   0x47b5:0x31d2
    4792:	6a 01                	push   0x1
    4794:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4798:	06                   	push   es
    4799:	57                   	push   di
    479a:	9a fb 2f aa 47       	call   0x47aa:0x2ffb
    479f:	6a 00                	push   0x0
    47a1:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    47a5:	06                   	push   es
    47a6:	57                   	push   di
    47a7:	9a d2 2e 18 48       	call   0x4818:0x2ed2
    47ac:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    47b0:	06                   	push   es
    47b1:	57                   	push   di
    47b2:	9a bf 31 39 48       	call   0x4839:0x31bf
    47b7:	b8 83 43             	mov    ax,0x4383
    47ba:	0e                   	push   cs
    47bb:	50                   	push   ax
    47bc:	55                   	push   bp
    47bd:	ff 36 58 18          	push   WORD PTR ds:0x1858
    47c1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    47c5:	8b 46 92             	mov    ax,WORD PTR [bp-0x6e]
    47c8:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    47cc:	b8 01 00             	mov    ax,0x1
    47cf:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    47d3:	7e 03                	jle    0x47d8
    47d5:	e9 03 01             	jmp    0x48db
    47d8:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    47db:	eb 03                	jmp    0x47e0
    47dd:	ff 46 90             	inc    WORD PTR [bp-0x70]
    47e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47e3:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    47e8:	99                   	cwd
    47e9:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    47ed:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    47f1:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    47f6:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    47f9:	99                   	cwd
    47fa:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    47fe:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    4802:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    4807:	8d be e2 fe          	lea    di,[bp-0x11e]
    480b:	16                   	push   ss
    480c:	57                   	push   di
    480d:	6a 01                	push   0x1
    480f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4813:	06                   	push   es
    4814:	57                   	push   di
    4815:	9a 95 28 15 49       	call   0x4915:0x2895
    481a:	08 c0                	or     al,al
    481c:	75 0d                	jne    0x482b
    481e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4821:	06                   	push   es
    4822:	57                   	push   di
    4823:	9a 7b 0b 92 49       	call   0x4992:0xb7b
    4828:	e9 a4 00             	jmp    0x48cf
    482b:	bf 52 43             	mov    di,0x4352
    482e:	0e                   	push   cs
    482f:	57                   	push   di
    4830:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4834:	06                   	push   es
    4835:	57                   	push   di
    4836:	9a 9b 3b 6e 48       	call   0x486e:0x3b9b
    483b:	89 c7                	mov    di,ax
    483d:	8e c2                	mov    es,dx
    483f:	06                   	push   es
    4840:	57                   	push   di
    4841:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4844:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4848:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    484b:	99                   	cwd
    484c:	bf 4a 43             	mov    di,0x434a
    484f:	9a 16 04 8b 48       	call   0x488b:0x416
    4854:	8b f8                	mov    di,ax
    4856:	c1 e7 03             	shl    di,0x3
    4859:	9b dd 9b 78 ff       	fstp   QWORD PTR [bp+di-0x88]
    485e:	90                   	nop
    485f:	9b                   	fwait
    4860:	bf 5e 43             	mov    di,0x435e
    4863:	0e                   	push   cs
    4864:	57                   	push   di
    4865:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4869:	06                   	push   es
    486a:	57                   	push   di
    486b:	9a 9b 3b a8 48       	call   0x48a8:0x3b9b
    4870:	89 c7                	mov    di,ax
    4872:	8e c2                	mov    es,dx
    4874:	06                   	push   es
    4875:	57                   	push   di
    4876:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4879:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    487d:	8b c8                	mov    cx,ax
    487f:	8b da                	mov    bx,dx
    4881:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    4884:	99                   	cwd
    4885:	bf 4a 43             	mov    di,0x434a
    4888:	9a 16 04 c1 48       	call   0x48c1:0x416
    488d:	8b f8                	mov    di,ax
    488f:	c1 e7 02             	shl    di,0x2
    4892:	89 8b 6c ff          	mov    WORD PTR [bp+di-0x94],cx
    4896:	89 9b 6e ff          	mov    WORD PTR [bp+di-0x92],bx
    489a:	bf 71 43             	mov    di,0x4371
    489d:	0e                   	push   cs
    489e:	57                   	push   di
    489f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    48a3:	06                   	push   es
    48a4:	57                   	push   di
    48a5:	9a 9b 3b f0 48       	call   0x48f0:0x3b9b
    48aa:	89 c7                	mov    di,ax
    48ac:	8e c2                	mov    es,dx
    48ae:	06                   	push   es
    48af:	57                   	push   di
    48b0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48b3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48b7:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    48ba:	99                   	cwd
    48bb:	bf 4a 43             	mov    di,0x434a
    48be:	9a 16 04 4d 49       	call   0x494d:0x416
    48c3:	8b f8                	mov    di,ax
    48c5:	c1 e7 03             	shl    di,0x3
    48c8:	9b dd 9b 58 ff       	fstp   QWORD PTR [bp+di-0xa8]
    48cd:	90                   	nop
    48ce:	9b                   	fwait
    48cf:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    48d2:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    48d6:	74 03                	je     0x48db
    48d8:	e9 02 ff             	jmp    0x47dd
    48db:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    48df:	83 c4 06             	add    sp,0x6
    48e2:	b8 f3 48             	mov    ax,0x48f3
    48e5:	0e                   	push   cs
    48e6:	50                   	push   ax
    48e7:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    48eb:	06                   	push   es
    48ec:	57                   	push   di
    48ed:	9a d2 31 08 49       	call   0x4908:0x31d2
    48f2:	cb                   	retf
    48f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48f6:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    48fb:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    48ff:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    4903:	06                   	push   es
    4904:	57                   	push   di
    4905:	9a d2 31 2d 49       	call   0x492d:0x31d2
    490a:	6a 01                	push   0x1
    490c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4910:	06                   	push   es
    4911:	57                   	push   di
    4912:	9a fb 2f 22 49       	call   0x4922:0x2ffb
    4917:	6a 00                	push   0x0
    4919:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    491d:	06                   	push   es
    491e:	57                   	push   di
    491f:	9a d2 2e 84 49       	call   0x4984:0x2ed2
    4924:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4928:	06                   	push   es
    4929:	57                   	push   di
    492a:	9a bf 31 a4 49       	call   0x49a4:0x31bf
    492f:	b8 a1 43             	mov    ax,0x43a1
    4932:	0e                   	push   cs
    4933:	50                   	push   ax
    4934:	55                   	push   bp
    4935:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4939:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    493d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4940:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    4945:	2d 01 00             	sub    ax,0x1
    4948:	71 05                	jno    0x494f
    494a:	9a 3e 04 91 4a       	call   0x4a91:0x43e
    494f:	99                   	cwd
    4950:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    4954:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    4958:	c6 86 e8 fe 00       	mov    BYTE PTR [bp-0x118],0x0
    495d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4960:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    4965:	99                   	cwd
    4966:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    496a:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    496e:	c6 86 f0 fe 00       	mov    BYTE PTR [bp-0x110],0x0
    4973:	8d be e4 fe          	lea    di,[bp-0x11c]
    4977:	16                   	push   ss
    4978:	57                   	push   di
    4979:	6a 01                	push   0x1
    497b:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    497f:	06                   	push   es
    4980:	57                   	push   di
    4981:	9a 95 28 3e 4a       	call   0x4a3e:0x2895
    4986:	08 c0                	or     al,al
    4988:	75 0c                	jne    0x4996
    498a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    498d:	06                   	push   es
    498e:	57                   	push   di
    498f:	9a 7b 0b e7 4a       	call   0x4ae7:0xb7b
    4994:	eb 6e                	jmp    0x4a04
    4996:	bf 89 43             	mov    di,0x4389
    4999:	0e                   	push   cs
    499a:	57                   	push   di
    499b:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    499f:	06                   	push   es
    49a0:	57                   	push   di
    49a1:	9a 9b 3b c9 49       	call   0x49c9:0x3b9b
    49a6:	89 c7                	mov    di,ax
    49a8:	8e c2                	mov    es,dx
    49aa:	06                   	push   es
    49ab:	57                   	push   di
    49ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49af:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    49b3:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
    49b7:	89 96 1a ff          	mov    WORD PTR [bp-0xe6],dx
    49bb:	bf 92 43             	mov    di,0x4392
    49be:	0e                   	push   cs
    49bf:	57                   	push   di
    49c0:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    49c4:	06                   	push   es
    49c5:	57                   	push   di
    49c6:	9a 9b 3b ed 49       	call   0x49ed:0x3b9b
    49cb:	89 c7                	mov    di,ax
    49cd:	8e c2                	mov    es,dx
    49cf:	06                   	push   es
    49d0:	57                   	push   di
    49d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49d4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    49d8:	9b dd 9e 10 ff       	fstp   QWORD PTR [bp-0xf0]
    49dd:	90                   	nop
    49de:	9b                   	fwait
    49df:	bf 9a 43             	mov    di,0x439a
    49e2:	0e                   	push   cs
    49e3:	57                   	push   di
    49e4:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    49e8:	06                   	push   es
    49e9:	57                   	push   di
    49ea:	9a 9b 3b 19 4a       	call   0x4a19:0x3b9b
    49ef:	89 c7                	mov    di,ax
    49f1:	8e c2                	mov    es,dx
    49f3:	06                   	push   es
    49f4:	57                   	push   di
    49f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49f8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    49fc:	89 86 04 ff          	mov    WORD PTR [bp-0xfc],ax
    4a00:	89 96 06 ff          	mov    WORD PTR [bp-0xfa],dx
    4a04:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4a08:	83 c4 06             	add    sp,0x6
    4a0b:	b8 1c 4a             	mov    ax,0x4a1c
    4a0e:	0e                   	push   cs
    4a0f:	50                   	push   ax
    4a10:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4a14:	06                   	push   es
    4a15:	57                   	push   di
    4a16:	9a d2 31 31 4a       	call   0x4a31:0x31d2
    4a1b:	cb                   	retf
    4a1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a1f:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    4a24:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    4a28:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    4a2c:	06                   	push   es
    4a2d:	57                   	push   di
    4a2e:	9a d2 31 56 4a       	call   0x4a56:0x31d2
    4a33:	6a 01                	push   0x1
    4a35:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4a39:	06                   	push   es
    4a3a:	57                   	push   di
    4a3b:	9a fb 2f 4b 4a       	call   0x4a4b:0x2ffb
    4a40:	6a 00                	push   0x0
    4a42:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4a46:	06                   	push   es
    4a47:	57                   	push   di
    4a48:	9a d2 2e d9 4a       	call   0x4ad9:0x2ed2
    4a4d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4a51:	06                   	push   es
    4a52:	57                   	push   di
    4a53:	9a bf 31 f9 4a       	call   0x4af9:0x31bf
    4a58:	b8 ce 43             	mov    ax,0x43ce
    4a5b:	0e                   	push   cs
    4a5c:	50                   	push   ax
    4a5d:	55                   	push   bp
    4a5e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4a62:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4a66:	8b 46 92             	mov    ax,WORD PTR [bp-0x6e]
    4a69:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    4a6d:	b8 01 00             	mov    ax,0x1
    4a70:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    4a74:	7e 03                	jle    0x4a79
    4a76:	e9 ed 00             	jmp    0x4b66
    4a79:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    4a7c:	eb 03                	jmp    0x4a81
    4a7e:	ff 46 90             	inc    WORD PTR [bp-0x70]
    4a81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a84:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    4a89:	2d 01 00             	sub    ax,0x1
    4a8c:	71 05                	jno    0x4a93
    4a8e:	9a 3e 04 12 4b       	call   0x4b12:0x43e
    4a93:	99                   	cwd
    4a94:	89 86 da fe          	mov    WORD PTR [bp-0x126],ax
    4a98:	89 96 dc fe          	mov    WORD PTR [bp-0x124],dx
    4a9c:	c6 86 de fe 00       	mov    BYTE PTR [bp-0x122],0x0
    4aa1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4aa4:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    4aa9:	99                   	cwd
    4aaa:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    4aae:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    4ab2:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    4ab7:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    4aba:	99                   	cwd
    4abb:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    4abf:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    4ac3:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    4ac8:	8d be da fe          	lea    di,[bp-0x126]
    4acc:	16                   	push   ss
    4acd:	57                   	push   di
    4ace:	6a 02                	push   0x2
    4ad0:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4ad4:	06                   	push   es
    4ad5:	57                   	push   di
    4ad6:	9a 95 28 ff ff       	call   0xffff:0x2895
    4adb:	08 c0                	or     al,al
    4add:	75 0c                	jne    0x4aeb
    4adf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ae2:	06                   	push   es
    4ae3:	57                   	push   di
    4ae4:	9a 7b 0b 27 62       	call   0x6227:0xb7b
    4ae9:	eb 6f                	jmp    0x4b5a
    4aeb:	bf af 43             	mov    di,0x43af
    4aee:	0e                   	push   cs
    4aef:	57                   	push   di
    4af0:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4af4:	06                   	push   es
    4af5:	57                   	push   di
    4af6:	9a 9b 3b 2e 4b       	call   0x4b2e:0x3b9b
    4afb:	89 c7                	mov    di,ax
    4afd:	8e c2                	mov    es,dx
    4aff:	06                   	push   es
    4b00:	57                   	push   di
    4b01:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b04:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4b08:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    4b0b:	99                   	cwd
    4b0c:	bf a7 43             	mov    di,0x43a7
    4b0f:	9a 16 04 4b 4b       	call   0x4b4b:0x416
    4b14:	8b f8                	mov    di,ax
    4b16:	c1 e7 03             	shl    di,0x3
    4b19:	9b dd 9b 2c ff       	fstp   QWORD PTR [bp+di-0xd4]
    4b1e:	90                   	nop
    4b1f:	9b                   	fwait
    4b20:	bf c5 43             	mov    di,0x43c5
    4b23:	0e                   	push   cs
    4b24:	57                   	push   di
    4b25:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4b29:	06                   	push   es
    4b2a:	57                   	push   di
    4b2b:	9a 9b 3b 7b 4b       	call   0x4b7b:0x3b9b
    4b30:	89 c7                	mov    di,ax
    4b32:	8e c2                	mov    es,dx
    4b34:	06                   	push   es
    4b35:	57                   	push   di
    4b36:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b39:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4b3d:	8b c8                	mov    cx,ax
    4b3f:	8b da                	mov    bx,dx
    4b41:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    4b44:	99                   	cwd
    4b45:	bf a7 43             	mov    di,0x43a7
    4b48:	9a 16 04 26 4d       	call   0x4d26:0x416
    4b4d:	8b f8                	mov    di,ax
    4b4f:	c1 e7 02             	shl    di,0x2
    4b52:	89 8b 04 ff          	mov    WORD PTR [bp+di-0xfc],cx
    4b56:	89 9b 06 ff          	mov    WORD PTR [bp+di-0xfa],bx
    4b5a:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    4b5d:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    4b61:	74 03                	je     0x4b66
    4b63:	e9 18 ff             	jmp    0x4a7e
    4b66:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4b6a:	83 c4 06             	add    sp,0x6
    4b6d:	b8 7e 4b             	mov    ax,0x4b7e
    4b70:	0e                   	push   cs
    4b71:	50                   	push   ax
    4b72:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4b76:	06                   	push   es
    4b77:	57                   	push   di
    4b78:	9a d2 31 9c 4b       	call   0x4b9c:0x31d2
    4b7d:	cb                   	retf
    4b7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b81:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    4b86:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    4b8a:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    4b8e:	bf d4 43             	mov    di,0x43d4
    4b91:	0e                   	push   cs
    4b92:	57                   	push   di
    4b93:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4b97:	06                   	push   es
    4b98:	57                   	push   di
    4b99:	9a 9b 3b eb 4b       	call   0x4beb:0x3b9b
    4b9e:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    4ba1:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    4ba4:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4ba7:	06                   	push   es
    4ba8:	57                   	push   di
    4ba9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4bac:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4bb0:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    4bb4:	90                   	nop
    4bb5:	9b 9b dd 46 e6       	fld    QWORD PTR [bp-0x1a]
    4bba:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    4bc0:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    4bc5:	90                   	nop
    4bc6:	9b                   	fwait
    4bc7:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    4bcb:	9e                   	sahf
    4bcc:	73 0f                	jae    0x4bdd
    4bce:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4bd1:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4bd7:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4bdd:	bf e3 43             	mov    di,0x43e3
    4be0:	0e                   	push   cs
    4be1:	57                   	push   di
    4be2:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4be6:	06                   	push   es
    4be7:	57                   	push   di
    4be8:	9a 9b 3b 5c 4c       	call   0x4c5c:0x3b9b
    4bed:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    4bf0:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    4bf3:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4bf6:	06                   	push   es
    4bf7:	57                   	push   di
    4bf8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4bfb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4bff:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    4c03:	90                   	nop
    4c04:	9b 9b dd 86 10 ff    	fld    QWORD PTR [bp-0xf0]
    4c0a:	9b d9 e0             	fchs
    4c0d:	9b dc 5e e6          	fcomp  QWORD PTR [bp-0x1a]
    4c11:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    4c16:	90                   	nop
    4c17:	9b                   	fwait
    4c18:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    4c1c:	9e                   	sahf
    4c1d:	76 0f                	jbe    0x4c2e
    4c1f:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4c22:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4c28:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4c2e:	9b dd 86 10 ff       	fld    QWORD PTR [bp-0xf0]
    4c33:	9b d9 e0             	fchs
    4c36:	9b dc 5e e6          	fcomp  QWORD PTR [bp-0x1a]
    4c3a:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    4c3f:	90                   	nop
    4c40:	9b                   	fwait
    4c41:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    4c45:	9e                   	sahf
    4c46:	76 55                	jbe    0x4c9d
    4c48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c4b:	26 80 bd 11 04 00    	cmp    BYTE PTR es:[di+0x411],0x0
    4c51:	74 3b                	je     0x4c8e
    4c53:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4c57:	06                   	push   es
    4c58:	57                   	push   di
    4c59:	9a 3c 53 7f 4c       	call   0x4c7f:0x533c
    4c5e:	9b dd 86 10 ff       	fld    QWORD PTR [bp-0xf0]
    4c63:	9b d9 e0             	fchs
    4c66:	83 ec 08             	sub    sp,0x8
    4c69:	89 e3                	mov    bx,sp
    4c6b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4c6f:	90                   	nop
    4c70:	9b                   	fwait
    4c71:	bf e3 43             	mov    di,0x43e3
    4c74:	0e                   	push   cs
    4c75:	57                   	push   di
    4c76:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4c7a:	06                   	push   es
    4c7b:	57                   	push   di
    4c7c:	9a 9b 3b ab 4c       	call   0x4cab:0x3b9b
    4c81:	89 c7                	mov    di,ax
    4c83:	8e c2                	mov    es,dx
    4c85:	06                   	push   es
    4c86:	57                   	push   di
    4c87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c8a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4c8e:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4c91:	26 c7 45 0c 02 00    	mov    WORD PTR es:[di+0xc],0x2
    4c97:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4c9d:	bf f4 43             	mov    di,0x43f4
    4ca0:	0e                   	push   cs
    4ca1:	57                   	push   di
    4ca2:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4ca6:	06                   	push   es
    4ca7:	57                   	push   di
    4ca8:	9a 9b 3b fa 4c       	call   0x4cfa:0x3b9b
    4cad:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    4cb0:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    4cb3:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4cb6:	06                   	push   es
    4cb7:	57                   	push   di
    4cb8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cbb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4cbf:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    4cc3:	90                   	nop
    4cc4:	9b 9b dd 46 e6       	fld    QWORD PTR [bp-0x1a]
    4cc9:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    4ccf:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    4cd4:	90                   	nop
    4cd5:	9b                   	fwait
    4cd6:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    4cda:	9e                   	sahf
    4cdb:	73 0f                	jae    0x4cec
    4cdd:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4ce0:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4ce6:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4cec:	bf 00 44             	mov    di,0x4400
    4cef:	0e                   	push   cs
    4cf0:	57                   	push   di
    4cf1:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4cf5:	06                   	push   es
    4cf6:	57                   	push   di
    4cf7:	9a 9b 3b a0 4d       	call   0x4da0:0x3b9b
    4cfc:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    4cff:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    4d02:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4d05:	06                   	push   es
    4d06:	57                   	push   di
    4d07:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d0a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4d0e:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    4d11:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    4d14:	b8 00 7d             	mov    ax,0x7d00
    4d17:	31 d2                	xor    dx,dx
    4d19:	2b 86 18 ff          	sub    ax,WORD PTR [bp-0xe8]
    4d1d:	1b 96 1a ff          	sbb    dx,WORD PTR [bp-0xe6]
    4d21:	71 05                	jno    0x4d28
    4d23:	9a 3e 04 40 4f       	call   0x4f40:0x43e
    4d28:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    4d2c:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
    4d30:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    4d35:	7f 0a                	jg     0x4d41
    4d37:	7c 14                	jl     0x4d4d
    4d39:	81 be f8 fe 10 27    	cmp    WORD PTR [bp-0x108],0x2710
    4d3f:	76 0c                	jbe    0x4d4d
    4d41:	c7 86 f8 fe 10 27    	mov    WORD PTR [bp-0x108],0x2710
    4d47:	c7 86 fa fe 00 00    	mov    WORD PTR [bp-0x106],0x0
    4d4d:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    4d50:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    4d53:	3b 96 fa fe          	cmp    dx,WORD PTR [bp-0x106]
    4d57:	7f 0c                	jg     0x4d65
    4d59:	7c 06                	jl     0x4d61
    4d5b:	3b 86 f8 fe          	cmp    ax,WORD PTR [bp-0x108]
    4d5f:	77 04                	ja     0x4d65
    4d61:	b0 00                	mov    al,0x0
    4d63:	eb 02                	jmp    0x4d67
    4d65:	b0 01                	mov    al,0x1
    4d67:	8a d0                	mov    dl,al
    4d69:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    4d6d:	7c 0c                	jl     0x4d7b
    4d6f:	7f 06                	jg     0x4d77
    4d71:	83 7e da 00          	cmp    WORD PTR [bp-0x26],0x0
    4d75:	72 04                	jb     0x4d7b
    4d77:	b0 00                	mov    al,0x0
    4d79:	eb 02                	jmp    0x4d7d
    4d7b:	b0 01                	mov    al,0x1
    4d7d:	0a c2                	or     al,dl
    4d7f:	08 c0                	or     al,al
    4d81:	74 0f                	je     0x4d92
    4d83:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4d86:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4d8c:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4d92:	bf 0e 44             	mov    di,0x440e
    4d95:	0e                   	push   cs
    4d96:	57                   	push   di
    4d97:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4d9b:	06                   	push   es
    4d9c:	57                   	push   di
    4d9d:	9a 9b 3b 49 4e       	call   0x4e49:0x3b9b
    4da2:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    4da5:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    4da8:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4dab:	06                   	push   es
    4dac:	57                   	push   di
    4dad:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4db0:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4db4:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    4db7:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    4dba:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    4dbd:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    4dc0:	3b 96 1a ff          	cmp    dx,WORD PTR [bp-0xe6]
    4dc4:	7f 0c                	jg     0x4dd2
    4dc6:	7c 06                	jl     0x4dce
    4dc8:	3b 86 18 ff          	cmp    ax,WORD PTR [bp-0xe8]
    4dcc:	77 04                	ja     0x4dd2
    4dce:	b0 00                	mov    al,0x0
    4dd0:	eb 02                	jmp    0x4dd4
    4dd2:	b0 01                	mov    al,0x1
    4dd4:	8a d0                	mov    dl,al
    4dd6:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    4dda:	7c 0c                	jl     0x4de8
    4ddc:	7f 06                	jg     0x4de4
    4dde:	83 7e da 00          	cmp    WORD PTR [bp-0x26],0x0
    4de2:	72 04                	jb     0x4de8
    4de4:	b0 00                	mov    al,0x0
    4de6:	eb 02                	jmp    0x4dea
    4de8:	b0 01                	mov    al,0x1
    4dea:	0a c2                	or     al,dl
    4dec:	08 c0                	or     al,al
    4dee:	74 0f                	je     0x4dff
    4df0:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4df3:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4df9:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4dff:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    4e02:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    4e05:	3b 96 1a ff          	cmp    dx,WORD PTR [bp-0xe6]
    4e09:	7f 0c                	jg     0x4e17
    4e0b:	7c 06                	jl     0x4e13
    4e0d:	3b 86 18 ff          	cmp    ax,WORD PTR [bp-0xe8]
    4e11:	77 04                	ja     0x4e17
    4e13:	b0 00                	mov    al,0x0
    4e15:	eb 02                	jmp    0x4e19
    4e17:	b0 01                	mov    al,0x1
    4e19:	8a d0                	mov    dl,al
    4e1b:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    4e1f:	7f 0c                	jg     0x4e2d
    4e21:	7c 06                	jl     0x4e29
    4e23:	83 7e da 00          	cmp    WORD PTR [bp-0x26],0x0
    4e27:	73 04                	jae    0x4e2d
    4e29:	b0 00                	mov    al,0x0
    4e2b:	eb 02                	jmp    0x4e2f
    4e2d:	b0 01                	mov    al,0x1
    4e2f:	22 c2                	and    al,dl
    4e31:	08 c0                	or     al,al
    4e33:	74 4a                	je     0x4e7f
    4e35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e38:	26 80 bd 11 04 00    	cmp    BYTE PTR es:[di+0x411],0x0
    4e3e:	74 30                	je     0x4e70
    4e40:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4e44:	06                   	push   es
    4e45:	57                   	push   di
    4e46:	9a 3c 53 61 4e       	call   0x4e61:0x533c
    4e4b:	ff b6 1a ff          	push   WORD PTR [bp-0xe6]
    4e4f:	ff b6 18 ff          	push   WORD PTR [bp-0xe8]
    4e53:	bf 0e 44             	mov    di,0x440e
    4e56:	0e                   	push   cs
    4e57:	57                   	push   di
    4e58:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4e5c:	06                   	push   es
    4e5d:	57                   	push   di
    4e5e:	9a 9b 3b 8d 4e       	call   0x4e8d:0x3b9b
    4e63:	89 c7                	mov    di,ax
    4e65:	8e c2                	mov    es,dx
    4e67:	06                   	push   es
    4e68:	57                   	push   di
    4e69:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e6c:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    4e70:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4e73:	26 c7 45 0c 02 00    	mov    WORD PTR es:[di+0xc],0x2
    4e79:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4e7f:	bf 1c 44             	mov    di,0x441c
    4e82:	0e                   	push   cs
    4e83:	57                   	push   di
    4e84:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4e88:	06                   	push   es
    4e89:	57                   	push   di
    4e8a:	9a 9b 3b 02 4f       	call   0x4f02:0x3b9b
    4e8f:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    4e92:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    4e95:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4e98:	06                   	push   es
    4e99:	57                   	push   di
    4e9a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e9d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ea1:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    4ea5:	90                   	nop
    4ea6:	9b 9b dd 46 e6       	fld    QWORD PTR [bp-0x1a]
    4eab:	9b 2e d8 1e 30 44    	fcomp  DWORD PTR cs:0x4430
    4eb1:	9b dd be f0 fe       	fstsw  WORD PTR [bp-0x110]
    4eb6:	90                   	nop
    4eb7:	9b                   	fwait
    4eb8:	8a a6 f1 fe          	mov    ah,BYTE PTR [bp-0x10f]
    4ebc:	9e                   	sahf
    4ebd:	b0 00                	mov    al,0x0
    4ebf:	76 01                	jbe    0x4ec2
    4ec1:	40                   	inc    ax
    4ec2:	8a d0                	mov    dl,al
    4ec4:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    4ec8:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    4ece:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    4ed3:	90                   	nop
    4ed4:	9b                   	fwait
    4ed5:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    4ed9:	9e                   	sahf
    4eda:	b0 00                	mov    al,0x0
    4edc:	73 01                	jae    0x4edf
    4ede:	40                   	inc    ax
    4edf:	0a c2                	or     al,dl
    4ee1:	08 c0                	or     al,al
    4ee3:	74 0f                	je     0x4ef4
    4ee5:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    4ee8:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4eee:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4ef4:	bf 34 44             	mov    di,0x4434
    4ef7:	0e                   	push   cs
    4ef8:	57                   	push   di
    4ef9:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4efd:	06                   	push   es
    4efe:	57                   	push   di
    4eff:	9a 9b 3b 18 4f       	call   0x4f18:0x3b9b
    4f04:	89 46 b2             	mov    WORD PTR [bp-0x4e],ax
    4f07:	89 56 b4             	mov    WORD PTR [bp-0x4c],dx
    4f0a:	bf 44 44             	mov    di,0x4444
    4f0d:	0e                   	push   cs
    4f0e:	57                   	push   di
    4f0f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    4f13:	06                   	push   es
    4f14:	57                   	push   di
    4f15:	9a 9b 3b 10 50       	call   0x5010:0x3b9b
    4f1a:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    4f1d:	89 56 b8             	mov    WORD PTR [bp-0x48],dx
    4f20:	c7 46 da 01 00       	mov    WORD PTR [bp-0x26],0x1
    4f25:	c7 46 dc 00 00       	mov    WORD PTR [bp-0x24],0x0
    4f2a:	eb 08                	jmp    0x4f34
    4f2c:	83 46 da 01          	add    WORD PTR [bp-0x26],0x1
    4f30:	83 56 dc 00          	adc    WORD PTR [bp-0x24],0x0
    4f34:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    4f37:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    4f3a:	bf 54 44             	mov    di,0x4454
    4f3d:	9a 16 04 63 4f       	call   0x4f63:0x416
    4f42:	8b f8                	mov    di,ax
    4f44:	c1 e7 02             	shl    di,0x2
    4f47:	c4 7b ae             	les    di,DWORD PTR [bp+di-0x52]
    4f4a:	06                   	push   es
    4f4b:	57                   	push   di
    4f4c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f4f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4f53:	8b c8                	mov    cx,ax
    4f55:	8b da                	mov    bx,dx
    4f57:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    4f5a:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    4f5d:	bf 54 44             	mov    di,0x4454
    4f60:	9a 16 04 7c 4f       	call   0x4f7c:0x416
    4f65:	8b f8                	mov    di,ax
    4f67:	c1 e7 02             	shl    di,0x2
    4f6a:	89 4b a6             	mov    WORD PTR [bp+di-0x5a],cx
    4f6d:	89 5b a8             	mov    WORD PTR [bp+di-0x58],bx
    4f70:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    4f73:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    4f76:	bf 54 44             	mov    di,0x4454
    4f79:	9a 16 04 9d 4f       	call   0x4f9d:0x416
    4f7e:	8b f8                	mov    di,ax
    4f80:	c1 e7 02             	shl    di,0x2
    4f83:	83 7b a8 00          	cmp    WORD PTR [bp+di-0x58],0x0
    4f87:	7c 08                	jl     0x4f91
    4f89:	7f 28                	jg     0x4fb3
    4f8b:	83 7b a6 00          	cmp    WORD PTR [bp+di-0x5a],0x0
    4f8f:	73 22                	jae    0x4fb3
    4f91:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    4f94:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    4f97:	bf 54 44             	mov    di,0x4454
    4f9a:	9a 16 04 2e 52       	call   0x522e:0x416
    4f9f:	8b f8                	mov    di,ax
    4fa1:	c1 e7 02             	shl    di,0x2
    4fa4:	c4 7b ae             	les    di,DWORD PTR [bp+di-0x52]
    4fa7:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4fad:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4fb3:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    4fb7:	74 03                	je     0x4fbc
    4fb9:	e9 70 ff             	jmp    0x4f2c
    4fbc:	83 7e da 02          	cmp    WORD PTR [bp-0x26],0x2
    4fc0:	74 03                	je     0x4fc5
    4fc2:	e9 67 ff             	jmp    0x4f2c
    4fc5:	8b 46 ae             	mov    ax,WORD PTR [bp-0x52]
    4fc8:	8b 56 b0             	mov    dx,WORD PTR [bp-0x50]
    4fcb:	3b 96 06 ff          	cmp    dx,WORD PTR [bp-0xfa]
    4fcf:	7f 08                	jg     0x4fd9
    4fd1:	7c 15                	jl     0x4fe8
    4fd3:	3b 86 04 ff          	cmp    ax,WORD PTR [bp-0xfc]
    4fd7:	76 0f                	jbe    0x4fe8
    4fd9:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    4fdc:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    4fe2:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    4fe8:	8b 46 ae             	mov    ax,WORD PTR [bp-0x52]
    4feb:	8b 56 b0             	mov    dx,WORD PTR [bp-0x50]
    4fee:	3b 96 06 ff          	cmp    dx,WORD PTR [bp-0xfa]
    4ff2:	7f 08                	jg     0x4ffc
    4ff4:	7c 66                	jl     0x505c
    4ff6:	3b 86 04 ff          	cmp    ax,WORD PTR [bp-0xfc]
    4ffa:	76 60                	jbe    0x505c
    4ffc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fff:	26 80 bd 11 04 00    	cmp    BYTE PTR es:[di+0x411],0x0
    5005:	74 46                	je     0x504d
    5007:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    500b:	06                   	push   es
    500c:	57                   	push   di
    500d:	9a 3c 53 30 50       	call   0x5030:0x533c
    5012:	9b db 86 04 ff       	fild   DWORD PTR [bp-0xfc]
    5017:	83 ec 08             	sub    sp,0x8
    501a:	89 e3                	mov    bx,sp
    501c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5020:	90                   	nop
    5021:	9b                   	fwait
    5022:	bf 44 44             	mov    di,0x4444
    5025:	0e                   	push   cs
    5026:	57                   	push   di
    5027:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    502b:	06                   	push   es
    502c:	57                   	push   di
    502d:	9a 9b 3b 6a 50       	call   0x506a:0x3b9b
    5032:	89 c7                	mov    di,ax
    5034:	8e c2                	mov    es,dx
    5036:	06                   	push   es
    5037:	57                   	push   di
    5038:	26 c4 3d             	les    di,DWORD PTR es:[di]
    503b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    503f:	8b 86 04 ff          	mov    ax,WORD PTR [bp-0xfc]
    5043:	8b 96 06 ff          	mov    dx,WORD PTR [bp-0xfa]
    5047:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    504a:	89 56 b0             	mov    WORD PTR [bp-0x50],dx
    504d:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    5050:	26 c7 45 0c 02 00    	mov    WORD PTR es:[di+0xc],0x2
    5056:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    505c:	bf 5c 44             	mov    di,0x445c
    505f:	0e                   	push   cs
    5060:	57                   	push   di
    5061:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    5065:	06                   	push   es
    5066:	57                   	push   di
    5067:	9a 9b 3b df 50       	call   0x50df:0x3b9b
    506c:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    506f:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    5072:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5075:	06                   	push   es
    5076:	57                   	push   di
    5077:	26 c4 3d             	les    di,DWORD PTR es:[di]
    507a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    507e:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    5082:	90                   	nop
    5083:	9b 9b dd 46 e6       	fld    QWORD PTR [bp-0x1a]
    5088:	9b 2e d8 1e 6f 44    	fcomp  DWORD PTR cs:0x446f
    508e:	9b dd be f0 fe       	fstsw  WORD PTR [bp-0x110]
    5093:	90                   	nop
    5094:	9b                   	fwait
    5095:	8a a6 f1 fe          	mov    ah,BYTE PTR [bp-0x10f]
    5099:	9e                   	sahf
    509a:	b0 00                	mov    al,0x0
    509c:	76 01                	jbe    0x509f
    509e:	40                   	inc    ax
    509f:	8a d0                	mov    dl,al
    50a1:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    50a5:	9b 2e d8 1e 6b 44    	fcomp  DWORD PTR cs:0x446b
    50ab:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    50b0:	90                   	nop
    50b1:	9b                   	fwait
    50b2:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    50b6:	9e                   	sahf
    50b7:	b0 00                	mov    al,0x0
    50b9:	73 01                	jae    0x50bc
    50bb:	40                   	inc    ax
    50bc:	0a c2                	or     al,dl
    50be:	08 c0                	or     al,al
    50c0:	74 0f                	je     0x50d1
    50c2:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    50c5:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    50cb:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    50d1:	bf 73 44             	mov    di,0x4473
    50d4:	0e                   	push   cs
    50d5:	57                   	push   di
    50d6:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    50da:	06                   	push   es
    50db:	57                   	push   di
    50dc:	9a 9b 3b 54 51       	call   0x5154:0x3b9b
    50e1:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    50e4:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    50e7:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    50ea:	06                   	push   es
    50eb:	57                   	push   di
    50ec:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50ef:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    50f3:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    50f7:	90                   	nop
    50f8:	9b 9b dd 46 e6       	fld    QWORD PTR [bp-0x1a]
    50fd:	9b 2e d8 1e 82 44    	fcomp  DWORD PTR cs:0x4482
    5103:	9b dd be f0 fe       	fstsw  WORD PTR [bp-0x110]
    5108:	90                   	nop
    5109:	9b                   	fwait
    510a:	8a a6 f1 fe          	mov    ah,BYTE PTR [bp-0x10f]
    510e:	9e                   	sahf
    510f:	b0 00                	mov    al,0x0
    5111:	76 01                	jbe    0x5114
    5113:	40                   	inc    ax
    5114:	8a d0                	mov    dl,al
    5116:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    511a:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    5120:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    5125:	90                   	nop
    5126:	9b                   	fwait
    5127:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    512b:	9e                   	sahf
    512c:	b0 00                	mov    al,0x0
    512e:	73 01                	jae    0x5131
    5130:	40                   	inc    ax
    5131:	0a c2                	or     al,dl
    5133:	08 c0                	or     al,al
    5135:	74 0f                	je     0x5146
    5137:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    513a:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5140:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5146:	bf 86 44             	mov    di,0x4486
    5149:	0e                   	push   cs
    514a:	57                   	push   di
    514b:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    514f:	06                   	push   es
    5150:	57                   	push   di
    5151:	9a 9b 3b c8 51       	call   0x51c8:0x3b9b
    5156:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    5159:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    515c:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    515f:	06                   	push   es
    5160:	57                   	push   di
    5161:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5164:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5168:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    516c:	90                   	nop
    516d:	9b 9b dd 46 e6       	fld    QWORD PTR [bp-0x1a]
    5172:	9b 2e d8 1e 30 44    	fcomp  DWORD PTR cs:0x4430
    5178:	9b dd be f0 fe       	fstsw  WORD PTR [bp-0x110]
    517d:	90                   	nop
    517e:	9b                   	fwait
    517f:	8a a6 f1 fe          	mov    ah,BYTE PTR [bp-0x10f]
    5183:	9e                   	sahf
    5184:	b0 00                	mov    al,0x0
    5186:	76 01                	jbe    0x5189
    5188:	40                   	inc    ax
    5189:	8a d0                	mov    dl,al
    518b:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    518f:	9b dc 9e 78 ff       	fcomp  QWORD PTR [bp-0x88]
    5194:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    5199:	90                   	nop
    519a:	9b                   	fwait
    519b:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    519f:	9e                   	sahf
    51a0:	b0 00                	mov    al,0x0
    51a2:	73 01                	jae    0x51a5
    51a4:	40                   	inc    ax
    51a5:	0a c2                	or     al,dl
    51a7:	08 c0                	or     al,al
    51a9:	74 0f                	je     0x51ba
    51ab:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    51ae:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    51b4:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    51ba:	bf 92 44             	mov    di,0x4492
    51bd:	0e                   	push   cs
    51be:	57                   	push   di
    51bf:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    51c3:	06                   	push   es
    51c4:	57                   	push   di
    51c5:	9a 9b 3b 4e 52       	call   0x524e:0x3b9b
    51ca:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    51cd:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    51d0:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    51d3:	06                   	push   es
    51d4:	57                   	push   di
    51d5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51d8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    51dc:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    51e0:	90                   	nop
    51e1:	9b 9b dd 46 e6       	fld    QWORD PTR [bp-0x1a]
    51e6:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    51ec:	9b dd be f2 fe       	fstsw  WORD PTR [bp-0x10e]
    51f1:	90                   	nop
    51f2:	9b                   	fwait
    51f3:	8a a6 f3 fe          	mov    ah,BYTE PTR [bp-0x10d]
    51f7:	9e                   	sahf
    51f8:	73 0f                	jae    0x5209
    51fa:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    51fd:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5203:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5209:	8b 46 92             	mov    ax,WORD PTR [bp-0x6e]
    520c:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    5210:	b8 01 00             	mov    ax,0x1
    5213:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    5217:	7e 03                	jle    0x521c
    5219:	e9 c7 09             	jmp    0x5be3
    521c:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    521f:	eb 03                	jmp    0x5224
    5221:	ff 46 90             	inc    WORD PTR [bp-0x70]
    5224:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5227:	99                   	cwd
    5228:	bf 54 44             	mov    di,0x4454
    522b:	9a 16 04 84 52       	call   0x5284:0x416
    5230:	8b f8                	mov    di,ax
    5232:	c1 e7 02             	shl    di,0x2
    5235:	c4 7b ca             	les    di,DWORD PTR [bp+di-0x36]
    5238:	89 be f2 fe          	mov    WORD PTR [bp-0x10e],di
    523c:	8c 86 f4 fe          	mov    WORD PTR [bp-0x10c],es
    5240:	bf 99 44             	mov    di,0x4499
    5243:	0e                   	push   cs
    5244:	57                   	push   di
    5245:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5249:	06                   	push   es
    524a:	57                   	push   di
    524b:	9a 9b 3b bb 52       	call   0x52bb:0x3b9b
    5250:	89 c7                	mov    di,ax
    5252:	8e c2                	mov    es,dx
    5254:	06                   	push   es
    5255:	57                   	push   di
    5256:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5259:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    525d:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    5261:	89 96 f0 fe          	mov    WORD PTR [bp-0x110],dx
    5265:	9b db 86 ee fe       	fild   DWORD PTR [bp-0x112]
    526a:	9b dc 8e 54 ff       	fmul   QWORD PTR [bp-0xac]
    526f:	83 ec 08             	sub    sp,0x8
    5272:	89 e3                	mov    bx,sp
    5274:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5278:	90                   	nop
    5279:	9b                   	fwait
    527a:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    527d:	99                   	cwd
    527e:	bf 54 44             	mov    di,0x4454
    5281:	9a 16 04 a3 52       	call   0x52a3:0x416
    5286:	8b f8                	mov    di,ax
    5288:	c1 e7 03             	shl    di,0x3
    528b:	ff b3 32 ff          	push   WORD PTR [bp+di-0xce]
    528f:	ff b3 30 ff          	push   WORD PTR [bp+di-0xd0]
    5293:	ff b3 2e ff          	push   WORD PTR [bp+di-0xd2]
    5297:	ff b3 2c ff          	push   WORD PTR [bp+di-0xd4]
    529b:	9a a7 2e 24 53       	call   0x5324:0x2ea7
    52a0:	9a 0e 10 f3 52       	call   0x52f3:0x100e
    52a5:	89 86 2c ff          	mov    WORD PTR [bp-0xd4],ax
    52a9:	89 96 2e ff          	mov    WORD PTR [bp-0xd2],dx
    52ad:	bf ab 44             	mov    di,0x44ab
    52b0:	0e                   	push   cs
    52b1:	57                   	push   di
    52b2:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    52b6:	06                   	push   es
    52b7:	57                   	push   di
    52b8:	9a 9b 3b 77 53       	call   0x5377:0x3b9b
    52bd:	89 c7                	mov    di,ax
    52bf:	8e c2                	mov    es,dx
    52c1:	06                   	push   es
    52c2:	57                   	push   di
    52c3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52c6:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    52ca:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    52ce:	89 96 f0 fe          	mov    WORD PTR [bp-0x110],dx
    52d2:	9b db 86 ee fe       	fild   DWORD PTR [bp-0x112]
    52d7:	9b dc 8e 4c ff       	fmul   QWORD PTR [bp-0xb4]
    52dc:	9b 2e d9 06 30 44    	fld    DWORD PTR cs:0x4430
    52e2:	9b dc 86 44 ff       	fadd   QWORD PTR [bp-0xbc]
    52e7:	9b de c9             	fmulp  st(1),st
    52ea:	9b 2e d9 06 30 44    	fld    DWORD PTR cs:0x4430
    52f0:	9a b2 04 0a 53       	call   0x530a:0x4b2
    52f5:	83 ec 08             	sub    sp,0x8
    52f8:	89 e3                	mov    bx,sp
    52fa:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    52fe:	90                   	nop
    52ff:	9b                   	fwait
    5300:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5303:	99                   	cwd
    5304:	bf 54 44             	mov    di,0x4454
    5307:	9a 16 04 29 53       	call   0x5329:0x416
    530c:	8b f8                	mov    di,ax
    530e:	c1 e7 03             	shl    di,0x3
    5311:	ff b3 32 ff          	push   WORD PTR [bp+di-0xce]
    5315:	ff b3 30 ff          	push   WORD PTR [bp+di-0xd0]
    5319:	ff b3 2e ff          	push   WORD PTR [bp+di-0xd2]
    531d:	ff b3 2c ff          	push   WORD PTR [bp+di-0xd4]
    5321:	9a a7 2e ff ff       	call   0xffff:0x2ea7
    5326:	9a 0e 10 8e 54       	call   0x548e:0x100e
    532b:	89 86 28 ff          	mov    WORD PTR [bp-0xd8],ax
    532f:	89 96 2a ff          	mov    WORD PTR [bp-0xd6],dx
    5333:	8b 86 2c ff          	mov    ax,WORD PTR [bp-0xd4]
    5337:	8b 96 2e ff          	mov    dx,WORD PTR [bp-0xd2]
    533b:	89 86 30 ff          	mov    WORD PTR [bp-0xd0],ax
    533f:	89 96 32 ff          	mov    WORD PTR [bp-0xce],dx
    5343:	8b 86 30 ff          	mov    ax,WORD PTR [bp-0xd0]
    5347:	8b 96 32 ff          	mov    dx,WORD PTR [bp-0xce]
    534b:	3b 96 2a ff          	cmp    dx,WORD PTR [bp-0xd6]
    534f:	7f 08                	jg     0x5359
    5351:	7c 16                	jl     0x5369
    5353:	3b 86 28 ff          	cmp    ax,WORD PTR [bp-0xd8]
    5357:	76 10                	jbe    0x5369
    5359:	8b 86 28 ff          	mov    ax,WORD PTR [bp-0xd8]
    535d:	8b 96 2a ff          	mov    dx,WORD PTR [bp-0xd6]
    5361:	89 86 30 ff          	mov    WORD PTR [bp-0xd0],ax
    5365:	89 96 32 ff          	mov    WORD PTR [bp-0xce],dx
    5369:	bf be 44             	mov    di,0x44be
    536c:	0e                   	push   cs
    536d:	57                   	push   di
    536e:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5372:	06                   	push   es
    5373:	57                   	push   di
    5374:	9a 9b 3b 3a 54       	call   0x543a:0x3b9b
    5379:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    537c:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    537f:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5382:	06                   	push   es
    5383:	57                   	push   di
    5384:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5387:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    538b:	89 86 24 ff          	mov    WORD PTR [bp-0xdc],ax
    538f:	89 96 26 ff          	mov    WORD PTR [bp-0xda],dx
    5393:	8b 86 24 ff          	mov    ax,WORD PTR [bp-0xdc]
    5397:	8b 96 26 ff          	mov    dx,WORD PTR [bp-0xda]
    539b:	3b 96 32 ff          	cmp    dx,WORD PTR [bp-0xce]
    539f:	7f 0c                	jg     0x53ad
    53a1:	7c 06                	jl     0x53a9
    53a3:	3b 86 30 ff          	cmp    ax,WORD PTR [bp-0xd0]
    53a7:	77 04                	ja     0x53ad
    53a9:	b0 00                	mov    al,0x0
    53ab:	eb 02                	jmp    0x53af
    53ad:	b0 01                	mov    al,0x1
    53af:	8a d0                	mov    dl,al
    53b1:	83 be 26 ff 00       	cmp    WORD PTR [bp-0xda],0x0
    53b6:	7c 0d                	jl     0x53c5
    53b8:	7f 07                	jg     0x53c1
    53ba:	83 be 24 ff 00       	cmp    WORD PTR [bp-0xdc],0x0
    53bf:	72 04                	jb     0x53c5
    53c1:	b0 00                	mov    al,0x0
    53c3:	eb 02                	jmp    0x53c7
    53c5:	b0 01                	mov    al,0x1
    53c7:	0a c2                	or     al,dl
    53c9:	08 c0                	or     al,al
    53cb:	74 0f                	je     0x53dc
    53cd:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    53d0:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    53d6:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    53dc:	8b 86 24 ff          	mov    ax,WORD PTR [bp-0xdc]
    53e0:	8b 96 26 ff          	mov    dx,WORD PTR [bp-0xda]
    53e4:	3b 96 32 ff          	cmp    dx,WORD PTR [bp-0xce]
    53e8:	7f 0c                	jg     0x53f6
    53ea:	7c 06                	jl     0x53f2
    53ec:	3b 86 30 ff          	cmp    ax,WORD PTR [bp-0xd0]
    53f0:	77 04                	ja     0x53f6
    53f2:	b0 00                	mov    al,0x0
    53f4:	eb 02                	jmp    0x53f8
    53f6:	b0 01                	mov    al,0x1
    53f8:	8a d0                	mov    dl,al
    53fa:	83 be 26 ff 00       	cmp    WORD PTR [bp-0xda],0x0
    53ff:	7f 0d                	jg     0x540e
    5401:	7c 07                	jl     0x540a
    5403:	83 be 24 ff 00       	cmp    WORD PTR [bp-0xdc],0x0
    5408:	73 04                	jae    0x540e
    540a:	b0 00                	mov    al,0x0
    540c:	eb 02                	jmp    0x5410
    540e:	b0 01                	mov    al,0x1
    5410:	22 c2                	and    al,dl
    5412:	08 c0                	or     al,al
    5414:	74 5a                	je     0x5470
    5416:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5419:	26 80 bd 11 04 00    	cmp    BYTE PTR es:[di+0x411],0x0
    541f:	74 40                	je     0x5461
    5421:	8b 86 30 ff          	mov    ax,WORD PTR [bp-0xd0]
    5425:	8b 96 32 ff          	mov    dx,WORD PTR [bp-0xce]
    5429:	89 86 24 ff          	mov    WORD PTR [bp-0xdc],ax
    542d:	89 96 26 ff          	mov    WORD PTR [bp-0xda],dx
    5431:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5435:	06                   	push   es
    5436:	57                   	push   di
    5437:	9a 3c 53 52 54       	call   0x5452:0x533c
    543c:	ff b6 26 ff          	push   WORD PTR [bp-0xda]
    5440:	ff b6 24 ff          	push   WORD PTR [bp-0xdc]
    5444:	bf be 44             	mov    di,0x44be
    5447:	0e                   	push   cs
    5448:	57                   	push   di
    5449:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    544d:	06                   	push   es
    544e:	57                   	push   di
    544f:	9a 9b 3b 7e 54       	call   0x547e:0x3b9b
    5454:	89 c7                	mov    di,ax
    5456:	8e c2                	mov    es,dx
    5458:	06                   	push   es
    5459:	57                   	push   di
    545a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    545d:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    5461:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5464:	26 c7 45 0c 02 00    	mov    WORD PTR es:[di+0xc],0x2
    546a:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5470:	bf 99 44             	mov    di,0x4499
    5473:	0e                   	push   cs
    5474:	57                   	push   di
    5475:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5479:	06                   	push   es
    547a:	57                   	push   di
    547b:	9a 9b 3b 20 55       	call   0x5520:0x3b9b
    5480:	8b c8                	mov    cx,ax
    5482:	8b da                	mov    bx,dx
    5484:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5487:	99                   	cwd
    5488:	bf 54 44             	mov    di,0x4454
    548b:	9a 16 04 a5 54       	call   0x54a5:0x416
    5490:	8b f8                	mov    di,ax
    5492:	c1 e7 02             	shl    di,0x2
    5495:	89 4b be             	mov    WORD PTR [bp+di-0x42],cx
    5498:	89 5b c0             	mov    WORD PTR [bp+di-0x40],bx
    549b:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    549e:	99                   	cwd
    549f:	bf 54 44             	mov    di,0x4454
    54a2:	9a 16 04 c6 54       	call   0x54c6:0x416
    54a7:	8b f8                	mov    di,ax
    54a9:	c1 e7 02             	shl    di,0x2
    54ac:	c4 7b be             	les    di,DWORD PTR [bp+di-0x42]
    54af:	06                   	push   es
    54b0:	57                   	push   di
    54b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54b4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    54b8:	8b c8                	mov    cx,ax
    54ba:	8b da                	mov    bx,dx
    54bc:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    54bf:	99                   	cwd
    54c0:	bf 54 44             	mov    di,0x4454
    54c3:	9a 16 04 dd 54       	call   0x54dd:0x416
    54c8:	8b f8                	mov    di,ax
    54ca:	c1 e7 02             	shl    di,0x2
    54cd:	89 4b b6             	mov    WORD PTR [bp+di-0x4a],cx
    54d0:	89 5b b8             	mov    WORD PTR [bp+di-0x48],bx
    54d3:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    54d6:	99                   	cwd
    54d7:	bf 54 44             	mov    di,0x4454
    54da:	9a 16 04 fc 54       	call   0x54fc:0x416
    54df:	8b f8                	mov    di,ax
    54e1:	c1 e7 02             	shl    di,0x2
    54e4:	83 7b b8 00          	cmp    WORD PTR [bp+di-0x48],0x0
    54e8:	7c 08                	jl     0x54f2
    54ea:	7f 26                	jg     0x5512
    54ec:	83 7b b6 00          	cmp    WORD PTR [bp+di-0x4a],0x0
    54f0:	73 20                	jae    0x5512
    54f2:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    54f5:	99                   	cwd
    54f6:	bf 54 44             	mov    di,0x4454
    54f9:	9a 16 04 8a 55       	call   0x558a:0x416
    54fe:	8b f8                	mov    di,ax
    5500:	c1 e7 02             	shl    di,0x2
    5503:	c4 7b be             	les    di,DWORD PTR [bp+di-0x42]
    5506:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    550c:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5512:	bf ab 44             	mov    di,0x44ab
    5515:	0e                   	push   cs
    5516:	57                   	push   di
    5517:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    551b:	06                   	push   es
    551c:	57                   	push   di
    551d:	9a 9b 3b a5 55       	call   0x55a5:0x3b9b
    5522:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    5525:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    5528:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    552b:	06                   	push   es
    552c:	57                   	push   di
    552d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5530:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5534:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    5537:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    553a:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    553e:	7f 0d                	jg     0x554d
    5540:	7c 07                	jl     0x5549
    5542:	81 7e da 10 27       	cmp    WORD PTR [bp-0x26],0x2710
    5547:	77 04                	ja     0x554d
    5549:	b0 00                	mov    al,0x0
    554b:	eb 02                	jmp    0x554f
    554d:	b0 01                	mov    al,0x1
    554f:	8a d0                	mov    dl,al
    5551:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    5555:	7c 0c                	jl     0x5563
    5557:	7f 06                	jg     0x555f
    5559:	83 7e da 00          	cmp    WORD PTR [bp-0x26],0x0
    555d:	72 04                	jb     0x5563
    555f:	b0 00                	mov    al,0x0
    5561:	eb 02                	jmp    0x5565
    5563:	b0 01                	mov    al,0x1
    5565:	0a c2                	or     al,dl
    5567:	08 c0                	or     al,al
    5569:	74 0f                	je     0x557a
    556b:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    556e:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5574:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    557a:	8b 4e da             	mov    cx,WORD PTR [bp-0x26]
    557d:	8b 5e dc             	mov    bx,WORD PTR [bp-0x24]
    5580:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5583:	99                   	cwd
    5584:	bf 54 44             	mov    di,0x4454
    5587:	9a 16 04 cf 55       	call   0x55cf:0x416
    558c:	8b f8                	mov    di,ax
    558e:	c1 e7 02             	shl    di,0x2
    5591:	89 4b 96             	mov    WORD PTR [bp+di-0x6a],cx
    5594:	89 5b 98             	mov    WORD PTR [bp+di-0x68],bx
    5597:	bf c9 44             	mov    di,0x44c9
    559a:	0e                   	push   cs
    559b:	57                   	push   di
    559c:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    55a0:	06                   	push   es
    55a1:	57                   	push   di
    55a2:	9a 9b 3b 30 56       	call   0x5630:0x3b9b
    55a7:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    55aa:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    55ad:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    55b0:	06                   	push   es
    55b1:	57                   	push   di
    55b2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55b5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    55b9:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    55bd:	90                   	nop
    55be:	9b                   	fwait
    55bf:	9b 2e d9 06 ce 44    	fld    DWORD PTR cs:0x44ce
    55c5:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    55c8:	99                   	cwd
    55c9:	bf 54 44             	mov    di,0x4454
    55cc:	9a 16 04 c3 57       	call   0x57c3:0x416
    55d1:	8b f8                	mov    di,ax
    55d3:	c1 e7 03             	shl    di,0x3
    55d6:	9b dc 8b 78 ff       	fmul   QWORD PTR [bp+di-0x88]
    55db:	9b dc 5e e6          	fcomp  QWORD PTR [bp-0x1a]
    55df:	9b dd be ee fe       	fstsw  WORD PTR [bp-0x112]
    55e4:	90                   	nop
    55e5:	9b                   	fwait
    55e6:	8a a6 ef fe          	mov    ah,BYTE PTR [bp-0x111]
    55ea:	9e                   	sahf
    55eb:	b0 00                	mov    al,0x0
    55ed:	73 01                	jae    0x55f0
    55ef:	40                   	inc    ax
    55f0:	8a d0                	mov    dl,al
    55f2:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    55f6:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    55fc:	9b dd be f0 fe       	fstsw  WORD PTR [bp-0x110]
    5601:	90                   	nop
    5602:	9b                   	fwait
    5603:	8a a6 f1 fe          	mov    ah,BYTE PTR [bp-0x10f]
    5607:	9e                   	sahf
    5608:	b0 00                	mov    al,0x0
    560a:	73 01                	jae    0x560d
    560c:	40                   	inc    ax
    560d:	0a c2                	or     al,dl
    560f:	08 c0                	or     al,al
    5611:	74 0f                	je     0x5622
    5613:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5616:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    561c:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5622:	bf d2 44             	mov    di,0x44d2
    5625:	0e                   	push   cs
    5626:	57                   	push   di
    5627:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    562b:	06                   	push   es
    562c:	57                   	push   di
    562d:	9a 9b 3b 7f 56       	call   0x567f:0x3b9b
    5632:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    5635:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    5638:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    563b:	06                   	push   es
    563c:	57                   	push   di
    563d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5640:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5644:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    5648:	90                   	nop
    5649:	9b 9b dd 46 e6       	fld    QWORD PTR [bp-0x1a]
    564e:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    5654:	9b dd be f0 fe       	fstsw  WORD PTR [bp-0x110]
    5659:	90                   	nop
    565a:	9b                   	fwait
    565b:	8a a6 f1 fe          	mov    ah,BYTE PTR [bp-0x10f]
    565f:	9e                   	sahf
    5660:	73 0f                	jae    0x5671
    5662:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5665:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    566b:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5671:	bf dc 44             	mov    di,0x44dc
    5674:	0e                   	push   cs
    5675:	57                   	push   di
    5676:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    567a:	06                   	push   es
    567b:	57                   	push   di
    567c:	9a 9b 3b ce 56       	call   0x56ce:0x3b9b
    5681:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    5684:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    5687:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    568a:	06                   	push   es
    568b:	57                   	push   di
    568c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    568f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5693:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    5697:	90                   	nop
    5698:	9b 9b dd 46 e6       	fld    QWORD PTR [bp-0x1a]
    569d:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    56a3:	9b dd be f0 fe       	fstsw  WORD PTR [bp-0x110]
    56a8:	90                   	nop
    56a9:	9b                   	fwait
    56aa:	8a a6 f1 fe          	mov    ah,BYTE PTR [bp-0x10f]
    56ae:	9e                   	sahf
    56af:	73 0f                	jae    0x56c0
    56b1:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    56b4:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    56ba:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    56c0:	bf ee 44             	mov    di,0x44ee
    56c3:	0e                   	push   cs
    56c4:	57                   	push   di
    56c5:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    56c9:	06                   	push   es
    56ca:	57                   	push   di
    56cb:	9a 9b 3b 36 57       	call   0x5736:0x3b9b
    56d0:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    56d3:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    56d6:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    56d9:	06                   	push   es
    56da:	57                   	push   di
    56db:	26 c4 3d             	les    di,DWORD PTR es:[di]
    56de:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    56e2:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    56e5:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    56e8:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    56ec:	7f 0d                	jg     0x56fb
    56ee:	7c 07                	jl     0x56f7
    56f0:	81 7e da 10 27       	cmp    WORD PTR [bp-0x26],0x2710
    56f5:	77 04                	ja     0x56fb
    56f7:	b0 00                	mov    al,0x0
    56f9:	eb 02                	jmp    0x56fd
    56fb:	b0 01                	mov    al,0x1
    56fd:	8a d0                	mov    dl,al
    56ff:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    5703:	7c 0c                	jl     0x5711
    5705:	7f 06                	jg     0x570d
    5707:	83 7e da 00          	cmp    WORD PTR [bp-0x26],0x0
    570b:	72 04                	jb     0x5711
    570d:	b0 00                	mov    al,0x0
    570f:	eb 02                	jmp    0x5713
    5711:	b0 01                	mov    al,0x1
    5713:	0a c2                	or     al,dl
    5715:	08 c0                	or     al,al
    5717:	74 0f                	je     0x5728
    5719:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    571c:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5722:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5728:	bf ff 44             	mov    di,0x44ff
    572b:	0e                   	push   cs
    572c:	57                   	push   di
    572d:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5731:	06                   	push   es
    5732:	57                   	push   di
    5733:	9a 9b 3b 9d 57       	call   0x579d:0x3b9b
    5738:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    573b:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    573e:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5741:	06                   	push   es
    5742:	57                   	push   di
    5743:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5746:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    574a:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    574d:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    5750:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    5754:	7f 0c                	jg     0x5762
    5756:	7c 06                	jl     0x575e
    5758:	83 7e da 78          	cmp    WORD PTR [bp-0x26],0x78
    575c:	77 04                	ja     0x5762
    575e:	b0 00                	mov    al,0x0
    5760:	eb 02                	jmp    0x5764
    5762:	b0 01                	mov    al,0x1
    5764:	8a d0                	mov    dl,al
    5766:	83 7e dc 00          	cmp    WORD PTR [bp-0x24],0x0
    576a:	7c 0c                	jl     0x5778
    576c:	7f 06                	jg     0x5774
    576e:	83 7e da 00          	cmp    WORD PTR [bp-0x26],0x0
    5772:	72 04                	jb     0x5778
    5774:	b0 00                	mov    al,0x0
    5776:	eb 02                	jmp    0x577a
    5778:	b0 01                	mov    al,0x1
    577a:	0a c2                	or     al,dl
    577c:	08 c0                	or     al,al
    577e:	74 0f                	je     0x578f
    5780:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5783:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5789:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    578f:	bf 11 45             	mov    di,0x4511
    5792:	0e                   	push   cs
    5793:	57                   	push   di
    5794:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5798:	06                   	push   es
    5799:	57                   	push   di
    579a:	9a 9b 3b 93 58       	call   0x5893:0x3b9b
    579f:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    57a2:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    57a5:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    57a8:	06                   	push   es
    57a9:	57                   	push   di
    57aa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57ad:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    57b1:	89 86 20 ff          	mov    WORD PTR [bp-0xe0],ax
    57b5:	89 96 22 ff          	mov    WORD PTR [bp-0xde],dx
    57b9:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    57bc:	99                   	cwd
    57bd:	bf 54 44             	mov    di,0x4454
    57c0:	9a 16 04 1d 58       	call   0x581d:0x416
    57c5:	8b f8                	mov    di,ax
    57c7:	c1 e7 02             	shl    di,0x2
    57ca:	8b 83 04 ff          	mov    ax,WORD PTR [bp+di-0xfc]
    57ce:	8b 93 06 ff          	mov    dx,WORD PTR [bp+di-0xfa]
    57d2:	3b 96 22 ff          	cmp    dx,WORD PTR [bp-0xde]
    57d6:	7c 0c                	jl     0x57e4
    57d8:	7f 06                	jg     0x57e0
    57da:	3b 86 20 ff          	cmp    ax,WORD PTR [bp-0xe0]
    57de:	72 04                	jb     0x57e4
    57e0:	b0 00                	mov    al,0x0
    57e2:	eb 02                	jmp    0x57e6
    57e4:	b0 01                	mov    al,0x1
    57e6:	8a d0                	mov    dl,al
    57e8:	83 be 22 ff 00       	cmp    WORD PTR [bp-0xde],0x0
    57ed:	7c 0d                	jl     0x57fc
    57ef:	7f 07                	jg     0x57f8
    57f1:	83 be 20 ff 00       	cmp    WORD PTR [bp-0xe0],0x0
    57f6:	72 04                	jb     0x57fc
    57f8:	b0 00                	mov    al,0x0
    57fa:	eb 02                	jmp    0x57fe
    57fc:	b0 01                	mov    al,0x1
    57fe:	0a c2                	or     al,dl
    5800:	08 c0                	or     al,al
    5802:	74 0f                	je     0x5813
    5804:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5807:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    580d:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5813:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5816:	99                   	cwd
    5817:	bf 54 44             	mov    di,0x4454
    581a:	9a 16 04 73 58       	call   0x5873:0x416
    581f:	8b f8                	mov    di,ax
    5821:	c1 e7 02             	shl    di,0x2
    5824:	8b 83 04 ff          	mov    ax,WORD PTR [bp+di-0xfc]
    5828:	8b 93 06 ff          	mov    dx,WORD PTR [bp+di-0xfa]
    582c:	3b 96 22 ff          	cmp    dx,WORD PTR [bp-0xde]
    5830:	7c 0c                	jl     0x583e
    5832:	7f 06                	jg     0x583a
    5834:	3b 86 20 ff          	cmp    ax,WORD PTR [bp-0xe0]
    5838:	72 04                	jb     0x583e
    583a:	b0 00                	mov    al,0x0
    583c:	eb 02                	jmp    0x5840
    583e:	b0 01                	mov    al,0x1
    5840:	8a d0                	mov    dl,al
    5842:	83 be 22 ff 00       	cmp    WORD PTR [bp-0xde],0x0
    5847:	7f 0d                	jg     0x5856
    5849:	7c 07                	jl     0x5852
    584b:	83 be 20 ff 00       	cmp    WORD PTR [bp-0xe0],0x0
    5850:	77 04                	ja     0x5856
    5852:	b0 00                	mov    al,0x0
    5854:	eb 02                	jmp    0x5858
    5856:	b0 01                	mov    al,0x1
    5858:	22 c2                	and    al,dl
    585a:	08 c0                	or     al,al
    585c:	74 6b                	je     0x58c9
    585e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5861:	26 80 bd 11 04 00    	cmp    BYTE PTR es:[di+0x411],0x0
    5867:	74 51                	je     0x58ba
    5869:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    586c:	99                   	cwd
    586d:	bf 54 44             	mov    di,0x4454
    5870:	9a 16 04 d3 58       	call   0x58d3:0x416
    5875:	8b f8                	mov    di,ax
    5877:	c1 e7 02             	shl    di,0x2
    587a:	8b 83 04 ff          	mov    ax,WORD PTR [bp+di-0xfc]
    587e:	8b 93 06 ff          	mov    dx,WORD PTR [bp+di-0xfa]
    5882:	89 86 20 ff          	mov    WORD PTR [bp-0xe0],ax
    5886:	89 96 22 ff          	mov    WORD PTR [bp-0xde],dx
    588a:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    588e:	06                   	push   es
    588f:	57                   	push   di
    5890:	9a 3c 53 ab 58       	call   0x58ab:0x533c
    5895:	ff b6 22 ff          	push   WORD PTR [bp-0xde]
    5899:	ff b6 20 ff          	push   WORD PTR [bp-0xe0]
    589d:	bf 11 45             	mov    di,0x4511
    58a0:	0e                   	push   cs
    58a1:	57                   	push   di
    58a2:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    58a6:	06                   	push   es
    58a7:	57                   	push   di
    58a8:	9a 9b 3b 5e 59       	call   0x595e:0x3b9b
    58ad:	89 c7                	mov    di,ax
    58af:	8e c2                	mov    es,dx
    58b1:	06                   	push   es
    58b2:	57                   	push   di
    58b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    58b6:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    58ba:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    58bd:	26 c7 45 0c 02 00    	mov    WORD PTR es:[di+0xc],0x2
    58c3:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    58c9:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    58cc:	99                   	cwd
    58cd:	bf 54 44             	mov    di,0x4454
    58d0:	9a 16 04 ef 58       	call   0x58ef:0x416
    58d5:	8b f8                	mov    di,ax
    58d7:	c1 e7 02             	shl    di,0x2
    58da:	8b 83 04 ff          	mov    ax,WORD PTR [bp+di-0xfc]
    58de:	8b 93 06 ff          	mov    dx,WORD PTR [bp+di-0xfa]
    58e2:	03 86 24 ff          	add    ax,WORD PTR [bp-0xdc]
    58e6:	13 96 26 ff          	adc    dx,WORD PTR [bp-0xda]
    58ea:	71 05                	jno    0x58f1
    58ec:	9a 3e 04 fe 58       	call   0x58fe:0x43e
    58f1:	2b 86 20 ff          	sub    ax,WORD PTR [bp-0xe0]
    58f5:	1b 96 22 ff          	sbb    dx,WORD PTR [bp-0xde]
    58f9:	71 05                	jno    0x5900
    58fb:	9a 3e 04 12 59       	call   0x5912:0x43e
    5900:	89 86 1c ff          	mov    WORD PTR [bp-0xe4],ax
    5904:	89 96 1e ff          	mov    WORD PTR [bp-0xe2],dx
    5908:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    590b:	99                   	cwd
    590c:	bf 54 44             	mov    di,0x4454
    590f:	9a 16 04 39 59       	call   0x5939:0x416
    5914:	8b f8                	mov    di,ax
    5916:	c1 e7 02             	shl    di,0x2
    5919:	8b 83 6c ff          	mov    ax,WORD PTR [bp+di-0x94]
    591d:	8b 93 6e ff          	mov    dx,WORD PTR [bp+di-0x92]
    5921:	3b 96 1e ff          	cmp    dx,WORD PTR [bp-0xe2]
    5925:	7c 08                	jl     0x592f
    5927:	7f 27                	jg     0x5950
    5929:	3b 86 1c ff          	cmp    ax,WORD PTR [bp-0xe4]
    592d:	73 21                	jae    0x5950
    592f:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5932:	99                   	cwd
    5933:	bf 54 44             	mov    di,0x4454
    5936:	9a 16 04 bb 5a       	call   0x5abb:0x416
    593b:	8b f8                	mov    di,ax
    593d:	c1 e7 02             	shl    di,0x2
    5940:	8b 83 6c ff          	mov    ax,WORD PTR [bp+di-0x94]
    5944:	8b 93 6e ff          	mov    dx,WORD PTR [bp+di-0x92]
    5948:	89 86 1c ff          	mov    WORD PTR [bp-0xe4],ax
    594c:	89 96 1e ff          	mov    WORD PTR [bp-0xe2],dx
    5950:	bf 1d 45             	mov    di,0x451d
    5953:	0e                   	push   cs
    5954:	57                   	push   di
    5955:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5959:	06                   	push   es
    595a:	57                   	push   di
    595b:	9a 9b 3b 21 5a       	call   0x5a21:0x3b9b
    5960:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    5963:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    5966:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5969:	06                   	push   es
    596a:	57                   	push   di
    596b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    596e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5972:	89 86 5c ff          	mov    WORD PTR [bp-0xa4],ax
    5976:	89 96 5e ff          	mov    WORD PTR [bp-0xa2],dx
    597a:	8b 86 5c ff          	mov    ax,WORD PTR [bp-0xa4]
    597e:	8b 96 5e ff          	mov    dx,WORD PTR [bp-0xa2]
    5982:	3b 96 1e ff          	cmp    dx,WORD PTR [bp-0xe2]
    5986:	7f 0c                	jg     0x5994
    5988:	7c 06                	jl     0x5990
    598a:	3b 86 1c ff          	cmp    ax,WORD PTR [bp-0xe4]
    598e:	77 04                	ja     0x5994
    5990:	b0 00                	mov    al,0x0
    5992:	eb 02                	jmp    0x5996
    5994:	b0 01                	mov    al,0x1
    5996:	8a d0                	mov    dl,al
    5998:	83 be 5e ff 00       	cmp    WORD PTR [bp-0xa2],0x0
    599d:	7c 0d                	jl     0x59ac
    599f:	7f 07                	jg     0x59a8
    59a1:	83 be 5c ff 00       	cmp    WORD PTR [bp-0xa4],0x0
    59a6:	72 04                	jb     0x59ac
    59a8:	b0 00                	mov    al,0x0
    59aa:	eb 02                	jmp    0x59ae
    59ac:	b0 01                	mov    al,0x1
    59ae:	0a c2                	or     al,dl
    59b0:	08 c0                	or     al,al
    59b2:	74 0f                	je     0x59c3
    59b4:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    59b7:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    59bd:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    59c3:	8b 86 5c ff          	mov    ax,WORD PTR [bp-0xa4]
    59c7:	8b 96 5e ff          	mov    dx,WORD PTR [bp-0xa2]
    59cb:	3b 96 1e ff          	cmp    dx,WORD PTR [bp-0xe2]
    59cf:	7f 0c                	jg     0x59dd
    59d1:	7c 06                	jl     0x59d9
    59d3:	3b 86 1c ff          	cmp    ax,WORD PTR [bp-0xe4]
    59d7:	77 04                	ja     0x59dd
    59d9:	b0 00                	mov    al,0x0
    59db:	eb 02                	jmp    0x59df
    59dd:	b0 01                	mov    al,0x1
    59df:	8a d0                	mov    dl,al
    59e1:	83 be 5e ff 00       	cmp    WORD PTR [bp-0xa2],0x0
    59e6:	7f 0d                	jg     0x59f5
    59e8:	7c 07                	jl     0x59f1
    59ea:	83 be 5c ff 00       	cmp    WORD PTR [bp-0xa4],0x0
    59ef:	77 04                	ja     0x59f5
    59f1:	b0 00                	mov    al,0x0
    59f3:	eb 02                	jmp    0x59f7
    59f5:	b0 01                	mov    al,0x1
    59f7:	22 c2                	and    al,dl
    59f9:	08 c0                	or     al,al
    59fb:	74 5a                	je     0x5a57
    59fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a00:	26 80 bd 11 04 00    	cmp    BYTE PTR es:[di+0x411],0x0
    5a06:	74 40                	je     0x5a48
    5a08:	8b 86 1c ff          	mov    ax,WORD PTR [bp-0xe4]
    5a0c:	8b 96 1e ff          	mov    dx,WORD PTR [bp-0xe2]
    5a10:	89 86 5c ff          	mov    WORD PTR [bp-0xa4],ax
    5a14:	89 96 5e ff          	mov    WORD PTR [bp-0xa2],dx
    5a18:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5a1c:	06                   	push   es
    5a1d:	57                   	push   di
    5a1e:	9a 3c 53 39 5a       	call   0x5a39:0x533c
    5a23:	ff b6 5e ff          	push   WORD PTR [bp-0xa2]
    5a27:	ff b6 5c ff          	push   WORD PTR [bp-0xa4]
    5a2b:	bf 1d 45             	mov    di,0x451d
    5a2e:	0e                   	push   cs
    5a2f:	57                   	push   di
    5a30:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5a34:	06                   	push   es
    5a35:	57                   	push   di
    5a36:	9a 9b 3b 65 5a       	call   0x5a65:0x3b9b
    5a3b:	89 c7                	mov    di,ax
    5a3d:	8e c2                	mov    es,dx
    5a3f:	06                   	push   es
    5a40:	57                   	push   di
    5a41:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a44:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    5a48:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5a4b:	26 c7 45 0c 02 00    	mov    WORD PTR es:[di+0xc],0x2
    5a51:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5a57:	bf 30 45             	mov    di,0x4530
    5a5a:	0e                   	push   cs
    5a5b:	57                   	push   di
    5a5c:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5a60:	06                   	push   es
    5a61:	57                   	push   di
    5a62:	9a 9b 3b 88 5b       	call   0x5b88:0x3b9b
    5a67:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    5a6a:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    5a6d:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5a70:	06                   	push   es
    5a71:	57                   	push   di
    5a72:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a75:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5a79:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    5a7d:	90                   	nop
    5a7e:	9b                   	fwait
    5a7f:	8b 86 5c ff          	mov    ax,WORD PTR [bp-0xa4]
    5a83:	0b 86 5e ff          	or     ax,WORD PTR [bp-0xa2]
    5a87:	b0 00                	mov    al,0x0
    5a89:	74 01                	je     0x5a8c
    5a8b:	40                   	inc    ax
    5a8c:	8a d0                	mov    dl,al
    5a8e:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    5a92:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    5a98:	9b dd be ec fe       	fstsw  WORD PTR [bp-0x114]
    5a9d:	90                   	nop
    5a9e:	9b                   	fwait
    5a9f:	8a a6 ed fe          	mov    ah,BYTE PTR [bp-0x113]
    5aa3:	9e                   	sahf
    5aa4:	b0 00                	mov    al,0x0
    5aa6:	75 01                	jne    0x5aa9
    5aa8:	40                   	inc    ax
    5aa9:	22 c2                	and    al,dl
    5aab:	8a c8                	mov    cl,al
    5aad:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    5ab1:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5ab4:	99                   	cwd
    5ab5:	bf 54 44             	mov    di,0x4454
    5ab8:	9a 16 04 1a 5b       	call   0x5b1a:0x416
    5abd:	8b f8                	mov    di,ax
    5abf:	c1 e7 03             	shl    di,0x3
    5ac2:	9b dc 9b 58 ff       	fcomp  QWORD PTR [bp+di-0xa8]
    5ac7:	9b dd be ee fe       	fstsw  WORD PTR [bp-0x112]
    5acc:	90                   	nop
    5acd:	9b                   	fwait
    5ace:	8a a6 ef fe          	mov    ah,BYTE PTR [bp-0x111]
    5ad2:	9e                   	sahf
    5ad3:	b0 00                	mov    al,0x0
    5ad5:	76 01                	jbe    0x5ad8
    5ad7:	40                   	inc    ax
    5ad8:	8a d0                	mov    dl,al
    5ada:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    5ade:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    5ae4:	9b dd be f0 fe       	fstsw  WORD PTR [bp-0x110]
    5ae9:	90                   	nop
    5aea:	9b                   	fwait
    5aeb:	8a a6 f1 fe          	mov    ah,BYTE PTR [bp-0x10f]
    5aef:	9e                   	sahf
    5af0:	b0 00                	mov    al,0x0
    5af2:	73 01                	jae    0x5af5
    5af4:	40                   	inc    ax
    5af5:	0a c2                	or     al,dl
    5af7:	0a c1                	or     al,cl
    5af9:	08 c0                	or     al,al
    5afb:	74 0f                	je     0x5b0c
    5afd:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5b00:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5b06:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5b0c:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    5b10:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5b13:	99                   	cwd
    5b14:	bf 54 44             	mov    di,0x4454
    5b17:	9a 16 04 94 5b       	call   0x5b94:0x416
    5b1c:	8b f8                	mov    di,ax
    5b1e:	c1 e7 03             	shl    di,0x3
    5b21:	9b dc 9b 58 ff       	fcomp  QWORD PTR [bp+di-0xa8]
    5b26:	9b dd be ee fe       	fstsw  WORD PTR [bp-0x112]
    5b2b:	90                   	nop
    5b2c:	9b                   	fwait
    5b2d:	8a a6 ef fe          	mov    ah,BYTE PTR [bp-0x111]
    5b31:	9e                   	sahf
    5b32:	b0 00                	mov    al,0x0
    5b34:	76 01                	jbe    0x5b37
    5b36:	40                   	inc    ax
    5b37:	8a c8                	mov    cl,al
    5b39:	9b dd 46 e6          	fld    QWORD PTR [bp-0x1a]
    5b3d:	9b 2e d8 1e df 43    	fcomp  DWORD PTR cs:0x43df
    5b43:	9b dd be f0 fe       	fstsw  WORD PTR [bp-0x110]
    5b48:	90                   	nop
    5b49:	9b                   	fwait
    5b4a:	8a a6 f1 fe          	mov    ah,BYTE PTR [bp-0x10f]
    5b4e:	9e                   	sahf
    5b4f:	b0 00                	mov    al,0x0
    5b51:	76 01                	jbe    0x5b54
    5b53:	40                   	inc    ax
    5b54:	8a d0                	mov    dl,al
    5b56:	83 be 5e ff 00       	cmp    WORD PTR [bp-0xa2],0x0
    5b5b:	7f 0d                	jg     0x5b6a
    5b5d:	7c 07                	jl     0x5b66
    5b5f:	83 be 5c ff 00       	cmp    WORD PTR [bp-0xa4],0x0
    5b64:	77 04                	ja     0x5b6a
    5b66:	b0 00                	mov    al,0x0
    5b68:	eb 02                	jmp    0x5b6c
    5b6a:	b0 01                	mov    al,0x1
    5b6c:	22 c2                	and    al,dl
    5b6e:	22 c1                	and    al,cl
    5b70:	08 c0                	or     al,al
    5b72:	74 63                	je     0x5bd7
    5b74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b77:	26 80 bd 11 04 00    	cmp    BYTE PTR es:[di+0x411],0x0
    5b7d:	74 49                	je     0x5bc8
    5b7f:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5b83:	06                   	push   es
    5b84:	57                   	push   di
    5b85:	9a 3c 53 b9 5b       	call   0x5bb9:0x533c
    5b8a:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5b8d:	99                   	cwd
    5b8e:	bf 54 44             	mov    di,0x4454
    5b91:	9a 16 04 0d 5c       	call   0x5c0d:0x416
    5b96:	8b f8                	mov    di,ax
    5b98:	c1 e7 03             	shl    di,0x3
    5b9b:	ff b3 5e ff          	push   WORD PTR [bp+di-0xa2]
    5b9f:	ff b3 5c ff          	push   WORD PTR [bp+di-0xa4]
    5ba3:	ff b3 5a ff          	push   WORD PTR [bp+di-0xa6]
    5ba7:	ff b3 58 ff          	push   WORD PTR [bp+di-0xa8]
    5bab:	bf 30 45             	mov    di,0x4530
    5bae:	0e                   	push   cs
    5baf:	57                   	push   di
    5bb0:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    5bb4:	06                   	push   es
    5bb5:	57                   	push   di
    5bb6:	9a 9b 3b f9 5d       	call   0x5df9:0x3b9b
    5bbb:	89 c7                	mov    di,ax
    5bbd:	8e c2                	mov    es,dx
    5bbf:	06                   	push   es
    5bc0:	57                   	push   di
    5bc1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5bc4:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5bc8:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    5bcb:	26 c7 45 0c 02 00    	mov    WORD PTR es:[di+0xc],0x2
    5bd1:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5bd7:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5bda:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    5bde:	74 03                	je     0x5be3
    5be0:	e9 3e f6             	jmp    0x5221
    5be3:	31 c0                	xor    ax,ax
    5be5:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    5be8:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    5beb:	8b 46 92             	mov    ax,WORD PTR [bp-0x6e]
    5bee:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    5bf2:	b8 01 00             	mov    ax,0x1
    5bf5:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    5bf9:	7f 3b                	jg     0x5c36
    5bfb:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    5bfe:	eb 03                	jmp    0x5c03
    5c00:	ff 46 90             	inc    WORD PTR [bp-0x70]
    5c03:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5c06:	99                   	cwd
    5c07:	bf 54 44             	mov    di,0x4454
    5c0a:	9a 16 04 25 5c       	call   0x5c25:0x416
    5c0f:	8b f8                	mov    di,ax
    5c11:	c1 e7 02             	shl    di,0x2
    5c14:	8b 43 b6             	mov    ax,WORD PTR [bp+di-0x4a]
    5c17:	8b 53 b8             	mov    dx,WORD PTR [bp+di-0x48]
    5c1a:	03 46 da             	add    ax,WORD PTR [bp-0x26]
    5c1d:	13 56 dc             	adc    dx,WORD PTR [bp-0x24]
    5c20:	71 05                	jno    0x5c27
    5c22:	9a 3e 04 6a 5c       	call   0x5c6a:0x43e
    5c27:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    5c2a:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    5c2d:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5c30:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    5c34:	75 ca                	jne    0x5c00
    5c36:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    5c39:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    5c3c:	3b 96 1a ff          	cmp    dx,WORD PTR [bp-0xe6]
    5c40:	75 06                	jne    0x5c48
    5c42:	3b 86 18 ff          	cmp    ax,WORD PTR [bp-0xe8]
    5c46:	74 41                	je     0x5c89
    5c48:	8b 46 92             	mov    ax,WORD PTR [bp-0x6e]
    5c4b:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    5c4f:	b8 01 00             	mov    ax,0x1
    5c52:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    5c56:	7f 31                	jg     0x5c89
    5c58:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    5c5b:	eb 03                	jmp    0x5c60
    5c5d:	ff 46 90             	inc    WORD PTR [bp-0x70]
    5c60:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5c63:	99                   	cwd
    5c64:	bf 54 44             	mov    di,0x4454
    5c67:	9a 16 04 b3 5c       	call   0x5cb3:0x416
    5c6c:	8b f8                	mov    di,ax
    5c6e:	c1 e7 02             	shl    di,0x2
    5c71:	c4 7b be             	les    di,DWORD PTR [bp+di-0x42]
    5c74:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5c7a:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5c80:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5c83:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    5c87:	75 d4                	jne    0x5c5d
    5c89:	31 c0                	xor    ax,ax
    5c8b:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    5c8e:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    5c91:	8b 46 92             	mov    ax,WORD PTR [bp-0x6e]
    5c94:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    5c98:	b8 01 00             	mov    ax,0x1
    5c9b:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    5c9f:	7f 3b                	jg     0x5cdc
    5ca1:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    5ca4:	eb 03                	jmp    0x5ca9
    5ca6:	ff 46 90             	inc    WORD PTR [bp-0x70]
    5ca9:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5cac:	99                   	cwd
    5cad:	bf 54 44             	mov    di,0x4454
    5cb0:	9a 16 04 cb 5c       	call   0x5ccb:0x416
    5cb5:	8b f8                	mov    di,ax
    5cb7:	c1 e7 02             	shl    di,0x2
    5cba:	8b 43 96             	mov    ax,WORD PTR [bp+di-0x6a]
    5cbd:	8b 53 98             	mov    dx,WORD PTR [bp+di-0x68]
    5cc0:	03 46 96             	add    ax,WORD PTR [bp-0x6a]
    5cc3:	13 56 98             	adc    dx,WORD PTR [bp-0x68]
    5cc6:	71 05                	jno    0x5ccd
    5cc8:	9a 3e 04 ed 5c       	call   0x5ced:0x43e
    5ccd:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    5cd0:	89 56 98             	mov    WORD PTR [bp-0x68],dx
    5cd3:	8b 46 90             	mov    ax,WORD PTR [bp-0x70]
    5cd6:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    5cda:	75 ca                	jne    0x5ca6
    5cdc:	8b 46 aa             	mov    ax,WORD PTR [bp-0x56]
    5cdf:	8b 56 ac             	mov    dx,WORD PTR [bp-0x54]
    5ce2:	2b 46 ae             	sub    ax,WORD PTR [bp-0x52]
    5ce5:	1b 56 b0             	sbb    dx,WORD PTR [bp-0x50]
    5ce8:	71 05                	jno    0x5cef
    5cea:	9a 3e 04 fc 5c       	call   0x5cfc:0x43e
    5cef:	03 86 04 ff          	add    ax,WORD PTR [bp-0xfc]
    5cf3:	13 96 06 ff          	adc    dx,WORD PTR [bp-0xfa]
    5cf7:	71 05                	jno    0x5cfe
    5cf9:	9a 3e 04 31 5d       	call   0x5d31:0x43e
    5cfe:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    5d02:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    5d06:	9b db 86 f4 fe       	fild   DWORD PTR [bp-0x10c]
    5d0b:	9b dd 5e a2          	fstp   QWORD PTR [bp-0x5e]
    5d0f:	90                   	nop
    5d10:	9b                   	fwait
    5d11:	83 7e 94 00          	cmp    WORD PTR [bp-0x6c],0x0
    5d15:	75 03                	jne    0x5d1a
    5d17:	e9 fd 00             	jmp    0x5e17
    5d1a:	8b 46 94             	mov    ax,WORD PTR [bp-0x6c]
    5d1d:	99                   	cwd
    5d1e:	8b c8                	mov    cx,ax
    5d20:	8b da                	mov    bx,dx
    5d22:	8b 46 94             	mov    ax,WORD PTR [bp-0x6c]
    5d25:	99                   	cwd
    5d26:	03 46 96             	add    ax,WORD PTR [bp-0x6a]
    5d29:	13 56 98             	adc    dx,WORD PTR [bp-0x68]
    5d2c:	71 05                	jno    0x5d33
    5d2e:	9a 3e 04 3e 5d       	call   0x5d3e:0x43e
    5d33:	2d 01 00             	sub    ax,0x1
    5d36:	83 da 00             	sbb    dx,0x0
    5d39:	71 05                	jno    0x5d40
    5d3b:	9a 3e 04 43 5d       	call   0x5d43:0x43e
    5d40:	9a 70 16 cc 5d       	call   0x5dcc:0x1670
    5d45:	89 86 00 ff          	mov    WORD PTR [bp-0x100],ax
    5d49:	89 96 02 ff          	mov    WORD PTR [bp-0xfe],dx
    5d4d:	9b db 46 96          	fild   DWORD PTR [bp-0x6a]
    5d51:	9b dc 5e a2          	fcomp  QWORD PTR [bp-0x5e]
    5d55:	9b dd be f4 fe       	fstsw  WORD PTR [bp-0x10c]
    5d5a:	90                   	nop
    5d5b:	9b                   	fwait
    5d5c:	8a a6 f5 fe          	mov    ah,BYTE PTR [bp-0x10b]
    5d60:	9e                   	sahf
    5d61:	b0 00                	mov    al,0x0
    5d63:	73 01                	jae    0x5d66
    5d65:	40                   	inc    ax
    5d66:	8a d0                	mov    dl,al
    5d68:	9b db 86 00 ff       	fild   DWORD PTR [bp-0x100]
    5d6d:	9b dc 5e a2          	fcomp  QWORD PTR [bp-0x5e]
    5d71:	9b dd be f6 fe       	fstsw  WORD PTR [bp-0x10a]
    5d76:	90                   	nop
    5d77:	9b                   	fwait
    5d78:	8a a6 f7 fe          	mov    ah,BYTE PTR [bp-0x109]
    5d7c:	9e                   	sahf
    5d7d:	b0 00                	mov    al,0x0
    5d7f:	76 01                	jbe    0x5d82
    5d81:	40                   	inc    ax
    5d82:	0a c2                	or     al,dl
    5d84:	08 c0                	or     al,al
    5d86:	74 0f                	je     0x5d97
    5d88:	c4 7e b2             	les    di,DWORD PTR [bp-0x4e]
    5d8b:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    5d91:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5d97:	9b db 86 00 ff       	fild   DWORD PTR [bp-0x100]
    5d9c:	9b dc 5e a2          	fcomp  QWORD PTR [bp-0x5e]
    5da0:	9b dd be f6 fe       	fstsw  WORD PTR [bp-0x10a]
    5da5:	90                   	nop
    5da6:	9b                   	fwait
    5da7:	8a a6 f7 fe          	mov    ah,BYTE PTR [bp-0x109]
    5dab:	9e                   	sahf
    5dac:	76 69                	jbe    0x5e17
    5dae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5db1:	26 80 bd 11 04 00    	cmp    BYTE PTR es:[di+0x411],0x0
    5db7:	74 4f                	je     0x5e08
    5db9:	8b 86 04 ff          	mov    ax,WORD PTR [bp-0xfc]
    5dbd:	8b 96 06 ff          	mov    dx,WORD PTR [bp-0xfa]
    5dc1:	2b 46 ae             	sub    ax,WORD PTR [bp-0x52]
    5dc4:	1b 56 b0             	sbb    dx,WORD PTR [bp-0x50]
    5dc7:	71 05                	jno    0x5dce
    5dc9:	9a 3e 04 e3 5d       	call   0x5de3:0x43e
    5dce:	8b c8                	mov    cx,ax
    5dd0:	8b da                	mov    bx,dx
    5dd2:	8b 86 00 ff          	mov    ax,WORD PTR [bp-0x100]
    5dd6:	8b 96 02 ff          	mov    dx,WORD PTR [bp-0xfe]
    5dda:	2b c1                	sub    ax,cx
    5ddc:	1b d3                	sbb    dx,bx
    5dde:	71 05                	jno    0x5de5
    5de0:	9a 3e 04 32 5e       	call   0x5e32:0x43e
    5de5:	52                   	push   dx
    5de6:	50                   	push   ax
    5de7:	bf 34 44             	mov    di,0x4434
    5dea:	0e                   	push   cs
    5deb:	57                   	push   di
    5dec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5def:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    5df4:	06                   	push   es
    5df5:	57                   	push   di
    5df6:	9a 9b 3b ae 5f       	call   0x5fae:0x3b9b
    5dfb:	89 c7                	mov    di,ax
    5dfd:	8e c2                	mov    es,dx
    5dff:	06                   	push   es
    5e00:	57                   	push   di
    5e01:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e04:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    5e08:	c4 7e b2             	les    di,DWORD PTR [bp-0x4e]
    5e0b:	26 c7 45 0c 02 00    	mov    WORD PTR es:[di+0xc],0x2
    5e11:	26 c7 45 0e 00 00    	mov    WORD PTR es:[di+0xe],0x0
    5e17:	c6 46 fd 00          	mov    BYTE PTR [bp-0x3],0x0
    5e1b:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    5e20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e23:	06                   	push   es
    5e24:	57                   	push   di
    5e25:	9a 7d 52 7c 5e       	call   0x5e7c:0x527d
    5e2a:	2d 01 00             	sub    ax,0x1
    5e2d:	71 05                	jno    0x5e34
    5e2f:	9a 3e 04 71 5e       	call   0x5e71:0x43e
    5e34:	99                   	cwd
    5e35:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    5e39:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    5e3d:	31 c0                	xor    ax,ax
    5e3f:	31 d2                	xor    dx,dx
    5e41:	3b 96 f6 fe          	cmp    dx,WORD PTR [bp-0x10a]
    5e45:	7e 03                	jle    0x5e4a
    5e47:	e9 7c 03             	jmp    0x61c6
    5e4a:	7c 09                	jl     0x5e55
    5e4c:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    5e50:	76 03                	jbe    0x5e55
    5e52:	e9 71 03             	jmp    0x61c6
    5e55:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    5e58:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    5e5b:	eb 08                	jmp    0x5e65
    5e5d:	83 46 da 01          	add    WORD PTR [bp-0x26],0x1
    5e61:	83 56 dc 00          	adc    WORD PTR [bp-0x24],0x0
    5e65:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    5e68:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    5e6b:	bf 3f 45             	mov    di,0x453f
    5e6e:	9a 16 04 8b 5e       	call   0x5e8b:0x416
    5e73:	50                   	push   ax
    5e74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e77:	06                   	push   es
    5e78:	57                   	push   di
    5e79:	9a 46 52 ab 5e       	call   0x5eab:0x5246
    5e7e:	52                   	push   dx
    5e7f:	50                   	push   ax
    5e80:	bf 99 03             	mov    di,0x399
    5e83:	b8 b3 5e             	mov    ax,0x5eb3
    5e86:	50                   	push   ax
    5e87:	57                   	push   di
    5e88:	9a 55 22 a0 5e       	call   0x5ea0:0x2255
    5e8d:	08 c0                	or     al,al
    5e8f:	75 03                	jne    0x5e94
    5e91:	e9 1a 03             	jmp    0x61ae
    5e94:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    5e97:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    5e9a:	bf 3f 45             	mov    di,0x453f
    5e9d:	9a 16 04 ba 5e       	call   0x5eba:0x416
    5ea2:	50                   	push   ax
    5ea3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ea6:	06                   	push   es
    5ea7:	57                   	push   di
    5ea8:	9a 46 52 e1 5e       	call   0x5ee1:0x5246
    5ead:	52                   	push   dx
    5eae:	50                   	push   ax
    5eaf:	bf 99 03             	mov    di,0x399
    5eb2:	b8 31 61             	mov    ax,0x6131
    5eb5:	50                   	push   ax
    5eb6:	57                   	push   di
    5eb7:	9a 73 22 d6 5e       	call   0x5ed6:0x2273
    5ebc:	89 c7                	mov    di,ax
    5ebe:	8e c2                	mov    es,dx
    5ec0:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5ec5:	75 03                	jne    0x5eca
    5ec7:	e9 e4 02             	jmp    0x61ae
    5eca:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    5ecd:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    5ed0:	bf 3f 45             	mov    di,0x453f
    5ed3:	9a 16 04 f0 5e       	call   0x5ef0:0x416
    5ed8:	50                   	push   ax
    5ed9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5edc:	06                   	push   es
    5edd:	57                   	push   di
    5ede:	9a 46 52 0a 5f       	call   0x5f0a:0x5246
    5ee3:	52                   	push   dx
    5ee4:	50                   	push   ax
    5ee5:	bf a2 0b             	mov    di,0xba2
    5ee8:	b8 12 5f             	mov    ax,0x5f12
    5eeb:	50                   	push   ax
    5eec:	57                   	push   di
    5eed:	9a 55 22 ff 5e       	call   0x5eff:0x2255
    5ef2:	50                   	push   ax
    5ef3:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    5ef6:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    5ef9:	bf 3f 45             	mov    di,0x453f
    5efc:	9a 16 04 19 5f       	call   0x5f19:0x416
    5f01:	50                   	push   ax
    5f02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f05:	06                   	push   es
    5f06:	57                   	push   di
    5f07:	9a 46 52 3c 5f       	call   0x5f3c:0x5246
    5f0c:	52                   	push   dx
    5f0d:	50                   	push   ax
    5f0e:	bf 22 00             	mov    di,0x22
    5f11:	b8 44 5f             	mov    ax,0x5f44
    5f14:	50                   	push   ax
    5f15:	57                   	push   di
    5f16:	9a 55 22 31 5f       	call   0x5f31:0x2255
    5f1b:	5a                   	pop    dx
    5f1c:	0a c2                	or     al,dl
    5f1e:	08 c0                	or     al,al
    5f20:	75 03                	jne    0x5f25
    5f22:	e9 89 02             	jmp    0x61ae
    5f25:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    5f28:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    5f2b:	bf 3f 45             	mov    di,0x453f
    5f2e:	9a 16 04 4b 5f       	call   0x5f4b:0x416
    5f33:	50                   	push   ax
    5f34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f37:	06                   	push   es
    5f38:	57                   	push   di
    5f39:	9a 46 52 68 5f       	call   0x5f68:0x5246
    5f3e:	52                   	push   dx
    5f3f:	50                   	push   ax
    5f40:	bf 22 00             	mov    di,0x22
    5f43:	b8 70 5f             	mov    ax,0x5f70
    5f46:	50                   	push   ax
    5f47:	57                   	push   di
    5f48:	9a 55 22 5d 5f       	call   0x5f5d:0x2255
    5f4d:	08 c0                	or     al,al
    5f4f:	74 65                	je     0x5fb6
    5f51:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    5f54:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    5f57:	bf 3f 45             	mov    di,0x453f
    5f5a:	9a 16 04 77 5f       	call   0x5f77:0x416
    5f5f:	50                   	push   ax
    5f60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f63:	06                   	push   es
    5f64:	57                   	push   di
    5f65:	9a 46 52 cd 5f       	call   0x5fcd:0x5246
    5f6a:	52                   	push   dx
    5f6b:	50                   	push   ax
    5f6c:	bf 22 00             	mov    di,0x22
    5f6f:	b8 94 5f             	mov    ax,0x5f94
    5f72:	50                   	push   ax
    5f73:	57                   	push   di
    5f74:	9a 73 22 c2 5f       	call   0x5fc2:0x2273
    5f79:	89 c7                	mov    di,ax
    5f7b:	8e c2                	mov    es,dx
    5f7d:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    5f81:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    5f85:	8d be f0 fd          	lea    di,[bp-0x210]
    5f89:	16                   	push   ss
    5f8a:	57                   	push   di
    5f8b:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    5f8f:	06                   	push   es
    5f90:	57                   	push   di
    5f91:	9a 9f 1a 9f 5f       	call   0x5f9f:0x1a9f
    5f96:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    5f9a:	06                   	push   es
    5f9b:	57                   	push   di
    5f9c:	9a 5f 1a d5 5f       	call   0x5fd5:0x1a5f
    5fa1:	89 c7                	mov    di,ax
    5fa3:	8e c2                	mov    es,dx
    5fa5:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5fa9:	06                   	push   es
    5faa:	57                   	push   di
    5fab:	9a 9b 3b 3f 60       	call   0x603f:0x3b9b
    5fb0:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    5fb3:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    5fb6:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    5fb9:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    5fbc:	bf 3f 45             	mov    di,0x453f
    5fbf:	9a 16 04 dc 5f       	call   0x5fdc:0x416
    5fc4:	50                   	push   ax
    5fc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fc8:	06                   	push   es
    5fc9:	57                   	push   di
    5fca:	9a 46 52 f9 5f       	call   0x5ff9:0x5246
    5fcf:	52                   	push   dx
    5fd0:	50                   	push   ax
    5fd1:	bf a2 0b             	mov    di,0xba2
    5fd4:	b8 01 60             	mov    ax,0x6001
    5fd7:	50                   	push   ax
    5fd8:	57                   	push   di
    5fd9:	9a 55 22 ee 5f       	call   0x5fee:0x2255
    5fde:	08 c0                	or     al,al
    5fe0:	74 65                	je     0x6047
    5fe2:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    5fe5:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    5fe8:	bf 3f 45             	mov    di,0x453f
    5feb:	9a 16 04 08 60       	call   0x6008:0x416
    5ff0:	50                   	push   ax
    5ff1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ff4:	06                   	push   es
    5ff5:	57                   	push   di
    5ff6:	9a 46 52 cf 60       	call   0x60cf:0x5246
    5ffb:	52                   	push   dx
    5ffc:	50                   	push   ax
    5ffd:	bf a2 0b             	mov    di,0xba2
    6000:	b8 25 60             	mov    ax,0x6025
    6003:	50                   	push   ax
    6004:	57                   	push   di
    6005:	9a 73 22 c4 60       	call   0x60c4:0x2273
    600a:	89 c7                	mov    di,ax
    600c:	8e c2                	mov    es,dx
    600e:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    6012:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    6016:	8d be f0 fd          	lea    di,[bp-0x210]
    601a:	16                   	push   ss
    601b:	57                   	push   di
    601c:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    6020:	06                   	push   es
    6021:	57                   	push   di
    6022:	9a 92 2a 30 60       	call   0x6030:0x2a92
    6027:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    602b:	06                   	push   es
    602c:	57                   	push   di
    602d:	9a 52 2a d7 60       	call   0x60d7:0x2a52
    6032:	89 c7                	mov    di,ax
    6034:	8e c2                	mov    es,dx
    6036:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    603a:	06                   	push   es
    603b:	57                   	push   di
    603c:	9a 9b 3b f5 66       	call   0x66f5:0x3b9b
    6041:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    6044:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    6047:	c7 46 f6 fa ff       	mov    WORD PTR [bp-0xa],0xfffa
    604c:	c7 46 f8 ff ff       	mov    WORD PTR [bp-0x8],0xffff
    6051:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    6054:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    6059:	75 15                	jne    0x6070
    605b:	26 83 7d 0c 01       	cmp    WORD PTR es:[di+0xc],0x1
    6060:	75 0e                	jne    0x6070
    6062:	c7 46 f6 ff 00       	mov    WORD PTR [bp-0xa],0xff
    6067:	c7 46 f8 00 00       	mov    WORD PTR [bp-0x8],0x0
    606c:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    6070:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    6073:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
    6078:	75 31                	jne    0x60ab
    607a:	26 83 7d 0c 02       	cmp    WORD PTR es:[di+0xc],0x2
    607f:	75 2a                	jne    0x60ab
    6081:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6084:	26 80 bd 11 04 00    	cmp    BYTE PTR es:[di+0x411],0x0
    608a:	74 0c                	je     0x6098
    608c:	c7 46 f6 ff ff       	mov    WORD PTR [bp-0xa],0xffff
    6091:	c7 46 f8 00 00       	mov    WORD PTR [bp-0x8],0x0
    6096:	eb 13                	jmp    0x60ab
    6098:	c7 46 f6 ff 00       	mov    WORD PTR [bp-0xa],0xff
    609d:	c7 46 f8 00 00       	mov    WORD PTR [bp-0x8],0x0
    60a2:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    60a6:	c7 46 fa 02 00       	mov    WORD PTR [bp-0x6],0x2
    60ab:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    60ae:	31 c0                	xor    ax,ax
    60b0:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    60b4:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    60b8:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    60bb:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    60be:	bf 3f 45             	mov    di,0x453f
    60c1:	9a 16 04 de 60       	call   0x60de:0x416
    60c6:	50                   	push   ax
    60c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60ca:	06                   	push   es
    60cb:	57                   	push   di
    60cc:	9a 46 52 fb 60       	call   0x60fb:0x5246
    60d1:	52                   	push   dx
    60d2:	50                   	push   ax
    60d3:	bf 22 00             	mov    di,0x22
    60d6:	b8 03 61             	mov    ax,0x6103
    60d9:	50                   	push   ax
    60da:	57                   	push   di
    60db:	9a 55 22 f0 60       	call   0x60f0:0x2255
    60e0:	08 c0                	or     al,al
    60e2:	74 4f                	je     0x6133
    60e4:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    60e7:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    60ea:	bf 3f 45             	mov    di,0x453f
    60ed:	9a 16 04 0a 61       	call   0x610a:0x416
    60f2:	50                   	push   ax
    60f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60f6:	06                   	push   es
    60f7:	57                   	push   di
    60f8:	9a 46 52 4a 61       	call   0x614a:0x5246
    60fd:	52                   	push   dx
    60fe:	50                   	push   ax
    60ff:	bf 22 00             	mov    di,0x22
    6102:	b8 52 61             	mov    ax,0x6152
    6105:	50                   	push   ax
    6106:	57                   	push   di
    6107:	9a 73 22 24 61       	call   0x6124:0x2273
    610c:	89 c7                	mov    di,ax
    610e:	8e c2                	mov    es,dx
    6110:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    6114:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    6118:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    611b:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    611e:	bf 47 45             	mov    di,0x4547
    6121:	9a 16 04 3f 61       	call   0x613f:0x416
    6126:	52                   	push   dx
    6127:	50                   	push   ax
    6128:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    612c:	06                   	push   es
    612d:	57                   	push   di
    612e:	9a d5 1e ac 61       	call   0x61ac:0x1ed5
    6133:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    6136:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    6139:	bf 3f 45             	mov    di,0x453f
    613c:	9a 16 04 59 61       	call   0x6159:0x416
    6141:	50                   	push   ax
    6142:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6145:	06                   	push   es
    6146:	57                   	push   di
    6147:	9a 46 52 76 61       	call   0x6176:0x5246
    614c:	52                   	push   dx
    614d:	50                   	push   ax
    614e:	bf a2 0b             	mov    di,0xba2
    6151:	b8 7e 61             	mov    ax,0x617e
    6154:	50                   	push   ax
    6155:	57                   	push   di
    6156:	9a 55 22 6b 61       	call   0x616b:0x2255
    615b:	08 c0                	or     al,al
    615d:	74 4f                	je     0x61ae
    615f:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    6162:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    6165:	bf 3f 45             	mov    di,0x453f
    6168:	9a 16 04 85 61       	call   0x6185:0x416
    616d:	50                   	push   ax
    616e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6171:	06                   	push   es
    6172:	57                   	push   di
    6173:	9a 46 52 ff ff       	call   0xffff:0x5246
    6178:	52                   	push   dx
    6179:	50                   	push   ax
    617a:	bf a2 0b             	mov    di,0xba2
    617d:	b8 8e 66             	mov    ax,0x668e
    6180:	50                   	push   ax
    6181:	57                   	push   di
    6182:	9a 73 22 9f 61       	call   0x619f:0x2273
    6187:	89 c7                	mov    di,ax
    6189:	8e c2                	mov    es,dx
    618b:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    618f:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    6193:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    6196:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    6199:	bf 47 45             	mov    di,0x4547
    619c:	9a 16 04 14 62       	call   0x6214:0x416
    61a1:	52                   	push   dx
    61a2:	50                   	push   ax
    61a3:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    61a7:	06                   	push   es
    61a8:	57                   	push   di
    61a9:	9a d5 1e c9 62       	call   0x62c9:0x1ed5
    61ae:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    61b1:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    61b4:	3b 96 f6 fe          	cmp    dx,WORD PTR [bp-0x10a]
    61b8:	74 03                	je     0x61bd
    61ba:	e9 a0 fc             	jmp    0x5e5d
    61bd:	3b 86 f4 fe          	cmp    ax,WORD PTR [bp-0x10c]
    61c1:	74 03                	je     0x61c6
    61c3:	e9 97 fc             	jmp    0x5e5d
    61c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61c9:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    61cf:	74 20                	je     0x61f1
    61d1:	80 7e fd 00          	cmp    BYTE PTR [bp-0x3],0x0
    61d5:	b0 00                	mov    al,0x0
    61d7:	75 01                	jne    0x61da
    61d9:	40                   	inc    ax
    61da:	26 88 85 10 04       	mov    BYTE PTR es:[di+0x410],al
    61df:	26 8a 85 10 04       	mov    al,BYTE PTR es:[di+0x410]
    61e4:	50                   	push   ax
    61e5:	26 c4 bd e0 03       	les    di,DWORD PTR es:[di+0x3e0]
    61ea:	06                   	push   es
    61eb:	57                   	push   di
    61ec:	9a 11 6e c2 65       	call   0x65c2:0x6e11
    61f1:	80 7e fd 00          	cmp    BYTE PTR [bp-0x3],0x0
    61f5:	74 08                	je     0x61ff
    61f7:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    61fa:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    61fd:	eb 05                	jmp    0x6204
    61ff:	31 c0                	xor    ax,ax
    6201:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6204:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6207:	c9                   	leave
    6208:	ca 04 00             	retf   0x4
    620b:	55                   	push   bp
    620c:	89 e5                	mov    bp,sp
    620e:	b8 04 00             	mov    ax,0x4
    6211:	9a 44 04 93 62       	call   0x6293:0x444
    6216:	83 ec 04             	sub    sp,0x4
    6219:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    621c:	26 c6 85 11 04 00    	mov    BYTE PTR es:[di+0x411],0x0
    6222:	06                   	push   es
    6223:	57                   	push   di
    6224:	9a 4f 45 60 62       	call   0x6260:0x454f
    6229:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    622c:	83 7e fc 01          	cmp    WORD PTR [bp-0x4],0x1
    6230:	75 05                	jne    0x6237
    6232:	9a fb 36 6a 62       	call   0x626a:0x36fb
    6237:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    623b:	75 2f                	jne    0x626c
    623d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6240:	26 80 bd 09 04 00    	cmp    BYTE PTR es:[di+0x409],0x0
    6246:	74 1f                	je     0x6267
    6248:	9a 6b 3c ff ff       	call   0xffff:0x3c6b
    624d:	3d 06 00             	cmp    ax,0x6
    6250:	75 13                	jne    0x6265
    6252:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6255:	26 c6 85 11 04 01    	mov    BYTE PTR es:[di+0x411],0x1
    625b:	06                   	push   es
    625c:	57                   	push   di
    625d:	9a 4f 45 e0 64       	call   0x64e0:0x454f
    6262:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6265:	eb 05                	jmp    0x626c
    6267:	9a fb 36 75 62       	call   0x6275:0x36fb
    626c:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    6270:	75 05                	jne    0x6277
    6272:	9a 75 36 39 79       	call   0x7939:0x3675
    6277:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    627b:	b0 00                	mov    al,0x0
    627d:	75 01                	jne    0x6280
    627f:	40                   	inc    ax
    6280:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6283:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6286:	c9                   	leave
    6287:	ca 04 00             	retf   0x4
    628a:	55                   	push   bp
    628b:	89 e5                	mov    bp,sp
    628d:	b8 08 02             	mov    ax,0x208
    6290:	9a 44 04 18 63       	call   0x6318:0x444
    6295:	81 ec 08 02          	sub    sp,0x208
    6299:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    629c:	26 c4 bd e4 03       	les    di,DWORD PTR es:[di+0x3e4]
    62a1:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    62a4:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    62a7:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    62ab:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    62ae:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    62b1:	06                   	push   es
    62b2:	57                   	push   di
    62b3:	9a 1a 12 d3 62       	call   0x62d3:0x121a
    62b8:	a8 08                	test   al,0x8
    62ba:	74 36                	je     0x62f2
    62bc:	bf 68 02             	mov    di,0x268
    62bf:	1e                   	push   ds
    62c0:	57                   	push   di
    62c1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    62c4:	06                   	push   es
    62c5:	57                   	push   di
    62c6:	9a 8c 1d 0b 63       	call   0x630b:0x1d8c
    62cb:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    62ce:	06                   	push   es
    62cf:	57                   	push   di
    62d0:	9a 1a 12 e0 62       	call   0x62e0:0x121a
    62d5:	24 f7                	and    al,0xf7
    62d7:	50                   	push   ax
    62d8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    62db:	06                   	push   es
    62dc:	57                   	push   di
    62dd:	9a 33 12 ee 62       	call   0x62ee:0x1233
    62e2:	6a 00                	push   0x0
    62e4:	6a 00                	push   0x0
    62e6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    62e9:	06                   	push   es
    62ea:	57                   	push   di
    62eb:	9a df 0f 47 63       	call   0x6347:0xfdf
    62f0:	eb 73                	jmp    0x6365
    62f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62f5:	26 80 bd 10 04 00    	cmp    BYTE PTR es:[di+0x410],0x0
    62fb:	75 68                	jne    0x6365
    62fd:	8d be f8 fe          	lea    di,[bp-0x108]
    6301:	16                   	push   ss
    6302:	57                   	push   di
    6303:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6306:	06                   	push   es
    6307:	57                   	push   di
    6308:	9a 53 1d 2e 63       	call   0x632e:0x1d53
    630d:	bf 68 02             	mov    di,0x268
    6310:	1e                   	push   ds
    6311:	57                   	push   di
    6312:	68 ff 00             	push   0xff
    6315:	9a e7 17 71 63       	call   0x6371:0x17e7
    631a:	8d be f8 fd          	lea    di,[bp-0x208]
    631e:	16                   	push   ss
    631f:	57                   	push   di
    6320:	8d be f8 fe          	lea    di,[bp-0x108]
    6324:	16                   	push   ss
    6325:	57                   	push   di
    6326:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6329:	06                   	push   es
    632a:	57                   	push   di
    632b:	9a 53 1d 3d 63       	call   0x633d:0x1d53
    6330:	9a 81 07 90 69       	call   0x6990:0x781
    6335:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6338:	06                   	push   es
    6339:	57                   	push   di
    633a:	9a 8c 1d 89 64       	call   0x6489:0x1d8c
    633f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6342:	06                   	push   es
    6343:	57                   	push   di
    6344:	9a 1a 12 54 63       	call   0x6354:0x121a
    6349:	0c 08                	or     al,0x8
    634b:	50                   	push   ax
    634c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    634f:	06                   	push   es
    6350:	57                   	push   di
    6351:	9a 33 12 63 63       	call   0x6363:0x1233
    6356:	6a 00                	push   0x0
    6358:	68 ff 00             	push   0xff
    635b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    635e:	06                   	push   es
    635f:	57                   	push   di
    6360:	9a df 0f 8b 7a       	call   0x7a8b:0xfdf
    6365:	c9                   	leave
    6366:	ca 08 00             	retf   0x8
    6369:	55                   	push   bp
    636a:	89 e5                	mov    bp,sp
    636c:	31 c0                	xor    ax,ax
    636e:	9a 44 04 8c 63       	call   0x638c:0x444
    6373:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6376:	26 80 3d 2e          	cmp    BYTE PTR es:[di],0x2e
    637a:	75 04                	jne    0x6380
    637c:	26 c6 05 2c          	mov    BYTE PTR es:[di],0x2c
    6380:	c9                   	leave
    6381:	ca 0c 00             	retf   0xc
    6384:	55                   	push   bp
    6385:	89 e5                	mov    bp,sp
    6387:	31 c0                	xor    ax,ax
    6389:	9a 44 04 cb 63       	call   0x63cb:0x444
    638e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6392:	b0 00                	mov    al,0x0
    6394:	75 01                	jne    0x6397
    6396:	40                   	inc    ax
    6397:	8a d0                	mov    dl,al
    6399:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    639c:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    63a0:	b0 00                	mov    al,0x0
    63a2:	75 01                	jne    0x63a5
    63a4:	40                   	inc    ax
    63a5:	22 c2                	and    al,dl
    63a7:	08 c0                	or     al,al
    63a9:	74 14                	je     0x63bf
    63ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63ae:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
    63b3:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    63b8:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    63bd:	74 00                	je     0x63bf
    63bf:	c9                   	leave
    63c0:	ca 0e 00             	retf   0xe
    63c3:	55                   	push   bp
    63c4:	89 e5                	mov    bp,sp
    63c6:	31 c0                	xor    ax,ax
    63c8:	9a 44 04 f9 63       	call   0x63f9:0x444
    63cd:	6a 01                	push   0x1
    63cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63d2:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    63d7:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    63dc:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    63e1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    63e5:	06                   	push   es
    63e6:	57                   	push   di
    63e7:	9a b2 77 65 64       	call   0x6465:0x77b2
    63ec:	c9                   	leave
    63ed:	ca 08 00             	retf   0x8
    63f0:	55                   	push   bp
    63f1:	89 e5                	mov    bp,sp
    63f3:	b8 04 00             	mov    ax,0x4
    63f6:	9a 44 04 74 64       	call   0x6474:0x444
    63fb:	83 ec 04             	sub    sp,0x4
    63fe:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6401:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    6406:	b0 00                	mov    al,0x0
    6408:	75 01                	jne    0x640b
    640a:	40                   	inc    ax
    640b:	8a c8                	mov    cl,al
    640d:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    6413:	b0 00                	mov    al,0x0
    6415:	77 01                	ja     0x6418
    6417:	40                   	inc    ax
    6418:	8a d0                	mov    dl,al
    641a:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    6420:	b0 00                	mov    al,0x0
    6422:	76 01                	jbe    0x6425
    6424:	40                   	inc    ax
    6425:	22 c2                	and    al,dl
    6427:	0a c1                	or     al,cl
    6429:	08 c0                	or     al,al
    642b:	74 3a                	je     0x6467
    642d:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6431:	31 c0                	xor    ax,ax
    6433:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    6437:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    643b:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    643f:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    6443:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6446:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    644a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    644d:	06                   	push   es
    644e:	57                   	push   di
    644f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6452:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    6456:	6a 02                	push   0x2
    6458:	6a 00                	push   0x0
    645a:	6a 00                	push   0x0
    645c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6460:	06                   	push   es
    6461:	57                   	push   di
    6462:	9a b2 77 cb 64       	call   0x64cb:0x77b2
    6467:	c9                   	leave
    6468:	ca 0c 00             	retf   0xc
    646b:	55                   	push   bp
    646c:	89 e5                	mov    bp,sp
    646e:	b8 04 00             	mov    ax,0x4
    6471:	9a 44 04 90 64       	call   0x6490:0x444
    6476:	83 ec 04             	sub    sp,0x4
    6479:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    647d:	75 76                	jne    0x64f5
    647f:	ff 76 14             	push   WORD PTR [bp+0x14]
    6482:	ff 76 12             	push   WORD PTR [bp+0x12]
    6485:	bf c1 05             	mov    di,0x5c1
    6488:	b8 ac 64             	mov    ax,0x64ac
    648b:	50                   	push   ax
    648c:	57                   	push   di
    648d:	9a 55 22 b3 64       	call   0x64b3:0x2255
    6492:	08 c0                	or     al,al
    6494:	74 5f                	je     0x64f5
    6496:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    649a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    649d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    64a0:	6a 08                	push   0x8
    64a2:	ff 76 14             	push   WORD PTR [bp+0x14]
    64a5:	ff 76 12             	push   WORD PTR [bp+0x12]
    64a8:	bf c1 05             	mov    di,0x5c1
    64ab:	b8 17 65             	mov    ax,0x6517
    64ae:	50                   	push   ax
    64af:	57                   	push   di
    64b0:	9a 73 22 02 65       	call   0x6502:0x2273
    64b5:	89 c7                	mov    di,ax
    64b7:	8e c2                	mov    es,dx
    64b9:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    64be:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    64c3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    64c6:	06                   	push   es
    64c7:	57                   	push   di
    64c8:	9a b2 77 d5 64       	call   0x64d5:0x77b2
    64cd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    64d0:	06                   	push   es
    64d1:	57                   	push   di
    64d2:	9a 03 73 5c 65       	call   0x655c:0x7303
    64d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64da:	06                   	push   es
    64db:	57                   	push   di
    64dc:	b8 f0 63             	mov    ax,0x63f0
    64df:	ba ee 6a             	mov    dx,0x6aee
    64e2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    64e5:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    64e9:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    64ed:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    64f1:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    64f5:	c9                   	leave
    64f6:	ca 10 00             	retf   0x10
    64f9:	55                   	push   bp
    64fa:	89 e5                	mov    bp,sp
    64fc:	b8 04 00             	mov    ax,0x4
    64ff:	9a 44 04 1e 65       	call   0x651e:0x444
    6504:	83 ec 04             	sub    sp,0x4
    6507:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    650b:	75 51                	jne    0x655e
    650d:	ff 76 14             	push   WORD PTR [bp+0x14]
    6510:	ff 76 12             	push   WORD PTR [bp+0x12]
    6513:	bf c1 05             	mov    di,0x5c1
    6516:	b8 2e 65             	mov    ax,0x652e
    6519:	50                   	push   ax
    651a:	57                   	push   di
    651b:	9a 55 22 35 65       	call   0x6535:0x2255
    6520:	08 c0                	or     al,al
    6522:	74 3a                	je     0x655e
    6524:	ff 76 14             	push   WORD PTR [bp+0x14]
    6527:	ff 76 12             	push   WORD PTR [bp+0x12]
    652a:	bf c1 05             	mov    di,0x5c1
    652d:	b8 0a 66             	mov    ax,0x660a
    6530:	50                   	push   ax
    6531:	57                   	push   di
    6532:	9a 73 22 75 65       	call   0x6575:0x2273
    6537:	89 c7                	mov    di,ax
    6539:	8e c2                	mov    es,dx
    653b:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    6540:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    6545:	74 17                	je     0x655e
    6547:	6a 08                	push   0x8
    6549:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    654e:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    6553:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    6557:	06                   	push   es
    6558:	57                   	push   di
    6559:	9a b2 77 58 79       	call   0x7958:0x77b2
    655e:	c9                   	leave
    655f:	ca 10 00             	retf   0x10
    6562:	01 09                	add    WORD PTR [bx+di],cx
    6564:	03 6f 75             	add    bp,WORD PTR [bx+0x75]
    6567:	69 03 6e 6f          	imul   ax,WORD PTR [bp+di],0x6f6e
    656b:	6e                   	outs   dx,BYTE PTR ds:[si]
    656c:	55                   	push   bp
    656d:	89 e5                	mov    bp,sp
    656f:	b8 04 03             	mov    ax,0x304
    6572:	9a 44 04 92 65       	call   0x6592:0x444
    6577:	81 ec 04 03          	sub    sp,0x304
    657b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    657e:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    6582:	76 27                	jbe    0x65ab
    6584:	8d be 00 ff          	lea    di,[bp-0x100]
    6588:	16                   	push   ss
    6589:	57                   	push   di
    658a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    658d:	06                   	push   es
    658e:	57                   	push   di
    658f:	9a cd 17 9c 65       	call   0x659c:0x17cd
    6594:	bf 62 65             	mov    di,0x6562
    6597:	0e                   	push   cs
    6598:	57                   	push   di
    6599:	9a 4c 18 a9 65       	call   0x65a9:0x184c
    659e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    65a1:	06                   	push   es
    65a2:	57                   	push   di
    65a3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    65a6:	9a e7 17 c9 65       	call   0x65c9:0x17e7
    65ab:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    65ae:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    65b3:	75 03                	jne    0x65b8
    65b5:	e9 ec 03             	jmp    0x69a4
    65b8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    65bb:	ff 76 08             	push   WORD PTR [bp+0x8]
    65be:	bf 0c 01             	mov    di,0x10c
    65c1:	b8 d9 65             	mov    ax,0x65d9
    65c4:	50                   	push   ax
    65c5:	57                   	push   di
    65c6:	9a 55 22 e0 65       	call   0x65e0:0x2255
    65cb:	08 c0                	or     al,al
    65cd:	74 4f                	je     0x661e
    65cf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    65d2:	ff 76 08             	push   WORD PTR [bp+0x8]
    65d5:	bf 0c 01             	mov    di,0x10c
    65d8:	b8 86 67             	mov    ax,0x6786
    65db:	50                   	push   ax
    65dc:	57                   	push   di
    65dd:	9a 73 22 fa 65       	call   0x65fa:0x2273
    65e2:	89 c7                	mov    di,ax
    65e4:	8e c2                	mov    es,dx
    65e6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    65e9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    65ec:	8d be fc fd          	lea    di,[bp-0x204]
    65f0:	16                   	push   ss
    65f1:	57                   	push   di
    65f2:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    65f5:	06                   	push   es
    65f6:	57                   	push   di
    65f7:	9a cd 17 0f 66       	call   0x660f:0x17cd
    65fc:	8d be fc fe          	lea    di,[bp-0x104]
    6600:	16                   	push   ss
    6601:	57                   	push   di
    6602:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6605:	06                   	push   es
    6606:	57                   	push   di
    6607:	9a 53 1d 70 66       	call   0x6670:0x1d53
    660c:	9a 4c 18 1c 66       	call   0x661c:0x184c
    6611:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6614:	06                   	push   es
    6615:	57                   	push   di
    6616:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6619:	9a e7 17 2f 66       	call   0x662f:0x17e7
    661e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6621:	ff 76 08             	push   WORD PTR [bp+0x8]
    6624:	bf ad 0d             	mov    di,0xdad
    6627:	b8 3f 66             	mov    ax,0x663f
    662a:	50                   	push   ax
    662b:	57                   	push   di
    662c:	9a 55 22 46 66       	call   0x6646:0x2255
    6631:	08 c0                	or     al,al
    6633:	74 4f                	je     0x6684
    6635:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6638:	ff 76 08             	push   WORD PTR [bp+0x8]
    663b:	bf ad 0d             	mov    di,0xdad
    663e:	b8 80 7a             	mov    ax,0x7a80
    6641:	50                   	push   ax
    6642:	57                   	push   di
    6643:	9a 73 22 60 66       	call   0x6660:0x2273
    6648:	89 c7                	mov    di,ax
    664a:	8e c2                	mov    es,dx
    664c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    664f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6652:	8d be fc fd          	lea    di,[bp-0x204]
    6656:	16                   	push   ss
    6657:	57                   	push   di
    6658:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    665b:	06                   	push   es
    665c:	57                   	push   di
    665d:	9a cd 17 75 66       	call   0x6675:0x17cd
    6662:	8d be fc fe          	lea    di,[bp-0x104]
    6666:	16                   	push   ss
    6667:	57                   	push   di
    6668:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    666b:	06                   	push   es
    666c:	57                   	push   di
    666d:	9a 53 1d 68 67       	call   0x6768:0x1d53
    6672:	9a 4c 18 82 66       	call   0x6682:0x184c
    6677:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    667a:	06                   	push   es
    667b:	57                   	push   di
    667c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    667f:	9a e7 17 95 66       	call   0x6695:0x17e7
    6684:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6687:	ff 76 08             	push   WORD PTR [bp+0x8]
    668a:	bf 22 00             	mov    di,0x22
    668d:	b8 a5 66             	mov    ax,0x66a5
    6690:	50                   	push   ax
    6691:	57                   	push   di
    6692:	9a 55 22 ac 66       	call   0x66ac:0x2255
    6697:	08 c0                	or     al,al
    6699:	74 7b                	je     0x6716
    669b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    669e:	ff 76 08             	push   WORD PTR [bp+0x8]
    66a1:	bf 22 00             	mov    di,0x22
    66a4:	b8 dc 66             	mov    ax,0x66dc
    66a7:	50                   	push   ax
    66a8:	57                   	push   di
    66a9:	9a 73 22 c6 66       	call   0x66c6:0x2273
    66ae:	89 c7                	mov    di,ax
    66b0:	8e c2                	mov    es,dx
    66b2:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    66b5:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    66b8:	8d be fc fc          	lea    di,[bp-0x304]
    66bc:	16                   	push   ss
    66bd:	57                   	push   di
    66be:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    66c1:	06                   	push   es
    66c2:	57                   	push   di
    66c3:	9a cd 17 07 67       	call   0x6707:0x17cd
    66c8:	8d be fc fd          	lea    di,[bp-0x204]
    66cc:	16                   	push   ss
    66cd:	57                   	push   di
    66ce:	8d be fc fe          	lea    di,[bp-0x104]
    66d2:	16                   	push   ss
    66d3:	57                   	push   di
    66d4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    66d7:	06                   	push   es
    66d8:	57                   	push   di
    66d9:	9a 9f 1a e6 66       	call   0x66e6:0x1a9f
    66de:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    66e1:	06                   	push   es
    66e2:	57                   	push   di
    66e3:	9a 5f 1a 20 67       	call   0x6720:0x1a5f
    66e8:	89 c7                	mov    di,ax
    66ea:	8e c2                	mov    es,dx
    66ec:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    66f0:	06                   	push   es
    66f1:	57                   	push   di
    66f2:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    66f7:	89 c7                	mov    di,ax
    66f9:	8e c2                	mov    es,dx
    66fb:	06                   	push   es
    66fc:	57                   	push   di
    66fd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6700:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    6704:	9a 4c 18 14 67       	call   0x6714:0x184c
    6709:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    670c:	06                   	push   es
    670d:	57                   	push   di
    670e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6711:	9a e7 17 27 67       	call   0x6727:0x17e7
    6716:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6719:	ff 76 08             	push   WORD PTR [bp+0x8]
    671c:	bf a2 0b             	mov    di,0xba2
    671f:	b8 37 67             	mov    ax,0x6737
    6722:	50                   	push   ax
    6723:	57                   	push   di
    6724:	9a 55 22 3e 67       	call   0x673e:0x2255
    6729:	08 c0                	or     al,al
    672b:	74 4f                	je     0x677c
    672d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6730:	ff 76 08             	push   WORD PTR [bp+0x8]
    6733:	bf a2 0b             	mov    di,0xba2
    6736:	b8 b8 68             	mov    ax,0x68b8
    6739:	50                   	push   ax
    673a:	57                   	push   di
    673b:	9a 73 22 58 67       	call   0x6758:0x2273
    6740:	89 c7                	mov    di,ax
    6742:	8e c2                	mov    es,dx
    6744:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6747:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    674a:	8d be fc fd          	lea    di,[bp-0x204]
    674e:	16                   	push   ss
    674f:	57                   	push   di
    6750:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6753:	06                   	push   es
    6754:	57                   	push   di
    6755:	9a cd 17 6d 67       	call   0x676d:0x17cd
    675a:	8d be fc fe          	lea    di,[bp-0x104]
    675e:	16                   	push   ss
    675f:	57                   	push   di
    6760:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6763:	06                   	push   es
    6764:	57                   	push   di
    6765:	9a 53 1d ce 67       	call   0x67ce:0x1d53
    676a:	9a 4c 18 7a 67       	call   0x677a:0x184c
    676f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6772:	06                   	push   es
    6773:	57                   	push   di
    6774:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6777:	9a e7 17 8d 67       	call   0x678d:0x17e7
    677c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    677f:	ff 76 08             	push   WORD PTR [bp+0x8]
    6782:	bf 90 0b             	mov    di,0xb90
    6785:	b8 9d 67             	mov    ax,0x679d
    6788:	50                   	push   ax
    6789:	57                   	push   di
    678a:	9a 55 22 a4 67       	call   0x67a4:0x2255
    678f:	08 c0                	or     al,al
    6791:	74 4f                	je     0x67e2
    6793:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6796:	ff 76 08             	push   WORD PTR [bp+0x8]
    6799:	bf 90 0b             	mov    di,0xb90
    679c:	b8 ec 67             	mov    ax,0x67ec
    679f:	50                   	push   ax
    67a0:	57                   	push   di
    67a1:	9a 73 22 be 67       	call   0x67be:0x2273
    67a6:	89 c7                	mov    di,ax
    67a8:	8e c2                	mov    es,dx
    67aa:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    67ad:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    67b0:	8d be fc fd          	lea    di,[bp-0x204]
    67b4:	16                   	push   ss
    67b5:	57                   	push   di
    67b6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    67b9:	06                   	push   es
    67ba:	57                   	push   di
    67bb:	9a cd 17 d3 67       	call   0x67d3:0x17cd
    67c0:	8d be fc fe          	lea    di,[bp-0x104]
    67c4:	16                   	push   ss
    67c5:	57                   	push   di
    67c6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    67c9:	06                   	push   es
    67ca:	57                   	push   di
    67cb:	9a 53 1d 34 68       	call   0x6834:0x1d53
    67d0:	9a 4c 18 e0 67       	call   0x67e0:0x184c
    67d5:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    67d8:	06                   	push   es
    67d9:	57                   	push   di
    67da:	ff 76 0c             	push   WORD PTR [bp+0xc]
    67dd:	9a e7 17 f3 67       	call   0x67f3:0x17e7
    67e2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    67e5:	ff 76 08             	push   WORD PTR [bp+0x8]
    67e8:	bf 17 06             	mov    di,0x617
    67eb:	b8 03 68             	mov    ax,0x6803
    67ee:	50                   	push   ax
    67ef:	57                   	push   di
    67f0:	9a 55 22 0a 68       	call   0x680a:0x2255
    67f5:	08 c0                	or     al,al
    67f7:	74 4f                	je     0x6848
    67f9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    67fc:	ff 76 08             	push   WORD PTR [bp+0x8]
    67ff:	bf 17 06             	mov    di,0x617
    6802:	b8 52 68             	mov    ax,0x6852
    6805:	50                   	push   ax
    6806:	57                   	push   di
    6807:	9a 73 22 24 68       	call   0x6824:0x2273
    680c:	89 c7                	mov    di,ax
    680e:	8e c2                	mov    es,dx
    6810:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6813:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6816:	8d be fc fd          	lea    di,[bp-0x204]
    681a:	16                   	push   ss
    681b:	57                   	push   di
    681c:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    681f:	06                   	push   es
    6820:	57                   	push   di
    6821:	9a cd 17 39 68       	call   0x6839:0x17cd
    6826:	8d be fc fe          	lea    di,[bp-0x104]
    682a:	16                   	push   ss
    682b:	57                   	push   di
    682c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    682f:	06                   	push   es
    6830:	57                   	push   di
    6831:	9a 53 1d 9a 68       	call   0x689a:0x1d53
    6836:	9a 4c 18 46 68       	call   0x6846:0x184c
    683b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    683e:	06                   	push   es
    683f:	57                   	push   di
    6840:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6843:	9a e7 17 59 68       	call   0x6859:0x17e7
    6848:	ff 76 0a             	push   WORD PTR [bp+0xa]
    684b:	ff 76 08             	push   WORD PTR [bp+0x8]
    684e:	bf 14 1b             	mov    di,0x1b14
    6851:	b8 69 68             	mov    ax,0x6869
    6854:	50                   	push   ax
    6855:	57                   	push   di
    6856:	9a 55 22 70 68       	call   0x6870:0x2255
    685b:	08 c0                	or     al,al
    685d:	74 4f                	je     0x68ae
    685f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6862:	ff 76 08             	push   WORD PTR [bp+0x8]
    6865:	bf 14 1b             	mov    di,0x1b14
    6868:	b8 e1 68             	mov    ax,0x68e1
    686b:	50                   	push   ax
    686c:	57                   	push   di
    686d:	9a 73 22 8a 68       	call   0x688a:0x2273
    6872:	89 c7                	mov    di,ax
    6874:	8e c2                	mov    es,dx
    6876:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6879:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    687c:	8d be fc fd          	lea    di,[bp-0x204]
    6880:	16                   	push   ss
    6881:	57                   	push   di
    6882:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6885:	06                   	push   es
    6886:	57                   	push   di
    6887:	9a cd 17 9f 68       	call   0x689f:0x17cd
    688c:	8d be fc fe          	lea    di,[bp-0x104]
    6890:	16                   	push   ss
    6891:	57                   	push   di
    6892:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6895:	06                   	push   es
    6896:	57                   	push   di
    6897:	9a 53 1d 09 6a       	call   0x6a09:0x1d53
    689c:	9a 4c 18 ac 68       	call   0x68ac:0x184c
    68a1:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    68a4:	06                   	push   es
    68a5:	57                   	push   di
    68a6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    68a9:	9a e7 17 bf 68       	call   0x68bf:0x17e7
    68ae:	ff 76 0a             	push   WORD PTR [bp+0xa]
    68b1:	ff 76 08             	push   WORD PTR [bp+0x8]
    68b4:	bf 26 06             	mov    di,0x626
    68b7:	b8 cf 68             	mov    ax,0x68cf
    68ba:	50                   	push   ax
    68bb:	57                   	push   di
    68bc:	9a 55 22 d6 68       	call   0x68d6:0x2255
    68c1:	08 c0                	or     al,al
    68c3:	74 72                	je     0x6937
    68c5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    68c8:	ff 76 08             	push   WORD PTR [bp+0x8]
    68cb:	bf 26 06             	mov    di,0x626
    68ce:	b8 ff ff             	mov    ax,0xffff
    68d1:	50                   	push   ax
    68d2:	57                   	push   di
    68d3:	9a 73 22 f5 68       	call   0x68f5:0x2273
    68d8:	89 c7                	mov    di,ax
    68da:	8e c2                	mov    es,dx
    68dc:	06                   	push   es
    68dd:	57                   	push   di
    68de:	9a d2 6d da 69       	call   0x69da:0x6dd2
    68e3:	08 c0                	or     al,al
    68e5:	74 29                	je     0x6910
    68e7:	8d be fc fe          	lea    di,[bp-0x104]
    68eb:	16                   	push   ss
    68ec:	57                   	push   di
    68ed:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    68f0:	06                   	push   es
    68f1:	57                   	push   di
    68f2:	9a cd 17 ff 68       	call   0x68ff:0x17cd
    68f7:	bf 64 65             	mov    di,0x6564
    68fa:	0e                   	push   cs
    68fb:	57                   	push   di
    68fc:	9a 4c 18 0c 69       	call   0x690c:0x184c
    6901:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6904:	06                   	push   es
    6905:	57                   	push   di
    6906:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6909:	9a e7 17 1e 69       	call   0x691e:0x17e7
    690e:	eb 27                	jmp    0x6937
    6910:	8d be fc fe          	lea    di,[bp-0x104]
    6914:	16                   	push   ss
    6915:	57                   	push   di
    6916:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6919:	06                   	push   es
    691a:	57                   	push   di
    691b:	9a cd 17 28 69       	call   0x6928:0x17cd
    6920:	bf 68 65             	mov    di,0x6568
    6923:	0e                   	push   cs
    6924:	57                   	push   di
    6925:	9a 4c 18 35 69       	call   0x6935:0x184c
    692a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    692d:	06                   	push   es
    692e:	57                   	push   di
    692f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6932:	9a e7 17 48 69       	call   0x6948:0x17e7
    6937:	ff 76 0a             	push   WORD PTR [bp+0xa]
    693a:	ff 76 08             	push   WORD PTR [bp+0x8]
    693d:	bf eb 03             	mov    di,0x3eb
    6940:	b8 58 69             	mov    ax,0x6958
    6943:	50                   	push   ax
    6944:	57                   	push   di
    6945:	9a 55 22 5f 69       	call   0x695f:0x2255
    694a:	08 c0                	or     al,al
    694c:	74 56                	je     0x69a4
    694e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6951:	ff 76 08             	push   WORD PTR [bp+0x8]
    6954:	bf eb 03             	mov    di,0x3eb
    6957:	b8 89 69             	mov    ax,0x6989
    695a:	50                   	push   ax
    695b:	57                   	push   di
    695c:	9a 73 22 79 69       	call   0x6979:0x2273
    6961:	89 c7                	mov    di,ax
    6963:	8e c2                	mov    es,dx
    6965:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6968:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    696b:	8d be fc fd          	lea    di,[bp-0x204]
    696f:	16                   	push   ss
    6970:	57                   	push   di
    6971:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6974:	06                   	push   es
    6975:	57                   	push   di
    6976:	9a cd 17 95 69       	call   0x6995:0x17cd
    697b:	8d be fc fe          	lea    di,[bp-0x104]
    697f:	16                   	push   ss
    6980:	57                   	push   di
    6981:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6984:	06                   	push   es
    6985:	57                   	push   di
    6986:	9a 33 17 ff ff       	call   0xffff:0x1733
    698b:	52                   	push   dx
    698c:	50                   	push   ax
    698d:	9a a9 08 2e 6a       	call   0x6a2e:0x8a9
    6992:	9a 4c 18 a2 69       	call   0x69a2:0x184c
    6997:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    699a:	06                   	push   es
    699b:	57                   	push   di
    699c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    699f:	9a e7 17 bf 69       	call   0x69bf:0x17e7
    69a4:	c9                   	leave
    69a5:	ca 0c 00             	retf   0xc
    69a8:	01 09                	add    WORD PTR [bx+di],cx
    69aa:	01 20                	add    WORD PTR [bx+si],sp
    69ac:	09 44 e9             	or     WORD PTR [si-0x17],ax
    69af:	63 69 73             	arpl   WORD PTR [bx+di+0x73],bp
    69b2:	69 6f 6e 73 55       	imul   bp,WORD PTR [bx+0x6e],0x5573
    69b7:	89 e5                	mov    bp,sp
    69b9:	b8 04 04             	mov    ax,0x404
    69bc:	9a 44 04 ea 69       	call   0x69ea:0x444
    69c1:	81 ec 04 04          	sub    sp,0x404
    69c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69c8:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
    69cd:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    69d1:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    69d5:	06                   	push   es
    69d6:	57                   	push   di
    69d7:	9a e3 49 96 78       	call   0x7896:0x49e3
    69dc:	8d be fc fd          	lea    di,[bp-0x204]
    69e0:	16                   	push   ss
    69e1:	57                   	push   di
    69e2:	bf fa 1d             	mov    di,0x1dfa
    69e5:	1e                   	push   ds
    69e6:	57                   	push   di
    69e7:	9a cd 17 f4 69       	call   0x69f4:0x17cd
    69ec:	bf a8 69             	mov    di,0x69a8
    69ef:	0e                   	push   cs
    69f0:	57                   	push   di
    69f1:	9a 4c 18 0e 6a       	call   0x6a0e:0x184c
    69f6:	8d be fc fc          	lea    di,[bp-0x304]
    69fa:	16                   	push   ss
    69fb:	57                   	push   di
    69fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69ff:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    6a04:	06                   	push   es
    6a05:	57                   	push   di
    6a06:	9a 53 1d 6e 6a       	call   0x6a6e:0x1d53
    6a0b:	9a 4c 18 18 6a       	call   0x6a18:0x184c
    6a10:	bf aa 69             	mov    di,0x69aa
    6a13:	0e                   	push   cs
    6a14:	57                   	push   di
    6a15:	9a 4c 18 33 6a       	call   0x6a33:0x184c
    6a1a:	8d be fc fb          	lea    di,[bp-0x404]
    6a1e:	16                   	push   ss
    6a1f:	57                   	push   di
    6a20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a23:	26 8b 85 0c 04       	mov    ax,WORD PTR es:[di+0x40c]
    6a28:	99                   	cwd
    6a29:	52                   	push   dx
    6a2a:	50                   	push   ax
    6a2b:	9a a9 08 8e 6a       	call   0x6a8e:0x8a9
    6a30:	9a 4c 18 41 6a       	call   0x6a41:0x184c
    6a35:	8d be 00 ff          	lea    di,[bp-0x100]
    6a39:	16                   	push   ss
    6a3a:	57                   	push   di
    6a3b:	68 ff 00             	push   0xff
    6a3e:	9a e7 17 78 6a       	call   0x6a78:0x17e7
    6a43:	8d be 00 ff          	lea    di,[bp-0x100]
    6a47:	16                   	push   ss
    6a48:	57                   	push   di
    6a49:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6a4d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6a52:	06                   	push   es
    6a53:	57                   	push   di
    6a54:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a57:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6a5b:	8d be fc fd          	lea    di,[bp-0x204]
    6a5f:	16                   	push   ss
    6a60:	57                   	push   di
    6a61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a64:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    6a69:	06                   	push   es
    6a6a:	57                   	push   di
    6a6b:	9a 53 1d fc 78       	call   0x78fc:0x1d53
    6a70:	bf aa 69             	mov    di,0x69aa
    6a73:	0e                   	push   cs
    6a74:	57                   	push   di
    6a75:	9a 4c 18 93 6a       	call   0x6a93:0x184c
    6a7a:	8d be fc fc          	lea    di,[bp-0x304]
    6a7e:	16                   	push   ss
    6a7f:	57                   	push   di
    6a80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a83:	26 8b 85 0e 04       	mov    ax,WORD PTR es:[di+0x40e]
    6a88:	99                   	cwd
    6a89:	52                   	push   dx
    6a8a:	50                   	push   ax
    6a8b:	9a a9 08 ff ff       	call   0xffff:0x8a9
    6a90:	9a 4c 18 9d 6a       	call   0x6a9d:0x184c
    6a95:	bf a8 69             	mov    di,0x69a8
    6a98:	0e                   	push   cs
    6a99:	57                   	push   di
    6a9a:	9a 4c 18 a7 6a       	call   0x6aa7:0x184c
    6a9f:	bf ac 69             	mov    di,0x69ac
    6aa2:	0e                   	push   cs
    6aa3:	57                   	push   di
    6aa4:	9a 4c 18 b5 6a       	call   0x6ab5:0x184c
    6aa9:	8d be 00 ff          	lea    di,[bp-0x100]
    6aad:	16                   	push   ss
    6aae:	57                   	push   di
    6aaf:	68 ff 00             	push   0xff
    6ab2:	9a e7 17 bb 78       	call   0x78bb:0x17e7
    6ab7:	8d be 00 ff          	lea    di,[bp-0x100]
    6abb:	16                   	push   ss
    6abc:	57                   	push   di
    6abd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6ac1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6ac6:	06                   	push   es
    6ac7:	57                   	push   di
    6ac8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6acb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6acf:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6ad4:	8d be 00 ff          	lea    di,[bp-0x100]
    6ad8:	16                   	push   ss
    6ad9:	57                   	push   di
    6ada:	68 ff 00             	push   0xff
    6add:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ae0:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    6ae5:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    6aea:	55                   	push   bp
    6aeb:	9a 6c 65 2e 6b       	call   0x6b2e:0x656c
    6af0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6af5:	76 18                	jbe    0x6b0f
    6af7:	8d be 00 ff          	lea    di,[bp-0x100]
    6afb:	16                   	push   ss
    6afc:	57                   	push   di
    6afd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6b01:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6b06:	06                   	push   es
    6b07:	57                   	push   di
    6b08:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b0b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6b0f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6b14:	8d be 00 ff          	lea    di,[bp-0x100]
    6b18:	16                   	push   ss
    6b19:	57                   	push   di
    6b1a:	68 ff 00             	push   0xff
    6b1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b20:	26 ff b5 e2 02       	push   WORD PTR es:[di+0x2e2]
    6b25:	26 ff b5 e0 02       	push   WORD PTR es:[di+0x2e0]
    6b2a:	55                   	push   bp
    6b2b:	9a 6c 65 4a 6b       	call   0x6b4a:0x656c
    6b30:	8d be 00 ff          	lea    di,[bp-0x100]
    6b34:	16                   	push   ss
    6b35:	57                   	push   di
    6b36:	68 ff 00             	push   0xff
    6b39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b3c:	26 ff b5 e6 02       	push   WORD PTR es:[di+0x2e6]
    6b41:	26 ff b5 e4 02       	push   WORD PTR es:[di+0x2e4]
    6b46:	55                   	push   bp
    6b47:	9a 6c 65 8a 6b       	call   0x6b8a:0x656c
    6b4c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6b51:	76 18                	jbe    0x6b6b
    6b53:	8d be 00 ff          	lea    di,[bp-0x100]
    6b57:	16                   	push   ss
    6b58:	57                   	push   di
    6b59:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6b5d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6b62:	06                   	push   es
    6b63:	57                   	push   di
    6b64:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b67:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6b6b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6b70:	8d be 00 ff          	lea    di,[bp-0x100]
    6b74:	16                   	push   ss
    6b75:	57                   	push   di
    6b76:	68 ff 00             	push   0xff
    6b79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b7c:	26 ff b5 ea 02       	push   WORD PTR es:[di+0x2ea]
    6b81:	26 ff b5 e8 02       	push   WORD PTR es:[di+0x2e8]
    6b86:	55                   	push   bp
    6b87:	9a 6c 65 a6 6b       	call   0x6ba6:0x656c
    6b8c:	8d be 00 ff          	lea    di,[bp-0x100]
    6b90:	16                   	push   ss
    6b91:	57                   	push   di
    6b92:	68 ff 00             	push   0xff
    6b95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b98:	26 ff b5 ee 02       	push   WORD PTR es:[di+0x2ee]
    6b9d:	26 ff b5 ec 02       	push   WORD PTR es:[di+0x2ec]
    6ba2:	55                   	push   bp
    6ba3:	9a 6c 65 e6 6b       	call   0x6be6:0x656c
    6ba8:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6bad:	76 18                	jbe    0x6bc7
    6baf:	8d be 00 ff          	lea    di,[bp-0x100]
    6bb3:	16                   	push   ss
    6bb4:	57                   	push   di
    6bb5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6bb9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6bbe:	06                   	push   es
    6bbf:	57                   	push   di
    6bc0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6bc3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6bc7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6bcc:	8d be 00 ff          	lea    di,[bp-0x100]
    6bd0:	16                   	push   ss
    6bd1:	57                   	push   di
    6bd2:	68 ff 00             	push   0xff
    6bd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bd8:	26 ff b5 f2 02       	push   WORD PTR es:[di+0x2f2]
    6bdd:	26 ff b5 f0 02       	push   WORD PTR es:[di+0x2f0]
    6be2:	55                   	push   bp
    6be3:	9a 6c 65 02 6c       	call   0x6c02:0x656c
    6be8:	8d be 00 ff          	lea    di,[bp-0x100]
    6bec:	16                   	push   ss
    6bed:	57                   	push   di
    6bee:	68 ff 00             	push   0xff
    6bf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bf4:	26 ff b5 f6 02       	push   WORD PTR es:[di+0x2f6]
    6bf9:	26 ff b5 f4 02       	push   WORD PTR es:[di+0x2f4]
    6bfe:	55                   	push   bp
    6bff:	9a 6c 65 42 6c       	call   0x6c42:0x656c
    6c04:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6c09:	76 18                	jbe    0x6c23
    6c0b:	8d be 00 ff          	lea    di,[bp-0x100]
    6c0f:	16                   	push   ss
    6c10:	57                   	push   di
    6c11:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6c15:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6c1a:	06                   	push   es
    6c1b:	57                   	push   di
    6c1c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c1f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6c23:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6c28:	8d be 00 ff          	lea    di,[bp-0x100]
    6c2c:	16                   	push   ss
    6c2d:	57                   	push   di
    6c2e:	68 ff 00             	push   0xff
    6c31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c34:	26 ff b5 fa 02       	push   WORD PTR es:[di+0x2fa]
    6c39:	26 ff b5 f8 02       	push   WORD PTR es:[di+0x2f8]
    6c3e:	55                   	push   bp
    6c3f:	9a 6c 65 5e 6c       	call   0x6c5e:0x656c
    6c44:	8d be 00 ff          	lea    di,[bp-0x100]
    6c48:	16                   	push   ss
    6c49:	57                   	push   di
    6c4a:	68 ff 00             	push   0xff
    6c4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c50:	26 ff b5 fe 02       	push   WORD PTR es:[di+0x2fe]
    6c55:	26 ff b5 fc 02       	push   WORD PTR es:[di+0x2fc]
    6c5a:	55                   	push   bp
    6c5b:	9a 6c 65 9e 6c       	call   0x6c9e:0x656c
    6c60:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6c65:	76 18                	jbe    0x6c7f
    6c67:	8d be 00 ff          	lea    di,[bp-0x100]
    6c6b:	16                   	push   ss
    6c6c:	57                   	push   di
    6c6d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6c71:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6c76:	06                   	push   es
    6c77:	57                   	push   di
    6c78:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c7b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6c7f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6c84:	8d be 00 ff          	lea    di,[bp-0x100]
    6c88:	16                   	push   ss
    6c89:	57                   	push   di
    6c8a:	68 ff 00             	push   0xff
    6c8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c90:	26 ff b5 02 03       	push   WORD PTR es:[di+0x302]
    6c95:	26 ff b5 00 03       	push   WORD PTR es:[di+0x300]
    6c9a:	55                   	push   bp
    6c9b:	9a 6c 65 ba 6c       	call   0x6cba:0x656c
    6ca0:	8d be 00 ff          	lea    di,[bp-0x100]
    6ca4:	16                   	push   ss
    6ca5:	57                   	push   di
    6ca6:	68 ff 00             	push   0xff
    6ca9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cac:	26 ff b5 06 03       	push   WORD PTR es:[di+0x306]
    6cb1:	26 ff b5 04 03       	push   WORD PTR es:[di+0x304]
    6cb6:	55                   	push   bp
    6cb7:	9a 6c 65 fa 6c       	call   0x6cfa:0x656c
    6cbc:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6cc1:	76 18                	jbe    0x6cdb
    6cc3:	8d be 00 ff          	lea    di,[bp-0x100]
    6cc7:	16                   	push   ss
    6cc8:	57                   	push   di
    6cc9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6ccd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6cd2:	06                   	push   es
    6cd3:	57                   	push   di
    6cd4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6cd7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6cdb:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6ce0:	8d be 00 ff          	lea    di,[bp-0x100]
    6ce4:	16                   	push   ss
    6ce5:	57                   	push   di
    6ce6:	68 ff 00             	push   0xff
    6ce9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cec:	26 ff b5 9a 01       	push   WORD PTR es:[di+0x19a]
    6cf1:	26 ff b5 98 01       	push   WORD PTR es:[di+0x198]
    6cf6:	55                   	push   bp
    6cf7:	9a 6c 65 3a 6d       	call   0x6d3a:0x656c
    6cfc:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6d01:	76 18                	jbe    0x6d1b
    6d03:	8d be 00 ff          	lea    di,[bp-0x100]
    6d07:	16                   	push   ss
    6d08:	57                   	push   di
    6d09:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6d0d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6d12:	06                   	push   es
    6d13:	57                   	push   di
    6d14:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d17:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6d1b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6d20:	8d be 00 ff          	lea    di,[bp-0x100]
    6d24:	16                   	push   ss
    6d25:	57                   	push   di
    6d26:	68 ff 00             	push   0xff
    6d29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d2c:	26 ff b5 0a 03       	push   WORD PTR es:[di+0x30a]
    6d31:	26 ff b5 08 03       	push   WORD PTR es:[di+0x308]
    6d36:	55                   	push   bp
    6d37:	9a 6c 65 56 6d       	call   0x6d56:0x656c
    6d3c:	8d be 00 ff          	lea    di,[bp-0x100]
    6d40:	16                   	push   ss
    6d41:	57                   	push   di
    6d42:	68 ff 00             	push   0xff
    6d45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d48:	26 ff b5 0e 03       	push   WORD PTR es:[di+0x30e]
    6d4d:	26 ff b5 0c 03       	push   WORD PTR es:[di+0x30c]
    6d52:	55                   	push   bp
    6d53:	9a 6c 65 96 6d       	call   0x6d96:0x656c
    6d58:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6d5d:	76 18                	jbe    0x6d77
    6d5f:	8d be 00 ff          	lea    di,[bp-0x100]
    6d63:	16                   	push   ss
    6d64:	57                   	push   di
    6d65:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6d69:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6d6e:	06                   	push   es
    6d6f:	57                   	push   di
    6d70:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d73:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6d77:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6d7c:	8d be 00 ff          	lea    di,[bp-0x100]
    6d80:	16                   	push   ss
    6d81:	57                   	push   di
    6d82:	68 ff 00             	push   0xff
    6d85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d88:	26 ff b5 12 03       	push   WORD PTR es:[di+0x312]
    6d8d:	26 ff b5 10 03       	push   WORD PTR es:[di+0x310]
    6d92:	55                   	push   bp
    6d93:	9a 6c 65 b2 6d       	call   0x6db2:0x656c
    6d98:	8d be 00 ff          	lea    di,[bp-0x100]
    6d9c:	16                   	push   ss
    6d9d:	57                   	push   di
    6d9e:	68 ff 00             	push   0xff
    6da1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6da4:	26 ff b5 16 03       	push   WORD PTR es:[di+0x316]
    6da9:	26 ff b5 14 03       	push   WORD PTR es:[di+0x314]
    6dae:	55                   	push   bp
    6daf:	9a 6c 65 f2 6d       	call   0x6df2:0x656c
    6db4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6db9:	76 18                	jbe    0x6dd3
    6dbb:	8d be 00 ff          	lea    di,[bp-0x100]
    6dbf:	16                   	push   ss
    6dc0:	57                   	push   di
    6dc1:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6dc5:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6dca:	06                   	push   es
    6dcb:	57                   	push   di
    6dcc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6dcf:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6dd3:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6dd8:	8d be 00 ff          	lea    di,[bp-0x100]
    6ddc:	16                   	push   ss
    6ddd:	57                   	push   di
    6dde:	68 ff 00             	push   0xff
    6de1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6de4:	26 ff b5 1a 03       	push   WORD PTR es:[di+0x31a]
    6de9:	26 ff b5 18 03       	push   WORD PTR es:[di+0x318]
    6dee:	55                   	push   bp
    6def:	9a 6c 65 0e 6e       	call   0x6e0e:0x656c
    6df4:	8d be 00 ff          	lea    di,[bp-0x100]
    6df8:	16                   	push   ss
    6df9:	57                   	push   di
    6dfa:	68 ff 00             	push   0xff
    6dfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e00:	26 ff b5 02 04       	push   WORD PTR es:[di+0x402]
    6e05:	26 ff b5 00 04       	push   WORD PTR es:[di+0x400]
    6e0a:	55                   	push   bp
    6e0b:	9a 6c 65 4e 6e       	call   0x6e4e:0x656c
    6e10:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6e15:	76 18                	jbe    0x6e2f
    6e17:	8d be 00 ff          	lea    di,[bp-0x100]
    6e1b:	16                   	push   ss
    6e1c:	57                   	push   di
    6e1d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6e21:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6e26:	06                   	push   es
    6e27:	57                   	push   di
    6e28:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6e2b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6e2f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6e34:	8d be 00 ff          	lea    di,[bp-0x100]
    6e38:	16                   	push   ss
    6e39:	57                   	push   di
    6e3a:	68 ff 00             	push   0xff
    6e3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e40:	26 ff b5 a2 01       	push   WORD PTR es:[di+0x1a2]
    6e45:	26 ff b5 a0 01       	push   WORD PTR es:[di+0x1a0]
    6e4a:	55                   	push   bp
    6e4b:	9a 6c 65 6a 6e       	call   0x6e6a:0x656c
    6e50:	8d be 00 ff          	lea    di,[bp-0x100]
    6e54:	16                   	push   ss
    6e55:	57                   	push   di
    6e56:	68 ff 00             	push   0xff
    6e59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e5c:	26 ff b5 22 02       	push   WORD PTR es:[di+0x222]
    6e61:	26 ff b5 20 02       	push   WORD PTR es:[di+0x220]
    6e66:	55                   	push   bp
    6e67:	9a 6c 65 86 6e       	call   0x6e86:0x656c
    6e6c:	8d be 00 ff          	lea    di,[bp-0x100]
    6e70:	16                   	push   ss
    6e71:	57                   	push   di
    6e72:	68 ff 00             	push   0xff
    6e75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e78:	26 ff b5 3a 02       	push   WORD PTR es:[di+0x23a]
    6e7d:	26 ff b5 38 02       	push   WORD PTR es:[di+0x238]
    6e82:	55                   	push   bp
    6e83:	9a 6c 65 c6 6e       	call   0x6ec6:0x656c
    6e88:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6e8d:	76 18                	jbe    0x6ea7
    6e8f:	8d be 00 ff          	lea    di,[bp-0x100]
    6e93:	16                   	push   ss
    6e94:	57                   	push   di
    6e95:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6e99:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6e9e:	06                   	push   es
    6e9f:	57                   	push   di
    6ea0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6ea3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6ea7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6eac:	8d be 00 ff          	lea    di,[bp-0x100]
    6eb0:	16                   	push   ss
    6eb1:	57                   	push   di
    6eb2:	68 ff 00             	push   0xff
    6eb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6eb8:	26 ff b5 22 03       	push   WORD PTR es:[di+0x322]
    6ebd:	26 ff b5 20 03       	push   WORD PTR es:[di+0x320]
    6ec2:	55                   	push   bp
    6ec3:	9a 6c 65 e2 6e       	call   0x6ee2:0x656c
    6ec8:	8d be 00 ff          	lea    di,[bp-0x100]
    6ecc:	16                   	push   ss
    6ecd:	57                   	push   di
    6ece:	68 ff 00             	push   0xff
    6ed1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ed4:	26 ff b5 26 02       	push   WORD PTR es:[di+0x226]
    6ed9:	26 ff b5 24 02       	push   WORD PTR es:[di+0x224]
    6ede:	55                   	push   bp
    6edf:	9a 6c 65 fe 6e       	call   0x6efe:0x656c
    6ee4:	8d be 00 ff          	lea    di,[bp-0x100]
    6ee8:	16                   	push   ss
    6ee9:	57                   	push   di
    6eea:	68 ff 00             	push   0xff
    6eed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ef0:	26 ff b5 3e 02       	push   WORD PTR es:[di+0x23e]
    6ef5:	26 ff b5 3c 02       	push   WORD PTR es:[di+0x23c]
    6efa:	55                   	push   bp
    6efb:	9a 6c 65 3e 6f       	call   0x6f3e:0x656c
    6f00:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6f05:	76 18                	jbe    0x6f1f
    6f07:	8d be 00 ff          	lea    di,[bp-0x100]
    6f0b:	16                   	push   ss
    6f0c:	57                   	push   di
    6f0d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6f11:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6f16:	06                   	push   es
    6f17:	57                   	push   di
    6f18:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f1b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6f1f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6f24:	8d be 00 ff          	lea    di,[bp-0x100]
    6f28:	16                   	push   ss
    6f29:	57                   	push   di
    6f2a:	68 ff 00             	push   0xff
    6f2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f30:	26 ff b5 26 03       	push   WORD PTR es:[di+0x326]
    6f35:	26 ff b5 24 03       	push   WORD PTR es:[di+0x324]
    6f3a:	55                   	push   bp
    6f3b:	9a 6c 65 5a 6f       	call   0x6f5a:0x656c
    6f40:	8d be 00 ff          	lea    di,[bp-0x100]
    6f44:	16                   	push   ss
    6f45:	57                   	push   di
    6f46:	68 ff 00             	push   0xff
    6f49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f4c:	26 ff b5 2a 02       	push   WORD PTR es:[di+0x22a]
    6f51:	26 ff b5 28 02       	push   WORD PTR es:[di+0x228]
    6f56:	55                   	push   bp
    6f57:	9a 6c 65 76 6f       	call   0x6f76:0x656c
    6f5c:	8d be 00 ff          	lea    di,[bp-0x100]
    6f60:	16                   	push   ss
    6f61:	57                   	push   di
    6f62:	68 ff 00             	push   0xff
    6f65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f68:	26 ff b5 42 02       	push   WORD PTR es:[di+0x242]
    6f6d:	26 ff b5 40 02       	push   WORD PTR es:[di+0x240]
    6f72:	55                   	push   bp
    6f73:	9a 6c 65 b6 6f       	call   0x6fb6:0x656c
    6f78:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6f7d:	76 18                	jbe    0x6f97
    6f7f:	8d be 00 ff          	lea    di,[bp-0x100]
    6f83:	16                   	push   ss
    6f84:	57                   	push   di
    6f85:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6f89:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6f8e:	06                   	push   es
    6f8f:	57                   	push   di
    6f90:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f93:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6f97:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6f9c:	8d be 00 ff          	lea    di,[bp-0x100]
    6fa0:	16                   	push   ss
    6fa1:	57                   	push   di
    6fa2:	68 ff 00             	push   0xff
    6fa5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fa8:	26 ff b5 2a 03       	push   WORD PTR es:[di+0x32a]
    6fad:	26 ff b5 28 03       	push   WORD PTR es:[di+0x328]
    6fb2:	55                   	push   bp
    6fb3:	9a 6c 65 d2 6f       	call   0x6fd2:0x656c
    6fb8:	8d be 00 ff          	lea    di,[bp-0x100]
    6fbc:	16                   	push   ss
    6fbd:	57                   	push   di
    6fbe:	68 ff 00             	push   0xff
    6fc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fc4:	26 ff b5 2e 02       	push   WORD PTR es:[di+0x22e]
    6fc9:	26 ff b5 2c 02       	push   WORD PTR es:[di+0x22c]
    6fce:	55                   	push   bp
    6fcf:	9a 6c 65 ee 6f       	call   0x6fee:0x656c
    6fd4:	8d be 00 ff          	lea    di,[bp-0x100]
    6fd8:	16                   	push   ss
    6fd9:	57                   	push   di
    6fda:	68 ff 00             	push   0xff
    6fdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fe0:	26 ff b5 46 02       	push   WORD PTR es:[di+0x246]
    6fe5:	26 ff b5 44 02       	push   WORD PTR es:[di+0x244]
    6fea:	55                   	push   bp
    6feb:	9a 6c 65 2e 70       	call   0x702e:0x656c
    6ff0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6ff5:	76 18                	jbe    0x700f
    6ff7:	8d be 00 ff          	lea    di,[bp-0x100]
    6ffb:	16                   	push   ss
    6ffc:	57                   	push   di
    6ffd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7001:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7006:	06                   	push   es
    7007:	57                   	push   di
    7008:	26 c4 3d             	les    di,DWORD PTR es:[di]
    700b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    700f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7014:	8d be 00 ff          	lea    di,[bp-0x100]
    7018:	16                   	push   ss
    7019:	57                   	push   di
    701a:	68 ff 00             	push   0xff
    701d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7020:	26 ff b5 2e 03       	push   WORD PTR es:[di+0x32e]
    7025:	26 ff b5 2c 03       	push   WORD PTR es:[di+0x32c]
    702a:	55                   	push   bp
    702b:	9a 6c 65 4a 70       	call   0x704a:0x656c
    7030:	8d be 00 ff          	lea    di,[bp-0x100]
    7034:	16                   	push   ss
    7035:	57                   	push   di
    7036:	68 ff 00             	push   0xff
    7039:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    703c:	26 ff b5 32 02       	push   WORD PTR es:[di+0x232]
    7041:	26 ff b5 30 02       	push   WORD PTR es:[di+0x230]
    7046:	55                   	push   bp
    7047:	9a 6c 65 66 70       	call   0x7066:0x656c
    704c:	8d be 00 ff          	lea    di,[bp-0x100]
    7050:	16                   	push   ss
    7051:	57                   	push   di
    7052:	68 ff 00             	push   0xff
    7055:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7058:	26 ff b5 4a 02       	push   WORD PTR es:[di+0x24a]
    705d:	26 ff b5 48 02       	push   WORD PTR es:[di+0x248]
    7062:	55                   	push   bp
    7063:	9a 6c 65 a6 70       	call   0x70a6:0x656c
    7068:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    706d:	76 18                	jbe    0x7087
    706f:	8d be 00 ff          	lea    di,[bp-0x100]
    7073:	16                   	push   ss
    7074:	57                   	push   di
    7075:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7079:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    707e:	06                   	push   es
    707f:	57                   	push   di
    7080:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7083:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7087:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    708c:	8d be 00 ff          	lea    di,[bp-0x100]
    7090:	16                   	push   ss
    7091:	57                   	push   di
    7092:	68 ff 00             	push   0xff
    7095:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7098:	26 ff b5 a6 01       	push   WORD PTR es:[di+0x1a6]
    709d:	26 ff b5 a4 01       	push   WORD PTR es:[di+0x1a4]
    70a2:	55                   	push   bp
    70a3:	9a 6c 65 c2 70       	call   0x70c2:0x656c
    70a8:	8d be 00 ff          	lea    di,[bp-0x100]
    70ac:	16                   	push   ss
    70ad:	57                   	push   di
    70ae:	68 ff 00             	push   0xff
    70b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70b4:	26 ff b5 52 02       	push   WORD PTR es:[di+0x252]
    70b9:	26 ff b5 50 02       	push   WORD PTR es:[di+0x250]
    70be:	55                   	push   bp
    70bf:	9a 6c 65 de 70       	call   0x70de:0x656c
    70c4:	8d be 00 ff          	lea    di,[bp-0x100]
    70c8:	16                   	push   ss
    70c9:	57                   	push   di
    70ca:	68 ff 00             	push   0xff
    70cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70d0:	26 ff b5 6a 02       	push   WORD PTR es:[di+0x26a]
    70d5:	26 ff b5 68 02       	push   WORD PTR es:[di+0x268]
    70da:	55                   	push   bp
    70db:	9a 6c 65 1e 71       	call   0x711e:0x656c
    70e0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    70e5:	76 18                	jbe    0x70ff
    70e7:	8d be 00 ff          	lea    di,[bp-0x100]
    70eb:	16                   	push   ss
    70ec:	57                   	push   di
    70ed:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    70f1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    70f6:	06                   	push   es
    70f7:	57                   	push   di
    70f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    70fb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    70ff:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7104:	8d be 00 ff          	lea    di,[bp-0x100]
    7108:	16                   	push   ss
    7109:	57                   	push   di
    710a:	68 ff 00             	push   0xff
    710d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7110:	26 ff b5 32 03       	push   WORD PTR es:[di+0x332]
    7115:	26 ff b5 30 03       	push   WORD PTR es:[di+0x330]
    711a:	55                   	push   bp
    711b:	9a 6c 65 3a 71       	call   0x713a:0x656c
    7120:	8d be 00 ff          	lea    di,[bp-0x100]
    7124:	16                   	push   ss
    7125:	57                   	push   di
    7126:	68 ff 00             	push   0xff
    7129:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    712c:	26 ff b5 56 02       	push   WORD PTR es:[di+0x256]
    7131:	26 ff b5 54 02       	push   WORD PTR es:[di+0x254]
    7136:	55                   	push   bp
    7137:	9a 6c 65 56 71       	call   0x7156:0x656c
    713c:	8d be 00 ff          	lea    di,[bp-0x100]
    7140:	16                   	push   ss
    7141:	57                   	push   di
    7142:	68 ff 00             	push   0xff
    7145:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7148:	26 ff b5 6e 02       	push   WORD PTR es:[di+0x26e]
    714d:	26 ff b5 6c 02       	push   WORD PTR es:[di+0x26c]
    7152:	55                   	push   bp
    7153:	9a 6c 65 96 71       	call   0x7196:0x656c
    7158:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    715d:	76 18                	jbe    0x7177
    715f:	8d be 00 ff          	lea    di,[bp-0x100]
    7163:	16                   	push   ss
    7164:	57                   	push   di
    7165:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7169:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    716e:	06                   	push   es
    716f:	57                   	push   di
    7170:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7173:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7177:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    717c:	8d be 00 ff          	lea    di,[bp-0x100]
    7180:	16                   	push   ss
    7181:	57                   	push   di
    7182:	68 ff 00             	push   0xff
    7185:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7188:	26 ff b5 36 03       	push   WORD PTR es:[di+0x336]
    718d:	26 ff b5 34 03       	push   WORD PTR es:[di+0x334]
    7192:	55                   	push   bp
    7193:	9a 6c 65 b2 71       	call   0x71b2:0x656c
    7198:	8d be 00 ff          	lea    di,[bp-0x100]
    719c:	16                   	push   ss
    719d:	57                   	push   di
    719e:	68 ff 00             	push   0xff
    71a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71a4:	26 ff b5 5a 02       	push   WORD PTR es:[di+0x25a]
    71a9:	26 ff b5 58 02       	push   WORD PTR es:[di+0x258]
    71ae:	55                   	push   bp
    71af:	9a 6c 65 ce 71       	call   0x71ce:0x656c
    71b4:	8d be 00 ff          	lea    di,[bp-0x100]
    71b8:	16                   	push   ss
    71b9:	57                   	push   di
    71ba:	68 ff 00             	push   0xff
    71bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71c0:	26 ff b5 72 02       	push   WORD PTR es:[di+0x272]
    71c5:	26 ff b5 70 02       	push   WORD PTR es:[di+0x270]
    71ca:	55                   	push   bp
    71cb:	9a 6c 65 0e 72       	call   0x720e:0x656c
    71d0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    71d5:	76 18                	jbe    0x71ef
    71d7:	8d be 00 ff          	lea    di,[bp-0x100]
    71db:	16                   	push   ss
    71dc:	57                   	push   di
    71dd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    71e1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    71e6:	06                   	push   es
    71e7:	57                   	push   di
    71e8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    71eb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    71ef:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    71f4:	8d be 00 ff          	lea    di,[bp-0x100]
    71f8:	16                   	push   ss
    71f9:	57                   	push   di
    71fa:	68 ff 00             	push   0xff
    71fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7200:	26 ff b5 3a 03       	push   WORD PTR es:[di+0x33a]
    7205:	26 ff b5 38 03       	push   WORD PTR es:[di+0x338]
    720a:	55                   	push   bp
    720b:	9a 6c 65 2a 72       	call   0x722a:0x656c
    7210:	8d be 00 ff          	lea    di,[bp-0x100]
    7214:	16                   	push   ss
    7215:	57                   	push   di
    7216:	68 ff 00             	push   0xff
    7219:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    721c:	26 ff b5 5e 02       	push   WORD PTR es:[di+0x25e]
    7221:	26 ff b5 5c 02       	push   WORD PTR es:[di+0x25c]
    7226:	55                   	push   bp
    7227:	9a 6c 65 46 72       	call   0x7246:0x656c
    722c:	8d be 00 ff          	lea    di,[bp-0x100]
    7230:	16                   	push   ss
    7231:	57                   	push   di
    7232:	68 ff 00             	push   0xff
    7235:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7238:	26 ff b5 76 02       	push   WORD PTR es:[di+0x276]
    723d:	26 ff b5 74 02       	push   WORD PTR es:[di+0x274]
    7242:	55                   	push   bp
    7243:	9a 6c 65 86 72       	call   0x7286:0x656c
    7248:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    724d:	76 18                	jbe    0x7267
    724f:	8d be 00 ff          	lea    di,[bp-0x100]
    7253:	16                   	push   ss
    7254:	57                   	push   di
    7255:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7259:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    725e:	06                   	push   es
    725f:	57                   	push   di
    7260:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7263:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7267:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    726c:	8d be 00 ff          	lea    di,[bp-0x100]
    7270:	16                   	push   ss
    7271:	57                   	push   di
    7272:	68 ff 00             	push   0xff
    7275:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7278:	26 ff b5 3e 03       	push   WORD PTR es:[di+0x33e]
    727d:	26 ff b5 3c 03       	push   WORD PTR es:[di+0x33c]
    7282:	55                   	push   bp
    7283:	9a 6c 65 a2 72       	call   0x72a2:0x656c
    7288:	8d be 00 ff          	lea    di,[bp-0x100]
    728c:	16                   	push   ss
    728d:	57                   	push   di
    728e:	68 ff 00             	push   0xff
    7291:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7294:	26 ff b5 c6 02       	push   WORD PTR es:[di+0x2c6]
    7299:	26 ff b5 c4 02       	push   WORD PTR es:[di+0x2c4]
    729e:	55                   	push   bp
    729f:	9a 6c 65 be 72       	call   0x72be:0x656c
    72a4:	8d be 00 ff          	lea    di,[bp-0x100]
    72a8:	16                   	push   ss
    72a9:	57                   	push   di
    72aa:	68 ff 00             	push   0xff
    72ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72b0:	26 ff b5 ca 02       	push   WORD PTR es:[di+0x2ca]
    72b5:	26 ff b5 c8 02       	push   WORD PTR es:[di+0x2c8]
    72ba:	55                   	push   bp
    72bb:	9a 6c 65 fe 72       	call   0x72fe:0x656c
    72c0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    72c5:	76 18                	jbe    0x72df
    72c7:	8d be 00 ff          	lea    di,[bp-0x100]
    72cb:	16                   	push   ss
    72cc:	57                   	push   di
    72cd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    72d1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    72d6:	06                   	push   es
    72d7:	57                   	push   di
    72d8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    72db:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    72df:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    72e4:	8d be 00 ff          	lea    di,[bp-0x100]
    72e8:	16                   	push   ss
    72e9:	57                   	push   di
    72ea:	68 ff 00             	push   0xff
    72ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72f0:	26 ff b5 42 03       	push   WORD PTR es:[di+0x342]
    72f5:	26 ff b5 40 03       	push   WORD PTR es:[di+0x340]
    72fa:	55                   	push   bp
    72fb:	9a 6c 65 1a 73       	call   0x731a:0x656c
    7300:	8d be 00 ff          	lea    di,[bp-0x100]
    7304:	16                   	push   ss
    7305:	57                   	push   di
    7306:	68 ff 00             	push   0xff
    7309:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    730c:	26 ff b5 62 02       	push   WORD PTR es:[di+0x262]
    7311:	26 ff b5 60 02       	push   WORD PTR es:[di+0x260]
    7316:	55                   	push   bp
    7317:	9a 6c 65 36 73       	call   0x7336:0x656c
    731c:	8d be 00 ff          	lea    di,[bp-0x100]
    7320:	16                   	push   ss
    7321:	57                   	push   di
    7322:	68 ff 00             	push   0xff
    7325:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7328:	26 ff b5 7a 02       	push   WORD PTR es:[di+0x27a]
    732d:	26 ff b5 78 02       	push   WORD PTR es:[di+0x278]
    7332:	55                   	push   bp
    7333:	9a 6c 65 76 73       	call   0x7376:0x656c
    7338:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    733d:	76 18                	jbe    0x7357
    733f:	8d be 00 ff          	lea    di,[bp-0x100]
    7343:	16                   	push   ss
    7344:	57                   	push   di
    7345:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7349:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    734e:	06                   	push   es
    734f:	57                   	push   di
    7350:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7353:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7357:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    735c:	8d be 00 ff          	lea    di,[bp-0x100]
    7360:	16                   	push   ss
    7361:	57                   	push   di
    7362:	68 ff 00             	push   0xff
    7365:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7368:	26 ff b5 0e 02       	push   WORD PTR es:[di+0x20e]
    736d:	26 ff b5 0c 02       	push   WORD PTR es:[di+0x20c]
    7372:	55                   	push   bp
    7373:	9a 6c 65 b6 73       	call   0x73b6:0x656c
    7378:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    737d:	76 18                	jbe    0x7397
    737f:	8d be 00 ff          	lea    di,[bp-0x100]
    7383:	16                   	push   ss
    7384:	57                   	push   di
    7385:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7389:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    738e:	06                   	push   es
    738f:	57                   	push   di
    7390:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7393:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7397:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    739c:	8d be 00 ff          	lea    di,[bp-0x100]
    73a0:	16                   	push   ss
    73a1:	57                   	push   di
    73a2:	68 ff 00             	push   0xff
    73a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73a8:	26 ff b5 46 03       	push   WORD PTR es:[di+0x346]
    73ad:	26 ff b5 44 03       	push   WORD PTR es:[di+0x344]
    73b2:	55                   	push   bp
    73b3:	9a 6c 65 d2 73       	call   0x73d2:0x656c
    73b8:	8d be 00 ff          	lea    di,[bp-0x100]
    73bc:	16                   	push   ss
    73bd:	57                   	push   di
    73be:	68 ff 00             	push   0xff
    73c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73c4:	26 ff b5 4a 03       	push   WORD PTR es:[di+0x34a]
    73c9:	26 ff b5 48 03       	push   WORD PTR es:[di+0x348]
    73ce:	55                   	push   bp
    73cf:	9a 6c 65 12 74       	call   0x7412:0x656c
    73d4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    73d9:	76 18                	jbe    0x73f3
    73db:	8d be 00 ff          	lea    di,[bp-0x100]
    73df:	16                   	push   ss
    73e0:	57                   	push   di
    73e1:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    73e5:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    73ea:	06                   	push   es
    73eb:	57                   	push   di
    73ec:	26 c4 3d             	les    di,DWORD PTR es:[di]
    73ef:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    73f3:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    73f8:	8d be 00 ff          	lea    di,[bp-0x100]
    73fc:	16                   	push   ss
    73fd:	57                   	push   di
    73fe:	68 ff 00             	push   0xff
    7401:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7404:	26 ff b5 4e 03       	push   WORD PTR es:[di+0x34e]
    7409:	26 ff b5 4c 03       	push   WORD PTR es:[di+0x34c]
    740e:	55                   	push   bp
    740f:	9a 6c 65 2e 74       	call   0x742e:0x656c
    7414:	8d be 00 ff          	lea    di,[bp-0x100]
    7418:	16                   	push   ss
    7419:	57                   	push   di
    741a:	68 ff 00             	push   0xff
    741d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7420:	26 ff b5 52 03       	push   WORD PTR es:[di+0x352]
    7425:	26 ff b5 50 03       	push   WORD PTR es:[di+0x350]
    742a:	55                   	push   bp
    742b:	9a 6c 65 6e 74       	call   0x746e:0x656c
    7430:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7435:	76 18                	jbe    0x744f
    7437:	8d be 00 ff          	lea    di,[bp-0x100]
    743b:	16                   	push   ss
    743c:	57                   	push   di
    743d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7441:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7446:	06                   	push   es
    7447:	57                   	push   di
    7448:	26 c4 3d             	les    di,DWORD PTR es:[di]
    744b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    744f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7454:	8d be 00 ff          	lea    di,[bp-0x100]
    7458:	16                   	push   ss
    7459:	57                   	push   di
    745a:	68 ff 00             	push   0xff
    745d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7460:	26 ff b5 56 03       	push   WORD PTR es:[di+0x356]
    7465:	26 ff b5 54 03       	push   WORD PTR es:[di+0x354]
    746a:	55                   	push   bp
    746b:	9a 6c 65 8a 74       	call   0x748a:0x656c
    7470:	8d be 00 ff          	lea    di,[bp-0x100]
    7474:	16                   	push   ss
    7475:	57                   	push   di
    7476:	68 ff 00             	push   0xff
    7479:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    747c:	26 ff b5 5a 03       	push   WORD PTR es:[di+0x35a]
    7481:	26 ff b5 58 03       	push   WORD PTR es:[di+0x358]
    7486:	55                   	push   bp
    7487:	9a 6c 65 dc 74       	call   0x74dc:0x656c
    748c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7491:	76 18                	jbe    0x74ab
    7493:	8d be 00 ff          	lea    di,[bp-0x100]
    7497:	16                   	push   ss
    7498:	57                   	push   di
    7499:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    749d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    74a2:	06                   	push   es
    74a3:	57                   	push   di
    74a4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    74a7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    74ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74ae:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    74b3:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    74b8:	75 03                	jne    0x74bd
    74ba:	e9 f8 00             	jmp    0x75b5
    74bd:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    74c2:	8d be 00 ff          	lea    di,[bp-0x100]
    74c6:	16                   	push   ss
    74c7:	57                   	push   di
    74c8:	68 ff 00             	push   0xff
    74cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74ce:	26 ff b5 0a 02       	push   WORD PTR es:[di+0x20a]
    74d3:	26 ff b5 08 02       	push   WORD PTR es:[di+0x208]
    74d8:	55                   	push   bp
    74d9:	9a 6c 65 1c 75       	call   0x751c:0x656c
    74de:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    74e3:	76 18                	jbe    0x74fd
    74e5:	8d be 00 ff          	lea    di,[bp-0x100]
    74e9:	16                   	push   ss
    74ea:	57                   	push   di
    74eb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    74ef:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    74f4:	06                   	push   es
    74f5:	57                   	push   di
    74f6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    74f9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    74fd:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7502:	8d be 00 ff          	lea    di,[bp-0x100]
    7506:	16                   	push   ss
    7507:	57                   	push   di
    7508:	68 ff 00             	push   0xff
    750b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    750e:	26 ff b5 5e 03       	push   WORD PTR es:[di+0x35e]
    7513:	26 ff b5 5c 03       	push   WORD PTR es:[di+0x35c]
    7518:	55                   	push   bp
    7519:	9a 6c 65 38 75       	call   0x7538:0x656c
    751e:	8d be 00 ff          	lea    di,[bp-0x100]
    7522:	16                   	push   ss
    7523:	57                   	push   di
    7524:	68 ff 00             	push   0xff
    7527:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    752a:	26 ff b5 62 03       	push   WORD PTR es:[di+0x362]
    752f:	26 ff b5 60 03       	push   WORD PTR es:[di+0x360]
    7534:	55                   	push   bp
    7535:	9a 6c 65 78 75       	call   0x7578:0x656c
    753a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    753f:	76 18                	jbe    0x7559
    7541:	8d be 00 ff          	lea    di,[bp-0x100]
    7545:	16                   	push   ss
    7546:	57                   	push   di
    7547:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    754b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7550:	06                   	push   es
    7551:	57                   	push   di
    7552:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7555:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7559:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    755e:	8d be 00 ff          	lea    di,[bp-0x100]
    7562:	16                   	push   ss
    7563:	57                   	push   di
    7564:	68 ff 00             	push   0xff
    7567:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    756a:	26 ff b5 66 03       	push   WORD PTR es:[di+0x366]
    756f:	26 ff b5 64 03       	push   WORD PTR es:[di+0x364]
    7574:	55                   	push   bp
    7575:	9a 6c 65 94 75       	call   0x7594:0x656c
    757a:	8d be 00 ff          	lea    di,[bp-0x100]
    757e:	16                   	push   ss
    757f:	57                   	push   di
    7580:	68 ff 00             	push   0xff
    7583:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7586:	26 ff b5 6a 03       	push   WORD PTR es:[di+0x36a]
    758b:	26 ff b5 68 03       	push   WORD PTR es:[di+0x368]
    7590:	55                   	push   bp
    7591:	9a 6c 65 d4 75       	call   0x75d4:0x656c
    7596:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    759b:	76 18                	jbe    0x75b5
    759d:	8d be 00 ff          	lea    di,[bp-0x100]
    75a1:	16                   	push   ss
    75a2:	57                   	push   di
    75a3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    75a7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    75ac:	06                   	push   es
    75ad:	57                   	push   di
    75ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    75b1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    75b5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    75ba:	8d be 00 ff          	lea    di,[bp-0x100]
    75be:	16                   	push   ss
    75bf:	57                   	push   di
    75c0:	68 ff 00             	push   0xff
    75c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75c6:	26 ff b5 a6 03       	push   WORD PTR es:[di+0x3a6]
    75cb:	26 ff b5 a4 03       	push   WORD PTR es:[di+0x3a4]
    75d0:	55                   	push   bp
    75d1:	9a 6c 65 f0 75       	call   0x75f0:0x656c
    75d6:	8d be 00 ff          	lea    di,[bp-0x100]
    75da:	16                   	push   ss
    75db:	57                   	push   di
    75dc:	68 ff 00             	push   0xff
    75df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75e2:	26 ff b5 aa 03       	push   WORD PTR es:[di+0x3aa]
    75e7:	26 ff b5 a8 03       	push   WORD PTR es:[di+0x3a8]
    75ec:	55                   	push   bp
    75ed:	9a 6c 65 42 76       	call   0x7642:0x656c
    75f2:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    75f7:	76 18                	jbe    0x7611
    75f9:	8d be 00 ff          	lea    di,[bp-0x100]
    75fd:	16                   	push   ss
    75fe:	57                   	push   di
    75ff:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7603:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7608:	06                   	push   es
    7609:	57                   	push   di
    760a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    760d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7611:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7614:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    7619:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    761e:	75 03                	jne    0x7623
    7620:	e9 f0 00             	jmp    0x7713
    7623:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7628:	8d be 00 ff          	lea    di,[bp-0x100]
    762c:	16                   	push   ss
    762d:	57                   	push   di
    762e:	68 ff 00             	push   0xff
    7631:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7634:	26 ff b5 12 02       	push   WORD PTR es:[di+0x212]
    7639:	26 ff b5 10 02       	push   WORD PTR es:[di+0x210]
    763e:	55                   	push   bp
    763f:	9a 6c 65 5e 76       	call   0x765e:0x656c
    7644:	8d be 00 ff          	lea    di,[bp-0x100]
    7648:	16                   	push   ss
    7649:	57                   	push   di
    764a:	68 ff 00             	push   0xff
    764d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7650:	26 ff b5 82 02       	push   WORD PTR es:[di+0x282]
    7655:	26 ff b5 80 02       	push   WORD PTR es:[di+0x280]
    765a:	55                   	push   bp
    765b:	9a 6c 65 7a 76       	call   0x767a:0x656c
    7660:	8d be 00 ff          	lea    di,[bp-0x100]
    7664:	16                   	push   ss
    7665:	57                   	push   di
    7666:	68 ff 00             	push   0xff
    7669:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    766c:	26 ff b5 92 02       	push   WORD PTR es:[di+0x292]
    7671:	26 ff b5 90 02       	push   WORD PTR es:[di+0x290]
    7676:	55                   	push   bp
    7677:	9a 6c 65 ba 76       	call   0x76ba:0x656c
    767c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7681:	76 18                	jbe    0x769b
    7683:	8d be 00 ff          	lea    di,[bp-0x100]
    7687:	16                   	push   ss
    7688:	57                   	push   di
    7689:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    768d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7692:	06                   	push   es
    7693:	57                   	push   di
    7694:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7697:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    769b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    76a0:	8d be 00 ff          	lea    di,[bp-0x100]
    76a4:	16                   	push   ss
    76a5:	57                   	push   di
    76a6:	68 ff 00             	push   0xff
    76a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76ac:	26 ff b5 ae 03       	push   WORD PTR es:[di+0x3ae]
    76b1:	26 ff b5 ac 03       	push   WORD PTR es:[di+0x3ac]
    76b6:	55                   	push   bp
    76b7:	9a 6c 65 d6 76       	call   0x76d6:0x656c
    76bc:	8d be 00 ff          	lea    di,[bp-0x100]
    76c0:	16                   	push   ss
    76c1:	57                   	push   di
    76c2:	68 ff 00             	push   0xff
    76c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76c8:	26 ff b5 86 02       	push   WORD PTR es:[di+0x286]
    76cd:	26 ff b5 84 02       	push   WORD PTR es:[di+0x284]
    76d2:	55                   	push   bp
    76d3:	9a 6c 65 f2 76       	call   0x76f2:0x656c
    76d8:	8d be 00 ff          	lea    di,[bp-0x100]
    76dc:	16                   	push   ss
    76dd:	57                   	push   di
    76de:	68 ff 00             	push   0xff
    76e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76e4:	26 ff b5 8e 02       	push   WORD PTR es:[di+0x28e]
    76e9:	26 ff b5 8c 02       	push   WORD PTR es:[di+0x28c]
    76ee:	55                   	push   bp
    76ef:	9a 6c 65 44 77       	call   0x7744:0x656c
    76f4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    76f9:	76 18                	jbe    0x7713
    76fb:	8d be 00 ff          	lea    di,[bp-0x100]
    76ff:	16                   	push   ss
    7700:	57                   	push   di
    7701:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7705:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    770a:	06                   	push   es
    770b:	57                   	push   di
    770c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    770f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7713:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7716:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    771b:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    7720:	75 03                	jne    0x7725
    7722:	e9 68 01             	jmp    0x788d
    7725:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    772a:	8d be 00 ff          	lea    di,[bp-0x100]
    772e:	16                   	push   ss
    772f:	57                   	push   di
    7730:	68 ff 00             	push   0xff
    7733:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7736:	26 ff b5 16 02       	push   WORD PTR es:[di+0x216]
    773b:	26 ff b5 14 02       	push   WORD PTR es:[di+0x214]
    7740:	55                   	push   bp
    7741:	9a 6c 65 60 77       	call   0x7760:0x656c
    7746:	8d be 00 ff          	lea    di,[bp-0x100]
    774a:	16                   	push   ss
    774b:	57                   	push   di
    774c:	68 ff 00             	push   0xff
    774f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7752:	26 ff b5 9a 02       	push   WORD PTR es:[di+0x29a]
    7757:	26 ff b5 98 02       	push   WORD PTR es:[di+0x298]
    775c:	55                   	push   bp
    775d:	9a 6c 65 7c 77       	call   0x777c:0x656c
    7762:	8d be 00 ff          	lea    di,[bp-0x100]
    7766:	16                   	push   ss
    7767:	57                   	push   di
    7768:	68 ff 00             	push   0xff
    776b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    776e:	26 ff b5 aa 02       	push   WORD PTR es:[di+0x2aa]
    7773:	26 ff b5 a8 02       	push   WORD PTR es:[di+0x2a8]
    7778:	55                   	push   bp
    7779:	9a 6c 65 bc 77       	call   0x77bc:0x656c
    777e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7783:	76 18                	jbe    0x779d
    7785:	8d be 00 ff          	lea    di,[bp-0x100]
    7789:	16                   	push   ss
    778a:	57                   	push   di
    778b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    778f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7794:	06                   	push   es
    7795:	57                   	push   di
    7796:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7799:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    779d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    77a2:	8d be 00 ff          	lea    di,[bp-0x100]
    77a6:	16                   	push   ss
    77a7:	57                   	push   di
    77a8:	68 ff 00             	push   0xff
    77ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77ae:	26 ff b5 b2 03       	push   WORD PTR es:[di+0x3b2]
    77b3:	26 ff b5 b0 03       	push   WORD PTR es:[di+0x3b0]
    77b8:	55                   	push   bp
    77b9:	9a 6c 65 d8 77       	call   0x77d8:0x656c
    77be:	8d be 00 ff          	lea    di,[bp-0x100]
    77c2:	16                   	push   ss
    77c3:	57                   	push   di
    77c4:	68 ff 00             	push   0xff
    77c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77ca:	26 ff b5 9e 02       	push   WORD PTR es:[di+0x29e]
    77cf:	26 ff b5 9c 02       	push   WORD PTR es:[di+0x29c]
    77d4:	55                   	push   bp
    77d5:	9a 6c 65 f4 77       	call   0x77f4:0x656c
    77da:	8d be 00 ff          	lea    di,[bp-0x100]
    77de:	16                   	push   ss
    77df:	57                   	push   di
    77e0:	68 ff 00             	push   0xff
    77e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77e6:	26 ff b5 ae 02       	push   WORD PTR es:[di+0x2ae]
    77eb:	26 ff b5 ac 02       	push   WORD PTR es:[di+0x2ac]
    77f0:	55                   	push   bp
    77f1:	9a 6c 65 34 78       	call   0x7834:0x656c
    77f6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    77fb:	76 18                	jbe    0x7815
    77fd:	8d be 00 ff          	lea    di,[bp-0x100]
    7801:	16                   	push   ss
    7802:	57                   	push   di
    7803:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7807:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    780c:	06                   	push   es
    780d:	57                   	push   di
    780e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7811:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7815:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    781a:	8d be 00 ff          	lea    di,[bp-0x100]
    781e:	16                   	push   ss
    781f:	57                   	push   di
    7820:	68 ff 00             	push   0xff
    7823:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7826:	26 ff b5 b6 03       	push   WORD PTR es:[di+0x3b6]
    782b:	26 ff b5 b4 03       	push   WORD PTR es:[di+0x3b4]
    7830:	55                   	push   bp
    7831:	9a 6c 65 50 78       	call   0x7850:0x656c
    7836:	8d be 00 ff          	lea    di,[bp-0x100]
    783a:	16                   	push   ss
    783b:	57                   	push   di
    783c:	68 ff 00             	push   0xff
    783f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7842:	26 ff b5 a2 02       	push   WORD PTR es:[di+0x2a2]
    7847:	26 ff b5 a0 02       	push   WORD PTR es:[di+0x2a0]
    784c:	55                   	push   bp
    784d:	9a 6c 65 6c 78       	call   0x786c:0x656c
    7852:	8d be 00 ff          	lea    di,[bp-0x100]
    7856:	16                   	push   ss
    7857:	57                   	push   di
    7858:	68 ff 00             	push   0xff
    785b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    785e:	26 ff b5 b2 02       	push   WORD PTR es:[di+0x2b2]
    7863:	26 ff b5 b0 02       	push   WORD PTR es:[di+0x2b0]
    7868:	55                   	push   bp
    7869:	9a 6c 65 ff ff       	call   0xffff:0x656c
    786e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7873:	76 18                	jbe    0x788d
    7875:	8d be 00 ff          	lea    di,[bp-0x100]
    7879:	16                   	push   ss
    787a:	57                   	push   di
    787b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    787f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7884:	06                   	push   es
    7885:	57                   	push   di
    7886:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7889:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    788d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7891:	06                   	push   es
    7892:	57                   	push   di
    7893:	9a 3f 4a a1 78       	call   0x78a1:0x4a3f
    7898:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    789c:	06                   	push   es
    789d:	57                   	push   di
    789e:	9a ff 49 ac 78       	call   0x78ac:0x49ff
    78a3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    78a7:	06                   	push   es
    78a8:	57                   	push   di
    78a9:	9a e3 49 ff ff       	call   0xffff:0x49e3
    78ae:	c9                   	leave
    78af:	ca 08 00             	retf   0x8
    78b2:	55                   	push   bp
    78b3:	89 e5                	mov    bp,sp
    78b5:	b8 08 00             	mov    ax,0x8
    78b8:	9a 44 04 d1 78       	call   0x78d1:0x444
    78bd:	83 ec 08             	sub    sp,0x8
    78c0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    78c3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    78c6:	bf ac 04             	mov    di,0x4ac
    78c9:	b8 ff ff             	mov    ax,0xffff
    78cc:	50                   	push   ax
    78cd:	57                   	push   di
    78ce:	9a 73 22 34 79       	call   0x7934:0x2273
    78d3:	89 c7                	mov    di,ax
    78d5:	8e c2                	mov    es,dx
    78d7:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    78db:	99                   	cwd
    78dc:	b9 02 00             	mov    cx,0x2
    78df:	f7 f9                	idiv   cx
    78e1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    78e4:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    78e8:	99                   	cwd
    78e9:	b9 02 00             	mov    cx,0x2
    78ec:	f7 f9                	idiv   cx
    78ee:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    78f1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    78f4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    78f7:	06                   	push   es
    78f8:	57                   	push   di
    78f9:	9a d4 19 4e 79       	call   0x794e:0x19d4
    78fe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7901:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7904:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7907:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    790c:	26 c6 45 25 00       	mov    BYTE PTR es:[di+0x25],0x0
    7911:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7914:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7917:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    791a:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    791f:	06                   	push   es
    7920:	57                   	push   di
    7921:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7924:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    7928:	c9                   	leave
    7929:	ca 08 00             	retf   0x8
    792c:	55                   	push   bp
    792d:	89 e5                	mov    bp,sp
    792f:	31 c0                	xor    ax,ax
    7931:	9a 44 04 78 79       	call   0x7978:0x444
    7936:	9a c6 34 ff ff       	call   0xffff:0x34c6
    793b:	08 c0                	or     al,al
    793d:	74 2c                	je     0x796b
    793f:	6a 00                	push   0x0
    7941:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7944:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    7949:	06                   	push   es
    794a:	57                   	push   di
    794b:	9a 77 1c 69 79       	call   0x7969:0x1c77
    7950:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7953:	06                   	push   es
    7954:	57                   	push   di
    7955:	9a 2d 5a 6a 7a       	call   0x7a6a:0x5a2d
    795a:	6a 01                	push   0x1
    795c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    795f:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    7964:	06                   	push   es
    7965:	57                   	push   di
    7966:	9a 77 1c 8c 79       	call   0x798c:0x1c77
    796b:	c9                   	leave
    796c:	ca 08 00             	retf   0x8
    796f:	55                   	push   bp
    7970:	89 e5                	mov    bp,sp
    7972:	b8 14 00             	mov    ax,0x14
    7975:	9a 44 04 e3 79       	call   0x79e3:0x444
    797a:	83 ec 14             	sub    sp,0x14
    797d:	6a 00                	push   0x0
    797f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7982:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    7987:	06                   	push   es
    7988:	57                   	push   di
    7989:	9a 77 1c 9f 79       	call   0x799f:0x1c77
    798e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7991:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    7995:	26 c4 bd dc 02       	les    di,DWORD PTR es:[di+0x2dc]
    799a:	06                   	push   es
    799b:	57                   	push   di
    799c:	9a bf 17 b2 79       	call   0x79b2:0x17bf
    79a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79a4:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    79a8:	26 c4 bd dc 02       	les    di,DWORD PTR es:[di+0x2dc]
    79ad:	06                   	push   es
    79ae:	57                   	push   di
    79af:	9a e1 17 cc 79       	call   0x79cc:0x17e1
    79b4:	31 c0                	xor    ax,ax
    79b6:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    79b9:	31 c0                	xor    ax,ax
    79bb:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    79be:	ff 76 ee             	push   WORD PTR [bp-0x12]
    79c1:	ff 76 ec             	push   WORD PTR [bp-0x14]
    79c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79c7:	06                   	push   es
    79c8:	57                   	push   di
    79c9:	9a d4 19 5b 7a       	call   0x7a5b:0x19d4
    79ce:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    79d1:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    79d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79d7:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    79db:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    79de:	71 05                	jno    0x79e5
    79e0:	9a 3e 04 f7 79       	call   0x79f7:0x43e
    79e5:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    79e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79eb:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    79ef:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    79f2:	71 05                	jno    0x79f9
    79f4:	9a 3e 04 0b 7a       	call   0x7a0b:0x43e
    79f9:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    79fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79ff:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    7a03:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    7a06:	71 05                	jno    0x7a0d
    7a08:	9a 3e 04 1f 7a       	call   0x7a1f:0x43e
    7a0d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    7a10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a13:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7a17:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    7a1a:	71 05                	jno    0x7a21
    7a1c:	9a 3e 04 ff ff       	call   0xffff:0x43e
    7a21:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    7a24:	31 c0                	xor    ax,ax
    7a26:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7a29:	31 c0                	xor    ax,ax
    7a2b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7a2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a31:	26 c4 bd dc 02       	les    di,DWORD PTR es:[di+0x2dc]
    7a36:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    7a3a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7a3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a40:	26 c4 bd dc 02       	les    di,DWORD PTR es:[di+0x2dc]
    7a45:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    7a49:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7a4c:	6a 00                	push   0x0
    7a4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a51:	26 c4 bd dc 02       	les    di,DWORD PTR es:[di+0x2dc]
    7a56:	06                   	push   es
    7a57:	57                   	push   di
    7a58:	9a 77 1c bb 7a       	call   0x7abb:0x1c77
    7a5d:	8d 7e f8             	lea    di,[bp-0x8]
    7a60:	16                   	push   ss
    7a61:	57                   	push   di
    7a62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a65:	06                   	push   es
    7a66:	57                   	push   di
    7a67:	9a d5 33 ff ff       	call   0xffff:0x33d5
    7a6c:	52                   	push   dx
    7a6d:	50                   	push   ax
    7a6e:	8d 7e f0             	lea    di,[bp-0x10]
    7a71:	16                   	push   ss
    7a72:	57                   	push   di
    7a73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a76:	26 c4 bd dc 02       	les    di,DWORD PTR es:[di+0x2dc]
    7a7b:	06                   	push   es
    7a7c:	57                   	push   di
    7a7d:	9a 94 1f ff ff       	call   0xffff:0x1f94
    7a82:	89 c7                	mov    di,ax
    7a84:	8e c2                	mov    es,dx
    7a86:	06                   	push   es
    7a87:	57                   	push   di
    7a88:	9a 10 1b ff ff       	call   0xffff:0x1b10
    7a8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a90:	26 c4 bd dc 02       	les    di,DWORD PTR es:[di+0x2dc]
    7a95:	26 ff b5 90 00       	push   WORD PTR es:[di+0x90]
    7a9a:	26 ff b5 8e 00       	push   WORD PTR es:[di+0x8e]
    7a9f:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    7aa3:	06                   	push   es
    7aa4:	57                   	push   di
    7aa5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7aa8:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    7aac:	6a 01                	push   0x1
    7aae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ab1:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    7ab6:	06                   	push   es
    7ab7:	57                   	push   di
    7ab8:	9a 77 1c ff ff       	call   0xffff:0x1c77
    7abd:	c9                   	leave
    7abe:	ca                   	.byte 0xca
    7abf:	08                   	.byte 0x8
