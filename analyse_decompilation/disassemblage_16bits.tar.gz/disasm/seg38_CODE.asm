; ================================================================
; seg38_CODE  (29068 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	26 00 01             	add    BYTE PTR es:[bx+di],al
       3:	06                   	push   es
       4:	54                   	push   sp
       5:	43                   	inc    bx
       6:	6f                   	outs   dx,WORD PTR ds:[si]
       7:	6c                   	ins    BYTE PTR es:[di],dx
       8:	6f                   	outs   dx,WORD PTR ds:[si]
       9:	72 04                	jb     0xf
       b:	eb ff                	jmp    0xc
       d:	ff                   	(bad)
       e:	ff                   	(bad)
       f:	ff                   	(bad)
      10:	ff                   	(bad)
      11:	ff 02                	inc    WORD PTR [bp+si]
	...
      1b:	33 00                	xor    ax,WORD PTR [bx+si]
      1d:	0c 00                	or     al,0x0
      1f:	2e 00 61 00          	add    BYTE PTR cs:[bx+di+0x0],ah
      23:	64 20 5d 00          	and    BYTE PTR fs:[di+0x0],bl
      27:	9a 1f 25 00 cb       	call   0xcb00:0x251f
      2c:	1f                   	pop    ds
      2d:	29 00                	sub    WORD PTR [bx+si],ax
      2f:	c4 29                	les    bp,DWORD PTR [bx+di]
      31:	21 00                	and    WORD PTR [bx+si],ax
      33:	0f 45 49 6e          	cmovne cx,WORD PTR [bx+di+0x6e]
      37:	76 61                	jbe    0x9a
      39:	6c                   	ins    BYTE PTR es:[di],dx
      3a:	69 64 47 72 61       	imul   sp,WORD PTR [si+0x47],0x6172
      3f:	70 68                	jo     0xa9
      41:	69 63 00 00 00       	imul   sp,WORD PTR [bp+di+0x0],0x0
      46:	00 00                	add    BYTE PTR [bx+si],al
      48:	00 00                	add    BYTE PTR [bx+si],al
      4a:	00 63 00             	add    BYTE PTR [bp+di+0x0],ah
      4d:	0c 00                	or     al,0x0
      4f:	2e 00 ea             	cs add dl,ch
      52:	0d 64 20             	or     ax,0x2064
      55:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
      56:	02 9a 1f 55          	add    bl,BYTE PTR [bp+si+0x551f]
      5a:	00 cb                	add    bl,cl
      5c:	1f                   	pop    ds
      5d:	59                   	pop    cx
      5e:	00 c4                	add    ah,al
      60:	29 51 00             	sub    WORD PTR [bx+di+0x0],dx
      63:	18 45 49             	sbb    BYTE PTR [di+0x49],al
      66:	6e                   	outs   dx,BYTE PTR ds:[si]
      67:	76 61                	jbe    0xca
      69:	6c                   	ins    BYTE PTR es:[di],dx
      6a:	69 64 47 72 61       	imul   sp,WORD PTR [si+0x47],0x6172
      6f:	70 68                	jo     0xd9
      71:	69 63 4f 70 65       	imul   sp,WORD PTR [bp+di+0x4f],0x6570
      76:	72 61                	jb     0xd9
      78:	74 69                	je     0xe3
      7a:	6f                   	outs   dx,WORD PTR ds:[si]
      7b:	6e                   	outs   dx,BYTE PTR ds:[si]
      7c:	03 0a                	add    cx,WORD PTR [bp+si]
      7e:	54                   	push   sp
      7f:	46                   	inc    si
      80:	6f                   	outs   dx,WORD PTR ds:[si]
      81:	6e                   	outs   dx,BYTE PTR ds:[si]
      82:	74 53                	je     0xd7
      84:	74 79                	je     0xff
      86:	6c                   	ins    BYTE PTR es:[di],dx
      87:	65 00 00             	add    BYTE PTR gs:[bx+si],al
      8a:	00 00                	add    BYTE PTR [bx+si],al
      8c:	00 03                	add    BYTE PTR [bp+di],al
      8e:	00 00                	add    BYTE PTR [bx+si],al
      90:	00 7c 00             	add    BYTE PTR [si+0x0],bh
      93:	cd 00                	int    0x0
      95:	06                   	push   es
      96:	66 73 42             	data32 jae 0xdb
      99:	6f                   	outs   dx,WORD PTR ds:[si]
      9a:	6c                   	ins    BYTE PTR es:[di],dx
      9b:	64 08 66 73          	or     BYTE PTR fs:[bp+0x73],ah
      9f:	49                   	dec    cx
      a0:	74 61                	je     0x103
      a2:	6c                   	ins    BYTE PTR es:[di],dx
      a3:	69 63 0b 66 73       	imul   sp,WORD PTR [bp+di+0xb],0x7366
      a8:	55                   	push   bp
      a9:	6e                   	outs   dx,BYTE PTR ds:[si]
      aa:	64 65 72 6c          	fs gs jb 0x11a
      ae:	69 6e 65 0b 66       	imul   bp,WORD PTR [bp+0x65],0x660b
      b3:	73 53                	jae    0x108
      b5:	74 72                	je     0x129
      b7:	69 6b 65 4f 75       	imul   bp,WORD PTR [bp+di+0x65],0x754f
      bc:	74 06                	je     0xc4
      be:	0b 54 46             	or     dx,WORD PTR [si+0x46]
      c1:	6f                   	outs   dx,WORD PTR ds:[si]
      c2:	6e                   	outs   dx,BYTE PTR ds:[si]
      c3:	74 53                	je     0x118
      c5:	74 79                	je     0x140
      c7:	6c                   	ins    BYTE PTR es:[di],dx
      c8:	65 73 01             	gs jae 0xcc
      cb:	7c 00                	jl     0xcd
      cd:	e6 00                	out    0x0,al
      cf:	03 0a                	add    cx,WORD PTR [bp+si]
      d1:	54                   	push   sp
      d2:	46                   	inc    si
      d3:	6f                   	outs   dx,WORD PTR ds:[si]
      d4:	6e                   	outs   dx,BYTE PTR ds:[si]
      d5:	74 50                	je     0x127
      d7:	69 74 63 68 00       	imul   si,WORD PTR [si+0x63],0x68
      dc:	00 00                	add    BYTE PTR [bx+si],al
      de:	00 00                	add    BYTE PTR [bx+si],al
      e0:	02 00                	add    al,BYTE PTR [bx+si]
      e2:	00 00                	add    BYTE PTR [bx+si],al
      e4:	cf                   	iret
      e5:	00 27                	add    BYTE PTR [bx],ah
      e7:	01 09                	add    WORD PTR [bx+di],cx
      e9:	66 70 44             	data32 jo 0x130
      ec:	65 66 61             	gs popad
      ef:	75 6c                	jne    0x15d
      f1:	74 0a                	je     0xfd
      f3:	66 70 56             	data32 jo 0x14c
      f6:	61                   	popa
      f7:	72 69                	jb     0x162
      f9:	61                   	popa
      fa:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      fd:	07                   	pop    es
      fe:	66 70 46             	data32 jo 0x147
     101:	69 78 65 64 05       	imul   di,WORD PTR [bx+si+0x65],0x564
     106:	09 54 46             	or     WORD PTR [si+0x46],dx
     109:	6f                   	outs   dx,WORD PTR ds:[si]
     10a:	6e                   	outs   dx,BYTE PTR ds:[si]
     10b:	74 4e                	je     0x15b
     10d:	61                   	popa
     10e:	6d                   	ins    WORD PTR es:[di],dx
     10f:	65 1f                	gs pop ds
     111:	03 09                	add    cx,WORD PTR [bx+di]
     113:	54                   	push   sp
     114:	50                   	push   ax
     115:	65 6e                	outs   dx,BYTE PTR gs:[si]
     117:	53                   	push   bx
     118:	74 79                	je     0x193
     11a:	6c                   	ins    BYTE PTR es:[di],dx
     11b:	65 00 00             	add    BYTE PTR gs:[bx+si],al
     11e:	00 00                	add    BYTE PTR [bx+si],al
     120:	00 06 00 00          	add    BYTE PTR ds:0x0,al
     124:	00 11                	add    BYTE PTR [bx+di],dl
     126:	01 80 01 07          	add    WORD PTR [bx+si+0x701],ax
     12a:	70 73                	jo     0x19f
     12c:	53                   	push   bx
     12d:	6f                   	outs   dx,WORD PTR ds:[si]
     12e:	6c                   	ins    BYTE PTR es:[di],dx
     12f:	69 64 06 70 73       	imul   sp,WORD PTR [si+0x6],0x7370
     134:	44                   	inc    sp
     135:	61                   	popa
     136:	73 68                	jae    0x1a0
     138:	05 70 73             	add    ax,0x7370
     13b:	44                   	inc    sp
     13c:	6f                   	outs   dx,WORD PTR ds:[si]
     13d:	74 09                	je     0x148
     13f:	70 73                	jo     0x1b4
     141:	44                   	inc    sp
     142:	61                   	popa
     143:	73 68                	jae    0x1ad
     145:	44                   	inc    sp
     146:	6f                   	outs   dx,WORD PTR ds:[si]
     147:	74 0c                	je     0x155
     149:	70 73                	jo     0x1be
     14b:	44                   	inc    sp
     14c:	61                   	popa
     14d:	73 68                	jae    0x1b7
     14f:	44                   	inc    sp
     150:	6f                   	outs   dx,WORD PTR ds:[si]
     151:	74 44                	je     0x197
     153:	6f                   	outs   dx,WORD PTR ds:[si]
     154:	74 07                	je     0x15d
     156:	70 73                	jo     0x1cb
     158:	43                   	inc    bx
     159:	6c                   	ins    BYTE PTR es:[di],dx
     15a:	65 61                	gs popa
     15c:	72 0d                	jb     0x16b
     15e:	70 73                	jo     0x1d3
     160:	49                   	dec    cx
     161:	6e                   	outs   dx,BYTE PTR ds:[si]
     162:	73 69                	jae    0x1cd
     164:	64 65 46             	fs gs inc si
     167:	72 61                	jb     0x1ca
     169:	6d                   	ins    WORD PTR es:[di],dx
     16a:	65 03 08             	add    cx,WORD PTR gs:[bx+si]
     16d:	54                   	push   sp
     16e:	50                   	push   ax
     16f:	65 6e                	outs   dx,BYTE PTR gs:[si]
     171:	4d                   	dec    bp
     172:	6f                   	outs   dx,WORD PTR ds:[si]
     173:	64 65 00 00          	fs add BYTE PTR gs:[bx+si],al
     177:	00 00                	add    BYTE PTR [bx+si],al
     179:	00 0f                	add    BYTE PTR [bx],cl
     17b:	00 00                	add    BYTE PTR [bx+si],al
     17d:	00 6b 01             	add    BYTE PTR [bp+di+0x1],ch
     180:	30 02                	xor    BYTE PTR [bp+si],al
     182:	07                   	pop    es
     183:	70 6d                	jo     0x1f2
     185:	42                   	inc    dx
     186:	6c                   	ins    BYTE PTR es:[di],dx
     187:	61                   	popa
     188:	63 6b 07             	arpl   WORD PTR [bp+di+0x7],bp
     18b:	70 6d                	jo     0x1fa
     18d:	57                   	push   di
     18e:	68 69 74             	push   0x7469
     191:	65 05 70 6d          	gs add ax,0x6d70
     195:	4e                   	dec    si
     196:	6f                   	outs   dx,WORD PTR ds:[si]
     197:	70 05                	jo     0x19e
     199:	70 6d                	jo     0x208
     19b:	4e                   	dec    si
     19c:	6f                   	outs   dx,WORD PTR ds:[si]
     19d:	74 06                	je     0x1a5
     19f:	70 6d                	jo     0x20e
     1a1:	43                   	inc    bx
     1a2:	6f                   	outs   dx,WORD PTR ds:[si]
     1a3:	70 79                	jo     0x21e
     1a5:	09 70 6d             	or     WORD PTR [bx+si+0x6d],si
     1a8:	4e                   	dec    si
     1a9:	6f                   	outs   dx,WORD PTR ds:[si]
     1aa:	74 43                	je     0x1ef
     1ac:	6f                   	outs   dx,WORD PTR ds:[si]
     1ad:	70 79                	jo     0x228
     1af:	0d 70 6d             	or     ax,0x6d70
     1b2:	4d                   	dec    bp
     1b3:	65 72 67             	gs jb  0x21d
     1b6:	65 50                	gs push ax
     1b8:	65 6e                	outs   dx,BYTE PTR gs:[si]
     1ba:	4e                   	dec    si
     1bb:	6f                   	outs   dx,WORD PTR ds:[si]
     1bc:	74 0c                	je     0x1ca
     1be:	70 6d                	jo     0x22d
     1c0:	4d                   	dec    bp
     1c1:	61                   	popa
     1c2:	73 6b                	jae    0x22f
     1c4:	50                   	push   ax
     1c5:	65 6e                	outs   dx,BYTE PTR gs:[si]
     1c7:	4e                   	dec    si
     1c8:	6f                   	outs   dx,WORD PTR ds:[si]
     1c9:	74 0d                	je     0x1d8
     1cb:	70 6d                	jo     0x23a
     1cd:	4d                   	dec    bp
     1ce:	65 72 67             	gs jb  0x238
     1d1:	65 4e                	gs dec si
     1d3:	6f                   	outs   dx,WORD PTR ds:[si]
     1d4:	74 50                	je     0x226
     1d6:	65 6e                	outs   dx,BYTE PTR gs:[si]
     1d8:	0c 70                	or     al,0x70
     1da:	6d                   	ins    WORD PTR es:[di],dx
     1db:	4d                   	dec    bp
     1dc:	61                   	popa
     1dd:	73 6b                	jae    0x24a
     1df:	4e                   	dec    si
     1e0:	6f                   	outs   dx,WORD PTR ds:[si]
     1e1:	74 50                	je     0x233
     1e3:	65 6e                	outs   dx,BYTE PTR gs:[si]
     1e5:	07                   	pop    es
     1e6:	70 6d                	jo     0x255
     1e8:	4d                   	dec    bp
     1e9:	65 72 67             	gs jb  0x253
     1ec:	65 0a 70 6d          	or     dh,BYTE PTR gs:[bx+si+0x6d]
     1f0:	4e                   	dec    si
     1f1:	6f                   	outs   dx,WORD PTR ds:[si]
     1f2:	74 4d                	je     0x241
     1f4:	65 72 67             	gs jb  0x25e
     1f7:	65 06                	gs push es
     1f9:	70 6d                	jo     0x268
     1fb:	4d                   	dec    bp
     1fc:	61                   	popa
     1fd:	73 6b                	jae    0x26a
     1ff:	09 70 6d             	or     WORD PTR [bx+si+0x6d],si
     202:	4e                   	dec    si
     203:	6f                   	outs   dx,WORD PTR ds:[si]
     204:	74 4d                	je     0x253
     206:	61                   	popa
     207:	73 6b                	jae    0x274
     209:	05 70 6d             	add    ax,0x6d70
     20c:	58                   	pop    ax
     20d:	6f                   	outs   dx,WORD PTR ds:[si]
     20e:	72 08                	jb     0x218
     210:	70 6d                	jo     0x27f
     212:	4e                   	dec    si
     213:	6f                   	outs   dx,WORD PTR ds:[si]
     214:	74 58                	je     0x26e
     216:	6f                   	outs   dx,WORD PTR ds:[si]
     217:	72 03                	jb     0x21c
     219:	0b 54 42             	or     dx,WORD PTR [si+0x42]
     21c:	72 75                	jb     0x293
     21e:	73 68                	jae    0x288
     220:	53                   	push   bx
     221:	74 79                	je     0x29c
     223:	6c                   	ins    BYTE PTR es:[di],dx
     224:	65 00 00             	add    BYTE PTR gs:[bx+si],al
     227:	00 00                	add    BYTE PTR [bx+si],al
     229:	00 07                	add    BYTE PTR [bx],al
     22b:	00 00                	add    BYTE PTR [bx+si],al
     22d:	00 18                	add    BYTE PTR [bx+si],bl
     22f:	02 c8                	add    cl,al
     231:	02 07                	add    al,BYTE PTR [bx]
     233:	62 73 53             	bound  si,DWORD PTR [bp+di+0x53]
     236:	6f                   	outs   dx,WORD PTR ds:[si]
     237:	6c                   	ins    BYTE PTR es:[di],dx
     238:	69 64 07 62 73       	imul   sp,WORD PTR [si+0x7],0x7362
     23d:	43                   	inc    bx
     23e:	6c                   	ins    BYTE PTR es:[di],dx
     23f:	65 61                	gs popa
     241:	72 0c                	jb     0x24f
     243:	62 73 48             	bound  si,DWORD PTR [bp+di+0x48]
     246:	6f                   	outs   dx,WORD PTR ds:[si]
     247:	72 69                	jb     0x2b2
     249:	7a 6f                	jp     0x2ba
     24b:	6e                   	outs   dx,BYTE PTR ds:[si]
     24c:	74 61                	je     0x2af
     24e:	6c                   	ins    BYTE PTR es:[di],dx
     24f:	0a 62 73             	or     ah,BYTE PTR [bp+si+0x73]
     252:	56                   	push   si
     253:	65 72 74             	gs jb  0x2ca
     256:	69 63 61 6c 0b       	imul   sp,WORD PTR [bp+di+0x61],0xb6c
     25b:	62 73 46             	bound  si,DWORD PTR [bp+di+0x46]
     25e:	44                   	inc    sp
     25f:	69 61 67 6f 6e       	imul   sp,WORD PTR [bx+di+0x67],0x6e6f
     264:	61                   	popa
     265:	6c                   	ins    BYTE PTR es:[di],dx
     266:	0b 62 73             	or     sp,WORD PTR [bp+si+0x73]
     269:	42                   	inc    dx
     26a:	44                   	inc    sp
     26b:	69 61 67 6f 6e       	imul   sp,WORD PTR [bx+di+0x67],0x6e6f
     270:	61                   	popa
     271:	6c                   	ins    BYTE PTR es:[di],dx
     272:	07                   	pop    es
     273:	62 73 43             	bound  si,DWORD PTR [bp+di+0x43]
     276:	72 6f                	jb     0x2e7
     278:	73 73                	jae    0x2ed
     27a:	0b 62 73             	or     sp,WORD PTR [bp+si+0x73]
     27d:	44                   	inc    sp
     27e:	69 61 67 43 72       	imul   sp,WORD PTR [bx+di+0x67],0x7243
     283:	6f                   	outs   dx,WORD PTR ds:[si]
     284:	73 73                	jae    0x2f9
     286:	ca 02 00             	retf   0x2
     289:	00 00                	add    BYTE PTR [bx+si],al
     28b:	00 c2                	add    dl,al
     28d:	02 b2 02 10          	add    dh,BYTE PTR [bp+si+0x1002]
     291:	00 d1                	add    cl,dl
     293:	02 e1                	add    ah,cl
     295:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     298:	0a 03                	or     al,BYTE PTR [bp+di]
     29a:	9a 1f 98 02 cb       	call   0xcb02:0x981f
     29f:	1f                   	pop    ds
     2a0:	9c                   	pushf
     2a1:	02 66 1f             	add    ah,BYTE PTR [bp+0x1f]
     2a4:	a0 02 cd             	mov    al,ds:0xcd02
     2a7:	11 ac 02 e4          	adc    WORD PTR [si-0x1bfe],bp
     2ab:	11 b0 02 fa          	adc    WORD PTR [bx+si-0x5fe],si
     2af:	10 94 02 0f          	adc    BYTE PTR [si+0xf02],dl
     2b3:	54                   	push   sp
     2b4:	47                   	inc    di
     2b5:	72 61                	jb     0x318
     2b7:	70 68                	jo     0x321
     2b9:	69 63 73 4f 62       	imul   sp,WORD PTR [bp+di+0x73],0x624f
     2be:	6a 65                	push   0x65
     2c0:	63 74 01             	arpl   WORD PTR [si+0x1],si
     2c3:	00 ff                	add    bh,bh
     2c5:	ff 72 0e             	push   WORD PTR [bp+si+0xe]
     2c8:	dd 02                	fld    QWORD PTR [bp+si]
     2ca:	07                   	pop    es
     2cb:	0f 54 47 72          	andps  xmm0,XMMWORD PTR [bx+0x72]
     2cf:	61                   	popa
     2d0:	70 68                	jo     0x33a
     2d2:	69 63 73 4f 62       	imul   sp,WORD PTR [bp+di+0x73],0x624f
     2d7:	6a 65                	push   0x65
     2d9:	63 74 a6             	arpl   WORD PTR [si-0x5a],si
     2dc:	02 0e 03 e9          	add    cl,BYTE PTR ds:0xe903
     2e0:	02 12                	add    dl,BYTE PTR [bp+si]
     2e2:	03 00                	add    ax,WORD PTR [bx+si]
     2e4:	00 08                	add    BYTE PTR [bx+si],cl
     2e6:	47                   	inc    di
     2e7:	72 61                	jb     0x34a
     2e9:	70 68                	jo     0x353
     2eb:	69 63 73 00 00       	imul   sp,WORD PTR [bp+di+0x73],0x0
     2f0:	22 03                	and    al,BYTE PTR [bp+di]
     2f2:	00 00                	add    BYTE PTR [bx+si],al
     2f4:	00 00                	add    BYTE PTR [bx+si],al
     2f6:	00 00                	add    BYTE PTR [bx+si],al
     2f8:	1c 03                	sbb    al,0x3
     2fa:	16                   	push   ss
     2fb:	00 a6 02 2b          	add    BYTE PTR [bp+0x2b02],ah
     2ff:	03 64 20             	add    sp,WORD PTR [si+0x20]
     302:	5e                   	pop    si
     303:	03 9a 1f 02          	add    bx,WORD PTR [bp+si+0x21f]
     307:	03 cb                	add    cx,bx
     309:	1f                   	pop    ds
     30a:	06                   	push   es
     30b:	03 ec                	add    bp,sp
     30d:	0e                   	push   cs
     30e:	1a 03                	sbb    al,BYTE PTR [bp+di]
     310:	cd 11                	int    0x11
     312:	16                   	push   ss
     313:	03 e4                	add    sp,sp
     315:	11 13                	adc    WORD PTR [bp+di],dx
     317:	04 14                	add    al,0x14
     319:	0f fe 02             	paddd  mm0,QWORD PTR [bp+si]
     31c:	05 54 46             	add    ax,0x4654
     31f:	6f                   	outs   dx,WORD PTR ds:[si]
     320:	6e                   	outs   dx,BYTE PTR ds:[si]
     321:	74 07                	je     0x32a
     323:	05 54 46             	add    ax,0x4654
     326:	6f                   	outs   dx,WORD PTR ds:[si]
     327:	6e                   	outs   dx,BYTE PTR ds:[si]
     328:	74 10                	je     0x33a
     32a:	03 2f                	add    bp,WORD PTR [bx]
     32c:	03 ca                	add    cx,dx
     32e:	02 40 03             	add    al,BYTE PTR [bx+si+0x3]
     331:	06                   	push   es
     332:	00 08                	add    BYTE PTR [bx+si],cl
     334:	47                   	inc    di
     335:	72 61                	jb     0x398
     337:	70 68                	jo     0x3a1
     339:	69 63 73 06 00       	imul   sp,WORD PTR [bp+di+0x73],0x6
     33e:	02 00                	add    al,BYTE PTR [bx+si]
     340:	48                   	dec    ax
     341:	03 10                	add    dx,WORD PTR [bx+si]
     343:	00 ff                	add    bh,bh
     345:	ff                   	call   (bad)
     346:	df 0f                	fisttp WORD PTR [bx]
     348:	62 03                	bound  ax,DWORD PTR [bp+di]
     34a:	01 00                	add    WORD PTR [bx+si],ax
     34c:	00 00                	add    BYTE PTR [bx+si],al
     34e:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     352:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     356:	05 43 6f             	add    ax,0x6f43
     359:	6c                   	ins    BYTE PTR es:[di],dx
     35a:	6f                   	outs   dx,WORD PTR ds:[si]
     35b:	72 d4                	jb     0x331
     35d:	22 b8 03 19          	and    bh,BYTE PTR [bx+si+0x1903]
     361:	11 66 03             	adc    WORD PTR [bp+0x3],sp
     364:	32 11                	xor    dl,BYTE PTR [bx+di]
     366:	7d 03                	jge    0x36b
     368:	01 00                	add    WORD PTR [bx+si],ax
     36a:	00 00                	add    BYTE PTR [bx+si],al
     36c:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     370:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     374:	06                   	push   es
     375:	48                   	dec    ax
     376:	65 69 67 68 74 05    	imul   sp,WORD PTR gs:[bx+0x68],0x574
     37c:	01 81 03 5e          	add    WORD PTR [bx+di+0x5e03],ax
     380:	11 85 03 7e          	adc    WORD PTR [di+0x7e03],ax
     384:	11 9a 03 01          	adc    WORD PTR [bp+si+0x103],bx
     388:	00 00                	add    BYTE PTR [bx+si],al
     38a:	00 00                	add    BYTE PTR [bx+si],al
     38c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     38f:	00 80 02 00          	add    BYTE PTR [bx+si+0x2],al
     393:	04 4e                	add    al,0x4e
     395:	61                   	popa
     396:	6d                   	ins    WORD PTR es:[di],dx
     397:	65 cf                	gs iret
     399:	00 9e 03 5f          	add    BYTE PTR [bp+0x5f03],bl
     39d:	12 a2 03 78          	adc    ah,BYTE PTR [bp+si+0x7803]
     3a1:	12 bc 03 01          	adc    bh,BYTE PTR [si+0x103]
     3a5:	00 00                	add    BYTE PTR [bx+si],al
     3a7:	00 00                	add    BYTE PTR [bx+si],al
     3a9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3ac:	00 00                	add    BYTE PTR [bx+si],al
     3ae:	03 00                	add    ax,WORD PTR [bx+si]
     3b0:	05 50 69             	add    ax,0x6950
     3b3:	74 63                	je     0x418
     3b5:	68 d4 22             	push   0x22d4
     3b8:	0b 04                	or     ax,WORD PTR [si]
     3ba:	cc                   	int3
     3bb:	11 c0                	adc    ax,ax
     3bd:	03 f5                	add    si,bp
     3bf:	11 d5                	adc    bp,dx
     3c1:	03 00                	add    ax,WORD PTR [bx+si]
     3c3:	00 00                	add    BYTE PTR [bx+si],al
     3c5:	00 00                	add    BYTE PTR [bx+si],al
     3c7:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3ca:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     3ce:	04 53                	add    al,0x53
     3d0:	69 7a 65 bd 00       	imul   di,WORD PTR [bp+si+0x65],0xbd
     3d5:	d9 03                	fld    DWORD PTR [bp+di]
     3d7:	1a 12                	sbb    dl,BYTE PTR [bp+si]
     3d9:	dd 03                	fld    QWORD PTR [bp+di]
     3db:	33 12                	xor    dx,WORD PTR [bp+si]
     3dd:	0f 04                	(bad)
     3df:	01 00                	add    WORD PTR [bx+si],ax
     3e1:	00 00                	add    BYTE PTR [bx+si],al
     3e3:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     3e7:	00 80 05 00          	add    BYTE PTR [bx+si+0x5],al
     3eb:	05 53 74             	add    ax,0x7453
     3ee:	79 6c                	jns    0x45c
     3f0:	65 22 04             	and    al,BYTE PTR gs:[si]
     3f3:	00 00                	add    BYTE PTR [bx+si],al
     3f5:	00 00                	add    BYTE PTR [bx+si],al
     3f7:	00 00                	add    BYTE PTR [bx+si],al
     3f9:	1d 04 11             	sbb    ax,0x1104
     3fc:	00 a6 02 2a          	add    BYTE PTR [bp+0x2a02],ah
     400:	04 64                	add    al,0x64
     402:	20 98 04 9a          	and    BYTE PTR [bx+si-0x65fc],bl
     406:	1f                   	pop    ds
     407:	03 04                	add    ax,WORD PTR [si]
     409:	cb                   	retf
     40a:	1f                   	pop    ds
     40b:	07                   	pop    es
     40c:	04 ec                	add    al,0xec
     40e:	12 1b                	adc    bl,BYTE PTR [bp+di]
     410:	04 cd                	add    al,0xcd
     412:	11 17                	adc    WORD PTR [bx],dx
     414:	04 e4                	add    al,0xe4
     416:	11 d6                	adc    si,dx
     418:	04 14                	add    al,0x14
     41a:	13 ff                	adc    di,di
     41c:	03 04                	add    ax,WORD PTR [si]
     41e:	54                   	push   sp
     41f:	50                   	push   ax
     420:	65 6e                	outs   dx,BYTE PTR gs:[si]
     422:	07                   	pop    es
     423:	04 54                	add    al,0x54
     425:	50                   	push   ax
     426:	65 6e                	outs   dx,BYTE PTR gs:[si]
     428:	11 04                	adc    WORD PTR [si],ax
     42a:	2e 04 ca             	cs add al,0xca
     42d:	02 3f                	add    bh,BYTE PTR [bx]
     42f:	04 04                	add    al,0x4
     431:	00 08                	add    BYTE PTR [bx+si],cl
     433:	47                   	inc    di
     434:	72 61                	jb     0x497
     436:	70 68                	jo     0x4a0
     438:	69 63 73 04 00       	imul   sp,WORD PTR [bp+di+0x73],0x4
     43d:	02 00                	add    al,BYTE PTR [bx+si]
     43f:	43                   	inc    bx
     440:	04 b7                	add    al,0xb7
     442:	13 47 04             	adc    ax,WORD PTR [bx+0x4]
     445:	da 13                	ficom  DWORD PTR [bp+di]
     447:	5d                   	pop    bp
     448:	04 01                	add    al,0x1
     44a:	00 00                	add    BYTE PTR [bx+si],al
     44c:	00 00                	add    BYTE PTR [bx+si],al
     44e:	80 00 00             	add    BYTE PTR [bx+si],0x0
     451:	00 00                	add    BYTE PTR [bx+si],al
     453:	00 00                	add    BYTE PTR [bx+si],al
     455:	05 43 6f             	add    ax,0x6f43
     458:	6c                   	ins    BYTE PTR es:[di],dx
     459:	6f                   	outs   dx,WORD PTR ds:[si]
     45a:	72 6b                	jb     0x4c7
     45c:	01 65 04             	add    WORD PTR [di+0x4],sp
     45f:	10 00                	adc    BYTE PTR [bx+si],al
     461:	ff                   	(bad)
     462:	ff 73 14             	push   WORD PTR [bp+di+0x14]
     465:	7a 04                	jp     0x46b
     467:	01 00                	add    WORD PTR [bx+si],ax
     469:	00 00                	add    BYTE PTR [bx+si],al
     46b:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     46f:	00 00                	add    BYTE PTR [bx+si],al
     471:	01 00                	add    WORD PTR [bx+si],ax
     473:	04 4d                	add    al,0x4d
     475:	6f                   	outs   dx,WORD PTR ds:[si]
     476:	64 65 11 01          	fs adc WORD PTR gs:[bx+di],ax
     47a:	7e 04                	jle    0x480
     47c:	97                   	xchg   di,ax
     47d:	14 82                	adc    al,0x82
     47f:	04 b0                	add    al,0xb0
     481:	14 9c                	adc    al,0x9c
     483:	04 01                	add    al,0x1
     485:	00 00                	add    BYTE PTR [bx+si],al
     487:	00 00                	add    BYTE PTR [bx+si],al
     489:	80 00 00             	add    BYTE PTR [bx+si],0x0
     48c:	00 00                	add    BYTE PTR [bx+si],al
     48e:	02 00                	add    al,BYTE PTR [bx+si]
     490:	05 53 74             	add    ax,0x7453
     493:	79 6c                	jns    0x501
     495:	65 d4 22             	gs aam 0x22
     498:	ce                   	into
     499:	04 dc                	add    al,0xdc
     49b:	14 a0                	adc    al,0xa0
     49d:	04 f5                	add    al,0xf5
     49f:	14 d2                	adc    al,0xd2
     4a1:	04 01                	add    al,0x1
     4a3:	00 00                	add    BYTE PTR [bx+si],al
     4a5:	00 00                	add    BYTE PTR [bx+si],al
     4a7:	80 01 00             	add    BYTE PTR [bx+di],0x0
     4aa:	00 00                	add    BYTE PTR [bx+si],al
     4ac:	03 00                	add    ax,WORD PTR [bx+si]
     4ae:	05 57 69             	add    ax,0x6957
     4b1:	64 74 68             	fs je  0x51c
     4b4:	e7 04                	out    0x4,ax
     4b6:	00 00                	add    BYTE PTR [bx+si],al
     4b8:	00 00                	add    BYTE PTR [bx+si],al
     4ba:	00 00                	add    BYTE PTR [bx+si],al
     4bc:	e0 04                	loopne 0x4c2
     4be:	10 00                	adc    BYTE PTR [bx+si],al
     4c0:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     4c1:	02 f1                	add    dh,cl
     4c3:	04 64                	add    al,0x64
     4c5:	20 5a 05             	and    BYTE PTR [bp+si+0x5],bl
     4c8:	9a 1f c6 04 cb       	call   0xcb04:0xc61f
     4cd:	1f                   	pop    ds
     4ce:	ca 04 6a             	retf   0x6a04
     4d1:	15 de 04             	adc    ax,0x4de
     4d4:	cd 11                	int    0x11
     4d6:	da 04                	fiadd  DWORD PTR [si]
     4d8:	e4 11                	in     al,0x11
     4da:	62 05                	bound  ax,DWORD PTR [di]
     4dc:	92                   	xchg   dx,ax
     4dd:	15 c2 04             	adc    ax,0x4c2
     4e0:	06                   	push   es
     4e1:	54                   	push   sp
     4e2:	42                   	inc    dx
     4e3:	72 75                	jb     0x55a
     4e5:	73 68                	jae    0x54f
     4e7:	07                   	pop    es
     4e8:	06                   	push   es
     4e9:	54                   	push   sp
     4ea:	42                   	inc    dx
     4eb:	72 75                	jb     0x562
     4ed:	73 68                	jae    0x557
     4ef:	d4 04                	aam    0x4
     4f1:	f5                   	cmc
     4f2:	04 ca                	add    al,0xca
     4f4:	02 06 05 02          	add    al,BYTE PTR ds:0x205
     4f8:	00 08                	add    BYTE PTR [bx+si],cl
     4fa:	47                   	inc    di
     4fb:	72 61                	jb     0x55e
     4fd:	70 68                	jo     0x567
     4ff:	69 63 73 02 00       	imul   sp,WORD PTR [bp+di+0x73],0x2
     504:	02 00                	add    al,BYTE PTR [bx+si]
     506:	0a 05                	or     al,BYTE PTR [di]
     508:	61                   	popa
     509:	16                   	push   ss
     50a:	0e                   	push   cs
     50b:	05 84 16             	add    ax,0x1684
     50e:	24 05                	and    al,0x5
     510:	01 00                	add    WORD PTR [bx+si],ax
     512:	00 00                	add    BYTE PTR [bx+si],al
     514:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     518:	ff 00                	inc    WORD PTR [bx+si]
     51a:	00 00                	add    BYTE PTR [bx+si],al
     51c:	05 43 6f             	add    ax,0x6f43
     51f:	6c                   	ins    BYTE PTR es:[di],dx
     520:	6f                   	outs   dx,WORD PTR ds:[si]
     521:	72 18                	jb     0x53b
     523:	02 28                	add    ch,BYTE PTR [bx+si]
     525:	05 63 17             	add    ax,0x1763
     528:	2c 05                	sub    al,0x5
     52a:	7c 17                	jl     0x543
     52c:	6e                   	outs   dx,BYTE PTR ds:[si]
     52d:	05 01 00             	add    ax,0x1
     530:	00 00                	add    BYTE PTR [bx+si],al
     532:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     536:	00 00                	add    BYTE PTR [bx+si],al
     538:	01 00                	add    WORD PTR [bx+si],ax
     53a:	05 53 74             	add    ax,0x7453
     53d:	79 6c                	jns    0x5ab
     53f:	65 80 05 00          	add    BYTE PTR gs:[di],0x0
     543:	00 00                	add    BYTE PTR [bx+si],al
     545:	00 00                	add    BYTE PTR [bx+si],al
     547:	00 78 05             	add    BYTE PTR [bx+si+0x5],bh
     54a:	2b 00                	sub    ax,WORD PTR [bx+si]
     54c:	d1 02                	rol    WORD PTR [bp+si],1
     54e:	8f 05                	pop    WORD PTR [di]
     550:	64 20 be 05 9a       	and    BYTE PTR fs:[bp-0x65fb],bh
     555:	1f                   	pop    ds
     556:	52                   	push   dx
     557:	05 cb 1f             	add    ax,0x1fcb
     55a:	56                   	push   si
     55b:	05 b7 18             	add    ax,0x18b7
     55e:	8b 05                	mov    ax,WORD PTR [di]
     560:	cd 11                	int    0x11
     562:	66 05 e4 11 6a 05    	add    eax,0x56a11e4
     568:	fa                   	cli
     569:	10 4e 05             	adc    BYTE PTR [bp+0x5],cl
     56c:	7f 23                	jg     0x591
     56e:	72 05                	jb     0x575
     570:	5b                   	pop    bx
     571:	23 76 05             	and    si,WORD PTR [bp+0x5]
     574:	56                   	push   si
     575:	22 5e 05             	and    bl,BYTE PTR [bp+0x5]
     578:	07                   	pop    es
     579:	54                   	push   sp
     57a:	43                   	inc    bx
     57b:	61                   	popa
     57c:	6e                   	outs   dx,BYTE PTR ds:[si]
     57d:	76 61                	jbe    0x5e0
     57f:	73 07                	jae    0x588
     581:	07                   	pop    es
     582:	54                   	push   sp
     583:	43                   	inc    bx
     584:	61                   	popa
     585:	6e                   	outs   dx,BYTE PTR ds:[si]
     586:	76 61                	jbe    0x5e9
     588:	73 60                	jae    0x5ea
     58a:	05 a0 05             	add    ax,0x5a0
     58d:	e9 02 38             	jmp    0x3d92
     590:	06                   	push   es
     591:	04 00                	add    al,0x0
     593:	08 47 72             	or     BYTE PTR [bx+0x72],al
     596:	61                   	popa
     597:	70 68                	jo     0x601
     599:	69 63 73 04 00       	imul   sp,WORD PTR [bp+di+0x73],0x4
     59e:	e7 04                	out    0x4,ax
     5a0:	a8 05                	test   al,0x5
     5a2:	0f 00                	(bad)
     5a4:	ff                   	(bad)
     5a5:	ff d3                	call   bx
     5a7:	20 df                	and    bh,bl
     5a9:	05 01 00             	add    ax,0x1
     5ac:	00 00                	add    BYTE PTR [bx+si],al
     5ae:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     5b2:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     5b6:	05 42 72             	add    ax,0x7242
     5b9:	75 73                	jne    0x62e
     5bb:	68 f5 22             	push   0x22f5
     5be:	48                   	dec    ax
     5bf:	06                   	push   es
     5c0:	17                   	pop    ss
     5c1:	00 ff                	add    bh,bh
     5c3:	ff 17                	call   WORD PTR [bx]
     5c5:	00 ff                	add    bh,bh
     5c7:	ff 01                	inc    WORD PTR [bx+di]
     5c9:	00 00                	add    BYTE PTR [bx+si],al
     5cb:	00 00                	add    BYTE PTR [bx+si],al
     5cd:	80 20 00             	and    BYTE PTR [bx+si],0x0
     5d0:	cc                   	int3
     5d1:	00 01                	add    BYTE PTR [bx+di],al
     5d3:	00 08                	add    BYTE PTR [bx+si],cl
     5d5:	43                   	inc    bx
     5d6:	6f                   	outs   dx,WORD PTR ds:[si]
     5d7:	70 79                	jo     0x652
     5d9:	4d                   	dec    bp
     5da:	6f                   	outs   dx,WORD PTR ds:[si]
     5db:	64 65 22 03          	fs and al,BYTE PTR gs:[bp+di]
     5df:	e7 05                	out    0x5,ax
     5e1:	07                   	pop    es
     5e2:	00 ff                	add    bh,bh
     5e4:	ff 99 20 fc          	call   DWORD PTR [bx+di-0x3e0]
     5e8:	05 01 00             	add    ax,0x1
     5eb:	00 00                	add    BYTE PTR [bx+si],al
     5ed:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     5f1:	00 80 02 00          	add    BYTE PTR [bx+si+0x2],al
     5f5:	04 46                	add    al,0x46
     5f7:	6f                   	outs   dx,WORD PTR ds:[si]
     5f8:	6e                   	outs   dx,BYTE PTR ds:[si]
     5f9:	74 22                	je     0x61d
     5fb:	04 04                	add    al,0x4
     5fd:	06                   	push   es
     5fe:	0b 00                	or     ax,WORD PTR [bx+si]
     600:	ff                   	(bad)
     601:	ff b6 20 44          	push   WORD PTR [bp+0x4420]
     605:	06                   	push   es
     606:	01 00                	add    WORD PTR [bx+si],ax
     608:	00 00                	add    BYTE PTR [bx+si],al
     60a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     60e:	00 80 03 00          	add    BYTE PTR [bx+si+0x3],al
     612:	03 50 65             	add    dx,WORD PTR [bx+si+0x65]
     615:	6e                   	outs   dx,BYTE PTR ds:[si]
     616:	87 06 00 00          	xchg   WORD PTR ds:0x0,ax
     61a:	00 00                	add    BYTE PTR [bx+si],al
     61c:	00 00                	add    BYTE PTR [bx+si],al
     61e:	7e 06                	jle    0x626
     620:	0e                   	push   cs
     621:	00 d1                	add    cl,dl
     623:	02 97 06 64          	add    dl,BYTE PTR [bx+0x6406]
     627:	20 c0                	and    al,al
     629:	06                   	push   es
     62a:	9a 1f 28 06 cb       	call   0xcb06:0x281f
     62f:	1f                   	pop    ds
     630:	2c 06                	sub    al,0x6
     632:	66 1f                	popd   ds
     634:	30 06 cd 11          	xor    BYTE PTR ds:0x11cd,al
     638:	24 06                	and    al,0x6
     63a:	cc                   	int3
     63b:	40                   	inc    ax
     63c:	58                   	pop    ax
     63d:	06                   	push   es
     63e:	37                   	aaa
     63f:	40                   	inc    ax
     640:	68 06 02             	push   0x206
     643:	40                   	inc    ax
     644:	3c 06                	cmp    al,0x6
     646:	64 20 4c 06          	and    BYTE PTR fs:[si+0x6],cl
     64a:	64 20 50 06          	and    BYTE PTR fs:[bx+si+0x6],dl
     64e:	64 20 54 06          	and    BYTE PTR fs:[si+0x6],dl
     652:	64 20 5c 06          	and    BYTE PTR fs:[si+0x6],bl
     656:	e0 41                	loopne 0x699
     658:	64 06                	fs push es
     65a:	64 20 60 06          	and    BYTE PTR fs:[bx+si+0x6],ah
     65e:	64 20 70 06          	and    BYTE PTR fs:[bx+si+0x6],dh
     662:	f9                   	stc
     663:	41                   	inc    cx
     664:	40                   	inc    ax
     665:	06                   	push   es
     666:	22 41 6c             	and    al,BYTE PTR [bx+di+0x6c]
     669:	06                   	push   es
     66a:	84 41 93             	test   BYTE PTR [bx+di-0x6d],al
     66d:	06                   	push   es
     66e:	64 20 74 06          	and    BYTE PTR fs:[si+0x6],dh
     672:	64 20 78 06          	and    BYTE PTR fs:[bx+si+0x6],bh
     676:	64 20 7c 06          	and    BYTE PTR fs:[si+0x6],bh
     67a:	64 20 34             	and    BYTE PTR fs:[si],dh
     67d:	06                   	push   es
     67e:	08 54 47             	or     BYTE PTR [si+0x47],dl
     681:	72 61                	jb     0x6e4
     683:	70 68                	jo     0x6ed
     685:	69 63 07 08 54       	imul   sp,WORD PTR [bp+di+0x7],0x5408
     68a:	47                   	inc    di
     68b:	72 61                	jb     0x6ee
     68d:	70 68                	jo     0x6f7
     68f:	69 63 36 06 cc       	imul   sp,WORD PTR [bp+di+0x36],0xcc06
     694:	06                   	push   es
     695:	e9 02 c8             	jmp    0xce9a
     698:	06                   	push   es
     699:	00 00                	add    BYTE PTR [bx+si],al
     69b:	08 47 72             	or     BYTE PTR [bx+0x72],al
     69e:	61                   	popa
     69f:	70 68                	jo     0x709
     6a1:	69 63 73 00 00       	imul   sp,WORD PTR [bp+di+0x73],0x0
     6a6:	db 06 00 00          	fild   DWORD PTR ds:0x0
     6aa:	00 00                	add    BYTE PTR [bx+si],al
     6ac:	00 00                	add    BYTE PTR [bx+si],al
     6ae:	d2 06 10 00          	rol    BYTE PTR ds:0x10,cl
     6b2:	d1 02                	rol    WORD PTR [bp+si],1
     6b4:	eb 06                	jmp    0x6bc
     6b6:	64 20 18             	and    BYTE PTR fs:[bx+si],bl
     6b9:	07                   	pop    es
     6ba:	9a 1f b8 06 cb       	call   0xcb06:0xb81f
     6bf:	1f                   	pop    ds
     6c0:	bc 06 12             	mov    sp,0x1206
     6c3:	42                   	inc    dx
     6c4:	d0 06 cd 11          	rol    BYTE PTR ds:0x11cd,1
     6c8:	b4 06                	mov    ah,0x6
     6ca:	82 47 c4 06          	add    BYTE PTR [bx-0x3c],0x6
     6ce:	32 45 e7             	xor    al,BYTE PTR [di-0x19]
     6d1:	06                   	push   es
     6d2:	08 54 50             	or     BYTE PTR [si+0x50],dl
     6d5:	69 63 74 75 72       	imul   sp,WORD PTR [bp+di+0x74],0x7275
     6da:	65 07                	gs pop es
     6dc:	08 54 50             	or     BYTE PTR [si+0x50],dl
     6df:	69 63 74 75 72       	imul   sp,WORD PTR [bp+di+0x74],0x7275
     6e4:	65 c6 06 5f 07 e9    	mov    BYTE PTR gs:0x75f,0xe9
     6ea:	02 4b 07             	add    cl,BYTE PTR [bp+di+0x7]
     6ed:	00 00                	add    BYTE PTR [bx+si],al
     6ef:	08 47 72             	or     BYTE PTR [bx+0x72],al
     6f2:	61                   	popa
     6f3:	70 68                	jo     0x75d
     6f5:	69 63 73 00 00       	imul   sp,WORD PTR [bp+di+0x73],0x0
	...
     702:	1a 07                	sbb    al,BYTE PTR [bx]
     704:	10 00                	adc    BYTE PTR [bx+si],al
     706:	2c 1f                	sub    al,0x1f
     708:	43                   	inc    bx
     709:	07                   	pop    es
     70a:	64 20 08             	and    BYTE PTR fs:[bx+si],cl
     70d:	07                   	pop    es
     70e:	9a 1f 0c 07 cb       	call   0xcb07:0xc1f
     713:	1f                   	pop    ds
     714:	10 07                	adc    BYTE PTR [bx],al
     716:	66 1f                	popd   ds
     718:	14 07                	adc    al,0x7
     71a:	0e                   	push   cs
     71b:	54                   	push   sp
     71c:	4d                   	dec    bp
     71d:	65 74 61             	gs je  0x781
     720:	66 69 6c 65 49 6d 61 	imul   ebp,DWORD PTR [si+0x65],0x67616d49
     727:	67 
     728:	65 9b                	gs fwait
     72a:	07                   	pop    es
     72b:	00 00                	add    BYTE PTR [bx+si],al
     72d:	00 00                	add    BYTE PTR [bx+si],al
     72f:	00 00                	add    BYTE PTR [bx+si],al
     731:	91                   	xchg   cx,ax
     732:	07                   	pop    es
     733:	12 00                	adc    al,BYTE PTR [bx+si]
     735:	36 06                	ss push es
     737:	a8 07                	test   al,0x7
     739:	64 20 dd             	fs and ch,bl
     73c:	07                   	pop    es
     73d:	9a 1f 3b 07 cb       	call   0xcb07:0x3b1f
     742:	1f                   	pop    ds
     743:	3f                   	aas
     744:	07                   	pop    es
     745:	64 48                	fs dec ax
     747:	83 07 cd             	add    WORD PTR [bx],0xffcd
     74a:	11 41 08             	adc    WORD PTR [bx+di+0x8],ax
     74d:	cc                   	int3
     74e:	40                   	inc    ax
     74f:	7b 07                	jnp    0x758
     751:	91                   	xchg   cx,ax
     752:	48                   	dec    ax
     753:	57                   	push   di
     754:	07                   	pop    es
     755:	02 40 4f             	add    al,BYTE PTR [bx+si+0x4f]
     758:	07                   	pop    es
     759:	66 4c                	dec    esp
     75b:	6b 07 15             	imul   ax,WORD PTR [bx],0x15
     75e:	4a                   	dec    dx
     75f:	63 07                	arpl   WORD PTR [bx],ax
     761:	33 4a 67             	xor    cx,WORD PTR [bp+si+0x67]
     764:	07                   	pop    es
     765:	83 4a 5b 07          	or     WORD PTR [bp+si+0x5b],0x7
     769:	bf 4b 6f             	mov    di,0x6f4b
     76c:	07                   	pop    es
     76d:	d3 4a 73             	ror    WORD PTR [bp+si+0x73],cl
     770:	07                   	pop    es
     771:	4c                   	dec    sp
     772:	4b                   	dec    bx
     773:	77 07                	ja     0x77c
     775:	32 4c 47             	xor    cl,BYTE PTR [si+0x47]
     778:	07                   	pop    es
     779:	22 41 7f             	and    al,BYTE PTR [bx+di+0x7f]
     77c:	07                   	pop    es
     77d:	84 41 37             	test   BYTE PTR [bx+di+0x37],al
     780:	07                   	pop    es
     781:	24 4d                	and    al,0x4d
     783:	87 07                	xchg   WORD PTR [bx],ax
     785:	9b                   	fwait
     786:	4d                   	dec    bp
     787:	8b 07                	mov    ax,WORD PTR [bx]
     789:	e5 4d                	in     ax,0x4d
     78b:	8f 07                	pop    WORD PTR [bx]
     78d:	17                   	pop    ss
     78e:	4f                   	dec    di
     78f:	53                   	push   bx
     790:	07                   	pop    es
     791:	09 54 4d             	or     WORD PTR [si+0x4d],dx
     794:	65 74 61             	gs je  0x7f8
     797:	66 69 6c 65 07 09 54 	imul   ebp,DWORD PTR [si+0x65],0x4d540907
     79e:	4d 
     79f:	65 74 61             	gs je  0x803
     7a2:	66 69 6c 65 49 07 ac 	imul   ebp,DWORD PTR [si+0x65],0x7ac0749
     7a9:	07 
     7aa:	87 06 10 08          	xchg   WORD PTR ds:0x810,ax
     7ae:	00 00                	add    BYTE PTR [bx+si],al
     7b0:	08 47 72             	or     BYTE PTR [bx+0x72],al
     7b3:	61                   	popa
     7b4:	70 68                	jo     0x81e
     7b6:	69 63 73 00 00       	imul   sp,WORD PTR [bp+di+0x73],0x0
	...
     7c3:	df 07                	fild   WORD PTR [bx]
     7c5:	0a 00                	or     al,BYTE PTR [bx+si]
     7c7:	2c 1f                	sub    al,0x1f
     7c9:	0c 08                	or     al,0x8
     7cb:	64 20 c9             	fs and cl,cl
     7ce:	07                   	pop    es
     7cf:	9a 1f cd 07 cb       	call   0xcb07:0xcd1f
     7d4:	1f                   	pop    ds
     7d5:	d1 07                	rol    WORD PTR [bx],1
     7d7:	66 1f                	popd   ds
     7d9:	d5 07                	aad    0x7
     7db:	64 20 d9             	fs and cl,bl
     7de:	07                   	pop    es
     7df:	0e                   	push   cs
     7e0:	54                   	push   sp
     7e1:	49                   	dec    cx
     7e2:	6e                   	outs   dx,BYTE PTR ds:[si]
     7e3:	74 65                	je     0x84a
     7e5:	72 6e                	jb     0x855
     7e7:	61                   	popa
     7e8:	6c                   	ins    BYTE PTR es:[di],dx
     7e9:	49                   	dec    cx
     7ea:	6d                   	ins    WORD PTR es:[di],dx
     7eb:	61                   	popa
     7ec:	67 65 00 00          	add    BYTE PTR gs:[eax],al
     7f0:	00 00                	add    BYTE PTR [bx+si],al
     7f2:	00 00                	add    BYTE PTR [bx+si],al
     7f4:	00 00                	add    BYTE PTR [bx+si],al
     7f6:	12 08                	adc    cl,BYTE PTR [bx+si]
     7f8:	14 00                	adc    al,0x0
     7fa:	db 07                	fild   DWORD PTR [bx]
     7fc:	51                   	push   cx
     7fd:	08 64 20             	or     BYTE PTR [si+0x20],ah
     800:	39 08                	cmp    WORD PTR [bx+si],cx
     802:	9a 1f 00 08 cb       	call   0xcb08:0x1f
     807:	1f                   	pop    ds
     808:	04 08                	add    al,0x8
     80a:	66 1f                	popd   ds
     80c:	08 08                	or     BYTE PTR [bx+si],cl
     80e:	64 53                	fs push bx
     810:	fc                   	cld
     811:	07                   	pop    es
     812:	0c 54                	or     al,0x54
     814:	42                   	inc    dx
     815:	69 74 6d 61 70       	imul   si,WORD PTR [si+0x6d],0x7061
     81a:	49                   	dec    cx
     81b:	6d                   	ins    WORD PTR es:[di],dx
     81c:	61                   	popa
     81d:	67 65 8f 08 00 00    	(bad)
     823:	00 00                	add    BYTE PTR [bx+si],al
     825:	00 00                	add    BYTE PTR [bx+si],al
     827:	87 08                	xchg   WORD PTR [bx+si],cx
     829:	16                   	push   ss
     82a:	00 36 06 9a          	add    BYTE PTR ds:0x9a06,dh
     82e:	08 64 20             	or     BYTE PTR [si+0x20],ah
     831:	cb                   	retf
     832:	08 9a 1f 31          	or     BYTE PTR [bp+si+0x311f],bl
     836:	08 cb                	or     bl,cl
     838:	1f                   	pop    ds
     839:	35 08 18             	xor    ax,0x1808
     83c:	57                   	push   di
     83d:	49                   	dec    cx
     83e:	08 cd                	or     ch,cl
     840:	11 fe                	adc    si,di
     842:	08 cc                	or     ah,cl
     844:	40                   	inc    ax
     845:	71 08                	jno    0x84f
     847:	53                   	push   bx
     848:	57                   	push   di
     849:	81 08 bd 56          	or     WORD PTR [bx+si],0x56bd
     84d:	3d 08 df             	cmp    ax,0xdf08
     850:	58                   	pop    ax
     851:	55                   	push   bp
     852:	08 e3                	or     bl,ah
     854:	59                   	pop    cx
     855:	59                   	pop    cx
     856:	08 db                	or     bl,bl
     858:	5a                   	pop    dx
     859:	5d                   	pop    bp
     85a:	08 8c 5b 61          	or     BYTE PTR [si+0x615b],cl
     85e:	08 16 5f 69          	or     BYTE PTR ds:0x695f,dl
     862:	08 e0                	or     al,ah
     864:	61                   	popa
     865:	6d                   	ins    WORD PTR es:[di],dx
     866:	08 6c 62             	or     BYTE PTR [si+0x62],ch
     869:	65 08 b2 62 4d       	or     BYTE PTR gs:[bp+si+0x4d62],dh
     86e:	08 22                	or     BYTE PTR [bp+si],ah
     870:	41                   	inc    cx
     871:	75 08                	jne    0x87b
     873:	84 41 2d             	test   BYTE PTR [bx+di+0x2d],al
     876:	08 11                	or     BYTE PTR [bx+di],dl
     878:	5e                   	pop    si
     879:	85 08                	test   WORD PTR [bx+si],cx
     87b:	3c 63                	cmp    al,0x63
     87d:	45                   	inc    bp
     87e:	08 1d                	or     BYTE PTR [di],bl
     880:	5d                   	pop    bp
     881:	79 08                	jns    0x88b
     883:	5f                   	pop    di
     884:	63 7d 08             	arpl   WORD PTR [di+0x8],di
     887:	07                   	pop    es
     888:	54                   	push   sp
     889:	42                   	inc    dx
     88a:	69 74 6d 61 70       	imul   si,WORD PTR [si+0x6d],0x7061
     88f:	07                   	pop    es
     890:	07                   	pop    es
     891:	54                   	push   sp
     892:	42                   	inc    dx
     893:	69 74 6d 61 70       	imul   si,WORD PTR [si+0x6d],0x7061
     898:	3f                   	aas
     899:	08 9e 08 87          	or     BYTE PTR [bp-0x78f8],bl
     89d:	06                   	push   es
     89e:	cf                   	iret
     89f:	08 00                	or     BYTE PTR [bx+si],al
     8a1:	00 08                	add    BYTE PTR [bx+si],cl
     8a3:	47                   	inc    di
     8a4:	72 61                	jb     0x907
     8a6:	70 68                	jo     0x910
     8a8:	69 63 73 00 00       	imul   sp,WORD PTR [bp+di+0x73],0x0
	...
     8b5:	d1 08                	ror    WORD PTR [bx+si],1
     8b7:	0c 00                	or     al,0x0
     8b9:	db 07                	fild   DWORD PTR [bx]
     8bb:	0e                   	push   cs
     8bc:	09 64 20             	or     WORD PTR [si+0x20],sp
     8bf:	3e 09 9a 1f bf       	or     WORD PTR ds:[bp+si-0x40e1],bx
     8c4:	08 cb                	or     bl,cl
     8c6:	1f                   	pop    ds
     8c7:	c3                   	ret
     8c8:	08 66 1f             	or     BYTE PTR [bp+0x1f],ah
     8cb:	c7                   	(bad)
     8cc:	08 eb                	or     bl,ch
     8ce:	63 bb 08 0a          	arpl   WORD PTR [bp+di+0xa08],di
     8d2:	54                   	push   sp
     8d3:	49                   	dec    cx
     8d4:	63 6f 6e             	arpl   WORD PTR [bx+0x6e],bp
     8d7:	49                   	dec    cx
     8d8:	6d                   	ins    WORD PTR es:[di],dx
     8d9:	61                   	popa
     8da:	67 65 4a             	addr32 gs dec dx
     8dd:	09 00                	or     WORD PTR [bx+si],ax
     8df:	00 00                	add    BYTE PTR [bx+si],al
     8e1:	00 00                	add    BYTE PTR [bx+si],al
     8e3:	00 44 09             	add    BYTE PTR [si+0x9],al
     8e6:	12 00                	adc    al,BYTE PTR [bx+si]
     8e8:	36 06                	ss push es
     8ea:	53                   	push   bx
     8eb:	09 64 20             	or     WORD PTR [si+0x20],sp
     8ee:	80 09 9a             	or     BYTE PTR [bx+di],0x9a
     8f1:	1f                   	pop    ds
     8f2:	ee                   	out    dx,al
     8f3:	08 cb                	or     bl,cl
     8f5:	1f                   	pop    ds
     8f6:	f2 08 69 64          	repnz or BYTE PTR [bx+di+0x64],ch
     8fa:	06                   	push   es
     8fb:	09 cd                	or     bp,cx
     8fd:	11 6e 0d             	adc    WORD PTR [bp+0xd],bp
     900:	cc                   	int3
     901:	40                   	inc    ax
     902:	1e                   	push   ds
     903:	09 96 64 36          	or     WORD PTR [bp+0x3664],dx
     907:	09 0e 64 fa          	or     WORD PTR ds:0xfa64,cx
     90b:	08 2a                	or     BYTE PTR [bp+si],ch
     90d:	65 12 09             	adc    cl,BYTE PTR gs:[bx+di]
     910:	68 65 16             	push   0x1665
     913:	09 b7 65 1a          	or     WORD PTR [bx+0x1a65],si
     917:	09 cc                	or     sp,cx
     919:	65 22 09             	and    cl,BYTE PTR gs:[bx+di]
     91c:	e0 41                	loopne 0x95f
     91e:	2a 09                	sub    cl,BYTE PTR [bx+di]
     920:	df 68 26             	fild   QWORD PTR [bx+si+0x26]
     923:	09 ec                	or     sp,bp
     925:	68 42 09             	push   0x942
     928:	f9                   	stc
     929:	41                   	inc    cx
     92a:	2e 09 22             	or     WORD PTR cs:[bp+si],sp
     92d:	41                   	inc    cx
     92e:	32 09                	xor    cl,BYTE PTR [bx+di]
     930:	84 41 ea             	test   BYTE PTR [bx+di-0x16],al
     933:	08 51 67             	or     BYTE PTR [bx+di+0x67],dl
     936:	3a 09                	cmp    cl,BYTE PTR [bx+di]
     938:	f9                   	stc
     939:	68 02 09             	push   0x902
     93c:	64 20 f6             	fs and dh,dh
     93f:	08 38                	or     BYTE PTR [bx+si],bh
     941:	69 0a 09 05          	imul   cx,WORD PTR [bp+si],0x509
     945:	54                   	push   sp
     946:	49                   	dec    cx
     947:	63 6f 6e             	arpl   WORD PTR [bx+0x6e],bp
     94a:	07                   	pop    es
     94b:	05 54 49             	add    ax,0x4954
     94e:	63 6f 6e             	arpl   WORD PTR [bx+0x6e],bp
     951:	fc                   	cld
     952:	08 57 09             	or     BYTE PTR [bx+0x9],dl
     955:	87 06 84 09          	xchg   WORD PTR ds:0x984,ax
     959:	00 00                	add    BYTE PTR [bx+si],al
     95b:	08 47 72             	or     BYTE PTR [bx+0x72],al
     95e:	61                   	popa
     95f:	70 68                	jo     0x9c9
     961:	69 63 73 00 00       	imul   sp,WORD PTR [bp+di+0x73],0x0
	...
     96e:	86 09                	xchg   BYTE PTR [bx+di],cl
     970:	1a 00                	sbb    al,BYTE PTR [bx+si]
     972:	2c 1f                	sub    al,0x1f
     974:	af                   	scas   ax,WORD PTR es:[di]
     975:	09 64 20             	or     WORD PTR [si+0x20],sp
     978:	74 09                	je     0x983
     97a:	9a 1f 78 09 cb       	call   0xcb09:0x781f
     97f:	1f                   	pop    ds
     980:	7c 09                	jl     0x98b
     982:	01 6a 04             	add    WORD PTR [bp+si+0x4],bp
     985:	0c 0a                	or     al,0xa
     987:	54                   	push   sp
     988:	49                   	dec    cx
     989:	6d                   	ins    WORD PTR es:[di],dx
     98a:	61                   	popa
     98b:	67 65 4c             	addr32 gs dec sp
     98e:	69 73 74 00 00       	imul   si,WORD PTR [bp+di+0x74],0x0
     993:	00 00                	add    BYTE PTR [bx+si],al
     995:	00 00                	add    BYTE PTR [bx+si],al
     997:	00 00                	add    BYTE PTR [bx+si],al
     999:	b1 09                	mov    cl,0x9
     99b:	0a 00                	or     al,BYTE PTR [bx+si]
     99d:	2c 1f                	sub    al,0x1f
     99f:	03 0a                	add    cx,WORD PTR [bp+si]
     9a1:	64 20 9f 09 9a       	and    BYTE PTR fs:[bx-0x65f7],bl
     9a6:	1f                   	pop    ds
     9a7:	a3 09 cb             	mov    ds:0xcb09,ax
     9aa:	1f                   	pop    ds
     9ab:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     9ac:	09 66 1f             	or     WORD PTR [bp+0x1f],sp
     9af:	ab                   	stos   WORD PTR es:[di],ax
     9b0:	09 10                	or     WORD PTR [bx+si],dx
     9b2:	54                   	push   sp
     9b3:	52                   	push   dx
     9b4:	65 73 6f             	gs jae 0xa26
     9b7:	75 72                	jne    0xa2b
     9b9:	63 65 4d             	arpl   WORD PTR [di+0x4d],sp
     9bc:	61                   	popa
     9bd:	6e                   	outs   dx,BYTE PTR ds:[si]
     9be:	61                   	popa
     9bf:	67 65 72 55          	addr32 gs jb 0xa18
     9c3:	89 e5                	mov    bp,sp
     9c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9c8:	8b 4e 04             	mov    cx,WORD PTR [bp+0x4]
     9cb:	31 c0                	xor    ax,ax
     9cd:	c1 c0 05             	rol    ax,0x5
     9d0:	26 32 05             	xor    al,BYTE PTR es:[di]
     9d3:	47                   	inc    di
     9d4:	e2 f7                	loop   0x9cd
     9d6:	c9                   	leave
     9d7:	c2 06 00             	ret    0x6
     9da:	55                   	push   bp
     9db:	89 e5                	mov    bp,sp
     9dd:	1e                   	push   ds
     9de:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
     9e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9e4:	8b 4e 04             	mov    cx,WORD PTR [bp+0x4]
     9e7:	31 c0                	xor    ax,ax
     9e9:	fc                   	cld
     9ea:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
     9ec:	75 01                	jne    0x9ef
     9ee:	40                   	inc    ax
     9ef:	1f                   	pop    ds
     9f0:	c9                   	leave
     9f1:	c2 0a 00             	ret    0xa
     9f4:	55                   	push   bp
     9f5:	89 e5                	mov    bp,sp
     9f7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     9fb:	74 08                	je     0xa05
     9fd:	83 ec 08             	sub    sp,0x8
     a00:	9a e2 1f a5 0a       	call   0xaa5:0x1fe2
     a05:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     a08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a0b:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     a0f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     a13:	74 07                	je     0xa1c
     a15:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     a19:	83 c4 06             	add    sp,0x6
     a1c:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     a1f:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     a22:	c9                   	leave
     a23:	ca 08 00             	retf   0x8
     a26:	c8 0a 00 00          	enter  0xa,0x0
     a2a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     a2d:	06                   	push   es
     a2e:	57                   	push   di
     a2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a32:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
     a36:	e8 89 ff             	call   0x9c2
     a39:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     a3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a3f:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     a43:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
     a47:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     a4a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     a4d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     a50:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
     a53:	74 3a                	je     0xa8f
     a55:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     a58:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     a5c:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
     a5f:	75 1c                	jne    0xa7d
     a61:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     a64:	81 c7 0a 00          	add    di,0xa
     a68:	06                   	push   es
     a69:	57                   	push   di
     a6a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     a6d:	06                   	push   es
     a6e:	57                   	push   di
     a6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a72:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
     a76:	e8 61 ff             	call   0x9da
     a79:	08 c0                	or     al,al
     a7b:	75 12                	jne    0xa8f
     a7d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     a80:	26 8b 05             	mov    ax,WORD PTR es:[di]
     a83:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     a87:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     a8a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     a8d:	eb be                	jmp    0xa4d
     a8f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     a92:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
     a95:	75 79                	jne    0xb10
     a97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a9a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     a9e:	05 0a 00             	add    ax,0xa
     aa1:	50                   	push   ax
     aa2:	9a 82 01 fd 0a       	call   0xafd:0x182
     aa7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     aaa:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     aad:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     ab0:	89 7e f6             	mov    WORD PTR [bp-0xa],di
     ab3:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
     ab6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ab9:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     abd:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
     ac1:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     ac4:	26 89 05             	mov    WORD PTR es:[di],ax
     ac7:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     acb:	31 c0                	xor    ax,ax
     acd:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     ad1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     ad4:	26 8b 05             	mov    ax,WORD PTR es:[di]
     ad7:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     ada:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
     ade:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     ae1:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     ae5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     ae8:	06                   	push   es
     ae9:	57                   	push   di
     aea:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     aed:	81 c7 0a 00          	add    di,0xa
     af1:	06                   	push   es
     af2:	57                   	push   di
     af3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     af6:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
     afa:	9a c1 1e dc 0b       	call   0xbdc:0x1ec1
     aff:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b02:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     b05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b08:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     b0c:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     b10:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     b13:	26 ff 45 04          	inc    WORD PTR es:[di+0x4]
     b17:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b1a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     b1d:	c9                   	leave
     b1e:	ca 08 00             	retf   0x8
     b21:	c8 08 00 00          	enter  0x8,0x0
     b25:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     b28:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
     b2b:	75 03                	jne    0xb30
     b2d:	e9 ae 00             	jmp    0xbde
     b30:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     b33:	26 ff 4d 04          	dec    WORD PTR es:[di+0x4]
     b37:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
     b3c:	74 03                	je     0xb41
     b3e:	e9 9d 00             	jmp    0xbde
     b41:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
     b46:	74 09                	je     0xb51
     b48:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     b4c:	9a 20 0d 00 00       	call   0x0:0xd20
     b51:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     b54:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
     b57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b5a:	26 3b 55 06          	cmp    dx,WORD PTR es:[di+0x6]
     b5e:	75 1d                	jne    0xb7d
     b60:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
     b64:	75 17                	jne    0xb7d
     b66:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     b69:	26 8b 05             	mov    ax,WORD PTR es:[di]
     b6c:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     b70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b73:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     b77:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     b7b:	eb 4b                	jmp    0xbc8
     b7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b80:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     b84:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
     b88:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b8b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     b8e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     b91:	26 8b 05             	mov    ax,WORD PTR es:[di]
     b94:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     b98:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
     b9b:	75 05                	jne    0xba2
     b9d:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
     ba0:	74 12                	je     0xbb4
     ba2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     ba5:	26 8b 05             	mov    ax,WORD PTR es:[di]
     ba8:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     bac:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     baf:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     bb2:	eb da                	jmp    0xb8e
     bb4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     bb7:	26 8b 05             	mov    ax,WORD PTR es:[di]
     bba:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     bbe:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     bc1:	26 89 05             	mov    WORD PTR es:[di],ax
     bc4:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     bc8:	ff 76 0c             	push   WORD PTR [bp+0xc]
     bcb:	ff 76 0a             	push   WORD PTR [bp+0xa]
     bce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bd1:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     bd5:	05 0a 00             	add    ax,0xa
     bd8:	50                   	push   ax
     bd9:	9a 9c 01 31 0c       	call   0xc31:0x19c
     bde:	c9                   	leave
     bdf:	ca 08 00             	retf   0x8
     be2:	c8 04 00 00          	enter  0x4,0x0
     be6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     be9:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     bed:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
     bf1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     bf4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     bf7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     bfa:	06                   	push   es
     bfb:	57                   	push   di
     bfc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bff:	06                   	push   es
     c00:	57                   	push   di
     c01:	9a 26 0a 41 0c       	call   0xc41:0xa26
     c06:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     c09:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
     c0d:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
     c11:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     c14:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     c18:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
     c1c:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
     c1f:	75 05                	jne    0xc26
     c21:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     c24:	74 0d                	je     0xc33
     c26:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     c29:	06                   	push   es
     c2a:	57                   	push   di
     c2b:	b8 ff ff             	mov    ax,0xffff
     c2e:	9a 6a 20 8f 0c       	call   0xc8f:0x206a
     c33:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c36:	ff 76 fc             	push   WORD PTR [bp-0x4]
     c39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c3c:	06                   	push   es
     c3d:	57                   	push   di
     c3e:	9a 21 0b 9f 0c       	call   0xc9f:0xb21
     c43:	c9                   	leave
     c44:	ca 0c 00             	retf   0xc
     c47:	c8 04 00 00          	enter  0x4,0x0
     c4b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     c4e:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     c52:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
     c56:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c59:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     c5c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     c5f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     c62:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
     c65:	75 05                	jne    0xc6c
     c67:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
     c6a:	74 35                	je     0xca1
     c6c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     c6f:	26 ff 45 04          	inc    WORD PTR es:[di+0x4]
     c73:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     c76:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
     c79:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     c7c:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
     c80:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
     c84:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     c87:	06                   	push   es
     c88:	57                   	push   di
     c89:	b8 ff ff             	mov    ax,0xffff
     c8c:	9a 6a 20 f7 0d       	call   0xdf7:0x206a
     c91:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c94:	ff 76 fc             	push   WORD PTR [bp-0x4]
     c97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c9a:	06                   	push   es
     c9b:	57                   	push   di
     c9c:	9a 21 0b 79 0d       	call   0xd79:0xb21
     ca1:	c9                   	leave
     ca2:	ca 0c 00             	retf   0xc
     ca5:	c8 04 00 00          	enter  0x4,0x0
     ca9:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     cac:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     caf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cb2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     cb5:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
     cb9:	7c 08                	jl     0xcc3
     cbb:	7f 25                	jg     0xce2
     cbd:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     cc1:	73 1f                	jae    0xce2
     cc3:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     cc6:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     cc9:	f7 d2                	not    dx
     ccb:	f7 d8                	neg    ax
     ccd:	83 da ff             	sbb    dx,0xffff
     cd0:	2d 01 00             	sub    ax,0x1
     cd3:	83 da 00             	sbb    dx,0x0
     cd6:	50                   	push   ax
     cd7:	9a ff ff 00 00       	call   0x0:0xffff
     cdc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cdf:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     ce2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     ce5:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     ce8:	c9                   	leave
     ce9:	ca 04 00             	retf   0x4
     cec:	c8 04 00 00          	enter  0x4,0x0
     cf0:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     cf3:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
     cf6:	74 47                	je     0xd3f
     cf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cfb:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     cfe:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     d01:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
     d06:	74 25                	je     0xd2d
     d08:	26 83 7d 0e 00       	cmp    WORD PTR es:[di+0xe],0x0
     d0d:	7c 09                	jl     0xd18
     d0f:	7f 1c                	jg     0xd2d
     d11:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
     d16:	73 15                	jae    0xd2d
     d18:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     d1b:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     d1f:	9a ca 30 00 00       	call   0x0:0x30ca
     d24:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     d27:	31 c0                	xor    ax,ax
     d29:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
     d2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d30:	26 8b 05             	mov    ax,WORD PTR es:[di]
     d33:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     d37:	89 46 06             	mov    WORD PTR [bp+0x6],ax
     d3a:	89 56 08             	mov    WORD PTR [bp+0x8],dx
     d3d:	eb b1                	jmp    0xcf0
     d3f:	c9                   	leave
     d40:	c2 06 00             	ret    0x6
     d43:	c8 04 00 00          	enter  0x4,0x0
     d47:	c4 3e 2c 2b          	les    di,DWORD PTR ds:0x2b2c
     d4b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     d4f:	48                   	dec    ax
     d50:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d53:	31 c0                	xor    ax,ax
     d55:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     d58:	7f 29                	jg     0xd83
     d5a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     d5d:	eb 03                	jmp    0xd62
     d5f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     d62:	ff 76 fe             	push   WORD PTR [bp-0x2]
     d65:	c4 3e 2c 2b          	les    di,DWORD PTR ds:0x2b2c
     d69:	06                   	push   es
     d6a:	57                   	push   di
     d6b:	9a d0 0d 94 0f       	call   0xf94:0xdd0
     d70:	89 c7                	mov    di,ax
     d72:	8e c2                	mov    es,dx
     d74:	06                   	push   es
     d75:	57                   	push   di
     d76:	9a ff 21 b5 0e       	call   0xeb5:0x21ff
     d7b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     d7e:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     d81:	75 dc                	jne    0xd5f
     d83:	c4 3e 24 2b          	les    di,DWORD PTR ds:0x2b24
     d87:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     d8b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     d8f:	55                   	push   bp
     d90:	e8 59 ff             	call   0xcec
     d93:	c4 3e 28 2b          	les    di,DWORD PTR ds:0x2b28
     d97:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     d9b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     d9f:	55                   	push   bp
     da0:	e8 49 ff             	call   0xcec
     da3:	c9                   	leave
     da4:	cb                   	retf
     da5:	c8 04 01 00          	enter  0x104,0x0
     da9:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     dad:	31 c0                	xor    ax,ax
     daf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     db2:	eb 03                	jmp    0xdb7
     db4:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     db7:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
     dba:	c1 e7 03             	shl    di,0x3
     dbd:	8b 85 82 0f          	mov    ax,WORD PTR [di+0xf82]
     dc1:	8b 95 84 0f          	mov    dx,WORD PTR [di+0xf84]
     dc5:	3b 56 0e             	cmp    dx,WORD PTR [bp+0xe]
     dc8:	75 31                	jne    0xdfb
     dca:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
     dcd:	75 2c                	jne    0xdfb
     dcf:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     dd3:	8d be fc fe          	lea    di,[bp-0x104]
     dd7:	16                   	push   ss
     dd8:	57                   	push   di
     dd9:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
     ddc:	c1 e7 03             	shl    di,0x3
     ddf:	ff b5 88 0f          	push   WORD PTR [di+0xf88]
     de3:	ff b5 86 0f          	push   WORD PTR [di+0xf86]
     de7:	9a 6e 0e 1f 0e       	call   0xe1f:0xe6e
     dec:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     def:	06                   	push   es
     df0:	57                   	push   di
     df1:	ff 76 06             	push   WORD PTR [bp+0x6]
     df4:	9a e7 17 a5 0e       	call   0xea5:0x17e7
     df9:	eb 06                	jmp    0xe01
     dfb:	83 7e fc 24          	cmp    WORD PTR [bp-0x4],0x24
     dff:	75 b3                	jne    0xdb4
     e01:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     e04:	c9                   	leave
     e05:	ca 0a 00             	retf   0xa
     e08:	c8 44 00 00          	enter  0x44,0x0
     e0c:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     e10:	8d 7e bc             	lea    di,[bp-0x44]
     e13:	16                   	push   ss
     e14:	57                   	push   di
     e15:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     e18:	06                   	push   es
     e19:	57                   	push   di
     e1a:	6a 3f                	push   0x3f
     e1c:	9a 6a 0d 41 0e       	call   0xe41:0xd6a
     e21:	31 c0                	xor    ax,ax
     e23:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     e26:	eb 03                	jmp    0xe2b
     e28:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     e2b:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
     e2e:	c1 e7 03             	shl    di,0x3
     e31:	ff b5 88 0f          	push   WORD PTR [di+0xf88]
     e35:	ff b5 86 0f          	push   WORD PTR [di+0xf86]
     e39:	8d 7e bc             	lea    di,[bp-0x44]
     e3c:	16                   	push   ss
     e3d:	57                   	push   di
     e3e:	9a db 0d 99 10       	call   0x1099:0xddb
     e43:	09 c0                	or     ax,ax
     e45:	75 1e                	jne    0xe65
     e47:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     e4b:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
     e4e:	c1 e7 03             	shl    di,0x3
     e51:	8b 85 82 0f          	mov    ax,WORD PTR [di+0xf82]
     e55:	8b 95 84 0f          	mov    dx,WORD PTR [di+0xf84]
     e59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e5c:	26 89 05             	mov    WORD PTR es:[di],ax
     e5f:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
     e63:	eb 06                	jmp    0xe6b
     e65:	83 7e fc 24          	cmp    WORD PTR [bp-0x4],0x24
     e69:	75 bd                	jne    0xe28
     e6b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     e6e:	c9                   	leave
     e6f:	ca 08 00             	retf   0x8
     e72:	55                   	push   bp
     e73:	89 e5                	mov    bp,sp
     e75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e78:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
     e7c:	09 c0                	or     ax,ax
     e7e:	74 12                	je     0xe92
     e80:	ff 76 08             	push   WORD PTR [bp+0x8]
     e83:	ff 76 06             	push   WORD PTR [bp+0x6]
     e86:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
     e8a:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
     e8e:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
     e92:	c9                   	leave
     e93:	ca 04 00             	retf   0x4
     e96:	55                   	push   bp
     e97:	89 e5                	mov    bp,sp
     e99:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     e9d:	74 08                	je     0xea7
     e9f:	83 ec 08             	sub    sp,0x8
     ea2:	9a e2 1f 0e 0f       	call   0xf0e:0x1fe2
     ea7:	bf 42 12             	mov    di,0x1242
     eaa:	1e                   	push   ds
     eab:	57                   	push   di
     eac:	c4 3e 20 2b          	les    di,DWORD PTR ds:0x2b20
     eb0:	06                   	push   es
     eb1:	57                   	push   di
     eb2:	9a 26 0a 03 0f       	call   0xf03:0xa26
     eb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eba:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
     ebe:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
     ec2:	26 c7 45 10 f7 ff    	mov    WORD PTR es:[di+0x10],0xfff7
     ec8:	26 c7 45 12 ff ff    	mov    WORD PTR es:[di+0x12],0xffff
     ece:	a1 16 2b             	mov    ax,ds:0x2b16
     ed1:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
     ed5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     ed9:	74 07                	je     0xee2
     edb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     edf:	83 c4 06             	add    sp,0x6
     ee2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     ee5:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     ee8:	c9                   	leave
     ee9:	ca 06 00             	retf   0x6
     eec:	55                   	push   bp
     eed:	89 e5                	mov    bp,sp
     eef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ef2:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
     ef6:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
     efa:	c4 3e 20 2b          	les    di,DWORD PTR ds:0x2b20
     efe:	06                   	push   es
     eff:	57                   	push   di
     f00:	9a 21 0b 21 0f       	call   0xf21:0xb21
     f05:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     f09:	74 05                	je     0xf10
     f0b:	9a 0f 20 28 0f       	call   0xf28:0x200f
     f10:	c9                   	leave
     f11:	ca 06 00             	retf   0x6
     f14:	55                   	push   bp
     f15:	89 e5                	mov    bp,sp
     f17:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f1a:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f1d:	bf 10 03             	mov    di,0x310
     f20:	b8 48 0f             	mov    ax,0xf48
     f23:	50                   	push   ax
     f24:	57                   	push   di
     f25:	9a 55 22 b4 0f       	call   0xfb4:0x2255
     f2a:	08 c0                	or     al,al
     f2c:	74 58                	je     0xf86
     f2e:	ff 76 08             	push   WORD PTR [bp+0x8]
     f31:	ff 76 06             	push   WORD PTR [bp+0x6]
     f34:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f37:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
     f3b:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
     f3f:	c4 3e 20 2b          	les    di,DWORD PTR ds:0x2b20
     f43:	06                   	push   es
     f44:	57                   	push   di
     f45:	9a 47 0c 5d 0f       	call   0xf5d:0xc47
     f4a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f4d:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
     f51:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     f55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f58:	06                   	push   es
     f59:	57                   	push   di
     f5a:	9a df 0f 77 0f       	call   0xf77:0xfdf
     f5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f62:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
     f66:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f69:	26 3b 45 14          	cmp    ax,WORD PTR es:[di+0x14]
     f6d:	74 15                	je     0xf84
     f6f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f72:	06                   	push   es
     f73:	57                   	push   di
     f74:	9a cc 11 82 0f       	call   0xf82:0x11cc
     f79:	50                   	push   ax
     f7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f7d:	06                   	push   es
     f7e:	57                   	push   di
     f7f:	9a f5 11 d9 0f       	call   0xfd9:0x11f5
     f84:	eb 10                	jmp    0xf96
     f86:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f89:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f8f:	06                   	push   es
     f90:	57                   	push   di
     f91:	9a fa 10 6c 13       	call   0x136c:0x10fa
     f96:	c9                   	leave
     f97:	ca 08 00             	retf   0x8
     f9a:	55                   	push   bp
     f9b:	89 e5                	mov    bp,sp
     f9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fa0:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
     fa4:	81 c7 0a 00          	add    di,0xa
     fa8:	06                   	push   es
     fa9:	57                   	push   di
     faa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     fad:	06                   	push   es
     fae:	57                   	push   di
     faf:	6a 26                	push   0x26
     fb1:	9a 1b 16 10 10       	call   0x1010:0x161b
     fb6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     fb9:	31 c0                	xor    ax,ax
     fbb:	26 89 05             	mov    WORD PTR es:[di],ax
     fbe:	c9                   	leave
     fbf:	ca 08 00             	retf   0x8
     fc2:	55                   	push   bp
     fc3:	89 e5                	mov    bp,sp
     fc5:	ff 76 08             	push   WORD PTR [bp+0x8]
     fc8:	ff 76 06             	push   WORD PTR [bp+0x6]
     fcb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     fce:	06                   	push   es
     fcf:	57                   	push   di
     fd0:	c4 3e 20 2b          	les    di,DWORD PTR ds:0x2b20
     fd4:	06                   	push   es
     fd5:	57                   	push   di
     fd6:	9a e2 0b af 10       	call   0x10af:0xbe2
     fdb:	c9                   	leave
     fdc:	ca 08 00             	retf   0x8
     fdf:	55                   	push   bp
     fe0:	89 e5                	mov    bp,sp
     fe2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fe5:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
     fe9:	26 8b 55 12          	mov    dx,WORD PTR es:[di+0x12]
     fed:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
     ff0:	75 05                	jne    0xff7
     ff2:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
     ff5:	74 1b                	je     0x1012
     ff7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     ffa:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
     ffd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1000:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    1004:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    1008:	06                   	push   es
    1009:	57                   	push   di
    100a:	b8 ff ff             	mov    ax,0xffff
    100d:	9a 6a 20 fe 10       	call   0x10fe:0x206a
    1012:	c9                   	leave
    1013:	ca 08 00             	retf   0x8
    1016:	c8 38 00 00          	enter  0x38,0x0
    101a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    101d:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1021:	89 7e c8             	mov    WORD PTR [bp-0x38],di
    1024:	8c 46 ca             	mov    WORD PTR [bp-0x36],es
    1027:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    102c:	74 03                	je     0x1031
    102e:	e9 a9 00             	jmp    0x10da
    1031:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1035:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    1038:	31 c0                	xor    ax,ax
    103a:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    103d:	31 c0                	xor    ax,ax
    103f:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    1042:	31 c0                	xor    ax,ax
    1044:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    1047:	26 f6 45 0f 01       	test   BYTE PTR es:[di+0xf],0x1
    104c:	74 07                	je     0x1055
    104e:	c7 46 d4 bc 02       	mov    WORD PTR [bp-0x2c],0x2bc
    1053:	eb 05                	jmp    0x105a
    1055:	c7 46 d4 90 01       	mov    WORD PTR [bp-0x2c],0x190
    105a:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    105d:	26 f6 45 0f 02       	test   BYTE PTR es:[di+0xf],0x2
    1062:	b0 00                	mov    al,0x0
    1064:	74 01                	je     0x1067
    1066:	40                   	inc    ax
    1067:	88 46 d6             	mov    BYTE PTR [bp-0x2a],al
    106a:	26 f6 45 0f 04       	test   BYTE PTR es:[di+0xf],0x4
    106f:	b0 00                	mov    al,0x0
    1071:	74 01                	je     0x1074
    1073:	40                   	inc    ax
    1074:	88 46 d7             	mov    BYTE PTR [bp-0x29],al
    1077:	26 f6 45 0f 08       	test   BYTE PTR es:[di+0xf],0x8
    107c:	b0 00                	mov    al,0x0
    107e:	74 01                	je     0x1081
    1080:	40                   	inc    ax
    1081:	88 46 d8             	mov    BYTE PTR [bp-0x28],al
    1084:	c6 46 d9 01          	mov    BYTE PTR [bp-0x27],0x1
    1088:	8d 7e de             	lea    di,[bp-0x22]
    108b:	16                   	push   ss
    108c:	57                   	push   di
    108d:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    1090:	81 c7 10 00          	add    di,0x10
    1094:	06                   	push   es
    1095:	57                   	push   di
    1096:	9a 4c 0d 00 23       	call   0x2300:0xd4c
    109b:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
    109f:	c6 46 da 00          	mov    BYTE PTR [bp-0x26],0x0
    10a3:	c6 46 db 00          	mov    BYTE PTR [bp-0x25],0x0
    10a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10aa:	06                   	push   es
    10ab:	57                   	push   di
    10ac:	9a 5f 12 13 11       	call   0x1113:0x125f
    10b1:	3c 01                	cmp    al,0x1
    10b3:	75 06                	jne    0x10bb
    10b5:	c6 46 dd 02          	mov    BYTE PTR [bp-0x23],0x2
    10b9:	eb 0e                	jmp    0x10c9
    10bb:	3c 02                	cmp    al,0x2
    10bd:	75 06                	jne    0x10c5
    10bf:	c6 46 dd 01          	mov    BYTE PTR [bp-0x23],0x1
    10c3:	eb 04                	jmp    0x10c9
    10c5:	c6 46 dd 00          	mov    BYTE PTR [bp-0x23],0x0
    10c9:	8d 7e cc             	lea    di,[bp-0x34]
    10cc:	16                   	push   ss
    10cd:	57                   	push   di
    10ce:	9a ff ff 00 00       	call   0x0:0xffff
    10d3:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    10d6:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    10da:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    10dd:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    10e1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    10e4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    10e7:	c9                   	leave
    10e8:	ca 04 00             	retf   0x4
    10eb:	c8 26 00 00          	enter  0x26,0x0
    10ef:	bf 42 12             	mov    di,0x1242
    10f2:	1e                   	push   ds
    10f3:	57                   	push   di
    10f4:	8d 7e da             	lea    di,[bp-0x26]
    10f7:	16                   	push   ss
    10f8:	57                   	push   di
    10f9:	6a 26                	push   0x26
    10fb:	9a 1b 16 78 11       	call   0x1178:0x161b
    1100:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1103:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    1106:	8d 7e da             	lea    di,[bp-0x26]
    1109:	16                   	push   ss
    110a:	57                   	push   di
    110b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    110e:	06                   	push   es
    110f:	57                   	push   di
    1110:	9a c2 0f 43 11       	call   0x1143:0xfc2
    1115:	c9                   	leave
    1116:	ca 06 00             	retf   0x6
    1119:	c8 02 00 00          	enter  0x2,0x0
    111d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1120:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1124:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1128:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    112b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    112e:	c9                   	leave
    112f:	ca 04 00             	retf   0x4
    1132:	c8 26 00 00          	enter  0x26,0x0
    1136:	8d 7e da             	lea    di,[bp-0x26]
    1139:	16                   	push   ss
    113a:	57                   	push   di
    113b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    113e:	06                   	push   es
    113f:	57                   	push   di
    1140:	9a 9a 0f 58 11       	call   0x1158:0xf9a
    1145:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1148:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    114b:	8d 7e da             	lea    di,[bp-0x26]
    114e:	16                   	push   ss
    114f:	57                   	push   di
    1150:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1153:	06                   	push   es
    1154:	57                   	push   di
    1155:	9a c2 0f 98 11       	call   0x1198:0xfc2
    115a:	c9                   	leave
    115b:	ca 06 00             	retf   0x6
    115e:	55                   	push   bp
    115f:	89 e5                	mov    bp,sp
    1161:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1164:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1168:	81 c7 10 00          	add    di,0x10
    116c:	06                   	push   es
    116d:	57                   	push   di
    116e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1171:	06                   	push   es
    1172:	57                   	push   di
    1173:	6a 1f                	push   0x1f
    1175:	9a e7 17 a6 11       	call   0x11a6:0x17e7
    117a:	c9                   	leave
    117b:	ca 04 00             	retf   0x4
    117e:	c8 26 00 00          	enter  0x26,0x0
    1182:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1185:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1189:	74 3d                	je     0x11c8
    118b:	8d 7e da             	lea    di,[bp-0x26]
    118e:	16                   	push   ss
    118f:	57                   	push   di
    1190:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1193:	06                   	push   es
    1194:	57                   	push   di
    1195:	9a 9a 0f c6 11       	call   0x11c6:0xf9a
    119a:	8d 7e e0             	lea    di,[bp-0x20]
    119d:	16                   	push   ss
    119e:	57                   	push   di
    119f:	6a 20                	push   0x20
    11a1:	6a 00                	push   0x0
    11a3:	9a e5 1e b7 11       	call   0x11b7:0x1ee5
    11a8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    11ab:	06                   	push   es
    11ac:	57                   	push   di
    11ad:	8d 7e e0             	lea    di,[bp-0x20]
    11b0:	16                   	push   ss
    11b1:	57                   	push   di
    11b2:	6a 1f                	push   0x1f
    11b4:	9a e7 17 b3 12       	call   0x12b3:0x17e7
    11b9:	8d 7e da             	lea    di,[bp-0x26]
    11bc:	16                   	push   ss
    11bd:	57                   	push   di
    11be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11c1:	06                   	push   es
    11c2:	57                   	push   di
    11c3:	9a c2 0f d8 11       	call   0x11d8:0xfc2
    11c8:	c9                   	leave
    11c9:	ca 08 00             	retf   0x8
    11cc:	c8 02 00 00          	enter  0x2,0x0
    11d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11d3:	06                   	push   es
    11d4:	57                   	push   di
    11d5:	9a 19 11 14 12       	call   0x1214:0x1119
    11da:	50                   	push   ax
    11db:	6a 48                	push   0x48
    11dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11e0:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    11e4:	9a 05 12 00 00       	call   0x0:0x1205
    11e9:	f7 d8                	neg    ax
    11eb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    11ee:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    11f1:	c9                   	leave
    11f2:	ca 04 00             	retf   0x4
    11f5:	55                   	push   bp
    11f6:	89 e5                	mov    bp,sp
    11f8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    11fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11fe:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    1202:	6a 48                	push   0x48
    1204:	9a 75 4a 00 00       	call   0x0:0x4a75
    1209:	f7 d8                	neg    ax
    120b:	50                   	push   ax
    120c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    120f:	06                   	push   es
    1210:	57                   	push   di
    1211:	9a 32 11 44 12       	call   0x1244:0x1132
    1216:	c9                   	leave
    1217:	ca 06 00             	retf   0x6
    121a:	c8 02 00 00          	enter  0x2,0x0
    121e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1221:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1225:	26 8a 45 0f          	mov    al,BYTE PTR es:[di+0xf]
    1229:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    122c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    122f:	c9                   	leave
    1230:	ca 04 00             	retf   0x4
    1233:	c8 26 00 00          	enter  0x26,0x0
    1237:	8d 7e da             	lea    di,[bp-0x26]
    123a:	16                   	push   ss
    123b:	57                   	push   di
    123c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    123f:	06                   	push   es
    1240:	57                   	push   di
    1241:	9a 9a 0f 59 12       	call   0x1259:0xf9a
    1246:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1249:	88 46 df             	mov    BYTE PTR [bp-0x21],al
    124c:	8d 7e da             	lea    di,[bp-0x26]
    124f:	16                   	push   ss
    1250:	57                   	push   di
    1251:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1254:	06                   	push   es
    1255:	57                   	push   di
    1256:	9a c2 0f 89 12       	call   0x1289:0xfc2
    125b:	c9                   	leave
    125c:	ca 06 00             	retf   0x6
    125f:	c8 02 00 00          	enter  0x2,0x0
    1263:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1266:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    126a:	26 8a 45 0e          	mov    al,BYTE PTR es:[di+0xe]
    126e:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1271:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1274:	c9                   	leave
    1275:	ca 04 00             	retf   0x4
    1278:	c8 26 00 00          	enter  0x26,0x0
    127c:	8d 7e da             	lea    di,[bp-0x26]
    127f:	16                   	push   ss
    1280:	57                   	push   di
    1281:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1284:	06                   	push   es
    1285:	57                   	push   di
    1286:	9a 9a 0f 9e 12       	call   0x129e:0xf9a
    128b:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    128e:	88 46 de             	mov    BYTE PTR [bp-0x22],al
    1291:	8d 7e da             	lea    di,[bp-0x26]
    1294:	16                   	push   ss
    1295:	57                   	push   di
    1296:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1299:	06                   	push   es
    129a:	57                   	push   di
    129b:	9a c2 0f c3 12       	call   0x12c3:0xfc2
    12a0:	c9                   	leave
    12a1:	ca 06 00             	retf   0x6
    12a4:	55                   	push   bp
    12a5:	89 e5                	mov    bp,sp
    12a7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    12ab:	74 08                	je     0x12b5
    12ad:	83 ec 08             	sub    sp,0x8
    12b0:	9a e2 1f 0e 13       	call   0x130e:0x1fe2
    12b5:	bf 68 12             	mov    di,0x1268
    12b8:	1e                   	push   ds
    12b9:	57                   	push   di
    12ba:	c4 3e 24 2b          	les    di,DWORD PTR ds:0x2b24
    12be:	06                   	push   es
    12bf:	57                   	push   di
    12c0:	9a 26 0a 03 13       	call   0x1303:0xa26
    12c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12c8:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    12cc:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    12d0:	26 c6 45 10 04       	mov    BYTE PTR es:[di+0x10],0x4
    12d5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    12d9:	74 07                	je     0x12e2
    12db:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    12df:	83 c4 06             	add    sp,0x6
    12e2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    12e5:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    12e8:	c9                   	leave
    12e9:	ca 06 00             	retf   0x6
    12ec:	55                   	push   bp
    12ed:	89 e5                	mov    bp,sp
    12ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12f2:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    12f6:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    12fa:	c4 3e 24 2b          	les    di,DWORD PTR ds:0x2b24
    12fe:	06                   	push   es
    12ff:	57                   	push   di
    1300:	9a 21 0b 21 13       	call   0x1321:0xb21
    1305:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1309:	74 05                	je     0x1310
    130b:	9a 0f 20 28 13       	call   0x1328:0x200f
    1310:	c9                   	leave
    1311:	ca 06 00             	retf   0x6
    1314:	55                   	push   bp
    1315:	89 e5                	mov    bp,sp
    1317:	ff 76 0c             	push   WORD PTR [bp+0xc]
    131a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    131d:	bf 11 04             	mov    di,0x411
    1320:	b8 48 13             	mov    ax,0x1348
    1323:	50                   	push   ax
    1324:	57                   	push   di
    1325:	9a 55 22 8c 13       	call   0x138c:0x2255
    132a:	08 c0                	or     al,al
    132c:	74 30                	je     0x135e
    132e:	ff 76 08             	push   WORD PTR [bp+0x8]
    1331:	ff 76 06             	push   WORD PTR [bp+0x6]
    1334:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1337:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    133b:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    133f:	c4 3e 24 2b          	les    di,DWORD PTR ds:0x2b24
    1343:	06                   	push   es
    1344:	57                   	push   di
    1345:	9a 47 0c 5a 13       	call   0x135a:0xc47
    134a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    134d:	26 8a 45 10          	mov    al,BYTE PTR es:[di+0x10]
    1351:	50                   	push   ax
    1352:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1355:	06                   	push   es
    1356:	57                   	push   di
    1357:	9a 73 14 b1 13       	call   0x13b1:0x1473
    135c:	eb 10                	jmp    0x136e
    135e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1361:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1364:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1367:	06                   	push   es
    1368:	57                   	push   di
    1369:	9a fa 10 d8 15       	call   0x15d8:0x10fa
    136e:	c9                   	leave
    136f:	ca 08 00             	retf   0x8
    1372:	55                   	push   bp
    1373:	89 e5                	mov    bp,sp
    1375:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1378:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    137c:	81 c7 0a 00          	add    di,0xa
    1380:	06                   	push   es
    1381:	57                   	push   di
    1382:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1385:	06                   	push   es
    1386:	57                   	push   di
    1387:	6a 09                	push   0x9
    1389:	9a 1b 16 91 14       	call   0x1491:0x161b
    138e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1391:	31 c0                	xor    ax,ax
    1393:	26 89 05             	mov    WORD PTR es:[di],ax
    1396:	c9                   	leave
    1397:	ca 08 00             	retf   0x8
    139a:	55                   	push   bp
    139b:	89 e5                	mov    bp,sp
    139d:	ff 76 08             	push   WORD PTR [bp+0x8]
    13a0:	ff 76 06             	push   WORD PTR [bp+0x6]
    13a3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    13a6:	06                   	push   es
    13a7:	57                   	push   di
    13a8:	c4 3e 24 2b          	les    di,DWORD PTR ds:0x2b24
    13ac:	06                   	push   es
    13ad:	57                   	push   di
    13ae:	9a e2 0b eb 13       	call   0x13eb:0xbe2
    13b3:	c9                   	leave
    13b4:	ca 08 00             	retf   0x8
    13b7:	c8 04 00 00          	enter  0x4,0x0
    13bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13be:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    13c2:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    13c6:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    13ca:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    13cd:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    13d0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    13d3:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    13d6:	c9                   	leave
    13d7:	ca 04 00             	retf   0x4
    13da:	c8 0a 00 00          	enter  0xa,0x0
    13de:	8d 7e f6             	lea    di,[bp-0xa]
    13e1:	16                   	push   ss
    13e2:	57                   	push   di
    13e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e6:	06                   	push   es
    13e7:	57                   	push   di
    13e8:	9a 72 13 06 14       	call   0x1406:0x1372
    13ed:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    13f0:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    13f3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    13f6:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    13f9:	8d 7e f6             	lea    di,[bp-0xa]
    13fc:	16                   	push   ss
    13fd:	57                   	push   di
    13fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1401:	06                   	push   es
    1402:	57                   	push   di
    1403:	9a 9a 13 49 14       	call   0x1449:0x139a
    1408:	c9                   	leave
    1409:	ca 08 00             	retf   0x8
    140c:	c8 10 00 00          	enter  0x10,0x0
    1410:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1413:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1417:	89 7e f0             	mov    WORD PTR [bp-0x10],di
    141a:	8c 46 f2             	mov    WORD PTR [bp-0xe],es
    141d:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    1422:	75 3e                	jne    0x1462
    1424:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    1428:	98                   	cbw
    1429:	8b f8                	mov    di,ax
    142b:	d1 e7                	shl    di,1
    142d:	8b 85 72 12          	mov    ax,WORD PTR [di+0x1272]
    1431:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1434:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    1437:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    143b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    143e:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1442:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1446:	9a a5 0c c1 14       	call   0x14c1:0xca5
    144b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    144e:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1451:	8d 7e f4             	lea    di,[bp-0xc]
    1454:	16                   	push   ss
    1455:	57                   	push   di
    1456:	9a ff ff 00 00       	call   0x0:0xffff
    145b:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    145e:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    1462:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    1465:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1469:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    146c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    146f:	c9                   	leave
    1470:	ca 04 00             	retf   0x4
    1473:	55                   	push   bp
    1474:	89 e5                	mov    bp,sp
    1476:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1479:	26 8a 45 10          	mov    al,BYTE PTR es:[di+0x10]
    147d:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1480:	74 11                	je     0x1493
    1482:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1485:	26 88 45 10          	mov    BYTE PTR es:[di+0x10],al
    1489:	06                   	push   es
    148a:	57                   	push   di
    148b:	b8 ff ff             	mov    ax,0xffff
    148e:	9a 6a 20 36 15       	call   0x1536:0x206a
    1493:	c9                   	leave
    1494:	ca 06 00             	retf   0x6
    1497:	c8 02 00 00          	enter  0x2,0x0
    149b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    149e:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    14a2:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    14a6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    14a9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    14ac:	c9                   	leave
    14ad:	ca 04 00             	retf   0x4
    14b0:	c8 0a 00 00          	enter  0xa,0x0
    14b4:	8d 7e f6             	lea    di,[bp-0xa]
    14b7:	16                   	push   ss
    14b8:	57                   	push   di
    14b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14bc:	06                   	push   es
    14bd:	57                   	push   di
    14be:	9a 72 13 d6 14       	call   0x14d6:0x1372
    14c3:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    14c6:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    14c9:	8d 7e f6             	lea    di,[bp-0xa]
    14cc:	16                   	push   ss
    14cd:	57                   	push   di
    14ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14d1:	06                   	push   es
    14d2:	57                   	push   di
    14d3:	9a 9a 13 0c 15       	call   0x150c:0x139a
    14d8:	c9                   	leave
    14d9:	ca 06 00             	retf   0x6
    14dc:	c8 02 00 00          	enter  0x2,0x0
    14e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14e3:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    14e7:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    14eb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    14ee:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    14f1:	c9                   	leave
    14f2:	ca 04 00             	retf   0x4
    14f5:	c8 0a 00 00          	enter  0xa,0x0
    14f9:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    14fd:	7c 24                	jl     0x1523
    14ff:	8d 7e f6             	lea    di,[bp-0xa]
    1502:	16                   	push   ss
    1503:	57                   	push   di
    1504:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1507:	06                   	push   es
    1508:	57                   	push   di
    1509:	9a 72 13 21 15       	call   0x1521:0x1372
    150e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1511:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1514:	8d 7e f6             	lea    di,[bp-0xa]
    1517:	16                   	push   ss
    1518:	57                   	push   di
    1519:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    151c:	06                   	push   es
    151d:	57                   	push   di
    151e:	9a 9a 13 46 15       	call   0x1546:0x139a
    1523:	c9                   	leave
    1524:	ca 06 00             	retf   0x6
    1527:	55                   	push   bp
    1528:	89 e5                	mov    bp,sp
    152a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    152e:	74 08                	je     0x1538
    1530:	83 ec 08             	sub    sp,0x8
    1533:	9a e2 1f 8c 15       	call   0x158c:0x1fe2
    1538:	bf 80 12             	mov    di,0x1280
    153b:	1e                   	push   ds
    153c:	57                   	push   di
    153d:	c4 3e 28 2b          	les    di,DWORD PTR ds:0x2b28
    1541:	06                   	push   es
    1542:	57                   	push   di
    1543:	9a 26 0a 81 15       	call   0x1581:0xa26
    1548:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    154b:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    154f:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    1553:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1557:	74 07                	je     0x1560
    1559:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    155d:	83 c4 06             	add    sp,0x6
    1560:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1563:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1566:	c9                   	leave
    1567:	ca 06 00             	retf   0x6
    156a:	55                   	push   bp
    156b:	89 e5                	mov    bp,sp
    156d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1570:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1574:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1578:	c4 3e 28 2b          	les    di,DWORD PTR ds:0x2b28
    157c:	06                   	push   es
    157d:	57                   	push   di
    157e:	9a 21 0b 9f 15       	call   0x159f:0xb21
    1583:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1587:	74 05                	je     0x158e
    1589:	9a 0f 20 a6 15       	call   0x15a6:0x200f
    158e:	c9                   	leave
    158f:	ca 06 00             	retf   0x6
    1592:	55                   	push   bp
    1593:	89 e5                	mov    bp,sp
    1595:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1598:	ff 76 0a             	push   WORD PTR [bp+0xa]
    159b:	bf d4 04             	mov    di,0x4d4
    159e:	b8 c6 15             	mov    ax,0x15c6
    15a1:	50                   	push   ax
    15a2:	57                   	push   di
    15a3:	9a 55 22 f8 15       	call   0x15f8:0x2255
    15a8:	08 c0                	or     al,al
    15aa:	74 1e                	je     0x15ca
    15ac:	ff 76 08             	push   WORD PTR [bp+0x8]
    15af:	ff 76 06             	push   WORD PTR [bp+0x6]
    15b2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    15b5:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    15b9:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    15bd:	c4 3e 28 2b          	les    di,DWORD PTR ds:0x2b28
    15c1:	06                   	push   es
    15c2:	57                   	push   di
    15c3:	9a 47 0c 27 16       	call   0x1627:0xc47
    15c8:	eb 10                	jmp    0x15da
    15ca:	ff 76 0c             	push   WORD PTR [bp+0xc]
    15cd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    15d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15d3:	06                   	push   es
    15d4:	57                   	push   di
    15d5:	9a fa 10 9e 18       	call   0x189e:0x10fa
    15da:	c9                   	leave
    15db:	ca 08 00             	retf   0x8
    15de:	55                   	push   bp
    15df:	89 e5                	mov    bp,sp
    15e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15e4:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    15e8:	81 c7 0a 00          	add    di,0xa
    15ec:	06                   	push   es
    15ed:	57                   	push   di
    15ee:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    15f1:	06                   	push   es
    15f2:	57                   	push   di
    15f3:	6a 0b                	push   0xb
    15f5:	9a 1b 16 40 16       	call   0x1640:0x161b
    15fa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    15fd:	31 c0                	xor    ax,ax
    15ff:	26 89 05             	mov    WORD PTR es:[di],ax
    1602:	31 c0                	xor    ax,ax
    1604:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    1608:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    160c:	c9                   	leave
    160d:	ca 08 00             	retf   0x8
    1610:	55                   	push   bp
    1611:	89 e5                	mov    bp,sp
    1613:	ff 76 08             	push   WORD PTR [bp+0x8]
    1616:	ff 76 06             	push   WORD PTR [bp+0x6]
    1619:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    161c:	06                   	push   es
    161d:	57                   	push   di
    161e:	c4 3e 28 2b          	les    di,DWORD PTR ds:0x2b28
    1622:	06                   	push   es
    1623:	57                   	push   di
    1624:	9a e2 0b 5b 16       	call   0x165b:0xbe2
    1629:	c9                   	leave
    162a:	ca 08 00             	retf   0x8
    162d:	c8 0c 00 00          	enter  0xc,0x0
    1631:	bf 80 12             	mov    di,0x1280
    1634:	1e                   	push   ds
    1635:	57                   	push   di
    1636:	8d 7e f4             	lea    di,[bp-0xc]
    1639:	16                   	push   ss
    163a:	57                   	push   di
    163b:	6a 0b                	push   0xb
    163d:	9a 1b 16 c7 17       	call   0x17c7:0x161b
    1642:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1645:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    1648:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    164b:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    164e:	8d 7e f4             	lea    di,[bp-0xc]
    1651:	16                   	push   ss
    1652:	57                   	push   di
    1653:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1656:	06                   	push   es
    1657:	57                   	push   di
    1658:	9a 10 16 95 16       	call   0x1695:0x1610
    165d:	c9                   	leave
    165e:	ca 08 00             	retf   0x8
    1661:	c8 04 00 00          	enter  0x4,0x0
    1665:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1668:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    166c:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1670:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    1674:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1677:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    167a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    167d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1680:	c9                   	leave
    1681:	ca 04 00             	retf   0x4
    1684:	c8 0c 00 00          	enter  0xc,0x0
    1688:	8d 7e f4             	lea    di,[bp-0xc]
    168b:	16                   	push   ss
    168c:	57                   	push   di
    168d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1690:	06                   	push   es
    1691:	57                   	push   di
    1692:	9a de 15 ba 16       	call   0x16ba:0x15de
    1697:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    169a:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    169d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    16a0:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    16a3:	80 7e fe 01          	cmp    BYTE PTR [bp-0x2],0x1
    16a7:	75 04                	jne    0x16ad
    16a9:	c6 46 fe 00          	mov    BYTE PTR [bp-0x2],0x0
    16ad:	8d 7e f4             	lea    di,[bp-0xc]
    16b0:	16                   	push   ss
    16b1:	57                   	push   di
    16b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16b5:	06                   	push   es
    16b6:	57                   	push   di
    16b7:	9a 10 16 f0 16       	call   0x16f0:0x1610
    16bc:	c9                   	leave
    16bd:	ca 08 00             	retf   0x8
    16c0:	c8 0e 00 00          	enter  0xe,0x0
    16c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16c7:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    16cb:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    16ce:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    16d1:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    16d6:	75 7a                	jne    0x1752
    16d8:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    16dc:	26 0b 45 12          	or     ax,WORD PTR es:[di+0x12]
    16e0:	74 15                	je     0x16f7
    16e2:	c7 46 f6 03 00       	mov    WORD PTR [bp-0xa],0x3
    16e7:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    16eb:	06                   	push   es
    16ec:	57                   	push   di
    16ed:	9a 9e 5a 39 17       	call   0x1739:0x5a9e
    16f2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    16f5:	eb 34                	jmp    0x172b
    16f7:	31 c0                	xor    ax,ax
    16f9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    16fc:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    16ff:	26 8a 45 14          	mov    al,BYTE PTR es:[di+0x14]
    1703:	3c 00                	cmp    al,0x0
    1705:	75 07                	jne    0x170e
    1707:	31 c0                	xor    ax,ax
    1709:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    170c:	eb 1d                	jmp    0x172b
    170e:	3c 01                	cmp    al,0x1
    1710:	75 07                	jne    0x1719
    1712:	c7 46 f6 01 00       	mov    WORD PTR [bp-0xa],0x1
    1717:	eb 12                	jmp    0x172b
    1719:	c7 46 f6 02 00       	mov    WORD PTR [bp-0xa],0x2
    171e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1721:	26 8a 45 14          	mov    al,BYTE PTR es:[di+0x14]
    1725:	98                   	cbw
    1726:	48                   	dec    ax
    1727:	48                   	dec    ax
    1728:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    172b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    172e:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1732:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1736:	9a a5 0c 8d 17       	call   0x178d:0xca5
    173b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    173e:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1741:	8d 7e f6             	lea    di,[bp-0xa]
    1744:	16                   	push   ss
    1745:	57                   	push   di
    1746:	9a ff ff 00 00       	call   0x0:0xffff
    174b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    174e:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    1752:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1755:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1759:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    175c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    175f:	c9                   	leave
    1760:	ca 04 00             	retf   0x4
    1763:	c8 02 00 00          	enter  0x2,0x0
    1767:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    176a:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    176e:	26 8a 45 14          	mov    al,BYTE PTR es:[di+0x14]
    1772:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1775:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1778:	c9                   	leave
    1779:	ca 04 00             	retf   0x4
    177c:	c8 0c 00 00          	enter  0xc,0x0
    1780:	8d 7e f4             	lea    di,[bp-0xc]
    1783:	16                   	push   ss
    1784:	57                   	push   di
    1785:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1788:	06                   	push   es
    1789:	57                   	push   di
    178a:	9a de 15 b2 17       	call   0x17b2:0x15de
    178f:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1792:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    1795:	80 7e fe 01          	cmp    BYTE PTR [bp-0x2],0x1
    1799:	75 0a                	jne    0x17a5
    179b:	c7 46 f6 ff ff       	mov    WORD PTR [bp-0xa],0xffff
    17a0:	c7 46 f8 ff 00       	mov    WORD PTR [bp-0x8],0xff
    17a5:	8d 7e f4             	lea    di,[bp-0xc]
    17a8:	16                   	push   ss
    17a9:	57                   	push   di
    17aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17ad:	06                   	push   es
    17ae:	57                   	push   di
    17af:	9a 10 16 dd 17       	call   0x17dd:0x1610
    17b4:	c9                   	leave
    17b5:	ca 06 00             	retf   0x6
    17b8:	55                   	push   bp
    17b9:	89 e5                	mov    bp,sp
    17bb:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    17bf:	74 08                	je     0x17c9
    17c1:	83 ec 08             	sub    sp,0x8
    17c4:	9a e2 1f d4 17       	call   0x17d4:0x1fe2
    17c9:	31 c0                	xor    ax,ax
    17cb:	50                   	push   ax
    17cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17cf:	06                   	push   es
    17d0:	57                   	push   di
    17d1:	9a 50 1f e3 18       	call   0x18e3:0x1f50
    17d6:	b0 01                	mov    al,0x1
    17d8:	50                   	push   ax
    17d9:	b8 10 03             	mov    ax,0x310
    17dc:	ba e4 17             	mov    dx,0x17e4
    17df:	52                   	push   dx
    17e0:	50                   	push   ax
    17e1:	9a 96 0e f7 17       	call   0x17f7:0xe96
    17e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e9:	26 89 45 07          	mov    WORD PTR es:[di+0x7],ax
    17ed:	26 89 55 09          	mov    WORD PTR es:[di+0x9],dx
    17f1:	06                   	push   es
    17f2:	57                   	push   di
    17f3:	b8 a0 24             	mov    ax,0x24a0
    17f6:	ba 14 18             	mov    dx,0x1814
    17f9:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    17fd:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1801:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1805:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    1809:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    180d:	b0 01                	mov    al,0x1
    180f:	50                   	push   ax
    1810:	b8 11 04             	mov    ax,0x411
    1813:	ba 1b 18             	mov    dx,0x181b
    1816:	52                   	push   dx
    1817:	50                   	push   ax
    1818:	9a a4 12 2e 18       	call   0x182e:0x12a4
    181d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1820:	26 89 45 0b          	mov    WORD PTR es:[di+0xb],ax
    1824:	26 89 55 0d          	mov    WORD PTR es:[di+0xd],dx
    1828:	06                   	push   es
    1829:	57                   	push   di
    182a:	b8 c3 24             	mov    ax,0x24c3
    182d:	ba 4b 18             	mov    dx,0x184b
    1830:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1834:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1838:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    183c:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    1840:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    1844:	b0 01                	mov    al,0x1
    1846:	50                   	push   ax
    1847:	b8 d4 04             	mov    ax,0x4d4
    184a:	ba 52 18             	mov    dx,0x1852
    184d:	52                   	push   dx
    184e:	50                   	push   ax
    184f:	9a 27 15 65 18       	call   0x1865:0x1527
    1854:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1857:	26 89 45 0f          	mov    WORD PTR es:[di+0xf],ax
    185b:	26 89 55 11          	mov    WORD PTR es:[di+0x11],dx
    185f:	06                   	push   es
    1860:	57                   	push   di
    1861:	b8 e6 24             	mov    ax,0x24e6
    1864:	ba d5 18             	mov    dx,0x18d5
    1867:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    186b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    186f:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1873:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    1877:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    187b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    187e:	26 c7 45 17 20 00    	mov    WORD PTR es:[di+0x17],0x20
    1884:	26 c7 45 19 cc 00    	mov    WORD PTR es:[di+0x19],0xcc
    188a:	26 c6 45 06 00       	mov    BYTE PTR es:[di+0x6],0x0
    188f:	ff 76 08             	push   WORD PTR [bp+0x8]
    1892:	ff 76 06             	push   WORD PTR [bp+0x6]
    1895:	c4 3e 2c 2b          	les    di,DWORD PTR ds:0x2b2c
    1899:	06                   	push   es
    189a:	57                   	push   di
    189b:	9a 2b 0c c9 18       	call   0x18c9:0xc2b
    18a0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    18a4:	74 07                	je     0x18ad
    18a6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    18aa:	83 c4 06             	add    sp,0x6
    18ad:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    18b0:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    18b3:	c9                   	leave
    18b4:	ca 06 00             	retf   0x6
    18b7:	55                   	push   bp
    18b8:	89 e5                	mov    bp,sp
    18ba:	ff 76 08             	push   WORD PTR [bp+0x8]
    18bd:	ff 76 06             	push   WORD PTR [bp+0x6]
    18c0:	c4 3e 2c 2b          	les    di,DWORD PTR ds:0x2b2c
    18c4:	06                   	push   es
    18c5:	57                   	push   di
    18c6:	9a a7 0f 48 1c       	call   0x1c48:0xfa7
    18cb:	6a 00                	push   0x0
    18cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18d0:	06                   	push   es
    18d1:	57                   	push   di
    18d2:	9a 5d 22 21 19       	call   0x1921:0x225d
    18d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18da:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    18de:	06                   	push   es
    18df:	57                   	push   di
    18e0:	9a 7f 1f f1 18       	call   0x18f1:0x1f7f
    18e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18e8:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    18ec:	06                   	push   es
    18ed:	57                   	push   di
    18ee:	9a 7f 1f ff 18       	call   0x18ff:0x1f7f
    18f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18f6:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    18fa:	06                   	push   es
    18fb:	57                   	push   di
    18fc:	9a 7f 1f 0c 19       	call   0x190c:0x1f7f
    1901:	31 c0                	xor    ax,ax
    1903:	50                   	push   ax
    1904:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1907:	06                   	push   es
    1908:	57                   	push   di
    1909:	9a 66 1f 17 19       	call   0x1917:0x1f66
    190e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1912:	74 05                	je     0x1919
    1914:	9a 0f 20 fd 1a       	call   0x1afd:0x200f
    1919:	c9                   	leave
    191a:	ca 06 00             	retf   0x6
    191d:	00 00                	add    BYTE PTR [bx+si],al
    191f:	f5                   	cmc
    1920:	1a 45 19             	sbb    al,BYTE PTR [di+0x19]
    1923:	c8 0c 00 00          	enter  0xc,0x0
    1927:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    192a:	0b 46 14             	or     ax,WORD PTR [bp+0x14]
    192d:	75 03                	jne    0x1932
    192f:	e9 da 01             	jmp    0x1b0c
    1932:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1935:	06                   	push   es
    1936:	57                   	push   di
    1937:	26 c4 3d             	les    di,DWORD PTR es:[di]
    193a:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    193e:	b0 01                	mov    al,0x1
    1940:	50                   	push   ax
    1941:	b8 3f 08             	mov    ax,0x83f
    1944:	ba 4c 19             	mov    dx,0x194c
    1947:	52                   	push   dx
    1948:	50                   	push   ax
    1949:	9a bd 56 82 19       	call   0x1982:0x56bd
    194e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1951:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1954:	b8 1d 19             	mov    ax,0x191d
    1957:	0e                   	push   cs
    1958:	50                   	push   ax
    1959:	55                   	push   bp
    195a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    195e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1962:	ff 76 14             	push   WORD PTR [bp+0x14]
    1965:	ff 76 12             	push   WORD PTR [bp+0x12]
    1968:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    196b:	06                   	push   es
    196c:	57                   	push   di
    196d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1970:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    1974:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1977:	ff 76 0a             	push   WORD PTR [bp+0xa]
    197a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    197d:	06                   	push   es
    197e:	57                   	push   di
    197f:	9a 0f 5a 91 19       	call   0x1991:0x5a0f
    1984:	89 c7                	mov    di,ax
    1986:	8e c2                	mov    es,dx
    1988:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    198c:	06                   	push   es
    198d:	57                   	push   di
    198e:	9a 84 16 9d 19       	call   0x199d:0x1684
    1993:	6a 00                	push   0x0
    1995:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1998:	06                   	push   es
    1999:	57                   	push   di
    199a:	9a 26 62 a9 19       	call   0x19a9:0x6226
    199f:	6a 01                	push   0x1
    19a1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    19a4:	06                   	push   es
    19a5:	57                   	push   di
    19a6:	9a 26 62 b5 19       	call   0x19b5:0x6226
    19ab:	6a 01                	push   0x1
    19ad:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    19b0:	06                   	push   es
    19b1:	57                   	push   di
    19b2:	9a 0f 5a c0 19       	call   0x19c0:0x5a0f
    19b7:	89 c7                	mov    di,ax
    19b9:	8e c2                	mov    es,dx
    19bb:	06                   	push   es
    19bc:	57                   	push   di
    19bd:	9a c2 22 cc 19       	call   0x19cc:0x22c2
    19c2:	6a 01                	push   0x1
    19c4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    19c7:	06                   	push   es
    19c8:	57                   	push   di
    19c9:	9a 0f 5a d7 19       	call   0x19d7:0x5a0f
    19ce:	89 c7                	mov    di,ax
    19d0:	8e c2                	mov    es,dx
    19d2:	06                   	push   es
    19d3:	57                   	push   di
    19d4:	9a c2 22 e3 19       	call   0x19e3:0x22c2
    19d9:	6a 09                	push   0x9
    19db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19de:	06                   	push   es
    19df:	57                   	push   di
    19e0:	9a c2 22 0f 1a       	call   0x1a0f:0x22c2
    19e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19e8:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    19ec:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    19ef:	26 ff 35             	push   WORD PTR es:[di]
    19f2:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    19f6:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    19fa:	26 2b 05             	sub    ax,WORD PTR es:[di]
    19fd:	50                   	push   ax
    19fe:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1a02:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    1a06:	50                   	push   ax
    1a07:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1a0a:	06                   	push   es
    1a0b:	57                   	push   di
    1a0c:	9a 0f 5a 95 1a       	call   0x1a95:0x5a0f
    1a11:	89 c7                	mov    di,ax
    1a13:	8e c2                	mov    es,dx
    1a15:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1a19:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1a1c:	26 ff 35             	push   WORD PTR es:[di]
    1a1f:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1a23:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1a27:	26 2b 05             	sub    ax,WORD PTR es:[di]
    1a2a:	50                   	push   ax
    1a2b:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1a2f:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    1a33:	50                   	push   ax
    1a34:	68 cc 00             	push   0xcc
    1a37:	6a 20                	push   0x20
    1a39:	9a c1 1a 00 00       	call   0x0:0x1ac1
    1a3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a41:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1a45:	6a 00                	push   0x0
    1a47:	6a 00                	push   0x0
    1a49:	9a d3 1a 00 00       	call   0x0:0x1ad3
    1a4e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1a51:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    1a54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a57:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1a5b:	68 ff 00             	push   0xff
    1a5e:	6a ff                	push   0xffff
    1a60:	9a e5 1a 00 00       	call   0x0:0x1ae5
    1a65:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1a68:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1a6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a6e:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1a72:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    1a75:	26 ff 35             	push   WORD PTR es:[di]
    1a78:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1a7c:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1a80:	26 2b 05             	sub    ax,WORD PTR es:[di]
    1a83:	50                   	push   ax
    1a84:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1a88:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    1a8c:	50                   	push   ax
    1a8d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1a90:	06                   	push   es
    1a91:	57                   	push   di
    1a92:	9a 0f 5a 29 1b       	call   0x1b29:0x5a0f
    1a97:	89 c7                	mov    di,ax
    1a99:	8e c2                	mov    es,dx
    1a9b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1a9f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1aa2:	26 ff 35             	push   WORD PTR es:[di]
    1aa5:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1aa9:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1aad:	26 2b 05             	sub    ax,WORD PTR es:[di]
    1ab0:	50                   	push   ax
    1ab1:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1ab5:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    1ab9:	50                   	push   ax
    1aba:	68 e2 00             	push   0xe2
    1abd:	68 46 07             	push   0x746
    1ac0:	9a 87 1b 00 00       	call   0x0:0x1b87
    1ac5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ac8:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1acc:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1acf:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1ad2:	9a 10 1c 00 00       	call   0x0:0x1c10
    1ad7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ada:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1ade:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1ae1:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1ae4:	9a f1 1b 00 00       	call   0x0:0x1bf1
    1ae9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1aed:	83 c4 06             	add    sp,0x6
    1af0:	b8 00 1b             	mov    ax,0x1b00
    1af3:	0e                   	push   cs
    1af4:	50                   	push   ax
    1af5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1af8:	06                   	push   es
    1af9:	57                   	push   di
    1afa:	9a 7f 1f 17 23       	call   0x2317:0x1f7f
    1aff:	cb                   	retf
    1b00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b03:	06                   	push   es
    1b04:	57                   	push   di
    1b05:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b08:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1b0c:	c9                   	leave
    1b0d:	ca 14 00             	retf   0x14
    1b10:	55                   	push   bp
    1b11:	89 e5                	mov    bp,sp
    1b13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b16:	06                   	push   es
    1b17:	57                   	push   di
    1b18:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b1b:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1b1f:	6a 0b                	push   0xb
    1b21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b24:	06                   	push   es
    1b25:	57                   	push   di
    1b26:	9a c2 22 35 1b       	call   0x1b35:0x22c2
    1b2b:	6a 01                	push   0x1
    1b2d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1b30:	06                   	push   es
    1b31:	57                   	push   di
    1b32:	9a c2 22 d3 1b       	call   0x1bd3:0x22c2
    1b37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b3a:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1b3e:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1b41:	26 ff 35             	push   WORD PTR es:[di]
    1b44:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1b48:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1b4c:	26 2b 05             	sub    ax,WORD PTR es:[di]
    1b4f:	50                   	push   ax
    1b50:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1b54:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    1b58:	50                   	push   ax
    1b59:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1b5c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1b60:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b63:	26 ff 35             	push   WORD PTR es:[di]
    1b66:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1b6a:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1b6e:	26 2b 05             	sub    ax,WORD PTR es:[di]
    1b71:	50                   	push   ax
    1b72:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1b76:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    1b7a:	50                   	push   ax
    1b7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b7e:	26 ff 75 19          	push   WORD PTR es:[di+0x19]
    1b82:	26 ff 75 17          	push   WORD PTR es:[di+0x17]
    1b86:	9a da 26 00 00       	call   0x0:0x26da
    1b8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b8e:	06                   	push   es
    1b8f:	57                   	push   di
    1b90:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b93:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1b97:	c9                   	leave
    1b98:	ca 10 00             	retf   0x10
    1b9b:	c8 08 00 00          	enter  0x8,0x0
    1b9f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1ba2:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1ba5:	75 03                	jne    0x1baa
    1ba7:	e9 b8 00             	jmp    0x1c62
    1baa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1bad:	06                   	push   es
    1bae:	57                   	push   di
    1baf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bb2:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    1bb6:	08 c0                	or     al,al
    1bb8:	74 03                	je     0x1bbd
    1bba:	e9 a5 00             	jmp    0x1c62
    1bbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bc0:	06                   	push   es
    1bc1:	57                   	push   di
    1bc2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bc5:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1bc9:	6a 01                	push   0x1
    1bcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bce:	06                   	push   es
    1bcf:	57                   	push   di
    1bd0:	9a c2 22 e5 1b       	call   0x1be5:0x22c2
    1bd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bd8:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1bdc:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1be0:	06                   	push   es
    1be1:	57                   	push   di
    1be2:	9a 61 16 ec 1b       	call   0x1bec:0x1661
    1be7:	52                   	push   dx
    1be8:	50                   	push   ax
    1be9:	9a a5 0c 0b 1c       	call   0x1c0b:0xca5
    1bee:	52                   	push   dx
    1bef:	50                   	push   ax
    1bf0:	9a 68 24 00 00       	call   0x0:0x2468
    1bf5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf8:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1bfc:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1c00:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    1c04:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1c08:	9a a5 0c 7f 1c       	call   0x1c7f:0xca5
    1c0d:	52                   	push   dx
    1c0e:	50                   	push   ax
    1c0f:	9a d9 23 00 00       	call   0x0:0x23d9
    1c14:	ff 76 08             	push   WORD PTR [bp+0x8]
    1c17:	ff 76 06             	push   WORD PTR [bp+0x6]
    1c1a:	8d 7e f8             	lea    di,[bp-0x8]
    1c1d:	16                   	push   ss
    1c1e:	57                   	push   di
    1c1f:	ff 76 10             	push   WORD PTR [bp+0x10]
    1c22:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1c25:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c28:	06                   	push   es
    1c29:	57                   	push   di
    1c2a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c2d:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    1c31:	03 46 10             	add    ax,WORD PTR [bp+0x10]
    1c34:	50                   	push   ax
    1c35:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c38:	06                   	push   es
    1c39:	57                   	push   di
    1c3a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c3d:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1c41:	03 46 0e             	add    ax,WORD PTR [bp+0xe]
    1c44:	50                   	push   ax
    1c45:	9a 88 06 ff 3d       	call   0x3dff:0x688
    1c4a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c4d:	06                   	push   es
    1c4e:	57                   	push   di
    1c4f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c52:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1c56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c59:	06                   	push   es
    1c5a:	57                   	push   di
    1c5b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c5e:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1c62:	c9                   	leave
    1c63:	ca 0c 00             	retf   0xc
    1c66:	55                   	push   bp
    1c67:	89 e5                	mov    bp,sp
    1c69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c6c:	06                   	push   es
    1c6d:	57                   	push   di
    1c6e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c71:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1c75:	6a 01                	push   0x1
    1c77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c7a:	06                   	push   es
    1c7b:	57                   	push   di
    1c7c:	9a c2 22 bb 1c       	call   0x1cbb:0x22c2
    1c81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c84:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1c88:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c8b:	06                   	push   es
    1c8c:	57                   	push   di
    1c8d:	9a ff ff 00 00       	call   0x0:0xffff
    1c92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c95:	06                   	push   es
    1c96:	57                   	push   di
    1c97:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c9a:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1c9e:	c9                   	leave
    1c9f:	ca 08 00             	retf   0x8
    1ca2:	55                   	push   bp
    1ca3:	89 e5                	mov    bp,sp
    1ca5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca8:	06                   	push   es
    1ca9:	57                   	push   di
    1caa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1cad:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1cb1:	6a 0d                	push   0xd
    1cb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cb6:	06                   	push   es
    1cb7:	57                   	push   di
    1cb8:	9a c2 22 fe 1c       	call   0x1cfe:0x22c2
    1cbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cc0:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1cc4:	ff 76 10             	push   WORD PTR [bp+0x10]
    1cc7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1cca:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ccd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1cd0:	9a ff ff 00 00       	call   0x0:0xffff
    1cd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cd8:	06                   	push   es
    1cd9:	57                   	push   di
    1cda:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1cdd:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1ce1:	c9                   	leave
    1ce2:	ca 0c 00             	retf   0xc
    1ce5:	55                   	push   bp
    1ce6:	89 e5                	mov    bp,sp
    1ce8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ceb:	06                   	push   es
    1cec:	57                   	push   di
    1ced:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1cf0:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1cf4:	6a 09                	push   0x9
    1cf6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf9:	06                   	push   es
    1cfa:	57                   	push   di
    1cfb:	9a c2 22 18 1d       	call   0x1d18:0x22c2
    1d00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d03:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1d07:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d0a:	06                   	push   es
    1d0b:	57                   	push   di
    1d0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d0f:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1d13:	06                   	push   es
    1d14:	57                   	push   di
    1d15:	9a c0 16 49 1d       	call   0x1d49:0x16c0
    1d1a:	50                   	push   ax
    1d1b:	9a 84 54 00 00       	call   0x0:0x5484
    1d20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d23:	06                   	push   es
    1d24:	57                   	push   di
    1d25:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d28:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1d2c:	c9                   	leave
    1d2d:	ca 08 00             	retf   0x8
    1d30:	55                   	push   bp
    1d31:	89 e5                	mov    bp,sp
    1d33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d36:	06                   	push   es
    1d37:	57                   	push   di
    1d38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d3b:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1d3f:	6a 09                	push   0x9
    1d41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d44:	06                   	push   es
    1d45:	57                   	push   di
    1d46:	9a c2 22 63 1d       	call   0x1d63:0x22c2
    1d4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d4e:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1d52:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d55:	06                   	push   es
    1d56:	57                   	push   di
    1d57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d5a:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1d5e:	06                   	push   es
    1d5f:	57                   	push   di
    1d60:	9a c0 16 94 1d       	call   0x1d94:0x16c0
    1d65:	50                   	push   ax
    1d66:	9a ff ff 00 00       	call   0x0:0xffff
    1d6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d6e:	06                   	push   es
    1d6f:	57                   	push   di
    1d70:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d73:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1d77:	c9                   	leave
    1d78:	ca 08 00             	retf   0x8
    1d7b:	55                   	push   bp
    1d7c:	89 e5                	mov    bp,sp
    1d7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d81:	06                   	push   es
    1d82:	57                   	push   di
    1d83:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d86:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1d8a:	6a 05                	push   0x5
    1d8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d8f:	06                   	push   es
    1d90:	57                   	push   di
    1d91:	9a c2 22 c5 1d       	call   0x1dc5:0x22c2
    1d96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d99:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1d9d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1da0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1da3:	9a ff ff 00 00       	call   0x0:0xffff
    1da8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dab:	06                   	push   es
    1dac:	57                   	push   di
    1dad:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1db0:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1db4:	c9                   	leave
    1db5:	ca 08 00             	retf   0x8
    1db8:	55                   	push   bp
    1db9:	89 e5                	mov    bp,sp
    1dbb:	6a 01                	push   0x1
    1dbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dc0:	06                   	push   es
    1dc1:	57                   	push   di
    1dc2:	9a c2 22 fa 1d       	call   0x1dfa:0x22c2
    1dc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dca:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1dce:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1dd1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1dd4:	6a 00                	push   0x0
    1dd6:	6a 00                	push   0x0
    1dd8:	9a ff ff 00 00       	call   0x0:0xffff
    1ddd:	c9                   	leave
    1dde:	ca 08 00             	retf   0x8
    1de1:	55                   	push   bp
    1de2:	89 e5                	mov    bp,sp
    1de4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1de7:	06                   	push   es
    1de8:	57                   	push   di
    1de9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1dec:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1df0:	6a 0d                	push   0xd
    1df2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1df5:	06                   	push   es
    1df6:	57                   	push   di
    1df7:	9a c2 22 3b 1e       	call   0x1e3b:0x22c2
    1dfc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dff:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1e03:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1e06:	06                   	push   es
    1e07:	57                   	push   di
    1e08:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1e0b:	40                   	inc    ax
    1e0c:	50                   	push   ax
    1e0d:	9a ff ff 00 00       	call   0x0:0xffff
    1e12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e15:	06                   	push   es
    1e16:	57                   	push   di
    1e17:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e1a:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1e1e:	c9                   	leave
    1e1f:	ca 0a 00             	retf   0xa
    1e22:	55                   	push   bp
    1e23:	89 e5                	mov    bp,sp
    1e25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e28:	06                   	push   es
    1e29:	57                   	push   di
    1e2a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e2d:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1e31:	6a 0d                	push   0xd
    1e33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e36:	06                   	push   es
    1e37:	57                   	push   di
    1e38:	9a c2 22 70 1e       	call   0x1e70:0x22c2
    1e3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e40:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1e44:	ff 76 10             	push   WORD PTR [bp+0x10]
    1e47:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1e4a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e4d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e50:	9a ff ff 00 00       	call   0x0:0xffff
    1e55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e58:	06                   	push   es
    1e59:	57                   	push   di
    1e5a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e5d:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1e61:	c9                   	leave
    1e62:	ca 0c 00             	retf   0xc
    1e65:	55                   	push   bp
    1e66:	89 e5                	mov    bp,sp
    1e68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e6b:	06                   	push   es
    1e6c:	57                   	push   di
    1e6d:	9a ff 21 8f 1e       	call   0x1e8f:0x21ff
    1e72:	c9                   	leave
    1e73:	ca 04 00             	retf   0x4
    1e76:	55                   	push   bp
    1e77:	89 e5                	mov    bp,sp
    1e79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e7c:	06                   	push   es
    1e7d:	57                   	push   di
    1e7e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e81:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1e85:	6a 0d                	push   0xd
    1e87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e8a:	06                   	push   es
    1e8b:	57                   	push   di
    1e8c:	9a c2 22 e0 1e       	call   0x1ee0:0x22c2
    1e91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e94:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1e98:	ff 76 14             	push   WORD PTR [bp+0x14]
    1e9b:	ff 76 12             	push   WORD PTR [bp+0x12]
    1e9e:	ff 76 10             	push   WORD PTR [bp+0x10]
    1ea1:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1ea4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ea7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1eaa:	9a ff ff 00 00       	call   0x0:0xffff
    1eaf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb2:	06                   	push   es
    1eb3:	57                   	push   di
    1eb4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1eb7:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1ebb:	c9                   	leave
    1ebc:	ca 10 00             	retf   0x10
    1ebf:	55                   	push   bp
    1ec0:	89 e5                	mov    bp,sp
    1ec2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1ec5:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1ec8:	74 3b                	je     0x1f05
    1eca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ecd:	06                   	push   es
    1ece:	57                   	push   di
    1ecf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ed2:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1ed6:	6a 0f                	push   0xf
    1ed8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1edb:	06                   	push   es
    1edc:	57                   	push   di
    1edd:	9a c2 22 22 1f       	call   0x1f22:0x22c2
    1ee2:	ff 76 08             	push   WORD PTR [bp+0x8]
    1ee5:	ff 76 06             	push   WORD PTR [bp+0x6]
    1ee8:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1eeb:	06                   	push   es
    1eec:	57                   	push   di
    1eed:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1ef0:	06                   	push   es
    1ef1:	57                   	push   di
    1ef2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ef5:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1ef9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1efc:	06                   	push   es
    1efd:	57                   	push   di
    1efe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f01:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1f05:	c9                   	leave
    1f06:	ca 0c 00             	retf   0xc
    1f09:	55                   	push   bp
    1f0a:	89 e5                	mov    bp,sp
    1f0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f0f:	06                   	push   es
    1f10:	57                   	push   di
    1f11:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f14:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1f18:	6a 0b                	push   0xb
    1f1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f1d:	06                   	push   es
    1f1e:	57                   	push   di
    1f1f:	9a c2 22 55 1f       	call   0x1f55:0x22c2
    1f24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f27:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1f2b:	ff 76 10             	push   WORD PTR [bp+0x10]
    1f2e:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1f31:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1f34:	81 c7 01 00          	add    di,0x1
    1f38:	06                   	push   es
    1f39:	57                   	push   di
    1f3a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1f3d:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1f40:	30 e4                	xor    ah,ah
    1f42:	50                   	push   ax
    1f43:	9a ff ff 00 00       	call   0x0:0xffff
    1f48:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1f4b:	06                   	push   es
    1f4c:	57                   	push   di
    1f4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f50:	06                   	push   es
    1f51:	57                   	push   di
    1f52:	9a 03 20 66 1f       	call   0x1f66:0x2003
    1f57:	03 46 10             	add    ax,WORD PTR [bp+0x10]
    1f5a:	50                   	push   ax
    1f5b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1f5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f61:	06                   	push   es
    1f62:	57                   	push   di
    1f63:	9a b8 1d a6 1f       	call   0x1fa6:0x1db8
    1f68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f6b:	06                   	push   es
    1f6c:	57                   	push   di
    1f6d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f70:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1f74:	c9                   	leave
    1f75:	ca 0c 00             	retf   0xc
    1f78:	c8 0a 00 00          	enter  0xa,0x0
    1f7c:	8c d3                	mov    bx,ss
    1f7e:	8e c3                	mov    es,bx
    1f80:	8c db                	mov    bx,ds
    1f82:	fc                   	cld
    1f83:	8d 7e f8             	lea    di,[bp-0x8]
    1f86:	c5 76 12             	lds    si,DWORD PTR [bp+0x12]
    1f89:	b9 08 00             	mov    cx,0x8
    1f8c:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1f8e:	8e db                	mov    ds,bx
    1f90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f93:	06                   	push   es
    1f94:	57                   	push   di
    1f95:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f98:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1f9c:	6a 0b                	push   0xb
    1f9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fa1:	06                   	push   es
    1fa2:	57                   	push   di
    1fa3:	9a c2 22 b9 1f       	call   0x1fb9:0x22c2
    1fa8:	c7 46 f6 04 00       	mov    WORD PTR [bp-0xa],0x4
    1fad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb0:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1fb4:	06                   	push   es
    1fb5:	57                   	push   di
    1fb6:	9a 63 17 11 20       	call   0x2011:0x1763
    1fbb:	3c 01                	cmp    al,0x1
    1fbd:	74 04                	je     0x1fc3
    1fbf:	83 46 f6 02          	add    WORD PTR [bp-0xa],0x2
    1fc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fc6:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1fca:	ff 76 10             	push   WORD PTR [bp+0x10]
    1fcd:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1fd0:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1fd3:	8d 7e f8             	lea    di,[bp-0x8]
    1fd6:	16                   	push   ss
    1fd7:	57                   	push   di
    1fd8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1fdb:	81 c7 01 00          	add    di,0x1
    1fdf:	06                   	push   es
    1fe0:	57                   	push   di
    1fe1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1fe4:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1fe7:	30 e4                	xor    ah,ah
    1fe9:	50                   	push   ax
    1fea:	6a 00                	push   0x0
    1fec:	6a 00                	push   0x0
    1fee:	9a ff ff 00 00       	call   0x0:0xffff
    1ff3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ff6:	06                   	push   es
    1ff7:	57                   	push   di
    1ff8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ffb:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1fff:	c9                   	leave
    2000:	ca 10 00             	retf   0x10
    2003:	c8 06 00 00          	enter  0x6,0x0
    2007:	6a 03                	push   0x3
    2009:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    200c:	06                   	push   es
    200d:	57                   	push   di
    200e:	9a c2 22 5c 20       	call   0x205c:0x22c2
    2013:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2016:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    201a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    201d:	81 c7 01 00          	add    di,0x1
    2021:	06                   	push   es
    2022:	57                   	push   di
    2023:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2026:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2029:	30 e4                	xor    ah,ah
    202b:	50                   	push   ax
    202c:	8d 7e fa             	lea    di,[bp-0x6]
    202f:	16                   	push   ss
    2030:	57                   	push   di
    2031:	9a 7d 20 00 00       	call   0x0:0x207d
    2036:	09 c0                	or     ax,ax
    2038:	74 08                	je     0x2042
    203a:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    203d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2040:	eb 05                	jmp    0x2047
    2042:	31 c0                	xor    ax,ax
    2044:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2047:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    204a:	c9                   	leave
    204b:	ca 08 00             	retf   0x8
    204e:	c8 06 00 00          	enter  0x6,0x0
    2052:	6a 03                	push   0x3
    2054:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2057:	06                   	push   es
    2058:	57                   	push   di
    2059:	9a c2 22 fe 20       	call   0x20fe:0x22c2
    205e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2061:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2065:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2068:	81 c7 01 00          	add    di,0x1
    206c:	06                   	push   es
    206d:	57                   	push   di
    206e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2071:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2074:	30 e4                	xor    ah,ah
    2076:	50                   	push   ax
    2077:	8d 7e fa             	lea    di,[bp-0x6]
    207a:	16                   	push   ss
    207b:	57                   	push   di
    207c:	9a ff ff 00 00       	call   0x0:0xffff
    2081:	09 c0                	or     ax,ax
    2083:	74 08                	je     0x208d
    2085:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2088:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    208b:	eb 05                	jmp    0x2092
    208d:	31 c0                	xor    ax,ax
    208f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2092:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2095:	c9                   	leave
    2096:	ca 08 00             	retf   0x8
    2099:	55                   	push   bp
    209a:	89 e5                	mov    bp,sp
    209c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    209f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a5:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    20a9:	06                   	push   es
    20aa:	57                   	push   di
    20ab:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20ae:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    20b2:	c9                   	leave
    20b3:	ca 08 00             	retf   0x8
    20b6:	55                   	push   bp
    20b7:	89 e5                	mov    bp,sp
    20b9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20bc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20c2:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    20c6:	06                   	push   es
    20c7:	57                   	push   di
    20c8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20cb:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    20cf:	c9                   	leave
    20d0:	ca 08 00             	retf   0x8
    20d3:	55                   	push   bp
    20d4:	89 e5                	mov    bp,sp
    20d6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20d9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    20dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20df:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    20e3:	06                   	push   es
    20e4:	57                   	push   di
    20e5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20e8:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    20ec:	c9                   	leave
    20ed:	ca 08 00             	retf   0x8
    20f0:	c8 04 00 00          	enter  0x4,0x0
    20f4:	6a 01                	push   0x1
    20f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20f9:	06                   	push   es
    20fa:	57                   	push   di
    20fb:	9a c2 22 2c 21       	call   0x212c:0x22c2
    2100:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2103:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2107:	8d 7e fc             	lea    di,[bp-0x4]
    210a:	16                   	push   ss
    210b:	57                   	push   di
    210c:	9a ff ff 00 00       	call   0x0:0xffff
    2111:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2114:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2117:	c9                   	leave
    2118:	ca 04 00             	retf   0x4
    211b:	55                   	push   bp
    211c:	89 e5                	mov    bp,sp
    211e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2121:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2124:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2127:	06                   	push   es
    2128:	57                   	push   di
    2129:	9a b8 1d 40 21       	call   0x2140:0x1db8
    212e:	c9                   	leave
    212f:	ca 08 00             	retf   0x8
    2132:	c8 04 00 00          	enter  0x4,0x0
    2136:	6a 01                	push   0x1
    2138:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    213b:	06                   	push   es
    213c:	57                   	push   di
    213d:	9a c2 22 7d 21       	call   0x217d:0x22c2
    2142:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2145:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2149:	ff 76 0c             	push   WORD PTR [bp+0xc]
    214c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    214f:	9a ff ff 00 00       	call   0x0:0xffff
    2154:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2157:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    215a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    215d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2160:	c9                   	leave
    2161:	ca 08 00             	retf   0x8
    2164:	55                   	push   bp
    2165:	89 e5                	mov    bp,sp
    2167:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    216a:	06                   	push   es
    216b:	57                   	push   di
    216c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    216f:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2173:	6a 01                	push   0x1
    2175:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2178:	06                   	push   es
    2179:	57                   	push   di
    217a:	9a c2 22 95 21       	call   0x2195:0x22c2
    217f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2182:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2186:	ff 76 10             	push   WORD PTR [bp+0x10]
    2189:	ff 76 0e             	push   WORD PTR [bp+0xe]
    218c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    218f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2192:	9a a5 0c bb 21       	call   0x21bb:0xca5
    2197:	52                   	push   dx
    2198:	50                   	push   ax
    2199:	9a ff ff 00 00       	call   0x0:0xffff
    219e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21a1:	06                   	push   es
    21a2:	57                   	push   di
    21a3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21a6:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    21aa:	c9                   	leave
    21ab:	ca 0c 00             	retf   0xc
    21ae:	55                   	push   bp
    21af:	89 e5                	mov    bp,sp
    21b1:	6a 01                	push   0x1
    21b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b6:	06                   	push   es
    21b7:	57                   	push   di
    21b8:	9a c2 22 ec 21       	call   0x21ec:0x22c2
    21bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c0:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    21c4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    21c7:	06                   	push   es
    21c8:	57                   	push   di
    21c9:	9a ff ff 00 00       	call   0x0:0xffff
    21ce:	c9                   	leave
    21cf:	ca 04 00             	retf   0x4
    21d2:	c8 02 00 00          	enter  0x2,0x0
    21d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21d9:	06                   	push   es
    21da:	57                   	push   di
    21db:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21de:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    21e2:	6a 0f                	push   0xf
    21e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21e7:	06                   	push   es
    21e8:	57                   	push   di
    21e9:	9a c2 22 78 22       	call   0x2278:0x22c2
    21ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21f1:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    21f5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    21f8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    21fb:	c9                   	leave
    21fc:	ca 04 00             	retf   0x4
    21ff:	55                   	push   bp
    2200:	89 e5                	mov    bp,sp
    2202:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2205:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    220a:	74 46                	je     0x2252
    220c:	26 8a 45 06          	mov    al,BYTE PTR es:[di+0x6]
    2210:	24 f1                	and    al,0xf1
    2212:	26 3a 45 06          	cmp    al,BYTE PTR es:[di+0x6]
    2216:	74 3a                	je     0x2252
    2218:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    221c:	ff 36 18 2b          	push   WORD PTR ds:0x2b18
    2220:	9a 31 22 00 00       	call   0x0:0x2231
    2225:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2228:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    222c:	ff 36 1a 2b          	push   WORD PTR ds:0x2b1a
    2230:	9a 41 22 00 00       	call   0x0:0x2241
    2235:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2238:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    223c:	ff 36 1c 2b          	push   WORD PTR ds:0x2b1c
    2240:	9a ba 23 00 00       	call   0x0:0x23ba
    2245:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2248:	26 8a 45 06          	mov    al,BYTE PTR es:[di+0x6]
    224c:	24 f1                	and    al,0xf1
    224e:	26 88 45 06          	mov    BYTE PTR es:[di+0x6],al
    2252:	c9                   	leave
    2253:	ca 04 00             	retf   0x4
    2256:	55                   	push   bp
    2257:	89 e5                	mov    bp,sp
    2259:	c9                   	leave
    225a:	ca 04 00             	retf   0x4
    225d:	55                   	push   bp
    225e:	89 e5                	mov    bp,sp
    2260:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2263:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2267:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    226a:	74 52                	je     0x22be
    226c:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    2271:	74 27                	je     0x229a
    2273:	06                   	push   es
    2274:	57                   	push   di
    2275:	9a ff 21 82 22       	call   0x2282:0x21ff
    227a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    227d:	06                   	push   es
    227e:	57                   	push   di
    227f:	9a f0 20 bc 22       	call   0x22bc:0x20f0
    2284:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2287:	26 89 45 13          	mov    WORD PTR es:[di+0x13],ax
    228b:	26 89 55 15          	mov    WORD PTR es:[di+0x15],dx
    228f:	31 c0                	xor    ax,ax
    2291:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2295:	26 80 65 06 fe       	and    BYTE PTR es:[di+0x6],0xfe
    229a:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    229e:	74 1e                	je     0x22be
    22a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a3:	26 80 4d 06 01       	or     BYTE PTR es:[di+0x6],0x1
    22a8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    22ab:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    22af:	26 ff 75 15          	push   WORD PTR es:[di+0x15]
    22b3:	26 ff 75 13          	push   WORD PTR es:[di+0x13]
    22b7:	06                   	push   es
    22b8:	57                   	push   di
    22b9:	9a 1b 21 27 23       	call   0x2327:0x211b
    22be:	c9                   	leave
    22bf:	ca 06 00             	retf   0x6
    22c2:	c8 02 01 00          	enter  0x102,0x0
    22c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c9:	26 8a 45 06          	mov    al,BYTE PTR es:[di+0x6]
    22cd:	f6 d0                	not    al
    22cf:	22 46 0a             	and    al,BYTE PTR [bp+0xa]
    22d2:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    22d5:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    22d9:	74 7c                	je     0x2357
    22db:	f6 46 ff 01          	test   BYTE PTR [bp-0x1],0x1
    22df:	74 38                	je     0x2319
    22e1:	06                   	push   es
    22e2:	57                   	push   di
    22e3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22e6:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    22ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ed:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    22f2:	75 25                	jne    0x2319
    22f4:	8d be fe fe          	lea    di,[bp-0x102]
    22f8:	16                   	push   ss
    22f9:	57                   	push   di
    22fa:	68 21 f0             	push   0xf021
    22fd:	9a 2b 09 10 23       	call   0x2310:0x92b
    2302:	b0 01                	mov    al,0x1
    2304:	50                   	push   ax
    2305:	b8 52 00             	mov    ax,0x52
    2308:	ba 9d 25             	mov    dx,0x259d
    230b:	52                   	push   dx
    230c:	50                   	push   ax
    230d:	9a e6 28 19 25       	call   0x2519:0x28e6
    2312:	52                   	push   dx
    2313:	50                   	push   ax
    2314:	9a 99 13 30 25       	call   0x2530:0x1399
    2319:	f6 46 ff 02          	test   BYTE PTR [bp-0x1],0x2
    231d:	74 0a                	je     0x2329
    231f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2322:	06                   	push   es
    2323:	57                   	push   di
    2324:	9a a3 23 37 23       	call   0x2337:0x23a3
    2329:	f6 46 ff 04          	test   BYTE PTR [bp-0x1],0x4
    232d:	74 0a                	je     0x2339
    232f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2332:	06                   	push   es
    2333:	57                   	push   di
    2334:	9a e1 23 47 23       	call   0x2347:0x23e1
    2339:	f6 46 ff 08          	test   BYTE PTR [bp-0x1],0x8
    233d:	74 0a                	je     0x2349
    233f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2342:	06                   	push   es
    2343:	57                   	push   di
    2344:	9a 1d 24 b6 23       	call   0x23b6:0x241d
    2349:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234c:	26 8a 45 06          	mov    al,BYTE PTR es:[di+0x6]
    2350:	0a 46 ff             	or     al,BYTE PTR [bp-0x1]
    2353:	26 88 45 06          	mov    BYTE PTR es:[di+0x6],al
    2357:	c9                   	leave
    2358:	ca 06 00             	retf   0x6
    235b:	55                   	push   bp
    235c:	89 e5                	mov    bp,sp
    235e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2361:	26 8b 45 25          	mov    ax,WORD PTR es:[di+0x25]
    2365:	09 c0                	or     ax,ax
    2367:	74 12                	je     0x237b
    2369:	ff 76 08             	push   WORD PTR [bp+0x8]
    236c:	ff 76 06             	push   WORD PTR [bp+0x6]
    236f:	26 ff 75 29          	push   WORD PTR es:[di+0x29]
    2373:	26 ff 75 27          	push   WORD PTR es:[di+0x27]
    2377:	26 ff 5d 23          	call   DWORD PTR es:[di+0x23]
    237b:	c9                   	leave
    237c:	ca 04 00             	retf   0x4
    237f:	55                   	push   bp
    2380:	89 e5                	mov    bp,sp
    2382:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2385:	26 8b 45 1d          	mov    ax,WORD PTR es:[di+0x1d]
    2389:	09 c0                	or     ax,ax
    238b:	74 12                	je     0x239f
    238d:	ff 76 08             	push   WORD PTR [bp+0x8]
    2390:	ff 76 06             	push   WORD PTR [bp+0x6]
    2393:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
    2397:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
    239b:	26 ff 5d 1b          	call   DWORD PTR es:[di+0x1b]
    239f:	c9                   	leave
    23a0:	ca 04 00             	retf   0x4
    23a3:	55                   	push   bp
    23a4:	89 e5                	mov    bp,sp
    23a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23a9:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    23ad:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    23b1:	06                   	push   es
    23b2:	57                   	push   di
    23b3:	9a 16 10 d4 23       	call   0x23d4:0x1016
    23b8:	50                   	push   ax
    23b9:	9a f8 23 00 00       	call   0x0:0x23f8
    23be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c1:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    23c5:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    23c9:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    23cd:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    23d1:	9a a5 0c f4 23       	call   0x23f4:0xca5
    23d6:	52                   	push   dx
    23d7:	50                   	push   ax
    23d8:	9a a2 54 00 00       	call   0x0:0x54a2
    23dd:	c9                   	leave
    23de:	ca 04 00             	retf   0x4
    23e1:	55                   	push   bp
    23e2:	89 e5                	mov    bp,sp
    23e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e7:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    23eb:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    23ef:	06                   	push   es
    23f0:	57                   	push   di
    23f1:	9a 0c 14 2c 24       	call   0x242c:0x140c
    23f6:	50                   	push   ax
    23f7:	9a 48 24 00 00       	call   0x0:0x2448
    23fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ff:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2403:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2407:	26 8a 45 10          	mov    al,BYTE PTR es:[di+0x10]
    240b:	98                   	cbw
    240c:	8b f8                	mov    di,ax
    240e:	d1 e7                	shl    di,1
    2410:	ff b5 8c 12          	push   WORD PTR [di+0x128c]
    2414:	9a ff ff 00 00       	call   0x0:0xffff
    2419:	c9                   	leave
    241a:	ca 04 00             	retf   0x4
    241d:	55                   	push   bp
    241e:	89 e5                	mov    bp,sp
    2420:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2423:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2427:	06                   	push   es
    2428:	57                   	push   di
    2429:	9a c0 16 44 24       	call   0x2444:0x16c0
    242e:	50                   	push   ax
    242f:	9a ff ff 00 00       	call   0x0:0xffff
    2434:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2437:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    243b:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    243f:	06                   	push   es
    2440:	57                   	push   di
    2441:	9a c0 16 5c 24       	call   0x245c:0x16c0
    2446:	50                   	push   ax
    2447:	9a bb 24 00 00       	call   0x0:0x24bb
    244c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    244f:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2453:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2457:	06                   	push   es
    2458:	57                   	push   di
    2459:	9a 61 16 63 24       	call   0x2463:0x1661
    245e:	52                   	push   dx
    245f:	50                   	push   ax
    2460:	9a a5 0c 78 24       	call   0x2478:0xca5
    2465:	52                   	push   dx
    2466:	50                   	push   ax
    2467:	9a c1 54 00 00       	call   0x0:0x54c1
    246c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    246f:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2473:	06                   	push   es
    2474:	57                   	push   di
    2475:	9a 63 17 22 25       	call   0x2522:0x1763
    247a:	08 c0                	or     al,al
    247c:	75 10                	jne    0x248e
    247e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2481:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2485:	6a 02                	push   0x2
    2487:	9a 98 24 00 00       	call   0x0:0x2498
    248c:	eb 0e                	jmp    0x249c
    248e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2491:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2495:	6a 01                	push   0x1
    2497:	9a ff ff 00 00       	call   0x0:0xffff
    249c:	c9                   	leave
    249d:	ca 04 00             	retf   0x4
    24a0:	55                   	push   bp
    24a1:	89 e5                	mov    bp,sp
    24a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24a6:	26 f6 45 06 02       	test   BYTE PTR es:[di+0x6],0x2
    24ab:	74 12                	je     0x24bf
    24ad:	26 80 65 06 fd       	and    BYTE PTR es:[di+0x6],0xfd
    24b2:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    24b6:	ff 36 1c 2b          	push   WORD PTR ds:0x2b1c
    24ba:	9a de 24 00 00       	call   0x0:0x24de
    24bf:	c9                   	leave
    24c0:	ca 08 00             	retf   0x8
    24c3:	55                   	push   bp
    24c4:	89 e5                	mov    bp,sp
    24c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c9:	26 f6 45 06 04       	test   BYTE PTR es:[di+0x6],0x4
    24ce:	74 12                	je     0x24e2
    24d0:	26 80 65 06 fb       	and    BYTE PTR es:[di+0x6],0xfb
    24d5:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    24d9:	ff 36 18 2b          	push   WORD PTR ds:0x2b18
    24dd:	9a 01 25 00 00       	call   0x0:0x2501
    24e2:	c9                   	leave
    24e3:	ca 08 00             	retf   0x8
    24e6:	55                   	push   bp
    24e7:	89 e5                	mov    bp,sp
    24e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24ec:	26 f6 45 06 08       	test   BYTE PTR es:[di+0x6],0x8
    24f1:	74 12                	je     0x2505
    24f3:	26 80 65 06 f7       	and    BYTE PTR es:[di+0x6],0xf7
    24f8:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    24fc:	ff 36 1a 2b          	push   WORD PTR ds:0x2b1a
    2500:	9a a5 26 00 00       	call   0x0:0x26a5
    2505:	c9                   	leave
    2506:	ca 08 00             	retf   0x8
    2509:	c8 00 01 00          	enter  0x100,0x0
    250d:	8d be 00 ff          	lea    di,[bp-0x100]
    2511:	16                   	push   ss
    2512:	57                   	push   di
    2513:	ff 76 04             	push   WORD PTR [bp+0x4]
    2516:	9a 2b 09 29 25       	call   0x2529:0x92b
    251b:	b0 01                	mov    al,0x1
    251d:	50                   	push   ax
    251e:	b8 63 00             	mov    ax,0x63
    2521:	ba 4f 25             	mov    dx,0x254f
    2524:	52                   	push   dx
    2525:	50                   	push   ax
    2526:	9a e6 28 46 25       	call   0x2546:0x28e6
    252b:	52                   	push   dx
    252c:	50                   	push   ax
    252d:	9a 99 13 5d 25       	call   0x255d:0x1399
    2532:	c9                   	leave
    2533:	c2 02 00             	ret    0x2
    2536:	c8 00 01 00          	enter  0x100,0x0
    253a:	8d be 00 ff          	lea    di,[bp-0x100]
    253e:	16                   	push   ss
    253f:	57                   	push   di
    2540:	ff 76 04             	push   WORD PTR [bp+0x4]
    2543:	9a 2b 09 56 25       	call   0x2556:0x92b
    2548:	b0 01                	mov    al,0x1
    254a:	50                   	push   ax
    254b:	b8 33 00             	mov    ax,0x33
    254e:	ba ff 25             	mov    dx,0x25ff
    2551:	52                   	push   dx
    2552:	50                   	push   ax
    2553:	9a e6 28 94 25       	call   0x2594:0x28e6
    2558:	52                   	push   dx
    2559:	50                   	push   ax
    255a:	9a 99 13 ab 25       	call   0x25ab:0x1399
    255f:	c9                   	leave
    2560:	c2 02 00             	ret    0x2
    2563:	55                   	push   bp
    2564:	89 e5                	mov    bp,sp
    2566:	68 19 f0             	push   0xf019
    2569:	e8 ca ff             	call   0x2536
    256c:	c9                   	leave
    256d:	c3                   	ret
    256e:	55                   	push   bp
    256f:	89 e5                	mov    bp,sp
    2571:	68 1a f0             	push   0xf01a
    2574:	e8 bf ff             	call   0x2536
    2577:	c9                   	leave
    2578:	c3                   	ret
    2579:	55                   	push   bp
    257a:	89 e5                	mov    bp,sp
    257c:	68 1b f0             	push   0xf01b
    257f:	e8 b4 ff             	call   0x2536
    2582:	c9                   	leave
    2583:	c3                   	ret
    2584:	c8 00 01 00          	enter  0x100,0x0
    2588:	8d be 00 ff          	lea    di,[bp-0x100]
    258c:	16                   	push   ss
    258d:	57                   	push   di
    258e:	68 20 f0             	push   0xf020
    2591:	9a 2b 09 a4 25       	call   0x25a4:0x92b
    2596:	b0 01                	mov    al,0x1
    2598:	50                   	push   ax
    2599:	b8 22 00             	mov    ax,0x22
    259c:	ba ff ff             	mov    dx,0xffff
    259f:	52                   	push   dx
    25a0:	50                   	push   ax
    25a1:	9a e6 28 2b 71       	call   0x712b:0x28e6
    25a6:	52                   	push   dx
    25a7:	50                   	push   ax
    25a8:	9a 99 13 c7 25       	call   0x25c7:0x1399
    25ad:	c9                   	leave
    25ae:	c3                   	ret
    25af:	c8 06 00 00          	enter  0x6,0x0
    25b3:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    25b7:	7c 08                	jl     0x25c1
    25b9:	7f 16                	jg     0x25d1
    25bb:	83 7e 06 ff          	cmp    WORD PTR [bp+0x6],0xffff
    25bf:	73 10                	jae    0x25d1
    25c1:	ff 76 06             	push   WORD PTR [bp+0x6]
    25c4:	9a 82 01 ca 27       	call   0x27ca:0x182
    25c9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    25cc:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    25cf:	eb 20                	jmp    0x25f1
    25d1:	ff 36 9a 18          	push   WORD PTR ds:0x189a
    25d5:	ff 76 08             	push   WORD PTR [bp+0x8]
    25d8:	ff 76 06             	push   WORD PTR [bp+0x6]
    25db:	9a ec 35 00 00       	call   0x0:0x35ec
    25e0:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    25e3:	ff 76 fa             	push   WORD PTR [bp-0x6]
    25e6:	9a 05 36 00 00       	call   0x0:0x3605
    25eb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    25ee:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    25f1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    25f4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    25f7:	c9                   	leave
    25f8:	ca 04 00             	retf   0x4
    25fb:	00 00                	add    BYTE PTR [bx+si],al
    25fd:	8d 26 4a 27          	lea    sp,ds:0x274a
    2601:	c8 1e 00 00          	enter  0x1e,0x0
    2605:	6a 00                	push   0x0
    2607:	9a 12 26 00 00       	call   0x0:0x2612
    260c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    260f:	6a 00                	push   0x0
    2611:	9a 70 52 00 00       	call   0x0:0x5270
    2616:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2619:	ff 76 0a             	push   WORD PTR [bp+0xa]
    261c:	6a 0e                	push   0xe
    261e:	8d 7e e6             	lea    di,[bp-0x1a]
    2621:	16                   	push   ss
    2622:	57                   	push   di
    2623:	9a 0c 34 00 00       	call   0x0:0x340c
    2628:	80 7e 04 00          	cmp    BYTE PTR [bp+0x4],0x0
    262c:	74 18                	je     0x2646
    262e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2631:	ff 76 08             	push   WORD PTR [bp+0x8]
    2634:	6a 01                	push   0x1
    2636:	6a 01                	push   0x1
    2638:	6a 00                	push   0x0
    263a:	6a 00                	push   0x0
    263c:	9a 72 3b 00 00       	call   0x0:0x3b72
    2641:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2644:	eb 52                	jmp    0x2698
    2646:	6a 00                	push   0x0
    2648:	9a ed 27 00 00       	call   0x0:0x27ed
    264d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2650:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    2654:	75 03                	jne    0x2659
    2656:	e8 2b ff             	call   0x2584
    2659:	b8 fb 25             	mov    ax,0x25fb
    265c:	0e                   	push   cs
    265d:	50                   	push   ax
    265e:	55                   	push   bp
    265f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2663:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2667:	ff 76 fc             	push   WORD PTR [bp-0x4]
    266a:	ff 76 06             	push   WORD PTR [bp+0x6]
    266d:	ff 76 08             	push   WORD PTR [bp+0x8]
    2670:	9a 29 54 00 00       	call   0x0:0x5429
    2675:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2678:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    267c:	75 03                	jne    0x2681
    267e:	e8 03 ff             	call   0x2584
    2681:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2685:	83 c4 06             	add    sp,0x6
    2688:	b8 98 26             	mov    ax,0x2698
    268b:	0e                   	push   cs
    268c:	50                   	push   ax
    268d:	6a 00                	push   0x0
    268f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2692:	9a f6 28 00 00       	call   0x0:0x28f6
    2697:	cb                   	retf
    2698:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    269c:	74 62                	je     0x2700
    269e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    26a1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    26a4:	9a b3 26 00 00       	call   0x0:0x26b3
    26a9:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    26ac:	ff 76 f8             	push   WORD PTR [bp-0x8]
    26af:	ff 76 fe             	push   WORD PTR [bp-0x2]
    26b2:	9a eb 26 00 00       	call   0x0:0x26eb
    26b7:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    26ba:	ff 76 f8             	push   WORD PTR [bp-0x8]
    26bd:	6a 00                	push   0x0
    26bf:	6a 00                	push   0x0
    26c1:	ff 76 06             	push   WORD PTR [bp+0x6]
    26c4:	ff 76 08             	push   WORD PTR [bp+0x8]
    26c7:	ff 76 fa             	push   WORD PTR [bp-0x6]
    26ca:	6a 00                	push   0x0
    26cc:	6a 00                	push   0x0
    26ce:	ff 76 e8             	push   WORD PTR [bp-0x18]
    26d1:	ff 76 ea             	push   WORD PTR [bp-0x16]
    26d4:	68 cc 00             	push   0xcc
    26d7:	6a 20                	push   0x20
    26d9:	9a 83 59 00 00       	call   0x0:0x5983
    26de:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    26e2:	74 0b                	je     0x26ef
    26e4:	ff 76 fa             	push   WORD PTR [bp-0x6]
    26e7:	ff 76 f6             	push   WORD PTR [bp-0xa]
    26ea:	9a fc 26 00 00       	call   0x0:0x26fc
    26ef:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    26f3:	74 0b                	je     0x2700
    26f5:	ff 76 f8             	push   WORD PTR [bp-0x8]
    26f8:	ff 76 f4             	push   WORD PTR [bp-0xc]
    26fb:	9a ef 51 00 00       	call   0x0:0x51ef
    2700:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2703:	9a 0c 27 00 00       	call   0x0:0x270c
    2708:	ff 76 f8             	push   WORD PTR [bp-0x8]
    270b:	9a 23 52 00 00       	call   0x0:0x5223
    2710:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2713:	c9                   	leave
    2714:	c2 08 00             	ret    0x8
    2717:	c8 02 00 00          	enter  0x2,0x0
    271b:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    271e:	3d 01 00             	cmp    ax,0x1
    2721:	74 0a                	je     0x272d
    2723:	3d 04 00             	cmp    ax,0x4
    2726:	74 05                	je     0x272d
    2728:	3d 08 00             	cmp    ax,0x8
    272b:	75 0d                	jne    0x273a
    272d:	b8 01 00             	mov    ax,0x1
    2730:	8b 4e 04             	mov    cx,WORD PTR [bp+0x4]
    2733:	d3 e0                	shl    ax,cl
    2735:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2738:	eb 05                	jmp    0x273f
    273a:	31 c0                	xor    ax,ax
    273c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    273f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2742:	c9                   	leave
    2743:	c2 02 00             	ret    0x2
    2746:	00 00                	add    BYTE PTR [bx+si],al
    2748:	ef                   	out    dx,ax
    2749:	28 50 27             	sub    BYTE PTR [bx+si+0x27],dl
    274c:	00 00                	add    BYTE PTR [bx+si],al
    274e:	14 29                	adc    al,0x29
    2750:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
    2751:	27                   	daa
    2752:	c8 5c 00 00          	enter  0x5c,0x0
    2756:	31 c0                	xor    ax,ax
    2758:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    275b:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    275e:	89 7e a6             	mov    WORD PTR [bp-0x5a],di
    2761:	8c 46 a8             	mov    WORD PTR [bp-0x58],es
    2764:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2768:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    276c:	74 09                	je     0x2777
    276e:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2772:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2775:	eb 0d                	jmp    0x2784
    2777:	c4 7e a6             	les    di,DWORD PTR [bp-0x5a]
    277a:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    277e:	e8 96 ff             	call   0x2717
    2781:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2784:	83 7e f8 02          	cmp    WORD PTR [bp-0x8],0x2
    2788:	7f 03                	jg     0x278d
    278a:	e9 96 01             	jmp    0x2923
    278d:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2790:	48                   	dec    ax
    2791:	c1 e0 02             	shl    ax,0x2
    2794:	05 08 00             	add    ax,0x8
    2797:	99                   	cwd
    2798:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    279b:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    279e:	ff 76 f4             	push   WORD PTR [bp-0xc]
    27a1:	ff 76 f2             	push   WORD PTR [bp-0xe]
    27a4:	9a af 25 2e 29       	call   0x292e:0x25af
    27a9:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    27ac:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    27af:	b8 4c 27             	mov    ax,0x274c
    27b2:	0e                   	push   cs
    27b3:	50                   	push   ax
    27b4:	55                   	push   bp
    27b5:	ff 36 58 18          	push   WORD PTR ds:0x1858
    27b9:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    27bd:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    27c0:	06                   	push   es
    27c1:	57                   	push   di
    27c2:	ff 76 f2             	push   WORD PTR [bp-0xe]
    27c5:	6a 00                	push   0x0
    27c7:	9a e5 1e 20 29       	call   0x2920:0x1ee5
    27cc:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    27cf:	89 7e a6             	mov    WORD PTR [bp-0x5a],di
    27d2:	8c 46 a8             	mov    WORD PTR [bp-0x58],es
    27d5:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    27d8:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    27dc:	26 c7 05 00 03       	mov    WORD PTR es:[di],0x300
    27e1:	9a 79 2a 00 00       	call   0x0:0x2a79
    27e6:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    27e9:	ff 76 ee             	push   WORD PTR [bp-0x12]
    27ec:	9a 84 2a 00 00       	call   0x0:0x2a84
    27f1:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    27f4:	b8 46 27             	mov    ax,0x2746
    27f7:	0e                   	push   cs
    27f8:	50                   	push   ax
    27f9:	55                   	push   bp
    27fa:	ff 36 58 18          	push   WORD PTR ds:0x1858
    27fe:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2802:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2805:	6a 68                	push   0x68
    2807:	9a 6f 32 00 00       	call   0x0:0x326f
    280c:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    280f:	83 7e f8 10          	cmp    WORD PTR [bp-0x8],0x10
    2813:	75 46                	jne    0x285b
    2815:	83 7e ac 10          	cmp    WORD PTR [bp-0x54],0x10
    2819:	7c 40                	jl     0x285b
    281b:	ff 76 f0             	push   WORD PTR [bp-0x10]
    281e:	6a 00                	push   0x0
    2820:	6a 08                	push   0x8
    2822:	c4 7e a6             	les    di,DWORD PTR [bp-0x5a]
    2825:	81 c7 04 00          	add    di,0x4
    2829:	06                   	push   es
    282a:	57                   	push   di
    282b:	9a 54 28 00 00       	call   0x0:0x2854
    2830:	c7 46 aa 08 00       	mov    WORD PTR [bp-0x56],0x8
    2835:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2838:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    283b:	2b 46 aa             	sub    ax,WORD PTR [bp-0x56]
    283e:	50                   	push   ax
    283f:	ff 76 aa             	push   WORD PTR [bp-0x56]
    2842:	8b 46 aa             	mov    ax,WORD PTR [bp-0x56]
    2845:	c1 e0 02             	shl    ax,0x2
    2848:	c4 7e a6             	les    di,DWORD PTR [bp-0x5a]
    284b:	03 f8                	add    di,ax
    284d:	81 c7 04 00          	add    di,0x4
    2851:	06                   	push   es
    2852:	57                   	push   di
    2853:	9a ff ff 00 00       	call   0x0:0xffff
    2858:	e9 88 00             	jmp    0x28e3
    285b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    285e:	48                   	dec    ax
    285f:	89 46 a4             	mov    WORD PTR [bp-0x5c],ax
    2862:	31 c0                	xor    ax,ax
    2864:	3b 46 a4             	cmp    ax,WORD PTR [bp-0x5c]
    2867:	7f 7a                	jg     0x28e3
    2869:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    286c:	eb 03                	jmp    0x2871
    286e:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    2871:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2874:	c1 e0 02             	shl    ax,0x2
    2877:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    287a:	03 f8                	add    di,ax
    287c:	26 8a 55 2a          	mov    dl,BYTE PTR es:[di+0x2a]
    2880:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2883:	c1 e0 02             	shl    ax,0x2
    2886:	c4 7e a6             	les    di,DWORD PTR [bp-0x5a]
    2889:	03 f8                	add    di,ax
    288b:	26 88 55 04          	mov    BYTE PTR es:[di+0x4],dl
    288f:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2892:	c1 e0 02             	shl    ax,0x2
    2895:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2898:	03 f8                	add    di,ax
    289a:	26 8a 55 29          	mov    dl,BYTE PTR es:[di+0x29]
    289e:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    28a1:	c1 e0 02             	shl    ax,0x2
    28a4:	c4 7e a6             	les    di,DWORD PTR [bp-0x5a]
    28a7:	03 f8                	add    di,ax
    28a9:	26 88 55 05          	mov    BYTE PTR es:[di+0x5],dl
    28ad:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    28b0:	c1 e0 02             	shl    ax,0x2
    28b3:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    28b6:	03 f8                	add    di,ax
    28b8:	26 8a 55 28          	mov    dl,BYTE PTR es:[di+0x28]
    28bc:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    28bf:	c1 e0 02             	shl    ax,0x2
    28c2:	c4 7e a6             	les    di,DWORD PTR [bp-0x5a]
    28c5:	03 f8                	add    di,ax
    28c7:	26 88 55 06          	mov    BYTE PTR es:[di+0x6],dl
    28cb:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    28ce:	c1 e0 02             	shl    ax,0x2
    28d1:	c4 7e a6             	les    di,DWORD PTR [bp-0x5a]
    28d4:	03 f8                	add    di,ax
    28d6:	26 c6 45 07 00       	mov    BYTE PTR es:[di+0x7],0x0
    28db:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    28de:	3b 46 a4             	cmp    ax,WORD PTR [bp-0x5c]
    28e1:	75 8b                	jne    0x286e
    28e3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    28e7:	83 c4 06             	add    sp,0x6
    28ea:	b8 fb 28             	mov    ax,0x28fb
    28ed:	0e                   	push   cs
    28ee:	50                   	push   ax
    28ef:	ff 76 ee             	push   WORD PTR [bp-0x12]
    28f2:	ff 76 f0             	push   WORD PTR [bp-0x10]
    28f5:	9a 38 2b 00 00       	call   0x0:0x2b38
    28fa:	cb                   	retf
    28fb:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    28fe:	06                   	push   es
    28ff:	57                   	push   di
    2900:	9a 8e 2c 00 00       	call   0x0:0x2c8e
    2905:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2908:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    290c:	83 c4 06             	add    sp,0x6
    290f:	b8 23 29             	mov    ax,0x2923
    2912:	0e                   	push   cs
    2913:	50                   	push   ax
    2914:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2917:	ff 76 fa             	push   WORD PTR [bp-0x6]
    291a:	ff 76 f2             	push   WORD PTR [bp-0xe]
    291d:	9a 9c 01 92 29       	call   0x2992:0x19c
    2922:	cb                   	retf
    2923:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2926:	c9                   	leave
    2927:	c2 04 00             	ret    0x4
    292a:	00 00                	add    BYTE PTR [bx+si],al
    292c:	11 2b                	adc    WORD PTR [bp+di],bp
    292e:	34 29                	xor    al,0x29
    2930:	00 00                	add    BYTE PTR [bx+si],al
    2932:	31 2b                	xor    WORD PTR [bp+di],bp
    2934:	3a 29                	cmp    ch,BYTE PTR [bx+di]
    2936:	00 00                	add    BYTE PTR [bx+si],al
    2938:	49                   	dec    cx
    2939:	2b 40 29             	sub    ax,WORD PTR [bx+si+0x29]
    293c:	00 00                	add    BYTE PTR [bx+si],al
    293e:	64 2b a4 29 c8       	sub    sp,WORD PTR fs:[si-0x37d7]
    2943:	44                   	inc    sp
    2944:	00 00                	add    BYTE PTR [bx+si],al
    2946:	8d 7e d2             	lea    di,[bp-0x2e]
    2949:	16                   	push   ss
    294a:	57                   	push   di
    294b:	6a 00                	push   0x0
    294d:	6a 24                	push   0x24
    294f:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2952:	06                   	push   es
    2953:	57                   	push   di
    2954:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2957:	26 ff 1d             	call   DWORD PTR es:[di]
    295a:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    295d:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    2960:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    2963:	89 56 d0             	mov    WORD PTR [bp-0x30],dx
    2966:	83 7e da 01          	cmp    WORD PTR [bp-0x26],0x1
    296a:	74 03                	je     0x296f
    296c:	e8 f4 fb             	call   0x2563
    296f:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2972:	0b 46 f0             	or     ax,WORD PTR [bp-0x10]
    2975:	75 0d                	jne    0x2984
    2977:	ff 76 dc             	push   WORD PTR [bp-0x24]
    297a:	e8 9a fd             	call   0x2717
    297d:	99                   	cwd
    297e:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2981:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    2984:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2987:	8b 56 f0             	mov    dx,WORD PTR [bp-0x10]
    298a:	b9 04 00             	mov    cx,0x4
    298d:	31 db                	xor    bx,bx
    298f:	9a 33 16 d2 29       	call   0x29d2:0x1633
    2994:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2997:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    299a:	05 28 00             	add    ax,0x28
    299d:	31 d2                	xor    dx,dx
    299f:	52                   	push   dx
    29a0:	50                   	push   ax
    29a1:	9a af 25 4c 2a       	call   0x2a4c:0x25af
    29a6:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    29a9:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    29ac:	b8 3c 29             	mov    ax,0x293c
    29af:	0e                   	push   cs
    29b0:	50                   	push   ax
    29b1:	55                   	push   bp
    29b2:	ff 36 58 18          	push   WORD PTR ds:0x1858
    29b6:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    29ba:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    29bd:	89 7e c0             	mov    WORD PTR [bp-0x40],di
    29c0:	8c 46 c2             	mov    WORD PTR [bp-0x3e],es
    29c3:	8d 7e ce             	lea    di,[bp-0x32]
    29c6:	16                   	push   ss
    29c7:	57                   	push   di
    29c8:	c4 7e c0             	les    di,DWORD PTR [bp-0x40]
    29cb:	06                   	push   es
    29cc:	57                   	push   di
    29cd:	6a 28                	push   0x28
    29cf:	9a 1b 16 55 2b       	call   0x2b55:0x161b
    29d4:	c4 7e c0             	les    di,DWORD PTR [bp-0x40]
    29d7:	81 c7 28 00          	add    di,0x28
    29db:	06                   	push   es
    29dc:	57                   	push   di
    29dd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    29e0:	31 d2                	xor    dx,dx
    29e2:	52                   	push   dx
    29e3:	50                   	push   ax
    29e4:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    29e7:	06                   	push   es
    29e8:	57                   	push   di
    29e9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29ec:	26 ff 1d             	call   DWORD PTR es:[di]
    29ef:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    29f2:	06                   	push   es
    29f3:	57                   	push   di
    29f4:	e8 5b fd             	call   0x2752
    29f7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    29fa:	26 89 05             	mov    WORD PTR es:[di],ax
    29fd:	c4 7e c0             	les    di,DWORD PTR [bp-0x40]
    2a00:	89 7e bc             	mov    WORD PTR [bp-0x44],di
    2a03:	8c 46 be             	mov    WORD PTR [bp-0x42],es
    2a06:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a09:	05 28 00             	add    ax,0x28
    2a0c:	31 d2                	xor    dx,dx
    2a0e:	29 46 04             	sub    WORD PTR [bp+0x4],ax
    2a11:	19 56 06             	sbb    WORD PTR [bp+0x6],dx
    2a14:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    2a18:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    2a1c:	74 25                	je     0x2a43
    2a1e:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    2a22:	26 8b 55 16          	mov    dx,WORD PTR es:[di+0x16]
    2a26:	3b 56 06             	cmp    dx,WORD PTR [bp+0x6]
    2a29:	7c 07                	jl     0x2a32
    2a2b:	7f 16                	jg     0x2a43
    2a2d:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
    2a30:	73 11                	jae    0x2a43
    2a32:	c4 7e bc             	les    di,DWORD PTR [bp-0x44]
    2a35:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    2a39:	26 8b 55 16          	mov    dx,WORD PTR es:[di+0x16]
    2a3d:	89 46 04             	mov    WORD PTR [bp+0x4],ax
    2a40:	89 56 06             	mov    WORD PTR [bp+0x6],dx
    2a43:	ff 76 06             	push   WORD PTR [bp+0x6]
    2a46:	ff 76 04             	push   WORD PTR [bp+0x4]
    2a49:	9a af 25 7f 2b       	call   0x2b7f:0x25af
    2a4e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2a51:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    2a54:	b8 36 29             	mov    ax,0x2936
    2a57:	0e                   	push   cs
    2a58:	50                   	push   ax
    2a59:	55                   	push   bp
    2a5a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2a5e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2a62:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2a65:	06                   	push   es
    2a66:	57                   	push   di
    2a67:	ff 76 06             	push   WORD PTR [bp+0x6]
    2a6a:	ff 76 04             	push   WORD PTR [bp+0x4]
    2a6d:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2a70:	06                   	push   es
    2a71:	57                   	push   di
    2a72:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a75:	26 ff 1d             	call   DWORD PTR es:[di]
    2a78:	9a c7 2d 00 00       	call   0x0:0x2dc7
    2a7d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a80:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2a83:	9a d2 2d 00 00       	call   0x0:0x2dd2
    2a88:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2a8b:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    2a8f:	75 03                	jne    0x2a94
    2a91:	e8 f0 fa             	call   0x2584
    2a94:	b8 30 29             	mov    ax,0x2930
    2a97:	0e                   	push   cs
    2a98:	50                   	push   ax
    2a99:	55                   	push   bp
    2a9a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2a9e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2aa2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2aa5:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    2aa9:	74 1a                	je     0x2ac5
    2aab:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2aae:	26 ff 35             	push   WORD PTR es:[di]
    2ab1:	6a 00                	push   0x0
    2ab3:	9a 20 2b 00 00       	call   0x0:0x2b20
    2ab8:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    2abb:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2abe:	9a 12 2e 00 00       	call   0x0:0x2e12
    2ac3:	eb 05                	jmp    0x2aca
    2ac5:	31 c0                	xor    ax,ax
    2ac7:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    2aca:	b8 2a 29             	mov    ax,0x292a
    2acd:	0e                   	push   cs
    2ace:	50                   	push   ax
    2acf:	55                   	push   bp
    2ad0:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2ad4:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2ad8:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2adb:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    2ade:	06                   	push   es
    2adf:	57                   	push   di
    2ae0:	6a 00                	push   0x0
    2ae2:	6a 04                	push   0x4
    2ae4:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2ae7:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2aea:	c4 7e ca             	les    di,DWORD PTR [bp-0x36]
    2aed:	06                   	push   es
    2aee:	57                   	push   di
    2aef:	6a 00                	push   0x0
    2af1:	9a 3e 2e 00 00       	call   0x0:0x2e3e
    2af6:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2af9:	26 89 05             	mov    WORD PTR es:[di],ax
    2afc:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    2b00:	75 03                	jne    0x2b05
    2b02:	e8 7f fa             	call   0x2584
    2b05:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2b09:	83 c4 06             	add    sp,0x6
    2b0c:	b8 25 2b             	mov    ax,0x2b25
    2b0f:	0e                   	push   cs
    2b10:	50                   	push   ax
    2b11:	83 7e c8 00          	cmp    WORD PTR [bp-0x38],0x0
    2b15:	74 0d                	je     0x2b24
    2b17:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2b1a:	ff 76 c8             	push   WORD PTR [bp-0x38]
    2b1d:	6a 00                	push   0x0
    2b1f:	9a 07 2e 00 00       	call   0x0:0x2e07
    2b24:	cb                   	retf
    2b25:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2b29:	83 c4 06             	add    sp,0x6
    2b2c:	b8 3d 2b             	mov    ax,0x2b3d
    2b2f:	0e                   	push   cs
    2b30:	50                   	push   ax
    2b31:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2b34:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2b37:	9a 84 2e 00 00       	call   0x0:0x2e84
    2b3c:	cb                   	retf
    2b3d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2b41:	83 c4 06             	add    sp,0x6
    2b44:	b8 58 2b             	mov    ax,0x2b58
    2b47:	0e                   	push   cs
    2b48:	50                   	push   ax
    2b49:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2b4c:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2b4f:	ff 76 04             	push   WORD PTR [bp+0x4]
    2b52:	9a 9c 01 74 2b       	call   0x2b74:0x19c
    2b57:	cb                   	retf
    2b58:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2b5c:	83 c4 06             	add    sp,0x6
    2b5f:	b8 77 2b             	mov    ax,0x2b77
    2b62:	0e                   	push   cs
    2b63:	50                   	push   ax
    2b64:	ff 76 cc             	push   WORD PTR [bp-0x34]
    2b67:	ff 76 ca             	push   WORD PTR [bp-0x36]
    2b6a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2b6d:	05 28 00             	add    ax,0x28
    2b70:	50                   	push   ax
    2b71:	9a 9c 01 cf 2b       	call   0x2bcf:0x19c
    2b76:	cb                   	retf
    2b77:	c9                   	leave
    2b78:	c2 14 00             	ret    0x14
    2b7b:	00 00                	add    BYTE PTR [bx+si],al
    2b7d:	a1 2c ba             	mov    ax,ds:0xba2c
    2b80:	2b c8                	sub    cx,ax
    2b82:	14 00                	adc    al,0x0
    2b84:	00 31                	add    BYTE PTR [bx+di],dh
    2b86:	c0 89 46 fe c4       	ror    BYTE PTR [bx+di-0x1ba],0xc4
    2b8b:	7e 04                	jle    0x2b91
    2b8d:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    2b91:	e8 83 fb             	call   0x2717
    2b94:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2b97:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    2b9b:	75 03                	jne    0x2ba0
    2b9d:	e9 10 01             	jmp    0x2cb0
    2ba0:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2ba3:	48                   	dec    ax
    2ba4:	c1 e0 02             	shl    ax,0x2
    2ba7:	05 08 00             	add    ax,0x8
    2baa:	99                   	cwd
    2bab:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2bae:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    2bb1:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2bb4:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2bb7:	9a af 25 bb 2c       	call   0x2cbb:0x25af
    2bbc:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2bbf:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2bc2:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2bc5:	06                   	push   es
    2bc6:	57                   	push   di
    2bc7:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2bca:	6a 00                	push   0x0
    2bcc:	9a e5 1e ad 2c       	call   0x2cad:0x1ee5
    2bd1:	b8 7b 2b             	mov    ax,0x2b7b
    2bd4:	0e                   	push   cs
    2bd5:	50                   	push   ax
    2bd6:	55                   	push   bp
    2bd7:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2bdb:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2bdf:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2be2:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    2be5:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    2be8:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2beb:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    2bef:	26 c7 05 00 03       	mov    WORD PTR es:[di],0x300
    2bf4:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2bf7:	48                   	dec    ax
    2bf8:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2bfb:	31 c0                	xor    ax,ax
    2bfd:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    2c00:	7e 03                	jle    0x2c05
    2c02:	e9 83 00             	jmp    0x2c88
    2c05:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2c08:	eb 03                	jmp    0x2c0d
    2c0a:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    2c0d:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2c10:	8b f0                	mov    si,ax
    2c12:	d1 e0                	shl    ax,1
    2c14:	01 f0                	add    ax,si
    2c16:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2c19:	03 f8                	add    di,ax
    2c1b:	26 8a 55 0e          	mov    dl,BYTE PTR es:[di+0xe]
    2c1f:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2c22:	c1 e0 02             	shl    ax,0x2
    2c25:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    2c28:	03 f8                	add    di,ax
    2c2a:	26 88 55 04          	mov    BYTE PTR es:[di+0x4],dl
    2c2e:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2c31:	8b f0                	mov    si,ax
    2c33:	d1 e0                	shl    ax,1
    2c35:	01 f0                	add    ax,si
    2c37:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2c3a:	03 f8                	add    di,ax
    2c3c:	26 8a 55 0d          	mov    dl,BYTE PTR es:[di+0xd]
    2c40:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2c43:	c1 e0 02             	shl    ax,0x2
    2c46:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    2c49:	03 f8                	add    di,ax
    2c4b:	26 88 55 05          	mov    BYTE PTR es:[di+0x5],dl
    2c4f:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2c52:	8b f0                	mov    si,ax
    2c54:	d1 e0                	shl    ax,1
    2c56:	01 f0                	add    ax,si
    2c58:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2c5b:	03 f8                	add    di,ax
    2c5d:	26 8a 55 0c          	mov    dl,BYTE PTR es:[di+0xc]
    2c61:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2c64:	c1 e0 02             	shl    ax,0x2
    2c67:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    2c6a:	03 f8                	add    di,ax
    2c6c:	26 88 55 06          	mov    BYTE PTR es:[di+0x6],dl
    2c70:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2c73:	c1 e0 02             	shl    ax,0x2
    2c76:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    2c79:	03 f8                	add    di,ax
    2c7b:	26 c6 45 07 00       	mov    BYTE PTR es:[di+0x7],0x0
    2c80:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2c83:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    2c86:	75 82                	jne    0x2c0a
    2c88:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2c8b:	06                   	push   es
    2c8c:	57                   	push   di
    2c8d:	9a 94 56 00 00       	call   0x0:0x5694
    2c92:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2c95:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2c99:	83 c4 06             	add    sp,0x6
    2c9c:	b8 b0 2c             	mov    ax,0x2cb0
    2c9f:	0e                   	push   cs
    2ca0:	50                   	push   ax
    2ca1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2ca4:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2ca7:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2caa:	9a 9c 01 46 2d       	call   0x2d46:0x19c
    2caf:	cb                   	retf
    2cb0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2cb3:	c9                   	leave
    2cb4:	c2 04 00             	ret    0x4
    2cb7:	00 00                	add    BYTE PTR [bx+si],al
    2cb9:	5d                   	pop    bp
    2cba:	2e c1 2c 00          	shr    WORD PTR cs:[si],0x0
    2cbe:	00 7d 2e             	add    BYTE PTR [di+0x2e],bh
    2cc1:	c7                   	(bad)
    2cc2:	2c 00                	sub    al,0x0
    2cc4:	00 95 2e cd          	add    BYTE PTR [di-0x32d2],dl
    2cc8:	2c 00                	sub    al,0x0
    2cca:	00 b0 2e 18          	add    BYTE PTR [bx+si+0x182e],dh
    2cce:	2d c8 28             	sub    ax,0x28c8
    2cd1:	00 00                	add    BYTE PTR [bx+si],al
    2cd3:	8d 7e ee             	lea    di,[bp-0x12]
    2cd6:	16                   	push   ss
    2cd7:	57                   	push   di
    2cd8:	6a 00                	push   0x0
    2cda:	6a 08                	push   0x8
    2cdc:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2cdf:	06                   	push   es
    2ce0:	57                   	push   di
    2ce1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ce4:	26 ff 1d             	call   DWORD PTR es:[di]
    2ce7:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    2cea:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    2ced:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    2cf0:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    2cf3:	83 7e f2 01          	cmp    WORD PTR [bp-0xe],0x1
    2cf7:	74 03                	je     0x2cfc
    2cf9:	e8 67 f8             	call   0x2563
    2cfc:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2cff:	e8 15 fa             	call   0x2717
    2d02:	8b f0                	mov    si,ax
    2d04:	d1 e0                	shl    ax,1
    2d06:	01 f0                	add    ax,si
    2d08:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d0b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d0e:	05 0f 00             	add    ax,0xf
    2d11:	31 d2                	xor    dx,dx
    2d13:	52                   	push   dx
    2d14:	50                   	push   ax
    2d15:	9a af 25 9a 2d       	call   0x2d9a:0x25af
    2d1a:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    2d1d:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    2d20:	b8 c9 2c             	mov    ax,0x2cc9
    2d23:	0e                   	push   cs
    2d24:	50                   	push   ax
    2d25:	55                   	push   bp
    2d26:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2d2a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2d2e:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    2d31:	89 7e dc             	mov    WORD PTR [bp-0x24],di
    2d34:	8c 46 de             	mov    WORD PTR [bp-0x22],es
    2d37:	8d 7e ea             	lea    di,[bp-0x16]
    2d3a:	16                   	push   ss
    2d3b:	57                   	push   di
    2d3c:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    2d3f:	06                   	push   es
    2d40:	57                   	push   di
    2d41:	6a 0c                	push   0xc
    2d43:	9a 1b 16 a1 2e       	call   0x2ea1:0x161b
    2d48:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    2d4b:	81 c7 0c 00          	add    di,0xc
    2d4f:	06                   	push   es
    2d50:	57                   	push   di
    2d51:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d54:	31 d2                	xor    dx,dx
    2d56:	52                   	push   dx
    2d57:	50                   	push   ax
    2d58:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2d5b:	06                   	push   es
    2d5c:	57                   	push   di
    2d5d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d60:	26 ff 1d             	call   DWORD PTR es:[di]
    2d63:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    2d66:	06                   	push   es
    2d67:	57                   	push   di
    2d68:	e8 16 fe             	call   0x2b81
    2d6b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2d6e:	26 89 05             	mov    WORD PTR es:[di],ax
    2d71:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    2d74:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2d78:	26 f7 65 0a          	mul    WORD PTR es:[di+0xa]
    2d7c:	05 1f 00             	add    ax,0x1f
    2d7f:	c1 e8 05             	shr    ax,0x5
    2d82:	c1 e0 02             	shl    ax,0x2
    2d85:	26 f7 65 06          	mul    WORD PTR es:[di+0x6]
    2d89:	31 d2                	xor    dx,dx
    2d8b:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2d8e:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    2d91:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    2d94:	ff 76 e0             	push   WORD PTR [bp-0x20]
    2d97:	9a af 25 ac 2f       	call   0x2fac:0x25af
    2d9c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2d9f:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    2da2:	b8 c3 2c             	mov    ax,0x2cc3
    2da5:	0e                   	push   cs
    2da6:	50                   	push   ax
    2da7:	55                   	push   bp
    2da8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2dac:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2db0:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2db3:	06                   	push   es
    2db4:	57                   	push   di
    2db5:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    2db8:	ff 76 e0             	push   WORD PTR [bp-0x20]
    2dbb:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2dbe:	06                   	push   es
    2dbf:	57                   	push   di
    2dc0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2dc3:	26 ff 1d             	call   DWORD PTR es:[di]
    2dc6:	9a 1b 38 00 00       	call   0x0:0x381b
    2dcb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2dce:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2dd1:	9a 38 30 00 00       	call   0x0:0x3038
    2dd6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2dd9:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    2ddd:	75 03                	jne    0x2de2
    2ddf:	e8 a2 f7             	call   0x2584
    2de2:	b8 bd 2c             	mov    ax,0x2cbd
    2de5:	0e                   	push   cs
    2de6:	50                   	push   ax
    2de7:	55                   	push   bp
    2de8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2dec:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2df0:	31 c0                	xor    ax,ax
    2df2:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2df5:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2df8:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    2dfc:	74 18                	je     0x2e16
    2dfe:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e01:	26 ff 35             	push   WORD PTR es:[di]
    2e04:	6a 00                	push   0x0
    2e06:	9a 6c 2e 00 00       	call   0x0:0x2e6c
    2e0b:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2e0e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e11:	9a 55 38 00 00       	call   0x0:0x3855
    2e16:	b8 b7 2c             	mov    ax,0x2cb7
    2e19:	0e                   	push   cs
    2e1a:	50                   	push   ax
    2e1b:	55                   	push   bp
    2e1c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2e20:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2e24:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e27:	c4 7e dc             	les    di,DWORD PTR [bp-0x24]
    2e2a:	06                   	push   es
    2e2b:	57                   	push   di
    2e2c:	6a 00                	push   0x0
    2e2e:	6a 04                	push   0x4
    2e30:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2e33:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2e36:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    2e39:	06                   	push   es
    2e3a:	57                   	push   di
    2e3b:	6a 00                	push   0x0
    2e3d:	9a 88 30 00 00       	call   0x0:0x3088
    2e42:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2e45:	26 89 05             	mov    WORD PTR es:[di],ax
    2e48:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    2e4c:	75 03                	jne    0x2e51
    2e4e:	e8 33 f7             	call   0x2584
    2e51:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2e55:	83 c4 06             	add    sp,0x6
    2e58:	b8 71 2e             	mov    ax,0x2e71
    2e5b:	0e                   	push   cs
    2e5c:	50                   	push   ax
    2e5d:	83 7e e4 00          	cmp    WORD PTR [bp-0x1c],0x0
    2e61:	74 0d                	je     0x2e70
    2e63:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e66:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    2e69:	6a 00                	push   0x0
    2e6b:	9a 4a 38 00 00       	call   0x0:0x384a
    2e70:	cb                   	retf
    2e71:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2e75:	83 c4 06             	add    sp,0x6
    2e78:	b8 89 2e             	mov    ax,0x2e89
    2e7b:	0e                   	push   cs
    2e7c:	50                   	push   ax
    2e7d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2e80:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e83:	9a d1 31 00 00       	call   0x0:0x31d1
    2e88:	cb                   	retf
    2e89:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2e8d:	83 c4 06             	add    sp,0x6
    2e90:	b8 a4 2e             	mov    ax,0x2ea4
    2e93:	0e                   	push   cs
    2e94:	50                   	push   ax
    2e95:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2e98:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2e9b:	ff 76 e0             	push   WORD PTR [bp-0x20]
    2e9e:	9a 9c 01 c0 2e       	call   0x2ec0:0x19c
    2ea3:	cb                   	retf
    2ea4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2ea8:	83 c4 06             	add    sp,0x6
    2eab:	b8 c3 2e             	mov    ax,0x2ec3
    2eae:	0e                   	push   cs
    2eaf:	50                   	push   ax
    2eb0:	ff 76 e8             	push   WORD PTR [bp-0x18]
    2eb3:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    2eb6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2eb9:	05 0f 00             	add    ax,0xf
    2ebc:	50                   	push   ax
    2ebd:	9a 9c 01 58 2f       	call   0x2f58:0x19c
    2ec2:	cb                   	retf
    2ec3:	c9                   	leave
    2ec4:	c2 14 00             	ret    0x14
    2ec7:	c8 04 00 00          	enter  0x4,0x0
    2ecb:	8d 7e fc             	lea    di,[bp-0x4]
    2ece:	16                   	push   ss
    2ecf:	57                   	push   di
    2ed0:	6a 00                	push   0x0
    2ed2:	6a 04                	push   0x4
    2ed4:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2ed7:	06                   	push   es
    2ed8:	57                   	push   di
    2ed9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2edc:	26 ff 1d             	call   DWORD PTR es:[di]
    2edf:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2ee3:	75 27                	jne    0x2f0c
    2ee5:	83 7e fc 28          	cmp    WORD PTR [bp-0x4],0x28
    2ee9:	75 21                	jne    0x2f0c
    2eeb:	ff 76 12             	push   WORD PTR [bp+0x12]
    2eee:	ff 76 10             	push   WORD PTR [bp+0x10]
    2ef1:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2ef4:	06                   	push   es
    2ef5:	57                   	push   di
    2ef6:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2ef9:	06                   	push   es
    2efa:	57                   	push   di
    2efb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2efe:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2f01:	ff 76 06             	push   WORD PTR [bp+0x6]
    2f04:	ff 76 04             	push   WORD PTR [bp+0x4]
    2f07:	e8 38 fa             	call   0x2942
    2f0a:	eb 30                	jmp    0x2f3c
    2f0c:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2f10:	75 27                	jne    0x2f39
    2f12:	83 7e fc 0c          	cmp    WORD PTR [bp-0x4],0xc
    2f16:	75 21                	jne    0x2f39
    2f18:	ff 76 12             	push   WORD PTR [bp+0x12]
    2f1b:	ff 76 10             	push   WORD PTR [bp+0x10]
    2f1e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f21:	06                   	push   es
    2f22:	57                   	push   di
    2f23:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2f26:	06                   	push   es
    2f27:	57                   	push   di
    2f28:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f2b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2f2e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2f31:	ff 76 04             	push   WORD PTR [bp+0x4]
    2f34:	e8 98 fd             	call   0x2ccf
    2f37:	eb 03                	jmp    0x2f3c
    2f39:	e8 27 f6             	call   0x2563
    2f3c:	c9                   	leave
    2f3d:	c2 10 00             	ret    0x10
    2f40:	c8 04 00 00          	enter  0x4,0x0
    2f44:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    2f47:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    2f4a:	05 1f 00             	add    ax,0x1f
    2f4d:	83 d2 00             	adc    dx,0x0
    2f50:	b9 20 00             	mov    cx,0x20
    2f53:	31 db                	xor    bx,bx
    2f55:	9a 70 16 62 2f       	call   0x2f62:0x1670
    2f5a:	b9 04 00             	mov    cx,0x4
    2f5d:	31 db                	xor    bx,bx
    2f5f:	9a 33 16 8c 2f       	call   0x2f8c:0x1633
    2f64:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2f67:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2f6a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f6d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2f70:	c9                   	leave
    2f71:	c2 04 00             	ret    0x4
    2f74:	c8 04 00 00          	enter  0x4,0x0
    2f78:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    2f7b:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    2f7e:	05 0f 00             	add    ax,0xf
    2f81:	83 d2 00             	adc    dx,0x0
    2f84:	b9 10 00             	mov    cx,0x10
    2f87:	31 db                	xor    bx,bx
    2f89:	9a 70 16 96 2f       	call   0x2f96:0x1670
    2f8e:	b9 02 00             	mov    cx,0x2
    2f91:	31 db                	xor    bx,bx
    2f93:	9a 33 16 eb 2f       	call   0x2feb:0x1633
    2f98:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2f9b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2f9e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2fa1:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2fa4:	c9                   	leave
    2fa5:	c2 04 00             	ret    0x4
    2fa8:	00 00                	add    BYTE PTR [bx+si],al
    2faa:	c6                   	(bad)
    2fab:	30 b2 2f 00          	xor    BYTE PTR [bp+si+0x2f],dh
    2faf:	00 b6 31 b8          	add    BYTE PTR [bp-0x47cf],dh
    2fb3:	2f                   	das
    2fb4:	00 00                	add    BYTE PTR [bx+si],al
    2fb6:	cb                   	retf
    2fb7:	31 de                	xor    si,bx
    2fb9:	31 c8                	xor    ax,cx
    2fbb:	16                   	push   ss
    2fbc:	00 00                	add    BYTE PTR [bx+si],al
    2fbe:	6a 0b                	push   0xb
    2fc0:	9a cb 2f 00 00       	call   0x0:0x2fcb
    2fc5:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2fc8:	6a 0c                	push   0xc
    2fca:	9a 37 32 00 00       	call   0x0:0x3237
    2fcf:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2fd2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2fd5:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    2fd8:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    2fdb:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2fdf:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    2fe3:	b9 01 00             	mov    cx,0x1
    2fe6:	31 db                	xor    bx,bx
    2fe8:	9a 16 17 09 30       	call   0x3009:0x1716
    2fed:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    2ff0:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2ff4:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    2ff8:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    2ffc:	31 d2                	xor    dx,dx
    2ffe:	26 8b 4d 04          	mov    cx,WORD PTR es:[di+0x4]
    3002:	26 8b 5d 06          	mov    bx,WORD PTR es:[di+0x6]
    3006:	9a 33 16 1e 30       	call   0x301e:0x1633
    300b:	52                   	push   dx
    300c:	50                   	push   ax
    300d:	e8 30 ff             	call   0x2f40
    3010:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    3013:	26 8b 4d 08          	mov    cx,WORD PTR es:[di+0x8]
    3017:	26 8b 5d 0a          	mov    bx,WORD PTR es:[di+0xa]
    301b:	9a 33 16 fd 30       	call   0x30fd:0x1633
    3020:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    3023:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    3027:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    302b:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    302f:	e8 e5 f6             	call   0x2717
    3032:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3035:	6a 00                	push   0x0
    3037:	9a 4b 32 00 00       	call   0x0:0x324b
    303c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    303f:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    3043:	75 03                	jne    0x3048
    3045:	e8 3c f5             	call   0x2584
    3048:	b8 b4 2f             	mov    ax,0x2fb4
    304b:	0e                   	push   cs
    304c:	50                   	push   ax
    304d:	55                   	push   bp
    304e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3052:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3056:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3059:	c1 e0 02             	shl    ax,0x2
    305c:	99                   	cwd
    305d:	8b c8                	mov    cx,ax
    305f:	8b da                	mov    bx,dx
    3061:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3064:	26 8d 45 28          	lea    ax,es:[di+0x28]
    3068:	8c c2                	mov    dx,es
    306a:	03 c1                	add    ax,cx
    306c:	13 d3                	adc    dx,bx
    306e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3071:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    3074:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3077:	06                   	push   es
    3078:	57                   	push   di
    3079:	6a 00                	push   0x0
    307b:	6a 04                	push   0x4
    307d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3080:	ff 76 f6             	push   WORD PTR [bp-0xa]
    3083:	06                   	push   es
    3084:	57                   	push   di
    3085:	6a 00                	push   0x0
    3087:	9a 78 31 00 00       	call   0x0:0x3178
    308c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    308f:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3093:	75 03                	jne    0x3098
    3095:	e8 ec f4             	call   0x2584
    3098:	b8 a8 2f             	mov    ax,0x2fa8
    309b:	0e                   	push   cs
    309c:	50                   	push   ax
    309d:	55                   	push   bp
    309e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    30a2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    30a6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    30a9:	ff 76 f0             	push   WORD PTR [bp-0x10]
    30ac:	ff 76 ee             	push   WORD PTR [bp-0x12]
    30af:	6a 00                	push   0x0
    30b1:	e8 4d f5             	call   0x2601
    30b4:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    30b7:	26 89 05             	mov    WORD PTR es:[di],ax
    30ba:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    30be:	83 c4 06             	add    sp,0x6
    30c1:	b8 cf 30             	mov    ax,0x30cf
    30c4:	0e                   	push   cs
    30c5:	50                   	push   ax
    30c6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    30c9:	9a ba 31 00 00       	call   0x0:0x31ba
    30ce:	cb                   	retf
    30cf:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    30d2:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    30d5:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    30d8:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    30dc:	26 8b 55 16          	mov    dx,WORD PTR es:[di+0x16]
    30e0:	01 46 f6             	add    WORD PTR [bp-0xa],ax
    30e3:	11 56 f8             	adc    WORD PTR [bp-0x8],dx
    30e6:	26 c7 45 0e 01 00    	mov    WORD PTR es:[di+0xe],0x1
    30ec:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    30f0:	31 d2                	xor    dx,dx
    30f2:	26 8b 4d 04          	mov    cx,WORD PTR es:[di+0x4]
    30f6:	26 8b 5d 06          	mov    bx,WORD PTR es:[di+0x6]
    30fa:	9a 33 16 12 31       	call   0x3112:0x1633
    30ff:	52                   	push   dx
    3100:	50                   	push   ax
    3101:	e8 3c fe             	call   0x2f40
    3104:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    3107:	26 8b 4d 08          	mov    cx,WORD PTR es:[di+0x8]
    310b:	26 8b 5d 0a          	mov    bx,WORD PTR es:[di+0xa]
    310f:	9a 33 16 09 35       	call   0x3509:0x1633
    3114:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    3117:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    311b:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    311f:	26 c7 45 20 02 00    	mov    WORD PTR es:[di+0x20],0x2
    3125:	26 c7 45 22 00 00    	mov    WORD PTR es:[di+0x22],0x0
    312b:	26 c7 45 24 02 00    	mov    WORD PTR es:[di+0x24],0x2
    3131:	26 c7 45 26 00 00    	mov    WORD PTR es:[di+0x26],0x0
    3137:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    313a:	26 8d 45 28          	lea    ax,es:[di+0x28]
    313e:	8c c2                	mov    dx,es
    3140:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3143:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    3146:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3149:	31 c0                	xor    ax,ax
    314b:	26 89 05             	mov    WORD PTR es:[di],ax
    314e:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    3152:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3155:	26 c7 45 04 ff ff    	mov    WORD PTR es:[di+0x4],0xffff
    315b:	26 c7 45 06 ff 00    	mov    WORD PTR es:[di+0x6],0xff
    3161:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3164:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3167:	06                   	push   es
    3168:	57                   	push   di
    3169:	6a 00                	push   0x0
    316b:	6a 04                	push   0x4
    316d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3170:	ff 76 f6             	push   WORD PTR [bp-0xa]
    3173:	06                   	push   es
    3174:	57                   	push   di
    3175:	6a 00                	push   0x0
    3177:	9a ff ff 00 00       	call   0x0:0xffff
    317c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    317f:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3183:	75 03                	jne    0x3188
    3185:	e8 fc f3             	call   0x2584
    3188:	b8 ae 2f             	mov    ax,0x2fae
    318b:	0e                   	push   cs
    318c:	50                   	push   ax
    318d:	55                   	push   bp
    318e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3192:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3196:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3199:	ff 76 f0             	push   WORD PTR [bp-0x10]
    319c:	ff 76 ee             	push   WORD PTR [bp-0x12]
    319f:	6a 01                	push   0x1
    31a1:	e8 5d f4             	call   0x2601
    31a4:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    31a7:	26 89 05             	mov    WORD PTR es:[di],ax
    31aa:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    31ae:	83 c4 06             	add    sp,0x6
    31b1:	b8 bf 31             	mov    ax,0x31bf
    31b4:	0e                   	push   cs
    31b5:	50                   	push   ax
    31b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    31b9:	9a b3 34 00 00       	call   0x0:0x34b3
    31be:	cb                   	retf
    31bf:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    31c3:	83 c4 06             	add    sp,0x6
    31c6:	b8 d6 31             	mov    ax,0x31d6
    31c9:	0e                   	push   cs
    31ca:	50                   	push   ax
    31cb:	6a 00                	push   0x0
    31cd:	ff 76 fa             	push   WORD PTR [bp-0x6]
    31d0:	9a ae 32 00 00       	call   0x0:0x32ae
    31d5:	cb                   	retf
    31d6:	c9                   	leave
    31d7:	c2 0c 00             	ret    0xc
    31da:	00 00                	add    BYTE PTR [bx+si],al
    31dc:	a8 32                	test   al,0x32
    31de:	e4 31                	in     al,0x31
    31e0:	00 00                	add    BYTE PTR [bx+si],al
    31e2:	fd                   	std
    31e3:	34 ea                	xor    al,0xea
    31e5:	31 00                	xor    WORD PTR [bx+si],ax
    31e7:	00 18                	add    BYTE PTR [bx+si],bl
    31e9:	35 f0 31             	xor    ax,0x31f0
    31ec:	00 00                	add    BYTE PTR [bx+si],al
    31ee:	37                   	aaa
    31ef:	35 08 32             	xor    ax,0x3208
    31f2:	c8 52 00 00          	enter  0x52,0x0
    31f6:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    31f9:	c1 e0 04             	shl    ax,0x4
    31fc:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    31ff:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3202:	99                   	cwd
    3203:	52                   	push   dx
    3204:	50                   	push   ax
    3205:	9a af 25 94 33       	call   0x3394:0x25af
    320a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    320d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3210:	b8 ec 31             	mov    ax,0x31ec
    3213:	0e                   	push   cs
    3214:	50                   	push   ax
    3215:	55                   	push   bp
    3216:	ff 36 58 18          	push   WORD PTR ds:0x1858
    321a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    321e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3221:	06                   	push   es
    3222:	57                   	push   di
    3223:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3226:	99                   	cwd
    3227:	52                   	push   dx
    3228:	50                   	push   ax
    3229:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    322c:	06                   	push   es
    322d:	57                   	push   di
    322e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3231:	26 ff 1d             	call   DWORD PTR es:[di]
    3234:	6a 0b                	push   0xb
    3236:	9a 41 32 00 00       	call   0x0:0x3241
    323b:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    323e:	6a 0c                	push   0xc
    3240:	9a be 65 00 00       	call   0x0:0x65be
    3245:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    3248:	6a 00                	push   0x0
    324a:	9a 26 38 00 00       	call   0x0:0x3826
    324f:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    3252:	83 7e e6 00          	cmp    WORD PTR [bp-0x1a],0x0
    3256:	75 03                	jne    0x325b
    3258:	e8 29 f3             	call   0x2584
    325b:	b8 da 31             	mov    ax,0x31da
    325e:	0e                   	push   cs
    325f:	50                   	push   ax
    3260:	55                   	push   bp
    3261:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3265:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3269:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    326c:	6a 0c                	push   0xc
    326e:	9a 7a 32 00 00       	call   0x0:0x327a
    3273:	50                   	push   ax
    3274:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3277:	6a 0e                	push   0xe
    3279:	9a ec 3a 00 00       	call   0x0:0x3aec
    327e:	5a                   	pop    dx
    327f:	f7 e2                	mul    dx
    3281:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3284:	83 7e f4 18          	cmp    WORD PTR [bp-0xc],0x18
    3288:	75 07                	jne    0x3291
    328a:	31 c0                	xor    ax,ax
    328c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    328f:	eb 0b                	jmp    0x329c
    3291:	b8 01 00             	mov    ax,0x1
    3294:	8b 4e f4             	mov    cx,WORD PTR [bp-0xc]
    3297:	d3 e0                	shl    ax,cl
    3299:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    329c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    32a0:	83 c4 06             	add    sp,0x6
    32a3:	b8 b3 32             	mov    ax,0x32b3
    32a6:	0e                   	push   cs
    32a7:	50                   	push   ax
    32a8:	6a 00                	push   0x0
    32aa:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    32ad:	9a a9 38 00 00       	call   0x0:0x38a9
    32b2:	cb                   	retf
    32b3:	c7 46 ec ff ff       	mov    WORD PTR [bp-0x14],0xffff
    32b8:	31 c0                	xor    ax,ax
    32ba:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    32bd:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    32c0:	48                   	dec    ax
    32c1:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    32c4:	31 c0                	xor    ax,ax
    32c6:	3b 46 b0             	cmp    ax,WORD PTR [bp-0x50]
    32c9:	7e 03                	jle    0x32ce
    32cb:	e9 89 00             	jmp    0x3357
    32ce:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    32d1:	eb 03                	jmp    0x32d6
    32d3:	ff 46 ee             	inc    WORD PTR [bp-0x12]
    32d6:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    32d9:	c1 e0 04             	shl    ax,0x4
    32dc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32df:	03 f8                	add    di,ax
    32e1:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    32e5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    32e8:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    32eb:	31 d2                	xor    dx,dx
    32ed:	8b c8                	mov    cx,ax
    32ef:	8b da                	mov    bx,dx
    32f1:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    32f4:	99                   	cwd
    32f5:	3b d3                	cmp    dx,bx
    32f7:	75 0e                	jne    0x3307
    32f9:	3b c1                	cmp    ax,cx
    32fb:	75 0a                	jne    0x3307
    32fd:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    3300:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3303:	eb 52                	jmp    0x3357
    3305:	eb 45                	jmp    0x334c
    3307:	83 7e ec ff          	cmp    WORD PTR [bp-0x14],0xffff
    330b:	75 31                	jne    0x333e
    330d:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    3310:	31 d2                	xor    dx,dx
    3312:	8b c8                	mov    cx,ax
    3314:	8b da                	mov    bx,dx
    3316:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3319:	99                   	cwd
    331a:	3b d3                	cmp    dx,bx
    331c:	7c 06                	jl     0x3324
    331e:	7f 1c                	jg     0x333c
    3320:	3b c1                	cmp    ax,cx
    3322:	77 18                	ja     0x333c
    3324:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    3327:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    332a:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    332d:	c1 e0 04             	shl    ax,0x4
    3330:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3333:	03 f8                	add    di,ax
    3335:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    3339:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    333c:	eb 0e                	jmp    0x334c
    333e:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3341:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    3344:	7e 06                	jle    0x334c
    3346:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    3349:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    334c:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    334f:	3b 46 b0             	cmp    ax,WORD PTR [bp-0x50]
    3352:	74 03                	je     0x3357
    3354:	e9 7c ff             	jmp    0x32d3
    3357:	83 7e ec ff          	cmp    WORD PTR [bp-0x14],0xffff
    335b:	75 05                	jne    0x3362
    335d:	31 c0                	xor    ax,ax
    335f:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3362:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    3365:	c1 e0 04             	shl    ax,0x4
    3368:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    336b:	03 f8                	add    di,ax
    336d:	89 7e ae             	mov    WORD PTR [bp-0x52],di
    3370:	8c 46 b0             	mov    WORD PTR [bp-0x50],es
    3373:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    3378:	7f 09                	jg     0x3383
    337a:	7c 0a                	jl     0x3386
    337c:	26 83 7d 08 ff       	cmp    WORD PTR es:[di+0x8],0xffff
    3381:	72 03                	jb     0x3386
    3383:	e8 e8 f1             	call   0x256e
    3386:	c4 7e ae             	les    di,DWORD PTR [bp-0x52]
    3389:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    338d:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    3391:	9a af 25 55 34       	call   0x3455:0x25af
    3396:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    3399:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    339c:	b8 e6 31             	mov    ax,0x31e6
    339f:	0e                   	push   cs
    33a0:	50                   	push   ax
    33a1:	55                   	push   bp
    33a2:	ff 36 58 18          	push   WORD PTR ds:0x1858
    33a6:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    33aa:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    33ad:	03 46 04             	add    ax,WORD PTR [bp+0x4]
    33b0:	99                   	cwd
    33b1:	8b c8                	mov    cx,ax
    33b3:	8b da                	mov    bx,dx
    33b5:	c4 7e ae             	les    di,DWORD PTR [bp-0x52]
    33b8:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    33bc:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    33c0:	2b c1                	sub    ax,cx
    33c2:	1b d3                	sbb    dx,bx
    33c4:	52                   	push   dx
    33c5:	50                   	push   ax
    33c6:	6a 01                	push   0x1
    33c8:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    33cb:	06                   	push   es
    33cc:	57                   	push   di
    33cd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33d0:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    33d4:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    33d7:	06                   	push   es
    33d8:	57                   	push   di
    33d9:	c4 7e ae             	les    di,DWORD PTR [bp-0x52]
    33dc:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    33e0:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    33e4:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    33e7:	06                   	push   es
    33e8:	57                   	push   di
    33e9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33ec:	26 ff 1d             	call   DWORD PTR es:[di]
    33ef:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    33f2:	06                   	push   es
    33f3:	57                   	push   di
    33f4:	8d 7e dc             	lea    di,[bp-0x24]
    33f7:	16                   	push   ss
    33f8:	57                   	push   di
    33f9:	8d 7e da             	lea    di,[bp-0x26]
    33fc:	16                   	push   ss
    33fd:	57                   	push   di
    33fe:	e8 b9 fb             	call   0x2fba
    3401:	ff 76 da             	push   WORD PTR [bp-0x26]
    3404:	6a 0e                	push   0xe
    3406:	8d 7e be             	lea    di,[bp-0x42]
    3409:	16                   	push   ss
    340a:	57                   	push   di
    340b:	9a 1b 34 00 00       	call   0x0:0x341b
    3410:	ff 76 dc             	push   WORD PTR [bp-0x24]
    3413:	6a 0e                	push   0xe
    3415:	8d 7e cc             	lea    di,[bp-0x34]
    3418:	16                   	push   ss
    3419:	57                   	push   di
    341a:	9a 93 36 00 00       	call   0x0:0x3693
    341f:	8a 46 c6             	mov    al,BYTE PTR [bp-0x3a]
    3422:	30 e4                	xor    ah,ah
    3424:	8b c8                	mov    cx,ax
    3426:	8b 46 c4             	mov    ax,WORD PTR [bp-0x3c]
    3429:	f7 66 c2             	mul    WORD PTR [bp-0x3e]
    342c:	f7 e1                	mul    cx
    342e:	89 46 b2             	mov    WORD PTR [bp-0x4e],ax
    3431:	8a 46 d4             	mov    al,BYTE PTR [bp-0x2c]
    3434:	30 e4                	xor    ah,ah
    3436:	8b c8                	mov    cx,ax
    3438:	8b 46 d2             	mov    ax,WORD PTR [bp-0x2e]
    343b:	f7 66 d0             	mul    WORD PTR [bp-0x30]
    343e:	f7 e1                	mul    cx
    3440:	89 46 b4             	mov    WORD PTR [bp-0x4c],ax
    3443:	8b 46 b2             	mov    ax,WORD PTR [bp-0x4e]
    3446:	03 46 b4             	add    ax,WORD PTR [bp-0x4c]
    3449:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    344c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    344f:	99                   	cwd
    3450:	52                   	push   dx
    3451:	50                   	push   ax
    3452:	9a af 25 a3 35       	call   0x35a3:0x25af
    3457:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    345a:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    345d:	b8 e0 31             	mov    ax,0x31e0
    3460:	0e                   	push   cs
    3461:	50                   	push   ax
    3462:	55                   	push   bp
    3463:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3467:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    346b:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    346e:	8b 56 e0             	mov    dx,WORD PTR [bp-0x20]
    3471:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    3474:	89 56 b8             	mov    WORD PTR [bp-0x48],dx
    3477:	8b 46 b2             	mov    ax,WORD PTR [bp-0x4e]
    347a:	99                   	cwd
    347b:	03 46 de             	add    ax,WORD PTR [bp-0x22]
    347e:	13 56 e0             	adc    dx,WORD PTR [bp-0x20]
    3481:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    3484:	89 56 bc             	mov    WORD PTR [bp-0x44],dx
    3487:	ff 76 da             	push   WORD PTR [bp-0x26]
    348a:	8b 46 b2             	mov    ax,WORD PTR [bp-0x4e]
    348d:	99                   	cwd
    348e:	52                   	push   dx
    348f:	50                   	push   ax
    3490:	ff 76 b8             	push   WORD PTR [bp-0x48]
    3493:	ff 76 b6             	push   WORD PTR [bp-0x4a]
    3496:	9a ab 34 00 00       	call   0x0:0x34ab
    349b:	ff 76 dc             	push   WORD PTR [bp-0x24]
    349e:	8b 46 b4             	mov    ax,WORD PTR [bp-0x4c]
    34a1:	99                   	cwd
    34a2:	52                   	push   dx
    34a3:	50                   	push   ax
    34a4:	ff 76 bc             	push   WORD PTR [bp-0x44]
    34a7:	ff 76 ba             	push   WORD PTR [bp-0x46]
    34aa:	9a ff ff 00 00       	call   0x0:0xffff
    34af:	ff 76 dc             	push   WORD PTR [bp-0x24]
    34b2:	9a bb 34 00 00       	call   0x0:0x34bb
    34b7:	ff 76 da             	push   WORD PTR [bp-0x26]
    34ba:	9a 9d 3d 00 00       	call   0x0:0x3d9d
    34bf:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    34c3:	ff 76 e8             	push   WORD PTR [bp-0x18]
    34c6:	ff 76 ea             	push   WORD PTR [bp-0x16]
    34c9:	8a 46 d4             	mov    al,BYTE PTR [bp-0x2c]
    34cc:	50                   	push   ax
    34cd:	8a 46 d5             	mov    al,BYTE PTR [bp-0x2b]
    34d0:	50                   	push   ax
    34d1:	ff 76 b8             	push   WORD PTR [bp-0x48]
    34d4:	ff 76 b6             	push   WORD PTR [bp-0x4a]
    34d7:	ff 76 bc             	push   WORD PTR [bp-0x44]
    34da:	ff 76 ba             	push   WORD PTR [bp-0x46]
    34dd:	9a ff ff 00 00       	call   0x0:0xffff
    34e2:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    34e5:	26 89 05             	mov    WORD PTR es:[di],ax
    34e8:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    34ec:	75 03                	jne    0x34f1
    34ee:	e8 93 f0             	call   0x2584
    34f1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    34f5:	83 c4 06             	add    sp,0x6
    34f8:	b8 0c 35             	mov    ax,0x350c
    34fb:	0e                   	push   cs
    34fc:	50                   	push   ax
    34fd:	ff 76 e0             	push   WORD PTR [bp-0x20]
    3500:	ff 76 de             	push   WORD PTR [bp-0x22]
    3503:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3506:	9a 9c 01 28 35       	call   0x3528:0x19c
    350b:	cb                   	retf
    350c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3510:	83 c4 06             	add    sp,0x6
    3513:	b8 2b 35             	mov    ax,0x352b
    3516:	0e                   	push   cs
    3517:	50                   	push   ax
    3518:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    351b:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    351e:	c4 7e ae             	les    di,DWORD PTR [bp-0x52]
    3521:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    3525:	9a 9c 01 43 35       	call   0x3543:0x19c
    352a:	cb                   	retf
    352b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    352f:	83 c4 06             	add    sp,0x6
    3532:	b8 46 35             	mov    ax,0x3546
    3535:	0e                   	push   cs
    3536:	50                   	push   ax
    3537:	ff 76 fe             	push   WORD PTR [bp-0x2]
    353a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    353d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3540:	9a 9c 01 79 36       	call   0x3679:0x19c
    3545:	cb                   	retf
    3546:	c9                   	leave
    3547:	c2 0c 00             	ret    0xc
    354a:	c8 0a 00 00          	enter  0xa,0x0
    354e:	31 c0                	xor    ax,ax
    3550:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3553:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    3556:	89 f8                	mov    ax,di
    3558:	8c c2                	mov    dx,es
    355a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    355d:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    3560:	26 8d 45 14          	lea    ax,es:[di+0x14]
    3564:	8c c2                	mov    dx,es
    3566:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3569:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    356c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    356f:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    3572:	3b 56 f8             	cmp    dx,WORD PTR [bp-0x8]
    3575:	7c 07                	jl     0x357e
    3577:	7f 1b                	jg     0x3594
    3579:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    357c:	73 16                	jae    0x3594
    357e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3581:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3584:	26 33 05             	xor    ax,WORD PTR es:[di]
    3587:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    358a:	83 46 fa 02          	add    WORD PTR [bp-0x6],0x2
    358e:	83 56 fc 00          	adc    WORD PTR [bp-0x4],0x0
    3592:	eb d8                	jmp    0x356c
    3594:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3597:	c9                   	leave
    3598:	c2 04 00             	ret    0x4
    359b:	01 00                	add    WORD PTR [bx+si],ax
    359d:	00 00                	add    BYTE PTR [bx+si],al
    359f:	00 00                	add    BYTE PTR [bx+si],al
    35a1:	66 36 01 38          	add    DWORD PTR ss:[bx+si],edi
    35a5:	c8 1c 00 00          	enter  0x1c,0x0
    35a9:	8d 7e ea             	lea    di,[bp-0x16]
    35ac:	16                   	push   ss
    35ad:	57                   	push   di
    35ae:	6a 00                	push   0x0
    35b0:	6a 16                	push   0x16
    35b2:	c4 7e 18             	les    di,DWORD PTR [bp+0x18]
    35b5:	06                   	push   es
    35b6:	57                   	push   di
    35b7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35ba:	26 ff 1d             	call   DWORD PTR es:[di]
    35bd:	81 7e ec c6 9a       	cmp    WORD PTR [bp-0x14],0x9ac6
    35c2:	75 14                	jne    0x35d8
    35c4:	81 7e ea d7 cd       	cmp    WORD PTR [bp-0x16],0xcdd7
    35c9:	75 0d                	jne    0x35d8
    35cb:	8d 7e ea             	lea    di,[bp-0x16]
    35ce:	16                   	push   ss
    35cf:	57                   	push   di
    35d0:	e8 77 ff             	call   0x354a
    35d3:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    35d6:	74 03                	je     0x35db
    35d8:	e8 9e ef             	call   0x2579
    35db:	83 6e 10 16          	sub    WORD PTR [bp+0x10],0x16
    35df:	83 5e 12 00          	sbb    WORD PTR [bp+0x12],0x0
    35e3:	6a 02                	push   0x2
    35e5:	ff 76 12             	push   WORD PTR [bp+0x12]
    35e8:	ff 76 10             	push   WORD PTR [bp+0x10]
    35eb:	9a 3a 4f 00 00       	call   0x0:0x4f3a
    35f0:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    35f3:	b8 9b 35             	mov    ax,0x359b
    35f6:	0e                   	push   cs
    35f7:	50                   	push   ax
    35f8:	55                   	push   bp
    35f9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    35fd:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3601:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3604:	9a 7c 3e 00 00       	call   0x0:0x3e7c
    3609:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    360c:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    360f:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    3612:	06                   	push   es
    3613:	57                   	push   di
    3614:	ff 76 12             	push   WORD PTR [bp+0x12]
    3617:	ff 76 10             	push   WORD PTR [bp+0x10]
    361a:	c4 7e 18             	les    di,DWORD PTR [bp+0x18]
    361d:	06                   	push   es
    361e:	57                   	push   di
    361f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3622:	26 ff 1d             	call   DWORD PTR es:[di]
    3625:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3628:	9a ff ff 00 00       	call   0x0:0xffff
    362d:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    3630:	26 89 05             	mov    WORD PTR es:[di],ax
    3633:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    3637:	75 03                	jne    0x363c
    3639:	e8 3d ef             	call   0x2579
    363c:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    363f:	2b 46 f0             	sub    ax,WORD PTR [bp-0x10]
    3642:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3645:	26 89 05             	mov    WORD PTR es:[di],ax
    3648:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    364b:	2b 46 f2             	sub    ax,WORD PTR [bp-0xe]
    364e:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3651:	26 89 05             	mov    WORD PTR es:[di],ax
    3654:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3657:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    365a:	26 89 05             	mov    WORD PTR es:[di],ax
    365d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3661:	83 c4 06             	add    sp,0x6
    3664:	eb 1a                	jmp    0x3680
    3666:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3669:	9a 07 3f 00 00       	call   0x0:0x3f07
    366e:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3671:	9a 1c 3f 00 00       	call   0x0:0x3f1c
    3676:	ea 85 13 7e 36       	jmp    0x367e:0x1385
    367b:	9a 34 14 72 37       	call   0x3772:0x1434
    3680:	c9                   	leave
    3681:	c2 18 00             	ret    0x18
    3684:	c8 12 00 00          	enter  0x12,0x0
    3688:	ff 76 0a             	push   WORD PTR [bp+0xa]
    368b:	6a 0e                	push   0xe
    368d:	8d 7e f2             	lea    di,[bp-0xe]
    3690:	16                   	push   ss
    3691:	57                   	push   di
    3692:	9a 3f 56 00 00       	call   0x0:0x563f
    3697:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    369a:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    369d:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    36a0:	26 c7 05 28 00       	mov    WORD PTR es:[di],0x28
    36a5:	26 c7 45 02 00 00    	mov    WORD PTR es:[di+0x2],0x0
    36ab:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    36ae:	99                   	cwd
    36af:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    36b3:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    36b7:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    36ba:	99                   	cwd
    36bb:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    36bf:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    36c3:	83 7e 04 00          	cmp    WORD PTR [bp+0x4],0x0
    36c7:	74 30                	je     0x36f9
    36c9:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    36cc:	3d 02 00             	cmp    ax,0x2
    36cf:	75 08                	jne    0x36d9
    36d1:	26 c7 45 0e 01 00    	mov    WORD PTR es:[di+0xe],0x1
    36d7:	eb 1e                	jmp    0x36f7
    36d9:	3d 10 00             	cmp    ax,0x10
    36dc:	75 0b                	jne    0x36e9
    36de:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    36e1:	26 c7 45 0e 04 00    	mov    WORD PTR es:[di+0xe],0x4
    36e7:	eb 0e                	jmp    0x36f7
    36e9:	3d 00 01             	cmp    ax,0x100
    36ec:	75 09                	jne    0x36f7
    36ee:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    36f1:	26 c7 45 0e 08 00    	mov    WORD PTR es:[di+0xe],0x8
    36f7:	eb 15                	jmp    0x370e
    36f9:	8a 46 fa             	mov    al,BYTE PTR [bp-0x6]
    36fc:	30 e4                	xor    ah,ah
    36fe:	8b d0                	mov    dx,ax
    3700:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    3703:	30 e4                	xor    ah,ah
    3705:	f7 e2                	mul    dx
    3707:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    370a:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    370e:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    3711:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    3717:	31 c0                	xor    ax,ax
    3719:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    371d:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    3721:	31 c0                	xor    ax,ax
    3723:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    3727:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    372b:	31 c0                	xor    ax,ax
    372d:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    3731:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    3735:	31 c0                	xor    ax,ax
    3737:	26 89 45 24          	mov    WORD PTR es:[di+0x24],ax
    373b:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    373f:	31 c0                	xor    ax,ax
    3741:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    3745:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    3749:	26 8a 45 0e          	mov    al,BYTE PTR es:[di+0xe]
    374d:	3c 10                	cmp    al,0x10
    374f:	74 04                	je     0x3755
    3751:	3c 20                	cmp    al,0x20
    3753:	75 09                	jne    0x375e
    3755:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    3758:	26 c7 45 0e 18 00    	mov    WORD PTR es:[di+0xe],0x18
    375e:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    3761:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    3765:	31 d2                	xor    dx,dx
    3767:	26 8b 4d 04          	mov    cx,WORD PTR es:[di+0x4]
    376b:	26 8b 5d 06          	mov    bx,WORD PTR es:[di+0x6]
    376f:	9a 33 16 87 37       	call   0x3787:0x1633
    3774:	52                   	push   dx
    3775:	50                   	push   ax
    3776:	e8 c7 f7             	call   0x2f40
    3779:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    377c:	26 8b 4d 08          	mov    cx,WORD PTR es:[di+0x8]
    3780:	26 8b 5d 0a          	mov    bx,WORD PTR es:[di+0xa]
    3784:	9a 33 16 49 39       	call   0x3949:0x1633
    3789:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    378c:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    3790:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    3794:	c9                   	leave
    3795:	c2 08 00             	ret    0x8
    3798:	c8 28 00 00          	enter  0x28,0x0
    379c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    379f:	8d 7e d8             	lea    di,[bp-0x28]
    37a2:	16                   	push   ss
    37a3:	57                   	push   di
    37a4:	ff 76 04             	push   WORD PTR [bp+0x4]
    37a7:	e8 da fe             	call   0x3684
    37aa:	8b 46 e6             	mov    ax,WORD PTR [bp-0x1a]
    37ad:	3d 18 00             	cmp    ax,0x18
    37b0:	75 0a                	jne    0x37bc
    37b2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    37b5:	26 c7 05 28 00       	mov    WORD PTR es:[di],0x28
    37ba:	eb 14                	jmp    0x37d0
    37bc:	b8 01 00             	mov    ax,0x1
    37bf:	8b 4e e6             	mov    cx,WORD PTR [bp-0x1a]
    37c2:	d3 e0                	shl    ax,cl
    37c4:	c1 e0 02             	shl    ax,0x2
    37c7:	05 28 00             	add    ax,0x28
    37ca:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    37cd:	26 89 05             	mov    WORD PTR es:[di],ax
    37d0:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    37d3:	8b 56 ee             	mov    dx,WORD PTR [bp-0x12]
    37d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37d9:	26 89 05             	mov    WORD PTR es:[di],ax
    37dc:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    37e0:	c9                   	leave
    37e1:	c2 0c 00             	ret    0xc
    37e4:	55                   	push   bp
    37e5:	89 e5                	mov    bp,sp
    37e7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    37ea:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    37ed:	06                   	push   es
    37ee:	57                   	push   di
    37ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37f2:	06                   	push   es
    37f3:	57                   	push   di
    37f4:	6a 00                	push   0x0
    37f6:	e8 9f ff             	call   0x3798
    37f9:	c9                   	leave
    37fa:	ca 0a 00             	retf   0xa
    37fd:	00 00                	add    BYTE PTR [bx+si],al
    37ff:	8f                   	(bad)
    3800:	38 e0                	cmp    al,ah
    3802:	38 c8                	cmp    al,cl
    3804:	08 00                	or     BYTE PTR [bx+si],al
    3806:	00 ff                	add    bh,bh
    3808:	76 10                	jbe    0x381a
    380a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    380d:	06                   	push   es
    380e:	57                   	push   di
    380f:	ff 76 04             	push   WORD PTR [bp+0x4]
    3812:	e8 6f fe             	call   0x3684
    3815:	31 c0                	xor    ax,ax
    3817:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    381a:	9a ff ff 00 00       	call   0x0:0xffff
    381f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3822:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3825:	9a c8 3a 00 00       	call   0x0:0x3ac8
    382a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    382d:	b8 fd 37             	mov    ax,0x37fd
    3830:	0e                   	push   cs
    3831:	50                   	push   ax
    3832:	55                   	push   bp
    3833:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3837:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    383b:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    383f:	74 18                	je     0x3859
    3841:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3844:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3847:	6a 00                	push   0x0
    3849:	9a 9e 38 00 00       	call   0x0:0x389e
    384e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3851:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3854:	9a e8 52 00 00       	call   0x0:0x52e8
    3859:	ff 76 f8             	push   WORD PTR [bp-0x8]
    385c:	ff 76 10             	push   WORD PTR [bp+0x10]
    385f:	6a 00                	push   0x0
    3861:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3864:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    3868:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    386b:	06                   	push   es
    386c:	57                   	push   di
    386d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3870:	06                   	push   es
    3871:	57                   	push   di
    3872:	6a 00                	push   0x0
    3874:	9a ff ff 00 00       	call   0x0:0xffff
    3879:	09 c0                	or     ax,ax
    387b:	b0 00                	mov    al,0x0
    387d:	74 01                	je     0x3880
    387f:	40                   	inc    ax
    3880:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3883:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3887:	83 c4 06             	add    sp,0x6
    388a:	b8 ae 38             	mov    ax,0x38ae
    388d:	0e                   	push   cs
    388e:	50                   	push   ax
    388f:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    3893:	74 0d                	je     0x38a2
    3895:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3898:	ff 76 fc             	push   WORD PTR [bp-0x4]
    389b:	6a 00                	push   0x0
    389d:	9a 08 52 00 00       	call   0x0:0x5208
    38a2:	ff 76 fa             	push   WORD PTR [bp-0x6]
    38a5:	ff 76 f8             	push   WORD PTR [bp-0x8]
    38a8:	9a 12 3b 00 00       	call   0x0:0x3b12
    38ad:	cb                   	retf
    38ae:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    38b1:	c9                   	leave
    38b2:	c2 0e 00             	ret    0xe
    38b5:	c8 02 00 00          	enter  0x2,0x0
    38b9:	ff 76 10             	push   WORD PTR [bp+0x10]
    38bc:	ff 76 0e             	push   WORD PTR [bp+0xe]
    38bf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    38c2:	06                   	push   es
    38c3:	57                   	push   di
    38c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38c7:	06                   	push   es
    38c8:	57                   	push   di
    38c9:	6a 00                	push   0x0
    38cb:	e8 35 ff             	call   0x3803
    38ce:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    38d1:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    38d4:	c9                   	leave
    38d5:	ca 0c 00             	retf   0xc
    38d8:	01 00                	add    WORD PTR [bx+si],ax
    38da:	00 00                	add    BYTE PTR [bx+si],al
    38dc:	00 00                	add    BYTE PTR [bx+si],al
    38de:	ca 39 23             	retf   0x2339
    38e1:	39 c8                	cmp    ax,cx
    38e3:	1a 00                	sbb    al,BYTE PTR [bx+si]
    38e5:	00 83 7e 0c          	add    BYTE PTR [bp+di+0xc7e],al
    38e9:	00 75 03             	add    BYTE PTR [di+0x3],dh
    38ec:	e8 74 ec             	call   0x2563
    38ef:	ff 76 0c             	push   WORD PTR [bp+0xc]
    38f2:	8d 7e fa             	lea    di,[bp-0x6]
    38f5:	16                   	push   ss
    38f6:	57                   	push   di
    38f7:	8d 7e f6             	lea    di,[bp-0xa]
    38fa:	16                   	push   ss
    38fb:	57                   	push   di
    38fc:	ff 76 08             	push   WORD PTR [bp+0x8]
    38ff:	e8 96 fe             	call   0x3798
    3902:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3905:	05 0e 00             	add    ax,0xe
    3908:	99                   	cwd
    3909:	03 46 f6             	add    ax,WORD PTR [bp-0xa]
    390c:	13 56 f8             	adc    dx,WORD PTR [bp-0x8]
    390f:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    3912:	26 89 05             	mov    WORD PTR es:[di],ax
    3915:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    3919:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    391d:	26 ff 35             	push   WORD PTR es:[di]
    3920:	9a af 25 f3 39       	call   0x39f3:0x25af
    3925:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3928:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    392b:	b8 d8 38             	mov    ax,0x38d8
    392e:	0e                   	push   cs
    392f:	50                   	push   ax
    3930:	55                   	push   bp
    3931:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3935:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3939:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    393c:	06                   	push   es
    393d:	57                   	push   di
    393e:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    3941:	26 ff 35             	push   WORD PTR es:[di]
    3944:	6a 00                	push   0x0
    3946:	9a e5 1e d9 39       	call   0x39d9:0x1ee5
    394b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    394e:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3951:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3954:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    3957:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    395a:	89 7e e6             	mov    WORD PTR [bp-0x1a],di
    395d:	8c 46 e8             	mov    WORD PTR [bp-0x18],es
    3960:	26 c7 05 42 4d       	mov    WORD PTR es:[di],0x4d42
    3965:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    3968:	26 8b 05             	mov    ax,WORD PTR es:[di]
    396b:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    396f:	c4 7e e6             	les    di,DWORD PTR [bp-0x1a]
    3972:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    3976:	26 89 55 04          	mov    WORD PTR es:[di+0x4],dx
    397a:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    397d:	05 0e 00             	add    ax,0xe
    3980:	99                   	cwd
    3981:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    3985:	26 89 55 0c          	mov    WORD PTR es:[di+0xc],dx
    3989:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    398c:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    398f:	05 0e 00             	add    ax,0xe
    3992:	83 d2 00             	adc    dx,0x0
    3995:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    3998:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    399b:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    399e:	99                   	cwd
    399f:	03 46 ee             	add    ax,WORD PTR [bp-0x12]
    39a2:	13 56 f0             	adc    dx,WORD PTR [bp-0x10]
    39a5:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    39a8:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    39ab:	ff 76 0c             	push   WORD PTR [bp+0xc]
    39ae:	ff 76 0a             	push   WORD PTR [bp+0xa]
    39b1:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    39b4:	06                   	push   es
    39b5:	57                   	push   di
    39b6:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    39b9:	06                   	push   es
    39ba:	57                   	push   di
    39bb:	ff 76 08             	push   WORD PTR [bp+0x8]
    39be:	e8 42 fe             	call   0x3803
    39c1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    39c5:	83 c4 06             	add    sp,0x6
    39c8:	eb 1b                	jmp    0x39e5
    39ca:	ff 76 fe             	push   WORD PTR [bp-0x2]
    39cd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    39d0:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    39d3:	26 ff 35             	push   WORD PTR es:[di]
    39d6:	9a 9c 01 de 39       	call   0x39de:0x19c
    39db:	ea 85 13 e3 39       	jmp    0x39e3:0x1385
    39e0:	9a 34 14 67 3a       	call   0x3a67:0x1434
    39e5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    39e8:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    39eb:	c9                   	leave
    39ec:	c2 0a 00             	ret    0xa
    39ef:	00 00                	add    BYTE PTR [bx+si],al
    39f1:	5b                   	pop    bx
    39f2:	3a 72 3a             	cmp    dh,BYTE PTR [bp+si+0x3a]
    39f5:	c8 08 00 00          	enter  0x8,0x0
    39f9:	ff 76 08             	push   WORD PTR [bp+0x8]
    39fc:	ff 76 06             	push   WORD PTR [bp+0x6]
    39ff:	6a 00                	push   0x0
    3a01:	8d 7e fc             	lea    di,[bp-0x4]
    3a04:	16                   	push   ss
    3a05:	57                   	push   di
    3a06:	e8 d9 fe             	call   0x38e2
    3a09:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3a0c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3a0f:	b8 ef 39             	mov    ax,0x39ef
    3a12:	0e                   	push   cs
    3a13:	50                   	push   ax
    3a14:	55                   	push   bp
    3a15:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3a19:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3a1d:	80 7e 04 00          	cmp    BYTE PTR [bp+0x4],0x0
    3a21:	74 15                	je     0x3a38
    3a23:	8d 7e fc             	lea    di,[bp-0x4]
    3a26:	16                   	push   ss
    3a27:	57                   	push   di
    3a28:	6a 00                	push   0x0
    3a2a:	6a 04                	push   0x4
    3a2c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a2f:	06                   	push   es
    3a30:	57                   	push   di
    3a31:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a34:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3a38:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3a3b:	06                   	push   es
    3a3c:	57                   	push   di
    3a3d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3a40:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3a43:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a46:	06                   	push   es
    3a47:	57                   	push   di
    3a48:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a4b:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3a4f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3a53:	83 c4 06             	add    sp,0x6
    3a56:	b8 6a 3a             	mov    ax,0x3a6a
    3a59:	0e                   	push   cs
    3a5a:	50                   	push   ax
    3a5b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3a5e:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3a61:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3a64:	9a 9c 01 9c 3a       	call   0x3a9c:0x19c
    3a69:	cb                   	retf
    3a6a:	c9                   	leave
    3a6b:	c2 0a 00             	ret    0xa
    3a6e:	00 00                	add    BYTE PTR [bx+si],al
    3a70:	0c 3b                	or     al,0x3b
    3a72:	78 3a                	js     0x3aae
    3a74:	00 00                	add    BYTE PTR [bx+si],al
    3a76:	63 3d                	arpl   WORD PTR [di],di
    3a78:	7e 3a                	jle    0x3ab4
    3a7a:	00 00                	add    BYTE PTR [bx+si],al
    3a7c:	7e 3d                	jle    0x3abb
    3a7e:	84 3a                	test   BYTE PTR [bp+si],bh
    3a80:	00 00                	add    BYTE PTR [bx+si],al
    3a82:	99                   	cwd
    3a83:	3d 8a 3a             	cmp    ax,0x3a8a
    3a86:	00 00                	add    BYTE PTR [bx+si],al
    3a88:	ae                   	scas   al,BYTE PTR es:[di]
    3a89:	3d c3 3d             	cmp    ax,0x3dc3
    3a8c:	c8 46 00 00          	enter  0x46,0x0
    3a90:	8d 7e ee             	lea    di,[bp-0x12]
    3a93:	16                   	push   ss
    3a94:	57                   	push   di
    3a95:	6a 06                	push   0x6
    3a97:	6a 00                	push   0x0
    3a99:	9a e5 1e aa 3a       	call   0x3aaa:0x1ee5
    3a9e:	8d 7e de             	lea    di,[bp-0x22]
    3aa1:	16                   	push   ss
    3aa2:	57                   	push   di
    3aa3:	6a 10                	push   0x10
    3aa5:	6a 00                	push   0x0
    3aa7:	9a e5 1e 51 3b       	call   0x3b51:0x1ee5
    3aac:	ff 76 06             	push   WORD PTR [bp+0x6]
    3aaf:	9a ff ff 00 00       	call   0x0:0xffff
    3ab4:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    3ab7:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    3aba:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    3abd:	0b 46 dc             	or     ax,WORD PTR [bp-0x24]
    3ac0:	75 03                	jne    0x3ac5
    3ac2:	e8 a9 ea             	call   0x256e
    3ac5:	6a 00                	push   0x0
    3ac7:	9a e1 53 00 00       	call   0x0:0x53e1
    3acc:	89 46 be             	mov    WORD PTR [bp-0x42],ax
    3acf:	83 7e be 00          	cmp    WORD PTR [bp-0x42],0x0
    3ad3:	75 03                	jne    0x3ad8
    3ad5:	e8 ac ea             	call   0x2584
    3ad8:	b8 6e 3a             	mov    ax,0x3a6e
    3adb:	0e                   	push   cs
    3adc:	50                   	push   ax
    3add:	55                   	push   bp
    3ade:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3ae2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3ae6:	ff 76 be             	push   WORD PTR [bp-0x42]
    3ae9:	6a 0c                	push   0xc
    3aeb:	9a f9 3a 00 00       	call   0x0:0x3af9
    3af0:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    3af3:	ff 76 be             	push   WORD PTR [bp-0x42]
    3af6:	6a 0e                	push   0xe
    3af8:	9a ed 6f 00 00       	call   0x0:0x6fed
    3afd:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    3b00:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3b04:	83 c4 06             	add    sp,0x6
    3b07:	b8 17 3b             	mov    ax,0x3b17
    3b0a:	0e                   	push   cs
    3b0b:	50                   	push   ax
    3b0c:	6a 00                	push   0x0
    3b0e:	ff 76 be             	push   WORD PTR [bp-0x42]
    3b11:	9a 10 56 00 00       	call   0x0:0x5610
    3b16:	cb                   	retf
    3b17:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    3b1a:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3b1e:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    3b21:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    3b24:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    3b28:	89 46 c4             	mov    WORD PTR [bp-0x3c],ax
    3b2b:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    3b2e:	8b 56 dc             	mov    dx,WORD PTR [bp-0x24]
    3b31:	05 0c 00             	add    ax,0xc
    3b34:	83 d2 00             	adc    dx,0x0
    3b37:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    3b3a:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    3b3d:	8b 46 c2             	mov    ax,WORD PTR [bp-0x3e]
    3b40:	99                   	cwd
    3b41:	52                   	push   dx
    3b42:	50                   	push   ax
    3b43:	e8 2e f4             	call   0x2f74
    3b46:	8b c8                	mov    cx,ax
    3b48:	8b da                	mov    bx,dx
    3b4a:	8b 46 c4             	mov    ax,WORD PTR [bp-0x3c]
    3b4d:	99                   	cwd
    3b4e:	9a 33 16 6f 3d       	call   0x3d6f:0x1633
    3b53:	03 46 d2             	add    ax,WORD PTR [bp-0x2e]
    3b56:	13 56 d4             	adc    dx,WORD PTR [bp-0x2c]
    3b59:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    3b5c:	89 56 d0             	mov    WORD PTR [bp-0x30],dx
    3b5f:	ff 76 c2             	push   WORD PTR [bp-0x3e]
    3b62:	ff 76 c4             	push   WORD PTR [bp-0x3c]
    3b65:	ff 76 c8             	push   WORD PTR [bp-0x38]
    3b68:	ff 76 c6             	push   WORD PTR [bp-0x3a]
    3b6b:	ff 76 d0             	push   WORD PTR [bp-0x30]
    3b6e:	ff 76 ce             	push   WORD PTR [bp-0x32]
    3b71:	9a 98 3b 00 00       	call   0x0:0x3b98
    3b76:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    3b79:	b8 86 3a             	mov    ax,0x3a86
    3b7c:	0e                   	push   cs
    3b7d:	50                   	push   ax
    3b7e:	55                   	push   bp
    3b7f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3b83:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3b87:	ff 76 c2             	push   WORD PTR [bp-0x3e]
    3b8a:	ff 76 c4             	push   WORD PTR [bp-0x3c]
    3b8d:	6a 01                	push   0x1
    3b8f:	6a 01                	push   0x1
    3b91:	ff 76 d4             	push   WORD PTR [bp-0x2c]
    3b94:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    3b97:	9a 16 54 00 00       	call   0x0:0x5416
    3b9c:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    3b9f:	b8 80 3a             	mov    ax,0x3a80
    3ba2:	0e                   	push   cs
    3ba3:	50                   	push   ax
    3ba4:	55                   	push   bp
    3ba5:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3ba9:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3bad:	c7 46 c0 10 00       	mov    WORD PTR [bp-0x40],0x10
    3bb2:	83 7e c6 01          	cmp    WORD PTR [bp-0x3a],0x1
    3bb6:	75 0b                	jne    0x3bc3
    3bb8:	83 7e c8 01          	cmp    WORD PTR [bp-0x38],0x1
    3bbc:	75 05                	jne    0x3bc3
    3bbe:	c7 46 c0 02 00       	mov    WORD PTR [bp-0x40],0x2
    3bc3:	ff 76 d6             	push   WORD PTR [bp-0x2a]
    3bc6:	6a 00                	push   0x0
    3bc8:	ff 76 c0             	push   WORD PTR [bp-0x40]
    3bcb:	8d 7e f4             	lea    di,[bp-0xc]
    3bce:	16                   	push   ss
    3bcf:	57                   	push   di
    3bd0:	e8 0f fd             	call   0x38e2
    3bd3:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    3bd6:	89 56 d0             	mov    WORD PTR [bp-0x30],dx
    3bd9:	b8 7a 3a             	mov    ax,0x3a7a
    3bdc:	0e                   	push   cs
    3bdd:	50                   	push   ax
    3bde:	55                   	push   bp
    3bdf:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3be3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3be7:	ff 76 d8             	push   WORD PTR [bp-0x28]
    3bea:	6a 00                	push   0x0
    3bec:	6a 02                	push   0x2
    3bee:	8d 7e f8             	lea    di,[bp-0x8]
    3bf1:	16                   	push   ss
    3bf2:	57                   	push   di
    3bf3:	e8 ec fc             	call   0x38e2
    3bf6:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    3bf9:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    3bfc:	b8 74 3a             	mov    ax,0x3a74
    3bff:	0e                   	push   cs
    3c00:	50                   	push   ax
    3c01:	55                   	push   bp
    3c02:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3c06:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3c0a:	c7 46 cc 3e 00       	mov    WORD PTR [bp-0x34],0x3e
    3c0f:	c7 46 ca 0e 00       	mov    WORD PTR [bp-0x36],0xe
    3c14:	8b 46 cc             	mov    ax,WORD PTR [bp-0x34]
    3c17:	99                   	cwd
    3c18:	52                   	push   dx
    3c19:	50                   	push   ax
    3c1a:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    3c1d:	99                   	cwd
    3c1e:	8b c8                	mov    cx,ax
    3c20:	8b da                	mov    bx,dx
    3c22:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    3c25:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    3c28:	05 16 00             	add    ax,0x16
    3c2b:	83 d2 00             	adc    dx,0x0
    3c2e:	2b c1                	sub    ax,cx
    3c30:	1b d3                	sbb    dx,bx
    3c32:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    3c35:	13 56 fa             	adc    dx,WORD PTR [bp-0x6]
    3c38:	59                   	pop    cx
    3c39:	5b                   	pop    bx
    3c3a:	2b c1                	sub    ax,cx
    3c3c:	1b d3                	sbb    dx,bx
    3c3e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3c41:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3c44:	80 7e 04 00          	cmp    BYTE PTR [bp+0x4],0x0
    3c48:	74 15                	je     0x3c5f
    3c4a:	8d 7e fc             	lea    di,[bp-0x4]
    3c4d:	16                   	push   ss
    3c4e:	57                   	push   di
    3c4f:	6a 00                	push   0x0
    3c51:	6a 04                	push   0x4
    3c53:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3c56:	06                   	push   es
    3c57:	57                   	push   di
    3c58:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c5b:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3c5f:	c7 46 f0 01 00       	mov    WORD PTR [bp-0x10],0x1
    3c64:	c7 46 f2 01 00       	mov    WORD PTR [bp-0xe],0x1
    3c69:	8d 7e ee             	lea    di,[bp-0x12]
    3c6c:	16                   	push   ss
    3c6d:	57                   	push   di
    3c6e:	6a 00                	push   0x0
    3c70:	6a 06                	push   0x6
    3c72:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3c75:	06                   	push   es
    3c76:	57                   	push   di
    3c77:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c7a:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3c7e:	8a 46 c2             	mov    al,BYTE PTR [bp-0x3e]
    3c81:	88 46 de             	mov    BYTE PTR [bp-0x22],al
    3c84:	8a 46 c4             	mov    al,BYTE PTR [bp-0x3c]
    3c87:	88 46 df             	mov    BYTE PTR [bp-0x21],al
    3c8a:	8b 46 c0             	mov    ax,WORD PTR [bp-0x40]
    3c8d:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    3c90:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    3c93:	99                   	cwd
    3c94:	52                   	push   dx
    3c95:	50                   	push   ax
    3c96:	8b 46 cc             	mov    ax,WORD PTR [bp-0x34]
    3c99:	99                   	cwd
    3c9a:	8b c8                	mov    cx,ax
    3c9c:	8b da                	mov    bx,dx
    3c9e:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3ca1:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    3ca4:	2b c1                	sub    ax,cx
    3ca6:	1b d3                	sbb    dx,bx
    3ca8:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    3cab:	13 56 f6             	adc    dx,WORD PTR [bp-0xa]
    3cae:	59                   	pop    cx
    3caf:	5b                   	pop    bx
    3cb0:	2b c1                	sub    ax,cx
    3cb2:	1b d3                	sbb    dx,bx
    3cb4:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    3cb7:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    3cba:	c7 46 ea 16 00       	mov    WORD PTR [bp-0x16],0x16
    3cbf:	c7 46 ec 00 00       	mov    WORD PTR [bp-0x14],0x0
    3cc4:	8d 7e de             	lea    di,[bp-0x22]
    3cc7:	16                   	push   ss
    3cc8:	57                   	push   di
    3cc9:	6a 00                	push   0x0
    3ccb:	6a 10                	push   0x10
    3ccd:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3cd0:	06                   	push   es
    3cd1:	57                   	push   di
    3cd2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cd5:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3cd9:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    3cdc:	99                   	cwd
    3cdd:	03 46 ce             	add    ax,WORD PTR [bp-0x32]
    3ce0:	13 56 d0             	adc    dx,WORD PTR [bp-0x30]
    3ce3:	89 c7                	mov    di,ax
    3ce5:	8e c2                	mov    es,dx
    3ce7:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3ceb:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    3cef:	26 01 45 08          	add    WORD PTR es:[di+0x8],ax
    3cf3:	26 11 55 0a          	adc    WORD PTR es:[di+0xa],dx
    3cf7:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    3cfa:	99                   	cwd
    3cfb:	03 46 ce             	add    ax,WORD PTR [bp-0x32]
    3cfe:	13 56 d0             	adc    dx,WORD PTR [bp-0x30]
    3d01:	89 c7                	mov    di,ax
    3d03:	8e c2                	mov    es,dx
    3d05:	06                   	push   es
    3d06:	57                   	push   di
    3d07:	8b 46 ca             	mov    ax,WORD PTR [bp-0x36]
    3d0a:	99                   	cwd
    3d0b:	8b c8                	mov    cx,ax
    3d0d:	8b da                	mov    bx,dx
    3d0f:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    3d12:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    3d15:	2b c1                	sub    ax,cx
    3d17:	1b d3                	sbb    dx,bx
    3d19:	52                   	push   dx
    3d1a:	50                   	push   ax
    3d1b:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3d1e:	06                   	push   es
    3d1f:	57                   	push   di
    3d20:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d23:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3d27:	8b 46 cc             	mov    ax,WORD PTR [bp-0x34]
    3d2a:	99                   	cwd
    3d2b:	03 46 d2             	add    ax,WORD PTR [bp-0x2e]
    3d2e:	13 56 d4             	adc    dx,WORD PTR [bp-0x2c]
    3d31:	89 c7                	mov    di,ax
    3d33:	8e c2                	mov    es,dx
    3d35:	06                   	push   es
    3d36:	57                   	push   di
    3d37:	8b 46 cc             	mov    ax,WORD PTR [bp-0x34]
    3d3a:	99                   	cwd
    3d3b:	8b c8                	mov    cx,ax
    3d3d:	8b da                	mov    bx,dx
    3d3f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3d42:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    3d45:	2b c1                	sub    ax,cx
    3d47:	1b d3                	sbb    dx,bx
    3d49:	52                   	push   dx
    3d4a:	50                   	push   ax
    3d4b:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3d4e:	06                   	push   es
    3d4f:	57                   	push   di
    3d50:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d53:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3d57:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3d5b:	83 c4 06             	add    sp,0x6
    3d5e:	b8 72 3d             	mov    ax,0x3d72
    3d61:	0e                   	push   cs
    3d62:	50                   	push   ax
    3d63:	ff 76 d4             	push   WORD PTR [bp-0x2c]
    3d66:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    3d69:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3d6c:	9a 9c 01 8a 3d       	call   0x3d8a:0x19c
    3d71:	cb                   	retf
    3d72:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3d76:	83 c4 06             	add    sp,0x6
    3d79:	b8 8d 3d             	mov    ax,0x3d8d
    3d7c:	0e                   	push   cs
    3d7d:	50                   	push   ax
    3d7e:	ff 76 d0             	push   WORD PTR [bp-0x30]
    3d81:	ff 76 ce             	push   WORD PTR [bp-0x32]
    3d84:	ff 76 f4             	push   WORD PTR [bp-0xc]
    3d87:	9a 9c 01 e1 3d       	call   0x3de1:0x19c
    3d8c:	cb                   	retf
    3d8d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3d91:	83 c4 06             	add    sp,0x6
    3d94:	b8 a2 3d             	mov    ax,0x3da2
    3d97:	0e                   	push   cs
    3d98:	50                   	push   ax
    3d99:	ff 76 d8             	push   WORD PTR [bp-0x28]
    3d9c:	9a b2 3d 00 00       	call   0x0:0x3db2
    3da1:	cb                   	retf
    3da2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3da6:	83 c4 06             	add    sp,0x6
    3da9:	b8 b7 3d             	mov    ax,0x3db7
    3dac:	0e                   	push   cs
    3dad:	50                   	push   ax
    3dae:	ff 76 d6             	push   WORD PTR [bp-0x2a]
    3db1:	9a 80 53 00 00       	call   0x0:0x5380
    3db6:	cb                   	retf
    3db7:	c9                   	leave
    3db8:	c2 08 00             	ret    0x8
    3dbb:	01 00                	add    WORD PTR [bx+si],ax
    3dbd:	00 00                	add    BYTE PTR [bx+si],al
    3dbf:	00 00                	add    BYTE PTR [bx+si],al
    3dc1:	58                   	pop    ax
    3dc2:	3e c9                	ds leave
    3dc4:	3d 00 00             	cmp    ax,0x0
    3dc7:	03 3f                	add    di,WORD PTR [bx]
    3dc9:	cf                   	iret
    3dca:	3d 00 00             	cmp    ax,0x0
    3dcd:	18 3f                	sbb    BYTE PTR [bx],bh
    3dcf:	ca 3f c8             	retf   0xc83f
    3dd2:	2a 00                	sub    al,BYTE PTR [bx+si]
    3dd4:	00 8d 7e ea          	add    BYTE PTR [di-0x1582],cl
    3dd8:	16                   	push   ss
    3dd9:	57                   	push   di
    3dda:	6a 16                	push   0x16
    3ddc:	6a 00                	push   0x0
    3dde:	9a e5 1e 0b 3e       	call   0x3e0b:0x1ee5
    3de3:	c7 46 ea d7 cd       	mov    WORD PTR [bp-0x16],0xcdd7
    3de8:	c7 46 ec c6 9a       	mov    WORD PTR [bp-0x14],0x9ac6
    3ded:	8d 7e d6             	lea    di,[bp-0x2a]
    3df0:	16                   	push   ss
    3df1:	57                   	push   di
    3df2:	6a 00                	push   0x0
    3df4:	6a 00                	push   0x0
    3df6:	ff 76 08             	push   WORD PTR [bp+0x8]
    3df9:	ff 76 06             	push   WORD PTR [bp+0x6]
    3dfc:	9a 88 06 47 3f       	call   0x3f47:0x688
    3e01:	8d 7e f0             	lea    di,[bp-0x10]
    3e04:	16                   	push   ss
    3e05:	57                   	push   di
    3e06:	6a 08                	push   0x8
    3e08:	9a 1b 16 63 3e       	call   0x3e63:0x161b
    3e0d:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    3e10:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3e13:	8d 7e ea             	lea    di,[bp-0x16]
    3e16:	16                   	push   ss
    3e17:	57                   	push   di
    3e18:	e8 2f f7             	call   0x354a
    3e1b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3e1e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3e21:	6a 00                	push   0x0
    3e23:	6a 00                	push   0x0
    3e25:	9a 6b 49 00 00       	call   0x0:0x496b
    3e2a:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3e2d:	83 7e e8 00          	cmp    WORD PTR [bp-0x18],0x0
    3e31:	75 03                	jne    0x3e36
    3e33:	e8 4e e7             	call   0x2584
    3e36:	b8 bb 3d             	mov    ax,0x3dbb
    3e39:	0e                   	push   cs
    3e3a:	50                   	push   ax
    3e3b:	55                   	push   bp
    3e3c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3e40:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3e44:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3e47:	9a ff ff 00 00       	call   0x0:0xffff
    3e4c:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    3e4f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3e53:	83 c4 06             	add    sp,0x6
    3e56:	eb 12                	jmp    0x3e6a
    3e58:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3e5b:	9a 52 48 00 00       	call   0x0:0x4852
    3e60:	ea 85 13 68 3e       	jmp    0x3e68:0x1385
    3e65:	9a 34 14 3f 3f       	call   0x3f3f:0x1434
    3e6a:	b8 cb 3d             	mov    ax,0x3dcb
    3e6d:	0e                   	push   cs
    3e6e:	50                   	push   ax
    3e6f:	55                   	push   bp
    3e70:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3e74:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3e78:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3e7b:	9a ff 4d 00 00       	call   0x0:0x4dff
    3e80:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    3e83:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
    3e86:	b8 c5 3d             	mov    ax,0x3dc5
    3e89:	0e                   	push   cs
    3e8a:	50                   	push   ax
    3e8b:	55                   	push   bp
    3e8c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3e90:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3e94:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3e97:	9a ff ff 00 00       	call   0x0:0xffff
    3e9c:	05 16 00             	add    ax,0x16
    3e9f:	83 d2 00             	adc    dx,0x0
    3ea2:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    3ea5:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    3ea8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3eac:	74 15                	je     0x3ec3
    3eae:	8d 7e de             	lea    di,[bp-0x22]
    3eb1:	16                   	push   ss
    3eb2:	57                   	push   di
    3eb3:	6a 00                	push   0x0
    3eb5:	6a 04                	push   0x4
    3eb7:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3eba:	06                   	push   es
    3ebb:	57                   	push   di
    3ebc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ebf:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3ec3:	8d 7e ea             	lea    di,[bp-0x16]
    3ec6:	16                   	push   ss
    3ec7:	57                   	push   di
    3ec8:	6a 00                	push   0x0
    3eca:	6a 16                	push   0x16
    3ecc:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3ecf:	06                   	push   es
    3ed0:	57                   	push   di
    3ed1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ed4:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3ed8:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    3edb:	06                   	push   es
    3edc:	57                   	push   di
    3edd:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    3ee0:	8b 56 e0             	mov    dx,WORD PTR [bp-0x20]
    3ee3:	2d 16 00             	sub    ax,0x16
    3ee6:	83 da 00             	sbb    dx,0x0
    3ee9:	52                   	push   dx
    3eea:	50                   	push   ax
    3eeb:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3eee:	06                   	push   es
    3eef:	57                   	push   di
    3ef0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ef3:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3ef7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3efb:	83 c4 06             	add    sp,0x6
    3efe:	b8 0c 3f             	mov    ax,0x3f0c
    3f01:	0e                   	push   cs
    3f02:	50                   	push   ax
    3f03:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3f06:	9a ee 4e 00 00       	call   0x0:0x4eee
    3f0b:	cb                   	retf
    3f0c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3f10:	83 c4 06             	add    sp,0x6
    3f13:	b8 21 3f             	mov    ax,0x3f21
    3f16:	0e                   	push   cs
    3f17:	50                   	push   ax
    3f18:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3f1b:	9a 5c 50 00 00       	call   0x0:0x505c
    3f20:	cb                   	retf
    3f21:	c9                   	leave
    3f22:	c2 0e 00             	ret    0xe
	...
    3f2d:	4d                   	dec    bp
    3f2e:	3f                   	aas
    3f2f:	0c 00                	or     al,0x0
    3f31:	a3 02 e7             	mov    ds:0xe702,ax
    3f34:	3f                   	aas
    3f35:	64 20 11             	and    BYTE PTR fs:[bx+di],dl
    3f38:	40                   	inc    ax
    3f39:	9a 1f 37 3f cb       	call   0xcb3f:0x371f
    3f3e:	1f                   	pop    ds
    3f3f:	3b 3f                	cmp    di,WORD PTR [bx]
    3f41:	0f 0c                	(bad)
    3f43:	33 3f                	xor    di,WORD PTR [bx]
    3f45:	fb                   	sti
    3f46:	0c 4b                	or     al,0x4b
    3f48:	3f                   	aas
    3f49:	17                   	pop    ss
    3f4a:	0e                   	push   cs
    3f4b:	43                   	inc    bx
    3f4c:	3f                   	aas
    3f4d:	0c 54                	or     al,0x54
    3f4f:	48                   	dec    ax
    3f50:	61                   	popa
    3f51:	6e                   	outs   dx,BYTE PTR ds:[si]
    3f52:	64 6c                	fs ins BYTE PTR es:[di],dx
    3f54:	65 43                	gs inc bx
    3f56:	61                   	popa
    3f57:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    3f5a:	c8 04 00 00          	enter  0x4,0x0
    3f5e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f61:	26 c7 05 ff ff       	mov    WORD PTR es:[di],0xffff
    3f66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f69:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3f6d:	48                   	dec    ax
    3f6e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3f71:	31 c0                	xor    ax,ax
    3f73:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3f76:	7f 32                	jg     0x3faa
    3f78:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3f7b:	eb 03                	jmp    0x3f80
    3f7d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3f80:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f83:	c1 e0 02             	shl    ax,0x2
    3f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f89:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    3f8d:	03 f8                	add    di,ax
    3f8f:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3f92:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    3f95:	75 0b                	jne    0x3fa2
    3f97:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f9a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f9d:	26 89 05             	mov    WORD PTR es:[di],ax
    3fa0:	eb 08                	jmp    0x3faa
    3fa2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3fa5:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3fa8:	75 d3                	jne    0x3f7d
    3faa:	c9                   	leave
    3fab:	ca 0a 00             	retf   0xa
    3fae:	c8 02 00 00          	enter  0x2,0x0
    3fb2:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    3fb6:	75 02                	jne    0x3fba
    3fb8:	eb 44                	jmp    0x3ffe
    3fba:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3fbd:	8d 7e fe             	lea    di,[bp-0x2]
    3fc0:	16                   	push   ss
    3fc1:	57                   	push   di
    3fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fc5:	06                   	push   es
    3fc6:	57                   	push   di
    3fc7:	9a 5a 3f 44 40       	call   0x4044:0x3f5a
    3fcc:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3fd0:	7d 19                	jge    0x3feb
    3fd2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3fd5:	31 d2                	xor    dx,dx
    3fd7:	05 00 00             	add    ax,0x0
    3fda:	83 d2 01             	adc    dx,0x1
    3fdd:	52                   	push   dx
    3fde:	50                   	push   ax
    3fdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fe2:	06                   	push   es
    3fe3:	57                   	push   di
    3fe4:	9a 2b 0c 98 40       	call   0x4098:0xc2b
    3fe9:	eb 13                	jmp    0x3ffe
    3feb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3fee:	c1 e0 02             	shl    ax,0x2
    3ff1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ff4:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    3ff8:	03 f8                	add    di,ax
    3ffa:	26 ff 45 02          	inc    WORD PTR es:[di+0x2]
    3ffe:	c9                   	leave
    3fff:	ca 06 00             	retf   0x6
    4002:	55                   	push   bp
    4003:	89 e5                	mov    bp,sp
    4005:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4009:	74 08                	je     0x4013
    400b:	83 ec 08             	sub    sp,0x8
    400e:	9a e2 1f 1e 40       	call   0x401e:0x1fe2
    4013:	31 c0                	xor    ax,ax
    4015:	50                   	push   ax
    4016:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4019:	06                   	push   es
    401a:	57                   	push   di
    401b:	9a 50 1f 4b 40       	call   0x404b:0x1f50
    4020:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4024:	74 07                	je     0x402d
    4026:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    402a:	83 c4 06             	add    sp,0x6
    402d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4030:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4033:	c9                   	leave
    4034:	ca 06 00             	retf   0x6
    4037:	55                   	push   bp
    4038:	89 e5                	mov    bp,sp
    403a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    403d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4040:	bf c6 06             	mov    di,0x6c6
    4043:	b8 20 41             	mov    ax,0x4120
    4046:	50                   	push   ax
    4047:	57                   	push   di
    4048:	9a 55 22 64 40       	call   0x4064:0x2255
    404d:	08 c0                	or     al,al
    404f:	74 39                	je     0x408a
    4051:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4054:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4058:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    405c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    405f:	06                   	push   es
    4060:	57                   	push   di
    4061:	9a dd 20 6b 40       	call   0x406b:0x20dd
    4066:	52                   	push   dx
    4067:	50                   	push   ax
    4068:	9a 55 22 77 41       	call   0x4177:0x2255
    406d:	08 c0                	or     al,al
    406f:	74 19                	je     0x408a
    4071:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4074:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4078:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    407c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    407f:	06                   	push   es
    4080:	57                   	push   di
    4081:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4084:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    4088:	eb 10                	jmp    0x409a
    408a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    408d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4090:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4093:	06                   	push   es
    4094:	57                   	push   di
    4095:	9a fa 10 34 41       	call   0x4134:0x10fa
    409a:	c9                   	leave
    409b:	ca 08 00             	retf   0x8
    409e:	55                   	push   bp
    409f:	89 e5                	mov    bp,sp
    40a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40a4:	26 c6 45 0c 01       	mov    BYTE PTR es:[di+0xc],0x1
    40a9:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    40ad:	09 c0                	or     ax,ax
    40af:	74 12                	je     0x40c3
    40b1:	ff 76 08             	push   WORD PTR [bp+0x8]
    40b4:	ff 76 06             	push   WORD PTR [bp+0x6]
    40b7:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    40bb:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    40bf:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    40c3:	c9                   	leave
    40c4:	ca 08 00             	retf   0x8
    40c7:	04 44                	add    al,0x44
    40c9:	61                   	popa
    40ca:	74 61                	je     0x412d
    40cc:	55                   	push   bp
    40cd:	89 e5                	mov    bp,sp
    40cf:	bf c7 40             	mov    di,0x40c7
    40d2:	0e                   	push   cs
    40d3:	57                   	push   di
    40d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40d7:	06                   	push   es
    40d8:	57                   	push   di
    40d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40dc:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    40e0:	26 8b 55 22          	mov    dx,WORD PTR es:[di+0x22]
    40e4:	52                   	push   dx
    40e5:	50                   	push   ax
    40e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40e9:	06                   	push   es
    40ea:	57                   	push   di
    40eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40ee:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    40f2:	26 8b 55 2e          	mov    dx,WORD PTR es:[di+0x2e]
    40f6:	52                   	push   dx
    40f7:	50                   	push   ax
    40f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40fb:	06                   	push   es
    40fc:	57                   	push   di
    40fd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4100:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    4104:	08 c0                	or     al,al
    4106:	b0 00                	mov    al,0x0
    4108:	75 01                	jne    0x410b
    410a:	40                   	inc    ax
    410b:	50                   	push   ax
    410c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    410f:	06                   	push   es
    4110:	57                   	push   di
    4111:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4114:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    4118:	c9                   	leave
    4119:	ca 08 00             	retf   0x8
    411c:	00 00                	add    BYTE PTR [bx+si],al
    411e:	6f                   	outs   dx,WORD PTR ds:[si]
    411f:	41                   	inc    cx
    4120:	82 41 c8 04          	add    BYTE PTR [bx+di-0x38],0x4
    4124:	00 00                	add    BYTE PTR [bx+si],al
    4126:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4129:	06                   	push   es
    412a:	57                   	push   di
    412b:	6a 00                	push   0x0
    412d:	b0 01                	mov    al,0x1
    412f:	50                   	push   ax
    4130:	b8 ec 04             	mov    ax,0x4ec
    4133:	ba 3b 41             	mov    dx,0x413b
    4136:	52                   	push   dx
    4137:	50                   	push   ax
    4138:	9a fc 26 96 41       	call   0x4196:0x26fc
    413d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4140:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4143:	b8 1c 41             	mov    ax,0x411c
    4146:	0e                   	push   cs
    4147:	50                   	push   ax
    4148:	55                   	push   bp
    4149:	ff 36 58 18          	push   WORD PTR ds:0x1858
    414d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4151:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4154:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4157:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    415a:	06                   	push   es
    415b:	57                   	push   di
    415c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    415f:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4163:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4167:	83 c4 06             	add    sp,0x6
    416a:	b8 7a 41             	mov    ax,0x417a
    416d:	0e                   	push   cs
    416e:	50                   	push   ax
    416f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4172:	06                   	push   es
    4173:	57                   	push   di
    4174:	9a 7f 1f d9 41       	call   0x41d9:0x1f7f
    4179:	cb                   	retf
    417a:	c9                   	leave
    417b:	ca 08 00             	retf   0x8
    417e:	00 00                	add    BYTE PTR [bx+si],al
    4180:	d1 41 94             	rol    WORD PTR [bx+di-0x6c],1
    4183:	42                   	inc    dx
    4184:	c8 04 00 00          	enter  0x4,0x0
    4188:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    418b:	06                   	push   es
    418c:	57                   	push   di
    418d:	6a ff                	push   0xffff
    418f:	b0 01                	mov    al,0x1
    4191:	50                   	push   ax
    4192:	b8 ec 04             	mov    ax,0x4ec
    4195:	ba 9d 41             	mov    dx,0x419d
    4198:	52                   	push   dx
    4199:	50                   	push   ax
    419a:	9a fc 26 b2 45       	call   0x45b2:0x26fc
    419f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    41a2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    41a5:	b8 7e 41             	mov    ax,0x417e
    41a8:	0e                   	push   cs
    41a9:	50                   	push   ax
    41aa:	55                   	push   bp
    41ab:	ff 36 58 18          	push   WORD PTR ds:0x1858
    41af:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    41b3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    41b6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    41b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41bc:	06                   	push   es
    41bd:	57                   	push   di
    41be:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41c1:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    41c5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    41c9:	83 c4 06             	add    sp,0x6
    41cc:	b8 dc 41             	mov    ax,0x41dc
    41cf:	0e                   	push   cs
    41d0:	50                   	push   ax
    41d1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    41d4:	06                   	push   es
    41d5:	57                   	push   di
    41d6:	9a 7f 1f 21 42       	call   0x4221:0x1f7f
    41db:	cb                   	retf
    41dc:	c9                   	leave
    41dd:	ca 08 00             	retf   0x8
    41e0:	55                   	push   bp
    41e1:	89 e5                	mov    bp,sp
    41e3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    41e6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    41e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41ec:	06                   	push   es
    41ed:	57                   	push   di
    41ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41f1:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    41f5:	c9                   	leave
    41f6:	ca 08 00             	retf   0x8
    41f9:	55                   	push   bp
    41fa:	89 e5                	mov    bp,sp
    41fc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    41ff:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4202:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4205:	06                   	push   es
    4206:	57                   	push   di
    4207:	26 c4 3d             	les    di,DWORD PTR es:[di]
    420a:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    420e:	c9                   	leave
    420f:	ca 08 00             	retf   0x8
    4212:	55                   	push   bp
    4213:	89 e5                	mov    bp,sp
    4215:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4218:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    421c:	06                   	push   es
    421d:	57                   	push   di
    421e:	9a 7f 1f 2e 42       	call   0x422e:0x1f7f
    4223:	31 c0                	xor    ax,ax
    4225:	50                   	push   ax
    4226:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4229:	06                   	push   es
    422a:	57                   	push   di
    422b:	9a 66 1f 39 42       	call   0x4239:0x1f66
    4230:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4234:	74 05                	je     0x423b
    4236:	9a 0f 20 56 42       	call   0x4256:0x200f
    423b:	c9                   	leave
    423c:	ca 06 00             	retf   0x6
    423f:	55                   	push   bp
    4240:	89 e5                	mov    bp,sp
    4242:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4245:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4249:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    424d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4250:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4253:	9a 55 22 68 42       	call   0x4268:0x2255
    4258:	08 c0                	or     al,al
    425a:	75 5e                	jne    0x42ba
    425c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    425f:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4263:	06                   	push   es
    4264:	57                   	push   di
    4265:	9a 7f 1f 18 43       	call   0x4318:0x1f7f
    426a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    426d:	31 c0                	xor    ax,ax
    426f:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    4273:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    4277:	b0 01                	mov    al,0x1
    4279:	50                   	push   ax
    427a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    427d:	06                   	push   es
    427e:	57                   	push   di
    427f:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    4283:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4286:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    428a:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    428e:	06                   	push   es
    428f:	57                   	push   di
    4290:	b8 b8 45             	mov    ax,0x45b8
    4293:	ba b8 42             	mov    dx,0x42b8
    4296:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    429a:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    429e:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    42a2:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    42a6:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    42aa:	ff 76 08             	push   WORD PTR [bp+0x8]
    42ad:	ff 76 06             	push   WORD PTR [bp+0x6]
    42b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42b3:	06                   	push   es
    42b4:	57                   	push   di
    42b5:	9a b8 45 c6 42       	call   0x42c6:0x45b8
    42ba:	c9                   	leave
    42bb:	ca 08 00             	retf   0x8
    42be:	c8 04 00 00          	enter  0x4,0x0
    42c2:	bf 3f 08             	mov    di,0x83f
    42c5:	b8 d2 42             	mov    ax,0x42d2
    42c8:	50                   	push   ax
    42c9:	57                   	push   di
    42ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42cd:	06                   	push   es
    42ce:	57                   	push   di
    42cf:	9a 3f 42 f7 42       	call   0x42f7:0x423f
    42d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42d7:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    42db:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    42df:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    42e2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    42e5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    42e8:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    42eb:	c9                   	leave
    42ec:	ca 04 00             	retf   0x4
    42ef:	01 00                	add    WORD PTR [bx+si],ax
    42f1:	00 00                	add    BYTE PTR [bx+si],al
    42f3:	00 00                	add    BYTE PTR [bx+si],al
    42f5:	9e                   	sahf
    42f6:	43                   	inc    bx
    42f7:	46                   	inc    si
    42f8:	43                   	inc    bx
    42f9:	c8 04 00 00          	enter  0x4,0x0
    42fd:	31 c0                	xor    ax,ax
    42ff:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4302:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4305:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4308:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    430b:	74 4e                	je     0x435b
    430d:	b0 01                	mov    al,0x1
    430f:	50                   	push   ax
    4310:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4313:	06                   	push   es
    4314:	57                   	push   di
    4315:	9a dd 20 23 43       	call   0x4323:0x20dd
    431a:	89 c7                	mov    di,ax
    431c:	8e c2                	mov    es,dx
    431e:	06                   	push   es
    431f:	57                   	push   di
    4320:	9a 50 1f 75 43       	call   0x4375:0x1f50
    4325:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4328:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    432b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    432e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4331:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4334:	06                   	push   es
    4335:	57                   	push   di
    4336:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4339:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    433d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4340:	06                   	push   es
    4341:	57                   	push   di
    4342:	b8 b8 45             	mov    ax,0x45b8
    4345:	ba 93 43             	mov    dx,0x4393
    4348:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    434b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    434f:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    4353:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    4357:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    435b:	b8 ef 42             	mov    ax,0x42ef
    435e:	0e                   	push   cs
    435f:	50                   	push   ax
    4360:	55                   	push   bp
    4361:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4365:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4369:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    436c:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4370:	06                   	push   es
    4371:	57                   	push   di
    4372:	9a 7f 1f a6 43       	call   0x43a6:0x1f7f
    4377:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    437a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    437d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4380:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    4384:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    4388:	ff 76 08             	push   WORD PTR [bp+0x8]
    438b:	ff 76 06             	push   WORD PTR [bp+0x6]
    438e:	06                   	push   es
    438f:	57                   	push   di
    4390:	9a b8 45 be 43       	call   0x43be:0x45b8
    4395:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4399:	83 c4 06             	add    sp,0x6
    439c:	eb 14                	jmp    0x43b2
    439e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    43a1:	06                   	push   es
    43a2:	57                   	push   di
    43a3:	9a 7f 1f ab 43       	call   0x43ab:0x1f7f
    43a8:	ea 85 13 b0 43       	jmp    0x43b0:0x1385
    43ad:	9a 34 14 48 44       	call   0x4448:0x1434
    43b2:	c9                   	leave
    43b3:	ca 08 00             	retf   0x8
    43b6:	01 00                	add    WORD PTR [bx+si],ax
    43b8:	00 00                	add    BYTE PTR [bx+si],al
    43ba:	00 00                	add    BYTE PTR [bx+si],al
    43bc:	40                   	inc    ax
    43bd:	44                   	inc    sp
    43be:	79 44                	jns    0x4404
    43c0:	c8 0c 00 00          	enter  0xc,0x0
    43c4:	a1 f4 12             	mov    ax,ds:0x12f4
    43c7:	8b 16 f6 12          	mov    dx,WORD PTR ds:0x12f6
    43cb:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    43ce:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    43d1:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    43d4:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    43d7:	75 03                	jne    0x43dc
    43d9:	e9 c8 00             	jmp    0x44a4
    43dc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    43df:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    43e2:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    43e5:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    43e8:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    43ec:	74 11                	je     0x43ff
    43ee:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    43f2:	26 8b 55 08          	mov    dx,WORD PTR es:[di+0x8]
    43f6:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    43f9:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    43fc:	e9 a2 00             	jmp    0x44a1
    43ff:	b0 01                	mov    al,0x1
    4401:	50                   	push   ax
    4402:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4405:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4408:	06                   	push   es
    4409:	57                   	push   di
    440a:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    440e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4411:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4414:	b8 b6 43             	mov    ax,0x43b6
    4417:	0e                   	push   cs
    4418:	50                   	push   ax
    4419:	55                   	push   bp
    441a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    441e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4422:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4425:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4428:	ff 76 0a             	push   WORD PTR [bp+0xa]
    442b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    442e:	06                   	push   es
    442f:	57                   	push   di
    4430:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4433:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4437:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    443b:	83 c4 06             	add    sp,0x6
    443e:	eb 14                	jmp    0x4454
    4440:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4443:	06                   	push   es
    4444:	57                   	push   di
    4445:	9a 7f 1f 4d 44       	call   0x444d:0x1f7f
    444a:	ea 85 13 52 44       	jmp    0x4452:0x1385
    444f:	9a 34 14 60 44       	call   0x4460:0x1434
    4454:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4457:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    445b:	06                   	push   es
    445c:	57                   	push   di
    445d:	9a 7f 1f 5e 45       	call   0x455e:0x1f7f
    4462:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4465:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    4468:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    446b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    446f:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    4473:	06                   	push   es
    4474:	57                   	push   di
    4475:	b8 b8 45             	mov    ax,0x45b8
    4478:	ba 9d 44             	mov    dx,0x449d
    447b:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    447f:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    4483:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    4487:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    448b:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    448f:	ff 76 08             	push   WORD PTR [bp+0x8]
    4492:	ff 76 06             	push   WORD PTR [bp+0x6]
    4495:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4498:	06                   	push   es
    4499:	57                   	push   di
    449a:	9a b8 45 49 45       	call   0x4549:0x45b8
    449f:	eb 09                	jmp    0x44aa
    44a1:	e9 2d ff             	jmp    0x43d1
    44a4:	68 1f f0             	push   0xf01f
    44a7:	e8 8c e0             	call   0x2536
    44aa:	c9                   	leave
    44ab:	ca 0a 00             	retf   0xa
    44ae:	55                   	push   bp
    44af:	89 e5                	mov    bp,sp
    44b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44b4:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    44b8:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    44bc:	74 1f                	je     0x44dd
    44be:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    44c1:	06                   	push   es
    44c2:	57                   	push   di
    44c3:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    44c6:	06                   	push   es
    44c7:	57                   	push   di
    44c8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    44cb:	06                   	push   es
    44cc:	57                   	push   di
    44cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44d0:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    44d4:	06                   	push   es
    44d5:	57                   	push   di
    44d6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44d9:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    44dd:	c9                   	leave
    44de:	ca 10 00             	retf   0x10
    44e1:	c8 0a 00 00          	enter  0xa,0x0
    44e5:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    44e9:	a1 f4 12             	mov    ax,ds:0x12f4
    44ec:	8b 16 f6 12          	mov    dx,WORD PTR ds:0x12f6
    44f0:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    44f3:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    44f6:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    44f9:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    44fc:	74 29                	je     0x4527
    44fe:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4501:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    4504:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    4507:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    450a:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    450e:	75 04                	jne    0x4514
    4510:	eb 19                	jmp    0x452b
    4512:	eb 11                	jmp    0x4525
    4514:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4517:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    451b:	26 8b 55 08          	mov    dx,WORD PTR es:[di+0x8]
    451f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4522:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    4525:	eb cf                	jmp    0x44f6
    4527:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    452b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    452e:	c9                   	leave
    452f:	ca 06 00             	retf   0x6
    4532:	55                   	push   bp
    4533:	89 e5                	mov    bp,sp
    4535:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4538:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    453b:	75 10                	jne    0x454d
    453d:	6a 00                	push   0x0
    453f:	6a 00                	push   0x0
    4541:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4544:	06                   	push   es
    4545:	57                   	push   di
    4546:	9a f9 42 57 45       	call   0x4557:0x42f9
    454b:	eb 67                	jmp    0x45b4
    454d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4550:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4553:	bf c6 06             	mov    di,0x6c6
    4556:	b8 77 45             	mov    ax,0x4577
    4559:	50                   	push   ax
    455a:	57                   	push   di
    455b:	9a 55 22 8c 45       	call   0x458c:0x2255
    4560:	08 c0                	or     al,al
    4562:	74 17                	je     0x457b
    4564:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4567:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    456b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    456f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4572:	06                   	push   es
    4573:	57                   	push   di
    4574:	9a f9 42 85 45       	call   0x4585:0x42f9
    4579:	eb 39                	jmp    0x45b4
    457b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    457e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4581:	bf 36 06             	mov    di,0x636
    4584:	b8 a0 45             	mov    ax,0x45a0
    4587:	50                   	push   ax
    4588:	57                   	push   di
    4589:	9a 55 22 51 46       	call   0x4651:0x2255
    458e:	08 c0                	or     al,al
    4590:	74 12                	je     0x45a4
    4592:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4595:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4598:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    459b:	06                   	push   es
    459c:	57                   	push   di
    459d:	9a f9 42 e4 45       	call   0x45e4:0x42f9
    45a2:	eb 10                	jmp    0x45b4
    45a4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    45a7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    45aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45ad:	06                   	push   es
    45ae:	57                   	push   di
    45af:	9a fa 10 53 4d       	call   0x4d53:0x10fa
    45b4:	c9                   	leave
    45b5:	ca 08 00             	retf   0x8
    45b8:	55                   	push   bp
    45b9:	89 e5                	mov    bp,sp
    45bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45be:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    45c2:	09 c0                	or     ax,ax
    45c4:	74 12                	je     0x45d8
    45c6:	ff 76 08             	push   WORD PTR [bp+0x8]
    45c9:	ff 76 06             	push   WORD PTR [bp+0x6]
    45cc:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    45d0:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    45d4:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    45d8:	c9                   	leave
    45d9:	ca 08 00             	retf   0x8
    45dc:	01 00                	add    WORD PTR [bx+si],ax
    45de:	00 00                	add    BYTE PTR [bx+si],al
    45e0:	00 00                	add    BYTE PTR [bx+si],al
    45e2:	b1 46                	mov    cl,0x46
    45e4:	ea 46 c8 50 01       	jmp    0x150:0xc846
    45e9:	00 c4                	add    ah,al
    45eb:	7e 0a                	jle    0x45f7
    45ed:	89 7e b4             	mov    WORD PTR [bp-0x4c],di
    45f0:	8c 46 b6             	mov    WORD PTR [bp-0x4a],es
    45f3:	8d 7e c0             	lea    di,[bp-0x40]
    45f6:	16                   	push   ss
    45f7:	57                   	push   di
    45f8:	6a 00                	push   0x0
    45fa:	6a 01                	push   0x1
    45fc:	c4 7e b4             	les    di,DWORD PTR [bp-0x4c]
    45ff:	06                   	push   es
    4600:	57                   	push   di
    4601:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4604:	26 ff 1d             	call   DWORD PTR es:[di]
    4607:	8d 7e c1             	lea    di,[bp-0x3f]
    460a:	16                   	push   ss
    460b:	57                   	push   di
    460c:	8a 46 c0             	mov    al,BYTE PTR [bp-0x40]
    460f:	30 e4                	xor    ah,ah
    4611:	99                   	cwd
    4612:	52                   	push   dx
    4613:	50                   	push   ax
    4614:	c4 7e b4             	les    di,DWORD PTR [bp-0x4c]
    4617:	06                   	push   es
    4618:	57                   	push   di
    4619:	26 c4 3d             	les    di,DWORD PTR es:[di]
    461c:	26 ff 1d             	call   DWORD PTR es:[di]
    461f:	a1 dc 12             	mov    ax,ds:0x12dc
    4622:	8b 16 de 12          	mov    dx,WORD PTR ds:0x12de
    4626:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    4629:	89 56 be             	mov    WORD PTR [bp-0x42],dx
    462c:	8b 46 bc             	mov    ax,WORD PTR [bp-0x44]
    462f:	0b 46 be             	or     ax,WORD PTR [bp-0x42]
    4632:	75 03                	jne    0x4637
    4634:	e9 de 00             	jmp    0x4715
    4637:	c4 7e bc             	les    di,DWORD PTR [bp-0x44]
    463a:	89 7e b0             	mov    WORD PTR [bp-0x50],di
    463d:	8c 46 b2             	mov    WORD PTR [bp-0x4e],es
    4640:	8d be b0 fe          	lea    di,[bp-0x150]
    4644:	16                   	push   ss
    4645:	57                   	push   di
    4646:	c4 7e b0             	les    di,DWORD PTR [bp-0x50]
    4649:	26 c4 3d             	les    di,DWORD PTR es:[di]
    464c:	06                   	push   es
    464d:	57                   	push   di
    464e:	9a ed 20 5b 46       	call   0x465b:0x20ed
    4653:	8d 7e c0             	lea    di,[bp-0x40]
    4656:	16                   	push   ss
    4657:	57                   	push   di
    4658:	9a be 18 b9 46       	call   0x46b9:0x18be
    465d:	74 14                	je     0x4673
    465f:	c4 7e b0             	les    di,DWORD PTR [bp-0x50]
    4662:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    4666:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    466a:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    466d:	89 56 be             	mov    WORD PTR [bp-0x42],dx
    4670:	e9 9f 00             	jmp    0x4712
    4673:	b0 01                	mov    al,0x1
    4675:	50                   	push   ax
    4676:	c4 7e b0             	les    di,DWORD PTR [bp-0x50]
    4679:	26 c4 3d             	les    di,DWORD PTR es:[di]
    467c:	06                   	push   es
    467d:	57                   	push   di
    467e:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    4682:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    4685:	89 56 ba             	mov    WORD PTR [bp-0x46],dx
    4688:	b8 dc 45             	mov    ax,0x45dc
    468b:	0e                   	push   cs
    468c:	50                   	push   ax
    468d:	55                   	push   bp
    468e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4692:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4696:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4699:	ff 76 0a             	push   WORD PTR [bp+0xa]
    469c:	c4 7e b8             	les    di,DWORD PTR [bp-0x48]
    469f:	06                   	push   es
    46a0:	57                   	push   di
    46a1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46a4:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    46a8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    46ac:	83 c4 06             	add    sp,0x6
    46af:	eb 14                	jmp    0x46c5
    46b1:	c4 7e b8             	les    di,DWORD PTR [bp-0x48]
    46b4:	06                   	push   es
    46b5:	57                   	push   di
    46b6:	9a 7f 1f be 46       	call   0x46be:0x1f7f
    46bb:	ea 85 13 c3 46       	jmp    0x46c3:0x1385
    46c0:	9a 34 14 d1 46       	call   0x46d1:0x1434
    46c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46c8:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    46cc:	06                   	push   es
    46cd:	57                   	push   di
    46ce:	9a 7f 1f 3b 47       	call   0x473b:0x1f7f
    46d3:	8b 46 b8             	mov    ax,WORD PTR [bp-0x48]
    46d6:	8b 56 ba             	mov    dx,WORD PTR [bp-0x46]
    46d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46dc:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    46e0:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    46e4:	06                   	push   es
    46e5:	57                   	push   di
    46e6:	b8 b8 45             	mov    ax,0x45b8
    46e9:	ba 0e 47             	mov    dx,0x470e
    46ec:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    46f0:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    46f4:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    46f8:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    46fc:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    4700:	ff 76 08             	push   WORD PTR [bp+0x8]
    4703:	ff 76 06             	push   WORD PTR [bp+0x6]
    4706:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4709:	06                   	push   es
    470a:	57                   	push   di
    470b:	9a b8 45 93 47       	call   0x4793:0x45b8
    4710:	eb 03                	jmp    0x4715
    4712:	e9 17 ff             	jmp    0x462c
    4715:	c9                   	leave
    4716:	ca 08 00             	retf   0x8
    4719:	c8 44 01 00          	enter  0x144,0x0
    471d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4720:	89 7e bc             	mov    WORD PTR [bp-0x44],di
    4723:	8c 46 be             	mov    WORD PTR [bp-0x42],es
    4726:	8d be bc fe          	lea    di,[bp-0x144]
    472a:	16                   	push   ss
    472b:	57                   	push   di
    472c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    472f:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4733:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4736:	06                   	push   es
    4737:	57                   	push   di
    4738:	9a ed 20 47 47       	call   0x4747:0x20ed
    473d:	8d 7e c0             	lea    di,[bp-0x40]
    4740:	16                   	push   ss
    4741:	57                   	push   di
    4742:	6a 3f                	push   0x3f
    4744:	9a e7 17 5e 48       	call   0x485e:0x17e7
    4749:	8d 7e c0             	lea    di,[bp-0x40]
    474c:	16                   	push   ss
    474d:	57                   	push   di
    474e:	8a 46 c0             	mov    al,BYTE PTR [bp-0x40]
    4751:	30 e4                	xor    ah,ah
    4753:	40                   	inc    ax
    4754:	99                   	cwd
    4755:	52                   	push   dx
    4756:	50                   	push   ax
    4757:	c4 7e bc             	les    di,DWORD PTR [bp-0x44]
    475a:	06                   	push   es
    475b:	57                   	push   di
    475c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    475f:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    4763:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4766:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4769:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    476c:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4770:	06                   	push   es
    4771:	57                   	push   di
    4772:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4775:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    4779:	c9                   	leave
    477a:	ca 08 00             	retf   0x8
    477d:	04 44                	add    al,0x44
    477f:	61                   	popa
    4780:	74 61                	je     0x47e3
    4782:	55                   	push   bp
    4783:	89 e5                	mov    bp,sp
    4785:	bf 7d 47             	mov    di,0x477d
    4788:	0e                   	push   cs
    4789:	57                   	push   di
    478a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    478d:	06                   	push   es
    478e:	57                   	push   di
    478f:	bf e6 45             	mov    di,0x45e6
    4792:	b8 a0 47             	mov    ax,0x47a0
    4795:	50                   	push   ax
    4796:	57                   	push   di
    4797:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    479a:	06                   	push   es
    479b:	57                   	push   di
    479c:	bf 19 47             	mov    di,0x4719
    479f:	b8 73 48             	mov    ax,0x4873
    47a2:	50                   	push   ax
    47a3:	57                   	push   di
    47a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47a7:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    47ab:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    47af:	b0 00                	mov    al,0x0
    47b1:	74 01                	je     0x47b4
    47b3:	40                   	inc    ax
    47b4:	50                   	push   ax
    47b5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    47b8:	06                   	push   es
    47b9:	57                   	push   di
    47ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47bd:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    47c1:	c9                   	leave
    47c2:	ca 08 00             	retf   0x8
    47c5:	c8 02 00 00          	enter  0x2,0x0
    47c9:	31 c0                	xor    ax,ax
    47cb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    47ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47d1:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    47d5:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    47d9:	74 10                	je     0x47eb
    47db:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    47df:	06                   	push   es
    47e0:	57                   	push   di
    47e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47e4:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    47e8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    47eb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    47ee:	c9                   	leave
    47ef:	ca 04 00             	retf   0x4
    47f2:	c8 02 00 00          	enter  0x2,0x0
    47f6:	31 c0                	xor    ax,ax
    47f8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    47fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47fe:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4802:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    4806:	74 10                	je     0x4818
    4808:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    480c:	06                   	push   es
    480d:	57                   	push   di
    480e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4811:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    4815:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4818:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    481b:	c9                   	leave
    481c:	ca 04 00             	retf   0x4
    481f:	55                   	push   bp
    4820:	89 e5                	mov    bp,sp
    4822:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4825:	26 ff 45 04          	inc    WORD PTR es:[di+0x4]
    4829:	c9                   	leave
    482a:	ca 04 00             	retf   0x4
    482d:	55                   	push   bp
    482e:	89 e5                	mov    bp,sp
    4830:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4833:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
    4836:	74 28                	je     0x4860
    4838:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    483b:	26 ff 4d 04          	dec    WORD PTR es:[di+0x4]
    483f:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    4844:	75 1a                	jne    0x4860
    4846:	26 83 7d 06 00       	cmp    WORD PTR es:[di+0x6],0x0
    484b:	74 09                	je     0x4856
    484d:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4851:	9a ff ff 00 00       	call   0x0:0xffff
    4856:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4859:	06                   	push   es
    485a:	57                   	push   di
    485b:	9a 7f 1f 80 48       	call   0x4880:0x1f7f
    4860:	c9                   	leave
    4861:	ca 04 00             	retf   0x4
    4864:	55                   	push   bp
    4865:	89 e5                	mov    bp,sp
    4867:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    486a:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    486e:	06                   	push   es
    486f:	57                   	push   di
    4870:	9a 2d 48 a6 48       	call   0x48a6:0x482d
    4875:	31 c0                	xor    ax,ax
    4877:	50                   	push   ax
    4878:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    487b:	06                   	push   es
    487c:	57                   	push   di
    487d:	9a 66 1f 8b 48       	call   0x488b:0x1f66
    4882:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4886:	74 05                	je     0x488d
    4888:	9a 0f 20 ad 48       	call   0x48ad:0x200f
    488d:	c9                   	leave
    488e:	ca 06 00             	retf   0x6
    4891:	55                   	push   bp
    4892:	89 e5                	mov    bp,sp
    4894:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4897:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    489a:	74 17                	je     0x48b3
    489c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    489f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    48a2:	bf 49 07             	mov    di,0x749
    48a5:	b8 bf 48             	mov    ax,0x48bf
    48a8:	50                   	push   ax
    48a9:	57                   	push   di
    48aa:	9a 55 22 ef 48       	call   0x48ef:0x2255
    48af:	08 c0                	or     al,al
    48b1:	74 69                	je     0x491c
    48b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48b6:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    48ba:	06                   	push   es
    48bb:	57                   	push   di
    48bc:	9a 2d 48 e8 48       	call   0x48e8:0x482d
    48c1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    48c4:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    48c7:	74 18                	je     0x48e1
    48c9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    48cc:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    48d0:	26 8b 55 10          	mov    dx,WORD PTR es:[di+0x10]
    48d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48d7:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    48db:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    48df:	eb 1b                	jmp    0x48fc
    48e1:	b0 01                	mov    al,0x1
    48e3:	50                   	push   ax
    48e4:	b8 1a 07             	mov    ax,0x71a
    48e7:	ba 08 49             	mov    dx,0x4908
    48ea:	52                   	push   dx
    48eb:	50                   	push   ax
    48ec:	9a 50 1f 53 49       	call   0x4953:0x1f50
    48f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48f4:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    48f8:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    48fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48ff:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4903:	06                   	push   es
    4904:	57                   	push   di
    4905:	9a 1f 48 18 49       	call   0x4918:0x481f
    490a:	ff 76 08             	push   WORD PTR [bp+0x8]
    490d:	ff 76 06             	push   WORD PTR [bp+0x6]
    4910:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4913:	06                   	push   es
    4914:	57                   	push   di
    4915:	9a 9e 40 2a 49       	call   0x492a:0x409e
    491a:	eb 10                	jmp    0x492c
    491c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    491f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4922:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4925:	06                   	push   es
    4926:	57                   	push   di
    4927:	9a 37 40 4c 49       	call   0x494c:0x4037
    492c:	c9                   	leave
    492d:	ca 08 00             	retf   0x8
    4930:	c8 04 00 00          	enter  0x4,0x0
    4934:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4937:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    493b:	26 83 7d 04 01       	cmp    WORD PTR es:[di+0x4],0x1
    4940:	7f 03                	jg     0x4945
    4942:	e9 91 00             	jmp    0x49d6
    4945:	b0 01                	mov    al,0x1
    4947:	50                   	push   ax
    4948:	b8 1a 07             	mov    ax,0x71a
    494b:	ba b8 49             	mov    dx,0x49b8
    494e:	52                   	push   dx
    494f:	50                   	push   ax
    4950:	9a 50 1f f9 49       	call   0x49f9:0x1f50
    4955:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4958:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    495b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    495e:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4962:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4966:	6a 00                	push   0x0
    4968:	6a 00                	push   0x0
    496a:	9a d3 4e 00 00       	call   0x0:0x4ed3
    496f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4972:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    4976:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4979:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    497d:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4981:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4984:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    4988:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    498b:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    498f:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4993:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4996:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    499a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    499d:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    49a1:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    49a5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    49a8:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    49ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49af:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    49b3:	06                   	push   es
    49b4:	57                   	push   di
    49b5:	9a 2d 48 d4 49       	call   0x49d4:0x482d
    49ba:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    49bd:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    49c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49c3:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    49c7:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    49cb:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    49cf:	06                   	push   es
    49d0:	57                   	push   di
    49d1:	9a 1f 48 e9 49       	call   0x49e9:0x481f
    49d6:	c9                   	leave
    49d7:	ca 04 00             	retf   0x4
    49da:	55                   	push   bp
    49db:	89 e5                	mov    bp,sp
    49dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49e0:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    49e4:	06                   	push   es
    49e5:	57                   	push   di
    49e6:	9a 2d 48 f2 49       	call   0x49f2:0x482d
    49eb:	b0 01                	mov    al,0x1
    49ed:	50                   	push   ax
    49ee:	b8 1a 07             	mov    ax,0x71a
    49f1:	ba 0f 4a             	mov    dx,0x4a0f
    49f4:	52                   	push   dx
    49f5:	50                   	push   ax
    49f6:	9a 50 1f 63 50       	call   0x5063:0x1f50
    49fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49fe:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    4a02:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    4a06:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4a0a:	06                   	push   es
    4a0b:	57                   	push   di
    4a0c:	9a 1f 48 e9 4a       	call   0x4ae9:0x481f
    4a11:	c9                   	leave
    4a12:	ca 04 00             	retf   0x4
    4a15:	c8 02 00 00          	enter  0x2,0x0
    4a19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a1c:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4a20:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    4a24:	b0 00                	mov    al,0x0
    4a26:	75 01                	jne    0x4a29
    4a28:	40                   	inc    ax
    4a29:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    4a2c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4a2f:	c9                   	leave
    4a30:	ca 04 00             	retf   0x4
    4a33:	c8 06 00 00          	enter  0x6,0x0
    4a37:	31 c0                	xor    ax,ax
    4a39:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4a3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a3f:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4a43:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    4a47:	74 33                	je     0x4a7c
    4a49:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4a4d:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    4a50:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    4a53:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4a57:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4a5a:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    4a5f:	74 1b                	je     0x4a7c
    4a61:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4a65:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4a69:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    4a6d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4a70:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4a74:	9a c5 4a 00 00       	call   0x0:0x4ac5
    4a79:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4a7c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4a7f:	c9                   	leave
    4a80:	ca 04 00             	retf   0x4
    4a83:	c8 06 00 00          	enter  0x6,0x0
    4a87:	31 c0                	xor    ax,ax
    4a89:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4a8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a8f:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4a93:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    4a97:	74 33                	je     0x4acc
    4a99:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4a9d:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    4aa0:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    4aa3:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4aa7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4aaa:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    4aaf:	74 1b                	je     0x4acc
    4ab1:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4ab5:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4ab9:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    4abd:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4ac0:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4ac4:	9a 09 4b 00 00       	call   0x0:0x4b09
    4ac9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4acc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4acf:	c9                   	leave
    4ad0:	ca 04 00             	retf   0x4
    4ad3:	c8 04 00 00          	enter  0x4,0x0
    4ad7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ada:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4ade:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    4ae2:	75 07                	jne    0x4aeb
    4ae4:	06                   	push   es
    4ae5:	57                   	push   di
    4ae6:	9a da 49 28 4b       	call   0x4b28:0x49da
    4aeb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4aee:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4af2:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    4af7:	74 17                	je     0x4b10
    4af9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4afc:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4b00:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4b04:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    4b08:	9a 7c 4b 00 00       	call   0x0:0x4b7c
    4b0d:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    4b10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b13:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4b17:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4b1b:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    4b1e:	74 28                	je     0x4b48
    4b20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b23:	06                   	push   es
    4b24:	57                   	push   di
    4b25:	9a 30 49 46 4b       	call   0x4b46:0x4930
    4b2a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4b2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b30:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4b34:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    4b38:	ff 76 08             	push   WORD PTR [bp+0x8]
    4b3b:	ff 76 06             	push   WORD PTR [bp+0x6]
    4b3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b41:	06                   	push   es
    4b42:	57                   	push   di
    4b43:	9a 9e 40 62 4b       	call   0x4b62:0x409e
    4b48:	c9                   	leave
    4b49:	ca 06 00             	retf   0x6
    4b4c:	c8 04 00 00          	enter  0x4,0x0
    4b50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b53:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4b57:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    4b5b:	75 07                	jne    0x4b64
    4b5d:	06                   	push   es
    4b5e:	57                   	push   di
    4b5f:	9a da 49 9b 4b       	call   0x4b9b:0x49da
    4b64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b67:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4b6b:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    4b70:	74 11                	je     0x4b83
    4b72:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b75:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4b79:	6a 60                	push   0x60
    4b7b:	9a 05 70 00 00       	call   0x0:0x7005
    4b80:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    4b83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b86:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4b8a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4b8e:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    4b91:	74 28                	je     0x4bbb
    4b93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b96:	06                   	push   es
    4b97:	57                   	push   di
    4b98:	9a 30 49 b9 4b       	call   0x4bb9:0x4930
    4b9d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4ba0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ba3:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4ba7:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    4bab:	ff 76 08             	push   WORD PTR [bp+0x8]
    4bae:	ff 76 06             	push   WORD PTR [bp+0x6]
    4bb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bb4:	06                   	push   es
    4bb5:	57                   	push   di
    4bb6:	9a 9e 40 cb 4b       	call   0x4bcb:0x409e
    4bbb:	c9                   	leave
    4bbc:	ca 06 00             	retf   0x6
    4bbf:	c8 08 00 00          	enter  0x8,0x0
    4bc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bc6:	06                   	push   es
    4bc7:	57                   	push   di
    4bc8:	9a da 49 2c 4c       	call   0x4c2c:0x49da
    4bcd:	8d 7e fc             	lea    di,[bp-0x4]
    4bd0:	16                   	push   ss
    4bd1:	57                   	push   di
    4bd2:	6a 00                	push   0x0
    4bd4:	6a 04                	push   0x4
    4bd6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4bd9:	06                   	push   es
    4bda:	57                   	push   di
    4bdb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4bde:	26 ff 1d             	call   DWORD PTR es:[di]
    4be1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4be4:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4be8:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    4beb:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    4bee:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4bf1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4bf4:	81 c7 06 00          	add    di,0x6
    4bf8:	06                   	push   es
    4bf9:	57                   	push   di
    4bfa:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4bfd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4c00:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4c03:	81 c7 08 00          	add    di,0x8
    4c07:	06                   	push   es
    4c08:	57                   	push   di
    4c09:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4c0c:	81 c7 0a 00          	add    di,0xa
    4c10:	06                   	push   es
    4c11:	57                   	push   di
    4c12:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4c15:	81 c7 0c 00          	add    di,0xc
    4c19:	06                   	push   es
    4c1a:	57                   	push   di
    4c1b:	e8 87 e9             	call   0x35a5
    4c1e:	ff 76 08             	push   WORD PTR [bp+0x8]
    4c21:	ff 76 06             	push   WORD PTR [bp+0x6]
    4c24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c27:	06                   	push   es
    4c28:	57                   	push   di
    4c29:	9a 9e 40 82 4c       	call   0x4c82:0x409e
    4c2e:	c9                   	leave
    4c2f:	ca 08 00             	retf   0x8
    4c32:	c8 04 00 00          	enter  0x4,0x0
    4c36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c39:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4c3d:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    4c41:	74 1f                	je     0x4c62
    4c43:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4c47:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4c4a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4c4d:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4c51:	6a 01                	push   0x1
    4c53:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4c57:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4c5b:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4c5f:	e8 6f f1             	call   0x3dd1
    4c62:	c9                   	leave
    4c63:	ca 08 00             	retf   0x8
    4c66:	c8 0c 00 00          	enter  0xc,0x0
    4c6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c6d:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4c71:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    4c75:	75 03                	jne    0x4c7a
    4c77:	e9 a6 00             	jmp    0x4d20
    4c7a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4c7d:	06                   	push   es
    4c7e:	57                   	push   di
    4c7f:	9a d2 21 30 4d       	call   0x4d30:0x21d2
    4c84:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4c87:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4c8a:	9a ff ff 00 00       	call   0x0:0xffff
    4c8f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4c92:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4c95:	6a 08                	push   0x8
    4c97:	9a ff ff 00 00       	call   0x0:0xffff
    4c9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c9f:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4ca3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4ca6:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4caa:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4cae:	6a 00                	push   0x0
    4cb0:	6a 00                	push   0x0
    4cb2:	9a ff ff 00 00       	call   0x0:0xffff
    4cb7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4cba:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4cbd:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4cc1:	26 2b 05             	sub    ax,WORD PTR es:[di]
    4cc4:	50                   	push   ax
    4cc5:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    4cc9:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    4ccd:	50                   	push   ax
    4cce:	6a 00                	push   0x0
    4cd0:	6a 00                	push   0x0
    4cd2:	9a ff ff 00 00       	call   0x0:0xffff
    4cd7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4cda:	8d 7e f8             	lea    di,[bp-0x8]
    4cdd:	16                   	push   ss
    4cde:	57                   	push   di
    4cdf:	9a ff ff 00 00       	call   0x0:0xffff
    4ce4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4ce7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4cea:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    4ced:	26 03 05             	add    ax,WORD PTR es:[di]
    4cf0:	50                   	push   ax
    4cf1:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4cf4:	26 03 45 02          	add    ax,WORD PTR es:[di+0x2]
    4cf8:	50                   	push   ax
    4cf9:	6a 00                	push   0x0
    4cfb:	6a 00                	push   0x0
    4cfd:	9a ff ff 00 00       	call   0x0:0xffff
    4d02:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4d05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d08:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4d0c:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4d10:	9a ff ff 00 00       	call   0x0:0xffff
    4d15:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4d18:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4d1b:	9a ff ff 00 00       	call   0x0:0xffff
    4d20:	c9                   	leave
    4d21:	ca 0c 00             	retf   0xc
    4d24:	c8 04 00 00          	enter  0x4,0x0
    4d28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d2b:	06                   	push   es
    4d2c:	57                   	push   di
    4d2d:	9a da 49 95 4d       	call   0x4d95:0x49da
    4d32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d35:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4d39:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4d3c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4d3f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d42:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d45:	81 c7 06 00          	add    di,0x6
    4d49:	06                   	push   es
    4d4a:	57                   	push   di
    4d4b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d4e:	06                   	push   es
    4d4f:	57                   	push   di
    4d50:	9a 7e 23 5f 4d       	call   0x4d5f:0x237e
    4d55:	52                   	push   dx
    4d56:	50                   	push   ax
    4d57:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d5a:	06                   	push   es
    4d5b:	57                   	push   di
    4d5c:	9a bf 23 90 50       	call   0x5090:0x23bf
    4d61:	59                   	pop    cx
    4d62:	5b                   	pop    bx
    4d63:	2b c1                	sub    ax,cx
    4d65:	1b d3                	sbb    dx,bx
    4d67:	52                   	push   dx
    4d68:	50                   	push   ax
    4d69:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4d6c:	81 c7 08 00          	add    di,0x8
    4d70:	06                   	push   es
    4d71:	57                   	push   di
    4d72:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4d75:	81 c7 0a 00          	add    di,0xa
    4d79:	06                   	push   es
    4d7a:	57                   	push   di
    4d7b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4d7e:	81 c7 0c 00          	add    di,0xc
    4d82:	06                   	push   es
    4d83:	57                   	push   di
    4d84:	e8 1e e8             	call   0x35a5
    4d87:	ff 76 08             	push   WORD PTR [bp+0x8]
    4d8a:	ff 76 06             	push   WORD PTR [bp+0x6]
    4d8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d90:	06                   	push   es
    4d91:	57                   	push   di
    4d92:	9a 9e 40 e3 4d       	call   0x4de3:0x409e
    4d97:	c9                   	leave
    4d98:	ca 08 00             	retf   0x8
    4d9b:	c8 04 00 00          	enter  0x4,0x0
    4d9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4da2:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4da6:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    4daa:	74 1f                	je     0x4dcb
    4dac:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4db0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4db3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4db6:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4dba:	6a 00                	push   0x0
    4dbc:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4dc0:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4dc4:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4dc8:	e8 06 f0             	call   0x3dd1
    4dcb:	c9                   	leave
    4dcc:	ca 08 00             	retf   0x8
    4dcf:	91                   	xchg   cx,ax
    4dd0:	4e                   	dec    si
    4dd1:	7b 4e                	jnp    0x4e21
    4dd3:	65 4e                	gs dec si
    4dd5:	86 4e 70             	xchg   BYTE PTR [bp+0x70],cl
    4dd8:	4e                   	dec    si
    4dd9:	a2 4e 65             	mov    ds:0x654e,al
    4ddc:	4e                   	dec    si
    4ddd:	65 4e                	gs dec si
    4ddf:	00 00                	add    BYTE PTR [bx+si],al
    4de1:	ea 4e 1f 4e c8       	jmp    0xc84e:0x1f4e
    4de6:	0c 00                	or     al,0x0
    4de8:	00 83 7e 0e          	add    BYTE PTR [bp+di+0xe7e],al
    4dec:	03 75 06             	add    si,WORD PTR [di+0x6]
    4def:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    4df3:	75 06                	jne    0x4dfb
    4df5:	68 1f f0             	push   0xf01f
    4df8:	e8 3b d7             	call   0x2536
    4dfb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4dfe:	9a 61 4f 00 00       	call   0x0:0x4f61
    4e03:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4e06:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4e09:	b8 df 4d             	mov    ax,0x4ddf
    4e0c:	0e                   	push   cs
    4e0d:	50                   	push   ax
    4e0e:	55                   	push   bp
    4e0f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4e13:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4e17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e1a:	06                   	push   es
    4e1b:	57                   	push   di
    4e1c:	9a da 49 01 4f       	call   0x4f01:0x49da
    4e21:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4e24:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    4e27:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    4e2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e2d:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4e31:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    4e34:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    4e37:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4e3a:	26 83 7d 02 01       	cmp    WORD PTR es:[di+0x2],0x1
    4e3f:	7c 07                	jl     0x4e48
    4e41:	26 83 7d 04 01       	cmp    WORD PTR es:[di+0x4],0x1
    4e46:	7d 06                	jge    0x4e4e
    4e48:	68 1f f0             	push   0xf01f
    4e4b:	e8 e8 d6             	call   0x2536
    4e4e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4e51:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4e54:	2d 01 00             	sub    ax,0x1
    4e57:	3d 07 00             	cmp    ax,0x7
    4e5a:	77 4f                	ja     0x4eab
    4e5c:	89 c3                	mov    bx,ax
    4e5e:	d1 e3                	shl    bx,1
    4e60:	2e ff a7 cf 4d       	jmp    WORD PTR cs:[bx+0x4dcf]
    4e65:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4e68:	26 c7 45 0c ec 09    	mov    WORD PTR es:[di+0xc],0x9ec
    4e6e:	eb 3b                	jmp    0x4eab
    4e70:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4e73:	26 c7 45 0c e8 03    	mov    WORD PTR es:[di+0xc],0x3e8
    4e79:	eb 30                	jmp    0x4eab
    4e7b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4e7e:	26 c7 45 0c fe 00    	mov    WORD PTR es:[di+0xc],0xfe
    4e84:	eb 25                	jmp    0x4eab
    4e86:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4e89:	26 c7 45 0c 64 00    	mov    WORD PTR es:[di+0xc],0x64
    4e8f:	eb 1a                	jmp    0x4eab
    4e91:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4e95:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    4e99:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4e9c:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    4ea0:	eb 09                	jmp    0x4eab
    4ea2:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4ea5:	26 c7 45 0c a0 05    	mov    WORD PTR es:[di+0xc],0x5a0
    4eab:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4eae:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    4eb2:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4eb5:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    4eb9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4ebc:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4ec0:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4ec3:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    4ec7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4eca:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    4ece:	6a 00                	push   0x0
    4ed0:	6a 00                	push   0x0
    4ed2:	9a 29 50 00 00       	call   0x0:0x5029
    4ed7:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    4eda:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    4ede:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4ee2:	83 c4 06             	add    sp,0x6
    4ee5:	b8 f3 4e             	mov    ax,0x4ef3
    4ee8:	0e                   	push   cs
    4ee9:	50                   	push   ax
    4eea:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4eed:	9a 47 50 00 00       	call   0x0:0x5047
    4ef2:	cb                   	retf
    4ef3:	ff 76 08             	push   WORD PTR [bp+0x8]
    4ef6:	ff 76 06             	push   WORD PTR [bp+0x6]
    4ef9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4efc:	06                   	push   es
    4efd:	57                   	push   di
    4efe:	9a 9e 40 0b 4f       	call   0x4f0b:0x409e
    4f03:	c9                   	leave
    4f04:	ca 0a 00             	retf   0xa
    4f07:	00 00                	add    BYTE PTR [bx+si],al
    4f09:	40                   	inc    ax
    4f0a:	50                   	push   ax
    4f0b:	15 4f 01             	adc    ax,0x14f
    4f0e:	00 00                	add    BYTE PTR [bx+si],al
    4f10:	00 00                	add    BYTE PTR [bx+si],al
    4f12:	00 55 50             	add    BYTE PTR [di+0x50],dl
    4f15:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    4f16:	50                   	push   ax
    4f17:	c8 0e 00 00          	enter  0xe,0x0
    4f1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f1e:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    4f22:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    4f26:	75 03                	jne    0x4f2b
    4f28:	e9 3f 01             	jmp    0x506a
    4f2b:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    4f2e:	26 c7 05 03 00       	mov    WORD PTR es:[di],0x3
    4f33:	6a 02                	push   0x2
    4f35:	6a 00                	push   0x0
    4f37:	6a 08                	push   0x8
    4f39:	9a ff ff 00 00       	call   0x0:0xffff
    4f3e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4f41:	26 89 05             	mov    WORD PTR es:[di],ax
    4f44:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4f47:	31 c0                	xor    ax,ax
    4f49:	26 89 05             	mov    WORD PTR es:[di],ax
    4f4c:	b8 0d 4f             	mov    ax,0x4f0d
    4f4f:	0e                   	push   cs
    4f50:	50                   	push   ax
    4f51:	55                   	push   bp
    4f52:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4f56:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4f5a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4f5d:	26 ff 35             	push   WORD PTR es:[di]
    4f60:	9a ff ff 00 00       	call   0x0:0xffff
    4f65:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4f68:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4f6b:	b8 07 4f             	mov    ax,0x4f07
    4f6e:	0e                   	push   cs
    4f6f:	50                   	push   ax
    4f70:	55                   	push   bp
    4f71:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4f75:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4f79:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4f7c:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    4f7f:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    4f82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f85:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    4f89:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    4f8c:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    4f8f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4f92:	26 c7 05 03 00       	mov    WORD PTR es:[di],0x3
    4f97:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    4f9b:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    4f9f:	99                   	cwd
    4fa0:	8b c8                	mov    cx,ax
    4fa2:	8b da                	mov    bx,dx
    4fa4:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4fa7:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    4fab:	31 d2                	xor    dx,dx
    4fad:	3b d3                	cmp    dx,bx
    4faf:	75 0e                	jne    0x4fbf
    4fb1:	3b c1                	cmp    ax,cx
    4fb3:	75 0a                	jne    0x4fbf
    4fb5:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4fb8:	26 c7 05 01 00       	mov    WORD PTR es:[di],0x1
    4fbd:	eb 42                	jmp    0x5001
    4fbf:	31 c0                	xor    ax,ax
    4fc1:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4fc4:	eb 03                	jmp    0x4fc9
    4fc6:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    4fc9:	8b 7e fa             	mov    di,WORD PTR [bp-0x6]
    4fcc:	d1 e7                	shl    di,1
    4fce:	8b 85 f8 12          	mov    ax,WORD PTR [di+0x12f8]
    4fd2:	99                   	cwd
    4fd3:	8b c8                	mov    cx,ax
    4fd5:	8b da                	mov    bx,dx
    4fd7:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    4fda:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    4fde:	31 d2                	xor    dx,dx
    4fe0:	3b d3                	cmp    dx,bx
    4fe2:	7c 06                	jl     0x4fea
    4fe4:	7f 15                	jg     0x4ffb
    4fe6:	3b c1                	cmp    ax,cx
    4fe8:	77 11                	ja     0x4ffb
    4fea:	8b 7e fa             	mov    di,WORD PTR [bp-0x6]
    4fed:	d1 e7                	shl    di,1
    4fef:	8b 85 02 13          	mov    ax,WORD PTR [di+0x1302]
    4ff3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    4ff6:	26 89 05             	mov    WORD PTR es:[di],ax
    4ff9:	eb 06                	jmp    0x5001
    4ffb:	83 7e fa 04          	cmp    WORD PTR [bp-0x6],0x4
    4fff:	75 c5                	jne    0x4fc6
    5001:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    5004:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    5008:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    500b:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    500f:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    5012:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    5016:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    5019:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    501d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    5020:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    5024:	6a 00                	push   0x0
    5026:	6a 00                	push   0x0
    5028:	9a ff ff 00 00       	call   0x0:0xffff
    502d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    5030:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    5034:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5038:	83 c4 06             	add    sp,0x6
    503b:	b8 4c 50             	mov    ax,0x504c
    503e:	0e                   	push   cs
    503f:	50                   	push   ax
    5040:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5043:	26 ff 35             	push   WORD PTR es:[di]
    5046:	9a ff ff 00 00       	call   0x0:0xffff
    504b:	cb                   	retf
    504c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5050:	83 c4 06             	add    sp,0x6
    5053:	eb 15                	jmp    0x506a
    5055:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5058:	26 ff 35             	push   WORD PTR es:[di]
    505b:	9a ff ff 00 00       	call   0x0:0xffff
    5060:	ea 85 13 68 50       	jmp    0x5068:0x1385
    5065:	9a 34 14 88 50       	call   0x5088:0x1434
    506a:	c9                   	leave
    506b:	ca 10 00             	retf   0x10
    506e:	b4 50                	mov    ah,0x50
    5070:	00 00                	add    BYTE PTR [bx+si],al
    5072:	00 00                	add    BYTE PTR [bx+si],al
    5074:	00 00                	add    BYTE PTR [bx+si],al
    5076:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    5077:	50                   	push   ax
    5078:	33 00                	xor    ax,WORD PTR [bx+si]
    507a:	60                   	pusha
    507b:	05 c5 50             	add    ax,0x50c5
    507e:	64 20 71 51          	and    BYTE PTR fs:[bx+di+0x51],dh
    5082:	9a 1f 80 50 cb       	call   0xcb50:0x801f
    5087:	1f                   	pop    ds
    5088:	84 50 a8             	test   BYTE PTR [bx+si-0x58],dl
    508b:	51                   	push   cx
    508c:	9c                   	pushf
    508d:	50                   	push   ax
    508e:	cd 11                	int    0x11
    5090:	94                   	xchg   sp,ax
    5091:	50                   	push   ax
    5092:	e4 11                	in     al,0x11
    5094:	98                   	cbw
    5095:	50                   	push   ax
    5096:	fa                   	cli
    5097:	10 f1                	adc    cl,dh
    5099:	50                   	push   ax
    509a:	7f 23                	jg     0x50bf
    509c:	a0 50 5b             	mov    al,ds:0x5b50
    509f:	23 7c 50             	and    di,WORD PTR [si+0x50]
    50a2:	3c 52                	cmp    al,0x52
    50a4:	8c 50 0d             	mov    WORD PTR [bx+si+0xd],ss
    50a7:	54                   	push   sp
    50a8:	42                   	inc    dx
    50a9:	69 74 6d 61 70       	imul   si,WORD PTR [si+0x6d],0x7061
    50ae:	43                   	inc    bx
    50af:	61                   	popa
    50b0:	6e                   	outs   dx,BYTE PTR ds:[si]
    50b1:	76 61                	jbe    0x5114
    50b3:	73 07                	jae    0x50bc
    50b5:	0d 54 42             	or     ax,0x4254
    50b8:	69 74 6d 61 70       	imul   si,WORD PTR [si+0x6d],0x7061
    50bd:	43                   	inc    bx
    50be:	61                   	popa
    50bf:	6e                   	outs   dx,BYTE PTR ds:[si]
    50c0:	76 61                	jbe    0x5123
    50c2:	73 8e                	jae    0x5052
    50c4:	50                   	push   ax
    50c5:	c9                   	leave
    50c6:	50                   	push   ax
    50c7:	80 05 fc             	add    BYTE PTR [di],0xfc
    50ca:	50                   	push   ax
    50cb:	04 00                	add    al,0x0
    50cd:	08 47 72             	or     BYTE PTR [bx+0x72],al
    50d0:	61                   	popa
    50d1:	70 68                	jo     0x513b
    50d3:	69 63 73 00 00       	imul   sp,WORD PTR [bp+di+0x73],0x0
    50d8:	55                   	push   bp
    50d9:	89 e5                	mov    bp,sp
    50db:	c4 3e 70 2b          	les    di,DWORD PTR ds:0x2b70
    50df:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    50e4:	7e 1a                	jle    0x5100
    50e6:	6a 00                	push   0x0
    50e8:	c4 3e 70 2b          	les    di,DWORD PTR ds:0x2b70
    50ec:	06                   	push   es
    50ed:	57                   	push   di
    50ee:	9a d0 0d 27 51       	call   0x5127:0xdd0
    50f3:	89 c7                	mov    di,ax
    50f5:	8e c2                	mov    es,dx
    50f7:	06                   	push   es
    50f8:	57                   	push   di
    50f9:	9a d1 51 56 51       	call   0x5156:0x51d1
    50fe:	eb db                	jmp    0x50db
    5100:	c9                   	leave
    5101:	cb                   	retf
    5102:	c8 06 00 00          	enter  0x6,0x0
    5106:	c4 3e 70 2b          	les    di,DWORD PTR ds:0x2b70
    510a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    510e:	48                   	dec    ax
    510f:	09 c0                	or     ax,ax
    5111:	7c 4b                	jl     0x515e
    5113:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5116:	eb 03                	jmp    0x511b
    5118:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    511b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    511e:	c4 3e 70 2b          	les    di,DWORD PTR ds:0x2b70
    5122:	06                   	push   es
    5123:	57                   	push   di
    5124:	9a d0 0d 36 52       	call   0x5236:0xdd0
    5129:	89 c7                	mov    di,ax
    512b:	8e c2                	mov    es,dx
    512d:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    5130:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    5133:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    5137:	26 0b 45 2d          	or     ax,WORD PTR es:[di+0x2d]
    513b:	74 1b                	je     0x5158
    513d:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    5141:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5145:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    5149:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
    514c:	75 0a                	jne    0x5158
    514e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5151:	06                   	push   es
    5152:	57                   	push   di
    5153:	9a d1 51 7e 51       	call   0x517e:0x51d1
    5158:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    515c:	75 ba                	jne    0x5118
    515e:	c9                   	leave
    515f:	c2 02 00             	ret    0x2
    5162:	55                   	push   bp
    5163:	89 e5                	mov    bp,sp
    5165:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5169:	74 08                	je     0x5173
    516b:	83 ec 08             	sub    sp,0x8
    516e:	9a e2 1f cb 51       	call   0x51cb:0x1fe2
    5173:	31 c0                	xor    ax,ax
    5175:	50                   	push   ax
    5176:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5179:	06                   	push   es
    517a:	57                   	push   di
    517b:	9a b8 17 b3 51       	call   0x51b3:0x17b8
    5180:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    5183:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    5186:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5189:	26 89 45 2b          	mov    WORD PTR es:[di+0x2b],ax
    518d:	26 89 55 2d          	mov    WORD PTR es:[di+0x2d],dx
    5191:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5195:	74 07                	je     0x519e
    5197:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    519b:	83 c4 06             	add    sp,0x6
    519e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    51a1:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    51a4:	c9                   	leave
    51a5:	ca 0a 00             	retf   0xa
    51a8:	55                   	push   bp
    51a9:	89 e5                	mov    bp,sp
    51ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51ae:	06                   	push   es
    51af:	57                   	push   di
    51b0:	9a d1 51 c0 51       	call   0x51c0:0x51d1
    51b5:	31 c0                	xor    ax,ax
    51b7:	50                   	push   ax
    51b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51bb:	06                   	push   es
    51bc:	57                   	push   di
    51bd:	9a b7 18 1d 52       	call   0x521d:0x18b7
    51c2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    51c6:	74 05                	je     0x51cd
    51c8:	9a 0f 20 49 53       	call   0x5349:0x200f
    51cd:	c9                   	leave
    51ce:	ca 06 00             	retf   0x6
    51d1:	c8 02 00 00          	enter  0x2,0x0
    51d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51d8:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    51dd:	74 59                	je     0x5238
    51df:	26 83 7d 2f 00       	cmp    WORD PTR es:[di+0x2f],0x0
    51e4:	74 0d                	je     0x51f3
    51e6:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    51ea:	26 ff 75 2f          	push   WORD PTR es:[di+0x2f]
    51ee:	9a 9c 52 00 00       	call   0x0:0x529c
    51f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51f6:	26 83 7d 31 00       	cmp    WORD PTR es:[di+0x31],0x0
    51fb:	74 0f                	je     0x520c
    51fd:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    5201:	26 ff 75 31          	push   WORD PTR es:[di+0x31]
    5205:	6a 01                	push   0x1
    5207:	9a d9 52 00 00       	call   0x0:0x52d9
    520c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    520f:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5213:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5216:	6a 00                	push   0x0
    5218:	06                   	push   es
    5219:	57                   	push   di
    521a:	9a 5d 22 59 52       	call   0x5259:0x225d
    521f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5222:	9a cb 55 00 00       	call   0x0:0x55cb
    5227:	ff 76 08             	push   WORD PTR [bp+0x8]
    522a:	ff 76 06             	push   WORD PTR [bp+0x6]
    522d:	c4 3e 70 2b          	les    di,DWORD PTR ds:0x2b70
    5231:	06                   	push   es
    5232:	57                   	push   di
    5233:	9a a7 0f 13 53       	call   0x5313:0xfa7
    5238:	c9                   	leave
    5239:	ca 04 00             	retf   0x4
    523c:	c8 02 00 00          	enter  0x2,0x0
    5240:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5243:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    5247:	26 0b 45 2d          	or     ax,WORD PTR es:[di+0x2d]
    524b:	75 03                	jne    0x5250
    524d:	e9 c5 00             	jmp    0x5315
    5250:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    5254:	06                   	push   es
    5255:	57                   	push   di
    5256:	9a c4 5b 02 53       	call   0x5302:0x5bc4
    525b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    525e:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    5262:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5266:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    526a:	e8 95 fe             	call   0x5102
    526d:	6a 00                	push   0x0
    526f:	9a ec 53 00 00       	call   0x0:0x53ec
    5274:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5277:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    527a:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    527e:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5282:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    5287:	74 20                	je     0x52a9
    5289:	ff 76 fe             	push   WORD PTR [bp-0x2]
    528c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    528f:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    5293:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5297:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    529b:	9a 4e 54 00 00       	call   0x0:0x544e
    52a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52a3:	26 89 45 2f          	mov    WORD PTR es:[di+0x2f],ax
    52a7:	eb 09                	jmp    0x52b2
    52a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52ac:	31 c0                	xor    ax,ax
    52ae:	26 89 45 2f          	mov    WORD PTR es:[di+0x2f],ax
    52b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52b5:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    52b9:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    52bd:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    52c2:	74 2a                	je     0x52ee
    52c4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    52c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52ca:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    52ce:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    52d2:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    52d6:	6a 01                	push   0x1
    52d8:	9a 2c 55 00 00       	call   0x0:0x552c
    52dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52e0:	26 89 45 31          	mov    WORD PTR es:[di+0x31],ax
    52e4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    52e7:	9a 34 55 00 00       	call   0x0:0x5534
    52ec:	eb 09                	jmp    0x52f7
    52ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52f1:	31 c0                	xor    ax,ax
    52f3:	26 89 45 31          	mov    WORD PTR es:[di+0x31],ax
    52f7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    52fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52fd:	06                   	push   es
    52fe:	57                   	push   di
    52ff:	9a 5d 22 ae 53       	call   0x53ae:0x225d
    5304:	ff 76 08             	push   WORD PTR [bp+0x8]
    5307:	ff 76 06             	push   WORD PTR [bp+0x6]
    530a:	c4 3e 70 2b          	les    di,DWORD PTR ds:0x2b70
    530e:	06                   	push   es
    530f:	57                   	push   di
    5310:	9a 2b 0c 72 54       	call   0x5472:0xc2b
    5315:	c9                   	leave
    5316:	ca 04 00             	retf   0x4
    5319:	55                   	push   bp
    531a:	89 e5                	mov    bp,sp
    531c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    531f:	26 ff 45 04          	inc    WORD PTR es:[di+0x4]
    5323:	c9                   	leave
    5324:	ca 04 00             	retf   0x4
    5327:	55                   	push   bp
    5328:	89 e5                	mov    bp,sp
    532a:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    532d:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
    5330:	74 2e                	je     0x5360
    5332:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5335:	26 ff 4d 04          	dec    WORD PTR es:[di+0x4]
    5339:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    533e:	75 20                	jne    0x5360
    5340:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5344:	06                   	push   es
    5345:	57                   	push   di
    5346:	9a 7f 1f 5e 53       	call   0x535e:0x1f7f
    534b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    534e:	06                   	push   es
    534f:	57                   	push   di
    5350:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5353:	26 ff 1d             	call   DWORD PTR es:[di]
    5356:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5359:	06                   	push   es
    535a:	57                   	push   di
    535b:	9a 7f 1f ef 55       	call   0x55ef:0x1f7f
    5360:	c9                   	leave
    5361:	ca 04 00             	retf   0x4
    5364:	55                   	push   bp
    5365:	89 e5                	mov    bp,sp
    5367:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    536a:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    536f:	74 13                	je     0x5384
    5371:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    5375:	e8 8a fd             	call   0x5102
    5378:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    537b:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    537f:	9a 93 53 00 00       	call   0x0:0x5393
    5384:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5387:	26 83 7d 0c 00       	cmp    WORD PTR es:[di+0xc],0x0
    538c:	74 09                	je     0x5397
    538e:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    5392:	9a e8 55 00 00       	call   0x0:0x55e8
    5397:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    539a:	31 c0                	xor    ax,ax
    539c:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    53a0:	31 c0                	xor    ax,ax
    53a2:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    53a6:	c9                   	leave
    53a7:	ca 04 00             	retf   0x4
    53aa:	00 00                	add    BYTE PTR [bx+si],al
    53ac:	c7                   	(bad)
    53ad:	55                   	push   bp
    53ae:	b8 53 01             	mov    ax,0x153
    53b1:	00 00                	add    BYTE PTR [bx+si],al
    53b3:	00 00                	add    BYTE PTR [bx+si],al
    53b5:	00 d9                	add    cl,bl
    53b7:	55                   	push   bp
    53b8:	be 53 00             	mov    si,0x53
    53bb:	00 02                	add    BYTE PTR [bp+si],al
    53bd:	56                   	push   si
    53be:	80 54 c8 22          	adc    BYTE PTR [si-0x38],0x22
    53c2:	00 00                	add    BYTE PTR [bx+si],al
    53c4:	31 c0                	xor    ax,ax
    53c6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    53c9:	83 7e 10 00          	cmp    WORD PTR [bp+0x10],0x0
    53cd:	75 0f                	jne    0x53de
    53cf:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    53d3:	74 06                	je     0x53db
    53d5:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    53d9:	75 03                	jne    0x53de
    53db:	e9 37 02             	jmp    0x5615
    53de:	6a 00                	push   0x0
    53e0:	9a ff ff 00 00       	call   0x0:0xffff
    53e5:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    53e8:	ff 76 ea             	push   WORD PTR [bp-0x16]
    53eb:	9a eb 54 00 00       	call   0x0:0x54eb
    53f0:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    53f3:	b8 ba 53             	mov    ax,0x53ba
    53f6:	0e                   	push   cs
    53f7:	50                   	push   ax
    53f8:	55                   	push   bp
    53f9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    53fd:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5401:	80 7e 04 00          	cmp    BYTE PTR [bp+0x4],0x0
    5405:	74 18                	je     0x541f
    5407:	ff 76 0c             	push   WORD PTR [bp+0xc]
    540a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    540d:	6a 01                	push   0x1
    540f:	6a 01                	push   0x1
    5411:	6a 00                	push   0x0
    5413:	6a 00                	push   0x0
    5415:	9a ff ff 00 00       	call   0x0:0xffff
    541a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    541d:	eb 11                	jmp    0x5430
    541f:	ff 76 ea             	push   WORD PTR [bp-0x16]
    5422:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5425:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5428:	9a ff ff 00 00       	call   0x0:0xffff
    542d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5430:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    5434:	75 03                	jne    0x5439
    5436:	e8 4b d1             	call   0x2584
    5439:	b8 b0 53             	mov    ax,0x53b0
    543c:	0e                   	push   cs
    543d:	50                   	push   ax
    543e:	55                   	push   bp
    543f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5443:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5447:	ff 76 e8             	push   WORD PTR [bp-0x18]
    544a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    544d:	9a 16 55 00 00       	call   0x0:0x5516
    5452:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    5455:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5458:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
    545b:	74 6a                	je     0x54c7
    545d:	ff 76 e8             	push   WORD PTR [bp-0x18]
    5460:	8d 7e de             	lea    di,[bp-0x22]
    5463:	16                   	push   ss
    5464:	57                   	push   di
    5465:	6a 00                	push   0x0
    5467:	6a 00                	push   0x0
    5469:	ff 76 0c             	push   WORD PTR [bp+0xc]
    546c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    546f:	9a 88 06 fd 5b       	call   0x5bfd:0x688
    5474:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5477:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    547b:	06                   	push   es
    547c:	57                   	push   di
    547d:	9a c0 16 9d 54       	call   0x549d:0x16c0
    5482:	50                   	push   ax
    5483:	9a ff ff 00 00       	call   0x0:0xffff
    5488:	ff 76 e8             	push   WORD PTR [bp-0x18]
    548b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    548e:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    5492:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    5496:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    549a:	9a a5 0c b5 54       	call   0x54b5:0xca5
    549f:	52                   	push   dx
    54a0:	50                   	push   ax
    54a1:	9a 6f 55 00 00       	call   0x0:0x556f
    54a6:	ff 76 e8             	push   WORD PTR [bp-0x18]
    54a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54ac:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    54b0:	06                   	push   es
    54b1:	57                   	push   di
    54b2:	9a 61 16 bc 54       	call   0x54bc:0x1661
    54b7:	52                   	push   dx
    54b8:	50                   	push   ax
    54b9:	9a a5 0c 6a 55       	call   0x556a:0xca5
    54be:	52                   	push   dx
    54bf:	50                   	push   ax
    54c0:	9a 8e 55 00 00       	call   0x0:0x558e
    54c5:	eb 17                	jmp    0x54de
    54c7:	ff 76 e8             	push   WORD PTR [bp-0x18]
    54ca:	6a 00                	push   0x0
    54cc:	6a 00                	push   0x0
    54ce:	ff 76 0c             	push   WORD PTR [bp+0xc]
    54d1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    54d4:	68 ff 00             	push   0xff
    54d7:	6a 62                	push   0x62
    54d9:	9a ff ff 00 00       	call   0x0:0xffff
    54de:	83 7e 10 00          	cmp    WORD PTR [bp+0x10],0x0
    54e2:	75 03                	jne    0x54e7
    54e4:	e9 e9 00             	jmp    0x55d0
    54e7:	ff 76 ea             	push   WORD PTR [bp-0x16]
    54ea:	9a e0 6f 00 00       	call   0x0:0x6fe0
    54ef:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    54f2:	83 7e e6 00          	cmp    WORD PTR [bp-0x1a],0x0
    54f6:	75 03                	jne    0x54fb
    54f8:	e8 89 d0             	call   0x2584
    54fb:	b8 aa 53             	mov    ax,0x53aa
    54fe:	0e                   	push   cs
    54ff:	50                   	push   ax
    5500:	55                   	push   bp
    5501:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5505:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5509:	ff 76 10             	push   WORD PTR [bp+0x10]
    550c:	e8 f3 fb             	call   0x5102
    550f:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    5512:	ff 76 10             	push   WORD PTR [bp+0x10]
    5515:	9a b7 55 00 00       	call   0x0:0x55b7
    551a:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    551d:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
    5521:	74 2a                	je     0x554d
    5523:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    5526:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5529:	6a 01                	push   0x1
    552b:	9a 41 55 00 00       	call   0x0:0x5541
    5530:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    5533:	9a 49 55 00 00       	call   0x0:0x5549
    5538:	ff 76 e8             	push   WORD PTR [bp-0x18]
    553b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    553e:	6a 01                	push   0x1
    5540:	9a ff ff 00 00       	call   0x0:0xffff
    5545:	ff 76 e8             	push   WORD PTR [bp-0x18]
    5548:	9a ff ff 00 00       	call   0x0:0xffff
    554d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5550:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
    5553:	74 3d                	je     0x5592
    5555:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    5558:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    555b:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    555f:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    5563:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    5567:	9a a5 0c 82 55       	call   0x5582:0xca5
    556c:	52                   	push   dx
    556d:	50                   	push   ax
    556e:	9a 1f 6f 00 00       	call   0x0:0x6f1f
    5573:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    5576:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5579:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    557d:	06                   	push   es
    557e:	57                   	push   di
    557f:	9a 61 16 89 55       	call   0x5589:0x1661
    5584:	52                   	push   dx
    5585:	50                   	push   ax
    5586:	9a a5 0c 20 56       	call   0x5620:0xca5
    558b:	52                   	push   dx
    558c:	50                   	push   ax
    558d:	9a 3a 6f 00 00       	call   0x0:0x6f3a
    5592:	ff 76 e8             	push   WORD PTR [bp-0x18]
    5595:	6a 00                	push   0x0
    5597:	6a 00                	push   0x0
    5599:	ff 76 0c             	push   WORD PTR [bp+0xc]
    559c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    559f:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    55a2:	6a 00                	push   0x0
    55a4:	6a 00                	push   0x0
    55a6:	68 cc 00             	push   0xcc
    55a9:	6a 20                	push   0x20
    55ab:	9a ff ff 00 00       	call   0x0:0xffff
    55b0:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    55b3:	ff 76 ee             	push   WORD PTR [bp-0x12]
    55b6:	9a e0 55 00 00       	call   0x0:0x55e0
    55bb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    55bf:	83 c4 06             	add    sp,0x6
    55c2:	b8 d0 55             	mov    ax,0x55d0
    55c5:	0e                   	push   cs
    55c6:	50                   	push   ax
    55c7:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    55ca:	9a 06 56 00 00       	call   0x0:0x5606
    55cf:	cb                   	retf
    55d0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    55d4:	83 c4 06             	add    sp,0x6
    55d7:	eb 1d                	jmp    0x55f6
    55d9:	ff 76 e8             	push   WORD PTR [bp-0x18]
    55dc:	ff 76 ec             	push   WORD PTR [bp-0x14]
    55df:	9a ff ff 00 00       	call   0x0:0xffff
    55e4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    55e7:	9a 81 58 00 00       	call   0x0:0x5881
    55ec:	ea 85 13 f4 55       	jmp    0x55f4:0x1385
    55f1:	9a 34 14 56 56       	call   0x5656:0x1434
    55f6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    55fa:	83 c4 06             	add    sp,0x6
    55fd:	b8 15 56             	mov    ax,0x5615
    5600:	0e                   	push   cs
    5601:	50                   	push   ax
    5602:	ff 76 e8             	push   WORD PTR [bp-0x18]
    5605:	9a f8 6f 00 00       	call   0x0:0x6ff8
    560a:	6a 00                	push   0x0
    560c:	ff 76 ea             	push   WORD PTR [bp-0x16]
    560f:	9a ff ff 00 00       	call   0x0:0xffff
    5614:	cb                   	retf
    5615:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5618:	c9                   	leave
    5619:	c2 0e 00             	ret    0xe
    561c:	00 00                	add    BYTE PTR [bx+si],al
    561e:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
    561f:	56                   	push   si
    5620:	d9 56 c8             	fst    DWORD PTR [bp-0x38]
    5623:	0e                   	push   cs
    5624:	00 00                	add    BYTE PTR [bx+si],al
    5626:	31 c0                	xor    ax,ax
    5628:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    562b:	83 7e 04 00          	cmp    WORD PTR [bp+0x4],0x0
    562f:	75 03                	jne    0x5634
    5631:	e9 82 00             	jmp    0x56b6
    5634:	ff 76 04             	push   WORD PTR [bp+0x4]
    5637:	6a 02                	push   0x2
    5639:	8d 7e fc             	lea    di,[bp-0x4]
    563c:	16                   	push   ss
    563d:	57                   	push   di
    563e:	9a 48 5d 00 00       	call   0x0:0x5d48
    5643:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5646:	48                   	dec    ax
    5647:	c1 e0 02             	shl    ax,0x2
    564a:	05 08 00             	add    ax,0x8
    564d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5650:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5653:	9a 82 01 b3 56       	call   0x56b3:0x182
    5658:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    565b:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    565e:	b8 1c 56             	mov    ax,0x561c
    5661:	0e                   	push   cs
    5662:	50                   	push   ax
    5663:	55                   	push   bp
    5664:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5668:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    566c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    566f:	26 c7 05 00 03       	mov    WORD PTR es:[di],0x300
    5674:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5677:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    567b:	ff 76 04             	push   WORD PTR [bp+0x4]
    567e:	6a 00                	push   0x0
    5680:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5683:	81 c7 04 00          	add    di,0x4
    5687:	06                   	push   es
    5688:	57                   	push   di
    5689:	9a ff ff 00 00       	call   0x0:0xffff
    568e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    5691:	06                   	push   es
    5692:	57                   	push   di
    5693:	9a ff ff 00 00       	call   0x0:0xffff
    5698:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    569b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    569f:	83 c4 06             	add    sp,0x6
    56a2:	b8 b6 56             	mov    ax,0x56b6
    56a5:	0e                   	push   cs
    56a6:	50                   	push   ax
    56a7:	ff 76 f8             	push   WORD PTR [bp-0x8]
    56aa:	ff 76 f6             	push   WORD PTR [bp-0xa]
    56ad:	ff 76 fa             	push   WORD PTR [bp-0x6]
    56b0:	9a 9c 01 cc 56       	call   0x56cc:0x19c
    56b5:	cb                   	retf
    56b6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    56b9:	c9                   	leave
    56ba:	c2 02 00             	ret    0x2
    56bd:	55                   	push   bp
    56be:	89 e5                	mov    bp,sp
    56c0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    56c4:	74 08                	je     0x56ce
    56c6:	83 ec 08             	sub    sp,0x8
    56c9:	9a e2 1f e9 56       	call   0x56e9:0x1fe2
    56ce:	31 c0                	xor    ax,ax
    56d0:	50                   	push   ax
    56d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56d4:	06                   	push   es
    56d5:	57                   	push   di
    56d6:	9a 02 40 e2 56       	call   0x56e2:0x4002
    56db:	b0 01                	mov    al,0x1
    56dd:	50                   	push   ax
    56de:	b8 0e 08             	mov    ax,0x80e
    56e1:	ba ff 56             	mov    dx,0x56ff
    56e4:	52                   	push   dx
    56e5:	50                   	push   ax
    56e6:	9a 50 1f 35 57       	call   0x5735:0x1f50
    56eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56ee:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    56f2:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    56f6:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    56fa:	06                   	push   es
    56fb:	57                   	push   di
    56fc:	9a 19 53 27 57       	call   0x5727:0x5319
    5701:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5705:	74 07                	je     0x570e
    5707:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    570b:	83 c4 06             	add    sp,0x6
    570e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5711:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5714:	c9                   	leave
    5715:	ca 06 00             	retf   0x6
    5718:	55                   	push   bp
    5719:	89 e5                	mov    bp,sp
    571b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    571e:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5722:	06                   	push   es
    5723:	57                   	push   di
    5724:	9a 27 53 68 57       	call   0x5768:0x5327
    5729:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    572c:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    5730:	06                   	push   es
    5731:	57                   	push   di
    5732:	9a 7f 1f 42 57       	call   0x5742:0x1f7f
    5737:	31 c0                	xor    ax,ax
    5739:	50                   	push   ax
    573a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    573d:	06                   	push   es
    573e:	57                   	push   di
    573f:	9a 66 1f 4d 57       	call   0x574d:0x1f66
    5744:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5748:	74 05                	je     0x574f
    574a:	9a 0f 20 6f 57       	call   0x576f:0x200f
    574f:	c9                   	leave
    5750:	ca 06 00             	retf   0x6
    5753:	55                   	push   bp
    5754:	89 e5                	mov    bp,sp
    5756:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5759:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    575c:	74 17                	je     0x5775
    575e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5761:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5764:	bf 3f 08             	mov    di,0x83f
    5767:	b8 89 57             	mov    ax,0x5789
    576a:	50                   	push   ax
    576b:	57                   	push   di
    576c:	9a 55 22 88 58       	call   0x5888:0x2255
    5771:	08 c0                	or     al,al
    5773:	74 66                	je     0x57db
    5775:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5778:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    577b:	74 34                	je     0x57b1
    577d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5780:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5784:	06                   	push   es
    5785:	57                   	push   di
    5786:	9a 19 53 97 57       	call   0x5797:0x5319
    578b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    578e:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5792:	06                   	push   es
    5793:	57                   	push   di
    5794:	9a 27 53 c7 57       	call   0x57c7:0x5327
    5799:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    579c:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    57a0:	26 8b 55 10          	mov    dx,WORD PTR es:[di+0x10]
    57a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57a7:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    57ab:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    57af:	eb 18                	jmp    0x57c9
    57b1:	6a 00                	push   0x0
    57b3:	6a 00                	push   0x0
    57b5:	6a 00                	push   0x0
    57b7:	6a 00                	push   0x0
    57b9:	6a 00                	push   0x0
    57bb:	6a 00                	push   0x0
    57bd:	6a 00                	push   0x0
    57bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57c2:	06                   	push   es
    57c3:	57                   	push   di
    57c4:	9a 60 5e d7 57       	call   0x57d7:0x5e60
    57c9:	ff 76 08             	push   WORD PTR [bp+0x8]
    57cc:	ff 76 06             	push   WORD PTR [bp+0x6]
    57cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57d2:	06                   	push   es
    57d3:	57                   	push   di
    57d4:	9a 9e 40 e9 57       	call   0x57e9:0x409e
    57d9:	eb 10                	jmp    0x57eb
    57db:	ff 76 0c             	push   WORD PTR [bp+0xc]
    57de:	ff 76 0a             	push   WORD PTR [bp+0xa]
    57e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57e4:	06                   	push   es
    57e5:	57                   	push   di
    57e6:	9a 37 40 f7 57       	call   0x57f7:0x4037
    57eb:	c9                   	leave
    57ec:	ca 08 00             	retf   0x8
    57ef:	01 00                	add    WORD PTR [bx+si],ax
    57f1:	00 00                	add    BYTE PTR [bx+si],al
    57f3:	00 00                	add    BYTE PTR [bx+si],al
    57f5:	7d 58                	jge    0x584f
    57f7:	01 58 01             	add    WORD PTR [bx+si+0x1],bx
    57fa:	00 00                	add    BYTE PTR [bx+si],al
    57fc:	00 00                	add    BYTE PTR [bx+si],al
    57fe:	00 98 58 0e          	add    BYTE PTR [bx+si+0xe58],bl
    5802:	58                   	pop    ax
    5803:	55                   	push   bp
    5804:	89 e5                	mov    bp,sp
    5806:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5809:	06                   	push   es
    580a:	57                   	push   di
    580b:	9a a5 5b 72 58       	call   0x5872:0x5ba5
    5810:	ff 76 12             	push   WORD PTR [bp+0x12]
    5813:	ff 76 10             	push   WORD PTR [bp+0x10]
    5816:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5819:	ff 76 0c             	push   WORD PTR [bp+0xc]
    581c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    581f:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    5823:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    5827:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    582a:	50                   	push   ax
    582b:	e8 92 fb             	call   0x53c0
    582e:	89 46 12             	mov    WORD PTR [bp+0x12],ax
    5831:	b8 f9 57             	mov    ax,0x57f9
    5834:	0e                   	push   cs
    5835:	50                   	push   ax
    5836:	55                   	push   bp
    5837:	ff 36 58 18          	push   WORD PTR ds:0x1858
    583b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    583f:	ff 76 10             	push   WORD PTR [bp+0x10]
    5842:	e8 dd fd             	call   0x5622
    5845:	89 46 10             	mov    WORD PTR [bp+0x10],ax
    5848:	b8 ef 57             	mov    ax,0x57ef
    584b:	0e                   	push   cs
    584c:	50                   	push   ax
    584d:	55                   	push   bp
    584e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5852:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5856:	ff 76 12             	push   WORD PTR [bp+0x12]
    5859:	ff 76 10             	push   WORD PTR [bp+0x10]
    585c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    585f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5862:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5865:	50                   	push   ax
    5866:	6a 00                	push   0x0
    5868:	6a 00                	push   0x0
    586a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    586d:	06                   	push   es
    586e:	57                   	push   di
    586f:	9a 60 5e b9 58       	call   0x58b9:0x5e60
    5874:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5878:	83 c4 06             	add    sp,0x6
    587b:	eb 12                	jmp    0x588f
    587d:	ff 76 10             	push   WORD PTR [bp+0x10]
    5880:	9a 9c 58 00 00       	call   0x0:0x589c
    5885:	ea 85 13 8d 58       	jmp    0x588d:0x1385
    588a:	9a 34 14 a3 58       	call   0x58a3:0x1434
    588f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5893:	83 c4 06             	add    sp,0x6
    5896:	eb 12                	jmp    0x58aa
    5898:	ff 76 12             	push   WORD PTR [bp+0x12]
    589b:	9a d4 5d 00 00       	call   0x0:0x5dd4
    58a0:	ea 85 13 a8 58       	jmp    0x58a8:0x1385
    58a5:	9a 34 14 d0 59       	call   0x59d0:0x1434
    58aa:	c9                   	leave
    58ab:	ca 0e 00             	retf   0xe
    58ae:	55                   	push   bp
    58af:	89 e5                	mov    bp,sp
    58b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58b4:	06                   	push   es
    58b5:	57                   	push   di
    58b6:	9a 8b 59 ca 58       	call   0x58ca:0x598b
    58bb:	c9                   	leave
    58bc:	ca 08 00             	retf   0x8
    58bf:	55                   	push   bp
    58c0:	89 e5                	mov    bp,sp
    58c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58c5:	06                   	push   es
    58c6:	57                   	push   di
    58c7:	9a 6a 5c ed 58       	call   0x58ed:0x5c6a
    58cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58cf:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    58d3:	06                   	push   es
    58d4:	57                   	push   di
    58d5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    58d8:	26 ff 1d             	call   DWORD PTR es:[di]
    58db:	c9                   	leave
    58dc:	ca 04 00             	retf   0x4
    58df:	c8 08 00 00          	enter  0x8,0x0
    58e3:	6a 0f                	push   0xf
    58e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58e8:	06                   	push   es
    58e9:	57                   	push   di
    58ea:	9a 0f 5a f8 58       	call   0x58f8:0x5a0f
    58ef:	89 c7                	mov    di,ax
    58f1:	8e c2                	mov    es,dx
    58f3:	06                   	push   es
    58f4:	57                   	push   di
    58f5:	9a c2 22 02 59       	call   0x5902:0x22c2
    58fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58fd:	06                   	push   es
    58fe:	57                   	push   di
    58ff:	9a f4 5a 10 59       	call   0x5910:0x5af4
    5904:	08 c0                	or     al,al
    5906:	75 12                	jne    0x591a
    5908:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    590b:	06                   	push   es
    590c:	57                   	push   di
    590d:	9a d2 21 38 59       	call   0x5938:0x21d2
    5912:	50                   	push   ax
    5913:	6a 03                	push   0x3
    5915:	9a ff ff 00 00       	call   0x0:0xffff
    591a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    591d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5920:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5923:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5926:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    592a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    592d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    5930:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5933:	06                   	push   es
    5934:	57                   	push   di
    5935:	9a d2 21 5e 59       	call   0x595e:0x21d2
    593a:	50                   	push   ax
    593b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    593e:	26 ff 35             	push   WORD PTR es:[di]
    5941:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    5945:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5949:	26 2b 05             	sub    ax,WORD PTR es:[di]
    594c:	50                   	push   ax
    594d:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    5951:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
    5955:	50                   	push   ax
    5956:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5959:	06                   	push   es
    595a:	57                   	push   di
    595b:	9a 0f 5a c0 59       	call   0x59c0:0x5a0f
    5960:	89 c7                	mov    di,ax
    5962:	8e c2                	mov    es,dx
    5964:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    5968:	6a 00                	push   0x0
    596a:	6a 00                	push   0x0
    596c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    596f:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    5973:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    5977:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    597a:	26 ff 75 19          	push   WORD PTR es:[di+0x19]
    597e:	26 ff 75 17          	push   WORD PTR es:[di+0x17]
    5982:	9a ff ff 00 00       	call   0x0:0xffff
    5987:	c9                   	leave
    5988:	ca 0c 00             	retf   0xc
    598b:	c8 04 00 00          	enter  0x4,0x0
    598f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5992:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5996:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5999:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    599c:	26 83 7d 04 01       	cmp    WORD PTR es:[di+0x4],0x1
    59a1:	7e 21                	jle    0x59c4
    59a3:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    59a7:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    59ab:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    59af:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    59b3:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    59b7:	50                   	push   ax
    59b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59bb:	06                   	push   es
    59bc:	57                   	push   di
    59bd:	9a 03 58 25 5a       	call   0x5a25:0x5803
    59c2:	eb 1b                	jmp    0x59df
    59c4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    59c7:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    59cb:	06                   	push   es
    59cc:	57                   	push   di
    59cd:	9a 7f 1f 96 5c       	call   0x5c96:0x1f7f
    59d2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    59d5:	31 c0                	xor    ax,ax
    59d7:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    59db:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    59df:	c9                   	leave
    59e0:	ca 04 00             	retf   0x4
    59e3:	c8 06 00 00          	enter  0x6,0x0
    59e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59ea:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    59ee:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    59f3:	75 0a                	jne    0x59ff
    59f5:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    59f9:	26 0b 45 08          	or     ax,WORD PTR es:[di+0x8]
    59fd:	74 04                	je     0x5a03
    59ff:	b0 00                	mov    al,0x0
    5a01:	eb 02                	jmp    0x5a05
    5a03:	b0 01                	mov    al,0x1
    5a05:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5a08:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    5a0b:	c9                   	leave
    5a0c:	ca 04 00             	retf   0x4
    5a0f:	c8 04 00 00          	enter  0x4,0x0
    5a13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a16:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    5a1a:	26 0b 45 14          	or     ax,WORD PTR es:[di+0x14]
    5a1e:	75 63                	jne    0x5a83
    5a20:	06                   	push   es
    5a21:	57                   	push   di
    5a22:	9a c4 5b 34 5a       	call   0x5a34:0x5bc4
    5a27:	ff 76 08             	push   WORD PTR [bp+0x8]
    5a2a:	ff 76 06             	push   WORD PTR [bp+0x6]
    5a2d:	b0 01                	mov    al,0x1
    5a2f:	50                   	push   ax
    5a30:	b8 8e 50             	mov    ax,0x508e
    5a33:	ba 3b 5a             	mov    dx,0x5a3b
    5a36:	52                   	push   dx
    5a37:	50                   	push   ax
    5a38:	9a 62 51 4e 5a       	call   0x5a4e:0x5162
    5a3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a40:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    5a44:	26 89 55 14          	mov    WORD PTR es:[di+0x14],dx
    5a48:	06                   	push   es
    5a49:	57                   	push   di
    5a4a:	b8 9e 40             	mov    ax,0x409e
    5a4d:	ba 6d 5a             	mov    dx,0x5a6d
    5a50:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    5a54:	26 89 45 1b          	mov    WORD PTR es:[di+0x1b],ax
    5a58:	26 89 55 1d          	mov    WORD PTR es:[di+0x1d],dx
    5a5c:	26 8f 45 1f          	pop    WORD PTR es:[di+0x1f]
    5a60:	26 8f 45 21          	pop    WORD PTR es:[di+0x21]
    5a64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a67:	06                   	push   es
    5a68:	57                   	push   di
    5a69:	b8 ae 58             	mov    ax,0x58ae
    5a6c:	ba aa 5a             	mov    dx,0x5aaa
    5a6f:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    5a73:	26 89 45 23          	mov    WORD PTR es:[di+0x23],ax
    5a77:	26 89 55 25          	mov    WORD PTR es:[di+0x25],dx
    5a7b:	26 8f 45 27          	pop    WORD PTR es:[di+0x27]
    5a7f:	26 8f 45 29          	pop    WORD PTR es:[di+0x29]
    5a83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a86:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    5a8a:	26 8b 55 14          	mov    dx,WORD PTR es:[di+0x14]
    5a8e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5a91:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5a94:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5a97:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5a9a:	c9                   	leave
    5a9b:	ca 04 00             	retf   0x4
    5a9e:	c8 02 00 00          	enter  0x2,0x0
    5aa2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5aa5:	06                   	push   es
    5aa6:	57                   	push   di
    5aa7:	9a a5 5b b4 5a       	call   0x5ab4:0x5ba5
    5aac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5aaf:	06                   	push   es
    5ab0:	57                   	push   di
    5ab1:	9a c4 5b c4 5a       	call   0x5ac4:0x5bc4
    5ab6:	ff 76 08             	push   WORD PTR [bp+0x8]
    5ab9:	ff 76 06             	push   WORD PTR [bp+0x6]
    5abc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5abf:	06                   	push   es
    5ac0:	57                   	push   di
    5ac1:	9a ae 58 32 5b       	call   0x5b32:0x58ae
    5ac6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ac9:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5acd:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    5ad1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5ad4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5ad7:	c9                   	leave
    5ad8:	ca 04 00             	retf   0x4
    5adb:	c8 02 00 00          	enter  0x2,0x0
    5adf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ae2:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5ae6:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    5aea:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5aed:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5af0:	c9                   	leave
    5af1:	ca 04 00             	retf   0x4
    5af4:	c8 02 00 00          	enter  0x2,0x0
    5af8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5afb:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5aff:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    5b03:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5b06:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    5b09:	c9                   	leave
    5b0a:	ca 04 00             	retf   0x4
    5b0d:	c8 02 00 00          	enter  0x2,0x0
    5b11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b14:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5b18:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    5b1c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5b1f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5b22:	c9                   	leave
    5b23:	ca 04 00             	retf   0x4
    5b26:	c8 04 00 00          	enter  0x4,0x0
    5b2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b2d:	06                   	push   es
    5b2e:	57                   	push   di
    5b2f:	9a f4 5a 5c 5b       	call   0x5b5c:0x5af4
    5b34:	08 c0                	or     al,al
    5b36:	74 0c                	je     0x5b44
    5b38:	c7 46 fc ff ff       	mov    WORD PTR [bp-0x4],0xffff
    5b3d:	c7 46 fe ff 00       	mov    WORD PTR [bp-0x2],0xff
    5b42:	eb 2b                	jmp    0x5b6f
    5b44:	6a 00                	push   0x0
    5b46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b49:	06                   	push   es
    5b4a:	57                   	push   di
    5b4b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5b4e:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    5b52:	48                   	dec    ax
    5b53:	50                   	push   ax
    5b54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b57:	06                   	push   es
    5b58:	57                   	push   di
    5b59:	9a 0f 5a 67 5b       	call   0x5b67:0x5a0f
    5b5e:	89 c7                	mov    di,ax
    5b60:	8e c2                	mov    es,dx
    5b62:	06                   	push   es
    5b63:	57                   	push   di
    5b64:	9a 32 21 be 5b       	call   0x5bbe:0x2132
    5b69:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5b6c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5b6f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5b72:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5b75:	0d 00 00             	or     ax,0x0
    5b78:	81 ca 00 02          	or     dx,0x200
    5b7c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5b7f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5b82:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5b85:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5b88:	c9                   	leave
    5b89:	ca 04 00             	retf   0x4
    5b8c:	c8 02 00 00          	enter  0x2,0x0
    5b90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b93:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5b97:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    5b9b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5b9e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5ba1:	c9                   	leave
    5ba2:	ca 04 00             	retf   0x4
    5ba5:	55                   	push   bp
    5ba6:	89 e5                	mov    bp,sp
    5ba8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bab:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    5baf:	26 0b 45 14          	or     ax,WORD PTR es:[di+0x14]
    5bb3:	74 0b                	je     0x5bc0
    5bb5:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    5bb9:	06                   	push   es
    5bba:	57                   	push   di
    5bbb:	9a d1 51 68 5c       	call   0x5c68:0x51d1
    5bc0:	c9                   	leave
    5bc1:	ca 04 00             	retf   0x4
    5bc4:	c8 12 00 00          	enter  0x12,0x0
    5bc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bcb:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5bcf:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    5bd2:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    5bd5:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    5bda:	74 02                	je     0x5bde
    5bdc:	eb 7e                	jmp    0x5c5c
    5bde:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    5be1:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    5be5:	26 0b 45 08          	or     ax,WORD PTR es:[di+0x8]
    5be9:	75 02                	jne    0x5bed
    5beb:	eb 6f                	jmp    0x5c5c
    5bed:	6a 00                	push   0x0
    5bef:	6a 00                	push   0x0
    5bf1:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    5bf4:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5bf8:	06                   	push   es
    5bf9:	57                   	push   di
    5bfa:	9a a4 23 0b 5c       	call   0x5c0b:0x23a4
    5bff:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    5c02:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5c06:	06                   	push   es
    5c07:	57                   	push   di
    5c08:	9a bf 23 4f 5c       	call   0x5c4f:0x23bf
    5c0d:	09 d0                	or     ax,dx
    5c0f:	74 4b                	je     0x5c5c
    5c11:	8d 7e f2             	lea    di,[bp-0xe]
    5c14:	16                   	push   ss
    5c15:	57                   	push   di
    5c16:	6a 00                	push   0x0
    5c18:	6a 0e                	push   0xe
    5c1a:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    5c1d:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5c21:	06                   	push   es
    5c22:	57                   	push   di
    5c23:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5c26:	26 ff 1d             	call   DWORD PTR es:[di]
    5c29:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    5c2c:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    5c30:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    5c34:	81 c7 0a 00          	add    di,0xa
    5c38:	06                   	push   es
    5c39:	57                   	push   di
    5c3a:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    5c3d:	81 c7 0c 00          	add    di,0xc
    5c41:	06                   	push   es
    5c42:	57                   	push   di
    5c43:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    5c46:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    5c4a:	06                   	push   es
    5c4b:	57                   	push   di
    5c4c:	9a bf 23 8f 5c       	call   0x5c8f:0x23bf
    5c51:	2d 0e 00             	sub    ax,0xe
    5c54:	83 da 00             	sbb    dx,0x0
    5c57:	52                   	push   dx
    5c58:	50                   	push   ax
    5c59:	e8 6b d2             	call   0x2ec7
    5c5c:	c9                   	leave
    5c5d:	ca 04 00             	retf   0x4
    5c60:	01 00                	add    WORD PTR [bx+si],ax
    5c62:	00 00                	add    BYTE PTR [bx+si],al
    5c64:	00 00                	add    BYTE PTR [bx+si],al
    5c66:	e0 5c                	loopne 0x5cc4
    5c68:	11 5d c8             	adc    WORD PTR [di-0x38],bx
    5c6b:	08 00                	or     BYTE PTR [bx+si],al
    5c6d:	00 c4                	add    ah,al
    5c6f:	7e 06                	jle    0x5c77
    5c71:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5c75:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    5c78:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    5c7b:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    5c7f:	26 0b 45 08          	or     ax,WORD PTR es:[di+0x8]
    5c83:	74 03                	je     0x5c88
    5c85:	e9 7d 00             	jmp    0x5d05
    5c88:	b0 01                	mov    al,0x1
    5c8a:	50                   	push   ax
    5c8b:	b8 24 05             	mov    ax,0x524
    5c8e:	ba d5 5c             	mov    dx,0x5cd5
    5c91:	52                   	push   dx
    5c92:	50                   	push   ax
    5c93:	9a 50 1f e8 5c       	call   0x5ce8:0x1f50
    5c98:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5c9b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5c9e:	b8 60 5c             	mov    ax,0x5c60
    5ca1:	0e                   	push   cs
    5ca2:	50                   	push   ax
    5ca3:	55                   	push   bp
    5ca4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5ca8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5cac:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5caf:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    5cb4:	74 13                	je     0x5cc9
    5cb6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5cb9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5cbc:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    5cc0:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    5cc4:	6a 00                	push   0x0
    5cc6:	e8 2c dd             	call   0x39f5
    5cc9:	6a 00                	push   0x0
    5ccb:	6a 00                	push   0x0
    5ccd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5cd0:	06                   	push   es
    5cd1:	57                   	push   di
    5cd2:	9a a4 23 1c 5e       	call   0x5e1c:0x23a4
    5cd7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5cdb:	83 c4 06             	add    sp,0x6
    5cde:	eb 14                	jmp    0x5cf4
    5ce0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5ce3:	06                   	push   es
    5ce4:	57                   	push   di
    5ce5:	9a 7f 1f ed 5c       	call   0x5ced:0x1f7f
    5cea:	ea 85 13 f2 5c       	jmp    0x5cf2:0x1385
    5cef:	9a 34 14 db 5d       	call   0x5ddb:0x1434
    5cf4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5cf7:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5cfa:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5cfd:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    5d01:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    5d05:	c9                   	leave
    5d06:	ca 04 00             	retf   0x4
    5d09:	01 00                	add    WORD PTR [bx+si],ax
    5d0b:	00 00                	add    BYTE PTR [bx+si],al
    5d0d:	00 00                	add    BYTE PTR [bx+si],al
    5d0f:	d0 5d 1b             	rcr    BYTE PTR [di+0x1b],1
    5d12:	5d                   	pop    bp
    5d13:	01 00                	add    WORD PTR [bx+si],ax
    5d15:	00 00                	add    BYTE PTR [bx+si],al
    5d17:	00 00                	add    BYTE PTR [bx+si],al
    5d19:	eb 5d                	jmp    0x5d78
    5d1b:	3b 5d c8             	cmp    bx,WORD PTR [di-0x38]
    5d1e:	10 00                	adc    BYTE PTR [bx+si],al
    5d20:	00 83 7e 0e          	add    BYTE PTR [bp+di+0xe7e],al
    5d24:	02 75 06             	add    dh,BYTE PTR [di+0x6]
    5d27:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    5d2b:	75 06                	jne    0x5d33
    5d2d:	68 1f f0             	push   0xf01f
    5d30:	e8 03 c8             	call   0x2536
    5d33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d36:	06                   	push   es
    5d37:	57                   	push   di
    5d38:	9a a5 5b c5 5d       	call   0x5dc5:0x5ba5
    5d3d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5d40:	6a 0e                	push   0xe
    5d42:	8d 7e f0             	lea    di,[bp-0x10]
    5d45:	16                   	push   ss
    5d46:	57                   	push   di
    5d47:	9a 3c 61 00 00       	call   0x0:0x613c
    5d4c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5d4f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5d52:	ff 76 f2             	push   WORD PTR [bp-0xe]
    5d55:	ff 76 f4             	push   WORD PTR [bp-0xc]
    5d58:	6a 00                	push   0x0
    5d5a:	6a 00                	push   0x0
    5d5c:	80 7e f8 01          	cmp    BYTE PTR [bp-0x8],0x1
    5d60:	75 06                	jne    0x5d68
    5d62:	80 7e f9 01          	cmp    BYTE PTR [bp-0x7],0x1
    5d66:	74 04                	je     0x5d6c
    5d68:	b0 00                	mov    al,0x0
    5d6a:	eb 02                	jmp    0x5d6e
    5d6c:	b0 01                	mov    al,0x1
    5d6e:	50                   	push   ax
    5d6f:	e8 4e f6             	call   0x53c0
    5d72:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5d75:	b8 13 5d             	mov    ax,0x5d13
    5d78:	0e                   	push   cs
    5d79:	50                   	push   ax
    5d7a:	55                   	push   bp
    5d7b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5d7f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5d83:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5d86:	e8 99 f8             	call   0x5622
    5d89:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    5d8c:	b8 09 5d             	mov    ax,0x5d09
    5d8f:	0e                   	push   cs
    5d90:	50                   	push   ax
    5d91:	55                   	push   bp
    5d92:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5d96:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5d9a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5d9d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5da0:	ff 76 f2             	push   WORD PTR [bp-0xe]
    5da3:	ff 76 f4             	push   WORD PTR [bp-0xc]
    5da6:	80 7e f8 01          	cmp    BYTE PTR [bp-0x8],0x1
    5daa:	75 06                	jne    0x5db2
    5dac:	80 7e f9 01          	cmp    BYTE PTR [bp-0x7],0x1
    5db0:	74 04                	je     0x5db6
    5db2:	b0 00                	mov    al,0x0
    5db4:	eb 02                	jmp    0x5db8
    5db6:	b0 01                	mov    al,0x1
    5db8:	50                   	push   ax
    5db9:	6a 00                	push   0x0
    5dbb:	6a 00                	push   0x0
    5dbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dc0:	06                   	push   es
    5dc1:	57                   	push   di
    5dc2:	9a 60 5e 0b 5e       	call   0x5e0b:0x5e60
    5dc7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5dcb:	83 c4 06             	add    sp,0x6
    5dce:	eb 12                	jmp    0x5de2
    5dd0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5dd3:	9a ef 5d 00 00       	call   0x0:0x5def
    5dd8:	ea 85 13 e0 5d       	jmp    0x5de0:0x1385
    5ddd:	9a 34 14 f6 5d       	call   0x5df6:0x1434
    5de2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5de6:	83 c4 06             	add    sp,0x6
    5de9:	eb 12                	jmp    0x5dfd
    5deb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5dee:	9a be 61 00 00       	call   0x0:0x61be
    5df3:	ea 85 13 fb 5d       	jmp    0x5dfb:0x1385
    5df8:	9a 34 14 72 5e       	call   0x5e72:0x1434
    5dfd:	ff 76 08             	push   WORD PTR [bp+0x8]
    5e00:	ff 76 06             	push   WORD PTR [bp+0x6]
    5e03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e06:	06                   	push   es
    5e07:	57                   	push   di
    5e08:	9a 9e 40 40 5e       	call   0x5e40:0x409e
    5e0d:	c9                   	leave
    5e0e:	ca 0a 00             	retf   0xa
    5e11:	55                   	push   bp
    5e12:	89 e5                	mov    bp,sp
    5e14:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5e17:	06                   	push   es
    5e18:	57                   	push   di
    5e19:	9a 7e 23 28 5e       	call   0x5e28:0x237e
    5e1e:	52                   	push   dx
    5e1f:	50                   	push   ax
    5e20:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5e23:	06                   	push   es
    5e24:	57                   	push   di
    5e25:	9a bf 23 9a 5f       	call   0x5f9a:0x23bf
    5e2a:	59                   	pop    cx
    5e2b:	5b                   	pop    bx
    5e2c:	2b c1                	sub    ax,cx
    5e2e:	1b d3                	sbb    dx,bx
    5e30:	52                   	push   dx
    5e31:	50                   	push   ax
    5e32:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5e35:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5e38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e3b:	06                   	push   es
    5e3c:	57                   	push   di
    5e3d:	9a 62 5f 50 5e       	call   0x5e50:0x5f62
    5e42:	ff 76 08             	push   WORD PTR [bp+0x8]
    5e45:	ff 76 06             	push   WORD PTR [bp+0x6]
    5e48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e4b:	06                   	push   es
    5e4c:	57                   	push   di
    5e4d:	9a 9e 40 5e 5e       	call   0x5e5e:0x409e
    5e52:	c9                   	leave
    5e53:	ca 08 00             	retf   0x8
    5e56:	01 00                	add    WORD PTR [bx+si],ax
    5e58:	00 00                	add    BYTE PTR [bx+si],al
    5e5a:	00 00                	add    BYTE PTR [bx+si],al
    5e5c:	d4 5e                	aam    0x5e
    5e5e:	6b 5e c8 04          	imul   bx,WORD PTR [bp-0x38],0x4
    5e62:	00 00                	add    BYTE PTR [bx+si],al
    5e64:	b0 01                	mov    al,0x1
    5e66:	50                   	push   ax
    5e67:	b8 0e 08             	mov    ax,0x80e
    5e6a:	ba f4 5e             	mov    dx,0x5ef4
    5e6d:	52                   	push   dx
    5e6e:	50                   	push   ax
    5e6f:	9a 50 1f dc 5e       	call   0x5edc:0x1f50
    5e74:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5e77:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5e7a:	b8 56 5e             	mov    ax,0x5e56
    5e7d:	0e                   	push   cs
    5e7e:	50                   	push   ax
    5e7f:	55                   	push   bp
    5e80:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5e84:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5e88:	8b 46 16             	mov    ax,WORD PTR [bp+0x16]
    5e8b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5e8e:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    5e92:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    5e95:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5e98:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    5e9c:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    5e9f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5ea2:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    5ea6:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    5ea9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5eac:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    5eb0:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    5eb3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5eb6:	26 88 45 12          	mov    BYTE PTR es:[di+0x12],al
    5eba:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5ebd:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    5ec0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5ec3:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    5ec7:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    5ecb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5ecf:	83 c4 06             	add    sp,0x6
    5ed2:	eb 14                	jmp    0x5ee8
    5ed4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5ed7:	06                   	push   es
    5ed8:	57                   	push   di
    5ed9:	9a 7f 1f e1 5e       	call   0x5ee1:0x1f7f
    5ede:	ea 85 13 e6 5e       	jmp    0x5ee6:0x1385
    5ee3:	9a 34 14 a1 5f       	call   0x5fa1:0x1434
    5ee8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5eeb:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5eef:	06                   	push   es
    5ef0:	57                   	push   di
    5ef1:	9a 27 53 10 5f       	call   0x5f10:0x5327
    5ef6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5ef9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5efc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5eff:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    5f03:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    5f07:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    5f0b:	06                   	push   es
    5f0c:	57                   	push   di
    5f0d:	9a 19 53 42 5f       	call   0x5f42:0x5319
    5f12:	c9                   	leave
    5f13:	ca 12 00             	retf   0x12
    5f16:	c8 04 00 00          	enter  0x4,0x0
    5f1a:	8d 7e fc             	lea    di,[bp-0x4]
    5f1d:	16                   	push   ss
    5f1e:	57                   	push   di
    5f1f:	6a 00                	push   0x0
    5f21:	6a 04                	push   0x4
    5f23:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5f26:	06                   	push   es
    5f27:	57                   	push   di
    5f28:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f2b:	26 ff 1d             	call   DWORD PTR es:[di]
    5f2e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5f31:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5f34:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5f37:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5f3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f3d:	06                   	push   es
    5f3e:	57                   	push   di
    5f3f:	9a 62 5f 52 5f       	call   0x5f52:0x5f62
    5f44:	ff 76 08             	push   WORD PTR [bp+0x8]
    5f47:	ff 76 06             	push   WORD PTR [bp+0x6]
    5f4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f4d:	06                   	push   es
    5f4e:	57                   	push   di
    5f4f:	9a 9e 40 60 5f       	call   0x5f60:0x409e
    5f54:	c9                   	leave
    5f55:	ca 08 00             	retf   0x8
    5f58:	01 00                	add    WORD PTR [bx+si],ax
    5f5a:	00 00                	add    BYTE PTR [bx+si],al
    5f5c:	00 00                	add    BYTE PTR [bx+si],al
    5f5e:	e2 60                	loop   0x5fc0
    5f60:	6e                   	outs   dx,BYTE PTR ds:[si]
    5f61:	5f                   	pop    di
    5f62:	c8 4c 00 00          	enter  0x4c,0x0
    5f66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f69:	06                   	push   es
    5f6a:	57                   	push   di
    5f6b:	9a a5 5b 8e 5f       	call   0x5f8e:0x5ba5
    5f70:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    5f73:	0b 46 10             	or     ax,WORD PTR [bp+0x10]
    5f76:	75 1b                	jne    0x5f93
    5f78:	6a 00                	push   0x0
    5f7a:	6a 00                	push   0x0
    5f7c:	6a 00                	push   0x0
    5f7e:	6a 00                	push   0x0
    5f80:	6a 00                	push   0x0
    5f82:	6a 00                	push   0x0
    5f84:	6a 00                	push   0x0
    5f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f89:	06                   	push   es
    5f8a:	57                   	push   di
    5f8b:	9a 60 5e d7 60       	call   0x60d7:0x5e60
    5f90:	e9 63 01             	jmp    0x60f6
    5f93:	b0 01                	mov    al,0x1
    5f95:	50                   	push   ax
    5f96:	b8 24 05             	mov    ax,0x524
    5f99:	ba c5 5f             	mov    dx,0x5fc5
    5f9c:	52                   	push   dx
    5f9d:	50                   	push   ax
    5f9e:	9a 50 1f ea 60       	call   0x60ea:0x1f50
    5fa3:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    5fa6:	89 56 bc             	mov    WORD PTR [bp-0x44],dx
    5fa9:	b8 58 5f             	mov    ax,0x5f58
    5fac:	0e                   	push   cs
    5fad:	50                   	push   ax
    5fae:	55                   	push   bp
    5faf:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5fb3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5fb7:	ff 76 10             	push   WORD PTR [bp+0x10]
    5fba:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5fbd:	c4 7e ba             	les    di,DWORD PTR [bp-0x46]
    5fc0:	06                   	push   es
    5fc1:	57                   	push   di
    5fc2:	9a b5 2a de 5f       	call   0x5fde:0x2ab5
    5fc7:	c4 7e ba             	les    di,DWORD PTR [bp-0x46]
    5fca:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    5fce:	06                   	push   es
    5fcf:	57                   	push   di
    5fd0:	ff 76 10             	push   WORD PTR [bp+0x10]
    5fd3:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5fd6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5fd9:	06                   	push   es
    5fda:	57                   	push   di
    5fdb:	9a 11 24 b9 60       	call   0x60b9:0x2411
    5fe0:	8d 7e f2             	lea    di,[bp-0xe]
    5fe3:	16                   	push   ss
    5fe4:	57                   	push   di
    5fe5:	6a 00                	push   0x0
    5fe7:	6a 0e                	push   0xe
    5fe9:	c4 7e ba             	les    di,DWORD PTR [bp-0x46]
    5fec:	06                   	push   es
    5fed:	57                   	push   di
    5fee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ff1:	26 ff 1d             	call   DWORD PTR es:[di]
    5ff4:	81 7e f2 42 4d       	cmp    WORD PTR [bp-0xe],0x4d42
    5ff9:	74 03                	je     0x5ffe
    5ffb:	e8 65 c5             	call   0x2563
    5ffe:	8d 7e 0e             	lea    di,[bp+0xe]
    6001:	16                   	push   ss
    6002:	57                   	push   di
    6003:	6a 00                	push   0x0
    6005:	6a 04                	push   0x4
    6007:	c4 7e ba             	les    di,DWORD PTR [bp-0x46]
    600a:	06                   	push   es
    600b:	57                   	push   di
    600c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    600f:	26 ff 1d             	call   DWORD PTR es:[di]
    6012:	6a ff                	push   0xffff
    6014:	6a fc                	push   0xfffc
    6016:	6a 01                	push   0x1
    6018:	c4 7e ba             	les    di,DWORD PTR [bp-0x46]
    601b:	06                   	push   es
    601c:	57                   	push   di
    601d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6020:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    6024:	83 7e 10 00          	cmp    WORD PTR [bp+0x10],0x0
    6028:	75 3d                	jne    0x6067
    602a:	83 7e 0e 0c          	cmp    WORD PTR [bp+0xe],0xc
    602e:	75 37                	jne    0x6067
    6030:	8d 7e e6             	lea    di,[bp-0x1a]
    6033:	16                   	push   ss
    6034:	57                   	push   di
    6035:	6a 00                	push   0x0
    6037:	6a 0c                	push   0xc
    6039:	c4 7e ba             	les    di,DWORD PTR [bp-0x46]
    603c:	06                   	push   es
    603d:	57                   	push   di
    603e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6041:	26 ff 1d             	call   DWORD PTR es:[di]
    6044:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    6047:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    604a:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    604d:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    6050:	83 7e ee 01          	cmp    WORD PTR [bp-0x12],0x1
    6054:	75 06                	jne    0x605c
    6056:	83 7e f0 01          	cmp    WORD PTR [bp-0x10],0x1
    605a:	74 04                	je     0x6060
    605c:	b0 00                	mov    al,0x0
    605e:	eb 02                	jmp    0x6062
    6060:	b0 01                	mov    al,0x1
    6062:	88 46 b5             	mov    BYTE PTR [bp-0x4b],al
    6065:	eb 46                	jmp    0x60ad
    6067:	83 7e 10 00          	cmp    WORD PTR [bp+0x10],0x0
    606b:	75 3d                	jne    0x60aa
    606d:	83 7e 0e 28          	cmp    WORD PTR [bp+0xe],0x28
    6071:	75 37                	jne    0x60aa
    6073:	8d 7e be             	lea    di,[bp-0x42]
    6076:	16                   	push   ss
    6077:	57                   	push   di
    6078:	6a 00                	push   0x0
    607a:	6a 28                	push   0x28
    607c:	c4 7e ba             	les    di,DWORD PTR [bp-0x46]
    607f:	06                   	push   es
    6080:	57                   	push   di
    6081:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6084:	26 ff 1d             	call   DWORD PTR es:[di]
    6087:	8b 46 c6             	mov    ax,WORD PTR [bp-0x3a]
    608a:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    608d:	8b 46 c2             	mov    ax,WORD PTR [bp-0x3e]
    6090:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    6093:	83 7e ca 01          	cmp    WORD PTR [bp-0x36],0x1
    6097:	75 06                	jne    0x609f
    6099:	83 7e cc 01          	cmp    WORD PTR [bp-0x34],0x1
    609d:	74 04                	je     0x60a3
    609f:	b0 00                	mov    al,0x0
    60a1:	eb 02                	jmp    0x60a5
    60a3:	b0 01                	mov    al,0x1
    60a5:	88 46 b5             	mov    BYTE PTR [bp-0x4b],al
    60a8:	eb 03                	jmp    0x60ad
    60aa:	e8 b6 c4             	call   0x2563
    60ad:	6a 00                	push   0x0
    60af:	6a 00                	push   0x0
    60b1:	c4 7e ba             	les    di,DWORD PTR [bp-0x46]
    60b4:	06                   	push   es
    60b5:	57                   	push   di
    60b6:	9a a4 23 f2 62       	call   0x62f2:0x23a4
    60bb:	6a 00                	push   0x0
    60bd:	6a 00                	push   0x0
    60bf:	ff 76 b8             	push   WORD PTR [bp-0x48]
    60c2:	ff 76 b6             	push   WORD PTR [bp-0x4a]
    60c5:	8a 46 b5             	mov    al,BYTE PTR [bp-0x4b]
    60c8:	50                   	push   ax
    60c9:	ff 76 bc             	push   WORD PTR [bp-0x44]
    60cc:	ff 76 ba             	push   WORD PTR [bp-0x46]
    60cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60d2:	06                   	push   es
    60d3:	57                   	push   di
    60d4:	9a 60 5e 02 61       	call   0x6102:0x5e60
    60d9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    60dd:	83 c4 06             	add    sp,0x6
    60e0:	eb 14                	jmp    0x60f6
    60e2:	c4 7e ba             	les    di,DWORD PTR [bp-0x46]
    60e5:	06                   	push   es
    60e6:	57                   	push   di
    60e7:	9a 7f 1f ef 60       	call   0x60ef:0x1f7f
    60ec:	ea 85 13 f4 60       	jmp    0x60f4:0x1385
    60f1:	9a 34 14 4e 61       	call   0x614e:0x1434
    60f6:	c9                   	leave
    60f7:	ca 0c 00             	retf   0xc
    60fa:	01 00                	add    WORD PTR [bx+si],ax
    60fc:	00 00                	add    BYTE PTR [bx+si],al
    60fe:	00 00                	add    BYTE PTR [bx+si],al
    6100:	ba 61 29             	mov    dx,0x2961
    6103:	61                   	popa
    6104:	c8 14 00 00          	enter  0x14,0x0
    6108:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    610b:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    610f:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    6112:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    6115:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    6119:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    611c:	75 03                	jne    0x6121
    611e:	e9 bb 00             	jmp    0x61dc
    6121:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6124:	06                   	push   es
    6125:	57                   	push   di
    6126:	9a a5 5b af 61       	call   0x61af:0x5ba5
    612b:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    612f:	74 11                	je     0x6142
    6131:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6134:	6a 0e                	push   0xe
    6136:	8d 7e f2             	lea    di,[bp-0xe]
    6139:	16                   	push   ss
    613a:	57                   	push   di
    613b:	9a ff ff 00 00       	call   0x0:0xffff
    6140:	eb 0e                	jmp    0x6150
    6142:	8d 7e f2             	lea    di,[bp-0xe]
    6145:	16                   	push   ss
    6146:	57                   	push   di
    6147:	6a 0e                	push   0xe
    6149:	6a 00                	push   0x0
    614b:	9a e5 1e c5 61       	call   0x61c5:0x1ee5
    6150:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    6153:	26 83 7d 04 01       	cmp    WORD PTR es:[di+0x4],0x1
    6158:	75 0f                	jne    0x6169
    615a:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    615e:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    6161:	31 c0                	xor    ax,ax
    6163:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    6167:	eb 0d                	jmp    0x6176
    6169:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    616c:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    6170:	e8 af f4             	call   0x5622
    6173:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    6176:	b8 fa 60             	mov    ax,0x60fa
    6179:	0e                   	push   cs
    617a:	50                   	push   ax
    617b:	55                   	push   bp
    617c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6180:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6184:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6187:	ff 76 f0             	push   WORD PTR [bp-0x10]
    618a:	ff 76 f4             	push   WORD PTR [bp-0xc]
    618d:	ff 76 f6             	push   WORD PTR [bp-0xa]
    6190:	80 7e fa 01          	cmp    BYTE PTR [bp-0x6],0x1
    6194:	75 06                	jne    0x619c
    6196:	80 7e fb 01          	cmp    BYTE PTR [bp-0x5],0x1
    619a:	74 04                	je     0x61a0
    619c:	b0 00                	mov    al,0x0
    619e:	eb 02                	jmp    0x61a2
    61a0:	b0 01                	mov    al,0x1
    61a2:	50                   	push   ax
    61a3:	6a 00                	push   0x0
    61a5:	6a 00                	push   0x0
    61a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61aa:	06                   	push   es
    61ab:	57                   	push   di
    61ac:	9a 60 5e da 61       	call   0x61da:0x5e60
    61b1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    61b5:	83 c4 06             	add    sp,0x6
    61b8:	eb 12                	jmp    0x61cc
    61ba:	ff 76 f0             	push   WORD PTR [bp-0x10]
    61bd:	9a d9 63 00 00       	call   0x0:0x63d9
    61c2:	ea 85 13 ca 61       	jmp    0x61ca:0x1385
    61c7:	9a 34 14 e0 63       	call   0x63e0:0x1434
    61cc:	ff 76 08             	push   WORD PTR [bp+0x8]
    61cf:	ff 76 06             	push   WORD PTR [bp+0x6]
    61d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61d5:	06                   	push   es
    61d6:	57                   	push   di
    61d7:	9a 9e 40 10 62       	call   0x6210:0x409e
    61dc:	c9                   	leave
    61dd:	ca 06 00             	retf   0x6
    61e0:	c8 04 00 00          	enter  0x4,0x0
    61e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61e7:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    61eb:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    61ef:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    61f2:	74 2e                	je     0x6222
    61f4:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    61f8:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    61fc:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    6200:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6203:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    6207:	50                   	push   ax
    6208:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    620b:	06                   	push   es
    620c:	57                   	push   di
    620d:	9a 03 58 20 62       	call   0x6220:0x5803
    6212:	ff 76 08             	push   WORD PTR [bp+0x8]
    6215:	ff 76 06             	push   WORD PTR [bp+0x6]
    6218:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    621b:	06                   	push   es
    621c:	57                   	push   di
    621d:	9a 9e 40 56 62       	call   0x6256:0x409e
    6222:	c9                   	leave
    6223:	ca 06 00             	retf   0x6
    6226:	c8 04 00 00          	enter  0x4,0x0
    622a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    622d:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6231:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6234:	26 3a 45 12          	cmp    al,BYTE PTR es:[di+0x12]
    6238:	74 2e                	je     0x6268
    623a:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    623e:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    6242:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    6246:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    624a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    624d:	50                   	push   ax
    624e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6251:	06                   	push   es
    6252:	57                   	push   di
    6253:	9a 03 58 66 62       	call   0x6266:0x5803
    6258:	ff 76 08             	push   WORD PTR [bp+0x8]
    625b:	ff 76 06             	push   WORD PTR [bp+0x6]
    625e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6261:	06                   	push   es
    6262:	57                   	push   di
    6263:	9a 9e 40 9c 62       	call   0x629c:0x409e
    6268:	c9                   	leave
    6269:	ca 06 00             	retf   0x6
    626c:	c8 04 00 00          	enter  0x4,0x0
    6270:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6273:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6277:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    627b:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    627e:	74 2e                	je     0x62ae
    6280:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    6284:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    6288:	ff 76 0a             	push   WORD PTR [bp+0xa]
    628b:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    628f:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    6293:	50                   	push   ax
    6294:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6297:	06                   	push   es
    6298:	57                   	push   di
    6299:	9a 03 58 ac 62       	call   0x62ac:0x5803
    629e:	ff 76 08             	push   WORD PTR [bp+0x8]
    62a1:	ff 76 06             	push   WORD PTR [bp+0x6]
    62a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62a7:	06                   	push   es
    62a8:	57                   	push   di
    62a9:	9a 9e 40 c5 62       	call   0x62c5:0x409e
    62ae:	c9                   	leave
    62af:	ca 06 00             	retf   0x6
    62b2:	55                   	push   bp
    62b3:	89 e5                	mov    bp,sp
    62b5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    62b8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    62bb:	6a 01                	push   0x1
    62bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62c0:	06                   	push   es
    62c1:	57                   	push   di
    62c2:	9a cb 62 e4 62       	call   0x62e4:0x62cb
    62c7:	c9                   	leave
    62c8:	ca 08 00             	retf   0x8
    62cb:	c8 08 00 00          	enter  0x8,0x0
    62cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62d2:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    62d6:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    62d9:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    62dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62df:	06                   	push   es
    62e0:	57                   	push   di
    62e1:	9a 6a 5c 4f 63       	call   0x634f:0x5c6a
    62e6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    62e9:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    62ed:	06                   	push   es
    62ee:	57                   	push   di
    62ef:	9a bf 23 11 63       	call   0x6311:0x23bf
    62f4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    62f7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    62fa:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    62fe:	74 13                	je     0x6313
    6300:	8d 7e fc             	lea    di,[bp-0x4]
    6303:	16                   	push   ss
    6304:	57                   	push   di
    6305:	6a 00                	push   0x0
    6307:	6a 04                	push   0x4
    6309:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    630c:	06                   	push   es
    630d:	57                   	push   di
    630e:	9a 66 24 36 63       	call   0x6336:0x2466
    6313:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6316:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    6319:	74 1d                	je     0x6338
    631b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    631e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    6322:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    6326:	06                   	push   es
    6327:	57                   	push   di
    6328:	ff 76 fe             	push   WORD PTR [bp-0x2]
    632b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    632e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    6331:	06                   	push   es
    6332:	57                   	push   di
    6333:	9a 66 24 1a 66       	call   0x661a:0x2466
    6338:	c9                   	leave
    6339:	ca 0a 00             	retf   0xa
    633c:	55                   	push   bp
    633d:	89 e5                	mov    bp,sp
    633f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6342:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6345:	6a 00                	push   0x0
    6347:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    634a:	06                   	push   es
    634b:	57                   	push   di
    634c:	9a cb 62 5d 63       	call   0x635d:0x62cb
    6351:	c9                   	leave
    6352:	ca 08 00             	retf   0x8
    6355:	01 00                	add    WORD PTR [bx+si],ax
    6357:	00 00                	add    BYTE PTR [bx+si],al
    6359:	00 00                	add    BYTE PTR [bx+si],al
    635b:	d5 63                	aad    0x63
    635d:	2a 64 c8             	sub    ah,BYTE PTR [si-0x38]
    6360:	06                   	push   es
    6361:	00 00                	add    BYTE PTR [bx+si],al
    6363:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    6366:	26 c7 05 02 00       	mov    WORD PTR es:[di],0x2
    636b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    636e:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6372:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    6375:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    6378:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    637c:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    6380:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    6384:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    6388:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    638b:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    638f:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    6393:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    6396:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    639a:	50                   	push   ax
    639b:	e8 22 f0             	call   0x53c0
    639e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    63a1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    63a4:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    63a7:	26 89 05             	mov    WORD PTR es:[di],ax
    63aa:	b8 55 63             	mov    ax,0x6355
    63ad:	0e                   	push   cs
    63ae:	50                   	push   ax
    63af:	55                   	push   bp
    63b0:	ff 36 58 18          	push   WORD PTR ds:0x1858
    63b4:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    63b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63bb:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    63bf:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    63c3:	e8 5c f2             	call   0x5622
    63c6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    63c9:	26 89 05             	mov    WORD PTR es:[di],ax
    63cc:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    63d0:	83 c4 06             	add    sp,0x6
    63d3:	eb 12                	jmp    0x63e7
    63d5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    63d8:	9a ff ff 00 00       	call   0x0:0xffff
    63dd:	ea 85 13 e5 63       	jmp    0x63e5:0x1385
    63e2:	9a 34 14 1d 64       	call   0x641d:0x1434
    63e7:	c9                   	leave
    63e8:	ca 10 00             	retf   0x10
    63eb:	55                   	push   bp
    63ec:	89 e5                	mov    bp,sp
    63ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63f1:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    63f6:	74 09                	je     0x6401
    63f8:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    63fc:	9a ff ff 00 00       	call   0x0:0xffff
    6401:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6404:	31 c0                	xor    ax,ax
    6406:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    640a:	c9                   	leave
    640b:	ca 04 00             	retf   0x4
    640e:	55                   	push   bp
    640f:	89 e5                	mov    bp,sp
    6411:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6415:	74 08                	je     0x641f
    6417:	83 ec 08             	sub    sp,0x8
    641a:	9a e2 1f 3a 64       	call   0x643a:0x1fe2
    641f:	31 c0                	xor    ax,ax
    6421:	50                   	push   ax
    6422:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6425:	06                   	push   es
    6426:	57                   	push   di
    6427:	9a 02 40 33 64       	call   0x6433:0x4002
    642c:	b0 01                	mov    al,0x1
    642e:	50                   	push   ax
    642f:	b8 cd 08             	mov    ax,0x8cd
    6432:	ba 50 64             	mov    dx,0x6450
    6435:	52                   	push   dx
    6436:	50                   	push   ax
    6437:	9a 50 1f 85 64       	call   0x6485:0x1f50
    643c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    643f:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    6443:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    6447:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    644b:	06                   	push   es
    644c:	57                   	push   di
    644d:	9a 19 53 78 64       	call   0x6478:0x5319
    6452:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6456:	74 07                	je     0x645f
    6458:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    645c:	83 c4 06             	add    sp,0x6
    645f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6462:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6465:	c9                   	leave
    6466:	ca 06 00             	retf   0x6
    6469:	55                   	push   bp
    646a:	89 e5                	mov    bp,sp
    646c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    646f:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6473:	06                   	push   es
    6474:	57                   	push   di
    6475:	9a 27 53 ab 64       	call   0x64ab:0x5327
    647a:	31 c0                	xor    ax,ax
    647c:	50                   	push   ax
    647d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6480:	06                   	push   es
    6481:	57                   	push   di
    6482:	9a 66 1f 90 64       	call   0x6490:0x1f66
    6487:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    648b:	74 05                	je     0x6492
    648d:	9a 0f 20 b2 64       	call   0x64b2:0x200f
    6492:	c9                   	leave
    6493:	ca 06 00             	retf   0x6
    6496:	55                   	push   bp
    6497:	89 e5                	mov    bp,sp
    6499:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    649c:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    649f:	74 17                	je     0x64b8
    64a1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    64a4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    64a7:	bf fc 08             	mov    di,0x8fc
    64aa:	b8 cc 64             	mov    ax,0x64cc
    64ad:	50                   	push   ax
    64ae:	57                   	push   di
    64af:	9a 55 22 b6 66       	call   0x66b6:0x2255
    64b4:	08 c0                	or     al,al
    64b6:	74 5e                	je     0x6516
    64b8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    64bb:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    64be:	74 34                	je     0x64f4
    64c0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    64c3:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    64c7:	06                   	push   es
    64c8:	57                   	push   di
    64c9:	9a 19 53 da 64       	call   0x64da:0x5319
    64ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64d1:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    64d5:	06                   	push   es
    64d6:	57                   	push   di
    64d7:	9a 27 53 02 65       	call   0x6502:0x5327
    64dc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    64df:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    64e3:	26 8b 55 10          	mov    dx,WORD PTR es:[di+0x10]
    64e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64ea:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    64ee:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    64f2:	eb 10                	jmp    0x6504
    64f4:	6a 00                	push   0x0
    64f6:	6a 00                	push   0x0
    64f8:	6a 00                	push   0x0
    64fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64fd:	06                   	push   es
    64fe:	57                   	push   di
    64ff:	9a 2a 68 12 65       	call   0x6512:0x682a
    6504:	ff 76 08             	push   WORD PTR [bp+0x8]
    6507:	ff 76 06             	push   WORD PTR [bp+0x6]
    650a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    650d:	06                   	push   es
    650e:	57                   	push   di
    650f:	9a 9e 40 24 65       	call   0x6524:0x409e
    6514:	eb 10                	jmp    0x6526
    6516:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6519:	ff 76 0a             	push   WORD PTR [bp+0xa]
    651c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    651f:	06                   	push   es
    6520:	57                   	push   di
    6521:	9a 37 40 41 65       	call   0x6541:0x4037
    6526:	c9                   	leave
    6527:	ca 08 00             	retf   0x8
    652a:	c8 04 00 00          	enter  0x4,0x0
    652e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6531:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6534:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6537:	6a 01                	push   0x1
    6539:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    653c:	06                   	push   es
    653d:	57                   	push   di
    653e:	9a c2 22 5c 65       	call   0x655c:0x22c2
    6543:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6546:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    654a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    654d:	26 ff 35             	push   WORD PTR es:[di]
    6550:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    6554:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6557:	06                   	push   es
    6558:	57                   	push   di
    6559:	9a 94 65 a0 65       	call   0x65a0:0x6594
    655e:	50                   	push   ax
    655f:	9a ff ff 00 00       	call   0x0:0xffff
    6564:	c9                   	leave
    6565:	ca 0c 00             	retf   0xc
    6568:	c8 06 00 00          	enter  0x6,0x0
    656c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    656f:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6573:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    6578:	75 0a                	jne    0x6584
    657a:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    657e:	26 0b 45 08          	or     ax,WORD PTR es:[di+0x8]
    6582:	74 04                	je     0x6588
    6584:	b0 00                	mov    al,0x0
    6586:	eb 02                	jmp    0x658a
    6588:	b0 01                	mov    al,0x1
    658a:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    658d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6590:	c9                   	leave
    6591:	ca 04 00             	retf   0x4
    6594:	c8 02 00 00          	enter  0x2,0x0
    6598:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    659b:	06                   	push   es
    659c:	57                   	push   di
    659d:	9a e1 65 7b 66       	call   0x667b:0x65e1
    65a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65a5:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    65a9:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    65ad:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    65b0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    65b3:	c9                   	leave
    65b4:	ca 04 00             	retf   0x4
    65b7:	c8 02 00 00          	enter  0x2,0x0
    65bb:	6a 0c                	push   0xc
    65bd:	9a d3 65 00 00       	call   0x0:0x65d3
    65c2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    65c5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    65c8:	c9                   	leave
    65c9:	ca 04 00             	retf   0x4
    65cc:	c8 02 00 00          	enter  0x2,0x0
    65d0:	6a 0b                	push   0xb
    65d2:	9a ff ff 00 00       	call   0x0:0xffff
    65d7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    65da:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    65dd:	c9                   	leave
    65de:	ca 04 00             	retf   0x4
    65e1:	c8 0c 00 00          	enter  0xc,0x0
    65e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65e8:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    65ec:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    65ef:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    65f2:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    65f7:	74 02                	je     0x65fb
    65f9:	eb 74                	jmp    0x666f
    65fb:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    65fe:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    6602:	26 0b 45 08          	or     ax,WORD PTR es:[di+0x8]
    6606:	75 02                	jne    0x660a
    6608:	eb 65                	jmp    0x666f
    660a:	6a 00                	push   0x0
    660c:	6a 00                	push   0x0
    660e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    6611:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    6615:	06                   	push   es
    6616:	57                   	push   di
    6617:	9a a4 23 31 66       	call   0x6631:0x23a4
    661c:	8d 7e fa             	lea    di,[bp-0x6]
    661f:	16                   	push   ss
    6620:	57                   	push   di
    6621:	6a 00                	push   0x0
    6623:	6a 06                	push   0x6
    6625:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    6628:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    662c:	06                   	push   es
    662d:	57                   	push   di
    662e:	9a 11 24 af 66       	call   0x66af:0x2411
    6633:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6636:	3d 00 00             	cmp    ax,0x0
    6639:	75 08                	jne    0x6643
    663b:	a1 1e 2b             	mov    ax,ds:0x2b1e
    663e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6641:	eb 22                	jmp    0x6665
    6643:	3d 01 00             	cmp    ax,0x1
    6646:	75 1a                	jne    0x6662
    6648:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    664b:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    664f:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    6653:	8d 7e f8             	lea    di,[bp-0x8]
    6656:	16                   	push   ss
    6657:	57                   	push   di
    6658:	ff 76 fe             	push   WORD PTR [bp-0x2]
    665b:	6a 06                	push   0x6
    665d:	e8 92 cb             	call   0x31f2
    6660:	eb 03                	jmp    0x6665
    6662:	e8 09 bf             	call   0x256e
    6665:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    6668:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    666b:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    666f:	c9                   	leave
    6670:	ca 04 00             	retf   0x4
    6673:	01 00                	add    WORD PTR [bx+si],ax
    6675:	00 00                	add    BYTE PTR [bx+si],al
    6677:	00 00                	add    BYTE PTR [bx+si],al
    6679:	1e                   	push   ds
    667a:	67 d4 66             	addr32 aam 0x66
    667d:	c8 0e 00 00          	enter  0xe,0x0
    6681:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6684:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6688:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    668b:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    668e:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    6692:	26 0b 45 08          	or     ax,WORD PTR es:[di+0x8]
    6696:	74 03                	je     0x669b
    6698:	e9 a8 00             	jmp    0x6743
    669b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    669e:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    66a3:	75 03                	jne    0x66a8
    66a5:	e8 c6 be             	call   0x256e
    66a8:	b0 01                	mov    al,0x1
    66aa:	50                   	push   ax
    66ab:	b8 24 05             	mov    ax,0x524
    66ae:	ba fb 66             	mov    dx,0x66fb
    66b1:	52                   	push   dx
    66b2:	50                   	push   ax
    66b3:	9a 50 1f e8 66       	call   0x66e8:0x1f50
    66b8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    66bb:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    66be:	b8 73 66             	mov    ax,0x6673
    66c1:	0e                   	push   cs
    66c2:	50                   	push   ax
    66c3:	55                   	push   bp
    66c4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    66c8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    66cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66cf:	06                   	push   es
    66d0:	57                   	push   di
    66d1:	9a 94 65 0d 67       	call   0x670d:0x6594
    66d6:	3b 06 1e 2b          	cmp    ax,WORD PTR ds:0x2b1e
    66da:	75 23                	jne    0x66ff
    66dc:	8d 7e f6             	lea    di,[bp-0xa]
    66df:	16                   	push   ss
    66e0:	57                   	push   di
    66e1:	6a 06                	push   0x6
    66e3:	6a 00                	push   0x0
    66e5:	9a e5 1e 26 67       	call   0x6726:0x1ee5
    66ea:	8d 7e f6             	lea    di,[bp-0xa]
    66ed:	16                   	push   ss
    66ee:	57                   	push   di
    66ef:	6a 00                	push   0x0
    66f1:	6a 06                	push   0x6
    66f3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    66f6:	06                   	push   es
    66f7:	57                   	push   di
    66f8:	9a 66 24 5c 67       	call   0x675c:0x2466
    66fd:	eb 16                	jmp    0x6715
    66ff:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6702:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6705:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6708:	06                   	push   es
    6709:	57                   	push   di
    670a:	9a 94 65 4f 67       	call   0x674f:0x6594
    670f:	50                   	push   ax
    6710:	6a 00                	push   0x0
    6712:	e8 77 d3             	call   0x3a8c
    6715:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6719:	83 c4 06             	add    sp,0x6
    671c:	eb 14                	jmp    0x6732
    671e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6721:	06                   	push   es
    6722:	57                   	push   di
    6723:	9a 7f 1f 2b 67       	call   0x672b:0x1f7f
    6728:	ea 85 13 30 67       	jmp    0x6730:0x1385
    672d:	9a 34 14 63 67       	call   0x6763:0x1434
    6732:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6735:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6738:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    673b:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    673f:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    6743:	c9                   	leave
    6744:	ca 04 00             	retf   0x4
    6747:	01 00                	add    WORD PTR [bx+si],ax
    6749:	00 00                	add    BYTE PTR [bx+si],al
    674b:	00 00                	add    BYTE PTR [bx+si],al
    674d:	f8                   	clc
    674e:	67 ed                	addr32 in ax,dx
    6750:	67 c8 0a 00 00       	addr32 enter 0xa,0x0
    6755:	b0 01                	mov    al,0x1
    6757:	50                   	push   ax
    6758:	b8 24 05             	mov    ax,0x524
    675b:	ba 81 67             	mov    dx,0x6781
    675e:	52                   	push   dx
    675f:	50                   	push   ax
    6760:	9a 50 1f 00 68       	call   0x6800:0x1f50
    6765:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6768:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    676b:	b8 47 67             	mov    ax,0x6747
    676e:	0e                   	push   cs
    676f:	50                   	push   ax
    6770:	55                   	push   bp
    6771:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6775:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6779:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    677c:	06                   	push   es
    677d:	57                   	push   di
    677e:	9a 7e 23 8d 67       	call   0x678d:0x237e
    6783:	52                   	push   dx
    6784:	50                   	push   ax
    6785:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6788:	06                   	push   es
    6789:	57                   	push   di
    678a:	9a bf 23 9f 67       	call   0x679f:0x23bf
    678f:	59                   	pop    cx
    6790:	5b                   	pop    bx
    6791:	2b c1                	sub    ax,cx
    6793:	1b d3                	sbb    dx,bx
    6795:	52                   	push   dx
    6796:	50                   	push   ax
    6797:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    679a:	06                   	push   es
    679b:	57                   	push   di
    679c:	9a b5 2a b2 67       	call   0x67b2:0x2ab5
    67a1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    67a4:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    67a8:	06                   	push   es
    67a9:	57                   	push   di
    67aa:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    67ad:	06                   	push   es
    67ae:	57                   	push   di
    67af:	9a bf 23 be 67       	call   0x67be:0x23bf
    67b4:	52                   	push   dx
    67b5:	50                   	push   ax
    67b6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    67b9:	06                   	push   es
    67ba:	57                   	push   di
    67bb:	9a 11 24 d1 67       	call   0x67d1:0x2411
    67c0:	8d 7e f6             	lea    di,[bp-0xa]
    67c3:	16                   	push   ss
    67c4:	57                   	push   di
    67c5:	6a 00                	push   0x0
    67c7:	6a 06                	push   0x6
    67c9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    67cc:	06                   	push   es
    67cd:	57                   	push   di
    67ce:	9a 11 24 26 69       	call   0x6926:0x2411
    67d3:	8a 46 f8             	mov    al,BYTE PTR [bp-0x8]
    67d6:	3c 01                	cmp    al,0x1
    67d8:	76 03                	jbe    0x67dd
    67da:	e8 91 bd             	call   0x256e
    67dd:	6a 00                	push   0x0
    67df:	ff 76 fe             	push   WORD PTR [bp-0x2]
    67e2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    67e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67e8:	06                   	push   es
    67e9:	57                   	push   di
    67ea:	9a 2a 68 1a 68       	call   0x681a:0x682a
    67ef:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    67f3:	83 c4 06             	add    sp,0x6
    67f6:	eb 14                	jmp    0x680c
    67f8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    67fb:	06                   	push   es
    67fc:	57                   	push   di
    67fd:	9a 7f 1f 05 68       	call   0x6805:0x1f7f
    6802:	ea 85 13 0a 68       	jmp    0x680a:0x1385
    6807:	9a 34 14 3c 68       	call   0x683c:0x1434
    680c:	ff 76 08             	push   WORD PTR [bp+0x8]
    680f:	ff 76 06             	push   WORD PTR [bp+0x6]
    6812:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6815:	06                   	push   es
    6816:	57                   	push   di
    6817:	9a 9e 40 28 68       	call   0x6828:0x409e
    681c:	c9                   	leave
    681d:	ca 08 00             	retf   0x8
    6820:	01 00                	add    WORD PTR [bx+si],ax
    6822:	00 00                	add    BYTE PTR [bx+si],al
    6824:	00 00                	add    BYTE PTR [bx+si],al
    6826:	76 68                	jbe    0x6890
    6828:	35 68 c8             	xor    ax,0xc868
    682b:	04 00                	add    al,0x0
    682d:	00 b0 01 50          	add    BYTE PTR [bx+si+0x5001],dh
    6831:	b8 cd 08             	mov    ax,0x8cd
    6834:	ba 92 68             	mov    dx,0x6892
    6837:	52                   	push   dx
    6838:	50                   	push   ax
    6839:	9a 50 1f 7e 68       	call   0x687e:0x1f50
    683e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6841:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6844:	b8 20 68             	mov    ax,0x6820
    6847:	0e                   	push   cs
    6848:	50                   	push   ax
    6849:	55                   	push   bp
    684a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    684e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6852:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    6855:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6858:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    685c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    685f:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6862:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6865:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    6869:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    686d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6871:	83 c4 06             	add    sp,0x6
    6874:	eb 14                	jmp    0x688a
    6876:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6879:	06                   	push   es
    687a:	57                   	push   di
    687b:	9a 7f 1f 83 68       	call   0x6883:0x1f7f
    6880:	ea 85 13 88 68       	jmp    0x6888:0x1385
    6885:	9a 34 14 54 69       	call   0x6954:0x1434
    688a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    688d:	06                   	push   es
    688e:	57                   	push   di
    688f:	9a 19 53 a0 68       	call   0x68a0:0x5319
    6894:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6897:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    689b:	06                   	push   es
    689c:	57                   	push   di
    689d:	9a 27 53 c9 68       	call   0x68c9:0x5327
    68a2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    68a5:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    68a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68ab:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    68af:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    68b3:	c9                   	leave
    68b4:	ca 0a 00             	retf   0xa
    68b7:	55                   	push   bp
    68b8:	89 e5                	mov    bp,sp
    68ba:	ff 76 0a             	push   WORD PTR [bp+0xa]
    68bd:	6a 00                	push   0x0
    68bf:	6a 00                	push   0x0
    68c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68c4:	06                   	push   es
    68c5:	57                   	push   di
    68c6:	9a 2a 68 d9 68       	call   0x68d9:0x682a
    68cb:	ff 76 08             	push   WORD PTR [bp+0x8]
    68ce:	ff 76 06             	push   WORD PTR [bp+0x6]
    68d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68d4:	06                   	push   es
    68d5:	57                   	push   di
    68d6:	9a 9e 40 05 69       	call   0x6905:0x409e
    68db:	c9                   	leave
    68dc:	ca 06 00             	retf   0x6
    68df:	55                   	push   bp
    68e0:	89 e5                	mov    bp,sp
    68e2:	68 1d f0             	push   0xf01d
    68e5:	e8 21 bc             	call   0x2509
    68e8:	c9                   	leave
    68e9:	ca 06 00             	retf   0x6
    68ec:	55                   	push   bp
    68ed:	89 e5                	mov    bp,sp
    68ef:	68 1d f0             	push   0xf01d
    68f2:	e8 14 bc             	call   0x2509
    68f5:	c9                   	leave
    68f6:	ca 06 00             	retf   0x6
    68f9:	c8 04 00 00          	enter  0x4,0x0
    68fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6900:	06                   	push   es
    6901:	57                   	push   di
    6902:	9a 7d 66 7c 69       	call   0x697c:0x667d
    6907:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    690a:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    690e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    6912:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6915:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6918:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    691c:	06                   	push   es
    691d:	57                   	push   di
    691e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6921:	06                   	push   es
    6922:	57                   	push   di
    6923:	9a bf 23 32 69       	call   0x6932:0x23bf
    6928:	52                   	push   dx
    6929:	50                   	push   ax
    692a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    692d:	06                   	push   es
    692e:	57                   	push   di
    692f:	9a 66 24 c2 69       	call   0x69c2:0x2466
    6934:	c9                   	leave
    6935:	ca 08 00             	retf   0x8
    6938:	55                   	push   bp
    6939:	89 e5                	mov    bp,sp
    693b:	68 a8 f0             	push   0xf0a8
    693e:	e8 c8 bb             	call   0x2509
    6941:	c9                   	leave
    6942:	ca 10 00             	retf   0x10
    6945:	55                   	push   bp
    6946:	89 e5                	mov    bp,sp
    6948:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    694c:	74 08                	je     0x6956
    694e:	83 ec 08             	sub    sp,0x8
    6951:	9a e2 1f 61 69       	call   0x6961:0x1fe2
    6956:	31 c0                	xor    ax,ax
    6958:	50                   	push   ax
    6959:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    695c:	06                   	push   es
    695d:	57                   	push   di
    695e:	9a 50 1f c9 69       	call   0x69c9:0x1f50
    6963:	83 7e 0c 01          	cmp    WORD PTR [bp+0xc],0x1
    6967:	7c 06                	jl     0x696f
    6969:	83 7e 0e 01          	cmp    WORD PTR [bp+0xe],0x1
    696d:	7d 06                	jge    0x6975
    696f:	68 22 f0             	push   0xf022
    6972:	e8 94 bb             	call   0x2509
    6975:	b0 01                	mov    al,0x1
    6977:	50                   	push   ax
    6978:	b8 3f 08             	mov    ax,0x83f
    697b:	ba 83 69             	mov    dx,0x6983
    697e:	52                   	push   dx
    697f:	50                   	push   ax
    6980:	9a bd 56 a7 69       	call   0x69a7:0x56bd
    6985:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6988:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    698c:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    6990:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6993:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6997:	06                   	push   es
    6998:	57                   	push   di
    6999:	26 c4 3d             	les    di,DWORD PTR es:[di]
    699c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    69a0:	b0 01                	mov    al,0x1
    69a2:	50                   	push   ax
    69a3:	b8 3f 08             	mov    ax,0x83f
    69a6:	ba ae 69             	mov    dx,0x69ae
    69a9:	52                   	push   dx
    69aa:	50                   	push   ax
    69ab:	9a bd 56 64 6b       	call   0x6b64:0x56bd
    69b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69b3:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    69b7:	26 89 55 14          	mov    WORD PTR es:[di+0x14],dx
    69bb:	b0 01                	mov    al,0x1
    69bd:	50                   	push   ax
    69be:	b8 a3 02             	mov    ax,0x2a3
    69c1:	ba 01 6b             	mov    dx,0x6b01
    69c4:	52                   	push   dx
    69c5:	50                   	push   ax
    69c6:	9a 50 1f 10 6a       	call   0x6a10:0x1f50
    69cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69ce:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    69d2:	26 89 55 18          	mov    WORD PTR es:[di+0x18],dx
    69d6:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    69d9:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    69dd:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    69e0:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    69e4:	26 c7 45 0c 04 00    	mov    WORD PTR es:[di+0xc],0x4
    69ea:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    69ee:	74 07                	je     0x69f7
    69f0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    69f4:	83 c4 06             	add    sp,0x6
    69f7:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    69fa:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    69fd:	c9                   	leave
    69fe:	ca 0a 00             	retf   0xa
    6a01:	55                   	push   bp
    6a02:	89 e5                	mov    bp,sp
    6a04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a07:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6a0b:	06                   	push   es
    6a0c:	57                   	push   di
    6a0d:	9a 7f 1f 1e 6a       	call   0x6a1e:0x1f7f
    6a12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a15:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    6a19:	06                   	push   es
    6a1a:	57                   	push   di
    6a1b:	9a 7f 1f 2c 6a       	call   0x6a2c:0x1f7f
    6a20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a23:	26 c4 7d 16          	les    di,DWORD PTR es:[di+0x16]
    6a27:	06                   	push   es
    6a28:	57                   	push   di
    6a29:	9a 7f 1f 39 6a       	call   0x6a39:0x1f7f
    6a2e:	31 c0                	xor    ax,ax
    6a30:	50                   	push   ax
    6a31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a34:	06                   	push   es
    6a35:	57                   	push   di
    6a36:	9a 66 1f 44 6a       	call   0x6a44:0x1f66
    6a3b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6a3f:	74 05                	je     0x6a46
    6a41:	9a 0f 20 98 6a       	call   0x6a98:0x200f
    6a46:	c9                   	leave
    6a47:	ca 06 00             	retf   0x6
    6a4a:	c8 08 00 00          	enter  0x8,0x0
    6a4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a51:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    6a55:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6a58:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    6a5c:	99                   	cwd
    6a5d:	26 01 45 08          	add    WORD PTR es:[di+0x8],ax
    6a61:	26 11 55 0a          	adc    WORD PTR es:[di+0xa],dx
    6a65:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6a69:	06                   	push   es
    6a6a:	57                   	push   di
    6a6b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a6e:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    6a72:	99                   	cwd
    6a73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a76:	26 3b 55 0a          	cmp    dx,WORD PTR es:[di+0xa]
    6a7a:	7c 08                	jl     0x6a84
    6a7c:	7f 63                	jg     0x6ae1
    6a7e:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    6a82:	73 5d                	jae    0x6ae1
    6a84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a87:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    6a8b:	99                   	cwd
    6a8c:	8b c8                	mov    cx,ax
    6a8e:	8b da                	mov    bx,dx
    6a90:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    6a94:	99                   	cwd
    6a95:	9a 33 16 28 6e       	call   0x6e28:0x1633
    6a9a:	52                   	push   dx
    6a9b:	50                   	push   ax
    6a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a9f:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6aa3:	06                   	push   es
    6aa4:	57                   	push   di
    6aa5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6aa8:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    6aac:	99                   	cwd
    6aad:	59                   	pop    cx
    6aae:	5b                   	pop    bx
    6aaf:	03 c1                	add    ax,cx
    6ab1:	13 d3                	adc    dx,bx
    6ab3:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6ab6:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    6ab9:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    6abd:	7f 09                	jg     0x6ac8
    6abf:	7c 0d                	jl     0x6ace
    6ac1:	81 7e fa 00 80       	cmp    WORD PTR [bp-0x6],0x8000
    6ac6:	76 06                	jbe    0x6ace
    6ac8:	68 23 f0             	push   0xf023
    6acb:	e8 3b ba             	call   0x2509
    6ace:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6ad1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ad4:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6ad8:	06                   	push   es
    6ad9:	57                   	push   di
    6ada:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6add:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    6ae1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ae4:	26 c4 7d 16          	les    di,DWORD PTR es:[di+0x16]
    6ae8:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    6aec:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6aef:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    6af2:	99                   	cwd
    6af3:	52                   	push   dx
    6af4:	50                   	push   ax
    6af5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6af8:	26 c4 7d 16          	les    di,DWORD PTR es:[di+0x16]
    6afc:	06                   	push   es
    6afd:	57                   	push   di
    6afe:	9a 2b 0c 17 6c       	call   0x6c17:0xc2b
    6b03:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6b06:	c9                   	leave
    6b07:	ca 04 00             	retf   0x4
    6b0a:	c8 04 00 00          	enter  0x4,0x0
    6b0e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6b11:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    6b14:	75 02                	jne    0x6b18
    6b16:	eb 36                	jmp    0x6b4e
    6b18:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6b1b:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    6b1e:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    6b21:	06                   	push   es
    6b22:	57                   	push   di
    6b23:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b26:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    6b2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b2d:	26 3b 45 06          	cmp    ax,WORD PTR es:[di+0x6]
    6b31:	75 15                	jne    0x6b48
    6b33:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6b36:	06                   	push   es
    6b37:	57                   	push   di
    6b38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b3b:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    6b3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b42:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    6b46:	74 06                	je     0x6b4e
    6b48:	68 24 f0             	push   0xf024
    6b4b:	e8 bb b9             	call   0x2509
    6b4e:	c9                   	leave
    6b4f:	ca 08 00             	retf   0x8
    6b52:	c8 02 00 00          	enter  0x2,0x0
    6b56:	ff 76 10             	push   WORD PTR [bp+0x10]
    6b59:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6b5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b5f:	06                   	push   es
    6b60:	57                   	push   di
    6b61:	9a 0a 6b 74 6b       	call   0x6b74:0x6b0a
    6b66:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6b69:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6b6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b6f:	06                   	push   es
    6b70:	57                   	push   di
    6b71:	9a 0a 6b 7e 6b       	call   0x6b7e:0x6b0a
    6b76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b79:	06                   	push   es
    6b7a:	57                   	push   di
    6b7b:	9a 4a 6a 9a 6b       	call   0x6b9a:0x6a4a
    6b80:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6b83:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6b86:	ff 76 10             	push   WORD PTR [bp+0x10]
    6b89:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6b8c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6b8f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6b92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b95:	06                   	push   es
    6b96:	57                   	push   di
    6b97:	9a e4 6b b5 6b       	call   0x6bb5:0x6be4
    6b9c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6b9f:	c9                   	leave
    6ba0:	ca 0c 00             	retf   0xc
    6ba3:	c8 02 00 00          	enter  0x2,0x0
    6ba7:	ff 76 10             	push   WORD PTR [bp+0x10]
    6baa:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6bad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bb0:	06                   	push   es
    6bb1:	57                   	push   di
    6bb2:	9a 0a 6b bf 6b       	call   0x6bbf:0x6b0a
    6bb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bba:	06                   	push   es
    6bbb:	57                   	push   di
    6bbc:	9a 4a 6a db 6b       	call   0x6bdb:0x6a4a
    6bc1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6bc4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6bc7:	ff 76 10             	push   WORD PTR [bp+0x10]
    6bca:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6bcd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6bd0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6bd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bd6:	06                   	push   es
    6bd7:	57                   	push   di
    6bd8:	9a fa 6c f6 6b       	call   0x6bf6:0x6cfa
    6bdd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6be0:	c9                   	leave
    6be1:	ca 0c 00             	retf   0xc
    6be4:	c8 04 00 00          	enter  0x4,0x0
    6be8:	ff 76 10             	push   WORD PTR [bp+0x10]
    6beb:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6bee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bf1:	06                   	push   es
    6bf2:	57                   	push   di
    6bf3:	9a 0a 6b 06 6c       	call   0x6c06:0x6b0a
    6bf8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6bfb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6bfe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c01:	06                   	push   es
    6c02:	57                   	push   di
    6c03:	9a 0a 6b 3d 6c       	call   0x6c3d:0x6b0a
    6c08:	ff 76 12             	push   WORD PTR [bp+0x12]
    6c0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c0e:	26 c4 7d 16          	les    di,DWORD PTR es:[di+0x16]
    6c12:	06                   	push   es
    6c13:	57                   	push   di
    6c14:	9a d0 0d e8 6c       	call   0x6ce8:0xdd0
    6c19:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6c1c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6c1f:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    6c22:	09 c0                	or     ax,ax
    6c24:	74 24                	je     0x6c4a
    6c26:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6c29:	6a 00                	push   0x0
    6c2b:	ff 76 10             	push   WORD PTR [bp+0x10]
    6c2e:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6c31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c34:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6c38:	06                   	push   es
    6c39:	57                   	push   di
    6c3a:	9a 0f 5a 48 6c       	call   0x6c48:0x5a0f
    6c3f:	89 c7                	mov    di,ax
    6c41:	8e c2                	mov    es,dx
    6c43:	06                   	push   es
    6c44:	57                   	push   di
    6c45:	9a 9b 1b 6b 6c       	call   0x6c6b:0x1b9b
    6c4a:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    6c4d:	09 c0                	or     ax,ax
    6c4f:	b0 00                	mov    al,0x0
    6c51:	74 01                	je     0x6c54
    6c53:	40                   	inc    ax
    6c54:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    6c57:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    6c5b:	74 76                	je     0x6cd3
    6c5d:	6a 01                	push   0x1
    6c5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c62:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    6c66:	06                   	push   es
    6c67:	57                   	push   di
    6c68:	9a 26 62 c6 6c       	call   0x6cc6:0x6226
    6c6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c70:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6c74:	06                   	push   es
    6c75:	57                   	push   di
    6c76:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c79:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    6c7d:	50                   	push   ax
    6c7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c81:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    6c85:	06                   	push   es
    6c86:	57                   	push   di
    6c87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c8a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6c8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c91:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6c95:	06                   	push   es
    6c96:	57                   	push   di
    6c97:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c9a:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    6c9e:	50                   	push   ax
    6c9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ca2:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    6ca6:	06                   	push   es
    6ca7:	57                   	push   di
    6ca8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6cab:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    6caf:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6cb2:	6a 00                	push   0x0
    6cb4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6cb7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6cba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cbd:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    6cc1:	06                   	push   es
    6cc2:	57                   	push   di
    6cc3:	9a 0f 5a d1 6c       	call   0x6cd1:0x5a0f
    6cc8:	89 c7                	mov    di,ax
    6cca:	8e c2                	mov    es,dx
    6ccc:	06                   	push   es
    6ccd:	57                   	push   di
    6cce:	9a 9b 1b f2 6c       	call   0x6cf2:0x1b9b
    6cd3:	ff 76 12             	push   WORD PTR [bp+0x12]
    6cd6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6cd9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6cdc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cdf:	26 c4 7d 16          	les    di,DWORD PTR es:[di+0x16]
    6ce3:	06                   	push   es
    6ce4:	57                   	push   di
    6ce5:	9a 67 0f 59 6e       	call   0x6e59:0xf67
    6cea:	c9                   	leave
    6ceb:	ca 0e 00             	retf   0xe
    6cee:	00 00                	add    BYTE PTR [bx+si],al
    6cf0:	20 6e f8             	and    BYTE PTR [bp-0x8],ch
    6cf3:	6c                   	ins    BYTE PTR es:[di],dx
    6cf4:	00 00                	add    BYTE PTR [bx+si],al
    6cf6:	37                   	aaa
    6cf7:	6e                   	outs   dx,BYTE PTR ds:[si]
    6cf8:	0c 6d                	or     al,0x6d
    6cfa:	c8 0c 00 00          	enter  0xc,0x0
    6cfe:	ff 76 10             	push   WORD PTR [bp+0x10]
    6d01:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6d04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d07:	06                   	push   es
    6d08:	57                   	push   di
    6d09:	9a 0a 6b 15 6d       	call   0x6d15:0x6b0a
    6d0e:	b0 01                	mov    al,0x1
    6d10:	50                   	push   ax
    6d11:	b8 3f 08             	mov    ax,0x83f
    6d14:	ba 1c 6d             	mov    dx,0x6d1c
    6d17:	52                   	push   dx
    6d18:	50                   	push   ax
    6d19:	9a bd 56 52 6d       	call   0x6d52:0x56bd
    6d1e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6d21:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6d24:	b8 f4 6c             	mov    ax,0x6cf4
    6d27:	0e                   	push   cs
    6d28:	50                   	push   ax
    6d29:	55                   	push   bp
    6d2a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6d2e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6d32:	ff 76 10             	push   WORD PTR [bp+0x10]
    6d35:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6d38:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6d3b:	06                   	push   es
    6d3c:	57                   	push   di
    6d3d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d40:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    6d44:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6d47:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6d4a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6d4d:	06                   	push   es
    6d4e:	57                   	push   di
    6d4f:	9a 0f 5a 61 6d       	call   0x6d61:0x5a0f
    6d54:	89 c7                	mov    di,ax
    6d56:	8e c2                	mov    es,dx
    6d58:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    6d5c:	06                   	push   es
    6d5d:	57                   	push   di
    6d5e:	9a 84 16 6d 6d       	call   0x6d6d:0x1684
    6d63:	6a 01                	push   0x1
    6d65:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6d68:	06                   	push   es
    6d69:	57                   	push   di
    6d6a:	9a 26 62 76 6d       	call   0x6d76:0x6226
    6d6f:	b0 01                	mov    al,0x1
    6d71:	50                   	push   ax
    6d72:	b8 3f 08             	mov    ax,0x83f
    6d75:	ba 7d 6d             	mov    dx,0x6d7d
    6d78:	52                   	push   dx
    6d79:	50                   	push   ax
    6d7a:	9a bd 56 ad 6d       	call   0x6dad:0x56bd
    6d7f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6d82:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    6d85:	b8 ee 6c             	mov    ax,0x6cee
    6d88:	0e                   	push   cs
    6d89:	50                   	push   ax
    6d8a:	55                   	push   bp
    6d8b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6d8f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6d93:	ff 76 10             	push   WORD PTR [bp+0x10]
    6d96:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6d99:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6d9c:	06                   	push   es
    6d9d:	57                   	push   di
    6d9e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6da1:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    6da5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6da8:	06                   	push   es
    6da9:	57                   	push   di
    6daa:	9a 0f 5a d2 6d       	call   0x6dd2:0x5a0f
    6daf:	89 c7                	mov    di,ax
    6db1:	8e c2                	mov    es,dx
    6db3:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    6db6:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    6db9:	26 c7 45 17 c6 00    	mov    WORD PTR es:[di+0x17],0xc6
    6dbf:	26 c7 45 19 88 00    	mov    WORD PTR es:[di+0x19],0x88
    6dc5:	6a 00                	push   0x0
    6dc7:	6a 00                	push   0x0
    6dc9:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    6dcd:	06                   	push   es
    6dce:	57                   	push   di
    6dcf:	9a 84 16 e5 6d       	call   0x6de5:0x1684
    6dd4:	68 ff 00             	push   0xff
    6dd7:	6a ff                	push   0xffff
    6dd9:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    6ddc:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    6de0:	06                   	push   es
    6de1:	57                   	push   di
    6de2:	9a df 0f f9 6d       	call   0x6df9:0xfdf
    6de7:	6a 00                	push   0x0
    6de9:	6a 00                	push   0x0
    6deb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6dee:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6df1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    6df4:	06                   	push   es
    6df5:	57                   	push   di
    6df6:	9a 9b 1b 12 6e       	call   0x6e12:0x1b9b
    6dfb:	ff 76 12             	push   WORD PTR [bp+0x12]
    6dfe:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6e01:	ff 76 f8             	push   WORD PTR [bp-0x8]
    6e04:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6e07:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6e0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e0d:	06                   	push   es
    6e0e:	57                   	push   di
    6e0f:	9a e4 6b ce 6e       	call   0x6ece:0x6be4
    6e14:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6e18:	83 c4 06             	add    sp,0x6
    6e1b:	b8 2b 6e             	mov    ax,0x6e2b
    6e1e:	0e                   	push   cs
    6e1f:	50                   	push   ax
    6e20:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6e23:	06                   	push   es
    6e24:	57                   	push   di
    6e25:	9a 7f 1f 3f 6e       	call   0x6e3f:0x1f7f
    6e2a:	cb                   	retf
    6e2b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6e2f:	83 c4 06             	add    sp,0x6
    6e32:	b8 42 6e             	mov    ax,0x6e42
    6e35:	0e                   	push   cs
    6e36:	50                   	push   ax
    6e37:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6e3a:	06                   	push   es
    6e3b:	57                   	push   di
    6e3c:	9a 7f 1f 94 70       	call   0x7094:0x1f7f
    6e41:	cb                   	retf
    6e42:	c9                   	leave
    6e43:	ca 0e 00             	retf   0xe
    6e46:	c8 2c 00 00          	enter  0x2c,0x0
    6e4a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6e4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e50:	26 c4 7d 16          	les    di,DWORD PTR es:[di+0x16]
    6e54:	06                   	push   es
    6e55:	57                   	push   di
    6e56:	9a d0 0d 8d 70       	call   0x708d:0xdd0
    6e5b:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    6e5e:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    6e61:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    6e64:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    6e67:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    6e6a:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    6e6d:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    6e70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e73:	26 03 45 04          	add    ax,WORD PTR es:[di+0x4]
    6e77:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    6e7a:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    6e7d:	26 03 45 06          	add    ax,WORD PTR es:[di+0x6]
    6e81:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    6e84:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    6e87:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6e8a:	31 c0                	xor    ax,ax
    6e8c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    6e8f:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    6e92:	26 03 45 04          	add    ax,WORD PTR es:[di+0x4]
    6e96:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6e99:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    6e9d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6ea0:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    6ea3:	89 7e d4             	mov    WORD PTR [bp-0x2c],di
    6ea6:	8c 46 d6             	mov    WORD PTR [bp-0x2a],es
    6ea9:	80 7e e6 00          	cmp    BYTE PTR [bp-0x1a],0x0
    6ead:	75 46                	jne    0x6ef5
    6eaf:	26 8b 45 17          	mov    ax,WORD PTR es:[di+0x17]
    6eb3:	26 8b 55 19          	mov    dx,WORD PTR es:[di+0x19]
    6eb7:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    6eba:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    6ebd:	8d 7e f0             	lea    di,[bp-0x10]
    6ec0:	16                   	push   ss
    6ec1:	57                   	push   di
    6ec2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ec5:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6ec9:	06                   	push   es
    6eca:	57                   	push   di
    6ecb:	9a 0f 5a df 6e       	call   0x6edf:0x5a0f
    6ed0:	52                   	push   dx
    6ed1:	50                   	push   ax
    6ed2:	8d 7e f8             	lea    di,[bp-0x8]
    6ed5:	16                   	push   ss
    6ed6:	57                   	push   di
    6ed7:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    6eda:	06                   	push   es
    6edb:	57                   	push   di
    6edc:	9a 10 1b 17 6f       	call   0x6f17:0x1b10
    6ee1:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    6ee4:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    6ee7:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    6eea:	26 89 45 17          	mov    WORD PTR es:[di+0x17],ax
    6eee:	26 89 55 19          	mov    WORD PTR es:[di+0x19],dx
    6ef2:	e9 e0 00             	jmp    0x6fd5
    6ef5:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    6ef8:	26 8b 45 17          	mov    ax,WORD PTR es:[di+0x17]
    6efc:	26 8b 55 19          	mov    dx,WORD PTR es:[di+0x19]
    6f00:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    6f03:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    6f06:	26 c7 45 17 c6 00    	mov    WORD PTR es:[di+0x17],0xc6
    6f0c:	26 c7 45 19 88 00    	mov    WORD PTR es:[di+0x19],0x88
    6f12:	06                   	push   es
    6f13:	57                   	push   di
    6f14:	9a d2 21 31 6f       	call   0x6f31:0x21d2
    6f19:	50                   	push   ax
    6f1a:	6a 00                	push   0x0
    6f1c:	6a 00                	push   0x0
    6f1e:	9a bb 6f 00 00       	call   0x0:0x6fbb
    6f23:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    6f26:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    6f29:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    6f2c:	06                   	push   es
    6f2d:	57                   	push   di
    6f2e:	9a d2 21 55 6f       	call   0x6f55:0x21d2
    6f33:	50                   	push   ax
    6f34:	68 ff 00             	push   0xff
    6f37:	6a ff                	push   0xffff
    6f39:	9a d1 6f 00 00       	call   0x0:0x6fd1
    6f3e:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    6f41:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    6f44:	8d 7e f0             	lea    di,[bp-0x10]
    6f47:	16                   	push   ss
    6f48:	57                   	push   di
    6f49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f4c:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    6f50:	06                   	push   es
    6f51:	57                   	push   di
    6f52:	9a 0f 5a 66 6f       	call   0x6f66:0x5a0f
    6f57:	52                   	push   dx
    6f58:	50                   	push   ax
    6f59:	8d 7e f8             	lea    di,[bp-0x8]
    6f5c:	16                   	push   ss
    6f5d:	57                   	push   di
    6f5e:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    6f61:	06                   	push   es
    6f62:	57                   	push   di
    6f63:	9a 10 1b 88 6f       	call   0x6f88:0x1b10
    6f68:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    6f6b:	26 c7 45 17 46 00    	mov    WORD PTR es:[di+0x17],0x46
    6f71:	26 c7 45 19 66 00    	mov    WORD PTR es:[di+0x19],0x66
    6f77:	8d 7e f0             	lea    di,[bp-0x10]
    6f7a:	16                   	push   ss
    6f7b:	57                   	push   di
    6f7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f7f:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    6f83:	06                   	push   es
    6f84:	57                   	push   di
    6f85:	9a 0f 5a 99 6f       	call   0x6f99:0x5a0f
    6f8a:	52                   	push   dx
    6f8b:	50                   	push   ax
    6f8c:	8d 7e f8             	lea    di,[bp-0x8]
    6f8f:	16                   	push   ss
    6f90:	57                   	push   di
    6f91:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    6f94:	06                   	push   es
    6f95:	57                   	push   di
    6f96:	9a 10 1b b1 6f       	call   0x6fb1:0x1b10
    6f9b:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    6f9e:	8b 56 e2             	mov    dx,WORD PTR [bp-0x1e]
    6fa1:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    6fa4:	26 89 45 17          	mov    WORD PTR es:[di+0x17],ax
    6fa8:	26 89 55 19          	mov    WORD PTR es:[di+0x19],dx
    6fac:	06                   	push   es
    6fad:	57                   	push   di
    6fae:	9a d2 21 c7 6f       	call   0x6fc7:0x21d2
    6fb3:	50                   	push   ax
    6fb4:	ff 76 de             	push   WORD PTR [bp-0x22]
    6fb7:	ff 76 dc             	push   WORD PTR [bp-0x24]
    6fba:	9a ff ff 00 00       	call   0x0:0xffff
    6fbf:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    6fc2:	06                   	push   es
    6fc3:	57                   	push   di
    6fc4:	9a d2 21 44 70       	call   0x7044:0x21d2
    6fc9:	50                   	push   ax
    6fca:	ff 76 da             	push   WORD PTR [bp-0x26]
    6fcd:	ff 76 d8             	push   WORD PTR [bp-0x28]
    6fd0:	9a ff ff 00 00       	call   0x0:0xffff
    6fd5:	c9                   	leave
    6fd6:	ca 0e 00             	retf   0xe
    6fd9:	c8 02 01 00          	enter  0x102,0x0
    6fdd:	6a 00                	push   0x0
    6fdf:	9a ff ff 00 00       	call   0x0:0xffff
    6fe4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6fe7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6fea:	6a 5a                	push   0x5a
    6fec:	9a ff ff 00 00       	call   0x0:0xffff
    6ff1:	a3 16 2b             	mov    ds:0x2b16,ax
    6ff4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6ff7:	9a ff ff 00 00       	call   0x0:0xffff
    6ffc:	6a 0a                	push   0xa
    6ffe:	ff 36 16 2b          	push   WORD PTR ds:0x2b16
    7002:	6a 48                	push   0x48
    7004:	9a ff ff 00 00       	call   0x0:0xffff
    7009:	f7 d8                	neg    ax
    700b:	a3 44 12             	mov    ds:0x1244,ax
    700e:	6a 07                	push   0x7
    7010:	9a 1b 70 00 00       	call   0x0:0x701b
    7015:	a3 18 2b             	mov    ds:0x2b18,ax
    7018:	6a 05                	push   0x5
    701a:	9a 25 70 00 00       	call   0x0:0x7025
    701f:	a3 1a 2b             	mov    ds:0x2b1a,ax
    7022:	6a 0d                	push   0xd
    7024:	9a ff ff 00 00       	call   0x0:0xffff
    7029:	a3 1c 2b             	mov    ds:0x2b1c,ax
    702c:	6a 00                	push   0x0
    702e:	6a 00                	push   0x0
    7030:	68 00 7f             	push   0x7f00
    7033:	9a ff ff 00 00       	call   0x0:0xffff
    7038:	a3 1e 2b             	mov    ds:0x2b1e,ax
    703b:	6a 26                	push   0x26
    703d:	b0 01                	mov    al,0x1
    703f:	50                   	push   ax
    7040:	b8 b1 09             	mov    ax,0x9b1
    7043:	ba 4b 70             	mov    dx,0x704b
    7046:	52                   	push   dx
    7047:	50                   	push   ax
    7048:	9a f4 09 5d 70       	call   0x705d:0x9f4
    704d:	a3 20 2b             	mov    ds:0x2b20,ax
    7050:	89 16 22 2b          	mov    WORD PTR ds:0x2b22,dx
    7054:	6a 09                	push   0x9
    7056:	b0 01                	mov    al,0x1
    7058:	50                   	push   ax
    7059:	b8 b1 09             	mov    ax,0x9b1
    705c:	ba 64 70             	mov    dx,0x7064
    705f:	52                   	push   dx
    7060:	50                   	push   ax
    7061:	9a f4 09 76 70       	call   0x7076:0x9f4
    7066:	a3 24 2b             	mov    ds:0x2b24,ax
    7069:	89 16 26 2b          	mov    WORD PTR ds:0x2b26,dx
    706d:	6a 0b                	push   0xb
    706f:	b0 01                	mov    al,0x1
    7071:	50                   	push   ax
    7072:	b8 b1 09             	mov    ax,0x9b1
    7075:	ba 7d 70             	mov    dx,0x707d
    7078:	52                   	push   dx
    7079:	50                   	push   ax
    707a:	9a f4 09 a4 70       	call   0x70a4:0x9f4
    707f:	a3 28 2b             	mov    ds:0x2b28,ax
    7082:	89 16 2a 2b          	mov    WORD PTR ds:0x2b2a,dx
    7086:	b0 01                	mov    al,0x1
    7088:	50                   	push   ax
    7089:	b8 a3 02             	mov    ax,0x2a3
    708c:	ba 0f 71             	mov    dx,0x710f
    708f:	52                   	push   dx
    7090:	50                   	push   ax
    7091:	9a 50 1f ab 70       	call   0x70ab:0x1f50
    7096:	a3 70 2b             	mov    ds:0x2b70,ax
    7099:	89 16 72 2b          	mov    WORD PTR ds:0x2b72,dx
    709d:	b0 01                	mov    al,0x1
    709f:	50                   	push   ax
    70a0:	b8 45 3f             	mov    ax,0x3f45
    70a3:	ba bb 70             	mov    dx,0x70bb
    70a6:	52                   	push   dx
    70a7:	50                   	push   ax
    70a8:	9a 50 1f c2 70       	call   0x70c2:0x1f50
    70ad:	a3 30 2b             	mov    ds:0x2b30,ax
    70b0:	89 16 32 2b          	mov    WORD PTR ds:0x2b32,dx
    70b4:	b0 01                	mov    al,0x1
    70b6:	50                   	push   ax
    70b7:	b8 45 3f             	mov    ax,0x3f45
    70ba:	ba d2 70             	mov    dx,0x70d2
    70bd:	52                   	push   dx
    70be:	50                   	push   ax
    70bf:	9a 50 1f d9 70       	call   0x70d9:0x1f50
    70c4:	a3 34 2b             	mov    ds:0x2b34,ax
    70c7:	89 16 36 2b          	mov    WORD PTR ds:0x2b36,dx
    70cb:	b0 01                	mov    al,0x1
    70cd:	50                   	push   ax
    70ce:	b8 45 3f             	mov    ax,0x3f45
    70d1:	ba e9 70             	mov    dx,0x70e9
    70d4:	52                   	push   dx
    70d5:	50                   	push   ax
    70d6:	9a 50 1f f0 70       	call   0x70f0:0x1f50
    70db:	a3 38 2b             	mov    ds:0x2b38,ax
    70de:	89 16 3a 2b          	mov    WORD PTR ds:0x2b3a,dx
    70e2:	b0 01                	mov    al,0x1
    70e4:	50                   	push   ax
    70e5:	b8 45 3f             	mov    ax,0x3f45
    70e8:	ba 06 71             	mov    dx,0x7106
    70eb:	52                   	push   dx
    70ec:	50                   	push   ax
    70ed:	9a 50 1f 16 71       	call   0x7116:0x1f50
    70f2:	a3 3c 2b             	mov    ds:0x2b3c,ax
    70f5:	89 16 3e 2b          	mov    WORD PTR ds:0x2b3e,dx
    70f9:	ff 36 1e 2b          	push   WORD PTR ds:0x2b1e
    70fd:	c4 3e 3c 2b          	les    di,DWORD PTR ds:0x2b3c
    7101:	06                   	push   es
    7102:	57                   	push   di
    7103:	9a ae 3f 71 71       	call   0x7171:0x3fae
    7108:	b0 01                	mov    al,0x1
    710a:	50                   	push   ax
    710b:	b8 a3 02             	mov    ax,0x2a3
    710e:	ba 88 71             	mov    dx,0x7188
    7111:	52                   	push   dx
    7112:	50                   	push   ax
    7113:	9a 50 1f 37 71       	call   0x7137:0x1f50
    7118:	a3 2c 2b             	mov    ds:0x2b2c,ax
    711b:	89 16 2e 2b          	mov    WORD PTR ds:0x2b2e,dx
    711f:	8d be fe fe          	lea    di,[bp-0x102]
    7123:	16                   	push   ss
    7124:	57                   	push   di
    7125:	68 52 f0             	push   0xf052
    7128:	9a 2b 09 45 71       	call   0x7145:0x92b
    712d:	bf 40 2b             	mov    di,0x2b40
    7130:	1e                   	push   ds
    7131:	57                   	push   di
    7132:	6a 0f                	push   0xf
    7134:	9a e7 17 51 71       	call   0x7151:0x17e7
    7139:	8d be fe fe          	lea    di,[bp-0x102]
    713d:	16                   	push   ss
    713e:	57                   	push   di
    713f:	68 53 f0             	push   0xf053
    7142:	9a 2b 09 5f 71       	call   0x715f:0x92b
    7147:	bf 50 2b             	mov    di,0x2b50
    714a:	1e                   	push   ds
    714b:	57                   	push   di
    714c:	6a 0f                	push   0xf
    714e:	9a e7 17 6b 71       	call   0x716b:0x17e7
    7153:	8d be fe fe          	lea    di,[bp-0x102]
    7157:	16                   	push   ss
    7158:	57                   	push   di
    7159:	68 54 f0             	push   0xf054
    715c:	9a 2b 09 ff ff       	call   0xffff:0x92b
    7161:	bf 60 2b             	mov    di,0x2b60
    7164:	1e                   	push   ds
    7165:	57                   	push   di
    7166:	6a 0f                	push   0xf
    7168:	9a e7 17 ff ff       	call   0xffff:0x17e7
    716d:	bf 02 00             	mov    di,0x2
    7170:	b8 79 71             	mov    ax,0x7179
    7173:	50                   	push   ax
    7174:	57                   	push   di
    7175:	bf 08 0e             	mov    di,0xe08
    7178:	b8 81 71             	mov    ax,0x7181
    717b:	50                   	push   ax
    717c:	57                   	push   di
    717d:	bf a5 0d             	mov    di,0xda5
    7180:	b8 ff ff             	mov    ax,0xffff
    7183:	50                   	push   ax
    7184:	57                   	push   di
    7185:	9a 36 0a ff ff       	call   0xffff:0xa36
    718a:	c9                   	leave
    718b:	cb                   	retf
