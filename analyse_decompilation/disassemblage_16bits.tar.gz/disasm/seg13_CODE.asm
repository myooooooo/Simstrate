; ================================================================
; seg13_CODE  (30968 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	0d 00 6c             	or     ax,0x6c00
       3:	22 94 03 b2          	and    dl,BYTE PTR [si-0x4dfd]
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 9e 00 f6          	add    BYTE PTR [bp-0xa00],bl
       d:	08 fb                	or     bl,bh
       f:	04 87                	add    al,0x87
      11:	22 39                	and    bh,BYTE PTR [bx+di]
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 9a 22 cb       	call   0xcb22:0x9a1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 c6                	adc    dh,al
      2d:	2f                   	das
      2e:	d6                   	(bad)
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 4c                	sbb    al,0x4c
      61:	23 e2                	and    sp,dx
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	13 54 46             	adc    dx,WORD PTR [si+0x46]
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	45                   	inc    bp
      a6:	52                   	push   dx
      a7:	53                   	push   bx
      a8:	5f                   	pop    di
      a9:	53                   	push   bx
      aa:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
      af:	69 6f 6e 25 00       	imul   bp,WORD PTR [bx+0x6e],0x25
      b4:	fa                   	cli
      b5:	24 c9                	and    al,0xc9
      b7:	00 0e 49 6d          	add    BYTE PTR ds:0x6d49,cl
      bb:	70 72                	jo     0x12f
      bd:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
      c2:	43                   	inc    bx
      c3:	6c                   	ins    BYTE PTR es:[di],dx
      c4:	69 63 6b a8 40       	imul   sp,WORD PTR [bp+di+0x6b],0x40a8
      c9:	db 00                	fild   DWORD PTR [bx+si]
      cb:	0d 51 75             	or     ax,0x7551
      ce:	69 74 74 65 72       	imul   si,WORD PTR [si+0x74],0x7265
      d3:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
      d6:	69 63 6b 49 52       	imul   sp,WORD PTR [bp+di+0x6b],0x5249
      db:	eb 00                	jmp    0xdd
      dd:	0b 46 6f             	or     ax,WORD PTR [bp+0x6f]
      e0:	72 6d                	jb     0x14f
      e2:	4b                   	dec    bx
      e3:	65 79 44             	gs jns 0x12a
      e6:	6f                   	outs   dx,WORD PTR ds:[si]
      e7:	77 6e                	ja     0x157
      e9:	f7 3b                	idiv   WORD PTR [bp+di]
      eb:	fa                   	cli
      ec:	00 0a                	add    BYTE PTR [bp+si],cl
      ee:	46                   	inc    si
      ef:	6f                   	outs   dx,WORD PTR ds:[si]
      f0:	72 6d                	jb     0x15f
      f2:	43                   	inc    bx
      f3:	72 65                	jb     0x15a
      f5:	61                   	popa
      f6:	74 65                	je     0x15d
      f8:	c0 40 0f 01          	rol    BYTE PTR [bx+si+0xf],0x1
      fc:	10 50 6c             	adc    BYTE PTR [bx+si+0x6c],dl
      ff:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     105:	61                   	popa
     106:	6e                   	outs   dx,BYTE PTR ds:[si]
     107:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     10a:	69 63 6b 89 40       	imul   sp,WORD PTR [bp+di+0x6b],0x4089
     10f:	1d 01 09             	sbb    ax,0x901
     112:	46                   	inc    si
     113:	6f                   	outs   dx,WORD PTR ds:[si]
     114:	72 6d                	jb     0x183
     116:	43                   	inc    bx
     117:	6c                   	ins    BYTE PTR es:[di],dx
     118:	6f                   	outs   dx,WORD PTR ds:[si]
     119:	73 65                	jae    0x180
     11b:	19 42 2c             	sbb    WORD PTR [bp+si+0x2c],ax
     11e:	01 0a                	add    WORD PTR [bp+si],cx
     120:	46                   	inc    si
     121:	6f                   	outs   dx,WORD PTR ds:[si]
     122:	72 6d                	jb     0x191
     124:	52                   	push   dx
     125:	65 73 69             	gs jae 0x191
     128:	7a 65                	jp     0x18f
     12a:	91                   	xchg   cx,ax
     12b:	44                   	inc    sp
     12c:	47                   	inc    di
     12d:	01 16 54 61          	add    WORD PTR ds:0x6154,dx
     131:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     134:	45                   	inc    bp
     135:	52                   	push   dx
     136:	47                   	inc    di
     137:	5f                   	pop    di
     138:	6f                   	outs   dx,WORD PTR ds:[si]
     139:	6c                   	ins    BYTE PTR es:[di],dx
     13a:	64 43                	fs inc bx
     13c:	61                   	popa
     13d:	6c                   	ins    BYTE PTR es:[di],dx
     13e:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     141:	65 6c                	gs ins BYTE PTR es:[di],dx
     143:	64 73 e3             	fs jae 0x129
     146:	46                   	inc    si
     147:	5e                   	pop    si
     148:	01 12                	add    WORD PTR [bp+si],dx
     14a:	54                   	push   sp
     14b:	61                   	popa
     14c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     14f:	45                   	inc    bp
     150:	52                   	push   dx
     151:	47                   	inc    di
     152:	43                   	inc    bx
     153:	61                   	popa
     154:	6c                   	ins    BYTE PTR es:[di],dx
     155:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     158:	65 6c                	gs ins BYTE PTR es:[di],dx
     15a:	64 73 42             	fs jae 0x19f
     15d:	42                   	inc    dx
     15e:	75 01                	jne    0x161
     160:	12 42 61             	adc    al,BYTE PTR [bp+si+0x61]
     163:	72 72                	jb     0x1d7
     165:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     168:	75 74                	jne    0x1de
     16a:	69 6c 73 31 43       	imul   bp,WORD PTR [si+0x73],0x4331
     16f:	6c                   	ins    BYTE PTR es:[di],dx
     170:	69 63 6b 40 54       	imul   sp,WORD PTR [bp+di+0x6b],0x5440
     175:	85 01                	test   WORD PTR [bx+di],ax
     177:	0b 49 6e             	or     cx,WORD PTR [bx+di+0x6e]
     17a:	64 65 78 31          	fs gs js 0x1af
     17e:	43                   	inc    bx
     17f:	6c                   	ins    BYTE PTR es:[di],dx
     180:	69 63 6b 5f 54       	imul   sp,WORD PTR [bp+di+0x6b],0x545f
     185:	9a 01 10 52 65       	call   0x6552:0x1001
     18a:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     18d:	72 63                	jb     0x1f2
     18f:	68 65 72             	push   0x7265
     192:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     195:	69 63 6b 80 54       	imul   sp,WORD PTR [bp+di+0x6b],0x5480
     19a:	b2 01                	mov    dl,0x1
     19c:	13 55 74             	adc    dx,WORD PTR [di+0x74]
     19f:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     1a4:	72 6c                	jb     0x212
     1a6:	61                   	popa
     1a7:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     1ac:	6c                   	ins    BYTE PTR es:[di],dx
     1ad:	69 63 6b 9f 54       	imul   sp,WORD PTR [bp+di+0x6b],0x549f
     1b2:	c4 01                	les    ax,DWORD PTR [bx+di]
     1b4:	0d 41 70             	or     ax,0x7041
     1b7:	72 6f                	jb     0x228
     1b9:	70 6f                	jo     0x22a
     1bb:	73 31                	jae    0x1ee
     1bd:	43                   	inc    bx
     1be:	6c                   	ins    BYTE PTR es:[di],dx
     1bf:	69 63 6b 30 49       	imul   sp,WORD PTR [bp+di+0x6b],0x4930
     1c4:	dc 01                	fadd   QWORD PTR [bx+di]
     1c6:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     1c9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1cc:	45                   	inc    bp
     1cd:	44                   	inc    sp
     1ce:	50                   	push   ax
     1cf:	31 43 61             	xor    WORD PTR [bp+di+0x61],ax
     1d2:	6c                   	ins    BYTE PTR es:[di],dx
     1d3:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     1d6:	65 6c                	gs ins BYTE PTR es:[di],dx
     1d8:	64 73 2a             	fs jae 0x205
     1db:	4c                   	dec    sp
     1dc:	f4                   	hlt
     1dd:	01 13                	add    WORD PTR [bp+di],dx
     1df:	54                   	push   sp
     1e0:	61                   	popa
     1e1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1e4:	45                   	inc    bp
     1e5:	52                   	push   dx
     1e6:	50                   	push   ax
     1e7:	31 43 61             	xor    WORD PTR [bp+di+0x61],ax
     1ea:	6c                   	ins    BYTE PTR es:[di],dx
     1eb:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     1ee:	65 6c                	gs ins BYTE PTR es:[di],dx
     1f0:	64 73 83             	fs jae 0x176
     1f3:	4f                   	dec    di
     1f4:	0c 02                	or     al,0x2
     1f6:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     1f9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1fc:	45                   	inc    bp
     1fd:	52                   	push   dx
     1fe:	50                   	push   ax
     1ff:	32 43 61             	xor    al,BYTE PTR [bp+di+0x61]
     202:	6c                   	ins    BYTE PTR es:[di],dx
     203:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     206:	65 6c                	gs ins BYTE PTR es:[di],dx
     208:	64 73 57             	fs jae 0x262
     20b:	42                   	inc    dx
     20c:	1e                   	push   ds
     20d:	02 0d                	add    cl,BYTE PTR [di]
     20f:	50                   	push   ax
     210:	65 72 69             	gs jb  0x27c
     213:	6f                   	outs   dx,WORD PTR ds:[si]
     214:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     219:	69 63 6b 9c 43       	imul   sp,WORD PTR [bp+di+0x6b],0x439c
     21e:	2b 02                	sub    ax,WORD PTR [bp+si]
     220:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     223:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     226:	69 63 6b 6b 2a       	imul   sp,WORD PTR [bp+di+0x6b],0x2a6b
     22b:	3b 02                	cmp    ax,WORD PTR [bp+si]
     22d:	0b 44 42             	or     ax,WORD PTR [si+0x42]
     230:	45                   	inc    bp
     231:	64 69 74 31 45 78    	imul   si,WORD PTR fs:[si+0x31],0x7845
     237:	69 74 21 2b 4e       	imul   si,WORD PTR [si+0x21],0x4e2b
     23c:	02 0e 44 42          	add    cl,BYTE PTR ds:0x4244
     240:	45                   	inc    bp
     241:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     247:	79 44                	jns    0x28d
     249:	6f                   	outs   dx,WORD PTR ds:[si]
     24a:	77 6e                	ja     0x2ba
     24c:	b8 2a 5f             	mov    ax,0x5f2a
     24f:	02 0c                	add    cl,BYTE PTR [si]
     251:	44                   	inc    sp
     252:	42                   	inc    dx
     253:	45                   	inc    bp
     254:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     25a:	79 55                	jns    0x2b1
     25c:	70 6e                	jo     0x2cc
     25e:	40                   	inc    ax
     25f:	6c                   	ins    BYTE PTR es:[di],dx
     260:	02 08                	add    cl,BYTE PTR [bx+si]
     262:	46                   	inc    si
     263:	6f                   	outs   dx,WORD PTR ds:[si]
     264:	72 6d                	jb     0x2d3
     266:	53                   	push   bx
     267:	68 6f 77             	push   0x776f
     26a:	37                   	aaa
     26b:	55                   	push   bp
     26c:	81 02 10 44          	add    WORD PTR [bp+si],0x4410
     270:	42                   	inc    dx
     271:	45                   	inc    bp
     272:	64 69 74 31 4d 6f    	imul   si,WORD PTR fs:[si+0x31],0x6f4d
     278:	75 73                	jne    0x2ed
     27a:	65 44                	gs inc sp
     27c:	6f                   	outs   dx,WORD PTR ds:[si]
     27d:	77 6e                	ja     0x2ed
     27f:	15 54 91             	adc    ax,0x9154
     282:	02 0b                	add    cl,BYTE PTR [bp+di]
     284:	46                   	inc    si
     285:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     28a:	43                   	inc    bx
     28b:	6c                   	ins    BYTE PTR es:[di],dx
     28c:	69 63 6b 42 5b       	imul   sp,WORD PTR [bp+di+0x6b],0x5b42
     291:	a2 02 0c             	mov    ds:0xc02,al
     294:	43                   	inc    bx
     295:	6f                   	outs   dx,WORD PTR ds:[si]
     296:	70 69                	jo     0x301
     298:	65 72 31             	gs jb  0x2cc
     29b:	43                   	inc    bx
     29c:	6c                   	ins    BYTE PTR es:[di],dx
     29d:	69 63 6b ee 55       	imul   sp,WORD PTR [bp+di+0x6b],0x55ee
     2a2:	b7 02                	mov    bh,0x2
     2a4:	10 50 61             	adc    BYTE PTR [bx+si+0x61],dl
     2a7:	6e                   	outs   dx,BYTE PTR ds:[si]
     2a8:	65 6c                	gs ins BYTE PTR es:[di],dx
     2aa:	31 33                	xor    WORD PTR [bp+di],si
     2ac:	4d                   	dec    bp
     2ad:	6f                   	outs   dx,WORD PTR ds:[si]
     2ae:	75 73                	jne    0x323
     2b0:	65 44                	gs inc sp
     2b2:	6f                   	outs   dx,WORD PTR ds:[si]
     2b3:	77 6e                	ja     0x323
     2b5:	c1 77 cb 02          	shl    WORD PTR [bx-0x35],0x2
     2b9:	0f 53 69 74          	rcpps  xmm5,XMMWORD PTR [bx+di+0x74]
     2bd:	75 61                	jne    0x320
     2bf:	74 69                	je     0x32a
     2c1:	6f                   	outs   dx,WORD PTR ds:[si]
     2c2:	6e                   	outs   dx,BYTE PTR ds:[si]
     2c3:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     2c6:	69 63 6b ef 77       	imul   sp,WORD PTR [bp+di+0x6b],0x77ef
     2cb:	e7 02                	out    0x2,ax
     2cd:	17                   	pop    ss
     2ce:	43                   	inc    bx
     2cf:	6f                   	outs   dx,WORD PTR ds:[si]
     2d0:	6d                   	ins    WORD PTR es:[di],dx
     2d1:	70 74                	jo     0x347
     2d3:	65 44                	gs inc sp
     2d5:	65 52                	gs push dx
     2d7:	65 73 75             	gs jae 0x34f
     2da:	6c                   	ins    BYTE PTR es:[di],dx
     2db:	74 61                	je     0x33e
     2dd:	74 73                	je     0x352
     2df:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     2e2:	69 63 6b 1d 78       	imul   sp,WORD PTR [bp+di+0x6b],0x781d
     2e7:	f7 02 0b 42          	test   WORD PTR [bp+si],0x420b
     2eb:	69 6c 61 6e 31       	imul   bp,WORD PTR [si+0x61],0x316e
     2f0:	43                   	inc    bx
     2f1:	6c                   	ins    BYTE PTR es:[di],dx
     2f2:	69 63 6b 4b 78       	imul   sp,WORD PTR [bp+di+0x6b],0x784b
     2f7:	16                   	push   ss
     2f8:	03 1a                	add    bx,WORD PTR [bp+si]
     2fa:	54                   	push   sp
     2fb:	61                   	popa
     2fc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2ff:	61                   	popa
     300:	75 44                	jne    0x346
     302:	65 46                	gs inc si
     304:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     309:	65 6d                	gs ins WORD PTR es:[di],dx
     30b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     30d:	74 31                	je     0x340
     30f:	43                   	inc    bx
     310:	6c                   	ins    BYTE PTR es:[di],dx
     311:	69 63 6b 79 78       	imul   sp,WORD PTR [bp+di+0x6b],0x7879
     316:	34 03                	xor    al,0x3
     318:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     31b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     31e:	61                   	popa
     31f:	75 44                	jne    0x365
     321:	65 54                	gs push sp
     323:	72 65                	jb     0x38a
     325:	73 6f                	jae    0x396
     327:	72 65                	jb     0x38e
     329:	72 69                	jb     0x394
     32b:	65 31 43 6c          	xor    WORD PTR gs:[bp+di+0x6c],ax
     32f:	69 63 6b d5 78       	imul   sp,WORD PTR [bp+di+0x6b],0x78d5
     334:	51                   	push   cx
     335:	03 18                	add    bx,WORD PTR [bx+si]
     337:	52                   	push   dx
     338:	61                   	popa
     339:	70 70                	jo     0x3ab
     33b:	65 6c                	gs ins BYTE PTR es:[di],dx
     33d:	44                   	inc    sp
     33e:	65 73 44             	gs jae 0x385
     341:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     345:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     34a:	43                   	inc    bx
     34b:	6c                   	ins    BYTE PTR es:[di],dx
     34c:	69 63 6b fc 40       	imul   sp,WORD PTR [bp+di+0x6b],0x40fc
     351:	60                   	pusha
     352:	03 0a                	add    cx,WORD PTR [bp+si]
     354:	4e                   	dec    si
     355:	31 30                	xor    WORD PTR [bx+si],si
     357:	30 31                	xor    BYTE PTR [bx+di],dh
     359:	43                   	inc    bx
     35a:	6c                   	ins    BYTE PTR es:[di],dx
     35b:	69 63 6b 57 56       	imul   sp,WORD PTR [bp+di+0x6b],0x5657
     360:	7b 03                	jnp    0x365
     362:	16                   	push   ss
     363:	49                   	dec    cx
     364:	6d                   	ins    WORD PTR es:[di],dx
     365:	70 72                	jo     0x3d9
     367:	65 73 73             	gs jae 0x3dd
     36a:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     36f:	70 69                	jo     0x3da
     371:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     376:	69 63 6b 9e 42       	imul   sp,WORD PTR [bp+di+0x6b],0x429e
     37b:	88 03                	mov    BYTE PTR [bp+di],al
     37d:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     380:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     383:	69 63 6b a7 78       	imul   sp,WORD PTR [bp+di+0x6b],0x78a7
     388:	83 22 09             	and    WORD PTR [bp+si],0x9
     38b:	53                   	push   bx
     38c:	49                   	dec    cx
     38d:	47                   	inc    di
     38e:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     391:	69 63 6b 9d 01       	imul   sp,WORD PTR [bp+di+0x6b],0x19d
     396:	36 22 7c 01          	and    bh,BYTE PTR ss:[si+0x1]
     39a:	00 00                	add    BYTE PTR [bx+si],al
     39c:	09 4d 61             	or     WORD PTR [di+0x61],cx
     39f:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     3a4:	75 31                	jne    0x3d7
     3a6:	80 01 04             	add    BYTE PTR [bx+di],0x4
     3a9:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     3ad:	6e                   	outs   dx,BYTE PTR ds:[si]
     3ae:	65 6c                	gs ins BYTE PTR es:[di],dx
     3b0:	30 84 01 08          	xor    BYTE PTR [si+0x801],al
     3b4:	00 08                	add    BYTE PTR [bx+si],cl
     3b6:	46                   	inc    si
     3b7:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     3bc:	72 31                	jb     0x3ef
     3be:	88 01                	mov    BYTE PTR [bx+di],al
     3c0:	08 00                	or     BYTE PTR [bx+si],al
     3c2:	08 51 75             	or     BYTE PTR [bx+di+0x75],dl
     3c5:	69 74 74 65 72       	imul   si,WORD PTR [si+0x74],0x7265
     3ca:	31 8c 01 08          	xor    WORD PTR [si+0x801],cx
     3ce:	00 02                	add    BYTE PTR [bp+si],al
     3d0:	4e                   	dec    si
     3d1:	31 90 01 08          	xor    WORD PTR [bx+si+0x801],dx
     3d5:	00 09                	add    BYTE PTR [bx+di],cl
     3d7:	49                   	dec    cx
     3d8:	6d                   	ins    WORD PTR es:[di],dx
     3d9:	70 72                	jo     0x44d
     3db:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     3e0:	94                   	xchg   sp,ax
     3e1:	01 08                	add    WORD PTR [bx+si],cx
     3e3:	00 05                	add    BYTE PTR [di],al
     3e5:	41                   	inc    cx
     3e6:	69 64 65 31 98       	imul   sp,WORD PTR [si+0x65],0x9831
     3eb:	01 08                	add    WORD PTR [bx+si],cx
     3ed:	00 08                	add    BYTE PTR [bx+si],cl
     3ef:	41                   	inc    cx
     3f0:	70 72                	jo     0x464
     3f2:	6f                   	outs   dx,WORD PTR ds:[si]
     3f3:	70 6f                	jo     0x464
     3f5:	73 31                	jae    0x428
     3f7:	9c                   	pushf
     3f8:	01 08                	add    WORD PTR [bx+si],cx
     3fa:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     3fe:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     403:	72 6c                	jb     0x471
     405:	61                   	popa
     406:	69 64 65 31 a0       	imul   sp,WORD PTR [si+0x65],0xa031
     40b:	01 08                	add    WORD PTR [bx+si],cx
     40d:	00 0b                	add    BYTE PTR [bp+di],cl
     40f:	52                   	push   dx
     410:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     414:	72 63                	jb     0x479
     416:	68 65 72             	push   0x7265
     419:	31 a4 01 08          	xor    WORD PTR [si+0x801],sp
     41d:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     421:	64 65 78 31          	fs gs js 0x456
     425:	a8 01                	test   al,0x1
     427:	04 00                	add    al,0x0
     429:	06                   	push   es
     42a:	50                   	push   ax
     42b:	61                   	popa
     42c:	6e                   	outs   dx,BYTE PTR ds:[si]
     42d:	65 6c                	gs ins BYTE PTR es:[di],dx
     42f:	32 ac 01 04          	xor    ch,BYTE PTR [si+0x401]
     433:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     437:	6e                   	outs   dx,BYTE PTR ds:[si]
     438:	65 6c                	gs ins BYTE PTR es:[di],dx
     43a:	35 b0 01             	xor    ax,0x1b0
     43d:	04 00                	add    al,0x0
     43f:	06                   	push   es
     440:	50                   	push   ax
     441:	61                   	popa
     442:	6e                   	outs   dx,BYTE PTR ds:[si]
     443:	65 6c                	gs ins BYTE PTR es:[di],dx
     445:	33 b4 01 04          	xor    si,WORD PTR [si+0x401]
     449:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     44d:	6e                   	outs   dx,BYTE PTR ds:[si]
     44e:	65 6c                	gs ins BYTE PTR es:[di],dx
     450:	36 b8 01 04          	ss mov ax,0x401
     454:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     458:	6e                   	outs   dx,BYTE PTR ds:[si]
     459:	65 6c                	gs ins BYTE PTR es:[di],dx
     45b:	37                   	aaa
     45c:	bc 01 04             	mov    sp,0x401
     45f:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     463:	6e                   	outs   dx,BYTE PTR ds:[si]
     464:	65 6c                	gs ins BYTE PTR es:[di],dx
     466:	38 c0                	cmp    al,al
     468:	01 04                	add    WORD PTR [si],ax
     46a:	00 07                	add    BYTE PTR [bx],al
     46c:	50                   	push   ax
     46d:	61                   	popa
     46e:	6e                   	outs   dx,BYTE PTR ds:[si]
     46f:	65 6c                	gs ins BYTE PTR es:[di],dx
     471:	33 37                	xor    si,WORD PTR [bx]
     473:	c4 01                	les    ax,DWORD PTR [bx+di]
     475:	04 00                	add    al,0x0
     477:	07                   	pop    es
     478:	50                   	push   ax
     479:	61                   	popa
     47a:	6e                   	outs   dx,BYTE PTR ds:[si]
     47b:	65 6c                	gs ins BYTE PTR es:[di],dx
     47d:	33 38                	xor    di,WORD PTR [bx+si]
     47f:	c8 01 08 00          	enter  0x801,0x0
     483:	0a 41 66             	or     al,BYTE PTR [bx+di+0x66]
     486:	66 69 63 68 61 67 65 	imul   esp,DWORD PTR [bp+di+0x68],0x31656761
     48d:	31 
     48e:	cc                   	int3
     48f:	01 08                	add    WORD PTR [bx+si],cx
     491:	00 0d                	add    BYTE PTR [di],cl
     493:	42                   	inc    dx
     494:	61                   	popa
     495:	72 72                	jb     0x509
     497:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     49a:	75 74                	jne    0x510
     49c:	69 6c 73 31 d0       	imul   bp,WORD PTR [si+0x73],0xd031
     4a1:	01 08                	add    WORD PTR [bx+si],cx
     4a3:	00 0b                	add    BYTE PTR [bp+di],cl
     4a5:	50                   	push   ax
     4a6:	6c                   	ins    BYTE PTR es:[di],dx
     4a7:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     4ad:	61                   	popa
     4ae:	6e                   	outs   dx,BYTE PTR ds:[si]
     4af:	31 d4                	xor    sp,dx
     4b1:	01 08                	add    WORD PTR [bx+si],cx
     4b3:	00 02                	add    BYTE PTR [bp+si],al
     4b5:	4e                   	dec    si
     4b6:	32 d8                	xor    bl,al
     4b8:	01 08                	add    WORD PTR [bx+si],cx
     4ba:	00 05                	add    BYTE PTR [di],al
     4bc:	5a                   	pop    dx
     4bd:	6f                   	outs   dx,WORD PTR ds:[si]
     4be:	6f                   	outs   dx,WORD PTR ds:[si]
     4bf:	6d                   	ins    WORD PTR es:[di],dx
     4c0:	31 dc                	xor    sp,bx
     4c2:	01 0c                	add    WORD PTR [si],cx
     4c4:	00 0c                	add    BYTE PTR [si],cl
     4c6:	54                   	push   sp
     4c7:	61                   	popa
     4c8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4cb:	41                   	inc    cx
     4cc:	44                   	inc    sp
     4cd:	47                   	inc    di
     4ce:	5f                   	pop    di
     4cf:	6f                   	outs   dx,WORD PTR ds:[si]
     4d0:	6c                   	ins    BYTE PTR es:[di],dx
     4d1:	64 e0 01             	fs loopne 0x4d5
     4d4:	0c 00                	or     al,0x0
     4d6:	0c 54                	or     al,0x54
     4d8:	61                   	popa
     4d9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4dc:	45                   	inc    bp
     4dd:	52                   	push   dx
     4de:	47                   	inc    di
     4df:	5f                   	pop    di
     4e0:	6f                   	outs   dx,WORD PTR ds:[si]
     4e1:	6c                   	ins    BYTE PTR es:[di],dx
     4e2:	64 e4 01             	fs in  al,0x1
     4e5:	0c 00                	or     al,0x0
     4e7:	0d 54 61             	or     ax,0x6154
     4ea:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4ed:	45                   	inc    bp
     4ee:	44                   	inc    sp
     4ef:	50                   	push   ax
     4f0:	31 5f 4f             	xor    WORD PTR [bx+0x4f],bx
     4f3:	6c                   	ins    BYTE PTR es:[di],dx
     4f4:	64 e8 01 0c          	fs call 0x10f9
     4f8:	00 0d                	add    BYTE PTR [di],cl
     4fa:	54                   	push   sp
     4fb:	61                   	popa
     4fc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4ff:	45                   	inc    bp
     500:	44                   	inc    sp
     501:	50                   	push   ax
     502:	32 5f 4f             	xor    bl,BYTE PTR [bx+0x4f]
     505:	6c                   	ins    BYTE PTR es:[di],dx
     506:	64 ec                	fs in  al,dx
     508:	01 0c                	add    WORD PTR [si],cx
     50a:	00 08                	add    BYTE PTR [bx+si],cl
     50c:	54                   	push   sp
     50d:	61                   	popa
     50e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     511:	41                   	inc    cx
     512:	44                   	inc    sp
     513:	47                   	inc    di
     514:	f0 01 0c             	lock add WORD PTR [si],cx
     517:	00 09                	add    BYTE PTR [bx+di],cl
     519:	54                   	push   sp
     51a:	61                   	popa
     51b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     51e:	45                   	inc    bp
     51f:	44                   	inc    sp
     520:	50                   	push   ax
     521:	31 f4                	xor    sp,si
     523:	01 0c                	add    WORD PTR [si],cx
     525:	00 09                	add    BYTE PTR [bx+di],cl
     527:	54                   	push   sp
     528:	61                   	popa
     529:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     52c:	45                   	inc    bp
     52d:	44                   	inc    sp
     52e:	50                   	push   ax
     52f:	32 f8                	xor    bh,al
     531:	01 0c                	add    WORD PTR [si],cx
     533:	00 08                	add    BYTE PTR [bx+si],cl
     535:	54                   	push   sp
     536:	61                   	popa
     537:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     53a:	45                   	inc    bp
     53b:	52                   	push   dx
     53c:	47                   	inc    di
     53d:	fc                   	cld
     53e:	01 0c                	add    WORD PTR [si],cx
     540:	00 09                	add    BYTE PTR [bx+di],cl
     542:	54                   	push   sp
     543:	61                   	popa
     544:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     547:	45                   	inc    bp
     548:	52                   	push   dx
     549:	50                   	push   ax
     54a:	31 00                	xor    WORD PTR [bx+si],ax
     54c:	02 0c                	add    cl,BYTE PTR [si]
     54e:	00 09                	add    BYTE PTR [bx+di],cl
     550:	54                   	push   sp
     551:	61                   	popa
     552:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     555:	45                   	inc    bp
     556:	52                   	push   dx
     557:	50                   	push   ax
     558:	32 04                	xor    al,BYTE PTR [si]
     55a:	02 10                	add    dl,BYTE PTR [bx+si]
     55c:	00 1e 54 61          	add    BYTE PTR ds:0x6154,bl
     560:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     563:	45                   	inc    bp
     564:	52                   	push   dx
     565:	47                   	inc    di
     566:	5f                   	pop    di
     567:	6f                   	outs   dx,WORD PTR ds:[si]
     568:	6c                   	ins    BYTE PTR es:[di],dx
     569:	64 43                	fs inc bx
     56b:	61                   	popa
     56c:	70 61                	jo     0x5cf
     56e:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
     571:	65 50                	gs push ax
     573:	72 6f                	jb     0x5e4
     575:	64 75 63             	fs jne 0x5db
     578:	74 69                	je     0x5e3
     57a:	76 65                	jbe    0x5e1
     57c:	08 02                	or     BYTE PTR [bp+si],al
     57e:	14 00                	adc    al,0x0
     580:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     583:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     586:	45                   	inc    bp
     587:	52                   	push   dx
     588:	47                   	inc    di
     589:	5f                   	pop    di
     58a:	6f                   	outs   dx,WORD PTR ds:[si]
     58b:	6c                   	ins    BYTE PTR es:[di],dx
     58c:	64 4e                	fs dec si
     58e:	6f                   	outs   dx,WORD PTR ds:[si]
     58f:	6d                   	ins    WORD PTR es:[di],dx
     590:	62 72 65             	bound  si,DWORD PTR [bp+si+0x65]
     593:	50                   	push   ax
     594:	72 6f                	jb     0x605
     596:	64 75 69             	fs jne 0x602
     599:	74 73                	je     0x60e
     59b:	0c 02                	or     al,0x2
     59d:	10 00                	adc    BYTE PTR [bx+si],al
     59f:	17                   	pop    ss
     5a0:	54                   	push   sp
     5a1:	61                   	popa
     5a2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5a5:	45                   	inc    bp
     5a6:	52                   	push   dx
     5a7:	47                   	inc    di
     5a8:	5f                   	pop    di
     5a9:	6f                   	outs   dx,WORD PTR ds:[si]
     5aa:	6c                   	ins    BYTE PTR es:[di],dx
     5ab:	64 56                	fs push si
     5ad:	61                   	popa
     5ae:	6c                   	ins    BYTE PTR es:[di],dx
     5af:	65 75 72             	gs jne 0x624
     5b2:	53                   	push   bx
     5b3:	74 6f                	je     0x624
     5b5:	63 6b 10             	arpl   WORD PTR [bp+di+0x10],bp
     5b8:	02 0c                	add    cl,BYTE PTR [si]
     5ba:	00 0d                	add    BYTE PTR [di],cl
     5bc:	54                   	push   sp
     5bd:	61                   	popa
     5be:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5c1:	45                   	inc    bp
     5c2:	52                   	push   dx
     5c3:	50                   	push   ax
     5c4:	31 5f 4f             	xor    WORD PTR [bx+0x4f],bx
     5c7:	6c                   	ins    BYTE PTR es:[di],dx
     5c8:	64 14 02             	fs adc al,0x2
     5cb:	0c 00                	or     al,0x0
     5cd:	0d 54 61             	or     ax,0x6154
     5d0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5d3:	45                   	inc    bp
     5d4:	52                   	push   dx
     5d5:	50                   	push   ax
     5d6:	32 5f 4f             	xor    bl,BYTE PTR [bx+0x4f]
     5d9:	6c                   	ins    BYTE PTR es:[di],dx
     5da:	64 18 02             	sbb    BYTE PTR fs:[bp+si],al
     5dd:	18 00                	sbb    BYTE PTR [bx+si],al
     5df:	11 44 61             	adc    WORD PTR [si+0x61],ax
     5e2:	74 61                	je     0x645
     5e4:	53                   	push   bx
     5e5:	6f                   	outs   dx,WORD PTR ds:[si]
     5e6:	75 72                	jne    0x65a
     5e8:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     5eb:	52                   	push   dx
     5ec:	47                   	inc    di
     5ed:	5f                   	pop    di
     5ee:	4f                   	dec    di
     5ef:	6c                   	ins    BYTE PTR es:[di],dx
     5f0:	64 1c 02             	fs sbb al,0x2
     5f3:	18 00                	sbb    BYTE PTR [bx+si],al
     5f5:	0d 44 61             	or     ax,0x6144
     5f8:	74 61                	je     0x65b
     5fa:	53                   	push   bx
     5fb:	6f                   	outs   dx,WORD PTR ds:[si]
     5fc:	75 72                	jne    0x670
     5fe:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     601:	52                   	push   dx
     602:	47                   	inc    di
     603:	20 02                	and    BYTE PTR [bp+si],al
     605:	18 00                	sbb    BYTE PTR [bx+si],al
     607:	0e                   	push   cs
     608:	44                   	inc    sp
     609:	61                   	popa
     60a:	74 61                	je     0x66d
     60c:	53                   	push   bx
     60d:	6f                   	outs   dx,WORD PTR ds:[si]
     60e:	75 72                	jne    0x682
     610:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     613:	44                   	inc    sp
     614:	50                   	push   ax
     615:	31 24                	xor    WORD PTR [si],sp
     617:	02 18                	add    bl,BYTE PTR [bx+si]
     619:	00 0e 44 61          	add    BYTE PTR ds:0x6144,cl
     61d:	74 61                	je     0x680
     61f:	53                   	push   bx
     620:	6f                   	outs   dx,WORD PTR ds:[si]
     621:	75 72                	jne    0x695
     623:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     626:	44                   	inc    sp
     627:	50                   	push   ax
     628:	32 28                	xor    ch,BYTE PTR [bx+si]
     62a:	02 18                	add    bl,BYTE PTR [bx+si]
     62c:	00 0e 44 61          	add    BYTE PTR ds:0x6144,cl
     630:	74 61                	je     0x693
     632:	53                   	push   bx
     633:	6f                   	outs   dx,WORD PTR ds:[si]
     634:	75 72                	jne    0x6a8
     636:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     639:	52                   	push   dx
     63a:	50                   	push   ax
     63b:	31 2c                	xor    WORD PTR [si],bp
     63d:	02 18                	add    bl,BYTE PTR [bx+si]
     63f:	00 0e 44 61          	add    BYTE PTR ds:0x6144,cl
     643:	74 61                	je     0x6a6
     645:	53                   	push   bx
     646:	6f                   	outs   dx,WORD PTR ds:[si]
     647:	75 72                	jne    0x6bb
     649:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     64c:	52                   	push   dx
     64d:	50                   	push   ax
     64e:	32 30                	xor    dh,BYTE PTR [bx+si]
     650:	02 10                	add    dl,BYTE PTR [bx+si]
     652:	00 13                	add    BYTE PTR [bp+di],dl
     654:	54                   	push   sp
     655:	61                   	popa
     656:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     659:	45                   	inc    bp
     65a:	44                   	inc    sp
     65b:	50                   	push   ax
     65c:	31 4d 61             	xor    WORD PTR [di+0x61],cx
     65f:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     662:	6e                   	outs   dx,BYTE PTR ds:[si]
     663:	65 73 50             	gs jae 0x6b6
     666:	63 34                	arpl   WORD PTR [si],si
     668:	02 10                	add    dl,BYTE PTR [bx+si]
     66a:	00 13                	add    BYTE PTR [bp+di],dl
     66c:	54                   	push   sp
     66d:	61                   	popa
     66e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     671:	45                   	inc    bp
     672:	44                   	inc    sp
     673:	50                   	push   ax
     674:	32 4d 61             	xor    cl,BYTE PTR [di+0x61]
     677:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     67a:	6e                   	outs   dx,BYTE PTR ds:[si]
     67b:	65 73 50             	gs jae 0x6ce
     67e:	43                   	inc    bx
     67f:	38 02                	cmp    BYTE PTR [bp+si],al
     681:	10 00                	adc    BYTE PTR [bx+si],al
     683:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
     686:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     689:	45                   	inc    bp
     68a:	44                   	inc    sp
     68b:	50                   	push   ax
     68c:	31 54 61             	xor    WORD PTR [si+0x61],dx
     68f:	75 78                	jne    0x709
     691:	55                   	push   bp
     692:	74 69                	je     0x6fd
     694:	6c                   	ins    BYTE PTR es:[di],dx
     695:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     69a:	6f                   	outs   dx,WORD PTR ds:[si]
     69b:	6e                   	outs   dx,BYTE PTR ds:[si]
     69c:	3c 02                	cmp    al,0x2
     69e:	10 00                	adc    BYTE PTR [bx+si],al
     6a0:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
     6a3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6a6:	45                   	inc    bp
     6a7:	44                   	inc    sp
     6a8:	50                   	push   ax
     6a9:	32 54 61             	xor    dl,BYTE PTR [si+0x61]
     6ac:	75 78                	jne    0x726
     6ae:	55                   	push   bp
     6af:	74 69                	je     0x71a
     6b1:	6c                   	ins    BYTE PTR es:[di],dx
     6b2:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     6b7:	6f                   	outs   dx,WORD PTR ds:[si]
     6b8:	6e                   	outs   dx,BYTE PTR ds:[si]
     6b9:	40                   	inc    ax
     6ba:	02 10                	add    dl,BYTE PTR [bx+si]
     6bc:	00 0b                	add    BYTE PTR [bp+di],cl
     6be:	54                   	push   sp
     6bf:	61                   	popa
     6c0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6c3:	45                   	inc    bp
     6c4:	52                   	push   dx
     6c5:	50                   	push   ax
     6c6:	31 43 41             	xor    WORD PTR [bp+di+0x41],ax
     6c9:	44                   	inc    sp
     6ca:	02 10                	add    dl,BYTE PTR [bx+si]
     6cc:	00 0b                	add    BYTE PTR [bp+di],cl
     6ce:	54                   	push   sp
     6cf:	61                   	popa
     6d0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6d3:	45                   	inc    bp
     6d4:	52                   	push   dx
     6d5:	50                   	push   ax
     6d6:	32 43 41             	xor    al,BYTE PTR [bp+di+0x41]
     6d9:	48                   	dec    ax
     6da:	02 08                	add    cl,BYTE PTR [bx+si]
     6dc:	00 08                	add    BYTE PTR [bx+si],cl
     6de:	50                   	push   ax
     6df:	65 72 69             	gs jb  0x74b
     6e2:	6f                   	outs   dx,WORD PTR ds:[si]
     6e3:	64 65 31 4c 02       	fs xor WORD PTR gs:[si+0x2],cx
     6e8:	08 00                	or     BYTE PTR [bx+si],al
     6ea:	0b 45 6e             	or     ax,WORD PTR [di+0x6e]
     6ed:	74 72                	je     0x761
     6ef:	65 70 72             	gs jo  0x764
     6f2:	69 73 65 31 50       	imul   si,WORD PTR [bp+di+0x65],0x5031
     6f7:	02 1c                	add    bl,BYTE PTR [si]
     6f9:	00 0c                	add    BYTE PTR [si],cl
     6fb:	50                   	push   ax
     6fc:	72 69                	jb     0x767
     6fe:	6e                   	outs   dx,BYTE PTR ds:[si]
     6ff:	74 44                	je     0x745
     701:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     706:	31 54 02             	xor    WORD PTR [si+0x2],dx
     709:	08 00                	or     BYTE PTR [bx+si],al
     70b:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
     70e:	31 58 02             	xor    WORD PTR [bx+si+0x2],bx
     711:	08 00                	or     BYTE PTR [bx+si],al
     713:	03 4e 32             	add    cx,WORD PTR [bp+0x32]
     716:	31 5c 02             	xor    WORD PTR [si+0x2],bx
     719:	08 00                	or     BYTE PTR [bx+si],al
     71b:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     71e:	31 60 02             	xor    WORD PTR [bx+si+0x2],sp
     721:	08 00                	or     BYTE PTR [bx+si],al
     723:	03 4e 34             	add    cx,WORD PTR [bp+0x34]
     726:	31 64 02             	xor    WORD PTR [si+0x2],sp
     729:	08 00                	or     BYTE PTR [bx+si],al
     72b:	03 4e 35             	add    cx,WORD PTR [bp+0x35]
     72e:	31 68 02             	xor    WORD PTR [bx+si+0x2],bp
     731:	08 00                	or     BYTE PTR [bx+si],al
     733:	03 4e 36             	add    cx,WORD PTR [bp+0x36]
     736:	31 6c 02             	xor    WORD PTR [si+0x2],bp
     739:	08 00                	or     BYTE PTR [bx+si],al
     73b:	03 4e 37             	add    cx,WORD PTR [bp+0x37]
     73e:	31 70 02             	xor    WORD PTR [bx+si+0x2],si
     741:	08 00                	or     BYTE PTR [bx+si],al
     743:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
     746:	31 74 02             	xor    WORD PTR [si+0x2],si
     749:	04 00                	add    al,0x0
     74b:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     74e:	6e                   	outs   dx,BYTE PTR ds:[si]
     74f:	65 6c                	gs ins BYTE PTR es:[di],dx
     751:	4c                   	dec    sp
     752:	4f                   	dec    di
     753:	55                   	push   bp
     754:	50                   	push   ax
     755:	45                   	inc    bp
     756:	78 02                	js     0x75a
     758:	10 00                	adc    BYTE PTR [bx+si],al
     75a:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     75d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     760:	45                   	inc    bp
     761:	52                   	push   dx
     762:	47                   	inc    di
     763:	43                   	inc    bx
     764:	61                   	popa
     765:	70 61                	jo     0x7c8
     767:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
     76a:	65 50                	gs push ax
     76c:	72 6f                	jb     0x7dd
     76e:	64 75 63             	fs jne 0x7d4
     771:	74 69                	je     0x7dc
     773:	76 65                	jbe    0x7da
     775:	7c 02                	jl     0x779
     777:	14 00                	adc    al,0x0
     779:	16                   	push   ss
     77a:	54                   	push   sp
     77b:	61                   	popa
     77c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     77f:	45                   	inc    bp
     780:	52                   	push   dx
     781:	47                   	inc    di
     782:	4e                   	dec    si
     783:	6f                   	outs   dx,WORD PTR ds:[si]
     784:	6d                   	ins    WORD PTR es:[di],dx
     785:	62 72 65             	bound  si,DWORD PTR [bp+si+0x65]
     788:	50                   	push   ax
     789:	72 6f                	jb     0x7fa
     78b:	64 75 69             	fs jne 0x7f7
     78e:	74 73                	je     0x803
     790:	80 02 10             	add    BYTE PTR [bp+si],0x10
     793:	00 13                	add    BYTE PTR [bp+di],dl
     795:	54                   	push   sp
     796:	61                   	popa
     797:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     79a:	45                   	inc    bp
     79b:	52                   	push   dx
     79c:	47                   	inc    di
     79d:	56                   	push   si
     79e:	61                   	popa
     79f:	6c                   	ins    BYTE PTR es:[di],dx
     7a0:	65 75 72             	gs jne 0x815
     7a3:	53                   	push   bx
     7a4:	74 6f                	je     0x815
     7a6:	63 6b 84             	arpl   WORD PTR [bp+di-0x7c],bp
     7a9:	02 18                	add    bl,BYTE PTR [bx+si]
     7ab:	00 12                	add    BYTE PTR [bp+si],dl
     7ad:	44                   	inc    sp
     7ae:	61                   	popa
     7af:	74 61                	je     0x812
     7b1:	53                   	push   bx
     7b2:	6f                   	outs   dx,WORD PTR ds:[si]
     7b3:	75 72                	jne    0x827
     7b5:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     7b8:	52                   	push   dx
     7b9:	50                   	push   ax
     7ba:	31 5f 4f             	xor    WORD PTR [bx+0x4f],bx
     7bd:	6c                   	ins    BYTE PTR es:[di],dx
     7be:	64 88 02             	mov    BYTE PTR fs:[bp+si],al
     7c1:	18 00                	sbb    BYTE PTR [bx+si],al
     7c3:	12 44 61             	adc    al,BYTE PTR [si+0x61]
     7c6:	74 61                	je     0x829
     7c8:	53                   	push   bx
     7c9:	6f                   	outs   dx,WORD PTR ds:[si]
     7ca:	75 72                	jne    0x83e
     7cc:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     7cf:	52                   	push   dx
     7d0:	50                   	push   ax
     7d1:	32 5f 4f             	xor    bl,BYTE PTR [bx+0x4f]
     7d4:	4c                   	dec    sp
     7d5:	64 8c 02             	mov    WORD PTR fs:[bp+si],es
     7d8:	14 00                	adc    al,0x0
     7da:	15 54 61             	adc    ax,0x6154
     7dd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7e0:	45                   	inc    bp
     7e1:	52                   	push   dx
     7e2:	47                   	inc    di
     7e3:	5f                   	pop    di
     7e4:	6f                   	outs   dx,WORD PTR ds:[si]
     7e5:	6c                   	ins    BYTE PTR es:[di],dx
     7e6:	64 50                	fs push ax
     7e8:	65 72 69             	gs jb  0x854
     7eb:	6f                   	outs   dx,WORD PTR ds:[si]
     7ec:	64 65 4e             	fs gs dec si
     7ef:	6f                   	outs   dx,WORD PTR ds:[si]
     7f0:	90                   	nop
     7f1:	02 14                	add    dl,BYTE PTR [si]
     7f3:	00 18                	add    BYTE PTR [bx+si],bl
     7f5:	54                   	push   sp
     7f6:	61                   	popa
     7f7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7fa:	45                   	inc    bp
     7fb:	52                   	push   dx
     7fc:	47                   	inc    di
     7fd:	5f                   	pop    di
     7fe:	6f                   	outs   dx,WORD PTR ds:[si]
     7ff:	6c                   	ins    BYTE PTR es:[di],dx
     800:	64 45                	fs inc bp
     802:	6e                   	outs   dx,BYTE PTR ds:[si]
     803:	74 72                	je     0x877
     805:	65 70 72             	gs jo  0x87a
     808:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     80d:	94                   	xchg   sp,ax
     80e:	02 20                	add    ah,BYTE PTR [bx+si]
     810:	00 19                	add    BYTE PTR [bx+di],bl
     812:	54                   	push   sp
     813:	61                   	popa
     814:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     817:	45                   	inc    bp
     818:	52                   	push   dx
     819:	47                   	inc    di
     81a:	5f                   	pop    di
     81b:	6f                   	outs   dx,WORD PTR ds:[si]
     81c:	6c                   	ins    BYTE PTR es:[di],dx
     81d:	64 43                	fs inc bx
     81f:	61                   	popa
     820:	70 69                	jo     0x88b
     822:	74 61                	je     0x885
     824:	6c                   	ins    BYTE PTR es:[di],dx
     825:	53                   	push   bx
     826:	6f                   	outs   dx,WORD PTR ds:[si]
     827:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     82a:	6c                   	ins    BYTE PTR es:[di],dx
     82b:	98                   	cbw
     82c:	02 20                	add    ah,BYTE PTR [bx+si]
     82e:	00 14                	add    BYTE PTR [si],dl
     830:	54                   	push   sp
     831:	61                   	popa
     832:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     835:	45                   	inc    bp
     836:	52                   	push   dx
     837:	47                   	inc    di
     838:	5f                   	pop    di
     839:	6f                   	outs   dx,WORD PTR ds:[si]
     83a:	6c                   	ins    BYTE PTR es:[di],dx
     83b:	64 52                	fs push dx
     83d:	65 73 65             	gs jae 0x8a5
     840:	72 76                	jb     0x8b8
     842:	65 73 9c             	gs jae 0x7e1
     845:	02 20                	add    ah,BYTE PTR [bx+si]
     847:	00 17                	add    BYTE PTR [bx],dl
     849:	54                   	push   sp
     84a:	61                   	popa
     84b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     84e:	45                   	inc    bp
     84f:	52                   	push   dx
     850:	47                   	inc    di
     851:	5f                   	pop    di
     852:	6f                   	outs   dx,WORD PTR ds:[si]
     853:	6c                   	ins    BYTE PTR es:[di],dx
     854:	64 52                	fs push dx
     856:	65 73 75             	gs jae 0x8ce
     859:	6c                   	ins    BYTE PTR es:[di],dx
     85a:	74 61                	je     0x8bd
     85c:	74 4e                	je     0x8ac
     85e:	65 74 a0             	gs je  0x801
     861:	02 20                	add    ah,BYTE PTR [bx+si]
     863:	00 1a                	add    BYTE PTR [bp+si],bl
     865:	54                   	push   sp
     866:	61                   	popa
     867:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     86a:	45                   	inc    bp
     86b:	52                   	push   dx
     86c:	47                   	inc    di
     86d:	5f                   	pop    di
     86e:	6f                   	outs   dx,WORD PTR ds:[si]
     86f:	6c                   	ins    BYTE PTR es:[di],dx
     870:	64 53                	fs push bx
     872:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     877:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
     87c:	74 74                	je     0x8f2
     87e:	65 a4                	movs   BYTE PTR es:[di],BYTE PTR gs:[si]
     880:	02 20                	add    ah,BYTE PTR [bx+si]
     882:	00 0f                	add    BYTE PTR [bx],cl
     884:	54                   	push   sp
     885:	61                   	popa
     886:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     889:	45                   	inc    bp
     88a:	52                   	push   dx
     88b:	47                   	inc    di
     88c:	5f                   	pop    di
     88d:	6f                   	outs   dx,WORD PTR ds:[si]
     88e:	6c                   	ins    BYTE PTR es:[di],dx
     88f:	64 43                	fs inc bx
     891:	41                   	inc    cx
     892:	46                   	inc    si
     893:	a8 02                	test   al,0x2
     895:	20 00                	and    BYTE PTR [bx+si],al
     897:	11 54 61             	adc    WORD PTR [si+0x61],dx
     89a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     89d:	45                   	inc    bp
     89e:	52                   	push   dx
     89f:	47                   	inc    di
     8a0:	5f                   	pop    di
     8a1:	6f                   	outs   dx,WORD PTR ds:[si]
     8a2:	6c                   	ins    BYTE PTR es:[di],dx
     8a3:	64 49                	fs dec cx
     8a5:	6d                   	ins    WORD PTR es:[di],dx
     8a6:	70 6f                	jo     0x917
     8a8:	74 ac                	je     0x856
     8aa:	02 20                	add    ah,BYTE PTR [bx+si]
     8ac:	00 0f                	add    BYTE PTR [bx],cl
     8ae:	54                   	push   sp
     8af:	61                   	popa
     8b0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8b3:	45                   	inc    bp
     8b4:	52                   	push   dx
     8b5:	47                   	inc    di
     8b6:	5f                   	pop    di
     8b7:	6f                   	outs   dx,WORD PTR ds:[si]
     8b8:	6c                   	ins    BYTE PTR es:[di],dx
     8b9:	64 49                	fs dec cx
     8bb:	46                   	inc    si
     8bc:	41                   	inc    cx
     8bd:	b0 02                	mov    al,0x2
     8bf:	20 00                	and    BYTE PTR [bx+si],al
     8c1:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     8c4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8c7:	45                   	inc    bp
     8c8:	52                   	push   dx
     8c9:	47                   	inc    di
     8ca:	5f                   	pop    di
     8cb:	6f                   	outs   dx,WORD PTR ds:[si]
     8cc:	6c                   	ins    BYTE PTR es:[di],dx
     8cd:	64 43                	fs inc bx
     8cf:	6c                   	ins    BYTE PTR es:[di],dx
     8d0:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
     8d5:	b4 02                	mov    ah,0x2
     8d7:	20 00                	and    BYTE PTR [bx+si],al
     8d9:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
     8dc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8df:	45                   	inc    bp
     8e0:	52                   	push   dx
     8e1:	47                   	inc    di
     8e2:	5f                   	pop    di
     8e3:	6f                   	outs   dx,WORD PTR ds:[si]
     8e4:	6c                   	ins    BYTE PTR es:[di],dx
     8e5:	64 46                	fs inc si
     8e7:	6f                   	outs   dx,WORD PTR ds:[si]
     8e8:	75 72                	jne    0x95c
     8ea:	6e                   	outs   dx,BYTE PTR ds:[si]
     8eb:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
     8f0:	72 73                	jb     0x965
     8f2:	b8 02 20             	mov    ax,0x2002
     8f5:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     8f9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8fc:	45                   	inc    bp
     8fd:	52                   	push   dx
     8fe:	47                   	inc    di
     8ff:	5f                   	pop    di
     900:	6f                   	outs   dx,WORD PTR ds:[si]
     901:	6c                   	ins    BYTE PTR es:[di],dx
     902:	64 54                	fs push sp
     904:	72 65                	jb     0x96b
     906:	73 6f                	jae    0x977
     908:	72 65                	jb     0x96f
     90a:	72 69                	jb     0x975
     90c:	65 bc 02 20          	gs mov sp,0x2002
     910:	00 13                	add    BYTE PTR [bp+di],dl
     912:	54                   	push   sp
     913:	61                   	popa
     914:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     917:	45                   	inc    bp
     918:	52                   	push   dx
     919:	47                   	inc    di
     91a:	5f                   	pop    di
     91b:	6f                   	outs   dx,WORD PTR ds:[si]
     91c:	6c                   	ins    BYTE PTR es:[di],dx
     91d:	64 45                	fs inc bp
     91f:	6d                   	ins    WORD PTR es:[di],dx
     920:	70 72                	jo     0x994
     922:	75 6e                	jne    0x992
     924:	74 c0                	je     0x8e6
     926:	02 20                	add    ah,BYTE PTR [bx+si]
     928:	00 19                	add    BYTE PTR [bx+di],bl
     92a:	54                   	push   sp
     92b:	61                   	popa
     92c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     92f:	45                   	inc    bp
     930:	52                   	push   dx
     931:	47                   	inc    di
     932:	5f                   	pop    di
     933:	6f                   	outs   dx,WORD PTR ds:[si]
     934:	6c                   	ins    BYTE PTR es:[di],dx
     935:	64 44                	fs inc sp
     937:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     93b:	76 65                	jbe    0x9a2
     93d:	72 74                	jb     0x9b3
     93f:	41                   	inc    cx
     940:	75 74                	jne    0x9b6
     942:	6f                   	outs   dx,WORD PTR ds:[si]
     943:	c4 02                	les    ax,DWORD PTR [bp+si]
     945:	20 00                	and    BYTE PTR [bx+si],al
     947:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     94a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     94d:	45                   	inc    bp
     94e:	52                   	push   dx
     94f:	47                   	inc    di
     950:	5f                   	pop    di
     951:	6f                   	outs   dx,WORD PTR ds:[si]
     952:	6c                   	ins    BYTE PTR es:[di],dx
     953:	64 44                	fs inc sp
     955:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     959:	76 65                	jbe    0x9c0
     95b:	72 74                	jb     0x9d1
     95d:	4e                   	dec    si
     95e:	41                   	inc    cx
     95f:	75 74                	jne    0x9d5
     961:	6f                   	outs   dx,WORD PTR ds:[si]
     962:	c8 02 20 00          	enter  0x2002,0x0
     966:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     969:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     96c:	45                   	inc    bp
     96d:	52                   	push   dx
     96e:	47                   	inc    di
     96f:	5f                   	pop    di
     970:	6f                   	outs   dx,WORD PTR ds:[si]
     971:	6c                   	ins    BYTE PTR es:[di],dx
     972:	64 41                	fs inc cx
     974:	6d                   	ins    WORD PTR es:[di],dx
     975:	6f                   	outs   dx,WORD PTR ds:[si]
     976:	72 74                	jb     0x9ec
     978:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     97d:	65 6e                	outs   dx,BYTE PTR gs:[si]
     97f:	74 cc                	je     0x94d
     981:	02 20                	add    ah,BYTE PTR [bx+si]
     983:	00 14                	add    BYTE PTR [si],dl
     985:	54                   	push   sp
     986:	61                   	popa
     987:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     98a:	45                   	inc    bp
     98b:	52                   	push   dx
     98c:	47                   	inc    di
     98d:	5f                   	pop    di
     98e:	6f                   	outs   dx,WORD PTR ds:[si]
     98f:	6c                   	ins    BYTE PTR es:[di],dx
     990:	64 43                	fs inc bx
     992:	65 73 73             	gs jae 0xa08
     995:	69 6f 6e 73 d0       	imul   bp,WORD PTR [bx+0x6e],0xd073
     99a:	02 14                	add    dl,BYTE PTR [si]
     99c:	00 14                	add    BYTE PTR [si],dl
     99e:	54                   	push   sp
     99f:	61                   	popa
     9a0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9a3:	45                   	inc    bp
     9a4:	52                   	push   dx
     9a5:	47                   	inc    di
     9a6:	5f                   	pop    di
     9a7:	6f                   	outs   dx,WORD PTR ds:[si]
     9a8:	6c                   	ins    BYTE PTR es:[di],dx
     9a9:	64 4d                	fs dec bp
     9ab:	61                   	popa
     9ac:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     9af:	6e                   	outs   dx,BYTE PTR ds:[si]
     9b0:	65 73 d4             	gs jae 0x987
     9b3:	02 20                	add    ah,BYTE PTR [bx+si]
     9b5:	00 21                	add    BYTE PTR [bx+di],ah
     9b7:	54                   	push   sp
     9b8:	61                   	popa
     9b9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9bc:	45                   	inc    bp
     9bd:	52                   	push   dx
     9be:	47                   	inc    di
     9bf:	5f                   	pop    di
     9c0:	6f                   	outs   dx,WORD PTR ds:[si]
     9c1:	6c                   	ins    BYTE PTR es:[di],dx
     9c2:	64 49                	fs dec cx
     9c4:	6d                   	ins    WORD PTR es:[di],dx
     9c5:	6d                   	ins    WORD PTR es:[di],dx
     9c6:	6f                   	outs   dx,WORD PTR ds:[si]
     9c7:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     9ca:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     9cf:	6f                   	outs   dx,WORD PTR ds:[si]
     9d0:	6e                   	outs   dx,BYTE PTR ds:[si]
     9d1:	73 42                	jae    0xa15
     9d3:	72 75                	jb     0xa4a
     9d5:	74 65                	je     0xa3c
     9d7:	73 d8                	jae    0x9b1
     9d9:	02 20                	add    ah,BYTE PTR [bx+si]
     9db:	00 20                	add    BYTE PTR [bx+si],ah
     9dd:	54                   	push   sp
     9de:	61                   	popa
     9df:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9e2:	45                   	inc    bp
     9e3:	52                   	push   dx
     9e4:	47                   	inc    di
     9e5:	5f                   	pop    di
     9e6:	6f                   	outs   dx,WORD PTR ds:[si]
     9e7:	6c                   	ins    BYTE PTR es:[di],dx
     9e8:	64 43                	fs inc bx
     9ea:	6f                   	outs   dx,WORD PTR ds:[si]
     9eb:	75 74                	jne    0xa61
     9ed:	73 46                	jae    0xa35
     9ef:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
     9f4:	72 6f                	jb     0xa65
     9f6:	64 75 63             	fs jne 0xa5c
     9f9:	74 69                	je     0xa64
     9fb:	6f                   	outs   dx,WORD PTR ds:[si]
     9fc:	6e                   	outs   dx,BYTE PTR ds:[si]
     9fd:	dc 02                	fadd   QWORD PTR [bp+si]
     9ff:	14 00                	adc    al,0x0
     a01:	16                   	push   ss
     a02:	54                   	push   sp
     a03:	61                   	popa
     a04:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a07:	45                   	inc    bp
     a08:	52                   	push   dx
     a09:	47                   	inc    di
     a0a:	5f                   	pop    di
     a0b:	6f                   	outs   dx,WORD PTR ds:[si]
     a0c:	6c                   	ins    BYTE PTR es:[di],dx
     a0d:	64 50                	fs push ax
     a0f:	72 6f                	jb     0xa80
     a11:	64 75 63             	fs jne 0xa77
     a14:	74 69                	je     0xa7f
     a16:	66 73 e0             	data32 jae 0x9f9
     a19:	02 14                	add    dl,BYTE PTR [si]
     a1b:	00 14                	add    BYTE PTR [si],dl
     a1d:	54                   	push   sp
     a1e:	61                   	popa
     a1f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a22:	45                   	inc    bp
     a23:	52                   	push   dx
     a24:	47                   	inc    di
     a25:	5f                   	pop    di
     a26:	6f                   	outs   dx,WORD PTR ds:[si]
     a27:	6c                   	ins    BYTE PTR es:[di],dx
     a28:	64 56                	fs push si
     a2a:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a2c:	64 65 75 72          	fs gs jne 0xaa2
     a30:	73 e4                	jae    0xa16
     a32:	02 14                	add    dl,BYTE PTR [si]
     a34:	00 12                	add    BYTE PTR [bp+si],dl
     a36:	54                   	push   sp
     a37:	61                   	popa
     a38:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a3b:	45                   	inc    bp
     a3c:	52                   	push   dx
     a3d:	47                   	inc    di
     a3e:	5f                   	pop    di
     a3f:	6f                   	outs   dx,WORD PTR ds:[si]
     a40:	6c                   	ins    BYTE PTR es:[di],dx
     a41:	64 43                	fs inc bx
     a43:	61                   	popa
     a44:	64 72 65             	fs jb  0xaac
     a47:	73 e8                	jae    0xa31
     a49:	02 20                	add    ah,BYTE PTR [bx+si]
     a4b:	00 18                	add    BYTE PTR [bx+si],bl
     a4d:	54                   	push   sp
     a4e:	61                   	popa
     a4f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a52:	45                   	inc    bp
     a53:	52                   	push   dx
     a54:	47                   	inc    di
     a55:	5f                   	pop    di
     a56:	6f                   	outs   dx,WORD PTR ds:[si]
     a57:	6c                   	ins    BYTE PTR es:[di],dx
     a58:	64 43                	fs inc bx
     a5a:	6f                   	outs   dx,WORD PTR ds:[si]
     a5b:	75 74                	jne    0xad1
     a5d:	45                   	inc    bp
     a5e:	6d                   	ins    WORD PTR es:[di],dx
     a5f:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
     a62:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     a65:	ec                   	in     al,dx
     a66:	02 20                	add    ah,BYTE PTR [bx+si]
     a68:	00 18                	add    BYTE PTR [bx+si],bl
     a6a:	54                   	push   sp
     a6b:	61                   	popa
     a6c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a6f:	45                   	inc    bp
     a70:	52                   	push   dx
     a71:	47                   	inc    di
     a72:	5f                   	pop    di
     a73:	6f                   	outs   dx,WORD PTR ds:[si]
     a74:	6c                   	ins    BYTE PTR es:[di],dx
     a75:	64 43                	fs inc bx
     a77:	6f                   	outs   dx,WORD PTR ds:[si]
     a78:	75 74                	jne    0xaee
     a7a:	4c                   	dec    sp
     a7b:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
     a80:	69 65 f0 02 20       	imul   sp,WORD PTR [di-0x10],0x2002
     a85:	00 19                	add    BYTE PTR [bx+di],bl
     a87:	54                   	push   sp
     a88:	61                   	popa
     a89:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a8c:	45                   	inc    bp
     a8d:	52                   	push   dx
     a8e:	47                   	inc    di
     a8f:	5f                   	pop    di
     a90:	6f                   	outs   dx,WORD PTR ds:[si]
     a91:	6c                   	ins    BYTE PTR es:[di],dx
     a92:	64 43                	fs inc bx
     a94:	6f                   	outs   dx,WORD PTR ds:[si]
     a95:	75 74                	jne    0xb0b
     a97:	46                   	inc    si
     a98:	6f                   	outs   dx,WORD PTR ds:[si]
     a99:	72 6d                	jb     0xb08
     a9b:	61                   	popa
     a9c:	74 69                	je     0xb07
     a9e:	6f                   	outs   dx,WORD PTR ds:[si]
     a9f:	6e                   	outs   dx,BYTE PTR ds:[si]
     aa0:	f4                   	hlt
     aa1:	02 20                	add    ah,BYTE PTR [bx+si]
     aa3:	00 19                	add    BYTE PTR [bx+di],bl
     aa5:	54                   	push   sp
     aa6:	61                   	popa
     aa7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     aaa:	45                   	inc    bp
     aab:	52                   	push   dx
     aac:	47                   	inc    di
     aad:	5f                   	pop    di
     aae:	6f                   	outs   dx,WORD PTR ds:[si]
     aaf:	6c                   	ins    BYTE PTR es:[di],dx
     ab0:	64 44                	fs inc sp
     ab2:	69 73 74 72 69       	imul   si,WORD PTR [bp+di+0x74],0x6972
     ab7:	62 75 74             	bound  si,DWORD PTR [di+0x74]
     aba:	69 6f 6e 73 f8       	imul   bp,WORD PTR [bx+0x6e],0xf873
     abf:	02 14                	add    dl,BYTE PTR [si]
     ac1:	00 13                	add    BYTE PTR [bp+di],dl
     ac3:	54                   	push   sp
     ac4:	61                   	popa
     ac5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ac8:	45                   	inc    bp
     ac9:	52                   	push   dx
     aca:	47                   	inc    di
     acb:	5f                   	pop    di
     acc:	6f                   	outs   dx,WORD PTR ds:[si]
     acd:	6c                   	ins    BYTE PTR es:[di],dx
     ace:	64 53                	fs push bx
     ad0:	70 65                	jo     0xb37
     ad2:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     ad5:	6c                   	ins    BYTE PTR es:[di],dx
     ad6:	fc                   	cld
     ad7:	02 14                	add    dl,BYTE PTR [si]
     ad9:	00 12                	add    BYTE PTR [bp+si],dl
     adb:	54                   	push   sp
     adc:	61                   	popa
     add:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ae0:	45                   	inc    bp
     ae1:	44                   	inc    sp
     ae2:	50                   	push   ax
     ae3:	31 50 65             	xor    WORD PTR [bx+si+0x65],dx
     ae6:	72 69                	jb     0xb51
     ae8:	6f                   	outs   dx,WORD PTR ds:[si]
     ae9:	64 65 4e             	fs gs dec si
     aec:	6f                   	outs   dx,WORD PTR ds:[si]
     aed:	00 03                	add    BYTE PTR [bp+di],al
     aef:	14 00                	adc    al,0x0
     af1:	15 54 61             	adc    ax,0x6154
     af4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     af7:	45                   	inc    bp
     af8:	44                   	inc    sp
     af9:	50                   	push   ax
     afa:	31 45 6e             	xor    WORD PTR [di+0x6e],ax
     afd:	74 72                	je     0xb71
     aff:	65 70 72             	gs jo  0xb74
     b02:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     b07:	04 03                	add    al,0x3
     b09:	14 00                	adc    al,0x0
     b0b:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     b0e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b11:	45                   	inc    bp
     b12:	44                   	inc    sp
     b13:	50                   	push   ax
     b14:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     b17:	6f                   	outs   dx,WORD PTR ds:[si]
     b18:	64 75 69             	fs jne 0xb84
     b1b:	74 4e                	je     0xb6b
     b1d:	6f                   	outs   dx,WORD PTR ds:[si]
     b1e:	08 03                	or     BYTE PTR [bp+di],al
     b20:	14 00                	adc    al,0x0
     b22:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     b25:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b28:	45                   	inc    bp
     b29:	44                   	inc    sp
     b2a:	50                   	push   ax
     b2b:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     b2e:	6f                   	outs   dx,WORD PTR ds:[si]
     b2f:	64 75 63             	fs jne 0xb95
     b32:	74 69                	je     0xb9d
     b34:	6f                   	outs   dx,WORD PTR ds:[si]
     b35:	6e                   	outs   dx,BYTE PTR ds:[si]
     b36:	0c 03                	or     al,0x3
     b38:	14 00                	adc    al,0x0
     b3a:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     b3d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b40:	45                   	inc    bp
     b41:	44                   	inc    sp
     b42:	50                   	push   ax
     b43:	31 4d 61             	xor    WORD PTR [di+0x61],cx
     b46:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     b49:	6e                   	outs   dx,BYTE PTR ds:[si]
     b4a:	65 73 41             	gs jae 0xb8e
     b4d:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
     b53:	65 73 10             	gs jae 0xb66
     b56:	03 14                	add    dx,WORD PTR [si]
     b58:	00 1b                	add    BYTE PTR [bp+di],bl
     b5a:	54                   	push   sp
     b5b:	61                   	popa
     b5c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b5f:	45                   	inc    bp
     b60:	44                   	inc    sp
     b61:	50                   	push   ax
     b62:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     b65:	6f                   	outs   dx,WORD PTR ds:[si]
     b66:	64 75 63             	fs jne 0xbcc
     b69:	74 69                	je     0xbd4
     b6b:	66 73 41             	data32 jae 0xbaf
     b6e:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
     b74:	73 14                	jae    0xb8a
     b76:	03 20                	add    sp,WORD PTR [bx+si]
     b78:	00 18                	add    BYTE PTR [bx+si],bl
     b7a:	54                   	push   sp
     b7b:	61                   	popa
     b7c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b7f:	45                   	inc    bp
     b80:	44                   	inc    sp
     b81:	50                   	push   ax
     b82:	31 44 65             	xor    WORD PTR [si+0x65],ax
     b85:	70 65                	jo     0xbec
     b87:	6e                   	outs   dx,BYTE PTR ds:[si]
     b88:	73 65                	jae    0xbef
     b8a:	73 51                	jae    0xbdd
     b8c:	75 61                	jne    0xbef
     b8e:	6c                   	ins    BYTE PTR es:[di],dx
     b8f:	69 74 65 18 03       	imul   si,WORD PTR [si+0x65],0x318
     b94:	20 00                	and    BYTE PTR [bx+si],al
     b96:	0d 54 61             	or     ax,0x6154
     b99:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b9c:	45                   	inc    bp
     b9d:	44                   	inc    sp
     b9e:	50                   	push   ax
     b9f:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     ba2:	69 78 1c 03 20       	imul   di,WORD PTR [bx+si+0x1c],0x2003
     ba7:	00 12                	add    BYTE PTR [bp+si],dl
     ba9:	54                   	push   sp
     baa:	61                   	popa
     bab:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bae:	45                   	inc    bp
     baf:	44                   	inc    sp
     bb0:	50                   	push   ax
     bb1:	31 50 75             	xor    WORD PTR [bx+si+0x75],dx
     bb4:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
     bb7:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
     bba:	65 20 03             	and    BYTE PTR gs:[bp+di],al
     bbd:	20 00                	and    BYTE PTR [bx+si],al
     bbf:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     bc2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bc5:	45                   	inc    bp
     bc6:	44                   	inc    sp
     bc7:	50                   	push   ax
     bc8:	31 41 63             	xor    WORD PTR [bx+di+0x63],ax
     bcb:	74 69                	je     0xc36
     bcd:	6f                   	outs   dx,WORD PTR ds:[si]
     bce:	6e                   	outs   dx,BYTE PTR ds:[si]
     bcf:	43                   	inc    bx
     bd0:	6f                   	outs   dx,WORD PTR ds:[si]
     bd1:	6d                   	ins    WORD PTR es:[di],dx
     bd2:	6d                   	ins    WORD PTR es:[di],dx
     bd3:	65 72 63             	gs jb  0xc39
     bd6:	69 61 6c 65 24       	imul   sp,WORD PTR [bx+di+0x6c],0x2465
     bdb:	03 14                	add    dx,WORD PTR [si]
     bdd:	00 19                	add    BYTE PTR [bx+di],bl
     bdf:	54                   	push   sp
     be0:	61                   	popa
     be1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     be4:	45                   	inc    bp
     be5:	44                   	inc    sp
     be6:	50                   	push   ax
     be7:	31 56 65             	xor    WORD PTR [bp+0x65],dx
     bea:	6e                   	outs   dx,BYTE PTR ds:[si]
     beb:	64 65 75 72          	fs gs jne 0xc61
     bef:	73 41                	jae    0xc32
     bf1:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
     bf7:	73 28                	jae    0xc21
     bf9:	03 14                	add    dx,WORD PTR [si]
     bfb:	00 1a                	add    BYTE PTR [bp+si],bl
     bfd:	54                   	push   sp
     bfe:	61                   	popa
     bff:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c02:	45                   	inc    bp
     c03:	44                   	inc    sp
     c04:	50                   	push   ax
     c05:	31 44 75             	xor    WORD PTR [si+0x75],ax
     c08:	72 65                	jb     0xc6f
     c0a:	65 43                	gs inc bx
     c0c:	72 65                	jb     0xc73
     c0e:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
     c14:	65 6e                	outs   dx,BYTE PTR gs:[si]
     c16:	74 2c                	je     0xc44
     c18:	03 14                	add    dx,WORD PTR [si]
     c1a:	00 14                	add    BYTE PTR [si],dl
     c1c:	54                   	push   sp
     c1d:	61                   	popa
     c1e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c21:	45                   	inc    bp
     c22:	44                   	inc    sp
     c23:	50                   	push   ax
     c24:	31 4c 69             	xor    WORD PTR [si+0x69],cx
     c27:	71 75                	jno    0xc9e
     c29:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
     c2e:	6f                   	outs   dx,WORD PTR ds:[si]
     c2f:	6e                   	outs   dx,BYTE PTR ds:[si]
     c30:	30 03                	xor    BYTE PTR [bp+di],al
     c32:	14 00                	adc    al,0x0
     c34:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
     c37:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c3a:	45                   	inc    bp
     c3b:	44                   	inc    sp
     c3c:	50                   	push   ax
     c3d:	31 53 6f             	xor    WORD PTR [bp+di+0x6f],dx
     c40:	75 6d                	jne    0xcaf
     c42:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
     c47:	6e                   	outs   dx,BYTE PTR ds:[si]
     c48:	51                   	push   cx
     c49:	75 61                	jne    0xcac
     c4b:	6e                   	outs   dx,BYTE PTR ds:[si]
     c4c:	74 69                	je     0xcb7
     c4e:	74 65                	je     0xcb5
     c50:	34 03                	xor    al,0x3
     c52:	20 00                	and    BYTE PTR [bx+si],al
     c54:	17                   	pop    ss
     c55:	54                   	push   sp
     c56:	61                   	popa
     c57:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c5a:	45                   	inc    bp
     c5b:	44                   	inc    sp
     c5c:	50                   	push   ax
     c5d:	31 53 6f             	xor    WORD PTR [bp+di+0x6f],dx
     c60:	75 6d                	jne    0xccf
     c62:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
     c67:	6e                   	outs   dx,BYTE PTR ds:[si]
     c68:	50                   	push   ax
     c69:	72 69                	jb     0xcd4
     c6b:	78 38                	js     0xca5
     c6d:	03 14                	add    dx,WORD PTR [si]
     c6f:	00 10                	add    BYTE PTR [bx+si],dl
     c71:	54                   	push   sp
     c72:	61                   	popa
     c73:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c76:	45                   	inc    bp
     c77:	44                   	inc    sp
     c78:	50                   	push   ax
     c79:	31 53 70             	xor    WORD PTR [bp+di+0x70],dx
     c7c:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     c80:	6c                   	ins    BYTE PTR es:[di],dx
     c81:	3c 03                	cmp    al,0x3
     c83:	14 00                	adc    al,0x0
     c85:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     c88:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c8b:	45                   	inc    bp
     c8c:	44                   	inc    sp
     c8d:	50                   	push   ax
     c8e:	32 50 65             	xor    dl,BYTE PTR [bx+si+0x65]
     c91:	72 69                	jb     0xcfc
     c93:	6f                   	outs   dx,WORD PTR ds:[si]
     c94:	64 65 4e             	fs gs dec si
     c97:	6f                   	outs   dx,WORD PTR ds:[si]
     c98:	40                   	inc    ax
     c99:	03 14                	add    dx,WORD PTR [si]
     c9b:	00 15                	add    BYTE PTR [di],dl
     c9d:	54                   	push   sp
     c9e:	61                   	popa
     c9f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ca2:	45                   	inc    bp
     ca3:	44                   	inc    sp
     ca4:	50                   	push   ax
     ca5:	32 45 6e             	xor    al,BYTE PTR [di+0x6e]
     ca8:	74 72                	je     0xd1c
     caa:	65 70 72             	gs jo  0xd1f
     cad:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     cb2:	44                   	inc    sp
     cb3:	03 14                	add    dx,WORD PTR [si]
     cb5:	00 12                	add    BYTE PTR [bp+si],dl
     cb7:	54                   	push   sp
     cb8:	61                   	popa
     cb9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     cbc:	45                   	inc    bp
     cbd:	44                   	inc    sp
     cbe:	50                   	push   ax
     cbf:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     cc2:	6f                   	outs   dx,WORD PTR ds:[si]
     cc3:	64 75 69             	fs jne 0xd2f
     cc6:	74 4e                	je     0xd16
     cc8:	6f                   	outs   dx,WORD PTR ds:[si]
     cc9:	48                   	dec    ax
     cca:	03 14                	add    dx,WORD PTR [si]
     ccc:	00 13                	add    BYTE PTR [bp+di],dl
     cce:	54                   	push   sp
     ccf:	61                   	popa
     cd0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     cd3:	45                   	inc    bp
     cd4:	44                   	inc    sp
     cd5:	50                   	push   ax
     cd6:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     cd9:	6f                   	outs   dx,WORD PTR ds:[si]
     cda:	64 75 63             	fs jne 0xd40
     cdd:	74 69                	je     0xd48
     cdf:	6f                   	outs   dx,WORD PTR ds:[si]
     ce0:	6e                   	outs   dx,BYTE PTR ds:[si]
     ce1:	4c                   	dec    sp
     ce2:	03 14                	add    dx,WORD PTR [si]
     ce4:	00 1a                	add    BYTE PTR [bp+si],bl
     ce6:	54                   	push   sp
     ce7:	61                   	popa
     ce8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ceb:	45                   	inc    bp
     cec:	44                   	inc    sp
     ced:	50                   	push   ax
     cee:	32 4d 61             	xor    cl,BYTE PTR [di+0x61]
     cf1:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     cf4:	6e                   	outs   dx,BYTE PTR ds:[si]
     cf5:	65 73 41             	gs jae 0xd39
     cf8:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
     cfe:	65 73 50             	gs jae 0xd51
     d01:	03 14                	add    dx,WORD PTR [si]
     d03:	00 1b                	add    BYTE PTR [bp+di],bl
     d05:	54                   	push   sp
     d06:	61                   	popa
     d07:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d0a:	45                   	inc    bp
     d0b:	44                   	inc    sp
     d0c:	50                   	push   ax
     d0d:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     d10:	6f                   	outs   dx,WORD PTR ds:[si]
     d11:	64 75 63             	fs jne 0xd77
     d14:	74 69                	je     0xd7f
     d16:	66 73 41             	data32 jae 0xd5a
     d19:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
     d1f:	73 54                	jae    0xd75
     d21:	03 20                	add    sp,WORD PTR [bx+si]
     d23:	00 18                	add    BYTE PTR [bx+si],bl
     d25:	54                   	push   sp
     d26:	61                   	popa
     d27:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d2a:	45                   	inc    bp
     d2b:	44                   	inc    sp
     d2c:	50                   	push   ax
     d2d:	32 44 65             	xor    al,BYTE PTR [si+0x65]
     d30:	70 65                	jo     0xd97
     d32:	6e                   	outs   dx,BYTE PTR ds:[si]
     d33:	73 65                	jae    0xd9a
     d35:	73 51                	jae    0xd88
     d37:	75 61                	jne    0xd9a
     d39:	6c                   	ins    BYTE PTR es:[di],dx
     d3a:	69 74 65 58 03       	imul   si,WORD PTR [si+0x65],0x358
     d3f:	20 00                	and    BYTE PTR [bx+si],al
     d41:	0d 54 61             	or     ax,0x6154
     d44:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d47:	45                   	inc    bp
     d48:	44                   	inc    sp
     d49:	50                   	push   ax
     d4a:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     d4d:	69 78 5c 03 20       	imul   di,WORD PTR [bx+si+0x5c],0x2003
     d52:	00 12                	add    BYTE PTR [bp+si],dl
     d54:	54                   	push   sp
     d55:	61                   	popa
     d56:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d59:	45                   	inc    bp
     d5a:	44                   	inc    sp
     d5b:	50                   	push   ax
     d5c:	32 50 75             	xor    dl,BYTE PTR [bx+si+0x75]
     d5f:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
     d62:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
     d65:	65 60                	gs pusha
     d67:	03 20                	add    sp,WORD PTR [bx+si]
     d69:	00 1a                	add    BYTE PTR [bp+si],bl
     d6b:	54                   	push   sp
     d6c:	61                   	popa
     d6d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d70:	45                   	inc    bp
     d71:	44                   	inc    sp
     d72:	50                   	push   ax
     d73:	32 41 63             	xor    al,BYTE PTR [bx+di+0x63]
     d76:	74 69                	je     0xde1
     d78:	6f                   	outs   dx,WORD PTR ds:[si]
     d79:	6e                   	outs   dx,BYTE PTR ds:[si]
     d7a:	43                   	inc    bx
     d7b:	6f                   	outs   dx,WORD PTR ds:[si]
     d7c:	6d                   	ins    WORD PTR es:[di],dx
     d7d:	6d                   	ins    WORD PTR es:[di],dx
     d7e:	65 72 63             	gs jb  0xde4
     d81:	69 61 6c 65 64       	imul   sp,WORD PTR [bx+di+0x6c],0x6465
     d86:	03 14                	add    dx,WORD PTR [si]
     d88:	00 19                	add    BYTE PTR [bx+di],bl
     d8a:	54                   	push   sp
     d8b:	61                   	popa
     d8c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d8f:	45                   	inc    bp
     d90:	44                   	inc    sp
     d91:	50                   	push   ax
     d92:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
     d95:	6e                   	outs   dx,BYTE PTR ds:[si]
     d96:	64 65 75 72          	fs gs jne 0xe0c
     d9a:	73 41                	jae    0xddd
     d9c:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
     da2:	73 68                	jae    0xe0c
     da4:	03 14                	add    dx,WORD PTR [si]
     da6:	00 1a                	add    BYTE PTR [bp+si],bl
     da8:	54                   	push   sp
     da9:	61                   	popa
     daa:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     dad:	45                   	inc    bp
     dae:	44                   	inc    sp
     daf:	50                   	push   ax
     db0:	32 44 75             	xor    al,BYTE PTR [si+0x75]
     db3:	72 65                	jb     0xe1a
     db5:	65 43                	gs inc bx
     db7:	72 65                	jb     0xe1e
     db9:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
     dbf:	65 6e                	outs   dx,BYTE PTR gs:[si]
     dc1:	74 6c                	je     0xe2f
     dc3:	03 14                	add    dx,WORD PTR [si]
     dc5:	00 14                	add    BYTE PTR [si],dl
     dc7:	54                   	push   sp
     dc8:	61                   	popa
     dc9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     dcc:	45                   	inc    bp
     dcd:	44                   	inc    sp
     dce:	50                   	push   ax
     dcf:	32 4c 69             	xor    cl,BYTE PTR [si+0x69]
     dd2:	71 75                	jno    0xe49
     dd4:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
     dd9:	6f                   	outs   dx,WORD PTR ds:[si]
     dda:	6e                   	outs   dx,BYTE PTR ds:[si]
     ddb:	70 03                	jo     0xde0
     ddd:	14 00                	adc    al,0x0
     ddf:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
     de2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     de5:	45                   	inc    bp
     de6:	44                   	inc    sp
     de7:	50                   	push   ax
     de8:	32 53 6f             	xor    dl,BYTE PTR [bp+di+0x6f]
     deb:	75 6d                	jne    0xe5a
     ded:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
     df2:	6e                   	outs   dx,BYTE PTR ds:[si]
     df3:	51                   	push   cx
     df4:	75 61                	jne    0xe57
     df6:	6e                   	outs   dx,BYTE PTR ds:[si]
     df7:	74 69                	je     0xe62
     df9:	74 65                	je     0xe60
     dfb:	74 03                	je     0xe00
     dfd:	20 00                	and    BYTE PTR [bx+si],al
     dff:	17                   	pop    ss
     e00:	54                   	push   sp
     e01:	61                   	popa
     e02:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e05:	45                   	inc    bp
     e06:	44                   	inc    sp
     e07:	50                   	push   ax
     e08:	32 53 6f             	xor    dl,BYTE PTR [bp+di+0x6f]
     e0b:	75 6d                	jne    0xe7a
     e0d:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
     e12:	6e                   	outs   dx,BYTE PTR ds:[si]
     e13:	50                   	push   ax
     e14:	72 69                	jb     0xe7f
     e16:	78 78                	js     0xe90
     e18:	03 14                	add    dx,WORD PTR [si]
     e1a:	00 10                	add    BYTE PTR [bx+si],dl
     e1c:	54                   	push   sp
     e1d:	61                   	popa
     e1e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e21:	45                   	inc    bp
     e22:	44                   	inc    sp
     e23:	50                   	push   ax
     e24:	32 53 70             	xor    dl,BYTE PTR [bp+di+0x70]
     e27:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     e2b:	6c                   	ins    BYTE PTR es:[di],dx
     e2c:	7c 03                	jl     0xe31
     e2e:	14 00                	adc    al,0x0
     e30:	11 54 61             	adc    WORD PTR [si+0x61],dx
     e33:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e36:	45                   	inc    bp
     e37:	52                   	push   dx
     e38:	47                   	inc    di
     e39:	50                   	push   ax
     e3a:	65 72 69             	gs jb  0xea6
     e3d:	6f                   	outs   dx,WORD PTR ds:[si]
     e3e:	64 65 4e             	fs gs dec si
     e41:	6f                   	outs   dx,WORD PTR ds:[si]
     e42:	80 03 14             	add    BYTE PTR [bp+di],0x14
     e45:	00 14                	add    BYTE PTR [si],dl
     e47:	54                   	push   sp
     e48:	61                   	popa
     e49:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e4c:	45                   	inc    bp
     e4d:	52                   	push   dx
     e4e:	47                   	inc    di
     e4f:	45                   	inc    bp
     e50:	6e                   	outs   dx,BYTE PTR ds:[si]
     e51:	74 72                	je     0xec5
     e53:	65 70 72             	gs jo  0xec8
     e56:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     e5b:	84 03                	test   BYTE PTR [bp+di],al
     e5d:	20 00                	and    BYTE PTR [bx+si],al
     e5f:	15 54 61             	adc    ax,0x6154
     e62:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e65:	45                   	inc    bp
     e66:	52                   	push   dx
     e67:	47                   	inc    di
     e68:	43                   	inc    bx
     e69:	61                   	popa
     e6a:	70 69                	jo     0xed5
     e6c:	74 61                	je     0xecf
     e6e:	6c                   	ins    BYTE PTR es:[di],dx
     e6f:	53                   	push   bx
     e70:	6f                   	outs   dx,WORD PTR ds:[si]
     e71:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     e74:	6c                   	ins    BYTE PTR es:[di],dx
     e75:	88 03                	mov    BYTE PTR [bp+di],al
     e77:	20 00                	and    BYTE PTR [bx+si],al
     e79:	10 54 61             	adc    BYTE PTR [si+0x61],dl
     e7c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e7f:	45                   	inc    bp
     e80:	52                   	push   dx
     e81:	47                   	inc    di
     e82:	52                   	push   dx
     e83:	65 73 65             	gs jae 0xeeb
     e86:	72 76                	jb     0xefe
     e88:	65 73 8c             	gs jae 0xe17
     e8b:	03 20                	add    sp,WORD PTR [bx+si]
     e8d:	00 13                	add    BYTE PTR [bp+di],dl
     e8f:	54                   	push   sp
     e90:	61                   	popa
     e91:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e94:	45                   	inc    bp
     e95:	52                   	push   dx
     e96:	47                   	inc    di
     e97:	52                   	push   dx
     e98:	65 73 75             	gs jae 0xf10
     e9b:	6c                   	ins    BYTE PTR es:[di],dx
     e9c:	74 61                	je     0xeff
     e9e:	74 4e                	je     0xeee
     ea0:	65 74 90             	gs je  0xe33
     ea3:	03 20                	add    sp,WORD PTR [bx+si]
     ea5:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     ea9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     eac:	45                   	inc    bp
     ead:	52                   	push   dx
     eae:	47                   	inc    di
     eaf:	53                   	push   bx
     eb0:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     eb5:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
     eba:	74 74                	je     0xf30
     ebc:	65 94                	gs xchg sp,ax
     ebe:	03 20                	add    sp,WORD PTR [bx+si]
     ec0:	00 0b                	add    BYTE PTR [bp+di],cl
     ec2:	54                   	push   sp
     ec3:	61                   	popa
     ec4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ec7:	45                   	inc    bp
     ec8:	52                   	push   dx
     ec9:	47                   	inc    di
     eca:	43                   	inc    bx
     ecb:	41                   	inc    cx
     ecc:	46                   	inc    si
     ecd:	98                   	cbw
     ece:	03 20                	add    sp,WORD PTR [bx+si]
     ed0:	00 0d                	add    BYTE PTR [di],cl
     ed2:	54                   	push   sp
     ed3:	61                   	popa
     ed4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ed7:	45                   	inc    bp
     ed8:	52                   	push   dx
     ed9:	47                   	inc    di
     eda:	49                   	dec    cx
     edb:	6d                   	ins    WORD PTR es:[di],dx
     edc:	70 6f                	jo     0xf4d
     ede:	74 9c                	je     0xe7c
     ee0:	03 20                	add    sp,WORD PTR [bx+si]
     ee2:	00 0b                	add    BYTE PTR [bp+di],cl
     ee4:	54                   	push   sp
     ee5:	61                   	popa
     ee6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ee9:	45                   	inc    bp
     eea:	52                   	push   dx
     eeb:	47                   	inc    di
     eec:	49                   	dec    cx
     eed:	46                   	inc    si
     eee:	41                   	inc    cx
     eef:	a0 03 20             	mov    al,ds:0x2003
     ef2:	00 0f                	add    BYTE PTR [bx],cl
     ef4:	54                   	push   sp
     ef5:	61                   	popa
     ef6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ef9:	45                   	inc    bp
     efa:	52                   	push   dx
     efb:	47                   	inc    di
     efc:	43                   	inc    bx
     efd:	6c                   	ins    BYTE PTR es:[di],dx
     efe:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
     f03:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     f04:	03 20                	add    sp,WORD PTR [bx+si]
     f06:	00 14                	add    BYTE PTR [si],dl
     f08:	54                   	push   sp
     f09:	61                   	popa
     f0a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f0d:	45                   	inc    bp
     f0e:	52                   	push   dx
     f0f:	47                   	inc    di
     f10:	46                   	inc    si
     f11:	6f                   	outs   dx,WORD PTR ds:[si]
     f12:	75 72                	jne    0xf86
     f14:	6e                   	outs   dx,BYTE PTR ds:[si]
     f15:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
     f1a:	72 73                	jb     0xf8f
     f1c:	a8 03                	test   al,0x3
     f1e:	20 00                	and    BYTE PTR [bx+si],al
     f20:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     f23:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f26:	45                   	inc    bp
     f27:	52                   	push   dx
     f28:	47                   	inc    di
     f29:	54                   	push   sp
     f2a:	72 65                	jb     0xf91
     f2c:	73 6f                	jae    0xf9d
     f2e:	72 65                	jb     0xf95
     f30:	72 69                	jb     0xf9b
     f32:	65 ac                	lods   al,BYTE PTR gs:[si]
     f34:	03 20                	add    sp,WORD PTR [bx+si]
     f36:	00 0f                	add    BYTE PTR [bx],cl
     f38:	54                   	push   sp
     f39:	61                   	popa
     f3a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f3d:	45                   	inc    bp
     f3e:	52                   	push   dx
     f3f:	47                   	inc    di
     f40:	45                   	inc    bp
     f41:	6d                   	ins    WORD PTR es:[di],dx
     f42:	70 72                	jo     0xfb6
     f44:	75 6e                	jne    0xfb4
     f46:	74 b0                	je     0xef8
     f48:	03 20                	add    sp,WORD PTR [bx+si]
     f4a:	00 15                	add    BYTE PTR [di],dl
     f4c:	54                   	push   sp
     f4d:	61                   	popa
     f4e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f51:	45                   	inc    bp
     f52:	52                   	push   dx
     f53:	47                   	inc    di
     f54:	44                   	inc    sp
     f55:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     f59:	76 65                	jbe    0xfc0
     f5b:	72 74                	jb     0xfd1
     f5d:	41                   	inc    cx
     f5e:	75 74                	jne    0xfd4
     f60:	6f                   	outs   dx,WORD PTR ds:[si]
     f61:	b4 03                	mov    ah,0x3
     f63:	20 00                	and    BYTE PTR [bx+si],al
     f65:	16                   	push   ss
     f66:	54                   	push   sp
     f67:	61                   	popa
     f68:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f6b:	45                   	inc    bp
     f6c:	52                   	push   dx
     f6d:	47                   	inc    di
     f6e:	44                   	inc    sp
     f6f:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     f73:	76 65                	jbe    0xfda
     f75:	72 74                	jb     0xfeb
     f77:	4e                   	dec    si
     f78:	41                   	inc    cx
     f79:	75 74                	jne    0xfef
     f7b:	6f                   	outs   dx,WORD PTR ds:[si]
     f7c:	b8 03 20             	mov    ax,0x2003
     f7f:	00 15                	add    BYTE PTR [di],dl
     f81:	54                   	push   sp
     f82:	61                   	popa
     f83:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f86:	45                   	inc    bp
     f87:	52                   	push   dx
     f88:	47                   	inc    di
     f89:	41                   	inc    cx
     f8a:	6d                   	ins    WORD PTR es:[di],dx
     f8b:	6f                   	outs   dx,WORD PTR ds:[si]
     f8c:	72 74                	jb     0x1002
     f8e:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     f93:	65 6e                	outs   dx,BYTE PTR gs:[si]
     f95:	74 bc                	je     0xf53
     f97:	03 20                	add    sp,WORD PTR [bx+si]
     f99:	00 10                	add    BYTE PTR [bx+si],dl
     f9b:	54                   	push   sp
     f9c:	61                   	popa
     f9d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fa0:	45                   	inc    bp
     fa1:	52                   	push   dx
     fa2:	47                   	inc    di
     fa3:	43                   	inc    bx
     fa4:	65 73 73             	gs jae 0x101a
     fa7:	69 6f 6e 73 c0       	imul   bp,WORD PTR [bx+0x6e],0xc073
     fac:	03 14                	add    dx,WORD PTR [si]
     fae:	00 10                	add    BYTE PTR [bx+si],dl
     fb0:	54                   	push   sp
     fb1:	61                   	popa
     fb2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fb5:	45                   	inc    bp
     fb6:	52                   	push   dx
     fb7:	47                   	inc    di
     fb8:	4d                   	dec    bp
     fb9:	61                   	popa
     fba:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     fbd:	6e                   	outs   dx,BYTE PTR ds:[si]
     fbe:	65 73 c4             	gs jae 0xf85
     fc1:	03 20                	add    sp,WORD PTR [bx+si]
     fc3:	00 1d                	add    BYTE PTR [di],bl
     fc5:	54                   	push   sp
     fc6:	61                   	popa
     fc7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fca:	45                   	inc    bp
     fcb:	52                   	push   dx
     fcc:	47                   	inc    di
     fcd:	49                   	dec    cx
     fce:	6d                   	ins    WORD PTR es:[di],dx
     fcf:	6d                   	ins    WORD PTR es:[di],dx
     fd0:	6f                   	outs   dx,WORD PTR ds:[si]
     fd1:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     fd4:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     fd9:	6f                   	outs   dx,WORD PTR ds:[si]
     fda:	6e                   	outs   dx,BYTE PTR ds:[si]
     fdb:	73 42                	jae    0x101f
     fdd:	72 75                	jb     0x1054
     fdf:	74 65                	je     0x1046
     fe1:	73 c8                	jae    0xfab
     fe3:	03 20                	add    sp,WORD PTR [bx+si]
     fe5:	00 1c                	add    BYTE PTR [si],bl
     fe7:	54                   	push   sp
     fe8:	61                   	popa
     fe9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fec:	45                   	inc    bp
     fed:	52                   	push   dx
     fee:	47                   	inc    di
     fef:	43                   	inc    bx
     ff0:	6f                   	outs   dx,WORD PTR ds:[si]
     ff1:	75 74                	jne    0x1067
     ff3:	73 46                	jae    0x103b
     ff5:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
     ffa:	72 6f                	jb     0x106b
     ffc:	64 75 63             	fs jne 0x1062
     fff:	74 69                	je     0x106a
    1001:	6f                   	outs   dx,WORD PTR ds:[si]
    1002:	6e                   	outs   dx,BYTE PTR ds:[si]
    1003:	cc                   	int3
    1004:	03 14                	add    dx,WORD PTR [si]
    1006:	00 12                	add    BYTE PTR [bp+si],dl
    1008:	54                   	push   sp
    1009:	61                   	popa
    100a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    100d:	45                   	inc    bp
    100e:	52                   	push   dx
    100f:	47                   	inc    di
    1010:	50                   	push   ax
    1011:	72 6f                	jb     0x1082
    1013:	64 75 63             	fs jne 0x1079
    1016:	74 69                	je     0x1081
    1018:	66 73 d0             	data32 jae 0xfeb
    101b:	03 14                	add    dx,WORD PTR [si]
    101d:	00 10                	add    BYTE PTR [bx+si],dl
    101f:	54                   	push   sp
    1020:	61                   	popa
    1021:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1024:	45                   	inc    bp
    1025:	52                   	push   dx
    1026:	47                   	inc    di
    1027:	56                   	push   si
    1028:	65 6e                	outs   dx,BYTE PTR gs:[si]
    102a:	64 65 75 72          	fs gs jne 0x10a0
    102e:	73 d4                	jae    0x1004
    1030:	03 14                	add    dx,WORD PTR [si]
    1032:	00 0e 54 61          	add    BYTE PTR ds:0x6154,cl
    1036:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1039:	45                   	inc    bp
    103a:	52                   	push   dx
    103b:	47                   	inc    di
    103c:	43                   	inc    bx
    103d:	61                   	popa
    103e:	64 72 65             	fs jb  0x10a6
    1041:	73 d8                	jae    0x101b
    1043:	03 20                	add    sp,WORD PTR [bx+si]
    1045:	00 14                	add    BYTE PTR [si],dl
    1047:	54                   	push   sp
    1048:	61                   	popa
    1049:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    104c:	45                   	inc    bp
    104d:	52                   	push   dx
    104e:	47                   	inc    di
    104f:	43                   	inc    bx
    1050:	6f                   	outs   dx,WORD PTR ds:[si]
    1051:	75 74                	jne    0x10c7
    1053:	45                   	inc    bp
    1054:	6d                   	ins    WORD PTR es:[di],dx
    1055:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    1058:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    105b:	dc 03                	fadd   QWORD PTR [bp+di]
    105d:	20 00                	and    BYTE PTR [bx+si],al
    105f:	14 54                	adc    al,0x54
    1061:	61                   	popa
    1062:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1065:	45                   	inc    bp
    1066:	52                   	push   dx
    1067:	47                   	inc    di
    1068:	43                   	inc    bx
    1069:	6f                   	outs   dx,WORD PTR ds:[si]
    106a:	75 74                	jne    0x10e0
    106c:	4c                   	dec    sp
    106d:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    1072:	69 65 e0 03 20       	imul   sp,WORD PTR [di-0x20],0x2003
    1077:	00 15                	add    BYTE PTR [di],dl
    1079:	54                   	push   sp
    107a:	61                   	popa
    107b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    107e:	45                   	inc    bp
    107f:	52                   	push   dx
    1080:	47                   	inc    di
    1081:	43                   	inc    bx
    1082:	6f                   	outs   dx,WORD PTR ds:[si]
    1083:	75 74                	jne    0x10f9
    1085:	46                   	inc    si
    1086:	6f                   	outs   dx,WORD PTR ds:[si]
    1087:	72 6d                	jb     0x10f6
    1089:	61                   	popa
    108a:	74 69                	je     0x10f5
    108c:	6f                   	outs   dx,WORD PTR ds:[si]
    108d:	6e                   	outs   dx,BYTE PTR ds:[si]
    108e:	e4 03                	in     al,0x3
    1090:	20 00                	and    BYTE PTR [bx+si],al
    1092:	15 54 61             	adc    ax,0x6154
    1095:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1098:	45                   	inc    bp
    1099:	52                   	push   dx
    109a:	47                   	inc    di
    109b:	44                   	inc    sp
    109c:	69 73 74 72 69       	imul   si,WORD PTR [bp+di+0x74],0x6972
    10a1:	62 75 74             	bound  si,DWORD PTR [di+0x74]
    10a4:	69 6f 6e 73 e8       	imul   bp,WORD PTR [bx+0x6e],0xe873
    10a9:	03 14                	add    dx,WORD PTR [si]
    10ab:	00 0f                	add    BYTE PTR [bx],cl
    10ad:	54                   	push   sp
    10ae:	61                   	popa
    10af:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10b2:	45                   	inc    bp
    10b3:	52                   	push   dx
    10b4:	47                   	inc    di
    10b5:	53                   	push   bx
    10b6:	70 65                	jo     0x111d
    10b8:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    10bb:	6c                   	ins    BYTE PTR es:[di],dx
    10bc:	ec                   	in     al,dx
    10bd:	03 14                	add    dx,WORD PTR [si]
    10bf:	00 12                	add    BYTE PTR [bp+si],dl
    10c1:	54                   	push   sp
    10c2:	61                   	popa
    10c3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10c6:	45                   	inc    bp
    10c7:	52                   	push   dx
    10c8:	50                   	push   ax
    10c9:	31 50 65             	xor    WORD PTR [bx+si+0x65],dx
    10cc:	72 69                	jb     0x1137
    10ce:	6f                   	outs   dx,WORD PTR ds:[si]
    10cf:	64 65 4e             	fs gs dec si
    10d2:	6f                   	outs   dx,WORD PTR ds:[si]
    10d3:	f0 03 14             	lock add dx,WORD PTR [si]
    10d6:	00 15                	add    BYTE PTR [di],dl
    10d8:	54                   	push   sp
    10d9:	61                   	popa
    10da:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10dd:	45                   	inc    bp
    10de:	52                   	push   dx
    10df:	50                   	push   ax
    10e0:	31 45 6e             	xor    WORD PTR [di+0x6e],ax
    10e3:	74 72                	je     0x1157
    10e5:	65 70 72             	gs jo  0x115a
    10e8:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    10ed:	f4                   	hlt
    10ee:	03 14                	add    dx,WORD PTR [si]
    10f0:	00 12                	add    BYTE PTR [bp+si],dl
    10f2:	54                   	push   sp
    10f3:	61                   	popa
    10f4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10f7:	45                   	inc    bp
    10f8:	52                   	push   dx
    10f9:	50                   	push   ax
    10fa:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
    10fd:	6f                   	outs   dx,WORD PTR ds:[si]
    10fe:	64 75 69             	fs jne 0x116a
    1101:	74 4e                	je     0x1151
    1103:	6f                   	outs   dx,WORD PTR ds:[si]
    1104:	f8                   	clc
    1105:	03 20                	add    sp,WORD PTR [bx+si]
    1107:	00 12                	add    BYTE PTR [bp+si],dl
    1109:	54                   	push   sp
    110a:	61                   	popa
    110b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    110e:	45                   	inc    bp
    110f:	52                   	push   dx
    1110:	50                   	push   ax
    1111:	31 45 66             	xor    WORD PTR [di+0x66],ax
    1114:	66 65 74 50          	data32 gs je 0x1168
    1118:	72 69                	jb     0x1183
    111a:	78 fc                	js     0x1118
    111c:	03 20                	add    sp,WORD PTR [bx+si]
    111e:	00 11                	add    BYTE PTR [bx+di],dl
    1120:	54                   	push   sp
    1121:	61                   	popa
    1122:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1125:	45                   	inc    bp
    1126:	52                   	push   dx
    1127:	50                   	push   ax
    1128:	31 45 66             	xor    WORD PTR [di+0x66],ax
    112b:	66 65 74 50          	data32 gs je 0x117f
    112f:	75 62                	jne    0x1193
    1131:	00 04                	add    BYTE PTR [si],al
    1133:	20 00                	and    BYTE PTR [bx+si],al
    1135:	10 54 61             	adc    BYTE PTR [si+0x61],dl
    1138:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    113b:	45                   	inc    bp
    113c:	52                   	push   dx
    113d:	50                   	push   ax
    113e:	31 45 66             	xor    WORD PTR [di+0x66],ax
    1141:	66 65 74 46          	data32 gs je 0x118b
    1145:	56                   	push   si
    1146:	04 04                	add    al,0x4
    1148:	20 00                	and    BYTE PTR [bx+si],al
    114a:	14 54                	adc    al,0x54
    114c:	61                   	popa
    114d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1150:	45                   	inc    bp
    1151:	52                   	push   dx
    1152:	50                   	push   ax
    1153:	31 45 66             	xor    WORD PTR [di+0x66],ax
    1156:	66 65 74 43          	data32 gs je 0x119d
    115a:	72 65                	jb     0x11c1
    115c:	64 69 74 08 04 20    	imul   si,WORD PTR fs:[si+0x8],0x2004
    1162:	00 14                	add    BYTE PTR [si],dl
    1164:	54                   	push   sp
    1165:	61                   	popa
    1166:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1169:	45                   	inc    bp
    116a:	52                   	push   dx
    116b:	50                   	push   ax
    116c:	31 45 66             	xor    WORD PTR [di+0x66],ax
    116f:	66 65 74 47          	data32 gs je 0x11ba
    1173:	6c                   	ins    BYTE PTR es:[di],dx
    1174:	6f                   	outs   dx,WORD PTR ds:[si]
    1175:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
    1178:	0c 04                	or     al,0x4
    117a:	14 00                	adc    al,0x0
    117c:	10 54 61             	adc    BYTE PTR [si+0x61],dl
    117f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1182:	45                   	inc    bp
    1183:	52                   	push   dx
    1184:	50                   	push   ax
    1185:	31 44 65             	xor    WORD PTR [si+0x65],ax
    1188:	6d                   	ins    WORD PTR es:[di],dx
    1189:	61                   	popa
    118a:	6e                   	outs   dx,BYTE PTR ds:[si]
    118b:	64 65 10 04          	fs adc BYTE PTR gs:[si],al
    118f:	14 00                	adc    al,0x0
    1191:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
    1195:	6c                   	ins    BYTE PTR es:[di],dx
    1196:	65 45                	gs inc bp
    1198:	52                   	push   dx
    1199:	50                   	push   ax
    119a:	31 56 65             	xor    WORD PTR [bp+0x65],dx
    119d:	6e                   	outs   dx,BYTE PTR ds:[si]
    119e:	74 65                	je     0x1205
    11a0:	73 14                	jae    0x11b6
    11a2:	04 14                	add    al,0x14
    11a4:	00 1d                	add    BYTE PTR [di],bl
    11a6:	54                   	push   sp
    11a7:	61                   	popa
    11a8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11ab:	45                   	inc    bp
    11ac:	52                   	push   dx
    11ad:	50                   	push   ax
    11ae:	31 44 65             	xor    WORD PTR [si+0x65],ax
    11b1:	6d                   	ins    WORD PTR es:[di],dx
    11b2:	61                   	popa
    11b3:	6e                   	outs   dx,BYTE PTR ds:[si]
    11b4:	64 65 4e             	fs gs dec si
    11b7:	6f                   	outs   dx,WORD PTR ds:[si]
    11b8:	6e                   	outs   dx,BYTE PTR ds:[si]
    11b9:	53                   	push   bx
    11ba:	61                   	popa
    11bb:	74 69                	je     0x1226
    11bd:	73 66                	jae    0x1225
    11bf:	61                   	popa
    11c0:	69 74 65 18 04       	imul   si,WORD PTR [si+0x65],0x418
    11c5:	14 00                	adc    al,0x0
    11c7:	15 54 61             	adc    ax,0x6154
    11ca:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11cd:	45                   	inc    bp
    11ce:	52                   	push   dx
    11cf:	50                   	push   ax
    11d0:	31 56 65             	xor    WORD PTR [bp+0x65],dx
    11d3:	6e                   	outs   dx,BYTE PTR ds:[si]
    11d4:	74 65                	je     0x123b
    11d6:	73 50                	jae    0x1228
    11d8:	72 69                	jb     0x1243
    11da:	73 65                	jae    0x1241
    11dc:	73 1c                	jae    0x11fa
    11de:	04 20                	add    al,0x20
    11e0:	00 13                	add    BYTE PTR [bp+di],dl
    11e2:	54                   	push   sp
    11e3:	61                   	popa
    11e4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11e7:	45                   	inc    bp
    11e8:	52                   	push   dx
    11e9:	50                   	push   ax
    11ea:	31 50 61             	xor    WORD PTR [bx+si+0x61],dx
    11ed:	72 74                	jb     0x1263
    11ef:	4d                   	dec    bp
    11f0:	61                   	popa
    11f1:	72 63                	jb     0x1256
    11f3:	68 65 20             	push   0x2065
    11f6:	04 14                	add    al,0x14
    11f8:	00 11                	add    BYTE PTR [bx+di],dl
    11fa:	54                   	push   sp
    11fb:	61                   	popa
    11fc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11ff:	45                   	inc    bp
    1200:	52                   	push   dx
    1201:	50                   	push   ax
    1202:	31 51 74             	xor    WORD PTR [bx+di+0x74],dx
    1205:	65 53                	gs push bx
    1207:	74 6f                	je     0x1278
    1209:	63 6b 24             	arpl   WORD PTR [bp+di+0x24],bp
    120c:	04 20                	add    al,0x20
    120e:	00 14                	add    BYTE PTR [si],dl
    1210:	54                   	push   sp
    1211:	61                   	popa
    1212:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1215:	45                   	inc    bp
    1216:	52                   	push   dx
    1217:	50                   	push   ax
    1218:	31 56 61             	xor    WORD PTR [bp+0x61],dx
    121b:	6c                   	ins    BYTE PTR es:[di],dx
    121c:	65 75 72             	gs jne 0x1291
    121f:	53                   	push   bx
    1220:	74 6f                	je     0x1291
    1222:	63 6b 28             	arpl   WORD PTR [bp+di+0x28],bp
    1225:	04 20                	add    al,0x20
    1227:	00 19                	add    BYTE PTR [bx+di],bl
    1229:	54                   	push   sp
    122a:	61                   	popa
    122b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    122e:	45                   	inc    bp
    122f:	52                   	push   dx
    1230:	50                   	push   ax
    1231:	31 44 6f             	xor    WORD PTR [si+0x6f],ax
    1234:	74 41                	je     0x1277
    1236:	6d                   	ins    WORD PTR es:[di],dx
    1237:	6f                   	outs   dx,WORD PTR ds:[si]
    1238:	72 74                	jb     0x12ae
    123a:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    123f:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1241:	74 2c                	je     0x126f
    1243:	04 14                	add    al,0x14
    1245:	00 19                	add    BYTE PTR [bx+di],bl
    1247:	54                   	push   sp
    1248:	61                   	popa
    1249:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    124c:	45                   	inc    bp
    124d:	52                   	push   dx
    124e:	50                   	push   ax
    124f:	31 56 65             	xor    WORD PTR [bp+0x65],dx
    1252:	6e                   	outs   dx,BYTE PTR ds:[si]
    1253:	74 65                	je     0x12ba
    1255:	73 53                	jae    0x12aa
    1257:	6f                   	outs   dx,WORD PTR ds:[si]
    1258:	6c                   	ins    BYTE PTR es:[di],dx
    1259:	64 65 65 73 51       	fs gs gs jae 0x12af
    125e:	74 65                	je     0x12c5
    1260:	30 04                	xor    BYTE PTR [si],al
    1262:	20 00                	and    BYTE PTR [bx+si],al
    1264:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
    1267:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    126a:	45                   	inc    bp
    126b:	52                   	push   dx
    126c:	50                   	push   ax
    126d:	31 56 65             	xor    WORD PTR [bp+0x65],dx
    1270:	6e                   	outs   dx,BYTE PTR ds:[si]
    1271:	74 65                	je     0x12d8
    1273:	73 53                	jae    0x12c8
    1275:	6f                   	outs   dx,WORD PTR ds:[si]
    1276:	6c                   	ins    BYTE PTR es:[di],dx
    1277:	64 65 65 73 50       	fs gs gs jae 0x12cc
    127c:	72 69                	jb     0x12e7
    127e:	78 34                	js     0x12b4
    1280:	04 14                	add    al,0x14
    1282:	00 15                	add    BYTE PTR [di],dl
    1284:	54                   	push   sp
    1285:	61                   	popa
    1286:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1289:	45                   	inc    bp
    128a:	52                   	push   dx
    128b:	50                   	push   ax
    128c:	31 56 65             	xor    WORD PTR [bp+0x65],dx
    128f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1290:	74 65                	je     0x12f7
    1292:	73 53                	jae    0x12e7
    1294:	70 65                	jo     0x12fb
    1296:	51                   	push   cx
    1297:	74 65                	je     0x12fe
    1299:	38 04                	cmp    BYTE PTR [si],al
    129b:	20 00                	and    BYTE PTR [bx+si],al
    129d:	16                   	push   ss
    129e:	54                   	push   sp
    129f:	61                   	popa
    12a0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    12a3:	45                   	inc    bp
    12a4:	52                   	push   dx
    12a5:	50                   	push   ax
    12a6:	31 56 65             	xor    WORD PTR [bp+0x65],dx
    12a9:	6e                   	outs   dx,BYTE PTR ds:[si]
    12aa:	74 65                	je     0x1311
    12ac:	73 53                	jae    0x1301
    12ae:	70 65                	jo     0x1315
    12b0:	50                   	push   ax
    12b1:	72 69                	jb     0x131c
    12b3:	78 3c                	js     0x12f1
    12b5:	04 20                	add    al,0x20
    12b7:	00 1a                	add    BYTE PTR [bp+si],bl
    12b9:	54                   	push   sp
    12ba:	61                   	popa
    12bb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    12be:	45                   	inc    bp
    12bf:	52                   	push   dx
    12c0:	50                   	push   ax
    12c1:	31 4d 61             	xor    WORD PTR [di+0x61],cx
    12c4:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    12c9:	76 72                	jbe    0x133d
    12cb:	65 44                	gs inc sp
    12cd:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    12d2:	65 40                	gs inc ax
    12d4:	04 20                	add    al,0x20
    12d6:	00 1c                	add    BYTE PTR [si],bl
    12d8:	54                   	push   sp
    12d9:	61                   	popa
    12da:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    12dd:	45                   	inc    bp
    12de:	52                   	push   dx
    12df:	50                   	push   ax
    12e0:	31 43 6f             	xor    WORD PTR [bp+di+0x6f],ax
    12e3:	6e                   	outs   dx,BYTE PTR ds:[si]
    12e4:	73 6f                	jae    0x1355
    12e6:	6d                   	ins    WORD PTR es:[di],dx
    12e7:	6d                   	ins    WORD PTR es:[di],dx
    12e8:	61                   	popa
    12e9:	74 69                	je     0x1354
    12eb:	6f                   	outs   dx,WORD PTR ds:[si]
    12ec:	6e                   	outs   dx,BYTE PTR ds:[si]
    12ed:	4d                   	dec    bp
    12ee:	61                   	popa
    12ef:	74 69                	je     0x135a
    12f1:	65 72 65             	gs jb  0x1359
    12f4:	44                   	inc    sp
    12f5:	04 10                	add    al,0x10
    12f7:	00 1e 54 61          	add    BYTE PTR ds:0x6154,bl
    12fb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    12fe:	45                   	inc    bp
    12ff:	52                   	push   dx
    1300:	50                   	push   ax
    1301:	31 54 65             	xor    WORD PTR [si+0x65],dx
    1304:	6d                   	ins    WORD PTR es:[di],dx
    1305:	70 73                	jo     0x137a
    1307:	46                   	inc    si
    1308:	61                   	popa
    1309:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    130c:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    130f:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    1314:	74 75                	je     0x138b
    1316:	72 48                	jb     0x1360
    1318:	04 14                	add    al,0x14
    131a:	00 10                	add    BYTE PTR [bx+si],dl
    131c:	54                   	push   sp
    131d:	61                   	popa
    131e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1321:	45                   	inc    bp
    1322:	52                   	push   dx
    1323:	50                   	push   ax
    1324:	31 53 70             	xor    WORD PTR [bp+di+0x70],dx
    1327:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
    132b:	6c                   	ins    BYTE PTR es:[di],dx
    132c:	4c                   	dec    sp
    132d:	04 14                	add    al,0x14
    132f:	00 12                	add    BYTE PTR [bp+si],dl
    1331:	54                   	push   sp
    1332:	61                   	popa
    1333:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1336:	45                   	inc    bp
    1337:	52                   	push   dx
    1338:	50                   	push   ax
    1339:	32 50 65             	xor    dl,BYTE PTR [bx+si+0x65]
    133c:	72 69                	jb     0x13a7
    133e:	6f                   	outs   dx,WORD PTR ds:[si]
    133f:	64 65 4e             	fs gs dec si
    1342:	6f                   	outs   dx,WORD PTR ds:[si]
    1343:	50                   	push   ax
    1344:	04 14                	add    al,0x14
    1346:	00 15                	add    BYTE PTR [di],dl
    1348:	54                   	push   sp
    1349:	61                   	popa
    134a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    134d:	45                   	inc    bp
    134e:	52                   	push   dx
    134f:	50                   	push   ax
    1350:	32 45 6e             	xor    al,BYTE PTR [di+0x6e]
    1353:	74 72                	je     0x13c7
    1355:	65 70 72             	gs jo  0x13ca
    1358:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    135d:	54                   	push   sp
    135e:	04 14                	add    al,0x14
    1360:	00 12                	add    BYTE PTR [bp+si],dl
    1362:	54                   	push   sp
    1363:	61                   	popa
    1364:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1367:	45                   	inc    bp
    1368:	52                   	push   dx
    1369:	50                   	push   ax
    136a:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
    136d:	6f                   	outs   dx,WORD PTR ds:[si]
    136e:	64 75 69             	fs jne 0x13da
    1371:	74 4e                	je     0x13c1
    1373:	6f                   	outs   dx,WORD PTR ds:[si]
    1374:	58                   	pop    ax
    1375:	04 20                	add    al,0x20
    1377:	00 12                	add    BYTE PTR [bp+si],dl
    1379:	54                   	push   sp
    137a:	61                   	popa
    137b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    137e:	45                   	inc    bp
    137f:	52                   	push   dx
    1380:	50                   	push   ax
    1381:	32 45 66             	xor    al,BYTE PTR [di+0x66]
    1384:	66 65 74 50          	data32 gs je 0x13d8
    1388:	72 69                	jb     0x13f3
    138a:	78 5c                	js     0x13e8
    138c:	04 20                	add    al,0x20
    138e:	00 11                	add    BYTE PTR [bx+di],dl
    1390:	54                   	push   sp
    1391:	61                   	popa
    1392:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1395:	45                   	inc    bp
    1396:	52                   	push   dx
    1397:	50                   	push   ax
    1398:	32 45 66             	xor    al,BYTE PTR [di+0x66]
    139b:	66 65 74 50          	data32 gs je 0x13ef
    139f:	75 62                	jne    0x1403
    13a1:	60                   	pusha
    13a2:	04 20                	add    al,0x20
    13a4:	00 10                	add    BYTE PTR [bx+si],dl
    13a6:	54                   	push   sp
    13a7:	61                   	popa
    13a8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    13ab:	45                   	inc    bp
    13ac:	52                   	push   dx
    13ad:	50                   	push   ax
    13ae:	32 45 66             	xor    al,BYTE PTR [di+0x66]
    13b1:	66 65 74 46          	data32 gs je 0x13fb
    13b5:	56                   	push   si
    13b6:	64 04 20             	fs add al,0x20
    13b9:	00 14                	add    BYTE PTR [si],dl
    13bb:	54                   	push   sp
    13bc:	61                   	popa
    13bd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    13c0:	45                   	inc    bp
    13c1:	52                   	push   dx
    13c2:	50                   	push   ax
    13c3:	32 45 66             	xor    al,BYTE PTR [di+0x66]
    13c6:	66 65 74 43          	data32 gs je 0x140d
    13ca:	72 65                	jb     0x1431
    13cc:	64 69 74 68 04 20    	imul   si,WORD PTR fs:[si+0x68],0x2004
    13d2:	00 14                	add    BYTE PTR [si],dl
    13d4:	54                   	push   sp
    13d5:	61                   	popa
    13d6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    13d9:	45                   	inc    bp
    13da:	52                   	push   dx
    13db:	50                   	push   ax
    13dc:	32 45 66             	xor    al,BYTE PTR [di+0x66]
    13df:	66 65 74 47          	data32 gs je 0x142a
    13e3:	6c                   	ins    BYTE PTR es:[di],dx
    13e4:	6f                   	outs   dx,WORD PTR ds:[si]
    13e5:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
    13e8:	6c                   	ins    BYTE PTR es:[di],dx
    13e9:	04 14                	add    al,0x14
    13eb:	00 10                	add    BYTE PTR [bx+si],dl
    13ed:	54                   	push   sp
    13ee:	61                   	popa
    13ef:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    13f2:	45                   	inc    bp
    13f3:	52                   	push   dx
    13f4:	50                   	push   ax
    13f5:	32 44 65             	xor    al,BYTE PTR [si+0x65]
    13f8:	6d                   	ins    WORD PTR es:[di],dx
    13f9:	61                   	popa
    13fa:	6e                   	outs   dx,BYTE PTR ds:[si]
    13fb:	64 65 70 04          	fs gs jo 0x1403
    13ff:	14 00                	adc    al,0x0
    1401:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
    1405:	6c                   	ins    BYTE PTR es:[di],dx
    1406:	65 45                	gs inc bp
    1408:	52                   	push   dx
    1409:	50                   	push   ax
    140a:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
    140d:	6e                   	outs   dx,BYTE PTR ds:[si]
    140e:	74 65                	je     0x1475
    1410:	73 74                	jae    0x1486
    1412:	04 14                	add    al,0x14
    1414:	00 1d                	add    BYTE PTR [di],bl
    1416:	54                   	push   sp
    1417:	61                   	popa
    1418:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    141b:	45                   	inc    bp
    141c:	52                   	push   dx
    141d:	50                   	push   ax
    141e:	32 44 65             	xor    al,BYTE PTR [si+0x65]
    1421:	6d                   	ins    WORD PTR es:[di],dx
    1422:	61                   	popa
    1423:	6e                   	outs   dx,BYTE PTR ds:[si]
    1424:	64 65 4e             	fs gs dec si
    1427:	6f                   	outs   dx,WORD PTR ds:[si]
    1428:	6e                   	outs   dx,BYTE PTR ds:[si]
    1429:	53                   	push   bx
    142a:	61                   	popa
    142b:	74 69                	je     0x1496
    142d:	73 66                	jae    0x1495
    142f:	61                   	popa
    1430:	69 74 65 78 04       	imul   si,WORD PTR [si+0x65],0x478
    1435:	14 00                	adc    al,0x0
    1437:	15 54 61             	adc    ax,0x6154
    143a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    143d:	45                   	inc    bp
    143e:	52                   	push   dx
    143f:	50                   	push   ax
    1440:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
    1443:	6e                   	outs   dx,BYTE PTR ds:[si]
    1444:	74 65                	je     0x14ab
    1446:	73 50                	jae    0x1498
    1448:	72 69                	jb     0x14b3
    144a:	73 65                	jae    0x14b1
    144c:	73 7c                	jae    0x14ca
    144e:	04 20                	add    al,0x20
    1450:	00 13                	add    BYTE PTR [bp+di],dl
    1452:	54                   	push   sp
    1453:	61                   	popa
    1454:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1457:	45                   	inc    bp
    1458:	52                   	push   dx
    1459:	50                   	push   ax
    145a:	32 50 61             	xor    dl,BYTE PTR [bx+si+0x61]
    145d:	72 74                	jb     0x14d3
    145f:	4d                   	dec    bp
    1460:	61                   	popa
    1461:	72 63                	jb     0x14c6
    1463:	68 65 80             	push   0x8065
    1466:	04 14                	add    al,0x14
    1468:	00 11                	add    BYTE PTR [bx+di],dl
    146a:	54                   	push   sp
    146b:	61                   	popa
    146c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    146f:	45                   	inc    bp
    1470:	52                   	push   dx
    1471:	50                   	push   ax
    1472:	32 51 74             	xor    dl,BYTE PTR [bx+di+0x74]
    1475:	65 53                	gs push bx
    1477:	74 6f                	je     0x14e8
    1479:	63 6b 84             	arpl   WORD PTR [bp+di-0x7c],bp
    147c:	04 20                	add    al,0x20
    147e:	00 14                	add    BYTE PTR [si],dl
    1480:	54                   	push   sp
    1481:	61                   	popa
    1482:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1485:	45                   	inc    bp
    1486:	52                   	push   dx
    1487:	50                   	push   ax
    1488:	32 56 61             	xor    dl,BYTE PTR [bp+0x61]
    148b:	6c                   	ins    BYTE PTR es:[di],dx
    148c:	65 75 72             	gs jne 0x1501
    148f:	53                   	push   bx
    1490:	74 6f                	je     0x1501
    1492:	63 6b 88             	arpl   WORD PTR [bp+di-0x78],bp
    1495:	04 20                	add    al,0x20
    1497:	00 19                	add    BYTE PTR [bx+di],bl
    1499:	54                   	push   sp
    149a:	61                   	popa
    149b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    149e:	45                   	inc    bp
    149f:	52                   	push   dx
    14a0:	50                   	push   ax
    14a1:	32 44 6f             	xor    al,BYTE PTR [si+0x6f]
    14a4:	74 41                	je     0x14e7
    14a6:	6d                   	ins    WORD PTR es:[di],dx
    14a7:	6f                   	outs   dx,WORD PTR ds:[si]
    14a8:	72 74                	jb     0x151e
    14aa:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    14af:	65 6e                	outs   dx,BYTE PTR gs:[si]
    14b1:	74 8c                	je     0x143f
    14b3:	04 14                	add    al,0x14
    14b5:	00 19                	add    BYTE PTR [bx+di],bl
    14b7:	54                   	push   sp
    14b8:	61                   	popa
    14b9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    14bc:	45                   	inc    bp
    14bd:	52                   	push   dx
    14be:	50                   	push   ax
    14bf:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
    14c2:	6e                   	outs   dx,BYTE PTR ds:[si]
    14c3:	74 65                	je     0x152a
    14c5:	73 53                	jae    0x151a
    14c7:	6f                   	outs   dx,WORD PTR ds:[si]
    14c8:	6c                   	ins    BYTE PTR es:[di],dx
    14c9:	64 65 65 73 51       	fs gs gs jae 0x151f
    14ce:	74 65                	je     0x1535
    14d0:	90                   	nop
    14d1:	04 20                	add    al,0x20
    14d3:	00 1a                	add    BYTE PTR [bp+si],bl
    14d5:	54                   	push   sp
    14d6:	61                   	popa
    14d7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    14da:	45                   	inc    bp
    14db:	52                   	push   dx
    14dc:	50                   	push   ax
    14dd:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
    14e0:	6e                   	outs   dx,BYTE PTR ds:[si]
    14e1:	74 65                	je     0x1548
    14e3:	73 53                	jae    0x1538
    14e5:	6f                   	outs   dx,WORD PTR ds:[si]
    14e6:	6c                   	ins    BYTE PTR es:[di],dx
    14e7:	64 65 65 73 50       	fs gs gs jae 0x153c
    14ec:	72 69                	jb     0x1557
    14ee:	78 94                	js     0x1484
    14f0:	04 14                	add    al,0x14
    14f2:	00 15                	add    BYTE PTR [di],dl
    14f4:	54                   	push   sp
    14f5:	61                   	popa
    14f6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    14f9:	45                   	inc    bp
    14fa:	52                   	push   dx
    14fb:	50                   	push   ax
    14fc:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
    14ff:	6e                   	outs   dx,BYTE PTR ds:[si]
    1500:	74 65                	je     0x1567
    1502:	73 53                	jae    0x1557
    1504:	70 65                	jo     0x156b
    1506:	51                   	push   cx
    1507:	74 65                	je     0x156e
    1509:	98                   	cbw
    150a:	04 20                	add    al,0x20
    150c:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
    1510:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1513:	45                   	inc    bp
    1514:	52                   	push   dx
    1515:	50                   	push   ax
    1516:	32 56 65             	xor    dl,BYTE PTR [bp+0x65]
    1519:	6e                   	outs   dx,BYTE PTR ds:[si]
    151a:	74 65                	je     0x1581
    151c:	73 53                	jae    0x1571
    151e:	70 65                	jo     0x1585
    1520:	50                   	push   ax
    1521:	72 69                	jb     0x158c
    1523:	78 9c                	js     0x14c1
    1525:	04 20                	add    al,0x20
    1527:	00 1a                	add    BYTE PTR [bp+si],bl
    1529:	54                   	push   sp
    152a:	61                   	popa
    152b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    152e:	45                   	inc    bp
    152f:	52                   	push   dx
    1530:	50                   	push   ax
    1531:	32 4d 61             	xor    cl,BYTE PTR [di+0x61]
    1534:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    1539:	76 72                	jbe    0x15ad
    153b:	65 44                	gs inc sp
    153d:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    1542:	65 a0 04 20          	mov    al,gs:0x2004
    1546:	00 1c                	add    BYTE PTR [si],bl
    1548:	54                   	push   sp
    1549:	61                   	popa
    154a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    154d:	45                   	inc    bp
    154e:	52                   	push   dx
    154f:	50                   	push   ax
    1550:	32 43 6f             	xor    al,BYTE PTR [bp+di+0x6f]
    1553:	6e                   	outs   dx,BYTE PTR ds:[si]
    1554:	73 6f                	jae    0x15c5
    1556:	6d                   	ins    WORD PTR es:[di],dx
    1557:	6d                   	ins    WORD PTR es:[di],dx
    1558:	61                   	popa
    1559:	74 69                	je     0x15c4
    155b:	6f                   	outs   dx,WORD PTR ds:[si]
    155c:	6e                   	outs   dx,BYTE PTR ds:[si]
    155d:	4d                   	dec    bp
    155e:	61                   	popa
    155f:	74 69                	je     0x15ca
    1561:	65 72 65             	gs jb  0x15c9
    1564:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1565:	04 10                	add    al,0x10
    1567:	00 1e 54 61          	add    BYTE PTR ds:0x6154,bl
    156b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    156e:	45                   	inc    bp
    156f:	52                   	push   dx
    1570:	50                   	push   ax
    1571:	32 54 65             	xor    dl,BYTE PTR [si+0x65]
    1574:	6d                   	ins    WORD PTR es:[di],dx
    1575:	70 73                	jo     0x15ea
    1577:	46                   	inc    si
    1578:	61                   	popa
    1579:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    157c:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    157f:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    1584:	74 75                	je     0x15fb
    1586:	72 a8                	jb     0x1530
    1588:	04 14                	add    al,0x14
    158a:	00 10                	add    BYTE PTR [bx+si],dl
    158c:	54                   	push   sp
    158d:	61                   	popa
    158e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1591:	45                   	inc    bp
    1592:	52                   	push   dx
    1593:	50                   	push   ax
    1594:	32 53 70             	xor    dl,BYTE PTR [bp+di+0x70]
    1597:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
    159b:	6c                   	ins    BYTE PTR es:[di],dx
    159c:	ac                   	lods   al,BYTE PTR ds:[si]
    159d:	04 20                	add    al,0x20
    159f:	00 19                	add    BYTE PTR [bx+di],bl
    15a1:	54                   	push   sp
    15a2:	61                   	popa
    15a3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    15a6:	45                   	inc    bp
    15a7:	52                   	push   dx
    15a8:	47                   	inc    di
    15a9:	5f                   	pop    di
    15aa:	6f                   	outs   dx,WORD PTR ds:[si]
    15ab:	6c                   	ins    BYTE PTR es:[di],dx
    15ac:	64 54                	fs push sp
    15ae:	56                   	push   si
    15af:	41                   	inc    cx
    15b0:	44                   	inc    sp
    15b1:	65 64 75 63          	gs fs jne 0x1618
    15b5:	74 69                	je     0x1620
    15b7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    15ba:	b0 04                	mov    al,0x4
    15bc:	20 00                	and    BYTE PTR [bx+si],al
    15be:	1e                   	push   ds
    15bf:	54                   	push   sp
    15c0:	61                   	popa
    15c1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    15c4:	45                   	inc    bp
    15c5:	52                   	push   dx
    15c6:	47                   	inc    di
    15c7:	5f                   	pop    di
    15c8:	6f                   	outs   dx,WORD PTR ds:[si]
    15c9:	6c                   	ins    BYTE PTR es:[di],dx
    15ca:	64 52                	fs push dx
    15cc:	65 6d                	gs ins WORD PTR es:[di],dx
    15ce:	75 6e                	jne    0x163e
    15d0:	65 72 61             	gs jb  0x1634
    15d3:	74 69                	je     0x163e
    15d5:	6f                   	outs   dx,WORD PTR ds:[si]
    15d6:	6e                   	outs   dx,BYTE PTR ds:[si]
    15d7:	43                   	inc    bx
    15d8:	61                   	popa
    15d9:	64 72 65             	fs jb  0x1641
    15dc:	73 b4                	jae    0x1592
    15de:	04 20                	add    al,0x20
    15e0:	00 15                	add    BYTE PTR [di],dl
    15e2:	54                   	push   sp
    15e3:	61                   	popa
    15e4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    15e7:	45                   	inc    bp
    15e8:	52                   	push   dx
    15e9:	47                   	inc    di
    15ea:	54                   	push   sp
    15eb:	56                   	push   si
    15ec:	41                   	inc    cx
    15ed:	44                   	inc    sp
    15ee:	65 64 75 63          	gs fs jne 0x1655
    15f2:	74 69                	je     0x165d
    15f4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    15f7:	b8 04 20             	mov    ax,0x2004
    15fa:	00 1a                	add    BYTE PTR [bp+si],bl
    15fc:	54                   	push   sp
    15fd:	61                   	popa
    15fe:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1601:	45                   	inc    bp
    1602:	52                   	push   dx
    1603:	47                   	inc    di
    1604:	52                   	push   dx
    1605:	65 6d                	gs ins WORD PTR es:[di],dx
    1607:	75 6e                	jne    0x1677
    1609:	65 72 61             	gs jb  0x166d
    160c:	74 69                	je     0x1677
    160e:	6f                   	outs   dx,WORD PTR ds:[si]
    160f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1610:	43                   	inc    bx
    1611:	61                   	popa
    1612:	64 72 65             	fs jb  0x167a
    1615:	73 bc                	jae    0x15d3
    1617:	04 20                	add    al,0x20
    1619:	00 17                	add    BYTE PTR [bx],dl
    161b:	54                   	push   sp
    161c:	61                   	popa
    161d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1620:	45                   	inc    bp
    1621:	52                   	push   dx
    1622:	50                   	push   ax
    1623:	31 52 65             	xor    WORD PTR [bp+si+0x65],dx
    1626:	6d                   	ins    WORD PTR es:[di],dx
    1627:	75 6e                	jne    0x1697
    1629:	65 72 61             	gs jb  0x168d
    162c:	74 69                	je     0x1697
    162e:	6f                   	outs   dx,WORD PTR ds:[si]
    162f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1630:	46                   	inc    si
    1631:	56                   	push   si
    1632:	c0 04 20             	rol    BYTE PTR [si],0x20
    1635:	00 17                	add    BYTE PTR [bx],dl
    1637:	54                   	push   sp
    1638:	61                   	popa
    1639:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    163c:	45                   	inc    bp
    163d:	52                   	push   dx
    163e:	50                   	push   ax
    163f:	32 52 65             	xor    dl,BYTE PTR [bp+si+0x65]
    1642:	6d                   	ins    WORD PTR es:[di],dx
    1643:	75 6e                	jne    0x16b3
    1645:	65 72 61             	gs jb  0x16a9
    1648:	74 69                	je     0x16b3
    164a:	6f                   	outs   dx,WORD PTR ds:[si]
    164b:	6e                   	outs   dx,BYTE PTR ds:[si]
    164c:	46                   	inc    si
    164d:	56                   	push   si
    164e:	c4 04                	les    ax,DWORD PTR [si]
    1650:	20 00                	and    BYTE PTR [bx+si],al
    1652:	14 54                	adc    al,0x54
    1654:	61                   	popa
    1655:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1658:	45                   	inc    bp
    1659:	52                   	push   dx
    165a:	47                   	inc    di
    165b:	54                   	push   sp
    165c:	56                   	push   si
    165d:	41                   	inc    cx
    165e:	43                   	inc    bx
    165f:	6f                   	outs   dx,WORD PTR ds:[si]
    1660:	6c                   	ins    BYTE PTR es:[di],dx
    1661:	6c                   	ins    BYTE PTR es:[di],dx
    1662:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
    1666:	65 c8 04 20 00       	gs enter 0x2004,0x0
    166b:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    166e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1671:	45                   	inc    bp
    1672:	52                   	push   dx
    1673:	47                   	inc    di
    1674:	5f                   	pop    di
    1675:	6f                   	outs   dx,WORD PTR ds:[si]
    1676:	6c                   	ins    BYTE PTR es:[di],dx
    1677:	64 54                	fs push sp
    1679:	56                   	push   si
    167a:	41                   	inc    cx
    167b:	43                   	inc    bx
    167c:	6f                   	outs   dx,WORD PTR ds:[si]
    167d:	6c                   	ins    BYTE PTR es:[di],dx
    167e:	6c                   	ins    BYTE PTR es:[di],dx
    167f:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
    1683:	65 cc                	gs int3
    1685:	04 08                	add    al,0x8
    1687:	00 06 46 69          	add    BYTE PTR ds:0x6946,al
    168b:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    168e:	31 d0                	xor    ax,dx
    1690:	04 08                	add    al,0x8
    1692:	00 02                	add    BYTE PTR [bp+si],al
    1694:	4e                   	dec    si
    1695:	33 d4                	xor    dx,sp
    1697:	04 20                	add    al,0x20
    1699:	00 14                	add    BYTE PTR [si],dl
    169b:	54                   	push   sp
    169c:	61                   	popa
    169d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    16a0:	45                   	inc    bp
    16a1:	52                   	push   dx
    16a2:	50                   	push   ax
    16a3:	31 48 65             	xor    WORD PTR [bx+si+0x65],cx
    16a6:	75 72                	jne    0x171a
    16a8:	65 73 53             	gs jae 0x16fe
    16ab:	75 70                	jne    0x171d
    16ad:	50                   	push   ax
    16ae:	63 d8                	arpl   ax,bx
    16b0:	04 20                	add    al,0x20
    16b2:	00 14                	add    BYTE PTR [si],dl
    16b4:	54                   	push   sp
    16b5:	61                   	popa
    16b6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    16b9:	45                   	inc    bp
    16ba:	52                   	push   dx
    16bb:	50                   	push   ax
    16bc:	32 48 65             	xor    cl,BYTE PTR [bx+si+0x65]
    16bf:	75 72                	jne    0x1733
    16c1:	65 73 53             	gs jae 0x1717
    16c4:	75 70                	jne    0x1736
    16c6:	50                   	push   ax
    16c7:	63 dc                	arpl   sp,bx
    16c9:	04 04                	add    al,0x4
    16cb:	00 07                	add    BYTE PTR [bx],al
    16cd:	50                   	push   ax
    16ce:	61                   	popa
    16cf:	6e                   	outs   dx,BYTE PTR ds:[si]
    16d0:	65 6c                	gs ins BYTE PTR es:[di],dx
    16d2:	31 30                	xor    WORD PTR [bx+si],si
    16d4:	e0 04                	loopne 0x16da
    16d6:	24 00                	and    al,0x0
    16d8:	09 47 72             	or     WORD PTR [bx+0x72],ax
    16db:	6f                   	outs   dx,WORD PTR ds:[si]
    16dc:	75 70                	jne    0x174e
    16de:	42                   	inc    dx
    16df:	6f                   	outs   dx,WORD PTR ds:[si]
    16e0:	78 31                	js     0x1713
    16e2:	e4 04                	in     al,0x4
    16e4:	28 00                	sub    BYTE PTR [bx+si],al
    16e6:	07                   	pop    es
    16e7:	44                   	inc    sp
    16e8:	42                   	inc    dx
    16e9:	45                   	inc    bp
    16ea:	64 69 74 31 e8 04    	imul   si,WORD PTR fs:[si+0x31],0x4e8
    16f0:	28 00                	sub    BYTE PTR [bx+si],al
    16f2:	07                   	pop    es
    16f3:	44                   	inc    sp
    16f4:	42                   	inc    dx
    16f5:	45                   	inc    bp
    16f6:	64 69 74 32 ec 04    	imul   si,WORD PTR fs:[si+0x32],0x4ec
    16fc:	28 00                	sub    BYTE PTR [bx+si],al
    16fe:	07                   	pop    es
    16ff:	44                   	inc    sp
    1700:	42                   	inc    dx
    1701:	45                   	inc    bp
    1702:	64 69 74 33 f0 04    	imul   si,WORD PTR fs:[si+0x33],0x4f0
    1708:	28 00                	sub    BYTE PTR [bx+si],al
    170a:	07                   	pop    es
    170b:	44                   	inc    sp
    170c:	42                   	inc    dx
    170d:	45                   	inc    bp
    170e:	64 69 74 35 f4 04    	imul   si,WORD PTR fs:[si+0x35],0x4f4
    1714:	28 00                	sub    BYTE PTR [bx+si],al
    1716:	07                   	pop    es
    1717:	44                   	inc    sp
    1718:	42                   	inc    dx
    1719:	45                   	inc    bp
    171a:	64 69 74 36 f8 04    	imul   si,WORD PTR fs:[si+0x36],0x4f8
    1720:	28 00                	sub    BYTE PTR [bx+si],al
    1722:	07                   	pop    es
    1723:	44                   	inc    sp
    1724:	42                   	inc    dx
    1725:	45                   	inc    bp
    1726:	64 69 74 37 fc 04    	imul   si,WORD PTR fs:[si+0x37],0x4fc
    172c:	28 00                	sub    BYTE PTR [bx+si],al
    172e:	07                   	pop    es
    172f:	44                   	inc    sp
    1730:	42                   	inc    dx
    1731:	45                   	inc    bp
    1732:	64 69 74 38 00 05    	imul   si,WORD PTR fs:[si+0x38],0x500
    1738:	28 00                	sub    BYTE PTR [bx+si],al
    173a:	08 44 42             	or     BYTE PTR [si+0x42],al
    173d:	45                   	inc    bp
    173e:	64 69 74 31 30 04    	imul   si,WORD PTR fs:[si+0x31],0x430
    1744:	05 04 00             	add    ax,0x4
    1747:	07                   	pop    es
    1748:	50                   	push   ax
    1749:	61                   	popa
    174a:	6e                   	outs   dx,BYTE PTR ds:[si]
    174b:	65 6c                	gs ins BYTE PTR es:[di],dx
    174d:	31 31                	xor    WORD PTR [bx+di],si
    174f:	08 05                	or     BYTE PTR [di],al
    1751:	04 00                	add    al,0x0
    1753:	07                   	pop    es
    1754:	50                   	push   ax
    1755:	61                   	popa
    1756:	6e                   	outs   dx,BYTE PTR ds:[si]
    1757:	65 6c                	gs ins BYTE PTR es:[di],dx
    1759:	31 32                	xor    WORD PTR [bp+si],si
    175b:	0c 05                	or     al,0x5
    175d:	04 00                	add    al,0x0
    175f:	07                   	pop    es
    1760:	50                   	push   ax
    1761:	61                   	popa
    1762:	6e                   	outs   dx,BYTE PTR ds:[si]
    1763:	65 6c                	gs ins BYTE PTR es:[di],dx
    1765:	31 33                	xor    WORD PTR [bp+di],si
    1767:	10 05                	adc    BYTE PTR [di],al
    1769:	04 00                	add    al,0x0
    176b:	07                   	pop    es
    176c:	50                   	push   ax
    176d:	61                   	popa
    176e:	6e                   	outs   dx,BYTE PTR ds:[si]
    176f:	65 6c                	gs ins BYTE PTR es:[di],dx
    1771:	31 34                	xor    WORD PTR [si],si
    1773:	14 05                	adc    al,0x5
    1775:	04 00                	add    al,0x0
    1777:	07                   	pop    es
    1778:	50                   	push   ax
    1779:	61                   	popa
    177a:	6e                   	outs   dx,BYTE PTR ds:[si]
    177b:	65 6c                	gs ins BYTE PTR es:[di],dx
    177d:	31 36 18 05          	xor    WORD PTR ds:0x518,si
    1781:	28 00                	sub    BYTE PTR [bx+si],al
    1783:	08 44 42             	or     BYTE PTR [si+0x42],al
    1786:	45                   	inc    bp
    1787:	64 69 74 34 37 1c    	imul   si,WORD PTR fs:[si+0x34],0x1c37
    178d:	05 28 00             	add    ax,0x28
    1790:	08 44 42             	or     BYTE PTR [si+0x42],al
    1793:	45                   	inc    bp
    1794:	64 69 74 34 38 20    	imul   si,WORD PTR fs:[si+0x34],0x2038
    179a:	05 28 00             	add    ax,0x28
    179d:	08 44 42             	or     BYTE PTR [si+0x42],al
    17a0:	45                   	inc    bp
    17a1:	64 69 74 34 39 24    	imul   si,WORD PTR fs:[si+0x34],0x2439
    17a7:	05 28 00             	add    ax,0x28
    17aa:	08 44 42             	or     BYTE PTR [si+0x42],al
    17ad:	45                   	inc    bp
    17ae:	64 69 74 35 30 28    	imul   si,WORD PTR fs:[si+0x35],0x2830
    17b4:	05 04 00             	add    ax,0x4
    17b7:	07                   	pop    es
    17b8:	50                   	push   ax
    17b9:	61                   	popa
    17ba:	6e                   	outs   dx,BYTE PTR ds:[si]
    17bb:	65 6c                	gs ins BYTE PTR es:[di],dx
    17bd:	34 39                	xor    al,0x39
    17bf:	2c 05                	sub    al,0x5
    17c1:	04 00                	add    al,0x0
    17c3:	07                   	pop    es
    17c4:	50                   	push   ax
    17c5:	61                   	popa
    17c6:	6e                   	outs   dx,BYTE PTR ds:[si]
    17c7:	65 6c                	gs ins BYTE PTR es:[di],dx
    17c9:	35 30 30             	xor    ax,0x3030
    17cc:	05 04 00             	add    ax,0x4
    17cf:	07                   	pop    es
    17d0:	50                   	push   ax
    17d1:	61                   	popa
    17d2:	6e                   	outs   dx,BYTE PTR ds:[si]
    17d3:	65 6c                	gs ins BYTE PTR es:[di],dx
    17d5:	35 31 34             	xor    ax,0x3431
    17d8:	05 04 00             	add    ax,0x4
    17db:	07                   	pop    es
    17dc:	50                   	push   ax
    17dd:	61                   	popa
    17de:	6e                   	outs   dx,BYTE PTR ds:[si]
    17df:	65 6c                	gs ins BYTE PTR es:[di],dx
    17e1:	31 35                	xor    WORD PTR [di],si
    17e3:	38 05                	cmp    BYTE PTR [di],al
    17e5:	28 00                	sub    BYTE PTR [bx+si],al
    17e7:	07                   	pop    es
    17e8:	44                   	inc    sp
    17e9:	42                   	inc    dx
    17ea:	45                   	inc    bp
    17eb:	64 69 74 34 3c 05    	imul   si,WORD PTR fs:[si+0x34],0x53c
    17f1:	28 00                	sub    BYTE PTR [bx+si],al
    17f3:	07                   	pop    es
    17f4:	44                   	inc    sp
    17f5:	42                   	inc    dx
    17f6:	45                   	inc    bp
    17f7:	64 69 74 39 40 05    	imul   si,WORD PTR fs:[si+0x39],0x540
    17fd:	04 00                	add    al,0x0
    17ff:	07                   	pop    es
    1800:	50                   	push   ax
    1801:	61                   	popa
    1802:	6e                   	outs   dx,BYTE PTR ds:[si]
    1803:	65 6c                	gs ins BYTE PTR es:[di],dx
    1805:	34 33                	xor    al,0x33
    1807:	44                   	inc    sp
    1808:	05 04 00             	add    ax,0x4
    180b:	07                   	pop    es
    180c:	50                   	push   ax
    180d:	61                   	popa
    180e:	6e                   	outs   dx,BYTE PTR ds:[si]
    180f:	65 6c                	gs ins BYTE PTR es:[di],dx
    1811:	34 32                	xor    al,0x32
    1813:	48                   	dec    ax
    1814:	05 04 00             	add    ax,0x4
    1817:	07                   	pop    es
    1818:	50                   	push   ax
    1819:	61                   	popa
    181a:	6e                   	outs   dx,BYTE PTR ds:[si]
    181b:	65 6c                	gs ins BYTE PTR es:[di],dx
    181d:	35 38 4c             	xor    ax,0x4c38
    1820:	05 04 00             	add    ax,0x4
    1823:	06                   	push   es
    1824:	50                   	push   ax
    1825:	61                   	popa
    1826:	6e                   	outs   dx,BYTE PTR ds:[si]
    1827:	65 6c                	gs ins BYTE PTR es:[di],dx
    1829:	34 50                	xor    al,0x50
    182b:	05 24 00             	add    ax,0x24
    182e:	09 47 72             	or     WORD PTR [bx+0x72],ax
    1831:	6f                   	outs   dx,WORD PTR ds:[si]
    1832:	75 70                	jne    0x18a4
    1834:	42                   	inc    dx
    1835:	6f                   	outs   dx,WORD PTR ds:[si]
    1836:	78 32                	js     0x186a
    1838:	54                   	push   sp
    1839:	05 28 00             	add    ax,0x28
    183c:	08 44 42             	or     BYTE PTR [si+0x42],al
    183f:	45                   	inc    bp
    1840:	64 69 74 31 31 58    	imul   si,WORD PTR fs:[si+0x31],0x5831
    1846:	05 28 00             	add    ax,0x28
    1849:	08 44 42             	or     BYTE PTR [si+0x42],al
    184c:	45                   	inc    bp
    184d:	64 69 74 31 32 5c    	imul   si,WORD PTR fs:[si+0x31],0x5c32
    1853:	05 28 00             	add    ax,0x28
    1856:	08 44 42             	or     BYTE PTR [si+0x42],al
    1859:	45                   	inc    bp
    185a:	64 69 74 31 33 60    	imul   si,WORD PTR fs:[si+0x31],0x6033
    1860:	05 28 00             	add    ax,0x28
    1863:	08 44 42             	or     BYTE PTR [si+0x42],al
    1866:	45                   	inc    bp
    1867:	64 69 74 31 35 64    	imul   si,WORD PTR fs:[si+0x31],0x6435
    186d:	05 28 00             	add    ax,0x28
    1870:	08 44 42             	or     BYTE PTR [si+0x42],al
    1873:	45                   	inc    bp
    1874:	64 69 74 31 36 68    	imul   si,WORD PTR fs:[si+0x31],0x6836
    187a:	05 28 00             	add    ax,0x28
    187d:	08 44 42             	or     BYTE PTR [si+0x42],al
    1880:	45                   	inc    bp
    1881:	64 69 74 31 37 6c    	imul   si,WORD PTR fs:[si+0x31],0x6c37
    1887:	05 28 00             	add    ax,0x28
    188a:	08 44 42             	or     BYTE PTR [si+0x42],al
    188d:	45                   	inc    bp
    188e:	64 69 74 31 39 70    	imul   si,WORD PTR fs:[si+0x31],0x7039
    1894:	05 04 00             	add    ax,0x4
    1897:	07                   	pop    es
    1898:	50                   	push   ax
    1899:	61                   	popa
    189a:	6e                   	outs   dx,BYTE PTR ds:[si]
    189b:	65 6c                	gs ins BYTE PTR es:[di],dx
    189d:	31 37                	xor    WORD PTR [bx],si
    189f:	74 05                	je     0x18a6
    18a1:	04 00                	add    al,0x0
    18a3:	07                   	pop    es
    18a4:	50                   	push   ax
    18a5:	61                   	popa
    18a6:	6e                   	outs   dx,BYTE PTR ds:[si]
    18a7:	65 6c                	gs ins BYTE PTR es:[di],dx
    18a9:	31 39                	xor    WORD PTR [bx+di],di
    18ab:	78 05                	js     0x18b2
    18ad:	04 00                	add    al,0x0
    18af:	07                   	pop    es
    18b0:	50                   	push   ax
    18b1:	61                   	popa
    18b2:	6e                   	outs   dx,BYTE PTR ds:[si]
    18b3:	65 6c                	gs ins BYTE PTR es:[di],dx
    18b5:	32 30                	xor    dh,BYTE PTR [bx+si]
    18b7:	7c 05                	jl     0x18be
    18b9:	04 00                	add    al,0x0
    18bb:	07                   	pop    es
    18bc:	50                   	push   ax
    18bd:	61                   	popa
    18be:	6e                   	outs   dx,BYTE PTR ds:[si]
    18bf:	65 6c                	gs ins BYTE PTR es:[di],dx
    18c1:	32 31                	xor    dh,BYTE PTR [bx+di]
    18c3:	80 05 04             	add    BYTE PTR [di],0x4
    18c6:	00 07                	add    BYTE PTR [bx],al
    18c8:	50                   	push   ax
    18c9:	61                   	popa
    18ca:	6e                   	outs   dx,BYTE PTR ds:[si]
    18cb:	65 6c                	gs ins BYTE PTR es:[di],dx
    18cd:	32 32                	xor    dh,BYTE PTR [bp+si]
    18cf:	84 05                	test   BYTE PTR [di],al
    18d1:	04 00                	add    al,0x0
    18d3:	07                   	pop    es
    18d4:	50                   	push   ax
    18d5:	61                   	popa
    18d6:	6e                   	outs   dx,BYTE PTR ds:[si]
    18d7:	65 6c                	gs ins BYTE PTR es:[di],dx
    18d9:	32 34                	xor    dh,BYTE PTR [si]
    18db:	88 05                	mov    BYTE PTR [di],al
    18dd:	04 00                	add    al,0x0
    18df:	07                   	pop    es
    18e0:	50                   	push   ax
    18e1:	61                   	popa
    18e2:	6e                   	outs   dx,BYTE PTR ds:[si]
    18e3:	65 6c                	gs ins BYTE PTR es:[di],dx
    18e5:	32 35                	xor    dh,BYTE PTR [di]
    18e7:	8c 05                	mov    WORD PTR [di],es
    18e9:	04 00                	add    al,0x0
    18eb:	07                   	pop    es
    18ec:	50                   	push   ax
    18ed:	61                   	popa
    18ee:	6e                   	outs   dx,BYTE PTR ds:[si]
    18ef:	65 6c                	gs ins BYTE PTR es:[di],dx
    18f1:	32 36 90 05          	xor    dh,BYTE PTR ds:0x590
    18f5:	04 00                	add    al,0x0
    18f7:	07                   	pop    es
    18f8:	50                   	push   ax
    18f9:	61                   	popa
    18fa:	6e                   	outs   dx,BYTE PTR ds:[si]
    18fb:	65 6c                	gs ins BYTE PTR es:[di],dx
    18fd:	32 38                	xor    bh,BYTE PTR [bx+si]
    18ff:	94                   	xchg   sp,ax
    1900:	05 04 00             	add    ax,0x4
    1903:	07                   	pop    es
    1904:	50                   	push   ax
    1905:	61                   	popa
    1906:	6e                   	outs   dx,BYTE PTR ds:[si]
    1907:	65 6c                	gs ins BYTE PTR es:[di],dx
    1909:	34 31                	xor    al,0x31
    190b:	98                   	cbw
    190c:	05 28 00             	add    ax,0x28
    190f:	08 44 42             	or     BYTE PTR [si+0x42],al
    1912:	45                   	inc    bp
    1913:	64 69 74 34 35 9c    	imul   si,WORD PTR fs:[si+0x34],0x9c35
    1919:	05 04 00             	add    ax,0x4
    191c:	07                   	pop    es
    191d:	50                   	push   ax
    191e:	61                   	popa
    191f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1920:	65 6c                	gs ins BYTE PTR es:[di],dx
    1922:	34 34                	xor    al,0x34
    1924:	a0 05 28             	mov    al,ds:0x2805
    1927:	00 08                	add    BYTE PTR [bx+si],cl
    1929:	44                   	inc    sp
    192a:	42                   	inc    dx
    192b:	45                   	inc    bp
    192c:	64 69 74 35 31 a4    	imul   si,WORD PTR fs:[si+0x35],0xa431
    1932:	05 04 00             	add    ax,0x4
    1935:	07                   	pop    es
    1936:	50                   	push   ax
    1937:	61                   	popa
    1938:	6e                   	outs   dx,BYTE PTR ds:[si]
    1939:	65 6c                	gs ins BYTE PTR es:[di],dx
    193b:	34 35                	xor    al,0x35
    193d:	a8 05                	test   al,0x5
    193f:	28 00                	sub    BYTE PTR [bx+si],al
    1941:	08 44 42             	or     BYTE PTR [si+0x42],al
    1944:	45                   	inc    bp
    1945:	64 69 74 35 33 ac    	imul   si,WORD PTR fs:[si+0x35],0xac33
    194b:	05 04 00             	add    ax,0x4
    194e:	07                   	pop    es
    194f:	50                   	push   ax
    1950:	61                   	popa
    1951:	6e                   	outs   dx,BYTE PTR ds:[si]
    1952:	65 6c                	gs ins BYTE PTR es:[di],dx
    1954:	31 38                	xor    WORD PTR [bx+si],di
    1956:	b0 05                	mov    al,0x5
    1958:	04 00                	add    al,0x0
    195a:	07                   	pop    es
    195b:	50                   	push   ax
    195c:	61                   	popa
    195d:	6e                   	outs   dx,BYTE PTR ds:[si]
    195e:	65 6c                	gs ins BYTE PTR es:[di],dx
    1960:	32 37                	xor    dh,BYTE PTR [bx]
    1962:	b4 05                	mov    ah,0x5
    1964:	28 00                	sub    BYTE PTR [bx+si],al
    1966:	08 44 42             	or     BYTE PTR [si+0x42],al
    1969:	45                   	inc    bp
    196a:	64 69 74 32 30 b8    	imul   si,WORD PTR fs:[si+0x32],0xb830
    1970:	05 28 00             	add    ax,0x28
    1973:	08 44 42             	or     BYTE PTR [si+0x42],al
    1976:	45                   	inc    bp
    1977:	64 69 74 32 31 bc    	imul   si,WORD PTR fs:[si+0x32],0xbc31
    197d:	05 28 00             	add    ax,0x28
    1980:	08 44 42             	or     BYTE PTR [si+0x42],al
    1983:	45                   	inc    bp
    1984:	64 69 74 34 36 c0    	imul   si,WORD PTR fs:[si+0x34],0xc036
    198a:	05 28 00             	add    ax,0x28
    198d:	08 44 42             	or     BYTE PTR [si+0x42],al
    1990:	45                   	inc    bp
    1991:	64 69 74 32 32 c4    	imul   si,WORD PTR fs:[si+0x32],0xc432
    1997:	05 28 00             	add    ax,0x28
    199a:	08 44 42             	or     BYTE PTR [si+0x42],al
    199d:	45                   	inc    bp
    199e:	64 69 74 32 34 c8    	imul   si,WORD PTR fs:[si+0x32],0xc834
    19a4:	05 28 00             	add    ax,0x28
    19a7:	08 44 42             	or     BYTE PTR [si+0x42],al
    19aa:	45                   	inc    bp
    19ab:	64 69 74 35 34 cc    	imul   si,WORD PTR fs:[si+0x35],0xcc34
    19b1:	05 28 00             	add    ax,0x28
    19b4:	08 44 42             	or     BYTE PTR [si+0x42],al
    19b7:	45                   	inc    bp
    19b8:	64 69 74 32 35 d0    	imul   si,WORD PTR fs:[si+0x32],0xd035
    19be:	05 28 00             	add    ax,0x28
    19c1:	08 44 42             	or     BYTE PTR [si+0x42],al
    19c4:	45                   	inc    bp
    19c5:	64 69 74 32 36 d4    	imul   si,WORD PTR fs:[si+0x32],0xd436
    19cb:	05 28 00             	add    ax,0x28
    19ce:	08 44 42             	or     BYTE PTR [si+0x42],al
    19d1:	45                   	inc    bp
    19d2:	64 69 74 32 37 d8    	imul   si,WORD PTR fs:[si+0x32],0xd837
    19d8:	05 28 00             	add    ax,0x28
    19db:	08 44 42             	or     BYTE PTR [si+0x42],al
    19de:	45                   	inc    bp
    19df:	64 69 74 32 38 dc    	imul   si,WORD PTR fs:[si+0x32],0xdc38
    19e5:	05 28 00             	add    ax,0x28
    19e8:	08 44 42             	or     BYTE PTR [si+0x42],al
    19eb:	45                   	inc    bp
    19ec:	64 69 74 35 32 e0    	imul   si,WORD PTR fs:[si+0x35],0xe032
    19f2:	05 04 00             	add    ax,0x4
    19f5:	07                   	pop    es
    19f6:	50                   	push   ax
    19f7:	61                   	popa
    19f8:	6e                   	outs   dx,BYTE PTR ds:[si]
    19f9:	65 6c                	gs ins BYTE PTR es:[di],dx
    19fb:	34 36                	xor    al,0x36
    19fd:	e4 05                	in     al,0x5
    19ff:	04 00                	add    al,0x0
    1a01:	07                   	pop    es
    1a02:	50                   	push   ax
    1a03:	61                   	popa
    1a04:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a05:	65 6c                	gs ins BYTE PTR es:[di],dx
    1a07:	35 35 e8             	xor    ax,0xe835
    1a0a:	05 28 00             	add    ax,0x28
    1a0d:	08 44 42             	or     BYTE PTR [si+0x42],al
    1a10:	45                   	inc    bp
    1a11:	64 69 74 31 38 ec    	imul   si,WORD PTR fs:[si+0x31],0xec38
    1a17:	05 04 00             	add    ax,0x4
    1a1a:	06                   	push   es
    1a1b:	50                   	push   ax
    1a1c:	61                   	popa
    1a1d:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a1e:	65 6c                	gs ins BYTE PTR es:[di],dx
    1a20:	39 f0                	cmp    ax,si
    1a22:	05 24 00             	add    ax,0x24
    1a25:	09 47 72             	or     WORD PTR [bx+0x72],ax
    1a28:	6f                   	outs   dx,WORD PTR ds:[si]
    1a29:	75 70                	jne    0x1a9b
    1a2b:	42                   	inc    dx
    1a2c:	6f                   	outs   dx,WORD PTR ds:[si]
    1a2d:	78 33                	js     0x1a62
    1a2f:	f4                   	hlt
    1a30:	05 28 00             	add    ax,0x28
    1a33:	08 44 42             	or     BYTE PTR [si+0x42],al
    1a36:	45                   	inc    bp
    1a37:	64 69 74 32 39 f8    	imul   si,WORD PTR fs:[si+0x32],0xf839
    1a3d:	05 28 00             	add    ax,0x28
    1a40:	08 44 42             	or     BYTE PTR [si+0x42],al
    1a43:	45                   	inc    bp
    1a44:	64 69 74 33 30 fc    	imul   si,WORD PTR fs:[si+0x33],0xfc30
    1a4a:	05 28 00             	add    ax,0x28
    1a4d:	08 44 42             	or     BYTE PTR [si+0x42],al
    1a50:	45                   	inc    bp
    1a51:	64 69 74 33 31 00    	imul   si,WORD PTR fs:[si+0x33],0x31
    1a57:	06                   	push   es
    1a58:	28 00                	sub    BYTE PTR [bx+si],al
    1a5a:	08 44 42             	or     BYTE PTR [si+0x42],al
    1a5d:	45                   	inc    bp
    1a5e:	64 69 74 33 32 04    	imul   si,WORD PTR fs:[si+0x33],0x432
    1a64:	06                   	push   es
    1a65:	28 00                	sub    BYTE PTR [bx+si],al
    1a67:	08 44 42             	or     BYTE PTR [si+0x42],al
    1a6a:	45                   	inc    bp
    1a6b:	64 69 74 33 33 08    	imul   si,WORD PTR fs:[si+0x33],0x833
    1a71:	06                   	push   es
    1a72:	04 00                	add    al,0x0
    1a74:	07                   	pop    es
    1a75:	50                   	push   ax
    1a76:	61                   	popa
    1a77:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a78:	65 6c                	gs ins BYTE PTR es:[di],dx
    1a7a:	32 39                	xor    bh,BYTE PTR [bx+di]
    1a7c:	0c 06                	or     al,0x6
    1a7e:	04 00                	add    al,0x0
    1a80:	07                   	pop    es
    1a81:	50                   	push   ax
    1a82:	61                   	popa
    1a83:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a84:	65 6c                	gs ins BYTE PTR es:[di],dx
    1a86:	33 31                	xor    si,WORD PTR [bx+di]
    1a88:	10 06 04 00          	adc    BYTE PTR ds:0x4,al
    1a8c:	07                   	pop    es
    1a8d:	50                   	push   ax
    1a8e:	61                   	popa
    1a8f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a90:	65 6c                	gs ins BYTE PTR es:[di],dx
    1a92:	33 32                	xor    si,WORD PTR [bp+si]
    1a94:	14 06                	adc    al,0x6
    1a96:	04 00                	add    al,0x0
    1a98:	07                   	pop    es
    1a99:	50                   	push   ax
    1a9a:	61                   	popa
    1a9b:	6e                   	outs   dx,BYTE PTR ds:[si]
    1a9c:	65 6c                	gs ins BYTE PTR es:[di],dx
    1a9e:	33 33                	xor    si,WORD PTR [bp+di]
    1aa0:	18 06 28 00          	sbb    BYTE PTR ds:0x28,al
    1aa4:	08 44 42             	or     BYTE PTR [si+0x42],al
    1aa7:	45                   	inc    bp
    1aa8:	64 69 74 33 39 1c    	imul   si,WORD PTR fs:[si+0x33],0x1c39
    1aae:	06                   	push   es
    1aaf:	04 00                	add    al,0x0
    1ab1:	07                   	pop    es
    1ab2:	50                   	push   ax
    1ab3:	61                   	popa
    1ab4:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ab5:	65 6c                	gs ins BYTE PTR es:[di],dx
    1ab7:	33 39                	xor    di,WORD PTR [bx+di]
    1ab9:	20 06 04 00          	and    BYTE PTR ds:0x4,al
    1abd:	07                   	pop    es
    1abe:	50                   	push   ax
    1abf:	61                   	popa
    1ac0:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ac1:	65 6c                	gs ins BYTE PTR es:[di],dx
    1ac3:	34 30                	xor    al,0x30
    1ac5:	24 06                	and    al,0x6
    1ac7:	28 00                	sub    BYTE PTR [bx+si],al
    1ac9:	08 44 42             	or     BYTE PTR [si+0x42],al
    1acc:	45                   	inc    bp
    1acd:	64 69 74 34 31 28    	imul   si,WORD PTR fs:[si+0x34],0x2831
    1ad3:	06                   	push   es
    1ad4:	28 00                	sub    BYTE PTR [bx+si],al
    1ad6:	08 44 42             	or     BYTE PTR [si+0x42],al
    1ad9:	45                   	inc    bp
    1ada:	64 69 74 34 32 2c    	imul   si,WORD PTR fs:[si+0x34],0x2c32
    1ae0:	06                   	push   es
    1ae1:	04 00                	add    al,0x0
    1ae3:	07                   	pop    es
    1ae4:	50                   	push   ax
    1ae5:	61                   	popa
    1ae6:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ae7:	65 6c                	gs ins BYTE PTR es:[di],dx
    1ae9:	33 30                	xor    si,WORD PTR [bx+si]
    1aeb:	30 06 04 00          	xor    BYTE PTR ds:0x4,al
    1aef:	07                   	pop    es
    1af0:	50                   	push   ax
    1af1:	61                   	popa
    1af2:	6e                   	outs   dx,BYTE PTR ds:[si]
    1af3:	65 6c                	gs ins BYTE PTR es:[di],dx
    1af5:	33 34                	xor    si,WORD PTR [si]
    1af7:	34 06                	xor    al,0x6
    1af9:	28 00                	sub    BYTE PTR [bx+si],al
    1afb:	08 44 42             	or     BYTE PTR [si+0x42],al
    1afe:	45                   	inc    bp
    1aff:	64 69 74 33 34 38    	imul   si,WORD PTR fs:[si+0x33],0x3834
    1b05:	06                   	push   es
    1b06:	28 00                	sub    BYTE PTR [bx+si],al
    1b08:	08 44 42             	or     BYTE PTR [si+0x42],al
    1b0b:	45                   	inc    bp
    1b0c:	64 69 74 34 33 3c    	imul   si,WORD PTR fs:[si+0x34],0x3c33
    1b12:	06                   	push   es
    1b13:	28 00                	sub    BYTE PTR [bx+si],al
    1b15:	08 44 42             	or     BYTE PTR [si+0x42],al
    1b18:	45                   	inc    bp
    1b19:	64 69 74 34 34 40    	imul   si,WORD PTR fs:[si+0x34],0x4034
    1b1f:	06                   	push   es
    1b20:	28 00                	sub    BYTE PTR [bx+si],al
    1b22:	08 44 42             	or     BYTE PTR [si+0x42],al
    1b25:	45                   	inc    bp
    1b26:	64 69 74 33 35 44    	imul   si,WORD PTR fs:[si+0x33],0x4435
    1b2c:	06                   	push   es
    1b2d:	28 00                	sub    BYTE PTR [bx+si],al
    1b2f:	08 44 42             	or     BYTE PTR [si+0x42],al
    1b32:	45                   	inc    bp
    1b33:	64 69 74 33 36 48    	imul   si,WORD PTR fs:[si+0x33],0x4836
    1b39:	06                   	push   es
    1b3a:	28 00                	sub    BYTE PTR [bx+si],al
    1b3c:	08 44 42             	or     BYTE PTR [si+0x42],al
    1b3f:	45                   	inc    bp
    1b40:	64 69 74 33 37 4c    	imul   si,WORD PTR fs:[si+0x33],0x4c37
    1b46:	06                   	push   es
    1b47:	28 00                	sub    BYTE PTR [bx+si],al
    1b49:	08 44 42             	or     BYTE PTR [si+0x42],al
    1b4c:	45                   	inc    bp
    1b4d:	64 69 74 33 38 50    	imul   si,WORD PTR fs:[si+0x33],0x5038
    1b53:	06                   	push   es
    1b54:	28 00                	sub    BYTE PTR [bx+si],al
    1b56:	08 44 42             	or     BYTE PTR [si+0x42],al
    1b59:	45                   	inc    bp
    1b5a:	64 69 74 34 30 54    	imul   si,WORD PTR fs:[si+0x34],0x5430
    1b60:	06                   	push   es
    1b61:	04 00                	add    al,0x0
    1b63:	07                   	pop    es
    1b64:	50                   	push   ax
    1b65:	61                   	popa
    1b66:	6e                   	outs   dx,BYTE PTR ds:[si]
    1b67:	65 6c                	gs ins BYTE PTR es:[di],dx
    1b69:	34 37                	xor    al,0x37
    1b6b:	58                   	pop    ax
    1b6c:	06                   	push   es
    1b6d:	04 00                	add    al,0x0
    1b6f:	07                   	pop    es
    1b70:	50                   	push   ax
    1b71:	61                   	popa
    1b72:	6e                   	outs   dx,BYTE PTR ds:[si]
    1b73:	65 6c                	gs ins BYTE PTR es:[di],dx
    1b75:	33 35                	xor    si,WORD PTR [di]
    1b77:	5c                   	pop    sp
    1b78:	06                   	push   es
    1b79:	04 00                	add    al,0x0
    1b7b:	07                   	pop    es
    1b7c:	50                   	push   ax
    1b7d:	61                   	popa
    1b7e:	6e                   	outs   dx,BYTE PTR ds:[si]
    1b7f:	65 6c                	gs ins BYTE PTR es:[di],dx
    1b81:	34 38                	xor    al,0x38
    1b83:	60                   	pusha
    1b84:	06                   	push   es
    1b85:	04 00                	add    al,0x0
    1b87:	07                   	pop    es
    1b88:	50                   	push   ax
    1b89:	61                   	popa
    1b8a:	6e                   	outs   dx,BYTE PTR ds:[si]
    1b8b:	65 6c                	gs ins BYTE PTR es:[di],dx
    1b8d:	35 32 64             	xor    ax,0x6432
    1b90:	06                   	push   es
    1b91:	04 00                	add    al,0x0
    1b93:	07                   	pop    es
    1b94:	50                   	push   ax
    1b95:	61                   	popa
    1b96:	6e                   	outs   dx,BYTE PTR ds:[si]
    1b97:	65 6c                	gs ins BYTE PTR es:[di],dx
    1b99:	35 33 68             	xor    ax,0x6833
    1b9c:	06                   	push   es
    1b9d:	04 00                	add    al,0x0
    1b9f:	07                   	pop    es
    1ba0:	50                   	push   ax
    1ba1:	61                   	popa
    1ba2:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ba3:	65 6c                	gs ins BYTE PTR es:[di],dx
    1ba5:	35 34 6c             	xor    ax,0x6c34
    1ba8:	06                   	push   es
    1ba9:	04 00                	add    al,0x0
    1bab:	07                   	pop    es
    1bac:	50                   	push   ax
    1bad:	61                   	popa
    1bae:	6e                   	outs   dx,BYTE PTR ds:[si]
    1baf:	65 6c                	gs ins BYTE PTR es:[di],dx
    1bb1:	33 36 70 06          	xor    si,WORD PTR ds:0x670
    1bb5:	04 00                	add    al,0x0
    1bb7:	07                   	pop    es
    1bb8:	50                   	push   ax
    1bb9:	61                   	popa
    1bba:	6e                   	outs   dx,BYTE PTR ds:[si]
    1bbb:	65 6c                	gs ins BYTE PTR es:[di],dx
    1bbd:	36 30 74 06          	xor    BYTE PTR ss:[si+0x6],dh
    1bc1:	04 00                	add    al,0x0
    1bc3:	07                   	pop    es
    1bc4:	50                   	push   ax
    1bc5:	61                   	popa
    1bc6:	6e                   	outs   dx,BYTE PTR ds:[si]
    1bc7:	65 6c                	gs ins BYTE PTR es:[di],dx
    1bc9:	36 31 78 06          	xor    WORD PTR ss:[bx+si+0x6],di
    1bcd:	2c 00                	sub    al,0x0
    1bcf:	07                   	pop    es
    1bd0:	4c                   	dec    sp
    1bd1:	61                   	popa
    1bd2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1bd5:	55                   	push   bp
    1bd6:	30 7c 06             	xor    BYTE PTR [si+0x6],bh
    1bd9:	2c 00                	sub    al,0x0
    1bdb:	07                   	pop    es
    1bdc:	4c                   	dec    sp
    1bdd:	61                   	popa
    1bde:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1be1:	55                   	push   bp
    1be2:	31 80 06 2c          	xor    WORD PTR [bx+si+0x2c06],ax
    1be6:	00 07                	add    BYTE PTR [bx],al
    1be8:	4c                   	dec    sp
    1be9:	61                   	popa
    1bea:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1bed:	55                   	push   bp
    1bee:	32 84 06 2c          	xor    al,BYTE PTR [si+0x2c06]
    1bf2:	00 07                	add    BYTE PTR [bx],al
    1bf4:	4c                   	dec    sp
    1bf5:	61                   	popa
    1bf6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    1bf9:	55                   	push   bp
    1bfa:	33 88 06 30          	xor    cx,WORD PTR [bx+si+0x3006]
    1bfe:	00 05                	add    BYTE PTR [di],al
    1c00:	4d                   	dec    bp
    1c01:	65 6d                	gs ins WORD PTR es:[di],dx
    1c03:	6f                   	outs   dx,WORD PTR ds:[si]
    1c04:	31 8c 06 08          	xor    WORD PTR [si+0x806],cx
    1c08:	00 08                	add    BYTE PTR [bx+si],cl
    1c0a:	45                   	inc    bp
    1c0b:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
    1c11:	31 90 06 08          	xor    WORD PTR [bx+si+0x806],dx
    1c15:	00 07                	add    BYTE PTR [bx],al
    1c17:	43                   	inc    bx
    1c18:	6f                   	outs   dx,WORD PTR ds:[si]
    1c19:	70 69                	jo     0x1c84
    1c1b:	65 72 31             	gs jb  0x1c4f
    1c1e:	94                   	xchg   sp,ax
    1c1f:	06                   	push   es
    1c20:	04 00                	add    al,0x0
    1c22:	06                   	push   es
    1c23:	50                   	push   ax
    1c24:	61                   	popa
    1c25:	6e                   	outs   dx,BYTE PTR ds:[si]
    1c26:	65 6c                	gs ins BYTE PTR es:[di],dx
    1c28:	31 98 06 28          	xor    WORD PTR [bx+si+0x2806],bx
    1c2c:	00 08                	add    BYTE PTR [bx+si],cl
    1c2e:	44                   	inc    sp
    1c2f:	42                   	inc    dx
    1c30:	45                   	inc    bp
    1c31:	64 69 74 35 37 9c    	imul   si,WORD PTR fs:[si+0x35],0x9c37
    1c37:	06                   	push   es
    1c38:	28 00                	sub    BYTE PTR [bx+si],al
    1c3a:	08 44 42             	or     BYTE PTR [si+0x42],al
    1c3d:	45                   	inc    bp
    1c3e:	64 69 74 35 38 a0    	imul   si,WORD PTR fs:[si+0x35],0xa038
    1c44:	06                   	push   es
    1c45:	20 00                	and    BYTE PTR [bx+si],al
    1c47:	13 54 61             	adc    dx,WORD PTR [si+0x61]
    1c4a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1c4d:	45                   	inc    bp
    1c4e:	52                   	push   dx
    1c4f:	47                   	inc    di
    1c50:	52                   	push   dx
    1c51:	65 70 61             	gs jo  0x1cb5
    1c54:	72 61                	jb     0x1cb7
    1c56:	74 69                	je     0x1cc1
    1c58:	6f                   	outs   dx,WORD PTR ds:[si]
    1c59:	6e                   	outs   dx,BYTE PTR ds:[si]
    1c5a:	73 a4                	jae    0x1c00
    1c5c:	06                   	push   es
    1c5d:	20 00                	and    BYTE PTR [bx+si],al
    1c5f:	15 54 61             	adc    ax,0x6154
    1c62:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1c65:	45                   	inc    bp
    1c66:	52                   	push   dx
    1c67:	47                   	inc    di
    1c68:	52                   	push   dx
    1c69:	65 6d                	gs ins WORD PTR es:[di],dx
    1c6b:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    1c6e:	72 73                	jb     0x1ce3
    1c70:	41                   	inc    cx
    1c71:	73 73                	jae    0x1ce6
    1c73:	75 72                	jne    0x1ce7
    1c75:	a8 06                	test   al,0x6
    1c77:	20 00                	and    BYTE PTR [bx+si],al
    1c79:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1c7c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1c7f:	45                   	inc    bp
    1c80:	52                   	push   dx
    1c81:	47                   	inc    di
    1c82:	49                   	dec    cx
    1c83:	6e                   	outs   dx,BYTE PTR ds:[si]
    1c84:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    1c8a:	74 69                	je     0x1cf5
    1c8c:	73 50                	jae    0x1cde
    1c8e:	65 72 73             	gs jb  0x1d04
    1c91:	6f                   	outs   dx,WORD PTR ds:[si]
    1c92:	6e                   	outs   dx,BYTE PTR ds:[si]
    1c93:	ac                   	lods   al,BYTE PTR ds:[si]
    1c94:	06                   	push   es
    1c95:	20 00                	and    BYTE PTR [bx+si],al
    1c97:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1c9a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1c9d:	45                   	inc    bp
    1c9e:	52                   	push   dx
    1c9f:	47                   	inc    di
    1ca0:	49                   	dec    cx
    1ca1:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ca2:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    1ca8:	74 69                	je     0x1d13
    1caa:	73 41                	jae    0x1ced
    1cac:	63 74 69             	arpl   WORD PTR [si+0x69],si
    1caf:	6f                   	outs   dx,WORD PTR ds:[si]
    1cb0:	6e                   	outs   dx,BYTE PTR ds:[si]
    1cb1:	b0 06                	mov    al,0x6
    1cb3:	20 00                	and    BYTE PTR [bx+si],al
    1cb5:	10 54 61             	adc    BYTE PTR [si+0x61],dl
    1cb8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1cbb:	45                   	inc    bp
    1cbc:	52                   	push   dx
    1cbd:	47                   	inc    di
    1cbe:	47                   	inc    di
    1cbf:	72 65                	jb     0x1d26
    1cc1:	76 65                	jbe    0x1d28
    1cc3:	73 50                	jae    0x1d15
    1cc5:	63 b4 06 14          	arpl   WORD PTR [si+0x1406],si
    1cc9:	00 1c                	add    BYTE PTR [si],bl
    1ccb:	54                   	push   sp
    1ccc:	61                   	popa
    1ccd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1cd0:	45                   	inc    bp
    1cd1:	52                   	push   dx
    1cd2:	47                   	inc    di
    1cd3:	4d                   	dec    bp
    1cd4:	61                   	popa
    1cd5:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1cd8:	6e                   	outs   dx,BYTE PTR ds:[si]
    1cd9:	65 73 44             	gs jae 0x1d20
    1cdc:	65 74 72             	gs je  0x1d51
    1cdf:	75 69                	jne    0x1d4a
    1ce1:	74 65                	je     0x1d48
    1ce3:	73 51                	jae    0x1d36
    1ce5:	74 65                	je     0x1d4c
    1ce7:	b8 06 14             	mov    ax,0x1406
    1cea:	00 17                	add    BYTE PTR [bx],dl
    1cec:	54                   	push   sp
    1ced:	61                   	popa
    1cee:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1cf1:	45                   	inc    bp
    1cf2:	52                   	push   dx
    1cf3:	47                   	inc    di
    1cf4:	53                   	push   bx
    1cf5:	74 6f                	je     0x1d66
    1cf7:	63 6b 44             	arpl   WORD PTR [bp+di+0x44],bp
    1cfa:	65 74 72             	gs je  0x1d6f
    1cfd:	75 69                	jne    0x1d68
    1cff:	74 51                	je     0x1d52
    1d01:	74 65                	je     0x1d68
    1d03:	bc 06 14             	mov    sp,0x1406
    1d06:	00 1c                	add    BYTE PTR [si],bl
    1d08:	54                   	push   sp
    1d09:	61                   	popa
    1d0a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1d0d:	45                   	inc    bp
    1d0e:	52                   	push   dx
    1d0f:	47                   	inc    di
    1d10:	44                   	inc    sp
    1d11:	65 6d                	gs ins WORD PTR es:[di],dx
    1d13:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    1d18:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d19:	73 50                	jae    0x1d6b
    1d1b:	72 6f                	jb     0x1d8c
    1d1d:	64 75 63             	fs jne 0x1d83
    1d20:	74 69                	je     0x1d8b
    1d22:	66 73 c0             	data32 jae 0x1ce5
    1d25:	06                   	push   es
    1d26:	14 00                	adc    al,0x0
    1d28:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
    1d2b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1d2e:	45                   	inc    bp
    1d2f:	52                   	push   dx
    1d30:	47                   	inc    di
    1d31:	44                   	inc    sp
    1d32:	65 6d                	gs ins WORD PTR es:[di],dx
    1d34:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    1d39:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d3a:	73 56                	jae    0x1d92
    1d3c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1d3e:	64 65 75 72          	fs gs jne 0x1db4
    1d42:	73 c4                	jae    0x1d08
    1d44:	06                   	push   es
    1d45:	14 00                	adc    al,0x0
    1d47:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1d4a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1d4d:	45                   	inc    bp
    1d4e:	52                   	push   dx
    1d4f:	50                   	push   ax
    1d50:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
    1d53:	6f                   	outs   dx,WORD PTR ds:[si]
    1d54:	64 75 63             	fs jne 0x1dba
    1d57:	74 69                	je     0x1dc2
    1d59:	6f                   	outs   dx,WORD PTR ds:[si]
    1d5a:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d5b:	52                   	push   dx
    1d5c:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    1d5f:	6c                   	ins    BYTE PTR es:[di],dx
    1d60:	65 c8 06 14 00       	gs enter 0x1406,0x0
    1d65:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1d68:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1d6b:	45                   	inc    bp
    1d6c:	52                   	push   dx
    1d6d:	50                   	push   ax
    1d6e:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
    1d71:	6f                   	outs   dx,WORD PTR ds:[si]
    1d72:	64 75 63             	fs jne 0x1dd8
    1d75:	74 69                	je     0x1de0
    1d77:	6f                   	outs   dx,WORD PTR ds:[si]
    1d78:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d79:	52                   	push   dx
    1d7a:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    1d7d:	6c                   	ins    BYTE PTR es:[di],dx
    1d7e:	65 cc                	gs int3
    1d80:	06                   	push   es
    1d81:	04 00                	add    al,0x0
    1d83:	07                   	pop    es
    1d84:	50                   	push   ax
    1d85:	61                   	popa
    1d86:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d87:	65 6c                	gs ins BYTE PTR es:[di],dx
    1d89:	32 33                	xor    dh,BYTE PTR [bp+di]
    1d8b:	d0 06 28 00          	rol    BYTE PTR ds:0x28,1
    1d8f:	08 44 42             	or     BYTE PTR [si+0x42],al
    1d92:	45                   	inc    bp
    1d93:	64 69 74 31 34 d4    	imul   si,WORD PTR fs:[si+0x31],0xd434
    1d99:	06                   	push   es
    1d9a:	28 00                	sub    BYTE PTR [bx+si],al
    1d9c:	08 44 42             	or     BYTE PTR [si+0x42],al
    1d9f:	45                   	inc    bp
    1da0:	64 69 74 32 33 d8    	imul   si,WORD PTR fs:[si+0x32],0xd833
    1da6:	06                   	push   es
    1da7:	04 00                	add    al,0x0
    1da9:	07                   	pop    es
    1daa:	50                   	push   ax
    1dab:	61                   	popa
    1dac:	6e                   	outs   dx,BYTE PTR ds:[si]
    1dad:	65 6c                	gs ins BYTE PTR es:[di],dx
    1daf:	35 39 dc             	xor    ax,0xdc39
    1db2:	06                   	push   es
    1db3:	28 00                	sub    BYTE PTR [bx+si],al
    1db5:	08 44 42             	or     BYTE PTR [si+0x42],al
    1db8:	45                   	inc    bp
    1db9:	64 69 74 35 35 e0    	imul   si,WORD PTR fs:[si+0x35],0xe035
    1dbf:	06                   	push   es
    1dc0:	28 00                	sub    BYTE PTR [bx+si],al
    1dc2:	08 44 42             	or     BYTE PTR [si+0x42],al
    1dc5:	45                   	inc    bp
    1dc6:	64 69 74 35 36 e4    	imul   si,WORD PTR fs:[si+0x35],0xe436
    1dcc:	06                   	push   es
    1dcd:	04 00                	add    al,0x0
    1dcf:	07                   	pop    es
    1dd0:	50                   	push   ax
    1dd1:	61                   	popa
    1dd2:	6e                   	outs   dx,BYTE PTR ds:[si]
    1dd3:	65 6c                	gs ins BYTE PTR es:[di],dx
    1dd5:	35 36 e8             	xor    ax,0xe836
    1dd8:	06                   	push   es
    1dd9:	04 00                	add    al,0x0
    1ddb:	07                   	pop    es
    1ddc:	50                   	push   ax
    1ddd:	61                   	popa
    1dde:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ddf:	65 6c                	gs ins BYTE PTR es:[di],dx
    1de1:	35 37 ec             	xor    ax,0xec37
    1de4:	06                   	push   es
    1de5:	04 00                	add    al,0x0
    1de7:	07                   	pop    es
    1de8:	50                   	push   ax
    1de9:	61                   	popa
    1dea:	6e                   	outs   dx,BYTE PTR ds:[si]
    1deb:	65 6c                	gs ins BYTE PTR es:[di],dx
    1ded:	36 32 f0             	ss xor dh,al
    1df0:	06                   	push   es
    1df1:	04 00                	add    al,0x0
    1df3:	07                   	pop    es
    1df4:	50                   	push   ax
    1df5:	61                   	popa
    1df6:	6e                   	outs   dx,BYTE PTR ds:[si]
    1df7:	65 6c                	gs ins BYTE PTR es:[di],dx
    1df9:	36 33 f4             	ss xor si,sp
    1dfc:	06                   	push   es
    1dfd:	28 00                	sub    BYTE PTR [bx+si],al
    1dff:	08 44 42             	or     BYTE PTR [si+0x42],al
    1e02:	45                   	inc    bp
    1e03:	64 69 74 35 39 f8    	imul   si,WORD PTR fs:[si+0x35],0xf839
    1e09:	06                   	push   es
    1e0a:	28 00                	sub    BYTE PTR [bx+si],al
    1e0c:	08 44 42             	or     BYTE PTR [si+0x42],al
    1e0f:	45                   	inc    bp
    1e10:	64 69 74 36 30 fc    	imul   si,WORD PTR fs:[si+0x36],0xfc30
    1e16:	06                   	push   es
    1e17:	28 00                	sub    BYTE PTR [bx+si],al
    1e19:	08 44 42             	or     BYTE PTR [si+0x42],al
    1e1c:	45                   	inc    bp
    1e1d:	64 69 74 36 31 00    	imul   si,WORD PTR fs:[si+0x36],0x31
    1e23:	07                   	pop    es
    1e24:	28 00                	sub    BYTE PTR [bx+si],al
    1e26:	08 44 42             	or     BYTE PTR [si+0x42],al
    1e29:	45                   	inc    bp
    1e2a:	64 69 74 36 32 04    	imul   si,WORD PTR fs:[si+0x36],0x432
    1e30:	07                   	pop    es
    1e31:	20 00                	and    BYTE PTR [bx+si],al
    1e33:	17                   	pop    ss
    1e34:	54                   	push   sp
    1e35:	61                   	popa
    1e36:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1e39:	45                   	inc    bp
    1e3a:	52                   	push   dx
    1e3b:	47                   	inc    di
    1e3c:	5f                   	pop    di
    1e3d:	6f                   	outs   dx,WORD PTR ds:[si]
    1e3e:	6c                   	ins    BYTE PTR es:[di],dx
    1e3f:	64 52                	fs push dx
    1e41:	65 70 61             	gs jo  0x1ea5
    1e44:	72 61                	jb     0x1ea7
    1e46:	74 69                	je     0x1eb1
    1e48:	6f                   	outs   dx,WORD PTR ds:[si]
    1e49:	6e                   	outs   dx,BYTE PTR ds:[si]
    1e4a:	73 08                	jae    0x1e54
    1e4c:	07                   	pop    es
    1e4d:	20 00                	and    BYTE PTR [bx+si],al
    1e4f:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1e52:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1e55:	45                   	inc    bp
    1e56:	52                   	push   dx
    1e57:	47                   	inc    di
    1e58:	5f                   	pop    di
    1e59:	6f                   	outs   dx,WORD PTR ds:[si]
    1e5a:	6c                   	ins    BYTE PTR es:[di],dx
    1e5b:	64 52                	fs push dx
    1e5d:	65 6d                	gs ins WORD PTR es:[di],dx
    1e5f:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    1e62:	72 73                	jb     0x1ed7
    1e64:	41                   	inc    cx
    1e65:	73 73                	jae    0x1eda
    1e67:	75 72                	jne    0x1edb
    1e69:	0c 07                	or     al,0x7
    1e6b:	20 00                	and    BYTE PTR [bx+si],al
    1e6d:	1d 54 61             	sbb    ax,0x6154
    1e70:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1e73:	45                   	inc    bp
    1e74:	52                   	push   dx
    1e75:	47                   	inc    di
    1e76:	5f                   	pop    di
    1e77:	6f                   	outs   dx,WORD PTR ds:[si]
    1e78:	6c                   	ins    BYTE PTR es:[di],dx
    1e79:	64 49                	fs dec cx
    1e7b:	6e                   	outs   dx,BYTE PTR ds:[si]
    1e7c:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    1e82:	74 69                	je     0x1eed
    1e84:	73 50                	jae    0x1ed6
    1e86:	65 72 73             	gs jb  0x1efc
    1e89:	6f                   	outs   dx,WORD PTR ds:[si]
    1e8a:	6e                   	outs   dx,BYTE PTR ds:[si]
    1e8b:	10 07                	adc    BYTE PTR [bx],al
    1e8d:	20 00                	and    BYTE PTR [bx+si],al
    1e8f:	1d 54 61             	sbb    ax,0x6154
    1e92:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1e95:	45                   	inc    bp
    1e96:	52                   	push   dx
    1e97:	47                   	inc    di
    1e98:	5f                   	pop    di
    1e99:	6f                   	outs   dx,WORD PTR ds:[si]
    1e9a:	6c                   	ins    BYTE PTR es:[di],dx
    1e9b:	64 49                	fs dec cx
    1e9d:	6e                   	outs   dx,BYTE PTR ds:[si]
    1e9e:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    1ea4:	74 69                	je     0x1f0f
    1ea6:	73 41                	jae    0x1ee9
    1ea8:	63 74 69             	arpl   WORD PTR [si+0x69],si
    1eab:	6f                   	outs   dx,WORD PTR ds:[si]
    1eac:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ead:	14 07                	adc    al,0x7
    1eaf:	20 00                	and    BYTE PTR [bx+si],al
    1eb1:	14 54                	adc    al,0x54
    1eb3:	61                   	popa
    1eb4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1eb7:	45                   	inc    bp
    1eb8:	52                   	push   dx
    1eb9:	47                   	inc    di
    1eba:	5f                   	pop    di
    1ebb:	6f                   	outs   dx,WORD PTR ds:[si]
    1ebc:	6c                   	ins    BYTE PTR es:[di],dx
    1ebd:	64 47                	fs inc di
    1ebf:	72 65                	jb     0x1f26
    1ec1:	76 65                	jbe    0x1f28
    1ec3:	73 50                	jae    0x1f15
    1ec5:	63 18                	arpl   WORD PTR [bx+si],bx
    1ec7:	07                   	pop    es
    1ec8:	14 00                	adc    al,0x0
    1eca:	20 54 61             	and    BYTE PTR [si+0x61],dl
    1ecd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1ed0:	45                   	inc    bp
    1ed1:	52                   	push   dx
    1ed2:	47                   	inc    di
    1ed3:	5f                   	pop    di
    1ed4:	6f                   	outs   dx,WORD PTR ds:[si]
    1ed5:	6c                   	ins    BYTE PTR es:[di],dx
    1ed6:	64 4d                	fs dec bp
    1ed8:	61                   	popa
    1ed9:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1edc:	6e                   	outs   dx,BYTE PTR ds:[si]
    1edd:	65 73 44             	gs jae 0x1f24
    1ee0:	65 74 72             	gs je  0x1f55
    1ee3:	75 69                	jne    0x1f4e
    1ee5:	74 65                	je     0x1f4c
    1ee7:	73 51                	jae    0x1f3a
    1ee9:	74 65                	je     0x1f50
    1eeb:	1c 07                	sbb    al,0x7
    1eed:	14 00                	adc    al,0x0
    1eef:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
    1ef2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1ef5:	45                   	inc    bp
    1ef6:	52                   	push   dx
    1ef7:	47                   	inc    di
    1ef8:	5f                   	pop    di
    1ef9:	6f                   	outs   dx,WORD PTR ds:[si]
    1efa:	6c                   	ins    BYTE PTR es:[di],dx
    1efb:	64 53                	fs push bx
    1efd:	74 6f                	je     0x1f6e
    1eff:	63 6b 44             	arpl   WORD PTR [bp+di+0x44],bp
    1f02:	65 74 72             	gs je  0x1f77
    1f05:	75 69                	jne    0x1f70
    1f07:	74 51                	je     0x1f5a
    1f09:	74 65                	je     0x1f70
    1f0b:	20 07                	and    BYTE PTR [bx],al
    1f0d:	14 00                	adc    al,0x0
    1f0f:	20 54 61             	and    BYTE PTR [si+0x61],dl
    1f12:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1f15:	45                   	inc    bp
    1f16:	52                   	push   dx
    1f17:	47                   	inc    di
    1f18:	5f                   	pop    di
    1f19:	6f                   	outs   dx,WORD PTR ds:[si]
    1f1a:	6c                   	ins    BYTE PTR es:[di],dx
    1f1b:	64 44                	fs inc sp
    1f1d:	65 6d                	gs ins WORD PTR es:[di],dx
    1f1f:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    1f24:	6e                   	outs   dx,BYTE PTR ds:[si]
    1f25:	73 50                	jae    0x1f77
    1f27:	72 6f                	jb     0x1f98
    1f29:	64 75 63             	fs jne 0x1f8f
    1f2c:	74 69                	je     0x1f97
    1f2e:	66 73 24             	data32 jae 0x1f55
    1f31:	07                   	pop    es
    1f32:	14 00                	adc    al,0x0
    1f34:	1e                   	push   ds
    1f35:	54                   	push   sp
    1f36:	61                   	popa
    1f37:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1f3a:	45                   	inc    bp
    1f3b:	52                   	push   dx
    1f3c:	47                   	inc    di
    1f3d:	5f                   	pop    di
    1f3e:	6f                   	outs   dx,WORD PTR ds:[si]
    1f3f:	6c                   	ins    BYTE PTR es:[di],dx
    1f40:	64 44                	fs inc sp
    1f42:	65 6d                	gs ins WORD PTR es:[di],dx
    1f44:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    1f49:	6e                   	outs   dx,BYTE PTR ds:[si]
    1f4a:	73 56                	jae    0x1fa2
    1f4c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1f4e:	64 65 75 72          	fs gs jne 0x1fc4
    1f52:	73 28                	jae    0x1f7c
    1f54:	07                   	pop    es
    1f55:	20 00                	and    BYTE PTR [bx+si],al
    1f57:	10 54 61             	adc    BYTE PTR [si+0x61],dl
    1f5a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1f5d:	45                   	inc    bp
    1f5e:	52                   	push   dx
    1f5f:	47                   	inc    di
    1f60:	50                   	push   ax
    1f61:	61                   	popa
    1f62:	6e                   	outs   dx,BYTE PTR ds:[si]
    1f63:	6e                   	outs   dx,BYTE PTR ds:[si]
    1f64:	65 73 50             	gs jae 0x1fb7
    1f67:	63 2c                	arpl   WORD PTR [si],bp
    1f69:	07                   	pop    es
    1f6a:	20 00                	and    BYTE PTR [bx+si],al
    1f6c:	14 54                	adc    al,0x54
    1f6e:	61                   	popa
    1f6f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1f72:	45                   	inc    bp
    1f73:	52                   	push   dx
    1f74:	47                   	inc    di
    1f75:	5f                   	pop    di
    1f76:	6f                   	outs   dx,WORD PTR ds:[si]
    1f77:	6c                   	ins    BYTE PTR es:[di],dx
    1f78:	64 50                	fs push ax
    1f7a:	61                   	popa
    1f7b:	6e                   	outs   dx,BYTE PTR ds:[si]
    1f7c:	6e                   	outs   dx,BYTE PTR ds:[si]
    1f7d:	65 73 50             	gs jae 0x1fd0
    1f80:	63 30                	arpl   WORD PTR [bx+si],si
    1f82:	07                   	pop    es
    1f83:	10 00                	adc    BYTE PTR [bx+si],al
    1f85:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    1f88:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1f8b:	45                   	inc    bp
    1f8c:	52                   	push   dx
    1f8d:	50                   	push   ax
    1f8e:	31 54 61             	xor    WORD PTR [si+0x61],dx
    1f91:	75 78                	jne    0x200b
    1f93:	55                   	push   bp
    1f94:	74 69                	je     0x1fff
    1f96:	6c                   	ins    BYTE PTR es:[di],dx
    1f97:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    1f9c:	6f                   	outs   dx,WORD PTR ds:[si]
    1f9d:	6e                   	outs   dx,BYTE PTR ds:[si]
    1f9e:	34 07                	xor    al,0x7
    1fa0:	10 00                	adc    BYTE PTR [bx+si],al
    1fa2:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    1fa5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1fa8:	45                   	inc    bp
    1fa9:	52                   	push   dx
    1faa:	50                   	push   ax
    1fab:	32 54 61             	xor    dl,BYTE PTR [si+0x61]
    1fae:	75 78                	jne    0x2028
    1fb0:	55                   	push   bp
    1fb1:	74 69                	je     0x201c
    1fb3:	6c                   	ins    BYTE PTR es:[di],dx
    1fb4:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    1fb9:	6f                   	outs   dx,WORD PTR ds:[si]
    1fba:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fbb:	38 07                	cmp    BYTE PTR [bx],al
    1fbd:	20 00                	and    BYTE PTR [bx+si],al
    1fbf:	1c 54                	sbb    al,0x54
    1fc1:	61                   	popa
    1fc2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1fc5:	45                   	inc    bp
    1fc6:	52                   	push   dx
    1fc7:	47                   	inc    di
    1fc8:	5f                   	pop    di
    1fc9:	6f                   	outs   dx,WORD PTR ds:[si]
    1fca:	6c                   	ins    BYTE PTR es:[di],dx
    1fcb:	64 41                	fs inc cx
    1fcd:	67 65 4d             	addr32 gs dec bp
    1fd0:	6f                   	outs   dx,WORD PTR ds:[si]
    1fd1:	79 65                	jns    0x2038
    1fd3:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fd4:	4d                   	dec    bp
    1fd5:	61                   	popa
    1fd6:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1fd9:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fda:	65 73 3c             	gs jae 0x2019
    1fdd:	07                   	pop    es
    1fde:	20 00                	and    BYTE PTR [bx+si],al
    1fe0:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
    1fe3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1fe6:	45                   	inc    bp
    1fe7:	52                   	push   dx
    1fe8:	47                   	inc    di
    1fe9:	5f                   	pop    di
    1fea:	6f                   	outs   dx,WORD PTR ds:[si]
    1feb:	6c                   	ins    BYTE PTR es:[di],dx
    1fec:	64 50                	fs push ax
    1fee:	72 69                	jb     0x2059
    1ff0:	6d                   	ins    WORD PTR es:[di],dx
    1ff1:	65 73 41             	gs jae 0x2035
    1ff4:	73 73                	jae    0x2069
    1ff6:	75 72                	jne    0x206a
    1ff8:	61                   	popa
    1ff9:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ffa:	63 65 40             	arpl   WORD PTR [di+0x40],sp
    1ffd:	07                   	pop    es
    1ffe:	20 00                	and    BYTE PTR [bx+si],al
    2000:	1d 54 61             	sbb    ax,0x6154
    2003:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    2006:	45                   	inc    bp
    2007:	52                   	push   dx
    2008:	47                   	inc    di
    2009:	5f                   	pop    di
    200a:	6f                   	outs   dx,WORD PTR ds:[si]
    200b:	6c                   	ins    BYTE PTR es:[di],dx
    200c:	64 45                	fs inc bp
    200e:	6e                   	outs   dx,BYTE PTR ds:[si]
    200f:	74 72                	je     0x2083
    2011:	65 74 69             	gs je  0x207d
    2014:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2016:	4d                   	dec    bp
    2017:	61                   	popa
    2018:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    201b:	6e                   	outs   dx,BYTE PTR ds:[si]
    201c:	65 73 44             	gs jae 0x2063
    201f:	07                   	pop    es
    2020:	20 00                	and    BYTE PTR [bx+si],al
    2022:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    2025:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    2028:	45                   	inc    bp
    2029:	52                   	push   dx
    202a:	47                   	inc    di
    202b:	41                   	inc    cx
    202c:	67 65 4d             	addr32 gs dec bp
    202f:	6f                   	outs   dx,WORD PTR ds:[si]
    2030:	79 65                	jns    0x2097
    2032:	6e                   	outs   dx,BYTE PTR ds:[si]
    2033:	4d                   	dec    bp
    2034:	61                   	popa
    2035:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    2038:	6e                   	outs   dx,BYTE PTR ds:[si]
    2039:	65 73 48             	gs jae 0x2084
    203c:	07                   	pop    es
    203d:	20 00                	and    BYTE PTR [bx+si],al
    203f:	17                   	pop    ss
    2040:	54                   	push   sp
    2041:	61                   	popa
    2042:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    2045:	45                   	inc    bp
    2046:	52                   	push   dx
    2047:	47                   	inc    di
    2048:	50                   	push   ax
    2049:	72 69                	jb     0x20b4
    204b:	6d                   	ins    WORD PTR es:[di],dx
    204c:	65 73 41             	gs jae 0x2090
    204f:	73 73                	jae    0x20c4
    2051:	75 72                	jne    0x20c5
    2053:	61                   	popa
    2054:	6e                   	outs   dx,BYTE PTR ds:[si]
    2055:	63 65 4c             	arpl   WORD PTR [di+0x4c],sp
    2058:	07                   	pop    es
    2059:	20 00                	and    BYTE PTR [bx+si],al
    205b:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    205e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    2061:	45                   	inc    bp
    2062:	52                   	push   dx
    2063:	47                   	inc    di
    2064:	45                   	inc    bp
    2065:	6e                   	outs   dx,BYTE PTR ds:[si]
    2066:	74 72                	je     0x20da
    2068:	65 74 69             	gs je  0x20d4
    206b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    206d:	4d                   	dec    bp
    206e:	61                   	popa
    206f:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    2072:	6e                   	outs   dx,BYTE PTR ds:[si]
    2073:	65 73 50             	gs jae 0x20c6
    2076:	07                   	pop    es
    2077:	08 00                	or     BYTE PTR [bx+si],al
    2079:	0f 41 75 74          	cmovno si,WORD PTR [di+0x74]
    207d:	72 65                	jb     0x20e4
    207f:	73 72                	jae    0x20f3
    2081:	73 75                	jae    0x20f8
    2083:	6c                   	ins    BYTE PTR es:[di],dx
    2084:	74 61                	je     0x20e7
    2086:	74 73                	je     0x20fb
    2088:	31 54 07             	xor    WORD PTR [si+0x7],dx
    208b:	08 00                	or     BYTE PTR [bx+si],al
    208d:	13 52 61             	adc    dx,WORD PTR [bp+si+0x61]
    2090:	70 70                	jo     0x2102
    2092:	65 6c                	gs ins BYTE PTR es:[di],dx
    2094:	44                   	inc    sp
    2095:	65 73 44             	gs jae 0x20dc
    2098:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
    209c:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
    20a1:	58                   	pop    ax
    20a2:	07                   	pop    es
    20a3:	08 00                	or     BYTE PTR [bx+si],al
    20a5:	02 4e 34             	add    cl,BYTE PTR [bp+0x34]
    20a8:	5c                   	pop    sp
    20a9:	07                   	pop    es
    20aa:	08 00                	or     BYTE PTR [bx+si],al
    20ac:	14 54                	adc    al,0x54
    20ae:	61                   	popa
    20af:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    20b2:	61                   	popa
    20b3:	75 44                	jne    0x20f9
    20b5:	65 54                	gs push sp
    20b7:	72 65                	jb     0x211e
    20b9:	73 6f                	jae    0x212a
    20bb:	72 65                	jb     0x2122
    20bd:	72 69                	jb     0x2128
    20bf:	65 31 60 07          	xor    WORD PTR gs:[bx+si+0x7],sp
    20c3:	08 00                	or     BYTE PTR [bx+si],al
    20c5:	15 54 61             	adc    ax,0x6154
    20c8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    20cb:	61                   	popa
    20cc:	75 44                	jne    0x2112
    20ce:	65 46                	gs inc si
    20d0:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    20d5:	65 6d                	gs ins WORD PTR es:[di],dx
    20d7:	65 6e                	outs   dx,BYTE PTR gs:[si]
    20d9:	74 31                	je     0x210c
    20db:	64 07                	fs pop es
    20dd:	08 00                	or     BYTE PTR [bx+si],al
    20df:	06                   	push   es
    20e0:	42                   	inc    dx
    20e1:	69 6c 61 6e 31       	imul   bp,WORD PTR [si+0x61],0x316e
    20e6:	68 07 08             	push   0x807
    20e9:	00 12                	add    BYTE PTR [bp+si],dl
    20eb:	43                   	inc    bx
    20ec:	6f                   	outs   dx,WORD PTR ds:[si]
    20ed:	6d                   	ins    WORD PTR es:[di],dx
    20ee:	70 74                	jo     0x2164
    20f0:	65 44                	gs inc sp
    20f2:	65 52                	gs push dx
    20f4:	65 73 75             	gs jae 0x216c
    20f7:	6c                   	ins    BYTE PTR es:[di],dx
    20f8:	74 61                	je     0x215b
    20fa:	74 73                	je     0x216f
    20fc:	31 6c 07             	xor    WORD PTR [si+0x7],bp
    20ff:	08 00                	or     BYTE PTR [bx+si],al
    2101:	0a 53 69             	or     dl,BYTE PTR [bp+di+0x69]
    2104:	74 75                	je     0x217b
    2106:	61                   	popa
    2107:	74 69                	je     0x2172
    2109:	6f                   	outs   dx,WORD PTR ds:[si]
    210a:	6e                   	outs   dx,BYTE PTR ds:[si]
    210b:	31 70 07             	xor    WORD PTR [bx+si+0x7],si
    210e:	08 00                	or     BYTE PTR [bx+si],al
    2110:	05 4e 31             	add    ax,0x314e
    2113:	30 30                	xor    BYTE PTR [bx+si],dh
    2115:	31 74 07             	xor    WORD PTR [si+0x7],si
    2118:	08 00                	or     BYTE PTR [bx+si],al
    211a:	05 4e 31             	add    ax,0x314e
    211d:	35 30 31             	xor    ax,0x3130
    2120:	78 07                	js     0x2129
    2122:	08 00                	or     BYTE PTR [bx+si],al
    2124:	05 4e 32             	add    ax,0x324e
    2127:	30 30                	xor    BYTE PTR [bx+si],dh
    2129:	31 7c 07             	xor    WORD PTR [si+0x7],di
    212c:	08 00                	or     BYTE PTR [bx+si],al
    212e:	04 4e                	add    al,0x4e
    2130:	37                   	aaa
    2131:	35 31 80             	xor    ax,0x8031
    2134:	07                   	pop    es
    2135:	08 00                	or     BYTE PTR [bx+si],al
    2137:	04 4e                	add    al,0x4e
    2139:	35 30 31             	xor    ax,0x3130
    213c:	84 07                	test   BYTE PTR [bx],al
    213e:	08 00                	or     BYTE PTR [bx+si],al
    2140:	02 4e 35             	add    cl,BYTE PTR [bp+0x35]
    2143:	88 07                	mov    BYTE PTR [bx],al
    2145:	08 00                	or     BYTE PTR [bx+si],al
    2147:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
    214a:	70 72                	jo     0x21be
    214c:	65 73 73             	gs jae 0x21c2
    214f:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
    2154:	70 69                	jo     0x21bf
    2156:	64 65 31 8c 07 08    	fs xor WORD PTR gs:[si+0x807],cx
    215c:	00 02                	add    BYTE PTR [bp+si],al
    215e:	4e                   	dec    si
    215f:	36 90                	ss nop
    2161:	07                   	pop    es
    2162:	08 00                	or     BYTE PTR [bx+si],al
    2164:	05 4e 31             	add    ax,0x314e
    2167:	32 35                	xor    dh,BYTE PTR [di]
    2169:	31 94 07 08          	xor    WORD PTR [si+0x807],dx
    216d:	00 08                	add    BYTE PTR [bx+si],cl
    216f:	50                   	push   ax
    2170:	65 72 69             	gs jb  0x21dc
    2173:	6f                   	outs   dx,WORD PTR ds:[si]
    2174:	64 65 32 98 07 08    	fs xor bl,BYTE PTR gs:[bx+si+0x807]
    217a:	00 06 61 75          	add    BYTE PTR ds:0x7561,al
    217e:	74 72                	je     0x21f2
    2180:	65 31 9c 07 08       	xor    WORD PTR gs:[si+0x807],bx
    2185:	00 04                	add    BYTE PTR [si],al
    2187:	4e                   	dec    si
    2188:	32 30                	xor    dh,BYTE PTR [bx+si]
    218a:	31 a0 07 08          	xor    WORD PTR [bx+si+0x807],sp
    218e:	00 04                	add    BYTE PTR [si],al
    2190:	4e                   	dec    si
    2191:	31 39                	xor    WORD PTR [bx+di],di
    2193:	31 a4 07 08          	xor    WORD PTR [si+0x807],sp
    2197:	00 04                	add    BYTE PTR [si],al
    2199:	4e                   	dec    si
    219a:	31 38                	xor    WORD PTR [bx+si],di
    219c:	31 a8 07 08          	xor    WORD PTR [bx+si+0x807],bp
    21a0:	00 04                	add    BYTE PTR [si],al
    21a2:	4e                   	dec    si
    21a3:	31 37                	xor    WORD PTR [bx],si
    21a5:	31 ac 07 08          	xor    WORD PTR [si+0x807],bp
    21a9:	00 04                	add    BYTE PTR [si],al
    21ab:	4e                   	dec    si
    21ac:	31 36 31 b0          	xor    WORD PTR ds:0xb031,si
    21b0:	07                   	pop    es
    21b1:	08 00                	or     BYTE PTR [bx+si],al
    21b3:	04 4e                	add    al,0x4e
    21b5:	31 35                	xor    WORD PTR [di],si
    21b7:	31 b4 07 08          	xor    WORD PTR [si+0x807],si
    21bb:	00 04                	add    BYTE PTR [si],al
    21bd:	4e                   	dec    si
    21be:	31 34                	xor    WORD PTR [si],si
    21c0:	31 b8 07 08          	xor    WORD PTR [bx+si+0x807],di
    21c4:	00 04                	add    BYTE PTR [si],al
    21c6:	4e                   	dec    si
    21c7:	31 33                	xor    WORD PTR [bp+di],si
    21c9:	31 bc 07 08          	xor    WORD PTR [si+0x807],di
    21cd:	00 04                	add    BYTE PTR [si],al
    21cf:	4e                   	dec    si
    21d0:	31 32                	xor    WORD PTR [bp+si],si
    21d2:	31 c0                	xor    ax,ax
    21d4:	07                   	pop    es
    21d5:	08 00                	or     BYTE PTR [bx+si],al
    21d7:	04 4e                	add    al,0x4e
    21d9:	31 31                	xor    WORD PTR [bx+di],si
    21db:	31 c4                	xor    sp,ax
    21dd:	07                   	pop    es
    21de:	08 00                	or     BYTE PTR [bx+si],al
    21e0:	04 4e                	add    al,0x4e
    21e2:	31 30                	xor    WORD PTR [bx+si],si
    21e4:	31 c8                	xor    ax,cx
    21e6:	07                   	pop    es
    21e7:	08 00                	or     BYTE PTR [bx+si],al
    21e9:	03 4e 39             	add    cx,WORD PTR [bp+0x39]
    21ec:	31 cc                	xor    sp,cx
    21ee:	07                   	pop    es
    21ef:	08 00                	or     BYTE PTR [bx+si],al
    21f1:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
    21f4:	32 d0                	xor    dl,al
    21f6:	07                   	pop    es
    21f7:	08 00                	or     BYTE PTR [bx+si],al
    21f9:	03 4e 37             	add    cx,WORD PTR [bp+0x37]
    21fc:	32 d4                	xor    dl,ah
    21fe:	07                   	pop    es
    21ff:	08 00                	or     BYTE PTR [bx+si],al
    2201:	03 4e 36             	add    cx,WORD PTR [bp+0x36]
    2204:	32 d8                	xor    bl,al
    2206:	07                   	pop    es
    2207:	08 00                	or     BYTE PTR [bx+si],al
    2209:	03 4e 35             	add    cx,WORD PTR [bp+0x35]
    220c:	32 dc                	xor    bl,ah
    220e:	07                   	pop    es
    220f:	08 00                	or     BYTE PTR [bx+si],al
    2211:	03 4e 34             	add    cx,WORD PTR [bp+0x34]
    2214:	32 e0                	xor    ah,al
    2216:	07                   	pop    es
    2217:	08 00                	or     BYTE PTR [bx+si],al
    2219:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
    221c:	32 e4                	xor    ah,ah
    221e:	07                   	pop    es
    221f:	08 00                	or     BYTE PTR [bx+si],al
    2221:	03 4e 32             	add    cx,WORD PTR [bp+0x32]
    2224:	32 e8                	xor    ch,al
    2226:	07                   	pop    es
    2227:	08 00                	or     BYTE PTR [bx+si],al
    2229:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
    222c:	32 ec                	xor    ch,ah
    222e:	07                   	pop    es
    222f:	08 00                	or     BYTE PTR [bx+si],al
    2231:	04 53                	add    al,0x53
    2233:	49                   	dec    cx
    2234:	47                   	inc    di
    2235:	31 0d                	xor    WORD PTR [di],cx
    2237:	00 ef                	add    bh,ch
    2239:	02 42 22             	add    al,BYTE PTR [bp+si+0x22]
    223c:	ad                   	lods   ax,WORD PTR ds:[si]
    223d:	0d c1 5c             	or     ax,0x5cc1
    2240:	94                   	xchg   sp,ax
    2241:	00 6b 34             	add    BYTE PTR [bp+di+0x34],ch
    2244:	38 01                	cmp    BYTE PTR [bx+di],al
    2246:	4a                   	dec    dx
    2247:	22 58 0a             	and    bl,BYTE PTR [bx+si+0xa]
    224a:	4e                   	dec    si
    224b:	22 c8                	and    cl,al
    224d:	07                   	pop    es
    224e:	5a                   	pop    dx
    224f:	22 c8                	and    cl,al
    2251:	08 7d 26             	or     BYTE PTR [di+0x26],bh
    2254:	7e 08                	jle    0x225e
    2256:	15 25 67             	adc    ax,0x6725
    2259:	0c 8f                	or     al,0x8f
    225b:	26 0c 01             	es or  al,0x1
    225e:	66 22 22             	data32 and ah,BYTE PTR [bp+si]
    2261:	00 63 26             	add    BYTE PTR [bp+di+0x26],ah
    2264:	17                   	pop    ss
    2265:	06                   	push   es
    2266:	6a 22                	push   0x22
    2268:	91                   	xchg   cx,ax
    2269:	12 3b                	adc    bh,BYTE PTR [bp+di]
    226b:	5b                   	pop    bx
    226c:	07                   	pop    es
    226d:	13 54 46             	adc    dx,WORD PTR [si+0x46]
    2270:	6f                   	outs   dx,WORD PTR ds:[si]
    2271:	72 6d                	jb     0x22e0
    2273:	53                   	push   bx
    2274:	45                   	inc    bp
    2275:	52                   	push   dx
    2276:	53                   	push   bx
    2277:	5f                   	pop    di
    2278:	53                   	push   bx
    2279:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
    227e:	69 6f 6e 22 00       	imul   bp,WORD PTR [bx+0x6e],0x22
    2283:	c1 22 7b             	shl    WORD PTR [bp+si],0x7b
    2286:	06                   	push   es
    2287:	b2 22                	mov    dl,0x22
    2289:	38 00                	cmp    BYTE PTR [bx+si],al
    228b:	04 53                	add    al,0x53
    228d:	65 72 73             	gs jb  0x2303
    2290:	00 00                	add    BYTE PTR [bx+si],al
    2292:	55                   	push   bp
    2293:	89 e5                	mov    bp,sp
    2295:	31 c0                	xor    ax,ax
    2297:	9a 44 04 cc 22       	call   0x22cc:0x444
    229c:	6a 00                	push   0x0
    229e:	9a c2 38 aa 24       	call   0x24aa:0x38c2
    22a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a6:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
    22ad:	06                   	push   es
    22ae:	57                   	push   di
    22af:	9a 56 55 da 22       	call   0x22da:0x5556
    22b4:	9a c3 28 f8 26       	call   0x26f8:0x28c3
    22b9:	c9                   	leave
    22ba:	ca 04 00             	retf   0x4
    22bd:	00 00                	add    BYTE PTR [bx+si],al
    22bf:	70 23                	jo     0x22e4
    22c1:	f4                   	hlt
    22c2:	22 55 89             	and    dl,BYTE PTR [di-0x77]
    22c5:	e5 b8                	in     ax,0xb8
    22c7:	08 00                	or     BYTE PTR [bx+si],al
    22c9:	9a 44 04 8e 23       	call   0x238e:0x444
    22ce:	83 ec 08             	sub    sp,0x8
    22d1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    22d5:	06                   	push   es
    22d6:	57                   	push   di
    22d7:	9a 03 73 fb 22       	call   0x22fb:0x7303
    22dc:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    22e0:	7f 03                	jg     0x22e5
    22e2:	e9 96 00             	jmp    0x237b
    22e5:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    22e9:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    22ed:	b0 01                	mov    al,0x1
    22ef:	50                   	push   ax
    22f0:	b8 22 00             	mov    ax,0x22
    22f3:	ba 2f 23             	mov    dx,0x232f
    22f6:	52                   	push   dx
    22f7:	50                   	push   ax
    22f8:	9a 53 25 58 23       	call   0x2358:0x2553
    22fd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2300:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2303:	b8 bd 22             	mov    ax,0x22bd
    2306:	0e                   	push   cs
    2307:	50                   	push   ax
    2308:	55                   	push   bp
    2309:	ff 36 58 18          	push   WORD PTR ds:0x1858
    230d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2311:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2314:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2317:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    231a:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    231d:	26 89 85 f4 07       	mov    WORD PTR es:[di+0x7f4],ax
    2322:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    2325:	26 89 85 f2 07       	mov    WORD PTR es:[di+0x7f2],ax
    232a:	06                   	push   es
    232b:	57                   	push   di
    232c:	9a 38 30 3e 23       	call   0x233e:0x3038
    2331:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2334:	26 ff b5 f2 07       	push   WORD PTR es:[di+0x7f2]
    2339:	06                   	push   es
    233a:	57                   	push   di
    233b:	9a a7 3b 83 23       	call   0x2383:0x3ba7
    2340:	6a ff                	push   0xffff
    2342:	6a f0                	push   0xfff0
    2344:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2347:	06                   	push   es
    2348:	57                   	push   di
    2349:	9a d5 1e 37 24       	call   0x2437:0x1ed5
    234e:	6a 02                	push   0x2
    2350:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2353:	06                   	push   es
    2354:	57                   	push   di
    2355:	9a 14 3a 62 23       	call   0x2362:0x3a14
    235a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    235d:	06                   	push   es
    235e:	57                   	push   di
    235f:	9a 45 5d 78 23       	call   0x2378:0x5d45
    2364:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2368:	83 c4 06             	add    sp,0x6
    236b:	b8 7b 23             	mov    ax,0x237b
    236e:	0e                   	push   cs
    236f:	50                   	push   ax
    2370:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2373:	06                   	push   es
    2374:	57                   	push   di
    2375:	9a 1d 5f 9c 23       	call   0x239c:0x5f1d
    237a:	cb                   	retf
    237b:	c9                   	leave
    237c:	ca 04 00             	retf   0x4
    237f:	00 00                	add    BYTE PTR [bx+si],al
    2381:	c3                   	ret
    2382:	24 de                	and    al,0xde
    2384:	23 55 89             	and    dx,WORD PTR [di-0x77]
    2387:	e5 b8                	in     ax,0xb8
    2389:	0a 00                	or     al,BYTE PTR [bx+si]
    238b:	9a 44 04 da 24       	call   0x24da:0x444
    2390:	83 ec 0a             	sub    sp,0xa
    2393:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2397:	06                   	push   es
    2398:	57                   	push   di
    2399:	9a 03 73 e5 23       	call   0x23e5:0x7303
    239e:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    23a2:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    23a6:	7e 1e                	jle    0x23c6
    23a8:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    23ac:	75 14                	jne    0x23c2
    23ae:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    23b2:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    23b8:	b0 00                	mov    al,0x0
    23ba:	75 01                	jne    0x23bd
    23bc:	40                   	inc    ax
    23bd:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    23c0:	eb 04                	jmp    0x23c6
    23c2:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    23c6:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    23ca:	75 03                	jne    0x23cf
    23cc:	e9 ff 00             	jmp    0x24ce
    23cf:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    23d3:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    23d7:	b0 01                	mov    al,0x1
    23d9:	50                   	push   ax
    23da:	b8 22 00             	mov    ax,0x22
    23dd:	ba 19 24             	mov    dx,0x2419
    23e0:	52                   	push   dx
    23e1:	50                   	push   ax
    23e2:	9a 53 25 45 24       	call   0x2445:0x2553
    23e7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    23ea:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    23ed:	b8 7f 23             	mov    ax,0x237f
    23f0:	0e                   	push   cs
    23f1:	50                   	push   ax
    23f2:	55                   	push   bp
    23f3:	ff 36 58 18          	push   WORD PTR ds:0x1858
    23f7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    23fb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23fe:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    2401:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    2404:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    2407:	26 89 85 f4 07       	mov    WORD PTR es:[di+0x7f4],ax
    240c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    240f:	26 89 85 f2 07       	mov    WORD PTR es:[di+0x7f2],ax
    2414:	06                   	push   es
    2415:	57                   	push   di
    2416:	9a 38 30 28 24       	call   0x2428:0x3038
    241b:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    241e:	26 ff b5 f2 07       	push   WORD PTR es:[di+0x7f2]
    2423:	06                   	push   es
    2424:	57                   	push   di
    2425:	9a a7 3b 7f 24       	call   0x247f:0x3ba7
    242a:	68 ff 00             	push   0xff
    242d:	6a ff                	push   0xffff
    242f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2432:	06                   	push   es
    2433:	57                   	push   di
    2434:	9a d5 1e 67 24       	call   0x2467:0x1ed5
    2439:	6a 00                	push   0x0
    243b:	6a 00                	push   0x0
    243d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2440:	06                   	push   es
    2441:	57                   	push   di
    2442:	9a b2 36 51 24       	call   0x2451:0x36b2
    2447:	6a 02                	push   0x2
    2449:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    244c:	06                   	push   es
    244d:	57                   	push   di
    244e:	9a 14 3a 5d 24       	call   0x245d:0x3a14
    2453:	6a 01                	push   0x1
    2455:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2458:	06                   	push   es
    2459:	57                   	push   di
    245a:	9a e5 34 8c 24       	call   0x248c:0x34e5
    245f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2462:	06                   	push   es
    2463:	57                   	push   di
    2464:	9a b9 62 b2 2a       	call   0x2ab2:0x62b9
    2469:	50                   	push   ax
    246a:	6a 04                	push   0x4
    246c:	9a ff ff 00 00       	call   0x0:0xffff
    2471:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    2475:	74 0c                	je     0x2483
    2477:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    247a:	06                   	push   es
    247b:	57                   	push   di
    247c:	9a e6 56 ee 24       	call   0x24ee:0x56e6
    2481:	eb 34                	jmp    0x24b7
    2483:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2487:	06                   	push   es
    2488:	57                   	push   di
    2489:	9a 03 73 b5 24       	call   0x24b5:0x7303
    248e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2491:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2494:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2497:	26 ff b5 82 01       	push   WORD PTR es:[di+0x182]
    249c:	26 ff b5 80 01       	push   WORD PTR es:[di+0x180]
    24a1:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    24a5:	06                   	push   es
    24a6:	57                   	push   di
    24a7:	9a 1a 31 4f 25       	call   0x254f:0x311a
    24ac:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    24b0:	06                   	push   es
    24b1:	57                   	push   di
    24b2:	9a 03 73 cb 24       	call   0x24cb:0x7303
    24b7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    24bb:	83 c4 06             	add    sp,0x6
    24be:	b8 ce 24             	mov    ax,0x24ce
    24c1:	0e                   	push   cs
    24c2:	50                   	push   ax
    24c3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    24c6:	06                   	push   es
    24c7:	57                   	push   di
    24c8:	9a 1d 5f 40 25       	call   0x2540:0x5f1d
    24cd:	cb                   	retf
    24ce:	c9                   	leave
    24cf:	ca 06 00             	retf   0x6
    24d2:	55                   	push   bp
    24d3:	89 e5                	mov    bp,sp
    24d5:	31 c0                	xor    ax,ax
    24d7:	9a 44 04 03 25       	call   0x2503:0x444
    24dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24df:	26 ff b5 f2 07       	push   WORD PTR es:[di+0x7f2]
    24e4:	26 ff b5 f4 07       	push   WORD PTR es:[di+0x7f4]
    24e9:	6a 00                	push   0x0
    24eb:	9a 85 23 f8 24       	call   0x24f8:0x2385
    24f0:	c9                   	leave
    24f1:	ca 08 00             	retf   0x8
    24f4:	00 00                	add    BYTE PTR [bx+si],al
    24f6:	b5 25                	mov    ch,0x25
    24f8:	89 25                	mov    WORD PTR [di],sp
    24fa:	55                   	push   bp
    24fb:	89 e5                	mov    bp,sp
    24fd:	b8 08 00             	mov    ax,0x8
    2500:	9a 44 04 04 26       	call   0x2604:0x444
    2505:	83 ec 08             	sub    sp,0x8
    2508:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    250b:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    2510:	06                   	push   es
    2511:	57                   	push   di
    2512:	9a 17 2f 6e 56       	call   0x566e:0x2f17
    2517:	08 c0                	or     al,al
    2519:	75 03                	jne    0x251e
    251b:	e9 b3 00             	jmp    0x25d1
    251e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2521:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    2526:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    252b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    252e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2531:	26 ff b5 82 01       	push   WORD PTR es:[di+0x182]
    2536:	26 ff b5 80 01       	push   WORD PTR es:[di+0x180]
    253b:	06                   	push   es
    253c:	57                   	push   di
    253d:	9a d0 3f 56 25       	call   0x2556:0x3fd0
    2542:	ff 76 08             	push   WORD PTR [bp+0x8]
    2545:	ff 76 06             	push   WORD PTR [bp+0x6]
    2548:	b0 01                	mov    al,0x1
    254a:	50                   	push   ax
    254b:	b8 b4 25             	mov    ax,0x25b4
    254e:	ba 7e 25             	mov    dx,0x257e
    2551:	52                   	push   dx
    2552:	50                   	push   ax
    2553:	9a 53 25 a7 25       	call   0x25a7:0x2553
    2558:	a3 04 20             	mov    ds:0x2004,ax
    255b:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    255f:	b8 f4 24             	mov    ax,0x24f4
    2562:	0e                   	push   cs
    2563:	50                   	push   ax
    2564:	55                   	push   bp
    2565:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2569:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    256d:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    2571:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2574:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2577:	6a 01                	push   0x1
    2579:	06                   	push   es
    257a:	57                   	push   di
    257b:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    2580:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2583:	06                   	push   es
    2584:	57                   	push   di
    2585:	b8 d2 24             	mov    ax,0x24d2
    2588:	ba 2a 30             	mov    dx,0x302a
    258b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    258e:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    2593:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    2598:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    259d:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    25a2:	06                   	push   es
    25a3:	57                   	push   di
    25a4:	9a 45 5d be 25       	call   0x25be:0x5d45
    25a9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    25ad:	83 c4 06             	add    sp,0x6
    25b0:	b8 c1 25             	mov    ax,0x25c1
    25b3:	0e                   	push   cs
    25b4:	50                   	push   ax
    25b5:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    25b9:	06                   	push   es
    25ba:	57                   	push   di
    25bb:	9a 1d 5f cf 25       	call   0x25cf:0x5f1d
    25c0:	cb                   	retf
    25c1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    25c4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    25c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25ca:	06                   	push   es
    25cb:	57                   	push   di
    25cc:	9a d0 3f 1d 26       	call   0x261d:0x3fd0
    25d1:	c9                   	leave
    25d2:	ca 08 00             	retf   0x8
    25d5:	0a 23                	or     ah,BYTE PTR [bp+di]
    25d7:	2c 23                	sub    al,0x23
    25d9:	23 30                	and    si,WORD PTR [bx+si]
    25db:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    25de:	23 23                	and    sp,WORD PTR [bp+di]
    25e0:	07                   	pop    es
    25e1:	23 30                	and    si,WORD PTR [bx+si]
    25e3:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    25e6:	23 23                	and    sp,WORD PTR [bp+di]
    25e8:	07                   	pop    es
    25e9:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    25ed:	2b 30                	sub    si,WORD PTR [bx+si]
    25ef:	30 01                	xor    BYTE PTR [bx+di],al
    25f1:	30 05                	xor    BYTE PTR [di],al
    25f3:	23 2c                	and    bp,WORD PTR [si]
    25f5:	23 23                	and    sp,WORD PTR [bp+di]
    25f7:	30 02                	xor    BYTE PTR [bp+si],al
    25f9:	23 30                	and    si,WORD PTR [bx+si]
    25fb:	55                   	push   bp
    25fc:	89 e5                	mov    bp,sp
    25fe:	b8 14 03             	mov    ax,0x314
    2601:	9a 44 04 96 26       	call   0x2696:0x444
    2606:	81 ec 14 03          	sub    sp,0x314
    260a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    260d:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    2611:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    2615:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2618:	06                   	push   es
    2619:	57                   	push   di
    261a:	9a d5 33 47 26       	call   0x2647:0x33d5
    261f:	89 c7                	mov    di,ax
    2621:	8e c2                	mov    es,dx
    2623:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    2627:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    262b:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    262f:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    2633:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    2637:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    263b:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    263f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2642:	06                   	push   es
    2643:	57                   	push   di
    2644:	9a d5 33 16 27       	call   0x2716:0x33d5
    2649:	89 c7                	mov    di,ax
    264b:	8e c2                	mov    es,dx
    264d:	06                   	push   es
    264e:	57                   	push   di
    264f:	9a 99 20 21 27       	call   0x2721:0x2099
    2654:	8d be f4 fc          	lea    di,[bp-0x30c]
    2658:	16                   	push   ss
    2659:	57                   	push   di
    265a:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    265e:	06                   	push   es
    265f:	57                   	push   di
    2660:	9a 9f 1a 6e 26       	call   0x266e:0x1a9f
    2665:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    2669:	06                   	push   es
    266a:	57                   	push   di
    266b:	9a 5f 1a 7f 2a       	call   0x2a7f:0x1a5f
    2670:	89 c7                	mov    di,ax
    2672:	8e c2                	mov    es,dx
    2674:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2678:	06                   	push   es
    2679:	57                   	push   di
    267a:	9a 9b 3b 0b 2c       	call   0x2c0b:0x3b9b
    267f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2682:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2685:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2688:	ff 76 fc             	push   WORD PTR [bp-0x4]
    268b:	bf 58 0a             	mov    di,0xa58
    268e:	b8 a9 26             	mov    ax,0x26a9
    2691:	50                   	push   ax
    2692:	57                   	push   di
    2693:	9a 55 22 b0 26       	call   0x26b0:0x2255
    2698:	08 c0                	or     al,al
    269a:	75 03                	jne    0x269f
    269c:	e9 bb 01             	jmp    0x285a
    269f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    26a2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    26a5:	bf 58 0a             	mov    di,0xa58
    26a8:	b8 55 28             	mov    ax,0x2855
    26ab:	50                   	push   ax
    26ac:	57                   	push   di
    26ad:	9a 73 22 cf 26       	call   0x26cf:0x2273
    26b2:	89 c7                	mov    di,ax
    26b4:	8e c2                	mov    es,dx
    26b6:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    26ba:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    26be:	bf d5 25             	mov    di,0x25d5
    26c1:	0e                   	push   cs
    26c2:	57                   	push   di
    26c3:	8d be fc fd          	lea    di,[bp-0x204]
    26c7:	16                   	push   ss
    26c8:	57                   	push   di
    26c9:	68 ff 00             	push   0xff
    26cc:	9a e7 17 06 27       	call   0x2706:0x17e7
    26d1:	8d be f0 fc          	lea    di,[bp-0x310]
    26d5:	16                   	push   ss
    26d6:	57                   	push   di
    26d7:	8d be fc fd          	lea    di,[bp-0x204]
    26db:	16                   	push   ss
    26dc:	57                   	push   di
    26dd:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    26e1:	06                   	push   es
    26e2:	57                   	push   di
    26e3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26e6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    26ea:	83 ec 0a             	sub    sp,0xa
    26ed:	89 e3                	mov    bx,sp
    26ef:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    26f3:	90                   	nop
    26f4:	9b                   	fwait
    26f5:	9a d4 10 78 27       	call   0x2778:0x10d4
    26fa:	8d be fc fe          	lea    di,[bp-0x104]
    26fe:	16                   	push   ss
    26ff:	57                   	push   di
    2700:	68 ff 00             	push   0xff
    2703:	9a e7 17 35 27       	call   0x2735:0x17e7
    2708:	8d be fc fe          	lea    di,[bp-0x104]
    270c:	16                   	push   ss
    270d:	57                   	push   di
    270e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2711:	06                   	push   es
    2712:	57                   	push   di
    2713:	9a d5 33 96 27       	call   0x2796:0x33d5
    2718:	89 c7                	mov    di,ax
    271a:	8e c2                	mov    es,dx
    271c:	06                   	push   es
    271d:	57                   	push   di
    271e:	9a 03 20 a1 27       	call   0x27a1:0x2003
    2723:	8b d0                	mov    dx,ax
    2725:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    2729:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    272d:	2d 05 00             	sub    ax,0x5
    2730:	71 05                	jno    0x2737
    2732:	9a 3e 04 4f 27       	call   0x274f:0x43e
    2737:	3b c2                	cmp    ax,dx
    2739:	7e 03                	jle    0x273e
    273b:	e9 08 01             	jmp    0x2846
    273e:	bf e0 25             	mov    di,0x25e0
    2741:	0e                   	push   cs
    2742:	57                   	push   di
    2743:	8d be fc fd          	lea    di,[bp-0x204]
    2747:	16                   	push   ss
    2748:	57                   	push   di
    2749:	68 ff 00             	push   0xff
    274c:	9a e7 17 86 27       	call   0x2786:0x17e7
    2751:	8d be f0 fc          	lea    di,[bp-0x310]
    2755:	16                   	push   ss
    2756:	57                   	push   di
    2757:	8d be fc fd          	lea    di,[bp-0x204]
    275b:	16                   	push   ss
    275c:	57                   	push   di
    275d:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    2761:	06                   	push   es
    2762:	57                   	push   di
    2763:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2766:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    276a:	83 ec 0a             	sub    sp,0xa
    276d:	89 e3                	mov    bx,sp
    276f:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2773:	90                   	nop
    2774:	9b                   	fwait
    2775:	9a d4 10 da 28       	call   0x28da:0x10d4
    277a:	8d be fc fe          	lea    di,[bp-0x104]
    277e:	16                   	push   ss
    277f:	57                   	push   di
    2780:	68 ff 00             	push   0xff
    2783:	9a e7 17 b5 27       	call   0x27b5:0x17e7
    2788:	8d be fc fe          	lea    di,[bp-0x104]
    278c:	16                   	push   ss
    278d:	57                   	push   di
    278e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2791:	06                   	push   es
    2792:	57                   	push   di
    2793:	9a d5 33 df 27       	call   0x27df:0x33d5
    2798:	89 c7                	mov    di,ax
    279a:	8e c2                	mov    es,dx
    279c:	06                   	push   es
    279d:	57                   	push   di
    279e:	9a 03 20 ea 27       	call   0x27ea:0x2003
    27a3:	8b d0                	mov    dx,ax
    27a5:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    27a9:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    27ad:	2d 05 00             	sub    ax,0x5
    27b0:	71 05                	jno    0x27b7
    27b2:	9a 3e 04 cf 27       	call   0x27cf:0x43e
    27b7:	3b c2                	cmp    ax,dx
    27b9:	7e 03                	jle    0x27be
    27bb:	e9 88 00             	jmp    0x2846
    27be:	bf e8 25             	mov    di,0x25e8
    27c1:	0e                   	push   cs
    27c2:	57                   	push   di
    27c3:	8d be fc fd          	lea    di,[bp-0x204]
    27c7:	16                   	push   ss
    27c8:	57                   	push   di
    27c9:	68 ff 00             	push   0xff
    27cc:	9a e7 17 fe 27       	call   0x27fe:0x17e7
    27d1:	8d be fc fd          	lea    di,[bp-0x204]
    27d5:	16                   	push   ss
    27d6:	57                   	push   di
    27d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27da:	06                   	push   es
    27db:	57                   	push   di
    27dc:	9a d5 33 f8 28       	call   0x28f8:0x33d5
    27e1:	89 c7                	mov    di,ax
    27e3:	8e c2                	mov    es,dx
    27e5:	06                   	push   es
    27e6:	57                   	push   di
    27e7:	9a 03 20 03 29       	call   0x2903:0x2003
    27ec:	8b d0                	mov    dx,ax
    27ee:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    27f2:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    27f6:	2d 05 00             	sub    ax,0x5
    27f9:	71 05                	jno    0x2800
    27fb:	9a 3e 04 2c 28       	call   0x282c:0x43e
    2800:	3b c2                	cmp    ax,dx
    2802:	b0 00                	mov    al,0x0
    2804:	7e 01                	jle    0x2807
    2806:	40                   	inc    ax
    2807:	8a d0                	mov    dl,al
    2809:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    280e:	b0 00                	mov    al,0x0
    2810:	73 01                	jae    0x2813
    2812:	40                   	inc    ax
    2813:	22 c2                	and    al,dl
    2815:	08 c0                	or     al,al
    2817:	74 17                	je     0x2830
    2819:	bf f0 25             	mov    di,0x25f0
    281c:	0e                   	push   cs
    281d:	57                   	push   di
    281e:	8d be fc fd          	lea    di,[bp-0x204]
    2822:	16                   	push   ss
    2823:	57                   	push   di
    2824:	68 ff 00             	push   0xff
    2827:	6a 03                	push   0x3
    2829:	9a 16 19 44 28       	call   0x2844:0x1916
    282e:	eb a1                	jmp    0x27d1
    2830:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    2835:	76 0f                	jbe    0x2846
    2837:	8d be fc fd          	lea    di,[bp-0x204]
    283b:	16                   	push   ss
    283c:	57                   	push   di
    283d:	6a 03                	push   0x3
    283f:	6a 01                	push   0x1
    2841:	9a 75 19 6b 28       	call   0x286b:0x1975
    2846:	8d be fc fd          	lea    di,[bp-0x204]
    284a:	16                   	push   ss
    284b:	57                   	push   di
    284c:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    2850:	06                   	push   es
    2851:	57                   	push   di
    2852:	9a f9 60 64 28       	call   0x2864:0x60f9
    2857:	e9 ec 01             	jmp    0x2a46
    285a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    285d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2860:	bf c8 07             	mov    di,0x7c8
    2863:	b8 7e 28             	mov    ax,0x287e
    2866:	50                   	push   ax
    2867:	57                   	push   di
    2868:	9a 55 22 85 28       	call   0x2885:0x2255
    286d:	08 c0                	or     al,al
    286f:	75 03                	jne    0x2874
    2871:	e9 d2 01             	jmp    0x2a46
    2874:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2877:	ff 76 fc             	push   WORD PTR [bp-0x4]
    287a:	bf c8 07             	mov    di,0x7c8
    287d:	b8 44 2a             	mov    ax,0x2a44
    2880:	50                   	push   ax
    2881:	57                   	push   di
    2882:	9a 73 22 a4 28       	call   0x28a4:0x2273
    2887:	89 c7                	mov    di,ax
    2889:	8e c2                	mov    es,dx
    288b:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    288f:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    2893:	bf f2 25             	mov    di,0x25f2
    2896:	0e                   	push   cs
    2897:	57                   	push   di
    2898:	8d be fc fd          	lea    di,[bp-0x204]
    289c:	16                   	push   ss
    289d:	57                   	push   di
    289e:	68 ff 00             	push   0xff
    28a1:	9a e7 17 e8 28       	call   0x28e8:0x17e7
    28a6:	8d be ec fc          	lea    di,[bp-0x314]
    28aa:	16                   	push   ss
    28ab:	57                   	push   di
    28ac:	8d be fc fd          	lea    di,[bp-0x204]
    28b0:	16                   	push   ss
    28b1:	57                   	push   di
    28b2:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    28b6:	06                   	push   es
    28b7:	57                   	push   di
    28b8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28bb:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    28bf:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    28c3:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    28c7:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    28cc:	83 ec 0a             	sub    sp,0xa
    28cf:	89 e3                	mov    bx,sp
    28d1:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    28d5:	90                   	nop
    28d6:	9b                   	fwait
    28d7:	9a d4 10 67 29       	call   0x2967:0x10d4
    28dc:	8d be fc fe          	lea    di,[bp-0x104]
    28e0:	16                   	push   ss
    28e1:	57                   	push   di
    28e2:	68 ff 00             	push   0xff
    28e5:	9a e7 17 17 29       	call   0x2917:0x17e7
    28ea:	8d be fc fe          	lea    di,[bp-0x104]
    28ee:	16                   	push   ss
    28ef:	57                   	push   di
    28f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28f3:	06                   	push   es
    28f4:	57                   	push   di
    28f5:	9a d5 33 85 29       	call   0x2985:0x33d5
    28fa:	89 c7                	mov    di,ax
    28fc:	8e c2                	mov    es,dx
    28fe:	06                   	push   es
    28ff:	57                   	push   di
    2900:	9a 03 20 90 29       	call   0x2990:0x2003
    2905:	8b d0                	mov    dx,ax
    2907:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    290b:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    290f:	2d 05 00             	sub    ax,0x5
    2912:	71 05                	jno    0x2919
    2914:	9a 3e 04 31 29       	call   0x2931:0x43e
    2919:	3b c2                	cmp    ax,dx
    291b:	7e 03                	jle    0x2920
    291d:	e9 15 01             	jmp    0x2a35
    2920:	bf f8 25             	mov    di,0x25f8
    2923:	0e                   	push   cs
    2924:	57                   	push   di
    2925:	8d be fc fd          	lea    di,[bp-0x204]
    2929:	16                   	push   ss
    292a:	57                   	push   di
    292b:	68 ff 00             	push   0xff
    292e:	9a e7 17 75 29       	call   0x2975:0x17e7
    2933:	8d be ec fc          	lea    di,[bp-0x314]
    2937:	16                   	push   ss
    2938:	57                   	push   di
    2939:	8d be fc fd          	lea    di,[bp-0x204]
    293d:	16                   	push   ss
    293e:	57                   	push   di
    293f:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    2943:	06                   	push   es
    2944:	57                   	push   di
    2945:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2948:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    294c:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    2950:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    2954:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    2959:	83 ec 0a             	sub    sp,0xa
    295c:	89 e3                	mov    bx,sp
    295e:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2962:	90                   	nop
    2963:	9b                   	fwait
    2964:	9a d4 10 6f 2c       	call   0x2c6f:0x10d4
    2969:	8d be fc fe          	lea    di,[bp-0x104]
    296d:	16                   	push   ss
    296e:	57                   	push   di
    296f:	68 ff 00             	push   0xff
    2972:	9a e7 17 a4 29       	call   0x29a4:0x17e7
    2977:	8d be fc fe          	lea    di,[bp-0x104]
    297b:	16                   	push   ss
    297c:	57                   	push   di
    297d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2980:	06                   	push   es
    2981:	57                   	push   di
    2982:	9a d5 33 ce 29       	call   0x29ce:0x33d5
    2987:	89 c7                	mov    di,ax
    2989:	8e c2                	mov    es,dx
    298b:	06                   	push   es
    298c:	57                   	push   di
    298d:	9a 03 20 d9 29       	call   0x29d9:0x2003
    2992:	8b d0                	mov    dx,ax
    2994:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    2998:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    299c:	2d 05 00             	sub    ax,0x5
    299f:	71 05                	jno    0x29a6
    29a1:	9a 3e 04 be 29       	call   0x29be:0x43e
    29a6:	3b c2                	cmp    ax,dx
    29a8:	7e 03                	jle    0x29ad
    29aa:	e9 88 00             	jmp    0x2a35
    29ad:	bf e8 25             	mov    di,0x25e8
    29b0:	0e                   	push   cs
    29b1:	57                   	push   di
    29b2:	8d be fc fd          	lea    di,[bp-0x204]
    29b6:	16                   	push   ss
    29b7:	57                   	push   di
    29b8:	68 ff 00             	push   0xff
    29bb:	9a e7 17 ed 29       	call   0x29ed:0x17e7
    29c0:	8d be fc fd          	lea    di,[bp-0x204]
    29c4:	16                   	push   ss
    29c5:	57                   	push   di
    29c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c9:	06                   	push   es
    29ca:	57                   	push   di
    29cb:	9a d5 33 5a 2a       	call   0x2a5a:0x33d5
    29d0:	89 c7                	mov    di,ax
    29d2:	8e c2                	mov    es,dx
    29d4:	06                   	push   es
    29d5:	57                   	push   di
    29d6:	9a 03 20 65 2a       	call   0x2a65:0x2003
    29db:	8b d0                	mov    dx,ax
    29dd:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    29e1:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    29e5:	2d 05 00             	sub    ax,0x5
    29e8:	71 05                	jno    0x29ef
    29ea:	9a 3e 04 1b 2a       	call   0x2a1b:0x43e
    29ef:	3b c2                	cmp    ax,dx
    29f1:	b0 00                	mov    al,0x0
    29f3:	7e 01                	jle    0x29f6
    29f5:	40                   	inc    ax
    29f6:	8a d0                	mov    dl,al
    29f8:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    29fd:	b0 00                	mov    al,0x0
    29ff:	73 01                	jae    0x2a02
    2a01:	40                   	inc    ax
    2a02:	22 c2                	and    al,dl
    2a04:	08 c0                	or     al,al
    2a06:	74 17                	je     0x2a1f
    2a08:	bf f0 25             	mov    di,0x25f0
    2a0b:	0e                   	push   cs
    2a0c:	57                   	push   di
    2a0d:	8d be fc fd          	lea    di,[bp-0x204]
    2a11:	16                   	push   ss
    2a12:	57                   	push   di
    2a13:	68 ff 00             	push   0xff
    2a16:	6a 03                	push   0x3
    2a18:	9a 16 19 33 2a       	call   0x2a33:0x1916
    2a1d:	eb a1                	jmp    0x29c0
    2a1f:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    2a24:	76 0f                	jbe    0x2a35
    2a26:	8d be fc fd          	lea    di,[bp-0x204]
    2a2a:	16                   	push   ss
    2a2b:	57                   	push   di
    2a2c:	6a 03                	push   0x3
    2a2e:	6a 01                	push   0x1
    2a30:	9a 75 19 73 2a       	call   0x2a73:0x1975
    2a35:	8d be fc fd          	lea    di,[bp-0x204]
    2a39:	16                   	push   ss
    2a3a:	57                   	push   di
    2a3b:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    2a3f:	06                   	push   es
    2a40:	57                   	push   di
    2a41:	9a f9 60 1d 2c       	call   0x2c1d:0x60f9
    2a46:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    2a4a:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2a4e:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2a52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a55:	06                   	push   es
    2a56:	57                   	push   di
    2a57:	9a d5 33 84 2b       	call   0x2b84:0x33d5
    2a5c:	89 c7                	mov    di,ax
    2a5e:	8e c2                	mov    es,dx
    2a60:	06                   	push   es
    2a61:	57                   	push   di
    2a62:	9a 99 20 63 2e       	call   0x2e63:0x2099
    2a67:	c9                   	leave
    2a68:	ca 08 00             	retf   0x8
    2a6b:	55                   	push   bp
    2a6c:	89 e5                	mov    bp,sp
    2a6e:	31 c0                	xor    ax,ax
    2a70:	9a 44 04 86 2a       	call   0x2a86:0x444
    2a75:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2a78:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2a7b:	bf a2 0b             	mov    di,0xba2
    2a7e:	b8 93 2a             	mov    ax,0x2a93
    2a81:	50                   	push   ax
    2a82:	57                   	push   di
    2a83:	9a 55 22 9a 2a       	call   0x2a9a:0x2255
    2a88:	50                   	push   ax
    2a89:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2a8c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2a8f:	bf 22 00             	mov    di,0x22
    2a92:	b8 d5 2a             	mov    ax,0x2ad5
    2a95:	50                   	push   ax
    2a96:	57                   	push   di
    2a97:	9a 55 22 c0 2a       	call   0x2ac0:0x2255
    2a9c:	5a                   	pop    dx
    2a9d:	0a c2                	or     al,dl
    2a9f:	08 c0                	or     al,al
    2aa1:	74 11                	je     0x2ab4
    2aa3:	6a 00                	push   0x0
    2aa5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa8:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2aad:	06                   	push   es
    2aae:	57                   	push   di
    2aaf:	9a 77 1c 08 2b       	call   0x2b08:0x1c77
    2ab4:	c9                   	leave
    2ab5:	ca 08 00             	retf   0x8
    2ab8:	55                   	push   bp
    2ab9:	89 e5                	mov    bp,sp
    2abb:	31 c0                	xor    ax,ax
    2abd:	9a 44 04 dc 2a       	call   0x2adc:0x444
    2ac2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2ac5:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    2ac9:	75 3f                	jne    0x2b0a
    2acb:	ff 76 12             	push   WORD PTR [bp+0x12]
    2ace:	ff 76 10             	push   WORD PTR [bp+0x10]
    2ad1:	bf a2 0b             	mov    di,0xba2
    2ad4:	b8 e9 2a             	mov    ax,0x2ae9
    2ad7:	50                   	push   ax
    2ad8:	57                   	push   di
    2ad9:	9a 55 22 f0 2a       	call   0x2af0:0x2255
    2ade:	50                   	push   ax
    2adf:	ff 76 12             	push   WORD PTR [bp+0x12]
    2ae2:	ff 76 10             	push   WORD PTR [bp+0x10]
    2ae5:	bf 22 00             	mov    di,0x22
    2ae8:	b8 b3 2b             	mov    ax,0x2bb3
    2aeb:	50                   	push   ax
    2aec:	57                   	push   di
    2aed:	9a 55 22 2a 2b       	call   0x2b2a:0x2255
    2af2:	5a                   	pop    dx
    2af3:	0a c2                	or     al,dl
    2af5:	08 c0                	or     al,al
    2af7:	74 11                	je     0x2b0a
    2af9:	6a 00                	push   0x0
    2afb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2afe:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2b03:	06                   	push   es
    2b04:	57                   	push   di
    2b05:	9a 77 1c 43 2b       	call   0x2b43:0x1c77
    2b0a:	c9                   	leave
    2b0b:	ca 0e 00             	retf   0xe
    2b0e:	0a 23                	or     ah,BYTE PTR [bp+di]
    2b10:	2c 23                	sub    al,0x23
    2b12:	23 30                	and    si,WORD PTR [bx+si]
    2b14:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    2b17:	23 23                	and    sp,WORD PTR [bp+di]
    2b19:	05 23 2c             	add    ax,0x2c23
    2b1c:	23 23                	and    sp,WORD PTR [bp+di]
    2b1e:	30 01                	xor    BYTE PTR [bx+di],al
    2b20:	20 55 89             	and    BYTE PTR [di-0x77],dl
    2b23:	e5 b8                	in     ax,0xb8
    2b25:	14 02                	adc    al,0x2
    2b27:	9a 44 04 4a 2b       	call   0x2b4a:0x444
    2b2c:	81 ec 14 02          	sub    sp,0x214
    2b30:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2b33:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    2b37:	75 4d                	jne    0x2b86
    2b39:	ff 76 12             	push   WORD PTR [bp+0x12]
    2b3c:	ff 76 10             	push   WORD PTR [bp+0x10]
    2b3f:	bf c1 05             	mov    di,0x5c1
    2b42:	b8 64 2b             	mov    ax,0x2b64
    2b45:	50                   	push   ax
    2b46:	57                   	push   di
    2b47:	9a 55 22 6b 2b       	call   0x2b6b:0x2255
    2b4c:	08 c0                	or     al,al
    2b4e:	74 36                	je     0x2b86
    2b50:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2b53:	31 c0                	xor    ax,ax
    2b55:	26 89 05             	mov    WORD PTR es:[di],ax
    2b58:	6a 08                	push   0x8
    2b5a:	ff 76 12             	push   WORD PTR [bp+0x12]
    2b5d:	ff 76 10             	push   WORD PTR [bp+0x10]
    2b60:	bf c1 05             	mov    di,0x5c1
    2b63:	b8 55 2d             	mov    ax,0x2d55
    2b66:	50                   	push   ax
    2b67:	57                   	push   di
    2b68:	9a 73 22 ba 2b       	call   0x2bba:0x2273
    2b6d:	89 c7                	mov    di,ax
    2b6f:	8e c2                	mov    es,dx
    2b71:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    2b76:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    2b7b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2b7f:	06                   	push   es
    2b80:	57                   	push   di
    2b81:	9a b2 77 3c 2e       	call   0x2e3c:0x77b2
    2b86:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2b89:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    2b8d:	74 03                	je     0x2b92
    2b8f:	e9 1a 04             	jmp    0x2fac
    2b92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b95:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2b9a:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2b9f:	74 03                	je     0x2ba4
    2ba1:	e9 08 04             	jmp    0x2fac
    2ba4:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    2ba9:	ff 76 12             	push   WORD PTR [bp+0x12]
    2bac:	ff 76 10             	push   WORD PTR [bp+0x10]
    2baf:	bf 22 00             	mov    di,0x22
    2bb2:	b8 cd 2b             	mov    ax,0x2bcd
    2bb5:	50                   	push   ax
    2bb6:	57                   	push   di
    2bb7:	9a 55 22 d4 2b       	call   0x2bd4:0x2255
    2bbc:	08 c0                	or     al,al
    2bbe:	75 03                	jne    0x2bc3
    2bc0:	e9 9a 01             	jmp    0x2d5d
    2bc3:	ff 76 12             	push   WORD PTR [bp+0x12]
    2bc6:	ff 76 10             	push   WORD PTR [bp+0x10]
    2bc9:	bf 22 00             	mov    di,0x22
    2bcc:	b8 f1 2b             	mov    ax,0x2bf1
    2bcf:	50                   	push   ax
    2bd0:	57                   	push   di
    2bd1:	9a 73 22 24 2c       	call   0x2c24:0x2273
    2bd6:	89 c7                	mov    di,ax
    2bd8:	8e c2                	mov    es,dx
    2bda:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2bde:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2be2:	8d be f4 fd          	lea    di,[bp-0x20c]
    2be6:	16                   	push   ss
    2be7:	57                   	push   di
    2be8:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2bec:	06                   	push   es
    2bed:	57                   	push   di
    2bee:	9a 9f 1a fc 2b       	call   0x2bfc:0x1a9f
    2bf3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2bf7:	06                   	push   es
    2bf8:	57                   	push   di
    2bf9:	9a 5f 1a 67 2d       	call   0x2d67:0x1a5f
    2bfe:	89 c7                	mov    di,ax
    2c00:	8e c2                	mov    es,dx
    2c02:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2c06:	06                   	push   es
    2c07:	57                   	push   di
    2c08:	9a 9b 3b 59 30       	call   0x3059:0x3b9b
    2c0d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2c10:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2c13:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c16:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2c19:	bf 58 0a             	mov    di,0xa58
    2c1c:	b8 34 2c             	mov    ax,0x2c34
    2c1f:	50                   	push   ax
    2c20:	57                   	push   di
    2c21:	9a 55 22 3b 2c       	call   0x2c3b:0x2255
    2c26:	08 c0                	or     al,al
    2c28:	74 58                	je     0x2c82
    2c2a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c2d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2c30:	bf 58 0a             	mov    di,0xa58
    2c33:	b8 8c 2c             	mov    ax,0x2c8c
    2c36:	50                   	push   ax
    2c37:	57                   	push   di
    2c38:	9a 73 22 7d 2c       	call   0x2c7d:0x2273
    2c3d:	89 c7                	mov    di,ax
    2c3f:	8e c2                	mov    es,dx
    2c41:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    2c45:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    2c49:	8d be f0 fd          	lea    di,[bp-0x210]
    2c4d:	16                   	push   ss
    2c4e:	57                   	push   di
    2c4f:	bf 0e 2b             	mov    di,0x2b0e
    2c52:	0e                   	push   cs
    2c53:	57                   	push   di
    2c54:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    2c58:	06                   	push   es
    2c59:	57                   	push   di
    2c5a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c5d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2c61:	83 ec 0a             	sub    sp,0xa
    2c64:	89 e3                	mov    bx,sp
    2c66:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2c6a:	90                   	nop
    2c6b:	9b                   	fwait
    2c6c:	9a d4 10 eb 2c       	call   0x2ceb:0x10d4
    2c71:	8d be f8 fe          	lea    di,[bp-0x108]
    2c75:	16                   	push   ss
    2c76:	57                   	push   di
    2c77:	68 ff 00             	push   0xff
    2c7a:	9a e7 17 93 2c       	call   0x2c93:0x17e7
    2c7f:	e9 9a 00             	jmp    0x2d1c
    2c82:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c85:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2c88:	bf c8 07             	mov    di,0x7c8
    2c8b:	b8 a3 2c             	mov    ax,0x2ca3
    2c8e:	50                   	push   ax
    2c8f:	57                   	push   di
    2c90:	9a 55 22 aa 2c       	call   0x2caa:0x2255
    2c95:	08 c0                	or     al,al
    2c97:	74 64                	je     0x2cfd
    2c99:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c9c:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2c9f:	bf c8 07             	mov    di,0x7c8
    2ca2:	b8 65 30             	mov    ax,0x3065
    2ca5:	50                   	push   ax
    2ca6:	57                   	push   di
    2ca7:	9a 73 22 f9 2c       	call   0x2cf9:0x2273
    2cac:	89 c7                	mov    di,ax
    2cae:	8e c2                	mov    es,dx
    2cb0:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    2cb4:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    2cb8:	8d be ec fd          	lea    di,[bp-0x214]
    2cbc:	16                   	push   ss
    2cbd:	57                   	push   di
    2cbe:	bf 19 2b             	mov    di,0x2b19
    2cc1:	0e                   	push   cs
    2cc2:	57                   	push   di
    2cc3:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    2cc7:	06                   	push   es
    2cc8:	57                   	push   di
    2cc9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ccc:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2cd0:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    2cd4:	89 96 ee fe          	mov    WORD PTR [bp-0x112],dx
    2cd8:	9b db 86 ec fe       	fild   DWORD PTR [bp-0x114]
    2cdd:	83 ec 0a             	sub    sp,0xa
    2ce0:	89 e3                	mov    bx,sp
    2ce2:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2ce6:	90                   	nop
    2ce7:	9b                   	fwait
    2ce8:	9a d4 10 0b 33       	call   0x330b:0x10d4
    2ced:	8d be f8 fe          	lea    di,[bp-0x108]
    2cf1:	16                   	push   ss
    2cf2:	57                   	push   di
    2cf3:	68 ff 00             	push   0xff
    2cf6:	9a e7 17 1a 2d       	call   0x2d1a:0x17e7
    2cfb:	eb 1f                	jmp    0x2d1c
    2cfd:	8d be f4 fd          	lea    di,[bp-0x20c]
    2d01:	16                   	push   ss
    2d02:	57                   	push   di
    2d03:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2d07:	06                   	push   es
    2d08:	57                   	push   di
    2d09:	9a 24 15 03 5e       	call   0x5e03:0x1524
    2d0e:	8d be f8 fe          	lea    di,[bp-0x108]
    2d12:	16                   	push   ss
    2d13:	57                   	push   di
    2d14:	68 ff 00             	push   0xff
    2d17:	9a e7 17 2c 2d       	call   0x2d2c:0x17e7
    2d1c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2d20:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2d24:	2d 04 00             	sub    ax,0x4
    2d27:	71 05                	jno    0x2d2e
    2d29:	9a 3e 04 41 2d       	call   0x2d41:0x43e
    2d2e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2d31:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2d35:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2d39:	2d 04 00             	sub    ax,0x4
    2d3c:	71 05                	jno    0x2d43
    2d3e:	9a 3e 04 6e 2d       	call   0x2d6e:0x43e
    2d43:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d46:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d49:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2d4c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2d50:	06                   	push   es
    2d51:	57                   	push   di
    2d52:	9a d4 19 a5 2d       	call   0x2da5:0x19d4
    2d57:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2d5a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2d5d:	ff 76 12             	push   WORD PTR [bp+0x12]
    2d60:	ff 76 10             	push   WORD PTR [bp+0x10]
    2d63:	bf a2 0b             	mov    di,0xba2
    2d66:	b8 81 2d             	mov    ax,0x2d81
    2d69:	50                   	push   ax
    2d6a:	57                   	push   di
    2d6b:	9a 55 22 88 2d       	call   0x2d88:0x2255
    2d70:	08 c0                	or     al,al
    2d72:	75 03                	jne    0x2d77
    2d74:	e9 7f 00             	jmp    0x2df6
    2d77:	ff 76 12             	push   WORD PTR [bp+0x12]
    2d7a:	ff 76 10             	push   WORD PTR [bp+0x10]
    2d7d:	bf a2 0b             	mov    di,0xba2
    2d80:	b8 f7 2f             	mov    ax,0x2ff7
    2d83:	50                   	push   ax
    2d84:	57                   	push   di
    2d85:	9a 73 22 b3 2d       	call   0x2db3:0x2273
    2d8a:	89 c7                	mov    di,ax
    2d8c:	8e c2                	mov    es,dx
    2d8e:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2d92:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2d96:	8d be f4 fd          	lea    di,[bp-0x20c]
    2d9a:	16                   	push   ss
    2d9b:	57                   	push   di
    2d9c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2da0:	06                   	push   es
    2da1:	57                   	push   di
    2da2:	9a 53 1d ee 2d       	call   0x2dee:0x1d53
    2da7:	8d be f8 fe          	lea    di,[bp-0x108]
    2dab:	16                   	push   ss
    2dac:	57                   	push   di
    2dad:	68 ff 00             	push   0xff
    2db0:	9a e7 17 c5 2d       	call   0x2dc5:0x17e7
    2db5:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2db9:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2dbd:	2d 04 00             	sub    ax,0x4
    2dc0:	71 05                	jno    0x2dc7
    2dc2:	9a 3e 04 da 2d       	call   0x2dda:0x43e
    2dc7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2dca:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2dce:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    2dd2:	2d 04 00             	sub    ax,0x4
    2dd5:	71 05                	jno    0x2ddc
    2dd7:	9a 3e 04 0e 2e       	call   0x2e0e:0x43e
    2ddc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2ddf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2de2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2de5:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2de9:	06                   	push   es
    2dea:	57                   	push   di
    2deb:	9a d4 19 32 2e       	call   0x2e32:0x19d4
    2df0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2df3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2df6:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    2dfb:	77 03                	ja     0x2e00
    2dfd:	e9 ac 01             	jmp    0x2fac
    2e00:	8d be f8 fd          	lea    di,[bp-0x208]
    2e04:	16                   	push   ss
    2e05:	57                   	push   di
    2e06:	bf 1f 2b             	mov    di,0x2b1f
    2e09:	0e                   	push   cs
    2e0a:	57                   	push   di
    2e0b:	9a cd 17 19 2e       	call   0x2e19:0x17cd
    2e10:	8d be f8 fe          	lea    di,[bp-0x108]
    2e14:	16                   	push   ss
    2e15:	57                   	push   di
    2e16:	9a 4c 18 23 2e       	call   0x2e23:0x184c
    2e1b:	bf 1f 2b             	mov    di,0x2b1f
    2e1e:	0e                   	push   cs
    2e1f:	57                   	push   di
    2e20:	9a 4c 18 bf 2e       	call   0x2ebf:0x184c
    2e25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e28:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2e2d:	06                   	push   es
    2e2e:	57                   	push   di
    2e2f:	9a 8c 1d 78 2e       	call   0x2e78:0x1d8c
    2e34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e37:	06                   	push   es
    2e38:	57                   	push   di
    2e39:	9a d5 33 8e 3d       	call   0x3d8e:0x33d5
    2e3e:	89 c7                	mov    di,ax
    2e40:	8e c2                	mov    es,dx
    2e42:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2e46:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2e4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e4d:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2e52:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2e56:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2e5a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2e5e:	06                   	push   es
    2e5f:	57                   	push   di
    2e60:	9a 99 20 83 2e       	call   0x2e83:0x2099
    2e65:	8d be f4 fd          	lea    di,[bp-0x20c]
    2e69:	16                   	push   ss
    2e6a:	57                   	push   di
    2e6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e6e:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2e73:	06                   	push   es
    2e74:	57                   	push   di
    2e75:	9a 53 1d 93 2e       	call   0x2e93:0x1d53
    2e7a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2e7e:	06                   	push   es
    2e7f:	57                   	push   di
    2e80:	9a 03 20 b3 2e       	call   0x2eb3:0x2003
    2e85:	50                   	push   ax
    2e86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e89:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2e8e:	06                   	push   es
    2e8f:	57                   	push   di
    2e90:	9a bf 17 a8 2e       	call   0x2ea8:0x17bf
    2e95:	8d be f4 fd          	lea    di,[bp-0x20c]
    2e99:	16                   	push   ss
    2e9a:	57                   	push   di
    2e9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e9e:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2ea3:	06                   	push   es
    2ea4:	57                   	push   di
    2ea5:	9a 53 1d d5 2e       	call   0x2ed5:0x1d53
    2eaa:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2eae:	06                   	push   es
    2eaf:	57                   	push   di
    2eb0:	9a 4e 20 ac 56       	call   0x56ac:0x204e
    2eb5:	b9 03 00             	mov    cx,0x3
    2eb8:	f7 e9                	imul   cx
    2eba:	71 05                	jno    0x2ec1
    2ebc:	9a 3e 04 32 2f       	call   0x2f32:0x43e
    2ec1:	99                   	cwd
    2ec2:	b9 02 00             	mov    cx,0x2
    2ec5:	f7 f9                	idiv   cx
    2ec7:	50                   	push   ax
    2ec8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ecb:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2ed0:	06                   	push   es
    2ed1:	57                   	push   di
    2ed2:	9a e1 17 e5 2e       	call   0x2ee5:0x17e1
    2ed7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2eda:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2edd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ee0:	06                   	push   es
    2ee1:	57                   	push   di
    2ee2:	9a 06 1a 05 2f       	call   0x2f05:0x1a06
    2ee7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2eea:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2eed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ef0:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2ef5:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    2ef9:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2efd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2f00:	06                   	push   es
    2f01:	57                   	push   di
    2f02:	9a 7b 17 13 2f       	call   0x2f13:0x177b
    2f07:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f0a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2f0e:	06                   	push   es
    2f0f:	57                   	push   di
    2f10:	9a 9d 17 1d 2f       	call   0x2f1d:0x179d
    2f15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f18:	06                   	push   es
    2f19:	57                   	push   di
    2f1a:	9a a9 18 54 2f       	call   0x2f54:0x18a9
    2f1f:	8b d0                	mov    dx,ax
    2f21:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2f25:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2f29:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    2f2d:	71 05                	jno    0x2f34
    2f2f:	9a 3e 04 48 2f       	call   0x2f48:0x43e
    2f34:	3b c2                	cmp    ax,dx
    2f36:	7e 20                	jle    0x2f58
    2f38:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2f3c:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2f40:	2d 08 00             	sub    ax,0x8
    2f43:	71 05                	jno    0x2f4a
    2f45:	9a 3e 04 75 2f       	call   0x2f75:0x43e
    2f4a:	50                   	push   ax
    2f4b:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2f4f:	06                   	push   es
    2f50:	57                   	push   di
    2f51:	9a 7b 17 60 2f       	call   0x2f60:0x177b
    2f56:	eb bd                	jmp    0x2f15
    2f58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f5b:	06                   	push   es
    2f5c:	57                   	push   di
    2f5d:	9a f4 18 97 2f       	call   0x2f97:0x18f4
    2f62:	8b d0                	mov    dx,ax
    2f64:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2f68:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2f6c:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    2f70:	71 05                	jno    0x2f77
    2f72:	9a 3e 04 8b 2f       	call   0x2f8b:0x43e
    2f77:	3b c2                	cmp    ax,dx
    2f79:	7e 20                	jle    0x2f9b
    2f7b:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2f7f:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2f83:	2d 08 00             	sub    ax,0x8
    2f86:	71 05                	jno    0x2f8d
    2f88:	9a 3e 04 b9 2f       	call   0x2fb9:0x43e
    2f8d:	50                   	push   ax
    2f8e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2f92:	06                   	push   es
    2f93:	57                   	push   di
    2f94:	9a 9d 17 aa 2f       	call   0x2faa:0x179d
    2f99:	eb bd                	jmp    0x2f58
    2f9b:	6a 01                	push   0x1
    2f9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa0:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    2fa5:	06                   	push   es
    2fa6:	57                   	push   di
    2fa7:	9a 77 1c 1a 33       	call   0x331a:0x1c77
    2fac:	c9                   	leave
    2fad:	ca 0e 00             	retf   0xe
    2fb0:	55                   	push   bp
    2fb1:	89 e5                	mov    bp,sp
    2fb3:	b8 04 00             	mov    ax,0x4
    2fb6:	9a 44 04 d0 2f       	call   0x2fd0:0x444
    2fbb:	83 ec 04             	sub    sp,0x4
    2fbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc1:	06                   	push   es
    2fc2:	57                   	push   di
    2fc3:	9a 7d 52 ef 2f       	call   0x2fef:0x527d
    2fc8:	2d 01 00             	sub    ax,0x1
    2fcb:	71 05                	jno    0x2fd2
    2fcd:	9a 3e 04 fe 2f       	call   0x2ffe:0x43e
    2fd2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2fd5:	31 c0                	xor    ax,ax
    2fd7:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2fda:	7f 58                	jg     0x3034
    2fdc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2fdf:	eb 03                	jmp    0x2fe4
    2fe1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2fe4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2fe7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fea:	06                   	push   es
    2feb:	57                   	push   di
    2fec:	9a 46 52 0f 30       	call   0x300f:0x5246
    2ff1:	52                   	push   dx
    2ff2:	50                   	push   ax
    2ff3:	bf 22 00             	mov    di,0x22
    2ff6:	b8 17 30             	mov    ax,0x3017
    2ff9:	50                   	push   ax
    2ffa:	57                   	push   di
    2ffb:	9a 55 22 1e 30       	call   0x301e:0x2255
    3000:	08 c0                	or     al,al
    3002:	74 28                	je     0x302c
    3004:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3007:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    300a:	06                   	push   es
    300b:	57                   	push   di
    300c:	9a 46 52 a9 3d       	call   0x3da9:0x5246
    3011:	52                   	push   dx
    3012:	50                   	push   ax
    3013:	bf 22 00             	mov    di,0x22
    3016:	b8 c5 5d             	mov    ax,0x5dc5
    3019:	50                   	push   ax
    301a:	57                   	push   di
    301b:	9a 73 22 41 30       	call   0x3041:0x2273
    3020:	52                   	push   dx
    3021:	50                   	push   ax
    3022:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3025:	06                   	push   es
    3026:	57                   	push   di
    3027:	9a fb 25 4d 35       	call   0x354d:0x25fb
    302c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    302f:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3032:	75 ad                	jne    0x2fe1
    3034:	c9                   	leave
    3035:	ca 04 00             	retf   0x4
    3038:	55                   	push   bp
    3039:	89 e5                	mov    bp,sp
    303b:	b8 04 00             	mov    ax,0x4
    303e:	9a 44 04 f1 32       	call   0x32f1:0x444
    3043:	83 ec 04             	sub    sp,0x4
    3046:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3049:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    304e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3051:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3054:	06                   	push   es
    3055:	57                   	push   di
    3056:	9a d2 31 7b 30       	call   0x307b:0x31d2
    305b:	6a 01                	push   0x1
    305d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3060:	06                   	push   es
    3061:	57                   	push   di
    3062:	9a fb 2f 71 30       	call   0x3071:0x2ffb
    3067:	6a 00                	push   0x0
    3069:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    306c:	06                   	push   es
    306d:	57                   	push   di
    306e:	9a d2 2e 9c 30       	call   0x309c:0x2ed2
    3073:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3076:	06                   	push   es
    3077:	57                   	push   di
    3078:	9a bf 31 90 30       	call   0x3090:0x31bf
    307d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3080:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3085:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3088:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    308b:	06                   	push   es
    308c:	57                   	push   di
    308d:	9a d2 31 b2 30       	call   0x30b2:0x31d2
    3092:	6a 01                	push   0x1
    3094:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3097:	06                   	push   es
    3098:	57                   	push   di
    3099:	9a fb 2f a8 30       	call   0x30a8:0x2ffb
    309e:	6a 00                	push   0x0
    30a0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    30a3:	06                   	push   es
    30a4:	57                   	push   di
    30a5:	9a d2 2e d3 30       	call   0x30d3:0x2ed2
    30aa:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    30ad:	06                   	push   es
    30ae:	57                   	push   di
    30af:	9a bf 31 c7 30       	call   0x30c7:0x31bf
    30b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30b7:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    30bc:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    30bf:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    30c2:	06                   	push   es
    30c3:	57                   	push   di
    30c4:	9a d2 31 e9 30       	call   0x30e9:0x31d2
    30c9:	6a 01                	push   0x1
    30cb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    30ce:	06                   	push   es
    30cf:	57                   	push   di
    30d0:	9a fb 2f df 30       	call   0x30df:0x2ffb
    30d5:	6a 00                	push   0x0
    30d7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    30da:	06                   	push   es
    30db:	57                   	push   di
    30dc:	9a d2 2e 0a 31       	call   0x310a:0x2ed2
    30e1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    30e4:	06                   	push   es
    30e5:	57                   	push   di
    30e6:	9a bf 31 fe 30       	call   0x30fe:0x31bf
    30eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30ee:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    30f3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    30f6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    30f9:	06                   	push   es
    30fa:	57                   	push   di
    30fb:	9a d2 31 20 31       	call   0x3120:0x31d2
    3100:	6a 01                	push   0x1
    3102:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3105:	06                   	push   es
    3106:	57                   	push   di
    3107:	9a fb 2f 16 31       	call   0x3116:0x2ffb
    310c:	6a 00                	push   0x0
    310e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3111:	06                   	push   es
    3112:	57                   	push   di
    3113:	9a d2 2e 41 31       	call   0x3141:0x2ed2
    3118:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    311b:	06                   	push   es
    311c:	57                   	push   di
    311d:	9a bf 31 35 31       	call   0x3135:0x31bf
    3122:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3125:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    312a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    312d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3130:	06                   	push   es
    3131:	57                   	push   di
    3132:	9a d2 31 57 31       	call   0x3157:0x31d2
    3137:	6a 01                	push   0x1
    3139:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    313c:	06                   	push   es
    313d:	57                   	push   di
    313e:	9a fb 2f 4d 31       	call   0x314d:0x2ffb
    3143:	6a 00                	push   0x0
    3145:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3148:	06                   	push   es
    3149:	57                   	push   di
    314a:	9a d2 2e 78 31       	call   0x3178:0x2ed2
    314f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3152:	06                   	push   es
    3153:	57                   	push   di
    3154:	9a bf 31 6c 31       	call   0x316c:0x31bf
    3159:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    315c:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    3161:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3164:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3167:	06                   	push   es
    3168:	57                   	push   di
    3169:	9a d2 31 8e 31       	call   0x318e:0x31d2
    316e:	6a 01                	push   0x1
    3170:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3173:	06                   	push   es
    3174:	57                   	push   di
    3175:	9a fb 2f 84 31       	call   0x3184:0x2ffb
    317a:	6a 00                	push   0x0
    317c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    317f:	06                   	push   es
    3180:	57                   	push   di
    3181:	9a d2 2e af 31       	call   0x31af:0x2ed2
    3186:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3189:	06                   	push   es
    318a:	57                   	push   di
    318b:	9a bf 31 a3 31       	call   0x31a3:0x31bf
    3190:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3193:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3198:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    319b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    319e:	06                   	push   es
    319f:	57                   	push   di
    31a0:	9a d2 31 c5 31       	call   0x31c5:0x31d2
    31a5:	6a 01                	push   0x1
    31a7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31aa:	06                   	push   es
    31ab:	57                   	push   di
    31ac:	9a fb 2f bb 31       	call   0x31bb:0x2ffb
    31b1:	6a 00                	push   0x0
    31b3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31b6:	06                   	push   es
    31b7:	57                   	push   di
    31b8:	9a d2 2e e6 31       	call   0x31e6:0x2ed2
    31bd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31c0:	06                   	push   es
    31c1:	57                   	push   di
    31c2:	9a bf 31 da 31       	call   0x31da:0x31bf
    31c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31ca:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    31cf:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    31d2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    31d5:	06                   	push   es
    31d6:	57                   	push   di
    31d7:	9a d2 31 fc 31       	call   0x31fc:0x31d2
    31dc:	6a 01                	push   0x1
    31de:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31e1:	06                   	push   es
    31e2:	57                   	push   di
    31e3:	9a fb 2f f2 31       	call   0x31f2:0x2ffb
    31e8:	6a 00                	push   0x0
    31ea:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31ed:	06                   	push   es
    31ee:	57                   	push   di
    31ef:	9a d2 2e 1d 32       	call   0x321d:0x2ed2
    31f4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    31f7:	06                   	push   es
    31f8:	57                   	push   di
    31f9:	9a bf 31 11 32       	call   0x3211:0x31bf
    31fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3201:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    3206:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3209:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    320c:	06                   	push   es
    320d:	57                   	push   di
    320e:	9a d2 31 33 32       	call   0x3233:0x31d2
    3213:	6a 01                	push   0x1
    3215:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3218:	06                   	push   es
    3219:	57                   	push   di
    321a:	9a fb 2f 29 32       	call   0x3229:0x2ffb
    321f:	6a 00                	push   0x0
    3221:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3224:	06                   	push   es
    3225:	57                   	push   di
    3226:	9a d2 2e 54 32       	call   0x3254:0x2ed2
    322b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    322e:	06                   	push   es
    322f:	57                   	push   di
    3230:	9a bf 31 48 32       	call   0x3248:0x31bf
    3235:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3238:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    323d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3240:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3243:	06                   	push   es
    3244:	57                   	push   di
    3245:	9a d2 31 6a 32       	call   0x326a:0x31d2
    324a:	6a 01                	push   0x1
    324c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    324f:	06                   	push   es
    3250:	57                   	push   di
    3251:	9a fb 2f 60 32       	call   0x3260:0x2ffb
    3256:	6a 00                	push   0x0
    3258:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    325b:	06                   	push   es
    325c:	57                   	push   di
    325d:	9a d2 2e 8b 32       	call   0x328b:0x2ed2
    3262:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3265:	06                   	push   es
    3266:	57                   	push   di
    3267:	9a bf 31 7f 32       	call   0x327f:0x31bf
    326c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    326f:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3274:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3277:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    327a:	06                   	push   es
    327b:	57                   	push   di
    327c:	9a d2 31 a1 32       	call   0x32a1:0x31d2
    3281:	6a 01                	push   0x1
    3283:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3286:	06                   	push   es
    3287:	57                   	push   di
    3288:	9a fb 2f 97 32       	call   0x3297:0x2ffb
    328d:	6a 00                	push   0x0
    328f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3292:	06                   	push   es
    3293:	57                   	push   di
    3294:	9a d2 2e c2 32       	call   0x32c2:0x2ed2
    3299:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    329c:	06                   	push   es
    329d:	57                   	push   di
    329e:	9a bf 31 b6 32       	call   0x32b6:0x31bf
    32a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32a6:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    32ab:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    32ae:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    32b1:	06                   	push   es
    32b2:	57                   	push   di
    32b3:	9a d2 31 d8 32       	call   0x32d8:0x31d2
    32b8:	6a 01                	push   0x1
    32ba:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32bd:	06                   	push   es
    32be:	57                   	push   di
    32bf:	9a fb 2f ce 32       	call   0x32ce:0x2ffb
    32c4:	6a 00                	push   0x0
    32c6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32c9:	06                   	push   es
    32ca:	57                   	push   di
    32cb:	9a d2 2e 3f 35       	call   0x353f:0x2ed2
    32d0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32d3:	06                   	push   es
    32d4:	57                   	push   di
    32d5:	9a bf 31 12 3a       	call   0x3a12:0x31bf
    32da:	c9                   	leave
    32db:	ca 04 00             	retf   0x4
    32de:	01 23                	add    WORD PTR [bp+di],sp
    32e0:	00 00                	add    BYTE PTR [bx+si],al
    32e2:	00 00                	add    BYTE PTR [bx+si],al
    32e4:	ff 00                	inc    WORD PTR [bx+si]
    32e6:	00 00                	add    BYTE PTR [bx+si],al
    32e8:	55                   	push   bp
    32e9:	89 e5                	mov    bp,sp
    32eb:	b8 02 02             	mov    ax,0x202
    32ee:	9a 44 04 56 33       	call   0x3356:0x444
    32f3:	81 ec 02 02          	sub    sp,0x202
    32f7:	8d be fe fd          	lea    di,[bp-0x202]
    32fb:	16                   	push   ss
    32fc:	57                   	push   di
    32fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3300:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    3305:	99                   	cwd
    3306:	52                   	push   dx
    3307:	50                   	push   ax
    3308:	9a a9 08 30 33       	call   0x3330:0x8a9
    330d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3310:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    3315:	06                   	push   es
    3316:	57                   	push   di
    3317:	9a 8c 1d 3f 33       	call   0x333f:0x1d8c
    331c:	8d be fe fd          	lea    di,[bp-0x202]
    3320:	16                   	push   ss
    3321:	57                   	push   di
    3322:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3325:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    332a:	99                   	cwd
    332b:	52                   	push   dx
    332c:	50                   	push   ax
    332d:	9a a9 08 a1 33       	call   0x33a1:0x8a9
    3332:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3335:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    333a:	06                   	push   es
    333b:	57                   	push   di
    333c:	9a 8c 1d 24 34       	call   0x3424:0x1d8c
    3341:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3344:	81 c7 f6 07          	add    di,0x7f6
    3348:	06                   	push   es
    3349:	57                   	push   di
    334a:	8d be fe fe          	lea    di,[bp-0x102]
    334e:	16                   	push   ss
    334f:	57                   	push   di
    3350:	68 ff 00             	push   0xff
    3353:	9a e7 17 66 33       	call   0x3366:0x17e7
    3358:	bf de 32             	mov    di,0x32de
    335b:	0e                   	push   cs
    335c:	57                   	push   di
    335d:	8d be fe fe          	lea    di,[bp-0x102]
    3361:	16                   	push   ss
    3362:	57                   	push   di
    3363:	9a 78 18 6f 33       	call   0x336f:0x1878
    3368:	99                   	cwd
    3369:	bf e0 32             	mov    di,0x32e0
    336c:	9a 16 04 8b 33       	call   0x338b:0x416
    3371:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3374:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3378:	76 3d                	jbe    0x33b7
    337a:	8d be fe fe          	lea    di,[bp-0x102]
    337e:	16                   	push   ss
    337f:	57                   	push   di
    3380:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3383:	30 e4                	xor    ah,ah
    3385:	50                   	push   ax
    3386:	6a 01                	push   0x1
    3388:	9a 75 19 b5 33       	call   0x33b5:0x1975
    338d:	8d be fe fd          	lea    di,[bp-0x202]
    3391:	16                   	push   ss
    3392:	57                   	push   di
    3393:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3396:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    339b:	99                   	cwd
    339c:	52                   	push   dx
    339d:	50                   	push   ax
    339e:	9a a9 08 00 34       	call   0x3400:0x8a9
    33a3:	8d be fe fe          	lea    di,[bp-0x102]
    33a7:	16                   	push   ss
    33a8:	57                   	push   di
    33a9:	68 ff 00             	push   0xff
    33ac:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    33af:	30 e4                	xor    ah,ah
    33b1:	50                   	push   ax
    33b2:	9a 16 19 c5 33       	call   0x33c5:0x1916
    33b7:	bf de 32             	mov    di,0x32de
    33ba:	0e                   	push   cs
    33bb:	57                   	push   di
    33bc:	8d be fe fe          	lea    di,[bp-0x102]
    33c0:	16                   	push   ss
    33c1:	57                   	push   di
    33c2:	9a 78 18 ce 33       	call   0x33ce:0x1878
    33c7:	99                   	cwd
    33c8:	bf e0 32             	mov    di,0x32e0
    33cb:	9a 16 04 ea 33       	call   0x33ea:0x416
    33d0:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    33d3:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    33d7:	76 3d                	jbe    0x3416
    33d9:	8d be fe fe          	lea    di,[bp-0x102]
    33dd:	16                   	push   ss
    33de:	57                   	push   di
    33df:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    33e2:	30 e4                	xor    ah,ah
    33e4:	50                   	push   ax
    33e5:	6a 01                	push   0x1
    33e7:	9a 75 19 14 34       	call   0x3414:0x1975
    33ec:	8d be fe fd          	lea    di,[bp-0x202]
    33f0:	16                   	push   ss
    33f1:	57                   	push   di
    33f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33f5:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    33fa:	99                   	cwd
    33fb:	52                   	push   dx
    33fc:	50                   	push   ax
    33fd:	9a a9 08 01 3f       	call   0x3f01:0x8a9
    3402:	8d be fe fe          	lea    di,[bp-0x102]
    3406:	16                   	push   ss
    3407:	57                   	push   di
    3408:	68 ff 00             	push   0xff
    340b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    340e:	30 e4                	xor    ah,ah
    3410:	50                   	push   ax
    3411:	9a 16 19 4c 34       	call   0x344c:0x1916
    3416:	8d be fe fe          	lea    di,[bp-0x102]
    341a:	16                   	push   ss
    341b:	57                   	push   di
    341c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    341f:	06                   	push   es
    3420:	57                   	push   di
    3421:	9a 8c 1d 38 3c       	call   0x3c38:0x1d8c
    3426:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3429:	26 c4 bd 94 07       	les    di,DWORD PTR es:[di+0x794]
    342e:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3432:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    3436:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    343a:	eb 03                	jmp    0x343f
    343c:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    343f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3442:	30 e4                	xor    ah,ah
    3444:	05 01 00             	add    ax,0x1
    3447:	71 05                	jno    0x344e
    3449:	9a 3e 04 9d 34       	call   0x349d:0x43e
    344e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3451:	26 3b 85 f2 07       	cmp    ax,WORD PTR es:[di+0x7f2]
    3456:	b0 00                	mov    al,0x0
    3458:	75 01                	jne    0x345b
    345a:	40                   	inc    ax
    345b:	50                   	push   ax
    345c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    345f:	30 e4                	xor    ah,ah
    3461:	50                   	push   ax
    3462:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3466:	06                   	push   es
    3467:	57                   	push   di
    3468:	9a 53 13 76 34       	call   0x3476:0x1353
    346d:	89 c7                	mov    di,ax
    346f:	8e c2                	mov    es,dx
    3471:	06                   	push   es
    3472:	57                   	push   di
    3473:	9a 75 12 93 34       	call   0x3493:0x1275
    3478:	80 7e ff 13          	cmp    BYTE PTR [bp-0x1],0x13
    347c:	75 be                	jne    0x343c
    347e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3481:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    3486:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    348a:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    348e:	06                   	push   es
    348f:	57                   	push   di
    3490:	9a 26 13 e8 34       	call   0x34e8:0x1326
    3495:	2d 01 00             	sub    ax,0x1
    3498:	71 05                	jno    0x349f
    349a:	9a 3e 04 a6 34       	call   0x34a6:0x43e
    349f:	99                   	cwd
    34a0:	bf e0 32             	mov    di,0x32e0
    34a3:	9a 16 04 c9 34       	call   0x34c9:0x416
    34a8:	88 86 f9 fe          	mov    BYTE PTR [bp-0x107],al
    34ac:	b0 00                	mov    al,0x0
    34ae:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    34b2:	77 4a                	ja     0x34fe
    34b4:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    34b7:	eb 03                	jmp    0x34bc
    34b9:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    34bc:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    34bf:	30 e4                	xor    ah,ah
    34c1:	05 01 00             	add    ax,0x1
    34c4:	71 05                	jno    0x34cb
    34c6:	9a 3e 04 1e 35       	call   0x351e:0x43e
    34cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34ce:	26 3b 85 f4 07       	cmp    ax,WORD PTR es:[di+0x7f4]
    34d3:	b0 00                	mov    al,0x0
    34d5:	75 01                	jne    0x34d8
    34d7:	40                   	inc    ax
    34d8:	50                   	push   ax
    34d9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    34dc:	30 e4                	xor    ah,ah
    34de:	50                   	push   ax
    34df:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    34e3:	06                   	push   es
    34e4:	57                   	push   di
    34e5:	9a 53 13 f3 34       	call   0x34f3:0x1353
    34ea:	89 c7                	mov    di,ax
    34ec:	8e c2                	mov    es,dx
    34ee:	06                   	push   es
    34ef:	57                   	push   di
    34f0:	9a 75 12 83 3c       	call   0x3c83:0x1275
    34f5:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    34f8:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    34fc:	75 bb                	jne    0x34b9
    34fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3501:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3506:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    350a:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    350e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3511:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    3516:	2d 01 00             	sub    ax,0x1
    3519:	71 05                	jno    0x3520
    351b:	9a 3e 04 b6 35       	call   0x35b6:0x43e
    3520:	99                   	cwd
    3521:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    3525:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    3529:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    352e:	8d be f2 fe          	lea    di,[bp-0x10e]
    3532:	16                   	push   ss
    3533:	57                   	push   di
    3534:	6a 00                	push   0x0
    3536:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    353a:	06                   	push   es
    353b:	57                   	push   di
    353c:	9a 95 28 86 35       	call   0x3586:0x2895
    3541:	08 c0                	or     al,al
    3543:	75 0a                	jne    0x354f
    3545:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3548:	06                   	push   es
    3549:	57                   	push   di
    354a:	9a 92 22 94 35       	call   0x3594:0x2292
    354f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3552:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3557:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    355b:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    355f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3562:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    3567:	99                   	cwd
    3568:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    356c:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    3570:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3575:	8d be f2 fe          	lea    di,[bp-0x10e]
    3579:	16                   	push   ss
    357a:	57                   	push   di
    357b:	6a 00                	push   0x0
    357d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3581:	06                   	push   es
    3582:	57                   	push   di
    3583:	9a 95 28 fe 35       	call   0x35fe:0x2895
    3588:	08 c0                	or     al,al
    358a:	75 0a                	jne    0x3596
    358c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    358f:	06                   	push   es
    3590:	57                   	push   di
    3591:	9a 92 22 0c 36       	call   0x360c:0x2292
    3596:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3599:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    359e:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    35a2:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    35a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35a9:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    35ae:	2d 01 00             	sub    ax,0x1
    35b1:	71 05                	jno    0x35b8
    35b3:	9a 3e 04 2e 36       	call   0x362e:0x43e
    35b8:	99                   	cwd
    35b9:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    35bd:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    35c1:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    35c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35c9:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    35ce:	99                   	cwd
    35cf:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    35d3:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    35d7:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    35dc:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    35e2:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    35e8:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    35ed:	8d be e2 fe          	lea    di,[bp-0x11e]
    35f1:	16                   	push   ss
    35f2:	57                   	push   di
    35f3:	6a 02                	push   0x2
    35f5:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    35f9:	06                   	push   es
    35fa:	57                   	push   di
    35fb:	9a 95 28 76 36       	call   0x3676:0x2895
    3600:	08 c0                	or     al,al
    3602:	75 0a                	jne    0x360e
    3604:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3607:	06                   	push   es
    3608:	57                   	push   di
    3609:	9a 92 22 84 36       	call   0x3684:0x2292
    360e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3611:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    3616:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    361a:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    361e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3621:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    3626:	2d 01 00             	sub    ax,0x1
    3629:	71 05                	jno    0x3630
    362b:	9a 3e 04 a6 36       	call   0x36a6:0x43e
    3630:	99                   	cwd
    3631:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    3635:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    3639:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    363e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3641:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    3646:	99                   	cwd
    3647:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    364b:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    364f:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    3654:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    365a:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    3660:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3665:	8d be e2 fe          	lea    di,[bp-0x11e]
    3669:	16                   	push   ss
    366a:	57                   	push   di
    366b:	6a 02                	push   0x2
    366d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3671:	06                   	push   es
    3672:	57                   	push   di
    3673:	9a 95 28 ee 36       	call   0x36ee:0x2895
    3678:	08 c0                	or     al,al
    367a:	75 0a                	jne    0x3686
    367c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    367f:	06                   	push   es
    3680:	57                   	push   di
    3681:	9a 92 22 fc 36       	call   0x36fc:0x2292
    3686:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3689:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    368e:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3692:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    3696:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3699:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    369e:	2d 01 00             	sub    ax,0x1
    36a1:	71 05                	jno    0x36a8
    36a3:	9a 3e 04 1e 37       	call   0x371e:0x43e
    36a8:	99                   	cwd
    36a9:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    36ad:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    36b1:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    36b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36b9:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    36be:	99                   	cwd
    36bf:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    36c3:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    36c7:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    36cc:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    36d2:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    36d8:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    36dd:	8d be e2 fe          	lea    di,[bp-0x11e]
    36e1:	16                   	push   ss
    36e2:	57                   	push   di
    36e3:	6a 02                	push   0x2
    36e5:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    36e9:	06                   	push   es
    36ea:	57                   	push   di
    36eb:	9a 95 28 66 37       	call   0x3766:0x2895
    36f0:	08 c0                	or     al,al
    36f2:	75 0a                	jne    0x36fe
    36f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36f7:	06                   	push   es
    36f8:	57                   	push   di
    36f9:	9a 92 22 74 37       	call   0x3774:0x2292
    36fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3701:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    3706:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    370a:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    370e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3711:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    3716:	2d 01 00             	sub    ax,0x1
    3719:	71 05                	jno    0x3720
    371b:	9a 3e 04 96 37       	call   0x3796:0x43e
    3720:	99                   	cwd
    3721:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    3725:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    3729:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    372e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3731:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    3736:	99                   	cwd
    3737:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    373b:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    373f:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    3744:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    374a:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    3750:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3755:	8d be e2 fe          	lea    di,[bp-0x11e]
    3759:	16                   	push   ss
    375a:	57                   	push   di
    375b:	6a 02                	push   0x2
    375d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3761:	06                   	push   es
    3762:	57                   	push   di
    3763:	9a 95 28 cd 37       	call   0x37cd:0x2895
    3768:	08 c0                	or     al,al
    376a:	75 0a                	jne    0x3776
    376c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    376f:	06                   	push   es
    3770:	57                   	push   di
    3771:	9a 92 22 db 37       	call   0x37db:0x2292
    3776:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3779:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    377e:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3782:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    3786:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3789:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    378e:	2d 01 00             	sub    ax,0x1
    3791:	71 05                	jno    0x3798
    3793:	9a 3e 04 fa 39       	call   0x39fa:0x43e
    3798:	99                   	cwd
    3799:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    379d:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    37a1:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    37a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37a9:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    37ae:	99                   	cwd
    37af:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    37b3:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    37b7:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    37bc:	8d be ea fe          	lea    di,[bp-0x116]
    37c0:	16                   	push   ss
    37c1:	57                   	push   di
    37c2:	6a 01                	push   0x1
    37c4:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    37c8:	06                   	push   es
    37c9:	57                   	push   di
    37ca:	9a 95 28 38 38       	call   0x3838:0x2895
    37cf:	08 c0                	or     al,al
    37d1:	75 0a                	jne    0x37dd
    37d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37d6:	06                   	push   es
    37d7:	57                   	push   di
    37d8:	9a 92 22 46 38       	call   0x3846:0x2292
    37dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37e0:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    37e5:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    37e9:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    37ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37f0:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    37f5:	99                   	cwd
    37f6:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    37fa:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    37fe:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    3803:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    3808:	99                   	cwd
    3809:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    380d:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    3811:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    3816:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    381c:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    3822:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3827:	8d be e2 fe          	lea    di,[bp-0x11e]
    382b:	16                   	push   ss
    382c:	57                   	push   di
    382d:	6a 02                	push   0x2
    382f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3833:	06                   	push   es
    3834:	57                   	push   di
    3835:	9a 95 28 a3 38       	call   0x38a3:0x2895
    383a:	08 c0                	or     al,al
    383c:	75 0a                	jne    0x3848
    383e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3841:	06                   	push   es
    3842:	57                   	push   di
    3843:	9a 92 22 b1 38       	call   0x38b1:0x2292
    3848:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    384b:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    3850:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3854:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    3858:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    385b:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    3860:	99                   	cwd
    3861:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    3865:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    3869:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    386e:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    3873:	99                   	cwd
    3874:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    3878:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    387c:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    3881:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    3887:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    388d:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3892:	8d be e2 fe          	lea    di,[bp-0x11e]
    3896:	16                   	push   ss
    3897:	57                   	push   di
    3898:	6a 02                	push   0x2
    389a:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    389e:	06                   	push   es
    389f:	57                   	push   di
    38a0:	9a 95 28 0e 39       	call   0x390e:0x2895
    38a5:	08 c0                	or     al,al
    38a7:	75 0a                	jne    0x38b3
    38a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38ac:	06                   	push   es
    38ad:	57                   	push   di
    38ae:	9a 92 22 1c 39       	call   0x391c:0x2292
    38b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38b6:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    38bb:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    38bf:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    38c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38c6:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    38cb:	99                   	cwd
    38cc:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    38d0:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    38d4:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    38d9:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    38de:	99                   	cwd
    38df:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    38e3:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    38e7:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    38ec:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    38f2:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    38f8:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    38fd:	8d be e2 fe          	lea    di,[bp-0x11e]
    3901:	16                   	push   ss
    3902:	57                   	push   di
    3903:	6a 02                	push   0x2
    3905:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3909:	06                   	push   es
    390a:	57                   	push   di
    390b:	9a 95 28 79 39       	call   0x3979:0x2895
    3910:	08 c0                	or     al,al
    3912:	75 0a                	jne    0x391e
    3914:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3917:	06                   	push   es
    3918:	57                   	push   di
    3919:	9a 92 22 87 39       	call   0x3987:0x2292
    391e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3921:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3926:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    392a:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    392e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3931:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    3936:	99                   	cwd
    3937:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    393b:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    393f:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    3944:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    3949:	99                   	cwd
    394a:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    394e:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    3952:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    3957:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    395d:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    3963:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3968:	8d be e2 fe          	lea    di,[bp-0x11e]
    396c:	16                   	push   ss
    396d:	57                   	push   di
    396e:	6a 02                	push   0x2
    3970:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3974:	06                   	push   es
    3975:	57                   	push   di
    3976:	9a 95 28 d3 39       	call   0x39d3:0x2895
    397b:	08 c0                	or     al,al
    397d:	75 0a                	jne    0x3989
    397f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3982:	06                   	push   es
    3983:	57                   	push   di
    3984:	9a 92 22 e1 39       	call   0x39e1:0x2292
    3989:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    398c:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    3991:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    3995:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    3999:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    399c:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    39a1:	99                   	cwd
    39a2:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    39a6:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    39aa:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    39af:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    39b4:	99                   	cwd
    39b5:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    39b9:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    39bd:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    39c2:	8d be ea fe          	lea    di,[bp-0x116]
    39c6:	16                   	push   ss
    39c7:	57                   	push   di
    39c8:	6a 01                	push   0x1
    39ca:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    39ce:	06                   	push   es
    39cf:	57                   	push   di
    39d0:	9a 95 28 6d 3f       	call   0x3f6d:0x2895
    39d5:	08 c0                	or     al,al
    39d7:	75 0a                	jne    0x39e3
    39d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39dc:	06                   	push   es
    39dd:	57                   	push   di
    39de:	9a 92 22 eb 39       	call   0x39eb:0x2292
    39e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39e6:	06                   	push   es
    39e7:	57                   	push   di
    39e8:	9a b0 2f c1 3b       	call   0x3bc1:0x2fb0
    39ed:	c9                   	leave
    39ee:	ca 04 00             	retf   0x4
    39f1:	55                   	push   bp
    39f2:	89 e5                	mov    bp,sp
    39f4:	b8 04 00             	mov    ax,0x4
    39f7:	9a 44 04 af 3b       	call   0x3baf:0x444
    39fc:	83 ec 04             	sub    sp,0x4
    39ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a02:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    3a07:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3a0a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3a0d:	06                   	push   es
    3a0e:	57                   	push   di
    3a0f:	9a 02 32 20 3a       	call   0x3a20:0x3202
    3a14:	08 c0                	or     al,al
    3a16:	74 0a                	je     0x3a22
    3a18:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3a1b:	06                   	push   es
    3a1c:	57                   	push   di
    3a1d:	9a d2 31 35 3a       	call   0x3a35:0x31d2
    3a22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a25:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3a2a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3a2d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3a30:	06                   	push   es
    3a31:	57                   	push   di
    3a32:	9a 02 32 43 3a       	call   0x3a43:0x3202
    3a37:	08 c0                	or     al,al
    3a39:	74 0a                	je     0x3a45
    3a3b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3a3e:	06                   	push   es
    3a3f:	57                   	push   di
    3a40:	9a d2 31 58 3a       	call   0x3a58:0x31d2
    3a45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a48:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    3a4d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3a50:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3a53:	06                   	push   es
    3a54:	57                   	push   di
    3a55:	9a 02 32 66 3a       	call   0x3a66:0x3202
    3a5a:	08 c0                	or     al,al
    3a5c:	74 0a                	je     0x3a68
    3a5e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3a61:	06                   	push   es
    3a62:	57                   	push   di
    3a63:	9a d2 31 7b 3a       	call   0x3a7b:0x31d2
    3a68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a6b:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    3a70:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3a73:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3a76:	06                   	push   es
    3a77:	57                   	push   di
    3a78:	9a 02 32 89 3a       	call   0x3a89:0x3202
    3a7d:	08 c0                	or     al,al
    3a7f:	74 0a                	je     0x3a8b
    3a81:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3a84:	06                   	push   es
    3a85:	57                   	push   di
    3a86:	9a d2 31 9e 3a       	call   0x3a9e:0x31d2
    3a8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a8e:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3a93:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3a96:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3a99:	06                   	push   es
    3a9a:	57                   	push   di
    3a9b:	9a 02 32 ac 3a       	call   0x3aac:0x3202
    3aa0:	08 c0                	or     al,al
    3aa2:	74 0a                	je     0x3aae
    3aa4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3aa7:	06                   	push   es
    3aa8:	57                   	push   di
    3aa9:	9a d2 31 c1 3a       	call   0x3ac1:0x31d2
    3aae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ab1:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    3ab6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3ab9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3abc:	06                   	push   es
    3abd:	57                   	push   di
    3abe:	9a 02 32 cf 3a       	call   0x3acf:0x3202
    3ac3:	08 c0                	or     al,al
    3ac5:	74 0a                	je     0x3ad1
    3ac7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3aca:	06                   	push   es
    3acb:	57                   	push   di
    3acc:	9a d2 31 e4 3a       	call   0x3ae4:0x31d2
    3ad1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ad4:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    3ad9:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3adc:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3adf:	06                   	push   es
    3ae0:	57                   	push   di
    3ae1:	9a 02 32 f2 3a       	call   0x3af2:0x3202
    3ae6:	08 c0                	or     al,al
    3ae8:	74 0a                	je     0x3af4
    3aea:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3aed:	06                   	push   es
    3aee:	57                   	push   di
    3aef:	9a d2 31 07 3b       	call   0x3b07:0x31d2
    3af4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3af7:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    3afc:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3aff:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3b02:	06                   	push   es
    3b03:	57                   	push   di
    3b04:	9a 02 32 15 3b       	call   0x3b15:0x3202
    3b09:	08 c0                	or     al,al
    3b0b:	74 0a                	je     0x3b17
    3b0d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b10:	06                   	push   es
    3b11:	57                   	push   di
    3b12:	9a d2 31 2a 3b       	call   0x3b2a:0x31d2
    3b17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b1a:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    3b1f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3b22:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3b25:	06                   	push   es
    3b26:	57                   	push   di
    3b27:	9a 02 32 38 3b       	call   0x3b38:0x3202
    3b2c:	08 c0                	or     al,al
    3b2e:	74 0a                	je     0x3b3a
    3b30:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b33:	06                   	push   es
    3b34:	57                   	push   di
    3b35:	9a d2 31 4d 3b       	call   0x3b4d:0x31d2
    3b3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b3d:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    3b42:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3b45:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3b48:	06                   	push   es
    3b49:	57                   	push   di
    3b4a:	9a 02 32 5b 3b       	call   0x3b5b:0x3202
    3b4f:	08 c0                	or     al,al
    3b51:	74 0a                	je     0x3b5d
    3b53:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b56:	06                   	push   es
    3b57:	57                   	push   di
    3b58:	9a d2 31 70 3b       	call   0x3b70:0x31d2
    3b5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b60:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    3b65:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3b68:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3b6b:	06                   	push   es
    3b6c:	57                   	push   di
    3b6d:	9a 02 32 7e 3b       	call   0x3b7e:0x3202
    3b72:	08 c0                	or     al,al
    3b74:	74 0a                	je     0x3b80
    3b76:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b79:	06                   	push   es
    3b7a:	57                   	push   di
    3b7b:	9a d2 31 93 3b       	call   0x3b93:0x31d2
    3b80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b83:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3b88:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3b8b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3b8e:	06                   	push   es
    3b8f:	57                   	push   di
    3b90:	9a 02 32 a1 3b       	call   0x3ba1:0x3202
    3b95:	08 c0                	or     al,al
    3b97:	74 0a                	je     0x3ba3
    3b99:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3b9c:	06                   	push   es
    3b9d:	57                   	push   di
    3b9e:	9a d2 31 dc 44       	call   0x44dc:0x31d2
    3ba3:	c9                   	leave
    3ba4:	ca 04 00             	retf   0x4
    3ba7:	55                   	push   bp
    3ba8:	89 e5                	mov    bp,sp
    3baa:	31 c0                	xor    ax,ax
    3bac:	9a 44 04 cf 3b       	call   0x3bcf:0x444
    3bb1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3bb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bb7:	26 89 85 f2 07       	mov    WORD PTR es:[di+0x7f2],ax
    3bbc:	06                   	push   es
    3bbd:	57                   	push   di
    3bbe:	9a e8 32 e1 3b       	call   0x3be1:0x32e8
    3bc3:	c9                   	leave
    3bc4:	ca 06 00             	retf   0x6
    3bc7:	55                   	push   bp
    3bc8:	89 e5                	mov    bp,sp
    3bca:	31 c0                	xor    ax,ax
    3bcc:	9a 44 04 00 3c       	call   0x3c00:0x444
    3bd1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3bd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bd7:	26 89 85 f4 07       	mov    WORD PTR es:[di+0x7f4],ax
    3bdc:	06                   	push   es
    3bdd:	57                   	push   di
    3bde:	9a e8 32 9b 40       	call   0x409b:0x32e8
    3be3:	c9                   	leave
    3be4:	ca 06 00             	retf   0x6
    3be7:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    3bea:	6d                   	ins    WORD PTR es:[di],dx
    3beb:	73 74                	jae    0x3c61
    3bed:	72 61                	jb     0x3c50
    3bef:	74 20                	je     0x3c11
    3bf1:	2d 20 03             	sub    ax,0x320
    3bf4:	20 2d                	and    BYTE PTR [di],ch
    3bf6:	20 55 89             	and    BYTE PTR [di-0x77],dl
    3bf9:	e5 b8                	in     ax,0xb8
    3bfb:	02 03                	add    al,BYTE PTR [bp+di]
    3bfd:	9a 44 04 14 3c       	call   0x3c14:0x444
    3c02:	81 ec 02 03          	sub    sp,0x302
    3c06:	8d be fe fe          	lea    di,[bp-0x102]
    3c0a:	16                   	push   ss
    3c0b:	57                   	push   di
    3c0c:	bf e7 3b             	mov    di,0x3be7
    3c0f:	0e                   	push   cs
    3c10:	57                   	push   di
    3c11:	9a cd 17 1e 3c       	call   0x3c1e:0x17cd
    3c16:	bf fa 1d             	mov    di,0x1dfa
    3c19:	1e                   	push   ds
    3c1a:	57                   	push   di
    3c1b:	9a 4c 18 28 3c       	call   0x3c28:0x184c
    3c20:	bf f3 3b             	mov    di,0x3bf3
    3c23:	0e                   	push   cs
    3c24:	57                   	push   di
    3c25:	9a 4c 18 3d 3c       	call   0x3c3d:0x184c
    3c2a:	8d be fe fd          	lea    di,[bp-0x202]
    3c2e:	16                   	push   ss
    3c2f:	57                   	push   di
    3c30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c33:	06                   	push   es
    3c34:	57                   	push   di
    3c35:	9a 53 1d 62 3c       	call   0x3c62:0x1d53
    3c3a:	9a 4c 18 4e 3c       	call   0x3c4e:0x184c
    3c3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c42:	81 c7 f6 07          	add    di,0x7f6
    3c46:	06                   	push   es
    3c47:	57                   	push   di
    3c48:	68 ff 00             	push   0xff
    3c4b:	9a e7 17 e8 3c       	call   0x3ce8:0x17e7
    3c50:	bf fa 1d             	mov    di,0x1dfa
    3c53:	1e                   	push   ds
    3c54:	57                   	push   di
    3c55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c58:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    3c5d:	06                   	push   es
    3c5e:	57                   	push   di
    3c5f:	9a 8c 1d dd 3d       	call   0x3ddd:0x1d8c
    3c64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c67:	26 c7 85 f0 07 64 00 	mov    WORD PTR es:[di+0x7f0],0x64
    3c6e:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    3c73:	b0 00                	mov    al,0x0
    3c75:	7c 01                	jl     0x3c78
    3c77:	40                   	inc    ax
    3c78:	50                   	push   ax
    3c79:	26 c4 bd 60 07       	les    di,DWORD PTR es:[di+0x760]
    3c7e:	06                   	push   es
    3c7f:	57                   	push   di
    3c80:	9a a5 13 9d 3c       	call   0x3c9d:0x13a5
    3c85:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    3c8a:	b0 00                	mov    al,0x0
    3c8c:	7c 01                	jl     0x3c8f
    3c8e:	40                   	inc    ax
    3c8f:	50                   	push   ax
    3c90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c93:	26 c4 bd 5c 07       	les    di,DWORD PTR es:[di+0x75c]
    3c98:	06                   	push   es
    3c99:	57                   	push   di
    3c9a:	9a a5 13 b7 3c       	call   0x3cb7:0x13a5
    3c9f:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    3ca4:	b0 00                	mov    al,0x0
    3ca6:	7c 01                	jl     0x3ca9
    3ca8:	40                   	inc    ax
    3ca9:	50                   	push   ax
    3caa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cad:	26 c4 bd ec 07       	les    di,DWORD PTR es:[di+0x7ec]
    3cb2:	06                   	push   es
    3cb3:	57                   	push   di
    3cb4:	9a a5 13 de 3c       	call   0x3cde:0x13a5
    3cb9:	c7 06 44 01 ff ff    	mov    WORD PTR ds:0x144,0xffff
    3cbf:	c7 06 46 01 ff ff    	mov    WORD PTR ds:0x146,0xffff
    3cc5:	c7 06 48 01 ff ff    	mov    WORD PTR ds:0x148,0xffff
    3ccb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cce:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    3cd3:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3cd6:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3cd9:	06                   	push   es
    3cda:	57                   	push   di
    3cdb:	9a 26 13 12 3d       	call   0x3d12:0x1326
    3ce0:	2d 01 00             	sub    ax,0x1
    3ce3:	71 05                	jno    0x3cea
    3ce5:	9a 3e 04 4a 3d       	call   0x3d4a:0x43e
    3cea:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3ced:	31 c0                	xor    ax,ax
    3cef:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3cf2:	7f 33                	jg     0x3d27
    3cf4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3cf7:	eb 03                	jmp    0x3cfc
    3cf9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3cfc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3cff:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    3d03:	7c 1a                	jl     0x3d1f
    3d05:	6a 00                	push   0x0
    3d07:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3d0a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3d0d:	06                   	push   es
    3d0e:	57                   	push   di
    3d0f:	9a 53 13 1d 3d       	call   0x3d1d:0x1353
    3d14:	89 c7                	mov    di,ax
    3d16:	8e c2                	mov    es,dx
    3d18:	06                   	push   es
    3d19:	57                   	push   di
    3d1a:	9a a5 13 6c 3d       	call   0x3d6c:0x13a5
    3d1f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3d22:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3d25:	75 d2                	jne    0x3cf9
    3d27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d2a:	26 c4 bd 94 07       	les    di,DWORD PTR es:[di+0x794]
    3d2f:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3d32:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3d35:	31 c0                	xor    ax,ax
    3d37:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3d3a:	eb 03                	jmp    0x3d3f
    3d3c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3d3f:	a1 4c 01             	mov    ax,ds:0x14c
    3d42:	2d 01 00             	sub    ax,0x1
    3d45:	71 05                	jno    0x3d4c
    3d47:	9a 3e 04 59 3d       	call   0x3d59:0x43e
    3d4c:	8b d0                	mov    dx,ax
    3d4e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3d51:	05 01 00             	add    ax,0x1
    3d54:	71 05                	jno    0x3d5b
    3d56:	9a 3e 04 b3 3d       	call   0x3db3:0x43e
    3d5b:	3b c2                	cmp    ax,dx
    3d5d:	7e 1a                	jle    0x3d79
    3d5f:	6a 00                	push   0x0
    3d61:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3d64:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3d67:	06                   	push   es
    3d68:	57                   	push   di
    3d69:	9a 53 13 77 3d       	call   0x3d77:0x1353
    3d6e:	89 c7                	mov    di,ax
    3d70:	8e c2                	mov    es,dx
    3d72:	06                   	push   es
    3d73:	57                   	push   di
    3d74:	9a a5 13 1f 41       	call   0x411f:0x13a5
    3d79:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    3d7d:	75 bd                	jne    0x3d3c
    3d7f:	6a 00                	push   0x0
    3d81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d84:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    3d89:	06                   	push   es
    3d8a:	57                   	push   di
    3d8b:	9a d0 1c 9f 3d       	call   0x3d9f:0x1cd0
    3d90:	6a 00                	push   0x0
    3d92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d95:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3d9a:	06                   	push   es
    3d9b:	57                   	push   di
    3d9c:	9a d0 1c 83 40       	call   0x4083:0x1cd0
    3da1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3da4:	06                   	push   es
    3da5:	57                   	push   di
    3da6:	9a 7d 52 d5 3d       	call   0x3dd5:0x527d
    3dab:	2d 01 00             	sub    ax,0x1
    3dae:	71 05                	jno    0x3db5
    3db0:	9a 3e 04 e4 3d       	call   0x3de4:0x43e
    3db5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3db8:	31 c0                	xor    ax,ax
    3dba:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3dbd:	7e 03                	jle    0x3dc2
    3dbf:	e9 a7 00             	jmp    0x3e69
    3dc2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3dc5:	eb 03                	jmp    0x3dca
    3dc7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3dca:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3dcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dd0:	06                   	push   es
    3dd1:	57                   	push   di
    3dd2:	9a 46 52 f5 3d       	call   0x3df5:0x5246
    3dd7:	52                   	push   dx
    3dd8:	50                   	push   ax
    3dd9:	bf 99 03             	mov    di,0x399
    3ddc:	b8 fd 3d             	mov    ax,0x3dfd
    3ddf:	50                   	push   ax
    3de0:	57                   	push   di
    3de1:	9a 55 22 04 3e       	call   0x3e04:0x2255
    3de6:	08 c0                	or     al,al
    3de8:	74 74                	je     0x3e5e
    3dea:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3ded:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3df0:	06                   	push   es
    3df1:	57                   	push   di
    3df2:	9a 46 52 f3 43       	call   0x43f3:0x5246
    3df7:	52                   	push   dx
    3df8:	50                   	push   ax
    3df9:	bf 99 03             	mov    di,0x399
    3dfc:	b8 5c 3e             	mov    ax,0x3e5c
    3dff:	50                   	push   ax
    3e00:	57                   	push   di
    3e01:	9a 73 22 41 3e       	call   0x3e41:0x2273
    3e06:	89 c7                	mov    di,ax
    3e08:	8e c2                	mov    es,dx
    3e0a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3e0d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3e10:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3e15:	74 47                	je     0x3e5e
    3e17:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    3e1b:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    3e1f:	74 3d                	je     0x3e5e
    3e21:	a1 06 1e             	mov    ax,ds:0x1e06
    3e24:	99                   	cwd
    3e25:	8b c8                	mov    cx,ax
    3e27:	8b da                	mov    bx,dx
    3e29:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    3e2d:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    3e31:	09 d2                	or     dx,dx
    3e33:	79 07                	jns    0x3e3c
    3e35:	f7 d2                	not    dx
    3e37:	f7 d8                	neg    ax
    3e39:	83 da ff             	sbb    dx,0xffff
    3e3c:	71 05                	jno    0x3e43
    3e3e:	9a 3e 04 f6 3e       	call   0x3ef6:0x43e
    3e43:	3b d3                	cmp    dx,bx
    3e45:	7c 0a                	jl     0x3e51
    3e47:	7f 04                	jg     0x3e4d
    3e49:	3b c1                	cmp    ax,cx
    3e4b:	76 04                	jbe    0x3e51
    3e4d:	b0 00                	mov    al,0x0
    3e4f:	eb 02                	jmp    0x3e53
    3e51:	b0 01                	mov    al,0x1
    3e53:	50                   	push   ax
    3e54:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3e57:	06                   	push   es
    3e58:	57                   	push   di
    3e59:	9a 77 1c 7d 3e       	call   0x3e7d:0x1c77
    3e5e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3e61:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3e64:	74 03                	je     0x3e69
    3e66:	e9 5e ff             	jmp    0x3dc7
    3e69:	8d be fe fe          	lea    di,[bp-0x102]
    3e6d:	16                   	push   ss
    3e6e:	57                   	push   di
    3e6f:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3e73:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    3e78:	06                   	push   es
    3e79:	57                   	push   di
    3e7a:	9a 53 1d 8c 3e       	call   0x3e8c:0x1d53
    3e7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e82:	26 c4 bd 78 06       	les    di,DWORD PTR es:[di+0x678]
    3e87:	06                   	push   es
    3e88:	57                   	push   di
    3e89:	9a 8c 1d a2 3e       	call   0x3ea2:0x1d8c
    3e8e:	8d be fe fe          	lea    di,[bp-0x102]
    3e92:	16                   	push   ss
    3e93:	57                   	push   di
    3e94:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3e98:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    3e9d:	06                   	push   es
    3e9e:	57                   	push   di
    3e9f:	9a 53 1d b1 3e       	call   0x3eb1:0x1d53
    3ea4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ea7:	26 c4 bd 7c 06       	les    di,DWORD PTR es:[di+0x67c]
    3eac:	06                   	push   es
    3ead:	57                   	push   di
    3eae:	9a 8c 1d c7 3e       	call   0x3ec7:0x1d8c
    3eb3:	8d be fe fe          	lea    di,[bp-0x102]
    3eb7:	16                   	push   ss
    3eb8:	57                   	push   di
    3eb9:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3ebd:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    3ec2:	06                   	push   es
    3ec3:	57                   	push   di
    3ec4:	9a 53 1d d6 3e       	call   0x3ed6:0x1d53
    3ec9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ecc:	26 c4 bd 80 06       	les    di,DWORD PTR es:[di+0x680]
    3ed1:	06                   	push   es
    3ed2:	57                   	push   di
    3ed3:	9a 8c 1d ec 3e       	call   0x3eec:0x1d8c
    3ed8:	8d be fe fe          	lea    di,[bp-0x102]
    3edc:	16                   	push   ss
    3edd:	57                   	push   di
    3ede:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3ee2:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    3ee7:	06                   	push   es
    3ee8:	57                   	push   di
    3ee9:	9a 53 1d 59 3f       	call   0x3f59:0x1d53
    3eee:	bf f3 3b             	mov    di,0x3bf3
    3ef1:	0e                   	push   cs
    3ef2:	57                   	push   di
    3ef3:	9a 4c 18 16 3f       	call   0x3f16:0x184c
    3ef8:	8d be fe fd          	lea    di,[bp-0x202]
    3efc:	16                   	push   ss
    3efd:	57                   	push   di
    3efe:	9a fe 15 11 3f       	call   0x3f11:0x15fe
    3f03:	83 ec 08             	sub    sp,0x8
    3f06:	89 e3                	mov    bx,sp
    3f08:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f0c:	90                   	nop
    3f0d:	9b                   	fwait
    3f0e:	9a bf 1c 2b 3f       	call   0x3f2b:0x1cbf
    3f13:	9a 4c 18 20 3f       	call   0x3f20:0x184c
    3f18:	bf f3 3b             	mov    di,0x3bf3
    3f1b:	0e                   	push   cs
    3f1c:	57                   	push   di
    3f1d:	9a 4c 18 40 3f       	call   0x3f40:0x184c
    3f22:	8d be fe fc          	lea    di,[bp-0x302]
    3f26:	16                   	push   ss
    3f27:	57                   	push   di
    3f28:	9a fe 15 3b 3f       	call   0x3f3b:0x15fe
    3f2d:	83 ec 08             	sub    sp,0x8
    3f30:	89 e3                	mov    bx,sp
    3f32:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f36:	90                   	nop
    3f37:	9b                   	fwait
    3f38:	9a e4 1c 05 44       	call   0x4405:0x1ce4
    3f3d:	9a 4c 18 4a 3f       	call   0x3f4a:0x184c
    3f42:	bf f3 3b             	mov    di,0x3bf3
    3f45:	0e                   	push   cs
    3f46:	57                   	push   di
    3f47:	9a 4c 18 60 40       	call   0x4060:0x184c
    3f4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f4f:	26 c4 bd 84 06       	les    di,DWORD PTR es:[di+0x684]
    3f54:	06                   	push   es
    3f55:	57                   	push   di
    3f56:	9a 8c 1d 08 42       	call   0x4208:0x1d8c
    3f5b:	bf 32 1e             	mov    di,0x1e32
    3f5e:	1e                   	push   ds
    3f5f:	57                   	push   di
    3f60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f63:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    3f68:	06                   	push   es
    3f69:	57                   	push   di
    3f6a:	9a 17 30 81 3f       	call   0x3f81:0x3017
    3f6f:	bf 5c 1e             	mov    di,0x1e5c
    3f72:	1e                   	push   ds
    3f73:	57                   	push   di
    3f74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f77:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    3f7c:	06                   	push   es
    3f7d:	57                   	push   di
    3f7e:	9a 17 30 95 3f       	call   0x3f95:0x3017
    3f83:	bf 5c 1e             	mov    di,0x1e5c
    3f86:	1e                   	push   ds
    3f87:	57                   	push   di
    3f88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f8b:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    3f90:	06                   	push   es
    3f91:	57                   	push   di
    3f92:	9a 17 30 a9 3f       	call   0x3fa9:0x3017
    3f97:	bf 78 1e             	mov    di,0x1e78
    3f9a:	1e                   	push   ds
    3f9b:	57                   	push   di
    3f9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f9f:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    3fa4:	06                   	push   es
    3fa5:	57                   	push   di
    3fa6:	9a 17 30 bd 3f       	call   0x3fbd:0x3017
    3fab:	bf 86 1e             	mov    di,0x1e86
    3fae:	1e                   	push   ds
    3faf:	57                   	push   di
    3fb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fb3:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    3fb8:	06                   	push   es
    3fb9:	57                   	push   di
    3fba:	9a 17 30 d1 3f       	call   0x3fd1:0x3017
    3fbf:	bf 86 1e             	mov    di,0x1e86
    3fc2:	1e                   	push   ds
    3fc3:	57                   	push   di
    3fc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fc7:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    3fcc:	06                   	push   es
    3fcd:	57                   	push   di
    3fce:	9a 17 30 e5 3f       	call   0x3fe5:0x3017
    3fd3:	bf 5c 1e             	mov    di,0x1e5c
    3fd6:	1e                   	push   ds
    3fd7:	57                   	push   di
    3fd8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fdb:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    3fe0:	06                   	push   es
    3fe1:	57                   	push   di
    3fe2:	9a 17 30 f9 3f       	call   0x3ff9:0x3017
    3fe7:	bf 5c 1e             	mov    di,0x1e5c
    3fea:	1e                   	push   ds
    3feb:	57                   	push   di
    3fec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fef:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    3ff4:	06                   	push   es
    3ff5:	57                   	push   di
    3ff6:	9a 17 30 0d 40       	call   0x400d:0x3017
    3ffb:	bf 32 1e             	mov    di,0x1e32
    3ffe:	1e                   	push   ds
    3fff:	57                   	push   di
    4000:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4003:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    4008:	06                   	push   es
    4009:	57                   	push   di
    400a:	9a 17 30 21 40       	call   0x4021:0x3017
    400f:	bf 78 1e             	mov    di,0x1e78
    4012:	1e                   	push   ds
    4013:	57                   	push   di
    4014:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4017:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    401c:	06                   	push   es
    401d:	57                   	push   di
    401e:	9a 17 30 35 40       	call   0x4035:0x3017
    4023:	bf 86 1e             	mov    di,0x1e86
    4026:	1e                   	push   ds
    4027:	57                   	push   di
    4028:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    402b:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    4030:	06                   	push   es
    4031:	57                   	push   di
    4032:	9a 17 30 49 40       	call   0x4049:0x3017
    4037:	bf 86 1e             	mov    di,0x1e86
    403a:	1e                   	push   ds
    403b:	57                   	push   di
    403c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    403f:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    4044:	06                   	push   es
    4045:	57                   	push   di
    4046:	9a 17 30 a9 44       	call   0x44a9:0x3017
    404b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    404e:	26 c7 85 f4 07 01 00 	mov    WORD PTR es:[di+0x7f4],0x1
    4055:	a1 4c 01             	mov    ax,ds:0x14c
    4058:	2d 01 00             	sub    ax,0x1
    405b:	71 05                	jno    0x4062
    405d:	9a 3e 04 76 40       	call   0x4076:0x43e
    4062:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4065:	26 89 85 f2 07       	mov    WORD PTR es:[di+0x7f2],ax
    406a:	c9                   	leave
    406b:	ca 08 00             	retf   0x8
    406e:	55                   	push   bp
    406f:	89 e5                	mov    bp,sp
    4071:	31 c0                	xor    ax,ax
    4073:	9a 44 04 91 40       	call   0x4091:0x444
    4078:	6a fe                	push   0xfffe
    407a:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    407e:	06                   	push   es
    407f:	57                   	push   di
    4080:	9a a9 63 ba 40       	call   0x40ba:0x63a9
    4085:	c9                   	leave
    4086:	ca 08 00             	retf   0x8
    4089:	55                   	push   bp
    408a:	89 e5                	mov    bp,sp
    408c:	31 c0                	xor    ax,ax
    408e:	9a 44 04 b0 40       	call   0x40b0:0x444
    4093:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4096:	06                   	push   es
    4097:	57                   	push   di
    4098:	9a f1 39 98 42       	call   0x4298:0x39f1
    409d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    40a0:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    40a4:	c9                   	leave
    40a5:	ca 0c 00             	retf   0xc
    40a8:	55                   	push   bp
    40a9:	89 e5                	mov    bp,sp
    40ab:	31 c0                	xor    ax,ax
    40ad:	9a 44 04 c8 40       	call   0x40c8:0x444
    40b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40b5:	06                   	push   es
    40b6:	57                   	push   di
    40b7:	9a 56 55 dc 40       	call   0x40dc:0x5556
    40bc:	c9                   	leave
    40bd:	ca 08 00             	retf   0x8
    40c0:	55                   	push   bp
    40c1:	89 e5                	mov    bp,sp
    40c3:	31 c0                	xor    ax,ax
    40c5:	9a 44 04 05 41       	call   0x4105:0x444
    40ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40cd:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    40d3:	75 0b                	jne    0x40e0
    40d5:	6a 00                	push   0x0
    40d7:	06                   	push   es
    40d8:	57                   	push   di
    40d9:	9a 14 3a ea 40       	call   0x40ea:0x3a14
    40de:	eb 0c                	jmp    0x40ec
    40e0:	6a 02                	push   0x2
    40e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40e5:	06                   	push   es
    40e6:	57                   	push   di
    40e7:	9a 14 3a 9d 52       	call   0x529d:0x3a14
    40ec:	c9                   	leave
    40ed:	ca 08 00             	retf   0x8
    40f0:	67 41                	addr32 inc cx
    40f2:	6e                   	outs   dx,BYTE PTR ds:[si]
    40f3:	41                   	inc    cx
    40f4:	75 41                	jne    0x4137
    40f6:	7c 41                	jl     0x4139
    40f8:	83 41 8a 41          	add    WORD PTR [bx+di-0x76],0x41
    40fc:	55                   	push   bp
    40fd:	89 e5                	mov    bp,sp
    40ff:	b8 0e 00             	mov    ax,0xe
    4102:	9a 44 04 26 41       	call   0x4126:0x444
    4107:	83 ec 0e             	sub    sp,0xe
    410a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    410d:	26 8b 85 f0 07       	mov    ax,WORD PTR es:[di+0x7f0]
    4112:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4115:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4118:	ff 76 0a             	push   WORD PTR [bp+0xa]
    411b:	bf 94 00             	mov    di,0x94
    411e:	b8 39 41             	mov    ax,0x4139
    4121:	50                   	push   ax
    4122:	57                   	push   di
    4123:	9a 55 22 40 41       	call   0x4140:0x2255
    4128:	08 c0                	or     al,al
    412a:	75 03                	jne    0x412f
    412c:	e9 bf 00             	jmp    0x41ee
    412f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4132:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4135:	bf 94 00             	mov    di,0x94
    4138:	b8 51 41             	mov    ax,0x4151
    413b:	50                   	push   ax
    413c:	57                   	push   di
    413d:	9a 73 22 ae 41       	call   0x41ae:0x2273
    4142:	52                   	push   dx
    4143:	50                   	push   ax
    4144:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4147:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    414c:	06                   	push   es
    414d:	57                   	push   di
    414e:	9a 2b 16 a4 41       	call   0x41a4:0x162b
    4153:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4156:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4159:	3d 05 00             	cmp    ax,0x5
    415c:	77 33                	ja     0x4191
    415e:	89 c3                	mov    bx,ax
    4160:	d1 e3                	shl    bx,1
    4162:	2e ff a7 f0 40       	jmp    WORD PTR cs:[bx+0x40f0]
    4167:	c7 46 fe 64 00       	mov    WORD PTR [bp-0x2],0x64
    416c:	eb 23                	jmp    0x4191
    416e:	c7 46 fe 7d 00       	mov    WORD PTR [bp-0x2],0x7d
    4173:	eb 1c                	jmp    0x4191
    4175:	c7 46 fe 96 00       	mov    WORD PTR [bp-0x2],0x96
    417a:	eb 15                	jmp    0x4191
    417c:	c7 46 fe c8 00       	mov    WORD PTR [bp-0x2],0xc8
    4181:	eb 0e                	jmp    0x4191
    4183:	c7 46 fe 4b 00       	mov    WORD PTR [bp-0x2],0x4b
    4188:	eb 07                	jmp    0x4191
    418a:	c7 46 fe 32 00       	mov    WORD PTR [bp-0x2],0x32
    418f:	eb 00                	jmp    0x4191
    4191:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4194:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    4199:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    419c:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    419f:	06                   	push   es
    41a0:	57                   	push   di
    41a1:	9a 26 13 d9 41       	call   0x41d9:0x1326
    41a6:	2d 01 00             	sub    ax,0x1
    41a9:	71 05                	jno    0x41b0
    41ab:	9a 3e 04 21 42       	call   0x4221:0x43e
    41b0:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    41b3:	31 c0                	xor    ax,ax
    41b5:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    41b8:	7f 34                	jg     0x41ee
    41ba:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    41bd:	eb 03                	jmp    0x41c2
    41bf:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    41c2:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    41c5:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    41c8:	b0 00                	mov    al,0x0
    41ca:	75 01                	jne    0x41cd
    41cc:	40                   	inc    ax
    41cd:	50                   	push   ax
    41ce:	ff 76 f8             	push   WORD PTR [bp-0x8]
    41d1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    41d4:	06                   	push   es
    41d5:	57                   	push   di
    41d6:	9a 53 13 e4 41       	call   0x41e4:0x1353
    41db:	89 c7                	mov    di,ax
    41dd:	8e c2                	mov    es,dx
    41df:	06                   	push   es
    41e0:	57                   	push   di
    41e1:	9a 75 12 3c 42       	call   0x423c:0x1275
    41e6:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    41e9:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    41ec:	75 d1                	jne    0x41bf
    41ee:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    41f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41f4:	26 3b 85 f0 07       	cmp    ax,WORD PTR es:[di+0x7f0]
    41f9:	74 1a                	je     0x4215
    41fb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    41fe:	26 ff b5 f0 07       	push   WORD PTR es:[di+0x7f0]
    4203:	06                   	push   es
    4204:	57                   	push   di
    4205:	9a f4 5d f9 52       	call   0x52f9:0x5df4
    420a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    420d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4210:	26 89 85 f0 07       	mov    WORD PTR es:[di+0x7f0],ax
    4215:	c9                   	leave
    4216:	ca 08 00             	retf   0x8
    4219:	55                   	push   bp
    421a:	89 e5                	mov    bp,sp
    421c:	31 c0                	xor    ax,ax
    421e:	9a 44 04 4a 42       	call   0x424a:0x444
    4223:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4226:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    422c:	b0 00                	mov    al,0x0
    422e:	75 01                	jne    0x4231
    4230:	40                   	inc    ax
    4231:	50                   	push   ax
    4232:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    4237:	06                   	push   es
    4238:	57                   	push   di
    4239:	9a 75 12 b6 42       	call   0x42b6:0x1275
    423e:	c9                   	leave
    423f:	ca 08 00             	retf   0x8
    4242:	55                   	push   bp
    4243:	89 e5                	mov    bp,sp
    4245:	31 c0                	xor    ax,ax
    4247:	9a 44 04 60 42       	call   0x4260:0x444
    424c:	6a 00                	push   0x0
    424e:	9a ff ff 00 00       	call   0x0:0xffff
    4253:	c9                   	leave
    4254:	ca 08 00             	retf   0x8
    4257:	55                   	push   bp
    4258:	89 e5                	mov    bp,sp
    425a:	b8 02 00             	mov    ax,0x2
    425d:	9a 44 04 70 42       	call   0x4270:0x444
    4262:	83 ec 02             	sub    sp,0x2
    4265:	a1 4c 01             	mov    ax,ds:0x14c
    4268:	2d 01 00             	sub    ax,0x1
    426b:	71 05                	jno    0x4272
    426d:	9a 3e 04 a7 42       	call   0x42a7:0x43e
    4272:	50                   	push   ax
    4273:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4276:	26 ff b5 f2 07       	push   WORD PTR es:[di+0x7f2]
    427b:	9a 32 3e 74 43       	call   0x4374:0x3e32
    4280:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4283:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4286:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4289:	26 3b 85 f2 07       	cmp    ax,WORD PTR es:[di+0x7f2]
    428e:	74 0a                	je     0x429a
    4290:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4293:	06                   	push   es
    4294:	57                   	push   di
    4295:	9a a7 3b 8e 43       	call   0x438e:0x3ba7
    429a:	c9                   	leave
    429b:	ca 08 00             	retf   0x8
    429e:	55                   	push   bp
    429f:	89 e5                	mov    bp,sp
    42a1:	b8 08 00             	mov    ax,0x8
    42a4:	9a 44 04 bd 42       	call   0x42bd:0x444
    42a9:	83 ec 08             	sub    sp,0x8
    42ac:	ff 76 0c             	push   WORD PTR [bp+0xc]
    42af:	ff 76 0a             	push   WORD PTR [bp+0xa]
    42b2:	bf 94 00             	mov    di,0x94
    42b5:	b8 d0 42             	mov    ax,0x42d0
    42b8:	50                   	push   ax
    42b9:	57                   	push   di
    42ba:	9a 55 22 d7 42       	call   0x42d7:0x2255
    42bf:	08 c0                	or     al,al
    42c1:	75 03                	jne    0x42c6
    42c3:	e9 ca 00             	jmp    0x4390
    42c6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    42c9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    42cc:	bf 94 00             	mov    di,0x94
    42cf:	b8 f2 42             	mov    ax,0x42f2
    42d2:	50                   	push   ax
    42d3:	57                   	push   di
    42d4:	9a 73 22 f9 42       	call   0x42f9:0x2273
    42d9:	89 c7                	mov    di,ax
    42db:	8e c2                	mov    es,dx
    42dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42e0:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    42e5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    42e8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    42eb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    42ee:	bf 94 00             	mov    di,0x94
    42f1:	b8 0a 43             	mov    ax,0x430a
    42f4:	50                   	push   ax
    42f5:	57                   	push   di
    42f6:	9a 73 22 1a 43       	call   0x431a:0x2273
    42fb:	52                   	push   dx
    42fc:	50                   	push   ax
    42fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4300:	26 c4 bd 94 07       	les    di,DWORD PTR es:[di+0x794]
    4305:	06                   	push   es
    4306:	57                   	push   di
    4307:	9a 2b 16 b5 43       	call   0x43b5:0x162b
    430c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    430f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4312:	05 01 00             	add    ax,0x1
    4315:	71 05                	jno    0x431c
    4317:	9a 3e 04 4e 43       	call   0x434e:0x43e
    431c:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    4320:	b0 00                	mov    al,0x0
    4322:	7d 01                	jge    0x4325
    4324:	40                   	inc    ax
    4325:	8a c8                	mov    cl,al
    4327:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    432b:	b0 00                	mov    al,0x0
    432d:	7d 01                	jge    0x4330
    432f:	40                   	inc    ax
    4330:	8a d0                	mov    dl,al
    4332:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    4336:	b0 00                	mov    al,0x0
    4338:	7c 01                	jl     0x433b
    433a:	40                   	inc    ax
    433b:	22 c2                	and    al,dl
    433d:	22 c1                	and    al,cl
    433f:	08 c0                	or     al,al
    4341:	74 12                	je     0x4355
    4343:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4346:	05 01 00             	add    ax,0x1
    4349:	71 05                	jno    0x4350
    434b:	9a 3e 04 66 43       	call   0x4366:0x43e
    4350:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4353:	eb 24                	jmp    0x4379
    4355:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    4359:	75 1e                	jne    0x4379
    435b:	a1 4c 01             	mov    ax,ds:0x14c
    435e:	2d 01 00             	sub    ax,0x1
    4361:	71 05                	jno    0x4368
    4363:	9a 3e 04 a5 43       	call   0x43a5:0x43e
    4368:	50                   	push   ax
    4369:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    436c:	26 ff b5 f2 07       	push   WORD PTR es:[di+0x7f2]
    4371:	9a 32 3e ff ff       	call   0xffff:0x3e32
    4376:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4379:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    437c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    437f:	26 3b 85 f2 07       	cmp    ax,WORD PTR es:[di+0x7f2]
    4384:	74 0a                	je     0x4390
    4386:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4389:	06                   	push   es
    438a:	57                   	push   di
    438b:	9a a7 3b 3a 44       	call   0x443a:0x3ba7
    4390:	c9                   	leave
    4391:	ca 08 00             	retf   0x8
    4394:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    4398:	ff                   	(bad)
    4399:	7f 00                	jg     0x439b
    439b:	00 55 89             	add    BYTE PTR [di-0x77],dl
    439e:	e5 b8                	in     ax,0xb8
    43a0:	06                   	push   es
    43a1:	02 9a 44 04          	add    bl,BYTE PTR [bp+si+0x444]
    43a5:	bc 43 81             	mov    sp,0x8143
    43a8:	ec                   	in     al,dx
    43a9:	06                   	push   es
    43aa:	02 ff                	add    bh,bh
    43ac:	76 0c                	jbe    0x43ba
    43ae:	ff 76 0a             	push   WORD PTR [bp+0xa]
    43b1:	bf 94 00             	mov    di,0x94
    43b4:	b8 cc 43             	mov    ax,0x43cc
    43b7:	50                   	push   ax
    43b8:	57                   	push   di
    43b9:	9a 55 22 d3 43       	call   0x43d3:0x2255
    43be:	08 c0                	or     al,al
    43c0:	74 7a                	je     0x443c
    43c2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    43c5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    43c8:	bf 94 00             	mov    di,0x94
    43cb:	b8 ff ff             	mov    ax,0xffff
    43ce:	50                   	push   ax
    43cf:	57                   	push   di
    43d0:	9a 73 22 00 44       	call   0x4400:0x2273
    43d5:	89 c7                	mov    di,ax
    43d7:	8e c2                	mov    es,dx
    43d9:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    43dc:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    43df:	8d be fa fd          	lea    di,[bp-0x206]
    43e3:	16                   	push   ss
    43e4:	57                   	push   di
    43e5:	8d be fa fe          	lea    di,[bp-0x106]
    43e9:	16                   	push   ss
    43ea:	57                   	push   di
    43eb:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    43ee:	06                   	push   es
    43ef:	57                   	push   di
    43f0:	9a 2a 51 ff ff       	call   0xffff:0x512a
    43f5:	83 c4 04             	add    sp,0x4
    43f8:	8a 86 fc fe          	mov    al,BYTE PTR [bp-0x104]
    43fc:	50                   	push   ax
    43fd:	9a e9 18 0d 44       	call   0x440d:0x18e9
    4402:	9a da 08 ff ff       	call   0xffff:0x8da
    4407:	bf 94 43             	mov    di,0x4394
    440a:	9a 16 04 9a 44       	call   0x449a:0x416
    440f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4412:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4415:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    4419:	b0 00                	mov    al,0x0
    441b:	7f 01                	jg     0x441e
    441d:	40                   	inc    ax
    441e:	8a d0                	mov    dl,al
    4420:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    4424:	b0 00                	mov    al,0x0
    4426:	7e 01                	jle    0x4429
    4428:	40                   	inc    ax
    4429:	22 c2                	and    al,dl
    442b:	08 c0                	or     al,al
    442d:	74 0d                	je     0x443c
    442f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4432:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4435:	06                   	push   es
    4436:	57                   	push   di
    4437:	9a c7 3b d5 55       	call   0x55d5:0x3bc7
    443c:	c9                   	leave
    443d:	ca 08 00             	retf   0x8
    4440:	12 43 61             	adc    al,BYTE PTR [bp+di+0x61]
    4443:	70 61                	jo     0x44a6
    4445:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    4448:	65 50                	gs push ax
    444a:	72 6f                	jb     0x44bb
    444c:	64 75 63             	fs jne 0x44b2
    444f:	74 69                	je     0x44ba
    4451:	76 65                	jbe    0x44b8
    4453:	08 4d 61             	or     BYTE PTR [di+0x61],cl
    4456:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4459:	6e                   	outs   dx,BYTE PTR ds:[si]
    445a:	65 73 10             	gs jae 0x446d
    445d:	48                   	dec    ax
    445e:	65 75 72             	gs jne 0x44d3
    4461:	65 73 50             	gs jae 0x44b4
    4464:	61                   	popa
    4465:	72 4d                	jb     0x44b4
    4467:	61                   	popa
    4468:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    446b:	6e                   	outs   dx,BYTE PTR ds:[si]
    446c:	65 04 50             	gs add al,0x50
    446f:	72 69                	jb     0x44da
    4471:	78 00                	js     0x4473
    4473:	00 00                	add    BYTE PTR [bx+si],al
    4475:	00 0e 4e 6f          	add    BYTE PTR ds:0x6f4e,cl
    4479:	6d                   	ins    WORD PTR es:[di],dx
    447a:	62 72 65             	bound  si,DWORD PTR [bp+si+0x65]
    447d:	50                   	push   ax
    447e:	72 6f                	jb     0x44ef
    4480:	64 75 69             	fs jne 0x44ec
    4483:	74 73                	je     0x44f8
    4485:	0b 56 61             	or     dx,WORD PTR [bp+0x61]
    4488:	6c                   	ins    BYTE PTR es:[di],dx
    4489:	65 75 72             	gs jne 0x44fe
    448c:	53                   	push   bx
    448d:	74 6f                	je     0x44fe
    448f:	63 6b 55             	arpl   WORD PTR [bp+di+0x55],bp
    4492:	89 e5                	mov    bp,sp
    4494:	b8 14 00             	mov    ax,0x14
    4497:	9a 44 04 b0 44       	call   0x44b0:0x444
    449c:	83 ec 14             	sub    sp,0x14
    449f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    44a2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    44a5:	bf 38 01             	mov    di,0x138
    44a8:	b8 fb 46             	mov    ax,0x46fb
    44ab:	50                   	push   ax
    44ac:	57                   	push   di
    44ad:	9a 73 22 ec 46       	call   0x46ec:0x2273
    44b2:	89 c7                	mov    di,ax
    44b4:	8e c2                	mov    es,dx
    44b6:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    44b9:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    44bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44bf:	26 83 bd f2 07 01    	cmp    WORD PTR es:[di+0x7f2],0x1
    44c5:	75 27                	jne    0x44ee
    44c7:	6a 00                	push   0x0
    44c9:	6a 00                	push   0x0
    44cb:	6a 00                	push   0x0
    44cd:	6a 00                	push   0x0
    44cf:	bf 40 44             	mov    di,0x4440
    44d2:	0e                   	push   cs
    44d3:	57                   	push   di
    44d4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    44d7:	06                   	push   es
    44d8:	57                   	push   di
    44d9:	9a 9b 3b fb 44       	call   0x44fb:0x3b9b
    44de:	89 c7                	mov    di,ax
    44e0:	8e c2                	mov    es,dx
    44e2:	06                   	push   es
    44e3:	57                   	push   di
    44e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44e7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    44eb:	e9 89 00             	jmp    0x4577
    44ee:	bf 53 44             	mov    di,0x4453
    44f1:	0e                   	push   cs
    44f2:	57                   	push   di
    44f3:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    44f6:	06                   	push   es
    44f7:	57                   	push   di
    44f8:	9a 9b 3b 2a 45       	call   0x452a:0x3b9b
    44fd:	89 c7                	mov    di,ax
    44ff:	8e c2                	mov    es,dx
    4501:	06                   	push   es
    4502:	57                   	push   di
    4503:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4506:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    450a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    450d:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    4510:	9b db 46 f6          	fild   DWORD PTR [bp-0xa]
    4514:	9b db 7e ec          	fstp   TBYTE PTR [bp-0x14]
    4518:	bf 5c 44             	mov    di,0x445c
    451b:	0e                   	push   cs
    451c:	57                   	push   di
    451d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4520:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
    4525:	06                   	push   es
    4526:	57                   	push   di
    4527:	9a 9b 3b 68 45       	call   0x4568:0x3b9b
    452c:	89 c7                	mov    di,ax
    452e:	8e c2                	mov    es,dx
    4530:	06                   	push   es
    4531:	57                   	push   di
    4532:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4535:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4539:	9b db 6e ec          	fld    TBYTE PTR [bp-0x14]
    453d:	9b de c9             	fmulp  st(1),st
    4540:	83 ec 08             	sub    sp,0x8
    4543:	89 e3                	mov    bx,sp
    4545:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4549:	90                   	nop
    454a:	9b                   	fwait
    454b:	9a a6 2f 65 46       	call   0x4665:0x2fa6
    4550:	83 ec 08             	sub    sp,0x8
    4553:	89 e3                	mov    bx,sp
    4555:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4559:	90                   	nop
    455a:	9b                   	fwait
    455b:	bf 40 44             	mov    di,0x4440
    455e:	0e                   	push   cs
    455f:	57                   	push   di
    4560:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4563:	06                   	push   es
    4564:	57                   	push   di
    4565:	9a 9b 3b 8e 45       	call   0x458e:0x3b9b
    456a:	89 c7                	mov    di,ax
    456c:	8e c2                	mov    es,dx
    456e:	06                   	push   es
    456f:	57                   	push   di
    4570:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4573:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4577:	31 c0                	xor    ax,ax
    4579:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    457c:	bf 6d 44             	mov    di,0x446d
    457f:	0e                   	push   cs
    4580:	57                   	push   di
    4581:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4584:	26 c4 bd e4 01       	les    di,DWORD PTR es:[di+0x1e4]
    4589:	06                   	push   es
    458a:	57                   	push   di
    458b:	9a 9b 3b c4 45       	call   0x45c4:0x3b9b
    4590:	89 c7                	mov    di,ax
    4592:	8e c2                	mov    es,dx
    4594:	06                   	push   es
    4595:	57                   	push   di
    4596:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4599:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    459d:	9b 2e d8 1e 72 44    	fcomp  DWORD PTR cs:0x4472
    45a3:	9b dd 7e f8          	fstsw  WORD PTR [bp-0x8]
    45a7:	90                   	nop
    45a8:	9b                   	fwait
    45a9:	8a 66 f9             	mov    ah,BYTE PTR [bp-0x7]
    45ac:	9e                   	sahf
    45ad:	74 03                	je     0x45b2
    45af:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    45b2:	bf 6d 44             	mov    di,0x446d
    45b5:	0e                   	push   cs
    45b6:	57                   	push   di
    45b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45ba:	26 c4 bd e8 01       	les    di,DWORD PTR es:[di+0x1e8]
    45bf:	06                   	push   es
    45c0:	57                   	push   di
    45c1:	9a 9b 3b fb 45       	call   0x45fb:0x3b9b
    45c6:	89 c7                	mov    di,ax
    45c8:	8e c2                	mov    es,dx
    45ca:	06                   	push   es
    45cb:	57                   	push   di
    45cc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45cf:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    45d3:	9b 2e d8 1e 72 44    	fcomp  DWORD PTR cs:0x4472
    45d9:	9b dd 7e f8          	fstsw  WORD PTR [bp-0x8]
    45dd:	90                   	nop
    45de:	9b                   	fwait
    45df:	8a 66 f9             	mov    ah,BYTE PTR [bp-0x7]
    45e2:	9e                   	sahf
    45e3:	74 03                	je     0x45e8
    45e5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    45e8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    45eb:	99                   	cwd
    45ec:	52                   	push   dx
    45ed:	50                   	push   ax
    45ee:	bf 76 44             	mov    di,0x4476
    45f1:	0e                   	push   cs
    45f2:	57                   	push   di
    45f3:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    45f6:	06                   	push   es
    45f7:	57                   	push   di
    45f8:	9a 9b 3b 1c 46       	call   0x461c:0x3b9b
    45fd:	89 c7                	mov    di,ax
    45ff:	8e c2                	mov    es,dx
    4601:	06                   	push   es
    4602:	57                   	push   di
    4603:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4606:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    460a:	bf 85 44             	mov    di,0x4485
    460d:	0e                   	push   cs
    460e:	57                   	push   di
    460f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4612:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    4617:	06                   	push   es
    4618:	57                   	push   di
    4619:	9a 9b 3b 41 46       	call   0x4641:0x3b9b
    461e:	89 c7                	mov    di,ax
    4620:	8e c2                	mov    es,dx
    4622:	06                   	push   es
    4623:	57                   	push   di
    4624:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4627:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    462b:	9b db 7e f0          	fstp   TBYTE PTR [bp-0x10]
    462f:	bf 85 44             	mov    di,0x4485
    4632:	0e                   	push   cs
    4633:	57                   	push   di
    4634:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4637:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    463c:	06                   	push   es
    463d:	57                   	push   di
    463e:	9a 9b 3b 7f 46       	call   0x467f:0x3b9b
    4643:	89 c7                	mov    di,ax
    4645:	8e c2                	mov    es,dx
    4647:	06                   	push   es
    4648:	57                   	push   di
    4649:	26 c4 3d             	les    di,DWORD PTR es:[di]
    464c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4650:	9b db 6e f0          	fld    TBYTE PTR [bp-0x10]
    4654:	9b de c1             	faddp  st(1),st
    4657:	83 ec 08             	sub    sp,0x8
    465a:	89 e3                	mov    bx,sp
    465c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4660:	90                   	nop
    4661:	9b                   	fwait
    4662:	9a a6 2f 6e 47       	call   0x476e:0x2fa6
    4667:	83 ec 08             	sub    sp,0x8
    466a:	89 e3                	mov    bx,sp
    466c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4670:	90                   	nop
    4671:	9b                   	fwait
    4672:	bf 85 44             	mov    di,0x4485
    4675:	0e                   	push   cs
    4676:	57                   	push   di
    4677:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    467a:	06                   	push   es
    467b:	57                   	push   di
    467c:	9a 9b 3b 1b 47       	call   0x471b:0x3b9b
    4681:	89 c7                	mov    di,ax
    4683:	8e c2                	mov    es,dx
    4685:	06                   	push   es
    4686:	57                   	push   di
    4687:	26 c4 3d             	les    di,DWORD PTR es:[di]
    468a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    468e:	c9                   	leave
    468f:	ca 08 00             	retf   0x8
    4692:	12 43 61             	adc    al,BYTE PTR [bp+di+0x61]
    4695:	70 61                	jo     0x46f8
    4697:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    469a:	65 50                	gs push ax
    469c:	72 6f                	jb     0x470d
    469e:	64 75 63             	fs jne 0x4704
    46a1:	74 69                	je     0x470c
    46a3:	76 65                	jbe    0x470a
    46a5:	08 4d 61             	or     BYTE PTR [di+0x61],cl
    46a8:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    46ab:	6e                   	outs   dx,BYTE PTR ds:[si]
    46ac:	65 73 10             	gs jae 0x46bf
    46af:	48                   	dec    ax
    46b0:	65 75 72             	gs jne 0x4725
    46b3:	65 73 50             	gs jae 0x4706
    46b6:	61                   	popa
    46b7:	72 4d                	jb     0x4706
    46b9:	61                   	popa
    46ba:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    46bd:	6e                   	outs   dx,BYTE PTR ds:[si]
    46be:	65 04 50             	gs add al,0x50
    46c1:	72 69                	jb     0x472c
    46c3:	78 00                	js     0x46c5
    46c5:	00 00                	add    BYTE PTR [bx+si],al
    46c7:	00 0e 4e 6f          	add    BYTE PTR ds:0x6f4e,cl
    46cb:	6d                   	ins    WORD PTR es:[di],dx
    46cc:	62 72 65             	bound  si,DWORD PTR [bp+si+0x65]
    46cf:	50                   	push   ax
    46d0:	72 6f                	jb     0x4741
    46d2:	64 75 69             	fs jne 0x473e
    46d5:	74 73                	je     0x474a
    46d7:	0b 56 61             	or     dx,WORD PTR [bp+0x61]
    46da:	6c                   	ins    BYTE PTR es:[di],dx
    46db:	65 75 72             	gs jne 0x4750
    46de:	53                   	push   bx
    46df:	74 6f                	je     0x4750
    46e1:	63 6b 55             	arpl   WORD PTR [bp+di+0x55],bp
    46e4:	89 e5                	mov    bp,sp
    46e6:	b8 14 00             	mov    ax,0x14
    46e9:	9a 44 04 02 47       	call   0x4702:0x444
    46ee:	83 ec 14             	sub    sp,0x14
    46f1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    46f4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    46f7:	bf 38 01             	mov    di,0x138
    46fa:	b8 48 49             	mov    ax,0x4948
    46fd:	50                   	push   ax
    46fe:	57                   	push   di
    46ff:	9a 73 22 39 49       	call   0x4939:0x2273
    4704:	89 c7                	mov    di,ax
    4706:	8e c2                	mov    es,dx
    4708:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    470b:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    470e:	bf a5 46             	mov    di,0x46a5
    4711:	0e                   	push   cs
    4712:	57                   	push   di
    4713:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4716:	06                   	push   es
    4717:	57                   	push   di
    4718:	9a 9b 3b 4a 47       	call   0x474a:0x3b9b
    471d:	89 c7                	mov    di,ax
    471f:	8e c2                	mov    es,dx
    4721:	06                   	push   es
    4722:	57                   	push   di
    4723:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4726:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    472a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    472d:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    4730:	9b db 46 f6          	fild   DWORD PTR [bp-0xa]
    4734:	9b db 7e ec          	fstp   TBYTE PTR [bp-0x14]
    4738:	bf ae 46             	mov    di,0x46ae
    473b:	0e                   	push   cs
    473c:	57                   	push   di
    473d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4740:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    4745:	06                   	push   es
    4746:	57                   	push   di
    4747:	9a 9b 3b 88 47       	call   0x4788:0x3b9b
    474c:	89 c7                	mov    di,ax
    474e:	8e c2                	mov    es,dx
    4750:	06                   	push   es
    4751:	57                   	push   di
    4752:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4755:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4759:	9b db 6e ec          	fld    TBYTE PTR [bp-0x14]
    475d:	9b de c9             	fmulp  st(1),st
    4760:	83 ec 08             	sub    sp,0x8
    4763:	89 e3                	mov    bx,sp
    4765:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4769:	90                   	nop
    476a:	9b                   	fwait
    476b:	9a a6 2f 85 48       	call   0x4885:0x2fa6
    4770:	83 ec 08             	sub    sp,0x8
    4773:	89 e3                	mov    bx,sp
    4775:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4779:	90                   	nop
    477a:	9b                   	fwait
    477b:	bf 92 46             	mov    di,0x4692
    477e:	0e                   	push   cs
    477f:	57                   	push   di
    4780:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4783:	06                   	push   es
    4784:	57                   	push   di
    4785:	9a 9b 3b ae 47       	call   0x47ae:0x3b9b
    478a:	89 c7                	mov    di,ax
    478c:	8e c2                	mov    es,dx
    478e:	06                   	push   es
    478f:	57                   	push   di
    4790:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4793:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4797:	31 c0                	xor    ax,ax
    4799:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    479c:	bf bf 46             	mov    di,0x46bf
    479f:	0e                   	push   cs
    47a0:	57                   	push   di
    47a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47a4:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    47a9:	06                   	push   es
    47aa:	57                   	push   di
    47ab:	9a 9b 3b e4 47       	call   0x47e4:0x3b9b
    47b0:	89 c7                	mov    di,ax
    47b2:	8e c2                	mov    es,dx
    47b4:	06                   	push   es
    47b5:	57                   	push   di
    47b6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47b9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    47bd:	9b 2e d8 1e c4 46    	fcomp  DWORD PTR cs:0x46c4
    47c3:	9b dd 7e f8          	fstsw  WORD PTR [bp-0x8]
    47c7:	90                   	nop
    47c8:	9b                   	fwait
    47c9:	8a 66 f9             	mov    ah,BYTE PTR [bp-0x7]
    47cc:	9e                   	sahf
    47cd:	74 03                	je     0x47d2
    47cf:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    47d2:	bf bf 46             	mov    di,0x46bf
    47d5:	0e                   	push   cs
    47d6:	57                   	push   di
    47d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47da:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    47df:	06                   	push   es
    47e0:	57                   	push   di
    47e1:	9a 9b 3b 1b 48       	call   0x481b:0x3b9b
    47e6:	89 c7                	mov    di,ax
    47e8:	8e c2                	mov    es,dx
    47ea:	06                   	push   es
    47eb:	57                   	push   di
    47ec:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47ef:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    47f3:	9b 2e d8 1e c4 46    	fcomp  DWORD PTR cs:0x46c4
    47f9:	9b dd 7e f8          	fstsw  WORD PTR [bp-0x8]
    47fd:	90                   	nop
    47fe:	9b                   	fwait
    47ff:	8a 66 f9             	mov    ah,BYTE PTR [bp-0x7]
    4802:	9e                   	sahf
    4803:	74 03                	je     0x4808
    4805:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4808:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    480b:	99                   	cwd
    480c:	52                   	push   dx
    480d:	50                   	push   ax
    480e:	bf c8 46             	mov    di,0x46c8
    4811:	0e                   	push   cs
    4812:	57                   	push   di
    4813:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4816:	06                   	push   es
    4817:	57                   	push   di
    4818:	9a 9b 3b 3c 48       	call   0x483c:0x3b9b
    481d:	89 c7                	mov    di,ax
    481f:	8e c2                	mov    es,dx
    4821:	06                   	push   es
    4822:	57                   	push   di
    4823:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4826:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    482a:	bf d7 46             	mov    di,0x46d7
    482d:	0e                   	push   cs
    482e:	57                   	push   di
    482f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4832:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
    4837:	06                   	push   es
    4838:	57                   	push   di
    4839:	9a 9b 3b 61 48       	call   0x4861:0x3b9b
    483e:	89 c7                	mov    di,ax
    4840:	8e c2                	mov    es,dx
    4842:	06                   	push   es
    4843:	57                   	push   di
    4844:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4847:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    484b:	9b db 7e f0          	fstp   TBYTE PTR [bp-0x10]
    484f:	bf d7 46             	mov    di,0x46d7
    4852:	0e                   	push   cs
    4853:	57                   	push   di
    4854:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4857:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    485c:	06                   	push   es
    485d:	57                   	push   di
    485e:	9a 9b 3b 9f 48       	call   0x489f:0x3b9b
    4863:	89 c7                	mov    di,ax
    4865:	8e c2                	mov    es,dx
    4867:	06                   	push   es
    4868:	57                   	push   di
    4869:	26 c4 3d             	les    di,DWORD PTR es:[di]
    486c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4870:	9b db 6e f0          	fld    TBYTE PTR [bp-0x10]
    4874:	9b de c1             	faddp  st(1),st
    4877:	83 ec 08             	sub    sp,0x8
    487a:	89 e3                	mov    bx,sp
    487c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4880:	90                   	nop
    4881:	9b                   	fwait
    4882:	9a a6 2f 43 4a       	call   0x4a43:0x2fa6
    4887:	83 ec 08             	sub    sp,0x8
    488a:	89 e3                	mov    bx,sp
    488c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4890:	90                   	nop
    4891:	9b                   	fwait
    4892:	bf d7 46             	mov    di,0x46d7
    4895:	0e                   	push   cs
    4896:	57                   	push   di
    4897:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    489a:	06                   	push   es
    489b:	57                   	push   di
    489c:	9a 9b 3b 6d 49       	call   0x496d:0x3b9b
    48a1:	89 c7                	mov    di,ax
    48a3:	8e c2                	mov    es,dx
    48a5:	06                   	push   es
    48a6:	57                   	push   di
    48a7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48aa:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    48ae:	c9                   	leave
    48af:	ca 08 00             	retf   0x8
    48b2:	10 48 65             	adc    BYTE PTR [bx+si+0x65],cl
    48b5:	75 72                	jne    0x4929
    48b7:	65 73 50             	gs jae 0x490a
    48ba:	61                   	popa
    48bb:	72 4d                	jb     0x490a
    48bd:	61                   	popa
    48be:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    48c1:	6e                   	outs   dx,BYTE PTR ds:[si]
    48c2:	65 09 50 72          	or     WORD PTR gs:[bx+si+0x72],dx
    48c6:	6f                   	outs   dx,WORD PTR ds:[si]
    48c7:	64 75 69             	fs jne 0x4933
    48ca:	74 4e                	je     0x491a
    48cc:	6f                   	outs   dx,WORD PTR ds:[si]
    48cd:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    48d1:	ff                   	(bad)
    48d2:	7f 00                	jg     0x48d4
    48d4:	00 15                	add    BYTE PTR [di],dl
    48d6:	54                   	push   sp
    48d7:	65 6d                	gs ins WORD PTR es:[di],dx
    48d9:	70 73                	jo     0x494e
    48db:	46                   	inc    si
    48dc:	61                   	popa
    48dd:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    48e0:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    48e3:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    48e8:	74 75                	je     0x495f
    48ea:	72 11                	jb     0x48fd
    48ec:	4d                   	dec    bp
    48ed:	61                   	popa
    48ee:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    48f1:	6e                   	outs   dx,BYTE PTR ds:[si]
    48f2:	65 73 41             	gs jae 0x4936
    48f5:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    48fb:	65 73 0a             	gs jae 0x4908
    48fe:	4d                   	dec    bp
    48ff:	61                   	popa
    4900:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4903:	6e                   	outs   dx,BYTE PTR ds:[si]
    4904:	65 73 50             	gs jae 0x4957
    4907:	43                   	inc    bx
    4908:	08 4d 61             	or     BYTE PTR [di+0x61],cl
    490b:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    490e:	6e                   	outs   dx,BYTE PTR ds:[si]
    490f:	65 73 00             	gs jae 0x4912
    4912:	00 c8                	add    al,cl
    4914:	42                   	inc    dx
    4915:	0a 50 72             	or     dl,BYTE PTR [bx+si+0x72]
    4918:	6f                   	outs   dx,WORD PTR ds:[si]
    4919:	64 75 63             	fs jne 0x497f
    491c:	74 69                	je     0x4987
    491e:	6f                   	outs   dx,WORD PTR ds:[si]
    491f:	6e                   	outs   dx,BYTE PTR ds:[si]
    4920:	0f 54 61 75          	andps  xmm4,XMMWORD PTR [bx+di+0x75]
    4924:	78 55                	js     0x497b
    4926:	74 69                	je     0x4991
    4928:	6c                   	ins    BYTE PTR es:[di],dx
    4929:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    492e:	6f                   	outs   dx,WORD PTR ds:[si]
    492f:	6e                   	outs   dx,BYTE PTR ds:[si]
    4930:	55                   	push   bp
    4931:	89 e5                	mov    bp,sp
    4933:	b8 26 00             	mov    ax,0x26
    4936:	9a 44 04 4f 49       	call   0x494f:0x444
    493b:	83 ec 26             	sub    sp,0x26
    493e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4941:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4944:	bf 38 01             	mov    di,0x138
    4947:	b8 42 4c             	mov    ax,0x4c42
    494a:	50                   	push   ax
    494b:	57                   	push   di
    494c:	9a 73 22 a4 49       	call   0x49a4:0x2273
    4951:	89 c7                	mov    di,ax
    4953:	8e c2                	mov    es,dx
    4955:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    4958:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    495b:	bf b2 48             	mov    di,0x48b2
    495e:	0e                   	push   cs
    495f:	57                   	push   di
    4960:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4963:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    4968:	06                   	push   es
    4969:	57                   	push   di
    496a:	9a 9b 3b 8f 49       	call   0x498f:0x3b9b
    496f:	89 c7                	mov    di,ax
    4971:	8e c2                	mov    es,dx
    4973:	06                   	push   es
    4974:	57                   	push   di
    4975:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4978:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    497c:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    4980:	90                   	nop
    4981:	9b                   	fwait
    4982:	bf c3 48             	mov    di,0x48c3
    4985:	0e                   	push   cs
    4986:	57                   	push   di
    4987:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    498a:	06                   	push   es
    498b:	57                   	push   di
    498c:	9a 9b 3b c1 49       	call   0x49c1:0x3b9b
    4991:	89 c7                	mov    di,ax
    4993:	8e c2                	mov    es,dx
    4995:	06                   	push   es
    4996:	57                   	push   di
    4997:	26 c4 3d             	les    di,DWORD PTR es:[di]
    499a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    499e:	bf cd 48             	mov    di,0x48cd
    49a1:	9a 16 04 48 4a       	call   0x4a48:0x416
    49a6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    49a9:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    49ad:	75 29                	jne    0x49d8
    49af:	bf d5 48             	mov    di,0x48d5
    49b2:	0e                   	push   cs
    49b3:	57                   	push   di
    49b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49b7:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    49bc:	06                   	push   es
    49bd:	57                   	push   di
    49be:	9a 9b 3b ea 49       	call   0x49ea:0x3b9b
    49c3:	89 c7                	mov    di,ax
    49c5:	8e c2                	mov    es,dx
    49c7:	06                   	push   es
    49c8:	57                   	push   di
    49c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49cc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    49d0:	9b dd 5e ee          	fstp   QWORD PTR [bp-0x12]
    49d4:	90                   	nop
    49d5:	9b                   	fwait
    49d6:	eb 27                	jmp    0x49ff
    49d8:	bf d5 48             	mov    di,0x48d5
    49db:	0e                   	push   cs
    49dc:	57                   	push   di
    49dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49e0:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    49e5:	06                   	push   es
    49e6:	57                   	push   di
    49e7:	9a 9b 3b 0c 4a       	call   0x4a0c:0x3b9b
    49ec:	89 c7                	mov    di,ax
    49ee:	8e c2                	mov    es,dx
    49f0:	06                   	push   es
    49f1:	57                   	push   di
    49f2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49f5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    49f9:	9b dd 5e ee          	fstp   QWORD PTR [bp-0x12]
    49fd:	90                   	nop
    49fe:	9b                   	fwait
    49ff:	bf eb 48             	mov    di,0x48eb
    4a02:	0e                   	push   cs
    4a03:	57                   	push   di
    4a04:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4a07:	06                   	push   es
    4a08:	57                   	push   di
    4a09:	9a 9b 3b 5d 4a       	call   0x4a5d:0x3b9b
    4a0e:	89 c7                	mov    di,ax
    4a10:	8e c2                	mov    es,dx
    4a12:	06                   	push   es
    4a13:	57                   	push   di
    4a14:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a17:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4a1b:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    4a1e:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    4a21:	9b db 46 de          	fild   DWORD PTR [bp-0x22]
    4a25:	9b dc 4e e6          	fmul   QWORD PTR [bp-0x1a]
    4a29:	83 ec 08             	sub    sp,0x8
    4a2c:	89 e3                	mov    bx,sp
    4a2e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4a32:	90                   	nop
    4a33:	9b                   	fwait
    4a34:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4a37:	ff 76 f2             	push   WORD PTR [bp-0xe]
    4a3a:	ff 76 f0             	push   WORD PTR [bp-0x10]
    4a3d:	ff 76 ee             	push   WORD PTR [bp-0x12]
    4a40:	9a a7 2e ba 4a       	call   0x4aba:0x2ea7
    4a45:	9a 0e 10 33 4c       	call   0x4c33:0x100e
    4a4a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4a4d:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    4a50:	bf eb 48             	mov    di,0x48eb
    4a53:	0e                   	push   cs
    4a54:	57                   	push   di
    4a55:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4a58:	06                   	push   es
    4a59:	57                   	push   di
    4a5a:	9a 9b 3b 93 4a       	call   0x4a93:0x3b9b
    4a5f:	89 c7                	mov    di,ax
    4a61:	8e c2                	mov    es,dx
    4a63:	06                   	push   es
    4a64:	57                   	push   di
    4a65:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a68:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4a6c:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    4a6f:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    4a72:	9b db 46 de          	fild   DWORD PTR [bp-0x22]
    4a76:	83 ec 08             	sub    sp,0x8
    4a79:	89 e3                	mov    bx,sp
    4a7b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4a7f:	90                   	nop
    4a80:	9b                   	fwait
    4a81:	bf 08 49             	mov    di,0x4908
    4a84:	0e                   	push   cs
    4a85:	57                   	push   di
    4a86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a89:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    4a8e:	06                   	push   es
    4a8f:	57                   	push   di
    4a90:	9a 9b 3b ea 4a       	call   0x4aea:0x3b9b
    4a95:	89 c7                	mov    di,ax
    4a97:	8e c2                	mov    es,dx
    4a99:	06                   	push   es
    4a9a:	57                   	push   di
    4a9b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a9e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4aa2:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    4aa5:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    4aa8:	9b db 46 da          	fild   DWORD PTR [bp-0x26]
    4aac:	83 ec 08             	sub    sp,0x8
    4aaf:	89 e3                	mov    bx,sp
    4ab1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4ab5:	90                   	nop
    4ab6:	9b                   	fwait
    4ab7:	9a a7 2e d0 4a       	call   0x4ad0:0x2ea7
    4abc:	9b 2e d8 0e 11 49    	fmul   DWORD PTR cs:0x4911
    4ac2:	83 ec 08             	sub    sp,0x8
    4ac5:	89 e3                	mov    bx,sp
    4ac7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4acb:	90                   	nop
    4acc:	9b                   	fwait
    4acd:	9a a6 2f 3c 4b       	call   0x4b3c:0x2fa6
    4ad2:	83 ec 08             	sub    sp,0x8
    4ad5:	89 e3                	mov    bx,sp
    4ad7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4adb:	90                   	nop
    4adc:	9b                   	fwait
    4add:	bf fd 48             	mov    di,0x48fd
    4ae0:	0e                   	push   cs
    4ae1:	57                   	push   di
    4ae2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4ae5:	06                   	push   es
    4ae6:	57                   	push   di
    4ae7:	9a 9b 3b 06 4b       	call   0x4b06:0x3b9b
    4aec:	89 c7                	mov    di,ax
    4aee:	8e c2                	mov    es,dx
    4af0:	06                   	push   es
    4af1:	57                   	push   di
    4af2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4af5:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4af9:	bf 15 49             	mov    di,0x4915
    4afc:	0e                   	push   cs
    4afd:	57                   	push   di
    4afe:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4b01:	06                   	push   es
    4b02:	57                   	push   di
    4b03:	9a 9b 3b 6c 4b       	call   0x4b6c:0x3b9b
    4b08:	89 c7                	mov    di,ax
    4b0a:	8e c2                	mov    es,dx
    4b0c:	06                   	push   es
    4b0d:	57                   	push   di
    4b0e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b11:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4b15:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4b18:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    4b1b:	9b db 46 fa          	fild   DWORD PTR [bp-0x6]
    4b1f:	83 ec 08             	sub    sp,0x8
    4b22:	89 e3                	mov    bx,sp
    4b24:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4b28:	90                   	nop
    4b29:	9b 9b db 46 f6       	fild   DWORD PTR [bp-0xa]
    4b2e:	83 ec 08             	sub    sp,0x8
    4b31:	89 e3                	mov    bx,sp
    4b33:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4b37:	90                   	nop
    4b38:	9b                   	fwait
    4b39:	9a a7 2e 52 4b       	call   0x4b52:0x2ea7
    4b3e:	9b 2e d8 0e 11 49    	fmul   DWORD PTR cs:0x4911
    4b44:	83 ec 08             	sub    sp,0x8
    4b47:	89 e3                	mov    bx,sp
    4b49:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4b4d:	90                   	nop
    4b4e:	9b                   	fwait
    4b4f:	9a a6 2f b5 4c       	call   0x4cb5:0x2fa6
    4b54:	83 ec 08             	sub    sp,0x8
    4b57:	89 e3                	mov    bx,sp
    4b59:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4b5d:	90                   	nop
    4b5e:	9b                   	fwait
    4b5f:	bf 20 49             	mov    di,0x4920
    4b62:	0e                   	push   cs
    4b63:	57                   	push   di
    4b64:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    4b67:	06                   	push   es
    4b68:	57                   	push   di
    4b69:	9a 9b 3b 62 4c       	call   0x4c62:0x3b9b
    4b6e:	89 c7                	mov    di,ax
    4b70:	8e c2                	mov    es,dx
    4b72:	06                   	push   es
    4b73:	57                   	push   di
    4b74:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b77:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4b7b:	c9                   	leave
    4b7c:	ca 08 00             	retf   0x8
    4b7f:	02 43 41             	add    al,BYTE PTR [bp+di+0x41]
    4b82:	06                   	push   es
    4b83:	56                   	push   si
    4b84:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4b86:	74 65                	je     0x4bed
    4b88:	73 04                	jae    0x4b8e
    4b8a:	50                   	push   ax
    4b8b:	72 69                	jb     0x4bf6
    4b8d:	78 10                	js     0x4b9f
    4b8f:	56                   	push   si
    4b90:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4b92:	74 65                	je     0x4bf9
    4b94:	73 53                	jae    0x4be9
    4b96:	6f                   	outs   dx,WORD PTR ds:[si]
    4b97:	6c                   	ins    BYTE PTR es:[di],dx
    4b98:	64 65 65 73 51       	fs gs gs jae 0x4bee
    4b9d:	74 65                	je     0x4c04
    4b9f:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    4ba2:	6e                   	outs   dx,BYTE PTR ds:[si]
    4ba3:	74 65                	je     0x4c0a
    4ba5:	73 53                	jae    0x4bfa
    4ba7:	6f                   	outs   dx,WORD PTR ds:[si]
    4ba8:	6c                   	ins    BYTE PTR es:[di],dx
    4ba9:	64 65 65 73 50       	fs gs gs jae 0x4bfe
    4bae:	72 69                	jb     0x4c19
    4bb0:	78 0c                	js     0x4bbe
    4bb2:	56                   	push   si
    4bb3:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4bb5:	74 65                	je     0x4c1c
    4bb7:	73 53                	jae    0x4c0c
    4bb9:	70 65                	jo     0x4c20
    4bbb:	51                   	push   cx
    4bbc:	74 65                	je     0x4c23
    4bbe:	0d 56 65             	or     ax,0x6556
    4bc1:	6e                   	outs   dx,BYTE PTR ds:[si]
    4bc2:	74 65                	je     0x4c29
    4bc4:	73 53                	jae    0x4c19
    4bc6:	70 65                	jo     0x4c2d
    4bc8:	50                   	push   ax
    4bc9:	72 69                	jb     0x4c34
    4bcb:	78 10                	js     0x4bdd
    4bcd:	48                   	dec    ax
    4bce:	65 75 72             	gs jne 0x4c43
    4bd1:	65 73 50             	gs jae 0x4c24
    4bd4:	61                   	popa
    4bd5:	72 4d                	jb     0x4c24
    4bd7:	61                   	popa
    4bd8:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4bdb:	6e                   	outs   dx,BYTE PTR ds:[si]
    4bdc:	65 15 54 65          	gs adc ax,0x6554
    4be0:	6d                   	ins    WORD PTR es:[di],dx
    4be1:	70 73                	jo     0x4c56
    4be3:	46                   	inc    si
    4be4:	61                   	popa
    4be5:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    4be8:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    4beb:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    4bf0:	74 75                	je     0x4c67
    4bf2:	72 11                	jb     0x4c05
    4bf4:	4d                   	dec    bp
    4bf5:	61                   	popa
    4bf6:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4bf9:	6e                   	outs   dx,BYTE PTR ds:[si]
    4bfa:	65 73 41             	gs jae 0x4c3e
    4bfd:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    4c03:	65 73 10             	gs jae 0x4c16
    4c06:	50                   	push   ax
    4c07:	72 6f                	jb     0x4c78
    4c09:	64 75 63             	fs jne 0x4c6f
    4c0c:	74 69                	je     0x4c77
    4c0e:	6f                   	outs   dx,WORD PTR ds:[si]
    4c0f:	6e                   	outs   dx,BYTE PTR ds:[si]
    4c10:	52                   	push   dx
    4c11:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    4c14:	6c                   	ins    BYTE PTR es:[di],dx
    4c15:	65 0f 54 61 75       	andps  xmm4,XMMWORD PTR gs:[bx+di+0x75]
    4c1a:	78 55                	js     0x4c71
    4c1c:	74 69                	je     0x4c87
    4c1e:	6c                   	ins    BYTE PTR es:[di],dx
    4c1f:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    4c24:	6f                   	outs   dx,WORD PTR ds:[si]
    4c25:	6e                   	outs   dx,BYTE PTR ds:[si]
    4c26:	00 00                	add    BYTE PTR [bx+si],al
    4c28:	c8 42 55 89          	enter  0x5542,0x89
    4c2c:	e5 b8                	in     ax,0xb8
    4c2e:	5a                   	pop    dx
    4c2f:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    4c33:	49                   	dec    cx
    4c34:	4c                   	dec    sp
    4c35:	83 ec 5a             	sub    sp,0x5a
    4c38:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4c3b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4c3e:	bf 38 01             	mov    di,0x138
    4c41:	b8 9b 4f             	mov    ax,0x4f9b
    4c44:	50                   	push   ax
    4c45:	57                   	push   di
    4c46:	9a 73 22 4a 4e       	call   0x4e4a:0x2273
    4c4b:	89 c7                	mov    di,ax
    4c4d:	8e c2                	mov    es,dx
    4c4f:	89 7e e4             	mov    WORD PTR [bp-0x1c],di
    4c52:	8c 46 e6             	mov    WORD PTR [bp-0x1a],es
    4c55:	bf 82 4b             	mov    di,0x4b82
    4c58:	0e                   	push   cs
    4c59:	57                   	push   di
    4c5a:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    4c5d:	06                   	push   es
    4c5e:	57                   	push   di
    4c5f:	9a 9b 3b 91 4c       	call   0x4c91:0x3b9b
    4c64:	89 c7                	mov    di,ax
    4c66:	8e c2                	mov    es,dx
    4c68:	06                   	push   es
    4c69:	57                   	push   di
    4c6a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c6d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4c71:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    4c74:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    4c77:	9b db 46 e0          	fild   DWORD PTR [bp-0x20]
    4c7b:	9b db 7e d6          	fstp   TBYTE PTR [bp-0x2a]
    4c7f:	bf 89 4b             	mov    di,0x4b89
    4c82:	0e                   	push   cs
    4c83:	57                   	push   di
    4c84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c87:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    4c8c:	06                   	push   es
    4c8d:	57                   	push   di
    4c8e:	9a 9b 3b c8 4c       	call   0x4cc8:0x3b9b
    4c93:	89 c7                	mov    di,ax
    4c95:	8e c2                	mov    es,dx
    4c97:	06                   	push   es
    4c98:	57                   	push   di
    4c99:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c9c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ca0:	9b db 6e d6          	fld    TBYTE PTR [bp-0x2a]
    4ca4:	9b de c9             	fmulp  st(1),st
    4ca7:	83 ec 08             	sub    sp,0x8
    4caa:	89 e3                	mov    bx,sp
    4cac:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4cb0:	90                   	nop
    4cb1:	9b                   	fwait
    4cb2:	9a a6 2f 16 4d       	call   0x4d16:0x2fa6
    4cb7:	9b db 7e be          	fstp   TBYTE PTR [bp-0x42]
    4cbb:	bf 8e 4b             	mov    di,0x4b8e
    4cbe:	0e                   	push   cs
    4cbf:	57                   	push   di
    4cc0:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    4cc3:	06                   	push   es
    4cc4:	57                   	push   di
    4cc5:	9a 9b 3b f2 4c       	call   0x4cf2:0x3b9b
    4cca:	89 c7                	mov    di,ax
    4ccc:	8e c2                	mov    es,dx
    4cce:	06                   	push   es
    4ccf:	57                   	push   di
    4cd0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cd3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4cd7:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    4cda:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    4cdd:	9b db 46 d2          	fild   DWORD PTR [bp-0x2e]
    4ce1:	9b db 7e c8          	fstp   TBYTE PTR [bp-0x38]
    4ce5:	bf 9f 4b             	mov    di,0x4b9f
    4ce8:	0e                   	push   cs
    4ce9:	57                   	push   di
    4cea:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    4ced:	06                   	push   es
    4cee:	57                   	push   di
    4cef:	9a 9b 3b 30 4d       	call   0x4d30:0x3b9b
    4cf4:	89 c7                	mov    di,ax
    4cf6:	8e c2                	mov    es,dx
    4cf8:	06                   	push   es
    4cf9:	57                   	push   di
    4cfa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cfd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4d01:	9b db 6e c8          	fld    TBYTE PTR [bp-0x38]
    4d05:	9b de c9             	fmulp  st(1),st
    4d08:	83 ec 08             	sub    sp,0x8
    4d0b:	89 e3                	mov    bx,sp
    4d0d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d11:	90                   	nop
    4d12:	9b                   	fwait
    4d13:	9a a6 2f 7e 4d       	call   0x4d7e:0x2fa6
    4d18:	9b db 6e be          	fld    TBYTE PTR [bp-0x42]
    4d1c:	9b de c1             	faddp  st(1),st
    4d1f:	9b db 7e a6          	fstp   TBYTE PTR [bp-0x5a]
    4d23:	bf b1 4b             	mov    di,0x4bb1
    4d26:	0e                   	push   cs
    4d27:	57                   	push   di
    4d28:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    4d2b:	06                   	push   es
    4d2c:	57                   	push   di
    4d2d:	9a 9b 3b 5a 4d       	call   0x4d5a:0x3b9b
    4d32:	89 c7                	mov    di,ax
    4d34:	8e c2                	mov    es,dx
    4d36:	06                   	push   es
    4d37:	57                   	push   di
    4d38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d3b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4d3f:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    4d42:	89 56 bc             	mov    WORD PTR [bp-0x44],dx
    4d45:	9b db 46 ba          	fild   DWORD PTR [bp-0x46]
    4d49:	9b db 7e b0          	fstp   TBYTE PTR [bp-0x50]
    4d4d:	bf be 4b             	mov    di,0x4bbe
    4d50:	0e                   	push   cs
    4d51:	57                   	push   di
    4d52:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    4d55:	06                   	push   es
    4d56:	57                   	push   di
    4d57:	9a 9b 3b 9f 4d       	call   0x4d9f:0x3b9b
    4d5c:	89 c7                	mov    di,ax
    4d5e:	8e c2                	mov    es,dx
    4d60:	06                   	push   es
    4d61:	57                   	push   di
    4d62:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d65:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4d69:	9b db 6e b0          	fld    TBYTE PTR [bp-0x50]
    4d6d:	9b de c9             	fmulp  st(1),st
    4d70:	83 ec 08             	sub    sp,0x8
    4d73:	89 e3                	mov    bx,sp
    4d75:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d79:	90                   	nop
    4d7a:	9b                   	fwait
    4d7b:	9a a6 2f 45 4e       	call   0x4e45:0x2fa6
    4d80:	9b db 6e a6          	fld    TBYTE PTR [bp-0x5a]
    4d84:	9b de c1             	faddp  st(1),st
    4d87:	83 ec 08             	sub    sp,0x8
    4d8a:	89 e3                	mov    bx,sp
    4d8c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d90:	90                   	nop
    4d91:	9b                   	fwait
    4d92:	bf 7f 4b             	mov    di,0x4b7f
    4d95:	0e                   	push   cs
    4d96:	57                   	push   di
    4d97:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    4d9a:	06                   	push   es
    4d9b:	57                   	push   di
    4d9c:	9a 9b 3b c0 4d       	call   0x4dc0:0x3b9b
    4da1:	89 c7                	mov    di,ax
    4da3:	8e c2                	mov    es,dx
    4da5:	06                   	push   es
    4da6:	57                   	push   di
    4da7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4daa:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4dae:	bf cc 4b             	mov    di,0x4bcc
    4db1:	0e                   	push   cs
    4db2:	57                   	push   di
    4db3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4db6:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    4dbb:	06                   	push   es
    4dbc:	57                   	push   di
    4dbd:	9a 9b 3b e7 4d       	call   0x4de7:0x3b9b
    4dc2:	89 c7                	mov    di,ax
    4dc4:	8e c2                	mov    es,dx
    4dc6:	06                   	push   es
    4dc7:	57                   	push   di
    4dc8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4dcb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4dcf:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    4dd3:	90                   	nop
    4dd4:	9b                   	fwait
    4dd5:	bf dd 4b             	mov    di,0x4bdd
    4dd8:	0e                   	push   cs
    4dd9:	57                   	push   di
    4dda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ddd:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    4de2:	06                   	push   es
    4de3:	57                   	push   di
    4de4:	9a 9b 3b 0e 4e       	call   0x4e0e:0x3b9b
    4de9:	89 c7                	mov    di,ax
    4deb:	8e c2                	mov    es,dx
    4ded:	06                   	push   es
    4dee:	57                   	push   di
    4def:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4df2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4df6:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    4dfa:	90                   	nop
    4dfb:	9b                   	fwait
    4dfc:	bf f3 4b             	mov    di,0x4bf3
    4dff:	0e                   	push   cs
    4e00:	57                   	push   di
    4e01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e04:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    4e09:	06                   	push   es
    4e0a:	57                   	push   di
    4e0b:	9a 9b 3b 5f 4e       	call   0x4e5f:0x3b9b
    4e10:	89 c7                	mov    di,ax
    4e12:	8e c2                	mov    es,dx
    4e14:	06                   	push   es
    4e15:	57                   	push   di
    4e16:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e19:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4e1d:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    4e20:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    4e23:	9b db 46 e0          	fild   DWORD PTR [bp-0x20]
    4e27:	9b dc 4e e8          	fmul   QWORD PTR [bp-0x18]
    4e2b:	83 ec 08             	sub    sp,0x8
    4e2e:	89 e3                	mov    bx,sp
    4e30:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4e34:	90                   	nop
    4e35:	9b                   	fwait
    4e36:	ff 76 f6             	push   WORD PTR [bp-0xa]
    4e39:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4e3c:	ff 76 f2             	push   WORD PTR [bp-0xe]
    4e3f:	ff 76 f0             	push   WORD PTR [bp-0x10]
    4e42:	9a a7 2e 95 4e       	call   0x4e95:0x2ea7
    4e47:	9a 0e 10 8c 4f       	call   0x4f8c:0x100e
    4e4c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4e4f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    4e52:	bf 05 4c             	mov    di,0x4c05
    4e55:	0e                   	push   cs
    4e56:	57                   	push   di
    4e57:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    4e5a:	06                   	push   es
    4e5b:	57                   	push   di
    4e5c:	9a 9b 3b c5 4e       	call   0x4ec5:0x3b9b
    4e61:	89 c7                	mov    di,ax
    4e63:	8e c2                	mov    es,dx
    4e65:	06                   	push   es
    4e66:	57                   	push   di
    4e67:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e6a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4e6e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4e71:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4e74:	9b db 46 fc          	fild   DWORD PTR [bp-0x4]
    4e78:	83 ec 08             	sub    sp,0x8
    4e7b:	89 e3                	mov    bx,sp
    4e7d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4e81:	90                   	nop
    4e82:	9b 9b db 46 f8       	fild   DWORD PTR [bp-0x8]
    4e87:	83 ec 08             	sub    sp,0x8
    4e8a:	89 e3                	mov    bx,sp
    4e8c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4e90:	90                   	nop
    4e91:	9b                   	fwait
    4e92:	9a a7 2e ab 4e       	call   0x4eab:0x2ea7
    4e97:	9b 2e d8 0e 26 4c    	fmul   DWORD PTR cs:0x4c26
    4e9d:	83 ec 08             	sub    sp,0x8
    4ea0:	89 e3                	mov    bx,sp
    4ea2:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4ea6:	90                   	nop
    4ea7:	9b                   	fwait
    4ea8:	9a a6 2f 0e 50       	call   0x500e:0x2fa6
    4ead:	83 ec 08             	sub    sp,0x8
    4eb0:	89 e3                	mov    bx,sp
    4eb2:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4eb6:	90                   	nop
    4eb7:	9b                   	fwait
    4eb8:	bf 16 4c             	mov    di,0x4c16
    4ebb:	0e                   	push   cs
    4ebc:	57                   	push   di
    4ebd:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    4ec0:	06                   	push   es
    4ec1:	57                   	push   di
    4ec2:	9a 9b 3b bb 4f       	call   0x4fbb:0x3b9b
    4ec7:	89 c7                	mov    di,ax
    4ec9:	8e c2                	mov    es,dx
    4ecb:	06                   	push   es
    4ecc:	57                   	push   di
    4ecd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ed0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4ed4:	c9                   	leave
    4ed5:	ca 08 00             	retf   0x8
    4ed8:	02 43 41             	add    al,BYTE PTR [bp+di+0x41]
    4edb:	06                   	push   es
    4edc:	56                   	push   si
    4edd:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4edf:	74 65                	je     0x4f46
    4ee1:	73 04                	jae    0x4ee7
    4ee3:	50                   	push   ax
    4ee4:	72 69                	jb     0x4f4f
    4ee6:	78 10                	js     0x4ef8
    4ee8:	56                   	push   si
    4ee9:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4eeb:	74 65                	je     0x4f52
    4eed:	73 53                	jae    0x4f42
    4eef:	6f                   	outs   dx,WORD PTR ds:[si]
    4ef0:	6c                   	ins    BYTE PTR es:[di],dx
    4ef1:	64 65 65 73 51       	fs gs gs jae 0x4f47
    4ef6:	74 65                	je     0x4f5d
    4ef8:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    4efb:	6e                   	outs   dx,BYTE PTR ds:[si]
    4efc:	74 65                	je     0x4f63
    4efe:	73 53                	jae    0x4f53
    4f00:	6f                   	outs   dx,WORD PTR ds:[si]
    4f01:	6c                   	ins    BYTE PTR es:[di],dx
    4f02:	64 65 65 73 50       	fs gs gs jae 0x4f57
    4f07:	72 69                	jb     0x4f72
    4f09:	78 0c                	js     0x4f17
    4f0b:	56                   	push   si
    4f0c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4f0e:	74 65                	je     0x4f75
    4f10:	73 53                	jae    0x4f65
    4f12:	70 65                	jo     0x4f79
    4f14:	51                   	push   cx
    4f15:	74 65                	je     0x4f7c
    4f17:	0d 56 65             	or     ax,0x6556
    4f1a:	6e                   	outs   dx,BYTE PTR ds:[si]
    4f1b:	74 65                	je     0x4f82
    4f1d:	73 53                	jae    0x4f72
    4f1f:	70 65                	jo     0x4f86
    4f21:	50                   	push   ax
    4f22:	72 69                	jb     0x4f8d
    4f24:	78 10                	js     0x4f36
    4f26:	48                   	dec    ax
    4f27:	65 75 72             	gs jne 0x4f9c
    4f2a:	65 73 50             	gs jae 0x4f7d
    4f2d:	61                   	popa
    4f2e:	72 4d                	jb     0x4f7d
    4f30:	61                   	popa
    4f31:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4f34:	6e                   	outs   dx,BYTE PTR ds:[si]
    4f35:	65 15 54 65          	gs adc ax,0x6554
    4f39:	6d                   	ins    WORD PTR es:[di],dx
    4f3a:	70 73                	jo     0x4faf
    4f3c:	46                   	inc    si
    4f3d:	61                   	popa
    4f3e:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    4f41:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    4f44:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    4f49:	74 75                	je     0x4fc0
    4f4b:	72 11                	jb     0x4f5e
    4f4d:	4d                   	dec    bp
    4f4e:	61                   	popa
    4f4f:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    4f52:	6e                   	outs   dx,BYTE PTR ds:[si]
    4f53:	65 73 41             	gs jae 0x4f97
    4f56:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    4f5c:	65 73 10             	gs jae 0x4f6f
    4f5f:	50                   	push   ax
    4f60:	72 6f                	jb     0x4fd1
    4f62:	64 75 63             	fs jne 0x4fc8
    4f65:	74 69                	je     0x4fd0
    4f67:	6f                   	outs   dx,WORD PTR ds:[si]
    4f68:	6e                   	outs   dx,BYTE PTR ds:[si]
    4f69:	52                   	push   dx
    4f6a:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    4f6d:	6c                   	ins    BYTE PTR es:[di],dx
    4f6e:	65 0f 54 61 75       	andps  xmm4,XMMWORD PTR gs:[bx+di+0x75]
    4f73:	78 55                	js     0x4fca
    4f75:	74 69                	je     0x4fe0
    4f77:	6c                   	ins    BYTE PTR es:[di],dx
    4f78:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    4f7d:	6f                   	outs   dx,WORD PTR ds:[si]
    4f7e:	6e                   	outs   dx,BYTE PTR ds:[si]
    4f7f:	00 00                	add    BYTE PTR [bx+si],al
    4f81:	c8 42 55 89          	enter  0x5542,0x89
    4f85:	e5 b8                	in     ax,0xb8
    4f87:	5a                   	pop    dx
    4f88:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    4f8c:	a2 4f 83             	mov    ds:0x834f,al
    4f8f:	ec                   	in     al,dx
    4f90:	5a                   	pop    dx
    4f91:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f94:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4f97:	bf 38 01             	mov    di,0x138
    4f9a:	b8 ff ff             	mov    ax,0xffff
    4f9d:	50                   	push   ax
    4f9e:	57                   	push   di
    4f9f:	9a 73 22 a3 51       	call   0x51a3:0x2273
    4fa4:	89 c7                	mov    di,ax
    4fa6:	8e c2                	mov    es,dx
    4fa8:	89 7e e4             	mov    WORD PTR [bp-0x1c],di
    4fab:	8c 46 e6             	mov    WORD PTR [bp-0x1a],es
    4fae:	bf db 4e             	mov    di,0x4edb
    4fb1:	0e                   	push   cs
    4fb2:	57                   	push   di
    4fb3:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    4fb6:	06                   	push   es
    4fb7:	57                   	push   di
    4fb8:	9a 9b 3b ea 4f       	call   0x4fea:0x3b9b
    4fbd:	89 c7                	mov    di,ax
    4fbf:	8e c2                	mov    es,dx
    4fc1:	06                   	push   es
    4fc2:	57                   	push   di
    4fc3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fc6:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4fca:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    4fcd:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    4fd0:	9b db 46 e0          	fild   DWORD PTR [bp-0x20]
    4fd4:	9b db 7e d6          	fstp   TBYTE PTR [bp-0x2a]
    4fd8:	bf e2 4e             	mov    di,0x4ee2
    4fdb:	0e                   	push   cs
    4fdc:	57                   	push   di
    4fdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fe0:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    4fe5:	06                   	push   es
    4fe6:	57                   	push   di
    4fe7:	9a 9b 3b 21 50       	call   0x5021:0x3b9b
    4fec:	89 c7                	mov    di,ax
    4fee:	8e c2                	mov    es,dx
    4ff0:	06                   	push   es
    4ff1:	57                   	push   di
    4ff2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ff5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ff9:	9b db 6e d6          	fld    TBYTE PTR [bp-0x2a]
    4ffd:	9b de c9             	fmulp  st(1),st
    5000:	83 ec 08             	sub    sp,0x8
    5003:	89 e3                	mov    bx,sp
    5005:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5009:	90                   	nop
    500a:	9b                   	fwait
    500b:	9a a6 2f 6f 50       	call   0x506f:0x2fa6
    5010:	9b db 7e be          	fstp   TBYTE PTR [bp-0x42]
    5014:	bf e7 4e             	mov    di,0x4ee7
    5017:	0e                   	push   cs
    5018:	57                   	push   di
    5019:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    501c:	06                   	push   es
    501d:	57                   	push   di
    501e:	9a 9b 3b 4b 50       	call   0x504b:0x3b9b
    5023:	89 c7                	mov    di,ax
    5025:	8e c2                	mov    es,dx
    5027:	06                   	push   es
    5028:	57                   	push   di
    5029:	26 c4 3d             	les    di,DWORD PTR es:[di]
    502c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5030:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    5033:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    5036:	9b db 46 d2          	fild   DWORD PTR [bp-0x2e]
    503a:	9b db 7e c8          	fstp   TBYTE PTR [bp-0x38]
    503e:	bf f8 4e             	mov    di,0x4ef8
    5041:	0e                   	push   cs
    5042:	57                   	push   di
    5043:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    5046:	06                   	push   es
    5047:	57                   	push   di
    5048:	9a 9b 3b 89 50       	call   0x5089:0x3b9b
    504d:	89 c7                	mov    di,ax
    504f:	8e c2                	mov    es,dx
    5051:	06                   	push   es
    5052:	57                   	push   di
    5053:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5056:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    505a:	9b db 6e c8          	fld    TBYTE PTR [bp-0x38]
    505e:	9b de c9             	fmulp  st(1),st
    5061:	83 ec 08             	sub    sp,0x8
    5064:	89 e3                	mov    bx,sp
    5066:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    506a:	90                   	nop
    506b:	9b                   	fwait
    506c:	9a a6 2f d7 50       	call   0x50d7:0x2fa6
    5071:	9b db 6e be          	fld    TBYTE PTR [bp-0x42]
    5075:	9b de c1             	faddp  st(1),st
    5078:	9b db 7e a6          	fstp   TBYTE PTR [bp-0x5a]
    507c:	bf 0a 4f             	mov    di,0x4f0a
    507f:	0e                   	push   cs
    5080:	57                   	push   di
    5081:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    5084:	06                   	push   es
    5085:	57                   	push   di
    5086:	9a 9b 3b b3 50       	call   0x50b3:0x3b9b
    508b:	89 c7                	mov    di,ax
    508d:	8e c2                	mov    es,dx
    508f:	06                   	push   es
    5090:	57                   	push   di
    5091:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5094:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5098:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    509b:	89 56 bc             	mov    WORD PTR [bp-0x44],dx
    509e:	9b db 46 ba          	fild   DWORD PTR [bp-0x46]
    50a2:	9b db 7e b0          	fstp   TBYTE PTR [bp-0x50]
    50a6:	bf 17 4f             	mov    di,0x4f17
    50a9:	0e                   	push   cs
    50aa:	57                   	push   di
    50ab:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    50ae:	06                   	push   es
    50af:	57                   	push   di
    50b0:	9a 9b 3b f8 50       	call   0x50f8:0x3b9b
    50b5:	89 c7                	mov    di,ax
    50b7:	8e c2                	mov    es,dx
    50b9:	06                   	push   es
    50ba:	57                   	push   di
    50bb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50be:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    50c2:	9b db 6e b0          	fld    TBYTE PTR [bp-0x50]
    50c6:	9b de c9             	fmulp  st(1),st
    50c9:	83 ec 08             	sub    sp,0x8
    50cc:	89 e3                	mov    bx,sp
    50ce:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    50d2:	90                   	nop
    50d3:	9b                   	fwait
    50d4:	9a a6 2f 9e 51       	call   0x519e:0x2fa6
    50d9:	9b db 6e a6          	fld    TBYTE PTR [bp-0x5a]
    50dd:	9b de c1             	faddp  st(1),st
    50e0:	83 ec 08             	sub    sp,0x8
    50e3:	89 e3                	mov    bx,sp
    50e5:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    50e9:	90                   	nop
    50ea:	9b                   	fwait
    50eb:	bf d8 4e             	mov    di,0x4ed8
    50ee:	0e                   	push   cs
    50ef:	57                   	push   di
    50f0:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    50f3:	06                   	push   es
    50f4:	57                   	push   di
    50f5:	9a 9b 3b 19 51       	call   0x5119:0x3b9b
    50fa:	89 c7                	mov    di,ax
    50fc:	8e c2                	mov    es,dx
    50fe:	06                   	push   es
    50ff:	57                   	push   di
    5100:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5103:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5107:	bf 25 4f             	mov    di,0x4f25
    510a:	0e                   	push   cs
    510b:	57                   	push   di
    510c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    510f:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    5114:	06                   	push   es
    5115:	57                   	push   di
    5116:	9a 9b 3b 40 51       	call   0x5140:0x3b9b
    511b:	89 c7                	mov    di,ax
    511d:	8e c2                	mov    es,dx
    511f:	06                   	push   es
    5120:	57                   	push   di
    5121:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5124:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5128:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    512c:	90                   	nop
    512d:	9b                   	fwait
    512e:	bf 36 4f             	mov    di,0x4f36
    5131:	0e                   	push   cs
    5132:	57                   	push   di
    5133:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5136:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    513b:	06                   	push   es
    513c:	57                   	push   di
    513d:	9a 9b 3b 67 51       	call   0x5167:0x3b9b
    5142:	89 c7                	mov    di,ax
    5144:	8e c2                	mov    es,dx
    5146:	06                   	push   es
    5147:	57                   	push   di
    5148:	26 c4 3d             	les    di,DWORD PTR es:[di]
    514b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    514f:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    5153:	90                   	nop
    5154:	9b                   	fwait
    5155:	bf 4c 4f             	mov    di,0x4f4c
    5158:	0e                   	push   cs
    5159:	57                   	push   di
    515a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    515d:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    5162:	06                   	push   es
    5163:	57                   	push   di
    5164:	9a 9b 3b b8 51       	call   0x51b8:0x3b9b
    5169:	89 c7                	mov    di,ax
    516b:	8e c2                	mov    es,dx
    516d:	06                   	push   es
    516e:	57                   	push   di
    516f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5172:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5176:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    5179:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    517c:	9b db 46 e0          	fild   DWORD PTR [bp-0x20]
    5180:	9b dc 4e e8          	fmul   QWORD PTR [bp-0x18]
    5184:	83 ec 08             	sub    sp,0x8
    5187:	89 e3                	mov    bx,sp
    5189:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    518d:	90                   	nop
    518e:	9b                   	fwait
    518f:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5192:	ff 76 f4             	push   WORD PTR [bp-0xc]
    5195:	ff 76 f2             	push   WORD PTR [bp-0xe]
    5198:	ff 76 f0             	push   WORD PTR [bp-0x10]
    519b:	9a a7 2e ee 51       	call   0x51ee:0x2ea7
    51a0:	9a 0e 10 52 52       	call   0x5252:0x100e
    51a5:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    51a8:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    51ab:	bf 5e 4f             	mov    di,0x4f5e
    51ae:	0e                   	push   cs
    51af:	57                   	push   di
    51b0:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    51b3:	06                   	push   es
    51b4:	57                   	push   di
    51b5:	9a 9b 3b 1e 52       	call   0x521e:0x3b9b
    51ba:	89 c7                	mov    di,ax
    51bc:	8e c2                	mov    es,dx
    51be:	06                   	push   es
    51bf:	57                   	push   di
    51c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51c3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    51c7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    51ca:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    51cd:	9b db 46 fc          	fild   DWORD PTR [bp-0x4]
    51d1:	83 ec 08             	sub    sp,0x8
    51d4:	89 e3                	mov    bx,sp
    51d6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    51da:	90                   	nop
    51db:	9b 9b db 46 f8       	fild   DWORD PTR [bp-0x8]
    51e0:	83 ec 08             	sub    sp,0x8
    51e3:	89 e3                	mov    bx,sp
    51e5:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    51e9:	90                   	nop
    51ea:	9b                   	fwait
    51eb:	9a a7 2e 04 52       	call   0x5204:0x2ea7
    51f0:	9b 2e d8 0e 7f 4f    	fmul   DWORD PTR cs:0x4f7f
    51f6:	83 ec 08             	sub    sp,0x8
    51f9:	89 e3                	mov    bx,sp
    51fb:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    51ff:	90                   	nop
    5200:	9b                   	fwait
    5201:	9a a6 2f ff ff       	call   0xffff:0x2fa6
    5206:	83 ec 08             	sub    sp,0x8
    5209:	89 e3                	mov    bx,sp
    520b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    520f:	90                   	nop
    5210:	9b                   	fwait
    5211:	bf 6f 4f             	mov    di,0x4f6f
    5214:	0e                   	push   cs
    5215:	57                   	push   di
    5216:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
    5219:	06                   	push   es
    521a:	57                   	push   di
    521b:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    5220:	89 c7                	mov    di,ax
    5222:	8e c2                	mov    es,dx
    5224:	06                   	push   es
    5225:	57                   	push   di
    5226:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5229:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    522d:	c9                   	leave
    522e:	ca 08 00             	retf   0x8
    5231:	16                   	push   ss
    5232:	53                   	push   bx
    5233:	f1                   	int1
    5234:	52                   	push   dx
    5235:	a2 52 93             	mov    ds:0x9352,al
    5238:	52                   	push   dx
    5239:	3f                   	aas
    523a:	53                   	push   bx
    523b:	d2 52 3f             	rcl    BYTE PTR [bp+si+0x3f],cl
    523e:	53                   	push   bx
    523f:	b3 52                	mov    bl,0x52
    5241:	00 00                	add    BYTE PTR [bx+si],al
    5243:	00 00                	add    BYTE PTR [bx+si],al
    5245:	ff 00                	inc    WORD PTR [bx+si]
    5247:	00 00                	add    BYTE PTR [bx+si],al
    5249:	55                   	push   bp
    524a:	89 e5                	mov    bp,sp
    524c:	b8 04 00             	mov    ax,0x4
    524f:	9a 44 04 c3 52       	call   0x52c3:0x444
    5254:	83 ec 04             	sub    sp,0x4
    5257:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    525a:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    525f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5262:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5265:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    5269:	b0 00                	mov    al,0x0
    526b:	74 01                	je     0x526e
    526d:	40                   	inc    ax
    526e:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    5272:	08 c0                	or     al,al
    5274:	75 03                	jne    0x5279
    5276:	e9 ee 00             	jmp    0x5367
    5279:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    527c:	26 8b 05             	mov    ax,WORD PTR es:[di]
    527f:	2d 21 00             	sub    ax,0x21
    5282:	3d 07 00             	cmp    ax,0x7
    5285:	76 03                	jbe    0x528a
    5287:	e9 b5 00             	jmp    0x533f
    528a:	89 c3                	mov    bx,ax
    528c:	d1 e3                	shl    bx,1
    528e:	2e ff a7 31 52       	jmp    WORD PTR cs:[bx+0x5231]
    5293:	6a 00                	push   0x0
    5295:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5298:	06                   	push   es
    5299:	57                   	push   di
    529a:	9a d0 1c ae 52       	call   0x52ae:0x1cd0
    529f:	e9 9d 00             	jmp    0x533f
    52a2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    52a5:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    52a9:	06                   	push   es
    52aa:	57                   	push   di
    52ab:	9a d0 1c ce 52       	call   0x52ce:0x1cd0
    52b0:	e9 8c 00             	jmp    0x533f
    52b3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    52b6:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    52ba:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    52be:	71 05                	jno    0x52c5
    52c0:	9a 3e 04 e2 52       	call   0x52e2:0x43e
    52c5:	50                   	push   ax
    52c6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    52c9:	06                   	push   es
    52ca:	57                   	push   di
    52cb:	9a d0 1c ed 52       	call   0x52ed:0x1cd0
    52d0:	eb 6d                	jmp    0x533f
    52d2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    52d5:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    52d9:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    52dd:	71 05                	jno    0x52e4
    52df:	9a 3e 04 07 53       	call   0x5307:0x43e
    52e4:	50                   	push   ax
    52e5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    52e8:	06                   	push   es
    52e9:	57                   	push   di
    52ea:	9a d0 1c 12 53       	call   0x5312:0x1cd0
    52ef:	eb 4e                	jmp    0x533f
    52f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52f4:	06                   	push   es
    52f5:	57                   	push   di
    52f6:	9a f4 18 1e 53       	call   0x531e:0x18f4
    52fb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    52fe:	26 03 45 0a          	add    ax,WORD PTR es:[di+0xa]
    5302:	71 05                	jno    0x5309
    5304:	9a 3e 04 30 53       	call   0x5330:0x43e
    5309:	50                   	push   ax
    530a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    530d:	06                   	push   es
    530e:	57                   	push   di
    530f:	9a d0 1c 3b 53       	call   0x533b:0x1cd0
    5314:	eb 29                	jmp    0x533f
    5316:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5319:	06                   	push   es
    531a:	57                   	push   di
    531b:	9a f4 18 58 55       	call   0x5558:0x18f4
    5320:	8b d0                	mov    dx,ax
    5322:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5325:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    5329:	2b c2                	sub    ax,dx
    532b:	71 05                	jno    0x5332
    532d:	9a 3e 04 4d 53       	call   0x534d:0x43e
    5332:	50                   	push   ax
    5333:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5336:	06                   	push   es
    5337:	57                   	push   di
    5338:	9a d0 1c ac 53       	call   0x53ac:0x1cd0
    533d:	eb 00                	jmp    0x533f
    533f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5342:	26 8b 05             	mov    ax,WORD PTR es:[di]
    5345:	31 d2                	xor    dx,dx
    5347:	bf 41 52             	mov    di,0x5241
    534a:	9a 16 04 a1 53       	call   0x53a1:0x416
    534f:	3c 21                	cmp    al,0x21
    5351:	72 14                	jb     0x5367
    5353:	3c 24                	cmp    al,0x24
    5355:	76 08                	jbe    0x535f
    5357:	3c 26                	cmp    al,0x26
    5359:	74 04                	je     0x535f
    535b:	3c 28                	cmp    al,0x28
    535d:	75 08                	jne    0x5367
    535f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5362:	31 c0                	xor    ax,ax
    5364:	26 89 05             	mov    WORD PTR es:[di],ax
    5367:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    536a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    536f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5372:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5375:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    5379:	b0 00                	mov    al,0x0
    537b:	74 01                	je     0x537e
    537d:	40                   	inc    ax
    537e:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    5382:	08 c0                	or     al,al
    5384:	74 6e                	je     0x53f4
    5386:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    5389:	26 8b 05             	mov    ax,WORD PTR es:[di]
    538c:	3d 27 00             	cmp    ax,0x27
    538f:	75 1f                	jne    0x53b0
    5391:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5394:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    5398:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    539c:	71 05                	jno    0x53a3
    539e:	9a 3e 04 c5 53       	call   0x53c5:0x43e
    53a3:	50                   	push   ax
    53a4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    53a7:	06                   	push   es
    53a8:	57                   	push   di
    53a9:	9a d0 1c d0 53       	call   0x53d0:0x1cd0
    53ae:	eb 24                	jmp    0x53d4
    53b0:	3d 25 00             	cmp    ax,0x25
    53b3:	75 1f                	jne    0x53d4
    53b5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    53b8:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    53bc:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    53c0:	71 05                	jno    0x53c7
    53c2:	9a 3e 04 e2 53       	call   0x53e2:0x43e
    53c7:	50                   	push   ax
    53c8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    53cb:	06                   	push   es
    53cc:	57                   	push   di
    53cd:	9a d0 1c 0f 54       	call   0x540f:0x1cd0
    53d2:	eb 00                	jmp    0x53d4
    53d4:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    53d7:	26 8b 05             	mov    ax,WORD PTR es:[di]
    53da:	31 d2                	xor    dx,dx
    53dc:	bf 41 52             	mov    di,0x5241
    53df:	9a 16 04 1d 54       	call   0x541d:0x416
    53e4:	3c 25                	cmp    al,0x25
    53e6:	74 04                	je     0x53ec
    53e8:	3c 27                	cmp    al,0x27
    53ea:	75 08                	jne    0x53f4
    53ec:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    53ef:	31 c0                	xor    ax,ax
    53f1:	26 89 05             	mov    WORD PTR es:[di],ax
    53f4:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    53f7:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    53fb:	74 14                	je     0x5411
    53fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5400:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    5405:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    540a:	06                   	push   es
    540b:	57                   	push   di
    540c:	9a 30 22 3a 54       	call   0x543a:0x2230
    5411:	c9                   	leave
    5412:	ca 0e 00             	retf   0xe
    5415:	55                   	push   bp
    5416:	89 e5                	mov    bp,sp
    5418:	31 c0                	xor    ax,ax
    541a:	9a 44 04 48 54       	call   0x5448:0x444
    541f:	6a 01                	push   0x1
    5421:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5424:	26 c4 bd cc 04       	les    di,DWORD PTR es:[di+0x4cc]
    5429:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    542d:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    5431:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5435:	06                   	push   es
    5436:	57                   	push   di
    5437:	9a b2 77 59 54       	call   0x5459:0x77b2
    543c:	c9                   	leave
    543d:	ca 08 00             	retf   0x8
    5440:	55                   	push   bp
    5441:	89 e5                	mov    bp,sp
    5443:	31 c0                	xor    ax,ax
    5445:	9a 44 04 67 54       	call   0x5467:0x444
    544a:	6a 03                	push   0x3
    544c:	6a 00                	push   0x0
    544e:	6a 00                	push   0x0
    5450:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5454:	06                   	push   es
    5455:	57                   	push   di
    5456:	9a b2 77 7a 54       	call   0x547a:0x77b2
    545b:	c9                   	leave
    545c:	ca 08 00             	retf   0x8
    545f:	55                   	push   bp
    5460:	89 e5                	mov    bp,sp
    5462:	31 c0                	xor    ax,ax
    5464:	9a 44 04 88 54       	call   0x5488:0x444
    5469:	68 05 01             	push   0x105
    546c:	bf 3c 02             	mov    di,0x23c
    546f:	1e                   	push   ds
    5470:	57                   	push   di
    5471:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5475:	06                   	push   es
    5476:	57                   	push   di
    5477:	9a b2 77 99 54       	call   0x5499:0x77b2
    547c:	c9                   	leave
    547d:	ca 08 00             	retf   0x8
    5480:	55                   	push   bp
    5481:	89 e5                	mov    bp,sp
    5483:	31 c0                	xor    ax,ax
    5485:	9a 44 04 a8 54       	call   0x54a8:0x444
    548a:	6a 04                	push   0x4
    548c:	6a 00                	push   0x0
    548e:	6a 00                	push   0x0
    5490:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5494:	06                   	push   es
    5495:	57                   	push   di
    5496:	9a b2 77 b6 54       	call   0x54b6:0x77b2
    549b:	c9                   	leave
    549c:	ca 08 00             	retf   0x8
    549f:	55                   	push   bp
    54a0:	89 e5                	mov    bp,sp
    54a2:	b8 04 00             	mov    ax,0x4
    54a5:	9a 44 04 c5 54       	call   0x54c5:0x444
    54aa:	83 ec 04             	sub    sp,0x4
    54ad:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    54b1:	06                   	push   es
    54b2:	57                   	push   di
    54b3:	9a 45 5d 31 55       	call   0x5531:0x5d45
    54b8:	c9                   	leave
    54b9:	ca 08 00             	retf   0x8
    54bc:	55                   	push   bp
    54bd:	89 e5                	mov    bp,sp
    54bf:	b8 04 00             	mov    ax,0x4
    54c2:	9a 44 04 40 55       	call   0x5540:0x444
    54c7:	83 ec 04             	sub    sp,0x4
    54ca:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    54cd:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    54d2:	b0 00                	mov    al,0x0
    54d4:	75 01                	jne    0x54d7
    54d6:	40                   	inc    ax
    54d7:	8a c8                	mov    cl,al
    54d9:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    54df:	b0 00                	mov    al,0x0
    54e1:	77 01                	ja     0x54e4
    54e3:	40                   	inc    ax
    54e4:	8a d0                	mov    dl,al
    54e6:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    54ec:	b0 00                	mov    al,0x0
    54ee:	76 01                	jbe    0x54f1
    54f0:	40                   	inc    ax
    54f1:	22 c2                	and    al,dl
    54f3:	0a c1                	or     al,cl
    54f5:	08 c0                	or     al,al
    54f7:	74 3a                	je     0x5533
    54f9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    54fd:	31 c0                	xor    ax,ax
    54ff:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    5503:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    5507:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    550b:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    550f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5512:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    5516:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5519:	06                   	push   es
    551a:	57                   	push   di
    551b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    551e:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    5522:	6a 02                	push   0x2
    5524:	6a 00                	push   0x0
    5526:	6a 00                	push   0x0
    5528:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    552c:	06                   	push   es
    552d:	57                   	push   di
    552e:	9a b2 77 c0 55       	call   0x55c0:0x77b2
    5533:	c9                   	leave
    5534:	ca 0c 00             	retf   0xc
    5537:	55                   	push   bp
    5538:	89 e5                	mov    bp,sp
    553a:	b8 04 00             	mov    ax,0x4
    553d:	9a 44 04 5f 55       	call   0x555f:0x444
    5542:	83 ec 04             	sub    sp,0x4
    5545:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    5549:	74 03                	je     0x554e
    554b:	e9 9c 00             	jmp    0x55ea
    554e:	ff 76 14             	push   WORD PTR [bp+0x14]
    5551:	ff 76 12             	push   WORD PTR [bp+0x12]
    5554:	bf c1 05             	mov    di,0x5c1
    5557:	b8 72 55             	mov    ax,0x5572
    555a:	50                   	push   ax
    555b:	57                   	push   di
    555c:	9a 55 22 79 55       	call   0x5579:0x2255
    5561:	08 c0                	or     al,al
    5563:	75 03                	jne    0x5568
    5565:	e9 82 00             	jmp    0x55ea
    5568:	ff 76 14             	push   WORD PTR [bp+0x14]
    556b:	ff 76 12             	push   WORD PTR [bp+0x12]
    556e:	bf c1 05             	mov    di,0x5c1
    5571:	b8 a1 55             	mov    ax,0x55a1
    5574:	50                   	push   ax
    5575:	57                   	push   di
    5576:	9a 73 22 a8 55       	call   0x55a8:0x2273
    557b:	89 c7                	mov    di,ax
    557d:	8e c2                	mov    es,dx
    557f:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    5584:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    5589:	74 5f                	je     0x55ea
    558b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    558f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5592:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5595:	6a 08                	push   0x8
    5597:	ff 76 14             	push   WORD PTR [bp+0x14]
    559a:	ff 76 12             	push   WORD PTR [bp+0x12]
    559d:	bf c1 05             	mov    di,0x5c1
    55a0:	b8 0c 56             	mov    ax,0x560c
    55a3:	50                   	push   ax
    55a4:	57                   	push   di
    55a5:	9a 73 22 f7 55       	call   0x55f7:0x2273
    55aa:	89 c7                	mov    di,ax
    55ac:	8e c2                	mov    es,dx
    55ae:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    55b3:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    55b8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    55bb:	06                   	push   es
    55bc:	57                   	push   di
    55bd:	9a b2 77 ca 55       	call   0x55ca:0x77b2
    55c2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    55c5:	06                   	push   es
    55c6:	57                   	push   di
    55c7:	9a 03 73 51 56       	call   0x5651:0x7303
    55cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55cf:	06                   	push   es
    55d0:	57                   	push   di
    55d1:	b8 bc 54             	mov    ax,0x54bc
    55d4:	ba 7c 56             	mov    dx,0x567c
    55d7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    55da:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    55de:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    55e2:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    55e6:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    55ea:	c9                   	leave
    55eb:	ca 10 00             	retf   0x10
    55ee:	55                   	push   bp
    55ef:	89 e5                	mov    bp,sp
    55f1:	b8 04 00             	mov    ax,0x4
    55f4:	9a 44 04 13 56       	call   0x5613:0x444
    55f9:	83 ec 04             	sub    sp,0x4
    55fc:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    5600:	75 51                	jne    0x5653
    5602:	ff 76 14             	push   WORD PTR [bp+0x14]
    5605:	ff 76 12             	push   WORD PTR [bp+0x12]
    5608:	bf c1 05             	mov    di,0x5c1
    560b:	b8 23 56             	mov    ax,0x5623
    560e:	50                   	push   ax
    560f:	57                   	push   di
    5610:	9a 55 22 2a 56       	call   0x562a:0x2255
    5615:	08 c0                	or     al,al
    5617:	74 3a                	je     0x5653
    5619:	ff 76 14             	push   WORD PTR [bp+0x14]
    561c:	ff 76 12             	push   WORD PTR [bp+0x12]
    561f:	bf c1 05             	mov    di,0x5c1
    5622:	b8 41 59             	mov    ax,0x5941
    5625:	50                   	push   ax
    5626:	57                   	push   di
    5627:	9a 73 22 5f 56       	call   0x565f:0x2273
    562c:	89 c7                	mov    di,ax
    562e:	8e c2                	mov    es,dx
    5630:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    5635:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    563a:	74 17                	je     0x5653
    563c:	6a 08                	push   0x8
    563e:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    5643:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    5648:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    564c:	06                   	push   es
    564d:	57                   	push   di
    564e:	9a b2 77 e9 77       	call   0x77e9:0x77b2
    5653:	c9                   	leave
    5654:	ca 10 00             	retf   0x10
    5657:	55                   	push   bp
    5658:	89 e5                	mov    bp,sp
    565a:	31 c0                	xor    ax,ax
    565c:	9a 44 04 93 56       	call   0x5693:0x444
    5661:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5664:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    5669:	06                   	push   es
    566a:	57                   	push   di
    566b:	9a 17 2f ff ff       	call   0xffff:0x2f17
    5670:	08 c0                	or     al,al
    5672:	74 0a                	je     0x567e
    5674:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5677:	06                   	push   es
    5678:	57                   	push   di
    5679:	9a e6 56 e4 56       	call   0x56e4:0x56e6
    567e:	c9                   	leave
    567f:	ca 08 00             	retf   0x8
    5682:	00 00                	add    BYTE PTR [bx+si],al
    5684:	00 00                	add    BYTE PTR [bx+si],al
    5686:	ff                   	(bad)
    5687:	ff 00                	inc    WORD PTR [bx+si]
    5689:	00 55 89             	add    BYTE PTR [di-0x77],dl
    568c:	e5 b8                	in     ax,0xb8
    568e:	22 00                	and    al,BYTE PTR [bx+si]
    5690:	9a 44 04 c3 56       	call   0x56c3:0x444
    5695:	83 ec 22             	sub    sp,0x22
    5698:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    569c:	06                   	push   es
    569d:	57                   	push   di
    569e:	9a 04 2a 0a 57       	call   0x570a:0x2a04
    56a3:	89 c7                	mov    di,ax
    56a5:	8e c2                	mov    es,dx
    56a7:	06                   	push   es
    56a8:	57                   	push   di
    56a9:	9a d2 21 5b 57       	call   0x575b:0x21d2
    56ae:	50                   	push   ax
    56af:	8d 7e de             	lea    di,[bp-0x22]
    56b2:	16                   	push   ss
    56b3:	57                   	push   di
    56b4:	9a ff ff 00 00       	call   0x0:0xffff
    56b9:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    56bc:	99                   	cwd
    56bd:	bf 82 56             	mov    di,0x5682
    56c0:	9a 16 04 ef 56       	call   0x56ef:0x416
    56c5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    56c8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    56cb:	c9                   	leave
    56cc:	ca 02 00             	retf   0x2
    56cf:	00 01                	add    BYTE PTR [bx+di],al
    56d1:	09 01                	or     WORD PTR [bx+di],ax
    56d3:	20 03                	and    BYTE PTR [bp+di],al
    56d5:	20 20                	and    BYTE PTR [bx+si],ah
    56d7:	20 00                	and    BYTE PTR [bx+si],al
    56d9:	80 ff ff             	cmp    bh,0xff
    56dc:	ff                   	(bad)
    56dd:	7f 00                	jg     0x56df
    56df:	00 00                	add    BYTE PTR [bx+si],al
    56e1:	00 1e 5b ff          	add    BYTE PTR ds:0xff5b,bl
    56e5:	56                   	push   si
    56e6:	55                   	push   bp
    56e7:	89 e5                	mov    bp,sp
    56e9:	b8 0e 04             	mov    ax,0x40e
    56ec:	9a 44 04 15 57       	call   0x5715:0x444
    56f1:	81 ec 0e 04          	sub    sp,0x40e
    56f5:	6a 01                	push   0x1
    56f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56fa:	06                   	push   es
    56fb:	57                   	push   di
    56fc:	9a 8a 5e 04 59       	call   0x5904:0x5e8a
    5701:	8d be fc fe          	lea    di,[bp-0x104]
    5705:	16                   	push   ss
    5706:	57                   	push   di
    5707:	9a 4e 20 33 57       	call   0x5733:0x204e
    570c:	8d be fc fe          	lea    di,[bp-0x104]
    5710:	16                   	push   ss
    5711:	57                   	push   di
    5712:	9a f5 09 1a 57       	call   0x571a:0x9f5
    5717:	9a 08 04 af 57       	call   0x57af:0x408
    571c:	b8 e0 56             	mov    ax,0x56e0
    571f:	0e                   	push   cs
    5720:	50                   	push   ax
    5721:	55                   	push   bp
    5722:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5726:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    572a:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    572e:	06                   	push   es
    572f:	57                   	push   di
    5730:	9a 04 2a 68 57       	call   0x5768:0x2a04
    5735:	89 c7                	mov    di,ax
    5737:	8e c2                	mov    es,dx
    5739:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    573d:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    5741:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    5745:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    574a:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    574e:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    5752:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5756:	06                   	push   es
    5757:	57                   	push   di
    5758:	9a 99 20 77 57       	call   0x5777:0x2099
    575d:	6a 0a                	push   0xa
    575f:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5763:	06                   	push   es
    5764:	57                   	push   di
    5765:	9a 04 2a 84 57       	call   0x5784:0x2a04
    576a:	89 c7                	mov    di,ax
    576c:	8e c2                	mov    es,dx
    576e:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    5772:	06                   	push   es
    5773:	57                   	push   di
    5774:	9a f5 11 93 57       	call   0x5793:0x11f5
    5779:	6a 02                	push   0x2
    577b:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    577f:	06                   	push   es
    5780:	57                   	push   di
    5781:	9a 04 2a d3 58       	call   0x58d3:0x2a04
    5786:	89 c7                	mov    di,ax
    5788:	8e c2                	mov    es,dx
    578a:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    578e:	06                   	push   es
    578f:	57                   	push   di
    5790:	9a 78 12 e2 58       	call   0x58e2:0x1278
    5795:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    579a:	eb 03                	jmp    0x579f
    579c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    579f:	8d be fc fe          	lea    di,[bp-0x104]
    57a3:	16                   	push   ss
    57a4:	57                   	push   di
    57a5:	bf cf 56             	mov    di,0x56cf
    57a8:	0e                   	push   cs
    57a9:	57                   	push   di
    57aa:	6a 00                	push   0x0
    57ac:	9a b5 0d b4 57       	call   0x57b4:0xdb5
    57b1:	9a 78 0c b9 57       	call   0x57b9:0xc78
    57b6:	9a 08 04 e7 57       	call   0x57e7:0x408
    57bb:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    57bf:	75 db                	jne    0x579c
    57c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57c4:	26 c4 bd 88 06       	les    di,DWORD PTR es:[di+0x688]
    57c9:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    57cd:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    57d1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    57d6:	06                   	push   es
    57d7:	57                   	push   di
    57d8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57db:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    57df:	2d 01 00             	sub    ax,0x1
    57e2:	71 05                	jno    0x57e9
    57e4:	9a 3e 04 27 58       	call   0x5827:0x43e
    57e9:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    57ed:	31 c0                	xor    ax,ax
    57ef:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    57f3:	7e 03                	jle    0x57f8
    57f5:	e9 c8 00             	jmp    0x58c0
    57f8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    57fb:	eb 03                	jmp    0x5800
    57fd:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    5800:	8d be f0 fc          	lea    di,[bp-0x310]
    5804:	16                   	push   ss
    5805:	57                   	push   di
    5806:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5809:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    580d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5812:	06                   	push   es
    5813:	57                   	push   di
    5814:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5817:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    581b:	8d be fc fd          	lea    di,[bp-0x204]
    581f:	16                   	push   ss
    5820:	57                   	push   di
    5821:	68 ff 00             	push   0xff
    5824:	9a e7 17 37 58       	call   0x5837:0x17e7
    5829:	bf d0 56             	mov    di,0x56d0
    582c:	0e                   	push   cs
    582d:	57                   	push   di
    582e:	8d be fc fd          	lea    di,[bp-0x204]
    5832:	16                   	push   ss
    5833:	57                   	push   di
    5834:	9a 78 18 50 58       	call   0x5850:0x1878
    5839:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    583c:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    5840:	7e 26                	jle    0x5868
    5842:	8d be fc fd          	lea    di,[bp-0x204]
    5846:	16                   	push   ss
    5847:	57                   	push   di
    5848:	ff 76 fc             	push   WORD PTR [bp-0x4]
    584b:	6a 01                	push   0x1
    584d:	9a 75 19 66 58       	call   0x5866:0x1975
    5852:	bf d2 56             	mov    di,0x56d2
    5855:	0e                   	push   cs
    5856:	57                   	push   di
    5857:	8d be fc fd          	lea    di,[bp-0x204]
    585b:	16                   	push   ss
    585c:	57                   	push   di
    585d:	68 ff 00             	push   0xff
    5860:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5863:	9a 16 19 7c 58       	call   0x587c:0x1916
    5868:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    586c:	75 bb                	jne    0x5829
    586e:	8d be f0 fc          	lea    di,[bp-0x310]
    5872:	16                   	push   ss
    5873:	57                   	push   di
    5874:	bf d4 56             	mov    di,0x56d4
    5877:	0e                   	push   cs
    5878:	57                   	push   di
    5879:	9a cd 17 87 58       	call   0x5887:0x17cd
    587e:	8d be fc fd          	lea    di,[bp-0x204]
    5882:	16                   	push   ss
    5883:	57                   	push   di
    5884:	9a 4c 18 95 58       	call   0x5895:0x184c
    5889:	8d be fc fd          	lea    di,[bp-0x204]
    588d:	16                   	push   ss
    588e:	57                   	push   di
    588f:	68 ff 00             	push   0xff
    5892:	9a e7 17 a8 58       	call   0x58a8:0x17e7
    5897:	8d be fc fe          	lea    di,[bp-0x104]
    589b:	16                   	push   ss
    589c:	57                   	push   di
    589d:	8d be fc fd          	lea    di,[bp-0x204]
    58a1:	16                   	push   ss
    58a2:	57                   	push   di
    58a3:	6a 00                	push   0x0
    58a5:	9a b5 0d ad 58       	call   0x58ad:0xdb5
    58aa:	9a 78 0c b2 58       	call   0x58b2:0xc78
    58af:	9a 08 04 0e 59       	call   0x590e:0x408
    58b4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    58b7:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    58bb:	74 03                	je     0x58c0
    58bd:	e9 3d ff             	jmp    0x57fd
    58c0:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    58c4:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    58c8:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    58cc:	6a 06                	push   0x6
    58ce:	06                   	push   es
    58cf:	57                   	push   di
    58d0:	9a 04 2a ef 58       	call   0x58ef:0x2a04
    58d5:	89 c7                	mov    di,ax
    58d7:	8e c2                	mov    es,dx
    58d9:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    58dd:	06                   	push   es
    58de:	57                   	push   di
    58df:	9a f5 11 fe 58       	call   0x58fe:0x11f5
    58e4:	6a 00                	push   0x0
    58e6:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    58ea:	06                   	push   es
    58eb:	57                   	push   di
    58ec:	9a 04 2a 72 59       	call   0x5972:0x2a04
    58f1:	89 c7                	mov    di,ax
    58f3:	8e c2                	mov    es,dx
    58f5:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    58f9:	06                   	push   es
    58fa:	57                   	push   di
    58fb:	9a 78 12 99 59       	call   0x5999:0x1278
    5900:	55                   	push   bp
    5901:	9a 8a 56 5a 5b       	call   0x5b5a:0x568a
    5906:	05 02 00             	add    ax,0x2
    5909:	73 05                	jae    0x5910
    590b:	9a 3e 04 18 59       	call   0x5918:0x43e
    5910:	31 d2                	xor    dx,dx
    5912:	bf d8 56             	mov    di,0x56d8
    5915:	9a 16 04 2c 59       	call   0x592c:0x416
    591a:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    591e:	8d be f2 fb          	lea    di,[bp-0x40e]
    5922:	16                   	push   ss
    5923:	57                   	push   di
    5924:	bf d4 56             	mov    di,0x56d4
    5927:	0e                   	push   cs
    5928:	57                   	push   di
    5929:	9a cd 17 46 59       	call   0x5946:0x17cd
    592e:	8d be f2 fc          	lea    di,[bp-0x30e]
    5932:	16                   	push   ss
    5933:	57                   	push   di
    5934:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5937:	26 c4 bd 78 06       	les    di,DWORD PTR es:[di+0x678]
    593c:	06                   	push   es
    593d:	57                   	push   di
    593e:	9a 53 1d be 59       	call   0x59be:0x1d53
    5943:	9a 4c 18 54 59       	call   0x5954:0x184c
    5948:	8d be fc fd          	lea    di,[bp-0x204]
    594c:	16                   	push   ss
    594d:	57                   	push   di
    594e:	68 ff 00             	push   0xff
    5951:	9a e7 17 66 59       	call   0x5966:0x17e7
    5956:	6a 00                	push   0x0
    5958:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    595c:	b9 05 00             	mov    cx,0x5
    595f:	f7 e9                	imul   cx
    5961:	71 05                	jno    0x5968
    5963:	9a 3e 04 7c 59       	call   0x597c:0x43e
    5968:	50                   	push   ax
    5969:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    596d:	06                   	push   es
    596e:	57                   	push   di
    596f:	9a 72 2a 8e 59       	call   0x598e:0x2a72
    5974:	5a                   	pop    dx
    5975:	2b c2                	sub    ax,dx
    5977:	71 05                	jno    0x597e
    5979:	9a 3e 04 a9 59       	call   0x59a9:0x43e
    597e:	50                   	push   ax
    597f:	8d be fc fd          	lea    di,[bp-0x204]
    5983:	16                   	push   ss
    5984:	57                   	push   di
    5985:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5989:	06                   	push   es
    598a:	57                   	push   di
    598b:	9a 04 2a ef 59       	call   0x59ef:0x2a04
    5990:	89 c7                	mov    di,ax
    5992:	8e c2                	mov    es,dx
    5994:	06                   	push   es
    5995:	57                   	push   di
    5996:	9a 09 1f 16 5a       	call   0x5a16:0x1f09
    599b:	8d be f2 fb          	lea    di,[bp-0x40e]
    599f:	16                   	push   ss
    59a0:	57                   	push   di
    59a1:	bf d4 56             	mov    di,0x56d4
    59a4:	0e                   	push   cs
    59a5:	57                   	push   di
    59a6:	9a cd 17 c3 59       	call   0x59c3:0x17cd
    59ab:	8d be f2 fc          	lea    di,[bp-0x30e]
    59af:	16                   	push   ss
    59b0:	57                   	push   di
    59b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59b4:	26 c4 bd 7c 06       	les    di,DWORD PTR es:[di+0x67c]
    59b9:	06                   	push   es
    59ba:	57                   	push   di
    59bb:	9a 53 1d 3b 5a       	call   0x5a3b:0x1d53
    59c0:	9a 4c 18 d1 59       	call   0x59d1:0x184c
    59c5:	8d be fc fd          	lea    di,[bp-0x204]
    59c9:	16                   	push   ss
    59ca:	57                   	push   di
    59cb:	68 ff 00             	push   0xff
    59ce:	9a e7 17 e3 59       	call   0x59e3:0x17e7
    59d3:	6a 00                	push   0x0
    59d5:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    59d9:	b9 04 00             	mov    cx,0x4
    59dc:	f7 e9                	imul   cx
    59de:	71 05                	jno    0x59e5
    59e0:	9a 3e 04 f9 59       	call   0x59f9:0x43e
    59e5:	50                   	push   ax
    59e6:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    59ea:	06                   	push   es
    59eb:	57                   	push   di
    59ec:	9a 72 2a 0b 5a       	call   0x5a0b:0x2a72
    59f1:	5a                   	pop    dx
    59f2:	2b c2                	sub    ax,dx
    59f4:	71 05                	jno    0x59fb
    59f6:	9a 3e 04 26 5a       	call   0x5a26:0x43e
    59fb:	50                   	push   ax
    59fc:	8d be fc fd          	lea    di,[bp-0x204]
    5a00:	16                   	push   ss
    5a01:	57                   	push   di
    5a02:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5a06:	06                   	push   es
    5a07:	57                   	push   di
    5a08:	9a 04 2a 6c 5a       	call   0x5a6c:0x2a04
    5a0d:	89 c7                	mov    di,ax
    5a0f:	8e c2                	mov    es,dx
    5a11:	06                   	push   es
    5a12:	57                   	push   di
    5a13:	9a 09 1f 93 5a       	call   0x5a93:0x1f09
    5a18:	8d be f2 fb          	lea    di,[bp-0x40e]
    5a1c:	16                   	push   ss
    5a1d:	57                   	push   di
    5a1e:	bf d4 56             	mov    di,0x56d4
    5a21:	0e                   	push   cs
    5a22:	57                   	push   di
    5a23:	9a cd 17 40 5a       	call   0x5a40:0x17cd
    5a28:	8d be f2 fc          	lea    di,[bp-0x30e]
    5a2c:	16                   	push   ss
    5a2d:	57                   	push   di
    5a2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a31:	26 c4 bd 80 06       	les    di,DWORD PTR es:[di+0x680]
    5a36:	06                   	push   es
    5a37:	57                   	push   di
    5a38:	9a 53 1d b8 5a       	call   0x5ab8:0x1d53
    5a3d:	9a 4c 18 4e 5a       	call   0x5a4e:0x184c
    5a42:	8d be fc fd          	lea    di,[bp-0x204]
    5a46:	16                   	push   ss
    5a47:	57                   	push   di
    5a48:	68 ff 00             	push   0xff
    5a4b:	9a e7 17 60 5a       	call   0x5a60:0x17e7
    5a50:	6a 00                	push   0x0
    5a52:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5a56:	b9 03 00             	mov    cx,0x3
    5a59:	f7 e9                	imul   cx
    5a5b:	71 05                	jno    0x5a62
    5a5d:	9a 3e 04 76 5a       	call   0x5a76:0x43e
    5a62:	50                   	push   ax
    5a63:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5a67:	06                   	push   es
    5a68:	57                   	push   di
    5a69:	9a 72 2a 88 5a       	call   0x5a88:0x2a72
    5a6e:	5a                   	pop    dx
    5a6f:	2b c2                	sub    ax,dx
    5a71:	71 05                	jno    0x5a78
    5a73:	9a 3e 04 a3 5a       	call   0x5aa3:0x43e
    5a78:	50                   	push   ax
    5a79:	8d be fc fd          	lea    di,[bp-0x204]
    5a7d:	16                   	push   ss
    5a7e:	57                   	push   di
    5a7f:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5a83:	06                   	push   es
    5a84:	57                   	push   di
    5a85:	9a 04 2a e9 5a       	call   0x5ae9:0x2a04
    5a8a:	89 c7                	mov    di,ax
    5a8c:	8e c2                	mov    es,dx
    5a8e:	06                   	push   es
    5a8f:	57                   	push   di
    5a90:	9a 09 1f 10 5b       	call   0x5b10:0x1f09
    5a95:	8d be f2 fb          	lea    di,[bp-0x40e]
    5a99:	16                   	push   ss
    5a9a:	57                   	push   di
    5a9b:	bf d4 56             	mov    di,0x56d4
    5a9e:	0e                   	push   cs
    5a9f:	57                   	push   di
    5aa0:	9a cd 17 bd 5a       	call   0x5abd:0x17cd
    5aa5:	8d be f2 fc          	lea    di,[bp-0x30e]
    5aa9:	16                   	push   ss
    5aaa:	57                   	push   di
    5aab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5aae:	26 c4 bd 84 06       	les    di,DWORD PTR es:[di+0x684]
    5ab3:	06                   	push   es
    5ab4:	57                   	push   di
    5ab5:	9a 53 1d 7a 5c       	call   0x5c7a:0x1d53
    5aba:	9a 4c 18 cb 5a       	call   0x5acb:0x184c
    5abf:	8d be fc fd          	lea    di,[bp-0x204]
    5ac3:	16                   	push   ss
    5ac4:	57                   	push   di
    5ac5:	68 ff 00             	push   0xff
    5ac8:	9a e7 17 dd 5a       	call   0x5add:0x17e7
    5acd:	6a 00                	push   0x0
    5acf:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5ad3:	b9 02 00             	mov    cx,0x2
    5ad6:	f7 e9                	imul   cx
    5ad8:	71 05                	jno    0x5adf
    5ada:	9a 3e 04 f3 5a       	call   0x5af3:0x43e
    5adf:	50                   	push   ax
    5ae0:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5ae4:	06                   	push   es
    5ae5:	57                   	push   di
    5ae6:	9a 72 2a 05 5b       	call   0x5b05:0x2a72
    5aeb:	5a                   	pop    dx
    5aec:	2b c2                	sub    ax,dx
    5aee:	71 05                	jno    0x5af5
    5af0:	9a 3e 04 27 5b       	call   0x5b27:0x43e
    5af5:	50                   	push   ax
    5af6:	8d be fc fd          	lea    di,[bp-0x204]
    5afa:	16                   	push   ss
    5afb:	57                   	push   di
    5afc:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5b00:	06                   	push   es
    5b01:	57                   	push   di
    5b02:	9a 04 2a ff ff       	call   0xffff:0x2a04
    5b07:	89 c7                	mov    di,ax
    5b09:	8e c2                	mov    es,dx
    5b0b:	06                   	push   es
    5b0c:	57                   	push   di
    5b0d:	9a 09 1f ff ff       	call   0xffff:0x1f09
    5b12:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5b16:	83 c4 06             	add    sp,0x6
    5b19:	b8 3e 5b             	mov    ax,0x5b3e
    5b1c:	0e                   	push   cs
    5b1d:	50                   	push   ax
    5b1e:	8d be fc fe          	lea    di,[bp-0x104]
    5b22:	16                   	push   ss
    5b23:	57                   	push   di
    5b24:	9a 4f 0a 2c 5b       	call   0x5b2c:0xa4f
    5b29:	9a 08 04 4b 5b       	call   0x5b4b:0x408
    5b2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b31:	26 c4 bd 88 06       	les    di,DWORD PTR es:[di+0x688]
    5b36:	06                   	push   es
    5b37:	57                   	push   di
    5b38:	9a e3 49 6f 5b       	call   0x5b6f:0x49e3
    5b3d:	cb                   	retf
    5b3e:	c9                   	leave
    5b3f:	ca 04 00             	retf   0x4
    5b42:	55                   	push   bp
    5b43:	89 e5                	mov    bp,sp
    5b45:	b8 04 00             	mov    ax,0x4
    5b48:	9a 44 04 96 5b       	call   0x5b96:0x444
    5b4d:	83 ec 04             	sub    sp,0x4
    5b50:	6a 00                	push   0x0
    5b52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b55:	06                   	push   es
    5b56:	57                   	push   di
    5b57:	9a 8a 5e d1 5e       	call   0x5ed1:0x5e8a
    5b5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b5f:	26 c4 bd 88 06       	les    di,DWORD PTR es:[di+0x688]
    5b64:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5b67:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5b6a:	06                   	push   es
    5b6b:	57                   	push   di
    5b6c:	9a 3f 4a 79 5b       	call   0x5b79:0x4a3f
    5b71:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5b74:	06                   	push   es
    5b75:	57                   	push   di
    5b76:	9a ff 49 83 5b       	call   0x5b83:0x49ff
    5b7b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5b7e:	06                   	push   es
    5b7f:	57                   	push   di
    5b80:	9a e3 49 3f 5c       	call   0x5c3f:0x49e3
    5b85:	c9                   	leave
    5b86:	ca 08 00             	retf   0x8
    5b89:	01 09                	add    WORD PTR [bx+di],cx
    5b8b:	01 20                	add    WORD PTR [bx+si],sp
    5b8d:	55                   	push   bp
    5b8e:	89 e5                	mov    bp,sp
    5b90:	b8 06 02             	mov    ax,0x206
    5b93:	9a 44 04 d1 5b       	call   0x5bd1:0x444
    5b98:	81 ec 06 02          	sub    sp,0x206
    5b9c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5b9f:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5ba4:	75 03                	jne    0x5ba9
    5ba6:	e9 d8 02             	jmp    0x5e81
    5ba9:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5bae:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    5bb1:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    5bb5:	3d 00 00             	cmp    ax,0x0
    5bb8:	75 32                	jne    0x5bec
    5bba:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5bbd:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    5bc1:	76 27                	jbe    0x5bea
    5bc3:	8d be fe fd          	lea    di,[bp-0x202]
    5bc7:	16                   	push   ss
    5bc8:	57                   	push   di
    5bc9:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5bcc:	06                   	push   es
    5bcd:	57                   	push   di
    5bce:	9a cd 17 db 5b       	call   0x5bdb:0x17cd
    5bd3:	bf 89 5b             	mov    di,0x5b89
    5bd6:	0e                   	push   cs
    5bd7:	57                   	push   di
    5bd8:	9a 4c 18 e8 5b       	call   0x5be8:0x184c
    5bdd:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5be0:	06                   	push   es
    5be1:	57                   	push   di
    5be2:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5be5:	9a e7 17 18 5c       	call   0x5c18:0x17e7
    5bea:	eb 49                	jmp    0x5c35
    5bec:	3d 01 00             	cmp    ax,0x1
    5bef:	75 44                	jne    0x5c35
    5bf1:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5bf4:	26 8a 05             	mov    al,BYTE PTR es:[di]
    5bf7:	30 e4                	xor    ah,ah
    5bf9:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    5bfd:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    5c01:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    5c04:	7d 2d                	jge    0x5c33
    5c06:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    5c0a:	8d be fe fd          	lea    di,[bp-0x202]
    5c0e:	16                   	push   ss
    5c0f:	57                   	push   di
    5c10:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5c13:	06                   	push   es
    5c14:	57                   	push   di
    5c15:	9a cd 17 22 5c       	call   0x5c22:0x17cd
    5c1a:	bf 8b 5b             	mov    di,0x5b8b
    5c1d:	0e                   	push   cs
    5c1e:	57                   	push   di
    5c1f:	9a 4c 18 2f 5c       	call   0x5c2f:0x184c
    5c24:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5c27:	06                   	push   es
    5c28:	57                   	push   di
    5c29:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5c2c:	9a e7 17 46 5c       	call   0x5c46:0x17e7
    5c31:	eb ca                	jmp    0x5bfd
    5c33:	eb 00                	jmp    0x5c35
    5c35:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5c38:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5c3b:	bf 0c 01             	mov    di,0x10c
    5c3e:	b8 56 5c             	mov    ax,0x5c56
    5c41:	50                   	push   ax
    5c42:	57                   	push   di
    5c43:	9a 55 22 5d 5c       	call   0x5c5d:0x2255
    5c48:	08 c0                	or     al,al
    5c4a:	74 6b                	je     0x5cb7
    5c4c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5c4f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5c52:	bf 0c 01             	mov    di,0x10c
    5c55:	b8 43 5d             	mov    ax,0x5d43
    5c58:	50                   	push   ax
    5c59:	57                   	push   di
    5c5a:	9a 73 22 88 5c       	call   0x5c88:0x2273
    5c5f:	89 c7                	mov    di,ax
    5c61:	8e c2                	mov    es,dx
    5c63:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    5c67:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    5c6b:	8d be fa fd          	lea    di,[bp-0x206]
    5c6f:	16                   	push   ss
    5c70:	57                   	push   di
    5c71:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    5c75:	06                   	push   es
    5c76:	57                   	push   di
    5c77:	9a 53 1d fc 5c       	call   0x5cfc:0x1d53
    5c7c:	8d be 00 ff          	lea    di,[bp-0x100]
    5c80:	16                   	push   ss
    5c81:	57                   	push   di
    5c82:	68 ff 00             	push   0xff
    5c85:	9a e7 17 b3 5c       	call   0x5cb3:0x17e7
    5c8a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5c8f:	b0 00                	mov    al,0x0
    5c91:	76 01                	jbe    0x5c94
    5c93:	40                   	inc    ax
    5c94:	8a d0                	mov    dl,al
    5c96:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    5c9b:	b0 00                	mov    al,0x0
    5c9d:	75 01                	jne    0x5ca0
    5c9f:	40                   	inc    ax
    5ca0:	22 c2                	and    al,dl
    5ca2:	08 c0                	or     al,al
    5ca4:	74 11                	je     0x5cb7
    5ca6:	8d be 00 ff          	lea    di,[bp-0x100]
    5caa:	16                   	push   ss
    5cab:	57                   	push   di
    5cac:	6a 01                	push   0x1
    5cae:	6a 01                	push   0x1
    5cb0:	9a 75 19 c8 5c       	call   0x5cc8:0x1975
    5cb5:	eb d3                	jmp    0x5c8a
    5cb7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5cba:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5cbd:	bf ad 0d             	mov    di,0xdad
    5cc0:	b8 d8 5c             	mov    ax,0x5cd8
    5cc3:	50                   	push   ax
    5cc4:	57                   	push   di
    5cc5:	9a 55 22 df 5c       	call   0x5cdf:0x2255
    5cca:	08 c0                	or     al,al
    5ccc:	74 6b                	je     0x5d39
    5cce:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5cd1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5cd4:	bf ad 0d             	mov    di,0xdad
    5cd7:	b8 ff ff             	mov    ax,0xffff
    5cda:	50                   	push   ax
    5cdb:	57                   	push   di
    5cdc:	9a 73 22 0a 5d       	call   0x5d0a:0x2273
    5ce1:	89 c7                	mov    di,ax
    5ce3:	8e c2                	mov    es,dx
    5ce5:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    5ce9:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    5ced:	8d be fa fd          	lea    di,[bp-0x206]
    5cf1:	16                   	push   ss
    5cf2:	57                   	push   di
    5cf3:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    5cf7:	06                   	push   es
    5cf8:	57                   	push   di
    5cf9:	9a 53 1d 7e 5d       	call   0x5d7e:0x1d53
    5cfe:	8d be 00 ff          	lea    di,[bp-0x100]
    5d02:	16                   	push   ss
    5d03:	57                   	push   di
    5d04:	68 ff 00             	push   0xff
    5d07:	9a e7 17 35 5d       	call   0x5d35:0x17e7
    5d0c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5d11:	b0 00                	mov    al,0x0
    5d13:	76 01                	jbe    0x5d16
    5d15:	40                   	inc    ax
    5d16:	8a d0                	mov    dl,al
    5d18:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    5d1d:	b0 00                	mov    al,0x0
    5d1f:	75 01                	jne    0x5d22
    5d21:	40                   	inc    ax
    5d22:	22 c2                	and    al,dl
    5d24:	08 c0                	or     al,al
    5d26:	74 11                	je     0x5d39
    5d28:	8d be 00 ff          	lea    di,[bp-0x100]
    5d2c:	16                   	push   ss
    5d2d:	57                   	push   di
    5d2e:	6a 01                	push   0x1
    5d30:	6a 01                	push   0x1
    5d32:	9a 75 19 4a 5d       	call   0x5d4a:0x1975
    5d37:	eb d3                	jmp    0x5d0c
    5d39:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5d3c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5d3f:	bf 17 06             	mov    di,0x617
    5d42:	b8 5a 5d             	mov    ax,0x5d5a
    5d45:	50                   	push   ax
    5d46:	57                   	push   di
    5d47:	9a 55 22 61 5d       	call   0x5d61:0x2255
    5d4c:	08 c0                	or     al,al
    5d4e:	74 6b                	je     0x5dbb
    5d50:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5d53:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5d56:	bf 17 06             	mov    di,0x617
    5d59:	b8 ae 5e             	mov    ax,0x5eae
    5d5c:	50                   	push   ax
    5d5d:	57                   	push   di
    5d5e:	9a 73 22 8c 5d       	call   0x5d8c:0x2273
    5d63:	89 c7                	mov    di,ax
    5d65:	8e c2                	mov    es,dx
    5d67:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    5d6b:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    5d6f:	8d be fa fd          	lea    di,[bp-0x206]
    5d73:	16                   	push   ss
    5d74:	57                   	push   di
    5d75:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    5d79:	06                   	push   es
    5d7a:	57                   	push   di
    5d7b:	9a 53 1d 01 5f       	call   0x5f01:0x1d53
    5d80:	8d be 00 ff          	lea    di,[bp-0x100]
    5d84:	16                   	push   ss
    5d85:	57                   	push   di
    5d86:	68 ff 00             	push   0xff
    5d89:	9a e7 17 b7 5d       	call   0x5db7:0x17e7
    5d8e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5d93:	b0 00                	mov    al,0x0
    5d95:	76 01                	jbe    0x5d98
    5d97:	40                   	inc    ax
    5d98:	8a d0                	mov    dl,al
    5d9a:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    5d9f:	b0 00                	mov    al,0x0
    5da1:	75 01                	jne    0x5da4
    5da3:	40                   	inc    ax
    5da4:	22 c2                	and    al,dl
    5da6:	08 c0                	or     al,al
    5da8:	74 11                	je     0x5dbb
    5daa:	8d be 00 ff          	lea    di,[bp-0x100]
    5dae:	16                   	push   ss
    5daf:	57                   	push   di
    5db0:	6a 01                	push   0x1
    5db2:	6a 01                	push   0x1
    5db4:	9a 75 19 cc 5d       	call   0x5dcc:0x1975
    5db9:	eb d3                	jmp    0x5d8e
    5dbb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5dbe:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5dc1:	bf 22 00             	mov    di,0x22
    5dc4:	b8 df 5d             	mov    ax,0x5ddf
    5dc7:	50                   	push   ax
    5dc8:	57                   	push   di
    5dc9:	9a 55 22 e6 5d       	call   0x5de6:0x2255
    5dce:	08 c0                	or     al,al
    5dd0:	75 03                	jne    0x5dd5
    5dd2:	e9 84 00             	jmp    0x5e59
    5dd5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5dd8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5ddb:	bf 22 00             	mov    di,0x22
    5dde:	b8 ff ff             	mov    ax,0xffff
    5de1:	50                   	push   ax
    5de2:	57                   	push   di
    5de3:	9a 73 22 11 5e       	call   0x5e11:0x2273
    5de8:	89 c7                	mov    di,ax
    5dea:	8e c2                	mov    es,dx
    5dec:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    5df0:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    5df4:	8d be fa fd          	lea    di,[bp-0x206]
    5df8:	16                   	push   ss
    5df9:	57                   	push   di
    5dfa:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    5dfe:	06                   	push   es
    5dff:	57                   	push   di
    5e00:	9a 24 15 ff ff       	call   0xffff:0x1524
    5e05:	8d be 00 ff          	lea    di,[bp-0x100]
    5e09:	16                   	push   ss
    5e0a:	57                   	push   di
    5e0b:	68 ff 00             	push   0xff
    5e0e:	9a e7 17 3c 5e       	call   0x5e3c:0x17e7
    5e13:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    5e17:	7e 40                	jle    0x5e59
    5e19:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    5e1d:	30 e4                	xor    ah,ah
    5e1f:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    5e23:	83 be fe fe 12       	cmp    WORD PTR [bp-0x102],0x12
    5e28:	7d 2f                	jge    0x5e59
    5e2a:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    5e2e:	8d be fa fd          	lea    di,[bp-0x206]
    5e32:	16                   	push   ss
    5e33:	57                   	push   di
    5e34:	bf 8b 5b             	mov    di,0x5b8b
    5e37:	0e                   	push   cs
    5e38:	57                   	push   di
    5e39:	9a cd 17 47 5e       	call   0x5e47:0x17cd
    5e3e:	8d be 00 ff          	lea    di,[bp-0x100]
    5e42:	16                   	push   ss
    5e43:	57                   	push   di
    5e44:	9a 4c 18 55 5e       	call   0x5e55:0x184c
    5e49:	8d be 00 ff          	lea    di,[bp-0x100]
    5e4d:	16                   	push   ss
    5e4e:	57                   	push   di
    5e4f:	68 ff 00             	push   0xff
    5e52:	9a e7 17 67 5e       	call   0x5e67:0x17e7
    5e57:	eb ca                	jmp    0x5e23
    5e59:	8d be fe fd          	lea    di,[bp-0x202]
    5e5d:	16                   	push   ss
    5e5e:	57                   	push   di
    5e5f:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5e62:	06                   	push   es
    5e63:	57                   	push   di
    5e64:	9a cd 17 72 5e       	call   0x5e72:0x17cd
    5e69:	8d be 00 ff          	lea    di,[bp-0x100]
    5e6d:	16                   	push   ss
    5e6e:	57                   	push   di
    5e6f:	9a 4c 18 7f 5e       	call   0x5e7f:0x184c
    5e74:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5e77:	06                   	push   es
    5e78:	57                   	push   di
    5e79:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5e7c:	9a e7 17 93 5e       	call   0x5e93:0x17e7
    5e81:	c9                   	leave
    5e82:	ca 0e 00             	retf   0xe
    5e85:	01 09                	add    WORD PTR [bx+di],cx
    5e87:	00 01                	add    BYTE PTR [bx+di],al
    5e89:	20 55 89             	and    BYTE PTR [di-0x77],dl
    5e8c:	e5 b8                	in     ax,0xb8
    5e8e:	04 03                	add    al,0x3
    5e90:	9a 44 04 e2 5e       	call   0x5ee2:0x444
    5e95:	81 ec 04 03          	sub    sp,0x304
    5e99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e9c:	26 c4 bd 88 06       	les    di,DWORD PTR es:[di+0x688]
    5ea1:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    5ea5:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    5ea9:	06                   	push   es
    5eaa:	57                   	push   di
    5eab:	9a e3 49 ff ff       	call   0xffff:0x49e3
    5eb0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5eb5:	8d be 00 ff          	lea    di,[bp-0x100]
    5eb9:	16                   	push   ss
    5eba:	57                   	push   di
    5ebb:	68 ff 00             	push   0xff
    5ebe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ec1:	26 ff b5 ae 01       	push   WORD PTR es:[di+0x1ae]
    5ec6:	26 ff b5 ac 01       	push   WORD PTR es:[di+0x1ac]
    5ecb:	6a 00                	push   0x0
    5ecd:	55                   	push   bp
    5ece:	9a 8d 5b 6c 5f       	call   0x5f6c:0x5b8d
    5ed3:	8d be fc fd          	lea    di,[bp-0x204]
    5ed7:	16                   	push   ss
    5ed8:	57                   	push   di
    5ed9:	8d be 00 ff          	lea    di,[bp-0x100]
    5edd:	16                   	push   ss
    5ede:	57                   	push   di
    5edf:	9a cd 17 ec 5e       	call   0x5eec:0x17cd
    5ee4:	bf 85 5e             	mov    di,0x5e85
    5ee7:	0e                   	push   cs
    5ee8:	57                   	push   di
    5ee9:	9a 4c 18 06 5f       	call   0x5f06:0x184c
    5eee:	8d be fc fc          	lea    di,[bp-0x304]
    5ef2:	16                   	push   ss
    5ef3:	57                   	push   di
    5ef4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ef7:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    5efc:	06                   	push   es
    5efd:	57                   	push   di
    5efe:	9a 53 1d 9c 5f       	call   0x5f9c:0x1d53
    5f03:	9a 4c 18 14 5f       	call   0x5f14:0x184c
    5f08:	8d be 00 ff          	lea    di,[bp-0x100]
    5f0c:	16                   	push   ss
    5f0d:	57                   	push   di
    5f0e:	68 ff 00             	push   0xff
    5f11:	9a e7 17 7d 5f       	call   0x5f7d:0x17e7
    5f16:	8d be 00 ff          	lea    di,[bp-0x100]
    5f1a:	16                   	push   ss
    5f1b:	57                   	push   di
    5f1c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5f20:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5f25:	06                   	push   es
    5f26:	57                   	push   di
    5f27:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f2a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5f2e:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    5f32:	75 17                	jne    0x5f4b
    5f34:	bf 87 5e             	mov    di,0x5e87
    5f37:	0e                   	push   cs
    5f38:	57                   	push   di
    5f39:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5f3d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5f42:	06                   	push   es
    5f43:	57                   	push   di
    5f44:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f47:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5f4b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5f50:	8d be 00 ff          	lea    di,[bp-0x100]
    5f54:	16                   	push   ss
    5f55:	57                   	push   di
    5f56:	68 ff 00             	push   0xff
    5f59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f5c:	26 ff b5 b6 01       	push   WORD PTR es:[di+0x1b6]
    5f61:	26 ff b5 b4 01       	push   WORD PTR es:[di+0x1b4]
    5f66:	6a 0a                	push   0xa
    5f68:	55                   	push   bp
    5f69:	9a 8d 5b cd 5f       	call   0x5fcd:0x5b8d
    5f6e:	8d be fc fd          	lea    di,[bp-0x204]
    5f72:	16                   	push   ss
    5f73:	57                   	push   di
    5f74:	8d be 00 ff          	lea    di,[bp-0x100]
    5f78:	16                   	push   ss
    5f79:	57                   	push   di
    5f7a:	9a cd 17 87 5f       	call   0x5f87:0x17cd
    5f7f:	bf 88 5e             	mov    di,0x5e88
    5f82:	0e                   	push   cs
    5f83:	57                   	push   di
    5f84:	9a 4c 18 a1 5f       	call   0x5fa1:0x184c
    5f89:	8d be fc fc          	lea    di,[bp-0x304]
    5f8d:	16                   	push   ss
    5f8e:	57                   	push   di
    5f8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f92:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    5f97:	06                   	push   es
    5f98:	57                   	push   di
    5f99:	9a 53 1d 1b 60       	call   0x601b:0x1d53
    5f9e:	9a 4c 18 af 5f       	call   0x5faf:0x184c
    5fa3:	8d be 00 ff          	lea    di,[bp-0x100]
    5fa7:	16                   	push   ss
    5fa8:	57                   	push   di
    5fa9:	68 ff 00             	push   0xff
    5fac:	9a e7 17 fc 5f       	call   0x5ffc:0x17e7
    5fb1:	8d be 00 ff          	lea    di,[bp-0x100]
    5fb5:	16                   	push   ss
    5fb6:	57                   	push   di
    5fb7:	68 ff 00             	push   0xff
    5fba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fbd:	26 ff b5 c6 01       	push   WORD PTR es:[di+0x1c6]
    5fc2:	26 ff b5 c4 01       	push   WORD PTR es:[di+0x1c4]
    5fc7:	6a 25                	push   0x25
    5fc9:	55                   	push   bp
    5fca:	9a 8d 5b eb 5f       	call   0x5feb:0x5b8d
    5fcf:	8d be 00 ff          	lea    di,[bp-0x100]
    5fd3:	16                   	push   ss
    5fd4:	57                   	push   di
    5fd5:	68 ff 00             	push   0xff
    5fd8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fdb:	26 ff b5 be 01       	push   WORD PTR es:[di+0x1be]
    5fe0:	26 ff b5 bc 01       	push   WORD PTR es:[di+0x1bc]
    5fe5:	6a 46                	push   0x46
    5fe7:	55                   	push   bp
    5fe8:	9a 8d 5b 88 60       	call   0x6088:0x5b8d
    5fed:	8d be fc fd          	lea    di,[bp-0x204]
    5ff1:	16                   	push   ss
    5ff2:	57                   	push   di
    5ff3:	8d be 00 ff          	lea    di,[bp-0x100]
    5ff7:	16                   	push   ss
    5ff8:	57                   	push   di
    5ff9:	9a cd 17 06 60       	call   0x6006:0x17cd
    5ffe:	bf 88 5e             	mov    di,0x5e88
    6001:	0e                   	push   cs
    6002:	57                   	push   di
    6003:	9a 4c 18 20 60       	call   0x6020:0x184c
    6008:	8d be fc fc          	lea    di,[bp-0x304]
    600c:	16                   	push   ss
    600d:	57                   	push   di
    600e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6011:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    6016:	06                   	push   es
    6017:	57                   	push   di
    6018:	9a 53 1d ff ff       	call   0xffff:0x1d53
    601d:	9a 4c 18 2e 60       	call   0x602e:0x184c
    6022:	8d be 00 ff          	lea    di,[bp-0x100]
    6026:	16                   	push   ss
    6027:	57                   	push   di
    6028:	68 ff 00             	push   0xff
    602b:	9a e7 17 99 60       	call   0x6099:0x17e7
    6030:	8d be 00 ff          	lea    di,[bp-0x100]
    6034:	16                   	push   ss
    6035:	57                   	push   di
    6036:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    603a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    603f:	06                   	push   es
    6040:	57                   	push   di
    6041:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6044:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6048:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    604c:	75 17                	jne    0x6065
    604e:	bf 87 5e             	mov    di,0x5e87
    6051:	0e                   	push   cs
    6052:	57                   	push   di
    6053:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6057:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    605c:	06                   	push   es
    605d:	57                   	push   di
    605e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6061:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6065:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    606a:	8d be 00 ff          	lea    di,[bp-0x100]
    606e:	16                   	push   ss
    606f:	57                   	push   di
    6070:	68 ff 00             	push   0xff
    6073:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6076:	26 ff b5 e2 04       	push   WORD PTR es:[di+0x4e2]
    607b:	26 ff b5 e0 04       	push   WORD PTR es:[di+0x4e0]
    6080:	ff 36 40 02          	push   WORD PTR ds:0x240
    6084:	55                   	push   bp
    6085:	9a 8d 5b d1 60       	call   0x60d1:0x5b8d
    608a:	8d be fc fd          	lea    di,[bp-0x204]
    608e:	16                   	push   ss
    608f:	57                   	push   di
    6090:	8d be 00 ff          	lea    di,[bp-0x100]
    6094:	16                   	push   ss
    6095:	57                   	push   di
    6096:	9a cd 17 a3 60       	call   0x60a3:0x17cd
    609b:	bf 85 5e             	mov    di,0x5e85
    609e:	0e                   	push   cs
    609f:	57                   	push   di
    60a0:	9a 4c 18 b1 60       	call   0x60b1:0x184c
    60a5:	8d be 00 ff          	lea    di,[bp-0x100]
    60a9:	16                   	push   ss
    60aa:	57                   	push   di
    60ab:	68 ff 00             	push   0xff
    60ae:	9a e7 17 46 61       	call   0x6146:0x17e7
    60b3:	8d be 00 ff          	lea    di,[bp-0x100]
    60b7:	16                   	push   ss
    60b8:	57                   	push   di
    60b9:	68 ff 00             	push   0xff
    60bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60bf:	26 ff b5 06 05       	push   WORD PTR es:[di+0x506]
    60c4:	26 ff b5 04 05       	push   WORD PTR es:[di+0x504]
    60c9:	ff 36 46 02          	push   WORD PTR ds:0x246
    60cd:	55                   	push   bp
    60ce:	9a 8d 5b f1 60       	call   0x60f1:0x5b8d
    60d3:	8d be 00 ff          	lea    di,[bp-0x100]
    60d7:	16                   	push   ss
    60d8:	57                   	push   di
    60d9:	68 ff 00             	push   0xff
    60dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60df:	26 ff b5 0a 05       	push   WORD PTR es:[di+0x50a]
    60e4:	26 ff b5 08 05       	push   WORD PTR es:[di+0x508]
    60e9:	ff 36 48 02          	push   WORD PTR ds:0x248
    60ed:	55                   	push   bp
    60ee:	9a 8d 5b 35 61       	call   0x6135:0x5b8d
    60f3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    60f8:	76 18                	jbe    0x6112
    60fa:	8d be 00 ff          	lea    di,[bp-0x100]
    60fe:	16                   	push   ss
    60ff:	57                   	push   di
    6100:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6104:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6109:	06                   	push   es
    610a:	57                   	push   di
    610b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    610e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6112:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6117:	8d be 00 ff          	lea    di,[bp-0x100]
    611b:	16                   	push   ss
    611c:	57                   	push   di
    611d:	68 ff 00             	push   0xff
    6120:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6123:	26 ff b5 0e 05       	push   WORD PTR es:[di+0x50e]
    6128:	26 ff b5 0c 05       	push   WORD PTR es:[di+0x50c]
    612d:	ff 36 42 02          	push   WORD PTR ds:0x242
    6131:	55                   	push   bp
    6132:	9a 8d 5b 7e 61       	call   0x617e:0x5b8d
    6137:	8d be fc fd          	lea    di,[bp-0x204]
    613b:	16                   	push   ss
    613c:	57                   	push   di
    613d:	8d be 00 ff          	lea    di,[bp-0x100]
    6141:	16                   	push   ss
    6142:	57                   	push   di
    6143:	9a cd 17 50 61       	call   0x6150:0x17cd
    6148:	bf 85 5e             	mov    di,0x5e85
    614b:	0e                   	push   cs
    614c:	57                   	push   di
    614d:	9a 4c 18 5e 61       	call   0x615e:0x184c
    6152:	8d be 00 ff          	lea    di,[bp-0x100]
    6156:	16                   	push   ss
    6157:	57                   	push   di
    6158:	68 ff 00             	push   0xff
    615b:	9a e7 17 f3 61       	call   0x61f3:0x17e7
    6160:	8d be 00 ff          	lea    di,[bp-0x100]
    6164:	16                   	push   ss
    6165:	57                   	push   di
    6166:	68 ff 00             	push   0xff
    6169:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    616c:	26 ff b5 e6 04       	push   WORD PTR es:[di+0x4e6]
    6171:	26 ff b5 e4 04       	push   WORD PTR es:[di+0x4e4]
    6176:	ff 36 46 02          	push   WORD PTR ds:0x246
    617a:	55                   	push   bp
    617b:	9a 8d 5b 9e 61       	call   0x619e:0x5b8d
    6180:	8d be 00 ff          	lea    di,[bp-0x100]
    6184:	16                   	push   ss
    6185:	57                   	push   di
    6186:	68 ff 00             	push   0xff
    6189:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    618c:	26 ff b5 f6 04       	push   WORD PTR es:[di+0x4f6]
    6191:	26 ff b5 f4 04       	push   WORD PTR es:[di+0x4f4]
    6196:	ff 36 48 02          	push   WORD PTR ds:0x248
    619a:	55                   	push   bp
    619b:	9a 8d 5b e2 61       	call   0x61e2:0x5b8d
    61a0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    61a5:	76 18                	jbe    0x61bf
    61a7:	8d be 00 ff          	lea    di,[bp-0x100]
    61ab:	16                   	push   ss
    61ac:	57                   	push   di
    61ad:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    61b1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    61b6:	06                   	push   es
    61b7:	57                   	push   di
    61b8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    61bb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    61bf:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    61c4:	8d be 00 ff          	lea    di,[bp-0x100]
    61c8:	16                   	push   ss
    61c9:	57                   	push   di
    61ca:	68 ff 00             	push   0xff
    61cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61d0:	26 ff b5 12 05       	push   WORD PTR es:[di+0x512]
    61d5:	26 ff b5 10 05       	push   WORD PTR es:[di+0x510]
    61da:	ff 36 42 02          	push   WORD PTR ds:0x242
    61de:	55                   	push   bp
    61df:	9a 8d 5b 2b 62       	call   0x622b:0x5b8d
    61e4:	8d be fc fd          	lea    di,[bp-0x204]
    61e8:	16                   	push   ss
    61e9:	57                   	push   di
    61ea:	8d be 00 ff          	lea    di,[bp-0x100]
    61ee:	16                   	push   ss
    61ef:	57                   	push   di
    61f0:	9a cd 17 fd 61       	call   0x61fd:0x17cd
    61f5:	bf 85 5e             	mov    di,0x5e85
    61f8:	0e                   	push   cs
    61f9:	57                   	push   di
    61fa:	9a 4c 18 0b 62       	call   0x620b:0x184c
    61ff:	8d be 00 ff          	lea    di,[bp-0x100]
    6203:	16                   	push   ss
    6204:	57                   	push   di
    6205:	68 ff 00             	push   0xff
    6208:	9a e7 17 a0 62       	call   0x62a0:0x17e7
    620d:	8d be 00 ff          	lea    di,[bp-0x100]
    6211:	16                   	push   ss
    6212:	57                   	push   di
    6213:	68 ff 00             	push   0xff
    6216:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6219:	26 ff b5 ea 04       	push   WORD PTR es:[di+0x4ea]
    621e:	26 ff b5 e8 04       	push   WORD PTR es:[di+0x4e8]
    6223:	ff 36 46 02          	push   WORD PTR ds:0x246
    6227:	55                   	push   bp
    6228:	9a 8d 5b 4b 62       	call   0x624b:0x5b8d
    622d:	8d be 00 ff          	lea    di,[bp-0x100]
    6231:	16                   	push   ss
    6232:	57                   	push   di
    6233:	68 ff 00             	push   0xff
    6236:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6239:	26 ff b5 fa 04       	push   WORD PTR es:[di+0x4fa]
    623e:	26 ff b5 f8 04       	push   WORD PTR es:[di+0x4f8]
    6243:	ff 36 48 02          	push   WORD PTR ds:0x248
    6247:	55                   	push   bp
    6248:	9a 8d 5b 8f 62       	call   0x628f:0x5b8d
    624d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6252:	76 18                	jbe    0x626c
    6254:	8d be 00 ff          	lea    di,[bp-0x100]
    6258:	16                   	push   ss
    6259:	57                   	push   di
    625a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    625e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6263:	06                   	push   es
    6264:	57                   	push   di
    6265:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6268:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    626c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6271:	8d be 00 ff          	lea    di,[bp-0x100]
    6275:	16                   	push   ss
    6276:	57                   	push   di
    6277:	68 ff 00             	push   0xff
    627a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    627d:	26 ff b5 36 05       	push   WORD PTR es:[di+0x536]
    6282:	26 ff b5 34 05       	push   WORD PTR es:[di+0x534]
    6287:	ff 36 42 02          	push   WORD PTR ds:0x242
    628b:	55                   	push   bp
    628c:	9a 8d 5b d8 62       	call   0x62d8:0x5b8d
    6291:	8d be fc fd          	lea    di,[bp-0x204]
    6295:	16                   	push   ss
    6296:	57                   	push   di
    6297:	8d be 00 ff          	lea    di,[bp-0x100]
    629b:	16                   	push   ss
    629c:	57                   	push   di
    629d:	9a cd 17 aa 62       	call   0x62aa:0x17cd
    62a2:	bf 85 5e             	mov    di,0x5e85
    62a5:	0e                   	push   cs
    62a6:	57                   	push   di
    62a7:	9a 4c 18 b8 62       	call   0x62b8:0x184c
    62ac:	8d be 00 ff          	lea    di,[bp-0x100]
    62b0:	16                   	push   ss
    62b1:	57                   	push   di
    62b2:	68 ff 00             	push   0xff
    62b5:	9a e7 17 6f 65       	call   0x656f:0x17e7
    62ba:	8d be 00 ff          	lea    di,[bp-0x100]
    62be:	16                   	push   ss
    62bf:	57                   	push   di
    62c0:	68 ff 00             	push   0xff
    62c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62c6:	26 ff b5 3a 05       	push   WORD PTR es:[di+0x53a]
    62cb:	26 ff b5 38 05       	push   WORD PTR es:[di+0x538]
    62d0:	ff 36 46 02          	push   WORD PTR ds:0x246
    62d4:	55                   	push   bp
    62d5:	9a 8d 5b f8 62       	call   0x62f8:0x5b8d
    62da:	8d be 00 ff          	lea    di,[bp-0x100]
    62de:	16                   	push   ss
    62df:	57                   	push   di
    62e0:	68 ff 00             	push   0xff
    62e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62e6:	26 ff b5 3e 05       	push   WORD PTR es:[di+0x53e]
    62eb:	26 ff b5 3c 05       	push   WORD PTR es:[di+0x53c]
    62f0:	ff 36 48 02          	push   WORD PTR ds:0x248
    62f4:	55                   	push   bp
    62f5:	9a 8d 5b 4e 63       	call   0x634e:0x5b8d
    62fa:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    62ff:	76 18                	jbe    0x6319
    6301:	8d be 00 ff          	lea    di,[bp-0x100]
    6305:	16                   	push   ss
    6306:	57                   	push   di
    6307:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    630b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6310:	06                   	push   es
    6311:	57                   	push   di
    6312:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6315:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6319:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    631e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6321:	26 c4 bd 48 05       	les    di,DWORD PTR es:[di+0x548]
    6326:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    632b:	75 03                	jne    0x6330
    632d:	e9 80 00             	jmp    0x63b0
    6330:	8d be 00 ff          	lea    di,[bp-0x100]
    6334:	16                   	push   ss
    6335:	57                   	push   di
    6336:	68 ff 00             	push   0xff
    6339:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    633c:	26 ff b5 2a 05       	push   WORD PTR es:[di+0x52a]
    6341:	26 ff b5 28 05       	push   WORD PTR es:[di+0x528]
    6346:	ff 36 42 02          	push   WORD PTR ds:0x242
    634a:	55                   	push   bp
    634b:	9a 8d 5b 6e 63       	call   0x636e:0x5b8d
    6350:	8d be 00 ff          	lea    di,[bp-0x100]
    6354:	16                   	push   ss
    6355:	57                   	push   di
    6356:	68 ff 00             	push   0xff
    6359:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    635c:	26 ff b5 4a 05       	push   WORD PTR es:[di+0x54a]
    6361:	26 ff b5 48 05       	push   WORD PTR es:[di+0x548]
    6366:	ff 36 44 02          	push   WORD PTR ds:0x244
    636a:	55                   	push   bp
    636b:	9a 8d 5b 8e 63       	call   0x638e:0x5b8d
    6370:	8d be 00 ff          	lea    di,[bp-0x100]
    6374:	16                   	push   ss
    6375:	57                   	push   di
    6376:	68 ff 00             	push   0xff
    6379:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    637c:	26 ff b5 1a 05       	push   WORD PTR es:[di+0x51a]
    6381:	26 ff b5 18 05       	push   WORD PTR es:[di+0x518]
    6386:	ff 36 46 02          	push   WORD PTR ds:0x246
    638a:	55                   	push   bp
    638b:	9a 8d 5b ae 63       	call   0x63ae:0x5b8d
    6390:	8d be 00 ff          	lea    di,[bp-0x100]
    6394:	16                   	push   ss
    6395:	57                   	push   di
    6396:	68 ff 00             	push   0xff
    6399:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    639c:	26 ff b5 1e 05       	push   WORD PTR es:[di+0x51e]
    63a1:	26 ff b5 1c 05       	push   WORD PTR es:[di+0x51c]
    63a6:	ff 36 48 02          	push   WORD PTR ds:0x248
    63aa:	55                   	push   bp
    63ab:	9a 8d 5b 04 64       	call   0x6404:0x5b8d
    63b0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    63b5:	76 18                	jbe    0x63cf
    63b7:	8d be 00 ff          	lea    di,[bp-0x100]
    63bb:	16                   	push   ss
    63bc:	57                   	push   di
    63bd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    63c1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    63c6:	06                   	push   es
    63c7:	57                   	push   di
    63c8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    63cb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    63cf:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    63d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63d7:	26 c4 bd 44 05       	les    di,DWORD PTR es:[di+0x544]
    63dc:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    63e1:	75 03                	jne    0x63e6
    63e3:	e9 80 00             	jmp    0x6466
    63e6:	8d be 00 ff          	lea    di,[bp-0x100]
    63ea:	16                   	push   ss
    63eb:	57                   	push   di
    63ec:	68 ff 00             	push   0xff
    63ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63f2:	26 ff b5 2a 05       	push   WORD PTR es:[di+0x52a]
    63f7:	26 ff b5 28 05       	push   WORD PTR es:[di+0x528]
    63fc:	ff 36 42 02          	push   WORD PTR ds:0x242
    6400:	55                   	push   bp
    6401:	9a 8d 5b 24 64       	call   0x6424:0x5b8d
    6406:	8d be 00 ff          	lea    di,[bp-0x100]
    640a:	16                   	push   ss
    640b:	57                   	push   di
    640c:	68 ff 00             	push   0xff
    640f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6412:	26 ff b5 46 05       	push   WORD PTR es:[di+0x546]
    6417:	26 ff b5 44 05       	push   WORD PTR es:[di+0x544]
    641c:	ff 36 44 02          	push   WORD PTR ds:0x244
    6420:	55                   	push   bp
    6421:	9a 8d 5b 44 64       	call   0x6444:0x5b8d
    6426:	8d be 00 ff          	lea    di,[bp-0x100]
    642a:	16                   	push   ss
    642b:	57                   	push   di
    642c:	68 ff 00             	push   0xff
    642f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6432:	26 ff b5 ee 04       	push   WORD PTR es:[di+0x4ee]
    6437:	26 ff b5 ec 04       	push   WORD PTR es:[di+0x4ec]
    643c:	ff 36 46 02          	push   WORD PTR ds:0x246
    6440:	55                   	push   bp
    6441:	9a 8d 5b 64 64       	call   0x6464:0x5b8d
    6446:	8d be 00 ff          	lea    di,[bp-0x100]
    644a:	16                   	push   ss
    644b:	57                   	push   di
    644c:	68 ff 00             	push   0xff
    644f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6452:	26 ff b5 fe 04       	push   WORD PTR es:[di+0x4fe]
    6457:	26 ff b5 fc 04       	push   WORD PTR es:[di+0x4fc]
    645c:	ff 36 48 02          	push   WORD PTR ds:0x248
    6460:	55                   	push   bp
    6461:	9a 8d 5b ba 64       	call   0x64ba:0x5b8d
    6466:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    646b:	76 18                	jbe    0x6485
    646d:	8d be 00 ff          	lea    di,[bp-0x100]
    6471:	16                   	push   ss
    6472:	57                   	push   di
    6473:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6477:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    647c:	06                   	push   es
    647d:	57                   	push   di
    647e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6481:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6485:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    648a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    648d:	26 c4 bd 40 05       	les    di,DWORD PTR es:[di+0x540]
    6492:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    6497:	75 03                	jne    0x649c
    6499:	e9 80 00             	jmp    0x651c
    649c:	8d be 00 ff          	lea    di,[bp-0x100]
    64a0:	16                   	push   ss
    64a1:	57                   	push   di
    64a2:	68 ff 00             	push   0xff
    64a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64a8:	26 ff b5 2a 05       	push   WORD PTR es:[di+0x52a]
    64ad:	26 ff b5 28 05       	push   WORD PTR es:[di+0x528]
    64b2:	ff 36 42 02          	push   WORD PTR ds:0x242
    64b6:	55                   	push   bp
    64b7:	9a 8d 5b da 64       	call   0x64da:0x5b8d
    64bc:	8d be 00 ff          	lea    di,[bp-0x100]
    64c0:	16                   	push   ss
    64c1:	57                   	push   di
    64c2:	68 ff 00             	push   0xff
    64c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64c8:	26 ff b5 42 05       	push   WORD PTR es:[di+0x542]
    64cd:	26 ff b5 40 05       	push   WORD PTR es:[di+0x540]
    64d2:	ff 36 44 02          	push   WORD PTR ds:0x244
    64d6:	55                   	push   bp
    64d7:	9a 8d 5b fa 64       	call   0x64fa:0x5b8d
    64dc:	8d be 00 ff          	lea    di,[bp-0x100]
    64e0:	16                   	push   ss
    64e1:	57                   	push   di
    64e2:	68 ff 00             	push   0xff
    64e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64e8:	26 ff b5 22 05       	push   WORD PTR es:[di+0x522]
    64ed:	26 ff b5 20 05       	push   WORD PTR es:[di+0x520]
    64f2:	ff 36 46 02          	push   WORD PTR ds:0x246
    64f6:	55                   	push   bp
    64f7:	9a 8d 5b 1a 65       	call   0x651a:0x5b8d
    64fc:	8d be 00 ff          	lea    di,[bp-0x100]
    6500:	16                   	push   ss
    6501:	57                   	push   di
    6502:	68 ff 00             	push   0xff
    6505:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6508:	26 ff b5 26 05       	push   WORD PTR es:[di+0x526]
    650d:	26 ff b5 24 05       	push   WORD PTR es:[di+0x524]
    6512:	ff 36 48 02          	push   WORD PTR ds:0x248
    6516:	55                   	push   bp
    6517:	9a 8d 5b 5e 65       	call   0x655e:0x5b8d
    651c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6521:	76 18                	jbe    0x653b
    6523:	8d be 00 ff          	lea    di,[bp-0x100]
    6527:	16                   	push   ss
    6528:	57                   	push   di
    6529:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    652d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6532:	06                   	push   es
    6533:	57                   	push   di
    6534:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6537:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    653b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6540:	8d be 00 ff          	lea    di,[bp-0x100]
    6544:	16                   	push   ss
    6545:	57                   	push   di
    6546:	68 ff 00             	push   0xff
    6549:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    654c:	26 ff b5 16 05       	push   WORD PTR es:[di+0x516]
    6551:	26 ff b5 14 05       	push   WORD PTR es:[di+0x514]
    6556:	ff 36 42 02          	push   WORD PTR ds:0x242
    655a:	55                   	push   bp
    655b:	9a 8d 5b a7 65       	call   0x65a7:0x5b8d
    6560:	8d be fc fd          	lea    di,[bp-0x204]
    6564:	16                   	push   ss
    6565:	57                   	push   di
    6566:	8d be 00 ff          	lea    di,[bp-0x100]
    656a:	16                   	push   ss
    656b:	57                   	push   di
    656c:	9a cd 17 79 65       	call   0x6579:0x17cd
    6571:	bf 85 5e             	mov    di,0x5e85
    6574:	0e                   	push   cs
    6575:	57                   	push   di
    6576:	9a 4c 18 87 65       	call   0x6587:0x184c
    657b:	8d be 00 ff          	lea    di,[bp-0x100]
    657f:	16                   	push   ss
    6580:	57                   	push   di
    6581:	68 ff 00             	push   0xff
    6584:	9a e7 17 a5 67       	call   0x67a5:0x17e7
    6589:	8d be 00 ff          	lea    di,[bp-0x100]
    658d:	16                   	push   ss
    658e:	57                   	push   di
    658f:	68 ff 00             	push   0xff
    6592:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6595:	26 ff b5 f2 04       	push   WORD PTR es:[di+0x4f2]
    659a:	26 ff b5 f0 04       	push   WORD PTR es:[di+0x4f0]
    659f:	ff 36 46 02          	push   WORD PTR ds:0x246
    65a3:	55                   	push   bp
    65a4:	9a 8d 5b c7 65       	call   0x65c7:0x5b8d
    65a9:	8d be 00 ff          	lea    di,[bp-0x100]
    65ad:	16                   	push   ss
    65ae:	57                   	push   di
    65af:	68 ff 00             	push   0xff
    65b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65b5:	26 ff b5 02 05       	push   WORD PTR es:[di+0x502]
    65ba:	26 ff b5 00 05       	push   WORD PTR es:[di+0x500]
    65bf:	ff 36 48 02          	push   WORD PTR ds:0x248
    65c3:	55                   	push   bp
    65c4:	9a 8d 5b 1d 66       	call   0x661d:0x5b8d
    65c9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    65ce:	76 18                	jbe    0x65e8
    65d0:	8d be 00 ff          	lea    di,[bp-0x100]
    65d4:	16                   	push   ss
    65d5:	57                   	push   di
    65d6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    65da:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    65df:	06                   	push   es
    65e0:	57                   	push   di
    65e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    65e4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    65e8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    65ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65f0:	26 c4 bd e4 06       	les    di,DWORD PTR es:[di+0x6e4]
    65f5:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    65fa:	75 03                	jne    0x65ff
    65fc:	e9 80 00             	jmp    0x667f
    65ff:	8d be 00 ff          	lea    di,[bp-0x100]
    6603:	16                   	push   ss
    6604:	57                   	push   di
    6605:	68 ff 00             	push   0xff
    6608:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    660b:	26 ff b5 e6 06       	push   WORD PTR es:[di+0x6e6]
    6610:	26 ff b5 e4 06       	push   WORD PTR es:[di+0x6e4]
    6615:	ff 36 42 02          	push   WORD PTR ds:0x242
    6619:	55                   	push   bp
    661a:	9a 8d 5b 3d 66       	call   0x663d:0x5b8d
    661f:	8d be 00 ff          	lea    di,[bp-0x100]
    6623:	16                   	push   ss
    6624:	57                   	push   di
    6625:	68 ff 00             	push   0xff
    6628:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    662b:	26 ff b5 ee 06       	push   WORD PTR es:[di+0x6ee]
    6630:	26 ff b5 ec 06       	push   WORD PTR es:[di+0x6ec]
    6635:	ff 36 44 02          	push   WORD PTR ds:0x244
    6639:	55                   	push   bp
    663a:	9a 8d 5b 5d 66       	call   0x665d:0x5b8d
    663f:	8d be 00 ff          	lea    di,[bp-0x100]
    6643:	16                   	push   ss
    6644:	57                   	push   di
    6645:	68 ff 00             	push   0xff
    6648:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    664b:	26 ff b5 f6 06       	push   WORD PTR es:[di+0x6f6]
    6650:	26 ff b5 f4 06       	push   WORD PTR es:[di+0x6f4]
    6655:	ff 36 46 02          	push   WORD PTR ds:0x246
    6659:	55                   	push   bp
    665a:	9a 8d 5b 7d 66       	call   0x667d:0x5b8d
    665f:	8d be 00 ff          	lea    di,[bp-0x100]
    6663:	16                   	push   ss
    6664:	57                   	push   di
    6665:	68 ff 00             	push   0xff
    6668:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    666b:	26 ff b5 fa 06       	push   WORD PTR es:[di+0x6fa]
    6670:	26 ff b5 f8 06       	push   WORD PTR es:[di+0x6f8]
    6675:	ff 36 48 02          	push   WORD PTR ds:0x248
    6679:	55                   	push   bp
    667a:	9a 8d 5b d3 66       	call   0x66d3:0x5b8d
    667f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6684:	76 18                	jbe    0x669e
    6686:	8d be 00 ff          	lea    di,[bp-0x100]
    668a:	16                   	push   ss
    668b:	57                   	push   di
    668c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6690:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6695:	06                   	push   es
    6696:	57                   	push   di
    6697:	26 c4 3d             	les    di,DWORD PTR es:[di]
    669a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    669e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    66a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66a6:	26 c4 bd e4 06       	les    di,DWORD PTR es:[di+0x6e4]
    66ab:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    66b0:	75 03                	jne    0x66b5
    66b2:	e9 80 00             	jmp    0x6735
    66b5:	8d be 00 ff          	lea    di,[bp-0x100]
    66b9:	16                   	push   ss
    66ba:	57                   	push   di
    66bb:	68 ff 00             	push   0xff
    66be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66c1:	26 ff b5 e6 06       	push   WORD PTR es:[di+0x6e6]
    66c6:	26 ff b5 e4 06       	push   WORD PTR es:[di+0x6e4]
    66cb:	ff 36 42 02          	push   WORD PTR ds:0x242
    66cf:	55                   	push   bp
    66d0:	9a 8d 5b f3 66       	call   0x66f3:0x5b8d
    66d5:	8d be 00 ff          	lea    di,[bp-0x100]
    66d9:	16                   	push   ss
    66da:	57                   	push   di
    66db:	68 ff 00             	push   0xff
    66de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66e1:	26 ff b5 f2 06       	push   WORD PTR es:[di+0x6f2]
    66e6:	26 ff b5 f0 06       	push   WORD PTR es:[di+0x6f0]
    66eb:	ff 36 44 02          	push   WORD PTR ds:0x244
    66ef:	55                   	push   bp
    66f0:	9a 8d 5b 13 67       	call   0x6713:0x5b8d
    66f5:	8d be 00 ff          	lea    di,[bp-0x100]
    66f9:	16                   	push   ss
    66fa:	57                   	push   di
    66fb:	68 ff 00             	push   0xff
    66fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6701:	26 ff b5 fe 06       	push   WORD PTR es:[di+0x6fe]
    6706:	26 ff b5 fc 06       	push   WORD PTR es:[di+0x6fc]
    670b:	ff 36 46 02          	push   WORD PTR ds:0x246
    670f:	55                   	push   bp
    6710:	9a 8d 5b 33 67       	call   0x6733:0x5b8d
    6715:	8d be 00 ff          	lea    di,[bp-0x100]
    6719:	16                   	push   ss
    671a:	57                   	push   di
    671b:	68 ff 00             	push   0xff
    671e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6721:	26 ff b5 02 07       	push   WORD PTR es:[di+0x702]
    6726:	26 ff b5 00 07       	push   WORD PTR es:[di+0x700]
    672b:	ff 36 48 02          	push   WORD PTR ds:0x248
    672f:	55                   	push   bp
    6730:	9a 8d 5b 94 67       	call   0x6794:0x5b8d
    6735:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    673a:	76 18                	jbe    0x6754
    673c:	8d be 00 ff          	lea    di,[bp-0x100]
    6740:	16                   	push   ss
    6741:	57                   	push   di
    6742:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6746:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    674b:	06                   	push   es
    674c:	57                   	push   di
    674d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6750:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6754:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    6758:	75 17                	jne    0x6771
    675a:	bf 87 5e             	mov    di,0x5e87
    675d:	0e                   	push   cs
    675e:	57                   	push   di
    675f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6763:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6768:	06                   	push   es
    6769:	57                   	push   di
    676a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    676d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6771:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6776:	8d be 00 ff          	lea    di,[bp-0x100]
    677a:	16                   	push   ss
    677b:	57                   	push   di
    677c:	68 ff 00             	push   0xff
    677f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6782:	26 ff b5 52 05       	push   WORD PTR es:[di+0x552]
    6787:	26 ff b5 50 05       	push   WORD PTR es:[di+0x550]
    678c:	ff 36 40 02          	push   WORD PTR ds:0x240
    6790:	55                   	push   bp
    6791:	9a 8d 5b dd 67       	call   0x67dd:0x5b8d
    6796:	8d be fc fd          	lea    di,[bp-0x204]
    679a:	16                   	push   ss
    679b:	57                   	push   di
    679c:	8d be 00 ff          	lea    di,[bp-0x100]
    67a0:	16                   	push   ss
    67a1:	57                   	push   di
    67a2:	9a cd 17 af 67       	call   0x67af:0x17cd
    67a7:	bf 85 5e             	mov    di,0x5e85
    67aa:	0e                   	push   cs
    67ab:	57                   	push   di
    67ac:	9a 4c 18 bd 67       	call   0x67bd:0x184c
    67b1:	8d be 00 ff          	lea    di,[bp-0x100]
    67b5:	16                   	push   ss
    67b6:	57                   	push   di
    67b7:	68 ff 00             	push   0xff
    67ba:	9a e7 17 9a 69       	call   0x699a:0x17e7
    67bf:	8d be 00 ff          	lea    di,[bp-0x100]
    67c3:	16                   	push   ss
    67c4:	57                   	push   di
    67c5:	68 ff 00             	push   0xff
    67c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67cb:	26 ff b5 72 05       	push   WORD PTR es:[di+0x572]
    67d0:	26 ff b5 70 05       	push   WORD PTR es:[di+0x570]
    67d5:	ff 36 46 02          	push   WORD PTR ds:0x246
    67d9:	55                   	push   bp
    67da:	9a 8d 5b fd 67       	call   0x67fd:0x5b8d
    67df:	8d be 00 ff          	lea    di,[bp-0x100]
    67e3:	16                   	push   ss
    67e4:	57                   	push   di
    67e5:	68 ff 00             	push   0xff
    67e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67eb:	26 ff b5 b2 05       	push   WORD PTR es:[di+0x5b2]
    67f0:	26 ff b5 b0 05       	push   WORD PTR es:[di+0x5b0]
    67f5:	ff 36 48 02          	push   WORD PTR ds:0x248
    67f9:	55                   	push   bp
    67fa:	9a 8d 5b 41 68       	call   0x6841:0x5b8d
    67ff:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6804:	76 18                	jbe    0x681e
    6806:	8d be 00 ff          	lea    di,[bp-0x100]
    680a:	16                   	push   ss
    680b:	57                   	push   di
    680c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6810:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6815:	06                   	push   es
    6816:	57                   	push   di
    6817:	26 c4 3d             	les    di,DWORD PTR es:[di]
    681a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    681e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6823:	8d be 00 ff          	lea    di,[bp-0x100]
    6827:	16                   	push   ss
    6828:	57                   	push   di
    6829:	68 ff 00             	push   0xff
    682c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    682f:	26 ff b5 76 05       	push   WORD PTR es:[di+0x576]
    6834:	26 ff b5 74 05       	push   WORD PTR es:[di+0x574]
    6839:	ff 36 42 02          	push   WORD PTR ds:0x242
    683d:	55                   	push   bp
    683e:	9a 8d 5b 61 68       	call   0x6861:0x5b8d
    6843:	8d be 00 ff          	lea    di,[bp-0x100]
    6847:	16                   	push   ss
    6848:	57                   	push   di
    6849:	68 ff 00             	push   0xff
    684c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    684f:	26 ff b5 7a 05       	push   WORD PTR es:[di+0x57a]
    6854:	26 ff b5 78 05       	push   WORD PTR es:[di+0x578]
    6859:	ff 36 44 02          	push   WORD PTR ds:0x244
    685d:	55                   	push   bp
    685e:	9a 8d 5b 81 68       	call   0x6881:0x5b8d
    6863:	8d be 00 ff          	lea    di,[bp-0x100]
    6867:	16                   	push   ss
    6868:	57                   	push   di
    6869:	68 ff 00             	push   0xff
    686c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    686f:	26 ff b5 56 05       	push   WORD PTR es:[di+0x556]
    6874:	26 ff b5 54 05       	push   WORD PTR es:[di+0x554]
    6879:	ff 36 46 02          	push   WORD PTR ds:0x246
    687d:	55                   	push   bp
    687e:	9a 8d 5b a1 68       	call   0x68a1:0x5b8d
    6883:	8d be 00 ff          	lea    di,[bp-0x100]
    6887:	16                   	push   ss
    6888:	57                   	push   di
    6889:	68 ff 00             	push   0xff
    688c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    688f:	26 ff b5 b6 05       	push   WORD PTR es:[di+0x5b6]
    6894:	26 ff b5 b4 05       	push   WORD PTR es:[di+0x5b4]
    6899:	ff 36 48 02          	push   WORD PTR ds:0x248
    689d:	55                   	push   bp
    689e:	9a 8d 5b e5 68       	call   0x68e5:0x5b8d
    68a3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    68a8:	76 18                	jbe    0x68c2
    68aa:	8d be 00 ff          	lea    di,[bp-0x100]
    68ae:	16                   	push   ss
    68af:	57                   	push   di
    68b0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    68b4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    68b9:	06                   	push   es
    68ba:	57                   	push   di
    68bb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    68be:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    68c2:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    68c7:	8d be 00 ff          	lea    di,[bp-0x100]
    68cb:	16                   	push   ss
    68cc:	57                   	push   di
    68cd:	68 ff 00             	push   0xff
    68d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68d3:	26 ff b5 76 05       	push   WORD PTR es:[di+0x576]
    68d8:	26 ff b5 74 05       	push   WORD PTR es:[di+0x574]
    68dd:	ff 36 42 02          	push   WORD PTR ds:0x242
    68e1:	55                   	push   bp
    68e2:	9a 8d 5b 05 69       	call   0x6905:0x5b8d
    68e7:	8d be 00 ff          	lea    di,[bp-0x100]
    68eb:	16                   	push   ss
    68ec:	57                   	push   di
    68ed:	68 ff 00             	push   0xff
    68f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68f3:	26 ff b5 e2 05       	push   WORD PTR es:[di+0x5e2]
    68f8:	26 ff b5 e0 05       	push   WORD PTR es:[di+0x5e0]
    68fd:	ff 36 44 02          	push   WORD PTR ds:0x244
    6901:	55                   	push   bp
    6902:	9a 8d 5b 25 69       	call   0x6925:0x5b8d
    6907:	8d be 00 ff          	lea    di,[bp-0x100]
    690b:	16                   	push   ss
    690c:	57                   	push   di
    690d:	68 ff 00             	push   0xff
    6910:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6913:	26 ff b5 5a 05       	push   WORD PTR es:[di+0x55a]
    6918:	26 ff b5 58 05       	push   WORD PTR es:[di+0x558]
    691d:	ff 36 46 02          	push   WORD PTR ds:0x246
    6921:	55                   	push   bp
    6922:	9a 8d 5b 45 69       	call   0x6945:0x5b8d
    6927:	8d be 00 ff          	lea    di,[bp-0x100]
    692b:	16                   	push   ss
    692c:	57                   	push   di
    692d:	68 ff 00             	push   0xff
    6930:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6933:	26 ff b5 ba 05       	push   WORD PTR es:[di+0x5ba]
    6938:	26 ff b5 b8 05       	push   WORD PTR es:[di+0x5b8]
    693d:	ff 36 48 02          	push   WORD PTR ds:0x248
    6941:	55                   	push   bp
    6942:	9a 8d 5b 89 69       	call   0x6989:0x5b8d
    6947:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    694c:	76 18                	jbe    0x6966
    694e:	8d be 00 ff          	lea    di,[bp-0x100]
    6952:	16                   	push   ss
    6953:	57                   	push   di
    6954:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6958:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    695d:	06                   	push   es
    695e:	57                   	push   di
    695f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6962:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6966:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    696b:	8d be 00 ff          	lea    di,[bp-0x100]
    696f:	16                   	push   ss
    6970:	57                   	push   di
    6971:	68 ff 00             	push   0xff
    6974:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6977:	26 ff b5 96 05       	push   WORD PTR es:[di+0x596]
    697c:	26 ff b5 94 05       	push   WORD PTR es:[di+0x594]
    6981:	ff 36 42 02          	push   WORD PTR ds:0x242
    6985:	55                   	push   bp
    6986:	9a 8d 5b d2 69       	call   0x69d2:0x5b8d
    698b:	8d be fc fd          	lea    di,[bp-0x204]
    698f:	16                   	push   ss
    6990:	57                   	push   di
    6991:	8d be 00 ff          	lea    di,[bp-0x100]
    6995:	16                   	push   ss
    6996:	57                   	push   di
    6997:	9a cd 17 a4 69       	call   0x69a4:0x17cd
    699c:	bf 85 5e             	mov    di,0x5e85
    699f:	0e                   	push   cs
    69a0:	57                   	push   di
    69a1:	9a 4c 18 b2 69       	call   0x69b2:0x184c
    69a6:	8d be 00 ff          	lea    di,[bp-0x100]
    69aa:	16                   	push   ss
    69ab:	57                   	push   di
    69ac:	68 ff 00             	push   0xff
    69af:	9a e7 17 47 6a       	call   0x6a47:0x17e7
    69b4:	8d be 00 ff          	lea    di,[bp-0x100]
    69b8:	16                   	push   ss
    69b9:	57                   	push   di
    69ba:	68 ff 00             	push   0xff
    69bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69c0:	26 ff b5 9a 05       	push   WORD PTR es:[di+0x59a]
    69c5:	26 ff b5 98 05       	push   WORD PTR es:[di+0x598]
    69ca:	ff 36 46 02          	push   WORD PTR ds:0x246
    69ce:	55                   	push   bp
    69cf:	9a 8d 5b f2 69       	call   0x69f2:0x5b8d
    69d4:	8d be 00 ff          	lea    di,[bp-0x100]
    69d8:	16                   	push   ss
    69d9:	57                   	push   di
    69da:	68 ff 00             	push   0xff
    69dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69e0:	26 ff b5 be 05       	push   WORD PTR es:[di+0x5be]
    69e5:	26 ff b5 bc 05       	push   WORD PTR es:[di+0x5bc]
    69ea:	ff 36 48 02          	push   WORD PTR ds:0x248
    69ee:	55                   	push   bp
    69ef:	9a 8d 5b 36 6a       	call   0x6a36:0x5b8d
    69f4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    69f9:	76 18                	jbe    0x6a13
    69fb:	8d be 00 ff          	lea    di,[bp-0x100]
    69ff:	16                   	push   ss
    6a00:	57                   	push   di
    6a01:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6a05:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6a0a:	06                   	push   es
    6a0b:	57                   	push   di
    6a0c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a0f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6a13:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6a18:	8d be 00 ff          	lea    di,[bp-0x100]
    6a1c:	16                   	push   ss
    6a1d:	57                   	push   di
    6a1e:	68 ff 00             	push   0xff
    6a21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a24:	26 ff b5 82 05       	push   WORD PTR es:[di+0x582]
    6a29:	26 ff b5 80 05       	push   WORD PTR es:[di+0x580]
    6a2e:	ff 36 42 02          	push   WORD PTR ds:0x242
    6a32:	55                   	push   bp
    6a33:	9a 8d 5b 7f 6a       	call   0x6a7f:0x5b8d
    6a38:	8d be fc fd          	lea    di,[bp-0x204]
    6a3c:	16                   	push   ss
    6a3d:	57                   	push   di
    6a3e:	8d be 00 ff          	lea    di,[bp-0x100]
    6a42:	16                   	push   ss
    6a43:	57                   	push   di
    6a44:	9a cd 17 51 6a       	call   0x6a51:0x17cd
    6a49:	bf 85 5e             	mov    di,0x5e85
    6a4c:	0e                   	push   cs
    6a4d:	57                   	push   di
    6a4e:	9a 4c 18 5f 6a       	call   0x6a5f:0x184c
    6a53:	8d be 00 ff          	lea    di,[bp-0x100]
    6a57:	16                   	push   ss
    6a58:	57                   	push   di
    6a59:	68 ff 00             	push   0xff
    6a5c:	9a e7 17 f4 6a       	call   0x6af4:0x17e7
    6a61:	8d be 00 ff          	lea    di,[bp-0x100]
    6a65:	16                   	push   ss
    6a66:	57                   	push   di
    6a67:	68 ff 00             	push   0xff
    6a6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a6d:	26 ff b5 5e 05       	push   WORD PTR es:[di+0x55e]
    6a72:	26 ff b5 5c 05       	push   WORD PTR es:[di+0x55c]
    6a77:	ff 36 46 02          	push   WORD PTR ds:0x246
    6a7b:	55                   	push   bp
    6a7c:	9a 8d 5b 9f 6a       	call   0x6a9f:0x5b8d
    6a81:	8d be 00 ff          	lea    di,[bp-0x100]
    6a85:	16                   	push   ss
    6a86:	57                   	push   di
    6a87:	68 ff 00             	push   0xff
    6a8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a8d:	26 ff b5 c2 05       	push   WORD PTR es:[di+0x5c2]
    6a92:	26 ff b5 c0 05       	push   WORD PTR es:[di+0x5c0]
    6a97:	ff 36 48 02          	push   WORD PTR ds:0x248
    6a9b:	55                   	push   bp
    6a9c:	9a 8d 5b e3 6a       	call   0x6ae3:0x5b8d
    6aa1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6aa6:	76 18                	jbe    0x6ac0
    6aa8:	8d be 00 ff          	lea    di,[bp-0x100]
    6aac:	16                   	push   ss
    6aad:	57                   	push   di
    6aae:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6ab2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6ab7:	06                   	push   es
    6ab8:	57                   	push   di
    6ab9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6abc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6ac0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6ac5:	8d be 00 ff          	lea    di,[bp-0x100]
    6ac9:	16                   	push   ss
    6aca:	57                   	push   di
    6acb:	68 ff 00             	push   0xff
    6ace:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ad1:	26 ff b5 86 05       	push   WORD PTR es:[di+0x586]
    6ad6:	26 ff b5 84 05       	push   WORD PTR es:[di+0x584]
    6adb:	ff 36 42 02          	push   WORD PTR ds:0x242
    6adf:	55                   	push   bp
    6ae0:	9a 8d 5b 2c 6b       	call   0x6b2c:0x5b8d
    6ae5:	8d be fc fd          	lea    di,[bp-0x204]
    6ae9:	16                   	push   ss
    6aea:	57                   	push   di
    6aeb:	8d be 00 ff          	lea    di,[bp-0x100]
    6aef:	16                   	push   ss
    6af0:	57                   	push   di
    6af1:	9a cd 17 fe 6a       	call   0x6afe:0x17cd
    6af6:	bf 85 5e             	mov    di,0x5e85
    6af9:	0e                   	push   cs
    6afa:	57                   	push   di
    6afb:	9a 4c 18 0c 6b       	call   0x6b0c:0x184c
    6b00:	8d be 00 ff          	lea    di,[bp-0x100]
    6b04:	16                   	push   ss
    6b05:	57                   	push   di
    6b06:	68 ff 00             	push   0xff
    6b09:	9a e7 17 a1 6b       	call   0x6ba1:0x17e7
    6b0e:	8d be 00 ff          	lea    di,[bp-0x100]
    6b12:	16                   	push   ss
    6b13:	57                   	push   di
    6b14:	68 ff 00             	push   0xff
    6b17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b1a:	26 ff b5 62 05       	push   WORD PTR es:[di+0x562]
    6b1f:	26 ff b5 60 05       	push   WORD PTR es:[di+0x560]
    6b24:	ff 36 46 02          	push   WORD PTR ds:0x246
    6b28:	55                   	push   bp
    6b29:	9a 8d 5b 4c 6b       	call   0x6b4c:0x5b8d
    6b2e:	8d be 00 ff          	lea    di,[bp-0x100]
    6b32:	16                   	push   ss
    6b33:	57                   	push   di
    6b34:	68 ff 00             	push   0xff
    6b37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b3a:	26 ff b5 c6 05       	push   WORD PTR es:[di+0x5c6]
    6b3f:	26 ff b5 c4 05       	push   WORD PTR es:[di+0x5c4]
    6b44:	ff 36 48 02          	push   WORD PTR ds:0x248
    6b48:	55                   	push   bp
    6b49:	9a 8d 5b 90 6b       	call   0x6b90:0x5b8d
    6b4e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6b53:	76 18                	jbe    0x6b6d
    6b55:	8d be 00 ff          	lea    di,[bp-0x100]
    6b59:	16                   	push   ss
    6b5a:	57                   	push   di
    6b5b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6b5f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6b64:	06                   	push   es
    6b65:	57                   	push   di
    6b66:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b69:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6b6d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6b72:	8d be 00 ff          	lea    di,[bp-0x100]
    6b76:	16                   	push   ss
    6b77:	57                   	push   di
    6b78:	68 ff 00             	push   0xff
    6b7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b7e:	26 ff b5 a6 05       	push   WORD PTR es:[di+0x5a6]
    6b83:	26 ff b5 a4 05       	push   WORD PTR es:[di+0x5a4]
    6b88:	ff 36 42 02          	push   WORD PTR ds:0x242
    6b8c:	55                   	push   bp
    6b8d:	9a 8d 5b d9 6b       	call   0x6bd9:0x5b8d
    6b92:	8d be fc fd          	lea    di,[bp-0x204]
    6b96:	16                   	push   ss
    6b97:	57                   	push   di
    6b98:	8d be 00 ff          	lea    di,[bp-0x100]
    6b9c:	16                   	push   ss
    6b9d:	57                   	push   di
    6b9e:	9a cd 17 ab 6b       	call   0x6bab:0x17cd
    6ba3:	bf 85 5e             	mov    di,0x5e85
    6ba6:	0e                   	push   cs
    6ba7:	57                   	push   di
    6ba8:	9a 4c 18 b9 6b       	call   0x6bb9:0x184c
    6bad:	8d be 00 ff          	lea    di,[bp-0x100]
    6bb1:	16                   	push   ss
    6bb2:	57                   	push   di
    6bb3:	68 ff 00             	push   0xff
    6bb6:	9a e7 17 4e 6c       	call   0x6c4e:0x17e7
    6bbb:	8d be 00 ff          	lea    di,[bp-0x100]
    6bbf:	16                   	push   ss
    6bc0:	57                   	push   di
    6bc1:	68 ff 00             	push   0xff
    6bc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bc7:	26 ff b5 aa 05       	push   WORD PTR es:[di+0x5aa]
    6bcc:	26 ff b5 a8 05       	push   WORD PTR es:[di+0x5a8]
    6bd1:	ff 36 46 02          	push   WORD PTR ds:0x246
    6bd5:	55                   	push   bp
    6bd6:	9a 8d 5b f9 6b       	call   0x6bf9:0x5b8d
    6bdb:	8d be 00 ff          	lea    di,[bp-0x100]
    6bdf:	16                   	push   ss
    6be0:	57                   	push   di
    6be1:	68 ff 00             	push   0xff
    6be4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6be7:	26 ff b5 ca 05       	push   WORD PTR es:[di+0x5ca]
    6bec:	26 ff b5 c8 05       	push   WORD PTR es:[di+0x5c8]
    6bf1:	ff 36 48 02          	push   WORD PTR ds:0x248
    6bf5:	55                   	push   bp
    6bf6:	9a 8d 5b 3d 6c       	call   0x6c3d:0x5b8d
    6bfb:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6c00:	76 18                	jbe    0x6c1a
    6c02:	8d be 00 ff          	lea    di,[bp-0x100]
    6c06:	16                   	push   ss
    6c07:	57                   	push   di
    6c08:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6c0c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6c11:	06                   	push   es
    6c12:	57                   	push   di
    6c13:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c16:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6c1a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6c1f:	8d be 00 ff          	lea    di,[bp-0x100]
    6c23:	16                   	push   ss
    6c24:	57                   	push   di
    6c25:	68 ff 00             	push   0xff
    6c28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c2b:	26 ff b5 8a 05       	push   WORD PTR es:[di+0x58a]
    6c30:	26 ff b5 88 05       	push   WORD PTR es:[di+0x588]
    6c35:	ff 36 42 02          	push   WORD PTR ds:0x242
    6c39:	55                   	push   bp
    6c3a:	9a 8d 5b 86 6c       	call   0x6c86:0x5b8d
    6c3f:	8d be fc fd          	lea    di,[bp-0x204]
    6c43:	16                   	push   ss
    6c44:	57                   	push   di
    6c45:	8d be 00 ff          	lea    di,[bp-0x100]
    6c49:	16                   	push   ss
    6c4a:	57                   	push   di
    6c4b:	9a cd 17 58 6c       	call   0x6c58:0x17cd
    6c50:	bf 85 5e             	mov    di,0x5e85
    6c53:	0e                   	push   cs
    6c54:	57                   	push   di
    6c55:	9a 4c 18 66 6c       	call   0x6c66:0x184c
    6c5a:	8d be 00 ff          	lea    di,[bp-0x100]
    6c5e:	16                   	push   ss
    6c5f:	57                   	push   di
    6c60:	68 ff 00             	push   0xff
    6c63:	9a e7 17 fb 6c       	call   0x6cfb:0x17e7
    6c68:	8d be 00 ff          	lea    di,[bp-0x100]
    6c6c:	16                   	push   ss
    6c6d:	57                   	push   di
    6c6e:	68 ff 00             	push   0xff
    6c71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c74:	26 ff b5 66 05       	push   WORD PTR es:[di+0x566]
    6c79:	26 ff b5 64 05       	push   WORD PTR es:[di+0x564]
    6c7e:	ff 36 46 02          	push   WORD PTR ds:0x246
    6c82:	55                   	push   bp
    6c83:	9a 8d 5b a6 6c       	call   0x6ca6:0x5b8d
    6c88:	8d be 00 ff          	lea    di,[bp-0x100]
    6c8c:	16                   	push   ss
    6c8d:	57                   	push   di
    6c8e:	68 ff 00             	push   0xff
    6c91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c94:	26 ff b5 ce 05       	push   WORD PTR es:[di+0x5ce]
    6c99:	26 ff b5 cc 05       	push   WORD PTR es:[di+0x5cc]
    6c9e:	ff 36 48 02          	push   WORD PTR ds:0x248
    6ca2:	55                   	push   bp
    6ca3:	9a 8d 5b ea 6c       	call   0x6cea:0x5b8d
    6ca8:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6cad:	76 18                	jbe    0x6cc7
    6caf:	8d be 00 ff          	lea    di,[bp-0x100]
    6cb3:	16                   	push   ss
    6cb4:	57                   	push   di
    6cb5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6cb9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6cbe:	06                   	push   es
    6cbf:	57                   	push   di
    6cc0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6cc3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6cc7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6ccc:	8d be 00 ff          	lea    di,[bp-0x100]
    6cd0:	16                   	push   ss
    6cd1:	57                   	push   di
    6cd2:	68 ff 00             	push   0xff
    6cd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cd8:	26 ff b5 8e 05       	push   WORD PTR es:[di+0x58e]
    6cdd:	26 ff b5 8c 05       	push   WORD PTR es:[di+0x58c]
    6ce2:	ff 36 42 02          	push   WORD PTR ds:0x242
    6ce6:	55                   	push   bp
    6ce7:	9a 8d 5b 33 6d       	call   0x6d33:0x5b8d
    6cec:	8d be fc fd          	lea    di,[bp-0x204]
    6cf0:	16                   	push   ss
    6cf1:	57                   	push   di
    6cf2:	8d be 00 ff          	lea    di,[bp-0x100]
    6cf6:	16                   	push   ss
    6cf7:	57                   	push   di
    6cf8:	9a cd 17 05 6d       	call   0x6d05:0x17cd
    6cfd:	bf 85 5e             	mov    di,0x5e85
    6d00:	0e                   	push   cs
    6d01:	57                   	push   di
    6d02:	9a 4c 18 13 6d       	call   0x6d13:0x184c
    6d07:	8d be 00 ff          	lea    di,[bp-0x100]
    6d0b:	16                   	push   ss
    6d0c:	57                   	push   di
    6d0d:	68 ff 00             	push   0xff
    6d10:	9a e7 17 a8 6d       	call   0x6da8:0x17e7
    6d15:	8d be 00 ff          	lea    di,[bp-0x100]
    6d19:	16                   	push   ss
    6d1a:	57                   	push   di
    6d1b:	68 ff 00             	push   0xff
    6d1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d21:	26 ff b5 6a 05       	push   WORD PTR es:[di+0x56a]
    6d26:	26 ff b5 68 05       	push   WORD PTR es:[di+0x568]
    6d2b:	ff 36 46 02          	push   WORD PTR ds:0x246
    6d2f:	55                   	push   bp
    6d30:	9a 8d 5b 53 6d       	call   0x6d53:0x5b8d
    6d35:	8d be 00 ff          	lea    di,[bp-0x100]
    6d39:	16                   	push   ss
    6d3a:	57                   	push   di
    6d3b:	68 ff 00             	push   0xff
    6d3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d41:	26 ff b5 d2 05       	push   WORD PTR es:[di+0x5d2]
    6d46:	26 ff b5 d0 05       	push   WORD PTR es:[di+0x5d0]
    6d4b:	ff 36 48 02          	push   WORD PTR ds:0x248
    6d4f:	55                   	push   bp
    6d50:	9a 8d 5b 97 6d       	call   0x6d97:0x5b8d
    6d55:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6d5a:	76 18                	jbe    0x6d74
    6d5c:	8d be 00 ff          	lea    di,[bp-0x100]
    6d60:	16                   	push   ss
    6d61:	57                   	push   di
    6d62:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6d66:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6d6b:	06                   	push   es
    6d6c:	57                   	push   di
    6d6d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d70:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6d74:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6d79:	8d be 00 ff          	lea    di,[bp-0x100]
    6d7d:	16                   	push   ss
    6d7e:	57                   	push   di
    6d7f:	68 ff 00             	push   0xff
    6d82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d85:	26 ff b5 e6 05       	push   WORD PTR es:[di+0x5e6]
    6d8a:	26 ff b5 e4 05       	push   WORD PTR es:[di+0x5e4]
    6d8f:	ff 36 42 02          	push   WORD PTR ds:0x242
    6d93:	55                   	push   bp
    6d94:	9a 8d 5b e0 6d       	call   0x6de0:0x5b8d
    6d99:	8d be fc fd          	lea    di,[bp-0x204]
    6d9d:	16                   	push   ss
    6d9e:	57                   	push   di
    6d9f:	8d be 00 ff          	lea    di,[bp-0x100]
    6da3:	16                   	push   ss
    6da4:	57                   	push   di
    6da5:	9a cd 17 b2 6d       	call   0x6db2:0x17cd
    6daa:	bf 85 5e             	mov    di,0x5e85
    6dad:	0e                   	push   cs
    6dae:	57                   	push   di
    6daf:	9a 4c 18 c0 6d       	call   0x6dc0:0x184c
    6db4:	8d be 00 ff          	lea    di,[bp-0x100]
    6db8:	16                   	push   ss
    6db9:	57                   	push   di
    6dba:	68 ff 00             	push   0xff
    6dbd:	9a e7 17 55 6e       	call   0x6e55:0x17e7
    6dc2:	8d be 00 ff          	lea    di,[bp-0x100]
    6dc6:	16                   	push   ss
    6dc7:	57                   	push   di
    6dc8:	68 ff 00             	push   0xff
    6dcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dce:	26 ff b5 ea 05       	push   WORD PTR es:[di+0x5ea]
    6dd3:	26 ff b5 e8 05       	push   WORD PTR es:[di+0x5e8]
    6dd8:	ff 36 46 02          	push   WORD PTR ds:0x246
    6ddc:	55                   	push   bp
    6ddd:	9a 8d 5b 00 6e       	call   0x6e00:0x5b8d
    6de2:	8d be 00 ff          	lea    di,[bp-0x100]
    6de6:	16                   	push   ss
    6de7:	57                   	push   di
    6de8:	68 ff 00             	push   0xff
    6deb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dee:	26 ff b5 d6 05       	push   WORD PTR es:[di+0x5d6]
    6df3:	26 ff b5 d4 05       	push   WORD PTR es:[di+0x5d4]
    6df8:	ff 36 48 02          	push   WORD PTR ds:0x248
    6dfc:	55                   	push   bp
    6dfd:	9a 8d 5b 44 6e       	call   0x6e44:0x5b8d
    6e02:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6e07:	76 18                	jbe    0x6e21
    6e09:	8d be 00 ff          	lea    di,[bp-0x100]
    6e0d:	16                   	push   ss
    6e0e:	57                   	push   di
    6e0f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6e13:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6e18:	06                   	push   es
    6e19:	57                   	push   di
    6e1a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6e1d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6e21:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6e26:	8d be 00 ff          	lea    di,[bp-0x100]
    6e2a:	16                   	push   ss
    6e2b:	57                   	push   di
    6e2c:	68 ff 00             	push   0xff
    6e2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e32:	26 ff b5 9e 05       	push   WORD PTR es:[di+0x59e]
    6e37:	26 ff b5 9c 05       	push   WORD PTR es:[di+0x59c]
    6e3c:	ff 36 42 02          	push   WORD PTR ds:0x242
    6e40:	55                   	push   bp
    6e41:	9a 8d 5b 8d 6e       	call   0x6e8d:0x5b8d
    6e46:	8d be fc fd          	lea    di,[bp-0x204]
    6e4a:	16                   	push   ss
    6e4b:	57                   	push   di
    6e4c:	8d be 00 ff          	lea    di,[bp-0x100]
    6e50:	16                   	push   ss
    6e51:	57                   	push   di
    6e52:	9a cd 17 5f 6e       	call   0x6e5f:0x17cd
    6e57:	bf 85 5e             	mov    di,0x5e85
    6e5a:	0e                   	push   cs
    6e5b:	57                   	push   di
    6e5c:	9a 4c 18 6d 6e       	call   0x6e6d:0x184c
    6e61:	8d be 00 ff          	lea    di,[bp-0x100]
    6e65:	16                   	push   ss
    6e66:	57                   	push   di
    6e67:	68 ff 00             	push   0xff
    6e6a:	9a e7 17 02 6f       	call   0x6f02:0x17e7
    6e6f:	8d be 00 ff          	lea    di,[bp-0x100]
    6e73:	16                   	push   ss
    6e74:	57                   	push   di
    6e75:	68 ff 00             	push   0xff
    6e78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e7b:	26 ff b5 a2 05       	push   WORD PTR es:[di+0x5a2]
    6e80:	26 ff b5 a0 05       	push   WORD PTR es:[di+0x5a0]
    6e85:	ff 36 46 02          	push   WORD PTR ds:0x246
    6e89:	55                   	push   bp
    6e8a:	9a 8d 5b ad 6e       	call   0x6ead:0x5b8d
    6e8f:	8d be 00 ff          	lea    di,[bp-0x100]
    6e93:	16                   	push   ss
    6e94:	57                   	push   di
    6e95:	68 ff 00             	push   0xff
    6e98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e9b:	26 ff b5 de 05       	push   WORD PTR es:[di+0x5de]
    6ea0:	26 ff b5 dc 05       	push   WORD PTR es:[di+0x5dc]
    6ea5:	ff 36 48 02          	push   WORD PTR ds:0x248
    6ea9:	55                   	push   bp
    6eaa:	9a 8d 5b f1 6e       	call   0x6ef1:0x5b8d
    6eaf:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6eb4:	76 18                	jbe    0x6ece
    6eb6:	8d be 00 ff          	lea    di,[bp-0x100]
    6eba:	16                   	push   ss
    6ebb:	57                   	push   di
    6ebc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6ec0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6ec5:	06                   	push   es
    6ec6:	57                   	push   di
    6ec7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6eca:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6ece:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6ed3:	8d be 00 ff          	lea    di,[bp-0x100]
    6ed7:	16                   	push   ss
    6ed8:	57                   	push   di
    6ed9:	68 ff 00             	push   0xff
    6edc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6edf:	26 ff b5 92 05       	push   WORD PTR es:[di+0x592]
    6ee4:	26 ff b5 90 05       	push   WORD PTR es:[di+0x590]
    6ee9:	ff 36 42 02          	push   WORD PTR ds:0x242
    6eed:	55                   	push   bp
    6eee:	9a 8d 5b 3a 6f       	call   0x6f3a:0x5b8d
    6ef3:	8d be fc fd          	lea    di,[bp-0x204]
    6ef7:	16                   	push   ss
    6ef8:	57                   	push   di
    6ef9:	8d be 00 ff          	lea    di,[bp-0x100]
    6efd:	16                   	push   ss
    6efe:	57                   	push   di
    6eff:	9a cd 17 0c 6f       	call   0x6f0c:0x17cd
    6f04:	bf 85 5e             	mov    di,0x5e85
    6f07:	0e                   	push   cs
    6f08:	57                   	push   di
    6f09:	9a 4c 18 1a 6f       	call   0x6f1a:0x184c
    6f0e:	8d be 00 ff          	lea    di,[bp-0x100]
    6f12:	16                   	push   ss
    6f13:	57                   	push   di
    6f14:	68 ff 00             	push   0xff
    6f17:	9a e7 17 cc 6f       	call   0x6fcc:0x17e7
    6f1c:	8d be 00 ff          	lea    di,[bp-0x100]
    6f20:	16                   	push   ss
    6f21:	57                   	push   di
    6f22:	68 ff 00             	push   0xff
    6f25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f28:	26 ff b5 6e 05       	push   WORD PTR es:[di+0x56e]
    6f2d:	26 ff b5 6c 05       	push   WORD PTR es:[di+0x56c]
    6f32:	ff 36 46 02          	push   WORD PTR ds:0x246
    6f36:	55                   	push   bp
    6f37:	9a 8d 5b 5a 6f       	call   0x6f5a:0x5b8d
    6f3c:	8d be 00 ff          	lea    di,[bp-0x100]
    6f40:	16                   	push   ss
    6f41:	57                   	push   di
    6f42:	68 ff 00             	push   0xff
    6f45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f48:	26 ff b5 da 05       	push   WORD PTR es:[di+0x5da]
    6f4d:	26 ff b5 d8 05       	push   WORD PTR es:[di+0x5d8]
    6f52:	ff 36 48 02          	push   WORD PTR ds:0x248
    6f56:	55                   	push   bp
    6f57:	9a 8d 5b bb 6f       	call   0x6fbb:0x5b8d
    6f5c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6f61:	76 18                	jbe    0x6f7b
    6f63:	8d be 00 ff          	lea    di,[bp-0x100]
    6f67:	16                   	push   ss
    6f68:	57                   	push   di
    6f69:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6f6d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6f72:	06                   	push   es
    6f73:	57                   	push   di
    6f74:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f77:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6f7b:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    6f7f:	75 17                	jne    0x6f98
    6f81:	bf 87 5e             	mov    di,0x5e87
    6f84:	0e                   	push   cs
    6f85:	57                   	push   di
    6f86:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6f8a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6f8f:	06                   	push   es
    6f90:	57                   	push   di
    6f91:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f94:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6f98:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6f9d:	8d be 00 ff          	lea    di,[bp-0x100]
    6fa1:	16                   	push   ss
    6fa2:	57                   	push   di
    6fa3:	68 ff 00             	push   0xff
    6fa6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fa9:	26 ff b5 f2 05       	push   WORD PTR es:[di+0x5f2]
    6fae:	26 ff b5 f0 05       	push   WORD PTR es:[di+0x5f0]
    6fb3:	ff 36 40 02          	push   WORD PTR ds:0x240
    6fb7:	55                   	push   bp
    6fb8:	9a 8d 5b 04 70       	call   0x7004:0x5b8d
    6fbd:	8d be fc fd          	lea    di,[bp-0x204]
    6fc1:	16                   	push   ss
    6fc2:	57                   	push   di
    6fc3:	8d be 00 ff          	lea    di,[bp-0x100]
    6fc7:	16                   	push   ss
    6fc8:	57                   	push   di
    6fc9:	9a cd 17 d6 6f       	call   0x6fd6:0x17cd
    6fce:	bf 85 5e             	mov    di,0x5e85
    6fd1:	0e                   	push   cs
    6fd2:	57                   	push   di
    6fd3:	9a 4c 18 e4 6f       	call   0x6fe4:0x184c
    6fd8:	8d be 00 ff          	lea    di,[bp-0x100]
    6fdc:	16                   	push   ss
    6fdd:	57                   	push   di
    6fde:	68 ff 00             	push   0xff
    6fe1:	9a e7 17 79 70       	call   0x7079:0x17e7
    6fe6:	8d be 00 ff          	lea    di,[bp-0x100]
    6fea:	16                   	push   ss
    6feb:	57                   	push   di
    6fec:	68 ff 00             	push   0xff
    6fef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ff2:	26 ff b5 0a 06       	push   WORD PTR es:[di+0x60a]
    6ff7:	26 ff b5 08 06       	push   WORD PTR es:[di+0x608]
    6ffc:	ff 36 46 02          	push   WORD PTR ds:0x246
    7000:	55                   	push   bp
    7001:	9a 8d 5b 24 70       	call   0x7024:0x5b8d
    7006:	8d be 00 ff          	lea    di,[bp-0x100]
    700a:	16                   	push   ss
    700b:	57                   	push   di
    700c:	68 ff 00             	push   0xff
    700f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7012:	26 ff b5 32 06       	push   WORD PTR es:[di+0x632]
    7017:	26 ff b5 30 06       	push   WORD PTR es:[di+0x630]
    701c:	ff 36 48 02          	push   WORD PTR ds:0x248
    7020:	55                   	push   bp
    7021:	9a 8d 5b 68 70       	call   0x7068:0x5b8d
    7026:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    702b:	76 18                	jbe    0x7045
    702d:	8d be 00 ff          	lea    di,[bp-0x100]
    7031:	16                   	push   ss
    7032:	57                   	push   di
    7033:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7037:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    703c:	06                   	push   es
    703d:	57                   	push   di
    703e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7041:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7045:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    704a:	8d be 00 ff          	lea    di,[bp-0x100]
    704e:	16                   	push   ss
    704f:	57                   	push   di
    7050:	68 ff 00             	push   0xff
    7053:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7056:	26 ff b5 96 06       	push   WORD PTR es:[di+0x696]
    705b:	26 ff b5 94 06       	push   WORD PTR es:[di+0x694]
    7060:	ff 36 42 02          	push   WORD PTR ds:0x242
    7064:	55                   	push   bp
    7065:	9a 8d 5b b1 70       	call   0x70b1:0x5b8d
    706a:	8d be fc fd          	lea    di,[bp-0x204]
    706e:	16                   	push   ss
    706f:	57                   	push   di
    7070:	8d be 00 ff          	lea    di,[bp-0x100]
    7074:	16                   	push   ss
    7075:	57                   	push   di
    7076:	9a cd 17 83 70       	call   0x7083:0x17cd
    707b:	bf 85 5e             	mov    di,0x5e85
    707e:	0e                   	push   cs
    707f:	57                   	push   di
    7080:	9a 4c 18 91 70       	call   0x7091:0x184c
    7085:	8d be 00 ff          	lea    di,[bp-0x100]
    7089:	16                   	push   ss
    708a:	57                   	push   di
    708b:	68 ff 00             	push   0xff
    708e:	9a e7 17 26 71       	call   0x7126:0x17e7
    7093:	8d be 00 ff          	lea    di,[bp-0x100]
    7097:	16                   	push   ss
    7098:	57                   	push   di
    7099:	68 ff 00             	push   0xff
    709c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    709f:	26 ff b5 9a 06       	push   WORD PTR es:[di+0x69a]
    70a4:	26 ff b5 98 06       	push   WORD PTR es:[di+0x698]
    70a9:	ff 36 46 02          	push   WORD PTR ds:0x246
    70ad:	55                   	push   bp
    70ae:	9a 8d 5b d1 70       	call   0x70d1:0x5b8d
    70b3:	8d be 00 ff          	lea    di,[bp-0x100]
    70b7:	16                   	push   ss
    70b8:	57                   	push   di
    70b9:	68 ff 00             	push   0xff
    70bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70bf:	26 ff b5 9e 06       	push   WORD PTR es:[di+0x69e]
    70c4:	26 ff b5 9c 06       	push   WORD PTR es:[di+0x69c]
    70c9:	ff 36 48 02          	push   WORD PTR ds:0x248
    70cd:	55                   	push   bp
    70ce:	9a 8d 5b 15 71       	call   0x7115:0x5b8d
    70d3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    70d8:	76 18                	jbe    0x70f2
    70da:	8d be 00 ff          	lea    di,[bp-0x100]
    70de:	16                   	push   ss
    70df:	57                   	push   di
    70e0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    70e4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    70e9:	06                   	push   es
    70ea:	57                   	push   di
    70eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    70ee:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    70f2:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    70f7:	8d be 00 ff          	lea    di,[bp-0x100]
    70fb:	16                   	push   ss
    70fc:	57                   	push   di
    70fd:	68 ff 00             	push   0xff
    7100:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7103:	26 ff b5 ce 06       	push   WORD PTR es:[di+0x6ce]
    7108:	26 ff b5 cc 06       	push   WORD PTR es:[di+0x6cc]
    710d:	ff 36 42 02          	push   WORD PTR ds:0x242
    7111:	55                   	push   bp
    7112:	9a 8d 5b 5e 71       	call   0x715e:0x5b8d
    7117:	8d be fc fd          	lea    di,[bp-0x204]
    711b:	16                   	push   ss
    711c:	57                   	push   di
    711d:	8d be 00 ff          	lea    di,[bp-0x100]
    7121:	16                   	push   ss
    7122:	57                   	push   di
    7123:	9a cd 17 30 71       	call   0x7130:0x17cd
    7128:	bf 85 5e             	mov    di,0x5e85
    712b:	0e                   	push   cs
    712c:	57                   	push   di
    712d:	9a 4c 18 3e 71       	call   0x713e:0x184c
    7132:	8d be 00 ff          	lea    di,[bp-0x100]
    7136:	16                   	push   ss
    7137:	57                   	push   di
    7138:	68 ff 00             	push   0xff
    713b:	9a e7 17 d3 71       	call   0x71d3:0x17e7
    7140:	8d be 00 ff          	lea    di,[bp-0x100]
    7144:	16                   	push   ss
    7145:	57                   	push   di
    7146:	68 ff 00             	push   0xff
    7149:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    714c:	26 ff b5 d2 06       	push   WORD PTR es:[di+0x6d2]
    7151:	26 ff b5 d0 06       	push   WORD PTR es:[di+0x6d0]
    7156:	ff 36 46 02          	push   WORD PTR ds:0x246
    715a:	55                   	push   bp
    715b:	9a 8d 5b 7e 71       	call   0x717e:0x5b8d
    7160:	8d be 00 ff          	lea    di,[bp-0x100]
    7164:	16                   	push   ss
    7165:	57                   	push   di
    7166:	68 ff 00             	push   0xff
    7169:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    716c:	26 ff b5 d6 06       	push   WORD PTR es:[di+0x6d6]
    7171:	26 ff b5 d4 06       	push   WORD PTR es:[di+0x6d4]
    7176:	ff 36 48 02          	push   WORD PTR ds:0x248
    717a:	55                   	push   bp
    717b:	9a 8d 5b c2 71       	call   0x71c2:0x5b8d
    7180:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7185:	76 18                	jbe    0x719f
    7187:	8d be 00 ff          	lea    di,[bp-0x100]
    718b:	16                   	push   ss
    718c:	57                   	push   di
    718d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7191:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7196:	06                   	push   es
    7197:	57                   	push   di
    7198:	26 c4 3d             	les    di,DWORD PTR es:[di]
    719b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    719f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    71a4:	8d be 00 ff          	lea    di,[bp-0x100]
    71a8:	16                   	push   ss
    71a9:	57                   	push   di
    71aa:	68 ff 00             	push   0xff
    71ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71b0:	26 ff b5 da 06       	push   WORD PTR es:[di+0x6da]
    71b5:	26 ff b5 d8 06       	push   WORD PTR es:[di+0x6d8]
    71ba:	ff 36 42 02          	push   WORD PTR ds:0x242
    71be:	55                   	push   bp
    71bf:	9a 8d 5b 0b 72       	call   0x720b:0x5b8d
    71c4:	8d be fc fd          	lea    di,[bp-0x204]
    71c8:	16                   	push   ss
    71c9:	57                   	push   di
    71ca:	8d be 00 ff          	lea    di,[bp-0x100]
    71ce:	16                   	push   ss
    71cf:	57                   	push   di
    71d0:	9a cd 17 dd 71       	call   0x71dd:0x17cd
    71d5:	bf 85 5e             	mov    di,0x5e85
    71d8:	0e                   	push   cs
    71d9:	57                   	push   di
    71da:	9a 4c 18 eb 71       	call   0x71eb:0x184c
    71df:	8d be 00 ff          	lea    di,[bp-0x100]
    71e3:	16                   	push   ss
    71e4:	57                   	push   di
    71e5:	68 ff 00             	push   0xff
    71e8:	9a e7 17 a2 74       	call   0x74a2:0x17e7
    71ed:	8d be 00 ff          	lea    di,[bp-0x100]
    71f1:	16                   	push   ss
    71f2:	57                   	push   di
    71f3:	68 ff 00             	push   0xff
    71f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71f9:	26 ff b5 de 06       	push   WORD PTR es:[di+0x6de]
    71fe:	26 ff b5 dc 06       	push   WORD PTR es:[di+0x6dc]
    7203:	ff 36 46 02          	push   WORD PTR ds:0x246
    7207:	55                   	push   bp
    7208:	9a 8d 5b 2b 72       	call   0x722b:0x5b8d
    720d:	8d be 00 ff          	lea    di,[bp-0x100]
    7211:	16                   	push   ss
    7212:	57                   	push   di
    7213:	68 ff 00             	push   0xff
    7216:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7219:	26 ff b5 e2 06       	push   WORD PTR es:[di+0x6e2]
    721e:	26 ff b5 e0 06       	push   WORD PTR es:[di+0x6e0]
    7223:	ff 36 48 02          	push   WORD PTR ds:0x248
    7227:	55                   	push   bp
    7228:	9a 8d 5b 81 72       	call   0x7281:0x5b8d
    722d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7232:	76 18                	jbe    0x724c
    7234:	8d be 00 ff          	lea    di,[bp-0x100]
    7238:	16                   	push   ss
    7239:	57                   	push   di
    723a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    723e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7243:	06                   	push   es
    7244:	57                   	push   di
    7245:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7248:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    724c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7251:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7254:	26 c4 bd 0c 06       	les    di,DWORD PTR es:[di+0x60c]
    7259:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    725e:	75 03                	jne    0x7263
    7260:	e9 80 00             	jmp    0x72e3
    7263:	8d be 00 ff          	lea    di,[bp-0x100]
    7267:	16                   	push   ss
    7268:	57                   	push   di
    7269:	68 ff 00             	push   0xff
    726c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    726f:	26 ff b5 0e 06       	push   WORD PTR es:[di+0x60e]
    7274:	26 ff b5 0c 06       	push   WORD PTR es:[di+0x60c]
    7279:	ff 36 42 02          	push   WORD PTR ds:0x242
    727d:	55                   	push   bp
    727e:	9a 8d 5b a1 72       	call   0x72a1:0x5b8d
    7283:	8d be 00 ff          	lea    di,[bp-0x100]
    7287:	16                   	push   ss
    7288:	57                   	push   di
    7289:	68 ff 00             	push   0xff
    728c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    728f:	26 ff b5 62 06       	push   WORD PTR es:[di+0x662]
    7294:	26 ff b5 60 06       	push   WORD PTR es:[di+0x660]
    7299:	ff 36 44 02          	push   WORD PTR ds:0x244
    729d:	55                   	push   bp
    729e:	9a 8d 5b c1 72       	call   0x72c1:0x5b8d
    72a3:	8d be 00 ff          	lea    di,[bp-0x100]
    72a7:	16                   	push   ss
    72a8:	57                   	push   di
    72a9:	68 ff 00             	push   0xff
    72ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72af:	26 ff b5 f6 05       	push   WORD PTR es:[di+0x5f6]
    72b4:	26 ff b5 f4 05       	push   WORD PTR es:[di+0x5f4]
    72b9:	ff 36 46 02          	push   WORD PTR ds:0x246
    72bd:	55                   	push   bp
    72be:	9a 8d 5b e1 72       	call   0x72e1:0x5b8d
    72c3:	8d be 00 ff          	lea    di,[bp-0x100]
    72c7:	16                   	push   ss
    72c8:	57                   	push   di
    72c9:	68 ff 00             	push   0xff
    72cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72cf:	26 ff b5 36 06       	push   WORD PTR es:[di+0x636]
    72d4:	26 ff b5 34 06       	push   WORD PTR es:[di+0x634]
    72d9:	ff 36 48 02          	push   WORD PTR ds:0x248
    72dd:	55                   	push   bp
    72de:	9a 8d 5b 37 73       	call   0x7337:0x5b8d
    72e3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    72e8:	76 18                	jbe    0x7302
    72ea:	8d be 00 ff          	lea    di,[bp-0x100]
    72ee:	16                   	push   ss
    72ef:	57                   	push   di
    72f0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    72f4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    72f9:	06                   	push   es
    72fa:	57                   	push   di
    72fb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    72fe:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7302:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7307:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    730a:	26 c4 bd 1c 06       	les    di,DWORD PTR es:[di+0x61c]
    730f:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    7314:	75 03                	jne    0x7319
    7316:	e9 80 00             	jmp    0x7399
    7319:	8d be 00 ff          	lea    di,[bp-0x100]
    731d:	16                   	push   ss
    731e:	57                   	push   di
    731f:	68 ff 00             	push   0xff
    7322:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7325:	26 ff b5 1e 06       	push   WORD PTR es:[di+0x61e]
    732a:	26 ff b5 1c 06       	push   WORD PTR es:[di+0x61c]
    732f:	ff 36 42 02          	push   WORD PTR ds:0x242
    7333:	55                   	push   bp
    7334:	9a 8d 5b 57 73       	call   0x7357:0x5b8d
    7339:	8d be 00 ff          	lea    di,[bp-0x100]
    733d:	16                   	push   ss
    733e:	57                   	push   di
    733f:	68 ff 00             	push   0xff
    7342:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7345:	26 ff b5 66 06       	push   WORD PTR es:[di+0x666]
    734a:	26 ff b5 64 06       	push   WORD PTR es:[di+0x664]
    734f:	ff 36 44 02          	push   WORD PTR ds:0x244
    7353:	55                   	push   bp
    7354:	9a 8d 5b 77 73       	call   0x7377:0x5b8d
    7359:	8d be 00 ff          	lea    di,[bp-0x100]
    735d:	16                   	push   ss
    735e:	57                   	push   di
    735f:	68 ff 00             	push   0xff
    7362:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7365:	26 ff b5 26 06       	push   WORD PTR es:[di+0x626]
    736a:	26 ff b5 24 06       	push   WORD PTR es:[di+0x624]
    736f:	ff 36 46 02          	push   WORD PTR ds:0x246
    7373:	55                   	push   bp
    7374:	9a 8d 5b 97 73       	call   0x7397:0x5b8d
    7379:	8d be 00 ff          	lea    di,[bp-0x100]
    737d:	16                   	push   ss
    737e:	57                   	push   di
    737f:	68 ff 00             	push   0xff
    7382:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7385:	26 ff b5 3a 06       	push   WORD PTR es:[di+0x63a]
    738a:	26 ff b5 38 06       	push   WORD PTR es:[di+0x638]
    738f:	ff 36 48 02          	push   WORD PTR ds:0x248
    7393:	55                   	push   bp
    7394:	9a 8d 5b ed 73       	call   0x73ed:0x5b8d
    7399:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    739e:	76 18                	jbe    0x73b8
    73a0:	8d be 00 ff          	lea    di,[bp-0x100]
    73a4:	16                   	push   ss
    73a5:	57                   	push   di
    73a6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    73aa:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    73af:	06                   	push   es
    73b0:	57                   	push   di
    73b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    73b4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    73b8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    73bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73c0:	26 c4 bd 20 06       	les    di,DWORD PTR es:[di+0x620]
    73c5:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    73ca:	75 03                	jne    0x73cf
    73cc:	e9 80 00             	jmp    0x744f
    73cf:	8d be 00 ff          	lea    di,[bp-0x100]
    73d3:	16                   	push   ss
    73d4:	57                   	push   di
    73d5:	68 ff 00             	push   0xff
    73d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73db:	26 ff b5 22 06       	push   WORD PTR es:[di+0x622]
    73e0:	26 ff b5 20 06       	push   WORD PTR es:[di+0x620]
    73e5:	ff 36 42 02          	push   WORD PTR ds:0x242
    73e9:	55                   	push   bp
    73ea:	9a 8d 5b 0d 74       	call   0x740d:0x5b8d
    73ef:	8d be 00 ff          	lea    di,[bp-0x100]
    73f3:	16                   	push   ss
    73f4:	57                   	push   di
    73f5:	68 ff 00             	push   0xff
    73f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73fb:	26 ff b5 6a 06       	push   WORD PTR es:[di+0x66a]
    7400:	26 ff b5 68 06       	push   WORD PTR es:[di+0x668]
    7405:	ff 36 44 02          	push   WORD PTR ds:0x244
    7409:	55                   	push   bp
    740a:	9a 8d 5b 2d 74       	call   0x742d:0x5b8d
    740f:	8d be 00 ff          	lea    di,[bp-0x100]
    7413:	16                   	push   ss
    7414:	57                   	push   di
    7415:	68 ff 00             	push   0xff
    7418:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    741b:	26 ff b5 2a 06       	push   WORD PTR es:[di+0x62a]
    7420:	26 ff b5 28 06       	push   WORD PTR es:[di+0x628]
    7425:	ff 36 46 02          	push   WORD PTR ds:0x246
    7429:	55                   	push   bp
    742a:	9a 8d 5b 4d 74       	call   0x744d:0x5b8d
    742f:	8d be 00 ff          	lea    di,[bp-0x100]
    7433:	16                   	push   ss
    7434:	57                   	push   di
    7435:	68 ff 00             	push   0xff
    7438:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    743b:	26 ff b5 3e 06       	push   WORD PTR es:[di+0x63e]
    7440:	26 ff b5 3c 06       	push   WORD PTR es:[di+0x63c]
    7445:	ff 36 48 02          	push   WORD PTR ds:0x248
    7449:	55                   	push   bp
    744a:	9a 8d 5b 91 74       	call   0x7491:0x5b8d
    744f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7454:	76 18                	jbe    0x746e
    7456:	8d be 00 ff          	lea    di,[bp-0x100]
    745a:	16                   	push   ss
    745b:	57                   	push   di
    745c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7460:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7465:	06                   	push   es
    7466:	57                   	push   di
    7467:	26 c4 3d             	les    di,DWORD PTR es:[di]
    746a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    746e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7473:	8d be 00 ff          	lea    di,[bp-0x100]
    7477:	16                   	push   ss
    7478:	57                   	push   di
    7479:	68 ff 00             	push   0xff
    747c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    747f:	26 ff b5 12 06       	push   WORD PTR es:[di+0x612]
    7484:	26 ff b5 10 06       	push   WORD PTR es:[di+0x610]
    7489:	ff 36 42 02          	push   WORD PTR ds:0x242
    748d:	55                   	push   bp
    748e:	9a 8d 5b da 74       	call   0x74da:0x5b8d
    7493:	8d be fc fd          	lea    di,[bp-0x204]
    7497:	16                   	push   ss
    7498:	57                   	push   di
    7499:	8d be 00 ff          	lea    di,[bp-0x100]
    749d:	16                   	push   ss
    749e:	57                   	push   di
    749f:	9a cd 17 ac 74       	call   0x74ac:0x17cd
    74a4:	bf 85 5e             	mov    di,0x5e85
    74a7:	0e                   	push   cs
    74a8:	57                   	push   di
    74a9:	9a 4c 18 ba 74       	call   0x74ba:0x184c
    74ae:	8d be 00 ff          	lea    di,[bp-0x100]
    74b2:	16                   	push   ss
    74b3:	57                   	push   di
    74b4:	68 ff 00             	push   0xff
    74b7:	9a e7 17 4f 75       	call   0x754f:0x17e7
    74bc:	8d be 00 ff          	lea    di,[bp-0x100]
    74c0:	16                   	push   ss
    74c1:	57                   	push   di
    74c2:	68 ff 00             	push   0xff
    74c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74c8:	26 ff b5 fa 05       	push   WORD PTR es:[di+0x5fa]
    74cd:	26 ff b5 f8 05       	push   WORD PTR es:[di+0x5f8]
    74d2:	ff 36 46 02          	push   WORD PTR ds:0x246
    74d6:	55                   	push   bp
    74d7:	9a 8d 5b fa 74       	call   0x74fa:0x5b8d
    74dc:	8d be 00 ff          	lea    di,[bp-0x100]
    74e0:	16                   	push   ss
    74e1:	57                   	push   di
    74e2:	68 ff 00             	push   0xff
    74e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74e8:	26 ff b5 42 06       	push   WORD PTR es:[di+0x642]
    74ed:	26 ff b5 40 06       	push   WORD PTR es:[di+0x640]
    74f2:	ff 36 48 02          	push   WORD PTR ds:0x248
    74f6:	55                   	push   bp
    74f7:	9a 8d 5b 3e 75       	call   0x753e:0x5b8d
    74fc:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7501:	76 18                	jbe    0x751b
    7503:	8d be 00 ff          	lea    di,[bp-0x100]
    7507:	16                   	push   ss
    7508:	57                   	push   di
    7509:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    750d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7512:	06                   	push   es
    7513:	57                   	push   di
    7514:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7517:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    751b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7520:	8d be 00 ff          	lea    di,[bp-0x100]
    7524:	16                   	push   ss
    7525:	57                   	push   di
    7526:	68 ff 00             	push   0xff
    7529:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    752c:	26 ff b5 16 06       	push   WORD PTR es:[di+0x616]
    7531:	26 ff b5 14 06       	push   WORD PTR es:[di+0x614]
    7536:	ff 36 42 02          	push   WORD PTR ds:0x242
    753a:	55                   	push   bp
    753b:	9a 8d 5b 87 75       	call   0x7587:0x5b8d
    7540:	8d be fc fd          	lea    di,[bp-0x204]
    7544:	16                   	push   ss
    7545:	57                   	push   di
    7546:	8d be 00 ff          	lea    di,[bp-0x100]
    754a:	16                   	push   ss
    754b:	57                   	push   di
    754c:	9a cd 17 59 75       	call   0x7559:0x17cd
    7551:	bf 85 5e             	mov    di,0x5e85
    7554:	0e                   	push   cs
    7555:	57                   	push   di
    7556:	9a 4c 18 67 75       	call   0x7567:0x184c
    755b:	8d be 00 ff          	lea    di,[bp-0x100]
    755f:	16                   	push   ss
    7560:	57                   	push   di
    7561:	68 ff 00             	push   0xff
    7564:	9a e7 17 44 77       	call   0x7744:0x17e7
    7569:	8d be 00 ff          	lea    di,[bp-0x100]
    756d:	16                   	push   ss
    756e:	57                   	push   di
    756f:	68 ff 00             	push   0xff
    7572:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7575:	26 ff b5 fe 05       	push   WORD PTR es:[di+0x5fe]
    757a:	26 ff b5 fc 05       	push   WORD PTR es:[di+0x5fc]
    757f:	ff 36 46 02          	push   WORD PTR ds:0x246
    7583:	55                   	push   bp
    7584:	9a 8d 5b a7 75       	call   0x75a7:0x5b8d
    7589:	8d be 00 ff          	lea    di,[bp-0x100]
    758d:	16                   	push   ss
    758e:	57                   	push   di
    758f:	68 ff 00             	push   0xff
    7592:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7595:	26 ff b5 46 06       	push   WORD PTR es:[di+0x646]
    759a:	26 ff b5 44 06       	push   WORD PTR es:[di+0x644]
    759f:	ff 36 48 02          	push   WORD PTR ds:0x248
    75a3:	55                   	push   bp
    75a4:	9a 8d 5b eb 75       	call   0x75eb:0x5b8d
    75a9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    75ae:	76 18                	jbe    0x75c8
    75b0:	8d be 00 ff          	lea    di,[bp-0x100]
    75b4:	16                   	push   ss
    75b5:	57                   	push   di
    75b6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    75ba:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    75bf:	06                   	push   es
    75c0:	57                   	push   di
    75c1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    75c4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    75c8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    75cd:	8d be 00 ff          	lea    di,[bp-0x100]
    75d1:	16                   	push   ss
    75d2:	57                   	push   di
    75d3:	68 ff 00             	push   0xff
    75d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75d9:	26 ff b5 5a 06       	push   WORD PTR es:[di+0x65a]
    75de:	26 ff b5 58 06       	push   WORD PTR es:[di+0x658]
    75e3:	ff 36 42 02          	push   WORD PTR ds:0x242
    75e7:	55                   	push   bp
    75e8:	9a 8d 5b 0b 76       	call   0x760b:0x5b8d
    75ed:	8d be 00 ff          	lea    di,[bp-0x100]
    75f1:	16                   	push   ss
    75f2:	57                   	push   di
    75f3:	68 ff 00             	push   0xff
    75f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75f9:	26 ff b5 6e 06       	push   WORD PTR es:[di+0x66e]
    75fe:	26 ff b5 6c 06       	push   WORD PTR es:[di+0x66c]
    7603:	ff 36 44 02          	push   WORD PTR ds:0x244
    7607:	55                   	push   bp
    7608:	9a 8d 5b 2b 76       	call   0x762b:0x5b8d
    760d:	8d be 00 ff          	lea    di,[bp-0x100]
    7611:	16                   	push   ss
    7612:	57                   	push   di
    7613:	68 ff 00             	push   0xff
    7616:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7619:	26 ff b5 02 06       	push   WORD PTR es:[di+0x602]
    761e:	26 ff b5 00 06       	push   WORD PTR es:[di+0x600]
    7623:	ff 36 46 02          	push   WORD PTR ds:0x246
    7627:	55                   	push   bp
    7628:	9a 8d 5b 4b 76       	call   0x764b:0x5b8d
    762d:	8d be 00 ff          	lea    di,[bp-0x100]
    7631:	16                   	push   ss
    7632:	57                   	push   di
    7633:	68 ff 00             	push   0xff
    7636:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7639:	26 ff b5 4a 06       	push   WORD PTR es:[di+0x64a]
    763e:	26 ff b5 48 06       	push   WORD PTR es:[di+0x648]
    7643:	ff 36 48 02          	push   WORD PTR ds:0x248
    7647:	55                   	push   bp
    7648:	9a 8d 5b 8f 76       	call   0x768f:0x5b8d
    764d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    7652:	76 18                	jbe    0x766c
    7654:	8d be 00 ff          	lea    di,[bp-0x100]
    7658:	16                   	push   ss
    7659:	57                   	push   di
    765a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    765e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7663:	06                   	push   es
    7664:	57                   	push   di
    7665:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7668:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    766c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7671:	8d be 00 ff          	lea    di,[bp-0x100]
    7675:	16                   	push   ss
    7676:	57                   	push   di
    7677:	68 ff 00             	push   0xff
    767a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    767d:	26 ff b5 5a 06       	push   WORD PTR es:[di+0x65a]
    7682:	26 ff b5 58 06       	push   WORD PTR es:[di+0x658]
    7687:	ff 36 42 02          	push   WORD PTR ds:0x242
    768b:	55                   	push   bp
    768c:	9a 8d 5b af 76       	call   0x76af:0x5b8d
    7691:	8d be 00 ff          	lea    di,[bp-0x100]
    7695:	16                   	push   ss
    7696:	57                   	push   di
    7697:	68 ff 00             	push   0xff
    769a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    769d:	26 ff b5 72 06       	push   WORD PTR es:[di+0x672]
    76a2:	26 ff b5 70 06       	push   WORD PTR es:[di+0x670]
    76a7:	ff 36 44 02          	push   WORD PTR ds:0x244
    76ab:	55                   	push   bp
    76ac:	9a 8d 5b cf 76       	call   0x76cf:0x5b8d
    76b1:	8d be 00 ff          	lea    di,[bp-0x100]
    76b5:	16                   	push   ss
    76b6:	57                   	push   di
    76b7:	68 ff 00             	push   0xff
    76ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76bd:	26 ff b5 06 06       	push   WORD PTR es:[di+0x606]
    76c2:	26 ff b5 04 06       	push   WORD PTR es:[di+0x604]
    76c7:	ff 36 46 02          	push   WORD PTR ds:0x246
    76cb:	55                   	push   bp
    76cc:	9a 8d 5b ef 76       	call   0x76ef:0x5b8d
    76d1:	8d be 00 ff          	lea    di,[bp-0x100]
    76d5:	16                   	push   ss
    76d6:	57                   	push   di
    76d7:	68 ff 00             	push   0xff
    76da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    76dd:	26 ff b5 4e 06       	push   WORD PTR es:[di+0x64e]
    76e2:	26 ff b5 4c 06       	push   WORD PTR es:[di+0x64c]
    76e7:	ff 36 48 02          	push   WORD PTR ds:0x248
    76eb:	55                   	push   bp
    76ec:	9a 8d 5b 33 77       	call   0x7733:0x5b8d
    76f1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    76f6:	76 18                	jbe    0x7710
    76f8:	8d be 00 ff          	lea    di,[bp-0x100]
    76fc:	16                   	push   ss
    76fd:	57                   	push   di
    76fe:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    7702:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    7707:	06                   	push   es
    7708:	57                   	push   di
    7709:	26 c4 3d             	les    di,DWORD PTR es:[di]
    770c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    7710:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    7715:	8d be 00 ff          	lea    di,[bp-0x100]
    7719:	16                   	push   ss
    771a:	57                   	push   di
    771b:	68 ff 00             	push   0xff
    771e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7721:	26 ff b5 56 06       	push   WORD PTR es:[di+0x656]
    7726:	26 ff b5 54 06       	push   WORD PTR es:[di+0x654]
    772b:	ff 36 42 02          	push   WORD PTR ds:0x242
    772f:	55                   	push   bp
    7730:	9a 8d 5b 7c 77       	call   0x777c:0x5b8d
    7735:	8d be fc fd          	lea    di,[bp-0x204]
    7739:	16                   	push   ss
    773a:	57                   	push   di
    773b:	8d be 00 ff          	lea    di,[bp-0x100]
    773f:	16                   	push   ss
    7740:	57                   	push   di
    7741:	9a cd 17 4e 77       	call   0x774e:0x17cd
    7746:	bf 85 5e             	mov    di,0x5e85
    7749:	0e                   	push   cs
    774a:	57                   	push   di
    774b:	9a 4c 18 5c 77       	call   0x775c:0x184c
    7750:	8d be 00 ff          	lea    di,[bp-0x100]
    7754:	16                   	push   ss
    7755:	57                   	push   di
    7756:	68 ff 00             	push   0xff
    7759:	9a e7 17 c9 77       	call   0x77c9:0x17e7
    775e:	8d be 00 ff          	lea    di,[bp-0x100]
    7762:	16                   	push   ss
    7763:	57                   	push   di
    7764:	68 ff 00             	push   0xff
    7767:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    776a:	26 ff b5 1a 06       	push   WORD PTR es:[di+0x61a]
    776f:	26 ff b5 18 06       	push   WORD PTR es:[di+0x618]
    7774:	ff 36 46 02          	push   WORD PTR ds:0x246
    7778:	55                   	push   bp
    7779:	9a 8d 5b 9c 77       	call   0x779c:0x5b8d
    777e:	8d be 00 ff          	lea    di,[bp-0x100]
    7782:	16                   	push   ss
    7783:	57                   	push   di
    7784:	68 ff 00             	push   0xff
    7787:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    778a:	26 ff b5 52 06       	push   WORD PTR es:[di+0x652]
    778f:	26 ff b5 50 06       	push   WORD PTR es:[di+0x650]
    7794:	ff 36 48 02          	push   WORD PTR ds:0x248
    7798:	55                   	push   bp
    7799:	9a 8d 5b ff ff       	call   0xffff:0x5b8d
    779e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    77a3:	76 18                	jbe    0x77bd
    77a5:	8d be 00 ff          	lea    di,[bp-0x100]
    77a9:	16                   	push   ss
    77aa:	57                   	push   di
    77ab:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    77af:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    77b4:	06                   	push   es
    77b5:	57                   	push   di
    77b6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    77b9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    77bd:	c9                   	leave
    77be:	ca 06 00             	retf   0x6
    77c1:	55                   	push   bp
    77c2:	89 e5                	mov    bp,sp
    77c4:	31 c0                	xor    ax,ax
    77c6:	9a 44 04 f7 77       	call   0x77f7:0x444
    77cb:	c7 06 44 01 15 00    	mov    WORD PTR ds:0x144,0x15
    77d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    77d4:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    77d9:	a3 46 01             	mov    ds:0x146,ax
    77dc:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    77e1:	a3 48 01             	mov    ds:0x148,ax
    77e4:	06                   	push   es
    77e5:	57                   	push   di
    77e6:	9a 56 55 17 78       	call   0x7817:0x5556
    77eb:	c9                   	leave
    77ec:	ca 08 00             	retf   0x8
    77ef:	55                   	push   bp
    77f0:	89 e5                	mov    bp,sp
    77f2:	31 c0                	xor    ax,ax
    77f4:	9a 44 04 25 78       	call   0x7825:0x444
    77f9:	c7 06 44 01 16 00    	mov    WORD PTR ds:0x144,0x16
    77ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7802:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    7807:	a3 46 01             	mov    ds:0x146,ax
    780a:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    780f:	a3 48 01             	mov    ds:0x148,ax
    7812:	06                   	push   es
    7813:	57                   	push   di
    7814:	9a 56 55 45 78       	call   0x7845:0x5556
    7819:	c9                   	leave
    781a:	ca 08 00             	retf   0x8
    781d:	55                   	push   bp
    781e:	89 e5                	mov    bp,sp
    7820:	31 c0                	xor    ax,ax
    7822:	9a 44 04 53 78       	call   0x7853:0x444
    7827:	c7 06 44 01 17 00    	mov    WORD PTR ds:0x144,0x17
    782d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7830:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    7835:	a3 46 01             	mov    ds:0x146,ax
    7838:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    783d:	a3 48 01             	mov    ds:0x148,ax
    7840:	06                   	push   es
    7841:	57                   	push   di
    7842:	9a 56 55 73 78       	call   0x7873:0x5556
    7847:	c9                   	leave
    7848:	ca 08 00             	retf   0x8
    784b:	55                   	push   bp
    784c:	89 e5                	mov    bp,sp
    784e:	31 c0                	xor    ax,ax
    7850:	9a 44 04 81 78       	call   0x7881:0x444
    7855:	c7 06 44 01 18 00    	mov    WORD PTR ds:0x144,0x18
    785b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    785e:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    7863:	a3 46 01             	mov    ds:0x146,ax
    7866:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    786b:	a3 48 01             	mov    ds:0x148,ax
    786e:	06                   	push   es
    786f:	57                   	push   di
    7870:	9a 56 55 a1 78       	call   0x78a1:0x5556
    7875:	c9                   	leave
    7876:	ca 08 00             	retf   0x8
    7879:	55                   	push   bp
    787a:	89 e5                	mov    bp,sp
    787c:	31 c0                	xor    ax,ax
    787e:	9a 44 04 af 78       	call   0x78af:0x444
    7883:	c7 06 44 01 19 00    	mov    WORD PTR ds:0x144,0x19
    7889:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    788c:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    7891:	a3 46 01             	mov    ds:0x146,ax
    7894:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    7899:	a3 48 01             	mov    ds:0x148,ax
    789c:	06                   	push   es
    789d:	57                   	push   di
    789e:	9a 56 55 cf 78       	call   0x78cf:0x5556
    78a3:	c9                   	leave
    78a4:	ca 08 00             	retf   0x8
    78a7:	55                   	push   bp
    78a8:	89 e5                	mov    bp,sp
    78aa:	31 c0                	xor    ax,ax
    78ac:	9a 44 04 dd 78       	call   0x78dd:0x444
    78b1:	c7 06 44 01 1a 00    	mov    WORD PTR ds:0x144,0x1a
    78b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78ba:	26 8b 85 f4 07       	mov    ax,WORD PTR es:[di+0x7f4]
    78bf:	a3 46 01             	mov    ds:0x146,ax
    78c2:	26 8b 85 f2 07       	mov    ax,WORD PTR es:[di+0x7f2]
    78c7:	a3 48 01             	mov    ds:0x148,ax
    78ca:	06                   	push   es
    78cb:	57                   	push   di
    78cc:	9a 56 55 ff ff       	call   0xffff:0x5556
    78d1:	c9                   	leave
    78d2:	ca 08 00             	retf   0x8
    78d5:	55                   	push   bp
    78d6:	89 e5                	mov    bp,sp
    78d8:	31 c0                	xor    ax,ax
    78da:	9a 44 04 ff ff       	call   0xffff:0x444
    78df:	ff 36 50 01          	push   WORD PTR ds:0x150
    78e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    78e6:	26 ff b5 f2 07       	push   WORD PTR es:[di+0x7f2]
    78eb:	26 ff b5 f4 07       	push   WORD PTR es:[di+0x7f4]
    78f0:	9a a1 0c ff ff       	call   0xffff:0xca1
    78f5:	c9                   	leave
    78f6:	ca                   	.byte 0xca
    78f7:	08                   	.byte 0x8
