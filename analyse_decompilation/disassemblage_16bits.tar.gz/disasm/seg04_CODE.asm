; ================================================================
; seg04_CODE  (45048 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	04 00                	add    al,0x0
       2:	9a 02 0d 01 b2       	call   0xb201:0xd02
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 9e 00 ea          	add    BYTE PTR [bp-0x1600],bl
       d:	01 fb                	add    bx,di
       f:	04 b5                	add    al,0xb5
      11:	02 39                	add    bh,BYTE PTR [bx+di]
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 0c 03 cb       	call   0xcb03:0xc1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 ff                	adc    bh,bh
      2d:	ff d6                	call   si
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 38                	sbb    al,0x38
      61:	03 e2                	add    sp,dx
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	13 54 46             	adc    dx,WORD PTR [si+0x46]
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	4a                   	dec    dx
      a6:	44                   	inc    sp
      a7:	41                   	inc    cx
      a8:	5f                   	pop    di
      a9:	41                   	inc    cx
      aa:	72 62                	jb     0x10e
      ac:	69 74 72 61 67       	imul   si,WORD PTR [si+0x72],0x6761
      b1:	65 05 00 70          	gs add ax,0x7000
      b5:	09 c5                	or     bp,ax
      b7:	00 0a                	add    BYTE PTR [bp+si],cl
      b9:	46                   	inc    si
      ba:	6f                   	outs   dx,WORD PTR ds:[si]
      bb:	72 6d                	jb     0x12a
      bd:	43                   	inc    bx
      be:	72 65                	jb     0x125
      c0:	61                   	popa
      c1:	74 65                	je     0x128
      c3:	0b 0e dd 00          	or     cx,WORD PTR ds:0xdd
      c7:	13 42 69             	adc    ax,WORD PTR [bp+si+0x69]
      ca:	74 42                	je     0x10e
      cc:	74 6e                	je     0x13c
      ce:	41                   	inc    cx
      cf:	72 62                	jb     0x133
      d1:	69 74 72 65 72       	imul   si,WORD PTR [si+0x72],0x7265
      d6:	43                   	inc    bx
      d7:	6c                   	ins    BYTE PTR es:[di],dx
      d8:	69 63 6b e1 0a       	imul   sp,WORD PTR [bp+di+0x6b],0xae1
      dd:	ee                   	out    dx,al
      de:	00 0c                	add    BYTE PTR [si],cl
      e0:	42                   	inc    dx
      e1:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
      e6:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
      e9:	69 63 6b a7 0a       	imul   sp,WORD PTR [bp+di+0x6b],0xaa7
      ee:	fc                   	cld
      ef:	00 09                	add    BYTE PTR [bx+di],cl
      f1:	46                   	inc    si
      f2:	6f                   	outs   dx,WORD PTR ds:[si]
      f3:	72 6d                	jb     0x162
      f5:	43                   	inc    bx
      f6:	6c                   	ins    BYTE PTR es:[di],dx
      f7:	6f                   	outs   dx,WORD PTR ds:[si]
      f8:	73 65                	jae    0x15f
      fa:	cc                   	int3
      fb:	0a b1 02 0e          	or     dh,BYTE PTR [bx+di+0xe02]
      ff:	46                   	inc    si
     100:	6f                   	outs   dx,WORD PTR ds:[si]
     101:	72 6d                	jb     0x170
     103:	43                   	inc    bx
     104:	6c                   	ins    BYTE PTR es:[di],dx
     105:	6f                   	outs   dx,WORD PTR ds:[si]
     106:	73 65                	jae    0x16d
     108:	51                   	push   cx
     109:	75 65                	jne    0x170
     10b:	72 79                	jb     0x186
     10d:	1b 00                	sbb    ax,WORD PTR [bx+si]
     10f:	80 02 7c             	add    BYTE PTR [bp+si],0x7c
     112:	01 00                	add    WORD PTR [bx+si],ax
     114:	00 08                	add    BYTE PTR [bx+si],cl
     116:	54                   	push   sp
     117:	61                   	popa
     118:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     11b:	41                   	inc    cx
     11c:	43                   	inc    bx
     11d:	47                   	inc    di
     11e:	80 01 00             	add    BYTE PTR [bx+di],0x0
     121:	00 08                	add    BYTE PTR [bx+si],cl
     123:	54                   	push   sp
     124:	61                   	popa
     125:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     128:	41                   	inc    cx
     129:	44                   	inc    sp
     12a:	47                   	inc    di
     12b:	84 01                	test   BYTE PTR [bx+di],al
     12d:	00 00                	add    BYTE PTR [bx+si],al
     12f:	08 54 61             	or     BYTE PTR [si+0x61],dl
     132:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     135:	41                   	inc    cx
     136:	44                   	inc    sp
     137:	50                   	push   ax
     138:	88 01                	mov    BYTE PTR [bx+di],al
     13a:	00 00                	add    BYTE PTR [bx+si],al
     13c:	08 54 61             	or     BYTE PTR [si+0x61],dl
     13f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     142:	45                   	inc    bp
     143:	44                   	inc    sp
     144:	47                   	inc    di
     145:	8c 01                	mov    WORD PTR [bx+di],es
     147:	00 00                	add    BYTE PTR [bx+si],al
     149:	08 54 61             	or     BYTE PTR [si+0x61],dl
     14c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     14f:	45                   	inc    bp
     150:	44                   	inc    sp
     151:	50                   	push   ax
     152:	90                   	nop
     153:	01 00                	add    WORD PTR [bx+si],ax
     155:	00 08                	add    BYTE PTR [bx+si],cl
     157:	54                   	push   sp
     158:	61                   	popa
     159:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     15c:	45                   	inc    bp
     15d:	52                   	push   dx
     15e:	47                   	inc    di
     15f:	94                   	xchg   sp,ax
     160:	01 00                	add    WORD PTR [bx+si],ax
     162:	00 08                	add    BYTE PTR [bx+si],cl
     164:	54                   	push   sp
     165:	61                   	popa
     166:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     169:	45                   	inc    bp
     16a:	52                   	push   dx
     16b:	50                   	push   ax
     16c:	98                   	cbw
     16d:	01 00                	add    WORD PTR [bx+si],ax
     16f:	00 08                	add    BYTE PTR [bx+si],cl
     171:	54                   	push   sp
     172:	61                   	popa
     173:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     176:	41                   	inc    cx
     177:	43                   	inc    bx
     178:	50                   	push   ax
     179:	9c                   	pushf
     17a:	01 04                	add    WORD PTR [si],ax
     17c:	00 09                	add    BYTE PTR [bx+di],cl
     17e:	47                   	inc    di
     17f:	72 6f                	jb     0x1f0
     181:	75 70                	jne    0x1f3
     183:	42                   	inc    dx
     184:	6f                   	outs   dx,WORD PTR ds:[si]
     185:	78 31                	js     0x1b8
     187:	a0 01 08             	mov    al,ds:0x801
     18a:	00 09                	add    BYTE PTR [bx+di],cl
     18c:	43                   	inc    bx
     18d:	68 65 63             	push   0x6365
     190:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     194:	41                   	inc    cx
     195:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     196:	01 08                	add    WORD PTR [bx+si],cx
     198:	00 0a                	add    BYTE PTR [bp+si],cl
     19a:	43                   	inc    bx
     19b:	68 65 63             	push   0x6365
     19e:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     1a2:	45                   	inc    bp
     1a3:	31 a8 01 08          	xor    WORD PTR [bx+si+0x801],bp
     1a7:	00 0a                	add    BYTE PTR [bp+si],cl
     1a9:	43                   	inc    bx
     1aa:	68 65 63             	push   0x6365
     1ad:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     1b1:	45                   	inc    bp
     1b2:	32 ac 01 08          	xor    ch,BYTE PTR [si+0x801]
     1b6:	00 0a                	add    BYTE PTR [bp+si],cl
     1b8:	43                   	inc    bx
     1b9:	68 65 63             	push   0x6365
     1bc:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     1c0:	45                   	inc    bp
     1c1:	33 b0 01 08          	xor    si,WORD PTR [bx+si+0x801]
     1c5:	00 0a                	add    BYTE PTR [bp+si],cl
     1c7:	43                   	inc    bx
     1c8:	68 65 63             	push   0x6365
     1cb:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     1cf:	45                   	inc    bp
     1d0:	34 b4                	xor    al,0xb4
     1d2:	01 08                	add    WORD PTR [bx+si],cx
     1d4:	00 0a                	add    BYTE PTR [bp+si],cl
     1d6:	43                   	inc    bx
     1d7:	68 65 63             	push   0x6365
     1da:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     1de:	45                   	inc    bp
     1df:	35 b8 01             	xor    ax,0x1b8
     1e2:	08 00                	or     BYTE PTR [bx+si],al
     1e4:	0a 43 68             	or     al,BYTE PTR [bp+di+0x68]
     1e7:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     1eb:	6f                   	outs   dx,WORD PTR ds:[si]
     1ec:	78 45                	js     0x233
     1ee:	36 bc 01 08          	ss mov sp,0x801
     1f2:	00 0a                	add    BYTE PTR [bp+si],cl
     1f4:	43                   	inc    bx
     1f5:	68 65 63             	push   0x6365
     1f8:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     1fc:	45                   	inc    bp
     1fd:	37                   	aaa
     1fe:	c0 01 08             	rol    BYTE PTR [bx+di],0x8
     201:	00 0a                	add    BYTE PTR [bp+si],cl
     203:	43                   	inc    bx
     204:	68 65 63             	push   0x6365
     207:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     20b:	45                   	inc    bp
     20c:	38 c4                	cmp    ah,al
     20e:	01 0c                	add    WORD PTR [si],cx
     210:	00 0e 42 69          	add    BYTE PTR ds:0x6942,cl
     214:	74 42                	je     0x258
     216:	74 6e                	je     0x286
     218:	41                   	inc    cx
     219:	72 62                	jb     0x27d
     21b:	69 74 72 65 72       	imul   si,WORD PTR [si+0x72],0x7265
     220:	c8 01 0c 00          	enter  0xc01,0x0
     224:	07                   	pop    es
     225:	42                   	inc    dx
     226:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
     22b:	32 cc                	xor    cl,ah
     22d:	01 10                	add    WORD PTR [bx+si],dx
     22f:	00 05                	add    BYTE PTR [di],al
     231:	4d                   	dec    bp
     232:	65 6d                	gs ins WORD PTR es:[di],dx
     234:	6f                   	outs   dx,WORD PTR ds:[si]
     235:	31 d0                	xor    ax,dx
     237:	01 14                	add    WORD PTR [si],dx
     239:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     23d:	6e                   	outs   dx,BYTE PTR ds:[si]
     23e:	65 6c                	gs ins BYTE PTR es:[di],dx
     240:	31 d4                	xor    sp,dx
     242:	01 00                	add    WORD PTR [bx+si],ax
     244:	00 09                	add    BYTE PTR [bx+di],cl
     246:	54                   	push   sp
     247:	61                   	popa
     248:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     24b:	4d                   	dec    bp
     24c:	41                   	inc    cx
     24d:	49                   	dec    cx
     24e:	4e                   	dec    si
     24f:	d8 01                	fadd   DWORD PTR [bx+di]
     251:	00 00                	add    BYTE PTR [bx+si],al
     253:	08 54 61             	or     BYTE PTR [si+0x61],dl
     256:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     259:	45                   	inc    bp
     25a:	44                   	inc    sp
     25b:	4d                   	dec    bp
     25c:	dc 01                	fadd   QWORD PTR [bx+di]
     25e:	14 00                	adc    al,0x0
     260:	06                   	push   es
     261:	50                   	push   ax
     262:	61                   	popa
     263:	6e                   	outs   dx,BYTE PTR ds:[si]
     264:	65 6c                	gs ins BYTE PTR es:[di],dx
     266:	32 e0                	xor    ah,al
     268:	01 00                	add    WORD PTR [bx+si],ax
     26a:	00 08                	add    BYTE PTR [bx+si],cl
     26c:	54                   	push   sp
     26d:	61                   	popa
     26e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     271:	4d                   	dec    bp
     272:	52                   	push   dx
     273:	50                   	push   ax
     274:	e4 01                	in     al,0x1
     276:	0c 00                	or     al,0x0
     278:	07                   	pop    es
     279:	42                   	inc    dx
     27a:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
     27f:	31 06 00 38          	xor    WORD PTR ds:0x3800,ax
     283:	01 07                	add    WORD PTR [bx],ax
     285:	05 0c 01             	add    ax,0x10c
     288:	8c 02                	mov    WORD PTR [bp+si],es
     28a:	22 27                	and    ah,BYTE PTR [bx]
     28c:	94                   	xchg   sp,ax
     28d:	02 ac 04 ff          	add    ch,BYTE PTR [si-0xfc]
     291:	ff 91 12 7b          	call   WORD PTR [bx+di+0x7b12]
     295:	0c ad                	or     al,0xad
     297:	0d ff ff             	or     ax,0xffff
     29a:	07                   	pop    es
     29b:	13 54 46             	adc    dx,WORD PTR [si+0x46]
     29e:	6f                   	outs   dx,WORD PTR ds:[si]
     29f:	72 6d                	jb     0x30e
     2a1:	53                   	push   bx
     2a2:	4a                   	dec    dx
     2a3:	44                   	inc    sp
     2a4:	41                   	inc    cx
     2a5:	5f                   	pop    di
     2a6:	41                   	inc    cx
     2a7:	72 62                	jb     0x30b
     2a9:	69 74 72 61 67       	imul   si,WORD PTR [si+0x72],0x6761
     2ae:	65 22 00             	and    al,BYTE PTR gs:[bx+si]
     2b1:	d7                   	xlat   BYTE PTR ds:[bx]
     2b2:	03 7b 06             	add    di,WORD PTR [bp+di+0x6]
     2b5:	c6 03 38             	mov    BYTE PTR [bp+di],0x38
     2b8:	00 04                	add    BYTE PTR [si],al
     2ba:	53                   	push   bx
     2bb:	6a 64                	push   0x64
     2bd:	61                   	popa
     2be:	00 00                	add    BYTE PTR [bx+si],al
     2c0:	0f 45 72 72          	cmovne si,WORD PTR [bp+si+0x72]
     2c4:	65 75 72             	gs jne 0x339
     2c7:	20 4d 41             	and    BYTE PTR [di+0x41],cl
     2ca:	4a                   	dec    dx
     2cb:	45                   	inc    bp
     2cc:	55                   	push   bp
     2cd:	52                   	push   dx
     2ce:	45                   	inc    bp
     2cf:	00 01                	add    BYTE PTR [bx+di],al
     2d1:	0d 1d 45             	or     ax,0x451d
     2d4:	6e                   	outs   dx,BYTE PTR ds:[si]
     2d5:	72 65                	jb     0x33c
     2d7:	67 69 73 74 72 65    	imul   si,WORD PTR [ebx+0x74],0x6572
     2dd:	6d                   	ins    WORD PTR es:[di],dx
     2de:	65 6e                	outs   dx,BYTE PTR gs:[si]
     2e0:	74 28                	je     0x30a
     2e2:	73 29                	jae    0x30d
     2e4:	20 6e 6f             	and    BYTE PTR [bp+0x6f],ch
     2e7:	6e                   	outs   dx,BYTE PTR ds:[si]
     2e8:	20 74 72             	and    BYTE PTR [si+0x72],dh
     2eb:	6f                   	outs   dx,WORD PTR ds:[si]
     2ec:	75 76                	jne    0x364
     2ee:	e9 2e 10             	jmp    0x131f
     2f1:	46                   	inc    si
     2f2:	65 72 6d             	gs jb  0x362
     2f5:	65 74 75             	gs je  0x36d
     2f8:	72 65                	jb     0x35f
     2fa:	20 64 75             	and    BYTE PTR [si+0x75],ah
     2fd:	20 4a 65             	and    BYTE PTR [bp+si+0x65],cl
     300:	75 01                	jne    0x303
     302:	00 55 89             	add    BYTE PTR [di-0x77],dl
     305:	e5 b8                	in     ax,0xb8
     307:	00 03                	add    BYTE PTR [bp+di],al
     309:	9a 44 04 28 03       	call   0x328:0x444
     30e:	81 ec 00 03          	sub    sp,0x300
     312:	c6 06 74 01 01       	mov    BYTE PTR ds:0x174,0x1
     317:	bf c0 02             	mov    di,0x2c0
     31a:	0e                   	push   cs
     31b:	57                   	push   di
     31c:	8d be 00 ff          	lea    di,[bp-0x100]
     320:	16                   	push   ss
     321:	57                   	push   di
     322:	68 ff 00             	push   0xff
     325:	9a e7 17 42 03       	call   0x342:0x17e7
     32a:	8d be 00 fd          	lea    di,[bp-0x300]
     32e:	16                   	push   ss
     32f:	57                   	push   di
     330:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     333:	06                   	push   es
     334:	57                   	push   di
     335:	9a 53 1d 96 03       	call   0x396:0x1d53
     33a:	bf d0 02             	mov    di,0x2d0
     33d:	0e                   	push   cs
     33e:	57                   	push   di
     33f:	9a 4c 18 4c 03       	call   0x34c:0x184c
     344:	bf d0 02             	mov    di,0x2d0
     347:	0e                   	push   cs
     348:	57                   	push   di
     349:	9a 4c 18 56 03       	call   0x356:0x184c
     34e:	bf d2 02             	mov    di,0x2d2
     351:	0e                   	push   cs
     352:	57                   	push   di
     353:	9a 4c 18 60 03       	call   0x360:0x184c
     358:	bf d0 02             	mov    di,0x2d0
     35b:	0e                   	push   cs
     35c:	57                   	push   di
     35d:	9a 4c 18 6a 03       	call   0x36a:0x184c
     362:	bf d0 02             	mov    di,0x2d0
     365:	0e                   	push   cs
     366:	57                   	push   di
     367:	9a 4c 18 74 03       	call   0x374:0x184c
     36c:	bf f0 02             	mov    di,0x2f0
     36f:	0e                   	push   cs
     370:	57                   	push   di
     371:	9a 4c 18 7e 03       	call   0x37e:0x184c
     376:	bf 01 03             	mov    di,0x301
     379:	0e                   	push   cs
     37a:	57                   	push   di
     37b:	9a 4c 18 8c 03       	call   0x38c:0x184c
     380:	8d be 00 fe          	lea    di,[bp-0x200]
     384:	16                   	push   ss
     385:	57                   	push   di
     386:	68 ff 00             	push   0xff
     389:	9a e7 17 e2 03       	call   0x3e2:0x17e7
     38e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     391:	06                   	push   es
     392:	57                   	push   di
     393:	9a b9 62 48 04       	call   0x448:0x62b9
     398:	50                   	push   ax
     399:	8d be 01 fe          	lea    di,[bp-0x1ff]
     39d:	16                   	push   ss
     39e:	57                   	push   di
     39f:	8d be 01 ff          	lea    di,[bp-0xff]
     3a3:	16                   	push   ss
     3a4:	57                   	push   di
     3a5:	6a 40                	push   0x40
     3a7:	9a 95 af 00 00       	call   0x0:0xaf95
     3ac:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     3b0:	06                   	push   es
     3b1:	57                   	push   di
     3b2:	9a c7 28 9a 0d       	call   0xd9a:0x28c7
     3b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     3ba:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     3c1:	06                   	push   es
     3c2:	57                   	push   di
     3c3:	9a 56 55 fe 03       	call   0x3fe:0x5556
     3c8:	9a c3 28 68 04       	call   0x468:0x28c3
     3cd:	c9                   	leave
     3ce:	ca 04 00             	retf   0x4
     3d1:	01 20                	add    WORD PTR [bx+si],sp
     3d3:	00 00                	add    BYTE PTR [bx+si],al
     3d5:	cd 04                	int    0x4
     3d7:	f7 03 55 89          	test   WORD PTR [bp+di],0x8955
     3db:	e5 b8                	in     ax,0xb8
     3dd:	0c 02                	or     al,0x2
     3df:	9a 44 04 52 04       	call   0x452:0x444
     3e4:	81 ec 0c 02          	sub    sp,0x20c
     3e8:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     3ec:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     3f0:	b0 01                	mov    al,0x1
     3f2:	50                   	push   ax
     3f3:	b8 22 00             	mov    ax,0x22
     3f6:	ba 22 04             	mov    dx,0x422
     3f9:	52                   	push   dx
     3fa:	50                   	push   ax
     3fb:	9a 53 25 bf 04       	call   0x4bf:0x2553
     400:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     403:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     406:	b8 d3 03             	mov    ax,0x3d3
     409:	0e                   	push   cs
     40a:	50                   	push   ax
     40b:	55                   	push   bp
     40c:	ff 36 58 18          	push   WORD PTR ds:0x1858
     410:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     414:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     417:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     41a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     41d:	06                   	push   es
     41e:	57                   	push   di
     41f:	9a da 04 86 04       	call   0x486:0x4da
     424:	a1 4c 01             	mov    ax,ds:0x14c
     427:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     42a:	26 89 85 e8 01       	mov    WORD PTR es:[di+0x1e8],ax
     42f:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
     434:	89 7e f4             	mov    WORD PTR [bp-0xc],di
     437:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
     43a:	8d be f4 fe          	lea    di,[bp-0x10c]
     43e:	16                   	push   ss
     43f:	57                   	push   di
     440:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     443:	06                   	push   es
     444:	57                   	push   di
     445:	9a 53 1d 77 04       	call   0x477:0x1d53
     44a:	bf d1 03             	mov    di,0x3d1
     44d:	0e                   	push   cs
     44e:	57                   	push   di
     44f:	9a 4c 18 6d 04       	call   0x46d:0x184c
     454:	8d be f4 fd          	lea    di,[bp-0x20c]
     458:	16                   	push   ss
     459:	57                   	push   di
     45a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     45d:	26 8b 85 e8 01       	mov    ax,WORD PTR es:[di+0x1e8]
     462:	99                   	cwd
     463:	52                   	push   dx
     464:	50                   	push   ax
     465:	9a a9 08 3f af       	call   0xaf3f:0x8a9
     46a:	9a 4c 18 e3 04       	call   0x4e3:0x184c
     46f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     472:	06                   	push   es
     473:	57                   	push   di
     474:	9a 8c 1d 9b 04       	call   0x49b:0x1d8c
     479:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     47c:	26 ff b5 e8 01       	push   WORD PTR es:[di+0x1e8]
     481:	06                   	push   es
     482:	57                   	push   di
     483:	9a 4f 0b b9 0a       	call   0xab9:0xb4f
     488:	08 c0                	or     al,al
     48a:	75 1a                	jne    0x4a6
     48c:	6a 00                	push   0x0
     48e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     491:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
     496:	06                   	push   es
     497:	57                   	push   di
     498:	9a b8 1c b5 04       	call   0x4b5:0x1cb8
     49d:	6a 00                	push   0x0
     49f:	9a ff ff 00 00       	call   0x0:0xffff
     4a4:	eb 11                	jmp    0x4b7
     4a6:	6a 00                	push   0x0
     4a8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     4ab:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
     4b0:	06                   	push   es
     4b1:	57                   	push   di
     4b2:	9a 77 1c b1 09       	call   0x9b1:0x1c77
     4b7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     4ba:	06                   	push   es
     4bb:	57                   	push   di
     4bc:	9a 45 5d d5 04       	call   0x4d5:0x5d45
     4c1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     4c5:	83 c4 06             	add    sp,0x6
     4c8:	b8 d8 04             	mov    ax,0x4d8
     4cb:	0e                   	push   cs
     4cc:	50                   	push   ax
     4cd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     4d0:	06                   	push   es
     4d1:	57                   	push   di
     4d2:	9a 1d 5f c6 0a       	call   0xac6:0x5f1d
     4d7:	cb                   	retf
     4d8:	c9                   	leave
     4d9:	cb                   	retf
     4da:	55                   	push   bp
     4db:	89 e5                	mov    bp,sp
     4dd:	b8 04 00             	mov    ax,0x4
     4e0:	9a 44 04 52 07       	call   0x752:0x444
     4e5:	83 ec 04             	sub    sp,0x4
     4e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     4eb:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
     4f0:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     4f3:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     4f6:	06                   	push   es
     4f7:	57                   	push   di
     4f8:	9a d2 31 1d 05       	call   0x51d:0x31d2
     4fd:	6a 00                	push   0x0
     4ff:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     502:	06                   	push   es
     503:	57                   	push   di
     504:	9a fb 2f 13 05       	call   0x513:0x2ffb
     509:	6a 01                	push   0x1
     50b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     50e:	06                   	push   es
     50f:	57                   	push   di
     510:	9a d2 2e 3e 05       	call   0x53e:0x2ed2
     515:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     518:	06                   	push   es
     519:	57                   	push   di
     51a:	9a bf 31 32 05       	call   0x532:0x31bf
     51f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     522:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     527:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     52a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     52d:	06                   	push   es
     52e:	57                   	push   di
     52f:	9a d2 31 54 05       	call   0x554:0x31d2
     534:	6a 01                	push   0x1
     536:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     539:	06                   	push   es
     53a:	57                   	push   di
     53b:	9a fb 2f 4a 05       	call   0x54a:0x2ffb
     540:	6a 00                	push   0x0
     542:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     545:	06                   	push   es
     546:	57                   	push   di
     547:	9a d2 2e 75 05       	call   0x575:0x2ed2
     54c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     54f:	06                   	push   es
     550:	57                   	push   di
     551:	9a bf 31 69 05       	call   0x569:0x31bf
     556:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     559:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
     55e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     561:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     564:	06                   	push   es
     565:	57                   	push   di
     566:	9a d2 31 8b 05       	call   0x58b:0x31d2
     56b:	6a 01                	push   0x1
     56d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     570:	06                   	push   es
     571:	57                   	push   di
     572:	9a fb 2f 81 05       	call   0x581:0x2ffb
     577:	6a 00                	push   0x0
     579:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     57c:	06                   	push   es
     57d:	57                   	push   di
     57e:	9a d2 2e ac 05       	call   0x5ac:0x2ed2
     583:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     586:	06                   	push   es
     587:	57                   	push   di
     588:	9a bf 31 a0 05       	call   0x5a0:0x31bf
     58d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     590:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
     595:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     598:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     59b:	06                   	push   es
     59c:	57                   	push   di
     59d:	9a d2 31 c2 05       	call   0x5c2:0x31d2
     5a2:	6a 00                	push   0x0
     5a4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     5a7:	06                   	push   es
     5a8:	57                   	push   di
     5a9:	9a fb 2f b8 05       	call   0x5b8:0x2ffb
     5ae:	6a 01                	push   0x1
     5b0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     5b3:	06                   	push   es
     5b4:	57                   	push   di
     5b5:	9a d2 2e e3 05       	call   0x5e3:0x2ed2
     5ba:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     5bd:	06                   	push   es
     5be:	57                   	push   di
     5bf:	9a bf 31 d7 05       	call   0x5d7:0x31bf
     5c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     5c7:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
     5cc:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     5cf:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     5d2:	06                   	push   es
     5d3:	57                   	push   di
     5d4:	9a d2 31 f9 05       	call   0x5f9:0x31d2
     5d9:	6a 00                	push   0x0
     5db:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     5de:	06                   	push   es
     5df:	57                   	push   di
     5e0:	9a fb 2f ef 05       	call   0x5ef:0x2ffb
     5e5:	6a 01                	push   0x1
     5e7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     5ea:	06                   	push   es
     5eb:	57                   	push   di
     5ec:	9a d2 2e 1a 06       	call   0x61a:0x2ed2
     5f1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     5f4:	06                   	push   es
     5f5:	57                   	push   di
     5f6:	9a bf 31 0e 06       	call   0x60e:0x31bf
     5fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     5fe:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
     603:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     606:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     609:	06                   	push   es
     60a:	57                   	push   di
     60b:	9a d2 31 30 06       	call   0x630:0x31d2
     610:	6a 00                	push   0x0
     612:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     615:	06                   	push   es
     616:	57                   	push   di
     617:	9a fb 2f 26 06       	call   0x626:0x2ffb
     61c:	6a 01                	push   0x1
     61e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     621:	06                   	push   es
     622:	57                   	push   di
     623:	9a d2 2e 51 06       	call   0x651:0x2ed2
     628:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     62b:	06                   	push   es
     62c:	57                   	push   di
     62d:	9a bf 31 45 06       	call   0x645:0x31bf
     632:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     635:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     63a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     63d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     640:	06                   	push   es
     641:	57                   	push   di
     642:	9a d2 31 67 06       	call   0x667:0x31d2
     647:	6a 00                	push   0x0
     649:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     64c:	06                   	push   es
     64d:	57                   	push   di
     64e:	9a fb 2f 5d 06       	call   0x65d:0x2ffb
     653:	6a 01                	push   0x1
     655:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     658:	06                   	push   es
     659:	57                   	push   di
     65a:	9a d2 2e 88 06       	call   0x688:0x2ed2
     65f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     662:	06                   	push   es
     663:	57                   	push   di
     664:	9a bf 31 7c 06       	call   0x67c:0x31bf
     669:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     66c:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
     671:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     674:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     677:	06                   	push   es
     678:	57                   	push   di
     679:	9a d2 31 9e 06       	call   0x69e:0x31d2
     67e:	6a 00                	push   0x0
     680:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     683:	06                   	push   es
     684:	57                   	push   di
     685:	9a fb 2f 94 06       	call   0x694:0x2ffb
     68a:	6a 01                	push   0x1
     68c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     68f:	06                   	push   es
     690:	57                   	push   di
     691:	9a d2 2e bf 06       	call   0x6bf:0x2ed2
     696:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     699:	06                   	push   es
     69a:	57                   	push   di
     69b:	9a bf 31 b3 06       	call   0x6b3:0x31bf
     6a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     6a3:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
     6a8:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     6ab:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     6ae:	06                   	push   es
     6af:	57                   	push   di
     6b0:	9a d2 31 d5 06       	call   0x6d5:0x31d2
     6b5:	6a 00                	push   0x0
     6b7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     6ba:	06                   	push   es
     6bb:	57                   	push   di
     6bc:	9a fb 2f cb 06       	call   0x6cb:0x2ffb
     6c1:	6a 01                	push   0x1
     6c3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     6c6:	06                   	push   es
     6c7:	57                   	push   di
     6c8:	9a d2 2e f6 06       	call   0x6f6:0x2ed2
     6cd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     6d0:	06                   	push   es
     6d1:	57                   	push   di
     6d2:	9a bf 31 ea 06       	call   0x6ea:0x31bf
     6d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     6da:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     6df:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     6e2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     6e5:	06                   	push   es
     6e6:	57                   	push   di
     6e7:	9a d2 31 0c 07       	call   0x70c:0x31d2
     6ec:	6a 00                	push   0x0
     6ee:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     6f1:	06                   	push   es
     6f2:	57                   	push   di
     6f3:	9a fb 2f 02 07       	call   0x702:0x2ffb
     6f8:	6a 01                	push   0x1
     6fa:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     6fd:	06                   	push   es
     6fe:	57                   	push   di
     6ff:	9a d2 2e 2d 07       	call   0x72d:0x2ed2
     704:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     707:	06                   	push   es
     708:	57                   	push   di
     709:	9a bf 31 21 07       	call   0x721:0x31bf
     70e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     711:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
     716:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     719:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     71c:	06                   	push   es
     71d:	57                   	push   di
     71e:	9a d2 31 43 07       	call   0x743:0x31d2
     723:	6a 00                	push   0x0
     725:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     728:	06                   	push   es
     729:	57                   	push   di
     72a:	9a fb 2f 39 07       	call   0x739:0x2ffb
     72f:	6a 01                	push   0x1
     731:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     734:	06                   	push   es
     735:	57                   	push   di
     736:	9a d2 2e 84 07       	call   0x784:0x2ed2
     73b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     73e:	06                   	push   es
     73f:	57                   	push   di
     740:	9a bf 31 6a 07       	call   0x76a:0x31bf
     745:	c9                   	leave
     746:	ca 04 00             	retf   0x4
     749:	55                   	push   bp
     74a:	89 e5                	mov    bp,sp
     74c:	b8 04 00             	mov    ax,0x4
     74f:	9a 44 04 79 09       	call   0x979:0x444
     754:	83 ec 04             	sub    sp,0x4
     757:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     75a:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
     75f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     762:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     765:	06                   	push   es
     766:	57                   	push   di
     767:	9a 02 32 78 07       	call   0x778:0x3202
     76c:	08 c0                	or     al,al
     76e:	74 16                	je     0x786
     770:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     773:	06                   	push   es
     774:	57                   	push   di
     775:	9a d2 31 99 07       	call   0x799:0x31d2
     77a:	6a 00                	push   0x0
     77c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     77f:	06                   	push   es
     780:	57                   	push   di
     781:	9a d2 2e b3 07       	call   0x7b3:0x2ed2
     786:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     789:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     78e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     791:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     794:	06                   	push   es
     795:	57                   	push   di
     796:	9a 02 32 a7 07       	call   0x7a7:0x3202
     79b:	08 c0                	or     al,al
     79d:	74 16                	je     0x7b5
     79f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     7a2:	06                   	push   es
     7a3:	57                   	push   di
     7a4:	9a d2 31 c8 07       	call   0x7c8:0x31d2
     7a9:	6a 00                	push   0x0
     7ab:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     7ae:	06                   	push   es
     7af:	57                   	push   di
     7b0:	9a d2 2e e2 07       	call   0x7e2:0x2ed2
     7b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7b8:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
     7bd:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     7c0:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     7c3:	06                   	push   es
     7c4:	57                   	push   di
     7c5:	9a 02 32 d6 07       	call   0x7d6:0x3202
     7ca:	08 c0                	or     al,al
     7cc:	74 16                	je     0x7e4
     7ce:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     7d1:	06                   	push   es
     7d2:	57                   	push   di
     7d3:	9a d2 31 f7 07       	call   0x7f7:0x31d2
     7d8:	6a 00                	push   0x0
     7da:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     7dd:	06                   	push   es
     7de:	57                   	push   di
     7df:	9a d2 2e 11 08       	call   0x811:0x2ed2
     7e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7e7:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
     7ec:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     7ef:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     7f2:	06                   	push   es
     7f3:	57                   	push   di
     7f4:	9a 02 32 05 08       	call   0x805:0x3202
     7f9:	08 c0                	or     al,al
     7fb:	74 16                	je     0x813
     7fd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     800:	06                   	push   es
     801:	57                   	push   di
     802:	9a d2 31 26 08       	call   0x826:0x31d2
     807:	6a 00                	push   0x0
     809:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     80c:	06                   	push   es
     80d:	57                   	push   di
     80e:	9a d2 2e 40 08       	call   0x840:0x2ed2
     813:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     816:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
     81b:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     81e:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     821:	06                   	push   es
     822:	57                   	push   di
     823:	9a 02 32 34 08       	call   0x834:0x3202
     828:	08 c0                	or     al,al
     82a:	74 16                	je     0x842
     82c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     82f:	06                   	push   es
     830:	57                   	push   di
     831:	9a d2 31 55 08       	call   0x855:0x31d2
     836:	6a 00                	push   0x0
     838:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     83b:	06                   	push   es
     83c:	57                   	push   di
     83d:	9a d2 2e 6f 08       	call   0x86f:0x2ed2
     842:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     845:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
     84a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     84d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     850:	06                   	push   es
     851:	57                   	push   di
     852:	9a 02 32 63 08       	call   0x863:0x3202
     857:	08 c0                	or     al,al
     859:	74 16                	je     0x871
     85b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     85e:	06                   	push   es
     85f:	57                   	push   di
     860:	9a d2 31 84 08       	call   0x884:0x31d2
     865:	6a 00                	push   0x0
     867:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     86a:	06                   	push   es
     86b:	57                   	push   di
     86c:	9a d2 2e 9e 08       	call   0x89e:0x2ed2
     871:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     874:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     879:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     87c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     87f:	06                   	push   es
     880:	57                   	push   di
     881:	9a 02 32 92 08       	call   0x892:0x3202
     886:	08 c0                	or     al,al
     888:	74 16                	je     0x8a0
     88a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     88d:	06                   	push   es
     88e:	57                   	push   di
     88f:	9a d2 31 b3 08       	call   0x8b3:0x31d2
     894:	6a 00                	push   0x0
     896:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     899:	06                   	push   es
     89a:	57                   	push   di
     89b:	9a d2 2e cd 08       	call   0x8cd:0x2ed2
     8a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8a3:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
     8a8:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     8ab:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     8ae:	06                   	push   es
     8af:	57                   	push   di
     8b0:	9a 02 32 c1 08       	call   0x8c1:0x3202
     8b5:	08 c0                	or     al,al
     8b7:	74 16                	je     0x8cf
     8b9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     8bc:	06                   	push   es
     8bd:	57                   	push   di
     8be:	9a d2 31 e2 08       	call   0x8e2:0x31d2
     8c3:	6a 00                	push   0x0
     8c5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     8c8:	06                   	push   es
     8c9:	57                   	push   di
     8ca:	9a d2 2e fc 08       	call   0x8fc:0x2ed2
     8cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8d2:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
     8d7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     8da:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     8dd:	06                   	push   es
     8de:	57                   	push   di
     8df:	9a 02 32 f0 08       	call   0x8f0:0x3202
     8e4:	08 c0                	or     al,al
     8e6:	74 16                	je     0x8fe
     8e8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     8eb:	06                   	push   es
     8ec:	57                   	push   di
     8ed:	9a d2 31 11 09       	call   0x911:0x31d2
     8f2:	6a 00                	push   0x0
     8f4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     8f7:	06                   	push   es
     8f8:	57                   	push   di
     8f9:	9a d2 2e 2b 09       	call   0x92b:0x2ed2
     8fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     901:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     906:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     909:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     90c:	06                   	push   es
     90d:	57                   	push   di
     90e:	9a 02 32 1f 09       	call   0x91f:0x3202
     913:	08 c0                	or     al,al
     915:	74 16                	je     0x92d
     917:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     91a:	06                   	push   es
     91b:	57                   	push   di
     91c:	9a d2 31 40 09       	call   0x940:0x31d2
     921:	6a 00                	push   0x0
     923:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     926:	06                   	push   es
     927:	57                   	push   di
     928:	9a d2 2e 5a 09       	call   0x95a:0x2ed2
     92d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     930:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
     935:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     938:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     93b:	06                   	push   es
     93c:	57                   	push   di
     93d:	9a 02 32 4e 09       	call   0x94e:0x3202
     942:	08 c0                	or     al,al
     944:	74 16                	je     0x95c
     946:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     949:	06                   	push   es
     94a:	57                   	push   di
     94b:	9a d2 31 63 0c       	call   0xc63:0x31d2
     950:	6a 00                	push   0x0
     952:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     955:	06                   	push   es
     956:	57                   	push   di
     957:	9a d2 2e d4 09       	call   0x9d4:0x2ed2
     95c:	c9                   	leave
     95d:	ca 04 00             	retf   0x4
     960:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
     963:	6d                   	ins    WORD PTR es:[di],dx
     964:	73 74                	jae    0x9da
     966:	72 61                	jb     0x9c9
     968:	74 20                	je     0x98a
     96a:	2d 20 03             	sub    ax,0x320
     96d:	20 2d                	and    BYTE PTR [di],ch
     96f:	20 55 89             	and    BYTE PTR [di-0x77],dl
     972:	e5 b8                	in     ax,0xb8
     974:	00 02                	add    BYTE PTR [bp+si],al
     976:	9a 44 04 8d 09       	call   0x98d:0x444
     97b:	81 ec 00 02          	sub    sp,0x200
     97f:	8d be 00 ff          	lea    di,[bp-0x100]
     983:	16                   	push   ss
     984:	57                   	push   di
     985:	bf 60 09             	mov    di,0x960
     988:	0e                   	push   cs
     989:	57                   	push   di
     98a:	9a cd 17 97 09       	call   0x997:0x17cd
     98f:	bf fa 1d             	mov    di,0x1dfa
     992:	1e                   	push   ds
     993:	57                   	push   di
     994:	9a 4c 18 a1 09       	call   0x9a1:0x184c
     999:	bf 6c 09             	mov    di,0x96c
     99c:	0e                   	push   cs
     99d:	57                   	push   di
     99e:	9a 4c 18 b6 09       	call   0x9b6:0x184c
     9a3:	8d be 00 fe          	lea    di,[bp-0x200]
     9a7:	16                   	push   ss
     9a8:	57                   	push   di
     9a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9ac:	06                   	push   es
     9ad:	57                   	push   di
     9ae:	9a 53 1d c0 09       	call   0x9c0:0x1d53
     9b3:	9a 4c 18 af 0a       	call   0xaaf:0x184c
     9b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9bb:	06                   	push   es
     9bc:	57                   	push   di
     9bd:	9a 8c 1d d4 0d       	call   0xdd4:0x1d8c
     9c2:	bf 08 1e             	mov    di,0x1e08
     9c5:	1e                   	push   ds
     9c6:	57                   	push   di
     9c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9ca:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
     9cf:	06                   	push   es
     9d0:	57                   	push   di
     9d1:	9a 17 30 e8 09       	call   0x9e8:0x3017
     9d6:	bf 16 1e             	mov    di,0x1e16
     9d9:	1e                   	push   ds
     9da:	57                   	push   di
     9db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9de:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
     9e3:	06                   	push   es
     9e4:	57                   	push   di
     9e5:	9a 17 30 fc 09       	call   0x9fc:0x3017
     9ea:	bf 24 1e             	mov    di,0x1e24
     9ed:	1e                   	push   ds
     9ee:	57                   	push   di
     9ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9f2:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
     9f7:	06                   	push   es
     9f8:	57                   	push   di
     9f9:	9a 17 30 10 0a       	call   0xa10:0x3017
     9fe:	bf 32 1e             	mov    di,0x1e32
     a01:	1e                   	push   ds
     a02:	57                   	push   di
     a03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a06:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
     a0b:	06                   	push   es
     a0c:	57                   	push   di
     a0d:	9a 17 30 24 0a       	call   0xa24:0x3017
     a12:	bf 40 1e             	mov    di,0x1e40
     a15:	1e                   	push   ds
     a16:	57                   	push   di
     a17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a1a:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
     a1f:	06                   	push   es
     a20:	57                   	push   di
     a21:	9a 17 30 38 0a       	call   0xa38:0x3017
     a26:	bf 4e 1e             	mov    di,0x1e4e
     a29:	1e                   	push   ds
     a2a:	57                   	push   di
     a2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a2e:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
     a33:	06                   	push   es
     a34:	57                   	push   di
     a35:	9a 17 30 4c 0a       	call   0xa4c:0x3017
     a3a:	bf 5c 1e             	mov    di,0x1e5c
     a3d:	1e                   	push   ds
     a3e:	57                   	push   di
     a3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a42:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
     a47:	06                   	push   es
     a48:	57                   	push   di
     a49:	9a 17 30 60 0a       	call   0xa60:0x3017
     a4e:	bf 6a 1e             	mov    di,0x1e6a
     a51:	1e                   	push   ds
     a52:	57                   	push   di
     a53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a56:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
     a5b:	06                   	push   es
     a5c:	57                   	push   di
     a5d:	9a 17 30 74 0a       	call   0xa74:0x3017
     a62:	bf 78 1e             	mov    di,0x1e78
     a65:	1e                   	push   ds
     a66:	57                   	push   di
     a67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a6a:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
     a6f:	06                   	push   es
     a70:	57                   	push   di
     a71:	9a 17 30 88 0a       	call   0xa88:0x3017
     a76:	bf 86 1e             	mov    di,0x1e86
     a79:	1e                   	push   ds
     a7a:	57                   	push   di
     a7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a7e:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
     a83:	06                   	push   es
     a84:	57                   	push   di
     a85:	9a 17 30 9c 0a       	call   0xa9c:0x3017
     a8a:	bf 94 1e             	mov    di,0x1e94
     a8d:	1e                   	push   ds
     a8e:	57                   	push   di
     a8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a92:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
     a97:	06                   	push   es
     a98:	57                   	push   di
     a99:	9a 17 30 46 0c       	call   0xc46:0x3017
     a9e:	c6 06 74 01 00       	mov    BYTE PTR ds:0x174,0x0
     aa3:	c9                   	leave
     aa4:	ca 08 00             	retf   0x8
     aa7:	55                   	push   bp
     aa8:	89 e5                	mov    bp,sp
     aaa:	31 c0                	xor    ax,ax
     aac:	9a 44 04 d4 0a       	call   0xad4:0x444
     ab1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ab4:	06                   	push   es
     ab5:	57                   	push   di
     ab6:	9a 49 07 18 0b       	call   0xb18:0x749
     abb:	6a fe                	push   0xfffe
     abd:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
     ac1:	06                   	push   es
     ac2:	57                   	push   di
     ac3:	9a a9 63 03 0b       	call   0xb03:0x63a9
     ac8:	c9                   	leave
     ac9:	ca 0c 00             	retf   0xc
     acc:	55                   	push   bp
     acd:	89 e5                	mov    bp,sp
     acf:	31 c0                	xor    ax,ax
     ad1:	9a 44 04 e9 0a       	call   0xae9:0x444
     ad6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     ad9:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
     add:	c9                   	leave
     ade:	ca 0c 00             	retf   0xc
     ae1:	55                   	push   bp
     ae2:	89 e5                	mov    bp,sp
     ae4:	31 c0                	xor    ax,ax
     ae6:	9a 44 04 58 0b       	call   0xb58:0x444
     aeb:	6a 01                	push   0x1
     aed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     af0:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
     af5:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
     afa:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     afe:	06                   	push   es
     aff:	57                   	push   di
     b00:	9a b2 77 31 0e       	call   0xe31:0x77b2
     b05:	c9                   	leave
     b06:	ca 08 00             	retf   0x8
     b09:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
     b0c:	6c                   	ins    BYTE PTR es:[di],dx
     b0d:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
     b12:	6f                   	outs   dx,WORD PTR ds:[si]
     b13:	6e                   	outs   dx,BYTE PTR ds:[si]
     b14:	00 00                	add    BYTE PTR [bx+si],al
     b16:	89 0c                	mov    WORD PTR [si],cx
     b18:	31 0b                	xor    WORD PTR [bp+di],cx
     b1a:	00 00                	add    BYTE PTR [bx+si],al
     b1c:	00 00                	add    BYTE PTR [bx+si],al
     b1e:	08 00                	or     BYTE PTR [bx+si],al
     b20:	00 00                	add    BYTE PTR [bx+si],al
     b22:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
     b25:	6c                   	ins    BYTE PTR es:[di],dx
     b26:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
     b2b:	6f                   	outs   dx,WORD PTR ds:[si]
     b2c:	6e                   	outs   dx,BYTE PTR ds:[si]
     b2d:	00 00                	add    BYTE PTR [bx+si],al
     b2f:	46                   	inc    si
     b30:	0d 43 0b             	or     ax,0xb43
     b33:	00 00                	add    BYTE PTR [bx+si],al
     b35:	00 00                	add    BYTE PTR [bx+si],al
     b37:	08 00                	or     BYTE PTR [bx+si],al
     b39:	00 00                	add    BYTE PTR [bx+si],al
     b3b:	01 00                	add    WORD PTR [bx+si],ax
     b3d:	00 00                	add    BYTE PTR [bx+si],al
     b3f:	00 00                	add    BYTE PTR [bx+si],al
     b41:	e7 0d                	out    0xd,ax
     b43:	4d                   	dec    bp
     b44:	0b 01                	or     ax,WORD PTR [bx+di]
     b46:	00 00                	add    BYTE PTR [bx+si],al
     b48:	00 00                	add    BYTE PTR [bx+si],al
     b4a:	00 fa                	add    dl,bh
     b4c:	0d 54 0c             	or     ax,0xc54
     b4f:	55                   	push   bp
     b50:	89 e5                	mov    bp,sp
     b52:	b8 40 00             	mov    ax,0x40
     b55:	9a 44 04 21 0d       	call   0xd21:0x444
     b5a:	83 ec 40             	sub    sp,0x40
     b5d:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     b61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b64:	26 8b 85 a0 01       	mov    ax,WORD PTR es:[di+0x1a0]
     b69:	26 8b 95 a2 01       	mov    dx,WORD PTR es:[di+0x1a2]
     b6e:	89 46 da             	mov    WORD PTR [bp-0x26],ax
     b71:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
     b74:	26 8b 85 a4 01       	mov    ax,WORD PTR es:[di+0x1a4]
     b79:	26 8b 95 a6 01       	mov    dx,WORD PTR es:[di+0x1a6]
     b7e:	89 46 de             	mov    WORD PTR [bp-0x22],ax
     b81:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
     b84:	26 8b 85 a8 01       	mov    ax,WORD PTR es:[di+0x1a8]
     b89:	26 8b 95 aa 01       	mov    dx,WORD PTR es:[di+0x1aa]
     b8e:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
     b91:	89 56 e4             	mov    WORD PTR [bp-0x1c],dx
     b94:	26 8b 85 ac 01       	mov    ax,WORD PTR es:[di+0x1ac]
     b99:	26 8b 95 ae 01       	mov    dx,WORD PTR es:[di+0x1ae]
     b9e:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
     ba1:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
     ba4:	26 8b 85 b0 01       	mov    ax,WORD PTR es:[di+0x1b0]
     ba9:	26 8b 95 b2 01       	mov    dx,WORD PTR es:[di+0x1b2]
     bae:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
     bb1:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
     bb4:	26 8b 85 b4 01       	mov    ax,WORD PTR es:[di+0x1b4]
     bb9:	26 8b 95 b6 01       	mov    dx,WORD PTR es:[di+0x1b6]
     bbe:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
     bc1:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
     bc4:	26 8b 85 b8 01       	mov    ax,WORD PTR es:[di+0x1b8]
     bc9:	26 8b 95 ba 01       	mov    dx,WORD PTR es:[di+0x1ba]
     bce:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     bd1:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     bd4:	26 8b 85 bc 01       	mov    ax,WORD PTR es:[di+0x1bc]
     bd9:	26 8b 95 be 01       	mov    dx,WORD PTR es:[di+0x1be]
     bde:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     be1:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
     be4:	26 8b 85 c0 01       	mov    ax,WORD PTR es:[di+0x1c0]
     be9:	26 8b 95 c2 01       	mov    dx,WORD PTR es:[di+0x1c2]
     bee:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     bf1:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     bf4:	b8 45 0b             	mov    ax,0xb45
     bf7:	0e                   	push   cs
     bf8:	50                   	push   ax
     bf9:	55                   	push   bp
     bfa:	ff 36 58 18          	push   WORD PTR ds:0x1858
     bfe:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     c02:	b8 3b 0b             	mov    ax,0xb3b
     c05:	0e                   	push   cs
     c06:	50                   	push   ax
     c07:	55                   	push   bp
     c08:	ff 36 58 18          	push   WORD PTR ds:0x1858
     c0c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     c10:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
     c15:	89 7e d2             	mov    WORD PTR [bp-0x2e],di
     c18:	8c 46 d4             	mov    WORD PTR [bp-0x2c],es
     c1b:	b8 14 0b             	mov    ax,0xb14
     c1e:	0e                   	push   cs
     c1f:	50                   	push   ax
     c20:	55                   	push   bp
     c21:	ff 36 58 18          	push   WORD PTR ds:0x1858
     c25:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     c29:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     c2c:	99                   	cwd
     c2d:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
     c30:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
     c33:	c6 46 ce 00          	mov    BYTE PTR [bp-0x32],0x0
     c37:	8d 7e ca             	lea    di,[bp-0x36]
     c3a:	16                   	push   ss
     c3b:	57                   	push   di
     c3c:	6a 00                	push   0x0
     c3e:	c4 7e d2             	les    di,DWORD PTR [bp-0x2e]
     c41:	06                   	push   es
     c42:	57                   	push   di
     c43:	9a 95 28 ea 0c       	call   0xcea:0x2895
     c48:	08 c0                	or     al,al
     c4a:	75 0a                	jne    0xc56
     c4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c4f:	06                   	push   es
     c50:	57                   	push   di
     c51:	9a 03 03 f8 0c       	call   0xcf8:0x303
     c56:	bf 09 0b             	mov    di,0xb09
     c59:	0e                   	push   cs
     c5a:	57                   	push   di
     c5b:	c4 7e d2             	les    di,DWORD PTR [bp-0x2e]
     c5e:	06                   	push   es
     c5f:	57                   	push   di
     c60:	9a 9b 3b 07 0d       	call   0xd07:0x3b9b
     c65:	89 c7                	mov    di,ax
     c67:	8e c2                	mov    es,dx
     c69:	06                   	push   es
     c6a:	57                   	push   di
     c6b:	26 c4 3d             	les    di,DWORD PTR es:[di]
     c6e:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
     c72:	50                   	push   ax
     c73:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
     c76:	06                   	push   es
     c77:	57                   	push   di
     c78:	9a 11 6e 30 0d       	call   0xd30:0x6e11
     c7d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     c81:	83 c4 06             	add    sp,0x6
     c84:	b8 8a 0c             	mov    ax,0xc8a
     c87:	0e                   	push   cs
     c88:	50                   	push   ax
     c89:	cb                   	retf
     c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c8d:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
     c92:	89 7e d2             	mov    WORD PTR [bp-0x2e],di
     c95:	8c 46 d4             	mov    WORD PTR [bp-0x2c],es
     c98:	b8 2d 0b             	mov    ax,0xb2d
     c9b:	0e                   	push   cs
     c9c:	50                   	push   ax
     c9d:	55                   	push   bp
     c9e:	ff 36 58 18          	push   WORD PTR ds:0x1858
     ca2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     ca6:	a1 4e 01             	mov    ax,ds:0x14e
     ca9:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
     cac:	b8 01 00             	mov    ax,0x1
     caf:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
     cb2:	7e 03                	jle    0xcb7
     cb4:	e9 83 00             	jmp    0xd3a
     cb7:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     cba:	eb 03                	jmp    0xcbf
     cbc:	ff 46 d8             	inc    WORD PTR [bp-0x28]
     cbf:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     cc2:	99                   	cwd
     cc3:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
     cc6:	89 56 c2             	mov    WORD PTR [bp-0x3e],dx
     cc9:	c6 46 c4 00          	mov    BYTE PTR [bp-0x3c],0x0
     ccd:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     cd0:	99                   	cwd
     cd1:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
     cd4:	89 56 ca             	mov    WORD PTR [bp-0x36],dx
     cd7:	c6 46 cc 00          	mov    BYTE PTR [bp-0x34],0x0
     cdb:	8d 7e c0             	lea    di,[bp-0x40]
     cde:	16                   	push   ss
     cdf:	57                   	push   di
     ce0:	6a 01                	push   0x1
     ce2:	c4 7e d2             	les    di,DWORD PTR [bp-0x2e]
     ce5:	06                   	push   es
     ce6:	57                   	push   di
     ce7:	9a 95 28 4b 10       	call   0x104b:0x2895
     cec:	08 c0                	or     al,al
     cee:	75 0a                	jne    0xcfa
     cf0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cf3:	06                   	push   es
     cf4:	57                   	push   di
     cf5:	9a 03 03 4b 0e       	call   0xe4b:0x303
     cfa:	bf 22 0b             	mov    di,0xb22
     cfd:	0e                   	push   cs
     cfe:	57                   	push   di
     cff:	c4 7e d2             	les    di,DWORD PTR [bp-0x2e]
     d02:	06                   	push   es
     d03:	57                   	push   di
     d04:	9a 9b 3b 6d 10       	call   0x106d:0x3b9b
     d09:	89 c7                	mov    di,ax
     d0b:	8e c2                	mov    es,dx
     d0d:	06                   	push   es
     d0e:	57                   	push   di
     d0f:	26 c4 3d             	les    di,DWORD PTR es:[di]
     d12:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
     d16:	50                   	push   ax
     d17:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     d1a:	99                   	cwd
     d1b:	bf 1a 0b             	mov    di,0xb1a
     d1e:	9a 16 04 6a 0d       	call   0xd6a:0x416
     d23:	8b f8                	mov    di,ax
     d25:	c1 e7 02             	shl    di,0x2
     d28:	c4 7b da             	les    di,DWORD PTR [bp+di-0x26]
     d2b:	06                   	push   es
     d2c:	57                   	push   di
     d2d:	9a 11 6e 79 0d       	call   0xd79:0x6e11
     d32:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
     d35:	3b 46 d0             	cmp    ax,WORD PTR [bp-0x30]
     d38:	75 82                	jne    0xcbc
     d3a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     d3e:	83 c4 06             	add    sp,0x6
     d41:	b8 47 0d             	mov    ax,0xd47
     d44:	0e                   	push   cs
     d45:	50                   	push   ax
     d46:	cb                   	retf
     d47:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     d4b:	a1 4e 01             	mov    ax,ds:0x14e
     d4e:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
     d51:	31 c0                	xor    ax,ax
     d53:	3b 46 d4             	cmp    ax,WORD PTR [bp-0x2c]
     d56:	7f 31                	jg     0xd89
     d58:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
     d5b:	eb 03                	jmp    0xd60
     d5d:	ff 46 d6             	inc    WORD PTR [bp-0x2a]
     d60:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
     d63:	99                   	cwd
     d64:	bf 33 0b             	mov    di,0xb33
     d67:	9a 16 04 aa 0d       	call   0xdaa:0x416
     d6c:	8b f8                	mov    di,ax
     d6e:	c1 e7 02             	shl    di,0x2
     d71:	c4 7b da             	les    di,DWORD PTR [bp+di-0x26]
     d74:	06                   	push   es
     d75:	57                   	push   di
     d76:	9a d2 6d ff ff       	call   0xffff:0x6dd2
     d7b:	22 46 ff             	and    al,BYTE PTR [bp-0x1]
     d7e:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     d81:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
     d84:	3b 46 d4             	cmp    ax,WORD PTR [bp-0x2c]
     d87:	75 d4                	jne    0xd5d
     d89:	68 68 40             	push   0x4068
     d8c:	68 70 fd             	push   0xfd70
     d8f:	68 d7 a3             	push   0xa3d7
     d92:	68 3d 0a             	push   0xa3d
     d95:	6a 18                	push   0x18
     d97:	9a 69 0a 81 0e       	call   0xe81:0xa69
     d9c:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
     d9f:	a1 4e 01             	mov    ax,ds:0x14e
     da2:	05 01 00             	add    ax,0x1
     da5:	71 05                	jno    0xdac
     da7:	9a 3e 04 c5 0d       	call   0xdc5:0x43e
     dac:	3b 46 d4             	cmp    ax,WORD PTR [bp-0x2c]
     daf:	7f 2d                	jg     0xdde
     db1:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
     db4:	eb 03                	jmp    0xdb9
     db6:	ff 46 d6             	inc    WORD PTR [bp-0x2a]
     db9:	6a 00                	push   0x0
     dbb:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
     dbe:	99                   	cwd
     dbf:	bf 33 0b             	mov    di,0xb33
     dc2:	9a 16 04 ea 0d       	call   0xdea:0x416
     dc7:	8b f8                	mov    di,ax
     dc9:	c1 e7 02             	shl    di,0x2
     dcc:	c4 7b da             	les    di,DWORD PTR [bp+di-0x26]
     dcf:	06                   	push   es
     dd0:	57                   	push   di
     dd1:	9a 77 1c 24 0e       	call   0xe24:0x1c77
     dd6:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
     dd9:	3b 46 d4             	cmp    ax,WORD PTR [bp-0x2c]
     ddc:	75 d8                	jne    0xdb6
     dde:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     de2:	83 c4 06             	add    sp,0x6
     de5:	eb 0a                	jmp    0xdf1
     de7:	ea 85 13 ef 0d       	jmp    0xdef:0x1385
     dec:	9a 34 14 fd 0d       	call   0xdfd:0x1434
     df1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     df5:	83 c4 06             	add    sp,0x6
     df8:	eb 0a                	jmp    0xe04
     dfa:	ea 85 13 02 0e       	jmp    0xe02:0x1385
     dff:	9a 34 14 13 0e       	call   0xe13:0x1434
     e04:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     e07:	c9                   	leave
     e08:	ca 06 00             	retf   0x6
     e0b:	55                   	push   bp
     e0c:	89 e5                	mov    bp,sp
     e0e:	31 c0                	xor    ax,ax
     e10:	9a 44 04 6b 0e       	call   0xe6b:0x444
     e15:	6a 01                	push   0x1
     e17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e1a:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
     e1f:	06                   	push   es
     e20:	57                   	push   di
     e21:	9a 77 1c 83 af       	call   0xaf83:0x1c77
     e26:	6a f5                	push   0xfff5
     e28:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
     e2c:	06                   	push   es
     e2d:	57                   	push   di
     e2e:	9a a9 63 3c 0e       	call   0xe3c:0x63a9
     e33:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     e37:	06                   	push   es
     e38:	57                   	push   di
     e39:	9a 03 73 58 0e       	call   0xe58:0x7303
     e3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e41:	26 ff b5 e8 01       	push   WORD PTR es:[di+0x1e8]
     e46:	06                   	push   es
     e47:	57                   	push   di
     e48:	9a 2b ab ae 0f       	call   0xfae:0xab2b
     e4d:	6a 00                	push   0x0
     e4f:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
     e53:	06                   	push   es
     e54:	57                   	push   di
     e55:	9a a9 63 ff ff       	call   0xffff:0x63a9
     e5a:	c9                   	leave
     e5b:	ca 08 00             	retf   0x8
     e5e:	00 00                	add    BYTE PTR [bx+si],al
     e60:	80 3f 55             	cmp    BYTE PTR [bx],0x55
     e63:	89 e5                	mov    bp,sp
     e65:	b8 0c 00             	mov    ax,0xc
     e68:	9a 44 04 8d 0e       	call   0xe8d:0x444
     e6d:	83 ec 0c             	sub    sp,0xc
     e70:	68 73 40             	push   0x4073
     e73:	68 a3 10             	push   0x10a3
     e76:	68 0a d7             	push   0xd70a
     e79:	68 71 3d             	push   0x3d71
     e7c:	6a 0c                	push   0xc
     e7e:	9a 69 0a 4b 12       	call   0x124b:0xa69
     e83:	b9 04 00             	mov    cx,0x4
     e86:	f7 e9                	imul   cx
     e88:	71 05                	jno    0xe8f
     e8a:	9a 3e 04 a1 0e       	call   0xea1:0x43e
     e8f:	99                   	cwd
     e90:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     e93:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
     e96:	9b db 46 f4          	fild   DWORD PTR [bp-0xc]
     e9a:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
     e9e:	9a af 04 d1 0e       	call   0xed1:0x4af
     ea3:	9b df 46 0e          	fild   WORD PTR [bp+0xe]
     ea7:	9b de c9             	fmulp  st(1),st
     eaa:	9b 2e d8 06 5e 0e    	fadd   DWORD PTR cs:0xe5e
     eb0:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
     eb4:	90                   	nop
     eb5:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
     eba:	90                   	nop
     ebb:	9b                   	fwait
     ebc:	c9                   	leave
     ebd:	ca 0a 00             	retf   0xa
     ec0:	00 00                	add    BYTE PTR [bx+si],al
     ec2:	c8 42 00 00          	enter  0x42,0x0
     ec6:	80 3f 55             	cmp    BYTE PTR [bx],0x55
     ec9:	89 e5                	mov    bp,sp
     ecb:	b8 08 00             	mov    ax,0x8
     ece:	9a 44 04 e3 0e       	call   0xee3:0x444
     ed3:	83 ec 08             	sub    sp,0x8
     ed6:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
     eda:	9b 2e d9 06 c0 0e    	fld    DWORD PTR cs:0xec0
     ee0:	9a b2 04 2b 0f       	call   0xf2b:0x4b2
     ee5:	9b 2e d8 06 c4 0e    	fadd   DWORD PTR cs:0xec4
     eeb:	83 ec 08             	sub    sp,0x8
     eee:	89 e3                	mov    bx,sp
     ef0:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
     ef4:	90                   	nop
     ef5:	9b 9b df 46 0e       	fild   WORD PTR [bp+0xe]
     efa:	83 ec 08             	sub    sp,0x8
     efd:	89 e3                	mov    bx,sp
     eff:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
     f03:	90                   	nop
     f04:	9b                   	fwait
     f05:	9a 38 2f 4e 0f       	call   0xf4e:0x2f38
     f0a:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
     f0e:	90                   	nop
     f0f:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
     f14:	90                   	nop
     f15:	9b                   	fwait
     f16:	c9                   	leave
     f17:	ca 0a 00             	retf   0xa
     f1a:	00 00                	add    BYTE PTR [bx+si],al
     f1c:	00 40 00             	add    BYTE PTR [bx+si+0x0],al
     f1f:	00 80 3f 55          	add    BYTE PTR [bx+si+0x553f],al
     f23:	89 e5                	mov    bp,sp
     f25:	b8 10 00             	mov    ax,0x10
     f28:	9a 44 04 7f 0f       	call   0xf7f:0x444
     f2d:	83 ec 10             	sub    sp,0x10
     f30:	9b df 46 0e          	fild   WORD PTR [bp+0xe]
     f34:	83 ec 08             	sub    sp,0x8
     f37:	89 e3                	mov    bx,sp
     f39:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
     f3d:	90                   	nop
     f3e:	9b                   	fwait
     f3f:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f42:	ff 76 0a             	push   WORD PTR [bp+0xa]
     f45:	ff 76 08             	push   WORD PTR [bp+0x8]
     f48:	ff 76 06             	push   WORD PTR [bp+0x6]
     f4b:	9a a7 2e fe 11       	call   0x11fe:0x2ea7
     f50:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
     f54:	90                   	nop
     f55:	9b 9b dd 46 f0       	fld    QWORD PTR [bp-0x10]
     f5a:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
     f5e:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
     f62:	90                   	nop
     f63:	9b                   	fwait
     f64:	9b 2e d9 06 1a 0f    	fld    DWORD PTR cs:0xf1a
     f6a:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
     f6e:	9b dd 46 f0          	fld    QWORD PTR [bp-0x10]
     f72:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
     f76:	9b 2e d8 06 1e 0f    	fadd   DWORD PTR cs:0xf1e
     f7c:	9a b2 04 ff 0f       	call   0xfff:0x4b2
     f81:	9b 2e d8 06 1e 0f    	fadd   DWORD PTR cs:0xf1e
     f87:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
     f8b:	90                   	nop
     f8c:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
     f91:	90                   	nop
     f92:	9b                   	fwait
     f93:	c9                   	leave
     f94:	ca 0a 00             	retf   0xa
     f97:	12 49 6e             	adc    cl,BYTE PTR [bx+di+0x6e]
     f9a:	64 69 63 65 43 6f    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6f43
     fa0:	6e                   	outs   dx,BYTE PTR ds:[si]
     fa1:	6a 6f                	push   0x6f
     fa3:	6e                   	outs   dx,BYTE PTR ds:[si]
     fa4:	63 74 75             	arpl   WORD PTR [si+0x75],si
     fa7:	72 65                	jb     0x100e
     fa9:	6c                   	ins    BYTE PTR es:[di],dx
     faa:	00 00                	add    BYTE PTR [bx+si],al
     fac:	8e 10                	mov    ss,WORD PTR [bx+si]
     fae:	ec                   	in     al,dx
     faf:	0f 0d 44 65          	prefetch BYTE PTR [si+0x65]
     fb3:	6d                   	ins    WORD PTR es:[di],dx
     fb4:	61                   	popa
     fb5:	6e                   	outs   dx,BYTE PTR ds:[si]
     fb6:	64 65 50             	fs gs push ax
     fb9:	6f                   	outs   dx,WORD PTR ds:[si]
     fba:	74 45                	je     0x1001
     fbc:	6e                   	outs   dx,BYTE PTR ds:[si]
     fbd:	74 10                	je     0xfcf
     fbf:	44                   	inc    sp
     fc0:	65 6d                	gs ins WORD PTR es:[di],dx
     fc2:	61                   	popa
     fc3:	6e                   	outs   dx,BYTE PTR ds:[si]
     fc4:	64 65 50             	fs gs push ax
     fc7:	61                   	popa
     fc8:	72 61                	jb     0x102b
     fca:	6d                   	ins    WORD PTR es:[di],dx
     fcb:	65 74 72             	gs je  0x1040
     fce:	65 10 44 65          	adc    BYTE PTR gs:[si+0x65],al
     fd2:	6d                   	ins    WORD PTR es:[di],dx
     fd3:	61                   	popa
     fd4:	6e                   	outs   dx,BYTE PTR ds:[si]
     fd5:	64 65 45             	fs gs inc bp
     fd8:	76 6f                	jbe    0x1049
     fda:	6c                   	ins    BYTE PTR es:[di],dx
     fdb:	75 74                	jne    0x1051
     fdd:	69 6f 6e 00 80       	imul   bp,WORD PTR [bx+0x6e],0x8000
     fe2:	ff                   	(bad)
     fe3:	ff                   	(bad)
     fe4:	ff                   	(bad)
     fe5:	7f 00                	jg     0xfe7
     fe7:	00 00                	add    BYTE PTR [bx+si],al
     fe9:	00 4f 11             	add    BYTE PTR [bx+0x11],cl
     fec:	59                   	pop    cx
     fed:	10 00                	adc    BYTE PTR [bx+si],al
     fef:	00 00                	add    BYTE PTR [bx+si],al
     ff1:	00 00                	add    BYTE PTR [bx+si],al
     ff3:	00 80 3f 55          	add    BYTE PTR [bx+si+0x553f],al
     ff7:	89 e5                	mov    bp,sp
     ff9:	b8 42 00             	mov    ax,0x42
     ffc:	9a 44 04 3e 11       	call   0x113e:0x444
    1001:	83 ec 42             	sub    sp,0x42
    1004:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1007:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    100c:	89 7e ce             	mov    WORD PTR [bp-0x32],di
    100f:	8c 46 d0             	mov    WORD PTR [bp-0x30],es
    1012:	b8 aa 0f             	mov    ax,0xfaa
    1015:	0e                   	push   cs
    1016:	50                   	push   ax
    1017:	55                   	push   bp
    1018:	ff 36 58 18          	push   WORD PTR ds:0x1858
    101c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1020:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1023:	99                   	cwd
    1024:	89 46 be             	mov    WORD PTR [bp-0x42],ax
    1027:	89 56 c0             	mov    WORD PTR [bp-0x40],dx
    102a:	c6 46 c2 00          	mov    BYTE PTR [bp-0x3e],0x0
    102e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1031:	99                   	cwd
    1032:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    1035:	89 56 c8             	mov    WORD PTR [bp-0x38],dx
    1038:	c6 46 ca 00          	mov    BYTE PTR [bp-0x36],0x0
    103c:	8d 7e be             	lea    di,[bp-0x42]
    103f:	16                   	push   ss
    1040:	57                   	push   di
    1041:	6a 01                	push   0x1
    1043:	c4 7e ce             	les    di,DWORD PTR [bp-0x32]
    1046:	06                   	push   es
    1047:	57                   	push   di
    1048:	9a 95 28 c8 10       	call   0x10c8:0x2895
    104d:	08 c0                	or     al,al
    104f:	75 0a                	jne    0x105b
    1051:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1054:	06                   	push   es
    1055:	57                   	push   di
    1056:	9a 03 03 d6 10       	call   0x10d6:0x303
    105b:	bf 97 0f             	mov    di,0xf97
    105e:	0e                   	push   cs
    105f:	57                   	push   di
    1060:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1063:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    1068:	06                   	push   es
    1069:	57                   	push   di
    106a:	9a 9b 3b e5 10       	call   0x10e5:0x3b9b
    106f:	89 c7                	mov    di,ax
    1071:	8e c2                	mov    es,dx
    1073:	06                   	push   es
    1074:	57                   	push   di
    1075:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1078:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    107c:	9b dd 5e e2          	fstp   QWORD PTR [bp-0x1e]
    1080:	90                   	nop
    1081:	9b                   	fwait
    1082:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1086:	83 c4 06             	add    sp,0x6
    1089:	b8 8f 10             	mov    ax,0x108f
    108c:	0e                   	push   cs
    108d:	50                   	push   ax
    108e:	cb                   	retf
    108f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1092:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    1097:	89 7e ce             	mov    WORD PTR [bp-0x32],di
    109a:	8c 46 d0             	mov    WORD PTR [bp-0x30],es
    109d:	b8 e8 0f             	mov    ax,0xfe8
    10a0:	0e                   	push   cs
    10a1:	50                   	push   ax
    10a2:	55                   	push   bp
    10a3:	ff 36 58 18          	push   WORD PTR ds:0x1858
    10a7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    10ab:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10ae:	99                   	cwd
    10af:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    10b2:	89 56 c8             	mov    WORD PTR [bp-0x38],dx
    10b5:	c6 46 ca 00          	mov    BYTE PTR [bp-0x36],0x0
    10b9:	8d 7e c6             	lea    di,[bp-0x3a]
    10bc:	16                   	push   ss
    10bd:	57                   	push   di
    10be:	6a 00                	push   0x0
    10c0:	c4 7e ce             	les    di,DWORD PTR [bp-0x32]
    10c3:	06                   	push   es
    10c4:	57                   	push   di
    10c5:	9a 95 28 7a 19       	call   0x197a:0x2895
    10ca:	08 c0                	or     al,al
    10cc:	75 0a                	jne    0x10d8
    10ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10d1:	06                   	push   es
    10d2:	57                   	push   di
    10d3:	9a 03 03 6a 11       	call   0x116a:0x303
    10d8:	bf b0 0f             	mov    di,0xfb0
    10db:	0e                   	push   cs
    10dc:	57                   	push   di
    10dd:	c4 7e ce             	les    di,DWORD PTR [bp-0x32]
    10e0:	06                   	push   es
    10e1:	57                   	push   di
    10e2:	9a 9b 3b 07 11       	call   0x1107:0x3b9b
    10e7:	89 c7                	mov    di,ax
    10e9:	8e c2                	mov    es,dx
    10eb:	06                   	push   es
    10ec:	57                   	push   di
    10ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    10f0:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    10f4:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    10f7:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    10fa:	bf be 0f             	mov    di,0xfbe
    10fd:	0e                   	push   cs
    10fe:	57                   	push   di
    10ff:	c4 7e ce             	les    di,DWORD PTR [bp-0x32]
    1102:	06                   	push   es
    1103:	57                   	push   di
    1104:	9a 9b 3b 29 11       	call   0x1129:0x3b9b
    1109:	89 c7                	mov    di,ax
    110b:	8e c2                	mov    es,dx
    110d:	06                   	push   es
    110e:	57                   	push   di
    110f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1112:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1116:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    111a:	90                   	nop
    111b:	9b                   	fwait
    111c:	bf cf 0f             	mov    di,0xfcf
    111f:	0e                   	push   cs
    1120:	57                   	push   di
    1121:	c4 7e ce             	les    di,DWORD PTR [bp-0x32]
    1124:	06                   	push   es
    1125:	57                   	push   di
    1126:	9a 9b 3b 98 19       	call   0x1998:0x3b9b
    112b:	89 c7                	mov    di,ax
    112d:	8e c2                	mov    es,dx
    112f:	06                   	push   es
    1130:	57                   	push   di
    1131:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1134:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1138:	bf e0 0f             	mov    di,0xfe0
    113b:	9a 16 04 35 12       	call   0x1235:0x416
    1140:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    1143:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1147:	83 c4 06             	add    sp,0x6
    114a:	b8 50 11             	mov    ax,0x1150
    114d:	0e                   	push   cs
    114e:	50                   	push   ax
    114f:	cb                   	retf
    1150:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    1153:	3d 00 00             	cmp    ax,0x0
    1156:	75 1c                	jne    0x1174
    1158:	ff 76 0c             	push   WORD PTR [bp+0xc]
    115b:	ff 76 f2             	push   WORD PTR [bp-0xe]
    115e:	ff 76 f0             	push   WORD PTR [bp-0x10]
    1161:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1164:	ff 76 ec             	push   WORD PTR [bp-0x14]
    1167:	9a 62 0e 8b 11       	call   0x118b:0xe62
    116c:	9b dd 5e da          	fstp   QWORD PTR [bp-0x26]
    1170:	90                   	nop
    1171:	9b                   	fwait
    1172:	eb 4e                	jmp    0x11c2
    1174:	3d 01 00             	cmp    ax,0x1
    1177:	75 1c                	jne    0x1195
    1179:	ff 76 0c             	push   WORD PTR [bp+0xc]
    117c:	ff 76 f2             	push   WORD PTR [bp-0xe]
    117f:	ff 76 f0             	push   WORD PTR [bp-0x10]
    1182:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1185:	ff 76 ec             	push   WORD PTR [bp-0x14]
    1188:	9a 22 0f ac 11       	call   0x11ac:0xf22
    118d:	9b dd 5e da          	fstp   QWORD PTR [bp-0x26]
    1191:	90                   	nop
    1192:	9b                   	fwait
    1193:	eb 2d                	jmp    0x11c2
    1195:	3d 02 00             	cmp    ax,0x2
    1198:	75 1c                	jne    0x11b6
    119a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    119d:	ff 76 f2             	push   WORD PTR [bp-0xe]
    11a0:	ff 76 f0             	push   WORD PTR [bp-0x10]
    11a3:	ff 76 ee             	push   WORD PTR [bp-0x12]
    11a6:	ff 76 ec             	push   WORD PTR [bp-0x14]
    11a9:	9a c8 0e 2f 14       	call   0x142f:0xec8
    11ae:	9b dd 5e da          	fstp   QWORD PTR [bp-0x26]
    11b2:	90                   	nop
    11b3:	9b                   	fwait
    11b4:	eb 0c                	jmp    0x11c2
    11b6:	9b 2e d9 06 ee 0f    	fld    DWORD PTR cs:0xfee
    11bc:	9b dd 5e da          	fstp   QWORD PTR [bp-0x26]
    11c0:	90                   	nop
    11c1:	9b 9b db 46 f4       	fild   DWORD PTR [bp-0xc]
    11c6:	9b dd 5e d2          	fstp   QWORD PTR [bp-0x2e]
    11ca:	90                   	nop
    11cb:	9b 9b df 06 4e 01    	fild   WORD PTR ds:0x14e
    11d1:	9b dc 4e d2          	fmul   QWORD PTR [bp-0x2e]
    11d5:	9b dd 5e d2          	fstp   QWORD PTR [bp-0x2e]
    11d9:	90                   	nop
    11da:	9b 9b dd 46 d2       	fld    QWORD PTR [bp-0x2e]
    11df:	9b dc 4e da          	fmul   QWORD PTR [bp-0x26]
    11e3:	9b 2e d9 06 f2 0f    	fld    DWORD PTR cs:0xff2
    11e9:	9b dc 46 e2          	fadd   QWORD PTR [bp-0x1e]
    11ed:	9b de c9             	fmulp  st(1),st
    11f0:	83 ec 08             	sub    sp,0x8
    11f3:	89 e3                	mov    bx,sp
    11f5:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    11f9:	90                   	nop
    11fa:	9b                   	fwait
    11fb:	9a a6 2f 01 13       	call   0x1301:0x2fa6
    1200:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1204:	90                   	nop
    1205:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    120a:	90                   	nop
    120b:	9b                   	fwait
    120c:	c9                   	leave
    120d:	ca 08 00             	retf   0x8
    1210:	00 00                	add    BYTE PTR [bx+si],al
    1212:	c0 40 00 00          	rol    BYTE PTR [bx+si+0x0],0x0
    1216:	80 40 66 66          	add    BYTE PTR [bx+si+0x66],0x66
    121a:	66 66 66 66 66 86 ff 	data32 data32 data32 data32 data32 xchg bh,bh
    1221:	3f                   	aas
    1222:	9a 99 99 99 99       	call   0x9999:0x9999
    1227:	99                   	cwd
    1228:	99                   	cwd
    1229:	99                   	cwd
    122a:	fc                   	cld
    122b:	3f                   	aas
    122c:	55                   	push   bp
    122d:	89 e5                	mov    bp,sp
    122f:	b8 0a 00             	mov    ax,0xa
    1232:	9a 44 04 54 12       	call   0x1254:0x444
    1237:	83 ec 0a             	sub    sp,0xa
    123a:	68 6f 40             	push   0x406f
    123d:	68 14 de             	push   0xde14
    1240:	68 e1 7a             	push   0x7ae1
    1243:	68 ae 47             	push   0x47ae
    1246:	6a 15                	push   0x15
    1248:	9a 69 0a 26 25       	call   0x2526:0xa69
    124d:	f7 d8                	neg    ax
    124f:	71 05                	jno    0x1256
    1251:	9a 3e 04 6e 12       	call   0x126e:0x43e
    1256:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1259:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    125d:	9b dc 4e 06          	fmul   QWORD PTR [bp+0x6]
    1261:	9b dc 4e 06          	fmul   QWORD PTR [bp+0x6]
    1265:	9b 2e d9 06 10 12    	fld    DWORD PTR cs:0x1210
    126b:	9a b2 04 81 12       	call   0x1281:0x4b2
    1270:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    1274:	9b dc 4e 06          	fmul   QWORD PTR [bp+0x6]
    1278:	9b 2e d9 06 14 12    	fld    DWORD PTR cs:0x1214
    127e:	9a b2 04 c6 12       	call   0x12c6:0x4b2
    1283:	9b de e9             	fsubp  st(1),st
    1286:	9b 2e db 2e 18 12    	fld    TBYTE PTR cs:0x1218
    128c:	9b de c9             	fmulp  st(1),st
    128f:	9b df 46 f6          	fild   WORD PTR [bp-0xa]
    1293:	9b de c9             	fmulp  st(1),st
    1296:	9b 2e db 2e 22 12    	fld    TBYTE PTR cs:0x1222
    129c:	9b de c1             	faddp  st(1),st
    129f:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    12a3:	90                   	nop
    12a4:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    12a9:	90                   	nop
    12aa:	9b                   	fwait
    12ab:	c9                   	leave
    12ac:	ca 08 00             	retf   0x8
    12af:	cd cc                	int    0xcc
    12b1:	cc                   	int3
    12b2:	cc                   	int3
    12b3:	cc                   	int3
    12b4:	cc                   	int3
    12b5:	cc                   	int3
    12b6:	cc                   	int3
    12b7:	fa                   	cli
    12b8:	3f                   	aas
    12b9:	00 00                	add    BYTE PTR [bx+si],al
    12bb:	80 3f 55             	cmp    BYTE PTR [bx],0x55
    12be:	89 e5                	mov    bp,sp
    12c0:	b8 08 00             	mov    ax,0x8
    12c3:	9a 44 04 62 13       	call   0x1362:0x444
    12c8:	83 ec 08             	sub    sp,0x8
    12cb:	9b 2e db 2e af 12    	fld    TBYTE PTR cs:0x12af
    12d1:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    12d4:	9b 36 dc 4d 12       	fmul   QWORD PTR ss:[di+0x12]
    12d9:	9b 36 dc 65 1a       	fsub   QWORD PTR ss:[di+0x1a]
    12de:	83 ec 08             	sub    sp,0x8
    12e1:	89 e3                	mov    bx,sp
    12e3:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    12e7:	90                   	nop
    12e8:	9b                   	fwait
    12e9:	9b 36 dd 45 12       	fld    QWORD PTR ss:[di+0x12]
    12ee:	9b 36 dc 65 1a       	fsub   QWORD PTR ss:[di+0x1a]
    12f3:	83 ec 08             	sub    sp,0x8
    12f6:	89 e3                	mov    bx,sp
    12f8:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    12fc:	90                   	nop
    12fd:	9b                   	fwait
    12fe:	9a a7 2e 39 13       	call   0x1339:0x2ea7
    1303:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1307:	90                   	nop
    1308:	9b                   	fwait
    1309:	9b 2e d9 06 b9 12    	fld    DWORD PTR cs:0x12b9
    130f:	9b dc 66 f8          	fsub   QWORD PTR [bp-0x8]
    1313:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    1316:	9b 36 dc 4d 1a       	fmul   QWORD PTR ss:[di+0x1a]
    131b:	83 ec 08             	sub    sp,0x8
    131e:	89 e3                	mov    bx,sp
    1320:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1324:	90                   	nop
    1325:	9b                   	fwait
    1326:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    132a:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    132e:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    1332:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    1336:	9a a7 2e 86 13       	call   0x1386:0x2ea7
    133b:	9b dc 46 f8          	fadd   QWORD PTR [bp-0x8]
    133f:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1343:	90                   	nop
    1344:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    1349:	90                   	nop
    134a:	9b                   	fwait
    134b:	c9                   	leave
    134c:	ca 02 00             	retf   0x2
    134f:	cd cc                	int    0xcc
    1351:	cc                   	int3
    1352:	cc                   	int3
    1353:	cc                   	int3
    1354:	cc                   	int3
    1355:	cc                   	int3
    1356:	cc                   	int3
    1357:	fa                   	cli
    1358:	3f                   	aas
    1359:	55                   	push   bp
    135a:	89 e5                	mov    bp,sp
    135c:	b8 08 00             	mov    ax,0x8
    135f:	9a 44 04 cc 13       	call   0x13cc:0x444
    1364:	83 ec 08             	sub    sp,0x8
    1367:	68 e0 bf             	push   0xbfe0
    136a:	6a 00                	push   0x0
    136c:	6a 00                	push   0x0
    136e:	6a 00                	push   0x0
    1370:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    1373:	36 ff 75 18          	push   WORD PTR ss:[di+0x18]
    1377:	36 ff 75 16          	push   WORD PTR ss:[di+0x16]
    137b:	36 ff 75 14          	push   WORD PTR ss:[di+0x14]
    137f:	36 ff 75 12          	push   WORD PTR ss:[di+0x12]
    1383:	9a a7 2e 13 15       	call   0x1513:0x2ea7
    1388:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    138b:	9b 36 dd 45 0a       	fld    QWORD PTR ss:[di+0xa]
    1390:	9b 36 dc 65 12       	fsub   QWORD PTR ss:[di+0x12]
    1395:	9b de c9             	fmulp  st(1),st
    1398:	9b 2e db 2e 4f 13    	fld    TBYTE PTR cs:0x134f
    139e:	9b de c1             	faddp  st(1),st
    13a1:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    13a5:	90                   	nop
    13a6:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    13ab:	90                   	nop
    13ac:	9b                   	fwait
    13ad:	c9                   	leave
    13ae:	ca 02 00             	retf   0x2
    13b1:	00 00                	add    BYTE PTR [bx+si],al
    13b3:	00 00                	add    BYTE PTR [bx+si],al
    13b5:	00 00                	add    BYTE PTR [bx+si],al
    13b7:	80 3f cd             	cmp    BYTE PTR [bx],0xcd
    13ba:	cc                   	int3
    13bb:	cc                   	int3
    13bc:	cc                   	int3
    13bd:	cc                   	int3
    13be:	cc                   	int3
    13bf:	cc                   	int3
    13c0:	8c ff                	mov    di,?
    13c2:	3f                   	aas
    13c3:	55                   	push   bp
    13c4:	89 e5                	mov    bp,sp
    13c6:	b8 10 00             	mov    ax,0x10
    13c9:	9a 44 04 ae 14       	call   0x14ae:0x444
    13ce:	83 ec 10             	sub    sp,0x10
    13d1:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    13d5:	9b 2e d8 1e b1 13    	fcomp  DWORD PTR cs:0x13b1
    13db:	9b dd 7e f6          	fstsw  WORD PTR [bp-0xa]
    13df:	90                   	nop
    13e0:	9b                   	fwait
    13e1:	8a 66 f7             	mov    ah,BYTE PTR [bp-0x9]
    13e4:	9e                   	sahf
    13e5:	75 0e                	jne    0x13f5
    13e7:	9b 2e d9 06 b1 13    	fld    DWORD PTR cs:0x13b1
    13ed:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    13f1:	90                   	nop
    13f2:	9b                   	fwait
    13f3:	eb 78                	jmp    0x146d
    13f5:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    13f9:	9b dc 5e 1a          	fcomp  QWORD PTR [bp+0x1a]
    13fd:	9b dd 7e f4          	fstsw  WORD PTR [bp-0xc]
    1401:	90                   	nop
    1402:	9b                   	fwait
    1403:	8a 66 f5             	mov    ah,BYTE PTR [bp-0xb]
    1406:	9e                   	sahf
    1407:	73 0e                	jae    0x1417
    1409:	9b 2e d9 06 b5 13    	fld    DWORD PTR cs:0x13b5
    140f:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1413:	90                   	nop
    1414:	9b                   	fwait
    1415:	eb 56                	jmp    0x146d
    1417:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    141b:	9b dc 5e 12          	fcomp  QWORD PTR [bp+0x12]
    141f:	9b dd 7e f2          	fstsw  WORD PTR [bp-0xe]
    1423:	90                   	nop
    1424:	9b                   	fwait
    1425:	8a 66 f3             	mov    ah,BYTE PTR [bp-0xd]
    1428:	9e                   	sahf
    1429:	77 0e                	ja     0x1439
    142b:	55                   	push   bp
    142c:	9a bd 12 57 14       	call   0x1457:0x12bd
    1431:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1435:	90                   	nop
    1436:	9b                   	fwait
    1437:	eb 34                	jmp    0x146d
    1439:	9b 2e db 2e b9 13    	fld    TBYTE PTR cs:0x13b9
    143f:	9b dc 4e 12          	fmul   QWORD PTR [bp+0x12]
    1443:	9b dc 5e 0a          	fcomp  QWORD PTR [bp+0xa]
    1447:	9b dd 7e f0          	fstsw  WORD PTR [bp-0x10]
    144b:	90                   	nop
    144c:	9b                   	fwait
    144d:	8a 66 f1             	mov    ah,BYTE PTR [bp-0xf]
    1450:	9e                   	sahf
    1451:	72 0e                	jb     0x1461
    1453:	55                   	push   bp
    1454:	9a 59 13 79 17       	call   0x1779:0x1359
    1459:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    145d:	90                   	nop
    145e:	9b                   	fwait
    145f:	eb 0c                	jmp    0x146d
    1461:	9b 2e d9 06 b1 13    	fld    DWORD PTR cs:0x13b1
    1467:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    146b:	90                   	nop
    146c:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    1471:	9b dc 4e 22          	fmul   QWORD PTR [bp+0x22]
    1475:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1479:	90                   	nop
    147a:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    147f:	90                   	nop
    1480:	9b                   	fwait
    1481:	c9                   	leave
    1482:	ca 24 00             	retf   0x24
    1485:	00 00                	add    BYTE PTR [bx+si],al
    1487:	00 00                	add    BYTE PTR [bx+si],al
    1489:	0a d7                	or     dl,bh
    148b:	a3 70 3d             	mov    ds:0x3d70,ax
    148e:	0a d7                	or     dl,bh
    1490:	a3 f8 3f             	mov    ds:0x3ff8,ax
    1493:	cd cc                	int    0xcc
    1495:	cc                   	int3
    1496:	cc                   	int3
    1497:	cc                   	int3
    1498:	cc                   	int3
    1499:	cc                   	int3
    149a:	cc                   	int3
    149b:	fb                   	sti
    149c:	3f                   	aas
    149d:	00 00                	add    BYTE PTR [bx+si],al
    149f:	80 3f 00             	cmp    BYTE PTR [bx],0x0
    14a2:	00 20                	add    BYTE PTR [bx+si],ah
    14a4:	41                   	inc    cx
    14a5:	55                   	push   bp
    14a6:	89 e5                	mov    bp,sp
    14a8:	b8 16 00             	mov    ax,0x16
    14ab:	9a 44 04 f5 14       	call   0x14f5:0x444
    14b0:	83 ec 16             	sub    sp,0x16
    14b3:	9b dd 46 12          	fld    QWORD PTR [bp+0x12]
    14b7:	9b 2e d8 1e 85 14    	fcomp  DWORD PTR cs:0x1485
    14bd:	9b dd 7e ee          	fstsw  WORD PTR [bp-0x12]
    14c1:	90                   	nop
    14c2:	9b                   	fwait
    14c3:	8a 66 ef             	mov    ah,BYTE PTR [bp-0x11]
    14c6:	9e                   	sahf
    14c7:	75 0f                	jne    0x14d8
    14c9:	9b 2e d9 06 85 14    	fld    DWORD PTR cs:0x1485
    14cf:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    14d3:	90                   	nop
    14d4:	9b                   	fwait
    14d5:	e9 9b 00             	jmp    0x1573
    14d8:	ff 76 10             	push   WORD PTR [bp+0x10]
    14db:	ff 76 0e             	push   WORD PTR [bp+0xe]
    14de:	ff 76 0c             	push   WORD PTR [bp+0xc]
    14e1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    14e4:	8b 46 1e             	mov    ax,WORD PTR [bp+0x1e]
    14e7:	8b 56 20             	mov    dx,WORD PTR [bp+0x20]
    14ea:	03 46 1a             	add    ax,WORD PTR [bp+0x1a]
    14ed:	13 56 1c             	adc    dx,WORD PTR [bp+0x1c]
    14f0:	71 05                	jno    0x14f7
    14f2:	9a 3e 04 c2 15       	call   0x15c2:0x43e
    14f7:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    14fa:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    14fd:	9b db 46 ea          	fild   DWORD PTR [bp-0x16]
    1501:	9b dc 4e 12          	fmul   QWORD PTR [bp+0x12]
    1505:	83 ec 08             	sub    sp,0x8
    1508:	89 e3                	mov    bx,sp
    150a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    150e:	90                   	nop
    150f:	9b                   	fwait
    1510:	9a a7 2e 2e 16       	call   0x162e:0x2ea7
    1515:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    1519:	90                   	nop
    151a:	9b                   	fwait
    151b:	9b 2e db 2e 89 14    	fld    TBYTE PTR cs:0x1489
    1521:	9b dc 5e f0          	fcomp  QWORD PTR [bp-0x10]
    1525:	9b dd 7e ec          	fstsw  WORD PTR [bp-0x14]
    1529:	90                   	nop
    152a:	9b                   	fwait
    152b:	8a 66 ed             	mov    ah,BYTE PTR [bp-0x13]
    152e:	9e                   	sahf
    152f:	76 0e                	jbe    0x153f
    1531:	9b 2e db 2e 93 14    	fld    TBYTE PTR cs:0x1493
    1537:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    153b:	90                   	nop
    153c:	9b                   	fwait
    153d:	eb 34                	jmp    0x1573
    153f:	9b 2e db 2e 93 14    	fld    TBYTE PTR cs:0x1493
    1545:	9b dc 5e f0          	fcomp  QWORD PTR [bp-0x10]
    1549:	9b dd 7e ea          	fstsw  WORD PTR [bp-0x16]
    154d:	90                   	nop
    154e:	9b                   	fwait
    154f:	8a 66 eb             	mov    ah,BYTE PTR [bp-0x15]
    1552:	9e                   	sahf
    1553:	73 0e                	jae    0x1563
    1555:	9b 2e d9 06 9d 14    	fld    DWORD PTR cs:0x149d
    155b:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    155f:	90                   	nop
    1560:	9b                   	fwait
    1561:	eb 10                	jmp    0x1573
    1563:	9b 2e d9 06 a1 14    	fld    DWORD PTR cs:0x14a1
    1569:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    156d:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1571:	90                   	nop
    1572:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    1577:	9b dc 4e 22          	fmul   QWORD PTR [bp+0x22]
    157b:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    157f:	90                   	nop
    1580:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    1585:	90                   	nop
    1586:	9b                   	fwait
    1587:	c9                   	leave
    1588:	ca 24 00             	retf   0x24
    158b:	00 00                	add    BYTE PTR [bx+si],al
    158d:	00 00                	add    BYTE PTR [bx+si],al
    158f:	0a d7                	or     dl,bh
    1591:	a3 70 3d             	mov    ds:0x3d70,ax
    1594:	0a d7                	or     dl,bh
    1596:	a3 fb 3f             	mov    ds:0x3ffb,ax
    1599:	cd cc                	int    0xcc
    159b:	cc                   	int3
    159c:	cc                   	int3
    159d:	cc                   	int3
    159e:	cc                   	int3
    159f:	cc                   	int3
    15a0:	cc                   	int3
    15a1:	fb                   	sti
    15a2:	3f                   	aas
    15a3:	cd cc                	int    0xcc
    15a5:	cc                   	int3
    15a6:	cc                   	int3
    15a7:	cc                   	int3
    15a8:	cc                   	int3
    15a9:	cc                   	int3
    15aa:	cc                   	int3
    15ab:	fc                   	cld
    15ac:	3f                   	aas
    15ad:	00 00                	add    BYTE PTR [bx+si],al
    15af:	80 3f 00             	cmp    BYTE PTR [bx],0x0
    15b2:	00 f0                	add    al,dh
    15b4:	40                   	inc    ax
    15b5:	00 00                	add    BYTE PTR [bx+si],al
    15b7:	00 3f                	add    BYTE PTR [bx],bh
    15b9:	55                   	push   bp
    15ba:	89 e5                	mov    bp,sp
    15bc:	b8 18 00             	mov    ax,0x18
    15bf:	9a 44 04 10 16       	call   0x1610:0x444
    15c4:	83 ec 18             	sub    sp,0x18
    15c7:	9b dd 46 16          	fld    QWORD PTR [bp+0x16]
    15cb:	9b 2e d8 1e 8b 15    	fcomp  DWORD PTR cs:0x158b
    15d1:	9b dd 7e ee          	fstsw  WORD PTR [bp-0x12]
    15d5:	90                   	nop
    15d6:	9b                   	fwait
    15d7:	8a 66 ef             	mov    ah,BYTE PTR [bp-0x11]
    15da:	9e                   	sahf
    15db:	75 0f                	jne    0x15ec
    15dd:	9b 2e d9 06 8b 15    	fld    DWORD PTR cs:0x158b
    15e3:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    15e7:	90                   	nop
    15e8:	9b                   	fwait
    15e9:	e9 cc 00             	jmp    0x16b8
    15ec:	9b db 46 12          	fild   DWORD PTR [bp+0x12]
    15f0:	9b dc 4e 1e          	fmul   QWORD PTR [bp+0x1e]
    15f4:	83 ec 08             	sub    sp,0x8
    15f7:	89 e3                	mov    bx,sp
    15f9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    15fd:	90                   	nop
    15fe:	9b                   	fwait
    15ff:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    1602:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    1605:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    1608:	13 56 0c             	adc    dx,WORD PTR [bp+0xc]
    160b:	71 05                	jno    0x1612
    160d:	9a 3e 04 f7 16       	call   0x16f7:0x43e
    1612:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    1615:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    1618:	9b db 46 ea          	fild   DWORD PTR [bp-0x16]
    161c:	9b dc 4e 16          	fmul   QWORD PTR [bp+0x16]
    1620:	83 ec 08             	sub    sp,0x8
    1623:	89 e3                	mov    bx,sp
    1625:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1629:	90                   	nop
    162a:	9b                   	fwait
    162b:	9a a7 2e 35 18       	call   0x1835:0x2ea7
    1630:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    1634:	90                   	nop
    1635:	9b 9b dd 46 f0       	fld    QWORD PTR [bp-0x10]
    163a:	9b 2e d8 1e 8b 15    	fcomp  DWORD PTR cs:0x158b
    1640:	9b dd 7e ec          	fstsw  WORD PTR [bp-0x14]
    1644:	90                   	nop
    1645:	9b                   	fwait
    1646:	8a 66 ed             	mov    ah,BYTE PTR [bp-0x13]
    1649:	9e                   	sahf
    164a:	75 0e                	jne    0x165a
    164c:	9b 2e d9 06 8b 15    	fld    DWORD PTR cs:0x158b
    1652:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1656:	90                   	nop
    1657:	9b                   	fwait
    1658:	eb 5e                	jmp    0x16b8
    165a:	9b 2e db 2e 8f 15    	fld    TBYTE PTR cs:0x158f
    1660:	9b dc 5e f0          	fcomp  QWORD PTR [bp-0x10]
    1664:	9b dd 7e ea          	fstsw  WORD PTR [bp-0x16]
    1668:	90                   	nop
    1669:	9b                   	fwait
    166a:	8a 66 eb             	mov    ah,BYTE PTR [bp-0x15]
    166d:	9e                   	sahf
    166e:	76 0e                	jbe    0x167e
    1670:	9b 2e db 2e 99 15    	fld    TBYTE PTR cs:0x1599
    1676:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    167a:	90                   	nop
    167b:	9b                   	fwait
    167c:	eb 3a                	jmp    0x16b8
    167e:	9b 2e db 2e a3 15    	fld    TBYTE PTR cs:0x15a3
    1684:	9b dc 5e f0          	fcomp  QWORD PTR [bp-0x10]
    1688:	9b dd 7e e8          	fstsw  WORD PTR [bp-0x18]
    168c:	90                   	nop
    168d:	9b                   	fwait
    168e:	8a 66 e9             	mov    ah,BYTE PTR [bp-0x17]
    1691:	9e                   	sahf
    1692:	73 0e                	jae    0x16a2
    1694:	9b 2e d9 06 ad 15    	fld    DWORD PTR cs:0x15ad
    169a:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    169e:	90                   	nop
    169f:	9b                   	fwait
    16a0:	eb 16                	jmp    0x16b8
    16a2:	9b 2e d9 06 b1 15    	fld    DWORD PTR cs:0x15b1
    16a8:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    16ac:	9b 2e d8 26 b5 15    	fsub   DWORD PTR cs:0x15b5
    16b2:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    16b6:	90                   	nop
    16b7:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    16bc:	9b dc 4e 26          	fmul   QWORD PTR [bp+0x26]
    16c0:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    16c4:	90                   	nop
    16c5:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    16ca:	90                   	nop
    16cb:	9b                   	fwait
    16cc:	c9                   	leave
    16cd:	ca 28 00             	retf   0x28
    16d0:	90                   	nop
    16d1:	9e                   	sahf
    16d2:	22 87 88 9b          	and    al,BYTE PTR [bx-0x6478]
    16d6:	53                   	push   bx
    16d7:	c9                   	leave
    16d8:	f0 3f                	lock aas
    16da:	e7 39                	out    0x39,ax
    16dc:	22 df                	and    bl,bh
    16de:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    16df:	d4 25                	aam    0x25
    16e1:	e3 f5                	jcxz   0x16d8
    16e3:	3f                   	aas
    16e4:	cd cc                	int    0xcc
    16e6:	cc                   	int3
    16e7:	cc                   	int3
    16e8:	cc                   	int3
    16e9:	cc                   	int3
    16ea:	cc                   	int3
    16eb:	cc                   	int3
    16ec:	fb                   	sti
    16ed:	3f                   	aas
    16ee:	55                   	push   bp
    16ef:	89 e5                	mov    bp,sp
    16f1:	b8 08 00             	mov    ax,0x8
    16f4:	9a 44 04 3d 17       	call   0x173d:0x444
    16f9:	83 ec 08             	sub    sp,0x8
    16fc:	9b 2e db 2e d0 16    	fld    TBYTE PTR cs:0x16d0
    1702:	9b dc 4e 08          	fmul   QWORD PTR [bp+0x8]
    1706:	9b dc 4e 08          	fmul   QWORD PTR [bp+0x8]
    170a:	9b 2e db 2e da 16    	fld    TBYTE PTR cs:0x16da
    1710:	9b dc 4e 08          	fmul   QWORD PTR [bp+0x8]
    1714:	9b de c1             	faddp  st(1),st
    1717:	9b 2e db 2e e4 16    	fld    TBYTE PTR cs:0x16e4
    171d:	9b de c1             	faddp  st(1),st
    1720:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1724:	90                   	nop
    1725:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    172a:	90                   	nop
    172b:	9b                   	fwait
    172c:	c9                   	leave
    172d:	ca 0a 00             	retf   0xa
    1730:	00 00                	add    BYTE PTR [bx+si],al
    1732:	00 00                	add    BYTE PTR [bx+si],al
    1734:	55                   	push   bp
    1735:	89 e5                	mov    bp,sp
    1737:	b8 0a 00             	mov    ax,0xa
    173a:	9a 44 04 d0 17       	call   0x17d0:0x444
    173f:	83 ec 0a             	sub    sp,0xa
    1742:	9b dd 46 0e          	fld    QWORD PTR [bp+0xe]
    1746:	9b 2e d8 1e 30 17    	fcomp  DWORD PTR cs:0x1730
    174c:	9b dd 7e f6          	fstsw  WORD PTR [bp-0xa]
    1750:	90                   	nop
    1751:	9b                   	fwait
    1752:	8a 66 f7             	mov    ah,BYTE PTR [bp-0x9]
    1755:	9e                   	sahf
    1756:	75 0e                	jne    0x1766
    1758:	9b 2e d9 06 30 17    	fld    DWORD PTR cs:0x1730
    175e:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1762:	90                   	nop
    1763:	9b                   	fwait
    1764:	eb 1b                	jmp    0x1781
    1766:	9b db 46 0a          	fild   DWORD PTR [bp+0xa]
    176a:	83 ec 08             	sub    sp,0x8
    176d:	89 e3                	mov    bx,sp
    176f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1773:	90                   	nop
    1774:	9b                   	fwait
    1775:	55                   	push   bp
    1776:	9a ee 16 e4 18       	call   0x18e4:0x16ee
    177b:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    177f:	90                   	nop
    1780:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    1785:	9b dc 4e 16          	fmul   QWORD PTR [bp+0x16]
    1789:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    178d:	90                   	nop
    178e:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    1793:	90                   	nop
    1794:	9b                   	fwait
    1795:	c9                   	leave
    1796:	ca 18 00             	retf   0x18
    1799:	00 00                	add    BYTE PTR [bx+si],al
    179b:	00 00                	add    BYTE PTR [bx+si],al
    179d:	0a d7                	or     dl,bh
    179f:	a3 70 3d             	mov    ds:0x3d70,ax
    17a2:	0a d7                	or     dl,bh
    17a4:	a3 fb 3f             	mov    ds:0x3ffb,ax
    17a7:	cd cc                	int    0xcc
    17a9:	cc                   	int3
    17aa:	cc                   	int3
    17ab:	cc                   	int3
    17ac:	cc                   	int3
    17ad:	cc                   	int3
    17ae:	cc                   	int3
    17af:	fb                   	sti
    17b0:	3f                   	aas
    17b1:	cd cc                	int    0xcc
    17b3:	cc                   	int3
    17b4:	cc                   	int3
    17b5:	cc                   	int3
    17b6:	cc                   	int3
    17b7:	cc                   	int3
    17b8:	cc                   	int3
    17b9:	fc                   	cld
    17ba:	3f                   	aas
    17bb:	00 00                	add    BYTE PTR [bx+si],al
    17bd:	80 3f 00             	cmp    BYTE PTR [bx],0x0
    17c0:	00 f0                	add    al,dh
    17c2:	40                   	inc    ax
    17c3:	00 00                	add    BYTE PTR [bx+si],al
    17c5:	00 3f                	add    BYTE PTR [bx],bh
    17c7:	55                   	push   bp
    17c8:	89 e5                	mov    bp,sp
    17ca:	b8 18 00             	mov    ax,0x18
    17cd:	9a 44 04 17 18       	call   0x1817:0x444
    17d2:	83 ec 18             	sub    sp,0x18
    17d5:	9b dd 46 12          	fld    QWORD PTR [bp+0x12]
    17d9:	9b 2e d8 1e 99 17    	fcomp  DWORD PTR cs:0x1799
    17df:	9b dd 7e ee          	fstsw  WORD PTR [bp-0x12]
    17e3:	90                   	nop
    17e4:	9b                   	fwait
    17e5:	8a 66 ef             	mov    ah,BYTE PTR [bp-0x11]
    17e8:	9e                   	sahf
    17e9:	75 0f                	jne    0x17fa
    17eb:	9b 2e d9 06 99 17    	fld    DWORD PTR cs:0x1799
    17f1:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    17f5:	90                   	nop
    17f6:	9b                   	fwait
    17f7:	e9 c5 00             	jmp    0x18bf
    17fa:	ff 76 20             	push   WORD PTR [bp+0x20]
    17fd:	ff 76 1e             	push   WORD PTR [bp+0x1e]
    1800:	ff 76 1c             	push   WORD PTR [bp+0x1c]
    1803:	ff 76 1a             	push   WORD PTR [bp+0x1a]
    1806:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    1809:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    180c:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    180f:	13 56 0c             	adc    dx,WORD PTR [bp+0xc]
    1812:	71 05                	jno    0x1819
    1814:	9a 3e 04 25 19       	call   0x1925:0x43e
    1819:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    181c:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    181f:	9b db 46 ea          	fild   DWORD PTR [bp-0x16]
    1823:	9b dc 4e 12          	fmul   QWORD PTR [bp+0x12]
    1827:	83 ec 08             	sub    sp,0x8
    182a:	89 e3                	mov    bx,sp
    182c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1830:	90                   	nop
    1831:	9b                   	fwait
    1832:	9a a7 2e b5 1c       	call   0x1cb5:0x2ea7
    1837:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    183b:	90                   	nop
    183c:	9b 9b dd 46 f0       	fld    QWORD PTR [bp-0x10]
    1841:	9b 2e d8 1e 99 17    	fcomp  DWORD PTR cs:0x1799
    1847:	9b dd 7e ec          	fstsw  WORD PTR [bp-0x14]
    184b:	90                   	nop
    184c:	9b                   	fwait
    184d:	8a 66 ed             	mov    ah,BYTE PTR [bp-0x13]
    1850:	9e                   	sahf
    1851:	75 0e                	jne    0x1861
    1853:	9b 2e d9 06 99 17    	fld    DWORD PTR cs:0x1799
    1859:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    185d:	90                   	nop
    185e:	9b                   	fwait
    185f:	eb 5e                	jmp    0x18bf
    1861:	9b 2e db 2e 9d 17    	fld    TBYTE PTR cs:0x179d
    1867:	9b dc 5e f0          	fcomp  QWORD PTR [bp-0x10]
    186b:	9b dd 7e ea          	fstsw  WORD PTR [bp-0x16]
    186f:	90                   	nop
    1870:	9b                   	fwait
    1871:	8a 66 eb             	mov    ah,BYTE PTR [bp-0x15]
    1874:	9e                   	sahf
    1875:	76 0e                	jbe    0x1885
    1877:	9b 2e db 2e a7 17    	fld    TBYTE PTR cs:0x17a7
    187d:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1881:	90                   	nop
    1882:	9b                   	fwait
    1883:	eb 3a                	jmp    0x18bf
    1885:	9b 2e db 2e b1 17    	fld    TBYTE PTR cs:0x17b1
    188b:	9b dc 5e f0          	fcomp  QWORD PTR [bp-0x10]
    188f:	9b dd 7e e8          	fstsw  WORD PTR [bp-0x18]
    1893:	90                   	nop
    1894:	9b                   	fwait
    1895:	8a 66 e9             	mov    ah,BYTE PTR [bp-0x17]
    1898:	9e                   	sahf
    1899:	73 0e                	jae    0x18a9
    189b:	9b 2e d9 06 bb 17    	fld    DWORD PTR cs:0x17bb
    18a1:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    18a5:	90                   	nop
    18a6:	9b                   	fwait
    18a7:	eb 16                	jmp    0x18bf
    18a9:	9b 2e d9 06 bf 17    	fld    DWORD PTR cs:0x17bf
    18af:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    18b3:	9b 2e d8 26 c3 17    	fsub   DWORD PTR cs:0x17c3
    18b9:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    18bd:	90                   	nop
    18be:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    18c3:	9b dc 4e 22          	fmul   QWORD PTR [bp+0x22]
    18c7:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    18cb:	90                   	nop
    18cc:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    18d1:	90                   	nop
    18d2:	9b                   	fwait
    18d3:	c9                   	leave
    18d4:	ca 24 00             	retf   0x24
    18d7:	08 4d 61             	or     BYTE PTR [di+0x61],cl
    18da:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    18dd:	6e                   	outs   dx,BYTE PTR ds:[si]
    18de:	65 73 00             	gs jae 0x18e1
    18e1:	00 bb 19 0e          	add    BYTE PTR [bp+di+0xe19],bh
    18e5:	19 0d                	sbb    WORD PTR [di],cx
    18e7:	41                   	inc    cx
    18e8:	63 68 61             	arpl   WORD PTR [bx+si+0x61],bp
    18eb:	74 4d                	je     0x193a
    18ed:	61                   	popa
    18ee:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    18f1:	6e                   	outs   dx,BYTE PTR ds:[si]
    18f2:	65 73 0d             	gs jae 0x1902
    18f5:	56                   	push   si
    18f6:	65 6e                	outs   dx,BYTE PTR gs:[si]
    18f8:	74 65                	je     0x195f
    18fa:	4d                   	dec    bp
    18fb:	61                   	popa
    18fc:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    18ff:	6e                   	outs   dx,BYTE PTR ds:[si]
    1900:	65 73 00             	gs jae 0x1903
    1903:	00 00                	add    BYTE PTR [bx+si],al
    1905:	00 32                	add    BYTE PTR [bp+si],dh
    1907:	00 00                	add    BYTE PTR [bx+si],al
    1909:	00 00                	add    BYTE PTR [bx+si],al
    190b:	00 c3                	add    bl,al
    190d:	1b 88 19 00          	sbb    cx,WORD PTR [bx+si+0x19]
    1911:	00 00                	add    BYTE PTR [bx+si],al
    1913:	00 00                	add    BYTE PTR [bx+si],al
    1915:	00 00                	add    BYTE PTR [bx+si],al
    1917:	00 32                	add    BYTE PTR [bp+si],dh
    1919:	00 00                	add    BYTE PTR [bx+si],al
    191b:	00 55 89             	add    BYTE PTR [di-0x77],dl
    191e:	e5 b8                	in     ax,0xb8
    1920:	0c 01                	or     al,0x1
    1922:	9a 44 04 e5 19       	call   0x19e5:0x444
    1927:	81 ec 0c 01          	sub    sp,0x10c
    192b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    192e:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    1933:	89 be 06 ff          	mov    WORD PTR [bp-0xfa],di
    1937:	8c 86 08 ff          	mov    WORD PTR [bp-0xf8],es
    193b:	b8 e0 18             	mov    ax,0x18e0
    193e:	0e                   	push   cs
    193f:	50                   	push   ax
    1940:	55                   	push   bp
    1941:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1945:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1949:	31 c0                	xor    ax,ax
    194b:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    194f:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    1953:	c6 86 fa fe 00       	mov    BYTE PTR [bp-0x106],0x0
    1958:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    195b:	99                   	cwd
    195c:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    1960:	89 96 00 ff          	mov    WORD PTR [bp-0x100],dx
    1964:	c6 86 02 ff 00       	mov    BYTE PTR [bp-0xfe],0x0
    1969:	8d be f6 fe          	lea    di,[bp-0x10a]
    196d:	16                   	push   ss
    196e:	57                   	push   di
    196f:	6a 01                	push   0x1
    1971:	c4 be 06 ff          	les    di,DWORD PTR [bp-0xfa]
    1975:	06                   	push   es
    1976:	57                   	push   di
    1977:	9a 95 28 32 1a       	call   0x1a32:0x2895
    197c:	08 c0                	or     al,al
    197e:	75 0a                	jne    0x198a
    1980:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1983:	06                   	push   es
    1984:	57                   	push   di
    1985:	9a 03 03 40 1a       	call   0x1a40:0x303
    198a:	bf d7 18             	mov    di,0x18d7
    198d:	0e                   	push   cs
    198e:	57                   	push   di
    198f:	c4 be 06 ff          	les    di,DWORD PTR [bp-0xfa]
    1993:	06                   	push   es
    1994:	57                   	push   di
    1995:	9a 9b 3b 50 1a       	call   0x1a50:0x3b9b
    199a:	89 c7                	mov    di,ax
    199c:	8e c2                	mov    es,dx
    199e:	06                   	push   es
    199f:	57                   	push   di
    19a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    19a3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    19a7:	89 86 28 ff          	mov    WORD PTR [bp-0xd8],ax
    19ab:	89 96 2a ff          	mov    WORD PTR [bp-0xd6],dx
    19af:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    19b3:	83 c4 06             	add    sp,0x6
    19b6:	b8 bc 19             	mov    ax,0x19bc
    19b9:	0e                   	push   cs
    19ba:	50                   	push   ax
    19bb:	cb                   	retf
    19bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19bf:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    19c4:	89 be 06 ff          	mov    WORD PTR [bp-0xfa],di
    19c8:	8c 86 08 ff          	mov    WORD PTR [bp-0xf8],es
    19cc:	b8 0a 19             	mov    ax,0x190a
    19cf:	0e                   	push   cs
    19d0:	50                   	push   ax
    19d1:	55                   	push   bp
    19d2:	ff 36 58 18          	push   WORD PTR ds:0x1858
    19d6:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    19da:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    19dd:	2d 01 00             	sub    ax,0x1
    19e0:	71 05                	jno    0x19e7
    19e2:	9a 3e 04 9e 1a       	call   0x1a9e:0x43e
    19e7:	89 86 04 ff          	mov    WORD PTR [bp-0xfc],ax
    19eb:	b8 01 00             	mov    ax,0x1
    19ee:	3b 86 04 ff          	cmp    ax,WORD PTR [bp-0xfc]
    19f2:	7e 03                	jle    0x19f7
    19f4:	e9 c0 01             	jmp    0x1bb7
    19f7:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    19fa:	eb 03                	jmp    0x19ff
    19fc:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    19ff:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1a02:	99                   	cwd
    1a03:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    1a07:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    1a0b:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    1a10:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1a13:	99                   	cwd
    1a14:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    1a18:	89 96 fe fe          	mov    WORD PTR [bp-0x102],dx
    1a1c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1a21:	8d be f4 fe          	lea    di,[bp-0x10c]
    1a25:	16                   	push   ss
    1a26:	57                   	push   di
    1a27:	6a 01                	push   0x1
    1a29:	c4 be 06 ff          	les    di,DWORD PTR [bp-0xfa]
    1a2d:	06                   	push   es
    1a2e:	57                   	push   di
    1a2f:	9a 95 28 bd 21       	call   0x21bd:0x2895
    1a34:	08 c0                	or     al,al
    1a36:	75 0a                	jne    0x1a42
    1a38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a3b:	06                   	push   es
    1a3c:	57                   	push   di
    1a3d:	9a 03 03 d6 1c       	call   0x1cd6:0x303
    1a42:	bf e6 18             	mov    di,0x18e6
    1a45:	0e                   	push   cs
    1a46:	57                   	push   di
    1a47:	c4 be 06 ff          	les    di,DWORD PTR [bp-0xfa]
    1a4b:	06                   	push   es
    1a4c:	57                   	push   di
    1a4d:	9a 9b 3b 75 1a       	call   0x1a75:0x3b9b
    1a52:	89 c7                	mov    di,ax
    1a54:	8e c2                	mov    es,dx
    1a56:	06                   	push   es
    1a57:	57                   	push   di
    1a58:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a5b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1a5f:	89 86 24 ff          	mov    WORD PTR [bp-0xdc],ax
    1a63:	89 96 26 ff          	mov    WORD PTR [bp-0xda],dx
    1a67:	bf f4 18             	mov    di,0x18f4
    1a6a:	0e                   	push   cs
    1a6b:	57                   	push   di
    1a6c:	c4 be 06 ff          	les    di,DWORD PTR [bp-0xfa]
    1a70:	06                   	push   es
    1a71:	57                   	push   di
    1a72:	9a 9b 3b db 21       	call   0x21db:0x3b9b
    1a77:	89 c7                	mov    di,ax
    1a79:	8e c2                	mov    es,dx
    1a7b:	06                   	push   es
    1a7c:	57                   	push   di
    1a7d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a80:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1a84:	89 86 20 ff          	mov    WORD PTR [bp-0xe0],ax
    1a88:	89 96 22 ff          	mov    WORD PTR [bp-0xde],dx
    1a8c:	8b 8e 24 ff          	mov    cx,WORD PTR [bp-0xdc]
    1a90:	8b 9e 26 ff          	mov    bx,WORD PTR [bp-0xda]
    1a94:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1a97:	99                   	cwd
    1a98:	bf 02 19             	mov    di,0x1902
    1a9b:	9a 16 04 c8 1a       	call   0x1ac8:0x416
    1aa0:	8b f8                	mov    di,ax
    1aa2:	c1 e7 02             	shl    di,0x2
    1aa5:	89 8b 28 ff          	mov    WORD PTR [bp+di-0xd8],cx
    1aa9:	89 9b 2a ff          	mov    WORD PTR [bp+di-0xd6],bx
    1aad:	8b 86 20 ff          	mov    ax,WORD PTR [bp-0xe0]
    1ab1:	8b 96 22 ff          	mov    dx,WORD PTR [bp-0xde]
    1ab5:	89 86 14 ff          	mov    WORD PTR [bp-0xec],ax
    1ab9:	89 96 16 ff          	mov    WORD PTR [bp-0xea],dx
    1abd:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1ac0:	2d 01 00             	sub    ax,0x1
    1ac3:	71 05                	jno    0x1aca
    1ac5:	9a 3e 04 eb 1a       	call   0x1aeb:0x43e
    1aca:	89 86 02 ff          	mov    WORD PTR [bp-0xfe],ax
    1ace:	31 c0                	xor    ax,ax
    1ad0:	3b 86 02 ff          	cmp    ax,WORD PTR [bp-0xfe]
    1ad4:	7e 03                	jle    0x1ad9
    1ad6:	e9 d2 00             	jmp    0x1bab
    1ad9:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1adc:	eb 03                	jmp    0x1ae1
    1ade:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    1ae1:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1ae4:	99                   	cwd
    1ae5:	bf 02 19             	mov    di,0x1902
    1ae8:	9a 16 04 12 1b       	call   0x1b12:0x416
    1aed:	8b f8                	mov    di,ax
    1aef:	c1 e7 02             	shl    di,0x2
    1af2:	8b 83 28 ff          	mov    ax,WORD PTR [bp+di-0xd8]
    1af6:	8b 93 2a ff          	mov    dx,WORD PTR [bp+di-0xd6]
    1afa:	3b 96 16 ff          	cmp    dx,WORD PTR [bp-0xea]
    1afe:	7c 08                	jl     0x1b08
    1b00:	7f 29                	jg     0x1b2b
    1b02:	3b 86 14 ff          	cmp    ax,WORD PTR [bp-0xec]
    1b06:	77 23                	ja     0x1b2b
    1b08:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1b0b:	99                   	cwd
    1b0c:	bf 02 19             	mov    di,0x1902
    1b0f:	9a 16 04 45 1b       	call   0x1b45:0x416
    1b14:	8b f8                	mov    di,ax
    1b16:	c1 e7 02             	shl    di,0x2
    1b19:	8b 83 28 ff          	mov    ax,WORD PTR [bp+di-0xd8]
    1b1d:	8b 93 2a ff          	mov    dx,WORD PTR [bp+di-0xd6]
    1b21:	89 86 10 ff          	mov    WORD PTR [bp-0xf0],ax
    1b25:	89 96 12 ff          	mov    WORD PTR [bp-0xee],dx
    1b29:	eb 10                	jmp    0x1b3b
    1b2b:	8b 86 14 ff          	mov    ax,WORD PTR [bp-0xec]
    1b2f:	8b 96 16 ff          	mov    dx,WORD PTR [bp-0xea]
    1b33:	89 86 10 ff          	mov    WORD PTR [bp-0xf0],ax
    1b37:	89 96 12 ff          	mov    WORD PTR [bp-0xee],dx
    1b3b:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1b3e:	99                   	cwd
    1b3f:	bf 02 19             	mov    di,0x1902
    1b42:	9a 16 04 61 1b       	call   0x1b61:0x416
    1b47:	8b f8                	mov    di,ax
    1b49:	c1 e7 02             	shl    di,0x2
    1b4c:	8b 83 28 ff          	mov    ax,WORD PTR [bp+di-0xd8]
    1b50:	8b 93 2a ff          	mov    dx,WORD PTR [bp+di-0xd6]
    1b54:	2b 86 10 ff          	sub    ax,WORD PTR [bp-0xf0]
    1b58:	1b 96 12 ff          	sbb    dx,WORD PTR [bp-0xee]
    1b5c:	71 05                	jno    0x1b63
    1b5e:	9a 3e 04 71 1b       	call   0x1b71:0x43e
    1b63:	8b c8                	mov    cx,ax
    1b65:	8b da                	mov    bx,dx
    1b67:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1b6a:	99                   	cwd
    1b6b:	bf 02 19             	mov    di,0x1902
    1b6e:	9a 16 04 95 1b       	call   0x1b95:0x416
    1b73:	8b f8                	mov    di,ax
    1b75:	c1 e7 02             	shl    di,0x2
    1b78:	89 8b 28 ff          	mov    WORD PTR [bp+di-0xd8],cx
    1b7c:	89 9b 2a ff          	mov    WORD PTR [bp+di-0xd6],bx
    1b80:	8b 86 14 ff          	mov    ax,WORD PTR [bp-0xec]
    1b84:	8b 96 16 ff          	mov    dx,WORD PTR [bp-0xea]
    1b88:	2b 86 10 ff          	sub    ax,WORD PTR [bp-0xf0]
    1b8c:	1b 96 12 ff          	sbb    dx,WORD PTR [bp-0xee]
    1b90:	71 05                	jno    0x1b97
    1b92:	9a 3e 04 e6 1b       	call   0x1be6:0x43e
    1b97:	89 86 14 ff          	mov    WORD PTR [bp-0xec],ax
    1b9b:	89 96 16 ff          	mov    WORD PTR [bp-0xea],dx
    1b9f:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1ba2:	3b 86 02 ff          	cmp    ax,WORD PTR [bp-0xfe]
    1ba6:	74 03                	je     0x1bab
    1ba8:	e9 33 ff             	jmp    0x1ade
    1bab:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1bae:	3b 86 04 ff          	cmp    ax,WORD PTR [bp-0xfc]
    1bb2:	74 03                	je     0x1bb7
    1bb4:	e9 45 fe             	jmp    0x19fc
    1bb7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1bbb:	83 c4 06             	add    sp,0x6
    1bbe:	b8 c4 1b             	mov    ax,0x1bc4
    1bc1:	0e                   	push   cs
    1bc2:	50                   	push   ax
    1bc3:	cb                   	retf
    1bc4:	9b 2e d9 06 10 19    	fld    DWORD PTR cs:0x1910
    1bca:	9b dd 9e 18 ff       	fstp   QWORD PTR [bp-0xe8]
    1bcf:	90                   	nop
    1bd0:	9b                   	fwait
    1bd1:	31 c0                	xor    ax,ax
    1bd3:	89 86 0c ff          	mov    WORD PTR [bp-0xf4],ax
    1bd7:	89 86 0e ff          	mov    WORD PTR [bp-0xf2],ax
    1bdb:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1bde:	2d 01 00             	sub    ax,0x1
    1be1:	71 05                	jno    0x1be8
    1be3:	9a 3e 04 0a 1c       	call   0x1c0a:0x43e
    1be8:	89 86 08 ff          	mov    WORD PTR [bp-0xf8],ax
    1bec:	31 c0                	xor    ax,ax
    1bee:	3b 86 08 ff          	cmp    ax,WORD PTR [bp-0xf8]
    1bf2:	7e 03                	jle    0x1bf7
    1bf4:	e9 9b 00             	jmp    0x1c92
    1bf7:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1bfa:	eb 03                	jmp    0x1bff
    1bfc:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    1bff:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1c02:	2b 46 f4             	sub    ax,WORD PTR [bp-0xc]
    1c05:	71 05                	jno    0x1c0c
    1c07:	9a 3e 04 14 1c       	call   0x1c14:0x43e
    1c0c:	05 01 00             	add    ax,0x1
    1c0f:	71 05                	jno    0x1c16
    1c11:	9a 3e 04 24 1c       	call   0x1c24:0x43e
    1c16:	89 86 0a ff          	mov    WORD PTR [bp-0xf6],ax
    1c1a:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1c1d:	99                   	cwd
    1c1e:	bf 14 19             	mov    di,0x1914
    1c21:	9a 16 04 3b 1c       	call   0x1c3b:0x416
    1c26:	8b f8                	mov    di,ax
    1c28:	c1 e7 02             	shl    di,0x2
    1c2b:	8b 8b 28 ff          	mov    cx,WORD PTR [bp+di-0xd8]
    1c2f:	8b 9b 2a ff          	mov    bx,WORD PTR [bp+di-0xd6]
    1c33:	8b 86 0a ff          	mov    ax,WORD PTR [bp-0xf6]
    1c37:	99                   	cwd
    1c38:	9a 5c 17 60 1c       	call   0x1c60:0x175c
    1c3d:	89 86 04 ff          	mov    WORD PTR [bp-0xfc],ax
    1c41:	89 96 06 ff          	mov    WORD PTR [bp-0xfa],dx
    1c45:	9b db 86 04 ff       	fild   DWORD PTR [bp-0xfc]
    1c4a:	9b dc 86 18 ff       	fadd   QWORD PTR [bp-0xe8]
    1c4f:	9b dd 9e 18 ff       	fstp   QWORD PTR [bp-0xe8]
    1c54:	90                   	nop
    1c55:	9b                   	fwait
    1c56:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1c59:	99                   	cwd
    1c5a:	bf 14 19             	mov    di,0x1914
    1c5d:	9a 16 04 7c 1c       	call   0x1c7c:0x416
    1c62:	8b f8                	mov    di,ax
    1c64:	c1 e7 02             	shl    di,0x2
    1c67:	8b 83 28 ff          	mov    ax,WORD PTR [bp+di-0xd8]
    1c6b:	8b 93 2a ff          	mov    dx,WORD PTR [bp+di-0xd6]
    1c6f:	03 86 0c ff          	add    ax,WORD PTR [bp-0xf4]
    1c73:	13 96 0e ff          	adc    dx,WORD PTR [bp-0xf2]
    1c77:	71 05                	jno    0x1c7e
    1c79:	9a 3e 04 77 21       	call   0x2177:0x43e
    1c7e:	89 86 0c ff          	mov    WORD PTR [bp-0xf4],ax
    1c82:	89 96 0e ff          	mov    WORD PTR [bp-0xf2],dx
    1c86:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1c89:	3b 86 08 ff          	cmp    ax,WORD PTR [bp-0xf8]
    1c8d:	74 03                	je     0x1c92
    1c8f:	e9 6a ff             	jmp    0x1bfc
    1c92:	ff b6 1e ff          	push   WORD PTR [bp-0xe2]
    1c96:	ff b6 1c ff          	push   WORD PTR [bp-0xe4]
    1c9a:	ff b6 1a ff          	push   WORD PTR [bp-0xe6]
    1c9e:	ff b6 18 ff          	push   WORD PTR [bp-0xe8]
    1ca2:	9b db 86 0c ff       	fild   DWORD PTR [bp-0xf4]
    1ca7:	83 ec 08             	sub    sp,0x8
    1caa:	89 e3                	mov    bx,sp
    1cac:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1cb0:	90                   	nop
    1cb1:	9b                   	fwait
    1cb2:	9a a7 2e e0 2f       	call   0x2fe0:0x2ea7
    1cb7:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    1cbb:	90                   	nop
    1cbc:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    1cc1:	90                   	nop
    1cc2:	9b                   	fwait
    1cc3:	c9                   	leave
    1cc4:	ca 08 00             	retf   0x8
    1cc7:	0a 48 53             	or     cl,BYTE PTR [bx+si+0x53]
    1cca:	56                   	push   si
    1ccb:	6f                   	outs   dx,WORD PTR ds:[si]
    1ccc:	6c                   	ins    BYTE PTR es:[di],dx
    1ccd:	75 6d                	jne    0x1d3c
    1ccf:	65 50                	gs push ax
    1cd1:	43                   	inc    bx
    1cd2:	00 00                	add    BYTE PTR [bx+si],al
    1cd4:	fc                   	cld
    1cd5:	21 db                	and    bx,bx
    1cd7:	1d 10 48             	sbb    ax,0x4810
    1cda:	65 75 72             	gs jne 0x1d4f
    1cdd:	65 73 50             	gs jae 0x1d30
    1ce0:	61                   	popa
    1ce1:	72 4d                	jb     0x1d30
    1ce3:	61                   	popa
    1ce4:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1ce7:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ce8:	65 12 48 65          	adc    cl,BYTE PTR gs:[bx+si+0x65]
    1cec:	75 72                	jne    0x1d60
    1cee:	65 73 50             	gs jae 0x1d41
    1cf1:	61                   	popa
    1cf2:	72 50                	jb     0x1d44
    1cf4:	72 6f                	jb     0x1d65
    1cf6:	64 75 63             	fs jne 0x1d5c
    1cf9:	74 69                	je     0x1d64
    1cfb:	66 10 43 6f          	data32 adc BYTE PTR [bp+di+0x6f],al
    1cff:	75 74                	jne    0x1d75
    1d01:	55                   	push   bp
    1d02:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d03:	69 74 65 56 65       	imul   si,WORD PTR [si+0x65],0x6556
    1d08:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d09:	64 65 75 72          	fs gs jne 0x1d7f
    1d0d:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    1d10:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d11:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d12:	65 73 50             	gs jae 0x1d65
    1d15:	63 08                	arpl   WORD PTR [bx+si],cx
    1d17:	47                   	inc    di
    1d18:	72 65                	jb     0x1d7f
    1d1a:	76 65                	jbe    0x1d81
    1d1c:	73 50                	jae    0x1d6e
    1d1e:	63 0a                	arpl   WORD PTR [bp+si],cx
    1d20:	49                   	dec    cx
    1d21:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d22:	64 69 63 65 50 72    	imul   sp,WORD PTR fs:[bp+di+0x65],0x7250
    1d28:	69 78 09 43 61       	imul   di,WORD PTR [bx+si+0x9],0x6143
    1d2d:	74 61                	je     0x1d90
    1d2f:	53                   	push   bx
    1d30:	74 79                	je     0x1dab
    1d32:	6c                   	ins    BYTE PTR es:[di],dx
    1d33:	65 00 80 ff ff       	add    BYTE PTR gs:[bx+si-0x1],al
    1d38:	ff                   	(bad)
    1d39:	7f 00                	jg     0x1d3b
    1d3b:	00 0e 43 61          	add    BYTE PTR ds:0x6143,cl
    1d3f:	74 61                	je     0x1da2
    1d41:	44                   	inc    sp
    1d42:	65 73 74             	gs jae 0x1db9
    1d45:	72 4d                	jb     0x1d94
    1d47:	6f                   	outs   dx,WORD PTR ds:[si]
    1d48:	79 50                	jns    0x1d9a
    1d4a:	63 0b                	arpl   WORD PTR [bp+di],cx
    1d4c:	43                   	inc    bx
    1d4d:	61                   	popa
    1d4e:	74 61                	je     0x1db1
    1d50:	50                   	push   ax
    1d51:	72 6f                	jb     0x1dc2
    1d53:	62 61 50             	bound  sp,DWORD PTR [bx+di+0x50]
    1d56:	63 0f                	arpl   WORD PTR [bx],cx
    1d58:	43                   	inc    bx
    1d59:	61                   	popa
    1d5a:	74 61                	je     0x1dbd
    1d5c:	44                   	inc    sp
    1d5d:	65 73 74             	gs jae 0x1dd4
    1d60:	72 45                	jb     0x1da7
    1d62:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d63:	74 31                	je     0x1d96
    1d65:	50                   	push   ax
    1d66:	63 0f                	arpl   WORD PTR [bx],cx
    1d68:	43                   	inc    bx
    1d69:	61                   	popa
    1d6a:	74 61                	je     0x1dcd
    1d6c:	44                   	inc    sp
    1d6d:	65 73 74             	gs jae 0x1de4
    1d70:	72 45                	jb     0x1db7
    1d72:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d73:	74 32                	je     0x1da7
    1d75:	50                   	push   ax
    1d76:	63 0f                	arpl   WORD PTR [bx],cx
    1d78:	43                   	inc    bx
    1d79:	61                   	popa
    1d7a:	74 61                	je     0x1ddd
    1d7c:	44                   	inc    sp
    1d7d:	65 73 74             	gs jae 0x1df4
    1d80:	72 45                	jb     0x1dc7
    1d82:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d83:	74 33                	je     0x1db8
    1d85:	50                   	push   ax
    1d86:	63 0f                	arpl   WORD PTR [bx],cx
    1d88:	43                   	inc    bx
    1d89:	61                   	popa
    1d8a:	74 61                	je     0x1ded
    1d8c:	44                   	inc    sp
    1d8d:	65 73 74             	gs jae 0x1e04
    1d90:	72 45                	jb     0x1dd7
    1d92:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d93:	74 34                	je     0x1dc9
    1d95:	50                   	push   ax
    1d96:	63 0f                	arpl   WORD PTR [bx],cx
    1d98:	43                   	inc    bx
    1d99:	61                   	popa
    1d9a:	74 61                	je     0x1dfd
    1d9c:	44                   	inc    sp
    1d9d:	65 73 74             	gs jae 0x1e14
    1da0:	72 45                	jb     0x1de7
    1da2:	6e                   	outs   dx,BYTE PTR ds:[si]
    1da3:	74 35                	je     0x1dda
    1da5:	50                   	push   ax
    1da6:	63 0f                	arpl   WORD PTR [bx],cx
    1da8:	43                   	inc    bx
    1da9:	61                   	popa
    1daa:	74 61                	je     0x1e0d
    1dac:	44                   	inc    sp
    1dad:	65 73 74             	gs jae 0x1e24
    1db0:	72 45                	jb     0x1df7
    1db2:	6e                   	outs   dx,BYTE PTR ds:[si]
    1db3:	74 36                	je     0x1deb
    1db5:	50                   	push   ax
    1db6:	63 0f                	arpl   WORD PTR [bx],cx
    1db8:	43                   	inc    bx
    1db9:	61                   	popa
    1dba:	74 61                	je     0x1e1d
    1dbc:	44                   	inc    sp
    1dbd:	65 73 74             	gs jae 0x1e34
    1dc0:	72 45                	jb     0x1e07
    1dc2:	6e                   	outs   dx,BYTE PTR ds:[si]
    1dc3:	74 37                	je     0x1dfc
    1dc5:	50                   	push   ax
    1dc6:	63 0f                	arpl   WORD PTR [bx],cx
    1dc8:	43                   	inc    bx
    1dc9:	61                   	popa
    1dca:	74 61                	je     0x1e2d
    1dcc:	44                   	inc    sp
    1dcd:	65 73 74             	gs jae 0x1e44
    1dd0:	72 45                	jb     0x1e17
    1dd2:	6e                   	outs   dx,BYTE PTR ds:[si]
    1dd3:	74 38                	je     0x1e0d
    1dd5:	50                   	push   ax
    1dd6:	63 00                	arpl   WORD PTR [bx+si],ax
    1dd8:	00 f6                	add    dh,dh
    1dda:	24 7a                	and    al,0x7a
    1ddc:	1e                   	push   ds
    1ddd:	01 00                	add    WORD PTR [bx+si],ax
    1ddf:	00 00                	add    BYTE PTR [bx+si],al
    1de1:	02 00                	add    al,BYTE PTR [bx+si]
    1de3:	00 00                	add    BYTE PTR [bx+si],al
    1de5:	12 41 70             	adc    al,BYTE PTR [bx+di+0x70]
    1de8:	70 65                	jo     0x1e4f
    1dea:	6c                   	ins    BYTE PTR es:[di],dx
    1deb:	4f                   	dec    di
    1dec:	66 66 72 65          	data32 data32 jb 0x1e55
    1df0:	51                   	push   cx
    1df1:	75 61                	jne    0x1e54
    1df3:	6e                   	outs   dx,BYTE PTR ds:[si]
    1df4:	74 69                	je     0x1e5f
    1df6:	74 65                	je     0x1e5d
    1df8:	11 41 70             	adc    WORD PTR [bx+di+0x70],ax
    1dfb:	70 65                	jo     0x1e62
    1dfd:	6c                   	ins    BYTE PTR es:[di],dx
    1dfe:	4f                   	dec    di
    1dff:	66 66 72 65          	data32 data32 jb 0x1e68
    1e03:	50                   	push   ax
    1e04:	72 69                	jb     0x1e6f
    1e06:	78 4d                	js     0x1e55
    1e08:	61                   	popa
    1e09:	78 0b                	js     0x1e16
    1e0b:	50                   	push   ax
    1e0c:	72 69                	jb     0x1e77
    1e0e:	78 4d                	js     0x1e5d
    1e10:	69 6e 69 6d 75       	imul   bp,WORD PTR [bp+0x69],0x756d
    1e15:	6d                   	ins    WORD PTR es:[di],dx
    1e16:	0b 50 72             	or     dx,WORD PTR [bx+si+0x72]
    1e19:	69 78 4d 61 78       	imul   di,WORD PTR [bx+si+0x4d],0x7861
    1e1e:	69 6d 75 6d 09       	imul   bp,WORD PTR [di+0x75],0x96d
    1e23:	50                   	push   ax
    1e24:	6f                   	outs   dx,WORD PTR ds:[si]
    1e25:	69 64 73 50 72       	imul   sp,WORD PTR [si+0x73],0x7250
    1e2a:	69 78 0e 50 6f       	imul   di,WORD PTR [bx+si+0xe],0x6f50
    1e2f:	69 64 73 50 75       	imul   sp,WORD PTR [si+0x73],0x7550
    1e34:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
    1e37:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    1e3a:	65 0f                	gs movmskps ebp,(bad)
    1e3c:	50                   	push   ax
    1e3d:	6f                   	outs   dx,WORD PTR ds:[si]
    1e3e:	69 64 73 46 6f       	imul   sp,WORD PTR [si+0x73],0x6f46
    1e43:	72 63                	jb     0x1ea8
    1e45:	65 56                	gs push si
    1e47:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1e49:	74 65                	je     0x1eb0
    1e4b:	0b 50 6f             	or     dx,WORD PTR [bx+si+0x6f]
    1e4e:	69 64 73 43 72       	imul   sp,WORD PTR [si+0x73],0x7243
    1e53:	65 64 69 74 0c 50 6f 	gs imul si,WORD PTR fs:[si+0xc],0x6f50
    1e5a:	69 64 73 51 75       	imul   sp,WORD PTR [si+0x73],0x7551
    1e5f:	61                   	popa
    1e60:	6c                   	ins    BYTE PTR es:[di],dx
    1e61:	69 74 65 11 50       	imul   si,WORD PTR [si+0x65],0x5011
    1e66:	6f                   	outs   dx,WORD PTR ds:[si]
    1e67:	69 64 73 46 69       	imul   sp,WORD PTR [si+0x73],0x6946
    1e6c:	64 65 6c             	fs gs ins BYTE PTR es:[di],dx
    1e6f:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    1e74:	6f                   	outs   dx,WORD PTR ds:[si]
    1e75:	6e                   	outs   dx,BYTE PTR ds:[si]
    1e76:	00 00                	add    BYTE PTR [bx+si],al
    1e78:	b2 27                	mov    dl,0x27
    1e7a:	ab                   	stos   WORD PTR es:[di],ax
    1e7b:	1e                   	push   ds
    1e7c:	01 00                	add    WORD PTR [bx+si],ax
    1e7e:	00 00                	add    BYTE PTR [bx+si],al
    1e80:	08 00                	or     BYTE PTR [bx+si],al
    1e82:	00 00                	add    BYTE PTR [bx+si],al
    1e84:	0e                   	push   cs
    1e85:	49                   	dec    cx
    1e86:	6e                   	outs   dx,BYTE PTR ds:[si]
    1e87:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    1e8d:	6c                   	ins    BYTE PTR es:[di],dx
    1e8e:	61                   	popa
    1e8f:	69 72 65 73 13       	imul   si,WORD PTR [bp+si+0x65],0x1373
    1e94:	45                   	inc    bp
    1e95:	6e                   	outs   dx,BYTE PTR ds:[si]
    1e96:	74 72                	je     0x1f0a
    1e98:	65 74 69             	gs je  0x1f04
    1e9b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1e9d:	4d                   	dec    bp
    1e9e:	61                   	popa
    1e9f:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1ea2:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ea3:	65 73 50             	gs jae 0x1ef6
    1ea6:	63 00                	arpl   WORD PTR [bx+si],ax
    1ea8:	00 33                	add    BYTE PTR [bp+di],dh
    1eaa:	29 33                	sub    WORD PTR [bp+di],si
    1eac:	1f                   	pop    ds
    1ead:	01 00                	add    WORD PTR [bx+si],ax
    1eaf:	00 00                	add    BYTE PTR [bx+si],al
    1eb1:	08 00                	or     BYTE PTR [bx+si],al
    1eb3:	00 00                	add    BYTE PTR [bx+si],al
    1eb5:	01 00                	add    WORD PTR [bx+si],ax
    1eb7:	00 00                	add    BYTE PTR [bx+si],al
    1eb9:	02 00                	add    al,BYTE PTR [bx+si]
    1ebb:	00 00                	add    BYTE PTR [bx+si],al
    1ebd:	04 50                	add    al,0x50
    1ebf:	72 69                	jb     0x1f2a
    1ec1:	78 09                	js     0x1ecc
    1ec3:	50                   	push   ax
    1ec4:	75 62                	jne    0x1f28
    1ec6:	6c                   	ins    BYTE PTR es:[di],dx
    1ec7:	69 63 69 74 65       	imul   sp,WORD PTR [bp+di+0x69],0x6574
    1ecc:	0f 44 65 70          	cmove  sp,WORD PTR [di+0x70]
    1ed0:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1ed2:	73 65                	jae    0x1f39
    1ed4:	73 51                	jae    0x1f27
    1ed6:	75 61                	jne    0x1f39
    1ed8:	6c                   	ins    BYTE PTR es:[di],dx
    1ed9:	69 74 65 10 56       	imul   si,WORD PTR [si+0x65],0x5610
    1ede:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1ee0:	64 65 75 72          	fs gs jne 0x1f56
    1ee4:	73 41                	jae    0x1f27
    1ee6:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    1eec:	73 11                	jae    0x1eff
    1eee:	44                   	inc    sp
    1eef:	75 72                	jne    0x1f63
    1ef1:	65 65 43             	gs gs inc bx
    1ef4:	72 65                	jb     0x1f5b
    1ef6:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    1efc:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1efe:	74 0a                	je     0x1f0a
    1f00:	50                   	push   ax
    1f01:	72 6f                	jb     0x1f72
    1f03:	64 75 63             	fs jne 0x1f69
    1f06:	74 69                	je     0x1f71
    1f08:	6f                   	outs   dx,WORD PTR ds:[si]
    1f09:	6e                   	outs   dx,BYTE PTR ds:[si]
    1f0a:	11 4d 61             	adc    WORD PTR [di+0x61],cx
    1f0d:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1f10:	6e                   	outs   dx,BYTE PTR ds:[si]
    1f11:	65 73 41             	gs jae 0x1f55
    1f14:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    1f1a:	65 73 12             	gs jae 0x1f2f
    1f1d:	50                   	push   ax
    1f1e:	72 6f                	jb     0x1f8f
    1f20:	64 75 63             	fs jne 0x1f86
    1f23:	74 69                	je     0x1f8e
    1f25:	66 73 41             	data32 jae 0x1f69
    1f28:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    1f2e:	73 00                	jae    0x1f30
    1f30:	00 53 2c             	add    BYTE PTR [bp+di+0x2c],dl
    1f33:	74 1f                	je     0x1f54
    1f35:	01 00                	add    WORD PTR [bx+si],ax
    1f37:	00 00                	add    BYTE PTR [bx+si],al
    1f39:	08 00                	or     BYTE PTR [bx+si],al
    1f3b:	00 00                	add    BYTE PTR [bx+si],al
    1f3d:	01 00                	add    WORD PTR [bx+si],ax
    1f3f:	00 00                	add    BYTE PTR [bx+si],al
    1f41:	02 00                	add    al,BYTE PTR [bx+si]
    1f43:	00 00                	add    BYTE PTR [bx+si],al
    1f45:	08 51 74             	or     BYTE PTR [bx+di+0x74],dl
    1f48:	65 53                	gs push bx
    1f4a:	74 6f                	je     0x1fbb
    1f4c:	63 6b 0b             	arpl   WORD PTR [bp+di+0xb],bp
    1f4f:	45                   	inc    bp
    1f50:	66 66 65 74 47       	data32 data32 gs je 0x1f9c
    1f55:	6c                   	ins    BYTE PTR es:[di],dx
    1f56:	6f                   	outs   dx,WORD PTR ds:[si]
    1f57:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
    1f5a:	15 54 65             	adc    ax,0x6554
    1f5d:	6d                   	ins    WORD PTR es:[di],dx
    1f5e:	70 73                	jo     0x1fd3
    1f60:	46                   	inc    si
    1f61:	61                   	popa
    1f62:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    1f65:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    1f68:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    1f6d:	74 75                	je     0x1fe4
    1f6f:	72 00                	jb     0x1f71
    1f71:	00 f3                	add    bl,dh
    1f73:	2d d0 1f             	sub    ax,0x1fd0
    1f76:	00 00                	add    BYTE PTR [bx+si],al
    1f78:	00 00                	add    BYTE PTR [bx+si],al
    1f7a:	01 00                	add    WORD PTR [bx+si],ax
    1f7c:	00 00                	add    BYTE PTR [bx+si],al
    1f7e:	08 00                	or     BYTE PTR [bx+si],al
    1f80:	00 00                	add    BYTE PTR [bx+si],al
    1f82:	00 00                	add    BYTE PTR [bx+si],al
    1f84:	20 41 00             	and    BYTE PTR [bx+di+0x0],al
    1f87:	00 80 3f 00          	add    BYTE PTR [bx+si+0x3f],al
    1f8b:	00 c8                	add    al,cl
    1f8d:	42                   	inc    dx
    1f8e:	00 00                	add    BYTE PTR [bx+si],al
    1f90:	a0 c0 00             	mov    al,ds:0xc0
    1f93:	00 c0                	add    al,al
    1f95:	40                   	inc    ax
    1f96:	01 00                	add    WORD PTR [bx+si],ax
    1f98:	00 00                	add    BYTE PTR [bx+si],al
    1f9a:	02 00                	add    al,BYTE PTR [bx+si]
    1f9c:	00 00                	add    BYTE PTR [bx+si],al
    1f9e:	0b 4c 69             	or     cx,WORD PTR [si+0x69]
    1fa1:	71 75                	jno    0x2018
    1fa3:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    1fa8:	6f                   	outs   dx,WORD PTR ds:[si]
    1fa9:	6e                   	outs   dx,BYTE PTR ds:[si]
    1faa:	12 53 6f             	adc    dl,BYTE PTR [bp+di+0x6f]
    1fad:	75 6d                	jne    0x201c
    1faf:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    1fb4:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fb5:	51                   	push   cx
    1fb6:	75 61                	jne    0x2019
    1fb8:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fb9:	74 69                	je     0x2024
    1fbb:	74 65                	je     0x2022
    1fbd:	0e                   	push   cs
    1fbe:	53                   	push   bx
    1fbf:	6f                   	outs   dx,WORD PTR ds:[si]
    1fc0:	75 6d                	jne    0x202f
    1fc2:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    1fc7:	6e                   	outs   dx,BYTE PTR ds:[si]
    1fc8:	50                   	push   ax
    1fc9:	72 69                	jb     0x2034
    1fcb:	78 00                	js     0x1fcd
    1fcd:	00 e5                	add    ch,ah
    1fcf:	40                   	inc    ax
    1fd0:	0b 21                	or     sp,WORD PTR [bx+di]
    1fd2:	01 00                	add    WORD PTR [bx+si],ax
    1fd4:	00 00                	add    BYTE PTR [bx+si],al
    1fd6:	08 00                	or     BYTE PTR [bx+si],al
    1fd8:	00 00                	add    BYTE PTR [bx+si],al
    1fda:	01 00                	add    WORD PTR [bx+si],ax
    1fdc:	00 00                	add    BYTE PTR [bx+si],al
    1fde:	02 00                	add    al,BYTE PTR [bx+si]
    1fe0:	00 00                	add    BYTE PTR [bx+si],al
    1fe2:	00 00                	add    BYTE PTR [bx+si],al
    1fe4:	00 00                	add    BYTE PTR [bx+si],al
    1fe6:	9a 99 99 99 99       	call   0x9999:0x9999
    1feb:	99                   	cwd
    1fec:	99                   	cwd
    1fed:	99                   	cwd
    1fee:	fe                   	(bad)
    1fef:	3f                   	aas
    1ff0:	00 00                	add    BYTE PTR [bx+si],al
    1ff2:	c8 42 09 45          	enter  0x942,0x45
    1ff6:	66 66 65 74 50       	data32 data32 gs je 0x204b
    1ffb:	72 69                	jb     0x2066
    1ffd:	78 08                	js     0x2007
    1fff:	45                   	inc    bp
    2000:	66 66 65 74 50       	data32 data32 gs je 0x2055
    2005:	75 62                	jne    0x2069
    2007:	07                   	pop    es
    2008:	45                   	inc    bp
    2009:	66 66 65 74 46       	data32 data32 gs je 0x2054
    200e:	56                   	push   si
    200f:	0b 45 66             	or     ax,WORD PTR [di+0x66]
    2012:	66 65 74 43          	data32 gs je 0x2059
    2016:	72 65                	jb     0x207d
    2018:	64 69 74 0c 45 66    	imul   si,WORD PTR fs:[si+0xc],0x6645
    201e:	66 65 74 51          	data32 gs je 0x2073
    2022:	75 61                	jne    0x2085
    2024:	6c                   	ins    BYTE PTR es:[di],dx
    2025:	69 74 65 0b 45       	imul   si,WORD PTR [si+0x65],0x450b
    202a:	66 66 65 74 47       	data32 data32 gs je 0x2076
    202f:	6c                   	ins    BYTE PTR es:[di],dx
    2030:	6f                   	outs   dx,WORD PTR ds:[si]
    2031:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
    2034:	07                   	pop    es
    2035:	44                   	inc    sp
    2036:	65 6d                	gs ins WORD PTR es:[di],dx
    2038:	61                   	popa
    2039:	6e                   	outs   dx,BYTE PTR ds:[si]
    203a:	64 65 06             	fs gs push es
    203d:	56                   	push   si
    203e:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2040:	74 65                	je     0x20a7
    2042:	73 14                	jae    0x2058
    2044:	44                   	inc    sp
    2045:	65 6d                	gs ins WORD PTR es:[di],dx
    2047:	61                   	popa
    2048:	6e                   	outs   dx,BYTE PTR ds:[si]
    2049:	64 65 4e             	fs gs dec si
    204c:	6f                   	outs   dx,WORD PTR ds:[si]
    204d:	6e                   	outs   dx,BYTE PTR ds:[si]
    204e:	53                   	push   bx
    204f:	61                   	popa
    2050:	74 69                	je     0x20bb
    2052:	73 66                	jae    0x20ba
    2054:	61                   	popa
    2055:	69 74 65 0c 56       	imul   si,WORD PTR [si+0x65],0x560c
    205a:	65 6e                	outs   dx,BYTE PTR gs:[si]
    205c:	74 65                	je     0x20c3
    205e:	73 50                	jae    0x20b0
    2060:	72 69                	jb     0x20cb
    2062:	73 65                	jae    0x20c9
    2064:	73 10                	jae    0x2076
    2066:	56                   	push   si
    2067:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2069:	74 65                	je     0x20d0
    206b:	73 53                	jae    0x20c0
    206d:	6f                   	outs   dx,WORD PTR ds:[si]
    206e:	6c                   	ins    BYTE PTR es:[di],dx
    206f:	64 65 65 73 51       	fs gs gs jae 0x20c5
    2074:	74 65                	je     0x20db
    2076:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    2079:	6e                   	outs   dx,BYTE PTR ds:[si]
    207a:	74 65                	je     0x20e1
    207c:	73 53                	jae    0x20d1
    207e:	6f                   	outs   dx,WORD PTR ds:[si]
    207f:	6c                   	ins    BYTE PTR es:[di],dx
    2080:	64 65 65 73 50       	fs gs gs jae 0x20d5
    2085:	72 69                	jb     0x20f0
    2087:	78 0c                	js     0x2095
    2089:	56                   	push   si
    208a:	65 6e                	outs   dx,BYTE PTR gs:[si]
    208c:	74 65                	je     0x20f3
    208e:	73 53                	jae    0x20e3
    2090:	70 65                	jo     0x20f7
    2092:	51                   	push   cx
    2093:	74 65                	je     0x20fa
    2095:	0d 56 65             	or     ax,0x6556
    2098:	6e                   	outs   dx,BYTE PTR ds:[si]
    2099:	74 65                	je     0x2100
    209b:	73 53                	jae    0x20f0
    209d:	70 65                	jo     0x2104
    209f:	50                   	push   ax
    20a0:	72 69                	jb     0x210b
    20a2:	78 08                	js     0x20ac
    20a4:	51                   	push   cx
    20a5:	74 65                	je     0x210c
    20a7:	53                   	push   bx
    20a8:	74 6f                	je     0x2119
    20aa:	63 6b 0a             	arpl   WORD PTR [bp+di+0xa],bp
    20ad:	50                   	push   ax
    20ae:	61                   	popa
    20af:	72 74                	jb     0x2125
    20b1:	4d                   	dec    bp
    20b2:	61                   	popa
    20b3:	72 63                	jb     0x2118
    20b5:	68 65 0b             	push   0xb65
    20b8:	56                   	push   si
    20b9:	61                   	popa
    20ba:	6c                   	ins    BYTE PTR es:[di],dx
    20bb:	65 75 72             	gs jne 0x2130
    20be:	53                   	push   bx
    20bf:	74 6f                	je     0x2130
    20c1:	63 6b 10             	arpl   WORD PTR [bp+di+0x10],bp
    20c4:	44                   	inc    sp
    20c5:	6f                   	outs   dx,WORD PTR ds:[si]
    20c6:	74 41                	je     0x2109
    20c8:	6d                   	ins    WORD PTR es:[di],dx
    20c9:	6f                   	outs   dx,WORD PTR ds:[si]
    20ca:	72 74                	jb     0x2140
    20cc:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    20d1:	65 6e                	outs   dx,BYTE PTR gs:[si]
    20d3:	74 15                	je     0x20ea
    20d5:	54                   	push   sp
    20d6:	65 6d                	gs ins WORD PTR es:[di],dx
    20d8:	70 73                	jo     0x214d
    20da:	46                   	inc    si
    20db:	61                   	popa
    20dc:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    20df:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    20e2:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    20e7:	74 75                	je     0x215e
    20e9:	72 10                	jb     0x20fb
    20eb:	50                   	push   ax
    20ec:	72 6f                	jb     0x215d
    20ee:	64 75 63             	fs jne 0x2154
    20f1:	74 69                	je     0x215c
    20f3:	6f                   	outs   dx,WORD PTR ds:[si]
    20f4:	6e                   	outs   dx,BYTE PTR ds:[si]
    20f5:	52                   	push   dx
    20f6:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    20f9:	6c                   	ins    BYTE PTR es:[di],dx
    20fa:	65 0b 48 65          	or     cx,WORD PTR gs:[bx+si+0x65]
    20fe:	75 72                	jne    0x2172
    2100:	65 73 53             	gs jae 0x2156
    2103:	75 70                	jne    0x2175
    2105:	50                   	push   ax
    2106:	63 00                	arpl   WORD PTR [bx+si],ax
    2108:	00 6f 56             	add    BYTE PTR [bx+0x56],ch
    210b:	51                   	push   cx
    210c:	21 14                	and    WORD PTR [si],dx
    210e:	4d                   	dec    bp
    210f:	61                   	popa
    2110:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    2113:	6e                   	outs   dx,BYTE PTR ds:[si]
    2114:	65 73 44             	gs jae 0x215b
    2117:	65 74 72             	gs je  0x218c
    211a:	75 69                	jne    0x2185
    211c:	74 65                	je     0x2183
    211e:	73 51                	jae    0x2171
    2120:	74 65                	je     0x2187
    2122:	01 00                	add    WORD PTR [bx+si],ax
    2124:	00 00                	add    BYTE PTR [bx+si],al
    2126:	08 00                	or     BYTE PTR [bx+si],al
    2128:	00 00                	add    BYTE PTR [bx+si],al
    212a:	10 41 67             	adc    BYTE PTR [bx+di+0x67],al
    212d:	65 4d                	gs dec bp
    212f:	6f                   	outs   dx,WORD PTR ds:[si]
    2130:	79 65                	jns    0x2197
    2132:	6e                   	outs   dx,BYTE PTR ds:[si]
    2133:	4d                   	dec    bp
    2134:	61                   	popa
    2135:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    2138:	6e                   	outs   dx,BYTE PTR ds:[si]
    2139:	65 73 08             	gs jae 0x2144
    213c:	50                   	push   ax
    213d:	61                   	popa
    213e:	6e                   	outs   dx,BYTE PTR ds:[si]
    213f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2140:	65 73 50             	gs jae 0x2193
    2143:	63 08                	arpl   WORD PTR [bx+si],cx
    2145:	47                   	inc    di
    2146:	72 65                	jb     0x21ad
    2148:	76 65                	jbe    0x21af
    214a:	73 50                	jae    0x219c
    214c:	63 00                	arpl   WORD PTR [bx+si],ax
    214e:	00 0a                	add    BYTE PTR [bp+si],cl
    2150:	58                   	pop    ax
    2151:	6c                   	ins    BYTE PTR es:[di],dx
    2152:	21 0c                	and    WORD PTR [si],cx
    2154:	56                   	push   si
    2155:	6f                   	outs   dx,WORD PTR ds:[si]
    2156:	6c                   	ins    BYTE PTR es:[di],dx
    2157:	75 6d                	jne    0x21c6
    2159:	65 4d                	gs dec bp
    215b:	61                   	popa
    215c:	72 63                	jb     0x21c1
    215e:	68 65 01             	push   0x165
    2161:	00 00                	add    BYTE PTR [bx+si],al
    2163:	00 02                	add    BYTE PTR [bp+si],al
    2165:	00 00                	add    BYTE PTR [bx+si],al
    2167:	00 00                	add    BYTE PTR [bx+si],al
    2169:	00 df                	add    bh,bl
    216b:	58                   	pop    ax
    216c:	cb                   	retf
    216d:	21 55 89             	and    WORD PTR [di-0x77],dx
    2170:	e5 b8                	in     ax,0xb8
    2172:	aa                   	stos   BYTE PTR es:[di],al
    2173:	0e                   	push   cs
    2174:	9a 44 04 4a 23       	call   0x234a:0x444
    2179:	81 ec aa 0e          	sub    sp,0xeaa
    217d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2180:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2185:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    2189:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    218d:	b8 d2 1c             	mov    ax,0x1cd2
    2190:	0e                   	push   cs
    2191:	50                   	push   ax
    2192:	55                   	push   bp
    2193:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2197:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    219b:	c7 86 68 f1 01 00    	mov    WORD PTR [bp-0xe98],0x1
    21a1:	c7 86 6a f1 00 00    	mov    WORD PTR [bp-0xe96],0x0
    21a7:	c6 86 6c f1 00       	mov    BYTE PTR [bp-0xe94],0x0
    21ac:	8d be 68 f1          	lea    di,[bp-0xe98]
    21b0:	16                   	push   ss
    21b1:	57                   	push   di
    21b2:	6a 00                	push   0x0
    21b4:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    21b8:	06                   	push   es
    21b9:	57                   	push   di
    21ba:	9a 95 28 3d 22       	call   0x223d:0x2895
    21bf:	08 c0                	or     al,al
    21c1:	75 0a                	jne    0x21cd
    21c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c6:	06                   	push   es
    21c7:	57                   	push   di
    21c8:	9a 03 03 4b 22       	call   0x224b:0x303
    21cd:	bf c7 1c             	mov    di,0x1cc7
    21d0:	0e                   	push   cs
    21d1:	57                   	push   di
    21d2:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    21d6:	06                   	push   es
    21d7:	57                   	push   di
    21d8:	9a 9b 3b 5b 22       	call   0x225b:0x3b9b
    21dd:	89 c7                	mov    di,ax
    21df:	8e c2                	mov    es,dx
    21e1:	06                   	push   es
    21e2:	57                   	push   di
    21e3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21e6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    21ea:	9b dd 5e f4          	fstp   QWORD PTR [bp-0xc]
    21ee:	90                   	nop
    21ef:	9b                   	fwait
    21f0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    21f4:	83 c4 06             	add    sp,0x6
    21f7:	b8 fd 21             	mov    ax,0x21fd
    21fa:	0e                   	push   cs
    21fb:	50                   	push   ax
    21fc:	cb                   	retf
    21fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2200:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    2205:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    2209:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    220d:	b8 d7 1d             	mov    ax,0x1dd7
    2210:	0e                   	push   cs
    2211:	50                   	push   ax
    2212:	55                   	push   bp
    2213:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2217:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    221b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    221e:	99                   	cwd
    221f:	89 86 68 f1          	mov    WORD PTR [bp-0xe98],ax
    2223:	89 96 6a f1          	mov    WORD PTR [bp-0xe96],dx
    2227:	c6 86 6c f1 00       	mov    BYTE PTR [bp-0xe94],0x0
    222c:	8d be 68 f1          	lea    di,[bp-0xe98]
    2230:	16                   	push   ss
    2231:	57                   	push   di
    2232:	6a 00                	push   0x0
    2234:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2238:	06                   	push   es
    2239:	57                   	push   di
    223a:	9a 95 28 73 25       	call   0x2573:0x2895
    223f:	08 c0                	or     al,al
    2241:	75 0a                	jne    0x224d
    2243:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2246:	06                   	push   es
    2247:	57                   	push   di
    2248:	9a 03 03 81 25       	call   0x2581:0x303
    224d:	bf d8 1c             	mov    di,0x1cd8
    2250:	0e                   	push   cs
    2251:	57                   	push   di
    2252:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2256:	06                   	push   es
    2257:	57                   	push   di
    2258:	9a 9b 3b 7f 22       	call   0x227f:0x3b9b
    225d:	89 c7                	mov    di,ax
    225f:	8e c2                	mov    es,dx
    2261:	06                   	push   es
    2262:	57                   	push   di
    2263:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2266:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    226a:	9b dd 9e 28 f9       	fstp   QWORD PTR [bp-0x6d8]
    226f:	90                   	nop
    2270:	9b                   	fwait
    2271:	bf e9 1c             	mov    di,0x1ce9
    2274:	0e                   	push   cs
    2275:	57                   	push   di
    2276:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    227a:	06                   	push   es
    227b:	57                   	push   di
    227c:	9a 9b 3b a3 22       	call   0x22a3:0x3b9b
    2281:	89 c7                	mov    di,ax
    2283:	8e c2                	mov    es,dx
    2285:	06                   	push   es
    2286:	57                   	push   di
    2287:	26 c4 3d             	les    di,DWORD PTR es:[di]
    228a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    228e:	9b dd 9e 20 f9       	fstp   QWORD PTR [bp-0x6e0]
    2293:	90                   	nop
    2294:	9b                   	fwait
    2295:	bf fc 1c             	mov    di,0x1cfc
    2298:	0e                   	push   cs
    2299:	57                   	push   di
    229a:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    229e:	06                   	push   es
    229f:	57                   	push   di
    22a0:	9a 9b 3b c7 22       	call   0x22c7:0x3b9b
    22a5:	89 c7                	mov    di,ax
    22a7:	8e c2                	mov    es,dx
    22a9:	06                   	push   es
    22aa:	57                   	push   di
    22ab:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22ae:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    22b2:	9b dd 9e 18 f9       	fstp   QWORD PTR [bp-0x6e8]
    22b7:	90                   	nop
    22b8:	9b                   	fwait
    22b9:	bf 0d 1d             	mov    di,0x1d0d
    22bc:	0e                   	push   cs
    22bd:	57                   	push   di
    22be:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    22c2:	06                   	push   es
    22c3:	57                   	push   di
    22c4:	9a 9b 3b ec 22       	call   0x22ec:0x3b9b
    22c9:	89 c7                	mov    di,ax
    22cb:	8e c2                	mov    es,dx
    22cd:	06                   	push   es
    22ce:	57                   	push   di
    22cf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22d2:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    22d6:	89 86 fe f3          	mov    WORD PTR [bp-0xc02],ax
    22da:	89 96 00 f4          	mov    WORD PTR [bp-0xc00],dx
    22de:	bf 16 1d             	mov    di,0x1d16
    22e1:	0e                   	push   cs
    22e2:	57                   	push   di
    22e3:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    22e7:	06                   	push   es
    22e8:	57                   	push   di
    22e9:	9a 9b 3b 11 23       	call   0x2311:0x3b9b
    22ee:	89 c7                	mov    di,ax
    22f0:	8e c2                	mov    es,dx
    22f2:	06                   	push   es
    22f3:	57                   	push   di
    22f4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22f7:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    22fb:	89 86 fa f3          	mov    WORD PTR [bp-0xc06],ax
    22ff:	89 96 fc f3          	mov    WORD PTR [bp-0xc04],dx
    2303:	bf 1f 1d             	mov    di,0x1d1f
    2306:	0e                   	push   cs
    2307:	57                   	push   di
    2308:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    230c:	06                   	push   es
    230d:	57                   	push   di
    230e:	9a 9b 3b 35 23       	call   0x2335:0x3b9b
    2313:	89 c7                	mov    di,ax
    2315:	8e c2                	mov    es,dx
    2317:	06                   	push   es
    2318:	57                   	push   di
    2319:	26 c4 3d             	les    di,DWORD PTR es:[di]
    231c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2320:	9b dd 9e 62 f2       	fstp   QWORD PTR [bp-0xd9e]
    2325:	90                   	nop
    2326:	9b                   	fwait
    2327:	bf 2a 1d             	mov    di,0x1d2a
    232a:	0e                   	push   cs
    232b:	57                   	push   di
    232c:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2330:	06                   	push   es
    2331:	57                   	push   di
    2332:	9a 9b 3b 5e 23       	call   0x235e:0x3b9b
    2337:	89 c7                	mov    di,ax
    2339:	8e c2                	mov    es,dx
    233b:	06                   	push   es
    233c:	57                   	push   di
    233d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2340:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2344:	bf 34 1d             	mov    di,0x1d34
    2347:	9a 16 04 73 23       	call   0x2373:0x416
    234c:	89 86 d4 f1          	mov    WORD PTR [bp-0xe2c],ax
    2350:	bf 3c 1d             	mov    di,0x1d3c
    2353:	0e                   	push   cs
    2354:	57                   	push   di
    2355:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2359:	06                   	push   es
    235a:	57                   	push   di
    235b:	9a 9b 3b 87 23       	call   0x2387:0x3b9b
    2360:	89 c7                	mov    di,ax
    2362:	8e c2                	mov    es,dx
    2364:	06                   	push   es
    2365:	57                   	push   di
    2366:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2369:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    236d:	bf 34 1d             	mov    di,0x1d34
    2370:	9a 16 04 9c 23       	call   0x239c:0x416
    2375:	89 86 d2 f1          	mov    WORD PTR [bp-0xe2e],ax
    2379:	bf 4b 1d             	mov    di,0x1d4b
    237c:	0e                   	push   cs
    237d:	57                   	push   di
    237e:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2382:	06                   	push   es
    2383:	57                   	push   di
    2384:	9a 9b 3b b0 23       	call   0x23b0:0x3b9b
    2389:	89 c7                	mov    di,ax
    238b:	8e c2                	mov    es,dx
    238d:	06                   	push   es
    238e:	57                   	push   di
    238f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2392:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2396:	bf 34 1d             	mov    di,0x1d34
    2399:	9a 16 04 c5 23       	call   0x23c5:0x416
    239e:	89 86 d0 f1          	mov    WORD PTR [bp-0xe30],ax
    23a2:	bf 57 1d             	mov    di,0x1d57
    23a5:	0e                   	push   cs
    23a6:	57                   	push   di
    23a7:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    23ab:	06                   	push   es
    23ac:	57                   	push   di
    23ad:	9a 9b 3b d9 23       	call   0x23d9:0x3b9b
    23b2:	89 c7                	mov    di,ax
    23b4:	8e c2                	mov    es,dx
    23b6:	06                   	push   es
    23b7:	57                   	push   di
    23b8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23bb:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    23bf:	bf 34 1d             	mov    di,0x1d34
    23c2:	9a 16 04 ee 23       	call   0x23ee:0x416
    23c7:	89 86 c0 f1          	mov    WORD PTR [bp-0xe40],ax
    23cb:	bf 67 1d             	mov    di,0x1d67
    23ce:	0e                   	push   cs
    23cf:	57                   	push   di
    23d0:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    23d4:	06                   	push   es
    23d5:	57                   	push   di
    23d6:	9a 9b 3b 02 24       	call   0x2402:0x3b9b
    23db:	89 c7                	mov    di,ax
    23dd:	8e c2                	mov    es,dx
    23df:	06                   	push   es
    23e0:	57                   	push   di
    23e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23e4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    23e8:	bf 34 1d             	mov    di,0x1d34
    23eb:	9a 16 04 17 24       	call   0x2417:0x416
    23f0:	89 86 c2 f1          	mov    WORD PTR [bp-0xe3e],ax
    23f4:	bf 77 1d             	mov    di,0x1d77
    23f7:	0e                   	push   cs
    23f8:	57                   	push   di
    23f9:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    23fd:	06                   	push   es
    23fe:	57                   	push   di
    23ff:	9a 9b 3b 2b 24       	call   0x242b:0x3b9b
    2404:	89 c7                	mov    di,ax
    2406:	8e c2                	mov    es,dx
    2408:	06                   	push   es
    2409:	57                   	push   di
    240a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    240d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2411:	bf 34 1d             	mov    di,0x1d34
    2414:	9a 16 04 40 24       	call   0x2440:0x416
    2419:	89 86 c4 f1          	mov    WORD PTR [bp-0xe3c],ax
    241d:	bf 87 1d             	mov    di,0x1d87
    2420:	0e                   	push   cs
    2421:	57                   	push   di
    2422:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2426:	06                   	push   es
    2427:	57                   	push   di
    2428:	9a 9b 3b 54 24       	call   0x2454:0x3b9b
    242d:	89 c7                	mov    di,ax
    242f:	8e c2                	mov    es,dx
    2431:	06                   	push   es
    2432:	57                   	push   di
    2433:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2436:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    243a:	bf 34 1d             	mov    di,0x1d34
    243d:	9a 16 04 69 24       	call   0x2469:0x416
    2442:	89 86 c6 f1          	mov    WORD PTR [bp-0xe3a],ax
    2446:	bf 97 1d             	mov    di,0x1d97
    2449:	0e                   	push   cs
    244a:	57                   	push   di
    244b:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    244f:	06                   	push   es
    2450:	57                   	push   di
    2451:	9a 9b 3b 7d 24       	call   0x247d:0x3b9b
    2456:	89 c7                	mov    di,ax
    2458:	8e c2                	mov    es,dx
    245a:	06                   	push   es
    245b:	57                   	push   di
    245c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    245f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2463:	bf 34 1d             	mov    di,0x1d34
    2466:	9a 16 04 92 24       	call   0x2492:0x416
    246b:	89 86 c8 f1          	mov    WORD PTR [bp-0xe38],ax
    246f:	bf a7 1d             	mov    di,0x1da7
    2472:	0e                   	push   cs
    2473:	57                   	push   di
    2474:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2478:	06                   	push   es
    2479:	57                   	push   di
    247a:	9a 9b 3b a6 24       	call   0x24a6:0x3b9b
    247f:	89 c7                	mov    di,ax
    2481:	8e c2                	mov    es,dx
    2483:	06                   	push   es
    2484:	57                   	push   di
    2485:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2488:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    248c:	bf 34 1d             	mov    di,0x1d34
    248f:	9a 16 04 bb 24       	call   0x24bb:0x416
    2494:	89 86 ca f1          	mov    WORD PTR [bp-0xe36],ax
    2498:	bf b7 1d             	mov    di,0x1db7
    249b:	0e                   	push   cs
    249c:	57                   	push   di
    249d:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    24a1:	06                   	push   es
    24a2:	57                   	push   di
    24a3:	9a 9b 3b cf 24       	call   0x24cf:0x3b9b
    24a8:	89 c7                	mov    di,ax
    24aa:	8e c2                	mov    es,dx
    24ac:	06                   	push   es
    24ad:	57                   	push   di
    24ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24b1:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    24b5:	bf 34 1d             	mov    di,0x1d34
    24b8:	9a 16 04 e4 24       	call   0x24e4:0x416
    24bd:	89 86 cc f1          	mov    WORD PTR [bp-0xe34],ax
    24c1:	bf c7 1d             	mov    di,0x1dc7
    24c4:	0e                   	push   cs
    24c5:	57                   	push   di
    24c6:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    24ca:	06                   	push   es
    24cb:	57                   	push   di
    24cc:	9a 9b 3b 91 25       	call   0x2591:0x3b9b
    24d1:	89 c7                	mov    di,ax
    24d3:	8e c2                	mov    es,dx
    24d5:	06                   	push   es
    24d6:	57                   	push   di
    24d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24da:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    24de:	bf 34 1d             	mov    di,0x1d34
    24e1:	9a 16 04 ae 25       	call   0x25ae:0x416
    24e6:	89 86 ce f1          	mov    WORD PTR [bp-0xe32],ax
    24ea:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    24ee:	83 c4 06             	add    sp,0x6
    24f1:	b8 f7 24             	mov    ax,0x24f7
    24f4:	0e                   	push   cs
    24f5:	50                   	push   ax
    24f6:	cb                   	retf
    24f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24fa:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    24ff:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    2503:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    2507:	b8 76 1e             	mov    ax,0x1e76
    250a:	0e                   	push   cs
    250b:	50                   	push   ax
    250c:	55                   	push   bp
    250d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2511:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2515:	68 57 40             	push   0x4057
    2518:	68 14 6e             	push   0x6e14
    251b:	68 e1 7a             	push   0x7ae1
    251e:	68 ae 47             	push   0x47ae
    2521:	6a 21                	push   0x21
    2523:	9a 69 0a e6 30       	call   0x30e6:0xa69
    2528:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    252c:	b8 01 00             	mov    ax,0x1
    252f:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    2533:	7e 03                	jle    0x2538
    2535:	e9 6e 02             	jmp    0x27a6
    2538:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    253b:	eb 03                	jmp    0x2540
    253d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2540:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2543:	99                   	cwd
    2544:	89 86 5e f1          	mov    WORD PTR [bp-0xea2],ax
    2548:	89 96 60 f1          	mov    WORD PTR [bp-0xea0],dx
    254c:	c6 86 62 f1 00       	mov    BYTE PTR [bp-0xe9e],0x0
    2551:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2554:	99                   	cwd
    2555:	89 86 66 f1          	mov    WORD PTR [bp-0xe9a],ax
    2559:	89 96 68 f1          	mov    WORD PTR [bp-0xe98],dx
    255d:	c6 86 6a f1 00       	mov    BYTE PTR [bp-0xe96],0x0
    2562:	8d be 5e f1          	lea    di,[bp-0xea2]
    2566:	16                   	push   ss
    2567:	57                   	push   di
    2568:	6a 01                	push   0x1
    256a:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    256e:	06                   	push   es
    256f:	57                   	push   di
    2570:	9a 95 28 29 28       	call   0x2829:0x2895
    2575:	08 c0                	or     al,al
    2577:	75 0a                	jne    0x2583
    2579:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    257c:	06                   	push   es
    257d:	57                   	push   di
    257e:	9a 03 03 37 28       	call   0x2837:0x303
    2583:	bf e5 1d             	mov    di,0x1de5
    2586:	0e                   	push   cs
    2587:	57                   	push   di
    2588:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    258c:	06                   	push   es
    258d:	57                   	push   di
    258e:	9a 9b 3b cb 25       	call   0x25cb:0x3b9b
    2593:	89 c7                	mov    di,ax
    2595:	8e c2                	mov    es,dx
    2597:	06                   	push   es
    2598:	57                   	push   di
    2599:	26 c4 3d             	les    di,DWORD PTR es:[di]
    259c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    25a0:	8b c8                	mov    cx,ax
    25a2:	8b da                	mov    bx,dx
    25a4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    25a7:	99                   	cwd
    25a8:	bf dd 1d             	mov    di,0x1ddd
    25ab:	9a 16 04 e4 25       	call   0x25e4:0x416
    25b0:	8b f8                	mov    di,ax
    25b2:	c1 e7 02             	shl    di,0x2
    25b5:	89 8b 44 f6          	mov    WORD PTR [bp+di-0x9bc],cx
    25b9:	89 9b 46 f6          	mov    WORD PTR [bp+di-0x9ba],bx
    25bd:	bf f8 1d             	mov    di,0x1df8
    25c0:	0e                   	push   cs
    25c1:	57                   	push   di
    25c2:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    25c6:	06                   	push   es
    25c7:	57                   	push   di
    25c8:	9a 9b 3b 00 26       	call   0x2600:0x3b9b
    25cd:	89 c7                	mov    di,ax
    25cf:	8e c2                	mov    es,dx
    25d1:	06                   	push   es
    25d2:	57                   	push   di
    25d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    25d6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    25da:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    25dd:	99                   	cwd
    25de:	bf dd 1d             	mov    di,0x1ddd
    25e1:	9a 16 04 19 26       	call   0x2619:0x416
    25e6:	8b f8                	mov    di,ax
    25e8:	c1 e7 03             	shl    di,0x3
    25eb:	9b dd 9b 30 f6       	fstp   QWORD PTR [bp+di-0x9d0]
    25f0:	90                   	nop
    25f1:	9b                   	fwait
    25f2:	bf 0a 1e             	mov    di,0x1e0a
    25f5:	0e                   	push   cs
    25f6:	57                   	push   di
    25f7:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    25fb:	06                   	push   es
    25fc:	57                   	push   di
    25fd:	9a 9b 3b 35 26       	call   0x2635:0x3b9b
    2602:	89 c7                	mov    di,ax
    2604:	8e c2                	mov    es,dx
    2606:	06                   	push   es
    2607:	57                   	push   di
    2608:	26 c4 3d             	les    di,DWORD PTR es:[di]
    260b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    260f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2612:	99                   	cwd
    2613:	bf dd 1d             	mov    di,0x1ddd
    2616:	9a 16 04 4e 26       	call   0x264e:0x416
    261b:	8b f8                	mov    di,ax
    261d:	c1 e7 03             	shl    di,0x3
    2620:	9b dd 9b 00 f9       	fstp   QWORD PTR [bp+di-0x700]
    2625:	90                   	nop
    2626:	9b                   	fwait
    2627:	bf 16 1e             	mov    di,0x1e16
    262a:	0e                   	push   cs
    262b:	57                   	push   di
    262c:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2630:	06                   	push   es
    2631:	57                   	push   di
    2632:	9a 9b 3b 6a 26       	call   0x266a:0x3b9b
    2637:	89 c7                	mov    di,ax
    2639:	8e c2                	mov    es,dx
    263b:	06                   	push   es
    263c:	57                   	push   di
    263d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2640:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2644:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2647:	99                   	cwd
    2648:	bf dd 1d             	mov    di,0x1ddd
    264b:	9a 16 04 83 26       	call   0x2683:0x416
    2650:	8b f8                	mov    di,ax
    2652:	c1 e7 03             	shl    di,0x3
    2655:	9b dd 9b f0 f8       	fstp   QWORD PTR [bp+di-0x710]
    265a:	90                   	nop
    265b:	9b                   	fwait
    265c:	bf 22 1e             	mov    di,0x1e22
    265f:	0e                   	push   cs
    2660:	57                   	push   di
    2661:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2665:	06                   	push   es
    2666:	57                   	push   di
    2667:	9a 9b 3b 9f 26       	call   0x269f:0x3b9b
    266c:	89 c7                	mov    di,ax
    266e:	8e c2                	mov    es,dx
    2670:	06                   	push   es
    2671:	57                   	push   di
    2672:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2675:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2679:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    267c:	99                   	cwd
    267d:	bf dd 1d             	mov    di,0x1ddd
    2680:	9a 16 04 b8 26       	call   0x26b8:0x416
    2685:	8b f8                	mov    di,ax
    2687:	c1 e7 03             	shl    di,0x3
    268a:	9b dd 9b e0 f8       	fstp   QWORD PTR [bp+di-0x720]
    268f:	90                   	nop
    2690:	9b                   	fwait
    2691:	bf 2c 1e             	mov    di,0x1e2c
    2694:	0e                   	push   cs
    2695:	57                   	push   di
    2696:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    269a:	06                   	push   es
    269b:	57                   	push   di
    269c:	9a 9b 3b d4 26       	call   0x26d4:0x3b9b
    26a1:	89 c7                	mov    di,ax
    26a3:	8e c2                	mov    es,dx
    26a5:	06                   	push   es
    26a6:	57                   	push   di
    26a7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26aa:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    26ae:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    26b1:	99                   	cwd
    26b2:	bf dd 1d             	mov    di,0x1ddd
    26b5:	9a 16 04 ed 26       	call   0x26ed:0x416
    26ba:	8b f8                	mov    di,ax
    26bc:	c1 e7 03             	shl    di,0x3
    26bf:	9b dd 9b d0 f8       	fstp   QWORD PTR [bp+di-0x730]
    26c4:	90                   	nop
    26c5:	9b                   	fwait
    26c6:	bf 3b 1e             	mov    di,0x1e3b
    26c9:	0e                   	push   cs
    26ca:	57                   	push   di
    26cb:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    26cf:	06                   	push   es
    26d0:	57                   	push   di
    26d1:	9a 9b 3b 09 27       	call   0x2709:0x3b9b
    26d6:	89 c7                	mov    di,ax
    26d8:	8e c2                	mov    es,dx
    26da:	06                   	push   es
    26db:	57                   	push   di
    26dc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26df:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    26e3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    26e6:	99                   	cwd
    26e7:	bf dd 1d             	mov    di,0x1ddd
    26ea:	9a 16 04 22 27       	call   0x2722:0x416
    26ef:	8b f8                	mov    di,ax
    26f1:	c1 e7 03             	shl    di,0x3
    26f4:	9b dd 9b c0 f8       	fstp   QWORD PTR [bp+di-0x740]
    26f9:	90                   	nop
    26fa:	9b                   	fwait
    26fb:	bf 4b 1e             	mov    di,0x1e4b
    26fe:	0e                   	push   cs
    26ff:	57                   	push   di
    2700:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2704:	06                   	push   es
    2705:	57                   	push   di
    2706:	9a 9b 3b 3e 27       	call   0x273e:0x3b9b
    270b:	89 c7                	mov    di,ax
    270d:	8e c2                	mov    es,dx
    270f:	06                   	push   es
    2710:	57                   	push   di
    2711:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2714:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2718:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    271b:	99                   	cwd
    271c:	bf dd 1d             	mov    di,0x1ddd
    271f:	9a 16 04 57 27       	call   0x2757:0x416
    2724:	8b f8                	mov    di,ax
    2726:	c1 e7 03             	shl    di,0x3
    2729:	9b dd 9b b0 f8       	fstp   QWORD PTR [bp+di-0x750]
    272e:	90                   	nop
    272f:	9b                   	fwait
    2730:	bf 57 1e             	mov    di,0x1e57
    2733:	0e                   	push   cs
    2734:	57                   	push   di
    2735:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2739:	06                   	push   es
    273a:	57                   	push   di
    273b:	9a 9b 3b 73 27       	call   0x2773:0x3b9b
    2740:	89 c7                	mov    di,ax
    2742:	8e c2                	mov    es,dx
    2744:	06                   	push   es
    2745:	57                   	push   di
    2746:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2749:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    274d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2750:	99                   	cwd
    2751:	bf dd 1d             	mov    di,0x1ddd
    2754:	9a 16 04 8c 27       	call   0x278c:0x416
    2759:	8b f8                	mov    di,ax
    275b:	c1 e7 03             	shl    di,0x3
    275e:	9b dd 9b a0 f8       	fstp   QWORD PTR [bp+di-0x760]
    2763:	90                   	nop
    2764:	9b                   	fwait
    2765:	bf 64 1e             	mov    di,0x1e64
    2768:	0e                   	push   cs
    2769:	57                   	push   di
    276a:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    276e:	06                   	push   es
    276f:	57                   	push   di
    2770:	9a 9b 3b 47 28       	call   0x2847:0x3b9b
    2775:	89 c7                	mov    di,ax
    2777:	8e c2                	mov    es,dx
    2779:	06                   	push   es
    277a:	57                   	push   di
    277b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    277e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2782:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2785:	99                   	cwd
    2786:	bf dd 1d             	mov    di,0x1ddd
    2789:	9a 16 04 f7 27       	call   0x27f7:0x416
    278e:	8b f8                	mov    di,ax
    2790:	c1 e7 03             	shl    di,0x3
    2793:	9b dd 9b 90 f8       	fstp   QWORD PTR [bp+di-0x770]
    2798:	90                   	nop
    2799:	9b                   	fwait
    279a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    279d:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    27a1:	74 03                	je     0x27a6
    27a3:	e9 97 fd             	jmp    0x253d
    27a6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    27aa:	83 c4 06             	add    sp,0x6
    27ad:	b8 b3 27             	mov    ax,0x27b3
    27b0:	0e                   	push   cs
    27b1:	50                   	push   ax
    27b2:	cb                   	retf
    27b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27b6:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    27bb:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    27bf:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    27c3:	b8 a7 1e             	mov    ax,0x1ea7
    27c6:	0e                   	push   cs
    27c7:	50                   	push   ax
    27c8:	55                   	push   bp
    27c9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    27cd:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    27d1:	a1 4e 01             	mov    ax,ds:0x14e
    27d4:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    27d8:	b8 01 00             	mov    ax,0x1
    27db:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    27df:	7e 03                	jle    0x27e4
    27e1:	e9 43 01             	jmp    0x2927
    27e4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    27e7:	eb 03                	jmp    0x27ec
    27e9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    27ec:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    27ef:	2d 01 00             	sub    ax,0x1
    27f2:	71 05                	jno    0x27f9
    27f4:	9a 3e 04 60 28       	call   0x2860:0x43e
    27f9:	99                   	cwd
    27fa:	89 86 5e f1          	mov    WORD PTR [bp-0xea2],ax
    27fe:	89 96 60 f1          	mov    WORD PTR [bp-0xea0],dx
    2802:	c6 86 62 f1 00       	mov    BYTE PTR [bp-0xe9e],0x0
    2807:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    280a:	99                   	cwd
    280b:	89 86 66 f1          	mov    WORD PTR [bp-0xe9a],ax
    280f:	89 96 68 f1          	mov    WORD PTR [bp-0xe98],dx
    2813:	c6 86 6a f1 00       	mov    BYTE PTR [bp-0xe96],0x0
    2818:	8d be 5e f1          	lea    di,[bp-0xea2]
    281c:	16                   	push   ss
    281d:	57                   	push   di
    281e:	6a 01                	push   0x1
    2820:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2824:	06                   	push   es
    2825:	57                   	push   di
    2826:	9a 95 28 a1 28       	call   0x28a1:0x2895
    282b:	08 c0                	or     al,al
    282d:	75 0a                	jne    0x2839
    282f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2832:	06                   	push   es
    2833:	57                   	push   di
    2834:	9a 03 03 af 28       	call   0x28af:0x303
    2839:	bf 84 1e             	mov    di,0x1e84
    283c:	0e                   	push   cs
    283d:	57                   	push   di
    283e:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2842:	06                   	push   es
    2843:	57                   	push   di
    2844:	9a 9b 3b bf 28       	call   0x28bf:0x3b9b
    2849:	89 c7                	mov    di,ax
    284b:	8e c2                	mov    es,dx
    284d:	06                   	push   es
    284e:	57                   	push   di
    284f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2852:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2856:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2859:	99                   	cwd
    285a:	bf 7c 1e             	mov    di,0x1e7c
    285d:	9a 16 04 d8 28       	call   0x28d8:0x416
    2862:	8b f8                	mov    di,ax
    2864:	c1 e7 03             	shl    di,0x3
    2867:	9b dd 9b b2 f2       	fstp   QWORD PTR [bp+di-0xd4e]
    286c:	90                   	nop
    286d:	9b                   	fwait
    286e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2871:	99                   	cwd
    2872:	89 86 5e f1          	mov    WORD PTR [bp-0xea2],ax
    2876:	89 96 60 f1          	mov    WORD PTR [bp-0xea0],dx
    287a:	c6 86 62 f1 00       	mov    BYTE PTR [bp-0xe9e],0x0
    287f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2882:	99                   	cwd
    2883:	89 86 66 f1          	mov    WORD PTR [bp-0xe9a],ax
    2887:	89 96 68 f1          	mov    WORD PTR [bp-0xe98],dx
    288b:	c6 86 6a f1 00       	mov    BYTE PTR [bp-0xe96],0x0
    2890:	8d be 5e f1          	lea    di,[bp-0xea2]
    2894:	16                   	push   ss
    2895:	57                   	push   di
    2896:	6a 01                	push   0x1
    2898:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    289c:	06                   	push   es
    289d:	57                   	push   di
    289e:	9a 95 28 bb 29       	call   0x29bb:0x2895
    28a3:	08 c0                	or     al,al
    28a5:	75 0a                	jne    0x28b1
    28a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28aa:	06                   	push   es
    28ab:	57                   	push   di
    28ac:	9a 03 03 c9 29       	call   0x29c9:0x303
    28b1:	bf 93 1e             	mov    di,0x1e93
    28b4:	0e                   	push   cs
    28b5:	57                   	push   di
    28b6:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    28ba:	06                   	push   es
    28bb:	57                   	push   di
    28bc:	9a 9b 3b f4 28       	call   0x28f4:0x3b9b
    28c1:	89 c7                	mov    di,ax
    28c3:	8e c2                	mov    es,dx
    28c5:	06                   	push   es
    28c6:	57                   	push   di
    28c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28ca:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    28ce:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    28d1:	99                   	cwd
    28d2:	bf 7c 1e             	mov    di,0x1e7c
    28d5:	9a 16 04 0d 29       	call   0x290d:0x416
    28da:	8b f8                	mov    di,ax
    28dc:	c1 e7 03             	shl    di,0x3
    28df:	9b dd 9b f2 f2       	fstp   QWORD PTR [bp+di-0xd0e]
    28e4:	90                   	nop
    28e5:	9b                   	fwait
    28e6:	bf 84 1e             	mov    di,0x1e84
    28e9:	0e                   	push   cs
    28ea:	57                   	push   di
    28eb:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    28ef:	06                   	push   es
    28f0:	57                   	push   di
    28f1:	9a 9b 3b d9 29       	call   0x29d9:0x3b9b
    28f6:	89 c7                	mov    di,ax
    28f8:	8e c2                	mov    es,dx
    28fa:	06                   	push   es
    28fb:	57                   	push   di
    28fc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28ff:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2903:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2906:	99                   	cwd
    2907:	bf 7c 1e             	mov    di,0x1e7c
    290a:	9a 16 04 f2 29       	call   0x29f2:0x416
    290f:	8b f8                	mov    di,ax
    2911:	c1 e7 03             	shl    di,0x3
    2914:	9b dd 9b 72 f2       	fstp   QWORD PTR [bp+di-0xd8e]
    2919:	90                   	nop
    291a:	9b                   	fwait
    291b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    291e:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    2922:	74 03                	je     0x2927
    2924:	e9 c2 fe             	jmp    0x27e9
    2927:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    292b:	83 c4 06             	add    sp,0x6
    292e:	b8 34 29             	mov    ax,0x2934
    2931:	0e                   	push   cs
    2932:	50                   	push   ax
    2933:	cb                   	retf
    2934:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2937:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    293c:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    2940:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    2944:	b8 2f 1f             	mov    ax,0x1f2f
    2947:	0e                   	push   cs
    2948:	50                   	push   ax
    2949:	55                   	push   bp
    294a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    294e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2952:	a1 4e 01             	mov    ax,ds:0x14e
    2955:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    2959:	b8 01 00             	mov    ax,0x1
    295c:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    2960:	7e 03                	jle    0x2965
    2962:	e9 e2 02             	jmp    0x2c47
    2965:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2968:	eb 03                	jmp    0x296d
    296a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    296d:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    2972:	eb 03                	jmp    0x2977
    2974:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2977:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    297a:	99                   	cwd
    297b:	89 86 56 f1          	mov    WORD PTR [bp-0xeaa],ax
    297f:	89 96 58 f1          	mov    WORD PTR [bp-0xea8],dx
    2983:	c6 86 5a f1 00       	mov    BYTE PTR [bp-0xea6],0x0
    2988:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    298b:	99                   	cwd
    298c:	89 86 5e f1          	mov    WORD PTR [bp-0xea2],ax
    2990:	89 96 60 f1          	mov    WORD PTR [bp-0xea0],dx
    2994:	c6 86 62 f1 00       	mov    BYTE PTR [bp-0xe9e],0x0
    2999:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    299c:	99                   	cwd
    299d:	89 86 66 f1          	mov    WORD PTR [bp-0xe9a],ax
    29a1:	89 96 68 f1          	mov    WORD PTR [bp-0xe98],dx
    29a5:	c6 86 6a f1 00       	mov    BYTE PTR [bp-0xe96],0x0
    29aa:	8d be 56 f1          	lea    di,[bp-0xeaa]
    29ae:	16                   	push   ss
    29af:	57                   	push   di
    29b0:	6a 02                	push   0x2
    29b2:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    29b6:	06                   	push   es
    29b7:	57                   	push   di
    29b8:	9a 95 28 e5 2c       	call   0x2ce5:0x2895
    29bd:	08 c0                	or     al,al
    29bf:	75 0a                	jne    0x29cb
    29c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c4:	06                   	push   es
    29c5:	57                   	push   di
    29c6:	9a 03 03 f3 2c       	call   0x2cf3:0x303
    29cb:	bf bd 1e             	mov    di,0x1ebd
    29ce:	0e                   	push   cs
    29cf:	57                   	push   di
    29d0:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    29d4:	06                   	push   es
    29d5:	57                   	push   di
    29d6:	9a 9b 3b 21 2a       	call   0x2a21:0x3b9b
    29db:	89 c7                	mov    di,ax
    29dd:	8e c2                	mov    es,dx
    29df:	06                   	push   es
    29e0:	57                   	push   di
    29e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29e4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    29e8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    29eb:	99                   	cwd
    29ec:	bf b5 1e             	mov    di,0x1eb5
    29ef:	9a 16 04 03 2a       	call   0x2a03:0x416
    29f4:	c1 e0 03             	shl    ax,0x3
    29f7:	8b c8                	mov    cx,ax
    29f9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    29fc:	99                   	cwd
    29fd:	bf ad 1e             	mov    di,0x1ead
    2a00:	9a 16 04 3a 2a       	call   0x2a3a:0x416
    2a05:	8b f8                	mov    di,ax
    2a07:	c1 e7 04             	shl    di,0x4
    2a0a:	03 f9                	add    di,cx
    2a0c:	9b dd 9b 10 f5       	fstp   QWORD PTR [bp+di-0xaf0]
    2a11:	90                   	nop
    2a12:	9b                   	fwait
    2a13:	bf c2 1e             	mov    di,0x1ec2
    2a16:	0e                   	push   cs
    2a17:	57                   	push   di
    2a18:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2a1c:	06                   	push   es
    2a1d:	57                   	push   di
    2a1e:	9a 9b 3b 69 2a       	call   0x2a69:0x3b9b
    2a23:	89 c7                	mov    di,ax
    2a25:	8e c2                	mov    es,dx
    2a27:	06                   	push   es
    2a28:	57                   	push   di
    2a29:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a2c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2a30:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2a33:	99                   	cwd
    2a34:	bf b5 1e             	mov    di,0x1eb5
    2a37:	9a 16 04 4b 2a       	call   0x2a4b:0x416
    2a3c:	c1 e0 03             	shl    ax,0x3
    2a3f:	8b c8                	mov    cx,ax
    2a41:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a44:	99                   	cwd
    2a45:	bf ad 1e             	mov    di,0x1ead
    2a48:	9a 16 04 82 2a       	call   0x2a82:0x416
    2a4d:	8b f8                	mov    di,ax
    2a4f:	c1 e7 04             	shl    di,0x4
    2a52:	03 f9                	add    di,cx
    2a54:	9b dd 9b 90 f4       	fstp   QWORD PTR [bp+di-0xb70]
    2a59:	90                   	nop
    2a5a:	9b                   	fwait
    2a5b:	bf cc 1e             	mov    di,0x1ecc
    2a5e:	0e                   	push   cs
    2a5f:	57                   	push   di
    2a60:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2a64:	06                   	push   es
    2a65:	57                   	push   di
    2a66:	9a 9b 3b b1 2a       	call   0x2ab1:0x3b9b
    2a6b:	89 c7                	mov    di,ax
    2a6d:	8e c2                	mov    es,dx
    2a6f:	06                   	push   es
    2a70:	57                   	push   di
    2a71:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a74:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2a78:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2a7b:	99                   	cwd
    2a7c:	bf b5 1e             	mov    di,0x1eb5
    2a7f:	9a 16 04 93 2a       	call   0x2a93:0x416
    2a84:	c1 e0 03             	shl    ax,0x3
    2a87:	8b c8                	mov    cx,ax
    2a89:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a8c:	99                   	cwd
    2a8d:	bf ad 1e             	mov    di,0x1ead
    2a90:	9a 16 04 cc 2a       	call   0x2acc:0x416
    2a95:	8b f8                	mov    di,ax
    2a97:	c1 e7 04             	shl    di,0x4
    2a9a:	03 f9                	add    di,cx
    2a9c:	9b dd 9b 10 f4       	fstp   QWORD PTR [bp+di-0xbf0]
    2aa1:	90                   	nop
    2aa2:	9b                   	fwait
    2aa3:	bf dc 1e             	mov    di,0x1edc
    2aa6:	0e                   	push   cs
    2aa7:	57                   	push   di
    2aa8:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2aac:	06                   	push   es
    2aad:	57                   	push   di
    2aae:	9a 9b 3b fe 2a       	call   0x2afe:0x3b9b
    2ab3:	89 c7                	mov    di,ax
    2ab5:	8e c2                	mov    es,dx
    2ab7:	06                   	push   es
    2ab8:	57                   	push   di
    2ab9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2abc:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2ac0:	52                   	push   dx
    2ac1:	50                   	push   ax
    2ac2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2ac5:	99                   	cwd
    2ac6:	bf b5 1e             	mov    di,0x1eb5
    2ac9:	9a 16 04 dd 2a       	call   0x2add:0x416
    2ace:	c1 e0 02             	shl    ax,0x2
    2ad1:	8b c8                	mov    cx,ax
    2ad3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ad6:	99                   	cwd
    2ad7:	bf ad 1e             	mov    di,0x1ead
    2ada:	9a 16 04 19 2b       	call   0x2b19:0x416
    2adf:	8b f8                	mov    di,ax
    2ae1:	c1 e7 03             	shl    di,0x3
    2ae4:	03 f9                	add    di,cx
    2ae6:	58                   	pop    ax
    2ae7:	5a                   	pop    dx
    2ae8:	89 83 e8 f9          	mov    WORD PTR [bp+di-0x618],ax
    2aec:	89 93 ea f9          	mov    WORD PTR [bp+di-0x616],dx
    2af0:	bf ed 1e             	mov    di,0x1eed
    2af3:	0e                   	push   cs
    2af4:	57                   	push   di
    2af5:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2af9:	06                   	push   es
    2afa:	57                   	push   di
    2afb:	9a 9b 3b 4b 2b       	call   0x2b4b:0x3b9b
    2b00:	89 c7                	mov    di,ax
    2b02:	8e c2                	mov    es,dx
    2b04:	06                   	push   es
    2b05:	57                   	push   di
    2b06:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b09:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2b0d:	52                   	push   dx
    2b0e:	50                   	push   ax
    2b0f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2b12:	99                   	cwd
    2b13:	bf b5 1e             	mov    di,0x1eb5
    2b16:	9a 16 04 2a 2b       	call   0x2b2a:0x416
    2b1b:	c1 e0 02             	shl    ax,0x2
    2b1e:	8b c8                	mov    cx,ax
    2b20:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2b23:	99                   	cwd
    2b24:	bf ad 1e             	mov    di,0x1ead
    2b27:	9a 16 04 8b 2b       	call   0x2b8b:0x416
    2b2c:	8b f8                	mov    di,ax
    2b2e:	c1 e7 03             	shl    di,0x3
    2b31:	03 f9                	add    di,cx
    2b33:	58                   	pop    ax
    2b34:	5a                   	pop    dx
    2b35:	89 83 a8 f9          	mov    WORD PTR [bp+di-0x658],ax
    2b39:	89 93 aa f9          	mov    WORD PTR [bp+di-0x656],dx
    2b3d:	bf ff 1e             	mov    di,0x1eff
    2b40:	0e                   	push   cs
    2b41:	57                   	push   di
    2b42:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2b46:	06                   	push   es
    2b47:	57                   	push   di
    2b48:	9a 9b 3b 70 2b       	call   0x2b70:0x3b9b
    2b4d:	89 c7                	mov    di,ax
    2b4f:	8e c2                	mov    es,dx
    2b51:	06                   	push   es
    2b52:	57                   	push   di
    2b53:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b56:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2b5a:	89 86 78 fb          	mov    WORD PTR [bp-0x488],ax
    2b5e:	89 96 7a fb          	mov    WORD PTR [bp-0x486],dx
    2b62:	bf 0a 1f             	mov    di,0x1f0a
    2b65:	0e                   	push   cs
    2b66:	57                   	push   di
    2b67:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2b6b:	06                   	push   es
    2b6c:	57                   	push   di
    2b6d:	9a 9b 3b bd 2b       	call   0x2bbd:0x3b9b
    2b72:	89 c7                	mov    di,ax
    2b74:	8e c2                	mov    es,dx
    2b76:	06                   	push   es
    2b77:	57                   	push   di
    2b78:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b7b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2b7f:	52                   	push   dx
    2b80:	50                   	push   ax
    2b81:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2b84:	99                   	cwd
    2b85:	bf b5 1e             	mov    di,0x1eb5
    2b88:	9a 16 04 9c 2b       	call   0x2b9c:0x416
    2b8d:	c1 e0 02             	shl    ax,0x2
    2b90:	8b c8                	mov    cx,ax
    2b92:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2b95:	99                   	cwd
    2b96:	bf ad 1e             	mov    di,0x1ead
    2b99:	9a 16 04 d8 2b       	call   0x2bd8:0x416
    2b9e:	8b f8                	mov    di,ax
    2ba0:	c1 e7 03             	shl    di,0x3
    2ba3:	03 f9                	add    di,cx
    2ba5:	58                   	pop    ax
    2ba6:	5a                   	pop    dx
    2ba7:	89 83 ec fa          	mov    WORD PTR [bp+di-0x514],ax
    2bab:	89 93 ee fa          	mov    WORD PTR [bp+di-0x512],dx
    2baf:	bf 1c 1f             	mov    di,0x1f1c
    2bb2:	0e                   	push   cs
    2bb3:	57                   	push   di
    2bb4:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2bb8:	06                   	push   es
    2bb9:	57                   	push   di
    2bba:	9a 9b 3b 03 2d       	call   0x2d03:0x3b9b
    2bbf:	89 c7                	mov    di,ax
    2bc1:	8e c2                	mov    es,dx
    2bc3:	06                   	push   es
    2bc4:	57                   	push   di
    2bc5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bc8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2bcc:	52                   	push   dx
    2bcd:	50                   	push   ax
    2bce:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2bd1:	99                   	cwd
    2bd2:	bf b5 1e             	mov    di,0x1eb5
    2bd5:	9a 16 04 e9 2b       	call   0x2be9:0x416
    2bda:	c1 e0 02             	shl    ax,0x2
    2bdd:	8b c8                	mov    cx,ax
    2bdf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2be2:	99                   	cwd
    2be3:	bf ad 1e             	mov    di,0x1ead
    2be6:	9a 16 04 0e 2c       	call   0x2c0e:0x416
    2beb:	8b f8                	mov    di,ax
    2bed:	c1 e7 03             	shl    di,0x3
    2bf0:	03 f9                	add    di,cx
    2bf2:	58                   	pop    ax
    2bf3:	5a                   	pop    dx
    2bf4:	89 83 ac fa          	mov    WORD PTR [bp+di-0x554],ax
    2bf8:	89 93 ae fa          	mov    WORD PTR [bp+di-0x552],dx
    2bfc:	ff b6 7a fb          	push   WORD PTR [bp-0x486]
    2c00:	ff b6 78 fb          	push   WORD PTR [bp-0x488]
    2c04:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2c07:	99                   	cwd
    2c08:	bf b5 1e             	mov    di,0x1eb5
    2c0b:	9a 16 04 1f 2c       	call   0x2c1f:0x416
    2c10:	c1 e0 02             	shl    ax,0x2
    2c13:	8b c8                	mov    cx,ax
    2c15:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2c18:	99                   	cwd
    2c19:	bf ad 1e             	mov    di,0x1ead
    2c1c:	9a 16 04 a2 2c       	call   0x2ca2:0x416
    2c21:	8b f8                	mov    di,ax
    2c23:	c1 e7 03             	shl    di,0x3
    2c26:	03 f9                	add    di,cx
    2c28:	58                   	pop    ax
    2c29:	5a                   	pop    dx
    2c2a:	89 83 2c fb          	mov    WORD PTR [bp+di-0x4d4],ax
    2c2e:	89 93 2e fb          	mov    WORD PTR [bp+di-0x4d2],dx
    2c32:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    2c36:	74 03                	je     0x2c3b
    2c38:	e9 39 fd             	jmp    0x2974
    2c3b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2c3e:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    2c42:	74 03                	je     0x2c47
    2c44:	e9 23 fd             	jmp    0x296a
    2c47:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2c4b:	83 c4 06             	add    sp,0x6
    2c4e:	b8 54 2c             	mov    ax,0x2c54
    2c51:	0e                   	push   cs
    2c52:	50                   	push   ax
    2c53:	cb                   	retf
    2c54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c57:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    2c5c:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    2c60:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    2c64:	b8 70 1f             	mov    ax,0x1f70
    2c67:	0e                   	push   cs
    2c68:	50                   	push   ax
    2c69:	55                   	push   bp
    2c6a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2c6e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2c72:	a1 4e 01             	mov    ax,ds:0x14e
    2c75:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    2c79:	b8 01 00             	mov    ax,0x1
    2c7c:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    2c80:	7e 03                	jle    0x2c85
    2c82:	e9 62 01             	jmp    0x2de7
    2c85:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2c88:	eb 03                	jmp    0x2c8d
    2c8a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2c8d:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    2c92:	eb 03                	jmp    0x2c97
    2c94:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2c97:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2c9a:	2d 01 00             	sub    ax,0x1
    2c9d:	71 05                	jno    0x2ca4
    2c9f:	9a 3e 04 1e 2d       	call   0x2d1e:0x43e
    2ca4:	99                   	cwd
    2ca5:	89 86 56 f1          	mov    WORD PTR [bp-0xeaa],ax
    2ca9:	89 96 58 f1          	mov    WORD PTR [bp-0xea8],dx
    2cad:	c6 86 5a f1 00       	mov    BYTE PTR [bp-0xea6],0x0
    2cb2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2cb5:	99                   	cwd
    2cb6:	89 86 5e f1          	mov    WORD PTR [bp-0xea2],ax
    2cba:	89 96 60 f1          	mov    WORD PTR [bp-0xea0],dx
    2cbe:	c6 86 62 f1 00       	mov    BYTE PTR [bp-0xe9e],0x0
    2cc3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2cc6:	99                   	cwd
    2cc7:	89 86 66 f1          	mov    WORD PTR [bp-0xe9a],ax
    2ccb:	89 96 68 f1          	mov    WORD PTR [bp-0xe98],dx
    2ccf:	c6 86 6a f1 00       	mov    BYTE PTR [bp-0xe96],0x0
    2cd4:	8d be 56 f1          	lea    di,[bp-0xeaa]
    2cd8:	16                   	push   ss
    2cd9:	57                   	push   di
    2cda:	6a 02                	push   0x2
    2cdc:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2ce0:	06                   	push   es
    2ce1:	57                   	push   di
    2ce2:	9a 95 28 0f 3f       	call   0x3f0f:0x2895
    2ce7:	08 c0                	or     al,al
    2ce9:	75 0a                	jne    0x2cf5
    2ceb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cee:	06                   	push   es
    2cef:	57                   	push   di
    2cf0:	9a 03 03 c7 2e       	call   0x2ec7:0x303
    2cf5:	bf 45 1f             	mov    di,0x1f45
    2cf8:	0e                   	push   cs
    2cf9:	57                   	push   di
    2cfa:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2cfe:	06                   	push   es
    2cff:	57                   	push   di
    2d00:	9a 9b 3b 50 2d       	call   0x2d50:0x3b9b
    2d05:	89 c7                	mov    di,ax
    2d07:	8e c2                	mov    es,dx
    2d09:	06                   	push   es
    2d0a:	57                   	push   di
    2d0b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d0e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2d12:	52                   	push   dx
    2d13:	50                   	push   ax
    2d14:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d17:	99                   	cwd
    2d18:	bf 3d 1f             	mov    di,0x1f3d
    2d1b:	9a 16 04 2f 2d       	call   0x2d2f:0x416
    2d20:	c1 e0 02             	shl    ax,0x2
    2d23:	8b c8                	mov    cx,ax
    2d25:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d28:	99                   	cwd
    2d29:	bf 35 1f             	mov    di,0x1f35
    2d2c:	9a 16 04 69 2d       	call   0x2d69:0x416
    2d31:	8b f8                	mov    di,ax
    2d33:	c1 e7 03             	shl    di,0x3
    2d36:	03 f9                	add    di,cx
    2d38:	58                   	pop    ax
    2d39:	5a                   	pop    dx
    2d3a:	89 83 f0 fb          	mov    WORD PTR [bp+di-0x410],ax
    2d3e:	89 93 f2 fb          	mov    WORD PTR [bp+di-0x40e],dx
    2d42:	bf 4e 1f             	mov    di,0x1f4e
    2d45:	0e                   	push   cs
    2d46:	57                   	push   di
    2d47:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2d4b:	06                   	push   es
    2d4c:	57                   	push   di
    2d4d:	9a 9b 3b 98 2d       	call   0x2d98:0x3b9b
    2d52:	89 c7                	mov    di,ax
    2d54:	8e c2                	mov    es,dx
    2d56:	06                   	push   es
    2d57:	57                   	push   di
    2d58:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d5b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2d5f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d62:	99                   	cwd
    2d63:	bf 3d 1f             	mov    di,0x1f3d
    2d66:	9a 16 04 7a 2d       	call   0x2d7a:0x416
    2d6b:	c1 e0 03             	shl    ax,0x3
    2d6e:	8b c8                	mov    cx,ax
    2d70:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d73:	99                   	cwd
    2d74:	bf 35 1f             	mov    di,0x1f35
    2d77:	9a 16 04 b1 2d       	call   0x2db1:0x416
    2d7c:	8b f8                	mov    di,ax
    2d7e:	c1 e7 04             	shl    di,0x4
    2d81:	03 f9                	add    di,cx
    2d83:	9b dd 9b 5c fc       	fstp   QWORD PTR [bp+di-0x3a4]
    2d88:	90                   	nop
    2d89:	9b                   	fwait
    2d8a:	bf 5a 1f             	mov    di,0x1f5a
    2d8d:	0e                   	push   cs
    2d8e:	57                   	push   di
    2d8f:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    2d93:	06                   	push   es
    2d94:	57                   	push   di
    2d95:	9a 9b 3b 2d 3f       	call   0x3f2d:0x3b9b
    2d9a:	89 c7                	mov    di,ax
    2d9c:	8e c2                	mov    es,dx
    2d9e:	06                   	push   es
    2d9f:	57                   	push   di
    2da0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2da3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2da7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2daa:	99                   	cwd
    2dab:	bf 3d 1f             	mov    di,0x1f3d
    2dae:	9a 16 04 c2 2d       	call   0x2dc2:0x416
    2db3:	c1 e0 03             	shl    ax,0x3
    2db6:	8b c8                	mov    cx,ax
    2db8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2dbb:	99                   	cwd
    2dbc:	bf 35 1f             	mov    di,0x1f35
    2dbf:	9a 16 04 28 2e       	call   0x2e28:0x416
    2dc4:	8b f8                	mov    di,ax
    2dc6:	c1 e7 04             	shl    di,0x4
    2dc9:	03 f9                	add    di,cx
    2dcb:	9b dd 9b 64 fb       	fstp   QWORD PTR [bp+di-0x49c]
    2dd0:	90                   	nop
    2dd1:	9b                   	fwait
    2dd2:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    2dd6:	74 03                	je     0x2ddb
    2dd8:	e9 b9 fe             	jmp    0x2c94
    2ddb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2dde:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    2de2:	74 03                	je     0x2de7
    2de4:	e9 a3 fe             	jmp    0x2c8a
    2de7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2deb:	83 c4 06             	add    sp,0x6
    2dee:	b8 f4 2d             	mov    ax,0x2df4
    2df1:	0e                   	push   cs
    2df2:	50                   	push   ax
    2df3:	cb                   	retf
    2df4:	9b 2e d9 06 76 1f    	fld    DWORD PTR cs:0x1f76
    2dfa:	9b dd 9e 6a f2       	fstp   QWORD PTR [bp-0xd96]
    2dff:	90                   	nop
    2e00:	9b                   	fwait
    2e01:	a1 4e 01             	mov    ax,ds:0x14e
    2e04:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    2e08:	b8 01 00             	mov    ax,0x1
    2e0b:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    2e0f:	7f 33                	jg     0x2e44
    2e11:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e14:	eb 03                	jmp    0x2e19
    2e16:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2e19:	9b dd 86 6a f2       	fld    QWORD PTR [bp-0xd96]
    2e1e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e21:	99                   	cwd
    2e22:	bf 7a 1f             	mov    di,0x1f7a
    2e25:	9a 16 04 51 2e       	call   0x2e51:0x416
    2e2a:	8b f8                	mov    di,ax
    2e2c:	c1 e7 03             	shl    di,0x3
    2e2f:	9b dc 83 72 f2       	fadd   QWORD PTR [bp+di-0xd8e]
    2e34:	9b dd 9e 6a f2       	fstp   QWORD PTR [bp-0xd96]
    2e39:	90                   	nop
    2e3a:	9b                   	fwait
    2e3b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e3e:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    2e42:	75 d2                	jne    0x2e16
    2e44:	9b df 06 4e 01       	fild   WORD PTR ds:0x14e
    2e49:	9b dd 86 6a f2       	fld    QWORD PTR [bp-0xd96]
    2e4e:	9a af 04 89 2e       	call   0x2e89:0x4af
    2e53:	9b dd 9e 6a f2       	fstp   QWORD PTR [bp-0xd96]
    2e58:	90                   	nop
    2e59:	9b                   	fwait
    2e5a:	31 c0                	xor    ax,ax
    2e5c:	89 86 d4 f1          	mov    WORD PTR [bp-0xe2c],ax
    2e60:	a1 4e 01             	mov    ax,ds:0x14e
    2e63:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    2e67:	b8 01 00             	mov    ax,0x1
    2e6a:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    2e6e:	7f 2e                	jg     0x2e9e
    2e70:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e73:	eb 03                	jmp    0x2e78
    2e75:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2e78:	83 be d4 f1 00       	cmp    WORD PTR [bp-0xe2c],0x0
    2e7d:	75 16                	jne    0x2e95
    2e7f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e82:	99                   	cwd
    2e83:	bf 7a 1f             	mov    di,0x1f7a
    2e86:	9a 16 04 d3 2e       	call   0x2ed3:0x416
    2e8b:	8b f8                	mov    di,ax
    2e8d:	d1 e7                	shl    di,1
    2e8f:	31 c0                	xor    ax,ax
    2e91:	89 83 be f1          	mov    WORD PTR [bp+di-0xe42],ax
    2e95:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e98:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    2e9c:	75 d7                	jne    0x2e75
    2e9e:	a1 4e 01             	mov    ax,ds:0x14e
    2ea1:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    2ea5:	b8 01 00             	mov    ax,0x1
    2ea8:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    2eac:	7e 03                	jle    0x2eb1
    2eae:	e9 ca 03             	jmp    0x327b
    2eb1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2eb4:	eb 03                	jmp    0x2eb9
    2eb6:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2eb9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ebc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ebf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec2:	06                   	push   es
    2ec3:	57                   	push   di
    2ec4:	9a 1c 19 32 37       	call   0x3732:0x191c
    2ec9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ecc:	99                   	cwd
    2ecd:	bf 7a 1f             	mov    di,0x1f7a
    2ed0:	9a 16 04 eb 2e       	call   0x2eeb:0x416
    2ed5:	8b f8                	mov    di,ax
    2ed7:	c1 e7 03             	shl    di,0x3
    2eda:	9b dd 9b 32 f3       	fstp   QWORD PTR [bp+di-0xcce]
    2edf:	90                   	nop
    2ee0:	9b                   	fwait
    2ee1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ee4:	99                   	cwd
    2ee5:	bf 7a 1f             	mov    di,0x1f7a
    2ee8:	9a 16 04 04 2f       	call   0x2f04:0x416
    2eed:	8b f8                	mov    di,ax
    2eef:	c1 e7 03             	shl    di,0x3
    2ef2:	8b 8b f4 fa          	mov    cx,WORD PTR [bp+di-0x50c]
    2ef6:	8b 9b f6 fa          	mov    bx,WORD PTR [bp+di-0x50a]
    2efa:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2efd:	99                   	cwd
    2efe:	bf 7a 1f             	mov    di,0x1f7a
    2f01:	9a 16 04 1c 2f       	call   0x2f1c:0x416
    2f06:	8b f8                	mov    di,ax
    2f08:	c1 e7 03             	shl    di,0x3
    2f0b:	8b 83 f0 fa          	mov    ax,WORD PTR [bp+di-0x510]
    2f0f:	8b 93 f2 fa          	mov    dx,WORD PTR [bp+di-0x50e]
    2f13:	03 c1                	add    ax,cx
    2f15:	13 d3                	adc    dx,bx
    2f17:	71 05                	jno    0x2f1e
    2f19:	9a 3e 04 30 2f       	call   0x2f30:0x43e
    2f1e:	89 86 9c f1          	mov    WORD PTR [bp-0xe64],ax
    2f22:	89 96 9e f1          	mov    WORD PTR [bp-0xe62],dx
    2f26:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f29:	99                   	cwd
    2f2a:	bf 7a 1f             	mov    di,0x1f7a
    2f2d:	9a 16 04 46 2f       	call   0x2f46:0x416
    2f32:	8b f8                	mov    di,ax
    2f34:	d1 e7                	shl    di,1
    2f36:	8b 83 be f1          	mov    ax,WORD PTR [bp+di-0xe42]
    2f3a:	99                   	cwd
    2f3b:	8b 8e 9c f1          	mov    cx,WORD PTR [bp-0xe64]
    2f3f:	8b 9e 9e f1          	mov    bx,WORD PTR [bp-0xe62]
    2f43:	9a 5c 17 58 2f       	call   0x2f58:0x175c
    2f48:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    2f4c:	89 96 70 f1          	mov    WORD PTR [bp-0xe90],dx
    2f50:	9b db 86 6e f1       	fild   DWORD PTR [bp-0xe92]
    2f55:	9a 0e 10 68 2f       	call   0x2f68:0x100e
    2f5a:	8b c8                	mov    cx,ax
    2f5c:	8b da                	mov    bx,dx
    2f5e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f61:	99                   	cwd
    2f62:	bf 7a 1f             	mov    di,0x1f7a
    2f65:	9a 16 04 86 2f       	call   0x2f86:0x416
    2f6a:	8b f8                	mov    di,ax
    2f6c:	c1 e7 02             	shl    di,0x2
    2f6f:	89 8b 9c f1          	mov    WORD PTR [bp+di-0xe64],cx
    2f73:	89 9b 9e f1          	mov    WORD PTR [bp+di-0xe62],bx
    2f77:	9b db 86 fe f3       	fild   DWORD PTR [bp-0xc02]
    2f7c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f7f:	99                   	cwd
    2f80:	bf 7a 1f             	mov    di,0x1f7a
    2f83:	9a 16 04 a4 2f       	call   0x2fa4:0x416
    2f88:	8b f8                	mov    di,ax
    2f8a:	c1 e7 03             	shl    di,0x3
    2f8d:	9b dd 83 32 f3       	fld    QWORD PTR [bp+di-0xcce]
    2f92:	9b d9 c0             	fld    st(0)
    2f95:	9b de c9             	fmulp  st(1),st
    2f98:	9b de c9             	fmulp  st(1),st
    2f9b:	9b 2e d9 06 82 1f    	fld    DWORD PTR cs:0x1f82
    2fa1:	9a b2 04 c1 2f       	call   0x2fc1:0x4b2
    2fa6:	83 ec 08             	sub    sp,0x8
    2fa9:	89 e3                	mov    bx,sp
    2fab:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2faf:	90                   	nop
    2fb0:	9b                   	fwait
    2fb1:	9b 2e d9 06 86 1f    	fld    DWORD PTR cs:0x1f86
    2fb7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2fba:	99                   	cwd
    2fbb:	bf 7a 1f             	mov    di,0x1f7a
    2fbe:	9a 16 04 d0 2f       	call   0x2fd0:0x416
    2fc3:	8b f8                	mov    di,ax
    2fc5:	c1 e7 03             	shl    di,0x3
    2fc8:	9b dc 83 f2 f2       	fadd   QWORD PTR [bp+di-0xd0e]
    2fcd:	9a 73 10 ec 2f       	call   0x2fec:0x1073
    2fd2:	83 ec 08             	sub    sp,0x8
    2fd5:	89 e3                	mov    bx,sp
    2fd7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2fdb:	90                   	nop
    2fdc:	9b                   	fwait
    2fdd:	9a a7 2e 76 30       	call   0x3076:0x2ea7
    2fe2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2fe5:	99                   	cwd
    2fe6:	bf 7a 1f             	mov    di,0x1f7a
    2fe9:	9a 16 04 04 30       	call   0x3004:0x416
    2fee:	8b f8                	mov    di,ax
    2ff0:	c1 e7 03             	shl    di,0x3
    2ff3:	9b dd 9b b2 f3       	fstp   QWORD PTR [bp+di-0xc4e]
    2ff8:	90                   	nop
    2ff9:	9b                   	fwait
    2ffa:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ffd:	99                   	cwd
    2ffe:	bf 7a 1f             	mov    di,0x1f7a
    3001:	9a 16 04 34 30       	call   0x3034:0x416
    3006:	8b f8                	mov    di,ax
    3008:	c1 e7 03             	shl    di,0x3
    300b:	9b dd 83 b2 f3       	fld    QWORD PTR [bp+di-0xc4e]
    3010:	9b 2e d8 1e 8a 1f    	fcomp  DWORD PTR cs:0x1f8a
    3016:	9b dd be 70 f1       	fstsw  WORD PTR [bp-0xe90]
    301b:	90                   	nop
    301c:	9b                   	fwait
    301d:	8a a6 71 f1          	mov    ah,BYTE PTR [bp-0xe8f]
    3021:	9e                   	sahf
    3022:	76 1e                	jbe    0x3042
    3024:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    302a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    302d:	99                   	cwd
    302e:	bf 7a 1f             	mov    di,0x1f7a
    3031:	9a 16 04 5c 30       	call   0x305c:0x416
    3036:	8b f8                	mov    di,ax
    3038:	c1 e7 03             	shl    di,0x3
    303b:	9b dd 9b b2 f3       	fstp   QWORD PTR [bp+di-0xc4e]
    3040:	90                   	nop
    3041:	9b                   	fwait
    3042:	ff b6 70 f2          	push   WORD PTR [bp-0xd90]
    3046:	ff b6 6e f2          	push   WORD PTR [bp-0xd92]
    304a:	ff b6 6c f2          	push   WORD PTR [bp-0xd94]
    304e:	ff b6 6a f2          	push   WORD PTR [bp-0xd96]
    3052:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3055:	99                   	cwd
    3056:	bf 7a 1f             	mov    di,0x1f7a
    3059:	9a 16 04 fe 30       	call   0x30fe:0x416
    305e:	8b f8                	mov    di,ax
    3060:	c1 e7 03             	shl    di,0x3
    3063:	ff b3 78 f2          	push   WORD PTR [bp+di-0xd88]
    3067:	ff b3 76 f2          	push   WORD PTR [bp+di-0xd8a]
    306b:	ff b3 74 f2          	push   WORD PTR [bp+di-0xd8c]
    306f:	ff b3 72 f2          	push   WORD PTR [bp+di-0xd8e]
    3073:	9a a7 2e a8 30       	call   0x30a8:0x2ea7
    3078:	9b dd 9e 8c f1       	fstp   QWORD PTR [bp-0xe74]
    307d:	90                   	nop
    307e:	9b 9b dd 86 8c f1    	fld    QWORD PTR [bp-0xe74]
    3084:	9b 2e d8 26 86 1f    	fsub   DWORD PTR cs:0x1f86
    308a:	83 ec 08             	sub    sp,0x8
    308d:	89 e3                	mov    bx,sp
    308f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3093:	90                   	nop
    3094:	9b                   	fwait
    3095:	ff b6 92 f1          	push   WORD PTR [bp-0xe6e]
    3099:	ff b6 90 f1          	push   WORD PTR [bp-0xe70]
    309d:	ff b6 8e f1          	push   WORD PTR [bp-0xe72]
    30a1:	ff b6 8c f1          	push   WORD PTR [bp-0xe74]
    30a5:	9a a7 2e 62 31       	call   0x3162:0x2ea7
    30aa:	9b dd 9e 7c f1       	fstp   QWORD PTR [bp-0xe84]
    30af:	90                   	nop
    30b0:	9b 9b dd 86 7c f1    	fld    QWORD PTR [bp-0xe84]
    30b6:	9b 2e d8 1e 8e 1f    	fcomp  DWORD PTR cs:0x1f8e
    30bc:	9b dd be 70 f1       	fstsw  WORD PTR [bp-0xe90]
    30c1:	90                   	nop
    30c2:	9b                   	fwait
    30c3:	8a a6 71 f1          	mov    ah,BYTE PTR [bp-0xe8f]
    30c7:	9e                   	sahf
    30c8:	73 0d                	jae    0x30d7
    30ca:	9b 2e d9 06 8e 1f    	fld    DWORD PTR cs:0x1f8e
    30d0:	9b dd 9e 7c f1       	fstp   QWORD PTR [bp-0xe84]
    30d5:	90                   	nop
    30d6:	9b                   	fwait
    30d7:	68 5a 40             	push   0x405a
    30da:	68 00 90             	push   0x9000
    30dd:	6a 00                	push   0x0
    30df:	6a 00                	push   0x0
    30e1:	6a 11                	push   0x11
    30e3:	9a 69 0a 98 33       	call   0x3398:0xa69
    30e8:	99                   	cwd
    30e9:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    30ed:	89 96 70 f1          	mov    WORD PTR [bp-0xe90],dx
    30f1:	9b db 86 6e f1       	fild   DWORD PTR [bp-0xe92]
    30f6:	9b dc 8e 7c f1       	fmul   QWORD PTR [bp-0xe84]
    30fb:	9a 87 10 1b 31       	call   0x311b:0x1087
    3100:	9b dd 9e 7c f1       	fstp   QWORD PTR [bp-0xe84]
    3105:	90                   	nop
    3106:	9b                   	fwait
    3107:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    310d:	9b dc 86 62 f2       	fadd   QWORD PTR [bp-0xd9e]
    3112:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    3118:	9a b2 04 27 31       	call   0x3127:0x4b2
    311d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3120:	99                   	cwd
    3121:	bf 7a 1f             	mov    di,0x1f7a
    3124:	9a 16 04 48 31       	call   0x3148:0x416
    3129:	8b f8                	mov    di,ax
    312b:	c1 e7 03             	shl    di,0x3
    312e:	9b dc 8b b2 f2       	fmul   QWORD PTR [bp+di-0xd4e]
    3133:	83 ec 08             	sub    sp,0x8
    3136:	89 e3                	mov    bx,sp
    3138:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    313c:	90                   	nop
    313d:	9b                   	fwait
    313e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3141:	99                   	cwd
    3142:	bf 7a 1f             	mov    di,0x1f7a
    3145:	9a 16 04 f7 31       	call   0x31f7:0x416
    314a:	8b f8                	mov    di,ax
    314c:	c1 e7 03             	shl    di,0x3
    314f:	ff b3 78 f2          	push   WORD PTR [bp+di-0xd88]
    3153:	ff b3 76 f2          	push   WORD PTR [bp+di-0xd8a]
    3157:	ff b3 74 f2          	push   WORD PTR [bp+di-0xd8c]
    315b:	ff b3 72 f2          	push   WORD PTR [bp+di-0xd8e]
    315f:	9a a7 2e ba 31       	call   0x31ba:0x2ea7
    3164:	9b dd 9e 84 f1       	fstp   QWORD PTR [bp-0xe7c]
    3169:	90                   	nop
    316a:	9b 9b dd 86 84 f1    	fld    QWORD PTR [bp-0xe7c]
    3170:	9b 2e d8 1e 86 1f    	fcomp  DWORD PTR cs:0x1f86
    3176:	9b dd be 70 f1       	fstsw  WORD PTR [bp-0xe90]
    317b:	90                   	nop
    317c:	9b                   	fwait
    317d:	8a a6 71 f1          	mov    ah,BYTE PTR [bp-0xe8f]
    3181:	9e                   	sahf
    3182:	73 0d                	jae    0x3191
    3184:	9b 2e d9 06 86 1f    	fld    DWORD PTR cs:0x1f86
    318a:	9b dd 9e 84 f1       	fstp   QWORD PTR [bp-0xe7c]
    318f:	90                   	nop
    3190:	9b 9b dd 86 84 f1    	fld    QWORD PTR [bp-0xe7c]
    3196:	9b 2e d8 26 86 1f    	fsub   DWORD PTR cs:0x1f86
    319c:	83 ec 08             	sub    sp,0x8
    319f:	89 e3                	mov    bx,sp
    31a1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    31a5:	90                   	nop
    31a6:	9b                   	fwait
    31a7:	ff b6 8a f1          	push   WORD PTR [bp-0xe76]
    31ab:	ff b6 88 f1          	push   WORD PTR [bp-0xe78]
    31af:	ff b6 86 f1          	push   WORD PTR [bp-0xe7a]
    31b3:	ff b6 84 f1          	push   WORD PTR [bp-0xe7c]
    31b7:	9a a7 2e 19 33       	call   0x3319:0x2ea7
    31bc:	9b dd 9e 74 f1       	fstp   QWORD PTR [bp-0xe8c]
    31c1:	90                   	nop
    31c2:	9b 9b dd 86 74 f1    	fld    QWORD PTR [bp-0xe8c]
    31c8:	9b 2e d8 1e 8e 1f    	fcomp  DWORD PTR cs:0x1f8e
    31ce:	9b dd be 70 f1       	fstsw  WORD PTR [bp-0xe90]
    31d3:	90                   	nop
    31d4:	9b                   	fwait
    31d5:	8a a6 71 f1          	mov    ah,BYTE PTR [bp-0xe8f]
    31d9:	9e                   	sahf
    31da:	73 0d                	jae    0x31e9
    31dc:	9b 2e d9 06 8e 1f    	fld    DWORD PTR cs:0x1f8e
    31e2:	9b dd 9e 74 f1       	fstp   QWORD PTR [bp-0xe8c]
    31e7:	90                   	nop
    31e8:	9b 9b dd 86 74 f1    	fld    QWORD PTR [bp-0xe8c]
    31ee:	9b 2e d8 0e 92 1f    	fmul   DWORD PTR cs:0x1f92
    31f4:	9a 87 10 19 32       	call   0x3219:0x1087
    31f9:	9b dd 9e 74 f1       	fstp   QWORD PTR [bp-0xe8c]
    31fe:	90                   	nop
    31ff:	9b 9b db 86 fa f3    	fild   DWORD PTR [bp-0xc06]
    3205:	9b dc 8e 7c f1       	fmul   QWORD PTR [bp-0xe84]
    320a:	9b dc 8e 74 f1       	fmul   QWORD PTR [bp-0xe8c]
    320f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3212:	99                   	cwd
    3213:	bf 7a 1f             	mov    di,0x1f7a
    3216:	9a 16 04 31 32       	call   0x3231:0x416
    321b:	8b f8                	mov    di,ax
    321d:	c1 e7 03             	shl    di,0x3
    3220:	9b dd 9b 72 f3       	fstp   QWORD PTR [bp+di-0xc8e]
    3225:	90                   	nop
    3226:	9b                   	fwait
    3227:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    322a:	99                   	cwd
    322b:	bf 7a 1f             	mov    di,0x1f7a
    322e:	9a 16 04 61 32       	call   0x3261:0x416
    3233:	8b f8                	mov    di,ax
    3235:	c1 e7 03             	shl    di,0x3
    3238:	9b dd 83 72 f3       	fld    QWORD PTR [bp+di-0xc8e]
    323d:	9b 2e d8 1e 8a 1f    	fcomp  DWORD PTR cs:0x1f8a
    3243:	9b dd be 70 f1       	fstsw  WORD PTR [bp-0xe90]
    3248:	90                   	nop
    3249:	9b                   	fwait
    324a:	8a a6 71 f1          	mov    ah,BYTE PTR [bp-0xe8f]
    324e:	9e                   	sahf
    324f:	76 1e                	jbe    0x326f
    3251:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    3257:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    325a:	99                   	cwd
    325b:	bf 7a 1f             	mov    di,0x1f7a
    325e:	9a 16 04 aa 32       	call   0x32aa:0x416
    3263:	8b f8                	mov    di,ax
    3265:	c1 e7 03             	shl    di,0x3
    3268:	9b dd 9b 72 f3       	fstp   QWORD PTR [bp+di-0xc8e]
    326d:	90                   	nop
    326e:	9b                   	fwait
    326f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3272:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    3276:	74 03                	je     0x327b
    3278:	e9 3b fc             	jmp    0x2eb6
    327b:	a1 4e 01             	mov    ax,ds:0x14e
    327e:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    3282:	b8 01 00             	mov    ax,0x1
    3285:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    3289:	7e 03                	jle    0x328e
    328b:	e9 8c 04             	jmp    0x371a
    328e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3291:	eb 03                	jmp    0x3296
    3293:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3296:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    329b:	eb 03                	jmp    0x32a0
    329d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    32a0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    32a3:	99                   	cwd
    32a4:	bf 7a 1f             	mov    di,0x1f7a
    32a7:	9a 16 04 c3 32       	call   0x32c3:0x416
    32ac:	8b f8                	mov    di,ax
    32ae:	c1 e7 03             	shl    di,0x3
    32b1:	8b 8b f4 fa          	mov    cx,WORD PTR [bp+di-0x50c]
    32b5:	8b 9b f6 fa          	mov    bx,WORD PTR [bp+di-0x50a]
    32b9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    32bc:	99                   	cwd
    32bd:	bf 7a 1f             	mov    di,0x1f7a
    32c0:	9a 16 04 db 32       	call   0x32db:0x416
    32c5:	8b f8                	mov    di,ax
    32c7:	c1 e7 03             	shl    di,0x3
    32ca:	8b 83 f0 fa          	mov    ax,WORD PTR [bp+di-0x510]
    32ce:	8b 93 f2 fa          	mov    dx,WORD PTR [bp+di-0x50e]
    32d2:	03 c1                	add    ax,cx
    32d4:	13 d3                	adc    dx,bx
    32d6:	71 05                	jno    0x32dd
    32d8:	9a 3e 04 ef 32       	call   0x32ef:0x43e
    32dd:	89 86 9c f1          	mov    WORD PTR [bp-0xe64],ax
    32e1:	89 96 9e f1          	mov    WORD PTR [bp-0xe62],dx
    32e5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    32e8:	99                   	cwd
    32e9:	bf 7a 1f             	mov    di,0x1f7a
    32ec:	9a 16 04 35 33       	call   0x3335:0x416
    32f1:	8b f8                	mov    di,ax
    32f3:	c1 e7 02             	shl    di,0x2
    32f6:	9b db 83 9c f1       	fild   DWORD PTR [bp+di-0xe64]
    32fb:	83 ec 08             	sub    sp,0x8
    32fe:	89 e3                	mov    bx,sp
    3300:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3304:	90                   	nop
    3305:	9b 9b db 86 9c f1    	fild   DWORD PTR [bp-0xe64]
    330b:	83 ec 08             	sub    sp,0x8
    330e:	89 e3                	mov    bx,sp
    3310:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3314:	90                   	nop
    3315:	9b                   	fwait
    3316:	9a a7 2e 29 33       	call   0x3329:0x2ea7
    331b:	83 ec 08             	sub    sp,0x8
    331e:	89 e3                	mov    bx,sp
    3320:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3324:	90                   	nop
    3325:	9b                   	fwait
    3326:	9a a6 2f 37 34       	call   0x3437:0x2fa6
    332b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    332e:	99                   	cwd
    332f:	bf 7a 1f             	mov    di,0x1f7a
    3332:	9a 16 04 4b 33       	call   0x334b:0x416
    3337:	8b f8                	mov    di,ax
    3339:	c1 e7 03             	shl    di,0x3
    333c:	9b dd 83 b2 f3       	fld    QWORD PTR [bp+di-0xc4e]
    3341:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3344:	99                   	cwd
    3345:	bf 7a 1f             	mov    di,0x1f7a
    3348:	9a 16 04 a4 33       	call   0x33a4:0x416
    334d:	8b f8                	mov    di,ax
    334f:	c1 e7 03             	shl    di,0x3
    3352:	9b dc 83 72 f3       	fadd   QWORD PTR [bp+di-0xc8e]
    3357:	9b de c1             	faddp  st(1),st
    335a:	9b dd 9e 72 f2       	fstp   QWORD PTR [bp-0xd8e]
    335f:	90                   	nop
    3360:	9b 9b dd 86 72 f2    	fld    QWORD PTR [bp-0xd8e]
    3366:	9b 2e d8 1e 8a 1f    	fcomp  DWORD PTR cs:0x1f8a
    336c:	9b dd be 70 f1       	fstsw  WORD PTR [bp-0xe90]
    3371:	90                   	nop
    3372:	9b                   	fwait
    3373:	8a a6 71 f1          	mov    ah,BYTE PTR [bp-0xe8f]
    3377:	9e                   	sahf
    3378:	76 0d                	jbe    0x3387
    337a:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    3380:	9b dd 9e 72 f2       	fstp   QWORD PTR [bp-0xd8e]
    3385:	90                   	nop
    3386:	9b                   	fwait
    3387:	68 85 40             	push   0x4085
    338a:	68 8f 70             	push   0x708f
    338d:	68 28 5c             	push   0x5c28
    3390:	68 c3 f5             	push   0xf5c3
    3393:	6a 1b                	push   0x1b
    3395:	9a 69 0a 44 59       	call   0x5944:0xa69
    339a:	b9 04 00             	mov    cx,0x4
    339d:	f7 e9                	imul   cx
    339f:	71 05                	jno    0x33a6
    33a1:	9a 3e 04 be 33       	call   0x33be:0x43e
    33a6:	99                   	cwd
    33a7:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    33ab:	89 96 70 f1          	mov    WORD PTR [bp-0xe90],dx
    33af:	9b db 86 6e f1       	fild   DWORD PTR [bp-0xe92]
    33b4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    33b7:	99                   	cwd
    33b8:	bf 96 1f             	mov    di,0x1f96
    33bb:	9a 16 04 cf 33       	call   0x33cf:0x416
    33c0:	c1 e0 02             	shl    ax,0x2
    33c3:	8b c8                	mov    cx,ax
    33c5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    33c8:	99                   	cwd
    33c9:	bf 7a 1f             	mov    di,0x1f7a
    33cc:	9a 16 04 f3 33       	call   0x33f3:0x416
    33d1:	8b f8                	mov    di,ax
    33d3:	c1 e7 03             	shl    di,0x3
    33d6:	03 f9                	add    di,cx
    33d8:	9b db 83 ec fa       	fild   DWORD PTR [bp+di-0x514]
    33dd:	9b dc 8e 28 f9       	fmul   QWORD PTR [bp-0x6d8]
    33e2:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    33e8:	9b dc a6 72 f2       	fsub   QWORD PTR [bp-0xd8e]
    33ed:	9b de c9             	fmulp  st(1),st
    33f0:	9a af 04 0a 34       	call   0x340a:0x4af
    33f5:	83 ec 08             	sub    sp,0x8
    33f8:	89 e3                	mov    bx,sp
    33fa:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    33fe:	90                   	nop
    33ff:	9b                   	fwait
    3400:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3403:	99                   	cwd
    3404:	bf 96 1f             	mov    di,0x1f96
    3407:	9a 16 04 1b 34       	call   0x341b:0x416
    340c:	c1 e0 03             	shl    ax,0x3
    340f:	8b c8                	mov    cx,ax
    3411:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3414:	99                   	cwd
    3415:	bf 7a 1f             	mov    di,0x1f7a
    3418:	9a 16 04 3c 34       	call   0x343c:0x416
    341d:	8b f8                	mov    di,ax
    341f:	c1 e7 04             	shl    di,0x4
    3422:	03 f9                	add    di,cx
    3424:	ff b3 6a fb          	push   WORD PTR [bp+di-0x496]
    3428:	ff b3 68 fb          	push   WORD PTR [bp+di-0x498]
    342c:	ff b3 66 fb          	push   WORD PTR [bp+di-0x49a]
    3430:	ff b3 64 fb          	push   WORD PTR [bp+di-0x49c]
    3434:	9a a7 2e e7 34       	call   0x34e7:0x2ea7
    3439:	9a 0e 10 50 34       	call   0x3450:0x100e
    343e:	89 86 5a f2          	mov    WORD PTR [bp-0xda6],ax
    3442:	89 96 5c f2          	mov    WORD PTR [bp-0xda4],dx
    3446:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3449:	99                   	cwd
    344a:	bf 96 1f             	mov    di,0x1f96
    344d:	9a 16 04 61 34       	call   0x3461:0x416
    3452:	c1 e0 02             	shl    ax,0x2
    3455:	8b c8                	mov    cx,ax
    3457:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    345a:	99                   	cwd
    345b:	bf 7a 1f             	mov    di,0x1f7a
    345e:	9a 16 04 8a 34       	call   0x348a:0x416
    3463:	8b f8                	mov    di,ax
    3465:	c1 e7 03             	shl    di,0x3
    3468:	03 f9                	add    di,cx
    346a:	9b db 83 ac fa       	fild   DWORD PTR [bp+di-0x554]
    346f:	9b dc 8e 20 f9       	fmul   QWORD PTR [bp-0x6e0]
    3474:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    347a:	9b dc 46 f4          	fadd   QWORD PTR [bp-0xc]
    347e:	9b de c9             	fmulp  st(1),st
    3481:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    3487:	9a b2 04 a3 34       	call   0x34a3:0x4b2
    348c:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    3492:	9b dc a6 72 f2       	fsub   QWORD PTR [bp-0xd8e]
    3497:	9b de c9             	fmulp  st(1),st
    349a:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    34a0:	9a b2 04 ba 34       	call   0x34ba:0x4b2
    34a5:	83 ec 08             	sub    sp,0x8
    34a8:	89 e3                	mov    bx,sp
    34aa:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    34ae:	90                   	nop
    34af:	9b                   	fwait
    34b0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    34b3:	99                   	cwd
    34b4:	bf 96 1f             	mov    di,0x1f96
    34b7:	9a 16 04 cb 34       	call   0x34cb:0x416
    34bc:	c1 e0 03             	shl    ax,0x3
    34bf:	8b c8                	mov    cx,ax
    34c1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    34c4:	99                   	cwd
    34c5:	bf 7a 1f             	mov    di,0x1f7a
    34c8:	9a 16 04 ec 34       	call   0x34ec:0x416
    34cd:	8b f8                	mov    di,ax
    34cf:	c1 e7 04             	shl    di,0x4
    34d2:	03 f9                	add    di,cx
    34d4:	ff b3 6a fb          	push   WORD PTR [bp+di-0x496]
    34d8:	ff b3 68 fb          	push   WORD PTR [bp+di-0x498]
    34dc:	ff b3 66 fb          	push   WORD PTR [bp+di-0x49a]
    34e0:	ff b3 64 fb          	push   WORD PTR [bp+di-0x49c]
    34e4:	9a a7 2e 4e 36       	call   0x364e:0x2ea7
    34e9:	9a 0e 10 36 35       	call   0x3536:0x100e
    34ee:	89 86 56 f2          	mov    WORD PTR [bp-0xdaa],ax
    34f2:	89 96 58 f2          	mov    WORD PTR [bp-0xda8],dx
    34f6:	8b 86 5a f2          	mov    ax,WORD PTR [bp-0xda6]
    34fa:	8b 96 5c f2          	mov    dx,WORD PTR [bp-0xda4]
    34fe:	89 86 5e f2          	mov    WORD PTR [bp-0xda2],ax
    3502:	89 96 60 f2          	mov    WORD PTR [bp-0xda0],dx
    3506:	8b 86 5e f2          	mov    ax,WORD PTR [bp-0xda2]
    350a:	8b 96 60 f2          	mov    dx,WORD PTR [bp-0xda0]
    350e:	3b 96 58 f2          	cmp    dx,WORD PTR [bp-0xda8]
    3512:	7f 08                	jg     0x351c
    3514:	7c 16                	jl     0x352c
    3516:	3b 86 56 f2          	cmp    ax,WORD PTR [bp-0xdaa]
    351a:	76 10                	jbe    0x352c
    351c:	8b 86 56 f2          	mov    ax,WORD PTR [bp-0xdaa]
    3520:	8b 96 58 f2          	mov    dx,WORD PTR [bp-0xda8]
    3524:	89 86 5e f2          	mov    WORD PTR [bp-0xda2],ax
    3528:	89 96 60 f2          	mov    WORD PTR [bp-0xda0],dx
    352c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    352f:	99                   	cwd
    3530:	bf 96 1f             	mov    di,0x1f96
    3533:	9a 16 04 47 35       	call   0x3547:0x416
    3538:	c1 e0 02             	shl    ax,0x2
    353b:	8b c8                	mov    cx,ax
    353d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3540:	99                   	cwd
    3541:	bf 7a 1f             	mov    di,0x1f7a
    3544:	9a 16 04 78 35       	call   0x3578:0x416
    3549:	8b f8                	mov    di,ax
    354b:	c1 e7 03             	shl    di,0x3
    354e:	03 f9                	add    di,cx
    3550:	8b 83 2c fb          	mov    ax,WORD PTR [bp+di-0x4d4]
    3554:	8b 93 2e fb          	mov    dx,WORD PTR [bp+di-0x4d2]
    3558:	3b 96 60 f2          	cmp    dx,WORD PTR [bp-0xda0]
    355c:	7f 08                	jg     0x3566
    355e:	7c 3c                	jl     0x359c
    3560:	3b 86 5e f2          	cmp    ax,WORD PTR [bp-0xda2]
    3564:	76 36                	jbe    0x359c
    3566:	ff b6 60 f2          	push   WORD PTR [bp-0xda0]
    356a:	ff b6 5e f2          	push   WORD PTR [bp-0xda2]
    356e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3571:	99                   	cwd
    3572:	bf 96 1f             	mov    di,0x1f96
    3575:	9a 16 04 89 35       	call   0x3589:0x416
    357a:	c1 e0 02             	shl    ax,0x2
    357d:	8b c8                	mov    cx,ax
    357f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3582:	99                   	cwd
    3583:	bf 7a 1f             	mov    di,0x1f7a
    3586:	9a 16 04 a6 35       	call   0x35a6:0x416
    358b:	8b f8                	mov    di,ax
    358d:	c1 e7 03             	shl    di,0x3
    3590:	03 f9                	add    di,cx
    3592:	58                   	pop    ax
    3593:	5a                   	pop    dx
    3594:	89 83 2c fb          	mov    WORD PTR [bp+di-0x4d4],ax
    3598:	89 93 2e fb          	mov    WORD PTR [bp+di-0x4d2],dx
    359c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    359f:	99                   	cwd
    35a0:	bf 96 1f             	mov    di,0x1f96
    35a3:	9a 16 04 b7 35       	call   0x35b7:0x416
    35a8:	c1 e0 02             	shl    ax,0x2
    35ab:	8b c8                	mov    cx,ax
    35ad:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    35b0:	99                   	cwd
    35b1:	bf 7a 1f             	mov    di,0x1f7a
    35b4:	9a 16 04 cf 35       	call   0x35cf:0x416
    35b9:	8b f8                	mov    di,ax
    35bb:	c1 e7 03             	shl    di,0x3
    35be:	03 f9                	add    di,cx
    35c0:	9b db 83 2c fb       	fild   DWORD PTR [bp+di-0x4d4]
    35c5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    35c8:	99                   	cwd
    35c9:	bf 96 1f             	mov    di,0x1f96
    35cc:	9a 16 04 e0 35       	call   0x35e0:0x416
    35d1:	c1 e0 03             	shl    ax,0x3
    35d4:	8b c8                	mov    cx,ax
    35d6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    35d9:	99                   	cwd
    35da:	bf 7a 1f             	mov    di,0x1f7a
    35dd:	9a 16 04 03 36       	call   0x3603:0x416
    35e2:	8b f8                	mov    di,ax
    35e4:	c1 e7 04             	shl    di,0x4
    35e7:	03 f9                	add    di,cx
    35e9:	9b dc 8b 64 fb       	fmul   QWORD PTR [bp+di-0x49c]
    35ee:	83 ec 08             	sub    sp,0x8
    35f1:	89 e3                	mov    bx,sp
    35f3:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    35f7:	90                   	nop
    35f8:	9b                   	fwait
    35f9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    35fc:	99                   	cwd
    35fd:	bf 96 1f             	mov    di,0x1f96
    3600:	9a 16 04 14 36       	call   0x3614:0x416
    3605:	c1 e0 02             	shl    ax,0x2
    3608:	8b c8                	mov    cx,ax
    360a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    360d:	99                   	cwd
    360e:	bf 7a 1f             	mov    di,0x1f7a
    3611:	9a 16 04 3e 36       	call   0x363e:0x416
    3616:	8b f8                	mov    di,ax
    3618:	c1 e7 03             	shl    di,0x3
    361b:	03 f9                	add    di,cx
    361d:	9b db 83 ac fa       	fild   DWORD PTR [bp+di-0x554]
    3622:	9b dc 8e 20 f9       	fmul   QWORD PTR [bp-0x6e0]
    3627:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    362d:	9b dc a6 72 f2       	fsub   QWORD PTR [bp-0xd8e]
    3632:	9b de c9             	fmulp  st(1),st
    3635:	9b 2e d9 06 8a 1f    	fld    DWORD PTR cs:0x1f8a
    363b:	9a b2 04 76 36       	call   0x3676:0x4b2
    3640:	83 ec 08             	sub    sp,0x8
    3643:	89 e3                	mov    bx,sp
    3645:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3649:	90                   	nop
    364a:	9b                   	fwait
    364b:	9a a7 2e 6a 36       	call   0x366a:0x2ea7
    3650:	9b 2e d8 0e 8a 1f    	fmul   DWORD PTR cs:0x1f8a
    3656:	9b 2e d8 26 8a 1f    	fsub   DWORD PTR cs:0x1f8a
    365c:	83 ec 08             	sub    sp,0x8
    365f:	89 e3                	mov    bx,sp
    3661:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3665:	90                   	nop
    3666:	9b                   	fwait
    3667:	9a a6 2f 0f 40       	call   0x400f:0x2fa6
    366c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    366f:	99                   	cwd
    3670:	bf 96 1f             	mov    di,0x1f96
    3673:	9a 16 04 87 36       	call   0x3687:0x416
    3678:	c1 e0 03             	shl    ax,0x3
    367b:	8b c8                	mov    cx,ax
    367d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3680:	99                   	cwd
    3681:	bf 7a 1f             	mov    di,0x1f7a
    3684:	9a 16 04 a1 36       	call   0x36a1:0x416
    3689:	8b f8                	mov    di,ax
    368b:	c1 e7 04             	shl    di,0x4
    368e:	03 f9                	add    di,cx
    3690:	9b dd 9b be f1       	fstp   QWORD PTR [bp+di-0xe42]
    3695:	90                   	nop
    3696:	9b                   	fwait
    3697:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    369a:	99                   	cwd
    369b:	bf 96 1f             	mov    di,0x1f96
    369e:	9a 16 04 b2 36       	call   0x36b2:0x416
    36a3:	c1 e0 03             	shl    ax,0x3
    36a6:	8b c8                	mov    cx,ax
    36a8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36ab:	99                   	cwd
    36ac:	bf 7a 1f             	mov    di,0x1f7a
    36af:	9a 16 04 e4 36       	call   0x36e4:0x416
    36b4:	8b f8                	mov    di,ax
    36b6:	c1 e7 04             	shl    di,0x4
    36b9:	03 f9                	add    di,cx
    36bb:	9b dd 83 be f1       	fld    QWORD PTR [bp+di-0xe42]
    36c0:	9b 2e d8 1e 76 1f    	fcomp  DWORD PTR cs:0x1f76
    36c6:	9b dd be 70 f1       	fstsw  WORD PTR [bp-0xe90]
    36cb:	90                   	nop
    36cc:	9b                   	fwait
    36cd:	8a a6 71 f1          	mov    ah,BYTE PTR [bp-0xe8f]
    36d1:	9e                   	sahf
    36d2:	73 31                	jae    0x3705
    36d4:	9b 2e d9 06 76 1f    	fld    DWORD PTR cs:0x1f76
    36da:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    36dd:	99                   	cwd
    36de:	bf 96 1f             	mov    di,0x1f96
    36e1:	9a 16 04 f5 36       	call   0x36f5:0x416
    36e6:	c1 e0 03             	shl    ax,0x3
    36e9:	8b c8                	mov    cx,ax
    36eb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36ee:	99                   	cwd
    36ef:	bf 7a 1f             	mov    di,0x1f7a
    36f2:	9a 16 04 3e 37       	call   0x373e:0x416
    36f7:	8b f8                	mov    di,ax
    36f9:	c1 e7 04             	shl    di,0x4
    36fc:	03 f9                	add    di,cx
    36fe:	9b dd 9b be f1       	fstp   QWORD PTR [bp+di-0xe42]
    3703:	90                   	nop
    3704:	9b                   	fwait
    3705:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    3709:	74 03                	je     0x370e
    370b:	e9 8f fb             	jmp    0x329d
    370e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3711:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    3715:	74 03                	je     0x371a
    3717:	e9 79 fb             	jmp    0x3293
    371a:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    371f:	eb 03                	jmp    0x3724
    3721:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3724:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3727:	ff 76 fc             	push   WORD PTR [bp-0x4]
    372a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    372d:	06                   	push   es
    372e:	57                   	push   di
    372f:	9a f6 0f 16 38       	call   0x3816:0xff6
    3734:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3737:	99                   	cwd
    3738:	bf 96 1f             	mov    di,0x1f96
    373b:	9a 16 04 81 37       	call   0x3781:0x416
    3740:	8b f8                	mov    di,ax
    3742:	c1 e7 03             	shl    di,0x3
    3745:	9b dd 9b fa f3       	fstp   QWORD PTR [bp+di-0xc06]
    374a:	90                   	nop
    374b:	9b                   	fwait
    374c:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    3750:	75 cf                	jne    0x3721
    3752:	a1 4e 01             	mov    ax,ds:0x14e
    3755:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    3759:	b8 01 00             	mov    ax,0x1
    375c:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    3760:	7e 03                	jle    0x3765
    3762:	e9 6e 06             	jmp    0x3dd3
    3765:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3768:	eb 03                	jmp    0x376d
    376a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    376d:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    3772:	eb 03                	jmp    0x3777
    3774:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3777:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    377a:	99                   	cwd
    377b:	bf 96 1f             	mov    di,0x1f96
    377e:	9a 16 04 a2 37       	call   0x37a2:0x416
    3783:	8b f8                	mov    di,ax
    3785:	c1 e7 03             	shl    di,0x3
    3788:	ff b3 e6 f8          	push   WORD PTR [bp+di-0x71a]
    378c:	ff b3 e4 f8          	push   WORD PTR [bp+di-0x71c]
    3790:	ff b3 e2 f8          	push   WORD PTR [bp+di-0x71e]
    3794:	ff b3 e0 f8          	push   WORD PTR [bp+di-0x720]
    3798:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    379b:	99                   	cwd
    379c:	bf 96 1f             	mov    di,0x1f96
    379f:	9a 16 04 c3 37       	call   0x37c3:0x416
    37a4:	8b f8                	mov    di,ax
    37a6:	c1 e7 03             	shl    di,0x3
    37a9:	ff b3 06 f9          	push   WORD PTR [bp+di-0x6fa]
    37ad:	ff b3 04 f9          	push   WORD PTR [bp+di-0x6fc]
    37b1:	ff b3 02 f9          	push   WORD PTR [bp+di-0x6fe]
    37b5:	ff b3 00 f9          	push   WORD PTR [bp+di-0x700]
    37b9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    37bc:	99                   	cwd
    37bd:	bf 96 1f             	mov    di,0x1f96
    37c0:	9a 16 04 e4 37       	call   0x37e4:0x416
    37c5:	8b f8                	mov    di,ax
    37c7:	c1 e7 03             	shl    di,0x3
    37ca:	ff b3 f6 f8          	push   WORD PTR [bp+di-0x70a]
    37ce:	ff b3 f4 f8          	push   WORD PTR [bp+di-0x70c]
    37d2:	ff b3 f2 f8          	push   WORD PTR [bp+di-0x70e]
    37d6:	ff b3 f0 f8          	push   WORD PTR [bp+di-0x710]
    37da:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    37dd:	99                   	cwd
    37de:	bf 96 1f             	mov    di,0x1f96
    37e1:	9a 16 04 f5 37       	call   0x37f5:0x416
    37e6:	c1 e0 03             	shl    ax,0x3
    37e9:	8b c8                	mov    cx,ax
    37eb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    37ee:	99                   	cwd
    37ef:	bf 7a 1f             	mov    di,0x1f7a
    37f2:	9a 16 04 22 38       	call   0x3822:0x416
    37f7:	8b f8                	mov    di,ax
    37f9:	c1 e7 04             	shl    di,0x4
    37fc:	03 f9                	add    di,cx
    37fe:	ff b3 16 f5          	push   WORD PTR [bp+di-0xaea]
    3802:	ff b3 14 f5          	push   WORD PTR [bp+di-0xaec]
    3806:	ff b3 12 f5          	push   WORD PTR [bp+di-0xaee]
    380a:	ff b3 10 f5          	push   WORD PTR [bp+di-0xaf0]
    380e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3811:	06                   	push   es
    3812:	57                   	push   di
    3813:	9a c3 13 2c 39       	call   0x392c:0x13c3
    3818:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    381b:	99                   	cwd
    381c:	bf 96 1f             	mov    di,0x1f96
    381f:	9a 16 04 33 38       	call   0x3833:0x416
    3824:	c1 e0 03             	shl    ax,0x3
    3827:	8b c8                	mov    cx,ax
    3829:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    382c:	99                   	cwd
    382d:	bf 7a 1f             	mov    di,0x1f7a
    3830:	9a 16 04 4d 38       	call   0x384d:0x416
    3835:	8b f8                	mov    di,ax
    3837:	c1 e7 04             	shl    di,0x4
    383a:	03 f9                	add    di,cx
    383c:	9b dd 9b 5c ff       	fstp   QWORD PTR [bp+di-0xa4]
    3841:	90                   	nop
    3842:	9b                   	fwait
    3843:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3846:	99                   	cwd
    3847:	bf 96 1f             	mov    di,0x1f96
    384a:	9a 16 04 6e 38       	call   0x386e:0x416
    384f:	8b f8                	mov    di,ax
    3851:	c1 e7 03             	shl    di,0x3
    3854:	ff b3 d6 f8          	push   WORD PTR [bp+di-0x72a]
    3858:	ff b3 d4 f8          	push   WORD PTR [bp+di-0x72c]
    385c:	ff b3 d2 f8          	push   WORD PTR [bp+di-0x72e]
    3860:	ff b3 d0 f8          	push   WORD PTR [bp+di-0x730]
    3864:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3867:	99                   	cwd
    3868:	bf 96 1f             	mov    di,0x1f96
    386b:	9a 16 04 7f 38       	call   0x387f:0x416
    3870:	c1 e0 02             	shl    ax,0x2
    3873:	8b c8                	mov    cx,ax
    3875:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3878:	99                   	cwd
    3879:	bf 7a 1f             	mov    di,0x1f7a
    387c:	9a 16 04 9a 38       	call   0x389a:0x416
    3881:	8b f8                	mov    di,ax
    3883:	c1 e7 03             	shl    di,0x3
    3886:	03 f9                	add    di,cx
    3888:	ff b3 2e fb          	push   WORD PTR [bp+di-0x4d2]
    388c:	ff b3 2c fb          	push   WORD PTR [bp+di-0x4d4]
    3890:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3893:	99                   	cwd
    3894:	bf 96 1f             	mov    di,0x1f96
    3897:	9a 16 04 ab 38       	call   0x38ab:0x416
    389c:	c1 e0 02             	shl    ax,0x2
    389f:	8b c8                	mov    cx,ax
    38a1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    38a4:	99                   	cwd
    38a5:	bf 7a 1f             	mov    di,0x1f7a
    38a8:	9a 16 04 c6 38       	call   0x38c6:0x416
    38ad:	8b f8                	mov    di,ax
    38af:	c1 e7 03             	shl    di,0x3
    38b2:	03 f9                	add    di,cx
    38b4:	ff b3 f2 fb          	push   WORD PTR [bp+di-0x40e]
    38b8:	ff b3 f0 fb          	push   WORD PTR [bp+di-0x410]
    38bc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    38bf:	99                   	cwd
    38c0:	bf 96 1f             	mov    di,0x1f96
    38c3:	9a 16 04 d7 38       	call   0x38d7:0x416
    38c8:	c1 e0 03             	shl    ax,0x3
    38cb:	8b c8                	mov    cx,ax
    38cd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    38d0:	99                   	cwd
    38d1:	bf 7a 1f             	mov    di,0x1f7a
    38d4:	9a 16 04 fa 38       	call   0x38fa:0x416
    38d9:	8b f8                	mov    di,ax
    38db:	c1 e7 04             	shl    di,0x4
    38de:	03 f9                	add    di,cx
    38e0:	ff b3 16 f5          	push   WORD PTR [bp+di-0xaea]
    38e4:	ff b3 14 f5          	push   WORD PTR [bp+di-0xaec]
    38e8:	ff b3 12 f5          	push   WORD PTR [bp+di-0xaee]
    38ec:	ff b3 10 f5          	push   WORD PTR [bp+di-0xaf0]
    38f0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    38f3:	99                   	cwd
    38f4:	bf 96 1f             	mov    di,0x1f96
    38f7:	9a 16 04 0b 39       	call   0x390b:0x416
    38fc:	c1 e0 03             	shl    ax,0x3
    38ff:	8b c8                	mov    cx,ax
    3901:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3904:	99                   	cwd
    3905:	bf 7a 1f             	mov    di,0x1f7a
    3908:	9a 16 04 38 39       	call   0x3938:0x416
    390d:	8b f8                	mov    di,ax
    390f:	c1 e7 04             	shl    di,0x4
    3912:	03 f9                	add    di,cx
    3914:	ff b3 96 f4          	push   WORD PTR [bp+di-0xb6a]
    3918:	ff b3 94 f4          	push   WORD PTR [bp+di-0xb6c]
    391c:	ff b3 92 f4          	push   WORD PTR [bp+di-0xb6e]
    3920:	ff b3 90 f4          	push   WORD PTR [bp+di-0xb70]
    3924:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3927:	06                   	push   es
    3928:	57                   	push   di
    3929:	9a a5 14 4a 3a       	call   0x3a4a:0x14a5
    392e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3931:	99                   	cwd
    3932:	bf 96 1f             	mov    di,0x1f96
    3935:	9a 16 04 49 39       	call   0x3949:0x416
    393a:	c1 e0 03             	shl    ax,0x3
    393d:	8b c8                	mov    cx,ax
    393f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3942:	99                   	cwd
    3943:	bf 7a 1f             	mov    di,0x1f7a
    3946:	9a 16 04 63 39       	call   0x3963:0x416
    394b:	8b f8                	mov    di,ax
    394d:	c1 e7 04             	shl    di,0x4
    3950:	03 f9                	add    di,cx
    3952:	9b dd 9b dc fe       	fstp   QWORD PTR [bp+di-0x124]
    3957:	90                   	nop
    3958:	9b                   	fwait
    3959:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    395c:	99                   	cwd
    395d:	bf 96 1f             	mov    di,0x1f96
    3960:	9a 16 04 94 39       	call   0x3994:0x416
    3965:	8b f8                	mov    di,ax
    3967:	c1 e7 03             	shl    di,0x3
    396a:	ff b3 c6 f8          	push   WORD PTR [bp+di-0x73a]
    396e:	ff b3 c4 f8          	push   WORD PTR [bp+di-0x73c]
    3972:	ff b3 c2 f8          	push   WORD PTR [bp+di-0x73e]
    3976:	ff b3 c0 f8          	push   WORD PTR [bp+di-0x740]
    397a:	ff b6 1e f9          	push   WORD PTR [bp-0x6e2]
    397e:	ff b6 1c f9          	push   WORD PTR [bp-0x6e4]
    3982:	ff b6 1a f9          	push   WORD PTR [bp-0x6e6]
    3986:	ff b6 18 f9          	push   WORD PTR [bp-0x6e8]
    398a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    398d:	99                   	cwd
    398e:	bf 96 1f             	mov    di,0x1f96
    3991:	9a 16 04 a5 39       	call   0x39a5:0x416
    3996:	c1 e0 03             	shl    ax,0x3
    3999:	8b c8                	mov    cx,ax
    399b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    399e:	99                   	cwd
    399f:	bf 7a 1f             	mov    di,0x1f7a
    39a2:	9a 16 04 c8 39       	call   0x39c8:0x416
    39a7:	8b f8                	mov    di,ax
    39a9:	c1 e7 04             	shl    di,0x4
    39ac:	03 f9                	add    di,cx
    39ae:	ff b3 16 f5          	push   WORD PTR [bp+di-0xaea]
    39b2:	ff b3 14 f5          	push   WORD PTR [bp+di-0xaec]
    39b6:	ff b3 12 f5          	push   WORD PTR [bp+di-0xaee]
    39ba:	ff b3 10 f5          	push   WORD PTR [bp+di-0xaf0]
    39be:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    39c1:	99                   	cwd
    39c2:	bf 96 1f             	mov    di,0x1f96
    39c5:	9a 16 04 d9 39       	call   0x39d9:0x416
    39ca:	c1 e0 02             	shl    ax,0x2
    39cd:	8b c8                	mov    cx,ax
    39cf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    39d2:	99                   	cwd
    39d3:	bf 7a 1f             	mov    di,0x1f7a
    39d6:	9a 16 04 f4 39       	call   0x39f4:0x416
    39db:	8b f8                	mov    di,ax
    39dd:	c1 e7 03             	shl    di,0x3
    39e0:	03 f9                	add    di,cx
    39e2:	ff b3 ea f9          	push   WORD PTR [bp+di-0x616]
    39e6:	ff b3 e8 f9          	push   WORD PTR [bp+di-0x618]
    39ea:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    39ed:	99                   	cwd
    39ee:	bf 96 1f             	mov    di,0x1f96
    39f1:	9a 16 04 05 3a       	call   0x3a05:0x416
    39f6:	c1 e0 02             	shl    ax,0x2
    39f9:	8b c8                	mov    cx,ax
    39fb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    39fe:	99                   	cwd
    39ff:	bf 7a 1f             	mov    di,0x1f7a
    3a02:	9a 16 04 20 3a       	call   0x3a20:0x416
    3a07:	8b f8                	mov    di,ax
    3a09:	c1 e7 03             	shl    di,0x3
    3a0c:	03 f9                	add    di,cx
    3a0e:	ff b3 2e fb          	push   WORD PTR [bp+di-0x4d2]
    3a12:	ff b3 2c fb          	push   WORD PTR [bp+di-0x4d4]
    3a16:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3a19:	99                   	cwd
    3a1a:	bf 96 1f             	mov    di,0x1f96
    3a1d:	9a 16 04 31 3a       	call   0x3a31:0x416
    3a22:	c1 e0 02             	shl    ax,0x2
    3a25:	8b c8                	mov    cx,ax
    3a27:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3a2a:	99                   	cwd
    3a2b:	bf 7a 1f             	mov    di,0x1f7a
    3a2e:	9a 16 04 56 3a       	call   0x3a56:0x416
    3a33:	8b f8                	mov    di,ax
    3a35:	c1 e7 03             	shl    di,0x3
    3a38:	03 f9                	add    di,cx
    3a3a:	ff b3 f2 fb          	push   WORD PTR [bp+di-0x40e]
    3a3e:	ff b3 f0 fb          	push   WORD PTR [bp+di-0x410]
    3a42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a45:	06                   	push   es
    3a46:	57                   	push   di
    3a47:	9a b9 15 00 3b       	call   0x3b00:0x15b9
    3a4c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3a4f:	99                   	cwd
    3a50:	bf 96 1f             	mov    di,0x1f96
    3a53:	9a 16 04 67 3a       	call   0x3a67:0x416
    3a58:	c1 e0 03             	shl    ax,0x3
    3a5b:	8b c8                	mov    cx,ax
    3a5d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3a60:	99                   	cwd
    3a61:	bf 7a 1f             	mov    di,0x1f7a
    3a64:	9a 16 04 81 3a       	call   0x3a81:0x416
    3a69:	8b f8                	mov    di,ax
    3a6b:	c1 e7 04             	shl    di,0x4
    3a6e:	03 f9                	add    di,cx
    3a70:	9b dd 9b 5c fe       	fstp   QWORD PTR [bp+di-0x1a4]
    3a75:	90                   	nop
    3a76:	9b                   	fwait
    3a77:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3a7a:	99                   	cwd
    3a7b:	bf 96 1f             	mov    di,0x1f96
    3a7e:	9a 16 04 a2 3a       	call   0x3aa2:0x416
    3a83:	8b f8                	mov    di,ax
    3a85:	c1 e7 03             	shl    di,0x3
    3a88:	ff b3 b6 f8          	push   WORD PTR [bp+di-0x74a]
    3a8c:	ff b3 b4 f8          	push   WORD PTR [bp+di-0x74c]
    3a90:	ff b3 b2 f8          	push   WORD PTR [bp+di-0x74e]
    3a94:	ff b3 b0 f8          	push   WORD PTR [bp+di-0x750]
    3a98:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3a9b:	99                   	cwd
    3a9c:	bf 96 1f             	mov    di,0x1f96
    3a9f:	9a 16 04 b3 3a       	call   0x3ab3:0x416
    3aa4:	c1 e0 03             	shl    ax,0x3
    3aa7:	8b c8                	mov    cx,ax
    3aa9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3aac:	99                   	cwd
    3aad:	bf 7a 1f             	mov    di,0x1f7a
    3ab0:	9a 16 04 d6 3a       	call   0x3ad6:0x416
    3ab5:	8b f8                	mov    di,ax
    3ab7:	c1 e7 04             	shl    di,0x4
    3aba:	03 f9                	add    di,cx
    3abc:	ff b3 16 f5          	push   WORD PTR [bp+di-0xaea]
    3ac0:	ff b3 14 f5          	push   WORD PTR [bp+di-0xaec]
    3ac4:	ff b3 12 f5          	push   WORD PTR [bp+di-0xaee]
    3ac8:	ff b3 10 f5          	push   WORD PTR [bp+di-0xaf0]
    3acc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3acf:	99                   	cwd
    3ad0:	bf 96 1f             	mov    di,0x1f96
    3ad3:	9a 16 04 e7 3a       	call   0x3ae7:0x416
    3ad8:	c1 e0 02             	shl    ax,0x2
    3adb:	8b c8                	mov    cx,ax
    3add:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3ae0:	99                   	cwd
    3ae1:	bf 7a 1f             	mov    di,0x1f7a
    3ae4:	9a 16 04 0c 3b       	call   0x3b0c:0x416
    3ae9:	8b f8                	mov    di,ax
    3aeb:	c1 e7 03             	shl    di,0x3
    3aee:	03 f9                	add    di,cx
    3af0:	ff b3 aa f9          	push   WORD PTR [bp+di-0x656]
    3af4:	ff b3 a8 f9          	push   WORD PTR [bp+di-0x658]
    3af8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3afb:	06                   	push   es
    3afc:	57                   	push   di
    3afd:	9a 34 17 16 3c       	call   0x3c16:0x1734
    3b02:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3b05:	99                   	cwd
    3b06:	bf 96 1f             	mov    di,0x1f96
    3b09:	9a 16 04 1d 3b       	call   0x3b1d:0x416
    3b0e:	c1 e0 03             	shl    ax,0x3
    3b11:	8b c8                	mov    cx,ax
    3b13:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3b16:	99                   	cwd
    3b17:	bf 7a 1f             	mov    di,0x1f7a
    3b1a:	9a 16 04 37 3b       	call   0x3b37:0x416
    3b1f:	8b f8                	mov    di,ax
    3b21:	c1 e7 04             	shl    di,0x4
    3b24:	03 f9                	add    di,cx
    3b26:	9b dd 9b dc fd       	fstp   QWORD PTR [bp+di-0x224]
    3b2b:	90                   	nop
    3b2c:	9b                   	fwait
    3b2d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3b30:	99                   	cwd
    3b31:	bf 96 1f             	mov    di,0x1f96
    3b34:	9a 16 04 58 3b       	call   0x3b58:0x416
    3b39:	8b f8                	mov    di,ax
    3b3b:	c1 e7 03             	shl    di,0x3
    3b3e:	ff b3 a6 f8          	push   WORD PTR [bp+di-0x75a]
    3b42:	ff b3 a4 f8          	push   WORD PTR [bp+di-0x75c]
    3b46:	ff b3 a2 f8          	push   WORD PTR [bp+di-0x75e]
    3b4a:	ff b3 a0 f8          	push   WORD PTR [bp+di-0x760]
    3b4e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3b51:	99                   	cwd
    3b52:	bf 96 1f             	mov    di,0x1f96
    3b55:	9a 16 04 69 3b       	call   0x3b69:0x416
    3b5a:	c1 e0 03             	shl    ax,0x3
    3b5d:	8b c8                	mov    cx,ax
    3b5f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3b62:	99                   	cwd
    3b63:	bf 7a 1f             	mov    di,0x1f7a
    3b66:	9a 16 04 8c 3b       	call   0x3b8c:0x416
    3b6b:	8b f8                	mov    di,ax
    3b6d:	c1 e7 04             	shl    di,0x4
    3b70:	03 f9                	add    di,cx
    3b72:	ff b3 16 f4          	push   WORD PTR [bp+di-0xbea]
    3b76:	ff b3 14 f4          	push   WORD PTR [bp+di-0xbec]
    3b7a:	ff b3 12 f4          	push   WORD PTR [bp+di-0xbee]
    3b7e:	ff b3 10 f4          	push   WORD PTR [bp+di-0xbf0]
    3b82:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3b85:	99                   	cwd
    3b86:	bf 96 1f             	mov    di,0x1f96
    3b89:	9a 16 04 9d 3b       	call   0x3b9d:0x416
    3b8e:	c1 e0 03             	shl    ax,0x3
    3b91:	8b c8                	mov    cx,ax
    3b93:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3b96:	99                   	cwd
    3b97:	bf 7a 1f             	mov    di,0x1f7a
    3b9a:	9a 16 04 c0 3b       	call   0x3bc0:0x416
    3b9f:	8b f8                	mov    di,ax
    3ba1:	c1 e7 04             	shl    di,0x4
    3ba4:	03 f9                	add    di,cx
    3ba6:	ff b3 16 f5          	push   WORD PTR [bp+di-0xaea]
    3baa:	ff b3 14 f5          	push   WORD PTR [bp+di-0xaec]
    3bae:	ff b3 12 f5          	push   WORD PTR [bp+di-0xaee]
    3bb2:	ff b3 10 f5          	push   WORD PTR [bp+di-0xaf0]
    3bb6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3bb9:	99                   	cwd
    3bba:	bf 96 1f             	mov    di,0x1f96
    3bbd:	9a 16 04 d1 3b       	call   0x3bd1:0x416
    3bc2:	c1 e0 02             	shl    ax,0x2
    3bc5:	8b c8                	mov    cx,ax
    3bc7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3bca:	99                   	cwd
    3bcb:	bf 7a 1f             	mov    di,0x1f7a
    3bce:	9a 16 04 ec 3b       	call   0x3bec:0x416
    3bd3:	8b f8                	mov    di,ax
    3bd5:	c1 e7 03             	shl    di,0x3
    3bd8:	03 f9                	add    di,cx
    3bda:	ff b3 2e fb          	push   WORD PTR [bp+di-0x4d2]
    3bde:	ff b3 2c fb          	push   WORD PTR [bp+di-0x4d4]
    3be2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3be5:	99                   	cwd
    3be6:	bf 96 1f             	mov    di,0x1f96
    3be9:	9a 16 04 fd 3b       	call   0x3bfd:0x416
    3bee:	c1 e0 02             	shl    ax,0x2
    3bf1:	8b c8                	mov    cx,ax
    3bf3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3bf6:	99                   	cwd
    3bf7:	bf 7a 1f             	mov    di,0x1f7a
    3bfa:	9a 16 04 22 3c       	call   0x3c22:0x416
    3bff:	8b f8                	mov    di,ax
    3c01:	c1 e7 03             	shl    di,0x3
    3c04:	03 f9                	add    di,cx
    3c06:	ff b3 f2 fb          	push   WORD PTR [bp+di-0x40e]
    3c0a:	ff b3 f0 fb          	push   WORD PTR [bp+di-0x410]
    3c0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c11:	06                   	push   es
    3c12:	57                   	push   di
    3c13:	9a c7 17 69 3e       	call   0x3e69:0x17c7
    3c18:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3c1b:	99                   	cwd
    3c1c:	bf 96 1f             	mov    di,0x1f96
    3c1f:	9a 16 04 33 3c       	call   0x3c33:0x416
    3c24:	c1 e0 03             	shl    ax,0x3
    3c27:	8b c8                	mov    cx,ax
    3c29:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3c2c:	99                   	cwd
    3c2d:	bf 7a 1f             	mov    di,0x1f7a
    3c30:	9a 16 04 4d 3c       	call   0x3c4d:0x416
    3c35:	8b f8                	mov    di,ax
    3c37:	c1 e7 04             	shl    di,0x4
    3c3a:	03 f9                	add    di,cx
    3c3c:	9b dd 9b 5c fd       	fstp   QWORD PTR [bp+di-0x2a4]
    3c41:	90                   	nop
    3c42:	9b                   	fwait
    3c43:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3c46:	99                   	cwd
    3c47:	bf 96 1f             	mov    di,0x1f96
    3c4a:	9a 16 04 5e 3c       	call   0x3c5e:0x416
    3c4f:	c1 e0 03             	shl    ax,0x3
    3c52:	8b c8                	mov    cx,ax
    3c54:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3c57:	99                   	cwd
    3c58:	bf 7a 1f             	mov    di,0x1f7a
    3c5b:	9a 16 04 76 3c       	call   0x3c76:0x416
    3c60:	8b f8                	mov    di,ax
    3c62:	c1 e7 04             	shl    di,0x4
    3c65:	03 f9                	add    di,cx
    3c67:	9b dd 83 5c ff       	fld    QWORD PTR [bp+di-0xa4]
    3c6c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3c6f:	99                   	cwd
    3c70:	bf 96 1f             	mov    di,0x1f96
    3c73:	9a 16 04 87 3c       	call   0x3c87:0x416
    3c78:	c1 e0 03             	shl    ax,0x3
    3c7b:	8b c8                	mov    cx,ax
    3c7d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3c80:	99                   	cwd
    3c81:	bf 7a 1f             	mov    di,0x1f7a
    3c84:	9a 16 04 9f 3c       	call   0x3c9f:0x416
    3c89:	8b f8                	mov    di,ax
    3c8b:	c1 e7 04             	shl    di,0x4
    3c8e:	03 f9                	add    di,cx
    3c90:	9b dc 83 dc fe       	fadd   QWORD PTR [bp+di-0x124]
    3c95:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3c98:	99                   	cwd
    3c99:	bf 96 1f             	mov    di,0x1f96
    3c9c:	9a 16 04 b0 3c       	call   0x3cb0:0x416
    3ca1:	c1 e0 03             	shl    ax,0x3
    3ca4:	8b c8                	mov    cx,ax
    3ca6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3ca9:	99                   	cwd
    3caa:	bf 7a 1f             	mov    di,0x1f7a
    3cad:	9a 16 04 c8 3c       	call   0x3cc8:0x416
    3cb2:	8b f8                	mov    di,ax
    3cb4:	c1 e7 04             	shl    di,0x4
    3cb7:	03 f9                	add    di,cx
    3cb9:	9b dc 83 5c fe       	fadd   QWORD PTR [bp+di-0x1a4]
    3cbe:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3cc1:	99                   	cwd
    3cc2:	bf 96 1f             	mov    di,0x1f96
    3cc5:	9a 16 04 d9 3c       	call   0x3cd9:0x416
    3cca:	c1 e0 03             	shl    ax,0x3
    3ccd:	8b c8                	mov    cx,ax
    3ccf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3cd2:	99                   	cwd
    3cd3:	bf 7a 1f             	mov    di,0x1f7a
    3cd6:	9a 16 04 f1 3c       	call   0x3cf1:0x416
    3cdb:	8b f8                	mov    di,ax
    3cdd:	c1 e7 04             	shl    di,0x4
    3ce0:	03 f9                	add    di,cx
    3ce2:	9b dc 83 dc fd       	fadd   QWORD PTR [bp+di-0x224]
    3ce7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3cea:	99                   	cwd
    3ceb:	bf 96 1f             	mov    di,0x1f96
    3cee:	9a 16 04 02 3d       	call   0x3d02:0x416
    3cf3:	c1 e0 03             	shl    ax,0x3
    3cf6:	8b c8                	mov    cx,ax
    3cf8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3cfb:	99                   	cwd
    3cfc:	bf 7a 1f             	mov    di,0x1f7a
    3cff:	9a 16 04 26 3d       	call   0x3d26:0x416
    3d04:	8b f8                	mov    di,ax
    3d06:	c1 e7 04             	shl    di,0x4
    3d09:	03 f9                	add    di,cx
    3d0b:	9b dc 83 5c fd       	fadd   QWORD PTR [bp+di-0x2a4]
    3d10:	9b dd 9e 94 f1       	fstp   QWORD PTR [bp-0xe6c]
    3d15:	90                   	nop
    3d16:	9b 9b dd 86 94 f1    	fld    QWORD PTR [bp-0xe6c]
    3d1c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3d1f:	99                   	cwd
    3d20:	bf 96 1f             	mov    di,0x1f96
    3d23:	9a 16 04 37 3d       	call   0x3d37:0x416
    3d28:	c1 e0 03             	shl    ax,0x3
    3d2b:	8b c8                	mov    cx,ax
    3d2d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3d30:	99                   	cwd
    3d31:	bf 7a 1f             	mov    di,0x1f7a
    3d34:	9a 16 04 57 3d       	call   0x3d57:0x416
    3d39:	8b f8                	mov    di,ax
    3d3b:	c1 e7 04             	shl    di,0x4
    3d3e:	03 f9                	add    di,cx
    3d40:	9b dc 8b 5c fc       	fmul   QWORD PTR [bp+di-0x3a4]
    3d45:	9b d9 e1             	fabs
    3d48:	9b dd 9e 8c f1       	fstp   QWORD PTR [bp-0xe74]
    3d4d:	90                   	nop
    3d4e:	9b 9b dd 86 8c f1    	fld    QWORD PTR [bp-0xe74]
    3d54:	9a 73 10 63 3d       	call   0x3d63:0x1073
    3d59:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3d5c:	99                   	cwd
    3d5d:	bf 96 1f             	mov    di,0x1f96
    3d60:	9a 16 04 7f 3d       	call   0x3d7f:0x416
    3d65:	8b f8                	mov    di,ax
    3d67:	c1 e7 03             	shl    di,0x3
    3d6a:	9b dc 8b 90 f8       	fmul   QWORD PTR [bp+di-0x770]
    3d6f:	9b 2e d9 06 86 1f    	fld    DWORD PTR cs:0x1f86
    3d75:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3d78:	99                   	cwd
    3d79:	bf 96 1f             	mov    di,0x1f96
    3d7c:	9a 16 04 9d 3d       	call   0x3d9d:0x416
    3d81:	8b f8                	mov    di,ax
    3d83:	c1 e7 03             	shl    di,0x3
    3d86:	9b dc a3 90 f8       	fsub   QWORD PTR [bp+di-0x770]
    3d8b:	9b dc 8e 94 f1       	fmul   QWORD PTR [bp-0xe6c]
    3d90:	9b de c1             	faddp  st(1),st
    3d93:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3d96:	99                   	cwd
    3d97:	bf 96 1f             	mov    di,0x1f96
    3d9a:	9a 16 04 ae 3d       	call   0x3dae:0x416
    3d9f:	c1 e0 03             	shl    ax,0x3
    3da2:	8b c8                	mov    cx,ax
    3da4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3da7:	99                   	cwd
    3da8:	bf 7a 1f             	mov    di,0x1f7a
    3dab:	9a 16 04 11 3e       	call   0x3e11:0x416
    3db0:	8b f8                	mov    di,ax
    3db2:	c1 e7 04             	shl    di,0x4
    3db5:	03 f9                	add    di,cx
    3db7:	9b dd 9b dc fc       	fstp   QWORD PTR [bp+di-0x324]
    3dbc:	90                   	nop
    3dbd:	9b                   	fwait
    3dbe:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    3dc2:	74 03                	je     0x3dc7
    3dc4:	e9 ad f9             	jmp    0x3774
    3dc7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3dca:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    3dce:	74 03                	je     0x3dd3
    3dd0:	e9 97 f9             	jmp    0x376a
    3dd3:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    3dd8:	eb 03                	jmp    0x3ddd
    3dda:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3ddd:	9b 2e d9 06 76 1f    	fld    DWORD PTR cs:0x1f76
    3de3:	9b dd 9e 6c fc       	fstp   QWORD PTR [bp-0x394]
    3de8:	90                   	nop
    3de9:	9b                   	fwait
    3dea:	a1 4e 01             	mov    ax,ds:0x14e
    3ded:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    3df1:	b8 01 00             	mov    ax,0x1
    3df4:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    3df8:	7f 46                	jg     0x3e40
    3dfa:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3dfd:	eb 03                	jmp    0x3e02
    3dff:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3e02:	9b dd 86 6c fc       	fld    QWORD PTR [bp-0x394]
    3e07:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3e0a:	99                   	cwd
    3e0b:	bf 96 1f             	mov    di,0x1f96
    3e0e:	9a 16 04 22 3e       	call   0x3e22:0x416
    3e13:	c1 e0 03             	shl    ax,0x3
    3e16:	8b c8                	mov    cx,ax
    3e18:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3e1b:	99                   	cwd
    3e1c:	bf 7a 1f             	mov    di,0x1f7a
    3e1f:	9a 16 04 4d 3e       	call   0x3e4d:0x416
    3e24:	8b f8                	mov    di,ax
    3e26:	c1 e7 04             	shl    di,0x4
    3e29:	03 f9                	add    di,cx
    3e2b:	9b dc 83 dc fc       	fadd   QWORD PTR [bp+di-0x324]
    3e30:	9b dd 9e 6c fc       	fstp   QWORD PTR [bp-0x394]
    3e35:	90                   	nop
    3e36:	9b                   	fwait
    3e37:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3e3a:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    3e3e:	75 bf                	jne    0x3dff
    3e40:	9b df 06 4e 01       	fild   WORD PTR ds:0x14e
    3e45:	9b dd 86 6c fc       	fld    QWORD PTR [bp-0x394]
    3e4a:	9a af 04 75 3e       	call   0x3e75:0x4af
    3e4f:	9b dd 9e 64 fc       	fstp   QWORD PTR [bp-0x39c]
    3e54:	90                   	nop
    3e55:	9b                   	fwait
    3e56:	ff b6 6a fc          	push   WORD PTR [bp-0x396]
    3e5a:	ff b6 68 fc          	push   WORD PTR [bp-0x398]
    3e5e:	ff b6 66 fc          	push   WORD PTR [bp-0x39a]
    3e62:	ff b6 64 fc          	push   WORD PTR [bp-0x39c]
    3e66:	9a 2c 12 1d 3f       	call   0x3f1d:0x122c
    3e6b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3e6e:	99                   	cwd
    3e6f:	bf 96 1f             	mov    di,0x1f96
    3e72:	9a 16 04 4a 3f       	call   0x3f4a:0x416
    3e77:	8b f8                	mov    di,ax
    3e79:	c1 e7 03             	shl    di,0x3
    3e7c:	9b dc 8b fa f3       	fmul   QWORD PTR [bp+di-0xc06]
    3e81:	9b dd 9e 3c fc       	fstp   QWORD PTR [bp-0x3c4]
    3e86:	90                   	nop
    3e87:	9b                   	fwait
    3e88:	31 c0                	xor    ax,ax
    3e8a:	89 86 74 fa          	mov    WORD PTR [bp-0x58c],ax
    3e8e:	89 86 76 fa          	mov    WORD PTR [bp-0x58a],ax
    3e92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e95:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    3e9a:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    3e9e:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    3ea2:	b8 cc 1f             	mov    ax,0x1fcc
    3ea5:	0e                   	push   cs
    3ea6:	50                   	push   ax
    3ea7:	55                   	push   bp
    3ea8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3eac:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3eb0:	a1 4e 01             	mov    ax,ds:0x14e
    3eb3:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    3eb7:	b8 01 00             	mov    ax,0x1
    3eba:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    3ebe:	7e 03                	jle    0x3ec3
    3ec0:	e9 16 02             	jmp    0x40d9
    3ec3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3ec6:	eb 03                	jmp    0x3ecb
    3ec8:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3ecb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3ece:	99                   	cwd
    3ecf:	89 86 56 f1          	mov    WORD PTR [bp-0xeaa],ax
    3ed3:	89 96 58 f1          	mov    WORD PTR [bp-0xea8],dx
    3ed7:	c6 86 5a f1 00       	mov    BYTE PTR [bp-0xea6],0x0
    3edc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3edf:	99                   	cwd
    3ee0:	89 86 5e f1          	mov    WORD PTR [bp-0xea2],ax
    3ee4:	89 96 60 f1          	mov    WORD PTR [bp-0xea0],dx
    3ee8:	c6 86 62 f1 00       	mov    BYTE PTR [bp-0xe9e],0x0
    3eed:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3ef0:	99                   	cwd
    3ef1:	89 86 66 f1          	mov    WORD PTR [bp-0xe9a],ax
    3ef5:	89 96 68 f1          	mov    WORD PTR [bp-0xe98],dx
    3ef9:	c6 86 6a f1 00       	mov    BYTE PTR [bp-0xe96],0x0
    3efe:	8d be 56 f1          	lea    di,[bp-0xeaa]
    3f02:	16                   	push   ss
    3f03:	57                   	push   di
    3f04:	6a 02                	push   0x2
    3f06:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    3f0a:	06                   	push   es
    3f0b:	57                   	push   di
    3f0c:	9a 95 28 47 50       	call   0x5047:0x2895
    3f11:	08 c0                	or     al,al
    3f13:	75 0a                	jne    0x3f1f
    3f15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f18:	06                   	push   es
    3f19:	57                   	push   di
    3f1a:	9a 03 03 55 50       	call   0x5055:0x303
    3f1f:	bf 9e 1f             	mov    di,0x1f9e
    3f22:	0e                   	push   cs
    3f23:	57                   	push   di
    3f24:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    3f28:	06                   	push   es
    3f29:	57                   	push   di
    3f2a:	9a 9b 3b 67 3f       	call   0x3f67:0x3b9b
    3f2f:	89 c7                	mov    di,ax
    3f31:	8e c2                	mov    es,dx
    3f33:	06                   	push   es
    3f34:	57                   	push   di
    3f35:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f38:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3f3c:	8b c8                	mov    cx,ax
    3f3e:	8b da                	mov    bx,dx
    3f40:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f43:	99                   	cwd
    3f44:	bf 7a 1f             	mov    di,0x1f7a
    3f47:	9a 16 04 84 3f       	call   0x3f84:0x416
    3f4c:	8b f8                	mov    di,ax
    3f4e:	c1 e7 02             	shl    di,0x2
    3f51:	89 8b 10 f6          	mov    WORD PTR [bp+di-0x9f0],cx
    3f55:	89 9b 12 f6          	mov    WORD PTR [bp+di-0x9ee],bx
    3f59:	bf aa 1f             	mov    di,0x1faa
    3f5c:	0e                   	push   cs
    3f5d:	57                   	push   di
    3f5e:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    3f62:	06                   	push   es
    3f63:	57                   	push   di
    3f64:	9a 9b 3b a1 3f       	call   0x3fa1:0x3b9b
    3f69:	89 c7                	mov    di,ax
    3f6b:	8e c2                	mov    es,dx
    3f6d:	06                   	push   es
    3f6e:	57                   	push   di
    3f6f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f72:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3f76:	8b c8                	mov    cx,ax
    3f78:	8b da                	mov    bx,dx
    3f7a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f7d:	99                   	cwd
    3f7e:	bf 7a 1f             	mov    di,0x1f7a
    3f81:	9a 16 04 ba 3f       	call   0x3fba:0x416
    3f86:	8b f8                	mov    di,ax
    3f88:	c1 e7 02             	shl    di,0x2
    3f8b:	89 8b f0 f5          	mov    WORD PTR [bp+di-0xa10],cx
    3f8f:	89 9b f2 f5          	mov    WORD PTR [bp+di-0xa0e],bx
    3f93:	bf bd 1f             	mov    di,0x1fbd
    3f96:	0e                   	push   cs
    3f97:	57                   	push   di
    3f98:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    3f9c:	06                   	push   es
    3f9d:	57                   	push   di
    3f9e:	9a 9b 3b 60 50       	call   0x5060:0x3b9b
    3fa3:	89 c7                	mov    di,ax
    3fa5:	8e c2                	mov    es,dx
    3fa7:	06                   	push   es
    3fa8:	57                   	push   di
    3fa9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3fac:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3fb0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3fb3:	99                   	cwd
    3fb4:	bf 7a 1f             	mov    di,0x1f7a
    3fb7:	9a 16 04 d2 3f       	call   0x3fd2:0x416
    3fbc:	8b f8                	mov    di,ax
    3fbe:	c1 e7 03             	shl    di,0x3
    3fc1:	9b dd 9b ac f5       	fstp   QWORD PTR [bp+di-0xa54]
    3fc6:	90                   	nop
    3fc7:	9b                   	fwait
    3fc8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3fcb:	99                   	cwd
    3fcc:	bf 96 1f             	mov    di,0x1f96
    3fcf:	9a 16 04 e3 3f       	call   0x3fe3:0x416
    3fd4:	c1 e0 03             	shl    ax,0x3
    3fd7:	8b c8                	mov    cx,ax
    3fd9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3fdc:	99                   	cwd
    3fdd:	bf 7a 1f             	mov    di,0x1f7a
    3fe0:	9a 16 04 19 40       	call   0x4019:0x416
    3fe5:	8b f8                	mov    di,ax
    3fe7:	c1 e7 04             	shl    di,0x4
    3fea:	03 f9                	add    di,cx
    3fec:	ff b3 e2 fc          	push   WORD PTR [bp+di-0x31e]
    3ff0:	ff b3 e0 fc          	push   WORD PTR [bp+di-0x320]
    3ff4:	ff b3 de fc          	push   WORD PTR [bp+di-0x322]
    3ff8:	ff b3 dc fc          	push   WORD PTR [bp+di-0x324]
    3ffc:	ff b6 72 fc          	push   WORD PTR [bp-0x38e]
    4000:	ff b6 70 fc          	push   WORD PTR [bp-0x390]
    4004:	ff b6 6e fc          	push   WORD PTR [bp-0x392]
    4008:	ff b6 6c fc          	push   WORD PTR [bp-0x394]
    400c:	9a a7 2e ae 4c       	call   0x4cae:0x2ea7
    4011:	9b dc 8e 3c fc       	fmul   QWORD PTR [bp-0x3c4]
    4016:	9a 0e 10 27 40       	call   0x4027:0x100e
    401b:	52                   	push   dx
    401c:	50                   	push   ax
    401d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4020:	99                   	cwd
    4021:	bf 96 1f             	mov    di,0x1f96
    4024:	9a 16 04 38 40       	call   0x4038:0x416
    4029:	c1 e0 02             	shl    ax,0x2
    402c:	8b c8                	mov    cx,ax
    402e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4031:	99                   	cwd
    4032:	bf 7a 1f             	mov    di,0x1f7a
    4035:	9a 16 04 55 40       	call   0x4055:0x416
    403a:	8b f8                	mov    di,ax
    403c:	c1 e7 03             	shl    di,0x3
    403f:	03 f9                	add    di,cx
    4041:	58                   	pop    ax
    4042:	5a                   	pop    dx
    4043:	89 83 6c fa          	mov    WORD PTR [bp+di-0x594],ax
    4047:	89 93 6e fa          	mov    WORD PTR [bp+di-0x592],dx
    404b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    404e:	99                   	cwd
    404f:	bf 96 1f             	mov    di,0x1f96
    4052:	9a 16 04 66 40       	call   0x4066:0x416
    4057:	c1 e0 02             	shl    ax,0x2
    405a:	8b c8                	mov    cx,ax
    405c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    405f:	99                   	cwd
    4060:	bf 7a 1f             	mov    di,0x1f7a
    4063:	9a 16 04 81 40       	call   0x4081:0x416
    4068:	8b f8                	mov    di,ax
    406a:	c1 e7 03             	shl    di,0x3
    406d:	03 f9                	add    di,cx
    406f:	ff b3 2e fb          	push   WORD PTR [bp+di-0x4d2]
    4073:	ff b3 2c fb          	push   WORD PTR [bp+di-0x4d4]
    4077:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    407a:	99                   	cwd
    407b:	bf 96 1f             	mov    di,0x1f96
    407e:	9a 16 04 92 40       	call   0x4092:0x416
    4083:	c1 e0 02             	shl    ax,0x2
    4086:	8b c8                	mov    cx,ax
    4088:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    408b:	99                   	cwd
    408c:	bf 7a 1f             	mov    di,0x1f7a
    408f:	9a 16 04 ae 40       	call   0x40ae:0x416
    4094:	8b f8                	mov    di,ax
    4096:	c1 e7 03             	shl    di,0x3
    4099:	03 f9                	add    di,cx
    409b:	8b 83 f0 fb          	mov    ax,WORD PTR [bp+di-0x410]
    409f:	8b 93 f2 fb          	mov    dx,WORD PTR [bp+di-0x40e]
    40a3:	59                   	pop    cx
    40a4:	5b                   	pop    bx
    40a5:	03 c1                	add    ax,cx
    40a7:	13 d3                	adc    dx,bx
    40a9:	71 05                	jno    0x40b0
    40ab:	9a 3e 04 be 40       	call   0x40be:0x43e
    40b0:	8b c8                	mov    cx,ax
    40b2:	8b da                	mov    bx,dx
    40b4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    40b7:	99                   	cwd
    40b8:	bf 7a 1f             	mov    di,0x1f7a
    40bb:	9a 16 04 0b 41       	call   0x410b:0x416
    40c0:	8b f8                	mov    di,ax
    40c2:	c1 e7 02             	shl    di,0x2
    40c5:	89 8b 40 fc          	mov    WORD PTR [bp+di-0x3c0],cx
    40c9:	89 9b 42 fc          	mov    WORD PTR [bp+di-0x3be],bx
    40cd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    40d0:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    40d4:	74 03                	je     0x40d9
    40d6:	e9 ef fd             	jmp    0x3ec8
    40d9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    40dd:	83 c4 06             	add    sp,0x6
    40e0:	b8 e6 40             	mov    ax,0x40e6
    40e3:	0e                   	push   cs
    40e4:	50                   	push   ax
    40e5:	cb                   	retf
    40e6:	a1 4e 01             	mov    ax,ds:0x14e
    40e9:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    40ed:	b8 01 00             	mov    ax,0x1
    40f0:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    40f4:	7e 03                	jle    0x40f9
    40f6:	e9 1b 02             	jmp    0x4314
    40f9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    40fc:	eb 03                	jmp    0x4101
    40fe:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4101:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4104:	99                   	cwd
    4105:	bf da 1f             	mov    di,0x1fda
    4108:	9a 16 04 1c 41       	call   0x411c:0x416
    410d:	c1 e0 02             	shl    ax,0x2
    4110:	8b c8                	mov    cx,ax
    4112:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4115:	99                   	cwd
    4116:	bf d2 1f             	mov    di,0x1fd2
    4119:	9a 16 04 37 41       	call   0x4137:0x416
    411e:	8b f8                	mov    di,ax
    4120:	c1 e7 03             	shl    di,0x3
    4123:	03 f9                	add    di,cx
    4125:	8b 8b f0 fb          	mov    cx,WORD PTR [bp+di-0x410]
    4129:	8b 9b f2 fb          	mov    bx,WORD PTR [bp+di-0x40e]
    412d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4130:	99                   	cwd
    4131:	bf d2 1f             	mov    di,0x1fd2
    4134:	9a 16 04 5a 41       	call   0x415a:0x416
    4139:	8b f8                	mov    di,ax
    413b:	c1 e7 02             	shl    di,0x2
    413e:	8b 83 10 f6          	mov    ax,WORD PTR [bp+di-0x9f0]
    4142:	8b 93 12 f6          	mov    dx,WORD PTR [bp+di-0x9ee]
    4146:	3b d3                	cmp    dx,bx
    4148:	7f 06                	jg     0x4150
    414a:	7c 60                	jl     0x41ac
    414c:	3b c1                	cmp    ax,cx
    414e:	72 5c                	jb     0x41ac
    4150:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4153:	99                   	cwd
    4154:	bf da 1f             	mov    di,0x1fda
    4157:	9a 16 04 6b 41       	call   0x416b:0x416
    415c:	c1 e0 02             	shl    ax,0x2
    415f:	8b c8                	mov    cx,ax
    4161:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4164:	99                   	cwd
    4165:	bf d2 1f             	mov    di,0x1fd2
    4168:	9a 16 04 86 41       	call   0x4186:0x416
    416d:	8b f8                	mov    di,ax
    416f:	c1 e7 03             	shl    di,0x3
    4172:	03 f9                	add    di,cx
    4174:	ff b3 f2 fb          	push   WORD PTR [bp+di-0x40e]
    4178:	ff b3 f0 fb          	push   WORD PTR [bp+di-0x410]
    417c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    417f:	99                   	cwd
    4180:	bf da 1f             	mov    di,0x1fda
    4183:	9a 16 04 97 41       	call   0x4197:0x416
    4188:	c1 e0 02             	shl    ax,0x2
    418b:	8b c8                	mov    cx,ax
    418d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4190:	99                   	cwd
    4191:	bf d2 1f             	mov    di,0x1fd2
    4194:	9a 16 04 b6 41       	call   0x41b6:0x416
    4199:	8b f8                	mov    di,ax
    419b:	c1 e7 03             	shl    di,0x3
    419e:	03 f9                	add    di,cx
    41a0:	58                   	pop    ax
    41a1:	5a                   	pop    dx
    41a2:	89 83 4c f8          	mov    WORD PTR [bp+di-0x7b4],ax
    41a6:	89 93 4e f8          	mov    WORD PTR [bp+di-0x7b2],dx
    41aa:	eb 47                	jmp    0x41f3
    41ac:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    41af:	99                   	cwd
    41b0:	bf d2 1f             	mov    di,0x1fd2
    41b3:	9a 16 04 cf 41       	call   0x41cf:0x416
    41b8:	8b f8                	mov    di,ax
    41ba:	c1 e7 02             	shl    di,0x2
    41bd:	ff b3 12 f6          	push   WORD PTR [bp+di-0x9ee]
    41c1:	ff b3 10 f6          	push   WORD PTR [bp+di-0x9f0]
    41c5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    41c8:	99                   	cwd
    41c9:	bf da 1f             	mov    di,0x1fda
    41cc:	9a 16 04 e0 41       	call   0x41e0:0x416
    41d1:	c1 e0 02             	shl    ax,0x2
    41d4:	8b c8                	mov    cx,ax
    41d6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    41d9:	99                   	cwd
    41da:	bf d2 1f             	mov    di,0x1fd2
    41dd:	9a 16 04 fd 41       	call   0x41fd:0x416
    41e2:	8b f8                	mov    di,ax
    41e4:	c1 e7 03             	shl    di,0x3
    41e7:	03 f9                	add    di,cx
    41e9:	58                   	pop    ax
    41ea:	5a                   	pop    dx
    41eb:	89 83 4c f8          	mov    WORD PTR [bp+di-0x7b4],ax
    41ef:	89 93 4e f8          	mov    WORD PTR [bp+di-0x7b2],dx
    41f3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    41f6:	99                   	cwd
    41f7:	bf da 1f             	mov    di,0x1fda
    41fa:	9a 16 04 0e 42       	call   0x420e:0x416
    41ff:	c1 e0 02             	shl    ax,0x2
    4202:	8b c8                	mov    cx,ax
    4204:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4207:	99                   	cwd
    4208:	bf d2 1f             	mov    di,0x1fd2
    420b:	9a 16 04 31 42       	call   0x4231:0x416
    4210:	8b f8                	mov    di,ax
    4212:	c1 e7 03             	shl    di,0x3
    4215:	03 f9                	add    di,cx
    4217:	83 bb 4e f8 00       	cmp    WORD PTR [bp+di-0x7b2],0x0
    421c:	7f 09                	jg     0x4227
    421e:	7c 4a                	jl     0x426a
    4220:	83 bb 4c f8 00       	cmp    WORD PTR [bp+di-0x7b4],0x0
    4225:	76 43                	jbe    0x426a
    4227:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    422a:	99                   	cwd
    422b:	bf da 1f             	mov    di,0x1fda
    422e:	9a 16 04 47 42       	call   0x4247:0x416
    4233:	8b f8                	mov    di,ax
    4235:	c1 e7 03             	shl    di,0x3
    4238:	9b dd 83 00 f9       	fld    QWORD PTR [bp+di-0x700]
    423d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4240:	99                   	cwd
    4241:	bf da 1f             	mov    di,0x1fda
    4244:	9a 16 04 58 42       	call   0x4258:0x416
    4249:	c1 e0 03             	shl    ax,0x3
    424c:	8b c8                	mov    cx,ax
    424e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4251:	99                   	cwd
    4252:	bf d2 1f             	mov    di,0x1fd2
    4255:	9a 16 04 7a 42       	call   0x427a:0x416
    425a:	8b f8                	mov    di,ax
    425c:	c1 e7 04             	shl    di,0x4
    425f:	03 f9                	add    di,cx
    4261:	9b dd 9b c0 f7       	fstp   QWORD PTR [bp+di-0x840]
    4266:	90                   	nop
    4267:	9b                   	fwait
    4268:	eb 31                	jmp    0x429b
    426a:	9b 2e d9 06 e2 1f    	fld    DWORD PTR cs:0x1fe2
    4270:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4273:	99                   	cwd
    4274:	bf da 1f             	mov    di,0x1fda
    4277:	9a 16 04 8b 42       	call   0x428b:0x416
    427c:	c1 e0 03             	shl    ax,0x3
    427f:	8b c8                	mov    cx,ax
    4281:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4284:	99                   	cwd
    4285:	bf d2 1f             	mov    di,0x1fd2
    4288:	9a 16 04 a5 42       	call   0x42a5:0x416
    428d:	8b f8                	mov    di,ax
    428f:	c1 e7 04             	shl    di,0x4
    4292:	03 f9                	add    di,cx
    4294:	9b dd 9b c0 f7       	fstp   QWORD PTR [bp+di-0x840]
    4299:	90                   	nop
    429a:	9b                   	fwait
    429b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    429e:	99                   	cwd
    429f:	bf da 1f             	mov    di,0x1fda
    42a2:	9a 16 04 b6 42       	call   0x42b6:0x416
    42a7:	c1 e0 02             	shl    ax,0x2
    42aa:	8b c8                	mov    cx,ax
    42ac:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    42af:	99                   	cwd
    42b0:	bf d2 1f             	mov    di,0x1fd2
    42b3:	9a 16 04 d1 42       	call   0x42d1:0x416
    42b8:	8b f8                	mov    di,ax
    42ba:	c1 e7 03             	shl    di,0x3
    42bd:	03 f9                	add    di,cx
    42bf:	8b 8b 4c f8          	mov    cx,WORD PTR [bp+di-0x7b4]
    42c3:	8b 9b 4e f8          	mov    bx,WORD PTR [bp+di-0x7b2]
    42c7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    42ca:	99                   	cwd
    42cb:	bf d2 1f             	mov    di,0x1fd2
    42ce:	9a 16 04 e9 42       	call   0x42e9:0x416
    42d3:	8b f8                	mov    di,ax
    42d5:	c1 e7 02             	shl    di,0x2
    42d8:	8b 83 40 fc          	mov    ax,WORD PTR [bp+di-0x3c0]
    42dc:	8b 93 42 fc          	mov    dx,WORD PTR [bp+di-0x3be]
    42e0:	2b c1                	sub    ax,cx
    42e2:	1b d3                	sbb    dx,bx
    42e4:	71 05                	jno    0x42eb
    42e6:	9a 3e 04 f9 42       	call   0x42f9:0x43e
    42eb:	8b c8                	mov    cx,ax
    42ed:	8b da                	mov    bx,dx
    42ef:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    42f2:	99                   	cwd
    42f3:	bf d2 1f             	mov    di,0x1fd2
    42f6:	9a 16 04 1e 43       	call   0x431e:0x416
    42fb:	8b f8                	mov    di,ax
    42fd:	c1 e7 02             	shl    di,0x2
    4300:	89 8b 40 fc          	mov    WORD PTR [bp+di-0x3c0],cx
    4304:	89 9b 42 fc          	mov    WORD PTR [bp+di-0x3be],bx
    4308:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    430b:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    430f:	74 03                	je     0x4314
    4311:	e9 ea fd             	jmp    0x40fe
    4314:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4317:	99                   	cwd
    4318:	bf da 1f             	mov    di,0x1fda
    431b:	9a 16 04 5a 43       	call   0x435a:0x416
    4320:	8b f8                	mov    di,ax
    4322:	c1 e7 02             	shl    di,0x2
    4325:	8b 83 44 f6          	mov    ax,WORD PTR [bp+di-0x9bc]
    4329:	8b 93 46 f6          	mov    dx,WORD PTR [bp+di-0x9ba]
    432d:	89 86 34 f6          	mov    WORD PTR [bp-0x9cc],ax
    4331:	89 96 36 f6          	mov    WORD PTR [bp-0x9ca],dx
    4335:	a1 4e 01             	mov    ax,ds:0x14e
    4338:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    433c:	b8 01 00             	mov    ax,0x1
    433f:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4343:	7f 28                	jg     0x436d
    4345:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4348:	eb 03                	jmp    0x434d
    434a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    434d:	8b 4e fe             	mov    cx,WORD PTR [bp-0x2]
    4350:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4353:	99                   	cwd
    4354:	bf d2 1f             	mov    di,0x1fd2
    4357:	9a 16 04 78 43       	call   0x4378:0x416
    435c:	8b f8                	mov    di,ax
    435e:	d1 e7                	shl    di,1
    4360:	89 8b 16 f4          	mov    WORD PTR [bp+di-0xbea],cx
    4364:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4367:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    436b:	75 dd                	jne    0x434a
    436d:	a1 4e 01             	mov    ax,ds:0x14e
    4370:	2d 01 00             	sub    ax,0x1
    4373:	71 05                	jno    0x437a
    4375:	9a 3e 04 a7 43       	call   0x43a7:0x43e
    437a:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    437e:	b8 01 00             	mov    ax,0x1
    4381:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4385:	7e 03                	jle    0x438a
    4387:	e9 fd 01             	jmp    0x4587
    438a:	89 86 16 f4          	mov    WORD PTR [bp-0xbea],ax
    438e:	eb 04                	jmp    0x4394
    4390:	ff 86 16 f4          	inc    WORD PTR [bp-0xbea]
    4394:	a1 4e 01             	mov    ax,ds:0x14e
    4397:	89 86 70 f1          	mov    WORD PTR [bp-0xe90],ax
    439b:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    439f:	05 01 00             	add    ax,0x1
    43a2:	71 05                	jno    0x43a9
    43a4:	9a 3e 04 c6 43       	call   0x43c6:0x43e
    43a9:	3b 86 70 f1          	cmp    ax,WORD PTR [bp-0xe90]
    43ad:	7e 03                	jle    0x43b2
    43af:	e9 c8 01             	jmp    0x457a
    43b2:	89 86 14 f4          	mov    WORD PTR [bp-0xbec],ax
    43b6:	eb 04                	jmp    0x43bc
    43b8:	ff 86 14 f4          	inc    WORD PTR [bp-0xbec]
    43bc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    43bf:	99                   	cwd
    43c0:	bf da 1f             	mov    di,0x1fda
    43c3:	9a 16 04 d8 43       	call   0x43d8:0x416
    43c8:	c1 e0 03             	shl    ax,0x3
    43cb:	8b c8                	mov    cx,ax
    43cd:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    43d1:	99                   	cwd
    43d2:	bf d2 1f             	mov    di,0x1fd2
    43d5:	9a 16 04 e9 43       	call   0x43e9:0x416
    43da:	8b f8                	mov    di,ax
    43dc:	d1 e7                	shl    di,1
    43de:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    43e2:	99                   	cwd
    43e3:	bf d2 1f             	mov    di,0x1fd2
    43e6:	9a 16 04 01 44       	call   0x4401:0x416
    43eb:	8b f8                	mov    di,ax
    43ed:	c1 e7 04             	shl    di,0x4
    43f0:	03 f9                	add    di,cx
    43f2:	9b dd 83 dc fc       	fld    QWORD PTR [bp+di-0x324]
    43f7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    43fa:	99                   	cwd
    43fb:	bf da 1f             	mov    di,0x1fda
    43fe:	9a 16 04 13 44       	call   0x4413:0x416
    4403:	c1 e0 03             	shl    ax,0x3
    4406:	8b c8                	mov    cx,ax
    4408:	8b 86 14 f4          	mov    ax,WORD PTR [bp-0xbec]
    440c:	99                   	cwd
    440d:	bf d2 1f             	mov    di,0x1fd2
    4410:	9a 16 04 24 44       	call   0x4424:0x416
    4415:	8b f8                	mov    di,ax
    4417:	d1 e7                	shl    di,1
    4419:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    441d:	99                   	cwd
    441e:	bf d2 1f             	mov    di,0x1fd2
    4421:	9a 16 04 50 44       	call   0x4450:0x416
    4426:	8b f8                	mov    di,ax
    4428:	c1 e7 04             	shl    di,0x4
    442b:	03 f9                	add    di,cx
    442d:	9b dc 9b dc fc       	fcomp  QWORD PTR [bp+di-0x324]
    4432:	9b dd be 6a f1       	fstsw  WORD PTR [bp-0xe96]
    4437:	90                   	nop
    4438:	9b                   	fwait
    4439:	8a a6 6b f1          	mov    ah,BYTE PTR [bp-0xe95]
    443d:	9e                   	sahf
    443e:	b0 00                	mov    al,0x0
    4440:	73 01                	jae    0x4443
    4442:	40                   	inc    ax
    4443:	8a c8                	mov    cl,al
    4445:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4449:	99                   	cwd
    444a:	bf d2 1f             	mov    di,0x1fd2
    444d:	9a 16 04 61 44       	call   0x4461:0x416
    4452:	8b f8                	mov    di,ax
    4454:	d1 e7                	shl    di,1
    4456:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    445a:	99                   	cwd
    445b:	bf d2 1f             	mov    di,0x1fd2
    445e:	9a 16 04 78 44       	call   0x4478:0x416
    4463:	8b f8                	mov    di,ax
    4465:	c1 e7 03             	shl    di,0x3
    4468:	9b dd 83 ac f5       	fld    QWORD PTR [bp+di-0xa54]
    446d:	8b 86 14 f4          	mov    ax,WORD PTR [bp-0xbec]
    4471:	99                   	cwd
    4472:	bf d2 1f             	mov    di,0x1fd2
    4475:	9a 16 04 89 44       	call   0x4489:0x416
    447a:	8b f8                	mov    di,ax
    447c:	d1 e7                	shl    di,1
    447e:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    4482:	99                   	cwd
    4483:	bf d2 1f             	mov    di,0x1fd2
    4486:	9a 16 04 b5 44       	call   0x44b5:0x416
    448b:	8b f8                	mov    di,ax
    448d:	c1 e7 03             	shl    di,0x3
    4490:	9b dc 9b ac f5       	fcomp  QWORD PTR [bp+di-0xa54]
    4495:	9b dd be 6c f1       	fstsw  WORD PTR [bp-0xe94]
    449a:	90                   	nop
    449b:	9b                   	fwait
    449c:	8a a6 6d f1          	mov    ah,BYTE PTR [bp-0xe93]
    44a0:	9e                   	sahf
    44a1:	b0 00                	mov    al,0x0
    44a3:	75 01                	jne    0x44a6
    44a5:	40                   	inc    ax
    44a6:	22 c1                	and    al,cl
    44a8:	8a c8                	mov    cl,al
    44aa:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    44ae:	99                   	cwd
    44af:	bf d2 1f             	mov    di,0x1fd2
    44b2:	9a 16 04 c6 44       	call   0x44c6:0x416
    44b7:	8b f8                	mov    di,ax
    44b9:	d1 e7                	shl    di,1
    44bb:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    44bf:	99                   	cwd
    44c0:	bf d2 1f             	mov    di,0x1fd2
    44c3:	9a 16 04 dd 44       	call   0x44dd:0x416
    44c8:	8b f8                	mov    di,ax
    44ca:	c1 e7 03             	shl    di,0x3
    44cd:	9b dd 83 ac f5       	fld    QWORD PTR [bp+di-0xa54]
    44d2:	8b 86 14 f4          	mov    ax,WORD PTR [bp-0xbec]
    44d6:	99                   	cwd
    44d7:	bf d2 1f             	mov    di,0x1fd2
    44da:	9a 16 04 ee 44       	call   0x44ee:0x416
    44df:	8b f8                	mov    di,ax
    44e1:	d1 e7                	shl    di,1
    44e3:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    44e7:	99                   	cwd
    44e8:	bf d2 1f             	mov    di,0x1fd2
    44eb:	9a 16 04 1c 45       	call   0x451c:0x416
    44f0:	8b f8                	mov    di,ax
    44f2:	c1 e7 03             	shl    di,0x3
    44f5:	9b dc 9b ac f5       	fcomp  QWORD PTR [bp+di-0xa54]
    44fa:	9b dd be 6e f1       	fstsw  WORD PTR [bp-0xe92]
    44ff:	90                   	nop
    4500:	9b                   	fwait
    4501:	8a a6 6f f1          	mov    ah,BYTE PTR [bp-0xe91]
    4505:	9e                   	sahf
    4506:	b0 00                	mov    al,0x0
    4508:	76 01                	jbe    0x450b
    450a:	40                   	inc    ax
    450b:	0a c1                	or     al,cl
    450d:	08 c0                	or     al,al
    450f:	74 5c                	je     0x456d
    4511:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4515:	99                   	cwd
    4516:	bf d2 1f             	mov    di,0x1fd2
    4519:	9a 16 04 35 45       	call   0x4535:0x416
    451e:	8b f8                	mov    di,ax
    4520:	d1 e7                	shl    di,1
    4522:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    4526:	89 86 12 f4          	mov    WORD PTR [bp-0xbee],ax
    452a:	8b 86 14 f4          	mov    ax,WORD PTR [bp-0xbec]
    452e:	99                   	cwd
    452f:	bf d2 1f             	mov    di,0x1fd2
    4532:	9a 16 04 4a 45       	call   0x454a:0x416
    4537:	8b f8                	mov    di,ax
    4539:	d1 e7                	shl    di,1
    453b:	8b 8b 16 f4          	mov    cx,WORD PTR [bp+di-0xbea]
    453f:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4543:	99                   	cwd
    4544:	bf d2 1f             	mov    di,0x1fd2
    4547:	9a 16 04 63 45       	call   0x4563:0x416
    454c:	8b f8                	mov    di,ax
    454e:	d1 e7                	shl    di,1
    4550:	89 8b 16 f4          	mov    WORD PTR [bp+di-0xbea],cx
    4554:	8b 8e 12 f4          	mov    cx,WORD PTR [bp-0xbee]
    4558:	8b 86 14 f4          	mov    ax,WORD PTR [bp-0xbec]
    455c:	99                   	cwd
    455d:	bf d2 1f             	mov    di,0x1fd2
    4560:	9a 16 04 af 45       	call   0x45af:0x416
    4565:	8b f8                	mov    di,ax
    4567:	d1 e7                	shl    di,1
    4569:	89 8b 16 f4          	mov    WORD PTR [bp+di-0xbea],cx
    456d:	8b 86 14 f4          	mov    ax,WORD PTR [bp-0xbec]
    4571:	3b 86 70 f1          	cmp    ax,WORD PTR [bp-0xe90]
    4575:	74 03                	je     0x457a
    4577:	e9 3e fe             	jmp    0x43b8
    457a:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    457e:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4582:	74 03                	je     0x4587
    4584:	e9 09 fe             	jmp    0x4390
    4587:	a1 4e 01             	mov    ax,ds:0x14e
    458a:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    458e:	b8 01 00             	mov    ax,0x1
    4591:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4595:	7e 03                	jle    0x459a
    4597:	e9 01 04             	jmp    0x499b
    459a:	89 86 16 f4          	mov    WORD PTR [bp-0xbea],ax
    459e:	eb 04                	jmp    0x45a4
    45a0:	ff 86 16 f4          	inc    WORD PTR [bp-0xbea]
    45a4:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    45a8:	99                   	cwd
    45a9:	bf d2 1f             	mov    di,0x1fd2
    45ac:	9a 16 04 c0 45       	call   0x45c0:0x416
    45b1:	8b f8                	mov    di,ax
    45b3:	d1 e7                	shl    di,1
    45b5:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    45b9:	99                   	cwd
    45ba:	bf d2 1f             	mov    di,0x1fd2
    45bd:	9a 16 04 e2 45       	call   0x45e2:0x416
    45c2:	8b f8                	mov    di,ax
    45c4:	c1 e7 02             	shl    di,0x2
    45c7:	8b 83 f0 f5          	mov    ax,WORD PTR [bp+di-0xa10]
    45cb:	8b 93 f2 f5          	mov    dx,WORD PTR [bp+di-0xa0e]
    45cf:	89 86 b0 f5          	mov    WORD PTR [bp-0xa50],ax
    45d3:	89 96 b2 f5          	mov    WORD PTR [bp-0xa4e],dx
    45d7:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    45db:	99                   	cwd
    45dc:	bf d2 1f             	mov    di,0x1fd2
    45df:	9a 16 04 f3 45       	call   0x45f3:0x416
    45e4:	8b f8                	mov    di,ax
    45e6:	d1 e7                	shl    di,1
    45e8:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    45ec:	99                   	cwd
    45ed:	bf d2 1f             	mov    di,0x1fd2
    45f0:	9a 16 04 1b 46       	call   0x461b:0x416
    45f5:	8b f8                	mov    di,ax
    45f7:	c1 e7 02             	shl    di,0x2
    45fa:	8b 83 40 fc          	mov    ax,WORD PTR [bp+di-0x3c0]
    45fe:	8b 93 42 fc          	mov    dx,WORD PTR [bp+di-0x3be]
    4602:	3b 96 b2 f5          	cmp    dx,WORD PTR [bp-0xa4e]
    4606:	7c 08                	jl     0x4610
    4608:	7f 39                	jg     0x4643
    460a:	3b 86 b0 f5          	cmp    ax,WORD PTR [bp-0xa50]
    460e:	73 33                	jae    0x4643
    4610:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4614:	99                   	cwd
    4615:	bf d2 1f             	mov    di,0x1fd2
    4618:	9a 16 04 2c 46       	call   0x462c:0x416
    461d:	8b f8                	mov    di,ax
    461f:	d1 e7                	shl    di,1
    4621:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    4625:	99                   	cwd
    4626:	bf d2 1f             	mov    di,0x1fd2
    4629:	9a 16 04 4e 46       	call   0x464e:0x416
    462e:	8b f8                	mov    di,ax
    4630:	c1 e7 02             	shl    di,0x2
    4633:	8b 83 40 fc          	mov    ax,WORD PTR [bp+di-0x3c0]
    4637:	8b 93 42 fc          	mov    dx,WORD PTR [bp+di-0x3be]
    463b:	89 86 b0 f5          	mov    WORD PTR [bp-0xa50],ax
    463f:	89 96 b2 f5          	mov    WORD PTR [bp-0xa4e],dx
    4643:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4647:	99                   	cwd
    4648:	bf d2 1f             	mov    di,0x1fd2
    464b:	9a 16 04 5f 46       	call   0x465f:0x416
    4650:	8b f8                	mov    di,ax
    4652:	d1 e7                	shl    di,1
    4654:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    4658:	99                   	cwd
    4659:	bf d2 1f             	mov    di,0x1fd2
    465c:	9a 16 04 7c 46       	call   0x467c:0x416
    4661:	8b f8                	mov    di,ax
    4663:	c1 e7 03             	shl    di,0x3
    4666:	9b dd 83 ac f5       	fld    QWORD PTR [bp+di-0xa54]
    466b:	9b dd 9e a8 f5       	fstp   QWORD PTR [bp-0xa58]
    4670:	90                   	nop
    4671:	9b                   	fwait
    4672:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4675:	99                   	cwd
    4676:	bf da 1f             	mov    di,0x1fda
    4679:	9a 16 04 8e 46       	call   0x468e:0x416
    467e:	c1 e0 02             	shl    ax,0x2
    4681:	8b c8                	mov    cx,ax
    4683:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4687:	99                   	cwd
    4688:	bf d2 1f             	mov    di,0x1fd2
    468b:	9a 16 04 9f 46       	call   0x469f:0x416
    4690:	8b f8                	mov    di,ax
    4692:	d1 e7                	shl    di,1
    4694:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    4698:	99                   	cwd
    4699:	bf d2 1f             	mov    di,0x1fd2
    469c:	9a 16 04 c2 46       	call   0x46c2:0x416
    46a1:	8b f8                	mov    di,ax
    46a3:	c1 e7 03             	shl    di,0x3
    46a6:	03 f9                	add    di,cx
    46a8:	31 c0                	xor    ax,ax
    46aa:	89 83 8c f7          	mov    WORD PTR [bp+di-0x874],ax
    46ae:	89 83 8e f7          	mov    WORD PTR [bp+di-0x872],ax
    46b2:	9b 2e d9 06 df 1f    	fld    DWORD PTR cs:0x1fdf
    46b8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    46bb:	99                   	cwd
    46bc:	bf da 1f             	mov    di,0x1fda
    46bf:	9a 16 04 d4 46       	call   0x46d4:0x416
    46c4:	c1 e0 03             	shl    ax,0x3
    46c7:	8b c8                	mov    cx,ax
    46c9:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    46cd:	99                   	cwd
    46ce:	bf d2 1f             	mov    di,0x1fd2
    46d1:	9a 16 04 e5 46       	call   0x46e5:0x416
    46d6:	8b f8                	mov    di,ax
    46d8:	d1 e7                	shl    di,1
    46da:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    46de:	99                   	cwd
    46df:	bf d2 1f             	mov    di,0x1fd2
    46e2:	9a 16 04 22 47       	call   0x4722:0x416
    46e7:	8b f8                	mov    di,ax
    46e9:	c1 e7 04             	shl    di,0x4
    46ec:	03 f9                	add    di,cx
    46ee:	9b dd 9b 00 f7       	fstp   QWORD PTR [bp+di-0x900]
    46f3:	90                   	nop
    46f4:	9b 9b dd 86 a8 f5    	fld    QWORD PTR [bp-0xa58]
    46fa:	9b 2e d8 1e df 1f    	fcomp  DWORD PTR cs:0x1fdf
    4700:	9b dd be 6e f1       	fstsw  WORD PTR [bp-0xe92]
    4705:	90                   	nop
    4706:	9b                   	fwait
    4707:	8a a6 6f f1          	mov    ah,BYTE PTR [bp-0xe91]
    470b:	9e                   	sahf
    470c:	b0 00                	mov    al,0x0
    470e:	76 01                	jbe    0x4711
    4710:	40                   	inc    ax
    4711:	8a c8                	mov    cl,al
    4713:	9b dd 86 a8 f5       	fld    QWORD PTR [bp-0xa58]
    4718:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    471b:	99                   	cwd
    471c:	bf da 1f             	mov    di,0x1fda
    471f:	9a 16 04 8a 47       	call   0x478a:0x416
    4724:	8b f8                	mov    di,ax
    4726:	c1 e7 03             	shl    di,0x3
    4729:	9b dc 9b 30 f6       	fcomp  QWORD PTR [bp+di-0x9d0]
    472e:	9b dd be 70 f1       	fstsw  WORD PTR [bp-0xe90]
    4733:	90                   	nop
    4734:	9b                   	fwait
    4735:	8a a6 71 f1          	mov    ah,BYTE PTR [bp-0xe8f]
    4739:	9e                   	sahf
    473a:	b0 00                	mov    al,0x0
    473c:	77 01                	ja     0x473f
    473e:	40                   	inc    ax
    473f:	8a d0                	mov    dl,al
    4741:	83 be b2 f5 00       	cmp    WORD PTR [bp-0xa4e],0x0
    4746:	7f 0d                	jg     0x4755
    4748:	7c 07                	jl     0x4751
    474a:	83 be b0 f5 00       	cmp    WORD PTR [bp-0xa50],0x0
    474f:	77 04                	ja     0x4755
    4751:	b0 00                	mov    al,0x0
    4753:	eb 02                	jmp    0x4757
    4755:	b0 01                	mov    al,0x1
    4757:	22 c2                	and    al,dl
    4759:	22 c1                	and    al,cl
    475b:	08 c0                	or     al,al
    475d:	75 03                	jne    0x4762
    475f:	e9 a8 00             	jmp    0x480a
    4762:	8b 86 b0 f5          	mov    ax,WORD PTR [bp-0xa50]
    4766:	8b 96 b2 f5          	mov    dx,WORD PTR [bp-0xa4e]
    476a:	3b 96 36 f6          	cmp    dx,WORD PTR [bp-0x9ca]
    476e:	7c 08                	jl     0x4778
    4770:	7f 50                	jg     0x47c2
    4772:	3b 86 34 f6          	cmp    ax,WORD PTR [bp-0x9cc]
    4776:	77 4a                	ja     0x47c2
    4778:	ff b6 b2 f5          	push   WORD PTR [bp-0xa4e]
    477c:	ff b6 b0 f5          	push   WORD PTR [bp-0xa50]
    4780:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4783:	99                   	cwd
    4784:	bf da 1f             	mov    di,0x1fda
    4787:	9a 16 04 9c 47       	call   0x479c:0x416
    478c:	c1 e0 02             	shl    ax,0x2
    478f:	8b c8                	mov    cx,ax
    4791:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4795:	99                   	cwd
    4796:	bf d2 1f             	mov    di,0x1fd2
    4799:	9a 16 04 ad 47       	call   0x47ad:0x416
    479e:	8b f8                	mov    di,ax
    47a0:	d1 e7                	shl    di,1
    47a2:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    47a6:	99                   	cwd
    47a7:	bf d2 1f             	mov    di,0x1fd2
    47aa:	9a 16 04 d4 47       	call   0x47d4:0x416
    47af:	8b f8                	mov    di,ax
    47b1:	c1 e7 03             	shl    di,0x3
    47b4:	03 f9                	add    di,cx
    47b6:	58                   	pop    ax
    47b7:	5a                   	pop    dx
    47b8:	89 83 8c f7          	mov    WORD PTR [bp+di-0x874],ax
    47bc:	89 93 8e f7          	mov    WORD PTR [bp+di-0x872],dx
    47c0:	eb 48                	jmp    0x480a
    47c2:	ff b6 36 f6          	push   WORD PTR [bp-0x9ca]
    47c6:	ff b6 34 f6          	push   WORD PTR [bp-0x9cc]
    47ca:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    47cd:	99                   	cwd
    47ce:	bf da 1f             	mov    di,0x1fda
    47d1:	9a 16 04 e6 47       	call   0x47e6:0x416
    47d6:	c1 e0 02             	shl    ax,0x2
    47d9:	8b c8                	mov    cx,ax
    47db:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    47df:	99                   	cwd
    47e0:	bf d2 1f             	mov    di,0x1fd2
    47e3:	9a 16 04 f7 47       	call   0x47f7:0x416
    47e8:	8b f8                	mov    di,ax
    47ea:	d1 e7                	shl    di,1
    47ec:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    47f0:	99                   	cwd
    47f1:	bf d2 1f             	mov    di,0x1fd2
    47f4:	9a 16 04 14 48       	call   0x4814:0x416
    47f9:	8b f8                	mov    di,ax
    47fb:	c1 e7 03             	shl    di,0x3
    47fe:	03 f9                	add    di,cx
    4800:	58                   	pop    ax
    4801:	5a                   	pop    dx
    4802:	89 83 8c f7          	mov    WORD PTR [bp+di-0x874],ax
    4806:	89 93 8e f7          	mov    WORD PTR [bp+di-0x872],dx
    480a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    480d:	99                   	cwd
    480e:	bf da 1f             	mov    di,0x1fda
    4811:	9a 16 04 26 48       	call   0x4826:0x416
    4816:	c1 e0 02             	shl    ax,0x2
    4819:	8b c8                	mov    cx,ax
    481b:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    481f:	99                   	cwd
    4820:	bf d2 1f             	mov    di,0x1fd2
    4823:	9a 16 04 37 48       	call   0x4837:0x416
    4828:	8b f8                	mov    di,ax
    482a:	d1 e7                	shl    di,1
    482c:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    4830:	99                   	cwd
    4831:	bf d2 1f             	mov    di,0x1fd2
    4834:	9a 16 04 5f 48       	call   0x485f:0x416
    4839:	8b f8                	mov    di,ax
    483b:	c1 e7 03             	shl    di,0x3
    483e:	03 f9                	add    di,cx
    4840:	83 bb 8e f7 00       	cmp    WORD PTR [bp+di-0x872],0x0
    4845:	7f 09                	jg     0x4850
    4847:	7c 49                	jl     0x4892
    4849:	83 bb 8c f7 00       	cmp    WORD PTR [bp+di-0x874],0x0
    484e:	76 42                	jbe    0x4892
    4850:	9b dd 86 a8 f5       	fld    QWORD PTR [bp-0xa58]
    4855:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4858:	99                   	cwd
    4859:	bf da 1f             	mov    di,0x1fda
    485c:	9a 16 04 71 48       	call   0x4871:0x416
    4861:	c1 e0 03             	shl    ax,0x3
    4864:	8b c8                	mov    cx,ax
    4866:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    486a:	99                   	cwd
    486b:	bf d2 1f             	mov    di,0x1fd2
    486e:	9a 16 04 82 48       	call   0x4882:0x416
    4873:	8b f8                	mov    di,ax
    4875:	d1 e7                	shl    di,1
    4877:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    487b:	99                   	cwd
    487c:	bf d2 1f             	mov    di,0x1fd2
    487f:	9a 16 04 9c 48       	call   0x489c:0x416
    4884:	8b f8                	mov    di,ax
    4886:	c1 e7 04             	shl    di,0x4
    4889:	03 f9                	add    di,cx
    488b:	9b dd 9b 00 f7       	fstp   QWORD PTR [bp+di-0x900]
    4890:	90                   	nop
    4891:	9b                   	fwait
    4892:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4895:	99                   	cwd
    4896:	bf da 1f             	mov    di,0x1fda
    4899:	9a 16 04 ae 48       	call   0x48ae:0x416
    489e:	c1 e0 02             	shl    ax,0x2
    48a1:	8b c8                	mov    cx,ax
    48a3:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    48a7:	99                   	cwd
    48a8:	bf d2 1f             	mov    di,0x1fd2
    48ab:	9a 16 04 bf 48       	call   0x48bf:0x416
    48b0:	8b f8                	mov    di,ax
    48b2:	d1 e7                	shl    di,1
    48b4:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    48b8:	99                   	cwd
    48b9:	bf d2 1f             	mov    di,0x1fd2
    48bc:	9a 16 04 e1 48       	call   0x48e1:0x416
    48c1:	8b f8                	mov    di,ax
    48c3:	c1 e7 03             	shl    di,0x3
    48c6:	03 f9                	add    di,cx
    48c8:	8b 8b 8c f7          	mov    cx,WORD PTR [bp+di-0x874]
    48cc:	8b 9b 8e f7          	mov    bx,WORD PTR [bp+di-0x872]
    48d0:	8b 86 34 f6          	mov    ax,WORD PTR [bp-0x9cc]
    48d4:	8b 96 36 f6          	mov    dx,WORD PTR [bp-0x9ca]
    48d8:	2b c1                	sub    ax,cx
    48da:	1b d3                	sbb    dx,bx
    48dc:	71 05                	jno    0x48e3
    48de:	9a 3e 04 f5 48       	call   0x48f5:0x43e
    48e3:	89 86 34 f6          	mov    WORD PTR [bp-0x9cc],ax
    48e7:	89 96 36 f6          	mov    WORD PTR [bp-0x9ca],dx
    48eb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    48ee:	99                   	cwd
    48ef:	bf da 1f             	mov    di,0x1fda
    48f2:	9a 16 04 07 49       	call   0x4907:0x416
    48f7:	c1 e0 02             	shl    ax,0x2
    48fa:	8b c8                	mov    cx,ax
    48fc:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4900:	99                   	cwd
    4901:	bf d2 1f             	mov    di,0x1fd2
    4904:	9a 16 04 18 49       	call   0x4918:0x416
    4909:	8b f8                	mov    di,ax
    490b:	d1 e7                	shl    di,1
    490d:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    4911:	99                   	cwd
    4912:	bf d2 1f             	mov    di,0x1fd2
    4915:	9a 16 04 34 49       	call   0x4934:0x416
    491a:	8b f8                	mov    di,ax
    491c:	c1 e7 03             	shl    di,0x3
    491f:	03 f9                	add    di,cx
    4921:	8b 8b 8c f7          	mov    cx,WORD PTR [bp+di-0x874]
    4925:	8b 9b 8e f7          	mov    bx,WORD PTR [bp+di-0x872]
    4929:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    492d:	99                   	cwd
    492e:	bf d2 1f             	mov    di,0x1fd2
    4931:	9a 16 04 45 49       	call   0x4945:0x416
    4936:	8b f8                	mov    di,ax
    4938:	d1 e7                	shl    di,1
    493a:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    493e:	99                   	cwd
    493f:	bf d2 1f             	mov    di,0x1fd2
    4942:	9a 16 04 5d 49       	call   0x495d:0x416
    4947:	8b f8                	mov    di,ax
    4949:	c1 e7 02             	shl    di,0x2
    494c:	8b 83 40 fc          	mov    ax,WORD PTR [bp+di-0x3c0]
    4950:	8b 93 42 fc          	mov    dx,WORD PTR [bp+di-0x3be]
    4954:	2b c1                	sub    ax,cx
    4956:	1b d3                	sbb    dx,bx
    4958:	71 05                	jno    0x495f
    495a:	9a 3e 04 6e 49       	call   0x496e:0x43e
    495f:	8b c8                	mov    cx,ax
    4961:	8b da                	mov    bx,dx
    4963:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4967:	99                   	cwd
    4968:	bf d2 1f             	mov    di,0x1fd2
    496b:	9a 16 04 7f 49       	call   0x497f:0x416
    4970:	8b f8                	mov    di,ax
    4972:	d1 e7                	shl    di,1
    4974:	8b 83 16 f4          	mov    ax,WORD PTR [bp+di-0xbea]
    4978:	99                   	cwd
    4979:	bf d2 1f             	mov    di,0x1fd2
    497c:	9a 16 04 c0 49       	call   0x49c0:0x416
    4981:	8b f8                	mov    di,ax
    4983:	c1 e7 02             	shl    di,0x2
    4986:	89 8b 40 fc          	mov    WORD PTR [bp+di-0x3c0],cx
    498a:	89 9b 42 fc          	mov    WORD PTR [bp+di-0x3be],bx
    498e:	8b 86 16 f4          	mov    ax,WORD PTR [bp-0xbea]
    4992:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4996:	74 03                	je     0x499b
    4998:	e9 05 fc             	jmp    0x45a0
    499b:	a1 4e 01             	mov    ax,ds:0x14e
    499e:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    49a2:	b8 01 00             	mov    ax,0x1
    49a5:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    49a9:	7e 03                	jle    0x49ae
    49ab:	e9 6d 02             	jmp    0x4c1b
    49ae:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    49b1:	eb 03                	jmp    0x49b6
    49b3:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    49b6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    49b9:	99                   	cwd
    49ba:	bf da 1f             	mov    di,0x1fda
    49bd:	9a 16 04 d1 49       	call   0x49d1:0x416
    49c2:	c1 e0 02             	shl    ax,0x2
    49c5:	8b c8                	mov    cx,ax
    49c7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    49ca:	99                   	cwd
    49cb:	bf d2 1f             	mov    di,0x1fd2
    49ce:	9a 16 04 ec 49       	call   0x49ec:0x416
    49d3:	8b f8                	mov    di,ax
    49d5:	c1 e7 03             	shl    di,0x3
    49d8:	03 f9                	add    di,cx
    49da:	8b 8b 6c fa          	mov    cx,WORD PTR [bp+di-0x594]
    49de:	8b 9b 6e fa          	mov    bx,WORD PTR [bp+di-0x592]
    49e2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    49e5:	99                   	cwd
    49e6:	bf d2 1f             	mov    di,0x1fd2
    49e9:	9a 16 04 15 4a       	call   0x4a15:0x416
    49ee:	8b f8                	mov    di,ax
    49f0:	c1 e7 02             	shl    di,0x2
    49f3:	8b 83 40 fc          	mov    ax,WORD PTR [bp+di-0x3c0]
    49f7:	8b 93 42 fc          	mov    dx,WORD PTR [bp+di-0x3be]
    49fb:	3b d3                	cmp    dx,bx
    49fd:	7c 0c                	jl     0x4a0b
    49ff:	7e 03                	jle    0x4a04
    4a01:	e9 d3 00             	jmp    0x4ad7
    4a04:	3b c1                	cmp    ax,cx
    4a06:	72 03                	jb     0x4a0b
    4a08:	e9 cc 00             	jmp    0x4ad7
    4a0b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4a0e:	99                   	cwd
    4a0f:	bf d2 1f             	mov    di,0x1fd2
    4a12:	9a 16 04 2e 4a       	call   0x4a2e:0x416
    4a17:	8b f8                	mov    di,ax
    4a19:	c1 e7 02             	shl    di,0x2
    4a1c:	ff b3 42 fc          	push   WORD PTR [bp+di-0x3be]
    4a20:	ff b3 40 fc          	push   WORD PTR [bp+di-0x3c0]
    4a24:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4a27:	99                   	cwd
    4a28:	bf da 1f             	mov    di,0x1fda
    4a2b:	9a 16 04 3f 4a       	call   0x4a3f:0x416
    4a30:	c1 e0 02             	shl    ax,0x2
    4a33:	8b c8                	mov    cx,ax
    4a35:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4a38:	99                   	cwd
    4a39:	bf d2 1f             	mov    di,0x1fd2
    4a3c:	9a 16 04 5c 4a       	call   0x4a5c:0x416
    4a41:	8b f8                	mov    di,ax
    4a43:	c1 e7 03             	shl    di,0x3
    4a46:	03 f9                	add    di,cx
    4a48:	58                   	pop    ax
    4a49:	5a                   	pop    dx
    4a4a:	89 83 68 f9          	mov    WORD PTR [bp+di-0x698],ax
    4a4e:	89 93 6a f9          	mov    WORD PTR [bp+di-0x696],dx
    4a52:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4a55:	99                   	cwd
    4a56:	bf d2 1f             	mov    di,0x1fd2
    4a59:	9a 16 04 75 4a       	call   0x4a75:0x416
    4a5e:	8b f8                	mov    di,ax
    4a60:	c1 e7 02             	shl    di,0x2
    4a63:	ff b3 42 fc          	push   WORD PTR [bp+di-0x3be]
    4a67:	ff b3 40 fc          	push   WORD PTR [bp+di-0x3c0]
    4a6b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4a6e:	99                   	cwd
    4a6f:	bf da 1f             	mov    di,0x1fda
    4a72:	9a 16 04 86 4a       	call   0x4a86:0x416
    4a77:	c1 e0 02             	shl    ax,0x2
    4a7a:	8b c8                	mov    cx,ax
    4a7c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4a7f:	99                   	cwd
    4a80:	bf d2 1f             	mov    di,0x1fd2
    4a83:	9a 16 04 a2 4a       	call   0x4aa2:0x416
    4a88:	8b f8                	mov    di,ax
    4a8a:	c1 e7 03             	shl    di,0x3
    4a8d:	03 f9                	add    di,cx
    4a8f:	8b 83 6c fa          	mov    ax,WORD PTR [bp+di-0x594]
    4a93:	8b 93 6e fa          	mov    dx,WORD PTR [bp+di-0x592]
    4a97:	59                   	pop    cx
    4a98:	5b                   	pop    bx
    4a99:	2b c1                	sub    ax,cx
    4a9b:	1b d3                	sbb    dx,bx
    4a9d:	71 05                	jno    0x4aa4
    4a9f:	9a 3e 04 b0 4a       	call   0x4ab0:0x43e
    4aa4:	52                   	push   dx
    4aa5:	50                   	push   ax
    4aa6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4aa9:	99                   	cwd
    4aaa:	bf da 1f             	mov    di,0x1fda
    4aad:	9a 16 04 c1 4a       	call   0x4ac1:0x416
    4ab2:	c1 e0 02             	shl    ax,0x2
    4ab5:	8b c8                	mov    cx,ax
    4ab7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4aba:	99                   	cwd
    4abb:	bf d2 1f             	mov    di,0x1fd2
    4abe:	9a 16 04 e1 4a       	call   0x4ae1:0x416
    4ac3:	8b f8                	mov    di,ax
    4ac5:	c1 e7 03             	shl    di,0x3
    4ac8:	03 f9                	add    di,cx
    4aca:	58                   	pop    ax
    4acb:	5a                   	pop    dx
    4acc:	89 83 28 fa          	mov    WORD PTR [bp+di-0x5d8],ax
    4ad0:	89 93 2a fa          	mov    WORD PTR [bp+di-0x5d6],dx
    4ad4:	e9 88 00             	jmp    0x4b5f
    4ad7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4ada:	99                   	cwd
    4adb:	bf da 1f             	mov    di,0x1fda
    4ade:	9a 16 04 f2 4a       	call   0x4af2:0x416
    4ae3:	c1 e0 02             	shl    ax,0x2
    4ae6:	8b c8                	mov    cx,ax
    4ae8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4aeb:	99                   	cwd
    4aec:	bf d2 1f             	mov    di,0x1fd2
    4aef:	9a 16 04 0d 4b       	call   0x4b0d:0x416
    4af4:	8b f8                	mov    di,ax
    4af6:	c1 e7 03             	shl    di,0x3
    4af9:	03 f9                	add    di,cx
    4afb:	ff b3 6e fa          	push   WORD PTR [bp+di-0x592]
    4aff:	ff b3 6c fa          	push   WORD PTR [bp+di-0x594]
    4b03:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4b06:	99                   	cwd
    4b07:	bf da 1f             	mov    di,0x1fda
    4b0a:	9a 16 04 1e 4b       	call   0x4b1e:0x416
    4b0f:	c1 e0 02             	shl    ax,0x2
    4b12:	8b c8                	mov    cx,ax
    4b14:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4b17:	99                   	cwd
    4b18:	bf d2 1f             	mov    di,0x1fd2
    4b1b:	9a 16 04 3b 4b       	call   0x4b3b:0x416
    4b20:	8b f8                	mov    di,ax
    4b22:	c1 e7 03             	shl    di,0x3
    4b25:	03 f9                	add    di,cx
    4b27:	58                   	pop    ax
    4b28:	5a                   	pop    dx
    4b29:	89 83 68 f9          	mov    WORD PTR [bp+di-0x698],ax
    4b2d:	89 93 6a f9          	mov    WORD PTR [bp+di-0x696],dx
    4b31:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4b34:	99                   	cwd
    4b35:	bf da 1f             	mov    di,0x1fda
    4b38:	9a 16 04 4c 4b       	call   0x4b4c:0x416
    4b3d:	c1 e0 02             	shl    ax,0x2
    4b40:	8b c8                	mov    cx,ax
    4b42:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4b45:	99                   	cwd
    4b46:	bf d2 1f             	mov    di,0x1fd2
    4b49:	9a 16 04 69 4b       	call   0x4b69:0x416
    4b4e:	8b f8                	mov    di,ax
    4b50:	c1 e7 03             	shl    di,0x3
    4b53:	03 f9                	add    di,cx
    4b55:	31 c0                	xor    ax,ax
    4b57:	89 83 28 fa          	mov    WORD PTR [bp+di-0x5d8],ax
    4b5b:	89 83 2a fa          	mov    WORD PTR [bp+di-0x5d6],ax
    4b5f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4b62:	99                   	cwd
    4b63:	bf da 1f             	mov    di,0x1fda
    4b66:	9a 16 04 7a 4b       	call   0x4b7a:0x416
    4b6b:	c1 e0 02             	shl    ax,0x2
    4b6e:	8b c8                	mov    cx,ax
    4b70:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4b73:	99                   	cwd
    4b74:	bf d2 1f             	mov    di,0x1fd2
    4b77:	9a 16 04 95 4b       	call   0x4b95:0x416
    4b7c:	8b f8                	mov    di,ax
    4b7e:	c1 e7 03             	shl    di,0x3
    4b81:	03 f9                	add    di,cx
    4b83:	8b 8b 68 f9          	mov    cx,WORD PTR [bp+di-0x698]
    4b87:	8b 9b 6a f9          	mov    bx,WORD PTR [bp+di-0x696]
    4b8b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4b8e:	99                   	cwd
    4b8f:	bf d2 1f             	mov    di,0x1fd2
    4b92:	9a 16 04 ad 4b       	call   0x4bad:0x416
    4b97:	8b f8                	mov    di,ax
    4b99:	c1 e7 02             	shl    di,0x2
    4b9c:	8b 83 40 fc          	mov    ax,WORD PTR [bp+di-0x3c0]
    4ba0:	8b 93 42 fc          	mov    dx,WORD PTR [bp+di-0x3be]
    4ba4:	2b c1                	sub    ax,cx
    4ba6:	1b d3                	sbb    dx,bx
    4ba8:	71 05                	jno    0x4baf
    4baa:	9a 3e 04 bd 4b       	call   0x4bbd:0x43e
    4baf:	8b c8                	mov    cx,ax
    4bb1:	8b da                	mov    bx,dx
    4bb3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4bb6:	99                   	cwd
    4bb7:	bf d2 1f             	mov    di,0x1fd2
    4bba:	9a 16 04 d6 4b       	call   0x4bd6:0x416
    4bbf:	8b f8                	mov    di,ax
    4bc1:	c1 e7 02             	shl    di,0x2
    4bc4:	89 8b 40 fc          	mov    WORD PTR [bp+di-0x3c0],cx
    4bc8:	89 9b 42 fc          	mov    WORD PTR [bp+di-0x3be],bx
    4bcc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4bcf:	99                   	cwd
    4bd0:	bf da 1f             	mov    di,0x1fda
    4bd3:	9a 16 04 e7 4b       	call   0x4be7:0x416
    4bd8:	c1 e0 02             	shl    ax,0x2
    4bdb:	8b c8                	mov    cx,ax
    4bdd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4be0:	99                   	cwd
    4be1:	bf d2 1f             	mov    di,0x1fd2
    4be4:	9a 16 04 05 4c       	call   0x4c05:0x416
    4be9:	8b f8                	mov    di,ax
    4beb:	c1 e7 03             	shl    di,0x3
    4bee:	03 f9                	add    di,cx
    4bf0:	8b 83 28 fa          	mov    ax,WORD PTR [bp+di-0x5d8]
    4bf4:	8b 93 2a fa          	mov    dx,WORD PTR [bp+di-0x5d6]
    4bf8:	03 86 74 fa          	add    ax,WORD PTR [bp-0x58c]
    4bfc:	13 96 76 fa          	adc    dx,WORD PTR [bp-0x58a]
    4c00:	71 05                	jno    0x4c07
    4c02:	9a 3e 04 40 4c       	call   0x4c40:0x43e
    4c07:	89 86 74 fa          	mov    WORD PTR [bp-0x58c],ax
    4c0b:	89 96 76 fa          	mov    WORD PTR [bp-0x58a],dx
    4c0f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4c12:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4c16:	74 03                	je     0x4c1b
    4c18:	e9 98 fd             	jmp    0x49b3
    4c1b:	a1 4e 01             	mov    ax,ds:0x14e
    4c1e:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    4c22:	b8 01 00             	mov    ax,0x1
    4c25:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4c29:	7e 03                	jle    0x4c2e
    4c2b:	e9 0a 02             	jmp    0x4e38
    4c2e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4c31:	eb 03                	jmp    0x4c36
    4c33:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4c36:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4c39:	99                   	cwd
    4c3a:	bf da 1f             	mov    di,0x1fda
    4c3d:	9a 16 04 51 4c       	call   0x4c51:0x416
    4c42:	c1 e0 02             	shl    ax,0x2
    4c45:	8b c8                	mov    cx,ax
    4c47:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4c4a:	99                   	cwd
    4c4b:	bf d2 1f             	mov    di,0x1fd2
    4c4e:	9a 16 04 71 4c       	call   0x4c71:0x416
    4c53:	8b f8                	mov    di,ax
    4c55:	c1 e7 03             	shl    di,0x3
    4c58:	03 f9                	add    di,cx
    4c5a:	8b 83 28 fa          	mov    ax,WORD PTR [bp+di-0x5d8]
    4c5e:	0b 83 2a fa          	or     ax,WORD PTR [bp+di-0x5d6]
    4c62:	74 03                	je     0x4c67
    4c64:	e9 97 01             	jmp    0x4dfe
    4c67:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4c6a:	99                   	cwd
    4c6b:	bf da 1f             	mov    di,0x1fda
    4c6e:	9a 16 04 82 4c       	call   0x4c82:0x416
    4c73:	c1 e0 03             	shl    ax,0x3
    4c76:	8b c8                	mov    cx,ax
    4c78:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4c7b:	99                   	cwd
    4c7c:	bf d2 1f             	mov    di,0x1fd2
    4c7f:	9a 16 04 c4 4c       	call   0x4cc4:0x416
    4c84:	8b f8                	mov    di,ax
    4c86:	c1 e7 04             	shl    di,0x4
    4c89:	03 f9                	add    di,cx
    4c8b:	ff b3 e2 fc          	push   WORD PTR [bp+di-0x31e]
    4c8f:	ff b3 e0 fc          	push   WORD PTR [bp+di-0x320]
    4c93:	ff b3 de fc          	push   WORD PTR [bp+di-0x322]
    4c97:	ff b3 dc fc          	push   WORD PTR [bp+di-0x324]
    4c9b:	ff b6 72 fc          	push   WORD PTR [bp-0x38e]
    4c9f:	ff b6 70 fc          	push   WORD PTR [bp-0x390]
    4ca3:	ff b6 6e fc          	push   WORD PTR [bp-0x392]
    4ca7:	ff b6 6c fc          	push   WORD PTR [bp-0x394]
    4cab:	9a a7 2e 78 4f       	call   0x4f78:0x2ea7
    4cb0:	9b db 86 74 fa       	fild   DWORD PTR [bp-0x58c]
    4cb5:	9b 2e db 2e e6 1f    	fld    TBYTE PTR cs:0x1fe6
    4cbb:	9b de c9             	fmulp  st(1),st
    4cbe:	9b de c9             	fmulp  st(1),st
    4cc1:	9a 0e 10 d8 4c       	call   0x4cd8:0x100e
    4cc6:	89 86 30 f9          	mov    WORD PTR [bp-0x6d0],ax
    4cca:	89 96 32 f9          	mov    WORD PTR [bp-0x6ce],dx
    4cce:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4cd1:	99                   	cwd
    4cd2:	bf d2 1f             	mov    di,0x1fd2
    4cd5:	9a 16 04 ff 4c       	call   0x4cff:0x416
    4cda:	8b f8                	mov    di,ax
    4cdc:	c1 e7 02             	shl    di,0x2
    4cdf:	8b 83 40 fc          	mov    ax,WORD PTR [bp+di-0x3c0]
    4ce3:	8b 93 42 fc          	mov    dx,WORD PTR [bp+di-0x3be]
    4ce7:	3b 96 32 f9          	cmp    dx,WORD PTR [bp-0x6ce]
    4ceb:	7c 08                	jl     0x4cf5
    4ced:	7f 27                	jg     0x4d16
    4cef:	3b 86 30 f9          	cmp    ax,WORD PTR [bp-0x6d0]
    4cf3:	73 21                	jae    0x4d16
    4cf5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4cf8:	99                   	cwd
    4cf9:	bf d2 1f             	mov    di,0x1fd2
    4cfc:	9a 16 04 28 4d       	call   0x4d28:0x416
    4d01:	8b f8                	mov    di,ax
    4d03:	c1 e7 02             	shl    di,0x2
    4d06:	8b 83 40 fc          	mov    ax,WORD PTR [bp+di-0x3c0]
    4d0a:	8b 93 42 fc          	mov    dx,WORD PTR [bp+di-0x3be]
    4d0e:	89 86 30 f9          	mov    WORD PTR [bp-0x6d0],ax
    4d12:	89 96 32 f9          	mov    WORD PTR [bp-0x6ce],dx
    4d16:	ff b6 32 f9          	push   WORD PTR [bp-0x6ce]
    4d1a:	ff b6 30 f9          	push   WORD PTR [bp-0x6d0]
    4d1e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4d21:	99                   	cwd
    4d22:	bf da 1f             	mov    di,0x1fda
    4d25:	9a 16 04 39 4d       	call   0x4d39:0x416
    4d2a:	c1 e0 02             	shl    ax,0x2
    4d2d:	8b c8                	mov    cx,ax
    4d2f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4d32:	99                   	cwd
    4d33:	bf d2 1f             	mov    di,0x1fd2
    4d36:	9a 16 04 56 4d       	call   0x4d56:0x416
    4d3b:	8b f8                	mov    di,ax
    4d3d:	c1 e7 03             	shl    di,0x3
    4d40:	03 f9                	add    di,cx
    4d42:	58                   	pop    ax
    4d43:	5a                   	pop    dx
    4d44:	89 83 28 f9          	mov    WORD PTR [bp+di-0x6d8],ax
    4d48:	89 93 2a f9          	mov    WORD PTR [bp+di-0x6d6],dx
    4d4c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4d4f:	99                   	cwd
    4d50:	bf da 1f             	mov    di,0x1fda
    4d53:	9a 16 04 67 4d       	call   0x4d67:0x416
    4d58:	c1 e0 02             	shl    ax,0x2
    4d5b:	8b c8                	mov    cx,ax
    4d5d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4d60:	99                   	cwd
    4d61:	bf d2 1f             	mov    di,0x1fd2
    4d64:	9a 16 04 85 4d       	call   0x4d85:0x416
    4d69:	8b f8                	mov    di,ax
    4d6b:	c1 e7 03             	shl    di,0x3
    4d6e:	03 f9                	add    di,cx
    4d70:	8b 83 68 f9          	mov    ax,WORD PTR [bp+di-0x698]
    4d74:	8b 93 6a f9          	mov    dx,WORD PTR [bp+di-0x696]
    4d78:	03 86 30 f9          	add    ax,WORD PTR [bp-0x6d0]
    4d7c:	13 96 32 f9          	adc    dx,WORD PTR [bp-0x6ce]
    4d80:	71 05                	jno    0x4d87
    4d82:	9a 3e 04 93 4d       	call   0x4d93:0x43e
    4d87:	52                   	push   dx
    4d88:	50                   	push   ax
    4d89:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4d8c:	99                   	cwd
    4d8d:	bf da 1f             	mov    di,0x1fda
    4d90:	9a 16 04 a4 4d       	call   0x4da4:0x416
    4d95:	c1 e0 02             	shl    ax,0x2
    4d98:	8b c8                	mov    cx,ax
    4d9a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4d9d:	99                   	cwd
    4d9e:	bf d2 1f             	mov    di,0x1fd2
    4da1:	9a 16 04 c1 4d       	call   0x4dc1:0x416
    4da6:	8b f8                	mov    di,ax
    4da8:	c1 e7 03             	shl    di,0x3
    4dab:	03 f9                	add    di,cx
    4dad:	58                   	pop    ax
    4dae:	5a                   	pop    dx
    4daf:	89 83 68 f9          	mov    WORD PTR [bp+di-0x698],ax
    4db3:	89 93 6a f9          	mov    WORD PTR [bp+di-0x696],dx
    4db7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4dba:	99                   	cwd
    4dbb:	bf d2 1f             	mov    di,0x1fd2
    4dbe:	9a 16 04 dd 4d       	call   0x4ddd:0x416
    4dc3:	8b f8                	mov    di,ax
    4dc5:	c1 e7 02             	shl    di,0x2
    4dc8:	8b 83 40 fc          	mov    ax,WORD PTR [bp+di-0x3c0]
    4dcc:	8b 93 42 fc          	mov    dx,WORD PTR [bp+di-0x3be]
    4dd0:	2b 86 30 f9          	sub    ax,WORD PTR [bp-0x6d0]
    4dd4:	1b 96 32 f9          	sbb    dx,WORD PTR [bp-0x6ce]
    4dd8:	71 05                	jno    0x4ddf
    4dda:	9a 3e 04 ed 4d       	call   0x4ded:0x43e
    4ddf:	8b c8                	mov    cx,ax
    4de1:	8b da                	mov    bx,dx
    4de3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4de6:	99                   	cwd
    4de7:	bf d2 1f             	mov    di,0x1fd2
    4dea:	9a 16 04 08 4e       	call   0x4e08:0x416
    4def:	8b f8                	mov    di,ax
    4df1:	c1 e7 02             	shl    di,0x2
    4df4:	89 8b 40 fc          	mov    WORD PTR [bp+di-0x3c0],cx
    4df8:	89 9b 42 fc          	mov    WORD PTR [bp+di-0x3be],bx
    4dfc:	eb 2e                	jmp    0x4e2c
    4dfe:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4e01:	99                   	cwd
    4e02:	bf da 1f             	mov    di,0x1fda
    4e05:	9a 16 04 19 4e       	call   0x4e19:0x416
    4e0a:	c1 e0 02             	shl    ax,0x2
    4e0d:	8b c8                	mov    cx,ax
    4e0f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e12:	99                   	cwd
    4e13:	bf d2 1f             	mov    di,0x1fd2
    4e16:	9a 16 04 5a 4e       	call   0x4e5a:0x416
    4e1b:	8b f8                	mov    di,ax
    4e1d:	c1 e7 03             	shl    di,0x3
    4e20:	03 f9                	add    di,cx
    4e22:	31 c0                	xor    ax,ax
    4e24:	89 83 28 f9          	mov    WORD PTR [bp+di-0x6d8],ax
    4e28:	89 83 2a f9          	mov    WORD PTR [bp+di-0x6d6],ax
    4e2c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e2f:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4e33:	74 03                	je     0x4e38
    4e35:	e9 fb fd             	jmp    0x4c33
    4e38:	a1 4e 01             	mov    ax,ds:0x14e
    4e3b:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    4e3f:	b8 01 00             	mov    ax,0x1
    4e42:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4e46:	7f 58                	jg     0x4ea0
    4e48:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4e4b:	eb 03                	jmp    0x4e50
    4e4d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4e50:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e53:	99                   	cwd
    4e54:	bf d2 1f             	mov    di,0x1fd2
    4e57:	9a 16 04 73 4e       	call   0x4e73:0x416
    4e5c:	8b f8                	mov    di,ax
    4e5e:	c1 e7 02             	shl    di,0x2
    4e61:	ff b3 42 fc          	push   WORD PTR [bp+di-0x3be]
    4e65:	ff b3 40 fc          	push   WORD PTR [bp+di-0x3c0]
    4e69:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4e6c:	99                   	cwd
    4e6d:	bf da 1f             	mov    di,0x1fda
    4e70:	9a 16 04 84 4e       	call   0x4e84:0x416
    4e75:	c1 e0 02             	shl    ax,0x2
    4e78:	8b c8                	mov    cx,ax
    4e7a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e7d:	99                   	cwd
    4e7e:	bf d2 1f             	mov    di,0x1fd2
    4e81:	9a 16 04 e2 4e       	call   0x4ee2:0x416
    4e86:	8b f8                	mov    di,ax
    4e88:	c1 e7 03             	shl    di,0x3
    4e8b:	03 f9                	add    di,cx
    4e8d:	58                   	pop    ax
    4e8e:	5a                   	pop    dx
    4e8f:	89 83 cc f6          	mov    WORD PTR [bp+di-0x934],ax
    4e93:	89 93 ce f6          	mov    WORD PTR [bp+di-0x932],dx
    4e97:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e9a:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4e9e:	75 ad                	jne    0x4e4d
    4ea0:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    4ea4:	74 03                	je     0x4ea9
    4ea6:	e9 31 ef             	jmp    0x3dda
    4ea9:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    4eae:	eb 03                	jmp    0x4eb3
    4eb0:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    4eb3:	9b 2e d9 06 df 1f    	fld    DWORD PTR cs:0x1fdf
    4eb9:	9b dd 9e 50 f6       	fstp   QWORD PTR [bp-0x9b0]
    4ebe:	90                   	nop
    4ebf:	9b                   	fwait
    4ec0:	a1 4e 01             	mov    ax,ds:0x14e
    4ec3:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    4ec7:	b8 01 00             	mov    ax,0x1
    4eca:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4ece:	7f 46                	jg     0x4f16
    4ed0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4ed3:	eb 03                	jmp    0x4ed8
    4ed5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4ed8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4edb:	99                   	cwd
    4edc:	bf da 1f             	mov    di,0x1fda
    4edf:	9a 16 04 f3 4e       	call   0x4ef3:0x416
    4ee4:	c1 e0 02             	shl    ax,0x2
    4ee7:	8b c8                	mov    cx,ax
    4ee9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4eec:	99                   	cwd
    4eed:	bf d2 1f             	mov    di,0x1fd2
    4ef0:	9a 16 04 3b 4f       	call   0x4f3b:0x416
    4ef5:	8b f8                	mov    di,ax
    4ef7:	c1 e7 03             	shl    di,0x3
    4efa:	03 f9                	add    di,cx
    4efc:	9b db 83 68 f9       	fild   DWORD PTR [bp+di-0x698]
    4f01:	9b dc 86 50 f6       	fadd   QWORD PTR [bp-0x9b0]
    4f06:	9b dd 9e 50 f6       	fstp   QWORD PTR [bp-0x9b0]
    4f0b:	90                   	nop
    4f0c:	9b                   	fwait
    4f0d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4f10:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4f14:	75 bf                	jne    0x4ed5
    4f16:	a1 4e 01             	mov    ax,ds:0x14e
    4f19:	89 86 72 f1          	mov    WORD PTR [bp-0xe8e],ax
    4f1d:	b8 01 00             	mov    ax,0x1
    4f20:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4f24:	7e 03                	jle    0x4f29
    4f26:	e9 8e 00             	jmp    0x4fb7
    4f29:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4f2c:	eb 03                	jmp    0x4f31
    4f2e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4f31:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4f34:	99                   	cwd
    4f35:	bf da 1f             	mov    di,0x1fda
    4f38:	9a 16 04 4c 4f       	call   0x4f4c:0x416
    4f3d:	c1 e0 02             	shl    ax,0x2
    4f40:	8b c8                	mov    cx,ax
    4f42:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4f45:	99                   	cwd
    4f46:	bf d2 1f             	mov    di,0x1fd2
    4f49:	9a 16 04 8a 4f       	call   0x4f8a:0x416
    4f4e:	8b f8                	mov    di,ax
    4f50:	c1 e7 03             	shl    di,0x3
    4f53:	03 f9                	add    di,cx
    4f55:	9b db 83 68 f9       	fild   DWORD PTR [bp+di-0x698]
    4f5a:	83 ec 08             	sub    sp,0x8
    4f5d:	89 e3                	mov    bx,sp
    4f5f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4f63:	90                   	nop
    4f64:	9b                   	fwait
    4f65:	ff b6 56 f6          	push   WORD PTR [bp-0x9aa]
    4f69:	ff b6 54 f6          	push   WORD PTR [bp-0x9ac]
    4f6d:	ff b6 52 f6          	push   WORD PTR [bp-0x9ae]
    4f71:	ff b6 50 f6          	push   WORD PTR [bp-0x9b0]
    4f75:	9a a7 2e 0c 5c       	call   0x5c0c:0x2ea7
    4f7a:	9b 2e d8 0e f0 1f    	fmul   DWORD PTR cs:0x1ff0
    4f80:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4f83:	99                   	cwd
    4f84:	bf da 1f             	mov    di,0x1fda
    4f87:	9a 16 04 9b 4f       	call   0x4f9b:0x416
    4f8c:	c1 e0 03             	shl    ax,0x3
    4f8f:	8b c8                	mov    cx,ax
    4f91:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4f94:	99                   	cwd
    4f95:	bf d2 1f             	mov    di,0x1fd2
    4f98:	9a 16 04 6c 50       	call   0x506c:0x416
    4f9d:	8b f8                	mov    di,ax
    4f9f:	c1 e7 04             	shl    di,0x4
    4fa2:	03 f9                	add    di,cx
    4fa4:	9b dd 9b 40 f6       	fstp   QWORD PTR [bp+di-0x9c0]
    4fa9:	90                   	nop
    4faa:	9b                   	fwait
    4fab:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4fae:	3b 86 72 f1          	cmp    ax,WORD PTR [bp-0xe8e]
    4fb2:	74 03                	je     0x4fb7
    4fb4:	e9 77 ff             	jmp    0x4f2e
    4fb7:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    4fbb:	74 03                	je     0x4fc0
    4fbd:	e9 f0 fe             	jmp    0x4eb0
    4fc0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fc3:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    4fc8:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    4fcc:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    4fd0:	b8 07 21             	mov    ax,0x2107
    4fd3:	0e                   	push   cs
    4fd4:	50                   	push   ax
    4fd5:	55                   	push   bp
    4fd6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4fda:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4fde:	a1 4e 01             	mov    ax,ds:0x14e
    4fe1:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    4fe5:	b8 01 00             	mov    ax,0x1
    4fe8:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    4fec:	7e 03                	jle    0x4ff1
    4fee:	e9 72 06             	jmp    0x5663
    4ff1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4ff4:	eb 03                	jmp    0x4ff9
    4ff6:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4ff9:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    4ffe:	eb 03                	jmp    0x5003
    5000:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    5003:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5006:	99                   	cwd
    5007:	89 86 56 f1          	mov    WORD PTR [bp-0xeaa],ax
    500b:	89 96 58 f1          	mov    WORD PTR [bp-0xea8],dx
    500f:	c6 86 5a f1 00       	mov    BYTE PTR [bp-0xea6],0x0
    5014:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5017:	99                   	cwd
    5018:	89 86 5e f1          	mov    WORD PTR [bp-0xea2],ax
    501c:	89 96 60 f1          	mov    WORD PTR [bp-0xea0],dx
    5020:	c6 86 62 f1 00       	mov    BYTE PTR [bp-0xe9e],0x0
    5025:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5028:	99                   	cwd
    5029:	89 86 66 f1          	mov    WORD PTR [bp-0xe9a],ax
    502d:	89 96 68 f1          	mov    WORD PTR [bp-0xe98],dx
    5031:	c6 86 6a f1 00       	mov    BYTE PTR [bp-0xe96],0x0
    5036:	8d be 56 f1          	lea    di,[bp-0xeaa]
    503a:	16                   	push   ss
    503b:	57                   	push   di
    503c:	6a 02                	push   0x2
    503e:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5042:	06                   	push   es
    5043:	57                   	push   di
    5044:	9a 95 28 dc 56       	call   0x56dc:0x2895
    5049:	08 c0                	or     al,al
    504b:	75 0a                	jne    0x5057
    504d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5050:	06                   	push   es
    5051:	57                   	push   di
    5052:	9a 03 03 ea 56       	call   0x56ea:0x303
    5057:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    505b:	06                   	push   es
    505c:	57                   	push   di
    505d:	9a 3c 53 a4 50       	call   0x50a4:0x533c
    5062:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5065:	99                   	cwd
    5066:	bf da 1f             	mov    di,0x1fda
    5069:	9a 16 04 7d 50       	call   0x507d:0x416
    506e:	c1 e0 03             	shl    ax,0x3
    5071:	8b c8                	mov    cx,ax
    5073:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5076:	99                   	cwd
    5077:	bf d2 1f             	mov    di,0x1fd2
    507a:	9a 16 04 bd 50       	call   0x50bd:0x416
    507f:	8b f8                	mov    di,ax
    5081:	c1 e7 04             	shl    di,0x4
    5084:	03 f9                	add    di,cx
    5086:	ff b3 62 ff          	push   WORD PTR [bp+di-0x9e]
    508a:	ff b3 60 ff          	push   WORD PTR [bp+di-0xa0]
    508e:	ff b3 5e ff          	push   WORD PTR [bp+di-0xa2]
    5092:	ff b3 5c ff          	push   WORD PTR [bp+di-0xa4]
    5096:	bf f4 1f             	mov    di,0x1ff4
    5099:	0e                   	push   cs
    509a:	57                   	push   di
    509b:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    509f:	06                   	push   es
    50a0:	57                   	push   di
    50a1:	9a 9b 3b f5 50       	call   0x50f5:0x3b9b
    50a6:	89 c7                	mov    di,ax
    50a8:	8e c2                	mov    es,dx
    50aa:	06                   	push   es
    50ab:	57                   	push   di
    50ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50af:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    50b3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    50b6:	99                   	cwd
    50b7:	bf da 1f             	mov    di,0x1fda
    50ba:	9a 16 04 ce 50       	call   0x50ce:0x416
    50bf:	c1 e0 03             	shl    ax,0x3
    50c2:	8b c8                	mov    cx,ax
    50c4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    50c7:	99                   	cwd
    50c8:	bf d2 1f             	mov    di,0x1fd2
    50cb:	9a 16 04 0e 51       	call   0x510e:0x416
    50d0:	8b f8                	mov    di,ax
    50d2:	c1 e7 04             	shl    di,0x4
    50d5:	03 f9                	add    di,cx
    50d7:	ff b3 e2 fe          	push   WORD PTR [bp+di-0x11e]
    50db:	ff b3 e0 fe          	push   WORD PTR [bp+di-0x120]
    50df:	ff b3 de fe          	push   WORD PTR [bp+di-0x122]
    50e3:	ff b3 dc fe          	push   WORD PTR [bp+di-0x124]
    50e7:	bf fe 1f             	mov    di,0x1ffe
    50ea:	0e                   	push   cs
    50eb:	57                   	push   di
    50ec:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    50f0:	06                   	push   es
    50f1:	57                   	push   di
    50f2:	9a 9b 3b 46 51       	call   0x5146:0x3b9b
    50f7:	89 c7                	mov    di,ax
    50f9:	8e c2                	mov    es,dx
    50fb:	06                   	push   es
    50fc:	57                   	push   di
    50fd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5100:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5104:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5107:	99                   	cwd
    5108:	bf da 1f             	mov    di,0x1fda
    510b:	9a 16 04 1f 51       	call   0x511f:0x416
    5110:	c1 e0 03             	shl    ax,0x3
    5113:	8b c8                	mov    cx,ax
    5115:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5118:	99                   	cwd
    5119:	bf d2 1f             	mov    di,0x1fd2
    511c:	9a 16 04 5f 51       	call   0x515f:0x416
    5121:	8b f8                	mov    di,ax
    5123:	c1 e7 04             	shl    di,0x4
    5126:	03 f9                	add    di,cx
    5128:	ff b3 62 fe          	push   WORD PTR [bp+di-0x19e]
    512c:	ff b3 60 fe          	push   WORD PTR [bp+di-0x1a0]
    5130:	ff b3 5e fe          	push   WORD PTR [bp+di-0x1a2]
    5134:	ff b3 5c fe          	push   WORD PTR [bp+di-0x1a4]
    5138:	bf 07 20             	mov    di,0x2007
    513b:	0e                   	push   cs
    513c:	57                   	push   di
    513d:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5141:	06                   	push   es
    5142:	57                   	push   di
    5143:	9a 9b 3b 97 51       	call   0x5197:0x3b9b
    5148:	89 c7                	mov    di,ax
    514a:	8e c2                	mov    es,dx
    514c:	06                   	push   es
    514d:	57                   	push   di
    514e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5151:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5155:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5158:	99                   	cwd
    5159:	bf da 1f             	mov    di,0x1fda
    515c:	9a 16 04 70 51       	call   0x5170:0x416
    5161:	c1 e0 03             	shl    ax,0x3
    5164:	8b c8                	mov    cx,ax
    5166:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5169:	99                   	cwd
    516a:	bf d2 1f             	mov    di,0x1fd2
    516d:	9a 16 04 b0 51       	call   0x51b0:0x416
    5172:	8b f8                	mov    di,ax
    5174:	c1 e7 04             	shl    di,0x4
    5177:	03 f9                	add    di,cx
    5179:	ff b3 e2 fd          	push   WORD PTR [bp+di-0x21e]
    517d:	ff b3 e0 fd          	push   WORD PTR [bp+di-0x220]
    5181:	ff b3 de fd          	push   WORD PTR [bp+di-0x222]
    5185:	ff b3 dc fd          	push   WORD PTR [bp+di-0x224]
    5189:	bf 0f 20             	mov    di,0x200f
    518c:	0e                   	push   cs
    518d:	57                   	push   di
    518e:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5192:	06                   	push   es
    5193:	57                   	push   di
    5194:	9a 9b 3b e8 51       	call   0x51e8:0x3b9b
    5199:	89 c7                	mov    di,ax
    519b:	8e c2                	mov    es,dx
    519d:	06                   	push   es
    519e:	57                   	push   di
    519f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51a2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    51a6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    51a9:	99                   	cwd
    51aa:	bf da 1f             	mov    di,0x1fda
    51ad:	9a 16 04 c1 51       	call   0x51c1:0x416
    51b2:	c1 e0 03             	shl    ax,0x3
    51b5:	8b c8                	mov    cx,ax
    51b7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    51ba:	99                   	cwd
    51bb:	bf d2 1f             	mov    di,0x1fd2
    51be:	9a 16 04 01 52       	call   0x5201:0x416
    51c3:	8b f8                	mov    di,ax
    51c5:	c1 e7 04             	shl    di,0x4
    51c8:	03 f9                	add    di,cx
    51ca:	ff b3 62 fd          	push   WORD PTR [bp+di-0x29e]
    51ce:	ff b3 60 fd          	push   WORD PTR [bp+di-0x2a0]
    51d2:	ff b3 5e fd          	push   WORD PTR [bp+di-0x2a2]
    51d6:	ff b3 5c fd          	push   WORD PTR [bp+di-0x2a4]
    51da:	bf 1b 20             	mov    di,0x201b
    51dd:	0e                   	push   cs
    51de:	57                   	push   di
    51df:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    51e3:	06                   	push   es
    51e4:	57                   	push   di
    51e5:	9a 9b 3b 39 52       	call   0x5239:0x3b9b
    51ea:	89 c7                	mov    di,ax
    51ec:	8e c2                	mov    es,dx
    51ee:	06                   	push   es
    51ef:	57                   	push   di
    51f0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51f3:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    51f7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    51fa:	99                   	cwd
    51fb:	bf da 1f             	mov    di,0x1fda
    51fe:	9a 16 04 12 52       	call   0x5212:0x416
    5203:	c1 e0 03             	shl    ax,0x3
    5206:	8b c8                	mov    cx,ax
    5208:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    520b:	99                   	cwd
    520c:	bf d2 1f             	mov    di,0x1fd2
    520f:	9a 16 04 52 52       	call   0x5252:0x416
    5214:	8b f8                	mov    di,ax
    5216:	c1 e7 04             	shl    di,0x4
    5219:	03 f9                	add    di,cx
    521b:	ff b3 e2 fc          	push   WORD PTR [bp+di-0x31e]
    521f:	ff b3 e0 fc          	push   WORD PTR [bp+di-0x320]
    5223:	ff b3 de fc          	push   WORD PTR [bp+di-0x322]
    5227:	ff b3 dc fc          	push   WORD PTR [bp+di-0x324]
    522b:	bf 28 20             	mov    di,0x2028
    522e:	0e                   	push   cs
    522f:	57                   	push   di
    5230:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5234:	06                   	push   es
    5235:	57                   	push   di
    5236:	9a 9b 3b 82 52       	call   0x5282:0x3b9b
    523b:	89 c7                	mov    di,ax
    523d:	8e c2                	mov    es,dx
    523f:	06                   	push   es
    5240:	57                   	push   di
    5241:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5244:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5248:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    524b:	99                   	cwd
    524c:	bf da 1f             	mov    di,0x1fda
    524f:	9a 16 04 63 52       	call   0x5263:0x416
    5254:	c1 e0 02             	shl    ax,0x2
    5257:	8b c8                	mov    cx,ax
    5259:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    525c:	99                   	cwd
    525d:	bf d2 1f             	mov    di,0x1fd2
    5260:	9a 16 04 9b 52       	call   0x529b:0x416
    5265:	8b f8                	mov    di,ax
    5267:	c1 e7 03             	shl    di,0x3
    526a:	03 f9                	add    di,cx
    526c:	ff b3 6e fa          	push   WORD PTR [bp+di-0x592]
    5270:	ff b3 6c fa          	push   WORD PTR [bp+di-0x594]
    5274:	bf 34 20             	mov    di,0x2034
    5277:	0e                   	push   cs
    5278:	57                   	push   di
    5279:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    527d:	06                   	push   es
    527e:	57                   	push   di
    527f:	9a 9b 3b cb 52       	call   0x52cb:0x3b9b
    5284:	89 c7                	mov    di,ax
    5286:	8e c2                	mov    es,dx
    5288:	06                   	push   es
    5289:	57                   	push   di
    528a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    528d:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    5291:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5294:	99                   	cwd
    5295:	bf da 1f             	mov    di,0x1fda
    5298:	9a 16 04 ac 52       	call   0x52ac:0x416
    529d:	c1 e0 02             	shl    ax,0x2
    52a0:	8b c8                	mov    cx,ax
    52a2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    52a5:	99                   	cwd
    52a6:	bf d2 1f             	mov    di,0x1fd2
    52a9:	9a 16 04 e4 52       	call   0x52e4:0x416
    52ae:	8b f8                	mov    di,ax
    52b0:	c1 e7 03             	shl    di,0x3
    52b3:	03 f9                	add    di,cx
    52b5:	ff b3 6a f9          	push   WORD PTR [bp+di-0x696]
    52b9:	ff b3 68 f9          	push   WORD PTR [bp+di-0x698]
    52bd:	bf 3c 20             	mov    di,0x203c
    52c0:	0e                   	push   cs
    52c1:	57                   	push   di
    52c2:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    52c6:	06                   	push   es
    52c7:	57                   	push   di
    52c8:	9a 9b 3b 14 53       	call   0x5314:0x3b9b
    52cd:	89 c7                	mov    di,ax
    52cf:	8e c2                	mov    es,dx
    52d1:	06                   	push   es
    52d2:	57                   	push   di
    52d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52d6:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    52da:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    52dd:	99                   	cwd
    52de:	bf da 1f             	mov    di,0x1fda
    52e1:	9a 16 04 f5 52       	call   0x52f5:0x416
    52e6:	c1 e0 02             	shl    ax,0x2
    52e9:	8b c8                	mov    cx,ax
    52eb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    52ee:	99                   	cwd
    52ef:	bf d2 1f             	mov    di,0x1fd2
    52f2:	9a 16 04 2d 53       	call   0x532d:0x416
    52f7:	8b f8                	mov    di,ax
    52f9:	c1 e7 03             	shl    di,0x3
    52fc:	03 f9                	add    di,cx
    52fe:	ff b3 2a fa          	push   WORD PTR [bp+di-0x5d6]
    5302:	ff b3 28 fa          	push   WORD PTR [bp+di-0x5d8]
    5306:	bf 43 20             	mov    di,0x2043
    5309:	0e                   	push   cs
    530a:	57                   	push   di
    530b:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    530f:	06                   	push   es
    5310:	57                   	push   di
    5311:	9a 9b 3b 5d 53       	call   0x535d:0x3b9b
    5316:	89 c7                	mov    di,ax
    5318:	8e c2                	mov    es,dx
    531a:	06                   	push   es
    531b:	57                   	push   di
    531c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    531f:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    5323:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5326:	99                   	cwd
    5327:	bf da 1f             	mov    di,0x1fda
    532a:	9a 16 04 3e 53       	call   0x533e:0x416
    532f:	c1 e0 02             	shl    ax,0x2
    5332:	8b c8                	mov    cx,ax
    5334:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5337:	99                   	cwd
    5338:	bf d2 1f             	mov    di,0x1fd2
    533b:	9a 16 04 76 53       	call   0x5376:0x416
    5340:	8b f8                	mov    di,ax
    5342:	c1 e7 03             	shl    di,0x3
    5345:	03 f9                	add    di,cx
    5347:	ff b3 2a f9          	push   WORD PTR [bp+di-0x6d6]
    534b:	ff b3 28 f9          	push   WORD PTR [bp+di-0x6d8]
    534f:	bf 58 20             	mov    di,0x2058
    5352:	0e                   	push   cs
    5353:	57                   	push   di
    5354:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5358:	06                   	push   es
    5359:	57                   	push   di
    535a:	9a 9b 3b a6 53       	call   0x53a6:0x3b9b
    535f:	89 c7                	mov    di,ax
    5361:	8e c2                	mov    es,dx
    5363:	06                   	push   es
    5364:	57                   	push   di
    5365:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5368:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    536c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    536f:	99                   	cwd
    5370:	bf da 1f             	mov    di,0x1fda
    5373:	9a 16 04 87 53       	call   0x5387:0x416
    5378:	c1 e0 02             	shl    ax,0x2
    537b:	8b c8                	mov    cx,ax
    537d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5380:	99                   	cwd
    5381:	bf d2 1f             	mov    di,0x1fd2
    5384:	9a 16 04 bf 53       	call   0x53bf:0x416
    5389:	8b f8                	mov    di,ax
    538b:	c1 e7 03             	shl    di,0x3
    538e:	03 f9                	add    di,cx
    5390:	ff b3 4e f8          	push   WORD PTR [bp+di-0x7b2]
    5394:	ff b3 4c f8          	push   WORD PTR [bp+di-0x7b4]
    5398:	bf 65 20             	mov    di,0x2065
    539b:	0e                   	push   cs
    539c:	57                   	push   di
    539d:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    53a1:	06                   	push   es
    53a2:	57                   	push   di
    53a3:	9a 9b 3b f7 53       	call   0x53f7:0x3b9b
    53a8:	89 c7                	mov    di,ax
    53aa:	8e c2                	mov    es,dx
    53ac:	06                   	push   es
    53ad:	57                   	push   di
    53ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53b1:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    53b5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    53b8:	99                   	cwd
    53b9:	bf da 1f             	mov    di,0x1fda
    53bc:	9a 16 04 d0 53       	call   0x53d0:0x416
    53c1:	c1 e0 03             	shl    ax,0x3
    53c4:	8b c8                	mov    cx,ax
    53c6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    53c9:	99                   	cwd
    53ca:	bf d2 1f             	mov    di,0x1fd2
    53cd:	9a 16 04 10 54       	call   0x5410:0x416
    53d2:	8b f8                	mov    di,ax
    53d4:	c1 e7 04             	shl    di,0x4
    53d7:	03 f9                	add    di,cx
    53d9:	ff b3 c6 f7          	push   WORD PTR [bp+di-0x83a]
    53dd:	ff b3 c4 f7          	push   WORD PTR [bp+di-0x83c]
    53e1:	ff b3 c2 f7          	push   WORD PTR [bp+di-0x83e]
    53e5:	ff b3 c0 f7          	push   WORD PTR [bp+di-0x840]
    53e9:	bf 76 20             	mov    di,0x2076
    53ec:	0e                   	push   cs
    53ed:	57                   	push   di
    53ee:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    53f2:	06                   	push   es
    53f3:	57                   	push   di
    53f4:	9a 9b 3b 40 54       	call   0x5440:0x3b9b
    53f9:	89 c7                	mov    di,ax
    53fb:	8e c2                	mov    es,dx
    53fd:	06                   	push   es
    53fe:	57                   	push   di
    53ff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5402:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5406:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5409:	99                   	cwd
    540a:	bf da 1f             	mov    di,0x1fda
    540d:	9a 16 04 21 54       	call   0x5421:0x416
    5412:	c1 e0 02             	shl    ax,0x2
    5415:	8b c8                	mov    cx,ax
    5417:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    541a:	99                   	cwd
    541b:	bf d2 1f             	mov    di,0x1fd2
    541e:	9a 16 04 59 54       	call   0x5459:0x416
    5423:	8b f8                	mov    di,ax
    5425:	c1 e7 03             	shl    di,0x3
    5428:	03 f9                	add    di,cx
    542a:	ff b3 8e f7          	push   WORD PTR [bp+di-0x872]
    542e:	ff b3 8c f7          	push   WORD PTR [bp+di-0x874]
    5432:	bf 88 20             	mov    di,0x2088
    5435:	0e                   	push   cs
    5436:	57                   	push   di
    5437:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    543b:	06                   	push   es
    543c:	57                   	push   di
    543d:	9a 9b 3b 91 54       	call   0x5491:0x3b9b
    5442:	89 c7                	mov    di,ax
    5444:	8e c2                	mov    es,dx
    5446:	06                   	push   es
    5447:	57                   	push   di
    5448:	26 c4 3d             	les    di,DWORD PTR es:[di]
    544b:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    544f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5452:	99                   	cwd
    5453:	bf da 1f             	mov    di,0x1fda
    5456:	9a 16 04 6a 54       	call   0x546a:0x416
    545b:	c1 e0 03             	shl    ax,0x3
    545e:	8b c8                	mov    cx,ax
    5460:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5463:	99                   	cwd
    5464:	bf d2 1f             	mov    di,0x1fd2
    5467:	9a 16 04 aa 54       	call   0x54aa:0x416
    546c:	8b f8                	mov    di,ax
    546e:	c1 e7 04             	shl    di,0x4
    5471:	03 f9                	add    di,cx
    5473:	ff b3 06 f7          	push   WORD PTR [bp+di-0x8fa]
    5477:	ff b3 04 f7          	push   WORD PTR [bp+di-0x8fc]
    547b:	ff b3 02 f7          	push   WORD PTR [bp+di-0x8fe]
    547f:	ff b3 00 f7          	push   WORD PTR [bp+di-0x900]
    5483:	bf 95 20             	mov    di,0x2095
    5486:	0e                   	push   cs
    5487:	57                   	push   di
    5488:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    548c:	06                   	push   es
    548d:	57                   	push   di
    548e:	9a 9b 3b da 54       	call   0x54da:0x3b9b
    5493:	89 c7                	mov    di,ax
    5495:	8e c2                	mov    es,dx
    5497:	06                   	push   es
    5498:	57                   	push   di
    5499:	26 c4 3d             	les    di,DWORD PTR es:[di]
    549c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    54a0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    54a3:	99                   	cwd
    54a4:	bf da 1f             	mov    di,0x1fda
    54a7:	9a 16 04 bb 54       	call   0x54bb:0x416
    54ac:	c1 e0 02             	shl    ax,0x2
    54af:	8b c8                	mov    cx,ax
    54b1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    54b4:	99                   	cwd
    54b5:	bf d2 1f             	mov    di,0x1fd2
    54b8:	9a 16 04 f3 54       	call   0x54f3:0x416
    54bd:	8b f8                	mov    di,ax
    54bf:	c1 e7 03             	shl    di,0x3
    54c2:	03 f9                	add    di,cx
    54c4:	ff b3 ce f6          	push   WORD PTR [bp+di-0x932]
    54c8:	ff b3 cc f6          	push   WORD PTR [bp+di-0x934]
    54cc:	bf a3 20             	mov    di,0x20a3
    54cf:	0e                   	push   cs
    54d0:	57                   	push   di
    54d1:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    54d5:	06                   	push   es
    54d6:	57                   	push   di
    54d7:	9a 9b 3b 2b 55       	call   0x552b:0x3b9b
    54dc:	89 c7                	mov    di,ax
    54de:	8e c2                	mov    es,dx
    54e0:	06                   	push   es
    54e1:	57                   	push   di
    54e2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54e5:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    54e9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    54ec:	99                   	cwd
    54ed:	bf da 1f             	mov    di,0x1fda
    54f0:	9a 16 04 04 55       	call   0x5504:0x416
    54f5:	c1 e0 03             	shl    ax,0x3
    54f8:	8b c8                	mov    cx,ax
    54fa:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    54fd:	99                   	cwd
    54fe:	bf d2 1f             	mov    di,0x1fd2
    5501:	9a 16 04 b3 55       	call   0x55b3:0x416
    5506:	8b f8                	mov    di,ax
    5508:	c1 e7 04             	shl    di,0x4
    550b:	03 f9                	add    di,cx
    550d:	ff b3 46 f6          	push   WORD PTR [bp+di-0x9ba]
    5511:	ff b3 44 f6          	push   WORD PTR [bp+di-0x9bc]
    5515:	ff b3 42 f6          	push   WORD PTR [bp+di-0x9be]
    5519:	ff b3 40 f6          	push   WORD PTR [bp+di-0x9c0]
    551d:	bf ac 20             	mov    di,0x20ac
    5520:	0e                   	push   cs
    5521:	57                   	push   di
    5522:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5526:	06                   	push   es
    5527:	57                   	push   di
    5528:	9a 9b 3b 50 55       	call   0x5550:0x3b9b
    552d:	89 c7                	mov    di,ax
    552f:	8e c2                	mov    es,dx
    5531:	06                   	push   es
    5532:	57                   	push   di
    5533:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5536:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    553a:	6a 00                	push   0x0
    553c:	6a 00                	push   0x0
    553e:	6a 00                	push   0x0
    5540:	6a 00                	push   0x0
    5542:	bf b7 20             	mov    di,0x20b7
    5545:	0e                   	push   cs
    5546:	57                   	push   di
    5547:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    554b:	06                   	push   es
    554c:	57                   	push   di
    554d:	9a 9b 3b 75 55       	call   0x5575:0x3b9b
    5552:	89 c7                	mov    di,ax
    5554:	8e c2                	mov    es,dx
    5556:	06                   	push   es
    5557:	57                   	push   di
    5558:	26 c4 3d             	les    di,DWORD PTR es:[di]
    555b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    555f:	6a 00                	push   0x0
    5561:	6a 00                	push   0x0
    5563:	6a 00                	push   0x0
    5565:	6a 00                	push   0x0
    5567:	bf c3 20             	mov    di,0x20c3
    556a:	0e                   	push   cs
    556b:	57                   	push   di
    556c:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5570:	06                   	push   es
    5571:	57                   	push   di
    5572:	9a 9b 3b 9a 55       	call   0x559a:0x3b9b
    5577:	89 c7                	mov    di,ax
    5579:	8e c2                	mov    es,dx
    557b:	06                   	push   es
    557c:	57                   	push   di
    557d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5580:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5584:	6a 00                	push   0x0
    5586:	6a 00                	push   0x0
    5588:	6a 00                	push   0x0
    558a:	6a 00                	push   0x0
    558c:	bf d4 20             	mov    di,0x20d4
    558f:	0e                   	push   cs
    5590:	57                   	push   di
    5591:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5595:	06                   	push   es
    5596:	57                   	push   di
    5597:	9a 9b 3b e3 55       	call   0x55e3:0x3b9b
    559c:	89 c7                	mov    di,ax
    559e:	8e c2                	mov    es,dx
    55a0:	06                   	push   es
    55a1:	57                   	push   di
    55a2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55a5:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    55a9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    55ac:	99                   	cwd
    55ad:	bf da 1f             	mov    di,0x1fda
    55b0:	9a 16 04 c4 55       	call   0x55c4:0x416
    55b5:	c1 e0 02             	shl    ax,0x2
    55b8:	8b c8                	mov    cx,ax
    55ba:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    55bd:	99                   	cwd
    55be:	bf d2 1f             	mov    di,0x1fd2
    55c1:	9a 16 04 fc 55       	call   0x55fc:0x416
    55c6:	8b f8                	mov    di,ax
    55c8:	c1 e7 03             	shl    di,0x3
    55cb:	03 f9                	add    di,cx
    55cd:	ff b3 2e fb          	push   WORD PTR [bp+di-0x4d2]
    55d1:	ff b3 2c fb          	push   WORD PTR [bp+di-0x4d4]
    55d5:	bf ea 20             	mov    di,0x20ea
    55d8:	0e                   	push   cs
    55d9:	57                   	push   di
    55da:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    55de:	06                   	push   es
    55df:	57                   	push   di
    55e0:	9a 9b 3b 34 56       	call   0x5634:0x3b9b
    55e5:	89 c7                	mov    di,ax
    55e7:	8e c2                	mov    es,dx
    55e9:	06                   	push   es
    55ea:	57                   	push   di
    55eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55ee:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    55f2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    55f5:	99                   	cwd
    55f6:	bf da 1f             	mov    di,0x1fda
    55f9:	9a 16 04 0d 56       	call   0x560d:0x416
    55fe:	c1 e0 03             	shl    ax,0x3
    5601:	8b c8                	mov    cx,ax
    5603:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5606:	99                   	cwd
    5607:	bf d2 1f             	mov    di,0x1fd2
    560a:	9a 16 04 01 57       	call   0x5701:0x416
    560f:	8b f8                	mov    di,ax
    5611:	c1 e7 04             	shl    di,0x4
    5614:	03 f9                	add    di,cx
    5616:	ff b3 c4 f1          	push   WORD PTR [bp+di-0xe3c]
    561a:	ff b3 c2 f1          	push   WORD PTR [bp+di-0xe3e]
    561e:	ff b3 c0 f1          	push   WORD PTR [bp+di-0xe40]
    5622:	ff b3 be f1          	push   WORD PTR [bp+di-0xe42]
    5626:	bf fb 20             	mov    di,0x20fb
    5629:	0e                   	push   cs
    562a:	57                   	push   di
    562b:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    562f:	06                   	push   es
    5630:	57                   	push   di
    5631:	9a 9b 3b 4c 56       	call   0x564c:0x3b9b
    5636:	89 c7                	mov    di,ax
    5638:	8e c2                	mov    es,dx
    563a:	06                   	push   es
    563b:	57                   	push   di
    563c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    563f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5643:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5647:	06                   	push   es
    5648:	57                   	push   di
    5649:	9a a0 54 f5 56       	call   0x56f5:0x54a0
    564e:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    5652:	74 03                	je     0x5657
    5654:	e9 a9 f9             	jmp    0x5000
    5657:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    565a:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    565e:	74 03                	je     0x5663
    5660:	e9 93 f9             	jmp    0x4ff6
    5663:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5667:	83 c4 06             	add    sp,0x6
    566a:	b8 70 56             	mov    ax,0x5670
    566d:	0e                   	push   cs
    566e:	50                   	push   ax
    566f:	cb                   	retf
    5670:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5673:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    5678:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    567c:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    5680:	b8 4d 21             	mov    ax,0x214d
    5683:	0e                   	push   cs
    5684:	50                   	push   ax
    5685:	55                   	push   bp
    5686:	ff 36 58 18          	push   WORD PTR ds:0x1858
    568a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    568e:	a1 4e 01             	mov    ax,ds:0x14e
    5691:	89 86 6e f1          	mov    WORD PTR [bp-0xe92],ax
    5695:	b8 01 00             	mov    ax,0x1
    5698:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    569c:	7e 03                	jle    0x56a1
    569e:	e9 5d 01             	jmp    0x57fe
    56a1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    56a4:	eb 03                	jmp    0x56a9
    56a6:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    56a9:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    56ac:	99                   	cwd
    56ad:	89 86 5e f1          	mov    WORD PTR [bp-0xea2],ax
    56b1:	89 96 60 f1          	mov    WORD PTR [bp-0xea0],dx
    56b5:	c6 86 62 f1 00       	mov    BYTE PTR [bp-0xe9e],0x0
    56ba:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    56bd:	99                   	cwd
    56be:	89 86 66 f1          	mov    WORD PTR [bp-0xe9a],ax
    56c2:	89 96 68 f1          	mov    WORD PTR [bp-0xe98],dx
    56c6:	c6 86 6a f1 00       	mov    BYTE PTR [bp-0xe96],0x0
    56cb:	8d be 5e f1          	lea    di,[bp-0xea2]
    56cf:	16                   	push   ss
    56d0:	57                   	push   di
    56d1:	6a 01                	push   0x1
    56d3:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    56d7:	06                   	push   es
    56d8:	57                   	push   di
    56d9:	9a 95 28 66 58       	call   0x5866:0x2895
    56de:	08 c0                	or     al,al
    56e0:	75 0a                	jne    0x56ec
    56e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56e5:	06                   	push   es
    56e6:	57                   	push   di
    56e7:	9a 03 03 74 58       	call   0x5874:0x303
    56ec:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    56f0:	06                   	push   es
    56f1:	57                   	push   di
    56f2:	9a 3c 53 1e 57       	call   0x571e:0x533c
    56f7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    56fa:	99                   	cwd
    56fb:	bf 22 21             	mov    di,0x2122
    56fe:	9a 16 04 37 57       	call   0x5737:0x416
    5703:	8b f8                	mov    di,ax
    5705:	c1 e7 02             	shl    di,0x2
    5708:	ff b3 9e f1          	push   WORD PTR [bp+di-0xe62]
    570c:	ff b3 9c f1          	push   WORD PTR [bp+di-0xe64]
    5710:	bf 0d 21             	mov    di,0x210d
    5713:	0e                   	push   cs
    5714:	57                   	push   di
    5715:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5719:	06                   	push   es
    571a:	57                   	push   di
    571b:	9a 9b 3b 5c 57       	call   0x575c:0x3b9b
    5720:	89 c7                	mov    di,ax
    5722:	8e c2                	mov    es,dx
    5724:	06                   	push   es
    5725:	57                   	push   di
    5726:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5729:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    572d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5730:	99                   	cwd
    5731:	bf 22 21             	mov    di,0x2122
    5734:	9a 16 04 75 57       	call   0x5775:0x416
    5739:	8b f8                	mov    di,ax
    573b:	c1 e7 03             	shl    di,0x3
    573e:	ff b3 38 f3          	push   WORD PTR [bp+di-0xcc8]
    5742:	ff b3 36 f3          	push   WORD PTR [bp+di-0xcca]
    5746:	ff b3 34 f3          	push   WORD PTR [bp+di-0xccc]
    574a:	ff b3 32 f3          	push   WORD PTR [bp+di-0xcce]
    574e:	bf 2a 21             	mov    di,0x212a
    5751:	0e                   	push   cs
    5752:	57                   	push   di
    5753:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5757:	06                   	push   es
    5758:	57                   	push   di
    5759:	9a 9b 3b 9a 57       	call   0x579a:0x3b9b
    575e:	89 c7                	mov    di,ax
    5760:	8e c2                	mov    es,dx
    5762:	06                   	push   es
    5763:	57                   	push   di
    5764:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5767:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    576b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    576e:	99                   	cwd
    576f:	bf 22 21             	mov    di,0x2122
    5772:	9a 16 04 b3 57       	call   0x57b3:0x416
    5777:	8b f8                	mov    di,ax
    5779:	c1 e7 03             	shl    di,0x3
    577c:	ff b3 b8 f3          	push   WORD PTR [bp+di-0xc48]
    5780:	ff b3 b6 f3          	push   WORD PTR [bp+di-0xc4a]
    5784:	ff b3 b4 f3          	push   WORD PTR [bp+di-0xc4c]
    5788:	ff b3 b2 f3          	push   WORD PTR [bp+di-0xc4e]
    578c:	bf 3b 21             	mov    di,0x213b
    578f:	0e                   	push   cs
    5790:	57                   	push   di
    5791:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5795:	06                   	push   es
    5796:	57                   	push   di
    5797:	9a 9b 3b d8 57       	call   0x57d8:0x3b9b
    579c:	89 c7                	mov    di,ax
    579e:	8e c2                	mov    es,dx
    57a0:	06                   	push   es
    57a1:	57                   	push   di
    57a2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57a5:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    57a9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    57ac:	99                   	cwd
    57ad:	bf 22 21             	mov    di,0x2122
    57b0:	9a 16 04 8b 58       	call   0x588b:0x416
    57b5:	8b f8                	mov    di,ax
    57b7:	c1 e7 03             	shl    di,0x3
    57ba:	ff b3 78 f3          	push   WORD PTR [bp+di-0xc88]
    57be:	ff b3 76 f3          	push   WORD PTR [bp+di-0xc8a]
    57c2:	ff b3 74 f3          	push   WORD PTR [bp+di-0xc8c]
    57c6:	ff b3 72 f3          	push   WORD PTR [bp+di-0xc8e]
    57ca:	bf 44 21             	mov    di,0x2144
    57cd:	0e                   	push   cs
    57ce:	57                   	push   di
    57cf:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    57d3:	06                   	push   es
    57d4:	57                   	push   di
    57d5:	9a 9b 3b f0 57       	call   0x57f0:0x3b9b
    57da:	89 c7                	mov    di,ax
    57dc:	8e c2                	mov    es,dx
    57de:	06                   	push   es
    57df:	57                   	push   di
    57e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57e3:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    57e7:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    57eb:	06                   	push   es
    57ec:	57                   	push   di
    57ed:	9a a0 54 7f 58       	call   0x587f:0x54a0
    57f2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    57f5:	3b 86 6e f1          	cmp    ax,WORD PTR [bp-0xe92]
    57f9:	74 03                	je     0x57fe
    57fb:	e9 a8 fe             	jmp    0x56a6
    57fe:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5802:	83 c4 06             	add    sp,0x6
    5805:	b8 0b 58             	mov    ax,0x580b
    5808:	0e                   	push   cs
    5809:	50                   	push   ax
    580a:	cb                   	retf
    580b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    580e:	26 c4 bd e0 01       	les    di,DWORD PTR es:[di+0x1e0]
    5813:	89 be 70 f1          	mov    WORD PTR [bp-0xe90],di
    5817:	8c 86 72 f1          	mov    WORD PTR [bp-0xe8e],es
    581b:	b8 68 21             	mov    ax,0x2168
    581e:	0e                   	push   cs
    581f:	50                   	push   ax
    5820:	55                   	push   bp
    5821:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5825:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5829:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    582e:	eb 03                	jmp    0x5833
    5830:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    5833:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5836:	99                   	cwd
    5837:	89 86 60 f1          	mov    WORD PTR [bp-0xea0],ax
    583b:	89 96 62 f1          	mov    WORD PTR [bp-0xe9e],dx
    583f:	c6 86 64 f1 00       	mov    BYTE PTR [bp-0xe9c],0x0
    5844:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5847:	99                   	cwd
    5848:	89 86 68 f1          	mov    WORD PTR [bp-0xe98],ax
    584c:	89 96 6a f1          	mov    WORD PTR [bp-0xe96],dx
    5850:	c6 86 6c f1 00       	mov    BYTE PTR [bp-0xe94],0x0
    5855:	8d be 60 f1          	lea    di,[bp-0xea0]
    5859:	16                   	push   ss
    585a:	57                   	push   di
    585b:	6a 01                	push   0x1
    585d:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    5861:	06                   	push   es
    5862:	57                   	push   di
    5863:	9a 95 28 ef 59       	call   0x59ef:0x2895
    5868:	08 c0                	or     al,al
    586a:	75 0a                	jne    0x5876
    586c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    586f:	06                   	push   es
    5870:	57                   	push   di
    5871:	9a 03 03 fb 58       	call   0x58fb:0x303
    5876:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    587a:	06                   	push   es
    587b:	57                   	push   di
    587c:	9a 3c 53 b0 58       	call   0x58b0:0x533c
    5881:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5884:	99                   	cwd
    5885:	bf 60 21             	mov    di,0x2160
    5888:	9a 16 04 2e 59       	call   0x592e:0x416
    588d:	8b f8                	mov    di,ax
    588f:	c1 e7 03             	shl    di,0x3
    5892:	ff b3 00 f4          	push   WORD PTR [bp+di-0xc00]
    5896:	ff b3 fe f3          	push   WORD PTR [bp+di-0xc02]
    589a:	ff b3 fc f3          	push   WORD PTR [bp+di-0xc04]
    589e:	ff b3 fa f3          	push   WORD PTR [bp+di-0xc06]
    58a2:	bf 53 21             	mov    di,0x2153
    58a5:	0e                   	push   cs
    58a6:	57                   	push   di
    58a7:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    58ab:	06                   	push   es
    58ac:	57                   	push   di
    58ad:	9a 9b 3b c8 58       	call   0x58c8:0x3b9b
    58b2:	89 c7                	mov    di,ax
    58b4:	8e c2                	mov    es,dx
    58b6:	06                   	push   es
    58b7:	57                   	push   di
    58b8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    58bb:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    58bf:	c4 be 70 f1          	les    di,DWORD PTR [bp-0xe90]
    58c3:	06                   	push   es
    58c4:	57                   	push   di
    58c5:	9a a0 54 0c 5a       	call   0x5a0c:0x54a0
    58ca:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    58ce:	74 03                	je     0x58d3
    58d0:	e9 5d ff             	jmp    0x5830
    58d3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    58d7:	83 c4 06             	add    sp,0x6
    58da:	b8 e0 58             	mov    ax,0x58e0
    58dd:	0e                   	push   cs
    58de:	50                   	push   ax
    58df:	cb                   	retf
    58e0:	c9                   	leave
    58e1:	ca 06 00             	retf   0x6
    58e4:	fc                   	cld
    58e5:	ff                   	(bad)
    58e6:	ff                   	(bad)
    58e7:	ff                   	(bad)
    58e8:	ff                   	(bad)
    58e9:	ff                   	(bad)
    58ea:	ff                   	(bad)
    58eb:	ff 00                	inc    WORD PTR [bx+si]
    58ed:	00 00                	add    BYTE PTR [bx+si],al
    58ef:	00 06 54 61          	add    BYTE PTR ds:0x6154,al
    58f3:	75 78                	jne    0x596d
    58f5:	49                   	dec    cx
    58f6:	53                   	push   bx
    58f7:	00 00                	add    BYTE PTR [bx+si],al
    58f9:	2d 5a 13             	sub    ax,0x135a
    58fc:	59                   	pop    cx
    58fd:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
    5900:	73 75                	jae    0x5977
    5902:	6c                   	ins    BYTE PTR es:[di],dx
    5903:	74 61                	je     0x5966
    5905:	74 4e                	je     0x5955
    5907:	65 74 05             	gs je  0x590f
    590a:	49                   	dec    cx
    590b:	6d                   	ins    WORD PTR es:[di],dx
    590c:	70 6f                	jo     0x597d
    590e:	74 00                	je     0x5910
    5910:	00 ea                	add    dl,ch
    5912:	5a                   	pop    dx
    5913:	fd                   	std
    5914:	59                   	pop    cx
    5915:	00 00                	add    BYTE PTR [bx+si],al
    5917:	00 00                	add    BYTE PTR [bx+si],al
    5919:	fc                   	cld
    591a:	ff                   	(bad)
    591b:	ff                   	(bad)
    591c:	ff                   	(bad)
    591d:	ff                   	(bad)
    591e:	ff                   	(bad)
    591f:	ff                   	(bad)
    5920:	ff 00                	inc    WORD PTR [bx+si]
    5922:	00 c8                	add    al,cl
    5924:	42                   	inc    dx
    5925:	55                   	push   bp
    5926:	89 e5                	mov    bp,sp
    5928:	b8 6c 00             	mov    ax,0x6c
    592b:	9a 44 04 53 59       	call   0x5953:0x444
    5930:	83 ec 6c             	sub    sp,0x6c
    5933:	68 58 40             	push   0x4058
    5936:	68 51 c8             	push   0xc851
    5939:	68 85 eb             	push   0xeb85
    593c:	68 b8 1e             	push   0x1eb8
    593f:	6a 17                	push   0x17
    5941:	9a 69 0a 83 62       	call   0x6283:0xa69
    5946:	89 46 aa             	mov    WORD PTR [bp-0x56],ax
    5949:	8b 46 aa             	mov    ax,WORD PTR [bp-0x56]
    594c:	f7 d8                	neg    ax
    594e:	71 05                	jno    0x5955
    5950:	9a 3e 04 72 59       	call   0x5972:0x43e
    5955:	3d ff ff             	cmp    ax,0xffff
    5958:	7f 2b                	jg     0x5985
    595a:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    595d:	eb 03                	jmp    0x5962
    595f:	ff 46 ac             	inc    WORD PTR [bp-0x54]
    5962:	9b 2e d9 06 ec 58    	fld    DWORD PTR cs:0x58ec
    5968:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    596b:	99                   	cwd
    596c:	bf e4 58             	mov    di,0x58e4
    596f:	9a 16 04 32 5b       	call   0x5b32:0x416
    5974:	8b f8                	mov    di,ax
    5976:	c1 e7 03             	shl    di,0x3
    5979:	9b dd 5b f8          	fstp   QWORD PTR [bp+di-0x8]
    597d:	90                   	nop
    597e:	9b                   	fwait
    597f:	83 7e ac ff          	cmp    WORD PTR [bp-0x54],0xffff
    5983:	75 da                	jne    0x595f
    5985:	9b 2e d9 06 ec 58    	fld    DWORD PTR cs:0x58ec
    598b:	9b dd 5e c0          	fstp   QWORD PTR [bp-0x40]
    598f:	90                   	nop
    5990:	9b                   	fwait
    5991:	9b 2e d9 06 ec 58    	fld    DWORD PTR cs:0x58ec
    5997:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    599b:	90                   	nop
    599c:	9b                   	fwait
    599d:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    59a0:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    59a3:	b8 01 00             	mov    ax,0x1
    59a6:	3b 46 a8             	cmp    ax,WORD PTR [bp-0x58]
    59a9:	7e 03                	jle    0x59ae
    59ab:	e9 0a 03             	jmp    0x5cb8
    59ae:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    59b1:	eb 03                	jmp    0x59b6
    59b3:	ff 46 ae             	inc    WORD PTR [bp-0x52]
    59b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59b9:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    59be:	89 7e a4             	mov    WORD PTR [bp-0x5c],di
    59c1:	8c 46 a6             	mov    WORD PTR [bp-0x5a],es
    59c4:	b8 f7 58             	mov    ax,0x58f7
    59c7:	0e                   	push   cs
    59c8:	50                   	push   ax
    59c9:	55                   	push   bp
    59ca:	ff 36 58 18          	push   WORD PTR ds:0x1858
    59ce:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    59d2:	8b 46 ae             	mov    ax,WORD PTR [bp-0x52]
    59d5:	99                   	cwd
    59d6:	89 46 9c             	mov    WORD PTR [bp-0x64],ax
    59d9:	89 56 9e             	mov    WORD PTR [bp-0x62],dx
    59dc:	c6 46 a0 00          	mov    BYTE PTR [bp-0x60],0x0
    59e0:	8d 7e 9c             	lea    di,[bp-0x64]
    59e3:	16                   	push   ss
    59e4:	57                   	push   di
    59e5:	6a 00                	push   0x0
    59e7:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    59ea:	06                   	push   es
    59eb:	57                   	push   di
    59ec:	9a 95 28 8a 5a       	call   0x5a8a:0x2895
    59f1:	08 c0                	or     al,al
    59f3:	75 0a                	jne    0x59ff
    59f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59f8:	06                   	push   es
    59f9:	57                   	push   di
    59fa:	9a 03 03 98 5a       	call   0x5a98:0x303
    59ff:	bf f0 58             	mov    di,0x58f0
    5a02:	0e                   	push   cs
    5a03:	57                   	push   di
    5a04:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    5a07:	06                   	push   es
    5a08:	57                   	push   di
    5a09:	9a 9b 3b a7 5a       	call   0x5aa7:0x3b9b
    5a0e:	89 c7                	mov    di,ax
    5a10:	8e c2                	mov    es,dx
    5a12:	06                   	push   es
    5a13:	57                   	push   di
    5a14:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a17:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5a1b:	9b dd 5e b0          	fstp   QWORD PTR [bp-0x50]
    5a1f:	90                   	nop
    5a20:	9b                   	fwait
    5a21:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5a25:	83 c4 06             	add    sp,0x6
    5a28:	b8 2e 5a             	mov    ax,0x5a2e
    5a2b:	0e                   	push   cs
    5a2c:	50                   	push   ax
    5a2d:	cb                   	retf
    5a2e:	8b 46 ae             	mov    ax,WORD PTR [bp-0x52]
    5a31:	3b 46 14             	cmp    ax,WORD PTR [bp+0x14]
    5a34:	75 0d                	jne    0x5a43
    5a36:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    5a3a:	9b dd 5e c8          	fstp   QWORD PTR [bp-0x38]
    5a3e:	90                   	nop
    5a3f:	9b                   	fwait
    5a40:	e9 b6 00             	jmp    0x5af9
    5a43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a46:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    5a4b:	89 7e a4             	mov    WORD PTR [bp-0x5c],di
    5a4e:	8c 46 a6             	mov    WORD PTR [bp-0x5a],es
    5a51:	b8 0f 59             	mov    ax,0x590f
    5a54:	0e                   	push   cs
    5a55:	50                   	push   ax
    5a56:	55                   	push   bp
    5a57:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5a5b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5a5f:	8b 46 ae             	mov    ax,WORD PTR [bp-0x52]
    5a62:	99                   	cwd
    5a63:	89 46 94             	mov    WORD PTR [bp-0x6c],ax
    5a66:	89 56 96             	mov    WORD PTR [bp-0x6a],dx
    5a69:	c6 46 98 00          	mov    BYTE PTR [bp-0x68],0x0
    5a6d:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    5a70:	99                   	cwd
    5a71:	89 46 9c             	mov    WORD PTR [bp-0x64],ax
    5a74:	89 56 9e             	mov    WORD PTR [bp-0x62],dx
    5a77:	c6 46 a0 00          	mov    BYTE PTR [bp-0x60],0x0
    5a7b:	8d 7e 94             	lea    di,[bp-0x6c]
    5a7e:	16                   	push   ss
    5a7f:	57                   	push   di
    5a80:	6a 01                	push   0x1
    5a82:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    5a85:	06                   	push   es
    5a86:	57                   	push   di
    5a87:	9a 95 28 21 5e       	call   0x5e21:0x2895
    5a8c:	08 c0                	or     al,al
    5a8e:	75 0a                	jne    0x5a9a
    5a90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a93:	06                   	push   es
    5a94:	57                   	push   di
    5a95:	9a 03 03 c0 5d       	call   0x5dc0:0x303
    5a9a:	bf fd 58             	mov    di,0x58fd
    5a9d:	0e                   	push   cs
    5a9e:	57                   	push   di
    5a9f:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    5aa2:	06                   	push   es
    5aa3:	57                   	push   di
    5aa4:	9a 9b 3b c9 5a       	call   0x5ac9:0x3b9b
    5aa9:	89 c7                	mov    di,ax
    5aab:	8e c2                	mov    es,dx
    5aad:	06                   	push   es
    5aae:	57                   	push   di
    5aaf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ab2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5ab6:	9b dd 5e c0          	fstp   QWORD PTR [bp-0x40]
    5aba:	90                   	nop
    5abb:	9b                   	fwait
    5abc:	bf 09 59             	mov    di,0x5909
    5abf:	0e                   	push   cs
    5ac0:	57                   	push   di
    5ac1:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    5ac4:	06                   	push   es
    5ac5:	57                   	push   di
    5ac6:	9a 9b 3b 3f 5e       	call   0x5e3f:0x3b9b
    5acb:	89 c7                	mov    di,ax
    5acd:	8e c2                	mov    es,dx
    5acf:	06                   	push   es
    5ad0:	57                   	push   di
    5ad1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ad4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5ad8:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    5adc:	90                   	nop
    5add:	9b                   	fwait
    5ade:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5ae2:	83 c4 06             	add    sp,0x6
    5ae5:	b8 eb 5a             	mov    ax,0x5aeb
    5ae8:	0e                   	push   cs
    5ae9:	50                   	push   ax
    5aea:	cb                   	retf
    5aeb:	9b dd 46 c0          	fld    QWORD PTR [bp-0x40]
    5aef:	9b dc 46 b8          	fadd   QWORD PTR [bp-0x48]
    5af3:	9b dd 5e c8          	fstp   QWORD PTR [bp-0x38]
    5af7:	90                   	nop
    5af8:	9b 9b dd 46 c8       	fld    QWORD PTR [bp-0x38]
    5afd:	9b 2e d8 1e 15 59    	fcomp  DWORD PTR cs:0x5915
    5b03:	9b dd 7e a6          	fstsw  WORD PTR [bp-0x5a]
    5b07:	90                   	nop
    5b08:	9b                   	fwait
    5b09:	8a 66 a7             	mov    ah,BYTE PTR [bp-0x59]
    5b0c:	9e                   	sahf
    5b0d:	77 0f                	ja     0x5b1e
    5b0f:	9b 2e d9 06 15 59    	fld    DWORD PTR cs:0x5915
    5b15:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    5b19:	90                   	nop
    5b1a:	9b                   	fwait
    5b1b:	e9 09 01             	jmp    0x5c27
    5b1e:	9b dd 46 c8          	fld    QWORD PTR [bp-0x38]
    5b22:	9b dd 5e d0          	fstp   QWORD PTR [bp-0x30]
    5b26:	90                   	nop
    5b27:	9b                   	fwait
    5b28:	8b 46 aa             	mov    ax,WORD PTR [bp-0x56]
    5b2b:	f7 d8                	neg    ax
    5b2d:	71 05                	jno    0x5b34
    5b2f:	9a 3e 04 68 5b       	call   0x5b68:0x43e
    5b34:	3d ff ff             	cmp    ax,0xffff
    5b37:	7e 03                	jle    0x5b3c
    5b39:	e9 99 00             	jmp    0x5bd5
    5b3c:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    5b3f:	eb 03                	jmp    0x5b44
    5b41:	ff 46 ac             	inc    WORD PTR [bp-0x54]
    5b44:	9b dd 46 d0          	fld    QWORD PTR [bp-0x30]
    5b48:	9b 2e d8 1e 15 59    	fcomp  DWORD PTR cs:0x5915
    5b4e:	9b dd 7e a4          	fstsw  WORD PTR [bp-0x5c]
    5b52:	90                   	nop
    5b53:	9b                   	fwait
    5b54:	8a 66 a5             	mov    ah,BYTE PTR [bp-0x5b]
    5b57:	9e                   	sahf
    5b58:	76 72                	jbe    0x5bcc
    5b5a:	9b dd 46 d0          	fld    QWORD PTR [bp-0x30]
    5b5e:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    5b61:	99                   	cwd
    5b62:	bf 19 59             	mov    di,0x5919
    5b65:	9a 16 04 9f 5b       	call   0x5b9f:0x416
    5b6a:	8b f8                	mov    di,ax
    5b6c:	c1 e7 03             	shl    di,0x3
    5b6f:	9b dc 63 f8          	fsub   QWORD PTR [bp+di-0x8]
    5b73:	9b dd 5e d0          	fstp   QWORD PTR [bp-0x30]
    5b77:	90                   	nop
    5b78:	9b 9b dd 46 d0       	fld    QWORD PTR [bp-0x30]
    5b7d:	9b 2e d8 1e 15 59    	fcomp  DWORD PTR cs:0x5915
    5b83:	9b dd 7e a2          	fstsw  WORD PTR [bp-0x5e]
    5b87:	90                   	nop
    5b88:	9b                   	fwait
    5b89:	8a 66 a3             	mov    ah,BYTE PTR [bp-0x5d]
    5b8c:	9e                   	sahf
    5b8d:	72 1f                	jb     0x5bae
    5b8f:	9b 2e d9 06 15 59    	fld    DWORD PTR cs:0x5915
    5b95:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    5b98:	99                   	cwd
    5b99:	bf 19 59             	mov    di,0x5919
    5b9c:	9a 16 04 bf 5b       	call   0x5bbf:0x416
    5ba1:	8b f8                	mov    di,ax
    5ba3:	c1 e7 03             	shl    di,0x3
    5ba6:	9b dd 5b f8          	fstp   QWORD PTR [bp+di-0x8]
    5baa:	90                   	nop
    5bab:	9b                   	fwait
    5bac:	eb 1e                	jmp    0x5bcc
    5bae:	9b dd 46 d0          	fld    QWORD PTR [bp-0x30]
    5bb2:	9b d9 e0             	fchs
    5bb5:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    5bb8:	99                   	cwd
    5bb9:	bf 19 59             	mov    di,0x5919
    5bbc:	9a 16 04 fc 5b       	call   0x5bfc:0x416
    5bc1:	8b f8                	mov    di,ax
    5bc3:	c1 e7 03             	shl    di,0x3
    5bc6:	9b dd 5b f8          	fstp   QWORD PTR [bp+di-0x8]
    5bca:	90                   	nop
    5bcb:	9b                   	fwait
    5bcc:	83 7e ac ff          	cmp    WORD PTR [bp-0x54],0xffff
    5bd0:	74 03                	je     0x5bd5
    5bd2:	e9 6c ff             	jmp    0x5b41
    5bd5:	9b dd 46 d0          	fld    QWORD PTR [bp-0x30]
    5bd9:	9b 2e d8 1e 15 59    	fcomp  DWORD PTR cs:0x5915
    5bdf:	9b dd 7e a4          	fstsw  WORD PTR [bp-0x5c]
    5be3:	90                   	nop
    5be4:	9b                   	fwait
    5be5:	8a 66 a5             	mov    ah,BYTE PTR [bp-0x5b]
    5be8:	9e                   	sahf
    5be9:	76 30                	jbe    0x5c1b
    5beb:	9b dd 46 d0          	fld    QWORD PTR [bp-0x30]
    5bef:	9b dc 4e b0          	fmul   QWORD PTR [bp-0x50]
    5bf3:	9b 2e d9 06 21 59    	fld    DWORD PTR cs:0x5921
    5bf9:	9a b2 04 11 5c       	call   0x5c11:0x4b2
    5bfe:	83 ec 08             	sub    sp,0x8
    5c01:	89 e3                	mov    bx,sp
    5c03:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5c07:	90                   	nop
    5c08:	9b                   	fwait
    5c09:	9a a6 2f 02 6a       	call   0x6a02:0x2fa6
    5c0e:	9a 41 10 31 5c       	call   0x5c31:0x1041
    5c13:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    5c17:	90                   	nop
    5c18:	9b                   	fwait
    5c19:	eb 0c                	jmp    0x5c27
    5c1b:	9b 2e d9 06 15 59    	fld    DWORD PTR cs:0x5915
    5c21:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    5c25:	90                   	nop
    5c26:	9b                   	fwait
    5c27:	8b 46 aa             	mov    ax,WORD PTR [bp-0x56]
    5c2a:	f7 d8                	neg    ax
    5c2c:	71 05                	jno    0x5c33
    5c2e:	9a 3e 04 4b 5c       	call   0x5c4b:0x43e
    5c33:	3d fe ff             	cmp    ax,0xfffe
    5c36:	7f 44                	jg     0x5c7c
    5c38:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    5c3b:	eb 03                	jmp    0x5c40
    5c3d:	ff 46 ac             	inc    WORD PTR [bp-0x54]
    5c40:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    5c43:	05 01 00             	add    ax,0x1
    5c46:	71 05                	jno    0x5c4d
    5c48:	9a 3e 04 54 5c       	call   0x5c54:0x43e
    5c4d:	99                   	cwd
    5c4e:	bf 19 59             	mov    di,0x5919
    5c51:	9a 16 04 69 5c       	call   0x5c69:0x416
    5c56:	8b f8                	mov    di,ax
    5c58:	c1 e7 03             	shl    di,0x3
    5c5b:	9b dd 43 f8          	fld    QWORD PTR [bp+di-0x8]
    5c5f:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    5c62:	99                   	cwd
    5c63:	bf 19 59             	mov    di,0x5919
    5c66:	9a 16 04 bf 5c       	call   0x5cbf:0x416
    5c6b:	8b f8                	mov    di,ax
    5c6d:	c1 e7 03             	shl    di,0x3
    5c70:	9b dd 5b f8          	fstp   QWORD PTR [bp+di-0x8]
    5c74:	90                   	nop
    5c75:	9b                   	fwait
    5c76:	83 7e ac fe          	cmp    WORD PTR [bp-0x54],0xfffe
    5c7a:	75 c1                	jne    0x5c3d
    5c7c:	9b dd 46 c0          	fld    QWORD PTR [bp-0x40]
    5c80:	9b 2e d8 1e 15 59    	fcomp  DWORD PTR cs:0x5915
    5c86:	9b dd 7e a6          	fstsw  WORD PTR [bp-0x5a]
    5c8a:	90                   	nop
    5c8b:	9b                   	fwait
    5c8c:	8a 66 a7             	mov    ah,BYTE PTR [bp-0x59]
    5c8f:	9e                   	sahf
    5c90:	73 0f                	jae    0x5ca1
    5c92:	9b dd 46 c0          	fld    QWORD PTR [bp-0x40]
    5c96:	9b d9 e0             	fchs
    5c99:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    5c9d:	90                   	nop
    5c9e:	9b                   	fwait
    5c9f:	eb 0c                	jmp    0x5cad
    5ca1:	9b 2e d9 06 15 59    	fld    DWORD PTR cs:0x5915
    5ca7:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    5cab:	90                   	nop
    5cac:	9b                   	fwait
    5cad:	8b 46 ae             	mov    ax,WORD PTR [bp-0x52]
    5cb0:	3b 46 a8             	cmp    ax,WORD PTR [bp-0x58]
    5cb3:	74 03                	je     0x5cb8
    5cb5:	e9 fb fc             	jmp    0x59b3
    5cb8:	9b dd 46 b8          	fld    QWORD PTR [bp-0x48]
    5cbc:	9a 41 10 db 5d       	call   0x5ddb:0x1041
    5cc1:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    5cc5:	90                   	nop
    5cc6:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    5ccb:	90                   	nop
    5ccc:	9b                   	fwait
    5ccd:	c9                   	leave
    5cce:	ca 10 00             	retf   0x10
    5cd1:	0d 49 46             	or     ax,0x4649
    5cd4:	41                   	inc    cx
    5cd5:	4e                   	dec    si
    5cd6:	62 54 72             	bound  dx,DWORD PTR [si+0x72]
    5cd9:	61                   	popa
    5cda:	6e                   	outs   dx,BYTE PTR ds:[si]
    5cdb:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    5cde:	73 00                	jae    0x5ce0
    5ce0:	80 ff ff             	cmp    bh,0xff
    5ce3:	ff                   	(bad)
    5ce4:	7f 00                	jg     0x5ce6
    5ce6:	00 09                	add    BYTE PTR [bx+di],cl
    5ce8:	49                   	dec    cx
    5ce9:	46                   	inc    si
    5cea:	41                   	inc    cx
    5ceb:	53                   	push   bx
    5cec:	65 75 69             	gs jne 0x5d58
    5cef:	6c                   	ins    BYTE PTR es:[di],dx
    5cf0:	31 09                	xor    WORD PTR [bx+di],cx
    5cf2:	49                   	dec    cx
    5cf3:	46                   	inc    si
    5cf4:	41                   	inc    cx
    5cf5:	53                   	push   bx
    5cf6:	65 75 69             	gs jne 0x5d62
    5cf9:	6c                   	ins    BYTE PTR es:[di],dx
    5cfa:	32 09                	xor    cl,BYTE PTR [bx+di]
    5cfc:	49                   	dec    cx
    5cfd:	46                   	inc    si
    5cfe:	41                   	inc    cx
    5cff:	53                   	push   bx
    5d00:	65 75 69             	gs jne 0x5d6c
    5d03:	6c                   	ins    BYTE PTR es:[di],dx
    5d04:	33 09                	xor    cx,WORD PTR [bx+di]
    5d06:	49                   	dec    cx
    5d07:	46                   	inc    si
    5d08:	41                   	inc    cx
    5d09:	53                   	push   bx
    5d0a:	65 75 69             	gs jne 0x5d76
    5d0d:	6c                   	ins    BYTE PTR es:[di],dx
    5d0e:	34 09                	xor    al,0x9
    5d10:	49                   	dec    cx
    5d11:	46                   	inc    si
    5d12:	41                   	inc    cx
    5d13:	53                   	push   bx
    5d14:	65 75 69             	gs jne 0x5d80
    5d17:	6c                   	ins    BYTE PTR es:[di],dx
    5d18:	35 09 49             	xor    ax,0x4909
    5d1b:	46                   	inc    si
    5d1c:	41                   	inc    cx
    5d1d:	53                   	push   bx
    5d1e:	65 75 69             	gs jne 0x5d8a
    5d21:	6c                   	ins    BYTE PTR es:[di],dx
    5d22:	36 09 49 46          	or     WORD PTR ss:[bx+di+0x46],cx
    5d26:	41                   	inc    cx
    5d27:	53                   	push   bx
    5d28:	65 75 69             	gs jne 0x5d94
    5d2b:	6c                   	ins    BYTE PTR es:[di],dx
    5d2c:	37                   	aaa
    5d2d:	09 49 46             	or     WORD PTR [bx+di+0x46],cx
    5d30:	41                   	inc    cx
    5d31:	53                   	push   bx
    5d32:	65 75 69             	gs jne 0x5d9e
    5d35:	6c                   	ins    BYTE PTR es:[di],dx
    5d36:	38 09                	cmp    BYTE PTR [bx+di],cl
    5d38:	49                   	dec    cx
    5d39:	46                   	inc    si
    5d3a:	41                   	inc    cx
    5d3b:	53                   	push   bx
    5d3c:	65 75 69             	gs jne 0x5da8
    5d3f:	6c                   	ins    BYTE PTR es:[di],dx
    5d40:	39 0a                	cmp    WORD PTR [bp+si],cx
    5d42:	49                   	dec    cx
    5d43:	46                   	inc    si
    5d44:	41                   	inc    cx
    5d45:	53                   	push   bx
    5d46:	65 75 69             	gs jne 0x5db2
    5d49:	6c                   	ins    BYTE PTR es:[di],dx
    5d4a:	31 30                	xor    WORD PTR [bx+si],si
    5d4c:	09 49 46             	or     WORD PTR [bx+di+0x46],cx
    5d4f:	41                   	inc    cx
    5d50:	54                   	push   sp
    5d51:	61                   	popa
    5d52:	72 69                	jb     0x5dbd
    5d54:	66 31 09             	xor    DWORD PTR [bx+di],ecx
    5d57:	49                   	dec    cx
    5d58:	46                   	inc    si
    5d59:	41                   	inc    cx
    5d5a:	54                   	push   sp
    5d5b:	61                   	popa
    5d5c:	72 69                	jb     0x5dc7
    5d5e:	66 32 09             	data32 xor cl,BYTE PTR [bx+di]
    5d61:	49                   	dec    cx
    5d62:	46                   	inc    si
    5d63:	41                   	inc    cx
    5d64:	54                   	push   sp
    5d65:	61                   	popa
    5d66:	72 69                	jb     0x5dd1
    5d68:	66 33 09             	xor    ecx,DWORD PTR [bx+di]
    5d6b:	49                   	dec    cx
    5d6c:	46                   	inc    si
    5d6d:	41                   	inc    cx
    5d6e:	54                   	push   sp
    5d6f:	61                   	popa
    5d70:	72 69                	jb     0x5ddb
    5d72:	66 34 09             	data32 xor al,0x9
    5d75:	49                   	dec    cx
    5d76:	46                   	inc    si
    5d77:	41                   	inc    cx
    5d78:	54                   	push   sp
    5d79:	61                   	popa
    5d7a:	72 69                	jb     0x5de5
    5d7c:	66 35 09 49 46 41    	xor    eax,0x41464909
    5d82:	54                   	push   sp
    5d83:	61                   	popa
    5d84:	72 69                	jb     0x5def
    5d86:	66 36 09 49 46       	or     DWORD PTR ss:[bx+di+0x46],ecx
    5d8b:	41                   	inc    cx
    5d8c:	54                   	push   sp
    5d8d:	61                   	popa
    5d8e:	72 69                	jb     0x5df9
    5d90:	66 37                	data32 aaa
    5d92:	09 49 46             	or     WORD PTR [bx+di+0x46],cx
    5d95:	41                   	inc    cx
    5d96:	54                   	push   sp
    5d97:	61                   	popa
    5d98:	72 69                	jb     0x5e03
    5d9a:	66 38 09             	data32 cmp BYTE PTR [bx+di],cl
    5d9d:	49                   	dec    cx
    5d9e:	46                   	inc    si
    5d9f:	41                   	inc    cx
    5da0:	54                   	push   sp
    5da1:	61                   	popa
    5da2:	72 69                	jb     0x5e0d
    5da4:	66 39 0a             	cmp    DWORD PTR [bp+si],ecx
    5da7:	49                   	dec    cx
    5da8:	46                   	inc    si
    5da9:	41                   	inc    cx
    5daa:	54                   	push   sp
    5dab:	61                   	popa
    5dac:	72 69                	jb     0x5e17
    5dae:	66 31 30             	xor    DWORD PTR [bx+si],esi
    5db1:	0a 49 46             	or     cl,BYTE PTR [bx+di+0x46]
    5db4:	41                   	inc    cx
    5db5:	54                   	push   sp
    5db6:	61                   	popa
    5db7:	72 69                	jb     0x5e22
    5db9:	66 31 31             	xor    DWORD PTR [bx+di],esi
    5dbc:	00 00                	add    BYTE PTR [bx+si],al
    5dbe:	94                   	xchg   sp,ax
    5dbf:	61                   	popa
    5dc0:	2f                   	das
    5dc1:	5e                   	pop    si
    5dc2:	01 00                	add    WORD PTR [bx+si],ax
    5dc4:	00 00                	add    BYTE PTR [bx+si],al
    5dc6:	0b 00                	or     ax,WORD PTR [bx+si]
    5dc8:	00 00                	add    BYTE PTR [bx+si],al
    5dca:	01 00                	add    WORD PTR [bx+si],ax
    5dcc:	00 00                	add    BYTE PTR [bx+si],al
    5dce:	0a 00                	or     al,BYTE PTR [bx+si]
    5dd0:	00 00                	add    BYTE PTR [bx+si],al
    5dd2:	55                   	push   bp
    5dd3:	89 e5                	mov    bp,sp
    5dd5:	b8 cc 00             	mov    ax,0xcc
    5dd8:	9a 44 04 66 5e       	call   0x5e66:0x444
    5ddd:	81 ec cc 00          	sub    sp,0xcc
    5de1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5de4:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    5de9:	89 be 3c ff          	mov    WORD PTR [bp-0xc4],di
    5ded:	8c 86 3e ff          	mov    WORD PTR [bp-0xc2],es
    5df1:	b8 bc 5d             	mov    ax,0x5dbc
    5df4:	0e                   	push   cs
    5df5:	50                   	push   ax
    5df6:	55                   	push   bp
    5df7:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5dfb:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5dff:	c7 86 34 ff 01 00    	mov    WORD PTR [bp-0xcc],0x1
    5e05:	c7 86 36 ff 00 00    	mov    WORD PTR [bp-0xca],0x0
    5e0b:	c6 86 38 ff 00       	mov    BYTE PTR [bp-0xc8],0x0
    5e10:	8d be 34 ff          	lea    di,[bp-0xcc]
    5e14:	16                   	push   ss
    5e15:	57                   	push   di
    5e16:	6a 00                	push   0x0
    5e18:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5e1c:	06                   	push   es
    5e1d:	57                   	push   di
    5e1e:	9a 95 28 51 63       	call   0x6351:0x2895
    5e23:	08 c0                	or     al,al
    5e25:	75 0a                	jne    0x5e31
    5e27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e2a:	06                   	push   es
    5e2b:	57                   	push   di
    5e2c:	9a 03 03 56 62       	call   0x6256:0x303
    5e31:	bf d1 5c             	mov    di,0x5cd1
    5e34:	0e                   	push   cs
    5e35:	57                   	push   di
    5e36:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5e3a:	06                   	push   es
    5e3b:	57                   	push   di
    5e3c:	9a 43 3c 80 5e       	call   0x5e80:0x3c43
    5e41:	89 86 40 ff          	mov    WORD PTR [bp-0xc0],ax
    5e45:	89 96 42 ff          	mov    WORD PTR [bp-0xbe],dx
    5e49:	8b 86 40 ff          	mov    ax,WORD PTR [bp-0xc0]
    5e4d:	0b 86 42 ff          	or     ax,WORD PTR [bp-0xbe]
    5e51:	74 1a                	je     0x5e6d
    5e53:	c4 be 40 ff          	les    di,DWORD PTR [bp-0xc0]
    5e57:	06                   	push   es
    5e58:	57                   	push   di
    5e59:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e5c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5e60:	bf df 5c             	mov    di,0x5cdf
    5e63:	9a 16 04 9f 61       	call   0x619f:0x416
    5e68:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    5e6b:	eb 05                	jmp    0x5e72
    5e6d:	c7 46 f6 08 00       	mov    WORD PTR [bp-0xa],0x8
    5e72:	bf e7 5c             	mov    di,0x5ce7
    5e75:	0e                   	push   cs
    5e76:	57                   	push   di
    5e77:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5e7b:	06                   	push   es
    5e7c:	57                   	push   di
    5e7d:	9a 9b 3b a3 5e       	call   0x5ea3:0x3b9b
    5e82:	89 c7                	mov    di,ax
    5e84:	8e c2                	mov    es,dx
    5e86:	06                   	push   es
    5e87:	57                   	push   di
    5e88:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e8b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5e8f:	9b dd 5e a6          	fstp   QWORD PTR [bp-0x5a]
    5e93:	90                   	nop
    5e94:	9b                   	fwait
    5e95:	bf f1 5c             	mov    di,0x5cf1
    5e98:	0e                   	push   cs
    5e99:	57                   	push   di
    5e9a:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5e9e:	06                   	push   es
    5e9f:	57                   	push   di
    5ea0:	9a 9b 3b c6 5e       	call   0x5ec6:0x3b9b
    5ea5:	89 c7                	mov    di,ax
    5ea7:	8e c2                	mov    es,dx
    5ea9:	06                   	push   es
    5eaa:	57                   	push   di
    5eab:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5eae:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5eb2:	9b dd 5e ae          	fstp   QWORD PTR [bp-0x52]
    5eb6:	90                   	nop
    5eb7:	9b                   	fwait
    5eb8:	bf fb 5c             	mov    di,0x5cfb
    5ebb:	0e                   	push   cs
    5ebc:	57                   	push   di
    5ebd:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5ec1:	06                   	push   es
    5ec2:	57                   	push   di
    5ec3:	9a 9b 3b e9 5e       	call   0x5ee9:0x3b9b
    5ec8:	89 c7                	mov    di,ax
    5eca:	8e c2                	mov    es,dx
    5ecc:	06                   	push   es
    5ecd:	57                   	push   di
    5ece:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ed1:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5ed5:	9b dd 5e b6          	fstp   QWORD PTR [bp-0x4a]
    5ed9:	90                   	nop
    5eda:	9b                   	fwait
    5edb:	bf 05 5d             	mov    di,0x5d05
    5ede:	0e                   	push   cs
    5edf:	57                   	push   di
    5ee0:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5ee4:	06                   	push   es
    5ee5:	57                   	push   di
    5ee6:	9a 9b 3b 0c 5f       	call   0x5f0c:0x3b9b
    5eeb:	89 c7                	mov    di,ax
    5eed:	8e c2                	mov    es,dx
    5eef:	06                   	push   es
    5ef0:	57                   	push   di
    5ef1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ef4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5ef8:	9b dd 5e be          	fstp   QWORD PTR [bp-0x42]
    5efc:	90                   	nop
    5efd:	9b                   	fwait
    5efe:	bf 0f 5d             	mov    di,0x5d0f
    5f01:	0e                   	push   cs
    5f02:	57                   	push   di
    5f03:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5f07:	06                   	push   es
    5f08:	57                   	push   di
    5f09:	9a 9b 3b 2f 5f       	call   0x5f2f:0x3b9b
    5f0e:	89 c7                	mov    di,ax
    5f10:	8e c2                	mov    es,dx
    5f12:	06                   	push   es
    5f13:	57                   	push   di
    5f14:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f17:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5f1b:	9b dd 5e c6          	fstp   QWORD PTR [bp-0x3a]
    5f1f:	90                   	nop
    5f20:	9b                   	fwait
    5f21:	bf 19 5d             	mov    di,0x5d19
    5f24:	0e                   	push   cs
    5f25:	57                   	push   di
    5f26:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5f2a:	06                   	push   es
    5f2b:	57                   	push   di
    5f2c:	9a 9b 3b 58 5f       	call   0x5f58:0x3b9b
    5f31:	89 c7                	mov    di,ax
    5f33:	8e c2                	mov    es,dx
    5f35:	06                   	push   es
    5f36:	57                   	push   di
    5f37:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f3a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5f3e:	9b dd 5e ce          	fstp   QWORD PTR [bp-0x32]
    5f42:	90                   	nop
    5f43:	9b                   	fwait
    5f44:	83 7e f6 07          	cmp    WORD PTR [bp-0xa],0x7
    5f48:	7e 23                	jle    0x5f6d
    5f4a:	bf 23 5d             	mov    di,0x5d23
    5f4d:	0e                   	push   cs
    5f4e:	57                   	push   di
    5f4f:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5f53:	06                   	push   es
    5f54:	57                   	push   di
    5f55:	9a 9b 3b 81 5f       	call   0x5f81:0x3b9b
    5f5a:	89 c7                	mov    di,ax
    5f5c:	8e c2                	mov    es,dx
    5f5e:	06                   	push   es
    5f5f:	57                   	push   di
    5f60:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f63:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5f67:	9b dd 5e d6          	fstp   QWORD PTR [bp-0x2a]
    5f6b:	90                   	nop
    5f6c:	9b                   	fwait
    5f6d:	83 7e f6 08          	cmp    WORD PTR [bp-0xa],0x8
    5f71:	7e 23                	jle    0x5f96
    5f73:	bf 2d 5d             	mov    di,0x5d2d
    5f76:	0e                   	push   cs
    5f77:	57                   	push   di
    5f78:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5f7c:	06                   	push   es
    5f7d:	57                   	push   di
    5f7e:	9a 9b 3b aa 5f       	call   0x5faa:0x3b9b
    5f83:	89 c7                	mov    di,ax
    5f85:	8e c2                	mov    es,dx
    5f87:	06                   	push   es
    5f88:	57                   	push   di
    5f89:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f8c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5f90:	9b dd 5e de          	fstp   QWORD PTR [bp-0x22]
    5f94:	90                   	nop
    5f95:	9b                   	fwait
    5f96:	83 7e f6 09          	cmp    WORD PTR [bp-0xa],0x9
    5f9a:	7e 23                	jle    0x5fbf
    5f9c:	bf 37 5d             	mov    di,0x5d37
    5f9f:	0e                   	push   cs
    5fa0:	57                   	push   di
    5fa1:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5fa5:	06                   	push   es
    5fa6:	57                   	push   di
    5fa7:	9a 9b 3b d3 5f       	call   0x5fd3:0x3b9b
    5fac:	89 c7                	mov    di,ax
    5fae:	8e c2                	mov    es,dx
    5fb0:	06                   	push   es
    5fb1:	57                   	push   di
    5fb2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5fb5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5fb9:	9b dd 5e e6          	fstp   QWORD PTR [bp-0x1a]
    5fbd:	90                   	nop
    5fbe:	9b                   	fwait
    5fbf:	83 7e f6 0a          	cmp    WORD PTR [bp-0xa],0xa
    5fc3:	7e 23                	jle    0x5fe8
    5fc5:	bf 41 5d             	mov    di,0x5d41
    5fc8:	0e                   	push   cs
    5fc9:	57                   	push   di
    5fca:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5fce:	06                   	push   es
    5fcf:	57                   	push   di
    5fd0:	9a 9b 3b f6 5f       	call   0x5ff6:0x3b9b
    5fd5:	89 c7                	mov    di,ax
    5fd7:	8e c2                	mov    es,dx
    5fd9:	06                   	push   es
    5fda:	57                   	push   di
    5fdb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5fde:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5fe2:	9b dd 5e ee          	fstp   QWORD PTR [bp-0x12]
    5fe6:	90                   	nop
    5fe7:	9b                   	fwait
    5fe8:	bf 4c 5d             	mov    di,0x5d4c
    5feb:	0e                   	push   cs
    5fec:	57                   	push   di
    5fed:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    5ff1:	06                   	push   es
    5ff2:	57                   	push   di
    5ff3:	9a 9b 3b 1a 60       	call   0x601a:0x3b9b
    5ff8:	89 c7                	mov    di,ax
    5ffa:	8e c2                	mov    es,dx
    5ffc:	06                   	push   es
    5ffd:	57                   	push   di
    5ffe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6001:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6005:	9b dd 9e 4e ff       	fstp   QWORD PTR [bp-0xb2]
    600a:	90                   	nop
    600b:	9b                   	fwait
    600c:	bf 56 5d             	mov    di,0x5d56
    600f:	0e                   	push   cs
    6010:	57                   	push   di
    6011:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    6015:	06                   	push   es
    6016:	57                   	push   di
    6017:	9a 9b 3b 3e 60       	call   0x603e:0x3b9b
    601c:	89 c7                	mov    di,ax
    601e:	8e c2                	mov    es,dx
    6020:	06                   	push   es
    6021:	57                   	push   di
    6022:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6025:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6029:	9b dd 9e 56 ff       	fstp   QWORD PTR [bp-0xaa]
    602e:	90                   	nop
    602f:	9b                   	fwait
    6030:	bf 60 5d             	mov    di,0x5d60
    6033:	0e                   	push   cs
    6034:	57                   	push   di
    6035:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    6039:	06                   	push   es
    603a:	57                   	push   di
    603b:	9a 9b 3b 62 60       	call   0x6062:0x3b9b
    6040:	89 c7                	mov    di,ax
    6042:	8e c2                	mov    es,dx
    6044:	06                   	push   es
    6045:	57                   	push   di
    6046:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6049:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    604d:	9b dd 9e 5e ff       	fstp   QWORD PTR [bp-0xa2]
    6052:	90                   	nop
    6053:	9b                   	fwait
    6054:	bf 6a 5d             	mov    di,0x5d6a
    6057:	0e                   	push   cs
    6058:	57                   	push   di
    6059:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    605d:	06                   	push   es
    605e:	57                   	push   di
    605f:	9a 9b 3b 86 60       	call   0x6086:0x3b9b
    6064:	89 c7                	mov    di,ax
    6066:	8e c2                	mov    es,dx
    6068:	06                   	push   es
    6069:	57                   	push   di
    606a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    606d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6071:	9b dd 9e 66 ff       	fstp   QWORD PTR [bp-0x9a]
    6076:	90                   	nop
    6077:	9b                   	fwait
    6078:	bf 74 5d             	mov    di,0x5d74
    607b:	0e                   	push   cs
    607c:	57                   	push   di
    607d:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    6081:	06                   	push   es
    6082:	57                   	push   di
    6083:	9a 9b 3b aa 60       	call   0x60aa:0x3b9b
    6088:	89 c7                	mov    di,ax
    608a:	8e c2                	mov    es,dx
    608c:	06                   	push   es
    608d:	57                   	push   di
    608e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6091:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6095:	9b dd 9e 6e ff       	fstp   QWORD PTR [bp-0x92]
    609a:	90                   	nop
    609b:	9b                   	fwait
    609c:	bf 7e 5d             	mov    di,0x5d7e
    609f:	0e                   	push   cs
    60a0:	57                   	push   di
    60a1:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    60a5:	06                   	push   es
    60a6:	57                   	push   di
    60a7:	9a 9b 3b ce 60       	call   0x60ce:0x3b9b
    60ac:	89 c7                	mov    di,ax
    60ae:	8e c2                	mov    es,dx
    60b0:	06                   	push   es
    60b1:	57                   	push   di
    60b2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    60b5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    60b9:	9b dd 9e 76 ff       	fstp   QWORD PTR [bp-0x8a]
    60be:	90                   	nop
    60bf:	9b                   	fwait
    60c0:	bf 88 5d             	mov    di,0x5d88
    60c3:	0e                   	push   cs
    60c4:	57                   	push   di
    60c5:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    60c9:	06                   	push   es
    60ca:	57                   	push   di
    60cb:	9a 9b 3b f8 60       	call   0x60f8:0x3b9b
    60d0:	89 c7                	mov    di,ax
    60d2:	8e c2                	mov    es,dx
    60d4:	06                   	push   es
    60d5:	57                   	push   di
    60d6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    60d9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    60dd:	9b dd 9e 7e ff       	fstp   QWORD PTR [bp-0x82]
    60e2:	90                   	nop
    60e3:	9b                   	fwait
    60e4:	83 7e f6 07          	cmp    WORD PTR [bp-0xa],0x7
    60e8:	7e 23                	jle    0x610d
    60ea:	bf 92 5d             	mov    di,0x5d92
    60ed:	0e                   	push   cs
    60ee:	57                   	push   di
    60ef:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    60f3:	06                   	push   es
    60f4:	57                   	push   di
    60f5:	9a 9b 3b 21 61       	call   0x6121:0x3b9b
    60fa:	89 c7                	mov    di,ax
    60fc:	8e c2                	mov    es,dx
    60fe:	06                   	push   es
    60ff:	57                   	push   di
    6100:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6103:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6107:	9b dd 5e 86          	fstp   QWORD PTR [bp-0x7a]
    610b:	90                   	nop
    610c:	9b                   	fwait
    610d:	83 7e f6 08          	cmp    WORD PTR [bp-0xa],0x8
    6111:	7e 23                	jle    0x6136
    6113:	bf 9c 5d             	mov    di,0x5d9c
    6116:	0e                   	push   cs
    6117:	57                   	push   di
    6118:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    611c:	06                   	push   es
    611d:	57                   	push   di
    611e:	9a 9b 3b 4a 61       	call   0x614a:0x3b9b
    6123:	89 c7                	mov    di,ax
    6125:	8e c2                	mov    es,dx
    6127:	06                   	push   es
    6128:	57                   	push   di
    6129:	26 c4 3d             	les    di,DWORD PTR es:[di]
    612c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6130:	9b dd 5e 8e          	fstp   QWORD PTR [bp-0x72]
    6134:	90                   	nop
    6135:	9b                   	fwait
    6136:	83 7e f6 09          	cmp    WORD PTR [bp-0xa],0x9
    613a:	7e 23                	jle    0x615f
    613c:	bf a6 5d             	mov    di,0x5da6
    613f:	0e                   	push   cs
    6140:	57                   	push   di
    6141:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    6145:	06                   	push   es
    6146:	57                   	push   di
    6147:	9a 9b 3b 73 61       	call   0x6173:0x3b9b
    614c:	89 c7                	mov    di,ax
    614e:	8e c2                	mov    es,dx
    6150:	06                   	push   es
    6151:	57                   	push   di
    6152:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6155:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6159:	9b dd 5e 96          	fstp   QWORD PTR [bp-0x6a]
    615d:	90                   	nop
    615e:	9b                   	fwait
    615f:	83 7e f6 0a          	cmp    WORD PTR [bp-0xa],0xa
    6163:	7e 23                	jle    0x6188
    6165:	bf b1 5d             	mov    di,0x5db1
    6168:	0e                   	push   cs
    6169:	57                   	push   di
    616a:	c4 be 3c ff          	les    di,DWORD PTR [bp-0xc4]
    616e:	06                   	push   es
    616f:	57                   	push   di
    6170:	9a 9b 3b 6e 63       	call   0x636e:0x3b9b
    6175:	89 c7                	mov    di,ax
    6177:	8e c2                	mov    es,dx
    6179:	06                   	push   es
    617a:	57                   	push   di
    617b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    617e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6182:	9b dd 5e 9e          	fstp   QWORD PTR [bp-0x62]
    6186:	90                   	nop
    6187:	9b                   	fwait
    6188:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    618c:	83 c4 06             	add    sp,0x6
    618f:	b8 95 61             	mov    ax,0x6195
    6192:	0e                   	push   cs
    6193:	50                   	push   ax
    6194:	cb                   	retf
    6195:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    6198:	99                   	cwd
    6199:	bf c2 5d             	mov    di,0x5dc2
    619c:	9a 16 04 bd 61       	call   0x61bd:0x416
    61a1:	8b f8                	mov    di,ax
    61a3:	c1 e7 03             	shl    di,0x3
    61a6:	9b dd 83 46 ff       	fld    QWORD PTR [bp+di-0xba]
    61ab:	9b dd 9e 46 ff       	fstp   QWORD PTR [bp-0xba]
    61b0:	90                   	nop
    61b1:	9b                   	fwait
    61b2:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    61b5:	2d 01 00             	sub    ax,0x1
    61b8:	71 05                	jno    0x61bf
    61ba:	9a 3e 04 dd 61       	call   0x61dd:0x43e
    61bf:	3d 01 00             	cmp    ax,0x1
    61c2:	7c 57                	jl     0x621b
    61c4:	89 86 44 ff          	mov    WORD PTR [bp-0xbc],ax
    61c8:	eb 04                	jmp    0x61ce
    61ca:	ff 8e 44 ff          	dec    WORD PTR [bp-0xbc]
    61ce:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    61d2:	8b 86 44 ff          	mov    ax,WORD PTR [bp-0xbc]
    61d6:	99                   	cwd
    61d7:	bf ca 5d             	mov    di,0x5dca
    61da:	9a 16 04 01 62       	call   0x6201:0x416
    61df:	8b f8                	mov    di,ax
    61e1:	c1 e7 03             	shl    di,0x3
    61e4:	9b dc 5b 9e          	fcomp  QWORD PTR [bp+di-0x62]
    61e8:	9b dd be 3e ff       	fstsw  WORD PTR [bp-0xc2]
    61ed:	90                   	nop
    61ee:	9b                   	fwait
    61ef:	8a a6 3f ff          	mov    ah,BYTE PTR [bp-0xc1]
    61f3:	9e                   	sahf
    61f4:	73 1e                	jae    0x6214
    61f6:	8b 86 44 ff          	mov    ax,WORD PTR [bp-0xbc]
    61fa:	99                   	cwd
    61fb:	bf c2 5d             	mov    di,0x5dc2
    61fe:	9a 16 04 6d 62       	call   0x626d:0x416
    6203:	8b f8                	mov    di,ax
    6205:	c1 e7 03             	shl    di,0x3
    6208:	9b dd 83 46 ff       	fld    QWORD PTR [bp+di-0xba]
    620d:	9b dd 9e 46 ff       	fstp   QWORD PTR [bp-0xba]
    6212:	90                   	nop
    6213:	9b                   	fwait
    6214:	83 be 44 ff 01       	cmp    WORD PTR [bp-0xbc],0x1
    6219:	75 af                	jne    0x61ca
    621b:	9b dd 86 46 ff       	fld    QWORD PTR [bp-0xba]
    6220:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    6224:	90                   	nop
    6225:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    622a:	90                   	nop
    622b:	9b                   	fwait
    622c:	c9                   	leave
    622d:	ca 0c 00             	retf   0xc
    6230:	fe                   	(bad)
    6231:	ff                   	(bad)
    6232:	ff                   	(bad)
    6233:	ff                   	(bad)
    6234:	ff                   	(bad)
    6235:	ff                   	(bad)
    6236:	ff                   	(bad)
    6237:	ff 00                	inc    WORD PTR [bx+si]
    6239:	00 00                	add    BYTE PTR [bx+si],al
    623b:	00 0b                	add    BYTE PTR [bp+di],cl
    623d:	52                   	push   dx
    623e:	65 73 75             	gs jae 0x62b6
    6241:	6c                   	ins    BYTE PTR es:[di],dx
    6242:	74 61                	je     0x62a5
    6244:	74 4e                	je     0x6294
    6246:	65 74 05             	gs je  0x624e
    6249:	49                   	dec    cx
    624a:	6d                   	ins    WORD PTR es:[di],dx
    624b:	70 6f                	jo     0x62bc
    624d:	74 03                	je     0x6252
    624f:	49                   	dec    cx
    6250:	46                   	inc    si
    6251:	41                   	inc    cx
    6252:	00 00                	add    BYTE PTR [bx+si],al
    6254:	33 64 5f             	xor    sp,WORD PTR [si+0x5f]
    6257:	63 00                	arpl   WORD PTR [bx+si],ax
    6259:	00 00                	add    BYTE PTR [bx+si],al
    625b:	00 fe                	add    dh,bh
    625d:	ff                   	(bad)
    625e:	ff                   	(bad)
    625f:	ff                   	(bad)
    6260:	ff                   	(bad)
    6261:	ff                   	(bad)
    6262:	ff                   	(bad)
    6263:	ff 55 89             	call   WORD PTR [di-0x77]
    6266:	e5 b8                	in     ax,0xb8
    6268:	6c                   	ins    BYTE PTR es:[di],dx
    6269:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    626d:	92                   	xchg   dx,ax
    626e:	62 83 ec 6c          	bound  ax,DWORD PTR [bp+di+0x6cec]
    6272:	68 42 40             	push   0x4042
    6275:	68 33 d3             	push   0xd333
    6278:	68 33 33             	push   0x3333
    627b:	68 33 33             	push   0x3333
    627e:	6a 0f                	push   0xf
    6280:	9a 69 0a fc 7d       	call   0x7dfc:0xa69
    6285:	89 46 aa             	mov    WORD PTR [bp-0x56],ax
    6288:	8b 46 aa             	mov    ax,WORD PTR [bp-0x56]
    628b:	f7 d8                	neg    ax
    628d:	71 05                	jno    0x6294
    628f:	9a 3e 04 b1 62       	call   0x62b1:0x43e
    6294:	3d ff ff             	cmp    ax,0xffff
    6297:	7f 2b                	jg     0x62c4
    6299:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    629c:	eb 03                	jmp    0x62a1
    629e:	ff 46 ac             	inc    WORD PTR [bp-0x54]
    62a1:	9b 2e d9 06 38 62    	fld    DWORD PTR cs:0x6238
    62a7:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    62aa:	99                   	cwd
    62ab:	bf 30 62             	mov    di,0x6230
    62ae:	9a 16 04 4a 64       	call   0x644a:0x416
    62b3:	8b f8                	mov    di,ax
    62b5:	c1 e7 03             	shl    di,0x3
    62b8:	9b dd 5b f8          	fstp   QWORD PTR [bp+di-0x8]
    62bc:	90                   	nop
    62bd:	9b                   	fwait
    62be:	83 7e ac ff          	cmp    WORD PTR [bp-0x54],0xffff
    62c2:	75 da                	jne    0x629e
    62c4:	9b 2e d9 06 38 62    	fld    DWORD PTR cs:0x6238
    62ca:	9b dd 5e b0          	fstp   QWORD PTR [bp-0x50]
    62ce:	90                   	nop
    62cf:	9b                   	fwait
    62d0:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    62d3:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    62d6:	b8 01 00             	mov    ax,0x1
    62d9:	3b 46 a8             	cmp    ax,WORD PTR [bp-0x58]
    62dc:	7e 03                	jle    0x62e1
    62de:	e9 a2 02             	jmp    0x6583
    62e1:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    62e4:	eb 03                	jmp    0x62e9
    62e6:	ff 46 ae             	inc    WORD PTR [bp-0x52]
    62e9:	8b 46 ae             	mov    ax,WORD PTR [bp-0x52]
    62ec:	3b 46 14             	cmp    ax,WORD PTR [bp+0x14]
    62ef:	75 19                	jne    0x630a
    62f1:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    62f5:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    62f9:	90                   	nop
    62fa:	9b                   	fwait
    62fb:	9b 2e d9 06 38 62    	fld    DWORD PTR cs:0x6238
    6301:	9b dd 5e c8          	fstp   QWORD PTR [bp-0x38]
    6305:	90                   	nop
    6306:	9b                   	fwait
    6307:	e9 2a 01             	jmp    0x6434
    630a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    630d:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    6312:	89 7e a4             	mov    WORD PTR [bp-0x5c],di
    6315:	8c 46 a6             	mov    WORD PTR [bp-0x5a],es
    6318:	b8 52 62             	mov    ax,0x6252
    631b:	0e                   	push   cs
    631c:	50                   	push   ax
    631d:	55                   	push   bp
    631e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6322:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6326:	8b 46 ae             	mov    ax,WORD PTR [bp-0x52]
    6329:	99                   	cwd
    632a:	89 46 94             	mov    WORD PTR [bp-0x6c],ax
    632d:	89 56 96             	mov    WORD PTR [bp-0x6a],dx
    6330:	c6 46 98 00          	mov    BYTE PTR [bp-0x68],0x0
    6334:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    6337:	99                   	cwd
    6338:	89 46 9c             	mov    WORD PTR [bp-0x64],ax
    633b:	89 56 9e             	mov    WORD PTR [bp-0x62],dx
    633e:	c6 46 a0 00          	mov    BYTE PTR [bp-0x60],0x0
    6342:	8d 7e 94             	lea    di,[bp-0x6c]
    6345:	16                   	push   ss
    6346:	57                   	push   di
    6347:	6a 01                	push   0x1
    6349:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    634c:	06                   	push   es
    634d:	57                   	push   di
    634e:	9a 95 28 4e 67       	call   0x674e:0x2895
    6353:	08 c0                	or     al,al
    6355:	75 0a                	jne    0x6361
    6357:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    635a:	06                   	push   es
    635b:	57                   	push   di
    635c:	9a 03 03 ef 63       	call   0x63ef:0x303
    6361:	bf 3c 62             	mov    di,0x623c
    6364:	0e                   	push   cs
    6365:	57                   	push   di
    6366:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    6369:	06                   	push   es
    636a:	57                   	push   di
    636b:	9a 9b 3b 90 63       	call   0x6390:0x3b9b
    6370:	89 c7                	mov    di,ax
    6372:	8e c2                	mov    es,dx
    6374:	06                   	push   es
    6375:	57                   	push   di
    6376:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6379:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    637d:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    6381:	90                   	nop
    6382:	9b                   	fwait
    6383:	bf 48 62             	mov    di,0x6248
    6386:	0e                   	push   cs
    6387:	57                   	push   di
    6388:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    638b:	06                   	push   es
    638c:	57                   	push   di
    638d:	9a 9b 3b b2 63       	call   0x63b2:0x3b9b
    6392:	89 c7                	mov    di,ax
    6394:	8e c2                	mov    es,dx
    6396:	06                   	push   es
    6397:	57                   	push   di
    6398:	26 c4 3d             	les    di,DWORD PTR es:[di]
    639b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    639f:	9b dd 5e d0          	fstp   QWORD PTR [bp-0x30]
    63a3:	90                   	nop
    63a4:	9b                   	fwait
    63a5:	bf 4e 62             	mov    di,0x624e
    63a8:	0e                   	push   cs
    63a9:	57                   	push   di
    63aa:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
    63ad:	06                   	push   es
    63ae:	57                   	push   di
    63af:	9a 9b 3b 6c 67       	call   0x676c:0x3b9b
    63b4:	89 c7                	mov    di,ax
    63b6:	8e c2                	mov    es,dx
    63b8:	06                   	push   es
    63b9:	57                   	push   di
    63ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    63bd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    63c1:	9b dd 5e c8          	fstp   QWORD PTR [bp-0x38]
    63c5:	90                   	nop
    63c6:	9b 9b dd 46 d8       	fld    QWORD PTR [bp-0x28]
    63cb:	9b dc 46 d0          	fadd   QWORD PTR [bp-0x30]
    63cf:	9b dd 5e c0          	fstp   QWORD PTR [bp-0x40]
    63d3:	90                   	nop
    63d4:	9b                   	fwait
    63d5:	ff 76 ae             	push   WORD PTR [bp-0x52]
    63d8:	ff 76 12             	push   WORD PTR [bp+0x12]
    63db:	ff 76 c6             	push   WORD PTR [bp-0x3a]
    63de:	ff 76 c4             	push   WORD PTR [bp-0x3c]
    63e1:	ff 76 c2             	push   WORD PTR [bp-0x3e]
    63e4:	ff 76 c0             	push   WORD PTR [bp-0x40]
    63e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63ea:	06                   	push   es
    63eb:	57                   	push   di
    63ec:	9a 25 59 f5 65       	call   0x65f5:0x5925
    63f1:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    63f5:	90                   	nop
    63f6:	9b 9b dd 46 b8       	fld    QWORD PTR [bp-0x48]
    63fb:	9b dc 5e c8          	fcomp  QWORD PTR [bp-0x38]
    63ff:	9b dd 7e a2          	fstsw  WORD PTR [bp-0x5e]
    6403:	90                   	nop
    6404:	9b                   	fwait
    6405:	8a 66 a3             	mov    ah,BYTE PTR [bp-0x5d]
    6408:	9e                   	sahf
    6409:	76 10                	jbe    0x641b
    640b:	9b dd 46 b8          	fld    QWORD PTR [bp-0x48]
    640f:	9b dc 66 c8          	fsub   QWORD PTR [bp-0x38]
    6413:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    6417:	90                   	nop
    6418:	9b                   	fwait
    6419:	eb 0c                	jmp    0x6427
    641b:	9b 2e d9 06 38 62    	fld    DWORD PTR cs:0x6238
    6421:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    6425:	90                   	nop
    6426:	9b                   	fwait
    6427:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    642b:	83 c4 06             	add    sp,0x6
    642e:	b8 34 64             	mov    ax,0x6434
    6431:	0e                   	push   cs
    6432:	50                   	push   ax
    6433:	cb                   	retf
    6434:	9b 2e d9 06 58 62    	fld    DWORD PTR cs:0x6258
    643a:	9b dd 5e b0          	fstp   QWORD PTR [bp-0x50]
    643e:	90                   	nop
    643f:	9b                   	fwait
    6440:	8b 46 aa             	mov    ax,WORD PTR [bp-0x56]
    6443:	f7 d8                	neg    ax
    6445:	71 05                	jno    0x644c
    6447:	9a 3e 04 7f 64       	call   0x647f:0x43e
    644c:	3d ff ff             	cmp    ax,0xffff
    644f:	7e 03                	jle    0x6454
    6451:	e9 f6 00             	jmp    0x654a
    6454:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    6457:	eb 03                	jmp    0x645c
    6459:	ff 46 ac             	inc    WORD PTR [bp-0x54]
    645c:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    6460:	9b 2e d8 1e 58 62    	fcomp  DWORD PTR cs:0x6258
    6466:	9b dd 7e a6          	fstsw  WORD PTR [bp-0x5a]
    646a:	90                   	nop
    646b:	9b                   	fwait
    646c:	8a 66 a7             	mov    ah,BYTE PTR [bp-0x59]
    646f:	9e                   	sahf
    6470:	77 03                	ja     0x6475
    6472:	e9 cc 00             	jmp    0x6541
    6475:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    6478:	99                   	cwd
    6479:	bf 5c 62             	mov    di,0x625c
    647c:	9a 16 04 a8 64       	call   0x64a8:0x416
    6481:	8b f8                	mov    di,ax
    6483:	c1 e7 03             	shl    di,0x3
    6486:	9b dd 43 f8          	fld    QWORD PTR [bp+di-0x8]
    648a:	9b dc 5e e0          	fcomp  QWORD PTR [bp-0x20]
    648e:	9b dd 7e a4          	fstsw  WORD PTR [bp-0x5c]
    6492:	90                   	nop
    6493:	9b                   	fwait
    6494:	8a 66 a5             	mov    ah,BYTE PTR [bp-0x5b]
    6497:	9e                   	sahf
    6498:	77 5d                	ja     0x64f7
    649a:	9b dd 46 b0          	fld    QWORD PTR [bp-0x50]
    649e:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    64a1:	99                   	cwd
    64a2:	bf 5c 62             	mov    di,0x625c
    64a5:	9a 16 04 c7 64       	call   0x64c7:0x416
    64aa:	8b f8                	mov    di,ax
    64ac:	c1 e7 03             	shl    di,0x3
    64af:	9b dc 43 f8          	fadd   QWORD PTR [bp+di-0x8]
    64b3:	9b dd 5e b0          	fstp   QWORD PTR [bp-0x50]
    64b7:	90                   	nop
    64b8:	9b 9b dd 46 e0       	fld    QWORD PTR [bp-0x20]
    64bd:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    64c0:	99                   	cwd
    64c1:	bf 5c 62             	mov    di,0x625c
    64c4:	9a 16 04 e8 64       	call   0x64e8:0x416
    64c9:	8b f8                	mov    di,ax
    64cb:	c1 e7 03             	shl    di,0x3
    64ce:	9b dc 63 f8          	fsub   QWORD PTR [bp+di-0x8]
    64d2:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    64d6:	90                   	nop
    64d7:	9b                   	fwait
    64d8:	9b 2e d9 06 58 62    	fld    DWORD PTR cs:0x6258
    64de:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    64e1:	99                   	cwd
    64e2:	bf 5c 62             	mov    di,0x625c
    64e5:	9a 16 04 0f 65       	call   0x650f:0x416
    64ea:	8b f8                	mov    di,ax
    64ec:	c1 e7 03             	shl    di,0x3
    64ef:	9b dd 5b f8          	fstp   QWORD PTR [bp+di-0x8]
    64f3:	90                   	nop
    64f4:	9b                   	fwait
    64f5:	eb 4a                	jmp    0x6541
    64f7:	9b dd 46 b0          	fld    QWORD PTR [bp-0x50]
    64fb:	9b dc 46 e0          	fadd   QWORD PTR [bp-0x20]
    64ff:	9b dd 5e b0          	fstp   QWORD PTR [bp-0x50]
    6503:	90                   	nop
    6504:	9b                   	fwait
    6505:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    6508:	99                   	cwd
    6509:	bf 5c 62             	mov    di,0x625c
    650c:	9a 16 04 28 65       	call   0x6528:0x416
    6511:	8b f8                	mov    di,ax
    6513:	c1 e7 03             	shl    di,0x3
    6516:	9b dd 43 f8          	fld    QWORD PTR [bp+di-0x8]
    651a:	9b dc 66 e0          	fsub   QWORD PTR [bp-0x20]
    651e:	8b 46 ac             	mov    ax,WORD PTR [bp-0x54]
    6521:	99                   	cwd
    6522:	bf 5c 62             	mov    di,0x625c
    6525:	9a 16 04 58 65       	call   0x6558:0x416
    652a:	8b f8                	mov    di,ax
    652c:	c1 e7 03             	shl    di,0x3
    652f:	9b dd 5b f8          	fstp   QWORD PTR [bp+di-0x8]
    6533:	90                   	nop
    6534:	9b                   	fwait
    6535:	9b 2e d9 06 58 62    	fld    DWORD PTR cs:0x6258
    653b:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    653f:	90                   	nop
    6540:	9b                   	fwait
    6541:	83 7e ac ff          	cmp    WORD PTR [bp-0x54],0xffff
    6545:	74 03                	je     0x654a
    6547:	e9 0f ff             	jmp    0x6459
    654a:	9b dd 46 f0          	fld    QWORD PTR [bp-0x10]
    654e:	8b 46 aa             	mov    ax,WORD PTR [bp-0x56]
    6551:	f7 d8                	neg    ax
    6553:	71 05                	jno    0x655a
    6555:	9a 3e 04 61 65       	call   0x6561:0x43e
    655a:	99                   	cwd
    655b:	bf 5c 62             	mov    di,0x625c
    655e:	9a 16 04 08 67       	call   0x6708:0x416
    6563:	8b f8                	mov    di,ax
    6565:	c1 e7 03             	shl    di,0x3
    6568:	9b dd 5b f8          	fstp   QWORD PTR [bp+di-0x8]
    656c:	90                   	nop
    656d:	9b 9b dd 46 c8       	fld    QWORD PTR [bp-0x38]
    6572:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    6576:	90                   	nop
    6577:	9b                   	fwait
    6578:	8b 46 ae             	mov    ax,WORD PTR [bp-0x52]
    657b:	3b 46 a8             	cmp    ax,WORD PTR [bp-0x58]
    657e:	74 03                	je     0x6583
    6580:	e9 63 fd             	jmp    0x62e6
    6583:	9b dd 46 b0          	fld    QWORD PTR [bp-0x50]
    6587:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    658b:	90                   	nop
    658c:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    6591:	90                   	nop
    6592:	9b                   	fwait
    6593:	c9                   	leave
    6594:	ca 10 00             	retf   0x10
    6597:	14 43                	adc    al,0x43
    6599:	61                   	popa
    659a:	70 69                	jo     0x6605
    659c:	74 61                	je     0x65ff
    659e:	6c                   	ins    BYTE PTR es:[di],dx
    659f:	53                   	push   bx
    65a0:	6f                   	outs   dx,WORD PTR ds:[si]
    65a1:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    65a4:	6c                   	ins    BYTE PTR es:[di],dx
    65a5:	49                   	dec    cx
    65a6:	6e                   	outs   dx,BYTE PTR ds:[si]
    65a7:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
    65ac:	11 4d 6f             	adc    WORD PTR [di+0x6f],cx
    65af:	64 65 41             	fs gs inc cx
    65b2:	6d                   	ins    WORD PTR es:[di],dx
    65b3:	6f                   	outs   dx,WORD PTR ds:[si]
    65b4:	72 74                	jb     0x662a
    65b6:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    65bb:	65 6e                	outs   dx,BYTE PTR gs:[si]
    65bd:	74 00                	je     0x65bf
    65bf:	80 ff ff             	cmp    bh,0xff
    65c2:	ff                   	(bad)
    65c3:	7f 00                	jg     0x65c5
    65c5:	00 12                	add    BYTE PTR [bp+si],dl
    65c7:	44                   	inc    sp
    65c8:	75 72                	jne    0x663c
    65ca:	65 65 41             	gs gs inc cx
    65cd:	6d                   	ins    WORD PTR es:[di],dx
    65ce:	6f                   	outs   dx,WORD PTR ds:[si]
    65cf:	72 74                	jb     0x6645
    65d1:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    65d6:	65 6e                	outs   dx,BYTE PTR gs:[si]
    65d8:	74 13                	je     0x65ed
    65da:	43                   	inc    bx
    65db:	6f                   	outs   dx,WORD PTR ds:[si]
    65dc:	65 66 66 41          	gs data32 inc ecx
    65e0:	6d                   	ins    WORD PTR es:[di],dx
    65e1:	6f                   	outs   dx,WORD PTR ds:[si]
    65e2:	72 74                	jb     0x6658
    65e4:	44                   	inc    sp
    65e5:	65 67 72 65          	gs addr32 jb 0x664e
    65e9:	73 73                	jae    0x665e
    65eb:	69 66 00 00 80       	imul   sp,WORD PTR [bp+0x0],0x8000
    65f0:	bf 00 00             	mov    di,0x0
    65f3:	1c 68                	sbb    al,0x68
    65f5:	26 66 01 00          	add    DWORD PTR es:[bx+si],eax
    65f9:	00 00                	add    BYTE PTR [bx+si],al
    65fb:	02 00                	add    al,BYTE PTR [bx+si]
    65fd:	00 00                	add    BYTE PTR [bx+si],al
    65ff:	10 54 65             	adc    BYTE PTR [si+0x65],dl
    6602:	6d                   	ins    WORD PTR es:[di],dx
    6603:	70 73                	jo     0x6678
    6605:	46                   	inc    si
    6606:	61                   	popa
    6607:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    660a:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    660d:	69 6f 6e 11 46       	imul   bp,WORD PTR [bx+0x6e],0x4611
    6612:	61                   	popa
    6613:	63 74 65             	arpl   WORD PTR [si+0x65],si
    6616:	75 72                	jne    0x668a
    6618:	54                   	push   sp
    6619:	65 6d                	gs ins WORD PTR es:[di],dx
    661b:	70 73                	jo     0x6690
    661d:	46                   	inc    si
    661e:	61                   	popa
    661f:	62 50 63             	bound  dx,DWORD PTR [bx+si+0x63]
    6622:	00 00                	add    BYTE PTR [bx+si],al
    6624:	29 69 43             	sub    WORD PTR [bx+di+0x43],bp
    6627:	66 08 4d 61          	data32 or BYTE PTR [di+0x61],cl
    662b:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    662e:	6e                   	outs   dx,BYTE PTR ds:[si]
    662f:	65 73 0d             	gs jae 0x663f
    6632:	43                   	inc    bx
    6633:	61                   	popa
    6634:	70 69                	jo     0x669f
    6636:	74 61                	je     0x6699
    6638:	6c                   	ins    BYTE PTR es:[di],dx
    6639:	53                   	push   bx
    663a:	6f                   	outs   dx,WORD PTR ds:[si]
    663b:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    663e:	6c                   	ins    BYTE PTR es:[di],dx
    663f:	00 00                	add    BYTE PTR [bx+si],al
    6641:	de 69 5e             	fisubr WORD PTR [bx+di+0x5e]
    6644:	66 00 00             	data32 add BYTE PTR [bx+si],al
    6647:	00 00                	add    BYTE PTR [bx+si],al
    6649:	10 43 6f             	adc    BYTE PTR [bp+di+0x6f],al
    664c:	75 74                	jne    0x66c2
    664e:	55                   	push   bp
    664f:	6e                   	outs   dx,BYTE PTR ds:[si]
    6650:	69 74 65 4d 61       	imul   si,WORD PTR [si+0x65],0x614d
    6655:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    6658:	6e                   	outs   dx,BYTE PTR ds:[si]
    6659:	65 00 00             	add    BYTE PTR gs:[bx+si],al
    665c:	d6                   	(bad)
    665d:	6a 80                	push   0xff80
    665f:	66 0d 41 63 68 61    	or     eax,0x61686341
    6665:	74 4d                	je     0x66b4
    6667:	61                   	popa
    6668:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    666b:	6e                   	outs   dx,BYTE PTR ds:[si]
    666c:	65 73 0d             	gs jae 0x667c
    666f:	56                   	push   si
    6670:	65 6e                	outs   dx,BYTE PTR gs:[si]
    6672:	74 65                	je     0x66d9
    6674:	4d                   	dec    bp
    6675:	61                   	popa
    6676:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    6679:	6e                   	outs   dx,BYTE PTR ds:[si]
    667a:	65 73 00             	gs jae 0x667d
    667d:	00 8f 6b a0          	add    BYTE PTR [bx-0x5f95],cl
    6681:	66 01 00             	add    DWORD PTR [bx+si],eax
    6684:	00 00                	add    BYTE PTR [bx+si],al
    6686:	02 00                	add    al,BYTE PTR [bx+si]
    6688:	00 00                	add    BYTE PTR [bx+si],al
    668a:	11 4d 61             	adc    WORD PTR [di+0x61],cx
    668d:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    6690:	6e                   	outs   dx,BYTE PTR ds:[si]
    6691:	65 73 41             	gs jae 0x66d5
    6694:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    669a:	65 73 00             	gs jae 0x669d
    669d:	00 61 6c             	add    BYTE PTR [bx+di+0x6c],ah
    66a0:	af                   	scas   ax,WORD PTR es:[di]
    66a1:	66 08 4d 61          	data32 or BYTE PTR [di+0x61],cl
    66a5:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    66a8:	6e                   	outs   dx,BYTE PTR ds:[si]
    66a9:	65 73 00             	gs jae 0x66ac
    66ac:	00 ff                	add    bh,bh
    66ae:	6c                   	ins    BYTE PTR es:[di],dx
    66af:	5c                   	pop    sp
    66b0:	67 00 00             	add    BYTE PTR [eax],al
    66b3:	00 00                	add    BYTE PTR [bx+si],al
    66b5:	32 00                	xor    al,BYTE PTR [bx+si]
    66b7:	00 00                	add    BYTE PTR [bx+si],al
    66b9:	01 00                	add    WORD PTR [bx+si],ax
    66bb:	00 00                	add    BYTE PTR [bx+si],al
    66bd:	02 00                	add    al,BYTE PTR [bx+si]
    66bf:	00 00                	add    BYTE PTR [bx+si],al
    66c1:	00 00                	add    BYTE PTR [bx+si],al
    66c3:	c0 3f 00             	sar    BYTE PTR [bx],0x0
    66c6:	00 00                	add    BYTE PTR [bx+si],al
    66c8:	40                   	inc    ax
    66c9:	00 00                	add    BYTE PTR [bx+si],al
    66cb:	20 40 00             	and    BYTE PTR [bx+si+0x0],al
    66ce:	00 80 3f 00          	add    BYTE PTR [bx+si+0x3f],al
    66d2:	00 c8                	add    al,cl
    66d4:	42                   	inc    dx
    66d5:	cd cc                	int    0xcc
    66d7:	cc                   	int3
    66d8:	cc                   	int3
    66d9:	cc                   	int3
    66da:	cc                   	int3
    66db:	cc                   	int3
    66dc:	cc                   	int3
    66dd:	fa                   	cli
    66de:	3f                   	aas
    66df:	3b df                	cmp    bx,di
    66e1:	4f                   	dec    di
    66e2:	8d 97 6e 12          	lea    dx,[bx+0x126e]
    66e6:	83 f8 3f             	cmp    ax,0x3f
    66e9:	cd cc                	int    0xcc
    66eb:	cc                   	int3
    66ec:	cc                   	int3
    66ed:	cc                   	int3
    66ee:	cc                   	int3
    66ef:	cc                   	int3
    66f0:	cc                   	int3
    66f1:	fb                   	sti
    66f2:	3f                   	aas
    66f3:	00 00                	add    BYTE PTR [bx+si],al
    66f5:	f0 40                	lock inc ax
    66f7:	00 00                	add    BYTE PTR [bx+si],al
    66f9:	40                   	inc    ax
    66fa:	40                   	inc    ax
    66fb:	00 40 1c             	add    BYTE PTR [bx+si+0x1c],al
    66fe:	46                   	inc    si
    66ff:	55                   	push   bp
    6700:	89 e5                	mov    bp,sp
    6702:	b8 20 05             	mov    ax,0x520
    6705:	9a 44 04 a4 67       	call   0x67a4:0x444
    670a:	81 ec 20 05          	sub    sp,0x520
    670e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6711:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    6716:	89 be fa fa          	mov    WORD PTR [bp-0x506],di
    671a:	8c 86 fc fa          	mov    WORD PTR [bp-0x504],es
    671e:	b8 f1 65             	mov    ax,0x65f1
    6721:	0e                   	push   cs
    6722:	50                   	push   ax
    6723:	55                   	push   bp
    6724:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6728:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    672c:	c7 86 f2 fa 01 00    	mov    WORD PTR [bp-0x50e],0x1
    6732:	c7 86 f4 fa 00 00    	mov    WORD PTR [bp-0x50c],0x0
    6738:	c6 86 f6 fa 00       	mov    BYTE PTR [bp-0x50a],0x0
    673d:	8d be f2 fa          	lea    di,[bp-0x50e]
    6741:	16                   	push   ss
    6742:	57                   	push   di
    6743:	6a 00                	push   0x0
    6745:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    6749:	06                   	push   es
    674a:	57                   	push   di
    674b:	9a 95 28 6a 68       	call   0x686a:0x2895
    6750:	08 c0                	or     al,al
    6752:	75 0a                	jne    0x675e
    6754:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6757:	06                   	push   es
    6758:	57                   	push   di
    6759:	9a 03 03 78 68       	call   0x6878:0x303
    675e:	bf 97 65             	mov    di,0x6597
    6761:	0e                   	push   cs
    6762:	57                   	push   di
    6763:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    6767:	06                   	push   es
    6768:	57                   	push   di
    6769:	9a 9b 3b 8f 67       	call   0x678f:0x3b9b
    676e:	89 c7                	mov    di,ax
    6770:	8e c2                	mov    es,dx
    6772:	06                   	push   es
    6773:	57                   	push   di
    6774:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6777:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    677b:	9b dd 5e f4          	fstp   QWORD PTR [bp-0xc]
    677f:	90                   	nop
    6780:	9b                   	fwait
    6781:	bf ac 65             	mov    di,0x65ac
    6784:	0e                   	push   cs
    6785:	57                   	push   di
    6786:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    678a:	06                   	push   es
    678b:	57                   	push   di
    678c:	9a 9b 3b b8 67       	call   0x67b8:0x3b9b
    6791:	89 c7                	mov    di,ax
    6793:	8e c2                	mov    es,dx
    6795:	06                   	push   es
    6796:	57                   	push   di
    6797:	26 c4 3d             	les    di,DWORD PTR es:[di]
    679a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    679e:	bf be 65             	mov    di,0x65be
    67a1:	9a 16 04 cd 67       	call   0x67cd:0x416
    67a6:	89 86 28 fb          	mov    WORD PTR [bp-0x4d8],ax
    67aa:	bf c6 65             	mov    di,0x65c6
    67ad:	0e                   	push   cs
    67ae:	57                   	push   di
    67af:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    67b3:	06                   	push   es
    67b4:	57                   	push   di
    67b5:	9a 9b 3b e0 67       	call   0x67e0:0x3b9b
    67ba:	89 c7                	mov    di,ax
    67bc:	8e c2                	mov    es,dx
    67be:	06                   	push   es
    67bf:	57                   	push   di
    67c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    67c3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    67c7:	bf be 65             	mov    di,0x65be
    67ca:	9a 16 04 a2 68       	call   0x68a2:0x416
    67cf:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    67d2:	bf d9 65             	mov    di,0x65d9
    67d5:	0e                   	push   cs
    67d6:	57                   	push   di
    67d7:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    67db:	06                   	push   es
    67dc:	57                   	push   di
    67dd:	9a 43 3c 88 68       	call   0x6888:0x3c43
    67e2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    67e5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    67e8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    67eb:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    67ee:	74 14                	je     0x6804
    67f0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    67f3:	06                   	push   es
    67f4:	57                   	push   di
    67f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    67f8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    67fc:	9b dd 5e ea          	fstp   QWORD PTR [bp-0x16]
    6800:	90                   	nop
    6801:	9b                   	fwait
    6802:	eb 0c                	jmp    0x6810
    6804:	9b 2e d9 06 ed 65    	fld    DWORD PTR cs:0x65ed
    680a:	9b dd 5e ea          	fstp   QWORD PTR [bp-0x16]
    680e:	90                   	nop
    680f:	9b                   	fwait
    6810:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6814:	83 c4 06             	add    sp,0x6
    6817:	b8 1d 68             	mov    ax,0x681d
    681a:	0e                   	push   cs
    681b:	50                   	push   ax
    681c:	cb                   	retf
    681d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6820:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    6825:	89 be fa fa          	mov    WORD PTR [bp-0x506],di
    6829:	8c 86 fc fa          	mov    WORD PTR [bp-0x504],es
    682d:	b8 22 66             	mov    ax,0x6622
    6830:	0e                   	push   cs
    6831:	50                   	push   ax
    6832:	55                   	push   bp
    6833:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6837:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    683b:	c7 86 d0 fb 01 00    	mov    WORD PTR [bp-0x430],0x1
    6841:	eb 04                	jmp    0x6847
    6843:	ff 86 d0 fb          	inc    WORD PTR [bp-0x430]
    6847:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    684b:	99                   	cwd
    684c:	89 86 f2 fa          	mov    WORD PTR [bp-0x50e],ax
    6850:	89 96 f4 fa          	mov    WORD PTR [bp-0x50c],dx
    6854:	c6 86 f6 fa 00       	mov    BYTE PTR [bp-0x50a],0x0
    6859:	8d be f2 fa          	lea    di,[bp-0x50e]
    685d:	16                   	push   ss
    685e:	57                   	push   di
    685f:	6a 00                	push   0x0
    6861:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    6865:	06                   	push   es
    6866:	57                   	push   di
    6867:	9a 95 28 79 69       	call   0x6979:0x2895
    686c:	08 c0                	or     al,al
    686e:	75 0a                	jne    0x687a
    6870:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6873:	06                   	push   es
    6874:	57                   	push   di
    6875:	9a 03 03 87 69       	call   0x6987:0x303
    687a:	bf ff 65             	mov    di,0x65ff
    687d:	0e                   	push   cs
    687e:	57                   	push   di
    687f:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    6883:	06                   	push   es
    6884:	57                   	push   di
    6885:	9a 9b 3b bd 68       	call   0x68bd:0x3b9b
    688a:	89 c7                	mov    di,ax
    688c:	8e c2                	mov    es,dx
    688e:	06                   	push   es
    688f:	57                   	push   di
    6890:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6893:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6897:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    689b:	99                   	cwd
    689c:	bf f7 65             	mov    di,0x65f7
    689f:	9a 16 04 e8 68       	call   0x68e8:0x416
    68a4:	8b f8                	mov    di,ax
    68a6:	c1 e7 03             	shl    di,0x3
    68a9:	9b dd 5b d2          	fstp   QWORD PTR [bp+di-0x2e]
    68ad:	90                   	nop
    68ae:	9b                   	fwait
    68af:	bf 10 66             	mov    di,0x6610
    68b2:	0e                   	push   cs
    68b3:	57                   	push   di
    68b4:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    68b8:	06                   	push   es
    68b9:	57                   	push   di
    68ba:	9a 43 3c 97 69       	call   0x6997:0x3c43
    68bf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    68c2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    68c5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    68c8:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    68cb:	74 2a                	je     0x68f7
    68cd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    68d0:	06                   	push   es
    68d1:	57                   	push   di
    68d2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    68d5:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    68d9:	8b c8                	mov    cx,ax
    68db:	8b da                	mov    bx,dx
    68dd:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    68e1:	99                   	cwd
    68e2:	bf f7 65             	mov    di,0x65f7
    68e5:	9a 16 04 02 69       	call   0x6902:0x416
    68ea:	8b f8                	mov    di,ax
    68ec:	c1 e7 02             	shl    di,0x2
    68ef:	89 4b ce             	mov    WORD PTR [bp+di-0x32],cx
    68f2:	89 5b d0             	mov    WORD PTR [bp+di-0x30],bx
    68f5:	eb 1c                	jmp    0x6913
    68f7:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    68fb:	99                   	cwd
    68fc:	bf f7 65             	mov    di,0x65f7
    68ff:	9a 16 04 3c 6c       	call   0x6c3c:0x416
    6904:	8b f8                	mov    di,ax
    6906:	c1 e7 02             	shl    di,0x2
    6909:	c7 43 ce 64 00       	mov    WORD PTR [bp+di-0x32],0x64
    690e:	c7 43 d0 00 00       	mov    WORD PTR [bp+di-0x30],0x0
    6913:	83 be d0 fb 02       	cmp    WORD PTR [bp-0x430],0x2
    6918:	74 03                	je     0x691d
    691a:	e9 26 ff             	jmp    0x6843
    691d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6921:	83 c4 06             	add    sp,0x6
    6924:	b8 2a 69             	mov    ax,0x692a
    6927:	0e                   	push   cs
    6928:	50                   	push   ax
    6929:	cb                   	retf
    692a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    692d:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    6932:	89 be fa fa          	mov    WORD PTR [bp-0x506],di
    6936:	8c 86 fc fa          	mov    WORD PTR [bp-0x504],es
    693a:	b8 3f 66             	mov    ax,0x663f
    693d:	0e                   	push   cs
    693e:	50                   	push   ax
    693f:	55                   	push   bp
    6940:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6944:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6948:	31 c0                	xor    ax,ax
    694a:	89 86 ea fa          	mov    WORD PTR [bp-0x516],ax
    694e:	89 86 ec fa          	mov    WORD PTR [bp-0x514],ax
    6952:	c6 86 ee fa 00       	mov    BYTE PTR [bp-0x512],0x0
    6957:	8b 46 2a             	mov    ax,WORD PTR [bp+0x2a]
    695a:	99                   	cwd
    695b:	89 86 f2 fa          	mov    WORD PTR [bp-0x50e],ax
    695f:	89 96 f4 fa          	mov    WORD PTR [bp-0x50c],dx
    6963:	c6 86 f6 fa 00       	mov    BYTE PTR [bp-0x50a],0x0
    6968:	8d be ea fa          	lea    di,[bp-0x516]
    696c:	16                   	push   ss
    696d:	57                   	push   di
    696e:	6a 01                	push   0x1
    6970:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    6974:	06                   	push   es
    6975:	57                   	push   di
    6976:	9a 95 28 96 6a       	call   0x6a96:0x2895
    697b:	08 c0                	or     al,al
    697d:	75 0a                	jne    0x6989
    697f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6982:	06                   	push   es
    6983:	57                   	push   di
    6984:	9a 03 03 a4 6a       	call   0x6aa4:0x303
    6989:	bf 28 66             	mov    di,0x6628
    698c:	0e                   	push   cs
    698d:	57                   	push   di
    698e:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    6992:	06                   	push   es
    6993:	57                   	push   di
    6994:	9a 9b 3b bc 69       	call   0x69bc:0x3b9b
    6999:	89 c7                	mov    di,ax
    699b:	8e c2                	mov    es,dx
    699d:	06                   	push   es
    699e:	57                   	push   di
    699f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    69a2:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    69a6:	89 86 06 ff          	mov    WORD PTR [bp-0xfa],ax
    69aa:	89 96 08 ff          	mov    WORD PTR [bp-0xf8],dx
    69ae:	bf 31 66             	mov    di,0x6631
    69b1:	0e                   	push   cs
    69b2:	57                   	push   di
    69b3:	c4 be fa fa          	les    di,DWORD PTR [bp-0x506]
    69b7:	06                   	push   es
    69b8:	57                   	push   di
    69b9:	9a 9b 3b b4 6a       	call   0x6ab4:0x3b9b
    69be:	89 c7                	mov    di,ax
    69c0:	8e c2                	mov    es,dx
    69c2:	06                   	push   es
    69c3:	57                   	push   di
    69c4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    69c7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    69cb:	9b dd 9e 6e fd       	fstp   QWORD PTR [bp-0x292]
    69d0:	90                   	nop
    69d1:	9b                   	fwait
    69d2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    69d6:	83 c4 06             	add    sp,0x6
    69d9:	b8 df 69             	mov    ax,0x69df
    69dc:	0e                   	push   cs
    69dd:	50                   	push   ax
    69de:	cb                   	retf
    69df:	ff b6 74 fd          	push   WORD PTR [bp-0x28c]
    69e3:	ff b6 72 fd          	push   WORD PTR [bp-0x28e]
    69e7:	ff b6 70 fd          	push   WORD PTR [bp-0x290]
    69eb:	ff b6 6e fd          	push   WORD PTR [bp-0x292]
    69ef:	9b db 86 06 ff       	fild   DWORD PTR [bp-0xfa]
    69f4:	83 ec 08             	sub    sp,0x8
    69f7:	89 e3                	mov    bx,sp
    69f9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    69fd:	90                   	nop
    69fe:	9b                   	fwait
    69ff:	9a a7 2e 58 6d       	call   0x6d58:0x2ea7
    6a04:	9b dd 9e d6 fb       	fstp   QWORD PTR [bp-0x42a]
    6a09:	90                   	nop
    6a0a:	9b                   	fwait
    6a0b:	9b 2e d9 06 45 66    	fld    DWORD PTR cs:0x6645
    6a11:	9b dd 9e a4 fb       	fstp   QWORD PTR [bp-0x45c]
    6a16:	90                   	nop
    6a17:	9b                   	fwait
    6a18:	9b 2e d9 06 45 66    	fld    DWORD PTR cs:0x6645
    6a1e:	9b dd 9e 7a fb       	fstp   QWORD PTR [bp-0x486]
    6a23:	90                   	nop
    6a24:	9b                   	fwait
    6a25:	9b 2e d9 06 45 66    	fld    DWORD PTR cs:0x6645
    6a2b:	9b dd 9e 9c fb       	fstp   QWORD PTR [bp-0x464]
    6a30:	90                   	nop
    6a31:	9b                   	fwait
    6a32:	31 c0                	xor    ax,ax
    6a34:	89 86 8a fb          	mov    WORD PTR [bp-0x476],ax
    6a38:	8b 46 2c             	mov    ax,WORD PTR [bp+0x2c]
    6a3b:	89 86 fc fa          	mov    WORD PTR [bp-0x504],ax
    6a3f:	b8 01 00             	mov    ax,0x1
    6a42:	3b 86 fc fa          	cmp    ax,WORD PTR [bp-0x504]
    6a46:	7e 03                	jle    0x6a4b
    6a48:	e9 54 09             	jmp    0x739f
    6a4b:	89 86 d4 fb          	mov    WORD PTR [bp-0x42c],ax
    6a4f:	eb 04                	jmp    0x6a55
    6a51:	ff 86 d4 fb          	inc    WORD PTR [bp-0x42c]
    6a55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a58:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    6a5d:	89 be f8 fa          	mov    WORD PTR [bp-0x508],di
    6a61:	8c 86 fa fa          	mov    WORD PTR [bp-0x506],es
    6a65:	b8 5a 66             	mov    ax,0x665a
    6a68:	0e                   	push   cs
    6a69:	50                   	push   ax
    6a6a:	55                   	push   bp
    6a6b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6a6f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6a73:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6a77:	99                   	cwd
    6a78:	89 86 f0 fa          	mov    WORD PTR [bp-0x510],ax
    6a7c:	89 96 f2 fa          	mov    WORD PTR [bp-0x50e],dx
    6a80:	c6 86 f4 fa 00       	mov    BYTE PTR [bp-0x50c],0x0
    6a85:	8d be f0 fa          	lea    di,[bp-0x510]
    6a89:	16                   	push   ss
    6a8a:	57                   	push   di
    6a8b:	6a 00                	push   0x0
    6a8d:	c4 be f8 fa          	les    di,DWORD PTR [bp-0x508]
    6a91:	06                   	push   es
    6a92:	57                   	push   di
    6a93:	9a 95 28 29 6b       	call   0x6b29:0x2895
    6a98:	08 c0                	or     al,al
    6a9a:	75 0a                	jne    0x6aa6
    6a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a9f:	06                   	push   es
    6aa0:	57                   	push   di
    6aa1:	9a 03 03 37 6b       	call   0x6b37:0x303
    6aa6:	bf 49 66             	mov    di,0x6649
    6aa9:	0e                   	push   cs
    6aaa:	57                   	push   di
    6aab:	c4 be f8 fa          	les    di,DWORD PTR [bp-0x508]
    6aaf:	06                   	push   es
    6ab0:	57                   	push   di
    6ab1:	9a 9b 3b 47 6b       	call   0x6b47:0x3b9b
    6ab6:	89 c7                	mov    di,ax
    6ab8:	8e c2                	mov    es,dx
    6aba:	06                   	push   es
    6abb:	57                   	push   di
    6abc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6abf:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    6ac3:	9b dd 9e c8 fb       	fstp   QWORD PTR [bp-0x438]
    6ac8:	90                   	nop
    6ac9:	9b                   	fwait
    6aca:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6ace:	83 c4 06             	add    sp,0x6
    6ad1:	b8 d7 6a             	mov    ax,0x6ad7
    6ad4:	0e                   	push   cs
    6ad5:	50                   	push   ax
    6ad6:	cb                   	retf
    6ad7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ada:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    6adf:	89 be f8 fa          	mov    WORD PTR [bp-0x508],di
    6ae3:	8c 86 fa fa          	mov    WORD PTR [bp-0x506],es
    6ae7:	b8 7c 66             	mov    ax,0x667c
    6aea:	0e                   	push   cs
    6aeb:	50                   	push   ax
    6aec:	55                   	push   bp
    6aed:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6af1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6af5:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6af9:	99                   	cwd
    6afa:	89 86 e8 fa          	mov    WORD PTR [bp-0x518],ax
    6afe:	89 96 ea fa          	mov    WORD PTR [bp-0x516],dx
    6b02:	c6 86 ec fa 00       	mov    BYTE PTR [bp-0x514],0x0
    6b07:	8b 46 2a             	mov    ax,WORD PTR [bp+0x2a]
    6b0a:	99                   	cwd
    6b0b:	89 86 f0 fa          	mov    WORD PTR [bp-0x510],ax
    6b0f:	89 96 f2 fa          	mov    WORD PTR [bp-0x50e],dx
    6b13:	c6 86 f4 fa 00       	mov    BYTE PTR [bp-0x50c],0x0
    6b18:	8d be e8 fa          	lea    di,[bp-0x518]
    6b1c:	16                   	push   ss
    6b1d:	57                   	push   di
    6b1e:	6a 01                	push   0x1
    6b20:	c4 be f8 fa          	les    di,DWORD PTR [bp-0x508]
    6b24:	06                   	push   es
    6b25:	57                   	push   di
    6b26:	9a 95 28 00 6c       	call   0x6c00:0x2895
    6b2b:	08 c0                	or     al,al
    6b2d:	75 0a                	jne    0x6b39
    6b2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b32:	06                   	push   es
    6b33:	57                   	push   di
    6b34:	9a 03 03 0e 6c       	call   0x6c0e:0x303
    6b39:	bf 60 66             	mov    di,0x6660
    6b3c:	0e                   	push   cs
    6b3d:	57                   	push   di
    6b3e:	c4 be f8 fa          	les    di,DWORD PTR [bp-0x508]
    6b42:	06                   	push   es
    6b43:	57                   	push   di
    6b44:	9a 9b 3b 6c 6b       	call   0x6b6c:0x3b9b
    6b49:	89 c7                	mov    di,ax
    6b4b:	8e c2                	mov    es,dx
    6b4d:	06                   	push   es
    6b4e:	57                   	push   di
    6b4f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b52:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    6b56:	89 86 c4 fb          	mov    WORD PTR [bp-0x43c],ax
    6b5a:	89 96 c6 fb          	mov    WORD PTR [bp-0x43a],dx
    6b5e:	bf 6e 66             	mov    di,0x666e
    6b61:	0e                   	push   cs
    6b62:	57                   	push   di
    6b63:	c4 be f8 fa          	les    di,DWORD PTR [bp-0x508]
    6b67:	06                   	push   es
    6b68:	57                   	push   di
    6b69:	9a 9b 3b 1e 6c       	call   0x6c1e:0x3b9b
    6b6e:	89 c7                	mov    di,ax
    6b70:	8e c2                	mov    es,dx
    6b72:	06                   	push   es
    6b73:	57                   	push   di
    6b74:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b77:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    6b7b:	89 86 c0 fb          	mov    WORD PTR [bp-0x440],ax
    6b7f:	89 96 c2 fb          	mov    WORD PTR [bp-0x43e],dx
    6b83:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6b87:	83 c4 06             	add    sp,0x6
    6b8a:	b8 90 6b             	mov    ax,0x6b90
    6b8d:	0e                   	push   cs
    6b8e:	50                   	push   ax
    6b8f:	cb                   	retf
    6b90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b93:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    6b98:	89 be f8 fa          	mov    WORD PTR [bp-0x508],di
    6b9c:	8c 86 fa fa          	mov    WORD PTR [bp-0x506],es
    6ba0:	b8 9c 66             	mov    ax,0x669c
    6ba3:	0e                   	push   cs
    6ba4:	50                   	push   ax
    6ba5:	55                   	push   bp
    6ba6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6baa:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6bae:	c7 86 d0 fb 01 00    	mov    WORD PTR [bp-0x430],0x1
    6bb4:	eb 04                	jmp    0x6bba
    6bb6:	ff 86 d0 fb          	inc    WORD PTR [bp-0x430]
    6bba:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6bbe:	99                   	cwd
    6bbf:	89 86 e0 fa          	mov    WORD PTR [bp-0x520],ax
    6bc3:	89 96 e2 fa          	mov    WORD PTR [bp-0x51e],dx
    6bc7:	c6 86 e4 fa 00       	mov    BYTE PTR [bp-0x51c],0x0
    6bcc:	8b 46 2a             	mov    ax,WORD PTR [bp+0x2a]
    6bcf:	99                   	cwd
    6bd0:	89 86 e8 fa          	mov    WORD PTR [bp-0x518],ax
    6bd4:	89 96 ea fa          	mov    WORD PTR [bp-0x516],dx
    6bd8:	c6 86 ec fa 00       	mov    BYTE PTR [bp-0x514],0x0
    6bdd:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    6be1:	99                   	cwd
    6be2:	89 86 f0 fa          	mov    WORD PTR [bp-0x510],ax
    6be6:	89 96 f2 fa          	mov    WORD PTR [bp-0x50e],dx
    6bea:	c6 86 f4 fa 00       	mov    BYTE PTR [bp-0x50c],0x0
    6bef:	8d be e0 fa          	lea    di,[bp-0x520]
    6bf3:	16                   	push   ss
    6bf4:	57                   	push   di
    6bf5:	6a 02                	push   0x2
    6bf7:	c4 be f8 fa          	les    di,DWORD PTR [bp-0x508]
    6bfb:	06                   	push   es
    6bfc:	57                   	push   di
    6bfd:	9a 95 28 be 6c       	call   0x6cbe:0x2895
    6c02:	08 c0                	or     al,al
    6c04:	75 0a                	jne    0x6c10
    6c06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c09:	06                   	push   es
    6c0a:	57                   	push   di
    6c0b:	9a 03 03 cc 6c       	call   0x6ccc:0x303
    6c10:	bf 8a 66             	mov    di,0x668a
    6c13:	0e                   	push   cs
    6c14:	57                   	push   di
    6c15:	c4 be f8 fa          	les    di,DWORD PTR [bp-0x508]
    6c19:	06                   	push   es
    6c1a:	57                   	push   di
    6c1b:	9a 9b 3b dc 6c       	call   0x6cdc:0x3b9b
    6c20:	89 c7                	mov    di,ax
    6c22:	8e c2                	mov    es,dx
    6c24:	06                   	push   es
    6c25:	57                   	push   di
    6c26:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c29:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    6c2d:	8b c8                	mov    cx,ax
    6c2f:	8b da                	mov    bx,dx
    6c31:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    6c35:	99                   	cwd
    6c36:	bf 82 66             	mov    di,0x6682
    6c39:	9a 16 04 8c 6c       	call   0x6c8c:0x416
    6c3e:	8b f8                	mov    di,ax
    6c40:	c1 e7 02             	shl    di,0x2
    6c43:	89 8b b4 fb          	mov    WORD PTR [bp+di-0x44c],cx
    6c47:	89 9b b6 fb          	mov    WORD PTR [bp+di-0x44a],bx
    6c4b:	83 be d0 fb 02       	cmp    WORD PTR [bp-0x430],0x2
    6c50:	74 03                	je     0x6c55
    6c52:	e9 61 ff             	jmp    0x6bb6
    6c55:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6c59:	83 c4 06             	add    sp,0x6
    6c5c:	b8 62 6c             	mov    ax,0x6c62
    6c5f:	0e                   	push   cs
    6c60:	50                   	push   ax
    6c61:	cb                   	retf
    6c62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c65:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    6c6a:	89 be f8 fa          	mov    WORD PTR [bp-0x508],di
    6c6e:	8c 86 fa fa          	mov    WORD PTR [bp-0x506],es
    6c72:	b8 ab 66             	mov    ax,0x66ab
    6c75:	0e                   	push   cs
    6c76:	50                   	push   ax
    6c77:	55                   	push   bp
    6c78:	ff 36 58 18          	push   WORD PTR ds:0x1858
    6c7c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    6c80:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6c84:	2d 01 00             	sub    ax,0x1
    6c87:	71 05                	jno    0x6c8e
    6c89:	9a 3e 04 13 6d       	call   0x6d13:0x43e
    6c8e:	99                   	cwd
    6c8f:	89 86 e8 fa          	mov    WORD PTR [bp-0x518],ax
    6c93:	89 96 ea fa          	mov    WORD PTR [bp-0x516],dx
    6c97:	c6 86 ec fa 00       	mov    BYTE PTR [bp-0x514],0x0
    6c9c:	8b 46 2a             	mov    ax,WORD PTR [bp+0x2a]
    6c9f:	99                   	cwd
    6ca0:	89 86 f0 fa          	mov    WORD PTR [bp-0x510],ax
    6ca4:	89 96 f2 fa          	mov    WORD PTR [bp-0x50e],dx
    6ca8:	c6 86 f4 fa 00       	mov    BYTE PTR [bp-0x50c],0x0
    6cad:	8d be e8 fa          	lea    di,[bp-0x518]
    6cb1:	16                   	push   ss
    6cb2:	57                   	push   di
    6cb3:	6a 01                	push   0x1
    6cb5:	c4 be f8 fa          	les    di,DWORD PTR [bp-0x508]
    6cb9:	06                   	push   es
    6cba:	57                   	push   di
    6cbb:	9a 95 28 be 7e       	call   0x7ebe:0x2895
    6cc0:	08 c0                	or     al,al
    6cc2:	75 0a                	jne    0x6cce
    6cc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cc7:	06                   	push   es
    6cc8:	57                   	push   di
    6cc9:	9a 03 03 86 77       	call   0x7786:0x303
    6cce:	bf a2 66             	mov    di,0x66a2
    6cd1:	0e                   	push   cs
    6cd2:	57                   	push   di
    6cd3:	c4 be f8 fa          	les    di,DWORD PTR [bp-0x508]
    6cd7:	06                   	push   es
    6cd8:	57                   	push   di
    6cd9:	9a 9b 3b dc 7e       	call   0x7edc:0x3b9b
    6cde:	89 c7                	mov    di,ax
    6ce0:	8e c2                	mov    es,dx
    6ce2:	06                   	push   es
    6ce3:	57                   	push   di
    6ce4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6ce7:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    6ceb:	89 86 ac fb          	mov    WORD PTR [bp-0x454],ax
    6cef:	89 96 ae fb          	mov    WORD PTR [bp-0x452],dx
    6cf3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6cf7:	83 c4 06             	add    sp,0x6
    6cfa:	b8 00 6d             	mov    ax,0x6d00
    6cfd:	0e                   	push   cs
    6cfe:	50                   	push   ax
    6cff:	cb                   	retf
    6d00:	8b 8e c4 fb          	mov    cx,WORD PTR [bp-0x43c]
    6d04:	8b 9e c6 fb          	mov    bx,WORD PTR [bp-0x43a]
    6d08:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6d0c:	99                   	cwd
    6d0d:	bf b1 66             	mov    di,0x66b1
    6d10:	9a 16 04 32 6d       	call   0x6d32:0x416
    6d15:	8b f8                	mov    di,ax
    6d17:	c1 e7 02             	shl    di,0x2
    6d1a:	89 8b 06 ff          	mov    WORD PTR [bp+di-0xfa],cx
    6d1e:	89 9b 08 ff          	mov    WORD PTR [bp+di-0xf8],bx
    6d22:	9b dd 86 c8 fb       	fld    QWORD PTR [bp-0x438]
    6d27:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6d2b:	99                   	cwd
    6d2c:	bf b1 66             	mov    di,0x66b1
    6d2f:	9a 16 04 65 6d       	call   0x6d65:0x416
    6d34:	8b f8                	mov    di,ax
    6d36:	c1 e7 03             	shl    di,0x3
    6d39:	9b dd 9b d6 fb       	fstp   QWORD PTR [bp+di-0x42a]
    6d3e:	90                   	nop
    6d3f:	9b 9b db 86 c4 fb    	fild   DWORD PTR [bp-0x43c]
    6d45:	9b dc 8e c8 fb       	fmul   QWORD PTR [bp-0x438]
    6d4a:	83 ec 08             	sub    sp,0x8
    6d4d:	89 e3                	mov    bx,sp
    6d4f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6d53:	90                   	nop
    6d54:	9b                   	fwait
    6d55:	9a a6 2f 7f 6e       	call   0x6e7f:0x2fa6
    6d5a:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6d5e:	99                   	cwd
    6d5f:	bf b1 66             	mov    di,0x66b1
    6d62:	9a 16 04 9d 6d       	call   0x6d9d:0x416
    6d67:	8b f8                	mov    di,ax
    6d69:	c1 e7 03             	shl    di,0x3
    6d6c:	9b dd 9b 6e fd       	fstp   QWORD PTR [bp+di-0x292]
    6d71:	90                   	nop
    6d72:	9b                   	fwait
    6d73:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    6d79:	9b dd 9e 9c fb       	fstp   QWORD PTR [bp-0x464]
    6d7e:	90                   	nop
    6d7f:	9b                   	fwait
    6d80:	c7 86 d0 fb 01 00    	mov    WORD PTR [bp-0x430],0x1
    6d86:	eb 04                	jmp    0x6d8c
    6d88:	ff 86 d0 fb          	inc    WORD PTR [bp-0x430]
    6d8c:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    6d92:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    6d96:	99                   	cwd
    6d97:	bf b9 66             	mov    di,0x66b9
    6d9a:	9a 16 04 c7 6d       	call   0x6dc7:0x416
    6d9f:	8b f8                	mov    di,ax
    6da1:	c1 e7 03             	shl    di,0x3
    6da4:	9b dd 9b 84 fb       	fstp   QWORD PTR [bp+di-0x47c]
    6da9:	90                   	nop
    6daa:	9b                   	fwait
    6dab:	83 be d0 fb 02       	cmp    WORD PTR [bp-0x430],0x2
    6db0:	75 d6                	jne    0x6d88
    6db2:	83 7e f2 00          	cmp    WORD PTR [bp-0xe],0x0
    6db6:	7f 03                	jg     0x6dbb
    6db8:	e9 57 03             	jmp    0x7112
    6dbb:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6dbf:	2b 46 f2             	sub    ax,WORD PTR [bp-0xe]
    6dc2:	71 05                	jno    0x6dc9
    6dc4:	9a 3e 04 e6 6d       	call   0x6de6:0x43e
    6dc9:	89 86 8a fb          	mov    WORD PTR [bp-0x476],ax
    6dcd:	83 be 8a fb 00       	cmp    WORD PTR [bp-0x476],0x0
    6dd2:	7d 06                	jge    0x6dda
    6dd4:	31 c0                	xor    ax,ax
    6dd6:	89 86 8a fb          	mov    WORD PTR [bp-0x476],ax
    6dda:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6dde:	2d 01 00             	sub    ax,0x1
    6de1:	71 05                	jno    0x6de8
    6de3:	9a 3e 04 1c 6e       	call   0x6e1c:0x43e
    6de8:	89 86 fa fa          	mov    WORD PTR [bp-0x506],ax
    6dec:	31 c0                	xor    ax,ax
    6dee:	3b 86 fa fa          	cmp    ax,WORD PTR [bp-0x506]
    6df2:	7e 03                	jle    0x6df7
    6df4:	e9 92 02             	jmp    0x7089
    6df7:	89 86 d2 fb          	mov    WORD PTR [bp-0x42e],ax
    6dfb:	eb 04                	jmp    0x6e01
    6dfd:	ff 86 d2 fb          	inc    WORD PTR [bp-0x42e]
    6e01:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    6e05:	3b 86 8a fb          	cmp    ax,WORD PTR [bp-0x476]
    6e09:	7d 22                	jge    0x6e2d
    6e0b:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    6e11:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    6e15:	99                   	cwd
    6e16:	bf b1 66             	mov    di,0x66b1
    6e19:	9a 16 04 3f 6e       	call   0x6e3f:0x416
    6e1e:	8b f8                	mov    di,ax
    6e20:	c1 e7 03             	shl    di,0x3
    6e23:	9b dd 9b 6e fd       	fstp   QWORD PTR [bp+di-0x292]
    6e28:	90                   	nop
    6e29:	9b                   	fwait
    6e2a:	e9 4f 02             	jmp    0x707c
    6e2d:	83 be 28 fb 00       	cmp    WORD PTR [bp-0x4d8],0x0
    6e32:	75 67                	jne    0x6e9b
    6e34:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    6e38:	99                   	cwd
    6e39:	bf b1 66             	mov    di,0x66b1
    6e3c:	9a 16 04 56 6e       	call   0x6e56:0x416
    6e41:	8b f8                	mov    di,ax
    6e43:	c1 e7 02             	shl    di,0x2
    6e46:	9b db 83 06 ff       	fild   DWORD PTR [bp+di-0xfa]
    6e4b:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    6e4f:	99                   	cwd
    6e50:	bf b1 66             	mov    di,0x66b1
    6e53:	9a 16 04 59 6f       	call   0x6f59:0x416
    6e58:	8b f8                	mov    di,ax
    6e5a:	c1 e7 03             	shl    di,0x3
    6e5d:	9b dc 8b d6 fb       	fmul   QWORD PTR [bp+di-0x42a]
    6e62:	83 ec 08             	sub    sp,0x8
    6e65:	89 e3                	mov    bx,sp
    6e67:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6e6b:	90                   	nop
    6e6c:	9b 9b df 46 f2       	fild   WORD PTR [bp-0xe]
    6e71:	83 ec 08             	sub    sp,0x8
    6e74:	89 e3                	mov    bx,sp
    6e76:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6e7a:	90                   	nop
    6e7b:	9b                   	fwait
    6e7c:	9a a7 2e 8f 6e       	call   0x6e8f:0x2ea7
    6e81:	83 ec 08             	sub    sp,0x8
    6e84:	89 e3                	mov    bx,sp
    6e86:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6e8a:	90                   	nop
    6e8b:	9b                   	fwait
    6e8c:	9a a6 2f 34 6f       	call   0x6f34:0x2fa6
    6e91:	9b dd 9e 82 fb       	fstp   QWORD PTR [bp-0x47e]
    6e96:	90                   	nop
    6e97:	9b                   	fwait
    6e98:	e9 9b 01             	jmp    0x7036
    6e9b:	9b dd 46 ea          	fld    QWORD PTR [bp-0x16]
    6e9f:	9b 2e d8 1e b1 66    	fcomp  DWORD PTR cs:0x66b1
    6ea5:	9b dd be f8 fa       	fstsw  WORD PTR [bp-0x508]
    6eaa:	90                   	nop
    6eab:	9b                   	fwait
    6eac:	8a a6 f9 fa          	mov    ah,BYTE PTR [bp-0x507]
    6eb0:	9e                   	sahf
    6eb1:	73 4e                	jae    0x6f01
    6eb3:	83 7e f2 04          	cmp    WORD PTR [bp-0xe],0x4
    6eb7:	7f 0f                	jg     0x6ec8
    6eb9:	9b 2e d9 06 c1 66    	fld    DWORD PTR cs:0x66c1
    6ebf:	9b dd 9e 20 fb       	fstp   QWORD PTR [bp-0x4e0]
    6ec4:	90                   	nop
    6ec5:	9b                   	fwait
    6ec6:	eb 37                	jmp    0x6eff
    6ec8:	83 7e f2 06          	cmp    WORD PTR [bp-0xe],0x6
    6ecc:	7f 0f                	jg     0x6edd
    6ece:	9b 2e d9 06 c5 66    	fld    DWORD PTR cs:0x66c5
    6ed4:	9b dd 9e 20 fb       	fstp   QWORD PTR [bp-0x4e0]
    6ed9:	90                   	nop
    6eda:	9b                   	fwait
    6edb:	eb 22                	jmp    0x6eff
    6edd:	83 7e f2 0f          	cmp    WORD PTR [bp-0xe],0xf
    6ee1:	7f 0f                	jg     0x6ef2
    6ee3:	9b 2e d9 06 c9 66    	fld    DWORD PTR cs:0x66c9
    6ee9:	9b dd 9e 20 fb       	fstp   QWORD PTR [bp-0x4e0]
    6eee:	90                   	nop
    6eef:	9b                   	fwait
    6ef0:	eb 0d                	jmp    0x6eff
    6ef2:	9b 2e d9 06 cd 66    	fld    DWORD PTR cs:0x66cd
    6ef8:	9b dd 9e 20 fb       	fstp   QWORD PTR [bp-0x4e0]
    6efd:	90                   	nop
    6efe:	9b                   	fwait
    6eff:	eb 0b                	jmp    0x6f0c
    6f01:	9b dd 46 ea          	fld    QWORD PTR [bp-0x16]
    6f05:	9b dd 9e 20 fb       	fstp   QWORD PTR [bp-0x4e0]
    6f0a:	90                   	nop
    6f0b:	9b 9b dd 86 20 fb    	fld    QWORD PTR [bp-0x4e0]
    6f11:	9b 2e d8 0e d1 66    	fmul   DWORD PTR cs:0x66d1
    6f17:	83 ec 08             	sub    sp,0x8
    6f1a:	89 e3                	mov    bx,sp
    6f1c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6f20:	90                   	nop
    6f21:	9b 9b df 46 f2       	fild   WORD PTR [bp-0xe]
    6f26:	83 ec 08             	sub    sp,0x8
    6f29:	89 e3                	mov    bx,sp
    6f2b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6f2f:	90                   	nop
    6f30:	9b                   	fwait
    6f31:	9a a7 2e 44 6f       	call   0x6f44:0x2ea7
    6f36:	83 ec 08             	sub    sp,0x8
    6f39:	89 e3                	mov    bx,sp
    6f3b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6f3f:	90                   	nop
    6f40:	9b                   	fwait
    6f41:	9a a6 2f ad 6f       	call   0x6fad:0x2fa6
    6f46:	9b dd 9e 18 fb       	fstp   QWORD PTR [bp-0x4e8]
    6f4b:	90                   	nop
    6f4c:	9b                   	fwait
    6f4d:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    6f51:	2d 01 00             	sub    ax,0x1
    6f54:	71 05                	jno    0x6f5b
    6f56:	9a 3e 04 64 6f       	call   0x6f64:0x43e
    6f5b:	2b 86 d2 fb          	sub    ax,WORD PTR [bp-0x42e]
    6f5f:	71 05                	jno    0x6f66
    6f61:	9a 3e 04 72 6f       	call   0x6f72:0x43e
    6f66:	8b d0                	mov    dx,ax
    6f68:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    6f6b:	2b c2                	sub    ax,dx
    6f6d:	71 05                	jno    0x6f74
    6f6f:	9a 3e 04 83 6f       	call   0x6f83:0x43e
    6f74:	89 86 16 fb          	mov    WORD PTR [bp-0x4ea],ax
    6f78:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    6f7c:	99                   	cwd
    6f7d:	bf b1 66             	mov    di,0x66b1
    6f80:	9a 16 04 9d 6f       	call   0x6f9d:0x416
    6f85:	8b f8                	mov    di,ax
    6f87:	c1 e7 03             	shl    di,0x3
    6f8a:	9b dd 83 6e fd       	fld    QWORD PTR [bp+di-0x292]
    6f8f:	9b dc 8e 18 fb       	fmul   QWORD PTR [bp-0x4e8]
    6f94:	9b 2e d9 06 d1 66    	fld    DWORD PTR cs:0x66d1
    6f9a:	9a b2 04 c1 6f       	call   0x6fc1:0x4b2
    6f9f:	83 ec 08             	sub    sp,0x8
    6fa2:	89 e3                	mov    bx,sp
    6fa4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6fa8:	90                   	nop
    6fa9:	9b                   	fwait
    6faa:	9a a6 2f eb 6f       	call   0x6feb:0x2fa6
    6faf:	9b dd 9e 0e fb       	fstp   QWORD PTR [bp-0x4f2]
    6fb4:	90                   	nop
    6fb5:	9b                   	fwait
    6fb6:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    6fba:	99                   	cwd
    6fbb:	bf b1 66             	mov    di,0x66b1
    6fbe:	9a 16 04 41 70       	call   0x7041:0x416
    6fc3:	8b f8                	mov    di,ax
    6fc5:	c1 e7 03             	shl    di,0x3
    6fc8:	ff b3 74 fd          	push   WORD PTR [bp+di-0x28c]
    6fcc:	ff b3 72 fd          	push   WORD PTR [bp+di-0x28e]
    6fd0:	ff b3 70 fd          	push   WORD PTR [bp+di-0x290]
    6fd4:	ff b3 6e fd          	push   WORD PTR [bp+di-0x292]
    6fd8:	9b df 86 16 fb       	fild   WORD PTR [bp-0x4ea]
    6fdd:	83 ec 08             	sub    sp,0x8
    6fe0:	89 e3                	mov    bx,sp
    6fe2:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6fe6:	90                   	nop
    6fe7:	9b                   	fwait
    6fe8:	9a a7 2e fb 6f       	call   0x6ffb:0x2ea7
    6fed:	83 ec 08             	sub    sp,0x8
    6ff0:	89 e3                	mov    bx,sp
    6ff2:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6ff6:	90                   	nop
    6ff7:	9b                   	fwait
    6ff8:	9a a6 2f e0 70       	call   0x70e0:0x2fa6
    6ffd:	9b dd 9e 06 fb       	fstp   QWORD PTR [bp-0x4fa]
    7002:	90                   	nop
    7003:	9b 9b dd 86 0e fb    	fld    QWORD PTR [bp-0x4f2]
    7009:	9b dc 9e 06 fb       	fcomp  QWORD PTR [bp-0x4fa]
    700e:	9b dd be f8 fa       	fstsw  WORD PTR [bp-0x508]
    7013:	90                   	nop
    7014:	9b                   	fwait
    7015:	8a a6 f9 fa          	mov    ah,BYTE PTR [bp-0x507]
    7019:	9e                   	sahf
    701a:	76 0e                	jbe    0x702a
    701c:	9b dd 86 0e fb       	fld    QWORD PTR [bp-0x4f2]
    7021:	9b dd 9e 82 fb       	fstp   QWORD PTR [bp-0x47e]
    7026:	90                   	nop
    7027:	9b                   	fwait
    7028:	eb 0c                	jmp    0x7036
    702a:	9b dd 86 06 fb       	fld    QWORD PTR [bp-0x4fa]
    702f:	9b dd 9e 82 fb       	fstp   QWORD PTR [bp-0x47e]
    7034:	90                   	nop
    7035:	9b                   	fwait
    7036:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    703a:	99                   	cwd
    703b:	bf b1 66             	mov    di,0x66b1
    703e:	9a 16 04 5d 70       	call   0x705d:0x416
    7043:	8b f8                	mov    di,ax
    7045:	c1 e7 03             	shl    di,0x3
    7048:	9b dd 83 6e fd       	fld    QWORD PTR [bp+di-0x292]
    704d:	9b dc a6 82 fb       	fsub   QWORD PTR [bp-0x47e]
    7052:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    7056:	99                   	cwd
    7057:	bf b1 66             	mov    di,0x66b1
    705a:	9a 16 04 b1 70       	call   0x70b1:0x416
    705f:	8b f8                	mov    di,ax
    7061:	c1 e7 03             	shl    di,0x3
    7064:	9b dd 9b 6e fd       	fstp   QWORD PTR [bp+di-0x292]
    7069:	90                   	nop
    706a:	9b 9b dd 86 9c fb    	fld    QWORD PTR [bp-0x464]
    7070:	9b dc 86 82 fb       	fadd   QWORD PTR [bp-0x47e]
    7075:	9b dd 9e 9c fb       	fstp   QWORD PTR [bp-0x464]
    707a:	90                   	nop
    707b:	9b                   	fwait
    707c:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    7080:	3b 86 fa fa          	cmp    ax,WORD PTR [bp-0x506]
    7084:	74 03                	je     0x7089
    7086:	e9 74 fd             	jmp    0x6dfd
    7089:	9b dd 86 a4 fb       	fld    QWORD PTR [bp-0x45c]
    708e:	9b dc 86 9c fb       	fadd   QWORD PTR [bp-0x464]
    7093:	9b dd 9e a4 fb       	fstp   QWORD PTR [bp-0x45c]
    7098:	90                   	nop
    7099:	9b                   	fwait
    709a:	c7 86 d0 fb 01 00    	mov    WORD PTR [bp-0x430],0x1
    70a0:	eb 04                	jmp    0x70a6
    70a2:	ff 86 d0 fb          	inc    WORD PTR [bp-0x430]
    70a6:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    70aa:	99                   	cwd
    70ab:	bf b9 66             	mov    di,0x66b9
    70ae:	9a 16 04 fd 70       	call   0x70fd:0x416
    70b3:	8b f8                	mov    di,ax
    70b5:	c1 e7 02             	shl    di,0x2
    70b8:	9b db 83 b4 fb       	fild   DWORD PTR [bp+di-0x44c]
    70bd:	9b dc 8e 9c fb       	fmul   QWORD PTR [bp-0x464]
    70c2:	83 ec 08             	sub    sp,0x8
    70c5:	89 e3                	mov    bx,sp
    70c7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    70cb:	90                   	nop
    70cc:	9b 9b db 86 ac fb    	fild   DWORD PTR [bp-0x454]
    70d2:	83 ec 08             	sub    sp,0x8
    70d5:	89 e3                	mov    bx,sp
    70d7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    70db:	90                   	nop
    70dc:	9b                   	fwait
    70dd:	9a a7 2e f0 70       	call   0x70f0:0x2ea7
    70e2:	83 ec 08             	sub    sp,0x8
    70e5:	89 e3                	mov    bx,sp
    70e7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    70eb:	90                   	nop
    70ec:	9b                   	fwait
    70ed:	9a a6 2f 9d 71       	call   0x719d:0x2fa6
    70f2:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    70f6:	99                   	cwd
    70f7:	bf b9 66             	mov    di,0x66b9
    70fa:	9a 16 04 3b 71       	call   0x713b:0x416
    70ff:	8b f8                	mov    di,ax
    7101:	c1 e7 03             	shl    di,0x3
    7104:	9b dd 9b 84 fb       	fstp   QWORD PTR [bp+di-0x47c]
    7109:	90                   	nop
    710a:	9b                   	fwait
    710b:	83 be d0 fb 02       	cmp    WORD PTR [bp-0x430],0x2
    7110:	75 90                	jne    0x70a2
    7112:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    7118:	9b dd 9e 7a fb       	fstp   QWORD PTR [bp-0x486]
    711d:	90                   	nop
    711e:	9b                   	fwait
    711f:	8b 86 c0 fb          	mov    ax,WORD PTR [bp-0x440]
    7123:	8b 96 c2 fb          	mov    dx,WORD PTR [bp-0x43e]
    7127:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    712b:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    712f:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    7133:	2d 01 00             	sub    ax,0x1
    7136:	71 05                	jno    0x713d
    7138:	9a 3e 04 61 71       	call   0x7161:0x43e
    713d:	89 86 fa fa          	mov    WORD PTR [bp-0x506],ax
    7141:	31 c0                	xor    ax,ax
    7143:	3b 86 fa fa          	cmp    ax,WORD PTR [bp-0x506]
    7147:	7e 03                	jle    0x714c
    7149:	e9 2a 02             	jmp    0x7376
    714c:	89 86 d2 fb          	mov    WORD PTR [bp-0x42e],ax
    7150:	eb 04                	jmp    0x7156
    7152:	ff 86 d2 fb          	inc    WORD PTR [bp-0x42e]
    7156:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    715a:	99                   	cwd
    715b:	bf b1 66             	mov    di,0x66b1
    715e:	9a 16 04 83 71       	call   0x7183:0x416
    7163:	8b f8                	mov    di,ax
    7165:	c1 e7 03             	shl    di,0x3
    7168:	ff b3 74 fd          	push   WORD PTR [bp+di-0x28c]
    716c:	ff b3 72 fd          	push   WORD PTR [bp+di-0x28e]
    7170:	ff b3 70 fd          	push   WORD PTR [bp+di-0x290]
    7174:	ff b3 6e fd          	push   WORD PTR [bp+di-0x292]
    7178:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    717c:	99                   	cwd
    717d:	bf b1 66             	mov    di,0x66b1
    7180:	9a 16 04 b1 71       	call   0x71b1:0x416
    7185:	8b f8                	mov    di,ax
    7187:	c1 e7 02             	shl    di,0x2
    718a:	9b db 83 06 ff       	fild   DWORD PTR [bp+di-0xfa]
    718f:	83 ec 08             	sub    sp,0x8
    7192:	89 e3                	mov    bx,sp
    7194:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    7198:	90                   	nop
    7199:	9b                   	fwait
    719a:	9a a7 2e 1a 72       	call   0x721a:0x2ea7
    719f:	9b dd 9e 6e fb       	fstp   QWORD PTR [bp-0x492]
    71a4:	90                   	nop
    71a5:	9b                   	fwait
    71a6:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    71aa:	99                   	cwd
    71ab:	bf b1 66             	mov    di,0x66b1
    71ae:	9a 16 04 d9 71       	call   0x71d9:0x416
    71b3:	8b f8                	mov    di,ax
    71b5:	c1 e7 02             	shl    di,0x2
    71b8:	8b 83 06 ff          	mov    ax,WORD PTR [bp+di-0xfa]
    71bc:	8b 93 08 ff          	mov    dx,WORD PTR [bp+di-0xf8]
    71c0:	3b 96 78 fb          	cmp    dx,WORD PTR [bp-0x488]
    71c4:	7c 08                	jl     0x71ce
    71c6:	7f 2a                	jg     0x71f2
    71c8:	3b 86 76 fb          	cmp    ax,WORD PTR [bp-0x48a]
    71cc:	77 24                	ja     0x71f2
    71ce:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    71d2:	99                   	cwd
    71d3:	bf b1 66             	mov    di,0x66b1
    71d6:	9a 16 04 3f 72       	call   0x723f:0x416
    71db:	8b f8                	mov    di,ax
    71dd:	c1 e7 02             	shl    di,0x2
    71e0:	8b 83 06 ff          	mov    ax,WORD PTR [bp+di-0xfa]
    71e4:	8b 93 08 ff          	mov    dx,WORD PTR [bp+di-0xf8]
    71e8:	89 86 5a fb          	mov    WORD PTR [bp-0x4a6],ax
    71ec:	89 96 5c fb          	mov    WORD PTR [bp-0x4a4],dx
    71f0:	eb 10                	jmp    0x7202
    71f2:	8b 86 76 fb          	mov    ax,WORD PTR [bp-0x48a]
    71f6:	8b 96 78 fb          	mov    dx,WORD PTR [bp-0x488]
    71fa:	89 86 5a fb          	mov    WORD PTR [bp-0x4a6],ax
    71fe:	89 96 5c fb          	mov    WORD PTR [bp-0x4a4],dx
    7202:	9b db 86 5a fb       	fild   DWORD PTR [bp-0x4a6]
    7207:	9b dc 8e 6e fb       	fmul   QWORD PTR [bp-0x492]
    720c:	83 ec 08             	sub    sp,0x8
    720f:	89 e3                	mov    bx,sp
    7211:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    7215:	90                   	nop
    7216:	9b                   	fwait
    7217:	9a a6 2f 20 73       	call   0x7320:0x2fa6
    721c:	9b dd 9e 66 fb       	fstp   QWORD PTR [bp-0x49a]
    7221:	90                   	nop
    7222:	9b 9b dd 86 7a fb    	fld    QWORD PTR [bp-0x486]
    7228:	9b dc 86 66 fb       	fadd   QWORD PTR [bp-0x49a]
    722d:	9b dd 9e 7a fb       	fstp   QWORD PTR [bp-0x486]
    7232:	90                   	nop
    7233:	9b                   	fwait
    7234:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    7238:	99                   	cwd
    7239:	bf b1 66             	mov    di,0x66b1
    723c:	9a 16 04 5b 72       	call   0x725b:0x416
    7241:	8b f8                	mov    di,ax
    7243:	c1 e7 02             	shl    di,0x2
    7246:	8b 83 06 ff          	mov    ax,WORD PTR [bp+di-0xfa]
    724a:	8b 93 08 ff          	mov    dx,WORD PTR [bp+di-0xf8]
    724e:	2b 86 5a fb          	sub    ax,WORD PTR [bp-0x4a6]
    7252:	1b 96 5c fb          	sbb    dx,WORD PTR [bp-0x4a4]
    7256:	71 05                	jno    0x725d
    7258:	9a 3e 04 6c 72       	call   0x726c:0x43e
    725d:	8b c8                	mov    cx,ax
    725f:	8b da                	mov    bx,dx
    7261:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    7265:	99                   	cwd
    7266:	bf b1 66             	mov    di,0x66b1
    7269:	9a 16 04 86 72       	call   0x7286:0x416
    726e:	8b f8                	mov    di,ax
    7270:	c1 e7 02             	shl    di,0x2
    7273:	89 8b 06 ff          	mov    WORD PTR [bp+di-0xfa],cx
    7277:	89 9b 08 ff          	mov    WORD PTR [bp+di-0xf8],bx
    727b:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    727f:	99                   	cwd
    7280:	bf b1 66             	mov    di,0x66b1
    7283:	9a 16 04 a2 72       	call   0x72a2:0x416
    7288:	8b f8                	mov    di,ax
    728a:	c1 e7 03             	shl    di,0x3
    728d:	9b dd 83 6e fd       	fld    QWORD PTR [bp+di-0x292]
    7292:	9b dc a6 66 fb       	fsub   QWORD PTR [bp-0x49a]
    7297:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    729b:	99                   	cwd
    729c:	bf b1 66             	mov    di,0x66b1
    729f:	9a 16 04 c5 72       	call   0x72c5:0x416
    72a4:	8b f8                	mov    di,ax
    72a6:	c1 e7 03             	shl    di,0x3
    72a9:	9b dd 9b 6e fd       	fstp   QWORD PTR [bp+di-0x292]
    72ae:	90                   	nop
    72af:	9b                   	fwait
    72b0:	8b 86 76 fb          	mov    ax,WORD PTR [bp-0x48a]
    72b4:	8b 96 78 fb          	mov    dx,WORD PTR [bp-0x488]
    72b8:	2b 86 5a fb          	sub    ax,WORD PTR [bp-0x4a6]
    72bc:	1b 96 5c fb          	sbb    dx,WORD PTR [bp-0x4a4]
    72c0:	71 05                	jno    0x72c7
    72c2:	9a 3e 04 f8 72       	call   0x72f8:0x43e
    72c7:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    72cb:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    72cf:	83 7e f2 00          	cmp    WORD PTR [bp-0xe],0x0
    72d3:	7f 03                	jg     0x72d8
    72d5:	e9 91 00             	jmp    0x7369
    72d8:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    72dc:	3b 86 8a fb          	cmp    ax,WORD PTR [bp-0x476]
    72e0:	7d 09                	jge    0x72eb
    72e2:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    72e5:	89 86 58 fb          	mov    WORD PTR [bp-0x4a8],ax
    72e9:	eb 13                	jmp    0x72fe
    72eb:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    72ef:	2b 86 d2 fb          	sub    ax,WORD PTR [bp-0x42e]
    72f3:	71 05                	jno    0x72fa
    72f5:	9a 3e 04 32 73       	call   0x7332:0x43e
    72fa:	89 86 58 fb          	mov    WORD PTR [bp-0x4a8],ax
    72fe:	9b df 86 58 fb       	fild   WORD PTR [bp-0x4a8]
    7303:	83 ec 08             	sub    sp,0x8
    7306:	89 e3                	mov    bx,sp
    7308:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    730c:	90                   	nop
    730d:	9b 9b df 46 f2       	fild   WORD PTR [bp-0xe]
    7312:	83 ec 08             	sub    sp,0x8
    7315:	89 e3                	mov    bx,sp
    7317:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    731b:	90                   	nop
    731c:	9b                   	fwait
    731d:	9a a7 2e 4f 73       	call   0x734f:0x2ea7
    7322:	9b db 86 5a fb       	fild   DWORD PTR [bp-0x4a6]
    7327:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    732b:	99                   	cwd
    732c:	bf b1 66             	mov    di,0x66b1
    732f:	9a 16 04 d8 73       	call   0x73d8:0x416
    7334:	8b f8                	mov    di,ax
    7336:	c1 e7 03             	shl    di,0x3
    7339:	9b dc 8b d6 fb       	fmul   QWORD PTR [bp+di-0x42a]
    733e:	9b de c9             	fmulp  st(1),st
    7341:	83 ec 08             	sub    sp,0x8
    7344:	89 e3                	mov    bx,sp
    7346:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    734a:	90                   	nop
    734b:	9b                   	fwait
    734c:	9a a6 2f 89 73       	call   0x7389:0x2fa6
    7351:	9b dd 9e 5e fb       	fstp   QWORD PTR [bp-0x4a2]
    7356:	90                   	nop
    7357:	9b 9b dd 86 a4 fb    	fld    QWORD PTR [bp-0x45c]
    735d:	9b dc a6 5e fb       	fsub   QWORD PTR [bp-0x4a2]
    7362:	9b dd 9e a4 fb       	fstp   QWORD PTR [bp-0x45c]
    7367:	90                   	nop
    7368:	9b                   	fwait
    7369:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    736d:	3b 86 fa fa          	cmp    ax,WORD PTR [bp-0x506]
    7371:	74 03                	je     0x7376
    7373:	e9 dc fd             	jmp    0x7152
    7376:	ff b6 80 fb          	push   WORD PTR [bp-0x480]
    737a:	ff b6 7e fb          	push   WORD PTR [bp-0x482]
    737e:	ff b6 7c fb          	push   WORD PTR [bp-0x484]
    7382:	ff b6 7a fb          	push   WORD PTR [bp-0x486]
    7386:	9a a6 2f 09 74       	call   0x7409:0x2fa6
    738b:	9b dd 9e 7a fb       	fstp   QWORD PTR [bp-0x486]
    7390:	90                   	nop
    7391:	9b                   	fwait
    7392:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    7396:	3b 86 fc fa          	cmp    ax,WORD PTR [bp-0x504]
    739a:	74 03                	je     0x739f
    739c:	e9 b2 f6             	jmp    0x6a51
    739f:	8b 46 2c             	mov    ax,WORD PTR [bp+0x2c]
    73a2:	89 86 d4 fb          	mov    WORD PTR [bp-0x42c],ax
    73a6:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    73ac:	9b dd 9e 50 fb       	fstp   QWORD PTR [bp-0x4b0]
    73b1:	90                   	nop
    73b2:	9b                   	fwait
    73b3:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    73b7:	89 86 fc fa          	mov    WORD PTR [bp-0x504],ax
    73bb:	31 c0                	xor    ax,ax
    73bd:	3b 86 fc fa          	cmp    ax,WORD PTR [bp-0x504]
    73c1:	7f 5e                	jg     0x7421
    73c3:	89 86 d2 fb          	mov    WORD PTR [bp-0x42e],ax
    73c7:	eb 04                	jmp    0x73cd
    73c9:	ff 86 d2 fb          	inc    WORD PTR [bp-0x42e]
    73cd:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    73d1:	99                   	cwd
    73d2:	bf b1 66             	mov    di,0x66b1
    73d5:	9a 16 04 ef 73       	call   0x73ef:0x416
    73da:	8b f8                	mov    di,ax
    73dc:	c1 e7 02             	shl    di,0x2
    73df:	9b db 83 06 ff       	fild   DWORD PTR [bp+di-0xfa]
    73e4:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    73e8:	99                   	cwd
    73e9:	bf b1 66             	mov    di,0x66b1
    73ec:	9a 16 04 62 74       	call   0x7462:0x416
    73f1:	8b f8                	mov    di,ax
    73f3:	c1 e7 03             	shl    di,0x3
    73f6:	9b dc 8b d6 fb       	fmul   QWORD PTR [bp+di-0x42a]
    73fb:	83 ec 08             	sub    sp,0x8
    73fe:	89 e3                	mov    bx,sp
    7400:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    7404:	90                   	nop
    7405:	9b                   	fwait
    7406:	9a a6 2f 10 75       	call   0x7510:0x2fa6
    740b:	9b dc 86 50 fb       	fadd   QWORD PTR [bp-0x4b0]
    7410:	9b dd 9e 50 fb       	fstp   QWORD PTR [bp-0x4b0]
    7415:	90                   	nop
    7416:	9b                   	fwait
    7417:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    741b:	3b 86 fc fa          	cmp    ax,WORD PTR [bp-0x504]
    741f:	75 a8                	jne    0x73c9
    7421:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    7427:	9b dd 9e 48 fb       	fstp   QWORD PTR [bp-0x4b8]
    742c:	90                   	nop
    742d:	9b                   	fwait
    742e:	31 c0                	xor    ax,ax
    7430:	89 86 44 fb          	mov    WORD PTR [bp-0x4bc],ax
    7434:	89 86 46 fb          	mov    WORD PTR [bp-0x4ba],ax
    7438:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    743c:	89 86 fc fa          	mov    WORD PTR [bp-0x504],ax
    7440:	31 c0                	xor    ax,ax
    7442:	3b 86 fc fa          	cmp    ax,WORD PTR [bp-0x504]
    7446:	7e 03                	jle    0x744b
    7448:	e9 a2 00             	jmp    0x74ed
    744b:	89 86 d2 fb          	mov    WORD PTR [bp-0x42e],ax
    744f:	eb 04                	jmp    0x7455
    7451:	ff 86 d2 fb          	inc    WORD PTR [bp-0x42e]
    7455:	8b 86 d4 fb          	mov    ax,WORD PTR [bp-0x42c]
    7459:	2b 86 d2 fb          	sub    ax,WORD PTR [bp-0x42e]
    745d:	71 05                	jno    0x7464
    745f:	9a 3e 04 6c 74       	call   0x746c:0x43e
    7464:	05 01 00             	add    ax,0x1
    7467:	71 05                	jno    0x746e
    7469:	9a 3e 04 7d 74       	call   0x747d:0x43e
    746e:	89 86 42 fb          	mov    WORD PTR [bp-0x4be],ax
    7472:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    7476:	99                   	cwd
    7477:	bf b1 66             	mov    di,0x66b1
    747a:	9a 16 04 94 74       	call   0x7494:0x416
    747f:	8b f8                	mov    di,ax
    7481:	c1 e7 02             	shl    di,0x2
    7484:	8b 8b 06 ff          	mov    cx,WORD PTR [bp+di-0xfa]
    7488:	8b 9b 08 ff          	mov    bx,WORD PTR [bp+di-0xf8]
    748c:	8b 86 42 fb          	mov    ax,WORD PTR [bp-0x4be]
    7490:	99                   	cwd
    7491:	9a 5c 17 ba 74       	call   0x74ba:0x175c
    7496:	89 86 f8 fa          	mov    WORD PTR [bp-0x508],ax
    749a:	89 96 fa fa          	mov    WORD PTR [bp-0x506],dx
    749e:	9b db 86 f8 fa       	fild   DWORD PTR [bp-0x508]
    74a3:	9b dc 86 48 fb       	fadd   QWORD PTR [bp-0x4b8]
    74a8:	9b dd 9e 48 fb       	fstp   QWORD PTR [bp-0x4b8]
    74ad:	90                   	nop
    74ae:	9b                   	fwait
    74af:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    74b3:	99                   	cwd
    74b4:	bf b1 66             	mov    di,0x66b1
    74b7:	9a 16 04 d6 74       	call   0x74d6:0x416
    74bc:	8b f8                	mov    di,ax
    74be:	c1 e7 02             	shl    di,0x2
    74c1:	8b 83 06 ff          	mov    ax,WORD PTR [bp+di-0xfa]
    74c5:	8b 93 08 ff          	mov    dx,WORD PTR [bp+di-0xf8]
    74c9:	03 86 44 fb          	add    ax,WORD PTR [bp-0x4bc]
    74cd:	13 96 46 fb          	adc    dx,WORD PTR [bp-0x4ba]
    74d1:	71 05                	jno    0x74d8
    74d3:	9a 3e 04 da 75       	call   0x75da:0x43e
    74d8:	89 86 44 fb          	mov    WORD PTR [bp-0x4bc],ax
    74dc:	89 96 46 fb          	mov    WORD PTR [bp-0x4ba],dx
    74e0:	8b 86 d2 fb          	mov    ax,WORD PTR [bp-0x42e]
    74e4:	3b 86 fc fa          	cmp    ax,WORD PTR [bp-0x504]
    74e8:	74 03                	je     0x74ed
    74ea:	e9 64 ff             	jmp    0x7451
    74ed:	ff b6 4e fb          	push   WORD PTR [bp-0x4b2]
    74f1:	ff b6 4c fb          	push   WORD PTR [bp-0x4b4]
    74f5:	ff b6 4a fb          	push   WORD PTR [bp-0x4b6]
    74f9:	ff b6 48 fb          	push   WORD PTR [bp-0x4b8]
    74fd:	9b db 86 44 fb       	fild   DWORD PTR [bp-0x4bc]
    7502:	83 ec 08             	sub    sp,0x8
    7505:	89 e3                	mov    bx,sp
    7507:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    750b:	90                   	nop
    750c:	9b                   	fwait
    750d:	9a a7 2e 8c 75       	call   0x758c:0x2ea7
    7512:	9b dd 9e 48 fb       	fstp   QWORD PTR [bp-0x4b8]
    7517:	90                   	nop
    7518:	9b                   	fwait
    7519:	c7 86 d0 fb 01 00    	mov    WORD PTR [bp-0x430],0x1
    751f:	eb 04                	jmp    0x7525
    7521:	ff 86 d0 fb          	inc    WORD PTR [bp-0x430]
    7525:	a1 06 1e             	mov    ax,ds:0x1e06
    7528:	3d 01 00             	cmp    ax,0x1
    752b:	75 10                	jne    0x753d
    752d:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    7533:	9b dd 9e fe fa       	fstp   QWORD PTR [bp-0x502]
    7538:	90                   	nop
    7539:	9b                   	fwait
    753a:	e9 f4 00             	jmp    0x7631
    753d:	3d 02 00             	cmp    ax,0x2
    7540:	75 56                	jne    0x7598
    7542:	9b dd 86 48 fb       	fld    QWORD PTR [bp-0x4b8]
    7547:	9b 2e d8 1e c5 66    	fcomp  DWORD PTR cs:0x66c5
    754d:	9b dd be fc fa       	fstsw  WORD PTR [bp-0x504]
    7552:	90                   	nop
    7553:	9b                   	fwait
    7554:	8a a6 fd fa          	mov    ah,BYTE PTR [bp-0x503]
    7558:	9e                   	sahf
    7559:	77 0f                	ja     0x756a
    755b:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    7561:	9b dd 9e fe fa       	fstp   QWORD PTR [bp-0x502]
    7566:	90                   	nop
    7567:	9b                   	fwait
    7568:	eb 2b                	jmp    0x7595
    756a:	9b dd 86 48 fb       	fld    QWORD PTR [bp-0x4b8]
    756f:	9b 2e d8 26 c5 66    	fsub   DWORD PTR cs:0x66c5
    7575:	9b 2e db 2e d5 66    	fld    TBYTE PTR cs:0x66d5
    757b:	9b de c9             	fmulp  st(1),st
    757e:	83 ec 08             	sub    sp,0x8
    7581:	89 e3                	mov    bx,sp
    7583:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    7587:	90                   	nop
    7588:	9b                   	fwait
    7589:	9a a6 2f 00 90       	call   0x9000:0x2fa6
    758e:	9b dd 9e fe fa       	fstp   QWORD PTR [bp-0x502]
    7593:	90                   	nop
    7594:	9b                   	fwait
    7595:	e9 99 00             	jmp    0x7631
    7598:	9b dd 86 48 fb       	fld    QWORD PTR [bp-0x4b8]
    759d:	9b 2e d8 1e c5 66    	fcomp  DWORD PTR cs:0x66c5
    75a3:	9b dd be fc fa       	fstsw  WORD PTR [bp-0x504]
    75a8:	90                   	nop
    75a9:	9b                   	fwait
    75aa:	8a a6 fd fa          	mov    ah,BYTE PTR [bp-0x503]
    75ae:	9e                   	sahf
    75af:	77 0f                	ja     0x75c0
    75b1:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    75b7:	9b dd 9e fe fa       	fstp   QWORD PTR [bp-0x502]
    75bc:	90                   	nop
    75bd:	9b                   	fwait
    75be:	eb 71                	jmp    0x7631
    75c0:	9b dd 86 48 fb       	fld    QWORD PTR [bp-0x4b8]
    75c5:	9b dd 9e fe fa       	fstp   QWORD PTR [bp-0x502]
    75ca:	90                   	nop
    75cb:	9b                   	fwait
    75cc:	9b 2e db 2e e9 66    	fld    TBYTE PTR cs:0x66e9
    75d2:	9b dc 86 fe fa       	fadd   QWORD PTR [bp-0x502]
    75d7:	9a 83 10 e5 75       	call   0x75e5:0x1083
    75dc:	9b 2e d8 0e f3 66    	fmul   DWORD PTR cs:0x66f3
    75e2:	9a 87 10 28 76       	call   0x7628:0x1087
    75e7:	9b dd 86 fe fa       	fld    QWORD PTR [bp-0x502]
    75ec:	9b 2e d8 26 c5 66    	fsub   DWORD PTR cs:0x66c5
    75f2:	9b d9 e1             	fabs
    75f5:	9b 2e db 2e df 66    	fld    TBYTE PTR cs:0x66df
    75fb:	9b de c9             	fmulp  st(1),st
    75fe:	9b de c9             	fmulp  st(1),st
    7601:	9b dd 86 fe fa       	fld    QWORD PTR [bp-0x502]
    7606:	9b dc 8e fe fa       	fmul   QWORD PTR [bp-0x502]
    760b:	9b dc 8e fe fa       	fmul   QWORD PTR [bp-0x502]
    7610:	9b dc 8e fe fa       	fmul   QWORD PTR [bp-0x502]
    7615:	9b dc 8e fe fa       	fmul   QWORD PTR [bp-0x502]
    761a:	9b dc 8e fe fa       	fmul   QWORD PTR [bp-0x502]
    761f:	9b 2e d8 06 f7 66    	fadd   DWORD PTR cs:0x66f7
    7625:	9a b2 04 3c 76       	call   0x763c:0x4b2
    762a:	9b dd 9e fe fa       	fstp   QWORD PTR [bp-0x502]
    762f:	90                   	nop
    7630:	9b                   	fwait
    7631:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    7635:	99                   	cwd
    7636:	bf b9 66             	mov    di,0x66b9
    7639:	9a 16 04 55 76       	call   0x7655:0x416
    763e:	8b f8                	mov    di,ax
    7640:	c1 e7 02             	shl    di,0x2
    7643:	9b db 43 ce          	fild   DWORD PTR [bp+di-0x32]
    7647:	9b dc 8e fe fa       	fmul   QWORD PTR [bp-0x502]
    764c:	9b 2e d9 06 d1 66    	fld    DWORD PTR cs:0x66d1
    7652:	9a b2 04 7e 76       	call   0x767e:0x4b2
    7657:	9b dd 9e fe fa       	fstp   QWORD PTR [bp-0x502]
    765c:	90                   	nop
    765d:	9b                   	fwait
    765e:	9b 2e d9 06 cd 66    	fld    DWORD PTR cs:0x66cd
    7664:	9b dc 86 fe fa       	fadd   QWORD PTR [bp-0x502]
    7669:	9b dd 9e fe fa       	fstp   QWORD PTR [bp-0x502]
    766e:	90                   	nop
    766f:	9b 9b dd 86 fe fa    	fld    QWORD PTR [bp-0x502]
    7675:	9b 2e d8 0e fb 66    	fmul   DWORD PTR cs:0x66fb
    767b:	9a 41 10 89 76       	call   0x7689:0x1041
    7680:	9b 2e d9 06 fb 66    	fld    DWORD PTR cs:0x66fb
    7686:	9a b2 04 9d 76       	call   0x769d:0x4b2
    768b:	9b dd 9e fe fa       	fstp   QWORD PTR [bp-0x502]
    7690:	90                   	nop
    7691:	9b                   	fwait
    7692:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    7696:	99                   	cwd
    7697:	bf b9 66             	mov    di,0x66b9
    769a:	9a 16 04 ea 76       	call   0x76ea:0x416
    769f:	8b f8                	mov    di,ax
    76a1:	c1 e7 03             	shl    di,0x3
    76a4:	9b dd 43 d2          	fld    QWORD PTR [bp+di-0x2e]
    76a8:	9b dc 8e fe fa       	fmul   QWORD PTR [bp-0x502]
    76ad:	9b dd 9e 3a fb       	fstp   QWORD PTR [bp-0x4c6]
    76b2:	90                   	nop
    76b3:	9b 9b dd 86 3a fb    	fld    QWORD PTR [bp-0x4c6]
    76b9:	9b 2e d8 1e b1 66    	fcomp  DWORD PTR cs:0x66b1
    76bf:	9b dd be fc fa       	fstsw  WORD PTR [bp-0x504]
    76c4:	90                   	nop
    76c5:	9b                   	fwait
    76c6:	8a a6 fd fa          	mov    ah,BYTE PTR [bp-0x503]
    76ca:	9e                   	sahf
    76cb:	73 0d                	jae    0x76da
    76cd:	9b 2e d9 06 b1 66    	fld    DWORD PTR cs:0x66b1
    76d3:	9b dd 9e 3a fb       	fstp   QWORD PTR [bp-0x4c6]
    76d8:	90                   	nop
    76d9:	9b 9b dd 86 3a fb    	fld    QWORD PTR [bp-0x4c6]
    76df:	8b 86 d0 fb          	mov    ax,WORD PTR [bp-0x430]
    76e3:	99                   	cwd
    76e4:	bf b9 66             	mov    di,0x66b9
    76e7:	9a 16 04 e5 7d       	call   0x7de5:0x416
    76ec:	8b f8                	mov    di,ax
    76ee:	c1 e7 03             	shl    di,0x3
    76f1:	9b dd 9b 22 fb       	fstp   QWORD PTR [bp+di-0x4de]
    76f6:	90                   	nop
    76f7:	9b                   	fwait
    76f8:	83 be d0 fb 02       	cmp    WORD PTR [bp-0x430],0x2
    76fd:	74 03                	je     0x7702
    76ff:	e9 1f fe             	jmp    0x7521
    7702:	9b dd 86 9c fb       	fld    QWORD PTR [bp-0x464]
    7707:	c4 7e 26             	les    di,DWORD PTR [bp+0x26]
    770a:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    770e:	90                   	nop
    770f:	9b 9b dd 86 8c fb    	fld    QWORD PTR [bp-0x474]
    7715:	c4 7e 22             	les    di,DWORD PTR [bp+0x22]
    7718:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    771c:	90                   	nop
    771d:	9b 9b dd 86 94 fb    	fld    QWORD PTR [bp-0x46c]
    7723:	c4 7e 1e             	les    di,DWORD PTR [bp+0x1e]
    7726:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    772a:	90                   	nop
    772b:	9b 9b dd 86 a4 fb    	fld    QWORD PTR [bp-0x45c]
    7731:	c4 7e 1a             	les    di,DWORD PTR [bp+0x1a]
    7734:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    7738:	90                   	nop
    7739:	9b 9b dd 86 7a fb    	fld    QWORD PTR [bp-0x486]
    773f:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    7742:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    7746:	90                   	nop
    7747:	9b 9b dd 86 50 fb    	fld    QWORD PTR [bp-0x4b0]
    774d:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    7750:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    7754:	90                   	nop
    7755:	9b 9b dd 86 2a fb    	fld    QWORD PTR [bp-0x4d6]
    775b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    775e:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    7762:	90                   	nop
    7763:	9b 9b dd 86 32 fb    	fld    QWORD PTR [bp-0x4ce]
    7769:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    776c:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    7770:	90                   	nop
    7771:	9b                   	fwait
    7772:	c9                   	leave
    7773:	ca 28 00             	retf   0x28
    7776:	0b 48 73             	or     cx,WORD PTR [bx+si+0x73]
    7779:	53                   	push   bx
    777a:	75 72                	jne    0x77ee
    777c:	43                   	inc    bx
    777d:	6f                   	outs   dx,WORD PTR ds:[si]
    777e:	75 74                	jne    0x77f4
    7780:	50                   	push   ax
    7781:	63 00                	arpl   WORD PTR [bx+si],ax
    7783:	00 fd                	add    ch,bh
    7785:	7e cd                	jle    0x7754
    7787:	78 0b                	js     0x7794
    7789:	54                   	push   sp
    778a:	61                   	popa
    778b:	75 78                	jne    0x7805
    778d:	45                   	inc    bp
    778e:	6d                   	ins    WORD PTR es:[di],dx
    778f:	70 72                	jo     0x7803
    7791:	75 6e                	jne    0x7801
    7793:	74 11                	je     0x77a6
    7795:	54                   	push   sp
    7796:	61                   	popa
    7797:	75 78                	jne    0x7811
    7799:	44                   	inc    sp
    779a:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    779e:	76 65                	jbe    0x7805
    77a0:	72 74                	jb     0x7816
    77a2:	41                   	inc    cx
    77a3:	75 74                	jne    0x7819
    77a5:	6f                   	outs   dx,WORD PTR ds:[si]
    77a6:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
    77a9:	75 78                	jne    0x7823
    77ab:	44                   	inc    sp
    77ac:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    77b0:	76 65                	jbe    0x7817
    77b2:	72 74                	jb     0x7828
    77b4:	4e                   	dec    si
    77b5:	41                   	inc    cx
    77b6:	75 74                	jne    0x782c
    77b8:	6f                   	outs   dx,WORD PTR ds:[si]
    77b9:	0d 54 61             	or     ax,0x6154
    77bc:	75 78                	jne    0x7836
    77be:	50                   	push   ax
    77bf:	6c                   	ins    BYTE PTR es:[di],dx
    77c0:	61                   	popa
    77c1:	63 65 6d             	arpl   WORD PTR [di+0x6d],sp
    77c4:	65 6e                	outs   dx,BYTE PTR gs:[si]
    77c6:	74 06                	je     0x77ce
    77c8:	54                   	push   sp
    77c9:	61                   	popa
    77ca:	75 78                	jne    0x7844
    77cc:	49                   	dec    cx
    77cd:	53                   	push   bx
    77ce:	07                   	pop    es
    77cf:	54                   	push   sp
    77d0:	61                   	popa
    77d1:	75 78                	jne    0x784b
    77d3:	54                   	push   sp
    77d4:	56                   	push   si
    77d5:	41                   	inc    cx
    77d6:	12 43 6f             	adc    al,BYTE PTR [bp+di+0x6f]
    77d9:	75 74                	jne    0x784f
    77db:	55                   	push   bp
    77dc:	6e                   	outs   dx,BYTE PTR ds:[si]
    77dd:	69 74 65 50 72       	imul   si,WORD PTR [si+0x65],0x7250
    77e2:	6f                   	outs   dx,WORD PTR ds:[si]
    77e3:	64 75 63             	fs jne 0x7849
    77e6:	74 69                	je     0x7851
    77e8:	66 10 43 6f          	data32 adc BYTE PTR [bp+di+0x6f],al
    77ec:	75 74                	jne    0x7862
    77ee:	55                   	push   bp
    77ef:	6e                   	outs   dx,BYTE PTR ds:[si]
    77f0:	69 74 65 56 65       	imul   si,WORD PTR [si+0x65],0x6556
    77f5:	6e                   	outs   dx,BYTE PTR ds:[si]
    77f6:	64 65 75 72          	fs gs jne 0x786c
    77fa:	0e                   	push   cs
    77fb:	43                   	inc    bx
    77fc:	6f                   	outs   dx,WORD PTR ds:[si]
    77fd:	75 74                	jne    0x7873
    77ff:	55                   	push   bp
    7800:	6e                   	outs   dx,BYTE PTR ds:[si]
    7801:	69 74 65 43 61       	imul   si,WORD PTR [si+0x65],0x6143
    7806:	64 72 65             	fs jb  0x786e
    7809:	0e                   	push   cs
    780a:	43                   	inc    bx
    780b:	6f                   	outs   dx,WORD PTR ds:[si]
    780c:	75 74                	jne    0x7882
    780e:	55                   	push   bp
    780f:	6e                   	outs   dx,BYTE PTR ds:[si]
    7810:	69 74 65 53 74       	imul   si,WORD PTR [si+0x65],0x7453
    7815:	6f                   	outs   dx,WORD PTR ds:[si]
    7816:	63 6b 10             	arpl   WORD PTR [bp+di+0x10],bp
    7819:	43                   	inc    bx
    781a:	6f                   	outs   dx,WORD PTR ds:[si]
    781b:	75 74                	jne    0x7891
    781d:	55                   	push   bp
    781e:	6e                   	outs   dx,BYTE PTR ds:[si]
    781f:	69 74 65 4d 61       	imul   si,WORD PTR [si+0x65],0x614d
    7824:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    7827:	6e                   	outs   dx,BYTE PTR ds:[si]
    7828:	65 12 48 65          	adc    cl,BYTE PTR gs:[bx+si+0x65]
    782c:	75 72                	jne    0x78a0
    782e:	65 73 50             	gs jae 0x7881
    7831:	61                   	popa
    7832:	72 50                	jb     0x7884
    7834:	72 6f                	jb     0x78a5
    7836:	64 75 63             	fs jne 0x789c
    7839:	74 69                	je     0x78a4
    783b:	66 08 43 6f          	data32 or BYTE PTR [bp+di+0x6f],al
    783f:	75 74                	jne    0x78b5
    7841:	46                   	inc    si
    7842:	69 78 65 0d 54       	imul   di,WORD PTR [bx+si+0x65],0x540d
    7847:	72 61                	jb     0x78aa
    7849:	6e                   	outs   dx,BYTE PTR ds:[si]
    784a:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    784d:	73 49                	jae    0x7898
    784f:	6d                   	ins    WORD PTR es:[di],dx
    7850:	6d                   	ins    WORD PTR es:[di],dx
    7851:	6f                   	outs   dx,WORD PTR ds:[si]
    7852:	62 11                	bound  dx,DWORD PTR [bx+di]
    7854:	53                   	push   bx
    7855:	75 70                	jne    0x78c7
    7857:	70 6c                	jo     0x78c5
    7859:	65 6d                	gs ins WORD PTR es:[di],dx
    785b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    785d:	74 54                	je     0x78b3
    785f:	72 61                	jb     0x78c2
    7861:	6e                   	outs   dx,BYTE PTR ds:[si]
    7862:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    7865:	0b 41 73             	or     ax,WORD PTR [bx+di+0x73]
    7868:	73 75                	jae    0x78df
    786a:	72 61                	jb     0x78cd
    786c:	6e                   	outs   dx,BYTE PTR ds:[si]
    786d:	63 65 50             	arpl   WORD PTR [di+0x50],sp
    7870:	63 12                	arpl   WORD PTR [bp+si],dx
    7872:	43                   	inc    bx
    7873:	6f                   	outs   dx,WORD PTR ds:[si]
    7874:	75 74                	jne    0x78ea
    7876:	4c                   	dec    sp
    7877:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    787c:	69 65 6d 65 6e       	imul   sp,WORD PTR [di+0x6d],0x6e65
    7881:	74 50                	je     0x78d3
    7883:	63 0e 43 6f          	arpl   WORD PTR ds:0x6f43,cx
    7887:	75 74                	jne    0x78fd
    7889:	45                   	inc    bp
    788a:	6d                   	ins    WORD PTR es:[di],dx
    788b:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    788e:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    7891:	50                   	push   ax
    7892:	63 0f                	arpl   WORD PTR [bx],cx
    7894:	44                   	inc    sp
    7895:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    7899:	76 65                	jbe    0x7900
    789b:	72 74                	jb     0x7911
    789d:	41                   	inc    cx
    789e:	75 74                	jne    0x7914
    78a0:	6f                   	outs   dx,WORD PTR ds:[si]
    78a1:	50                   	push   ax
    78a2:	63 11                	arpl   WORD PTR [bx+di],dx
    78a4:	43                   	inc    bx
    78a5:	72 65                	jb     0x790c
    78a7:	64 69 74 46 6f 75    	imul   si,WORD PTR fs:[si+0x46],0x756f
    78ad:	72 6e                	jb     0x791d
    78af:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    78b4:	72 13                	jb     0x78c9
    78b6:	43                   	inc    bx
    78b7:	6f                   	outs   dx,WORD PTR ds:[si]
    78b8:	75 74                	jne    0x792e
    78ba:	50                   	push   ax
    78bb:	6f                   	outs   dx,WORD PTR ds:[si]
    78bc:	69 6e 74 52 65       	imul   bp,WORD PTR [bp+0x74],0x6552
    78c1:	70 61                	jo     0x7924
    78c3:	72 61                	jb     0x7926
    78c5:	74 69                	je     0x7930
    78c7:	6f                   	outs   dx,WORD PTR ds:[si]
    78c8:	6e                   	outs   dx,BYTE PTR ds:[si]
    78c9:	00 00                	add    BYTE PTR [bx+si],al
    78cb:	3c 82                	cmp    al,0x82
    78cd:	f3 78 01             	repz js 0x78d1
    78d0:	00 00                	add    BYTE PTR [bx+si],al
    78d2:	00 02                	add    BYTE PTR [bp+si],al
    78d4:	00 00                	add    BYTE PTR [bx+si],al
    78d6:	00 0b                	add    BYTE PTR [bp+di],cl
    78d8:	50                   	push   ax
    78d9:	72 69                	jb     0x7944
    78db:	78 4d                	js     0x792a
    78dd:	69 6e 69 6d 75       	imul   bp,WORD PTR [bp+0x69],0x756d
    78e2:	6d                   	ins    WORD PTR es:[di],dx
    78e3:	0b 43 6f             	or     ax,WORD PTR [bp+di+0x6f]
    78e6:	75 74                	jne    0x795c
    78e8:	4d                   	dec    bp
    78e9:	61                   	popa
    78ea:	74 69                	je     0x7955
    78ec:	65 72 65             	gs jb  0x7954
    78ef:	00 00                	add    BYTE PTR [bx+si],al
    78f1:	2d 83 c7             	sub    ax,0xc783
    78f4:	79 10                	jns    0x7906
    78f6:	56                   	push   si
    78f7:	61                   	popa
    78f8:	72 69                	jb     0x7963
    78fa:	61                   	popa
    78fb:	74 69                	je     0x7966
    78fd:	6f                   	outs   dx,WORD PTR ds:[si]
    78fe:	6e                   	outs   dx,BYTE PTR ds:[si]
    78ff:	43                   	inc    bx
    7900:	61                   	popa
    7901:	70 69                	jo     0x796c
    7903:	74 61                	je     0x7966
    7905:	6c                   	ins    BYTE PTR es:[di],dx
    7906:	0a 44 69             	or     al,BYTE PTR [si+0x69]
    7909:	76 69                	jbe    0x7974
    790b:	64 65 6e             	fs outs dx,BYTE PTR gs:[si]
    790e:	64 65 73 10          	fs gs jae 0x7922
    7912:	56                   	push   si
    7913:	61                   	popa
    7914:	72 69                	jb     0x797f
    7916:	61                   	popa
    7917:	74 69                	je     0x7982
    7919:	6f                   	outs   dx,WORD PTR ds:[si]
    791a:	6e                   	outs   dx,BYTE PTR ds:[si]
    791b:	45                   	inc    bp
    791c:	6d                   	ins    WORD PTR es:[di],dx
    791d:	70 72                	jo     0x7991
    791f:	75 6e                	jne    0x798f
    7921:	74 0b                	je     0x792e
    7923:	53                   	push   bx
    7924:	75 62                	jne    0x7988
    7926:	76 65                	jbe    0x798d
    7928:	6e                   	outs   dx,BYTE PTR ds:[si]
    7929:	74 69                	je     0x7994
    792b:	6f                   	outs   dx,WORD PTR ds:[si]
    792c:	6e                   	outs   dx,BYTE PTR ds:[si]
    792d:	73 13                	jae    0x7942
    792f:	50                   	push   ax
    7930:	72 6f                	jb     0x79a1
    7932:	64 75 69             	fs jne 0x799e
    7935:	74 73                	je     0x79aa
    7937:	4f                   	dec    di
    7938:	75 43                	jne    0x797d
    793a:	68 61 72             	push   0x7261
    793d:	67 65 73 45          	addr32 gs jae 0x7986
    7941:	78 0d                	js     0x7950
    7943:	41                   	inc    cx
    7944:	63 68 61             	arpl   WORD PTR [bx+si+0x61],bp
    7947:	74 4d                	je     0x7996
    7949:	61                   	popa
    794a:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    794d:	6e                   	outs   dx,BYTE PTR ds:[si]
    794e:	65 73 0d             	gs jae 0x795e
    7951:	56                   	push   si
    7952:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7954:	74 65                	je     0x79bb
    7956:	4d                   	dec    bp
    7957:	61                   	popa
    7958:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    795b:	6e                   	outs   dx,BYTE PTR ds:[si]
    795c:	65 73 13             	gs jae 0x7972
    795f:	45                   	inc    bp
    7960:	6e                   	outs   dx,BYTE PTR ds:[si]
    7961:	74 72                	je     0x79d5
    7963:	65 74 69             	gs je  0x79cf
    7966:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7968:	4d                   	dec    bp
    7969:	61                   	popa
    796a:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    796d:	6e                   	outs   dx,BYTE PTR ds:[si]
    796e:	65 73 50             	gs jae 0x79c1
    7971:	63 0f                	arpl   WORD PTR [bx],cx
    7973:	43                   	inc    bx
    7974:	61                   	popa
    7975:	64 72 65             	fs jb  0x79dd
    7978:	73 45                	jae    0x79bf
    797a:	6d                   	ins    WORD PTR es:[di],dx
    797b:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    797e:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    7981:	73 0f                	jae    0x7992
    7983:	43                   	inc    bx
    7984:	61                   	popa
    7985:	64 72 65             	fs jb  0x79ed
    7988:	73 4c                	jae    0x79d6
    798a:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    798f:	69 65 73 0e 49       	imul   sp,WORD PTR [di+0x73],0x490e
    7994:	6e                   	outs   dx,BYTE PTR ds:[si]
    7995:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    799b:	6c                   	ins    BYTE PTR es:[di],dx
    799c:	61                   	popa
    799d:	69 72 65 73 0e       	imul   si,WORD PTR [bp+si+0x65],0xe73
    79a2:	43                   	inc    bx
    79a3:	6f                   	outs   dx,WORD PTR ds:[si]
    79a4:	6d                   	ins    WORD PTR es:[di],dx
    79a5:	6d                   	ins    WORD PTR es:[di],dx
    79a6:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    79ab:	6e                   	outs   dx,BYTE PTR ds:[si]
    79ac:	46                   	inc    si
    79ad:	56                   	push   si
    79ae:	70 63                	jo     0x7a13
    79b0:	0b 46 6f             	or     ax,WORD PTR [bp+0x6f]
    79b3:	72 6d                	jb     0x7a22
    79b5:	61                   	popa
    79b6:	74 69                	je     0x7a21
    79b8:	6f                   	outs   dx,WORD PTR ds:[si]
    79b9:	6e                   	outs   dx,BYTE PTR ds:[si]
    79ba:	50                   	push   ax
    79bb:	63 06 45 74          	arpl   WORD PTR ds:0x7445,ax
    79bf:	75 64                	jne    0x7a25
    79c1:	65 73 00             	gs jae 0x79c4
    79c4:	00 97 85 4b          	add    BYTE PTR [bx+0x4b85],dl
    79c8:	7a 01                	jp     0x79cb
    79ca:	00 00                	add    BYTE PTR [bx+si],al
    79cc:	00 02                	add    BYTE PTR [bp+si],al
    79ce:	00 00                	add    BYTE PTR [bx+si],al
    79d0:	00 04                	add    BYTE PTR [si],al
    79d2:	50                   	push   ax
    79d3:	72 69                	jb     0x7a3e
    79d5:	78 0e                	js     0x79e5
    79d7:	53                   	push   bx
    79d8:	6f                   	outs   dx,WORD PTR ds:[si]
    79d9:	75 6d                	jne    0x7a48
    79db:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    79e0:	6e                   	outs   dx,BYTE PTR ds:[si]
    79e1:	50                   	push   ax
    79e2:	72 69                	jb     0x7a4d
    79e4:	78 09                	js     0x79ef
    79e6:	50                   	push   ax
    79e7:	75 62                	jne    0x7a4b
    79e9:	6c                   	ins    BYTE PTR es:[di],dx
    79ea:	69 63 69 74 65       	imul   sp,WORD PTR [bp+di+0x69],0x6574
    79ef:	0f 44 65 70          	cmove  sp,WORD PTR [di+0x70]
    79f3:	65 6e                	outs   dx,BYTE PTR gs:[si]
    79f5:	73 65                	jae    0x7a5c
    79f7:	73 51                	jae    0x7a4a
    79f9:	75 61                	jne    0x7a5c
    79fb:	6c                   	ins    BYTE PTR es:[di],dx
    79fc:	69 74 65 11 41       	imul   si,WORD PTR [si+0x65],0x4111
    7a01:	63 74 69             	arpl   WORD PTR [si+0x69],si
    7a04:	6f                   	outs   dx,WORD PTR ds:[si]
    7a05:	6e                   	outs   dx,BYTE PTR ds:[si]
    7a06:	43                   	inc    bx
    7a07:	6f                   	outs   dx,WORD PTR ds:[si]
    7a08:	6d                   	ins    WORD PTR es:[di],dx
    7a09:	6d                   	ins    WORD PTR es:[di],dx
    7a0a:	65 72 63             	gs jb  0x7a70
    7a0d:	69 61 6c 65 12       	imul   sp,WORD PTR [bx+di+0x6c],0x1265
    7a12:	50                   	push   ax
    7a13:	72 6f                	jb     0x7a84
    7a15:	64 75 63             	fs jne 0x7a7b
    7a18:	74 69                	je     0x7a83
    7a1a:	66 73 41             	data32 jae 0x7a5e
    7a1d:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    7a23:	73 10                	jae    0x7a35
    7a25:	56                   	push   si
    7a26:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7a28:	64 65 75 72          	fs gs jne 0x7a9e
    7a2c:	73 41                	jae    0x7a6f
    7a2e:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    7a34:	73 11                	jae    0x7a47
    7a36:	44                   	inc    sp
    7a37:	75 72                	jne    0x7aab
    7a39:	65 65 43             	gs gs inc bx
    7a3c:	72 65                	jb     0x7aa3
    7a3e:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    7a44:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7a46:	74 00                	je     0x7a48
    7a48:	00 ec                	add    ah,ch
    7a4a:	87 fd                	xchg   bp,di
    7a4c:	7a 0d                	jp     0x7a5b
    7a4e:	43                   	inc    bx
    7a4f:	61                   	popa
    7a50:	70 69                	jo     0x7abb
    7a52:	74 61                	je     0x7ab5
    7a54:	6c                   	ins    BYTE PTR es:[di],dx
    7a55:	53                   	push   bx
    7a56:	6f                   	outs   dx,WORD PTR ds:[si]
    7a57:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    7a5a:	6c                   	ins    BYTE PTR es:[di],dx
    7a5b:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
    7a5e:	73 65                	jae    0x7ac5
    7a60:	72 76                	jb     0x7ad8
    7a62:	65 73 0b             	gs jae 0x7a70
    7a65:	52                   	push   dx
    7a66:	65 73 75             	gs jae 0x7ade
    7a69:	6c                   	ins    BYTE PTR es:[di],dx
    7a6a:	74 61                	je     0x7acd
    7a6c:	74 4e                	je     0x7abc
    7a6e:	65 74 05             	gs je  0x7a76
    7a71:	49                   	dec    cx
    7a72:	6d                   	ins    WORD PTR es:[di],dx
    7a73:	70 6f                	jo     0x7ae4
    7a75:	74 03                	je     0x7a7a
    7a77:	49                   	dec    cx
    7a78:	46                   	inc    si
    7a79:	41                   	inc    cx
    7a7a:	07                   	pop    es
    7a7b:	43                   	inc    bx
    7a7c:	6c                   	ins    BYTE PTR es:[di],dx
    7a7d:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    7a82:	0c 46                	or     al,0x46
    7a84:	6f                   	outs   dx,WORD PTR ds:[si]
    7a85:	75 72                	jne    0x7af9
    7a87:	6e                   	outs   dx,BYTE PTR ds:[si]
    7a88:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    7a8d:	72 73                	jb     0x7b02
    7a8f:	0a 54 72             	or     dl,BYTE PTR [si+0x72]
    7a92:	65 73 6f             	gs jae 0x7b04
    7a95:	72 65                	jb     0x7afc
    7a97:	72 69                	jb     0x7b02
    7a99:	65 07                	gs pop es
    7a9b:	45                   	inc    bp
    7a9c:	6d                   	ins    WORD PTR es:[di],dx
    7a9d:	70 72                	jo     0x7b11
    7a9f:	75 6e                	jne    0x7b0f
    7aa1:	74 0d                	je     0x7ab0
    7aa3:	44                   	inc    sp
    7aa4:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    7aa8:	76 65                	jbe    0x7b0f
    7aaa:	72 74                	jb     0x7b20
    7aac:	41                   	inc    cx
    7aad:	75 74                	jne    0x7b23
    7aaf:	6f                   	outs   dx,WORD PTR ds:[si]
    7ab0:	0e                   	push   cs
    7ab1:	44                   	inc    sp
    7ab2:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    7ab6:	76 65                	jbe    0x7b1d
    7ab8:	72 74                	jb     0x7b2e
    7aba:	4e                   	dec    si
    7abb:	41                   	inc    cx
    7abc:	75 74                	jne    0x7b32
    7abe:	6f                   	outs   dx,WORD PTR ds:[si]
    7abf:	08 4d 61             	or     BYTE PTR [di+0x61],cl
    7ac2:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    7ac5:	6e                   	outs   dx,BYTE PTR ds:[si]
    7ac6:	65 73 15             	gs jae 0x7ade
    7ac9:	49                   	dec    cx
    7aca:	6d                   	ins    WORD PTR es:[di],dx
    7acb:	6d                   	ins    WORD PTR es:[di],dx
    7acc:	6f                   	outs   dx,WORD PTR ds:[si]
    7acd:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
    7ad0:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    7ad5:	6f                   	outs   dx,WORD PTR ds:[si]
    7ad6:	6e                   	outs   dx,BYTE PTR ds:[si]
    7ad7:	73 42                	jae    0x7b1b
    7ad9:	72 75                	jb     0x7b50
    7adb:	74 65                	je     0x7b42
    7add:	73 0a                	jae    0x7ae9
    7adf:	50                   	push   ax
    7ae0:	72 6f                	jb     0x7b51
    7ae2:	64 75 63             	fs jne 0x7b48
    7ae5:	74 69                	je     0x7b50
    7ae7:	66 73 08             	data32 jae 0x7af2
    7aea:	56                   	push   si
    7aeb:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7aed:	64 65 75 72          	fs gs jne 0x7b63
    7af1:	73 06                	jae    0x7af9
    7af3:	43                   	inc    bx
    7af4:	61                   	popa
    7af5:	64 72 65             	fs jb  0x7b5d
    7af8:	73 00                	jae    0x7afa
    7afa:	00 a8 8a 36          	add    BYTE PTR [bx+si+0x368a],ch
    7afe:	7b 01                	jnp    0x7b01
    7b00:	00 00                	add    BYTE PTR [bx+si],al
    7b02:	00 02                	add    BYTE PTR [bp+si],al
    7b04:	00 00                	add    BYTE PTR [bx+si],al
    7b06:	00 08                	add    BYTE PTR [bx+si],cl
    7b08:	51                   	push   cx
    7b09:	74 65                	je     0x7b70
    7b0b:	53                   	push   bx
    7b0c:	74 6f                	je     0x7b7d
    7b0e:	63 6b 0b             	arpl   WORD PTR [bp+di+0xb],bp
    7b11:	56                   	push   si
    7b12:	61                   	popa
    7b13:	6c                   	ins    BYTE PTR es:[di],dx
    7b14:	65 75 72             	gs jne 0x7b89
    7b17:	53                   	push   bx
    7b18:	74 6f                	je     0x7b89
    7b1a:	63 6b 15             	arpl   WORD PTR [bp+di+0x15],bp
    7b1d:	54                   	push   sp
    7b1e:	65 6d                	gs ins WORD PTR es:[di],dx
    7b20:	70 73                	jo     0x7b95
    7b22:	46                   	inc    si
    7b23:	61                   	popa
    7b24:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    7b27:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    7b2a:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    7b2f:	74 75                	je     0x7ba6
    7b31:	72 00                	jb     0x7b33
    7b33:	00 ef                	add    bh,ch
    7b35:	8b 4e 7b             	mov    cx,WORD PTR [bp+0x7b]
    7b38:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    7b3b:	6e                   	outs   dx,BYTE PTR ds:[si]
    7b3c:	6e                   	outs   dx,BYTE PTR ds:[si]
    7b3d:	65 73 50             	gs jae 0x7b90
    7b40:	63 08                	arpl   WORD PTR [bx+si],cx
    7b42:	47                   	inc    di
    7b43:	72 65                	jb     0x7baa
    7b45:	76 65                	jbe    0x7bac
    7b47:	73 50                	jae    0x7b99
    7b49:	63 00                	arpl   WORD PTR [bx+si],ax
    7b4b:	00 a5 8c a7          	add    BYTE PTR [di-0x5874],ah
    7b4f:	7b 01                	jnp    0x7b52
    7b51:	00 00                	add    BYTE PTR [bx+si],al
    7b53:	00 02                	add    BYTE PTR [bp+si],al
    7b55:	00 00                	add    BYTE PTR [bx+si],al
    7b57:	00 06 56 65          	add    BYTE PTR ds:0x6556,al
    7b5b:	6e                   	outs   dx,BYTE PTR ds:[si]
    7b5c:	74 65                	je     0x7bc3
    7b5e:	73 10                	jae    0x7b70
    7b60:	56                   	push   si
    7b61:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7b63:	74 65                	je     0x7bca
    7b65:	73 53                	jae    0x7bba
    7b67:	6f                   	outs   dx,WORD PTR ds:[si]
    7b68:	6c                   	ins    BYTE PTR es:[di],dx
    7b69:	64 65 65 73 51       	fs gs gs jae 0x7bbf
    7b6e:	74 65                	je     0x7bd5
    7b70:	0c 56                	or     al,0x56
    7b72:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7b74:	74 65                	je     0x7bdb
    7b76:	73 53                	jae    0x7bcb
    7b78:	70 65                	jo     0x7bdf
    7b7a:	51                   	push   cx
    7b7b:	74 65                	je     0x7be2
    7b7d:	08 51 74             	or     BYTE PTR [bx+di+0x74],dl
    7b80:	65 53                	gs push bx
    7b82:	74 6f                	je     0x7bf3
    7b84:	63 6b 10             	arpl   WORD PTR [bp+di+0x10],bp
    7b87:	50                   	push   ax
    7b88:	72 6f                	jb     0x7bf9
    7b8a:	64 75 63             	fs jne 0x7bf0
    7b8d:	74 69                	je     0x7bf8
    7b8f:	6f                   	outs   dx,WORD PTR ds:[si]
    7b90:	6e                   	outs   dx,BYTE PTR ds:[si]
    7b91:	52                   	push   dx
    7b92:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    7b95:	6c                   	ins    BYTE PTR es:[di],dx
    7b96:	65 0b 48 65          	or     cx,WORD PTR gs:[bx+si+0x65]
    7b9a:	75 72                	jne    0x7c0e
    7b9c:	65 73 53             	gs jae 0x7bf2
    7b9f:	75 70                	jne    0x7c11
    7ba1:	50                   	push   ax
    7ba2:	63 00                	arpl   WORD PTR [bx+si],ax
    7ba4:	00 98 8e 64          	add    BYTE PTR [bx+si+0x648e],bl
    7ba8:	7d 01                	jge    0x7bab
    7baa:	00 00                	add    BYTE PTR [bx+si],al
    7bac:	00 02                	add    BYTE PTR [bp+si],al
	...
    7bb6:	00 c8                	add    al,cl
    7bb8:	42                   	inc    dx
    7bb9:	00 00                	add    BYTE PTR [bx+si],al
    7bbb:	80 3f 00             	cmp    BYTE PTR [bx],0x0
    7bbe:	00 a0 41 00          	add    BYTE PTR [bx+si+0x41],ah
    7bc2:	00 20                	add    BYTE PTR [bx+si],ah
    7bc4:	41                   	inc    cx
    7bc5:	00 00                	add    BYTE PTR [bx+si],al
    7bc7:	a0 40 00             	mov    al,ds:0x40
    7bca:	00 be 42 00          	add    BYTE PTR [bp+0x42],bh
    7bce:	00 b4 43 00          	add    BYTE PTR [si+0x43],dh
    7bd2:	00 70 42             	add    BYTE PTR [bx+si+0x42],dh
    7bd5:	0d 43 61             	or     ax,0x6143
    7bd8:	70 69                	jo     0x7c43
    7bda:	74 61                	je     0x7c3d
    7bdc:	6c                   	ins    BYTE PTR es:[di],dx
    7bdd:	53                   	push   bx
    7bde:	6f                   	outs   dx,WORD PTR ds:[si]
    7bdf:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    7be2:	6c                   	ins    BYTE PTR es:[di],dx
    7be3:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
    7be6:	73 65                	jae    0x7c4d
    7be8:	72 76                	jb     0x7c60
    7bea:	65 73 0b             	gs jae 0x7bf8
    7bed:	52                   	push   dx
    7bee:	65 73 75             	gs jae 0x7c66
    7bf1:	6c                   	ins    BYTE PTR es:[di],dx
    7bf2:	74 61                	je     0x7c55
    7bf4:	74 4e                	je     0x7c44
    7bf6:	65 74 0e             	gs je  0x7c07
    7bf9:	53                   	push   bx
    7bfa:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
    7bff:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
    7c04:	74 74                	je     0x7c7a
    7c06:	65 03 43 41          	add    ax,WORD PTR gs:[bp+di+0x41]
    7c0a:	46                   	inc    si
    7c0b:	05 49 6d             	add    ax,0x6d49
    7c0e:	70 6f                	jo     0x7c7f
    7c10:	74 03                	je     0x7c15
    7c12:	49                   	dec    cx
    7c13:	46                   	inc    si
    7c14:	41                   	inc    cx
    7c15:	0c 54                	or     al,0x54
    7c17:	56                   	push   si
    7c18:	41                   	inc    cx
    7c19:	43                   	inc    bx
    7c1a:	6f                   	outs   dx,WORD PTR ds:[si]
    7c1b:	6c                   	ins    BYTE PTR es:[di],dx
    7c1c:	6c                   	ins    BYTE PTR es:[di],dx
    7c1d:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
    7c21:	65 0d 54 56          	gs or  ax,0x5654
    7c25:	41                   	inc    cx
    7c26:	44                   	inc    sp
    7c27:	65 64 75 63          	gs fs jne 0x7c8e
    7c2b:	74 69                	je     0x7c96
    7c2d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    7c30:	07                   	pop    es
    7c31:	43                   	inc    bx
    7c32:	6c                   	ins    BYTE PTR es:[di],dx
    7c33:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    7c38:	0c 46                	or     al,0x46
    7c3a:	6f                   	outs   dx,WORD PTR ds:[si]
    7c3b:	75 72                	jne    0x7caf
    7c3d:	6e                   	outs   dx,BYTE PTR ds:[si]
    7c3e:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    7c43:	72 73                	jb     0x7cb8
    7c45:	0a 54 72             	or     dl,BYTE PTR [si+0x72]
    7c48:	65 73 6f             	gs jae 0x7cba
    7c4b:	72 65                	jb     0x7cb2
    7c4d:	72 69                	jb     0x7cb8
    7c4f:	65 07                	gs pop es
    7c51:	45                   	inc    bp
    7c52:	6d                   	ins    WORD PTR es:[di],dx
    7c53:	70 72                	jo     0x7cc7
    7c55:	75 6e                	jne    0x7cc5
    7c57:	74 0d                	je     0x7c66
    7c59:	44                   	inc    sp
    7c5a:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    7c5e:	76 65                	jbe    0x7cc5
    7c60:	72 74                	jb     0x7cd6
    7c62:	41                   	inc    cx
    7c63:	75 74                	jne    0x7cd9
    7c65:	6f                   	outs   dx,WORD PTR ds:[si]
    7c66:	0e                   	push   cs
    7c67:	44                   	inc    sp
    7c68:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    7c6c:	76 65                	jbe    0x7cd3
    7c6e:	72 74                	jb     0x7ce4
    7c70:	4e                   	dec    si
    7c71:	41                   	inc    cx
    7c72:	75 74                	jne    0x7ce8
    7c74:	6f                   	outs   dx,WORD PTR ds:[si]
    7c75:	0d 41 6d             	or     ax,0x6d41
    7c78:	6f                   	outs   dx,WORD PTR ds:[si]
    7c79:	72 74                	jb     0x7cef
    7c7b:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    7c80:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7c82:	74 08                	je     0x7c8c
    7c84:	43                   	inc    bx
    7c85:	65 73 73             	gs jae 0x7cfb
    7c88:	69 6f 6e 73 15       	imul   bp,WORD PTR [bx+0x6e],0x1573
    7c8d:	49                   	dec    cx
    7c8e:	6d                   	ins    WORD PTR es:[di],dx
    7c8f:	6d                   	ins    WORD PTR es:[di],dx
    7c90:	6f                   	outs   dx,WORD PTR ds:[si]
    7c91:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
    7c94:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    7c99:	6f                   	outs   dx,WORD PTR ds:[si]
    7c9a:	6e                   	outs   dx,BYTE PTR ds:[si]
    7c9b:	73 42                	jae    0x7cdf
    7c9d:	72 75                	jb     0x7d14
    7c9f:	74 65                	je     0x7d06
    7ca1:	73 14                	jae    0x7cb7
    7ca3:	43                   	inc    bx
    7ca4:	6f                   	outs   dx,WORD PTR ds:[si]
    7ca5:	75 74                	jne    0x7d1b
    7ca7:	73 46                	jae    0x7cef
    7ca9:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
    7cae:	72 6f                	jb     0x7d1f
    7cb0:	64 75 63             	fs jne 0x7d16
    7cb3:	74 69                	je     0x7d1e
    7cb5:	6f                   	outs   dx,WORD PTR ds:[si]
    7cb6:	6e                   	outs   dx,BYTE PTR ds:[si]
    7cb7:	0f                   	movmskps esi,(bad)
    7cb8:	50                   	push   ax
    7cb9:	72 69                	jb     0x7d24
    7cbb:	6d                   	ins    WORD PTR es:[di],dx
    7cbc:	65 73 41             	gs jae 0x7d00
    7cbf:	73 73                	jae    0x7d34
    7cc1:	75 72                	jne    0x7d35
    7cc3:	61                   	popa
    7cc4:	6e                   	outs   dx,BYTE PTR ds:[si]
    7cc5:	63 65 0d             	arpl   WORD PTR [di+0xd],sp
    7cc8:	52                   	push   dx
    7cc9:	65 6d                	gs ins WORD PTR es:[di],dx
    7ccb:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    7cce:	72 73                	jb     0x7d43
    7cd0:	41                   	inc    cx
    7cd1:	73 73                	jae    0x7d46
    7cd3:	75 72                	jne    0x7d47
    7cd5:	08 4d 61             	or     BYTE PTR [di+0x61],cl
    7cd8:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    7cdb:	6e                   	outs   dx,BYTE PTR ds:[si]
    7cdc:	65 73 08             	gs jae 0x7ce7
    7cdf:	56                   	push   si
    7ce0:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7ce2:	64 65 75 72          	fs gs jne 0x7d58
    7ce6:	73 0a                	jae    0x7cf2
    7ce8:	50                   	push   ax
    7ce9:	72 6f                	jb     0x7d5a
    7ceb:	64 75 63             	fs jne 0x7d51
    7cee:	74 69                	je     0x7d59
    7cf0:	66 73 06             	data32 jae 0x7cf9
    7cf3:	43                   	inc    bx
    7cf4:	61                   	popa
    7cf5:	64 72 65             	fs jb  0x7d5d
    7cf8:	73 12                	jae    0x7d0c
    7cfa:	52                   	push   dx
    7cfb:	65 6d                	gs ins WORD PTR es:[di],dx
    7cfd:	75 6e                	jne    0x7d6d
    7cff:	65 72 61             	gs jb  0x7d63
    7d02:	74 69                	je     0x7d6d
    7d04:	6f                   	outs   dx,WORD PTR ds:[si]
    7d05:	6e                   	outs   dx,BYTE PTR ds:[si]
    7d06:	43                   	inc    bx
    7d07:	61                   	popa
    7d08:	64 72 65             	fs jb  0x7d70
    7d0b:	73 0c                	jae    0x7d19
    7d0d:	43                   	inc    bx
    7d0e:	6f                   	outs   dx,WORD PTR ds:[si]
    7d0f:	75 74                	jne    0x7d85
    7d11:	45                   	inc    bp
    7d12:	6d                   	ins    WORD PTR es:[di],dx
    7d13:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    7d16:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    7d19:	0c 43                	or     al,0x43
    7d1b:	6f                   	outs   dx,WORD PTR ds:[si]
    7d1c:	75 74                	jne    0x7d92
    7d1e:	4c                   	dec    sp
    7d1f:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    7d24:	69 65 0d 43 6f       	imul   sp,WORD PTR [di+0xd],0x6f43
    7d29:	75 74                	jne    0x7d9f
    7d2b:	46                   	inc    si
    7d2c:	6f                   	outs   dx,WORD PTR ds:[si]
    7d2d:	72 6d                	jb     0x7d9c
    7d2f:	61                   	popa
    7d30:	74 69                	je     0x7d9b
    7d32:	6f                   	outs   dx,WORD PTR ds:[si]
    7d33:	6e                   	outs   dx,BYTE PTR ds:[si]
    7d34:	0d 44 69             	or     ax,0x6944
    7d37:	73 74                	jae    0x7dad
    7d39:	72 69                	jb     0x7da4
    7d3b:	62 75 74             	bound  si,DWORD PTR [di+0x74]
    7d3e:	69 6f 6e 73 0b       	imul   bp,WORD PTR [bx+0x6e],0xb73
    7d43:	52                   	push   dx
    7d44:	65 70 61             	gs jo  0x7da8
    7d47:	72 61                	jb     0x7daa
    7d49:	74 69                	je     0x7db4
    7d4b:	6f                   	outs   dx,WORD PTR ds:[si]
    7d4c:	6e                   	outs   dx,BYTE PTR ds:[si]
    7d4d:	73 11                	jae    0x7d60
    7d4f:	45                   	inc    bp
    7d50:	6e                   	outs   dx,BYTE PTR ds:[si]
    7d51:	74 72                	je     0x7dc5
    7d53:	65 74 69             	gs je  0x7dbf
    7d56:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7d58:	4d                   	dec    bp
    7d59:	61                   	popa
    7d5a:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    7d5d:	6e                   	outs   dx,BYTE PTR ds:[si]
    7d5e:	65 73 00             	gs jae 0x7d61
    7d61:	00 3f                	add    BYTE PTR [bx],bh
    7d63:	a8 da                	test   al,0xda
    7d65:	7d 0b                	jge    0x7d72
    7d67:	56                   	push   si
    7d68:	61                   	popa
    7d69:	6c                   	ins    BYTE PTR es:[di],dx
    7d6a:	65 75 72             	gs jne 0x7ddf
    7d6d:	53                   	push   bx
    7d6e:	74 6f                	je     0x7ddf
    7d70:	63 6b 01             	arpl   WORD PTR [bp+di+0x1],bp
    7d73:	00 00                	add    BYTE PTR [bx+si],al
    7d75:	00 02                	add    BYTE PTR [bp+si],al
    7d77:	00 00                	add    BYTE PTR [bx+si],al
    7d79:	00 10                	add    BYTE PTR [bx+si],dl
    7d7b:	44                   	inc    sp
    7d7c:	6f                   	outs   dx,WORD PTR ds:[si]
    7d7d:	74 41                	je     0x7dc0
    7d7f:	6d                   	ins    WORD PTR es:[di],dx
    7d80:	6f                   	outs   dx,WORD PTR ds:[si]
    7d81:	72 74                	jb     0x7df7
    7d83:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    7d88:	65 6e                	outs   dx,BYTE PTR gs:[si]
    7d8a:	74 15                	je     0x7da1
    7d8c:	54                   	push   sp
    7d8d:	65 6d                	gs ins WORD PTR es:[di],dx
    7d8f:	70 73                	jo     0x7e04
    7d91:	46                   	inc    si
    7d92:	61                   	popa
    7d93:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    7d96:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    7d99:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    7d9e:	74 75                	je     0x7e15
    7da0:	72 11                	jb     0x7db3
    7da2:	4d                   	dec    bp
    7da3:	61                   	popa
    7da4:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    7da9:	76 72                	jbe    0x7e1d
    7dab:	65 44                	gs inc sp
    7dad:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    7db2:	65 13 43 6f          	adc    ax,WORD PTR gs:[bp+di+0x6f]
    7db6:	6e                   	outs   dx,BYTE PTR ds:[si]
    7db7:	73 6f                	jae    0x7e28
    7db9:	6d                   	ins    WORD PTR es:[di],dx
    7dba:	6d                   	ins    WORD PTR es:[di],dx
    7dbb:	61                   	popa
    7dbc:	74 69                	je     0x7e27
    7dbe:	6f                   	outs   dx,WORD PTR ds:[si]
    7dbf:	6e                   	outs   dx,BYTE PTR ds:[si]
    7dc0:	4d                   	dec    bp
    7dc1:	61                   	popa
    7dc2:	74 69                	je     0x7e2d
    7dc4:	65 72 65             	gs jb  0x7e2c
    7dc7:	0e                   	push   cs
    7dc8:	52                   	push   dx
    7dc9:	65 6d                	gs ins WORD PTR es:[di],dx
    7dcb:	75 6e                	jne    0x7e3b
    7dcd:	65 72 61             	gs jb  0x7e31
    7dd0:	74 69                	je     0x7e3b
    7dd2:	6f                   	outs   dx,WORD PTR ds:[si]
    7dd3:	6e                   	outs   dx,BYTE PTR ds:[si]
    7dd4:	46                   	inc    si
    7dd5:	56                   	push   si
    7dd6:	00 00                	add    BYTE PTR [bx+si],al
    7dd8:	65 aa                	gs stos BYTE PTR es:[di],al
    7dda:	4c                   	dec    sp
    7ddb:	7e 55                	jle    0x7e32
    7ddd:	89 e5                	mov    bp,sp
    7ddf:	b8 a6 04             	mov    ax,0x4a6
    7de2:	9a 44 04 08 7e       	call   0x7e08:0x444
    7de7:	81 ec a6 04          	sub    sp,0x4a6
    7deb:	68 6c 40             	push   0x406c
    7dee:	68 51 48             	push   0x4851
    7df1:	68 85 eb             	push   0xeb85
    7df4:	68 b8 1e             	push   0x1eb8
    7df7:	6a 09                	push   0x9
    7df9:	9a 69 0a ff ff       	call   0xffff:0xa69
    7dfe:	b9 04 00             	mov    cx,0x4
    7e01:	f7 e9                	imul   cx
    7e03:	71 05                	jno    0x7e0a
    7e05:	9a 3e 04 d3 82       	call   0x82d3:0x43e
    7e0a:	89 86 82 fb          	mov    WORD PTR [bp-0x47e],ax
    7e0e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7e11:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7e14:	8d be 3e fc          	lea    di,[bp-0x3c2]
    7e18:	16                   	push   ss
    7e19:	57                   	push   di
    7e1a:	8d be 36 fc          	lea    di,[bp-0x3ca]
    7e1e:	16                   	push   ss
    7e1f:	57                   	push   di
    7e20:	8d be 2e fc          	lea    di,[bp-0x3d2]
    7e24:	16                   	push   ss
    7e25:	57                   	push   di
    7e26:	8d be 3e fd          	lea    di,[bp-0x2c2]
    7e2a:	16                   	push   ss
    7e2b:	57                   	push   di
    7e2c:	8d be 36 fd          	lea    di,[bp-0x2ca]
    7e30:	16                   	push   ss
    7e31:	57                   	push   di
    7e32:	8d be 2e fd          	lea    di,[bp-0x2d2]
    7e36:	16                   	push   ss
    7e37:	57                   	push   di
    7e38:	8d be d6 fb          	lea    di,[bp-0x42a]
    7e3c:	16                   	push   ss
    7e3d:	57                   	push   di
    7e3e:	8d be ce fb          	lea    di,[bp-0x432]
    7e42:	16                   	push   ss
    7e43:	57                   	push   di
    7e44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e47:	06                   	push   es
    7e48:	57                   	push   di
    7e49:	9a ff 66 cc 7e       	call   0x7ecc:0x66ff
    7e4e:	9b dd 86 36 fc       	fld    QWORD PTR [bp-0x3ca]
    7e53:	9b dd 9e 8e fc       	fstp   QWORD PTR [bp-0x372]
    7e58:	90                   	nop
    7e59:	9b 9b dd 86 2e fc    	fld    QWORD PTR [bp-0x3d2]
    7e5f:	9b dd 9e 96 fc       	fstp   QWORD PTR [bp-0x36a]
    7e64:	90                   	nop
    7e65:	9b 9b dd 86 d6 fb    	fld    QWORD PTR [bp-0x42a]
    7e6b:	9b dd 9e 4e fc       	fstp   QWORD PTR [bp-0x3b2]
    7e70:	90                   	nop
    7e71:	9b 9b dd 86 ce fb    	fld    QWORD PTR [bp-0x432]
    7e77:	9b dd 9e 56 fc       	fstp   QWORD PTR [bp-0x3aa]
    7e7c:	90                   	nop
    7e7d:	9b                   	fwait
    7e7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e81:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    7e86:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    7e8a:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    7e8e:	b8 82 77             	mov    ax,0x7782
    7e91:	0e                   	push   cs
    7e92:	50                   	push   ax
    7e93:	55                   	push   bp
    7e94:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7e98:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7e9c:	c7 86 76 fb 01 00    	mov    WORD PTR [bp-0x48a],0x1
    7ea2:	c7 86 78 fb 00 00    	mov    WORD PTR [bp-0x488],0x0
    7ea8:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    7ead:	8d be 76 fb          	lea    di,[bp-0x48a]
    7eb1:	16                   	push   ss
    7eb2:	57                   	push   di
    7eb3:	6a 00                	push   0x0
    7eb5:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    7eb9:	06                   	push   es
    7eba:	57                   	push   di
    7ebb:	9a 95 28 3e 7f       	call   0x7f3e:0x2895
    7ec0:	08 c0                	or     al,al
    7ec2:	75 0a                	jne    0x7ece
    7ec4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ec7:	06                   	push   es
    7ec8:	57                   	push   di
    7ec9:	9a 03 03 4c 7f       	call   0x7f4c:0x303
    7ece:	bf 76 77             	mov    di,0x7776
    7ed1:	0e                   	push   cs
    7ed2:	57                   	push   di
    7ed3:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    7ed7:	06                   	push   es
    7ed8:	57                   	push   di
    7ed9:	9a 9b 3b 5c 7f       	call   0x7f5c:0x3b9b
    7ede:	89 c7                	mov    di,ax
    7ee0:	8e c2                	mov    es,dx
    7ee2:	06                   	push   es
    7ee3:	57                   	push   di
    7ee4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7ee7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7eeb:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    7eef:	90                   	nop
    7ef0:	9b                   	fwait
    7ef1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7ef5:	83 c4 06             	add    sp,0x6
    7ef8:	b8 fe 7e             	mov    ax,0x7efe
    7efb:	0e                   	push   cs
    7efc:	50                   	push   ax
    7efd:	cb                   	retf
    7efe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f01:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    7f06:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    7f0a:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    7f0e:	b8 c9 78             	mov    ax,0x78c9
    7f11:	0e                   	push   cs
    7f12:	50                   	push   ax
    7f13:	55                   	push   bp
    7f14:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7f18:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7f1c:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    7f1f:	99                   	cwd
    7f20:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    7f24:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    7f28:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    7f2d:	8d be 76 fb          	lea    di,[bp-0x48a]
    7f31:	16                   	push   ss
    7f32:	57                   	push   di
    7f33:	6a 00                	push   0x0
    7f35:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    7f39:	06                   	push   es
    7f3a:	57                   	push   di
    7f3b:	9a 95 28 9b 82       	call   0x829b:0x2895
    7f40:	08 c0                	or     al,al
    7f42:	75 0a                	jne    0x7f4e
    7f44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f47:	06                   	push   es
    7f48:	57                   	push   di
    7f49:	9a 03 03 a9 82       	call   0x82a9:0x303
    7f4e:	bf 88 77             	mov    di,0x7788
    7f51:	0e                   	push   cs
    7f52:	57                   	push   di
    7f53:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    7f57:	06                   	push   es
    7f58:	57                   	push   di
    7f59:	9a 9b 3b 7f 7f       	call   0x7f7f:0x3b9b
    7f5e:	89 c7                	mov    di,ax
    7f60:	8e c2                	mov    es,dx
    7f62:	06                   	push   es
    7f63:	57                   	push   di
    7f64:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7f67:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7f6b:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    7f6f:	90                   	nop
    7f70:	9b                   	fwait
    7f71:	bf 94 77             	mov    di,0x7794
    7f74:	0e                   	push   cs
    7f75:	57                   	push   di
    7f76:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    7f7a:	06                   	push   es
    7f7b:	57                   	push   di
    7f7c:	9a 9b 3b a2 7f       	call   0x7fa2:0x3b9b
    7f81:	89 c7                	mov    di,ax
    7f83:	8e c2                	mov    es,dx
    7f85:	06                   	push   es
    7f86:	57                   	push   di
    7f87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7f8a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7f8e:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    7f92:	90                   	nop
    7f93:	9b                   	fwait
    7f94:	bf a6 77             	mov    di,0x77a6
    7f97:	0e                   	push   cs
    7f98:	57                   	push   di
    7f99:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    7f9d:	06                   	push   es
    7f9e:	57                   	push   di
    7f9f:	9a 9b 3b c5 7f       	call   0x7fc5:0x3b9b
    7fa4:	89 c7                	mov    di,ax
    7fa6:	8e c2                	mov    es,dx
    7fa8:	06                   	push   es
    7fa9:	57                   	push   di
    7faa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7fad:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7fb1:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    7fb5:	90                   	nop
    7fb6:	9b                   	fwait
    7fb7:	bf b9 77             	mov    di,0x77b9
    7fba:	0e                   	push   cs
    7fbb:	57                   	push   di
    7fbc:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    7fc0:	06                   	push   es
    7fc1:	57                   	push   di
    7fc2:	9a 9b 3b e8 7f       	call   0x7fe8:0x3b9b
    7fc7:	89 c7                	mov    di,ax
    7fc9:	8e c2                	mov    es,dx
    7fcb:	06                   	push   es
    7fcc:	57                   	push   di
    7fcd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7fd0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7fd4:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    7fd8:	90                   	nop
    7fd9:	9b                   	fwait
    7fda:	bf c7 77             	mov    di,0x77c7
    7fdd:	0e                   	push   cs
    7fde:	57                   	push   di
    7fdf:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    7fe3:	06                   	push   es
    7fe4:	57                   	push   di
    7fe5:	9a 9b 3b 0b 80       	call   0x800b:0x3b9b
    7fea:	89 c7                	mov    di,ax
    7fec:	8e c2                	mov    es,dx
    7fee:	06                   	push   es
    7fef:	57                   	push   di
    7ff0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7ff3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    7ff7:	9b dd 5e d0          	fstp   QWORD PTR [bp-0x30]
    7ffb:	90                   	nop
    7ffc:	9b                   	fwait
    7ffd:	bf ce 77             	mov    di,0x77ce
    8000:	0e                   	push   cs
    8001:	57                   	push   di
    8002:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8006:	06                   	push   es
    8007:	57                   	push   di
    8008:	9a 9b 3b 2e 80       	call   0x802e:0x3b9b
    800d:	89 c7                	mov    di,ax
    800f:	8e c2                	mov    es,dx
    8011:	06                   	push   es
    8012:	57                   	push   di
    8013:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8016:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    801a:	9b dd 5e c8          	fstp   QWORD PTR [bp-0x38]
    801e:	90                   	nop
    801f:	9b                   	fwait
    8020:	bf d6 77             	mov    di,0x77d6
    8023:	0e                   	push   cs
    8024:	57                   	push   di
    8025:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8029:	06                   	push   es
    802a:	57                   	push   di
    802b:	9a 9b 3b 51 80       	call   0x8051:0x3b9b
    8030:	89 c7                	mov    di,ax
    8032:	8e c2                	mov    es,dx
    8034:	06                   	push   es
    8035:	57                   	push   di
    8036:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8039:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    803d:	9b dd 5e c0          	fstp   QWORD PTR [bp-0x40]
    8041:	90                   	nop
    8042:	9b                   	fwait
    8043:	bf e9 77             	mov    di,0x77e9
    8046:	0e                   	push   cs
    8047:	57                   	push   di
    8048:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    804c:	06                   	push   es
    804d:	57                   	push   di
    804e:	9a 9b 3b 74 80       	call   0x8074:0x3b9b
    8053:	89 c7                	mov    di,ax
    8055:	8e c2                	mov    es,dx
    8057:	06                   	push   es
    8058:	57                   	push   di
    8059:	26 c4 3d             	les    di,DWORD PTR es:[di]
    805c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8060:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    8064:	90                   	nop
    8065:	9b                   	fwait
    8066:	bf fa 77             	mov    di,0x77fa
    8069:	0e                   	push   cs
    806a:	57                   	push   di
    806b:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    806f:	06                   	push   es
    8070:	57                   	push   di
    8071:	9a 9b 3b 97 80       	call   0x8097:0x3b9b
    8076:	89 c7                	mov    di,ax
    8078:	8e c2                	mov    es,dx
    807a:	06                   	push   es
    807b:	57                   	push   di
    807c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    807f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8083:	9b dd 5e b0          	fstp   QWORD PTR [bp-0x50]
    8087:	90                   	nop
    8088:	9b                   	fwait
    8089:	bf 09 78             	mov    di,0x7809
    808c:	0e                   	push   cs
    808d:	57                   	push   di
    808e:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8092:	06                   	push   es
    8093:	57                   	push   di
    8094:	9a 9b 3b ba 80       	call   0x80ba:0x3b9b
    8099:	89 c7                	mov    di,ax
    809b:	8e c2                	mov    es,dx
    809d:	06                   	push   es
    809e:	57                   	push   di
    809f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    80a2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    80a6:	9b dd 5e a8          	fstp   QWORD PTR [bp-0x58]
    80aa:	90                   	nop
    80ab:	9b                   	fwait
    80ac:	bf 18 78             	mov    di,0x7818
    80af:	0e                   	push   cs
    80b0:	57                   	push   di
    80b1:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    80b5:	06                   	push   es
    80b6:	57                   	push   di
    80b7:	9a 9b 3b dd 80       	call   0x80dd:0x3b9b
    80bc:	89 c7                	mov    di,ax
    80be:	8e c2                	mov    es,dx
    80c0:	06                   	push   es
    80c1:	57                   	push   di
    80c2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    80c5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    80c9:	9b dd 5e a0          	fstp   QWORD PTR [bp-0x60]
    80cd:	90                   	nop
    80ce:	9b                   	fwait
    80cf:	bf 29 78             	mov    di,0x7829
    80d2:	0e                   	push   cs
    80d3:	57                   	push   di
    80d4:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    80d8:	06                   	push   es
    80d9:	57                   	push   di
    80da:	9a 9b 3b 00 81       	call   0x8100:0x3b9b
    80df:	89 c7                	mov    di,ax
    80e1:	8e c2                	mov    es,dx
    80e3:	06                   	push   es
    80e4:	57                   	push   di
    80e5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    80e8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    80ec:	9b dd 5e 98          	fstp   QWORD PTR [bp-0x68]
    80f0:	90                   	nop
    80f1:	9b                   	fwait
    80f2:	bf 3c 78             	mov    di,0x783c
    80f5:	0e                   	push   cs
    80f6:	57                   	push   di
    80f7:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    80fb:	06                   	push   es
    80fc:	57                   	push   di
    80fd:	9a 9b 3b 23 81       	call   0x8123:0x3b9b
    8102:	89 c7                	mov    di,ax
    8104:	8e c2                	mov    es,dx
    8106:	06                   	push   es
    8107:	57                   	push   di
    8108:	26 c4 3d             	les    di,DWORD PTR es:[di]
    810b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    810f:	9b dd 5e 90          	fstp   QWORD PTR [bp-0x70]
    8113:	90                   	nop
    8114:	9b                   	fwait
    8115:	bf 45 78             	mov    di,0x7845
    8118:	0e                   	push   cs
    8119:	57                   	push   di
    811a:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    811e:	06                   	push   es
    811f:	57                   	push   di
    8120:	9a 9b 3b 46 81       	call   0x8146:0x3b9b
    8125:	89 c7                	mov    di,ax
    8127:	8e c2                	mov    es,dx
    8129:	06                   	push   es
    812a:	57                   	push   di
    812b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    812e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8132:	9b dd 5e 88          	fstp   QWORD PTR [bp-0x78]
    8136:	90                   	nop
    8137:	9b                   	fwait
    8138:	bf 53 78             	mov    di,0x7853
    813b:	0e                   	push   cs
    813c:	57                   	push   di
    813d:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8141:	06                   	push   es
    8142:	57                   	push   di
    8143:	9a 9b 3b 69 81       	call   0x8169:0x3b9b
    8148:	89 c7                	mov    di,ax
    814a:	8e c2                	mov    es,dx
    814c:	06                   	push   es
    814d:	57                   	push   di
    814e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8151:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8155:	9b dd 5e 80          	fstp   QWORD PTR [bp-0x80]
    8159:	90                   	nop
    815a:	9b                   	fwait
    815b:	bf 65 78             	mov    di,0x7865
    815e:	0e                   	push   cs
    815f:	57                   	push   di
    8160:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8164:	06                   	push   es
    8165:	57                   	push   di
    8166:	9a 9b 3b 8d 81       	call   0x818d:0x3b9b
    816b:	89 c7                	mov    di,ax
    816d:	8e c2                	mov    es,dx
    816f:	06                   	push   es
    8170:	57                   	push   di
    8171:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8174:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8178:	9b dd 9e 78 ff       	fstp   QWORD PTR [bp-0x88]
    817d:	90                   	nop
    817e:	9b                   	fwait
    817f:	bf 71 78             	mov    di,0x7871
    8182:	0e                   	push   cs
    8183:	57                   	push   di
    8184:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8188:	06                   	push   es
    8189:	57                   	push   di
    818a:	9a 9b 3b b1 81       	call   0x81b1:0x3b9b
    818f:	89 c7                	mov    di,ax
    8191:	8e c2                	mov    es,dx
    8193:	06                   	push   es
    8194:	57                   	push   di
    8195:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8198:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    819c:	9b dd 9e 70 ff       	fstp   QWORD PTR [bp-0x90]
    81a1:	90                   	nop
    81a2:	9b                   	fwait
    81a3:	bf 84 78             	mov    di,0x7884
    81a6:	0e                   	push   cs
    81a7:	57                   	push   di
    81a8:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    81ac:	06                   	push   es
    81ad:	57                   	push   di
    81ae:	9a 9b 3b d5 81       	call   0x81d5:0x3b9b
    81b3:	89 c7                	mov    di,ax
    81b5:	8e c2                	mov    es,dx
    81b7:	06                   	push   es
    81b8:	57                   	push   di
    81b9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    81bc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    81c0:	9b dd 9e 68 ff       	fstp   QWORD PTR [bp-0x98]
    81c5:	90                   	nop
    81c6:	9b                   	fwait
    81c7:	bf 93 78             	mov    di,0x7893
    81ca:	0e                   	push   cs
    81cb:	57                   	push   di
    81cc:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    81d0:	06                   	push   es
    81d1:	57                   	push   di
    81d2:	9a 9b 3b f9 81       	call   0x81f9:0x3b9b
    81d7:	89 c7                	mov    di,ax
    81d9:	8e c2                	mov    es,dx
    81db:	06                   	push   es
    81dc:	57                   	push   di
    81dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    81e0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    81e4:	9b dd 9e 60 ff       	fstp   QWORD PTR [bp-0xa0]
    81e9:	90                   	nop
    81ea:	9b                   	fwait
    81eb:	bf a3 78             	mov    di,0x78a3
    81ee:	0e                   	push   cs
    81ef:	57                   	push   di
    81f0:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    81f4:	06                   	push   es
    81f5:	57                   	push   di
    81f6:	9a 9b 3b 1a 82       	call   0x821a:0x3b9b
    81fb:	89 c7                	mov    di,ax
    81fd:	8e c2                	mov    es,dx
    81ff:	06                   	push   es
    8200:	57                   	push   di
    8201:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8204:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    8208:	88 86 5f ff          	mov    BYTE PTR [bp-0xa1],al
    820c:	bf b5 78             	mov    di,0x78b5
    820f:	0e                   	push   cs
    8210:	57                   	push   di
    8211:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8215:	06                   	push   es
    8216:	57                   	push   di
    8217:	9a 9b 3b b9 82       	call   0x82b9:0x3b9b
    821c:	89 c7                	mov    di,ax
    821e:	8e c2                	mov    es,dx
    8220:	06                   	push   es
    8221:	57                   	push   di
    8222:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8225:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8229:	9b dd 9e 46 ff       	fstp   QWORD PTR [bp-0xba]
    822e:	90                   	nop
    822f:	9b                   	fwait
    8230:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8234:	83 c4 06             	add    sp,0x6
    8237:	b8 3d 82             	mov    ax,0x823d
    823a:	0e                   	push   cs
    823b:	50                   	push   ax
    823c:	cb                   	retf
    823d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8240:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    8245:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    8249:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    824d:	b8 ef 78             	mov    ax,0x78ef
    8250:	0e                   	push   cs
    8251:	50                   	push   ax
    8252:	55                   	push   bp
    8253:	ff 36 58 18          	push   WORD PTR ds:0x1858
    8257:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    825b:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    8261:	eb 04                	jmp    0x8267
    8263:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    8267:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    826a:	99                   	cwd
    826b:	89 86 6e fb          	mov    WORD PTR [bp-0x492],ax
    826f:	89 96 70 fb          	mov    WORD PTR [bp-0x490],dx
    8273:	c6 86 72 fb 00       	mov    BYTE PTR [bp-0x48e],0x0
    8278:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    827c:	99                   	cwd
    827d:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    8281:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    8285:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    828a:	8d be 6e fb          	lea    di,[bp-0x492]
    828e:	16                   	push   ss
    828f:	57                   	push   di
    8290:	6a 01                	push   0x1
    8292:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8296:	06                   	push   es
    8297:	57                   	push   di
    8298:	9a 95 28 7f 83       	call   0x837f:0x2895
    829d:	08 c0                	or     al,al
    829f:	75 0a                	jne    0x82ab
    82a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82a4:	06                   	push   es
    82a5:	57                   	push   di
    82a6:	9a 03 03 8d 83       	call   0x838d:0x303
    82ab:	bf d7 78             	mov    di,0x78d7
    82ae:	0e                   	push   cs
    82af:	57                   	push   di
    82b0:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    82b4:	06                   	push   es
    82b5:	57                   	push   di
    82b6:	9a 9b 3b ef 82       	call   0x82ef:0x3b9b
    82bb:	89 c7                	mov    di,ax
    82bd:	8e c2                	mov    es,dx
    82bf:	06                   	push   es
    82c0:	57                   	push   di
    82c1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    82c4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    82c8:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    82cc:	99                   	cwd
    82cd:	bf cf 78             	mov    di,0x78cf
    82d0:	9a 16 04 09 83       	call   0x8309:0x416
    82d5:	8b f8                	mov    di,ax
    82d7:	c1 e7 03             	shl    di,0x3
    82da:	9b dd 9b 1e ff       	fstp   QWORD PTR [bp+di-0xe2]
    82df:	90                   	nop
    82e0:	9b                   	fwait
    82e1:	bf e3 78             	mov    di,0x78e3
    82e4:	0e                   	push   cs
    82e5:	57                   	push   di
    82e6:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    82ea:	06                   	push   es
    82eb:	57                   	push   di
    82ec:	9a 9b 3b 9d 83       	call   0x839d:0x3b9b
    82f1:	89 c7                	mov    di,ax
    82f3:	8e c2                	mov    es,dx
    82f5:	06                   	push   es
    82f6:	57                   	push   di
    82f7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    82fa:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    82fe:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8302:	99                   	cwd
    8303:	bf cf 78             	mov    di,0x78cf
    8306:	9a 16 04 3f 86       	call   0x863f:0x416
    830b:	8b f8                	mov    di,ax
    830d:	c1 e7 03             	shl    di,0x3
    8310:	9b dd 9b 2e ff       	fstp   QWORD PTR [bp+di-0xd2]
    8315:	90                   	nop
    8316:	9b                   	fwait
    8317:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    831c:	74 03                	je     0x8321
    831e:	e9 42 ff             	jmp    0x8263
    8321:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8325:	83 c4 06             	add    sp,0x6
    8328:	b8 2e 83             	mov    ax,0x832e
    832b:	0e                   	push   cs
    832c:	50                   	push   ax
    832d:	cb                   	retf
    832e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8331:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    8336:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    833a:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    833e:	b8 c3 79             	mov    ax,0x79c3
    8341:	0e                   	push   cs
    8342:	50                   	push   ax
    8343:	55                   	push   bp
    8344:	ff 36 58 18          	push   WORD PTR ds:0x1858
    8348:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    834c:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    834f:	99                   	cwd
    8350:	89 86 6e fb          	mov    WORD PTR [bp-0x492],ax
    8354:	89 96 70 fb          	mov    WORD PTR [bp-0x490],dx
    8358:	c6 86 72 fb 00       	mov    BYTE PTR [bp-0x48e],0x0
    835d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8360:	99                   	cwd
    8361:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    8365:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    8369:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    836e:	8d be 6e fb          	lea    di,[bp-0x492]
    8372:	16                   	push   ss
    8373:	57                   	push   di
    8374:	6a 01                	push   0x1
    8376:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    837a:	06                   	push   es
    837b:	57                   	push   di
    837c:	9a 95 28 07 86       	call   0x8607:0x2895
    8381:	08 c0                	or     al,al
    8383:	75 0a                	jne    0x838f
    8385:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8388:	06                   	push   es
    8389:	57                   	push   di
    838a:	9a 03 03 15 86       	call   0x8615:0x303
    838f:	bf f5 78             	mov    di,0x78f5
    8392:	0e                   	push   cs
    8393:	57                   	push   di
    8394:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8398:	06                   	push   es
    8399:	57                   	push   di
    839a:	9a 9b 3b c1 83       	call   0x83c1:0x3b9b
    839f:	89 c7                	mov    di,ax
    83a1:	8e c2                	mov    es,dx
    83a3:	06                   	push   es
    83a4:	57                   	push   di
    83a5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    83a8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    83ac:	9b dd 9e 0e ff       	fstp   QWORD PTR [bp-0xf2]
    83b1:	90                   	nop
    83b2:	9b                   	fwait
    83b3:	bf 06 79             	mov    di,0x7906
    83b6:	0e                   	push   cs
    83b7:	57                   	push   di
    83b8:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    83bc:	06                   	push   es
    83bd:	57                   	push   di
    83be:	9a 9b 3b e5 83       	call   0x83e5:0x3b9b
    83c3:	89 c7                	mov    di,ax
    83c5:	8e c2                	mov    es,dx
    83c7:	06                   	push   es
    83c8:	57                   	push   di
    83c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    83cc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    83d0:	9b dd 9e 06 ff       	fstp   QWORD PTR [bp-0xfa]
    83d5:	90                   	nop
    83d6:	9b                   	fwait
    83d7:	bf 11 79             	mov    di,0x7911
    83da:	0e                   	push   cs
    83db:	57                   	push   di
    83dc:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    83e0:	06                   	push   es
    83e1:	57                   	push   di
    83e2:	9a 9b 3b 09 84       	call   0x8409:0x3b9b
    83e7:	89 c7                	mov    di,ax
    83e9:	8e c2                	mov    es,dx
    83eb:	06                   	push   es
    83ec:	57                   	push   di
    83ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    83f0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    83f4:	9b dd 9e fe fe       	fstp   QWORD PTR [bp-0x102]
    83f9:	90                   	nop
    83fa:	9b                   	fwait
    83fb:	bf 22 79             	mov    di,0x7922
    83fe:	0e                   	push   cs
    83ff:	57                   	push   di
    8400:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8404:	06                   	push   es
    8405:	57                   	push   di
    8406:	9a 9b 3b 2d 84       	call   0x842d:0x3b9b
    840b:	89 c7                	mov    di,ax
    840d:	8e c2                	mov    es,dx
    840f:	06                   	push   es
    8410:	57                   	push   di
    8411:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8414:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8418:	9b dd 9e f6 fe       	fstp   QWORD PTR [bp-0x10a]
    841d:	90                   	nop
    841e:	9b                   	fwait
    841f:	bf 2e 79             	mov    di,0x792e
    8422:	0e                   	push   cs
    8423:	57                   	push   di
    8424:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8428:	06                   	push   es
    8429:	57                   	push   di
    842a:	9a 9b 3b 51 84       	call   0x8451:0x3b9b
    842f:	89 c7                	mov    di,ax
    8431:	8e c2                	mov    es,dx
    8433:	06                   	push   es
    8434:	57                   	push   di
    8435:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8438:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    843c:	9b dd 9e ee fe       	fstp   QWORD PTR [bp-0x112]
    8441:	90                   	nop
    8442:	9b                   	fwait
    8443:	bf 42 79             	mov    di,0x7942
    8446:	0e                   	push   cs
    8447:	57                   	push   di
    8448:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    844c:	06                   	push   es
    844d:	57                   	push   di
    844e:	9a 9b 3b 76 84       	call   0x8476:0x3b9b
    8453:	89 c7                	mov    di,ax
    8455:	8e c2                	mov    es,dx
    8457:	06                   	push   es
    8458:	57                   	push   di
    8459:	26 c4 3d             	les    di,DWORD PTR es:[di]
    845c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8460:	89 86 22 ff          	mov    WORD PTR [bp-0xde],ax
    8464:	89 96 24 ff          	mov    WORD PTR [bp-0xdc],dx
    8468:	bf 50 79             	mov    di,0x7950
    846b:	0e                   	push   cs
    846c:	57                   	push   di
    846d:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8471:	06                   	push   es
    8472:	57                   	push   di
    8473:	9a 9b 3b 9b 84       	call   0x849b:0x3b9b
    8478:	89 c7                	mov    di,ax
    847a:	8e c2                	mov    es,dx
    847c:	06                   	push   es
    847d:	57                   	push   di
    847e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8481:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8485:	89 86 1e ff          	mov    WORD PTR [bp-0xe2],ax
    8489:	89 96 20 ff          	mov    WORD PTR [bp-0xe0],dx
    848d:	bf 5e 79             	mov    di,0x795e
    8490:	0e                   	push   cs
    8491:	57                   	push   di
    8492:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8496:	06                   	push   es
    8497:	57                   	push   di
    8498:	9a 9b 3b bf 84       	call   0x84bf:0x3b9b
    849d:	89 c7                	mov    di,ax
    849f:	8e c2                	mov    es,dx
    84a1:	06                   	push   es
    84a2:	57                   	push   di
    84a3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    84a6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    84aa:	9b dd 9e 16 ff       	fstp   QWORD PTR [bp-0xea]
    84af:	90                   	nop
    84b0:	9b                   	fwait
    84b1:	bf 72 79             	mov    di,0x7972
    84b4:	0e                   	push   cs
    84b5:	57                   	push   di
    84b6:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    84ba:	06                   	push   es
    84bb:	57                   	push   di
    84bc:	9a 9b 3b e4 84       	call   0x84e4:0x3b9b
    84c1:	89 c7                	mov    di,ax
    84c3:	8e c2                	mov    es,dx
    84c5:	06                   	push   es
    84c6:	57                   	push   di
    84c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    84ca:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    84ce:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    84d2:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    84d6:	bf 82 79             	mov    di,0x7982
    84d9:	0e                   	push   cs
    84da:	57                   	push   di
    84db:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    84df:	06                   	push   es
    84e0:	57                   	push   di
    84e1:	9a 9b 3b 09 85       	call   0x8509:0x3b9b
    84e6:	89 c7                	mov    di,ax
    84e8:	8e c2                	mov    es,dx
    84ea:	06                   	push   es
    84eb:	57                   	push   di
    84ec:	26 c4 3d             	les    di,DWORD PTR es:[di]
    84ef:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    84f3:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    84f7:	89 96 e8 fe          	mov    WORD PTR [bp-0x118],dx
    84fb:	bf 92 79             	mov    di,0x7992
    84fe:	0e                   	push   cs
    84ff:	57                   	push   di
    8500:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8504:	06                   	push   es
    8505:	57                   	push   di
    8506:	9a 9b 3b 2d 85       	call   0x852d:0x3b9b
    850b:	89 c7                	mov    di,ax
    850d:	8e c2                	mov    es,dx
    850f:	06                   	push   es
    8510:	57                   	push   di
    8511:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8514:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8518:	9b dd 9e de fe       	fstp   QWORD PTR [bp-0x122]
    851d:	90                   	nop
    851e:	9b                   	fwait
    851f:	bf a1 79             	mov    di,0x79a1
    8522:	0e                   	push   cs
    8523:	57                   	push   di
    8524:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8528:	06                   	push   es
    8529:	57                   	push   di
    852a:	9a 9b 3b 51 85       	call   0x8551:0x3b9b
    852f:	89 c7                	mov    di,ax
    8531:	8e c2                	mov    es,dx
    8533:	06                   	push   es
    8534:	57                   	push   di
    8535:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8538:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    853c:	9b dd 9e d6 fe       	fstp   QWORD PTR [bp-0x12a]
    8541:	90                   	nop
    8542:	9b                   	fwait
    8543:	bf b0 79             	mov    di,0x79b0
    8546:	0e                   	push   cs
    8547:	57                   	push   di
    8548:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    854c:	06                   	push   es
    854d:	57                   	push   di
    854e:	9a 9b 3b 75 85       	call   0x8575:0x3b9b
    8553:	89 c7                	mov    di,ax
    8555:	8e c2                	mov    es,dx
    8557:	06                   	push   es
    8558:	57                   	push   di
    8559:	26 c4 3d             	les    di,DWORD PTR es:[di]
    855c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8560:	9b dd 9e ce fe       	fstp   QWORD PTR [bp-0x132]
    8565:	90                   	nop
    8566:	9b                   	fwait
    8567:	bf bc 79             	mov    di,0x79bc
    856a:	0e                   	push   cs
    856b:	57                   	push   di
    856c:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8570:	06                   	push   es
    8571:	57                   	push   di
    8572:	9a 9b 3b 25 86       	call   0x8625:0x3b9b
    8577:	89 c7                	mov    di,ax
    8579:	8e c2                	mov    es,dx
    857b:	06                   	push   es
    857c:	57                   	push   di
    857d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8580:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8584:	9b dd 9e c6 fe       	fstp   QWORD PTR [bp-0x13a]
    8589:	90                   	nop
    858a:	9b                   	fwait
    858b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    858f:	83 c4 06             	add    sp,0x6
    8592:	b8 98 85             	mov    ax,0x8598
    8595:	0e                   	push   cs
    8596:	50                   	push   ax
    8597:	cb                   	retf
    8598:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    859b:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    85a0:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    85a4:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    85a8:	b8 47 7a             	mov    ax,0x7a47
    85ab:	0e                   	push   cs
    85ac:	50                   	push   ax
    85ad:	55                   	push   bp
    85ae:	ff 36 58 18          	push   WORD PTR ds:0x1858
    85b2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    85b6:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    85bc:	eb 04                	jmp    0x85c2
    85be:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    85c2:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    85c5:	99                   	cwd
    85c6:	89 86 66 fb          	mov    WORD PTR [bp-0x49a],ax
    85ca:	89 96 68 fb          	mov    WORD PTR [bp-0x498],dx
    85ce:	c6 86 6a fb 00       	mov    BYTE PTR [bp-0x496],0x0
    85d3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    85d6:	99                   	cwd
    85d7:	89 86 6e fb          	mov    WORD PTR [bp-0x492],ax
    85db:	89 96 70 fb          	mov    WORD PTR [bp-0x490],dx
    85df:	c6 86 72 fb 00       	mov    BYTE PTR [bp-0x48e],0x0
    85e4:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    85e8:	99                   	cwd
    85e9:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    85ed:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    85f1:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    85f6:	8d be 66 fb          	lea    di,[bp-0x49a]
    85fa:	16                   	push   ss
    85fb:	57                   	push   di
    85fc:	6a 02                	push   0x2
    85fe:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8602:	06                   	push   es
    8603:	57                   	push   di
    8604:	9a 95 28 48 88       	call   0x8848:0x2895
    8609:	08 c0                	or     al,al
    860b:	75 0a                	jne    0x8617
    860d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8610:	06                   	push   es
    8611:	57                   	push   di
    8612:	9a 03 03 56 88       	call   0x8856:0x303
    8617:	bf d1 79             	mov    di,0x79d1
    861a:	0e                   	push   cs
    861b:	57                   	push   di
    861c:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8620:	06                   	push   es
    8621:	57                   	push   di
    8622:	9a 9b 3b 5b 86       	call   0x865b:0x3b9b
    8627:	89 c7                	mov    di,ax
    8629:	8e c2                	mov    es,dx
    862b:	06                   	push   es
    862c:	57                   	push   di
    862d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8630:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8634:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8638:	99                   	cwd
    8639:	bf c9 79             	mov    di,0x79c9
    863c:	9a 16 04 75 86       	call   0x8675:0x416
    8641:	8b f8                	mov    di,ax
    8643:	c1 e7 03             	shl    di,0x3
    8646:	9b dd 9b ae fe       	fstp   QWORD PTR [bp+di-0x152]
    864b:	90                   	nop
    864c:	9b                   	fwait
    864d:	bf d6 79             	mov    di,0x79d6
    8650:	0e                   	push   cs
    8651:	57                   	push   di
    8652:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8656:	06                   	push   es
    8657:	57                   	push   di
    8658:	9a 9b 3b 91 86       	call   0x8691:0x3b9b
    865d:	89 c7                	mov    di,ax
    865f:	8e c2                	mov    es,dx
    8661:	06                   	push   es
    8662:	57                   	push   di
    8663:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8666:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    866a:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    866e:	99                   	cwd
    866f:	bf c9 79             	mov    di,0x79c9
    8672:	9a 16 04 ab 86       	call   0x86ab:0x416
    8677:	8b f8                	mov    di,ax
    8679:	c1 e7 03             	shl    di,0x3
    867c:	9b dd 9b 4e fe       	fstp   QWORD PTR [bp+di-0x1b2]
    8681:	90                   	nop
    8682:	9b                   	fwait
    8683:	bf e5 79             	mov    di,0x79e5
    8686:	0e                   	push   cs
    8687:	57                   	push   di
    8688:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    868c:	06                   	push   es
    868d:	57                   	push   di
    868e:	9a 9b 3b c7 86       	call   0x86c7:0x3b9b
    8693:	89 c7                	mov    di,ax
    8695:	8e c2                	mov    es,dx
    8697:	06                   	push   es
    8698:	57                   	push   di
    8699:	26 c4 3d             	les    di,DWORD PTR es:[di]
    869c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    86a0:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    86a4:	99                   	cwd
    86a5:	bf c9 79             	mov    di,0x79c9
    86a8:	9a 16 04 e1 86       	call   0x86e1:0x416
    86ad:	8b f8                	mov    di,ax
    86af:	c1 e7 03             	shl    di,0x3
    86b2:	9b dd 9b 9e fe       	fstp   QWORD PTR [bp+di-0x162]
    86b7:	90                   	nop
    86b8:	9b                   	fwait
    86b9:	bf ef 79             	mov    di,0x79ef
    86bc:	0e                   	push   cs
    86bd:	57                   	push   di
    86be:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    86c2:	06                   	push   es
    86c3:	57                   	push   di
    86c4:	9a 9b 3b fd 86       	call   0x86fd:0x3b9b
    86c9:	89 c7                	mov    di,ax
    86cb:	8e c2                	mov    es,dx
    86cd:	06                   	push   es
    86ce:	57                   	push   di
    86cf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    86d2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    86d6:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    86da:	99                   	cwd
    86db:	bf c9 79             	mov    di,0x79c9
    86de:	9a 16 04 17 87       	call   0x8717:0x416
    86e3:	8b f8                	mov    di,ax
    86e5:	c1 e7 03             	shl    di,0x3
    86e8:	9b dd 9b 8e fe       	fstp   QWORD PTR [bp+di-0x172]
    86ed:	90                   	nop
    86ee:	9b                   	fwait
    86ef:	bf ff 79             	mov    di,0x79ff
    86f2:	0e                   	push   cs
    86f3:	57                   	push   di
    86f4:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    86f8:	06                   	push   es
    86f9:	57                   	push   di
    86fa:	9a 9b 3b 33 87       	call   0x8733:0x3b9b
    86ff:	89 c7                	mov    di,ax
    8701:	8e c2                	mov    es,dx
    8703:	06                   	push   es
    8704:	57                   	push   di
    8705:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8708:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    870c:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8710:	99                   	cwd
    8711:	bf c9 79             	mov    di,0x79c9
    8714:	9a 16 04 51 87       	call   0x8751:0x416
    8719:	8b f8                	mov    di,ax
    871b:	c1 e7 03             	shl    di,0x3
    871e:	9b dd 9b 7e fe       	fstp   QWORD PTR [bp+di-0x182]
    8723:	90                   	nop
    8724:	9b                   	fwait
    8725:	bf 11 7a             	mov    di,0x7a11
    8728:	0e                   	push   cs
    8729:	57                   	push   di
    872a:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    872e:	06                   	push   es
    872f:	57                   	push   di
    8730:	9a 9b 3b 6e 87       	call   0x876e:0x3b9b
    8735:	89 c7                	mov    di,ax
    8737:	8e c2                	mov    es,dx
    8739:	06                   	push   es
    873a:	57                   	push   di
    873b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    873e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8742:	8b c8                	mov    cx,ax
    8744:	8b da                	mov    bx,dx
    8746:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    874a:	99                   	cwd
    874b:	bf c9 79             	mov    di,0x79c9
    874e:	9a 16 04 8c 87       	call   0x878c:0x416
    8753:	8b f8                	mov    di,ax
    8755:	c1 e7 02             	shl    di,0x2
    8758:	89 8b 7a fe          	mov    WORD PTR [bp+di-0x186],cx
    875c:	89 9b 7c fe          	mov    WORD PTR [bp+di-0x184],bx
    8760:	bf 24 7a             	mov    di,0x7a24
    8763:	0e                   	push   cs
    8764:	57                   	push   di
    8765:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8769:	06                   	push   es
    876a:	57                   	push   di
    876b:	9a 9b 3b a9 87       	call   0x87a9:0x3b9b
    8770:	89 c7                	mov    di,ax
    8772:	8e c2                	mov    es,dx
    8774:	06                   	push   es
    8775:	57                   	push   di
    8776:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8779:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    877d:	8b c8                	mov    cx,ax
    877f:	8b da                	mov    bx,dx
    8781:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8785:	99                   	cwd
    8786:	bf c9 79             	mov    di,0x79c9
    8789:	9a 16 04 c7 87       	call   0x87c7:0x416
    878e:	8b f8                	mov    di,ax
    8790:	c1 e7 02             	shl    di,0x2
    8793:	89 8b 72 fe          	mov    WORD PTR [bp+di-0x18e],cx
    8797:	89 9b 74 fe          	mov    WORD PTR [bp+di-0x18c],bx
    879b:	bf 35 7a             	mov    di,0x7a35
    879e:	0e                   	push   cs
    879f:	57                   	push   di
    87a0:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    87a4:	06                   	push   es
    87a5:	57                   	push   di
    87a6:	9a 9b 3b 66 88       	call   0x8866:0x3b9b
    87ab:	89 c7                	mov    di,ax
    87ad:	8e c2                	mov    es,dx
    87af:	06                   	push   es
    87b0:	57                   	push   di
    87b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    87b4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    87b8:	8b c8                	mov    cx,ax
    87ba:	8b da                	mov    bx,dx
    87bc:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    87c0:	99                   	cwd
    87c1:	bf c9 79             	mov    di,0x79c9
    87c4:	9a 16 04 16 88       	call   0x8816:0x416
    87c9:	8b f8                	mov    di,ax
    87cb:	c1 e7 02             	shl    di,0x2
    87ce:	89 8b 6a fe          	mov    WORD PTR [bp+di-0x196],cx
    87d2:	89 9b 6c fe          	mov    WORD PTR [bp+di-0x194],bx
    87d6:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    87db:	74 03                	je     0x87e0
    87dd:	e9 de fd             	jmp    0x85be
    87e0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    87e4:	83 c4 06             	add    sp,0x6
    87e7:	b8 ed 87             	mov    ax,0x87ed
    87ea:	0e                   	push   cs
    87eb:	50                   	push   ax
    87ec:	cb                   	retf
    87ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    87f0:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    87f5:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    87f9:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    87fd:	b8 f9 7a             	mov    ax,0x7af9
    8800:	0e                   	push   cs
    8801:	50                   	push   ax
    8802:	55                   	push   bp
    8803:	ff 36 58 18          	push   WORD PTR ds:0x1858
    8807:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    880b:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    880e:	2d 01 00             	sub    ax,0x1
    8811:	71 05                	jno    0x8818
    8813:	9a 3e 04 de 8a       	call   0x8ade:0x43e
    8818:	99                   	cwd
    8819:	89 86 6e fb          	mov    WORD PTR [bp-0x492],ax
    881d:	89 96 70 fb          	mov    WORD PTR [bp-0x490],dx
    8821:	c6 86 72 fb 00       	mov    BYTE PTR [bp-0x48e],0x0
    8826:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8829:	99                   	cwd
    882a:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    882e:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    8832:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    8837:	8d be 6e fb          	lea    di,[bp-0x492]
    883b:	16                   	push   ss
    883c:	57                   	push   di
    883d:	6a 01                	push   0x1
    883f:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8843:	06                   	push   es
    8844:	57                   	push   di
    8845:	9a 95 28 22 8b       	call   0x8b22:0x2895
    884a:	08 c0                	or     al,al
    884c:	75 0a                	jne    0x8858
    884e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8851:	06                   	push   es
    8852:	57                   	push   di
    8853:	9a 03 03 30 8b       	call   0x8b30:0x303
    8858:	bf 4d 7a             	mov    di,0x7a4d
    885b:	0e                   	push   cs
    885c:	57                   	push   di
    885d:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8861:	06                   	push   es
    8862:	57                   	push   di
    8863:	9a 9b 3b 8a 88       	call   0x888a:0x3b9b
    8868:	89 c7                	mov    di,ax
    886a:	8e c2                	mov    es,dx
    886c:	06                   	push   es
    886d:	57                   	push   di
    886e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8871:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8875:	9b dd 9e 4e fe       	fstp   QWORD PTR [bp-0x1b2]
    887a:	90                   	nop
    887b:	9b                   	fwait
    887c:	bf 5b 7a             	mov    di,0x7a5b
    887f:	0e                   	push   cs
    8880:	57                   	push   di
    8881:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8885:	06                   	push   es
    8886:	57                   	push   di
    8887:	9a 9b 3b ae 88       	call   0x88ae:0x3b9b
    888c:	89 c7                	mov    di,ax
    888e:	8e c2                	mov    es,dx
    8890:	06                   	push   es
    8891:	57                   	push   di
    8892:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8895:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8899:	9b dd 9e 46 fe       	fstp   QWORD PTR [bp-0x1ba]
    889e:	90                   	nop
    889f:	9b                   	fwait
    88a0:	bf 64 7a             	mov    di,0x7a64
    88a3:	0e                   	push   cs
    88a4:	57                   	push   di
    88a5:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    88a9:	06                   	push   es
    88aa:	57                   	push   di
    88ab:	9a 9b 3b d2 88       	call   0x88d2:0x3b9b
    88b0:	89 c7                	mov    di,ax
    88b2:	8e c2                	mov    es,dx
    88b4:	06                   	push   es
    88b5:	57                   	push   di
    88b6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    88b9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    88bd:	9b dd 9e 3e fe       	fstp   QWORD PTR [bp-0x1c2]
    88c2:	90                   	nop
    88c3:	9b                   	fwait
    88c4:	bf 70 7a             	mov    di,0x7a70
    88c7:	0e                   	push   cs
    88c8:	57                   	push   di
    88c9:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    88cd:	06                   	push   es
    88ce:	57                   	push   di
    88cf:	9a 9b 3b f6 88       	call   0x88f6:0x3b9b
    88d4:	89 c7                	mov    di,ax
    88d6:	8e c2                	mov    es,dx
    88d8:	06                   	push   es
    88d9:	57                   	push   di
    88da:	26 c4 3d             	les    di,DWORD PTR es:[di]
    88dd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    88e1:	9b dd 9e 36 fe       	fstp   QWORD PTR [bp-0x1ca]
    88e6:	90                   	nop
    88e7:	9b                   	fwait
    88e8:	bf 76 7a             	mov    di,0x7a76
    88eb:	0e                   	push   cs
    88ec:	57                   	push   di
    88ed:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    88f1:	06                   	push   es
    88f2:	57                   	push   di
    88f3:	9a 9b 3b 1a 89       	call   0x891a:0x3b9b
    88f8:	89 c7                	mov    di,ax
    88fa:	8e c2                	mov    es,dx
    88fc:	06                   	push   es
    88fd:	57                   	push   di
    88fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8901:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8905:	9b dd 9e 2e fe       	fstp   QWORD PTR [bp-0x1d2]
    890a:	90                   	nop
    890b:	9b                   	fwait
    890c:	bf 7a 7a             	mov    di,0x7a7a
    890f:	0e                   	push   cs
    8910:	57                   	push   di
    8911:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8915:	06                   	push   es
    8916:	57                   	push   di
    8917:	9a 9b 3b 3e 89       	call   0x893e:0x3b9b
    891c:	89 c7                	mov    di,ax
    891e:	8e c2                	mov    es,dx
    8920:	06                   	push   es
    8921:	57                   	push   di
    8922:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8925:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8929:	9b dd 9e 26 fe       	fstp   QWORD PTR [bp-0x1da]
    892e:	90                   	nop
    892f:	9b                   	fwait
    8930:	bf 82 7a             	mov    di,0x7a82
    8933:	0e                   	push   cs
    8934:	57                   	push   di
    8935:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8939:	06                   	push   es
    893a:	57                   	push   di
    893b:	9a 9b 3b 62 89       	call   0x8962:0x3b9b
    8940:	89 c7                	mov    di,ax
    8942:	8e c2                	mov    es,dx
    8944:	06                   	push   es
    8945:	57                   	push   di
    8946:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8949:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    894d:	9b dd 9e 1e fe       	fstp   QWORD PTR [bp-0x1e2]
    8952:	90                   	nop
    8953:	9b                   	fwait
    8954:	bf 8f 7a             	mov    di,0x7a8f
    8957:	0e                   	push   cs
    8958:	57                   	push   di
    8959:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    895d:	06                   	push   es
    895e:	57                   	push   di
    895f:	9a 9b 3b 86 89       	call   0x8986:0x3b9b
    8964:	89 c7                	mov    di,ax
    8966:	8e c2                	mov    es,dx
    8968:	06                   	push   es
    8969:	57                   	push   di
    896a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    896d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8971:	9b dd 9e 16 fe       	fstp   QWORD PTR [bp-0x1ea]
    8976:	90                   	nop
    8977:	9b                   	fwait
    8978:	bf 9a 7a             	mov    di,0x7a9a
    897b:	0e                   	push   cs
    897c:	57                   	push   di
    897d:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8981:	06                   	push   es
    8982:	57                   	push   di
    8983:	9a 9b 3b aa 89       	call   0x89aa:0x3b9b
    8988:	89 c7                	mov    di,ax
    898a:	8e c2                	mov    es,dx
    898c:	06                   	push   es
    898d:	57                   	push   di
    898e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8991:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8995:	9b dd 9e 0e fe       	fstp   QWORD PTR [bp-0x1f2]
    899a:	90                   	nop
    899b:	9b                   	fwait
    899c:	bf a2 7a             	mov    di,0x7aa2
    899f:	0e                   	push   cs
    89a0:	57                   	push   di
    89a1:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    89a5:	06                   	push   es
    89a6:	57                   	push   di
    89a7:	9a 9b 3b ce 89       	call   0x89ce:0x3b9b
    89ac:	89 c7                	mov    di,ax
    89ae:	8e c2                	mov    es,dx
    89b0:	06                   	push   es
    89b1:	57                   	push   di
    89b2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    89b5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    89b9:	9b dd 9e 06 fe       	fstp   QWORD PTR [bp-0x1fa]
    89be:	90                   	nop
    89bf:	9b                   	fwait
    89c0:	bf b0 7a             	mov    di,0x7ab0
    89c3:	0e                   	push   cs
    89c4:	57                   	push   di
    89c5:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    89c9:	06                   	push   es
    89ca:	57                   	push   di
    89cb:	9a 9b 3b f2 89       	call   0x89f2:0x3b9b
    89d0:	89 c7                	mov    di,ax
    89d2:	8e c2                	mov    es,dx
    89d4:	06                   	push   es
    89d5:	57                   	push   di
    89d6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    89d9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    89dd:	9b dd 9e fe fd       	fstp   QWORD PTR [bp-0x202]
    89e2:	90                   	nop
    89e3:	9b                   	fwait
    89e4:	bf bf 7a             	mov    di,0x7abf
    89e7:	0e                   	push   cs
    89e8:	57                   	push   di
    89e9:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    89ed:	06                   	push   es
    89ee:	57                   	push   di
    89ef:	9a 9b 3b 17 8a       	call   0x8a17:0x3b9b
    89f4:	89 c7                	mov    di,ax
    89f6:	8e c2                	mov    es,dx
    89f8:	06                   	push   es
    89f9:	57                   	push   di
    89fa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    89fd:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8a01:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    8a05:	89 96 fc fd          	mov    WORD PTR [bp-0x204],dx
    8a09:	bf c8 7a             	mov    di,0x7ac8
    8a0c:	0e                   	push   cs
    8a0d:	57                   	push   di
    8a0e:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8a12:	06                   	push   es
    8a13:	57                   	push   di
    8a14:	9a 9b 3b 3b 8a       	call   0x8a3b:0x3b9b
    8a19:	89 c7                	mov    di,ax
    8a1b:	8e c2                	mov    es,dx
    8a1d:	06                   	push   es
    8a1e:	57                   	push   di
    8a1f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8a22:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8a26:	9b dd 9e f2 fd       	fstp   QWORD PTR [bp-0x20e]
    8a2b:	90                   	nop
    8a2c:	9b                   	fwait
    8a2d:	bf de 7a             	mov    di,0x7ade
    8a30:	0e                   	push   cs
    8a31:	57                   	push   di
    8a32:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8a36:	06                   	push   es
    8a37:	57                   	push   di
    8a38:	9a 9b 3b 60 8a       	call   0x8a60:0x3b9b
    8a3d:	89 c7                	mov    di,ax
    8a3f:	8e c2                	mov    es,dx
    8a41:	06                   	push   es
    8a42:	57                   	push   di
    8a43:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8a46:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8a4a:	89 86 ee fd          	mov    WORD PTR [bp-0x212],ax
    8a4e:	89 96 f0 fd          	mov    WORD PTR [bp-0x210],dx
    8a52:	bf e9 7a             	mov    di,0x7ae9
    8a55:	0e                   	push   cs
    8a56:	57                   	push   di
    8a57:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8a5b:	06                   	push   es
    8a5c:	57                   	push   di
    8a5d:	9a 9b 3b 85 8a       	call   0x8a85:0x3b9b
    8a62:	89 c7                	mov    di,ax
    8a64:	8e c2                	mov    es,dx
    8a66:	06                   	push   es
    8a67:	57                   	push   di
    8a68:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8a6b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8a6f:	89 86 ea fd          	mov    WORD PTR [bp-0x216],ax
    8a73:	89 96 ec fd          	mov    WORD PTR [bp-0x214],dx
    8a77:	bf f2 7a             	mov    di,0x7af2
    8a7a:	0e                   	push   cs
    8a7b:	57                   	push   di
    8a7c:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8a80:	06                   	push   es
    8a81:	57                   	push   di
    8a82:	9a 9b 3b 40 8b       	call   0x8b40:0x3b9b
    8a87:	89 c7                	mov    di,ax
    8a89:	8e c2                	mov    es,dx
    8a8b:	06                   	push   es
    8a8c:	57                   	push   di
    8a8d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8a90:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8a94:	89 86 e6 fd          	mov    WORD PTR [bp-0x21a],ax
    8a98:	89 96 e8 fd          	mov    WORD PTR [bp-0x218],dx
    8a9c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8aa0:	83 c4 06             	add    sp,0x6
    8aa3:	b8 a9 8a             	mov    ax,0x8aa9
    8aa6:	0e                   	push   cs
    8aa7:	50                   	push   ax
    8aa8:	cb                   	retf
    8aa9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8aac:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    8ab1:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    8ab5:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    8ab9:	b8 32 7b             	mov    ax,0x7b32
    8abc:	0e                   	push   cs
    8abd:	50                   	push   ax
    8abe:	55                   	push   bp
    8abf:	ff 36 58 18          	push   WORD PTR ds:0x1858
    8ac3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    8ac7:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    8acd:	eb 04                	jmp    0x8ad3
    8acf:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    8ad3:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    8ad6:	2d 01 00             	sub    ax,0x1
    8ad9:	71 05                	jno    0x8ae0
    8adb:	9a 3e 04 5e 8b       	call   0x8b5e:0x43e
    8ae0:	99                   	cwd
    8ae1:	89 86 66 fb          	mov    WORD PTR [bp-0x49a],ax
    8ae5:	89 96 68 fb          	mov    WORD PTR [bp-0x498],dx
    8ae9:	c6 86 6a fb 00       	mov    BYTE PTR [bp-0x496],0x0
    8aee:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8af1:	99                   	cwd
    8af2:	89 86 6e fb          	mov    WORD PTR [bp-0x492],ax
    8af6:	89 96 70 fb          	mov    WORD PTR [bp-0x490],dx
    8afa:	c6 86 72 fb 00       	mov    BYTE PTR [bp-0x48e],0x0
    8aff:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8b03:	99                   	cwd
    8b04:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    8b08:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    8b0c:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    8b11:	8d be 66 fb          	lea    di,[bp-0x49a]
    8b15:	16                   	push   ss
    8b16:	57                   	push   di
    8b17:	6a 02                	push   0x2
    8b19:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8b1d:	06                   	push   es
    8b1e:	57                   	push   di
    8b1f:	9a 95 28 41 8c       	call   0x8c41:0x2895
    8b24:	08 c0                	or     al,al
    8b26:	75 0a                	jne    0x8b32
    8b28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8b2b:	06                   	push   es
    8b2c:	57                   	push   di
    8b2d:	9a 03 03 4f 8c       	call   0x8c4f:0x303
    8b32:	bf 07 7b             	mov    di,0x7b07
    8b35:	0e                   	push   cs
    8b36:	57                   	push   di
    8b37:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8b3b:	06                   	push   es
    8b3c:	57                   	push   di
    8b3d:	9a 9b 3b 7b 8b       	call   0x8b7b:0x3b9b
    8b42:	89 c7                	mov    di,ax
    8b44:	8e c2                	mov    es,dx
    8b46:	06                   	push   es
    8b47:	57                   	push   di
    8b48:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8b4b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8b4f:	8b c8                	mov    cx,ax
    8b51:	8b da                	mov    bx,dx
    8b53:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8b57:	99                   	cwd
    8b58:	bf ff 7a             	mov    di,0x7aff
    8b5b:	9a 16 04 95 8b       	call   0x8b95:0x416
    8b60:	8b f8                	mov    di,ax
    8b62:	c1 e7 02             	shl    di,0x2
    8b65:	89 8b da fd          	mov    WORD PTR [bp+di-0x226],cx
    8b69:	89 9b dc fd          	mov    WORD PTR [bp+di-0x224],bx
    8b6d:	bf 10 7b             	mov    di,0x7b10
    8b70:	0e                   	push   cs
    8b71:	57                   	push   di
    8b72:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8b76:	06                   	push   es
    8b77:	57                   	push   di
    8b78:	9a 9b 3b b1 8b       	call   0x8bb1:0x3b9b
    8b7d:	89 c7                	mov    di,ax
    8b7f:	8e c2                	mov    es,dx
    8b81:	06                   	push   es
    8b82:	57                   	push   di
    8b83:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8b86:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8b8a:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8b8e:	99                   	cwd
    8b8f:	bf ff 7a             	mov    di,0x7aff
    8b92:	9a 16 04 cb 8b       	call   0x8bcb:0x416
    8b97:	8b f8                	mov    di,ax
    8b99:	c1 e7 03             	shl    di,0x3
    8b9c:	9b dd 9b c6 fd       	fstp   QWORD PTR [bp+di-0x23a]
    8ba1:	90                   	nop
    8ba2:	9b                   	fwait
    8ba3:	bf 1c 7b             	mov    di,0x7b1c
    8ba6:	0e                   	push   cs
    8ba7:	57                   	push   di
    8ba8:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8bac:	06                   	push   es
    8bad:	57                   	push   di
    8bae:	9a 9b 3b 5f 8c       	call   0x8c5f:0x3b9b
    8bb3:	89 c7                	mov    di,ax
    8bb5:	8e c2                	mov    es,dx
    8bb7:	06                   	push   es
    8bb8:	57                   	push   di
    8bb9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8bbc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8bc0:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8bc4:	99                   	cwd
    8bc5:	bf ff 7a             	mov    di,0x7aff
    8bc8:	9a 16 04 51 8d       	call   0x8d51:0x416
    8bcd:	8b f8                	mov    di,ax
    8bcf:	c1 e7 03             	shl    di,0x3
    8bd2:	9b dd 9b b6 fd       	fstp   QWORD PTR [bp+di-0x24a]
    8bd7:	90                   	nop
    8bd8:	9b                   	fwait
    8bd9:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    8bde:	74 03                	je     0x8be3
    8be0:	e9 ec fe             	jmp    0x8acf
    8be3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8be7:	83 c4 06             	add    sp,0x6
    8bea:	b8 f0 8b             	mov    ax,0x8bf0
    8bed:	0e                   	push   cs
    8bee:	50                   	push   ax
    8bef:	cb                   	retf
    8bf0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8bf3:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    8bf8:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    8bfc:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    8c00:	b8 4a 7b             	mov    ax,0x7b4a
    8c03:	0e                   	push   cs
    8c04:	50                   	push   ax
    8c05:	55                   	push   bp
    8c06:	ff 36 58 18          	push   WORD PTR ds:0x1858
    8c0a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    8c0e:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    8c11:	99                   	cwd
    8c12:	89 86 6e fb          	mov    WORD PTR [bp-0x492],ax
    8c16:	89 96 70 fb          	mov    WORD PTR [bp-0x490],dx
    8c1a:	c6 86 72 fb 00       	mov    BYTE PTR [bp-0x48e],0x0
    8c1f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8c22:	99                   	cwd
    8c23:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    8c27:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    8c2b:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    8c30:	8d be 6e fb          	lea    di,[bp-0x492]
    8c34:	16                   	push   ss
    8c35:	57                   	push   di
    8c36:	6a 01                	push   0x1
    8c38:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8c3c:	06                   	push   es
    8c3d:	57                   	push   di
    8c3e:	9a 95 28 15 8d       	call   0x8d15:0x2895
    8c43:	08 c0                	or     al,al
    8c45:	75 0a                	jne    0x8c51
    8c47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8c4a:	06                   	push   es
    8c4b:	57                   	push   di
    8c4c:	9a 03 03 23 8d       	call   0x8d23:0x303
    8c51:	bf 38 7b             	mov    di,0x7b38
    8c54:	0e                   	push   cs
    8c55:	57                   	push   di
    8c56:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8c5a:	06                   	push   es
    8c5b:	57                   	push   di
    8c5c:	9a 9b 3b 83 8c       	call   0x8c83:0x3b9b
    8c61:	89 c7                	mov    di,ax
    8c63:	8e c2                	mov    es,dx
    8c65:	06                   	push   es
    8c66:	57                   	push   di
    8c67:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8c6a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8c6e:	9b dd 9e 4e ff       	fstp   QWORD PTR [bp-0xb2]
    8c73:	90                   	nop
    8c74:	9b                   	fwait
    8c75:	bf 41 7b             	mov    di,0x7b41
    8c78:	0e                   	push   cs
    8c79:	57                   	push   di
    8c7a:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8c7e:	06                   	push   es
    8c7f:	57                   	push   di
    8c80:	9a 9b 3b 33 8d       	call   0x8d33:0x3b9b
    8c85:	89 c7                	mov    di,ax
    8c87:	8e c2                	mov    es,dx
    8c89:	06                   	push   es
    8c8a:	57                   	push   di
    8c8b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8c8e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8c92:	9b dd 9e 56 ff       	fstp   QWORD PTR [bp-0xaa]
    8c97:	90                   	nop
    8c98:	9b                   	fwait
    8c99:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8c9d:	83 c4 06             	add    sp,0x6
    8ca0:	b8 a6 8c             	mov    ax,0x8ca6
    8ca3:	0e                   	push   cs
    8ca4:	50                   	push   ax
    8ca5:	cb                   	retf
    8ca6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8ca9:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    8cae:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    8cb2:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    8cb6:	b8 a3 7b             	mov    ax,0x7ba3
    8cb9:	0e                   	push   cs
    8cba:	50                   	push   ax
    8cbb:	55                   	push   bp
    8cbc:	ff 36 58 18          	push   WORD PTR ds:0x1858
    8cc0:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    8cc4:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    8cca:	eb 04                	jmp    0x8cd0
    8ccc:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    8cd0:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    8cd3:	99                   	cwd
    8cd4:	89 86 66 fb          	mov    WORD PTR [bp-0x49a],ax
    8cd8:	89 96 68 fb          	mov    WORD PTR [bp-0x498],dx
    8cdc:	c6 86 6a fb 00       	mov    BYTE PTR [bp-0x496],0x0
    8ce1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    8ce4:	99                   	cwd
    8ce5:	89 86 6e fb          	mov    WORD PTR [bp-0x492],ax
    8ce9:	89 96 70 fb          	mov    WORD PTR [bp-0x490],dx
    8ced:	c6 86 72 fb 00       	mov    BYTE PTR [bp-0x48e],0x0
    8cf2:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8cf6:	99                   	cwd
    8cf7:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    8cfb:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    8cff:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    8d04:	8d be 66 fb          	lea    di,[bp-0x49a]
    8d08:	16                   	push   ss
    8d09:	57                   	push   di
    8d0a:	6a 02                	push   0x2
    8d0c:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8d10:	06                   	push   es
    8d11:	57                   	push   di
    8d12:	9a 95 28 8d a2       	call   0xa28d:0x2895
    8d17:	08 c0                	or     al,al
    8d19:	75 0a                	jne    0x8d25
    8d1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8d1e:	06                   	push   es
    8d1f:	57                   	push   di
    8d20:	9a 03 03 08 9b       	call   0x9b08:0x303
    8d25:	bf 58 7b             	mov    di,0x7b58
    8d28:	0e                   	push   cs
    8d29:	57                   	push   di
    8d2a:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8d2e:	06                   	push   es
    8d2f:	57                   	push   di
    8d30:	9a 9b 3b 6e 8d       	call   0x8d6e:0x3b9b
    8d35:	89 c7                	mov    di,ax
    8d37:	8e c2                	mov    es,dx
    8d39:	06                   	push   es
    8d3a:	57                   	push   di
    8d3b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8d3e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8d42:	8b c8                	mov    cx,ax
    8d44:	8b da                	mov    bx,dx
    8d46:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8d4a:	99                   	cwd
    8d4b:	bf 50 7b             	mov    di,0x7b50
    8d4e:	9a 16 04 8c 8d       	call   0x8d8c:0x416
    8d53:	8b f8                	mov    di,ax
    8d55:	c1 e7 02             	shl    di,0x2
    8d58:	89 8b c2 fc          	mov    WORD PTR [bp+di-0x33e],cx
    8d5c:	89 9b c4 fc          	mov    WORD PTR [bp+di-0x33c],bx
    8d60:	bf 5f 7b             	mov    di,0x7b5f
    8d63:	0e                   	push   cs
    8d64:	57                   	push   di
    8d65:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8d69:	06                   	push   es
    8d6a:	57                   	push   di
    8d6b:	9a 9b 3b a9 8d       	call   0x8da9:0x3b9b
    8d70:	89 c7                	mov    di,ax
    8d72:	8e c2                	mov    es,dx
    8d74:	06                   	push   es
    8d75:	57                   	push   di
    8d76:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8d79:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8d7d:	8b c8                	mov    cx,ax
    8d7f:	8b da                	mov    bx,dx
    8d81:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8d85:	99                   	cwd
    8d86:	bf 50 7b             	mov    di,0x7b50
    8d89:	9a 16 04 c7 8d       	call   0x8dc7:0x416
    8d8e:	8b f8                	mov    di,ax
    8d90:	c1 e7 02             	shl    di,0x2
    8d93:	89 8b ba fc          	mov    WORD PTR [bp+di-0x346],cx
    8d97:	89 9b bc fc          	mov    WORD PTR [bp+di-0x344],bx
    8d9b:	bf 70 7b             	mov    di,0x7b70
    8d9e:	0e                   	push   cs
    8d9f:	57                   	push   di
    8da0:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8da4:	06                   	push   es
    8da5:	57                   	push   di
    8da6:	9a 9b 3b e4 8d       	call   0x8de4:0x3b9b
    8dab:	89 c7                	mov    di,ax
    8dad:	8e c2                	mov    es,dx
    8daf:	06                   	push   es
    8db0:	57                   	push   di
    8db1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8db4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8db8:	8b c8                	mov    cx,ax
    8dba:	8b da                	mov    bx,dx
    8dbc:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8dc0:	99                   	cwd
    8dc1:	bf 50 7b             	mov    di,0x7b50
    8dc4:	9a 16 04 02 8e       	call   0x8e02:0x416
    8dc9:	8b f8                	mov    di,ax
    8dcb:	c1 e7 02             	shl    di,0x2
    8dce:	89 8b b2 fc          	mov    WORD PTR [bp+di-0x34e],cx
    8dd2:	89 9b b4 fc          	mov    WORD PTR [bp+di-0x34c],bx
    8dd6:	bf 7d 7b             	mov    di,0x7b7d
    8dd9:	0e                   	push   cs
    8dda:	57                   	push   di
    8ddb:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8ddf:	06                   	push   es
    8de0:	57                   	push   di
    8de1:	9a 9b 3b 1f 8e       	call   0x8e1f:0x3b9b
    8de6:	89 c7                	mov    di,ax
    8de8:	8e c2                	mov    es,dx
    8dea:	06                   	push   es
    8deb:	57                   	push   di
    8dec:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8def:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8df3:	8b c8                	mov    cx,ax
    8df5:	8b da                	mov    bx,dx
    8df7:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8dfb:	99                   	cwd
    8dfc:	bf 50 7b             	mov    di,0x7b50
    8dff:	9a 16 04 3d 8e       	call   0x8e3d:0x416
    8e04:	8b f8                	mov    di,ax
    8e06:	c1 e7 02             	shl    di,0x2
    8e09:	89 8b aa fc          	mov    WORD PTR [bp+di-0x356],cx
    8e0d:	89 9b ac fc          	mov    WORD PTR [bp+di-0x354],bx
    8e11:	bf 86 7b             	mov    di,0x7b86
    8e14:	0e                   	push   cs
    8e15:	57                   	push   di
    8e16:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8e1a:	06                   	push   es
    8e1b:	57                   	push   di
    8e1c:	9a 9b 3b 5a 8e       	call   0x8e5a:0x3b9b
    8e21:	89 c7                	mov    di,ax
    8e23:	8e c2                	mov    es,dx
    8e25:	06                   	push   es
    8e26:	57                   	push   di
    8e27:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8e2a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    8e2e:	8b c8                	mov    cx,ax
    8e30:	8b da                	mov    bx,dx
    8e32:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8e36:	99                   	cwd
    8e37:	bf 50 7b             	mov    di,0x7b50
    8e3a:	9a 16 04 74 8e       	call   0x8e74:0x416
    8e3f:	8b f8                	mov    di,ax
    8e41:	c1 e7 02             	shl    di,0x2
    8e44:	89 8b 62 fe          	mov    WORD PTR [bp+di-0x19e],cx
    8e48:	89 9b 64 fe          	mov    WORD PTR [bp+di-0x19c],bx
    8e4c:	bf 97 7b             	mov    di,0x7b97
    8e4f:	0e                   	push   cs
    8e50:	57                   	push   di
    8e51:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    8e55:	06                   	push   es
    8e56:	57                   	push   di
    8e57:	9a 9b 3b a6 a2       	call   0xa2a6:0x3b9b
    8e5c:	89 c7                	mov    di,ax
    8e5e:	8e c2                	mov    es,dx
    8e60:	06                   	push   es
    8e61:	57                   	push   di
    8e62:	26 c4 3d             	les    di,DWORD PTR es:[di]
    8e65:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    8e69:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8e6d:	99                   	cwd
    8e6e:	bf 50 7b             	mov    di,0x7b50
    8e71:	9a 16 04 ae 8e       	call   0x8eae:0x416
    8e76:	8b f8                	mov    di,ax
    8e78:	c1 e7 03             	shl    di,0x3
    8e7b:	9b dd 9b a4 fb       	fstp   QWORD PTR [bp+di-0x45c]
    8e80:	90                   	nop
    8e81:	9b                   	fwait
    8e82:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    8e87:	74 03                	je     0x8e8c
    8e89:	e9 40 fe             	jmp    0x8ccc
    8e8c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    8e90:	83 c4 06             	add    sp,0x6
    8e93:	b8 99 8e             	mov    ax,0x8e99
    8e96:	0e                   	push   cs
    8e97:	50                   	push   ax
    8e98:	cb                   	retf
    8e99:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    8e9d:	8b 96 fc fd          	mov    dx,WORD PTR [bp-0x204]
    8ea1:	03 86 22 ff          	add    ax,WORD PTR [bp-0xde]
    8ea5:	13 96 24 ff          	adc    dx,WORD PTR [bp-0xdc]
    8ea9:	71 05                	jno    0x8eb0
    8eab:	9a 3e 04 bd 8e       	call   0x8ebd:0x43e
    8eb0:	2b 86 1e ff          	sub    ax,WORD PTR [bp-0xe2]
    8eb4:	1b 96 20 ff          	sbb    dx,WORD PTR [bp-0xe0]
    8eb8:	71 05                	jno    0x8ebf
    8eba:	9a 3e 04 e8 8e       	call   0x8ee8:0x43e
    8ebf:	89 86 02 fd          	mov    WORD PTR [bp-0x2fe],ax
    8ec3:	89 96 04 fd          	mov    WORD PTR [bp-0x2fc],dx
    8ec7:	31 c0                	xor    ax,ax
    8ec9:	89 86 fa fc          	mov    WORD PTR [bp-0x306],ax
    8ecd:	89 86 fc fc          	mov    WORD PTR [bp-0x304],ax
    8ed1:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    8ed7:	eb 04                	jmp    0x8edd
    8ed9:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    8edd:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8ee1:	99                   	cwd
    8ee2:	bf a9 7b             	mov    di,0x7ba9
    8ee5:	9a 16 04 04 8f       	call   0x8f04:0x416
    8eea:	8b f8                	mov    di,ax
    8eec:	c1 e7 02             	shl    di,0x2
    8eef:	8b 83 72 fe          	mov    ax,WORD PTR [bp+di-0x18e]
    8ef3:	8b 93 74 fe          	mov    dx,WORD PTR [bp+di-0x18c]
    8ef7:	03 86 fa fc          	add    ax,WORD PTR [bp-0x306]
    8efb:	13 96 fc fc          	adc    dx,WORD PTR [bp-0x304]
    8eff:	71 05                	jno    0x8f06
    8f01:	9a 3e 04 36 8f       	call   0x8f36:0x43e
    8f06:	89 86 fa fc          	mov    WORD PTR [bp-0x306],ax
    8f0a:	89 96 fc fc          	mov    WORD PTR [bp-0x304],dx
    8f0e:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    8f13:	75 c4                	jne    0x8ed9
    8f15:	31 c0                	xor    ax,ax
    8f17:	89 86 fe fc          	mov    WORD PTR [bp-0x302],ax
    8f1b:	89 86 00 fd          	mov    WORD PTR [bp-0x300],ax
    8f1f:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    8f25:	eb 04                	jmp    0x8f2b
    8f27:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    8f2b:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8f2f:	99                   	cwd
    8f30:	bf a9 7b             	mov    di,0x7ba9
    8f33:	9a 16 04 52 8f       	call   0x8f52:0x416
    8f38:	8b f8                	mov    di,ax
    8f3a:	c1 e7 02             	shl    di,0x2
    8f3d:	8b 83 7a fe          	mov    ax,WORD PTR [bp+di-0x186]
    8f41:	8b 93 7c fe          	mov    dx,WORD PTR [bp+di-0x184]
    8f45:	03 86 fe fc          	add    ax,WORD PTR [bp-0x302]
    8f49:	13 96 00 fd          	adc    dx,WORD PTR [bp-0x300]
    8f4d:	71 05                	jno    0x8f54
    8f4f:	9a 3e 04 78 8f       	call   0x8f78:0x43e
    8f54:	89 86 fe fc          	mov    WORD PTR [bp-0x302],ax
    8f58:	89 96 00 fd          	mov    WORD PTR [bp-0x300],dx
    8f5c:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    8f61:	75 c4                	jne    0x8f27
    8f63:	8b 86 e6 fd          	mov    ax,WORD PTR [bp-0x21a]
    8f67:	8b 96 e8 fd          	mov    dx,WORD PTR [bp-0x218]
    8f6b:	03 86 ea fe          	add    ax,WORD PTR [bp-0x116]
    8f6f:	13 96 ec fe          	adc    dx,WORD PTR [bp-0x114]
    8f73:	71 05                	jno    0x8f7a
    8f75:	9a 3e 04 87 8f       	call   0x8f87:0x43e
    8f7a:	2b 86 e6 fe          	sub    ax,WORD PTR [bp-0x11a]
    8f7e:	1b 96 e8 fe          	sbb    dx,WORD PTR [bp-0x118]
    8f82:	71 05                	jno    0x8f89
    8f84:	9a 3e 04 cf 8f       	call   0x8fcf:0x43e
    8f89:	89 86 f6 fc          	mov    WORD PTR [bp-0x30a],ax
    8f8d:	89 96 f8 fc          	mov    WORD PTR [bp-0x308],dx
    8f91:	9b 2e d9 06 b1 7b    	fld    DWORD PTR cs:0x7bb1
    8f97:	9b dd 9e 26 fc       	fstp   QWORD PTR [bp-0x3da]
    8f9c:	90                   	nop
    8f9d:	9b                   	fwait
    8f9e:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    8fa4:	9b dd 9e 1e fc       	fstp   QWORD PTR [bp-0x3e2]
    8fa9:	90                   	nop
    8faa:	9b                   	fwait
    8fab:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    8fb1:	9b dd 9e 16 fc       	fstp   QWORD PTR [bp-0x3ea]
    8fb6:	90                   	nop
    8fb7:	9b                   	fwait
    8fb8:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    8fbe:	eb 04                	jmp    0x8fc4
    8fc0:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    8fc4:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8fc8:	99                   	cwd
    8fc9:	bf a9 7b             	mov    di,0x7ba9
    8fcc:	9a 16 04 e6 8f       	call   0x8fe6:0x416
    8fd1:	8b f8                	mov    di,ax
    8fd3:	c1 e7 02             	shl    di,0x2
    8fd6:	9b db 83 62 fe       	fild   DWORD PTR [bp+di-0x19e]
    8fdb:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    8fdf:	99                   	cwd
    8fe0:	bf a9 7b             	mov    di,0x7ba9
    8fe3:	9a 16 04 0d 90       	call   0x900d:0x416
    8fe8:	8b f8                	mov    di,ax
    8fea:	c1 e7 03             	shl    di,0x3
    8fed:	9b dc 8b 2e ff       	fmul   QWORD PTR [bp+di-0xd2]
    8ff2:	83 ec 08             	sub    sp,0x8
    8ff5:	89 e3                	mov    bx,sp
    8ff7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    8ffb:	90                   	nop
    8ffc:	9b                   	fwait
    8ffd:	9a a6 2f 44 90       	call   0x9044:0x2fa6
    9002:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9006:	99                   	cwd
    9007:	bf a9 7b             	mov    di,0x7ba9
    900a:	9a 16 04 26 90       	call   0x9026:0x416
    900f:	8b f8                	mov    di,ax
    9011:	c1 e7 03             	shl    di,0x3
    9014:	9b dd 9b 76 fc       	fstp   QWORD PTR [bp+di-0x38a]
    9019:	90                   	nop
    901a:	9b                   	fwait
    901b:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    901f:	99                   	cwd
    9020:	bf a9 7b             	mov    di,0x7ba9
    9023:	9a 16 04 51 90       	call   0x9051:0x416
    9028:	8b f8                	mov    di,ax
    902a:	c1 e7 02             	shl    di,0x2
    902d:	9b db 83 7a fe       	fild   DWORD PTR [bp+di-0x186]
    9032:	9b dc 4e c0          	fmul   QWORD PTR [bp-0x40]
    9036:	83 ec 08             	sub    sp,0x8
    9039:	89 e3                	mov    bx,sp
    903b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    903f:	90                   	nop
    9040:	9b                   	fwait
    9041:	9a a6 2f 98 90       	call   0x9098:0x2fa6
    9046:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    904a:	99                   	cwd
    904b:	bf a9 7b             	mov    di,0x7ba9
    904e:	9a 16 04 74 90       	call   0x9074:0x416
    9053:	8b f8                	mov    di,ax
    9055:	c1 e7 03             	shl    di,0x3
    9058:	9b dd 9b 66 fc       	fstp   QWORD PTR [bp+di-0x39a]
    905d:	90                   	nop
    905e:	9b 9b df 86 82 fb    	fild   WORD PTR [bp-0x47e]
    9064:	9b dc a6 56 ff       	fsub   QWORD PTR [bp-0xaa]
    9069:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    906d:	99                   	cwd
    906e:	bf a9 7b             	mov    di,0x7ba9
    9071:	9a 16 04 88 90       	call   0x9088:0x416
    9076:	8b f8                	mov    di,ax
    9078:	c1 e7 03             	shl    di,0x3
    907b:	9b dc 8b 66 fc       	fmul   QWORD PTR [bp+di-0x39a]
    9080:	9b df 86 82 fb       	fild   WORD PTR [bp-0x47e]
    9085:	9a b2 04 a5 90       	call   0x90a5:0x4b2
    908a:	83 ec 08             	sub    sp,0x8
    908d:	89 e3                	mov    bx,sp
    908f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    9093:	90                   	nop
    9094:	9b                   	fwait
    9095:	9a a6 2f 44 91       	call   0x9144:0x2fa6
    909a:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    909e:	99                   	cwd
    909f:	bf a9 7b             	mov    di,0x7ba9
    90a2:	9a 16 04 be 90       	call   0x90be:0x416
    90a7:	8b f8                	mov    di,ax
    90a9:	c1 e7 03             	shl    di,0x3
    90ac:	9b dd 9b 66 fc       	fstp   QWORD PTR [bp+di-0x39a]
    90b1:	90                   	nop
    90b2:	9b                   	fwait
    90b3:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    90b7:	99                   	cwd
    90b8:	bf a9 7b             	mov    di,0x7ba9
    90bb:	9a 16 04 ec 90       	call   0x90ec:0x416
    90c0:	8b f8                	mov    di,ax
    90c2:	c1 e7 03             	shl    di,0x3
    90c5:	9b dd 83 a4 fb       	fld    QWORD PTR [bp+di-0x45c]
    90ca:	9b 2e d8 1e ae 7b    	fcomp  DWORD PTR cs:0x7bae
    90d0:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    90d5:	90                   	nop
    90d6:	9b                   	fwait
    90d7:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    90db:	9e                   	sahf
    90dc:	77 03                	ja     0x90e1
    90de:	e9 95 00             	jmp    0x9176
    90e1:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    90e5:	99                   	cwd
    90e6:	bf a9 7b             	mov    di,0x7ba9
    90e9:	9a 16 04 03 91       	call   0x9103:0x416
    90ee:	8b f8                	mov    di,ax
    90f0:	c1 e7 02             	shl    di,0x2
    90f3:	9b db 83 7a fe       	fild   DWORD PTR [bp+di-0x186]
    90f8:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    90fc:	99                   	cwd
    90fd:	bf a9 7b             	mov    di,0x7ba9
    9100:	9a 16 04 18 91       	call   0x9118:0x416
    9105:	8b f8                	mov    di,ax
    9107:	c1 e7 03             	shl    di,0x3
    910a:	9b dc 8b a4 fb       	fmul   QWORD PTR [bp+di-0x45c]
    910f:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9115:	9a b2 04 34 91       	call   0x9134:0x4b2
    911a:	9b dc 4e c0          	fmul   QWORD PTR [bp-0x40]
    911e:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9124:	9b dc 46 f8          	fadd   QWORD PTR [bp-0x8]
    9128:	9b de c9             	fmulp  st(1),st
    912b:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9131:	9a b2 04 51 91       	call   0x9151:0x4b2
    9136:	83 ec 08             	sub    sp,0x8
    9139:	89 e3                	mov    bx,sp
    913b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    913f:	90                   	nop
    9140:	9b                   	fwait
    9141:	9a a6 2f ab 91       	call   0x91ab:0x2fa6
    9146:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    914a:	99                   	cwd
    914b:	bf a9 7b             	mov    di,0x7ba9
    914e:	9a 16 04 68 91       	call   0x9168:0x416
    9153:	8b f8                	mov    di,ax
    9155:	c1 e7 03             	shl    di,0x3
    9158:	9b dc 83 66 fc       	fadd   QWORD PTR [bp+di-0x39a]
    915d:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9161:	99                   	cwd
    9162:	bf a9 7b             	mov    di,0x7ba9
    9165:	9a 16 04 81 91       	call   0x9181:0x416
    916a:	8b f8                	mov    di,ax
    916c:	c1 e7 03             	shl    di,0x3
    916f:	9b dd 9b 66 fc       	fstp   QWORD PTR [bp+di-0x39a]
    9174:	90                   	nop
    9175:	9b                   	fwait
    9176:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    917a:	99                   	cwd
    917b:	bf a9 7b             	mov    di,0x7ba9
    917e:	9a 16 04 9b 91       	call   0x919b:0x416
    9183:	8b f8                	mov    di,ax
    9185:	c1 e7 03             	shl    di,0x3
    9188:	9b dd 83 66 fc       	fld    QWORD PTR [bp+di-0x39a]
    918d:	9b dc 8e de fe       	fmul   QWORD PTR [bp-0x122]
    9192:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9198:	9a b2 04 b8 91       	call   0x91b8:0x4b2
    919d:	83 ec 08             	sub    sp,0x8
    91a0:	89 e3                	mov    bx,sp
    91a2:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    91a6:	90                   	nop
    91a7:	9b                   	fwait
    91a8:	9a a6 2f aa 92       	call   0x92aa:0x2fa6
    91ad:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    91b1:	99                   	cwd
    91b2:	bf a9 7b             	mov    di,0x7ba9
    91b5:	9a 16 04 d1 91       	call   0x91d1:0x416
    91ba:	8b f8                	mov    di,ax
    91bc:	c1 e7 03             	shl    di,0x3
    91bf:	9b dd 9b 66 fc       	fstp   QWORD PTR [bp+di-0x39a]
    91c4:	90                   	nop
    91c5:	9b                   	fwait
    91c6:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    91ca:	99                   	cwd
    91cb:	bf a9 7b             	mov    di,0x7ba9
    91ce:	9a 16 04 e8 91       	call   0x91e8:0x416
    91d3:	8b f8                	mov    di,ax
    91d5:	c1 e7 03             	shl    di,0x3
    91d8:	9b dd 83 76 fc       	fld    QWORD PTR [bp+di-0x38a]
    91dd:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    91e1:	99                   	cwd
    91e2:	bf a9 7b             	mov    di,0x7ba9
    91e5:	9a 16 04 ff 91       	call   0x91ff:0x416
    91ea:	8b f8                	mov    di,ax
    91ec:	c1 e7 03             	shl    di,0x3
    91ef:	9b dc 83 66 fc       	fadd   QWORD PTR [bp+di-0x39a]
    91f4:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    91f8:	99                   	cwd
    91f9:	bf a9 7b             	mov    di,0x7ba9
    91fc:	9a 16 04 16 92       	call   0x9216:0x416
    9201:	8b f8                	mov    di,ax
    9203:	c1 e7 03             	shl    di,0x3
    9206:	9b dc 83 8e fe       	fadd   QWORD PTR [bp+di-0x172]
    920b:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    920f:	99                   	cwd
    9210:	bf a9 7b             	mov    di,0x7ba9
    9213:	9a 16 04 2d 92       	call   0x922d:0x416
    9218:	8b f8                	mov    di,ax
    921a:	c1 e7 03             	shl    di,0x3
    921d:	9b dc 83 86 fc       	fadd   QWORD PTR [bp+di-0x37a]
    9222:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9226:	99                   	cwd
    9227:	bf a9 7b             	mov    di,0x7ba9
    922a:	9a 16 04 5b 92       	call   0x925b:0x416
    922f:	8b f8                	mov    di,ax
    9231:	c1 e7 03             	shl    di,0x3
    9234:	9b dc 83 c6 fd       	fadd   QWORD PTR [bp+di-0x23a]
    9239:	9b dd 9e 0e fc       	fstp   QWORD PTR [bp-0x3f2]
    923e:	90                   	nop
    923f:	9b                   	fwait
    9240:	ff b6 14 fc          	push   WORD PTR [bp-0x3ec]
    9244:	ff b6 12 fc          	push   WORD PTR [bp-0x3ee]
    9248:	ff b6 10 fc          	push   WORD PTR [bp-0x3f0]
    924c:	ff b6 0e fc          	push   WORD PTR [bp-0x3f2]
    9250:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9254:	99                   	cwd
    9255:	bf a9 7b             	mov    di,0x7ba9
    9258:	9a 16 04 75 92       	call   0x9275:0x416
    925d:	8b f8                	mov    di,ax
    925f:	c1 e7 02             	shl    di,0x2
    9262:	8b 8b 62 fe          	mov    cx,WORD PTR [bp+di-0x19e]
    9266:	8b 9b 64 fe          	mov    bx,WORD PTR [bp+di-0x19c]
    926a:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    926e:	99                   	cwd
    926f:	bf a9 7b             	mov    di,0x7ba9
    9272:	9a 16 04 8d 92       	call   0x928d:0x416
    9277:	8b f8                	mov    di,ax
    9279:	c1 e7 02             	shl    di,0x2
    927c:	8b 83 da fd          	mov    ax,WORD PTR [bp+di-0x226]
    9280:	8b 93 dc fd          	mov    dx,WORD PTR [bp+di-0x224]
    9284:	03 c1                	add    ax,cx
    9286:	13 d3                	adc    dx,bx
    9288:	71 05                	jno    0x928f
    928a:	9a 3e 04 be 92       	call   0x92be:0x43e
    928f:	89 86 7e fb          	mov    WORD PTR [bp-0x482],ax
    9293:	89 96 80 fb          	mov    WORD PTR [bp-0x480],dx
    9297:	9b db 86 7e fb       	fild   DWORD PTR [bp-0x482]
    929c:	83 ec 08             	sub    sp,0x8
    929f:	89 e3                	mov    bx,sp
    92a1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    92a5:	90                   	nop
    92a6:	9b                   	fwait
    92a7:	9a a7 2e dd 92       	call   0x92dd:0x2ea7
    92ac:	9b dd 9e 06 fc       	fstp   QWORD PTR [bp-0x3fa]
    92b1:	90                   	nop
    92b2:	9b                   	fwait
    92b3:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    92b7:	99                   	cwd
    92b8:	bf a9 7b             	mov    di,0x7ba9
    92bb:	9a 16 04 ea 92       	call   0x92ea:0x416
    92c0:	8b f8                	mov    di,ax
    92c2:	c1 e7 02             	shl    di,0x2
    92c5:	9b db 83 aa fc       	fild   DWORD PTR [bp+di-0x356]
    92ca:	9b dc 8e 06 fc       	fmul   QWORD PTR [bp-0x3fa]
    92cf:	83 ec 08             	sub    sp,0x8
    92d2:	89 e3                	mov    bx,sp
    92d4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    92d8:	90                   	nop
    92d9:	9b                   	fwait
    92da:	9a a6 2f 30 93       	call   0x9330:0x2fa6
    92df:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    92e3:	99                   	cwd
    92e4:	bf a9 7b             	mov    di,0x7ba9
    92e7:	9a 16 04 03 93       	call   0x9303:0x416
    92ec:	8b f8                	mov    di,ax
    92ee:	c1 e7 03             	shl    di,0x3
    92f1:	9b dd 9b 96 fc       	fstp   QWORD PTR [bp+di-0x36a]
    92f6:	90                   	nop
    92f7:	9b                   	fwait
    92f8:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    92fc:	99                   	cwd
    92fd:	bf a9 7b             	mov    di,0x7ba9
    9300:	9a 16 04 20 93       	call   0x9320:0x416
    9305:	8b f8                	mov    di,ax
    9307:	c1 e7 02             	shl    di,0x2
    930a:	9b db 83 72 fe       	fild   DWORD PTR [bp+di-0x18e]
    930f:	9b dc 4e b8          	fmul   QWORD PTR [bp-0x48]
    9313:	9b dc 8e de fe       	fmul   QWORD PTR [bp-0x122]
    9318:	9b df 86 82 fb       	fild   WORD PTR [bp-0x47e]
    931d:	9a b2 04 42 93       	call   0x9342:0x4b2
    9322:	83 ec 08             	sub    sp,0x8
    9325:	89 e3                	mov    bx,sp
    9327:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    932b:	90                   	nop
    932c:	9b                   	fwait
    932d:	9a a6 2f 83 93       	call   0x9383:0x2fa6
    9332:	9b db be 78 fb       	fstp   TBYTE PTR [bp-0x488]
    9337:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    933b:	99                   	cwd
    933c:	bf a9 7b             	mov    di,0x7ba9
    933f:	9a 16 04 59 93       	call   0x9359:0x416
    9344:	8b f8                	mov    di,ax
    9346:	c1 e7 02             	shl    di,0x2
    9349:	9b db 83 c2 fc       	fild   DWORD PTR [bp+di-0x33e]
    934e:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9352:	99                   	cwd
    9353:	bf a9 7b             	mov    di,0x7ba9
    9356:	9a 16 04 73 93       	call   0x9373:0x416
    935b:	8b f8                	mov    di,ax
    935d:	c1 e7 03             	shl    di,0x3
    9360:	9b dc 8b ae fe       	fmul   QWORD PTR [bp+di-0x152]
    9365:	9b dc 8e d6 fe       	fmul   QWORD PTR [bp-0x12a]
    936a:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9370:	9a b2 04 98 93       	call   0x9398:0x4b2
    9375:	83 ec 08             	sub    sp,0x8
    9378:	89 e3                	mov    bx,sp
    937a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    937e:	90                   	nop
    937f:	9b                   	fwait
    9380:	9a a6 2f e2 93       	call   0x93e2:0x2fa6
    9385:	9b db ae 78 fb       	fld    TBYTE PTR [bp-0x488]
    938a:	9b de c1             	faddp  st(1),st
    938d:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9391:	99                   	cwd
    9392:	bf a9 7b             	mov    di,0x7ba9
    9395:	9a 16 04 b1 93       	call   0x93b1:0x416
    939a:	8b f8                	mov    di,ax
    939c:	c1 e7 03             	shl    di,0x3
    939f:	9b dd 9b 56 fc       	fstp   QWORD PTR [bp+di-0x3aa]
    93a4:	90                   	nop
    93a5:	9b                   	fwait
    93a6:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    93aa:	99                   	cwd
    93ab:	bf a9 7b             	mov    di,0x7ba9
    93ae:	9a 16 04 c8 93       	call   0x93c8:0x416
    93b3:	8b f8                	mov    di,ax
    93b5:	c1 e7 02             	shl    di,0x2
    93b8:	9b db 83 c2 fc       	fild   DWORD PTR [bp+di-0x33e]
    93bd:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    93c1:	99                   	cwd
    93c2:	bf a9 7b             	mov    di,0x7ba9
    93c5:	9a 16 04 f4 93       	call   0x93f4:0x416
    93ca:	8b f8                	mov    di,ax
    93cc:	c1 e7 03             	shl    di,0x3
    93cf:	9b dc 8b ae fe       	fmul   QWORD PTR [bp+di-0x152]
    93d4:	83 ec 08             	sub    sp,0x8
    93d7:	89 e3                	mov    bx,sp
    93d9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    93dd:	90                   	nop
    93de:	9b                   	fwait
    93df:	9a a6 2f 25 94       	call   0x9425:0x2fa6
    93e4:	9b db be 78 fb       	fstp   TBYTE PTR [bp-0x488]
    93e9:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    93ed:	99                   	cwd
    93ee:	bf a9 7b             	mov    di,0x7ba9
    93f1:	9a 16 04 0b 94       	call   0x940b:0x416
    93f6:	8b f8                	mov    di,ax
    93f8:	c1 e7 02             	shl    di,0x2
    93fb:	9b db 83 ba fc       	fild   DWORD PTR [bp+di-0x346]
    9400:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9404:	99                   	cwd
    9405:	bf a9 7b             	mov    di,0x7ba9
    9408:	9a 16 04 3f 94       	call   0x943f:0x416
    940d:	8b f8                	mov    di,ax
    940f:	c1 e7 03             	shl    di,0x3
    9412:	9b dc 8b 1e ff       	fmul   QWORD PTR [bp+di-0xe2]
    9417:	83 ec 08             	sub    sp,0x8
    941a:	89 e3                	mov    bx,sp
    941c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    9420:	90                   	nop
    9421:	9b                   	fwait
    9422:	9a a6 2f 70 94       	call   0x9470:0x2fa6
    9427:	9b db ae 78 fb       	fld    TBYTE PTR [bp-0x488]
    942c:	9b de c1             	faddp  st(1),st
    942f:	9b db be 6e fb       	fstp   TBYTE PTR [bp-0x492]
    9434:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9438:	99                   	cwd
    9439:	bf a9 7b             	mov    di,0x7ba9
    943c:	9a 16 04 56 94       	call   0x9456:0x416
    9441:	8b f8                	mov    di,ax
    9443:	c1 e7 02             	shl    di,0x2
    9446:	9b db 83 b2 fc       	fild   DWORD PTR [bp+di-0x34e]
    944b:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    944f:	99                   	cwd
    9450:	bf a9 7b             	mov    di,0x7ba9
    9453:	9a 16 04 85 94       	call   0x9485:0x416
    9458:	8b f8                	mov    di,ax
    945a:	c1 e7 03             	shl    di,0x3
    945d:	9b dc 8b 4e fe       	fmul   QWORD PTR [bp+di-0x1b2]
    9462:	83 ec 08             	sub    sp,0x8
    9465:	89 e3                	mov    bx,sp
    9467:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    946b:	90                   	nop
    946c:	9b                   	fwait
    946d:	9a a6 2f df 94       	call   0x94df:0x2fa6
    9472:	9b db ae 6e fb       	fld    TBYTE PTR [bp-0x492]
    9477:	9b de c1             	faddp  st(1),st
    947a:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    947e:	99                   	cwd
    947f:	bf a9 7b             	mov    di,0x7ba9
    9482:	9a 16 04 a3 94       	call   0x94a3:0x416
    9487:	8b f8                	mov    di,ax
    9489:	c1 e7 03             	shl    di,0x3
    948c:	9b dd 9b b4 fb       	fstp   QWORD PTR [bp+di-0x44c]
    9491:	90                   	nop
    9492:	9b 9b dd 86 16 fc    	fld    QWORD PTR [bp-0x3ea]
    9498:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    949c:	99                   	cwd
    949d:	bf a9 7b             	mov    di,0x7ba9
    94a0:	9a 16 04 c1 94       	call   0x94c1:0x416
    94a5:	8b f8                	mov    di,ax
    94a7:	c1 e7 03             	shl    di,0x3
    94aa:	9b dc 83 b4 fb       	fadd   QWORD PTR [bp+di-0x44c]
    94af:	9b dd 9e 16 fc       	fstp   QWORD PTR [bp-0x3ea]
    94b4:	90                   	nop
    94b5:	9b                   	fwait
    94b6:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    94ba:	99                   	cwd
    94bb:	bf a9 7b             	mov    di,0x7ba9
    94be:	9a 16 04 f1 94       	call   0x94f1:0x416
    94c3:	8b f8                	mov    di,ax
    94c5:	c1 e7 02             	shl    di,0x2
    94c8:	9b db 83 da fd       	fild   DWORD PTR [bp+di-0x226]
    94cd:	9b dc 4e a8          	fmul   QWORD PTR [bp-0x58]
    94d1:	83 ec 08             	sub    sp,0x8
    94d4:	89 e3                	mov    bx,sp
    94d6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    94da:	90                   	nop
    94db:	9b                   	fwait
    94dc:	9a a6 2f 43 97       	call   0x9743:0x2fa6
    94e1:	9b dd 86 26 fc       	fld    QWORD PTR [bp-0x3da]
    94e6:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    94ea:	99                   	cwd
    94eb:	bf a9 7b             	mov    di,0x7ba9
    94ee:	9a 16 04 08 95       	call   0x9508:0x416
    94f3:	8b f8                	mov    di,ax
    94f5:	c1 e7 03             	shl    di,0x3
    94f8:	9b dc 83 76 fc       	fadd   QWORD PTR [bp+di-0x38a]
    94fd:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9501:	99                   	cwd
    9502:	bf a9 7b             	mov    di,0x7ba9
    9505:	9a 16 04 1f 95       	call   0x951f:0x416
    950a:	8b f8                	mov    di,ax
    950c:	c1 e7 03             	shl    di,0x3
    950f:	9b dc 83 66 fc       	fadd   QWORD PTR [bp+di-0x39a]
    9514:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9518:	99                   	cwd
    9519:	bf a9 7b             	mov    di,0x7ba9
    951c:	9a 16 04 36 95       	call   0x9536:0x416
    9521:	8b f8                	mov    di,ax
    9523:	c1 e7 03             	shl    di,0x3
    9526:	9b dc 83 86 fc       	fadd   QWORD PTR [bp+di-0x37a]
    952b:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    952f:	99                   	cwd
    9530:	bf a9 7b             	mov    di,0x7ba9
    9533:	9a 16 04 4d 95       	call   0x954d:0x416
    9538:	8b f8                	mov    di,ax
    953a:	c1 e7 03             	shl    di,0x3
    953d:	9b dc 83 9e fe       	fadd   QWORD PTR [bp+di-0x162]
    9542:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9546:	99                   	cwd
    9547:	bf a9 7b             	mov    di,0x7ba9
    954a:	9a 16 04 64 95       	call   0x9564:0x416
    954f:	8b f8                	mov    di,ax
    9551:	c1 e7 03             	shl    di,0x3
    9554:	9b dc 83 8e fe       	fadd   QWORD PTR [bp+di-0x172]
    9559:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    955d:	99                   	cwd
    955e:	bf a9 7b             	mov    di,0x7ba9
    9561:	9a 16 04 7b 95       	call   0x957b:0x416
    9566:	8b f8                	mov    di,ax
    9568:	c1 e7 03             	shl    di,0x3
    956b:	9b dc 83 7e fe       	fadd   QWORD PTR [bp+di-0x182]
    9570:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9574:	99                   	cwd
    9575:	bf a9 7b             	mov    di,0x7ba9
    9578:	9a 16 04 a1 95       	call   0x95a1:0x416
    957d:	8b f8                	mov    di,ax
    957f:	c1 e7 03             	shl    di,0x3
    9582:	9b dc 83 56 fc       	fadd   QWORD PTR [bp+di-0x3aa]
    9587:	9b de c1             	faddp  st(1),st
    958a:	9b dd 9e 26 fc       	fstp   QWORD PTR [bp-0x3da]
    958f:	90                   	nop
    9590:	9b 9b dd 86 1e fc    	fld    QWORD PTR [bp-0x3e2]
    9596:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    959a:	99                   	cwd
    959b:	bf a9 7b             	mov    di,0x7ba9
    959e:	9a 16 04 b8 95       	call   0x95b8:0x416
    95a3:	8b f8                	mov    di,ax
    95a5:	c1 e7 03             	shl    di,0x3
    95a8:	9b dc 83 96 fc       	fadd   QWORD PTR [bp+di-0x36a]
    95ad:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    95b1:	99                   	cwd
    95b2:	bf a9 7b             	mov    di,0x7ba9
    95b5:	9a 16 04 cf 95       	call   0x95cf:0x416
    95ba:	8b f8                	mov    di,ax
    95bc:	c1 e7 03             	shl    di,0x3
    95bf:	9b dc a3 c6 fd       	fsub   QWORD PTR [bp+di-0x23a]
    95c4:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    95c8:	99                   	cwd
    95c9:	bf a9 7b             	mov    di,0x7ba9
    95cc:	9a 16 04 1b 96       	call   0x961b:0x416
    95d1:	8b f8                	mov    di,ax
    95d3:	c1 e7 03             	shl    di,0x3
    95d6:	9b dc 83 b4 fb       	fadd   QWORD PTR [bp+di-0x44c]
    95db:	9b dd 9e 1e fc       	fstp   QWORD PTR [bp-0x3e2]
    95e0:	90                   	nop
    95e1:	9b                   	fwait
    95e2:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    95e7:	74 03                	je     0x95ec
    95e9:	e9 d4 f9             	jmp    0x8fc0
    95ec:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    95f2:	9b dd 9e e6 fc       	fstp   QWORD PTR [bp-0x31a]
    95f7:	90                   	nop
    95f8:	9b                   	fwait
    95f9:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    95ff:	9b dd 9e de fc       	fstp   QWORD PTR [bp-0x322]
    9604:	90                   	nop
    9605:	9b                   	fwait
    9606:	8b 86 ee fd          	mov    ax,WORD PTR [bp-0x212]
    960a:	8b 96 f0 fd          	mov    dx,WORD PTR [bp-0x210]
    960e:	2b 86 fe fc          	sub    ax,WORD PTR [bp-0x302]
    9612:	1b 96 00 fd          	sbb    dx,WORD PTR [bp-0x300]
    9616:	71 05                	jno    0x961d
    9618:	9a 3e 04 93 96       	call   0x9693:0x43e
    961d:	89 86 7e fb          	mov    WORD PTR [bp-0x482],ax
    9621:	89 96 80 fb          	mov    WORD PTR [bp-0x480],dx
    9625:	9b db 86 7e fb       	fild   DWORD PTR [bp-0x482]
    962a:	9b dd 9e a4 fb       	fstp   QWORD PTR [bp-0x45c]
    962f:	90                   	nop
    9630:	9b 9b dd 86 a4 fb    	fld    QWORD PTR [bp-0x45c]
    9636:	9b dc 4e c0          	fmul   QWORD PTR [bp-0x40]
    963a:	9b dd 9e 9c fb       	fstp   QWORD PTR [bp-0x464]
    963f:	90                   	nop
    9640:	9b 9b dd 86 a4 fb    	fld    QWORD PTR [bp-0x45c]
    9646:	9b 2e d8 1e ae 7b    	fcomp  DWORD PTR cs:0x7bae
    964c:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    9651:	90                   	nop
    9652:	9b                   	fwait
    9653:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    9657:	9e                   	sahf
    9658:	76 13                	jbe    0x966d
    965a:	9b dd 86 e6 fc       	fld    QWORD PTR [bp-0x31a]
    965f:	9b dc 86 9c fb       	fadd   QWORD PTR [bp-0x464]
    9664:	9b dd 9e e6 fc       	fstp   QWORD PTR [bp-0x31a]
    9669:	90                   	nop
    966a:	9b                   	fwait
    966b:	eb 11                	jmp    0x967e
    966d:	9b dd 86 de fc       	fld    QWORD PTR [bp-0x322]
    9672:	9b dc a6 9c fb       	fsub   QWORD PTR [bp-0x464]
    9677:	9b dd 9e de fc       	fstp   QWORD PTR [bp-0x322]
    967c:	90                   	nop
    967d:	9b                   	fwait
    967e:	8b 86 ea fd          	mov    ax,WORD PTR [bp-0x216]
    9682:	8b 96 ec fd          	mov    dx,WORD PTR [bp-0x214]
    9686:	2b 86 fa fc          	sub    ax,WORD PTR [bp-0x306]
    968a:	1b 96 fc fc          	sbb    dx,WORD PTR [bp-0x304]
    968e:	71 05                	jno    0x9695
    9690:	9a 3e 04 33 97       	call   0x9733:0x43e
    9695:	89 86 7e fb          	mov    WORD PTR [bp-0x482],ax
    9699:	89 96 80 fb          	mov    WORD PTR [bp-0x480],dx
    969d:	9b db 86 7e fb       	fild   DWORD PTR [bp-0x482]
    96a2:	9b dd 9e a4 fb       	fstp   QWORD PTR [bp-0x45c]
    96a7:	90                   	nop
    96a8:	9b 9b dd 86 a4 fb    	fld    QWORD PTR [bp-0x45c]
    96ae:	9b dc 4e b8          	fmul   QWORD PTR [bp-0x48]
    96b2:	9b dd 9e 9c fb       	fstp   QWORD PTR [bp-0x464]
    96b7:	90                   	nop
    96b8:	9b 9b dd 86 a4 fb    	fld    QWORD PTR [bp-0x45c]
    96be:	9b 2e d8 1e ae 7b    	fcomp  DWORD PTR cs:0x7bae
    96c4:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    96c9:	90                   	nop
    96ca:	9b                   	fwait
    96cb:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    96cf:	9e                   	sahf
    96d0:	76 13                	jbe    0x96e5
    96d2:	9b dd 86 e6 fc       	fld    QWORD PTR [bp-0x31a]
    96d7:	9b dc 86 9c fb       	fadd   QWORD PTR [bp-0x464]
    96dc:	9b dd 9e e6 fc       	fstp   QWORD PTR [bp-0x31a]
    96e1:	90                   	nop
    96e2:	9b                   	fwait
    96e3:	eb 11                	jmp    0x96f6
    96e5:	9b dd 86 de fc       	fld    QWORD PTR [bp-0x322]
    96ea:	9b dc a6 9c fb       	fsub   QWORD PTR [bp-0x464]
    96ef:	9b dd 9e de fc       	fstp   QWORD PTR [bp-0x322]
    96f4:	90                   	nop
    96f5:	9b 9b db 86 e6 fe    	fild   DWORD PTR [bp-0x11a]
    96fb:	9b dc 4e b0          	fmul   QWORD PTR [bp-0x50]
    96ff:	9b dc 86 e6 fc       	fadd   QWORD PTR [bp-0x31a]
    9704:	9b dd 9e e6 fc       	fstp   QWORD PTR [bp-0x31a]
    9709:	90                   	nop
    970a:	9b 9b db 86 ea fe    	fild   DWORD PTR [bp-0x116]
    9710:	9b dc 4e b0          	fmul   QWORD PTR [bp-0x50]
    9714:	9b dc 86 de fc       	fadd   QWORD PTR [bp-0x322]
    9719:	9b dd 9e de fc       	fstp   QWORD PTR [bp-0x322]
    971e:	90                   	nop
    971f:	9b 9b dd 86 e6 fc    	fld    QWORD PTR [bp-0x31a]
    9725:	9b dc 8e 70 ff       	fmul   QWORD PTR [bp-0x90]
    972a:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9730:	9a b2 04 5f 97       	call   0x975f:0x4b2
    9735:	83 ec 08             	sub    sp,0x8
    9738:	89 e3                	mov    bx,sp
    973a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    973e:	90                   	nop
    973f:	9b                   	fwait
    9740:	9a a6 2f 6f 97       	call   0x976f:0x2fa6
    9745:	9b dd 9e e6 fc       	fstp   QWORD PTR [bp-0x31a]
    974a:	90                   	nop
    974b:	9b 9b dd 86 de fc    	fld    QWORD PTR [bp-0x322]
    9751:	9b dc 8e 68 ff       	fmul   QWORD PTR [bp-0x98]
    9756:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    975c:	9a b2 04 8f 97       	call   0x978f:0x4b2
    9761:	83 ec 08             	sub    sp,0x8
    9764:	89 e3                	mov    bx,sp
    9766:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    976a:	90                   	nop
    976b:	9b                   	fwait
    976c:	9a a6 2f 9f 97       	call   0x979f:0x2fa6
    9771:	9b dd 9e de fc       	fstp   QWORD PTR [bp-0x322]
    9776:	90                   	nop
    9777:	9b 9b db 86 f6 fc    	fild   DWORD PTR [bp-0x30a]
    977d:	9b dc 4e b0          	fmul   QWORD PTR [bp-0x50]
    9781:	9b dc 8e de fe       	fmul   QWORD PTR [bp-0x122]
    9786:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    978c:	9a b2 04 cf 97       	call   0x97cf:0x4b2
    9791:	83 ec 08             	sub    sp,0x8
    9794:	89 e3                	mov    bx,sp
    9796:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    979a:	90                   	nop
    979b:	9b                   	fwait
    979c:	9a a6 2f df 97       	call   0x97df:0x2fa6
    97a1:	9b dd 9e ee fc       	fstp   QWORD PTR [bp-0x312]
    97a6:	90                   	nop
    97a7:	9b 9b dd 86 6e fc    	fld    QWORD PTR [bp-0x392]
    97ad:	9b dc 86 76 fc       	fadd   QWORD PTR [bp-0x38a]
    97b2:	9b dc 86 5e fc       	fadd   QWORD PTR [bp-0x3a2]
    97b7:	9b dc 86 66 fc       	fadd   QWORD PTR [bp-0x39a]
    97bc:	9b dc 86 ee fc       	fadd   QWORD PTR [bp-0x312]
    97c1:	9b dc 8e ce fe       	fmul   QWORD PTR [bp-0x132]
    97c6:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    97cc:	9a b2 04 31 98       	call   0x9831:0x4b2
    97d1:	83 ec 08             	sub    sp,0x8
    97d4:	89 e3                	mov    bx,sp
    97d6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    97da:	90                   	nop
    97db:	9b                   	fwait
    97dc:	9a a6 2f 2c 98       	call   0x982c:0x2fa6
    97e1:	9b dd 9e d6 fc       	fstp   QWORD PTR [bp-0x32a]
    97e6:	90                   	nop
    97e7:	9b                   	fwait
    97e8:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    97ed:	7d 0e                	jge    0x97fd
    97ef:	9b dd 46 90          	fld    QWORD PTR [bp-0x70]
    97f3:	9b dd 9e 26 fd       	fstp   QWORD PTR [bp-0x2da]
    97f8:	90                   	nop
    97f9:	9b                   	fwait
    97fa:	e9 b5 00             	jmp    0x98b2
    97fd:	9b db 86 fa fd       	fild   DWORD PTR [bp-0x206]
    9802:	9b dc 4e a0          	fmul   QWORD PTR [bp-0x60]
    9806:	9b dd 9e 94 fb       	fstp   QWORD PTR [bp-0x46c]
    980b:	90                   	nop
    980c:	9b                   	fwait
    980d:	ff b6 9a fb          	push   WORD PTR [bp-0x466]
    9811:	ff b6 98 fb          	push   WORD PTR [bp-0x468]
    9815:	ff b6 96 fb          	push   WORD PTR [bp-0x46a]
    9819:	ff b6 94 fb          	push   WORD PTR [bp-0x46c]
    981d:	ff 76 8e             	push   WORD PTR [bp-0x72]
    9820:	ff 76 8c             	push   WORD PTR [bp-0x74]
    9823:	ff 76 8a             	push   WORD PTR [bp-0x76]
    9826:	ff 76 88             	push   WORD PTR [bp-0x78]
    9829:	9a a7 2e a5 98       	call   0x98a5:0x2ea7
    982e:	9a 41 10 e6 98       	call   0x98e6:0x1041
    9833:	9b dd 9e 8c fb       	fstp   QWORD PTR [bp-0x474]
    9838:	90                   	nop
    9839:	9b 9b dd 86 8c fb    	fld    QWORD PTR [bp-0x474]
    983f:	9b dc 4e 88          	fmul   QWORD PTR [bp-0x78]
    9843:	9b dc 9e 94 fb       	fcomp  QWORD PTR [bp-0x46c]
    9848:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    984d:	90                   	nop
    984e:	9b                   	fwait
    984f:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    9853:	9e                   	sahf
    9854:	75 12                	jne    0x9868
    9856:	9b dd 86 8c fb       	fld    QWORD PTR [bp-0x474]
    985b:	9b 2e d8 26 b9 7b    	fsub   DWORD PTR cs:0x7bb9
    9861:	9b dd 9e 8c fb       	fstp   QWORD PTR [bp-0x474]
    9866:	90                   	nop
    9867:	9b 9b dd 86 8c fb    	fld    QWORD PTR [bp-0x474]
    986d:	9b 2e d8 1e ae 7b    	fcomp  DWORD PTR cs:0x7bae
    9873:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    9878:	90                   	nop
    9879:	9b                   	fwait
    987a:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    987e:	9e                   	sahf
    987f:	73 0d                	jae    0x988e
    9881:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    9887:	9b dd 9e 8c fb       	fstp   QWORD PTR [bp-0x474]
    988c:	90                   	nop
    988d:	9b 9b dd 86 8c fb    	fld    QWORD PTR [bp-0x474]
    9893:	9b dc 4e 80          	fmul   QWORD PTR [bp-0x80]
    9897:	83 ec 08             	sub    sp,0x8
    989a:	89 e3                	mov    bx,sp
    989c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    98a0:	90                   	nop
    98a1:	9b                   	fwait
    98a2:	9a a6 2f cf 98       	call   0x98cf:0x2fa6
    98a7:	9b dc 46 90          	fadd   QWORD PTR [bp-0x70]
    98ab:	9b dd 9e 26 fd       	fstp   QWORD PTR [bp-0x2da]
    98b0:	90                   	nop
    98b1:	9b 9b db 86 fa fd    	fild   DWORD PTR [bp-0x206]
    98b7:	9b dc 8e 4e ff       	fmul   QWORD PTR [bp-0xb2]
    98bc:	9b dc 8e 46 ff       	fmul   QWORD PTR [bp-0xba]
    98c1:	83 ec 08             	sub    sp,0x8
    98c4:	89 e3                	mov    bx,sp
    98c6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    98ca:	90                   	nop
    98cb:	9b                   	fwait
    98cc:	9a a6 2f 02 99       	call   0x9902:0x2fa6
    98d1:	9b dd 9e 1e fd       	fstp   QWORD PTR [bp-0x2e2]
    98d6:	90                   	nop
    98d7:	9b 9b dd 86 16 ff    	fld    QWORD PTR [bp-0xea]
    98dd:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    98e3:	9a b2 04 20 99       	call   0x9920:0x4b2
    98e8:	9b db 86 fa fd       	fild   DWORD PTR [bp-0x206]
    98ed:	9b de c9             	fmulp  st(1),st
    98f0:	9b dc 4e a0          	fmul   QWORD PTR [bp-0x60]
    98f4:	83 ec 08             	sub    sp,0x8
    98f7:	89 e3                	mov    bx,sp
    98f9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    98fd:	90                   	nop
    98fe:	9b                   	fwait
    98ff:	9a a6 2f 51 99       	call   0x9951:0x2fa6
    9904:	9b dd 9e 16 fd       	fstp   QWORD PTR [bp-0x2ea]
    9909:	90                   	nop
    990a:	9b                   	fwait
    990b:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    990f:	8b 96 fc fd          	mov    dx,WORD PTR [bp-0x204]
    9913:	03 86 22 ff          	add    ax,WORD PTR [bp-0xde]
    9917:	13 96 24 ff          	adc    dx,WORD PTR [bp-0xdc]
    991b:	71 05                	jno    0x9922
    991d:	9a 3e 04 41 99       	call   0x9941:0x43e
    9922:	89 86 7e fb          	mov    WORD PTR [bp-0x482],ax
    9926:	89 96 80 fb          	mov    WORD PTR [bp-0x480],dx
    992a:	9b db 86 7e fb       	fild   DWORD PTR [bp-0x482]
    992f:	9b dc 4e a0          	fmul   QWORD PTR [bp-0x60]
    9933:	9b dc 8e 78 ff       	fmul   QWORD PTR [bp-0x88]
    9938:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    993e:	9a b2 04 80 99       	call   0x9980:0x4b2
    9943:	83 ec 08             	sub    sp,0x8
    9946:	89 e3                	mov    bx,sp
    9948:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    994c:	90                   	nop
    994d:	9b                   	fwait
    994e:	9a a6 2f 90 99       	call   0x9990:0x2fa6
    9953:	9b dd 9e 0e fd       	fstp   QWORD PTR [bp-0x2f2]
    9958:	90                   	nop
    9959:	9b                   	fwait
    995a:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    9960:	9b dd 9e 06 fd       	fstp   QWORD PTR [bp-0x2fa]
    9965:	90                   	nop
    9966:	9b 9b dd 86 1e fd    	fld    QWORD PTR [bp-0x2e2]
    996c:	9b 2e d8 0e bd 7b    	fmul   DWORD PTR cs:0x7bbd
    9972:	9b dc 8e 78 ff       	fmul   QWORD PTR [bp-0x88]
    9977:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    997d:	9a b2 04 af 99       	call   0x99af:0x4b2
    9982:	83 ec 08             	sub    sp,0x8
    9985:	89 e3                	mov    bx,sp
    9987:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    998b:	90                   	nop
    998c:	9b                   	fwait
    998d:	9a a6 2f bf 99       	call   0x99bf:0x2fa6
    9992:	9b dc 86 06 fd       	fadd   QWORD PTR [bp-0x2fa]
    9997:	9b dd 9e 06 fd       	fstp   QWORD PTR [bp-0x2fa]
    999c:	90                   	nop
    999d:	9b 9b dd 86 0e fe    	fld    QWORD PTR [bp-0x1f2]
    99a3:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    99a7:	9b df 86 82 fb       	fild   WORD PTR [bp-0x47e]
    99ac:	9a b2 04 0d 9a       	call   0x9a0d:0x4b2
    99b1:	83 ec 08             	sub    sp,0x8
    99b4:	89 e3                	mov    bx,sp
    99b6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    99ba:	90                   	nop
    99bb:	9b                   	fwait
    99bc:	9a a6 2f 1d 9a       	call   0x9a1d:0x2fa6
    99c1:	9b dd 86 26 fc       	fld    QWORD PTR [bp-0x3da]
    99c6:	9b dc 86 ee fc       	fadd   QWORD PTR [bp-0x312]
    99cb:	9b dc 86 e6 fc       	fadd   QWORD PTR [bp-0x31a]
    99d0:	9b dc 86 de fc       	fadd   QWORD PTR [bp-0x322]
    99d5:	9b dc 86 d6 fc       	fadd   QWORD PTR [bp-0x32a]
    99da:	9b dc 86 26 fd       	fadd   QWORD PTR [bp-0x2da]
    99df:	9b dc 86 1e fd       	fadd   QWORD PTR [bp-0x2e2]
    99e4:	9b dc 86 16 fd       	fadd   QWORD PTR [bp-0x2ea]
    99e9:	9b dc 86 0e fd       	fadd   QWORD PTR [bp-0x2f2]
    99ee:	9b dc 86 c6 fe       	fadd   QWORD PTR [bp-0x13a]
    99f3:	9b de c1             	faddp  st(1),st
    99f6:	9b db be 78 fb       	fstp   TBYTE PTR [bp-0x488]
    99fb:	9b dd 86 06 fe       	fld    QWORD PTR [bp-0x1fa]
    9a00:	9b dc 4e e8          	fmul   QWORD PTR [bp-0x18]
    9a04:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9a0a:	9a b2 04 3e 9a       	call   0x9a3e:0x4b2
    9a0f:	83 ec 08             	sub    sp,0x8
    9a12:	89 e3                	mov    bx,sp
    9a14:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    9a18:	90                   	nop
    9a19:	9b                   	fwait
    9a1a:	9a a6 2f 4e 9a       	call   0x9a4e:0x2fa6
    9a1f:	9b db ae 78 fb       	fld    TBYTE PTR [bp-0x488]
    9a24:	9b de c1             	faddp  st(1),st
    9a27:	9b db be 6e fb       	fstp   TBYTE PTR [bp-0x492]
    9a2c:	9b dd 86 fe fd       	fld    QWORD PTR [bp-0x202]
    9a31:	9b dc 4e e0          	fmul   QWORD PTR [bp-0x20]
    9a35:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9a3b:	9a b2 04 71 9a       	call   0x9a71:0x4b2
    9a40:	83 ec 08             	sub    sp,0x8
    9a43:	89 e3                	mov    bx,sp
    9a45:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    9a49:	90                   	nop
    9a4a:	9b                   	fwait
    9a4b:	9a a6 2f 81 9a       	call   0x9a81:0x2fa6
    9a50:	9b db ae 6e fb       	fld    TBYTE PTR [bp-0x492]
    9a55:	9b de c1             	faddp  st(1),st
    9a58:	9b dd 9e 26 fc       	fstp   QWORD PTR [bp-0x3da]
    9a5d:	90                   	nop
    9a5e:	9b 9b dd 86 16 fe    	fld    QWORD PTR [bp-0x1ea]
    9a64:	9b dc 4e d8          	fmul   QWORD PTR [bp-0x28]
    9a68:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9a6e:	9a b2 04 33 9b       	call   0x9b33:0x4b2
    9a73:	83 ec 08             	sub    sp,0x8
    9a76:	89 e3                	mov    bx,sp
    9a78:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    9a7c:	90                   	nop
    9a7d:	9b                   	fwait
    9a7e:	9a a6 2f 00 9e       	call   0x9e00:0x2fa6
    9a83:	9b dd 86 1e fc       	fld    QWORD PTR [bp-0x3e2]
    9a88:	9b dc 86 f6 fe       	fadd   QWORD PTR [bp-0x10a]
    9a8d:	9b de c1             	faddp  st(1),st
    9a90:	9b dc 86 06 fd       	fadd   QWORD PTR [bp-0x2fa]
    9a95:	9b dd 9e 1e fc       	fstp   QWORD PTR [bp-0x3e2]
    9a9a:	90                   	nop
    9a9b:	9b 9b dd 86 ee fe    	fld    QWORD PTR [bp-0x112]
    9aa1:	9b 2e d8 1e ae 7b    	fcomp  DWORD PTR cs:0x7bae
    9aa7:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    9aac:	90                   	nop
    9aad:	9b                   	fwait
    9aae:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    9ab2:	9e                   	sahf
    9ab3:	76 13                	jbe    0x9ac8
    9ab5:	9b dd 86 1e fc       	fld    QWORD PTR [bp-0x3e2]
    9aba:	9b dc 86 ee fe       	fadd   QWORD PTR [bp-0x112]
    9abf:	9b dd 9e 1e fc       	fstp   QWORD PTR [bp-0x3e2]
    9ac4:	90                   	nop
    9ac5:	9b                   	fwait
    9ac6:	eb 11                	jmp    0x9ad9
    9ac8:	9b dd 86 26 fc       	fld    QWORD PTR [bp-0x3da]
    9acd:	9b dc a6 ee fe       	fsub   QWORD PTR [bp-0x112]
    9ad2:	9b dd 9e 26 fc       	fstp   QWORD PTR [bp-0x3da]
    9ad7:	90                   	nop
    9ad8:	9b 9b dd 86 1e fc    	fld    QWORD PTR [bp-0x3e2]
    9ade:	9b dc a6 26 fc       	fsub   QWORD PTR [bp-0x3da]
    9ae3:	9b dd 9e fe fb       	fstp   QWORD PTR [bp-0x402]
    9ae8:	90                   	nop
    9ae9:	9b                   	fwait
    9aea:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9aed:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9af0:	ff b6 04 fc          	push   WORD PTR [bp-0x3fc]
    9af4:	ff b6 02 fc          	push   WORD PTR [bp-0x3fe]
    9af8:	ff b6 00 fc          	push   WORD PTR [bp-0x400]
    9afc:	ff b6 fe fb          	push   WORD PTR [bp-0x402]
    9b00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b03:	06                   	push   es
    9b04:	57                   	push   di
    9b05:	9a 25 59 48 9b       	call   0x9b48:0x5925
    9b0a:	9b dd 9e 8e fd       	fstp   QWORD PTR [bp-0x272]
    9b0f:	90                   	nop
    9b10:	9b                   	fwait
    9b11:	83 3e 06 1e 04       	cmp    WORD PTR ds:0x1e06,0x4
    9b16:	7d 03                	jge    0x9b1b
    9b18:	e9 9a 00             	jmp    0x9bb5
    9b1b:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9b21:	9b dc 46 c8          	fadd   QWORD PTR [bp-0x38]
    9b25:	9b dc 8e 16 fc       	fmul   QWORD PTR [bp-0x3ea]
    9b2a:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9b30:	9a b2 04 e5 9b       	call   0x9be5:0x4b2
    9b35:	83 ec 08             	sub    sp,0x8
    9b38:	89 e3                	mov    bx,sp
    9b3a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    9b3e:	90                   	nop
    9b3f:	9b                   	fwait
    9b40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b43:	06                   	push   es
    9b44:	57                   	push   di
    9b45:	9a d2 5d 9a 9b       	call   0x9b9a:0x5dd2
    9b4a:	9b dd 9e 86 fd       	fstp   QWORD PTR [bp-0x27a]
    9b4f:	90                   	nop
    9b50:	9b 9b dd 86 8e fd    	fld    QWORD PTR [bp-0x272]
    9b56:	9b dc 9e 86 fd       	fcomp  QWORD PTR [bp-0x27a]
    9b5b:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    9b60:	90                   	nop
    9b61:	9b                   	fwait
    9b62:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    9b66:	9e                   	sahf
    9b67:	77 0e                	ja     0x9b77
    9b69:	9b dd 86 86 fd       	fld    QWORD PTR [bp-0x27a]
    9b6e:	9b dd 9e 8e fd       	fstp   QWORD PTR [bp-0x272]
    9b73:	90                   	nop
    9b74:	9b                   	fwait
    9b75:	eb 3e                	jmp    0x9bb5
    9b77:	ff 76 0c             	push   WORD PTR [bp+0xc]
    9b7a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    9b7d:	9b dd 86 8e fd       	fld    QWORD PTR [bp-0x272]
    9b82:	9b dc a6 86 fd       	fsub   QWORD PTR [bp-0x27a]
    9b87:	83 ec 08             	sub    sp,0x8
    9b8a:	89 e3                	mov    bx,sp
    9b8c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    9b90:	90                   	nop
    9b91:	9b                   	fwait
    9b92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    9b95:	06                   	push   es
    9b96:	57                   	push   di
    9b97:	9a 64 62 9b a2       	call   0xa29b:0x6264
    9b9c:	9b dc ae 8e fd       	fsubr  QWORD PTR [bp-0x272]
    9ba1:	9b dd 9e 8e fd       	fstp   QWORD PTR [bp-0x272]
    9ba6:	90                   	nop
    9ba7:	9b                   	fwait
    9ba8:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    9bae:	9b dd 9e 86 fd       	fstp   QWORD PTR [bp-0x27a]
    9bb3:	90                   	nop
    9bb4:	9b 9b dd 86 fe fb    	fld    QWORD PTR [bp-0x402]
    9bba:	9b dc a6 8e fd       	fsub   QWORD PTR [bp-0x272]
    9bbf:	9b dd 9e a6 fd       	fstp   QWORD PTR [bp-0x25a]
    9bc4:	90                   	nop
    9bc5:	9b 9b dd 86 3e fc    	fld    QWORD PTR [bp-0x3c2]
    9bcb:	9b dc 86 a6 fd       	fadd   QWORD PTR [bp-0x25a]
    9bd0:	9b dd 9e 96 fd       	fstp   QWORD PTR [bp-0x26a]
    9bd5:	90                   	nop
    9bd6:	9b 9b dd 86 4e fe    	fld    QWORD PTR [bp-0x1b2]
    9bdc:	9b 2e d9 06 c1 7b    	fld    DWORD PTR cs:0x7bc1
    9be2:	9a b2 04 1b 9c       	call   0x9c1b:0x4b2
    9be7:	9b dd 9e 8c fb       	fstp   QWORD PTR [bp-0x474]
    9bec:	90                   	nop
    9bed:	9b 9b dd 86 3e fe    	fld    QWORD PTR [bp-0x1c2]
    9bf3:	9b 2e d8 1e ae 7b    	fcomp  DWORD PTR cs:0x7bae
    9bf9:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    9bfe:	90                   	nop
    9bff:	9b                   	fwait
    9c00:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    9c04:	9e                   	sahf
    9c05:	72 65                	jb     0x9c6c
    9c07:	9b dd 86 3e fe       	fld    QWORD PTR [bp-0x1c2]
    9c0c:	9b 2e d8 0e c5 7b    	fmul   DWORD PTR cs:0x7bc5
    9c12:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9c18:	9a b2 04 61 9c       	call   0x9c61:0x4b2
    9c1d:	9b dc 86 46 fe       	fadd   QWORD PTR [bp-0x1ba]
    9c22:	9b dc 9e 8c fb       	fcomp  QWORD PTR [bp-0x474]
    9c27:	9b dd be 7e fb       	fstsw  WORD PTR [bp-0x482]
    9c2c:	90                   	nop
    9c2d:	9b                   	fwait
    9c2e:	8a a6 7f fb          	mov    ah,BYTE PTR [bp-0x481]
    9c32:	9e                   	sahf
    9c33:	72 18                	jb     0x9c4d
    9c35:	9b dd 86 46 fe       	fld    QWORD PTR [bp-0x1ba]
    9c3a:	9b dc 86 3e fe       	fadd   QWORD PTR [bp-0x1c2]
    9c3f:	9b dc a6 8c fb       	fsub   QWORD PTR [bp-0x474]
    9c44:	9b dd 9e f6 fb       	fstp   QWORD PTR [bp-0x40a]
    9c49:	90                   	nop
    9c4a:	9b                   	fwait
    9c4b:	eb 1d                	jmp    0x9c6a
    9c4d:	9b dd 86 3e fe       	fld    QWORD PTR [bp-0x1c2]
    9c52:	9b 2e d8 0e c9 7b    	fmul   DWORD PTR cs:0x7bc9
    9c58:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9c5e:	9a b2 04 ce 9c       	call   0x9cce:0x4b2
    9c63:	9b dd 9e f6 fb       	fstp   QWORD PTR [bp-0x40a]
    9c68:	90                   	nop
    9c69:	9b                   	fwait
    9c6a:	eb 42                	jmp    0x9cae
    9c6c:	9b dd 86 46 fe       	fld    QWORD PTR [bp-0x1ba]
    9c71:	9b dc 86 3e fe       	fadd   QWORD PTR [bp-0x1c2]
    9c76:	9b dc 9e 8c fb       	fcomp  QWORD PTR [bp-0x474]
    9c7b:	9b dd be 7e fb       	fstsw  WORD PTR [bp-0x482]
    9c80:	90                   	nop
    9c81:	9b                   	fwait
    9c82:	8a a6 7f fb          	mov    ah,BYTE PTR [bp-0x481]
    9c86:	9e                   	sahf
    9c87:	72 18                	jb     0x9ca1
    9c89:	9b dd 86 46 fe       	fld    QWORD PTR [bp-0x1ba]
    9c8e:	9b dc 86 3e fe       	fadd   QWORD PTR [bp-0x1c2]
    9c93:	9b dc a6 8c fb       	fsub   QWORD PTR [bp-0x474]
    9c98:	9b dd 9e f6 fb       	fstp   QWORD PTR [bp-0x40a]
    9c9d:	90                   	nop
    9c9e:	9b                   	fwait
    9c9f:	eb 0d                	jmp    0x9cae
    9ca1:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    9ca7:	9b dd 9e f6 fb       	fstp   QWORD PTR [bp-0x40a]
    9cac:	90                   	nop
    9cad:	9b 9b dd 86 06 ff    	fld    QWORD PTR [bp-0xfa]
    9cb3:	9b dc 9e f6 fb       	fcomp  QWORD PTR [bp-0x40a]
    9cb8:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    9cbd:	90                   	nop
    9cbe:	9b                   	fwait
    9cbf:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    9cc3:	9e                   	sahf
    9cc4:	76 13                	jbe    0x9cd9
    9cc6:	9b dd 86 f6 fb       	fld    QWORD PTR [bp-0x40a]
    9ccb:	9a 41 10 7d 9d       	call   0x9d7d:0x1041
    9cd0:	9b dd 9e ce fc       	fstp   QWORD PTR [bp-0x332]
    9cd5:	90                   	nop
    9cd6:	9b                   	fwait
    9cd7:	eb 0c                	jmp    0x9ce5
    9cd9:	9b dd 86 06 ff       	fld    QWORD PTR [bp-0xfa]
    9cde:	9b dd 9e ce fc       	fstp   QWORD PTR [bp-0x332]
    9ce3:	90                   	nop
    9ce4:	9b 9b dd 86 46 fe    	fld    QWORD PTR [bp-0x1ba]
    9cea:	9b dc 86 3e fe       	fadd   QWORD PTR [bp-0x1c2]
    9cef:	9b dc a6 ce fc       	fsub   QWORD PTR [bp-0x332]
    9cf4:	9b dd 9e ae fd       	fstp   QWORD PTR [bp-0x252]
    9cf9:	90                   	nop
    9cfa:	9b 9b dd 86 4e fe    	fld    QWORD PTR [bp-0x1b2]
    9d00:	9b dd 9e b6 fd       	fstp   QWORD PTR [bp-0x24a]
    9d05:	90                   	nop
    9d06:	9b 9b dd 86 0e ff    	fld    QWORD PTR [bp-0xf2]
    9d0c:	9b 2e d8 1e ae 7b    	fcomp  DWORD PTR cs:0x7bae
    9d12:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    9d17:	90                   	nop
    9d18:	9b                   	fwait
    9d19:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    9d1d:	9e                   	sahf
    9d1e:	74 23                	je     0x9d43
    9d20:	9b dd 86 b6 fd       	fld    QWORD PTR [bp-0x24a]
    9d25:	9b dc 86 0e ff       	fadd   QWORD PTR [bp-0xf2]
    9d2a:	9b dc 86 ae fd       	fadd   QWORD PTR [bp-0x252]
    9d2f:	9b dd 9e b6 fd       	fstp   QWORD PTR [bp-0x24a]
    9d34:	90                   	nop
    9d35:	9b                   	fwait
    9d36:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    9d3c:	9b dd 9e ae fd       	fstp   QWORD PTR [bp-0x252]
    9d41:	90                   	nop
    9d42:	9b 9b dd 86 b6 fd    	fld    QWORD PTR [bp-0x24a]
    9d48:	9b dc 86 ae fd       	fadd   QWORD PTR [bp-0x252]
    9d4d:	9b dc 86 a6 fd       	fadd   QWORD PTR [bp-0x25a]
    9d52:	9b dd 9e 9e fd       	fstp   QWORD PTR [bp-0x262]
    9d57:	90                   	nop
    9d58:	9b                   	fwait
    9d59:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    9d5f:	9b dd 9e 6e fd       	fstp   QWORD PTR [bp-0x292]
    9d64:	90                   	nop
    9d65:	9b                   	fwait
    9d66:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    9d6c:	eb 04                	jmp    0x9d72
    9d6e:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    9d72:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9d76:	99                   	cwd
    9d77:	bf a9 7b             	mov    di,0x7ba9
    9d7a:	9a 16 04 94 9d       	call   0x9d94:0x416
    9d7f:	8b f8                	mov    di,ax
    9d81:	c1 e7 02             	shl    di,0x2
    9d84:	9b db 83 c2 fc       	fild   DWORD PTR [bp+di-0x33e]
    9d89:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9d8d:	99                   	cwd
    9d8e:	bf a9 7b             	mov    di,0x7ba9
    9d91:	9a 16 04 ab 9d       	call   0x9dab:0x416
    9d96:	8b f8                	mov    di,ax
    9d98:	c1 e7 03             	shl    di,0x3
    9d9b:	9b dc 8b ae fe       	fmul   QWORD PTR [bp+di-0x152]
    9da0:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9da4:	99                   	cwd
    9da5:	bf a9 7b             	mov    di,0x7ba9
    9da8:	9a 16 04 c3 9d       	call   0x9dc3:0x416
    9dad:	8b f8                	mov    di,ax
    9daf:	c1 e7 02             	shl    di,0x2
    9db2:	9b db 83 6a fe       	fild   DWORD PTR [bp+di-0x196]
    9db7:	9b de c9             	fmulp  st(1),st
    9dba:	9b 2e d9 06 cd 7b    	fld    DWORD PTR cs:0x7bcd
    9dc0:	9a b2 04 f0 9d       	call   0x9df0:0x4b2
    9dc5:	9b dc 86 6e fd       	fadd   QWORD PTR [bp-0x292]
    9dca:	9b dd 9e 6e fd       	fstp   QWORD PTR [bp-0x292]
    9dcf:	90                   	nop
    9dd0:	9b                   	fwait
    9dd1:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    9dd6:	75 96                	jne    0x9d6e
    9dd8:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9dde:	9b dc 46 c8          	fadd   QWORD PTR [bp-0x38]
    9de2:	9b dc 8e 6e fd       	fmul   QWORD PTR [bp-0x292]
    9de7:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9ded:	9a b2 04 34 9e       	call   0x9e34:0x4b2
    9df2:	83 ec 08             	sub    sp,0x8
    9df5:	89 e3                	mov    bx,sp
    9df7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    9dfb:	90                   	nop
    9dfc:	9b                   	fwait
    9dfd:	9a a6 2f a3 9e       	call   0x9ea3:0x2fa6
    9e02:	9b dd 9e 6e fd       	fstp   QWORD PTR [bp-0x292]
    9e07:	90                   	nop
    9e08:	9b                   	fwait
    9e09:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    9e0f:	9b dd 9e 66 fd       	fstp   QWORD PTR [bp-0x29a]
    9e14:	90                   	nop
    9e15:	9b                   	fwait
    9e16:	80 be 5f ff 00       	cmp    BYTE PTR [bp-0xa1],0x0
    9e1b:	74 5e                	je     0x9e7b
    9e1d:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    9e23:	eb 04                	jmp    0x9e29
    9e25:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    9e29:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9e2d:	99                   	cwd
    9e2e:	bf a9 7b             	mov    di,0x7ba9
    9e31:	9a 16 04 4b 9e       	call   0x9e4b:0x416
    9e36:	8b f8                	mov    di,ax
    9e38:	c1 e7 02             	shl    di,0x2
    9e3b:	9b db 83 62 fe       	fild   DWORD PTR [bp+di-0x19e]
    9e40:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    9e44:	99                   	cwd
    9e45:	bf a9 7b             	mov    di,0x7ba9
    9e48:	9a 16 04 66 9e       	call   0x9e66:0x416
    9e4d:	8b f8                	mov    di,ax
    9e4f:	c1 e7 03             	shl    di,0x3
    9e52:	9b dc 8b 2e ff       	fmul   QWORD PTR [bp+di-0xd2]
    9e57:	9b 2e d8 0e d1 7b    	fmul   DWORD PTR cs:0x7bd1
    9e5d:	9b 2e d9 06 cd 7b    	fld    DWORD PTR cs:0x7bcd
    9e63:	9a b2 04 93 9e       	call   0x9e93:0x4b2
    9e68:	9b dc 86 66 fd       	fadd   QWORD PTR [bp-0x29a]
    9e6d:	9b dd 9e 66 fd       	fstp   QWORD PTR [bp-0x29a]
    9e72:	90                   	nop
    9e73:	9b                   	fwait
    9e74:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    9e79:	75 aa                	jne    0x9e25
    9e7b:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9e81:	9b dc 46 c8          	fadd   QWORD PTR [bp-0x38]
    9e85:	9b dc 8e 66 fd       	fmul   QWORD PTR [bp-0x29a]
    9e8a:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9e90:	9a b2 04 9c 9f       	call   0x9f9c:0x4b2
    9e95:	83 ec 08             	sub    sp,0x8
    9e98:	89 e3                	mov    bx,sp
    9e9a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    9e9e:	90                   	nop
    9e9f:	9b                   	fwait
    9ea0:	9a a6 2f 0a a0       	call   0xa00a:0x2fa6
    9ea5:	9b dd 9e 66 fd       	fstp   QWORD PTR [bp-0x29a]
    9eaa:	90                   	nop
    9eab:	9b 9b dd 86 0e fe    	fld    QWORD PTR [bp-0x1f2]
    9eb1:	9b dc 86 fe fe       	fadd   QWORD PTR [bp-0x102]
    9eb6:	9b dd 9e 56 fd       	fstp   QWORD PTR [bp-0x2aa]
    9ebb:	90                   	nop
    9ebc:	9b 9b dd 86 16 fe    	fld    QWORD PTR [bp-0x1ea]
    9ec2:	9b dd 9e e6 fb       	fstp   QWORD PTR [bp-0x41a]
    9ec7:	90                   	nop
    9ec8:	9b 9b dd 86 0e ff    	fld    QWORD PTR [bp-0xf2]
    9ece:	9b dc 86 fe fe       	fadd   QWORD PTR [bp-0x102]
    9ed3:	9b dc 86 66 fd       	fadd   QWORD PTR [bp-0x29a]
    9ed8:	9b dc a6 1e fe       	fsub   QWORD PTR [bp-0x1e2]
    9edd:	9b dc 86 8e fd       	fadd   QWORD PTR [bp-0x272]
    9ee2:	9b dc a6 36 fe       	fsub   QWORD PTR [bp-0x1ca]
    9ee7:	9b dc 86 36 fd       	fadd   QWORD PTR [bp-0x2ca]
    9eec:	9b dc 86 96 fd       	fadd   QWORD PTR [bp-0x26a]
    9ef1:	9b dc 86 e6 fb       	fadd   QWORD PTR [bp-0x41a]
    9ef6:	9b dd 86 6e fd       	fld    QWORD PTR [bp-0x292]
    9efb:	9b dc a6 26 fe       	fsub   QWORD PTR [bp-0x1da]
    9f00:	9b db 86 22 ff       	fild   DWORD PTR [bp-0xde]
    9f05:	9b dc 4e a0          	fmul   QWORD PTR [bp-0x60]
    9f09:	9b de c1             	faddp  st(1),st
    9f0c:	9b dc 86 ce fc       	fadd   QWORD PTR [bp-0x332]
    9f11:	9b dc 86 9e fc       	fadd   QWORD PTR [bp-0x362]
    9f16:	9b dc a6 ce fd       	fsub   QWORD PTR [bp-0x232]
    9f1b:	9b dc 86 a6 fc       	fadd   QWORD PTR [bp-0x35a]
    9f20:	9b dc a6 d6 fd       	fsub   QWORD PTR [bp-0x22a]
    9f25:	9b dc 86 06 fe       	fadd   QWORD PTR [bp-0x1fa]
    9f2a:	9b dc 86 fe fd       	fadd   QWORD PTR [bp-0x202]
    9f2f:	9b de e9             	fsubp  st(1),st
    9f32:	9b dd 9e e6 fb       	fstp   QWORD PTR [bp-0x41a]
    9f37:	90                   	nop
    9f38:	9b 9b dd 86 e6 fb    	fld    QWORD PTR [bp-0x41a]
    9f3e:	9b 2e d8 1e ae 7b    	fcomp  DWORD PTR cs:0x7bae
    9f44:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    9f49:	90                   	nop
    9f4a:	9b                   	fwait
    9f4b:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    9f4f:	9e                   	sahf
    9f50:	73 1e                	jae    0x9f70
    9f52:	9b dd 86 e6 fb       	fld    QWORD PTR [bp-0x41a]
    9f57:	9b d9 e0             	fchs
    9f5a:	9b dd 9e de fb       	fstp   QWORD PTR [bp-0x422]
    9f5f:	90                   	nop
    9f60:	9b                   	fwait
    9f61:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    9f67:	9b dd 9e 5e fd       	fstp   QWORD PTR [bp-0x2a2]
    9f6c:	90                   	nop
    9f6d:	9b                   	fwait
    9f6e:	eb 19                	jmp    0x9f89
    9f70:	9b 2e d9 06 ae 7b    	fld    DWORD PTR cs:0x7bae
    9f76:	9b dd 9e de fb       	fstp   QWORD PTR [bp-0x422]
    9f7b:	90                   	nop
    9f7c:	9b 9b dd 86 e6 fb    	fld    QWORD PTR [bp-0x41a]
    9f82:	9b dd 9e 5e fd       	fstp   QWORD PTR [bp-0x2a2]
    9f87:	90                   	nop
    9f88:	9b 9b dd 86 16 fc    	fld    QWORD PTR [bp-0x3ea]
    9f8e:	9b dc 8e 60 ff       	fmul   QWORD PTR [bp-0xa0]
    9f93:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9f99:	9a b2 04 fa 9f       	call   0x9ffa:0x4b2
    9f9e:	9b dd 9e ee fb       	fstp   QWORD PTR [bp-0x412]
    9fa3:	90                   	nop
    9fa4:	9b 9b dd 86 de fb    	fld    QWORD PTR [bp-0x422]
    9faa:	9b dc 9e ee fb       	fcomp  QWORD PTR [bp-0x412]
    9faf:	9b dd be 80 fb       	fstsw  WORD PTR [bp-0x480]
    9fb4:	90                   	nop
    9fb5:	9b                   	fwait
    9fb6:	8a a6 81 fb          	mov    ah,BYTE PTR [bp-0x47f]
    9fba:	9e                   	sahf
    9fbb:	77 0e                	ja     0x9fcb
    9fbd:	9b dd 86 de fb       	fld    QWORD PTR [bp-0x422]
    9fc2:	9b dd 9e 4e fd       	fstp   QWORD PTR [bp-0x2b2]
    9fc7:	90                   	nop
    9fc8:	9b                   	fwait
    9fc9:	eb 0c                	jmp    0x9fd7
    9fcb:	9b dd 86 ee fb       	fld    QWORD PTR [bp-0x412]
    9fd0:	9b dd 9e 4e fd       	fstp   QWORD PTR [bp-0x2b2]
    9fd5:	90                   	nop
    9fd6:	9b 9b dd 86 de fb    	fld    QWORD PTR [bp-0x422]
    9fdc:	9b dc a6 4e fd       	fsub   QWORD PTR [bp-0x2b2]
    9fe1:	9b dd 9e 46 fd       	fstp   QWORD PTR [bp-0x2ba]
    9fe6:	90                   	nop
    9fe7:	9b 9b dd 86 16 fc    	fld    QWORD PTR [bp-0x3ea]
    9fed:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    9ff1:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    9ff7:	9a b2 04 23 a0       	call   0xa023:0x4b2
    9ffc:	83 ec 08             	sub    sp,0x8
    9fff:	89 e3                	mov    bx,sp
    a001:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a005:	90                   	nop
    a006:	9b                   	fwait
    a007:	9a a6 2f 33 a0       	call   0xa033:0x2fa6
    a00c:	9b db be 78 fb       	fstp   TBYTE PTR [bp-0x488]
    a011:	9b dd 86 36 fd       	fld    QWORD PTR [bp-0x2ca]
    a016:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    a01a:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    a020:	9a b2 04 76 a0       	call   0xa076:0x4b2
    a025:	83 ec 08             	sub    sp,0x8
    a028:	89 e3                	mov    bx,sp
    a02a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a02e:	90                   	nop
    a02f:	9b                   	fwait
    a030:	9a a6 2f 5b a0       	call   0xa05b:0x2fa6
    a035:	9b db ae 78 fb       	fld    TBYTE PTR [bp-0x488]
    a03a:	9b de c1             	faddp  st(1),st
    a03d:	9b dd 9e 7e fd       	fstp   QWORD PTR [bp-0x282]
    a042:	90                   	nop
    a043:	9b 9b db 86 22 ff    	fild   DWORD PTR [bp-0xde]
    a049:	9b dc 4e a0          	fmul   QWORD PTR [bp-0x60]
    a04d:	83 ec 08             	sub    sp,0x8
    a050:	89 e3                	mov    bx,sp
    a052:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a056:	90                   	nop
    a057:	9b                   	fwait
    a058:	9a a6 2f 86 a0       	call   0xa086:0x2fa6
    a05d:	9b dd 9e 46 fc       	fstp   QWORD PTR [bp-0x3ba]
    a062:	90                   	nop
    a063:	9b 9b dd 86 c6 fe    	fld    QWORD PTR [bp-0x13a]
    a069:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    a06d:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    a073:	9a b2 04 9f a0       	call   0xa09f:0x4b2
    a078:	83 ec 08             	sub    sp,0x8
    a07b:	89 e3                	mov    bx,sp
    a07d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a081:	90                   	nop
    a082:	9b                   	fwait
    a083:	9a a6 2f af a0       	call   0xa0af:0x2fa6
    a088:	9b db be 78 fb       	fstp   TBYTE PTR [bp-0x488]
    a08d:	9b dd 86 46 fc       	fld    QWORD PTR [bp-0x3ba]
    a092:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    a096:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    a09c:	9a b2 04 cf a0       	call   0xa0cf:0x4b2
    a0a1:	83 ec 08             	sub    sp,0x8
    a0a4:	89 e3                	mov    bx,sp
    a0a6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a0aa:	90                   	nop
    a0ab:	9b                   	fwait
    a0ac:	9a a6 2f df a0       	call   0xa0df:0x2fa6
    a0b1:	9b db ae 78 fb       	fld    TBYTE PTR [bp-0x488]
    a0b6:	9b de c1             	faddp  st(1),st
    a0b9:	9b db be 6e fb       	fstp   TBYTE PTR [bp-0x492]
    a0be:	9b dd 86 26 fd       	fld    QWORD PTR [bp-0x2da]
    a0c3:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    a0c7:	9b df 86 82 fb       	fild   WORD PTR [bp-0x47e]
    a0cc:	9a b2 04 00 a1       	call   0xa100:0x4b2
    a0d1:	83 ec 08             	sub    sp,0x8
    a0d4:	89 e3                	mov    bx,sp
    a0d6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a0da:	90                   	nop
    a0db:	9b                   	fwait
    a0dc:	9a a6 2f 10 a1       	call   0xa110:0x2fa6
    a0e1:	9b db ae 6e fb       	fld    TBYTE PTR [bp-0x492]
    a0e6:	9b de c1             	faddp  st(1),st
    a0e9:	9b db be 64 fb       	fstp   TBYTE PTR [bp-0x49c]
    a0ee:	9b dd 86 1e fd       	fld    QWORD PTR [bp-0x2e2]
    a0f3:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    a0f7:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    a0fd:	9a b2 04 31 a1       	call   0xa131:0x4b2
    a102:	83 ec 08             	sub    sp,0x8
    a105:	89 e3                	mov    bx,sp
    a107:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a10b:	90                   	nop
    a10c:	9b                   	fwait
    a10d:	9a a6 2f 41 a1       	call   0xa141:0x2fa6
    a112:	9b db ae 64 fb       	fld    TBYTE PTR [bp-0x49c]
    a117:	9b de c1             	faddp  st(1),st
    a11a:	9b db be 5a fb       	fstp   TBYTE PTR [bp-0x4a6]
    a11f:	9b dd 86 16 fd       	fld    QWORD PTR [bp-0x2ea]
    a124:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    a128:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    a12e:	9a b2 04 69 a1       	call   0xa169:0x4b2
    a133:	83 ec 08             	sub    sp,0x8
    a136:	89 e3                	mov    bx,sp
    a138:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a13c:	90                   	nop
    a13d:	9b                   	fwait
    a13e:	9a a6 2f 92 a1       	call   0xa192:0x2fa6
    a143:	9b db ae 5a fb       	fld    TBYTE PTR [bp-0x4a6]
    a148:	9b de c1             	faddp  st(1),st
    a14b:	9b dd 9e 84 fb       	fstp   QWORD PTR [bp-0x47c]
    a150:	90                   	nop
    a151:	9b                   	fwait
    a152:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    a158:	eb 04                	jmp    0xa15e
    a15a:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    a15e:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    a162:	99                   	cwd
    a163:	bf a9 7b             	mov    di,0x7ba9
    a166:	9a 16 04 82 a1       	call   0xa182:0x416
    a16b:	8b f8                	mov    di,ax
    a16d:	c1 e7 03             	shl    di,0x3
    a170:	9b dd 83 76 fc       	fld    QWORD PTR [bp+di-0x38a]
    a175:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    a179:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    a17f:	9a b2 04 a9 a1       	call   0xa1a9:0x4b2
    a184:	83 ec 08             	sub    sp,0x8
    a187:	89 e3                	mov    bx,sp
    a189:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a18d:	90                   	nop
    a18e:	9b                   	fwait
    a18f:	9a a6 2f d2 a1       	call   0xa1d2:0x2fa6
    a194:	9b dc 86 84 fb       	fadd   QWORD PTR [bp-0x47c]
    a199:	9b db be 78 fb       	fstp   TBYTE PTR [bp-0x488]
    a19e:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    a1a2:	99                   	cwd
    a1a3:	bf a9 7b             	mov    di,0x7ba9
    a1a6:	9a 16 04 c2 a1       	call   0xa1c2:0x416
    a1ab:	8b f8                	mov    di,ax
    a1ad:	c1 e7 03             	shl    di,0x3
    a1b0:	9b dd 83 9e fe       	fld    QWORD PTR [bp+di-0x162]
    a1b5:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    a1b9:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    a1bf:	9a b2 04 ec a1       	call   0xa1ec:0x4b2
    a1c4:	83 ec 08             	sub    sp,0x8
    a1c7:	89 e3                	mov    bx,sp
    a1c9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a1cd:	90                   	nop
    a1ce:	9b                   	fwait
    a1cf:	9a a6 2f 15 a2       	call   0xa215:0x2fa6
    a1d4:	9b db ae 78 fb       	fld    TBYTE PTR [bp-0x488]
    a1d9:	9b de c1             	faddp  st(1),st
    a1dc:	9b db be 6e fb       	fstp   TBYTE PTR [bp-0x492]
    a1e1:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    a1e5:	99                   	cwd
    a1e6:	bf a9 7b             	mov    di,0x7ba9
    a1e9:	9a 16 04 05 a2       	call   0xa205:0x416
    a1ee:	8b f8                	mov    di,ax
    a1f0:	c1 e7 03             	shl    di,0x3
    a1f3:	9b dd 83 7e fe       	fld    QWORD PTR [bp+di-0x182]
    a1f8:	9b dc 4e c8          	fmul   QWORD PTR [bp-0x38]
    a1fc:	9b 2e d9 06 b5 7b    	fld    DWORD PTR cs:0x7bb5
    a202:	9a b2 04 d5 a8       	call   0xa8d5:0x4b2
    a207:	83 ec 08             	sub    sp,0x8
    a20a:	89 e3                	mov    bx,sp
    a20c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    a210:	90                   	nop
    a211:	9b                   	fwait
    a212:	9a a6 2f d7 af       	call   0xafd7:0x2fa6
    a217:	9b db ae 6e fb       	fld    TBYTE PTR [bp-0x492]
    a21c:	9b de c1             	faddp  st(1),st
    a21f:	9b dd 9e 84 fb       	fstp   QWORD PTR [bp-0x47c]
    a224:	90                   	nop
    a225:	9b                   	fwait
    a226:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    a22b:	74 03                	je     0xa230
    a22d:	e9 2a ff             	jmp    0xa15a
    a230:	9b dd 86 84 fb       	fld    QWORD PTR [bp-0x47c]
    a235:	9b dd 9e 76 fd       	fstp   QWORD PTR [bp-0x28a]
    a23a:	90                   	nop
    a23b:	9b                   	fwait
    a23c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    a23f:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    a244:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    a248:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    a24c:	b8 60 7d             	mov    ax,0x7d60
    a24f:	0e                   	push   cs
    a250:	50                   	push   ax
    a251:	55                   	push   bp
    a252:	ff 36 58 18          	push   WORD PTR ds:0x1858
    a256:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    a25a:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    a25d:	99                   	cwd
    a25e:	89 86 6e fb          	mov    WORD PTR [bp-0x492],ax
    a262:	89 96 70 fb          	mov    WORD PTR [bp-0x490],dx
    a266:	c6 86 72 fb 00       	mov    BYTE PTR [bp-0x48e],0x0
    a26b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    a26e:	99                   	cwd
    a26f:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    a273:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    a277:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    a27c:	8d be 6e fb          	lea    di,[bp-0x492]
    a280:	16                   	push   ss
    a281:	57                   	push   di
    a282:	6a 01                	push   0x1
    a284:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a288:	06                   	push   es
    a289:	57                   	push   di
    a28a:	9a 95 28 af a8       	call   0xa8af:0x2895
    a28f:	08 c0                	or     al,al
    a291:	75 0a                	jne    0xa29d
    a293:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    a296:	06                   	push   es
    a297:	57                   	push   di
    a298:	9a 03 03 bd a8       	call   0xa8bd:0x303
    a29d:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a2a1:	06                   	push   es
    a2a2:	57                   	push   di
    a2a3:	9a 3c 53 c6 a2       	call   0xa2c6:0x533c
    a2a8:	ff b6 bc fd          	push   WORD PTR [bp-0x244]
    a2ac:	ff b6 ba fd          	push   WORD PTR [bp-0x246]
    a2b0:	ff b6 b8 fd          	push   WORD PTR [bp-0x248]
    a2b4:	ff b6 b6 fd          	push   WORD PTR [bp-0x24a]
    a2b8:	bf d5 7b             	mov    di,0x7bd5
    a2bb:	0e                   	push   cs
    a2bc:	57                   	push   di
    a2bd:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a2c1:	06                   	push   es
    a2c2:	57                   	push   di
    a2c3:	9a 9b 3b f3 a2       	call   0xa2f3:0x3b9b
    a2c8:	89 c7                	mov    di,ax
    a2ca:	8e c2                	mov    es,dx
    a2cc:	06                   	push   es
    a2cd:	57                   	push   di
    a2ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a2d1:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a2d5:	ff b6 b4 fd          	push   WORD PTR [bp-0x24c]
    a2d9:	ff b6 b2 fd          	push   WORD PTR [bp-0x24e]
    a2dd:	ff b6 b0 fd          	push   WORD PTR [bp-0x250]
    a2e1:	ff b6 ae fd          	push   WORD PTR [bp-0x252]
    a2e5:	bf e3 7b             	mov    di,0x7be3
    a2e8:	0e                   	push   cs
    a2e9:	57                   	push   di
    a2ea:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a2ee:	06                   	push   es
    a2ef:	57                   	push   di
    a2f0:	9a 9b 3b 20 a3       	call   0xa320:0x3b9b
    a2f5:	89 c7                	mov    di,ax
    a2f7:	8e c2                	mov    es,dx
    a2f9:	06                   	push   es
    a2fa:	57                   	push   di
    a2fb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a2fe:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a302:	ff b6 ac fd          	push   WORD PTR [bp-0x254]
    a306:	ff b6 aa fd          	push   WORD PTR [bp-0x256]
    a30a:	ff b6 a8 fd          	push   WORD PTR [bp-0x258]
    a30e:	ff b6 a6 fd          	push   WORD PTR [bp-0x25a]
    a312:	bf ec 7b             	mov    di,0x7bec
    a315:	0e                   	push   cs
    a316:	57                   	push   di
    a317:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a31b:	06                   	push   es
    a31c:	57                   	push   di
    a31d:	9a 9b 3b 4d a3       	call   0xa34d:0x3b9b
    a322:	89 c7                	mov    di,ax
    a324:	8e c2                	mov    es,dx
    a326:	06                   	push   es
    a327:	57                   	push   di
    a328:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a32b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a32f:	ff b6 a4 fd          	push   WORD PTR [bp-0x25c]
    a333:	ff b6 a2 fd          	push   WORD PTR [bp-0x25e]
    a337:	ff b6 a0 fd          	push   WORD PTR [bp-0x260]
    a33b:	ff b6 9e fd          	push   WORD PTR [bp-0x262]
    a33f:	bf f8 7b             	mov    di,0x7bf8
    a342:	0e                   	push   cs
    a343:	57                   	push   di
    a344:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a348:	06                   	push   es
    a349:	57                   	push   di
    a34a:	9a 9b 3b 7a a3       	call   0xa37a:0x3b9b
    a34f:	89 c7                	mov    di,ax
    a351:	8e c2                	mov    es,dx
    a353:	06                   	push   es
    a354:	57                   	push   di
    a355:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a358:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a35c:	ff b6 9c fd          	push   WORD PTR [bp-0x264]
    a360:	ff b6 9a fd          	push   WORD PTR [bp-0x266]
    a364:	ff b6 98 fd          	push   WORD PTR [bp-0x268]
    a368:	ff b6 96 fd          	push   WORD PTR [bp-0x26a]
    a36c:	bf 07 7c             	mov    di,0x7c07
    a36f:	0e                   	push   cs
    a370:	57                   	push   di
    a371:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a375:	06                   	push   es
    a376:	57                   	push   di
    a377:	9a 9b 3b a7 a3       	call   0xa3a7:0x3b9b
    a37c:	89 c7                	mov    di,ax
    a37e:	8e c2                	mov    es,dx
    a380:	06                   	push   es
    a381:	57                   	push   di
    a382:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a385:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a389:	ff b6 94 fd          	push   WORD PTR [bp-0x26c]
    a38d:	ff b6 92 fd          	push   WORD PTR [bp-0x26e]
    a391:	ff b6 90 fd          	push   WORD PTR [bp-0x270]
    a395:	ff b6 8e fd          	push   WORD PTR [bp-0x272]
    a399:	bf 0b 7c             	mov    di,0x7c0b
    a39c:	0e                   	push   cs
    a39d:	57                   	push   di
    a39e:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a3a2:	06                   	push   es
    a3a3:	57                   	push   di
    a3a4:	9a 9b 3b d4 a3       	call   0xa3d4:0x3b9b
    a3a9:	89 c7                	mov    di,ax
    a3ab:	8e c2                	mov    es,dx
    a3ad:	06                   	push   es
    a3ae:	57                   	push   di
    a3af:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a3b2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a3b6:	ff b6 8c fd          	push   WORD PTR [bp-0x274]
    a3ba:	ff b6 8a fd          	push   WORD PTR [bp-0x276]
    a3be:	ff b6 88 fd          	push   WORD PTR [bp-0x278]
    a3c2:	ff b6 86 fd          	push   WORD PTR [bp-0x27a]
    a3c6:	bf 11 7c             	mov    di,0x7c11
    a3c9:	0e                   	push   cs
    a3ca:	57                   	push   di
    a3cb:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a3cf:	06                   	push   es
    a3d0:	57                   	push   di
    a3d1:	9a 9b 3b 01 a4       	call   0xa401:0x3b9b
    a3d6:	89 c7                	mov    di,ax
    a3d8:	8e c2                	mov    es,dx
    a3da:	06                   	push   es
    a3db:	57                   	push   di
    a3dc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a3df:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a3e3:	ff b6 84 fd          	push   WORD PTR [bp-0x27c]
    a3e7:	ff b6 82 fd          	push   WORD PTR [bp-0x27e]
    a3eb:	ff b6 80 fd          	push   WORD PTR [bp-0x280]
    a3ef:	ff b6 7e fd          	push   WORD PTR [bp-0x282]
    a3f3:	bf 15 7c             	mov    di,0x7c15
    a3f6:	0e                   	push   cs
    a3f7:	57                   	push   di
    a3f8:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a3fc:	06                   	push   es
    a3fd:	57                   	push   di
    a3fe:	9a 9b 3b 2e a4       	call   0xa42e:0x3b9b
    a403:	89 c7                	mov    di,ax
    a405:	8e c2                	mov    es,dx
    a407:	06                   	push   es
    a408:	57                   	push   di
    a409:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a40c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a410:	ff b6 7c fd          	push   WORD PTR [bp-0x284]
    a414:	ff b6 7a fd          	push   WORD PTR [bp-0x286]
    a418:	ff b6 78 fd          	push   WORD PTR [bp-0x288]
    a41c:	ff b6 76 fd          	push   WORD PTR [bp-0x28a]
    a420:	bf 22 7c             	mov    di,0x7c22
    a423:	0e                   	push   cs
    a424:	57                   	push   di
    a425:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a429:	06                   	push   es
    a42a:	57                   	push   di
    a42b:	9a 9b 3b 5b a4       	call   0xa45b:0x3b9b
    a430:	89 c7                	mov    di,ax
    a432:	8e c2                	mov    es,dx
    a434:	06                   	push   es
    a435:	57                   	push   di
    a436:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a439:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a43d:	ff b6 74 fd          	push   WORD PTR [bp-0x28c]
    a441:	ff b6 72 fd          	push   WORD PTR [bp-0x28e]
    a445:	ff b6 70 fd          	push   WORD PTR [bp-0x290]
    a449:	ff b6 6e fd          	push   WORD PTR [bp-0x292]
    a44d:	bf 30 7c             	mov    di,0x7c30
    a450:	0e                   	push   cs
    a451:	57                   	push   di
    a452:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a456:	06                   	push   es
    a457:	57                   	push   di
    a458:	9a 9b 3b 88 a4       	call   0xa488:0x3b9b
    a45d:	89 c7                	mov    di,ax
    a45f:	8e c2                	mov    es,dx
    a461:	06                   	push   es
    a462:	57                   	push   di
    a463:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a466:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a46a:	ff b6 6c fd          	push   WORD PTR [bp-0x294]
    a46e:	ff b6 6a fd          	push   WORD PTR [bp-0x296]
    a472:	ff b6 68 fd          	push   WORD PTR [bp-0x298]
    a476:	ff b6 66 fd          	push   WORD PTR [bp-0x29a]
    a47a:	bf 38 7c             	mov    di,0x7c38
    a47d:	0e                   	push   cs
    a47e:	57                   	push   di
    a47f:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a483:	06                   	push   es
    a484:	57                   	push   di
    a485:	9a 9b 3b b5 a4       	call   0xa4b5:0x3b9b
    a48a:	89 c7                	mov    di,ax
    a48c:	8e c2                	mov    es,dx
    a48e:	06                   	push   es
    a48f:	57                   	push   di
    a490:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a493:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a497:	ff b6 64 fd          	push   WORD PTR [bp-0x29c]
    a49b:	ff b6 62 fd          	push   WORD PTR [bp-0x29e]
    a49f:	ff b6 60 fd          	push   WORD PTR [bp-0x2a0]
    a4a3:	ff b6 5e fd          	push   WORD PTR [bp-0x2a2]
    a4a7:	bf 45 7c             	mov    di,0x7c45
    a4aa:	0e                   	push   cs
    a4ab:	57                   	push   di
    a4ac:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a4b0:	06                   	push   es
    a4b1:	57                   	push   di
    a4b2:	9a 9b 3b e2 a4       	call   0xa4e2:0x3b9b
    a4b7:	89 c7                	mov    di,ax
    a4b9:	8e c2                	mov    es,dx
    a4bb:	06                   	push   es
    a4bc:	57                   	push   di
    a4bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a4c0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a4c4:	ff b6 5c fd          	push   WORD PTR [bp-0x2a4]
    a4c8:	ff b6 5a fd          	push   WORD PTR [bp-0x2a6]
    a4cc:	ff b6 58 fd          	push   WORD PTR [bp-0x2a8]
    a4d0:	ff b6 56 fd          	push   WORD PTR [bp-0x2aa]
    a4d4:	bf 50 7c             	mov    di,0x7c50
    a4d7:	0e                   	push   cs
    a4d8:	57                   	push   di
    a4d9:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a4dd:	06                   	push   es
    a4de:	57                   	push   di
    a4df:	9a 9b 3b 0f a5       	call   0xa50f:0x3b9b
    a4e4:	89 c7                	mov    di,ax
    a4e6:	8e c2                	mov    es,dx
    a4e8:	06                   	push   es
    a4e9:	57                   	push   di
    a4ea:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a4ed:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a4f1:	ff b6 54 fd          	push   WORD PTR [bp-0x2ac]
    a4f5:	ff b6 52 fd          	push   WORD PTR [bp-0x2ae]
    a4f9:	ff b6 50 fd          	push   WORD PTR [bp-0x2b0]
    a4fd:	ff b6 4e fd          	push   WORD PTR [bp-0x2b2]
    a501:	bf 58 7c             	mov    di,0x7c58
    a504:	0e                   	push   cs
    a505:	57                   	push   di
    a506:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a50a:	06                   	push   es
    a50b:	57                   	push   di
    a50c:	9a 9b 3b 3c a5       	call   0xa53c:0x3b9b
    a511:	89 c7                	mov    di,ax
    a513:	8e c2                	mov    es,dx
    a515:	06                   	push   es
    a516:	57                   	push   di
    a517:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a51a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a51e:	ff b6 4c fd          	push   WORD PTR [bp-0x2b4]
    a522:	ff b6 4a fd          	push   WORD PTR [bp-0x2b6]
    a526:	ff b6 48 fd          	push   WORD PTR [bp-0x2b8]
    a52a:	ff b6 46 fd          	push   WORD PTR [bp-0x2ba]
    a52e:	bf 66 7c             	mov    di,0x7c66
    a531:	0e                   	push   cs
    a532:	57                   	push   di
    a533:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a537:	06                   	push   es
    a538:	57                   	push   di
    a539:	9a 9b 3b 69 a5       	call   0xa569:0x3b9b
    a53e:	89 c7                	mov    di,ax
    a540:	8e c2                	mov    es,dx
    a542:	06                   	push   es
    a543:	57                   	push   di
    a544:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a547:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a54b:	ff b6 44 fd          	push   WORD PTR [bp-0x2bc]
    a54f:	ff b6 42 fd          	push   WORD PTR [bp-0x2be]
    a553:	ff b6 40 fd          	push   WORD PTR [bp-0x2c0]
    a557:	ff b6 3e fd          	push   WORD PTR [bp-0x2c2]
    a55b:	bf 75 7c             	mov    di,0x7c75
    a55e:	0e                   	push   cs
    a55f:	57                   	push   di
    a560:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a564:	06                   	push   es
    a565:	57                   	push   di
    a566:	9a 9b 3b 96 a5       	call   0xa596:0x3b9b
    a56b:	89 c7                	mov    di,ax
    a56d:	8e c2                	mov    es,dx
    a56f:	06                   	push   es
    a570:	57                   	push   di
    a571:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a574:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a578:	ff b6 3c fd          	push   WORD PTR [bp-0x2c4]
    a57c:	ff b6 3a fd          	push   WORD PTR [bp-0x2c6]
    a580:	ff b6 38 fd          	push   WORD PTR [bp-0x2c8]
    a584:	ff b6 36 fd          	push   WORD PTR [bp-0x2ca]
    a588:	bf 83 7c             	mov    di,0x7c83
    a58b:	0e                   	push   cs
    a58c:	57                   	push   di
    a58d:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a591:	06                   	push   es
    a592:	57                   	push   di
    a593:	9a 9b 3b c3 a5       	call   0xa5c3:0x3b9b
    a598:	89 c7                	mov    di,ax
    a59a:	8e c2                	mov    es,dx
    a59c:	06                   	push   es
    a59d:	57                   	push   di
    a59e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a5a1:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a5a5:	ff b6 34 fd          	push   WORD PTR [bp-0x2cc]
    a5a9:	ff b6 32 fd          	push   WORD PTR [bp-0x2ce]
    a5ad:	ff b6 30 fd          	push   WORD PTR [bp-0x2d0]
    a5b1:	ff b6 2e fd          	push   WORD PTR [bp-0x2d2]
    a5b5:	bf 8c 7c             	mov    di,0x7c8c
    a5b8:	0e                   	push   cs
    a5b9:	57                   	push   di
    a5ba:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a5be:	06                   	push   es
    a5bf:	57                   	push   di
    a5c0:	9a 9b 3b f0 a5       	call   0xa5f0:0x3b9b
    a5c5:	89 c7                	mov    di,ax
    a5c7:	8e c2                	mov    es,dx
    a5c9:	06                   	push   es
    a5ca:	57                   	push   di
    a5cb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a5ce:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a5d2:	ff b6 2c fd          	push   WORD PTR [bp-0x2d4]
    a5d6:	ff b6 2a fd          	push   WORD PTR [bp-0x2d6]
    a5da:	ff b6 28 fd          	push   WORD PTR [bp-0x2d8]
    a5de:	ff b6 26 fd          	push   WORD PTR [bp-0x2da]
    a5e2:	bf a2 7c             	mov    di,0x7ca2
    a5e5:	0e                   	push   cs
    a5e6:	57                   	push   di
    a5e7:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a5eb:	06                   	push   es
    a5ec:	57                   	push   di
    a5ed:	9a 9b 3b 1d a6       	call   0xa61d:0x3b9b
    a5f2:	89 c7                	mov    di,ax
    a5f4:	8e c2                	mov    es,dx
    a5f6:	06                   	push   es
    a5f7:	57                   	push   di
    a5f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a5fb:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a5ff:	ff b6 14 fd          	push   WORD PTR [bp-0x2ec]
    a603:	ff b6 12 fd          	push   WORD PTR [bp-0x2ee]
    a607:	ff b6 10 fd          	push   WORD PTR [bp-0x2f0]
    a60b:	ff b6 0e fd          	push   WORD PTR [bp-0x2f2]
    a60f:	bf b7 7c             	mov    di,0x7cb7
    a612:	0e                   	push   cs
    a613:	57                   	push   di
    a614:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a618:	06                   	push   es
    a619:	57                   	push   di
    a61a:	9a 9b 3b 4a a6       	call   0xa64a:0x3b9b
    a61f:	89 c7                	mov    di,ax
    a621:	8e c2                	mov    es,dx
    a623:	06                   	push   es
    a624:	57                   	push   di
    a625:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a628:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a62c:	ff b6 0c fd          	push   WORD PTR [bp-0x2f4]
    a630:	ff b6 0a fd          	push   WORD PTR [bp-0x2f6]
    a634:	ff b6 08 fd          	push   WORD PTR [bp-0x2f8]
    a638:	ff b6 06 fd          	push   WORD PTR [bp-0x2fa]
    a63c:	bf c7 7c             	mov    di,0x7cc7
    a63f:	0e                   	push   cs
    a640:	57                   	push   di
    a641:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a645:	06                   	push   es
    a646:	57                   	push   di
    a647:	9a 9b 3b 6f a6       	call   0xa66f:0x3b9b
    a64c:	89 c7                	mov    di,ax
    a64e:	8e c2                	mov    es,dx
    a650:	06                   	push   es
    a651:	57                   	push   di
    a652:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a655:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a659:	ff b6 04 fd          	push   WORD PTR [bp-0x2fc]
    a65d:	ff b6 02 fd          	push   WORD PTR [bp-0x2fe]
    a661:	bf d5 7c             	mov    di,0x7cd5
    a664:	0e                   	push   cs
    a665:	57                   	push   di
    a666:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a66a:	06                   	push   es
    a66b:	57                   	push   di
    a66c:	9a 9b 3b 94 a6       	call   0xa694:0x3b9b
    a671:	89 c7                	mov    di,ax
    a673:	8e c2                	mov    es,dx
    a675:	06                   	push   es
    a676:	57                   	push   di
    a677:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a67a:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    a67e:	ff b6 fc fc          	push   WORD PTR [bp-0x304]
    a682:	ff b6 fa fc          	push   WORD PTR [bp-0x306]
    a686:	bf de 7c             	mov    di,0x7cde
    a689:	0e                   	push   cs
    a68a:	57                   	push   di
    a68b:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a68f:	06                   	push   es
    a690:	57                   	push   di
    a691:	9a 9b 3b b9 a6       	call   0xa6b9:0x3b9b
    a696:	89 c7                	mov    di,ax
    a698:	8e c2                	mov    es,dx
    a69a:	06                   	push   es
    a69b:	57                   	push   di
    a69c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a69f:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    a6a3:	ff b6 00 fd          	push   WORD PTR [bp-0x300]
    a6a7:	ff b6 fe fc          	push   WORD PTR [bp-0x302]
    a6ab:	bf e7 7c             	mov    di,0x7ce7
    a6ae:	0e                   	push   cs
    a6af:	57                   	push   di
    a6b0:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a6b4:	06                   	push   es
    a6b5:	57                   	push   di
    a6b6:	9a 9b 3b de a6       	call   0xa6de:0x3b9b
    a6bb:	89 c7                	mov    di,ax
    a6bd:	8e c2                	mov    es,dx
    a6bf:	06                   	push   es
    a6c0:	57                   	push   di
    a6c1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a6c4:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    a6c8:	ff b6 f8 fc          	push   WORD PTR [bp-0x308]
    a6cc:	ff b6 f6 fc          	push   WORD PTR [bp-0x30a]
    a6d0:	bf f2 7c             	mov    di,0x7cf2
    a6d3:	0e                   	push   cs
    a6d4:	57                   	push   di
    a6d5:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a6d9:	06                   	push   es
    a6da:	57                   	push   di
    a6db:	9a 9b 3b 0b a7       	call   0xa70b:0x3b9b
    a6e0:	89 c7                	mov    di,ax
    a6e2:	8e c2                	mov    es,dx
    a6e4:	06                   	push   es
    a6e5:	57                   	push   di
    a6e6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a6e9:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    a6ed:	ff b6 f4 fc          	push   WORD PTR [bp-0x30c]
    a6f1:	ff b6 f2 fc          	push   WORD PTR [bp-0x30e]
    a6f5:	ff b6 f0 fc          	push   WORD PTR [bp-0x310]
    a6f9:	ff b6 ee fc          	push   WORD PTR [bp-0x312]
    a6fd:	bf f9 7c             	mov    di,0x7cf9
    a700:	0e                   	push   cs
    a701:	57                   	push   di
    a702:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a706:	06                   	push   es
    a707:	57                   	push   di
    a708:	9a 9b 3b 38 a7       	call   0xa738:0x3b9b
    a70d:	89 c7                	mov    di,ax
    a70f:	8e c2                	mov    es,dx
    a711:	06                   	push   es
    a712:	57                   	push   di
    a713:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a716:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a71a:	ff b6 e4 fc          	push   WORD PTR [bp-0x31c]
    a71e:	ff b6 e2 fc          	push   WORD PTR [bp-0x31e]
    a722:	ff b6 e0 fc          	push   WORD PTR [bp-0x320]
    a726:	ff b6 de fc          	push   WORD PTR [bp-0x322]
    a72a:	bf 0c 7d             	mov    di,0x7d0c
    a72d:	0e                   	push   cs
    a72e:	57                   	push   di
    a72f:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a733:	06                   	push   es
    a734:	57                   	push   di
    a735:	9a 9b 3b 65 a7       	call   0xa765:0x3b9b
    a73a:	89 c7                	mov    di,ax
    a73c:	8e c2                	mov    es,dx
    a73e:	06                   	push   es
    a73f:	57                   	push   di
    a740:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a743:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a747:	ff b6 ec fc          	push   WORD PTR [bp-0x314]
    a74b:	ff b6 ea fc          	push   WORD PTR [bp-0x316]
    a74f:	ff b6 e8 fc          	push   WORD PTR [bp-0x318]
    a753:	ff b6 e6 fc          	push   WORD PTR [bp-0x31a]
    a757:	bf 19 7d             	mov    di,0x7d19
    a75a:	0e                   	push   cs
    a75b:	57                   	push   di
    a75c:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a760:	06                   	push   es
    a761:	57                   	push   di
    a762:	9a 9b 3b 92 a7       	call   0xa792:0x3b9b
    a767:	89 c7                	mov    di,ax
    a769:	8e c2                	mov    es,dx
    a76b:	06                   	push   es
    a76c:	57                   	push   di
    a76d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a770:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a774:	ff b6 dc fc          	push   WORD PTR [bp-0x324]
    a778:	ff b6 da fc          	push   WORD PTR [bp-0x326]
    a77c:	ff b6 d8 fc          	push   WORD PTR [bp-0x328]
    a780:	ff b6 d6 fc          	push   WORD PTR [bp-0x32a]
    a784:	bf 26 7d             	mov    di,0x7d26
    a787:	0e                   	push   cs
    a788:	57                   	push   di
    a789:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a78d:	06                   	push   es
    a78e:	57                   	push   di
    a78f:	9a 9b 3b bf a7       	call   0xa7bf:0x3b9b
    a794:	89 c7                	mov    di,ax
    a796:	8e c2                	mov    es,dx
    a798:	06                   	push   es
    a799:	57                   	push   di
    a79a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a79d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a7a1:	ff b6 d4 fc          	push   WORD PTR [bp-0x32c]
    a7a5:	ff b6 d2 fc          	push   WORD PTR [bp-0x32e]
    a7a9:	ff b6 d0 fc          	push   WORD PTR [bp-0x330]
    a7ad:	ff b6 ce fc          	push   WORD PTR [bp-0x332]
    a7b1:	bf 34 7d             	mov    di,0x7d34
    a7b4:	0e                   	push   cs
    a7b5:	57                   	push   di
    a7b6:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a7ba:	06                   	push   es
    a7bb:	57                   	push   di
    a7bc:	9a 9b 3b ec a7       	call   0xa7ec:0x3b9b
    a7c1:	89 c7                	mov    di,ax
    a7c3:	8e c2                	mov    es,dx
    a7c5:	06                   	push   es
    a7c6:	57                   	push   di
    a7c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a7ca:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a7ce:	ff b6 24 fd          	push   WORD PTR [bp-0x2dc]
    a7d2:	ff b6 22 fd          	push   WORD PTR [bp-0x2de]
    a7d6:	ff b6 20 fd          	push   WORD PTR [bp-0x2e0]
    a7da:	ff b6 1e fd          	push   WORD PTR [bp-0x2e2]
    a7de:	bf 42 7d             	mov    di,0x7d42
    a7e1:	0e                   	push   cs
    a7e2:	57                   	push   di
    a7e3:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a7e7:	06                   	push   es
    a7e8:	57                   	push   di
    a7e9:	9a 9b 3b 19 a8       	call   0xa819:0x3b9b
    a7ee:	89 c7                	mov    di,ax
    a7f0:	8e c2                	mov    es,dx
    a7f2:	06                   	push   es
    a7f3:	57                   	push   di
    a7f4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a7f7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a7fb:	ff b6 1c fd          	push   WORD PTR [bp-0x2e4]
    a7ff:	ff b6 1a fd          	push   WORD PTR [bp-0x2e6]
    a803:	ff b6 18 fd          	push   WORD PTR [bp-0x2e8]
    a807:	ff b6 16 fd          	push   WORD PTR [bp-0x2ea]
    a80b:	bf 4e 7d             	mov    di,0x7d4e
    a80e:	0e                   	push   cs
    a80f:	57                   	push   di
    a810:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a814:	06                   	push   es
    a815:	57                   	push   di
    a816:	9a 9b 3b 31 a8       	call   0xa831:0x3b9b
    a81b:	89 c7                	mov    di,ax
    a81d:	8e c2                	mov    es,dx
    a81f:	06                   	push   es
    a820:	57                   	push   di
    a821:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a824:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a828:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a82c:	06                   	push   es
    a82d:	57                   	push   di
    a82e:	9a a0 54 c8 a8       	call   0xa8c8:0x54a0
    a833:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    a837:	83 c4 06             	add    sp,0x6
    a83a:	b8 40 a8             	mov    ax,0xa840
    a83d:	0e                   	push   cs
    a83e:	50                   	push   ax
    a83f:	cb                   	retf
    a840:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    a843:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    a848:	89 be 7e fb          	mov    WORD PTR [bp-0x482],di
    a84c:	8c 86 80 fb          	mov    WORD PTR [bp-0x480],es
    a850:	b8 d6 7d             	mov    ax,0x7dd6
    a853:	0e                   	push   cs
    a854:	50                   	push   ax
    a855:	55                   	push   bp
    a856:	ff 36 58 18          	push   WORD PTR ds:0x1858
    a85a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    a85e:	c7 86 cc fb 01 00    	mov    WORD PTR [bp-0x434],0x1
    a864:	eb 04                	jmp    0xa86a
    a866:	ff 86 cc fb          	inc    WORD PTR [bp-0x434]
    a86a:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    a86d:	99                   	cwd
    a86e:	89 86 66 fb          	mov    WORD PTR [bp-0x49a],ax
    a872:	89 96 68 fb          	mov    WORD PTR [bp-0x498],dx
    a876:	c6 86 6a fb 00       	mov    BYTE PTR [bp-0x496],0x0
    a87b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    a87e:	99                   	cwd
    a87f:	89 86 6e fb          	mov    WORD PTR [bp-0x492],ax
    a883:	89 96 70 fb          	mov    WORD PTR [bp-0x490],dx
    a887:	c6 86 72 fb 00       	mov    BYTE PTR [bp-0x48e],0x0
    a88c:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    a890:	99                   	cwd
    a891:	89 86 76 fb          	mov    WORD PTR [bp-0x48a],ax
    a895:	89 96 78 fb          	mov    WORD PTR [bp-0x488],dx
    a899:	c6 86 7a fb 00       	mov    BYTE PTR [bp-0x486],0x0
    a89e:	8d be 66 fb          	lea    di,[bp-0x49a]
    a8a2:	16                   	push   ss
    a8a3:	57                   	push   di
    a8a4:	6a 02                	push   0x2
    a8a6:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a8aa:	06                   	push   es
    a8ab:	57                   	push   di
    a8ac:	9a 95 28 5f ac       	call   0xac5f:0x2895
    a8b1:	08 c0                	or     al,al
    a8b3:	75 0a                	jne    0xa8bf
    a8b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    a8b8:	06                   	push   es
    a8b9:	57                   	push   di
    a8ba:	9a 03 03 72 aa       	call   0xaa72:0x303
    a8bf:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a8c3:	06                   	push   es
    a8c4:	57                   	push   di
    a8c5:	9a 3c 53 fa a8       	call   0xa8fa:0x533c
    a8ca:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    a8ce:	99                   	cwd
    a8cf:	bf 72 7d             	mov    di,0x7d72
    a8d2:	9a 16 04 14 a9       	call   0xa914:0x416
    a8d7:	8b f8                	mov    di,ax
    a8d9:	c1 e7 03             	shl    di,0x3
    a8dc:	ff b3 9c fc          	push   WORD PTR [bp+di-0x364]
    a8e0:	ff b3 9a fc          	push   WORD PTR [bp+di-0x366]
    a8e4:	ff b3 98 fc          	push   WORD PTR [bp+di-0x368]
    a8e8:	ff b3 96 fc          	push   WORD PTR [bp+di-0x36a]
    a8ec:	bf 66 7d             	mov    di,0x7d66
    a8ef:	0e                   	push   cs
    a8f0:	57                   	push   di
    a8f1:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a8f5:	06                   	push   es
    a8f6:	57                   	push   di
    a8f7:	9a 9b 3b 39 a9       	call   0xa939:0x3b9b
    a8fc:	89 c7                	mov    di,ax
    a8fe:	8e c2                	mov    es,dx
    a900:	06                   	push   es
    a901:	57                   	push   di
    a902:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a905:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a909:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    a90d:	99                   	cwd
    a90e:	bf 72 7d             	mov    di,0x7d72
    a911:	9a 16 04 53 a9       	call   0xa953:0x416
    a916:	8b f8                	mov    di,ax
    a918:	c1 e7 03             	shl    di,0x3
    a91b:	ff b3 8c fc          	push   WORD PTR [bp+di-0x374]
    a91f:	ff b3 8a fc          	push   WORD PTR [bp+di-0x376]
    a923:	ff b3 88 fc          	push   WORD PTR [bp+di-0x378]
    a927:	ff b3 86 fc          	push   WORD PTR [bp+di-0x37a]
    a92b:	bf 7a 7d             	mov    di,0x7d7a
    a92e:	0e                   	push   cs
    a92f:	57                   	push   di
    a930:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a934:	06                   	push   es
    a935:	57                   	push   di
    a936:	9a 9b 3b 78 a9       	call   0xa978:0x3b9b
    a93b:	89 c7                	mov    di,ax
    a93d:	8e c2                	mov    es,dx
    a93f:	06                   	push   es
    a940:	57                   	push   di
    a941:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a944:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a948:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    a94c:	99                   	cwd
    a94d:	bf 72 7d             	mov    di,0x7d72
    a950:	9a 16 04 92 a9       	call   0xa992:0x416
    a955:	8b f8                	mov    di,ax
    a957:	c1 e7 03             	shl    di,0x3
    a95a:	ff b3 4c fc          	push   WORD PTR [bp+di-0x3b4]
    a95e:	ff b3 4a fc          	push   WORD PTR [bp+di-0x3b6]
    a962:	ff b3 48 fc          	push   WORD PTR [bp+di-0x3b8]
    a966:	ff b3 46 fc          	push   WORD PTR [bp+di-0x3ba]
    a96a:	bf 8b 7d             	mov    di,0x7d8b
    a96d:	0e                   	push   cs
    a96e:	57                   	push   di
    a96f:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a973:	06                   	push   es
    a974:	57                   	push   di
    a975:	9a 9b 3b b7 a9       	call   0xa9b7:0x3b9b
    a97a:	89 c7                	mov    di,ax
    a97c:	8e c2                	mov    es,dx
    a97e:	06                   	push   es
    a97f:	57                   	push   di
    a980:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a983:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a987:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    a98b:	99                   	cwd
    a98c:	bf 72 7d             	mov    di,0x7d72
    a98f:	9a 16 04 d1 a9       	call   0xa9d1:0x416
    a994:	8b f8                	mov    di,ax
    a996:	c1 e7 03             	shl    di,0x3
    a999:	ff b3 6c fc          	push   WORD PTR [bp+di-0x394]
    a99d:	ff b3 6a fc          	push   WORD PTR [bp+di-0x396]
    a9a1:	ff b3 68 fc          	push   WORD PTR [bp+di-0x398]
    a9a5:	ff b3 66 fc          	push   WORD PTR [bp+di-0x39a]
    a9a9:	bf a1 7d             	mov    di,0x7da1
    a9ac:	0e                   	push   cs
    a9ad:	57                   	push   di
    a9ae:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a9b2:	06                   	push   es
    a9b3:	57                   	push   di
    a9b4:	9a 9b 3b f6 a9       	call   0xa9f6:0x3b9b
    a9b9:	89 c7                	mov    di,ax
    a9bb:	8e c2                	mov    es,dx
    a9bd:	06                   	push   es
    a9be:	57                   	push   di
    a9bf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    a9c2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    a9c6:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    a9ca:	99                   	cwd
    a9cb:	bf 72 7d             	mov    di,0x7d72
    a9ce:	9a 16 04 10 aa       	call   0xaa10:0x416
    a9d3:	8b f8                	mov    di,ax
    a9d5:	c1 e7 03             	shl    di,0x3
    a9d8:	ff b3 7c fc          	push   WORD PTR [bp+di-0x384]
    a9dc:	ff b3 7a fc          	push   WORD PTR [bp+di-0x386]
    a9e0:	ff b3 78 fc          	push   WORD PTR [bp+di-0x388]
    a9e4:	ff b3 76 fc          	push   WORD PTR [bp+di-0x38a]
    a9e8:	bf b3 7d             	mov    di,0x7db3
    a9eb:	0e                   	push   cs
    a9ec:	57                   	push   di
    a9ed:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    a9f1:	06                   	push   es
    a9f2:	57                   	push   di
    a9f3:	9a 9b 3b 35 aa       	call   0xaa35:0x3b9b
    a9f8:	89 c7                	mov    di,ax
    a9fa:	8e c2                	mov    es,dx
    a9fc:	06                   	push   es
    a9fd:	57                   	push   di
    a9fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    aa01:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    aa05:	8b 86 cc fb          	mov    ax,WORD PTR [bp-0x434]
    aa09:	99                   	cwd
    aa0a:	bf 72 7d             	mov    di,0x7d72
    aa0d:	9a 16 04 34 ab       	call   0xab34:0x416
    aa12:	8b f8                	mov    di,ax
    aa14:	c1 e7 03             	shl    di,0x3
    aa17:	ff b3 5c fc          	push   WORD PTR [bp+di-0x3a4]
    aa1b:	ff b3 5a fc          	push   WORD PTR [bp+di-0x3a6]
    aa1f:	ff b3 58 fc          	push   WORD PTR [bp+di-0x3a8]
    aa23:	ff b3 56 fc          	push   WORD PTR [bp+di-0x3aa]
    aa27:	bf c7 7d             	mov    di,0x7dc7
    aa2a:	0e                   	push   cs
    aa2b:	57                   	push   di
    aa2c:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    aa30:	06                   	push   es
    aa31:	57                   	push   di
    aa32:	9a 9b 3b 4d aa       	call   0xaa4d:0x3b9b
    aa37:	89 c7                	mov    di,ax
    aa39:	8e c2                	mov    es,dx
    aa3b:	06                   	push   es
    aa3c:	57                   	push   di
    aa3d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    aa40:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    aa44:	c4 be 7e fb          	les    di,DWORD PTR [bp-0x482]
    aa48:	06                   	push   es
    aa49:	57                   	push   di
    aa4a:	9a a0 54 6e aa       	call   0xaa6e:0x54a0
    aa4f:	83 be cc fb 02       	cmp    WORD PTR [bp-0x434],0x2
    aa54:	74 03                	je     0xaa59
    aa56:	e9 0d fe             	jmp    0xa866
    aa59:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    aa5d:	83 c4 06             	add    sp,0x6
    aa60:	b8 66 aa             	mov    ax,0xaa66
    aa63:	0e                   	push   cs
    aa64:	50                   	push   ax
    aa65:	cb                   	retf
    aa66:	c9                   	leave
    aa67:	ca 08 00             	retf   0x8
    aa6a:	02 00                	add    al,BYTE PTR [bx+si]
    aa6c:	2f                   	das
    aa6d:	00 0b                	add    BYTE PTR [bp+di],cl
    aa6f:	ab                   	stos   WORD PTR es:[di],ax
    aa70:	9e                   	sahf
    aa71:	ab                   	stos   WORD PTR es:[di],ax
    aa72:	7a aa                	jp     0xaa1e
    aa74:	00 00                	add    BYTE PTR [bx+si],al
    aa76:	00 00                	add    BYTE PTR [bx+si],al
    aa78:	ad                   	lods   ax,WORD PTR ds:[si]
    aa79:	ab                   	stos   WORD PTR es:[di],ax
    aa7a:	8b aa 0a 56          	mov    bp,WORD PTR [bp+si+0x560a]
    aa7e:	61                   	popa
    aa7f:	6c                   	ins    BYTE PTR es:[di],dx
    aa80:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    aa85:	6f                   	outs   dx,WORD PTR ds:[si]
    aa86:	6e                   	outs   dx,BYTE PTR ds:[si]
    aa87:	00 00                	add    BYTE PTR [bx+si],al
    aa89:	b0 ac                	mov    al,0xac
    aa8b:	91                   	xchg   cx,ax
    aa8c:	aa                   	stos   BYTE PTR es:[di],al
    aa8d:	00 00                	add    BYTE PTR [bx+si],al
    aa8f:	f3 ac                	rep lods al,BYTE PTR ds:[si]
    aa91:	a2 aa 0a             	mov    ds:0xaaa,al
    aa94:	56                   	push   si
    aa95:	61                   	popa
    aa96:	6c                   	ins    BYTE PTR es:[di],dx
    aa97:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    aa9c:	6f                   	outs   dx,WORD PTR ds:[si]
    aa9d:	6e                   	outs   dx,BYTE PTR ds:[si]
    aa9e:	00 00                	add    BYTE PTR [bx+si],al
    aaa0:	e7 ad                	out    0xad,ax
    aaa2:	a8 aa                	test   al,0xaa
    aaa4:	00 00                	add    BYTE PTR [bx+si],al
    aaa6:	2a ae ae aa          	sub    ch,BYTE PTR [bp-0x5552]
    aaaa:	00 00                	add    BYTE PTR [bx+si],al
    aaac:	6d                   	ins    WORD PTR es:[di],dx
    aaad:	ae                   	scas   al,BYTE PTR es:[di]
    aaae:	c3                   	ret
    aaaf:	aa                   	stos   BYTE PTR es:[di],al
    aab0:	0e                   	push   cs
    aab1:	50                   	push   ax
    aab2:	65 72 69             	gs jb  0xab1e
    aab5:	6f                   	outs   dx,WORD PTR ds:[si]
    aab6:	64 65 45             	fs gs inc bp
    aab9:	6e                   	outs   dx,BYTE PTR ds:[si]
    aaba:	63 6f 75             	arpl   WORD PTR [bx+0x75],bp
    aabd:	72 73                	jb     0xab32
    aabf:	00 00                	add    BYTE PTR [bx+si],al
    aac1:	1b af 0f ab          	sbb    bp,WORD PTR [bx-0x54f1]
    aac5:	17                   	pop    ss
    aac6:	48                   	dec    ax
    aac7:	41                   	inc    cx
    aac8:	50                   	push   ax
    aac9:	50                   	push   ax
    aaca:	59                   	pop    cx
    aacb:	20 4e 45             	and    BYTE PTR [bp+0x45],cl
    aace:	57                   	push   di
    aacf:	20 50 45             	and    BYTE PTR [bx+si+0x45],dl
    aad2:	52                   	push   dx
    aad3:	49                   	dec    cx
    aad4:	4f                   	dec    di
    aad5:	44                   	inc    sp
    aad6:	45                   	inc    bp
    aad7:	20 6e b0             	and    BYTE PTR [bp-0x50],ch
    aada:	20 20                	and    BYTE PTR [bx+si],ah
    aadc:	20 02                	and    BYTE PTR [bp+si],al
    aade:	20 21                	and    BYTE PTR [bx+di],ah
    aae0:	01 00                	add    WORD PTR [bx+si],ax
    aae2:	24 45                	and    al,0x45
    aae4:	74 20                	je     0xab06
    aae6:	65 6e                	outs   dx,BYTE PTR gs:[si]
    aae8:	63 6f 72             	arpl   WORD PTR [bx+0x72],bp
    aaeb:	65 20 75 6e          	and    BYTE PTR gs:[di+0x6e],dh
    aaef:	65 20 70 e9          	and    BYTE PTR gs:[bx+si-0x17],dh
    aaf3:	72 69                	jb     0xab5e
    aaf5:	6f                   	outs   dx,WORD PTR ds:[si]
    aaf6:	64 65 20 64 65       	fs and BYTE PTR gs:[si+0x65],ah
    aafb:	20 70 61             	and    BYTE PTR [bx+si+0x61],dh
    aafe:	73 73                	jae    0xab73
    ab00:	e9 65 20             	jmp    0xcb68
    ab03:	2e 2e 2e 00 02       	cs cs add BYTE PTR cs:[bp+si],al
    ab08:	00 2f                	add    BYTE PTR [bx],ch
    ab0a:	00 1d                	add    BYTE PTR [di],bl
    ab0c:	ab                   	stos   WORD PTR es:[di],ax
    ab0d:	a2 af 17             	mov    ds:0x17af,al
    ab10:	ab                   	stos   WORD PTR es:[di],ax
    ab11:	00 00                	add    BYTE PTR [bx+si],al
    ab13:	00 00                	add    BYTE PTR [bx+si],al
    ab15:	b1 af                	mov    cl,0xaf
    ab17:	21 ab 02 00          	and    WORD PTR [bp+di+0x2],bp
    ab1b:	2f                   	das
    ab1c:	00 25                	add    BYTE PTR [di],ah
    ab1e:	ab                   	stos   WORD PTR es:[di],ax
    ab1f:	c4 af 29 ab          	les    bp,DWORD PTR [bx-0x54d7]
    ab23:	5e                   	pop    si
    ab24:	00 78 ac             	add    BYTE PTR [bx+si-0x54],bh
    ab27:	db af c2 ab          	fld    TBYTE PTR [bx-0x543e]
    ab2b:	55                   	push   bp
    ab2c:	89 e5                	mov    bp,sp
    ab2e:	b8 06 04             	mov    ax,0x406
    ab31:	9a 44 04 a9 ab       	call   0xaba9:0x444
    ab36:	81 ec 06 04          	sub    sp,0x406
    ab3a:	b8 19 ab             	mov    ax,0xab19
    ab3d:	0e                   	push   cs
    ab3e:	50                   	push   ax
    ab3f:	55                   	push   bp
    ab40:	ff 36 58 18          	push   WORD PTR ds:0x1858
    ab44:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    ab48:	b8 6a aa             	mov    ax,0xaa6a
    ab4b:	0e                   	push   cs
    ab4c:	50                   	push   ax
    ab4d:	55                   	push   bp
    ab4e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    ab52:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    ab56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ab59:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    ab5e:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    ab63:	ff 76 0a             	push   WORD PTR [bp+0xa]
    ab66:	9a 8a 3a 7e ab       	call   0xab7e:0x3a8a
    ab6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ab6e:	26 ff b5 96 01       	push   WORD PTR es:[di+0x196]
    ab73:	26 ff b5 94 01       	push   WORD PTR es:[di+0x194]
    ab78:	ff 76 0a             	push   WORD PTR [bp+0xa]
    ab7b:	9a 36 44 93 ab       	call   0xab93:0x4436
    ab80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ab83:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    ab88:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    ab8d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    ab90:	9a d0 47 31 ac       	call   0xac31:0x47d0
    ab95:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    ab99:	83 c4 06             	add    sp,0x6
    ab9c:	eb 19                	jmp    0xabb7
    ab9e:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    aba2:	89 96 fc fd          	mov    WORD PTR [bp-0x204],dx
    aba6:	ea 85 13 b0 ab       	jmp    0xabb0:0x1385
    abab:	eb 05                	jmp    0xabb2
    abad:	ea 85 13 b5 ab       	jmp    0xabb5:0x1385
    abb2:	9a 34 14 2b ac       	call   0xac2b:0x1434
    abb7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    abba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    abbd:	06                   	push   es
    abbe:	57                   	push   di
    abbf:	9a 6e 21 ea ab       	call   0xabea:0x216e
    abc4:	a1 4e 01             	mov    ax,ds:0x14e
    abc7:	89 86 fc fd          	mov    WORD PTR [bp-0x204],ax
    abcb:	b8 01 00             	mov    ax,0x1
    abce:	3b 86 fc fd          	cmp    ax,WORD PTR [bp-0x204]
    abd2:	7f 21                	jg     0xabf5
    abd4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    abd7:	eb 03                	jmp    0xabdc
    abd9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    abdc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    abdf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    abe2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    abe5:	06                   	push   es
    abe6:	57                   	push   di
    abe7:	9a dc 7d 6d ac       	call   0xac6d:0x7ddc
    abec:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    abef:	3b 86 fc fd          	cmp    ax,WORD PTR [bp-0x204]
    abf3:	75 e4                	jne    0xabd9
    abf5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    abf8:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    abfd:	89 be fa fd          	mov    WORD PTR [bp-0x206],di
    ac01:	8c 86 fc fd          	mov    WORD PTR [bp-0x204],es
    ac05:	b8 87 aa             	mov    ax,0xaa87
    ac08:	0e                   	push   cs
    ac09:	50                   	push   ax
    ac0a:	55                   	push   bp
    ac0b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    ac0f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    ac13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ac16:	26 ff b5 82 01       	push   WORD PTR es:[di+0x182]
    ac1b:	26 ff b5 80 01       	push   WORD PTR es:[di+0x180]
    ac20:	a1 4c 01             	mov    ax,ds:0x14c
    ac23:	05 01 00             	add    ax,0x1
    ac26:	71 05                	jno    0xac2d
    ac28:	9a 3e 04 3e ac       	call   0xac3e:0x43e
    ac2d:	50                   	push   ax
    ac2e:	9a 43 18 e5 ac       	call   0xace5:0x1843
    ac33:	a1 4c 01             	mov    ax,ds:0x14c
    ac36:	05 01 00             	add    ax,0x1
    ac39:	71 05                	jno    0xac40
    ac3b:	9a 3e 04 df ac       	call   0xacdf:0x43e
    ac40:	99                   	cwd
    ac41:	89 86 f2 fd          	mov    WORD PTR [bp-0x20e],ax
    ac45:	89 96 f4 fd          	mov    WORD PTR [bp-0x20c],dx
    ac49:	c6 86 f6 fd 00       	mov    BYTE PTR [bp-0x20a],0x0
    ac4e:	8d be f2 fd          	lea    di,[bp-0x20e]
    ac52:	16                   	push   ss
    ac53:	57                   	push   di
    ac54:	6a 00                	push   0x0
    ac56:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    ac5a:	06                   	push   es
    ac5b:	57                   	push   di
    ac5c:	9a 95 28 8a ad       	call   0xad8a:0x2895
    ac61:	08 c0                	or     al,al
    ac63:	75 0a                	jne    0xac6f
    ac65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ac68:	06                   	push   es
    ac69:	57                   	push   di
    ac6a:	9a 03 03 98 ad       	call   0xad98:0x303
    ac6f:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    ac73:	06                   	push   es
    ac74:	57                   	push   di
    ac75:	9a 3c 53 8a ac       	call   0xac8a:0x533c
    ac7a:	6a 00                	push   0x0
    ac7c:	bf 7c aa             	mov    di,0xaa7c
    ac7f:	0e                   	push   cs
    ac80:	57                   	push   di
    ac81:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    ac85:	06                   	push   es
    ac86:	57                   	push   di
    ac87:	9a 9b 3b a2 ac       	call   0xaca2:0x3b9b
    ac8c:	89 c7                	mov    di,ax
    ac8e:	8e c2                	mov    es,dx
    ac90:	06                   	push   es
    ac91:	57                   	push   di
    ac92:	26 c4 3d             	les    di,DWORD PTR es:[di]
    ac95:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    ac99:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    ac9d:	06                   	push   es
    ac9e:	57                   	push   di
    ac9f:	9a a0 54 a3 ad       	call   0xada3:0x54a0
    aca4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    aca8:	83 c4 06             	add    sp,0x6
    acab:	b8 b1 ac             	mov    ax,0xacb1
    acae:	0e                   	push   cs
    acaf:	50                   	push   ax
    acb0:	cb                   	retf
    acb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    acb4:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    acb9:	b8 8d aa             	mov    ax,0xaa8d
    acbc:	0e                   	push   cs
    acbd:	50                   	push   ax
    acbe:	55                   	push   bp
    acbf:	ff 36 58 18          	push   WORD PTR ds:0x1858
    acc3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    acc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    acca:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    accf:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    acd4:	a1 4c 01             	mov    ax,ds:0x14c
    acd7:	05 01 00             	add    ax,0x1
    acda:	71 05                	jno    0xace1
    acdc:	9a 3e 04 2a ad       	call   0xad2a:0x43e
    ace1:	50                   	push   ax
    ace2:	9a 9b 20 30 ad       	call   0xad30:0x209b
    ace7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    aceb:	83 c4 06             	add    sp,0x6
    acee:	b8 f4 ac             	mov    ax,0xacf4
    acf1:	0e                   	push   cs
    acf2:	50                   	push   ax
    acf3:	cb                   	retf
    acf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    acf7:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    acfc:	89 be fa fd          	mov    WORD PTR [bp-0x206],di
    ad00:	8c 86 fc fd          	mov    WORD PTR [bp-0x204],es
    ad04:	b8 9e aa             	mov    ax,0xaa9e
    ad07:	0e                   	push   cs
    ad08:	50                   	push   ax
    ad09:	55                   	push   bp
    ad0a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    ad0e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    ad12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ad15:	26 ff b5 8a 01       	push   WORD PTR es:[di+0x18a]
    ad1a:	26 ff b5 88 01       	push   WORD PTR es:[di+0x188]
    ad1f:	a1 4c 01             	mov    ax,ds:0x14c
    ad22:	05 01 00             	add    ax,0x1
    ad25:	71 05                	jno    0xad2c
    ad27:	9a 3e 04 58 ad       	call   0xad58:0x43e
    ad2c:	50                   	push   ax
    ad2d:	9a 32 26 1c ae       	call   0xae1c:0x2632
    ad32:	a1 4e 01             	mov    ax,ds:0x14e
    ad35:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    ad39:	b8 01 00             	mov    ax,0x1
    ad3c:	3b 86 f8 fd          	cmp    ax,WORD PTR [bp-0x208]
    ad40:	7e 03                	jle    0xad45
    ad42:	e9 96 00             	jmp    0xaddb
    ad45:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    ad48:	eb 03                	jmp    0xad4d
    ad4a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    ad4d:	a1 4c 01             	mov    ax,ds:0x14c
    ad50:	05 01 00             	add    ax,0x1
    ad53:	71 05                	jno    0xad5a
    ad55:	9a 3e 04 16 ae       	call   0xae16:0x43e
    ad5a:	99                   	cwd
    ad5b:	89 86 e8 fd          	mov    WORD PTR [bp-0x218],ax
    ad5f:	89 96 ea fd          	mov    WORD PTR [bp-0x216],dx
    ad63:	c6 86 ec fd 00       	mov    BYTE PTR [bp-0x214],0x0
    ad68:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    ad6b:	99                   	cwd
    ad6c:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    ad70:	89 96 f2 fd          	mov    WORD PTR [bp-0x20e],dx
    ad74:	c6 86 f4 fd 00       	mov    BYTE PTR [bp-0x20c],0x0
    ad79:	8d be e8 fd          	lea    di,[bp-0x218]
    ad7d:	16                   	push   ss
    ad7e:	57                   	push   di
    ad7f:	6a 01                	push   0x1
    ad81:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    ad85:	06                   	push   es
    ad86:	57                   	push   di
    ad87:	9a 95 28 bc ae       	call   0xaebc:0x2895
    ad8c:	08 c0                	or     al,al
    ad8e:	75 0a                	jne    0xad9a
    ad90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ad93:	06                   	push   es
    ad94:	57                   	push   di
    ad95:	9a 03 03 ca ae       	call   0xaeca:0x303
    ad9a:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    ad9e:	06                   	push   es
    ad9f:	57                   	push   di
    ada0:	9a 3c 53 b5 ad       	call   0xadb5:0x533c
    ada5:	6a 00                	push   0x0
    ada7:	bf 93 aa             	mov    di,0xaa93
    adaa:	0e                   	push   cs
    adab:	57                   	push   di
    adac:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    adb0:	06                   	push   es
    adb1:	57                   	push   di
    adb2:	9a 9b 3b cd ad       	call   0xadcd:0x3b9b
    adb7:	89 c7                	mov    di,ax
    adb9:	8e c2                	mov    es,dx
    adbb:	06                   	push   es
    adbc:	57                   	push   di
    adbd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    adc0:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    adc4:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    adc8:	06                   	push   es
    adc9:	57                   	push   di
    adca:	9a a0 54 d5 ae       	call   0xaed5:0x54a0
    adcf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    add2:	3b 86 f8 fd          	cmp    ax,WORD PTR [bp-0x208]
    add6:	74 03                	je     0xaddb
    add8:	e9 6f ff             	jmp    0xad4a
    addb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    addf:	83 c4 06             	add    sp,0x6
    ade2:	b8 e8 ad             	mov    ax,0xade8
    ade5:	0e                   	push   cs
    ade6:	50                   	push   ax
    ade7:	cb                   	retf
    ade8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    adeb:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    adf0:	b8 a4 aa             	mov    ax,0xaaa4
    adf3:	0e                   	push   cs
    adf4:	50                   	push   ax
    adf5:	55                   	push   bp
    adf6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    adfa:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    adfe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ae01:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    ae06:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    ae0b:	a1 4c 01             	mov    ax,ds:0x14c
    ae0e:	05 01 00             	add    ax,0x1
    ae11:	71 05                	jno    0xae18
    ae13:	9a 3e 04 59 ae       	call   0xae59:0x43e
    ae18:	50                   	push   ax
    ae19:	9a cb 2b 5f ae       	call   0xae5f:0x2bcb
    ae1e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    ae22:	83 c4 06             	add    sp,0x6
    ae25:	b8 2b ae             	mov    ax,0xae2b
    ae28:	0e                   	push   cs
    ae29:	50                   	push   ax
    ae2a:	cb                   	retf
    ae2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ae2e:	26 c4 bd d8 01       	les    di,DWORD PTR es:[di+0x1d8]
    ae33:	b8 aa aa             	mov    ax,0xaaaa
    ae36:	0e                   	push   cs
    ae37:	50                   	push   ax
    ae38:	55                   	push   bp
    ae39:	ff 36 58 18          	push   WORD PTR ds:0x1858
    ae3d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    ae41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ae44:	26 ff b5 da 01       	push   WORD PTR es:[di+0x1da]
    ae49:	26 ff b5 d8 01       	push   WORD PTR es:[di+0x1d8]
    ae4e:	a1 4c 01             	mov    ax,ds:0x14c
    ae51:	05 01 00             	add    ax,0x1
    ae54:	71 05                	jno    0xae5b
    ae56:	9a 3e 04 e2 ae       	call   0xaee2:0x43e
    ae5b:	50                   	push   ax
    ae5c:	9a 18 30 ff ff       	call   0xffff:0x3018
    ae61:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    ae65:	83 c4 06             	add    sp,0x6
    ae68:	b8 6e ae             	mov    ax,0xae6e
    ae6b:	0e                   	push   cs
    ae6c:	50                   	push   ax
    ae6d:	cb                   	retf
    ae6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    ae71:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    ae76:	89 be fa fd          	mov    WORD PTR [bp-0x206],di
    ae7a:	8c 86 fc fd          	mov    WORD PTR [bp-0x204],es
    ae7e:	b8 07 ab             	mov    ax,0xab07
    ae81:	0e                   	push   cs
    ae82:	50                   	push   ax
    ae83:	55                   	push   bp
    ae84:	ff 36 58 18          	push   WORD PTR ds:0x1858
    ae88:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    ae8c:	b8 bf aa             	mov    ax,0xaabf
    ae8f:	0e                   	push   cs
    ae90:	50                   	push   ax
    ae91:	55                   	push   bp
    ae92:	ff 36 58 18          	push   WORD PTR ds:0x1858
    ae96:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    ae9a:	c7 86 f2 fd 01 00    	mov    WORD PTR [bp-0x20e],0x1
    aea0:	c7 86 f4 fd 00 00    	mov    WORD PTR [bp-0x20c],0x0
    aea6:	c6 86 f6 fd 00       	mov    BYTE PTR [bp-0x20a],0x0
    aeab:	8d be f2 fd          	lea    di,[bp-0x20e]
    aeaf:	16                   	push   ss
    aeb0:	57                   	push   di
    aeb1:	6a 00                	push   0x0
    aeb3:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    aeb7:	06                   	push   es
    aeb8:	57                   	push   di
    aeb9:	9a 95 28 ff ff       	call   0xffff:0x2895
    aebe:	08 c0                	or     al,al
    aec0:	75 0a                	jne    0xaecc
    aec2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    aec5:	06                   	push   es
    aec6:	57                   	push   di
    aec7:	9a 03 03 ff ff       	call   0xffff:0x303
    aecc:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    aed0:	06                   	push   es
    aed1:	57                   	push   di
    aed2:	9a 3c 53 f5 ae       	call   0xaef5:0x533c
    aed7:	a1 4c 01             	mov    ax,ds:0x14c
    aeda:	05 01 00             	add    ax,0x1
    aedd:	71 05                	jno    0xaee4
    aedf:	9a 3e 04 2e af       	call   0xaf2e:0x43e
    aee4:	99                   	cwd
    aee5:	52                   	push   dx
    aee6:	50                   	push   ax
    aee7:	bf b0 aa             	mov    di,0xaab0
    aeea:	0e                   	push   cs
    aeeb:	57                   	push   di
    aeec:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    aef0:	06                   	push   es
    aef1:	57                   	push   di
    aef2:	9a 9b 3b 0d af       	call   0xaf0d:0x3b9b
    aef7:	89 c7                	mov    di,ax
    aef9:	8e c2                	mov    es,dx
    aefb:	06                   	push   es
    aefc:	57                   	push   di
    aefd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    af00:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    af04:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    af08:	06                   	push   es
    af09:	57                   	push   di
    af0a:	9a a0 54 ff ff       	call   0xffff:0x54a0
    af0f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    af13:	83 c4 06             	add    sp,0x6
    af16:	b8 1c af             	mov    ax,0xaf1c
    af19:	0e                   	push   cs
    af1a:	50                   	push   ax
    af1b:	cb                   	retf
    af1c:	ff 06 4c 01          	inc    WORD PTR ds:0x14c
    af20:	8d be fa fb          	lea    di,[bp-0x406]
    af24:	16                   	push   ss
    af25:	57                   	push   di
    af26:	bf c5 aa             	mov    di,0xaac5
    af29:	0e                   	push   cs
    af2a:	57                   	push   di
    af2b:	9a cd 17 44 af       	call   0xaf44:0x17cd
    af30:	8d be fa fc          	lea    di,[bp-0x306]
    af34:	16                   	push   ss
    af35:	57                   	push   di
    af36:	a1 4c 01             	mov    ax,ds:0x14c
    af39:	99                   	cwd
    af3a:	52                   	push   dx
    af3b:	50                   	push   ax
    af3c:	9a a9 08 ff ff       	call   0xffff:0x8a9
    af41:	9a 4c 18 4e af       	call   0xaf4e:0x184c
    af46:	bf dd aa             	mov    di,0xaadd
    af49:	0e                   	push   cs
    af4a:	57                   	push   di
    af4b:	9a 4c 18 58 af       	call   0xaf58:0x184c
    af50:	bf e0 aa             	mov    di,0xaae0
    af53:	0e                   	push   cs
    af54:	57                   	push   di
    af55:	9a 4c 18 66 af       	call   0xaf66:0x184c
    af5a:	8d be fe fd          	lea    di,[bp-0x202]
    af5e:	16                   	push   ss
    af5f:	57                   	push   di
    af60:	68 ff 00             	push   0xff
    af63:	9a e7 17 79 af       	call   0xaf79:0x17e7
    af68:	bf e2 aa             	mov    di,0xaae2
    af6b:	0e                   	push   cs
    af6c:	57                   	push   di
    af6d:	8d be fe fe          	lea    di,[bp-0x102]
    af71:	16                   	push   ss
    af72:	57                   	push   di
    af73:	68 ff 00             	push   0xff
    af76:	9a e7 17 ad af       	call   0xafad:0x17e7
    af7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    af7e:	06                   	push   es
    af7f:	57                   	push   di
    af80:	9a b9 62 ff ff       	call   0xffff:0x62b9
    af85:	50                   	push   ax
    af86:	8d be ff fd          	lea    di,[bp-0x201]
    af8a:	16                   	push   ss
    af8b:	57                   	push   di
    af8c:	8d be ff fe          	lea    di,[bp-0x101]
    af90:	16                   	push   ss
    af91:	57                   	push   di
    af92:	6a 30                	push   0x30
    af94:	9a ff ff 00 00       	call   0x0:0xffff
    af99:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    af9d:	83 c4 06             	add    sp,0x6
    afa0:	eb 19                	jmp    0xafbb
    afa2:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    afa6:	89 96 f8 fd          	mov    WORD PTR [bp-0x208],dx
    afaa:	ea 85 13 b4 af       	jmp    0xafb4:0x1385
    afaf:	eb 05                	jmp    0xafb6
    afb1:	ea 85 13 b9 af       	jmp    0xafb9:0x1385
    afb6:	9a 34 14 f3 af       	call   0xaff3:0x1434
    afbb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    afbf:	83 c4 06             	add    sp,0x6
    afc2:	eb 31                	jmp    0xaff5
    afc4:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    afc8:	89 96 fc fd          	mov    WORD PTR [bp-0x204],dx
    afcc:	ff b6 fc fd          	push   WORD PTR [bp-0x204]
    afd0:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    afd4:	9a 2d 34 ee af       	call   0xafee:0x342d
    afd9:	eb 15                	jmp    0xaff0
    afdb:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    afdf:	89 96 f8 fd          	mov    WORD PTR [bp-0x208],dx
    afe3:	ff b6 f8 fd          	push   WORD PTR [bp-0x208]
    afe7:	ff b6 f6 fd          	push   WORD PTR [bp-0x20a]
    afeb:	9a 2d 34 ff ff       	call   0xffff:0x342d
    aff0:	9a 34 14 ff ff       	call   0xffff:0x1434
    aff5:	c9                   	leave
    aff6:	ca                   	.byte 0xca
    aff7:	06                   	push   es
