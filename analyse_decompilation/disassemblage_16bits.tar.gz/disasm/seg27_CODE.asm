; ================================================================
; seg27_CODE  (16344 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	1b 00                	sbb    ax,WORD PTR [bx+si]
       2:	e6 00                	out    0x0,al
       4:	00 00                	add    BYTE PTR [bx+si],al
       6:	00 00                	add    BYTE PTR [bx+si],al
       8:	ae                   	scas   al,BYTE PTR es:[di]
       9:	00 a6 00 09          	add    BYTE PTR [bp+0x900],ah
       d:	01 4f 00             	add    WORD PTR [bx+0x0],cx
      10:	f5                   	cmc
      11:	00 fa                	add    dl,bh
      13:	45                   	inc    bp
      14:	88 00                	mov    BYTE PTR [bx+si],al
      16:	9a 1f 05 01 cb       	call   0xcb01:0x51f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	33 18                	xor    bx,WORD PTR [bx+si]
      20:	c4 00                	les    ax,DWORD PTR [bx+si]
      22:	cd 11                	int    0x11
      24:	2c 00                	sub    al,0x0
      26:	3a 27                	cmp    ah,BYTE PTR [bx]
      28:	30 00                	xor    BYTE PTR [bx+si],al
      2a:	fa                   	cli
      2b:	10 2e 04 d6          	adc    BYTE PTR ds:0xd604,ch
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	44                   	inc    sp
      35:	00 7c 18             	add    BYTE PTR [si+0x18],bh
      38:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
      39:	00 ec                	add    ah,ch
      3b:	30 98 00 51          	xor    BYTE PTR [bx+si+0x5100],bl
      3f:	1b 96 01 38          	sbb    dx,WORD PTR [bp+0x3801]
      43:	50                   	push   ax
      44:	4c                   	dec    sp
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	52                   	push   dx
      4f:	17                   	pop    ss
      50:	20 00                	and    BYTE PTR [bx+si],al
      52:	d9 62 58             	fldenv [bp+si+0x58]
      55:	00 06 63 5c          	add    BYTE PTR ds:0x5c63,al
      59:	00 8f 60 94          	add    BYTE PTR [bx-0x6ba0],cl
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 40                	sbb    al,0x40
      61:	00 46 44             	add    BYTE PTR [bp+0x44],al
      64:	48                   	dec    ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 9c             	bound  bx,DWORD PTR [si-0x64]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	28 00                	sub    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	80 00 5f             	add    BYTE PTR [bx+si],0x5f
      7b:	4a                   	dec    dx
      7c:	84 00                	test   BYTE PTR [bx+si],al
      7e:	17                   	pop    ss
      7f:	3e 14 00             	ds adc al,0x0
      82:	62 4b 30             	bound  cx,DWORD PTR [bp+di+0x30]
      85:	01 ed                	add    bp,bp
      87:	3e 8c 00             	mov    WORD PTR ds:[bx+si],es
      8a:	77 3e                	ja     0xca
      8c:	90                   	nop
      8d:	00 c2                	add    dl,al
      8f:	35 54 00             	xor    ax,0x54
      92:	1c 48                	sbb    al,0x48
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	64 00 35             	add    BYTE PTR fs:[di],dh
      9b:	62 74 00             	bound  si,DWORD PTR [si+0x0]
      9e:	b8 19 38             	mov    ax,0x3819
      a1:	00 d5                	add    ch,dl
      a3:	19 50 00             	sbb    WORD PTR [bx+si+0x0],dx
      a6:	07                   	pop    es
      a7:	54                   	push   sp
      a8:	44                   	inc    sp
      a9:	42                   	inc    dx
      aa:	45                   	inc    bp
      ab:	64 69 74 09 00 00    	imul   si,WORD PTR fs:[si+0x9],0x0
      b1:	03 02                	add    ax,WORD PTR [bp+si]
      b3:	03 1a                	add    bx,WORD PTR [bp+si]
      b5:	0f 1b 0f             	bndstx (bad),bnd1
      b8:	0f 00 0e 0f ee       	str    WORD PTR ds:0xee0f
      bd:	ff f1                	push   cx
      bf:	ff                   	jmp    (bad)
      c0:	ef                   	out    dx,ax
      c1:	ff 33                	push   WORD PTR [bp+di]
      c3:	1d c8 00             	sbb    ax,0xc8
      c6:	0d 1d cc             	or     ax,0xcc1d
      c9:	00 59 1d             	add    BYTE PTR [bx+di+0x1d],bl
      cc:	d0 00                	rol    BYTE PTR [bx+si],1
      ce:	86 1d                	xchg   BYTE PTR [di],bl
      d0:	d4 00                	aam    0x0
      d2:	fe                   	(bad)
      d3:	1d d8 00             	sbb    ax,0xd8
      d6:	5e                   	pop    si
      d7:	20 dc                	and    ah,bl
      d9:	00 3f                	add    BYTE PTR [bx],bh
      db:	1a e0                	sbb    ah,al
      dd:	00 cb                	add    bl,cl
      df:	18 e4                	sbb    ah,ah
      e1:	00 09                	add    BYTE PTR [bx+di],cl
      e3:	19 f1                	sbb    cx,si
      e5:	00 07                	add    BYTE PTR [bx],al
      e7:	07                   	pop    es
      e8:	54                   	push   sp
      e9:	44                   	inc    sp
      ea:	42                   	inc    dx
      eb:	45                   	inc    bp
      ec:	64 69 74 22 00 ce    	imul   si,WORD PTR fs:[si+0x22],0xce00
      f2:	01 2d                	add    WORD PTR [di],bp
      f4:	01 94 02 2f          	add    WORD PTR [si+0x2f02],dx
      f8:	00 07                	add    BYTE PTR [bx],al
      fa:	44                   	inc    sp
      fb:	42                   	inc    dx
      fc:	43                   	inc    bx
      fd:	74 72                	je     0x171
      ff:	6c                   	ins    BYTE PTR es:[di],dx
     100:	73 26                	jae    0x128
     102:	00 07                	add    BYTE PTR [bx],al
     104:	23 28                	and    bp,WORD PTR [bx+si]
     106:	01 de                	add    si,bx
     108:	00 ff                	add    bh,bh
     10a:	ff                   	call   (bad)
     10b:	de 00                	fiadd  WORD PTR [bx+si]
     10d:	ff                   	(bad)
     10e:	ff 01                	inc    WORD PTR [bx+di]
     110:	00 00                	add    BYTE PTR [bx+si],al
     112:	00 00                	add    BYTE PTR [bx+si],al
     114:	80 01 00             	add    BYTE PTR [bx+di],0x0
     117:	00 00                	add    BYTE PTR [bx+si],al
     119:	0a 00                	or     al,BYTE PTR [bx+si]
     11b:	0a 41 75             	or     al,BYTE PTR [bx+di+0x75]
     11e:	74 6f                	je     0x18f
     120:	53                   	push   bx
     121:	65 6c                	gs ins BYTE PTR es:[di],dx
     123:	65 63 74 07          	arpl   WORD PTR gs:[si+0x7],si
     127:	23 ac 01 dd          	and    bp,WORD PTR [si-0x22ff]
     12b:	00 ff                	add    bh,bh
     12d:	ff 9c 47 51          	call   DWORD PTR [si+0x5147]
     131:	01 01                	add    WORD PTR [bx+di],ax
     133:	00 00                	add    BYTE PTR [bx+si],al
     135:	00 00                	add    BYTE PTR [bx+si],al
     137:	80 01 00             	add    BYTE PTR [bx+di],0x0
     13a:	00 00                	add    BYTE PTR [bx+si],al
     13c:	0b 00                	or     ax,WORD PTR [bx+si]
     13e:	08 41 75             	or     BYTE PTR [bx+di+0x75],al
     141:	74 6f                	je     0x1b2
     143:	53                   	push   bx
     144:	69 7a 65 d4 02       	imul   di,WORD PTR [bp+si+0x65],0x2d4
     149:	ff                   	(bad)
     14a:	ff                   	call   (bad)
     14b:	da 00                	fiadd  DWORD PTR [bx+si]
     14d:	ff                   	(bad)
     14e:	ff                   	(bad)
     14f:	bf 47 6d             	mov    di,0x6d47
     152:	01 01                	add    WORD PTR [bx+di],ax
     154:	00 00                	add    BYTE PTR [bx+si],al
     156:	00 00                	add    BYTE PTR [bx+si],al
     158:	80 01 00             	add    BYTE PTR [bx+di],0x0
     15b:	00 00                	add    BYTE PTR [bx+si],al
     15d:	0c 00                	or     al,0x0
     15f:	0b 42 6f             	or     ax,WORD PTR [bp+si+0x6f]
     162:	72 64                	jb     0x1c8
     164:	65 72 53             	gs jb  0x1ba
     167:	74 79                	je     0x1e2
     169:	6c                   	ins    BYTE PTR es:[di],dx
     16a:	65 29 0a             	sub    WORD PTR gs:[bp+si],cx
     16d:	75 01                	jne    0x170
     16f:	e1 00                	loope  0x171
     171:	ff                   	(bad)
     172:	ff                   	jmp    (bad)
     173:	ec                   	in     al,dx
     174:	47                   	inc    di
     175:	4c                   	dec    sp
     176:	03 01                	add    ax,WORD PTR [bx+di]
     178:	00 00                	add    BYTE PTR [bx+si],al
     17a:	00 00                	add    BYTE PTR [bx+si],al
     17c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     17f:	00 00                	add    BYTE PTR [bx+si],al
     181:	0d 00 08             	or     ax,0x800
     184:	43                   	inc    bx
     185:	68 61 72             	push   0x7261
     188:	43                   	inc    bx
     189:	61                   	popa
     18a:	73 65                	jae    0x1f1
     18c:	02 00                	add    al,BYTE PTR [bx+si]
     18e:	73 02                	jae    0x192
     190:	38 00                	cmp    BYTE PTR [bx+si],al
     192:	ff                   	(bad)
     193:	ff d5                	call   bp
     195:	1e                   	push   ds
     196:	9a 01 17 1f b4       	call   0xb41f:0x1701
     19b:	01 00                	add    WORD PTR [bx+si],ax
     19d:	80 fa ff             	cmp    dl,0xff
     1a0:	ff                   	(bad)
     1a1:	ff 0e 00 05          	dec    WORD PTR ds:0x500
     1a5:	43                   	inc    bx
     1a6:	6f                   	outs   dx,WORD PTR ds:[si]
     1a7:	6c                   	ins    BYTE PTR es:[di],dx
     1a8:	6f                   	outs   dx,WORD PTR ds:[si]
     1a9:	72 07                	jb     0x1b2
     1ab:	23 ca                	and    cx,dx
     1ad:	01 a5 00 ff          	add    WORD PTR [di-0x100],sp
     1b1:	ff 22                	jmp    WORD PTR [bp+si]
     1b3:	63 b8 01 54          	arpl   WORD PTR [bx+si+0x5401],di
     1b7:	63 0f                	arpl   WORD PTR [bx],cx
     1b9:	02 00                	add    al,BYTE PTR [bx+si]
     1bb:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1be:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     1c2:	05 43 74             	add    ax,0x7443
     1c5:	6c                   	ins    BYTE PTR es:[di],dx
     1c6:	33 44 62             	xor    ax,WORD PTR [si+0x62]
     1c9:	23 53 02             	and    dx,WORD PTR [bp+di+0x2]
     1cc:	9f                   	lahf
     1cd:	1a d2                	sbb    dl,dl
     1cf:	01 c9                	add    cx,cx
     1d1:	1a f0                	sbb    dh,al
     1d3:	01 01                	add    WORD PTR [bx+di],ax
     1d5:	00 00                	add    BYTE PTR [bx+si],al
     1d7:	00 00                	add    BYTE PTR [bx+si],al
     1d9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1dc:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     1e0:	09 44 61             	or     WORD PTR [si+0x61],ax
     1e3:	74 61                	je     0x246
     1e5:	46                   	inc    si
     1e6:	69 65 6c 64 04       	imul   sp,WORD PTR [di+0x6c],0x464
     1eb:	09 a7 07 5f          	or     WORD PTR [bx+0x5f07],sp
     1ef:	1a f4                	sbb    dh,ah
     1f1:	01 83 1a 8f          	add    WORD PTR [bp+di-0x70e6],ax
     1f5:	03 01                	add    ax,WORD PTR [bx+di]
     1f7:	00 00                	add    BYTE PTR [bx+si],al
     1f9:	00 00                	add    BYTE PTR [bx+si],al
     1fb:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1fe:	00 80 11 00          	add    BYTE PTR [bx+si+0x11],al
     202:	0a 44 61             	or     al,BYTE PTR [si+0x61]
     205:	74 61                	je     0x268
     207:	53                   	push   bx
     208:	6f                   	outs   dx,WORD PTR ds:[si]
     209:	75 72                	jne    0x27d
     20b:	63 65 64             	arpl   WORD PTR [di+0x64],sp
     20e:	00 32                	add    BYTE PTR [bp+si],dh
     210:	02 3e 00 ff          	add    bh,BYTE PTR ds:0xff00
     214:	ff                   	(bad)
     215:	3e 00 ff             	ds add bh,bh
     218:	ff 01                	inc    WORD PTR [bx+di]
     21a:	00 00                	add    BYTE PTR [bx+si],al
     21c:	00 00                	add    BYTE PTR [bx+si],al
     21e:	80 f4 ff             	xor    ah,0xff
     221:	ff                   	(bad)
     222:	ff 12                	call   WORD PTR [bp+si]
     224:	00 0a                	add    BYTE PTR [bp+si],cl
     226:	44                   	inc    sp
     227:	72 61                	jb     0x28a
     229:	67 43                	addr32 inc bx
     22b:	75 72                	jne    0x29f
     22d:	73 6f                	jae    0x29e
     22f:	72 25                	jb     0x256
     231:	01 5b 02             	add    WORD PTR [bp+di+0x2],bx
     234:	2e 00 ff             	cs add bh,bh
     237:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     23b:	ff 01                	inc    WORD PTR [bx+di]
     23d:	00 00                	add    BYTE PTR [bx+si],al
     23f:	00 00                	add    BYTE PTR [bx+si],al
     241:	80 00 00             	add    BYTE PTR [bx+si],0x0
     244:	00 00                	add    BYTE PTR [bx+si],al
     246:	13 00                	adc    ax,WORD PTR [bx+si]
     248:	08 44 72             	or     BYTE PTR [si+0x72],al
     24b:	61                   	popa
     24c:	67 4d                	addr32 dec bp
     24e:	6f                   	outs   dx,WORD PTR ds:[si]
     24f:	64 65 07             	fs gs pop es
     252:	23 90 02 2a          	and    dx,WORD PTR [bx+si+0x2a02]
     256:	00 ff                	add    bh,bh
     258:	ff                   	(bad)
     259:	b8 1c 7b             	mov    ax,0x7b1c
     25c:	02 01                	add    al,BYTE PTR [bx+di]
     25e:	00 00                	add    BYTE PTR [bx+si],al
     260:	00 00                	add    BYTE PTR [bx+si],al
     262:	80 01 00             	add    BYTE PTR [bx+di],0x0
     265:	00 00                	add    BYTE PTR [bx+si],al
     267:	14 00                	adc    al,0x0
     269:	07                   	pop    es
     26a:	45                   	inc    bp
     26b:	6e                   	outs   dx,BYTE PTR ds:[si]
     26c:	61                   	popa
     26d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     270:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     273:	49                   	dec    cx
     274:	07                   	pop    es
     275:	34 00                	xor    al,0x0
     277:	ff                   	(bad)
     278:	ff                   	jmp    (bad)
     279:	eb 1d                	jmp    0x298
     27b:	7f 02                	jg     0x27f
     27d:	08 1e ba 02          	or     BYTE PTR ds:0x2ba,bl
     281:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     285:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     289:	04 46                	add    al,0x46
     28b:	6f                   	outs   dx,WORD PTR ds:[si]
     28c:	6e                   	outs   dx,BYTE PTR ds:[si]
     28d:	74 d4                	je     0x263
     28f:	22 b2 02 55          	and    dh,BYTE PTR [bp+si+0x5502]
     293:	1a 98 02 6b          	sbb    bl,BYTE PTR [bx+si+0x6b02]
     297:	1a 74 17             	sbb    dh,BYTE PTR [si+0x17]
     29a:	01 00                	add    WORD PTR [bx+si],ax
     29c:	00 00                	add    BYTE PTR [bx+si],al
     29e:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     2a2:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     2a6:	09 4d 61             	or     WORD PTR [di+0x61],cx
     2a9:	78 4c                	js     0x2f7
     2ab:	65 6e                	outs   dx,BYTE PTR gs:[si]
     2ad:	67 74 68             	addr32 je 0x318
     2b0:	07                   	pop    es
     2b1:	23 d6                	and    dx,si
     2b3:	02 2c                	add    ch,BYTE PTR [si]
     2b5:	00 ff                	add    bh,bh
     2b7:	ff 32                	push   WORD PTR [bp+si]
     2b9:	1f                   	pop    ds
     2ba:	de 02                	fiadd  WORD PTR [bp+si]
     2bc:	01 00                	add    WORD PTR [bx+si],ax
     2be:	00 00                	add    BYTE PTR [bx+si],al
     2c0:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     2c4:	00 00                	add    BYTE PTR [bx+si],al
     2c6:	17                   	pop    ss
     2c7:	00 0b                	add    BYTE PTR [bp+di],cl
     2c9:	50                   	push   ax
     2ca:	61                   	popa
     2cb:	72 65                	jb     0x332
     2cd:	6e                   	outs   dx,BYTE PTR ds:[si]
     2ce:	74 43                	je     0x313
     2d0:	6f                   	outs   dx,WORD PTR ds:[si]
     2d1:	6c                   	ins    BYTE PTR es:[di],dx
     2d2:	6f                   	outs   dx,WORD PTR ds:[si]
     2d3:	72 07                	jb     0x2dc
     2d5:	23 fa                	and    di,dx
     2d7:	02 a6 00 ff          	add    ah,BYTE PTR [bp-0x100]
     2db:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     2de:	02 03                	add    al,BYTE PTR [bp+di]
     2e0:	01 00                	add    WORD PTR [bx+si],ax
     2e2:	00 00                	add    BYTE PTR [bx+si],al
     2e4:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     2e8:	00 00                	add    BYTE PTR [bx+si],al
     2ea:	18 00                	sbb    BYTE PTR [bx+si],al
     2ec:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     2ef:	72 65                	jb     0x356
     2f1:	6e                   	outs   dx,BYTE PTR ds:[si]
     2f2:	74 43                	je     0x337
     2f4:	74 6c                	je     0x362
     2f6:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     2f9:	23 1d                	and    bx,WORD PTR [di]
     2fb:	03 2b                	add    bp,WORD PTR [bp+di]
     2fd:	00 ff                	add    bh,bh
     2ff:	ff                   	(bad)
     300:	3e 1e                	ds push ds
     302:	25 03 01             	and    ax,0x103
     305:	00 00                	add    BYTE PTR [bx+si],al
     307:	00 00                	add    BYTE PTR [bx+si],al
     309:	80 01 00             	add    BYTE PTR [bx+di],0x0
     30c:	00 00                	add    BYTE PTR [bx+si],al
     30e:	19 00                	sbb    WORD PTR [bx+si],ax
     310:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     313:	72 65                	jb     0x37a
     315:	6e                   	outs   dx,BYTE PTR ds:[si]
     316:	74 46                	je     0x35e
     318:	6f                   	outs   dx,WORD PTR ds:[si]
     319:	6e                   	outs   dx,BYTE PTR ds:[si]
     31a:	74 07                	je     0x323
     31c:	23 44 03             	and    ax,WORD PTR [si+0x3]
     31f:	49                   	dec    cx
     320:	00 ff                	add    bh,bh
     322:	ff a1 1e b4          	jmp    WORD PTR [bx+di-0x4be2]
     326:	03 01                	add    ax,WORD PTR [bx+di]
     328:	00 00                	add    BYTE PTR [bx+si],al
     32a:	00 00                	add    BYTE PTR [bx+si],al
     32c:	80 01 00             	add    BYTE PTR [bx+di],0x0
     32f:	00 00                	add    BYTE PTR [bx+si],al
     331:	1a 00                	sbb    al,BYTE PTR [bx+si]
     333:	0e                   	push   cs
     334:	50                   	push   ax
     335:	61                   	popa
     336:	72 65                	jb     0x39d
     338:	6e                   	outs   dx,BYTE PTR ds:[si]
     339:	74 53                	je     0x38e
     33b:	68 6f 77             	push   0x776f
     33e:	48                   	dec    ax
     33f:	69 6e 74 28 23       	imul   bp,WORD PTR [bp+0x74],0x2328
     344:	8b 03                	mov    ax,WORD PTR [bp+di]
     346:	db 00                	fild   DWORD PTR [bx+si]
     348:	ff                   	(bad)
     349:	ff 08                	dec    WORD PTR [bx+si]
     34b:	49                   	dec    cx
     34c:	80 06 01 00 00       	add    BYTE PTR ds:0x1,0x0
     351:	00 00                	add    BYTE PTR [bx+si],al
     353:	80 00 00             	add    BYTE PTR [bx+si],0x0
     356:	00 00                	add    BYTE PTR [bx+si],al
     358:	1b 00                	sbb    ax,WORD PTR [bx+si]
     35a:	0c 50                	or     al,0x50
     35c:	61                   	popa
     35d:	73 73                	jae    0x3d2
     35f:	77 6f                	ja     0x3d0
     361:	72 64                	jb     0x3c7
     363:	43                   	inc    bx
     364:	68 61 72             	push   0x7261
     367:	0d 04 dd             	or     ax,0xdd04
     36a:	08 40 00             	or     BYTE PTR [bx+si+0x0],al
     36d:	ff                   	(bad)
     36e:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     371:	ff                   	(bad)
     372:	ff 01                	inc    WORD PTR [bx+di]
     374:	00 00                	add    BYTE PTR [bx+si],al
     376:	00 00                	add    BYTE PTR [bx+si],al
     378:	80 00 00             	add    BYTE PTR [bx+si],0x0
     37b:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
     37f:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     382:	70 75                	jo     0x3f9
     384:	70 4d                	jo     0x3d3
     386:	65 6e                	outs   dx,BYTE PTR gs:[si]
     388:	75 07                	jne    0x391
     38a:	23 ac 03 e4          	and    bp,WORD PTR [si-0x1bfd]
     38e:	1a 93 03 fe          	sbb    dl,BYTE PTR [bp+di-0x1fd]
     392:	1a a4 06 01          	sbb    ah,BYTE PTR [si+0x106]
     396:	00 00                	add    BYTE PTR [bx+si],al
     398:	00 00                	add    BYTE PTR [bx+si],al
     39a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     39d:	00 00                	add    BYTE PTR [bx+si],al
     39f:	1d 00 08             	sbb    ax,0x800
     3a2:	52                   	push   dx
     3a3:	65 61                	gs popa
     3a5:	64 4f                	fs dec di
     3a7:	6e                   	outs   dx,BYTE PTR ds:[si]
     3a8:	6c                   	ins    BYTE PTR es:[di],dx
     3a9:	79 07                	jns    0x3b2
     3ab:	23 ee                	and    bp,si
     3ad:	03 48 00             	add    cx,WORD PTR [bx+si+0x0]
     3b0:	ff                   	(bad)
     3b1:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     3b4:	b8 03 23             	mov    ax,0x2303
     3b7:	1e                   	push   ds
     3b8:	cd 03                	int    0x3
     3ba:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     3be:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
     3c2:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     3c5:	6f                   	outs   dx,WORD PTR ds:[si]
     3c6:	77 48                	ja     0x410
     3c8:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     3cd:	d1 03                	rol    WORD PTR [bp+di],1
     3cf:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     3d0:	63 d5                	arpl   bp,dx
     3d2:	03 60 64             	add    sp,WORD PTR [bx+si+0x64]
     3d5:	f6 03 01             	test   BYTE PTR [bp+di],0x1
     3d8:	00 00                	add    BYTE PTR [bx+si],al
     3da:	00 00                	add    BYTE PTR [bx+si],al
     3dc:	80 ff ff             	cmp    bh,0xff
     3df:	ff                   	(bad)
     3e0:	ff 1f                	call   DWORD PTR [bx]
     3e2:	00 08                	add    BYTE PTR [bx+si],cl
     3e4:	54                   	push   sp
     3e5:	61                   	popa
     3e6:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     3e9:	64 65 72 07          	fs gs jb 0x3f4
     3ed:	23 0e 04 a4          	and    cx,WORD PTR ds:0xa404
     3f1:	00 ff                	add    bh,bh
     3f3:	ff 88 64 16          	dec    WORD PTR [bx+si+0x1664]
     3f7:	04 01                	add    al,0x1
     3f9:	00 00                	add    BYTE PTR [bx+si],al
     3fb:	00 00                	add    BYTE PTR [bx+si],al
     3fd:	80 01 00             	add    BYTE PTR [bx+di],0x0
     400:	00 00                	add    BYTE PTR [bx+si],al
     402:	09 00                	or     WORD PTR [bx+si],ax
     404:	07                   	pop    es
     405:	54                   	push   sp
     406:	61                   	popa
     407:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     40a:	6f                   	outs   dx,WORD PTR ds:[si]
     40b:	70 07                	jo     0x414
     40d:	23 20                	and    sp,WORD PTR [bx+si]
     40f:	06                   	push   es
     410:	29 00                	sub    WORD PTR [bx+si],ax
     412:	ff                   	(bad)
     413:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     416:	92                   	xchg   dx,ax
     417:	04 01                	add    al,0x1
     419:	00 00                	add    BYTE PTR [bx+si],al
     41b:	00 00                	add    BYTE PTR [bx+si],al
     41d:	80 01 00             	add    BYTE PTR [bx+di],0x0
     420:	00 00                	add    BYTE PTR [bx+si],al
     422:	20 00                	and    BYTE PTR [bx+si],al
     424:	07                   	pop    es
     425:	56                   	push   si
     426:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     42b:	65 71 00             	gs jno 0x42e
     42e:	4f                   	dec    di
     42f:	04 e4                	add    al,0xe4
     431:	00 ff                	add    bh,bh
     433:	ff e4                	jmp    sp
     435:	00 ff                	add    bh,bh
     437:	ff 01                	inc    WORD PTR [bx+di]
     439:	00 00                	add    BYTE PTR [bx+si],al
     43b:	00 00                	add    BYTE PTR [bx+si],al
     43d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     440:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     444:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     447:	43                   	inc    bx
     448:	68 61 6e             	push   0x6e61
     44b:	67 65 71 00          	addr32 gs jno 0x44f
     44f:	6f                   	outs   dx,WORD PTR ds:[si]
     450:	04 7a                	add    al,0x7a
     452:	00 ff                	add    bh,bh
     454:	ff                   	(bad)
     455:	7a 00                	jp     0x457
     457:	ff                   	(bad)
     458:	ff 01                	inc    WORD PTR [bx+di]
     45a:	00 00                	add    BYTE PTR [bx+si],al
     45c:	00 00                	add    BYTE PTR [bx+si],al
     45e:	80 00 00             	add    BYTE PTR [bx+si],0x0
     461:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     465:	07                   	pop    es
     466:	4f                   	dec    di
     467:	6e                   	outs   dx,BYTE PTR ds:[si]
     468:	43                   	inc    bx
     469:	6c                   	ins    BYTE PTR es:[di],dx
     46a:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     46f:	fa                   	cli
     470:	04 82                	add    al,0x82
     472:	00 ff                	add    bh,bh
     474:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     478:	ff 01                	inc    WORD PTR [bx+di]
     47a:	00 00                	add    BYTE PTR [bx+si],al
     47c:	00 00                	add    BYTE PTR [bx+si],al
     47e:	80 00 00             	add    BYTE PTR [bx+si],0x0
     481:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     485:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     488:	44                   	inc    sp
     489:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     48c:	6c                   	ins    BYTE PTR es:[di],dx
     48d:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     492:	b5 04                	mov    ch,0x4
     494:	62 00                	bound  ax,DWORD PTR [bx+si]
     496:	ff                   	(bad)
     497:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     49a:	ff                   	(bad)
     49b:	ff 01                	inc    WORD PTR [bx+di]
     49d:	00 00                	add    BYTE PTR [bx+si],al
     49f:	00 00                	add    BYTE PTR [bx+si],al
     4a1:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4a4:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     4a8:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     4ab:	44                   	inc    sp
     4ac:	72 61                	jb     0x50f
     4ae:	67 44                	addr32 inc sp
     4b0:	72 6f                	jb     0x521
     4b2:	70 80                	jo     0x434
     4b4:	02 d8                	add    bl,al
     4b6:	04 6a                	add    al,0x6a
     4b8:	00 ff                	add    bh,bh
     4ba:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     4bd:	ff                   	(bad)
     4be:	ff 01                	inc    WORD PTR [bx+di]
     4c0:	00 00                	add    BYTE PTR [bx+si],al
     4c2:	00 00                	add    BYTE PTR [bx+si],al
     4c4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4c7:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     4cb:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     4ce:	44                   	inc    sp
     4cf:	72 61                	jb     0x532
     4d1:	67 4f                	addr32 dec di
     4d3:	76 65                	jbe    0x53a
     4d5:	72 32                	jb     0x509
     4d7:	03 39                	add    di,WORD PTR [bx+di]
     4d9:	05 72 00             	add    ax,0x72
     4dc:	ff                   	(bad)
     4dd:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     4e0:	ff                   	(bad)
     4e1:	ff 01                	inc    WORD PTR [bx+di]
     4e3:	00 00                	add    BYTE PTR [bx+si],al
     4e5:	00 00                	add    BYTE PTR [bx+si],al
     4e7:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4ea:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
     4ee:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     4f1:	45                   	inc    bp
     4f2:	6e                   	outs   dx,BYTE PTR ds:[si]
     4f3:	64 44                	fs inc sp
     4f5:	72 61                	jb     0x558
     4f7:	67 71 00             	addr32 jno 0x4fa
     4fa:	1a 05                	sbb    al,BYTE PTR [di]
     4fc:	c8 00 ff ff          	enter  0xff00,0xff
     500:	c8 00 ff ff          	enter  0xff00,0xff
     504:	01 00                	add    WORD PTR [bx+si],ax
     506:	00 00                	add    BYTE PTR [bx+si],al
     508:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     50c:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
     510:	07                   	pop    es
     511:	4f                   	dec    di
     512:	6e                   	outs   dx,BYTE PTR ds:[si]
     513:	45                   	inc    bp
     514:	6e                   	outs   dx,BYTE PTR ds:[si]
     515:	74 65                	je     0x57c
     517:	72 71                	jb     0x58a
     519:	00 38                	add    BYTE PTR [bx+si],bh
     51b:	06                   	push   es
     51c:	d0 00                	rol    BYTE PTR [bx+si],1
     51e:	ff                   	(bad)
     51f:	ff d0                	call   ax
     521:	00 ff                	add    bh,bh
     523:	ff 01                	inc    WORD PTR [bx+di]
     525:	00 00                	add    BYTE PTR [bx+si],al
     527:	00 00                	add    BYTE PTR [bx+si],al
     529:	80 00 00             	add    BYTE PTR [bx+si],0x0
     52c:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
     530:	06                   	push   es
     531:	4f                   	dec    di
     532:	6e                   	outs   dx,BYTE PTR ds:[si]
     533:	45                   	inc    bp
     534:	78 69                	js     0x59f
     536:	74 1a                	je     0x552
     538:	02 5b 05             	add    bl,BYTE PTR [bp+di+0x5]
     53b:	b0 00                	mov    al,0x0
     53d:	ff                   	(bad)
     53e:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     542:	ff 01                	inc    WORD PTR [bx+di]
     544:	00 00                	add    BYTE PTR [bx+si],al
     546:	00 00                	add    BYTE PTR [bx+si],al
     548:	80 00 00             	add    BYTE PTR [bx+si],0x0
     54b:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
     54f:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     552:	4b                   	dec    bx
     553:	65 79 44             	gs jns 0x59a
     556:	6f                   	outs   dx,WORD PTR ds:[si]
     557:	77 6e                	ja     0x5c7
     559:	54                   	push   sp
     55a:	02 7e 05             	add    bh,BYTE PTR [bp+0x5]
     55d:	b8 00 ff             	mov    ax,0xff00
     560:	ff                   	(bad)
     561:	b8 00 ff             	mov    ax,0xff00
     564:	ff 01                	inc    WORD PTR [bx+di]
     566:	00 00                	add    BYTE PTR [bx+si],al
     568:	00 00                	add    BYTE PTR [bx+si],al
     56a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     56d:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
     571:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     574:	4b                   	dec    bx
     575:	65 79 50             	gs jns 0x5c8
     578:	72 65                	jb     0x5df
     57a:	73 73                	jae    0x5ef
     57c:	1a 02                	sbb    al,BYTE PTR [bp+si]
     57e:	9e                   	sahf
     57f:	05 c0 00             	add    ax,0xc0
     582:	ff                   	(bad)
     583:	ff c0                	inc    ax
     585:	00 ff                	add    bh,bh
     587:	ff 01                	inc    WORD PTR [bx+di]
     589:	00 00                	add    BYTE PTR [bx+si],al
     58b:	00 00                	add    BYTE PTR [bx+si],al
     58d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     590:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
     594:	07                   	pop    es
     595:	4f                   	dec    di
     596:	6e                   	outs   dx,BYTE PTR ds:[si]
     597:	4b                   	dec    bx
     598:	65 79 55             	gs jns 0x5f0
     59b:	70 71                	jo     0x60e
     59d:	01 c2                	add    dx,ax
     59f:	05 4a 00             	add    ax,0x4a
     5a2:	ff                   	(bad)
     5a3:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     5a6:	ff                   	(bad)
     5a7:	ff 01                	inc    WORD PTR [bx+di]
     5a9:	00 00                	add    BYTE PTR [bx+si],al
     5ab:	00 00                	add    BYTE PTR [bx+si],al
     5ad:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5b0:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
     5b4:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     5b7:	4d                   	dec    bp
     5b8:	6f                   	outs   dx,WORD PTR ds:[si]
     5b9:	75 73                	jne    0x62e
     5bb:	65 44                	gs inc sp
     5bd:	6f                   	outs   dx,WORD PTR ds:[si]
     5be:	77 6e                	ja     0x62e
     5c0:	ce                   	into
     5c1:	01 e6                	add    si,sp
     5c3:	05 52 00             	add    ax,0x52
     5c6:	ff                   	(bad)
     5c7:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     5ca:	ff                   	(bad)
     5cb:	ff 01                	inc    WORD PTR [bx+di]
     5cd:	00 00                	add    BYTE PTR [bx+si],al
     5cf:	00 00                	add    BYTE PTR [bx+si],al
     5d1:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5d4:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
     5d8:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     5db:	4d                   	dec    bp
     5dc:	6f                   	outs   dx,WORD PTR ds:[si]
     5dd:	75 73                	jne    0x652
     5df:	65 4d                	gs dec bp
     5e1:	6f                   	outs   dx,WORD PTR ds:[si]
     5e2:	76 65                	jbe    0x649
     5e4:	71 01                	jno    0x5e7
     5e6:	7c 06                	jl     0x5ee
     5e8:	5a                   	pop    dx
     5e9:	00 ff                	add    bh,bh
     5eb:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     5ee:	ff                   	(bad)
     5ef:	ff 01                	inc    WORD PTR [bx+di]
     5f1:	00 00                	add    BYTE PTR [bx+si],al
     5f3:	00 00                	add    BYTE PTR [bx+si],al
     5f5:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5f8:	00 80 2e 00          	add    BYTE PTR [bx+si+0x2e],al
     5fc:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     5ff:	4d                   	dec    bp
     600:	6f                   	outs   dx,WORD PTR ds:[si]
     601:	75 73                	jne    0x676
     603:	65 55                	gs push bp
     605:	70 c0                	jo     0x5c7
     607:	06                   	push   es
     608:	00 00                	add    BYTE PTR [bx+si],al
     60a:	00 00                	add    BYTE PTR [bx+si],al
     60c:	b2 06                	mov    dl,0x6
     60e:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     60f:	06                   	push   es
     610:	ea 00 12 26 d3       	jmp    0xd326:0x1200
     615:	06                   	push   es
     616:	fa                   	cli
     617:	45                   	inc    bp
     618:	8c 06 9a 1f          	mov    WORD PTR ds:0x1f9a,es
     61c:	05 07 cb             	add    ax,0xcb07
     61f:	1f                   	pop    ds
     620:	1c 06                	sbb    al,0x6
     622:	f7 21                	mul    WORD PTR [bx+di]
     624:	ba 06 cd             	mov    dx,0xcd06
     627:	11 30                	adc    WORD PTR [bx+si],si
     629:	06                   	push   es
     62a:	3a 27                	cmp    ah,BYTE PTR [bx]
     62c:	34 06                	xor    al,0x6
     62e:	fa                   	cli
     62f:	10 e3                	adc    bl,ah
     631:	06                   	push   es
     632:	d6                   	(bad)
     633:	14 64                	adc    al,0x64
     635:	06                   	push   es
     636:	f4                   	hlt
     637:	4f                   	dec    di
     638:	48                   	dec    ax
     639:	06                   	push   es
     63a:	55                   	push   bp
     63b:	22 54 06             	and    dl,BYTE PTR [si+0x6]
     63e:	ec                   	in     al,dx
     63f:	30 9c 06 51          	xor    BYTE PTR [si+0x5106],bl
     643:	1b 29                	sbb    bp,WORD PTR [bx+di]
     645:	07                   	pop    es
     646:	38 50 50             	cmp    BYTE PTR [bx+si+0x50],dl
     649:	06                   	push   es
     64a:	63 31                	arpl   WORD PTR [bx+di],si
     64c:	6c                   	ins    BYTE PTR es:[di],dx
     64d:	06                   	push   es
     64e:	21 50 28             	and    WORD PTR [bx+si+0x28],dx
     651:	06                   	push   es
     652:	ff 20                	jmp    WORD PTR [bx+si]
     654:	24 06                	and    al,0x6
     656:	d9 62 5c             	fldenv [bp+si+0x5c]
     659:	06                   	push   es
     65a:	06                   	push   es
     65b:	63 60 06             	arpl   WORD PTR [bx+si+0x6],sp
     65e:	8f                   	(bad)
     65f:	60                   	pusha
     660:	98                   	cbw
     661:	06                   	push   es
     662:	3a 1c                	cmp    bl,BYTE PTR [si]
     664:	44                   	inc    sp
     665:	06                   	push   es
     666:	35 69 14             	xor    ax,0x1469
     669:	06                   	push   es
     66a:	08 61 70             	or     BYTE PTR [bx+di+0x70],ah
     66d:	06                   	push   es
     66e:	5c                   	pop    sp
     66f:	61                   	popa
     670:	74 06                	je     0x678
     672:	62 5c a0             	bound  bx,DWORD PTR [si-0x60]
     675:	06                   	push   es
     676:	3a 61 2c             	cmp    ah,BYTE PTR [bx+di+0x2c]
     679:	06                   	push   es
     67a:	72 3f                	jb     0x6bb
     67c:	84 06 8d 6e          	test   BYTE PTR ds:0x6e8d,al
     680:	88 06 17 3e          	mov    BYTE PTR ds:0x3e17,al
     684:	18 06 f5 6e          	sbb    BYTE PTR ds:0x6ef5,al
     688:	68 06 ed             	push   0xed06
     68b:	3e 90                	ds nop
     68d:	06                   	push   es
     68e:	77 3e                	ja     0x6ce
     690:	94                   	xchg   sp,ax
     691:	06                   	push   es
     692:	c2 35 58             	ret    0x5835
     695:	06                   	push   es
     696:	1c 48                	sbb    al,0x48
     698:	40                   	inc    ax
     699:	06                   	push   es
     69a:	ae                   	scas   al,BYTE PTR es:[di]
     69b:	5f                   	pop    di
     69c:	4c                   	dec    sp
     69d:	06                   	push   es
     69e:	35 62 78             	xor    ax,0x7862
     6a1:	06                   	push   es
     6a2:	9e                   	sahf
     6a3:	24 3c                	and    al,0x3c
     6a5:	06                   	push   es
     6a6:	0b 54 44             	or     dx,WORD PTR [si+0x44]
     6a9:	42                   	inc    dx
     6aa:	43                   	inc    bx
     6ab:	68 65 63             	push   0x6365
     6ae:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     6b2:	02 00                	add    al,BYTE PTR [bx+si]
     6b4:	1b 0f                	sbb    cx,WORD PTR [bx]
     6b6:	ef                   	out    dx,ax
     6b7:	ff 6c 26             	jmp    DWORD PTR [si+0x26]
     6ba:	be 06 8a             	mov    si,0x8a06
     6bd:	25 cf 06             	and    ax,0x6cf
     6c0:	07                   	pop    es
     6c1:	0b 54 44             	or     dx,WORD PTR [si+0x44]
     6c4:	42                   	inc    dx
     6c5:	43                   	inc    bx
     6c6:	68 65 63             	push   0x6365
     6c9:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     6cd:	26 06                	es push es
     6cf:	89 07                	mov    WORD PTR [bx],ax
     6d1:	bc 26 eb             	mov    sp,0xeb26
     6d4:	06                   	push   es
     6d5:	2c 00                	sub    al,0x0
     6d7:	07                   	pop    es
     6d8:	44                   	inc    sp
     6d9:	42                   	inc    dx
     6da:	43                   	inc    bx
     6db:	74 72                	je     0x74f
     6dd:	6c                   	ins    BYTE PTR es:[di],dx
     6de:	73 23                	jae    0x703
     6e0:	00 41 00             	add    BYTE PTR [bx+di+0x0],al
     6e3:	ee                   	out    dx,al
     6e4:	09 da                	or     dx,bx
     6e6:	00 ff                	add    bh,bh
     6e8:	ff                   	jmp    (bad)
     6e9:	ee                   	out    dx,al
     6ea:	6d                   	ins    WORD PTR es:[di],dx
     6eb:	fc                   	cld
     6ec:	0b 01                	or     ax,WORD PTR [bx+di]
     6ee:	00 00                	add    BYTE PTR [bx+si],al
     6f0:	00 00                	add    BYTE PTR [bx+si],al
     6f2:	80 01 00             	add    BYTE PTR [bx+di],0x0
     6f5:	00 00                	add    BYTE PTR [bx+si],al
     6f7:	0a 00                	or     al,BYTE PTR [bx+si]
     6f9:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
     6fc:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
     701:	6e                   	outs   dx,BYTE PTR ds:[si]
     702:	74 07                	je     0x70b
     704:	23 67 07             	and    sp,WORD PTR [bx+0x7]
     707:	db 00                	fild   DWORD PTR [bx+si]
     709:	ff                   	(bad)
     70a:	ff                   	call   (bad)
     70b:	db 00                	fild   DWORD PTR [bx+si]
     70d:	ff                   	(bad)
     70e:	ff 01                	inc    WORD PTR [bx+di]
     710:	00 00                	add    BYTE PTR [bx+si],al
     712:	00 00                	add    BYTE PTR [bx+si],al
     714:	80 00 00             	add    BYTE PTR [bx+si],0x0
     717:	00 00                	add    BYTE PTR [bx+si],al
     719:	0b 00                	or     ax,WORD PTR [bx+si]
     71b:	0b 41 6c             	or     ax,WORD PTR [bx+di+0x6c]
     71e:	6c                   	ins    BYTE PTR es:[di],dx
     71f:	6f                   	outs   dx,WORD PTR ds:[si]
     720:	77 47                	ja     0x769
     722:	72 61                	jb     0x785
     724:	79 65                	jns    0x78b
     726:	64 66 01 2d          	add    DWORD PTR fs:[di],ebp
     72a:	07                   	pop    es
     72b:	53                   	push   bx
     72c:	1d 31 07             	sbb    ax,0x731
     72f:	8c 1d                	mov    WORD PTR [di],ds
     731:	51                   	push   cx
     732:	07                   	pop    es
     733:	01 00                	add    WORD PTR [bx+si],ax
     735:	00 00                	add    BYTE PTR [bx+si],al
     737:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     73b:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
     73f:	07                   	pop    es
     740:	43                   	inc    bx
     741:	61                   	popa
     742:	70 74                	jo     0x7b8
     744:	69 6f 6e 02 00       	imul   bp,WORD PTR [bx+0x6e],0x2
     749:	2e 08 38             	or     BYTE PTR cs:[bx+si],bh
     74c:	00 ff                	add    bh,bh
     74e:	ff d5                	call   bp
     750:	1e                   	push   ds
     751:	55                   	push   bp
     752:	07                   	pop    es
     753:	17                   	pop    ss
     754:	1f                   	pop    ds
     755:	6f                   	outs   dx,WORD PTR ds:[si]
     756:	07                   	pop    es
     757:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
     75b:	ff                   	(bad)
     75c:	ff 0d                	dec    WORD PTR [di]
     75e:	00 05                	add    BYTE PTR [di],al
     760:	43                   	inc    bx
     761:	6f                   	outs   dx,WORD PTR ds:[si]
     762:	6c                   	ins    BYTE PTR es:[di],dx
     763:	6f                   	outs   dx,WORD PTR ds:[si]
     764:	72 07                	jb     0x76d
     766:	23 85 07 a5          	and    ax,WORD PTR [di-0x5af9]
     76a:	00 ff                	add    bh,bh
     76c:	ff 22                	jmp    WORD PTR [bp+si]
     76e:	63 73 07             	arpl   WORD PTR [bp+di+0x7],si
     771:	54                   	push   sp
     772:	63 ca                	arpl   dx,cx
     774:	07                   	pop    es
     775:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     779:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
     77d:	05 43 74             	add    ax,0x7443
     780:	6c                   	ins    BYTE PTR es:[di],dx
     781:	33 44 62             	xor    ax,WORD PTR [si+0x62]
     784:	23 0e 08 11          	and    cx,WORD PTR ds:0x1108
     788:	25 8d 07             	and    ax,0x78d
     78b:	3b 25                	cmp    sp,WORD PTR [di]
     78d:	ab                   	stos   WORD PTR es:[di],ax
     78e:	07                   	pop    es
     78f:	01 00                	add    WORD PTR [bx+si],ax
     791:	00 00                	add    BYTE PTR [bx+si],al
     793:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     797:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     79b:	09 44 61             	or     WORD PTR [si+0x61],ax
     79e:	74 61                	je     0x801
     7a0:	46                   	inc    si
     7a1:	69 65 6c 64 04       	imul   sp,WORD PTR [di+0x6c],0x464
     7a6:	09 fb                	or     bx,di
     7a8:	0c d1                	or     al,0xd1
     7aa:	24 af                	and    al,0xaf
     7ac:	07                   	pop    es
     7ad:	f5                   	cmc
     7ae:	24 03                	and    al,0x3
     7b0:	09 01                	or     WORD PTR [bx+di],ax
     7b2:	00 00                	add    BYTE PTR [bx+si],al
     7b4:	00 00                	add    BYTE PTR [bx+si],al
     7b6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7b9:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     7bd:	0a 44 61             	or     al,BYTE PTR [si+0x61]
     7c0:	74 61                	je     0x823
     7c2:	53                   	push   bx
     7c3:	6f                   	outs   dx,WORD PTR ds:[si]
     7c4:	75 72                	jne    0x838
     7c6:	63 65 64             	arpl   WORD PTR [di+0x64],sp
     7c9:	00 ed                	add    ch,ch
     7cb:	07                   	pop    es
     7cc:	3e 00 ff             	ds add bh,bh
     7cf:	ff                   	(bad)
     7d0:	3e 00 ff             	ds add bh,bh
     7d3:	ff 01                	inc    WORD PTR [bx+di]
     7d5:	00 00                	add    BYTE PTR [bx+si],al
     7d7:	00 00                	add    BYTE PTR [bx+si],al
     7d9:	80 f4 ff             	xor    ah,0xff
     7dc:	ff                   	(bad)
     7dd:	ff 11                	call   WORD PTR [bx+di]
     7df:	00 0a                	add    BYTE PTR [bp+si],cl
     7e1:	44                   	inc    sp
     7e2:	72 61                	jb     0x845
     7e4:	67 43                	addr32 inc bx
     7e6:	75 72                	jne    0x85a
     7e8:	73 6f                	jae    0x859
     7ea:	72 25                	jb     0x811
     7ec:	01 16 08 2e          	add    WORD PTR ds:0x2e08,dx
     7f0:	00 ff                	add    bh,bh
     7f2:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     7f6:	ff 01                	inc    WORD PTR [bx+di]
     7f8:	00 00                	add    BYTE PTR [bx+si],al
     7fa:	00 00                	add    BYTE PTR [bx+si],al
     7fc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7ff:	00 00                	add    BYTE PTR [bx+si],al
     801:	12 00                	adc    al,BYTE PTR [bx+si]
     803:	08 44 72             	or     BYTE PTR [si+0x72],al
     806:	61                   	popa
     807:	67 4d                	addr32 dec bp
     809:	6f                   	outs   dx,WORD PTR ds:[si]
     80a:	64 65 07             	fs gs pop es
     80d:	23 4b 08             	and    cx,WORD PTR [bp+di+0x8]
     810:	2a 00                	sub    al,BYTE PTR [bx+si]
     812:	ff                   	(bad)
     813:	ff                   	(bad)
     814:	b8 1c 36             	mov    ax,0x361c
     817:	08 01                	or     BYTE PTR [bx+di],al
     819:	00 00                	add    BYTE PTR [bx+si],al
     81b:	00 00                	add    BYTE PTR [bx+si],al
     81d:	80 01 00             	add    BYTE PTR [bx+di],0x0
     820:	00 00                	add    BYTE PTR [bx+si],al
     822:	13 00                	adc    ax,WORD PTR [bx+si]
     824:	07                   	pop    es
     825:	45                   	inc    bp
     826:	6e                   	outs   dx,BYTE PTR ds:[si]
     827:	61                   	popa
     828:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     82b:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     82e:	9d                   	popf
     82f:	0c 34                	or     al,0x34
     831:	00 ff                	add    bh,bh
     833:	ff                   	jmp    (bad)
     834:	eb 1d                	jmp    0x853
     836:	3a 08                	cmp    cl,BYTE PTR [bx+si]
     838:	08 1e 53 08          	or     BYTE PTR ds:0x853,bl
     83c:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     840:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     844:	04 46                	add    al,0x46
     846:	6f                   	outs   dx,WORD PTR ds:[si]
     847:	6e                   	outs   dx,BYTE PTR ds:[si]
     848:	74 07                	je     0x851
     84a:	23 6f 08             	and    bp,WORD PTR [bx+0x8]
     84d:	2c 00                	sub    al,0x0
     84f:	ff                   	(bad)
     850:	ff 32                	push   WORD PTR [bp+si]
     852:	1f                   	pop    ds
     853:	77 08                	ja     0x85d
     855:	01 00                	add    WORD PTR [bx+si],ax
     857:	00 00                	add    BYTE PTR [bx+si],al
     859:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     85d:	00 00                	add    BYTE PTR [bx+si],al
     85f:	15 00 0b             	adc    ax,0xb00
     862:	50                   	push   ax
     863:	61                   	popa
     864:	72 65                	jb     0x8cb
     866:	6e                   	outs   dx,BYTE PTR ds:[si]
     867:	74 43                	je     0x8ac
     869:	6f                   	outs   dx,WORD PTR ds:[si]
     86a:	6c                   	ins    BYTE PTR es:[di],dx
     86b:	6f                   	outs   dx,WORD PTR ds:[si]
     86c:	72 07                	jb     0x875
     86e:	23 93 08 a6          	and    dx,WORD PTR [bp+di-0x59f8]
     872:	00 ff                	add    bh,bh
     874:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     877:	9b                   	fwait
     878:	08 01                	or     BYTE PTR [bx+di],al
     87a:	00 00                	add    BYTE PTR [bx+si],al
     87c:	00 00                	add    BYTE PTR [bx+si],al
     87e:	80 01 00             	add    BYTE PTR [bx+di],0x0
     881:	00 00                	add    BYTE PTR [bx+si],al
     883:	16                   	push   ss
     884:	00 0b                	add    BYTE PTR [bp+di],cl
     886:	50                   	push   ax
     887:	61                   	popa
     888:	72 65                	jb     0x8ef
     88a:	6e                   	outs   dx,BYTE PTR ds:[si]
     88b:	74 43                	je     0x8d0
     88d:	74 6c                	je     0x8fb
     88f:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     892:	23 b6 08 2b          	and    si,WORD PTR [bp+0x2b08]
     896:	00 ff                	add    bh,bh
     898:	ff                   	(bad)
     899:	3e 1e                	ds push ds
     89b:	be 08 01             	mov    si,0x108
     89e:	00 00                	add    BYTE PTR [bx+si],al
     8a0:	00 00                	add    BYTE PTR [bx+si],al
     8a2:	80 01 00             	add    BYTE PTR [bx+di],0x0
     8a5:	00 00                	add    BYTE PTR [bx+si],al
     8a7:	17                   	pop    ss
     8a8:	00 0a                	add    BYTE PTR [bp+si],cl
     8aa:	50                   	push   ax
     8ab:	61                   	popa
     8ac:	72 65                	jb     0x913
     8ae:	6e                   	outs   dx,BYTE PTR ds:[si]
     8af:	74 46                	je     0x8f7
     8b1:	6f                   	outs   dx,WORD PTR ds:[si]
     8b2:	6e                   	outs   dx,BYTE PTR ds:[si]
     8b3:	74 07                	je     0x8bc
     8b5:	23 ff                	and    di,di
     8b7:	08 49 00             	or     BYTE PTR [bx+di+0x0],cl
     8ba:	ff                   	(bad)
     8bb:	ff a1 1e 28          	jmp    WORD PTR [bx+di+0x281e]
     8bf:	09 01                	or     WORD PTR [bx+di],ax
     8c1:	00 00                	add    BYTE PTR [bx+si],al
     8c3:	00 00                	add    BYTE PTR [bx+si],al
     8c5:	80 01 00             	add    BYTE PTR [bx+di],0x0
     8c8:	00 00                	add    BYTE PTR [bx+si],al
     8ca:	18 00                	sbb    BYTE PTR [bx+si],al
     8cc:	0e                   	push   cs
     8cd:	50                   	push   ax
     8ce:	61                   	popa
     8cf:	72 65                	jb     0x936
     8d1:	6e                   	outs   dx,BYTE PTR ds:[si]
     8d2:	74 53                	je     0x927
     8d4:	68 6f 77             	push   0x776f
     8d7:	48                   	dec    ax
     8d8:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     8dd:	98                   	cbw
     8de:	0e                   	push   cs
     8df:	40                   	inc    ax
     8e0:	00 ff                	add    bh,bh
     8e2:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     8e5:	ff                   	(bad)
     8e6:	ff 01                	inc    WORD PTR [bx+di]
     8e8:	00 00                	add    BYTE PTR [bx+si],al
     8ea:	00 00                	add    BYTE PTR [bx+si],al
     8ec:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8ef:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
     8f3:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     8f6:	70 75                	jo     0x96d
     8f8:	70 4d                	jo     0x947
     8fa:	65 6e                	outs   dx,BYTE PTR gs:[si]
     8fc:	75 07                	jne    0x905
     8fe:	23 20                	and    sp,WORD PTR [bx+si]
     900:	09 56 25             	or     WORD PTR [bp+0x25],dx
     903:	07                   	pop    es
     904:	09 70 25             	or     WORD PTR [bx+si+0x25],si
     907:	86 09                	xchg   BYTE PTR [bx+di],cl
     909:	01 00                	add    WORD PTR [bx+si],ax
     90b:	00 00                	add    BYTE PTR [bx+si],al
     90d:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     911:	00 00                	add    BYTE PTR [bx+si],al
     913:	1a 00                	sbb    al,BYTE PTR [bx+si]
     915:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
     918:	61                   	popa
     919:	64 4f                	fs dec di
     91b:	6e                   	outs   dx,BYTE PTR ds:[si]
     91c:	6c                   	ins    BYTE PTR es:[di],dx
     91d:	79 07                	jns    0x926
     91f:	23 62 09             	and    sp,WORD PTR [bp+si+0x9]
     922:	48                   	dec    ax
     923:	00 ff                	add    bh,bh
     925:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     928:	2c 09                	sub    al,0x9
     92a:	23 1e 41 09          	and    bx,WORD PTR ds:0x941
     92e:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     932:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     936:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     939:	6f                   	outs   dx,WORD PTR ds:[si]
     93a:	77 48                	ja     0x984
     93c:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     941:	45                   	inc    bp
     942:	09 a6 63 49          	or     WORD PTR [bp+0x4963],sp
     946:	09 60 64             	or     WORD PTR [bx+si+0x64],sp
     949:	6a 09                	push   0x9
     94b:	01 00                	add    WORD PTR [bx+si],ax
     94d:	00 00                	add    BYTE PTR [bx+si],al
     94f:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     953:	ff                   	(bad)
     954:	ff 1c                	call   DWORD PTR [si]
     956:	00 08                	add    BYTE PTR [bx+si],cl
     958:	54                   	push   sp
     959:	61                   	popa
     95a:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     95d:	64 65 72 07          	fs gs jb 0x968
     961:	23 82 09 a4          	and    ax,WORD PTR [bp+si-0x5bf7]
     965:	00 ff                	add    bh,bh
     967:	ff 88 64 d6          	dec    WORD PTR [bx+si-0x299c]
     96b:	09 01                	or     WORD PTR [bx+di],ax
     96d:	00 00                	add    BYTE PTR [bx+si],al
     96f:	00 00                	add    BYTE PTR [bx+si],al
     971:	80 01 00             	add    BYTE PTR [bx+di],0x0
     974:	00 00                	add    BYTE PTR [bx+si],al
     976:	09 00                	or     WORD PTR [bx+si],ax
     978:	07                   	pop    es
     979:	54                   	push   sp
     97a:	61                   	popa
     97b:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     97e:	6f                   	outs   dx,WORD PTR ds:[si]
     97f:	70 62                	jo     0x9e3
     981:	23 a7 09 d2          	and    sp,WORD PTR [bx-0x2df7]
     985:	25 8a 09             	and    ax,0x98a
     988:	0e                   	push   cs
     989:	26 ab                	es stos WORD PTR es:[di],ax
     98b:	09 01                	or     WORD PTR [bx+di],ax
     98d:	00 00                	add    BYTE PTR [bx+si],al
     98f:	00 00                	add    BYTE PTR [bx+si],al
     991:	80 00 00             	add    BYTE PTR [bx+si],0x0
     994:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
     998:	0c 56                	or     al,0x56
     99a:	61                   	popa
     99b:	6c                   	ins    BYTE PTR es:[di],dx
     99c:	75 65                	jne    0xa03
     99e:	43                   	inc    bx
     99f:	68 65 63             	push   0x6365
     9a2:	6b 65 64 62          	imul   sp,WORD PTR [di+0x64],0x62
     9a6:	23 ce                	and    cx,si
     9a8:	09 f0                	or     ax,si
     9aa:	25 af 09             	and    ax,0x9af
     9ad:	38 26 20 0c          	cmp    BYTE PTR ds:0xc20,ah
     9b1:	01 00                	add    WORD PTR [bx+si],ax
     9b3:	00 00                	add    BYTE PTR [bx+si],al
     9b5:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     9b9:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
     9bd:	0e                   	push   cs
     9be:	56                   	push   si
     9bf:	61                   	popa
     9c0:	6c                   	ins    BYTE PTR es:[di],dx
     9c1:	75 65                	jne    0xa28
     9c3:	55                   	push   bp
     9c4:	6e                   	outs   dx,BYTE PTR ds:[si]
     9c5:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     9c8:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
     9cb:	64 07                	fs pop es
     9cd:	23 9c 0b 29          	and    bx,WORD PTR [si+0x290b]
     9d1:	00 ff                	add    bh,bh
     9d3:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     9d6:	0e                   	push   cs
     9d7:	0a 01                	or     al,BYTE PTR [bx+di]
     9d9:	00 00                	add    BYTE PTR [bx+si],al
     9db:	00 00                	add    BYTE PTR [bx+si],al
     9dd:	80 01 00             	add    BYTE PTR [bx+di],0x0
     9e0:	00 00                	add    BYTE PTR [bx+si],al
     9e2:	1f                   	pop    ds
     9e3:	00 07                	add    BYTE PTR [bx],al
     9e5:	56                   	push   si
     9e6:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     9eb:	65 71 00             	gs jno 0x9ee
     9ee:	76 0a                	jbe    0x9fa
     9f0:	7a 00                	jp     0x9f2
     9f2:	ff                   	(bad)
     9f3:	ff                   	(bad)
     9f4:	7a 00                	jp     0x9f6
     9f6:	ff                   	(bad)
     9f7:	ff 01                	inc    WORD PTR [bx+di]
     9f9:	00 00                	add    BYTE PTR [bx+si],al
     9fb:	00 00                	add    BYTE PTR [bx+si],al
     9fd:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a00:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
     a04:	07                   	pop    es
     a05:	4f                   	dec    di
     a06:	6e                   	outs   dx,BYTE PTR ds:[si]
     a07:	43                   	inc    bx
     a08:	6c                   	ins    BYTE PTR es:[di],dx
     a09:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     a0e:	31 0a                	xor    WORD PTR [bp+si],cx
     a10:	62 00                	bound  ax,DWORD PTR [bx+si]
     a12:	ff                   	(bad)
     a13:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     a16:	ff                   	(bad)
     a17:	ff 01                	inc    WORD PTR [bx+di]
     a19:	00 00                	add    BYTE PTR [bx+si],al
     a1b:	00 00                	add    BYTE PTR [bx+si],al
     a1d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a20:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     a24:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     a27:	44                   	inc    sp
     a28:	72 61                	jb     0xa8b
     a2a:	67 44                	addr32 inc sp
     a2c:	72 6f                	jb     0xa9d
     a2e:	70 80                	jo     0x9b0
     a30:	02 54 0a             	add    dl,BYTE PTR [si+0xa]
     a33:	6a 00                	push   0x0
     a35:	ff                   	(bad)
     a36:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     a39:	ff                   	(bad)
     a3a:	ff 01                	inc    WORD PTR [bx+di]
     a3c:	00 00                	add    BYTE PTR [bx+si],al
     a3e:	00 00                	add    BYTE PTR [bx+si],al
     a40:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a43:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     a47:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     a4a:	44                   	inc    sp
     a4b:	72 61                	jb     0xaae
     a4d:	67 4f                	addr32 dec di
     a4f:	76 65                	jbe    0xab6
     a51:	72 32                	jb     0xa85
     a53:	03 b5 0a 72          	add    si,WORD PTR [di+0x720a]
     a57:	00 ff                	add    bh,bh
     a59:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     a5c:	ff                   	(bad)
     a5d:	ff 01                	inc    WORD PTR [bx+di]
     a5f:	00 00                	add    BYTE PTR [bx+si],al
     a61:	00 00                	add    BYTE PTR [bx+si],al
     a63:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a66:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     a6a:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     a6d:	45                   	inc    bp
     a6e:	6e                   	outs   dx,BYTE PTR ds:[si]
     a6f:	64 44                	fs inc sp
     a71:	72 61                	jb     0xad4
     a73:	67 71 00             	addr32 jno 0xa76
     a76:	96                   	xchg   si,ax
     a77:	0a c8                	or     cl,al
     a79:	00 ff                	add    bh,bh
     a7b:	ff c8                	dec    ax
     a7d:	00 ff                	add    bh,bh
     a7f:	ff 01                	inc    WORD PTR [bx+di]
     a81:	00 00                	add    BYTE PTR [bx+si],al
     a83:	00 00                	add    BYTE PTR [bx+si],al
     a85:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a88:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     a8c:	07                   	pop    es
     a8d:	4f                   	dec    di
     a8e:	6e                   	outs   dx,BYTE PTR ds:[si]
     a8f:	45                   	inc    bp
     a90:	6e                   	outs   dx,BYTE PTR ds:[si]
     a91:	74 65                	je     0xaf8
     a93:	72 71                	jb     0xb06
     a95:	00 b4 0b d0          	add    BYTE PTR [si-0x2ff5],dh
     a99:	00 ff                	add    bh,bh
     a9b:	ff d0                	call   ax
     a9d:	00 ff                	add    bh,bh
     a9f:	ff 01                	inc    WORD PTR [bx+di]
     aa1:	00 00                	add    BYTE PTR [bx+si],al
     aa3:	00 00                	add    BYTE PTR [bx+si],al
     aa5:	80 00 00             	add    BYTE PTR [bx+si],0x0
     aa8:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     aac:	06                   	push   es
     aad:	4f                   	dec    di
     aae:	6e                   	outs   dx,BYTE PTR ds:[si]
     aaf:	45                   	inc    bp
     ab0:	78 69                	js     0xb1b
     ab2:	74 1a                	je     0xace
     ab4:	02 d7                	add    dl,bh
     ab6:	0a b0 00 ff          	or     dh,BYTE PTR [bx+si-0x100]
     aba:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     abe:	ff 01                	inc    WORD PTR [bx+di]
     ac0:	00 00                	add    BYTE PTR [bx+si],al
     ac2:	00 00                	add    BYTE PTR [bx+si],al
     ac4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ac7:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
     acb:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     ace:	4b                   	dec    bx
     acf:	65 79 44             	gs jns 0xb16
     ad2:	6f                   	outs   dx,WORD PTR ds:[si]
     ad3:	77 6e                	ja     0xb43
     ad5:	54                   	push   sp
     ad6:	02 fa                	add    bh,dl
     ad8:	0a b8 00 ff          	or     bh,BYTE PTR [bx+si-0x100]
     adc:	ff                   	(bad)
     add:	b8 00 ff             	mov    ax,0xff00
     ae0:	ff 01                	inc    WORD PTR [bx+di]
     ae2:	00 00                	add    BYTE PTR [bx+si],al
     ae4:	00 00                	add    BYTE PTR [bx+si],al
     ae6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ae9:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
     aed:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     af0:	4b                   	dec    bx
     af1:	65 79 50             	gs jns 0xb44
     af4:	72 65                	jb     0xb5b
     af6:	73 73                	jae    0xb6b
     af8:	1a 02                	sbb    al,BYTE PTR [bp+si]
     afa:	1a 0b                	sbb    cl,BYTE PTR [bp+di]
     afc:	c0 00 ff             	rol    BYTE PTR [bx+si],0xff
     aff:	ff c0                	inc    ax
     b01:	00 ff                	add    bh,bh
     b03:	ff 01                	inc    WORD PTR [bx+di]
     b05:	00 00                	add    BYTE PTR [bx+si],al
     b07:	00 00                	add    BYTE PTR [bx+si],al
     b09:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b0c:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
     b10:	07                   	pop    es
     b11:	4f                   	dec    di
     b12:	6e                   	outs   dx,BYTE PTR ds:[si]
     b13:	4b                   	dec    bx
     b14:	65 79 55             	gs jns 0xb6c
     b17:	70 71                	jo     0xb8a
     b19:	01 3e 0b 4a          	add    WORD PTR ds:0x4a0b,di
     b1d:	00 ff                	add    bh,bh
     b1f:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     b22:	ff                   	(bad)
     b23:	ff 01                	inc    WORD PTR [bx+di]
     b25:	00 00                	add    BYTE PTR [bx+si],al
     b27:	00 00                	add    BYTE PTR [bx+si],al
     b29:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b2c:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
     b30:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     b33:	4d                   	dec    bp
     b34:	6f                   	outs   dx,WORD PTR ds:[si]
     b35:	75 73                	jne    0xbaa
     b37:	65 44                	gs inc sp
     b39:	6f                   	outs   dx,WORD PTR ds:[si]
     b3a:	77 6e                	ja     0xbaa
     b3c:	ce                   	into
     b3d:	01 62 0b             	add    WORD PTR [bp+si+0xb],sp
     b40:	52                   	push   dx
     b41:	00 ff                	add    bh,bh
     b43:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     b46:	ff                   	(bad)
     b47:	ff 01                	inc    WORD PTR [bx+di]
     b49:	00 00                	add    BYTE PTR [bx+si],al
     b4b:	00 00                	add    BYTE PTR [bx+si],al
     b4d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b50:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
     b54:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     b57:	4d                   	dec    bp
     b58:	6f                   	outs   dx,WORD PTR ds:[si]
     b59:	75 73                	jne    0xbce
     b5b:	65 4d                	gs dec bp
     b5d:	6f                   	outs   dx,WORD PTR ds:[si]
     b5e:	76 65                	jbe    0xbc5
     b60:	71 01                	jno    0xb63
     b62:	f8                   	clc
     b63:	0b 5a 00             	or     bx,WORD PTR [bp+si+0x0]
     b66:	ff                   	(bad)
     b67:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     b6a:	ff                   	(bad)
     b6b:	ff 01                	inc    WORD PTR [bx+di]
     b6d:	00 00                	add    BYTE PTR [bx+si],al
     b6f:	00 00                	add    BYTE PTR [bx+si],al
     b71:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b74:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
     b78:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     b7b:	4d                   	dec    bp
     b7c:	6f                   	outs   dx,WORD PTR ds:[si]
     b7d:	75 73                	jne    0xbf2
     b7f:	65 55                	gs push bp
     b81:	70 5c                	jo     0xbdf
     b83:	0c 00                	or     al,0x0
     b85:	00 00                	add    BYTE PTR [bx+si],al
     b87:	00 36 0c 2a          	add    BYTE PTR ds:0x2a0c,dh
     b8b:	0c 26                	or     al,0x26
     b8d:	01 ba 19 6f          	add    WORD PTR [bp+si+0x6f19],di
     b91:	0c fa                	or     al,0xfa
     b93:	45                   	inc    bp
     b94:	08 0c                	or     BYTE PTR [si],cl
     b96:	9a 1f bb 0c cb       	call   0xcb0c:0xbb1f
     b9b:	1f                   	pop    ds
     b9c:	98                   	cbw
     b9d:	0b 8a 27 46          	or     cx,WORD PTR [bp+si+0x4627]
     ba1:	0c cd                	or     al,0xcd
     ba3:	11 ac 0b 3a          	adc    WORD PTR [si+0x3a0b],bp
     ba7:	27                   	daa
     ba8:	b0 0b                	mov    al,0xb
     baa:	fa                   	cli
     bab:	10 e8                	adc    al,ch
     bad:	0d d6 14             	or     ax,0x14d6
     bb0:	e0 0b                	loopne 0xbbd
     bb2:	f4                   	hlt
     bb3:	4f                   	dec    di
     bb4:	c4 0b                	les    cx,DWORD PTR [bp+di]
     bb6:	c4 27                	les    sp,DWORD PTR [bx]
     bb8:	e4 0b                	in     al,0xb
     bba:	ec                   	in     al,dx
     bbb:	30 18                	xor    BYTE PTR [bx+si],bl
     bbd:	0c 51                	or     al,0x51
     bbf:	1b a5 0c 38          	sbb    sp,WORD PTR [di+0x380c]
     bc3:	50                   	push   ax
     bc4:	cc                   	int3
     bc5:	0b 63 31             	or     sp,WORD PTR [bp+di+0x31]
     bc8:	e8 0b 21             	call   0x2cd6
     bcb:	50                   	push   ax
     bcc:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     bcd:	0b bf 26 a0          	or     di,WORD PTR [bx-0x5fda]
     bd1:	0b d9                	or     bx,cx
     bd3:	62                   	(bad)
     bd4:	d8 0b                	fmul   DWORD PTR [bp+di]
     bd6:	06                   	push   es
     bd7:	63 dc                	arpl   sp,bx
     bd9:	0b 8f 60 14          	or     cx,WORD PTR [bx+0x1460]
     bdd:	0c 3a                	or     al,0x3a
     bdf:	1c c0                	sbb    al,0xc0
     be1:	0b 83 2c d0          	or     ax,WORD PTR [bp+di-0x2fd4]
     be5:	0b 08                	or     cx,WORD PTR [bx+si]
     be7:	61                   	popa
     be8:	ec                   	in     al,dx
     be9:	0b 5c 61             	or     bx,WORD PTR [si+0x61]
     bec:	f0 0b 62 5c          	lock or sp,WORD PTR [bp+si+0x5c]
     bf0:	1c 0c                	sbb    al,0xc
     bf2:	3a 61 a8             	cmp    ah,BYTE PTR [bx+di-0x58]
     bf5:	0b 72 3f             	or     si,WORD PTR [bp+si+0x3f]
     bf8:	00 0c                	add    BYTE PTR [si],cl
     bfa:	6b 5d 0c 0c          	imul   bx,WORD PTR [di+0xc],0xc
     bfe:	17                   	pop    ss
     bff:	3e 94                	ds xchg sp,ax
     c01:	0b 13                	or     dx,WORD PTR [bp+di]
     c03:	28 b8 0b ed          	sub    BYTE PTR [bx+si-0x12f5],bh
     c07:	3e 10 0c             	adc    BYTE PTR ds:[si],cl
     c0a:	43                   	inc    bx
     c0b:	5f                   	pop    di
     c0c:	24 0c                	and    al,0xc
     c0e:	c2 35 d4             	ret    0xd435
     c11:	0b 1c                	or     bx,WORD PTR [si]
     c13:	48                   	dec    ax
     c14:	bc 0b ae             	mov    sp,0xae0b
     c17:	5f                   	pop    di
     c18:	c8 0b 35 62          	enter  0x350b,0x62
     c1c:	f4                   	hlt
     c1d:	0b 2f                	or     bp,WORD PTR [bx]
     c1f:	2d 04 0c             	sub    ax,0xc04
     c22:	9a 66 28 0c 56       	call   0x560c:0x2866
     c27:	67 90                	addr32 nop
     c29:	0b 0b                	or     cx,WORD PTR [bp+di]
     c2b:	54                   	push   sp
     c2c:	44                   	inc    sp
     c2d:	42                   	inc    dx
     c2e:	43                   	inc    bx
     c2f:	6f                   	outs   dx,WORD PTR ds:[si]
     c30:	6d                   	ins    WORD PTR es:[di],dx
     c31:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     c34:	6f                   	outs   dx,WORD PTR ds:[si]
     c35:	78 06                	js     0xc3d
     c37:	00 1b                	add    BYTE PTR [bp+di],bl
     c39:	0f ee ff             	pmaxsw mm7,mm7
     c3c:	fe                   	(bad)
     c3d:	ff                   	jmp    (bad)
     c3e:	ed                   	in     ax,dx
     c3f:	ff f1                	push   cx
     c41:	ff                   	jmp    (bad)
     c42:	ef                   	out    dx,ax
     c43:	ff 94 2d 4a          	call   WORD PTR [si+0x4a2d]
     c47:	0c d4                	or     al,0xd4
     c49:	29 4e 0c             	sub    WORD PTR [bp+0xc],cx
     c4c:	03 2a                	add    bp,WORD PTR [bp+si]
     c4e:	52                   	push   dx
     c4f:	0c 32                	or     al,0x32
     c51:	2a 56 0c             	sub    dl,BYTE PTR [bp+0xc]
     c54:	2f                   	das
     c55:	2b 5a 0c             	sub    bx,WORD PTR [bp+si+0xc]
     c58:	80 2b 6b             	sub    BYTE PTR [bp+di],0x6b
     c5b:	0c 07                	or     al,0x7
     c5d:	0b 54 44             	or     dx,WORD PTR [si+0x44]
     c60:	42                   	inc    dx
     c61:	43                   	inc    bx
     c62:	6f                   	outs   dx,WORD PTR ds:[si]
     c63:	6d                   	ins    WORD PTR es:[di],dx
     c64:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     c67:	6f                   	outs   dx,WORD PTR ds:[si]
     c68:	78 a2                	js     0xc0c
     c6a:	0b dd                	or     bx,bp
     c6c:	0c ae                	or     al,0xae
     c6e:	1a 7f 0c             	sbb    bh,BYTE PTR [bx+0xc]
     c71:	2e 00 07             	add    BYTE PTR cs:[bx],al
     c74:	44                   	inc    sp
     c75:	42                   	inc    dx
     c76:	43                   	inc    bx
     c77:	74 72                	je     0xceb
     c79:	6c                   	ins    BYTE PTR es:[di],dx
     c7a:	73 25                	jae    0xca1
     c7c:	00 93 18 87          	add    BYTE PTR [bp+di-0x78e8],dl
     c80:	0c e1                	or     al,0xe1
     c82:	00 ff                	add    bh,bh
     c84:	ff b3 5c c9          	push   WORD PTR [bp+di-0x36a4]
     c88:	0d 01 00             	or     ax,0x1
     c8b:	00 00                	add    BYTE PTR [bx+si],al
     c8d:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     c91:	00 00                	add    BYTE PTR [bx+si],al
     c93:	0a 00                	or     al,BYTE PTR [bx+si]
     c95:	05 53 74             	add    ax,0x7453
     c98:	79 6c                	jns    0xd06
     c9a:	65 02 00             	add    al,BYTE PTR gs:[bx+si]
     c9d:	a8 0d                	test   al,0xd
     c9f:	38 00                	cmp    BYTE PTR [bx+si],al
     ca1:	ff                   	(bad)
     ca2:	ff d5                	call   bp
     ca4:	1e                   	push   ds
     ca5:	a9 0c 17             	test   ax,0x170c
     ca8:	1f                   	pop    ds
     ca9:	c3                   	ret
     caa:	0c 00                	or     al,0x0
     cac:	80 fa ff             	cmp    dl,0xff
     caf:	ff                   	(bad)
     cb0:	ff 0b                	dec    WORD PTR [bp+di]
     cb2:	00 05                	add    BYTE PTR [di],al
     cb4:	43                   	inc    bx
     cb5:	6f                   	outs   dx,WORD PTR ds:[si]
     cb6:	6c                   	ins    BYTE PTR es:[di],dx
     cb7:	6f                   	outs   dx,WORD PTR ds:[si]
     cb8:	72 07                	jb     0xcc1
     cba:	23 d9                	and    bx,cx
     cbc:	0c a5                	or     al,0xa5
     cbe:	00 ff                	add    bh,bh
     cc0:	ff 22                	jmp    WORD PTR [bp+si]
     cc2:	63 c7                	arpl   di,ax
     cc4:	0c 54                	or     al,0x54
     cc6:	63 1e 0d 00          	arpl   WORD PTR ds:0xd,bx
     cca:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ccd:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
     cd1:	05 43 74             	add    ax,0x7443
     cd4:	6c                   	ins    BYTE PTR es:[di],dx
     cd5:	33 44 62             	xor    ax,WORD PTR [si+0x62]
     cd8:	23 62 0d             	and    sp,WORD PTR [bp+si+0xd]
     cdb:	92                   	xchg   dx,ax
     cdc:	2a e1                	sub    ah,cl
     cde:	0c bc                	or     al,0xbc
     ce0:	2a ff                	sub    bh,bh
     ce2:	0c 01                	or     al,0x1
     ce4:	00 00                	add    BYTE PTR [bx+si],al
     ce6:	00 00                	add    BYTE PTR [bx+si],al
     ce8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ceb:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     cef:	09 44 61             	or     WORD PTR [si+0x61],ax
     cf2:	74 61                	je     0xd55
     cf4:	46                   	inc    si
     cf5:	69 65 6c 64 04       	imul   sp,WORD PTR [di+0x6c],0x464
     cfa:	09 fc                	or     sp,di
     cfc:	12 52 2a             	adc    dl,BYTE PTR [bp+si+0x2a]
     cff:	03 0d                	add    cx,WORD PTR [di]
     d01:	76 2a                	jbe    0xd2d
     d03:	f0 0d 01 00          	lock or ax,0x1
     d07:	00 00                	add    BYTE PTR [bx+si],al
     d09:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     d0d:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
     d11:	0a 44 61             	or     al,BYTE PTR [si+0x61]
     d14:	74 61                	je     0xd77
     d16:	53                   	push   bx
     d17:	6f                   	outs   dx,WORD PTR ds:[si]
     d18:	75 72                	jne    0xd8c
     d1a:	63 65 25             	arpl   WORD PTR [di+0x25],sp
     d1d:	01 3f                	add    WORD PTR [bx],di
     d1f:	0d 2e 00             	or     ax,0x2e
     d22:	ff                   	(bad)
     d23:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     d27:	ff 01                	inc    WORD PTR [bx+di]
     d29:	00 00                	add    BYTE PTR [bx+si],al
     d2b:	00 00                	add    BYTE PTR [bx+si],al
     d2d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     d30:	00 00                	add    BYTE PTR [bx+si],al
     d32:	0f 00 08             	str    WORD PTR [bx+si]
     d35:	44                   	inc    sp
     d36:	72 61                	jb     0xd99
     d38:	67 4d                	addr32 dec bp
     d3a:	6f                   	outs   dx,WORD PTR ds:[si]
     d3b:	64 65 64 00 90 0d 3e 	fs gs add BYTE PTR fs:[bx+si+0x3e0d],dl
     d42:	00 ff                	add    bh,bh
     d44:	ff                   	(bad)
     d45:	3e 00 ff             	ds add bh,bh
     d48:	ff 01                	inc    WORD PTR [bx+di]
     d4a:	00 00                	add    BYTE PTR [bx+si],al
     d4c:	00 00                	add    BYTE PTR [bx+si],al
     d4e:	80 f4 ff             	xor    ah,0xff
     d51:	ff                   	(bad)
     d52:	ff 10                	call   WORD PTR [bx+si]
     d54:	00 0a                	add    BYTE PTR [bp+si],cl
     d56:	44                   	inc    sp
     d57:	72 61                	jb     0xdba
     d59:	67 43                	addr32 inc bx
     d5b:	75 72                	jne    0xdcf
     d5d:	73 6f                	jae    0xdce
     d5f:	72 d4                	jb     0xd35
     d61:	22 88 0d e6          	and    cl,BYTE PTR [bx+si-0x19f3]
     d65:	00 ff                	add    bh,bh
     d67:	ff e6                	jmp    si
     d69:	00 ff                	add    bh,bh
     d6b:	ff 01                	inc    WORD PTR [bx+di]
     d6d:	00 00                	add    BYTE PTR [bx+si],al
     d6f:	00 00                	add    BYTE PTR [bx+si],al
     d71:	80 08 00             	or     BYTE PTR [bx+si],0x0
     d74:	00 00                	add    BYTE PTR [bx+si],al
     d76:	11 00                	adc    WORD PTR [bx+si],ax
     d78:	0d 44 72             	or     ax,0x7244
     d7b:	6f                   	outs   dx,WORD PTR ds:[si]
     d7c:	70 44                	jo     0xdc2
     d7e:	6f                   	outs   dx,WORD PTR ds:[si]
     d7f:	77 6e                	ja     0xdef
     d81:	43                   	inc    bx
     d82:	6f                   	outs   dx,WORD PTR ds:[si]
     d83:	75 6e                	jne    0xdf3
     d85:	74 07                	je     0xd8e
     d87:	23 c5                	and    ax,bp
     d89:	0d 2a 00             	or     ax,0x2a
     d8c:	ff                   	(bad)
     d8d:	ff                   	(bad)
     d8e:	b8 1c b0             	mov    ax,0xb01c
     d91:	0d 01 00             	or     ax,0x1
     d94:	00 00                	add    BYTE PTR [bx+si],al
     d96:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     d9a:	00 00                	add    BYTE PTR [bx+si],al
     d9c:	12 00                	adc    al,BYTE PTR [bx+si]
     d9e:	07                   	pop    es
     d9f:	45                   	inc    bp
     da0:	6e                   	outs   dx,BYTE PTR ds:[si]
     da1:	61                   	popa
     da2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     da5:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     da8:	45                   	inc    bp
     da9:	1e                   	push   ds
     daa:	34 00                	xor    al,0x0
     dac:	ff                   	(bad)
     dad:	ff                   	jmp    (bad)
     dae:	eb 1d                	jmp    0xdcd
     db0:	b4 0d                	mov    ah,0xd
     db2:	08 1e 0e 0e          	or     BYTE PTR ds:0xe0e,bl
     db6:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     dba:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
     dbe:	04 46                	add    al,0x46
     dc0:	6f                   	outs   dx,WORD PTR ds:[si]
     dc1:	6e                   	outs   dx,BYTE PTR ds:[si]
     dc2:	74 d4                	je     0xd98
     dc4:	22 06 0e fa          	and    al,BYTE PTR ds:0xfa0e
     dc8:	5c                   	pop    sp
     dc9:	cd 0d                	int    0xd
     dcb:	35 5d 04             	xor    ax,0x45d
     dce:	0f 01 00             	sgdtw  [bx+si]
     dd1:	00 00                	add    BYTE PTR [bx+si],al
     dd3:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     dd7:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     ddb:	0a 49 74             	or     cl,BYTE PTR [bx+di+0x74]
     dde:	65 6d                	gs ins WORD PTR es:[di],dx
     de0:	48                   	dec    ax
     de1:	65 69 67 68 74 8b    	imul   sp,WORD PTR gs:[bx+0x68],0x8b74
     de7:	03 7c 0f             	add    di,WORD PTR [si+0xf]
     dea:	d8 00                	fadd   DWORD PTR [bx+si]
     dec:	ff                   	(bad)
     ded:	ff f1                	push   cx
     def:	2d be 0e             	sub    ax,0xebe
     df2:	01 00                	add    WORD PTR [bx+si],ax
     df4:	00 00                	add    BYTE PTR [bx+si],al
     df6:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     dfa:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     dfe:	05 49 74             	add    ax,0x7449
     e01:	65 6d                	gs ins WORD PTR es:[di],dx
     e03:	73 07                	jae    0xe0c
     e05:	23 2a                	and    bp,WORD PTR [bp+si]
     e07:	0e                   	push   cs
     e08:	2c 00                	sub    al,0x0
     e0a:	ff                   	(bad)
     e0b:	ff 32                	push   WORD PTR [bp+si]
     e0d:	1f                   	pop    ds
     e0e:	32 0e 01 00          	xor    cl,BYTE PTR ds:0x1
     e12:	00 00                	add    BYTE PTR [bx+si],al
     e14:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     e18:	00 00                	add    BYTE PTR [bx+si],al
     e1a:	16                   	push   ss
     e1b:	00 0b                	add    BYTE PTR [bp+di],cl
     e1d:	50                   	push   ax
     e1e:	61                   	popa
     e1f:	72 65                	jb     0xe86
     e21:	6e                   	outs   dx,BYTE PTR ds:[si]
     e22:	74 43                	je     0xe67
     e24:	6f                   	outs   dx,WORD PTR ds:[si]
     e25:	6c                   	ins    BYTE PTR es:[di],dx
     e26:	6f                   	outs   dx,WORD PTR ds:[si]
     e27:	72 07                	jb     0xe30
     e29:	23 4e 0e             	and    cx,WORD PTR [bp+0xe]
     e2c:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     e2d:	00 ff                	add    bh,bh
     e2f:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     e32:	56                   	push   si
     e33:	0e                   	push   cs
     e34:	01 00                	add    WORD PTR [bx+si],ax
     e36:	00 00                	add    BYTE PTR [bx+si],al
     e38:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     e3c:	00 00                	add    BYTE PTR [bx+si],al
     e3e:	17                   	pop    ss
     e3f:	00 0b                	add    BYTE PTR [bp+di],cl
     e41:	50                   	push   ax
     e42:	61                   	popa
     e43:	72 65                	jb     0xeaa
     e45:	6e                   	outs   dx,BYTE PTR ds:[si]
     e46:	74 43                	je     0xe8b
     e48:	74 6c                	je     0xeb6
     e4a:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     e4d:	23 71 0e             	and    si,WORD PTR [bx+di+0xe]
     e50:	2b 00                	sub    ax,WORD PTR [bx+si]
     e52:	ff                   	(bad)
     e53:	ff                   	(bad)
     e54:	3e 1e                	ds push ds
     e56:	79 0e                	jns    0xe66
     e58:	01 00                	add    WORD PTR [bx+si],ax
     e5a:	00 00                	add    BYTE PTR [bx+si],al
     e5c:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     e60:	00 00                	add    BYTE PTR [bx+si],al
     e62:	18 00                	sbb    BYTE PTR [bx+si],al
     e64:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     e67:	72 65                	jb     0xece
     e69:	6e                   	outs   dx,BYTE PTR ds:[si]
     e6a:	74 46                	je     0xeb2
     e6c:	6f                   	outs   dx,WORD PTR ds:[si]
     e6d:	6e                   	outs   dx,BYTE PTR ds:[si]
     e6e:	74 07                	je     0xe77
     e70:	23 ba 0e 49          	and    di,WORD PTR [bp+si+0x490e]
     e74:	00 ff                	add    bh,bh
     e76:	ff a1 1e e3          	jmp    WORD PTR [bx+di-0x1ce2]
     e7a:	0e                   	push   cs
     e7b:	01 00                	add    WORD PTR [bx+si],ax
     e7d:	00 00                	add    BYTE PTR [bx+si],al
     e7f:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     e83:	00 00                	add    BYTE PTR [bx+si],al
     e85:	19 00                	sbb    WORD PTR [bx+si],ax
     e87:	0e                   	push   cs
     e88:	50                   	push   ax
     e89:	61                   	popa
     e8a:	72 65                	jb     0xef1
     e8c:	6e                   	outs   dx,BYTE PTR ds:[si]
     e8d:	74 53                	je     0xee2
     e8f:	68 6f 77             	push   0x776f
     e92:	48                   	dec    ax
     e93:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     e98:	4f                   	dec    di
     e99:	14 40                	adc    al,0x40
     e9b:	00 ff                	add    bh,bh
     e9d:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     ea0:	ff                   	(bad)
     ea1:	ff 01                	inc    WORD PTR [bx+di]
     ea3:	00 00                	add    BYTE PTR [bx+si],al
     ea5:	00 00                	add    BYTE PTR [bx+si],al
     ea7:	80 00 00             	add    BYTE PTR [bx+si],0x0
     eaa:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     eae:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     eb1:	70 75                	jo     0xf28
     eb3:	70 4d                	jo     0xf02
     eb5:	65 6e                	outs   dx,BYTE PTR gs:[si]
     eb7:	75 07                	jne    0xec0
     eb9:	23 db                	and    bx,bx
     ebb:	0e                   	push   cs
     ebc:	d7                   	xlat   BYTE PTR ds:[bx]
     ebd:	2a c2                	sub    al,dl
     ebf:	0e                   	push   cs
     ec0:	f1                   	int1
     ec1:	2a 6f 11             	sub    ch,BYTE PTR [bx+0x11]
     ec4:	01 00                	add    WORD PTR [bx+si],ax
     ec6:	00 00                	add    BYTE PTR [bx+si],al
     ec8:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     ecc:	00 00                	add    BYTE PTR [bx+si],al
     ece:	1b 00                	sbb    ax,WORD PTR [bx+si]
     ed0:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
     ed3:	61                   	popa
     ed4:	64 4f                	fs dec di
     ed6:	6e                   	outs   dx,BYTE PTR ds:[si]
     ed7:	6c                   	ins    BYTE PTR es:[di],dx
     ed8:	79 07                	jns    0xee1
     eda:	23 fc                	and    di,sp
     edc:	0e                   	push   cs
     edd:	48                   	dec    ax
     ede:	00 ff                	add    bh,bh
     ee0:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     ee3:	e7 0e                	out    0xe,ax
     ee5:	23 1e 1b 0f          	and    bx,WORD PTR ds:0xf1b
     ee9:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     eed:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
     ef1:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     ef4:	6f                   	outs   dx,WORD PTR ds:[si]
     ef5:	77 48                	ja     0xf3f
     ef7:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
     efc:	3c 0f                	cmp    al,0xf
     efe:	e0 00                	loopne 0xf00
     f00:	ff                   	(bad)
     f01:	ff 90 5c 26          	call   WORD PTR [bx+si+0x265c]
     f05:	10 01                	adc    BYTE PTR [bx+di],al
     f07:	00 00                	add    BYTE PTR [bx+si],al
     f09:	00 00                	add    BYTE PTR [bx+si],al
     f0b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     f0e:	00 00                	add    BYTE PTR [bx+si],al
     f10:	1d 00 06             	sbb    ax,0x600
     f13:	53                   	push   bx
     f14:	6f                   	outs   dx,WORD PTR ds:[si]
     f15:	72 74                	jb     0xf8b
     f17:	65 64 52             	gs fs push dx
     f1a:	01 1f                	add    WORD PTR [bx],bx
     f1c:	0f a6                	(bad)
     f1e:	63 23                	arpl   WORD PTR [bp+di],sp
     f20:	0f 60 64 44          	punpcklbw mm4,DWORD PTR [si+0x44]
     f24:	0f 01 00             	sgdtw  [bx+si]
     f27:	00 00                	add    BYTE PTR [bx+si],al
     f29:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     f2d:	ff                   	(bad)
     f2e:	ff 1e 00 08          	call   DWORD PTR ds:0x800
     f32:	54                   	push   sp
     f33:	61                   	popa
     f34:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     f37:	64 65 72 07          	fs gs jb 0xf42
     f3b:	23 5c 0f             	and    bx,WORD PTR [si+0xf]
     f3e:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     f3f:	00 ff                	add    bh,bh
     f41:	ff 88 64 64          	dec    WORD PTR [bx+si+0x6464]
     f45:	0f 01 00             	sgdtw  [bx+si]
     f48:	00 00                	add    BYTE PTR [bx+si],al
     f4a:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     f4e:	00 00                	add    BYTE PTR [bx+si],al
     f50:	09 00                	or     WORD PTR [bx+si],ax
     f52:	07                   	pop    es
     f53:	54                   	push   sp
     f54:	61                   	popa
     f55:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     f58:	6f                   	outs   dx,WORD PTR ds:[si]
     f59:	70 07                	jo     0xf62
     f5b:	23 1f                	and    bx,WORD PTR [bx]
     f5d:	12 29                	adc    ch,BYTE PTR [bx+di]
     f5f:	00 ff                	add    bh,bh
     f61:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     f64:	e0 0f                	loopne 0xf75
     f66:	01 00                	add    WORD PTR [bx+si],ax
     f68:	00 00                	add    BYTE PTR [bx+si],al
     f6a:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     f6e:	00 00                	add    BYTE PTR [bx+si],al
     f70:	1f                   	pop    ds
     f71:	00 07                	add    BYTE PTR [bx],al
     f73:	56                   	push   si
     f74:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     f79:	65 71 00             	gs jno 0xf7c
     f7c:	9d                   	popf
     f7d:	0f 1a 01             	bndldx bnd0,(bad)
     f80:	ff                   	(bad)
     f81:	ff 1a                	call   DWORD PTR [bp+si]
     f83:	01 ff                	add    di,di
     f85:	ff 01                	inc    WORD PTR [bx+di]
     f87:	00 00                	add    BYTE PTR [bx+si],al
     f89:	00 00                	add    BYTE PTR [bx+si],al
     f8b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     f8e:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
     f92:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     f95:	43                   	inc    bx
     f96:	68 61 6e             	push   0x6e61
     f99:	67 65 71 00          	addr32 gs jno 0xf9d
     f9d:	bd 0f 7a             	mov    bp,0x7a0f
     fa0:	00 ff                	add    bh,bh
     fa2:	ff                   	(bad)
     fa3:	7a 00                	jp     0xfa5
     fa5:	ff                   	(bad)
     fa6:	ff 01                	inc    WORD PTR [bx+di]
     fa8:	00 00                	add    BYTE PTR [bx+si],al
     faa:	00 00                	add    BYTE PTR [bx+si],al
     fac:	80 00 00             	add    BYTE PTR [bx+si],0x0
     faf:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     fb3:	07                   	pop    es
     fb4:	4f                   	dec    di
     fb5:	6e                   	outs   dx,BYTE PTR ds:[si]
     fb6:	43                   	inc    bx
     fb7:	6c                   	ins    BYTE PTR es:[di],dx
     fb8:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     fbd:	49                   	dec    cx
     fbe:	10 82 00 ff          	adc    BYTE PTR [bp+si-0x100],al
     fc2:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     fc6:	ff 01                	inc    WORD PTR [bx+di]
     fc8:	00 00                	add    BYTE PTR [bx+si],al
     fca:	00 00                	add    BYTE PTR [bx+si],al
     fcc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     fcf:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     fd3:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     fd6:	44                   	inc    sp
     fd7:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     fda:	6c                   	ins    BYTE PTR es:[di],dx
     fdb:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     fe0:	03 10                	add    dx,WORD PTR [bx+si]
     fe2:	62 00                	bound  ax,DWORD PTR [bx+si]
     fe4:	ff                   	(bad)
     fe5:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     fe8:	ff                   	(bad)
     fe9:	ff 01                	inc    WORD PTR [bx+di]
     feb:	00 00                	add    BYTE PTR [bx+si],al
     fed:	00 00                	add    BYTE PTR [bx+si],al
     fef:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ff2:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     ff6:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     ff9:	44                   	inc    sp
     ffa:	72 61                	jb     0x105d
     ffc:	67 44                	addr32 inc sp
     ffe:	72 6f                	jb     0x106f
    1000:	70 80                	jo     0xf82
    1002:	02 6c 10             	add    ch,BYTE PTR [si+0x10]
    1005:	6a 00                	push   0x0
    1007:	ff                   	(bad)
    1008:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    100b:	ff                   	(bad)
    100c:	ff 01                	inc    WORD PTR [bx+di]
    100e:	00 00                	add    BYTE PTR [bx+si],al
    1010:	00 00                	add    BYTE PTR [bx+si],al
    1012:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1015:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
    1019:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    101c:	44                   	inc    sp
    101d:	72 61                	jb     0x1080
    101f:	67 4f                	addr32 dec di
    1021:	76 65                	jbe    0x1088
    1023:	72 f8                	jb     0x101d
    1025:	18 32                	sbb    BYTE PTR [bp+si],dh
    1027:	11 06 01 ff          	adc    WORD PTR ds:0xff01,ax
    102b:	ff 06 01 ff          	inc    WORD PTR ds:0xff01
    102f:	ff 01                	inc    WORD PTR [bx+di]
    1031:	00 00                	add    BYTE PTR [bx+si],al
    1033:	00 00                	add    BYTE PTR [bx+si],al
    1035:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1038:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
    103c:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    103f:	44                   	inc    sp
    1040:	72 61                	jb     0x10a3
    1042:	77 49                	ja     0x108d
    1044:	74 65                	je     0x10ab
    1046:	6d                   	ins    WORD PTR es:[di],dx
    1047:	71 00                	jno    0x1049
    1049:	8e 10                	mov    ss,WORD PTR [bx+si]
    104b:	fe 00                	inc    BYTE PTR [bx+si]
    104d:	ff                   	(bad)
    104e:	ff                   	(bad)
    104f:	fe 00                	inc    BYTE PTR [bx+si]
    1051:	ff                   	(bad)
    1052:	ff 01                	inc    WORD PTR [bx+di]
    1054:	00 00                	add    BYTE PTR [bx+si],al
    1056:	00 00                	add    BYTE PTR [bx+si],al
    1058:	80 00 00             	add    BYTE PTR [bx+si],0x0
    105b:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
    105f:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1062:	44                   	inc    sp
    1063:	72 6f                	jb     0x10d4
    1065:	70 44                	jo     0x10ab
    1067:	6f                   	outs   dx,WORD PTR ds:[si]
    1068:	77 6e                	ja     0x10d8
    106a:	32 03                	xor    al,BYTE PTR [bp+di]
    106c:	cd 10                	int    0x10
    106e:	72 00                	jb     0x1070
    1070:	ff                   	(bad)
    1071:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    1074:	ff                   	(bad)
    1075:	ff 01                	inc    WORD PTR [bx+di]
    1077:	00 00                	add    BYTE PTR [bx+si],al
    1079:	00 00                	add    BYTE PTR [bx+si],al
    107b:	80 00 00             	add    BYTE PTR [bx+si],0x0
    107e:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
    1082:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    1085:	45                   	inc    bp
    1086:	6e                   	outs   dx,BYTE PTR ds:[si]
    1087:	64 44                	fs inc sp
    1089:	72 61                	jb     0x10ec
    108b:	67 71 00             	addr32 jno 0x108e
    108e:	ae                   	scas   al,BYTE PTR es:[di]
    108f:	10 c8                	adc    al,cl
    1091:	00 ff                	add    bh,bh
    1093:	ff c8                	dec    ax
    1095:	00 ff                	add    bh,bh
    1097:	ff 01                	inc    WORD PTR [bx+di]
    1099:	00 00                	add    BYTE PTR [bx+si],al
    109b:	00 00                	add    BYTE PTR [bx+si],al
    109d:	80 00 00             	add    BYTE PTR [bx+si],0x0
    10a0:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
    10a4:	07                   	pop    es
    10a5:	4f                   	dec    di
    10a6:	6e                   	outs   dx,BYTE PTR ds:[si]
    10a7:	45                   	inc    bp
    10a8:	6e                   	outs   dx,BYTE PTR ds:[si]
    10a9:	74 65                	je     0x1110
    10ab:	72 71                	jb     0x111e
    10ad:	00 47 12             	add    BYTE PTR [bx+0x12],al
    10b0:	d0 00                	rol    BYTE PTR [bx+si],1
    10b2:	ff                   	(bad)
    10b3:	ff d0                	call   ax
    10b5:	00 ff                	add    bh,bh
    10b7:	ff 01                	inc    WORD PTR [bx+di]
    10b9:	00 00                	add    BYTE PTR [bx+si],al
    10bb:	00 00                	add    BYTE PTR [bx+si],al
    10bd:	80 00 00             	add    BYTE PTR [bx+si],0x0
    10c0:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
    10c4:	06                   	push   es
    10c5:	4f                   	dec    di
    10c6:	6e                   	outs   dx,BYTE PTR ds:[si]
    10c7:	45                   	inc    bp
    10c8:	78 69                	js     0x1133
    10ca:	74 1a                	je     0x10e6
    10cc:	02 ef                	add    ch,bh
    10ce:	10 b0 00 ff          	adc    BYTE PTR [bx+si-0x100],dh
    10d2:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    10d6:	ff 01                	inc    WORD PTR [bx+di]
    10d8:	00 00                	add    BYTE PTR [bx+si],al
    10da:	00 00                	add    BYTE PTR [bx+si],al
    10dc:	80 00 00             	add    BYTE PTR [bx+si],0x0
    10df:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
    10e3:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    10e6:	4b                   	dec    bx
    10e7:	65 79 44             	gs jns 0x112e
    10ea:	6f                   	outs   dx,WORD PTR ds:[si]
    10eb:	77 6e                	ja     0x115b
    10ed:	54                   	push   sp
    10ee:	02 12                	add    dl,BYTE PTR [bp+si]
    10f0:	11 b8 00 ff          	adc    WORD PTR [bx+si-0x100],di
    10f4:	ff                   	(bad)
    10f5:	b8 00 ff             	mov    ax,0xff00
    10f8:	ff 01                	inc    WORD PTR [bx+di]
    10fa:	00 00                	add    BYTE PTR [bx+si],al
    10fc:	00 00                	add    BYTE PTR [bx+si],al
    10fe:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1101:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
    1105:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1108:	4b                   	dec    bx
    1109:	65 79 50             	gs jns 0x115c
    110c:	72 65                	jb     0x1173
    110e:	73 73                	jae    0x1183
    1110:	1a 02                	sbb    al,BYTE PTR [bp+si]
    1112:	97                   	xchg   di,ax
    1113:	12 c0                	adc    al,al
    1115:	00 ff                	add    bh,bh
    1117:	ff c0                	inc    ax
    1119:	00 ff                	add    bh,bh
    111b:	ff 01                	inc    WORD PTR [bx+di]
    111d:	00 00                	add    BYTE PTR [bx+si],al
    111f:	00 00                	add    BYTE PTR [bx+si],al
    1121:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1124:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
    1128:	07                   	pop    es
    1129:	4f                   	dec    di
    112a:	6e                   	outs   dx,BYTE PTR ds:[si]
    112b:	4b                   	dec    bx
    112c:	65 79 55             	gs jns 0x1184
    112f:	70 51                	jo     0x1182
    1131:	19 80 17 0e          	sbb    WORD PTR [bx+si+0xe17],ax
    1135:	01 ff                	add    di,di
    1137:	ff 0e 01 ff          	dec    WORD PTR ds:0xff01
    113b:	ff 01                	inc    WORD PTR [bx+di]
    113d:	00 00                	add    BYTE PTR [bx+si],al
    113f:	00 00                	add    BYTE PTR [bx+si],al
    1141:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1144:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
    1148:	0d 4f 6e             	or     ax,0x6e4f
    114b:	4d                   	dec    bp
    114c:	65 61                	gs popa
    114e:	73 75                	jae    0x11c5
    1150:	72 65                	jb     0x11b7
    1152:	49                   	dec    cx
    1153:	74 65                	je     0x11ba
    1155:	6d                   	ins    WORD PTR es:[di],dx
    1156:	03 0c                	add    cx,WORD PTR [si]
    1158:	54                   	push   sp
    1159:	4e                   	dec    si
    115a:	61                   	popa
    115b:	76 69                	jbe    0x11c6
    115d:	67 61                	addr32 popa
    115f:	74 65                	je     0x11c6
    1161:	42                   	inc    dx
    1162:	74 6e                	je     0x11d2
    1164:	00 00                	add    BYTE PTR [bx+si],al
    1166:	00 00                	add    BYTE PTR [bx+si],al
    1168:	00 09                	add    BYTE PTR [bx+di],cl
    116a:	00 00                	add    BYTE PTR [bx+si],al
    116c:	00 56 11             	add    BYTE PTR [bp+0x11],dl
    116f:	d1 11                	rcl    WORD PTR [bx+di],1
    1171:	07                   	pop    es
    1172:	6e                   	outs   dx,BYTE PTR ds:[si]
    1173:	62 46 69             	bound  ax,DWORD PTR [bp+0x69]
    1176:	72 73                	jb     0x11eb
    1178:	74 07                	je     0x1181
    117a:	6e                   	outs   dx,BYTE PTR ds:[si]
    117b:	62 50 72             	bound  dx,DWORD PTR [bx+si+0x72]
    117e:	69 6f 72 06 6e       	imul   bp,WORD PTR [bx+0x72],0x6e06
    1183:	62 4e 65             	bound  cx,DWORD PTR [bp+0x65]
    1186:	78 74                	js     0x11fc
    1188:	06                   	push   es
    1189:	6e                   	outs   dx,BYTE PTR ds:[si]
    118a:	62 4c 61             	bound  cx,DWORD PTR [si+0x61]
    118d:	73 74                	jae    0x1203
    118f:	08 6e 62             	or     BYTE PTR [bp+0x62],ch
    1192:	49                   	dec    cx
    1193:	6e                   	outs   dx,BYTE PTR ds:[si]
    1194:	73 65                	jae    0x11fb
    1196:	72 74                	jb     0x120c
    1198:	08 6e 62             	or     BYTE PTR [bp+0x62],ch
    119b:	44                   	inc    sp
    119c:	65 6c                	gs ins BYTE PTR es:[di],dx
    119e:	65 74 65             	gs je  0x1206
    11a1:	06                   	push   es
    11a2:	6e                   	outs   dx,BYTE PTR ds:[si]
    11a3:	62 45 64             	bound  ax,DWORD PTR [di+0x64]
    11a6:	69 74 06 6e 62       	imul   si,WORD PTR [si+0x6],0x626e
    11ab:	50                   	push   ax
    11ac:	6f                   	outs   dx,WORD PTR ds:[si]
    11ad:	73 74                	jae    0x1223
    11af:	08 6e 62             	or     BYTE PTR [bp+0x62],ch
    11b2:	43                   	inc    bx
    11b3:	61                   	popa
    11b4:	6e                   	outs   dx,BYTE PTR ds:[si]
    11b5:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
    11b8:	09 6e 62             	or     WORD PTR [bp+0x62],bp
    11bb:	52                   	push   dx
    11bc:	65 66 72 65          	gs data32 jb 0x1225
    11c0:	73 68                	jae    0x122a
    11c2:	06                   	push   es
    11c3:	0a 54 42             	or     dl,BYTE PTR [si+0x42]
    11c6:	75 74                	jne    0x123c
    11c8:	74 6f                	je     0x1239
    11ca:	6e                   	outs   dx,BYTE PTR ds:[si]
    11cb:	53                   	push   bx
    11cc:	65 74 03             	gs je  0x11d2
    11cf:	56                   	push   si
    11d0:	11 37                	adc    WORD PTR [bx],si
    11d2:	12 08                	adc    cl,BYTE PTR [bx+si]
    11d4:	09 45 4e             	or     WORD PTR [di+0x4e],ax
    11d7:	61                   	popa
    11d8:	76 43                	jbe    0x121d
    11da:	6c                   	ins    BYTE PTR es:[di],dx
    11db:	69 63 6b 00 02       	imul   sp,WORD PTR [bp+di+0x6b],0x200
    11e0:	00 06 53 65          	add    BYTE PTR ds:0x6553,al
    11e4:	6e                   	outs   dx,BYTE PTR ds:[si]
    11e5:	64 65 72 07          	fs gs jb 0x11f0
    11e9:	54                   	push   sp
    11ea:	4f                   	dec    di
    11eb:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
    11ee:	63 74 00             	arpl   WORD PTR [si+0x0],si
    11f1:	06                   	push   es
    11f2:	42                   	inc    dx
    11f3:	75 74                	jne    0x1269
    11f5:	74 6f                	je     0x1266
    11f7:	6e                   	outs   dx,BYTE PTR ds:[si]
    11f8:	0c 54                	or     al,0x54
    11fa:	4e                   	dec    si
    11fb:	61                   	popa
    11fc:	76 69                	jbe    0x1267
    11fe:	67 61                	addr32 popa
    1200:	74 65                	je     0x1267
    1202:	42                   	inc    dx
    1203:	74 6e                	je     0x1273
    1205:	d8 12                	fcom   DWORD PTR [bp+si]
    1207:	00 00                	add    BYTE PTR [bx+si],al
    1209:	00 00                	add    BYTE PTR [bx+si],al
    120b:	b2 12                	mov    dl,0x12
    120d:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    120e:	12 2f                	adc    ch,BYTE PTR [bx]
    1210:	01 c9                	add    cx,cx
    1212:	0c ec                	or     al,0xec
    1214:	12 fa                	adc    bh,dl
    1216:	45                   	inc    bp
    1217:	8b 12                	mov    dx,WORD PTR [bp+si]
    1219:	9a 1f a8 13 cb       	call   0xcb13:0xa81f
    121e:	1f                   	pop    ds
    121f:	1b 12                	sbb    dx,WORD PTR [bp+si]
    1221:	00 2f                	add    BYTE PTR [bx],ch
    1223:	73 12                	jae    0x1237
    1225:	cd 11                	int    0x11
    1227:	2f                   	das
    1228:	12 89 29 a3          	adc    cl,BYTE PTR [bx+di-0x5cd7]
    122c:	12 fa                	adc    bh,dl
    122e:	10 e6                	adc    dh,ah
    1230:	13 d6                	adc    dx,si
    1232:	14 63                	adc    al,0x63
    1234:	12 6c 3c             	adc    ch,BYTE PTR [si+0x3c]
    1237:	3b 12                	cmp    dx,WORD PTR [bp+si]
    1239:	fd                   	std
    123a:	31 53 12             	xor    WORD PTR [bp+di+0x12],dx
    123d:	ec                   	in     al,dx
    123e:	30 9b 12 51          	xor    BYTE PTR [bp+di+0x5112],bl
    1242:	1b 46 13             	sbb    ax,WORD PTR [bp+0x13]
    1245:	38 50 4f             	cmp    BYTE PTR [bx+si+0x4f],dl
    1248:	12 63 31             	adc    ah,BYTE PTR [bp+di+0x31]
    124b:	6b 12 21             	imul   dx,WORD PTR [bp+si],0x21
    124e:	50                   	push   ax
    124f:	27                   	daa
    1250:	12 1f                	adc    bl,BYTE PTR [bx]
    1252:	2e 23 12             	and    dx,WORD PTR cs:[bp+si]
    1255:	d9 62 5b             	fldenv [bp+si+0x5b]
    1258:	12 06 63 5f          	adc    al,BYTE PTR ds:0x5f63
    125c:	12 8f 60 3f          	adc    cl,BYTE PTR [bx+0x3f60]
    1260:	12 3a                	adc    bh,BYTE PTR [bp+si]
    1262:	1c 43                	sbb    al,0x43
    1264:	12 46 44             	adc    al,BYTE PTR [bp+0x44]
    1267:	4b                   	dec    bx
    1268:	12 08                	adc    cl,BYTE PTR [bx+si]
    126a:	61                   	popa
    126b:	6f                   	outs   dx,WORD PTR ds:[si]
    126c:	12 5c 61             	adc    bl,BYTE PTR [si+0x61]
    126f:	9f                   	lahf
    1270:	12 ac 34 c2          	adc    ch,BYTE PTR [si-0x3dcc]
    1274:	12 3a                	adc    bh,BYTE PTR [bp+si]
    1276:	61                   	popa
    1277:	33 12                	xor    dx,WORD PTR [bp+si]
    1279:	72 3f                	jb     0x12ba
    127b:	83 12 61             	adc    WORD PTR [bp+si],0x61
    127e:	28 93 12 17          	sub    BYTE PTR [bp+di+0x1712],dl
    1282:	3e 87 12             	xchg   WORD PTR ds:[bp+si],dx
    1285:	88 3c                	mov    BYTE PTR [si],bh
    1287:	17                   	pop    ss
    1288:	12 ed                	adc    ch,ch
    128a:	3e 8f                	ds (bad)
    128c:	12 77 3e             	adc    dh,BYTE PTR [bx+0x3e]
    128f:	57                   	push   di
    1290:	12 1e 29 2b          	adc    bl,BYTE PTR ds:0x2b29
    1294:	12 26 6d 7b          	adc    ah,BYTE PTR ds:0x7b6d
    1298:	12 ae 5f 67          	adc    ch,BYTE PTR [bp+0x675f]
    129c:	12 35                	adc    dh,BYTE PTR [di]
    129e:	62 77 12             	bound  si,DWORD PTR [bx+0x12]
    12a1:	43                   	inc    bx
    12a2:	2a 13                	sub    dl,BYTE PTR [bp+di]
    12a4:	12 0c                	adc    cl,BYTE PTR [si]
    12a6:	54                   	push   sp
    12a7:	44                   	inc    sp
    12a8:	42                   	inc    dx
    12a9:	4e                   	dec    si
    12aa:	61                   	popa
    12ab:	76 69                	jbe    0x1316
    12ad:	67 61                	addr32 popa
    12af:	74 6f                	je     0x1320
    12b1:	72 06                	jb     0x12b9
    12b3:	00 05                	add    BYTE PTR [di],al
    12b5:	00 07                	add    BYTE PTR [bx],al
    12b7:	00 08                	add    BYTE PTR [bx+si],cl
    12b9:	00 87 00 0c          	add    BYTE PTR [bx+0xc00],al
    12bd:	0f f1 ff             	psllw  mm7,mm7
    12c0:	ea 34 c6 12 88       	jmp    0x8812:0xc634
    12c5:	37                   	aaa
    12c6:	ca 12 ab             	retf   0xab12
    12c9:	37                   	aaa
    12ca:	ce                   	into
    12cb:	12 36 39 d2          	adc    dh,BYTE PTR ds:0xd239
    12cf:	12 f3                	adc    dh,bl
    12d1:	3b d6                	cmp    dx,si
    12d3:	12 ce                	adc    cl,dh
    12d5:	37                   	aaa
    12d6:	e8 12 07             	call   0x19eb
    12d9:	0c 54                	or     al,0x54
    12db:	44                   	inc    sp
    12dc:	42                   	inc    dx
    12dd:	4e                   	dec    si
    12de:	61                   	popa
    12df:	76 69                	jbe    0x134a
    12e1:	67 61                	addr32 popa
    12e3:	74 6f                	je     0x1354
    12e5:	72 25                	jb     0x130c
    12e7:	12 00                	adc    al,BYTE PTR [bx+si]
    12e9:	13 6a 0d             	adc    bp,WORD PTR [bp+si+0xd]
    12ec:	41                   	inc    cx
    12ed:	2e 21 00             	and    WORD PTR cs:[bx+si],ax
    12f0:	07                   	pop    es
    12f1:	44                   	inc    sp
    12f2:	42                   	inc    dx
    12f3:	43                   	inc    bx
    12f4:	74 72                	je     0x1368
    12f6:	6c                   	ins    BYTE PTR es:[di],dx
    12f7:	73 18                	jae    0x1311
    12f9:	00 04                	add    BYTE PTR [si],al
    12fb:	09 05                	or     WORD PTR [di],ax
    12fd:	17                   	pop    ss
    12fe:	48                   	dec    ax
    12ff:	3c 04                	cmp    al,0x4
    1301:	13 1b                	adc    bx,WORD PTR [bp+di]
    1303:	3c 1f                	cmp    al,0x1f
    1305:	13 01                	adc    ax,WORD PTR [bx+di]
    1307:	00 00                	add    BYTE PTR [bx+si],al
    1309:	00 00                	add    BYTE PTR [bx+si],al
    130b:	80 00 00             	add    BYTE PTR [bx+si],0x0
    130e:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
    1312:	0a 44 61             	or     al,BYTE PTR [si+0x61]
    1315:	74 61                	je     0x1378
    1317:	53                   	push   bx
    1318:	6f                   	outs   dx,WORD PTR ds:[si]
    1319:	75 72                	jne    0x138d
    131b:	63 65 c2             	arpl   WORD PTR [di-0x3e],sp
    131e:	11 27                	adc    WORD PTR [bx],sp
    1320:	13 f1                	adc    si,cx
    1322:	00 ff                	add    bh,bh
    1324:	ff 4c 32             	dec    WORD PTR [si+0x32]
    1327:	ee                   	out    dx,al
    1328:	13 01                	adc    ax,WORD PTR [bx+di]
    132a:	00 00                	add    BYTE PTR [bx+si],al
    132c:	00 00                	add    BYTE PTR [bx+si],al
    132e:	80 ff 03             	cmp    bh,0x3
    1331:	00 00                	add    BYTE PTR [bx+si],al
    1333:	0a 00                	or     al,BYTE PTR [bx+si]
    1335:	0e                   	push   cs
    1336:	56                   	push   si
    1337:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    133c:	65 42                	gs inc dx
    133e:	75 74                	jne    0x13b4
    1340:	74 6f                	je     0x13b1
    1342:	6e                   	outs   dx,BYTE PTR ds:[si]
    1343:	73 e2                	jae    0x1327
    1345:	00 4e 13             	add    BYTE PTR [bp+0x13],cl
    1348:	2d 00 ff             	sub    ax,0xff00
    134b:	ff 72 16             	push   WORD PTR [bp+si+0x16]
    134e:	64 13 01             	adc    ax,WORD PTR fs:[bx+di]
    1351:	00 00                	add    BYTE PTR [bx+si],al
    1353:	00 00                	add    BYTE PTR [bx+si],al
    1355:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1358:	00 00                	add    BYTE PTR [bx+si],al
    135a:	0b 00                	or     ax,WORD PTR [bx+si]
    135c:	05 41 6c             	add    ax,0x6c41
    135f:	69 67 6e 64 00       	imul   sp,WORD PTR [bx+0x6e],0x64
    1364:	87 13                	xchg   WORD PTR [bp+di],dx
    1366:	3e 00 ff             	ds add bh,bh
    1369:	ff                   	(bad)
    136a:	3e 00 ff             	ds add bh,bh
    136d:	ff 01                	inc    WORD PTR [bx+di]
    136f:	00 00                	add    BYTE PTR [bx+si],al
    1371:	00 00                	add    BYTE PTR [bx+si],al
    1373:	80 f4 ff             	xor    ah,0xff
    1376:	ff                   	(bad)
    1377:	ff 0c                	dec    WORD PTR [si]
    1379:	00 0a                	add    BYTE PTR [bp+si],cl
    137b:	44                   	inc    sp
    137c:	72 61                	jb     0x13df
    137e:	67 43                	addr32 inc bx
    1380:	75 72                	jne    0x13f4
    1382:	73 6f                	jae    0x13f3
    1384:	72 25                	jb     0x13ab
    1386:	01 b0 13 2e          	add    WORD PTR [bx+si+0x2e13],si
    138a:	00 ff                	add    bh,bh
    138c:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
    1390:	ff 01                	inc    WORD PTR [bx+di]
    1392:	00 00                	add    BYTE PTR [bx+si],al
    1394:	00 00                	add    BYTE PTR [bx+si],al
    1396:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1399:	00 00                	add    BYTE PTR [bx+si],al
    139b:	0d 00 08             	or     ax,0x800
    139e:	44                   	inc    sp
    139f:	72 61                	jb     0x1402
    13a1:	67 4d                	addr32 dec bp
    13a3:	6f                   	outs   dx,WORD PTR ds:[si]
    13a4:	64 65 07             	fs gs pop es
    13a7:	23 c8                	and    cx,ax
    13a9:	13 2a                	adc    bp,WORD PTR [bp+si]
    13ab:	00 ff                	add    bh,bh
    13ad:	ff                   	(bad)
    13ae:	b8 1c d0             	mov    ax,0xd01c
    13b1:	13 01                	adc    ax,WORD PTR [bx+di]
    13b3:	00 00                	add    BYTE PTR [bx+si],al
    13b5:	00 00                	add    BYTE PTR [bx+si],al
    13b7:	80 01 00             	add    BYTE PTR [bx+di],0x0
    13ba:	00 00                	add    BYTE PTR [bx+si],al
    13bc:	0e                   	push   cs
    13bd:	00 07                	add    BYTE PTR [bx],al
    13bf:	45                   	inc    bp
    13c0:	6e                   	outs   dx,BYTE PTR ds:[si]
    13c1:	61                   	popa
    13c2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    13c5:	64 07                	fs pop es
    13c7:	23 04                	and    ax,WORD PTR [si]
    13c9:	14 a5                	adc    al,0xa5
    13cb:	00 ff                	add    bh,bh
    13cd:	ff 22                	jmp    WORD PTR [bp+si]
    13cf:	63 d4                	arpl   sp,dx
    13d1:	13 54 63             	adc    dx,WORD PTR [si+0x63]
    13d4:	0c 14                	or     al,0x14
    13d6:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    13da:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
    13de:	05 43 74             	add    ax,0x7443
    13e1:	6c                   	ins    BYTE PTR es:[di],dx
    13e2:	33 44 8b             	xor    ax,WORD PTR [si-0x75]
    13e5:	03 39                	add    di,WORD PTR [bx+di]
    13e7:	15 f3 00             	adc    ax,0xf3
    13ea:	ff                   	(bad)
    13eb:	ff d5                	call   bp
    13ed:	31 19                	xor    WORD PTR [bx+di],bx
    13ef:	15 01 00             	adc    ax,0x1
    13f2:	00 00                	add    BYTE PTR [bx+si],al
    13f4:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    13f8:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
    13fc:	05 48 69             	add    ax,0x6948
    13ff:	6e                   	outs   dx,BYTE PTR ds:[si]
    1400:	74 73                	je     0x1475
    1402:	07                   	pop    es
    1403:	23 28                	and    bp,WORD PTR [bx+si]
    1405:	14 a6                	adc    al,0xa6
    1407:	00 ff                	add    bh,bh
    1409:	ff 70 63             	push   WORD PTR [bx+si+0x63]
    140c:	30 14                	xor    BYTE PTR [si],dl
    140e:	01 00                	add    WORD PTR [bx+si],ax
    1410:	00 00                	add    BYTE PTR [bx+si],al
    1412:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    1416:	00 00                	add    BYTE PTR [bx+si],al
    1418:	11 00                	adc    WORD PTR [bx+si],ax
    141a:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
    141d:	72 65                	jb     0x1484
    141f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1420:	74 43                	je     0x1465
    1422:	74 6c                	je     0x1490
    1424:	33 44 07             	xor    ax,WORD PTR [si+0x7]
    1427:	23 71 14             	and    si,WORD PTR [bx+di+0x14]
    142a:	49                   	dec    cx
    142b:	00 ff                	add    bh,bh
    142d:	ff a1 1e 9f          	jmp    WORD PTR [bx+di-0x60e2]
    1431:	14 01                	adc    al,0x1
    1433:	00 00                	add    BYTE PTR [bx+si],al
    1435:	00 00                	add    BYTE PTR [bx+si],al
    1437:	80 01 00             	add    BYTE PTR [bx+di],0x0
    143a:	00 00                	add    BYTE PTR [bx+si],al
    143c:	12 00                	adc    al,BYTE PTR [bx+si]
    143e:	0e                   	push   cs
    143f:	50                   	push   ax
    1440:	61                   	popa
    1441:	72 65                	jb     0x14a8
    1443:	6e                   	outs   dx,BYTE PTR ds:[si]
    1444:	74 53                	je     0x1499
    1446:	68 6f 77             	push   0x776f
    1449:	48                   	dec    ax
    144a:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
    144f:	ff                   	(bad)
    1450:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    1453:	ff                   	(bad)
    1454:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
    1457:	ff                   	(bad)
    1458:	ff 01                	inc    WORD PTR [bx+di]
    145a:	00 00                	add    BYTE PTR [bx+si],al
    145c:	00 00                	add    BYTE PTR [bx+si],al
    145e:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1461:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
    1465:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    1468:	70 75                	jo     0x14df
    146a:	70 4d                	jo     0x14b9
    146c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    146e:	75 07                	jne    0x1477
    1470:	23 97 14 06          	and    dx,WORD PTR [bx+0x614]
    1474:	01 ff                	add    di,di
    1476:	ff 06 01 ff          	inc    WORD PTR ds:0xff01
    147a:	ff 01                	inc    WORD PTR [bx+di]
    147c:	00 00                	add    BYTE PTR [bx+si],al
    147e:	00 00                	add    BYTE PTR [bx+si],al
    1480:	80 01 00             	add    BYTE PTR [bx+di],0x0
    1483:	00 00                	add    BYTE PTR [bx+si],al
    1485:	14 00                	adc    al,0x0
    1487:	0d 43 6f             	or     ax,0x6f43
    148a:	6e                   	outs   dx,BYTE PTR ds:[si]
    148b:	66 69 72 6d 44 65 6c 	imul   esi,DWORD PTR [bp+si+0x6d],0x656c6544
    1492:	65 
    1493:	74 65                	je     0x14fa
    1495:	07                   	pop    es
    1496:	23 d9                	and    bx,cx
    1498:	14 48                	adc    al,0x48
    149a:	00 ff                	add    bh,bh
    149c:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
    149f:	a3 14 23             	mov    ds:0x2314,ax
    14a2:	1e                   	push   ds
    14a3:	b8 14 00             	mov    ax,0x14
    14a6:	80 00 00             	add    BYTE PTR [bx+si],0x0
    14a9:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
    14ad:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
    14b0:	6f                   	outs   dx,WORD PTR ds:[si]
    14b1:	77 48                	ja     0x14fb
    14b3:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
    14b8:	bc 14 a6             	mov    sp,0xa614
    14bb:	63 c0                	arpl   ax,ax
    14bd:	14 60                	adc    al,0x60
    14bf:	64 e1 14             	fs loope 0x14d6
    14c2:	01 00                	add    WORD PTR [bx+si],ax
    14c4:	00 00                	add    BYTE PTR [bx+si],al
    14c6:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    14ca:	ff                   	(bad)
    14cb:	ff 16 00 08          	call   WORD PTR ds:0x800
    14cf:	54                   	push   sp
    14d0:	61                   	popa
    14d1:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
    14d4:	64 65 72 07          	fs gs jb 0x14df
    14d8:	23 f9                	and    di,cx
    14da:	14 a4                	adc    al,0xa4
    14dc:	00 ff                	add    bh,bh
    14de:	ff 88 64 01          	dec    WORD PTR [bx+si+0x164]
    14e2:	15 01 00             	adc    ax,0x1
    14e5:	00 00                	add    BYTE PTR [bx+si],al
    14e7:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    14eb:	00 00                	add    BYTE PTR [bx+si],al
    14ed:	17                   	pop    ss
    14ee:	00 07                	add    BYTE PTR [bx],al
    14f0:	54                   	push   sp
    14f1:	61                   	popa
    14f2:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    14f5:	6f                   	outs   dx,WORD PTR ds:[si]
    14f6:	70 07                	jo     0x14ff
    14f8:	23 3c                	and    di,WORD PTR [si]
    14fa:	16                   	push   ss
    14fb:	29 00                	sub    WORD PTR [bx+si],ax
    14fd:	ff                   	(bad)
    14fe:	ff 77 1c             	push   WORD PTR [bx+0x1c]
    1501:	5c                   	pop    sp
    1502:	15 01 00             	adc    ax,0x1
    1505:	00 00                	add    BYTE PTR [bx+si],al
    1507:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
    150b:	00 00                	add    BYTE PTR [bx+si],al
    150d:	18 00                	sbb    BYTE PTR [bx+si],al
    150f:	07                   	pop    es
    1510:	56                   	push   si
    1511:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
    1516:	65 d3 11             	rcl    WORD PTR gs:[bx+di],cl
    1519:	98                   	cbw
    151a:	16                   	push   ss
    151b:	fd                   	std
    151c:	00 ff                	add    bh,bh
    151e:	ff                   	(bad)
    151f:	fd                   	std
    1520:	00 ff                	add    bh,bh
    1522:	ff 01                	inc    WORD PTR [bx+di]
    1524:	00 00                	add    BYTE PTR [bx+si],al
    1526:	00 00                	add    BYTE PTR [bx+si],al
    1528:	80 00 00             	add    BYTE PTR [bx+si],0x0
    152b:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
    152f:	07                   	pop    es
    1530:	4f                   	dec    di
    1531:	6e                   	outs   dx,BYTE PTR ds:[si]
    1532:	43                   	inc    bx
    1533:	6c                   	ins    BYTE PTR es:[di],dx
    1534:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
    1539:	c4 15                	les    dx,DWORD PTR [di]
    153b:	82 00 ff             	add    BYTE PTR [bx+si],0xff
    153e:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
    1542:	ff 01                	inc    WORD PTR [bx+di]
    1544:	00 00                	add    BYTE PTR [bx+si],al
    1546:	00 00                	add    BYTE PTR [bx+si],al
    1548:	80 00 00             	add    BYTE PTR [bx+si],0x0
    154b:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
    154f:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1552:	44                   	inc    sp
    1553:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
    1556:	6c                   	ins    BYTE PTR es:[di],dx
    1557:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    155c:	7f 15                	jg     0x1573
    155e:	62 00                	bound  ax,DWORD PTR [bx+si]
    1560:	ff                   	(bad)
    1561:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    1564:	ff                   	(bad)
    1565:	ff 01                	inc    WORD PTR [bx+di]
    1567:	00 00                	add    BYTE PTR [bx+si],al
    1569:	00 00                	add    BYTE PTR [bx+si],al
    156b:	80 00 00             	add    BYTE PTR [bx+si],0x0
    156e:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
    1572:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1575:	44                   	inc    sp
    1576:	72 61                	jb     0x15d9
    1578:	67 44                	addr32 inc sp
    157a:	72 6f                	jb     0x15eb
    157c:	70 80                	jo     0x14fe
    157e:	02 a2 15 6a          	add    ah,BYTE PTR [bp+si+0x6a15]
    1582:	00 ff                	add    bh,bh
    1584:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    1587:	ff                   	(bad)
    1588:	ff 01                	inc    WORD PTR [bx+di]
    158a:	00 00                	add    BYTE PTR [bx+si],al
    158c:	00 00                	add    BYTE PTR [bx+si],al
    158e:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1591:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
    1595:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1598:	44                   	inc    sp
    1599:	72 61                	jb     0x15fc
    159b:	67 4f                	addr32 dec di
    159d:	76 65                	jbe    0x1604
    159f:	72 32                	jb     0x15d3
    15a1:	03 34                	add    si,WORD PTR [si]
    15a3:	16                   	push   ss
    15a4:	72 00                	jb     0x15a6
    15a6:	ff                   	(bad)
    15a7:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    15aa:	ff                   	(bad)
    15ab:	ff 01                	inc    WORD PTR [bx+di]
    15ad:	00 00                	add    BYTE PTR [bx+si],al
    15af:	00 00                	add    BYTE PTR [bx+si],al
    15b1:	80 00 00             	add    BYTE PTR [bx+si],0x0
    15b4:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    15b8:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    15bb:	45                   	inc    bp
    15bc:	6e                   	outs   dx,BYTE PTR ds:[si]
    15bd:	64 44                	fs inc sp
    15bf:	72 61                	jb     0x1622
    15c1:	67 71 00             	addr32 jno 0x15c4
    15c4:	e4 15                	in     al,0x15
    15c6:	c8 00 ff ff          	enter  0xff00,0xff
    15ca:	c8 00 ff ff          	enter  0xff00,0xff
    15ce:	01 00                	add    WORD PTR [bx+si],ax
    15d0:	00 00                	add    BYTE PTR [bx+si],al
    15d2:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    15d6:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
    15da:	07                   	pop    es
    15db:	4f                   	dec    di
    15dc:	6e                   	outs   dx,BYTE PTR ds:[si]
    15dd:	45                   	inc    bp
    15de:	6e                   	outs   dx,BYTE PTR ds:[si]
    15df:	74 65                	je     0x1646
    15e1:	72 71                	jb     0x1654
    15e3:	00 03                	add    BYTE PTR [bp+di],al
    15e5:	16                   	push   ss
    15e6:	d0 00                	rol    BYTE PTR [bx+si],1
    15e8:	ff                   	(bad)
    15e9:	ff d0                	call   ax
    15eb:	00 ff                	add    bh,bh
    15ed:	ff 01                	inc    WORD PTR [bx+di]
    15ef:	00 00                	add    BYTE PTR [bx+si],al
    15f1:	00 00                	add    BYTE PTR [bx+si],al
    15f3:	80 00 00             	add    BYTE PTR [bx+si],0x0
    15f6:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
    15fa:	06                   	push   es
    15fb:	4f                   	dec    di
    15fc:	6e                   	outs   dx,BYTE PTR ds:[si]
    15fd:	45                   	inc    bp
    15fe:	78 69                	js     0x1669
    1600:	74 71                	je     0x1673
    1602:	00 54 16             	add    BYTE PTR [si+0x16],dl
    1605:	e4 00                	in     al,0x0
    1607:	ff                   	(bad)
    1608:	ff e4                	jmp    sp
    160a:	00 ff                	add    bh,bh
    160c:	ff 01                	inc    WORD PTR [bx+di]
    160e:	00 00                	add    BYTE PTR [bx+si],al
    1610:	00 00                	add    BYTE PTR [bx+si],al
    1612:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1615:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
    1619:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
    161c:	52                   	push   dx
    161d:	65 73 69             	gs jae 0x1689
    1620:	7a 65                	jp     0x1687
    1622:	b3 16                	mov    bl,0x16
    1624:	00 00                	add    BYTE PTR [bx+si],al
    1626:	00 00                	add    BYTE PTR [bx+si],al
    1628:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    1629:	16                   	push   ss
    162a:	9a 16 a3 00 bb       	call   0xbb00:0xa316
    162f:	00 c5                	add    ch,al
    1631:	16                   	push   ss
    1632:	10 26 48 16          	adc    BYTE PTR ds:0x1648,ah
    1636:	9a 1f ed 16 cb       	call   0xcb16:0xed1f
    163b:	1f                   	pop    ds
    163c:	38 16 e4 3c          	cmp    BYTE PTR ds:0x3ce4,dl
    1640:	ad                   	lods   ax,WORD PTR ds:[si]
    1641:	16                   	push   ss
    1642:	cd 11                	int    0x11
    1644:	4c                   	dec    sp
    1645:	16                   	push   ss
    1646:	3a 27                	cmp    ah,BYTE PTR [bx]
    1648:	74 16                	je     0x1660
    164a:	fa                   	cli
    164b:	10 f5                	adc    ch,dh
    164d:	16                   	push   ss
    164e:	d6                   	(bad)
    164f:	14 58                	adc    al,0x58
    1651:	16                   	push   ss
    1652:	f4                   	hlt
    1653:	4f                   	dec    di
    1654:	64 16                	fs push ss
    1656:	32 16 5c 16          	xor    dl,BYTE PTR ds:0x165c
    165a:	98                   	cbw
    165b:	15 80 16             	adc    ax,0x1680
    165e:	51                   	push   cx
    165f:	1b 84 16 38          	sbb    ax,WORD PTR [si+0x3816]
    1663:	50                   	push   ax
    1664:	68 16 1a             	push   0x1a16
    1667:	50                   	push   ax
    1668:	6c                   	ins    BYTE PTR es:[di],dx
    1669:	16                   	push   ss
    166a:	21 50 44             	and    WORD PTR [bx+si+0x44],dx
    166d:	16                   	push   ss
    166e:	27                   	daa
    166f:	1f                   	pop    ds
    1670:	30 16 3f 19          	xor    BYTE PTR ds:0x193f,dl
    1674:	78 16                	js     0x168c
    1676:	78 18                	js     0x1690
    1678:	7c 16                	jl     0x1690
    167a:	02 21                	add    ah,BYTE PTR [bx+di]
    167c:	50                   	push   ax
    167d:	16                   	push   ss
    167e:	3a 1c                	cmp    bl,BYTE PTR [si]
    1680:	60                   	pusha
    1681:	16                   	push   ss
    1682:	15 25 88             	adc    ax,0x8825
    1685:	16                   	push   ss
    1686:	37                   	aaa
    1687:	22 8c 16 df          	and    cl,BYTE PTR [si-0x20ea]
    168b:	22 90 16 f8          	and    dl,BYTE PTR [bx+si-0x7ea]
    168f:	16                   	push   ss
    1690:	94                   	xchg   sp,ax
    1691:	16                   	push   ss
    1692:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    1693:	22 91 18 69          	and    dl,BYTE PTR [bx+di+0x6918]
    1697:	3e 40                	ds inc ax
    1699:	16                   	push   ss
    169a:	0a 54 4e             	or     dl,BYTE PTR [si+0x4e]
    169d:	61                   	popa
    169e:	76 42                	jbe    0x16e2
    16a0:	75 74                	jne    0x1716
    16a2:	74 6f                	je     0x1713
    16a4:	6e                   	outs   dx,BYTE PTR ds:[si]
    16a5:	02 00                	add    al,BYTE PTR [bx+si]
    16a7:	fa                   	cli
    16a8:	ff                   	(bad)
    16a9:	f8                   	clc
    16aa:	ff 1e 3d b1          	call   DWORD PTR ds:0xb13d
    16ae:	16                   	push   ss
    16af:	b6 3d                	mov    dh,0x3d
    16b1:	c1 16 07 0a 54       	rcl    WORD PTR ds:0xa07,0x54
    16b6:	4e                   	dec    si
    16b7:	61                   	popa
    16b8:	76 42                	jbe    0x16fc
    16ba:	75 74                	jne    0x1730
    16bc:	74 6f                	je     0x172d
    16be:	6e                   	outs   dx,BYTE PTR ds:[si]
    16bf:	42                   	inc    dx
    16c0:	16                   	push   ss
    16c1:	15 17 6a             	adc    ax,0x6a17
    16c4:	01 76 2f             	add    WORD PTR [bp+0x2f],si
    16c7:	1c 00                	sbb    al,0x0
    16c9:	07                   	pop    es
    16ca:	44                   	inc    sp
    16cb:	42                   	inc    dx
    16cc:	43                   	inc    bx
    16cd:	74 72                	je     0x1741
    16cf:	6c                   	ins    BYTE PTR es:[di],dx
    16d0:	73 00                	jae    0x16d2
    16d2:	00 30                	add    BYTE PTR [bx+si],dh
    16d4:	17                   	pop    ss
    16d5:	00 00                	add    BYTE PTR [bx+si],al
    16d7:	00 00                	add    BYTE PTR [bx+si],al
    16d9:	00 00                	add    BYTE PTR [bx+si],al
    16db:	23 17                	and    dx,WORD PTR [bx]
    16dd:	18 00                	sbb    BYTE PTR [bx+si],al
    16df:	1d 0d 44             	sbb    ax,0x440d
    16e2:	17                   	pop    ss
    16e3:	64 20 61 17          	and    BYTE PTR fs:[bx+di+0x17],ah
    16e7:	9a 1f e5 16 cb       	call   0xcb16:0xe51f
    16ec:	1f                   	pop    ds
    16ed:	e9 16 53             	jmp    0x6a06
    16f0:	3f                   	aas
    16f1:	40                   	inc    ax
    16f2:	17                   	pop    ss
    16f3:	cd 11                	int    0x11
    16f5:	f9                   	stc
    16f6:	16                   	push   ss
    16f7:	e4 11                	in     al,0x11
    16f9:	fd                   	std
    16fa:	16                   	push   ss
    16fb:	fa                   	cli
    16fc:	10 93 1c ba          	adc    BYTE PTR [bp+di-0x45e4],dl
    1700:	3f                   	aas
    1701:	f1                   	int1
    1702:	16                   	push   ss
    1703:	0c 7b                	or     al,0x7b
    1705:	0d 17 9b             	or     ax,0x9b17
    1708:	3f                   	aas
    1709:	01 17                	add    WORD PTR [bx],dx
    170b:	2a 7b 11             	sub    bh,BYTE PTR [bp+di+0x11]
    170e:	17                   	pop    ss
    170f:	44                   	inc    sp
    1710:	7b 19                	jnp    0x172b
    1712:	17                   	pop    ss
    1713:	7c 3f                	jl     0x1754
    1715:	09 17                	or     WORD PTR [bx],dx
    1717:	4b                   	dec    bx
    1718:	7b 1d                	jnp    0x1737
    171a:	17                   	pop    ss
    171b:	5e                   	pop    si
    171c:	7b 21                	jnp    0x173f
    171e:	17                   	pop    ss
    171f:	65 7b e1             	gs jnp 0x1703
    1722:	16                   	push   ss
    1723:	0c 54                	or     al,0x54
    1725:	4e                   	dec    si
    1726:	61                   	popa
    1727:	76 44                	jbe    0x176d
    1729:	61                   	popa
    172a:	74 61                	je     0x178d
    172c:	4c                   	dec    sp
    172d:	69 6e 6b 07 0c       	imul   bp,WORD PTR [bp+0x6b],0xc07
    1732:	54                   	push   sp
    1733:	4e                   	dec    si
    1734:	61                   	popa
    1735:	76 44                	jbe    0x177b
    1737:	61                   	popa
    1738:	74 61                	je     0x179b
    173a:	4c                   	dec    sp
    173b:	69 6e 6b f3 16       	imul   bp,WORD PTR [bp+0x6b],0x16f3
    1740:	bb 17 57             	mov    bx,0x5717
    1743:	0d 99 1a             	or     ax,0x1a99
    1746:	00 00                	add    BYTE PTR [bx+si],al
    1748:	07                   	pop    es
    1749:	44                   	inc    sp
    174a:	42                   	inc    dx
    174b:	43                   	inc    bx
    174c:	74 72                	je     0x17c0
    174e:	6c                   	ins    BYTE PTR es:[di],dx
    174f:	73 00                	jae    0x1751
    1751:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1754:	e5 80                	in     ax,0x80
    1756:	7e 0a                	jle    0x1762
    1758:	00 74 08             	add    BYTE PTR [si+0x8],dh
    175b:	83 ec 08             	sub    sp,0x8
    175e:	9a e2 1f 43 18       	call   0x1843:0x1fe2
    1763:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1766:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1769:	31 c0                	xor    ax,ax
    176b:	50                   	push   ax
    176c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    176f:	06                   	push   es
    1770:	57                   	push   di
    1771:	9a 5a 11 6b 18       	call   0x186b:0x115a
    1776:	6a 01                	push   0x1
    1778:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    177b:	06                   	push   es
    177c:	57                   	push   di
    177d:	9a 79 49 ab 19       	call   0x19ab:0x4979
    1782:	b0 01                	mov    al,0x1
    1784:	50                   	push   ax
    1785:	b8 1c 15             	mov    ax,0x151c
    1788:	ba 90 17             	mov    dx,0x1790
    178b:	52                   	push   dx
    178c:	50                   	push   ax
    178d:	9a b4 7f 03 19       	call   0x1903:0x7fb4
    1792:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1795:	26 89 85 fd 00       	mov    WORD PTR es:[di+0xfd],ax
    179a:	26 89 95 ff 00       	mov    WORD PTR es:[di+0xff],dx
    179f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    17a2:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    17a5:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    17aa:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    17ae:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    17b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17b5:	06                   	push   es
    17b6:	57                   	push   di
    17b7:	b8 3d 1b             	mov    ax,0x1b3d
    17ba:	ba db 17             	mov    dx,0x17db
    17bd:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    17c2:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    17c6:	26 89 55 24          	mov    WORD PTR es:[di+0x24],dx
    17ca:	26 8f 45 26          	pop    WORD PTR es:[di+0x26]
    17ce:	26 8f 45 28          	pop    WORD PTR es:[di+0x28]
    17d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17d5:	06                   	push   es
    17d6:	57                   	push   di
    17d7:	b8 b4 1c             	mov    ax,0x1cb4
    17da:	ba fb 17             	mov    dx,0x17fb
    17dd:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    17e2:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    17e6:	26 89 55 2c          	mov    WORD PTR es:[di+0x2c],dx
    17ea:	26 8f 45 2e          	pop    WORD PTR es:[di+0x2e]
    17ee:	26 8f 45 30          	pop    WORD PTR es:[di+0x30]
    17f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17f5:	06                   	push   es
    17f6:	57                   	push   di
    17f7:	b8 d8 1c             	mov    ax,0x1cd8
    17fa:	ba 1a 18             	mov    dx,0x181a
    17fd:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1802:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    1806:	26 89 55 34          	mov    WORD PTR es:[di+0x34],dx
    180a:	26 8f 45 36          	pop    WORD PTR es:[di+0x36]
    180e:	26 8f 45 38          	pop    WORD PTR es:[di+0x38]
    1812:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1815:	06                   	push   es
    1816:	57                   	push   di
    1817:	9a 7f 20 ad 18       	call   0x18ad:0x207f
    181c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1820:	74 07                	je     0x1829
    1822:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1826:	83 c4 06             	add    sp,0x6
    1829:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    182c:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    182f:	c9                   	leave
    1830:	ca 0a 00             	retf   0xa
    1833:	55                   	push   bp
    1834:	89 e5                	mov    bp,sp
    1836:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1839:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    183e:	06                   	push   es
    183f:	57                   	push   di
    1840:	9a 7f 1f 5e 18       	call   0x185e:0x1f7f
    1845:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1848:	31 c0                	xor    ax,ax
    184a:	26 89 85 fd 00       	mov    WORD PTR es:[di+0xfd],ax
    184f:	26 89 85 ff 00       	mov    WORD PTR es:[di+0xff],ax
    1854:	26 c4 bd 01 01       	les    di,DWORD PTR es:[di+0x101]
    1859:	06                   	push   es
    185a:	57                   	push   di
    185b:	9a 7f 1f 76 18       	call   0x1876:0x1f7f
    1860:	31 c0                	xor    ax,ax
    1862:	50                   	push   ax
    1863:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1866:	06                   	push   es
    1867:	57                   	push   di
    1868:	9a c8 11 df 18       	call   0x18df:0x11c8
    186d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1871:	74 05                	je     0x1878
    1873:	9a 0f 20 c3 1a       	call   0x1ac3:0x200f
    1878:	c9                   	leave
    1879:	ca 06 00             	retf   0x6
    187c:	55                   	push   bp
    187d:	89 e5                	mov    bp,sp
    187f:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1882:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1885:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1888:	50                   	push   ax
    1889:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    188c:	06                   	push   es
    188d:	57                   	push   di
    188e:	9a 32 16 23 1e       	call   0x1e23:0x1632
    1893:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    1897:	75 2e                	jne    0x18c7
    1899:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    189c:	26 8b 85 fd 00       	mov    ax,WORD PTR es:[di+0xfd]
    18a1:	26 0b 85 ff 00       	or     ax,WORD PTR es:[di+0xff]
    18a6:	74 1f                	je     0x18c7
    18a8:	06                   	push   es
    18a9:	57                   	push   di
    18aa:	9a 5f 1a c5 18       	call   0x18c5:0x1a5f
    18af:	3b 56 0e             	cmp    dx,WORD PTR [bp+0xe]
    18b2:	75 13                	jne    0x18c7
    18b4:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    18b7:	75 0e                	jne    0x18c7
    18b9:	6a 00                	push   0x0
    18bb:	6a 00                	push   0x0
    18bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18c0:	06                   	push   es
    18c1:	57                   	push   di
    18c2:	9a 83 1a 66 1d       	call   0x1d66:0x1a83
    18c7:	c9                   	leave
    18c8:	ca 0a 00             	retf   0xa
    18cb:	55                   	push   bp
    18cc:	89 e5                	mov    bp,sp
    18ce:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    18d1:	06                   	push   es
    18d2:	57                   	push   di
    18d3:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    18d6:	50                   	push   ax
    18d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18da:	06                   	push   es
    18db:	57                   	push   di
    18dc:	9a 0b 12 19 19       	call   0x1919:0x120b
    18e1:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    18e4:	26 83 3d 2e          	cmp    WORD PTR es:[di],0x2e
    18e8:	74 0c                	je     0x18f6
    18ea:	26 83 3d 2d          	cmp    WORD PTR es:[di],0x2d
    18ee:	75 15                	jne    0x1905
    18f0:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    18f4:	74 0f                	je     0x1905
    18f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18f9:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    18fe:	06                   	push   es
    18ff:	57                   	push   di
    1900:	9a 4f 81 8c 19       	call   0x198c:0x814f
    1905:	c9                   	leave
    1906:	ca 0a 00             	retf   0xa
    1909:	55                   	push   bp
    190a:	89 e5                	mov    bp,sp
    190c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    190f:	06                   	push   es
    1910:	57                   	push   di
    1911:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1914:	06                   	push   es
    1915:	57                   	push   di
    1916:	9a 87 13 1a 1a       	call   0x1a1a:0x1387
    191b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    191e:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1921:	3c 20                	cmp    al,0x20
    1923:	72 40                	jb     0x1965
    1925:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1928:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    192d:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    1931:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    1935:	74 2e                	je     0x1965
    1937:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    193a:	26 8a 05             	mov    al,BYTE PTR es:[di]
    193d:	50                   	push   ax
    193e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1941:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1946:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    194a:	06                   	push   es
    194b:	57                   	push   di
    194c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    194f:	26 ff 5d 70          	call   DWORD PTR es:[di+0x70]
    1953:	08 c0                	or     al,al
    1955:	75 0e                	jne    0x1965
    1957:	6a 00                	push   0x0
    1959:	9a d1 2b 00 00       	call   0x0:0x2bd1
    195e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1961:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1965:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1968:	26 8a 05             	mov    al,BYTE PTR es:[di]
    196b:	3c 08                	cmp    al,0x8
    196d:	74 10                	je     0x197f
    196f:	3c 16                	cmp    al,0x16
    1971:	74 0c                	je     0x197f
    1973:	3c 18                	cmp    al,0x18
    1975:	74 08                	je     0x197f
    1977:	3c 20                	cmp    al,0x20
    1979:	72 15                	jb     0x1990
    197b:	3c ff                	cmp    al,0xff
    197d:	77 11                	ja     0x1990
    197f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1982:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1987:	06                   	push   es
    1988:	57                   	push   di
    1989:	9a 4f 81 a1 19       	call   0x19a1:0x814f
    198e:	eb 24                	jmp    0x19b4
    1990:	3c 1b                	cmp    al,0x1b
    1992:	75 20                	jne    0x19b4
    1994:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1997:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    199c:	06                   	push   es
    199d:	57                   	push   di
    199e:	9a c2 81 c9 19       	call   0x19c9:0x81c2
    19a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a6:	06                   	push   es
    19a7:	57                   	push   di
    19a8:	9a 3f 4a ef 19       	call   0x19ef:0x4a3f
    19ad:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19b0:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    19b4:	c9                   	leave
    19b5:	ca 08 00             	retf   0x8
    19b8:	c8 02 00 00          	enter  0x2,0x0
    19bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19bf:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    19c4:	06                   	push   es
    19c5:	57                   	push   di
    19c6:	9a 4f 81 e5 19       	call   0x19e5:0x814f
    19cb:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    19ce:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    19d1:	c9                   	leave
    19d2:	ca 04 00             	retf   0x4
    19d5:	55                   	push   bp
    19d6:	89 e5                	mov    bp,sp
    19d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19db:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    19e0:	06                   	push   es
    19e1:	57                   	push   di
    19e2:	9a c2 81 39 1a       	call   0x1a39:0x81c2
    19e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19ea:	06                   	push   es
    19eb:	57                   	push   di
    19ec:	9a 3f 4a 59 1a       	call   0x1a59:0x4a3f
    19f1:	c9                   	leave
    19f2:	ca 04 00             	retf   0x4
    19f5:	55                   	push   bp
    19f6:	89 e5                	mov    bp,sp
    19f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19fb:	26 8a 85 06 01       	mov    al,BYTE PTR es:[di+0x106]
    1a00:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1a03:	74 36                	je     0x1a3b
    1a05:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1a08:	26 88 85 06 01       	mov    BYTE PTR es:[di+0x106],al
    1a0d:	26 80 bd 05 01 00    	cmp    BYTE PTR es:[di+0x105],0x0
    1a13:	74 17                	je     0x1a2c
    1a15:	06                   	push   es
    1a16:	57                   	push   di
    1a17:	9a 1c 18 7a 1b       	call   0x1b7a:0x181c
    1a1c:	08 c0                	or     al,al
    1a1e:	75 0c                	jne    0x1a2c
    1a20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a23:	06                   	push   es
    1a24:	57                   	push   di
    1a25:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a28:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1a2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a2f:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1a34:	06                   	push   es
    1a35:	57                   	push   di
    1a36:	9a c2 81 4f 1a       	call   0x1a4f:0x81c2
    1a3b:	c9                   	leave
    1a3c:	ca 06 00             	retf   0x6
    1a3f:	55                   	push   bp
    1a40:	89 e5                	mov    bp,sp
    1a42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a45:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1a4a:	06                   	push   es
    1a4b:	57                   	push   di
    1a4c:	9a b3 81 b6 1a       	call   0x1ab6:0x81b3
    1a51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a54:	06                   	push   es
    1a55:	57                   	push   di
    1a56:	9a b6 4c d2 1c       	call   0x1cd2:0x4cb6
    1a5b:	c9                   	leave
    1a5c:	ca 04 00             	retf   0x4
    1a5f:	c8 04 00 00          	enter  0x4,0x0
    1a63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a66:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1a6b:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1a6f:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    1a73:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1a76:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1a79:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1a7c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1a7f:	c9                   	leave
    1a80:	ca 04 00             	retf   0x4
    1a83:	55                   	push   bp
    1a84:	89 e5                	mov    bp,sp
    1a86:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a89:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1a8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a8f:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1a94:	06                   	push   es
    1a95:	57                   	push   di
    1a96:	9a 31 77 12 1b       	call   0x1b12:0x7731
    1a9b:	c9                   	leave
    1a9c:	ca 08 00             	retf   0x8
    1a9f:	c8 00 01 00          	enter  0x100,0x0
    1aa3:	8d be 00 ff          	lea    di,[bp-0x100]
    1aa7:	16                   	push   ss
    1aa8:	57                   	push   di
    1aa9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aac:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1ab1:	06                   	push   es
    1ab2:	57                   	push   di
    1ab3:	9a 63 80 de 1a       	call   0x1ade:0x8063
    1ab8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1abb:	06                   	push   es
    1abc:	57                   	push   di
    1abd:	68 ff 00             	push   0xff
    1ac0:	9a e7 17 c8 1d       	call   0x1dc8:0x17e7
    1ac5:	c9                   	leave
    1ac6:	ca 04 00             	retf   0x4
    1ac9:	55                   	push   bp
    1aca:	89 e5                	mov    bp,sp
    1acc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1acf:	06                   	push   es
    1ad0:	57                   	push   di
    1ad1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ad4:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1ad9:	06                   	push   es
    1ada:	57                   	push   di
    1adb:	9a 80 80 07 1c       	call   0x1c07:0x8080
    1ae0:	c9                   	leave
    1ae1:	ca 08 00             	retf   0x8
    1ae4:	c8 02 00 00          	enter  0x2,0x0
    1ae8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aeb:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1af0:	26 8a 45 10          	mov    al,BYTE PTR es:[di+0x10]
    1af4:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1af7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1afa:	c9                   	leave
    1afb:	ca 04 00             	retf   0x4
    1afe:	55                   	push   bp
    1aff:	89 e5                	mov    bp,sp
    1b01:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1b04:	50                   	push   ax
    1b05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b08:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1b0d:	06                   	push   es
    1b0e:	57                   	push   di
    1b0f:	9a 6e 77 ab 1b       	call   0x1bab:0x776e
    1b14:	c9                   	leave
    1b15:	ca 06 00             	retf   0x6
    1b18:	c8 04 00 00          	enter  0x4,0x0
    1b1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b1f:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1b24:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    1b28:	26 8b 55 16          	mov    dx,WORD PTR es:[di+0x16]
    1b2c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b2f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1b32:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b35:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1b38:	c9                   	leave
    1b39:	ca 04 00             	retf   0x4
    1b3c:	00 c8                	add    al,cl
    1b3e:	00 01                	add    BYTE PTR [bx+di],al
    1b40:	00 c4                	add    ah,al
    1b42:	7e 06                	jle    0x1b4a
    1b44:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1b49:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    1b4d:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    1b51:	75 03                	jne    0x1b56
    1b53:	e9 01 01             	jmp    0x1c57
    1b56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b59:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    1b5e:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1b63:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1b67:	26 3a 45 25          	cmp    al,BYTE PTR es:[di+0x25]
    1b6b:	74 27                	je     0x1b94
    1b6d:	bf 3c 1b             	mov    di,0x1b3c
    1b70:	0e                   	push   cs
    1b71:	57                   	push   di
    1b72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b75:	06                   	push   es
    1b76:	57                   	push   di
    1b77:	9a 8e 14 b5 1b       	call   0x1bb5:0x148e
    1b7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b7f:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1b84:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1b88:	26 8a 45 25          	mov    al,BYTE PTR es:[di+0x25]
    1b8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b8f:	26 88 85 05 01       	mov    BYTE PTR es:[di+0x105],al
    1b94:	8d be 00 ff          	lea    di,[bp-0x100]
    1b98:	16                   	push   ss
    1b99:	57                   	push   di
    1b9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b9d:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1ba2:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1ba6:	06                   	push   es
    1ba7:	57                   	push   di
    1ba8:	9a b2 68 24 1c       	call   0x1c24:0x68b2
    1bad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bb0:	06                   	push   es
    1bb1:	57                   	push   di
    1bb2:	9a 2a 19 e2 1b       	call   0x1be2:0x192a
    1bb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bba:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1bbf:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1bc3:	26 80 7d 22 01       	cmp    BYTE PTR es:[di+0x22],0x1
    1bc8:	75 1c                	jne    0x1be6
    1bca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bcd:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1bd2:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1bd6:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    1bda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bdd:	06                   	push   es
    1bde:	57                   	push   di
    1bdf:	9a 6b 1a f0 1b       	call   0x1bf0:0x1a6b
    1be4:	eb 0c                	jmp    0x1bf2
    1be6:	6a 00                	push   0x0
    1be8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1beb:	06                   	push   es
    1bec:	57                   	push   di
    1bed:	9a 6b 1a 2e 1c       	call   0x1c2e:0x1a6b
    1bf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf5:	26 80 bd 06 01 00    	cmp    BYTE PTR es:[di+0x106],0x0
    1bfb:	74 35                	je     0x1c32
    1bfd:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1c02:	06                   	push   es
    1c03:	57                   	push   di
    1c04:	9a 7c 81 1d 1d       	call   0x1d1d:0x817c
    1c09:	08 c0                	or     al,al
    1c0b:	74 25                	je     0x1c32
    1c0d:	8d be 00 ff          	lea    di,[bp-0x100]
    1c11:	16                   	push   ss
    1c12:	57                   	push   di
    1c13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c16:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1c1b:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1c1f:	06                   	push   es
    1c20:	57                   	push   di
    1c21:	9a cf 68 49 1c       	call   0x1c49:0x68cf
    1c26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c29:	06                   	push   es
    1c2a:	57                   	push   di
    1c2b:	9a b5 15 53 1c       	call   0x1c53:0x15b5
    1c30:	eb 23                	jmp    0x1c55
    1c32:	8d be 00 ff          	lea    di,[bp-0x100]
    1c36:	16                   	push   ss
    1c37:	57                   	push   di
    1c38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c3b:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1c40:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1c44:	06                   	push   es
    1c45:	57                   	push   di
    1c46:	9a 35 68 07 1d       	call   0x1d07:0x6835
    1c4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c4e:	06                   	push   es
    1c4f:	57                   	push   di
    1c50:	9a 8e 14 6d 1c       	call   0x1c6d:0x148e
    1c55:	eb 59                	jmp    0x1cb0
    1c57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c5a:	26 c6 85 05 01 00    	mov    BYTE PTR es:[di+0x105],0x0
    1c60:	bf 3c 1b             	mov    di,0x1b3c
    1c63:	0e                   	push   cs
    1c64:	57                   	push   di
    1c65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c68:	06                   	push   es
    1c69:	57                   	push   di
    1c6a:	9a 2a 19 79 1c       	call   0x1c79:0x192a
    1c6f:	6a 00                	push   0x0
    1c71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c74:	06                   	push   es
    1c75:	57                   	push   di
    1c76:	9a 6b 1a 9d 1c       	call   0x1c9d:0x1a6b
    1c7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c7e:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    1c83:	74 1c                	je     0x1ca1
    1c85:	8d be 00 ff          	lea    di,[bp-0x100]
    1c89:	16                   	push   ss
    1c8a:	57                   	push   di
    1c8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c8e:	06                   	push   es
    1c8f:	57                   	push   di
    1c90:	9a 2a 51 82 28       	call   0x2882:0x512a
    1c95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c98:	06                   	push   es
    1c99:	57                   	push   di
    1c9a:	9a 8e 14 ae 1c       	call   0x1cae:0x148e
    1c9f:	eb 0f                	jmp    0x1cb0
    1ca1:	bf 3c 1b             	mov    di,0x1b3c
    1ca4:	0e                   	push   cs
    1ca5:	57                   	push   di
    1ca6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca9:	06                   	push   es
    1caa:	57                   	push   di
    1cab:	9a 8e 14 e4 1c       	call   0x1ce4:0x148e
    1cb0:	c9                   	leave
    1cb1:	ca 08 00             	retf   0x8
    1cb4:	55                   	push   bp
    1cb5:	89 e5                	mov    bp,sp
    1cb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cba:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1cbf:	26 80 7d 20 00       	cmp    BYTE PTR es:[di+0x20],0x0
    1cc4:	b0 00                	mov    al,0x0
    1cc6:	75 01                	jne    0x1cc9
    1cc8:	40                   	inc    ax
    1cc9:	50                   	push   ax
    1cca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ccd:	06                   	push   es
    1cce:	57                   	push   di
    1ccf:	9a 79 49 b7 1d       	call   0x1db7:0x4979
    1cd4:	c9                   	leave
    1cd5:	ca 08 00             	retf   0x8
    1cd8:	c8 00 01 00          	enter  0x100,0x0
    1cdc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cdf:	06                   	push   es
    1ce0:	57                   	push   di
    1ce1:	9a ff 23 f4 1c       	call   0x1cf4:0x23ff
    1ce6:	8d be 00 ff          	lea    di,[bp-0x100]
    1cea:	16                   	push   ss
    1ceb:	57                   	push   di
    1cec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cef:	06                   	push   es
    1cf0:	57                   	push   di
    1cf1:	9a 24 15 2d 1d       	call   0x1d2d:0x1524
    1cf6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf9:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1cfe:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1d02:	06                   	push   es
    1d03:	57                   	push   di
    1d04:	9a 56 6f a4 1d       	call   0x1da4:0x6f56
    1d09:	c9                   	leave
    1d0a:	ca 08 00             	retf   0x8
    1d0d:	55                   	push   bp
    1d0e:	89 e5                	mov    bp,sp
    1d10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d13:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1d18:	06                   	push   es
    1d19:	57                   	push   di
    1d1a:	9a 4f 81 43 1d       	call   0x1d43:0x814f
    1d1f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d22:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d28:	06                   	push   es
    1d29:	57                   	push   di
    1d2a:	9a 00 17 53 1d       	call   0x1d53:0x1700
    1d2f:	c9                   	leave
    1d30:	ca 08 00             	retf   0x8
    1d33:	55                   	push   bp
    1d34:	89 e5                	mov    bp,sp
    1d36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d39:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1d3e:	06                   	push   es
    1d3f:	57                   	push   di
    1d40:	9a 4f 81 77 21       	call   0x2177:0x814f
    1d45:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d48:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d4e:	06                   	push   es
    1d4f:	57                   	push   di
    1d50:	9a c1 16 76 1d       	call   0x1d76:0x16c1
    1d55:	c9                   	leave
    1d56:	ca 08 00             	retf   0x8
    1d59:	55                   	push   bp
    1d5a:	89 e5                	mov    bp,sp
    1d5c:	6a 01                	push   0x1
    1d5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d61:	06                   	push   es
    1d62:	57                   	push   di
    1d63:	9a f5 19 84 1d       	call   0x1d84:0x19f5
    1d68:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d6b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d71:	06                   	push   es
    1d72:	57                   	push   di
    1d73:	9a 7d 22 e5 1d       	call   0x1de5:0x227d
    1d78:	c9                   	leave
    1d79:	ca 08 00             	retf   0x8
    1d7c:	01 00                	add    WORD PTR [bx+si],ax
    1d7e:	00 00                	add    BYTE PTR [bx+si],al
    1d80:	00 00                	add    BYTE PTR [bx+si],al
    1d82:	af                   	scas   ax,WORD PTR es:[di]
    1d83:	1d d9 1d             	sbb    ax,0x1dd9
    1d86:	55                   	push   bp
    1d87:	89 e5                	mov    bp,sp
    1d89:	b8 7c 1d             	mov    ax,0x1d7c
    1d8c:	0e                   	push   cs
    1d8d:	50                   	push   ax
    1d8e:	55                   	push   bp
    1d8f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1d93:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1d97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d9a:	26 c4 bd fd 00       	les    di,DWORD PTR es:[di+0xfd]
    1d9f:	06                   	push   es
    1da0:	57                   	push   di
    1da1:	9a 5e 78 d2 22       	call   0x22d2:0x785e
    1da6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1daa:	83 c4 06             	add    sp,0x6
    1dad:	eb 20                	jmp    0x1dcf
    1daf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1db2:	06                   	push   es
    1db3:	57                   	push   di
    1db4:	9a 3f 4a 6f 20       	call   0x206f:0x4a3f
    1db9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dbc:	06                   	push   es
    1dbd:	57                   	push   di
    1dbe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1dc1:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    1dc5:	ea 85 13 cd 1d       	jmp    0x1dcd:0x1385
    1dca:	9a 34 14 f2 1d       	call   0x1df2:0x1434
    1dcf:	6a 00                	push   0x0
    1dd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dd4:	06                   	push   es
    1dd5:	57                   	push   di
    1dd6:	9a f5 19 fc 1d       	call   0x1dfc:0x19f5
    1ddb:	6a 00                	push   0x0
    1ddd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1de0:	06                   	push   es
    1de1:	57                   	push   di
    1de2:	9a 12 1b 57 1f       	call   0x1f57:0x1b12
    1de7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dea:	06                   	push   es
    1deb:	57                   	push   di
    1dec:	b8 f2 ff             	mov    ax,0xfff2
    1def:	9a 6a 20 f1 1e       	call   0x1ef1:0x206a
    1df4:	c9                   	leave
    1df5:	ca 08 00             	retf   0x8
    1df8:	00 00                	add    BYTE PTR [bx+si],al
    1dfa:	29 20                	sub    WORD PTR [bx+si],sp
    1dfc:	79 20                	jns    0x1e1e
    1dfe:	c8 36 02 00          	enter  0x236,0x0
    1e02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e05:	26 80 bd 05 01 00    	cmp    BYTE PTR es:[di+0x105],0x0
    1e0b:	74 08                	je     0x1e15
    1e0d:	26 80 bd 06 01 00    	cmp    BYTE PTR es:[di+0x106],0x0
    1e13:	74 13                	je     0x1e28
    1e15:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e18:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e1e:	06                   	push   es
    1e1f:	57                   	push   di
    1e20:	9a 8c 4a 3e 1e       	call   0x1e3e:0x4a8c
    1e25:	e9 32 02             	jmp    0x205a
    1e28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e2b:	26 8b 85 01 01       	mov    ax,WORD PTR es:[di+0x101]
    1e30:	26 0b 85 03 01       	or     ax,WORD PTR es:[di+0x103]
    1e35:	75 2f                	jne    0x1e66
    1e37:	b0 01                	mov    al,0x1
    1e39:	50                   	push   ax
    1e3a:	b8 96 00             	mov    ax,0x96
    1e3d:	ba 64 1e             	mov    dx,0x1e64
    1e40:	52                   	push   dx
    1e41:	50                   	push   ax
    1e42:	9a b8 17 9e 1e       	call   0x1e9e:0x17b8
    1e47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e4a:	26 89 85 01 01       	mov    WORD PTR es:[di+0x101],ax
    1e4f:	26 89 95 03 01       	mov    WORD PTR es:[di+0x103],dx
    1e54:	ff 76 08             	push   WORD PTR [bp+0x8]
    1e57:	ff 76 06             	push   WORD PTR [bp+0x6]
    1e5a:	26 c4 bd 01 01       	les    di,DWORD PTR es:[di+0x101]
    1e5f:	06                   	push   es
    1e60:	57                   	push   di
    1e61:	9a 64 13 7e 1e       	call   0x1e7e:0x1364
    1e66:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e69:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    1e6d:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    1e70:	83 7e ee 00          	cmp    WORD PTR [bp-0x12],0x0
    1e74:	75 18                	jne    0x1e8e
    1e76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e79:	06                   	push   es
    1e7a:	57                   	push   di
    1e7b:	9a b9 62 4c 20       	call   0x204c:0x62b9
    1e80:	50                   	push   ax
    1e81:	8d 7e ce             	lea    di,[bp-0x32]
    1e84:	16                   	push   ss
    1e85:	57                   	push   di
    1e86:	9a ff ff 00 00       	call   0x0:0xffff
    1e8b:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    1e8e:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1e91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e94:	26 c4 bd 01 01       	les    di,DWORD PTR es:[di+0x101]
    1e99:	06                   	push   es
    1e9a:	57                   	push   di
    1e9b:	9a 5d 22 c3 1e       	call   0x1ec3:0x225d
    1ea0:	b8 f8 1d             	mov    ax,0x1df8
    1ea3:	0e                   	push   cs
    1ea4:	50                   	push   ax
    1ea5:	55                   	push   bp
    1ea6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1eaa:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1eae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb1:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1eb5:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1eb9:	26 c4 bd 01 01       	les    di,DWORD PTR es:[di+0x101]
    1ebe:	06                   	push   es
    1ebf:	57                   	push   di
    1ec0:	9a 99 20 0f 1f       	call   0x1f0f:0x2099
    1ec5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ec8:	26 c4 bd 01 01       	les    di,DWORD PTR es:[di+0x101]
    1ecd:	89 be ca fe          	mov    WORD PTR [bp-0x136],di
    1ed1:	8c 86 cc fe          	mov    WORD PTR [bp-0x134],es
    1ed5:	8d be c2 fe          	lea    di,[bp-0x13e]
    1ed9:	16                   	push   ss
    1eda:	57                   	push   di
    1edb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ede:	06                   	push   es
    1edf:	57                   	push   di
    1ee0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ee3:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1ee7:	8d 7e f0             	lea    di,[bp-0x10]
    1eea:	16                   	push   ss
    1eeb:	57                   	push   di
    1eec:	6a 08                	push   0x8
    1eee:	9a 1b 16 65 1f       	call   0x1f65:0x161b
    1ef3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ef6:	26 80 bd da 00 01    	cmp    BYTE PTR es:[di+0xda],0x1
    1efc:	75 31                	jne    0x1f2f
    1efe:	6a ff                	push   0xffff
    1f00:	6a f9                	push   0xfff9
    1f02:	c4 be ca fe          	les    di,DWORD PTR [bp-0x136]
    1f06:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1f0a:	06                   	push   es
    1f0b:	57                   	push   di
    1f0c:	9a 84 16 1f 1f       	call   0x1f1f:0x1684
    1f11:	8d 7e f0             	lea    di,[bp-0x10]
    1f14:	16                   	push   ss
    1f15:	57                   	push   di
    1f16:	c4 be ca fe          	les    di,DWORD PTR [bp-0x136]
    1f1a:	06                   	push   es
    1f1b:	57                   	push   di
    1f1c:	9a 30 1d 47 1f       	call   0x1f47:0x1d30
    1f21:	8d 7e f0             	lea    di,[bp-0x10]
    1f24:	16                   	push   ss
    1f25:	57                   	push   di
    1f26:	6a ff                	push   0xffff
    1f28:	6a ff                	push   0xffff
    1f2a:	9a d2 3e 00 00       	call   0x0:0x3ed2
    1f2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f32:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    1f36:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    1f3a:	c4 be ca fe          	les    di,DWORD PTR [bp-0x136]
    1f3e:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1f42:	06                   	push   es
    1f43:	57                   	push   di
    1f44:	9a 84 16 b4 1f       	call   0x1fb4:0x1684
    1f49:	8d be ca fd          	lea    di,[bp-0x236]
    1f4d:	16                   	push   ss
    1f4e:	57                   	push   di
    1f4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f52:	06                   	push   es
    1f53:	57                   	push   di
    1f54:	9a d8 14 ff ff       	call   0xffff:0x14d8
    1f59:	8d be ce fe          	lea    di,[bp-0x132]
    1f5d:	16                   	push   ss
    1f5e:	57                   	push   di
    1f5f:	68 ff 00             	push   0xff
    1f62:	9a e7 17 0f 21       	call   0x210f:0x17e7
    1f67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f6a:	26 80 bd db 00 00    	cmp    BYTE PTR es:[di+0xdb],0x0
    1f70:	74 33                	je     0x1fa5
    1f72:	8a 86 ce fe          	mov    al,BYTE PTR [bp-0x132]
    1f76:	30 e4                	xor    ah,ah
    1f78:	89 86 c8 fe          	mov    WORD PTR [bp-0x138],ax
    1f7c:	b8 01 00             	mov    ax,0x1
    1f7f:	3b 86 c8 fe          	cmp    ax,WORD PTR [bp-0x138]
    1f83:	7f 20                	jg     0x1fa5
    1f85:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1f88:	eb 03                	jmp    0x1f8d
    1f8a:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    1f8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f90:	26 8a 85 db 00       	mov    al,BYTE PTR es:[di+0xdb]
    1f95:	8b 7e f8             	mov    di,WORD PTR [bp-0x8]
    1f98:	88 83 ce fe          	mov    BYTE PTR [bp+di-0x132],al
    1f9c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1f9f:	3b 86 c8 fe          	cmp    ax,WORD PTR [bp-0x138]
    1fa3:	75 e5                	jne    0x1f8a
    1fa5:	8d be ce fe          	lea    di,[bp-0x132]
    1fa9:	16                   	push   ss
    1faa:	57                   	push   di
    1fab:	c4 be ca fe          	les    di,DWORD PTR [bp-0x136]
    1faf:	06                   	push   es
    1fb0:	57                   	push   di
    1fb1:	9a 03 20 1b 20       	call   0x201b:0x2003
    1fb6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1fb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fbc:	26 80 bd da 00 00    	cmp    BYTE PTR es:[di+0xda],0x0
    1fc2:	75 07                	jne    0x1fcb
    1fc4:	31 c0                	xor    ax,ax
    1fc6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1fc9:	eb 0b                	jmp    0x1fd6
    1fcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fce:	26 8b 85 07 01       	mov    ax,WORD PTR es:[di+0x107]
    1fd3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1fd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fd9:	26 80 bd 05 01 01    	cmp    BYTE PTR es:[di+0x105],0x1
    1fdf:	75 0e                	jne    0x1fef
    1fe1:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1fe4:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    1fe7:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    1fea:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1fed:	eb 12                	jmp    0x2001
    1fef:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1ff2:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    1ff5:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    1ff8:	99                   	cwd
    1ff9:	b9 02 00             	mov    cx,0x2
    1ffc:	f7 f9                	idiv   cx
    1ffe:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2001:	8d 7e f0             	lea    di,[bp-0x10]
    2004:	16                   	push   ss
    2005:	57                   	push   di
    2006:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2009:	ff 76 fc             	push   WORD PTR [bp-0x4]
    200c:	8d be ce fe          	lea    di,[bp-0x132]
    2010:	16                   	push   ss
    2011:	57                   	push   di
    2012:	c4 be ca fe          	les    di,DWORD PTR [bp-0x136]
    2016:	06                   	push   es
    2017:	57                   	push   di
    2018:	9a 78 1f 38 20       	call   0x2038:0x1f78
    201d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2021:	83 c4 06             	add    sp,0x6
    2024:	b8 5a 20             	mov    ax,0x205a
    2027:	0e                   	push   cs
    2028:	50                   	push   ax
    2029:	6a 00                	push   0x0
    202b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    202e:	26 c4 bd 01 01       	les    di,DWORD PTR es:[di+0x101]
    2033:	06                   	push   es
    2034:	57                   	push   di
    2035:	9a 5d 22 a9 20       	call   0x20a9:0x225d
    203a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    203d:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    2042:	75 15                	jne    0x2059
    2044:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2047:	06                   	push   es
    2048:	57                   	push   di
    2049:	9a b9 62 44 22       	call   0x2244:0x62b9
    204e:	50                   	push   ax
    204f:	8d 7e ce             	lea    di,[bp-0x32]
    2052:	16                   	push   ss
    2053:	57                   	push   di
    2054:	9a ff ff 00 00       	call   0x0:0xffff
    2059:	cb                   	retf
    205a:	c9                   	leave
    205b:	ca 08 00             	retf   0x8
    205e:	55                   	push   bp
    205f:	89 e5                	mov    bp,sp
    2061:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2064:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2067:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    206a:	06                   	push   es
    206b:	57                   	push   di
    206c:	9a de 4c 22 21       	call   0x2122:0x4cde
    2071:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2074:	06                   	push   es
    2075:	57                   	push   di
    2076:	9a 7f 20 a9 21       	call   0x21a9:0x207f
    207b:	c9                   	leave
    207c:	ca 08 00             	retf   0x8
    207f:	c8 46 00 00          	enter  0x46,0x0
    2083:	6a 00                	push   0x0
    2085:	9a ff ff 00 00       	call   0x0:0xffff
    208a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    208d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2090:	8d 7e da             	lea    di,[bp-0x26]
    2093:	16                   	push   ss
    2094:	57                   	push   di
    2095:	9a bd 20 00 00       	call   0x0:0x20bd
    209a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    209d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a0:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    20a4:	06                   	push   es
    20a5:	57                   	push   di
    20a6:	9a 16 10 2b 30       	call   0x302b:0x1016
    20ab:	50                   	push   ax
    20ac:	9a c8 20 00 00       	call   0x0:0x20c8
    20b1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    20b4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20b7:	8d 7e ba             	lea    di,[bp-0x46]
    20ba:	16                   	push   ss
    20bb:	57                   	push   di
    20bc:	9a ff ff 00 00       	call   0x0:0xffff
    20c1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20c4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    20c7:	9a ff ff 00 00       	call   0x0:0xffff
    20cc:	6a 00                	push   0x0
    20ce:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20d1:	9a ff ff 00 00       	call   0x0:0xffff
    20d6:	8b 46 da             	mov    ax,WORD PTR [bp-0x26]
    20d9:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    20dc:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    20df:	3b 46 ba             	cmp    ax,WORD PTR [bp-0x46]
    20e2:	7e 06                	jle    0x20ea
    20e4:	8b 46 ba             	mov    ax,WORD PTR [bp-0x46]
    20e7:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    20ea:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    20ed:	99                   	cwd
    20ee:	b9 04 00             	mov    cx,0x4
    20f1:	f7 f9                	idiv   cx
    20f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20f6:	26 89 85 07 01       	mov    WORD PTR es:[di+0x107],ax
    20fb:	c9                   	leave
    20fc:	ca 04 00             	retf   0x4
    20ff:	c8 00 01 00          	enter  0x100,0x0
    2103:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2107:	74 08                	je     0x2111
    2109:	83 ec 08             	sub    sp,0x8
    210c:	9a e2 1f 07 22       	call   0x2207:0x1fe2
    2111:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2114:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2117:	31 c0                	xor    ax,ax
    2119:	50                   	push   ax
    211a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    211d:	06                   	push   es
    211e:	57                   	push   di
    211f:	9a 08 6d 2e 21       	call   0x212e:0x6d08
    2124:	6a 00                	push   0x0
    2126:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2129:	06                   	push   es
    212a:	57                   	push   di
    212b:	9a 38 6e 8c 23       	call   0x238c:0x6e38
    2130:	8d be 00 ff          	lea    di,[bp-0x100]
    2134:	16                   	push   ss
    2135:	57                   	push   di
    2136:	68 27 f2             	push   0xf227
    2139:	9a 2b 09 41 21       	call   0x2141:0x92b
    213e:	9a d7 05 5c 21       	call   0x215c:0x5d7
    2143:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2146:	26 89 85 e2 00       	mov    WORD PTR es:[di+0xe2],ax
    214b:	26 89 95 e4 00       	mov    WORD PTR es:[di+0xe4],dx
    2150:	8d be 00 ff          	lea    di,[bp-0x100]
    2154:	16                   	push   ss
    2155:	57                   	push   di
    2156:	68 26 f2             	push   0xf226
    2159:	9a 2b 09 61 21       	call   0x2161:0x92b
    215e:	9a d7 05 25 22       	call   0x2225:0x5d7
    2163:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2166:	26 89 85 e6 00       	mov    WORD PTR es:[di+0xe6],ax
    216b:	26 89 95 e8 00       	mov    WORD PTR es:[di+0xe8],dx
    2170:	b0 01                	mov    al,0x1
    2172:	50                   	push   ax
    2173:	b8 1c 15             	mov    ax,0x151c
    2176:	ba 7e 21             	mov    dx,0x217e
    2179:	52                   	push   dx
    217a:	50                   	push   ax
    217b:	9a b4 7f ae 24       	call   0x24ae:0x7fb4
    2180:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2183:	26 89 85 de 00       	mov    WORD PTR es:[di+0xde],ax
    2188:	26 89 95 e0 00       	mov    WORD PTR es:[di+0xe0],dx
    218d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2190:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2193:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2198:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    219c:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    21a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21a3:	06                   	push   es
    21a4:	57                   	push   di
    21a5:	b8 a4 22             	mov    ax,0x22a4
    21a8:	ba c9 21             	mov    dx,0x21c9
    21ab:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    21b0:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    21b4:	26 89 55 24          	mov    WORD PTR es:[di+0x24],dx
    21b8:	26 8f 45 26          	pop    WORD PTR es:[di+0x26]
    21bc:	26 8f 45 28          	pop    WORD PTR es:[di+0x28]
    21c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c3:	06                   	push   es
    21c4:	57                   	push   di
    21c5:	b8 92 23             	mov    ax,0x2392
    21c8:	ba 86 22             	mov    dx,0x2286
    21cb:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    21d0:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    21d4:	26 89 55 34          	mov    WORD PTR es:[di+0x34],dx
    21d8:	26 8f 45 36          	pop    WORD PTR es:[di+0x36]
    21dc:	26 8f 45 38          	pop    WORD PTR es:[di+0x38]
    21e0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    21e4:	74 07                	je     0x21ed
    21e6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    21ea:	83 c4 06             	add    sp,0x6
    21ed:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    21f0:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    21f3:	c9                   	leave
    21f4:	ca 0a 00             	retf   0xa
    21f7:	55                   	push   bp
    21f8:	89 e5                	mov    bp,sp
    21fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21fd:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2202:	06                   	push   es
    2203:	57                   	push   di
    2204:	9a 7f 1f 4f 22       	call   0x224f:0x1f7f
    2209:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    220c:	31 c0                	xor    ax,ax
    220e:	26 89 85 de 00       	mov    WORD PTR es:[di+0xde],ax
    2213:	26 89 85 e0 00       	mov    WORD PTR es:[di+0xe0],ax
    2218:	26 ff b5 e8 00       	push   WORD PTR es:[di+0xe8]
    221d:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    2222:	9a 24 06 37 22       	call   0x2237:0x624
    2227:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    222a:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    222f:	26 ff b5 e2 00       	push   WORD PTR es:[di+0xe2]
    2234:	9a 24 06 89 24       	call   0x2489:0x624
    2239:	31 c0                	xor    ax,ax
    223b:	50                   	push   ax
    223c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    223f:	06                   	push   es
    2240:	57                   	push   di
    2241:	9a fc 2e 6a 22       	call   0x226a:0x2efc
    2246:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    224a:	74 05                	je     0x2251
    224c:	9a 0f 20 38 23       	call   0x2338:0x200f
    2251:	c9                   	leave
    2252:	ca 06 00             	retf   0x6
    2255:	55                   	push   bp
    2256:	89 e5                	mov    bp,sp
    2258:	ff 76 0e             	push   WORD PTR [bp+0xe]
    225b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    225e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2261:	50                   	push   ax
    2262:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2265:	06                   	push   es
    2266:	57                   	push   di
    2267:	9a 32 16 9a 25       	call   0x259a:0x1632
    226c:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    2270:	75 2e                	jne    0x22a0
    2272:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2275:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    227a:	26 0b 85 e0 00       	or     ax,WORD PTR es:[di+0xe0]
    227f:	74 1f                	je     0x22a0
    2281:	06                   	push   es
    2282:	57                   	push   di
    2283:	9a d1 24 9e 22       	call   0x229e:0x24d1
    2288:	3b 56 0e             	cmp    dx,WORD PTR [bp+0xe]
    228b:	75 13                	jne    0x22a0
    228d:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    2290:	75 0e                	jne    0x22a0
    2292:	6a 00                	push   0x0
    2294:	6a 00                	push   0x0
    2296:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2299:	06                   	push   es
    229a:	57                   	push   di
    229b:	9a f5 24 52 23       	call   0x2352:0x24f5
    22a0:	c9                   	leave
    22a1:	ca 0a 00             	retf   0xa
    22a4:	c8 02 02 00          	enter  0x202,0x0
    22a8:	c6 46 ff 02          	mov    BYTE PTR [bp-0x1],0x2
    22ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22af:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    22b4:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    22b8:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    22bc:	75 03                	jne    0x22c1
    22be:	e9 bf 00             	jmp    0x2380
    22c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c4:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    22c9:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    22cd:	06                   	push   es
    22ce:	57                   	push   di
    22cf:	9a db 69 2a 23       	call   0x232a:0x69db
    22d4:	08 c0                	or     al,al
    22d6:	74 03                	je     0x22db
    22d8:	e9 a5 00             	jmp    0x2380
    22db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22de:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    22e3:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    22e7:	26 80 7d 22 05       	cmp    BYTE PTR es:[di+0x22],0x5
    22ec:	75 25                	jne    0x2313
    22ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22f1:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    22f6:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    22fa:	06                   	push   es
    22fb:	57                   	push   di
    22fc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22ff:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    2303:	08 c0                	or     al,al
    2305:	74 06                	je     0x230d
    2307:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    230b:	eb 04                	jmp    0x2311
    230d:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2311:	eb 6d                	jmp    0x2380
    2313:	8d be fe fd          	lea    di,[bp-0x202]
    2317:	16                   	push   ss
    2318:	57                   	push   di
    2319:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    231c:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2321:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    2325:	06                   	push   es
    2326:	57                   	push   di
    2327:	9a cf 68 39 24       	call   0x2439:0x68cf
    232c:	8d be fe fe          	lea    di,[bp-0x102]
    2330:	16                   	push   ss
    2331:	57                   	push   di
    2332:	68 ff 00             	push   0xff
    2335:	9a e7 17 35 25       	call   0x2535:0x17e7
    233a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    233d:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2342:	06                   	push   es
    2343:	57                   	push   di
    2344:	8d be fe fe          	lea    di,[bp-0x102]
    2348:	16                   	push   ss
    2349:	57                   	push   di
    234a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234d:	06                   	push   es
    234e:	57                   	push   di
    234f:	9a 52 24 76 23       	call   0x2376:0x2452
    2354:	08 c0                	or     al,al
    2356:	74 06                	je     0x235e
    2358:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    235c:	eb 22                	jmp    0x2380
    235e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2361:	26 c4 bd e6 00       	les    di,DWORD PTR es:[di+0xe6]
    2366:	06                   	push   es
    2367:	57                   	push   di
    2368:	8d be fe fe          	lea    di,[bp-0x102]
    236c:	16                   	push   ss
    236d:	57                   	push   di
    236e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2371:	06                   	push   es
    2372:	57                   	push   di
    2373:	9a 52 24 32 26       	call   0x2632:0x2452
    2378:	08 c0                	or     al,al
    237a:	74 04                	je     0x2380
    237c:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2380:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2383:	50                   	push   ax
    2384:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2387:	06                   	push   es
    2388:	57                   	push   di
    2389:	9a 38 6e d1 23       	call   0x23d1:0x6e38
    238e:	c9                   	leave
    238f:	ca 08 00             	retf   0x8
    2392:	c8 06 01 00          	enter  0x106,0x0
    2396:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2399:	26 80 bd dc 00 02    	cmp    BYTE PTR es:[di+0xdc],0x2
    239f:	75 15                	jne    0x23b6
    23a1:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    23a6:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    23aa:	06                   	push   es
    23ab:	57                   	push   di
    23ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23af:	26 ff 5d 6c          	call   DWORD PTR es:[di+0x6c]
    23b3:	e9 98 00             	jmp    0x244e
    23b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b9:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    23be:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    23c2:	26 80 7d 22 05       	cmp    BYTE PTR es:[di+0x22],0x5
    23c7:	75 22                	jne    0x23eb
    23c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23cc:	06                   	push   es
    23cd:	57                   	push   di
    23ce:	9a d2 6d f3 23       	call   0x23f3:0x6dd2
    23d3:	50                   	push   ax
    23d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d7:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    23dc:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    23e0:	06                   	push   es
    23e1:	57                   	push   di
    23e2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23e5:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    23e9:	eb 63                	jmp    0x244e
    23eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ee:	06                   	push   es
    23ef:	57                   	push   di
    23f0:	9a d2 6d bc 24       	call   0x24bc:0x6dd2
    23f5:	08 c0                	or     al,al
    23f7:	74 15                	je     0x240e
    23f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23fc:	26 8b 85 e2 00       	mov    ax,WORD PTR es:[di+0xe2]
    2401:	26 8b 95 e4 00       	mov    dx,WORD PTR es:[di+0xe4]
    2406:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2409:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    240c:	eb 13                	jmp    0x2421
    240e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2411:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    2416:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    241b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    241e:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2421:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    2426:	8d be fa fe          	lea    di,[bp-0x106]
    242a:	16                   	push   ss
    242b:	57                   	push   di
    242c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    242f:	06                   	push   es
    2430:	57                   	push   di
    2431:	8d 7e fe             	lea    di,[bp-0x2]
    2434:	16                   	push   ss
    2435:	57                   	push   di
    2436:	9a f3 0f 4c 24       	call   0x244c:0xff3
    243b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    243e:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2443:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    2447:	06                   	push   es
    2448:	57                   	push   di
    2449:	9a 56 6f 7f 24       	call   0x247f:0x6f56
    244e:	c9                   	leave
    244f:	ca 08 00             	retf   0x8
    2452:	c8 04 01 00          	enter  0x104,0x0
    2456:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    245a:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    245f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2462:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2465:	30 e4                	xor    ah,ah
    2467:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    246a:	7c 2b                	jl     0x2497
    246c:	8d be fc fe          	lea    di,[bp-0x104]
    2470:	16                   	push   ss
    2471:	57                   	push   di
    2472:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2475:	06                   	push   es
    2476:	57                   	push   di
    2477:	8d 7e fc             	lea    di,[bp-0x4]
    247a:	16                   	push   ss
    247b:	57                   	push   di
    247c:	9a f3 0f 0b 25       	call   0x250b:0xff3
    2481:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2484:	06                   	push   es
    2485:	57                   	push   di
    2486:	9a ed 07 22 26       	call   0x2622:0x7ed
    248b:	09 c0                	or     ax,ax
    248d:	75 06                	jne    0x2495
    248f:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    2493:	eb 02                	jmp    0x2497
    2495:	eb c8                	jmp    0x245f
    2497:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    249a:	c9                   	leave
    249b:	ca 0c 00             	retf   0xc
    249e:	55                   	push   bp
    249f:	89 e5                	mov    bp,sp
    24a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24a4:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    24a9:	06                   	push   es
    24aa:	57                   	push   di
    24ab:	9a 4f 81 cb 24       	call   0x24cb:0x814f
    24b0:	08 c0                	or     al,al
    24b2:	74 19                	je     0x24cd
    24b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24b7:	06                   	push   es
    24b8:	57                   	push   di
    24b9:	9a 7c 6d e1 26       	call   0x26e1:0x6d7c
    24be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c1:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    24c6:	06                   	push   es
    24c7:	57                   	push   di
    24c8:	9a b3 81 28 25       	call   0x2528:0x81b3
    24cd:	c9                   	leave
    24ce:	ca 04 00             	retf   0x4
    24d1:	c8 04 00 00          	enter  0x4,0x0
    24d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24d8:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    24dd:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    24e1:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    24e5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    24e8:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    24eb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    24ee:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    24f1:	c9                   	leave
    24f2:	ca 04 00             	retf   0x4
    24f5:	55                   	push   bp
    24f6:	89 e5                	mov    bp,sp
    24f8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    24fb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    24fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2501:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2506:	06                   	push   es
    2507:	57                   	push   di
    2508:	9a 31 77 84 25       	call   0x2584:0x7731
    250d:	c9                   	leave
    250e:	ca 08 00             	retf   0x8
    2511:	c8 00 01 00          	enter  0x100,0x0
    2515:	8d be 00 ff          	lea    di,[bp-0x100]
    2519:	16                   	push   ss
    251a:	57                   	push   di
    251b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    251e:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2523:	06                   	push   es
    2524:	57                   	push   di
    2525:	9a 63 80 50 25       	call   0x2550:0x8063
    252a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    252d:	06                   	push   es
    252e:	57                   	push   di
    252f:	68 ff 00             	push   0xff
    2532:	9a e7 17 ea 25       	call   0x25ea:0x17e7
    2537:	c9                   	leave
    2538:	ca 04 00             	retf   0x4
    253b:	55                   	push   bp
    253c:	89 e5                	mov    bp,sp
    253e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2541:	06                   	push   es
    2542:	57                   	push   di
    2543:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2546:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    254b:	06                   	push   es
    254c:	57                   	push   di
    254d:	9a 80 80 b7 25       	call   0x25b7:0x8080
    2552:	c9                   	leave
    2553:	ca 08 00             	retf   0x8
    2556:	c8 02 00 00          	enter  0x2,0x0
    255a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    255d:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2562:	26 8a 45 10          	mov    al,BYTE PTR es:[di+0x10]
    2566:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2569:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    256c:	c9                   	leave
    256d:	ca 04 00             	retf   0x4
    2570:	55                   	push   bp
    2571:	89 e5                	mov    bp,sp
    2573:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2576:	50                   	push   ax
    2577:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    257a:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    257f:	06                   	push   es
    2580:	57                   	push   di
    2581:	9a 6e 77 8a 26       	call   0x268a:0x776e
    2586:	c9                   	leave
    2587:	ca 06 00             	retf   0x6
    258a:	55                   	push   bp
    258b:	89 e5                	mov    bp,sp
    258d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2590:	06                   	push   es
    2591:	57                   	push   di
    2592:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2595:	06                   	push   es
    2596:	57                   	push   di
    2597:	9a 1f 52 b9 26       	call   0x26b9:0x521f
    259c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    259f:	26 8a 05             	mov    al,BYTE PTR es:[di]
    25a2:	3c 08                	cmp    al,0x8
    25a4:	74 04                	je     0x25aa
    25a6:	3c 20                	cmp    al,0x20
    25a8:	75 11                	jne    0x25bb
    25aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25ad:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    25b2:	06                   	push   es
    25b3:	57                   	push   di
    25b4:	9a 4f 81 cc 25       	call   0x25cc:0x814f
    25b9:	eb 13                	jmp    0x25ce
    25bb:	3c 1b                	cmp    al,0x1b
    25bd:	75 0f                	jne    0x25ce
    25bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c2:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    25c7:	06                   	push   es
    25c8:	57                   	push   di
    25c9:	9a c2 81 ea 26       	call   0x26ea:0x81c2
    25ce:	c9                   	leave
    25cf:	ca 08 00             	retf   0x8
    25d2:	55                   	push   bp
    25d3:	89 e5                	mov    bp,sp
    25d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25d8:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    25dd:	06                   	push   es
    25de:	57                   	push   di
    25df:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    25e2:	06                   	push   es
    25e3:	57                   	push   di
    25e4:	68 ff 00             	push   0xff
    25e7:	9a e7 17 08 26       	call   0x2608:0x17e7
    25ec:	c9                   	leave
    25ed:	ca 04 00             	retf   0x4
    25f0:	55                   	push   bp
    25f1:	89 e5                	mov    bp,sp
    25f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f6:	26 c4 bd e6 00       	les    di,DWORD PTR es:[di+0xe6]
    25fb:	06                   	push   es
    25fc:	57                   	push   di
    25fd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2600:	06                   	push   es
    2601:	57                   	push   di
    2602:	68 ff 00             	push   0xff
    2605:	9a e7 17 a4 26       	call   0x26a4:0x17e7
    260a:	c9                   	leave
    260b:	ca 04 00             	retf   0x4
    260e:	55                   	push   bp
    260f:	89 e5                	mov    bp,sp
    2611:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2614:	81 c7 e2 00          	add    di,0xe2
    2618:	06                   	push   es
    2619:	57                   	push   di
    261a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    261d:	06                   	push   es
    261e:	57                   	push   di
    261f:	9a 51 06 4c 26       	call   0x264c:0x651
    2624:	ff 76 08             	push   WORD PTR [bp+0x8]
    2627:	ff 76 06             	push   WORD PTR [bp+0x6]
    262a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    262d:	06                   	push   es
    262e:	57                   	push   di
    262f:	9a a4 22 5c 26       	call   0x265c:0x22a4
    2634:	c9                   	leave
    2635:	ca 08 00             	retf   0x8
    2638:	55                   	push   bp
    2639:	89 e5                	mov    bp,sp
    263b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    263e:	81 c7 e6 00          	add    di,0xe6
    2642:	06                   	push   es
    2643:	57                   	push   di
    2644:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2647:	06                   	push   es
    2648:	57                   	push   di
    2649:	9a 51 06 0e 30       	call   0x300e:0x651
    264e:	ff 76 08             	push   WORD PTR [bp+0x8]
    2651:	ff 76 06             	push   WORD PTR [bp+0x6]
    2654:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2657:	06                   	push   es
    2658:	57                   	push   di
    2659:	9a a4 22 6a 26       	call   0x266a:0x22a4
    265e:	c9                   	leave
    265f:	ca 08 00             	retf   0x8
    2662:	01 00                	add    WORD PTR [bx+si],ax
    2664:	00 00                	add    BYTE PTR [bx+si],al
    2666:	00 00                	add    BYTE PTR [bx+si],al
    2668:	95                   	xchg   bp,ax
    2669:	26 1c 27             	es sbb al,0x27
    266c:	55                   	push   bp
    266d:	89 e5                	mov    bp,sp
    266f:	b8 62 26             	mov    ax,0x2662
    2672:	0e                   	push   cs
    2673:	50                   	push   ax
    2674:	55                   	push   bp
    2675:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2679:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    267d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2680:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2685:	06                   	push   es
    2686:	57                   	push   di
    2687:	9a 5e 78 5c 28       	call   0x285c:0x785e
    268c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2690:	83 c4 06             	add    sp,0x6
    2693:	eb 16                	jmp    0x26ab
    2695:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2698:	06                   	push   es
    2699:	57                   	push   di
    269a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    269d:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    26a1:	ea 85 13 a9 26       	jmp    0x26a9:0x1385
    26a6:	9a 34 14 ce 26       	call   0x26ce:0x1434
    26ab:	ff 76 0c             	push   WORD PTR [bp+0xc]
    26ae:	ff 76 0a             	push   WORD PTR [bp+0xa]
    26b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b4:	06                   	push   es
    26b5:	57                   	push   di
    26b6:	9a d2 55 d9 27       	call   0x27d9:0x55d2
    26bb:	c9                   	leave
    26bc:	ca 08 00             	retf   0x8
    26bf:	55                   	push   bp
    26c0:	89 e5                	mov    bp,sp
    26c2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    26c6:	74 08                	je     0x26d0
    26c8:	83 ec 08             	sub    sp,0x8
    26cb:	9a e2 1f 9a 27       	call   0x279a:0x1fe2
    26d0:	ff 76 0e             	push   WORD PTR [bp+0xe]
    26d3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    26d6:	31 c0                	xor    ax,ax
    26d8:	50                   	push   ax
    26d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26dc:	06                   	push   es
    26dd:	57                   	push   di
    26de:	9a 20 5a b3 27       	call   0x27b3:0x5a20
    26e3:	b0 01                	mov    al,0x1
    26e5:	50                   	push   ax
    26e6:	b8 1c 15             	mov    ax,0x151c
    26e9:	ba f1 26             	mov    dx,0x26f1
    26ec:	52                   	push   dx
    26ed:	50                   	push   ax
    26ee:	9a b4 7f e4 29       	call   0x29e4:0x7fb4
    26f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26f6:	26 89 85 22 01       	mov    WORD PTR es:[di+0x122],ax
    26fb:	26 89 95 24 01       	mov    WORD PTR es:[di+0x124],dx
    2700:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2703:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2706:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    270b:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    270f:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    2713:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2716:	06                   	push   es
    2717:	57                   	push   di
    2718:	b8 2f 28             	mov    ax,0x282f
    271b:	ba 3c 27             	mov    dx,0x273c
    271e:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2723:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    2727:	26 89 55 24          	mov    WORD PTR es:[di+0x24],dx
    272b:	26 8f 45 26          	pop    WORD PTR es:[di+0x26]
    272f:	26 8f 45 28          	pop    WORD PTR es:[di+0x28]
    2733:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2736:	06                   	push   es
    2737:	57                   	push   di
    2738:	b8 a3 28             	mov    ax,0x28a3
    273b:	ba 5c 27             	mov    dx,0x275c
    273e:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2743:	26 89 45 32          	mov    WORD PTR es:[di+0x32],ax
    2747:	26 89 55 34          	mov    WORD PTR es:[di+0x34],dx
    274b:	26 8f 45 36          	pop    WORD PTR es:[di+0x36]
    274f:	26 8f 45 38          	pop    WORD PTR es:[di+0x38]
    2753:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2756:	06                   	push   es
    2757:	57                   	push   di
    2758:	b8 2f 2c             	mov    ax,0x2c2f
    275b:	ba f5 27             	mov    dx,0x27f5
    275e:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2763:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    2767:	26 89 55 2c          	mov    WORD PTR es:[di+0x2c],dx
    276b:	26 8f 45 2e          	pop    WORD PTR es:[di+0x2e]
    276f:	26 8f 45 30          	pop    WORD PTR es:[di+0x30]
    2773:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2777:	74 07                	je     0x2780
    2779:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    277d:	83 c4 06             	add    sp,0x6
    2780:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2783:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2786:	c9                   	leave
    2787:	ca 0a 00             	retf   0xa
    278a:	55                   	push   bp
    278b:	89 e5                	mov    bp,sp
    278d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2790:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2795:	06                   	push   es
    2796:	57                   	push   di
    2797:	9a 7f 1f be 27       	call   0x27be:0x1f7f
    279c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    279f:	31 c0                	xor    ax,ax
    27a1:	26 89 85 22 01       	mov    WORD PTR es:[di+0x122],ax
    27a6:	26 89 85 24 01       	mov    WORD PTR es:[di+0x124],ax
    27ab:	31 c0                	xor    ax,ax
    27ad:	50                   	push   ax
    27ae:	06                   	push   es
    27af:	57                   	push   di
    27b0:	9a 36 5b 1e 28       	call   0x281e:0x5b36
    27b5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    27b9:	74 05                	je     0x27c0
    27bb:	9a 0f 20 ea 28       	call   0x28ea:0x200f
    27c0:	c9                   	leave
    27c1:	ca 06 00             	retf   0x6
    27c4:	55                   	push   bp
    27c5:	89 e5                	mov    bp,sp
    27c7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    27ca:	ff 76 0c             	push   WORD PTR [bp+0xc]
    27cd:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    27d0:	50                   	push   ax
    27d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27d4:	06                   	push   es
    27d5:	57                   	push   di
    27d6:	9a 32 16 50 29       	call   0x2950:0x1632
    27db:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    27df:	75 2e                	jne    0x280f
    27e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e4:	26 8b 85 22 01       	mov    ax,WORD PTR es:[di+0x122]
    27e9:	26 0b 85 24 01       	or     ax,WORD PTR es:[di+0x124]
    27ee:	74 1f                	je     0x280f
    27f0:	06                   	push   es
    27f1:	57                   	push   di
    27f2:	9a 52 2a 0d 28       	call   0x280d:0x2a52
    27f7:	3b 56 0e             	cmp    dx,WORD PTR [bp+0xe]
    27fa:	75 13                	jne    0x280f
    27fc:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    27ff:	75 0e                	jne    0x280f
    2801:	6a 00                	push   0x0
    2803:	6a 00                	push   0x0
    2805:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2808:	06                   	push   es
    2809:	57                   	push   di
    280a:	9a 76 2a 28 28       	call   0x2828:0x2a76
    280f:	c9                   	leave
    2810:	ca 0a 00             	retf   0xa
    2813:	55                   	push   bp
    2814:	89 e5                	mov    bp,sp
    2816:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2819:	06                   	push   es
    281a:	57                   	push   di
    281b:	9a f4 5d 2d 29       	call   0x292d:0x5df4
    2820:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2823:	06                   	push   es
    2824:	57                   	push   di
    2825:	9a 40 2c 66 28       	call   0x2866:0x2c40
    282a:	c9                   	leave
    282b:	ca 04 00             	retf   0x4
    282e:	00 c8                	add    al,cl
    2830:	00 01                	add    BYTE PTR [bx+di],al
    2832:	00 c4                	add    ah,al
    2834:	7e 06                	jle    0x283c
    2836:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    283b:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    283f:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    2843:	74 25                	je     0x286a
    2845:	8d be 00 ff          	lea    di,[bp-0x100]
    2849:	16                   	push   ss
    284a:	57                   	push   di
    284b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284e:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2853:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    2857:	06                   	push   es
    2858:	57                   	push   di
    2859:	9a cf 68 c8 28       	call   0x28c8:0x68cf
    285e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2861:	06                   	push   es
    2862:	57                   	push   di
    2863:	9a ce 28 8c 28       	call   0x288c:0x28ce
    2868:	eb 35                	jmp    0x289f
    286a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    286d:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2872:	74 1c                	je     0x2890
    2874:	8d be 00 ff          	lea    di,[bp-0x100]
    2878:	16                   	push   ss
    2879:	57                   	push   di
    287a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    287d:	06                   	push   es
    287e:	57                   	push   di
    287f:	9a 2a 51 85 2e       	call   0x2e85:0x512a
    2884:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2887:	06                   	push   es
    2888:	57                   	push   di
    2889:	9a ce 28 9d 28       	call   0x289d:0x28ce
    288e:	eb 0f                	jmp    0x289f
    2890:	bf 2e 28             	mov    di,0x282e
    2893:	0e                   	push   cs
    2894:	57                   	push   di
    2895:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2898:	06                   	push   es
    2899:	57                   	push   di
    289a:	9a ce 28 b5 28       	call   0x28b5:0x28ce
    289f:	c9                   	leave
    28a0:	ca 08 00             	retf   0x8
    28a3:	c8 00 01 00          	enter  0x100,0x0
    28a7:	8d be 00 ff          	lea    di,[bp-0x100]
    28ab:	16                   	push   ss
    28ac:	57                   	push   di
    28ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b0:	06                   	push   es
    28b1:	57                   	push   di
    28b2:	9a 56 29 e5 28       	call   0x28e5:0x2956
    28b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ba:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    28bf:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    28c3:	06                   	push   es
    28c4:	57                   	push   di
    28c5:	9a 56 6f 8c 2a       	call   0x2a8c:0x6f56
    28ca:	c9                   	leave
    28cb:	ca 08 00             	retf   0x8
    28ce:	c8 02 01 00          	enter  0x102,0x0
    28d2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    28d5:	06                   	push   es
    28d6:	57                   	push   di
    28d7:	8d be fe fe          	lea    di,[bp-0x102]
    28db:	16                   	push   ss
    28dc:	57                   	push   di
    28dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28e0:	06                   	push   es
    28e1:	57                   	push   di
    28e2:	9a 56 29 3a 2c       	call   0x2c3a:0x2956
    28e7:	9a be 18 81 29       	call   0x2981:0x18be
    28ec:	74 64                	je     0x2952
    28ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28f1:	26 80 bd e1 00 00    	cmp    BYTE PTR es:[di+0xe1],0x0
    28f7:	74 3e                	je     0x2937
    28f9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    28fc:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2900:	75 07                	jne    0x2909
    2902:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    2907:	eb 19                	jmp    0x2922
    2909:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    290c:	06                   	push   es
    290d:	57                   	push   di
    290e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2911:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2916:	06                   	push   es
    2917:	57                   	push   di
    2918:	26 c4 3d             	les    di,DWORD PTR es:[di]
    291b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    291f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2922:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2925:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2928:	06                   	push   es
    2929:	57                   	push   di
    292a:	9a 2e 5c 8d 29       	call   0x298d:0x5c2e
    292f:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2933:	7c 02                	jl     0x2937
    2935:	eb 1b                	jmp    0x2952
    2937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    293a:	26 8a 85 e1 00       	mov    al,BYTE PTR es:[di+0xe1]
    293f:	3c 01                	cmp    al,0x1
    2941:	77 0f                	ja     0x2952
    2943:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2946:	06                   	push   es
    2947:	57                   	push   di
    2948:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    294b:	06                   	push   es
    294c:	57                   	push   di
    294d:	9a 8c 1d 74 29       	call   0x2974:0x1d8c
    2952:	c9                   	leave
    2953:	ca 08 00             	retf   0x8
    2956:	c8 02 01 00          	enter  0x102,0x0
    295a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    295d:	26 8a 85 e1 00       	mov    al,BYTE PTR es:[di+0xe1]
    2962:	3c 01                	cmp    al,0x1
    2964:	77 1f                	ja     0x2985
    2966:	8d be fe fe          	lea    di,[bp-0x102]
    296a:	16                   	push   ss
    296b:	57                   	push   di
    296c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    296f:	06                   	push   es
    2970:	57                   	push   di
    2971:	9a 53 1d 1d 2a       	call   0x2a1d:0x1d53
    2976:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2979:	06                   	push   es
    297a:	57                   	push   di
    297b:	68 ff 00             	push   0xff
    297e:	9a e7 17 ce 29       	call   0x29ce:0x17e7
    2983:	eb 4b                	jmp    0x29d0
    2985:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2988:	06                   	push   es
    2989:	57                   	push   di
    298a:	9a 07 5c 9a 29       	call   0x299a:0x5c07
    298f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2992:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2995:	06                   	push   es
    2996:	57                   	push   di
    2997:	9a 07 5c ee 29       	call   0x29ee:0x5c07
    299c:	09 c0                	or     ax,ax
    299e:	7d 09                	jge    0x29a9
    29a0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    29a3:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    29a7:	eb 27                	jmp    0x29d0
    29a9:	8d be fe fe          	lea    di,[bp-0x102]
    29ad:	16                   	push   ss
    29ae:	57                   	push   di
    29af:	ff 76 fe             	push   WORD PTR [bp-0x2]
    29b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29b5:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    29ba:	06                   	push   es
    29bb:	57                   	push   di
    29bc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29bf:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    29c3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    29c6:	06                   	push   es
    29c7:	57                   	push   di
    29c8:	68 ff 00             	push   0xff
    29cb:	9a e7 17 b6 2a       	call   0x2ab6:0x17e7
    29d0:	c9                   	leave
    29d1:	ca 04 00             	retf   0x4
    29d4:	55                   	push   bp
    29d5:	89 e5                	mov    bp,sp
    29d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29da:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    29df:	06                   	push   es
    29e0:	57                   	push   di
    29e1:	9a 4f 81 fd 29       	call   0x29fd:0x814f
    29e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29e9:	06                   	push   es
    29ea:	57                   	push   di
    29eb:	9a 72 66 4c 2a       	call   0x2a4c:0x6672
    29f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29f3:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    29f8:	06                   	push   es
    29f9:	57                   	push   di
    29fa:	9a b3 81 13 2a       	call   0x2a13:0x81b3
    29ff:	c9                   	leave
    2a00:	ca 04 00             	retf   0x4
    2a03:	55                   	push   bp
    2a04:	89 e5                	mov    bp,sp
    2a06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a09:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2a0e:	06                   	push   es
    2a0f:	57                   	push   di
    2a10:	9a 4f 81 2c 2a       	call   0x2a2c:0x814f
    2a15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a18:	06                   	push   es
    2a19:	57                   	push   di
    2a1a:	9a 73 27 43 2b       	call   0x2b43:0x2773
    2a1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a22:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2a27:	06                   	push   es
    2a28:	57                   	push   di
    2a29:	9a b3 81 42 2a       	call   0x2a42:0x81b3
    2a2e:	c9                   	leave
    2a2f:	ca 04 00             	retf   0x4
    2a32:	55                   	push   bp
    2a33:	89 e5                	mov    bp,sp
    2a35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a38:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2a3d:	06                   	push   es
    2a3e:	57                   	push   di
    2a3f:	9a 4f 81 a9 2a       	call   0x2aa9:0x814f
    2a44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a47:	06                   	push   es
    2a48:	57                   	push   di
    2a49:	9a 2e 67 22 2c       	call   0x2c22:0x672e
    2a4e:	c9                   	leave
    2a4f:	ca 04 00             	retf   0x4
    2a52:	c8 04 00 00          	enter  0x4,0x0
    2a56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a59:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2a5e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2a62:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    2a66:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a69:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2a6c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2a6f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2a72:	c9                   	leave
    2a73:	ca 04 00             	retf   0x4
    2a76:	55                   	push   bp
    2a77:	89 e5                	mov    bp,sp
    2a79:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2a7c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2a7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a82:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2a87:	06                   	push   es
    2a88:	57                   	push   di
    2a89:	9a 31 77 05 2b       	call   0x2b05:0x7731
    2a8e:	c9                   	leave
    2a8f:	ca 08 00             	retf   0x8
    2a92:	c8 00 01 00          	enter  0x100,0x0
    2a96:	8d be 00 ff          	lea    di,[bp-0x100]
    2a9a:	16                   	push   ss
    2a9b:	57                   	push   di
    2a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a9f:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2aa4:	06                   	push   es
    2aa5:	57                   	push   di
    2aa6:	9a 63 80 d1 2a       	call   0x2ad1:0x8063
    2aab:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2aae:	06                   	push   es
    2aaf:	57                   	push   di
    2ab0:	68 ff 00             	push   0xff
    2ab3:	9a e7 17 d6 2d       	call   0x2dd6:0x17e7
    2ab8:	c9                   	leave
    2ab9:	ca 04 00             	retf   0x4
    2abc:	55                   	push   bp
    2abd:	89 e5                	mov    bp,sp
    2abf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ac2:	06                   	push   es
    2ac3:	57                   	push   di
    2ac4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac7:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2acc:	06                   	push   es
    2acd:	57                   	push   di
    2ace:	9a 80 80 60 2b       	call   0x2b60:0x8080
    2ad3:	c9                   	leave
    2ad4:	ca 08 00             	retf   0x8
    2ad7:	c8 02 00 00          	enter  0x2,0x0
    2adb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ade:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2ae3:	26 8a 45 10          	mov    al,BYTE PTR es:[di+0x10]
    2ae7:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2aea:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2aed:	c9                   	leave
    2aee:	ca 04 00             	retf   0x4
    2af1:	55                   	push   bp
    2af2:	89 e5                	mov    bp,sp
    2af4:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2af7:	50                   	push   ax
    2af8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2afb:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2b00:	06                   	push   es
    2b01:	57                   	push   di
    2b02:	9a 6e 77 b2 2d       	call   0x2db2:0x776e
    2b07:	c9                   	leave
    2b08:	ca 06 00             	retf   0x6
    2b0b:	c8 04 00 00          	enter  0x4,0x0
    2b0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b12:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2b17:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    2b1b:	26 8b 55 16          	mov    dx,WORD PTR es:[di+0x16]
    2b1f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2b22:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2b25:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2b28:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2b2b:	c9                   	leave
    2b2c:	ca 04 00             	retf   0x4
    2b2f:	55                   	push   bp
    2b30:	89 e5                	mov    bp,sp
    2b32:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2b35:	06                   	push   es
    2b36:	57                   	push   di
    2b37:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2b3a:	50                   	push   ax
    2b3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b3e:	06                   	push   es
    2b3f:	57                   	push   di
    2b40:	9a 6a 4f 90 2b       	call   0x2b90:0x4f6a
    2b45:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2b48:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2b4b:	3c 08                	cmp    al,0x8
    2b4d:	74 04                	je     0x2b53
    2b4f:	3c 20                	cmp    al,0x20
    2b51:	72 29                	jb     0x2b7c
    2b53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b56:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2b5b:	06                   	push   es
    2b5c:	57                   	push   di
    2b5d:	9a 4f 81 03 2c       	call   0x2c03:0x814f
    2b62:	08 c0                	or     al,al
    2b64:	75 16                	jne    0x2b7c
    2b66:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2b69:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2b6c:	3c 26                	cmp    al,0x26
    2b6e:	74 04                	je     0x2b74
    2b70:	3c 28                	cmp    al,0x28
    2b72:	75 08                	jne    0x2b7c
    2b74:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2b77:	31 c0                	xor    ax,ax
    2b79:	26 89 05             	mov    WORD PTR es:[di],ax
    2b7c:	c9                   	leave
    2b7d:	ca 0a 00             	retf   0xa
    2b80:	55                   	push   bp
    2b81:	89 e5                	mov    bp,sp
    2b83:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b86:	06                   	push   es
    2b87:	57                   	push   di
    2b88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b8b:	06                   	push   es
    2b8c:	57                   	push   di
    2b8d:	9a 1f 52 54 2c       	call   0x2c54:0x521f
    2b92:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b95:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2b98:	3c 20                	cmp    al,0x20
    2b9a:	72 40                	jb     0x2bdc
    2b9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b9f:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2ba4:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    2ba8:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    2bac:	74 2e                	je     0x2bdc
    2bae:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2bb1:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2bb4:	50                   	push   ax
    2bb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bb8:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2bbd:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    2bc1:	06                   	push   es
    2bc2:	57                   	push   di
    2bc3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bc6:	26 ff 5d 70          	call   DWORD PTR es:[di+0x70]
    2bca:	08 c0                	or     al,al
    2bcc:	75 0e                	jne    0x2bdc
    2bce:	6a 00                	push   0x0
    2bd0:	9a ff ff 00 00       	call   0x0:0xffff
    2bd5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2bd8:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    2bdc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2bdf:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2be2:	3c 08                	cmp    al,0x8
    2be4:	74 10                	je     0x2bf6
    2be6:	3c 16                	cmp    al,0x16
    2be8:	74 0c                	je     0x2bf6
    2bea:	3c 18                	cmp    al,0x18
    2bec:	74 08                	je     0x2bf6
    2bee:	3c 20                	cmp    al,0x20
    2bf0:	72 15                	jb     0x2c07
    2bf2:	3c ff                	cmp    al,0xff
    2bf4:	77 11                	ja     0x2c07
    2bf6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bf9:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2bfe:	06                   	push   es
    2bff:	57                   	push   di
    2c00:	9a 4f 81 18 2c       	call   0x2c18:0x814f
    2c05:	eb 24                	jmp    0x2c2b
    2c07:	3c 1b                	cmp    al,0x1b
    2c09:	75 20                	jne    0x2c2b
    2c0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c0e:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2c13:	06                   	push   es
    2c14:	57                   	push   di
    2c15:	9a c2 81 b2 2c       	call   0x2cb2:0x81c2
    2c1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c1d:	06                   	push   es
    2c1e:	57                   	push   di
    2c1f:	9a e7 5b 29 2d       	call   0x2d29:0x5be7
    2c24:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2c27:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    2c2b:	c9                   	leave
    2c2c:	ca 08 00             	retf   0x8
    2c2f:	55                   	push   bp
    2c30:	89 e5                	mov    bp,sp
    2c32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c35:	06                   	push   es
    2c36:	57                   	push   di
    2c37:	9a 40 2c 1a 2d       	call   0x2d1a:0x2c40
    2c3c:	c9                   	leave
    2c3d:	ca 08 00             	retf   0x8
    2c40:	55                   	push   bp
    2c41:	89 e5                	mov    bp,sp
    2c43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c46:	26 8a 85 e1 00       	mov    al,BYTE PTR es:[di+0xe1]
    2c4b:	3c 01                	cmp    al,0x1
    2c4d:	77 30                	ja     0x2c7f
    2c4f:	06                   	push   es
    2c50:	57                   	push   di
    2c51:	9a fa 64 c8 2c       	call   0x2cc8:0x64fa
    2c56:	08 c0                	or     al,al
    2c58:	74 25                	je     0x2c7f
    2c5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c5d:	26 ff b5 16 01       	push   WORD PTR es:[di+0x116]
    2c62:	68 1f 04             	push   0x41f
    2c65:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2c6a:	26 80 7d 20 00       	cmp    BYTE PTR es:[di+0x20],0x0
    2c6f:	b0 00                	mov    al,0x0
    2c71:	75 01                	jne    0x2c74
    2c73:	40                   	inc    ax
    2c74:	98                   	cbw
    2c75:	50                   	push   ax
    2c76:	6a 00                	push   0x0
    2c78:	6a 00                	push   0x0
    2c7a:	9a ff ff 00 00       	call   0x0:0xffff
    2c7f:	c9                   	leave
    2c80:	ca 04 00             	retf   0x4
    2c83:	55                   	push   bp
    2c84:	89 e5                	mov    bp,sp
    2c86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c89:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2c8e:	74 03                	je     0x2c93
    2c90:	e9 89 00             	jmp    0x2d1c
    2c93:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2c96:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2c99:	3d 11 01             	cmp    ax,0x111
    2c9c:	75 3f                	jne    0x2cdd
    2c9e:	26 83 7d 06 01       	cmp    WORD PTR es:[di+0x6],0x1
    2ca3:	75 36                	jne    0x2cdb
    2ca5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ca8:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2cad:	06                   	push   es
    2cae:	57                   	push   di
    2caf:	9a 4f 81 f9 2c       	call   0x2cf9:0x814f
    2cb4:	08 c0                	or     al,al
    2cb6:	75 23                	jne    0x2cdb
    2cb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cbb:	26 80 bd e1 00 01    	cmp    BYTE PTR es:[di+0xe1],0x1
    2cc1:	74 16                	je     0x2cd9
    2cc3:	06                   	push   es
    2cc4:	57                   	push   di
    2cc5:	9a b9 62 eb 2d       	call   0x2deb:0x62b9
    2cca:	50                   	push   ax
    2ccb:	68 0f 04             	push   0x40f
    2cce:	6a 00                	push   0x0
    2cd0:	6a 00                	push   0x0
    2cd2:	6a 00                	push   0x0
    2cd4:	9a ff ff 00 00       	call   0x0:0xffff
    2cd9:	eb 50                	jmp    0x2d2b
    2cdb:	eb 3f                	jmp    0x2d1c
    2cdd:	3d 0f 04             	cmp    ax,0x40f
    2ce0:	75 3a                	jne    0x2d1c
    2ce2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ce5:	26 83 7d 02 00       	cmp    WORD PTR es:[di+0x2],0x0
    2cea:	74 11                	je     0x2cfd
    2cec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cef:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2cf4:	06                   	push   es
    2cf5:	57                   	push   di
    2cf6:	9a 4f 81 66 2d       	call   0x2d66:0x814f
    2cfb:	eb 1f                	jmp    0x2d1c
    2cfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d00:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2d05:	26 80 7d 20 00       	cmp    BYTE PTR es:[di+0x20],0x0
    2d0a:	75 10                	jne    0x2d1c
    2d0c:	ff 76 08             	push   WORD PTR [bp+0x8]
    2d0f:	ff 76 06             	push   WORD PTR [bp+0x6]
    2d12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d15:	06                   	push   es
    2d16:	57                   	push   di
    2d17:	9a 2f 28 92 2d       	call   0x2d92:0x282f
    2d1c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2d1f:	06                   	push   es
    2d20:	57                   	push   di
    2d21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d24:	06                   	push   es
    2d25:	57                   	push   di
    2d26:	9a 15 64 84 2d       	call   0x2d84:0x6415
    2d2b:	c9                   	leave
    2d2c:	ca 08 00             	retf   0x8
    2d2f:	55                   	push   bp
    2d30:	89 e5                	mov    bp,sp
    2d32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d35:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2d3a:	75 32                	jne    0x2d6e
    2d3c:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2d3f:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2d42:	3d 01 02             	cmp    ax,0x201
    2d45:	75 27                	jne    0x2d6e
    2d47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d4a:	26 80 bd e1 00 01    	cmp    BYTE PTR es:[di+0xe1],0x1
    2d50:	75 1c                	jne    0x2d6e
    2d52:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    2d55:	26 3b 85 16 01       	cmp    ax,WORD PTR es:[di+0x116]
    2d5a:	74 12                	je     0x2d6e
    2d5c:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2d61:	06                   	push   es
    2d62:	57                   	push   di
    2d63:	9a 4f 81 72 3b       	call   0x3b72:0x814f
    2d68:	08 c0                	or     al,al
    2d6a:	75 02                	jne    0x2d6e
    2d6c:	eb 18                	jmp    0x2d86
    2d6e:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2d71:	06                   	push   es
    2d72:	57                   	push   di
    2d73:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2d76:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2d79:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2d7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d7f:	06                   	push   es
    2d80:	57                   	push   di
    2d81:	9a 72 62 c5 2d       	call   0x2dc5:0x6272
    2d86:	c9                   	leave
    2d87:	ca 0e 00             	retf   0xe
    2d8a:	01 00                	add    WORD PTR [bx+si],ax
    2d8c:	00 00                	add    BYTE PTR [bx+si],al
    2d8e:	00 00                	add    BYTE PTR [bx+si],al
    2d90:	bd 2d 19             	mov    bp,0x192d
    2d93:	2e 55                	cs push bp
    2d95:	89 e5                	mov    bp,sp
    2d97:	b8 8a 2d             	mov    ax,0x2d8a
    2d9a:	0e                   	push   cs
    2d9b:	50                   	push   ax
    2d9c:	55                   	push   bp
    2d9d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2da1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2da5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2da8:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    2dad:	06                   	push   es
    2dae:	57                   	push   di
    2daf:	9a 5e 78 bd 36       	call   0x36bd:0x785e
    2db4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2db8:	83 c4 06             	add    sp,0x6
    2dbb:	eb 20                	jmp    0x2ddd
    2dbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dc0:	06                   	push   es
    2dc1:	57                   	push   di
    2dc2:	9a e7 5b ff ff       	call   0xffff:0x5be7
    2dc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dca:	06                   	push   es
    2dcb:	57                   	push   di
    2dcc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2dcf:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    2dd3:	ea 85 13 db 2d       	jmp    0x2ddb:0x1385
    2dd8:	9a 34 14 2e 2e       	call   0x2e2e:0x1434
    2ddd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2de0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2de3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2de6:	06                   	push   es
    2de7:	57                   	push   di
    2de8:	9a d2 55 c5 2e       	call   0x2ec5:0x55d2
    2ded:	c9                   	leave
    2dee:	ca 08 00             	retf   0x8
    2df1:	55                   	push   bp
    2df2:	89 e5                	mov    bp,sp
    2df4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2df7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2dfa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dfd:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2e02:	06                   	push   es
    2e03:	57                   	push   di
    2e04:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e07:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2e0b:	ff 76 08             	push   WORD PTR [bp+0x8]
    2e0e:	ff 76 06             	push   WORD PTR [bp+0x6]
    2e11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e14:	06                   	push   es
    2e15:	57                   	push   di
    2e16:	9a 2f 28 61 2e       	call   0x2e61:0x282f
    2e1b:	c9                   	leave
    2e1c:	ca 08 00             	retf   0x8
    2e1f:	55                   	push   bp
    2e20:	89 e5                	mov    bp,sp
    2e22:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2e26:	74 08                	je     0x2e30
    2e28:	83 ec 08             	sub    sp,0x8
    2e2b:	9a e2 1f 10 2f       	call   0x2f10:0x1fe2
    2e30:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2e33:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2e36:	31 c0                	xor    ax,ax
    2e38:	50                   	push   ax
    2e39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e3c:	06                   	push   es
    2e3d:	57                   	push   di
    2e3e:	9a d5 27 ac 2e       	call   0x2eac:0x27d5
    2e43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e46:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    2e4a:	25 de ff             	and    ax,0xffde
    2e4d:	0d 50 00             	or     ax,0x50
    2e50:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    2e54:	ff 76 08             	push   WORD PTR [bp+0x8]
    2e57:	ff 76 06             	push   WORD PTR [bp+0x6]
    2e5a:	b0 01                	mov    al,0x1
    2e5c:	50                   	push   ax
    2e5d:	b8 f3 16             	mov    ax,0x16f3
    2e60:	ba 68 2e             	mov    dx,0x2e68
    2e63:	52                   	push   dx
    2e64:	50                   	push   ax
    2e65:	9a 0d 3f a0 2e       	call   0x2ea0:0x3f0d
    2e6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e6d:	26 89 85 ed 00       	mov    WORD PTR es:[di+0xed],ax
    2e72:	26 89 95 ef 00       	mov    WORD PTR es:[di+0xef],dx
    2e77:	26 c7 85 f1 00 ff 03 	mov    WORD PTR es:[di+0xf1],0x3ff
    2e7e:	b0 01                	mov    al,0x1
    2e80:	50                   	push   ax
    2e81:	b8 c9 03             	mov    ax,0x3c9
    2e84:	ba 8c 2e             	mov    dx,0x2e8c
    2e87:	52                   	push   dx
    2e88:	50                   	push   ax
    2e89:	9a 08 1d 45 2f       	call   0x2f45:0x1d08
    2e8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e91:	26 89 85 f3 00       	mov    WORD PTR es:[di+0xf3],ax
    2e96:	26 89 95 f5 00       	mov    WORD PTR es:[di+0xf5],dx
    2e9b:	06                   	push   es
    2e9c:	57                   	push   di
    2e9d:	9a 3a 2f 6f 2f       	call   0x2f6f:0x2f3a
    2ea2:	6a 00                	push   0x0
    2ea4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea7:	06                   	push   es
    2ea8:	57                   	push   di
    2ea9:	9a 3e 2c b8 2e       	call   0x2eb8:0x2c3e
    2eae:	6a 00                	push   0x0
    2eb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eb3:	06                   	push   es
    2eb4:	57                   	push   di
    2eb5:	9a 19 2c fc 34       	call   0x34fc:0x2c19
    2eba:	68 f1 00             	push   0xf1
    2ebd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec0:	06                   	push   es
    2ec1:	57                   	push   di
    2ec2:	9a bf 17 d1 2e       	call   0x2ed1:0x17bf
    2ec7:	6a 19                	push   0x19
    2ec9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ecc:	06                   	push   es
    2ecd:	57                   	push   di
    2ece:	9a e1 17 29 2f       	call   0x2f29:0x17e1
    2ed3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed6:	31 c0                	xor    ax,ax
    2ed8:	26 89 85 f7 00       	mov    WORD PTR es:[di+0xf7],ax
    2edd:	26 c6 85 05 01 00    	mov    BYTE PTR es:[di+0x105],0x0
    2ee3:	26 c6 85 06 01 01    	mov    BYTE PTR es:[di+0x106],0x1
    2ee9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2eed:	74 07                	je     0x2ef6
    2eef:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2ef3:	83 c4 06             	add    sp,0x6
    2ef6:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2ef9:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2efc:	c9                   	leave
    2efd:	ca 0a 00             	retf   0xa
    2f00:	55                   	push   bp
    2f01:	89 e5                	mov    bp,sp
    2f03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f06:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    2f0b:	06                   	push   es
    2f0c:	57                   	push   di
    2f0d:	9a 7f 1f 34 2f       	call   0x2f34:0x1f7f
    2f12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f15:	31 c0                	xor    ax,ax
    2f17:	26 89 85 ed 00       	mov    WORD PTR es:[di+0xed],ax
    2f1c:	26 89 85 ef 00       	mov    WORD PTR es:[di+0xef],ax
    2f21:	31 c0                	xor    ax,ax
    2f23:	50                   	push   ax
    2f24:	06                   	push   es
    2f25:	57                   	push   di
    2f26:	9a dc 6c af 2f       	call   0x2faf:0x6cdc
    2f2b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2f2f:	74 05                	je     0x2f36
    2f31:	9a 0f 20 30 39       	call   0x3930:0x200f
    2f36:	c9                   	leave
    2f37:	ca 06 00             	retf   0x6
    2f3a:	c8 3a 00 00          	enter  0x3a,0x0
    2f3e:	6a 14                	push   0x14
    2f40:	6a 12                	push   0x12
    2f42:	9a 6e 06 78 3c       	call   0x3c78:0x66e
    2f47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f4a:	26 89 85 f9 00       	mov    WORD PTR es:[di+0xf9],ax
    2f4f:	26 89 95 fb 00       	mov    WORD PTR es:[di+0xfb],dx
    2f54:	31 c0                	xor    ax,ax
    2f56:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2f59:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2f5d:	eb 03                	jmp    0x2f62
    2f5f:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    2f62:	ff 76 08             	push   WORD PTR [bp+0x8]
    2f65:	ff 76 06             	push   WORD PTR [bp+0x6]
    2f68:	b0 01                	mov    al,0x1
    2f6a:	50                   	push   ax
    2f6b:	b8 42 16             	mov    ax,0x1642
    2f6e:	ba 42 30             	mov    dx,0x3042
    2f71:	52                   	push   dx
    2f72:	50                   	push   ax
    2f73:	9a 27 1f 20 30       	call   0x3020:0x1f27
    2f78:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2f7b:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2f7e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2f81:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2f84:	26 88 85 9d 00       	mov    BYTE PTR es:[di+0x9d],al
    2f89:	8a 4e ff             	mov    cl,BYTE PTR [bp-0x1]
    2f8c:	80 f9 10             	cmp    cl,0x10
    2f8f:	73 0f                	jae    0x2fa0
    2f91:	b8 01 00             	mov    ax,0x1
    2f94:	d3 c0                	rol    ax,cl
    2f96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f99:	26 85 85 f1 00       	test   WORD PTR es:[di+0xf1],ax
    2f9e:	75 04                	jne    0x2fa4
    2fa0:	b0 00                	mov    al,0x0
    2fa2:	eb 02                	jmp    0x2fa6
    2fa4:	b0 01                	mov    al,0x1
    2fa6:	50                   	push   ax
    2fa7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2faa:	06                   	push   es
    2fab:	57                   	push   di
    2fac:	9a 77 1c bb 2f       	call   0x2fbb:0x1c77
    2fb1:	6a 01                	push   0x1
    2fb3:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2fb6:	06                   	push   es
    2fb7:	57                   	push   di
    2fb8:	9a b8 1c 38 31       	call   0x3138:0x1cb8
    2fbd:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2fc0:	6a 00                	push   0x0
    2fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc5:	26 ff b5 f9 00       	push   WORD PTR es:[di+0xf9]
    2fca:	26 ff b5 fb 00       	push   WORD PTR es:[di+0xfb]
    2fcf:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2fd2:	06                   	push   es
    2fd3:	57                   	push   di
    2fd4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2fd7:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    2fdb:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    2fdf:	8d 7e ce             	lea    di,[bp-0x32]
    2fe2:	16                   	push   ss
    2fe3:	57                   	push   di
    2fe4:	bf a0 0a             	mov    di,0xaa0
    2fe7:	1e                   	push   ds
    2fe8:	57                   	push   di
    2fe9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2fec:	98                   	cbw
    2fed:	8b f8                	mov    di,ax
    2fef:	c1 e7 02             	shl    di,0x2
    2ff2:	8b 85 26 0a          	mov    ax,WORD PTR [di+0xa26]
    2ff6:	8b 95 28 0a          	mov    dx,WORD PTR [di+0xa28]
    2ffa:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    2ffd:	89 56 c8             	mov    WORD PTR [bp-0x38],dx
    3000:	c6 46 ca 06          	mov    BYTE PTR [bp-0x36],0x6
    3004:	8d 7e c6             	lea    di,[bp-0x3a]
    3007:	16                   	push   ss
    3008:	57                   	push   di
    3009:	6a 00                	push   0x0
    300b:	9a a3 0f 20 31       	call   0x3120:0xfa3
    3010:	52                   	push   dx
    3011:	50                   	push   ax
    3012:	9a ff ff 00 00       	call   0x0:0xffff
    3017:	50                   	push   ax
    3018:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    301b:	06                   	push   es
    301c:	57                   	push   di
    301d:	9a 59 23 37 30       	call   0x3037:0x2359
    3022:	89 c7                	mov    di,ax
    3024:	8e c2                	mov    es,dx
    3026:	06                   	push   es
    3027:	57                   	push   di
    3028:	9a 04 61 fc 3e       	call   0x3efc:0x6104
    302d:	6a 02                	push   0x2
    302f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3032:	06                   	push   es
    3033:	57                   	push   di
    3034:	9a bf 23 0d 3d       	call   0x3d0d:0x23bf
    3039:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    303c:	06                   	push   es
    303d:	57                   	push   di
    303e:	b8 61 35             	mov    ax,0x3561
    3041:	ba 61 30             	mov    dx,0x3061
    3044:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3047:	26 89 45 7a          	mov    WORD PTR es:[di+0x7a],ax
    304b:	26 89 55 7c          	mov    WORD PTR es:[di+0x7c],dx
    304f:	26 8f 45 7e          	pop    WORD PTR es:[di+0x7e]
    3053:	26 8f 85 80 00       	pop    WORD PTR es:[di+0x80]
    3058:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    305b:	06                   	push   es
    305c:	57                   	push   di
    305d:	b8 7b 35             	mov    ax,0x357b
    3060:	ba c0 30             	mov    dx,0x30c0
    3063:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3066:	26 89 45 4a          	mov    WORD PTR es:[di+0x4a],ax
    306a:	26 89 55 4c          	mov    WORD PTR es:[di+0x4c],dx
    306e:	26 8f 45 4e          	pop    WORD PTR es:[di+0x4e]
    3072:	26 8f 45 50          	pop    WORD PTR es:[di+0x50]
    3076:	ff 76 08             	push   WORD PTR [bp+0x8]
    3079:	ff 76 06             	push   WORD PTR [bp+0x6]
    307c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    307f:	06                   	push   es
    3080:	57                   	push   di
    3081:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3084:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    3088:	8b 4e fa             	mov    cx,WORD PTR [bp-0x6]
    308b:	8b 5e fc             	mov    bx,WORD PTR [bp-0x4]
    308e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3091:	98                   	cbw
    3092:	c1 e0 02             	shl    ax,0x2
    3095:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3098:	03 f8                	add    di,ax
    309a:	26 89 8d 07 01       	mov    WORD PTR es:[di+0x107],cx
    309f:	26 89 9d 09 01       	mov    WORD PTR es:[di+0x109],bx
    30a4:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    30a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30aa:	26 03 85 f9 00       	add    ax,WORD PTR es:[di+0xf9]
    30af:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    30b2:	80 7e ff 09          	cmp    BYTE PTR [bp-0x1],0x9
    30b6:	74 03                	je     0x30bb
    30b8:	e9 a4 fe             	jmp    0x2f5f
    30bb:	06                   	push   es
    30bc:	57                   	push   di
    30bd:	9a fe 30 f7 31       	call   0x31f7:0x30fe
    30c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30c5:	26 c4 bd 0b 01       	les    di,DWORD PTR es:[di+0x10b]
    30ca:	26 8a 85 9e 00       	mov    al,BYTE PTR es:[di+0x9e]
    30cf:	0c 01                	or     al,0x1
    30d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30d4:	26 c4 bd 0b 01       	les    di,DWORD PTR es:[di+0x10b]
    30d9:	26 88 85 9e 00       	mov    BYTE PTR es:[di+0x9e],al
    30de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30e1:	26 c4 bd 0f 01       	les    di,DWORD PTR es:[di+0x10f]
    30e6:	26 8a 85 9e 00       	mov    al,BYTE PTR es:[di+0x9e]
    30eb:	0c 01                	or     al,0x1
    30ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30f0:	26 c4 bd 0f 01       	les    di,DWORD PTR es:[di+0x10f]
    30f5:	26 88 85 9e 00       	mov    BYTE PTR es:[di+0x9e],al
    30fa:	c9                   	leave
    30fb:	ca 04 00             	retf   0x4
    30fe:	c8 06 02 00          	enter  0x206,0x0
    3102:	c6 46 fd 00          	mov    BYTE PTR [bp-0x3],0x0
    3106:	eb 03                	jmp    0x310b
    3108:	fe 46 fd             	inc    BYTE PTR [bp-0x3]
    310b:	8d be fc fe          	lea    di,[bp-0x104]
    310f:	16                   	push   ss
    3110:	57                   	push   di
    3111:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    3114:	98                   	cbw
    3115:	8b f8                	mov    di,ax
    3117:	d1 e7                	shl    di,1
    3119:	ff b5 8c 0a          	push   WORD PTR [di+0xa8c]
    311d:	9a 2b 09 3a 37       	call   0x373a:0x92b
    3122:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    3125:	98                   	cbw
    3126:	c1 e0 02             	shl    ax,0x2
    3129:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    312c:	03 f8                	add    di,ax
    312e:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    3133:	06                   	push   es
    3134:	57                   	push   di
    3135:	9a 02 20 bc 31       	call   0x31bc:0x2002
    313a:	80 7e fd 09          	cmp    BYTE PTR [bp-0x3],0x9
    313e:	75 c8                	jne    0x3108
    3140:	c6 46 fd 00          	mov    BYTE PTR [bp-0x3],0x0
    3144:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3147:	26 c4 bd f3 00       	les    di,DWORD PTR es:[di+0xf3]
    314c:	06                   	push   es
    314d:	57                   	push   di
    314e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3151:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3155:	48                   	dec    ax
    3156:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3159:	31 c0                	xor    ax,ax
    315b:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    315e:	7f 71                	jg     0x31d1
    3160:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3163:	eb 03                	jmp    0x3168
    3165:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3168:	8d be fa fe          	lea    di,[bp-0x106]
    316c:	16                   	push   ss
    316d:	57                   	push   di
    316e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3171:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3174:	26 c4 bd f3 00       	les    di,DWORD PTR es:[di+0xf3]
    3179:	06                   	push   es
    317a:	57                   	push   di
    317b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    317e:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    3182:	83 c4 04             	add    sp,0x4
    3185:	80 be fa fe 00       	cmp    BYTE PTR [bp-0x106],0x0
    318a:	74 32                	je     0x31be
    318c:	8d be fa fd          	lea    di,[bp-0x206]
    3190:	16                   	push   ss
    3191:	57                   	push   di
    3192:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3195:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3198:	26 c4 bd f3 00       	les    di,DWORD PTR es:[di+0xf3]
    319d:	06                   	push   es
    319e:	57                   	push   di
    319f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31a2:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    31a6:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    31a9:	98                   	cbw
    31aa:	c1 e0 02             	shl    ax,0x2
    31ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31b0:	03 f8                	add    di,ax
    31b2:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    31b7:	06                   	push   es
    31b8:	57                   	push   di
    31b9:	9a 02 20 12 32       	call   0x3212:0x2002
    31be:	80 7e fd 09          	cmp    BYTE PTR [bp-0x3],0x9
    31c2:	75 02                	jne    0x31c6
    31c4:	eb 0b                	jmp    0x31d1
    31c6:	fe 46 fd             	inc    BYTE PTR [bp-0x3]
    31c9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    31cc:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    31cf:	75 94                	jne    0x3165
    31d1:	c9                   	leave
    31d2:	ca 04 00             	retf   0x4
    31d5:	55                   	push   bp
    31d6:	89 e5                	mov    bp,sp
    31d8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    31db:	ff 76 0a             	push   WORD PTR [bp+0xa]
    31de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e1:	26 c4 bd f3 00       	les    di,DWORD PTR es:[di+0xf3]
    31e6:	06                   	push   es
    31e7:	57                   	push   di
    31e8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31eb:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    31ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31f2:	06                   	push   es
    31f3:	57                   	push   di
    31f4:	9a fe 30 2e 32       	call   0x322e:0x30fe
    31f9:	c9                   	leave
    31fa:	ca 08 00             	retf   0x8
    31fd:	55                   	push   bp
    31fe:	89 e5                	mov    bp,sp
    3200:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3203:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3206:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3209:	50                   	push   ax
    320a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    320d:	06                   	push   es
    320e:	57                   	push   di
    320f:	9a 32 16 a6 32       	call   0x32a6:0x1632
    3214:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    3218:	75 2e                	jne    0x3248
    321a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    321d:	26 8b 85 ed 00       	mov    ax,WORD PTR es:[di+0xed]
    3222:	26 0b 85 ef 00       	or     ax,WORD PTR es:[di+0xef]
    3227:	74 1f                	je     0x3248
    3229:	06                   	push   es
    322a:	57                   	push   di
    322b:	9a 48 3c 46 32       	call   0x3246:0x3c48
    3230:	3b 56 0e             	cmp    dx,WORD PTR [bp+0xe]
    3233:	75 13                	jne    0x3248
    3235:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    3238:	75 0e                	jne    0x3248
    323a:	6a 00                	push   0x0
    323c:	6a 00                	push   0x0
    323e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3241:	06                   	push   es
    3242:	57                   	push   di
    3243:	9a 1b 3c c0 32       	call   0x32c0:0x3c1b
    3248:	c9                   	leave
    3249:	ca 0a 00             	retf   0xa
    324c:	c8 06 00 00          	enter  0x6,0x0
    3250:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3253:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3257:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    325a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    325e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3261:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3264:	26 89 85 f1 00       	mov    WORD PTR es:[di+0xf1],ax
    3269:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    326d:	eb 03                	jmp    0x3272
    326f:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    3272:	8a 4e ff             	mov    cl,BYTE PTR [bp-0x1]
    3275:	80 f9 10             	cmp    cl,0x10
    3278:	73 0f                	jae    0x3289
    327a:	b8 01 00             	mov    ax,0x1
    327d:	d3 c0                	rol    ax,cl
    327f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3282:	26 85 85 f1 00       	test   WORD PTR es:[di+0xf1],ax
    3287:	75 04                	jne    0x328d
    3289:	b0 00                	mov    al,0x0
    328b:	eb 02                	jmp    0x328f
    328d:	b0 01                	mov    al,0x1
    328f:	50                   	push   ax
    3290:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3293:	98                   	cbw
    3294:	c1 e0 02             	shl    ax,0x2
    3297:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    329a:	03 f8                	add    di,ax
    329c:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    32a1:	06                   	push   es
    32a2:	57                   	push   di
    32a3:	9a 77 1c ed 32       	call   0x32ed:0x1c77
    32a8:	80 7e ff 09          	cmp    BYTE PTR [bp-0x1],0x9
    32ac:	75 c1                	jne    0x326f
    32ae:	8d 7e fc             	lea    di,[bp-0x4]
    32b1:	16                   	push   ss
    32b2:	57                   	push   di
    32b3:	8d 7e fa             	lea    di,[bp-0x6]
    32b6:	16                   	push   ss
    32b7:	57                   	push   di
    32b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32bb:	06                   	push   es
    32bc:	57                   	push   di
    32bd:	9a ff 32 ce 34       	call   0x34ce:0x32ff
    32c2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    32c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32c8:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
    32cc:	75 09                	jne    0x32d7
    32ce:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    32d1:	26 3b 45 24          	cmp    ax,WORD PTR es:[di+0x24]
    32d5:	74 18                	je     0x32ef
    32d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32da:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    32de:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    32e2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    32e5:	ff 76 fa             	push   WORD PTR [bp-0x6]
    32e8:	06                   	push   es
    32e9:	57                   	push   di
    32ea:	9a 62 5c e4 34       	call   0x34e4:0x5c62
    32ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32f2:	06                   	push   es
    32f3:	57                   	push   di
    32f4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32f7:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    32fb:	c9                   	leave
    32fc:	ca 06 00             	retf   0x6
    32ff:	c8 0e 00 00          	enter  0xe,0x0
    3303:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3306:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    330b:	74 03                	je     0x3310
    330d:	e9 98 01             	jmp    0x34a8
    3310:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3313:	26 8b 85 07 01       	mov    ax,WORD PTR es:[di+0x107]
    3318:	26 0b 85 09 01       	or     ax,WORD PTR es:[di+0x109]
    331d:	75 03                	jne    0x3322
    331f:	e9 86 01             	jmp    0x34a8
    3322:	31 c0                	xor    ax,ax
    3324:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3327:	c6 46 fa 09          	mov    BYTE PTR [bp-0x6],0x9
    332b:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    332f:	eb 03                	jmp    0x3334
    3331:	fe 46 fb             	inc    BYTE PTR [bp-0x5]
    3334:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    3337:	98                   	cbw
    3338:	c1 e0 02             	shl    ax,0x2
    333b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    333e:	03 f8                	add    di,ax
    3340:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    3345:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    334a:	74 09                	je     0x3355
    334c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    334f:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    3352:	88 46 fa             	mov    BYTE PTR [bp-0x6],al
    3355:	80 7e fb 09          	cmp    BYTE PTR [bp-0x5],0x9
    3359:	75 d6                	jne    0x3331
    335b:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    335f:	75 03                	jne    0x3364
    3361:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3364:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3367:	26 8b 85 f9 00       	mov    ax,WORD PTR es:[di+0xf9]
    336c:	48                   	dec    ax
    336d:	f7 66 fe             	mul    WORD PTR [bp-0x2]
    3370:	40                   	inc    ax
    3371:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3374:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3377:	26 8b 05             	mov    ax,WORD PTR es:[di]
    337a:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    337d:	7d 06                	jge    0x3385
    337f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3382:	26 89 05             	mov    WORD PTR es:[di],ax
    3385:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3388:	26 8b 05             	mov    ax,WORD PTR es:[di]
    338b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    338e:	26 3b 85 fb 00       	cmp    ax,WORD PTR es:[di+0xfb]
    3393:	7d 0b                	jge    0x33a0
    3395:	26 8b 85 fb 00       	mov    ax,WORD PTR es:[di+0xfb]
    339a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    339d:	26 89 05             	mov    WORD PTR es:[di],ax
    33a0:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    33a3:	26 8b 05             	mov    ax,WORD PTR es:[di]
    33a6:	48                   	dec    ax
    33a7:	99                   	cwd
    33a8:	f7 7e fe             	idiv   WORD PTR [bp-0x2]
    33ab:	40                   	inc    ax
    33ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33af:	26 89 85 f7 00       	mov    WORD PTR es:[di+0xf7],ax
    33b4:	26 8b 85 f7 00       	mov    ax,WORD PTR es:[di+0xf7]
    33b9:	48                   	dec    ax
    33ba:	f7 66 fe             	mul    WORD PTR [bp-0x2]
    33bd:	40                   	inc    ax
    33be:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    33c1:	26 80 7d 2d 00       	cmp    BYTE PTR es:[di+0x2d],0x0
    33c6:	75 09                	jne    0x33d1
    33c8:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    33cb:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    33ce:	26 89 05             	mov    WORD PTR es:[di],ax
    33d1:	31 c0                	xor    ax,ax
    33d3:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    33d6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    33d9:	26 8b 05             	mov    ax,WORD PTR es:[di]
    33dc:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    33df:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    33e2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    33e5:	99                   	cwd
    33e6:	b9 02 00             	mov    cx,0x2
    33e9:	f7 f9                	idiv   cx
    33eb:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    33ee:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    33f2:	eb 03                	jmp    0x33f7
    33f4:	fe 46 fb             	inc    BYTE PTR [bp-0x5]
    33f7:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    33fa:	98                   	cbw
    33fb:	c1 e0 02             	shl    ax,0x2
    33fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3401:	03 f8                	add    di,ax
    3403:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    3408:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    340d:	74 65                	je     0x3474
    340f:	31 c0                	xor    ax,ax
    3411:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3414:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    3418:	74 17                	je     0x3431
    341a:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    341d:	29 46 f6             	sub    WORD PTR [bp-0xa],ax
    3420:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    3424:	7d 0b                	jge    0x3431
    3426:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3429:	01 46 f6             	add    WORD PTR [bp-0xa],ax
    342c:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    3431:	ff 76 f2             	push   WORD PTR [bp-0xe]
    3434:	6a 00                	push   0x0
    3436:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3439:	26 8b 85 f7 00       	mov    ax,WORD PTR es:[di+0xf7]
    343e:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    3441:	50                   	push   ax
    3442:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    3446:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    3449:	98                   	cbw
    344a:	c1 e0 02             	shl    ax,0x2
    344d:	03 f8                	add    di,ax
    344f:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    3454:	06                   	push   es
    3455:	57                   	push   di
    3456:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3459:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    345d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3460:	26 8b 85 f7 00       	mov    ax,WORD PTR es:[di+0xf7]
    3465:	48                   	dec    ax
    3466:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    3469:	01 46 f2             	add    WORD PTR [bp-0xe],ax
    346c:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    346f:	88 46 fa             	mov    BYTE PTR [bp-0x6],al
    3472:	eb 2b                	jmp    0x349f
    3474:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3477:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    347b:	40                   	inc    ax
    347c:	50                   	push   ax
    347d:	6a 00                	push   0x0
    347f:	26 ff b5 f7 00       	push   WORD PTR es:[di+0xf7]
    3484:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    3488:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    348b:	98                   	cbw
    348c:	c1 e0 02             	shl    ax,0x2
    348f:	03 f8                	add    di,ax
    3491:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    3496:	06                   	push   es
    3497:	57                   	push   di
    3498:	26 c4 3d             	les    di,DWORD PTR es:[di]
    349b:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    349f:	80 7e fb 09          	cmp    BYTE PTR [bp-0x5],0x9
    34a3:	74 03                	je     0x34a8
    34a5:	e9 4c ff             	jmp    0x33f4
    34a8:	c9                   	leave
    34a9:	ca 0c 00             	retf   0xc
    34ac:	c8 04 00 00          	enter  0x4,0x0
    34b0:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    34b3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    34b6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    34b9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    34bc:	8d 7e fe             	lea    di,[bp-0x2]
    34bf:	16                   	push   ss
    34c0:	57                   	push   di
    34c1:	8d 7e fc             	lea    di,[bp-0x4]
    34c4:	16                   	push   ss
    34c5:	57                   	push   di
    34c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c9:	06                   	push   es
    34ca:	57                   	push   di
    34cb:	9a ff 32 21 35       	call   0x3521:0x32ff
    34d0:	ff 76 10             	push   WORD PTR [bp+0x10]
    34d3:	ff 76 0e             	push   WORD PTR [bp+0xe]
    34d6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    34d9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    34dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34df:	06                   	push   es
    34e0:	57                   	push   di
    34e1:	9a 62 5c 4e 35       	call   0x354e:0x5c62
    34e6:	c9                   	leave
    34e7:	ca 0c 00             	retf   0xc
    34ea:	c8 04 00 00          	enter  0x4,0x0
    34ee:	ff 76 0c             	push   WORD PTR [bp+0xc]
    34f1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    34f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34f7:	06                   	push   es
    34f8:	57                   	push   di
    34f9:	9a f3 28 5d 3d       	call   0x3d5d:0x28f3
    34fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3501:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3505:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3508:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    350c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    350f:	8d 7e fe             	lea    di,[bp-0x2]
    3512:	16                   	push   ss
    3513:	57                   	push   di
    3514:	8d 7e fc             	lea    di,[bp-0x4]
    3517:	16                   	push   ss
    3518:	57                   	push   di
    3519:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    351c:	06                   	push   es
    351d:	57                   	push   di
    351e:	9a ff 32 75 35       	call   0x3575:0x32ff
    3523:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3526:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3529:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
    352d:	75 09                	jne    0x3538
    352f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3532:	26 3b 45 24          	cmp    ax,WORD PTR es:[di+0x24]
    3536:	74 18                	je     0x3550
    3538:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    353b:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    353f:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    3543:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3546:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3549:	06                   	push   es
    354a:	57                   	push   di
    354b:	9a 62 5c a7 35       	call   0x35a7:0x5c62
    3550:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3553:	31 c0                	xor    ax,ax
    3555:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    3559:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    355d:	c9                   	leave
    355e:	ca 08 00             	retf   0x8
    3561:	55                   	push   bp
    3562:	89 e5                	mov    bp,sp
    3564:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3567:	26 8a 85 9d 00       	mov    al,BYTE PTR es:[di+0x9d]
    356c:	50                   	push   ax
    356d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3570:	06                   	push   es
    3571:	57                   	push   di
    3572:	9a 5c 36 68 36       	call   0x3668:0x365c
    3577:	c9                   	leave
    3578:	ca 08 00             	retf   0x8
    357b:	c8 06 00 00          	enter  0x6,0x0
    357f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3582:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    3587:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    358a:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    358d:	26 8a 85 9d 00       	mov    al,BYTE PTR es:[di+0x9d]
    3592:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3595:	26 88 85 05 01       	mov    BYTE PTR es:[di+0x105],al
    359a:	26 80 bd a4 00 00    	cmp    BYTE PTR es:[di+0xa4],0x0
    35a0:	74 45                	je     0x35e7
    35a2:	06                   	push   es
    35a3:	57                   	push   di
    35a4:	9a b9 62 bc 35       	call   0x35bc:0x62b9
    35a9:	50                   	push   ax
    35aa:	9a da 35 00 00       	call   0x0:0x35da
    35af:	5a                   	pop    dx
    35b0:	3b c2                	cmp    ax,dx
    35b2:	74 33                	je     0x35e7
    35b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35b7:	06                   	push   es
    35b8:	57                   	push   di
    35b9:	9a c4 61 d6 35       	call   0x35d6:0x61c4
    35be:	08 c0                	or     al,al
    35c0:	74 25                	je     0x35e7
    35c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35c5:	06                   	push   es
    35c6:	57                   	push   di
    35c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35ca:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    35ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35d1:	06                   	push   es
    35d2:	57                   	push   di
    35d3:	9a b9 62 f7 35       	call   0x35f7:0x62b9
    35d8:	50                   	push   ax
    35d9:	9a fb 35 00 00       	call   0x0:0x35fb
    35de:	5a                   	pop    dx
    35df:	3b c2                	cmp    ax,dx
    35e1:	74 02                	je     0x35e5
    35e3:	eb 5f                	jmp    0x3644
    35e5:	eb 5d                	jmp    0x3644
    35e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35ea:	26 80 bd a4 00 00    	cmp    BYTE PTR es:[di+0xa4],0x0
    35f0:	74 52                	je     0x3644
    35f2:	06                   	push   es
    35f3:	57                   	push   di
    35f4:	9a b9 62 d3 39       	call   0x39d3:0x62b9
    35f9:	50                   	push   ax
    35fa:	9a 87 3e 00 00       	call   0x0:0x3e87
    35ff:	5a                   	pop    dx
    3600:	3b c2                	cmp    ax,dx
    3602:	75 40                	jne    0x3644
    3604:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3607:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    360a:	26 3a 85 05 01       	cmp    al,BYTE PTR es:[di+0x105]
    360f:	74 33                	je     0x3644
    3611:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3614:	98                   	cbw
    3615:	c1 e0 02             	shl    ax,0x2
    3618:	03 f8                	add    di,ax
    361a:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    361f:	06                   	push   es
    3620:	57                   	push   di
    3621:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3624:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3628:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    362b:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    3630:	98                   	cbw
    3631:	c1 e0 02             	shl    ax,0x2
    3634:	03 f8                	add    di,ax
    3636:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    363b:	06                   	push   es
    363c:	57                   	push   di
    363d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3640:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3644:	c9                   	leave
    3645:	ca 10 00             	retf   0x10
    3648:	cf                   	iret
    3649:	36 b5 36             	ss mov ch,0x36
    364c:	c2 36 db             	ret    0xdb36
    364f:	36 e7 36             	ss out 0x36,ax
    3652:	23 37                	and    si,WORD PTR [bx]
    3654:	f3 36 0b 37          	repz or si,WORD PTR ss:[bx]
    3658:	ff 36 17 37          	push   WORD PTR ds:0x3717
    365c:	c8 04 01 00          	enter  0x104,0x0
    3660:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3663:	06                   	push   es
    3664:	57                   	push   di
    3665:	9a 48 3c 79 36       	call   0x3679:0x3c48
    366a:	09 d0                	or     ax,dx
    366c:	75 03                	jne    0x3671
    366e:	e9 e7 00             	jmp    0x3758
    3671:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3674:	06                   	push   es
    3675:	57                   	push   di
    3676:	9a 48 3c 91 36       	call   0x3691:0x3c48
    367b:	89 c7                	mov    di,ax
    367d:	8e c2                	mov    es,dx
    367f:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    3684:	75 03                	jne    0x3689
    3686:	e9 cf 00             	jmp    0x3758
    3689:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    368c:	06                   	push   es
    368d:	57                   	push   di
    368e:	9a 48 3c e3 3b       	call   0x3be3:0x3c48
    3693:	89 c7                	mov    di,ax
    3695:	8e c2                	mov    es,dx
    3697:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    369b:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    369e:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    36a1:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    36a4:	3c 09                	cmp    al,0x9
    36a6:	76 03                	jbe    0x36ab
    36a8:	e9 ad 00             	jmp    0x3758
    36ab:	98                   	cbw
    36ac:	89 c3                	mov    bx,ax
    36ae:	d1 e3                	shl    bx,1
    36b0:	2e ff a7 48 36       	jmp    WORD PTR cs:[bx+0x3648]
    36b5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    36b8:	06                   	push   es
    36b9:	57                   	push   di
    36ba:	9a ff 4e ca 36       	call   0x36ca:0x4eff
    36bf:	e9 96 00             	jmp    0x3758
    36c2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    36c5:	06                   	push   es
    36c6:	57                   	push   di
    36c7:	9a ec 4e d7 36       	call   0x36d7:0x4eec
    36cc:	e9 89 00             	jmp    0x3758
    36cf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    36d2:	06                   	push   es
    36d3:	57                   	push   di
    36d4:	9a cd 4c e3 36       	call   0x36e3:0x4ccd
    36d9:	eb 7d                	jmp    0x3758
    36db:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    36de:	06                   	push   es
    36df:	57                   	push   di
    36e0:	9a 4a 4d ef 36       	call   0x36ef:0x4d4a
    36e5:	eb 71                	jmp    0x3758
    36e7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    36ea:	06                   	push   es
    36eb:	57                   	push   di
    36ec:	9a 99 4f fb 36       	call   0x36fb:0x4f99
    36f1:	eb 65                	jmp    0x3758
    36f3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    36f6:	06                   	push   es
    36f7:	57                   	push   di
    36f8:	9a 3c 53 07 37       	call   0x3707:0x533c
    36fd:	eb 59                	jmp    0x3758
    36ff:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3702:	06                   	push   es
    3703:	57                   	push   di
    3704:	9a 8b 55 13 37       	call   0x3713:0x558b
    3709:	eb 4d                	jmp    0x3758
    370b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    370e:	06                   	push   es
    370f:	57                   	push   di
    3710:	9a a0 54 1f 37       	call   0x371f:0x54a0
    3715:	eb 41                	jmp    0x3758
    3717:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    371a:	06                   	push   es
    371b:	57                   	push   di
    371c:	9a 12 4f 56 37       	call   0x3756:0x4f12
    3721:	eb 35                	jmp    0x3758
    3723:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3726:	26 80 bd 06 01 00    	cmp    BYTE PTR es:[di+0x106],0x0
    372c:	74 20                	je     0x374e
    372e:	8d be fc fe          	lea    di,[bp-0x104]
    3732:	16                   	push   ss
    3733:	57                   	push   di
    3734:	68 4d f2             	push   0xf24d
    3737:	9a 2b 09 ff ff       	call   0xffff:0x92b
    373c:	6a 03                	push   0x3
    373e:	6a 0c                	push   0xc
    3740:	6a 00                	push   0x0
    3742:	6a 00                	push   0x0
    3744:	9a 8a 38 ff ff       	call   0xffff:0x388a
    3749:	3d 02 00             	cmp    ax,0x2
    374c:	74 0a                	je     0x3758
    374e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3751:	06                   	push   es
    3752:	57                   	push   di
    3753:	9a 22 56 73 39       	call   0x3973:0x5622
    3758:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    375b:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3760:	75 22                	jne    0x3784
    3762:	26 8b 85 ff 00       	mov    ax,WORD PTR es:[di+0xff]
    3767:	09 c0                	or     ax,ax
    3769:	74 19                	je     0x3784
    376b:	ff 76 08             	push   WORD PTR [bp+0x8]
    376e:	ff 76 06             	push   WORD PTR [bp+0x6]
    3771:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3774:	50                   	push   ax
    3775:	26 ff b5 03 01       	push   WORD PTR es:[di+0x103]
    377a:	26 ff b5 01 01       	push   WORD PTR es:[di+0x101]
    377f:	26 ff 9d fd 00       	call   DWORD PTR es:[di+0xfd]
    3784:	c9                   	leave
    3785:	ca 06 00             	retf   0x6
    3788:	55                   	push   bp
    3789:	89 e5                	mov    bp,sp
    378b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    378e:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    3793:	98                   	cbw
    3794:	c1 e0 02             	shl    ax,0x2
    3797:	03 f8                	add    di,ax
    3799:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    379e:	06                   	push   es
    379f:	57                   	push   di
    37a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    37a3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    37a7:	c9                   	leave
    37a8:	ca 08 00             	retf   0x8
    37ab:	55                   	push   bp
    37ac:	89 e5                	mov    bp,sp
    37ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37b1:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    37b6:	98                   	cbw
    37b7:	c1 e0 02             	shl    ax,0x2
    37ba:	03 f8                	add    di,ax
    37bc:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    37c1:	06                   	push   es
    37c2:	57                   	push   di
    37c3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    37c6:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    37ca:	c9                   	leave
    37cb:	ca 08 00             	retf   0x8
    37ce:	c8 02 00 00          	enter  0x2,0x0
    37d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37d5:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    37da:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    37dd:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    37e0:	26 8b 05             	mov    ax,WORD PTR es:[di]
    37e3:	3d 27 00             	cmp    ax,0x27
    37e6:	74 03                	je     0x37eb
    37e8:	e9 82 00             	jmp    0x386d
    37eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37ee:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    37f3:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    37f6:	80 7e ff 09          	cmp    BYTE PTR [bp-0x1],0x9
    37fa:	7d 08                	jge    0x3804
    37fc:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    37ff:	fe c0                	inc    al
    3801:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3804:	80 7e ff 09          	cmp    BYTE PTR [bp-0x1],0x9
    3808:	74 18                	je     0x3822
    380a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    380d:	98                   	cbw
    380e:	c1 e0 02             	shl    ax,0x2
    3811:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3814:	03 f8                	add    di,ax
    3816:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    381b:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    3820:	74 d4                	je     0x37f6
    3822:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3825:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3828:	26 3a 85 05 01       	cmp    al,BYTE PTR es:[di+0x105]
    382d:	74 3b                	je     0x386a
    382f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3832:	26 88 85 05 01       	mov    BYTE PTR es:[di+0x105],al
    3837:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    383a:	98                   	cbw
    383b:	c1 e0 02             	shl    ax,0x2
    383e:	03 f8                	add    di,ax
    3840:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    3845:	06                   	push   es
    3846:	57                   	push   di
    3847:	26 c4 3d             	les    di,DWORD PTR es:[di]
    384a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    384e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3851:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    3856:	98                   	cbw
    3857:	c1 e0 02             	shl    ax,0x2
    385a:	03 f8                	add    di,ax
    385c:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    3861:	06                   	push   es
    3862:	57                   	push   di
    3863:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3866:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    386a:	e9 c5 00             	jmp    0x3932
    386d:	3d 25 00             	cmp    ax,0x25
    3870:	74 03                	je     0x3875
    3872:	e9 81 00             	jmp    0x38f6
    3875:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3878:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    387d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3880:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3884:	7e 08                	jle    0x388e
    3886:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3889:	fe c8                	dec    al
    388b:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    388e:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3892:	74 18                	je     0x38ac
    3894:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3897:	98                   	cbw
    3898:	c1 e0 02             	shl    ax,0x2
    389b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    389e:	03 f8                	add    di,ax
    38a0:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    38a5:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    38aa:	74 d4                	je     0x3880
    38ac:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    38af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38b2:	26 3a 85 05 01       	cmp    al,BYTE PTR es:[di+0x105]
    38b7:	74 3b                	je     0x38f4
    38b9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    38bc:	26 88 85 05 01       	mov    BYTE PTR es:[di+0x105],al
    38c1:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    38c4:	98                   	cbw
    38c5:	c1 e0 02             	shl    ax,0x2
    38c8:	03 f8                	add    di,ax
    38ca:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    38cf:	06                   	push   es
    38d0:	57                   	push   di
    38d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    38d4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    38d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38db:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    38e0:	98                   	cbw
    38e1:	c1 e0 02             	shl    ax,0x2
    38e4:	03 f8                	add    di,ax
    38e6:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    38eb:	06                   	push   es
    38ec:	57                   	push   di
    38ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    38f0:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    38f4:	eb 3c                	jmp    0x3932
    38f6:	3d 20 00             	cmp    ax,0x20
    38f9:	75 37                	jne    0x3932
    38fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38fe:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    3903:	98                   	cbw
    3904:	c1 e0 02             	shl    ax,0x2
    3907:	03 f8                	add    di,ax
    3909:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    390e:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    3913:	74 1d                	je     0x3932
    3915:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3918:	26 8a 85 05 01       	mov    al,BYTE PTR es:[di+0x105]
    391d:	98                   	cbw
    391e:	c1 e0 02             	shl    ax,0x2
    3921:	03 f8                	add    di,ax
    3923:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    3928:	06                   	push   es
    3929:	57                   	push   di
    392a:	b8 fe ff             	mov    ax,0xfffe
    392d:	9a 6a 20 79 3b       	call   0x3b79:0x206a
    3932:	c9                   	leave
    3933:	ca 0a 00             	retf   0xa
    3936:	55                   	push   bp
    3937:	89 e5                	mov    bp,sp
    3939:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    393c:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    3942:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    3948:	c9                   	leave
    3949:	ca 08 00             	retf   0x8
    394c:	c8 02 00 00          	enter  0x2,0x0
    3950:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3953:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    3958:	74 26                	je     0x3980
    395a:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    395f:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    3964:	74 1a                	je     0x3980
    3966:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3969:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    396e:	06                   	push   es
    396f:	57                   	push   di
    3970:	9a fa 76 ac 39       	call   0x39ac:0x76fa
    3975:	89 c7                	mov    di,ax
    3977:	8e c2                	mov    es,dx
    3979:	26 80 7d 38 00       	cmp    BYTE PTR es:[di+0x38],0x0
    397e:	74 04                	je     0x3984
    3980:	b0 00                	mov    al,0x0
    3982:	eb 02                	jmp    0x3986
    3984:	b0 01                	mov    al,0x1
    3986:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3989:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    398c:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    3991:	74 26                	je     0x39b9
    3993:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3998:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    399d:	74 1a                	je     0x39b9
    399f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39a2:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    39a7:	06                   	push   es
    39a8:	57                   	push   di
    39a9:	9a fa 76 31 3a       	call   0x3a31:0x76fa
    39ae:	89 c7                	mov    di,ax
    39b0:	8e c2                	mov    es,dx
    39b2:	26 80 7d 39 00       	cmp    BYTE PTR es:[di+0x39],0x0
    39b7:	74 04                	je     0x39bd
    39b9:	b0 00                	mov    al,0x0
    39bb:	eb 02                	jmp    0x39bf
    39bd:	b0 01                	mov    al,0x1
    39bf:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    39c2:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    39c5:	50                   	push   ax
    39c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39c9:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    39ce:	06                   	push   es
    39cf:	57                   	push   di
    39d0:	9a b8 1c e6 39       	call   0x39e6:0x1cb8
    39d5:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    39d8:	50                   	push   ax
    39d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39dc:	26 c4 bd 0b 01       	les    di,DWORD PTR es:[di+0x10b]
    39e1:	06                   	push   es
    39e2:	57                   	push   di
    39e3:	9a b8 1c f9 39       	call   0x39f9:0x1cb8
    39e8:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    39eb:	50                   	push   ax
    39ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39ef:	26 c4 bd 0f 01       	les    di,DWORD PTR es:[di+0x10f]
    39f4:	06                   	push   es
    39f5:	57                   	push   di
    39f6:	9a b8 1c 0c 3a       	call   0x3a0c:0x1cb8
    39fb:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    39fe:	50                   	push   ax
    39ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a02:	26 c4 bd 13 01       	les    di,DWORD PTR es:[di+0x113]
    3a07:	06                   	push   es
    3a08:	57                   	push   di
    3a09:	9a b8 1c 86 3a       	call   0x3a86:0x1cb8
    3a0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a11:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    3a16:	74 5a                	je     0x3a72
    3a18:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3a1d:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    3a22:	74 4e                	je     0x3a72
    3a24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a27:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3a2c:	06                   	push   es
    3a2d:	57                   	push   di
    3a2e:	9a fa 76 4b 3a       	call   0x3a4b:0x76fa
    3a33:	89 c7                	mov    di,ax
    3a35:	8e c2                	mov    es,dx
    3a37:	26 80 7d 3d 00       	cmp    BYTE PTR es:[di+0x3d],0x0
    3a3c:	74 34                	je     0x3a72
    3a3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a41:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3a46:	06                   	push   es
    3a47:	57                   	push   di
    3a48:	9a fa 76 65 3a       	call   0x3a65:0x76fa
    3a4d:	89 c7                	mov    di,ax
    3a4f:	8e c2                	mov    es,dx
    3a51:	26 80 7d 38 00       	cmp    BYTE PTR es:[di+0x38],0x0
    3a56:	74 1e                	je     0x3a76
    3a58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a5b:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3a60:	06                   	push   es
    3a61:	57                   	push   di
    3a62:	9a fa 76 b3 3a       	call   0x3ab3:0x76fa
    3a67:	89 c7                	mov    di,ax
    3a69:	8e c2                	mov    es,dx
    3a6b:	26 80 7d 39 00       	cmp    BYTE PTR es:[di+0x39],0x0
    3a70:	74 04                	je     0x3a76
    3a72:	b0 00                	mov    al,0x0
    3a74:	eb 02                	jmp    0x3a78
    3a76:	b0 01                	mov    al,0x1
    3a78:	50                   	push   ax
    3a79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a7c:	26 c4 bd 1b 01       	les    di,DWORD PTR es:[di+0x11b]
    3a81:	06                   	push   es
    3a82:	57                   	push   di
    3a83:	9a b8 1c da 3a       	call   0x3ada:0x1cb8
    3a88:	c9                   	leave
    3a89:	ca 04 00             	retf   0x4
    3a8c:	c8 02 00 00          	enter  0x2,0x0
    3a90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a93:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    3a98:	74 26                	je     0x3ac0
    3a9a:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3a9f:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    3aa4:	74 1a                	je     0x3ac0
    3aa6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3aa9:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3aae:	06                   	push   es
    3aaf:	57                   	push   di
    3ab0:	9a fa 76 6a 3b       	call   0x3b6a:0x76fa
    3ab5:	89 c7                	mov    di,ax
    3ab7:	8e c2                	mov    es,dx
    3ab9:	26 80 7d 3d 00       	cmp    BYTE PTR es:[di+0x3d],0x0
    3abe:	75 04                	jne    0x3ac4
    3ac0:	b0 00                	mov    al,0x0
    3ac2:	eb 02                	jmp    0x3ac6
    3ac4:	b0 01                	mov    al,0x1
    3ac6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3ac9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3acc:	50                   	push   ax
    3acd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ad0:	26 c4 bd 17 01       	les    di,DWORD PTR es:[di+0x117]
    3ad5:	06                   	push   es
    3ad6:	57                   	push   di
    3ad7:	9a b8 1c 05 3b       	call   0x3b05:0x1cb8
    3adc:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3ae0:	74 0f                	je     0x3af1
    3ae2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ae5:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3aea:	26 80 7d 12 00       	cmp    BYTE PTR es:[di+0x12],0x0
    3aef:	74 04                	je     0x3af5
    3af1:	b0 00                	mov    al,0x0
    3af3:	eb 02                	jmp    0x3af7
    3af5:	b0 01                	mov    al,0x1
    3af7:	50                   	push   ax
    3af8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3afb:	26 c4 bd 1f 01       	les    di,DWORD PTR es:[di+0x11f]
    3b00:	06                   	push   es
    3b01:	57                   	push   di
    3b02:	9a b8 1c 30 3b       	call   0x3b30:0x1cb8
    3b07:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3b0b:	74 0f                	je     0x3b1c
    3b0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b10:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3b15:	26 80 7d 12 00       	cmp    BYTE PTR es:[di+0x12],0x0
    3b1a:	75 04                	jne    0x3b20
    3b1c:	b0 00                	mov    al,0x0
    3b1e:	eb 02                	jmp    0x3b22
    3b20:	b0 01                	mov    al,0x1
    3b22:	50                   	push   ax
    3b23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b26:	26 c4 bd 23 01       	les    di,DWORD PTR es:[di+0x123]
    3b2b:	06                   	push   es
    3b2c:	57                   	push   di
    3b2d:	9a b8 1c 5b 3b       	call   0x3b5b:0x1cb8
    3b32:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3b36:	74 0f                	je     0x3b47
    3b38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b3b:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3b40:	26 80 7d 12 00       	cmp    BYTE PTR es:[di+0x12],0x0
    3b45:	75 04                	jne    0x3b4b
    3b47:	b0 00                	mov    al,0x0
    3b49:	eb 02                	jmp    0x3b4d
    3b4b:	b0 01                	mov    al,0x1
    3b4d:	50                   	push   ax
    3b4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b51:	26 c4 bd 27 01       	les    di,DWORD PTR es:[di+0x127]
    3b56:	06                   	push   es
    3b57:	57                   	push   di
    3b58:	9a b8 1c 90 3b       	call   0x3b90:0x1cb8
    3b5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b60:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3b65:	06                   	push   es
    3b66:	57                   	push   di
    3b67:	9a fa 76 31 3c       	call   0x3c31:0x76fa
    3b6c:	52                   	push   dx
    3b6d:	50                   	push   ax
    3b6e:	bf cb 03             	mov    di,0x3cb
    3b71:	b8 ff ff             	mov    ax,0xffff
    3b74:	50                   	push   ax
    3b75:	57                   	push   di
    3b76:	9a 55 22 00 3d       	call   0x3d00:0x2255
    3b7b:	08 c0                	or     al,al
    3b7d:	b0 00                	mov    al,0x0
    3b7f:	75 01                	jne    0x3b82
    3b81:	40                   	inc    ax
    3b82:	50                   	push   ax
    3b83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b86:	26 c4 bd 2b 01       	les    di,DWORD PTR es:[di+0x12b]
    3b8b:	06                   	push   es
    3b8c:	57                   	push   di
    3b8d:	9a b8 1c d1 3b       	call   0x3bd1:0x1cb8
    3b92:	c9                   	leave
    3b93:	ca 04 00             	retf   0x4
    3b96:	c8 02 00 00          	enter  0x2,0x0
    3b9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b9d:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    3ba2:	74 0c                	je     0x3bb0
    3ba4:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3ba9:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    3bae:	75 2b                	jne    0x3bdb
    3bb0:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    3bb4:	eb 03                	jmp    0x3bb9
    3bb6:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    3bb9:	6a 00                	push   0x0
    3bbb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3bbe:	98                   	cbw
    3bbf:	c1 e0 02             	shl    ax,0x2
    3bc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bc5:	03 f8                	add    di,ax
    3bc7:	26 c4 bd 07 01       	les    di,DWORD PTR es:[di+0x107]
    3bcc:	06                   	push   es
    3bcd:	57                   	push   di
    3bce:	9a b8 1c 04 3c       	call   0x3c04:0x1cb8
    3bd3:	80 7e ff 09          	cmp    BYTE PTR [bp-0x1],0x9
    3bd7:	75 dd                	jne    0x3bb6
    3bd9:	eb 14                	jmp    0x3bef
    3bdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bde:	06                   	push   es
    3bdf:	57                   	push   di
    3be0:	9a 4c 39 ed 3b       	call   0x3bed:0x394c
    3be5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3be8:	06                   	push   es
    3be9:	57                   	push   di
    3bea:	9a 8c 3a 15 3c       	call   0x3c15:0x3a8c
    3bef:	c9                   	leave
    3bf0:	ca 04 00             	retf   0x4
    3bf3:	55                   	push   bp
    3bf4:	89 e5                	mov    bp,sp
    3bf6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3bf9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3bfc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bff:	06                   	push   es
    3c00:	57                   	push   di
    3c01:	9a b3 56 ca 3c       	call   0x3cca:0x56b3
    3c06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c09:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    3c0e:	75 07                	jne    0x3c17
    3c10:	06                   	push   es
    3c11:	57                   	push   di
    3c12:	9a 96 3b 42 3c       	call   0x3c42:0x3b96
    3c17:	c9                   	leave
    3c18:	ca 08 00             	retf   0x8
    3c1b:	55                   	push   bp
    3c1c:	89 e5                	mov    bp,sp
    3c1e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3c21:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3c24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c27:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3c2c:	06                   	push   es
    3c2d:	57                   	push   di
    3c2e:	9a 31 77 29 3f       	call   0x3f29:0x7731
    3c33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c36:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    3c3b:	75 07                	jne    0x3c44
    3c3d:	06                   	push   es
    3c3e:	57                   	push   di
    3c3f:	9a 96 3b 9d 3c       	call   0x3c9d:0x3b96
    3c44:	c9                   	leave
    3c45:	ca 08 00             	retf   0x8
    3c48:	c8 04 00 00          	enter  0x4,0x0
    3c4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c4f:	26 c4 bd ed 00       	les    di,DWORD PTR es:[di+0xed]
    3c54:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3c58:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    3c5c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3c5f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3c62:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3c65:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3c68:	c9                   	leave
    3c69:	ca 04 00             	retf   0x4
    3c6c:	c8 04 00 00          	enter  0x4,0x0
    3c70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c73:	06                   	push   es
    3c74:	57                   	push   di
    3c75:	9a f4 4f ba 3e       	call   0x3eba:0x4ff4
    3c7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c7d:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3c81:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3c84:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    3c88:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3c8b:	8d 7e fe             	lea    di,[bp-0x2]
    3c8e:	16                   	push   ss
    3c8f:	57                   	push   di
    3c90:	8d 7e fc             	lea    di,[bp-0x4]
    3c93:	16                   	push   ss
    3c94:	57                   	push   di
    3c95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c98:	06                   	push   es
    3c99:	57                   	push   di
    3c9a:	9a ff 32 d4 3c       	call   0x3cd4:0x32ff
    3c9f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3ca2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ca5:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
    3ca9:	75 09                	jne    0x3cb4
    3cab:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3cae:	26 3b 45 24          	cmp    ax,WORD PTR es:[di+0x24]
    3cb2:	74 18                	je     0x3ccc
    3cb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cb7:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    3cbb:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    3cbf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3cc2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3cc5:	06                   	push   es
    3cc6:	57                   	push   di
    3cc7:	9a 62 5c 20 3e       	call   0x3e20:0x5c62
    3ccc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ccf:	06                   	push   es
    3cd0:	57                   	push   di
    3cd1:	9a fe 30 de 3c       	call   0x3cde:0x30fe
    3cd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cd9:	06                   	push   es
    3cda:	57                   	push   di
    3cdb:	9a 96 3b 7c 3d       	call   0x3d7c:0x3b96
    3ce0:	c9                   	leave
    3ce1:	ca 04 00             	retf   0x4
    3ce4:	55                   	push   bp
    3ce5:	89 e5                	mov    bp,sp
    3ce7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cea:	26 8b 85 9f 00       	mov    ax,WORD PTR es:[di+0x9f]
    3cef:	26 0b 85 a1 00       	or     ax,WORD PTR es:[di+0xa1]
    3cf4:	74 0c                	je     0x3d02
    3cf6:	26 c4 bd 9f 00       	les    di,DWORD PTR es:[di+0x9f]
    3cfb:	06                   	push   es
    3cfc:	57                   	push   di
    3cfd:	9a 7f 1f 18 3d       	call   0x3d18:0x1f7f
    3d02:	31 c0                	xor    ax,ax
    3d04:	50                   	push   ax
    3d05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d08:	06                   	push   es
    3d09:	57                   	push   di
    3d0a:	9a e0 1f 37 3d       	call   0x3d37:0x1fe0
    3d0f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3d13:	74 05                	je     0x3d1a
    3d15:	9a 0f 20 3f 3e       	call   0x3e3f:0x200f
    3d1a:	c9                   	leave
    3d1b:	ca 06 00             	retf   0x6
    3d1e:	55                   	push   bp
    3d1f:	89 e5                	mov    bp,sp
    3d21:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    3d24:	50                   	push   ax
    3d25:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    3d28:	50                   	push   ax
    3d29:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3d2c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d32:	06                   	push   es
    3d33:	57                   	push   di
    3d34:	9a 72 21 cf 3d       	call   0x3dcf:0x2172
    3d39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d3c:	26 f6 85 9e 00 01    	test   BYTE PTR es:[di+0x9e],0x1
    3d42:	74 6e                	je     0x3db2
    3d44:	26 8b 85 9f 00       	mov    ax,WORD PTR es:[di+0x9f]
    3d49:	26 0b 85 a1 00       	or     ax,WORD PTR es:[di+0xa1]
    3d4e:	75 23                	jne    0x3d73
    3d50:	ff 76 08             	push   WORD PTR [bp+0x8]
    3d53:	ff 76 06             	push   WORD PTR [bp+0x6]
    3d56:	b0 01                	mov    al,0x1
    3d58:	50                   	push   ax
    3d59:	b8 8b 0b             	mov    ax,0xb8b
    3d5c:	ba 64 3d             	mov    dx,0x3d64
    3d5f:	52                   	push   dx
    3d60:	50                   	push   ax
    3d61:	9a be 25 8d 3d       	call   0x3d8d:0x25be
    3d66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d69:	26 89 85 9f 00       	mov    WORD PTR es:[di+0x9f],ax
    3d6e:	26 89 95 a1 00       	mov    WORD PTR es:[di+0xa1],dx
    3d73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d76:	06                   	push   es
    3d77:	57                   	push   di
    3d78:	bf fc 3d             	mov    di,0x3dfc
    3d7b:	b8 fa 3d             	mov    ax,0x3dfa
    3d7e:	50                   	push   ax
    3d7f:	57                   	push   di
    3d80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d83:	26 c4 bd 9f 00       	les    di,DWORD PTR es:[di+0x9f]
    3d88:	06                   	push   es
    3d89:	57                   	push   di
    3d8a:	9a 8b 27 9f 3d       	call   0x3d9f:0x278b
    3d8f:	68 90 01             	push   0x190
    3d92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d95:	26 c4 bd 9f 00       	les    di,DWORD PTR es:[di+0x9f]
    3d9a:	06                   	push   es
    3d9b:	57                   	push   di
    3d9c:	9a 6a 27 b0 3d       	call   0x3db0:0x276a
    3da1:	6a 01                	push   0x1
    3da3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3da6:	26 c4 bd 9f 00       	les    di,DWORD PTR es:[di+0x9f]
    3dab:	06                   	push   es
    3dac:	57                   	push   di
    3dad:	9a 49 27 ec 3d       	call   0x3dec:0x2749
    3db2:	c9                   	leave
    3db3:	ca 0c 00             	retf   0xc
    3db6:	55                   	push   bp
    3db7:	89 e5                	mov    bp,sp
    3db9:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    3dbc:	50                   	push   ax
    3dbd:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    3dc0:	50                   	push   ax
    3dc1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3dc4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3dc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dca:	06                   	push   es
    3dcb:	57                   	push   di
    3dcc:	9a 57 22 75 3e       	call   0x3e75:0x2257
    3dd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dd4:	26 8b 85 9f 00       	mov    ax,WORD PTR es:[di+0x9f]
    3dd9:	26 0b 85 a1 00       	or     ax,WORD PTR es:[di+0xa1]
    3dde:	74 0e                	je     0x3dee
    3de0:	6a 00                	push   0x0
    3de2:	26 c4 bd 9f 00       	les    di,DWORD PTR es:[di+0x9f]
    3de7:	06                   	push   es
    3de8:	57                   	push   di
    3de9:	9a 49 27 0e 3e       	call   0x3e0e:0x2749
    3dee:	c9                   	leave
    3def:	ca 0c 00             	retf   0xc
    3df2:	01 00                	add    WORD PTR [bx+si],ax
    3df4:	00 00                	add    BYTE PTR [bx+si],al
    3df6:	00 00                	add    BYTE PTR [bx+si],al
    3df8:	4a                   	dec    dx
    3df9:	3e 95                	ds xchg bp,ax
    3dfb:	3f                   	aas
    3dfc:	55                   	push   bp
    3dfd:	89 e5                	mov    bp,sp
    3dff:	6a 64                	push   0x64
    3e01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e04:	26 c4 bd 9f 00       	les    di,DWORD PTR es:[di+0x9f]
    3e09:	06                   	push   es
    3e0a:	57                   	push   di
    3e0b:	9a 6a 27 59 3e       	call   0x3e59:0x276a
    3e10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e13:	26 80 bd 9c 00 02    	cmp    BYTE PTR es:[di+0x9c],0x2
    3e19:	75 4a                	jne    0x3e65
    3e1b:	06                   	push   es
    3e1c:	57                   	push   di
    3e1d:	9a 90 1f 83 3e       	call   0x3e83:0x1f90
    3e22:	08 c0                	or     al,al
    3e24:	74 3f                	je     0x3e65
    3e26:	b8 f2 3d             	mov    ax,0x3df2
    3e29:	0e                   	push   cs
    3e2a:	50                   	push   ax
    3e2b:	55                   	push   bp
    3e2c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3e30:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3e34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e37:	06                   	push   es
    3e38:	57                   	push   di
    3e39:	b8 fe ff             	mov    ax,0xfffe
    3e3c:	9a 6a 20 5e 3e       	call   0x3e5e:0x206a
    3e41:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3e45:	83 c4 06             	add    sp,0x6
    3e48:	eb 1b                	jmp    0x3e65
    3e4a:	6a 00                	push   0x0
    3e4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e4f:	26 c4 bd 9f 00       	les    di,DWORD PTR es:[di+0x9f]
    3e54:	06                   	push   es
    3e55:	57                   	push   di
    3e56:	9a 49 27 ff ff       	call   0xffff:0x2749
    3e5b:	ea 85 13 63 3e       	jmp    0x3e63:0x1385
    3e60:	9a 34 14 c6 3e       	call   0x3ec6:0x1434
    3e65:	c9                   	leave
    3e66:	ca 08 00             	retf   0x8
    3e69:	c8 10 00 00          	enter  0x10,0x0
    3e6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e70:	06                   	push   es
    3e71:	57                   	push   di
    3e72:	9a 2c 20 ff ff       	call   0xffff:0x202c
    3e77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e7a:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3e7e:	06                   	push   es
    3e7f:	57                   	push   di
    3e80:	9a b9 62 ff ff       	call   0xffff:0x62b9
    3e85:	50                   	push   ax
    3e86:	9a ff ff 00 00       	call   0x0:0xffff
    3e8b:	5a                   	pop    dx
    3e8c:	3b c2                	cmp    ax,dx
    3e8e:	75 79                	jne    0x3f09
    3e90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e93:	26 8a 85 9d 00       	mov    al,BYTE PTR es:[di+0x9d]
    3e98:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    3e9c:	26 3a 85 05 01       	cmp    al,BYTE PTR es:[di+0x105]
    3ea1:	75 66                	jne    0x3f09
    3ea3:	8d 7e f0             	lea    di,[bp-0x10]
    3ea6:	16                   	push   ss
    3ea7:	57                   	push   di
    3ea8:	6a 00                	push   0x0
    3eaa:	6a 00                	push   0x0
    3eac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3eaf:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    3eb3:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    3eb7:	9a ae 06 ff ff       	call   0xffff:0x6ae
    3ebc:	8d 7e f8             	lea    di,[bp-0x8]
    3ebf:	16                   	push   ss
    3ec0:	57                   	push   di
    3ec1:	6a 08                	push   0x8
    3ec3:	9a 1b 16 1c 3f       	call   0x3f1c:0x161b
    3ec8:	8d 7e f8             	lea    di,[bp-0x8]
    3ecb:	16                   	push   ss
    3ecc:	57                   	push   di
    3ecd:	6a fd                	push   0xfffd
    3ecf:	6a fd                	push   0xfffd
    3ed1:	9a ff ff 00 00       	call   0x0:0xffff
    3ed6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ed9:	26 80 bd 9c 00 02    	cmp    BYTE PTR es:[di+0x9c],0x2
    3edf:	75 0e                	jne    0x3eef
    3ee1:	8d 7e f8             	lea    di,[bp-0x8]
    3ee4:	16                   	push   ss
    3ee5:	57                   	push   di
    3ee6:	6a 01                	push   0x1
    3ee8:	6a 01                	push   0x1
    3eea:	9a ff ff 00 00       	call   0x0:0xffff
    3eef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ef2:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    3ef7:	06                   	push   es
    3ef8:	57                   	push   di
    3ef9:	9a d2 21 ff ff       	call   0xffff:0x21d2
    3efe:	50                   	push   ax
    3eff:	8d 7e f8             	lea    di,[bp-0x8]
    3f02:	16                   	push   ss
    3f03:	57                   	push   di
    3f04:	9a ff ff 00 00       	call   0x0:0xffff
    3f09:	c9                   	leave
    3f0a:	ca 04 00             	retf   0x4
    3f0d:	55                   	push   bp
    3f0e:	89 e5                	mov    bp,sp
    3f10:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3f14:	74 08                	je     0x3f1e
    3f16:	83 ec 08             	sub    sp,0x8
    3f19:	9a e2 1f 76 3f       	call   0x3f76:0x1fe2
    3f1e:	31 c0                	xor    ax,ax
    3f20:	50                   	push   ax
    3f21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f24:	06                   	push   es
    3f25:	57                   	push   di
    3f26:	9a dc 75 6b 3f       	call   0x3f6b:0x75dc
    3f2b:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    3f2e:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    3f31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f34:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    3f38:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    3f3c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3f40:	74 07                	je     0x3f49
    3f42:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3f46:	83 c4 06             	add    sp,0x6
    3f49:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3f4c:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    3f4f:	c9                   	leave
    3f50:	ca 0a 00             	retf   0xa
    3f53:	55                   	push   bp
    3f54:	89 e5                	mov    bp,sp
    3f56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f59:	31 c0                	xor    ax,ax
    3f5b:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    3f5f:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    3f63:	31 c0                	xor    ax,ax
    3f65:	50                   	push   ax
    3f66:	06                   	push   es
    3f67:	57                   	push   di
    3f68:	9a 1a 76 ff ff       	call   0xffff:0x761a
    3f6d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3f71:	74 05                	je     0x3f78
    3f73:	9a 0f 20 ff ff       	call   0xffff:0x200f
    3f78:	c9                   	leave
    3f79:	ca 06 00             	retf   0x6
    3f7c:	55                   	push   bp
    3f7d:	89 e5                	mov    bp,sp
    3f7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f82:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    3f86:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    3f8a:	74 0b                	je     0x3f97
    3f8c:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    3f90:	06                   	push   es
    3f91:	57                   	push   di
    3f92:	9a 8c 3a b4 3f       	call   0x3fb4:0x3a8c
    3f97:	c9                   	leave
    3f98:	ca 04 00             	retf   0x4
    3f9b:	55                   	push   bp
    3f9c:	89 e5                	mov    bp,sp
    3f9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fa1:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    3fa5:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    3fa9:	74 0b                	je     0x3fb6
    3fab:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    3faf:	06                   	push   es
    3fb0:	57                   	push   di
    3fb1:	9a 4c 39 d3 3f       	call   0x3fd3:0x394c
    3fb6:	c9                   	leave
    3fb7:	ca 04 00             	retf   0x4
    3fba:	55                   	push   bp
    3fbb:	89 e5                	mov    bp,sp
    3fbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fc0:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    3fc4:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    3fc8:	74 0b                	je     0x3fd5
    3fca:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    3fce:	06                   	push   es
    3fcf:	57                   	push   di
    3fd0:	9a 96 3b ff ff       	call   0xffff:0x3b96
    3fd5:	c9                   	leave
    3fd6:	ca                   	.byte 0xca
    3fd7:	04                   	.byte 0x4
