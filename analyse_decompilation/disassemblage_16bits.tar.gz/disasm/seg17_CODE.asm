; ================================================================
; seg17_CODE  (16063 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	11 00                	adc    WORD PTR [bx+si],ax
       2:	c0 07 cd             	rol    BYTE PTR [bx],0xcd
       5:	00 ae 00 00          	add    BYTE PTR [bp+0x0],ch
       9:	00 9e 00 9c          	add    BYTE PTR [bp-0x6400],bl
       d:	04 fb                	add    al,0xfb
       f:	04 d7                	add    al,0xd7
      11:	07                   	pop    es
      12:	39 3f                	cmp    WORD PTR [bx],di
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f ea 07 cb       	call   0xcb07:0xea1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 c2                	adc    dl,al
      2d:	08 d6                	or     dh,dl
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 5e                	sbb    al,0x5e
      61:	08 e2                	or     dl,ah
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	0f 54 46 6f          	andps  xmm0,XMMWORD PTR [bp+0x6f]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	45                   	inc    bp
      a6:	44                   	inc    sp
      a7:	49                   	dec    cx
      a8:	5f                   	pop    di
      a9:	50                   	push   ax
      aa:	72 69                	jb     0x115
      ac:	6e                   	outs   dx,BYTE PTR ds:[si]
      ad:	74 02                	je     0xb1
      af:	00 c8                	add    al,cl
      b1:	0a c0                	or     al,al
      b3:	00 09                	add    BYTE PTR [bx+di],cl
      b5:	46                   	inc    si
      b6:	6f                   	outs   dx,WORD PTR ds:[si]
      b7:	72 6d                	jb     0x126
      b9:	43                   	inc    bx
      ba:	6c                   	ins    BYTE PTR es:[di],dx
      bb:	6f                   	outs   dx,WORD PTR ds:[si]
      bc:	73 65                	jae    0x123
      be:	1d 08 d3             	sbb    ax,0xd308
      c1:	07                   	pop    es
      c2:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
      c5:	72 6d                	jb     0x134
      c7:	43                   	inc    bx
      c8:	72 65                	jb     0x12f
      ca:	61                   	popa
      cb:	74 65                	je     0x132
      cd:	87 00                	xchg   WORD PTR [bx+si],ax
      cf:	9e                   	sahf
      d0:	07                   	pop    es
      d1:	7c 01                	jl     0xd4
      d3:	00 00                	add    BYTE PTR [bx+si],al
      d5:	06                   	push   es
      d6:	50                   	push   ax
      d7:	61                   	popa
      d8:	6e                   	outs   dx,BYTE PTR ds:[si]
      d9:	65 6c                	gs ins BYTE PTR es:[di],dx
      db:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
      df:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
      e3:	6e                   	outs   dx,BYTE PTR ds:[si]
      e4:	65 6c                	gs ins BYTE PTR es:[di],dx
      e6:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
      ea:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
      ee:	6e                   	outs   dx,BYTE PTR ds:[si]
      ef:	65 6c                	gs ins BYTE PTR es:[di],dx
      f1:	35 88 01             	xor    ax,0x188
      f4:	00 00                	add    BYTE PTR [bx+si],al
      f6:	06                   	push   es
      f7:	50                   	push   ax
      f8:	61                   	popa
      f9:	6e                   	outs   dx,BYTE PTR ds:[si]
      fa:	65 6c                	gs ins BYTE PTR es:[di],dx
      fc:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     100:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     104:	6e                   	outs   dx,BYTE PTR ds:[si]
     105:	65 6c                	gs ins BYTE PTR es:[di],dx
     107:	36 90                	ss nop
     109:	01 00                	add    WORD PTR [bx+si],ax
     10b:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     10f:	6e                   	outs   dx,BYTE PTR ds:[si]
     110:	65 6c                	gs ins BYTE PTR es:[di],dx
     112:	37                   	aaa
     113:	94                   	xchg   sp,ax
     114:	01 00                	add    WORD PTR [bx+si],ax
     116:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     11a:	6e                   	outs   dx,BYTE PTR ds:[si]
     11b:	65 6c                	gs ins BYTE PTR es:[di],dx
     11d:	38 98 01 00          	cmp    BYTE PTR [bx+si+0x1],bl
     121:	00 07                	add    BYTE PTR [bx],al
     123:	50                   	push   ax
     124:	61                   	popa
     125:	6e                   	outs   dx,BYTE PTR ds:[si]
     126:	65 6c                	gs ins BYTE PTR es:[di],dx
     128:	33 37                	xor    si,WORD PTR [bx]
     12a:	9c                   	pushf
     12b:	01 00                	add    WORD PTR [bx+si],ax
     12d:	00 07                	add    BYTE PTR [bx],al
     12f:	50                   	push   ax
     130:	61                   	popa
     131:	6e                   	outs   dx,BYTE PTR ds:[si]
     132:	65 6c                	gs ins BYTE PTR es:[di],dx
     134:	33 38                	xor    di,WORD PTR [bx+si]
     136:	a0 01 04             	mov    al,ds:0x401
     139:	00 08                	add    BYTE PTR [bx+si],cl
     13b:	54                   	push   sp
     13c:	61                   	popa
     13d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     140:	45                   	inc    bp
     141:	44                   	inc    sp
     142:	47                   	inc    di
     143:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     144:	01 08                	add    WORD PTR [bx+si],cx
     146:	00 0d                	add    BYTE PTR [di],cl
     148:	44                   	inc    sp
     149:	61                   	popa
     14a:	74 61                	je     0x1ad
     14c:	53                   	push   bx
     14d:	6f                   	outs   dx,WORD PTR ds:[si]
     14e:	75 72                	jne    0x1c2
     150:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     153:	44                   	inc    sp
     154:	47                   	inc    di
     155:	a8 01                	test   al,0x1
     157:	04 00                	add    al,0x0
     159:	08 54 61             	or     BYTE PTR [si+0x61],dl
     15c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     15f:	45                   	inc    bp
     160:	44                   	inc    sp
     161:	4d                   	dec    bp
     162:	ac                   	lods   al,BYTE PTR ds:[si]
     163:	01 08                	add    WORD PTR [bx+si],cx
     165:	00 0d                	add    BYTE PTR [di],cl
     167:	44                   	inc    sp
     168:	61                   	popa
     169:	74 61                	je     0x1cc
     16b:	53                   	push   bx
     16c:	6f                   	outs   dx,WORD PTR ds:[si]
     16d:	75 72                	jne    0x1e1
     16f:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     172:	44                   	inc    sp
     173:	4d                   	dec    bp
     174:	b0 01                	mov    al,0x1
     176:	08 00                	or     BYTE PTR [bx+si],al
     178:	0e                   	push   cs
     179:	44                   	inc    sp
     17a:	61                   	popa
     17b:	74 61                	je     0x1de
     17d:	53                   	push   bx
     17e:	6f                   	outs   dx,WORD PTR ds:[si]
     17f:	75 72                	jne    0x1f3
     181:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     184:	44                   	inc    sp
     185:	50                   	push   ax
     186:	31 b4 01 08          	xor    WORD PTR [si+0x801],si
     18a:	00 0e 44 61          	add    BYTE PTR ds:0x6144,cl
     18e:	74 61                	je     0x1f1
     190:	53                   	push   bx
     191:	6f                   	outs   dx,WORD PTR ds:[si]
     192:	75 72                	jne    0x206
     194:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     197:	44                   	inc    sp
     198:	50                   	push   ax
     199:	32 b8 01 04          	xor    bh,BYTE PTR [bx+si+0x401]
     19d:	00 09                	add    BYTE PTR [bx+di],cl
     19f:	54                   	push   sp
     1a0:	61                   	popa
     1a1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1a4:	45                   	inc    bp
     1a5:	44                   	inc    sp
     1a6:	50                   	push   ax
     1a7:	31 bc 01 04          	xor    WORD PTR [si+0x401],di
     1ab:	00 09                	add    BYTE PTR [bx+di],cl
     1ad:	54                   	push   sp
     1ae:	61                   	popa
     1af:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1b2:	45                   	inc    bp
     1b3:	44                   	inc    sp
     1b4:	50                   	push   ax
     1b5:	32 c0                	xor    al,al
     1b7:	01 00                	add    WORD PTR [bx+si],ax
     1b9:	00 07                	add    BYTE PTR [bx],al
     1bb:	50                   	push   ax
     1bc:	61                   	popa
     1bd:	6e                   	outs   dx,BYTE PTR ds:[si]
     1be:	65 6c                	gs ins BYTE PTR es:[di],dx
     1c0:	31 36 c4 01          	xor    WORD PTR ds:0x1c4,si
     1c4:	0c 00                	or     al,0x0
     1c6:	09 47 72             	or     WORD PTR [bx+0x72],ax
     1c9:	6f                   	outs   dx,WORD PTR ds:[si]
     1ca:	75 70                	jne    0x23c
     1cc:	42                   	inc    dx
     1cd:	6f                   	outs   dx,WORD PTR ds:[si]
     1ce:	78 31                	js     0x201
     1d0:	c8 01 0c 00          	enter  0xc01,0x0
     1d4:	09 47 72             	or     WORD PTR [bx+0x72],ax
     1d7:	6f                   	outs   dx,WORD PTR ds:[si]
     1d8:	75 70                	jne    0x24a
     1da:	42                   	inc    dx
     1db:	6f                   	outs   dx,WORD PTR ds:[si]
     1dc:	78 34                	js     0x212
     1de:	cc                   	int3
     1df:	01 00                	add    WORD PTR [bx+si],ax
     1e1:	00 07                	add    BYTE PTR [bx],al
     1e3:	50                   	push   ax
     1e4:	61                   	popa
     1e5:	6e                   	outs   dx,BYTE PTR ds:[si]
     1e6:	65 6c                	gs ins BYTE PTR es:[di],dx
     1e8:	31 37                	xor    WORD PTR [bx],si
     1ea:	d0 01                	rol    BYTE PTR [bx+di],1
     1ec:	10 00                	adc    BYTE PTR [bx+si],al
     1ee:	06                   	push   es
     1ef:	4c                   	dec    sp
     1f0:	61                   	popa
     1f1:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1f4:	33 d4                	xor    dx,sp
     1f6:	01 10                	add    WORD PTR [bx+si],dx
     1f8:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     1fc:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     1ff:	34 d8                	xor    al,0xd8
     201:	01 14                	add    WORD PTR [si],dx
     203:	00 07                	add    BYTE PTR [bx],al
     205:	44                   	inc    sp
     206:	42                   	inc    dx
     207:	45                   	inc    bp
     208:	64 69 74 31 dc 01    	imul   si,WORD PTR fs:[si+0x31],0x1dc
     20e:	14 00                	adc    al,0x0
     210:	07                   	pop    es
     211:	44                   	inc    sp
     212:	42                   	inc    dx
     213:	45                   	inc    bp
     214:	64 69 74 32 e0 01    	imul   si,WORD PTR fs:[si+0x32],0x1e0
     21a:	00 00                	add    BYTE PTR [bx+si],al
     21c:	07                   	pop    es
     21d:	50                   	push   ax
     21e:	61                   	popa
     21f:	6e                   	outs   dx,BYTE PTR ds:[si]
     220:	65 6c                	gs ins BYTE PTR es:[di],dx
     222:	31 38                	xor    WORD PTR [bx+si],di
     224:	e4 01                	in     al,0x1
     226:	10 00                	adc    BYTE PTR [bx+si],al
     228:	06                   	push   es
     229:	4c                   	dec    sp
     22a:	61                   	popa
     22b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     22e:	35 e8 01             	xor    ax,0x1e8
     231:	10 00                	adc    BYTE PTR [bx+si],al
     233:	06                   	push   es
     234:	4c                   	dec    sp
     235:	61                   	popa
     236:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     239:	36 ec                	ss in  al,dx
     23b:	01 14                	add    WORD PTR [si],dx
     23d:	00 07                	add    BYTE PTR [bx],al
     23f:	44                   	inc    sp
     240:	42                   	inc    dx
     241:	45                   	inc    bp
     242:	64 69 74 33 f0 01    	imul   si,WORD PTR fs:[si+0x33],0x1f0
     248:	14 00                	adc    al,0x0
     24a:	07                   	pop    es
     24b:	44                   	inc    sp
     24c:	42                   	inc    dx
     24d:	45                   	inc    bp
     24e:	64 69 74 34 f4 01    	imul   si,WORD PTR fs:[si+0x34],0x1f4
     254:	00 00                	add    BYTE PTR [bx+si],al
     256:	07                   	pop    es
     257:	50                   	push   ax
     258:	61                   	popa
     259:	6e                   	outs   dx,BYTE PTR ds:[si]
     25a:	65 6c                	gs ins BYTE PTR es:[di],dx
     25c:	31 39                	xor    WORD PTR [bx+di],di
     25e:	f8                   	clc
     25f:	01 10                	add    WORD PTR [bx+si],dx
     261:	00 07                	add    BYTE PTR [bx],al
     263:	4c                   	dec    sp
     264:	61                   	popa
     265:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     268:	31 38                	xor    WORD PTR [bx+si],di
     26a:	fc                   	cld
     26b:	01 14                	add    WORD PTR [si],dx
     26d:	00 07                	add    BYTE PTR [bx],al
     26f:	44                   	inc    sp
     270:	42                   	inc    dx
     271:	45                   	inc    bp
     272:	64 69 74 35 00 02    	imul   si,WORD PTR fs:[si+0x35],0x200
     278:	0c 00                	or     al,0x0
     27a:	09 47 72             	or     WORD PTR [bx+0x72],ax
     27d:	6f                   	outs   dx,WORD PTR ds:[si]
     27e:	75 70                	jne    0x2f0
     280:	42                   	inc    dx
     281:	6f                   	outs   dx,WORD PTR ds:[si]
     282:	78 35                	js     0x2b9
     284:	04 02                	add    al,0x2
     286:	10 00                	adc    BYTE PTR [bx+si],al
     288:	06                   	push   es
     289:	4c                   	dec    sp
     28a:	61                   	popa
     28b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     28e:	31 08                	xor    WORD PTR [bx+si],cx
     290:	02 10                	add    dl,BYTE PTR [bx+si]
     292:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     296:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     299:	32 0c                	xor    cl,BYTE PTR [si]
     29b:	02 14                	add    dl,BYTE PTR [si]
     29d:	00 07                	add    BYTE PTR [bx],al
     29f:	44                   	inc    sp
     2a0:	42                   	inc    dx
     2a1:	45                   	inc    bp
     2a2:	64 69 74 36 10 02    	imul   si,WORD PTR fs:[si+0x36],0x210
     2a8:	14 00                	adc    al,0x0
     2aa:	07                   	pop    es
     2ab:	44                   	inc    sp
     2ac:	42                   	inc    dx
     2ad:	45                   	inc    bp
     2ae:	64 69 74 37 14 02    	imul   si,WORD PTR fs:[si+0x37],0x214
     2b4:	00 00                	add    BYTE PTR [bx+si],al
     2b6:	06                   	push   es
     2b7:	50                   	push   ax
     2b8:	61                   	popa
     2b9:	6e                   	outs   dx,BYTE PTR ds:[si]
     2ba:	65 6c                	gs ins BYTE PTR es:[di],dx
     2bc:	34 18                	xor    al,0x18
     2be:	02 0c                	add    cl,BYTE PTR [si]
     2c0:	00 09                	add    BYTE PTR [bx+di],cl
     2c2:	47                   	inc    di
     2c3:	72 6f                	jb     0x334
     2c5:	75 70                	jne    0x337
     2c7:	42                   	inc    dx
     2c8:	6f                   	outs   dx,WORD PTR ds:[si]
     2c9:	78 32                	js     0x2fd
     2cb:	1c 02                	sbb    al,0x2
     2cd:	0c 00                	or     al,0x0
     2cf:	09 47 72             	or     WORD PTR [bx+0x72],ax
     2d2:	6f                   	outs   dx,WORD PTR ds:[si]
     2d3:	75 70                	jne    0x345
     2d5:	42                   	inc    dx
     2d6:	6f                   	outs   dx,WORD PTR ds:[si]
     2d7:	78 36                	js     0x30f
     2d9:	20 02                	and    BYTE PTR [bp+si],al
     2db:	00 00                	add    BYTE PTR [bx+si],al
     2dd:	06                   	push   es
     2de:	50                   	push   ax
     2df:	61                   	popa
     2e0:	6e                   	outs   dx,BYTE PTR ds:[si]
     2e1:	65 6c                	gs ins BYTE PTR es:[di],dx
     2e3:	39 24                	cmp    WORD PTR [si],sp
     2e5:	02 10                	add    dl,BYTE PTR [bx+si]
     2e7:	00 07                	add    BYTE PTR [bx],al
     2e9:	4c                   	dec    sp
     2ea:	61                   	popa
     2eb:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2ee:	31 30                	xor    WORD PTR [bx+si],si
     2f0:	28 02                	sub    BYTE PTR [bp+si],al
     2f2:	10 00                	adc    BYTE PTR [bx+si],al
     2f4:	07                   	pop    es
     2f5:	4c                   	dec    sp
     2f6:	61                   	popa
     2f7:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2fa:	31 39                	xor    WORD PTR [bx+di],di
     2fc:	2c 02                	sub    al,0x2
     2fe:	10 00                	adc    BYTE PTR [bx+si],al
     300:	06                   	push   es
     301:	4c                   	dec    sp
     302:	61                   	popa
     303:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     306:	37                   	aaa
     307:	30 02                	xor    BYTE PTR [bp+si],al
     309:	10 00                	adc    BYTE PTR [bx+si],al
     30b:	06                   	push   es
     30c:	4c                   	dec    sp
     30d:	61                   	popa
     30e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     311:	39 34                	cmp    WORD PTR [si],si
     313:	02 10                	add    dl,BYTE PTR [bx+si]
     315:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     319:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     31c:	38 38                	cmp    BYTE PTR [bx+si],bh
     31e:	02 14                	add    dl,BYTE PTR [si]
     320:	00 09                	add    BYTE PTR [bx+di],cl
     322:	44                   	inc    sp
     323:	42                   	inc    dx
     324:	45                   	inc    bp
     325:	64 69 74 32 31 31    	imul   si,WORD PTR fs:[si+0x32],0x3131
     32b:	3c 02                	cmp    al,0x2
     32d:	14 00                	adc    al,0x0
     32f:	09 44 42             	or     WORD PTR [si+0x42],ax
     332:	45                   	inc    bp
     333:	64 69 74 32 31 32    	imul   si,WORD PTR fs:[si+0x32],0x3231
     339:	40                   	inc    ax
     33a:	02 14                	add    dl,BYTE PTR [si]
     33c:	00 08                	add    BYTE PTR [bx+si],cl
     33e:	44                   	inc    sp
     33f:	42                   	inc    dx
     340:	45                   	inc    bp
     341:	64 69 74 31 30 44    	imul   si,WORD PTR fs:[si+0x31],0x4430
     347:	02 14                	add    dl,BYTE PTR [si]
     349:	00 08                	add    BYTE PTR [bx+si],cl
     34b:	44                   	inc    sp
     34c:	42                   	inc    dx
     34d:	45                   	inc    bp
     34e:	64 69 74 31 31 48    	imul   si,WORD PTR fs:[si+0x31],0x4831
     354:	02 00                	add    al,BYTE PTR [bx+si]
     356:	00 07                	add    BYTE PTR [bx],al
     358:	50                   	push   ax
     359:	61                   	popa
     35a:	6e                   	outs   dx,BYTE PTR ds:[si]
     35b:	65 6c                	gs ins BYTE PTR es:[di],dx
     35d:	31 30                	xor    WORD PTR [bx+si],si
     35f:	4c                   	dec    sp
     360:	02 10                	add    dl,BYTE PTR [bx+si]
     362:	00 07                	add    BYTE PTR [bx],al
     364:	4c                   	dec    sp
     365:	61                   	popa
     366:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     369:	31 31                	xor    WORD PTR [bx+di],si
     36b:	50                   	push   ax
     36c:	02 14                	add    dl,BYTE PTR [si]
     36e:	00 09                	add    BYTE PTR [bx+di],cl
     370:	44                   	inc    sp
     371:	42                   	inc    dx
     372:	45                   	inc    bp
     373:	64 69 74 32 32 31    	imul   si,WORD PTR fs:[si+0x32],0x3132
     379:	54                   	push   sp
     37a:	02 14                	add    dl,BYTE PTR [si]
     37c:	00 09                	add    BYTE PTR [bx+di],cl
     37e:	44                   	inc    sp
     37f:	42                   	inc    dx
     380:	45                   	inc    bp
     381:	64 69 74 32 32 32    	imul   si,WORD PTR fs:[si+0x32],0x3232
     387:	58                   	pop    ax
     388:	02 14                	add    dl,BYTE PTR [si]
     38a:	00 08                	add    BYTE PTR [bx+si],cl
     38c:	44                   	inc    sp
     38d:	42                   	inc    dx
     38e:	45                   	inc    bp
     38f:	64 69 74 31 32 5c    	imul   si,WORD PTR fs:[si+0x31],0x5c32
     395:	02 14                	add    dl,BYTE PTR [si]
     397:	00 08                	add    BYTE PTR [bx+si],cl
     399:	44                   	inc    sp
     39a:	42                   	inc    dx
     39b:	45                   	inc    bp
     39c:	64 69 74 31 33 60    	imul   si,WORD PTR fs:[si+0x31],0x6033
     3a2:	02 0c                	add    cl,BYTE PTR [si]
     3a4:	00 09                	add    BYTE PTR [bx+di],cl
     3a6:	47                   	inc    di
     3a7:	72 6f                	jb     0x418
     3a9:	75 70                	jne    0x41b
     3ab:	42                   	inc    dx
     3ac:	6f                   	outs   dx,WORD PTR ds:[si]
     3ad:	78 37                	js     0x3e6
     3af:	64 02 00             	add    al,BYTE PTR fs:[bx+si]
     3b2:	00 07                	add    BYTE PTR [bx],al
     3b4:	50                   	push   ax
     3b5:	61                   	popa
     3b6:	6e                   	outs   dx,BYTE PTR ds:[si]
     3b7:	65 6c                	gs ins BYTE PTR es:[di],dx
     3b9:	31 31                	xor    WORD PTR [bx+di],si
     3bb:	68 02 10             	push   0x1002
     3be:	00 07                	add    BYTE PTR [bx],al
     3c0:	4c                   	dec    sp
     3c1:	61                   	popa
     3c2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3c5:	31 36 6c 02          	xor    WORD PTR ds:0x26c,si
     3c9:	10 00                	adc    BYTE PTR [bx+si],al
     3cb:	07                   	pop    es
     3cc:	4c                   	dec    sp
     3cd:	61                   	popa
     3ce:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3d1:	31 35                	xor    WORD PTR [di],si
     3d3:	70 02                	jo     0x3d7
     3d5:	10 00                	adc    BYTE PTR [bx+si],al
     3d7:	07                   	pop    es
     3d8:	4c                   	dec    sp
     3d9:	61                   	popa
     3da:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3dd:	31 34                	xor    WORD PTR [si],si
     3df:	74 02                	je     0x3e3
     3e1:	10 00                	adc    BYTE PTR [bx+si],al
     3e3:	07                   	pop    es
     3e4:	4c                   	dec    sp
     3e5:	61                   	popa
     3e6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3e9:	32 30                	xor    dh,BYTE PTR [bx+si]
     3eb:	78 02                	js     0x3ef
     3ed:	10 00                	adc    BYTE PTR [bx+si],al
     3ef:	07                   	pop    es
     3f0:	4c                   	dec    sp
     3f1:	61                   	popa
     3f2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3f5:	31 33                	xor    WORD PTR [bp+di],si
     3f7:	7c 02                	jl     0x3fb
     3f9:	10 00                	adc    BYTE PTR [bx+si],al
     3fb:	07                   	pop    es
     3fc:	4c                   	dec    sp
     3fd:	61                   	popa
     3fe:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     401:	31 32                	xor    WORD PTR [bp+si],si
     403:	80 02 14             	add    BYTE PTR [bp+si],0x14
     406:	00 09                	add    BYTE PTR [bx+di],cl
     408:	44                   	inc    sp
     409:	42                   	inc    dx
     40a:	45                   	inc    bp
     40b:	64 69 74 32 31 33    	imul   si,WORD PTR fs:[si+0x32],0x3331
     411:	84 02                	test   BYTE PTR [bp+si],al
     413:	14 00                	adc    al,0x0
     415:	09 44 42             	or     WORD PTR [si+0x42],ax
     418:	45                   	inc    bp
     419:	64 69 74 32 31 34    	imul   si,WORD PTR fs:[si+0x32],0x3431
     41f:	88 02                	mov    BYTE PTR [bp+si],al
     421:	14 00                	adc    al,0x0
     423:	08 44 42             	or     BYTE PTR [si+0x42],al
     426:	45                   	inc    bp
     427:	64 69 74 31 34 8c    	imul   si,WORD PTR fs:[si+0x31],0x8c34
     42d:	02 14                	add    dl,BYTE PTR [si]
     42f:	00 09                	add    BYTE PTR [bx+di],cl
     431:	44                   	inc    sp
     432:	42                   	inc    dx
     433:	45                   	inc    bp
     434:	64 69 74 32 31 35    	imul   si,WORD PTR fs:[si+0x32],0x3531
     43a:	90                   	nop
     43b:	02 14                	add    dl,BYTE PTR [si]
     43d:	00 07                	add    BYTE PTR [bx],al
     43f:	44                   	inc    sp
     440:	42                   	inc    dx
     441:	45                   	inc    bp
     442:	64 69 74 38 94 02    	imul   si,WORD PTR fs:[si+0x38],0x294
     448:	00 00                	add    BYTE PTR [bx+si],al
     44a:	07                   	pop    es
     44b:	50                   	push   ax
     44c:	61                   	popa
     44d:	6e                   	outs   dx,BYTE PTR ds:[si]
     44e:	65 6c                	gs ins BYTE PTR es:[di],dx
     450:	32 30                	xor    dh,BYTE PTR [bx+si]
     452:	98                   	cbw
     453:	02 10                	add    dl,BYTE PTR [bx+si]
     455:	00 07                	add    BYTE PTR [bx],al
     457:	4c                   	dec    sp
     458:	61                   	popa
     459:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     45c:	31 37                	xor    WORD PTR [bx],si
     45e:	9c                   	pushf
     45f:	02 14                	add    dl,BYTE PTR [si]
     461:	00 09                	add    BYTE PTR [bx+di],cl
     463:	44                   	inc    sp
     464:	42                   	inc    dx
     465:	45                   	inc    bp
     466:	64 69 74 32 32 33    	imul   si,WORD PTR fs:[si+0x32],0x3332
     46c:	a0 02 14             	mov    al,ds:0x1402
     46f:	00 09                	add    BYTE PTR [bx+di],cl
     471:	44                   	inc    sp
     472:	42                   	inc    dx
     473:	45                   	inc    bp
     474:	64 69 74 32 32 34    	imul   si,WORD PTR fs:[si+0x32],0x3432
     47a:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     47b:	02 14                	add    dl,BYTE PTR [si]
     47d:	00 08                	add    BYTE PTR [bx+si],cl
     47f:	44                   	inc    sp
     480:	42                   	inc    dx
     481:	45                   	inc    bp
     482:	64 69 74 31 35 a8    	imul   si,WORD PTR fs:[si+0x31],0xa835
     488:	02 14                	add    dl,BYTE PTR [si]
     48a:	00 09                	add    BYTE PTR [bx+di],cl
     48c:	44                   	inc    sp
     48d:	42                   	inc    dx
     48e:	45                   	inc    bp
     48f:	64 69 74 32 32 35    	imul   si,WORD PTR fs:[si+0x32],0x3532
     495:	ac                   	lods   al,BYTE PTR ds:[si]
     496:	02 14                	add    dl,BYTE PTR [si]
     498:	00 07                	add    BYTE PTR [bx],al
     49a:	44                   	inc    sp
     49b:	42                   	inc    dx
     49c:	45                   	inc    bp
     49d:	64 69 74 39 b0 02    	imul   si,WORD PTR fs:[si+0x39],0x2b0
     4a3:	00 00                	add    BYTE PTR [bx+si],al
     4a5:	07                   	pop    es
     4a6:	50                   	push   ax
     4a7:	61                   	popa
     4a8:	6e                   	outs   dx,BYTE PTR ds:[si]
     4a9:	65 6c                	gs ins BYTE PTR es:[di],dx
     4ab:	32 31                	xor    dh,BYTE PTR [bx+di]
     4ad:	b4 02                	mov    ah,0x2
     4af:	0c 00                	or     al,0x0
     4b1:	09 47 72             	or     WORD PTR [bx+0x72],ax
     4b4:	6f                   	outs   dx,WORD PTR ds:[si]
     4b5:	75 70                	jne    0x527
     4b7:	42                   	inc    dx
     4b8:	6f                   	outs   dx,WORD PTR ds:[si]
     4b9:	78 38                	js     0x4f3
     4bb:	b8 02 0c             	mov    ax,0xc02
     4be:	00 0a                	add    BYTE PTR [bp+si],cl
     4c0:	47                   	inc    di
     4c1:	72 6f                	jb     0x532
     4c3:	75 70                	jne    0x535
     4c5:	42                   	inc    dx
     4c6:	6f                   	outs   dx,WORD PTR ds:[si]
     4c7:	78 31                	js     0x4fa
     4c9:	32 bc 02 10          	xor    bh,BYTE PTR [si+0x1002]
     4cd:	00 07                	add    BYTE PTR [bx],al
     4cf:	4c                   	dec    sp
     4d0:	61                   	popa
     4d1:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4d4:	32 32                	xor    dh,BYTE PTR [bp+si]
     4d6:	c0 02 10             	rol    BYTE PTR [bp+si],0x10
     4d9:	00 07                	add    BYTE PTR [bx],al
     4db:	4c                   	dec    sp
     4dc:	61                   	popa
     4dd:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4e0:	32 34                	xor    dh,BYTE PTR [si]
     4e2:	c4 02                	les    ax,DWORD PTR [bp+si]
     4e4:	14 00                	adc    al,0x0
     4e6:	08 44 42             	or     BYTE PTR [si+0x42],al
     4e9:	45                   	inc    bp
     4ea:	64 69 74 31 36 c8    	imul   si,WORD PTR fs:[si+0x31],0xc836
     4f0:	02 14                	add    dl,BYTE PTR [si]
     4f2:	00 08                	add    BYTE PTR [bx+si],cl
     4f4:	44                   	inc    sp
     4f5:	42                   	inc    dx
     4f6:	45                   	inc    bp
     4f7:	64 69 74 31 37 cc    	imul   si,WORD PTR fs:[si+0x31],0xcc37
     4fd:	02 0c                	add    cl,BYTE PTR [si]
     4ff:	00 0a                	add    BYTE PTR [bp+si],cl
     501:	47                   	inc    di
     502:	72 6f                	jb     0x573
     504:	75 70                	jne    0x576
     506:	42                   	inc    dx
     507:	6f                   	outs   dx,WORD PTR ds:[si]
     508:	78 31                	js     0x53b
     50a:	33 d0                	xor    dx,ax
     50c:	02 10                	add    dl,BYTE PTR [bx+si]
     50e:	00 07                	add    BYTE PTR [bx],al
     510:	4c                   	dec    sp
     511:	61                   	popa
     512:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     515:	32 35                	xor    dh,BYTE PTR [di]
     517:	d4 02                	aam    0x2
     519:	10 00                	adc    BYTE PTR [bx+si],al
     51b:	07                   	pop    es
     51c:	4c                   	dec    sp
     51d:	61                   	popa
     51e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     521:	32 36 d8 02          	xor    dh,BYTE PTR ds:0x2d8
     525:	10 00                	adc    BYTE PTR [bx+si],al
     527:	07                   	pop    es
     528:	4c                   	dec    sp
     529:	61                   	popa
     52a:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     52d:	32 37                	xor    dh,BYTE PTR [bx]
     52f:	dc 02                	fadd   QWORD PTR [bp+si]
     531:	14 00                	adc    al,0x0
     533:	08 44 42             	or     BYTE PTR [si+0x42],al
     536:	45                   	inc    bp
     537:	64 69 74 31 38 e0    	imul   si,WORD PTR fs:[si+0x31],0xe038
     53d:	02 14                	add    dl,BYTE PTR [si]
     53f:	00 08                	add    BYTE PTR [bx+si],cl
     541:	44                   	inc    sp
     542:	42                   	inc    dx
     543:	45                   	inc    bp
     544:	64 69 74 31 39 e4    	imul   si,WORD PTR fs:[si+0x31],0xe439
     54a:	02 14                	add    dl,BYTE PTR [si]
     54c:	00 08                	add    BYTE PTR [bx+si],cl
     54e:	44                   	inc    sp
     54f:	42                   	inc    dx
     550:	45                   	inc    bp
     551:	64 69 74 32 30 e8    	imul   si,WORD PTR fs:[si+0x32],0xe830
     557:	02 00                	add    al,BYTE PTR [bx+si]
     559:	00 07                	add    BYTE PTR [bx],al
     55b:	50                   	push   ax
     55c:	61                   	popa
     55d:	6e                   	outs   dx,BYTE PTR ds:[si]
     55e:	65 6c                	gs ins BYTE PTR es:[di],dx
     560:	32 32                	xor    dh,BYTE PTR [bp+si]
     562:	ec                   	in     al,dx
     563:	02 0c                	add    cl,BYTE PTR [si]
     565:	00 09                	add    BYTE PTR [bx+di],cl
     567:	47                   	inc    di
     568:	72 6f                	jb     0x5d9
     56a:	75 70                	jne    0x5dc
     56c:	42                   	inc    dx
     56d:	6f                   	outs   dx,WORD PTR ds:[si]
     56e:	78 33                	js     0x5a3
     570:	f0 02 0c             	lock add cl,BYTE PTR [si]
     573:	00 09                	add    BYTE PTR [bx+di],cl
     575:	47                   	inc    di
     576:	72 6f                	jb     0x5e7
     578:	75 70                	jne    0x5ea
     57a:	42                   	inc    dx
     57b:	6f                   	outs   dx,WORD PTR ds:[si]
     57c:	78 39                	js     0x5b7
     57e:	f4                   	hlt
     57f:	02 18                	add    bl,BYTE PTR [bx+si]
     581:	00 0b                	add    BYTE PTR [bp+di],cl
     583:	44                   	inc    sp
     584:	42                   	inc    dx
     585:	43                   	inc    bx
     586:	68 65 63             	push   0x6365
     589:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     58d:	31 f8                	xor    ax,di
     58f:	02 18                	add    bl,BYTE PTR [bx+si]
     591:	00 0b                	add    BYTE PTR [bp+di],cl
     593:	44                   	inc    sp
     594:	42                   	inc    dx
     595:	43                   	inc    bx
     596:	68 65 63             	push   0x6365
     599:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     59d:	32 fc                	xor    bh,ah
     59f:	02 0c                	add    cl,BYTE PTR [si]
     5a1:	00 0a                	add    BYTE PTR [bp+si],cl
     5a3:	47                   	inc    di
     5a4:	72 6f                	jb     0x615
     5a6:	75 70                	jne    0x618
     5a8:	42                   	inc    dx
     5a9:	6f                   	outs   dx,WORD PTR ds:[si]
     5aa:	78 31                	js     0x5dd
     5ac:	30 00                	xor    BYTE PTR [bx+si],al
     5ae:	03 18                	add    bx,WORD PTR [bx+si]
     5b0:	00 0b                	add    BYTE PTR [bp+di],cl
     5b2:	44                   	inc    sp
     5b3:	42                   	inc    dx
     5b4:	43                   	inc    bx
     5b5:	68 65 63             	push   0x6365
     5b8:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     5bc:	33 04                	xor    ax,WORD PTR [si]
     5be:	03 18                	add    bx,WORD PTR [bx+si]
     5c0:	00 0b                	add    BYTE PTR [bp+di],cl
     5c2:	44                   	inc    sp
     5c3:	42                   	inc    dx
     5c4:	43                   	inc    bx
     5c5:	68 65 63             	push   0x6365
     5c8:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     5cc:	34 08                	xor    al,0x8
     5ce:	03 18                	add    bx,WORD PTR [bx+si]
     5d0:	00 0b                	add    BYTE PTR [bp+di],cl
     5d2:	44                   	inc    sp
     5d3:	42                   	inc    dx
     5d4:	43                   	inc    bx
     5d5:	68 65 63             	push   0x6365
     5d8:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     5dc:	35 0c 03             	xor    ax,0x30c
     5df:	0c 00                	or     al,0x0
     5e1:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     5e4:	6f                   	outs   dx,WORD PTR ds:[si]
     5e5:	75 70                	jne    0x657
     5e7:	42                   	inc    dx
     5e8:	6f                   	outs   dx,WORD PTR ds:[si]
     5e9:	78 31                	js     0x61c
     5eb:	31 10                	xor    WORD PTR [bx+si],dx
     5ed:	03 18                	add    bx,WORD PTR [bx+si]
     5ef:	00 0b                	add    BYTE PTR [bp+di],cl
     5f1:	44                   	inc    sp
     5f2:	42                   	inc    dx
     5f3:	43                   	inc    bx
     5f4:	68 65 63             	push   0x6365
     5f7:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     5fb:	36 14 03             	ss adc al,0x3
     5fe:	18 00                	sbb    BYTE PTR [bx+si],al
     600:	0b 44 42             	or     ax,WORD PTR [si+0x42]
     603:	43                   	inc    bx
     604:	68 65 63             	push   0x6365
     607:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     60b:	37                   	aaa
     60c:	18 03                	sbb    BYTE PTR [bp+di],al
     60e:	0c 00                	or     al,0x0
     610:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     613:	6f                   	outs   dx,WORD PTR ds:[si]
     614:	75 70                	jne    0x686
     616:	42                   	inc    dx
     617:	6f                   	outs   dx,WORD PTR ds:[si]
     618:	78 31                	js     0x64b
     61a:	37                   	aaa
     61b:	1c 03                	sbb    al,0x3
     61d:	10 00                	adc    BYTE PTR [bx+si],al
     61f:	07                   	pop    es
     620:	4c                   	dec    sp
     621:	61                   	popa
     622:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     625:	32 31                	xor    dh,BYTE PTR [bx+di]
     627:	20 03                	and    BYTE PTR [bp+di],al
     629:	14 00                	adc    al,0x0
     62b:	08 44 42             	or     BYTE PTR [si+0x42],al
     62e:	45                   	inc    bp
     62f:	64 69 74 32 37 24    	imul   si,WORD PTR fs:[si+0x32],0x2437
     635:	03 00                	add    ax,WORD PTR [bx+si]
     637:	00 07                	add    BYTE PTR [bx],al
     639:	50                   	push   ax
     63a:	61                   	popa
     63b:	6e                   	outs   dx,BYTE PTR ds:[si]
     63c:	65 6c                	gs ins BYTE PTR es:[di],dx
     63e:	31 32                	xor    WORD PTR [bp+si],si
     640:	28 03                	sub    BYTE PTR [bp+di],al
     642:	0c 00                	or     al,0x0
     644:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     647:	6f                   	outs   dx,WORD PTR ds:[si]
     648:	75 70                	jne    0x6ba
     64a:	42                   	inc    dx
     64b:	6f                   	outs   dx,WORD PTR ds:[si]
     64c:	78 31                	js     0x67f
     64e:	34 2c                	xor    al,0x2c
     650:	03 0c                	add    cx,WORD PTR [si]
     652:	00 0a                	add    BYTE PTR [bp+si],cl
     654:	47                   	inc    di
     655:	72 6f                	jb     0x6c6
     657:	75 70                	jne    0x6c9
     659:	42                   	inc    dx
     65a:	6f                   	outs   dx,WORD PTR ds:[si]
     65b:	78 31                	js     0x68e
     65d:	35 30 03             	xor    ax,0x330
     660:	00 00                	add    BYTE PTR [bx+si],al
     662:	07                   	pop    es
     663:	50                   	push   ax
     664:	61                   	popa
     665:	6e                   	outs   dx,BYTE PTR ds:[si]
     666:	65 6c                	gs ins BYTE PTR es:[di],dx
     668:	31 33                	xor    WORD PTR [bp+di],si
     66a:	34 03                	xor    al,0x3
     66c:	10 00                	adc    BYTE PTR [bx+si],al
     66e:	07                   	pop    es
     66f:	4c                   	dec    sp
     670:	61                   	popa
     671:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     674:	32 38                	xor    bh,BYTE PTR [bx+si]
     676:	38 03                	cmp    BYTE PTR [bp+di],al
     678:	10 00                	adc    BYTE PTR [bx+si],al
     67a:	07                   	pop    es
     67b:	4c                   	dec    sp
     67c:	61                   	popa
     67d:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     680:	33 31                	xor    si,WORD PTR [bx+di]
     682:	3c 03                	cmp    al,0x3
     684:	14 00                	adc    al,0x0
     686:	08 44 42             	or     BYTE PTR [si+0x42],al
     689:	45                   	inc    bp
     68a:	64 69 74 32 31 40    	imul   si,WORD PTR fs:[si+0x32],0x4031
     690:	03 00                	add    ax,WORD PTR [bx+si]
     692:	00 07                	add    BYTE PTR [bx],al
     694:	50                   	push   ax
     695:	61                   	popa
     696:	6e                   	outs   dx,BYTE PTR ds:[si]
     697:	65 6c                	gs ins BYTE PTR es:[di],dx
     699:	31 34                	xor    WORD PTR [si],si
     69b:	44                   	inc    sp
     69c:	03 10                	add    dx,WORD PTR [bx+si]
     69e:	00 07                	add    BYTE PTR [bx],al
     6a0:	4c                   	dec    sp
     6a1:	61                   	popa
     6a2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6a5:	33 30                	xor    si,WORD PTR [bx+si]
     6a7:	48                   	dec    ax
     6a8:	03 14                	add    dx,WORD PTR [si]
     6aa:	00 08                	add    BYTE PTR [bx+si],cl
     6ac:	44                   	inc    sp
     6ad:	42                   	inc    dx
     6ae:	45                   	inc    bp
     6af:	64 69 74 32 32 4c    	imul   si,WORD PTR fs:[si+0x32],0x4c32
     6b5:	03 0c                	add    cx,WORD PTR [si]
     6b7:	00 0a                	add    BYTE PTR [bp+si],cl
     6b9:	47                   	inc    di
     6ba:	72 6f                	jb     0x72b
     6bc:	75 70                	jne    0x72e
     6be:	42                   	inc    dx
     6bf:	6f                   	outs   dx,WORD PTR ds:[si]
     6c0:	78 31                	js     0x6f3
     6c2:	36 50                	ss push ax
     6c4:	03 00                	add    ax,WORD PTR [bx+si]
     6c6:	00 07                	add    BYTE PTR [bx],al
     6c8:	50                   	push   ax
     6c9:	61                   	popa
     6ca:	6e                   	outs   dx,BYTE PTR ds:[si]
     6cb:	65 6c                	gs ins BYTE PTR es:[di],dx
     6cd:	31 35                	xor    WORD PTR [di],si
     6cf:	54                   	push   sp
     6d0:	03 10                	add    dx,WORD PTR [bx+si]
     6d2:	00 07                	add    BYTE PTR [bx],al
     6d4:	4c                   	dec    sp
     6d5:	61                   	popa
     6d6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6d9:	33 32                	xor    si,WORD PTR [bp+si]
     6db:	58                   	pop    ax
     6dc:	03 10                	add    dx,WORD PTR [bx+si]
     6de:	00 07                	add    BYTE PTR [bx],al
     6e0:	4c                   	dec    sp
     6e1:	61                   	popa
     6e2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6e5:	33 34                	xor    si,WORD PTR [si]
     6e7:	5c                   	pop    sp
     6e8:	03 10                	add    dx,WORD PTR [bx+si]
     6ea:	00 07                	add    BYTE PTR [bx],al
     6ec:	4c                   	dec    sp
     6ed:	61                   	popa
     6ee:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6f1:	33 35                	xor    si,WORD PTR [di]
     6f3:	60                   	pusha
     6f4:	03 14                	add    dx,WORD PTR [si]
     6f6:	00 08                	add    BYTE PTR [bx+si],cl
     6f8:	44                   	inc    sp
     6f9:	42                   	inc    dx
     6fa:	45                   	inc    bp
     6fb:	64 69 74 32 33 64    	imul   si,WORD PTR fs:[si+0x32],0x6433
     701:	03 14                	add    dx,WORD PTR [si]
     703:	00 08                	add    BYTE PTR [bx+si],cl
     705:	44                   	inc    sp
     706:	42                   	inc    dx
     707:	45                   	inc    bp
     708:	64 69 74 32 35 68    	imul   si,WORD PTR fs:[si+0x32],0x6835
     70e:	03 00                	add    ax,WORD PTR [bx+si]
     710:	00 07                	add    BYTE PTR [bx],al
     712:	50                   	push   ax
     713:	61                   	popa
     714:	6e                   	outs   dx,BYTE PTR ds:[si]
     715:	65 6c                	gs ins BYTE PTR es:[di],dx
     717:	32 33                	xor    dh,BYTE PTR [bp+di]
     719:	6c                   	ins    BYTE PTR es:[di],dx
     71a:	03 10                	add    dx,WORD PTR [bx+si]
     71c:	00 07                	add    BYTE PTR [bx],al
     71e:	4c                   	dec    sp
     71f:	61                   	popa
     720:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     723:	33 33                	xor    si,WORD PTR [bp+di]
     725:	70 03                	jo     0x72a
     727:	14 00                	adc    al,0x0
     729:	08 44 42             	or     BYTE PTR [si+0x42],al
     72c:	45                   	inc    bp
     72d:	64 69 74 32 34 74    	imul   si,WORD PTR fs:[si+0x32],0x7434
     733:	03 14                	add    dx,WORD PTR [si]
     735:	00 08                	add    BYTE PTR [bx+si],cl
     737:	44                   	inc    sp
     738:	42                   	inc    dx
     739:	45                   	inc    bp
     73a:	64 69 74 32 36 78    	imul   si,WORD PTR fs:[si+0x32],0x7836
     740:	03 00                	add    ax,WORD PTR [bx+si]
     742:	00 07                	add    BYTE PTR [bx],al
     744:	50                   	push   ax
     745:	61                   	popa
     746:	6e                   	outs   dx,BYTE PTR ds:[si]
     747:	65 6c                	gs ins BYTE PTR es:[di],dx
     749:	34 34                	xor    al,0x34
     74b:	7c 03                	jl     0x750
     74d:	10 00                	adc    BYTE PTR [bx+si],al
     74f:	07                   	pop    es
     750:	4c                   	dec    sp
     751:	61                   	popa
     752:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     755:	55                   	push   bp
     756:	30 80 03 10          	xor    BYTE PTR [bx+si+0x1003],al
     75a:	00 07                	add    BYTE PTR [bx],al
     75c:	4c                   	dec    sp
     75d:	61                   	popa
     75e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     761:	55                   	push   bp
     762:	31 84 03 10          	xor    WORD PTR [si+0x1003],ax
     766:	00 07                	add    BYTE PTR [bx],al
     768:	4c                   	dec    sp
     769:	61                   	popa
     76a:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     76d:	55                   	push   bp
     76e:	32 88 03 10          	xor    cl,BYTE PTR [bx+si+0x1003]
     772:	00 07                	add    BYTE PTR [bx],al
     774:	4c                   	dec    sp
     775:	61                   	popa
     776:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     779:	55                   	push   bp
     77a:	33 8c 03 10          	xor    cx,WORD PTR [si+0x1003]
     77e:	00 07                	add    BYTE PTR [bx],al
     780:	4c                   	dec    sp
     781:	61                   	popa
     782:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     785:	33 36 90 03          	xor    si,WORD PTR ds:0x390
     789:	14 00                	adc    al,0x0
     78b:	08 44 42             	or     BYTE PTR [si+0x42],al
     78e:	45                   	inc    bp
     78f:	64 69 74 32 38 94    	imul   si,WORD PTR fs:[si+0x32],0x9438
     795:	03 1c                	add    bx,WORD PTR [si]
     797:	00 05                	add    BYTE PTR [di],al
     799:	4d                   	dec    bp
     79a:	65 6d                	gs ins WORD PTR es:[di],dx
     79c:	6f                   	outs   dx,WORD PTR ds:[si]
     79d:	31 08                	xor    WORD PTR [bx+si],cx
     79f:	00 ad 0d 79          	add    BYTE PTR [di+0x790d],ch
     7a3:	19 38                	sbb    WORD PTR [bx+si],di
     7a5:	01 86 0a c8          	add    WORD PTR [bp-0x37f6],ax
     7a9:	08 45 0b             	or     BYTE PTR [di+0xb],al
     7ac:	0c 01                	or     al,0x1
     7ae:	b2 07                	mov    dl,0x7
     7b0:	17                   	pop    ss
     7b1:	06                   	push   es
     7b2:	be 07 22             	mov    si,0x2207
     7b5:	00 ba 07 26          	add    BYTE PTR [bp+si+0x2607],bh
     7b9:	06                   	push   es
     7ba:	2b 0b                	sub    cx,WORD PTR [bp+di]
     7bc:	91                   	xchg   cx,ax
     7bd:	12 67 18             	adc    ah,BYTE PTR [bx+0x18]
     7c0:	07                   	pop    es
     7c1:	0f 54 46 6f          	andps  xmm0,XMMWORD PTR [bp+0x6f]
     7c5:	72 6d                	jb     0x834
     7c7:	53                   	push   bx
     7c8:	45                   	inc    bp
     7c9:	44                   	inc    sp
     7ca:	49                   	dec    cx
     7cb:	5f                   	pop    di
     7cc:	50                   	push   ax
     7cd:	72 69                	jb     0x838
     7cf:	6e                   	outs   dx,BYTE PTR ds:[si]
     7d0:	74 22                	je     0x7f4
     7d2:	00 da                	add    dl,bl
     7d4:	0a 7b 06             	or     bh,BYTE PTR [bp+di+0x6]
     7d7:	02 08                	add    cl,BYTE PTR [bx+si]
     7d9:	38 00                	cmp    BYTE PTR [bx+si],al
     7db:	04 53                	add    al,0x53
     7dd:	65 64 69 00 00 55    	gs imul ax,WORD PTR fs:[bx+si],0x5500
     7e3:	89 e5                	mov    bp,sp
     7e5:	31 c0                	xor    ax,ax
     7e7:	9a 44 04 26 08       	call   0x826:0x444
     7ec:	6a 00                	push   0x0
     7ee:	9a c2 38 d2 12       	call   0x12d2:0x38c2
     7f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7f6:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     7fd:	06                   	push   es
     7fe:	57                   	push   di
     7ff:	9a 56 55 99 08       	call   0x899:0x5556
     804:	9a c3 28 1a 0a       	call   0xa1a:0x28c3
     809:	c9                   	leave
     80a:	ca 04 00             	retf   0x4
     80d:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
     810:	6d                   	ins    WORD PTR es:[di],dx
     811:	73 74                	jae    0x887
     813:	72 61                	jb     0x876
     815:	74 20                	je     0x837
     817:	2d 20 03             	sub    ax,0x320
     81a:	20 2d                	and    BYTE PTR [di],ch
     81c:	20 55 89             	and    BYTE PTR [di-0x77],dl
     81f:	e5 b8                	in     ax,0xb8
     821:	02 03                	add    al,BYTE PTR [bp+di]
     823:	9a 44 04 3a 08       	call   0x83a:0x444
     828:	81 ec 02 03          	sub    sp,0x302
     82c:	8d be fe fe          	lea    di,[bp-0x102]
     830:	16                   	push   ss
     831:	57                   	push   di
     832:	bf 0d 08             	mov    di,0x80d
     835:	0e                   	push   cs
     836:	57                   	push   di
     837:	9a cd 17 44 08       	call   0x844:0x17cd
     83c:	bf fa 1d             	mov    di,0x1dfa
     83f:	1e                   	push   ds
     840:	57                   	push   di
     841:	9a 4c 18 4e 08       	call   0x84e:0x184c
     846:	bf 19 08             	mov    di,0x819
     849:	0e                   	push   cs
     84a:	57                   	push   di
     84b:	9a 4c 18 63 08       	call   0x863:0x184c
     850:	8d be fe fd          	lea    di,[bp-0x202]
     854:	16                   	push   ss
     855:	57                   	push   di
     856:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     859:	06                   	push   es
     85a:	57                   	push   di
     85b:	9a 53 1d 88 08       	call   0x888:0x1d53
     860:	9a 4c 18 74 08       	call   0x874:0x184c
     865:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     868:	81 c7 9c 03          	add    di,0x39c
     86c:	06                   	push   es
     86d:	57                   	push   di
     86e:	68 ff 00             	push   0xff
     871:	9a e7 17 cc 08       	call   0x8cc:0x17e7
     876:	bf fa 1d             	mov    di,0x1dfa
     879:	1e                   	push   ds
     87a:	57                   	push   di
     87b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     87e:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
     883:	06                   	push   es
     884:	57                   	push   di
     885:	9a 8c 1d f6 08       	call   0x8f6:0x1d8c
     88a:	6a 00                	push   0x0
     88c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     88f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     894:	06                   	push   es
     895:	57                   	push   di
     896:	9a d0 1c aa 08       	call   0x8aa:0x1cd0
     89b:	6a 00                	push   0x0
     89d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8a0:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
     8a5:	06                   	push   es
     8a6:	57                   	push   di
     8a7:	9a d0 1c b9 0b       	call   0xbb9:0x1cd0
     8ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8af:	26 c7 85 98 03 01 00 	mov    WORD PTR es:[di+0x398],0x1
     8b6:	26 c7 85 9a 03 01 00 	mov    WORD PTR es:[di+0x39a],0x1
     8bd:	06                   	push   es
     8be:	57                   	push   di
     8bf:	9a 7d 52 ee 08       	call   0x8ee:0x527d
     8c4:	2d 01 00             	sub    ax,0x1
     8c7:	71 05                	jno    0x8ce
     8c9:	9a 3e 04 fd 08       	call   0x8fd:0x43e
     8ce:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     8d1:	31 c0                	xor    ax,ax
     8d3:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     8d6:	7e 03                	jle    0x8db
     8d8:	e9 a7 00             	jmp    0x982
     8db:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     8de:	eb 03                	jmp    0x8e3
     8e0:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     8e3:	ff 76 fe             	push   WORD PTR [bp-0x2]
     8e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8e9:	06                   	push   es
     8ea:	57                   	push   di
     8eb:	9a 46 52 0e 09       	call   0x90e:0x5246
     8f0:	52                   	push   dx
     8f1:	50                   	push   ax
     8f2:	bf 99 03             	mov    di,0x399
     8f5:	b8 16 09             	mov    ax,0x916
     8f8:	50                   	push   ax
     8f9:	57                   	push   di
     8fa:	9a 55 22 1d 09       	call   0x91d:0x2255
     8ff:	08 c0                	or     al,al
     901:	74 74                	je     0x977
     903:	ff 76 fe             	push   WORD PTR [bp-0x2]
     906:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     909:	06                   	push   es
     90a:	57                   	push   di
     90b:	9a 46 52 ed 0c       	call   0xced:0x5246
     910:	52                   	push   dx
     911:	50                   	push   ax
     912:	bf 99 03             	mov    di,0x399
     915:	b8 75 09             	mov    ax,0x975
     918:	50                   	push   ax
     919:	57                   	push   di
     91a:	9a 73 22 5a 09       	call   0x95a:0x2273
     91f:	89 c7                	mov    di,ax
     921:	8e c2                	mov    es,dx
     923:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     926:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     929:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
     92e:	74 47                	je     0x977
     930:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     934:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
     938:	74 3d                	je     0x977
     93a:	a1 06 1e             	mov    ax,ds:0x1e06
     93d:	99                   	cwd
     93e:	8b c8                	mov    cx,ax
     940:	8b da                	mov    bx,dx
     942:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
     946:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
     94a:	09 d2                	or     dx,dx
     94c:	79 07                	jns    0x955
     94e:	f7 d2                	not    dx
     950:	f7 d8                	neg    ax
     952:	83 da ff             	sbb    dx,0xffff
     955:	71 05                	jno    0x95c
     957:	9a 3e 04 0f 0a       	call   0xa0f:0x43e
     95c:	3b d3                	cmp    dx,bx
     95e:	7c 0a                	jl     0x96a
     960:	7f 04                	jg     0x966
     962:	3b c1                	cmp    ax,cx
     964:	76 04                	jbe    0x96a
     966:	b0 00                	mov    al,0x0
     968:	eb 02                	jmp    0x96c
     96a:	b0 01                	mov    al,0x1
     96c:	50                   	push   ax
     96d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     970:	06                   	push   es
     971:	57                   	push   di
     972:	9a 77 1c 96 09       	call   0x996:0x1c77
     977:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     97a:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     97d:	74 03                	je     0x982
     97f:	e9 5e ff             	jmp    0x8e0
     982:	8d be fe fe          	lea    di,[bp-0x102]
     986:	16                   	push   ss
     987:	57                   	push   di
     988:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     98c:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
     991:	06                   	push   es
     992:	57                   	push   di
     993:	9a 53 1d a5 09       	call   0x9a5:0x1d53
     998:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     99b:	26 c4 bd 7c 03       	les    di,DWORD PTR es:[di+0x37c]
     9a0:	06                   	push   es
     9a1:	57                   	push   di
     9a2:	9a 8c 1d bb 09       	call   0x9bb:0x1d8c
     9a7:	8d be fe fe          	lea    di,[bp-0x102]
     9ab:	16                   	push   ss
     9ac:	57                   	push   di
     9ad:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     9b1:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
     9b6:	06                   	push   es
     9b7:	57                   	push   di
     9b8:	9a 53 1d ca 09       	call   0x9ca:0x1d53
     9bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9c0:	26 c4 bd 80 03       	les    di,DWORD PTR es:[di+0x380]
     9c5:	06                   	push   es
     9c6:	57                   	push   di
     9c7:	9a 8c 1d e0 09       	call   0x9e0:0x1d8c
     9cc:	8d be fe fe          	lea    di,[bp-0x102]
     9d0:	16                   	push   ss
     9d1:	57                   	push   di
     9d2:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     9d6:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
     9db:	06                   	push   es
     9dc:	57                   	push   di
     9dd:	9a 53 1d ef 09       	call   0x9ef:0x1d53
     9e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9e5:	26 c4 bd 84 03       	les    di,DWORD PTR es:[di+0x384]
     9ea:	06                   	push   es
     9eb:	57                   	push   di
     9ec:	9a 8c 1d 05 0a       	call   0xa05:0x1d8c
     9f1:	8d be fe fe          	lea    di,[bp-0x102]
     9f5:	16                   	push   ss
     9f6:	57                   	push   di
     9f7:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
     9fb:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
     a00:	06                   	push   es
     a01:	57                   	push   di
     a02:	9a 53 1d 72 0a       	call   0xa72:0x1d53
     a07:	bf 19 08             	mov    di,0x819
     a0a:	0e                   	push   cs
     a0b:	57                   	push   di
     a0c:	9a 4c 18 2f 0a       	call   0xa2f:0x184c
     a11:	8d be fe fd          	lea    di,[bp-0x202]
     a15:	16                   	push   ss
     a16:	57                   	push   di
     a17:	9a fe 15 2a 0a       	call   0xa2a:0x15fe
     a1c:	83 ec 08             	sub    sp,0x8
     a1f:	89 e3                	mov    bx,sp
     a21:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
     a25:	90                   	nop
     a26:	9b                   	fwait
     a27:	9a bf 1c 44 0a       	call   0xa44:0x1cbf
     a2c:	9a 4c 18 39 0a       	call   0xa39:0x184c
     a31:	bf 19 08             	mov    di,0x819
     a34:	0e                   	push   cs
     a35:	57                   	push   di
     a36:	9a 4c 18 59 0a       	call   0xa59:0x184c
     a3b:	8d be fe fc          	lea    di,[bp-0x302]
     a3f:	16                   	push   ss
     a40:	57                   	push   di
     a41:	9a fe 15 54 0a       	call   0xa54:0x15fe
     a46:	83 ec 08             	sub    sp,0x8
     a49:	89 e3                	mov    bx,sp
     a4b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
     a4f:	90                   	nop
     a50:	9b                   	fwait
     a51:	9a e4 1c ce 0e       	call   0xece:0x1ce4
     a56:	9a 4c 18 63 0a       	call   0xa63:0x184c
     a5b:	bf 19 08             	mov    di,0x819
     a5e:	0e                   	push   cs
     a5f:	57                   	push   di
     a60:	9a 4c 18 d0 0a       	call   0xad0:0x184c
     a65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a68:	26 c4 bd 88 03       	les    di,DWORD PTR es:[di+0x388]
     a6d:	06                   	push   es
     a6e:	57                   	push   di
     a6f:	9a 8c 1d dd 0e       	call   0xedd:0x1d8c
     a74:	bf 4e 1e             	mov    di,0x1e4e
     a77:	1e                   	push   ds
     a78:	57                   	push   di
     a79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a7c:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
     a81:	06                   	push   es
     a82:	57                   	push   di
     a83:	9a 17 30 9a 0a       	call   0xa9a:0x3017
     a88:	bf 5c 1e             	mov    di,0x1e5c
     a8b:	1e                   	push   ds
     a8c:	57                   	push   di
     a8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a90:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
     a95:	06                   	push   es
     a96:	57                   	push   di
     a97:	9a 17 30 ae 0a       	call   0xaae:0x3017
     a9c:	bf 5c 1e             	mov    di,0x1e5c
     a9f:	1e                   	push   ds
     aa0:	57                   	push   di
     aa1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aa4:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
     aa9:	06                   	push   es
     aaa:	57                   	push   di
     aab:	9a 17 30 c2 0a       	call   0xac2:0x3017
     ab0:	bf 6a 1e             	mov    di,0x1e6a
     ab3:	1e                   	push   ds
     ab4:	57                   	push   di
     ab5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ab8:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
     abd:	06                   	push   es
     abe:	57                   	push   di
     abf:	9a 17 30 57 0b       	call   0xb57:0x3017
     ac4:	c9                   	leave
     ac5:	ca 08 00             	retf   0x8
     ac8:	55                   	push   bp
     ac9:	89 e5                	mov    bp,sp
     acb:	31 c0                	xor    ax,ax
     acd:	9a 44 04 0b 0b       	call   0xb0b:0x444
     ad2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ad5:	06                   	push   es
     ad6:	57                   	push   di
     ad7:	9a 5f 0d 51 0d       	call   0xd51:0xd5f
     adc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     adf:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
     ae3:	c9                   	leave
     ae4:	ca 0c 00             	retf   0xc
     ae7:	07                   	pop    es
     ae8:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
     aec:	2b 30                	sub    si,WORD PTR [bx+si]
     aee:	30 01                	xor    BYTE PTR [bx+di],al
     af0:	30 0a                	xor    BYTE PTR [bp+si],cl
     af2:	23 2c                	and    bp,WORD PTR [si]
     af4:	23 23                	and    sp,WORD PTR [bp+di]
     af6:	30 2e 30 30          	xor    BYTE PTR ds:0x3030,ch
     afa:	23 23                	and    sp,WORD PTR [bp+di]
     afc:	05 23 2c             	add    ax,0x2c23
     aff:	23 23                	and    sp,WORD PTR [bp+di]
     b01:	30 55 89             	xor    BYTE PTR [di-0x77],dl
     b04:	e5 b8                	in     ax,0xb8
     b06:	0c 02                	or     al,0x2
     b08:	9a 44 04 5e 0b       	call   0xb5e:0x444
     b0d:	81 ec 0c 02          	sub    sp,0x20c
     b11:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     b14:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
     b18:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
     b1c:	8d be f8 fd          	lea    di,[bp-0x208]
     b20:	16                   	push   ss
     b21:	57                   	push   di
     b22:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     b26:	06                   	push   es
     b27:	57                   	push   di
     b28:	9a 9f 1a 36 0b       	call   0xb36:0x1a9f
     b2d:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     b31:	06                   	push   es
     b32:	57                   	push   di
     b33:	9a 5f 1a 1e 0d       	call   0xd1e:0x1a5f
     b38:	89 c7                	mov    di,ax
     b3a:	8e c2                	mov    es,dx
     b3c:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     b40:	06                   	push   es
     b41:	57                   	push   di
     b42:	9a 9b 3b 95 0b       	call   0xb95:0x3b9b
     b47:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b4a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     b4d:	ff 76 fe             	push   WORD PTR [bp-0x2]
     b50:	ff 76 fc             	push   WORD PTR [bp-0x4]
     b53:	bf 58 0a             	mov    di,0xa58
     b56:	b8 71 0b             	mov    ax,0xb71
     b59:	50                   	push   ax
     b5a:	57                   	push   di
     b5b:	9a 55 22 78 0b       	call   0xb78:0x2255
     b60:	08 c0                	or     al,al
     b62:	75 03                	jne    0xb67
     b64:	e9 26 01             	jmp    0xc8d
     b67:	ff 76 fe             	push   WORD PTR [bp-0x2]
     b6a:	ff 76 fc             	push   WORD PTR [bp-0x4]
     b6d:	bf 58 0a             	mov    di,0xa58
     b70:	b8 77 0c             	mov    ax,0xc77
     b73:	50                   	push   ax
     b74:	57                   	push   di
     b75:	9a 73 22 a3 0b       	call   0xba3:0x2273
     b7a:	89 c7                	mov    di,ax
     b7c:	8e c2                	mov    es,dx
     b7e:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
     b82:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
     b86:	8d be f4 fd          	lea    di,[bp-0x20c]
     b8a:	16                   	push   ss
     b8b:	57                   	push   di
     b8c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     b90:	06                   	push   es
     b91:	57                   	push   di
     b92:	9a cf 68 76 0d       	call   0xd76:0x68cf
     b97:	8d be fc fe          	lea    di,[bp-0x104]
     b9b:	16                   	push   ss
     b9c:	57                   	push   di
     b9d:	68 ff 00             	push   0xff
     ba0:	9a e7 17 ff 0b       	call   0xbff:0x17e7
     ba5:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     ba9:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
     bad:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
     bb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bb4:	06                   	push   es
     bb5:	57                   	push   di
     bb6:	9a d5 33 d4 0b       	call   0xbd4:0x33d5
     bbb:	89 c7                	mov    di,ax
     bbd:	8e c2                	mov    es,dx
     bbf:	06                   	push   es
     bc0:	57                   	push   di
     bc1:	9a 99 20 df 0b       	call   0xbdf:0x2099
     bc6:	8d be fc fe          	lea    di,[bp-0x104]
     bca:	16                   	push   ss
     bcb:	57                   	push   di
     bcc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bcf:	06                   	push   es
     bd0:	57                   	push   di
     bd1:	9a d5 33 0f 0c       	call   0xc0f:0x33d5
     bd6:	89 c7                	mov    di,ax
     bd8:	8e c2                	mov    es,dx
     bda:	06                   	push   es
     bdb:	57                   	push   di
     bdc:	9a 03 20 1a 0c       	call   0xc1a:0x2003
     be1:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     be5:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
     be9:	7d 03                	jge    0xbee
     beb:	e9 8d 00             	jmp    0xc7b
     bee:	bf e7 0a             	mov    di,0xae7
     bf1:	0e                   	push   cs
     bf2:	57                   	push   di
     bf3:	8d be fc fe          	lea    di,[bp-0x104]
     bf7:	16                   	push   ss
     bf8:	57                   	push   di
     bf9:	68 ff 00             	push   0xff
     bfc:	9a e7 17 4e 0c       	call   0xc4e:0x17e7
     c01:	8d be fc fe          	lea    di,[bp-0x104]
     c05:	16                   	push   ss
     c06:	57                   	push   di
     c07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c0a:	06                   	push   es
     c0b:	57                   	push   di
     c0c:	9a d5 33 cf 11       	call   0x11cf:0x33d5
     c11:	89 c7                	mov    di,ax
     c13:	8e c2                	mov    es,dx
     c15:	06                   	push   es
     c16:	57                   	push   di
     c17:	9a 03 20 d8 13       	call   0x13d8:0x2003
     c1c:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
     c20:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
     c24:	b0 00                	mov    al,0x0
     c26:	7d 01                	jge    0xc29
     c28:	40                   	inc    ax
     c29:	8a d0                	mov    dl,al
     c2b:	80 be fc fe 0c       	cmp    BYTE PTR [bp-0x104],0xc
     c30:	b0 00                	mov    al,0x0
     c32:	73 01                	jae    0xc35
     c34:	40                   	inc    ax
     c35:	22 c2                	and    al,dl
     c37:	08 c0                	or     al,al
     c39:	74 17                	je     0xc52
     c3b:	bf ef 0a             	mov    di,0xaef
     c3e:	0e                   	push   cs
     c3f:	57                   	push   di
     c40:	8d be fc fe          	lea    di,[bp-0x104]
     c44:	16                   	push   ss
     c45:	57                   	push   di
     c46:	68 ff 00             	push   0xff
     c49:	6a 03                	push   0x3
     c4b:	9a 16 19 66 0c       	call   0xc66:0x1916
     c50:	eb af                	jmp    0xc01
     c52:	80 be fc fe 07       	cmp    BYTE PTR [bp-0x104],0x7
     c57:	76 0f                	jbe    0xc68
     c59:	8d be fc fe          	lea    di,[bp-0x104]
     c5d:	16                   	push   ss
     c5e:	57                   	push   di
     c5f:	6a 03                	push   0x3
     c61:	6a 01                	push   0x1
     c63:	9a 75 19 9e 0c       	call   0xc9e:0x1975
     c68:	8d be fc fe          	lea    di,[bp-0x104]
     c6c:	16                   	push   ss
     c6d:	57                   	push   di
     c6e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     c72:	06                   	push   es
     c73:	57                   	push   di
     c74:	9a f9 60 89 0c       	call   0xc89:0x60f9
     c79:	eb 10                	jmp    0xc8b
     c7b:	bf f1 0a             	mov    di,0xaf1
     c7e:	0e                   	push   cs
     c7f:	57                   	push   di
     c80:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     c84:	06                   	push   es
     c85:	57                   	push   di
     c86:	9a f9 60 97 0c       	call   0xc97:0x60f9
     c8b:	eb 46                	jmp    0xcd3
     c8d:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c90:	ff 76 fc             	push   WORD PTR [bp-0x4]
     c93:	bf c8 07             	mov    di,0x7c8
     c96:	b8 ae 0c             	mov    ax,0xcae
     c99:	50                   	push   ax
     c9a:	57                   	push   di
     c9b:	9a 55 22 b5 0c       	call   0xcb5:0x2255
     ca0:	08 c0                	or     al,al
     ca2:	74 2f                	je     0xcd3
     ca4:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ca7:	ff 76 fc             	push   WORD PTR [bp-0x4]
     caa:	bf c8 07             	mov    di,0x7c8
     cad:	b8 d1 0c             	mov    ax,0xcd1
     cb0:	50                   	push   ax
     cb1:	57                   	push   di
     cb2:	9a 73 22 e0 0c       	call   0xce0:0x2273
     cb7:	89 c7                	mov    di,ax
     cb9:	8e c2                	mov    es,dx
     cbb:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
     cbf:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
     cc3:	bf fc 0a             	mov    di,0xafc
     cc6:	0e                   	push   cs
     cc7:	57                   	push   di
     cc8:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
     ccc:	06                   	push   es
     ccd:	57                   	push   di
     cce:	9a f9 60 d6 0d       	call   0xdd6:0x60f9
     cd3:	c9                   	leave
     cd4:	ca 08 00             	retf   0x8
     cd7:	55                   	push   bp
     cd8:	89 e5                	mov    bp,sp
     cda:	b8 04 00             	mov    ax,0x4
     cdd:	9a 44 04 f7 0c       	call   0xcf7:0x444
     ce2:	83 ec 04             	sub    sp,0x4
     ce5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ce8:	06                   	push   es
     ce9:	57                   	push   di
     cea:	9a 7d 52 16 0d       	call   0xd16:0x527d
     cef:	2d 01 00             	sub    ax,0x1
     cf2:	71 05                	jno    0xcf9
     cf4:	9a 3e 04 25 0d       	call   0xd25:0x43e
     cf9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cfc:	31 c0                	xor    ax,ax
     cfe:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     d01:	7f 58                	jg     0xd5b
     d03:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     d06:	eb 03                	jmp    0xd0b
     d08:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     d0b:	ff 76 fe             	push   WORD PTR [bp-0x2]
     d0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d11:	06                   	push   es
     d12:	57                   	push   di
     d13:	9a 46 52 36 0d       	call   0xd36:0x5246
     d18:	52                   	push   dx
     d19:	50                   	push   ax
     d1a:	bf 22 00             	mov    di,0x22
     d1d:	b8 3e 0d             	mov    ax,0xd3e
     d20:	50                   	push   ax
     d21:	57                   	push   di
     d22:	9a 55 22 45 0d       	call   0xd45:0x2255
     d27:	08 c0                	or     al,al
     d29:	74 28                	je     0xd53
     d2b:	ff 76 fe             	push   WORD PTR [bp-0x2]
     d2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d31:	06                   	push   es
     d32:	57                   	push   di
     d33:	9a 46 52 40 39       	call   0x3940:0x5246
     d38:	52                   	push   dx
     d39:	50                   	push   ax
     d3a:	bf 22 00             	mov    di,0x22
     d3d:	b8 78 1a             	mov    ax,0x1a78
     d40:	50                   	push   ax
     d41:	57                   	push   di
     d42:	9a 73 22 67 0d       	call   0xd67:0x2273
     d47:	52                   	push   dx
     d48:	50                   	push   ax
     d49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d4c:	06                   	push   es
     d4d:	57                   	push   di
     d4e:	9a 02 0b a9 0e       	call   0xea9:0xb02
     d53:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     d56:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     d59:	75 ad                	jne    0xd08
     d5b:	c9                   	leave
     d5c:	ca 04 00             	retf   0x4
     d5f:	55                   	push   bp
     d60:	89 e5                	mov    bp,sp
     d62:	31 c0                	xor    ax,ax
     d64:	9a 44 04 b2 0d       	call   0xdb2:0x444
     d69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d6c:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
     d71:	06                   	push   es
     d72:	57                   	push   di
     d73:	9a d2 31 85 0d       	call   0xd85:0x31d2
     d78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d7b:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
     d80:	06                   	push   es
     d81:	57                   	push   di
     d82:	9a d2 31 94 0d       	call   0xd94:0x31d2
     d87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d8a:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
     d8f:	06                   	push   es
     d90:	57                   	push   di
     d91:	9a d2 31 a3 0d       	call   0xda3:0x31d2
     d96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d99:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
     d9e:	06                   	push   es
     d9f:	57                   	push   di
     da0:	9a d2 31 ca 0d       	call   0xdca:0x31d2
     da5:	c9                   	leave
     da6:	ca 04 00             	retf   0x4
     da9:	55                   	push   bp
     daa:	89 e5                	mov    bp,sp
     dac:	b8 04 00             	mov    ax,0x4
     daf:	9a 44 04 b4 0e       	call   0xeb4:0x444
     db4:	83 ec 04             	sub    sp,0x4
     db7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dba:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
     dbf:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     dc2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     dc5:	06                   	push   es
     dc6:	57                   	push   di
     dc7:	9a d2 31 ec 0d       	call   0xdec:0x31d2
     dcc:	6a 01                	push   0x1
     dce:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     dd1:	06                   	push   es
     dd2:	57                   	push   di
     dd3:	9a fb 2f e2 0d       	call   0xde2:0x2ffb
     dd8:	6a 00                	push   0x0
     dda:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     ddd:	06                   	push   es
     dde:	57                   	push   di
     ddf:	9a d2 2e 0d 0e       	call   0xe0d:0x2ed2
     de4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     de7:	06                   	push   es
     de8:	57                   	push   di
     de9:	9a bf 31 01 0e       	call   0xe01:0x31bf
     dee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     df1:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
     df6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     df9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     dfc:	06                   	push   es
     dfd:	57                   	push   di
     dfe:	9a d2 31 23 0e       	call   0xe23:0x31d2
     e03:	6a 01                	push   0x1
     e05:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e08:	06                   	push   es
     e09:	57                   	push   di
     e0a:	9a fb 2f 19 0e       	call   0xe19:0x2ffb
     e0f:	6a 00                	push   0x0
     e11:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e14:	06                   	push   es
     e15:	57                   	push   di
     e16:	9a d2 2e 44 0e       	call   0xe44:0x2ed2
     e1b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e1e:	06                   	push   es
     e1f:	57                   	push   di
     e20:	9a bf 31 38 0e       	call   0xe38:0x31bf
     e25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e28:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
     e2d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     e30:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     e33:	06                   	push   es
     e34:	57                   	push   di
     e35:	9a d2 31 5a 0e       	call   0xe5a:0x31d2
     e3a:	6a 01                	push   0x1
     e3c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e3f:	06                   	push   es
     e40:	57                   	push   di
     e41:	9a fb 2f 50 0e       	call   0xe50:0x2ffb
     e46:	6a 00                	push   0x0
     e48:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e4b:	06                   	push   es
     e4c:	57                   	push   di
     e4d:	9a d2 2e 7b 0e       	call   0xe7b:0x2ed2
     e52:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e55:	06                   	push   es
     e56:	57                   	push   di
     e57:	9a bf 31 6f 0e       	call   0xe6f:0x31bf
     e5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e5f:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
     e64:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     e67:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     e6a:	06                   	push   es
     e6b:	57                   	push   di
     e6c:	9a d2 31 91 0e       	call   0xe91:0x31d2
     e71:	6a 01                	push   0x1
     e73:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e76:	06                   	push   es
     e77:	57                   	push   di
     e78:	9a fb 2f 87 0e       	call   0xe87:0x2ffb
     e7d:	6a 00                	push   0x0
     e7f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e82:	06                   	push   es
     e83:	57                   	push   di
     e84:	9a d2 2e 41 10       	call   0x1041:0x2ed2
     e89:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e8c:	06                   	push   es
     e8d:	57                   	push   di
     e8e:	9a bf 31 a5 0e       	call   0xea5:0x31bf
     e93:	c9                   	leave
     e94:	ca 04 00             	retf   0x4
     e97:	01 23                	add    WORD PTR [bp+di],sp
     e99:	00 00                	add    BYTE PTR [bx+si],al
     e9b:	00 00                	add    BYTE PTR [bx+si],al
     e9d:	ff 00                	inc    WORD PTR [bx+si]
     e9f:	00 00                	add    BYTE PTR [bx+si],al
     ea1:	01 00                	add    WORD PTR [bx+si],ax
     ea3:	2f                   	das
     ea4:	00 01                	add    BYTE PTR [bx+di],al
     ea6:	3e 8a 11             	mov    dl,BYTE PTR ds:[bx+di]
     ea9:	4f                   	dec    di
     eaa:	10 55 89             	adc    BYTE PTR [di-0x77],dl
     ead:	e5 b8                	in     ax,0xb8
     eaf:	02 02                	add    al,BYTE PTR [bp+si]
     eb1:	9a 44 04 19 0f       	call   0xf19:0x444
     eb6:	81 ec 02 02          	sub    sp,0x202
     eba:	8d be fe fd          	lea    di,[bp-0x202]
     ebe:	16                   	push   ss
     ebf:	57                   	push   di
     ec0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ec3:	26 8b 85 9a 03       	mov    ax,WORD PTR es:[di+0x39a]
     ec8:	99                   	cwd
     ec9:	52                   	push   dx
     eca:	50                   	push   ax
     ecb:	9a a9 08 f3 0e       	call   0xef3:0x8a9
     ed0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ed3:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
     ed8:	06                   	push   es
     ed9:	57                   	push   di
     eda:	9a 8c 1d 02 0f       	call   0xf02:0x1d8c
     edf:	8d be fe fd          	lea    di,[bp-0x202]
     ee3:	16                   	push   ss
     ee4:	57                   	push   di
     ee5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ee8:	26 8b 85 98 03       	mov    ax,WORD PTR es:[di+0x398]
     eed:	99                   	cwd
     eee:	52                   	push   dx
     eef:	50                   	push   ax
     ef0:	9a a9 08 64 0f       	call   0xf64:0x8a9
     ef5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ef8:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
     efd:	06                   	push   es
     efe:	57                   	push   di
     eff:	9a 8c 1d e7 0f       	call   0xfe7:0x1d8c
     f04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f07:	81 c7 9c 03          	add    di,0x39c
     f0b:	06                   	push   es
     f0c:	57                   	push   di
     f0d:	8d be fe fe          	lea    di,[bp-0x102]
     f11:	16                   	push   ss
     f12:	57                   	push   di
     f13:	68 ff 00             	push   0xff
     f16:	9a e7 17 29 0f       	call   0xf29:0x17e7
     f1b:	bf 97 0e             	mov    di,0xe97
     f1e:	0e                   	push   cs
     f1f:	57                   	push   di
     f20:	8d be fe fe          	lea    di,[bp-0x102]
     f24:	16                   	push   ss
     f25:	57                   	push   di
     f26:	9a 78 18 32 0f       	call   0xf32:0x1878
     f2b:	99                   	cwd
     f2c:	bf 99 0e             	mov    di,0xe99
     f2f:	9a 16 04 4e 0f       	call   0xf4e:0x416
     f34:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     f37:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
     f3b:	76 3d                	jbe    0xf7a
     f3d:	8d be fe fe          	lea    di,[bp-0x102]
     f41:	16                   	push   ss
     f42:	57                   	push   di
     f43:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     f46:	30 e4                	xor    ah,ah
     f48:	50                   	push   ax
     f49:	6a 01                	push   0x1
     f4b:	9a 75 19 78 0f       	call   0xf78:0x1975
     f50:	8d be fe fd          	lea    di,[bp-0x202]
     f54:	16                   	push   ss
     f55:	57                   	push   di
     f56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f59:	26 8b 85 9a 03       	mov    ax,WORD PTR es:[di+0x39a]
     f5e:	99                   	cwd
     f5f:	52                   	push   dx
     f60:	50                   	push   ax
     f61:	9a a9 08 c3 0f       	call   0xfc3:0x8a9
     f66:	8d be fe fe          	lea    di,[bp-0x102]
     f6a:	16                   	push   ss
     f6b:	57                   	push   di
     f6c:	68 ff 00             	push   0xff
     f6f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     f72:	30 e4                	xor    ah,ah
     f74:	50                   	push   ax
     f75:	9a 16 19 88 0f       	call   0xf88:0x1916
     f7a:	bf 97 0e             	mov    di,0xe97
     f7d:	0e                   	push   cs
     f7e:	57                   	push   di
     f7f:	8d be fe fe          	lea    di,[bp-0x102]
     f83:	16                   	push   ss
     f84:	57                   	push   di
     f85:	9a 78 18 91 0f       	call   0xf91:0x1878
     f8a:	99                   	cwd
     f8b:	bf 99 0e             	mov    di,0xe99
     f8e:	9a 16 04 ad 0f       	call   0xfad:0x416
     f93:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     f96:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
     f9a:	76 3d                	jbe    0xfd9
     f9c:	8d be fe fe          	lea    di,[bp-0x102]
     fa0:	16                   	push   ss
     fa1:	57                   	push   di
     fa2:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     fa5:	30 e4                	xor    ah,ah
     fa7:	50                   	push   ax
     fa8:	6a 01                	push   0x1
     faa:	9a 75 19 d7 0f       	call   0xfd7:0x1975
     faf:	8d be fe fd          	lea    di,[bp-0x202]
     fb3:	16                   	push   ss
     fb4:	57                   	push   di
     fb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fb8:	26 8b 85 98 03       	mov    ax,WORD PTR es:[di+0x398]
     fbd:	99                   	cwd
     fbe:	52                   	push   dx
     fbf:	50                   	push   ax
     fc0:	9a a9 08 a1 2e       	call   0x2ea1:0x8a9
     fc5:	8d be fe fe          	lea    di,[bp-0x102]
     fc9:	16                   	push   ss
     fca:	57                   	push   di
     fcb:	68 ff 00             	push   0xff
     fce:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     fd1:	30 e4                	xor    ah,ah
     fd3:	50                   	push   ax
     fd4:	9a 16 19 a2 11       	call   0x11a2:0x1916
     fd9:	8d be fe fe          	lea    di,[bp-0x102]
     fdd:	16                   	push   ss
     fde:	57                   	push   di
     fdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fe2:	06                   	push   es
     fe3:	57                   	push   di
     fe4:	9a 8c 1d 5f 12       	call   0x125f:0x1d8c
     fe9:	b8 a1 0e             	mov    ax,0xea1
     fec:	0e                   	push   cs
     fed:	50                   	push   ax
     fee:	55                   	push   bp
     fef:	ff 36 58 18          	push   WORD PTR ds:0x1858
     ff3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     ff7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ffa:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
     fff:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1003:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1007:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    100a:	26 8b 85 98 03       	mov    ax,WORD PTR es:[di+0x398]
    100f:	99                   	cwd
    1010:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    1014:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    1018:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    101d:	26 8b 85 9a 03       	mov    ax,WORD PTR es:[di+0x39a]
    1022:	99                   	cwd
    1023:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    1027:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    102b:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1030:	8d be ea fe          	lea    di,[bp-0x116]
    1034:	16                   	push   ss
    1035:	57                   	push   di
    1036:	6a 01                	push   0x1
    1038:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    103c:	06                   	push   es
    103d:	57                   	push   di
    103e:	9a 95 28 9b 10       	call   0x109b:0x2895
    1043:	08 c0                	or     al,al
    1045:	75 0a                	jne    0x1051
    1047:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    104a:	06                   	push   es
    104b:	57                   	push   di
    104c:	9a e2 07 a9 10       	call   0x10a9:0x7e2
    1051:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1054:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    1059:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    105d:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1061:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1064:	26 8b 85 98 03       	mov    ax,WORD PTR es:[di+0x398]
    1069:	99                   	cwd
    106a:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    106e:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    1072:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    1077:	26 8b 85 9a 03       	mov    ax,WORD PTR es:[di+0x39a]
    107c:	99                   	cwd
    107d:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    1081:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    1085:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    108a:	8d be ea fe          	lea    di,[bp-0x116]
    108e:	16                   	push   ss
    108f:	57                   	push   di
    1090:	6a 01                	push   0x1
    1092:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1096:	06                   	push   es
    1097:	57                   	push   di
    1098:	9a 95 28 06 11       	call   0x1106:0x2895
    109d:	08 c0                	or     al,al
    109f:	75 0a                	jne    0x10ab
    10a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10a4:	06                   	push   es
    10a5:	57                   	push   di
    10a6:	9a e2 07 14 11       	call   0x1114:0x7e2
    10ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10ae:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    10b3:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    10b7:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    10bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10be:	26 8b 85 98 03       	mov    ax,WORD PTR es:[di+0x398]
    10c3:	99                   	cwd
    10c4:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    10c8:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    10cc:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    10d1:	26 8b 85 9a 03       	mov    ax,WORD PTR es:[di+0x39a]
    10d6:	99                   	cwd
    10d7:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    10db:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    10df:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    10e4:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    10ea:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    10f0:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    10f5:	8d be e2 fe          	lea    di,[bp-0x11e]
    10f9:	16                   	push   ss
    10fa:	57                   	push   di
    10fb:	6a 02                	push   0x2
    10fd:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1101:	06                   	push   es
    1102:	57                   	push   di
    1103:	9a 95 28 71 11       	call   0x1171:0x2895
    1108:	08 c0                	or     al,al
    110a:	75 0a                	jne    0x1116
    110c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    110f:	06                   	push   es
    1110:	57                   	push   di
    1111:	9a e2 07 7f 11       	call   0x117f:0x7e2
    1116:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1119:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    111e:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1122:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1126:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1129:	26 8b 85 98 03       	mov    ax,WORD PTR es:[di+0x398]
    112e:	99                   	cwd
    112f:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    1133:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    1137:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    113c:	26 8b 85 9a 03       	mov    ax,WORD PTR es:[di+0x39a]
    1141:	99                   	cwd
    1142:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    1146:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    114a:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    114f:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    1155:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    115b:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1160:	8d be e2 fe          	lea    di,[bp-0x11e]
    1164:	16                   	push   ss
    1165:	57                   	push   di
    1166:	6a 02                	push   0x2
    1168:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    116c:	06                   	push   es
    116d:	57                   	push   di
    116e:	9a 95 28 ff ff       	call   0xffff:0x2895
    1173:	08 c0                	or     al,al
    1175:	75 0a                	jne    0x1181
    1177:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    117a:	06                   	push   es
    117b:	57                   	push   di
    117c:	9a e2 07 9d 11       	call   0x119d:0x7e2
    1181:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1185:	83 c4 06             	add    sp,0x6
    1188:	eb 1a                	jmp    0x11a4
    118a:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    118e:	89 96 fc fe          	mov    WORD PTR [bp-0x104],dx
    1192:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    1196:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    119a:	9a 2d 34 ac 11       	call   0x11ac:0x342d
    119f:	9a 34 14 c1 11       	call   0x11c1:0x1434
    11a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11a7:	06                   	push   es
    11a8:	57                   	push   di
    11a9:	9a d7 0c b6 11       	call   0x11b6:0xcd7
    11ae:	c9                   	leave
    11af:	ca 04 00             	retf   0x4
    11b2:	00 00                	add    BYTE PTR [bx+si],al
    11b4:	eb 12                	jmp    0x11c8
    11b6:	0b 12                	or     dx,WORD PTR [bp+si]
    11b8:	55                   	push   bp
    11b9:	89 e5                	mov    bp,sp
    11bb:	b8 0a 00             	mov    ax,0xa
    11be:	9a 44 04 09 13       	call   0x1309:0x444
    11c3:	83 ec 0a             	sub    sp,0xa
    11c6:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    11ca:	06                   	push   es
    11cb:	57                   	push   di
    11cc:	9a 03 73 12 12       	call   0x1212:0x7303
    11d1:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    11d5:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    11d9:	75 14                	jne    0x11ef
    11db:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    11df:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    11e5:	b0 00                	mov    al,0x0
    11e7:	75 01                	jne    0x11ea
    11e9:	40                   	inc    ax
    11ea:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    11ed:	eb 04                	jmp    0x11f3
    11ef:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    11f3:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    11f7:	75 03                	jne    0x11fc
    11f9:	e9 fa 00             	jmp    0x12f6
    11fc:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1200:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1204:	b0 01                	mov    al,0x1
    1206:	50                   	push   ax
    1207:	b8 22 00             	mov    ax,0x22
    120a:	ba 36 12             	mov    dx,0x1236
    120d:	52                   	push   dx
    120e:	50                   	push   ax
    120f:	9a 53 25 6d 12       	call   0x126d:0x2553
    1214:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1217:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    121a:	b8 b2 11             	mov    ax,0x11b2
    121d:	0e                   	push   cs
    121e:	50                   	push   ax
    121f:	55                   	push   bp
    1220:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1224:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1228:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    122b:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    122e:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1231:	06                   	push   es
    1232:	57                   	push   di
    1233:	9a a9 0d 50 12       	call   0x1250:0xda9
    1238:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    123b:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    123e:	26 89 85 98 03       	mov    WORD PTR es:[di+0x398],ax
    1243:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1246:	26 89 85 9a 03       	mov    WORD PTR es:[di+0x39a],ax
    124b:	06                   	push   es
    124c:	57                   	push   di
    124d:	9a ab 0e b2 12       	call   0x12b2:0xeab
    1252:	68 ff 00             	push   0xff
    1255:	6a ff                	push   0xffff
    1257:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    125a:	06                   	push   es
    125b:	57                   	push   di
    125c:	9a d5 1e 8f 12       	call   0x128f:0x1ed5
    1261:	6a 00                	push   0x0
    1263:	6a 00                	push   0x0
    1265:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1268:	06                   	push   es
    1269:	57                   	push   di
    126a:	9a b2 36 79 12       	call   0x1279:0x36b2
    126f:	6a 02                	push   0x2
    1271:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1274:	06                   	push   es
    1275:	57                   	push   di
    1276:	9a 14 3a 85 12       	call   0x1285:0x3a14
    127b:	6a 01                	push   0x1
    127d:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1280:	06                   	push   es
    1281:	57                   	push   di
    1282:	9a e5 34 a2 12       	call   0x12a2:0x34e5
    1287:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    128a:	06                   	push   es
    128b:	57                   	push   di
    128c:	9a b9 62 7b 13       	call   0x137b:0x62b9
    1291:	50                   	push   ax
    1292:	6a 04                	push   0x4
    1294:	9a ff ff 00 00       	call   0x0:0xffff
    1299:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    129d:	06                   	push   es
    129e:	57                   	push   di
    129f:	9a 03 73 dd 12       	call   0x12dd:0x7303
    12a4:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    12a8:	74 0c                	je     0x12b6
    12aa:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    12ad:	06                   	push   es
    12ae:	57                   	push   di
    12af:	9a 12 14 fe 12       	call   0x12fe:0x1412
    12b4:	eb 1e                	jmp    0x12d4
    12b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    12b9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    12bc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    12bf:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    12c4:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    12c9:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    12cd:	06                   	push   es
    12ce:	57                   	push   di
    12cf:	9a 1a 31 ff ff       	call   0xffff:0x311a
    12d4:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    12d8:	06                   	push   es
    12d9:	57                   	push   di
    12da:	9a 03 73 f3 12       	call   0x12f3:0x7303
    12df:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    12e3:	83 c4 06             	add    sp,0x6
    12e6:	b8 f6 12             	mov    ax,0x12f6
    12e9:	0e                   	push   cs
    12ea:	50                   	push   ax
    12eb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    12ee:	06                   	push   es
    12ef:	57                   	push   di
    12f0:	9a 1d 5f 17 13       	call   0x1317:0x5f1d
    12f5:	cb                   	retf
    12f6:	c9                   	leave
    12f7:	ca 06 00             	retf   0x6
    12fa:	00 00                	add    BYTE PTR [bx+si],al
    12fc:	9f                   	lahf
    12fd:	13 28                	adc    bp,WORD PTR [bx+si]
    12ff:	13 55 89             	adc    dx,WORD PTR [di-0x77]
    1302:	e5 b8                	in     ax,0xb8
    1304:	08 00                	or     BYTE PTR [bx+si],al
    1306:	9a 44 04 bf 13       	call   0x13bf:0x444
    130b:	83 ec 08             	sub    sp,0x8
    130e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1312:	06                   	push   es
    1313:	57                   	push   di
    1314:	9a 03 73 2f 13       	call   0x132f:0x7303
    1319:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    131d:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1321:	b0 01                	mov    al,0x1
    1323:	50                   	push   ax
    1324:	b8 22 00             	mov    ax,0x22
    1327:	ba 53 13             	mov    dx,0x1353
    132a:	52                   	push   dx
    132b:	50                   	push   ax
    132c:	9a 53 25 87 13       	call   0x1387:0x2553
    1331:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1334:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1337:	b8 fa 12             	mov    ax,0x12fa
    133a:	0e                   	push   cs
    133b:	50                   	push   ax
    133c:	55                   	push   bp
    133d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1341:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1345:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1348:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    134b:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    134e:	06                   	push   es
    134f:	57                   	push   di
    1350:	9a a9 0d 6d 13       	call   0x136d:0xda9
    1355:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1358:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    135b:	26 89 85 98 03       	mov    WORD PTR es:[di+0x398],ax
    1360:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1363:	26 89 85 9a 03       	mov    WORD PTR es:[di+0x39a],ax
    1368:	06                   	push   es
    1369:	57                   	push   di
    136a:	9a ab 0e 10 14       	call   0x1410:0xeab
    136f:	6a ff                	push   0xffff
    1371:	6a f0                	push   0xfff0
    1373:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1376:	06                   	push   es
    1377:	57                   	push   di
    1378:	9a d5 1e 6d 16       	call   0x166d:0x1ed5
    137d:	6a 02                	push   0x2
    137f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1382:	06                   	push   es
    1383:	57                   	push   di
    1384:	9a 14 3a 91 13       	call   0x1391:0x3a14
    1389:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    138c:	06                   	push   es
    138d:	57                   	push   di
    138e:	9a 45 5d a7 13       	call   0x13a7:0x5d45
    1393:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1397:	83 c4 06             	add    sp,0x6
    139a:	b8 aa 13             	mov    ax,0x13aa
    139d:	0e                   	push   cs
    139e:	50                   	push   ax
    139f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    13a2:	06                   	push   es
    13a3:	57                   	push   di
    13a4:	9a 1d 5f 9c 39       	call   0x399c:0x5f1d
    13a9:	cb                   	retf
    13aa:	c9                   	leave
    13ab:	ca 04 00             	retf   0x4
    13ae:	00 00                	add    BYTE PTR [bx+si],al
    13b0:	00 00                	add    BYTE PTR [bx+si],al
    13b2:	ff                   	(bad)
    13b3:	ff 00                	inc    WORD PTR [bx+si]
    13b5:	00 55 89             	add    BYTE PTR [di-0x77],dl
    13b8:	e5 b8                	in     ax,0xb8
    13ba:	22 00                	and    al,BYTE PTR [bx+si]
    13bc:	9a 44 04 ef 13       	call   0x13ef:0x444
    13c1:	83 ec 22             	sub    sp,0x22
    13c4:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    13c8:	06                   	push   es
    13c9:	57                   	push   di
    13ca:	9a 04 2a 36 14       	call   0x1436:0x2a04
    13cf:	89 c7                	mov    di,ax
    13d1:	8e c2                	mov    es,dx
    13d3:	06                   	push   es
    13d4:	57                   	push   di
    13d5:	9a d2 21 87 14       	call   0x1487:0x21d2
    13da:	50                   	push   ax
    13db:	8d 7e de             	lea    di,[bp-0x22]
    13de:	16                   	push   ss
    13df:	57                   	push   di
    13e0:	9a ff ff 00 00       	call   0x0:0xffff
    13e5:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    13e8:	99                   	cwd
    13e9:	bf ae 13             	mov    di,0x13ae
    13ec:	9a 16 04 1b 14       	call   0x141b:0x416
    13f1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    13f4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    13f7:	c9                   	leave
    13f8:	ca 02 00             	retf   0x2
    13fb:	00 01                	add    BYTE PTR [bx+di],al
    13fd:	09 01                	or     WORD PTR [bx+di],ax
    13ff:	20 03                	and    BYTE PTR [bp+di],al
    1401:	20 20                	and    BYTE PTR [bx+si],ah
    1403:	20 00                	and    BYTE PTR [bx+si],al
    1405:	80 ff ff             	cmp    bh,0xff
    1408:	ff                   	(bad)
    1409:	7f 00                	jg     0x140b
    140b:	00 00                	add    BYTE PTR [bx+si],al
    140d:	00 4a 18             	add    BYTE PTR [bp+si+0x18],cl
    1410:	2b 14                	sub    dx,WORD PTR [si]
    1412:	55                   	push   bp
    1413:	89 e5                	mov    bp,sp
    1415:	b8 0e 04             	mov    ax,0x40e
    1418:	9a 44 04 41 14       	call   0x1441:0x444
    141d:	81 ec 0e 04          	sub    sp,0x40e
    1421:	6a 01                	push   0x1
    1423:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1426:	06                   	push   es
    1427:	57                   	push   di
    1428:	9a d1 1b 30 16       	call   0x1630:0x1bd1
    142d:	8d be fc fe          	lea    di,[bp-0x104]
    1431:	16                   	push   ss
    1432:	57                   	push   di
    1433:	9a 4e 20 5f 14       	call   0x145f:0x204e
    1438:	8d be fc fe          	lea    di,[bp-0x104]
    143c:	16                   	push   ss
    143d:	57                   	push   di
    143e:	9a f5 09 46 14       	call   0x1446:0x9f5
    1443:	9a 08 04 db 14       	call   0x14db:0x408
    1448:	b8 0c 14             	mov    ax,0x140c
    144b:	0e                   	push   cs
    144c:	50                   	push   ax
    144d:	55                   	push   bp
    144e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1452:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1456:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    145a:	06                   	push   es
    145b:	57                   	push   di
    145c:	9a 04 2a 94 14       	call   0x1494:0x2a04
    1461:	89 c7                	mov    di,ax
    1463:	8e c2                	mov    es,dx
    1465:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    1469:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    146d:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    1471:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    1476:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    147a:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    147e:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1482:	06                   	push   es
    1483:	57                   	push   di
    1484:	9a 99 20 a3 14       	call   0x14a3:0x2099
    1489:	6a 02                	push   0x2
    148b:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    148f:	06                   	push   es
    1490:	57                   	push   di
    1491:	9a 04 2a b0 14       	call   0x14b0:0x2a04
    1496:	89 c7                	mov    di,ax
    1498:	8e c2                	mov    es,dx
    149a:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    149e:	06                   	push   es
    149f:	57                   	push   di
    14a0:	9a 78 12 bf 14       	call   0x14bf:0x1278
    14a5:	6a 0a                	push   0xa
    14a7:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    14ab:	06                   	push   es
    14ac:	57                   	push   di
    14ad:	9a 04 2a ff 15       	call   0x15ff:0x2a04
    14b2:	89 c7                	mov    di,ax
    14b4:	8e c2                	mov    es,dx
    14b6:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    14ba:	06                   	push   es
    14bb:	57                   	push   di
    14bc:	9a f5 11 0e 16       	call   0x160e:0x11f5
    14c1:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    14c6:	eb 03                	jmp    0x14cb
    14c8:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    14cb:	8d be fc fe          	lea    di,[bp-0x104]
    14cf:	16                   	push   ss
    14d0:	57                   	push   di
    14d1:	bf fb 13             	mov    di,0x13fb
    14d4:	0e                   	push   cs
    14d5:	57                   	push   di
    14d6:	6a 00                	push   0x0
    14d8:	9a b5 0d e0 14       	call   0x14e0:0xdb5
    14dd:	9a 78 0c e5 14       	call   0x14e5:0xc78
    14e2:	9a 08 04 13 15       	call   0x1513:0x408
    14e7:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    14eb:	75 db                	jne    0x14c8
    14ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14f0:	26 c4 bd 94 03       	les    di,DWORD PTR es:[di+0x394]
    14f5:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    14f9:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    14fd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1502:	06                   	push   es
    1503:	57                   	push   di
    1504:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1507:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    150b:	2d 01 00             	sub    ax,0x1
    150e:	71 05                	jno    0x1515
    1510:	9a 3e 04 53 15       	call   0x1553:0x43e
    1515:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    1519:	31 c0                	xor    ax,ax
    151b:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    151f:	7e 03                	jle    0x1524
    1521:	e9 c8 00             	jmp    0x15ec
    1524:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1527:	eb 03                	jmp    0x152c
    1529:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    152c:	8d be f0 fc          	lea    di,[bp-0x310]
    1530:	16                   	push   ss
    1531:	57                   	push   di
    1532:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1535:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1539:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    153e:	06                   	push   es
    153f:	57                   	push   di
    1540:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1543:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1547:	8d be fc fd          	lea    di,[bp-0x204]
    154b:	16                   	push   ss
    154c:	57                   	push   di
    154d:	68 ff 00             	push   0xff
    1550:	9a e7 17 63 15       	call   0x1563:0x17e7
    1555:	bf fc 13             	mov    di,0x13fc
    1558:	0e                   	push   cs
    1559:	57                   	push   di
    155a:	8d be fc fd          	lea    di,[bp-0x204]
    155e:	16                   	push   ss
    155f:	57                   	push   di
    1560:	9a 78 18 7c 15       	call   0x157c:0x1878
    1565:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1568:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    156c:	7e 26                	jle    0x1594
    156e:	8d be fc fd          	lea    di,[bp-0x204]
    1572:	16                   	push   ss
    1573:	57                   	push   di
    1574:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1577:	6a 01                	push   0x1
    1579:	9a 75 19 92 15       	call   0x1592:0x1975
    157e:	bf fe 13             	mov    di,0x13fe
    1581:	0e                   	push   cs
    1582:	57                   	push   di
    1583:	8d be fc fd          	lea    di,[bp-0x204]
    1587:	16                   	push   ss
    1588:	57                   	push   di
    1589:	68 ff 00             	push   0xff
    158c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    158f:	9a 16 19 a8 15       	call   0x15a8:0x1916
    1594:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    1598:	75 bb                	jne    0x1555
    159a:	8d be f0 fc          	lea    di,[bp-0x310]
    159e:	16                   	push   ss
    159f:	57                   	push   di
    15a0:	bf 00 14             	mov    di,0x1400
    15a3:	0e                   	push   cs
    15a4:	57                   	push   di
    15a5:	9a cd 17 b3 15       	call   0x15b3:0x17cd
    15aa:	8d be fc fd          	lea    di,[bp-0x204]
    15ae:	16                   	push   ss
    15af:	57                   	push   di
    15b0:	9a 4c 18 c1 15       	call   0x15c1:0x184c
    15b5:	8d be fc fd          	lea    di,[bp-0x204]
    15b9:	16                   	push   ss
    15ba:	57                   	push   di
    15bb:	68 ff 00             	push   0xff
    15be:	9a e7 17 d4 15       	call   0x15d4:0x17e7
    15c3:	8d be fc fe          	lea    di,[bp-0x104]
    15c7:	16                   	push   ss
    15c8:	57                   	push   di
    15c9:	8d be fc fd          	lea    di,[bp-0x204]
    15cd:	16                   	push   ss
    15ce:	57                   	push   di
    15cf:	6a 00                	push   0x0
    15d1:	9a b5 0d d9 15       	call   0x15d9:0xdb5
    15d6:	9a 78 0c de 15       	call   0x15de:0xc78
    15db:	9a 08 04 3a 16       	call   0x163a:0x408
    15e0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    15e3:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    15e7:	74 03                	je     0x15ec
    15e9:	e9 3d ff             	jmp    0x1529
    15ec:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    15f0:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    15f4:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    15f8:	6a 06                	push   0x6
    15fa:	06                   	push   es
    15fb:	57                   	push   di
    15fc:	9a 04 2a 1b 16       	call   0x161b:0x2a04
    1601:	89 c7                	mov    di,ax
    1603:	8e c2                	mov    es,dx
    1605:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1609:	06                   	push   es
    160a:	57                   	push   di
    160b:	9a f5 11 2a 16       	call   0x162a:0x11f5
    1610:	6a 00                	push   0x0
    1612:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1616:	06                   	push   es
    1617:	57                   	push   di
    1618:	9a 04 2a 9e 16       	call   0x169e:0x2a04
    161d:	89 c7                	mov    di,ax
    161f:	8e c2                	mov    es,dx
    1621:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1625:	06                   	push   es
    1626:	57                   	push   di
    1627:	9a 78 12 c5 16       	call   0x16c5:0x1278
    162c:	55                   	push   bp
    162d:	9a b6 13 1a 1c       	call   0x1c1a:0x13b6
    1632:	05 02 00             	add    ax,0x2
    1635:	73 05                	jae    0x163c
    1637:	9a 3e 04 44 16       	call   0x1644:0x43e
    163c:	31 d2                	xor    dx,dx
    163e:	bf 04 14             	mov    di,0x1404
    1641:	9a 16 04 58 16       	call   0x1658:0x416
    1646:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    164a:	8d be f2 fb          	lea    di,[bp-0x40e]
    164e:	16                   	push   ss
    164f:	57                   	push   di
    1650:	bf 00 14             	mov    di,0x1400
    1653:	0e                   	push   cs
    1654:	57                   	push   di
    1655:	9a cd 17 72 16       	call   0x1672:0x17cd
    165a:	8d be f2 fc          	lea    di,[bp-0x30e]
    165e:	16                   	push   ss
    165f:	57                   	push   di
    1660:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1663:	26 c4 bd 7c 03       	les    di,DWORD PTR es:[di+0x37c]
    1668:	06                   	push   es
    1669:	57                   	push   di
    166a:	9a 53 1d ea 16       	call   0x16ea:0x1d53
    166f:	9a 4c 18 80 16       	call   0x1680:0x184c
    1674:	8d be fc fd          	lea    di,[bp-0x204]
    1678:	16                   	push   ss
    1679:	57                   	push   di
    167a:	68 ff 00             	push   0xff
    167d:	9a e7 17 92 16       	call   0x1692:0x17e7
    1682:	6a 00                	push   0x0
    1684:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    1688:	b9 05 00             	mov    cx,0x5
    168b:	f7 e9                	imul   cx
    168d:	71 05                	jno    0x1694
    168f:	9a 3e 04 a8 16       	call   0x16a8:0x43e
    1694:	50                   	push   ax
    1695:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1699:	06                   	push   es
    169a:	57                   	push   di
    169b:	9a 72 2a ba 16       	call   0x16ba:0x2a72
    16a0:	5a                   	pop    dx
    16a1:	2b c2                	sub    ax,dx
    16a3:	71 05                	jno    0x16aa
    16a5:	9a 3e 04 d5 16       	call   0x16d5:0x43e
    16aa:	50                   	push   ax
    16ab:	8d be fc fd          	lea    di,[bp-0x204]
    16af:	16                   	push   ss
    16b0:	57                   	push   di
    16b1:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    16b5:	06                   	push   es
    16b6:	57                   	push   di
    16b7:	9a 04 2a 1b 17       	call   0x171b:0x2a04
    16bc:	89 c7                	mov    di,ax
    16be:	8e c2                	mov    es,dx
    16c0:	06                   	push   es
    16c1:	57                   	push   di
    16c2:	9a 09 1f 42 17       	call   0x1742:0x1f09
    16c7:	8d be f2 fb          	lea    di,[bp-0x40e]
    16cb:	16                   	push   ss
    16cc:	57                   	push   di
    16cd:	bf 00 14             	mov    di,0x1400
    16d0:	0e                   	push   cs
    16d1:	57                   	push   di
    16d2:	9a cd 17 ef 16       	call   0x16ef:0x17cd
    16d7:	8d be f2 fc          	lea    di,[bp-0x30e]
    16db:	16                   	push   ss
    16dc:	57                   	push   di
    16dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16e0:	26 c4 bd 80 03       	les    di,DWORD PTR es:[di+0x380]
    16e5:	06                   	push   es
    16e6:	57                   	push   di
    16e7:	9a 53 1d 67 17       	call   0x1767:0x1d53
    16ec:	9a 4c 18 fd 16       	call   0x16fd:0x184c
    16f1:	8d be fc fd          	lea    di,[bp-0x204]
    16f5:	16                   	push   ss
    16f6:	57                   	push   di
    16f7:	68 ff 00             	push   0xff
    16fa:	9a e7 17 0f 17       	call   0x170f:0x17e7
    16ff:	6a 00                	push   0x0
    1701:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    1705:	b9 04 00             	mov    cx,0x4
    1708:	f7 e9                	imul   cx
    170a:	71 05                	jno    0x1711
    170c:	9a 3e 04 25 17       	call   0x1725:0x43e
    1711:	50                   	push   ax
    1712:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1716:	06                   	push   es
    1717:	57                   	push   di
    1718:	9a 72 2a 37 17       	call   0x1737:0x2a72
    171d:	5a                   	pop    dx
    171e:	2b c2                	sub    ax,dx
    1720:	71 05                	jno    0x1727
    1722:	9a 3e 04 52 17       	call   0x1752:0x43e
    1727:	50                   	push   ax
    1728:	8d be fc fd          	lea    di,[bp-0x204]
    172c:	16                   	push   ss
    172d:	57                   	push   di
    172e:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1732:	06                   	push   es
    1733:	57                   	push   di
    1734:	9a 04 2a 98 17       	call   0x1798:0x2a04
    1739:	89 c7                	mov    di,ax
    173b:	8e c2                	mov    es,dx
    173d:	06                   	push   es
    173e:	57                   	push   di
    173f:	9a 09 1f bf 17       	call   0x17bf:0x1f09
    1744:	8d be f2 fb          	lea    di,[bp-0x40e]
    1748:	16                   	push   ss
    1749:	57                   	push   di
    174a:	bf 00 14             	mov    di,0x1400
    174d:	0e                   	push   cs
    174e:	57                   	push   di
    174f:	9a cd 17 6c 17       	call   0x176c:0x17cd
    1754:	8d be f2 fc          	lea    di,[bp-0x30e]
    1758:	16                   	push   ss
    1759:	57                   	push   di
    175a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    175d:	26 c4 bd 84 03       	les    di,DWORD PTR es:[di+0x384]
    1762:	06                   	push   es
    1763:	57                   	push   di
    1764:	9a 53 1d e4 17       	call   0x17e4:0x1d53
    1769:	9a 4c 18 7a 17       	call   0x177a:0x184c
    176e:	8d be fc fd          	lea    di,[bp-0x204]
    1772:	16                   	push   ss
    1773:	57                   	push   di
    1774:	68 ff 00             	push   0xff
    1777:	9a e7 17 8c 17       	call   0x178c:0x17e7
    177c:	6a 00                	push   0x0
    177e:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    1782:	b9 03 00             	mov    cx,0x3
    1785:	f7 e9                	imul   cx
    1787:	71 05                	jno    0x178e
    1789:	9a 3e 04 a2 17       	call   0x17a2:0x43e
    178e:	50                   	push   ax
    178f:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1793:	06                   	push   es
    1794:	57                   	push   di
    1795:	9a 72 2a b4 17       	call   0x17b4:0x2a72
    179a:	5a                   	pop    dx
    179b:	2b c2                	sub    ax,dx
    179d:	71 05                	jno    0x17a4
    179f:	9a 3e 04 cf 17       	call   0x17cf:0x43e
    17a4:	50                   	push   ax
    17a5:	8d be fc fd          	lea    di,[bp-0x204]
    17a9:	16                   	push   ss
    17aa:	57                   	push   di
    17ab:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    17af:	06                   	push   es
    17b0:	57                   	push   di
    17b1:	9a 04 2a 15 18       	call   0x1815:0x2a04
    17b6:	89 c7                	mov    di,ax
    17b8:	8e c2                	mov    es,dx
    17ba:	06                   	push   es
    17bb:	57                   	push   di
    17bc:	9a 09 1f 3c 18       	call   0x183c:0x1f09
    17c1:	8d be f2 fb          	lea    di,[bp-0x40e]
    17c5:	16                   	push   ss
    17c6:	57                   	push   di
    17c7:	bf 00 14             	mov    di,0x1400
    17ca:	0e                   	push   cs
    17cb:	57                   	push   di
    17cc:	9a cd 17 e9 17       	call   0x17e9:0x17cd
    17d1:	8d be f2 fc          	lea    di,[bp-0x30e]
    17d5:	16                   	push   ss
    17d6:	57                   	push   di
    17d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17da:	26 c4 bd 88 03       	les    di,DWORD PTR es:[di+0x388]
    17df:	06                   	push   es
    17e0:	57                   	push   di
    17e1:	9a 53 1d 5f 19       	call   0x195f:0x1d53
    17e6:	9a 4c 18 f7 17       	call   0x17f7:0x184c
    17eb:	8d be fc fd          	lea    di,[bp-0x204]
    17ef:	16                   	push   ss
    17f0:	57                   	push   di
    17f1:	68 ff 00             	push   0xff
    17f4:	9a e7 17 09 18       	call   0x1809:0x17e7
    17f9:	6a 00                	push   0x0
    17fb:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    17ff:	b9 02 00             	mov    cx,0x2
    1802:	f7 e9                	imul   cx
    1804:	71 05                	jno    0x180b
    1806:	9a 3e 04 1f 18       	call   0x181f:0x43e
    180b:	50                   	push   ax
    180c:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1810:	06                   	push   es
    1811:	57                   	push   di
    1812:	9a 72 2a 31 18       	call   0x1831:0x2a72
    1817:	5a                   	pop    dx
    1818:	2b c2                	sub    ax,dx
    181a:	71 05                	jno    0x1821
    181c:	9a 3e 04 53 18       	call   0x1853:0x43e
    1821:	50                   	push   ax
    1822:	8d be fc fd          	lea    di,[bp-0x204]
    1826:	16                   	push   ss
    1827:	57                   	push   di
    1828:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    182c:	06                   	push   es
    182d:	57                   	push   di
    182e:	9a 04 2a ff ff       	call   0xffff:0x2a04
    1833:	89 c7                	mov    di,ax
    1835:	8e c2                	mov    es,dx
    1837:	06                   	push   es
    1838:	57                   	push   di
    1839:	9a 09 1f 60 33       	call   0x3360:0x1f09
    183e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1842:	83 c4 06             	add    sp,0x6
    1845:	b8 6a 18             	mov    ax,0x186a
    1848:	0e                   	push   cs
    1849:	50                   	push   ax
    184a:	8d be fc fe          	lea    di,[bp-0x104]
    184e:	16                   	push   ss
    184f:	57                   	push   di
    1850:	9a 4f 0a 58 18       	call   0x1858:0xa4f
    1855:	9a 08 04 7b 18       	call   0x187b:0x408
    185a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    185d:	26 c4 bd 94 03       	les    di,DWORD PTR es:[di+0x394]
    1862:	06                   	push   es
    1863:	57                   	push   di
    1864:	9a e3 49 24 19       	call   0x1924:0x49e3
    1869:	cb                   	retf
    186a:	c9                   	leave
    186b:	ca 04 00             	retf   0x4
    186e:	01 09                	add    WORD PTR [bx+di],cx
    1870:	01 20                	add    WORD PTR [bx+si],sp
    1872:	55                   	push   bp
    1873:	89 e5                	mov    bp,sp
    1875:	b8 06 02             	mov    ax,0x206
    1878:	9a 44 04 b6 18       	call   0x18b6:0x444
    187d:	81 ec 06 02          	sub    sp,0x206
    1881:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1884:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    1889:	75 03                	jne    0x188e
    188b:	e9 3a 03             	jmp    0x1bc8
    188e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1893:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    1896:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    189a:	3d 00 00             	cmp    ax,0x0
    189d:	75 32                	jne    0x18d1
    189f:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    18a2:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    18a6:	76 27                	jbe    0x18cf
    18a8:	8d be fe fd          	lea    di,[bp-0x202]
    18ac:	16                   	push   ss
    18ad:	57                   	push   di
    18ae:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    18b1:	06                   	push   es
    18b2:	57                   	push   di
    18b3:	9a cd 17 c0 18       	call   0x18c0:0x17cd
    18b8:	bf 6e 18             	mov    di,0x186e
    18bb:	0e                   	push   cs
    18bc:	57                   	push   di
    18bd:	9a 4c 18 cd 18       	call   0x18cd:0x184c
    18c2:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    18c5:	06                   	push   es
    18c6:	57                   	push   di
    18c7:	ff 76 10             	push   WORD PTR [bp+0x10]
    18ca:	9a e7 17 fd 18       	call   0x18fd:0x17e7
    18cf:	eb 49                	jmp    0x191a
    18d1:	3d 01 00             	cmp    ax,0x1
    18d4:	75 44                	jne    0x191a
    18d6:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    18d9:	26 8a 05             	mov    al,BYTE PTR es:[di]
    18dc:	30 e4                	xor    ah,ah
    18de:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    18e2:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    18e6:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    18e9:	7d 2d                	jge    0x1918
    18eb:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    18ef:	8d be fe fd          	lea    di,[bp-0x202]
    18f3:	16                   	push   ss
    18f4:	57                   	push   di
    18f5:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    18f8:	06                   	push   es
    18f9:	57                   	push   di
    18fa:	9a cd 17 07 19       	call   0x1907:0x17cd
    18ff:	bf 70 18             	mov    di,0x1870
    1902:	0e                   	push   cs
    1903:	57                   	push   di
    1904:	9a 4c 18 14 19       	call   0x1914:0x184c
    1909:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    190c:	06                   	push   es
    190d:	57                   	push   di
    190e:	ff 76 10             	push   WORD PTR [bp+0x10]
    1911:	9a e7 17 2b 19       	call   0x192b:0x17e7
    1916:	eb ca                	jmp    0x18e2
    1918:	eb 00                	jmp    0x191a
    191a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    191d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1920:	bf 0c 01             	mov    di,0x10c
    1923:	b8 3b 19             	mov    ax,0x193b
    1926:	50                   	push   ax
    1927:	57                   	push   di
    1928:	9a 55 22 42 19       	call   0x1942:0x2255
    192d:	08 c0                	or     al,al
    192f:	74 3e                	je     0x196f
    1931:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1934:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1937:	bf 0c 01             	mov    di,0x10c
    193a:	b8 ce 19             	mov    ax,0x19ce
    193d:	50                   	push   ax
    193e:	57                   	push   di
    193f:	9a 73 22 6d 19       	call   0x196d:0x2273
    1944:	89 c7                	mov    di,ax
    1946:	8e c2                	mov    es,dx
    1948:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    194c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1950:	8d be fa fd          	lea    di,[bp-0x206]
    1954:	16                   	push   ss
    1955:	57                   	push   di
    1956:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    195a:	06                   	push   es
    195b:	57                   	push   di
    195c:	9a 53 1d b4 19       	call   0x19b4:0x1d53
    1961:	8d be 00 ff          	lea    di,[bp-0x100]
    1965:	16                   	push   ss
    1966:	57                   	push   di
    1967:	68 ff 00             	push   0xff
    196a:	9a e7 17 80 19       	call   0x1980:0x17e7
    196f:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1972:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1975:	bf ad 0d             	mov    di,0xdad
    1978:	b8 90 19             	mov    ax,0x1990
    197b:	50                   	push   ax
    197c:	57                   	push   di
    197d:	9a 55 22 97 19       	call   0x1997:0x2255
    1982:	08 c0                	or     al,al
    1984:	74 3e                	je     0x19c4
    1986:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1989:	ff 76 0c             	push   WORD PTR [bp+0xc]
    198c:	bf ad 0d             	mov    di,0xdad
    198f:	b8 1c 3a             	mov    ax,0x3a1c
    1992:	50                   	push   ax
    1993:	57                   	push   di
    1994:	9a 73 22 c2 19       	call   0x19c2:0x2273
    1999:	89 c7                	mov    di,ax
    199b:	8e c2                	mov    es,dx
    199d:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    19a1:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    19a5:	8d be fa fd          	lea    di,[bp-0x206]
    19a9:	16                   	push   ss
    19aa:	57                   	push   di
    19ab:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    19af:	06                   	push   es
    19b0:	57                   	push   di
    19b1:	9a 53 1d 09 1a       	call   0x1a09:0x1d53
    19b6:	8d be 00 ff          	lea    di,[bp-0x100]
    19ba:	16                   	push   ss
    19bb:	57                   	push   di
    19bc:	68 ff 00             	push   0xff
    19bf:	9a e7 17 d5 19       	call   0x19d5:0x17e7
    19c4:	ff 76 0e             	push   WORD PTR [bp+0xe]
    19c7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    19ca:	bf 17 06             	mov    di,0x617
    19cd:	b8 e5 19             	mov    ax,0x19e5
    19d0:	50                   	push   ax
    19d1:	57                   	push   di
    19d2:	9a 55 22 ec 19       	call   0x19ec:0x2255
    19d7:	08 c0                	or     al,al
    19d9:	74 3e                	je     0x1a19
    19db:	ff 76 0e             	push   WORD PTR [bp+0xe]
    19de:	ff 76 0c             	push   WORD PTR [bp+0xc]
    19e1:	bf 17 06             	mov    di,0x617
    19e4:	b8 23 1a             	mov    ax,0x1a23
    19e7:	50                   	push   ax
    19e8:	57                   	push   di
    19e9:	9a 73 22 17 1a       	call   0x1a17:0x2273
    19ee:	89 c7                	mov    di,ax
    19f0:	8e c2                	mov    es,dx
    19f2:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    19f6:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    19fa:	8d be fa fd          	lea    di,[bp-0x206]
    19fe:	16                   	push   ss
    19ff:	57                   	push   di
    1a00:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1a04:	06                   	push   es
    1a05:	57                   	push   di
    1a06:	9a 53 1d 5e 1a       	call   0x1a5e:0x1d53
    1a0b:	8d be 00 ff          	lea    di,[bp-0x100]
    1a0f:	16                   	push   ss
    1a10:	57                   	push   di
    1a11:	68 ff 00             	push   0xff
    1a14:	9a e7 17 2a 1a       	call   0x1a2a:0x17e7
    1a19:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1a1c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a1f:	bf 19 2c             	mov    di,0x2c19
    1a22:	b8 3a 1a             	mov    ax,0x1a3a
    1a25:	50                   	push   ax
    1a26:	57                   	push   di
    1a27:	9a 55 22 41 1a       	call   0x1a41:0x2255
    1a2c:	08 c0                	or     al,al
    1a2e:	74 3e                	je     0x1a6e
    1a30:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1a33:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a36:	bf 19 2c             	mov    di,0x2c19
    1a39:	b8 cd 1a             	mov    ax,0x1acd
    1a3c:	50                   	push   ax
    1a3d:	57                   	push   di
    1a3e:	9a 73 22 6c 1a       	call   0x1a6c:0x2273
    1a43:	89 c7                	mov    di,ax
    1a45:	8e c2                	mov    es,dx
    1a47:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1a4b:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1a4f:	8d be fa fd          	lea    di,[bp-0x206]
    1a53:	16                   	push   ss
    1a54:	57                   	push   di
    1a55:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1a59:	06                   	push   es
    1a5a:	57                   	push   di
    1a5b:	9a 53 1d 08 1b       	call   0x1b08:0x1d53
    1a60:	8d be 00 ff          	lea    di,[bp-0x100]
    1a64:	16                   	push   ss
    1a65:	57                   	push   di
    1a66:	68 ff 00             	push   0xff
    1a69:	9a e7 17 7f 1a       	call   0x1a7f:0x17e7
    1a6e:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1a71:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a74:	bf 22 00             	mov    di,0x22
    1a77:	b8 8f 1a             	mov    ax,0x1a8f
    1a7a:	50                   	push   ax
    1a7b:	57                   	push   di
    1a7c:	9a 55 22 96 1a       	call   0x1a96:0x2255
    1a81:	08 c0                	or     al,al
    1a83:	74 3e                	je     0x1ac3
    1a85:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1a88:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a8b:	bf 22 00             	mov    di,0x22
    1a8e:	b8 ff ff             	mov    ax,0xffff
    1a91:	50                   	push   ax
    1a92:	57                   	push   di
    1a93:	9a 73 22 c1 1a       	call   0x1ac1:0x2273
    1a98:	89 c7                	mov    di,ax
    1a9a:	8e c2                	mov    es,dx
    1a9c:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1aa0:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1aa4:	8d be fa fd          	lea    di,[bp-0x206]
    1aa8:	16                   	push   ss
    1aa9:	57                   	push   di
    1aaa:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1aae:	06                   	push   es
    1aaf:	57                   	push   di
    1ab0:	9a 24 15 ff ff       	call   0xffff:0x1524
    1ab5:	8d be 00 ff          	lea    di,[bp-0x100]
    1ab9:	16                   	push   ss
    1aba:	57                   	push   di
    1abb:	68 ff 00             	push   0xff
    1abe:	9a e7 17 d4 1a       	call   0x1ad4:0x17e7
    1ac3:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1ac6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ac9:	bf 90 0b             	mov    di,0xb90
    1acc:	b8 e4 1a             	mov    ax,0x1ae4
    1acf:	50                   	push   ax
    1ad0:	57                   	push   di
    1ad1:	9a 55 22 eb 1a       	call   0x1aeb:0x2255
    1ad6:	08 c0                	or     al,al
    1ad8:	74 3e                	je     0x1b18
    1ada:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1add:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ae0:	bf 90 0b             	mov    di,0xb90
    1ae3:	b8 f5 1b             	mov    ax,0x1bf5
    1ae6:	50                   	push   ax
    1ae7:	57                   	push   di
    1ae8:	9a 73 22 16 1b       	call   0x1b16:0x2273
    1aed:	89 c7                	mov    di,ax
    1aef:	8e c2                	mov    es,dx
    1af1:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1af5:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1af9:	8d be fa fd          	lea    di,[bp-0x206]
    1afd:	16                   	push   ss
    1afe:	57                   	push   di
    1aff:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1b03:	06                   	push   es
    1b04:	57                   	push   di
    1b05:	9a 53 1d 4a 1c       	call   0x1c4a:0x1d53
    1b0a:	8d be 00 ff          	lea    di,[bp-0x100]
    1b0e:	16                   	push   ss
    1b0f:	57                   	push   di
    1b10:	68 ff 00             	push   0xff
    1b13:	9a e7 17 1f 1b       	call   0x1b1f:0x17e7
    1b18:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
    1b1b:	50                   	push   ax
    1b1c:	9a f9 1e 4e 1b       	call   0x1b4e:0x1ef9
    1b21:	3c 47                	cmp    al,0x47
    1b23:	75 2f                	jne    0x1b54
    1b25:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1b2a:	b0 00                	mov    al,0x0
    1b2c:	76 01                	jbe    0x1b2f
    1b2e:	40                   	inc    ax
    1b2f:	8a d0                	mov    dl,al
    1b31:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    1b36:	b0 00                	mov    al,0x0
    1b38:	75 01                	jne    0x1b3b
    1b3a:	40                   	inc    ax
    1b3b:	22 c2                	and    al,dl
    1b3d:	08 c0                	or     al,al
    1b3f:	74 11                	je     0x1b52
    1b41:	8d be 00 ff          	lea    di,[bp-0x100]
    1b45:	16                   	push   ss
    1b46:	57                   	push   di
    1b47:	6a 01                	push   0x1
    1b49:	6a 01                	push   0x1
    1b4b:	9a 75 19 7b 1b       	call   0x1b7b:0x1975
    1b50:	eb d3                	jmp    0x1b25
    1b52:	eb 4c                	jmp    0x1ba0
    1b54:	3c 44                	cmp    al,0x44
    1b56:	75 42                	jne    0x1b9a
    1b58:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    1b5c:	30 e4                	xor    ah,ah
    1b5e:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    1b62:	83 be fe fe 12       	cmp    WORD PTR [bp-0x102],0x12
    1b67:	7d 2f                	jge    0x1b98
    1b69:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    1b6d:	8d be fe fd          	lea    di,[bp-0x202]
    1b71:	16                   	push   ss
    1b72:	57                   	push   di
    1b73:	bf 70 18             	mov    di,0x1870
    1b76:	0e                   	push   cs
    1b77:	57                   	push   di
    1b78:	9a cd 17 86 1b       	call   0x1b86:0x17cd
    1b7d:	8d be 00 ff          	lea    di,[bp-0x100]
    1b81:	16                   	push   ss
    1b82:	57                   	push   di
    1b83:	9a 4c 18 94 1b       	call   0x1b94:0x184c
    1b88:	8d be 00 ff          	lea    di,[bp-0x100]
    1b8c:	16                   	push   ss
    1b8d:	57                   	push   di
    1b8e:	68 ff 00             	push   0xff
    1b91:	9a e7 17 ae 1b       	call   0x1bae:0x17e7
    1b96:	eb ca                	jmp    0x1b62
    1b98:	eb 06                	jmp    0x1ba0
    1b9a:	3c 43                	cmp    al,0x43
    1b9c:	75 02                	jne    0x1ba0
    1b9e:	eb 00                	jmp    0x1ba0
    1ba0:	8d be fe fd          	lea    di,[bp-0x202]
    1ba4:	16                   	push   ss
    1ba5:	57                   	push   di
    1ba6:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1ba9:	06                   	push   es
    1baa:	57                   	push   di
    1bab:	9a cd 17 b9 1b       	call   0x1bb9:0x17cd
    1bb0:	8d be 00 ff          	lea    di,[bp-0x100]
    1bb4:	16                   	push   ss
    1bb5:	57                   	push   di
    1bb6:	9a 4c 18 c6 1b       	call   0x1bc6:0x184c
    1bbb:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1bbe:	06                   	push   es
    1bbf:	57                   	push   di
    1bc0:	ff 76 10             	push   WORD PTR [bp+0x10]
    1bc3:	9a e7 17 da 1b       	call   0x1bda:0x17e7
    1bc8:	c9                   	leave
    1bc9:	ca 10 00             	retf   0x10
    1bcc:	01 09                	add    WORD PTR [bx+di],cx
    1bce:	00 01                	add    BYTE PTR [bx+di],al
    1bd0:	20 55 89             	and    BYTE PTR [di-0x77],dl
    1bd3:	e5 b8                	in     ax,0xb8
    1bd5:	04 03                	add    al,0x3
    1bd7:	9a 44 04 2b 1c       	call   0x1c2b:0x444
    1bdc:	81 ec 04 03          	sub    sp,0x304
    1be0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1be3:	26 c4 bd 94 03       	les    di,DWORD PTR es:[di+0x394]
    1be8:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    1bec:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    1bf0:	06                   	push   es
    1bf1:	57                   	push   di
    1bf2:	9a e3 49 24 3a       	call   0x3a24:0x49e3
    1bf7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1bfc:	8d be 00 ff          	lea    di,[bp-0x100]
    1c00:	16                   	push   ss
    1c01:	57                   	push   di
    1c02:	68 ff 00             	push   0xff
    1c05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c08:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    1c0d:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    1c12:	6a 00                	push   0x0
    1c14:	6a 67                	push   0x67
    1c16:	55                   	push   bp
    1c17:	9a 72 18 b7 1c       	call   0x1cb7:0x1872
    1c1c:	8d be fc fd          	lea    di,[bp-0x204]
    1c20:	16                   	push   ss
    1c21:	57                   	push   di
    1c22:	8d be 00 ff          	lea    di,[bp-0x100]
    1c26:	16                   	push   ss
    1c27:	57                   	push   di
    1c28:	9a cd 17 35 1c       	call   0x1c35:0x17cd
    1c2d:	bf cc 1b             	mov    di,0x1bcc
    1c30:	0e                   	push   cs
    1c31:	57                   	push   di
    1c32:	9a 4c 18 4f 1c       	call   0x1c4f:0x184c
    1c37:	8d be fc fc          	lea    di,[bp-0x304]
    1c3b:	16                   	push   ss
    1c3c:	57                   	push   di
    1c3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c40:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    1c45:	06                   	push   es
    1c46:	57                   	push   di
    1c47:	9a 53 1d e7 1c       	call   0x1ce7:0x1d53
    1c4c:	9a 4c 18 5d 1c       	call   0x1c5d:0x184c
    1c51:	8d be 00 ff          	lea    di,[bp-0x100]
    1c55:	16                   	push   ss
    1c56:	57                   	push   di
    1c57:	68 ff 00             	push   0xff
    1c5a:	9a e7 17 c8 1c       	call   0x1cc8:0x17e7
    1c5f:	8d be 00 ff          	lea    di,[bp-0x100]
    1c63:	16                   	push   ss
    1c64:	57                   	push   di
    1c65:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1c69:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1c6e:	06                   	push   es
    1c6f:	57                   	push   di
    1c70:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c73:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1c77:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    1c7b:	75 17                	jne    0x1c94
    1c7d:	bf ce 1b             	mov    di,0x1bce
    1c80:	0e                   	push   cs
    1c81:	57                   	push   di
    1c82:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1c86:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1c8b:	06                   	push   es
    1c8c:	57                   	push   di
    1c8d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c90:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1c94:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1c99:	8d be 00 ff          	lea    di,[bp-0x100]
    1c9d:	16                   	push   ss
    1c9e:	57                   	push   di
    1c9f:	68 ff 00             	push   0xff
    1ca2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca5:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    1caa:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    1caf:	6a 0a                	push   0xa
    1cb1:	6a 67                	push   0x67
    1cb3:	55                   	push   bp
    1cb4:	9a 72 18 1a 1d       	call   0x1d1a:0x1872
    1cb9:	8d be fc fd          	lea    di,[bp-0x204]
    1cbd:	16                   	push   ss
    1cbe:	57                   	push   di
    1cbf:	8d be 00 ff          	lea    di,[bp-0x100]
    1cc3:	16                   	push   ss
    1cc4:	57                   	push   di
    1cc5:	9a cd 17 d2 1c       	call   0x1cd2:0x17cd
    1cca:	bf cf 1b             	mov    di,0x1bcf
    1ccd:	0e                   	push   cs
    1cce:	57                   	push   di
    1ccf:	9a 4c 18 ec 1c       	call   0x1cec:0x184c
    1cd4:	8d be fc fc          	lea    di,[bp-0x304]
    1cd8:	16                   	push   ss
    1cd9:	57                   	push   di
    1cda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cdd:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    1ce2:	06                   	push   es
    1ce3:	57                   	push   di
    1ce4:	9a 53 1d 6a 1d       	call   0x1d6a:0x1d53
    1ce9:	9a 4c 18 fa 1c       	call   0x1cfa:0x184c
    1cee:	8d be 00 ff          	lea    di,[bp-0x100]
    1cf2:	16                   	push   ss
    1cf3:	57                   	push   di
    1cf4:	68 ff 00             	push   0xff
    1cf7:	9a e7 17 4b 1d       	call   0x1d4b:0x17e7
    1cfc:	8d be 00 ff          	lea    di,[bp-0x100]
    1d00:	16                   	push   ss
    1d01:	57                   	push   di
    1d02:	68 ff 00             	push   0xff
    1d05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d08:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    1d0d:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    1d12:	6a 23                	push   0x23
    1d14:	6a 67                	push   0x67
    1d16:	55                   	push   bp
    1d17:	9a 72 18 3a 1d       	call   0x1d3a:0x1872
    1d1c:	8d be 00 ff          	lea    di,[bp-0x100]
    1d20:	16                   	push   ss
    1d21:	57                   	push   di
    1d22:	68 ff 00             	push   0xff
    1d25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d28:	26 ff b5 96 01       	push   WORD PTR es:[di+0x196]
    1d2d:	26 ff b5 94 01       	push   WORD PTR es:[di+0x194]
    1d32:	6a 46                	push   0x46
    1d34:	6a 67                	push   0x67
    1d36:	55                   	push   bp
    1d37:	9a 72 18 d9 1d       	call   0x1dd9:0x1872
    1d3c:	8d be fc fd          	lea    di,[bp-0x204]
    1d40:	16                   	push   ss
    1d41:	57                   	push   di
    1d42:	8d be 00 ff          	lea    di,[bp-0x100]
    1d46:	16                   	push   ss
    1d47:	57                   	push   di
    1d48:	9a cd 17 55 1d       	call   0x1d55:0x17cd
    1d4d:	bf cf 1b             	mov    di,0x1bcf
    1d50:	0e                   	push   cs
    1d51:	57                   	push   di
    1d52:	9a 4c 18 6f 1d       	call   0x1d6f:0x184c
    1d57:	8d be fc fc          	lea    di,[bp-0x304]
    1d5b:	16                   	push   ss
    1d5c:	57                   	push   di
    1d5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d60:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    1d65:	06                   	push   es
    1d66:	57                   	push   di
    1d67:	9a 53 1d 84 39       	call   0x3984:0x1d53
    1d6c:	9a 4c 18 7d 1d       	call   0x1d7d:0x184c
    1d71:	8d be 00 ff          	lea    di,[bp-0x100]
    1d75:	16                   	push   ss
    1d76:	57                   	push   di
    1d77:	68 ff 00             	push   0xff
    1d7a:	9a e7 17 4b 2e       	call   0x2e4b:0x17e7
    1d7f:	8d be 00 ff          	lea    di,[bp-0x100]
    1d83:	16                   	push   ss
    1d84:	57                   	push   di
    1d85:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1d89:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1d8e:	06                   	push   es
    1d8f:	57                   	push   di
    1d90:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d93:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1d97:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    1d9b:	75 17                	jne    0x1db4
    1d9d:	bf ce 1b             	mov    di,0x1bce
    1da0:	0e                   	push   cs
    1da1:	57                   	push   di
    1da2:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1da6:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1dab:	06                   	push   es
    1dac:	57                   	push   di
    1dad:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1db0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1db4:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1db9:	8d be 00 ff          	lea    di,[bp-0x100]
    1dbd:	16                   	push   ss
    1dbe:	57                   	push   di
    1dbf:	68 ff 00             	push   0xff
    1dc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dc5:	26 ff b5 ca 01       	push   WORD PTR es:[di+0x1ca]
    1dca:	26 ff b5 c8 01       	push   WORD PTR es:[di+0x1c8]
    1dcf:	ff 36 6a 03          	push   WORD PTR ds:0x36a
    1dd3:	6a 67                	push   0x67
    1dd5:	55                   	push   bp
    1dd6:	9a 72 18 1f 1e       	call   0x1e1f:0x1872
    1ddb:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1de0:	76 18                	jbe    0x1dfa
    1de2:	8d be 00 ff          	lea    di,[bp-0x100]
    1de6:	16                   	push   ss
    1de7:	57                   	push   di
    1de8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1dec:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1df1:	06                   	push   es
    1df2:	57                   	push   di
    1df3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1df6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1dfa:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1dff:	8d be 00 ff          	lea    di,[bp-0x100]
    1e03:	16                   	push   ss
    1e04:	57                   	push   di
    1e05:	68 ff 00             	push   0xff
    1e08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e0b:	26 ff b5 d2 01       	push   WORD PTR es:[di+0x1d2]
    1e10:	26 ff b5 d0 01       	push   WORD PTR es:[di+0x1d0]
    1e15:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    1e19:	6a 67                	push   0x67
    1e1b:	55                   	push   bp
    1e1c:	9a 72 18 41 1e       	call   0x1e41:0x1872
    1e21:	8d be 00 ff          	lea    di,[bp-0x100]
    1e25:	16                   	push   ss
    1e26:	57                   	push   di
    1e27:	68 ff 00             	push   0xff
    1e2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e2d:	26 ff b5 da 01       	push   WORD PTR es:[di+0x1da]
    1e32:	26 ff b5 d8 01       	push   WORD PTR es:[di+0x1d8]
    1e37:	ff 36 70 03          	push   WORD PTR ds:0x370
    1e3b:	6a 64                	push   0x64
    1e3d:	55                   	push   bp
    1e3e:	9a 72 18 87 1e       	call   0x1e87:0x1872
    1e43:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1e48:	76 18                	jbe    0x1e62
    1e4a:	8d be 00 ff          	lea    di,[bp-0x100]
    1e4e:	16                   	push   ss
    1e4f:	57                   	push   di
    1e50:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1e54:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1e59:	06                   	push   es
    1e5a:	57                   	push   di
    1e5b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e5e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1e62:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1e67:	8d be 00 ff          	lea    di,[bp-0x100]
    1e6b:	16                   	push   ss
    1e6c:	57                   	push   di
    1e6d:	68 ff 00             	push   0xff
    1e70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e73:	26 ff b5 d6 01       	push   WORD PTR es:[di+0x1d6]
    1e78:	26 ff b5 d4 01       	push   WORD PTR es:[di+0x1d4]
    1e7d:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    1e81:	6a 67                	push   0x67
    1e83:	55                   	push   bp
    1e84:	9a 72 18 a9 1e       	call   0x1ea9:0x1872
    1e89:	8d be 00 ff          	lea    di,[bp-0x100]
    1e8d:	16                   	push   ss
    1e8e:	57                   	push   di
    1e8f:	68 ff 00             	push   0xff
    1e92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e95:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    1e9a:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    1e9f:	ff 36 70 03          	push   WORD PTR ds:0x370
    1ea3:	6a 64                	push   0x64
    1ea5:	55                   	push   bp
    1ea6:	9a 72 18 ef 1e       	call   0x1eef:0x1872
    1eab:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1eb0:	76 18                	jbe    0x1eca
    1eb2:	8d be 00 ff          	lea    di,[bp-0x100]
    1eb6:	16                   	push   ss
    1eb7:	57                   	push   di
    1eb8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1ebc:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1ec1:	06                   	push   es
    1ec2:	57                   	push   di
    1ec3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ec6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1eca:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1ecf:	8d be 00 ff          	lea    di,[bp-0x100]
    1ed3:	16                   	push   ss
    1ed4:	57                   	push   di
    1ed5:	68 ff 00             	push   0xff
    1ed8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1edb:	26 ff b5 e6 01       	push   WORD PTR es:[di+0x1e6]
    1ee0:	26 ff b5 e4 01       	push   WORD PTR es:[di+0x1e4]
    1ee5:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    1ee9:	6a 67                	push   0x67
    1eeb:	55                   	push   bp
    1eec:	9a 72 18 11 1f       	call   0x1f11:0x1872
    1ef1:	8d be 00 ff          	lea    di,[bp-0x100]
    1ef5:	16                   	push   ss
    1ef6:	57                   	push   di
    1ef7:	68 ff 00             	push   0xff
    1efa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1efd:	26 ff b5 ee 01       	push   WORD PTR es:[di+0x1ee]
    1f02:	26 ff b5 ec 01       	push   WORD PTR es:[di+0x1ec]
    1f07:	ff 36 70 03          	push   WORD PTR ds:0x370
    1f0b:	6a 64                	push   0x64
    1f0d:	55                   	push   bp
    1f0e:	9a 72 18 57 1f       	call   0x1f57:0x1872
    1f13:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1f18:	76 18                	jbe    0x1f32
    1f1a:	8d be 00 ff          	lea    di,[bp-0x100]
    1f1e:	16                   	push   ss
    1f1f:	57                   	push   di
    1f20:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1f24:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1f29:	06                   	push   es
    1f2a:	57                   	push   di
    1f2b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f2e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1f32:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1f37:	8d be 00 ff          	lea    di,[bp-0x100]
    1f3b:	16                   	push   ss
    1f3c:	57                   	push   di
    1f3d:	68 ff 00             	push   0xff
    1f40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f43:	26 ff b5 ea 01       	push   WORD PTR es:[di+0x1ea]
    1f48:	26 ff b5 e8 01       	push   WORD PTR es:[di+0x1e8]
    1f4d:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    1f51:	6a 67                	push   0x67
    1f53:	55                   	push   bp
    1f54:	9a 72 18 79 1f       	call   0x1f79:0x1872
    1f59:	8d be 00 ff          	lea    di,[bp-0x100]
    1f5d:	16                   	push   ss
    1f5e:	57                   	push   di
    1f5f:	68 ff 00             	push   0xff
    1f62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f65:	26 ff b5 f2 01       	push   WORD PTR es:[di+0x1f2]
    1f6a:	26 ff b5 f0 01       	push   WORD PTR es:[di+0x1f0]
    1f6f:	ff 36 70 03          	push   WORD PTR ds:0x370
    1f73:	6a 64                	push   0x64
    1f75:	55                   	push   bp
    1f76:	9a 72 18 bf 1f       	call   0x1fbf:0x1872
    1f7b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1f80:	76 18                	jbe    0x1f9a
    1f82:	8d be 00 ff          	lea    di,[bp-0x100]
    1f86:	16                   	push   ss
    1f87:	57                   	push   di
    1f88:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1f8c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1f91:	06                   	push   es
    1f92:	57                   	push   di
    1f93:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f96:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1f9a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1f9f:	8d be 00 ff          	lea    di,[bp-0x100]
    1fa3:	16                   	push   ss
    1fa4:	57                   	push   di
    1fa5:	68 ff 00             	push   0xff
    1fa8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fab:	26 ff b5 fa 01       	push   WORD PTR es:[di+0x1fa]
    1fb0:	26 ff b5 f8 01       	push   WORD PTR es:[di+0x1f8]
    1fb5:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    1fb9:	6a 67                	push   0x67
    1fbb:	55                   	push   bp
    1fbc:	9a 72 18 e1 1f       	call   0x1fe1:0x1872
    1fc1:	8d be 00 ff          	lea    di,[bp-0x100]
    1fc5:	16                   	push   ss
    1fc6:	57                   	push   di
    1fc7:	68 ff 00             	push   0xff
    1fca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fcd:	26 ff b5 fe 01       	push   WORD PTR es:[di+0x1fe]
    1fd2:	26 ff b5 fc 01       	push   WORD PTR es:[di+0x1fc]
    1fd7:	ff 36 70 03          	push   WORD PTR ds:0x370
    1fdb:	6a 64                	push   0x64
    1fdd:	55                   	push   bp
    1fde:	9a 72 18 44 20       	call   0x2044:0x1872
    1fe3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    1fe8:	76 18                	jbe    0x2002
    1fea:	8d be 00 ff          	lea    di,[bp-0x100]
    1fee:	16                   	push   ss
    1fef:	57                   	push   di
    1ff0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    1ff4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1ff9:	06                   	push   es
    1ffa:	57                   	push   di
    1ffb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ffe:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2002:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    2006:	75 17                	jne    0x201f
    2008:	bf ce 1b             	mov    di,0x1bce
    200b:	0e                   	push   cs
    200c:	57                   	push   di
    200d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2011:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2016:	06                   	push   es
    2017:	57                   	push   di
    2018:	26 c4 3d             	les    di,DWORD PTR es:[di]
    201b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    201f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2024:	8d be 00 ff          	lea    di,[bp-0x100]
    2028:	16                   	push   ss
    2029:	57                   	push   di
    202a:	68 ff 00             	push   0xff
    202d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2030:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    2035:	26 ff b5 00 02       	push   WORD PTR es:[di+0x200]
    203a:	ff 36 6a 03          	push   WORD PTR ds:0x36a
    203e:	6a 67                	push   0x67
    2040:	55                   	push   bp
    2041:	9a 72 18 8a 20       	call   0x208a:0x1872
    2046:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    204b:	76 18                	jbe    0x2065
    204d:	8d be 00 ff          	lea    di,[bp-0x100]
    2051:	16                   	push   ss
    2052:	57                   	push   di
    2053:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2057:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    205c:	06                   	push   es
    205d:	57                   	push   di
    205e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2061:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2065:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    206a:	8d be 00 ff          	lea    di,[bp-0x100]
    206e:	16                   	push   ss
    206f:	57                   	push   di
    2070:	68 ff 00             	push   0xff
    2073:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2076:	26 ff b5 06 02       	push   WORD PTR es:[di+0x206]
    207b:	26 ff b5 04 02       	push   WORD PTR es:[di+0x204]
    2080:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2084:	6a 67                	push   0x67
    2086:	55                   	push   bp
    2087:	9a 72 18 ac 20       	call   0x20ac:0x1872
    208c:	8d be 00 ff          	lea    di,[bp-0x100]
    2090:	16                   	push   ss
    2091:	57                   	push   di
    2092:	68 ff 00             	push   0xff
    2095:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2098:	26 ff b5 0e 02       	push   WORD PTR es:[di+0x20e]
    209d:	26 ff b5 0c 02       	push   WORD PTR es:[di+0x20c]
    20a2:	ff 36 70 03          	push   WORD PTR ds:0x370
    20a6:	6a 64                	push   0x64
    20a8:	55                   	push   bp
    20a9:	9a 72 18 f2 20       	call   0x20f2:0x1872
    20ae:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    20b3:	76 18                	jbe    0x20cd
    20b5:	8d be 00 ff          	lea    di,[bp-0x100]
    20b9:	16                   	push   ss
    20ba:	57                   	push   di
    20bb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    20bf:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    20c4:	06                   	push   es
    20c5:	57                   	push   di
    20c6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20c9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    20cd:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    20d2:	8d be 00 ff          	lea    di,[bp-0x100]
    20d6:	16                   	push   ss
    20d7:	57                   	push   di
    20d8:	68 ff 00             	push   0xff
    20db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20de:	26 ff b5 0a 02       	push   WORD PTR es:[di+0x20a]
    20e3:	26 ff b5 08 02       	push   WORD PTR es:[di+0x208]
    20e8:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    20ec:	6a 67                	push   0x67
    20ee:	55                   	push   bp
    20ef:	9a 72 18 14 21       	call   0x2114:0x1872
    20f4:	8d be 00 ff          	lea    di,[bp-0x100]
    20f8:	16                   	push   ss
    20f9:	57                   	push   di
    20fa:	68 ff 00             	push   0xff
    20fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2100:	26 ff b5 12 02       	push   WORD PTR es:[di+0x212]
    2105:	26 ff b5 10 02       	push   WORD PTR es:[di+0x210]
    210a:	ff 36 70 03          	push   WORD PTR ds:0x370
    210e:	6a 64                	push   0x64
    2110:	55                   	push   bp
    2111:	9a 72 18 5a 21       	call   0x215a:0x1872
    2116:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    211b:	76 18                	jbe    0x2135
    211d:	8d be 00 ff          	lea    di,[bp-0x100]
    2121:	16                   	push   ss
    2122:	57                   	push   di
    2123:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2127:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    212c:	06                   	push   es
    212d:	57                   	push   di
    212e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2131:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2135:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    213a:	8d be 00 ff          	lea    di,[bp-0x100]
    213e:	16                   	push   ss
    213f:	57                   	push   di
    2140:	68 ff 00             	push   0xff
    2143:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2146:	26 ff b5 8e 03       	push   WORD PTR es:[di+0x38e]
    214b:	26 ff b5 8c 03       	push   WORD PTR es:[di+0x38c]
    2150:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2154:	6a 67                	push   0x67
    2156:	55                   	push   bp
    2157:	9a 72 18 7c 21       	call   0x217c:0x1872
    215c:	8d be 00 ff          	lea    di,[bp-0x100]
    2160:	16                   	push   ss
    2161:	57                   	push   di
    2162:	68 ff 00             	push   0xff
    2165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2168:	26 ff b5 92 03       	push   WORD PTR es:[di+0x392]
    216d:	26 ff b5 90 03       	push   WORD PTR es:[di+0x390]
    2172:	ff 36 70 03          	push   WORD PTR ds:0x370
    2176:	6a 64                	push   0x64
    2178:	55                   	push   bp
    2179:	9a 72 18 df 21       	call   0x21df:0x1872
    217e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2183:	76 18                	jbe    0x219d
    2185:	8d be 00 ff          	lea    di,[bp-0x100]
    2189:	16                   	push   ss
    218a:	57                   	push   di
    218b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    218f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2194:	06                   	push   es
    2195:	57                   	push   di
    2196:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2199:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    219d:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    21a1:	75 17                	jne    0x21ba
    21a3:	bf ce 1b             	mov    di,0x1bce
    21a6:	0e                   	push   cs
    21a7:	57                   	push   di
    21a8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    21ac:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    21b1:	06                   	push   es
    21b2:	57                   	push   di
    21b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21b6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    21ba:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    21bf:	8d be 00 ff          	lea    di,[bp-0x100]
    21c3:	16                   	push   ss
    21c4:	57                   	push   di
    21c5:	68 ff 00             	push   0xff
    21c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21cb:	26 ff b5 1e 02       	push   WORD PTR es:[di+0x21e]
    21d0:	26 ff b5 1c 02       	push   WORD PTR es:[di+0x21c]
    21d5:	ff 36 6a 03          	push   WORD PTR ds:0x36a
    21d9:	6a 67                	push   0x67
    21db:	55                   	push   bp
    21dc:	9a 72 18 01 22       	call   0x2201:0x1872
    21e1:	8d be 00 ff          	lea    di,[bp-0x100]
    21e5:	16                   	push   ss
    21e6:	57                   	push   di
    21e7:	68 ff 00             	push   0xff
    21ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ed:	26 ff b5 26 02       	push   WORD PTR es:[di+0x226]
    21f2:	26 ff b5 24 02       	push   WORD PTR es:[di+0x224]
    21f7:	ff 36 70 03          	push   WORD PTR ds:0x370
    21fb:	6a 64                	push   0x64
    21fd:	55                   	push   bp
    21fe:	9a 72 18 23 22       	call   0x2223:0x1872
    2203:	8d be 00 ff          	lea    di,[bp-0x100]
    2207:	16                   	push   ss
    2208:	57                   	push   di
    2209:	68 ff 00             	push   0xff
    220c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    220f:	26 ff b5 4e 02       	push   WORD PTR es:[di+0x24e]
    2214:	26 ff b5 4c 02       	push   WORD PTR es:[di+0x24c]
    2219:	ff 36 72 03          	push   WORD PTR ds:0x372
    221d:	6a 64                	push   0x64
    221f:	55                   	push   bp
    2220:	9a 72 18 69 22       	call   0x2269:0x1872
    2225:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    222a:	76 18                	jbe    0x2244
    222c:	8d be 00 ff          	lea    di,[bp-0x100]
    2230:	16                   	push   ss
    2231:	57                   	push   di
    2232:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2236:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    223b:	06                   	push   es
    223c:	57                   	push   di
    223d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2240:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2244:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2249:	8d be 00 ff          	lea    di,[bp-0x100]
    224d:	16                   	push   ss
    224e:	57                   	push   di
    224f:	68 ff 00             	push   0xff
    2252:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2255:	26 ff b5 36 02       	push   WORD PTR es:[di+0x236]
    225a:	26 ff b5 34 02       	push   WORD PTR es:[di+0x234]
    225f:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2263:	6a 67                	push   0x67
    2265:	55                   	push   bp
    2266:	9a 72 18 8b 22       	call   0x228b:0x1872
    226b:	8d be 00 ff          	lea    di,[bp-0x100]
    226f:	16                   	push   ss
    2270:	57                   	push   di
    2271:	68 ff 00             	push   0xff
    2274:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2277:	26 ff b5 3a 02       	push   WORD PTR es:[di+0x23a]
    227c:	26 ff b5 38 02       	push   WORD PTR es:[di+0x238]
    2281:	ff 36 70 03          	push   WORD PTR ds:0x370
    2285:	6a 64                	push   0x64
    2287:	55                   	push   bp
    2288:	9a 72 18 ad 22       	call   0x22ad:0x1872
    228d:	8d be 00 ff          	lea    di,[bp-0x100]
    2291:	16                   	push   ss
    2292:	57                   	push   di
    2293:	68 ff 00             	push   0xff
    2296:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2299:	26 ff b5 52 02       	push   WORD PTR es:[di+0x252]
    229e:	26 ff b5 50 02       	push   WORD PTR es:[di+0x250]
    22a3:	ff 36 72 03          	push   WORD PTR ds:0x372
    22a7:	6a 64                	push   0x64
    22a9:	55                   	push   bp
    22aa:	9a 72 18 f3 22       	call   0x22f3:0x1872
    22af:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    22b4:	76 18                	jbe    0x22ce
    22b6:	8d be 00 ff          	lea    di,[bp-0x100]
    22ba:	16                   	push   ss
    22bb:	57                   	push   di
    22bc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    22c0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    22c5:	06                   	push   es
    22c6:	57                   	push   di
    22c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22ca:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    22ce:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    22d3:	8d be 00 ff          	lea    di,[bp-0x100]
    22d7:	16                   	push   ss
    22d8:	57                   	push   di
    22d9:	68 ff 00             	push   0xff
    22dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22df:	26 ff b5 32 02       	push   WORD PTR es:[di+0x232]
    22e4:	26 ff b5 30 02       	push   WORD PTR es:[di+0x230]
    22e9:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    22ed:	6a 67                	push   0x67
    22ef:	55                   	push   bp
    22f0:	9a 72 18 15 23       	call   0x2315:0x1872
    22f5:	8d be 00 ff          	lea    di,[bp-0x100]
    22f9:	16                   	push   ss
    22fa:	57                   	push   di
    22fb:	68 ff 00             	push   0xff
    22fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2301:	26 ff b5 3e 02       	push   WORD PTR es:[di+0x23e]
    2306:	26 ff b5 3c 02       	push   WORD PTR es:[di+0x23c]
    230b:	ff 36 70 03          	push   WORD PTR ds:0x370
    230f:	6a 64                	push   0x64
    2311:	55                   	push   bp
    2312:	9a 72 18 37 23       	call   0x2337:0x1872
    2317:	8d be 00 ff          	lea    di,[bp-0x100]
    231b:	16                   	push   ss
    231c:	57                   	push   di
    231d:	68 ff 00             	push   0xff
    2320:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2323:	26 ff b5 56 02       	push   WORD PTR es:[di+0x256]
    2328:	26 ff b5 54 02       	push   WORD PTR es:[di+0x254]
    232d:	ff 36 72 03          	push   WORD PTR ds:0x372
    2331:	6a 64                	push   0x64
    2333:	55                   	push   bp
    2334:	9a 72 18 7d 23       	call   0x237d:0x1872
    2339:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    233e:	76 18                	jbe    0x2358
    2340:	8d be 00 ff          	lea    di,[bp-0x100]
    2344:	16                   	push   ss
    2345:	57                   	push   di
    2346:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    234a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    234f:	06                   	push   es
    2350:	57                   	push   di
    2351:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2354:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2358:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    235d:	8d be 00 ff          	lea    di,[bp-0x100]
    2361:	16                   	push   ss
    2362:	57                   	push   di
    2363:	68 ff 00             	push   0xff
    2366:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2369:	26 ff b5 2e 02       	push   WORD PTR es:[di+0x22e]
    236e:	26 ff b5 2c 02       	push   WORD PTR es:[di+0x22c]
    2373:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2377:	6a 67                	push   0x67
    2379:	55                   	push   bp
    237a:	9a 72 18 9f 23       	call   0x239f:0x1872
    237f:	8d be 00 ff          	lea    di,[bp-0x100]
    2383:	16                   	push   ss
    2384:	57                   	push   di
    2385:	68 ff 00             	push   0xff
    2388:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    238b:	26 ff b5 42 02       	push   WORD PTR es:[di+0x242]
    2390:	26 ff b5 40 02       	push   WORD PTR es:[di+0x240]
    2395:	ff 36 70 03          	push   WORD PTR ds:0x370
    2399:	6a 64                	push   0x64
    239b:	55                   	push   bp
    239c:	9a 72 18 c1 23       	call   0x23c1:0x1872
    23a1:	8d be 00 ff          	lea    di,[bp-0x100]
    23a5:	16                   	push   ss
    23a6:	57                   	push   di
    23a7:	68 ff 00             	push   0xff
    23aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ad:	26 ff b5 5a 02       	push   WORD PTR es:[di+0x25a]
    23b2:	26 ff b5 58 02       	push   WORD PTR es:[di+0x258]
    23b7:	ff 36 72 03          	push   WORD PTR ds:0x372
    23bb:	6a 64                	push   0x64
    23bd:	55                   	push   bp
    23be:	9a 72 18 07 24       	call   0x2407:0x1872
    23c3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    23c8:	76 18                	jbe    0x23e2
    23ca:	8d be 00 ff          	lea    di,[bp-0x100]
    23ce:	16                   	push   ss
    23cf:	57                   	push   di
    23d0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    23d4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    23d9:	06                   	push   es
    23da:	57                   	push   di
    23db:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23de:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    23e2:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    23e7:	8d be 00 ff          	lea    di,[bp-0x100]
    23eb:	16                   	push   ss
    23ec:	57                   	push   di
    23ed:	68 ff 00             	push   0xff
    23f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23f3:	26 ff b5 2a 02       	push   WORD PTR es:[di+0x22a]
    23f8:	26 ff b5 28 02       	push   WORD PTR es:[di+0x228]
    23fd:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2401:	6a 67                	push   0x67
    2403:	55                   	push   bp
    2404:	9a 72 18 29 24       	call   0x2429:0x1872
    2409:	8d be 00 ff          	lea    di,[bp-0x100]
    240d:	16                   	push   ss
    240e:	57                   	push   di
    240f:	68 ff 00             	push   0xff
    2412:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2415:	26 ff b5 46 02       	push   WORD PTR es:[di+0x246]
    241a:	26 ff b5 44 02       	push   WORD PTR es:[di+0x244]
    241f:	ff 36 70 03          	push   WORD PTR ds:0x370
    2423:	6a 64                	push   0x64
    2425:	55                   	push   bp
    2426:	9a 72 18 4b 24       	call   0x244b:0x1872
    242b:	8d be 00 ff          	lea    di,[bp-0x100]
    242f:	16                   	push   ss
    2430:	57                   	push   di
    2431:	68 ff 00             	push   0xff
    2434:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2437:	26 ff b5 5e 02       	push   WORD PTR es:[di+0x25e]
    243c:	26 ff b5 5c 02       	push   WORD PTR es:[di+0x25c]
    2441:	ff 36 72 03          	push   WORD PTR ds:0x372
    2445:	6a 64                	push   0x64
    2447:	55                   	push   bp
    2448:	9a 72 18 ae 24       	call   0x24ae:0x1872
    244d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2452:	76 18                	jbe    0x246c
    2454:	8d be 00 ff          	lea    di,[bp-0x100]
    2458:	16                   	push   ss
    2459:	57                   	push   di
    245a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    245e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2463:	06                   	push   es
    2464:	57                   	push   di
    2465:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2468:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    246c:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    2470:	75 17                	jne    0x2489
    2472:	bf ce 1b             	mov    di,0x1bce
    2475:	0e                   	push   cs
    2476:	57                   	push   di
    2477:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    247b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2480:	06                   	push   es
    2481:	57                   	push   di
    2482:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2485:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2489:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    248e:	8d be 00 ff          	lea    di,[bp-0x100]
    2492:	16                   	push   ss
    2493:	57                   	push   di
    2494:	68 ff 00             	push   0xff
    2497:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    249a:	26 ff b5 62 02       	push   WORD PTR es:[di+0x262]
    249f:	26 ff b5 60 02       	push   WORD PTR es:[di+0x260]
    24a4:	ff 36 6a 03          	push   WORD PTR ds:0x36a
    24a8:	6a 67                	push   0x67
    24aa:	55                   	push   bp
    24ab:	9a 72 18 d0 24       	call   0x24d0:0x1872
    24b0:	8d be 00 ff          	lea    di,[bp-0x100]
    24b4:	16                   	push   ss
    24b5:	57                   	push   di
    24b6:	68 ff 00             	push   0xff
    24b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24bc:	26 ff b5 6a 02       	push   WORD PTR es:[di+0x26a]
    24c1:	26 ff b5 68 02       	push   WORD PTR es:[di+0x268]
    24c6:	ff 36 70 03          	push   WORD PTR ds:0x370
    24ca:	6a 64                	push   0x64
    24cc:	55                   	push   bp
    24cd:	9a 72 18 f2 24       	call   0x24f2:0x1872
    24d2:	8d be 00 ff          	lea    di,[bp-0x100]
    24d6:	16                   	push   ss
    24d7:	57                   	push   di
    24d8:	68 ff 00             	push   0xff
    24db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24de:	26 ff b5 9a 02       	push   WORD PTR es:[di+0x29a]
    24e3:	26 ff b5 98 02       	push   WORD PTR es:[di+0x298]
    24e8:	ff 36 72 03          	push   WORD PTR ds:0x372
    24ec:	6a 64                	push   0x64
    24ee:	55                   	push   bp
    24ef:	9a 72 18 38 25       	call   0x2538:0x1872
    24f4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    24f9:	76 18                	jbe    0x2513
    24fb:	8d be 00 ff          	lea    di,[bp-0x100]
    24ff:	16                   	push   ss
    2500:	57                   	push   di
    2501:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2505:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    250a:	06                   	push   es
    250b:	57                   	push   di
    250c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    250f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2513:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2518:	8d be 00 ff          	lea    di,[bp-0x100]
    251c:	16                   	push   ss
    251d:	57                   	push   di
    251e:	68 ff 00             	push   0xff
    2521:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2524:	26 ff b5 7e 02       	push   WORD PTR es:[di+0x27e]
    2529:	26 ff b5 7c 02       	push   WORD PTR es:[di+0x27c]
    252e:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2532:	6a 67                	push   0x67
    2534:	55                   	push   bp
    2535:	9a 72 18 5a 25       	call   0x255a:0x1872
    253a:	8d be 00 ff          	lea    di,[bp-0x100]
    253e:	16                   	push   ss
    253f:	57                   	push   di
    2540:	68 ff 00             	push   0xff
    2543:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2546:	26 ff b5 82 02       	push   WORD PTR es:[di+0x282]
    254b:	26 ff b5 80 02       	push   WORD PTR es:[di+0x280]
    2550:	ff 36 70 03          	push   WORD PTR ds:0x370
    2554:	6a 64                	push   0x64
    2556:	55                   	push   bp
    2557:	9a 72 18 7c 25       	call   0x257c:0x1872
    255c:	8d be 00 ff          	lea    di,[bp-0x100]
    2560:	16                   	push   ss
    2561:	57                   	push   di
    2562:	68 ff 00             	push   0xff
    2565:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2568:	26 ff b5 9e 02       	push   WORD PTR es:[di+0x29e]
    256d:	26 ff b5 9c 02       	push   WORD PTR es:[di+0x29c]
    2572:	ff 36 72 03          	push   WORD PTR ds:0x372
    2576:	6a 64                	push   0x64
    2578:	55                   	push   bp
    2579:	9a 72 18 c2 25       	call   0x25c2:0x1872
    257e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2583:	76 18                	jbe    0x259d
    2585:	8d be 00 ff          	lea    di,[bp-0x100]
    2589:	16                   	push   ss
    258a:	57                   	push   di
    258b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    258f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2594:	06                   	push   es
    2595:	57                   	push   di
    2596:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2599:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    259d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    25a2:	8d be 00 ff          	lea    di,[bp-0x100]
    25a6:	16                   	push   ss
    25a7:	57                   	push   di
    25a8:	68 ff 00             	push   0xff
    25ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25ae:	26 ff b5 7a 02       	push   WORD PTR es:[di+0x27a]
    25b3:	26 ff b5 78 02       	push   WORD PTR es:[di+0x278]
    25b8:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    25bc:	6a 67                	push   0x67
    25be:	55                   	push   bp
    25bf:	9a 72 18 e4 25       	call   0x25e4:0x1872
    25c4:	8d be 00 ff          	lea    di,[bp-0x100]
    25c8:	16                   	push   ss
    25c9:	57                   	push   di
    25ca:	68 ff 00             	push   0xff
    25cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25d0:	26 ff b5 86 02       	push   WORD PTR es:[di+0x286]
    25d5:	26 ff b5 84 02       	push   WORD PTR es:[di+0x284]
    25da:	ff 36 70 03          	push   WORD PTR ds:0x370
    25de:	6a 64                	push   0x64
    25e0:	55                   	push   bp
    25e1:	9a 72 18 06 26       	call   0x2606:0x1872
    25e6:	8d be 00 ff          	lea    di,[bp-0x100]
    25ea:	16                   	push   ss
    25eb:	57                   	push   di
    25ec:	68 ff 00             	push   0xff
    25ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f2:	26 ff b5 a2 02       	push   WORD PTR es:[di+0x2a2]
    25f7:	26 ff b5 a0 02       	push   WORD PTR es:[di+0x2a0]
    25fc:	ff 36 72 03          	push   WORD PTR ds:0x372
    2600:	6a 64                	push   0x64
    2602:	55                   	push   bp
    2603:	9a 72 18 4c 26       	call   0x264c:0x1872
    2608:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    260d:	76 18                	jbe    0x2627
    260f:	8d be 00 ff          	lea    di,[bp-0x100]
    2613:	16                   	push   ss
    2614:	57                   	push   di
    2615:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2619:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    261e:	06                   	push   es
    261f:	57                   	push   di
    2620:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2623:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2627:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    262c:	8d be 00 ff          	lea    di,[bp-0x100]
    2630:	16                   	push   ss
    2631:	57                   	push   di
    2632:	68 ff 00             	push   0xff
    2635:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2638:	26 ff b5 72 02       	push   WORD PTR es:[di+0x272]
    263d:	26 ff b5 70 02       	push   WORD PTR es:[di+0x270]
    2642:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2646:	6a 67                	push   0x67
    2648:	55                   	push   bp
    2649:	9a 72 18 6e 26       	call   0x266e:0x1872
    264e:	8d be 00 ff          	lea    di,[bp-0x100]
    2652:	16                   	push   ss
    2653:	57                   	push   di
    2654:	68 ff 00             	push   0xff
    2657:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    265a:	26 ff b5 8e 02       	push   WORD PTR es:[di+0x28e]
    265f:	26 ff b5 8c 02       	push   WORD PTR es:[di+0x28c]
    2664:	ff 36 70 03          	push   WORD PTR ds:0x370
    2668:	6a 64                	push   0x64
    266a:	55                   	push   bp
    266b:	9a 72 18 90 26       	call   0x2690:0x1872
    2670:	8d be 00 ff          	lea    di,[bp-0x100]
    2674:	16                   	push   ss
    2675:	57                   	push   di
    2676:	68 ff 00             	push   0xff
    2679:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    267c:	26 ff b5 aa 02       	push   WORD PTR es:[di+0x2aa]
    2681:	26 ff b5 a8 02       	push   WORD PTR es:[di+0x2a8]
    2686:	ff 36 72 03          	push   WORD PTR ds:0x372
    268a:	6a 64                	push   0x64
    268c:	55                   	push   bp
    268d:	9a 72 18 d6 26       	call   0x26d6:0x1872
    2692:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2697:	76 18                	jbe    0x26b1
    2699:	8d be 00 ff          	lea    di,[bp-0x100]
    269d:	16                   	push   ss
    269e:	57                   	push   di
    269f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    26a3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    26a8:	06                   	push   es
    26a9:	57                   	push   di
    26aa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26ad:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    26b1:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    26b6:	8d be 00 ff          	lea    di,[bp-0x100]
    26ba:	16                   	push   ss
    26bb:	57                   	push   di
    26bc:	68 ff 00             	push   0xff
    26bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c2:	26 ff b5 76 02       	push   WORD PTR es:[di+0x276]
    26c7:	26 ff b5 74 02       	push   WORD PTR es:[di+0x274]
    26cc:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    26d0:	6a 67                	push   0x67
    26d2:	55                   	push   bp
    26d3:	9a 72 18 f8 26       	call   0x26f8:0x1872
    26d8:	8d be 00 ff          	lea    di,[bp-0x100]
    26dc:	16                   	push   ss
    26dd:	57                   	push   di
    26de:	68 ff 00             	push   0xff
    26e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e4:	26 ff b5 8a 02       	push   WORD PTR es:[di+0x28a]
    26e9:	26 ff b5 88 02       	push   WORD PTR es:[di+0x288]
    26ee:	ff 36 70 03          	push   WORD PTR ds:0x370
    26f2:	6a 64                	push   0x64
    26f4:	55                   	push   bp
    26f5:	9a 72 18 1a 27       	call   0x271a:0x1872
    26fa:	8d be 00 ff          	lea    di,[bp-0x100]
    26fe:	16                   	push   ss
    26ff:	57                   	push   di
    2700:	68 ff 00             	push   0xff
    2703:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2706:	26 ff b5 a6 02       	push   WORD PTR es:[di+0x2a6]
    270b:	26 ff b5 a4 02       	push   WORD PTR es:[di+0x2a4]
    2710:	ff 36 72 03          	push   WORD PTR ds:0x372
    2714:	6a 64                	push   0x64
    2716:	55                   	push   bp
    2717:	9a 72 18 60 27       	call   0x2760:0x1872
    271c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2721:	76 18                	jbe    0x273b
    2723:	8d be 00 ff          	lea    di,[bp-0x100]
    2727:	16                   	push   ss
    2728:	57                   	push   di
    2729:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    272d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2732:	06                   	push   es
    2733:	57                   	push   di
    2734:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2737:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    273b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2740:	8d be 00 ff          	lea    di,[bp-0x100]
    2744:	16                   	push   ss
    2745:	57                   	push   di
    2746:	68 ff 00             	push   0xff
    2749:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    274c:	26 ff b5 6e 02       	push   WORD PTR es:[di+0x26e]
    2751:	26 ff b5 6c 02       	push   WORD PTR es:[di+0x26c]
    2756:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    275a:	6a 67                	push   0x67
    275c:	55                   	push   bp
    275d:	9a 72 18 82 27       	call   0x2782:0x1872
    2762:	8d be 00 ff          	lea    di,[bp-0x100]
    2766:	16                   	push   ss
    2767:	57                   	push   di
    2768:	68 ff 00             	push   0xff
    276b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    276e:	26 ff b5 92 02       	push   WORD PTR es:[di+0x292]
    2773:	26 ff b5 90 02       	push   WORD PTR es:[di+0x290]
    2778:	ff 36 70 03          	push   WORD PTR ds:0x370
    277c:	6a 64                	push   0x64
    277e:	55                   	push   bp
    277f:	9a 72 18 a4 27       	call   0x27a4:0x1872
    2784:	8d be 00 ff          	lea    di,[bp-0x100]
    2788:	16                   	push   ss
    2789:	57                   	push   di
    278a:	68 ff 00             	push   0xff
    278d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2790:	26 ff b5 ae 02       	push   WORD PTR es:[di+0x2ae]
    2795:	26 ff b5 ac 02       	push   WORD PTR es:[di+0x2ac]
    279a:	ff 36 72 03          	push   WORD PTR ds:0x372
    279e:	6a 64                	push   0x64
    27a0:	55                   	push   bp
    27a1:	9a 72 18 07 28       	call   0x2807:0x1872
    27a6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    27ab:	76 18                	jbe    0x27c5
    27ad:	8d be 00 ff          	lea    di,[bp-0x100]
    27b1:	16                   	push   ss
    27b2:	57                   	push   di
    27b3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    27b7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    27bc:	06                   	push   es
    27bd:	57                   	push   di
    27be:	26 c4 3d             	les    di,DWORD PTR es:[di]
    27c1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    27c5:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    27c9:	75 17                	jne    0x27e2
    27cb:	bf ce 1b             	mov    di,0x1bce
    27ce:	0e                   	push   cs
    27cf:	57                   	push   di
    27d0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    27d4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    27d9:	06                   	push   es
    27da:	57                   	push   di
    27db:	26 c4 3d             	les    di,DWORD PTR es:[di]
    27de:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    27e2:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    27e7:	8d be 00 ff          	lea    di,[bp-0x100]
    27eb:	16                   	push   ss
    27ec:	57                   	push   di
    27ed:	68 ff 00             	push   0xff
    27f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27f3:	26 ff b5 ce 02       	push   WORD PTR es:[di+0x2ce]
    27f8:	26 ff b5 cc 02       	push   WORD PTR es:[di+0x2cc]
    27fd:	ff 36 6a 03          	push   WORD PTR ds:0x36a
    2801:	6a 67                	push   0x67
    2803:	55                   	push   bp
    2804:	9a 72 18 4d 28       	call   0x284d:0x1872
    2809:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    280e:	76 18                	jbe    0x2828
    2810:	8d be 00 ff          	lea    di,[bp-0x100]
    2814:	16                   	push   ss
    2815:	57                   	push   di
    2816:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    281a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    281f:	06                   	push   es
    2820:	57                   	push   di
    2821:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2824:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2828:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    282d:	8d be 00 ff          	lea    di,[bp-0x100]
    2831:	16                   	push   ss
    2832:	57                   	push   di
    2833:	68 ff 00             	push   0xff
    2836:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2839:	26 ff b5 d2 02       	push   WORD PTR es:[di+0x2d2]
    283e:	26 ff b5 d0 02       	push   WORD PTR es:[di+0x2d0]
    2843:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2847:	6a 67                	push   0x67
    2849:	55                   	push   bp
    284a:	9a 72 18 6f 28       	call   0x286f:0x1872
    284f:	8d be 00 ff          	lea    di,[bp-0x100]
    2853:	16                   	push   ss
    2854:	57                   	push   di
    2855:	68 ff 00             	push   0xff
    2858:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    285b:	26 ff b5 de 02       	push   WORD PTR es:[di+0x2de]
    2860:	26 ff b5 dc 02       	push   WORD PTR es:[di+0x2dc]
    2865:	ff 36 70 03          	push   WORD PTR ds:0x370
    2869:	6a 64                	push   0x64
    286b:	55                   	push   bp
    286c:	9a 72 18 b5 28       	call   0x28b5:0x1872
    2871:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2876:	76 18                	jbe    0x2890
    2878:	8d be 00 ff          	lea    di,[bp-0x100]
    287c:	16                   	push   ss
    287d:	57                   	push   di
    287e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2882:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2887:	06                   	push   es
    2888:	57                   	push   di
    2889:	26 c4 3d             	les    di,DWORD PTR es:[di]
    288c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2890:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2895:	8d be 00 ff          	lea    di,[bp-0x100]
    2899:	16                   	push   ss
    289a:	57                   	push   di
    289b:	68 ff 00             	push   0xff
    289e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28a1:	26 ff b5 d6 02       	push   WORD PTR es:[di+0x2d6]
    28a6:	26 ff b5 d4 02       	push   WORD PTR es:[di+0x2d4]
    28ab:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    28af:	6a 67                	push   0x67
    28b1:	55                   	push   bp
    28b2:	9a 72 18 d7 28       	call   0x28d7:0x1872
    28b7:	8d be 00 ff          	lea    di,[bp-0x100]
    28bb:	16                   	push   ss
    28bc:	57                   	push   di
    28bd:	68 ff 00             	push   0xff
    28c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28c3:	26 ff b5 e2 02       	push   WORD PTR es:[di+0x2e2]
    28c8:	26 ff b5 e0 02       	push   WORD PTR es:[di+0x2e0]
    28cd:	ff 36 70 03          	push   WORD PTR ds:0x370
    28d1:	6a 64                	push   0x64
    28d3:	55                   	push   bp
    28d4:	9a 72 18 1d 29       	call   0x291d:0x1872
    28d9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    28de:	76 18                	jbe    0x28f8
    28e0:	8d be 00 ff          	lea    di,[bp-0x100]
    28e4:	16                   	push   ss
    28e5:	57                   	push   di
    28e6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    28ea:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    28ef:	06                   	push   es
    28f0:	57                   	push   di
    28f1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28f4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    28f8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    28fd:	8d be 00 ff          	lea    di,[bp-0x100]
    2901:	16                   	push   ss
    2902:	57                   	push   di
    2903:	68 ff 00             	push   0xff
    2906:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2909:	26 ff b5 da 02       	push   WORD PTR es:[di+0x2da]
    290e:	26 ff b5 d8 02       	push   WORD PTR es:[di+0x2d8]
    2913:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2917:	6a 67                	push   0x67
    2919:	55                   	push   bp
    291a:	9a 72 18 3f 29       	call   0x293f:0x1872
    291f:	8d be 00 ff          	lea    di,[bp-0x100]
    2923:	16                   	push   ss
    2924:	57                   	push   di
    2925:	68 ff 00             	push   0xff
    2928:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    292b:	26 ff b5 e6 02       	push   WORD PTR es:[di+0x2e6]
    2930:	26 ff b5 e4 02       	push   WORD PTR es:[di+0x2e4]
    2935:	ff 36 70 03          	push   WORD PTR ds:0x370
    2939:	6a 64                	push   0x64
    293b:	55                   	push   bp
    293c:	9a 72 18 b4 29       	call   0x29b4:0x1872
    2941:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2946:	76 18                	jbe    0x2960
    2948:	8d be 00 ff          	lea    di,[bp-0x100]
    294c:	16                   	push   ss
    294d:	57                   	push   di
    294e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2952:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2957:	06                   	push   es
    2958:	57                   	push   di
    2959:	26 c4 3d             	les    di,DWORD PTR es:[di]
    295c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2960:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    2964:	75 17                	jne    0x297d
    2966:	bf ce 1b             	mov    di,0x1bce
    2969:	0e                   	push   cs
    296a:	57                   	push   di
    296b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    296f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2974:	06                   	push   es
    2975:	57                   	push   di
    2976:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2979:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    297d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2980:	26 c4 bd b8 02       	les    di,DWORD PTR es:[di+0x2b8]
    2985:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    298a:	75 03                	jne    0x298f
    298c:	e9 16 01             	jmp    0x2aa5
    298f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2994:	8d be 00 ff          	lea    di,[bp-0x100]
    2998:	16                   	push   ss
    2999:	57                   	push   di
    299a:	68 ff 00             	push   0xff
    299d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a0:	26 ff b5 ba 02       	push   WORD PTR es:[di+0x2ba]
    29a5:	26 ff b5 b8 02       	push   WORD PTR es:[di+0x2b8]
    29aa:	ff 36 6a 03          	push   WORD PTR ds:0x36a
    29ae:	6a 67                	push   0x67
    29b0:	55                   	push   bp
    29b1:	9a 72 18 fa 29       	call   0x29fa:0x1872
    29b6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    29bb:	76 18                	jbe    0x29d5
    29bd:	8d be 00 ff          	lea    di,[bp-0x100]
    29c1:	16                   	push   ss
    29c2:	57                   	push   di
    29c3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    29c7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    29cc:	06                   	push   es
    29cd:	57                   	push   di
    29ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29d1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    29d5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    29da:	8d be 00 ff          	lea    di,[bp-0x100]
    29de:	16                   	push   ss
    29df:	57                   	push   di
    29e0:	68 ff 00             	push   0xff
    29e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29e6:	26 ff b5 be 02       	push   WORD PTR es:[di+0x2be]
    29eb:	26 ff b5 bc 02       	push   WORD PTR es:[di+0x2bc]
    29f0:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    29f4:	6a 67                	push   0x67
    29f6:	55                   	push   bp
    29f7:	9a 72 18 1c 2a       	call   0x2a1c:0x1872
    29fc:	8d be 00 ff          	lea    di,[bp-0x100]
    2a00:	16                   	push   ss
    2a01:	57                   	push   di
    2a02:	68 ff 00             	push   0xff
    2a05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a08:	26 ff b5 c6 02       	push   WORD PTR es:[di+0x2c6]
    2a0d:	26 ff b5 c4 02       	push   WORD PTR es:[di+0x2c4]
    2a12:	ff 36 70 03          	push   WORD PTR ds:0x370
    2a16:	6a 64                	push   0x64
    2a18:	55                   	push   bp
    2a19:	9a 72 18 62 2a       	call   0x2a62:0x1872
    2a1e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2a23:	76 18                	jbe    0x2a3d
    2a25:	8d be 00 ff          	lea    di,[bp-0x100]
    2a29:	16                   	push   ss
    2a2a:	57                   	push   di
    2a2b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2a2f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2a34:	06                   	push   es
    2a35:	57                   	push   di
    2a36:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a39:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2a3d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2a42:	8d be 00 ff          	lea    di,[bp-0x100]
    2a46:	16                   	push   ss
    2a47:	57                   	push   di
    2a48:	68 ff 00             	push   0xff
    2a4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a4e:	26 ff b5 c2 02       	push   WORD PTR es:[di+0x2c2]
    2a53:	26 ff b5 c0 02       	push   WORD PTR es:[di+0x2c0]
    2a58:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2a5c:	6a 67                	push   0x67
    2a5e:	55                   	push   bp
    2a5f:	9a 72 18 84 2a       	call   0x2a84:0x1872
    2a64:	8d be 00 ff          	lea    di,[bp-0x100]
    2a68:	16                   	push   ss
    2a69:	57                   	push   di
    2a6a:	68 ff 00             	push   0xff
    2a6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a70:	26 ff b5 ca 02       	push   WORD PTR es:[di+0x2ca]
    2a75:	26 ff b5 c8 02       	push   WORD PTR es:[di+0x2c8]
    2a7a:	ff 36 70 03          	push   WORD PTR ds:0x370
    2a7e:	6a 64                	push   0x64
    2a80:	55                   	push   bp
    2a81:	9a 72 18 e7 2a       	call   0x2ae7:0x1872
    2a86:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2a8b:	76 18                	jbe    0x2aa5
    2a8d:	8d be 00 ff          	lea    di,[bp-0x100]
    2a91:	16                   	push   ss
    2a92:	57                   	push   di
    2a93:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2a97:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2a9c:	06                   	push   es
    2a9d:	57                   	push   di
    2a9e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2aa1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2aa5:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    2aa9:	75 17                	jne    0x2ac2
    2aab:	bf ce 1b             	mov    di,0x1bce
    2aae:	0e                   	push   cs
    2aaf:	57                   	push   di
    2ab0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2ab4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2ab9:	06                   	push   es
    2aba:	57                   	push   di
    2abb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2abe:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2ac2:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2ac7:	8d be 00 ff          	lea    di,[bp-0x100]
    2acb:	16                   	push   ss
    2acc:	57                   	push   di
    2acd:	68 ff 00             	push   0xff
    2ad0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad3:	26 ff b5 1e 03       	push   WORD PTR es:[di+0x31e]
    2ad8:	26 ff b5 1c 03       	push   WORD PTR es:[di+0x31c]
    2add:	ff 36 6a 03          	push   WORD PTR ds:0x36a
    2ae1:	6a 67                	push   0x67
    2ae3:	55                   	push   bp
    2ae4:	9a 72 18 09 2b       	call   0x2b09:0x1872
    2ae9:	8d be 00 ff          	lea    di,[bp-0x100]
    2aed:	16                   	push   ss
    2aee:	57                   	push   di
    2aef:	68 ff 00             	push   0xff
    2af2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2af5:	26 ff b5 22 03       	push   WORD PTR es:[di+0x322]
    2afa:	26 ff b5 20 03       	push   WORD PTR es:[di+0x320]
    2aff:	ff 36 70 03          	push   WORD PTR ds:0x370
    2b03:	6a 64                	push   0x64
    2b05:	55                   	push   bp
    2b06:	9a 72 18 7e 2b       	call   0x2b7e:0x1872
    2b0b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2b10:	76 18                	jbe    0x2b2a
    2b12:	8d be 00 ff          	lea    di,[bp-0x100]
    2b16:	16                   	push   ss
    2b17:	57                   	push   di
    2b18:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2b1c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b21:	06                   	push   es
    2b22:	57                   	push   di
    2b23:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b26:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2b2a:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    2b2e:	75 17                	jne    0x2b47
    2b30:	bf ce 1b             	mov    di,0x1bce
    2b33:	0e                   	push   cs
    2b34:	57                   	push   di
    2b35:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2b39:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b3e:	06                   	push   es
    2b3f:	57                   	push   di
    2b40:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b43:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2b47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b4a:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    2b4f:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2b54:	75 03                	jne    0x2b59
    2b56:	e9 14 01             	jmp    0x2c6d
    2b59:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2b5e:	8d be 00 ff          	lea    di,[bp-0x100]
    2b62:	16                   	push   ss
    2b63:	57                   	push   di
    2b64:	68 ff 00             	push   0xff
    2b67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b6a:	26 ff b5 2e 03       	push   WORD PTR es:[di+0x32e]
    2b6f:	26 ff b5 2c 03       	push   WORD PTR es:[di+0x32c]
    2b74:	ff 36 6a 03          	push   WORD PTR ds:0x36a
    2b78:	6a 67                	push   0x67
    2b7a:	55                   	push   bp
    2b7b:	9a 72 18 a0 2b       	call   0x2ba0:0x1872
    2b80:	8d be 00 ff          	lea    di,[bp-0x100]
    2b84:	16                   	push   ss
    2b85:	57                   	push   di
    2b86:	68 ff 00             	push   0xff
    2b89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b8c:	26 ff b5 36 03       	push   WORD PTR es:[di+0x336]
    2b91:	26 ff b5 34 03       	push   WORD PTR es:[di+0x334]
    2b96:	ff 36 70 03          	push   WORD PTR ds:0x370
    2b9a:	6a 64                	push   0x64
    2b9c:	55                   	push   bp
    2b9d:	9a 72 18 c2 2b       	call   0x2bc2:0x1872
    2ba2:	8d be 00 ff          	lea    di,[bp-0x100]
    2ba6:	16                   	push   ss
    2ba7:	57                   	push   di
    2ba8:	68 ff 00             	push   0xff
    2bab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bae:	26 ff b5 46 03       	push   WORD PTR es:[di+0x346]
    2bb3:	26 ff b5 44 03       	push   WORD PTR es:[di+0x344]
    2bb8:	ff 36 72 03          	push   WORD PTR ds:0x372
    2bbc:	6a 64                	push   0x64
    2bbe:	55                   	push   bp
    2bbf:	9a 72 18 08 2c       	call   0x2c08:0x1872
    2bc4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2bc9:	76 18                	jbe    0x2be3
    2bcb:	8d be 00 ff          	lea    di,[bp-0x100]
    2bcf:	16                   	push   ss
    2bd0:	57                   	push   di
    2bd1:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2bd5:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2bda:	06                   	push   es
    2bdb:	57                   	push   di
    2bdc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bdf:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2be3:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2be8:	8d be 00 ff          	lea    di,[bp-0x100]
    2bec:	16                   	push   ss
    2bed:	57                   	push   di
    2bee:	68 ff 00             	push   0xff
    2bf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bf4:	26 ff b5 3a 03       	push   WORD PTR es:[di+0x33a]
    2bf9:	26 ff b5 38 03       	push   WORD PTR es:[di+0x338]
    2bfe:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2c02:	6a 67                	push   0x67
    2c04:	55                   	push   bp
    2c05:	9a 72 18 2a 2c       	call   0x2c2a:0x1872
    2c0a:	8d be 00 ff          	lea    di,[bp-0x100]
    2c0e:	16                   	push   ss
    2c0f:	57                   	push   di
    2c10:	68 ff 00             	push   0xff
    2c13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c16:	26 ff b5 3e 03       	push   WORD PTR es:[di+0x33e]
    2c1b:	26 ff b5 3c 03       	push   WORD PTR es:[di+0x33c]
    2c20:	ff 36 70 03          	push   WORD PTR ds:0x370
    2c24:	6a 64                	push   0x64
    2c26:	55                   	push   bp
    2c27:	9a 72 18 4c 2c       	call   0x2c4c:0x1872
    2c2c:	8d be 00 ff          	lea    di,[bp-0x100]
    2c30:	16                   	push   ss
    2c31:	57                   	push   di
    2c32:	68 ff 00             	push   0xff
    2c35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c38:	26 ff b5 4a 03       	push   WORD PTR es:[di+0x34a]
    2c3d:	26 ff b5 48 03       	push   WORD PTR es:[di+0x348]
    2c42:	ff 36 72 03          	push   WORD PTR ds:0x372
    2c46:	6a 64                	push   0x64
    2c48:	55                   	push   bp
    2c49:	9a 72 18 c1 2c       	call   0x2cc1:0x1872
    2c4e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2c53:	76 18                	jbe    0x2c6d
    2c55:	8d be 00 ff          	lea    di,[bp-0x100]
    2c59:	16                   	push   ss
    2c5a:	57                   	push   di
    2c5b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2c5f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2c64:	06                   	push   es
    2c65:	57                   	push   di
    2c66:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c69:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2c6d:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    2c71:	75 17                	jne    0x2c8a
    2c73:	bf ce 1b             	mov    di,0x1bce
    2c76:	0e                   	push   cs
    2c77:	57                   	push   di
    2c78:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2c7c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2c81:	06                   	push   es
    2c82:	57                   	push   di
    2c83:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c86:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c8d:	26 c4 bd 4c 03       	les    di,DWORD PTR es:[di+0x34c]
    2c92:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2c97:	75 03                	jne    0x2c9c
    2c99:	e9 9e 01             	jmp    0x2e3a
    2c9c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2ca1:	8d be 00 ff          	lea    di,[bp-0x100]
    2ca5:	16                   	push   ss
    2ca6:	57                   	push   di
    2ca7:	68 ff 00             	push   0xff
    2caa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cad:	26 ff b5 4e 03       	push   WORD PTR es:[di+0x34e]
    2cb2:	26 ff b5 4c 03       	push   WORD PTR es:[di+0x34c]
    2cb7:	ff 36 6a 03          	push   WORD PTR ds:0x36a
    2cbb:	6a 67                	push   0x67
    2cbd:	55                   	push   bp
    2cbe:	9a 72 18 e3 2c       	call   0x2ce3:0x1872
    2cc3:	8d be 00 ff          	lea    di,[bp-0x100]
    2cc7:	16                   	push   ss
    2cc8:	57                   	push   di
    2cc9:	68 ff 00             	push   0xff
    2ccc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ccf:	26 ff b5 56 03       	push   WORD PTR es:[di+0x356]
    2cd4:	26 ff b5 54 03       	push   WORD PTR es:[di+0x354]
    2cd9:	ff 36 70 03          	push   WORD PTR ds:0x370
    2cdd:	6a 64                	push   0x64
    2cdf:	55                   	push   bp
    2ce0:	9a 72 18 05 2d       	call   0x2d05:0x1872
    2ce5:	8d be 00 ff          	lea    di,[bp-0x100]
    2ce9:	16                   	push   ss
    2cea:	57                   	push   di
    2ceb:	68 ff 00             	push   0xff
    2cee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cf1:	26 ff b5 6e 03       	push   WORD PTR es:[di+0x36e]
    2cf6:	26 ff b5 6c 03       	push   WORD PTR es:[di+0x36c]
    2cfb:	ff 36 72 03          	push   WORD PTR ds:0x372
    2cff:	6a 64                	push   0x64
    2d01:	55                   	push   bp
    2d02:	9a 72 18 4b 2d       	call   0x2d4b:0x1872
    2d07:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2d0c:	76 18                	jbe    0x2d26
    2d0e:	8d be 00 ff          	lea    di,[bp-0x100]
    2d12:	16                   	push   ss
    2d13:	57                   	push   di
    2d14:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2d18:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2d1d:	06                   	push   es
    2d1e:	57                   	push   di
    2d1f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d22:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2d26:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2d2b:	8d be 00 ff          	lea    di,[bp-0x100]
    2d2f:	16                   	push   ss
    2d30:	57                   	push   di
    2d31:	68 ff 00             	push   0xff
    2d34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d37:	26 ff b5 5a 03       	push   WORD PTR es:[di+0x35a]
    2d3c:	26 ff b5 58 03       	push   WORD PTR es:[di+0x358]
    2d41:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2d45:	6a 67                	push   0x67
    2d47:	55                   	push   bp
    2d48:	9a 72 18 6d 2d       	call   0x2d6d:0x1872
    2d4d:	8d be 00 ff          	lea    di,[bp-0x100]
    2d51:	16                   	push   ss
    2d52:	57                   	push   di
    2d53:	68 ff 00             	push   0xff
    2d56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d59:	26 ff b5 62 03       	push   WORD PTR es:[di+0x362]
    2d5e:	26 ff b5 60 03       	push   WORD PTR es:[di+0x360]
    2d63:	ff 36 70 03          	push   WORD PTR ds:0x370
    2d67:	6a 64                	push   0x64
    2d69:	55                   	push   bp
    2d6a:	9a 72 18 8f 2d       	call   0x2d8f:0x1872
    2d6f:	8d be 00 ff          	lea    di,[bp-0x100]
    2d73:	16                   	push   ss
    2d74:	57                   	push   di
    2d75:	68 ff 00             	push   0xff
    2d78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d7b:	26 ff b5 72 03       	push   WORD PTR es:[di+0x372]
    2d80:	26 ff b5 70 03       	push   WORD PTR es:[di+0x370]
    2d85:	ff 36 72 03          	push   WORD PTR ds:0x372
    2d89:	6a 64                	push   0x64
    2d8b:	55                   	push   bp
    2d8c:	9a 72 18 d5 2d       	call   0x2dd5:0x1872
    2d91:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2d96:	76 18                	jbe    0x2db0
    2d98:	8d be 00 ff          	lea    di,[bp-0x100]
    2d9c:	16                   	push   ss
    2d9d:	57                   	push   di
    2d9e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2da2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2da7:	06                   	push   es
    2da8:	57                   	push   di
    2da9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2dac:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2db0:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2db5:	8d be 00 ff          	lea    di,[bp-0x100]
    2db9:	16                   	push   ss
    2dba:	57                   	push   di
    2dbb:	68 ff 00             	push   0xff
    2dbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dc1:	26 ff b5 5e 03       	push   WORD PTR es:[di+0x35e]
    2dc6:	26 ff b5 5c 03       	push   WORD PTR es:[di+0x35c]
    2dcb:	ff 36 6c 03          	push   WORD PTR ds:0x36c
    2dcf:	6a 67                	push   0x67
    2dd1:	55                   	push   bp
    2dd2:	9a 72 18 f7 2d       	call   0x2df7:0x1872
    2dd7:	8d be 00 ff          	lea    di,[bp-0x100]
    2ddb:	16                   	push   ss
    2ddc:	57                   	push   di
    2ddd:	68 ff 00             	push   0xff
    2de0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2de3:	26 ff b5 66 03       	push   WORD PTR es:[di+0x366]
    2de8:	26 ff b5 64 03       	push   WORD PTR es:[di+0x364]
    2ded:	ff 36 70 03          	push   WORD PTR ds:0x370
    2df1:	6a 64                	push   0x64
    2df3:	55                   	push   bp
    2df4:	9a 72 18 19 2e       	call   0x2e19:0x1872
    2df9:	8d be 00 ff          	lea    di,[bp-0x100]
    2dfd:	16                   	push   ss
    2dfe:	57                   	push   di
    2dff:	68 ff 00             	push   0xff
    2e02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e05:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    2e0a:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    2e0f:	ff 36 72 03          	push   WORD PTR ds:0x372
    2e13:	6a 64                	push   0x64
    2e15:	55                   	push   bp
    2e16:	9a 72 18 a5 2e       	call   0x2ea5:0x1872
    2e1b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    2e20:	76 18                	jbe    0x2e3a
    2e22:	8d be 00 ff          	lea    di,[bp-0x100]
    2e26:	16                   	push   ss
    2e27:	57                   	push   di
    2e28:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    2e2c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2e31:	06                   	push   es
    2e32:	57                   	push   di
    2e33:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e36:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    2e3a:	c9                   	leave
    2e3b:	ca 06 00             	retf   0x6
    2e3e:	00 00                	add    BYTE PTR [bx+si],al
    2e40:	c8 42 55 89          	enter  0x5542,0x89
    2e44:	e5 b8                	in     ax,0xb8
    2e46:	14 00                	adc    al,0x0
    2e48:	9a 44 04 86 2e       	call   0x2e86:0x444
    2e4d:	83 ec 14             	sub    sp,0x14
    2e50:	9a ff ff 00 00       	call   0x0:0xffff
    2e55:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2e58:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    2e5b:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
    2e5e:	30 e4                	xor    ah,ah
    2e60:	31 d2                	xor    dx,dx
    2e62:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2e65:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    2e68:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
    2e6c:	8a 46 f5             	mov    al,BYTE PTR [bp-0xb]
    2e6f:	30 e4                	xor    ah,ah
    2e71:	31 d2                	xor    dx,dx
    2e73:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2e76:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    2e79:	9b db 46 f0          	fild   DWORD PTR [bp-0x10]
    2e7d:	9b 2e d9 06 3e 2e    	fld    DWORD PTR cs:0x2e3e
    2e83:	9a b2 04 b0 2e       	call   0x2eb0:0x4b2
    2e88:	9b de c1             	faddp  st(1),st
    2e8b:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    2e8f:	90                   	nop
    2e90:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    2e95:	90                   	nop
    2e96:	9b                   	fwait
    2e97:	c9                   	leave
    2e98:	cb                   	retf
    2e99:	00 00                	add    BYTE PTR [bx+si],al
    2e9b:	00 00                	add    BYTE PTR [bx+si],al
    2e9d:	01 00                	add    WORD PTR [bx+si],ax
    2e9f:	86 01                	xchg   BYTE PTR [bx+di],al
    2ea1:	32 2f                	xor    ch,BYTE PTR [bx]
    2ea3:	0f 2f 36 2f 55       	comiss xmm6,DWORD PTR ds:0x552f
    2ea8:	89 e5                	mov    bp,sp
    2eaa:	b8 0a 00             	mov    ax,0xa
    2ead:	9a 44 04 f0 2e       	call   0x2ef0:0x444
    2eb2:	83 ec 0a             	sub    sp,0xa
    2eb5:	9b 2e d9 06 99 2e    	fld    DWORD PTR cs:0x2e99
    2ebb:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    2ebf:	90                   	nop
    2ec0:	9b                   	fwait
    2ec1:	b8 9d 2e             	mov    ax,0x2e9d
    2ec4:	0e                   	push   cs
    2ec5:	50                   	push   ax
    2ec6:	55                   	push   bp
    2ec7:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2ecb:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2ecf:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    2ed3:	9b 2e d8 1e 99 2e    	fcomp  DWORD PTR cs:0x2e99
    2ed9:	9b dd 7e f6          	fstsw  WORD PTR [bp-0xa]
    2edd:	90                   	nop
    2ede:	9b                   	fwait
    2edf:	8a 66 f7             	mov    ah,BYTE PTR [bp-0x9]
    2ee2:	9e                   	sahf
    2ee3:	74 15                	je     0x2efa
    2ee5:	9b dd 46 0e          	fld    QWORD PTR [bp+0xe]
    2ee9:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    2eed:	9a b2 04 1e 2f       	call   0x2f1e:0x4b2
    2ef2:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    2ef6:	90                   	nop
    2ef7:	9b                   	fwait
    2ef8:	eb 0c                	jmp    0x2f06
    2efa:	9b 2e d9 06 99 2e    	fld    DWORD PTR cs:0x2e99
    2f00:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    2f04:	90                   	nop
    2f05:	9b                   	fwait
    2f06:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2f0a:	83 c4 06             	add    sp,0x6
    2f0d:	eb 11                	jmp    0x2f20
    2f0f:	9b 2e d9 06 99 2e    	fld    DWORD PTR cs:0x2e99
    2f15:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    2f19:	90                   	nop
    2f1a:	9b                   	fwait
    2f1b:	9a 34 14 41 2f       	call   0x2f41:0x1434
    2f20:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    2f24:	90                   	nop
    2f25:	9b                   	fwait
    2f26:	c9                   	leave
    2f27:	ca 10 00             	retf   0x10
    2f2a:	00 00                	add    BYTE PTR [bx+si],al
    2f2c:	00 00                	add    BYTE PTR [bx+si],al
    2f2e:	01 00                	add    WORD PTR [bx+si],ax
    2f30:	86 01                	xchg   BYTE PTR [bx+di],al
    2f32:	a0 2f 75             	mov    al,ds:0x752f
    2f35:	2f                   	das
    2f36:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    2f37:	2f                   	das
    2f38:	55                   	push   bp
    2f39:	89 e5                	mov    bp,sp
    2f3b:	b8 08 00             	mov    ax,0x8
    2f3e:	9a 44 04 5b 2f       	call   0x2f5b:0x444
    2f43:	83 ec 08             	sub    sp,0x8
    2f46:	b8 2e 2f             	mov    ax,0x2f2e
    2f49:	0e                   	push   cs
    2f4a:	50                   	push   ax
    2f4b:	55                   	push   bp
    2f4c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2f50:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2f54:	9b dd 46 0e          	fld    QWORD PTR [bp+0xe]
    2f58:	9a 83 10 64 2f       	call   0x2f64:0x1083
    2f5d:	9b dc 4e 06          	fmul   QWORD PTR [bp+0x6]
    2f61:	9a 87 10 84 2f       	call   0x2f84:0x1087
    2f66:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    2f6a:	90                   	nop
    2f6b:	9b                   	fwait
    2f6c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2f70:	83 c4 06             	add    sp,0x6
    2f73:	eb 11                	jmp    0x2f86
    2f75:	9b 2e d9 06 2a 2f    	fld    DWORD PTR cs:0x2f2a
    2f7b:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    2f7f:	90                   	nop
    2f80:	9b                   	fwait
    2f81:	9a 34 14 af 2f       	call   0x2faf:0x1434
    2f86:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    2f8a:	90                   	nop
    2f8b:	9b                   	fwait
    2f8c:	c9                   	leave
    2f8d:	ca 10 00             	retf   0x10
    2f90:	00 00                	add    BYTE PTR [bx+si],al
    2f92:	00 00                	add    BYTE PTR [bx+si],al
    2f94:	00 00                	add    BYTE PTR [bx+si],al
    2f96:	c8 42 00 00          	enter  0x42,0x0
    2f9a:	00 3f                	add    BYTE PTR [bx],bh
    2f9c:	01 00                	add    WORD PTR [bx+si],ax
    2f9e:	86 01                	xchg   BYTE PTR [bx+di],al
    2fa0:	cb                   	retf
    2fa1:	30 61 30             	xor    BYTE PTR [bx+di+0x30],ah
    2fa4:	82 30 55             	xor    BYTE PTR [bx+si],0x55
    2fa7:	89 e5                	mov    bp,sp
    2fa9:	b8 14 00             	mov    ax,0x14
    2fac:	9a 44 04 df 2f       	call   0x2fdf:0x444
    2fb1:	83 ec 14             	sub    sp,0x14
    2fb4:	b8 9c 2f             	mov    ax,0x2f9c
    2fb7:	0e                   	push   cs
    2fb8:	50                   	push   ax
    2fb9:	55                   	push   bp
    2fba:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2fbe:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2fc2:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    2fc6:	9b 2e d8 1e 90 2f    	fcomp  DWORD PTR cs:0x2f90
    2fcc:	9b dd 7e f6          	fstsw  WORD PTR [bp-0xa]
    2fd0:	90                   	nop
    2fd1:	9b                   	fwait
    2fd2:	8a 66 f7             	mov    ah,BYTE PTR [bp-0x9]
    2fd5:	9e                   	sahf
    2fd6:	72 41                	jb     0x3019
    2fd8:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    2fdc:	9a 41 10 ec 2f       	call   0x2fec:0x1041
    2fe1:	9b db 7e ec          	fstp   TBYTE PTR [bp-0x14]
    2fe5:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    2fe9:	9a 57 10 fd 2f       	call   0x2ffd:0x1057
    2fee:	9b 2e d8 0e 94 2f    	fmul   DWORD PTR cs:0x2f94
    2ff4:	9b 2e d8 06 98 2f    	fadd   DWORD PTR cs:0x2f98
    2ffa:	9a 41 10 08 30       	call   0x3008:0x1041
    2fff:	9b 2e d9 06 94 2f    	fld    DWORD PTR cs:0x2f94
    3005:	9a b2 04 20 30       	call   0x3020:0x4b2
    300a:	9b db 6e ec          	fld    TBYTE PTR [bp-0x14]
    300e:	9b de c1             	faddp  st(1),st
    3011:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3015:	90                   	nop
    3016:	9b                   	fwait
    3017:	eb 3f                	jmp    0x3058
    3019:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    301d:	9a 41 10 2d 30       	call   0x302d:0x1041
    3022:	9b db 7e ec          	fstp   TBYTE PTR [bp-0x14]
    3026:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    302a:	9a 57 10 3e 30       	call   0x303e:0x1057
    302f:	9b 2e d8 0e 94 2f    	fmul   DWORD PTR cs:0x2f94
    3035:	9b 2e d8 26 98 2f    	fsub   DWORD PTR cs:0x2f98
    303b:	9a 41 10 49 30       	call   0x3049:0x1041
    3040:	9b 2e d9 06 94 2f    	fld    DWORD PTR cs:0x2f94
    3046:	9a b2 04 6e 30       	call   0x306e:0x4b2
    304b:	9b db 6e ec          	fld    TBYTE PTR [bp-0x14]
    304f:	9b de c1             	faddp  st(1),st
    3052:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3056:	90                   	nop
    3057:	9b                   	fwait
    3058:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    305c:	83 c4 06             	add    sp,0x6
    305f:	eb 0f                	jmp    0x3070
    3061:	9b dd 46 06          	fld    QWORD PTR [bp+0x6]
    3065:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3069:	90                   	nop
    306a:	9b                   	fwait
    306b:	9a 34 14 9c 30       	call   0x309c:0x1434
    3070:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    3074:	90                   	nop
    3075:	9b                   	fwait
    3076:	c9                   	leave
    3077:	ca 08 00             	retf   0x8
    307a:	01 00                	add    WORD PTR [bx+si],ax
    307c:	00 00                	add    BYTE PTR [bx+si],al
    307e:	00 00                	add    BYTE PTR [bx+si],al
    3080:	e4 30                	in     al,0x30
    3082:	22 33                	and    dh,BYTE PTR [bp+di]
    3084:	01 65 02             	add    WORD PTR [di+0x2],sp
    3087:	25 2e 01             	and    ax,0x12e
    308a:	45                   	inc    bp
    308b:	00 00                	add    BYTE PTR [bx+si],al
    308d:	00 00                	add    BYTE PTR [bx+si],al
    308f:	ff 00                	inc    WORD PTR [bx+si]
    3091:	00 00                	add    BYTE PTR [bx+si],al
    3093:	55                   	push   bp
    3094:	89 e5                	mov    bp,sp
    3096:	b8 06 04             	mov    ax,0x406
    3099:	9a 44 04 d9 30       	call   0x30d9:0x444
    309e:	81 ec 06 04          	sub    sp,0x406
    30a2:	c6 86 fd fd 01       	mov    BYTE PTR [bp-0x203],0x1
    30a7:	b8 7a 30             	mov    ax,0x307a
    30aa:	0e                   	push   cs
    30ab:	50                   	push   ax
    30ac:	55                   	push   bp
    30ad:	ff 36 58 18          	push   WORD PTR ds:0x1858
    30b1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    30b5:	8d be fa fc          	lea    di,[bp-0x306]
    30b9:	16                   	push   ss
    30ba:	57                   	push   di
    30bb:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    30be:	06                   	push   es
    30bf:	57                   	push   di
    30c0:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    30c3:	06                   	push   es
    30c4:	57                   	push   di
    30c5:	ff 76 06             	push   WORD PTR [bp+0x6]
    30c8:	9a 34 10 67 31       	call   0x3167:0x1034
    30cd:	8d be 00 ff          	lea    di,[bp-0x100]
    30d1:	16                   	push   ss
    30d2:	57                   	push   di
    30d3:	68 ff 00             	push   0xff
    30d6:	9a e7 17 ec 30       	call   0x30ec:0x17e7
    30db:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    30df:	83 c4 06             	add    sp,0x6
    30e2:	eb 0a                	jmp    0x30ee
    30e4:	c6 86 fd fd 00       	mov    BYTE PTR [bp-0x203],0x0
    30e9:	9a 34 14 fb 30       	call   0x30fb:0x1434
    30ee:	bf 84 30             	mov    di,0x3084
    30f1:	0e                   	push   cs
    30f2:	57                   	push   di
    30f3:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    30f6:	06                   	push   es
    30f7:	57                   	push   di
    30f8:	9a 78 18 41 31       	call   0x3141:0x1878
    30fd:	09 c0                	or     ax,ax
    30ff:	b0 00                	mov    al,0x0
    3101:	75 01                	jne    0x3104
    3103:	40                   	inc    ax
    3104:	8a d0                	mov    dl,al
    3106:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    310a:	30 e4                	xor    ah,ah
    310c:	3b 46 10             	cmp    ax,WORD PTR [bp+0x10]
    310f:	b0 00                	mov    al,0x0
    3111:	7e 01                	jle    0x3114
    3113:	40                   	inc    ax
    3114:	22 c2                	and    al,dl
    3116:	8a d0                	mov    dl,al
    3118:	80 be fd fd 00       	cmp    BYTE PTR [bp-0x203],0x0
    311d:	b0 00                	mov    al,0x0
    311f:	75 01                	jne    0x3122
    3121:	40                   	inc    ax
    3122:	0a c2                	or     al,dl
    3124:	08 c0                	or     al,al
    3126:	75 03                	jne    0x312b
    3128:	e9 a1 01             	jmp    0x32cc
    312b:	83 7e 10 0a          	cmp    WORD PTR [bp+0x10],0xa
    312f:	7d 05                	jge    0x3136
    3131:	c7 46 10 0a 00       	mov    WORD PTR [bp+0x10],0xa
    3136:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    3139:	2d 08 00             	sub    ax,0x8
    313c:	71 05                	jno    0x3143
    313e:	9a 3e 04 55 31       	call   0x3155:0x43e
    3143:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    3147:	8d be fa fb          	lea    di,[bp-0x406]
    314b:	16                   	push   ss
    314c:	57                   	push   di
    314d:	bf 86 30             	mov    di,0x3086
    3150:	0e                   	push   cs
    3151:	57                   	push   di
    3152:	9a cd 17 6c 31       	call   0x316c:0x17cd
    3157:	8d be fa fc          	lea    di,[bp-0x306]
    315b:	16                   	push   ss
    315c:	57                   	push   di
    315d:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    3161:	99                   	cwd
    3162:	52                   	push   dx
    3163:	50                   	push   ax
    3164:	9a a9 08 9d 31       	call   0x319d:0x8a9
    3169:	9a 4c 18 76 31       	call   0x3176:0x184c
    316e:	bf 84 30             	mov    di,0x3084
    3171:	0e                   	push   cs
    3172:	57                   	push   di
    3173:	9a 4c 18 84 31       	call   0x3184:0x184c
    3178:	8d be fe fd          	lea    di,[bp-0x202]
    317c:	16                   	push   ss
    317d:	57                   	push   di
    317e:	68 ff 00             	push   0xff
    3181:	9a e7 17 ab 31       	call   0x31ab:0x17e7
    3186:	8d be fa fc          	lea    di,[bp-0x306]
    318a:	16                   	push   ss
    318b:	57                   	push   di
    318c:	8d be fe fd          	lea    di,[bp-0x202]
    3190:	16                   	push   ss
    3191:	57                   	push   di
    3192:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3195:	06                   	push   es
    3196:	57                   	push   di
    3197:	ff 76 06             	push   WORD PTR [bp+0x6]
    319a:	9a 34 10 2d 32       	call   0x322d:0x1034
    319f:	8d be 00 ff          	lea    di,[bp-0x100]
    31a3:	16                   	push   ss
    31a4:	57                   	push   di
    31a5:	68 ff 00             	push   0xff
    31a8:	9a e7 17 bb 31       	call   0x31bb:0x17e7
    31ad:	bf 89 30             	mov    di,0x3089
    31b0:	0e                   	push   cs
    31b1:	57                   	push   di
    31b2:	8d be 00 ff          	lea    di,[bp-0x100]
    31b6:	16                   	push   ss
    31b7:	57                   	push   di
    31b8:	9a 78 18 d7 31       	call   0x31d7:0x1878
    31bd:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    31c1:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    31c6:	7f 03                	jg     0x31cb
    31c8:	e9 a8 00             	jmp    0x3273
    31cb:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    31cf:	05 02 00             	add    ax,0x2
    31d2:	71 05                	jno    0x31d9
    31d4:	9a 3e 04 e0 31       	call   0x31e0:0x43e
    31d9:	99                   	cwd
    31da:	bf 8b 30             	mov    di,0x308b
    31dd:	9a 16 04 fd 31       	call   0x31fd:0x416
    31e2:	8b f8                	mov    di,ax
    31e4:	80 bb 00 ff 30       	cmp    BYTE PTR [bp+di-0x100],0x30
    31e9:	75 22                	jne    0x320d
    31eb:	8d be 00 ff          	lea    di,[bp-0x100]
    31ef:	16                   	push   ss
    31f0:	57                   	push   di
    31f1:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    31f5:	05 02 00             	add    ax,0x2
    31f8:	71 05                	jno    0x31ff
    31fa:	9a 3e 04 05 32       	call   0x3205:0x43e
    31ff:	50                   	push   ax
    3200:	6a 01                	push   0x1
    3202:	9a 75 19 1b 32       	call   0x321b:0x1975
    3207:	ff 86 fa fd          	inc    WORD PTR [bp-0x206]
    320b:	eb be                	jmp    0x31cb
    320d:	8d be fa fb          	lea    di,[bp-0x406]
    3211:	16                   	push   ss
    3212:	57                   	push   di
    3213:	bf 86 30             	mov    di,0x3086
    3216:	0e                   	push   cs
    3217:	57                   	push   di
    3218:	9a cd 17 32 32       	call   0x3232:0x17cd
    321d:	8d be fa fc          	lea    di,[bp-0x306]
    3221:	16                   	push   ss
    3222:	57                   	push   di
    3223:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    3227:	99                   	cwd
    3228:	52                   	push   dx
    3229:	50                   	push   ax
    322a:	9a a9 08 63 32       	call   0x3263:0x8a9
    322f:	9a 4c 18 3c 32       	call   0x323c:0x184c
    3234:	bf 84 30             	mov    di,0x3084
    3237:	0e                   	push   cs
    3238:	57                   	push   di
    3239:	9a 4c 18 4a 32       	call   0x324a:0x184c
    323e:	8d be fe fd          	lea    di,[bp-0x202]
    3242:	16                   	push   ss
    3243:	57                   	push   di
    3244:	68 ff 00             	push   0xff
    3247:	9a e7 17 71 32       	call   0x3271:0x17e7
    324c:	8d be fa fc          	lea    di,[bp-0x306]
    3250:	16                   	push   ss
    3251:	57                   	push   di
    3252:	8d be fe fd          	lea    di,[bp-0x202]
    3256:	16                   	push   ss
    3257:	57                   	push   di
    3258:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    325b:	06                   	push   es
    325c:	57                   	push   di
    325d:	ff 76 06             	push   WORD PTR [bp+0x6]
    3260:	9a 34 10 e7 33       	call   0x33e7:0x1034
    3265:	8d be 00 ff          	lea    di,[bp-0x100]
    3269:	16                   	push   ss
    326a:	57                   	push   di
    326b:	68 ff 00             	push   0xff
    326e:	9a e7 17 81 32       	call   0x3281:0x17e7
    3273:	bf 89 30             	mov    di,0x3089
    3276:	0e                   	push   cs
    3277:	57                   	push   di
    3278:	8d be 00 ff          	lea    di,[bp-0x100]
    327c:	16                   	push   ss
    327d:	57                   	push   di
    327e:	9a 78 18 9a 32       	call   0x329a:0x1878
    3283:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    3287:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    328c:	7e 3e                	jle    0x32cc
    328e:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    3292:	05 02 00             	add    ax,0x2
    3295:	71 05                	jno    0x329c
    3297:	9a 3e 04 a3 32       	call   0x32a3:0x43e
    329c:	99                   	cwd
    329d:	bf 8b 30             	mov    di,0x308b
    32a0:	9a 16 04 c0 32       	call   0x32c0:0x416
    32a5:	8b f8                	mov    di,ax
    32a7:	80 bb 00 ff 30       	cmp    BYTE PTR [bp+di-0x100],0x30
    32ac:	75 1e                	jne    0x32cc
    32ae:	8d be 00 ff          	lea    di,[bp-0x100]
    32b2:	16                   	push   ss
    32b3:	57                   	push   di
    32b4:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    32b8:	05 02 00             	add    ax,0x2
    32bb:	71 05                	jno    0x32c2
    32bd:	9a 3e 04 c8 32       	call   0x32c8:0x43e
    32c2:	50                   	push   ax
    32c3:	6a 01                	push   0x1
    32c5:	9a 75 19 e0 32       	call   0x32e0:0x1975
    32ca:	eb c2                	jmp    0x328e
    32cc:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    32d1:	75 11                	jne    0x32e4
    32d3:	8d be 00 ff          	lea    di,[bp-0x100]
    32d7:	16                   	push   ss
    32d8:	57                   	push   di
    32d9:	6a 01                	push   0x1
    32db:	6a 01                	push   0x1
    32dd:	9a 75 19 f5 32       	call   0x32f5:0x1975
    32e2:	eb e8                	jmp    0x32cc
    32e4:	8d be 00 ff          	lea    di,[bp-0x100]
    32e8:	16                   	push   ss
    32e9:	57                   	push   di
    32ea:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    32ed:	06                   	push   es
    32ee:	57                   	push   di
    32ef:	68 ff 00             	push   0xff
    32f2:	9a e7 17 04 33       	call   0x3304:0x17e7
    32f7:	c9                   	leave
    32f8:	ca 0c 00             	retf   0xc
    32fb:	55                   	push   bp
    32fc:	89 e5                	mov    bp,sp
    32fe:	b8 00 01             	mov    ax,0x100
    3301:	9a 44 04 2f 33       	call   0x332f:0x444
    3306:	81 ec 00 01          	sub    sp,0x100
    330a:	8d be 00 ff          	lea    di,[bp-0x100]
    330e:	16                   	push   ss
    330f:	57                   	push   di
    3310:	6a 14                	push   0x14
    3312:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3315:	06                   	push   es
    3316:	57                   	push   di
    3317:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    331a:	06                   	push   es
    331b:	57                   	push   di
    331c:	ff 76 06             	push   WORD PTR [bp+0x6]
    331f:	9a 93 30 bd 34       	call   0x34bd:0x3093
    3324:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    3327:	06                   	push   es
    3328:	57                   	push   di
    3329:	68 ff 00             	push   0xff
    332c:	9a e7 17 3e 33       	call   0x333e:0x17e7
    3331:	c9                   	leave
    3332:	ca 0a 00             	retf   0xa
    3335:	55                   	push   bp
    3336:	89 e5                	mov    bp,sp
    3338:	b8 38 01             	mov    ax,0x138
    333b:	9a 44 04 50 33       	call   0x3350:0x444
    3340:	81 ec 38 01          	sub    sp,0x138
    3344:	8d 7e cc             	lea    di,[bp-0x34]
    3347:	16                   	push   ss
    3348:	57                   	push   di
    3349:	6a 32                	push   0x32
    334b:	6a 00                	push   0x0
    334d:	9a e5 1e 36 34       	call   0x3436:0x1ee5
    3352:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3355:	89 7e c8             	mov    WORD PTR [bp-0x38],di
    3358:	8c 46 ca             	mov    WORD PTR [bp-0x36],es
    335b:	06                   	push   es
    335c:	57                   	push   di
    335d:	9a 19 11 7d 33       	call   0x337d:0x1119
    3362:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    3365:	31 c0                	xor    ax,ax
    3367:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    336a:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    336d:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    3370:	31 c0                	xor    ax,ax
    3372:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    3375:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    3378:	06                   	push   es
    3379:	57                   	push   di
    337a:	9a 1a 12 97 33       	call   0x3397:0x121a
    337f:	a8 01                	test   al,0x1
    3381:	74 07                	je     0x338a
    3383:	c7 46 d4 bc 02       	mov    WORD PTR [bp-0x2c],0x2bc
    3388:	eb 05                	jmp    0x338f
    338a:	c7 46 d4 90 01       	mov    WORD PTR [bp-0x2c],0x190
    338f:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    3392:	06                   	push   es
    3393:	57                   	push   di
    3394:	9a 1a 12 ab 33       	call   0x33ab:0x121a
    3399:	a8 02                	test   al,0x2
    339b:	b0 00                	mov    al,0x0
    339d:	74 01                	je     0x33a0
    339f:	40                   	inc    ax
    33a0:	88 46 d6             	mov    BYTE PTR [bp-0x2a],al
    33a3:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    33a6:	06                   	push   es
    33a7:	57                   	push   di
    33a8:	9a 1a 12 bf 33       	call   0x33bf:0x121a
    33ad:	a8 04                	test   al,0x4
    33af:	b0 00                	mov    al,0x0
    33b1:	74 01                	je     0x33b4
    33b3:	40                   	inc    ax
    33b4:	88 46 d7             	mov    BYTE PTR [bp-0x29],al
    33b7:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    33ba:	06                   	push   es
    33bb:	57                   	push   di
    33bc:	9a 1a 12 e2 33       	call   0x33e2:0x121a
    33c1:	a8 08                	test   al,0x8
    33c3:	b0 00                	mov    al,0x0
    33c5:	74 01                	je     0x33c8
    33c7:	40                   	inc    ax
    33c8:	88 46 d8             	mov    BYTE PTR [bp-0x28],al
    33cb:	c6 46 d9 01          	mov    BYTE PTR [bp-0x27],0x1
    33cf:	8d 7e de             	lea    di,[bp-0x22]
    33d2:	16                   	push   ss
    33d3:	57                   	push   di
    33d4:	8d be c8 fe          	lea    di,[bp-0x138]
    33d8:	16                   	push   ss
    33d9:	57                   	push   di
    33da:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    33dd:	06                   	push   es
    33de:	57                   	push   di
    33df:	9a 5e 11 fd 33       	call   0x33fd:0x115e
    33e4:	9a 4c 0d 75 34       	call   0x3475:0xd4c
    33e9:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
    33ed:	c6 46 da 00          	mov    BYTE PTR [bp-0x26],0x0
    33f1:	c6 46 db 00          	mov    BYTE PTR [bp-0x25],0x0
    33f5:	c4 7e c8             	les    di,DWORD PTR [bp-0x38]
    33f8:	06                   	push   es
    33f9:	57                   	push   di
    33fa:	9a 5f 12 ff ff       	call   0xffff:0x125f
    33ff:	3c 01                	cmp    al,0x1
    3401:	75 06                	jne    0x3409
    3403:	c6 46 dd 02          	mov    BYTE PTR [bp-0x23],0x2
    3407:	eb 0e                	jmp    0x3417
    3409:	3c 02                	cmp    al,0x2
    340b:	75 06                	jne    0x3413
    340d:	c6 46 dd 01          	mov    BYTE PTR [bp-0x23],0x1
    3411:	eb 04                	jmp    0x3417
    3413:	c6 46 dd 00          	mov    BYTE PTR [bp-0x23],0x0
    3417:	8d 7e cc             	lea    di,[bp-0x34]
    341a:	16                   	push   ss
    341b:	57                   	push   di
    341c:	9a ff ff 00 00       	call   0x0:0xffff
    3421:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3424:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3427:	c9                   	leave
    3428:	ca 06 00             	retf   0x6
    342b:	01 00                	add    WORD PTR [bx+si],ax
    342d:	55                   	push   bp
    342e:	89 e5                	mov    bp,sp
    3430:	b8 00 03             	mov    ax,0x300
    3433:	9a 44 04 4d 34       	call   0x344d:0x444
    3438:	81 ec 00 03          	sub    sp,0x300
    343c:	8d be 00 fd          	lea    di,[bp-0x300]
    3440:	16                   	push   ss
    3441:	57                   	push   di
    3442:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3445:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3448:	06                   	push   es
    3449:	57                   	push   di
    344a:	9a ed 20 57 34       	call   0x3457:0x20ed
    344f:	bf 2b 34             	mov    di,0x342b
    3452:	0e                   	push   cs
    3453:	57                   	push   di
    3454:	9a 4c 18 65 34       	call   0x3465:0x184c
    3459:	8d be 00 ff          	lea    di,[bp-0x100]
    345d:	16                   	push   ss
    345e:	57                   	push   di
    345f:	68 ff 00             	push   0xff
    3462:	9a e7 17 7f 34       	call   0x347f:0x17e7
    3467:	8d be 00 fd          	lea    di,[bp-0x300]
    346b:	16                   	push   ss
    346c:	57                   	push   di
    346d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3470:	06                   	push   es
    3471:	57                   	push   di
    3472:	9a e6 29 40 38       	call   0x3840:0x29e6
    3477:	bf 2b 34             	mov    di,0x342b
    347a:	0e                   	push   cs
    347b:	57                   	push   di
    347c:	9a 4c 18 8d 34       	call   0x348d:0x184c
    3481:	8d be 00 fe          	lea    di,[bp-0x200]
    3485:	16                   	push   ss
    3486:	57                   	push   di
    3487:	68 ff 00             	push   0xff
    348a:	9a e7 17 b8 34       	call   0x34b8:0x17e7
    348f:	6a 00                	push   0x0
    3491:	9a ff ff 00 00       	call   0x0:0xffff
    3496:	6a 00                	push   0x0
    3498:	8d be 01 fe          	lea    di,[bp-0x1ff]
    349c:	16                   	push   ss
    349d:	57                   	push   di
    349e:	8d be 01 ff          	lea    di,[bp-0xff]
    34a2:	16                   	push   ss
    34a3:	57                   	push   di
    34a4:	68 00 20             	push   0x2000
    34a7:	9a ff ff 00 00       	call   0x0:0xffff
    34ac:	c9                   	leave
    34ad:	ca 04 00             	retf   0x4
    34b0:	55                   	push   bp
    34b1:	89 e5                	mov    bp,sp
    34b3:	31 c0                	xor    ax,ax
    34b5:	9a 44 04 d0 34       	call   0x34d0:0x444
    34ba:	9a 42 2e 12 35       	call   0x3512:0x2e42
    34bf:	9b dd 1e 00 05       	fstp   QWORD PTR ds:0x500
    34c4:	90                   	nop
    34c5:	9b                   	fwait
    34c6:	c9                   	leave
    34c7:	cb                   	retf
    34c8:	55                   	push   bp
    34c9:	89 e5                	mov    bp,sp
    34cb:	31 c0                	xor    ax,ax
    34cd:	9a 44 04 e8 34       	call   0x34e8:0x444
    34d2:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    34d5:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    34d9:	76 39                	jbe    0x3514
    34db:	26 8a 05             	mov    al,BYTE PTR es:[di]
    34de:	30 e4                	xor    ah,ah
    34e0:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    34e3:	76 05                	jbe    0x34ea
    34e5:	9a 38 04 05 35       	call   0x3505:0x438
    34ea:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    34ed:	03 f8                	add    di,ax
    34ef:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    34f3:	75 1f                	jne    0x3514
    34f5:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    34f8:	06                   	push   es
    34f9:	57                   	push   di
    34fa:	26 8a 05             	mov    al,BYTE PTR es:[di]
    34fd:	30 e4                	xor    ah,ah
    34ff:	50                   	push   ax
    3500:	6a 01                	push   0x1
    3502:	9a 75 19 9d 35       	call   0x359d:0x1975
    3507:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    350a:	06                   	push   es
    350b:	57                   	push   di
    350c:	ff 76 06             	push   WORD PTR [bp+0x6]
    350f:	9a c8 34 af 38       	call   0x38af:0x34c8
    3514:	c9                   	leave
    3515:	ca 06 00             	retf   0x6
    3518:	23 53 69             	and    dx,WORD PTR [bp+di+0x69]
    351b:	6d                   	ins    WORD PTR es:[di],dx
    351c:	73 74                	jae    0x3592
    351e:	72 61                	jb     0x3581
    3520:	74 20                	je     0x3542
    3522:	70 6f                	jo     0x3593
    3524:	75 72                	jne    0x3598
    3526:	20 57 69             	and    BYTE PTR [bx+0x69],dl
    3529:	6e                   	outs   dx,BYTE PTR ds:[si]
    352a:	64 6f                	outs   dx,WORD PTR fs:[si]
    352c:	77 73                	ja     0x35a1
    352e:	2e 20 56 65          	and    BYTE PTR cs:[bp+0x65],dl
    3532:	72 73                	jb     0x35a7
    3534:	69 6f 6e 20 31       	imul   bp,WORD PTR [bx+0x6e],0x3120
    3539:	2e 31 30             	xor    WORD PTR cs:[bx+si],si
    353c:	0a 31                	or     dh,BYTE PTR [bx+di]
    353e:	34 2f                	xor    al,0x2f
    3540:	30 35                	xor    BYTE PTR [di],dh
    3542:	2f                   	das
    3543:	31 39                	xor    WORD PTR [bx+di],di
    3545:	39 39                	cmp    WORD PTR [bx+di],di
    3547:	01 00                	add    WORD PTR [bx+si],ax
    3549:	00 00                	add    BYTE PTR [bx+si],al
    354b:	06                   	push   es
    354c:	00 00                	add    BYTE PTR [bx+si],al
    354e:	00 01                	add    BYTE PTR [bx+di],al
    3550:	00 00                	add    BYTE PTR [bx+si],al
    3552:	00 0c                	add    BYTE PTR [si],cl
    3554:	00 00                	add    BYTE PTR [bx+si],al
    3556:	00 2c                	add    BYTE PTR [si],ch
    3558:	55                   	push   bp
    3559:	74 69                	je     0x35c4
    355b:	6c                   	ins    BYTE PTR es:[di],dx
    355c:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    3561:	6f                   	outs   dx,WORD PTR ds:[si]
    3562:	6e                   	outs   dx,BYTE PTR ds:[si]
    3563:	20 65 78             	and    BYTE PTR [di+0x78],ah
    3566:	63 6c 75             	arpl   WORD PTR [si+0x75],bp
    3569:	73 69                	jae    0x35d4
    356b:	76 65                	jbe    0x35d2
    356d:	20 65 6e             	and    BYTE PTR [di+0x6e],ah
    3570:	20 55 4e             	and    BYTE PTR [di+0x4e],dl
    3573:	20 65 78             	and    BYTE PTR [di+0x78],ah
    3576:	65 6d                	gs ins WORD PTR es:[di],dx
    3578:	70 6c                	jo     0x35e6
    357a:	61                   	popa
    357b:	69 72 65 20 70       	imul   si,WORD PTR [bp+si+0x65],0x7020
    3580:	61                   	popa
    3581:	72 3a                	jb     0x35bd
    3583:	20 01                	and    BYTE PTR [bx+di],al
    3585:	00 00                	add    BYTE PTR [bx+si],al
    3587:	00 04                	add    BYTE PTR [si],al
    3589:	00 00                	add    BYTE PTR [bx+si],al
    358b:	00 00                	add    BYTE PTR [bx+si],al
    358d:	00 00                	add    BYTE PTR [bx+si],al
    358f:	00 31                	add    BYTE PTR [bx+di],dh
    3591:	00 00                	add    BYTE PTR [bx+si],al
    3593:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3596:	e5 b8                	in     ax,0xb8
    3598:	0e                   	push   cs
    3599:	01 9a 44 04          	add    WORD PTR [bp+si+0x444],bx
    359d:	b3 35                	mov    bl,0x35
    359f:	81 ec 0e 01          	sub    sp,0x10e
    35a3:	bf 18 35             	mov    di,0x3518
    35a6:	0e                   	push   cs
    35a7:	57                   	push   di
    35a8:	bf 0c 20             	mov    di,0x200c
    35ab:	1e                   	push   ds
    35ac:	57                   	push   di
    35ad:	68 ff 00             	push   0xff
    35b0:	9a e7 17 c4 35       	call   0x35c4:0x17e7
    35b5:	bf 3c 35             	mov    di,0x353c
    35b8:	0e                   	push   cs
    35b9:	57                   	push   di
    35ba:	bf 0c 21             	mov    di,0x210c
    35bd:	1e                   	push   ds
    35be:	57                   	push   di
    35bf:	6a 0a                	push   0xa
    35c1:	9a e7 17 fa 35       	call   0x35fa:0x17e7
    35c6:	a1 42 05             	mov    ax,ds:0x542
    35c9:	8b 1e 44 05          	mov    bx,WORD PTR ds:0x544
    35cd:	8b 16 46 05          	mov    dx,WORD PTR ds:0x546
    35d1:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    35d4:	89 5e fc             	mov    WORD PTR [bp-0x4],bx
    35d7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    35da:	c7 46 f2 01 00       	mov    WORD PTR [bp-0xe],0x1
    35df:	c7 46 f4 00 00       	mov    WORD PTR [bp-0xc],0x0
    35e4:	eb 08                	jmp    0x35ee
    35e6:	83 46 f2 01          	add    WORD PTR [bp-0xe],0x1
    35ea:	83 56 f4 00          	adc    WORD PTR [bp-0xc],0x0
    35ee:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    35f1:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    35f4:	bf 47 35             	mov    di,0x3547
    35f7:	9a 16 04 12 36       	call   0x3612:0x416
    35fc:	8b f8                	mov    di,ax
    35fe:	80 7b f9 00          	cmp    BYTE PTR [bp+di-0x7],0x0
    3602:	75 51                	jne    0x3655
    3604:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3607:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    360a:	b9 02 00             	mov    cx,0x2
    360d:	31 db                	xor    bx,bx
    360f:	9a 5c 17 1f 36       	call   0x361f:0x175c
    3614:	2d 01 00             	sub    ax,0x1
    3617:	83 da 00             	sbb    dx,0x0
    361a:	71 05                	jno    0x3621
    361c:	9a 3e 04 27 36       	call   0x3627:0x43e
    3621:	bf 4f 35             	mov    di,0x354f
    3624:	9a 16 04 42 36       	call   0x3642:0x416
    3629:	8b f8                	mov    di,ax
    362b:	c6 85 16 21 01       	mov    BYTE PTR [di+0x2116],0x1
    3630:	8a 46 f2             	mov    al,BYTE PTR [bp-0xe]
    3633:	50                   	push   ax
    3634:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3637:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    363a:	b9 02 00             	mov    cx,0x2
    363d:	31 db                	xor    bx,bx
    363f:	9a 5c 17 4a 36       	call   0x364a:0x175c
    3644:	bf 4f 35             	mov    di,0x354f
    3647:	9a 16 04 63 36       	call   0x3663:0x416
    364c:	8b f8                	mov    di,ax
    364e:	58                   	pop    ax
    364f:	88 85 16 21          	mov    BYTE PTR [di+0x2116],al
    3653:	eb 5f                	jmp    0x36b4
    3655:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3658:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    365b:	b9 02 00             	mov    cx,0x2
    365e:	31 db                	xor    bx,bx
    3660:	9a 5c 17 70 36       	call   0x3670:0x175c
    3665:	2d 01 00             	sub    ax,0x1
    3668:	83 da 00             	sbb    dx,0x0
    366b:	71 05                	jno    0x3672
    366d:	9a 3e 04 78 36       	call   0x3678:0x43e
    3672:	bf 4f 35             	mov    di,0x354f
    3675:	9a 16 04 8d 36       	call   0x368d:0x416
    367a:	8b f8                	mov    di,ax
    367c:	c6 85 16 21 02       	mov    BYTE PTR [di+0x2116],0x2
    3681:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3684:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    3687:	bf 47 35             	mov    di,0x3547
    368a:	9a 16 04 a3 36       	call   0x36a3:0x416
    368f:	8b f8                	mov    di,ax
    3691:	8a 43 f9             	mov    al,BYTE PTR [bp+di-0x7]
    3694:	50                   	push   ax
    3695:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3698:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    369b:	b9 02 00             	mov    cx,0x2
    369e:	31 db                	xor    bx,bx
    36a0:	9a 5c 17 ab 36       	call   0x36ab:0x175c
    36a5:	bf 4f 35             	mov    di,0x354f
    36a8:	9a 16 04 fa 36       	call   0x36fa:0x416
    36ad:	8b f8                	mov    di,ax
    36af:	58                   	pop    ax
    36b0:	88 85 16 21          	mov    BYTE PTR [di+0x2116],al
    36b4:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    36b8:	74 03                	je     0x36bd
    36ba:	e9 29 ff             	jmp    0x35e6
    36bd:	83 7e f2 06          	cmp    WORD PTR [bp-0xe],0x6
    36c1:	74 03                	je     0x36c6
    36c3:	e9 20 ff             	jmp    0x35e6
    36c6:	a1 48 05             	mov    ax,ds:0x548
    36c9:	8b 1e 4a 05          	mov    bx,WORD PTR ds:0x54a
    36cd:	8b 16 4c 05          	mov    dx,WORD PTR ds:0x54c
    36d1:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    36d4:	89 5e fc             	mov    WORD PTR [bp-0x4],bx
    36d7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    36da:	c7 46 f2 01 00       	mov    WORD PTR [bp-0xe],0x1
    36df:	c7 46 f4 00 00       	mov    WORD PTR [bp-0xc],0x0
    36e4:	eb 08                	jmp    0x36ee
    36e6:	83 46 f2 01          	add    WORD PTR [bp-0xe],0x1
    36ea:	83 56 f4 00          	adc    WORD PTR [bp-0xc],0x0
    36ee:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    36f1:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    36f4:	bf 47 35             	mov    di,0x3547
    36f7:	9a 16 04 12 37       	call   0x3712:0x416
    36fc:	8b f8                	mov    di,ax
    36fe:	80 7b f9 00          	cmp    BYTE PTR [bp+di-0x7],0x0
    3702:	75 51                	jne    0x3755
    3704:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3707:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    370a:	b9 02 00             	mov    cx,0x2
    370d:	31 db                	xor    bx,bx
    370f:	9a 5c 17 1f 37       	call   0x371f:0x175c
    3714:	2d 01 00             	sub    ax,0x1
    3717:	83 da 00             	sbb    dx,0x0
    371a:	71 05                	jno    0x3721
    371c:	9a 3e 04 27 37       	call   0x3727:0x43e
    3721:	bf 4f 35             	mov    di,0x354f
    3724:	9a 16 04 42 37       	call   0x3742:0x416
    3729:	8b f8                	mov    di,ax
    372b:	c6 85 22 21 01       	mov    BYTE PTR [di+0x2122],0x1
    3730:	8a 46 f2             	mov    al,BYTE PTR [bp-0xe]
    3733:	50                   	push   ax
    3734:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3737:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    373a:	b9 02 00             	mov    cx,0x2
    373d:	31 db                	xor    bx,bx
    373f:	9a 5c 17 4a 37       	call   0x374a:0x175c
    3744:	bf 4f 35             	mov    di,0x354f
    3747:	9a 16 04 63 37       	call   0x3763:0x416
    374c:	8b f8                	mov    di,ax
    374e:	58                   	pop    ax
    374f:	88 85 22 21          	mov    BYTE PTR [di+0x2122],al
    3753:	eb 5f                	jmp    0x37b4
    3755:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3758:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    375b:	b9 02 00             	mov    cx,0x2
    375e:	31 db                	xor    bx,bx
    3760:	9a 5c 17 70 37       	call   0x3770:0x175c
    3765:	2d 01 00             	sub    ax,0x1
    3768:	83 da 00             	sbb    dx,0x0
    376b:	71 05                	jno    0x3772
    376d:	9a 3e 04 78 37       	call   0x3778:0x43e
    3772:	bf 4f 35             	mov    di,0x354f
    3775:	9a 16 04 8d 37       	call   0x378d:0x416
    377a:	8b f8                	mov    di,ax
    377c:	c6 85 22 21 02       	mov    BYTE PTR [di+0x2122],0x2
    3781:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3784:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    3787:	bf 47 35             	mov    di,0x3547
    378a:	9a 16 04 a3 37       	call   0x37a3:0x416
    378f:	8b f8                	mov    di,ax
    3791:	8a 43 f9             	mov    al,BYTE PTR [bp+di-0x7]
    3794:	50                   	push   ax
    3795:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3798:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    379b:	b9 02 00             	mov    cx,0x2
    379e:	31 db                	xor    bx,bx
    37a0:	9a 5c 17 ab 37       	call   0x37ab:0x175c
    37a5:	bf 4f 35             	mov    di,0x354f
    37a8:	9a 16 04 d6 37       	call   0x37d6:0x416
    37ad:	8b f8                	mov    di,ax
    37af:	58                   	pop    ax
    37b0:	88 85 22 21          	mov    BYTE PTR [di+0x2122],al
    37b4:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    37b8:	74 03                	je     0x37bd
    37ba:	e9 29 ff             	jmp    0x36e6
    37bd:	83 7e f2 06          	cmp    WORD PTR [bp-0xe],0x6
    37c1:	74 03                	je     0x37c6
    37c3:	e9 20 ff             	jmp    0x36e6
    37c6:	bf 57 35             	mov    di,0x3557
    37c9:	0e                   	push   cs
    37ca:	57                   	push   di
    37cb:	bf 2f 21             	mov    di,0x212f
    37ce:	1e                   	push   ds
    37cf:	57                   	push   di
    37d0:	68 ff 00             	push   0xff
    37d3:	9a e7 17 f8 37       	call   0x37f8:0x17e7
    37d8:	c7 46 f6 01 00       	mov    WORD PTR [bp-0xa],0x1
    37dd:	c7 46 f8 00 00       	mov    WORD PTR [bp-0x8],0x0
    37e2:	eb 08                	jmp    0x37ec
    37e4:	83 46 f6 01          	add    WORD PTR [bp-0xa],0x1
    37e8:	83 56 f8 00          	adc    WORD PTR [bp-0x8],0x0
    37ec:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    37ef:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    37f2:	bf 84 35             	mov    di,0x3584
    37f5:	9a 16 04 11 38       	call   0x3811:0x416
    37fa:	8b f8                	mov    di,ax
    37fc:	c1 e7 08             	shl    di,0x8
    37ff:	81 c7 56 04          	add    di,0x456
    3803:	1e                   	push   ds
    3804:	57                   	push   di
    3805:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    3808:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    380b:	bf 84 35             	mov    di,0x3584
    380e:	9a 16 04 24 38       	call   0x3824:0x416
    3813:	8b f8                	mov    di,ax
    3815:	c1 e7 08             	shl    di,0x8
    3818:	81 c7 2f 21          	add    di,0x212f
    381c:	1e                   	push   ds
    381d:	57                   	push   di
    381e:	68 ff 00             	push   0xff
    3821:	9a e7 17 5c 38       	call   0x385c:0x17e7
    3826:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    382a:	75 b8                	jne    0x37e4
    382c:	83 7e f6 04          	cmp    WORD PTR [bp-0xa],0x4
    3830:	75 b2                	jne    0x37e4
    3832:	c6 06 2f 26 00       	mov    BYTE PTR ds:0x262f,0x0
    3837:	8d be f2 fe          	lea    di,[bp-0x10e]
    383b:	16                   	push   ss
    383c:	57                   	push   di
    383d:	9a fe 15 50 38       	call   0x3850:0x15fe
    3842:	83 ec 08             	sub    sp,0x8
    3845:	89 e3                	mov    bx,sp
    3847:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    384b:	90                   	nop
    384c:	9b                   	fwait
    384d:	9a bf 1c ff ff       	call   0xffff:0x1cbf
    3852:	bf 2f 27             	mov    di,0x272f
    3855:	1e                   	push   ds
    3856:	57                   	push   di
    3857:	6a 0a                	push   0xa
    3859:	9a e7 17 81 38       	call   0x3881:0x17e7
    385e:	31 c0                	xor    ax,ax
    3860:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3863:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3866:	eb 08                	jmp    0x3870
    3868:	83 46 f6 01          	add    WORD PTR [bp-0xa],0x1
    386c:	83 56 f8 00          	adc    WORD PTR [bp-0x8],0x0
    3870:	bf 64 09             	mov    di,0x964
    3873:	1e                   	push   ds
    3874:	57                   	push   di
    3875:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    3878:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    387b:	bf 8c 35             	mov    di,0x358c
    387e:	9a 16 04 91 38       	call   0x3891:0x416
    3883:	6b f8 0c             	imul   di,ax,0xc
    3886:	81 c7 3a 27          	add    di,0x273a
    388a:	1e                   	push   ds
    388b:	57                   	push   di
    388c:	6a 0c                	push   0xc
    388e:	9a 1b 16 eb 38       	call   0x38eb:0x161b
    3893:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    3897:	75 cf                	jne    0x3868
    3899:	83 7e f6 31          	cmp    WORD PTR [bp-0xa],0x31
    389d:	75 c9                	jne    0x3868
    389f:	c6 06 92 29 00       	mov    BYTE PTR ds:0x2992,0x0
    38a4:	bf 0c 20             	mov    di,0x200c
    38a7:	1e                   	push   ds
    38a8:	57                   	push   di
    38a9:	68 ff 00             	push   0xff
    38ac:	9a c8 34 bc 38       	call   0x38bc:0x34c8
    38b1:	bf 2f 21             	mov    di,0x212f
    38b4:	1e                   	push   ds
    38b5:	57                   	push   di
    38b6:	68 ff 00             	push   0xff
    38b9:	9a c8 34 c9 38       	call   0x38c9:0x34c8
    38be:	bf 2f 26             	mov    di,0x262f
    38c1:	1e                   	push   ds
    38c2:	57                   	push   di
    38c3:	68 ff 00             	push   0xff
    38c6:	9a c8 34 fe 38       	call   0x38fe:0x34c8
    38cb:	c7 46 f2 01 00       	mov    WORD PTR [bp-0xe],0x1
    38d0:	c7 46 f4 00 00       	mov    WORD PTR [bp-0xc],0x0
    38d5:	eb 08                	jmp    0x38df
    38d7:	83 46 f2 01          	add    WORD PTR [bp-0xe],0x1
    38db:	83 56 f4 00          	adc    WORD PTR [bp-0xc],0x0
    38df:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    38e2:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    38e5:	bf 84 35             	mov    di,0x3584
    38e8:	9a 16 04 28 39       	call   0x3928:0x416
    38ed:	8b f8                	mov    di,ax
    38ef:	c1 e7 08             	shl    di,0x8
    38f2:	81 c7 2f 21          	add    di,0x212f
    38f6:	1e                   	push   ds
    38f7:	57                   	push   di
    38f8:	68 ff 00             	push   0xff
    38fb:	9a c8 34 3e 3a       	call   0x3a3e:0x34c8
    3900:	83 7e f4 00          	cmp    WORD PTR [bp-0xc],0x0
    3904:	75 d1                	jne    0x38d7
    3906:	83 7e f2 04          	cmp    WORD PTR [bp-0xe],0x4
    390a:	75 cb                	jne    0x38d7
    390c:	c9                   	leave
    390d:	cb                   	retf
    390e:	2e 3a b7 39 00       	cmp    dh,BYTE PTR cs:[bx+0x39]
    3913:	00 00                	add    BYTE PTR [bx+si],al
    3915:	00 aa 39 98          	add    BYTE PTR [bp+si-0x67c7],ch
    3919:	01 fb                	add    bx,di
    391b:	04 42                	add    al,0x42
    391d:	3a 39                	cmp    bh,BYTE PTR [bx+di]
    391f:	3f                   	aas
    3920:	34 39                	xor    al,0x39
    3922:	9a 1f 03 3b cb       	call   0xcb3b:0x31f
    3927:	1f                   	pop    ds
    3928:	24 39                	and    al,0x39
    392a:	ad                   	lods   ax,WORD PTR ds:[si]
    392b:	27                   	daa
    392c:	a8 39                	test   al,0x39
    392e:	cd 11                	int    0x11
    3930:	38 39                	cmp    BYTE PTR [bx+di],bh
    3932:	f7 2a                	imul   WORD PTR [bp+si]
    3934:	94                   	xchg   sp,ax
    3935:	39 fa                	cmp    dx,di
    3937:	10 7b 3b             	adc    BYTE PTR [bp+di+0x3b],bh
    393a:	d6                   	(bad)
    393b:	14 6c                	adc    al,0x6c
    393d:	39 f4                	cmp    sp,si
    393f:	4f                   	dec    di
    3940:	58                   	pop    ax
    3941:	39 9a 28 a0          	cmp    WORD PTR [bp+si-0x5fd8],bx
    3945:	39 85 29 4c          	cmp    WORD PTR [di+0x4c29],ax
    3949:	39 57 4d             	cmp    WORD PTR [bx+0x4d],dx
    394c:	50                   	push   ax
    394d:	39 91 2f 70          	cmp    WORD PTR [bx+di+0x702f],dx
    3951:	39 63 31             	cmp    WORD PTR [bp+di+0x31],sp
    3954:	74 39                	je     0x398f
    3956:	21 50 30             	and    WORD PTR [bx+si+0x30],dx
    3959:	39 53 25             	cmp    WORD PTR [bp+di+0x25],dx
    395c:	2c 39                	sub    al,0x39
    395e:	d9 62 68             	fldenv [bp+si+0x68]
    3961:	39 55 2e             	cmp    WORD PTR [di+0x2e],dx
    3964:	44                   	inc    sp
    3965:	39 8f 60 a4          	cmp    WORD PTR [bx-0x5ba0],cx
    3969:	39 3a                	cmp    WORD PTR [bp+si],di
    396b:	1c 9d                	sbb    al,0x9d
    396d:	3a e2                	cmp    ah,dl
    396f:	2f                   	das
    3970:	5c                   	pop    sp
    3971:	39 08                	cmp    WORD PTR [bx+si],cx
    3973:	61                   	popa
    3974:	78 39                	js     0x39af
    3976:	5c                   	pop    sp
    3977:	61                   	popa
    3978:	7c 39                	jl     0x39b3
    397a:	62 5c 80             	bound  bx,DWORD PTR [si-0x80]
    397d:	39 3a                	cmp    WORD PTR [bp+si],di
    397f:	61                   	popa
    3980:	3c 39                	cmp    al,0x39
    3982:	72 3f                	jb     0x39c3
    3984:	98                   	cbw
    3985:	39 58 3a             	cmp    WORD PTR [bx+si+0x3a],bx
    3988:	8c 39                	mov    WORD PTR [bx+di],?
    398a:	ec                   	in     al,dx
    398b:	3d 90 39             	cmp    ax,0x3990
    398e:	e4 3c                	in     al,0x3c
    3990:	20 39                	and    BYTE PTR [bx+di],bh
    3992:	ed                   	in     ax,dx
    3993:	3e 64 39 77 3e       	ds cmp WORD PTR fs:[bx+0x3e],si
    3998:	60                   	pusha
    3999:	39 e6                	cmp    si,sp
    399b:	31 88 39 3c          	xor    WORD PTR [bx+si+0x3c39],cx
    399f:	47                   	inc    di
    39a0:	48                   	dec    ax
    39a1:	39 ae 5f 54          	cmp    WORD PTR [bp+0x545f],bp
    39a5:	39 e9                	cmp    cx,bp
    39a7:	5c                   	pop    sp
    39a8:	1c 39                	sbb    al,0x39
    39aa:	0c 54                	or     al,0x54
    39ac:	4c                   	dec    sp
    39ad:	6f                   	outs   dx,WORD PTR ds:[si]
    39ae:	67 69 6e 44 69 61    	imul   bp,WORD PTR [esi+0x44],0x6169
    39b4:	6c                   	ins    BYTE PTR es:[di],dx
    39b5:	6f                   	outs   dx,WORD PTR ds:[si]
    39b6:	67 07                	addr32 pop es
    39b8:	00 18                	add    BYTE PTR [bx+si],bl
    39ba:	3a 7c 01             	cmp    bh,BYTE PTR [si+0x1]
    39bd:	00 00                	add    BYTE PTR [bx+si],al
    39bf:	05 50 61             	add    ax,0x6150
    39c2:	6e                   	outs   dx,BYTE PTR ds:[si]
    39c3:	65 6c                	gs ins BYTE PTR es:[di],dx
    39c5:	80 01 04             	add    BYTE PTR [bx+di],0x4
    39c8:	00 05                	add    BYTE PTR [di],al
    39ca:	42                   	inc    dx
    39cb:	65 76 65             	gs jbe 0x3a33
    39ce:	6c                   	ins    BYTE PTR es:[di],dx
    39cf:	84 01                	test   BYTE PTR [bx+di],al
    39d1:	08 00                	or     BYTE PTR [bx+si],al
    39d3:	0c 44                	or     al,0x44
    39d5:	61                   	popa
    39d6:	74 61                	je     0x3a39
    39d8:	62 61 73             	bound  sp,DWORD PTR [bx+di+0x73]
    39db:	65 4e                	gs dec si
    39dd:	61                   	popa
    39de:	6d                   	ins    WORD PTR es:[di],dx
    39df:	65 88 01             	mov    BYTE PTR gs:[bx+di],al
    39e2:	0c 00                	or     al,0x0
    39e4:	08 55 73             	or     BYTE PTR [di+0x73],dl
    39e7:	65 72 4e             	gs jb  0x3a38
    39ea:	61                   	popa
    39eb:	6d                   	ins    WORD PTR es:[di],dx
    39ec:	65 8c 01             	mov    WORD PTR gs:[bx+di],es
    39ef:	0c 00                	or     al,0x0
    39f1:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    39f4:	73 73                	jae    0x3a69
    39f6:	77 6f                	ja     0x3a67
    39f8:	72 64                	jb     0x3a5e
    39fa:	90                   	nop
    39fb:	01 10                	add    WORD PTR [bx+si],dx
    39fd:	00 08                	add    BYTE PTR [bx+si],cl
    39ff:	4f                   	dec    di
    3a00:	4b                   	dec    bx
    3a01:	42                   	inc    dx
    3a02:	75 74                	jne    0x3a78
    3a04:	74 6f                	je     0x3a75
    3a06:	6e                   	outs   dx,BYTE PTR ds:[si]
    3a07:	94                   	xchg   sp,ax
    3a08:	01 10                	add    WORD PTR [bx+si],dx
    3a0a:	00 0c                	add    BYTE PTR [si],cl
    3a0c:	43                   	inc    bx
    3a0d:	61                   	popa
    3a0e:	6e                   	outs   dx,BYTE PTR ds:[si]
    3a0f:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
    3a12:	42                   	inc    dx
    3a13:	75 74                	jne    0x3a89
    3a15:	74 6f                	je     0x3a86
    3a17:	6e                   	outs   dx,BYTE PTR ds:[si]
    3a18:	05 00 ad             	add    ax,0xad00
    3a1b:	0d 20 3a             	or     ax,0x3a20
    3a1e:	2d 0a ff             	sub    ax,0xff0a
    3a21:	ff 17                	call   WORD PTR [bx]
    3a23:	06                   	push   es
    3a24:	28 3a                	sub    BYTE PTR [bp+si],bh
    3a26:	90                   	nop
    3a27:	0b ca                	or     cx,dx
    3a29:	3c ac                	cmp    al,0xac
    3a2b:	04 d6                	add    al,0xd6
    3a2d:	3c 07                	cmp    al,0x7
    3a2f:	0c 54                	or     al,0x54
    3a31:	4c                   	dec    sp
    3a32:	6f                   	outs   dx,WORD PTR ds:[si]
    3a33:	67 69 6e 44 69 61    	imul   bp,WORD PTR [esi+0x44],0x6169
    3a39:	6c                   	ins    BYTE PTR es:[di],dx
    3a3a:	6f                   	outs   dx,WORD PTR ds:[si]
    3a3b:	67 2e 39 55 3a       	cmp    WORD PTR cs:[ebp+0x3a],dx
    3a40:	7b 06                	jnp    0x3a48
    3a42:	71 3a                	jno    0x3a7e
    3a44:	38 00                	cmp    BYTE PTR [bx+si],al
    3a46:	08 44 42             	or     BYTE PTR [si+0x42],al
    3a49:	4c                   	dec    sp
    3a4a:	6f                   	outs   dx,WORD PTR ds:[si]
    3a4b:	67 44                	addr32 inc sp
    3a4d:	6c                   	ins    BYTE PTR es:[di],dx
    3a4e:	67 00 00             	add    BYTE PTR [eax],al
    3a51:	00 00                	add    BYTE PTR [bx+si],al
    3a53:	37                   	aaa
    3a54:	3b 6a 3a             	cmp    bp,WORD PTR [bp+si+0x3a]
    3a57:	c8 06 01 00          	enter  0x106,0x0
    3a5b:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    3a5f:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    3a63:	b0 01                	mov    al,0x1
    3a65:	50                   	push   ax
    3a66:	b8 2e 39             	mov    ax,0x392e
    3a69:	ba f9 3b             	mov    dx,0x3bf9
    3a6c:	52                   	push   dx
    3a6d:	50                   	push   ax
    3a6e:	9a 53 25 d2 3a       	call   0x3ad2:0x2553
    3a73:	89 c7                	mov    di,ax
    3a75:	8e c2                	mov    es,dx
    3a77:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3a7a:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3a7d:	b8 51 3a             	mov    ax,0x3a51
    3a80:	0e                   	push   cs
    3a81:	50                   	push   ax
    3a82:	55                   	push   bp
    3a83:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3a87:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3a8b:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3a8e:	06                   	push   es
    3a8f:	57                   	push   di
    3a90:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3a93:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3a98:	06                   	push   es
    3a99:	57                   	push   di
    3a9a:	9a 8c 1d b1 3a       	call   0x3ab1:0x1d8c
    3a9f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3aa2:	06                   	push   es
    3aa3:	57                   	push   di
    3aa4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3aa7:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3aac:	06                   	push   es
    3aad:	57                   	push   di
    3aae:	9a 8c 1d f6 3a       	call   0x3af6:0x1d8c
    3ab3:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    3ab7:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3aba:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    3abe:	75 14                	jne    0x3ad4
    3ac0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ac3:	26 ff b5 8a 01       	push   WORD PTR es:[di+0x18a]
    3ac8:	26 ff b5 88 01       	push   WORD PTR es:[di+0x188]
    3acd:	06                   	push   es
    3ace:	57                   	push   di
    3acf:	9a d0 3f dc 3a       	call   0x3adc:0x3fd0
    3ad4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ad7:	06                   	push   es
    3ad8:	57                   	push   di
    3ad9:	9a 45 5d d7 3b       	call   0x3bd7:0x5d45
    3ade:	3d 01 00             	cmp    ax,0x1
    3ae1:	75 48                	jne    0x3b2b
    3ae3:	8d be fa fe          	lea    di,[bp-0x106]
    3ae7:	16                   	push   ss
    3ae8:	57                   	push   di
    3ae9:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3aec:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3af1:	06                   	push   es
    3af2:	57                   	push   di
    3af3:	9a 53 1d 18 3b       	call   0x3b18:0x1d53
    3af8:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3afb:	06                   	push   es
    3afc:	57                   	push   di
    3afd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b00:	9a e7 17 25 3b       	call   0x3b25:0x17e7
    3b05:	8d be fa fe          	lea    di,[bp-0x106]
    3b09:	16                   	push   ss
    3b0a:	57                   	push   di
    3b0b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3b0e:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    3b13:	06                   	push   es
    3b14:	57                   	push   di
    3b15:	9a 53 1d bf 3b       	call   0x3bbf:0x1d53
    3b1a:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3b1d:	06                   	push   es
    3b1e:	57                   	push   di
    3b1f:	ff 76 06             	push   WORD PTR [bp+0x6]
    3b22:	9a e7 17 3f 3b       	call   0x3b3f:0x17e7
    3b27:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    3b2b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3b2f:	83 c4 06             	add    sp,0x6
    3b32:	b8 42 3b             	mov    ax,0x3b42
    3b35:	0e                   	push   cs
    3b36:	50                   	push   ax
    3b37:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3b3a:	06                   	push   es
    3b3b:	57                   	push   di
    3b3c:	9a 7f 1f 63 3b       	call   0x3b63:0x1f7f
    3b41:	cb                   	retf
    3b42:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3b45:	c9                   	leave
    3b46:	ca 10 00             	retf   0x10
    3b49:	d8 3c                	fdivr  DWORD PTR [si]
    3b4b:	5a                   	pop    dx
    3b4c:	3c f5                	cmp    al,0xf5
    3b4e:	3b 00                	cmp    ax,WORD PTR [bx+si]
    3b50:	00 e5                	add    ch,ah
    3b52:	3b 99 01 fb          	cmp    bx,WORD PTR [bx+di-0x4ff]
    3b56:	04 ef                	add    al,0xef
    3b58:	3c 39                	cmp    al,0x39
    3b5a:	3f                   	aas
    3b5b:	6f                   	outs   dx,WORD PTR ds:[si]
    3b5c:	3b 9a 1f 5d          	cmp    bx,WORD PTR [bp+si+0x5d1f]
    3b60:	3d cb 1f             	cmp    ax,0x1fcb
    3b63:	5f                   	pop    di
    3b64:	3b ad 27 e3          	cmp    bp,WORD PTR [di-0x1cd9]
    3b68:	3b cd                	cmp    cx,bp
    3b6a:	11 73 3b             	adc    WORD PTR [bp+di+0x3b],si
    3b6d:	f7 2a                	imul   WORD PTR [bp+si]
    3b6f:	cf                   	iret
    3b70:	3b fa                	cmp    di,dx
    3b72:	10 ff                	adc    bh,bh
    3b74:	ff d6                	call   si
    3b76:	14 a7                	adc    al,0xa7
    3b78:	3b f4                	cmp    si,sp
    3b7a:	4f                   	dec    di
    3b7b:	93                   	xchg   bx,ax
    3b7c:	3b 9a 28 db          	cmp    bx,WORD PTR [bp+si-0x24d8]
    3b80:	3b 85 29 87          	cmp    ax,WORD PTR [di-0x78d7]
    3b84:	3b 57 4d             	cmp    dx,WORD PTR [bx+0x4d]
    3b87:	8b 3b                	mov    di,WORD PTR [bp+di]
    3b89:	91                   	xchg   cx,ax
    3b8a:	2f                   	das
    3b8b:	ab                   	stos   WORD PTR es:[di],ax
    3b8c:	3b 63 31             	cmp    sp,WORD PTR [bp+di+0x31]
    3b8f:	af                   	scas   ax,WORD PTR es:[di]
    3b90:	3b 21                	cmp    sp,WORD PTR [bx+di]
    3b92:	50                   	push   ax
    3b93:	6b 3b 53             	imul   di,WORD PTR [bp+di],0x53
    3b96:	25 67 3b             	and    ax,0x3b67
    3b99:	d9 62 a3             	fldenv [bp+si-0x5d]
    3b9c:	3b 55 2e             	cmp    dx,WORD PTR [di+0x2e]
    3b9f:	7f 3b                	jg     0x3bdc
    3ba1:	8f                   	(bad)
    3ba2:	60                   	pusha
    3ba3:	df 3b                	fistp  QWORD PTR [bp+di]
    3ba5:	3a 1c                	cmp    bl,BYTE PTR [si]
    3ba7:	7c 3d                	jl     0x3be6
    3ba9:	e2 2f                	loop   0x3bda
    3bab:	97                   	xchg   di,ax
    3bac:	3b 08                	cmp    cx,WORD PTR [bx+si]
    3bae:	61                   	popa
    3baf:	b3 3b                	mov    bl,0x3b
    3bb1:	5c                   	pop    sp
    3bb2:	61                   	popa
    3bb3:	b7 3b                	mov    bh,0x3b
    3bb5:	62 5c bb             	bound  bx,DWORD PTR [si-0x45]
    3bb8:	3b 3a                	cmp    di,WORD PTR [bp+si]
    3bba:	61                   	popa
    3bbb:	77 3b                	ja     0x3bf8
    3bbd:	72 3f                	jb     0x3bfe
    3bbf:	d3 3b                	sar    WORD PTR [bp+di],cl
    3bc1:	58                   	pop    ax
    3bc2:	3a c7                	cmp    al,bh
    3bc4:	3b ec                	cmp    bp,sp
    3bc6:	3d cb 3b             	cmp    ax,0x3bcb
    3bc9:	e4 3c                	in     al,0x3c
    3bcb:	5b                   	pop    bx
    3bcc:	3b ed                	cmp    bp,bp
    3bce:	3e 9f                	ds lahf
    3bd0:	3b 77 3e             	cmp    si,WORD PTR [bx+0x3e]
    3bd3:	9b                   	fwait
    3bd4:	3b e6                	cmp    sp,si
    3bd6:	31 c3                	xor    bx,ax
    3bd8:	3b 3c                	cmp    di,WORD PTR [si]
    3bda:	47                   	inc    di
    3bdb:	83 3b ae             	cmp    WORD PTR [bp+di],0xffae
    3bde:	5f                   	pop    di
    3bdf:	8f                   	(bad)
    3be0:	3b e9                	cmp    bp,cx
    3be2:	5c                   	pop    sp
    3be3:	57                   	push   di
    3be4:	3b 0f                	cmp    cx,WORD PTR [bx]
    3be6:	54                   	push   sp
    3be7:	50                   	push   ax
    3be8:	61                   	popa
    3be9:	73 73                	jae    0x3c5e
    3beb:	77 6f                	ja     0x3c5c
    3bed:	72 64                	jb     0x3c53
    3bef:	44                   	inc    sp
    3bf0:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
    3bf5:	05 00 65             	add    ax,0x6500
    3bf8:	3d 08 3c             	cmp    ax,0x3c08
    3bfb:	0a 45 64             	or     al,BYTE PTR [di+0x64]
    3bfe:	69 74 43 68 61       	imul   si,WORD PTR [si+0x43],0x6168
    3c03:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c04:	67 65 df 3d 1b 3c 0e 	addr32 fistp QWORD PTR gs:0x410e3c1b
    3c0b:	41 
    3c0c:	64 64 42             	fs fs inc dx
    3c0f:	75 74                	jne    0x3c85
    3c11:	74 6f                	je     0x3c82
    3c13:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c14:	43                   	inc    bx
    3c15:	6c                   	ins    BYTE PTR es:[di],dx
    3c16:	69 63 6b 2d 3e       	imul   sp,WORD PTR [bp+di+0x6b],0x3e2d
    3c1b:	31 3c                	xor    WORD PTR [si],di
    3c1d:	11 52 65             	adc    WORD PTR [bp+si+0x65],dx
    3c20:	6d                   	ins    WORD PTR es:[di],dx
    3c21:	6f                   	outs   dx,WORD PTR ds:[si]
    3c22:	76 65                	jbe    0x3c89
    3c24:	42                   	inc    dx
    3c25:	75 74                	jne    0x3c9b
    3c27:	74 6f                	je     0x3c98
    3c29:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c2a:	43                   	inc    bx
    3c2b:	6c                   	ins    BYTE PTR es:[di],dx
    3c2c:	69 63 6b 75 3e       	imul   sp,WORD PTR [bp+di+0x6b],0x3e75
    3c31:	4a                   	dec    dx
    3c32:	3c 14                	cmp    al,0x14
    3c34:	52                   	push   dx
    3c35:	65 6d                	gs ins WORD PTR es:[di],dx
    3c37:	6f                   	outs   dx,WORD PTR ds:[si]
    3c38:	76 65                	jbe    0x3c9f
    3c3a:	41                   	inc    cx
    3c3b:	6c                   	ins    BYTE PTR es:[di],dx
    3c3c:	6c                   	ins    BYTE PTR es:[di],dx
    3c3d:	42                   	inc    dx
    3c3e:	75 74                	jne    0x3cb4
    3c40:	74 6f                	je     0x3cb1
    3c42:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c43:	43                   	inc    bx
    3c44:	6c                   	ins    BYTE PTR es:[di],dx
    3c45:	69 63 6b 98 3e       	imul   sp,WORD PTR [bp+di+0x6b],0x3e98
    3c4a:	eb 3c                	jmp    0x3c88
    3c4c:	0d 4f 4b             	or     ax,0x4b4f
    3c4f:	42                   	inc    dx
    3c50:	75 74                	jne    0x3cc6
    3c52:	74 6f                	je     0x3cc3
    3c54:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c55:	43                   	inc    bx
    3c56:	6c                   	ins    BYTE PTR es:[di],dx
    3c57:	69 63 6b 07 00       	imul   sp,WORD PTR [bp+di+0x6b],0x7
    3c5c:	c6                   	(bad)
    3c5d:	3c 7c                	cmp    al,0x7c
    3c5f:	01 00                	add    WORD PTR [bx+si],ax
    3c61:	00 09                	add    BYTE PTR [bx+di],cl
    3c63:	47                   	inc    di
    3c64:	72 6f                	jb     0x3cd5
    3c66:	75 70                	jne    0x3cd8
    3c68:	42                   	inc    dx
    3c69:	6f                   	outs   dx,WORD PTR ds:[si]
    3c6a:	78 31                	js     0x3c9d
    3c6c:	80 01 04             	add    BYTE PTR [bx+di],0x4
    3c6f:	00 04                	add    BYTE PTR [si],al
    3c71:	45                   	inc    bp
    3c72:	64 69 74 84 01 08    	imul   si,WORD PTR fs:[si-0x7c],0x801
    3c78:	00 09                	add    BYTE PTR [bx+di],cl
    3c7a:	41                   	inc    cx
    3c7b:	64 64 42             	fs fs inc dx
    3c7e:	75 74                	jne    0x3cf4
    3c80:	74 6f                	je     0x3cf1
    3c82:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c83:	88 01                	mov    BYTE PTR [bx+di],al
    3c85:	08 00                	or     BYTE PTR [bx+si],al
    3c87:	0c 52                	or     al,0x52
    3c89:	65 6d                	gs ins WORD PTR es:[di],dx
    3c8b:	6f                   	outs   dx,WORD PTR ds:[si]
    3c8c:	76 65                	jbe    0x3cf3
    3c8e:	42                   	inc    dx
    3c8f:	75 74                	jne    0x3d05
    3c91:	74 6f                	je     0x3d02
    3c93:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c94:	8c 01                	mov    WORD PTR [bx+di],es
    3c96:	08 00                	or     BYTE PTR [bx+si],al
    3c98:	0f 52 65 6d          	rsqrtps xmm4,XMMWORD PTR [di+0x6d]
    3c9c:	6f                   	outs   dx,WORD PTR ds:[si]
    3c9d:	76 65                	jbe    0x3d04
    3c9f:	41                   	inc    cx
    3ca0:	6c                   	ins    BYTE PTR es:[di],dx
    3ca1:	6c                   	ins    BYTE PTR es:[di],dx
    3ca2:	42                   	inc    dx
    3ca3:	75 74                	jne    0x3d19
    3ca5:	74 6f                	je     0x3d16
    3ca7:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ca8:	90                   	nop
    3ca9:	01 0c                	add    WORD PTR [si],cx
    3cab:	00 08                	add    BYTE PTR [bx+si],cl
    3cad:	4f                   	dec    di
    3cae:	4b                   	dec    bx
    3caf:	42                   	inc    dx
    3cb0:	75 74                	jne    0x3d26
    3cb2:	74 6f                	je     0x3d23
    3cb4:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cb5:	94                   	xchg   sp,ax
    3cb6:	01 0c                	add    WORD PTR [si],cx
    3cb8:	00 0c                	add    BYTE PTR [si],cl
    3cba:	43                   	inc    bx
    3cbb:	61                   	popa
    3cbc:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cbd:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
    3cc0:	42                   	inc    dx
    3cc1:	75 74                	jne    0x3d37
    3cc3:	74 6f                	je     0x3d34
    3cc5:	6e                   	outs   dx,BYTE PTR ds:[si]
    3cc6:	04 00                	add    al,0x0
    3cc8:	0c 01                	or     al,0x1
    3cca:	ce                   	into
    3ccb:	3c 90                	cmp    al,0x90
    3ccd:	0b d2                	or     dx,dx
    3ccf:	3c 68                	cmp    al,0x68
    3cd1:	21 16 3e ac          	and    WORD PTR ds:0xac3e,dx
    3cd5:	04 ff                	add    al,0xff
    3cd7:	ff 07                	inc    WORD PTR [bx]
    3cd9:	0f 54 50 61          	andps  xmm2,XMMWORD PTR [bx+si+0x61]
    3cdd:	73 73                	jae    0x3d52
    3cdf:	77 6f                	ja     0x3d50
    3ce1:	72 64                	jb     0x3d47
    3ce3:	44                   	inc    sp
    3ce4:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
    3ce9:	69 3b 01 3d          	imul   di,WORD PTR [bp+di],0x3d01
    3ced:	7b 06                	jnp    0x3cf5
    3cef:	1d 3d 38             	sbb    ax,0x383d
    3cf2:	00 07                	add    BYTE PTR [bx],al
    3cf4:	44                   	inc    sp
    3cf5:	42                   	inc    dx
    3cf6:	50                   	push   ax
    3cf7:	57                   	push   di
    3cf8:	44                   	inc    sp
    3cf9:	6c                   	ins    BYTE PTR es:[di],dx
    3cfa:	67 00 00             	add    BYTE PTR [eax],al
    3cfd:	00 00                	add    BYTE PTR [bx+si],al
    3cff:	55                   	push   bp
    3d00:	3d 16 3d             	cmp    ax,0x3d16
    3d03:	c8 06 00 00          	enter  0x6,0x0
    3d07:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    3d0b:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    3d0f:	b0 01                	mov    al,0x1
    3d11:	50                   	push   ax
    3d12:	b8 69 3b             	mov    ax,0x3b69
    3d15:	ba ff ff             	mov    dx,0xffff
    3d18:	52                   	push   dx
    3d19:	50                   	push   ax
    3d1a:	9a 53 25 3c 3d       	call   0x3d3c:0x2553
    3d1f:	89 c7                	mov    di,ax
    3d21:	8e c2                	mov    es,dx
    3d23:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3d26:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3d29:	b8 fd 3c             	mov    ax,0x3cfd
    3d2c:	0e                   	push   cs
    3d2d:	50                   	push   ax
    3d2e:	55                   	push   bp
    3d2f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3d33:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3d37:	06                   	push   es
    3d38:	57                   	push   di
    3d39:	9a 45 5d ff ff       	call   0xffff:0x5d45
    3d3e:	3d 01 00             	cmp    ax,0x1
    3d41:	b0 00                	mov    al,0x0
    3d43:	75 01                	jne    0x3d46
    3d45:	40                   	inc    ax
    3d46:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3d49:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3d4d:	83 c4 06             	add    sp,0x6
    3d50:	b8 60 3d             	mov    ax,0x3d60
    3d53:	0e                   	push   cs
    3d54:	50                   	push   ax
    3d55:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3d58:	06                   	push   es
    3d59:	57                   	push   di
    3d5a:	9a 7f 1f ff ff       	call   0xffff:0x1f7f
    3d5f:	cb                   	retf
    3d60:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3d63:	c9                   	leave
    3d64:	cb                   	retf
    3d65:	c8 02 01 00          	enter  0x102,0x0
    3d69:	8d be fe fe          	lea    di,[bp-0x102]
    3d6d:	16                   	push   ss
    3d6e:	57                   	push   di
    3d6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d72:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3d77:	06                   	push   es
    3d78:	57                   	push   di
    3d79:	9a 53 1d 9f 3d       	call   0x3d9f:0x1d53
    3d7e:	83 c4 04             	add    sp,0x4
    3d81:	80 be fe fe 00       	cmp    BYTE PTR [bp-0x102],0x0
    3d86:	b0 00                	mov    al,0x0
    3d88:	74 01                	je     0x3d8b
    3d8a:	40                   	inc    ax
    3d8b:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3d8e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3d91:	50                   	push   ax
    3d92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d95:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3d9a:	06                   	push   es
    3d9b:	57                   	push   di
    3d9c:	9a b8 1c b2 3d       	call   0x3db2:0x1cb8
    3da1:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3da4:	50                   	push   ax
    3da5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3da8:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3dad:	06                   	push   es
    3dae:	57                   	push   di
    3daf:	9a b8 1c d9 3d       	call   0x3dd9:0x1cb8
    3db4:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3db8:	75 0f                	jne    0x3dc9
    3dba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dbd:	26 80 bd 98 01 00    	cmp    BYTE PTR es:[di+0x198],0x0
    3dc3:	75 04                	jne    0x3dc9
    3dc5:	b0 00                	mov    al,0x0
    3dc7:	eb 02                	jmp    0x3dcb
    3dc9:	b0 01                	mov    al,0x1
    3dcb:	50                   	push   ax
    3dcc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dcf:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3dd4:	06                   	push   es
    3dd5:	57                   	push   di
    3dd6:	9a b8 1c f6 3d       	call   0x3df6:0x1cb8
    3ddb:	c9                   	leave
    3ddc:	ca 08 00             	retf   0x8
    3ddf:	c8 00 01 00          	enter  0x100,0x0
    3de3:	8d be 00 ff          	lea    di,[bp-0x100]
    3de7:	16                   	push   ss
    3de8:	57                   	push   di
    3de9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dec:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3df1:	06                   	push   es
    3df2:	57                   	push   di
    3df3:	9a 53 1d 44 3e       	call   0x3e44:0x1d53
    3df8:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    3dfc:	06                   	push   es
    3dfd:	57                   	push   di
    3dfe:	9a 97 17 4f 3e       	call   0x3e4f:0x1797
    3e03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e06:	26 c6 85 98 01 01    	mov    BYTE PTR es:[di+0x198],0x1
    3e0c:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3e11:	06                   	push   es
    3e12:	57                   	push   di
    3e13:	9a e3 49 5e 3e       	call   0x3e5e:0x49e3
    3e18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e1b:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3e20:	06                   	push   es
    3e21:	57                   	push   di
    3e22:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e25:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    3e29:	c9                   	leave
    3e2a:	ca 08 00             	retf   0x8
    3e2d:	c8 00 01 00          	enter  0x100,0x0
    3e31:	8d be 00 ff          	lea    di,[bp-0x100]
    3e35:	16                   	push   ss
    3e36:	57                   	push   di
    3e37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e3a:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3e3f:	06                   	push   es
    3e40:	57                   	push   di
    3e41:	9a 53 1d af 3e       	call   0x3eaf:0x1d53
    3e46:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    3e4a:	06                   	push   es
    3e4b:	57                   	push   di
    3e4c:	9a 66 1c 81 3e       	call   0x3e81:0x1c66
    3e51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e54:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3e59:	06                   	push   es
    3e5a:	57                   	push   di
    3e5b:	9a e3 49 ff ff       	call   0xffff:0x49e3
    3e60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e63:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3e68:	06                   	push   es
    3e69:	57                   	push   di
    3e6a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e6d:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    3e71:	c9                   	leave
    3e72:	ca 08 00             	retf   0x8
    3e75:	55                   	push   bp
    3e76:	89 e5                	mov    bp,sp
    3e78:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    3e7c:	06                   	push   es
    3e7d:	57                   	push   di
    3e7e:	9a 56 1c ba 3e       	call   0x3eba:0x1c56
    3e83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e86:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3e8b:	06                   	push   es
    3e8c:	57                   	push   di
    3e8d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e90:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    3e94:	c9                   	leave
    3e95:	ca 08 00             	retf   0x8
    3e98:	c8 00 01 00          	enter  0x100,0x0
    3e9c:	8d be 00 ff          	lea    di,[bp-0x100]
    3ea0:	16                   	push   ss
    3ea1:	57                   	push   di
    3ea2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ea5:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    3eaa:	06                   	push   es
    3eab:	57                   	push   di
    3eac:	9a 53 1d ff ff       	call   0xffff:0x1d53
    3eb1:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    3eb5:	06                   	push   es
    3eb6:	57                   	push   di
    3eb7:	9a 97 17 ff ff       	call   0xffff:0x1797
    3ebc:	c9                   	leave
    3ebd:	ca                   	.byte 0xca
    3ebe:	08                   	.byte 0x8
