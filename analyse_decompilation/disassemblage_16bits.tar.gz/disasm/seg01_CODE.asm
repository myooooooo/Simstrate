; ================================================================
; seg01_CODE  (16247 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	01 00                	add    WORD PTR [bx+si],ax
       2:	0e                   	push   cs
       3:	53                   	push   bx
       4:	69 6d 73 74 72       	imul   bp,WORD PTR [di+0x73],0x7274
       9:	61                   	popa
       a:	74 65                	je     0x71
       c:	20 31                	and    BYTE PTR [bx+di],dh
       e:	2e 32 31             	xor    dh,BYTE PTR cs:[bx+di]
      11:	9a ff ff 00 00       	call   0x0:0xffff
      16:	9a 02 00 1e 00       	call   0x1e:0x2
      1b:	9a 50 0f 64 00       	call   0x64:0xf50
      20:	9a 40 2e 5b 0a       	call   0xa5b:0x2e40
      25:	9a 63 53 eb 00       	call   0xeb:0x5363
      2a:	9a 2f 2e 01 3e       	call   0x3e01:0x2e2f
      2f:	9a e3 6e 2f 01       	call   0x12f:0x6ee3
      34:	9a 7d 22 fa 09       	call   0x9fa:0x227d
      39:	9a a1 2f 41 3c       	call   0x3c41:0x2fa1
      3e:	9a 2c 3a 02 0a       	call   0xa02:0x3a2c
      43:	9a 7a 3d 93 3a       	call   0x3a93:0x3d7a
      48:	9a b7 9b ff ff       	call   0xffff:0x9bb7
      4d:	9a 7c 7b 06 0a       	call   0xa06:0x7b7c
      52:	9a b0 34 16 0d       	call   0xd16:0x34b0
      57:	9a f2 32 ff ff       	call   0xffff:0x32f2
      5c:	55                   	push   bp
      5d:	89 e5                	mov    bp,sp
      5f:	31 c0                	xor    ax,ax
      61:	9a 44 04 b7 00       	call   0xb7:0x444
      66:	bf 02 00             	mov    di,0x2
      69:	0e                   	push   cs
      6a:	57                   	push   di
      6b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
      6f:	06                   	push   es
      70:	57                   	push   di
      71:	9a 92 70 8c 00       	call   0x8c:0x7092
      76:	bf d9 00             	mov    di,0xd9
      79:	b8 66 01             	mov    ax,0x166
      7c:	50                   	push   ax
      7d:	57                   	push   di
      7e:	bf f6 18             	mov    di,0x18f6
      81:	1e                   	push   ds
      82:	57                   	push   di
      83:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
      87:	06                   	push   es
      88:	57                   	push   di
      89:	9a 66 74 a4 00       	call   0xa4:0x7466
      8e:	bf 44 3a             	mov    di,0x3a44
      91:	b8 da 0c             	mov    ax,0xcda
      94:	50                   	push   ax
      95:	57                   	push   di
      96:	bf 08 20             	mov    di,0x2008
      99:	1e                   	push   ds
      9a:	57                   	push   di
      9b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
      9f:	06                   	push   es
      a0:	57                   	push   di
      a1:	9a 66 74 af 00       	call   0xaf:0x7466
      a6:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
      aa:	06                   	push   es
      ab:	57                   	push   di
      ac:	9a 01 75 47 01       	call   0x147:0x7501
      b1:	c9                   	leave
      b2:	31 c0                	xor    ax,ax
      b4:	9a 93 00 d3 00       	call   0xd3:0x93
      b9:	28 0a                	sub    BYTE PTR [bp+si],cl
      bb:	0e                   	push   cs
      bc:	05 62 01             	add    ax,0x162
      bf:	00 00                	add    BYTE PTR [bx+si],al
      c1:	55                   	push   bp
      c2:	01 e4                	add    sp,sp
      c4:	04 fb                	add    al,0xfb
      c6:	04 3c                	add    al,0x3c
      c8:	0a 39                	or     bh,BYTE PTR [bx+di]
      ca:	3f                   	aas
      cb:	df 00                	fild   WORD PTR [bx+si]
      cd:	9a 1f 72 0a cb       	call   0xcb0a:0x721f
      d2:	1f                   	pop    ds
      d3:	cf                   	iret
      d4:	00 ad 27 53          	add    BYTE PTR [di+0x5327],ch
      d8:	01 cd                	add    bp,cx
      da:	11 e3                	adc    bx,sp
      dc:	00 f7                	add    bh,dh
      de:	2a 3f                	sub    bh,BYTE PTR [bx]
      e0:	01 fa                	add    dx,di
      e2:	10 9c 0c d6          	adc    BYTE PTR [si-0x29f4],bl
      e6:	14 17                	adc    al,0x17
      e8:	01 f4                	add    sp,si
      ea:	4f                   	dec    di
      eb:	03 01                	add    ax,WORD PTR [bx+di]
      ed:	9a 28 4b 01 85       	call   0x8501:0x4b28
      f2:	29 f7                	sub    di,si
      f4:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      f7:	fb                   	sti
      f8:	00 91 2f 1b          	add    BYTE PTR [bx+di+0x1b2f],dl
      fc:	01 63 31             	add    WORD PTR [bp+di+0x31],sp
      ff:	1f                   	pop    ds
     100:	01 21                	add    WORD PTR [bx+di],sp
     102:	50                   	push   ax
     103:	db 00                	fild   DWORD PTR [bx+si]
     105:	53                   	push   bx
     106:	25 d7 00             	and    ax,0xd7
     109:	d9 62 13             	fldenv [bp+si+0x13]
     10c:	01 55 2e             	add    WORD PTR [di+0x2e],dx
     10f:	ef                   	out    dx,ax
     110:	00 8f 60 4f          	add    BYTE PTR [bx+0x4f60],cl
     114:	01 3a                	add    WORD PTR [bp+si],di
     116:	1c 6f                	sbb    al,0x6f
     118:	0b e2                	or     sp,dx
     11a:	2f                   	das
     11b:	07                   	pop    es
     11c:	01 08                	add    WORD PTR [bx+si],cx
     11e:	61                   	popa
     11f:	23 01                	and    ax,WORD PTR [bx+di]
     121:	5c                   	pop    sp
     122:	61                   	popa
     123:	27                   	daa
     124:	01 62 5c             	add    WORD PTR [bp+si+0x5c],sp
     127:	2b 01                	sub    ax,WORD PTR [bx+di]
     129:	3a 61 e7             	cmp    ah,BYTE PTR [bx+di-0x19]
     12c:	00 72 3f             	add    BYTE PTR [bp+si+0x3f],dh
     12f:	43                   	inc    bx
     130:	01 58 3a             	add    WORD PTR [bx+si+0x3a],bx
     133:	37                   	aaa
     134:	01 ec                	add    sp,bp
     136:	3d 3b 01             	cmp    ax,0x13b
     139:	e4 3c                	in     al,0x3c
     13b:	cb                   	retf
     13c:	00 ed                	add    ch,ch
     13e:	3e 0f 01 77 3e       	lmsw   WORD PTR ds:[bx+0x3e]
     143:	0b 01                	or     ax,WORD PTR [bx+di]
     145:	e6 31                	out    0x31,al
     147:	33 01                	xor    ax,WORD PTR [bx+di]
     149:	3c 47                	cmp    al,0x47
     14b:	f3 00 ae 5f ff       	repz add BYTE PTR [bp-0xa1],ch
     150:	00 e9                	add    cl,ch
     152:	5c                   	pop    sp
     153:	c7 00 0c 54          	mov    WORD PTR [bx+si],0x540c
     157:	54                   	push   sp
     158:	68 65 4d             	push   0x4d65
     15b:	61                   	popa
     15c:	69 6e 46 6f 72       	imul   bp,WORD PTR [bp+0x46],0x726f
     161:	6d                   	ins    WORD PTR es:[di],dx
     162:	30 00                	xor    BYTE PTR [bx+si],al
     164:	0a 14                	or     dl,BYTE PTR [si]
     166:	78 01                	js     0x169
     168:	0d 51 75             	or     ax,0x7551
     16b:	69 74 74 65 72       	imul   si,WORD PTR [si+0x74],0x7265
     170:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     173:	69 63 6b 48 19       	imul   sp,WORD PTR [bp+di+0x6b],0x1948
     178:	8a 01                	mov    al,BYTE PTR [bx+di]
     17a:	0d 4e 6f             	or     ax,0x6f4e
     17d:	75 76                	jne    0x1f5
     17f:	65 61                	gs popa
     181:	75 31                	jne    0x1b4
     183:	43                   	inc    bx
     184:	6c                   	ins    BYTE PTR es:[di],dx
     185:	69 63 6b 57 33       	imul   sp,WORD PTR [bp+di+0x6b],0x3357
     18a:	a2 01 13             	mov    ds:0x1301,al
     18d:	55                   	push   bp
     18e:	74 69                	je     0x1f9
     190:	6c                   	ins    BYTE PTR es:[di],dx
     191:	69 73 65 72 6c       	imul   si,WORD PTR [bp+di+0x65],0x6c72
     196:	61                   	popa
     197:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     19c:	6c                   	ins    BYTE PTR es:[di],dx
     19d:	69 63 6b 76 33       	imul   sp,WORD PTR [bp+di+0x6b],0x3376
     1a2:	b4 01                	mov    ah,0x1
     1a4:	0d 41 70             	or     ax,0x7041
     1a7:	72 6f                	jb     0x218
     1a9:	70 6f                	jo     0x21a
     1ab:	73 31                	jae    0x1de
     1ad:	43                   	inc    bx
     1ae:	6c                   	ins    BYTE PTR es:[di],dx
     1af:	69 63 6b 2c 0b       	imul   sp,WORD PTR [bp+di+0x6b],0xb2c
     1b4:	c3                   	ret
     1b5:	01 0a                	add    WORD PTR [bp+si],cx
     1b7:	46                   	inc    si
     1b8:	6f                   	outs   dx,WORD PTR ds:[si]
     1b9:	72 6d                	jb     0x228
     1bb:	43                   	inc    bx
     1bc:	72 65                	jb     0x223
     1be:	61                   	popa
     1bf:	74 65                	je     0x226
     1c1:	17                   	pop    ss
     1c2:	33 d3                	xor    dx,bx
     1c4:	01 0b                	add    WORD PTR [bp+di],cx
     1c6:	49                   	dec    cx
     1c7:	6e                   	outs   dx,BYTE PTR ds:[si]
     1c8:	64 65 78 31          	fs gs js 0x1fd
     1cc:	43                   	inc    bx
     1cd:	6c                   	ins    BYTE PTR es:[di],dx
     1ce:	69 63 6b 36 33       	imul   sp,WORD PTR [bp+di+0x6b],0x3336
     1d3:	e8 01 10             	call   0x11d7
     1d6:	52                   	push   dx
     1d7:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     1db:	72 63                	jb     0x240
     1dd:	68 65 72             	push   0x7265
     1e0:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     1e3:	69 63 6b 89 22       	imul   sp,WORD PTR [bp+di+0x6b],0x2289
     1e8:	f9                   	stc
     1e9:	01 0c                	add    WORD PTR [si],cx
     1eb:	4f                   	dec    di
     1ec:	75 76                	jne    0x264
     1ee:	72 69                	jb     0x259
     1f0:	72 31                	jb     0x223
     1f2:	43                   	inc    bx
     1f3:	6c                   	ins    BYTE PTR es:[di],dx
     1f4:	69 63 6b 59 29       	imul   sp,WORD PTR [bp+di+0x6b],0x2959
     1f9:	0f 02 11             	lar    dx,WORD PTR [bx+di]
     1fc:	49                   	dec    cx
     1fd:	6d                   	ins    WORD PTR es:[di],dx
     1fe:	70 72                	jo     0x272
     200:	65 73 73             	gs jae 0x276
     203:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     208:	43                   	inc    bx
     209:	6c                   	ins    BYTE PTR es:[di],dx
     20a:	69 63 6b ce 29       	imul   sp,WORD PTR [bp+di+0x6b],0x29ce
     20f:	24 02                	and    al,0x2
     211:	10 44 65             	adc    BYTE PTR [si+0x65],al
     214:	63 69 73             	arpl   WORD PTR [bx+di+0x73],bp
     217:	69 6f 6e 73 45       	imul   bp,WORD PTR [bx+0x6e],0x4573
     21c:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     21f:	69 63 6b fe 2f       	imul   sp,WORD PTR [bp+di+0x6b],0x2ffe
     224:	39 02                	cmp    WORD PTR [bp+si],ax
     226:	10 41 72             	adc    BYTE PTR [bx+di+0x72],al
     229:	62 69 74             	bound  bp,DWORD PTR [bx+di+0x74]
     22c:	72 61                	jb     0x28f
     22e:	67 65 41             	addr32 gs inc cx
     231:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     234:	69 63 6b 62 30       	imul   sp,WORD PTR [bp+di+0x6b],0x3062
     239:	4d                   	dec    bp
     23a:	02 0f                	add    cl,BYTE PTR [bx]
     23c:	43                   	inc    bx
     23d:	72 65                	jb     0x2a4
     23f:	61                   	popa
     240:	74 69                	je     0x2ab
     242:	6f                   	outs   dx,WORD PTR ds:[si]
     243:	6e                   	outs   dx,BYTE PTR ds:[si]
     244:	41                   	inc    cx
     245:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     248:	69 63 6b 70 2c       	imul   sp,WORD PTR [bp+di+0x6b],0x2c70
     24d:	61                   	popa
     24e:	02 0f                	add    cl,BYTE PTR [bx]
     250:	53                   	push   bx
     251:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     256:	69 6f 6e 31 43       	imul   bp,WORD PTR [bx+0x6e],0x4331
     25b:	6c                   	ins    BYTE PTR es:[di],dx
     25c:	69 63 6b 9d 2c       	imul   sp,WORD PTR [bp+di+0x6b],0x2c9d
     261:	7d 02                	jge    0x265
     263:	17                   	pop    ss
     264:	43                   	inc    bx
     265:	6f                   	outs   dx,WORD PTR ds:[si]
     266:	6d                   	ins    WORD PTR es:[di],dx
     267:	70 74                	jo     0x2dd
     269:	65 64 65 52          	gs fs gs push dx
     26d:	65 73 75             	gs jae 0x2e5
     270:	6c                   	ins    BYTE PTR es:[di],dx
     271:	74 61                	je     0x2d4
     273:	74 73                	je     0x2e8
     275:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     278:	69 63 6b ca 2c       	imul   sp,WORD PTR [bp+di+0x6b],0x2cca
     27d:	8d 02                	lea    ax,[bp+si]
     27f:	0b 42 69             	or     ax,WORD PTR [bp+si+0x69]
     282:	6c                   	ins    BYTE PTR es:[di],dx
     283:	61                   	popa
     284:	6e                   	outs   dx,BYTE PTR ds:[si]
     285:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     288:	69 63 6b f7 2c       	imul   sp,WORD PTR [bp+di+0x6b],0x2cf7
     28d:	ac                   	lods   al,BYTE PTR ds:[si]
     28e:	02 1a                	add    bl,BYTE PTR [bp+si]
     290:	54                   	push   sp
     291:	61                   	popa
     292:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     295:	61                   	popa
     296:	75 64                	jne    0x2fc
     298:	65 46                	gs inc si
     29a:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     29f:	65 6d                	gs ins WORD PTR es:[di],dx
     2a1:	65 6e                	outs   dx,BYTE PTR gs:[si]
     2a3:	74 31                	je     0x2d6
     2a5:	43                   	inc    bx
     2a6:	6c                   	ins    BYTE PTR es:[di],dx
     2a7:	69 63 6b 34 2d       	imul   sp,WORD PTR [bp+di+0x6b],0x2d34
     2ac:	ca 02 19             	retf   0x1902
     2af:	54                   	push   sp
     2b0:	61                   	popa
     2b1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2b4:	61                   	popa
     2b5:	75 64                	jne    0x31b
     2b7:	65 54                	gs push sp
     2b9:	72 65                	jb     0x320
     2bb:	73 6f                	jae    0x32c
     2bd:	72 65                	jb     0x324
     2bf:	72 69                	jb     0x32a
     2c1:	65 31 43 6c          	xor    WORD PTR gs:[bp+di+0x6c],ax
     2c5:	69 63 6b c4 30       	imul   sp,WORD PTR [bp+di+0x6b],0x30c4
     2ca:	dd 02                	fld    QWORD PTR [bp+si]
     2cc:	0e                   	push   cs
     2cd:	52                   	push   dx
     2ce:	65 70 72             	gs jo  0x343
     2d1:	69 73 65 41 31       	imul   si,WORD PTR [bp+di+0x65],0x3141
     2d6:	43                   	inc    bx
     2d7:	6c                   	ins    BYTE PTR es:[di],dx
     2d8:	69 63 6b 14 2b       	imul   sp,WORD PTR [bp+di+0x6b],0x2b14
     2dd:	f0 02 0e 52 61       	lock add cl,BYTE PTR ds:0x6152
     2e2:	70 70                	jo     0x354
     2e4:	65 6c                	gs ins BYTE PTR es:[di],dx
     2e6:	73 45                	jae    0x32d
     2e8:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     2eb:	69 63 6b f6 32       	imul   sp,WORD PTR [bp+di+0x6b],0x32f6
     2f0:	05 03 10             	add    ax,0x1003
     2f3:	56                   	push   si
     2f4:	6f                   	outs   dx,WORD PTR ds:[si]
     2f5:	69 72 54 54 41       	imul   si,WORD PTR [bp+si+0x54],0x4154
     2fa:	42                   	inc    dx
     2fb:	4c                   	dec    sp
     2fc:	45                   	inc    bp
     2fd:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     300:	69 63 6b cf 2f       	imul   sp,WORD PTR [bp+di+0x6b],0x2fcf
     305:	1a 03                	sbb    al,BYTE PTR [bp+di]
     307:	10 44 65             	adc    BYTE PTR [si+0x65],al
     30a:	63 69 73             	arpl   WORD PTR [bx+di+0x73],bp
     30d:	69 6f 6e 73 41       	imul   bp,WORD PTR [bx+0x6e],0x4173
     312:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     315:	69 63 6b 9e 2d       	imul   sp,WORD PTR [bp+di+0x6b],0x2d9e
     31a:	33 03                	xor    ax,WORD PTR [bp+di]
     31c:	14 45                	adc    al,0x45
     31e:	74 75                	je     0x395
     320:	64 65 73 64          	fs gs jae 0x388
     324:	65 4d                	gs dec bp
     326:	61                   	popa
     327:	72 63                	jb     0x38c
     329:	68 65 31             	push   0x3165
     32c:	43                   	inc    bx
     32d:	6c                   	ins    BYTE PTR es:[di],dx
     32e:	69 63 6b 1b 31       	imul   sp,WORD PTR [bp+di+0x6b],0x311b
     333:	49                   	dec    cx
     334:	03 11                	add    dx,WORD PTR [bx+di]
     336:	50                   	push   ax
     337:	61                   	popa
     338:	72 50                	jb     0x38a
     33a:	72 6f                	jb     0x3ab
     33c:	64 75 69             	fs jne 0x3a8
     33f:	74 73                	je     0x3b4
     341:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     344:	69 63 6b 46 31       	imul   sp,WORD PTR [bp+di+0x6b],0x3146
     349:	5c                   	pop    sp
     34a:	03 0e 47 65          	add    cx,WORD PTR ds:0x6547
     34e:	6e                   	outs   dx,BYTE PTR ds:[si]
     34f:	65 72 61             	gs jb  0x3b3
     352:	75 78                	jne    0x3cc
     354:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     357:	69 63 6b 18 39       	imul   sp,WORD PTR [bp+di+0x6b],0x3918
     35c:	6e                   	outs   dx,BYTE PTR ds:[si]
     35d:	03 0d                	add    cx,WORD PTR [di]
     35f:	4d                   	dec    bp
     360:	65 6d                	gs ins WORD PTR es:[di],dx
     362:	6f                   	outs   dx,WORD PTR ds:[si]
     363:	69 72 65 31 43       	imul   si,WORD PTR [bp+si+0x65],0x4331
     368:	6c                   	ins    BYTE PTR es:[di],dx
     369:	69 63 6b 73 39       	imul   sp,WORD PTR [bp+di+0x6b],0x3973
     36e:	7e 03                	jle    0x373
     370:	0b 45 73             	or     ax,WORD PTR [di+0x73]
     373:	73 61                	jae    0x3d6
     375:	69 31 43 6c          	imul   si,WORD PTR [bx+di],0x6c43
     379:	69 63 6b 74 0d       	imul   sp,WORD PTR [bp+di+0x6b],0xd74
     37e:	91                   	xchg   cx,ax
     37f:	03 0e 46 6f          	add    cx,WORD PTR ds:0x6f46
     383:	72 6d                	jb     0x3f2
     385:	43                   	inc    bx
     386:	6c                   	ins    BYTE PTR es:[di],dx
     387:	6f                   	outs   dx,WORD PTR ds:[si]
     388:	73 65                	jae    0x3ef
     38a:	51                   	push   cx
     38b:	75 65                	jne    0x3f2
     38d:	72 79                	jb     0x408
     38f:	2b 0d                	sub    cx,WORD PTR [di]
     391:	9f                   	lahf
     392:	03 09                	add    cx,WORD PTR [bx+di]
     394:	46                   	inc    si
     395:	6f                   	outs   dx,WORD PTR ds:[si]
     396:	72 6d                	jb     0x405
     398:	43                   	inc    bx
     399:	6c                   	ins    BYTE PTR es:[di],dx
     39a:	6f                   	outs   dx,WORD PTR ds:[si]
     39b:	73 65                	jae    0x402
     39d:	d0 32                	shl    BYTE PTR [bp+si],1
     39f:	b2 03                	mov    dl,0x3
     3a1:	0e                   	push   cs
     3a2:	49                   	dec    cx
     3a3:	6e                   	outs   dx,BYTE PTR ds:[si]
     3a4:	66 6f                	outs   dx,DWORD PTR ds:[si]
     3a6:	73 4a                	jae    0x3f2
     3a8:	45                   	inc    bp
     3a9:	55                   	push   bp
     3aa:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     3ad:	69 63 6b e3 32       	imul   sp,WORD PTR [bp+di+0x6b],0x32e3
     3b2:	c4 03                	les    ax,DWORD PTR [bp+di]
     3b4:	0d 47 72             	or     ax,0x7247
     3b7:	61                   	popa
     3b8:	70 68                	jo     0x422
     3ba:	65 73 31             	gs jae 0x3ee
     3bd:	43                   	inc    bx
     3be:	6c                   	ins    BYTE PTR es:[di],dx
     3bf:	69 63 6b 6f 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3a6f
     3c4:	d7                   	xlat   BYTE PTR ds:[bx]
     3c5:	03 0e 43 72          	add    cx,WORD PTR ds:0x7243
     3c9:	65 61                	gs popa
     3cb:	74 69                	je     0x436
     3cd:	6f                   	outs   dx,WORD PTR ds:[si]
     3ce:	6e                   	outs   dx,BYTE PTR ds:[si]
     3cf:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     3d2:	69 63 6b f7 39       	imul   sp,WORD PTR [bp+di+0x6b],0x39f7
     3d7:	e6 03                	out    0x3,al
     3d9:	0a 6e 69             	or     ch,BYTE PTR [bp+0x69]
     3dc:	76 31                	jbe    0x40f
     3de:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     3e1:	69 63 6b 15 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3a15
     3e6:	f5                   	cmc
     3e7:	03 0a                	add    cx,WORD PTR [bp+si]
     3e9:	6e                   	outs   dx,BYTE PTR ds:[si]
     3ea:	69 76 32 31 43       	imul   si,WORD PTR [bp+0x32],0x4331
     3ef:	6c                   	ins    BYTE PTR es:[di],dx
     3f0:	69 63 6b 33 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3a33
     3f5:	04 04                	add    al,0x4
     3f7:	0a 6e 69             	or     ch,BYTE PTR [bp+0x69]
     3fa:	76 33                	jbe    0x42f
     3fc:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     3ff:	69 63 6b 51 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3a51
     404:	13 04                	adc    ax,WORD PTR [si]
     406:	0a 6e 69             	or     ch,BYTE PTR [bp+0x69]
     409:	76 34                	jbe    0x43f
     40b:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     40e:	69 63 6b 82 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3a82
     413:	27                   	daa
     414:	04 0f                	add    al,0xf
     416:	61                   	popa
     417:	6e                   	outs   dx,BYTE PTR ds:[si]
     418:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
     41d:	75 72                	jne    0x491
     41f:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     422:	69 63 6b 99 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3a99
     427:	3d 04 11             	cmp    ax,0x1104
     42a:	65 6e                	outs   dx,BYTE PTR gs:[si]
     42c:	74 72                	je     0x4a0
     42e:	65 70 72             	gs jo  0x4a3
     431:	69 73 65 73 32       	imul   si,WORD PTR [bp+di+0x65],0x3273
     436:	43                   	inc    bx
     437:	6c                   	ins    BYTE PTR es:[di],dx
     438:	69 63 6b bb 31       	imul   sp,WORD PTR [bp+di+0x6b],0x31bb
     43d:	4e                   	dec    si
     43e:	04 0c                	add    al,0xc
     440:	50                   	push   ax
     441:	75 62                	jne    0x4a5
     443:	6c                   	ins    BYTE PTR es:[di],dx
     444:	69 63 31 43 6c       	imul   sp,WORD PTR [bp+di+0x31],0x6c43
     449:	69 63 6b 4e 2e       	imul   sp,WORD PTR [bp+di+0x6b],0x2e4e
     44e:	5e                   	pop    si
     44f:	04 0b                	add    al,0xb
     451:	44                   	inc    sp
     452:	41                   	inc    cx
     453:	45                   	inc    bp
     454:	6e                   	outs   dx,BYTE PTR ds:[si]
     455:	74 31                	je     0x488
     457:	43                   	inc    bx
     458:	6c                   	ins    BYTE PTR es:[di],dx
     459:	69 63 6b c1 2d       	imul   sp,WORD PTR [bp+di+0x6b],0x2dc1
     45e:	7a 04                	jp     0x464
     460:	17                   	pop    ss
     461:	44                   	inc    sp
     462:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     466:	69 6f 6e 73 41       	imul   bp,WORD PTR [bx+0x6e],0x4173
     46b:	6e                   	outs   dx,BYTE PTR ds:[si]
     46c:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
     471:	75 72                	jne    0x4e5
     473:	43                   	inc    bx
     474:	6c                   	ins    BYTE PTR es:[di],dx
     475:	69 63 6b af 28       	imul   sp,WORD PTR [bp+di+0x6b],0x28af
     47a:	8b 04                	mov    ax,WORD PTR [si]
     47c:	0c 46                	or     al,0x46
     47e:	65 72 6d             	gs jb  0x4ee
     481:	65 72 31             	gs jb  0x4b5
     484:	43                   	inc    bx
     485:	6c                   	ins    BYTE PTR es:[di],dx
     486:	69 63 6b 93 39       	imul   sp,WORD PTR [bp+di+0x6b],0x3993
     48b:	a0 04 10             	mov    al,ds:0x1004
     48e:	54                   	push   sp
     48f:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     494:	49                   	dec    cx
     495:	6e                   	outs   dx,BYTE PTR ds:[si]
     496:	66 6f                	outs   dx,DWORD PTR ds:[si]
     498:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     49b:	69 63 6b f4 38       	imul   sp,WORD PTR [bp+di+0x6b],0x38f4
     4a0:	b0 04                	mov    al,0x4
     4a2:	0b 54 69             	or     dx,WORD PTR [si+0x69]
     4a5:	6d                   	ins    WORD PTR es:[di],dx
     4a6:	65 72 31             	gs jb  0x4da
     4a9:	54                   	push   sp
     4aa:	69 6d 65 72 2b       	imul   bp,WORD PTR [di+0x65],0x2b72
     4af:	38 c3                	cmp    bl,al
     4b1:	04 0e                	add    al,0xe
     4b3:	50                   	push   ax
     4b4:	61                   	popa
     4b5:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     4ba:	78 31                	js     0x4ed
     4bc:	50                   	push   ax
     4bd:	61                   	popa
     4be:	69 6e 74 e0 0c       	imul   bp,WORD PTR [bp+0x74],0xce0
     4c3:	d0 04                	rol    BYTE PTR [si],1
     4c5:	08 46 6f             	or     BYTE PTR [bp+0x6f],al
     4c8:	72 6d                	jb     0x537
     4ca:	53                   	push   bx
     4cb:	68 6f 77             	push   0x776f
     4ce:	8d 30                	lea    si,[bx+si]
     4d0:	e7 04                	out    0x4,ax
     4d2:	12 45 6e             	adc    al,BYTE PTR [di+0x6e]
     4d5:	74 72                	je     0x549
     4d7:	65 70 72             	gs jo  0x54c
     4da:	69 73 65 73 41       	imul   si,WORD PTR [bp+di+0x65],0x4173
     4df:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     4e2:	69 63 6b b2 3a       	imul   sp,WORD PTR [bp+di+0x6b],0x3ab2
     4e7:	02 05                	add    al,BYTE PTR [di]
     4e9:	16                   	push   ss
     4ea:	49                   	dec    cx
     4eb:	6d                   	ins    WORD PTR es:[di],dx
     4ec:	70 72                	jo     0x560
     4ee:	65 73 73             	gs jae 0x564
     4f1:	69 6f 6e 72 61       	imul   bp,WORD PTR [bx+0x6e],0x6172
     4f6:	70 69                	jo     0x561
     4f8:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     4fd:	69 63 6b 71 2d       	imul   sp,WORD PTR [bp+di+0x6b],0x2d71
     502:	38 0a                	cmp    BYTE PTR [bp+si],cl
     504:	09 53 49             	or     WORD PTR [bp+di+0x49],dx
     507:	47                   	inc    di
     508:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     50b:	69 63 6b 5a 00       	imul   sp,WORD PTR [bp+di+0x6b],0x5a
     510:	f6 09 7c             	test   BYTE PTR [bx+di],0x7c
     513:	01 00                	add    WORD PTR [bx+si],ax
     515:	00 09                	add    BYTE PTR [bx+di],cl
     517:	4d                   	dec    bp
     518:	61                   	popa
     519:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     51e:	75 31                	jne    0x551
     520:	80 01 04             	add    BYTE PTR [bx+di],0x4
     523:	00 05                	add    BYTE PTR [di],al
     525:	41                   	inc    cx
     526:	69 64 65 31 84       	imul   sp,WORD PTR [si+0x65],0x8431
     52b:	01 04                	add    WORD PTR [si],ax
     52d:	00 08                	add    BYTE PTR [bx+si],cl
     52f:	41                   	inc    cx
     530:	70 72                	jo     0x5a4
     532:	6f                   	outs   dx,WORD PTR ds:[si]
     533:	70 6f                	jo     0x5a4
     535:	73 31                	jae    0x568
     537:	88 01                	mov    BYTE PTR [bx+di],al
     539:	04 00                	add    al,0x0
     53b:	0e                   	push   cs
     53c:	55                   	push   bp
     53d:	74 69                	je     0x5a8
     53f:	6c                   	ins    BYTE PTR es:[di],dx
     540:	69 73 65 72 6c       	imul   si,WORD PTR [bp+di+0x65],0x6c72
     545:	61                   	popa
     546:	69 64 65 31 8c       	imul   sp,WORD PTR [si+0x65],0x8c31
     54b:	01 04                	add    WORD PTR [si],ax
     54d:	00 0b                	add    BYTE PTR [bp+di],cl
     54f:	52                   	push   dx
     550:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     554:	72 63                	jb     0x5b9
     556:	68 65 72             	push   0x7265
     559:	31 90 01 04          	xor    WORD PTR [bx+si+0x401],dx
     55d:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     561:	64 65 78 31          	fs gs js 0x596
     565:	94                   	xchg   sp,ax
     566:	01 04                	add    WORD PTR [si],ax
     568:	00 02                	add    BYTE PTR [bp+si],al
     56a:	4e                   	dec    si
     56b:	33 98 01 08          	xor    bx,WORD PTR [bx+si+0x801]
     56f:	00 0e 4f 70          	add    BYTE PTR ds:0x704f,cl
     573:	65 6e                	outs   dx,BYTE PTR gs:[si]
     575:	46                   	inc    si
     576:	69 6c 65 44 69       	imul   bp,WORD PTR [si+0x65],0x6944
     57b:	61                   	popa
     57c:	6c                   	ins    BYTE PTR es:[di],dx
     57d:	6f                   	outs   dx,WORD PTR ds:[si]
     57e:	67 9c                	addr32 pushf
     580:	01 04                	add    WORD PTR [si],ax
     582:	00 08                	add    BYTE PTR [bx+si],cl
     584:	46                   	inc    si
     585:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     58a:	72 31                	jb     0x5bd
     58c:	a0 01 04             	mov    al,ds:0x401
     58f:	00 08                	add    BYTE PTR [bx+si],cl
     591:	51                   	push   cx
     592:	75 69                	jne    0x5fd
     594:	74 74                	je     0x60a
     596:	65 72 31             	gs jb  0x5ca
     599:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     59a:	01 04                	add    WORD PTR [si],ax
     59c:	00 02                	add    BYTE PTR [bp+si],al
     59e:	4e                   	dec    si
     59f:	32 a8 01 04          	xor    ch,BYTE PTR [bx+si+0x401]
     5a3:	00 07                	add    BYTE PTR [bx],al
     5a5:	4f                   	dec    di
     5a6:	75 76                	jne    0x61e
     5a8:	72 69                	jb     0x613
     5aa:	72 31                	jb     0x5dd
     5ac:	ac                   	lods   al,BYTE PTR ds:[si]
     5ad:	01 04                	add    WORD PTR [si],ax
     5af:	00 08                	add    BYTE PTR [bx+si],cl
     5b1:	4e                   	dec    si
     5b2:	6f                   	outs   dx,WORD PTR ds:[si]
     5b3:	75 76                	jne    0x62b
     5b5:	65 61                	gs popa
     5b7:	75 31                	jne    0x5ea
     5b9:	b0 01                	mov    al,0x1
     5bb:	04 00                	add    al,0x0
     5bd:	0c 49                	or     al,0x49
     5bf:	6d                   	ins    WORD PTR es:[di],dx
     5c0:	70 72                	jo     0x634
     5c2:	65 73 73             	gs jae 0x638
     5c5:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     5ca:	b4 01                	mov    ah,0x1
     5cc:	04 00                	add    al,0x0
     5ce:	0b 4d 69             	or     cx,WORD PTR [di+0x69]
     5d1:	73 65                	jae    0x638
     5d3:	41                   	inc    cx
     5d4:	75 50                	jne    0x626
     5d6:	6f                   	outs   dx,WORD PTR ds:[si]
     5d7:	69 6e 74 b8 01       	imul   bp,WORD PTR [bp+0x74],0x1b8
     5dc:	04 00                	add    al,0x0
     5de:	0a 41 6e             	or     al,BYTE PTR [bx+di+0x6e]
     5e1:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
     5e6:	75 72                	jne    0x65a
     5e8:	31 bc 01 04          	xor    WORD PTR [si+0x401],di
     5ec:	00 0a                	add    BYTE PTR [bp+si],cl
     5ee:	44                   	inc    sp
     5ef:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     5f3:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     5f8:	c0 01 04             	rol    BYTE PTR [bx+di],0x4
     5fb:	00 0b                	add    BYTE PTR [bp+di],cl
     5fd:	41                   	inc    cx
     5fe:	72 62                	jb     0x662
     600:	69 74 72 61 67       	imul   si,WORD PTR [si+0x72],0x6761
     605:	65 41                	gs inc cx
     607:	31 c4                	xor    sp,ax
     609:	01 04                	add    WORD PTR [si],ax
     60b:	00 0b                	add    BYTE PTR [bp+di],cl
     60d:	52                   	push   dx
     60e:	65 73 75             	gs jae 0x686
     611:	6c                   	ins    BYTE PTR es:[di],dx
     612:	74 61                	je     0x675
     614:	74 73                	je     0x689
     616:	41                   	inc    cx
     617:	31 c8                	xor    ax,cx
     619:	01 04                	add    WORD PTR [si],ax
     61b:	00 02                	add    BYTE PTR [bp+si],al
     61d:	4e                   	dec    si
     61e:	35 cc 01             	xor    ax,0x1cc
     621:	04 00                	add    al,0x0
     623:	09 52 61             	or     WORD PTR [bp+si+0x61],dx
     626:	70 70                	jo     0x698
     628:	65 6c                	gs ins BYTE PTR es:[di],dx
     62a:	73 41                	jae    0x66d
     62c:	31 d0                	xor    ax,dx
     62e:	01 04                	add    WORD PTR [si],ax
     630:	00 0a                	add    BYTE PTR [bp+si],cl
     632:	43                   	inc    bx
     633:	72 65                	jb     0x69a
     635:	61                   	popa
     636:	74 69                	je     0x6a1
     638:	6f                   	outs   dx,WORD PTR ds:[si]
     639:	6e                   	outs   dx,BYTE PTR ds:[si]
     63a:	41                   	inc    cx
     63b:	32 d4                	xor    dl,ah
     63d:	01 04                	add    WORD PTR [si],ax
     63f:	00 0c                	add    BYTE PTR [si],cl
     641:	45                   	inc    bp
     642:	6e                   	outs   dx,BYTE PTR ds:[si]
     643:	74 72                	je     0x6b7
     645:	65 70 72             	gs jo  0x6ba
     648:	69 73 65 73 31       	imul   si,WORD PTR [bp+di+0x65],0x3173
     64d:	d8 01                	fadd   DWORD PTR [bx+di]
     64f:	04 00                	add    al,0x0
     651:	0b 44 65             	or     ax,WORD PTR [si+0x65]
     654:	63 69 73             	arpl   WORD PTR [bx+di+0x73],bp
     657:	69 6f 6e 73 45       	imul   bp,WORD PTR [bx+0x6e],0x4573
     65c:	31 dc                	xor    sp,bx
     65e:	01 04                	add    WORD PTR [si],ax
     660:	00 0b                	add    BYTE PTR [bp+di],cl
     662:	52                   	push   dx
     663:	65 73 75             	gs jae 0x6db
     666:	6c                   	ins    BYTE PTR es:[di],dx
     667:	74 61                	je     0x6ca
     669:	74 73                	je     0x6de
     66b:	45                   	inc    bp
     66c:	32 e0                	xor    ah,al
     66e:	01 04                	add    WORD PTR [si],ax
     670:	00 0a                	add    BYTE PTR [bp+si],cl
     672:	53                   	push   bx
     673:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     678:	69 6f 6e 31 e4       	imul   bp,WORD PTR [bx+0x6e],0xe431
     67d:	01 04                	add    WORD PTR [si],ax
     67f:	00 12                	add    BYTE PTR [bp+si],dl
     681:	43                   	inc    bx
     682:	6f                   	outs   dx,WORD PTR ds:[si]
     683:	6d                   	ins    WORD PTR es:[di],dx
     684:	70 74                	jo     0x6fa
     686:	65 64 65 52          	gs fs gs push dx
     68a:	65 73 75             	gs jae 0x702
     68d:	6c                   	ins    BYTE PTR es:[di],dx
     68e:	74 61                	je     0x6f1
     690:	74 73                	je     0x705
     692:	31 e8                	xor    ax,bp
     694:	01 04                	add    WORD PTR [si],ax
     696:	00 06 42 69          	add    BYTE PTR ds:0x6942,al
     69a:	6c                   	ins    BYTE PTR es:[di],dx
     69b:	61                   	popa
     69c:	6e                   	outs   dx,BYTE PTR ds:[si]
     69d:	31 ec                	xor    sp,bp
     69f:	01 04                	add    WORD PTR [si],ax
     6a1:	00 15                	add    BYTE PTR [di],dl
     6a3:	54                   	push   sp
     6a4:	61                   	popa
     6a5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6a8:	61                   	popa
     6a9:	75 64                	jne    0x70f
     6ab:	65 46                	gs inc si
     6ad:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     6b2:	65 6d                	gs ins WORD PTR es:[di],dx
     6b4:	65 6e                	outs   dx,BYTE PTR gs:[si]
     6b6:	74 31                	je     0x6e9
     6b8:	f0 01 04             	lock add WORD PTR [si],ax
     6bb:	00 14                	add    BYTE PTR [si],dl
     6bd:	54                   	push   sp
     6be:	61                   	popa
     6bf:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6c2:	61                   	popa
     6c3:	75 64                	jne    0x729
     6c5:	65 54                	gs push sp
     6c7:	72 65                	jb     0x72e
     6c9:	73 6f                	jae    0x73a
     6cb:	72 65                	jb     0x732
     6cd:	72 69                	jb     0x738
     6cf:	65 31 f4             	gs xor sp,si
     6d2:	01 04                	add    WORD PTR [si],ax
     6d4:	00 02                	add    BYTE PTR [bp+si],al
     6d6:	4e                   	dec    si
     6d7:	36 f8                	ss clc
     6d9:	01 04                	add    WORD PTR [si],ax
     6db:	00 0f                	add    BYTE PTR [bx],cl
     6dd:	45                   	inc    bp
     6de:	74 75                	je     0x755
     6e0:	64 65 73 64          	fs gs jae 0x748
     6e4:	65 4d                	gs dec bp
     6e6:	61                   	popa
     6e7:	72 63                	jb     0x74c
     6e9:	68 65 31             	push   0x3165
     6ec:	fc                   	cld
     6ed:	01 04                	add    WORD PTR [si],ax
     6ef:	00 09                	add    BYTE PTR [bx+di],cl
     6f1:	52                   	push   dx
     6f2:	65 70 72             	gs jo  0x767
     6f5:	69 73 65 41 31       	imul   si,WORD PTR [bp+di+0x65],0x3141
     6fa:	00 02                	add    BYTE PTR [bp+si],al
     6fc:	04 00                	add    al,0x0
     6fe:	0b 44 65             	or     ax,WORD PTR [si+0x65]
     701:	63 69 73             	arpl   WORD PTR [bx+di+0x73],bp
     704:	69 6f 6e 73 41       	imul   bp,WORD PTR [bx+0x6e],0x4173
     709:	32 04                	xor    al,BYTE PTR [si]
     70b:	02 04                	add    al,BYTE PTR [si]
     70d:	00 02                	add    BYTE PTR [bp+si],al
     70f:	4e                   	dec    si
     710:	37                   	aaa
     711:	08 02                	or     BYTE PTR [bp+si],al
     713:	04 00                	add    al,0x0
     715:	09 52 61             	or     WORD PTR [bp+si+0x61],dx
     718:	70 70                	jo     0x78a
     71a:	65 6c                	gs ins BYTE PTR es:[di],dx
     71c:	73 45                	jae    0x763
     71e:	31 0c                	xor    WORD PTR [si],cx
     720:	02 04                	add    al,BYTE PTR [si]
     722:	00 0b                	add    BYTE PTR [bp+di],cl
     724:	56                   	push   si
     725:	6f                   	outs   dx,WORD PTR ds:[si]
     726:	69 72 54 54 41       	imul   si,WORD PTR [bp+si+0x54],0x4154
     72b:	42                   	inc    dx
     72c:	4c                   	dec    sp
     72d:	45                   	inc    bp
     72e:	31 10                	xor    WORD PTR [bx+si],dx
     730:	02 04                	add    al,BYTE PTR [si]
     732:	00 08                	add    BYTE PTR [bx+si],cl
     734:	4f                   	dec    di
     735:	70 74                	jo     0x7ab
     737:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     73c:	14 02                	adc    al,0x2
     73e:	0c 00                	or     al,0x0
     740:	09 44 61             	or     WORD PTR [si+0x61],ax
     743:	74 61                	je     0x7a6
     745:	62 61 73             	bound  sp,DWORD PTR [bx+di+0x73]
     748:	65 31 18             	xor    WORD PTR gs:[bx+si],bx
     74b:	02 04                	add    al,BYTE PTR [si]
     74d:	00 0c                	add    BYTE PTR [si],cl
     74f:	50                   	push   ax
     750:	61                   	popa
     751:	72 50                	jb     0x7a3
     753:	72 6f                	jb     0x7c4
     755:	64 75 69             	fs jne 0x7c1
     758:	74 73                	je     0x7cd
     75a:	31 1c                	xor    WORD PTR [si],bx
     75c:	02 04                	add    al,BYTE PTR [si]
     75e:	00 09                	add    BYTE PTR [bx+di],cl
     760:	47                   	inc    di
     761:	65 6e                	outs   dx,BYTE PTR gs:[si]
     763:	65 72 61             	gs jb  0x7c7
     766:	75 78                	jne    0x7e0
     768:	31 20                	xor    WORD PTR [bx+si],sp
     76a:	02 04                	add    al,BYTE PTR [si]
     76c:	00 08                	add    BYTE PTR [bx+si],cl
     76e:	4d                   	dec    bp
     76f:	65 6d                	gs ins WORD PTR es:[di],dx
     771:	6f                   	outs   dx,WORD PTR ds:[si]
     772:	69 72 65 31 24       	imul   si,WORD PTR [bp+si+0x65],0x2431
     777:	02 04                	add    al,BYTE PTR [si]
     779:	00 06 45 73          	add    BYTE PTR ds:0x7345,al
     77d:	73 61                	jae    0x7e0
     77f:	69 31 28 02          	imul   si,WORD PTR [bx+di],0x228
     783:	10 00                	adc    BYTE PTR [bx+si],al
     785:	0d 4d 61             	or     ax,0x614d
     788:	69 6e 54 61 62       	imul   bp,WORD PTR [bp+0x54],0x6261
     78d:	6c                   	ins    BYTE PTR es:[di],dx
     78e:	65 4d                	gs dec bp
     790:	41                   	inc    cx
     791:	49                   	dec    cx
     792:	4e                   	dec    si
     793:	2c 02                	sub    al,0x2
     795:	10 00                	adc    BYTE PTR [bx+si],al
     797:	0c 4d                	or     al,0x4d
     799:	61                   	popa
     79a:	69 6e 54 61 62       	imul   bp,WORD PTR [bp+0x54],0x6261
     79f:	6c                   	ins    BYTE PTR es:[di],dx
     7a0:	65 41                	gs inc cx
     7a2:	43                   	inc    bx
     7a3:	47                   	inc    di
     7a4:	30 02                	xor    BYTE PTR [bp+si],al
     7a6:	04 00                	add    al,0x0
     7a8:	09 49 6e             	or     WORD PTR [bx+di+0x6e],cx
     7ab:	66 6f                	outs   dx,DWORD PTR ds:[si]
     7ad:	73 4a                	jae    0x7f9
     7af:	45                   	inc    bp
     7b0:	55                   	push   bp
     7b1:	31 34                	xor    WORD PTR [si],si
     7b3:	02 10                	add    dl,BYTE PTR [bx+si]
     7b5:	00 0c                	add    BYTE PTR [si],cl
     7b7:	4d                   	dec    bp
     7b8:	61                   	popa
     7b9:	69 6e 54 61 62       	imul   bp,WORD PTR [bp+0x54],0x6261
     7be:	6c                   	ins    BYTE PTR es:[di],dx
     7bf:	65 41                	gs inc cx
     7c1:	44                   	inc    sp
     7c2:	47                   	inc    di
     7c3:	38 02                	cmp    BYTE PTR [bp+si],al
     7c5:	04 00                	add    al,0x0
     7c7:	08 47 72             	or     BYTE PTR [bx+0x72],al
     7ca:	61                   	popa
     7cb:	70 68                	jo     0x835
     7cd:	65 73 31             	gs jae 0x801
     7d0:	3c 02                	cmp    al,0x2
     7d2:	14 00                	adc    al,0x0
     7d4:	06                   	push   es
     7d5:	50                   	push   ax
     7d6:	61                   	popa
     7d7:	6e                   	outs   dx,BYTE PTR ds:[si]
     7d8:	65 6c                	gs ins BYTE PTR es:[di],dx
     7da:	30 40 02             	xor    BYTE PTR [bx+si+0x2],al
     7dd:	14 00                	adc    al,0x0
     7df:	06                   	push   es
     7e0:	50                   	push   ax
     7e1:	61                   	popa
     7e2:	6e                   	outs   dx,BYTE PTR ds:[si]
     7e3:	65 6c                	gs ins BYTE PTR es:[di],dx
     7e5:	32 44 02             	xor    al,BYTE PTR [si+0x2]
     7e8:	18 00                	sbb    BYTE PTR [bx+si],al
     7ea:	06                   	push   es
     7eb:	4c                   	dec    sp
     7ec:	61                   	popa
     7ed:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7f0:	31 48 02             	xor    WORD PTR [bx+si+0x2],cx
     7f3:	18 00                	sbb    BYTE PTR [bx+si],al
     7f5:	07                   	pop    es
     7f6:	4c                   	dec    sp
     7f7:	61                   	popa
     7f8:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7fb:	55                   	push   bp
     7fc:	33 4c 02             	xor    cx,WORD PTR [si+0x2]
     7ff:	18 00                	sbb    BYTE PTR [bx+si],al
     801:	07                   	pop    es
     802:	4c                   	dec    sp
     803:	61                   	popa
     804:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     807:	55                   	push   bp
     808:	30 50 02             	xor    BYTE PTR [bx+si+0x2],dl
     80b:	18 00                	sbb    BYTE PTR [bx+si],al
     80d:	07                   	pop    es
     80e:	4c                   	dec    sp
     80f:	61                   	popa
     810:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     813:	55                   	push   bp
     814:	31 54 02             	xor    WORD PTR [si+0x2],dx
     817:	18 00                	sbb    BYTE PTR [bx+si],al
     819:	07                   	pop    es
     81a:	4c                   	dec    sp
     81b:	61                   	popa
     81c:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     81f:	55                   	push   bp
     820:	32 58 02             	xor    bl,BYTE PTR [bx+si+0x2]
     823:	18 00                	sbb    BYTE PTR [bx+si],al
     825:	06                   	push   es
     826:	4c                   	dec    sp
     827:	61                   	popa
     828:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     82b:	32 5c 02             	xor    bl,BYTE PTR [si+0x2]
     82e:	04 00                	add    al,0x0
     830:	0d 4d 41             	or     ax,0x414d
     833:	50                   	push   ax
     834:	44                   	inc    sp
     835:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     839:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     83e:	60                   	pusha
     83f:	02 04                	add    al,BYTE PTR [si]
     841:	00 09                	add    BYTE PTR [bx+di],cl
     843:	63 72 65             	arpl   WORD PTR [bp+si+0x65],si
     846:	61                   	popa
     847:	74 69                	je     0x8b2
     849:	6f                   	outs   dx,WORD PTR ds:[si]
     84a:	6e                   	outs   dx,BYTE PTR ds:[si]
     84b:	31 64 02             	xor    WORD PTR [si+0x2],sp
     84e:	04 00                	add    al,0x0
     850:	0a 61 6e             	or     ah,BYTE PTR [bx+di+0x6e]
     853:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
     858:	75 72                	jne    0x8cc
     85a:	32 68 02             	xor    ch,BYTE PTR [bx+si+0x2]
     85d:	04 00                	add    al,0x0
     85f:	0c 65                	or     al,0x65
     861:	6e                   	outs   dx,BYTE PTR ds:[si]
     862:	74 72                	je     0x8d6
     864:	65 70 72             	gs jo  0x8d9
     867:	69 73 65 73 32       	imul   si,WORD PTR [bp+di+0x65],0x3273
     86c:	6c                   	ins    BYTE PTR es:[di],dx
     86d:	02 04                	add    al,BYTE PTR [si]
     86f:	00 0e 4d 6f          	add    BYTE PTR ds:0x6f4d,cl
     873:	64 69 66 69 65 6e    	imul   sp,WORD PTR fs:[bp+0x69],0x6e65
     879:	69 76 65 61 75       	imul   si,WORD PTR [bp+0x65],0x7561
     87e:	31 70 02             	xor    WORD PTR [bx+si+0x2],si
     881:	04 00                	add    al,0x0
     883:	05 6e 69             	add    ax,0x696e
     886:	76 31                	jbe    0x8b9
     888:	31 74 02             	xor    WORD PTR [si+0x2],si
     88b:	04 00                	add    al,0x0
     88d:	05 6e 69             	add    ax,0x696e
     890:	76 32                	jbe    0x8c4
     892:	31 78 02             	xor    WORD PTR [bx+si+0x2],di
     895:	04 00                	add    al,0x0
     897:	05 6e 69             	add    ax,0x696e
     89a:	76 33                	jbe    0x8cf
     89c:	31 7c 02             	xor    WORD PTR [si+0x2],di
     89f:	04 00                	add    al,0x0
     8a1:	05 6e 69             	add    ax,0x696e
     8a4:	76 34                	jbe    0x8da
     8a6:	31 80 02 04          	xor    WORD PTR [bx+si+0x402],ax
     8aa:	00 07                	add    BYTE PTR [bx],al
     8ac:	50                   	push   ax
     8ad:	75 62                	jne    0x911
     8af:	6c                   	ins    BYTE PTR es:[di],dx
     8b0:	69 63 31 84 02       	imul   sp,WORD PTR [bp+di+0x31],0x284
     8b5:	04 00                	add    al,0x0
     8b7:	12 44 65             	adc    al,BYTE PTR [si+0x65]
     8ba:	63 69 73             	arpl   WORD PTR [bx+di+0x73],bp
     8bd:	69 6f 6e 73 41       	imul   bp,WORD PTR [bx+0x6e],0x4173
     8c2:	6e                   	outs   dx,BYTE PTR ds:[si]
     8c3:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
     8c8:	75 72                	jne    0x93c
     8ca:	88 02                	mov    BYTE PTR [bp+si],al
     8cc:	04 00                	add    al,0x0
     8ce:	02 4e 39             	add    cl,BYTE PTR [bp+0x39]
     8d1:	8c 02                	mov    WORD PTR [bp+si],es
     8d3:	04 00                	add    al,0x0
     8d5:	06                   	push   es
     8d6:	44                   	inc    sp
     8d7:	41                   	inc    cx
     8d8:	45                   	inc    bp
     8d9:	6e                   	outs   dx,BYTE PTR ds:[si]
     8da:	74 31                	je     0x90d
     8dc:	90                   	nop
     8dd:	02 04                	add    al,BYTE PTR [si]
     8df:	00 06 44 41          	add    BYTE PTR ds:0x4144,al
     8e3:	45                   	inc    bp
     8e4:	6e                   	outs   dx,BYTE PTR ds:[si]
     8e5:	74 32                	je     0x919
     8e7:	94                   	xchg   sp,ax
     8e8:	02 04                	add    al,BYTE PTR [si]
     8ea:	00 06 44 41          	add    BYTE PTR ds:0x4144,al
     8ee:	45                   	inc    bp
     8ef:	6e                   	outs   dx,BYTE PTR ds:[si]
     8f0:	74 33                	je     0x925
     8f2:	98                   	cbw
     8f3:	02 04                	add    al,BYTE PTR [si]
     8f5:	00 06 44 41          	add    BYTE PTR ds:0x4144,al
     8f9:	45                   	inc    bp
     8fa:	6e                   	outs   dx,BYTE PTR ds:[si]
     8fb:	74 34                	je     0x931
     8fd:	9c                   	pushf
     8fe:	02 04                	add    al,BYTE PTR [si]
     900:	00 06 44 41          	add    BYTE PTR ds:0x4144,al
     904:	45                   	inc    bp
     905:	6e                   	outs   dx,BYTE PTR ds:[si]
     906:	74 35                	je     0x93d
     908:	a0 02 04             	mov    al,ds:0x402
     90b:	00 06 44 41          	add    BYTE PTR ds:0x4144,al
     90f:	45                   	inc    bp
     910:	6e                   	outs   dx,BYTE PTR ds:[si]
     911:	74 36                	je     0x949
     913:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     914:	02 04                	add    al,BYTE PTR [si]
     916:	00 06 44 41          	add    BYTE PTR ds:0x4144,al
     91a:	45                   	inc    bp
     91b:	6e                   	outs   dx,BYTE PTR ds:[si]
     91c:	74 37                	je     0x955
     91e:	a8 02                	test   al,0x2
     920:	04 00                	add    al,0x0
     922:	06                   	push   es
     923:	44                   	inc    sp
     924:	41                   	inc    cx
     925:	45                   	inc    bp
     926:	6e                   	outs   dx,BYTE PTR ds:[si]
     927:	74 38                	je     0x961
     929:	ac                   	lods   al,BYTE PTR ds:[si]
     92a:	02 10                	add    dl,BYTE PTR [bx+si]
     92c:	00 0c                	add    BYTE PTR [si],cl
     92e:	4d                   	dec    bp
     92f:	61                   	popa
     930:	69 6e 54 61 62       	imul   bp,WORD PTR [bp+0x54],0x6261
     935:	6c                   	ins    BYTE PTR es:[di],dx
     936:	65 45                	gs inc bp
     938:	44                   	inc    sp
     939:	47                   	inc    di
     93a:	b0 02                	mov    al,0x2
     93c:	04 00                	add    al,0x0
     93e:	07                   	pop    es
     93f:	46                   	inc    si
     940:	65 72 6d             	gs jb  0x9b0
     943:	65 72 31             	gs jb  0x977
     946:	b4 02                	mov    ah,0x2
     948:	1c 00                	sbb    al,0x0
     94a:	06                   	push   es
     94b:	54                   	push   sp
     94c:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     951:	b8 02 20             	mov    ax,0x2002
     954:	00 09                	add    BYTE PTR [bx+di],cl
     956:	50                   	push   ax
     957:	61                   	popa
     958:	69 6e 74 42 6f       	imul   bp,WORD PTR [bp+0x74],0x6f42
     95d:	78 31                	js     0x990
     95f:	bc 02 04             	mov    sp,0x402
     962:	00 0b                	add    BYTE PTR [bp+di],cl
     964:	54                   	push   sp
     965:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     96a:	49                   	dec    cx
     96b:	6e                   	outs   dx,BYTE PTR ds:[si]
     96c:	66 6f                	outs   dx,DWORD PTR ds:[si]
     96e:	31 c0                	xor    ax,ax
     970:	02 24                	add    ah,BYTE PTR [si]
     972:	00 13                	add    BYTE PTR [bp+di],dl
     974:	50                   	push   ax
     975:	72 69                	jb     0x9e0
     977:	6e                   	outs   dx,BYTE PTR ds:[si]
     978:	74 65                	je     0x9df
     97a:	72 53                	jb     0x9cf
     97c:	65 74 75             	gs je  0x9f4
     97f:	70 44                	jo     0x9c5
     981:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     986:	31 c4                	xor    sp,ax
     988:	02 04                	add    al,BYTE PTR [si]
     98a:	00 0d                	add    BYTE PTR [di],cl
     98c:	45                   	inc    bp
     98d:	6e                   	outs   dx,BYTE PTR ds:[si]
     98e:	74 72                	je     0xa02
     990:	65 70 72             	gs jo  0xa05
     993:	69 73 65 73 41       	imul   si,WORD PTR [bp+di+0x65],0x4173
     998:	32 c8                	xor    cl,al
     99a:	02 28                	add    ch,BYTE PTR [bx+si]
     99c:	00 0a                	add    BYTE PTR [bp+si],cl
     99e:	4d                   	dec    bp
     99f:	65 6d                	gs ins WORD PTR es:[di],dx
     9a1:	6f                   	outs   dx,WORD PTR ds:[si]
     9a2:	49                   	dec    cx
     9a3:	6d                   	ins    WORD PTR es:[di],dx
     9a4:	70 52                	jo     0x9f8
     9a6:	61                   	popa
     9a7:	70 cc                	jo     0x975
     9a9:	02 2c                	add    ch,BYTE PTR [si]
     9ab:	00 0b                	add    BYTE PTR [bp+di],cl
     9ad:	46                   	inc    si
     9ae:	6f                   	outs   dx,WORD PTR ds:[si]
     9af:	6e                   	outs   dx,BYTE PTR ds:[si]
     9b0:	74 44                	je     0x9f6
     9b2:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     9b7:	31 d0                	xor    ax,dx
     9b9:	02 04                	add    al,BYTE PTR [si]
     9bb:	00 02                	add    BYTE PTR [bp+si],al
     9bd:	4e                   	dec    si
     9be:	31 d4                	xor    sp,dx
     9c0:	02 04                	add    al,BYTE PTR [si]
     9c2:	00 08                	add    BYTE PTR [bx+si],cl
     9c4:	50                   	push   ax
     9c5:	6f                   	outs   dx,WORD PTR ds:[si]
     9c6:	6c                   	ins    BYTE PTR es:[di],dx
     9c7:	69 63 65 73 31       	imul   sp,WORD PTR [bp+di+0x65],0x3173
     9cc:	d8 02                	fadd   DWORD PTR [bp+si]
     9ce:	04 00                	add    al,0x0
     9d0:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
     9d3:	70 72                	jo     0xa47
     9d5:	65 73 73             	gs jae 0xa4b
     9d8:	69 6f 6e 72 61       	imul   bp,WORD PTR [bx+0x6e],0x6172
     9dd:	70 69                	jo     0xa48
     9df:	64 65 31 dc          	fs gs xor sp,bx
     9e3:	02 18                	add    bl,BYTE PTR [bx+si]
     9e5:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     9e9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     9ec:	33 e0                	xor    sp,ax
     9ee:	02 04                	add    al,BYTE PTR [si]
     9f0:	00 04                	add    BYTE PTR [si],al
     9f2:	53                   	push   bx
     9f3:	49                   	dec    cx
     9f4:	47                   	inc    di
     9f5:	31 0c                	xor    WORD PTR [si],cx
     9f7:	00 ef                	add    bh,ch
     9f9:	02 fe                	add    bh,dh
     9fb:	09 94 00 84          	or     WORD PTR [si-0x7c00],dx
     9ff:	0b c1                	or     ax,cx
     a01:	02 1e 0a d7          	add    bl,BYTE PTR ds:0xd70a
     a05:	01 7f 0c             	add    WORD PTR [bx+0xc],di
     a08:	38 01                	cmp    BYTE PTR [bx+di],al
     a0a:	b1 10                	mov    cl,0x10
     a0c:	ad                   	lods   ax,WORD PTR ds:[si]
     a0d:	0d 16 0a             	or     ax,0xa16
     a10:	17                   	pop    ss
     a11:	06                   	push   es
     a12:	22 0a                	and    cl,BYTE PTR [bp+si]
     a14:	8b 0b                	mov    cx,WORD PTR [bp+di]
     a16:	1a 0a                	sbb    cl,BYTE PTR [bp+si]
     a18:	22 03                	and    al,BYTE PTR [bp+di]
     a1a:	bf 35 2b             	mov    di,0x2b35
     a1d:	07                   	pop    es
     a1e:	26 0a 91 12 3d       	or     dl,BYTE PTR es:[bx+di+0x3d12]
     a23:	3c de                	cmp    al,0xde
     a25:	05 ae 0d             	add    ax,0xdae
     a28:	07                   	pop    es
     a29:	0c 54                	or     al,0x54
     a2b:	54                   	push   sp
     a2c:	68 65 4d             	push   0x4d65
     a2f:	61                   	popa
     a30:	69 6e 46 6f 72       	imul   bp,WORD PTR [bp+0x46],0x726f
     a35:	6d                   	ins    WORD PTR es:[di],dx
     a36:	d9 00                	fld    DWORD PTR [bx+si]
     a38:	5f                   	pop    di
     a39:	0a 7b 06             	or     bh,BYTE PTR [bp+di+0x6]
     a3c:	d1 0b                	ror    WORD PTR [bp+di],1
     a3e:	38 00                	cmp    BYTE PTR [bx+si],al
     a40:	04 53                	add    al,0x53
     a42:	6d                   	ins    WORD PTR es:[di],dx
     a43:	6d                   	ins    WORD PTR es:[di],dx
     a44:	66 00 00             	data32 add BYTE PTR [bx+si],al
     a47:	00 00                	add    BYTE PTR [bx+si],al
     a49:	00 00                	add    BYTE PTR [bx+si],al
     a4b:	31 00                	xor    WORD PTR [bx+si],ax
     a4d:	00 00                	add    BYTE PTR [bx+si],al
     a4f:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     a53:	ff                   	(bad)
     a54:	7f 00                	jg     0xa56
     a56:	00 02                	add    BYTE PTR [bp+si],al
     a58:	00 86 01 63          	add    BYTE PTR [bp+0x6301],al
     a5c:	0a ef                	or     ch,bh
     a5e:	0a 67 0a             	or     ah,BYTE PTR [bx+0xa]
     a61:	d8 00                	fadd   DWORD PTR [bx+si]
     a63:	d6                   	(bad)
     a64:	0b f6                	or     si,si
     a66:	0a 2a                	or     ch,BYTE PTR [bp+si]
     a68:	0b 55 89             	or     dx,WORD PTR [di-0x77]
     a6b:	e5 b8                	in     ax,0xb8
     a6d:	0c 00                	or     al,0x0
     a6f:	9a 44 04 91 0a       	call   0xa91:0x444
     a74:	83 ec 0c             	sub    sp,0xc
     a77:	31 c0                	xor    ax,ax
     a79:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     a7c:	b8 57 0a             	mov    ax,0xa57
     a7f:	0e                   	push   cs
     a80:	50                   	push   ax
     a81:	55                   	push   bp
     a82:	ff 36 58 18          	push   WORD PTR ds:0x1858
     a86:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     a8a:	9b dd 46 08          	fld    QWORD PTR [bp+0x8]
     a8e:	9a 83 10 a1 0a       	call   0xaa1:0x1083
     a93:	9b db 7e f4          	fstp   TBYTE PTR [bp-0xc]
     a97:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     a9a:	99                   	cwd
     a9b:	bf 47 0a             	mov    di,0xa47
     a9e:	9a 16 04 bc 0a       	call   0xabc:0x416
     aa3:	8b f8                	mov    di,ax
     aa5:	d1 e7                	shl    di,1
     aa7:	8b f7                	mov    si,di
     aa9:	d1 e7                	shl    di,1
     aab:	01 f7                	add    di,si
     aad:	8b 85 94 29          	mov    ax,WORD PTR [di+0x2994]
     ab1:	8b 9d 96 29          	mov    bx,WORD PTR [di+0x2996]
     ab5:	8b 95 98 29          	mov    dx,WORD PTR [di+0x2998]
     ab9:	9a 9d 0f c8 0a       	call   0xac8:0xf9d
     abe:	9b db 6e f4          	fld    TBYTE PTR [bp-0xc]
     ac2:	9b de e1             	fsubrp st(1),st
     ac5:	9a 87 10 cd 0a       	call   0xacd:0x1087
     aca:	9a 0e 10 d5 0a       	call   0xad5:0x100e
     acf:	bf 4f 0a             	mov    di,0xa4f
     ad2:	9a 16 04 fe 0a       	call   0xafe:0x416
     ad7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     ada:	83 7e fe 30          	cmp    WORD PTR [bp-0x2],0x30
     ade:	7e 06                	jle    0xae6
     ae0:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     ae3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     ae6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     aea:	83 c4 06             	add    sp,0x6
     aed:	eb 11                	jmp    0xb00
     aef:	31 c0                	xor    ax,ax
     af1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     af4:	eb 05                	jmp    0xafb
     af6:	31 c0                	xor    ax,ax
     af8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     afb:	9a 34 14 35 0b       	call   0xb35:0x1434
     b00:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     b03:	c9                   	leave
     b04:	ca 0a 00             	retf   0xa
     b07:	08 53 69             	or     BYTE PTR [bp+di+0x69],dl
     b0a:	6d                   	ins    WORD PTR es:[di],dx
     b0b:	73 74                	jae    0xb81
     b0d:	72 61                	jb     0xb70
     b0f:	74 01                	je     0xb12
     b11:	20 01                	and    BYTE PTR [bx+di],al
     b13:	5c                   	pop    sp
     b14:	0c 53                	or     al,0x53
     b16:	69 6d 73 74 72       	imul   bp,WORD PTR [di+0x73],0x7274
     b1b:	61                   	popa
     b1c:	74 2e                	je     0xb4c
     b1e:	48                   	dec    ax
     b1f:	6c                   	ins    BYTE PTR es:[di],dx
     b20:	70 04                	jo     0xb26
     b22:	50                   	push   ax
     b23:	61                   	popa
     b24:	74 68                	je     0xb8e
     b26:	00 00                	add    BYTE PTR [bx+si],al
     b28:	c2 0c b4             	ret    0xb40c
     b2b:	0c 55                	or     al,0x55
     b2d:	89 e5                	mov    bp,sp
     b2f:	b8 00 02             	mov    ax,0x200
     b32:	9a 44 04 5c 0b       	call   0xb5c:0x444
     b37:	81 ec 00 02          	sub    sp,0x200
     b3b:	68 01 80             	push   0x8001
     b3e:	9a ff ff 00 00       	call   0x0:0xffff
     b43:	c6 06 65 2c 2f       	mov    BYTE PTR ds:0x2c65,0x2f
     b48:	bf 07 0b             	mov    di,0xb07
     b4b:	0e                   	push   cs
     b4c:	57                   	push   di
     b4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b50:	81 c7 e4 02          	add    di,0x2e4
     b54:	06                   	push   es
     b55:	57                   	push   di
     b56:	68 ff 00             	push   0xff
     b59:	9a e7 17 8e 0b       	call   0xb8e:0x17e7
     b5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b61:	81 c7 e4 02          	add    di,0x2e4
     b65:	06                   	push   es
     b66:	57                   	push   di
     b67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b6a:	06                   	push   es
     b6b:	57                   	push   di
     b6c:	9a 8c 1d 2c 13       	call   0x132c:0x1d8c
     b71:	8d be 00 ff          	lea    di,[bp-0x100]
     b75:	16                   	push   ss
     b76:	57                   	push   di
     b77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b7a:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
     b7f:	06                   	push   es
     b80:	57                   	push   di
     b81:	9a 61 11 a7 0b       	call   0xba7:0x1161
     b86:	bf 10 0b             	mov    di,0xb10
     b89:	0e                   	push   cs
     b8a:	57                   	push   di
     b8b:	9a 4c 18 98 0b       	call   0xb98:0x184c
     b90:	bf 07 0b             	mov    di,0xb07
     b93:	0e                   	push   cs
     b94:	57                   	push   di
     b95:	9a 4c 18 ba 0b       	call   0xbba:0x184c
     b9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b9d:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
     ba2:	06                   	push   es
     ba3:	57                   	push   di
     ba4:	9a 37 12 e1 0d       	call   0xde1:0x1237
     ba9:	6a 00                	push   0x0
     bab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bae:	81 c7 e4 03          	add    di,0x3e4
     bb2:	06                   	push   es
     bb3:	57                   	push   di
     bb4:	68 ff 00             	push   0xff
     bb7:	9a 58 0e e3 0b       	call   0xbe3:0xe58
     bbc:	8d be 00 fe          	lea    di,[bp-0x200]
     bc0:	16                   	push   ss
     bc1:	57                   	push   di
     bc2:	8d be 00 ff          	lea    di,[bp-0x100]
     bc6:	16                   	push   ss
     bc7:	57                   	push   di
     bc8:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     bcc:	06                   	push   es
     bcd:	57                   	push   di
     bce:	9a d3 77 57 0c       	call   0xc57:0x77d3
     bd3:	9a 6e 0b df 12       	call   0x12df:0xb6e
     bd8:	bf 44 00             	mov    di,0x44
     bdb:	1e                   	push   ds
     bdc:	57                   	push   di
     bdd:	68 ff 00             	push   0xff
     be0:	9a e7 17 03 0c       	call   0xc03:0x17e7
     be5:	a0 44 00             	mov    al,ds:0x44
     be8:	30 e4                	xor    ah,ah
     bea:	8b f8                	mov    di,ax
     bec:	80 bd 44 00 5c       	cmp    BYTE PTR [di+0x44],0x5c
     bf1:	75 12                	jne    0xc05
     bf3:	bf 44 00             	mov    di,0x44
     bf6:	1e                   	push   ds
     bf7:	57                   	push   di
     bf8:	a0 44 00             	mov    al,ds:0x44
     bfb:	30 e4                	xor    ah,ah
     bfd:	50                   	push   ax
     bfe:	6a 01                	push   0x1
     c00:	9a 75 19 21 0c       	call   0xc21:0x1975
     c05:	a0 44 00             	mov    al,ds:0x44
     c08:	30 e4                	xor    ah,ah
     c0a:	8b f8                	mov    di,ax
     c0c:	80 bd 44 00 3a       	cmp    BYTE PTR [di+0x44],0x3a
     c11:	75 27                	jne    0xc3a
     c13:	8d be 00 ff          	lea    di,[bp-0x100]
     c17:	16                   	push   ss
     c18:	57                   	push   di
     c19:	bf 44 00             	mov    di,0x44
     c1c:	1e                   	push   ds
     c1d:	57                   	push   di
     c1e:	9a cd 17 2b 0c       	call   0xc2b:0x17cd
     c23:	bf 12 0b             	mov    di,0xb12
     c26:	0e                   	push   cs
     c27:	57                   	push   di
     c28:	9a 4c 18 38 0c       	call   0xc38:0x184c
     c2d:	bf 44 00             	mov    di,0x44
     c30:	1e                   	push   ds
     c31:	57                   	push   di
     c32:	68 ff 00             	push   0xff
     c35:	9a e7 17 42 0c       	call   0xc42:0x17e7
     c3a:	bf 44 00             	mov    di,0x44
     c3d:	1e                   	push   ds
     c3e:	57                   	push   di
     c3f:	9a b2 0e 47 0c       	call   0xc47:0xeb2
     c44:	9a 08 04 69 0c       	call   0xc69:0x408
     c49:	bf 14 0b             	mov    di,0xb14
     c4c:	0e                   	push   cs
     c4d:	57                   	push   di
     c4e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     c52:	06                   	push   es
     c53:	57                   	push   di
     c54:	9a 84 80 44 0d       	call   0xd44:0x8084
     c59:	bf 44 00             	mov    di,0x44
     c5c:	1e                   	push   ds
     c5d:	57                   	push   di
     c5e:	bf fa 19             	mov    di,0x19fa
     c61:	1e                   	push   ds
     c62:	57                   	push   di
     c63:	68 ff 00             	push   0xff
     c66:	9a e7 17 e9 0c       	call   0xce9:0x17e7
     c6b:	c6 06 fa 18 00       	mov    BYTE PTR ds:0x18fa,0x0
     c70:	6a 00                	push   0x0
     c72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c75:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
     c7a:	06                   	push   es
     c7b:	57                   	push   di
     c7c:	9a 72 26 a3 0f       	call   0xfa3:0x2672
     c81:	bf 21 0b             	mov    di,0xb21
     c84:	0e                   	push   cs
     c85:	57                   	push   di
     c86:	bf fa 19             	mov    di,0x19fa
     c89:	1e                   	push   ds
     c8a:	57                   	push   di
     c8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c8e:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
     c93:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
     c97:	06                   	push   es
     c98:	57                   	push   di
     c99:	9a 1b 1b 58 16       	call   0x1658:0x1b1b
     c9e:	b8 26 0b             	mov    ax,0xb26
     ca1:	0e                   	push   cs
     ca2:	50                   	push   ax
     ca3:	55                   	push   bp
     ca4:	ff 36 58 18          	push   WORD PTR ds:0x1858
     ca8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     cac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     caf:	06                   	push   es
     cb0:	57                   	push   di
     cb1:	9a c4 34 ca 0c       	call   0xcca:0x34c4
     cb6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     cba:	83 c4 06             	add    sp,0x6
     cbd:	b8 d7 0c             	mov    ax,0xcd7
     cc0:	0e                   	push   cs
     cc1:	50                   	push   ax
     cc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cc5:	06                   	push   es
     cc6:	57                   	push   di
     cc7:	9a 71 12 d4 0c       	call   0xcd4:0x1271
     ccc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ccf:	06                   	push   es
     cd0:	57                   	push   di
     cd1:	9a c2 0d 8c 0f       	call   0xf8c:0xdc2
     cd6:	cb                   	retf
     cd7:	9a a5 3e 72 29       	call   0x2972:0x3ea5
     cdc:	c9                   	leave
     cdd:	ca 08 00             	retf   0x8
     ce0:	55                   	push   bp
     ce1:	89 e5                	mov    bp,sp
     ce3:	b8 08 00             	mov    ax,0x8
     ce6:	9a 44 04 33 0d       	call   0xd33:0x444
     ceb:	83 ec 08             	sub    sp,0x8
     cee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cf1:	26 c4 bd b8 02       	les    di,DWORD PTR es:[di+0x2b8]
     cf6:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     cf9:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     cfc:	26 8b 45 34          	mov    ax,WORD PTR es:[di+0x34]
     d00:	26 8b 55 36          	mov    dx,WORD PTR es:[di+0x36]
     d04:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d07:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     d0a:	ff 76 fe             	push   WORD PTR [bp-0x2]
     d0d:	ff 76 fc             	push   WORD PTR [bp-0x4]
     d10:	68 c2 01             	push   0x1c2
     d13:	9a 35 33 f2 34       	call   0x34f2:0x3335
     d18:	50                   	push   ax
     d19:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d1c:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
     d20:	06                   	push   es
     d21:	57                   	push   di
     d22:	9a eb 10 87 38       	call   0x3887:0x10eb
     d27:	c9                   	leave
     d28:	ca 08 00             	retf   0x8
     d2b:	55                   	push   bp
     d2c:	89 e5                	mov    bp,sp
     d2e:	31 c0                	xor    ax,ax
     d30:	9a 44 04 52 0d       	call   0xd52:0x444
     d35:	6a 02                	push   0x2
     d37:	6a 00                	push   0x0
     d39:	6a 00                	push   0x0
     d3b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     d3f:	06                   	push   es
     d40:	57                   	push   di
     d41:	9a b2 77 1c 14       	call   0x141c:0x77b2
     d46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d49:	81 c7 e4 03          	add    di,0x3e4
     d4d:	06                   	push   es
     d4e:	57                   	push   di
     d4f:	9a b2 0e 57 0d       	call   0xd57:0xeb2
     d54:	9a 08 04 7d 0d       	call   0xd7d:0x408
     d59:	c9                   	leave
     d5a:	ca 0c 00             	retf   0xc
     d5d:	16                   	push   ss
     d5e:	51                   	push   cx
     d5f:	75 69                	jne    0xdca
     d61:	74 74                	je     0xdd7
     d63:	65 72 20             	gs jb  0xd86
     d66:	6c                   	ins    BYTE PTR es:[di],dx
     d67:	65 20 70 72          	and    BYTE PTR gs:[bx+si+0x72],dh
     d6b:	6f                   	outs   dx,WORD PTR ds:[si]
     d6c:	67 72 61             	addr32 jb 0xdd0
     d6f:	6d                   	ins    WORD PTR es:[di],dx
     d70:	6d                   	ins    WORD PTR es:[di],dx
     d71:	65 20 3f             	and    BYTE PTR gs:[bx],bh
     d74:	55                   	push   bp
     d75:	89 e5                	mov    bp,sp
     d77:	b8 00 01             	mov    ax,0x100
     d7a:	9a 44 04 94 0d       	call   0xd94:0x444
     d7f:	81 ec 00 01          	sub    sp,0x100
     d83:	bf 5d 0d             	mov    di,0xd5d
     d86:	0e                   	push   cs
     d87:	57                   	push   di
     d88:	8d be 00 ff          	lea    di,[bp-0x100]
     d8c:	16                   	push   ss
     d8d:	57                   	push   di
     d8e:	68 ff 00             	push   0xff
     d91:	9a e7 17 cb 0d       	call   0xdcb:0x17e7
     d96:	6a 20                	push   0x20
     d98:	9a fa 18 00 00       	call   0x0:0x18fa
     d9d:	8d be 00 ff          	lea    di,[bp-0x100]
     da1:	16                   	push   ss
     da2:	57                   	push   di
     da3:	6a 03                	push   0x3
     da5:	6a 0c                	push   0xc
     da7:	6a 00                	push   0x0
     da9:	6a 00                	push   0x0
     dab:	9a 8a 38 0f 19       	call   0x190f:0x388a
     db0:	3d 01 00             	cmp    ax,0x1
     db3:	b0 00                	mov    al,0x0
     db5:	75 01                	jne    0xdb8
     db7:	40                   	inc    ax
     db8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     dbb:	26 88 05             	mov    BYTE PTR es:[di],al
     dbe:	c9                   	leave
     dbf:	ca 0c 00             	retf   0xc
     dc2:	55                   	push   bp
     dc3:	89 e5                	mov    bp,sp
     dc5:	b8 0c 00             	mov    ax,0xc
     dc8:	9a 44 04 13 0e       	call   0xe13:0x444
     dcd:	83 ec 0c             	sub    sp,0xc
     dd0:	a0 4a 01             	mov    al,ds:0x14a
     dd3:	50                   	push   ax
     dd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dd7:	26 c4 bd b0 02       	les    di,DWORD PTR es:[di+0x2b0]
     ddc:	06                   	push   es
     ddd:	57                   	push   di
     dde:	9a 9b 12 f4 0d       	call   0xdf4:0x129b
     de3:	a0 4a 01             	mov    al,ds:0x14a
     de6:	50                   	push   ax
     de7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dea:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
     def:	06                   	push   es
     df0:	57                   	push   di
     df1:	9a 9b 12 09 0e       	call   0xe09:0x129b
     df6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     df9:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
     dfe:	89 7e fa             	mov    WORD PTR [bp-0x6],di
     e01:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
     e04:	06                   	push   es
     e05:	57                   	push   di
     e06:	9a 26 13 32 0e       	call   0xe32:0x1326
     e0b:	2d 01 00             	sub    ax,0x1
     e0e:	71 05                	jno    0xe15
     e10:	9a 3e 04 49 0e       	call   0xe49:0x43e
     e15:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     e18:	31 c0                	xor    ax,ax
     e1a:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     e1d:	7f 48                	jg     0xe67
     e1f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     e22:	eb 03                	jmp    0xe27
     e24:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     e27:	ff 76 fe             	push   WORD PTR [bp-0x2]
     e2a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     e2d:	06                   	push   es
     e2e:	57                   	push   di
     e2f:	9a 53 13 5d 0e       	call   0xe5d:0x1353
     e34:	89 c7                	mov    di,ax
     e36:	8e c2                	mov    es,dx
     e38:	89 7e f4             	mov    WORD PTR [bp-0xc],di
     e3b:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
     e3e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     e41:	2d 01 00             	sub    ax,0x1
     e44:	71 05                	jno    0xe4b
     e46:	9a 3e 04 b2 0f       	call   0xfb2:0x43e
     e4b:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
     e4f:	b0 00                	mov    al,0x0
     e51:	7f 01                	jg     0xe54
     e53:	40                   	inc    ax
     e54:	50                   	push   ax
     e55:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     e58:	06                   	push   es
     e59:	57                   	push   di
     e5a:	9a a5 13 7f 0e       	call   0xe7f:0x13a5
     e5f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     e62:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     e65:	75 bd                	jne    0xe24
     e67:	83 3e 4c 01 01       	cmp    WORD PTR ds:0x14c,0x1
     e6c:	b0 00                	mov    al,0x0
     e6e:	7e 01                	jle    0xe71
     e70:	40                   	inc    ax
     e71:	50                   	push   ax
     e72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e75:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
     e7a:	06                   	push   es
     e7b:	57                   	push   di
     e7c:	9a 9b 12 99 0e       	call   0xe99:0x129b
     e81:	83 3e 4c 01 01       	cmp    WORD PTR ds:0x14c,0x1
     e86:	b0 00                	mov    al,0x0
     e88:	7e 01                	jle    0xe8b
     e8a:	40                   	inc    ax
     e8b:	50                   	push   ax
     e8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e8f:	26 c4 bd fc 01       	les    di,DWORD PTR es:[di+0x1fc]
     e94:	06                   	push   es
     e95:	57                   	push   di
     e96:	9a 9b 12 ac 0e       	call   0xeac:0x129b
     e9b:	a0 4a 01             	mov    al,ds:0x14a
     e9e:	50                   	push   ax
     e9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ea2:	26 c4 bd 80 02       	les    di,DWORD PTR es:[di+0x280]
     ea7:	06                   	push   es
     ea8:	57                   	push   di
     ea9:	9a 9b 12 bf 0e       	call   0xebf:0x129b
     eae:	a0 4a 01             	mov    al,ds:0x14a
     eb1:	50                   	push   ax
     eb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eb5:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
     eba:	06                   	push   es
     ebb:	57                   	push   di
     ebc:	9a 9b 12 d9 0e       	call   0xed9:0x129b
     ec1:	83 3e 4c 01 01       	cmp    WORD PTR ds:0x14c,0x1
     ec6:	b0 00                	mov    al,0x0
     ec8:	7e 01                	jle    0xecb
     eca:	40                   	inc    ax
     ecb:	50                   	push   ax
     ecc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ecf:	26 c4 bd dc 01       	les    di,DWORD PTR es:[di+0x1dc]
     ed4:	06                   	push   es
     ed5:	57                   	push   di
     ed6:	9a 9b 12 f3 0e       	call   0xef3:0x129b
     edb:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
     ee0:	b0 00                	mov    al,0x0
     ee2:	7e 01                	jle    0xee5
     ee4:	40                   	inc    ax
     ee5:	50                   	push   ax
     ee6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ee9:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
     eee:	06                   	push   es
     eef:	57                   	push   di
     ef0:	9a 9b 12 0d 0f       	call   0xf0d:0x129b
     ef5:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
     efa:	b0 00                	mov    al,0x0
     efc:	7e 01                	jle    0xeff
     efe:	40                   	inc    ax
     eff:	50                   	push   ax
     f00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f03:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
     f08:	06                   	push   es
     f09:	57                   	push   di
     f0a:	9a 9b 12 20 0f       	call   0xf20:0x129b
     f0f:	a0 4a 01             	mov    al,ds:0x14a
     f12:	50                   	push   ax
     f13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f16:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
     f1b:	06                   	push   es
     f1c:	57                   	push   di
     f1d:	9a 9b 12 33 0f       	call   0xf33:0x129b
     f22:	a0 4a 01             	mov    al,ds:0x14a
     f25:	50                   	push   ax
     f26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f29:	26 c4 bd 30 02       	les    di,DWORD PTR es:[di+0x230]
     f2e:	06                   	push   es
     f2f:	57                   	push   di
     f30:	9a 9b 12 51 0f       	call   0xf51:0x129b
     f35:	83 3e 4c 01 01       	cmp    WORD PTR ds:0x14c,0x1
     f3a:	b0 00                	mov    al,0x0
     f3c:	7e 01                	jle    0xf3f
     f3e:	40                   	inc    ax
     f3f:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
     f43:	50                   	push   ax
     f44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f47:	26 c4 bd 38 02       	les    di,DWORD PTR es:[di+0x238]
     f4c:	06                   	push   es
     f4d:	57                   	push   di
     f4e:	9a 9b 12 64 0f       	call   0xf64:0x129b
     f53:	a0 4a 01             	mov    al,ds:0x14a
     f56:	50                   	push   ax
     f57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f5a:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
     f5f:	06                   	push   es
     f60:	57                   	push   di
     f61:	9a 9b 12 77 0f       	call   0xf77:0x129b
     f66:	a0 4a 01             	mov    al,ds:0x14a
     f69:	50                   	push   ax
     f6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f6d:	26 c4 bd 6c 02       	les    di,DWORD PTR es:[di+0x26c]
     f72:	06                   	push   es
     f73:	57                   	push   di
     f74:	9a 9b 12 e2 0f       	call   0xfe2:0x129b
     f79:	c9                   	leave
     f7a:	ca 04 00             	retf   0x4
     f7d:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
     f80:	6c                   	ins    BYTE PTR es:[di],dx
     f81:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
     f86:	6f                   	outs   dx,WORD PTR ds:[si]
     f87:	6e                   	outs   dx,BYTE PTR ds:[si]
     f88:	00 00                	add    BYTE PTR [bx+si],al
     f8a:	21 11                	and    WORD PTR [bx+di],dx
     f8c:	9d                   	popf
     f8d:	0f 0a                	(bad)
     f8f:	56                   	push   si
     f90:	61                   	popa
     f91:	6c                   	ins    BYTE PTR es:[di],dx
     f92:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
     f97:	6f                   	outs   dx,WORD PTR ds:[si]
     f98:	6e                   	outs   dx,BYTE PTR ds:[si]
     f99:	00 00                	add    BYTE PTR [bx+si],al
     f9b:	2f                   	das
     f9c:	12 a7 0f 01          	adc    ah,BYTE PTR [bx+0x10f]
     fa0:	00 5e 00             	add    BYTE PTR [bp+0x0],bl
     fa3:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     fa4:	10 43 12             	adc    BYTE PTR [bp+di+0x12],al
     fa7:	4b                   	dec    bx
     fa8:	12 55 89             	adc    dl,BYTE PTR [di-0x77]
     fab:	e5 b8                	in     ax,0xb8
     fad:	1c 00                	sbb    al,0x0
     faf:	9a 44 04 ec 0f       	call   0xfec:0x444
     fb4:	83 ec 1c             	sub    sp,0x1c
     fb7:	b8 9f 0f             	mov    ax,0xf9f
     fba:	0e                   	push   cs
     fbb:	50                   	push   ax
     fbc:	55                   	push   bp
     fbd:	ff 36 58 18          	push   WORD PTR ds:0x1858
     fc1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     fc5:	80 3e 4a 01 00       	cmp    BYTE PTR ds:0x14a,0x0
     fca:	75 03                	jne    0xfcf
     fcc:	e9 6b 02             	jmp    0x123a
     fcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fd2:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
     fd7:	89 7e f6             	mov    WORD PTR [bp-0xa],di
     fda:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
     fdd:	06                   	push   es
     fde:	57                   	push   di
     fdf:	9a 26 13 0b 10       	call   0x100b:0x1326
     fe4:	2d 01 00             	sub    ax,0x1
     fe7:	71 05                	jno    0xfee
     fe9:	9a 3e 04 22 10       	call   0x1022:0x43e
     fee:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     ff1:	31 c0                	xor    ax,ax
     ff3:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     ff6:	7f 48                	jg     0x1040
     ff8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ffb:	eb 03                	jmp    0x1000
     ffd:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1000:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1003:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1006:	06                   	push   es
    1007:	57                   	push   di
    1008:	9a 53 13 36 10       	call   0x1036:0x1353
    100d:	89 c7                	mov    di,ax
    100f:	8e c2                	mov    es,dx
    1011:	89 7e f0             	mov    WORD PTR [bp-0x10],di
    1014:	8c 46 f2             	mov    WORD PTR [bp-0xe],es
    1017:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    101a:	2d 01 00             	sub    ax,0x1
    101d:	71 05                	jno    0x1024
    101f:	9a 3e 04 00 12       	call   0x1200:0x43e
    1024:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    1028:	b0 00                	mov    al,0x0
    102a:	7f 01                	jg     0x102d
    102c:	40                   	inc    ax
    102d:	50                   	push   ax
    102e:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    1031:	06                   	push   es
    1032:	57                   	push   di
    1033:	9a a5 13 58 10       	call   0x1058:0x13a5
    1038:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    103b:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    103e:	75 bd                	jne    0xffd
    1040:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    1045:	b0 00                	mov    al,0x0
    1047:	7e 01                	jle    0x104a
    1049:	40                   	inc    ax
    104a:	50                   	push   ax
    104b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    104e:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    1053:	06                   	push   es
    1054:	57                   	push   di
    1055:	9a a5 13 72 10       	call   0x1072:0x13a5
    105a:	83 3e 06 1e 02       	cmp    WORD PTR ds:0x1e06,0x2
    105f:	b0 00                	mov    al,0x0
    1061:	7e 01                	jle    0x1064
    1063:	40                   	inc    ax
    1064:	50                   	push   ax
    1065:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1068:	26 c4 bd f0 01       	les    di,DWORD PTR es:[di+0x1f0]
    106d:	06                   	push   es
    106e:	57                   	push   di
    106f:	9a a5 13 8c 10       	call   0x108c:0x13a5
    1074:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    1079:	b0 00                	mov    al,0x0
    107b:	7c 01                	jl     0x107e
    107d:	40                   	inc    ax
    107e:	50                   	push   ax
    107f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1082:	26 c4 bd e0 02       	les    di,DWORD PTR es:[di+0x2e0]
    1087:	06                   	push   es
    1088:	57                   	push   di
    1089:	9a a5 13 3d 11       	call   0x113d:0x13a5
    108e:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1092:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1095:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    109a:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    109d:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    10a0:	06                   	push   es
    10a1:	57                   	push   di
    10a2:	9a d2 31 c7 10       	call   0x10c7:0x31d2
    10a7:	6a 01                	push   0x1
    10a9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    10ac:	06                   	push   es
    10ad:	57                   	push   di
    10ae:	9a fb 2f bd 10       	call   0x10bd:0x2ffb
    10b3:	6a 00                	push   0x0
    10b5:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    10b8:	06                   	push   es
    10b9:	57                   	push   di
    10ba:	9a d2 2e f4 10       	call   0x10f4:0x2ed2
    10bf:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    10c2:	06                   	push   es
    10c3:	57                   	push   di
    10c4:	9a bf 31 03 11       	call   0x1103:0x31bf
    10c9:	b8 88 0f             	mov    ax,0xf88
    10cc:	0e                   	push   cs
    10cd:	50                   	push   ax
    10ce:	55                   	push   bp
    10cf:	ff 36 58 18          	push   WORD PTR ds:0x1858
    10d3:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    10d7:	a1 4c 01             	mov    ax,ds:0x14c
    10da:	99                   	cwd
    10db:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    10de:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    10e1:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    10e5:	8d 7e ee             	lea    di,[bp-0x12]
    10e8:	16                   	push   ss
    10e9:	57                   	push   di
    10ea:	6a 00                	push   0x0
    10ec:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    10ef:	06                   	push   es
    10f0:	57                   	push   di
    10f1:	9a 95 28 5e 11       	call   0x115e:0x2895
    10f6:	bf 7d 0f             	mov    di,0xf7d
    10f9:	0e                   	push   cs
    10fa:	57                   	push   di
    10fb:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    10fe:	06                   	push   es
    10ff:	57                   	push   di
    1100:	9a 9b 3b 29 11       	call   0x1129:0x3b9b
    1105:	89 c7                	mov    di,ax
    1107:	8e c2                	mov    es,dx
    1109:	06                   	push   es
    110a:	57                   	push   di
    110b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    110e:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    1112:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1115:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1119:	83 c4 06             	add    sp,0x6
    111c:	b8 2c 11             	mov    ax,0x112c
    111f:	0e                   	push   cs
    1120:	50                   	push   ax
    1121:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1124:	06                   	push   es
    1125:	57                   	push   di
    1126:	9a d2 31 52 11       	call   0x1152:0x31d2
    112b:	cb                   	retf
    112c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    112f:	50                   	push   ax
    1130:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1133:	26 c4 bd 84 02       	les    di,DWORD PTR es:[di+0x284]
    1138:	06                   	push   es
    1139:	57                   	push   di
    113a:	9a 75 12 0b 12       	call   0x120b:0x1275
    113f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1142:	26 c4 bd ac 02       	les    di,DWORD PTR es:[di+0x2ac]
    1147:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    114a:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    114d:	06                   	push   es
    114e:	57                   	push   di
    114f:	9a d2 31 74 11       	call   0x1174:0x31d2
    1154:	6a 01                	push   0x1
    1156:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1159:	06                   	push   es
    115a:	57                   	push   di
    115b:	9a fb 2f 6a 11       	call   0x116a:0x2ffb
    1160:	6a 00                	push   0x0
    1162:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1165:	06                   	push   es
    1166:	57                   	push   di
    1167:	9a d2 2e c8 11       	call   0x11c8:0x2ed2
    116c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    116f:	06                   	push   es
    1170:	57                   	push   di
    1171:	9a bf 31 e5 11       	call   0x11e5:0x31bf
    1176:	b8 99 0f             	mov    ax,0xf99
    1179:	0e                   	push   cs
    117a:	50                   	push   ax
    117b:	55                   	push   bp
    117c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1180:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1184:	a1 4e 01             	mov    ax,ds:0x14e
    1187:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    118a:	b8 01 00             	mov    ax,0x1
    118d:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1190:	7e 03                	jle    0x1195
    1192:	e9 8e 00             	jmp    0x1223
    1195:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1198:	eb 03                	jmp    0x119d
    119a:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    119d:	a1 4c 01             	mov    ax,ds:0x14c
    11a0:	99                   	cwd
    11a1:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    11a4:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    11a7:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    11ab:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    11ae:	99                   	cwd
    11af:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    11b2:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    11b5:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    11b9:	8d 7e e4             	lea    di,[bp-0x1c]
    11bc:	16                   	push   ss
    11bd:	57                   	push   di
    11be:	6a 01                	push   0x1
    11c0:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    11c3:	06                   	push   es
    11c4:	57                   	push   di
    11c5:	9a 95 28 ce 1e       	call   0x1ece:0x2895
    11ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11cd:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    11d2:	89 7e f0             	mov    WORD PTR [bp-0x10],di
    11d5:	8c 46 f2             	mov    WORD PTR [bp-0xe],es
    11d8:	bf 8e 0f             	mov    di,0xf8e
    11db:	0e                   	push   cs
    11dc:	57                   	push   di
    11dd:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    11e0:	06                   	push   es
    11e1:	57                   	push   di
    11e2:	9a 9b 3b 37 12       	call   0x1237:0x3b9b
    11e7:	89 c7                	mov    di,ax
    11e9:	8e c2                	mov    es,dx
    11eb:	06                   	push   es
    11ec:	57                   	push   di
    11ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    11f0:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    11f4:	50                   	push   ax
    11f5:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    11f8:	05 01 00             	add    ax,0x1
    11fb:	71 05                	jno    0x1202
    11fd:	9a 3e 04 50 12       	call   0x1250:0x43e
    1202:	50                   	push   ax
    1203:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    1206:	06                   	push   es
    1207:	57                   	push   di
    1208:	9a 53 13 16 12       	call   0x1216:0x1353
    120d:	89 c7                	mov    di,ax
    120f:	8e c2                	mov    es,dx
    1211:	06                   	push   es
    1212:	57                   	push   di
    1213:	9a 75 12 02 2a       	call   0x2a02:0x1275
    1218:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    121b:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    121e:	74 03                	je     0x1223
    1220:	e9 77 ff             	jmp    0x119a
    1223:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1227:	83 c4 06             	add    sp,0x6
    122a:	b8 3a 12             	mov    ax,0x123a
    122d:	0e                   	push   cs
    122e:	50                   	push   ax
    122f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1232:	06                   	push   es
    1233:	57                   	push   di
    1234:	9a d2 31 3b 16       	call   0x163b:0x31d2
    1239:	cb                   	retf
    123a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    123e:	83 c4 06             	add    sp,0x6
    1241:	eb 14                	jmp    0x1257
    1243:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1246:	06                   	push   es
    1247:	57                   	push   di
    1248:	9a c7 28 19 19       	call   0x1919:0x28c7
    124d:	ea 85 13 55 12       	jmp    0x1255:0x1385
    1252:	9a 34 14 7a 12       	call   0x127a:0x1434
    1257:	c9                   	leave
    1258:	ca 04 00             	retf   0x4
    125b:	03 20                	add    sp,WORD PTR [bx+si]
    125d:	2d 20 02             	sub    ax,0x220
    1260:	20 28                	and    BYTE PTR [bx+si],ch
    1262:	01 29                	add    WORD PTR [bx+di],bp
    1264:	0b 20                	or     sp,WORD PTR [bx+si]
    1266:	2d 20 50             	sub    ax,0x5020
    1269:	e9 72 69             	jmp    0x7bde
    126c:	6f                   	outs   dx,WORD PTR ds:[si]
    126d:	64 65 20 00          	fs and BYTE PTR gs:[bx+si],al
    1271:	55                   	push   bp
    1272:	89 e5                	mov    bp,sp
    1274:	b8 00 04             	mov    ax,0x400
    1277:	9a 44 04 95 12       	call   0x1295:0x444
    127c:	81 ec 00 04          	sub    sp,0x400
    1280:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1283:	81 c7 e4 02          	add    di,0x2e4
    1287:	06                   	push   es
    1288:	57                   	push   di
    1289:	8d be 00 ff          	lea    di,[bp-0x100]
    128d:	16                   	push   ss
    128e:	57                   	push   di
    128f:	68 ff 00             	push   0xff
    1292:	9a e7 17 b0 12       	call   0x12b0:0x17e7
    1297:	80 3e 4a 01 00       	cmp    BYTE PTR ds:0x14a,0x0
    129c:	75 03                	jne    0x12a1
    129e:	e9 7d 00             	jmp    0x131e
    12a1:	8d be 00 fe          	lea    di,[bp-0x200]
    12a5:	16                   	push   ss
    12a6:	57                   	push   di
    12a7:	8d be 00 ff          	lea    di,[bp-0x100]
    12ab:	16                   	push   ss
    12ac:	57                   	push   di
    12ad:	9a cd 17 ba 12       	call   0x12ba:0x17cd
    12b2:	bf 5b 12             	mov    di,0x125b
    12b5:	0e                   	push   cs
    12b6:	57                   	push   di
    12b7:	9a 4c 18 c4 12       	call   0x12c4:0x184c
    12bc:	bf fa 1d             	mov    di,0x1dfa
    12bf:	1e                   	push   ds
    12c0:	57                   	push   di
    12c1:	9a 4c 18 ce 12       	call   0x12ce:0x184c
    12c6:	bf 5f 12             	mov    di,0x125f
    12c9:	0e                   	push   cs
    12ca:	57                   	push   di
    12cb:	9a 4c 18 e4 12       	call   0x12e4:0x184c
    12d0:	8d be 00 fd          	lea    di,[bp-0x300]
    12d4:	16                   	push   ss
    12d5:	57                   	push   di
    12d6:	a1 06 1e             	mov    ax,ds:0x1e06
    12d9:	99                   	cwd
    12da:	52                   	push   dx
    12db:	50                   	push   ax
    12dc:	9a a9 08 09 13       	call   0x1309:0x8a9
    12e1:	9a 4c 18 ee 12       	call   0x12ee:0x184c
    12e6:	bf 62 12             	mov    di,0x1262
    12e9:	0e                   	push   cs
    12ea:	57                   	push   di
    12eb:	9a 4c 18 f8 12       	call   0x12f8:0x184c
    12f0:	bf 64 12             	mov    di,0x1264
    12f3:	0e                   	push   cs
    12f4:	57                   	push   di
    12f5:	9a 4c 18 0e 13       	call   0x130e:0x184c
    12fa:	8d be 00 fc          	lea    di,[bp-0x400]
    12fe:	16                   	push   ss
    12ff:	57                   	push   di
    1300:	a1 4c 01             	mov    ax,ds:0x14c
    1303:	99                   	cwd
    1304:	52                   	push   dx
    1305:	50                   	push   ax
    1306:	9a a9 08 7f 14       	call   0x147f:0x8a9
    130b:	9a 4c 18 1c 13       	call   0x131c:0x184c
    1310:	8d be 00 ff          	lea    di,[bp-0x100]
    1314:	16                   	push   ss
    1315:	57                   	push   di
    1316:	68 ff 00             	push   0xff
    1319:	9a e7 17 12 14       	call   0x1412:0x17e7
    131e:	8d be 00 ff          	lea    di,[bp-0x100]
    1322:	16                   	push   ss
    1323:	57                   	push   di
    1324:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1327:	06                   	push   es
    1328:	57                   	push   di
    1329:	9a 8c 1d 47 13       	call   0x1347:0x1d8c
    132e:	80 3e 42 00 00       	cmp    BYTE PTR ds:0x42,0x0
    1333:	75 14                	jne    0x1349
    1335:	bf 70 12             	mov    di,0x1270
    1338:	0e                   	push   cs
    1339:	57                   	push   di
    133a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    133d:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1342:	06                   	push   es
    1343:	57                   	push   di
    1344:	9a 8c 1d 5c 13       	call   0x135c:0x1d8c
    1349:	8d be 00 fe          	lea    di,[bp-0x200]
    134d:	16                   	push   ss
    134e:	57                   	push   di
    134f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1352:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    1357:	06                   	push   es
    1358:	57                   	push   di
    1359:	9a 53 1d 6b 13       	call   0x136b:0x1d53
    135e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1361:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    1366:	06                   	push   es
    1367:	57                   	push   di
    1368:	9a 8c 1d 80 13       	call   0x1380:0x1d8c
    136d:	8d be 00 fe          	lea    di,[bp-0x200]
    1371:	16                   	push   ss
    1372:	57                   	push   di
    1373:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1376:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    137b:	06                   	push   es
    137c:	57                   	push   di
    137d:	9a 53 1d 8f 13       	call   0x138f:0x1d53
    1382:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1385:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    138a:	06                   	push   es
    138b:	57                   	push   di
    138c:	9a 8c 1d a4 13       	call   0x13a4:0x1d8c
    1391:	8d be 00 fe          	lea    di,[bp-0x200]
    1395:	16                   	push   ss
    1396:	57                   	push   di
    1397:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    139a:	26 c4 bd 58 02       	les    di,DWORD PTR es:[di+0x258]
    139f:	06                   	push   es
    13a0:	57                   	push   di
    13a1:	9a 53 1d b3 13       	call   0x13b3:0x1d53
    13a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13a9:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    13ae:	06                   	push   es
    13af:	57                   	push   di
    13b0:	9a 8c 1d c7 13       	call   0x13c7:0x1d8c
    13b5:	bf 2f 21             	mov    di,0x212f
    13b8:	1e                   	push   ds
    13b9:	57                   	push   di
    13ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13bd:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    13c2:	06                   	push   es
    13c3:	57                   	push   di
    13c4:	9a 8c 1d db 13       	call   0x13db:0x1d8c
    13c9:	bf 2f 22             	mov    di,0x222f
    13cc:	1e                   	push   ds
    13cd:	57                   	push   di
    13ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13d1:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    13d6:	06                   	push   es
    13d7:	57                   	push   di
    13d8:	9a 8c 1d ef 13       	call   0x13ef:0x1d8c
    13dd:	bf 2f 23             	mov    di,0x232f
    13e0:	1e                   	push   ds
    13e1:	57                   	push   di
    13e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e5:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    13ea:	06                   	push   es
    13eb:	57                   	push   di
    13ec:	9a 8c 1d 04 14       	call   0x1404:0x1d8c
    13f1:	8d be 00 ff          	lea    di,[bp-0x100]
    13f5:	16                   	push   ss
    13f6:	57                   	push   di
    13f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13fa:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    13ff:	06                   	push   es
    1400:	57                   	push   di
    1401:	9a 8c 1d 6d 29       	call   0x296d:0x1d8c
    1406:	c9                   	leave
    1407:	ca 04 00             	retf   0x4
    140a:	55                   	push   bp
    140b:	89 e5                	mov    bp,sp
    140d:	31 c0                	xor    ax,ax
    140f:	9a 44 04 67 14       	call   0x1467:0x444
    1414:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1417:	06                   	push   es
    1418:	57                   	push   di
    1419:	9a 56 55 92 19       	call   0x1992:0x5556
    141e:	c9                   	leave
    141f:	ca 08 00             	retf   0x8
    1422:	01 5c 01             	add    WORD PTR [si+0x1],bx
    1425:	2e 04 53             	cs add al,0x53
    1428:	49                   	dec    cx
    1429:	4d                   	dec    bp
    142a:	53                   	push   bx
    142b:	03 2e 44 42          	add    bp,WORD PTR ds:0x4244
    142f:	04 50                	add    al,0x50
    1431:	61                   	popa
    1432:	74 68                	je     0x149c
    1434:	01 53 03             	add    WORD PTR [bp+di+0x3],dx
    1437:	41                   	inc    cx
    1438:	43                   	inc    bx
    1439:	47                   	inc    di
    143a:	03 41 43             	add    ax,WORD PTR [bx+di+0x43]
    143d:	50                   	push   ax
    143e:	03 41 44             	add    ax,WORD PTR [bx+di+0x44]
    1441:	47                   	inc    di
    1442:	03 41 44             	add    ax,WORD PTR [bx+di+0x44]
    1445:	50                   	push   ax
    1446:	03 45 44             	add    ax,WORD PTR [di+0x44]
    1449:	47                   	inc    di
    144a:	03 45 44             	add    ax,WORD PTR [di+0x44]
    144d:	50                   	push   ax
    144e:	03 45 44             	add    ax,WORD PTR [di+0x44]
    1451:	4d                   	dec    bp
    1452:	03 45 52             	add    ax,WORD PTR [di+0x52]
    1455:	47                   	inc    di
    1456:	03 45 52             	add    ax,WORD PTR [di+0x52]
    1459:	50                   	push   ax
    145a:	03 4d 52             	add    cx,WORD PTR [di+0x52]
    145d:	50                   	push   ax
    145e:	55                   	push   bp
    145f:	89 e5                	mov    bp,sp
    1461:	b8 02 03             	mov    ax,0x302
    1464:	9a 44 04 8c 14       	call   0x148c:0x444
    1469:	81 ec 02 03          	sub    sp,0x302
    146d:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1471:	8d be fe fe          	lea    di,[bp-0x102]
    1475:	16                   	push   ss
    1476:	57                   	push   di
    1477:	bf fa 18             	mov    di,0x18fa
    147a:	1e                   	push   ds
    147b:	57                   	push   di
    147c:	9a 6e 0b f1 14       	call   0x14f1:0xb6e
    1481:	bf fa 19             	mov    di,0x19fa
    1484:	1e                   	push   ds
    1485:	57                   	push   di
    1486:	68 ff 00             	push   0xff
    1489:	9a e7 17 ac 14       	call   0x14ac:0x17e7
    148e:	a0 fa 19             	mov    al,ds:0x19fa
    1491:	30 e4                	xor    ah,ah
    1493:	8b f8                	mov    di,ax
    1495:	80 bd fa 19 5c       	cmp    BYTE PTR [di+0x19fa],0x5c
    149a:	75 12                	jne    0x14ae
    149c:	bf fa 19             	mov    di,0x19fa
    149f:	1e                   	push   ds
    14a0:	57                   	push   di
    14a1:	a0 fa 19             	mov    al,ds:0x19fa
    14a4:	30 e4                	xor    ah,ah
    14a6:	50                   	push   ax
    14a7:	6a 01                	push   0x1
    14a9:	9a 75 19 ca 14       	call   0x14ca:0x1975
    14ae:	a0 fa 19             	mov    al,ds:0x19fa
    14b1:	30 e4                	xor    ah,ah
    14b3:	8b f8                	mov    di,ax
    14b5:	80 bd fa 19 3a       	cmp    BYTE PTR [di+0x19fa],0x3a
    14ba:	75 27                	jne    0x14e3
    14bc:	8d be fe fe          	lea    di,[bp-0x102]
    14c0:	16                   	push   ss
    14c1:	57                   	push   di
    14c2:	bf fa 19             	mov    di,0x19fa
    14c5:	1e                   	push   ds
    14c6:	57                   	push   di
    14c7:	9a cd 17 d4 14       	call   0x14d4:0x17cd
    14cc:	bf 22 14             	mov    di,0x1422
    14cf:	0e                   	push   cs
    14d0:	57                   	push   di
    14d1:	9a 4c 18 e1 14       	call   0x14e1:0x184c
    14d6:	bf fa 19             	mov    di,0x19fa
    14d9:	1e                   	push   ds
    14da:	57                   	push   di
    14db:	68 ff 00             	push   0xff
    14de:	9a e7 17 fe 14       	call   0x14fe:0x17e7
    14e3:	8d be fe fe          	lea    di,[bp-0x102]
    14e7:	16                   	push   ss
    14e8:	57                   	push   di
    14e9:	bf fa 18             	mov    di,0x18fa
    14ec:	1e                   	push   ds
    14ed:	57                   	push   di
    14ee:	9a c1 0b 0e 15       	call   0x150e:0xbc1
    14f3:	bf fa 1a             	mov    di,0x1afa
    14f6:	1e                   	push   ds
    14f7:	57                   	push   di
    14f8:	68 ff 00             	push   0xff
    14fb:	9a e7 17 1b 15       	call   0x151b:0x17e7
    1500:	8d be fe fe          	lea    di,[bp-0x102]
    1504:	16                   	push   ss
    1505:	57                   	push   di
    1506:	bf fa 18             	mov    di,0x18fa
    1509:	1e                   	push   ds
    150a:	57                   	push   di
    150b:	9a 17 0c a4 15       	call   0x15a4:0xc17
    1510:	bf fa 1b             	mov    di,0x1bfa
    1513:	1e                   	push   ds
    1514:	57                   	push   di
    1515:	68 ff 00             	push   0xff
    1518:	9a e7 17 37 15       	call   0x1537:0x17e7
    151d:	8d be fe fe          	lea    di,[bp-0x102]
    1521:	16                   	push   ss
    1522:	57                   	push   di
    1523:	bf fa 1a             	mov    di,0x1afa
    1526:	1e                   	push   ds
    1527:	57                   	push   di
    1528:	6a 01                	push   0x1
    152a:	bf 24 14             	mov    di,0x1424
    152d:	0e                   	push   cs
    152e:	57                   	push   di
    152f:	bf fa 1a             	mov    di,0x1afa
    1532:	1e                   	push   ds
    1533:	57                   	push   di
    1534:	9a 78 18 41 15       	call   0x1541:0x1878
    1539:	2d 01 00             	sub    ax,0x1
    153c:	71 05                	jno    0x1543
    153e:	9a 3e 04 47 15       	call   0x1547:0x43e
    1543:	50                   	push   ax
    1544:	9a 0b 18 54 15       	call   0x1554:0x180b
    1549:	bf fa 1c             	mov    di,0x1cfa
    154c:	1e                   	push   ds
    154d:	57                   	push   di
    154e:	68 ff 00             	push   0xff
    1551:	9a e7 17 68 15       	call   0x1568:0x17e7
    1556:	8d be fe fe          	lea    di,[bp-0x102]
    155a:	16                   	push   ss
    155b:	57                   	push   di
    155c:	bf fa 1c             	mov    di,0x1cfa
    155f:	1e                   	push   ds
    1560:	57                   	push   di
    1561:	6a 01                	push   0x1
    1563:	6a 04                	push   0x4
    1565:	9a 0b 18 74 15       	call   0x1574:0x180b
    156a:	bf fa 1d             	mov    di,0x1dfa
    156d:	1e                   	push   ds
    156e:	57                   	push   di
    156f:	6a 04                	push   0x4
    1571:	9a e7 17 88 15       	call   0x1588:0x17e7
    1576:	8d be fe fe          	lea    di,[bp-0x102]
    157a:	16                   	push   ss
    157b:	57                   	push   di
    157c:	bf fa 1c             	mov    di,0x1cfa
    157f:	1e                   	push   ds
    1580:	57                   	push   di
    1581:	6a 05                	push   0x5
    1583:	6a 08                	push   0x8
    1585:	9a 0b 18 94 15       	call   0x1594:0x180b
    158a:	bf 00 1e             	mov    di,0x1e00
    158d:	1e                   	push   ds
    158e:	57                   	push   di
    158f:	6a 04                	push   0x4
    1591:	9a e7 17 ae 15       	call   0x15ae:0x17e7
    1596:	8d be fe fd          	lea    di,[bp-0x202]
    159a:	16                   	push   ss
    159b:	57                   	push   di
    159c:	bf fa 1b             	mov    di,0x1bfa
    159f:	1e                   	push   ds
    15a0:	57                   	push   di
    15a1:	9a b5 06 c4 15       	call   0x15c4:0x6b5
    15a6:	bf 2b 14             	mov    di,0x142b
    15a9:	0e                   	push   cs
    15aa:	57                   	push   di
    15ab:	9a be 18 ce 15       	call   0x15ce:0x18be
    15b0:	b0 00                	mov    al,0x0
    15b2:	75 01                	jne    0x15b5
    15b4:	40                   	inc    ax
    15b5:	50                   	push   ax
    15b6:	8d be fe fe          	lea    di,[bp-0x102]
    15ba:	16                   	push   ss
    15bb:	57                   	push   di
    15bc:	bf 00 1e             	mov    di,0x1e00
    15bf:	1e                   	push   ds
    15c0:	57                   	push   di
    15c1:	9a b5 06 12 16       	call   0x1612:0x6b5
    15c6:	bf 26 14             	mov    di,0x1426
    15c9:	0e                   	push   cs
    15ca:	57                   	push   di
    15cb:	9a be 18 f4 15       	call   0x15f4:0x18be
    15d0:	b0 00                	mov    al,0x0
    15d2:	75 01                	jne    0x15d5
    15d4:	40                   	inc    ax
    15d5:	5a                   	pop    dx
    15d6:	22 c2                	and    al,dl
    15d8:	8a d0                	mov    dl,al
    15da:	80 3e fa 1d 04       	cmp    BYTE PTR ds:0x1dfa,0x4
    15df:	b0 00                	mov    al,0x0
    15e1:	75 01                	jne    0x15e4
    15e3:	40                   	inc    ax
    15e4:	22 c2                	and    al,dl
    15e6:	08 c0                	or     al,al
    15e8:	75 03                	jne    0x15ed
    15ea:	e9 c6 02             	jmp    0x18b3
    15ed:	a0 fb 1d             	mov    al,ds:0x1dfb
    15f0:	50                   	push   ax
    15f1:	9a f9 1e 1e 16       	call   0x161e:0x1ef9
    15f6:	3c 41                	cmp    al,0x41
    15f8:	73 03                	jae    0x15fd
    15fa:	e9 b6 02             	jmp    0x18b3
    15fd:	3c 5a                	cmp    al,0x5a
    15ff:	76 03                	jbe    0x1604
    1601:	e9 af 02             	jmp    0x18b3
    1604:	8d be fe fc          	lea    di,[bp-0x302]
    1608:	16                   	push   ss
    1609:	57                   	push   di
    160a:	bf fa 1d             	mov    di,0x1dfa
    160d:	1e                   	push   ds
    160e:	57                   	push   di
    160f:	9a db 06 c2 19       	call   0x19c2:0x6db
    1614:	bf fa 1d             	mov    di,0x1dfa
    1617:	1e                   	push   ds
    1618:	57                   	push   di
    1619:	6a 04                	push   0x4
    161b:	9a e7 17 27 16       	call   0x1627:0x17e7
    1620:	a0 fb 1d             	mov    al,ds:0x1dfb
    1623:	50                   	push   ax
    1624:	9a f9 1e 69 16       	call   0x1669:0x1ef9
    1629:	a2 fb 1d             	mov    ds:0x1dfb,al
    162c:	6a 00                	push   0x0
    162e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1631:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    1636:	06                   	push   es
    1637:	57                   	push   di
    1638:	9a 72 26 95 1c       	call   0x1c95:0x2672
    163d:	bf 2f 14             	mov    di,0x142f
    1640:	0e                   	push   cs
    1641:	57                   	push   di
    1642:	bf fa 19             	mov    di,0x19fa
    1645:	1e                   	push   ds
    1646:	57                   	push   di
    1647:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    164a:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    164f:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    1653:	06                   	push   es
    1654:	57                   	push   di
    1655:	9a 1b 1b 29 3b       	call   0x3b29:0x1b1b
    165a:	bf fa 1a             	mov    di,0x1afa
    165d:	1e                   	push   ds
    165e:	57                   	push   di
    165f:	bf 08 1e             	mov    di,0x1e08
    1662:	1e                   	push   ds
    1663:	57                   	push   di
    1664:	6a 0c                	push   0xc
    1666:	9a e7 17 79 16       	call   0x1679:0x17e7
    166b:	8d be fe fc          	lea    di,[bp-0x302]
    166f:	16                   	push   ss
    1670:	57                   	push   di
    1671:	bf fa 1d             	mov    di,0x1dfa
    1674:	1e                   	push   ds
    1675:	57                   	push   di
    1676:	9a cd 17 83 16       	call   0x1683:0x17cd
    167b:	bf 34 14             	mov    di,0x1434
    167e:	0e                   	push   cs
    167f:	57                   	push   di
    1680:	9a 4c 18 8d 16       	call   0x168d:0x184c
    1685:	bf 36 14             	mov    di,0x1436
    1688:	0e                   	push   cs
    1689:	57                   	push   di
    168a:	9a 4c 18 97 16       	call   0x1697:0x184c
    168f:	bf 2b 14             	mov    di,0x142b
    1692:	0e                   	push   cs
    1693:	57                   	push   di
    1694:	9a 4c 18 a3 16       	call   0x16a3:0x184c
    1699:	bf 16 1e             	mov    di,0x1e16
    169c:	1e                   	push   ds
    169d:	57                   	push   di
    169e:	6a 0c                	push   0xc
    16a0:	9a e7 17 b3 16       	call   0x16b3:0x17e7
    16a5:	8d be fe fc          	lea    di,[bp-0x302]
    16a9:	16                   	push   ss
    16aa:	57                   	push   di
    16ab:	bf fa 1d             	mov    di,0x1dfa
    16ae:	1e                   	push   ds
    16af:	57                   	push   di
    16b0:	9a cd 17 bd 16       	call   0x16bd:0x17cd
    16b5:	bf 34 14             	mov    di,0x1434
    16b8:	0e                   	push   cs
    16b9:	57                   	push   di
    16ba:	9a 4c 18 c7 16       	call   0x16c7:0x184c
    16bf:	bf 3a 14             	mov    di,0x143a
    16c2:	0e                   	push   cs
    16c3:	57                   	push   di
    16c4:	9a 4c 18 d1 16       	call   0x16d1:0x184c
    16c9:	bf 2b 14             	mov    di,0x142b
    16cc:	0e                   	push   cs
    16cd:	57                   	push   di
    16ce:	9a 4c 18 dd 16       	call   0x16dd:0x184c
    16d3:	bf 24 1e             	mov    di,0x1e24
    16d6:	1e                   	push   ds
    16d7:	57                   	push   di
    16d8:	6a 0c                	push   0xc
    16da:	9a e7 17 ed 16       	call   0x16ed:0x17e7
    16df:	8d be fe fc          	lea    di,[bp-0x302]
    16e3:	16                   	push   ss
    16e4:	57                   	push   di
    16e5:	bf fa 1d             	mov    di,0x1dfa
    16e8:	1e                   	push   ds
    16e9:	57                   	push   di
    16ea:	9a cd 17 f7 16       	call   0x16f7:0x17cd
    16ef:	bf 34 14             	mov    di,0x1434
    16f2:	0e                   	push   cs
    16f3:	57                   	push   di
    16f4:	9a 4c 18 01 17       	call   0x1701:0x184c
    16f9:	bf 3e 14             	mov    di,0x143e
    16fc:	0e                   	push   cs
    16fd:	57                   	push   di
    16fe:	9a 4c 18 0b 17       	call   0x170b:0x184c
    1703:	bf 2b 14             	mov    di,0x142b
    1706:	0e                   	push   cs
    1707:	57                   	push   di
    1708:	9a 4c 18 17 17       	call   0x1717:0x184c
    170d:	bf 32 1e             	mov    di,0x1e32
    1710:	1e                   	push   ds
    1711:	57                   	push   di
    1712:	6a 0c                	push   0xc
    1714:	9a e7 17 27 17       	call   0x1727:0x17e7
    1719:	8d be fe fc          	lea    di,[bp-0x302]
    171d:	16                   	push   ss
    171e:	57                   	push   di
    171f:	bf fa 1d             	mov    di,0x1dfa
    1722:	1e                   	push   ds
    1723:	57                   	push   di
    1724:	9a cd 17 31 17       	call   0x1731:0x17cd
    1729:	bf 34 14             	mov    di,0x1434
    172c:	0e                   	push   cs
    172d:	57                   	push   di
    172e:	9a 4c 18 3b 17       	call   0x173b:0x184c
    1733:	bf 42 14             	mov    di,0x1442
    1736:	0e                   	push   cs
    1737:	57                   	push   di
    1738:	9a 4c 18 45 17       	call   0x1745:0x184c
    173d:	bf 2b 14             	mov    di,0x142b
    1740:	0e                   	push   cs
    1741:	57                   	push   di
    1742:	9a 4c 18 51 17       	call   0x1751:0x184c
    1747:	bf 40 1e             	mov    di,0x1e40
    174a:	1e                   	push   ds
    174b:	57                   	push   di
    174c:	6a 0c                	push   0xc
    174e:	9a e7 17 61 17       	call   0x1761:0x17e7
    1753:	8d be fe fc          	lea    di,[bp-0x302]
    1757:	16                   	push   ss
    1758:	57                   	push   di
    1759:	bf fa 1d             	mov    di,0x1dfa
    175c:	1e                   	push   ds
    175d:	57                   	push   di
    175e:	9a cd 17 6b 17       	call   0x176b:0x17cd
    1763:	bf 34 14             	mov    di,0x1434
    1766:	0e                   	push   cs
    1767:	57                   	push   di
    1768:	9a 4c 18 75 17       	call   0x1775:0x184c
    176d:	bf 46 14             	mov    di,0x1446
    1770:	0e                   	push   cs
    1771:	57                   	push   di
    1772:	9a 4c 18 7f 17       	call   0x177f:0x184c
    1777:	bf 2b 14             	mov    di,0x142b
    177a:	0e                   	push   cs
    177b:	57                   	push   di
    177c:	9a 4c 18 8b 17       	call   0x178b:0x184c
    1781:	bf 4e 1e             	mov    di,0x1e4e
    1784:	1e                   	push   ds
    1785:	57                   	push   di
    1786:	6a 0c                	push   0xc
    1788:	9a e7 17 9b 17       	call   0x179b:0x17e7
    178d:	8d be fe fc          	lea    di,[bp-0x302]
    1791:	16                   	push   ss
    1792:	57                   	push   di
    1793:	bf fa 1d             	mov    di,0x1dfa
    1796:	1e                   	push   ds
    1797:	57                   	push   di
    1798:	9a cd 17 a5 17       	call   0x17a5:0x17cd
    179d:	bf 34 14             	mov    di,0x1434
    17a0:	0e                   	push   cs
    17a1:	57                   	push   di
    17a2:	9a 4c 18 af 17       	call   0x17af:0x184c
    17a7:	bf 4a 14             	mov    di,0x144a
    17aa:	0e                   	push   cs
    17ab:	57                   	push   di
    17ac:	9a 4c 18 b9 17       	call   0x17b9:0x184c
    17b1:	bf 2b 14             	mov    di,0x142b
    17b4:	0e                   	push   cs
    17b5:	57                   	push   di
    17b6:	9a 4c 18 c5 17       	call   0x17c5:0x184c
    17bb:	bf 5c 1e             	mov    di,0x1e5c
    17be:	1e                   	push   ds
    17bf:	57                   	push   di
    17c0:	6a 0c                	push   0xc
    17c2:	9a e7 17 d5 17       	call   0x17d5:0x17e7
    17c7:	8d be fe fc          	lea    di,[bp-0x302]
    17cb:	16                   	push   ss
    17cc:	57                   	push   di
    17cd:	bf fa 1d             	mov    di,0x1dfa
    17d0:	1e                   	push   ds
    17d1:	57                   	push   di
    17d2:	9a cd 17 df 17       	call   0x17df:0x17cd
    17d7:	bf 34 14             	mov    di,0x1434
    17da:	0e                   	push   cs
    17db:	57                   	push   di
    17dc:	9a 4c 18 e9 17       	call   0x17e9:0x184c
    17e1:	bf 4e 14             	mov    di,0x144e
    17e4:	0e                   	push   cs
    17e5:	57                   	push   di
    17e6:	9a 4c 18 f3 17       	call   0x17f3:0x184c
    17eb:	bf 2b 14             	mov    di,0x142b
    17ee:	0e                   	push   cs
    17ef:	57                   	push   di
    17f0:	9a 4c 18 ff 17       	call   0x17ff:0x184c
    17f5:	bf 6a 1e             	mov    di,0x1e6a
    17f8:	1e                   	push   ds
    17f9:	57                   	push   di
    17fa:	6a 0c                	push   0xc
    17fc:	9a e7 17 0f 18       	call   0x180f:0x17e7
    1801:	8d be fe fc          	lea    di,[bp-0x302]
    1805:	16                   	push   ss
    1806:	57                   	push   di
    1807:	bf fa 1d             	mov    di,0x1dfa
    180a:	1e                   	push   ds
    180b:	57                   	push   di
    180c:	9a cd 17 19 18       	call   0x1819:0x17cd
    1811:	bf 34 14             	mov    di,0x1434
    1814:	0e                   	push   cs
    1815:	57                   	push   di
    1816:	9a 4c 18 23 18       	call   0x1823:0x184c
    181b:	bf 52 14             	mov    di,0x1452
    181e:	0e                   	push   cs
    181f:	57                   	push   di
    1820:	9a 4c 18 2d 18       	call   0x182d:0x184c
    1825:	bf 2b 14             	mov    di,0x142b
    1828:	0e                   	push   cs
    1829:	57                   	push   di
    182a:	9a 4c 18 39 18       	call   0x1839:0x184c
    182f:	bf 78 1e             	mov    di,0x1e78
    1832:	1e                   	push   ds
    1833:	57                   	push   di
    1834:	6a 0c                	push   0xc
    1836:	9a e7 17 49 18       	call   0x1849:0x17e7
    183b:	8d be fe fc          	lea    di,[bp-0x302]
    183f:	16                   	push   ss
    1840:	57                   	push   di
    1841:	bf fa 1d             	mov    di,0x1dfa
    1844:	1e                   	push   ds
    1845:	57                   	push   di
    1846:	9a cd 17 53 18       	call   0x1853:0x17cd
    184b:	bf 34 14             	mov    di,0x1434
    184e:	0e                   	push   cs
    184f:	57                   	push   di
    1850:	9a 4c 18 5d 18       	call   0x185d:0x184c
    1855:	bf 56 14             	mov    di,0x1456
    1858:	0e                   	push   cs
    1859:	57                   	push   di
    185a:	9a 4c 18 67 18       	call   0x1867:0x184c
    185f:	bf 2b 14             	mov    di,0x142b
    1862:	0e                   	push   cs
    1863:	57                   	push   di
    1864:	9a 4c 18 73 18       	call   0x1873:0x184c
    1869:	bf 86 1e             	mov    di,0x1e86
    186c:	1e                   	push   ds
    186d:	57                   	push   di
    186e:	6a 0c                	push   0xc
    1870:	9a e7 17 83 18       	call   0x1883:0x17e7
    1875:	8d be fe fc          	lea    di,[bp-0x302]
    1879:	16                   	push   ss
    187a:	57                   	push   di
    187b:	bf fa 1d             	mov    di,0x1dfa
    187e:	1e                   	push   ds
    187f:	57                   	push   di
    1880:	9a cd 17 8d 18       	call   0x188d:0x17cd
    1885:	bf 34 14             	mov    di,0x1434
    1888:	0e                   	push   cs
    1889:	57                   	push   di
    188a:	9a 4c 18 97 18       	call   0x1897:0x184c
    188f:	bf 5a 14             	mov    di,0x145a
    1892:	0e                   	push   cs
    1893:	57                   	push   di
    1894:	9a 4c 18 a1 18       	call   0x18a1:0x184c
    1899:	bf 2b 14             	mov    di,0x142b
    189c:	0e                   	push   cs
    189d:	57                   	push   di
    189e:	9a 4c 18 ad 18       	call   0x18ad:0x184c
    18a3:	bf 94 1e             	mov    di,0x1e94
    18a6:	1e                   	push   ds
    18a7:	57                   	push   di
    18a8:	6a 0c                	push   0xc
    18aa:	9a e7 17 de 18       	call   0x18de:0x17e7
    18af:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    18b3:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    18b6:	c9                   	leave
    18b7:	ca 04 00             	retf   0x4
    18ba:	1a 49 6d             	sbb    cl,BYTE PTR [bx+di+0x6d]
    18bd:	70 6f                	jo     0x192e
    18bf:	73 73                	jae    0x1934
    18c1:	69 62 6c 65 20       	imul   sp,WORD PTR [bp+si+0x6c],0x2065
    18c6:	64 65 20 63 72       	fs and BYTE PTR gs:[bp+di+0x72],ah
    18cb:	e9 65 72             	jmp    0x8b33
    18ce:	20 6c 65             	and    BYTE PTR [si+0x65],ch
    18d1:	20 4a 65             	and    BYTE PTR [bp+si+0x65],cl
    18d4:	75 55                	jne    0x192b
    18d6:	89 e5                	mov    bp,sp
    18d8:	b8 00 01             	mov    ax,0x100
    18db:	9a 44 04 f5 18       	call   0x18f5:0x444
    18e0:	81 ec 00 01          	sub    sp,0x100
    18e4:	bf ba 18             	mov    di,0x18ba
    18e7:	0e                   	push   cs
    18e8:	57                   	push   di
    18e9:	8d be 00 ff          	lea    di,[bp-0x100]
    18ed:	16                   	push   ss
    18ee:	57                   	push   di
    18ef:	68 ff 00             	push   0xff
    18f2:	9a e7 17 51 19       	call   0x1951:0x17e7
    18f7:	6a 30                	push   0x30
    18f9:	9a d9 1a 00 00       	call   0x0:0x1ad9
    18fe:	8d be 00 ff          	lea    di,[bp-0x100]
    1902:	16                   	push   ss
    1903:	57                   	push   di
    1904:	6a 01                	push   0x1
    1906:	6a 04                	push   0x4
    1908:	6a 00                	push   0x0
    190a:	6a 00                	push   0x0
    190c:	9a 8a 38 ee 1a       	call   0x1aee:0x388a
    1911:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1914:	06                   	push   es
    1915:	57                   	push   di
    1916:	9a c7 28 46 19       	call   0x1946:0x28c7
    191b:	c9                   	leave
    191c:	ca 04 00             	retf   0x4
    191f:	01 5c 04             	add    WORD PTR [si+0x4],bx
    1922:	53                   	push   bx
    1923:	49                   	dec    cx
    1924:	4d                   	dec    bp
    1925:	53                   	push   bx
    1926:	03 2e 44 42          	add    bp,WORD PTR ds:0x4244
    192a:	17                   	pop    ss
    192b:	4e                   	dec    si
    192c:	6f                   	outs   dx,WORD PTR ds:[si]
    192d:	6d                   	ins    WORD PTR es:[di],dx
    192e:	20 64 65             	and    BYTE PTR [si+0x65],ah
    1931:	20 66 69             	and    BYTE PTR [bp+0x69],ah
    1934:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1937:	65 72 20             	gs jb  0x195a
    193a:	69 6e 74 65 72       	imul   bp,WORD PTR [bp+0x74],0x7265
    193f:	64 69 74 00 00 19    	imul   si,WORD PTR fs:[si+0x0],0x1900
    1945:	1b 0b                	sbb    cx,WORD PTR [bp+di]
    1947:	1b 55 89             	sbb    dx,WORD PTR [di-0x77]
    194a:	e5 b8                	in     ax,0xb8
    194c:	0a 06 9a 44          	or     al,BYTE PTR ds:0x449a
    1950:	04 d0                	add    al,0xd0
    1952:	19 81 ec 0a          	sbb    WORD PTR [bx+di+0xaec],ax
    1956:	06                   	push   es
    1957:	80 3e 42 00 00       	cmp    BYTE PTR ds:0x42,0x0
    195c:	74 08                	je     0x1966
    195e:	9a 2b 35 8b 19       	call   0x198b:0x352b
    1963:	e9 c3 01             	jmp    0x1b29
    1966:	b8 42 19             	mov    ax,0x1942
    1969:	0e                   	push   cs
    196a:	50                   	push   ax
    196b:	55                   	push   bp
    196c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1970:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1974:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    1979:	c6 86 00 fd 00       	mov    BYTE PTR [bp-0x300],0x0
    197e:	ff 76 08             	push   WORD PTR [bp+0x8]
    1981:	ff 76 06             	push   WORD PTR [bp+0x6]
    1984:	b0 01                	mov    al,0x1
    1986:	50                   	push   ax
    1987:	b8 a8 17             	mov    ax,0x17a8
    198a:	ba f3 29             	mov    dx,0x29f3
    198d:	52                   	push   dx
    198e:	50                   	push   ax
    198f:	9a 53 25 bd 19       	call   0x19bd:0x2553
    1994:	89 86 fa fb          	mov    WORD PTR [bp-0x406],ax
    1998:	89 96 fc fb          	mov    WORD PTR [bp-0x404],dx
    199c:	c4 be fa fb          	les    di,DWORD PTR [bp-0x406]
    19a0:	89 be f6 fb          	mov    WORD PTR [bp-0x40a],di
    19a4:	8c 86 f8 fb          	mov    WORD PTR [bp-0x408],es
    19a8:	8d be f6 f9          	lea    di,[bp-0x60a]
    19ac:	16                   	push   ss
    19ad:	57                   	push   di
    19ae:	8d be f6 fa          	lea    di,[bp-0x50a]
    19b2:	16                   	push   ss
    19b3:	57                   	push   di
    19b4:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    19b8:	06                   	push   es
    19b9:	57                   	push   di
    19ba:	9a d3 77 0f 1a       	call   0x1a0f:0x77d3
    19bf:	9a 6e 0b 6f 1c       	call   0x1c6f:0xb6e
    19c4:	8d be 00 ff          	lea    di,[bp-0x100]
    19c8:	16                   	push   ss
    19c9:	57                   	push   di
    19ca:	68 ff 00             	push   0xff
    19cd:	9a e7 17 3b 1a       	call   0x1a3b:0x17e7
    19d2:	8a 86 01 ff          	mov    al,BYTE PTR [bp-0xff]
    19d6:	50                   	push   ax
    19d7:	c4 be f6 fb          	les    di,DWORD PTR [bp-0x40a]
    19db:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    19e0:	06                   	push   es
    19e1:	57                   	push   di
    19e2:	9a a4 1c 51 1a       	call   0x1a51:0x1ca4
    19e7:	8d be 00 ff          	lea    di,[bp-0x100]
    19eb:	16                   	push   ss
    19ec:	57                   	push   di
    19ed:	c4 be f6 fb          	les    di,DWORD PTR [bp-0x40a]
    19f1:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    19f6:	06                   	push   es
    19f7:	57                   	push   di
    19f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    19fb:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    1a00:	c7 86 fe fc 01 00    	mov    WORD PTR [bp-0x302],0x1
    1a06:	c4 be f6 fb          	les    di,DWORD PTR [bp-0x40a]
    1a0a:	06                   	push   es
    1a0b:	57                   	push   di
    1a0c:	9a 45 5d af 1a       	call   0x1aaf:0x5d45
    1a11:	3d 01 00             	cmp    ax,0x1
    1a14:	74 03                	je     0x1a19
    1a16:	e9 8d 00             	jmp    0x1aa6
    1a19:	8d be f6 fa          	lea    di,[bp-0x50a]
    1a1d:	16                   	push   ss
    1a1e:	57                   	push   di
    1a1f:	c4 be f6 fb          	les    di,DWORD PTR [bp-0x40a]
    1a23:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    1a28:	06                   	push   es
    1a29:	57                   	push   di
    1a2a:	9a 24 15 ff ff       	call   0xffff:0x1524
    1a2f:	8d be 00 fd          	lea    di,[bp-0x300]
    1a33:	16                   	push   ss
    1a34:	57                   	push   di
    1a35:	68 ff 00             	push   0xff
    1a38:	9a e7 17 5b 1a       	call   0x1a5b:0x17e7
    1a3d:	8d be f6 fa          	lea    di,[bp-0x50a]
    1a41:	16                   	push   ss
    1a42:	57                   	push   di
    1a43:	c4 be f6 fb          	les    di,DWORD PTR [bp-0x40a]
    1a47:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    1a4c:	06                   	push   es
    1a4d:	57                   	push   di
    1a4e:	9a 4a 26 ff ff       	call   0xffff:0x264a
    1a53:	bf 1f 19             	mov    di,0x191f
    1a56:	0e                   	push   cs
    1a57:	57                   	push   di
    1a58:	9a 4c 18 66 1a       	call   0x1a66:0x184c
    1a5d:	8d be 00 fd          	lea    di,[bp-0x300]
    1a61:	16                   	push   ss
    1a62:	57                   	push   di
    1a63:	9a 4c 18 70 1a       	call   0x1a70:0x184c
    1a68:	bf 21 19             	mov    di,0x1921
    1a6b:	0e                   	push   cs
    1a6c:	57                   	push   di
    1a6d:	9a 4c 18 7a 1a       	call   0x1a7a:0x184c
    1a72:	bf 26 19             	mov    di,0x1926
    1a75:	0e                   	push   cs
    1a76:	57                   	push   di
    1a77:	9a 4c 18 88 1a       	call   0x1a88:0x184c
    1a7c:	8d be 00 fe          	lea    di,[bp-0x200]
    1a80:	16                   	push   ss
    1a81:	57                   	push   di
    1a82:	68 ff 00             	push   0xff
    1a85:	9a e7 17 a0 1a       	call   0x1aa0:0x17e7
    1a8a:	c4 be f6 fb          	les    di,DWORD PTR [bp-0x40a]
    1a8e:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    1a93:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    1a98:	05 01 00             	add    ax,0x1
    1a9b:	71 05                	jno    0x1aa2
    1a9d:	9a 3e 04 bf 1a       	call   0x1abf:0x43e
    1aa2:	89 86 fe fc          	mov    WORD PTR [bp-0x302],ax
    1aa6:	c4 be f6 fb          	les    di,DWORD PTR [bp-0x40a]
    1aaa:	06                   	push   es
    1aab:	57                   	push   di
    1aac:	9a 1d 5f 90 1d       	call   0x1d90:0x5f1d
    1ab1:	8d be 00 fd          	lea    di,[bp-0x300]
    1ab5:	16                   	push   ss
    1ab6:	57                   	push   di
    1ab7:	bf 21 19             	mov    di,0x1921
    1aba:	0e                   	push   cs
    1abb:	57                   	push   di
    1abc:	9a be 18 d4 1a       	call   0x1ad4:0x18be
    1ac1:	75 2f                	jne    0x1af2
    1ac3:	bf 2a 19             	mov    di,0x192a
    1ac6:	0e                   	push   cs
    1ac7:	57                   	push   di
    1ac8:	8d be fe fb          	lea    di,[bp-0x402]
    1acc:	16                   	push   ss
    1acd:	57                   	push   di
    1ace:	68 ff 00             	push   0xff
    1ad1:	9a e7 17 21 1b       	call   0x1b21:0x17e7
    1ad6:	6a 30                	push   0x30
    1ad8:	9a 51 1d 00 00       	call   0x0:0x1d51
    1add:	8d be fe fb          	lea    di,[bp-0x402]
    1ae1:	16                   	push   ss
    1ae2:	57                   	push   di
    1ae3:	6a 01                	push   0x1
    1ae5:	6a 04                	push   0x4
    1ae7:	6a 00                	push   0x0
    1ae9:	6a 00                	push   0x0
    1aeb:	9a 8a 38 66 1d       	call   0x1d66:0x388a
    1af0:	eb 1b                	jmp    0x1b0d
    1af2:	80 be 00 fd 00       	cmp    BYTE PTR [bp-0x300],0x0
    1af7:	74 14                	je     0x1b0d
    1af9:	8d be 00 fe          	lea    di,[bp-0x200]
    1afd:	16                   	push   ss
    1afe:	57                   	push   di
    1aff:	ff b6 fe fc          	push   WORD PTR [bp-0x302]
    1b03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b06:	06                   	push   es
    1b07:	57                   	push   di
    1b08:	9a 22 1c 8e 1b       	call   0x1b8e:0x1c22
    1b0d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1b11:	83 c4 06             	add    sp,0x6
    1b14:	b8 29 1b             	mov    ax,0x1b29
    1b17:	0e                   	push   cs
    1b18:	50                   	push   ax
    1b19:	bf 44 00             	mov    di,0x44
    1b1c:	1e                   	push   ds
    1b1d:	57                   	push   di
    1b1e:	9a b2 0e 26 1b       	call   0x1b26:0xeb2
    1b23:	9a 08 04 2b 1c       	call   0x1c2b:0x408
    1b28:	cb                   	retf
    1b29:	c9                   	leave
    1b2a:	ca 08 00             	retf   0x8
    1b2d:	18 43 65             	sbb    BYTE PTR [bp+di+0x65],al
    1b30:	20 66 69             	and    BYTE PTR [bp+0x69],ah
    1b33:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1b36:	65 72 20             	gs jb  0x1b59
    1b39:	65 78 69             	gs js  0x1ba5
    1b3c:	73 74                	jae    0x1bb2
    1b3e:	65 20 64 e9          	and    BYTE PTR gs:[si-0x17],ah
    1b42:	6a e0                	push   0xffe0
    1b44:	20 21                	and    BYTE PTR [bx+di],ah
    1b46:	1a 43 72             	sbb    al,BYTE PTR [bp+di+0x72]
    1b49:	e9 65 72             	jmp    0x8db1
    1b4c:	20 6c 65             	and    BYTE PTR [si+0x65],ch
    1b4f:	20 4a 65             	and    BYTE PTR [bp+si+0x65],cl
    1b52:	75 3a                	jne    0x1b8e
    1b54:	0d 4e 6f             	or     ax,0x6f4e
    1b57:	6d                   	ins    WORD PTR es:[di],dx
    1b58:	20 64 65             	and    BYTE PTR [si+0x65],ah
    1b5b:	20 6a 65             	and    BYTE PTR [bp+si+0x65],ch
    1b5e:	75 3a                	jne    0x1b9a
    1b60:	20 0c                	and    BYTE PTR [si],cl
    1b62:	20 2d                	and    BYTE PTR [di],ch
    1b64:	2d 20 4e             	sub    ax,0x4e20
    1b67:	69 76 65 61 75       	imul   si,WORD PTR [bp+0x65],0x7561
    1b6c:	3a 20                	cmp    ah,BYTE PTR [bx+si]
    1b6e:	01 0d                	add    WORD PTR [di],cx
    1b70:	0c 46                	or     al,0x46
    1b72:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
    1b77:	72 3a                	jb     0x1bb3
    1b79:	20 20                	and    BYTE PTR [bx+si],ah
    1b7b:	20 20                	and    BYTE PTR [bx+si],ah
    1b7d:	0c 52                	or     al,0x52
    1b7f:	e9 70 65             	jmp    0x80f2
    1b82:	72 74                	jb     0x1bf8
    1b84:	6f                   	outs   dx,WORD PTR ds:[si]
    1b85:	69 72 65 3a 20       	imul   si,WORD PTR [bp+si+0x65],0x203a
    1b8a:	00 00                	add    BYTE PTR [bx+si],al
    1b8c:	95                   	xchg   bp,ax
    1b8d:	1e                   	push   ds
    1b8e:	d5 1b                	aad    0x1b
    1b90:	14 43                	adc    al,0x43
    1b92:	61                   	popa
    1b93:	70 69                	jo     0x1bfe
    1b95:	74 61                	je     0x1bf8
    1b97:	6c                   	ins    BYTE PTR es:[di],dx
    1b98:	53                   	push   bx
    1b99:	6f                   	outs   dx,WORD PTR ds:[si]
    1b9a:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    1b9d:	6c                   	ins    BYTE PTR es:[di],dx
    1b9e:	49                   	dec    cx
    1b9f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ba0:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
    1ba5:	11 4e 6f             	adc    WORD PTR [bp+0x6f],cx
    1ba8:	6d                   	ins    WORD PTR es:[di],dx
    1ba9:	62 72 65             	bound  si,DWORD PTR [bp+si+0x65]
    1bac:	45                   	inc    bp
    1bad:	6e                   	outs   dx,BYTE PTR ds:[si]
    1bae:	74 72                	je     0x1c22
    1bb0:	65 70 72             	gs jo  0x1c25
    1bb3:	69 73 65 73 00       	imul   si,WORD PTR [bp+di+0x65],0x73
    1bb8:	80 ff ff             	cmp    bh,0xff
    1bbb:	ff                   	(bad)
    1bbc:	7f 00                	jg     0x1bbe
    1bbe:	00 11                	add    BYTE PTR [bx+di],dl
    1bc0:	4d                   	dec    bp
    1bc1:	61                   	popa
    1bc2:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1bc5:	6e                   	outs   dx,BYTE PTR ds:[si]
    1bc6:	65 73 49             	gs jae 0x1c12
    1bc9:	6e                   	outs   dx,BYTE PTR ds:[si]
    1bca:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
    1bcf:	65 73 00             	gs jae 0x1bd2
    1bd2:	00 a9 1f f4          	add    BYTE PTR [bx+di-0xbe1],ch
    1bd6:	1b 01                	sbb    ax,WORD PTR [bx+di]
    1bd8:	00 00                	add    BYTE PTR [bx+si],al
    1bda:	00 02                	add    BYTE PTR [bp+si],al
    1bdc:	00 00                	add    BYTE PTR [bx+si],al
    1bde:	00 10                	add    BYTE PTR [bx+si],dl
    1be0:	54                   	push   sp
    1be1:	65 6d                	gs ins WORD PTR es:[di],dx
    1be3:	70 73                	jo     0x1c58
    1be5:	46                   	inc    si
    1be6:	61                   	popa
    1be7:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    1bea:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    1bed:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
    1bf2:	80 20 fa             	and    BYTE PTR [bx+si],0xfa
    1bf5:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1bf7:	00 ee                	add    dh,ch
    1bf9:	21 ad 1c 25          	and    WORD PTR [di+0x251c],bp
    1bfd:	20 6e 27             	and    BYTE PTR [bp+0x27],ch
    1c00:	65 73 74             	gs jae 0x1c77
    1c03:	20 70 61             	and    BYTE PTR [bx+si+0x61],dh
    1c06:	73 20                	jae    0x1c28
    1c08:	75 6e                	jne    0x1c78
    1c0a:	20 6e 6f             	and    BYTE PTR [bp+0x6f],ch
    1c0d:	6d                   	ins    WORD PTR es:[di],dx
    1c0e:	20 64 65             	and    BYTE PTR [si+0x65],ah
    1c11:	20 66 69             	and    BYTE PTR [bp+0x69],ah
    1c14:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1c17:	65 72 20             	gs jb  0x1c3a
    1c1a:	63 6f 72             	arpl   WORD PTR [bx+0x72],bp
    1c1d:	72 65                	jb     0x1c84
    1c1f:	63 74 2e             	arpl   WORD PTR [si+0x2e],si
    1c22:	55                   	push   bp
    1c23:	89 e5                	mov    bp,sp
    1c25:	b8 5c 03             	mov    ax,0x35c
    1c28:	9a 44 04 65 1c       	call   0x1c65:0x444
    1c2d:	81 ec 5c 03          	sub    sp,0x35c
    1c31:	8c d3                	mov    bx,ss
    1c33:	8e c3                	mov    es,bx
    1c35:	8c db                	mov    bx,ds
    1c37:	fc                   	cld
    1c38:	8d 7e b0             	lea    di,[bp-0x50]
    1c3b:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    1c3e:	ac                   	lods   al,BYTE PTR ds:[si]
    1c3f:	3c 4f                	cmp    al,0x4f
    1c41:	72 02                	jb     0x1c45
    1c43:	b0 4f                	mov    al,0x4f
    1c45:	aa                   	stos   BYTE PTR es:[di],al
    1c46:	91                   	xchg   cx,ax
    1c47:	30 ed                	xor    ch,ch
    1c49:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1c4b:	8e db                	mov    ds,bx
    1c4d:	c6 46 a4 00          	mov    BYTE PTR [bp-0x5c],0x0
    1c51:	c6 46 a5 00          	mov    BYTE PTR [bp-0x5b],0x0
    1c55:	8d 7e b0             	lea    di,[bp-0x50]
    1c58:	16                   	push   ss
    1c59:	57                   	push   di
    1c5a:	bf fa 18             	mov    di,0x18fa
    1c5d:	1e                   	push   ds
    1c5e:	57                   	push   di
    1c5f:	68 ff 00             	push   0xff
    1c62:	9a e7 17 86 1c       	call   0x1c86:0x17e7
    1c67:	bf fa 18             	mov    di,0x18fa
    1c6a:	1e                   	push   ds
    1c6b:	57                   	push   di
    1c6c:	9a 26 0a 9c 1c       	call   0x1c9c:0xa26
    1c71:	08 c0                	or     al,al
    1c73:	74 30                	je     0x1ca5
    1c75:	bf 2d 1b             	mov    di,0x1b2d
    1c78:	0e                   	push   cs
    1c79:	57                   	push   di
    1c7a:	8d be a4 fe          	lea    di,[bp-0x15c]
    1c7e:	16                   	push   ss
    1c7f:	57                   	push   di
    1c80:	68 ff 00             	push   0xff
    1c83:	9a e7 17 a3 1c       	call   0x1ca3:0x17e7
    1c88:	8d be a4 fe          	lea    di,[bp-0x15c]
    1c8c:	16                   	push   ss
    1c8d:	57                   	push   di
    1c8e:	b0 01                	mov    al,0x1
    1c90:	50                   	push   ax
    1c91:	b8 2f 00             	mov    ax,0x2f
    1c94:	ba c1 1e             	mov    dx,0x1ec1
    1c97:	52                   	push   dx
    1c98:	50                   	push   ax
    1c99:	9a e6 28 f3 1c       	call   0x1cf3:0x28e6
    1c9e:	52                   	push   dx
    1c9f:	50                   	push   ax
    1ca0:	9a 99 13 ce 1c       	call   0x1cce:0x1399
    1ca5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca8:	06                   	push   es
    1ca9:	57                   	push   di
    1caa:	9a c7 28 b7 1c       	call   0x1cb7:0x28c7
    1caf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cb2:	06                   	push   es
    1cb3:	57                   	push   di
    1cb4:	9a 5e 14 1e 22       	call   0x221e:0x145e
    1cb9:	08 c0                	or     al,al
    1cbb:	75 03                	jne    0x1cc0
    1cbd:	e9 6e 05             	jmp    0x222e
    1cc0:	8d be a4 fd          	lea    di,[bp-0x25c]
    1cc4:	16                   	push   ss
    1cc5:	57                   	push   di
    1cc6:	bf 46 1b             	mov    di,0x1b46
    1cc9:	0e                   	push   cs
    1cca:	57                   	push   di
    1ccb:	9a cd 17 d8 1c       	call   0x1cd8:0x17cd
    1cd0:	bf fa 1d             	mov    di,0x1dfa
    1cd3:	1e                   	push   ds
    1cd4:	57                   	push   di
    1cd5:	9a 4c 18 e2 1c       	call   0x1ce2:0x184c
    1cda:	bf 61 1b             	mov    di,0x1b61
    1cdd:	0e                   	push   cs
    1cde:	57                   	push   di
    1cdf:	9a 4c 18 f8 1c       	call   0x1cf8:0x184c
    1ce4:	8d be a4 fc          	lea    di,[bp-0x35c]
    1ce8:	16                   	push   ss
    1ce9:	57                   	push   di
    1cea:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1ced:	99                   	cwd
    1cee:	52                   	push   dx
    1cef:	50                   	push   ax
    1cf0:	9a a9 08 a9 1e       	call   0x1ea9:0x8a9
    1cf5:	9a 4c 18 02 1d       	call   0x1d02:0x184c
    1cfa:	bf 6e 1b             	mov    di,0x1b6e
    1cfd:	0e                   	push   cs
    1cfe:	57                   	push   di
    1cff:	9a 4c 18 0c 1d       	call   0x1d0c:0x184c
    1d04:	bf 6e 1b             	mov    di,0x1b6e
    1d07:	0e                   	push   cs
    1d08:	57                   	push   di
    1d09:	9a 4c 18 16 1d       	call   0x1d16:0x184c
    1d0e:	bf 70 1b             	mov    di,0x1b70
    1d11:	0e                   	push   cs
    1d12:	57                   	push   di
    1d13:	9a 4c 18 20 1d       	call   0x1d20:0x184c
    1d18:	bf fa 1a             	mov    di,0x1afa
    1d1b:	1e                   	push   ds
    1d1c:	57                   	push   di
    1d1d:	9a 4c 18 2a 1d       	call   0x1d2a:0x184c
    1d22:	bf 6e 1b             	mov    di,0x1b6e
    1d25:	0e                   	push   cs
    1d26:	57                   	push   di
    1d27:	9a 4c 18 34 1d       	call   0x1d34:0x184c
    1d2c:	bf 7d 1b             	mov    di,0x1b7d
    1d2f:	0e                   	push   cs
    1d30:	57                   	push   di
    1d31:	9a 4c 18 3e 1d       	call   0x1d3e:0x184c
    1d36:	bf fa 19             	mov    di,0x19fa
    1d39:	1e                   	push   ds
    1d3a:	57                   	push   di
    1d3b:	9a 4c 18 4c 1d       	call   0x1d4c:0x184c
    1d40:	8d be a4 fe          	lea    di,[bp-0x15c]
    1d44:	16                   	push   ss
    1d45:	57                   	push   di
    1d46:	68 ff 00             	push   0xff
    1d49:	9a e7 17 6a 1f       	call   0x1f6a:0x17e7
    1d4e:	6a 20                	push   0x20
    1d50:	9a 59 22 00 00       	call   0x0:0x2259
    1d55:	8d be a4 fe          	lea    di,[bp-0x15c]
    1d59:	16                   	push   ss
    1d5a:	57                   	push   di
    1d5b:	6a 03                	push   0x3
    1d5d:	6a 03                	push   0x3
    1d5f:	6a 00                	push   0x0
    1d61:	6a 00                	push   0x0
    1d63:	9a 8a 38 6e 22       	call   0x226e:0x388a
    1d68:	3d 06 00             	cmp    ax,0x6
    1d6b:	74 03                	je     0x1d70
    1d6d:	e9 bc 04             	jmp    0x222c
    1d70:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1d73:	a3 6e 01             	mov    ds:0x16e,ax
    1d76:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1d79:	a3 06 1e             	mov    ds:0x1e06,ax
    1d7c:	ff 76 08             	push   WORD PTR [bp+0x8]
    1d7f:	ff 76 06             	push   WORD PTR [bp+0x6]
    1d82:	b0 01                	mov    al,0x1
    1d84:	50                   	push   ax
    1d85:	b8 22 00             	mov    ax,0x22
    1d88:	ba b6 1d             	mov    dx,0x1db6
    1d8b:	52                   	push   dx
    1d8c:	50                   	push   ax
    1d8d:	9a 53 25 54 1e       	call   0x1e54:0x2553
    1d92:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    1d95:	89 56 aa             	mov    WORD PTR [bp-0x56],dx
    1d98:	c4 7e a8             	les    di,DWORD PTR [bp-0x58]
    1d9b:	89 be a0 fe          	mov    WORD PTR [bp-0x160],di
    1d9f:	8c 86 a2 fe          	mov    WORD PTR [bp-0x15e],es
    1da3:	b8 f6 1b             	mov    ax,0x1bf6
    1da6:	0e                   	push   cs
    1da7:	50                   	push   ax
    1da8:	55                   	push   bp
    1da9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1dad:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1db1:	06                   	push   es
    1db2:	57                   	push   di
    1db3:	9a 22 4d ee 1d       	call   0x1dee:0x4d22
    1db8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dbb:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    1dc0:	89 be 9c fe          	mov    WORD PTR [bp-0x164],di
    1dc4:	8c 86 9e fe          	mov    WORD PTR [bp-0x162],es
    1dc8:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    1dcc:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    1dd1:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    1dd6:	bf 08 1e             	mov    di,0x1e08
    1dd9:	1e                   	push   ds
    1dda:	57                   	push   di
    1ddb:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1ddf:	81 c7 38 00          	add    di,0x38
    1de3:	06                   	push   es
    1de4:	57                   	push   di
    1de5:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    1de9:	06                   	push   es
    1dea:	57                   	push   di
    1deb:	9a 2d 4c 16 1e       	call   0x1e16:0x4c2d
    1df0:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    1df4:	26 ff b5 82 01       	push   WORD PTR es:[di+0x182]
    1df9:	26 ff b5 80 01       	push   WORD PTR es:[di+0x180]
    1dfe:	bf 16 1e             	mov    di,0x1e16
    1e01:	1e                   	push   ds
    1e02:	57                   	push   di
    1e03:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1e07:	81 c7 38 00          	add    di,0x38
    1e0b:	06                   	push   es
    1e0c:	57                   	push   di
    1e0d:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    1e11:	06                   	push   es
    1e12:	57                   	push   di
    1e13:	9a 2d 4c 3e 1e       	call   0x1e3e:0x4c2d
    1e18:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    1e1c:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    1e21:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    1e26:	bf 24 1e             	mov    di,0x1e24
    1e29:	1e                   	push   ds
    1e2a:	57                   	push   di
    1e2b:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1e2f:	81 c7 38 00          	add    di,0x38
    1e33:	06                   	push   es
    1e34:	57                   	push   di
    1e35:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    1e39:	06                   	push   es
    1e3a:	57                   	push   di
    1e3b:	9a 2d 4c c2 20       	call   0x20c2:0x4c2d
    1e40:	ff 76 08             	push   WORD PTR [bp+0x8]
    1e43:	ff 76 06             	push   WORD PTR [bp+0x6]
    1e46:	b0 01                	mov    al,0x1
    1e48:	50                   	push   ax
    1e49:	b8 22 00             	mov    ax,0x22
    1e4c:	ba 72 1e             	mov    dx,0x1e72
    1e4f:	52                   	push   dx
    1e50:	50                   	push   ax
    1e51:	9a 53 25 7c 1e       	call   0x1e7c:0x2553
    1e56:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    1e59:	89 56 ae             	mov    WORD PTR [bp-0x52],dx
    1e5c:	b8 8a 1b             	mov    ax,0x1b8a
    1e5f:	0e                   	push   cs
    1e60:	50                   	push   ax
    1e61:	55                   	push   bp
    1e62:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1e66:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1e6a:	c4 7e ac             	les    di,DWORD PTR [bp-0x54]
    1e6d:	06                   	push   es
    1e6e:	57                   	push   di
    1e6f:	9a bf 2b 7b 30       	call   0x307b:0x2bbf
    1e74:	c4 7e ac             	les    di,DWORD PTR [bp-0x54]
    1e77:	06                   	push   es
    1e78:	57                   	push   di
    1e79:	9a 45 5d 9d 1e       	call   0x1e9d:0x5d45
    1e7e:	3d 01 00             	cmp    ax,0x1
    1e81:	b0 00                	mov    al,0x0
    1e83:	75 01                	jne    0x1e86
    1e85:	40                   	inc    ax
    1e86:	88 46 a5             	mov    BYTE PTR [bp-0x5b],al
    1e89:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1e8d:	83 c4 06             	add    sp,0x6
    1e90:	b8 a0 1e             	mov    ax,0x1ea0
    1e93:	0e                   	push   cs
    1e94:	50                   	push   ax
    1e95:	c4 7e ac             	les    di,DWORD PTR [bp-0x54]
    1e98:	06                   	push   es
    1e99:	57                   	push   di
    1e9a:	9a 1d 5f 08 22       	call   0x2208:0x5f1d
    1e9f:	cb                   	retf
    1ea0:	80 7e a5 00          	cmp    BYTE PTR [bp-0x5b],0x0
    1ea4:	75 05                	jne    0x1eab
    1ea6:	9a c3 28 21 1f       	call   0x1f21:0x28c3
    1eab:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    1eaf:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    1eb4:	89 be 9c fe          	mov    WORD PTR [bp-0x164],di
    1eb8:	8c 86 9e fe          	mov    WORD PTR [bp-0x162],es
    1ebc:	06                   	push   es
    1ebd:	57                   	push   di
    1ebe:	9a d2 31 e6 1e       	call   0x1ee6:0x31d2
    1ec3:	6a 01                	push   0x1
    1ec5:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1ec9:	06                   	push   es
    1eca:	57                   	push   di
    1ecb:	9a fb 2f db 1e       	call   0x1edb:0x2ffb
    1ed0:	6a 00                	push   0x0
    1ed2:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1ed6:	06                   	push   es
    1ed7:	57                   	push   di
    1ed8:	9a d2 2e 18 1f       	call   0x1f18:0x2ed2
    1edd:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1ee1:	06                   	push   es
    1ee2:	57                   	push   di
    1ee3:	9a bf 31 31 1f       	call   0x1f31:0x31bf
    1ee8:	b8 d1 1b             	mov    ax,0x1bd1
    1eeb:	0e                   	push   cs
    1eec:	50                   	push   ax
    1eed:	55                   	push   bp
    1eee:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1ef2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1ef6:	c7 86 94 fe 01 00    	mov    WORD PTR [bp-0x16c],0x1
    1efc:	c7 86 96 fe 00 00    	mov    WORD PTR [bp-0x16a],0x0
    1f02:	c6 86 98 fe 00       	mov    BYTE PTR [bp-0x168],0x0
    1f07:	8d be 94 fe          	lea    di,[bp-0x16c]
    1f0b:	16                   	push   ss
    1f0c:	57                   	push   di
    1f0d:	6a 00                	push   0x0
    1f0f:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1f13:	06                   	push   es
    1f14:	57                   	push   di
    1f15:	9a 95 28 d8 1f       	call   0x1fd8:0x2895
    1f1a:	08 c0                	or     al,al
    1f1c:	75 05                	jne    0x1f23
    1f1e:	9a c3 28 35 20       	call   0x2035:0x28c3
    1f23:	bf 90 1b             	mov    di,0x1b90
    1f26:	0e                   	push   cs
    1f27:	57                   	push   di
    1f28:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1f2c:	06                   	push   es
    1f2d:	57                   	push   di
    1f2e:	9a 9b 3b 55 1f       	call   0x1f55:0x3b9b
    1f33:	89 c7                	mov    di,ax
    1f35:	8e c2                	mov    es,dx
    1f37:	06                   	push   es
    1f38:	57                   	push   di
    1f39:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f3c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1f40:	9b dd 1e 52 01       	fstp   QWORD PTR ds:0x152
    1f45:	90                   	nop
    1f46:	9b                   	fwait
    1f47:	bf a5 1b             	mov    di,0x1ba5
    1f4a:	0e                   	push   cs
    1f4b:	57                   	push   di
    1f4c:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1f50:	06                   	push   es
    1f51:	57                   	push   di
    1f52:	9a 9b 3b 7d 1f       	call   0x1f7d:0x3b9b
    1f57:	89 c7                	mov    di,ax
    1f59:	8e c2                	mov    es,dx
    1f5b:	06                   	push   es
    1f5c:	57                   	push   di
    1f5d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f60:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1f64:	bf b7 1b             	mov    di,0x1bb7
    1f67:	9a 16 04 92 1f       	call   0x1f92:0x416
    1f6c:	a3 5a 01             	mov    ds:0x15a,ax
    1f6f:	bf bf 1b             	mov    di,0x1bbf
    1f72:	0e                   	push   cs
    1f73:	57                   	push   di
    1f74:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1f78:	06                   	push   es
    1f79:	57                   	push   di
    1f7a:	9a 9b 3b b2 1f       	call   0x1fb2:0x3b9b
    1f7f:	89 c7                	mov    di,ax
    1f81:	8e c2                	mov    es,dx
    1f83:	06                   	push   es
    1f84:	57                   	push   di
    1f85:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f88:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1f8c:	bf b7 1b             	mov    di,0x1bb7
    1f8f:	9a 16 04 60 20       	call   0x2060:0x416
    1f94:	a3 5c 01             	mov    ds:0x15c,ax
    1f97:	a1 5a 01             	mov    ax,ds:0x15a
    1f9a:	a3 4e 01             	mov    ds:0x14e,ax
    1f9d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1fa1:	83 c4 06             	add    sp,0x6
    1fa4:	b8 b5 1f             	mov    ax,0x1fb5
    1fa7:	0e                   	push   cs
    1fa8:	50                   	push   ax
    1fa9:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1fad:	06                   	push   es
    1fae:	57                   	push   di
    1faf:	9a d2 31 cb 1f       	call   0x1fcb:0x31d2
    1fb4:	cb                   	retf
    1fb5:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    1fb9:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    1fbe:	89 be 9c fe          	mov    WORD PTR [bp-0x164],di
    1fc2:	8c 86 9e fe          	mov    WORD PTR [bp-0x162],es
    1fc6:	06                   	push   es
    1fc7:	57                   	push   di
    1fc8:	9a d2 31 f0 1f       	call   0x1ff0:0x31d2
    1fcd:	6a 01                	push   0x1
    1fcf:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1fd3:	06                   	push   es
    1fd4:	57                   	push   di
    1fd5:	9a fb 2f e5 1f       	call   0x1fe5:0x2ffb
    1fda:	6a 00                	push   0x0
    1fdc:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1fe0:	06                   	push   es
    1fe1:	57                   	push   di
    1fe2:	9a d2 2e 2c 20       	call   0x202c:0x2ed2
    1fe7:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    1feb:	06                   	push   es
    1fec:	57                   	push   di
    1fed:	9a bf 31 47 20       	call   0x2047:0x31bf
    1ff2:	b8 f0 1b             	mov    ax,0x1bf0
    1ff5:	0e                   	push   cs
    1ff6:	50                   	push   ax
    1ff7:	55                   	push   bp
    1ff8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1ffc:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2000:	c7 46 a6 01 00       	mov    WORD PTR [bp-0x5a],0x1
    2005:	eb 03                	jmp    0x200a
    2007:	ff 46 a6             	inc    WORD PTR [bp-0x5a]
    200a:	8b 46 a6             	mov    ax,WORD PTR [bp-0x5a]
    200d:	99                   	cwd
    200e:	89 86 94 fe          	mov    WORD PTR [bp-0x16c],ax
    2012:	89 96 96 fe          	mov    WORD PTR [bp-0x16a],dx
    2016:	c6 86 98 fe 00       	mov    BYTE PTR [bp-0x168],0x0
    201b:	8d be 94 fe          	lea    di,[bp-0x16c]
    201f:	16                   	push   ss
    2020:	57                   	push   di
    2021:	6a 00                	push   0x0
    2023:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    2027:	06                   	push   es
    2028:	57                   	push   di
    2029:	9a 95 28 5c 25       	call   0x255c:0x2895
    202e:	08 c0                	or     al,al
    2030:	75 07                	jne    0x2039
    2032:	9a c3 28 ce 22       	call   0x22ce:0x28c3
    2037:	eb 35                	jmp    0x206e
    2039:	bf df 1b             	mov    di,0x1bdf
    203c:	0e                   	push   cs
    203d:	57                   	push   di
    203e:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    2042:	06                   	push   es
    2043:	57                   	push   di
    2044:	9a 9b 3b 89 20       	call   0x2089:0x3b9b
    2049:	89 c7                	mov    di,ax
    204b:	8e c2                	mov    es,dx
    204d:	06                   	push   es
    204e:	57                   	push   di
    204f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2052:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2056:	8b 46 a6             	mov    ax,WORD PTR [bp-0x5a]
    2059:	99                   	cwd
    205a:	bf d7 1b             	mov    di,0x1bd7
    205d:	9a 16 04 3c 22       	call   0x223c:0x416
    2062:	8b f8                	mov    di,ax
    2064:	c1 e7 03             	shl    di,0x3
    2067:	9b dd 9d 56 01       	fstp   QWORD PTR [di+0x156]
    206c:	90                   	nop
    206d:	9b                   	fwait
    206e:	83 7e a6 02          	cmp    WORD PTR [bp-0x5a],0x2
    2072:	75 93                	jne    0x2007
    2074:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2078:	83 c4 06             	add    sp,0x6
    207b:	b8 8c 20             	mov    ax,0x208c
    207e:	0e                   	push   cs
    207f:	50                   	push   ax
    2080:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    2084:	06                   	push   es
    2085:	57                   	push   di
    2086:	9a d2 31 d7 23       	call   0x23d7:0x31d2
    208b:	cb                   	retf
    208c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    208f:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    2094:	89 be 9c fe          	mov    WORD PTR [bp-0x164],di
    2098:	8c 86 9e fe          	mov    WORD PTR [bp-0x162],es
    209c:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    20a0:	26 ff b5 8a 01       	push   WORD PTR es:[di+0x18a]
    20a5:	26 ff b5 88 01       	push   WORD PTR es:[di+0x188]
    20aa:	bf 32 1e             	mov    di,0x1e32
    20ad:	1e                   	push   ds
    20ae:	57                   	push   di
    20af:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    20b3:	81 c7 38 00          	add    di,0x38
    20b7:	06                   	push   es
    20b8:	57                   	push   di
    20b9:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    20bd:	06                   	push   es
    20be:	57                   	push   di
    20bf:	9a 2d 4c ea 20       	call   0x20ea:0x4c2d
    20c4:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    20c8:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    20cd:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    20d2:	bf 40 1e             	mov    di,0x1e40
    20d5:	1e                   	push   ds
    20d6:	57                   	push   di
    20d7:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    20db:	81 c7 38 00          	add    di,0x38
    20df:	06                   	push   es
    20e0:	57                   	push   di
    20e1:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    20e5:	06                   	push   es
    20e6:	57                   	push   di
    20e7:	9a 2d 4c 12 21       	call   0x2112:0x4c2d
    20ec:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    20f0:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    20f5:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    20fa:	bf 4e 1e             	mov    di,0x1e4e
    20fd:	1e                   	push   ds
    20fe:	57                   	push   di
    20ff:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    2103:	81 c7 38 00          	add    di,0x38
    2107:	06                   	push   es
    2108:	57                   	push   di
    2109:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    210d:	06                   	push   es
    210e:	57                   	push   di
    210f:	9a 2d 4c 3a 21       	call   0x213a:0x4c2d
    2114:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    2118:	26 ff b5 96 01       	push   WORD PTR es:[di+0x196]
    211d:	26 ff b5 94 01       	push   WORD PTR es:[di+0x194]
    2122:	bf 5c 1e             	mov    di,0x1e5c
    2125:	1e                   	push   ds
    2126:	57                   	push   di
    2127:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    212b:	81 c7 38 00          	add    di,0x38
    212f:	06                   	push   es
    2130:	57                   	push   di
    2131:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    2135:	06                   	push   es
    2136:	57                   	push   di
    2137:	9a 2d 4c 62 21       	call   0x2162:0x4c2d
    213c:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    2140:	26 ff b5 9a 01       	push   WORD PTR es:[di+0x19a]
    2145:	26 ff b5 98 01       	push   WORD PTR es:[di+0x198]
    214a:	bf 6a 1e             	mov    di,0x1e6a
    214d:	1e                   	push   ds
    214e:	57                   	push   di
    214f:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    2153:	81 c7 38 00          	add    di,0x38
    2157:	06                   	push   es
    2158:	57                   	push   di
    2159:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    215d:	06                   	push   es
    215e:	57                   	push   di
    215f:	9a 2d 4c 8a 21       	call   0x218a:0x4c2d
    2164:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    2168:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    216d:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    2172:	bf 78 1e             	mov    di,0x1e78
    2175:	1e                   	push   ds
    2176:	57                   	push   di
    2177:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    217b:	81 c7 38 00          	add    di,0x38
    217f:	06                   	push   es
    2180:	57                   	push   di
    2181:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    2185:	06                   	push   es
    2186:	57                   	push   di
    2187:	9a 2d 4c b2 21       	call   0x21b2:0x4c2d
    218c:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    2190:	26 ff b5 a2 01       	push   WORD PTR es:[di+0x1a2]
    2195:	26 ff b5 a0 01       	push   WORD PTR es:[di+0x1a0]
    219a:	bf 86 1e             	mov    di,0x1e86
    219d:	1e                   	push   ds
    219e:	57                   	push   di
    219f:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    21a3:	81 c7 38 00          	add    di,0x38
    21a7:	06                   	push   es
    21a8:	57                   	push   di
    21a9:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    21ad:	06                   	push   es
    21ae:	57                   	push   di
    21af:	9a 2d 4c da 21       	call   0x21da:0x4c2d
    21b4:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    21b8:	26 ff b5 a6 01       	push   WORD PTR es:[di+0x1a6]
    21bd:	26 ff b5 a4 01       	push   WORD PTR es:[di+0x1a4]
    21c2:	bf 94 1e             	mov    di,0x1e94
    21c5:	1e                   	push   ds
    21c6:	57                   	push   di
    21c7:	c4 be 9c fe          	les    di,DWORD PTR [bp-0x164]
    21cb:	81 c7 38 00          	add    di,0x38
    21cf:	06                   	push   es
    21d0:	57                   	push   di
    21d1:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    21d5:	06                   	push   es
    21d6:	57                   	push   di
    21d7:	9a 2d 4c fd 21       	call   0x21fd:0x4c2d
    21dc:	8a 46 a5             	mov    al,BYTE PTR [bp-0x5b]
    21df:	88 46 a4             	mov    BYTE PTR [bp-0x5c],al
    21e2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    21e6:	83 c4 06             	add    sp,0x6
    21e9:	b8 0b 22             	mov    ax,0x220b
    21ec:	0e                   	push   cs
    21ed:	50                   	push   ax
    21ee:	80 7e a4 00          	cmp    BYTE PTR [bp-0x5c],0x0
    21f2:	75 0b                	jne    0x21ff
    21f4:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    21f8:	06                   	push   es
    21f9:	57                   	push   di
    21fa:	9a 7a 4e ff ff       	call   0xffff:0x4e7a
    21ff:	c4 be a0 fe          	les    di,DWORD PTR [bp-0x160]
    2203:	06                   	push   es
    2204:	57                   	push   di
    2205:	9a 1d 5f c9 22       	call   0x22c9:0x5f1d
    220a:	cb                   	retf
    220b:	80 7e a4 00          	cmp    BYTE PTR [bp-0x5c],0x0
    220f:	74 11                	je     0x2222
    2211:	bf fa 18             	mov    di,0x18fa
    2214:	1e                   	push   ds
    2215:	57                   	push   di
    2216:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2219:	06                   	push   es
    221a:	57                   	push   di
    221b:	9a 40 24 2a 22       	call   0x222a:0x2440
    2220:	eb 0a                	jmp    0x222c
    2222:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2225:	06                   	push   es
    2226:	57                   	push   di
    2227:	9a d5 18 87 22       	call   0x2287:0x18d5
    222c:	eb 42                	jmp    0x2270
    222e:	8d be a4 fd          	lea    di,[bp-0x25c]
    2232:	16                   	push   ss
    2233:	57                   	push   di
    2234:	8d 7e b0             	lea    di,[bp-0x50]
    2237:	16                   	push   ss
    2238:	57                   	push   di
    2239:	9a cd 17 46 22       	call   0x2246:0x17cd
    223e:	bf fc 1b             	mov    di,0x1bfc
    2241:	0e                   	push   cs
    2242:	57                   	push   di
    2243:	9a 4c 18 54 22       	call   0x2254:0x184c
    2248:	8d be a4 fe          	lea    di,[bp-0x15c]
    224c:	16                   	push   ss
    224d:	57                   	push   di
    224e:	68 ff 00             	push   0xff
    2251:	9a e7 17 92 22       	call   0x2292:0x17e7
    2256:	6a 30                	push   0x30
    2258:	9a c9 27 00 00       	call   0x0:0x27c9
    225d:	8d be a4 fe          	lea    di,[bp-0x15c]
    2261:	16                   	push   ss
    2262:	57                   	push   di
    2263:	6a 01                	push   0x1
    2265:	6a 04                	push   0x4
    2267:	6a 00                	push   0x0
    2269:	6a 00                	push   0x0
    226b:	9a 8a 38 d8 22       	call   0x22d8:0x388a
    2270:	c9                   	leave
    2271:	ca 0a 00             	retf   0xa
    2274:	02 44 42             	add    al,BYTE PTR [si+0x42]
    2277:	0b 3f                	or     di,WORD PTR [bx]
    2279:	3f                   	aas
    227a:	3f                   	aas
    227b:	3f                   	aas
    227c:	53                   	push   bx
    227d:	49                   	dec    cx
    227e:	4d                   	dec    bp
    227f:	53                   	push   bx
    2280:	2e 44                	cs inc sp
    2282:	42                   	inc    dx
    2283:	00 00                	add    BYTE PTR [bx+si],al
    2285:	33 23                	xor    sp,WORD PTR [bp+di]
    2287:	25 23 55             	and    ax,0x5523
    228a:	89 e5                	mov    bp,sp
    228c:	b8 04 02             	mov    ax,0x204
    228f:	9a 44 04 ed 22       	call   0x22ed:0x444
    2294:	81 ec 04 02          	sub    sp,0x204
    2298:	b8 83 22             	mov    ax,0x2283
    229b:	0e                   	push   cs
    229c:	50                   	push   ax
    229d:	55                   	push   bp
    229e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    22a2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    22a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a9:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    22ae:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    22b1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    22b4:	8d be fc fd          	lea    di,[bp-0x204]
    22b8:	16                   	push   ss
    22b9:	57                   	push   di
    22ba:	8d be fc fe          	lea    di,[bp-0x104]
    22be:	16                   	push   ss
    22bf:	57                   	push   di
    22c0:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    22c4:	06                   	push   es
    22c5:	57                   	push   di
    22c6:	9a d3 77 50 30       	call   0x3050:0x77d3
    22cb:	9a 6e 0b aa 24       	call   0x24aa:0xb6e
    22d0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22d3:	06                   	push   es
    22d4:	57                   	push   di
    22d5:	9a 19 28 de 27       	call   0x27de:0x2819
    22da:	bf 74 22             	mov    di,0x2274
    22dd:	0e                   	push   cs
    22de:	57                   	push   di
    22df:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22e2:	81 c7 37 00          	add    di,0x37
    22e6:	06                   	push   es
    22e7:	57                   	push   di
    22e8:	6a 03                	push   0x3
    22ea:	9a e7 17 02 23       	call   0x2302:0x17e7
    22ef:	bf 77 22             	mov    di,0x2277
    22f2:	0e                   	push   cs
    22f3:	57                   	push   di
    22f4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22f7:	81 c7 3b 00          	add    di,0x3b
    22fb:	06                   	push   es
    22fc:	57                   	push   di
    22fd:	6a 4f                	push   0x4f
    22ff:	9a e7 17 3b 23       	call   0x233b:0x17e7
    2304:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2307:	06                   	push   es
    2308:	57                   	push   di
    2309:	26 c4 3d             	les    di,DWORD PTR es:[di]
    230c:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    2310:	08 c0                	or     al,al
    2312:	74 13                	je     0x2327
    2314:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2317:	81 c7 3b 00          	add    di,0x3b
    231b:	06                   	push   es
    231c:	57                   	push   di
    231d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2320:	06                   	push   es
    2321:	57                   	push   di
    2322:	9a 40 24 69 23       	call   0x2369:0x2440
    2327:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    232b:	83 c4 06             	add    sp,0x6
    232e:	b8 43 23             	mov    ax,0x2343
    2331:	0e                   	push   cs
    2332:	50                   	push   ax
    2333:	bf 44 00             	mov    di,0x44
    2336:	1e                   	push   ds
    2337:	57                   	push   di
    2338:	9a b2 0e 40 23       	call   0x2340:0xeb2
    233d:	9a 08 04 49 24       	call   0x2449:0x408
    2342:	cb                   	retf
    2343:	c9                   	leave
    2344:	ca 08 00             	retf   0x8
    2347:	06                   	push   es
    2348:	4e                   	dec    si
    2349:	69 76 65 61 75       	imul   si,WORD PTR [bp+0x65],0x7561
    234e:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    2352:	ff                   	(bad)
    2353:	7f 00                	jg     0x2355
    2355:	00 0e 50 65          	add    BYTE PTR ds:0x6550,cl
    2359:	72 69                	jb     0x23c4
    235b:	6f                   	outs   dx,WORD PTR ds:[si]
    235c:	64 65 45             	fs gs inc bp
    235f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2360:	43                   	inc    bx
    2361:	6f                   	outs   dx,WORD PTR ds:[si]
    2362:	75 72                	jne    0x23d6
    2364:	73 00                	jae    0x2366
    2366:	00 7f 26             	add    BYTE PTR [bx+0x26],bh
    2369:	db 23                	(bad)  [bp+di]
    236b:	11 4e 6f             	adc    WORD PTR [bp+0x6f],cx
    236e:	6d                   	ins    WORD PTR es:[di],dx
    236f:	62 72 65             	bound  si,DWORD PTR [bp+si+0x65]
    2372:	45                   	inc    bp
    2373:	6e                   	outs   dx,BYTE PTR ds:[si]
    2374:	74 72                	je     0x23e8
    2376:	65 70 72             	gs jo  0x23eb
    2379:	69 73 65 73 00       	imul   si,WORD PTR [bp+di+0x65],0x73
    237e:	80 ff ff             	cmp    bh,0xff
    2381:	ff                   	(bad)
    2382:	7f 00                	jg     0x2384
    2384:	00 14                	add    BYTE PTR [si],dl
    2386:	44                   	inc    sp
    2387:	61                   	popa
    2388:	74 65                	je     0x23ef
    238a:	56                   	push   si
    238b:	61                   	popa
    238c:	6c                   	ins    BYTE PTR es:[di],dx
    238d:	69 64 69 74 65       	imul   sp,WORD PTR [si+0x69],0x6574
    2392:	46                   	inc    si
    2393:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
    2398:	72 73                	jb     0x240d
    239a:	14 44                	adc    al,0x44
    239c:	61                   	popa
    239d:	74 65                	je     0x2404
    239f:	46                   	inc    si
    23a0:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
    23a5:	72 73                	jb     0x241a
    23a7:	49                   	dec    cx
    23a8:	6e                   	outs   dx,BYTE PTR ds:[si]
    23a9:	76 61                	jbe    0x240c
    23ab:	6c                   	ins    BYTE PTR es:[di],dx
    23ac:	69 64 65 23 46       	imul   sp,WORD PTR [si+0x65],0x4623
    23b1:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
    23b6:	72 20                	jb     0x23d8
    23b8:	69 6e 63 6f 72       	imul   bp,WORD PTR [bp+0x63],0x726f
    23bd:	72 65                	jb     0x2424
    23bf:	63 74 20             	arpl   WORD PTR [si+0x20],si
    23c2:	28 4a 65             	sub    BYTE PTR [bp+si+0x65],cl
    23c5:	75 20                	jne    0x23e7
    23c7:	74 72                	je     0x243b
    23c9:	6f                   	outs   dx,WORD PTR ds:[si]
    23ca:	70 20                	jo     0x23ec
    23cc:	61                   	popa
    23cd:	6e                   	outs   dx,BYTE PTR ds:[si]
    23ce:	63 69 65             	arpl   WORD PTR [bx+di+0x65],bp
    23d1:	6e                   	outs   dx,BYTE PTR ds:[si]
    23d2:	29 01                	sub    WORD PTR [bx+di],ax
    23d4:	00 2f                	add    BYTE PTR [bx],ch
    23d6:	00 e7                	add    bh,ah
    23d8:	23 ab 27 e1          	and    bp,WORD PTR [bp+di-0x1ed9]
    23dc:	23 00                	and    ax,WORD PTR [bx+si]
    23de:	00 f6                	add    dh,dh
    23e0:	27                   	daa
    23e1:	eb 23                	jmp    0x2406
    23e3:	01 00                	add    WORD PTR [bx+si],ax
    23e5:	5e                   	pop    si
    23e6:	00 bd 25 0b          	add    BYTE PTR [di+0xb25],bh
    23ea:	28 73 24             	sub    BYTE PTR [bp+di+0x24],dh
    23ed:	32 55 6e             	xor    dl,BYTE PTR [di+0x6e]
    23f0:	20 6f 75             	and    BYTE PTR [bx+0x75],ch
    23f3:	20 70 6c             	and    BYTE PTR [bx+si+0x6c],dh
    23f6:	75 73                	jne    0x246b
    23f8:	69 65 75 72 73       	imul   sp,WORD PTR [di+0x75],0x7372
    23fd:	20 66 69             	and    BYTE PTR [bp+0x69],ah
    2400:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    2403:	65 72 73             	gs jb  0x2479
    2406:	20 6e 6f             	and    BYTE PTR [bp+0x6f],ch
    2409:	6e                   	outs   dx,BYTE PTR ds:[si]
    240a:	20 74 72             	and    BYTE PTR [si+0x72],dh
    240d:	6f                   	outs   dx,WORD PTR ds:[si]
    240e:	75 76                	jne    0x2486
    2410:	e9 73 20             	jmp    0x4486
    2413:	6f                   	outs   dx,WORD PTR ds:[si]
    2414:	75 20                	jne    0x2436
    2416:	69 6e 63 6f 72       	imul   bp,WORD PTR [bp+0x63],0x726f
    241b:	72 65                	jb     0x2482
    241d:	63 74 73             	arpl   WORD PTR [si+0x73],si
    2420:	1f                   	pop    ds
    2421:	20 6e 27             	and    BYTE PTR [bp+0x27],ch
    2424:	65 73 74             	gs jae 0x249b
    2427:	20 70 61             	and    BYTE PTR [bx+si+0x61],dh
    242a:	73 20                	jae    0x244c
    242c:	75 6e                	jne    0x249c
    242e:	20 6e 6f             	and    BYTE PTR [bp+0x6f],ch
    2431:	6d                   	ins    WORD PTR es:[di],dx
    2432:	20 64 65             	and    BYTE PTR [si+0x65],ah
    2435:	20 4a 65             	and    BYTE PTR [bp+si+0x65],cl
    2438:	75 20                	jne    0x245a
    243a:	76 61                	jbe    0x249d
    243c:	6c                   	ins    BYTE PTR es:[di],dx
    243d:	69 64 65 55 89       	imul   sp,WORD PTR [si+0x65],0x8955
    2442:	e5 b8                	in     ax,0xb8
    2444:	56                   	push   si
    2445:	02 9a 44 04          	add    bl,BYTE PTR [bp+si+0x444]
    2449:	85 24                	test   WORD PTR [si],sp
    244b:	81 ec 56 02          	sub    sp,0x256
    244f:	8c d3                	mov    bx,ss
    2451:	8e c3                	mov    es,bx
    2453:	8c db                	mov    bx,ds
    2455:	fc                   	cld
    2456:	8d 7e b0             	lea    di,[bp-0x50]
    2459:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    245c:	ac                   	lods   al,BYTE PTR ds:[si]
    245d:	3c 4f                	cmp    al,0x4f
    245f:	72 02                	jb     0x2463
    2461:	b0 4f                	mov    al,0x4f
    2463:	aa                   	stos   BYTE PTR es:[di],al
    2464:	91                   	xchg   cx,ax
    2465:	30 ed                	xor    ch,ch
    2467:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2469:	8e db                	mov    ds,bx
    246b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    246e:	06                   	push   es
    246f:	57                   	push   di
    2470:	9a c7 28 8f 24       	call   0x248f:0x28c7
    2475:	8d 7e b0             	lea    di,[bp-0x50]
    2478:	16                   	push   ss
    2479:	57                   	push   di
    247a:	bf fa 18             	mov    di,0x18fa
    247d:	1e                   	push   ds
    247e:	57                   	push   di
    247f:	68 ff 00             	push   0xff
    2482:	9a e7 17 42 26       	call   0x2642:0x17e7
    2487:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    248a:	06                   	push   es
    248b:	57                   	push   di
    248c:	9a 5e 14 13 28       	call   0x2813:0x145e
    2491:	a2 4a 01             	mov    ds:0x14a,al
    2494:	c6 46 af 00          	mov    BYTE PTR [bp-0x51],0x0
    2498:	80 3e 4a 01 00       	cmp    BYTE PTR ds:0x14a,0x0
    249d:	75 03                	jne    0x24a2
    249f:	e9 99 00             	jmp    0x253b
    24a2:	bf 94 1e             	mov    di,0x1e94
    24a5:	1e                   	push   ds
    24a6:	57                   	push   di
    24a7:	9a 26 0a b5 24       	call   0x24b5:0xa26
    24ac:	50                   	push   ax
    24ad:	bf 86 1e             	mov    di,0x1e86
    24b0:	1e                   	push   ds
    24b1:	57                   	push   di
    24b2:	9a 26 0a c0 24       	call   0x24c0:0xa26
    24b7:	50                   	push   ax
    24b8:	bf 78 1e             	mov    di,0x1e78
    24bb:	1e                   	push   ds
    24bc:	57                   	push   di
    24bd:	9a 26 0a cb 24       	call   0x24cb:0xa26
    24c2:	50                   	push   ax
    24c3:	bf 6a 1e             	mov    di,0x1e6a
    24c6:	1e                   	push   ds
    24c7:	57                   	push   di
    24c8:	9a 26 0a d6 24       	call   0x24d6:0xa26
    24cd:	50                   	push   ax
    24ce:	bf 5c 1e             	mov    di,0x1e5c
    24d1:	1e                   	push   ds
    24d2:	57                   	push   di
    24d3:	9a 26 0a e1 24       	call   0x24e1:0xa26
    24d8:	50                   	push   ax
    24d9:	bf 4e 1e             	mov    di,0x1e4e
    24dc:	1e                   	push   ds
    24dd:	57                   	push   di
    24de:	9a 26 0a ec 24       	call   0x24ec:0xa26
    24e3:	50                   	push   ax
    24e4:	bf 40 1e             	mov    di,0x1e40
    24e7:	1e                   	push   ds
    24e8:	57                   	push   di
    24e9:	9a 26 0a f7 24       	call   0x24f7:0xa26
    24ee:	50                   	push   ax
    24ef:	bf 32 1e             	mov    di,0x1e32
    24f2:	1e                   	push   ds
    24f3:	57                   	push   di
    24f4:	9a 26 0a 02 25       	call   0x2502:0xa26
    24f9:	50                   	push   ax
    24fa:	bf 24 1e             	mov    di,0x1e24
    24fd:	1e                   	push   ds
    24fe:	57                   	push   di
    24ff:	9a 26 0a 0d 25       	call   0x250d:0xa26
    2504:	50                   	push   ax
    2505:	bf 16 1e             	mov    di,0x1e16
    2508:	1e                   	push   ds
    2509:	57                   	push   di
    250a:	9a 26 0a 18 25       	call   0x2518:0xa26
    250f:	50                   	push   ax
    2510:	bf 08 1e             	mov    di,0x1e08
    2513:	1e                   	push   ds
    2514:	57                   	push   di
    2515:	9a 26 0a 1d 26       	call   0x261d:0xa26
    251a:	5a                   	pop    dx
    251b:	22 c2                	and    al,dl
    251d:	5a                   	pop    dx
    251e:	22 c2                	and    al,dl
    2520:	5a                   	pop    dx
    2521:	22 c2                	and    al,dl
    2523:	5a                   	pop    dx
    2524:	22 c2                	and    al,dl
    2526:	5a                   	pop    dx
    2527:	22 c2                	and    al,dl
    2529:	5a                   	pop    dx
    252a:	22 c2                	and    al,dl
    252c:	5a                   	pop    dx
    252d:	22 c2                	and    al,dl
    252f:	5a                   	pop    dx
    2530:	22 c2                	and    al,dl
    2532:	5a                   	pop    dx
    2533:	22 c2                	and    al,dl
    2535:	5a                   	pop    dx
    2536:	22 c2                	and    al,dl
    2538:	a2 4a 01             	mov    ds:0x14a,al
    253b:	80 3e 4a 01 00       	cmp    BYTE PTR ds:0x14a,0x0
    2540:	75 03                	jne    0x2545
    2542:	e9 da 02             	jmp    0x281f
    2545:	c6 06 4a 01 00       	mov    BYTE PTR ds:0x14a,0x0
    254a:	bf 08 1e             	mov    di,0x1e08
    254d:	1e                   	push   ds
    254e:	57                   	push   di
    254f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2552:	26 c4 bd 28 02       	les    di,DWORD PTR es:[di+0x228]
    2557:	06                   	push   es
    2558:	57                   	push   di
    2559:	9a 17 30 70 25       	call   0x2570:0x3017
    255e:	bf 16 1e             	mov    di,0x1e16
    2561:	1e                   	push   ds
    2562:	57                   	push   di
    2563:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2566:	26 c4 bd 2c 02       	les    di,DWORD PTR es:[di+0x22c]
    256b:	06                   	push   es
    256c:	57                   	push   di
    256d:	9a 17 30 84 25       	call   0x2584:0x3017
    2572:	bf 32 1e             	mov    di,0x1e32
    2575:	1e                   	push   ds
    2576:	57                   	push   di
    2577:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    257a:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    257f:	06                   	push   es
    2580:	57                   	push   di
    2581:	9a 17 30 98 25       	call   0x2598:0x3017
    2586:	bf 4e 1e             	mov    di,0x1e4e
    2589:	1e                   	push   ds
    258a:	57                   	push   di
    258b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    258e:	26 c4 bd ac 02       	les    di,DWORD PTR es:[di+0x2ac]
    2593:	06                   	push   es
    2594:	57                   	push   di
    2595:	9a 17 30 ca 25       	call   0x25ca:0x3017
    259a:	b8 e3 23             	mov    ax,0x23e3
    259d:	0e                   	push   cs
    259e:	50                   	push   ax
    259f:	55                   	push   bp
    25a0:	ff 36 58 18          	push   WORD PTR ds:0x1858
    25a4:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    25a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25ab:	26 c4 bd 28 02       	les    di,DWORD PTR es:[di+0x228]
    25b0:	89 be a6 fe          	mov    WORD PTR [bp-0x15a],di
    25b4:	8c 86 a8 fe          	mov    WORD PTR [bp-0x158],es
    25b8:	06                   	push   es
    25b9:	57                   	push   di
    25ba:	9a d2 31 e2 25       	call   0x25e2:0x31d2
    25bf:	6a 01                	push   0x1
    25c1:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    25c5:	06                   	push   es
    25c6:	57                   	push   di
    25c7:	9a fb 2f d7 25       	call   0x25d7:0x2ffb
    25cc:	6a 00                	push   0x0
    25ce:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    25d2:	06                   	push   es
    25d3:	57                   	push   di
    25d4:	9a d2 2e 14 26       	call   0x2614:0x2ed2
    25d9:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    25dd:	06                   	push   es
    25de:	57                   	push   di
    25df:	9a bf 31 2d 26       	call   0x262d:0x31bf
    25e4:	b8 65 23             	mov    ax,0x2365
    25e7:	0e                   	push   cs
    25e8:	50                   	push   ax
    25e9:	55                   	push   bp
    25ea:	ff 36 58 18          	push   WORD PTR ds:0x1858
    25ee:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    25f2:	c7 86 9e fe 01 00    	mov    WORD PTR [bp-0x162],0x1
    25f8:	c7 86 a0 fe 00 00    	mov    WORD PTR [bp-0x160],0x0
    25fe:	c6 86 a2 fe 00       	mov    BYTE PTR [bp-0x15e],0x0
    2603:	8d be 9e fe          	lea    di,[bp-0x162]
    2607:	16                   	push   ss
    2608:	57                   	push   di
    2609:	6a 00                	push   0x0
    260b:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    260f:	06                   	push   es
    2610:	57                   	push   di
    2611:	9a 95 28 b6 26       	call   0x26b6:0x2895
    2616:	08 c0                	or     al,al
    2618:	75 05                	jne    0x261f
    261a:	9a c3 28 09 27       	call   0x2709:0x28c3
    261f:	bf 47 23             	mov    di,0x2347
    2622:	0e                   	push   cs
    2623:	57                   	push   di
    2624:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    2628:	06                   	push   es
    2629:	57                   	push   di
    262a:	9a 9b 3b 55 26       	call   0x2655:0x3b9b
    262f:	89 c7                	mov    di,ax
    2631:	8e c2                	mov    es,dx
    2633:	06                   	push   es
    2634:	57                   	push   di
    2635:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2638:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    263c:	bf 4e 23             	mov    di,0x234e
    263f:	9a 16 04 6a 26       	call   0x266a:0x416
    2644:	a3 06 1e             	mov    ds:0x1e06,ax
    2647:	bf 56 23             	mov    di,0x2356
    264a:	0e                   	push   cs
    264b:	57                   	push   di
    264c:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    2650:	06                   	push   es
    2651:	57                   	push   di
    2652:	9a 9b 3b 88 26       	call   0x2688:0x3b9b
    2657:	89 c7                	mov    di,ax
    2659:	8e c2                	mov    es,dx
    265b:	06                   	push   es
    265c:	57                   	push   di
    265d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2660:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2664:	bf 4e 23             	mov    di,0x234e
    2667:	9a 16 04 2e 27       	call   0x272e:0x416
    266c:	a3 4c 01             	mov    ds:0x14c,ax
    266f:	c6 46 af 01          	mov    BYTE PTR [bp-0x51],0x1
    2673:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2677:	83 c4 06             	add    sp,0x6
    267a:	b8 8b 26             	mov    ax,0x268b
    267d:	0e                   	push   cs
    267e:	50                   	push   ax
    267f:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    2683:	06                   	push   es
    2684:	57                   	push   di
    2685:	9a d2 31 a9 26       	call   0x26a9:0x31d2
    268a:	cb                   	retf
    268b:	80 7e af 00          	cmp    BYTE PTR [bp-0x51],0x0
    268f:	75 03                	jne    0x2694
    2691:	e9 6e 01             	jmp    0x2802
    2694:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2697:	26 c4 bd 2c 02       	les    di,DWORD PTR es:[di+0x22c]
    269c:	89 be a6 fe          	mov    WORD PTR [bp-0x15a],di
    26a0:	8c 86 a8 fe          	mov    WORD PTR [bp-0x158],es
    26a4:	06                   	push   es
    26a5:	57                   	push   di
    26a6:	9a d2 31 ce 26       	call   0x26ce:0x31d2
    26ab:	6a 01                	push   0x1
    26ad:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    26b1:	06                   	push   es
    26b2:	57                   	push   di
    26b3:	9a fb 2f c3 26       	call   0x26c3:0x2ffb
    26b8:	6a 00                	push   0x0
    26ba:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    26be:	06                   	push   es
    26bf:	57                   	push   di
    26c0:	9a d2 2e 00 27       	call   0x2700:0x2ed2
    26c5:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    26c9:	06                   	push   es
    26ca:	57                   	push   di
    26cb:	9a bf 31 19 27       	call   0x2719:0x31bf
    26d0:	b8 dd 23             	mov    ax,0x23dd
    26d3:	0e                   	push   cs
    26d4:	50                   	push   ax
    26d5:	55                   	push   bp
    26d6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    26da:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    26de:	c7 86 9e fe 01 00    	mov    WORD PTR [bp-0x162],0x1
    26e4:	c7 86 a0 fe 00 00    	mov    WORD PTR [bp-0x160],0x0
    26ea:	c6 86 a2 fe 00       	mov    BYTE PTR [bp-0x15e],0x0
    26ef:	8d be 9e fe          	lea    di,[bp-0x162]
    26f3:	16                   	push   ss
    26f4:	57                   	push   di
    26f5:	6a 00                	push   0x0
    26f7:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    26fb:	06                   	push   es
    26fc:	57                   	push   di
    26fd:	9a 95 28 38 2a       	call   0x2a38:0x2895
    2702:	08 c0                	or     al,al
    2704:	75 05                	jne    0x270b
    2706:	9a c3 28 e3 27       	call   0x27e3:0x28c3
    270b:	bf 6b 23             	mov    di,0x236b
    270e:	0e                   	push   cs
    270f:	57                   	push   di
    2710:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    2714:	06                   	push   es
    2715:	57                   	push   di
    2716:	9a 9b 3b 4f 27       	call   0x274f:0x3b9b
    271b:	89 c7                	mov    di,ax
    271d:	8e c2                	mov    es,dx
    271f:	06                   	push   es
    2720:	57                   	push   di
    2721:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2724:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2728:	bf 7d 23             	mov    di,0x237d
    272b:	9a 16 04 c4 27       	call   0x27c4:0x416
    2730:	a3 4e 01             	mov    ds:0x14e,ax
    2733:	b8 d3 23             	mov    ax,0x23d3
    2736:	0e                   	push   cs
    2737:	50                   	push   ax
    2738:	55                   	push   bp
    2739:	ff 36 58 18          	push   WORD PTR ds:0x1858
    273d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2741:	bf 85 23             	mov    di,0x2385
    2744:	0e                   	push   cs
    2745:	57                   	push   di
    2746:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    274a:	06                   	push   es
    274b:	57                   	push   di
    274c:	9a 9b 3b 86 27       	call   0x2786:0x3b9b
    2751:	89 c7                	mov    di,ax
    2753:	8e c2                	mov    es,dx
    2755:	06                   	push   es
    2756:	57                   	push   di
    2757:	26 c4 3d             	les    di,DWORD PTR es:[di]
    275a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    275e:	89 86 aa fe          	mov    WORD PTR [bp-0x156],ax
    2762:	89 96 ac fe          	mov    WORD PTR [bp-0x154],dx
    2766:	81 be ac fe 31 01    	cmp    WORD PTR [bp-0x154],0x131
    276c:	7c 0a                	jl     0x2778
    276e:	7f 2d                	jg     0x279d
    2770:	81 be aa fe 3a cb    	cmp    WORD PTR [bp-0x156],0xcb3a
    2776:	73 25                	jae    0x279d
    2778:	bf 9a 23             	mov    di,0x239a
    277b:	0e                   	push   cs
    277c:	57                   	push   di
    277d:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    2781:	06                   	push   es
    2782:	57                   	push   di
    2783:	9a 9b 3b ff 27       	call   0x27ff:0x3b9b
    2788:	89 c7                	mov    di,ax
    278a:	8e c2                	mov    es,dx
    278c:	06                   	push   es
    278d:	57                   	push   di
    278e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2791:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2795:	89 86 aa fe          	mov    WORD PTR [bp-0x156],ax
    2799:	89 96 ac fe          	mov    WORD PTR [bp-0x154],dx
    279d:	c6 06 4a 01 01       	mov    BYTE PTR ds:0x14a,0x1
    27a2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    27a6:	83 c4 06             	add    sp,0x6
    27a9:	eb 3f                	jmp    0x27ea
    27ab:	89 86 a2 fe          	mov    WORD PTR [bp-0x15e],ax
    27af:	89 96 a4 fe          	mov    WORD PTR [bp-0x15c],dx
    27b3:	bf af 23             	mov    di,0x23af
    27b6:	0e                   	push   cs
    27b7:	57                   	push   di
    27b8:	8d be ae fe          	lea    di,[bp-0x152]
    27bc:	16                   	push   ss
    27bd:	57                   	push   di
    27be:	68 ff 00             	push   0xff
    27c1:	9a e7 17 e8 27       	call   0x27e8:0x17e7
    27c6:	6a 30                	push   0x30
    27c8:	9a 76 28 00 00       	call   0x0:0x2876
    27cd:	8d be ae fe          	lea    di,[bp-0x152]
    27d1:	16                   	push   ss
    27d2:	57                   	push   di
    27d3:	6a 02                	push   0x2
    27d5:	6a 04                	push   0x4
    27d7:	6a 00                	push   0x0
    27d9:	6a 00                	push   0x0
    27db:	9a 8a 38 8b 28       	call   0x288b:0x388a
    27e0:	9a c3 28 9b 33       	call   0x339b:0x28c3
    27e5:	9a 34 14 18 28       	call   0x2818:0x1434
    27ea:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    27ee:	83 c4 06             	add    sp,0x6
    27f1:	b8 02 28             	mov    ax,0x2802
    27f4:	0e                   	push   cs
    27f5:	50                   	push   ax
    27f6:	c4 be a6 fe          	les    di,DWORD PTR [bp-0x15a]
    27fa:	06                   	push   es
    27fb:	57                   	push   di
    27fc:	9a d2 31 e4 28       	call   0x28e4:0x31d2
    2801:	cb                   	retf
    2802:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2806:	83 c4 06             	add    sp,0x6
    2809:	eb 14                	jmp    0x281f
    280b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    280e:	06                   	push   es
    280f:	57                   	push   di
    2810:	9a c7 28 2e 28       	call   0x282e:0x28c7
    2815:	ea 85 13 1d 28       	jmp    0x281d:0x1385
    281a:	9a 34 14 47 28       	call   0x2847:0x1434
    281f:	80 3e 4a 01 00       	cmp    BYTE PTR ds:0x14a,0x0
    2824:	75 67                	jne    0x288d
    2826:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2829:	06                   	push   es
    282a:	57                   	push   di
    282b:	9a c7 28 95 28       	call   0x2895:0x28c7
    2830:	80 7e af 00          	cmp    BYTE PTR [bp-0x51],0x0
    2834:	74 15                	je     0x284b
    2836:	bf ed 23             	mov    di,0x23ed
    2839:	0e                   	push   cs
    283a:	57                   	push   di
    283b:	8d be ae fe          	lea    di,[bp-0x152]
    283f:	16                   	push   ss
    2840:	57                   	push   di
    2841:	68 ff 00             	push   0xff
    2844:	9a e7 17 59 28       	call   0x2859:0x17e7
    2849:	eb 28                	jmp    0x2873
    284b:	8d be aa fd          	lea    di,[bp-0x256]
    284f:	16                   	push   ss
    2850:	57                   	push   di
    2851:	bf fa 1a             	mov    di,0x1afa
    2854:	1e                   	push   ds
    2855:	57                   	push   di
    2856:	9a cd 17 63 28       	call   0x2863:0x17cd
    285b:	bf 20 24             	mov    di,0x2420
    285e:	0e                   	push   cs
    285f:	57                   	push   di
    2860:	9a 4c 18 71 28       	call   0x2871:0x184c
    2865:	8d be ae fe          	lea    di,[bp-0x152]
    2869:	16                   	push   ss
    286a:	57                   	push   di
    286b:	68 ff 00             	push   0xff
    286e:	9a e7 17 b7 28       	call   0x28b7:0x17e7
    2873:	6a 30                	push   0x30
    2875:	9a e3 2a 00 00       	call   0x0:0x2ae3
    287a:	8d be ae fe          	lea    di,[bp-0x152]
    287e:	16                   	push   ss
    287f:	57                   	push   di
    2880:	6a 01                	push   0x1
    2882:	6a 04                	push   0x4
    2884:	6a 00                	push   0x0
    2886:	6a 00                	push   0x0
    2888:	9a 8a 38 f8 2a       	call   0x2af8:0x388a
    288d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2890:	06                   	push   es
    2891:	57                   	push   di
    2892:	9a 71 12 9f 28       	call   0x289f:0x1271
    2897:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    289a:	06                   	push   es
    289b:	57                   	push   di
    289c:	9a c2 0d a9 28       	call   0x28a9:0xdc2
    28a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28a4:	06                   	push   es
    28a5:	57                   	push   di
    28a6:	9a a9 0f c1 28       	call   0x28c1:0xfa9
    28ab:	c9                   	leave
    28ac:	ca 08 00             	retf   0x8
    28af:	55                   	push   bp
    28b0:	89 e5                	mov    bp,sp
    28b2:	31 c0                	xor    ax,ax
    28b4:	9a 44 04 d0 28       	call   0x28d0:0x444
    28b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28bc:	06                   	push   es
    28bd:	57                   	push   di
    28be:	9a c7 28 49 29       	call   0x2949:0x28c7
    28c3:	c9                   	leave
    28c4:	ca 08 00             	retf   0x8
    28c7:	55                   	push   bp
    28c8:	89 e5                	mov    bp,sp
    28ca:	b8 08 00             	mov    ax,0x8
    28cd:	9a 44 04 03 29       	call   0x2903:0x444
    28d2:	83 ec 08             	sub    sp,0x8
    28d5:	6a 00                	push   0x0
    28d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28da:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    28df:	06                   	push   es
    28e0:	57                   	push   di
    28e1:	9a 72 26 f9 28       	call   0x28f9:0x2672
    28e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28e9:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    28ee:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    28f1:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    28f4:	06                   	push   es
    28f5:	57                   	push   di
    28f6:	9a 32 21 22 29       	call   0x2922:0x2132
    28fb:	2d 01 00             	sub    ax,0x1
    28fe:	71 05                	jno    0x2905
    2900:	9a 3e 04 61 29       	call   0x2961:0x43e
    2905:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2908:	31 c0                	xor    ax,ax
    290a:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    290d:	7f 28                	jg     0x2937
    290f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2912:	eb 03                	jmp    0x2917
    2914:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2917:	ff 76 fe             	push   WORD PTR [bp-0x2]
    291a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    291d:	06                   	push   es
    291e:	57                   	push   di
    291f:	9a 0d 21 2d 29       	call   0x292d:0x210d
    2924:	89 c7                	mov    di,ax
    2926:	8e c2                	mov    es,dx
    2928:	06                   	push   es
    2929:	57                   	push   di
    292a:	9a d2 31 2b 2a       	call   0x2a2b:0x31d2
    292f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2932:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2935:	75 dd                	jne    0x2914
    2937:	c6 06 4a 01 00       	mov    BYTE PTR ds:0x14a,0x0
    293c:	31 c0                	xor    ax,ax
    293e:	a3 4c 01             	mov    ds:0x14c,ax
    2941:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2944:	06                   	push   es
    2945:	57                   	push   di
    2946:	9a 71 12 53 29       	call   0x2953:0x1271
    294b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    294e:	06                   	push   es
    294f:	57                   	push   di
    2950:	9a c2 0d 93 29       	call   0x2993:0xdc2
    2955:	c9                   	leave
    2956:	ca 04 00             	retf   0x4
    2959:	55                   	push   bp
    295a:	89 e5                	mov    bp,sp
    295c:	31 c0                	xor    ax,ax
    295e:	9a 44 04 d7 29       	call   0x29d7:0x444
    2963:	6a 00                	push   0x0
    2965:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2968:	06                   	push   es
    2969:	57                   	push   di
    296a:	9a b8 1c 7e 29       	call   0x297e:0x1cb8
    296f:	9a 6b 0d ff ff       	call   0xffff:0xd6b
    2974:	6a 01                	push   0x1
    2976:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2979:	06                   	push   es
    297a:	57                   	push   di
    297b:	9a b8 1c e7 29       	call   0x29e7:0x1cb8
    2980:	c9                   	leave
    2981:	ca 08 00             	retf   0x8
    2984:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    2987:	6c                   	ins    BYTE PTR es:[di],dx
    2988:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    298d:	6f                   	outs   dx,WORD PTR ds:[si]
    298e:	6e                   	outs   dx,BYTE PTR ds:[si]
    298f:	00 00                	add    BYTE PTR [bx+si],al
    2991:	b0 2a                	mov    al,0x2a
    2993:	02 2b                	add    ch,BYTE PTR [bp+di]
    2995:	38 44 e9             	cmp    BYTE PTR [si-0x17],al
    2998:	63 69 73             	arpl   WORD PTR [bx+di+0x73],bp
    299b:	69 6f 6e 73 20       	imul   bp,WORD PTR [bx+0x6e],0x2073
    29a0:	41                   	inc    cx
    29a1:	6e                   	outs   dx,BYTE PTR ds:[si]
    29a2:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
    29a7:	75 72                	jne    0x2a1b
    29a9:	20 64 65             	and    BYTE PTR [si+0x65],ah
    29ac:	20 6c 61             	and    BYTE PTR [si+0x61],ch
    29af:	20 70 e9             	and    BYTE PTR [bx+si-0x17],dh
    29b2:	72 69                	jb     0x2a1d
    29b4:	6f                   	outs   dx,WORD PTR ds:[si]
    29b5:	64 65 20 65 6e       	fs and BYTE PTR gs:[di+0x6e],ah
    29ba:	20 63 6f             	and    BYTE PTR [bp+di+0x6f],ah
    29bd:	75 72                	jne    0x2a31
    29bf:	73 2c                	jae    0x29ed
    29c1:	20 6e 6f             	and    BYTE PTR [bp+0x6f],ch
    29c4:	6e                   	outs   dx,BYTE PTR ds:[si]
    29c5:	20 76 61             	and    BYTE PTR [bp+0x61],dh
    29c8:	6c                   	ins    BYTE PTR es:[di],dx
    29c9:	69 64 e9 65 73       	imul   sp,WORD PTR [si-0x17],0x7365
    29ce:	55                   	push   bp
    29cf:	89 e5                	mov    bp,sp
    29d1:	b8 0e 01             	mov    ax,0x10e
    29d4:	9a 44 04 09 2a       	call   0x2a09:0x444
    29d9:	81 ec 0e 01          	sub    sp,0x10e
    29dd:	6a 00                	push   0x0
    29df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29e2:	06                   	push   es
    29e3:	57                   	push   di
    29e4:	9a b8 1c 0e 2b       	call   0x2b0e:0x1cb8
    29e9:	80 3e 42 00 00       	cmp    BYTE PTR ds:0x42,0x0
    29ee:	74 08                	je     0x29f8
    29f0:	9a 2b 35 e1 2d       	call   0x2de1:0x352b
    29f5:	e9 0c 01             	jmp    0x2b04
    29f8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    29fb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    29fe:	bf 94 00             	mov    di,0x94
    2a01:	b8 82 2e             	mov    ax,0x2e82
    2a04:	50                   	push   ax
    2a05:	57                   	push   di
    2a06:	9a 55 22 de 2a       	call   0x2ade:0x2255
    2a0b:	08 c0                	or     al,al
    2a0d:	75 03                	jne    0x2a12
    2a0f:	e9 f2 00             	jmp    0x2b04
    2a12:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2a16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a19:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    2a1e:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2a22:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2a26:	06                   	push   es
    2a27:	57                   	push   di
    2a28:	9a d2 31 50 2a       	call   0x2a50:0x31d2
    2a2d:	6a 01                	push   0x1
    2a2f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2a33:	06                   	push   es
    2a34:	57                   	push   di
    2a35:	9a fb 2f 45 2a       	call   0x2a45:0x2ffb
    2a3a:	6a 00                	push   0x0
    2a3c:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2a40:	06                   	push   es
    2a41:	57                   	push   di
    2a42:	9a d2 2e 82 2a       	call   0x2a82:0x2ed2
    2a47:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2a4b:	06                   	push   es
    2a4c:	57                   	push   di
    2a4d:	9a bf 31 92 2a       	call   0x2a92:0x31bf
    2a52:	b8 8f 29             	mov    ax,0x298f
    2a55:	0e                   	push   cs
    2a56:	50                   	push   ax
    2a57:	55                   	push   bp
    2a58:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2a5c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2a60:	a1 4c 01             	mov    ax,ds:0x14c
    2a63:	99                   	cwd
    2a64:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2a68:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    2a6c:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2a71:	8d be f2 fe          	lea    di,[bp-0x10e]
    2a75:	16                   	push   ss
    2a76:	57                   	push   di
    2a77:	6a 00                	push   0x0
    2a79:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2a7d:	06                   	push   es
    2a7e:	57                   	push   di
    2a7f:	9a 95 28 f4 2e       	call   0x2ef4:0x2895
    2a84:	bf 84 29             	mov    di,0x2984
    2a87:	0e                   	push   cs
    2a88:	57                   	push   di
    2a89:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2a8d:	06                   	push   es
    2a8e:	57                   	push   di
    2a8f:	9a 9b 3b b9 2a       	call   0x2ab9:0x3b9b
    2a94:	89 c7                	mov    di,ax
    2a96:	8e c2                	mov    es,dx
    2a98:	06                   	push   es
    2a99:	57                   	push   di
    2a9a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a9d:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    2aa1:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2aa4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2aa8:	83 c4 06             	add    sp,0x6
    2aab:	b8 bc 2a             	mov    ax,0x2abc
    2aae:	0e                   	push   cs
    2aaf:	50                   	push   ax
    2ab0:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2ab4:	06                   	push   es
    2ab5:	57                   	push   di
    2ab6:	9a d2 31 e7 2e       	call   0x2ee7:0x31d2
    2abb:	cb                   	retf
    2abc:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2ac0:	74 0b                	je     0x2acd
    2ac2:	ff 36 50 01          	push   WORD PTR ds:0x150
    2ac6:	9a ea 0b 39 2b       	call   0x2b39:0xbea
    2acb:	eb 2d                	jmp    0x2afa
    2acd:	bf 95 29             	mov    di,0x2995
    2ad0:	0e                   	push   cs
    2ad1:	57                   	push   di
    2ad2:	8d be fe fe          	lea    di,[bp-0x102]
    2ad6:	16                   	push   ss
    2ad7:	57                   	push   di
    2ad8:	68 ff 00             	push   0xff
    2adb:	9a e7 17 1c 2b       	call   0x2b1c:0x17e7
    2ae0:	6a 30                	push   0x30
    2ae2:	9a 2c 2d 00 00       	call   0x0:0x2d2c
    2ae7:	8d be fe fe          	lea    di,[bp-0x102]
    2aeb:	16                   	push   ss
    2aec:	57                   	push   di
    2aed:	6a 01                	push   0x1
    2aef:	6a 04                	push   0x4
    2af1:	6a 00                	push   0x0
    2af3:	6a 00                	push   0x0
    2af5:	9a 8a 38 b3 2f       	call   0x2fb3:0x388a
    2afa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2afd:	06                   	push   es
    2afe:	57                   	push   di
    2aff:	9a a9 0f 97 2c       	call   0x2c97:0xfa9
    2b04:	6a 01                	push   0x1
    2b06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b09:	06                   	push   es
    2b0a:	57                   	push   di
    2b0b:	9a b8 1c 28 2b       	call   0x2b28:0x1cb8
    2b10:	c9                   	leave
    2b11:	ca 08 00             	retf   0x8
    2b14:	55                   	push   bp
    2b15:	89 e5                	mov    bp,sp
    2b17:	31 c0                	xor    ax,ax
    2b19:	9a 44 04 54 2b       	call   0x2b54:0x444
    2b1e:	6a 00                	push   0x0
    2b20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b23:	06                   	push   es
    2b24:	57                   	push   di
    2b25:	9a b8 1c 45 2b       	call   0x2b45:0x1cb8
    2b2a:	ff 36 50 01          	push   WORD PTR ds:0x150
    2b2e:	ff 36 4c 01          	push   WORD PTR ds:0x14c
    2b32:	ff 36 50 01          	push   WORD PTR ds:0x150
    2b36:	9a a1 0c 84 2f       	call   0x2f84:0xca1
    2b3b:	6a 01                	push   0x1
    2b3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b40:	06                   	push   es
    2b41:	57                   	push   di
    2b42:	9a b8 1c d5 2d       	call   0x2dd5:0x1cb8
    2b47:	c9                   	leave
    2b48:	ca 08 00             	retf   0x8
    2b4b:	55                   	push   bp
    2b4c:	89 e5                	mov    bp,sp
    2b4e:	b8 06 00             	mov    ax,0x6
    2b51:	9a 44 04 78 2c       	call   0x2c78:0x444
    2b56:	83 ec 06             	sub    sp,0x6
    2b59:	83 3e 48 01 01       	cmp    WORD PTR ds:0x148,0x1
    2b5e:	b0 00                	mov    al,0x0
    2b60:	7c 01                	jl     0x2b63
    2b62:	40                   	inc    ax
    2b63:	8a d8                	mov    bl,al
    2b65:	a1 46 01             	mov    ax,ds:0x146
    2b68:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    2b6c:	b0 00                	mov    al,0x0
    2b6e:	7f 01                	jg     0x2b71
    2b70:	40                   	inc    ax
    2b71:	8a c8                	mov    cl,al
    2b73:	83 3e 46 01 00       	cmp    WORD PTR ds:0x146,0x0
    2b78:	b0 00                	mov    al,0x0
    2b7a:	7c 01                	jl     0x2b7d
    2b7c:	40                   	inc    ax
    2b7d:	8a d0                	mov    dl,al
    2b7f:	83 3e 44 01 00       	cmp    WORD PTR ds:0x144,0x0
    2b84:	b0 00                	mov    al,0x0
    2b86:	7e 01                	jle    0x2b89
    2b88:	40                   	inc    ax
    2b89:	22 c2                	and    al,dl
    2b8b:	22 c1                	and    al,cl
    2b8d:	22 c3                	and    al,bl
    2b8f:	8a d0                	mov    dl,al
    2b91:	a1 48 01             	mov    ax,ds:0x148
    2b94:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    2b98:	b0 00                	mov    al,0x0
    2b9a:	7d 01                	jge    0x2b9d
    2b9c:	40                   	inc    ax
    2b9d:	22 c2                	and    al,dl
    2b9f:	08 c0                	or     al,al
    2ba1:	75 03                	jne    0x2ba6
    2ba3:	e9 b4 00             	jmp    0x2c5a
    2ba6:	a1 44 01             	mov    ax,ds:0x144
    2ba9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2bac:	a1 48 01             	mov    ax,ds:0x148
    2baf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2bb2:	a1 46 01             	mov    ax,ds:0x146
    2bb5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2bb8:	c7 06 44 01 ff ff    	mov    WORD PTR ds:0x144,0xffff
    2bbe:	c7 06 46 01 ff ff    	mov    WORD PTR ds:0x146,0xffff
    2bc4:	c7 06 48 01 ff ff    	mov    WORD PTR ds:0x148,0xffff
    2bca:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2bcd:	3d 0b 00             	cmp    ax,0xb
    2bd0:	75 0a                	jne    0x2bdc
    2bd2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2bd5:	9a 4a 0c 36 31       	call   0x3136:0xc4a
    2bda:	eb 7b                	jmp    0x2c57
    2bdc:	3d 0c 00             	cmp    ax,0xc
    2bdf:	75 0a                	jne    0x2beb
    2be1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2be4:	9a a8 0c 61 31       	call   0x3161:0xca8
    2be9:	eb 6c                	jmp    0x2c57
    2beb:	3d 15 00             	cmp    ax,0x15
    2bee:	75 0d                	jne    0x2bfd
    2bf0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2bf3:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2bf6:	9a c3 22 8d 2c       	call   0x2c8d:0x22c3
    2bfb:	eb 5a                	jmp    0x2c57
    2bfd:	3d 16 00             	cmp    ax,0x16
    2c00:	75 0d                	jne    0x2c0f
    2c02:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2c05:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c08:	9a e8 1c ba 2c       	call   0x2cba:0x1ce8
    2c0d:	eb 48                	jmp    0x2c57
    2c0f:	3d 17 00             	cmp    ax,0x17
    2c12:	75 0d                	jne    0x2c21
    2c14:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2c17:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c1a:	9a f7 0d e7 2c       	call   0x2ce7:0xdf7
    2c1f:	eb 36                	jmp    0x2c57
    2c21:	3d 18 00             	cmp    ax,0x18
    2c24:	75 0d                	jne    0x2c33
    2c26:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2c29:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c2c:	9a 1a 13 1b 2d       	call   0x2d1b:0x131a
    2c31:	eb 24                	jmp    0x2c57
    2c33:	3d 19 00             	cmp    ax,0x19
    2c36:	75 0d                	jne    0x2c45
    2c38:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2c3b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c3e:	9a 30 14 58 2d       	call   0x2d58:0x1430
    2c43:	eb 12                	jmp    0x2c57
    2c45:	3d 1a 00             	cmp    ax,0x1a
    2c48:	75 0d                	jne    0x2c57
    2c4a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2c4d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c50:	9a 39 14 8e 2d       	call   0x2d8e:0x1439
    2c55:	eb 00                	jmp    0x2c57
    2c57:	e9 ff fe             	jmp    0x2b59
    2c5a:	c7 06 44 01 ff ff    	mov    WORD PTR ds:0x144,0xffff
    2c60:	c7 06 46 01 ff ff    	mov    WORD PTR ds:0x146,0xffff
    2c66:	c7 06 48 01 ff ff    	mov    WORD PTR ds:0x148,0xffff
    2c6c:	c9                   	leave
    2c6d:	ca 04 00             	retf   0x4
    2c70:	55                   	push   bp
    2c71:	89 e5                	mov    bp,sp
    2c73:	31 c0                	xor    ax,ax
    2c75:	9a 44 04 85 2c       	call   0x2c85:0x444
    2c7a:	a1 4c 01             	mov    ax,ds:0x14c
    2c7d:	2d 01 00             	sub    ax,0x1
    2c80:	71 05                	jno    0x2c87
    2c82:	9a 3e 04 a5 2c       	call   0x2ca5:0x43e
    2c87:	50                   	push   ax
    2c88:	6a 01                	push   0x1
    2c8a:	9a c3 22 ff ff       	call   0xffff:0x22c3
    2c8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c92:	06                   	push   es
    2c93:	57                   	push   di
    2c94:	9a 4b 2b c4 2c       	call   0x2cc4:0x2b4b
    2c99:	c9                   	leave
    2c9a:	ca 08 00             	retf   0x8
    2c9d:	55                   	push   bp
    2c9e:	89 e5                	mov    bp,sp
    2ca0:	31 c0                	xor    ax,ax
    2ca2:	9a 44 04 b2 2c       	call   0x2cb2:0x444
    2ca7:	a1 4c 01             	mov    ax,ds:0x14c
    2caa:	2d 01 00             	sub    ax,0x1
    2cad:	71 05                	jno    0x2cb4
    2caf:	9a 3e 04 d2 2c       	call   0x2cd2:0x43e
    2cb4:	50                   	push   ax
    2cb5:	6a 01                	push   0x1
    2cb7:	9a e8 1c ff ff       	call   0xffff:0x1ce8
    2cbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cbf:	06                   	push   es
    2cc0:	57                   	push   di
    2cc1:	9a 4b 2b f1 2c       	call   0x2cf1:0x2b4b
    2cc6:	c9                   	leave
    2cc7:	ca 08 00             	retf   0x8
    2cca:	55                   	push   bp
    2ccb:	89 e5                	mov    bp,sp
    2ccd:	31 c0                	xor    ax,ax
    2ccf:	9a 44 04 df 2c       	call   0x2cdf:0x444
    2cd4:	a1 4c 01             	mov    ax,ds:0x14c
    2cd7:	2d 01 00             	sub    ax,0x1
    2cda:	71 05                	jno    0x2ce1
    2cdc:	9a 3e 04 ff 2c       	call   0x2cff:0x43e
    2ce1:	50                   	push   ax
    2ce2:	6a 01                	push   0x1
    2ce4:	9a f7 0d ff ff       	call   0xffff:0xdf7
    2ce9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cec:	06                   	push   es
    2ced:	57                   	push   di
    2cee:	9a 4b 2b 25 2d       	call   0x2d25:0x2b4b
    2cf3:	c9                   	leave
    2cf4:	ca 08 00             	retf   0x8
    2cf7:	55                   	push   bp
    2cf8:	89 e5                	mov    bp,sp
    2cfa:	31 c0                	xor    ax,ax
    2cfc:	9a 44 04 13 2d       	call   0x2d13:0x444
    2d01:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    2d06:	7c 21                	jl     0x2d29
    2d08:	a1 4c 01             	mov    ax,ds:0x14c
    2d0b:	2d 01 00             	sub    ax,0x1
    2d0e:	71 05                	jno    0x2d15
    2d10:	9a 3e 04 3c 2d       	call   0x2d3c:0x43e
    2d15:	50                   	push   ax
    2d16:	6a 01                	push   0x1
    2d18:	9a 1a 13 ff ff       	call   0xffff:0x131a
    2d1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d20:	06                   	push   es
    2d21:	57                   	push   di
    2d22:	9a 4b 2b 62 2d       	call   0x2d62:0x2b4b
    2d27:	eb 07                	jmp    0x2d30
    2d29:	6a 30                	push   0x30
    2d2b:	9a 69 2d 00 00       	call   0x0:0x2d69
    2d30:	c9                   	leave
    2d31:	ca 08 00             	retf   0x8
    2d34:	55                   	push   bp
    2d35:	89 e5                	mov    bp,sp
    2d37:	31 c0                	xor    ax,ax
    2d39:	9a 44 04 50 2d       	call   0x2d50:0x444
    2d3e:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    2d43:	7c 21                	jl     0x2d66
    2d45:	a1 4c 01             	mov    ax,ds:0x14c
    2d48:	2d 01 00             	sub    ax,0x1
    2d4b:	71 05                	jno    0x2d52
    2d4d:	9a 3e 04 79 2d       	call   0x2d79:0x43e
    2d52:	50                   	push   ax
    2d53:	6a 01                	push   0x1
    2d55:	9a 30 14 ff ff       	call   0xffff:0x1430
    2d5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d5d:	06                   	push   es
    2d5e:	57                   	push   di
    2d5f:	9a 4b 2b 98 2d       	call   0x2d98:0x2b4b
    2d64:	eb 07                	jmp    0x2d6d
    2d66:	6a 30                	push   0x30
    2d68:	9a 9e 2f 00 00       	call   0x0:0x2f9e
    2d6d:	c9                   	leave
    2d6e:	ca 08 00             	retf   0x8
    2d71:	55                   	push   bp
    2d72:	89 e5                	mov    bp,sp
    2d74:	31 c0                	xor    ax,ax
    2d76:	9a 44 04 86 2d       	call   0x2d86:0x444
    2d7b:	a1 4c 01             	mov    ax,ds:0x14c
    2d7e:	2d 01 00             	sub    ax,0x1
    2d81:	71 05                	jno    0x2d88
    2d83:	9a 3e 04 a6 2d       	call   0x2da6:0x43e
    2d88:	50                   	push   ax
    2d89:	6a 01                	push   0x1
    2d8b:	9a 39 14 ff ff       	call   0xffff:0x1439
    2d90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d93:	06                   	push   es
    2d94:	57                   	push   di
    2d95:	9a 4b 2b f2 2d       	call   0x2df2:0x2b4b
    2d9a:	c9                   	leave
    2d9b:	ca 08 00             	retf   0x8
    2d9e:	55                   	push   bp
    2d9f:	89 e5                	mov    bp,sp
    2da1:	31 c0                	xor    ax,ax
    2da3:	9a 44 04 b3 2d       	call   0x2db3:0x444
    2da8:	a1 4c 01             	mov    ax,ds:0x14c
    2dab:	2d 01 00             	sub    ax,0x1
    2dae:	71 05                	jno    0x2db5
    2db0:	9a 3e 04 c9 2d       	call   0x2dc9:0x43e
    2db5:	50                   	push   ax
    2db6:	6a 01                	push   0x1
    2db8:	9a 64 07 ff ff       	call   0xffff:0x764
    2dbd:	c9                   	leave
    2dbe:	ca 08 00             	retf   0x8
    2dc1:	55                   	push   bp
    2dc2:	89 e5                	mov    bp,sp
    2dc4:	31 c0                	xor    ax,ax
    2dc6:	9a 44 04 57 2e       	call   0x2e57:0x444
    2dcb:	6a 00                	push   0x0
    2dcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dd0:	06                   	push   es
    2dd1:	57                   	push   di
    2dd2:	9a b8 1c fe 2d       	call   0x2dfe:0x1cb8
    2dd7:	80 3e 42 00 00       	cmp    BYTE PTR ds:0x42,0x0
    2ddc:	74 07                	je     0x2de5
    2dde:	9a 2b 35 73 2e       	call   0x2e73:0x352b
    2de3:	eb 0f                	jmp    0x2df4
    2de5:	9a b7 0d ec 2f       	call   0x2fec:0xdb7
    2dea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ded:	06                   	push   es
    2dee:	57                   	push   di
    2def:	9a a9 0f 13 2e       	call   0x2e13:0xfa9
    2df4:	6a 01                	push   0x1
    2df6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2df9:	06                   	push   es
    2dfa:	57                   	push   di
    2dfb:	9a b8 1c 67 2e       	call   0x2e67:0x1cb8
    2e00:	c9                   	leave
    2e01:	ca 08 00             	retf   0x8
    2e04:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    2e07:	6c                   	ins    BYTE PTR es:[di],dx
    2e08:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    2e0d:	6f                   	outs   dx,WORD PTR ds:[si]
    2e0e:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e0f:	00 00                	add    BYTE PTR [bx+si],al
    2e11:	6c                   	ins    BYTE PTR es:[di],dx
    2e12:	2f                   	das
    2e13:	bd 2f 38             	mov    bp,0x382f
    2e16:	44                   	inc    sp
    2e17:	e9 63 69             	jmp    0x977d
    2e1a:	73 69                	jae    0x2e85
    2e1c:	6f                   	outs   dx,WORD PTR ds:[si]
    2e1d:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e1e:	73 20                	jae    0x2e40
    2e20:	41                   	inc    cx
    2e21:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e22:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
    2e27:	75 72                	jne    0x2e9b
    2e29:	20 64 65             	and    BYTE PTR [si+0x65],ah
    2e2c:	20 6c 61             	and    BYTE PTR [si+0x61],ch
    2e2f:	20 70 e9             	and    BYTE PTR [bx+si-0x17],dh
    2e32:	72 69                	jb     0x2e9d
    2e34:	6f                   	outs   dx,WORD PTR ds:[si]
    2e35:	64 65 20 65 6e       	fs and BYTE PTR gs:[di+0x6e],ah
    2e3a:	20 63 6f             	and    BYTE PTR [bp+di+0x6f],ah
    2e3d:	75 72                	jne    0x2eb1
    2e3f:	73 2c                	jae    0x2e6d
    2e41:	20 6e 6f             	and    BYTE PTR [bp+0x6f],ch
    2e44:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e45:	20 76 61             	and    BYTE PTR [bp+0x61],dh
    2e48:	6c                   	ins    BYTE PTR es:[di],dx
    2e49:	69 64 e9 65 73       	imul   sp,WORD PTR [si-0x17],0x7365
    2e4e:	55                   	push   bp
    2e4f:	89 e5                	mov    bp,sp
    2e51:	b8 10 01             	mov    ax,0x110
    2e54:	9a 44 04 89 2e       	call   0x2e89:0x444
    2e59:	81 ec 10 01          	sub    sp,0x110
    2e5d:	6a 00                	push   0x0
    2e5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e62:	06                   	push   es
    2e63:	57                   	push   di
    2e64:	9a b8 1c c9 2f       	call   0x2fc9:0x1cb8
    2e69:	80 3e 42 00 00       	cmp    BYTE PTR ds:0x42,0x0
    2e6e:	74 08                	je     0x2e78
    2e70:	9a 2b 35 1e 30       	call   0x301e:0x352b
    2e75:	e9 47 01             	jmp    0x2fbf
    2e78:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2e7b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2e7e:	bf 94 00             	mov    di,0x94
    2e81:	b8 9c 2e             	mov    ax,0x2e9c
    2e84:	50                   	push   ax
    2e85:	57                   	push   di
    2e86:	9a 55 22 a3 2e       	call   0x2ea3:0x2255
    2e8b:	08 c0                	or     al,al
    2e8d:	75 03                	jne    0x2e92
    2e8f:	e9 2d 01             	jmp    0x2fbf
    2e92:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2e95:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2e98:	bf 94 00             	mov    di,0x94
    2e9b:	b8 b4 2e             	mov    ax,0x2eb4
    2e9e:	50                   	push   ax
    2e9f:	57                   	push   di
    2ea0:	9a 73 22 be 2e       	call   0x2ebe:0x2273
    2ea5:	52                   	push   dx
    2ea6:	50                   	push   ax
    2ea7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eaa:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2eaf:	06                   	push   es
    2eb0:	57                   	push   di
    2eb1:	9a 2b 16 ff ff       	call   0xffff:0x162b
    2eb6:	2d 01 00             	sub    ax,0x1
    2eb9:	71 05                	jno    0x2ec0
    2ebb:	9a 3e 04 99 2f       	call   0x2f99:0x43e
    2ec0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2ec3:	83 7e fc ff          	cmp    WORD PTR [bp-0x4],0xffff
    2ec7:	75 05                	jne    0x2ece
    2ec9:	31 c0                	xor    ax,ax
    2ecb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2ece:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2ed2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed5:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    2eda:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
    2ede:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
    2ee2:	06                   	push   es
    2ee3:	57                   	push   di
    2ee4:	9a d2 31 0c 2f       	call   0x2f0c:0x31d2
    2ee9:	6a 01                	push   0x1
    2eeb:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2eef:	06                   	push   es
    2ef0:	57                   	push   di
    2ef1:	9a fb 2f 01 2f       	call   0x2f01:0x2ffb
    2ef6:	6a 00                	push   0x0
    2ef8:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2efc:	06                   	push   es
    2efd:	57                   	push   di
    2efe:	9a d2 2e 3e 2f       	call   0x2f3e:0x2ed2
    2f03:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2f07:	06                   	push   es
    2f08:	57                   	push   di
    2f09:	9a bf 31 4e 2f       	call   0x2f4e:0x31bf
    2f0e:	b8 0f 2e             	mov    ax,0x2e0f
    2f11:	0e                   	push   cs
    2f12:	50                   	push   ax
    2f13:	55                   	push   bp
    2f14:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2f18:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2f1c:	a1 4c 01             	mov    ax,ds:0x14c
    2f1f:	99                   	cwd
    2f20:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    2f24:	89 96 f2 fe          	mov    WORD PTR [bp-0x10e],dx
    2f28:	c6 86 f4 fe 00       	mov    BYTE PTR [bp-0x10c],0x0
    2f2d:	8d be f0 fe          	lea    di,[bp-0x110]
    2f31:	16                   	push   ss
    2f32:	57                   	push   di
    2f33:	6a 00                	push   0x0
    2f35:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2f39:	06                   	push   es
    2f3a:	57                   	push   di
    2f3b:	9a 95 28 f0 31       	call   0x31f0:0x2895
    2f40:	bf 04 2e             	mov    di,0x2e04
    2f43:	0e                   	push   cs
    2f44:	57                   	push   di
    2f45:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2f49:	06                   	push   es
    2f4a:	57                   	push   di
    2f4b:	9a 9b 3b 75 2f       	call   0x2f75:0x3b9b
    2f50:	89 c7                	mov    di,ax
    2f52:	8e c2                	mov    es,dx
    2f54:	06                   	push   es
    2f55:	57                   	push   di
    2f56:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f59:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    2f5d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2f60:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2f64:	83 c4 06             	add    sp,0x6
    2f67:	b8 78 2f             	mov    ax,0x2f78
    2f6a:	0e                   	push   cs
    2f6b:	50                   	push   ax
    2f6c:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    2f70:	06                   	push   es
    2f71:	57                   	push   di
    2f72:	9a d2 31 e3 31       	call   0x31e3:0x31d2
    2f77:	cb                   	retf
    2f78:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2f7c:	74 0a                	je     0x2f88
    2f7e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2f81:	9a ea 0b b2 30       	call   0x30b2:0xbea
    2f86:	eb 2d                	jmp    0x2fb5
    2f88:	bf 15 2e             	mov    di,0x2e15
    2f8b:	0e                   	push   cs
    2f8c:	57                   	push   di
    2f8d:	8d be fc fe          	lea    di,[bp-0x104]
    2f91:	16                   	push   ss
    2f92:	57                   	push   di
    2f93:	68 ff 00             	push   0xff
    2f96:	9a e7 17 d7 2f       	call   0x2fd7:0x17e7
    2f9b:	6a 30                	push   0x30
    2f9d:	9a 9b 32 00 00       	call   0x0:0x329b
    2fa2:	8d be fc fe          	lea    di,[bp-0x104]
    2fa6:	16                   	push   ss
    2fa7:	57                   	push   di
    2fa8:	6a 01                	push   0x1
    2faa:	6a 04                	push   0x4
    2fac:	6a 00                	push   0x0
    2fae:	6a 00                	push   0x0
    2fb0:	9a 8a 38 b0 32       	call   0x32b0:0x388a
    2fb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fb8:	06                   	push   es
    2fb9:	57                   	push   di
    2fba:	9a a9 0f 2f 30       	call   0x302f:0xfa9
    2fbf:	6a 01                	push   0x1
    2fc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc4:	06                   	push   es
    2fc5:	57                   	push   di
    2fc6:	9a b8 1c e3 2f       	call   0x2fe3:0x1cb8
    2fcb:	c9                   	leave
    2fcc:	ca 08 00             	retf   0x8
    2fcf:	55                   	push   bp
    2fd0:	89 e5                	mov    bp,sp
    2fd2:	31 c0                	xor    ax,ax
    2fd4:	9a 44 04 06 30       	call   0x3006:0x444
    2fd9:	6a 00                	push   0x0
    2fdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fde:	06                   	push   es
    2fdf:	57                   	push   di
    2fe0:	9a b8 1c f8 2f       	call   0x2ff8:0x1cb8
    2fe5:	ff 36 4c 01          	push   WORD PTR ds:0x14c
    2fe9:	9a 44 0e ff ff       	call   0xffff:0xe44
    2fee:	6a 01                	push   0x1
    2ff0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ff3:	06                   	push   es
    2ff4:	57                   	push   di
    2ff5:	9a b8 1c 12 30       	call   0x3012:0x1cb8
    2ffa:	c9                   	leave
    2ffb:	ca 08 00             	retf   0x8
    2ffe:	55                   	push   bp
    2fff:	89 e5                	mov    bp,sp
    3001:	31 c0                	xor    ax,ax
    3003:	9a 44 04 6a 30       	call   0x306a:0x444
    3008:	6a 00                	push   0x0
    300a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    300d:	06                   	push   es
    300e:	57                   	push   di
    300f:	9a b8 1c 5c 30       	call   0x305c:0x1cb8
    3014:	80 3e 42 00 00       	cmp    BYTE PTR ds:0x42,0x0
    3019:	74 07                	je     0x3022
    301b:	9a 2b 35 e4 30       	call   0x30e4:0x352b
    3020:	eb 30                	jmp    0x3052
    3022:	9a d9 03 ff ff       	call   0xffff:0x3d9
    3027:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    302a:	06                   	push   es
    302b:	57                   	push   di
    302c:	9a 71 12 39 30       	call   0x3039:0x1271
    3031:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3034:	06                   	push   es
    3035:	57                   	push   di
    3036:	9a c2 0d 43 30       	call   0x3043:0xdc2
    303b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    303e:	06                   	push   es
    303f:	57                   	push   di
    3040:	9a a9 0f f5 30       	call   0x30f5:0xfa9
    3045:	6a fe                	push   0xfffe
    3047:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    304b:	06                   	push   es
    304c:	57                   	push   di
    304d:	9a a9 63 30 33       	call   0x3330:0x63a9
    3052:	6a 01                	push   0x1
    3054:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3057:	06                   	push   es
    3058:	57                   	push   di
    3059:	9a b8 1c 76 30       	call   0x3076:0x1cb8
    305e:	c9                   	leave
    305f:	ca 08 00             	retf   0x8
    3062:	55                   	push   bp
    3063:	89 e5                	mov    bp,sp
    3065:	31 c0                	xor    ax,ax
    3067:	9a 44 04 95 30       	call   0x3095:0x444
    306c:	6a 00                	push   0x0
    306e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3071:	06                   	push   es
    3072:	57                   	push   di
    3073:	9a b8 1c 87 30       	call   0x3087:0x1cb8
    3078:	9a 42 09 ff ff       	call   0xffff:0x942
    307d:	6a 01                	push   0x1
    307f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3082:	06                   	push   es
    3083:	57                   	push   di
    3084:	9a b8 1c a1 30       	call   0x30a1:0x1cb8
    3089:	c9                   	leave
    308a:	ca 08 00             	retf   0x8
    308d:	55                   	push   bp
    308e:	89 e5                	mov    bp,sp
    3090:	31 c0                	xor    ax,ax
    3092:	9a 44 04 cc 30       	call   0x30cc:0x444
    3097:	6a 00                	push   0x0
    3099:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    309c:	06                   	push   es
    309d:	57                   	push   di
    309e:	9a b8 1c be 30       	call   0x30be:0x1cb8
    30a3:	ff 36 50 01          	push   WORD PTR ds:0x150
    30a7:	ff 36 4c 01          	push   WORD PTR ds:0x14c
    30ab:	ff 36 50 01          	push   WORD PTR ds:0x150
    30af:	9a a1 0c ff ff       	call   0xffff:0xca1
    30b4:	6a 01                	push   0x1
    30b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30b9:	06                   	push   es
    30ba:	57                   	push   di
    30bb:	9a b8 1c d8 30       	call   0x30d8:0x1cb8
    30c0:	c9                   	leave
    30c1:	ca 08 00             	retf   0x8
    30c4:	55                   	push   bp
    30c5:	89 e5                	mov    bp,sp
    30c7:	31 c0                	xor    ax,ax
    30c9:	9a 44 04 23 31       	call   0x3123:0x444
    30ce:	6a 00                	push   0x0
    30d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30d3:	06                   	push   es
    30d4:	57                   	push   di
    30d5:	9a b8 1c 15 31       	call   0x3115:0x1cb8
    30da:	80 3e 42 00 00       	cmp    BYTE PTR ds:0x42,0x0
    30df:	74 07                	je     0x30e8
    30e1:	9a 2b 35 eb 30       	call   0x30eb:0x352b
    30e6:	eb 23                	jmp    0x310b
    30e8:	9a f4 10 dd 32       	call   0x32dd:0x10f4
    30ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30f0:	06                   	push   es
    30f1:	57                   	push   di
    30f2:	9a 71 12 ff 30       	call   0x30ff:0x1271
    30f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30fa:	06                   	push   es
    30fb:	57                   	push   di
    30fc:	9a c2 0d 09 31       	call   0x3109:0xdc2
    3101:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3104:	06                   	push   es
    3105:	57                   	push   di
    3106:	9a a9 0f 40 31       	call   0x3140:0xfa9
    310b:	6a 01                	push   0x1
    310d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3110:	06                   	push   es
    3111:	57                   	push   di
    3112:	9a b8 1c f1 3a       	call   0x3af1:0x1cb8
    3117:	c9                   	leave
    3118:	ca 08 00             	retf   0x8
    311b:	55                   	push   bp
    311c:	89 e5                	mov    bp,sp
    311e:	31 c0                	xor    ax,ax
    3120:	9a 44 04 30 31       	call   0x3130:0x444
    3125:	a1 4c 01             	mov    ax,ds:0x14c
    3128:	2d 01 00             	sub    ax,0x1
    312b:	71 05                	jno    0x3132
    312d:	9a 3e 04 4e 31       	call   0x314e:0x43e
    3132:	50                   	push   ax
    3133:	9a 4a 0c ff ff       	call   0xffff:0xc4a
    3138:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    313b:	06                   	push   es
    313c:	57                   	push   di
    313d:	9a 4b 2b 6b 31       	call   0x316b:0x2b4b
    3142:	c9                   	leave
    3143:	ca 08 00             	retf   0x8
    3146:	55                   	push   bp
    3147:	89 e5                	mov    bp,sp
    3149:	31 c0                	xor    ax,ax
    314b:	9a 44 04 5b 31       	call   0x315b:0x444
    3150:	a1 4c 01             	mov    ax,ds:0x14c
    3153:	2d 01 00             	sub    ax,0x1
    3156:	71 05                	jno    0x315d
    3158:	9a 3e 04 c4 31       	call   0x31c4:0x43e
    315d:	50                   	push   ax
    315e:	9a a8 0c ff ff       	call   0xffff:0xca8
    3163:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3166:	06                   	push   es
    3167:	57                   	push   di
    3168:	9a 4b 2b 80 31       	call   0x3180:0x2b4b
    316d:	c9                   	leave
    316e:	ca 08 00             	retf   0x8
    3171:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    3174:	6c                   	ins    BYTE PTR es:[di],dx
    3175:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    317a:	6f                   	outs   dx,WORD PTR ds:[si]
    317b:	6e                   	outs   dx,BYTE PTR ds:[si]
    317c:	00 00                	add    BYTE PTR [bx+si],al
    317e:	68 32 9f             	push   0x9f32
    3181:	33 38                	xor    di,WORD PTR [bx+si]
    3183:	44                   	inc    sp
    3184:	e9 63 69             	jmp    0x9aea
    3187:	73 69                	jae    0x31f2
    3189:	6f                   	outs   dx,WORD PTR ds:[si]
    318a:	6e                   	outs   dx,BYTE PTR ds:[si]
    318b:	73 20                	jae    0x31ad
    318d:	41                   	inc    cx
    318e:	6e                   	outs   dx,BYTE PTR ds:[si]
    318f:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
    3194:	75 72                	jne    0x3208
    3196:	20 64 65             	and    BYTE PTR [si+0x65],ah
    3199:	20 6c 61             	and    BYTE PTR [si+0x61],ch
    319c:	20 70 e9             	and    BYTE PTR [bx+si-0x17],dh
    319f:	72 69                	jb     0x320a
    31a1:	6f                   	outs   dx,WORD PTR ds:[si]
    31a2:	64 65 20 65 6e       	fs and BYTE PTR gs:[di+0x6e],ah
    31a7:	20 63 6f             	and    BYTE PTR [bp+di+0x6f],ah
    31aa:	75 72                	jne    0x321e
    31ac:	73 2c                	jae    0x31da
    31ae:	20 6e 6f             	and    BYTE PTR [bp+0x6f],ch
    31b1:	6e                   	outs   dx,BYTE PTR ds:[si]
    31b2:	20 76 61             	and    BYTE PTR [bp+0x61],dh
    31b5:	6c                   	ins    BYTE PTR es:[di],dx
    31b6:	69 64 e9 65 73       	imul   sp,WORD PTR [si-0x17],0x7365
    31bb:	55                   	push   bp
    31bc:	89 e5                	mov    bp,sp
    31be:	b8 0e 01             	mov    ax,0x10e
    31c1:	9a 44 04 96 32       	call   0x3296:0x444
    31c6:	81 ec 0e 01          	sub    sp,0x10e
    31ca:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    31ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31d1:	26 c4 bd 34 02       	les    di,DWORD PTR es:[di+0x234]
    31d6:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    31da:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    31de:	06                   	push   es
    31df:	57                   	push   di
    31e0:	9a d2 31 08 32       	call   0x3208:0x31d2
    31e5:	6a 01                	push   0x1
    31e7:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    31eb:	06                   	push   es
    31ec:	57                   	push   di
    31ed:	9a fb 2f fd 31       	call   0x31fd:0x2ffb
    31f2:	6a 00                	push   0x0
    31f4:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    31f8:	06                   	push   es
    31f9:	57                   	push   di
    31fa:	9a d2 2e 3a 32       	call   0x323a:0x2ed2
    31ff:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3203:	06                   	push   es
    3204:	57                   	push   di
    3205:	9a bf 31 4a 32       	call   0x324a:0x31bf
    320a:	b8 7c 31             	mov    ax,0x317c
    320d:	0e                   	push   cs
    320e:	50                   	push   ax
    320f:	55                   	push   bp
    3210:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3214:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3218:	a1 4c 01             	mov    ax,ds:0x14c
    321b:	99                   	cwd
    321c:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    3220:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    3224:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    3229:	8d be f2 fe          	lea    di,[bp-0x10e]
    322d:	16                   	push   ss
    322e:	57                   	push   di
    322f:	6a 00                	push   0x0
    3231:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3235:	06                   	push   es
    3236:	57                   	push   di
    3237:	9a 95 28 ff ff       	call   0xffff:0x2895
    323c:	bf 71 31             	mov    di,0x3171
    323f:	0e                   	push   cs
    3240:	57                   	push   di
    3241:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    3245:	06                   	push   es
    3246:	57                   	push   di
    3247:	9a 9b 3b 71 32       	call   0x3271:0x3b9b
    324c:	89 c7                	mov    di,ax
    324e:	8e c2                	mov    es,dx
    3250:	06                   	push   es
    3251:	57                   	push   di
    3252:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3255:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    3259:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    325c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3260:	83 c4 06             	add    sp,0x6
    3263:	b8 74 32             	mov    ax,0x3274
    3266:	0e                   	push   cs
    3267:	50                   	push   ax
    3268:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    326c:	06                   	push   es
    326d:	57                   	push   di
    326e:	9a d2 31 ff ff       	call   0xffff:0x31d2
    3273:	cb                   	retf
    3274:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    3278:	74 0b                	je     0x3285
    327a:	ff 36 4c 01          	push   WORD PTR ds:0x14c
    327e:	9a 87 1c ca 32       	call   0x32ca:0x1c87
    3283:	eb 47                	jmp    0x32cc
    3285:	bf 82 31             	mov    di,0x3182
    3288:	0e                   	push   cs
    3289:	57                   	push   di
    328a:	8d be fe fe          	lea    di,[bp-0x102]
    328e:	16                   	push   ss
    328f:	57                   	push   di
    3290:	68 ff 00             	push   0xff
    3293:	9a e7 17 c4 32       	call   0x32c4:0x17e7
    3298:	6a 30                	push   0x30
    329a:	9a e1 36 00 00       	call   0x0:0x36e1
    329f:	8d be fe fe          	lea    di,[bp-0x102]
    32a3:	16                   	push   ss
    32a4:	57                   	push   di
    32a5:	6a 02                	push   0x2
    32a7:	6a 04                	push   0x4
    32a9:	6a 00                	push   0x0
    32ab:	6a 00                	push   0x0
    32ad:	9a 8a 38 f6 36       	call   0x36f6:0x388a
    32b2:	83 3e 4c 01 01       	cmp    WORD PTR ds:0x14c,0x1
    32b7:	7e 13                	jle    0x32cc
    32b9:	a1 4c 01             	mov    ax,ds:0x14c
    32bc:	2d 01 00             	sub    ax,0x1
    32bf:	71 05                	jno    0x32c6
    32c1:	9a 3e 04 d8 32       	call   0x32d8:0x43e
    32c6:	50                   	push   ax
    32c7:	9a 87 1c ff ff       	call   0xffff:0x1c87
    32cc:	c9                   	leave
    32cd:	ca 08 00             	retf   0x8
    32d0:	55                   	push   bp
    32d1:	89 e5                	mov    bp,sp
    32d3:	31 c0                	xor    ax,ax
    32d5:	9a 44 04 eb 32       	call   0x32eb:0x444
    32da:	9a 3e 20 0a 33       	call   0x330a:0x203e
    32df:	c9                   	leave
    32e0:	ca 08 00             	retf   0x8
    32e3:	55                   	push   bp
    32e4:	89 e5                	mov    bp,sp
    32e6:	31 c0                	xor    ax,ax
    32e8:	9a 44 04 fe 32       	call   0x32fe:0x444
    32ed:	9a 87 10 ff ff       	call   0xffff:0x1087
    32f2:	c9                   	leave
    32f3:	ca 08 00             	retf   0x8
    32f6:	55                   	push   bp
    32f7:	89 e5                	mov    bp,sp
    32f9:	31 c0                	xor    ax,ax
    32fb:	9a 44 04 1f 33       	call   0x331f:0x444
    3300:	80 3e 42 00 00       	cmp    BYTE PTR ds:0x42,0x0
    3305:	74 07                	je     0x330e
    3307:	9a 2b 35 11 33       	call   0x3311:0x352b
    330c:	eb 05                	jmp    0x3313
    330e:	9a 11 04 ff ff       	call   0xffff:0x411
    3313:	c9                   	leave
    3314:	ca 08 00             	retf   0x8
    3317:	55                   	push   bp
    3318:	89 e5                	mov    bp,sp
    331a:	31 c0                	xor    ax,ax
    331c:	9a 44 04 3e 33       	call   0x333e:0x444
    3321:	6a 03                	push   0x3
    3323:	6a 00                	push   0x0
    3325:	6a 00                	push   0x0
    3327:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    332b:	06                   	push   es
    332c:	57                   	push   di
    332d:	9a b2 77 51 33       	call   0x3351:0x77b2
    3332:	c9                   	leave
    3333:	ca 08 00             	retf   0x8
    3336:	55                   	push   bp
    3337:	89 e5                	mov    bp,sp
    3339:	31 c0                	xor    ax,ax
    333b:	9a 44 04 5f 33       	call   0x335f:0x444
    3340:	68 05 01             	push   0x105
    3343:	bf 70 01             	mov    di,0x170
    3346:	1e                   	push   ds
    3347:	57                   	push   di
    3348:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    334c:	06                   	push   es
    334d:	57                   	push   di
    334e:	9a b2 77 70 33       	call   0x3370:0x77b2
    3353:	c9                   	leave
    3354:	ca 08 00             	retf   0x8
    3357:	55                   	push   bp
    3358:	89 e5                	mov    bp,sp
    335a:	31 c0                	xor    ax,ax
    335c:	9a 44 04 7f 33       	call   0x337f:0x444
    3361:	6a 04                	push   0x4
    3363:	6a 00                	push   0x0
    3365:	6a 00                	push   0x0
    3367:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    336b:	06                   	push   es
    336c:	57                   	push   di
    336d:	9a b2 77 8d 33       	call   0x338d:0x77b2
    3372:	c9                   	leave
    3373:	ca 08 00             	retf   0x8
    3376:	55                   	push   bp
    3377:	89 e5                	mov    bp,sp
    3379:	b8 04 00             	mov    ax,0x4
    337c:	9a 44 04 cd 34       	call   0x34cd:0x444
    3381:	83 ec 04             	sub    sp,0x4
    3384:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    3388:	06                   	push   es
    3389:	57                   	push   di
    338a:	9a 45 5d dc 34       	call   0x34dc:0x5d45
    338f:	c9                   	leave
    3390:	ca 08 00             	retf   0x8
    3393:	00 80 3b 45          	add    BYTE PTR [bx+si+0x453b],al
    3397:	02 00                	add    al,BYTE PTR [bx+si]
    3399:	86 01                	xchg   BYTE PTR [bx+di],al
    339b:	a3 33 58             	mov    ds:0x5833,ax
    339e:	35 a7 33             	xor    ax,0x33a7
    33a1:	d8 00                	fadd   DWORD PTR [bx+si]
    33a3:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    33a4:	34 67                	xor    al,0x67
    33a6:	35 a8 34             	xor    ax,0x34a8
    33a9:	00 40 1c             	add    BYTE PTR [bx+si+0x1c],al
    33ac:	46                   	inc    si
    33ad:	00 00                	add    BYTE PTR [bx+si],al
    33af:	00 00                	add    BYTE PTR [bx+si],al
    33b1:	ff                   	(bad)
    33b2:	ff 00                	inc    WORD PTR [bx+si]
    33b4:	00 37                	add    BYTE PTR [bx],dh
    33b6:	45                   	inc    bp
    33b7:	72 72                	jb     0x342b
    33b9:	65 75 72             	gs jne 0x342e
    33bc:	20 64 27             	and    BYTE PTR [si+0x27],ah
    33bf:	61                   	popa
    33c0:	63 63 e8             	arpl   WORD PTR [bp+di-0x18],sp
    33c3:	73 20                	jae    0x33e5
    33c5:	61                   	popa
    33c6:	75 20                	jne    0x33e8
    33c8:	66 69 63 68 69 65 72 	imul   esp,DWORD PTR [bp+di+0x68],0x20726569
    33cf:	20 
    33d0:	53                   	push   bx
    33d1:	69 6d 73 74 72       	imul   bp,WORD PTR [di+0x73],0x7274
    33d6:	61                   	popa
    33d7:	31 2e 44 4c          	xor    WORD PTR ds:0x4c44,bp
    33db:	4c                   	dec    sp
    33dc:	20 28                	and    BYTE PTR [bx+si],ch
    33de:	43                   	inc    bx
    33df:	6f                   	outs   dx,WORD PTR ds:[si]
    33e0:	64 65 20 64 27       	fs and BYTE PTR gs:[si+0x27],ah
    33e5:	65 72 72             	gs jb  0x345a
    33e8:	65 75 72             	gs jne 0x345d
    33eb:	3a 20                	cmp    ah,BYTE PTR [bx+si]
    33ed:	01 29                	add    WORD PTR [bx+di],bp
    33ef:	01 0d                	add    WORD PTR [di],cx
    33f1:	2b 43 65             	sub    ax,WORD PTR [bp+di+0x65]
    33f4:	20 66 69             	and    BYTE PTR [bp+0x69],ah
    33f7:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    33fa:	65 72 20             	gs jb  0x341d
    33fd:	65 73 74             	gs jae 0x3474
    3400:	20 70 65             	and    BYTE PTR [bx+si+0x65],dh
    3403:	75 74                	jne    0x3479
    3405:	2d ea 74             	sub    ax,0x74ea
    3408:	72 65                	jb     0x346f
    340a:	20 61 6c             	and    BYTE PTR [bx+di+0x6c],ah
    340d:	74 e9                	je     0x33f8
    340f:	72 e9                	jb     0x33fa
    3411:	20 6f 75             	and    BYTE PTR [bx+0x75],ch
    3414:	20 64 e9             	and    BYTE PTR [si-0x17],ah
    3417:	74 72                	je     0x348b
    3419:	75 69                	jne    0x3484
    341b:	74 2e                	je     0x344b
    341d:	3a 53 69             	cmp    dl,BYTE PTR [bp+di+0x69]
    3420:	20 62 65             	and    BYTE PTR [bp+si+0x65],ah
    3423:	73 6f                	jae    0x3494
    3425:	69 6e 2c 20 6c       	imul   bp,WORD PTR [bp+0x2c],0x6c20
    342a:	65 20 72 65          	and    BYTE PTR gs:[bp+si+0x65],dh
    342e:	63 6f 70             	arpl   WORD PTR [bx+0x70],bp
    3431:	69 65 72 20 64       	imul   sp,WORD PTR [di+0x72],0x6420
    3436:	65 70 75             	gs jo  0x34ae
    3439:	69 73 20 6c 61       	imul   si,WORD PTR [bp+di+0x20],0x616c
    343e:	20 64 69             	and    BYTE PTR [si+0x69],ah
    3441:	73 71                	jae    0x34b4
    3443:	75 65                	jne    0x34aa
    3445:	74 74                	je     0x34bb
    3447:	65 20 64 27          	and    BYTE PTR gs:[si+0x27],ah
    344b:	69 6e 73 74 61       	imul   bp,WORD PTR [bp+0x73],0x6174
    3450:	6c                   	ins    BYTE PTR es:[di],dx
    3451:	6c                   	ins    BYTE PTR es:[di],dx
    3452:	61                   	popa
    3453:	74 69                	je     0x34be
    3455:	6f                   	outs   dx,WORD PTR ds:[si]
    3456:	6e                   	outs   dx,BYTE PTR ds:[si]
    3457:	3a 0a                	cmp    cl,BYTE PTR [bp+si]
    3459:	20 20                	and    BYTE PTR [bx+si],ah
    345b:	43                   	inc    bx
    345c:	6f                   	outs   dx,WORD PTR ds:[si]
    345d:	70 79                	jo     0x34d8
    345f:	20 61 3a             	and    BYTE PTR [bx+di+0x3a],ah
    3462:	5c                   	pop    sp
    3463:	0c 53                	or     al,0x53
    3465:	69 6d 73 74 72       	imul   bp,WORD PTR [di+0x73],0x7274
    346a:	61                   	popa
    346b:	31 2e 44 4c          	xor    WORD PTR ds:0x4c44,bp
    346f:	4c                   	dec    sp
    3470:	01 20                	add    WORD PTR [bx+si],sp
    3472:	08 53 69             	or     BYTE PTR [bp+di+0x69],dl
    3475:	6d                   	ins    WORD PTR es:[di],dx
    3476:	73 74                	jae    0x34ec
    3478:	72 61                	jb     0x34db
    347a:	74 20                	je     0x349c
    347c:	20 70 61             	and    BYTE PTR [bx+si+0x61],dh
    347f:	73 73                	jae    0x34f4
    3481:	65 20 65 6e          	and    BYTE PTR gs:[di+0x6e],ah
    3485:	20 6d 6f             	and    BYTE PTR [di+0x6f],ch
    3488:	64 65 20 64 e9       	fs and BYTE PTR gs:[si-0x17],ah
    348d:	6d                   	ins    WORD PTR es:[di],dx
    348e:	6f                   	outs   dx,WORD PTR ds:[si]
    348f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3490:	73 74                	jae    0x3506
    3492:	72 61                	jb     0x34f5
    3494:	74 69                	je     0x34ff
    3496:	6f                   	outs   dx,WORD PTR ds:[si]
    3497:	6e                   	outs   dx,BYTE PTR ds:[si]
    3498:	20 2e 2e 2e          	and    BYTE PTR ds:0x2e2e,ch
    349c:	00 80 3b 45          	add    BYTE PTR [bx+si+0x453b],al
    34a0:	02 00                	add    al,BYTE PTR [bx+si]
    34a2:	86 01                	xchg   BYTE PTR [bx+di],al
    34a4:	ac                   	lods   al,BYTE PTR ds:[si]
    34a5:	34 5e                	xor    al,0x5e
    34a7:	37                   	aaa
    34a8:	b0 34                	mov    al,0x34
    34aa:	d8 00                	fadd   DWORD PTR [bx+si]
    34ac:	26 36 6d             	es ss ins WORD PTR es:[di],dx
    34af:	37                   	aaa
    34b0:	c2 34 00             	ret    0x34
    34b3:	40                   	inc    ax
    34b4:	1c 46                	sbb    al,0x46
    34b6:	00 00                	add    BYTE PTR [bx+si],al
    34b8:	00 00                	add    BYTE PTR [bx+si],al
    34ba:	ff                   	(bad)
    34bb:	ff 00                	inc    WORD PTR [bx+si]
    34bd:	00 00                	add    BYTE PTR [bx+si],al
    34bf:	00 04                	add    BYTE PTR [si],al
    34c1:	37                   	aaa
    34c2:	0f 3a 55             	(bad)
    34c5:	89 e5                	mov    bp,sp
    34c7:	b8 1e 06             	mov    ax,0x61e
    34ca:	9a 44 04 46 35       	call   0x3546:0x444
    34cf:	81 ec 1e 06          	sub    sp,0x61e
    34d3:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    34d7:	06                   	push   es
    34d8:	57                   	push   di
    34d9:	9a 03 73 9c 36       	call   0x369c:0x7303
    34de:	c6 06 42 00 01       	mov    BYTE PTR ds:0x42,0x1
    34e3:	c7 86 e4 fe ff ff    	mov    WORD PTR [bp-0x11c],0xffff
    34e9:	c7 86 e6 fe ff ff    	mov    WORD PTR [bp-0x11a],0xffff
    34ef:	9a 94 35 ac 3a       	call   0x3aac:0x3594
    34f4:	b8 97 33             	mov    ax,0x3397
    34f7:	0e                   	push   cs
    34f8:	50                   	push   ax
    34f9:	55                   	push   bp
    34fa:	ff 36 58 18          	push   WORD PTR ds:0x1858
    34fe:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3502:	bf 2f 21             	mov    di,0x212f
    3505:	1e                   	push   ds
    3506:	57                   	push   di
    3507:	bf 2f 22             	mov    di,0x222f
    350a:	1e                   	push   ds
    350b:	57                   	push   di
    350c:	bf 2f 23             	mov    di,0x232f
    350f:	1e                   	push   ds
    3510:	57                   	push   di
    3511:	9a 52 07 ee 35       	call   0x35ee:0x752
    3516:	89 86 e0 fd          	mov    WORD PTR [bp-0x220],ax
    351a:	89 96 e2 fd          	mov    WORD PTR [bp-0x21e],dx
    351e:	9b db 86 e0 fd       	fild   DWORD PTR [bp-0x220]
    3523:	9b dd 9e f8 fe       	fstp   QWORD PTR [bp-0x108]
    3528:	90                   	nop
    3529:	9b 9b db 06 52 05    	fild   DWORD PTR ds:0x552
    352f:	9b dd 9e f0 fe       	fstp   QWORD PTR [bp-0x110]
    3534:	90                   	nop
    3535:	9b 9b dd 86 f8 fe    	fld    QWORD PTR [bp-0x108]
    353b:	9b dc a6 f0 fe       	fsub   QWORD PTR [bp-0x110]
    3540:	9b d9 e1             	fabs
    3543:	9a 41 10 77 35       	call   0x3577:0x1041
    3548:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    354d:	90                   	nop
    354e:	9b                   	fwait
    354f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3553:	83 c4 06             	add    sp,0x6
    3556:	eb 21                	jmp    0x3579
    3558:	9b 2e d9 06 93 33    	fld    DWORD PTR cs:0x3393
    355e:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    3563:	90                   	nop
    3564:	9b                   	fwait
    3565:	eb 0d                	jmp    0x3574
    3567:	9b 2e d9 06 93 33    	fld    DWORD PTR cs:0x3393
    356d:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    3572:	90                   	nop
    3573:	9b                   	fwait
    3574:	9a 34 14 a7 35       	call   0x35a7:0x1434
    3579:	9b dd 86 e8 fe       	fld    QWORD PTR [bp-0x118]
    357e:	9b 2e d8 1e a9 33    	fcomp  DWORD PTR cs:0x33a9
    3584:	9b dd be e2 fd       	fstsw  WORD PTR [bp-0x21e]
    3589:	90                   	nop
    358a:	9b                   	fwait
    358b:	8a a6 e3 fd          	mov    ah,BYTE PTR [bp-0x21d]
    358f:	9e                   	sahf
    3590:	76 0d                	jbe    0x359f
    3592:	9b 2e d9 06 a9 33    	fld    DWORD PTR cs:0x33a9
    3598:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    359d:	90                   	nop
    359e:	9b 9b dd 86 e8 fe    	fld    QWORD PTR [bp-0x118]
    35a4:	9a 0e 10 af 35       	call   0x35af:0x100e
    35a9:	bf ad 33             	mov    di,0x33ad
    35ac:	9a 16 04 13 36       	call   0x3613:0x416
    35b1:	50                   	push   ax
    35b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35b5:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
    35ba:	06                   	push   es
    35bb:	57                   	push   di
    35bc:	9a 6a 27 e2 37       	call   0x37e2:0x276a
    35c1:	9b dd 86 e8 fe       	fld    QWORD PTR [bp-0x118]
    35c6:	9b 2e d8 1e ad 33    	fcomp  DWORD PTR cs:0x33ad
    35cc:	9b dd be e2 fd       	fstsw  WORD PTR [bp-0x21e]
    35d1:	90                   	nop
    35d2:	9b                   	fwait
    35d3:	8a a6 e3 fd          	mov    ah,BYTE PTR [bp-0x21d]
    35d7:	9e                   	sahf
    35d8:	74 03                	je     0x35dd
    35da:	e9 3c 02             	jmp    0x3819
    35dd:	b8 be 34             	mov    ax,0x34be
    35e0:	0e                   	push   cs
    35e1:	50                   	push   ax
    35e2:	55                   	push   bp
    35e3:	ff 36 58 18          	push   WORD PTR ds:0x1858
    35e7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    35eb:	9a 1e 00 1a 37       	call   0x371a:0x1e
    35f0:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    35f4:	89 96 e6 fe          	mov    WORD PTR [bp-0x11a],dx
    35f8:	8b 86 e4 fe          	mov    ax,WORD PTR [bp-0x11c]
    35fc:	0b 86 e6 fe          	or     ax,WORD PTR [bp-0x11a]
    3600:	75 03                	jne    0x3605
    3602:	e9 f3 00             	jmp    0x36f8
    3605:	8d be e2 fb          	lea    di,[bp-0x41e]
    3609:	16                   	push   ss
    360a:	57                   	push   di
    360b:	bf b5 33             	mov    di,0x33b5
    360e:	0e                   	push   cs
    360f:	57                   	push   di
    3610:	9a cd 17 2b 36       	call   0x362b:0x17cd
    3615:	8d be e2 fc          	lea    di,[bp-0x31e]
    3619:	16                   	push   ss
    361a:	57                   	push   di
    361b:	ff b6 e6 fe          	push   WORD PTR [bp-0x11a]
    361f:	ff b6 e4 fe          	push   WORD PTR [bp-0x11c]
    3623:	9a a9 08 a1 36       	call   0x36a1:0x8a9
    3628:	9a 4c 18 35 36       	call   0x3635:0x184c
    362d:	bf ed 33             	mov    di,0x33ed
    3630:	0e                   	push   cs
    3631:	57                   	push   di
    3632:	9a 4c 18 3f 36       	call   0x363f:0x184c
    3637:	bf ef 33             	mov    di,0x33ef
    363a:	0e                   	push   cs
    363b:	57                   	push   di
    363c:	9a 4c 18 49 36       	call   0x3649:0x184c
    3641:	bf f1 33             	mov    di,0x33f1
    3644:	0e                   	push   cs
    3645:	57                   	push   di
    3646:	9a 4c 18 53 36       	call   0x3653:0x184c
    364b:	bf ef 33             	mov    di,0x33ef
    364e:	0e                   	push   cs
    364f:	57                   	push   di
    3650:	9a 4c 18 5d 36       	call   0x365d:0x184c
    3655:	bf 1d 34             	mov    di,0x341d
    3658:	0e                   	push   cs
    3659:	57                   	push   di
    365a:	9a 4c 18 67 36       	call   0x3667:0x184c
    365f:	bf ef 33             	mov    di,0x33ef
    3662:	0e                   	push   cs
    3663:	57                   	push   di
    3664:	9a 4c 18 71 36       	call   0x3671:0x184c
    3669:	bf 58 34             	mov    di,0x3458
    366c:	0e                   	push   cs
    366d:	57                   	push   di
    366e:	9a 4c 18 7b 36       	call   0x367b:0x184c
    3673:	bf 63 34             	mov    di,0x3463
    3676:	0e                   	push   cs
    3677:	57                   	push   di
    3678:	9a 4c 18 85 36       	call   0x3685:0x184c
    367d:	bf 70 34             	mov    di,0x3470
    3680:	0e                   	push   cs
    3681:	57                   	push   di
    3682:	9a 4c 18 a6 36       	call   0x36a6:0x184c
    3687:	8d be e2 f9          	lea    di,[bp-0x61e]
    368b:	16                   	push   ss
    368c:	57                   	push   di
    368d:	8d be e2 fa          	lea    di,[bp-0x51e]
    3691:	16                   	push   ss
    3692:	57                   	push   di
    3693:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3697:	06                   	push   es
    3698:	57                   	push   di
    3699:	9a d3 77 07 39       	call   0x3907:0x77d3
    369e:	9a 6e 0b 47 39       	call   0x3947:0xb6e
    36a3:	9a 4c 18 b0 36       	call   0x36b0:0x184c
    36a8:	bf ef 33             	mov    di,0x33ef
    36ab:	0e                   	push   cs
    36ac:	57                   	push   di
    36ad:	9a 4c 18 ba 36       	call   0x36ba:0x184c
    36b2:	bf ef 33             	mov    di,0x33ef
    36b5:	0e                   	push   cs
    36b6:	57                   	push   di
    36b7:	9a 4c 18 c4 36       	call   0x36c4:0x184c
    36bc:	bf 72 34             	mov    di,0x3472
    36bf:	0e                   	push   cs
    36c0:	57                   	push   di
    36c1:	9a 4c 18 ce 36       	call   0x36ce:0x184c
    36c6:	bf 7b 34             	mov    di,0x347b
    36c9:	0e                   	push   cs
    36ca:	57                   	push   di
    36cb:	9a 4c 18 dc 36       	call   0x36dc:0x184c
    36d0:	8d be 00 ff          	lea    di,[bp-0x100]
    36d4:	16                   	push   ss
    36d5:	57                   	push   di
    36d6:	68 ff 00             	push   0xff
    36d9:	9a e7 17 4c 37       	call   0x374c:0x17e7
    36de:	6a 30                	push   0x30
    36e0:	9a 80 39 00 00       	call   0x0:0x3980
    36e5:	8d be 00 ff          	lea    di,[bp-0x100]
    36e9:	16                   	push   ss
    36ea:	57                   	push   di
    36eb:	6a 00                	push   0x0
    36ed:	6a 04                	push   0x4
    36ef:	6a 00                	push   0x0
    36f1:	6a 00                	push   0x0
    36f3:	9a 8a 38 6d 39       	call   0x396d:0x388a
    36f8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    36fc:	83 c4 06             	add    sp,0x6
    36ff:	b8 19 38             	mov    ax,0x3819
    3702:	0e                   	push   cs
    3703:	50                   	push   ax
    3704:	b8 a0 34             	mov    ax,0x34a0
    3707:	0e                   	push   cs
    3708:	50                   	push   ax
    3709:	55                   	push   bp
    370a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    370e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3712:	bf 0c 20             	mov    di,0x200c
    3715:	1e                   	push   ds
    3716:	57                   	push   di
    3717:	9a c8 01 ff ff       	call   0xffff:0x1c8
    371c:	89 86 de fd          	mov    WORD PTR [bp-0x222],ax
    3720:	89 96 e0 fd          	mov    WORD PTR [bp-0x220],dx
    3724:	9b db 86 de fd       	fild   DWORD PTR [bp-0x222]
    3729:	9b dd 9e f8 fe       	fstp   QWORD PTR [bp-0x108]
    372e:	90                   	nop
    372f:	9b 9b db 06 4e 05    	fild   DWORD PTR ds:0x54e
    3735:	9b dd 9e f0 fe       	fstp   QWORD PTR [bp-0x110]
    373a:	90                   	nop
    373b:	9b 9b dd 86 f8 fe    	fld    QWORD PTR [bp-0x108]
    3741:	9b dc a6 f0 fe       	fsub   QWORD PTR [bp-0x110]
    3746:	9b d9 e1             	fabs
    3749:	9a 41 10 7d 37       	call   0x377d:0x1041
    374e:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    3753:	90                   	nop
    3754:	9b                   	fwait
    3755:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3759:	83 c4 06             	add    sp,0x6
    375c:	eb 21                	jmp    0x377f
    375e:	9b 2e d9 06 9c 34    	fld    DWORD PTR cs:0x349c
    3764:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    3769:	90                   	nop
    376a:	9b                   	fwait
    376b:	eb 0d                	jmp    0x377a
    376d:	9b 2e d9 06 9c 34    	fld    DWORD PTR cs:0x349c
    3773:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    3778:	90                   	nop
    3779:	9b                   	fwait
    377a:	9a 34 14 ad 37       	call   0x37ad:0x1434
    377f:	9b dd 86 e8 fe       	fld    QWORD PTR [bp-0x118]
    3784:	9b 2e d8 1e b2 34    	fcomp  DWORD PTR cs:0x34b2
    378a:	9b dd be e0 fd       	fstsw  WORD PTR [bp-0x220]
    378f:	90                   	nop
    3790:	9b                   	fwait
    3791:	8a a6 e1 fd          	mov    ah,BYTE PTR [bp-0x21f]
    3795:	9e                   	sahf
    3796:	76 0d                	jbe    0x37a5
    3798:	9b 2e d9 06 b2 34    	fld    DWORD PTR cs:0x34b2
    379e:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    37a3:	90                   	nop
    37a4:	9b 9b dd 86 e8 fe    	fld    QWORD PTR [bp-0x118]
    37aa:	9a 0e 10 ca 37       	call   0x37ca:0x100e
    37af:	8b c8                	mov    cx,ax
    37b1:	8b da                	mov    bx,dx
    37b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37b6:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
    37bb:	26 8b 45 1c          	mov    ax,WORD PTR es:[di+0x1c]
    37bf:	31 d2                	xor    dx,dx
    37c1:	03 c1                	add    ax,cx
    37c3:	13 d3                	adc    dx,bx
    37c5:	71 05                	jno    0x37cc
    37c7:	9a 3e 04 d2 37       	call   0x37d2:0x43e
    37cc:	bf b6 34             	mov    di,0x34b6
    37cf:	9a 16 04 34 38       	call   0x3834:0x416
    37d4:	50                   	push   ax
    37d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37d8:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
    37dd:	06                   	push   es
    37de:	57                   	push   di
    37df:	9a 6a 27 39 3c       	call   0x3c39:0x276a
    37e4:	8b 86 e4 fe          	mov    ax,WORD PTR [bp-0x11c]
    37e8:	0b 86 e6 fe          	or     ax,WORD PTR [bp-0x11a]
    37ec:	b0 00                	mov    al,0x0
    37ee:	74 01                	je     0x37f1
    37f0:	40                   	inc    ax
    37f1:	8a d0                	mov    dl,al
    37f3:	9b dd 86 e8 fe       	fld    QWORD PTR [bp-0x118]
    37f8:	9b 2e d8 1e b6 34    	fcomp  DWORD PTR cs:0x34b6
    37fe:	9b dd be e0 fd       	fstsw  WORD PTR [bp-0x220]
    3803:	90                   	nop
    3804:	9b                   	fwait
    3805:	8a a6 e1 fd          	mov    ah,BYTE PTR [bp-0x21f]
    3809:	9e                   	sahf
    380a:	b0 00                	mov    al,0x0
    380c:	74 01                	je     0x380f
    380e:	40                   	inc    ax
    380f:	0a 06 56 09          	or     al,BYTE PTR ds:0x956
    3813:	0a c2                	or     al,dl
    3815:	a2 42 00             	mov    ds:0x42,al
    3818:	cb                   	retf
    3819:	c9                   	leave
    381a:	ca 04 00             	retf   0x4
    381d:	0d 44 e9             	or     ax,0xe944
    3820:	6d                   	ins    WORD PTR es:[di],dx
    3821:	6f                   	outs   dx,WORD PTR ds:[si]
    3822:	6e                   	outs   dx,BYTE PTR ds:[si]
    3823:	73 74                	jae    0x3899
    3825:	72 61                	jb     0x3888
    3827:	74 69                	je     0x3892
    3829:	6f                   	outs   dx,WORD PTR ds:[si]
    382a:	6e                   	outs   dx,BYTE PTR ds:[si]
    382b:	55                   	push   bp
    382c:	89 e5                	mov    bp,sp
    382e:	b8 0c 01             	mov    ax,0x10c
    3831:	9a 44 04 65 38       	call   0x3865:0x444
    3836:	81 ec 0c 01          	sub    sp,0x10c
    383a:	80 3e 42 00 00       	cmp    BYTE PTR ds:0x42,0x0
    383f:	75 03                	jne    0x3844
    3841:	e9 ac 00             	jmp    0x38f0
    3844:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3847:	26 c4 bd b8 02       	les    di,DWORD PTR es:[di+0x2b8]
    384c:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
    3850:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
    3854:	bf 1d 38             	mov    di,0x381d
    3857:	0e                   	push   cs
    3858:	57                   	push   di
    3859:	8d be fc fe          	lea    di,[bp-0x104]
    385d:	16                   	push   ss
    385e:	57                   	push   di
    385f:	68 ff 00             	push   0xff
    3862:	9a e7 17 c3 38       	call   0x38c3:0x17e7
    3867:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    386b:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    3870:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    3874:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    3878:	8d be fc fe          	lea    di,[bp-0x104]
    387c:	16                   	push   ss
    387d:	57                   	push   di
    387e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    3882:	06                   	push   es
    3883:	57                   	push   di
    3884:	9a 4e 20 a1 38       	call   0x38a1:0x204e
    3889:	99                   	cwd
    388a:	b9 03 00             	mov    cx,0x3
    388d:	f7 f9                	idiv   cx
    388f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3892:	8d be fc fe          	lea    di,[bp-0x104]
    3896:	16                   	push   ss
    3897:	57                   	push   di
    3898:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    389c:	06                   	push   es
    389d:	57                   	push   di
    389e:	9a 03 20 b9 38       	call   0x38b9:0x2003
    38a3:	99                   	cwd
    38a4:	b9 02 00             	mov    cx,0x2
    38a7:	f7 f9                	idiv   cx
    38a9:	50                   	push   ax
    38aa:	8d be fc fe          	lea    di,[bp-0x104]
    38ae:	16                   	push   ss
    38af:	57                   	push   di
    38b0:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    38b4:	06                   	push   es
    38b5:	57                   	push   di
    38b6:	9a 4e 20 d7 38       	call   0x38d7:0x204e
    38bb:	5a                   	pop    dx
    38bc:	03 c2                	add    ax,dx
    38be:	71 05                	jno    0x38c5
    38c0:	9a 3e 04 fc 38       	call   0x38fc:0x43e
    38c5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    38c8:	6a 01                	push   0x1
    38ca:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    38ce:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    38d2:	06                   	push   es
    38d3:	57                   	push   di
    38d4:	9a 7c 17 ee 38       	call   0x38ee:0x177c
    38d9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    38dc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    38df:	8d be fc fe          	lea    di,[bp-0x104]
    38e3:	16                   	push   ss
    38e4:	57                   	push   di
    38e5:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    38e9:	06                   	push   es
    38ea:	57                   	push   di
    38eb:	9a 09 1f ff ff       	call   0xffff:0x1f09
    38f0:	c9                   	leave
    38f1:	ca 08 00             	retf   0x8
    38f4:	55                   	push   bp
    38f5:	89 e5                	mov    bp,sp
    38f7:	31 c0                	xor    ax,ax
    38f9:	9a 44 04 21 39       	call   0x3921:0x444
    38fe:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3902:	06                   	push   es
    3903:	57                   	push   di
    3904:	9a 43 75 85 3b       	call   0x3b85:0x7543
    3909:	c9                   	leave
    390a:	ca 08 00             	retf   0x8
    390d:	0a 4d 65             	or     cl,BYTE PTR [di+0x65]
    3910:	6d                   	ins    WORD PTR es:[di],dx
    3911:	41                   	inc    cx
    3912:	76 61                	jbe    0x3975
    3914:	69 6c 3a 20 55       	imul   bp,WORD PTR [si+0x3a],0x5520
    3919:	89 e5                	mov    bp,sp
    391b:	b8 00 03             	mov    ax,0x300
    391e:	9a 44 04 35 39       	call   0x3935:0x444
    3923:	81 ec 00 03          	sub    sp,0x300
    3927:	8d be 00 fd          	lea    di,[bp-0x300]
    392b:	16                   	push   ss
    392c:	57                   	push   di
    392d:	bf 0d 39             	mov    di,0x390d
    3930:	0e                   	push   cs
    3931:	57                   	push   di
    3932:	9a cd 17 40 39       	call   0x3940:0x17cd
    3937:	8d be 00 fe          	lea    di,[bp-0x200]
    393b:	16                   	push   ss
    393c:	57                   	push   di
    393d:	9a bc 01 4c 39       	call   0x394c:0x1bc
    3942:	52                   	push   dx
    3943:	50                   	push   ax
    3944:	9a a9 08 cb 39       	call   0x39cb:0x8a9
    3949:	9a 4c 18 5a 39       	call   0x395a:0x184c
    394e:	8d be 00 ff          	lea    di,[bp-0x100]
    3952:	16                   	push   ss
    3953:	57                   	push   di
    3954:	68 ff 00             	push   0xff
    3957:	9a e7 17 7b 39       	call   0x397b:0x17e7
    395c:	8d be 00 ff          	lea    di,[bp-0x100]
    3960:	16                   	push   ss
    3961:	57                   	push   di
    3962:	6a 02                	push   0x2
    3964:	6a 04                	push   0x4
    3966:	6a 00                	push   0x0
    3968:	6a 00                	push   0x0
    396a:	9a 8a 38 f1 39       	call   0x39f1:0x388a
    396f:	c9                   	leave
    3970:	ca 08 00             	retf   0x8
    3973:	55                   	push   bp
    3974:	89 e5                	mov    bp,sp
    3976:	31 c0                	xor    ax,ax
    3978:	9a 44 04 9c 39       	call   0x399c:0x444
    397d:	6a 30                	push   0x30
    397f:	9a ff ff 00 00       	call   0x0:0xffff
    3984:	c9                   	leave
    3985:	ca 08 00             	retf   0x8
    3988:	0a 49 6e             	or     cl,BYTE PTR [bx+di+0x6e]
    398b:	74 65                	je     0x39f2
    398d:	72 76                	jb     0x3a05
    398f:	61                   	popa
    3990:	6c                   	ins    BYTE PTR es:[di],dx
    3991:	3a 20                	cmp    ah,BYTE PTR [bx+si]
    3993:	55                   	push   bp
    3994:	89 e5                	mov    bp,sp
    3996:	b8 00 03             	mov    ax,0x300
    3999:	9a 44 04 b0 39       	call   0x39b0:0x444
    399e:	81 ec 00 03          	sub    sp,0x300
    39a2:	8d be 00 fd          	lea    di,[bp-0x300]
    39a6:	16                   	push   ss
    39a7:	57                   	push   di
    39a8:	bf 88 39             	mov    di,0x3988
    39ab:	0e                   	push   cs
    39ac:	57                   	push   di
    39ad:	9a cd 17 d0 39       	call   0x39d0:0x17cd
    39b2:	8d be 00 fe          	lea    di,[bp-0x200]
    39b6:	16                   	push   ss
    39b7:	57                   	push   di
    39b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39bb:	26 c4 bd b4 02       	les    di,DWORD PTR es:[di+0x2b4]
    39c0:	26 8b 45 1c          	mov    ax,WORD PTR es:[di+0x1c]
    39c4:	31 d2                	xor    dx,dx
    39c6:	52                   	push   dx
    39c7:	50                   	push   ax
    39c8:	9a a9 08 95 3e       	call   0x3e95:0x8a9
    39cd:	9a 4c 18 de 39       	call   0x39de:0x184c
    39d2:	8d be 00 ff          	lea    di,[bp-0x100]
    39d6:	16                   	push   ss
    39d7:	57                   	push   di
    39d8:	68 ff 00             	push   0xff
    39db:	9a e7 17 ff 39       	call   0x39ff:0x17e7
    39e0:	8d be 00 ff          	lea    di,[bp-0x100]
    39e4:	16                   	push   ss
    39e5:	57                   	push   di
    39e6:	6a 02                	push   0x2
    39e8:	6a 04                	push   0x4
    39ea:	6a 00                	push   0x0
    39ec:	6a 00                	push   0x0
    39ee:	9a 8a 38 d3 3a       	call   0x3ad3:0x388a
    39f3:	c9                   	leave
    39f4:	ca 08 00             	retf   0x8
    39f7:	55                   	push   bp
    39f8:	89 e5                	mov    bp,sp
    39fa:	31 c0                	xor    ax,ax
    39fc:	9a 44 04 1d 3a       	call   0x3a1d:0x444
    3a01:	c7 06 06 1e 01 00    	mov    WORD PTR ds:0x1e06,0x1
    3a07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a0a:	06                   	push   es
    3a0b:	57                   	push   di
    3a0c:	9a a9 0f 2d 3a       	call   0x3a2d:0xfa9
    3a11:	c9                   	leave
    3a12:	ca 08 00             	retf   0x8
    3a15:	55                   	push   bp
    3a16:	89 e5                	mov    bp,sp
    3a18:	31 c0                	xor    ax,ax
    3a1a:	9a 44 04 3b 3a       	call   0x3a3b:0x444
    3a1f:	c7 06 06 1e 02 00    	mov    WORD PTR ds:0x1e06,0x2
    3a25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a28:	06                   	push   es
    3a29:	57                   	push   di
    3a2a:	9a a9 0f 4b 3a       	call   0x3a4b:0xfa9
    3a2f:	c9                   	leave
    3a30:	ca 08 00             	retf   0x8
    3a33:	55                   	push   bp
    3a34:	89 e5                	mov    bp,sp
    3a36:	31 c0                	xor    ax,ax
    3a38:	9a 44 04 59 3a       	call   0x3a59:0x444
    3a3d:	c7 06 06 1e 03 00    	mov    WORD PTR ds:0x1e06,0x3
    3a43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a46:	06                   	push   es
    3a47:	57                   	push   di
    3a48:	9a a9 0f 69 3a       	call   0x3a69:0xfa9
    3a4d:	c9                   	leave
    3a4e:	ca 08 00             	retf   0x8
    3a51:	55                   	push   bp
    3a52:	89 e5                	mov    bp,sp
    3a54:	31 c0                	xor    ax,ax
    3a56:	9a 44 04 77 3a       	call   0x3a77:0x444
    3a5b:	c7 06 06 1e 04 00    	mov    WORD PTR ds:0x1e06,0x4
    3a61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a64:	06                   	push   es
    3a65:	57                   	push   di
    3a66:	9a a9 0f aa 3b       	call   0x3baa:0xfa9
    3a6b:	c9                   	leave
    3a6c:	ca 08 00             	retf   0x8
    3a6f:	55                   	push   bp
    3a70:	89 e5                	mov    bp,sp
    3a72:	31 c0                	xor    ax,ax
    3a74:	9a 44 04 8a 3a       	call   0x3a8a:0x444
    3a79:	9a dd 14 ff ff       	call   0xffff:0x14dd
    3a7e:	c9                   	leave
    3a7f:	ca 08 00             	retf   0x8
    3a82:	55                   	push   bp
    3a83:	89 e5                	mov    bp,sp
    3a85:	31 c0                	xor    ax,ax
    3a87:	9a 44 04 a1 3a       	call   0x3aa1:0x444
    3a8c:	ff 36 4c 01          	push   WORD PTR ds:0x14c
    3a90:	9a f1 14 ff ff       	call   0xffff:0x14f1
    3a95:	c9                   	leave
    3a96:	ca 08 00             	retf   0x8
    3a99:	55                   	push   bp
    3a9a:	89 e5                	mov    bp,sp
    3a9c:	31 c0                	xor    ax,ax
    3a9e:	9a 44 04 bb 3a       	call   0x3abb:0x444
    3aa3:	ff 36 4c 01          	push   WORD PTR ds:0x14c
    3aa7:	6a 01                	push   0x1
    3aa9:	9a 00 13 ff ff       	call   0xffff:0x1300
    3aae:	c9                   	leave
    3aaf:	ca 08 00             	retf   0x8
    3ab2:	55                   	push   bp
    3ab3:	89 e5                	mov    bp,sp
    3ab5:	b8 04 00             	mov    ax,0x4
    3ab8:	9a 44 04 11 3b       	call   0x3b11:0x444
    3abd:	83 ec 04             	sub    sp,0x4
    3ac0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ac3:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
    3ac8:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3acb:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3ace:	06                   	push   es
    3acf:	57                   	push   di
    3ad0:	9a 0d 2b ff ff       	call   0xffff:0x2b0d
    3ad5:	08 c0                	or     al,al
    3ad7:	74 1a                	je     0x3af3
    3ad9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3adc:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
    3ae0:	26 ff 75 1f          	push   WORD PTR es:[di+0x1f]
    3ae4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ae7:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    3aec:	06                   	push   es
    3aed:	57                   	push   di
    3aee:	9a eb 1d 6d 3b       	call   0x3b6d:0x1deb
    3af3:	c9                   	leave
    3af4:	ca 08 00             	retf   0x8
    3af7:	43                   	inc    bx
    3af8:	3c b6                	cmp    al,0xb6
    3afa:	3b a6 3b 00          	cmp    sp,WORD PTR [bp+0x3b]
    3afe:	00 93 3b a8          	add    BYTE PTR [bp+di-0x57c5],dl
    3b02:	01 fb                	add    bx,di
    3b04:	04 5d                	add    al,0x5d
    3b06:	3c 39                	cmp    al,0x39
    3b08:	3f                   	aas
    3b09:	1d 3b 9a             	sbb    ax,0x9a3b
    3b0c:	1f                   	pop    ds
    3b0d:	74 3c                	je     0x3b4b
    3b0f:	cb                   	retf
    3b10:	1f                   	pop    ds
    3b11:	0d 3b ad             	or     ax,0xad3b
    3b14:	27                   	daa
    3b15:	91                   	xchg   cx,ax
    3b16:	3b cd                	cmp    cx,bp
    3b18:	11 21                	adc    WORD PTR [bx+di],sp
    3b1a:	3b f7                	cmp    si,di
    3b1c:	2a 7d 3b             	sub    bh,BYTE PTR [di+0x3b]
    3b1f:	fa                   	cli
    3b20:	10 f0                	adc    al,dh
    3b22:	3c d6                	cmp    al,0xd6
    3b24:	14 55                	adc    al,0x55
    3b26:	3b f4                	cmp    si,sp
    3b28:	4f                   	dec    di
    3b29:	41                   	inc    cx
    3b2a:	3b 9a 28 89          	cmp    bx,WORD PTR [bp+si-0x76d8]
    3b2e:	3b 85 29 35          	cmp    ax,WORD PTR [di+0x3529]
    3b32:	3b 57 4d             	cmp    dx,WORD PTR [bx+0x4d]
    3b35:	39 3b                	cmp    WORD PTR [bp+di],di
    3b37:	91                   	xchg   cx,ax
    3b38:	2f                   	das
    3b39:	59                   	pop    cx
    3b3a:	3b 63 31             	cmp    sp,WORD PTR [bp+di+0x31]
    3b3d:	5d                   	pop    bp
    3b3e:	3b 21                	cmp    sp,WORD PTR [bx+di]
    3b40:	50                   	push   ax
    3b41:	19 3b                	sbb    WORD PTR [bp+di],di
    3b43:	53                   	push   bx
    3b44:	25 15 3b             	and    ax,0x3b15
    3b47:	d9 62 51             	fldenv [bp+si+0x51]
    3b4a:	3b 55 2e             	cmp    dx,WORD PTR [di+0x2e]
    3b4d:	2d 3b 8f             	sub    ax,0x8f3b
    3b50:	60                   	pusha
    3b51:	8d 3b                	lea    di,[bp+di]
    3b53:	3a 1c                	cmp    bl,BYTE PTR [si]
    3b55:	34 3d                	xor    al,0x3d
    3b57:	e2 2f                	loop   0x3b88
    3b59:	45                   	inc    bp
    3b5a:	3b 08                	cmp    cx,WORD PTR [bx+si]
    3b5c:	61                   	popa
    3b5d:	61                   	popa
    3b5e:	3b 5c 61             	cmp    bx,WORD PTR [si+0x61]
    3b61:	65 3b 62 5c          	cmp    sp,WORD PTR gs:[bp+si+0x5c]
    3b65:	69 3b 3a 61          	imul   di,WORD PTR [bp+di],0x613a
    3b69:	25 3b 72             	and    ax,0x723b
    3b6c:	3f                   	aas
    3b6d:	81 3b 58 3a          	cmp    WORD PTR [bp+di],0x3a58
    3b71:	75 3b                	jne    0x3bae
    3b73:	ec                   	in     al,dx
    3b74:	3d 79 3b             	cmp    ax,0x3b79
    3b77:	e4 3c                	in     al,0x3c
    3b79:	09 3b                	or     WORD PTR [bp+di],di
    3b7b:	ed                   	in     ax,dx
    3b7c:	3e 4d                	ds dec bp
    3b7e:	3b 77 3e             	cmp    si,WORD PTR [bx+0x3e]
    3b81:	49                   	dec    cx
    3b82:	3b e6                	cmp    sp,si
    3b84:	31 71 3b             	xor    WORD PTR [bx+di+0x3b],si
    3b87:	3c 47                	cmp    al,0x47
    3b89:	31 3b                	xor    WORD PTR [bp+di],di
    3b8b:	ae                   	scas   al,BYTE PTR es:[di]
    3b8c:	5f                   	pop    di
    3b8d:	3d 3b e9             	cmp    ax,0xe93b
    3b90:	5c                   	pop    sp
    3b91:	05 3b 12             	add    ax,0x123b
    3b94:	54                   	push   sp
    3b95:	46                   	inc    si
    3b96:	6f                   	outs   dx,WORD PTR ds:[si]
    3b97:	72 6d                	jb     0x3c06
    3b99:	53                   	push   bx
    3b9a:	45                   	inc    bp
    3b9b:	44                   	inc    sp
    3b9c:	44                   	inc    sp
    3b9d:	5f                   	pop    di
    3b9e:	41                   	inc    cx
    3b9f:	75 74                	jne    0x3c15
    3ba1:	6f                   	outs   dx,WORD PTR ds:[si]
    3ba2:	43                   	inc    bx
    3ba3:	6f                   	outs   dx,WORD PTR ds:[si]
    3ba4:	72 72                	jb     0x3c18
    3ba6:	01 00                	add    WORD PTR [bx+si],ax
    3ba8:	a9 3c 59             	test   ax,0x593c
    3bab:	3c 09                	cmp    al,0x9
    3bad:	46                   	inc    si
    3bae:	6f                   	outs   dx,WORD PTR ds:[si]
    3baf:	72 6d                	jb     0x3c1e
    3bb1:	43                   	inc    bx
    3bb2:	6c                   	ins    BYTE PTR es:[di],dx
    3bb3:	6f                   	outs   dx,WORD PTR ds:[si]
    3bb4:	73 65                	jae    0x3c1b
    3bb6:	0b 00                	or     ax,WORD PTR [bx+si]
    3bb8:	35 3c 7c             	xor    ax,0x7c3c
    3bbb:	01 00                	add    WORD PTR [bx+si],ax
    3bbd:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    3bc1:	6e                   	outs   dx,BYTE PTR ds:[si]
    3bc2:	65 6c                	gs ins BYTE PTR es:[di],dx
    3bc4:	31 80 01 00          	xor    WORD PTR [bx+si+0x1],ax
    3bc8:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    3bcc:	6e                   	outs   dx,BYTE PTR ds:[si]
    3bcd:	65 6c                	gs ins BYTE PTR es:[di],dx
    3bcf:	32 84 01 04          	xor    al,BYTE PTR [si+0x401]
    3bd3:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3bd7:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3bda:	36 88 01             	mov    BYTE PTR ss:[bx+di],al
    3bdd:	04 00                	add    al,0x0
    3bdf:	06                   	push   es
    3be0:	4c                   	dec    sp
    3be1:	61                   	popa
    3be2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3be5:	31 8c 01 04          	xor    WORD PTR [si+0x401],cx
    3be9:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3bed:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3bf0:	32 90 01 04          	xor    dl,BYTE PTR [bx+si+0x401]
    3bf4:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3bf8:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3bfb:	33 94 01 08          	xor    dx,WORD PTR [si+0x801]
    3bff:	00 07                	add    BYTE PTR [bx],al
    3c01:	42                   	inc    dx
    3c02:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    3c07:	31 98 01 08          	xor    WORD PTR [bx+si+0x801],bx
    3c0b:	00 07                	add    BYTE PTR [bx],al
    3c0d:	42                   	inc    dx
    3c0e:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    3c13:	32 9c 01 00          	xor    bl,BYTE PTR [si+0x1]
    3c17:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    3c1b:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c1c:	65 6c                	gs ins BYTE PTR es:[di],dx
    3c1e:	33 a0 01 04          	xor    sp,WORD PTR [bx+si+0x401]
    3c22:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3c26:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3c29:	34 a4                	xor    al,0xa4
    3c2b:	01 04                	add    WORD PTR [si],ax
    3c2d:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3c31:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3c34:	35 03 00             	xor    ax,0x3
    3c37:	ad                   	lods   ax,WORD PTR ds:[si]
    3c38:	0d f9 3d             	or     ax,0x3df9
    3c3b:	17                   	pop    ss
    3c3c:	06                   	push   es
    3c3d:	fd                   	std
    3c3e:	3d ac 04             	cmp    ax,0x4ac
    3c41:	f5                   	cmc
    3c42:	3d 07 12             	cmp    ax,0x1207
    3c45:	54                   	push   sp
    3c46:	46                   	inc    si
    3c47:	6f                   	outs   dx,WORD PTR ds:[si]
    3c48:	72 6d                	jb     0x3cb7
    3c4a:	53                   	push   bx
    3c4b:	45                   	inc    bp
    3c4c:	44                   	inc    sp
    3c4d:	44                   	inc    sp
    3c4e:	5f                   	pop    di
    3c4f:	41                   	inc    cx
    3c50:	75 74                	jne    0x3cc6
    3c52:	6f                   	outs   dx,WORD PTR ds:[si]
    3c53:	43                   	inc    bx
    3c54:	6f                   	outs   dx,WORD PTR ds:[si]
    3c55:	72 72                	jb     0x3cc9
    3c57:	17                   	pop    ss
    3c58:	3b 88 3c 7b          	cmp    cx,WORD PTR [bx+si+0x7b3c]
    3c5c:	06                   	push   es
    3c5d:	8f                   	(bad)
    3c5e:	3c 38                	cmp    al,0x38
    3c60:	00 07                	add    BYTE PTR [bx],al
    3c62:	53                   	push   bx
    3c63:	65 64 64 6d          	gs fs fs ins WORD PTR es:[di],dx
    3c67:	61                   	popa
    3c68:	63 00                	arpl   WORD PTR [bx+si],ax
    3c6a:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3c6d:	e5 b8                	in     ax,0xb8
    3c6f:	06                   	push   es
    3c70:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    3c74:	b1 3c                	mov    cl,0x3c
    3c76:	83 ec 06             	sub    sp,0x6
    3c79:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    3c7d:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    3c81:	b0 01                	mov    al,0x1
    3c83:	50                   	push   ax
    3c84:	b8 17 3b             	mov    ax,0x3b17
    3c87:	ba 73 3d             	mov    dx,0x3d73
    3c8a:	52                   	push   dx
    3c8b:	50                   	push   ax
    3c8c:	9a 53 25 9f 3c       	call   0x3c9f:0x2553
    3c91:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3c94:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    3c97:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3c9a:	06                   	push   es
    3c9b:	57                   	push   di
    3c9c:	9a 45 5d 4c 3d       	call   0x3d4c:0x5d45
    3ca1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3ca4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3ca7:	c9                   	leave
    3ca8:	cb                   	retf
    3ca9:	55                   	push   bp
    3caa:	89 e5                	mov    bp,sp
    3cac:	31 c0                	xor    ax,ax
    3cae:	9a 44 04 d8 3c       	call   0x3cd8:0x444
    3cb3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3cb6:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
    3cba:	c9                   	leave
    3cbb:	ca 0c 00             	retf   0xc
    3cbe:	03 3e 9b 3d          	add    di,WORD PTR ds:0x3d9b
    3cc2:	6f                   	outs   dx,WORD PTR ds:[si]
    3cc3:	3d 00 00             	cmp    ax,0x0
    3cc6:	5a                   	pop    dx
    3cc7:	3d 98 01             	cmp    ax,0x198
    3cca:	fb                   	sti
    3ccb:	04 1f                	add    al,0x1f
    3ccd:	3e 39 3f             	cmp    WORD PTR ds:[bx],di
    3cd0:	e4 3c                	in     al,0x3c
    3cd2:	9a 1f 3b 3e cb       	call   0xcb3e:0x3b1f
    3cd7:	1f                   	pop    ds
    3cd8:	d4 3c                	aam    0x3c
    3cda:	ad                   	lods   ax,WORD PTR ds:[si]
    3cdb:	27                   	daa
    3cdc:	58                   	pop    ax
    3cdd:	3d cd 11             	cmp    ax,0x11cd
    3ce0:	e8 3c f7             	call   0x341f
    3ce3:	2a 44 3d             	sub    al,BYTE PTR [si+0x3d]
    3ce6:	fa                   	cli
    3ce7:	10 ff                	adc    bh,bh
    3ce9:	ff d6                	call   si
    3ceb:	14 1c                	adc    al,0x1c
    3ced:	3d f4 4f             	cmp    ax,0x4ff4
    3cf0:	08 3d                	or     BYTE PTR [di],bh
    3cf2:	9a 28 50 3d 85       	call   0x853d:0x5028
    3cf7:	29 fc                	sub    sp,di
    3cf9:	3c 57                	cmp    al,0x57
    3cfb:	4d                   	dec    bp
    3cfc:	00 3d                	add    BYTE PTR [di],bh
    3cfe:	91                   	xchg   cx,ax
    3cff:	2f                   	das
    3d00:	20 3d                	and    BYTE PTR [di],bh
    3d02:	63 31                	arpl   WORD PTR [bx+di],si
    3d04:	24 3d                	and    al,0x3d
    3d06:	21 50 e0             	and    WORD PTR [bx+si-0x20],dx
    3d09:	3c 53                	cmp    al,0x53
    3d0b:	25 dc 3c             	and    ax,0x3cdc
    3d0e:	d9 62 18             	fldenv [bp+si+0x18]
    3d11:	3d 55 2e             	cmp    ax,0x2e55
    3d14:	f4                   	hlt
    3d15:	3c 8f                	cmp    al,0x8f
    3d17:	60                   	pusha
    3d18:	54                   	push   sp
    3d19:	3d 3a 1c             	cmp    ax,0x1c3a
    3d1c:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    3d1d:	3e e2 2f             	ds loop 0x3d4f
    3d20:	0c 3d                	or     al,0x3d
    3d22:	08 61 28             	or     BYTE PTR [bx+di+0x28],ah
    3d25:	3d 5c 61             	cmp    ax,0x615c
    3d28:	2c 3d                	sub    al,0x3d
    3d2a:	62 5c 30             	bound  bx,DWORD PTR [si+0x30]
    3d2d:	3d 3a 61             	cmp    ax,0x613a
    3d30:	ec                   	in     al,dx
    3d31:	3c 72                	cmp    al,0x72
    3d33:	3f                   	aas
    3d34:	48                   	dec    ax
    3d35:	3d 58 3a             	cmp    ax,0x3a58
    3d38:	3c 3d                	cmp    al,0x3d
    3d3a:	ec                   	in     al,dx
    3d3b:	3d 40 3d             	cmp    ax,0x3d40
    3d3e:	e4 3c                	in     al,0x3c
    3d40:	d0 3c                	sar    BYTE PTR [si],1
    3d42:	ed                   	in     ax,dx
    3d43:	3e 14 3d             	ds adc al,0x3d
    3d46:	77 3e                	ja     0x3d86
    3d48:	10 3d                	adc    BYTE PTR [di],bh
    3d4a:	e6 31                	out    0x31,al
    3d4c:	38 3d                	cmp    BYTE PTR [di],bh
    3d4e:	3c 47                	cmp    al,0x47
    3d50:	f8                   	clc
    3d51:	3c ae                	cmp    al,0xae
    3d53:	5f                   	pop    di
    3d54:	04 3d                	add    al,0x3d
    3d56:	e9 5c cc             	jmp    0x9b5
    3d59:	3c 14                	cmp    al,0x14
    3d5b:	54                   	push   sp
    3d5c:	46                   	inc    si
    3d5d:	6f                   	outs   dx,WORD PTR ds:[si]
    3d5e:	72 6d                	jb     0x3dcd
    3d60:	53                   	push   bx
    3d61:	4a                   	dec    dx
    3d62:	47                   	inc    di
    3d63:	50                   	push   ax
    3d64:	5f                   	pop    di
    3d65:	47                   	inc    di
    3d66:	65 74 50             	gs je  0x3db9
    3d69:	65 72 69             	gs jb  0x3dd5
    3d6c:	6f                   	outs   dx,WORD PTR ds:[si]
    3d6d:	64 65 03 00          	fs add ax,WORD PTR gs:[bx+si]
    3d71:	01 3f                	add    WORD PTR [bx],di
    3d73:	81 3d 09 46          	cmp    WORD PTR [di],0x4609
    3d77:	6f                   	outs   dx,WORD PTR ds:[si]
    3d78:	72 6d                	jb     0x3de7
    3d7a:	43                   	inc    bx
    3d7b:	6c                   	ins    BYTE PTR es:[di],dx
    3d7c:	6f                   	outs   dx,WORD PTR ds:[si]
    3d7d:	73 65                	jae    0x3de4
    3d7f:	21 3f                	and    WORD PTR [bx],di
    3d81:	8e 3d                	mov    ?,WORD PTR [di]
    3d83:	08 46 6f             	or     BYTE PTR [bp+0x6f],al
    3d86:	72 6d                	jb     0x3df5
    3d88:	53                   	push   bx
    3d89:	68 6f 77             	push   0x776f
    3d8c:	6a 3f                	push   0x3f
    3d8e:	1b 3e 0a 46          	sbb    di,WORD PTR ds:0x460a
    3d92:	6f                   	outs   dx,WORD PTR ds:[si]
    3d93:	72 6d                	jb     0x3e02
    3d95:	43                   	inc    bx
    3d96:	72 65                	jb     0x3dfd
    3d98:	61                   	popa
    3d99:	74 65                	je     0x3e00
    3d9b:	07                   	pop    es
    3d9c:	00 f1                	add    cl,dh
    3d9e:	3d 7c 01             	cmp    ax,0x17c
    3da1:	00 00                	add    BYTE PTR [bx+si],al
    3da3:	07                   	pop    es
    3da4:	42                   	inc    dx
    3da5:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    3daa:	31 80 01 04          	xor    WORD PTR [bx+si+0x401],ax
    3dae:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    3db2:	6e                   	outs   dx,BYTE PTR ds:[si]
    3db3:	65 6c                	gs ins BYTE PTR es:[di],dx
    3db5:	31 84 01 00          	xor    WORD PTR [si+0x1],ax
    3db9:	00 07                	add    BYTE PTR [bx],al
    3dbb:	42                   	inc    dx
    3dbc:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
    3dc1:	32 88 01 08          	xor    cl,BYTE PTR [bx+si+0x801]
    3dc5:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3dc9:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3dcc:	31 8c 01 08          	xor    WORD PTR [si+0x801],cx
    3dd0:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3dd4:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3dd7:	33 90 01 0c          	xor    dx,WORD PTR [bx+si+0xc01]
    3ddb:	00 09                	add    BYTE PTR [bx+di],cl
    3ddd:	53                   	push   bx
    3dde:	70 69                	jo     0x3e49
    3de0:	6e                   	outs   dx,BYTE PTR ds:[si]
    3de1:	45                   	inc    bp
    3de2:	64 69 74 31 94 01    	imul   si,WORD PTR fs:[si+0x31],0x194
    3de8:	08 00                	or     BYTE PTR [bx+si],al
    3dea:	06                   	push   es
    3deb:	4c                   	dec    sp
    3dec:	61                   	popa
    3ded:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3df0:	32 04                	xor    al,BYTE PTR [si]
    3df2:	00 ac 04 ff          	add    BYTE PTR [si-0xfc],ch
    3df6:	ff ad 0d ff          	jmp    DWORD PTR [di-0xf3]
    3dfa:	ff 17                	call   WORD PTR [bx]
    3dfc:	06                   	push   es
    3dfd:	ff                   	(bad)
    3dfe:	ff                   	jmp    (bad)
    3dff:	eb 03                	jmp    0x3e04
    3e01:	cf                   	iret
    3e02:	3e 07                	ds pop es
    3e04:	14 54                	adc    al,0x54
    3e06:	46                   	inc    si
    3e07:	6f                   	outs   dx,WORD PTR ds:[si]
    3e08:	72 6d                	jb     0x3e77
    3e0a:	53                   	push   bx
    3e0b:	4a                   	dec    dx
    3e0c:	47                   	inc    di
    3e0d:	50                   	push   ax
    3e0e:	5f                   	pop    di
    3e0f:	47                   	inc    di
    3e10:	65 74 50             	gs je  0x3e63
    3e13:	65 72 69             	gs jb  0x3e7f
    3e16:	6f                   	outs   dx,WORD PTR ds:[si]
    3e17:	64 65 de 3c          	fs fidivr WORD PTR gs:[si]
    3e1b:	56                   	push   si
    3e1c:	3e 7b 06             	ds jnp 0x3e25
    3e1f:	5d                   	pop    bp
    3e20:	3e 38 00             	cmp    BYTE PTR ds:[bx+si],al
    3e23:	04 53                	add    al,0x53
    3e25:	6a 67                	push   0x67
    3e27:	70 00                	jo     0x3e29
    3e29:	00 00                	add    BYTE PTR [bx+si],al
    3e2b:	80 ff ff             	cmp    bh,0xff
    3e2e:	ff                   	(bad)
    3e2f:	7f 00                	jg     0x3e31
    3e31:	00 55 89             	add    BYTE PTR [di-0x77],dl
    3e34:	e5 b8                	in     ax,0xb8
    3e36:	0a 01                	or     al,BYTE PTR [bx+di]
    3e38:	9a 44 04 8d 3e       	call   0x3e8d:0x444
    3e3d:	81 ec 0a 01          	sub    sp,0x10a
    3e41:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3e44:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3e47:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    3e4b:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    3e4f:	b0 01                	mov    al,0x1
    3e51:	50                   	push   ax
    3e52:	b8 de 3c             	mov    ax,0x3cde
    3e55:	ba ff ff             	mov    dx,0xffff
    3e58:	52                   	push   dx
    3e59:	50                   	push   ax
    3e5a:	9a 53 25 d9 3e       	call   0x3ed9:0x2553
    3e5f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3e62:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    3e65:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3e68:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    3e6b:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    3e6e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3e71:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    3e74:	7e 06                	jle    0x3e7c
    3e76:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    3e79:	89 46 06             	mov    WORD PTR [bp+0x6],ax
    3e7c:	8d be f6 fe          	lea    di,[bp-0x10a]
    3e80:	16                   	push   ss
    3e81:	57                   	push   di
    3e82:	a1 4c 01             	mov    ax,ds:0x14c
    3e85:	2d 01 00             	sub    ax,0x1
    3e88:	71 05                	jno    0x3e8f
    3e8a:	9a 3e 04 f5 3e       	call   0x3ef5:0x43e
    3e8f:	99                   	cwd
    3e90:	52                   	push   dx
    3e91:	50                   	push   ax
    3e92:	9a a9 08 ff ff       	call   0xffff:0x8a9
    3e97:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3e9a:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    3e9f:	06                   	push   es
    3ea0:	57                   	push   di
    3ea1:	9a 8c 1d 64 3f       	call   0x3f64:0x1d8c
    3ea6:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    3ea9:	99                   	cwd
    3eaa:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3ead:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3eb2:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
    3eb7:	26 89 95 f2 00       	mov    WORD PTR es:[di+0xf2],dx
    3ebc:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3ebf:	99                   	cwd
    3ec0:	52                   	push   dx
    3ec1:	50                   	push   ax
    3ec2:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3ec5:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3eca:	06                   	push   es
    3ecb:	57                   	push   di
    3ecc:	9a 8b 17 ed 3e       	call   0x3eed:0x178b
    3ed1:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3ed4:	06                   	push   es
    3ed5:	57                   	push   di
    3ed6:	9a 45 5d 14 3f       	call   0x3f14:0x5d45
    3edb:	3d 01 00             	cmp    ax,0x1
    3ede:	75 1a                	jne    0x3efa
    3ee0:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3ee3:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3ee8:	06                   	push   es
    3ee9:	57                   	push   di
    3eea:	9a 33 17 ff ff       	call   0xffff:0x1733
    3eef:	bf 2a 3e             	mov    di,0x3e2a
    3ef2:	9a 16 04 09 3f       	call   0x3f09:0x416
    3ef7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3efa:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3efd:	c9                   	leave
    3efe:	ca 04 00             	retf   0x4
    3f01:	55                   	push   bp
    3f02:	89 e5                	mov    bp,sp
    3f04:	31 c0                	xor    ax,ax
    3f06:	9a 44 04 2a 3f       	call   0x3f2a:0x444
    3f0b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    3f0f:	06                   	push   es
    3f10:	57                   	push   di
    3f11:	9a 03 73 ff ff       	call   0xffff:0x7303
    3f16:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f19:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
    3f1d:	c9                   	leave
    3f1e:	ca 0c 00             	retf   0xc
    3f21:	55                   	push   bp
    3f22:	89 e5                	mov    bp,sp
    3f24:	b8 04 00             	mov    ax,0x4
    3f27:	9a 44 04 72 3f       	call   0x3f72:0x444
    3f2c:	83 ec 04             	sub    sp,0x4
    3f2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f32:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    3f37:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3f3a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3f3d:	26 8b 85 ec 00       	mov    ax,WORD PTR es:[di+0xec]
    3f42:	26 8b 95 ee 00       	mov    dx,WORD PTR es:[di+0xee]
    3f47:	26 3b 95 f2 00       	cmp    dx,WORD PTR es:[di+0xf2]
    3f4c:	75 0b                	jne    0x3f59
    3f4e:	26 3b 85 f0 00       	cmp    ax,WORD PTR es:[di+0xf0]
    3f53:	75 04                	jne    0x3f59
    3f55:	b0 00                	mov    al,0x0
    3f57:	eb 02                	jmp    0x3f5b
    3f59:	b0 01                	mov    al,0x1
    3f5b:	50                   	push   ax
    3f5c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3f5f:	06                   	push   es
    3f60:	57                   	push   di
    3f61:	9a b8 1c ff ff       	call   0xffff:0x1cb8
    3f66:	c9                   	leave
    3f67:	ca 08 00             	retf   0x8
    3f6a:	55                   	push   bp
    3f6b:	89 e5                	mov    bp,sp
    3f6d:	31 c0                	xor    ax,ax
    3f6f:	9a 44 04 ff ff       	call   0xffff:0x444
    3f74:	c9                   	leave
    3f75:	ca                   	.byte 0xca
    3f76:	08                   	.byte 0x8
