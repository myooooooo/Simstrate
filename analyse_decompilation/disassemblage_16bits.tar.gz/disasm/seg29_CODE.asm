; ================================================================
; seg29_CODE  (33579 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	1d 00 00             	sbb    ax,0x0
       3:	00 00                	add    BYTE PTR [bx+si],al
       5:	00 00                	add    BYTE PTR [bx+si],al
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 22                	add    BYTE PTR [bp+si],ah
       b:	00 11                	add    BYTE PTR [bx+di],dl
       d:	00 2c                	add    BYTE PTR [si],ch
       f:	1f                   	pop    ds
      10:	46                   	inc    si
      11:	00 64 20             	add    BYTE PTR [si+0x20],ah
      14:	10 00                	adc    BYTE PTR [bx+si],al
      16:	9a 1f 14 00 cb       	call   0xcb00:0x141f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	c1 17 4a             	rcl    WORD PTR [bx],0x4a
      21:	00 09                	add    BYTE PTR [bx+di],cl
      23:	54                   	push   sp
      24:	49                   	dec    cx
      25:	6e                   	outs   dx,BYTE PTR ds:[si]
      26:	64 65 78 44          	fs gs js 0x6e
      2a:	65 66 00 00          	data32 add BYTE PTR gs:[bx+si],al
      2e:	00 00                	add    BYTE PTR [bx+si],al
      30:	00 00                	add    BYTE PTR [bx+si],al
      32:	00 00                	add    BYTE PTR [bx+si],al
      34:	4c                   	dec    sp
      35:	00 0e 00 2c          	add    BYTE PTR ds:0x2c00,cl
      39:	1f                   	pop    ds
      3a:	71 00                	jno    0x3c
      3c:	64 20 3a             	and    BYTE PTR fs:[bp+si],bh
      3f:	00 9a 1f 3e          	add    BYTE PTR [bp+si+0x3e1f],bl
      43:	00 cb                	add    bl,cl
      45:	1f                   	pop    ds
      46:	42                   	inc    dx
      47:	00 c2                	add    dl,al
      49:	18 85 00 0a          	sbb    BYTE PTR [di+0xa00],al
      4d:	54                   	push   sp
      4e:	49                   	dec    cx
      4f:	6e                   	outs   dx,BYTE PTR ds:[si]
      50:	64 65 78 44          	fs gs js 0x98
      54:	65 66 73 b6          	gs data32 jae 0xe
      58:	00 00                	add    BYTE PTR [bx+si],al
      5a:	00 00                	add    BYTE PTR [bx+si],al
      5c:	00 00                	add    BYTE PTR [bx+si],al
      5e:	00 a7 00 20          	add    BYTE PTR [bx+0x2000],ah
      62:	00 1d                	add    BYTE PTR [di],bl
      64:	0d cc 00             	or     ax,0xcc
      67:	64 20 32             	and    BYTE PTR fs:[bp+si],dh
      6a:	01 9a 1f 69          	add    WORD PTR [bp+si+0x691f],bx
      6e:	00 cb                	add    bl,cl
      70:	1f                   	pop    ds
      71:	6d                   	ins    WORD PTR es:[di],dx
      72:	00 d4                	add    ah,dl
      74:	1b c8                	sbb    cx,ax
      76:	00 cd                	add    ch,cl
      78:	11 7d 00             	adc    WORD PTR [di+0x0],di
      7b:	e4 11                	in     al,0x11
      7d:	81 00 fa 10          	add    WORD PTR [bx+si],0x10fa
      81:	3e 01 1b             	add    WORD PTR ds:[bp+di],bx
      84:	1c 89                	sbb    al,0x89
      86:	00 16 1d 9d          	add    BYTE PTR ds:0x9d1d,dl
      8a:	00 13                	add    BYTE PTR [bp+di],dl
      8c:	7b 91                	jnp    0x1f
      8e:	00 2a                	add    BYTE PTR [bp+si],ch
      90:	7b 95                	jnp    0x27
      92:	00 44 7b             	add    BYTE PTR [si+0x7b],al
      95:	99                   	cwd
      96:	00 3d                	add    BYTE PTR [di],bh
      98:	7b a5                	jnp    0x3f
      9a:	00 3d                	add    BYTE PTR [di],bh
      9c:	1d a1 00             	sbb    ax,0xa1
      9f:	50                   	push   ax
      a0:	1d 75 00             	sbb    ax,0x75
      a3:	65 7b 65             	gs jnp 0x10b
      a6:	00 0e 54 54          	add    BYTE PTR ds:0x5454,cl
      aa:	61                   	popa
      ab:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      ae:	44                   	inc    sp
      af:	61                   	popa
      b0:	74 61                	je     0x113
      b2:	4c                   	dec    sp
      b3:	69 6e 6b 07 0e       	imul   bp,WORD PTR [bp+0x6b],0xe07
      b8:	54                   	push   sp
      b9:	54                   	push   sp
      ba:	61                   	popa
      bb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      be:	44                   	inc    sp
      bf:	61                   	popa
      c0:	74 61                	je     0x123
      c2:	4c                   	dec    sp
      c3:	69 6e 6b 77 00       	imul   bp,WORD PTR [bp+0x6b],0x77
      c8:	f2 00 57 0d          	repnz add BYTE PTR [bx+0xd],dl
      cc:	6a 01                	push   0x1
      ce:	00 00                	add    BYTE PTR [bx+si],al
      d0:	08 44 42             	or     BYTE PTR [si+0x42],al
      d3:	54                   	push   sp
      d4:	61                   	popa
      d5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      d8:	73 00                	jae    0xda
      da:	00 03                	add    BYTE PTR [bp+di],al
      dc:	0a 54 54             	or     dl,BYTE PTR [si+0x54]
      df:	61                   	popa
      e0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      e3:	54                   	push   sp
      e4:	79 70                	jns    0x156
      e6:	65 00 00             	add    BYTE PTR gs:[bx+si],al
      e9:	00 00                	add    BYTE PTR [bx+si],al
      eb:	00 03                	add    BYTE PTR [bp+di],al
      ed:	00 00                	add    BYTE PTR [bx+si],al
      ef:	00 db                	add    bl,bl
      f1:	00 6e 01             	add    BYTE PTR [bp+0x1],ch
      f4:	09 74 74             	or     WORD PTR [si+0x74],si
      f7:	44                   	inc    sp
      f8:	65 66 61             	gs popad
      fb:	75 6c                	jne    0x169
      fd:	74 09                	je     0x108
      ff:	74 74                	je     0x175
     101:	50                   	push   ax
     102:	61                   	popa
     103:	72 61                	jb     0x166
     105:	64 6f                	outs   dx,WORD PTR fs:[si]
     107:	78 07                	js     0x110
     109:	74 74                	je     0x17f
     10b:	44                   	inc    sp
     10c:	42                   	inc    dx
     10d:	61                   	popa
     10e:	73 65                	jae    0x175
     110:	07                   	pop    es
     111:	74 74                	je     0x187
     113:	41                   	inc    cx
     114:	53                   	push   bx
     115:	43                   	inc    bx
     116:	49                   	dec    cx
     117:	49                   	dec    cx
     118:	d3 01                	rol    WORD PTR [bx+di],cl
     11a:	00 00                	add    BYTE PTR [bx+si],al
     11c:	00 00                	add    BYTE PTR [bx+si],al
     11e:	00 00                	add    BYTE PTR [bx+si],al
     120:	cc                   	int3
     121:	01 54 02             	add    WORD PTR [si+0x2],dx
     124:	97                   	xchg   di,ax
     125:	07                   	pop    es
     126:	e1 01                	loope  0x129
     128:	64 20 f2             	fs and dl,dh
     12b:	01 9a 1f 2a          	add    WORD PTR [bp+si+0x2a1f],bx
     12f:	01 cb                	add    bx,cx
     131:	1f                   	pop    ds
     132:	2e 01 6f 1e          	add    WORD PTR cs:[bx+0x1e],bp
     136:	dd 01                	fld    QWORD PTR [bx+di]
     138:	cd 11                	int    0x11
     13a:	42                   	inc    dx
     13b:	01 6e 4f             	add    WORD PTR [bp+0x4f],bp
     13e:	46                   	inc    si
     13f:	01 fa                	add    dx,di
     141:	10 63 03             	adc    BYTE PTR [bp+di+0x3],ah
     144:	e5 4f                	in     ax,0x4f
     146:	4e                   	dec    si
     147:	01 2f                	add    WORD PTR [bx],bp
     149:	31 56 01             	xor    WORD PTR [bp+0x1],dx
     14c:	05 4f 52             	add    ax,0x524f
     14f:	01 03                	add    WORD PTR [bp+di],ax
     151:	50                   	push   ax
     152:	5a                   	pop    dx
     153:	01 43 2f             	add    WORD PTR [bp+di+0x2f],ax
     156:	5e                   	pop    si
     157:	01 38                	add    WORD PTR [bx+si],di
     159:	50                   	push   ax
     15a:	62 01                	bound  ax,DWORD PTR [bx+di]
     15c:	b6 30                	mov    dh,0x30
     15e:	26 01 21             	add    WORD PTR es:[bx+di],sp
     161:	50                   	push   ax
     162:	3a 01                	cmp    al,BYTE PTR [bx+di]
     164:	ee                   	out    dx,al
     165:	1d 36 01             	sbb    ax,0x136
     168:	d4 5d                	aam    0x5d
     16a:	c6 01 0a             	mov    BYTE PTR [bx+di],0xa
     16d:	1f                   	pop    ds
     16e:	72 01                	jb     0x171
     170:	c4 23                	les    sp,DWORD PTR [bp+di]
     172:	b2 01                	mov    dl,0x1
     174:	f4                   	hlt
     175:	5a                   	pop    dx
     176:	7a 01                	jp     0x179
     178:	1c 5b                	sbb    al,0x5b
     17a:	7e 01                	jle    0x17d
     17c:	44                   	inc    sp
     17d:	5b                   	pop    bx
     17e:	82 01 6c             	add    BYTE PTR [bx+di],0x6c
     181:	5b                   	pop    bx
     182:	86 01                	xchg   BYTE PTR [bx+di],al
     184:	94                   	xchg   sp,ax
     185:	5b                   	pop    bx
     186:	8a 01                	mov    al,BYTE PTR [bx+di]
     188:	bc 5b 8e             	mov    sp,0x8e5b
     18b:	01 e4                	add    sp,sp
     18d:	5b                   	pop    bx
     18e:	92                   	xchg   dx,ax
     18f:	01 0c                	add    WORD PTR [si],cx
     191:	5c                   	pop    sp
     192:	96                   	xchg   si,ax
     193:	01 34                	add    WORD PTR [si],si
     195:	5c                   	pop    sp
     196:	9a 01 5c 5c 9e       	call   0x9e5c:0x5c01
     19b:	01 84 5c a2          	add    WORD PTR [si-0x5da4],ax
     19f:	01 ac 5c a6          	add    WORD PTR [si-0x59a4],bp
     1a3:	01 d4                	add    sp,dx
     1a5:	5c                   	pop    sp
     1a6:	aa                   	stos   BYTE PTR es:[di],al
     1a7:	01 fc                	add    sp,di
     1a9:	5c                   	pop    sp
     1aa:	ae                   	scas   al,BYTE PTR es:[di]
     1ab:	01 24                	add    WORD PTR [si],sp
     1ad:	5d                   	pop    bp
     1ae:	4a                   	dec    dx
     1af:	01 0d                	add    WORD PTR [di],cx
     1b1:	26 b6 01             	es mov dh,0x1
     1b4:	cb                   	retf
     1b5:	28 ba 01 4a          	sub    BYTE PTR [bp+si+0x4a01],bh
     1b9:	2c c2                	sub    al,0xc2
     1bb:	01 74 5d             	add    WORD PTR [si+0x5d],si
     1be:	ca 01 5d             	retf   0x5d01
     1c1:	2e 66 01 f6          	cs add esi,esi
     1c5:	5d                   	pop    bp
     1c6:	be 01 07             	mov    si,0x701
     1c9:	5e                   	pop    si
     1ca:	76 01                	jbe    0x1cd
     1cc:	06                   	push   es
     1cd:	54                   	push   sp
     1ce:	54                   	push   sp
     1cf:	61                   	popa
     1d0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1d3:	07                   	pop    es
     1d4:	06                   	push   es
     1d5:	54                   	push   sp
     1d6:	54                   	push   sp
     1d7:	61                   	popa
     1d8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1db:	38 01                	cmp    BYTE PTR [bx+di],al
     1dd:	fa                   	cli
     1de:	01 36 08 83          	add    WORD PTR ds:0x8308,si
     1e2:	02 1e 00 08          	add    bl,BYTE PTR ds:0x800
     1e6:	44                   	inc    sp
     1e7:	42                   	inc    dx
     1e8:	54                   	push   sp
     1e9:	61                   	popa
     1ea:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1ed:	73 09                	jae    0x1f8
     1ef:	00 07                	add    BYTE PTR [bx],al
     1f1:	23 14                	and    dx,WORD PTR [si]
     1f3:	02 80 01 ff          	add    al,BYTE PTR [bx+si-0xff]
     1f7:	ff d2                	call   dx
     1f9:	2e 18 02             	sbb    BYTE PTR cs:[bp+si],al
     1fc:	01 00                	add    WORD PTR [bx+si],ax
     1fe:	00 00                	add    BYTE PTR [bx+si],al
     200:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     204:	00 00                	add    BYTE PTR [bx+si],al
     206:	15 00 09             	adc    ax,0x900
     209:	45                   	inc    bp
     20a:	78 63                	js     0x26f
     20c:	6c                   	ins    BYTE PTR es:[di],dx
     20d:	75 73                	jne    0x282
     20f:	69 76 65 62 23       	imul   si,WORD PTR [bp+0x65],0x2362
     214:	3c 02                	cmp    al,0x2
     216:	74 29                	je     0x241
     218:	1c 02                	sbb    al,0x2
     21a:	a8 2f                	test   al,0x2f
     21c:	40                   	inc    ax
     21d:	02 01                	add    al,BYTE PTR [bx+di]
     21f:	00 00                	add    BYTE PTR [bx+si],al
     221:	00 00                	add    BYTE PTR [bx+si],al
     223:	80 00 00             	add    BYTE PTR [bx+si],0x0
     226:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     22a:	0f 49 6e 64          	cmovns bp,WORD PTR [bp+0x64]
     22e:	65 78 46             	gs js  0x277
     231:	69 65 6c 64 4e       	imul   sp,WORD PTR [di+0x6c],0x4e64
     236:	61                   	popa
     237:	6d                   	ins    WORD PTR es:[di],dx
     238:	65 73 62             	gs jae 0x29d
     23b:	23 5e 02             	and    bx,WORD PTR [bp+0x2]
     23e:	a2 29 44             	mov    ds:0x4429,al
     241:	02 c8                	add    cl,al
     243:	2f                   	das
     244:	62 02                	bound  ax,DWORD PTR [bp+si]
     246:	01 00                	add    WORD PTR [bx+si],ax
     248:	00 00                	add    BYTE PTR [bx+si],al
     24a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     24e:	00 80 17 00          	add    BYTE PTR [bx+si+0x17],al
     252:	09 49 6e             	or     WORD PTR [bx+di+0x6e],cx
     255:	64 65 78 4e          	fs gs js 0x2a7
     259:	61                   	popa
     25a:	6d                   	ins    WORD PTR es:[di],dx
     25b:	65 62 23             	bound  sp,DWORD PTR gs:[bp+di]
     25e:	a8 02                	test   al,0x2
     260:	3b 2b                	cmp    bp,WORD PTR [bp+di]
     262:	66 02 e0             	data32 add ah,al
     265:	2f                   	das
     266:	8b 02                	mov    ax,WORD PTR [bp+si]
     268:	01 00                	add    WORD PTR [bx+si],ax
     26a:	00 00                	add    BYTE PTR [bx+si],al
     26c:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     270:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
     274:	0c 4d                	or     al,0x4d
     276:	61                   	popa
     277:	73 74                	jae    0x2ed
     279:	65 72 46             	gs jb  0x2c2
     27c:	69 65 6c 64 73       	imul   sp,WORD PTR [di+0x6c],0x7364
     281:	04 09                	add    al,0x9
     283:	0d 03 7c             	or     ax,0x7c03
     286:	00 fe                	add    dh,bh
     288:	ff 9a 2e b0          	call   DWORD PTR [bp+si-0x4fd2]
     28c:	02 01                	add    al,BYTE PTR [bx+di]
     28e:	00 00                	add    BYTE PTR [bx+si],al
     290:	00 00                	add    BYTE PTR [bx+si],al
     292:	80 00 00             	add    BYTE PTR [bx+si],0x0
     295:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
     299:	0c 4d                	or     al,0x4d
     29b:	61                   	popa
     29c:	73 74                	jae    0x312
     29e:	65 72 53             	gs jb  0x2f4
     2a1:	6f                   	outs   dx,WORD PTR ds:[si]
     2a2:	75 72                	jne    0x316
     2a4:	63 65 07             	arpl   WORD PTR [di+0x7],sp
     2a7:	23 48 03             	and    cx,WORD PTR [bx+si+0x3]
     2aa:	81 01 ff ff          	add    WORD PTR [bx+di],0xffff
     2ae:	fb                   	sti
     2af:	2f                   	das
     2b0:	d1 02                	rol    WORD PTR [bp+si],1
     2b2:	01 00                	add    WORD PTR [bx+si],ax
     2b4:	00 00                	add    BYTE PTR [bx+si],al
     2b6:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     2ba:	00 00                	add    BYTE PTR [bx+si],al
     2bc:	1a 00                	sbb    al,BYTE PTR [bx+si]
     2be:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
     2c1:	61                   	popa
     2c2:	64 4f                	fs dec di
     2c4:	6e                   	outs   dx,BYTE PTR ds:[si]
     2c5:	6c                   	ins    BYTE PTR es:[di],dx
     2c6:	79 02                	jns    0x2ca
     2c8:	00 81 17 84          	add    BYTE PTR [bx+di-0x7be9],al
     2cc:	01 ff                	add    di,di
     2ce:	ff 17                	call   WORD PTR [bx]
     2d0:	30 eb                	xor    bl,ch
     2d2:	02 01                	add    al,BYTE PTR [bx+di]
     2d4:	00 00                	add    BYTE PTR [bx+si],al
     2d6:	00 00                	add    BYTE PTR [bx+si],al
     2d8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2db:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     2df:	09 54 61             	or     WORD PTR [si+0x61],dx
     2e2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2e5:	4e                   	dec    si
     2e6:	61                   	popa
     2e7:	6d                   	ins    WORD PTR es:[di],dx
     2e8:	65 db 00             	fild   DWORD PTR gs:[bx+si]
     2eb:	f3 02 82 01 ff       	repz add al,BYTE PTR [bp+si-0xff]
     2f0:	ff 4f 30             	dec    WORD PTR [bx+0x30]
     2f3:	4c                   	dec    sp
     2f4:	03 01                	add    ax,WORD PTR [bx+di]
     2f6:	00 00                	add    BYTE PTR [bx+si],al
     2f8:	00 00                	add    BYTE PTR [bx+si],al
     2fa:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2fd:	00 00                	add    BYTE PTR [bx+si],al
     2ff:	1c 00                	sbb    al,0x0
     301:	09 54 61             	or     WORD PTR [si+0x61],dx
     304:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     307:	54                   	push   sp
     308:	79 70                	jns    0x37a
     30a:	65 34 07             	gs xor al,0x7
     30d:	fd                   	std
     30e:	03 22                	add    sp,WORD PTR [bp+si]
     310:	01 ff                	add    di,di
     312:	ff 22                	jmp    WORD PTR [bp+si]
     314:	01 ff                	add    di,di
     316:	ff 01                	inc    WORD PTR [bx+di]
     318:	00 00                	add    BYTE PTR [bx+si],al
     31a:	00 00                	add    BYTE PTR [bx+si],al
     31c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     31f:	00 00                	add    BYTE PTR [bx+si],al
     321:	1d 00 0a             	sbb    ax,0xa00
     324:	55                   	push   bp
     325:	70 64                	jo     0x38b
     327:	61                   	popa
     328:	74 65                	je     0x38f
     32a:	4d                   	dec    bp
     32b:	6f                   	outs   dx,WORD PTR ds:[si]
     32c:	64 65 00 00          	fs add BYTE PTR gs:[bx+si],al
     330:	00 00                	add    BYTE PTR [bx+si],al
     332:	00 00                	add    BYTE PTR [bx+si],al
     334:	00 00                	add    BYTE PTR [bx+si],al
     336:	4e                   	dec    si
     337:	03 1c                	add    bx,WORD PTR [si]
     339:	00 2c                	add    BYTE PTR [si],ch
     33b:	1f                   	pop    ds
     33c:	6f                   	outs   dx,WORD PTR ds:[si]
     33d:	03 64 20             	add    sp,WORD PTR [si+0x20]
     340:	3c 03                	cmp    al,0x3
     342:	9a 1f 40 03 cb       	call   0xcb03:0x401f
     347:	1f                   	pop    ds
     348:	44                   	inc    sp
     349:	03 b7 39 7b          	add    si,WORD PTR [bx+0x7b39]
     34d:	03 06 54 50          	add    ax,WORD PTR ds:0x5054
     351:	61                   	popa
     352:	72 61                	jb     0x3b5
     354:	6d                   	ins    WORD PTR es:[di],dx
     355:	8d 03                	lea    ax,[bp+di]
     357:	00 00                	add    BYTE PTR [bx+si],al
     359:	00 00                	add    BYTE PTR [bx+si],al
     35b:	00 00                	add    BYTE PTR [bx+si],al
     35d:	85 03                	test   WORD PTR [bp+di],ax
     35f:	08 00                	or     BYTE PTR [bx+si],al
     361:	d1 02                	rol    WORD PTR [bp+si],1
     363:	9c                   	pushf
     364:	03 64 20             	add    sp,WORD PTR [si+0x20]
     367:	c5 03                	lds    ax,DWORD PTR [bp+di]
     369:	9a 1f 67 03 cb       	call   0xcb03:0x671f
     36e:	1f                   	pop    ds
     36f:	6b 03 37             	imul   ax,WORD PTR [bp+di],0x37
     372:	32 7f 03             	xor    bh,BYTE PTR [bx+0x3]
     375:	09 33                	or     WORD PTR [bp+di],si
     377:	83 03 d0             	add    WORD PTR [bp+di],0xffd0
     37a:	35 77 03             	xor    ax,0x377
     37d:	6e                   	outs   dx,BYTE PTR ds:[si]
     37e:	32 98 03 f4          	xor    bl,BYTE PTR [bx+si-0xbfd]
     382:	31 73 03             	xor    WORD PTR [bp+di+0x3],si
     385:	07                   	pop    es
     386:	54                   	push   sp
     387:	50                   	push   ax
     388:	61                   	popa
     389:	72 61                	jb     0x3ec
     38b:	6d                   	ins    WORD PTR es:[di],dx
     38c:	73 07                	jae    0x395
     38e:	07                   	pop    es
     38f:	54                   	push   sp
     390:	50                   	push   ax
     391:	61                   	popa
     392:	72 61                	jb     0x3f5
     394:	6d                   	ins    WORD PTR es:[di],dx
     395:	73 75                	jae    0x40c
     397:	03 d1                	add    dx,cx
     399:	03 e9                	add    bp,cx
     39b:	02 d9                	add    bl,cl
     39d:	03 00                	add    ax,WORD PTR [bx+si]
     39f:	00 08                	add    BYTE PTR [bx+si],cl
     3a1:	44                   	inc    sp
     3a2:	42                   	inc    dx
     3a3:	54                   	push   sp
     3a4:	61                   	popa
     3a5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3a8:	73 00                	jae    0x3aa
     3aa:	00 66 04             	add    BYTE PTR [bp+0x4],ah
     3ad:	00 00                	add    BYTE PTR [bx+si],al
     3af:	00 00                	add    BYTE PTR [bx+si],al
     3b1:	00 00                	add    BYTE PTR [bx+si],al
     3b3:	5f                   	pop    di
     3b4:	04 94                	add    al,0x94
     3b6:	01 97 07 74          	add    WORD PTR [bx+0x7407],dx
     3ba:	04 64                	add    al,0x64
     3bc:	20 c4                	and    ah,al
     3be:	04 9a                	add    al,0x9a
     3c0:	1f                   	pop    ds
     3c1:	bd 03 cb             	mov    bp,0xcb03
     3c4:	1f                   	pop    ds
     3c5:	c1 03 00             	rol    WORD PTR [bp+di],0x0
     3c8:	4e                   	dec    si
     3c9:	70 04                	jo     0x3cf
     3cb:	cd 11                	int    0x11
     3cd:	d5 03                	aad    0x3
     3cf:	b2 50                	mov    dl,0x50
     3d1:	01 04                	add    WORD PTR [si],ax
     3d3:	fa                   	cli
     3d4:	10 85 04 e5          	adc    BYTE PTR [di-0x1afc],al
     3d8:	4f                   	dec    di
     3d9:	e1 03                	loope  0x3de
     3db:	2f                   	das
     3dc:	31 55 04             	xor    WORD PTR [di+0x4],dx
     3df:	05 4f e5             	add    ax,0xe54f
     3e2:	03 03                	add    ax,WORD PTR [bp+di]
     3e4:	50                   	push   ax
     3e5:	ed                   	in     ax,dx
     3e6:	03 43 2f             	add    ax,WORD PTR [bp+di+0x2f]
     3e9:	f1                   	int1
     3ea:	03 38                	add    di,WORD PTR [bx+si]
     3ec:	50                   	push   ax
     3ed:	f5                   	cmc
     3ee:	03 b6 30 b9          	add    si,WORD PTR [bp-0x46d0]
     3f2:	03 21                	add    sp,WORD PTR [bx+di]
     3f4:	50                   	push   ax
     3f5:	cd 03                	int    0x3
     3f7:	39 4d c9             	cmp    WORD PTR [di-0x37],cx
     3fa:	03 d4                	add    dx,sp
     3fc:	5d                   	pop    bp
     3fd:	51                   	push   cx
     3fe:	04 06                	add    al,0x6
     400:	57                   	push   di
     401:	59                   	pop    cx
     402:	04 19                	add    al,0x19
     404:	43                   	inc    bx
     405:	09 04                	or     WORD PTR [si],ax
     407:	f4                   	hlt
     408:	5a                   	pop    dx
     409:	0d 04 1c             	or     ax,0x1c04
     40c:	5b                   	pop    bx
     40d:	11 04                	adc    WORD PTR [si],ax
     40f:	44                   	inc    sp
     410:	5b                   	pop    bx
     411:	15 04 6c             	adc    ax,0x6c04
     414:	5b                   	pop    bx
     415:	19 04                	sbb    WORD PTR [si],ax
     417:	94                   	xchg   sp,ax
     418:	5b                   	pop    bx
     419:	1d 04 bc             	sbb    ax,0xbc04
     41c:	5b                   	pop    bx
     41d:	21 04                	and    WORD PTR [si],ax
     41f:	e4 5b                	in     al,0x5b
     421:	25 04 0c             	and    ax,0xc04
     424:	5c                   	pop    sp
     425:	29 04                	sub    WORD PTR [si],ax
     427:	34 5c                	xor    al,0x5c
     429:	2d 04 5c             	sub    ax,0x5c04
     42c:	5c                   	pop    sp
     42d:	31 04                	xor    WORD PTR [si],ax
     42f:	84 5c 35             	test   BYTE PTR [si+0x35],bl
     432:	04 ac                	add    al,0xac
     434:	5c                   	pop    sp
     435:	39 04                	cmp    WORD PTR [si],ax
     437:	d4 5c                	aam    0x5c
     439:	3d 04 fc             	cmp    ax,0xfc04
     43c:	5c                   	pop    sp
     43d:	41                   	inc    cx
     43e:	04 24                	add    al,0x24
     440:	5d                   	pop    bp
     441:	45                   	inc    bp
     442:	04 4c                	add    al,0x4c
     444:	5d                   	pop    bp
     445:	4d                   	dec    bp
     446:	04 fe                	add    al,0xfe
     448:	4e                   	dec    si
     449:	5d                   	pop    bp
     44a:	04 88                	add    al,0x88
     44c:	3a dd                	cmp    bl,ch
     44e:	03 74 5d             	add    si,WORD PTR [si+0x5d]
     451:	05 04 0a             	add    ax,0xa04
     454:	37                   	aaa
     455:	e9 03 87             	jmp    0x8b5b
     458:	4e                   	dec    si
     459:	49                   	dec    cx
     45a:	04 92                	add    al,0x92
     45c:	5a                   	pop    dx
     45d:	f9                   	stc
     45e:	03 06 54 51          	add    ax,WORD PTR ds:0x5154
     462:	75 65                	jne    0x4c9
     464:	72 79                	jb     0x4df
     466:	07                   	pop    es
     467:	06                   	push   es
     468:	54                   	push   sp
     469:	51                   	push   cx
     46a:	75 65                	jne    0x4d1
     46c:	72 79                	jb     0x4e7
     46e:	cb                   	retf
     46f:	03 8d 04 36          	add    cx,WORD PTR [di+0x3604]
     473:	08 a1 04 1b          	or     BYTE PTR [bx+di+0x1b04],ah
     477:	00 08                	add    BYTE PTR [bx+si],cl
     479:	44                   	inc    sp
     47a:	42                   	inc    dx
     47b:	54                   	push   sp
     47c:	61                   	popa
     47d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     480:	73 06                	jae    0x488
     482:	00 8b 03 75          	add    BYTE PTR [bp+di+0x7503],cl
     486:	05 7c 01             	add    ax,0x17c
     489:	ff                   	(bad)
     48a:	ff 22                	jmp    WORD PTR [bp+si]
     48c:	4f                   	dec    di
     48d:	a9 04 01             	test   ax,0x104
     490:	00 00                	add    BYTE PTR [bx+si],al
     492:	00 00                	add    BYTE PTR [bx+si],al
     494:	80 00 00             	add    BYTE PTR [bx+si],0x0
     497:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     49b:	03 53 51             	add    dx,WORD PTR [bp+di+0x51]
     49e:	4c                   	dec    sp
     49f:	04 09                	add    al,0x9
     4a1:	2e 05 7c 00          	cs add ax,0x7c
     4a5:	fe                   	(bad)
     4a6:	ff c6                	inc    si
     4a8:	4e                   	dec    si
     4a9:	0f 05                	syscall
     4ab:	01 00                	add    WORD PTR [bx+si],ax
     4ad:	00 00                	add    BYTE PTR [bx+si],al
     4af:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     4b3:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     4b7:	0a 44 61             	or     al,BYTE PTR [si+0x61]
     4ba:	74 61                	je     0x51d
     4bc:	53                   	push   bx
     4bd:	6f                   	outs   dx,WORD PTR ds:[si]
     4be:	75 72                	jne    0x532
     4c0:	63 65 07             	arpl   WORD PTR [di+0x7],sp
     4c3:	23 eb                	and    bp,bx
     4c5:	04 8e                	add    al,0x8e
     4c7:	01 ff                	add    di,di
     4c9:	ff 8e 01 ff          	dec    WORD PTR [bp-0xff]
     4cd:	ff 01                	inc    WORD PTR [bx+di]
     4cf:	00 00                	add    BYTE PTR [bx+si],al
     4d1:	00 00                	add    BYTE PTR [bx+si],al
     4d3:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4d6:	00 00                	add    BYTE PTR [bx+si],al
     4d8:	17                   	pop    ss
     4d9:	00 0e 55 6e          	add    BYTE PTR ds:0x6e55,cl
     4dd:	69 44 69 72 65       	imul   ax,WORD PTR [si+0x69],0x6572
     4e2:	63 74 69             	arpl   WORD PTR [si+0x69],si
     4e5:	6f                   	outs   dx,WORD PTR ds:[si]
     4e6:	6e                   	outs   dx,BYTE PTR ds:[si]
     4e7:	61                   	popa
     4e8:	6c                   	ins    BYTE PTR es:[di],dx
     4e9:	07                   	pop    es
     4ea:	23 69 05             	and    bp,WORD PTR [bx+di+0x5]
     4ed:	8f 01                	pop    WORD PTR [bx+di]
     4ef:	ff                   	(bad)
     4f0:	ff 8f 01 ff          	dec    WORD PTR [bx-0xff]
     4f4:	ff 01                	inc    WORD PTR [bx+di]
     4f6:	00 00                	add    BYTE PTR [bx+si],al
     4f8:	00 00                	add    BYTE PTR [bx+si],al
     4fa:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4fd:	00 00                	add    BYTE PTR [bx+si],al
     4ff:	18 00                	sbb    BYTE PTR [bx+si],al
     501:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
     504:	71 75                	jno    0x57b
     506:	65 73 74             	gs jae 0x57d
     509:	4c                   	dec    sp
     50a:	69 76 65 8d 03       	imul   si,WORD PTR [bp+0x65],0x38d
     50f:	17                   	pop    ss
     510:	05 81 01             	add    ax,0x181
     513:	ff                   	(bad)
     514:	ff 91 50 a9          	call   WORD PTR [bx+di-0x56b0]
     518:	05 01 00             	add    ax,0x1
     51b:	00 00                	add    BYTE PTR [bx+si],al
     51d:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     521:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
     525:	06                   	push   es
     526:	50                   	push   ax
     527:	61                   	popa
     528:	72 61                	jb     0x58b
     52a:	6d                   	ins    WORD PTR es:[di],dx
     52b:	73 34                	jae    0x561
     52d:	07                   	pop    es
     52e:	a1 05 22             	mov    ax,ds:0x2205
     531:	01 ff                	add    di,di
     533:	ff 22                	jmp    WORD PTR [bp+si]
     535:	01 ff                	add    di,di
     537:	ff 01                	inc    WORD PTR [bx+di]
     539:	00 00                	add    BYTE PTR [bx+si],al
     53b:	00 00                	add    BYTE PTR [bx+si],al
     53d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     540:	00 00                	add    BYTE PTR [bx+si],al
     542:	1a 00                	sbb    al,BYTE PTR [bx+si]
     544:	0a 55 70             	or     dl,BYTE PTR [di+0x70]
     547:	64 61                	fs popa
     549:	74 65                	je     0x5b0
     54b:	4d                   	dec    bp
     54c:	6f                   	outs   dx,WORD PTR ds:[si]
     54d:	64 65 f0 05 00 00    	fs gs lock add ax,0x0
     553:	00 00                	add    BYTE PTR [bx+si],al
     555:	00 00                	add    BYTE PTR [bx+si],al
     557:	e3 05                	jcxz   0x55e
     559:	62 00                	bound  ax,DWORD PTR [bx+si]
     55b:	b2 0a                	mov    dl,0xa
     55d:	04 06                	add    al,0x6
     55f:	64 20 15             	and    BYTE PTR fs:[di],dl
     562:	06                   	push   es
     563:	9a 1f 61 05 cb       	call   0xcb05:0x611f
     568:	1f                   	pop    ds
     569:	65 05 5e 60          	gs add ax,0x605e
     56d:	79 05                	jns    0x574
     56f:	cd 11                	int    0x11
     571:	9d                   	popf
     572:	06                   	push   es
     573:	6e                   	outs   dx,BYTE PTR ds:[si]
     574:	4f                   	dec    di
     575:	81 05 1d 61          	add    WORD PTR [di],0x611d
     579:	dd 05                	fld    QWORD PTR [di]
     57b:	25 6a 89             	and    ax,0x896a
     57e:	05 f4 4f             	add    ax,0x4ff4
     581:	85 05                	test   WORD PTR [di],ax
     583:	05 4f 8d             	add    ax,0x8d4f
     586:	05 be 6a             	add    ax,0x6abe
     589:	d9 05                	fld    DWORD PTR [di]
     58b:	46                   	inc    si
     58c:	51                   	push   cx
     58d:	91                   	xchg   cx,ax
     58e:	05 38 50             	add    ax,0x5038
     591:	95                   	xchg   bp,ax
     592:	05 1a 50             	add    ax,0x501a
     595:	99                   	cwd
     596:	05 21 50             	add    ax,0x5021
     599:	71 05                	jno    0x5a0
     59b:	7a 5c                	jp     0x5f9
     59d:	00 06 a3 63          	add    BYTE PTR ds:0x63a3,al
     5a1:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     5a2:	05 6d 64             	add    ax,0x646d
     5a5:	7d 05                	jge    0x5ac
     5a7:	d5 5c                	aad    0x5c
     5a9:	ad                   	lods   ax,WORD PTR ds:[si]
     5aa:	05 20 5d             	add    ax,0x5d20
     5ad:	b1 05                	mov    cl,0x5
     5af:	4b                   	dec    bx
     5b0:	5d                   	pop    bp
     5b1:	b5 05                	mov    ch,0x5
     5b3:	76 5d                	jbe    0x612
     5b5:	b9 05 a1             	mov    cx,0xa105
     5b8:	5d                   	pop    bp
     5b9:	bd 05 1f             	mov    bp,0x1f05
     5bc:	5e                   	pop    si
     5bd:	c1 05 34             	rol    WORD PTR [di],0x34
     5c0:	5e                   	pop    si
     5c1:	c5 05                	lds    ax,DWORD PTR [di]
     5c3:	a3 5e c9             	mov    ds:0xc95e,ax
     5c6:	05 c4 5e             	add    ax,0x5ec4
     5c9:	cd 05                	int    0x5
     5cb:	ef                   	out    dx,ax
     5cc:	5e                   	pop    si
     5cd:	d1 05                	rol    WORD PTR [di],1
     5cf:	1d 5f d5             	sbb    ax,0xd55f
     5d2:	05 42 5f             	add    ax,0x5f42
     5d5:	9d                   	popf
     5d6:	05 f6 70             	add    ax,0x70f6
     5d9:	6d                   	ins    WORD PTR es:[di],dx
     5da:	05 f2 63             	add    ax,0x63f2
     5dd:	e1 05                	loope  0x5e4
     5df:	34 6a                	xor    al,0x6a
     5e1:	5d                   	pop    bp
     5e2:	05 0c 54             	add    ax,0x540c
     5e5:	53                   	push   bx
     5e6:	74 72                	je     0x65a
     5e8:	69 6e 67 46 69       	imul   bp,WORD PTR [bp+0x67],0x6946
     5ed:	65 6c                	gs ins BYTE PTR es:[di],dx
     5ef:	64 07                	fs pop es
     5f1:	0c 54                	or     al,0x54
     5f3:	53                   	push   bx
     5f4:	74 72                	je     0x668
     5f6:	69 6e 67 46 69       	imul   bp,WORD PTR [bp+0x67],0x6946
     5fb:	65 6c                	gs ins BYTE PTR es:[di],dx
     5fd:	64 6f                	outs   dx,WORD PTR fs:[si]
     5ff:	05 c5 06             	add    ax,0x6c5
     602:	2d 0b 19             	sub    ax,0x190b
     605:	06                   	push   es
     606:	12 00                	adc    al,BYTE PTR [bx+si]
     608:	08 44 42             	or     BYTE PTR [si+0x42],al
     60b:	54                   	push   sp
     60c:	61                   	popa
     60d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     610:	73 03                	jae    0x615
     612:	00 62 23             	add    BYTE PTR [bp+si+0x23],ah
     615:	36 06                	ss push es
     617:	b2 68                	mov    dl,0x68
     619:	1d 06 30             	sbb    ax,0x3006
     61c:	6f                   	outs   dx,WORD PTR ds:[si]
     61d:	3e 06                	ds push es
     61f:	01 00                	add    WORD PTR [bx+si],ax
     621:	00 00                	add    BYTE PTR [bx+si],al
     623:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     627:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     62b:	08 45 64             	or     BYTE PTR [di+0x64],al
     62e:	69 74 4d 61 73       	imul   si,WORD PTR [si+0x4d],0x7361
     633:	6b e6 22             	imul   sp,si,0x22
     636:	53                   	push   bx
     637:	06                   	push   es
     638:	2a 00                	sub    al,BYTE PTR [bx+si]
     63a:	ff                   	(bad)
     63b:	ff c6                	inc    si
     63d:	70 c9                	jo     0x608
     63f:	06                   	push   es
     640:	01 00                	add    WORD PTR [bx+si],ax
     642:	00 00                	add    BYTE PTR [bx+si],al
     644:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     648:	00 00                	add    BYTE PTR [bx+si],al
     64a:	10 00                	adc    BYTE PTR [bx+si],al
     64c:	04 53                	add    al,0x53
     64e:	69 7a 65 07 23       	imul   di,WORD PTR [bp+si+0x65],0x2307
     653:	91                   	xchg   cx,ax
     654:	06                   	push   es
     655:	60                   	pusha
     656:	00 ff                	add    bh,bh
     658:	ff 60 00             	jmp    WORD PTR [bx+si+0x0]
     65b:	ff                   	(bad)
     65c:	ff 01                	inc    WORD PTR [bx+di]
     65e:	00 00                	add    BYTE PTR [bx+si],al
     660:	00 00                	add    BYTE PTR [bx+si],al
     662:	80 01 00             	add    BYTE PTR [bx+di],0x0
     665:	00 00                	add    BYTE PTR [bx+si],al
     667:	11 00                	adc    WORD PTR [bx+si],ax
     669:	0d 54 72             	or     ax,0x7254
     66c:	61                   	popa
     66d:	6e                   	outs   dx,BYTE PTR ds:[si]
     66e:	73 6c                	jae    0x6dc
     670:	69 74 65 72 61       	imul   si,WORD PTR [si+0x65],0x6172
     675:	74 65                	je     0x6dc
     677:	19 07                	sbb    WORD PTR [bx],ax
     679:	00 00                	add    BYTE PTR [bx+si],al
     67b:	00 00                	add    BYTE PTR [bx+si],al
     67d:	00 00                	add    BYTE PTR [bx+si],al
     67f:	0b 07                	or     ax,WORD PTR [bx]
     681:	68 00 b2             	push   0xb200
     684:	0a 2e 07 64          	or     ch,BYTE PTR ds:0x6407
     688:	20 61 07             	and    BYTE PTR [bx+di+0x7],ah
     68b:	9a 1f 89 06 cb       	call   0xcb06:0x891f
     690:	1f                   	pop    ds
     691:	8d 06 08 60          	lea    ax,ds:0x6008
     695:	2a 07                	sub    al,BYTE PTR [bx]
     697:	cd 11                	int    0x11
     699:	3f                   	aas
     69a:	07                   	pop    es
     69b:	6e                   	outs   dx,BYTE PTR ds:[si]
     69c:	4f                   	dec    di
     69d:	a9 06 1d             	test   ax,0x1d06
     6a0:	61                   	popa
     6a1:	05 07 25             	add    ax,0x2507
     6a4:	6a b1                	push   0xffb1
     6a6:	06                   	push   es
     6a7:	f4                   	hlt
     6a8:	4f                   	dec    di
     6a9:	ad                   	lods   ax,WORD PTR ds:[si]
     6aa:	06                   	push   es
     6ab:	05 4f b5             	add    ax,0xb54f
     6ae:	06                   	push   es
     6af:	be 6a ed             	mov    si,0xed6a
     6b2:	06                   	push   es
     6b3:	46                   	inc    si
     6b4:	51                   	push   cx
     6b5:	b9 06 38             	mov    cx,0x3806
     6b8:	50                   	push   ax
     6b9:	bd 06 1a             	mov    bp,0x1a06
     6bc:	50                   	push   ax
     6bd:	c1 06 21 50 99       	rol    WORD PTR ds:0x5021,0x99
     6c2:	06                   	push   es
     6c3:	a0 5f 95             	mov    al,ds:0x955f
     6c6:	06                   	push   es
     6c7:	a3 63 cd             	mov    ds:0xcd63,ax
     6ca:	06                   	push   es
     6cb:	6d                   	ins    WORD PTR es:[di],dx
     6cc:	64 d1 06 7c 64       	rol    WORD PTR fs:0x647c,1
     6d1:	d5 06                	aad    0x6
     6d3:	9f                   	lahf
     6d4:	64 d9 06 c2 64       	fld    DWORD PTR fs:0x64c2
     6d9:	dd 06 e7 64          	fld    QWORD PTR ds:0x64e7
     6dd:	e1 06                	loope  0x6e5
     6df:	0f 65 e5             	pcmpgtw mm4,mm5
     6e2:	06                   	push   es
     6e3:	c2 67 e9             	ret    0xe967
     6e6:	06                   	push   es
     6e7:	fe                   	(bad)
     6e8:	69 a5 06 0e 6b f1    	imul   sp,WORD PTR [di+0xe06],0xf16b
     6ee:	06                   	push   es
     6ef:	2d 6b f5             	sub    ax,0xf56b
     6f2:	06                   	push   es
     6f3:	49                   	dec    cx
     6f4:	6b f9 06             	imul   di,cx,0x6
     6f7:	67 6b fd 06          	addr32 imul di,bp,0x6
     6fb:	84 6b 01             	test   BYTE PTR [bp+di+0x1],ch
     6fe:	07                   	pop    es
     6ff:	f6 70 a1             	div    BYTE PTR [bx+si-0x5f]
     702:	06                   	push   es
     703:	f2 63 09             	repnz arpl WORD PTR [bx+di],cx
     706:	07                   	pop    es
     707:	34 6a                	xor    al,0x6a
     709:	85 06 0d 54          	test   WORD PTR ds:0x540d,ax
     70d:	4e                   	dec    si
     70e:	75 6d                	jne    0x77d
     710:	65 72 69             	gs jb  0x77c
     713:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     716:	65 6c                	gs ins BYTE PTR es:[di],dx
     718:	64 07                	fs pop es
     71a:	0d 54 4e             	or     ax,0x4e54
     71d:	75 6d                	jne    0x78c
     71f:	65 72 69             	gs jb  0x78b
     722:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     725:	65 6c                	gs ins BYTE PTR es:[di],dx
     727:	64 97                	fs xchg di,ax
     729:	06                   	push   es
     72a:	65 07                	gs pop es
     72c:	2d 0b 47             	sub    ax,0x470b
     72f:	07                   	pop    es
     730:	11 00                	adc    WORD PTR [bx+si],ax
     732:	08 44 42             	or     BYTE PTR [si+0x42],al
     735:	54                   	push   sp
     736:	61                   	popa
     737:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     73a:	73 03                	jae    0x73f
     73c:	00 02                	add    BYTE PTR [bp+si],al
     73e:	00 ce                	add    dh,cl
     740:	07                   	pop    es
     741:	25 00 ff             	and    ax,0xff00
     744:	ff 9a 6b fa          	call   DWORD PTR [bp+si-0x595]
     748:	07                   	pop    es
     749:	01 00                	add    WORD PTR [bx+si],ax
     74b:	00 00                	add    BYTE PTR [bx+si],al
     74d:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     751:	00 00                	add    BYTE PTR [bx+si],al
     753:	02 00                	add    al,BYTE PTR [bx+si]
     755:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
     758:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
     75d:	6e                   	outs   dx,BYTE PTR ds:[si]
     75e:	74 62                	je     0x7c2
     760:	23 87 07 47          	and    ax,WORD PTR [bx+0x4707]
     764:	60                   	pusha
     765:	69 07 f9 60          	imul   ax,WORD PTR [bx],0x60f9
     769:	8b 07                	mov    ax,WORD PTR [bx]
     76b:	01 00                	add    WORD PTR [bx+si],ax
     76d:	00 00                	add    BYTE PTR [bx+si],al
     76f:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     773:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     777:	0d 44 69             	or     ax,0x6944
     77a:	73 70                	jae    0x7ec
     77c:	6c                   	ins    BYTE PTR es:[di],dx
     77d:	61                   	popa
     77e:	79 46                	jns    0x7c6
     780:	6f                   	outs   dx,WORD PTR ds:[si]
     781:	72 6d                	jb     0x7f0
     783:	61                   	popa
     784:	74 62                	je     0x7e8
     786:	23 c2                	and    ax,dx
     788:	07                   	pop    es
     789:	64 60                	fs pusha
     78b:	8f 07                	pop    WORD PTR [bx]
     78d:	34 61                	xor    al,0x61
     78f:	0a 08                	or     cl,BYTE PTR [bx+si]
     791:	01 00                	add    WORD PTR [bx+si],ax
     793:	00 00                	add    BYTE PTR [bx+si],al
     795:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     799:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     79d:	0a 45 64             	or     al,BYTE PTR [di+0x64]
     7a0:	69 74 46 6f 72       	imul   si,WORD PTR [si+0x46],0x726f
     7a5:	6d                   	ins    WORD PTR es:[di],dx
     7a6:	61                   	popa
     7a7:	74 4a                	je     0x7f3
     7a9:	08 00                	or     BYTE PTR [bx+si],al
     7ab:	00 00                	add    BYTE PTR [bx+si],al
     7ad:	00 00                	add    BYTE PTR [bx+si],al
     7af:	00 3c                	add    BYTE PTR [si],bh
     7b1:	08 78 00             	or     BYTE PTR [bx+si+0x0],bh
     7b4:	97                   	xchg   di,ax
     7b5:	06                   	push   es
     7b6:	5b                   	pop    bx
     7b7:	08 64 20             	or     BYTE PTR [si+0x20],ah
     7ba:	70 08                	jo     0x7c4
     7bc:	9a 1f ba 07 cb       	call   0xcb07:0xba1f
     7c1:	1f                   	pop    ds
     7c2:	be 07 08             	mov    si,0x807
     7c5:	60                   	pusha
     7c6:	b6 07                	mov    dh,0x7
     7c8:	cd 11                	int    0x11
     7ca:	d6                   	(bad)
     7cb:	08 6e 4f             	or     BYTE PTR [bp+0x4f],ch
     7ce:	da 07                	fiadd  DWORD PTR [bx]
     7d0:	1d 61 36             	sbb    ax,0x3661
     7d3:	08 25                	or     BYTE PTR [di],ah
     7d5:	6a e2                	push   0xffe2
     7d7:	07                   	pop    es
     7d8:	f4                   	hlt
     7d9:	4f                   	dec    di
     7da:	de 07                	fiadd  WORD PTR [bx]
     7dc:	05 4f e6             	add    ax,0xe64f
     7df:	07                   	pop    es
     7e0:	be 6a 1e             	mov    si,0x1e6a
     7e3:	08 46 51             	or     BYTE PTR [bp+0x51],al
     7e6:	ea 07 38 50 ee       	jmp    0xee50:0x3807
     7eb:	07                   	pop    es
     7ec:	1a 50 f2             	sbb    dl,BYTE PTR [bx+si-0xe]
     7ef:	07                   	pop    es
     7f0:	21 50 ca             	and    WORD PTR [bx+si-0x36],dx
     7f3:	07                   	pop    es
     7f4:	6f                   	outs   dx,WORD PTR ds:[si]
     7f5:	61                   	popa
     7f6:	3a 08                	cmp    cl,BYTE PTR [bx+si]
     7f8:	a3 63 fe             	mov    ds:0xfe63,ax
     7fb:	07                   	pop    es
     7fc:	6d                   	ins    WORD PTR es:[di],dx
     7fd:	64 02 08             	add    cl,BYTE PTR fs:[bx+si]
     800:	7c 64                	jl     0x866
     802:	06                   	push   es
     803:	08 9f 64 16          	or     BYTE PTR [bx+0x1664],bl
     807:	08 33                	or     BYTE PTR [bp+di],dh
     809:	62 0e 08 5d          	bound  cx,DWORD PTR ds:0x5d08
     80d:	62 12                	bound  dx,DWORD PTR [bp+si]
     80f:	08 86 62 1a          	or     BYTE PTR [bp+0x1a62],al
     813:	08 c2                	or     dl,al
     815:	67 d6                	addr32 (bad)
     817:	07                   	pop    es
     818:	bf 62 26             	mov    di,0x2662
     81b:	08 0e 6b 22          	or     BYTE PTR ds:0x226b,cl
     81f:	08 2d                	or     BYTE PTR [di],ch
     821:	6b 32 08             	imul   si,WORD PTR [bp+si],0x8
     824:	ff 63 2a             	jmp    WORD PTR [bp+di+0x2a]
     827:	08 1d                	or     BYTE PTR [di],bl
     829:	64 2e 08 8c 64 f6    	fs or  BYTE PTR cs:[si-0x99c],cl
     82f:	07                   	pop    es
     830:	f6 70 d2             	div    BYTE PTR [bx+si-0x2e]
     833:	07                   	pop    es
     834:	f2 63 02             	repnz arpl WORD PTR [bp+si],ax
     837:	09 d8                	or     ax,bx
     839:	63 c6                	arpl   si,ax
     83b:	07                   	pop    es
     83c:	0d 54 49             	or     ax,0x4954
     83f:	6e                   	outs   dx,BYTE PTR ds:[si]
     840:	74 65                	je     0x8a7
     842:	67 65 72 46          	addr32 gs jb 0x88c
     846:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
     84b:	0d 54 49             	or     ax,0x4954
     84e:	6e                   	outs   dx,BYTE PTR ds:[si]
     84f:	74 65                	je     0x8b6
     851:	67 65 72 46          	addr32 gs jb 0x89b
     855:	69 65 6c 64 c8       	imul   sp,WORD PTR [di+0x6c],0xc864
     85a:	07                   	pop    es
     85b:	5f                   	pop    di
     85c:	08 19                	or     BYTE PTR [bx+di],bl
     85e:	07                   	pop    es
     85f:	78 08                	js     0x869
     861:	13 00                	adc    ax,WORD PTR [bx+si]
     863:	08 44 42             	or     BYTE PTR [si+0x42],al
     866:	54                   	push   sp
     867:	61                   	popa
     868:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     86b:	73 02                	jae    0x86f
     86d:	00 f5                	add    ch,dh
     86f:	22 91 08 74          	and    dl,BYTE PTR [bx+di+0x7408]
     873:	00 ff                	add    bh,bh
     875:	ff 14                	call   WORD PTR [si]
     877:	65 99                	gs cwd
     879:	08 01                	or     BYTE PTR [bx+di],al
     87b:	00 00                	add    BYTE PTR [bx+si],al
     87d:	00 00                	add    BYTE PTR [bx+si],al
     87f:	80 00 00             	add    BYTE PTR [bx+si],0x0
     882:	00 00                	add    BYTE PTR [bx+si],al
     884:	11 00                	adc    WORD PTR [bx+si],ax
     886:	08 4d 61             	or     BYTE PTR [di+0x61],cl
     889:	78 56                	js     0x8e1
     88b:	61                   	popa
     88c:	6c                   	ins    BYTE PTR es:[di],dx
     88d:	75 65                	jne    0x8f4
     88f:	f5                   	cmc
     890:	22 ca                	and    cl,dl
     892:	08 70 00             	or     BYTE PTR [bx+si+0x0],dh
     895:	ff                   	(bad)
     896:	ff 4c 65             	dec    WORD PTR [si+0x65]
     899:	fe 08                	dec    BYTE PTR [bx+si]
     89b:	01 00                	add    WORD PTR [bx+si],ax
     89d:	00 00                	add    BYTE PTR [bx+si],al
     89f:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     8a3:	00 00                	add    BYTE PTR [bx+si],al
     8a5:	12 00                	adc    al,BYTE PTR [bx+si]
     8a7:	08 4d 69             	or     BYTE PTR [di+0x69],cl
     8aa:	6e                   	outs   dx,BYTE PTR ds:[si]
     8ab:	56                   	push   si
     8ac:	61                   	popa
     8ad:	6c                   	ins    BYTE PTR es:[di],dx
     8ae:	75 65                	jne    0x915
     8b0:	53                   	push   bx
     8b1:	09 00                	or     WORD PTR [bx+si],ax
     8b3:	00 00                	add    BYTE PTR [bx+si],al
     8b5:	00 00                	add    BYTE PTR [bx+si],al
     8b7:	00 44 09             	add    BYTE PTR [si+0x9],al
     8ba:	78 00                	js     0x8bc
     8bc:	c8 07 65 09          	enter  0x6507,0x9
     8c0:	64 20 92 09 9a       	and    BYTE PTR fs:[bp+si-0x65f7],dl
     8c5:	1f                   	pop    ds
     8c6:	c2 08 cb             	ret    0xcb08
     8c9:	1f                   	pop    ds
     8ca:	c6                   	(bad)
     8cb:	08 08                	or     BYTE PTR [bx+si],cl
     8cd:	60                   	pusha
     8ce:	be 08 cd             	mov    si,0xcd08
     8d1:	11 9e 09 6e          	adc    WORD PTR [bp+0x6e09],bx
     8d5:	4f                   	dec    di
     8d6:	e2 08                	loop   0x8e0
     8d8:	1d 61 3e             	sbb    ax,0x3e61
     8db:	09 25                	or     WORD PTR [di],sp
     8dd:	6a ea                	push   0xffea
     8df:	08 f4                	or     ah,dh
     8e1:	4f                   	dec    di
     8e2:	e6 08                	out    0x8,al
     8e4:	05 4f ee             	add    ax,0xee4f
     8e7:	08 be 6a 26          	or     BYTE PTR [bp+0x266a],bh
     8eb:	09 46 51             	or     WORD PTR [bp+0x51],ax
     8ee:	f2 08 38             	repnz or BYTE PTR [bx+si],bh
     8f1:	50                   	push   ax
     8f2:	f6 08 1a             	test   BYTE PTR [bx+si],0x1a
     8f5:	50                   	push   ax
     8f6:	fa                   	cli
     8f7:	08 21                	or     BYTE PTR [bx+di],ah
     8f9:	50                   	push   ax
     8fa:	d2 08                	ror    BYTE PTR [bx+si],cl
     8fc:	84 65 12             	test   BYTE PTR [di+0x12],ah
     8ff:	09 a3 63 06          	or     WORD PTR [bp+di+0x663],sp
     903:	09 6d 64             	or     WORD PTR [di+0x64],bp
     906:	0a 09                	or     cl,BYTE PTR [bx+di]
     908:	7c 64                	jl     0x96e
     90a:	0e                   	push   cs
     90b:	09 9f 64 1e          	or     WORD PTR [bx+0x1e64],bx
     90f:	09 33                	or     WORD PTR [bp+di],si
     911:	62 16 09 5d          	bound  dx,DWORD PTR ds:0x5d09
     915:	62 1a                	bound  bx,DWORD PTR [bp+si]
     917:	09 86 62 22          	or     WORD PTR [bp+0x2262],ax
     91b:	09 c2                	or     dx,ax
     91d:	67 de 08             	fimul  WORD PTR [eax]
     920:	bf 62 2e             	mov    di,0x2e62
     923:	09 0e 6b 2a          	or     WORD PTR ds:0x2a6b,cx
     927:	09 2d                	or     WORD PTR [di],bp
     929:	6b 3a 09             	imul   di,WORD PTR [bp+si],0x9
     92c:	ff 63 32             	jmp    WORD PTR [bp+di+0x32]
     92f:	09 1d                	or     WORD PTR [di],bx
     931:	64 36 09 8c 64 42    	fs or  WORD PTR ss:[si+0x4264],cx
     937:	09 f6                	or     si,si
     939:	70 da                	jo     0x915
     93b:	08 f2                	or     dl,dh
     93d:	63 ca                	arpl   dx,cx
     93f:	09 d8                	or     ax,bx
     941:	63 ce                	arpl   si,cx
     943:	08 0e 54 53          	or     BYTE PTR ds:0x5354,cl
     947:	6d                   	ins    WORD PTR es:[di],dx
     948:	61                   	popa
     949:	6c                   	ins    BYTE PTR es:[di],dx
     94a:	6c                   	ins    BYTE PTR es:[di],dx
     94b:	69 6e 74 46 69       	imul   bp,WORD PTR [bp+0x74],0x6946
     950:	65 6c                	gs ins BYTE PTR es:[di],dx
     952:	64 07                	fs pop es
     954:	0e                   	push   cs
     955:	54                   	push   sp
     956:	53                   	push   bx
     957:	6d                   	ins    WORD PTR es:[di],dx
     958:	61                   	popa
     959:	6c                   	ins    BYTE PTR es:[di],dx
     95a:	6c                   	ins    BYTE PTR es:[di],dx
     95b:	69 6e 74 46 69       	imul   bp,WORD PTR [bp+0x74],0x6946
     960:	65 6c                	gs ins BYTE PTR es:[di],dx
     962:	64 d0 08             	ror    BYTE PTR fs:[bx+si],1
     965:	69 09 4a 08          	imul   cx,WORD PTR [bx+di],0x84a
     969:	c6                   	(bad)
     96a:	09 13                	or     WORD PTR [bp+di],dx
     96c:	00 08                	add    BYTE PTR [bx+si],cl
     96e:	44                   	inc    sp
     96f:	42                   	inc    dx
     970:	54                   	push   sp
     971:	61                   	popa
     972:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     975:	73 00                	jae    0x977
     977:	00 17                	add    BYTE PTR [bx],dl
     979:	0a 00                	or     al,BYTE PTR [bx+si]
     97b:	00 00                	add    BYTE PTR [bx+si],al
     97d:	00 00                	add    BYTE PTR [bx+si],al
     97f:	00 0c                	add    BYTE PTR [si],cl
     981:	0a 78 00             	or     bh,BYTE PTR [bx+si+0x0]
     984:	c8 07 25 0a          	enter  0x2507,0xa
     988:	64 20 52 0a          	and    BYTE PTR fs:[bp+si+0xa],dl
     98c:	9a 1f 8a 09 cb       	call   0xcb09:0x8a1f
     991:	1f                   	pop    ds
     992:	8e 09                	mov    cs,WORD PTR [bx+di]
     994:	08 60 86             	or     BYTE PTR [bx+si-0x7a],ah
     997:	09 cd                	or     bp,cx
     999:	11 5e 0a             	adc    WORD PTR [bp+0xa],bx
     99c:	6e                   	outs   dx,BYTE PTR ds:[si]
     99d:	4f                   	dec    di
     99e:	aa                   	stos   BYTE PTR es:[di],al
     99f:	09 1d                	or     WORD PTR [di],bx
     9a1:	61                   	popa
     9a2:	06                   	push   es
     9a3:	0a 25                	or     ah,BYTE PTR [di]
     9a5:	6a b2                	push   0xffb2
     9a7:	09 f4                	or     sp,si
     9a9:	4f                   	dec    di
     9aa:	ae                   	scas   al,BYTE PTR es:[di]
     9ab:	09 05                	or     WORD PTR [di],ax
     9ad:	4f                   	dec    di
     9ae:	b6 09                	mov    dh,0x9
     9b0:	be 6a ee             	mov    si,0xee6a
     9b3:	09 46 51             	or     WORD PTR [bp+0x51],ax
     9b6:	ba 09 38             	mov    dx,0x3809
     9b9:	50                   	push   ax
     9ba:	be 09 1a             	mov    si,0x1a09
     9bd:	50                   	push   ax
     9be:	c2 09 21             	ret    0x2109
     9c1:	50                   	push   ax
     9c2:	9a 09 e6 65 da       	call   0xda65:0xe609
     9c7:	09 a3 63 ce          	or     WORD PTR [bp+di-0x319d],sp
     9cb:	09 6d 64             	or     WORD PTR [di+0x64],bp
     9ce:	d2 09                	ror    BYTE PTR [bx+di],cl
     9d0:	7c 64                	jl     0xa36
     9d2:	d6                   	(bad)
     9d3:	09 9f 64 e6          	or     WORD PTR [bx-0x199c],bx
     9d7:	09 33                	or     WORD PTR [bp+di],si
     9d9:	62 de 09             	(bad)  {k5},{ru-bad}
     9dc:	5d                   	pop    bp
     9dd:	62 e2 09             	(bad)  {k6}{z}
     9e0:	86 62 ea             	xchg   BYTE PTR [bp+si-0x16],ah
     9e3:	09 c2                	or     dx,ax
     9e5:	67 a6                	cmps   BYTE PTR ds:[esi],BYTE PTR es:[edi]
     9e7:	09 bf 62 f6          	or     WORD PTR [bx-0x99e],di
     9eb:	09 0e 6b f2          	or     WORD PTR ds:0xf26b,cx
     9ef:	09 2d                	or     WORD PTR [di],bp
     9f1:	6b 02 0a             	imul   ax,WORD PTR [bp+si],0xa
     9f4:	ff 63 fa             	jmp    WORD PTR [bp+di-0x6]
     9f7:	09 1d                	or     WORD PTR [di],bx
     9f9:	64 fe 09             	dec    BYTE PTR fs:[bx+di]
     9fc:	8c 64 0a             	mov    WORD PTR [si+0xa],fs
     9ff:	0a f6                	or     dh,dh
     a01:	70 a2                	jo     0x9a5
     a03:	09 f2                	or     dx,si
     a05:	63 8a 0a d8          	arpl   WORD PTR [bp+si-0x27f6],cx
     a09:	63 96 09 0a          	arpl   WORD PTR [bp+0xa09],dx
     a0d:	54                   	push   sp
     a0e:	57                   	push   di
     a0f:	6f                   	outs   dx,WORD PTR ds:[si]
     a10:	72 64                	jb     0xa76
     a12:	46                   	inc    si
     a13:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
     a18:	0a 54 57             	or     dl,BYTE PTR [si+0x57]
     a1b:	6f                   	outs   dx,WORD PTR ds:[si]
     a1c:	72 64                	jb     0xa82
     a1e:	46                   	inc    si
     a1f:	69 65 6c 64 98       	imul   sp,WORD PTR [di+0x6c],0x9864
     a24:	09 29                	or     WORD PTR [bx+di],bp
     a26:	0a 4a 08             	or     cl,BYTE PTR [bp+si+0x8]
     a29:	9a 0a 13 00 08       	call   0x800:0x130a
     a2e:	44                   	inc    sp
     a2f:	42                   	inc    dx
     a30:	54                   	push   sp
     a31:	61                   	popa
     a32:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a35:	73 00                	jae    0xa37
     a37:	00 d8                	add    al,bl
     a39:	0a 00                	or     al,BYTE PTR [bx+si]
     a3b:	00 00                	add    BYTE PTR [bx+si],al
     a3d:	00 00                	add    BYTE PTR [bx+si],al
     a3f:	00 cc                	add    ah,cl
     a41:	0a 7c 00             	or     bh,BYTE PTR [si+0x0]
     a44:	97                   	xchg   di,ax
     a45:	06                   	push   es
     a46:	e7 0a                	out    0xa,ax
     a48:	64 20 fc             	fs and ah,bh
     a4b:	0a 9a 1f 4a          	or     bl,BYTE PTR [bp+si+0x4a1f]
     a4f:	0a cb                	or     cl,bl
     a51:	1f                   	pop    ds
     a52:	4e                   	dec    si
     a53:	0a 08                	or     cl,BYTE PTR [bx+si]
     a55:	60                   	pusha
     a56:	46                   	inc    si
     a57:	0a cd                	or     cl,ch
     a59:	11 a5 0b 6e          	adc    WORD PTR [di+0x6e0b],sp
     a5d:	4f                   	dec    di
     a5e:	6a 0a                	push   0xa
     a60:	1d 61 c6             	sbb    ax,0xc661
     a63:	0a 25                	or     ah,BYTE PTR [di]
     a65:	6a 72                	push   0x72
     a67:	0a f4                	or     dh,ah
     a69:	4f                   	dec    di
     a6a:	6e                   	outs   dx,BYTE PTR ds:[si]
     a6b:	0a 05                	or     al,BYTE PTR [di]
     a6d:	4f                   	dec    di
     a6e:	76 0a                	jbe    0xa7a
     a70:	be 6a ae             	mov    si,0xae6a
     a73:	0a 46 51             	or     al,BYTE PTR [bp+0x51]
     a76:	7a 0a                	jp     0xa82
     a78:	38 50 7e             	cmp    BYTE PTR [bx+si+0x7e],dl
     a7b:	0a 1a                	or     bl,BYTE PTR [bp+si]
     a7d:	50                   	push   ax
     a7e:	82 0a 21             	or     BYTE PTR [bp+si],0x21
     a81:	50                   	push   ax
     a82:	5a                   	pop    dx
     a83:	0a 46 66             	or     al,BYTE PTR [bp+0x66]
     a86:	ca 0a a3             	retf   0xa30a
     a89:	63 8e 0a 6d          	arpl   WORD PTR [bp+0x6d0a],cx
     a8d:	64 92                	fs xchg dx,ax
     a8f:	0a 7c 64             	or     bh,BYTE PTR [si+0x64]
     a92:	96                   	xchg   si,ax
     a93:	0a 9f 64 a6          	or     bl,BYTE PTR [bx-0x599c]
     a97:	0a 9a 66 9e          	or     bl,BYTE PTR [bp+si-0x619a]
     a9b:	0a c7                	or     al,bh
     a9d:	66 a2 0a ec          	data32 mov ds:0xec0a,al
     aa1:	66 aa                	data32 stos BYTE PTR es:[di],al
     aa3:	0a c2                	or     al,dl
     aa5:	67 66 0a 37          	data32 or dh,BYTE PTR [edi]
     aa9:	67 b6 0a             	addr32 mov dh,0xa
     aac:	0e                   	push   cs
     aad:	6b b2 0a 2d 6b       	imul   si,WORD PTR [bp+si+0x2d0a],0x6b
     ab2:	c2 0a ec             	ret    0xec0a
     ab5:	68 ba 0a             	push   0xaba
     ab8:	a0 69 be             	mov    al,ds:0xbe69
     abb:	0a c2                	or     al,dl
     abd:	69 86 0a f6 70 62    	imul   ax,WORD PTR [bp-0x9f6],0x6270
     ac3:	0a f2                	or     dh,dl
     ac5:	63 d1                	arpl   cx,dx
     ac7:	0b a6 68 56          	or     sp,WORD PTR [bp+0x5668]
     acb:	0a 0b                	or     cl,BYTE PTR [bp+di]
     acd:	54                   	push   sp
     ace:	46                   	inc    si
     acf:	6c                   	ins    BYTE PTR es:[di],dx
     ad0:	6f                   	outs   dx,WORD PTR ds:[si]
     ad1:	61                   	popa
     ad2:	74 46                	je     0xb1a
     ad4:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
     ad9:	0b 54 46             	or     dx,WORD PTR [si+0x46]
     adc:	6c                   	ins    BYTE PTR es:[di],dx
     add:	6f                   	outs   dx,WORD PTR ds:[si]
     ade:	61                   	popa
     adf:	74 46                	je     0xb27
     ae1:	69 65 6c 64 58       	imul   sp,WORD PTR [di+0x6c],0x5864
     ae6:	0a eb                	or     ch,bl
     ae8:	0a 19                	or     bl,BYTE PTR [bx+di]
     aea:	07                   	pop    es
     aeb:	04 0b                	add    al,0xb
     aed:	15 00 08             	adc    ax,0x800
     af0:	44                   	inc    sp
     af1:	42                   	inc    dx
     af2:	54                   	push   sp
     af3:	61                   	popa
     af4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     af7:	73 04                	jae    0xafd
     af9:	00 07                	add    BYTE PTR [bx],al
     afb:	23 1d                	and    bx,WORD PTR [di]
     afd:	0b 68 00             	or     bp,WORD PTR [bx+si+0x0]
     b00:	ff                   	(bad)
     b01:	ff 59 6a             	call   DWORD PTR [bx+di+0x6a]
     b04:	25 0b 01             	and    ax,0x10b
     b07:	00 00                	add    BYTE PTR [bx+si],al
     b09:	00 00                	add    BYTE PTR [bx+si],al
     b0b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b0e:	00 00                	add    BYTE PTR [bx+si],al
     b10:	11 00                	adc    WORD PTR [bx+si],ax
     b12:	08 43 75             	or     BYTE PTR [bp+di+0x75],al
     b15:	72 72                	jb     0xb89
     b17:	65 6e                	outs   dx,BYTE PTR gs:[si]
     b19:	63 79 40             	arpl   WORD PTR [bx+di+0x40],di
     b1c:	23 3e 0b 74          	and    di,WORD PTR ds:0x740b
     b20:	00 ff                	add    bh,bh
     b22:	ff                   	(bad)
     b23:	7c 6a                	jl     0xb8f
     b25:	46                   	inc    si
     b26:	0b 01                	or     ax,WORD PTR [bx+di]
     b28:	00 00                	add    BYTE PTR [bx+si],al
     b2a:	00 00                	add    BYTE PTR [bx+si],al
     b2c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b2f:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
     b33:	08 4d 61             	or     BYTE PTR [di+0x61],cl
     b36:	78 56                	js     0xb8e
     b38:	61                   	popa
     b39:	6c                   	ins    BYTE PTR es:[di],dx
     b3a:	75 65                	jne    0xba1
     b3c:	40                   	inc    ax
     b3d:	23 5f 0b             	and    bx,WORD PTR [bx+0xb]
     b40:	6c                   	ins    BYTE PTR es:[di],dx
     b41:	00 ff                	add    bh,bh
     b43:	ff 98 6a 67          	call   DWORD PTR [bx+si+0x676a]
     b47:	0b 01                	or     ax,WORD PTR [bx+di]
     b49:	00 00                	add    BYTE PTR [bx+si],al
     b4b:	00 00                	add    BYTE PTR [bx+si],al
     b4d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b50:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
     b54:	08 4d 69             	or     BYTE PTR [di+0x69],cl
     b57:	6e                   	outs   dx,BYTE PTR ds:[si]
     b58:	56                   	push   si
     b59:	61                   	popa
     b5a:	6c                   	ins    BYTE PTR es:[di],dx
     b5b:	75 65                	jne    0xbc2
     b5d:	d4 22                	aam    0x22
     b5f:	99                   	cwd
     b60:	0b 6a 00             	or     bp,WORD PTR [bp+si+0x0]
     b63:	ff                   	(bad)
     b64:	ff b4 6a cd          	push   WORD PTR [si-0x3296]
     b68:	0b 01                	or     ax,WORD PTR [bx+di]
     b6a:	00 00                	add    BYTE PTR [bx+si],al
     b6c:	00 00                	add    BYTE PTR [bx+si],al
     b6e:	80 0f 00             	or     BYTE PTR [bx],0x0
     b71:	00 00                	add    BYTE PTR [bx+si],al
     b73:	14 00                	adc    al,0x0
     b75:	09 50 72             	or     WORD PTR [bx+si+0x72],dx
     b78:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     b7c:	69 6f 6e 22 0c       	imul   bp,WORD PTR [bx+0x6e],0xc22
     b81:	00 00                	add    BYTE PTR [bx+si],al
     b83:	00 00                	add    BYTE PTR [bx+si],al
     b85:	00 00                	add    BYTE PTR [bx+si],al
     b87:	13 0c                	adc    cx,WORD PTR [si]
     b89:	7c 00                	jl     0xb8b
     b8b:	58                   	pop    ax
     b8c:	0a 34                	or     dh,BYTE PTR [si]
     b8e:	0c 64                	or     al,0x64
     b90:	20 61 0c             	and    BYTE PTR [bx+di+0xc],ah
     b93:	9a 1f 91 0b cb       	call   0xcb0b:0x911f
     b98:	1f                   	pop    ds
     b99:	95                   	xchg   bp,ax
     b9a:	0b 08                	or     cx,WORD PTR [bx+si]
     b9c:	60                   	pusha
     b9d:	8d 0b                	lea    cx,[bp+di]
     b9f:	cd 11                	int    0x11
     ba1:	6d                   	ins    WORD PTR es:[di],dx
     ba2:	0c 6e                	or     al,0x6e
     ba4:	4f                   	dec    di
     ba5:	b1 0b                	mov    cl,0xb
     ba7:	1d 61 0d             	sbb    ax,0xd61
     baa:	0c 25                	or     al,0x25
     bac:	6a b9                	push   0xffb9
     bae:	0b f4                	or     si,sp
     bb0:	4f                   	dec    di
     bb1:	b5 0b                	mov    ch,0xb
     bb3:	05 4f bd             	add    ax,0xbd4f
     bb6:	0b be 6a f5          	or     di,WORD PTR [bp-0xa96]
     bba:	0b 46 51             	or     ax,WORD PTR [bp+0x51]
     bbd:	c1 0b 38             	ror    WORD PTR [bp+di],0x38
     bc0:	50                   	push   ax
     bc1:	c5 0b                	lds    cx,DWORD PTR [bp+di]
     bc3:	1a 50 c9             	sbb    dl,BYTE PTR [bx+si-0x37]
     bc6:	0b 21                	or     sp,WORD PTR [bx+di]
     bc8:	50                   	push   ax
     bc9:	a1 0b 37             	mov    ax,ds:0x370b
     bcc:	6b e1 0b             	imul   sp,cx,0xb
     bcf:	a3 63 d5             	mov    ds:0xd563,ax
     bd2:	0b 6d 64             	or     bp,WORD PTR [di+0x64]
     bd5:	d9 0b                	(bad)  [bp+di]
     bd7:	7c 64                	jl     0xc3d
     bd9:	dd 0b                	fisttp QWORD PTR [bp+di]
     bdb:	9f                   	lahf
     bdc:	64 ed                	fs in  ax,dx
     bde:	0b 9a 66 e5          	or     bx,WORD PTR [bp+si-0x1a9a]
     be2:	0b c7                	or     ax,di
     be4:	66 e9 0b ec 66 f1    	jmpd   0xf166f7f5
     bea:	0b c2                	or     ax,dx
     bec:	67 ad                	lods   ax,WORD PTR ds:[esi]
     bee:	0b 37                	or     si,WORD PTR [bx]
     bf0:	67 fd                	addr32 std
     bf2:	0b 0e 6b f9          	or     cx,WORD PTR ds:0xf96b
     bf6:	0b 2d                	or     bp,WORD PTR [di]
     bf8:	6b 09 0c             	imul   cx,WORD PTR [bx+di],0xc
     bfb:	ec                   	in     al,dx
     bfc:	68 01 0c             	push   0xc01
     bff:	a0 69 05             	mov    al,ds:0x569
     c02:	0c c2                	or     al,0xc2
     c04:	69 11 0c f6          	imul   dx,WORD PTR [bx+di],0xf60c
     c08:	70 a9                	jo     0xbb3
     c0a:	0b f2                	or     si,dx
     c0c:	63 99 0c a6          	arpl   WORD PTR [bx+di-0x59f4],bx
     c10:	68 9d 0b             	push   0xb9d
     c13:	0e                   	push   cs
     c14:	54                   	push   sp
     c15:	43                   	inc    bx
     c16:	75 72                	jne    0xc8a
     c18:	72 65                	jb     0xc7f
     c1a:	6e                   	outs   dx,BYTE PTR ds:[si]
     c1b:	63 79 46             	arpl   WORD PTR [bx+di+0x46],di
     c1e:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
     c23:	0e                   	push   cs
     c24:	54                   	push   sp
     c25:	43                   	inc    bx
     c26:	75 72                	jne    0xc9a
     c28:	72 65                	jb     0xc8f
     c2a:	6e                   	outs   dx,BYTE PTR ds:[si]
     c2b:	63 79 46             	arpl   WORD PTR [bx+di+0x46],di
     c2e:	69 65 6c 64 9f       	imul   sp,WORD PTR [di+0x6c],0x9f64
     c33:	0b 38                	or     di,WORD PTR [bx+si]
     c35:	0c d8                	or     al,0xd8
     c37:	0a 95 0c 15          	or     dl,BYTE PTR [di+0x150c]
     c3b:	00 08                	add    BYTE PTR [bx+si],cl
     c3d:	44                   	inc    sp
     c3e:	42                   	inc    dx
     c3f:	54                   	push   sp
     c40:	61                   	popa
     c41:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c44:	73 00                	jae    0xc46
     c46:	00 e5                	add    ch,ah
     c48:	0c 00                	or     al,0x0
     c4a:	00 00                	add    BYTE PTR [bx+si],al
     c4c:	00 00                	add    BYTE PTR [bx+si],al
     c4e:	00 db                	add    bl,bl
     c50:	0c 7c                	or     al,0x7c
     c52:	00 58 0a             	add    BYTE PTR [bx+si+0xa],bl
     c55:	f2 0c 64             	repnz or al,0x64
     c58:	20 07                	and    BYTE PTR [bx],al
     c5a:	0d 9a 1f             	or     ax,0x1f9a
     c5d:	59                   	pop    cx
     c5e:	0c cb                	or     al,0xcb
     c60:	1f                   	pop    ds
     c61:	5d                   	pop    bp
     c62:	0c 08                	or     al,0x8
     c64:	60                   	pusha
     c65:	55                   	push   bp
     c66:	0c cd                	or     al,0xcd
     c68:	11 48 0d             	adc    WORD PTR [bx+si+0xd],cx
     c6b:	6e                   	outs   dx,BYTE PTR ds:[si]
     c6c:	4f                   	dec    di
     c6d:	79 0c                	jns    0xc7b
     c6f:	1d 61 d5             	sbb    ax,0xd561
     c72:	0c 25                	or     al,0x25
     c74:	6a 81                	push   0xff81
     c76:	0c f4                	or     al,0xf4
     c78:	4f                   	dec    di
     c79:	7d 0c                	jge    0xc87
     c7b:	05 4f 85             	add    ax,0x854f
     c7e:	0c be                	or     al,0xbe
     c80:	6a bd                	push   0xffbd
     c82:	0c 46                	or     al,0x46
     c84:	51                   	push   cx
     c85:	89 0c                	mov    WORD PTR [si],cx
     c87:	38 50 8d             	cmp    BYTE PTR [bx+si-0x73],dl
     c8a:	0c 1a                	or     al,0x1a
     c8c:	50                   	push   ax
     c8d:	91                   	xchg   cx,ax
     c8e:	0c 21                	or     al,0x21
     c90:	50                   	push   ax
     c91:	69 0c 86 6b          	imul   cx,WORD PTR [si],0x6b86
     c95:	a9 0c a3             	test   ax,0xa30c
     c98:	63 9d 0c 6d          	arpl   WORD PTR [di+0x6d0c],bx
     c9c:	64 a1 0c 7c          	mov    ax,fs:0x7c0c
     ca0:	64 a5                	movs   WORD PTR es:[di],WORD PTR fs:[si]
     ca2:	0c 9f                	or     al,0x9f
     ca4:	64 b5 0c             	fs mov ch,0xc
     ca7:	9a 66 ad 0c c7       	call   0xc70c:0xad66
     cac:	66 b1 0c             	data32 mov cl,0xc
     caf:	ec                   	in     al,dx
     cb0:	66 b9 0c c2 67 75    	mov    ecx,0x7567c20c
     cb6:	0c 37                	or     al,0x37
     cb8:	67 c5 0c 0e          	lds    cx,DWORD PTR [esi+ecx*1]
     cbc:	6b c1 0c             	imul   ax,cx,0xc
     cbf:	2d 6b d1             	sub    ax,0xd16b
     cc2:	0c ec                	or     al,0xec
     cc4:	68 c9 0c             	push   0xcc9
     cc7:	a0 69 cd             	mov    al,ds:0xcd69
     cca:	0c c2                	or     al,0xc2
     ccc:	69 d9 0c f6          	imul   bx,cx,0xf60c
     cd0:	70 71                	jo     0xd43
     cd2:	0c f2                	or     al,0xf2
     cd4:	63 0f                	arpl   WORD PTR [bx],cx
     cd6:	0d a6 68             	or     ax,0x68a6
     cd9:	65 0c 09             	gs or  al,0x9
     cdc:	54                   	push   sp
     cdd:	42                   	inc    dx
     cde:	43                   	inc    bx
     cdf:	44                   	inc    sp
     ce0:	46                   	inc    si
     ce1:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
     ce6:	09 54 42             	or     WORD PTR [si+0x42],dx
     ce9:	43                   	inc    bx
     cea:	44                   	inc    sp
     ceb:	46                   	inc    si
     cec:	69 65 6c 64 67       	imul   sp,WORD PTR [di+0x6c],0x6764
     cf1:	0c f6                	or     al,0xf6
     cf3:	0c d8                	or     al,0xd8
     cf5:	0a 7c 0d             	or     bh,BYTE PTR [si+0xd]
     cf8:	16                   	push   ss
     cf9:	00 08                	add    BYTE PTR [bx+si],cl
     cfb:	44                   	inc    sp
     cfc:	42                   	inc    dx
     cfd:	54                   	push   sp
     cfe:	61                   	popa
     cff:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d02:	73 01                	jae    0xd05
     d04:	00 e6                	add    dh,ah
     d06:	22 3c                	and    bh,BYTE PTR [si]
     d08:	0d 2a 00             	or     ax,0x2a
     d0b:	ff                   	(bad)
     d0c:	ff c6                	inc    si
     d0e:	70 74                	jo     0xd84
     d10:	0d 01 00             	or     ax,0x1
     d13:	00 00                	add    BYTE PTR [bx+si],al
     d15:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     d19:	00 00                	add    BYTE PTR [bx+si],al
     d1b:	15 00 04             	adc    ax,0x400
     d1e:	53                   	push   bx
     d1f:	69 7a 65 c4 0d       	imul   di,WORD PTR [bp+si+0x65],0xdc4
     d24:	00 00                	add    BYTE PTR [bx+si],al
     d26:	00 00                	add    BYTE PTR [bx+si],al
     d28:	00 00                	add    BYTE PTR [bx+si],al
     d2a:	b6 0d                	mov    dh,0xd
     d2c:	84 00                	test   BYTE PTR [bx+si],al
     d2e:	b2 0a                	mov    dl,0xa
     d30:	d9 0d                	(bad)  [di]
     d32:	64 20 ea             	fs and dl,ch
     d35:	0d 9a 1f             	or     ax,0x1f9a
     d38:	34 0d                	xor    al,0xd
     d3a:	cb                   	retf
     d3b:	1f                   	pop    ds
     d3c:	38 0d                	cmp    BYTE PTR [di],cl
     d3e:	39 6c d5             	cmp    WORD PTR [si-0x2b],bp
     d41:	0d cd 11             	or     ax,0x11cd
     d44:	34 0e                	xor    al,0xe
     d46:	6e                   	outs   dx,BYTE PTR ds:[si]
     d47:	4f                   	dec    di
     d48:	54                   	push   sp
     d49:	0d 1d 61             	or     ax,0x611d
     d4c:	b0 0d                	mov    al,0xd
     d4e:	25 6a 5c             	and    ax,0x5c6a
     d51:	0d f4 4f             	or     ax,0x4ff4
     d54:	58                   	pop    ax
     d55:	0d 05 4f             	or     ax,0x4f05
     d58:	60                   	pusha
     d59:	0d be 6a             	or     ax,0x6abe
     d5c:	9c                   	pushf
     d5d:	0d 46 51             	or     ax,0x5146
     d60:	64 0d 38 50          	fs or  ax,0x5038
     d64:	68 0d 1a             	push   0x1a0d
     d67:	50                   	push   ax
     d68:	6c                   	ins    BYTE PTR es:[di],dx
     d69:	0d 21 50             	or     ax,0x5021
     d6c:	44                   	inc    sp
     d6d:	0d d9 6b             	or     ax,0x6bd9
     d70:	40                   	inc    ax
     d71:	0d a3 63             	or     ax,0x63a3
     d74:	78 0d                	js     0xd83
     d76:	6d                   	ins    WORD PTR es:[di],dx
     d77:	64 80 0d 68          	or     BYTE PTR fs:[di],0x68
     d7b:	6c                   	ins    BYTE PTR es:[di],dx
     d7c:	8c 0d                	mov    WORD PTR [di],cs
     d7e:	9f                   	lahf
     d7f:	64 84 0d             	test   BYTE PTR fs:[di],cl
     d82:	c2 64 88             	ret    0x8864
     d85:	0d e7 64             	or     ax,0x64e7
     d88:	94                   	xchg   sp,ax
     d89:	0d 98 6c             	or     ax,0x6c98
     d8c:	90                   	nop
     d8d:	0d e1 6c             	or     ax,0x6ce1
     d90:	98                   	cbw
     d91:	0d fe 69             	or     ax,0x69fe
     d94:	50                   	push   ax
     d95:	0d 71 6d             	or     ax,0x6d71
     d98:	a8 0d                	test   al,0xd
     d9a:	2d 6b a0             	sub    ax,0xa06b
     d9d:	0d 49 6b             	or     ax,0x6b49
     da0:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     da1:	0d 67 6b             	or     ax,0x6b67
     da4:	ac                   	lods   al,BYTE PTR ds:[si]
     da5:	0d 8f 6d             	or     ax,0x6d8f
     da8:	70 0d                	jo     0xdb7
     daa:	f6 70 4c             	div    BYTE PTR [bx+si+0x4c]
     dad:	0d f2 63             	or     ax,0x63f2
     db0:	b4 0d                	mov    ah,0xd
     db2:	34 6a                	xor    al,0x6a
     db4:	30 0d                	xor    BYTE PTR [di],cl
     db6:	0d 54 42             	or     ax,0x4254
     db9:	6f                   	outs   dx,WORD PTR ds:[si]
     dba:	6f                   	outs   dx,WORD PTR ds:[si]
     dbb:	6c                   	ins    BYTE PTR es:[di],dx
     dbc:	65 61                	gs popa
     dbe:	6e                   	outs   dx,BYTE PTR ds:[si]
     dbf:	46                   	inc    si
     dc0:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
     dc5:	0d 54 42             	or     ax,0x4254
     dc8:	6f                   	outs   dx,WORD PTR ds:[si]
     dc9:	6f                   	outs   dx,WORD PTR ds:[si]
     dca:	6c                   	ins    BYTE PTR es:[di],dx
     dcb:	65 61                	gs popa
     dcd:	6e                   	outs   dx,BYTE PTR ds:[si]
     dce:	46                   	inc    si
     dcf:	69 65 6c 64 42       	imul   sp,WORD PTR [di+0x6c],0x4264
     dd4:	0d ee 0d             	or     ax,0xdee
     dd7:	2d 0b 60             	sub    ax,0x600b
     dda:	0e                   	push   cs
     ddb:	10 00                	adc    BYTE PTR [bx+si],al
     ddd:	08 44 42             	or     BYTE PTR [si+0x42],al
     de0:	54                   	push   sp
     de1:	61                   	popa
     de2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     de5:	73 01                	jae    0xde8
     de7:	00 62 23             	add    BYTE PTR [bp+si+0x23],ah
     dea:	28 0e 10 6d          	sub    BYTE PTR ds:0x6d10,cl
     dee:	f2 0d 98 6e          	repnz or ax,0x6e98
     df2:	6c                   	ins    BYTE PTR es:[di],dx
     df3:	0e                   	push   cs
     df4:	01 00                	add    WORD PTR [bx+si],ax
     df6:	00 00                	add    BYTE PTR [bx+si],al
     df8:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     dfc:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     e00:	0d 44 69             	or     ax,0x6944
     e03:	73 70                	jae    0xe75
     e05:	6c                   	ins    BYTE PTR es:[di],dx
     e06:	61                   	popa
     e07:	79 56                	jns    0xe5f
     e09:	61                   	popa
     e0a:	6c                   	ins    BYTE PTR es:[di],dx
     e0b:	75 65                	jne    0xe72
     e0d:	73 b1                	jae    0xdc0
     e0f:	0e                   	push   cs
     e10:	00 00                	add    BYTE PTR [bx+si],al
     e12:	00 00                	add    BYTE PTR [bx+si],al
     e14:	00 00                	add    BYTE PTR [bx+si],al
     e16:	a2 0e 64             	mov    ds:0x640e,al
     e19:	00 b2 0a c7          	add    BYTE PTR [bp+si-0x38f6],dh
     e1d:	0e                   	push   cs
     e1e:	64 20 d8             	fs and al,bl
     e21:	0e                   	push   cs
     e22:	9a 1f 20 0e cb       	call   0xcb0e:0x201f
     e27:	1f                   	pop    ds
     e28:	24 0e                	and    al,0xe
     e2a:	b1 6f                	mov    cl,0x6f
     e2c:	c3                   	ret
     e2d:	0e                   	push   cs
     e2e:	cd 11                	int    0x11
     e30:	43                   	inc    bx
     e31:	0f 6e 4f 40          	movd   mm1,DWORD PTR [bx+0x40]
     e35:	0e                   	push   cs
     e36:	1d 61 9c             	sbb    ax,0x9c61
     e39:	0e                   	push   cs
     e3a:	25 6a 48             	and    ax,0x486a
     e3d:	0e                   	push   cs
     e3e:	f4                   	hlt
     e3f:	4f                   	dec    di
     e40:	44                   	inc    sp
     e41:	0e                   	push   cs
     e42:	05 4f 4c             	add    ax,0x4c4f
     e45:	0e                   	push   cs
     e46:	be 6a 84             	mov    si,0x846a
     e49:	0e                   	push   cs
     e4a:	46                   	inc    si
     e4b:	51                   	push   cx
     e4c:	50                   	push   ax
     e4d:	0e                   	push   cs
     e4e:	38 50 54             	cmp    BYTE PTR [bx+si+0x54],dl
     e51:	0e                   	push   cs
     e52:	1a 50 58             	sbb    dl,BYTE PTR [bx+si+0x58]
     e55:	0e                   	push   cs
     e56:	21 50 30             	and    WORD PTR [bx+si+0x30],dx
     e59:	0e                   	push   cs
     e5a:	58                   	pop    ax
     e5b:	6f                   	outs   dx,WORD PTR ds:[si]
     e5c:	2c 0e                	sub    al,0xe
     e5e:	a3 63 64             	mov    ds:0x6463,ax
     e61:	0e                   	push   cs
     e62:	6d                   	ins    WORD PTR es:[di],dx
     e63:	64 68 0e 7c          	fs push 0x7c0e
     e67:	64 74 0e             	fs je  0xe78
     e6a:	e4 6f                	in     al,0x6f
     e6c:	70 0e                	jo     0xe7c
     e6e:	11 70 78             	adc    WORD PTR [bx+si+0x78],si
     e71:	0e                   	push   cs
     e72:	e7 64                	out    0x64,ax
     e74:	7c 0e                	jl     0xe84
     e76:	31 70 80             	xor    WORD PTR [bx+si-0x80],si
     e79:	0e                   	push   cs
     e7a:	c2 67 3c             	ret    0x3c67
     e7d:	0e                   	push   cs
     e7e:	6b 70 88 0e          	imul   si,WORD PTR [bx+si-0x78],0xe
     e82:	0e                   	push   cs
     e83:	6b 90 0e 84 71       	imul   dx,WORD PTR [bx+si-0x7bf2],0x71
     e88:	8c 0e e7 71          	mov    WORD PTR ds:0x71e7,cs
     e8c:	94                   	xchg   sp,ax
     e8d:	0e                   	push   cs
     e8e:	67 6b 98 0e 06 72 5c 	imul   bx,WORD PTR [eax+0x5c72060e],0xe
     e95:	0e 
     e96:	f6 70 38             	div    BYTE PTR [bx+si+0x38]
     e99:	0e                   	push   cs
     e9a:	f2 63 a0 0e 34       	repnz arpl WORD PTR [bx+si+0x340e],sp
     e9f:	6a 1c                	push   0x1c
     ea1:	0e                   	push   cs
     ea2:	0e                   	push   cs
     ea3:	54                   	push   sp
     ea4:	44                   	inc    sp
     ea5:	61                   	popa
     ea6:	74 65                	je     0xf0d
     ea8:	54                   	push   sp
     ea9:	69 6d 65 46 69       	imul   bp,WORD PTR [di+0x65],0x6946
     eae:	65 6c                	gs ins BYTE PTR es:[di],dx
     eb0:	64 07                	fs pop es
     eb2:	0e                   	push   cs
     eb3:	54                   	push   sp
     eb4:	44                   	inc    sp
     eb5:	61                   	popa
     eb6:	74 65                	je     0xf1d
     eb8:	54                   	push   sp
     eb9:	69 6d 65 46 69       	imul   bp,WORD PTR [di+0x65],0x6946
     ebe:	65 6c                	gs ins BYTE PTR es:[di],dx
     ec0:	64 2e 0e             	fs cs push cs
     ec3:	dc 0e 2d 0b          	fmul   QWORD PTR ds:0xb2d
     ec7:	02 0f                	add    cl,BYTE PTR [bx]
     ec9:	11 00                	adc    WORD PTR [bx+si],ax
     ecb:	08 44 42             	or     BYTE PTR [si+0x42],al
     ece:	54                   	push   sp
     ecf:	61                   	popa
     ed0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ed3:	73 02                	jae    0xed7
     ed5:	00 62 23             	add    BYTE PTR [bp+si+0x23],ah
     ed8:	fe 0e 4e 70          	dec    BYTE PTR ds:0x704e
     edc:	e0 0e                	loopne 0xeec
     ede:	80 72 6b 0f          	xor    BYTE PTR [bp+si+0x6b],0xf
     ee2:	01 00                	add    WORD PTR [bx+si],ax
     ee4:	00 00                	add    BYTE PTR [bx+si],al
     ee6:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     eea:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     eee:	0d 44 69             	or     ax,0x6944
     ef1:	73 70                	jae    0xf63
     ef3:	6c                   	ins    BYTE PTR es:[di],dx
     ef4:	61                   	popa
     ef5:	79 46                	jns    0xf3d
     ef7:	6f                   	outs   dx,WORD PTR ds:[si]
     ef8:	72 6d                	jb     0xf67
     efa:	61                   	popa
     efb:	74 62                	je     0xf5f
     efd:	23 37                	and    si,WORD PTR [bx]
     eff:	0f b2 68 06          	lss    bp,DWORD PTR [bx+si+0x6]
     f03:	0f 30                	wrmsr
     f05:	6f                   	outs   dx,WORD PTR ds:[si]
     f06:	6f                   	outs   dx,WORD PTR ds:[si]
     f07:	0f 01 00             	sgdtw  [bx+si]
     f0a:	00 00                	add    BYTE PTR [bx+si],al
     f0c:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     f10:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     f14:	08 45 64             	or     BYTE PTR [di+0x64],al
     f17:	69 74 4d 61 73       	imul   si,WORD PTR [si+0x4d],0x7361
     f1c:	6b bc 0f 00 00       	imul   di,WORD PTR [si+0xf],0x0
     f21:	00 00                	add    BYTE PTR [bx+si],al
     f23:	00 00                	add    BYTE PTR [bx+si],al
     f25:	b1 0f                	mov    cl,0xf
     f27:	64 00 2e 0e ca       	add    BYTE PTR fs:0xca0e,ch
     f2c:	0f 64 20             	pcmpgtb mm4,QWORD PTR [bx+si]
     f2f:	f7 0f 9a 1f          	test   WORD PTR [bx],0x1f9a
     f33:	2f                   	das
     f34:	0f cb                	bswap  bx
     f36:	1f                   	pop    ds
     f37:	33 0f                	xor    cx,WORD PTR [bx]
     f39:	b1 6f                	mov    cl,0x6f
     f3b:	2b 0f                	sub    cx,WORD PTR [bx]
     f3d:	cd 11                	int    0x11
     f3f:	03 10                	add    dx,WORD PTR [bx+si]
     f41:	6e                   	outs   dx,BYTE PTR ds:[si]
     f42:	4f                   	dec    di
     f43:	4f                   	dec    di
     f44:	0f 1d 61 ab          	nop    WORD PTR [bx+di-0x55]
     f48:	0f 25                	(bad)
     f4a:	6a 57                	push   0x57
     f4c:	0f f4 4f 53          	pmuludq mm1,QWORD PTR [bx+0x53]
     f50:	0f 05                	syscall
     f52:	4f                   	dec    di
     f53:	5b                   	pop    bx
     f54:	0f be 6a 93          	movsx  bp,BYTE PTR [bp+si-0x6d]
     f58:	0f 46 51 5f          	cmovbe dx,WORD PTR [bx+di+0x5f]
     f5c:	0f 38 50             	(bad)
     f5f:	63 0f                	arpl   WORD PTR [bx],cx
     f61:	1a 50 67             	sbb    dl,BYTE PTR [bx+si+0x67]
     f64:	0f 21 50             	mov    eax,dr2
     f67:	3f                   	aas
     f68:	0f bb 72 7b          	btc    WORD PTR [bp+si+0x7b],si
     f6c:	0f a3 63 73          	bt     WORD PTR [bp+di+0x73],sp
     f70:	0f 6d                	(bad)
     f72:	64 77 0f             	fs ja  0xf84
     f75:	7c 64                	jl     0xfdb
     f77:	83 0f e4             	or     WORD PTR [bx],0xffe4
     f7a:	6f                   	outs   dx,WORD PTR ds:[si]
     f7b:	7f 0f                	jg     0xf8c
     f7d:	11 70 87             	adc    WORD PTR [bx+si-0x79],si
     f80:	0f e7 64 8b          	movntq QWORD PTR [si-0x75],mm4
     f84:	0f 31                	rdtsc
     f86:	70 8f                	jo     0xf17
     f88:	0f c2 67 4b 0f       	cmpps  xmm4,XMMWORD PTR [bx+0x4b],0xf
     f8d:	6b 70 97 0f          	imul   si,WORD PTR [bx+si-0x69],0xf
     f91:	0e                   	push   cs
     f92:	6b 9f 0f 84 71       	imul   bx,WORD PTR [bx-0x7bf1],0x71
     f97:	9b                   	fwait
     f98:	0f e7 71 a3          	movntq QWORD PTR [bx+di-0x5d],mm6
     f9c:	0f 67 6b a7          	packuswb mm5,QWORD PTR [bp+di-0x59]
     fa0:	0f 06                	clts
     fa2:	72 3b                	jb     0xfdf
     fa4:	0f f6 70 47          	psadbw mm6,QWORD PTR [bx+si+0x47]
     fa8:	0f f2 63 af          	pslld  mm4,QWORD PTR [bp+di-0x51]
     fac:	0f 34                	sysenter
     fae:	6a 2f                	push   0x2f
     fb0:	10 0a                	adc    BYTE PTR [bp+si],cl
     fb2:	54                   	push   sp
     fb3:	44                   	inc    sp
     fb4:	61                   	popa
     fb5:	74 65                	je     0x101c
     fb7:	46                   	inc    si
     fb8:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
     fbd:	0a 54 44             	or     dl,BYTE PTR [si+0x44]
     fc0:	61                   	popa
     fc1:	74 65                	je     0x1028
     fc3:	46                   	inc    si
     fc4:	69 65 6c 64 3d       	imul   sp,WORD PTR [di+0x6c],0x3d64
     fc9:	0f ce                	bswap  si
     fcb:	0f b1 0e 2b 10       	cmpxchg WORD PTR ds:0x102b,cx
     fd0:	11 00                	adc    WORD PTR [bx+si],ax
     fd2:	08 44 42             	or     BYTE PTR [si+0x42],al
     fd5:	54                   	push   sp
     fd6:	61                   	popa
     fd7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fda:	73 00                	jae    0xfdc
     fdc:	00 7c 10             	add    BYTE PTR [si+0x10],bh
     fdf:	00 00                	add    BYTE PTR [bx+si],al
     fe1:	00 00                	add    BYTE PTR [bx+si],al
     fe3:	00 00                	add    BYTE PTR [bx+si],al
     fe5:	71 10                	jno    0xff7
     fe7:	64 00 2e 0e 8a       	add    BYTE PTR fs:0x8a0e,ch
     fec:	10 64 20             	adc    BYTE PTR [si+0x20],ah
     fef:	b7 10                	mov    bh,0x10
     ff1:	9a 1f ef 0f cb       	call   0xcb0f:0xef1f
     ff6:	1f                   	pop    ds
     ff7:	f3 0f b1 6f eb       	repz cmpxchg WORD PTR [bx-0x15],bp
     ffc:	0f cd                	bswap  bp
     ffe:	11 c3                	adc    bx,ax
    1000:	10 6e 4f             	adc    BYTE PTR [bp+0x4f],ch
    1003:	0f 10 1d             	movups xmm3,XMMWORD PTR [di]
    1006:	61                   	popa
    1007:	6b 10 25             	imul   dx,WORD PTR [bx+si],0x25
    100a:	6a 17                	push   0x17
    100c:	10 f4                	adc    ah,dh
    100e:	4f                   	dec    di
    100f:	13 10                	adc    dx,WORD PTR [bx+si]
    1011:	05 4f 1b             	add    ax,0x1b4f
    1014:	10 be 6a 53          	adc    BYTE PTR [bp+0x536a],bh
    1018:	10 46 51             	adc    BYTE PTR [bp+0x51],al
    101b:	1f                   	pop    ds
    101c:	10 38                	adc    BYTE PTR [bx+si],bh
    101e:	50                   	push   ax
    101f:	23 10                	and    dx,WORD PTR [bx+si]
    1021:	1a 50 27             	sbb    dl,BYTE PTR [bx+si+0x27]
    1024:	10 21                	adc    BYTE PTR [bx+di],ah
    1026:	50                   	push   ax
    1027:	ff 0f                	dec    WORD PTR [bx]
    1029:	02 73 3b             	add    dh,BYTE PTR [bp+di+0x3b]
    102c:	10 a3 63 33          	adc    BYTE PTR [bp+di+0x3363],ah
    1030:	10 6d 64             	adc    BYTE PTR [di+0x64],ch
    1033:	37                   	aaa
    1034:	10 7c 64             	adc    BYTE PTR [si+0x64],bh
    1037:	43                   	inc    bx
    1038:	10 e4                	adc    ah,ah
    103a:	6f                   	outs   dx,WORD PTR ds:[si]
    103b:	3f                   	aas
    103c:	10 11                	adc    BYTE PTR [bx+di],dl
    103e:	70 47                	jo     0x1087
    1040:	10 e7                	adc    bh,ah
    1042:	64 4b                	fs dec bx
    1044:	10 31                	adc    BYTE PTR [bx+di],dh
    1046:	70 4f                	jo     0x1097
    1048:	10 c2                	adc    dl,al
    104a:	67 0b 10             	or     dx,WORD PTR [eax]
    104d:	6b 70 57 10          	imul   si,WORD PTR [bx+si+0x57],0x10
    1051:	0e                   	push   cs
    1052:	6b 5f 10 84          	imul   bx,WORD PTR [bx+0x10],0xff84
    1056:	71 5b                	jno    0x10b3
    1058:	10 e7                	adc    bh,ah
    105a:	71 63                	jno    0x10bf
    105c:	10 67 6b             	adc    BYTE PTR [bx+0x6b],ah
    105f:	67 10 06             	adc    BYTE PTR [esi],al
    1062:	72 fb                	jb     0x105f
    1064:	0f f6 70 07          	psadbw mm6,QWORD PTR [bx+si+0x7]
    1068:	10 f2                	adc    dl,dh
    106a:	63 6f 10             	arpl   WORD PTR [bx+0x10],bp
    106d:	34 6a                	xor    al,0x6a
    106f:	ef                   	out    dx,ax
    1070:	10 0a                	adc    BYTE PTR [bp+si],cl
    1072:	54                   	push   sp
    1073:	54                   	push   sp
    1074:	69 6d 65 46 69       	imul   bp,WORD PTR [di+0x65],0x6946
    1079:	65 6c                	gs ins BYTE PTR es:[di],dx
    107b:	64 07                	fs pop es
    107d:	0a 54 54             	or     dl,BYTE PTR [si+0x54]
    1080:	69 6d 65 46 69       	imul   bp,WORD PTR [di+0x65],0x6946
    1085:	65 6c                	gs ins BYTE PTR es:[di],dx
    1087:	64 fd                	fs std
    1089:	0f 8e 10 b1          	jle    0xc19d
    108d:	0e                   	push   cs
    108e:	eb 10                	jmp    0x10a0
    1090:	11 00                	adc    WORD PTR [bx+si],ax
    1092:	08 44 42             	or     BYTE PTR [si+0x42],al
    1095:	54                   	push   sp
    1096:	61                   	popa
    1097:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    109a:	73 00                	jae    0x109c
    109c:	00 3d                	add    BYTE PTR [di],bh
    109e:	11 00                	adc    WORD PTR [bx+si],ax
    10a0:	00 00                	add    BYTE PTR [bx+si],al
    10a2:	00 00                	add    BYTE PTR [bx+si],al
    10a4:	00 31                	add    BYTE PTR [bx+di],dh
    10a6:	11 60 00             	adc    WORD PTR [bx+si+0x0],sp
    10a9:	b2 0a                	mov    dl,0xa
    10ab:	50                   	push   ax
    10ac:	11 64 20             	adc    WORD PTR [si+0x20],sp
    10af:	61                   	popa
    10b0:	11 9a 1f af          	adc    WORD PTR [bp+si-0x50e1],bx
    10b4:	10 cb                	adc    bl,cl
    10b6:	1f                   	pop    ds
    10b7:	b3 10                	mov    bl,0x10
    10b9:	5e                   	pop    si
    10ba:	60                   	pusha
    10bb:	c7                   	(bad)
    10bc:	10 cd                	adc    ch,cl
    10be:	11 a2 11 6e          	adc    WORD PTR [bp+si+0x6e11],sp
    10c2:	4f                   	dec    di
    10c3:	cf                   	iret
    10c4:	10 1d                	adc    BYTE PTR [di],bl
    10c6:	61                   	popa
    10c7:	2b 11                	sub    dx,WORD PTR [bx+di]
    10c9:	25 6a d7             	and    ax,0xd76a
    10cc:	10 f4                	adc    ah,dh
    10ce:	4f                   	dec    di
    10cf:	d3 10                	rcl    WORD PTR [bx+si],cl
    10d1:	05 4f db             	add    ax,0xdb4f
    10d4:	10 be 6a 13          	adc    BYTE PTR [bp+0x136a],bh
    10d8:	11 46 51             	adc    WORD PTR [bp+0x51],ax
    10db:	df 10                	fist   WORD PTR [bx+si]
    10dd:	38 50 e3             	cmp    BYTE PTR [bx+si-0x1d],dl
    10e0:	10 1a                	adc    BYTE PTR [bp+si],bl
    10e2:	50                   	push   ax
    10e3:	e7 10                	out    0x10,ax
    10e5:	21 50 bf             	and    WORD PTR [bx+si-0x41],dx
    10e8:	10 49 73             	adc    BYTE PTR [bx+di+0x73],cl
    10eb:	4c                   	dec    sp
    10ec:	11 a3 63 f3          	adc    WORD PTR [bp+di-0xc9d],sp
    10f0:	10 6d 64             	adc    BYTE PTR [di+0x64],ch
    10f3:	f7 10                	not    WORD PTR [bx+si]
    10f5:	7c 64                	jl     0x115b
    10f7:	fb                   	sti
    10f8:	10 9f 64 ff          	adc    BYTE PTR [bx-0x9c],bl
    10fc:	10 c2                	adc    dl,al
    10fe:	64 03 11             	add    dx,WORD PTR fs:[bx+di]
    1101:	e7 64                	out    0x64,ax
    1103:	07                   	pop    es
    1104:	11 0f                	adc    WORD PTR [bx],cx
    1106:	65 0b 11             	or     dx,WORD PTR gs:[bx+di]
    1109:	c2 67 0f             	ret    0xf67
    110c:	11 fe                	adc    si,di
    110e:	69 cb 10 0e          	imul   cx,bx,0xe10
    1112:	6b 17 11             	imul   dx,WORD PTR [bx],0x11
    1115:	2d 6b 1b             	sub    ax,0x1b6b
    1118:	11 49 6b             	adc    WORD PTR [bx+di+0x6b],cx
    111b:	1f                   	pop    ds
    111c:	11 67 6b             	adc    WORD PTR [bx+0x6b],sp
    111f:	23 11                	and    dx,WORD PTR [bx+di]
    1121:	84 6b 27             	test   BYTE PTR [bp+di+0x27],ch
    1124:	11 f6                	adc    si,si
    1126:	70 bb                	jo     0x10e3
    1128:	10 f2                	adc    dl,dh
    112a:	63 2f                	arpl   WORD PTR [bx],bp
    112c:	11 34                	adc    WORD PTR [si],si
    112e:	6a ab                	push   0xffab
    1130:	10 0b                	adc    BYTE PTR [bp+di],cl
    1132:	54                   	push   sp
    1133:	42                   	inc    dx
    1134:	79 74                	jns    0x11aa
    1136:	65 73 46             	gs jae 0x117f
    1139:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
    113e:	0b 54 42             	or     dx,WORD PTR [si+0x42]
    1141:	79 74                	jns    0x11b7
    1143:	65 73 46             	gs jae 0x118c
    1146:	69 65 6c 64 bd       	imul   sp,WORD PTR [di+0x6c],0xbd64
    114b:	10 ca                	adc    dl,cl
    114d:	11 2d                	adc    WORD PTR [di],bp
    114f:	0b 69 11             	or     bp,WORD PTR [bx+di+0x11]
    1152:	10 00                	adc    BYTE PTR [bx+si],al
    1154:	08 44 42             	or     BYTE PTR [si+0x42],al
    1157:	54                   	push   sp
    1158:	61                   	popa
    1159:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    115c:	73 01                	jae    0x115f
    115e:	00 e6                	add    dh,ah
    1160:	22 96 11 2a          	and    dl,BYTE PTR [bp+0x2a11]
    1164:	00 ff                	add    bh,bh
    1166:	ff c6                	inc    si
    1168:	70 ce                	jo     0x1138
    116a:	11 01                	adc    WORD PTR [bx+di],ax
    116c:	00 00                	add    BYTE PTR [bx+si],al
    116e:	00 00                	add    BYTE PTR [bx+si],al
    1170:	80 10 00             	adc    BYTE PTR [bx+si],0x0
    1173:	00 00                	add    BYTE PTR [bx+si],al
    1175:	0f 00 04             	sldt   WORD PTR [si]
    1178:	53                   	push   bx
    1179:	69 7a 65 1f 12       	imul   di,WORD PTR [bp+si+0x65],0x121f
    117e:	00 00                	add    BYTE PTR [bx+si],al
    1180:	00 00                	add    BYTE PTR [bx+si],al
    1182:	00 00                	add    BYTE PTR [bx+si],al
    1184:	10 12                	adc    BYTE PTR [bp+si],dl
    1186:	60                   	pusha
    1187:	00 b2 0a 35          	add    BYTE PTR [bp+si+0x350a],dh
    118b:	12 64 20             	adc    ah,BYTE PTR [si+0x20]
    118e:	46                   	inc    si
    118f:	12 9a 1f 8e          	adc    bl,BYTE PTR [bp+si-0x71e1]
    1193:	11 cb                	adc    bx,cx
    1195:	1f                   	pop    ds
    1196:	92                   	xchg   dx,ax
    1197:	11 5e 60             	adc    WORD PTR [bp+0x60],bx
    119a:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    119b:	11 cd                	adc    bp,cx
    119d:	11 87 12 6e          	adc    WORD PTR [bx+0x6e12],ax
    11a1:	4f                   	dec    di
    11a2:	ae                   	scas   al,BYTE PTR es:[di]
    11a3:	11 1d                	adc    WORD PTR [di],bx
    11a5:	61                   	popa
    11a6:	0a 12                	or     dl,BYTE PTR [bp+si]
    11a8:	25 6a b6             	and    ax,0xb66a
    11ab:	11 f4                	adc    sp,si
    11ad:	4f                   	dec    di
    11ae:	b2 11                	mov    dl,0x11
    11b0:	05 4f ba             	add    ax,0xba4f
    11b3:	11 be 6a f2          	adc    WORD PTR [bp-0xd96],di
    11b7:	11 46 51             	adc    WORD PTR [bp+0x51],ax
    11ba:	be 11 38             	mov    si,0x3811
    11bd:	50                   	push   ax
    11be:	c2 11 1a             	ret    0x1a11
    11c1:	50                   	push   ax
    11c2:	c6                   	(bad)
    11c3:	11 21                	adc    WORD PTR [bx+di],sp
    11c5:	50                   	push   ax
    11c6:	9e                   	sahf
    11c7:	11 90 73 31          	adc    WORD PTR [bx+si+0x3173],dx
    11cb:	12 a3 63 d2          	adc    ah,BYTE PTR [bp+di-0x2d9d]
    11cf:	11 6d 64             	adc    WORD PTR [di+0x64],bp
    11d2:	d6                   	(bad)
    11d3:	11 7c 64             	adc    WORD PTR [si+0x64],di
    11d6:	da 11                	ficom  DWORD PTR [bx+di]
    11d8:	9f                   	lahf
    11d9:	64 de 11             	ficom  WORD PTR fs:[bx+di]
    11dc:	c2 64 e2             	ret    0xe264
    11df:	11 e7                	adc    di,sp
    11e1:	64 e6 11             	fs out 0x11,al
    11e4:	0f 65 ea             	pcmpgtw mm5,mm2
    11e7:	11 c2                	adc    dx,ax
    11e9:	67 ee                	addr32 out dx,al
    11eb:	11 fe                	adc    si,di
    11ed:	69 aa 11 0e 6b f6    	imul   bp,WORD PTR [bp+si+0xe11],0xf66b
    11f3:	11 2d                	adc    WORD PTR [di],bp
    11f5:	6b fa 11             	imul   di,dx,0x11
    11f8:	49                   	dec    cx
    11f9:	6b fe 11             	imul   di,si,0x11
    11fc:	67 6b 02 12          	imul   ax,WORD PTR [edx],0x12
    1200:	84 6b 06             	test   BYTE PTR [bp+di+0x6],ch
    1203:	12 f6                	adc    dh,dh
    1205:	70 9a                	jo     0x11a1
    1207:	11 f2                	adc    dx,si
    1209:	63 0e 12 34          	arpl   WORD PTR ds:0x3412,cx
    120d:	6a 8a                	push   0xff8a
    120f:	11 0e 54 56          	adc    WORD PTR ds:0x5654,cx
    1213:	61                   	popa
    1214:	72 42                	jb     0x1258
    1216:	79 74                	jns    0x128c
    1218:	65 73 46             	gs jae 0x1261
    121b:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
    1220:	0e                   	push   cs
    1221:	54                   	push   sp
    1222:	56                   	push   si
    1223:	61                   	popa
    1224:	72 42                	jb     0x1268
    1226:	79 74                	jns    0x129c
    1228:	65 73 46             	gs jae 0x1271
    122b:	69 65 6c 64 9c       	imul   sp,WORD PTR [di+0x6c],0x9c64
    1230:	11 83 12 2d          	adc    WORD PTR [bp+di+0x2d12],ax
    1234:	0b 4e 12             	or     cx,WORD PTR [bp+0x12]
    1237:	10 00                	adc    BYTE PTR [bx+si],al
    1239:	08 44 42             	or     BYTE PTR [si+0x42],al
    123c:	54                   	push   sp
    123d:	61                   	popa
    123e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1241:	73 01                	jae    0x1244
    1243:	00 e6                	add    dh,ah
    1245:	22 7b 12             	and    bh,BYTE PTR [bp+di+0x12]
    1248:	2a 00                	sub    al,BYTE PTR [bx+si]
    124a:	ff                   	(bad)
    124b:	ff c6                	inc    si
    124d:	70 b3                	jo     0x1202
    124f:	12 01                	adc    al,BYTE PTR [bx+di]
    1251:	00 00                	add    BYTE PTR [bx+si],al
    1253:	00 00                	add    BYTE PTR [bx+si],al
    1255:	80 10 00             	adc    BYTE PTR [bx+si],0x0
    1258:	00 00                	add    BYTE PTR [bx+si],al
    125a:	0f 00 04             	sldt   WORD PTR [si]
    125d:	53                   	push   bx
    125e:	69 7a 65 00 13       	imul   di,WORD PTR [bp+si+0x65],0x1300
    1263:	00 00                	add    BYTE PTR [bx+si],al
    1265:	00 00                	add    BYTE PTR [bx+si],al
    1267:	00 00                	add    BYTE PTR [bx+si],al
    1269:	f5                   	cmc
    126a:	12 62 00             	adc    ah,BYTE PTR [bp+si+0x0]
    126d:	b2 0a                	mov    dl,0xa
    126f:	12 13                	adc    dl,BYTE PTR [bp+di]
    1271:	64 20 23             	and    BYTE PTR fs:[bp+di],ah
    1274:	13 9a 1f 73          	adc    bx,WORD PTR [bp+si+0x731f]
    1278:	12 cb                	adc    cl,bl
    127a:	1f                   	pop    ds
    127b:	77 12                	ja     0x128f
    127d:	5e                   	pop    si
    127e:	60                   	pusha
    127f:	f3 12 fc             	repz adc bh,ah
    1282:	74 b7                	je     0x123b
    1284:	12 6e 4f             	adc    ch,BYTE PTR [bp+0x4f]
    1287:	93                   	xchg   bx,ax
    1288:	12 1e 74 ef          	adc    bl,BYTE PTR ds:0xef74
    128c:	12 25                	adc    ah,BYTE PTR [di]
    128e:	6a 9b                	push   0xff9b
    1290:	12 f4                	adc    dh,ah
    1292:	4f                   	dec    di
    1293:	97                   	xchg   di,ax
    1294:	12 05                	adc    al,BYTE PTR [di]
    1296:	4f                   	dec    di
    1297:	9f                   	lahf
    1298:	12 be 6a d7          	adc    bh,BYTE PTR [bp-0x2896]
    129c:	12 46 51             	adc    al,BYTE PTR [bp+0x51]
    129f:	a3 12 38             	mov    ds:0x3812,ax
    12a2:	50                   	push   ax
    12a3:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
    12a4:	12 1a                	adc    bl,BYTE PTR [bp+si]
    12a6:	50                   	push   ax
    12a7:	ab                   	stos   WORD PTR es:[di],ax
    12a8:	12 21                	adc    ah,BYTE PTR [bx+di]
    12aa:	50                   	push   ax
    12ab:	64 13 d7             	fs adc dx,di
    12ae:	73 8b                	jae    0x123b
    12b0:	12 a3 63 bb          	adc    ah,BYTE PTR [bp+di-0x449d]
    12b4:	12 be 75 af          	adc    bh,BYTE PTR [bp-0x508b]
    12b8:	12 7c 64             	adc    bh,BYTE PTR [si+0x64]
    12bb:	bf 12 9f             	mov    di,0x9f12
    12be:	64 c3                	fs ret
    12c0:	12 c2                	adc    al,dl
    12c2:	64 c7                	fs (bad)
    12c4:	12 e7                	adc    ah,bh
    12c6:	64 cb                	fs retf
    12c8:	12 0f                	adc    cl,BYTE PTR [bx]
    12ca:	65 cf                	gs iret
    12cc:	12 c2                	adc    al,dl
    12ce:	67 d3 12             	rcl    WORD PTR [edx],cl
    12d1:	fe                   	(bad)
    12d2:	69 8f 12 0e 6b db    	imul   cx,WORD PTR [bx+0xe12],0xdb6b
    12d8:	12 2d                	adc    ch,BYTE PTR [di]
    12da:	6b df 12             	imul   bx,di,0x12
    12dd:	49                   	dec    cx
    12de:	6b e3 12             	imul   sp,bx,0x12
    12e1:	67 6b e7 12          	addr32 imul sp,di,0x12
    12e5:	84 6b eb             	test   BYTE PTR [bp+di-0x15],ch
    12e8:	12 f6                	adc    dh,dh
    12ea:	70 7f                	jo     0x136b
    12ec:	12 94 75 0e          	adc    dl,BYTE PTR [si+0xe75]
    12f0:	13 34                	adc    si,WORD PTR [si]
    12f2:	6a 6f                	push   0x6f
    12f4:	12 0a                	adc    cl,BYTE PTR [bp+si]
    12f6:	54                   	push   sp
    12f7:	42                   	inc    dx
    12f8:	6c                   	ins    BYTE PTR es:[di],dx
    12f9:	6f                   	outs   dx,WORD PTR ds:[si]
    12fa:	62 46 69             	bound  ax,DWORD PTR [bp+0x69]
    12fd:	65 6c                	gs ins BYTE PTR es:[di],dx
    12ff:	64 07                	fs pop es
    1301:	0a 54 42             	or     dl,BYTE PTR [si+0x42]
    1304:	6c                   	ins    BYTE PTR es:[di],dx
    1305:	6f                   	outs   dx,WORD PTR ds:[si]
    1306:	62 46 69             	bound  ax,DWORD PTR [bp+0x69]
    1309:	65 6c                	gs ins BYTE PTR es:[di],dx
    130b:	64 81 12 8c 13       	adc    WORD PTR fs:[bp+si],0x138c
    1310:	2d 0b 2b             	sub    ax,0x2b0b
    1313:	13 10                	adc    dx,WORD PTR [bx+si]
    1315:	00 08                	add    BYTE PTR [bx+si],cl
    1317:	44                   	inc    sp
    1318:	42                   	inc    dx
    1319:	54                   	push   sp
    131a:	61                   	popa
    131b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    131e:	73 01                	jae    0x1321
    1320:	00 e6                	add    dh,ah
    1322:	22 58 13             	and    bl,BYTE PTR [bx+si+0x13]
    1325:	2a 00                	sub    al,BYTE PTR [bx+si]
    1327:	ff                   	(bad)
    1328:	ff c6                	inc    si
    132a:	70 90                	jo     0x12bc
    132c:	13 01                	adc    ax,WORD PTR [bx+di]
    132e:	00 00                	add    BYTE PTR [bx+si],al
    1330:	00 00                	add    BYTE PTR [bx+si],al
    1332:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1335:	00 00                	add    BYTE PTR [bx+si],al
    1337:	0f 00 04             	sldt   WORD PTR [si]
    133a:	53                   	push   bx
    133b:	69 7a 65 dd 13       	imul   di,WORD PTR [bp+si+0x65],0x13dd
    1340:	00 00                	add    BYTE PTR [bx+si],al
    1342:	00 00                	add    BYTE PTR [bx+si],al
    1344:	00 00                	add    BYTE PTR [bx+si],al
    1346:	d2 13                	rcl    BYTE PTR [bp+di],cl
    1348:	62 00                	bound  ax,DWORD PTR [bx+si]
    134a:	81 12 eb 13          	adc    WORD PTR [bp+si],0x13eb
    134e:	64 20 18             	and    BYTE PTR fs:[bx+si],bl
    1351:	14 9a                	adc    al,0x9a
    1353:	1f                   	pop    ds
    1354:	50                   	push   ax
    1355:	13 cb                	adc    cx,bx
    1357:	1f                   	pop    ds
    1358:	54                   	push   sp
    1359:	13 5e 60             	adc    bx,WORD PTR [bp+0x60]
    135c:	d0 13                	rcl    BYTE PTR [bp+di],1
    135e:	fc                   	cld
    135f:	74 94                	je     0x12f5
    1361:	13 6e 4f             	adc    bp,WORD PTR [bp+0x4f]
    1364:	70 13                	jo     0x1379
    1366:	1e                   	push   ds
    1367:	74 cc                	je     0x1335
    1369:	13 25                	adc    sp,WORD PTR [di]
    136b:	6a 78                	push   0x78
    136d:	13 f4                	adc    si,sp
    136f:	4f                   	dec    di
    1370:	74 13                	je     0x1385
    1372:	05 4f 7c             	add    ax,0x7c4f
    1375:	13 be 6a b4          	adc    di,WORD PTR [bp-0x4b96]
    1379:	13 46 51             	adc    ax,WORD PTR [bp+0x51]
    137c:	80 13 38             	adc    BYTE PTR [bp+di],0x38
    137f:	50                   	push   ax
    1380:	84 13                	test   BYTE PTR [bp+di],dl
    1382:	1a 50 88             	sbb    dl,BYTE PTR [bx+si-0x78]
    1385:	13 21                	adc    sp,WORD PTR [bx+di]
    1387:	50                   	push   ax
    1388:	24 14                	and    al,0x14
    138a:	32 79 60             	xor    bh,BYTE PTR [bx+di+0x60]
    138d:	13 a3 63 98          	adc    sp,WORD PTR [bp+di-0x679d]
    1391:	13 be 75 68          	adc    di,WORD PTR [bp+0x6875]
    1395:	13 7c 64             	adc    di,WORD PTR [si+0x64]
    1398:	9c                   	pushf
    1399:	13 9f 64 a0          	adc    bx,WORD PTR [bx-0x5f9c]
    139d:	13 c2                	adc    ax,dx
    139f:	64 a4                	movs   BYTE PTR es:[di],BYTE PTR fs:[si]
    13a1:	13 e7                	adc    sp,di
    13a3:	64 a8 13             	fs test al,0x13
    13a6:	0f 65 ac 13 c2       	pcmpgtw mm5,QWORD PTR [si-0x3ded]
    13ab:	67 b0 13             	addr32 mov al,0x13
    13ae:	fe                   	(bad)
    13af:	69 6c 13 0e 6b       	imul   bp,WORD PTR [si+0x13],0x6b0e
    13b4:	b8 13 2d             	mov    ax,0x2d13
    13b7:	6b bc 13 49 6b       	imul   di,WORD PTR [si+0x4913],0x6b
    13bc:	c0 13 67             	rcl    BYTE PTR [bp+di],0x67
    13bf:	6b c4 13             	imul   ax,sp,0x13
    13c2:	84 6b c8             	test   BYTE PTR [bp+di-0x38],ch
    13c5:	13 f6                	adc    si,si
    13c7:	70 5c                	jo     0x1425
    13c9:	13 94 75 4c          	adc    dx,WORD PTR [si+0x4c75]
    13cd:	13 34                	adc    si,WORD PTR [si]
    13cf:	6a 50                	push   0x50
    13d1:	14 0a                	adc    al,0xa
    13d3:	54                   	push   sp
    13d4:	4d                   	dec    bp
    13d5:	65 6d                	gs ins WORD PTR es:[di],dx
    13d7:	6f                   	outs   dx,WORD PTR ds:[si]
    13d8:	46                   	inc    si
    13d9:	69 65 6c 64 07       	imul   sp,WORD PTR [di+0x6c],0x764
    13de:	0a 54 4d             	or     dl,BYTE PTR [si+0x4d]
    13e1:	65 6d                	gs ins WORD PTR es:[di],dx
    13e3:	6f                   	outs   dx,WORD PTR ds:[si]
    13e4:	46                   	inc    si
    13e5:	69 65 6c 64 5e       	imul   sp,WORD PTR [di+0x6c],0x5e64
    13ea:	13 ef                	adc    bp,di
    13ec:	13 00                	adc    ax,WORD PTR [bx+si]
    13ee:	13 4c 14             	adc    cx,WORD PTR [si+0x14]
    13f1:	10 00                	adc    BYTE PTR [bx+si],al
    13f3:	08 44 42             	or     BYTE PTR [si+0x42],al
    13f6:	54                   	push   sp
    13f7:	61                   	popa
    13f8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    13fb:	73 00                	jae    0x13fd
    13fd:	00 a0 14 00          	add    BYTE PTR [bx+si+0x14],ah
    1401:	00 00                	add    BYTE PTR [bx+si],al
    1403:	00 00                	add    BYTE PTR [bx+si],al
    1405:	00 92 14 62          	add    BYTE PTR [bp+si+0x6214],dl
    1409:	00 81 12 b1          	add    BYTE PTR [bx+di-0x4eee],al
    140d:	14 64                	adc    al,0x64
    140f:	20 de                	and    dh,bl
    1411:	14 9a                	adc    al,0x9a
    1413:	1f                   	pop    ds
    1414:	10 14                	adc    BYTE PTR [si],dl
    1416:	cb                   	retf
    1417:	1f                   	pop    ds
    1418:	14 14                	adc    al,0x14
    141a:	5e                   	pop    si
    141b:	60                   	pusha
    141c:	90                   	nop
    141d:	14 fc                	adc    al,0xfc
    141f:	74 54                	je     0x1475
    1421:	14 6e                	adc    al,0x6e
    1423:	4f                   	dec    di
    1424:	30 14                	xor    BYTE PTR [si],dl
    1426:	1e                   	push   ds
    1427:	74 8c                	je     0x13b5
    1429:	14 25                	adc    al,0x25
    142b:	6a 38                	push   0x38
    142d:	14 f4                	adc    al,0xf4
    142f:	4f                   	dec    di
    1430:	34 14                	xor    al,0x14
    1432:	05 4f 3c             	add    ax,0x3c4f
    1435:	14 be                	adc    al,0xbe
    1437:	6a 74                	push   0x74
    1439:	14 46                	adc    al,0x46
    143b:	51                   	push   cx
    143c:	40                   	inc    ax
    143d:	14 38                	adc    al,0x38
    143f:	50                   	push   ax
    1440:	44                   	inc    sp
    1441:	14 1a                	adc    al,0x1a
    1443:	50                   	push   ax
    1444:	48                   	dec    ax
    1445:	14 21                	adc    al,0x21
    1447:	50                   	push   ax
    1448:	d2 14                	rcl    BYTE PTR [si],cl
    144a:	81 79 20 14 a3       	cmp    WORD PTR [bx+di+0x20],0xa314
    144f:	63 58 14             	arpl   WORD PTR [bx+si+0x14],bx
    1452:	be 75 28             	mov    si,0x2875
    1455:	14 7c                	adc    al,0x7c
    1457:	64 5c                	fs pop sp
    1459:	14 9f                	adc    al,0x9f
    145b:	64 60                	fs pusha
    145d:	14 c2                	adc    al,0xc2
    145f:	64 64 14 e7          	fs fs adc al,0xe7
    1463:	64 68 14 0f          	fs push 0xf14
    1467:	65 6c                	gs ins BYTE PTR es:[di],dx
    1469:	14 c2                	adc    al,0xc2
    146b:	67 70 14             	addr32 jo 0x1482
    146e:	fe                   	(bad)
    146f:	69 2c 14 0e          	imul   bp,WORD PTR [si],0xe14
    1473:	6b 78 14 2d          	imul   di,WORD PTR [bx+si+0x14],0x2d
    1477:	6b 7c 14 49          	imul   di,WORD PTR [si+0x14],0x49
    147b:	6b 80 14 67 6b       	imul   ax,WORD PTR [bx+si+0x6714],0x6b
    1480:	84 14                	test   BYTE PTR [si],dl
    1482:	84 6b 88             	test   BYTE PTR [bp+di-0x78],ch
    1485:	14 f6                	adc    al,0xf6
    1487:	70 1c                	jo     0x14a5
    1489:	14 94                	adc    al,0x94
    148b:	75 0c                	jne    0x1499
    148d:	14 34                	adc    al,0x34
    148f:	6a 2e                	push   0x2e
    1491:	15 0d 54             	adc    ax,0x540d
    1494:	47                   	inc    di
    1495:	72 61                	jb     0x14f8
    1497:	70 68                	jo     0x1501
    1499:	69 63 46 69 65       	imul   sp,WORD PTR [bp+di+0x46],0x6569
    149e:	6c                   	ins    BYTE PTR es:[di],dx
    149f:	64 07                	fs pop es
    14a1:	0d 54 47             	or     ax,0x4754
    14a4:	72 61                	jb     0x1507
    14a6:	70 68                	jo     0x1510
    14a8:	69 63 46 69 65       	imul   sp,WORD PTR [bp+di+0x46],0x6569
    14ad:	6c                   	ins    BYTE PTR es:[di],dx
    14ae:	64 1e                	fs push ds
    14b0:	14 b5                	adc    al,0xb5
    14b2:	14 00                	adc    al,0x0
    14b4:	13 e2                	adc    sp,dx
    14b6:	14 10                	adc    al,0x10
    14b8:	00 08                	add    BYTE PTR [bx+si],cl
    14ba:	44                   	inc    sp
    14bb:	42                   	inc    dx
    14bc:	54                   	push   sp
    14bd:	61                   	popa
    14be:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    14c1:	73 00                	jae    0x14c3
	...
    14cb:	00 f0                	add    al,dh
    14cd:	14 1c                	adc    al,0x1c
    14cf:	00 7e 04             	add    BYTE PTR [bp+0x4],bh
    14d2:	1e                   	push   ds
    14d3:	15 64 20             	adc    ax,0x2064
    14d6:	16                   	push   ss
    14d7:	15 9a 1f             	adc    ax,0x1f9a
    14da:	d6                   	(bad)
    14db:	14 cb                	adc    al,0xcb
    14dd:	1f                   	pop    ds
    14de:	da 14                	ficom  DWORD PTR [si]
    14e0:	06                   	push   es
    14e1:	7b e6                	jnp    0x14c9
    14e3:	14 c7                	adc    al,0xc7
    14e5:	7b ea                	jnp    0x14d1
    14e7:	14 12                	adc    al,0x12
    14e9:	7d ee                	jge    0x14d9
    14eb:	14 b0                	adc    al,0xb0
    14ed:	7e 2a                	jle    0x1519
    14ef:	15 0b 54             	adc    ax,0x540b
    14f2:	42                   	inc    dx
    14f3:	6c                   	ins    BYTE PTR es:[di],dx
    14f4:	6f                   	outs   dx,WORD PTR ds:[si]
    14f5:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
    14f8:	72 65                	jb     0x155f
    14fa:	61                   	popa
    14fb:	6d                   	ins    WORD PTR es:[di],dx
    14fc:	5b                   	pop    bx
    14fd:	15 00 00             	adc    ax,0x0
    1500:	00 00                	add    BYTE PTR [bx+si],al
    1502:	00 00                	add    BYTE PTR [bx+si],al
    1504:	4c                   	dec    sp
    1505:	15 42 00             	adc    ax,0x42
    1508:	1d 0d 71             	sbb    ax,0x710d
    150b:	15 64 20             	adc    ax,0x2064
    150e:	9a 15 9a 1f 0e       	call   0xe1f:0x9a15
    1513:	15 cb 1f             	adc    ax,0x1fcb
    1516:	12 15                	adc    dl,BYTE PTR [di]
    1518:	fb                   	sti
    1519:	7f 6d                	jg     0x1588
    151b:	15 cd 11             	adc    ax,0x11cd
    151e:	22 15                	and    dl,BYTE PTR [di]
    1520:	e4 11                	in     al,0x11
    1522:	26 15 fa 10          	es adc ax,0x10fa
    1526:	a2 15 d9             	mov    ds:0xd915,al
    1529:	81 3e 15 0c 7b 32    	cmp    WORD PTR ds:0xc15,0x327b
    152f:	15 13 7b             	adc    ax,0x7b13
    1532:	36 15 2a 7b          	ss adc ax,0x7b2a
    1536:	0a 15                	or     dl,BYTE PTR [di]
    1538:	34 82                	xor    al,0x82
    153a:	42                   	inc    dx
    153b:	15 07 82             	adc    ax,0x8207
    153e:	3a 15                	cmp    dl,BYTE PTR [di]
    1540:	de 82 46 15          	fiadd  WORD PTR [bp+si+0x1546]
    1544:	95                   	xchg   bp,ax
    1545:	82 4a 15 ef          	or     BYTE PTR [bp+si+0x15],0xef
    1549:	82 1a 15             	sbb    BYTE PTR [bp+si],0x15
    154c:	0e                   	push   cs
    154d:	54                   	push   sp
    154e:	46                   	inc    si
    154f:	69 65 6c 64 44       	imul   sp,WORD PTR [di+0x6c],0x4464
    1554:	61                   	popa
    1555:	74 61                	je     0x15b8
    1557:	4c                   	dec    sp
    1558:	69 6e 6b 07 0e       	imul   bp,WORD PTR [bp+0x6b],0xe07
    155d:	54                   	push   sp
    155e:	46                   	inc    si
    155f:	69 65 6c 64 44       	imul   sp,WORD PTR [di+0x6c],0x4464
    1564:	61                   	popa
    1565:	74 61                	je     0x15c8
    1567:	4c                   	dec    sp
    1568:	69 6e 6b 1c 15       	imul   bp,WORD PTR [bp+0x6b],0x151c
    156d:	ae                   	scas   al,BYTE PTR es:[di]
    156e:	15 57 0d             	adc    ax,0xd57
    1571:	b6 15                	mov    dh,0x15
    1573:	00 00                	add    BYTE PTR [bx+si],al
    1575:	08 44 42             	or     BYTE PTR [si+0x42],al
    1578:	54                   	push   sp
    1579:	61                   	popa
    157a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    157d:	73 00                	jae    0x157f
    157f:	00 df                	add    bh,bl
    1581:	15 00 00             	adc    ax,0x0
    1584:	00 00                	add    BYTE PTR [bx+si],al
    1586:	00 00                	add    BYTE PTR [bx+si],al
    1588:	d0 15                	rcl    BYTE PTR [di],1
    158a:	18 00                	sbb    BYTE PTR [bx+si],al
    158c:	1d 0d f5             	sbb    ax,0xf50d
    158f:	15 64 20             	adc    ax,0x2064
    1592:	a3 16 9a             	mov    ds:0x9a16,ax
    1595:	1f                   	pop    ds
    1596:	92                   	xchg   dx,ax
    1597:	15 cb 1f             	adc    ax,0x1fcb
    159a:	96                   	xchg   si,ax
    159b:	15 1a 76             	adc    ax,0x761a
    159e:	8e 15                	mov    ss,WORD PTR [di]
    15a0:	cd 11                	int    0x11
    15a2:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    15a3:	15 e4 11             	adc    ax,0x11e4
    15a6:	aa                   	stos   BYTE PTR es:[di],al
    15a7:	15 fa 10             	adc    ax,0x10fa
    15aa:	5e                   	pop    si
    15ab:	17                   	pop    ss
    15ac:	bc 4c ca             	mov    sp,0xca4c
    15af:	15 12 4d             	adc    ax,0x4d12
    15b2:	f1                   	int1
    15b3:	15 13 7b             	adc    ax,0x7b13
    15b6:	ba 15 2a             	mov    dx,0x2a15
    15b9:	7b be                	jnp    0x1579
    15bb:	15 44 7b             	adc    ax,0x7b44
    15be:	c2 15 3d             	ret    0x3d15
    15c1:	7b c6                	jnp    0x1589
    15c3:	15 4b 7b             	adc    ax,0x7b4b
    15c6:	ce                   	into
    15c7:	15 e3 4c             	adc    ax,0x4ce3
    15ca:	b2 15                	mov    dl,0x15
    15cc:	65 7b 9e             	gs jnp 0x156d
    15cf:	15 0e 54             	adc    ax,0x540e
    15d2:	51                   	push   cx
    15d3:	75 65                	jne    0x163a
    15d5:	72 79                	jb     0x1650
    15d7:	44                   	inc    sp
    15d8:	61                   	popa
    15d9:	74 61                	je     0x163c
    15db:	4c                   	dec    sp
    15dc:	69 6e 6b 07 0e       	imul   bp,WORD PTR [bp+0x6b],0xe07
    15e1:	54                   	push   sp
    15e2:	51                   	push   cx
    15e3:	75 65                	jne    0x164a
    15e5:	72 79                	jb     0x1660
    15e7:	44                   	inc    sp
    15e8:	61                   	popa
    15e9:	74 61                	je     0x164c
    15eb:	4c                   	dec    sp
    15ec:	69 6e 6b a0 15       	imul   bp,WORD PTR [bp+0x6b],0x15a0
    15f1:	d7                   	xlat   BYTE PTR ds:[bx]
    15f2:	18 57 0d             	sbb    BYTE PTR [bx+0xd],dl
    15f5:	24 16                	and    al,0x16
    15f7:	00 00                	add    BYTE PTR [bx+si],al
    15f9:	08 44 42             	or     BYTE PTR [si+0x42],al
    15fc:	54                   	push   sp
    15fd:	61                   	popa
    15fe:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1601:	73 00                	jae    0x1603
    1603:	00 c8                	add    al,cl
    1605:	02 00                	add    al,BYTE PTR [bx+si]
    1607:	00 8b 46 04          	add    BYTE PTR [bp+di+0x446],cl
    160b:	3d 00 00             	cmp    ax,0x0
    160e:	75 06                	jne    0x1616
    1610:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1614:	eb 2a                	jmp    0x1640
    1616:	3d 02 29             	cmp    ax,0x2902
    1619:	75 1d                	jne    0x1638
    161b:	c4 3e c6 2a          	les    di,DWORD PTR ds:0x2ac6
    161f:	06                   	push   es
    1620:	57                   	push   di
    1621:	9a 56 1b 30 16       	call   0x1630:0x1b56
    1626:	08 c0                	or     al,al
    1628:	75 08                	jne    0x1632
    162a:	ff 76 04             	push   WORD PTR [bp+0x4]
    162d:	9a 2d 12 3e 16       	call   0x163e:0x122d
    1632:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1636:	eb 08                	jmp    0x1640
    1638:	ff 76 04             	push   WORD PTR [bp+0x4]
    163b:	9a 2d 12 2b 19       	call   0x192b:0x122d
    1640:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1643:	c9                   	leave
    1644:	c2 02 00             	ret    0x2
    1647:	00 00                	add    BYTE PTR [bx+si],al
    1649:	00 00                	add    BYTE PTR [bx+si],al
    164b:	00 00                	add    BYTE PTR [bx+si],al
    164d:	ff 03                	inc    WORD PTR [bp+di]
	...
    1667:	c8 26 00 00          	enter  0x26,0x0
    166b:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    166f:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1672:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1676:	74 63                	je     0x16db
    1678:	26 8a 05             	mov    al,BYTE PTR es:[di]
    167b:	30 e4                	xor    ah,ah
    167d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1680:	b8 01 00             	mov    ax,0x1
    1683:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1686:	7f 4f                	jg     0x16d7
    1688:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    168b:	eb 03                	jmp    0x1690
    168d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1690:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1693:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1696:	03 f8                	add    di,ax
    1698:	26 8a 05             	mov    al,BYTE PTR es:[di]
    169b:	b4 01                	mov    ah,0x1
    169d:	ba 20 00             	mov    dx,0x20
    16a0:	9a 99 1a b6 16       	call   0x16b6:0x1a99
    16a5:	52                   	push   dx
    16a6:	50                   	push   ax
    16a7:	8d 7e da             	lea    di,[bp-0x26]
    16aa:	16                   	push   ss
    16ab:	57                   	push   di
    16ac:	bf 47 16             	mov    di,0x1647
    16af:	0e                   	push   cs
    16b0:	57                   	push   di
    16b1:	6a 20                	push   0x20
    16b3:	9a e4 19 bf 16       	call   0x16bf:0x19e4
    16b8:	a0 63 2c             	mov    al,ds:0x2c63
    16bb:	50                   	push   ax
    16bc:	9a 24 1a 42 17       	call   0x1742:0x1a24
    16c1:	83 c4 04             	add    sp,0x4
    16c4:	59                   	pop    cx
    16c5:	5b                   	pop    bx
    16c6:	8b fb                	mov    di,bx
    16c8:	84 4b da             	test   BYTE PTR [bp+di-0x26],cl
    16cb:	75 02                	jne    0x16cf
    16cd:	eb 0c                	jmp    0x16db
    16cf:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    16d2:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    16d5:	75 b6                	jne    0x168d
    16d7:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    16db:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    16de:	c9                   	leave
    16df:	c2 04 00             	ret    0x4
    16e2:	c8 06 00 00          	enter  0x6,0x0
    16e6:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    16ea:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    16ed:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    16f1:	74 39                	je     0x172c
    16f3:	26 8a 05             	mov    al,BYTE PTR es:[di]
    16f6:	30 e4                	xor    ah,ah
    16f8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    16fb:	b8 01 00             	mov    ax,0x1
    16fe:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1701:	7f 25                	jg     0x1728
    1703:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1706:	eb 03                	jmp    0x170b
    1708:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    170b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    170e:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1711:	03 f8                	add    di,ax
    1713:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1716:	3c 30                	cmp    al,0x30
    1718:	72 04                	jb     0x171e
    171a:	3c 39                	cmp    al,0x39
    171c:	76 02                	jbe    0x1720
    171e:	eb 0c                	jmp    0x172c
    1720:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1723:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1726:	75 e0                	jne    0x1708
    1728:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    172c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    172f:	c9                   	leave
    1730:	c2 04 00             	ret    0x4
    1733:	55                   	push   bp
    1734:	89 e5                	mov    bp,sp
    1736:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    173a:	74 08                	je     0x1744
    173c:	83 ec 08             	sub    sp,0x8
    173f:	9a e2 1f 1b 18       	call   0x181b:0x1fe2
    1744:	8b 46 16             	mov    ax,WORD PTR [bp+0x16]
    1747:	0b 46 18             	or     ax,WORD PTR [bp+0x18]
    174a:	74 2d                	je     0x1779
    174c:	ff 76 08             	push   WORD PTR [bp+0x8]
    174f:	ff 76 06             	push   WORD PTR [bp+0x6]
    1752:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    1755:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1759:	06                   	push   es
    175a:	57                   	push   di
    175b:	9a 2b 0c 04 18       	call   0x1804:0xc2b
    1760:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    1763:	26 c6 45 0c 00       	mov    BYTE PTR es:[di+0xc],0x0
    1768:	8b 46 16             	mov    ax,WORD PTR [bp+0x16]
    176b:	8b 56 18             	mov    dx,WORD PTR [bp+0x18]
    176e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1771:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1775:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1779:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    177c:	06                   	push   es
    177d:	57                   	push   di
    177e:	9a d7 05 96 17       	call   0x1796:0x5d7
    1783:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1786:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    178a:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    178e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1791:	06                   	push   es
    1792:	57                   	push   di
    1793:	9a d7 05 d2 17       	call   0x17d2:0x5d7
    1798:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    179b:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    179f:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    17a3:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    17a6:	26 88 45 10          	mov    BYTE PTR es:[di+0x10],al
    17aa:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    17ae:	74 07                	je     0x17b7
    17b0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    17b4:	83 c4 06             	add    sp,0x6
    17b7:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    17ba:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    17bd:	c9                   	leave
    17be:	ca 14 00             	retf   0x14
    17c1:	55                   	push   bp
    17c2:	89 e5                	mov    bp,sp
    17c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17c7:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    17cb:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    17cf:	9a 24 06 e2 17       	call   0x17e2:0x624
    17d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17d7:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    17db:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    17df:	9a 24 06 fe 19       	call   0x19fe:0x624
    17e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e7:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    17eb:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    17ef:	74 21                	je     0x1812
    17f1:	ff 76 08             	push   WORD PTR [bp+0x8]
    17f4:	ff 76 06             	push   WORD PTR [bp+0x6]
    17f7:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    17fb:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    17ff:	06                   	push   es
    1800:	57                   	push   di
    1801:	9a a7 0f 97 18       	call   0x1897:0xfa7
    1806:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1809:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    180d:	26 c6 45 0c 00       	mov    BYTE PTR es:[di+0xc],0x0
    1812:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1816:	74 05                	je     0x181d
    1818:	9a 0f 20 4b 18       	call   0x184b:0x200f
    181d:	c9                   	leave
    181e:	ca 06 00             	retf   0x6
    1821:	55                   	push   bp
    1822:	89 e5                	mov    bp,sp
    1824:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1827:	26 f6 45 10 10       	test   BYTE PTR es:[di+0x10],0x10
    182c:	74 09                	je     0x1837
    182e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1831:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1835:	eb 16                	jmp    0x184d
    1837:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    183a:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    183e:	06                   	push   es
    183f:	57                   	push   di
    1840:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1843:	06                   	push   es
    1844:	57                   	push   di
    1845:	68 ff 00             	push   0xff
    1848:	9a e7 17 68 18       	call   0x1868:0x17e7
    184d:	c9                   	leave
    184e:	ca 04 00             	retf   0x4
    1851:	55                   	push   bp
    1852:	89 e5                	mov    bp,sp
    1854:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1857:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    185b:	06                   	push   es
    185c:	57                   	push   di
    185d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1860:	06                   	push   es
    1861:	57                   	push   di
    1862:	68 ff 00             	push   0xff
    1865:	9a e7 17 7d 18       	call   0x187d:0x17e7
    186a:	c9                   	leave
    186b:	ca 04 00             	retf   0x4
    186e:	55                   	push   bp
    186f:	89 e5                	mov    bp,sp
    1871:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1875:	74 08                	je     0x187f
    1877:	83 ec 08             	sub    sp,0x8
    187a:	9a e2 1f 9e 18       	call   0x189e:0x1fe2
    187f:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1882:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    1885:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1888:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    188c:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1890:	b0 01                	mov    al,0x1
    1892:	50                   	push   ax
    1893:	b8 a3 02             	mov    ax,0x2a3
    1896:	ba 72 19             	mov    dx,0x1972
    1899:	52                   	push   dx
    189a:	50                   	push   ax
    189b:	9a 50 1f e5 18       	call   0x18e5:0x1f50
    18a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18a3:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    18a7:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    18ab:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    18af:	74 07                	je     0x18b8
    18b1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    18b5:	83 c4 06             	add    sp,0x6
    18b8:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    18bb:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    18be:	c9                   	leave
    18bf:	ca 0a 00             	retf   0xa
    18c2:	55                   	push   bp
    18c3:	89 e5                	mov    bp,sp
    18c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18c8:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    18cc:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
    18d0:	74 07                	je     0x18d9
    18d2:	06                   	push   es
    18d3:	57                   	push   di
    18d4:	9a 55 19 07 19       	call   0x1907:0x1955
    18d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18dc:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    18e0:	06                   	push   es
    18e1:	57                   	push   di
    18e2:	9a 7f 1f f0 18       	call   0x18f0:0x1f7f
    18e7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    18eb:	74 05                	je     0x18f2
    18ed:	9a 0f 20 7d 19       	call   0x197d:0x200f
    18f2:	c9                   	leave
    18f3:	ca 06 00             	retf   0x6
    18f6:	c8 08 00 00          	enter  0x8,0x0
    18fa:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    18fd:	06                   	push   es
    18fe:	57                   	push   di
    18ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1902:	06                   	push   es
    1903:	57                   	push   di
    1904:	9a ee 1a 48 19       	call   0x1948:0x1aee
    1909:	09 c0                	or     ax,ax
    190b:	7c 20                	jl     0x192d
    190d:	68 23 f2             	push   0xf223
    1910:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    1913:	89 f8                	mov    ax,di
    1915:	8c c2                	mov    dx,es
    1917:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    191a:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    191d:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    1921:	8d 7e f8             	lea    di,[bp-0x8]
    1924:	16                   	push   ss
    1925:	57                   	push   di
    1926:	6a 00                	push   0x0
    1928:	9a 0a 12 9d 1a       	call   0x1a9d:0x120a
    192d:	ff 76 08             	push   WORD PTR [bp+0x8]
    1930:	ff 76 06             	push   WORD PTR [bp+0x6]
    1933:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    1936:	06                   	push   es
    1937:	57                   	push   di
    1938:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    193b:	06                   	push   es
    193c:	57                   	push   di
    193d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1940:	50                   	push   ax
    1941:	b0 01                	mov    al,0x1
    1943:	50                   	push   ax
    1944:	b8 22 00             	mov    ax,0x22
    1947:	ba 4f 19             	mov    dx,0x194f
    194a:	52                   	push   dx
    194b:	50                   	push   ax
    194c:	9a 33 17 91 19       	call   0x1991:0x1733
    1951:	c9                   	leave
    1952:	ca 0e 00             	retf   0xe
    1955:	55                   	push   bp
    1956:	89 e5                	mov    bp,sp
    1958:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    195b:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    195f:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    1964:	7e 1b                	jle    0x1981
    1966:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1969:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    196d:	06                   	push   es
    196e:	57                   	push   di
    196f:	9a 43 0f d2 19       	call   0x19d2:0xf43
    1974:	89 c7                	mov    di,ax
    1976:	8e c2                	mov    es,dx
    1978:	06                   	push   es
    1979:	57                   	push   di
    197a:	9a 7f 1f 25 1a       	call   0x1a25:0x1f7f
    197f:	eb d7                	jmp    0x1958
    1981:	c9                   	leave
    1982:	ca 04 00             	retf   0x4
    1985:	c8 0c 01 00          	enter  0x10c,0x0
    1989:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    198c:	06                   	push   es
    198d:	57                   	push   di
    198e:	9a 4f 1b 5e 1b       	call   0x1b5e:0x1b4f
    1993:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1996:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1999:	30 e4                	xor    ah,ah
    199b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    199e:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    19a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a5:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    19a9:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    19ad:	48                   	dec    ax
    19ae:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    19b1:	31 c0                	xor    ax,ax
    19b3:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    19b6:	7e 03                	jle    0x19bb
    19b8:	e9 a6 00             	jmp    0x1a61
    19bb:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    19be:	eb 03                	jmp    0x19c3
    19c0:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    19c3:	ff 76 f8             	push   WORD PTR [bp-0x8]
    19c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19c9:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    19cd:	06                   	push   es
    19ce:	57                   	push   di
    19cf:	9a d0 0d dc 1a       	call   0x1adc:0xdd0
    19d4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    19d7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    19da:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    19dd:	26 8a 45 10          	mov    al,BYTE PTR es:[di+0x10]
    19e1:	24 14                	and    al,0x14
    19e3:	08 c0                	or     al,al
    19e5:	75 6f                	jne    0x1a56
    19e7:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    19eb:	74 1c                	je     0x1a09
    19ed:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19f0:	06                   	push   es
    19f1:	57                   	push   di
    19f2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    19f5:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    19f9:	06                   	push   es
    19fa:	57                   	push   di
    19fb:	9a ed 07 2a 1a       	call   0x1a2a:0x7ed
    1a00:	09 c0                	or     ax,ax
    1a02:	75 03                	jne    0x1a07
    1a04:	e9 9f 00             	jmp    0x1aa6
    1a07:	eb 4d                	jmp    0x1a56
    1a09:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a0c:	06                   	push   es
    1a0d:	57                   	push   di
    1a0e:	8d be f4 fe          	lea    di,[bp-0x10c]
    1a12:	16                   	push   ss
    1a13:	57                   	push   di
    1a14:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1a17:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1a1b:	06                   	push   es
    1a1c:	57                   	push   di
    1a1d:	6a 01                	push   0x1
    1a1f:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1a22:	9a 0b 18 73 1b       	call   0x1b73:0x180b
    1a27:	9a ed 07 33 1b       	call   0x1b33:0x7ed
    1a2c:	09 c0                	or     ax,ax
    1a2e:	75 26                	jne    0x1a56
    1a30:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1a33:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1a37:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1a3a:	30 e4                	xor    ah,ah
    1a3c:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1a3f:	74 13                	je     0x1a54
    1a41:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1a44:	40                   	inc    ax
    1a45:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1a48:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1a4c:	03 f8                	add    di,ax
    1a4e:	26 80 3d 3b          	cmp    BYTE PTR es:[di],0x3b
    1a52:	75 02                	jne    0x1a56
    1a54:	eb 50                	jmp    0x1aa6
    1a56:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1a59:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1a5c:	74 03                	je     0x1a61
    1a5e:	e9 5f ff             	jmp    0x19c0
    1a61:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    1a65:	75 38                	jne    0x1a9f
    1a67:	68 25 f2             	push   0xf225
    1a6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a6d:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1a71:	26 8d 85 84 01       	lea    ax,es:[di+0x184]
    1a76:	8c c2                	mov    dx,es
    1a78:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    1a7b:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    1a7e:	c6 46 ea 04          	mov    BYTE PTR [bp-0x16],0x4
    1a82:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a85:	89 f8                	mov    ax,di
    1a87:	8c c2                	mov    dx,es
    1a89:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    1a8c:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    1a8f:	c6 46 f2 04          	mov    BYTE PTR [bp-0xe],0x4
    1a93:	8d 7e e6             	lea    di,[bp-0x1a]
    1a96:	16                   	push   ss
    1a97:	57                   	push   di
    1a98:	6a 01                	push   0x1
    1a9a:	9a 0a 12 80 1b       	call   0x1b80:0x120a
    1a9f:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    1aa3:	e9 fc fe             	jmp    0x19a2
    1aa6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1aa9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1aac:	c9                   	leave
    1aad:	ca 08 00             	retf   0x8
    1ab0:	c8 02 00 00          	enter  0x2,0x0
    1ab4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ab7:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1abb:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1abf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ac2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ac5:	c9                   	leave
    1ac6:	ca 04 00             	retf   0x4
    1ac9:	c8 04 00 00          	enter  0x4,0x0
    1acd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ad0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ad3:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1ad7:	06                   	push   es
    1ad8:	57                   	push   di
    1ad9:	9a d0 0d 1f 1b       	call   0x1b1f:0xdd0
    1ade:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1ae1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1ae4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ae7:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1aea:	c9                   	leave
    1aeb:	ca 06 00             	retf   0x6
    1aee:	c8 04 00 00          	enter  0x4,0x0
    1af2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1af5:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1af9:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1afd:	48                   	dec    ax
    1afe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b01:	31 c0                	xor    ax,ax
    1b03:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1b06:	7f 3b                	jg     0x1b43
    1b08:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b0b:	eb 03                	jmp    0x1b10
    1b0d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1b10:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b16:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1b1a:	06                   	push   es
    1b1b:	57                   	push   di
    1b1c:	9a d0 0d a9 1b       	call   0x1ba9:0xdd0
    1b21:	89 c7                	mov    di,ax
    1b23:	8e c2                	mov    es,dx
    1b25:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1b29:	06                   	push   es
    1b2a:	57                   	push   di
    1b2b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b2e:	06                   	push   es
    1b2f:	57                   	push   di
    1b30:	9a ed 07 e5 1b       	call   0x1be5:0x7ed
    1b35:	09 c0                	or     ax,ax
    1b37:	75 02                	jne    0x1b3b
    1b39:	eb 0d                	jmp    0x1b48
    1b3b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b3e:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1b41:	75 ca                	jne    0x1b0d
    1b43:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    1b48:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b4b:	c9                   	leave
    1b4c:	ca 08 00             	retf   0x8
    1b4f:	55                   	push   bp
    1b50:	89 e5                	mov    bp,sp
    1b52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b55:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1b59:	06                   	push   es
    1b5a:	57                   	push   di
    1b5b:	9a 77 30 19 1c       	call   0x1c19:0x3077
    1b60:	c9                   	leave
    1b61:	ca 04 00             	retf   0x4
    1b64:	55                   	push   bp
    1b65:	89 e5                	mov    bp,sp
    1b67:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1b6b:	74 08                	je     0x1b75
    1b6d:	83 ec 08             	sub    sp,0x8
    1b70:	9a e2 1f b0 1b       	call   0x1bb0:0x1fe2
    1b75:	31 c0                	xor    ax,ax
    1b77:	50                   	push   ax
    1b78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b7b:	06                   	push   es
    1b7c:	57                   	push   di
    1b7d:	9a dc 75 00 1c       	call   0x1c00:0x75dc
    1b82:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1b85:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    1b88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b8b:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    1b8f:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    1b93:	a1 16 17             	mov    ax,ds:0x1716
    1b96:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    1b9a:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    1b9e:	26 89 55 1a          	mov    WORD PTR es:[di+0x1a],dx
    1ba2:	b0 01                	mov    al,0x1
    1ba4:	50                   	push   ax
    1ba5:	b8 a3 02             	mov    ax,0x2a3
    1ba8:	ba 2b 1c             	mov    dx,0x1c2b
    1bab:	52                   	push   dx
    1bac:	50                   	push   ax
    1bad:	9a 50 1f f3 1b       	call   0x1bf3:0x1f50
    1bb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bb5:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    1bb9:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    1bbd:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1bc1:	74 07                	je     0x1bca
    1bc3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1bc7:	83 c4 06             	add    sp,0x6
    1bca:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1bcd:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1bd0:	c9                   	leave
    1bd1:	ca 0a 00             	retf   0xa
    1bd4:	55                   	push   bp
    1bd5:	89 e5                	mov    bp,sp
    1bd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bda:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1bde:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    1be2:	9a 24 06 dc 1d       	call   0x1ddc:0x624
    1be7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bea:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    1bee:	06                   	push   es
    1bef:	57                   	push   di
    1bf0:	9a 7f 1f 0b 1c       	call   0x1c0b:0x1f7f
    1bf5:	31 c0                	xor    ax,ax
    1bf7:	50                   	push   ax
    1bf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bfb:	06                   	push   es
    1bfc:	57                   	push   di
    1bfd:	9a 1a 76 75 1c       	call   0x1c75:0x761a
    1c02:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1c06:	74 05                	je     0x1c0d
    1c08:	9a 0f 20 b8 1c       	call   0x1cb8:0x200f
    1c0d:	c9                   	leave
    1c0e:	ca 06 00             	retf   0x6
    1c11:	01 00                	add    WORD PTR [bx+si],ax
    1c13:	00 00                	add    BYTE PTR [bx+si],al
    1c15:	00 00                	add    BYTE PTR [bx+si],al
    1c17:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
    1c18:	1c 00                	sbb    al,0x0
    1c1a:	1d c8 02             	sbb    ax,0x2c8
    1c1d:	01 00                	add    WORD PTR [bx+si],ax
    1c1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c22:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    1c26:	06                   	push   es
    1c27:	57                   	push   di
    1c28:	9a 75 0c 9a 1c       	call   0x1c9a:0xc75
    1c2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c30:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    1c35:	75 03                	jne    0x1c3a
    1c37:	e9 85 00             	jmp    0x1cbf
    1c3a:	b8 11 1c             	mov    ax,0x1c11
    1c3d:	0e                   	push   cs
    1c3e:	50                   	push   ax
    1c3f:	55                   	push   bp
    1c40:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1c44:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1c48:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    1c4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c50:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    1c54:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1c57:	30 e4                	xor    ah,ah
    1c59:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    1c5c:	7c 40                	jl     0x1c9e
    1c5e:	8d be fe fe          	lea    di,[bp-0x102]
    1c62:	16                   	push   ss
    1c63:	57                   	push   di
    1c64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c67:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    1c6b:	06                   	push   es
    1c6c:	57                   	push   di
    1c6d:	8d 7e fe             	lea    di,[bp-0x2]
    1c70:	16                   	push   ss
    1c71:	57                   	push   di
    1c72:	9a f3 0f 7f 1c       	call   0x1c7f:0xff3
    1c77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c7a:	06                   	push   es
    1c7b:	57                   	push   di
    1c7c:	9a fa 76 8a 1c       	call   0x1c8a:0x76fa
    1c81:	89 c7                	mov    di,ax
    1c83:	8e c2                	mov    es,dx
    1c85:	06                   	push   es
    1c86:	57                   	push   di
    1c87:	9a 9b 3b cb 1c       	call   0x1ccb:0x3b9b
    1c8c:	52                   	push   dx
    1c8d:	50                   	push   ax
    1c8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c91:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    1c95:	06                   	push   es
    1c96:	57                   	push   di
    1c97:	9a 2b 0c b3 1c       	call   0x1cb3:0xc2b
    1c9c:	eb af                	jmp    0x1c4d
    1c9e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1ca2:	83 c4 06             	add    sp,0x6
    1ca5:	eb 18                	jmp    0x1cbf
    1ca7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1caa:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    1cae:	06                   	push   es
    1caf:	57                   	push   di
    1cb0:	9a 75 0c 9b 1d       	call   0x1d9b:0xc75
    1cb5:	ea 85 13 bd 1c       	jmp    0x1cbd:0x1385
    1cba:	9a 34 14 c7 1d       	call   0x1dc7:0x1434
    1cbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cc2:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1cc6:	06                   	push   es
    1cc7:	57                   	push   di
    1cc8:	9a 02 32 25 1d       	call   0x1d25:0x3202
    1ccd:	08 c0                	or     al,al
    1ccf:	74 41                	je     0x1d12
    1cd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cd4:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1cd8:	26 f6 45 18 08       	test   BYTE PTR es:[di+0x18],0x8
    1cdd:	75 33                	jne    0x1d12
    1cdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ce2:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    1ce7:	74 1b                	je     0x1d04
    1ce9:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    1ced:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    1cf2:	7e 10                	jle    0x1d04
    1cf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf7:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1cfb:	06                   	push   es
    1cfc:	57                   	push   di
    1cfd:	9a 38 2e 10 1d       	call   0x1d10:0x2e38
    1d02:	eb 0e                	jmp    0x1d12
    1d04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d07:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1d0b:	06                   	push   es
    1d0c:	57                   	push   di
    1d0d:	9a d5 1e ad 1d       	call   0x1dad:0x1ed5
    1d12:	c9                   	leave
    1d13:	ca 04 00             	retf   0x4
    1d16:	55                   	push   bp
    1d17:	89 e5                	mov    bp,sp
    1d19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d1c:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1d20:	06                   	push   es
    1d21:	57                   	push   di
    1d22:	9a 02 32 37 1d       	call   0x1d37:0x3202
    1d27:	08 c0                	or     al,al
    1d29:	74 0e                	je     0x1d39
    1d2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d2e:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1d32:	06                   	push   es
    1d33:	57                   	push   di
    1d34:	9a 3d 4c 6d 1d       	call   0x1d6d:0x4c3d
    1d39:	c9                   	leave
    1d3a:	ca 04 00             	retf   0x4
    1d3d:	55                   	push   bp
    1d3e:	89 e5                	mov    bp,sp
    1d40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d43:	06                   	push   es
    1d44:	57                   	push   di
    1d45:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d48:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1d4c:	c9                   	leave
    1d4d:	ca 04 00             	retf   0x4
    1d50:	55                   	push   bp
    1d51:	89 e5                	mov    bp,sp
    1d53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d56:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1d5a:	26 80 7d 24 04       	cmp    BYTE PTR es:[di+0x24],0x4
    1d5f:	74 4e                	je     0x1daf
    1d61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d64:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1d68:	06                   	push   es
    1d69:	57                   	push   di
    1d6a:	9a 02 32 10 1e       	call   0x1e10:0x3202
    1d6f:	08 c0                	or     al,al
    1d71:	74 3c                	je     0x1daf
    1d73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d76:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    1d7a:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    1d7f:	7e 2e                	jle    0x1daf
    1d81:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1d84:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1d87:	74 18                	je     0x1da1
    1d89:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d8c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1d8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d92:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    1d96:	06                   	push   es
    1d97:	57                   	push   di
    1d98:	9a 58 0e 6d 26       	call   0x266d:0xe58
    1d9d:	09 c0                	or     ax,ax
    1d9f:	7c 0e                	jl     0x1daf
    1da1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1da4:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1da8:	06                   	push   es
    1da9:	57                   	push   di
    1daa:	9a 38 2e 1f 1e       	call   0x1e1f:0x2e38
    1daf:	c9                   	leave
    1db0:	ca 08 00             	retf   0x8
    1db3:	55                   	push   bp
    1db4:	89 e5                	mov    bp,sp
    1db6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1db9:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    1dbd:	06                   	push   es
    1dbe:	57                   	push   di
    1dbf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1dc2:	06                   	push   es
    1dc3:	57                   	push   di
    1dc4:	9a be 18 fd 1d       	call   0x1dfd:0x18be
    1dc9:	74 1f                	je     0x1dea
    1dcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dce:	81 c7 18 00          	add    di,0x18
    1dd2:	06                   	push   es
    1dd3:	57                   	push   di
    1dd4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1dd7:	06                   	push   es
    1dd8:	57                   	push   di
    1dd9:	9a 51 06 fc 20       	call   0x20fc:0x651
    1dde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1de1:	06                   	push   es
    1de2:	57                   	push   di
    1de3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1de6:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1dea:	c9                   	leave
    1deb:	ca 08 00             	retf   0x8
    1dee:	55                   	push   bp
    1def:	89 e5                	mov    bp,sp
    1df1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1df5:	74 08                	je     0x1dff
    1df7:	83 ec 08             	sub    sp,0x8
    1dfa:	9a e2 1f 7f 1e       	call   0x1e7f:0x1fe2
    1dff:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1e02:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e05:	31 c0                	xor    ax,ax
    1e07:	50                   	push   ax
    1e08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e0b:	06                   	push   es
    1e0c:	57                   	push   di
    1e0d:	9a e5 2d 9b 1e       	call   0x1e9b:0x2de5
    1e12:	ff 76 08             	push   WORD PTR [bp+0x8]
    1e15:	ff 76 06             	push   WORD PTR [bp+0x6]
    1e18:	b0 01                	mov    al,0x1
    1e1a:	50                   	push   ax
    1e1b:	b8 4c 00             	mov    ax,0x4c
    1e1e:	ba 26 1e             	mov    dx,0x1e26
    1e21:	52                   	push   dx
    1e22:	50                   	push   ax
    1e23:	9a 6e 18 42 1e       	call   0x1e42:0x186e
    1e28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e2b:	26 89 85 78 01       	mov    WORD PTR es:[di+0x178],ax
    1e30:	26 89 95 7a 01       	mov    WORD PTR es:[di+0x17a],dx
    1e35:	ff 76 08             	push   WORD PTR [bp+0x8]
    1e38:	ff 76 06             	push   WORD PTR [bp+0x6]
    1e3b:	b0 01                	mov    al,0x1
    1e3d:	50                   	push   ax
    1e3e:	b8 77 00             	mov    ax,0x77
    1e41:	ba 49 1e             	mov    dx,0x1e49
    1e44:	52                   	push   dx
    1e45:	50                   	push   ax
    1e46:	9a 64 1b 68 1f       	call   0x1f68:0x1b64
    1e4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e4e:	26 89 85 7c 01       	mov    WORD PTR es:[di+0x17c],ax
    1e53:	26 89 95 7e 01       	mov    WORD PTR es:[di+0x17e],dx
    1e58:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1e5c:	74 07                	je     0x1e65
    1e5e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1e62:	83 c4 06             	add    sp,0x6
    1e65:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1e68:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1e6b:	c9                   	leave
    1e6c:	ca 0a 00             	retf   0xa
    1e6f:	55                   	push   bp
    1e70:	89 e5                	mov    bp,sp
    1e72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e75:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    1e7a:	06                   	push   es
    1e7b:	57                   	push   di
    1e7c:	9a 7f 1f 8e 1e       	call   0x1e8e:0x1f7f
    1e81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e84:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    1e89:	06                   	push   es
    1e8a:	57                   	push   di
    1e8b:	9a 7f 1f a6 1e       	call   0x1ea6:0x1f7f
    1e90:	31 c0                	xor    ax,ax
    1e92:	50                   	push   ax
    1e93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e96:	06                   	push   es
    1e97:	57                   	push   di
    1e98:	9a 9a 2e b7 1e       	call   0x1eb7:0x2e9a
    1e9d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1ea1:	74 05                	je     0x1ea8
    1ea3:	9a 0f 20 9a 20       	call   0x209a:0x200f
    1ea8:	c9                   	leave
    1ea9:	ca 06 00             	retf   0x6
    1eac:	55                   	push   bp
    1ead:	89 e5                	mov    bp,sp
    1eaf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb2:	06                   	push   es
    1eb3:	57                   	push   di
    1eb4:	9a 3d 4c c1 1e       	call   0x1ec1:0x4c3d
    1eb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ebc:	06                   	push   es
    1ebd:	57                   	push   di
    1ebe:	9a 4a 58 cf 1e       	call   0x1ecf:0x584a
    1ec3:	08 c0                	or     al,al
    1ec5:	74 0a                	je     0x1ed1
    1ec7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eca:	06                   	push   es
    1ecb:	57                   	push   di
    1ecc:	9a cd 4c e0 1e       	call   0x1ee0:0x4ccd
    1ed1:	c9                   	leave
    1ed2:	ca 04 00             	retf   0x4
    1ed5:	55                   	push   bp
    1ed6:	89 e5                	mov    bp,sp
    1ed8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1edb:	06                   	push   es
    1edc:	57                   	push   di
    1edd:	9a 3d 4c ea 1e       	call   0x1eea:0x4c3d
    1ee2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ee5:	06                   	push   es
    1ee6:	57                   	push   di
    1ee7:	9a 3b 48 f4 1e       	call   0x1ef4:0x483b
    1eec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eef:	06                   	push   es
    1ef0:	57                   	push   di
    1ef1:	9a a2 59 04 1f       	call   0x1f04:0x59a2
    1ef6:	08 c0                	or     al,al
    1ef8:	74 0c                	je     0x1f06
    1efa:	6a 00                	push   0x0
    1efc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eff:	06                   	push   es
    1f00:	57                   	push   di
    1f01:	9a 1e 4b 1f 1f       	call   0x1f1f:0x4b1e
    1f06:	c9                   	leave
    1f07:	ca 04 00             	retf   0x4
    1f0a:	c8 f4 00 00          	enter  0xf4,0x0
    1f0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f11:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    1f17:	75 08                	jne    0x1f21
    1f19:	68 6c f2             	push   0xf26c
    1f1c:	9a ef 11 29 1f       	call   0x1f29:0x11ef
    1f21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f24:	06                   	push   es
    1f25:	57                   	push   di
    1f26:	9a 65 5f 40 1f       	call   0x1f40:0x5f65
    1f2b:	52                   	push   dx
    1f2c:	50                   	push   ax
    1f2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f30:	81 c7 84 01          	add    di,0x184
    1f34:	06                   	push   es
    1f35:	57                   	push   di
    1f36:	8d 7e ac             	lea    di,[bp-0x54]
    1f39:	16                   	push   ss
    1f3a:	57                   	push   di
    1f3b:	6a 4f                	push   0x4f
    1f3d:	9a b7 0e 7a 1f       	call   0x1f7a:0xeb7
    1f42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f45:	81 c7 d4 01          	add    di,0x1d4
    1f49:	06                   	push   es
    1f4a:	57                   	push   di
    1f4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f4e:	26 8a 85 83 01       	mov    al,BYTE PTR es:[di+0x183]
    1f53:	50                   	push   ax
    1f54:	8d be 2c ff          	lea    di,[bp-0xd4]
    1f58:	16                   	push   ss
    1f59:	57                   	push   di
    1f5a:	8d be 0c ff          	lea    di,[bp-0xf4]
    1f5e:	16                   	push   ss
    1f5f:	57                   	push   di
    1f60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f63:	06                   	push   es
    1f64:	57                   	push   di
    1f65:	9a da 29 8b 1f       	call   0x1f8b:0x29da
    1f6a:	31 c0                	xor    ax,ax
    1f6c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1f6f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f75:	06                   	push   es
    1f76:	57                   	push   di
    1f77:	9a 2b 5f f7 1f       	call   0x1ff7:0x5f2b
    1f7c:	52                   	push   dx
    1f7d:	50                   	push   ax
    1f7e:	8d 7e ac             	lea    di,[bp-0x54]
    1f81:	16                   	push   ss
    1f82:	57                   	push   di
    1f83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f86:	06                   	push   es
    1f87:	57                   	push   di
    1f88:	9a 5d 2b e9 1f       	call   0x1fe9:0x2b5d
    1f8d:	52                   	push   dx
    1f8e:	50                   	push   ax
    1f8f:	8d be 2c ff          	lea    di,[bp-0xd4]
    1f93:	16                   	push   ss
    1f94:	57                   	push   di
    1f95:	8d be 0c ff          	lea    di,[bp-0xf4]
    1f99:	16                   	push   ss
    1f9a:	57                   	push   di
    1f9b:	6a 00                	push   0x0
    1f9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fa0:	26 8a 85 81 01       	mov    al,BYTE PTR es:[di+0x181]
    1fa5:	98                   	cbw
    1fa6:	8b f8                	mov    di,ax
    1fa8:	d1 e7                	shl    di,1
    1faa:	ff b5 60 0b          	push   WORD PTR [di+0xb60]
    1fae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb1:	26 8a 85 80 01       	mov    al,BYTE PTR es:[di+0x180]
    1fb6:	98                   	cbw
    1fb7:	8b f8                	mov    di,ax
    1fb9:	d1 e7                	shl    di,1
    1fbb:	ff b5 64 0b          	push   WORD PTR [di+0xb64]
    1fbf:	6a 02                	push   0x2
    1fc1:	6a 00                	push   0x0
    1fc3:	6a 00                	push   0x0
    1fc5:	6a 00                	push   0x0
    1fc7:	8d 7e fc             	lea    di,[bp-0x4]
    1fca:	16                   	push   ss
    1fcb:	57                   	push   di
    1fcc:	9a 6d 00 e4 21       	call   0x21e4:0x6d
    1fd1:	50                   	push   ax
    1fd2:	e8 2f f6             	call   0x1604
    1fd5:	08 c0                	or     al,al
    1fd7:	75 02                	jne    0x1fdb
    1fd9:	eb 97                	jmp    0x1f72
    1fdb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1fde:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1fe1:	c9                   	leave
    1fe2:	ca 04 00             	retf   0x4
    1fe5:	00 00                	add    BYTE PTR [bx+si],al
    1fe7:	4c                   	dec    sp
    1fe8:	23 e1                	and    sp,cx
    1fea:	20 c8                	and    al,cl
    1fec:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1fed:	03 00                	add    ax,WORD PTR [bx+si]
    1fef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ff2:	06                   	push   es
    1ff3:	57                   	push   di
    1ff4:	9a e5 31 05 20       	call   0x2005:0x31e5
    1ff9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ffc:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2000:	06                   	push   es
    2001:	57                   	push   di
    2002:	9a 31 2d 13 20       	call   0x2013:0x2d31
    2007:	09 c0                	or     ax,ax
    2009:	75 79                	jne    0x2084
    200b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    200e:	06                   	push   es
    200f:	57                   	push   di
    2010:	9a 32 3b 35 20       	call   0x2035:0x3b32
    2015:	48                   	dec    ax
    2016:	89 86 60 fe          	mov    WORD PTR [bp-0x1a0],ax
    201a:	31 c0                	xor    ax,ax
    201c:	3b 86 60 fe          	cmp    ax,WORD PTR [bp-0x1a0]
    2020:	7f 62                	jg     0x2084
    2022:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2025:	eb 03                	jmp    0x202a
    2027:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    202a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    202d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2030:	06                   	push   es
    2031:	57                   	push   di
    2032:	9a 4b 3b 59 20       	call   0x2059:0x3b4b
    2037:	89 c7                	mov    di,ax
    2039:	8e c2                	mov    es,dx
    203b:	89 be 5c fe          	mov    WORD PTR [bp-0x1a4],di
    203f:	8c 86 5e fe          	mov    WORD PTR [bp-0x1a2],es
    2043:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    2048:	75 31                	jne    0x207b
    204a:	8d be 5c fd          	lea    di,[bp-0x2a4]
    204e:	16                   	push   ss
    204f:	57                   	push   di
    2050:	c4 be 5c fe          	les    di,DWORD PTR [bp-0x1a4]
    2054:	06                   	push   es
    2055:	57                   	push   di
    2056:	9a 1f 69 79 20       	call   0x2079:0x691f
    205b:	c4 be 5c fe          	les    di,DWORD PTR [bp-0x1a4]
    205f:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    2063:	50                   	push   ax
    2064:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    2068:	26 8a 45 27          	mov    al,BYTE PTR es:[di+0x27]
    206c:	50                   	push   ax
    206d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2070:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2074:	06                   	push   es
    2075:	57                   	push   di
    2076:	9a a1 2a d7 20       	call   0x20d7:0x2aa1
    207b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    207e:	3b 86 60 fe          	cmp    ax,WORD PTR [bp-0x1a0]
    2082:	75 a3                	jne    0x2027
    2084:	31 c0                	xor    ax,ax
    2086:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2089:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    208c:	8d be 62 fe          	lea    di,[bp-0x19e]
    2090:	16                   	push   ss
    2091:	57                   	push   di
    2092:	68 72 01             	push   0x172
    2095:	6a 00                	push   0x0
    2097:	9a e5 1e 63 23       	call   0x2363:0x1ee5
    209c:	6a 03                	push   0x3
    209e:	6a 01                	push   0x1
    20a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a3:	06                   	push   es
    20a4:	57                   	push   di
    20a5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20a8:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    20ad:	b8 e5 1f             	mov    ax,0x1fe5
    20b0:	0e                   	push   cs
    20b1:	50                   	push   ax
    20b2:	55                   	push   bp
    20b3:	ff 36 58 18          	push   WORD PTR ds:0x1858
    20b7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    20bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20be:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    20c2:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    20c6:	81 c7 84 01          	add    di,0x184
    20ca:	06                   	push   es
    20cb:	57                   	push   di
    20cc:	8d be 62 fe          	lea    di,[bp-0x19e]
    20d0:	16                   	push   ss
    20d1:	57                   	push   di
    20d2:	6a 7f                	push   0x7f
    20d4:	9a b7 0e 0a 21       	call   0x210a:0xeb7
    20d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20dc:	06                   	push   es
    20dd:	57                   	push   di
    20de:	9a 5d 2b f5 20       	call   0x20f5:0x2b5d
    20e3:	09 d0                	or     ax,dx
    20e5:	74 17                	je     0x20fe
    20e7:	8d be e2 fe          	lea    di,[bp-0x11e]
    20eb:	16                   	push   ss
    20ec:	57                   	push   di
    20ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20f0:	06                   	push   es
    20f1:	57                   	push   di
    20f2:	9a 5d 2b 90 21       	call   0x2190:0x2b5d
    20f7:	52                   	push   dx
    20f8:	50                   	push   ax
    20f9:	9a df 0c 17 21       	call   0x2117:0xcdf
    20fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2101:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2105:	06                   	push   es
    2106:	57                   	push   di
    2107:	9a 31 2d 2b 21       	call   0x212b:0x2d31
    210c:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    210f:	6b 46 98 34          	imul   ax,WORD PTR [bp-0x68],0x34
    2113:	50                   	push   ax
    2114:	9a 76 04 b1 21       	call   0x21b1:0x476
    2119:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    211c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    211f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2122:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2126:	06                   	push   es
    2127:	57                   	push   di
    2128:	9a 31 2d 51 21       	call   0x2151:0x2d31
    212d:	48                   	dec    ax
    212e:	89 86 60 fe          	mov    WORD PTR [bp-0x1a0],ax
    2132:	31 c0                	xor    ax,ax
    2134:	3b 86 60 fe          	cmp    ax,WORD PTR [bp-0x1a0]
    2138:	7f 6f                	jg     0x21a9
    213a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    213d:	eb 03                	jmp    0x2142
    213f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2142:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2145:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2148:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    214c:	06                   	push   es
    214d:	57                   	push   di
    214e:	9a 4a 2d 79 21       	call   0x2179:0x2d4a
    2153:	89 c7                	mov    di,ax
    2155:	8e c2                	mov    es,dx
    2157:	89 be 5c fe          	mov    WORD PTR [bp-0x1a4],di
    215b:	8c 86 5e fe          	mov    WORD PTR [bp-0x1a2],es
    215f:	6b 46 fe 34          	imul   ax,WORD PTR [bp-0x2],0x34
    2163:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2166:	03 f8                	add    di,ax
    2168:	06                   	push   es
    2169:	57                   	push   di
    216a:	8d be 5c fd          	lea    di,[bp-0x2a4]
    216e:	16                   	push   ss
    216f:	57                   	push   di
    2170:	c4 be 5c fe          	les    di,DWORD PTR [bp-0x1a4]
    2174:	06                   	push   es
    2175:	57                   	push   di
    2176:	9a fc 29 ea 21       	call   0x21ea:0x29fc
    217b:	c4 be 5c fe          	les    di,DWORD PTR [bp-0x1a4]
    217f:	26 8a 45 0c          	mov    al,BYTE PTR es:[di+0xc]
    2183:	50                   	push   ax
    2184:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    2188:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    218b:	06                   	push   es
    218c:	57                   	push   di
    218d:	9a 91 26 d3 21       	call   0x21d3:0x2691
    2192:	c4 be 5c fe          	les    di,DWORD PTR [bp-0x1a4]
    2196:	26 80 7d 0d 00       	cmp    BYTE PTR es:[di+0xd],0x0
    219b:	74 03                	je     0x21a0
    219d:	ff 46 b6             	inc    WORD PTR [bp-0x4a]
    21a0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    21a3:	3b 86 60 fe          	cmp    ax,WORD PTR [bp-0x1a0]
    21a7:	75 96                	jne    0x213f
    21a9:	6b 46 98 34          	imul   ax,WORD PTR [bp-0x68],0x34
    21ad:	50                   	push   ax
    21ae:	9a 76 04 07 22       	call   0x2207:0x476
    21b3:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    21b6:	89 56 a0             	mov    WORD PTR [bp-0x60],dx
    21b9:	6a 00                	push   0x0
    21bb:	6a 00                	push   0x0
    21bd:	ff 76 98             	push   WORD PTR [bp-0x68]
    21c0:	ff 76 fa             	push   WORD PTR [bp-0x6]
    21c3:	ff 76 f8             	push   WORD PTR [bp-0x8]
    21c6:	8d 7e d4             	lea    di,[bp-0x2c]
    21c9:	16                   	push   ss
    21ca:	57                   	push   di
    21cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ce:	06                   	push   es
    21cf:	57                   	push   di
    21d0:	9a ef 28 f9 21       	call   0x21f9:0x28ef
    21d5:	52                   	push   dx
    21d6:	50                   	push   ax
    21d7:	6a 00                	push   0x0
    21d9:	6a 00                	push   0x0
    21db:	ff 76 a0             	push   WORD PTR [bp-0x60]
    21de:	ff 76 9e             	push   WORD PTR [bp-0x62]
    21e1:	9a cd 22 38 23       	call   0x2338:0x22cd
    21e6:	50                   	push   ax
    21e7:	9a 4e 12 cd 22       	call   0x22cd:0x124e
    21ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ef:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    21f4:	06                   	push   es
    21f5:	57                   	push   di
    21f6:	9a b0 1a 1c 22       	call   0x221c:0x1ab0
    21fb:	89 46 a2             	mov    WORD PTR [bp-0x5e],ax
    21fe:	69 46 a2 d8 02       	imul   ax,WORD PTR [bp-0x5e],0x2d8
    2203:	50                   	push   ax
    2204:	9a 76 04 ad 22       	call   0x22ad:0x476
    2209:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    220c:	89 56 aa             	mov    WORD PTR [bp-0x56],dx
    220f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2212:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    2217:	06                   	push   es
    2218:	57                   	push   di
    2219:	9a b0 1a 43 22       	call   0x2243:0x1ab0
    221e:	48                   	dec    ax
    221f:	89 86 60 fe          	mov    WORD PTR [bp-0x1a0],ax
    2223:	31 c0                	xor    ax,ax
    2225:	3b 86 60 fe          	cmp    ax,WORD PTR [bp-0x1a0]
    2229:	7f 70                	jg     0x229b
    222b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    222e:	eb 03                	jmp    0x2233
    2230:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2233:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2236:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2239:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    223e:	06                   	push   es
    223f:	57                   	push   di
    2240:	9a c9 1a 6c 22       	call   0x226c:0x1ac9
    2245:	89 c7                	mov    di,ax
    2247:	8e c2                	mov    es,dx
    2249:	89 be 5c fe          	mov    WORD PTR [bp-0x1a4],di
    224d:	8c 86 5e fe          	mov    WORD PTR [bp-0x1a2],es
    2251:	69 46 fe d8 02       	imul   ax,WORD PTR [bp-0x2],0x2d8
    2256:	c4 7e a8             	les    di,DWORD PTR [bp-0x58]
    2259:	03 f8                	add    di,ax
    225b:	06                   	push   es
    225c:	57                   	push   di
    225d:	8d be 5c fd          	lea    di,[bp-0x2a4]
    2261:	16                   	push   ss
    2262:	57                   	push   di
    2263:	c4 be 5c fe          	les    di,DWORD PTR [bp-0x1a4]
    2267:	06                   	push   es
    2268:	57                   	push   di
    2269:	9a 51 18 7d 22       	call   0x227d:0x1851
    226e:	8d be 5c fc          	lea    di,[bp-0x3a4]
    2272:	16                   	push   ss
    2273:	57                   	push   di
    2274:	c4 be 5c fe          	les    di,DWORD PTR [bp-0x1a4]
    2278:	06                   	push   es
    2279:	57                   	push   di
    227a:	9a 21 18 90 22       	call   0x2290:0x1821
    227f:	c4 be 5c fe          	les    di,DWORD PTR [bp-0x1a4]
    2283:	26 8a 45 10          	mov    al,BYTE PTR es:[di+0x10]
    2287:	50                   	push   ax
    2288:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    228b:	06                   	push   es
    228c:	57                   	push   di
    228d:	9a 4d 27 76 25       	call   0x2576:0x274d
    2292:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2295:	3b 86 60 fe          	cmp    ax,WORD PTR [bp-0x1a0]
    2299:	75 95                	jne    0x2230
    229b:	83 7e b6 00          	cmp    WORD PTR [bp-0x4a],0x0
    229f:	75 03                	jne    0x22a4
    22a1:	e9 7d 00             	jmp    0x2321
    22a4:	69 46 b6 0e 04       	imul   ax,WORD PTR [bp-0x4a],0x40e
    22a9:	50                   	push   ax
    22aa:	9a 76 04 35 29       	call   0x2935:0x476
    22af:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    22b2:	89 56 be             	mov    WORD PTR [bp-0x42],dx
    22b5:	8b 46 bc             	mov    ax,WORD PTR [bp-0x44]
    22b8:	8b 56 be             	mov    dx,WORD PTR [bp-0x42]
    22bb:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    22be:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    22c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c4:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    22c8:	06                   	push   es
    22c9:	57                   	push   di
    22ca:	9a 31 2d f3 22       	call   0x22f3:0x2d31
    22cf:	48                   	dec    ax
    22d0:	89 86 60 fe          	mov    WORD PTR [bp-0x1a0],ax
    22d4:	31 c0                	xor    ax,ax
    22d6:	3b 86 60 fe          	cmp    ax,WORD PTR [bp-0x1a0]
    22da:	7f 45                	jg     0x2321
    22dc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    22df:	eb 03                	jmp    0x22e4
    22e1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    22e4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    22e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ea:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    22ee:	06                   	push   es
    22ef:	57                   	push   di
    22f0:	9a 4a 2d 29 23       	call   0x2329:0x2d4a
    22f5:	89 c7                	mov    di,ax
    22f7:	8e c2                	mov    es,dx
    22f9:	26 80 7d 0d 00       	cmp    BYTE PTR es:[di+0xd],0x0
    22fe:	74 18                	je     0x2318
    2300:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2303:	40                   	inc    ax
    2304:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2307:	26 89 05             	mov    WORD PTR es:[di],ax
    230a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    230d:	26 c7 45 02 01 00    	mov    WORD PTR es:[di+0x2],0x1
    2313:	81 46 f4 0e 04       	add    WORD PTR [bp-0xc],0x40e
    2318:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    231b:	3b 86 60 fe          	cmp    ax,WORD PTR [bp-0x1a0]
    231f:	75 c0                	jne    0x22e1
    2321:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2324:	06                   	push   es
    2325:	57                   	push   di
    2326:	9a 2b 5f 3e 23       	call   0x233e:0x5f2b
    232b:	52                   	push   dx
    232c:	50                   	push   ax
    232d:	6a 01                	push   0x1
    232f:	8d be 62 fe          	lea    di,[bp-0x19e]
    2333:	16                   	push   ss
    2334:	57                   	push   di
    2335:	9a 0d 08 e3 25       	call   0x25e3:0x80d
    233a:	50                   	push   ax
    233b:	9a 4e 12 ec 23       	call   0x23ec:0x124e
    2340:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2344:	83 c4 06             	add    sp,0x6
    2347:	b8 c0 23             	mov    ax,0x23c0
    234a:	0e                   	push   cs
    234b:	50                   	push   ax
    234c:	8b 46 bc             	mov    ax,WORD PTR [bp-0x44]
    234f:	0b 46 be             	or     ax,WORD PTR [bp-0x42]
    2352:	74 11                	je     0x2365
    2354:	ff 76 be             	push   WORD PTR [bp-0x42]
    2357:	ff 76 bc             	push   WORD PTR [bp-0x44]
    235a:	69 46 b6 0e 04       	imul   ax,WORD PTR [bp-0x4a],0x40e
    235f:	50                   	push   ax
    2360:	9a 9c 01 7c 23       	call   0x237c:0x19c
    2365:	8b 46 a8             	mov    ax,WORD PTR [bp-0x58]
    2368:	0b 46 aa             	or     ax,WORD PTR [bp-0x56]
    236b:	74 11                	je     0x237e
    236d:	ff 76 aa             	push   WORD PTR [bp-0x56]
    2370:	ff 76 a8             	push   WORD PTR [bp-0x58]
    2373:	69 46 a2 d8 02       	imul   ax,WORD PTR [bp-0x5e],0x2d8
    2378:	50                   	push   ax
    2379:	9a 9c 01 94 23       	call   0x2394:0x19c
    237e:	8b 46 9e             	mov    ax,WORD PTR [bp-0x62]
    2381:	0b 46 a0             	or     ax,WORD PTR [bp-0x60]
    2384:	74 10                	je     0x2396
    2386:	ff 76 a0             	push   WORD PTR [bp-0x60]
    2389:	ff 76 9e             	push   WORD PTR [bp-0x62]
    238c:	6b 46 98 34          	imul   ax,WORD PTR [bp-0x68],0x34
    2390:	50                   	push   ax
    2391:	9a 9c 01 ac 23       	call   0x23ac:0x19c
    2396:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2399:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    239c:	74 10                	je     0x23ae
    239e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    23a1:	ff 76 f8             	push   WORD PTR [bp-0x8]
    23a4:	6b 46 98 34          	imul   ax,WORD PTR [bp-0x68],0x34
    23a8:	50                   	push   ax
    23a9:	9a 9c 01 ef 24       	call   0x24ef:0x19c
    23ae:	6a 03                	push   0x3
    23b0:	6a 00                	push   0x0
    23b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b5:	06                   	push   es
    23b6:	57                   	push   di
    23b7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23ba:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    23bf:	cb                   	retf
    23c0:	c9                   	leave
    23c1:	ca 04 00             	retf   0x4
    23c4:	55                   	push   bp
    23c5:	89 e5                	mov    bp,sp
    23c7:	80 7e 0e 08          	cmp    BYTE PTR [bp+0xe],0x8
    23cb:	75 0d                	jne    0x23da
    23cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d0:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    23d5:	26 c6 45 0c 00       	mov    BYTE PTR es:[di+0xc],0x0
    23da:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    23dd:	50                   	push   ax
    23de:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23e1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e7:	06                   	push   es
    23e8:	57                   	push   di
    23e9:	9a 19 43 41 24       	call   0x2441:0x4319
    23ee:	c9                   	leave
    23ef:	ca 0a 00             	retf   0xa
    23f2:	01 3b                	add    WORD PTR [bp+di],di
    23f4:	c8 0e 02 00          	enter  0x20e,0x0
    23f8:	c4 7e 1a             	les    di,DWORD PTR [bp+0x1a]
    23fb:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    23fe:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    2401:	26 80 bd 82 00 00    	cmp    BYTE PTR es:[di+0x82],0x0
    2407:	75 0c                	jne    0x2415
    2409:	89 f8                	mov    ax,di
    240b:	8c c2                	mov    dx,es
    240d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2410:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2413:	eb 10                	jmp    0x2425
    2415:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2418:	26 8d 85 82 00       	lea    ax,es:[di+0x82]
    241d:	8c c2                	mov    dx,es
    241f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2422:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2425:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2428:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    242c:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    2430:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2433:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2436:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    2439:	06                   	push   es
    243a:	57                   	push   di
    243b:	ff 76 14             	push   WORD PTR [bp+0x14]
    243e:	9a 13 0f b1 24       	call   0x24b1:0xf13
    2443:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2447:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    244a:	26 83 bd c2 00 00    	cmp    WORD PTR es:[di+0xc2],0x0
    2450:	74 04                	je     0x2456
    2452:	80 4e ff 01          	or     BYTE PTR [bp-0x1],0x1
    2456:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2459:	26 83 bd c4 00 00    	cmp    WORD PTR es:[di+0xc4],0x0
    245f:	74 04                	je     0x2465
    2461:	80 4e ff 02          	or     BYTE PTR [bp-0x1],0x2
    2465:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2468:	26 83 bd c6 00 00    	cmp    WORD PTR es:[di+0xc6],0x0
    246e:	74 04                	je     0x2474
    2470:	80 4e ff 04          	or     BYTE PTR [bp-0x1],0x4
    2474:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2477:	26 83 bd b2 02 00    	cmp    WORD PTR es:[di+0x2b2],0x0
    247d:	74 04                	je     0x2483
    247f:	80 4e ff 08          	or     BYTE PTR [bp-0x1],0x8
    2483:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2486:	26 83 bd cc 00 00    	cmp    WORD PTR es:[di+0xcc],0x0
    248c:	74 28                	je     0x24b6
    248e:	80 4e ff 10          	or     BYTE PTR [bp-0x1],0x10
    2492:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2495:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    2499:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    249d:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    24a0:	81 c7 f8 00          	add    di,0xf8
    24a4:	06                   	push   es
    24a5:	57                   	push   di
    24a6:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    24a9:	06                   	push   es
    24aa:	57                   	push   di
    24ab:	ff 76 0e             	push   WORD PTR [bp+0xe]
    24ae:	9a 13 0f 3b 25       	call   0x253b:0xf13
    24b3:	e9 af 00             	jmp    0x2565
    24b6:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    24b9:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    24bd:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    24c0:	26 8b 85 d0 00       	mov    ax,WORD PTR es:[di+0xd0]
    24c5:	48                   	dec    ax
    24c6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    24c9:	31 c0                	xor    ax,ax
    24cb:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    24ce:	7e 03                	jle    0x24d3
    24d0:	e9 92 00             	jmp    0x2565
    24d3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    24d6:	eb 03                	jmp    0x24db
    24d8:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    24db:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    24df:	74 27                	je     0x2508
    24e1:	8d be f2 fe          	lea    di,[bp-0x10e]
    24e5:	16                   	push   ss
    24e6:	57                   	push   di
    24e7:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    24ea:	06                   	push   es
    24eb:	57                   	push   di
    24ec:	9a cd 17 f9 24       	call   0x24f9:0x17cd
    24f1:	bf f2 23             	mov    di,0x23f2
    24f4:	0e                   	push   cs
    24f5:	57                   	push   di
    24f6:	9a 4c 18 06 25       	call   0x2506:0x184c
    24fb:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    24fe:	06                   	push   es
    24ff:	57                   	push   di
    2500:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2503:	9a e7 17 16 25       	call   0x2516:0x17e7
    2508:	8d be f2 fd          	lea    di,[bp-0x20e]
    250c:	16                   	push   ss
    250d:	57                   	push   di
    250e:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2511:	06                   	push   es
    2512:	57                   	push   di
    2513:	9a cd 17 4b 25       	call   0x254b:0x17cd
    2518:	8d be f2 fe          	lea    di,[bp-0x10e]
    251c:	16                   	push   ss
    251d:	57                   	push   di
    251e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2521:	d1 e0                	shl    ax,1
    2523:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2526:	03 f8                	add    di,ax
    2528:	26 8b 85 d8 00       	mov    ax,WORD PTR es:[di+0xd8]
    252d:	48                   	dec    ax
    252e:	50                   	push   ax
    252f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2532:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2536:	06                   	push   es
    2537:	57                   	push   di
    2538:	9a 4a 2d 46 25       	call   0x2546:0x2d4a
    253d:	89 c7                	mov    di,ax
    253f:	8e c2                	mov    es,dx
    2541:	06                   	push   es
    2542:	57                   	push   di
    2543:	9a fc 29 84 25       	call   0x2584:0x29fc
    2548:	9a 4c 18 58 25       	call   0x2558:0x184c
    254d:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2550:	06                   	push   es
    2551:	57                   	push   di
    2552:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2555:	9a e7 17 5e 27       	call   0x275e:0x17e7
    255a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    255d:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    2560:	74 03                	je     0x2565
    2562:	e9 73 ff             	jmp    0x24d8
    2565:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2568:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    256b:	26 88 05             	mov    BYTE PTR es:[di],al
    256e:	c9                   	leave
    256f:	ca 18 00             	retf   0x18
    2572:	00 00                	add    BYTE PTR [bx+si],al
    2574:	f7 25                	mul    WORD PTR [di]
    2576:	dc 25                	fsub   QWORD PTR [di]
    2578:	c8 50 00 00          	enter  0x50,0x0
    257c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    257f:	06                   	push   es
    2580:	57                   	push   di
    2581:	9a e5 31 ad 25       	call   0x25ad:0x31e5
    2586:	6a 03                	push   0x3
    2588:	6a 01                	push   0x1
    258a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    258d:	06                   	push   es
    258e:	57                   	push   di
    258f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2592:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    2597:	b8 72 25             	mov    ax,0x2572
    259a:	0e                   	push   cs
    259b:	50                   	push   ax
    259c:	55                   	push   bp
    259d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    25a1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    25a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a8:	06                   	push   es
    25a9:	57                   	push   di
    25aa:	9a 2b 5f b9 25       	call   0x25b9:0x5f2b
    25af:	52                   	push   dx
    25b0:	50                   	push   ax
    25b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25b4:	06                   	push   es
    25b5:	57                   	push   di
    25b6:	9a 65 5f d0 25       	call   0x25d0:0x5f65
    25bb:	52                   	push   dx
    25bc:	50                   	push   ax
    25bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c0:	81 c7 84 01          	add    di,0x184
    25c4:	06                   	push   es
    25c5:	57                   	push   di
    25c6:	8d 7e b0             	lea    di,[bp-0x50]
    25c9:	16                   	push   ss
    25ca:	57                   	push   di
    25cb:	6a 4f                	push   0x4f
    25cd:	9a b7 0e e9 25       	call   0x25e9:0xeb7
    25d2:	52                   	push   dx
    25d3:	50                   	push   ax
    25d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25d7:	06                   	push   es
    25d8:	57                   	push   di
    25d9:	9a 5d 2b 71 27       	call   0x2771:0x2b5d
    25de:	52                   	push   dx
    25df:	50                   	push   ax
    25e0:	9a 3d 08 1f 29       	call   0x291f:0x83d
    25e5:	50                   	push   ax
    25e6:	9a 4e 12 79 26       	call   0x2679:0x124e
    25eb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    25ef:	83 c4 06             	add    sp,0x6
    25f2:	b8 09 26             	mov    ax,0x2609
    25f5:	0e                   	push   cs
    25f6:	50                   	push   ax
    25f7:	6a 03                	push   0x3
    25f9:	6a 00                	push   0x0
    25fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25fe:	06                   	push   es
    25ff:	57                   	push   di
    2600:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2603:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    2608:	cb                   	retf
    2609:	c9                   	leave
    260a:	ca 04 00             	retf   0x4
    260d:	c8 04 00 00          	enter  0x4,0x0
    2611:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2614:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2619:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    261e:	74 63                	je     0x2683
    2620:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2623:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2628:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    262c:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    2631:	7e 50                	jle    0x2683
    2633:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2636:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    263b:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    263f:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2643:	48                   	dec    ax
    2644:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2647:	31 c0                	xor    ax,ax
    2649:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    264c:	7f 35                	jg     0x2683
    264e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2651:	eb 03                	jmp    0x2656
    2653:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2656:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2659:	ff 76 fe             	push   WORD PTR [bp-0x2]
    265c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    265f:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2664:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    2668:	06                   	push   es
    2669:	57                   	push   di
    266a:	9a d0 0d 0c 32       	call   0x320c:0xdd0
    266f:	52                   	push   dx
    2670:	50                   	push   ax
    2671:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2674:	06                   	push   es
    2675:	57                   	push   di
    2676:	9a 88 3d 8b 26       	call   0x268b:0x3d88
    267b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    267e:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2681:	75 d0                	jne    0x2653
    2683:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2686:	06                   	push   es
    2687:	57                   	push   di
    2688:	9a 4c 5d bc 26       	call   0x26bc:0x5d4c
    268d:	c9                   	leave
    268e:	ca 04 00             	retf   0x4
    2691:	c8 04 00 00          	enter  0x4,0x0
    2695:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2698:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    269b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    269e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26a1:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    26a5:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    26a9:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    26ac:	06                   	push   es
    26ad:	57                   	push   di
    26ae:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    26b1:	81 c7 02 00          	add    di,0x2
    26b5:	06                   	push   es
    26b6:	57                   	push   di
    26b7:	6a 1f                	push   0x1f
    26b9:	9a b7 0e 7f 27       	call   0x277f:0xeb7
    26be:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    26c1:	98                   	cbw
    26c2:	8b f8                	mov    di,ax
    26c4:	8a 85 68 0b          	mov    al,BYTE PTR [di+0xb68]
    26c8:	30 e4                	xor    ah,ah
    26ca:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    26cd:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    26d1:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    26d4:	3c 01                	cmp    al,0x1
    26d6:	74 14                	je     0x26ec
    26d8:	3c 0c                	cmp    al,0xc
    26da:	74 10                	je     0x26ec
    26dc:	3c 0d                	cmp    al,0xd
    26de:	74 0c                	je     0x26ec
    26e0:	3c 0e                	cmp    al,0xe
    26e2:	74 08                	je     0x26ec
    26e4:	3c 0f                	cmp    al,0xf
    26e6:	74 04                	je     0x26ec
    26e8:	3c 10                	cmp    al,0x10
    26ea:	75 0c                	jne    0x26f8
    26ec:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    26ef:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    26f2:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    26f6:	eb 14                	jmp    0x270c
    26f8:	3c 08                	cmp    al,0x8
    26fa:	75 10                	jne    0x270c
    26fc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    26ff:	26 c7 45 26 20 00    	mov    WORD PTR es:[di+0x26],0x20
    2705:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2708:	26 89 45 28          	mov    WORD PTR es:[di+0x28],ax
    270c:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    270f:	3c 07                	cmp    al,0x7
    2711:	75 0b                	jne    0x271e
    2713:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2716:	26 c7 45 24 15 00    	mov    WORD PTR es:[di+0x24],0x15
    271c:	eb 2b                	jmp    0x2749
    271e:	3c 0e                	cmp    al,0xe
    2720:	75 0b                	jne    0x272d
    2722:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2725:	26 c7 45 24 17 00    	mov    WORD PTR es:[di+0x24],0x17
    272b:	eb 1c                	jmp    0x2749
    272d:	3c 0f                	cmp    al,0xf
    272f:	75 0b                	jne    0x273c
    2731:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2734:	26 c7 45 24 16 00    	mov    WORD PTR es:[di+0x24],0x16
    273a:	eb 0d                	jmp    0x2749
    273c:	3c 10                	cmp    al,0x10
    273e:	75 09                	jne    0x2749
    2740:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2743:	26 c7 45 24 1a 00    	mov    WORD PTR es:[di+0x24],0x1a
    2749:	c9                   	leave
    274a:	ca 10 00             	retf   0x10
    274d:	c8 06 01 00          	enter  0x106,0x0
    2751:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2754:	06                   	push   es
    2755:	57                   	push   di
    2756:	68 d8 02             	push   0x2d8
    2759:	6a 00                	push   0x0
    275b:	9a e5 1e 93 29       	call   0x2993:0x1ee5
    2760:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2763:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2766:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2769:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    276c:	06                   	push   es
    276d:	57                   	push   di
    276e:	9a f7 2d bf 28       	call   0x28bf:0x2df7
    2773:	08 c0                	or     al,al
    2775:	74 23                	je     0x279a
    2777:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    277a:	06                   	push   es
    277b:	57                   	push   di
    277c:	9a 65 5f 96 27       	call   0x2796:0x5f65
    2781:	52                   	push   dx
    2782:	50                   	push   ax
    2783:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2786:	06                   	push   es
    2787:	57                   	push   di
    2788:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    278b:	81 c7 82 00          	add    di,0x82
    278f:	06                   	push   es
    2790:	57                   	push   di
    2791:	6a 1f                	push   0x1f
    2793:	9a b7 0e a2 27       	call   0x27a2:0xeb7
    2798:	eb 1d                	jmp    0x27b7
    279a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    279d:	06                   	push   es
    279e:	57                   	push   di
    279f:	9a 65 5f b5 27       	call   0x27b5:0x5f65
    27a4:	52                   	push   dx
    27a5:	50                   	push   ax
    27a6:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    27a9:	06                   	push   es
    27aa:	57                   	push   di
    27ab:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    27ae:	06                   	push   es
    27af:	57                   	push   di
    27b0:	6a 7f                	push   0x7f
    27b2:	9a b7 0e 12 28       	call   0x2812:0xeb7
    27b7:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    27bb:	b0 00                	mov    al,0x0
    27bd:	74 01                	je     0x27c0
    27bf:	40                   	inc    ax
    27c0:	98                   	cbw
    27c1:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    27c4:	26 89 85 c2 00       	mov    WORD PTR es:[di+0xc2],ax
    27c9:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    27cd:	b0 00                	mov    al,0x0
    27cf:	74 01                	je     0x27d2
    27d1:	40                   	inc    ax
    27d2:	98                   	cbw
    27d3:	26 89 85 c4 00       	mov    WORD PTR es:[di+0xc4],ax
    27d8:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    27dc:	b0 00                	mov    al,0x0
    27de:	74 01                	je     0x27e1
    27e0:	40                   	inc    ax
    27e1:	98                   	cbw
    27e2:	26 89 85 c6 00       	mov    WORD PTR es:[di+0xc6],ax
    27e7:	26 c7 85 c8 00 01 00 	mov    WORD PTR es:[di+0xc8],0x1
    27ee:	f6 46 0a 08          	test   BYTE PTR [bp+0xa],0x8
    27f2:	b0 00                	mov    al,0x0
    27f4:	74 01                	je     0x27f7
    27f6:	40                   	inc    ax
    27f7:	98                   	cbw
    27f8:	26 89 85 b2 02       	mov    WORD PTR es:[di+0x2b2],ax
    27fd:	f6 46 0a 10          	test   BYTE PTR [bp+0xa],0x10
    2801:	74 2b                	je     0x282e
    2803:	26 c7 85 cc 00 01 00 	mov    WORD PTR es:[di+0xcc],0x1
    280a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    280d:	06                   	push   es
    280e:	57                   	push   di
    280f:	9a 65 5f 2a 28       	call   0x282a:0x5f65
    2814:	52                   	push   dx
    2815:	50                   	push   ax
    2816:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2819:	06                   	push   es
    281a:	57                   	push   di
    281b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    281e:	81 c7 f8 00          	add    di,0xf8
    2822:	06                   	push   es
    2823:	57                   	push   di
    2824:	68 dc 00             	push   0xdc
    2827:	9a b7 0e 5e 28       	call   0x285e:0xeb7
    282c:	eb 63                	jmp    0x2891
    282e:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    2833:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2836:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2839:	30 e4                	xor    ah,ah
    283b:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    283e:	7c 51                	jl     0x2891
    2840:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2843:	26 83 bd d0 00 10    	cmp    WORD PTR es:[di+0xd0],0x10
    2849:	73 46                	jae    0x2891
    284b:	8d be fa fe          	lea    di,[bp-0x106]
    284f:	16                   	push   ss
    2850:	57                   	push   di
    2851:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2854:	06                   	push   es
    2855:	57                   	push   di
    2856:	8d 7e fe             	lea    di,[bp-0x2]
    2859:	16                   	push   ss
    285a:	57                   	push   di
    285b:	9a f3 0f 6c 28       	call   0x286c:0xff3
    2860:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2863:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2867:	06                   	push   es
    2868:	57                   	push   di
    2869:	9a d4 2c a1 28       	call   0x28a1:0x2cd4
    286e:	89 c7                	mov    di,ax
    2870:	8e c2                	mov    es,dx
    2872:	26 8b 55 10          	mov    dx,WORD PTR es:[di+0x10]
    2876:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2879:	26 8b 85 d0 00       	mov    ax,WORD PTR es:[di+0xd0]
    287e:	d1 e0                	shl    ax,1
    2880:	03 f8                	add    di,ax
    2882:	26 89 95 d8 00       	mov    WORD PTR es:[di+0xd8],dx
    2887:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    288a:	26 ff 85 d0 00       	inc    WORD PTR es:[di+0xd0]
    288f:	eb a2                	jmp    0x2833
    2891:	c9                   	leave
    2892:	ca 12 00             	retf   0x12
    2895:	c8 02 00 00          	enter  0x2,0x0
    2899:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    289c:	06                   	push   es
    289d:	57                   	push   di
    289e:	9a 3d 4c b5 28       	call   0x28b5:0x4c3d
    28a3:	6a 00                	push   0x0
    28a5:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    28a8:	06                   	push   es
    28a9:	57                   	push   di
    28aa:	ff 76 0a             	push   WORD PTR [bp+0xa]
    28ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b0:	06                   	push   es
    28b1:	57                   	push   di
    28b2:	9a 85 57 07 29       	call   0x2907:0x5785
    28b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ba:	06                   	push   es
    28bb:	57                   	push   di
    28bc:	9a cb 2b 43 29       	call   0x2943:0x2bcb
    28c1:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    28c4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    28c7:	c9                   	leave
    28c8:	ca 0a 00             	retf   0xa
    28cb:	c8 04 00 00          	enter  0x4,0x0
    28cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d2:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    28d7:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    28db:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    28df:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    28e2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    28e5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    28e8:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    28eb:	c9                   	leave
    28ec:	ca 04 00             	retf   0x4
    28ef:	c8 06 00 00          	enter  0x6,0x0
    28f3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    28f6:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    28f9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    28fc:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    28ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2902:	06                   	push   es
    2903:	57                   	push   di
    2904:	9a 2b 5f 25 29       	call   0x2925:0x5f2b
    2909:	52                   	push   dx
    290a:	50                   	push   ax
    290b:	6a 04                	push   0x4
    290d:	6a 02                	push   0x2
    290f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2912:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2915:	6a 20                	push   0x20
    2917:	8d 7e fa             	lea    di,[bp-0x6]
    291a:	16                   	push   ss
    291b:	57                   	push   di
    291c:	9a ad 21 21 2c       	call   0x2c21:0x21ad
    2921:	50                   	push   ax
    2922:	9a 4e 12 2d 2a       	call   0x2a2d:0x124e
    2927:	ff 76 0c             	push   WORD PTR [bp+0xc]
    292a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    292d:	bf 7a 0b             	mov    di,0xb7a
    2930:	1e                   	push   ds
    2931:	57                   	push   di
    2932:	9a db 0d 62 29       	call   0x2962:0xddb
    2937:	09 c0                	or     ax,ax
    2939:	75 2f                	jne    0x296a
    293b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    293e:	06                   	push   es
    293f:	57                   	push   di
    2940:	9a 5d 2b ab 2a       	call   0x2aab:0x2b5d
    2945:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2948:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    294b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    294e:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    2951:	74 17                	je     0x296a
    2953:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2956:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2959:	ff 76 fe             	push   WORD PTR [bp-0x2]
    295c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    295f:	9a df 0c 09 2b       	call   0x2b09:0xcdf
    2964:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2967:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    296a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    296d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2970:	c9                   	leave
    2971:	ca 08 00             	retf   0x8
    2974:	55                   	push   bp
    2975:	89 e5                	mov    bp,sp
    2977:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    297a:	26 80 bd 83 01 00    	cmp    BYTE PTR es:[di+0x183],0x0
    2980:	74 15                	je     0x2997
    2982:	81 c7 d4 01          	add    di,0x1d4
    2986:	06                   	push   es
    2987:	57                   	push   di
    2988:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    298b:	06                   	push   es
    298c:	57                   	push   di
    298d:	68 ff 00             	push   0xff
    2990:	9a e7 17 cd 29       	call   0x29cd:0x17e7
    2995:	eb 07                	jmp    0x299e
    2997:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    299a:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    299e:	c9                   	leave
    299f:	ca 04 00             	retf   0x4
    29a2:	55                   	push   bp
    29a3:	89 e5                	mov    bp,sp
    29a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a8:	26 80 bd 83 01 00    	cmp    BYTE PTR es:[di+0x183],0x0
    29ae:	74 09                	je     0x29b9
    29b0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    29b3:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    29b7:	eb 16                	jmp    0x29cf
    29b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29bc:	81 c7 d4 01          	add    di,0x1d4
    29c0:	06                   	push   es
    29c1:	57                   	push   di
    29c2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    29c5:	06                   	push   es
    29c6:	57                   	push   di
    29c7:	68 ff 00             	push   0xff
    29ca:	9a e7 17 15 2a       	call   0x2a15:0x17e7
    29cf:	c9                   	leave
    29d0:	ca 04 00             	retf   0x4
    29d3:	01 40 04             	add    WORD PTR [bx+si+0x4],ax
    29d6:	2e 4d                	cs dec bp
    29d8:	44                   	inc    sp
    29d9:	58                   	pop    ax
    29da:	c8 82 01 00          	enter  0x182,0x0
    29de:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    29e1:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    29e5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    29e8:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    29ec:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    29ef:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    29f3:	75 03                	jne    0x29f8
    29f5:	e9 3f 01             	jmp    0x2b37
    29f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29fb:	26 80 7d 40 00       	cmp    BYTE PTR es:[di+0x40],0x0
    2a00:	74 03                	je     0x2a05
    2a02:	e9 32 01             	jmp    0x2b37
    2a05:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2a08:	06                   	push   es
    2a09:	57                   	push   di
    2a0a:	8d be 7e ff          	lea    di,[bp-0x82]
    2a0e:	16                   	push   ss
    2a0f:	57                   	push   di
    2a10:	6a 7f                	push   0x7f
    2a12:	9a e7 17 77 2a       	call   0x2a77:0x17e7
    2a17:	80 7e 12 00          	cmp    BYTE PTR [bp+0x12],0x0
    2a1b:	75 03                	jne    0x2a20
    2a1d:	e9 a5 00             	jmp    0x2ac5
    2a20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a23:	26 c4 bd 24 01       	les    di,DWORD PTR es:[di+0x124]
    2a28:	06                   	push   es
    2a29:	57                   	push   di
    2a2a:	9a 7a 21 db 2a       	call   0x2adb:0x217a
    2a2f:	08 c0                	or     al,al
    2a31:	74 60                	je     0x2a93
    2a33:	8a 86 7e ff          	mov    al,BYTE PTR [bp-0x82]
    2a37:	30 e4                	xor    ah,ah
    2a39:	89 86 7c ff          	mov    WORD PTR [bp-0x84],ax
    2a3d:	b8 01 00             	mov    ax,0x1
    2a40:	3b 86 7c ff          	cmp    ax,WORD PTR [bp-0x84]
    2a44:	7f 23                	jg     0x2a69
    2a46:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a49:	eb 03                	jmp    0x2a4e
    2a4b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2a4e:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
    2a51:	80 bb 7e ff 3b       	cmp    BYTE PTR [bp+di-0x82],0x3b
    2a56:	75 08                	jne    0x2a60
    2a58:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
    2a5b:	c6 83 7e ff 40       	mov    BYTE PTR [bp+di-0x82],0x40
    2a60:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a63:	3b 86 7c ff          	cmp    ax,WORD PTR [bp-0x84]
    2a67:	75 e2                	jne    0x2a4b
    2a69:	8d be 7e fe          	lea    di,[bp-0x182]
    2a6d:	16                   	push   ss
    2a6e:	57                   	push   di
    2a6f:	bf d3 29             	mov    di,0x29d3
    2a72:	0e                   	push   cs
    2a73:	57                   	push   di
    2a74:	9a cd 17 82 2a       	call   0x2a82:0x17cd
    2a79:	8d be 7e ff          	lea    di,[bp-0x82]
    2a7d:	16                   	push   ss
    2a7e:	57                   	push   di
    2a7f:	9a 4c 18 8f 2a       	call   0x2a8f:0x184c
    2a84:	8d be 7e ff          	lea    di,[bp-0x82]
    2a88:	16                   	push   ss
    2a89:	57                   	push   di
    2a8a:	6a 7f                	push   0x7f
    2a8c:	9a e7 17 c3 2a       	call   0x2ac3:0x17e7
    2a91:	eb 32                	jmp    0x2ac5
    2a93:	8d be 7e fe          	lea    di,[bp-0x182]
    2a97:	16                   	push   ss
    2a98:	57                   	push   di
    2a99:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    2a9c:	06                   	push   es
    2a9d:	57                   	push   di
    2a9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa1:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    2aa6:	06                   	push   es
    2aa7:	57                   	push   di
    2aa8:	9a 85 19 b6 2a       	call   0x2ab6:0x1985
    2aad:	89 c7                	mov    di,ax
    2aaf:	8e c2                	mov    es,dx
    2ab1:	06                   	push   es
    2ab2:	57                   	push   di
    2ab3:	9a 51 18 cd 2a       	call   0x2acd:0x1851
    2ab8:	8d be 7e ff          	lea    di,[bp-0x82]
    2abc:	16                   	push   ss
    2abd:	57                   	push   di
    2abe:	6a 7f                	push   0x7f
    2ac0:	9a e7 17 16 2b       	call   0x2b16:0x17e7
    2ac5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac8:	06                   	push   es
    2ac9:	57                   	push   di
    2aca:	9a f7 2d 42 2c       	call   0x2c42:0x2df7
    2acf:	08 c0                	or     al,al
    2ad1:	74 45                	je     0x2b18
    2ad3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad6:	06                   	push   es
    2ad7:	57                   	push   di
    2ad8:	9a 65 5f f0 2a       	call   0x2af0:0x5f65
    2add:	52                   	push   dx
    2ade:	50                   	push   ax
    2adf:	8d be 7e ff          	lea    di,[bp-0x82]
    2ae3:	16                   	push   ss
    2ae4:	57                   	push   di
    2ae5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ae8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2aeb:	6a 1f                	push   0x1f
    2aed:	9a b7 0e 20 2b       	call   0x2b20:0xeb7
    2af2:	8d be 7e fe          	lea    di,[bp-0x182]
    2af6:	16                   	push   ss
    2af7:	57                   	push   di
    2af8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2afb:	81 c7 84 01          	add    di,0x184
    2aff:	06                   	push   es
    2b00:	57                   	push   di
    2b01:	bf d5 29             	mov    di,0x29d5
    2b04:	0e                   	push   cs
    2b05:	57                   	push   di
    2b06:	9a f2 0a 99 2b       	call   0x2b99:0xaf2
    2b0b:	8d be 7e ff          	lea    di,[bp-0x82]
    2b0f:	16                   	push   ss
    2b10:	57                   	push   di
    2b11:	6a 7f                	push   0x7f
    2b13:	9a e7 17 57 2b       	call   0x2b57:0x17e7
    2b18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b1b:	06                   	push   es
    2b1c:	57                   	push   di
    2b1d:	9a 65 5f 35 2b       	call   0x2b35:0x5f65
    2b22:	52                   	push   dx
    2b23:	50                   	push   ax
    2b24:	8d be 7e ff          	lea    di,[bp-0x82]
    2b28:	16                   	push   ss
    2b29:	57                   	push   di
    2b2a:	ff 76 10             	push   WORD PTR [bp+0x10]
    2b2d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2b30:	6a 7f                	push   0x7f
    2b32:	9a b7 0e 76 2b       	call   0x2b76:0xeb7
    2b37:	c9                   	leave
    2b38:	ca 12 00             	retf   0x12
    2b3b:	55                   	push   bp
    2b3c:	89 e5                	mov    bp,sp
    2b3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b41:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2b46:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    2b4a:	06                   	push   es
    2b4b:	57                   	push   di
    2b4c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b4f:	06                   	push   es
    2b50:	57                   	push   di
    2b51:	68 ff 00             	push   0xff
    2b54:	9a e7 17 99 2c       	call   0x2c99:0x17e7
    2b59:	c9                   	leave
    2b5a:	ca 04 00             	retf   0x4
    2b5d:	c8 04 01 00          	enter  0x104,0x0
    2b61:	31 c0                	xor    ax,ax
    2b63:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2b66:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2b69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b6c:	26 c4 bd 24 01       	les    di,DWORD PTR es:[di+0x124]
    2b71:	06                   	push   es
    2b72:	57                   	push   di
    2b73:	9a 7a 21 d7 2b       	call   0x2bd7:0x217a
    2b78:	08 c0                	or     al,al
    2b7a:	75 45                	jne    0x2bc1
    2b7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b7f:	26 80 bd 82 01 00    	cmp    BYTE PTR es:[di+0x182],0x0
    2b85:	75 1e                	jne    0x2ba5
    2b87:	8d be fc fe          	lea    di,[bp-0x104]
    2b8b:	16                   	push   ss
    2b8c:	57                   	push   di
    2b8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b90:	81 c7 84 01          	add    di,0x184
    2b94:	06                   	push   es
    2b95:	57                   	push   di
    2b96:	9a 17 0c 18 2e       	call   0x2e18:0xc17
    2b9b:	83 c4 04             	add    sp,0x4
    2b9e:	80 be fc fe 00       	cmp    BYTE PTR [bp-0x104],0x0
    2ba3:	75 1c                	jne    0x2bc1
    2ba5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ba8:	26 8a 85 82 01       	mov    al,BYTE PTR es:[di+0x182]
    2bad:	98                   	cbw
    2bae:	8b f8                	mov    di,ax
    2bb0:	c1 e7 02             	shl    di,0x2
    2bb3:	8b 85 84 0b          	mov    ax,WORD PTR [di+0xb84]
    2bb7:	8b 95 86 0b          	mov    dx,WORD PTR [di+0xb86]
    2bbb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2bbe:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2bc1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2bc4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2bc7:	c9                   	leave
    2bc8:	ca 04 00             	retf   0x4
    2bcb:	c8 06 00 00          	enter  0x6,0x0
    2bcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bd2:	06                   	push   es
    2bd3:	57                   	push   di
    2bd4:	9a 3d 4c e1 2b       	call   0x2be1:0x4c3d
    2bd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bdc:	06                   	push   es
    2bdd:	57                   	push   di
    2bde:	9a 57 48 ed 2b       	call   0x2bed:0x4857
    2be3:	6a 00                	push   0x0
    2be5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2be8:	06                   	push   es
    2be9:	57                   	push   di
    2bea:	9a e8 56 31 2c       	call   0x2c31:0x56e8
    2bef:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2bf2:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2bf5:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2bf9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bfc:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2c00:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2c04:	6a 00                	push   0x0
    2c06:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2c09:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2c0d:	6a 00                	push   0x0
    2c0f:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2c12:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    2c15:	05 04 00             	add    ax,0x4
    2c18:	52                   	push   dx
    2c19:	50                   	push   ax
    2c1a:	6a 00                	push   0x0
    2c1c:	6a 00                	push   0x0
    2c1e:	9a 5d 09 ce 2c       	call   0x2cce:0x95d
    2c23:	09 c0                	or     ax,ax
    2c25:	75 10                	jne    0x2c37
    2c27:	6a 03                	push   0x3
    2c29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c2c:	06                   	push   es
    2c2d:	57                   	push   di
    2c2e:	9a 1e 4b 75 2c       	call   0x2c75:0x4b1e
    2c33:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    2c37:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2c3a:	c9                   	leave
    2c3b:	ca 04 00             	retf   0x4
    2c3e:	00 00                	add    BYTE PTR [bx+si],al
    2c40:	c5 2d                	lds    bp,DWORD PTR [di]
    2c42:	48                   	dec    ax
    2c43:	2c 00                	sub    al,0x0
    2c45:	00 dc                	add    ah,bl
    2c47:	2d c0 2c             	sub    ax,0x2cc0
    2c4a:	c8 dc 04 00          	enter  0x4dc,0x0
    2c4e:	6a 04                	push   0x4
    2c50:	6a 01                	push   0x1
    2c52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c55:	06                   	push   es
    2c56:	57                   	push   di
    2c57:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c5a:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    2c5f:	b8 44 2c             	mov    ax,0x2c44
    2c62:	0e                   	push   cs
    2c63:	50                   	push   ax
    2c64:	55                   	push   bp
    2c65:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2c69:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2c6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c70:	06                   	push   es
    2c71:	57                   	push   di
    2c72:	9a 65 5f 8c 2c       	call   0x2c8c:0x5f65
    2c77:	52                   	push   dx
    2c78:	50                   	push   ax
    2c79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c7c:	81 c7 84 01          	add    di,0x184
    2c80:	06                   	push   es
    2c81:	57                   	push   di
    2c82:	8d 7e 86             	lea    di,[bp-0x7a]
    2c85:	16                   	push   ss
    2c86:	57                   	push   di
    2c87:	6a 4f                	push   0x4f
    2c89:	9a b7 0e af 2c       	call   0x2caf:0xeb7
    2c8e:	8d be 24 fb          	lea    di,[bp-0x4dc]
    2c92:	16                   	push   ss
    2c93:	57                   	push   di
    2c94:	6a 00                	push   0x0
    2c96:	9a 0e 1a a5 2c       	call   0x2ca5:0x1a0e
    2c9b:	8d 7e d6             	lea    di,[bp-0x2a]
    2c9e:	16                   	push   ss
    2c9f:	57                   	push   di
    2ca0:	6a 20                	push   0x20
    2ca2:	9a 79 1a 42 2d       	call   0x2d42:0x1a79
    2ca7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2caa:	06                   	push   es
    2cab:	57                   	push   di
    2cac:	9a 2b 5f f0 2c       	call   0x2cf0:0x5f2b
    2cb1:	52                   	push   dx
    2cb2:	50                   	push   ax
    2cb3:	8d 7e 86             	lea    di,[bp-0x7a]
    2cb6:	16                   	push   ss
    2cb7:	57                   	push   di
    2cb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cbb:	06                   	push   es
    2cbc:	57                   	push   di
    2cbd:	9a 5d 2b 01 2d       	call   0x2d01:0x2b5d
    2cc2:	52                   	push   dx
    2cc3:	50                   	push   ax
    2cc4:	6a 00                	push   0x0
    2cc6:	8d 7e fa             	lea    di,[bp-0x6]
    2cc9:	16                   	push   ss
    2cca:	57                   	push   di
    2ccb:	9a fd 01 0d 2d       	call   0x2d0d:0x1fd
    2cd0:	50                   	push   ax
    2cd1:	e8 30 e9             	call   0x1604
    2cd4:	08 c0                	or     al,al
    2cd6:	75 02                	jne    0x2cda
    2cd8:	eb cd                	jmp    0x2ca7
    2cda:	b8 3e 2c             	mov    ax,0x2c3e
    2cdd:	0e                   	push   cs
    2cde:	50                   	push   ax
    2cdf:	55                   	push   bp
    2ce0:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2ce4:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2ce8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ceb:	06                   	push   es
    2cec:	57                   	push   di
    2ced:	9a 2b 5f 66 2d       	call   0x2d66:0x5f2b
    2cf2:	52                   	push   dx
    2cf3:	50                   	push   ax
    2cf4:	8d 7e 86             	lea    di,[bp-0x7a]
    2cf7:	16                   	push   ss
    2cf8:	57                   	push   di
    2cf9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cfc:	06                   	push   es
    2cfd:	57                   	push   di
    2cfe:	9a 5d 2b 4d 2e       	call   0x2e4d:0x2b5d
    2d03:	52                   	push   dx
    2d04:	50                   	push   ax
    2d05:	8d 7e f6             	lea    di,[bp-0xa]
    2d08:	16                   	push   ss
    2d09:	57                   	push   di
    2d0a:	9a 1d 02 28 2d       	call   0x2d28:0x21d
    2d0f:	09 c0                	or     ax,ax
    2d11:	75 42                	jne    0x2d55
    2d13:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2d16:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2d19:	6a 00                	push   0x0
    2d1b:	8d be 44 fb          	lea    di,[bp-0x4bc]
    2d1f:	16                   	push   ss
    2d20:	57                   	push   di
    2d21:	6a 00                	push   0x0
    2d23:	6a 00                	push   0x0
    2d25:	9a ed 00 53 2d       	call   0x2d53:0xed
    2d2a:	09 c0                	or     ax,ax
    2d2c:	75 1d                	jne    0x2d4b
    2d2e:	83 be 46 fb 00       	cmp    WORD PTR [bp-0x4ba],0x0
    2d33:	74 14                	je     0x2d49
    2d35:	8b 86 44 fb          	mov    ax,WORD PTR [bp-0x4bc]
    2d39:	48                   	dec    ax
    2d3a:	b4 01                	mov    ah,0x1
    2d3c:	ba 20 00             	mov    dx,0x20
    2d3f:	9a 99 1a 94 2d       	call   0x2d94:0x1a99
    2d44:	8b fa                	mov    di,dx
    2d46:	08 43 d6             	or     BYTE PTR [bp+di-0x2a],al
    2d49:	eb c8                	jmp    0x2d13
    2d4b:	8d 7e f6             	lea    di,[bp-0xa]
    2d4e:	16                   	push   ss
    2d4f:	57                   	push   di
    2d50:	9a ad 00 7d 2d       	call   0x2d7d:0xad
    2d55:	31 c0                	xor    ax,ax
    2d57:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d5d:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2d61:	06                   	push   es
    2d62:	57                   	push   di
    2d63:	9a a4 2c b2 2d       	call   0x2db2:0x2ca4
    2d68:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2d6b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2d6e:	6a 00                	push   0x0
    2d70:	8d be 52 ff          	lea    di,[bp-0xae]
    2d74:	16                   	push   ss
    2d75:	57                   	push   di
    2d76:	6a 00                	push   0x0
    2d78:	6a 00                	push   0x0
    2d7a:	9a ed 00 cd 2d       	call   0x2dcd:0xed
    2d7f:	09 c0                	or     ax,ax
    2d81:	75 36                	jne    0x2db9
    2d83:	8d be 52 ff          	lea    di,[bp-0xae]
    2d87:	16                   	push   ss
    2d88:	57                   	push   di
    2d89:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    2d8c:	b4 01                	mov    ah,0x1
    2d8e:	ba 20 00             	mov    dx,0x20
    2d91:	9a 99 1a 1b 2f       	call   0x2f1b:0x1a99
    2d96:	8b fa                	mov    di,dx
    2d98:	84 43 d6             	test   BYTE PTR [bp+di-0x2a],al
    2d9b:	b0 00                	mov    al,0x0
    2d9d:	74 01                	je     0x2da0
    2d9f:	40                   	inc    ax
    2da0:	50                   	push   ax
    2da1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2da4:	40                   	inc    ax
    2da5:	50                   	push   ax
    2da6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2da9:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2dad:	06                   	push   es
    2dae:	57                   	push   di
    2daf:	9a 44 2b 43 2e       	call   0x2e43:0x2b44
    2db4:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2db7:	eb af                	jmp    0x2d68
    2db9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2dbd:	83 c4 06             	add    sp,0x6
    2dc0:	b8 d0 2d             	mov    ax,0x2dd0
    2dc3:	0e                   	push   cs
    2dc4:	50                   	push   ax
    2dc5:	8d 7e fa             	lea    di,[bp-0x6]
    2dc8:	16                   	push   ss
    2dc9:	57                   	push   di
    2dca:	9a ad 00 fd 30       	call   0x30fd:0xad
    2dcf:	cb                   	retf
    2dd0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2dd4:	83 c4 06             	add    sp,0x6
    2dd7:	b8 ee 2d             	mov    ax,0x2dee
    2dda:	0e                   	push   cs
    2ddb:	50                   	push   ax
    2ddc:	6a 04                	push   0x4
    2dde:	6a 00                	push   0x0
    2de0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2de3:	06                   	push   es
    2de4:	57                   	push   di
    2de5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2de8:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    2ded:	cb                   	retf
    2dee:	c9                   	leave
    2def:	ca 04 00             	retf   0x4
    2df2:	04 2e                	add    al,0x2e
    2df4:	44                   	inc    sp
    2df5:	42                   	inc    dx
    2df6:	46                   	inc    si
    2df7:	c8 02 01 00          	enter  0x102,0x0
    2dfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dfe:	26 80 bd 82 01 02    	cmp    BYTE PTR es:[di+0x182],0x2
    2e04:	74 26                	je     0x2e2c
    2e06:	8d be fe fe          	lea    di,[bp-0x102]
    2e0a:	16                   	push   ss
    2e0b:	57                   	push   di
    2e0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e0f:	81 c7 84 01          	add    di,0x184
    2e13:	06                   	push   es
    2e14:	57                   	push   di
    2e15:	9a 17 0c 22 2e       	call   0x2e22:0xc17
    2e1a:	bf f2 2d             	mov    di,0x2df2
    2e1d:	0e                   	push   cs
    2e1e:	57                   	push   di
    2e1f:	9a 30 07 91 35       	call   0x3591:0x730
    2e24:	09 c0                	or     ax,ax
    2e26:	74 04                	je     0x2e2c
    2e28:	b0 00                	mov    al,0x0
    2e2a:	eb 02                	jmp    0x2e2e
    2e2c:	b0 01                	mov    al,0x1
    2e2e:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2e31:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2e34:	c9                   	leave
    2e35:	ca 04 00             	retf   0x4
    2e38:	55                   	push   bp
    2e39:	89 e5                	mov    bp,sp
    2e3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e3e:	06                   	push   es
    2e3f:	57                   	push   di
    2e40:	9a 3d 4c 94 2e       	call   0x2e94:0x4c3d
    2e45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e48:	06                   	push   es
    2e49:	57                   	push   di
    2e4a:	9a d3 31 57 2e       	call   0x2e57:0x31d3
    2e4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e52:	06                   	push   es
    2e53:	57                   	push   di
    2e54:	9a ac 1e 8a 2e       	call   0x2e8a:0x1eac
    2e59:	c9                   	leave
    2e5a:	ca 04 00             	retf   0x4
    2e5d:	55                   	push   bp
    2e5e:	89 e5                	mov    bp,sp
    2e60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e63:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2e68:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    2e6d:	74 27                	je     0x2e96
    2e6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e72:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2e77:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    2e7b:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    2e80:	7e 14                	jle    0x2e96
    2e82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e85:	06                   	push   es
    2e86:	57                   	push   di
    2e87:	9a d3 31 56 2f       	call   0x2f56:0x31d3
    2e8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e8f:	06                   	push   es
    2e90:	57                   	push   di
    2e91:	9a 4a 58 ab 2e       	call   0x2eab:0x584a
    2e96:	c9                   	leave
    2e97:	ca 04 00             	retf   0x4
    2e9a:	55                   	push   bp
    2e9b:	89 e5                	mov    bp,sp
    2e9d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ea0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ea3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea6:	06                   	push   es
    2ea7:	57                   	push   di
    2ea8:	9a da 3d b7 2e       	call   0x2eb7:0x3dda
    2ead:	08 c0                	or     al,al
    2eaf:	74 08                	je     0x2eb9
    2eb1:	68 1f f2             	push   0xf21f
    2eb4:	9a ef 11 cc 2e       	call   0x2ecc:0x11ef
    2eb9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ebc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ebf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ec2:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2ec7:	06                   	push   es
    2ec8:	57                   	push   di
    2ec9:	9a 31 77 dd 2e       	call   0x2edd:0x7731
    2ece:	c9                   	leave
    2ecf:	ca 08 00             	retf   0x8
    2ed2:	55                   	push   bp
    2ed3:	89 e5                	mov    bp,sp
    2ed5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed8:	06                   	push   es
    2ed9:	57                   	push   di
    2eda:	9a e5 31 fa 2e       	call   0x2efa:0x31e5
    2edf:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2ee2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ee5:	26 88 85 80 01       	mov    BYTE PTR es:[di+0x180],al
    2eea:	c9                   	leave
    2eeb:	ca 06 00             	retf   0x6
    2eee:	c8 a0 00 00          	enter  0xa0,0x0
    2ef2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ef5:	06                   	push   es
    2ef6:	57                   	push   di
    2ef7:	9a 02 32 08 2f       	call   0x2f08:0x3202
    2efc:	08 c0                	or     al,al
    2efe:	74 0a                	je     0x2f0a
    2f00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f03:	06                   	push   es
    2f04:	57                   	push   di
    2f05:	9a 3d 4c 34 2f       	call   0x2f34:0x4c3d
    2f0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f0d:	81 c7 d4 01          	add    di,0x1d4
    2f11:	06                   	push   es
    2f12:	57                   	push   di
    2f13:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f16:	06                   	push   es
    2f17:	57                   	push   di
    2f18:	9a be 18 80 2f       	call   0x2f80:0x18be
    2f1d:	75 0d                	jne    0x2f2c
    2f1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f22:	26 8a 85 83 01       	mov    al,BYTE PTR es:[di+0x183]
    2f27:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    2f2a:	74 78                	je     0x2fa4
    2f2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f2f:	06                   	push   es
    2f30:	57                   	push   di
    2f31:	9a 02 32 6b 2f       	call   0x2f6b:0x3202
    2f36:	08 c0                	or     al,al
    2f38:	74 33                	je     0x2f6d
    2f3a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f3d:	06                   	push   es
    2f3e:	57                   	push   di
    2f3f:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f42:	50                   	push   ax
    2f43:	8d 7e 80             	lea    di,[bp-0x80]
    2f46:	16                   	push   ss
    2f47:	57                   	push   di
    2f48:	8d be 60 ff          	lea    di,[bp-0xa0]
    2f4c:	16                   	push   ss
    2f4d:	57                   	push   di
    2f4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f51:	06                   	push   es
    2f52:	57                   	push   di
    2f53:	9a da 29 c2 2f       	call   0x2fc2:0x29da
    2f58:	8d 7e 80             	lea    di,[bp-0x80]
    2f5b:	16                   	push   ss
    2f5c:	57                   	push   di
    2f5d:	8d be 60 ff          	lea    di,[bp-0xa0]
    2f61:	16                   	push   ss
    2f62:	57                   	push   di
    2f63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f66:	06                   	push   es
    2f67:	57                   	push   di
    2f68:	9a 16 39 92 2f       	call   0x2f92:0x3916
    2f6d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f70:	06                   	push   es
    2f71:	57                   	push   di
    2f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f75:	81 c7 d4 01          	add    di,0x1d4
    2f79:	06                   	push   es
    2f7a:	57                   	push   di
    2f7b:	6a 7f                	push   0x7f
    2f7d:	9a e7 17 37 30       	call   0x3037:0x17e7
    2f82:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f88:	26 88 85 83 01       	mov    BYTE PTR es:[di+0x183],al
    2f8d:	06                   	push   es
    2f8e:	57                   	push   di
    2f8f:	9a 02 32 a2 2f       	call   0x2fa2:0x3202
    2f94:	08 c0                	or     al,al
    2f96:	74 0c                	je     0x2fa4
    2f98:	6a 00                	push   0x0
    2f9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f9d:	06                   	push   es
    2f9e:	57                   	push   di
    2f9f:	9a 1e 4b 06 30       	call   0x3006:0x4b1e
    2fa4:	c9                   	leave
    2fa5:	ca 0a 00             	retf   0xa
    2fa8:	55                   	push   bp
    2fa9:	89 e5                	mov    bp,sp
    2fab:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2fae:	06                   	push   es
    2faf:	57                   	push   di
    2fb0:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2fb4:	b0 00                	mov    al,0x0
    2fb6:	74 01                	je     0x2fb9
    2fb8:	40                   	inc    ax
    2fb9:	50                   	push   ax
    2fba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fbd:	06                   	push   es
    2fbe:	57                   	push   di
    2fbf:	9a ee 2e da 2f       	call   0x2fda:0x2eee
    2fc4:	c9                   	leave
    2fc5:	ca 08 00             	retf   0x8
    2fc8:	55                   	push   bp
    2fc9:	89 e5                	mov    bp,sp
    2fcb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2fce:	06                   	push   es
    2fcf:	57                   	push   di
    2fd0:	6a 00                	push   0x0
    2fd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd5:	06                   	push   es
    2fd6:	57                   	push   di
    2fd7:	9a ee 2e f5 2f       	call   0x2ff5:0x2eee
    2fdc:	c9                   	leave
    2fdd:	ca 08 00             	retf   0x8
    2fe0:	55                   	push   bp
    2fe1:	89 e5                	mov    bp,sp
    2fe3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2fe6:	06                   	push   es
    2fe7:	57                   	push   di
    2fe8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2feb:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2ff0:	06                   	push   es
    2ff1:	57                   	push   di
    2ff2:	9a b3 1d 6f 30       	call   0x306f:0x1db3
    2ff7:	c9                   	leave
    2ff8:	ca 08 00             	retf   0x8
    2ffb:	55                   	push   bp
    2ffc:	89 e5                	mov    bp,sp
    2ffe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3001:	06                   	push   es
    3002:	57                   	push   di
    3003:	9a e5 31 22 30       	call   0x3022:0x31e5
    3008:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    300b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    300e:	26 88 85 81 01       	mov    BYTE PTR es:[di+0x181],al
    3013:	c9                   	leave
    3014:	ca 06 00             	retf   0x6
    3017:	55                   	push   bp
    3018:	89 e5                	mov    bp,sp
    301a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    301d:	06                   	push   es
    301e:	57                   	push   di
    301f:	9a e5 31 5a 30       	call   0x305a:0x31e5
    3024:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3027:	06                   	push   es
    3028:	57                   	push   di
    3029:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    302c:	81 c7 84 01          	add    di,0x184
    3030:	06                   	push   es
    3031:	57                   	push   di
    3032:	6a 4f                	push   0x4f
    3034:	9a e7 17 03 32       	call   0x3203:0x17e7
    3039:	6a 08                	push   0x8
    303b:	6a 00                	push   0x0
    303d:	6a 00                	push   0x0
    303f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3042:	06                   	push   es
    3043:	57                   	push   di
    3044:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3047:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    304b:	c9                   	leave
    304c:	ca 08 00             	retf   0x8
    304f:	55                   	push   bp
    3050:	89 e5                	mov    bp,sp
    3052:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3055:	06                   	push   es
    3056:	57                   	push   di
    3057:	9a e5 31 b8 30       	call   0x30b8:0x31e5
    305c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    305f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3062:	26 88 85 82 01       	mov    BYTE PTR es:[di+0x182],al
    3067:	c9                   	leave
    3068:	ca 06 00             	retf   0x6
    306b:	00 00                	add    BYTE PTR [bx+si],al
    306d:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    306e:	31 75 30             	xor    WORD PTR [di+0x30],si
    3071:	00 00                	add    BYTE PTR [bx+si],al
    3073:	bd 31 f1             	mov    bp,0xf131
    3076:	30 c8                	xor    al,cl
    3078:	4e                   	dec    si
    3079:	04 00                	add    al,0x0
    307b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    307e:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    3083:	26 80 7d 0c 00       	cmp    BYTE PTR es:[di+0xc],0x0
    3088:	74 03                	je     0x308d
    308a:	e9 42 01             	jmp    0x31cf
    308d:	6a 05                	push   0x5
    308f:	6a 01                	push   0x1
    3091:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3094:	06                   	push   es
    3095:	57                   	push   di
    3096:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3099:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    309e:	b8 71 30             	mov    ax,0x3071
    30a1:	0e                   	push   cs
    30a2:	50                   	push   ax
    30a3:	55                   	push   bp
    30a4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    30a8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    30ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30af:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    30b3:	06                   	push   es
    30b4:	57                   	push   di
    30b5:	9a d0 2d c2 30       	call   0x30c2:0x2dd0
    30ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30bd:	06                   	push   es
    30be:	57                   	push   di
    30bf:	9a 2b 5f ce 30       	call   0x30ce:0x5f2b
    30c4:	52                   	push   dx
    30c5:	50                   	push   ax
    30c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30c9:	06                   	push   es
    30ca:	57                   	push   di
    30cb:	9a 65 5f e5 30       	call   0x30e5:0x5f65
    30d0:	52                   	push   dx
    30d1:	50                   	push   ax
    30d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30d5:	81 c7 84 01          	add    di,0x184
    30d9:	06                   	push   es
    30da:	57                   	push   di
    30db:	8d 7e ac             	lea    di,[bp-0x54]
    30de:	16                   	push   ss
    30df:	57                   	push   di
    30e0:	6a 4f                	push   0x4f
    30e2:	9a b7 0e ee 31       	call   0x31ee:0xeb7
    30e7:	52                   	push   dx
    30e8:	50                   	push   ax
    30e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30ec:	06                   	push   es
    30ed:	57                   	push   di
    30ee:	9a 5d 2b 24 31       	call   0x3124:0x2b5d
    30f3:	52                   	push   dx
    30f4:	50                   	push   ax
    30f5:	8d 7e fc             	lea    di,[bp-0x4]
    30f8:	16                   	push   ss
    30f9:	57                   	push   di
    30fa:	9a ed 01 3b 31       	call   0x313b:0x1ed
    30ff:	50                   	push   ax
    3100:	e8 01 e5             	call   0x1604
    3103:	08 c0                	or     al,al
    3105:	75 02                	jne    0x3109
    3107:	eb b1                	jmp    0x30ba
    3109:	b8 6b 30             	mov    ax,0x306b
    310c:	0e                   	push   cs
    310d:	50                   	push   ax
    310e:	55                   	push   bp
    310f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3113:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3117:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    311a:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    311f:	06                   	push   es
    3120:	57                   	push   di
    3121:	9a 55 19 6b 31       	call   0x316b:0x1955
    3126:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3129:	ff 76 fc             	push   WORD PTR [bp-0x4]
    312c:	6a 00                	push   0x0
    312e:	8d be b2 fb          	lea    di,[bp-0x44e]
    3132:	16                   	push   ss
    3133:	57                   	push   di
    3134:	6a 00                	push   0x0
    3136:	6a 00                	push   0x0
    3138:	9a ed 00 ae 31       	call   0x31ae:0xed
    313d:	09 c0                	or     ax,ax
    313f:	75 4c                	jne    0x318d
    3141:	83 be 7a fc 00       	cmp    WORD PTR [bp-0x386],0x0
    3146:	74 43                	je     0x318b
    3148:	8d be b2 fb          	lea    di,[bp-0x44e]
    314c:	16                   	push   ss
    314d:	57                   	push   di
    314e:	8d 7e 8a             	lea    di,[bp-0x76]
    3151:	16                   	push   ss
    3152:	57                   	push   di
    3153:	6a 1f                	push   0x1f
    3155:	8d be 8a fe          	lea    di,[bp-0x176]
    3159:	16                   	push   ss
    315a:	57                   	push   di
    315b:	68 ff 00             	push   0xff
    315e:	8d 7e ab             	lea    di,[bp-0x55]
    3161:	16                   	push   ss
    3162:	57                   	push   di
    3163:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3166:	06                   	push   es
    3167:	57                   	push   di
    3168:	9a f4 23 89 31       	call   0x3189:0x23f4
    316d:	8d 7e 8a             	lea    di,[bp-0x76]
    3170:	16                   	push   ss
    3171:	57                   	push   di
    3172:	8d be 8a fe          	lea    di,[bp-0x176]
    3176:	16                   	push   ss
    3177:	57                   	push   di
    3178:	8a 46 ab             	mov    al,BYTE PTR [bp-0x55]
    317b:	50                   	push   ax
    317c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    317f:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    3184:	06                   	push   es
    3185:	57                   	push   di
    3186:	9a f6 18 42 32       	call   0x3242:0x18f6
    318b:	eb 99                	jmp    0x3126
    318d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3190:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    3195:	26 c6 45 0c 01       	mov    BYTE PTR es:[di+0xc],0x1
    319a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    319e:	83 c4 06             	add    sp,0x6
    31a1:	b8 b1 31             	mov    ax,0x31b1
    31a4:	0e                   	push   cs
    31a5:	50                   	push   ax
    31a6:	8d 7e fc             	lea    di,[bp-0x4]
    31a9:	16                   	push   ss
    31aa:	57                   	push   di
    31ab:	9a ad 00 0c 52       	call   0x520c:0xad
    31b0:	cb                   	retf
    31b1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    31b5:	83 c4 06             	add    sp,0x6
    31b8:	b8 cf 31             	mov    ax,0x31cf
    31bb:	0e                   	push   cs
    31bc:	50                   	push   ax
    31bd:	6a 05                	push   0x5
    31bf:	6a 00                	push   0x0
    31c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31c4:	06                   	push   es
    31c5:	57                   	push   di
    31c6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31c9:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    31ce:	cb                   	retf
    31cf:	c9                   	leave
    31d0:	ca 04 00             	retf   0x4
    31d3:	55                   	push   bp
    31d4:	89 e5                	mov    bp,sp
    31d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31d9:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    31de:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    31e2:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    31e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e9:	06                   	push   es
    31ea:	57                   	push   di
    31eb:	9a 0f 5a bf 35       	call   0x35bf:0x5a0f
    31f0:	c9                   	leave
    31f1:	ca 04 00             	retf   0x4
    31f4:	55                   	push   bp
    31f5:	89 e5                	mov    bp,sp
    31f7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    31fb:	74 08                	je     0x3205
    31fd:	83 ec 08             	sub    sp,0x8
    3200:	9a e2 1f 13 32       	call   0x3213:0x1fe2
    3205:	b0 01                	mov    al,0x1
    3207:	50                   	push   ax
    3208:	b8 a3 02             	mov    ax,0x2a3
    320b:	ba 03 33             	mov    dx,0x3303
    320e:	52                   	push   dx
    320f:	50                   	push   ax
    3210:	9a 50 1f 50 32       	call   0x3250:0x1f50
    3215:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3218:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    321c:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3220:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3224:	74 07                	je     0x322d
    3226:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    322a:	83 c4 06             	add    sp,0x6
    322d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3230:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    3233:	c9                   	leave
    3234:	ca 06 00             	retf   0x6
    3237:	55                   	push   bp
    3238:	89 e5                	mov    bp,sp
    323a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    323d:	06                   	push   es
    323e:	57                   	push   di
    323f:	9a d0 34 7c 32       	call   0x327c:0x34d0
    3244:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3247:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    324b:	06                   	push   es
    324c:	57                   	push   di
    324d:	9a 7f 1f 5d 32       	call   0x325d:0x1f7f
    3252:	31 c0                	xor    ax,ax
    3254:	50                   	push   ax
    3255:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3258:	06                   	push   es
    3259:	57                   	push   di
    325a:	9a 66 1f 68 32       	call   0x3268:0x1f66
    325f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3263:	74 05                	je     0x326a
    3265:	9a 0f 20 83 32       	call   0x3283:0x200f
    326a:	c9                   	leave
    326b:	ca 06 00             	retf   0x6
    326e:	c8 08 00 00          	enter  0x8,0x0
    3272:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3275:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3278:	bf 75 03             	mov    di,0x375
    327b:	b8 91 32             	mov    ax,0x3291
    327e:	50                   	push   ax
    327f:	57                   	push   di
    3280:	9a 55 22 1d 33       	call   0x331d:0x2255
    3285:	08 c0                	or     al,al
    3287:	74 6c                	je     0x32f5
    3289:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    328c:	06                   	push   es
    328d:	57                   	push   di
    328e:	9a d0 34 9b 32       	call   0x329b:0x34d0
    3293:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3296:	06                   	push   es
    3297:	57                   	push   di
    3298:	9a b7 34 bf 32       	call   0x32bf:0x34b7
    329d:	48                   	dec    ax
    329e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    32a1:	31 c0                	xor    ax,ax
    32a3:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    32a6:	7f 4b                	jg     0x32f3
    32a8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    32ab:	eb 03                	jmp    0x32b0
    32ad:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    32b0:	ff 76 08             	push   WORD PTR [bp+0x8]
    32b3:	ff 76 06             	push   WORD PTR [bp+0x6]
    32b6:	6a 00                	push   0x0
    32b8:	b0 01                	mov    al,0x1
    32ba:	50                   	push   ax
    32bb:	b8 4e 03             	mov    ax,0x34e
    32be:	ba c6 32             	mov    dx,0x32c6
    32c1:	52                   	push   dx
    32c2:	50                   	push   ax
    32c3:	9a 3e 39 dd 32       	call   0x32dd:0x393e
    32c8:	89 c7                	mov    di,ax
    32ca:	8e c2                	mov    es,dx
    32cc:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    32cf:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    32d2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    32d5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    32d8:	06                   	push   es
    32d9:	57                   	push   di
    32da:	9a 00 35 e9 32       	call   0x32e9:0x3500
    32df:	52                   	push   dx
    32e0:	50                   	push   ax
    32e1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    32e4:	06                   	push   es
    32e5:	57                   	push   di
    32e6:	9a 9d 3e 16 33       	call   0x3316:0x3e9d
    32eb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    32ee:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    32f1:	75 ba                	jne    0x32ad
    32f3:	eb 10                	jmp    0x3305
    32f5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    32f8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    32fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32fe:	06                   	push   es
    32ff:	57                   	push   di
    3300:	9a fa 10 45 33       	call   0x3345:0x10fa
    3305:	c9                   	leave
    3306:	ca 08 00             	retf   0x8
    3309:	55                   	push   bp
    330a:	89 e5                	mov    bp,sp
    330c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    330f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3312:	bf 75 03             	mov    di,0x375
    3315:	b8 57 33             	mov    ax,0x3357
    3318:	50                   	push   ax
    3319:	57                   	push   di
    331a:	9a 55 22 cb 33       	call   0x33cb:0x2255
    331f:	08 c0                	or     al,al
    3321:	74 14                	je     0x3337
    3323:	ff 76 08             	push   WORD PTR [bp+0x8]
    3326:	ff 76 06             	push   WORD PTR [bp+0x6]
    3329:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    332c:	06                   	push   es
    332d:	57                   	push   di
    332e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3331:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    3335:	eb 10                	jmp    0x3347
    3337:	ff 76 0c             	push   WORD PTR [bp+0xc]
    333a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    333d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3340:	06                   	push   es
    3341:	57                   	push   di
    3342:	9a cd 11 24 34       	call   0x3424:0x11cd
    3347:	c9                   	leave
    3348:	ca 08 00             	retf   0x8
    334b:	c8 08 02 00          	enter  0x208,0x0
    334f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3352:	06                   	push   es
    3353:	57                   	push   di
    3354:	9a b7 34 77 33       	call   0x3377:0x34b7
    3359:	48                   	dec    ax
    335a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    335d:	31 c0                	xor    ax,ax
    335f:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    3362:	7e 03                	jle    0x3367
    3364:	e9 a4 00             	jmp    0x340b
    3367:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    336a:	eb 03                	jmp    0x336f
    336c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    336f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3372:	06                   	push   es
    3373:	57                   	push   di
    3374:	9a b7 34 9d 33       	call   0x339d:0x34b7
    3379:	48                   	dec    ax
    337a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    337d:	31 c0                	xor    ax,ax
    337f:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3382:	7f 7c                	jg     0x3400
    3384:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3387:	eb 03                	jmp    0x338c
    3389:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    338c:	8d be f8 fe          	lea    di,[bp-0x108]
    3390:	16                   	push   ss
    3391:	57                   	push   di
    3392:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3395:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3398:	06                   	push   es
    3399:	57                   	push   di
    339a:	9a 00 35 a8 33       	call   0x33a8:0x3500
    339f:	89 c7                	mov    di,ax
    33a1:	8e c2                	mov    es,dx
    33a3:	06                   	push   es
    33a4:	57                   	push   di
    33a5:	9a 56 3a bb 33       	call   0x33bb:0x3a56
    33aa:	8d be f8 fd          	lea    di,[bp-0x208]
    33ae:	16                   	push   ss
    33af:	57                   	push   di
    33b0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    33b3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    33b6:	06                   	push   es
    33b7:	57                   	push   di
    33b8:	9a 00 35 c6 33       	call   0x33c6:0x3500
    33bd:	89 c7                	mov    di,ax
    33bf:	8e c2                	mov    es,dx
    33c1:	06                   	push   es
    33c2:	57                   	push   di
    33c3:	9a 56 3a da 33       	call   0x33da:0x3a56
    33c8:	9a be 18 f8 34       	call   0x34f8:0x18be
    33cd:	75 29                	jne    0x33f8
    33cf:	ff 76 fc             	push   WORD PTR [bp-0x4]
    33d2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    33d5:	06                   	push   es
    33d6:	57                   	push   di
    33d7:	9a 00 35 e9 33       	call   0x33e9:0x3500
    33dc:	52                   	push   dx
    33dd:	50                   	push   ax
    33de:	ff 76 fe             	push   WORD PTR [bp-0x2]
    33e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33e4:	06                   	push   es
    33e5:	57                   	push   di
    33e6:	9a 00 35 f4 33       	call   0x33f4:0x3500
    33eb:	89 c7                	mov    di,ax
    33ed:	8e c2                	mov    es,dx
    33ef:	06                   	push   es
    33f0:	57                   	push   di
    33f1:	9a 9d 3e 78 34       	call   0x3478:0x3e9d
    33f6:	eb 08                	jmp    0x3400
    33f8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    33fb:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    33fe:	75 89                	jne    0x3389
    3400:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3403:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    3406:	74 03                	je     0x340b
    3408:	e9 61 ff             	jmp    0x336c
    340b:	c9                   	leave
    340c:	ca 08 00             	retf   0x8
    340f:	55                   	push   bp
    3410:	89 e5                	mov    bp,sp
    3412:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3415:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3418:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    341b:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    341f:	06                   	push   es
    3420:	57                   	push   di
    3421:	9a 2b 0c 50 34       	call   0x3450:0xc2b
    3426:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3429:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    342c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    342f:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    3433:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    3437:	c9                   	leave
    3438:	ca 08 00             	retf   0x8
    343b:	55                   	push   bp
    343c:	89 e5                	mov    bp,sp
    343e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3441:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3444:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3447:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    344b:	06                   	push   es
    344c:	57                   	push   di
    344d:	9a a7 0f ed 34       	call   0x34ed:0xfa7
    3452:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3455:	31 c0                	xor    ax,ax
    3457:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    345b:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    345f:	c9                   	leave
    3460:	ca 08 00             	retf   0x8
    3463:	c8 08 00 00          	enter  0x8,0x0
    3467:	ff 76 08             	push   WORD PTR [bp+0x8]
    346a:	ff 76 06             	push   WORD PTR [bp+0x6]
    346d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3470:	50                   	push   ax
    3471:	b0 01                	mov    al,0x1
    3473:	50                   	push   ax
    3474:	b8 4e 03             	mov    ax,0x34e
    3477:	ba 7f 34             	mov    dx,0x347f
    347a:	52                   	push   dx
    347b:	50                   	push   ax
    347c:	9a 3e 39 9d 34       	call   0x349d:0x393e
    3481:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3484:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3487:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    348a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    348d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3490:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    3493:	06                   	push   es
    3494:	57                   	push   di
    3495:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3498:	06                   	push   es
    3499:	57                   	push   di
    349a:	9a 3c 3a ab 34       	call   0x34ab:0x3a3c
    349f:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    34a2:	50                   	push   ax
    34a3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    34a6:	06                   	push   es
    34a7:	57                   	push   di
    34a8:	9a 0b 3a 24 35       	call   0x3524:0x3a0b
    34ad:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    34b0:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    34b3:	c9                   	leave
    34b4:	ca 0c 00             	retf   0xc
    34b7:	c8 02 00 00          	enter  0x2,0x0
    34bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34be:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    34c2:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    34c6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    34c9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    34cc:	c9                   	leave
    34cd:	ca 04 00             	retf   0x4
    34d0:	55                   	push   bp
    34d1:	89 e5                	mov    bp,sp
    34d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34d6:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    34da:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    34df:	7e 1b                	jle    0x34fc
    34e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34e4:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    34e8:	06                   	push   es
    34e9:	57                   	push   di
    34ea:	9a 43 0f 19 35       	call   0x3519:0xf43
    34ef:	89 c7                	mov    di,ax
    34f1:	8e c2                	mov    es,dx
    34f3:	06                   	push   es
    34f4:	57                   	push   di
    34f5:	9a 7f 1f 4d 39       	call   0x394d:0x1f7f
    34fa:	eb d7                	jmp    0x34d3
    34fc:	c9                   	leave
    34fd:	ca 04 00             	retf   0x4
    3500:	c8 04 01 00          	enter  0x104,0x0
    3504:	8d be fc fe          	lea    di,[bp-0x104]
    3508:	16                   	push   ss
    3509:	57                   	push   di
    350a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    350d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3510:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    3514:	06                   	push   es
    3515:	57                   	push   di
    3516:	9a d0 0d 71 35       	call   0x3571:0xdd0
    351b:	89 c7                	mov    di,ax
    351d:	8e c2                	mov    es,dx
    351f:	06                   	push   es
    3520:	57                   	push   di
    3521:	9a 56 3a 2e 35       	call   0x352e:0x3a56
    3526:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3529:	06                   	push   es
    352a:	57                   	push   di
    352b:	9a 40 35 87 35       	call   0x3587:0x3540
    3530:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3533:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3536:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3539:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    353c:	c9                   	leave
    353d:	ca 06 00             	retf   0x6
    3540:	c8 08 01 00          	enter  0x108,0x0
    3544:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3547:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    354b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    354f:	48                   	dec    ax
    3550:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3553:	31 c0                	xor    ax,ax
    3555:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3558:	7f 47                	jg     0x35a1
    355a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    355d:	eb 03                	jmp    0x3562
    355f:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    3562:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3565:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3568:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    356c:	06                   	push   es
    356d:	57                   	push   di
    356e:	9a d0 0d e1 35       	call   0x35e1:0xdd0
    3573:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3576:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3579:	8d be f8 fe          	lea    di,[bp-0x108]
    357d:	16                   	push   ss
    357e:	57                   	push   di
    357f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3582:	06                   	push   es
    3583:	57                   	push   di
    3584:	9a 56 3a f1 35       	call   0x35f1:0x3a56
    3589:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    358c:	06                   	push   es
    358d:	57                   	push   di
    358e:	9a ed 07 e6 39       	call   0x39e6:0x7ed
    3593:	09 c0                	or     ax,ax
    3595:	75 02                	jne    0x3599
    3597:	eb 28                	jmp    0x35c1
    3599:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    359c:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    359f:	75 be                	jne    0x355f
    35a1:	68 2c f2             	push   0xf22c
    35a4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    35a7:	89 f8                	mov    ax,di
    35a9:	8c c2                	mov    dx,es
    35ab:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    35ae:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    35b1:	c6 46 f6 04          	mov    BYTE PTR [bp-0xa],0x4
    35b5:	8d 7e f2             	lea    di,[bp-0xe]
    35b8:	16                   	push   ss
    35b9:	57                   	push   di
    35ba:	6a 00                	push   0x0
    35bc:	9a 0a 12 66 36       	call   0x3666:0x120a
    35c1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    35c4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    35c7:	c9                   	leave
    35c8:	ca 08 00             	retf   0x8
    35cb:	04 44                	add    al,0x44
    35cd:	61                   	popa
    35ce:	74 61                	je     0x3631
    35d0:	55                   	push   bp
    35d1:	89 e5                	mov    bp,sp
    35d3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    35d6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    35d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35dc:	06                   	push   es
    35dd:	57                   	push   di
    35de:	9a e4 11 4f 36       	call   0x364f:0x11e4
    35e3:	bf cb 35             	mov    di,0x35cb
    35e6:	0e                   	push   cs
    35e7:	57                   	push   di
    35e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35eb:	06                   	push   es
    35ec:	57                   	push   di
    35ed:	bf 24 36             	mov    di,0x3624
    35f0:	b8 fe 35             	mov    ax,0x35fe
    35f3:	50                   	push   ax
    35f4:	57                   	push   di
    35f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35f8:	06                   	push   es
    35f9:	57                   	push   di
    35fa:	bf b7 37             	mov    di,0x37b7
    35fd:	b8 0a 36             	mov    ax,0x360a
    3600:	50                   	push   ax
    3601:	57                   	push   di
    3602:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3605:	06                   	push   es
    3606:	57                   	push   di
    3607:	9a b7 34 30 36       	call   0x3630:0x34b7
    360c:	09 c0                	or     ax,ax
    360e:	b0 00                	mov    al,0x0
    3610:	7e 01                	jle    0x3613
    3612:	40                   	inc    ax
    3613:	50                   	push   ax
    3614:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3617:	06                   	push   es
    3618:	57                   	push   di
    3619:	26 c4 3d             	les    di,DWORD PTR es:[di]
    361c:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    3620:	c9                   	leave
    3621:	ca 08 00             	retf   0x8
    3624:	c8 10 02 00          	enter  0x210,0x0
    3628:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    362b:	06                   	push   es
    362c:	57                   	push   di
    362d:	9a d0 34 59 36       	call   0x3659:0x34d0
    3632:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3635:	89 be f6 fd          	mov    WORD PTR [bp-0x20a],di
    3639:	8c 86 f8 fd          	mov    WORD PTR [bp-0x208],es
    363d:	8d 7e fc             	lea    di,[bp-0x4]
    3640:	16                   	push   ss
    3641:	57                   	push   di
    3642:	6a 00                	push   0x0
    3644:	6a 02                	push   0x2
    3646:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    364a:	06                   	push   es
    364b:	57                   	push   di
    364c:	9a 11 24 7a 36       	call   0x367a:0x2411
    3651:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3654:	06                   	push   es
    3655:	57                   	push   di
    3656:	9a 2e 39 a6 36       	call   0x36a6:0x392e
    365b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    365e:	74 08                	je     0x3668
    3660:	68 61 f2             	push   0xf261
    3663:	9a ef 11 c6 3a       	call   0x3ac6:0x11ef
    3668:	8d 7e fa             	lea    di,[bp-0x6]
    366b:	16                   	push   ss
    366c:	57                   	push   di
    366d:	6a 00                	push   0x0
    366f:	6a 02                	push   0x2
    3671:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    3675:	06                   	push   es
    3676:	57                   	push   di
    3677:	9a 11 24 ce 36       	call   0x36ce:0x2411
    367c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    367f:	48                   	dec    ax
    3680:	89 86 f4 fd          	mov    WORD PTR [bp-0x20c],ax
    3684:	31 c0                	xor    ax,ax
    3686:	3b 86 f4 fd          	cmp    ax,WORD PTR [bp-0x20c]
    368a:	7e 03                	jle    0x368f
    368c:	e9 24 01             	jmp    0x37b3
    368f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3692:	eb 03                	jmp    0x3697
    3694:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3697:	ff 76 08             	push   WORD PTR [bp+0x8]
    369a:	ff 76 06             	push   WORD PTR [bp+0x6]
    369d:	6a 00                	push   0x0
    369f:	b0 01                	mov    al,0x1
    36a1:	50                   	push   ax
    36a2:	b8 4e 03             	mov    ax,0x34e
    36a5:	ba ad 36             	mov    dx,0x36ad
    36a8:	52                   	push   dx
    36a9:	50                   	push   ax
    36aa:	9a 3e 39 fa 36       	call   0x36fa:0x393e
    36af:	89 c7                	mov    di,ax
    36b1:	8e c2                	mov    es,dx
    36b3:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    36b7:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    36bb:	8d be fa fd          	lea    di,[bp-0x206]
    36bf:	16                   	push   ss
    36c0:	57                   	push   di
    36c1:	6a 00                	push   0x0
    36c3:	6a 01                	push   0x1
    36c5:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    36c9:	06                   	push   es
    36ca:	57                   	push   di
    36cb:	9a 11 24 e9 36       	call   0x36e9:0x2411
    36d0:	8d be fb fd          	lea    di,[bp-0x205]
    36d4:	16                   	push   ss
    36d5:	57                   	push   di
    36d6:	8a 86 fa fd          	mov    al,BYTE PTR [bp-0x206]
    36da:	30 e4                	xor    ah,ah
    36dc:	31 d2                	xor    dx,dx
    36de:	52                   	push   dx
    36df:	50                   	push   ax
    36e0:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    36e4:	06                   	push   es
    36e5:	57                   	push   di
    36e6:	9a 11 24 13 37       	call   0x3713:0x2411
    36eb:	8d be fa fd          	lea    di,[bp-0x206]
    36ef:	16                   	push   ss
    36f0:	57                   	push   di
    36f1:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    36f5:	06                   	push   es
    36f6:	57                   	push   di
    36f7:	9a 3c 3a 73 37       	call   0x3773:0x3a3c
    36fc:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    3700:	81 c7 1b 00          	add    di,0x1b
    3704:	06                   	push   es
    3705:	57                   	push   di
    3706:	6a 00                	push   0x0
    3708:	6a 01                	push   0x1
    370a:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    370e:	06                   	push   es
    370f:	57                   	push   di
    3710:	9a 11 24 2c 37       	call   0x372c:0x2411
    3715:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    3719:	81 c7 18 00          	add    di,0x18
    371d:	06                   	push   es
    371e:	57                   	push   di
    371f:	6a 00                	push   0x0
    3721:	6a 01                	push   0x1
    3723:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    3727:	06                   	push   es
    3728:	57                   	push   di
    3729:	9a 11 24 4b 37       	call   0x374b:0x2411
    372e:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    3732:	26 80 7d 18 00       	cmp    BYTE PTR es:[di+0x18],0x0
    3737:	74 3c                	je     0x3775
    3739:	8d 7e fc             	lea    di,[bp-0x4]
    373c:	16                   	push   ss
    373d:	57                   	push   di
    373e:	6a 00                	push   0x0
    3740:	6a 02                	push   0x2
    3742:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    3746:	06                   	push   es
    3747:	57                   	push   di
    3748:	9a 11 24 62 37       	call   0x3762:0x2411
    374d:	8d be fa fe          	lea    di,[bp-0x106]
    3751:	16                   	push   ss
    3752:	57                   	push   di
    3753:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3756:	99                   	cwd
    3757:	52                   	push   dx
    3758:	50                   	push   ax
    3759:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    375d:	06                   	push   es
    375e:	57                   	push   di
    375f:	9a 11 24 8c 37       	call   0x378c:0x2411
    3764:	8d be fa fe          	lea    di,[bp-0x106]
    3768:	16                   	push   ss
    3769:	57                   	push   di
    376a:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    376e:	06                   	push   es
    376f:	57                   	push   di
    3770:	9a d5 3c ce 37       	call   0x37ce:0x3cd5
    3775:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    3779:	81 c7 19 00          	add    di,0x19
    377d:	06                   	push   es
    377e:	57                   	push   di
    377f:	6a 00                	push   0x0
    3781:	6a 01                	push   0x1
    3783:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    3787:	06                   	push   es
    3788:	57                   	push   di
    3789:	9a 11 24 a5 37       	call   0x37a5:0x2411
    378e:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    3792:	81 c7 1a 00          	add    di,0x1a
    3796:	06                   	push   es
    3797:	57                   	push   di
    3798:	6a 00                	push   0x0
    379a:	6a 01                	push   0x1
    379c:	c4 be f6 fd          	les    di,DWORD PTR [bp-0x20a]
    37a0:	06                   	push   es
    37a1:	57                   	push   di
    37a2:	9a 11 24 e5 37       	call   0x37e5:0x2411
    37a7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    37aa:	3b 86 f4 fd          	cmp    ax,WORD PTR [bp-0x20c]
    37ae:	74 03                	je     0x37b3
    37b0:	e9 e1 fe             	jmp    0x3694
    37b3:	c9                   	leave
    37b4:	ca 08 00             	retf   0x8
    37b7:	c8 0e 01 00          	enter  0x10e,0x0
    37bb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    37be:	89 be f8 fe          	mov    WORD PTR [bp-0x108],di
    37c2:	8c 86 fa fe          	mov    WORD PTR [bp-0x106],es
    37c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37c9:	06                   	push   es
    37ca:	57                   	push   di
    37cb:	9a 2e 39 ef 37       	call   0x37ef:0x392e
    37d0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    37d3:	8d 7e fc             	lea    di,[bp-0x4]
    37d6:	16                   	push   ss
    37d7:	57                   	push   di
    37d8:	6a 00                	push   0x0
    37da:	6a 02                	push   0x2
    37dc:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    37e0:	06                   	push   es
    37e1:	57                   	push   di
    37e2:	9a 66 24 06 38       	call   0x3806:0x2466
    37e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37ea:	06                   	push   es
    37eb:	57                   	push   di
    37ec:	9a b7 34 10 38       	call   0x3810:0x34b7
    37f1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    37f4:	8d 7e fc             	lea    di,[bp-0x4]
    37f7:	16                   	push   ss
    37f8:	57                   	push   di
    37f9:	6a 00                	push   0x0
    37fb:	6a 02                	push   0x2
    37fd:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    3801:	06                   	push   es
    3802:	57                   	push   di
    3803:	9a 66 24 63 38       	call   0x3863:0x2466
    3808:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    380b:	06                   	push   es
    380c:	57                   	push   di
    380d:	9a b7 34 35 38       	call   0x3835:0x34b7
    3812:	48                   	dec    ax
    3813:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    3817:	31 c0                	xor    ax,ax
    3819:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    381d:	7e 03                	jle    0x3822
    381f:	e9 08 01             	jmp    0x392a
    3822:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3825:	eb 03                	jmp    0x382a
    3827:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    382a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    382d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3830:	06                   	push   es
    3831:	57                   	push   di
    3832:	9a 00 35 b1 38       	call   0x38b1:0x3500
    3837:	89 c7                	mov    di,ax
    3839:	8e c2                	mov    es,dx
    383b:	89 be f2 fe          	mov    WORD PTR [bp-0x10e],di
    383f:	8c 86 f4 fe          	mov    WORD PTR [bp-0x10c],es
    3843:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    3847:	06                   	push   es
    3848:	57                   	push   di
    3849:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    384d:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    3851:	26 8a 05             	mov    al,BYTE PTR es:[di]
    3854:	30 e4                	xor    ah,ah
    3856:	40                   	inc    ax
    3857:	99                   	cwd
    3858:	52                   	push   dx
    3859:	50                   	push   ax
    385a:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    385e:	06                   	push   es
    385f:	57                   	push   di
    3860:	9a 66 24 7c 38       	call   0x387c:0x2466
    3865:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    3869:	81 c7 1b 00          	add    di,0x1b
    386d:	06                   	push   es
    386e:	57                   	push   di
    386f:	6a 00                	push   0x0
    3871:	6a 01                	push   0x1
    3873:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    3877:	06                   	push   es
    3878:	57                   	push   di
    3879:	9a 66 24 95 38       	call   0x3895:0x2466
    387e:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    3882:	81 c7 18 00          	add    di,0x18
    3886:	06                   	push   es
    3887:	57                   	push   di
    3888:	6a 00                	push   0x0
    388a:	6a 01                	push   0x1
    388c:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    3890:	06                   	push   es
    3891:	57                   	push   di
    3892:	9a 66 24 d3 38       	call   0x38d3:0x2466
    3897:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    389b:	26 80 7d 18 00       	cmp    BYTE PTR es:[di+0x18],0x0
    38a0:	74 4a                	je     0x38ec
    38a2:	8d be fc fe          	lea    di,[bp-0x104]
    38a6:	16                   	push   ss
    38a7:	57                   	push   di
    38a8:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    38ac:	06                   	push   es
    38ad:	57                   	push   di
    38ae:	9a 46 3b bc 38       	call   0x38bc:0x3b46
    38b3:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    38b7:	06                   	push   es
    38b8:	57                   	push   di
    38b9:	9a 8b 3a 65 39       	call   0x3965:0x3a8b
    38be:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    38c1:	8d 7e fc             	lea    di,[bp-0x4]
    38c4:	16                   	push   ss
    38c5:	57                   	push   di
    38c6:	6a 00                	push   0x0
    38c8:	6a 02                	push   0x2
    38ca:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    38ce:	06                   	push   es
    38cf:	57                   	push   di
    38d0:	9a 66 24 ea 38       	call   0x38ea:0x2466
    38d5:	8d be fc fe          	lea    di,[bp-0x104]
    38d9:	16                   	push   ss
    38da:	57                   	push   di
    38db:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    38de:	99                   	cwd
    38df:	52                   	push   dx
    38e0:	50                   	push   ax
    38e1:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    38e5:	06                   	push   es
    38e6:	57                   	push   di
    38e7:	9a 66 24 03 39       	call   0x3903:0x2466
    38ec:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    38f0:	81 c7 19 00          	add    di,0x19
    38f4:	06                   	push   es
    38f5:	57                   	push   di
    38f6:	6a 00                	push   0x0
    38f8:	6a 01                	push   0x1
    38fa:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    38fe:	06                   	push   es
    38ff:	57                   	push   di
    3900:	9a 66 24 1c 39       	call   0x391c:0x2466
    3905:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    3909:	81 c7 1a 00          	add    di,0x1a
    390d:	06                   	push   es
    390e:	57                   	push   di
    390f:	6a 00                	push   0x0
    3911:	6a 01                	push   0x1
    3913:	c4 be f8 fe          	les    di,DWORD PTR [bp-0x108]
    3917:	06                   	push   es
    3918:	57                   	push   di
    3919:	9a 66 24 64 4d       	call   0x4d64:0x2466
    391e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3921:	3b 86 f6 fe          	cmp    ax,WORD PTR [bp-0x10a]
    3925:	74 03                	je     0x392a
    3927:	e9 fd fe             	jmp    0x3827
    392a:	c9                   	leave
    392b:	ca 08 00             	retf   0x8
    392e:	c8 02 00 00          	enter  0x2,0x0
    3932:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    3937:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    393a:	c9                   	leave
    393b:	ca 04 00             	retf   0x4
    393e:	55                   	push   bp
    393f:	89 e5                	mov    bp,sp
    3941:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3945:	74 08                	je     0x394f
    3947:	83 ec 08             	sub    sp,0x8
    394a:	9a e2 1f 01 3a       	call   0x3a01:0x1fe2
    394f:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    3952:	0b 46 10             	or     ax,WORD PTR [bp+0x10]
    3955:	74 10                	je     0x3967
    3957:	ff 76 08             	push   WORD PTR [bp+0x8]
    395a:	ff 76 06             	push   WORD PTR [bp+0x6]
    395d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3960:	06                   	push   es
    3961:	57                   	push   di
    3962:	9a 0f 34 8f 39       	call   0x398f:0x340f
    3967:	a1 16 17             	mov    ax,ds:0x1716
    396a:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    396e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3971:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    3975:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    3979:	a1 16 17             	mov    ax,ds:0x1716
    397c:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    3980:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    3984:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    3988:	6a 00                	push   0x0
    398a:	06                   	push   es
    398b:	57                   	push   di
    398c:	9a 0b 3a d6 39       	call   0x39d6:0x3a0b
    3991:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    3994:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3997:	26 88 45 1b          	mov    BYTE PTR es:[di+0x1b],al
    399b:	26 c6 45 1a 00       	mov    BYTE PTR es:[di+0x1a],0x0
    39a0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    39a4:	74 07                	je     0x39ad
    39a6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    39aa:	83 c4 06             	add    sp,0x6
    39ad:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    39b0:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    39b3:	c9                   	leave
    39b4:	ca 0c 00             	retf   0xc
    39b7:	55                   	push   bp
    39b8:	89 e5                	mov    bp,sp
    39ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39bd:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    39c1:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    39c5:	74 11                	je     0x39d8
    39c7:	ff 76 08             	push   WORD PTR [bp+0x8]
    39ca:	ff 76 06             	push   WORD PTR [bp+0x6]
    39cd:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    39d1:	06                   	push   es
    39d2:	57                   	push   di
    39d3:	9a 3b 34 d7 3b       	call   0x3bd7:0x343b
    39d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39db:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    39df:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    39e3:	9a 24 06 f6 39       	call   0x39f6:0x624
    39e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39eb:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    39ef:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    39f3:	9a 24 06 2c 3a       	call   0x3a2c:0x624
    39f8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    39fc:	74 05                	je     0x3a03
    39fe:	9a 0f 20 6d 3a       	call   0x3a6d:0x200f
    3a03:	c9                   	leave
    3a04:	ca 06 00             	retf   0x6
    3a07:	00 00                	add    BYTE PTR [bx+si],al
    3a09:	00 00                	add    BYTE PTR [bx+si],al
    3a0b:	55                   	push   bp
    3a0c:	89 e5                	mov    bp,sp
    3a0e:	9b 2e d9 06 07 3a    	fld    DWORD PTR cs:0x3a07
    3a14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a17:	9b 26 dd 5d 08       	fstp   QWORD PTR es:[di+0x8]
    3a1c:	90                   	nop
    3a1d:	9b                   	fwait
    3a1e:	81 c7 14 00          	add    di,0x14
    3a22:	06                   	push   es
    3a23:	57                   	push   di
    3a24:	bf 07 3a             	mov    di,0x3a07
    3a27:	0e                   	push   cs
    3a28:	57                   	push   di
    3a29:	9a 51 06 50 3a       	call   0x3a50:0x651
    3a2e:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3a31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a34:	26 88 45 18          	mov    BYTE PTR es:[di+0x18],al
    3a38:	c9                   	leave
    3a39:	ca 06 00             	retf   0x6
    3a3c:	55                   	push   bp
    3a3d:	89 e5                	mov    bp,sp
    3a3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a42:	81 c7 10 00          	add    di,0x10
    3a46:	06                   	push   es
    3a47:	57                   	push   di
    3a48:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a4b:	06                   	push   es
    3a4c:	57                   	push   di
    3a4d:	9a 51 06 ac 3b       	call   0x3bac:0x651
    3a52:	c9                   	leave
    3a53:	ca 08 00             	retf   0x8
    3a56:	55                   	push   bp
    3a57:	89 e5                	mov    bp,sp
    3a59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a5c:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    3a60:	06                   	push   es
    3a61:	57                   	push   di
    3a62:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a65:	06                   	push   es
    3a66:	57                   	push   di
    3a67:	68 ff 00             	push   0xff
    3a6a:	9a e7 17 19 3c       	call   0x3c19:0x17e7
    3a6f:	c9                   	leave
    3a70:	ca 04 00             	retf   0x4
    3a73:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    3a74:	3a ca                	cmp    cl,dl
    3a76:	3a f1                	cmp    dh,cl
    3a78:	3a ea                	cmp    ch,dl
    3a7a:	3a f8                	cmp    bh,al
    3a7c:	3a dc                	cmp    bl,ah
    3a7e:	3a e3                	cmp    ah,bl
    3a80:	3a e3                	cmp    ah,bl
    3a82:	3a e3                	cmp    ah,bl
    3a84:	3a ea                	cmp    ch,dl
    3a86:	3a ea                	cmp    ch,dl
    3a88:	3a e3                	cmp    ah,bl
    3a8a:	3a c8                	cmp    cl,al
    3a8c:	0a 00                	or     al,BYTE PTR [bx+si]
    3a8e:	00 c4                	add    ah,al
    3a90:	7e 06                	jle    0x3a98
    3a92:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    3a96:	3c 0b                	cmp    al,0xb
    3a98:	77 65                	ja     0x3aff
    3a9a:	98                   	cbw
    3a9b:	89 c3                	mov    bx,ax
    3a9d:	d1 e3                	shl    bx,1
    3a9f:	2e ff a7 73 3a       	jmp    WORD PTR cs:[bx+0x3a73]
    3aa4:	68 1b f2             	push   0xf21b
    3aa7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3aaa:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    3aae:	89 f8                	mov    ax,di
    3ab0:	8c c2                	mov    dx,es
    3ab2:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3ab5:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    3ab8:	c6 46 fa 04          	mov    BYTE PTR [bp-0x6],0x4
    3abc:	8d 7e f6             	lea    di,[bp-0xa]
    3abf:	16                   	push   ss
    3ac0:	57                   	push   di
    3ac1:	6a 00                	push   0x0
    3ac3:	9a 0a 12 21 3b       	call   0x3b21:0x120a
    3ac8:	eb 59                	jmp    0x3b23
    3aca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3acd:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    3ad1:	26 8a 05             	mov    al,BYTE PTR es:[di]
    3ad4:	30 e4                	xor    ah,ah
    3ad6:	40                   	inc    ax
    3ad7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3ada:	eb 47                	jmp    0x3b23
    3adc:	c7 46 fe 02 00       	mov    WORD PTR [bp-0x2],0x2
    3ae1:	eb 40                	jmp    0x3b23
    3ae3:	c7 46 fe 08 00       	mov    WORD PTR [bp-0x2],0x8
    3ae8:	eb 39                	jmp    0x3b23
    3aea:	c7 46 fe 04 00       	mov    WORD PTR [bp-0x2],0x4
    3aef:	eb 32                	jmp    0x3b23
    3af1:	c7 46 fe 02 00       	mov    WORD PTR [bp-0x2],0x2
    3af6:	eb 2b                	jmp    0x3b23
    3af8:	c7 46 fe 02 00       	mov    WORD PTR [bp-0x2],0x2
    3afd:	eb 24                	jmp    0x3b23
    3aff:	68 1c f2             	push   0xf21c
    3b02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b05:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    3b09:	89 f8                	mov    ax,di
    3b0b:	8c c2                	mov    dx,es
    3b0d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3b10:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    3b13:	c6 46 fa 04          	mov    BYTE PTR [bp-0x6],0x4
    3b17:	8d 7e f6             	lea    di,[bp-0xa]
    3b1a:	16                   	push   ss
    3b1b:	57                   	push   di
    3b1c:	6a 00                	push   0x0
    3b1e:	9a 0a 12 84 3b       	call   0x3b84:0x120a
    3b23:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3b26:	c9                   	leave
    3b27:	ca 04 00             	retf   0x4
    3b2a:	80 cb a4             	or     bl,0xa4
    3b2d:	4c                   	dec    sp
    3b2e:	62 3b                	bound  di,DWORD PTR [bp+di]
    3b30:	89 3b                	mov    WORD PTR [bp+di],di
    3b32:	cf                   	iret
    3b33:	3b f5                	cmp    si,bp
    3b35:	3b e2                	cmp    sp,dx
    3b37:	3b 7e 3c             	cmp    di,WORD PTR [bp+0x3c]
    3b3a:	69 3c 69 3c          	imul   di,WORD PTR [si],0x3c69
    3b3e:	69 3c 33 3c          	imul   di,WORD PTR [si],0x3c33
    3b42:	0c 3c                	or     al,0x3c
    3b44:	4e                   	dec    si
    3b45:	3c c8                	cmp    al,0xc8
    3b47:	08 00                	or     BYTE PTR [bx+si],al
    3b49:	00 c4                	add    ah,al
    3b4b:	7e 06                	jle    0x3b53
    3b4d:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    3b51:	3c 0b                	cmp    al,0xb
    3b53:	76 03                	jbe    0x3b58
    3b55:	e9 39 01             	jmp    0x3c91
    3b58:	98                   	cbw
    3b59:	89 c3                	mov    bx,ax
    3b5b:	d1 e3                	shl    bx,1
    3b5d:	2e ff a7 2e 3b       	jmp    WORD PTR cs:[bx+0x3b2e]
    3b62:	68 1b f2             	push   0xf21b
    3b65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b68:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    3b6c:	89 f8                	mov    ax,di
    3b6e:	8c c2                	mov    dx,es
    3b70:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3b73:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3b76:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    3b7a:	8d 7e f8             	lea    di,[bp-0x8]
    3b7d:	16                   	push   ss
    3b7e:	57                   	push   di
    3b7f:	6a 00                	push   0x0
    3b81:	9a 0a 12 b3 3c       	call   0x3cb3:0x120a
    3b86:	e9 2c 01             	jmp    0x3cb5
    3b89:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b8c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b92:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    3b96:	81 c7 01 00          	add    di,0x1
    3b9a:	06                   	push   es
    3b9b:	57                   	push   di
    3b9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b9f:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    3ba3:	26 8a 05             	mov    al,BYTE PTR es:[di]
    3ba6:	30 e4                	xor    ah,ah
    3ba8:	50                   	push   ax
    3ba9:	9a ba 0c 27 3d       	call   0x3d27:0xcba
    3bae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bb1:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    3bb5:	26 8a 05             	mov    al,BYTE PTR es:[di]
    3bb8:	30 e4                	xor    ah,ah
    3bba:	8b c8                	mov    cx,ax
    3bbc:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3bbf:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3bc2:	03 c1                	add    ax,cx
    3bc4:	89 c7                	mov    di,ax
    3bc6:	8e c2                	mov    es,dx
    3bc8:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    3bcc:	e9 e6 00             	jmp    0x3cb5
    3bcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bd2:	06                   	push   es
    3bd3:	57                   	push   di
    3bd4:	9a 40 48 ea 3b       	call   0x3bea:0x4840
    3bd9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3bdc:	26 89 05             	mov    WORD PTR es:[di],ax
    3bdf:	e9 d3 00             	jmp    0x3cb5
    3be2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3be5:	06                   	push   es
    3be6:	57                   	push   di
    3be7:	9a 40 48 fd 3b       	call   0x3bfd:0x4840
    3bec:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3bef:	26 89 05             	mov    WORD PTR es:[di],ax
    3bf2:	e9 c0 00             	jmp    0x3cb5
    3bf5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bf8:	06                   	push   es
    3bf9:	57                   	push   di
    3bfa:	9a 40 48 14 3c       	call   0x3c14:0x4840
    3bff:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c02:	26 89 05             	mov    WORD PTR es:[di],ax
    3c05:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    3c09:	e9 a9 00             	jmp    0x3cb5
    3c0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c0f:	06                   	push   es
    3c10:	57                   	push   di
    3c11:	9a d4 4b 3b 3c       	call   0x3c3b:0x4bd4
    3c16:	9a 57 10 24 3c       	call   0x3c24:0x1057
    3c1b:	9b 2e d8 0e 2a 3b    	fmul   DWORD PTR cs:0x3b2a
    3c21:	9a 2f 10 40 3c       	call   0x3c40:0x102f
    3c26:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c29:	26 89 05             	mov    WORD PTR es:[di],ax
    3c2c:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    3c30:	e9 82 00             	jmp    0x3cb5
    3c33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c36:	06                   	push   es
    3c37:	57                   	push   di
    3c38:	9a d4 4b 56 3c       	call   0x3c56:0x4bd4
    3c3d:	9a 0e 10 89 3d       	call   0x3d89:0x100e
    3c42:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c45:	26 89 05             	mov    WORD PTR es:[di],ax
    3c48:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    3c4c:	eb 67                	jmp    0x3cb5
    3c4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c51:	06                   	push   es
    3c52:	57                   	push   di
    3c53:	9a d4 4b 71 3c       	call   0x3c71:0x4bd4
    3c58:	9b 2e d8 0e 2a 3b    	fmul   DWORD PTR cs:0x3b2a
    3c5e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c61:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    3c65:	90                   	nop
    3c66:	9b                   	fwait
    3c67:	eb 4c                	jmp    0x3cb5
    3c69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c6c:	06                   	push   es
    3c6d:	57                   	push   di
    3c6e:	9a bc 46 86 3c       	call   0x3c86:0x46bc
    3c73:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c76:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    3c7a:	90                   	nop
    3c7b:	9b                   	fwait
    3c7c:	eb 37                	jmp    0x3cb5
    3c7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c81:	06                   	push   es
    3c82:	57                   	push   di
    3c83:	9a 3c 44 31 3d       	call   0x3d31:0x443c
    3c88:	98                   	cbw
    3c89:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c8c:	26 89 05             	mov    WORD PTR es:[di],ax
    3c8f:	eb 24                	jmp    0x3cb5
    3c91:	68 1c f2             	push   0xf21c
    3c94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c97:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    3c9b:	89 f8                	mov    ax,di
    3c9d:	8c c2                	mov    dx,es
    3c9f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3ca2:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3ca5:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    3ca9:	8d 7e f8             	lea    di,[bp-0x8]
    3cac:	16                   	push   ss
    3cad:	57                   	push   di
    3cae:	6a 00                	push   0x0
    3cb0:	9a 0a 12 13 3d       	call   0x3d13:0x120a
    3cb5:	c9                   	leave
    3cb6:	ca 08 00             	retf   0x8
    3cb9:	80 cb a4             	or     bl,0xa4
    3cbc:	4c                   	dec    sp
    3cbd:	f1                   	int1
    3cbe:	3c 18                	cmp    al,0x18
    3cc0:	3d 4c 3d             	cmp    ax,0x3d4c
    3cc3:	62 3d                	bound  di,DWORD PTR [di]
    3cc5:	36 3d 46 3e          	ss cmp ax,0x3e46
    3cc9:	28 3e 0a 3e          	sub    BYTE PTR ds:0x3e0a,bh
    3ccd:	ec                   	in     al,dx
    3cce:	3d a3 3d             	cmp    ax,0x3da3
    3cd1:	79 3d                	jns    0x3d10
    3cd3:	c2 3d c8             	ret    0xc83d
    3cd6:	00 01                	add    BYTE PTR [bx+di],al
    3cd8:	00 c4                	add    ah,al
    3cda:	7e 06                	jle    0x3ce2
    3cdc:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    3ce0:	3c 0b                	cmp    al,0xb
    3ce2:	76 03                	jbe    0x3ce7
    3ce4:	e9 78 01             	jmp    0x3e5f
    3ce7:	98                   	cbw
    3ce8:	89 c3                	mov    bx,ax
    3cea:	d1 e3                	shl    bx,1
    3cec:	2e ff a7 bd 3c       	jmp    WORD PTR cs:[bx+0x3cbd]
    3cf1:	68 1b f2             	push   0xf21b
    3cf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cf7:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    3cfb:	89 f8                	mov    ax,di
    3cfd:	8c c2                	mov    dx,es
    3cff:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3d02:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3d05:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    3d09:	8d 7e f8             	lea    di,[bp-0x8]
    3d0c:	16                   	push   ss
    3d0d:	57                   	push   di
    3d0e:	6a 00                	push   0x0
    3d10:	9a 0a 12 81 3e       	call   0x3e81:0x120a
    3d15:	e9 6b 01             	jmp    0x3e83
    3d18:	8d be 00 ff          	lea    di,[bp-0x100]
    3d1c:	16                   	push   ss
    3d1d:	57                   	push   di
    3d1e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3d21:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3d24:	9a 6e 0e ff 42       	call   0x42ff:0xe6e
    3d29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d2c:	06                   	push   es
    3d2d:	57                   	push   di
    3d2e:	9a 40 49 47 3d       	call   0x3d47:0x4940
    3d33:	e9 4d 01             	jmp    0x3e83
    3d36:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3d39:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3d3c:	99                   	cwd
    3d3d:	52                   	push   dx
    3d3e:	50                   	push   ax
    3d3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d42:	06                   	push   es
    3d43:	57                   	push   di
    3d44:	9a ec 47 5d 3d       	call   0x3d5d:0x47ec
    3d49:	e9 37 01             	jmp    0x3e83
    3d4c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3d4f:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3d52:	99                   	cwd
    3d53:	52                   	push   dx
    3d54:	50                   	push   ax
    3d55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d58:	06                   	push   es
    3d59:	57                   	push   di
    3d5a:	9a 0b 48 74 3d       	call   0x3d74:0x480b
    3d5f:	e9 21 01             	jmp    0x3e83
    3d62:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3d65:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3d69:	26 ff 35             	push   WORD PTR es:[di]
    3d6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d6f:	06                   	push   es
    3d70:	57                   	push   di
    3d71:	9a be 47 9e 3d       	call   0x3d9e:0x47be
    3d76:	e9 0a 01             	jmp    0x3e83
    3d79:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3d7c:	9b 26 db 05          	fild   DWORD PTR es:[di]
    3d80:	9b 2e d9 06 b9 3c    	fld    DWORD PTR cs:0x3cb9
    3d86:	9a b2 04 d2 3d       	call   0x3dd2:0x4b2
    3d8b:	83 ec 08             	sub    sp,0x8
    3d8e:	89 e3                	mov    bx,sp
    3d90:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3d94:	90                   	nop
    3d95:	9b                   	fwait
    3d96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d99:	06                   	push   es
    3d9a:	57                   	push   di
    3d9b:	9a 95 4b bd 3d       	call   0x3dbd:0x4b95
    3da0:	e9 e0 00             	jmp    0x3e83
    3da3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3da6:	9b 26 db 05          	fild   DWORD PTR es:[di]
    3daa:	83 ec 08             	sub    sp,0x8
    3dad:	89 e3                	mov    bx,sp
    3daf:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3db3:	90                   	nop
    3db4:	9b                   	fwait
    3db5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3db8:	06                   	push   es
    3db9:	57                   	push   di
    3dba:	9a 95 4b e7 3d       	call   0x3de7:0x4b95
    3dbf:	e9 c1 00             	jmp    0x3e83
    3dc2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3dc5:	9b 26 dd 05          	fld    QWORD PTR es:[di]
    3dc9:	9b 2e d9 06 b9 3c    	fld    DWORD PTR cs:0x3cb9
    3dcf:	9a b2 04 63 43       	call   0x4363:0x4b2
    3dd4:	83 ec 08             	sub    sp,0x8
    3dd7:	89 e3                	mov    bx,sp
    3dd9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3ddd:	90                   	nop
    3dde:	9b                   	fwait
    3ddf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3de2:	06                   	push   es
    3de3:	57                   	push   di
    3de4:	9a 95 4b 06 3e       	call   0x3e06:0x4b95
    3de9:	e9 97 00             	jmp    0x3e83
    3dec:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3def:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3df3:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    3df7:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3dfb:	26 ff 35             	push   WORD PTR es:[di]
    3dfe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e01:	06                   	push   es
    3e02:	57                   	push   di
    3e03:	9a 7d 46 24 3e       	call   0x3e24:0x467d
    3e08:	eb 79                	jmp    0x3e83
    3e0a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e0d:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3e11:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    3e15:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3e19:	26 ff 35             	push   WORD PTR es:[di]
    3e1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e1f:	06                   	push   es
    3e20:	57                   	push   di
    3e21:	9a 58 46 42 3e       	call   0x3e42:0x4658
    3e26:	eb 5b                	jmp    0x3e83
    3e28:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e2b:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    3e2f:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    3e33:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    3e37:	26 ff 35             	push   WORD PTR es:[di]
    3e3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e3d:	06                   	push   es
    3e3e:	57                   	push   di
    3e3f:	9a 2d 46 5b 3e       	call   0x3e5b:0x462d
    3e44:	eb 3d                	jmp    0x3e83
    3e46:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3e49:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3e4c:	f7 d8                	neg    ax
    3e4e:	18 c0                	sbb    al,al
    3e50:	f6 d8                	neg    al
    3e52:	50                   	push   ax
    3e53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e56:	06                   	push   es
    3e57:	57                   	push   di
    3e58:	9a 19 43 bc 3e       	call   0x3ebc:0x4319
    3e5d:	eb 24                	jmp    0x3e83
    3e5f:	68 1c f2             	push   0xf21c
    3e62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e65:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    3e69:	89 f8                	mov    ax,di
    3e6b:	8c c2                	mov    dx,es
    3e6d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3e70:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3e73:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    3e77:	8d 7e f8             	lea    di,[bp-0x8]
    3e7a:	16                   	push   ss
    3e7b:	57                   	push   di
    3e7c:	6a 00                	push   0x0
    3e7e:	9a 0a 12 ae 40       	call   0x40ae:0x120a
    3e83:	c9                   	leave
    3e84:	ca 08 00             	retf   0x8
    3e87:	ef                   	out    dx,ax
    3e88:	3e ee                	ds out dx,al
    3e8a:	3f                   	aas
    3e8b:	1e                   	push   ds
    3e8c:	40                   	inc    ax
    3e8d:	06                   	push   es
    3e8e:	40                   	inc    ax
    3e8f:	0c 3f                	or     al,0x3f
    3e91:	cd 3f                	int    0x3f
    3e93:	8a 3f                	mov    bh,BYTE PTR [bx]
    3e95:	ac                   	lods   al,BYTE PTR ds:[si]
    3e96:	3f                   	aas
    3e97:	46                   	inc    si
    3e98:	3f                   	aas
    3e99:	24 3f                	and    al,0x3f
    3e9b:	68 3f c8             	push   0xc83f
    3e9e:	00 01                	add    BYTE PTR [bx+di],al
    3ea0:	00 8b 46 0a          	add    BYTE PTR [bp+di+0xa46],cl
    3ea4:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3ea7:	75 03                	jne    0x3eac
    3ea9:	e9 c8 01             	jmp    0x4074
    3eac:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3eaf:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    3eb3:	50                   	push   ax
    3eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3eb7:	06                   	push   es
    3eb8:	57                   	push   di
    3eb9:	9a 0b 3a d0 3e       	call   0x3ed0:0x3a0b
    3ebe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3ec1:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    3ec6:	74 0d                	je     0x3ed5
    3ec8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ecb:	06                   	push   es
    3ecc:	57                   	push   di
    3ecd:	9a d9 42 fd 3e       	call   0x3efd:0x42d9
    3ed2:	e9 5f 01             	jmp    0x4034
    3ed5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ed8:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    3edc:	2c 01                	sub    al,0x1
    3ede:	3c 0a                	cmp    al,0xa
    3ee0:	76 03                	jbe    0x3ee5
    3ee2:	e9 4f 01             	jmp    0x4034
    3ee5:	98                   	cbw
    3ee6:	89 c3                	mov    bx,ax
    3ee8:	d1 e3                	shl    bx,1
    3eea:	2e ff a7 87 3e       	jmp    WORD PTR cs:[bx+0x3e87]
    3eef:	8d be 00 ff          	lea    di,[bp-0x100]
    3ef3:	16                   	push   ss
    3ef4:	57                   	push   di
    3ef5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3ef8:	06                   	push   es
    3ef9:	57                   	push   di
    3efa:	9a 88 49 07 3f       	call   0x3f07:0x4988
    3eff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f02:	06                   	push   es
    3f03:	57                   	push   di
    3f04:	9a 40 49 14 3f       	call   0x3f14:0x4940
    3f09:	e9 28 01             	jmp    0x4034
    3f0c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f0f:	06                   	push   es
    3f10:	57                   	push   di
    3f11:	9a 3c 44 1f 3f       	call   0x3f1f:0x443c
    3f16:	50                   	push   ax
    3f17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f1a:	06                   	push   es
    3f1b:	57                   	push   di
    3f1c:	9a 19 43 2c 3f       	call   0x3f2c:0x4319
    3f21:	e9 10 01             	jmp    0x4034
    3f24:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f27:	06                   	push   es
    3f28:	57                   	push   di
    3f29:	9a d4 4b 41 3f       	call   0x3f41:0x4bd4
    3f2e:	83 ec 08             	sub    sp,0x8
    3f31:	89 e3                	mov    bx,sp
    3f33:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f37:	90                   	nop
    3f38:	9b                   	fwait
    3f39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f3c:	06                   	push   es
    3f3d:	57                   	push   di
    3f3e:	9a 70 4b 4e 3f       	call   0x3f4e:0x4b70
    3f43:	e9 ee 00             	jmp    0x4034
    3f46:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f49:	06                   	push   es
    3f4a:	57                   	push   di
    3f4b:	9a d4 4b 63 3f       	call   0x3f63:0x4bd4
    3f50:	83 ec 08             	sub    sp,0x8
    3f53:	89 e3                	mov    bx,sp
    3f55:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f59:	90                   	nop
    3f5a:	9b                   	fwait
    3f5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f5e:	06                   	push   es
    3f5f:	57                   	push   di
    3f60:	9a 45 4b 70 3f       	call   0x3f70:0x4b45
    3f65:	e9 cc 00             	jmp    0x4034
    3f68:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f6b:	06                   	push   es
    3f6c:	57                   	push   di
    3f6d:	9a d4 4b 85 3f       	call   0x3f85:0x4bd4
    3f72:	83 ec 08             	sub    sp,0x8
    3f75:	89 e3                	mov    bx,sp
    3f77:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f7b:	90                   	nop
    3f7c:	9b                   	fwait
    3f7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f80:	06                   	push   es
    3f81:	57                   	push   di
    3f82:	9a 95 4b 92 3f       	call   0x3f92:0x4b95
    3f87:	e9 aa 00             	jmp    0x4034
    3f8a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f8d:	06                   	push   es
    3f8e:	57                   	push   di
    3f8f:	9a bc 46 a7 3f       	call   0x3fa7:0x46bc
    3f94:	83 ec 08             	sub    sp,0x8
    3f97:	89 e3                	mov    bx,sp
    3f99:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f9d:	90                   	nop
    3f9e:	9b                   	fwait
    3f9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fa2:	06                   	push   es
    3fa3:	57                   	push   di
    3fa4:	9a 58 46 b4 3f       	call   0x3fb4:0x4658
    3fa9:	e9 88 00             	jmp    0x4034
    3fac:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3faf:	06                   	push   es
    3fb0:	57                   	push   di
    3fb1:	9a bc 46 c9 3f       	call   0x3fc9:0x46bc
    3fb6:	83 ec 08             	sub    sp,0x8
    3fb9:	89 e3                	mov    bx,sp
    3fbb:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3fbf:	90                   	nop
    3fc0:	9b                   	fwait
    3fc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fc4:	06                   	push   es
    3fc5:	57                   	push   di
    3fc6:	9a 7d 46 d5 3f       	call   0x3fd5:0x467d
    3fcb:	eb 67                	jmp    0x4034
    3fcd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3fd0:	06                   	push   es
    3fd1:	57                   	push   di
    3fd2:	9a bc 46 ea 3f       	call   0x3fea:0x46bc
    3fd7:	83 ec 08             	sub    sp,0x8
    3fda:	89 e3                	mov    bx,sp
    3fdc:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3fe0:	90                   	nop
    3fe1:	9b                   	fwait
    3fe2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fe5:	06                   	push   es
    3fe6:	57                   	push   di
    3fe7:	9a 2d 46 f6 3f       	call   0x3ff6:0x462d
    3fec:	eb 46                	jmp    0x4034
    3fee:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3ff1:	06                   	push   es
    3ff2:	57                   	push   di
    3ff3:	9a 40 48 02 40       	call   0x4002:0x4840
    3ff8:	52                   	push   dx
    3ff9:	50                   	push   ax
    3ffa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ffd:	06                   	push   es
    3ffe:	57                   	push   di
    3fff:	9a 0b 48 0e 40       	call   0x400e:0x480b
    4004:	eb 2e                	jmp    0x4034
    4006:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4009:	06                   	push   es
    400a:	57                   	push   di
    400b:	9a 40 48 1a 40       	call   0x401a:0x4840
    4010:	52                   	push   dx
    4011:	50                   	push   ax
    4012:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4015:	06                   	push   es
    4016:	57                   	push   di
    4017:	9a ec 47 26 40       	call   0x4026:0x47ec
    401c:	eb 16                	jmp    0x4034
    401e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4021:	06                   	push   es
    4022:	57                   	push   di
    4023:	9a 40 48 32 40       	call   0x4032:0x4840
    4028:	52                   	push   dx
    4029:	50                   	push   ax
    402a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    402d:	06                   	push   es
    402e:	57                   	push   di
    402f:	9a be 47 50 40       	call   0x4050:0x47be
    4034:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4037:	26 8a 45 1a          	mov    al,BYTE PTR es:[di+0x1a]
    403b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    403e:	26 88 45 1a          	mov    BYTE PTR es:[di+0x1a],al
    4042:	8d be 00 ff          	lea    di,[bp-0x100]
    4046:	16                   	push   ss
    4047:	57                   	push   di
    4048:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    404b:	06                   	push   es
    404c:	57                   	push   di
    404d:	9a 56 3a 5a 40       	call   0x405a:0x3a56
    4052:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4055:	06                   	push   es
    4056:	57                   	push   di
    4057:	9a 3c 3a a4 40       	call   0x40a4:0x3a3c
    405c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    405f:	26 80 7d 1b 00       	cmp    BYTE PTR es:[di+0x1b],0x0
    4064:	75 0e                	jne    0x4074
    4066:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4069:	26 8a 45 1b          	mov    al,BYTE PTR es:[di+0x1b]
    406d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4070:	26 88 45 1b          	mov    BYTE PTR es:[di+0x1b],al
    4074:	c9                   	leave
    4075:	ca 08 00             	retf   0x8
    4078:	d9 40 00             	fld    DWORD PTR [bx+si+0x0]
    407b:	41                   	inc    cx
    407c:	1f                   	pop    ds
    407d:	41                   	inc    cx
    407e:	55                   	push   bp
    407f:	41                   	inc    cx
    4080:	3a 41 46             	cmp    al,BYTE PTR [bx+di+0x46]
    4083:	42                   	inc    dx
    4084:	23 42 00             	and    ax,WORD PTR [bp+si+0x0]
    4087:	42                   	inc    dx
    4088:	dc 41 94             	fadd   QWORD PTR [bx+di-0x6c]
    408b:	41                   	inc    cx
    408c:	70 41                	jo     0x40cf
    408e:	b8 41 c8             	mov    ax,0xc841
    4091:	00 01                	add    BYTE PTR [bx+di],al
    4093:	00 c4                	add    ah,al
    4095:	7e 0a                	jle    0x40a1
    4097:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    409b:	50                   	push   ax
    409c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    409f:	06                   	push   es
    40a0:	57                   	push   di
    40a1:	9a 0b 3a bc 40       	call   0x40bc:0x3a0b
    40a6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    40a9:	06                   	push   es
    40aa:	57                   	push   di
    40ab:	9a db 69 fb 40       	call   0x40fb:0x69db
    40b0:	08 c0                	or     al,al
    40b2:	74 0d                	je     0x40c1
    40b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40b7:	06                   	push   es
    40b8:	57                   	push   di
    40b9:	9a d9 42 1a 41       	call   0x411a:0x42d9
    40be:	e9 c2 01             	jmp    0x4283
    40c1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    40c4:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    40c8:	3c 0b                	cmp    al,0xb
    40ca:	76 03                	jbe    0x40cf
    40cc:	e9 90 01             	jmp    0x425f
    40cf:	98                   	cbw
    40d0:	89 c3                	mov    bx,ax
    40d2:	d1 e3                	shl    bx,1
    40d4:	2e ff a7 78 40       	jmp    WORD PTR cs:[bx+0x4078]
    40d9:	68 1b f2             	push   0xf21b
    40dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40df:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    40e3:	89 f8                	mov    ax,di
    40e5:	8c c2                	mov    dx,es
    40e7:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    40ea:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    40ed:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    40f1:	8d 7e f8             	lea    di,[bp-0x8]
    40f4:	16                   	push   ss
    40f5:	57                   	push   di
    40f6:	6a 00                	push   0x0
    40f8:	9a 0a 12 81 42       	call   0x4281:0x120a
    40fd:	e9 83 01             	jmp    0x4283
    4100:	8d be 00 ff          	lea    di,[bp-0x100]
    4104:	16                   	push   ss
    4105:	57                   	push   di
    4106:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4109:	06                   	push   es
    410a:	57                   	push   di
    410b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    410e:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    4112:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4115:	06                   	push   es
    4116:	57                   	push   di
    4117:	9a 40 49 35 41       	call   0x4135:0x4940
    411c:	e9 64 01             	jmp    0x4283
    411f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4122:	06                   	push   es
    4123:	57                   	push   di
    4124:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4127:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    412b:	52                   	push   dx
    412c:	50                   	push   ax
    412d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4130:	06                   	push   es
    4131:	57                   	push   di
    4132:	9a 0b 48 50 41       	call   0x4150:0x480b
    4137:	e9 49 01             	jmp    0x4283
    413a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    413d:	06                   	push   es
    413e:	57                   	push   di
    413f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4142:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4146:	52                   	push   dx
    4147:	50                   	push   ax
    4148:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    414b:	06                   	push   es
    414c:	57                   	push   di
    414d:	9a ec 47 6b 41       	call   0x416b:0x47ec
    4152:	e9 2e 01             	jmp    0x4283
    4155:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4158:	06                   	push   es
    4159:	57                   	push   di
    415a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    415d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4161:	52                   	push   dx
    4162:	50                   	push   ax
    4163:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4166:	06                   	push   es
    4167:	57                   	push   di
    4168:	9a be 47 8f 41       	call   0x418f:0x47be
    416d:	e9 13 01             	jmp    0x4283
    4170:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4173:	06                   	push   es
    4174:	57                   	push   di
    4175:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4178:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    417c:	83 ec 08             	sub    sp,0x8
    417f:	89 e3                	mov    bx,sp
    4181:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4185:	90                   	nop
    4186:	9b                   	fwait
    4187:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    418a:	06                   	push   es
    418b:	57                   	push   di
    418c:	9a 70 4b b3 41       	call   0x41b3:0x4b70
    4191:	e9 ef 00             	jmp    0x4283
    4194:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4197:	06                   	push   es
    4198:	57                   	push   di
    4199:	26 c4 3d             	les    di,DWORD PTR es:[di]
    419c:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    41a0:	83 ec 08             	sub    sp,0x8
    41a3:	89 e3                	mov    bx,sp
    41a5:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    41a9:	90                   	nop
    41aa:	9b                   	fwait
    41ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41ae:	06                   	push   es
    41af:	57                   	push   di
    41b0:	9a 45 4b d7 41       	call   0x41d7:0x4b45
    41b5:	e9 cb 00             	jmp    0x4283
    41b8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    41bb:	06                   	push   es
    41bc:	57                   	push   di
    41bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41c0:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    41c4:	83 ec 08             	sub    sp,0x8
    41c7:	89 e3                	mov    bx,sp
    41c9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    41cd:	90                   	nop
    41ce:	9b                   	fwait
    41cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41d2:	06                   	push   es
    41d3:	57                   	push   di
    41d4:	9a 95 4b fb 41       	call   0x41fb:0x4b95
    41d9:	e9 a7 00             	jmp    0x4283
    41dc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    41df:	06                   	push   es
    41e0:	57                   	push   di
    41e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41e4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    41e8:	83 ec 08             	sub    sp,0x8
    41eb:	89 e3                	mov    bx,sp
    41ed:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    41f1:	90                   	nop
    41f2:	9b                   	fwait
    41f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41f6:	06                   	push   es
    41f7:	57                   	push   di
    41f8:	9a 7d 46 1f 42       	call   0x421f:0x467d
    41fd:	e9 83 00             	jmp    0x4283
    4200:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4203:	06                   	push   es
    4204:	57                   	push   di
    4205:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4208:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    420c:	83 ec 08             	sub    sp,0x8
    420f:	89 e3                	mov    bx,sp
    4211:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4215:	90                   	nop
    4216:	9b                   	fwait
    4217:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    421a:	06                   	push   es
    421b:	57                   	push   di
    421c:	9a 58 46 42 42       	call   0x4242:0x4658
    4221:	eb 60                	jmp    0x4283
    4223:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4226:	06                   	push   es
    4227:	57                   	push   di
    4228:	26 c4 3d             	les    di,DWORD PTR es:[di]
    422b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    422f:	83 ec 08             	sub    sp,0x8
    4232:	89 e3                	mov    bx,sp
    4234:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4238:	90                   	nop
    4239:	9b                   	fwait
    423a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    423d:	06                   	push   es
    423e:	57                   	push   di
    423f:	9a 2d 46 5b 42       	call   0x425b:0x462d
    4244:	eb 3d                	jmp    0x4283
    4246:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4249:	06                   	push   es
    424a:	57                   	push   di
    424b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    424e:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    4252:	50                   	push   ax
    4253:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4256:	06                   	push   es
    4257:	57                   	push   di
    4258:	9a 19 43 a3 42       	call   0x42a3:0x4319
    425d:	eb 24                	jmp    0x4283
    425f:	68 1c f2             	push   0xf21c
    4262:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4265:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4269:	89 f8                	mov    ax,di
    426b:	8c c2                	mov    dx,es
    426d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4270:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    4273:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    4277:	8d 7e f8             	lea    di,[bp-0x8]
    427a:	16                   	push   ss
    427b:	57                   	push   di
    427c:	6a 00                	push   0x0
    427e:	9a 0a 12 99 42       	call   0x4299:0x120a
    4283:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4286:	26 c6 45 1a 01       	mov    BYTE PTR es:[di+0x1a],0x1
    428b:	8d be 00 ff          	lea    di,[bp-0x100]
    428f:	16                   	push   ss
    4290:	57                   	push   di
    4291:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4294:	06                   	push   es
    4295:	57                   	push   di
    4296:	9a 1f 69 cf 42       	call   0x42cf:0x691f
    429b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    429e:	06                   	push   es
    429f:	57                   	push   di
    42a0:	9a 3c 3a 24 43       	call   0x4324:0x3a3c
    42a5:	c9                   	leave
    42a6:	ca 08 00             	retf   0x8
    42a9:	c8 08 00 00          	enter  0x8,0x0
    42ad:	68 2d f2             	push   0xf22d
    42b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42b3:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    42b7:	89 f8                	mov    ax,di
    42b9:	8c c2                	mov    dx,es
    42bb:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    42be:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    42c1:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    42c5:	8d 7e f8             	lea    di,[bp-0x8]
    42c8:	16                   	push   ss
    42c9:	57                   	push   di
    42ca:	6a 00                	push   0x0
    42cc:	9a 0a 12 a9 43       	call   0x43a9:0x120a
    42d1:	c9                   	leave
    42d2:	ca 04 00             	retf   0x4
    42d5:	00 00                	add    BYTE PTR [bx+si],al
    42d7:	00 00                	add    BYTE PTR [bx+si],al
    42d9:	55                   	push   bp
    42da:	89 e5                	mov    bp,sp
    42dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42df:	26 c6 45 19 01       	mov    BYTE PTR es:[di+0x19],0x1
    42e4:	9b 2e d9 06 d5 42    	fld    DWORD PTR cs:0x42d5
    42ea:	9b 26 dd 5d 08       	fstp   QWORD PTR es:[di+0x8]
    42ef:	90                   	nop
    42f0:	9b                   	fwait
    42f1:	81 c7 14 00          	add    di,0x14
    42f5:	06                   	push   es
    42f6:	57                   	push   di
    42f7:	bf d5 42             	mov    di,0x42d5
    42fa:	0e                   	push   cs
    42fb:	57                   	push   di
    42fc:	9a 51 06 0a 45       	call   0x450a:0x651
    4301:	c9                   	leave
    4302:	ca 04 00             	retf   0x4
    4305:	55                   	push   bp
    4306:	89 e5                	mov    bp,sp
    4308:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    430b:	26 c6 45 1a 01       	mov    BYTE PTR es:[di+0x1a],0x1
    4310:	26 c6 45 19 00       	mov    BYTE PTR es:[di+0x19],0x0
    4315:	c9                   	leave
    4316:	ca 04 00             	retf   0x4
    4319:	55                   	push   bp
    431a:	89 e5                	mov    bp,sp
    431c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    431f:	06                   	push   es
    4320:	57                   	push   di
    4321:	9a 05 43 30 43       	call   0x4330:0x4305
    4326:	6a 05                	push   0x5
    4328:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    432b:	06                   	push   es
    432c:	57                   	push   di
    432d:	9a 0b 3a 86 43       	call   0x4386:0x3a0b
    4332:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    4335:	98                   	cbw
    4336:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4339:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    433d:	c9                   	leave
    433e:	ca 06 00             	retf   0x6
    4341:	c8 0c 01 00          	enter  0x10c,0x0
    4345:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4348:	06                   	push   es
    4349:	57                   	push   di
    434a:	e8 95 d3             	call   0x16e2
    434d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    4350:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    4354:	74 55                	je     0x43ab
    4356:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4359:	06                   	push   es
    435a:	57                   	push   di
    435b:	8d 7e fc             	lea    di,[bp-0x4]
    435e:	16                   	push   ss
    435f:	57                   	push   di
    4360:	9a fb 1d d4 43       	call   0x43d4:0x1dfb
    4365:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4368:	26 89 05             	mov    WORD PTR es:[di],ax
    436b:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    436f:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    4373:	74 36                	je     0x43ab
    4375:	68 0d f2             	push   0xf20d
    4378:	8d be fc fe          	lea    di,[bp-0x104]
    437c:	16                   	push   ss
    437d:	57                   	push   di
    437e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4381:	06                   	push   es
    4382:	57                   	push   di
    4383:	9a 56 3a f6 43       	call   0x43f6:0x3a56
    4388:	83 c4 04             	add    sp,0x4
    438b:	8d 86 fc fe          	lea    ax,[bp-0x104]
    438f:	8c d2                	mov    dx,ss
    4391:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    4395:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    4399:	c6 86 f8 fe 04       	mov    BYTE PTR [bp-0x108],0x4
    439e:	8d be f4 fe          	lea    di,[bp-0x10c]
    43a2:	16                   	push   ss
    43a3:	57                   	push   di
    43a4:	6a 00                	push   0x0
    43a6:	9a 0a 12 19 44       	call   0x4419:0x120a
    43ab:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    43ae:	c9                   	leave
    43af:	ca 0c 00             	retf   0xc
    43b2:	c8 0c 01 00          	enter  0x10c,0x0
    43b6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    43b9:	06                   	push   es
    43ba:	57                   	push   di
    43bb:	e8 a9 d2             	call   0x1667
    43be:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    43c1:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    43c5:	74 54                	je     0x441b
    43c7:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    43ca:	06                   	push   es
    43cb:	57                   	push   di
    43cc:	8d 7e fc             	lea    di,[bp-0x4]
    43cf:	16                   	push   ss
    43d0:	57                   	push   di
    43d1:	9a 86 1e 14 45       	call   0x4514:0x1e86
    43d6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    43d9:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    43dd:	90                   	nop
    43de:	9b                   	fwait
    43df:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    43e3:	74 36                	je     0x441b
    43e5:	68 0c f2             	push   0xf20c
    43e8:	8d be fc fe          	lea    di,[bp-0x104]
    43ec:	16                   	push   ss
    43ed:	57                   	push   di
    43ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43f1:	06                   	push   es
    43f2:	57                   	push   di
    43f3:	9a 56 3a 9d 44       	call   0x449d:0x3a56
    43f8:	83 c4 04             	add    sp,0x4
    43fb:	8d 86 fc fe          	lea    ax,[bp-0x104]
    43ff:	8c d2                	mov    dx,ss
    4401:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    4405:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    4409:	c6 86 f8 fe 04       	mov    BYTE PTR [bp-0x108],0x4
    440e:	8d be f4 fe          	lea    di,[bp-0x10c]
    4412:	16                   	push   ss
    4413:	57                   	push   di
    4414:	6a 00                	push   0x0
    4416:	9a 0a 12 a8 45       	call   0x45a8:0x120a
    441b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    441e:	c9                   	leave
    441f:	ca 0c 00             	retf   0xc
    4422:	00 00                	add    BYTE PTR [bx+si],al
    4424:	00 00                	add    BYTE PTR [bx+si],al
    4426:	6b 44 ac 45          	imul   ax,WORD PTR [si-0x54],0x45
    442a:	ac                   	lods   al,BYTE PTR ds:[si]
    442b:	45                   	inc    bp
    442c:	ac                   	lods   al,BYTE PTR ds:[si]
    442d:	45                   	inc    bp
    442e:	0a 46 e6             	or     al,BYTE PTR [bp-0x1a]
    4431:	45                   	inc    bp
    4432:	e6 45                	out    0x45,al
    4434:	e6 45                	out    0x45,al
    4436:	c2 45 c2             	ret    0xc245
    4439:	45                   	inc    bp
    443a:	c2 45 c8             	ret    0xc845
    443d:	20 05                	and    BYTE PTR [di],al
    443f:	00 c4                	add    ah,al
    4441:	7e 06                	jle    0x4449
    4443:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    4448:	74 07                	je     0x4451
    444a:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    444e:	e9 d5 01             	jmp    0x4626
    4451:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4454:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    4458:	2c 01                	sub    al,0x1
    445a:	3c 0a                	cmp    al,0xa
    445c:	76 03                	jbe    0x4461
    445e:	e9 bb 01             	jmp    0x461c
    4461:	98                   	cbw
    4462:	89 c3                	mov    bx,ax
    4464:	d1 e3                	shl    bx,1
    4466:	2e ff a7 26 44       	jmp    WORD PTR cs:[bx+0x4426]
    446b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    446e:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4472:	26 8a 05             	mov    al,BYTE PTR es:[di]
    4475:	30 e4                	xor    ah,ah
    4477:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    447a:	83 7e f0 00          	cmp    WORD PTR [bp-0x10],0x0
    447e:	75 07                	jne    0x4487
    4480:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    4484:	e9 23 01             	jmp    0x45aa
    4487:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    448a:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    448e:	06                   	push   es
    448f:	57                   	push   di
    4490:	8d 7e f2             	lea    di,[bp-0xe]
    4493:	16                   	push   ss
    4494:	57                   	push   di
    4495:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4498:	06                   	push   es
    4499:	57                   	push   di
    449a:	9a 41 43 ca 44       	call   0x44ca:0x4341
    449f:	08 c0                	or     al,al
    44a1:	74 11                	je     0x44b4
    44a3:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    44a6:	0b 46 f4             	or     ax,WORD PTR [bp-0xc]
    44a9:	b0 00                	mov    al,0x0
    44ab:	74 01                	je     0x44ae
    44ad:	40                   	inc    ax
    44ae:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    44b1:	e9 f6 00             	jmp    0x45aa
    44b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44b7:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    44bb:	06                   	push   es
    44bc:	57                   	push   di
    44bd:	8d 7e f6             	lea    di,[bp-0xa]
    44c0:	16                   	push   ss
    44c1:	57                   	push   di
    44c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44c5:	06                   	push   es
    44c6:	57                   	push   di
    44c7:	9a b2 43 85 45       	call   0x4585:0x43b2
    44cc:	08 c0                	or     al,al
    44ce:	74 1f                	je     0x44ef
    44d0:	9b dd 46 f6          	fld    QWORD PTR [bp-0xa]
    44d4:	9b 2e d8 1e 22 44    	fcomp  DWORD PTR cs:0x4422
    44da:	9b dd 7e ee          	fstsw  WORD PTR [bp-0x12]
    44de:	90                   	nop
    44df:	9b                   	fwait
    44e0:	8a 66 ef             	mov    ah,BYTE PTR [bp-0x11]
    44e3:	9e                   	sahf
    44e4:	b0 00                	mov    al,0x0
    44e6:	74 01                	je     0x44e9
    44e8:	40                   	inc    ax
    44e9:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    44ec:	e9 bb 00             	jmp    0x45aa
    44ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44f2:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    44f6:	06                   	push   es
    44f7:	57                   	push   di
    44f8:	8d be f0 fd          	lea    di,[bp-0x210]
    44fc:	16                   	push   ss
    44fd:	57                   	push   di
    44fe:	8d be f0 fe          	lea    di,[bp-0x110]
    4502:	16                   	push   ss
    4503:	57                   	push   di
    4504:	68 26 f2             	push   0xf226
    4507:	9a 2b 09 19 45       	call   0x4519:0x92b
    450c:	6a 01                	push   0x1
    450e:	ff 76 f0             	push   WORD PTR [bp-0x10]
    4511:	9a 0b 18 4b 45       	call   0x454b:0x180b
    4516:	9a ed 07 41 45       	call   0x4541:0x7ed
    451b:	09 c0                	or     ax,ax
    451d:	75 07                	jne    0x4526
    451f:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    4523:	e9 84 00             	jmp    0x45aa
    4526:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4529:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    452d:	06                   	push   es
    452e:	57                   	push   di
    452f:	8d be f0 fb          	lea    di,[bp-0x410]
    4533:	16                   	push   ss
    4534:	57                   	push   di
    4535:	8d be f0 fc          	lea    di,[bp-0x310]
    4539:	16                   	push   ss
    453a:	57                   	push   di
    453b:	68 27 f2             	push   0xf227
    453e:	9a 2b 09 50 45       	call   0x4550:0x92b
    4543:	6a 01                	push   0x1
    4545:	ff 76 f0             	push   WORD PTR [bp-0x10]
    4548:	9a 0b 18 cd 48       	call   0x48cd:0x180b
    454d:	9a ed 07 6a 49       	call   0x496a:0x7ed
    4552:	09 c0                	or     ax,ax
    4554:	75 06                	jne    0x455c
    4556:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    455a:	eb 4e                	jmp    0x45aa
    455c:	68 11 f2             	push   0xf211
    455f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4562:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4566:	89 f8                	mov    ax,di
    4568:	8c c2                	mov    dx,es
    456a:	89 86 e0 fa          	mov    WORD PTR [bp-0x520],ax
    456e:	89 96 e2 fa          	mov    WORD PTR [bp-0x51e],dx
    4572:	c6 86 e4 fa 04       	mov    BYTE PTR [bp-0x51c],0x4
    4577:	8d be f0 fa          	lea    di,[bp-0x510]
    457b:	16                   	push   ss
    457c:	57                   	push   di
    457d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4580:	06                   	push   es
    4581:	57                   	push   di
    4582:	9a 56 3a b4 45       	call   0x45b4:0x3a56
    4587:	83 c4 04             	add    sp,0x4
    458a:	8d 86 f0 fa          	lea    ax,[bp-0x510]
    458e:	8c d2                	mov    dx,ss
    4590:	89 86 e8 fa          	mov    WORD PTR [bp-0x518],ax
    4594:	89 96 ea fa          	mov    WORD PTR [bp-0x516],dx
    4598:	c6 86 ec fa 04       	mov    BYTE PTR [bp-0x514],0x4
    459d:	8d be e0 fa          	lea    di,[bp-0x520]
    45a1:	16                   	push   ss
    45a2:	57                   	push   di
    45a3:	6a 01                	push   0x1
    45a5:	9a 0a 12 da 49       	call   0x49da:0x120a
    45aa:	eb 7a                	jmp    0x4626
    45ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45af:	06                   	push   es
    45b0:	57                   	push   di
    45b1:	9a 40 48 ca 45       	call   0x45ca:0x4840
    45b6:	09 d0                	or     ax,dx
    45b8:	b0 00                	mov    al,0x0
    45ba:	74 01                	je     0x45bd
    45bc:	40                   	inc    ax
    45bd:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    45c0:	eb 64                	jmp    0x4626
    45c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45c5:	06                   	push   es
    45c6:	57                   	push   di
    45c7:	9a d4 4b ee 45       	call   0x45ee:0x4bd4
    45cc:	9b 2e d8 1e 22 44    	fcomp  DWORD PTR cs:0x4422
    45d2:	9b dd 7e ee          	fstsw  WORD PTR [bp-0x12]
    45d6:	90                   	nop
    45d7:	9b                   	fwait
    45d8:	8a 66 ef             	mov    ah,BYTE PTR [bp-0x11]
    45db:	9e                   	sahf
    45dc:	b0 00                	mov    al,0x0
    45de:	74 01                	je     0x45e1
    45e0:	40                   	inc    ax
    45e1:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    45e4:	eb 40                	jmp    0x4626
    45e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45e9:	06                   	push   es
    45ea:	57                   	push   di
    45eb:	9a bc 46 24 46       	call   0x4624:0x46bc
    45f0:	9b 2e d8 1e 22 44    	fcomp  DWORD PTR cs:0x4422
    45f6:	9b dd 7e ee          	fstsw  WORD PTR [bp-0x12]
    45fa:	90                   	nop
    45fb:	9b                   	fwait
    45fc:	8a 66 ef             	mov    ah,BYTE PTR [bp-0x11]
    45ff:	9e                   	sahf
    4600:	b0 00                	mov    al,0x0
    4602:	74 01                	je     0x4605
    4604:	40                   	inc    ax
    4605:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    4608:	eb 1c                	jmp    0x4626
    460a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    460d:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4611:	f7 d8                	neg    ax
    4613:	18 c0                	sbb    al,al
    4615:	f6 d8                	neg    al
    4617:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    461a:	eb 0a                	jmp    0x4626
    461c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    461f:	06                   	push   es
    4620:	57                   	push   di
    4621:	9a a9 42 38 46       	call   0x4638:0x42a9
    4626:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4629:	c9                   	leave
    462a:	ca 04 00             	retf   0x4
    462d:	55                   	push   bp
    462e:	89 e5                	mov    bp,sp
    4630:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4633:	06                   	push   es
    4634:	57                   	push   di
    4635:	9a 05 43 44 46       	call   0x4644:0x4305
    463a:	6a 06                	push   0x6
    463c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    463f:	06                   	push   es
    4640:	57                   	push   di
    4641:	9a 0b 3a 6f 46       	call   0x466f:0x3a0b
    4646:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    464a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    464d:	9b 26 dd 5d 08       	fstp   QWORD PTR es:[di+0x8]
    4652:	90                   	nop
    4653:	9b                   	fwait
    4654:	c9                   	leave
    4655:	ca 0c 00             	retf   0xc
    4658:	55                   	push   bp
    4659:	89 e5                	mov    bp,sp
    465b:	ff 76 10             	push   WORD PTR [bp+0x10]
    465e:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4661:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4664:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4667:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    466a:	06                   	push   es
    466b:	57                   	push   di
    466c:	9a 2d 46 94 46       	call   0x4694:0x462d
    4671:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4674:	26 c6 45 18 07       	mov    BYTE PTR es:[di+0x18],0x7
    4679:	c9                   	leave
    467a:	ca 0c 00             	retf   0xc
    467d:	55                   	push   bp
    467e:	89 e5                	mov    bp,sp
    4680:	ff 76 10             	push   WORD PTR [bp+0x10]
    4683:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4686:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4689:	ff 76 0a             	push   WORD PTR [bp+0xa]
    468c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    468f:	06                   	push   es
    4690:	57                   	push   di
    4691:	9a 2d 46 16 47       	call   0x4716:0x462d
    4696:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4699:	26 c6 45 18 08       	mov    BYTE PTR es:[di+0x18],0x8
    469e:	c9                   	leave
    469f:	ca 0c 00             	retf   0xc
    46a2:	00 00                	add    BYTE PTR [bx+si],al
    46a4:	00 00                	add    BYTE PTR [bx+si],al
    46a6:	f3 46                	repz inc si
    46a8:	7c 47                	jl     0x46f1
    46aa:	7c 47                	jl     0x46f3
    46ac:	7c 47                	jl     0x46f5
    46ae:	aa                   	stos   BYTE PTR es:[di],al
    46af:	47                   	inc    di
    46b0:	6c                   	ins    BYTE PTR es:[di],dx
    46b1:	47                   	inc    di
    46b2:	6c                   	ins    BYTE PTR es:[di],dx
    46b3:	47                   	inc    di
    46b4:	6c                   	ins    BYTE PTR es:[di],dx
    46b5:	47                   	inc    di
    46b6:	98                   	cbw
    46b7:	47                   	inc    di
    46b8:	98                   	cbw
    46b9:	47                   	inc    di
    46ba:	98                   	cbw
    46bb:	47                   	inc    di
    46bc:	c8 18 00 00          	enter  0x18,0x0
    46c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46c3:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    46c8:	74 0f                	je     0x46d9
    46ca:	9b 2e d9 06 a2 46    	fld    DWORD PTR cs:0x46a2
    46d0:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    46d4:	90                   	nop
    46d5:	9b                   	fwait
    46d6:	e9 db 00             	jmp    0x47b4
    46d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46dc:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    46e0:	2c 01                	sub    al,0x1
    46e2:	3c 0a                	cmp    al,0xa
    46e4:	76 03                	jbe    0x46e9
    46e6:	e9 c1 00             	jmp    0x47aa
    46e9:	98                   	cbw
    46ea:	89 c3                	mov    bx,ax
    46ec:	d1 e3                	shl    bx,1
    46ee:	2e ff a7 a6 46       	jmp    WORD PTR cs:[bx+0x46a6]
    46f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46f6:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    46fa:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    46fe:	76 5e                	jbe    0x475e
    4700:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4703:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4707:	06                   	push   es
    4708:	57                   	push   di
    4709:	8d 7e ec             	lea    di,[bp-0x14]
    470c:	16                   	push   ss
    470d:	57                   	push   di
    470e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4711:	06                   	push   es
    4712:	57                   	push   di
    4713:	9a 41 43 3e 47       	call   0x473e:0x4341
    4718:	08 c0                	or     al,al
    471a:	74 0c                	je     0x4728
    471c:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
    4720:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4724:	90                   	nop
    4725:	9b                   	fwait
    4726:	eb 34                	jmp    0x475c
    4728:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    472b:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    472f:	06                   	push   es
    4730:	57                   	push   di
    4731:	8d 7e f0             	lea    di,[bp-0x10]
    4734:	16                   	push   ss
    4735:	57                   	push   di
    4736:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4739:	06                   	push   es
    473a:	57                   	push   di
    473b:	9a b2 43 84 47       	call   0x4784:0x43b2
    4740:	08 c0                	or     al,al
    4742:	74 0c                	je     0x4750
    4744:	9b dd 46 f0          	fld    QWORD PTR [bp-0x10]
    4748:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    474c:	90                   	nop
    474d:	9b                   	fwait
    474e:	eb 0c                	jmp    0x475c
    4750:	9b 2e d9 06 a2 46    	fld    DWORD PTR cs:0x46a2
    4756:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    475a:	90                   	nop
    475b:	9b                   	fwait
    475c:	eb 0c                	jmp    0x476a
    475e:	9b 2e d9 06 a2 46    	fld    DWORD PTR cs:0x46a2
    4764:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4768:	90                   	nop
    4769:	9b                   	fwait
    476a:	eb 48                	jmp    0x47b4
    476c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    476f:	9b 26 dd 45 08       	fld    QWORD PTR es:[di+0x8]
    4774:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4778:	90                   	nop
    4779:	9b                   	fwait
    477a:	eb 38                	jmp    0x47b4
    477c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    477f:	06                   	push   es
    4780:	57                   	push   di
    4781:	9a 40 48 a0 47       	call   0x47a0:0x4840
    4786:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    4789:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    478c:	9b db 46 e8          	fild   DWORD PTR [bp-0x18]
    4790:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4794:	90                   	nop
    4795:	9b                   	fwait
    4796:	eb 1c                	jmp    0x47b4
    4798:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    479b:	06                   	push   es
    479c:	57                   	push   di
    479d:	9a d4 4b b2 47       	call   0x47b2:0x4bd4
    47a2:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    47a6:	90                   	nop
    47a7:	9b                   	fwait
    47a8:	eb 0a                	jmp    0x47b4
    47aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47ad:	06                   	push   es
    47ae:	57                   	push   di
    47af:	9a a9 42 c9 47       	call   0x47c9:0x42a9
    47b4:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    47b8:	90                   	nop
    47b9:	9b                   	fwait
    47ba:	c9                   	leave
    47bb:	ca 04 00             	retf   0x4
    47be:	55                   	push   bp
    47bf:	89 e5                	mov    bp,sp
    47c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47c4:	06                   	push   es
    47c5:	57                   	push   di
    47c6:	9a 05 43 d5 47       	call   0x47d5:0x4305
    47cb:	6a 03                	push   0x3
    47cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47d0:	06                   	push   es
    47d1:	57                   	push   di
    47d2:	9a 0b 3a fd 47       	call   0x47fd:0x3a0b
    47d7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    47da:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    47dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47e0:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    47e4:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    47e8:	c9                   	leave
    47e9:	ca 08 00             	retf   0x8
    47ec:	55                   	push   bp
    47ed:	89 e5                	mov    bp,sp
    47ef:	ff 76 0c             	push   WORD PTR [bp+0xc]
    47f2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    47f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47f8:	06                   	push   es
    47f9:	57                   	push   di
    47fa:	9a be 47 1c 48       	call   0x481c:0x47be
    47ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4802:	26 c6 45 18 04       	mov    BYTE PTR es:[di+0x18],0x4
    4807:	c9                   	leave
    4808:	ca 08 00             	retf   0x8
    480b:	55                   	push   bp
    480c:	89 e5                	mov    bp,sp
    480e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4811:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4814:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4817:	06                   	push   es
    4818:	57                   	push   di
    4819:	9a be 47 96 48       	call   0x4896:0x47be
    481e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4821:	26 c6 45 18 02       	mov    BYTE PTR es:[di+0x18],0x2
    4826:	c9                   	leave
    4827:	ca 08 00             	retf   0x8
    482a:	73 48                	jae    0x4874
    482c:	eb 48                	jmp    0x4876
    482e:	eb 48                	jmp    0x4878
    4830:	eb 48                	jmp    0x487a
    4832:	2c 49                	sub    al,0x49
    4834:	fe 48 fe             	dec    BYTE PTR [bx+si-0x2]
    4837:	48                   	dec    ax
    4838:	fe 48 15             	dec    BYTE PTR [bx+si+0x15]
    483b:	49                   	dec    cx
    483c:	15 49 15             	adc    ax,0x1549
    483f:	49                   	dec    cx
    4840:	c8 10 00 00          	enter  0x10,0x0
    4844:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4847:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    484c:	74 0b                	je     0x4859
    484e:	31 c0                	xor    ax,ax
    4850:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4853:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4856:	e9 dd 00             	jmp    0x4936
    4859:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    485c:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    4860:	2c 01                	sub    al,0x1
    4862:	3c 0a                	cmp    al,0xa
    4864:	76 03                	jbe    0x4869
    4866:	e9 c3 00             	jmp    0x492c
    4869:	98                   	cbw
    486a:	89 c3                	mov    bx,ax
    486c:	d1 e3                	shl    bx,1
    486e:	2e ff a7 2a 48       	jmp    WORD PTR cs:[bx+0x482a]
    4873:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4876:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    487a:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    487e:	76 61                	jbe    0x48e1
    4880:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4883:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4887:	06                   	push   es
    4888:	57                   	push   di
    4889:	8d 7e f0             	lea    di,[bp-0x10]
    488c:	16                   	push   ss
    488d:	57                   	push   di
    488e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4891:	06                   	push   es
    4892:	57                   	push   di
    4893:	9a 41 43 c0 48       	call   0x48c0:0x4341
    4898:	08 c0                	or     al,al
    489a:	74 0e                	je     0x48aa
    489c:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    489f:	8b 56 f2             	mov    dx,WORD PTR [bp-0xe]
    48a2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    48a5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    48a8:	eb 35                	jmp    0x48df
    48aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48ad:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    48b1:	06                   	push   es
    48b2:	57                   	push   di
    48b3:	8d 7e f4             	lea    di,[bp-0xc]
    48b6:	16                   	push   ss
    48b7:	57                   	push   di
    48b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48bb:	06                   	push   es
    48bc:	57                   	push   di
    48bd:	9a b2 43 06 49       	call   0x4906:0x43b2
    48c2:	08 c0                	or     al,al
    48c4:	74 11                	je     0x48d7
    48c6:	9b dd 46 f4          	fld    QWORD PTR [bp-0xc]
    48ca:	9a 0e 10 0b 49       	call   0x490b:0x100e
    48cf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    48d2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    48d5:	eb 08                	jmp    0x48df
    48d7:	31 c0                	xor    ax,ax
    48d9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    48dc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    48df:	eb 08                	jmp    0x48e9
    48e1:	31 c0                	xor    ax,ax
    48e3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    48e6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    48e9:	eb 4b                	jmp    0x4936
    48eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48ee:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    48f2:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    48f6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    48f9:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    48fc:	eb 38                	jmp    0x4936
    48fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4901:	06                   	push   es
    4902:	57                   	push   di
    4903:	9a bc 46 1d 49       	call   0x491d:0x46bc
    4908:	9a 0e 10 22 49       	call   0x4922:0x100e
    490d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4910:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4913:	eb 21                	jmp    0x4936
    4915:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4918:	06                   	push   es
    4919:	57                   	push   di
    491a:	9a d4 4b 34 49       	call   0x4934:0x4bd4
    491f:	9a 0e 10 f3 49       	call   0x49f3:0x100e
    4924:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4927:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    492a:	eb 0a                	jmp    0x4936
    492c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    492f:	06                   	push   es
    4930:	57                   	push   di
    4931:	9a a9 42 4b 49       	call   0x494b:0x42a9
    4936:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4939:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    493c:	c9                   	leave
    493d:	ca 04 00             	retf   0x4
    4940:	55                   	push   bp
    4941:	89 e5                	mov    bp,sp
    4943:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4946:	06                   	push   es
    4947:	57                   	push   di
    4948:	9a 05 43 57 49       	call   0x4957:0x4305
    494d:	6a 01                	push   0x1
    494f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4952:	06                   	push   es
    4953:	57                   	push   di
    4954:	9a 0b 3a dd 4a       	call   0x4add:0x3a0b
    4959:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    495c:	81 c7 14 00          	add    di,0x14
    4960:	06                   	push   es
    4961:	57                   	push   di
    4962:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4965:	06                   	push   es
    4966:	57                   	push   di
    4967:	9a 51 06 0c 4a       	call   0x4a0c:0x651
    496c:	c9                   	leave
    496d:	ca 08 00             	retf   0x8
    4970:	b8 49 df             	mov    ax,0xdf49
    4973:	49                   	dec    cx
    4974:	f8                   	clc
    4975:	49                   	dec    cx
    4976:	f8                   	clc
    4977:	49                   	dec    cx
    4978:	f8                   	clc
    4979:	49                   	dec    cx
    497a:	d5 4a                	aad    0x4a
    497c:	a8 4a                	test   al,0x4a
    497e:	a8 4a                	test   al,0x4a
    4980:	a8 4a                	test   al,0x4a
    4982:	1e                   	push   ds
    4983:	4a                   	dec    dx
    4984:	4c                   	dec    sp
    4985:	4a                   	dec    dx
    4986:	7a 4a                	jp     0x49d2
    4988:	c8 00 01 00          	enter  0x100,0x0
    498c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    498f:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    4994:	74 0a                	je     0x49a0
    4996:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4999:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    499d:	e9 a1 01             	jmp    0x4b41
    49a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49a3:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    49a7:	3c 0b                	cmp    al,0xb
    49a9:	76 03                	jbe    0x49ae
    49ab:	e9 6f 01             	jmp    0x4b1d
    49ae:	98                   	cbw
    49af:	89 c3                	mov    bx,ax
    49b1:	d1 e3                	shl    bx,1
    49b3:	2e ff a7 70 49       	jmp    WORD PTR cs:[bx+0x4970]
    49b8:	68 1b f2             	push   0xf21b
    49bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49be:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    49c2:	89 f8                	mov    ax,di
    49c4:	8c c2                	mov    dx,es
    49c6:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    49c9:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    49cc:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    49d0:	8d 7e f8             	lea    di,[bp-0x8]
    49d3:	16                   	push   ss
    49d4:	57                   	push   di
    49d5:	6a 00                	push   0x0
    49d7:	9a 0a 12 3f 4b       	call   0x4b3f:0x120a
    49dc:	e9 62 01             	jmp    0x4b41
    49df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49e2:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    49e6:	06                   	push   es
    49e7:	57                   	push   di
    49e8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    49eb:	06                   	push   es
    49ec:	57                   	push   di
    49ed:	68 ff 00             	push   0xff
    49f0:	9a e7 17 19 4a       	call   0x4a19:0x17e7
    49f5:	e9 49 01             	jmp    0x4b41
    49f8:	8d be 00 ff          	lea    di,[bp-0x100]
    49fc:	16                   	push   ss
    49fd:	57                   	push   di
    49fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a01:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4a05:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4a09:	9a a9 08 3a 4a       	call   0x4a3a:0x8a9
    4a0e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a11:	06                   	push   es
    4a12:	57                   	push   di
    4a13:	68 ff 00             	push   0xff
    4a16:	9a e7 17 47 4a       	call   0x4a47:0x17e7
    4a1b:	e9 23 01             	jmp    0x4b41
    4a1e:	8d be 00 ff          	lea    di,[bp-0x100]
    4a22:	16                   	push   ss
    4a23:	57                   	push   di
    4a24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a27:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    4a2b:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4a2f:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4a33:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4a37:	9a bf 1c 68 4a       	call   0x4a68:0x1cbf
    4a3c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a3f:	06                   	push   es
    4a40:	57                   	push   di
    4a41:	68 ff 00             	push   0xff
    4a44:	9a e7 17 75 4a       	call   0x4a75:0x17e7
    4a49:	e9 f5 00             	jmp    0x4b41
    4a4c:	8d be 00 ff          	lea    di,[bp-0x100]
    4a50:	16                   	push   ss
    4a51:	57                   	push   di
    4a52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a55:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    4a59:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4a5d:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4a61:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4a65:	9a e4 1c 96 4a       	call   0x4a96:0x1ce4
    4a6a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a6d:	06                   	push   es
    4a6e:	57                   	push   di
    4a6f:	68 ff 00             	push   0xff
    4a72:	9a e7 17 a3 4a       	call   0x4aa3:0x17e7
    4a77:	e9 c7 00             	jmp    0x4b41
    4a7a:	8d be 00 ff          	lea    di,[bp-0x100]
    4a7e:	16                   	push   ss
    4a7f:	57                   	push   di
    4a80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a83:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    4a87:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4a8b:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4a8f:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4a93:	9a 0a 1d c4 4a       	call   0x4ac4:0x1d0a
    4a98:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a9b:	06                   	push   es
    4a9c:	57                   	push   di
    4a9d:	68 ff 00             	push   0xff
    4aa0:	9a e7 17 d1 4a       	call   0x4ad1:0x17e7
    4aa5:	e9 99 00             	jmp    0x4b41
    4aa8:	8d be 00 ff          	lea    di,[bp-0x100]
    4aac:	16                   	push   ss
    4aad:	57                   	push   di
    4aae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ab1:	9b 26 dd 45 08       	fld    QWORD PTR es:[di+0x8]
    4ab6:	83 ec 0a             	sub    sp,0xa
    4ab9:	89 e3                	mov    bx,sp
    4abb:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    4abf:	90                   	nop
    4ac0:	9b                   	fwait
    4ac1:	9a a4 10 ef 4a       	call   0x4aef:0x10a4
    4ac6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4ac9:	06                   	push   es
    4aca:	57                   	push   di
    4acb:	68 ff 00             	push   0xff
    4ace:	9a e7 17 fc 4a       	call   0x4afc:0x17e7
    4ad3:	eb 6c                	jmp    0x4b41
    4ad5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ad8:	06                   	push   es
    4ad9:	57                   	push   di
    4ada:	9a 3c 44 50 4b       	call   0x4b50:0x443c
    4adf:	08 c0                	or     al,al
    4ae1:	74 1d                	je     0x4b00
    4ae3:	8d be 00 ff          	lea    di,[bp-0x100]
    4ae7:	16                   	push   ss
    4ae8:	57                   	push   di
    4ae9:	68 27 f2             	push   0xf227
    4aec:	9a 2b 09 0c 4b       	call   0x4b0c:0x92b
    4af1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4af4:	06                   	push   es
    4af5:	57                   	push   di
    4af6:	68 ff 00             	push   0xff
    4af9:	9a e7 17 19 4b       	call   0x4b19:0x17e7
    4afe:	eb 1b                	jmp    0x4b1b
    4b00:	8d be 00 ff          	lea    di,[bp-0x100]
    4b04:	16                   	push   ss
    4b05:	57                   	push   di
    4b06:	68 26 f2             	push   0xf226
    4b09:	9a 2b 09 1a 4c       	call   0x4c1a:0x92b
    4b0e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4b11:	06                   	push   es
    4b12:	57                   	push   di
    4b13:	68 ff 00             	push   0xff
    4b16:	9a e7 17 85 4c       	call   0x4c85:0x17e7
    4b1b:	eb 24                	jmp    0x4b41
    4b1d:	68 1c f2             	push   0xf21c
    4b20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b23:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4b27:	89 f8                	mov    ax,di
    4b29:	8c c2                	mov    dx,es
    4b2b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    4b2e:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    4b31:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    4b35:	8d 7e f8             	lea    di,[bp-0x8]
    4b38:	16                   	push   ss
    4b39:	57                   	push   di
    4b3a:	6a 00                	push   0x0
    4b3c:	9a 0a 12 92 4c       	call   0x4c92:0x120a
    4b41:	c9                   	leave
    4b42:	ca 04 00             	retf   0x4
    4b45:	55                   	push   bp
    4b46:	89 e5                	mov    bp,sp
    4b48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b4b:	06                   	push   es
    4b4c:	57                   	push   di
    4b4d:	9a 05 43 5c 4b       	call   0x4b5c:0x4305
    4b52:	6a 09                	push   0x9
    4b54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b57:	06                   	push   es
    4b58:	57                   	push   di
    4b59:	9a 0b 3a 87 4b       	call   0x4b87:0x3a0b
    4b5e:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    4b62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b65:	9b 26 dd 5d 08       	fstp   QWORD PTR es:[di+0x8]
    4b6a:	90                   	nop
    4b6b:	9b                   	fwait
    4b6c:	c9                   	leave
    4b6d:	ca 0c 00             	retf   0xc
    4b70:	55                   	push   bp
    4b71:	89 e5                	mov    bp,sp
    4b73:	ff 76 10             	push   WORD PTR [bp+0x10]
    4b76:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4b79:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4b7c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b82:	06                   	push   es
    4b83:	57                   	push   di
    4b84:	9a 45 4b ac 4b       	call   0x4bac:0x4b45
    4b89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b8c:	26 c6 45 18 0a       	mov    BYTE PTR es:[di+0x18],0xa
    4b91:	c9                   	leave
    4b92:	ca 0c 00             	retf   0xc
    4b95:	55                   	push   bp
    4b96:	89 e5                	mov    bp,sp
    4b98:	ff 76 10             	push   WORD PTR [bp+0x10]
    4b9b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4b9e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ba1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4ba4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ba7:	06                   	push   es
    4ba8:	57                   	push   di
    4ba9:	9a 45 4b 15 4c       	call   0x4c15:0x4b45
    4bae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bb1:	26 c6 45 18 0b       	mov    BYTE PTR es:[di+0x18],0xb
    4bb6:	c9                   	leave
    4bb7:	ca 0c 00             	retf   0xc
    4bba:	00 00                	add    BYTE PTR [bx+si],al
    4bbc:	00 00                	add    BYTE PTR [bx+si],al
    4bbe:	07                   	pop    es
    4bbf:	4c                   	dec    sp
    4bc0:	34 4c                	xor    al,0x4c
    4bc2:	34 4c                	xor    al,0x4c
    4bc4:	34 4c                	xor    al,0x4c
    4bc6:	62 4c 50             	bound  cx,DWORD PTR [si+0x50]
    4bc9:	4c                   	dec    sp
    4bca:	50                   	push   ax
    4bcb:	4c                   	dec    sp
    4bcc:	50                   	push   ax
    4bcd:	4c                   	dec    sp
    4bce:	24 4c                	and    al,0x4c
    4bd0:	24 4c                	and    al,0x4c
    4bd2:	24 4c                	and    al,0x4c
    4bd4:	c8 08 01 00          	enter  0x108,0x0
    4bd8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bdb:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    4be0:	74 0e                	je     0x4bf0
    4be2:	9b 2e d9 06 ba 4b    	fld    DWORD PTR cs:0x4bba
    4be8:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4bec:	90                   	nop
    4bed:	9b                   	fwait
    4bee:	eb 7c                	jmp    0x4c6c
    4bf0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bf3:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    4bf7:	2c 01                	sub    al,0x1
    4bf9:	3c 0a                	cmp    al,0xa
    4bfb:	77 65                	ja     0x4c62
    4bfd:	98                   	cbw
    4bfe:	89 c3                	mov    bx,ax
    4c00:	d1 e3                	shl    bx,1
    4c02:	2e ff a7 be 4b       	jmp    WORD PTR cs:[bx+0x4bbe]
    4c07:	8d be f8 fe          	lea    di,[bp-0x108]
    4c0b:	16                   	push   ss
    4c0c:	57                   	push   di
    4c0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c10:	06                   	push   es
    4c11:	57                   	push   di
    4c12:	9a 88 49 3c 4c       	call   0x4c3c:0x4988
    4c17:	9a 14 22 39 4e       	call   0x4e39:0x2214
    4c1c:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4c20:	90                   	nop
    4c21:	9b                   	fwait
    4c22:	eb 48                	jmp    0x4c6c
    4c24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c27:	9b 26 dd 45 08       	fld    QWORD PTR es:[di+0x8]
    4c2c:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4c30:	90                   	nop
    4c31:	9b                   	fwait
    4c32:	eb 38                	jmp    0x4c6c
    4c34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c37:	06                   	push   es
    4c38:	57                   	push   di
    4c39:	9a 40 48 58 4c       	call   0x4c58:0x4840
    4c3e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    4c41:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    4c44:	9b db 46 f4          	fild   DWORD PTR [bp-0xc]
    4c48:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4c4c:	90                   	nop
    4c4d:	9b                   	fwait
    4c4e:	eb 1c                	jmp    0x4c6c
    4c50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c53:	06                   	push   es
    4c54:	57                   	push   di
    4c55:	9a bc 46 6a 4c       	call   0x4c6a:0x46bc
    4c5a:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    4c5e:	90                   	nop
    4c5f:	9b                   	fwait
    4c60:	eb 0a                	jmp    0x4c6c
    4c62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c65:	06                   	push   es
    4c66:	57                   	push   di
    4c67:	9a a9 42 dd 4c       	call   0x4cdd:0x42a9
    4c6c:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    4c70:	90                   	nop
    4c71:	9b                   	fwait
    4c72:	c9                   	leave
    4c73:	ca 04 00             	retf   0x4
    4c76:	55                   	push   bp
    4c77:	89 e5                	mov    bp,sp
    4c79:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4c7d:	74 08                	je     0x4c87
    4c7f:	83 ec 08             	sub    sp,0x8
    4c82:	9a e2 1f 48 4d       	call   0x4d48:0x1fe2
    4c87:	31 c0                	xor    ax,ax
    4c89:	50                   	push   ax
    4c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c8d:	06                   	push   es
    4c8e:	57                   	push   di
    4c8f:	9a dc 75 cb 4c       	call   0x4ccb:0x75dc
    4c94:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    4c97:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    4c9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c9d:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    4ca1:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    4ca5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4ca9:	74 07                	je     0x4cb2
    4cab:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4caf:	83 c4 06             	add    sp,0x6
    4cb2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4cb5:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4cb8:	c9                   	leave
    4cb9:	ca 0a 00             	retf   0xa
    4cbc:	55                   	push   bp
    4cbd:	89 e5                	mov    bp,sp
    4cbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cc2:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4cc6:	06                   	push   es
    4cc7:	57                   	push   di
    4cc8:	9a 02 32 fa 4c       	call   0x4cfa:0x3202
    4ccd:	08 c0                	or     al,al
    4ccf:	74 0e                	je     0x4cdf
    4cd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cd4:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4cd8:	06                   	push   es
    4cd9:	57                   	push   di
    4cda:	9a e3 52 0c 4d       	call   0x4d0c:0x52e3
    4cdf:	c9                   	leave
    4ce0:	ca 04 00             	retf   0x4
    4ce3:	55                   	push   bp
    4ce4:	89 e5                	mov    bp,sp
    4ce6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4ce9:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    4cec:	75 20                	jne    0x4d0e
    4cee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cf1:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4cf5:	06                   	push   es
    4cf6:	57                   	push   di
    4cf7:	9a 02 32 21 4d       	call   0x4d21:0x3202
    4cfc:	08 c0                	or     al,al
    4cfe:	74 0e                	je     0x4d0e
    4d00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d03:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4d07:	06                   	push   es
    4d08:	57                   	push   di
    4d09:	9a e3 52 80 4d       	call   0x4d80:0x52e3
    4d0e:	c9                   	leave
    4d0f:	ca 08 00             	retf   0x8
    4d12:	55                   	push   bp
    4d13:	89 e5                	mov    bp,sp
    4d15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d18:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4d1c:	06                   	push   es
    4d1d:	57                   	push   di
    4d1e:	9a 02 32 33 4d       	call   0x4d33:0x3202
    4d23:	08 c0                	or     al,al
    4d25:	74 0e                	je     0x4d35
    4d27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d2a:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    4d2e:	06                   	push   es
    4d2f:	57                   	push   di
    4d30:	9a 3d 4c 5b 4d       	call   0x4d5b:0x4c3d
    4d35:	c9                   	leave
    4d36:	ca 04 00             	retf   0x4
    4d39:	55                   	push   bp
    4d3a:	89 e5                	mov    bp,sp
    4d3c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4d40:	74 08                	je     0x4d4a
    4d42:	83 ec 08             	sub    sp,0x8
    4d45:	9a e2 1f 27 4e       	call   0x4e27:0x1fe2
    4d4a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4d4d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d50:	31 c0                	xor    ax,ax
    4d52:	50                   	push   ax
    4d53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d56:	06                   	push   es
    4d57:	57                   	push   di
    4d58:	9a e5 2d 76 4e       	call   0x4e76:0x2de5
    4d5d:	b0 01                	mov    al,0x1
    4d5f:	50                   	push   ax
    4d60:	b8 c9 03             	mov    ax,0x3c9
    4d63:	ba 6b 4d             	mov    dx,0x4d6b
    4d66:	52                   	push   dx
    4d67:	50                   	push   ax
    4d68:	9a 08 1d 0b 4e       	call   0x4e0b:0x1d08
    4d6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d70:	26 89 85 7c 01       	mov    WORD PTR es:[di+0x17c],ax
    4d75:	26 89 95 7e 01       	mov    WORD PTR es:[di+0x17e],dx
    4d7a:	06                   	push   es
    4d7b:	57                   	push   di
    4d7c:	b8 9f 4f             	mov    ax,0x4f9f
    4d7f:	ba 9e 4d             	mov    dx,0x4d9e
    4d82:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    4d87:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    4d8b:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    4d8f:	26 8f 45 10          	pop    WORD PTR es:[di+0x10]
    4d93:	26 8f 45 12          	pop    WORD PTR es:[di+0x12]
    4d97:	b0 01                	mov    al,0x1
    4d99:	50                   	push   ax
    4d9a:	b8 75 03             	mov    ax,0x375
    4d9d:	ba a5 4d             	mov    dx,0x4da5
    4da0:	52                   	push   dx
    4da1:	50                   	push   ax
    4da2:	9a f4 31 c1 4d       	call   0x4dc1:0x31f4
    4da7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4daa:	26 89 85 81 01       	mov    WORD PTR es:[di+0x181],ax
    4daf:	26 89 95 83 01       	mov    WORD PTR es:[di+0x183],dx
    4db4:	ff 76 08             	push   WORD PTR [bp+0x8]
    4db7:	ff 76 06             	push   WORD PTR [bp+0x6]
    4dba:	b0 01                	mov    al,0x1
    4dbc:	50                   	push   ax
    4dbd:	b8 a0 15             	mov    ax,0x15a0
    4dc0:	ba c8 4d             	mov    dx,0x4dc8
    4dc3:	52                   	push   dx
    4dc4:	50                   	push   ax
    4dc5:	9a 76 4c 9c 4e       	call   0x4e9c:0x4c76
    4dca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dcd:	26 89 85 89 01       	mov    WORD PTR es:[di+0x189],ax
    4dd2:	26 89 95 8b 01       	mov    WORD PTR es:[di+0x18b],dx
    4dd7:	31 c0                	xor    ax,ax
    4dd9:	26 89 85 85 01       	mov    WORD PTR es:[di+0x185],ax
    4dde:	26 89 85 87 01       	mov    WORD PTR es:[di+0x187],ax
    4de3:	26 c6 85 8f 01 00    	mov    BYTE PTR es:[di+0x18f],0x0
    4de9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4ded:	74 07                	je     0x4df6
    4def:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4df3:	83 c4 06             	add    sp,0x6
    4df6:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4df9:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4dfc:	c9                   	leave
    4dfd:	ca 0a 00             	retf   0xa
    4e00:	55                   	push   bp
    4e01:	89 e5                	mov    bp,sp
    4e03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e06:	06                   	push   es
    4e07:	57                   	push   di
    4e08:	9a a5 4e c3 50       	call   0x50c3:0x4ea5
    4e0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e10:	06                   	push   es
    4e11:	57                   	push   di
    4e12:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e15:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    4e1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e1d:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    4e22:	06                   	push   es
    4e23:	57                   	push   di
    4e24:	9a 7f 1f 48 4e       	call   0x4e48:0x1f7f
    4e29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e2c:	26 ff b5 87 01       	push   WORD PTR es:[di+0x187]
    4e31:	26 ff b5 85 01       	push   WORD PTR es:[di+0x185]
    4e36:	9a 23 0f 69 4e       	call   0x4e69:0xf23
    4e3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e3e:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    4e43:	06                   	push   es
    4e44:	57                   	push   di
    4e45:	9a 7f 1f 57 4e       	call   0x4e57:0x1f7f
    4e4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e4d:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    4e52:	06                   	push   es
    4e53:	57                   	push   di
    4e54:	9a 7f 1f 81 4e       	call   0x4e81:0x1f7f
    4e59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e5c:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    4e61:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    4e66:	9a 23 0f c0 4f       	call   0x4fc0:0xf23
    4e6b:	31 c0                	xor    ax,ax
    4e6d:	50                   	push   ax
    4e6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e71:	06                   	push   es
    4e72:	57                   	push   di
    4e73:	9a 9a 2e 92 4e       	call   0x4e92:0x2e9a
    4e78:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4e7c:	74 05                	je     0x4e83
    4e7e:	9a 0f 20 60 50       	call   0x5060:0x200f
    4e83:	c9                   	leave
    4e84:	ca 06 00             	retf   0x6
    4e87:	55                   	push   bp
    4e88:	89 e5                	mov    bp,sp
    4e8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e8d:	06                   	push   es
    4e8e:	57                   	push   di
    4e8f:	9a d2 31 d7 4e       	call   0x4ed7:0x31d2
    4e94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e97:	06                   	push   es
    4e98:	57                   	push   di
    4e99:	9a a2 4e af 4e       	call   0x4eaf:0x4ea2
    4e9e:	c9                   	leave
    4e9f:	ca 04 00             	retf   0x4
    4ea2:	55                   	push   bp
    4ea3:	89 e5                	mov    bp,sp
    4ea5:	6a 00                	push   0x0
    4ea7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eaa:	06                   	push   es
    4eab:	57                   	push   di
    4eac:	9a 79 51 6c 4f       	call   0x4f6c:0x5179
    4eb1:	6a 01                	push   0x1
    4eb3:	6a 00                	push   0x0
    4eb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eb8:	06                   	push   es
    4eb9:	57                   	push   di
    4eba:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ebd:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    4ec2:	c9                   	leave
    4ec3:	ca 04 00             	retf   0x4
    4ec6:	55                   	push   bp
    4ec7:	89 e5                	mov    bp,sp
    4ec9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ecc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4ecf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ed2:	06                   	push   es
    4ed3:	57                   	push   di
    4ed4:	9a da 3d e3 4e       	call   0x4ee3:0x3dda
    4ed9:	08 c0                	or     al,al
    4edb:	74 08                	je     0x4ee5
    4edd:	68 1f f2             	push   0xf21f
    4ee0:	9a ef 11 f8 4e       	call   0x4ef8:0x11ef
    4ee5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ee8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4eeb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eee:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    4ef3:	06                   	push   es
    4ef4:	57                   	push   di
    4ef5:	9a 31 77 8f 51       	call   0x518f:0x7731
    4efa:	c9                   	leave
    4efb:	ca 08 00             	retf   0x8
    4efe:	c8 04 00 00          	enter  0x4,0x0
    4f02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f05:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    4f0a:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4f0e:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    4f12:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4f15:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4f18:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4f1b:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    4f1e:	c9                   	leave
    4f1f:	ca 04 00             	retf   0x4
    4f22:	55                   	push   bp
    4f23:	89 e5                	mov    bp,sp
    4f25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f28:	06                   	push   es
    4f29:	57                   	push   di
    4f2a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f2d:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    4f32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f35:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    4f3a:	31 c0                	xor    ax,ax
    4f3c:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    4f40:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    4f44:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    4f48:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    4f4c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f4f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4f52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f55:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    4f5a:	06                   	push   es
    4f5b:	57                   	push   di
    4f5c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f5f:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    4f63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f66:	06                   	push   es
    4f67:	57                   	push   di
    4f68:	b8 9f 4f             	mov    ax,0x4f9f
    4f6b:	ba 8f 4f             	mov    dx,0x4f8f
    4f6e:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    4f73:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    4f77:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    4f7b:	26 8f 45 10          	pop    WORD PTR es:[di+0x10]
    4f7f:	26 8f 45 12          	pop    WORD PTR es:[di+0x12]
    4f83:	6a 00                	push   0x0
    4f85:	6a 00                	push   0x0
    4f87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f8a:	06                   	push   es
    4f8b:	57                   	push   di
    4f8c:	9a 9f 4f 9d 4f       	call   0x4f9d:0x4f9f
    4f91:	c9                   	leave
    4f92:	ca 08 00             	retf   0x8
    4f95:	01 00                	add    WORD PTR [bx+si],ax
    4f97:	00 00                	add    BYTE PTR [bx+si],al
    4f99:	00 00                	add    BYTE PTR [bx+si],al
    4f9b:	7e 50                	jle    0x4fed
    4f9d:	05 50 c8             	add    ax,0xc850
    4fa0:	04 00                	add    al,0x0
    4fa2:	00 c4                	add    ah,al
    4fa4:	7e 06                	jle    0x4fac
    4fa6:	06                   	push   es
    4fa7:	57                   	push   di
    4fa8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fab:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    4fb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fb3:	26 ff b5 87 01       	push   WORD PTR es:[di+0x187]
    4fb8:	26 ff b5 85 01       	push   WORD PTR es:[di+0x185]
    4fbd:	9a 23 0f ed 4f       	call   0x4fed:0xf23
    4fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fc5:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    4fca:	06                   	push   es
    4fcb:	57                   	push   di
    4fcc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fcf:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    4fd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fd6:	26 89 85 85 01       	mov    WORD PTR es:[di+0x185],ax
    4fdb:	26 89 95 87 01       	mov    WORD PTR es:[di+0x187],dx
    4fe0:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    4fe5:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    4fea:	9a 23 0f 18 51       	call   0x5118:0xf23
    4fef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ff2:	31 c0                	xor    ax,ax
    4ff4:	26 89 85 90 01       	mov    WORD PTR es:[di+0x190],ax
    4ff9:	26 89 85 92 01       	mov    WORD PTR es:[di+0x192],ax
    4ffe:	b0 01                	mov    al,0x1
    5000:	50                   	push   ax
    5001:	b8 75 03             	mov    ax,0x375
    5004:	ba 0c 50             	mov    dx,0x500c
    5007:	52                   	push   dx
    5008:	50                   	push   ax
    5009:	9a f4 31 3a 50       	call   0x503a:0x31f4
    500e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5011:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5014:	b8 95 4f             	mov    ax,0x4f95
    5017:	0e                   	push   cs
    5018:	50                   	push   ax
    5019:	55                   	push   bp
    501a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    501e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5022:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5025:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5028:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    502b:	26 ff b5 87 01       	push   WORD PTR es:[di+0x187]
    5030:	26 ff b5 85 01       	push   WORD PTR es:[di+0x185]
    5035:	06                   	push   es
    5036:	57                   	push   di
    5037:	9a df 54 51 50       	call   0x5051:0x54df
    503c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    503f:	26 ff b5 83 01       	push   WORD PTR es:[di+0x183]
    5044:	26 ff b5 81 01       	push   WORD PTR es:[di+0x181]
    5049:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    504c:	06                   	push   es
    504d:	57                   	push   di
    504e:	9a 4b 33 a7 50       	call   0x50a7:0x334b
    5053:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5056:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    505b:	06                   	push   es
    505c:	57                   	push   di
    505d:	9a 7f 1f 86 50       	call   0x5086:0x1f7f
    5062:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5065:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5068:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    506b:	26 89 85 81 01       	mov    WORD PTR es:[di+0x181],ax
    5070:	26 89 95 83 01       	mov    WORD PTR es:[di+0x183],dx
    5075:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5079:	83 c4 06             	add    sp,0x6
    507c:	eb 0f                	jmp    0x508d
    507e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5081:	06                   	push   es
    5082:	57                   	push   di
    5083:	9a 7f 1f 8b 50       	call   0x508b:0x1f7f
    5088:	9a 34 14 be 54       	call   0x54be:0x1434
    508d:	c9                   	leave
    508e:	ca 08 00             	retf   0x8
    5091:	55                   	push   bp
    5092:	89 e5                	mov    bp,sp
    5094:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5097:	ff 76 0a             	push   WORD PTR [bp+0xa]
    509a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    509d:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    50a2:	06                   	push   es
    50a3:	57                   	push   di
    50a4:	9a 4b 33 d3 50       	call   0x50d3:0x334b
    50a9:	c9                   	leave
    50aa:	ca 08 00             	retf   0x8
    50ad:	04 44                	add    al,0x44
    50af:	61                   	popa
    50b0:	74 61                	je     0x5113
    50b2:	55                   	push   bp
    50b3:	89 e5                	mov    bp,sp
    50b5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    50b8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    50bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50be:	06                   	push   es
    50bf:	57                   	push   di
    50c0:	9a 6e 4f 12 51       	call   0x5112:0x4f6e
    50c5:	bf ad 50             	mov    di,0x50ad
    50c8:	0e                   	push   cs
    50c9:	57                   	push   di
    50ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50cd:	06                   	push   es
    50ce:	57                   	push   di
    50cf:	bf 07 51             	mov    di,0x5107
    50d2:	b8 e0 50             	mov    ax,0x50e0
    50d5:	50                   	push   ax
    50d6:	57                   	push   di
    50d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50da:	06                   	push   es
    50db:	57                   	push   di
    50dc:	bf 48 51             	mov    di,0x5148
    50df:	b8 ca 51             	mov    ax,0x51ca
    50e2:	50                   	push   ax
    50e3:	57                   	push   di
    50e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50e7:	26 8b 85 90 01       	mov    ax,WORD PTR es:[di+0x190]
    50ec:	26 0b 85 92 01       	or     ax,WORD PTR es:[di+0x192]
    50f1:	b0 00                	mov    al,0x0
    50f3:	74 01                	je     0x50f6
    50f5:	40                   	inc    ax
    50f6:	50                   	push   ax
    50f7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    50fa:	06                   	push   es
    50fb:	57                   	push   di
    50fc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50ff:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    5103:	c9                   	leave
    5104:	ca 08 00             	retf   0x8
    5107:	55                   	push   bp
    5108:	89 e5                	mov    bp,sp
    510a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    510d:	06                   	push   es
    510e:	57                   	push   di
    510f:	9a bf 23 36 51       	call   0x5136:0x23bf
    5114:	50                   	push   ax
    5115:	9a 8f 0e 65 51       	call   0x5165:0xe8f
    511a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    511d:	26 89 85 90 01       	mov    WORD PTR es:[di+0x190],ax
    5122:	26 89 95 92 01       	mov    WORD PTR es:[di+0x192],dx
    5127:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    512c:	06                   	push   es
    512d:	57                   	push   di
    512e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5131:	06                   	push   es
    5132:	57                   	push   di
    5133:	9a bf 23 42 51       	call   0x5142:0x23bf
    5138:	52                   	push   dx
    5139:	50                   	push   ax
    513a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    513d:	06                   	push   es
    513e:	57                   	push   di
    513f:	9a 11 24 73 51       	call   0x5173:0x2411
    5144:	c9                   	leave
    5145:	ca 08 00             	retf   0x8
    5148:	55                   	push   bp
    5149:	89 e5                	mov    bp,sp
    514b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    514e:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    5153:	06                   	push   es
    5154:	57                   	push   di
    5155:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5158:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    515d:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    5162:	9a bc 0e b1 51       	call   0x51b1:0xebc
    5167:	31 d2                	xor    dx,dx
    5169:	52                   	push   dx
    516a:	50                   	push   ax
    516b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    516e:	06                   	push   es
    516f:	57                   	push   di
    5170:	9a 66 24 55 74       	call   0x7455:0x2466
    5175:	c9                   	leave
    5176:	ca 08 00             	retf   0x8
    5179:	55                   	push   bp
    517a:	89 e5                	mov    bp,sp
    517c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    517f:	26 8b 45 34          	mov    ax,WORD PTR es:[di+0x34]
    5183:	26 0b 45 36          	or     ax,WORD PTR es:[di+0x36]
    5187:	74 08                	je     0x5191
    5189:	68 04 f2             	push   0xf204
    518c:	9a ef 11 d4 51       	call   0x51d4:0x11ef
    5191:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5194:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5197:	26 3a 85 80 01       	cmp    al,BYTE PTR es:[di+0x180]
    519c:	74 4f                	je     0x51ed
    519e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    51a2:	74 34                	je     0x51d8
    51a4:	26 ff b5 87 01       	push   WORD PTR es:[di+0x187]
    51a9:	26 ff b5 85 01       	push   WORD PTR es:[di+0x185]
    51ae:	9a 8c 0c 03 54       	call   0x5403:0xc8c
    51b3:	3d 01 00             	cmp    ax,0x1
    51b6:	76 16                	jbe    0x51ce
    51b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51bb:	26 ff b5 87 01       	push   WORD PTR es:[di+0x187]
    51c0:	26 ff b5 85 01       	push   WORD PTR es:[di+0x185]
    51c5:	06                   	push   es
    51c6:	57                   	push   di
    51c7:	9a 48 5b e0 51       	call   0x51e0:0x5b48
    51cc:	eb 08                	jmp    0x51d6
    51ce:	68 29 f2             	push   0xf229
    51d1:	9a ef 11 58 52       	call   0x5258:0x11ef
    51d6:	eb 0a                	jmp    0x51e2
    51d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51db:	06                   	push   es
    51dc:	57                   	push   di
    51dd:	9a f1 51 6b 52       	call   0x526b:0x51f1
    51e2:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    51e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51e8:	26 88 85 80 01       	mov    BYTE PTR es:[di+0x180],al
    51ed:	c9                   	leave
    51ee:	ca 06 00             	retf   0x6
    51f1:	55                   	push   bp
    51f2:	89 e5                	mov    bp,sp
    51f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51f7:	26 8b 85 78 01       	mov    ax,WORD PTR es:[di+0x178]
    51fc:	26 0b 85 7a 01       	or     ax,WORD PTR es:[di+0x17a]
    5201:	74 0b                	je     0x520e
    5203:	81 c7 78 01          	add    di,0x178
    5207:	06                   	push   es
    5208:	57                   	push   di
    5209:	9a cd 06 80 57       	call   0x5780:0x6cd
    520e:	c9                   	leave
    520f:	ca 04 00             	retf   0x4
    5212:	c8 10 01 00          	enter  0x110,0x0
    5216:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5219:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    521e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5222:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    5226:	75 03                	jne    0x522b
    5228:	e9 ae 00             	jmp    0x52d9
    522b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    522e:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    5233:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    5237:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    523b:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    523f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5242:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    5245:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    5248:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    524b:	75 03                	jne    0x5250
    524d:	e9 89 00             	jmp    0x52d9
    5250:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    5253:	06                   	push   es
    5254:	57                   	push   di
    5255:	9a 02 32 bb 52       	call   0x52bb:0x3202
    525a:	08 c0                	or     al,al
    525c:	74 7b                	je     0x52d9
    525e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5261:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    5266:	06                   	push   es
    5267:	57                   	push   di
    5268:	9a b7 34 90 52       	call   0x5290:0x34b7
    526d:	48                   	dec    ax
    526e:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5271:	31 c0                	xor    ax,ax
    5273:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    5276:	7f 61                	jg     0x52d9
    5278:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    527b:	eb 03                	jmp    0x5280
    527d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    5280:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5283:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5286:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    528b:	06                   	push   es
    528c:	57                   	push   di
    528d:	9a 00 35 b1 52       	call   0x52b1:0x3500
    5292:	89 c7                	mov    di,ax
    5294:	8e c2                	mov    es,dx
    5296:	89 7e f0             	mov    WORD PTR [bp-0x10],di
    5299:	8c 46 f2             	mov    WORD PTR [bp-0xe],es
    529c:	26 80 7d 1a 00       	cmp    BYTE PTR es:[di+0x1a],0x0
    52a1:	75 2e                	jne    0x52d1
    52a3:	8d be f0 fe          	lea    di,[bp-0x110]
    52a7:	16                   	push   ss
    52a8:	57                   	push   di
    52a9:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    52ac:	06                   	push   es
    52ad:	57                   	push   di
    52ae:	9a 56 3a c7 52       	call   0x52c7:0x3a56
    52b3:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    52b6:	06                   	push   es
    52b7:	57                   	push   di
    52b8:	9a 9b 3b ef 52       	call   0x52ef:0x3b9b
    52bd:	52                   	push   dx
    52be:	50                   	push   ax
    52bf:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    52c2:	06                   	push   es
    52c3:	57                   	push   di
    52c4:	9a 90 40 e1 52       	call   0x52e1:0x4090
    52c9:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    52cc:	26 c6 45 1a 00       	mov    BYTE PTR es:[di+0x1a],0x0
    52d1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    52d4:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    52d7:	75 a4                	jne    0x527d
    52d9:	c9                   	leave
    52da:	ca 04 00             	retf   0x4
    52dd:	00 00                	add    BYTE PTR [bx+si],al
    52df:	6b 53 4d 54          	imul   dx,WORD PTR [bp+di+0x4d],0x54
    52e3:	c8 04 00 00          	enter  0x4,0x0
    52e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52ea:	06                   	push   es
    52eb:	57                   	push   di
    52ec:	9a 41 44 3b 53       	call   0x533b:0x4441
    52f1:	b8 dd 52             	mov    ax,0x52dd
    52f4:	0e                   	push   cs
    52f5:	50                   	push   ax
    52f6:	55                   	push   bp
    52f7:	ff 36 58 18          	push   WORD PTR ds:0x1858
    52fb:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    52ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5302:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    5307:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    530b:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    530f:	74 4e                	je     0x535f
    5311:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5314:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    5319:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    531d:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    5321:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    5325:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5328:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    532b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    532e:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    5331:	74 2c                	je     0x535f
    5333:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5336:	06                   	push   es
    5337:	57                   	push   di
    5338:	9a 02 32 53 53       	call   0x5353:0x3202
    533d:	08 c0                	or     al,al
    533f:	74 1e                	je     0x535f
    5341:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5344:	26 80 7d 3a 04       	cmp    BYTE PTR es:[di+0x3a],0x4
    5349:	74 14                	je     0x535f
    534b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    534e:	06                   	push   es
    534f:	57                   	push   di
    5350:	9a d2 31 5d 53       	call   0x535d:0x31d2
    5355:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5358:	06                   	push   es
    5359:	57                   	push   di
    535a:	9a bf 31 73 53       	call   0x5373:0x31bf
    535f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5363:	83 c4 06             	add    sp,0x6
    5366:	b8 76 53             	mov    ax,0x5376
    5369:	0e                   	push   cs
    536a:	50                   	push   ax
    536b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    536e:	06                   	push   es
    536f:	57                   	push   di
    5370:	9a 66 44 86 57       	call   0x5786:0x4466
    5375:	cb                   	retf
    5376:	c9                   	leave
    5377:	ca 04 00             	retf   0x4
    537a:	c8 02 00 00          	enter  0x2,0x0
    537e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5381:	36 8a 45 f5          	mov    al,BYTE PTR ss:[di-0xb]
    5385:	3c 0a                	cmp    al,0xa
    5387:	74 18                	je     0x53a1
    5389:	3c 0d                	cmp    al,0xd
    538b:	74 14                	je     0x53a1
    538d:	3c 20                	cmp    al,0x20
    538f:	74 10                	je     0x53a1
    5391:	3c 29                	cmp    al,0x29
    5393:	74 0c                	je     0x53a1
    5395:	3c 2c                	cmp    al,0x2c
    5397:	74 08                	je     0x53a1
    5399:	3c 3b                	cmp    al,0x3b
    539b:	74 04                	je     0x53a1
    539d:	b0 00                	mov    al,0x0
    539f:	eb 02                	jmp    0x53a3
    53a1:	b0 01                	mov    al,0x1
    53a3:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    53a6:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    53a9:	c9                   	leave
    53aa:	c2 02 00             	ret    0x2
    53ad:	c8 02 00 00          	enter  0x2,0x0
    53b1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    53b4:	36 8a 45 f5          	mov    al,BYTE PTR ss:[di-0xb]
    53b8:	3c 22                	cmp    al,0x22
    53ba:	74 08                	je     0x53c4
    53bc:	3c 27                	cmp    al,0x27
    53be:	74 04                	je     0x53c4
    53c0:	b0 00                	mov    al,0x0
    53c2:	eb 02                	jmp    0x53c6
    53c4:	b0 01                	mov    al,0x1
    53c6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    53c9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    53cc:	c9                   	leave
    53cd:	c2 02 00             	ret    0x2
    53d0:	55                   	push   bp
    53d1:	89 e5                	mov    bp,sp
    53d3:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    53d6:	36 c4 7d fa          	les    di,DWORD PTR ss:[di-0x6]
    53da:	26 8a 05             	mov    al,BYTE PTR es:[di]
    53dd:	3a 46 06             	cmp    al,BYTE PTR [bp+0x6]
    53e0:	75 23                	jne    0x5405
    53e2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    53e5:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    53e9:	36 ff 75 fa          	push   WORD PTR ss:[di-0x6]
    53ed:	36 8b 45 fa          	mov    ax,WORD PTR ss:[di-0x6]
    53f1:	36 8b 55 fc          	mov    dx,WORD PTR ss:[di-0x4]
    53f5:	05 01 00             	add    ax,0x1
    53f8:	52                   	push   dx
    53f9:	50                   	push   ax
    53fa:	36 8b 45 fe          	mov    ax,WORD PTR ss:[di-0x2]
    53fe:	48                   	dec    ax
    53ff:	50                   	push   ax
    5400:	9a ba 0c 13 54       	call   0x5413:0xcba
    5405:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5408:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    540c:	36 ff 75 fa          	push   WORD PTR ss:[di-0x6]
    5410:	9a 8c 0c 35 54       	call   0x5435:0xc8c
    5415:	48                   	dec    ax
    5416:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    5419:	36 c4 7d fa          	les    di,DWORD PTR ss:[di-0x6]
    541d:	03 f8                	add    di,ax
    541f:	26 8a 05             	mov    al,BYTE PTR es:[di]
    5422:	3a 46 06             	cmp    al,BYTE PTR [bp+0x6]
    5425:	75 1e                	jne    0x5445
    5427:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    542a:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    542e:	36 ff 75 fa          	push   WORD PTR ss:[di-0x6]
    5432:	9a 8c 0c 5c 54       	call   0x545c:0xc8c
    5437:	48                   	dec    ax
    5438:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    543b:	36 c4 7d fa          	les    di,DWORD PTR ss:[di-0x6]
    543f:	03 f8                	add    di,ax
    5441:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    5445:	c9                   	leave
    5446:	c2 04 00             	ret    0x4
    5449:	00 00                	add    BYTE PTR [bx+si],al
    544b:	cc                   	int3
    544c:	54                   	push   sp
    544d:	f8                   	clc
    544e:	55                   	push   bp
    544f:	c8 06 01 00          	enter  0x106,0x0
    5453:	ff 76 08             	push   WORD PTR [bp+0x8]
    5456:	ff 76 06             	push   WORD PTR [bp+0x6]
    5459:	9a 8c 0c 68 54       	call   0x5468:0xc8c
    545e:	40                   	inc    ax
    545f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5462:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5465:	9a 76 04 94 54       	call   0x5494:0x476
    546a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    546d:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    5470:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5473:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    5477:	b8 49 54             	mov    ax,0x5449
    547a:	0e                   	push   cs
    547b:	50                   	push   ax
    547c:	55                   	push   bp
    547d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5481:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5485:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5488:	ff 76 fa             	push   WORD PTR [bp-0x6]
    548b:	ff 76 08             	push   WORD PTR [bp+0x8]
    548e:	ff 76 06             	push   WORD PTR [bp+0x6]
    5491:	9a df 0c b1 54       	call   0x54b1:0xcdf
    5496:	6a 27                	push   0x27
    5498:	55                   	push   bp
    5499:	e8 34 ff             	call   0x53d0
    549c:	6a 22                	push   0x22
    549e:	55                   	push   bp
    549f:	e8 2e ff             	call   0x53d0
    54a2:	8d be fa fe          	lea    di,[bp-0x106]
    54a6:	16                   	push   ss
    54a7:	57                   	push   di
    54a8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    54ab:	ff 76 fa             	push   WORD PTR [bp-0x6]
    54ae:	9a 6e 0e ec 54       	call   0x54ec:0xe6e
    54b3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    54b6:	06                   	push   es
    54b7:	57                   	push   di
    54b8:	68 ff 00             	push   0xff
    54bb:	9a e7 17 d8 54       	call   0x54d8:0x17e7
    54c0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    54c4:	83 c4 06             	add    sp,0x6
    54c7:	b8 db 54             	mov    ax,0x54db
    54ca:	0e                   	push   cs
    54cb:	50                   	push   ax
    54cc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    54cf:	ff 76 fa             	push   WORD PTR [bp-0x6]
    54d2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    54d5:	9a 9c 01 ba 55       	call   0x55ba:0x19c
    54da:	cb                   	retf
    54db:	c9                   	leave
    54dc:	c2 06 00             	ret    0x6
    54df:	c8 0e 02 00          	enter  0x20e,0x0
    54e3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    54e6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    54e9:	9a 8c 0c d6 55       	call   0x55d6:0xc8c
    54ee:	40                   	inc    ax
    54ef:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    54f2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    54f5:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    54f8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    54fb:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    54fe:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    5502:	c6 46 f3 00          	mov    BYTE PTR [bp-0xd],0x0
    5506:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5509:	26 8a 05             	mov    al,BYTE PTR es:[di]
    550c:	88 46 f5             	mov    BYTE PTR [bp-0xb],al
    550f:	80 7e f5 3a          	cmp    BYTE PTR [bp-0xb],0x3a
    5513:	74 03                	je     0x5518
    5515:	e9 21 01             	jmp    0x5639
    5518:	80 7e f4 00          	cmp    BYTE PTR [bp-0xc],0x0
    551c:	74 03                	je     0x5521
    551e:	e9 18 01             	jmp    0x5639
    5521:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5524:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5527:	05 01 00             	add    ax,0x1
    552a:	89 c7                	mov    di,ax
    552c:	8e c2                	mov    es,dx
    552e:	26 80 3d 3a          	cmp    BYTE PTR es:[di],0x3a
    5532:	75 03                	jne    0x5537
    5534:	e9 02 01             	jmp    0x5639
    5537:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    553a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    553d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5540:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    5543:	80 7e f5 00          	cmp    BYTE PTR [bp-0xb],0x0
    5547:	74 43                	je     0x558c
    5549:	80 7e f4 00          	cmp    BYTE PTR [bp-0xc],0x0
    554d:	75 08                	jne    0x5557
    554f:	55                   	push   bp
    5550:	e8 27 fe             	call   0x537a
    5553:	08 c0                	or     al,al
    5555:	75 35                	jne    0x558c
    5557:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    555a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    555d:	26 8a 05             	mov    al,BYTE PTR es:[di]
    5560:	88 46 f5             	mov    BYTE PTR [bp-0xb],al
    5563:	55                   	push   bp
    5564:	e8 46 fe             	call   0x53ad
    5567:	08 c0                	or     al,al
    5569:	74 1f                	je     0x558a
    556b:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
    556e:	34 01                	xor    al,0x1
    5570:	88 46 f4             	mov    BYTE PTR [bp-0xc],al
    5573:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    5576:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    5579:	05 01 00             	add    ax,0x1
    557c:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    557f:	75 09                	jne    0x558a
    5581:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    5584:	75 04                	jne    0x558a
    5586:	c6 46 f3 01          	mov    BYTE PTR [bp-0xd],0x1
    558a:	eb b7                	jmp    0x5543
    558c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    558f:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    5593:	80 7e f3 00          	cmp    BYTE PTR [bp-0xd],0x0
    5597:	74 29                	je     0x55c2
    5599:	8d be f2 fd          	lea    di,[bp-0x20e]
    559d:	16                   	push   ss
    559e:	57                   	push   di
    559f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    55a2:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    55a5:	05 01 00             	add    ax,0x1
    55a8:	52                   	push   dx
    55a9:	50                   	push   ax
    55aa:	55                   	push   bp
    55ab:	e8 a1 fe             	call   0x544f
    55ae:	8d be f2 fe          	lea    di,[bp-0x10e]
    55b2:	16                   	push   ss
    55b3:	57                   	push   di
    55b4:	68 ff 00             	push   0xff
    55b7:	9a e7 17 e4 55       	call   0x55e4:0x17e7
    55bc:	c6 46 f3 00          	mov    BYTE PTR [bp-0xd],0x0
    55c0:	eb 24                	jmp    0x55e6
    55c2:	8d be f2 fd          	lea    di,[bp-0x20e]
    55c6:	16                   	push   ss
    55c7:	57                   	push   di
    55c8:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    55cb:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    55ce:	05 01 00             	add    ax,0x1
    55d1:	52                   	push   dx
    55d2:	50                   	push   ax
    55d3:	9a 6e 0e 22 56       	call   0x5622:0xe6e
    55d8:	8d be f2 fe          	lea    di,[bp-0x10e]
    55dc:	16                   	push   ss
    55dd:	57                   	push   di
    55de:	68 ff 00             	push   0xff
    55e1:	9a e7 17 4e 5a       	call   0x5a4e:0x17e7
    55e6:	6a 00                	push   0x0
    55e8:	8d be f2 fe          	lea    di,[bp-0x10e]
    55ec:	16                   	push   ss
    55ed:	57                   	push   di
    55ee:	6a 00                	push   0x0
    55f0:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    55f3:	06                   	push   es
    55f4:	57                   	push   di
    55f5:	9a 63 34 c0 56       	call   0x56c0:0x3463
    55fa:	8a 46 f5             	mov    al,BYTE PTR [bp-0xb]
    55fd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5600:	26 88 05             	mov    BYTE PTR es:[di],al
    5603:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    5606:	26 c6 05 3f          	mov    BYTE PTR es:[di],0x3f
    560a:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    560d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5610:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5613:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5616:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5619:	ff 76 fe             	push   WORD PTR [bp-0x2]
    561c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    561f:	9a 8c 0c 29 56       	call   0x5629:0xc8c
    5624:	40                   	inc    ax
    5625:	50                   	push   ax
    5626:	9a ba 0c 72 56       	call   0x5672:0xcba
    562b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    562e:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    5631:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5634:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5637:	eb 54                	jmp    0x568d
    5639:	80 7e f5 3a          	cmp    BYTE PTR [bp-0xb],0x3a
    563d:	75 3e                	jne    0x567d
    563f:	80 7e f4 00          	cmp    BYTE PTR [bp-0xc],0x0
    5643:	75 38                	jne    0x567d
    5645:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5648:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    564b:	05 01 00             	add    ax,0x1
    564e:	89 c7                	mov    di,ax
    5650:	8e c2                	mov    es,dx
    5652:	26 80 3d 3a          	cmp    BYTE PTR es:[di],0x3a
    5656:	75 25                	jne    0x567d
    5658:	ff 76 fe             	push   WORD PTR [bp-0x2]
    565b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    565e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5661:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5664:	05 01 00             	add    ax,0x1
    5667:	52                   	push   dx
    5668:	50                   	push   ax
    5669:	ff 76 fe             	push   WORD PTR [bp-0x2]
    566c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    566f:	9a 8c 0c 79 56       	call   0x5679:0xc8c
    5674:	40                   	inc    ax
    5675:	50                   	push   ax
    5676:	9a ba 0c b8 57       	call   0x57b8:0xcba
    567b:	eb 10                	jmp    0x568d
    567d:	55                   	push   bp
    567e:	e8 2c fd             	call   0x53ad
    5681:	08 c0                	or     al,al
    5683:	74 08                	je     0x568d
    5685:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
    5688:	34 01                	xor    al,0x1
    568a:	88 46 f4             	mov    BYTE PTR [bp-0xc],al
    568d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    5690:	80 7e f5 00          	cmp    BYTE PTR [bp-0xb],0x0
    5694:	74 03                	je     0x5699
    5696:	e9 6d fe             	jmp    0x5506
    5699:	c9                   	leave
    569a:	ca 0c 00             	retf   0xc
    569d:	c8 04 00 00          	enter  0x4,0x0
    56a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56a4:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    56a9:	06                   	push   es
    56aa:	57                   	push   di
    56ab:	26 c4 3d             	les    di,DWORD PTR es:[di]
    56ae:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    56b2:	09 c0                	or     ax,ax
    56b4:	7e 3e                	jle    0x56f4
    56b6:	6a 01                	push   0x1
    56b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56bb:	06                   	push   es
    56bc:	57                   	push   di
    56bd:	9a 79 51 dc 56       	call   0x56dc:0x5179
    56c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56c5:	26 c4 bd 89 01       	les    di,DWORD PTR es:[di+0x189]
    56ca:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    56ce:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    56d2:	74 0a                	je     0x56de
    56d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56d7:	06                   	push   es
    56d8:	57                   	push   di
    56d9:	9a 12 52 ea 56       	call   0x56ea:0x5212
    56de:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    56e1:	50                   	push   ax
    56e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56e5:	06                   	push   es
    56e6:	57                   	push   di
    56e7:	9a 26 57 14 57       	call   0x5714:0x5726
    56ec:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    56ef:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    56f2:	eb 08                	jmp    0x56fc
    56f4:	31 c0                	xor    ax,ax
    56f6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    56f9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    56fc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    56ff:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5702:	c9                   	leave
    5703:	ca 06 00             	retf   0x6
    5706:	c8 04 00 00          	enter  0x4,0x0
    570a:	6a 01                	push   0x1
    570c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    570f:	06                   	push   es
    5710:	57                   	push   di
    5711:	9a 9d 56 5a 57       	call   0x575a:0x569d
    5716:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5719:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    571c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    571f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5722:	c9                   	leave
    5723:	ca 04 00             	retf   0x4
    5726:	c8 26 01 00          	enter  0x126,0x0
    572a:	31 c0                	xor    ax,ax
    572c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    572f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5732:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5736:	74 0d                	je     0x5745
    5738:	8d 46 fc             	lea    ax,[bp-0x4]
    573b:	8c d2                	mov    dx,ss
    573d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5740:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    5743:	eb 08                	jmp    0x574d
    5745:	31 c0                	xor    ax,ax
    5747:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    574a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    574d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5750:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    5755:	06                   	push   es
    5756:	57                   	push   di
    5757:	9a b7 34 68 57       	call   0x5768:0x34b7
    575c:	09 c0                	or     ax,ax
    575e:	7e 0a                	jle    0x576a
    5760:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5763:	06                   	push   es
    5764:	57                   	push   di
    5765:	9a 9e 57 96 57       	call   0x5796:0x579e
    576a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    576d:	26 ff b5 7a 01       	push   WORD PTR es:[di+0x17a]
    5772:	26 ff b5 78 01       	push   WORD PTR es:[di+0x178]
    5777:	ff 76 fa             	push   WORD PTR [bp-0x6]
    577a:	ff 76 f8             	push   WORD PTR [bp-0x8]
    577d:	9a 9d 06 fd 57       	call   0x57fd:0x69d
    5782:	50                   	push   ax
    5783:	9a 4e 12 4e 59       	call   0x594e:0x124e
    5788:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    578b:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    578e:	c9                   	leave
    578f:	ca 06 00             	retf   0x6
    5792:	00 00                	add    BYTE PTR [bx+si],al
    5794:	42                   	inc    dx
    5795:	5a                   	pop    dx
    5796:	9c                   	pushf
    5797:	57                   	push   di
    5798:	00 00                	add    BYTE PTR [bx+si],al
    579a:	5d                   	pop    bp
    579b:	5a                   	pop    dx
    579c:	af                   	scas   ax,WORD PTR es:[di]
    579d:	57                   	push   di
    579e:	c8 52 01 00          	enter  0x152,0x0
    57a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57a5:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    57aa:	06                   	push   es
    57ab:	57                   	push   di
    57ac:	9a b7 34 37 58       	call   0x5837:0x34b7
    57b1:	6b c0 34             	imul   ax,ax,0x34
    57b4:	50                   	push   ax
    57b5:	9a 76 04 07 58       	call   0x5807:0x476
    57ba:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    57bd:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    57c0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    57c3:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    57c6:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    57c9:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    57cc:	c7 46 f8 02 00       	mov    WORD PTR [bp-0x8],0x2
    57d1:	c6 46 c0 00          	mov    BYTE PTR [bp-0x40],0x0
    57d5:	31 c0                	xor    ax,ax
    57d7:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    57da:	89 46 be             	mov    WORD PTR [bp-0x42],ax
    57dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57e0:	26 ff b5 7a 01       	push   WORD PTR es:[di+0x17a]
    57e5:	26 ff b5 78 01       	push   WORD PTR es:[di+0x178]
    57ea:	6a 06                	push   0x6
    57ec:	6a 04                	push   0x4
    57ee:	8d 7e c0             	lea    di,[bp-0x40]
    57f1:	16                   	push   ss
    57f2:	57                   	push   di
    57f3:	6a 20                	push   0x20
    57f5:	8d 7e f8             	lea    di,[bp-0x8]
    57f8:	16                   	push   ss
    57f9:	57                   	push   di
    57fa:	9a ad 21 1a 58       	call   0x581a:0x21ad
    57ff:	8d 7e c0             	lea    di,[bp-0x40]
    5802:	16                   	push   ss
    5803:	57                   	push   di
    5804:	9a 8c 0c 7a 58       	call   0x587a:0xc8c
    5809:	09 c0                	or     ax,ax
    580b:	76 0f                	jbe    0x581c
    580d:	8d 7e c0             	lea    di,[bp-0x40]
    5810:	16                   	push   ss
    5811:	57                   	push   di
    5812:	8d 7e bc             	lea    di,[bp-0x44]
    5815:	16                   	push   ss
    5816:	57                   	push   di
    5817:	9a ad 13 2e 5a       	call   0x5a2e:0x13ad
    581c:	b8 98 57             	mov    ax,0x5798
    581f:	0e                   	push   cs
    5820:	50                   	push   ax
    5821:	55                   	push   bp
    5822:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5826:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    582a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    582d:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    5832:	06                   	push   es
    5833:	57                   	push   di
    5834:	9a b7 34 5c 58       	call   0x585c:0x34b7
    5839:	48                   	dec    ax
    583a:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    583d:	31 c0                	xor    ax,ax
    583f:	3b 46 ba             	cmp    ax,WORD PTR [bp-0x46]
    5842:	7f 30                	jg     0x5874
    5844:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5847:	eb 03                	jmp    0x584c
    5849:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    584c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    584f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5852:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    5857:	06                   	push   es
    5858:	57                   	push   di
    5859:	9a 00 35 67 58       	call   0x5867:0x3500
    585e:	89 c7                	mov    di,ax
    5860:	8e c2                	mov    es,dx
    5862:	06                   	push   es
    5863:	57                   	push   di
    5864:	9a 8b 3a c3 58       	call   0x58c3:0x3a8b
    5869:	01 46 f8             	add    WORD PTR [bp-0x8],ax
    586c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    586f:	3b 46 ba             	cmp    ax,WORD PTR [bp-0x46]
    5872:	75 d5                	jne    0x5849
    5874:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5877:	9a 76 04 39 5d       	call   0x5d39:0x476
    587c:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    587f:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    5882:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    5885:	8b 56 ee             	mov    dx,WORD PTR [bp-0x12]
    5888:	03 46 f8             	add    ax,WORD PTR [bp-0x8]
    588b:	2d 02 00             	sub    ax,0x2
    588e:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    5891:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    5894:	c4 7e e0             	les    di,DWORD PTR [bp-0x20]
    5897:	26 c7 05 ff ff       	mov    WORD PTR es:[di],0xffff
    589c:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    589f:	8b 56 ee             	mov    dx,WORD PTR [bp-0x12]
    58a2:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    58a5:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    58a8:	b8 92 57             	mov    ax,0x5792
    58ab:	0e                   	push   cs
    58ac:	50                   	push   ax
    58ad:	55                   	push   bp
    58ae:	ff 36 58 18          	push   WORD PTR ds:0x1858
    58b2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    58b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58b9:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    58be:	06                   	push   es
    58bf:	57                   	push   di
    58c0:	9a b7 34 eb 58       	call   0x58eb:0x34b7
    58c5:	48                   	dec    ax
    58c6:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    58c9:	31 c0                	xor    ax,ax
    58cb:	3b 46 ba             	cmp    ax,WORD PTR [bp-0x46]
    58ce:	7e 03                	jle    0x58d3
    58d0:	e9 32 01             	jmp    0x5a05
    58d3:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    58d6:	eb 03                	jmp    0x58db
    58d8:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    58db:	ff 76 fa             	push   WORD PTR [bp-0x6]
    58de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58e1:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    58e6:	06                   	push   es
    58e7:	57                   	push   di
    58e8:	9a 00 35 2b 59       	call   0x592b:0x3500
    58ed:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    58f0:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    58f3:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    58f6:	89 7e b6             	mov    WORD PTR [bp-0x4a],di
    58f9:	8c 46 b8             	mov    WORD PTR [bp-0x48],es
    58fc:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    58ff:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    5903:	98                   	cbw
    5904:	8b f8                	mov    di,ax
    5906:	8a 85 ac 0b          	mov    al,BYTE PTR [di+0xbac]
    590a:	30 e4                	xor    ah,ah
    590c:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    590f:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    5913:	26 83 7d 22 00       	cmp    WORD PTR es:[di+0x22],0x0
    5918:	75 36                	jne    0x5950
    591a:	68 2a f2             	push   0xf22a
    591d:	8d be b6 fe          	lea    di,[bp-0x14a]
    5921:	16                   	push   ss
    5922:	57                   	push   di
    5923:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    5926:	06                   	push   es
    5927:	57                   	push   di
    5928:	9a 56 3a 62 59       	call   0x5962:0x3a56
    592d:	83 c4 04             	add    sp,0x4
    5930:	8d 86 b6 fe          	lea    ax,[bp-0x14a]
    5934:	8c d2                	mov    dx,ss
    5936:	89 86 ae fe          	mov    WORD PTR [bp-0x152],ax
    593a:	89 96 b0 fe          	mov    WORD PTR [bp-0x150],dx
    593e:	c6 86 b2 fe 04       	mov    BYTE PTR [bp-0x14e],0x4
    5943:	8d be ae fe          	lea    di,[bp-0x152]
    5947:	16                   	push   ss
    5948:	57                   	push   di
    5949:	6a 00                	push   0x0
    594b:	9a 0a 12 e7 59       	call   0x59e7:0x120a
    5950:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    5953:	40                   	inc    ax
    5954:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    5957:	26 89 05             	mov    WORD PTR es:[di],ax
    595a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    595d:	06                   	push   es
    595e:	57                   	push   di
    595f:	9a 8b 3a b3 59       	call   0x59b3:0x3a8b
    5964:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    5967:	26 89 45 2c          	mov    WORD PTR es:[di+0x2c],ax
    596b:	26 83 7d 22 01       	cmp    WORD PTR es:[di+0x22],0x1
    5970:	75 09                	jne    0x597b
    5972:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    5976:	48                   	dec    ax
    5977:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    597b:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    597e:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    5981:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    5984:	26 89 45 2a          	mov    WORD PTR es:[di+0x2a],ax
    5988:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    598b:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    5990:	74 0d                	je     0x599f
    5992:	8b 46 e0             	mov    ax,WORD PTR [bp-0x20]
    5995:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    5998:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    599b:	26 89 45 2e          	mov    WORD PTR es:[di+0x2e],ax
    599f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    59a2:	89 7e b6             	mov    WORD PTR [bp-0x4a],di
    59a5:	8c 46 b8             	mov    WORD PTR [bp-0x48],es
    59a8:	ff 76 ea             	push   WORD PTR [bp-0x16]
    59ab:	ff 76 e8             	push   WORD PTR [bp-0x18]
    59ae:	06                   	push   es
    59af:	57                   	push   di
    59b0:	9a 46 3b e1 59       	call   0x59e1:0x3b46
    59b5:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    59b8:	26 83 7d 22 01       	cmp    WORD PTR es:[di+0x22],0x1
    59bd:	75 2a                	jne    0x59e9
    59bf:	8b 46 bc             	mov    ax,WORD PTR [bp-0x44]
    59c2:	0b 46 be             	or     ax,WORD PTR [bp-0x42]
    59c5:	74 22                	je     0x59e9
    59c7:	ff 76 be             	push   WORD PTR [bp-0x42]
    59ca:	ff 76 bc             	push   WORD PTR [bp-0x44]
    59cd:	ff 76 ea             	push   WORD PTR [bp-0x16]
    59d0:	ff 76 e8             	push   WORD PTR [bp-0x18]
    59d3:	ff 76 ea             	push   WORD PTR [bp-0x16]
    59d6:	ff 76 e8             	push   WORD PTR [bp-0x18]
    59d9:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    59dc:	06                   	push   es
    59dd:	57                   	push   di
    59de:	9a 8b 3a f1 59       	call   0x59f1:0x3a8b
    59e3:	50                   	push   ax
    59e4:	9a 5d 0f 34 5a       	call   0x5a34:0xf5d
    59e9:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    59ec:	06                   	push   es
    59ed:	57                   	push   di
    59ee:	9a 8b 3a 1c 5a       	call   0x5a1c:0x3a8b
    59f3:	01 46 e8             	add    WORD PTR [bp-0x18],ax
    59f6:	83 46 f0 34          	add    WORD PTR [bp-0x10],0x34
    59fa:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    59fd:	3b 46 ba             	cmp    ax,WORD PTR [bp-0x46]
    5a00:	74 03                	je     0x5a05
    5a02:	e9 d3 fe             	jmp    0x58d8
    5a05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a08:	26 ff b5 7a 01       	push   WORD PTR es:[di+0x17a]
    5a0d:	26 ff b5 78 01       	push   WORD PTR es:[di+0x178]
    5a12:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    5a17:	06                   	push   es
    5a18:	57                   	push   di
    5a19:	9a b7 34 70 5a       	call   0x5a70:0x34b7
    5a1e:	50                   	push   ax
    5a1f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5a22:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5a25:	ff 76 ee             	push   WORD PTR [bp-0x12]
    5a28:	ff 76 ec             	push   WORD PTR [bp-0x14]
    5a2b:	9a ad 06 8b 5a       	call   0x5a8b:0x6ad
    5a30:	50                   	push   ax
    5a31:	9a 4e 12 b9 5a       	call   0x5ab9:0x124e
    5a36:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5a3a:	83 c4 06             	add    sp,0x6
    5a3d:	b8 51 5a             	mov    ax,0x5a51
    5a40:	0e                   	push   cs
    5a41:	50                   	push   ax
    5a42:	ff 76 ee             	push   WORD PTR [bp-0x12]
    5a45:	ff 76 ec             	push   WORD PTR [bp-0x14]
    5a48:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5a4b:	9a 9c 01 79 5a       	call   0x5a79:0x19c
    5a50:	cb                   	retf
    5a51:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5a55:	83 c4 06             	add    sp,0x6
    5a58:	b8 8e 5a             	mov    ax,0x5a8e
    5a5b:	0e                   	push   cs
    5a5c:	50                   	push   ax
    5a5d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5a60:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5a63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a66:	26 c4 bd 81 01       	les    di,DWORD PTR es:[di+0x181]
    5a6b:	06                   	push   es
    5a6c:	57                   	push   di
    5a6d:	9a b7 34 31 5b       	call   0x5b31:0x34b7
    5a72:	6b c0 34             	imul   ax,ax,0x34
    5a75:	50                   	push   ax
    5a76:	9a 9c 01 f8 5a       	call   0x5af8:0x19c
    5a7b:	8b 46 bc             	mov    ax,WORD PTR [bp-0x44]
    5a7e:	0b 46 be             	or     ax,WORD PTR [bp-0x42]
    5a81:	74 0a                	je     0x5a8d
    5a83:	8d 7e bc             	lea    di,[bp-0x44]
    5a86:	16                   	push   ss
    5a87:	57                   	push   di
    5a88:	9a dd 14 80 5b       	call   0x5b80:0x14dd
    5a8d:	cb                   	retf
    5a8e:	c9                   	leave
    5a8f:	ca 04 00             	retf   0x4
    5a92:	c8 62 00 00          	enter  0x62,0x0
    5a96:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5a9a:	74 4c                	je     0x5ae8
    5a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a9f:	26 83 bd 20 01 00    	cmp    WORD PTR es:[di+0x120],0x0
    5aa5:	b0 00                	mov    al,0x0
    5aa7:	75 01                	jne    0x5aaa
    5aa9:	40                   	inc    ax
    5aaa:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5aad:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5ab0:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5ab3:	50                   	push   ax
    5ab4:	06                   	push   es
    5ab5:	57                   	push   di
    5ab6:	9a 07 5e d5 5a       	call   0x5ad5:0x5e07
    5abb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5abe:	26 f6 45 18 02       	test   BYTE PTR es:[di+0x18],0x2
    5ac3:	75 21                	jne    0x5ae6
    5ac5:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    5ac9:	74 1b                	je     0x5ae6
    5acb:	26 c4 bd 24 01       	les    di,DWORD PTR es:[di+0x124]
    5ad0:	06                   	push   es
    5ad1:	57                   	push   di
    5ad2:	9a 7a 21 42 5b       	call   0x5b42:0x217a
    5ad7:	08 c0                	or     al,al
    5ad9:	b0 00                	mov    al,0x0
    5adb:	75 01                	jne    0x5ade
    5add:	40                   	inc    ax
    5ade:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ae1:	26 88 85 8d 01       	mov    BYTE PTR es:[di+0x18d],al
    5ae6:	eb 5c                	jmp    0x5b44
    5ae8:	8d 7e be             	lea    di,[bp-0x42]
    5aeb:	16                   	push   ss
    5aec:	57                   	push   di
    5aed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5af0:	26 ff b5 20 01       	push   WORD PTR es:[di+0x120]
    5af5:	9a 0e 1a 04 5b       	call   0x5b04:0x1a0e
    5afa:	8d 7e de             	lea    di,[bp-0x22]
    5afd:	16                   	push   ss
    5afe:	57                   	push   di
    5aff:	6a 00                	push   0x0
    5b01:	9a 0e 1a 0d 5b       	call   0x5b0d:0x1a0e
    5b06:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
    5b09:	50                   	push   ax
    5b0a:	9a 24 1a 12 5b       	call   0x5b12:0x1a24
    5b0f:	9a d5 1a 1e 5b       	call   0x5b1e:0x1ad5
    5b14:	8d 7e 9e             	lea    di,[bp-0x62]
    5b17:	16                   	push   ss
    5b18:	57                   	push   di
    5b19:	6a 00                	push   0x0
    5b1b:	9a 0e 1a 23 5b       	call   0x5b23:0x1a0e
    5b20:	9a 0f 1b 89 5c       	call   0x5c89:0x1b0f
    5b25:	75 0c                	jne    0x5b33
    5b27:	6a 00                	push   0x0
    5b29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b2c:	06                   	push   es
    5b2d:	57                   	push   di
    5b2e:	9a 79 51 59 5b       	call   0x5b59:0x5179
    5b33:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5b36:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5b39:	50                   	push   ax
    5b3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b3d:	06                   	push   es
    5b3e:	57                   	push   di
    5b3f:	9a 07 5e 86 5b       	call   0x5b86:0x5e07
    5b44:	c9                   	leave
    5b45:	ca 08 00             	retf   0x8
    5b48:	55                   	push   bp
    5b49:	89 e5                	mov    bp,sp
    5b4b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5b4e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5b51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b54:	06                   	push   es
    5b55:	57                   	push   di
    5b56:	9a 8c 5b 91 61       	call   0x6191:0x5b8c
    5b5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b5e:	26 80 bd 8d 01 00    	cmp    BYTE PTR es:[di+0x18d],0x0
    5b64:	75 22                	jne    0x5b88
    5b66:	26 ff b5 7a 01       	push   WORD PTR es:[di+0x17a]
    5b6b:	26 ff b5 78 01       	push   WORD PTR es:[di+0x178]
    5b70:	6a 06                	push   0x6
    5b72:	6a 10                	push   0x10
    5b74:	26 8a 85 8e 01       	mov    al,BYTE PTR es:[di+0x18e]
    5b79:	98                   	cbw
    5b7a:	99                   	cwd
    5b7b:	52                   	push   dx
    5b7c:	50                   	push   ax
    5b7d:	9a bd 21 bd 5b       	call   0x5bbd:0x21bd
    5b82:	50                   	push   ax
    5b83:	9a 4e 12 a5 5b       	call   0x5ba5:0x124e
    5b88:	c9                   	leave
    5b89:	ca 08 00             	retf   0x8
    5b8c:	55                   	push   bp
    5b8d:	89 e5                	mov    bp,sp
    5b8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b92:	26 80 bd 8d 01 00    	cmp    BYTE PTR es:[di+0x18d],0x0
    5b98:	75 03                	jne    0x5b9d
    5b9a:	e9 7d 00             	jmp    0x5c1a
    5b9d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ba0:	06                   	push   es
    5ba1:	57                   	push   di
    5ba2:	9a 2b 5f f6 5b       	call   0x5bf6:0x5f2b
    5ba7:	52                   	push   dx
    5ba8:	50                   	push   ax
    5ba9:	6a 02                	push   0x2
    5bab:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5bae:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5bb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bb4:	81 c7 78 01          	add    di,0x178
    5bb8:	06                   	push   es
    5bb9:	57                   	push   di
    5bba:	9a 8d 06 f0 5b       	call   0x5bf0:0x68d
    5bbf:	50                   	push   ax
    5bc0:	e8 41 ba             	call   0x1604
    5bc3:	08 c0                	or     al,al
    5bc5:	75 02                	jne    0x5bc9
    5bc7:	eb d4                	jmp    0x5b9d
    5bc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bcc:	26 ff b5 7a 01       	push   WORD PTR es:[di+0x17a]
    5bd1:	26 ff b5 78 01       	push   WORD PTR es:[di+0x178]
    5bd6:	6a 06                	push   0x6
    5bd8:	6a 21                	push   0x21
    5bda:	26 8a 85 8f 01       	mov    al,BYTE PTR es:[di+0x18f]
    5bdf:	98                   	cbw
    5be0:	8b f8                	mov    di,ax
    5be2:	c1 e7 02             	shl    di,0x2
    5be5:	ff b5 c0 0b          	push   WORD PTR [di+0xbc0]
    5be9:	ff b5 be 0b          	push   WORD PTR [di+0xbbe]
    5bed:	9a bd 21 10 5c       	call   0x5c10:0x21bd
    5bf2:	50                   	push   ax
    5bf3:	9a 4e 12 16 5c       	call   0x5c16:0x124e
    5bf8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bfb:	26 ff b5 7a 01       	push   WORD PTR es:[di+0x17a]
    5c00:	26 ff b5 78 01       	push   WORD PTR es:[di+0x178]
    5c05:	6a 06                	push   0x6
    5c07:	6a 26                	push   0x26
    5c09:	6a 00                	push   0x0
    5c0b:	6a 00                	push   0x0
    5c0d:	9a bd 21 44 5c       	call   0x5c44:0x21bd
    5c12:	50                   	push   ax
    5c13:	9a 4e 12 2a 5c       	call   0x5c2a:0x124e
    5c18:	eb 5c                	jmp    0x5c76
    5c1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c1d:	26 80 bd 8f 01 00    	cmp    BYTE PTR es:[di+0x18f],0x0
    5c23:	74 29                	je     0x5c4e
    5c25:	06                   	push   es
    5c26:	57                   	push   di
    5c27:	9a 2b 5f 4a 5c       	call   0x5c4a:0x5f2b
    5c2c:	52                   	push   dx
    5c2d:	50                   	push   ax
    5c2e:	6a 02                	push   0x2
    5c30:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5c33:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5c36:	6a 01                	push   0x1
    5c38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c3b:	81 c7 78 01          	add    di,0x178
    5c3f:	06                   	push   es
    5c40:	57                   	push   di
    5c41:	9a ad 24 6e 5c       	call   0x5c6e:0x24ad
    5c46:	50                   	push   ax
    5c47:	9a 4e 12 56 5c       	call   0x5c56:0x124e
    5c4c:	eb 28                	jmp    0x5c76
    5c4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c51:	06                   	push   es
    5c52:	57                   	push   di
    5c53:	9a 2b 5f 74 5c       	call   0x5c74:0x5f2b
    5c58:	52                   	push   dx
    5c59:	50                   	push   ax
    5c5a:	6a 02                	push   0x2
    5c5c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5c5f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5c62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c65:	81 c7 78 01          	add    di,0x178
    5c69:	06                   	push   es
    5c6a:	57                   	push   di
    5c6b:	9a 8d 06 7d 68       	call   0x687d:0x68d
    5c70:	50                   	push   ax
    5c71:	9a 4e 12 9c 5c       	call   0x5c9c:0x124e
    5c76:	c9                   	leave
    5c77:	ca 08 00             	retf   0x8
    5c7a:	55                   	push   bp
    5c7b:	89 e5                	mov    bp,sp
    5c7d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5c81:	74 08                	je     0x5c8b
    5c83:	83 ec 08             	sub    sp,0x8
    5c86:	9a e2 1f f5 5c       	call   0x5cf5:0x1fe2
    5c8b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5c8e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5c91:	31 c0                	xor    ax,ax
    5c93:	50                   	push   ax
    5c94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c97:	06                   	push   es
    5c98:	57                   	push   di
    5c99:	9a ee 5f a8 5c       	call   0x5ca8:0x5fee
    5c9e:	6a 01                	push   0x1
    5ca0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ca3:	06                   	push   es
    5ca4:	57                   	push   di
    5ca5:	9a 85 6e b4 5c       	call   0x5cb4:0x6e85
    5caa:	6a 14                	push   0x14
    5cac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5caf:	06                   	push   es
    5cb0:	57                   	push   di
    5cb1:	9a c6 70 b3 5d       	call   0x5db3:0x70c6
    5cb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cb9:	26 c6 45 60 01       	mov    BYTE PTR es:[di+0x60],0x1
    5cbe:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5cc2:	74 07                	je     0x5ccb
    5cc4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5cc8:	83 c4 06             	add    sp,0x6
    5ccb:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5cce:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5cd1:	c9                   	leave
    5cd2:	ca 0a 00             	retf   0xa
    5cd5:	c8 12 01 00          	enter  0x112,0x0
    5cd9:	8d be ee fe          	lea    di,[bp-0x112]
    5cdd:	16                   	push   ss
    5cde:	57                   	push   di
    5cdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ce2:	06                   	push   es
    5ce3:	57                   	push   di
    5ce4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ce7:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    5ceb:	8d 7e ee             	lea    di,[bp-0x12]
    5cee:	16                   	push   ss
    5cef:	57                   	push   di
    5cf0:	6a 0f                	push   0xf
    5cf2:	9a e7 17 10 5e       	call   0x5e10:0x17e7
    5cf7:	80 7e ee 00          	cmp    BYTE PTR [bp-0x12],0x0
    5cfb:	76 13                	jbe    0x5d10
    5cfd:	8a 46 ef             	mov    al,BYTE PTR [bp-0x11]
    5d00:	3c 54                	cmp    al,0x54
    5d02:	74 10                	je     0x5d14
    5d04:	3c 59                	cmp    al,0x59
    5d06:	74 0c                	je     0x5d14
    5d08:	3c 74                	cmp    al,0x74
    5d0a:	74 08                	je     0x5d14
    5d0c:	3c 79                	cmp    al,0x79
    5d0e:	74 04                	je     0x5d14
    5d10:	b0 00                	mov    al,0x0
    5d12:	eb 02                	jmp    0x5d16
    5d14:	b0 01                	mov    al,0x1
    5d16:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    5d19:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    5d1c:	c9                   	leave
    5d1d:	ca 04 00             	retf   0x4
    5d20:	c8 08 01 00          	enter  0x108,0x0
    5d24:	8d be f8 fe          	lea    di,[bp-0x108]
    5d28:	16                   	push   ss
    5d29:	57                   	push   di
    5d2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d2d:	06                   	push   es
    5d2e:	57                   	push   di
    5d2f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5d32:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    5d36:	9a 14 22 64 5d       	call   0x5d64:0x2214
    5d3b:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    5d3f:	90                   	nop
    5d40:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    5d45:	90                   	nop
    5d46:	9b                   	fwait
    5d47:	c9                   	leave
    5d48:	ca 04 00             	retf   0x4
    5d4b:	c8 08 01 00          	enter  0x108,0x0
    5d4f:	8d be f8 fe          	lea    di,[bp-0x108]
    5d53:	16                   	push   ss
    5d54:	57                   	push   di
    5d55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d58:	06                   	push   es
    5d59:	57                   	push   di
    5d5a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5d5d:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    5d61:	9a 14 11 8f 5d       	call   0x5d8f:0x1114
    5d66:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    5d6a:	90                   	nop
    5d6b:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    5d70:	90                   	nop
    5d71:	9b                   	fwait
    5d72:	c9                   	leave
    5d73:	ca 04 00             	retf   0x4
    5d76:	c8 04 01 00          	enter  0x104,0x0
    5d7a:	8d be fc fe          	lea    di,[bp-0x104]
    5d7e:	16                   	push   ss
    5d7f:	57                   	push   di
    5d80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d83:	06                   	push   es
    5d84:	57                   	push   di
    5d85:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5d88:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    5d8c:	9a da 08 ed 5d       	call   0x5ded:0x8da
    5d91:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5d94:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5d97:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5d9a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5d9d:	c9                   	leave
    5d9e:	ca 04 00             	retf   0x4
    5da1:	c8 00 01 00          	enter  0x100,0x0
    5da5:	8d be 00 ff          	lea    di,[bp-0x100]
    5da9:	16                   	push   ss
    5daa:	57                   	push   di
    5dab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dae:	06                   	push   es
    5daf:	57                   	push   di
    5db0:	9a 35 66 e0 5d       	call   0x5de0:0x6635
    5db5:	08 c0                	or     al,al
    5db7:	74 5b                	je     0x5e14
    5db9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5dbc:	26 80 7d 60 00       	cmp    BYTE PTR es:[di+0x60],0x0
    5dc1:	74 21                	je     0x5de4
    5dc3:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5dc7:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    5dcb:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    5dcf:	8d be 00 ff          	lea    di,[bp-0x100]
    5dd3:	16                   	push   ss
    5dd4:	57                   	push   di
    5dd5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5dd8:	06                   	push   es
    5dd9:	57                   	push   di
    5dda:	68 ff 00             	push   0xff
    5ddd:	9a 13 0f 71 5f       	call   0x5f71:0xf13
    5de2:	eb 2e                	jmp    0x5e12
    5de4:	8d be 00 ff          	lea    di,[bp-0x100]
    5de8:	16                   	push   ss
    5de9:	57                   	push   di
    5dea:	9a 8c 0c dd 5e       	call   0x5edd:0xc8c
    5def:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5df2:	26 88 05             	mov    BYTE PTR es:[di],al
    5df5:	8d be 00 ff          	lea    di,[bp-0x100]
    5df9:	16                   	push   ss
    5dfa:	57                   	push   di
    5dfb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5dfe:	81 c7 01 00          	add    di,0x1
    5e02:	06                   	push   es
    5e03:	57                   	push   di
    5e04:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5e07:	26 8a 05             	mov    al,BYTE PTR es:[di]
    5e0a:	30 e4                	xor    ah,ah
    5e0c:	50                   	push   ax
    5e0d:	9a c1 1e 7c 5e       	call   0x5e7c:0x1ec1
    5e12:	eb 07                	jmp    0x5e1b
    5e14:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5e17:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    5e1b:	c9                   	leave
    5e1c:	ca 04 00             	retf   0x4
    5e1f:	c8 02 00 00          	enter  0x2,0x0
    5e23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e26:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    5e2a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5e2d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5e30:	c9                   	leave
    5e31:	ca 04 00             	retf   0x4
    5e34:	c8 00 02 00          	enter  0x200,0x0
    5e38:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5e3c:	74 42                	je     0x5e80
    5e3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e41:	26 c4 7d 38          	les    di,DWORD PTR es:[di+0x38]
    5e45:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    5e49:	74 35                	je     0x5e80
    5e4b:	8d be 00 fe          	lea    di,[bp-0x200]
    5e4f:	16                   	push   ss
    5e50:	57                   	push   di
    5e51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e54:	26 c4 7d 38          	les    di,DWORD PTR es:[di+0x38]
    5e58:	06                   	push   es
    5e59:	57                   	push   di
    5e5a:	8d be 00 ff          	lea    di,[bp-0x100]
    5e5e:	16                   	push   ss
    5e5f:	57                   	push   di
    5e60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e63:	06                   	push   es
    5e64:	57                   	push   di
    5e65:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e68:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    5e6c:	9a fe 10 ff ff       	call   0xffff:0x10fe
    5e71:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5e74:	06                   	push   es
    5e75:	57                   	push   di
    5e76:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5e79:	9a e7 17 9d 5e       	call   0x5e9d:0x17e7
    5e7e:	eb 1f                	jmp    0x5e9f
    5e80:	8d be 00 ff          	lea    di,[bp-0x100]
    5e84:	16                   	push   ss
    5e85:	57                   	push   di
    5e86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e89:	06                   	push   es
    5e8a:	57                   	push   di
    5e8b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e8e:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    5e92:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5e95:	06                   	push   es
    5e96:	57                   	push   di
    5e97:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5e9a:	9a e7 17 af 5f       	call   0x5faf:0x17e7
    5e9f:	c9                   	leave
    5ea0:	ca 0c 00             	retf   0xc
    5ea3:	55                   	push   bp
    5ea4:	89 e5                	mov    bp,sp
    5ea6:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    5ea9:	98                   	cbw
    5eaa:	8b f8                	mov    di,ax
    5eac:	d1 e7                	shl    di,1
    5eae:	81 c7 c6 0b          	add    di,0xbc6
    5eb2:	1e                   	push   ds
    5eb3:	57                   	push   di
    5eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5eb7:	06                   	push   es
    5eb8:	57                   	push   di
    5eb9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ebc:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    5ec0:	c9                   	leave
    5ec1:	ca 06 00             	retf   0x6
    5ec4:	c8 00 01 00          	enter  0x100,0x0
    5ec8:	8d be 00 ff          	lea    di,[bp-0x100]
    5ecc:	16                   	push   ss
    5ecd:	57                   	push   di
    5ece:	ff 76 10             	push   WORD PTR [bp+0x10]
    5ed1:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5ed4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5ed7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5eda:	9a 0a 1d 0b 5f       	call   0x5f0b:0x1d0a
    5edf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ee2:	06                   	push   es
    5ee3:	57                   	push   di
    5ee4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ee7:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    5eeb:	c9                   	leave
    5eec:	ca 0c 00             	retf   0xc
    5eef:	c8 00 01 00          	enter  0x100,0x0
    5ef3:	8d be 00 ff          	lea    di,[bp-0x100]
    5ef7:	16                   	push   ss
    5ef8:	57                   	push   di
    5ef9:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    5efd:	83 ec 0a             	sub    sp,0xa
    5f00:	89 e3                	mov    bx,sp
    5f02:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    5f06:	90                   	nop
    5f07:	9b                   	fwait
    5f08:	9a a4 10 30 5f       	call   0x5f30:0x10a4
    5f0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f10:	06                   	push   es
    5f11:	57                   	push   di
    5f12:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f15:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    5f19:	c9                   	leave
    5f1a:	ca 0c 00             	retf   0xc
    5f1d:	c8 00 01 00          	enter  0x100,0x0
    5f21:	8d be 00 ff          	lea    di,[bp-0x100]
    5f25:	16                   	push   ss
    5f26:	57                   	push   di
    5f27:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5f2a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5f2d:	9a a9 08 8a 5f       	call   0x5f8a:0x8a9
    5f32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f35:	06                   	push   es
    5f36:	57                   	push   di
    5f37:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f3a:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    5f3e:	c9                   	leave
    5f3f:	ca 08 00             	retf   0x8
    5f42:	c8 00 01 00          	enter  0x100,0x0
    5f46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f49:	26 80 7d 60 00       	cmp    BYTE PTR es:[di+0x60],0x0
    5f4e:	74 25                	je     0x5f75
    5f50:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    5f54:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    5f58:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    5f5c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5f5f:	06                   	push   es
    5f60:	57                   	push   di
    5f61:	8d be 00 ff          	lea    di,[bp-0x100]
    5f65:	16                   	push   ss
    5f66:	57                   	push   di
    5f67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f6a:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    5f6e:	9a b7 0e 9a 5f       	call   0x5f9a:0xeb7
    5f73:	eb 17                	jmp    0x5f8c
    5f75:	8d be 00 ff          	lea    di,[bp-0x100]
    5f79:	16                   	push   ss
    5f7a:	57                   	push   di
    5f7b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5f7e:	06                   	push   es
    5f7f:	57                   	push   di
    5f80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f83:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    5f87:	9a 6a 0d 19 60       	call   0x6019:0xd6a
    5f8c:	8d be 00 ff          	lea    di,[bp-0x100]
    5f90:	16                   	push   ss
    5f91:	57                   	push   di
    5f92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f95:	06                   	push   es
    5f96:	57                   	push   di
    5f97:	9a de 6b c2 5f       	call   0x5fc2:0x6bde
    5f9c:	c9                   	leave
    5f9d:	ca 08 00             	retf   0x8
    5fa0:	55                   	push   bp
    5fa1:	89 e5                	mov    bp,sp
    5fa3:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5fa7:	74 08                	je     0x5fb1
    5fa9:	83 ec 08             	sub    sp,0x8
    5fac:	9a e2 1f 41 60       	call   0x6041:0x1fe2
    5fb1:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5fb4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5fb7:	31 c0                	xor    ax,ax
    5fb9:	50                   	push   ax
    5fba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fbd:	06                   	push   es
    5fbe:	57                   	push   di
    5fbf:	9a ee 5f ce 5f       	call   0x5fce:0x5fee
    5fc4:	6a 01                	push   0x1
    5fc6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fc9:	06                   	push   es
    5fca:	57                   	push   di
    5fcb:	9a 9a 6b 36 60       	call   0x6036:0x6b9a
    5fd0:	a1 16 17             	mov    ax,ds:0x1716
    5fd3:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    5fd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fda:	26 89 45 60          	mov    WORD PTR es:[di+0x60],ax
    5fde:	26 89 55 62          	mov    WORD PTR es:[di+0x62],dx
    5fe2:	a1 16 17             	mov    ax,ds:0x1716
    5fe5:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    5fe9:	26 89 45 64          	mov    WORD PTR es:[di+0x64],ax
    5fed:	26 89 55 66          	mov    WORD PTR es:[di+0x66],dx
    5ff1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5ff5:	74 07                	je     0x5ffe
    5ff7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5ffb:	83 c4 06             	add    sp,0x6
    5ffe:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6001:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6004:	c9                   	leave
    6005:	ca 0a 00             	retf   0xa
    6008:	55                   	push   bp
    6009:	89 e5                	mov    bp,sp
    600b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    600e:	26 ff 75 66          	push   WORD PTR es:[di+0x66]
    6012:	26 ff 75 64          	push   WORD PTR es:[di+0x64]
    6016:	9a 24 06 29 60       	call   0x6029:0x624
    601b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    601e:	26 ff 75 62          	push   WORD PTR es:[di+0x62]
    6022:	26 ff 75 60          	push   WORD PTR es:[di+0x60]
    6026:	9a 24 06 22 61       	call   0x6122:0x624
    602b:	31 c0                	xor    ax,ax
    602d:	50                   	push   ax
    602e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6031:	06                   	push   es
    6032:	57                   	push   di
    6033:	9a 5e 60 a7 60       	call   0x60a7:0x605e
    6038:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    603c:	74 05                	je     0x6043
    603e:	9a 0f 20 5e 60       	call   0x605e:0x200f
    6043:	c9                   	leave
    6044:	ca 06 00             	retf   0x6
    6047:	55                   	push   bp
    6048:	89 e5                	mov    bp,sp
    604a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    604d:	26 c4 7d 60          	les    di,DWORD PTR es:[di+0x60]
    6051:	06                   	push   es
    6052:	57                   	push   di
    6053:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6056:	06                   	push   es
    6057:	57                   	push   di
    6058:	68 ff 00             	push   0xff
    605b:	9a e7 17 7b 60       	call   0x607b:0x17e7
    6060:	c9                   	leave
    6061:	ca 04 00             	retf   0x4
    6064:	55                   	push   bp
    6065:	89 e5                	mov    bp,sp
    6067:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    606a:	26 c4 7d 64          	les    di,DWORD PTR es:[di+0x64]
    606e:	06                   	push   es
    606f:	57                   	push   di
    6070:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6073:	06                   	push   es
    6074:	57                   	push   di
    6075:	68 ff 00             	push   0xff
    6078:	9a e7 17 0d 61       	call   0x610d:0x17e7
    607d:	c9                   	leave
    607e:	ca 04 00             	retf   0x4
    6081:	c8 3e 00 00          	enter  0x3e,0x0
    6085:	68 0e f2             	push   0xf20e
    6088:	9b dd 46 1a          	fld    QWORD PTR [bp+0x1a]
    608c:	9b db 7e f6          	fstp   TBYTE PTR [bp-0xa]
    6090:	8d 46 f6             	lea    ax,[bp-0xa]
    6093:	8c d2                	mov    dx,ss
    6095:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    6098:	89 56 c4             	mov    WORD PTR [bp-0x3c],dx
    609b:	c6 46 c6 03          	mov    BYTE PTR [bp-0x3a],0x3
    609f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60a2:	06                   	push   es
    60a3:	57                   	push   di
    60a4:	9a f6 67 f3 60       	call   0x60f3:0x67f6
    60a9:	89 c7                	mov    di,ax
    60ab:	8e c2                	mov    es,dx
    60ad:	89 f8                	mov    ax,di
    60af:	8c c2                	mov    dx,es
    60b1:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    60b4:	89 56 cc             	mov    WORD PTR [bp-0x34],dx
    60b7:	c6 46 ce 04          	mov    BYTE PTR [bp-0x32],0x4
    60bb:	9b dd 46 12          	fld    QWORD PTR [bp+0x12]
    60bf:	9b db 7e ec          	fstp   TBYTE PTR [bp-0x14]
    60c3:	8d 46 ec             	lea    ax,[bp-0x14]
    60c6:	8c d2                	mov    dx,ss
    60c8:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    60cb:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    60ce:	c6 46 d6 03          	mov    BYTE PTR [bp-0x2a],0x3
    60d2:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    60d6:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
    60da:	8d 46 e2             	lea    ax,[bp-0x1e]
    60dd:	8c d2                	mov    dx,ss
    60df:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    60e2:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    60e5:	c6 46 de 03          	mov    BYTE PTR [bp-0x22],0x3
    60e9:	8d 7e c2             	lea    di,[bp-0x3e]
    60ec:	16                   	push   ss
    60ed:	57                   	push   di
    60ee:	6a 03                	push   0x3
    60f0:	9a 0a 12 2e 61       	call   0x612e:0x120a
    60f5:	c9                   	leave
    60f6:	ca 1c 00             	retf   0x1c
    60f9:	55                   	push   bp
    60fa:	89 e5                	mov    bp,sp
    60fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60ff:	26 c4 7d 60          	les    di,DWORD PTR es:[di+0x60]
    6103:	06                   	push   es
    6104:	57                   	push   di
    6105:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6108:	06                   	push   es
    6109:	57                   	push   di
    610a:	9a be 18 48 61       	call   0x6148:0x18be
    610f:	74 1f                	je     0x6130
    6111:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6114:	81 c7 60 00          	add    di,0x60
    6118:	06                   	push   es
    6119:	57                   	push   di
    611a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    611d:	06                   	push   es
    611e:	57                   	push   di
    611f:	9a 51 06 5d 61       	call   0x615d:0x651
    6124:	6a 00                	push   0x0
    6126:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6129:	06                   	push   es
    612a:	57                   	push   di
    612b:	9a 7c 6a 69 61       	call   0x6169:0x6a7c
    6130:	c9                   	leave
    6131:	ca 08 00             	retf   0x8
    6134:	55                   	push   bp
    6135:	89 e5                	mov    bp,sp
    6137:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    613a:	26 c4 7d 64          	les    di,DWORD PTR es:[di+0x64]
    613e:	06                   	push   es
    613f:	57                   	push   di
    6140:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6143:	06                   	push   es
    6144:	57                   	push   di
    6145:	9a be 18 7e 61       	call   0x617e:0x18be
    614a:	74 1f                	je     0x616b
    614c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    614f:	81 c7 64 00          	add    di,0x64
    6153:	06                   	push   es
    6154:	57                   	push   di
    6155:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6158:	06                   	push   es
    6159:	57                   	push   di
    615a:	9a 51 06 59 63       	call   0x6359:0x651
    615f:	6a 00                	push   0x0
    6161:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6164:	06                   	push   es
    6165:	57                   	push   di
    6166:	9a 7c 6a 9d 61       	call   0x619d:0x6a7c
    616b:	c9                   	leave
    616c:	ca 08 00             	retf   0x8
    616f:	55                   	push   bp
    6170:	89 e5                	mov    bp,sp
    6172:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6176:	74 08                	je     0x6180
    6178:	83 ec 08             	sub    sp,0x8
    617b:	9a e2 1f b0 62       	call   0x62b0:0x1fe2
    6180:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6183:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6186:	31 c0                	xor    ax,ax
    6188:	50                   	push   ax
    6189:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    618c:	06                   	push   es
    618d:	57                   	push   di
    618e:	9a a0 5f 2d 62       	call   0x622d:0x5fa0
    6193:	6a 03                	push   0x3
    6195:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6198:	06                   	push   es
    6199:	57                   	push   di
    619a:	9a 85 6e 86 63       	call   0x6386:0x6e85
    619f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61a2:	26 c7 45 68 00 00    	mov    WORD PTR es:[di+0x68],0x0
    61a8:	26 c7 45 6a 00 80    	mov    WORD PTR es:[di+0x6a],0x8000
    61ae:	26 c7 45 6c ff ff    	mov    WORD PTR es:[di+0x6c],0xffff
    61b4:	26 c7 45 6e ff 7f    	mov    WORD PTR es:[di+0x6e],0x7fff
    61ba:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    61be:	74 07                	je     0x61c7
    61c0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    61c4:	83 c4 06             	add    sp,0x6
    61c7:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    61ca:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    61cd:	c9                   	leave
    61ce:	ca 0a 00             	retf   0xa
    61d1:	55                   	push   bp
    61d2:	89 e5                	mov    bp,sp
    61d4:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    61d7:	8b 56 14             	mov    dx,WORD PTR [bp+0x14]
    61da:	3b 56 10             	cmp    dx,WORD PTR [bp+0x10]
    61dd:	7c 19                	jl     0x61f8
    61df:	7f 05                	jg     0x61e6
    61e1:	3b 46 0e             	cmp    ax,WORD PTR [bp+0xe]
    61e4:	72 12                	jb     0x61f8
    61e6:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    61e9:	8b 56 14             	mov    dx,WORD PTR [bp+0x14]
    61ec:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    61ef:	7f 07                	jg     0x61f8
    61f1:	7c 3c                	jl     0x622f
    61f3:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    61f6:	76 37                	jbe    0x622f
    61f8:	9b db 46 12          	fild   DWORD PTR [bp+0x12]
    61fc:	83 ec 08             	sub    sp,0x8
    61ff:	89 e3                	mov    bx,sp
    6201:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6205:	90                   	nop
    6206:	9b 9b db 46 0e       	fild   DWORD PTR [bp+0xe]
    620b:	83 ec 08             	sub    sp,0x8
    620e:	89 e3                	mov    bx,sp
    6210:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6214:	90                   	nop
    6215:	9b 9b db 46 0a       	fild   DWORD PTR [bp+0xa]
    621a:	83 ec 08             	sub    sp,0x8
    621d:	89 e3                	mov    bx,sp
    621f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6223:	90                   	nop
    6224:	9b                   	fwait
    6225:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6228:	06                   	push   es
    6229:	57                   	push   di
    622a:	9a 81 60 6e 62       	call   0x626e:0x6081
    622f:	c9                   	leave
    6230:	ca 10 00             	retf   0x10
    6233:	c8 0c 00 00          	enter  0xc,0x0
    6237:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    623a:	06                   	push   es
    623b:	57                   	push   di
    623c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    623f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    6243:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    6246:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    6249:	9b db 46 f4          	fild   DWORD PTR [bp-0xc]
    624d:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    6251:	90                   	nop
    6252:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    6257:	90                   	nop
    6258:	9b                   	fwait
    6259:	c9                   	leave
    625a:	ca 04 00             	retf   0x4
    625d:	c8 04 00 00          	enter  0x4,0x0
    6261:	8d 7e fc             	lea    di,[bp-0x4]
    6264:	16                   	push   ss
    6265:	57                   	push   di
    6266:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6269:	06                   	push   es
    626a:	57                   	push   di
    626b:	9a 75 63 97 62       	call   0x6297:0x6375
    6270:	08 c0                	or     al,al
    6272:	75 08                	jne    0x627c
    6274:	31 c0                	xor    ax,ax
    6276:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    6279:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    627c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    627f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    6282:	c9                   	leave
    6283:	ca 04 00             	retf   0x4
    6286:	c8 04 00 00          	enter  0x4,0x0
    628a:	8d 7e fc             	lea    di,[bp-0x4]
    628d:	16                   	push   ss
    628e:	57                   	push   di
    628f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6292:	06                   	push   es
    6293:	57                   	push   di
    6294:	9a 75 63 d0 62       	call   0x62d0:0x6375
    6299:	08 c0                	or     al,al
    629b:	74 17                	je     0x62b4
    629d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    62a0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    62a3:	6a 00                	push   0x0
    62a5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    62a8:	06                   	push   es
    62a9:	57                   	push   di
    62aa:	68 ff 00             	push   0xff
    62ad:	9a b0 1d 2c 63       	call   0x632c:0x1db0
    62b2:	eb 07                	jmp    0x62bb
    62b4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    62b7:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    62bb:	c9                   	leave
    62bc:	ca 04 00             	retf   0x4
    62bf:	c8 e8 00 00          	enter  0xe8,0x0
    62c3:	8d 7e f8             	lea    di,[bp-0x8]
    62c6:	16                   	push   ss
    62c7:	57                   	push   di
    62c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62cb:	06                   	push   es
    62cc:	57                   	push   di
    62cd:	9a 75 63 55 64       	call   0x6455:0x6375
    62d2:	08 c0                	or     al,al
    62d4:	75 03                	jne    0x62d9
    62d6:	e9 91 00             	jmp    0x636a
    62d9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    62dd:	75 0d                	jne    0x62ec
    62df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62e2:	26 c4 7d 64          	les    di,DWORD PTR es:[di+0x64]
    62e6:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    62ea:	75 13                	jne    0x62ff
    62ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62ef:	26 8b 45 60          	mov    ax,WORD PTR es:[di+0x60]
    62f3:	26 8b 55 62          	mov    dx,WORD PTR es:[di+0x62]
    62f7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    62fa:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    62fd:	eb 11                	jmp    0x6310
    62ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6302:	26 8b 45 64          	mov    ax,WORD PTR es:[di+0x64]
    6306:	26 8b 55 66          	mov    dx,WORD PTR es:[di+0x66]
    630a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    630d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    6310:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6313:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    6317:	75 17                	jne    0x6330
    6319:	ff 76 fa             	push   WORD PTR [bp-0x6]
    631c:	ff 76 f8             	push   WORD PTR [bp-0x8]
    631f:	6a 00                	push   0x0
    6321:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6324:	06                   	push   es
    6325:	57                   	push   di
    6326:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6329:	9a b0 1d 09 64       	call   0x6409:0x1db0
    632e:	eb 38                	jmp    0x6368
    6330:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6333:	81 c7 01 00          	add    di,0x1
    6337:	06                   	push   es
    6338:	57                   	push   di
    6339:	9b db 46 f8          	fild   DWORD PTR [bp-0x8]
    633d:	83 ec 0a             	sub    sp,0xa
    6340:	89 e3                	mov    bx,sp
    6342:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    6346:	90                   	nop
    6347:	9b                   	fwait
    6348:	8d be 18 ff          	lea    di,[bp-0xe8]
    634c:	16                   	push   ss
    634d:	57                   	push   di
    634e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    6351:	06                   	push   es
    6352:	57                   	push   di
    6353:	68 df 00             	push   0xdf
    6356:	9a 6a 0d 60 63       	call   0x6360:0xd6a
    635b:	52                   	push   dx
    635c:	50                   	push   ax
    635d:	9a 19 34 1b 67       	call   0x671b:0x3419
    6362:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6365:	26 88 05             	mov    BYTE PTR es:[di],al
    6368:	eb 07                	jmp    0x6371
    636a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    636d:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    6371:	c9                   	leave
    6372:	ca 0c 00             	retf   0xc
    6375:	c8 06 00 00          	enter  0x6,0x0
    6379:	8d 7e fa             	lea    di,[bp-0x6]
    637c:	16                   	push   ss
    637d:	57                   	push   di
    637e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6381:	06                   	push   es
    6382:	57                   	push   di
    6383:	9a 35 66 86 64       	call   0x6486:0x6635
    6388:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    638b:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    638f:	74 40                	je     0x63d1
    6391:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6394:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    6398:	3c 02                	cmp    al,0x2
    639a:	75 10                	jne    0x63ac
    639c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    639f:	99                   	cwd
    63a0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    63a3:	26 89 05             	mov    WORD PTR es:[di],ax
    63a6:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    63aa:	eb 25                	jmp    0x63d1
    63ac:	3c 04                	cmp    al,0x4
    63ae:	75 11                	jne    0x63c1
    63b0:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    63b3:	31 d2                	xor    dx,dx
    63b5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    63b8:	26 89 05             	mov    WORD PTR es:[di],ax
    63bb:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    63bf:	eb 10                	jmp    0x63d1
    63c1:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    63c4:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    63c7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    63ca:	26 89 05             	mov    WORD PTR es:[di],ax
    63cd:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    63d1:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    63d4:	c9                   	leave
    63d5:	ca 08 00             	retf   0x8
    63d8:	c8 02 00 00          	enter  0x2,0x0
    63dc:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    63df:	3c 2b                	cmp    al,0x2b
    63e1:	74 10                	je     0x63f3
    63e3:	3c 2d                	cmp    al,0x2d
    63e5:	74 0c                	je     0x63f3
    63e7:	3c 30                	cmp    al,0x30
    63e9:	72 04                	jb     0x63ef
    63eb:	3c 39                	cmp    al,0x39
    63ed:	76 04                	jbe    0x63f3
    63ef:	b0 00                	mov    al,0x0
    63f1:	eb 02                	jmp    0x63f5
    63f3:	b0 01                	mov    al,0x1
    63f5:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    63f8:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    63fb:	c9                   	leave
    63fc:	ca 06 00             	retf   0x6
    63ff:	55                   	push   bp
    6400:	89 e5                	mov    bp,sp
    6402:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    6406:	9a 2f 10 b4 64       	call   0x64b4:0x102f
    640b:	52                   	push   dx
    640c:	50                   	push   ax
    640d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6410:	06                   	push   es
    6411:	57                   	push   di
    6412:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6415:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    6419:	c9                   	leave
    641a:	ca 0c 00             	retf   0xc
    641d:	55                   	push   bp
    641e:	89 e5                	mov    bp,sp
    6420:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6423:	26 8b 45 70          	mov    ax,WORD PTR es:[di+0x70]
    6427:	26 0b 45 72          	or     ax,WORD PTR es:[di+0x72]
    642b:	75 0a                	jne    0x6437
    642d:	26 8b 45 74          	mov    ax,WORD PTR es:[di+0x74]
    6431:	26 0b 45 76          	or     ax,WORD PTR es:[di+0x76]
    6435:	74 22                	je     0x6459
    6437:	ff 76 0c             	push   WORD PTR [bp+0xc]
    643a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    643d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6440:	26 ff 75 72          	push   WORD PTR es:[di+0x72]
    6444:	26 ff 75 70          	push   WORD PTR es:[di+0x70]
    6448:	26 ff 75 76          	push   WORD PTR es:[di+0x76]
    644c:	26 ff 75 74          	push   WORD PTR es:[di+0x74]
    6450:	06                   	push   es
    6451:	57                   	push   di
    6452:	9a d1 61 77 64       	call   0x6477:0x61d1
    6457:	eb 20                	jmp    0x6479
    6459:	ff 76 0c             	push   WORD PTR [bp+0xc]
    645c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    645f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6462:	26 ff 75 6a          	push   WORD PTR es:[di+0x6a]
    6466:	26 ff 75 68          	push   WORD PTR es:[di+0x68]
    646a:	26 ff 75 6e          	push   WORD PTR es:[di+0x6e]
    646e:	26 ff 75 6c          	push   WORD PTR es:[di+0x6c]
    6472:	06                   	push   es
    6473:	57                   	push   di
    6474:	9a d1 61 35 65       	call   0x6535:0x61d1
    6479:	8d 7e 0a             	lea    di,[bp+0xa]
    647c:	16                   	push   ss
    647d:	57                   	push   di
    647e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6481:	06                   	push   es
    6482:	57                   	push   di
    6483:	9a de 6b de 64       	call   0x64de:0x6bde
    6488:	c9                   	leave
    6489:	ca 08 00             	retf   0x8
    648c:	c8 16 00 00          	enter  0x16,0x0
    6490:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6493:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    6497:	75 0e                	jne    0x64a7
    6499:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    649c:	06                   	push   es
    649d:	57                   	push   di
    649e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    64a1:	26 ff 5d 6c          	call   DWORD PTR es:[di+0x6c]
    64a5:	eb 69                	jmp    0x6510
    64a7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    64aa:	06                   	push   es
    64ab:	57                   	push   di
    64ac:	8d 7e fe             	lea    di,[bp-0x2]
    64af:	16                   	push   ss
    64b0:	57                   	push   di
    64b1:	9a fb 1d 93 65       	call   0x6593:0x1dfb
    64b6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    64b9:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    64bc:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    64c0:	74 3c                	je     0x64fe
    64c2:	68 0f f2             	push   0xf20f
    64c5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    64c8:	89 f8                	mov    ax,di
    64ca:	8c c2                	mov    dx,es
    64cc:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    64cf:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    64d2:	c6 46 ee 04          	mov    BYTE PTR [bp-0x12],0x4
    64d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64d9:	06                   	push   es
    64da:	57                   	push   di
    64db:	9a f6 67 fc 64       	call   0x64fc:0x67f6
    64e0:	89 c7                	mov    di,ax
    64e2:	8e c2                	mov    es,dx
    64e4:	89 f8                	mov    ax,di
    64e6:	8c c2                	mov    dx,es
    64e8:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    64eb:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    64ee:	c6 46 f6 04          	mov    BYTE PTR [bp-0xa],0x4
    64f2:	8d 7e ea             	lea    di,[bp-0x16]
    64f5:	16                   	push   ss
    64f6:	57                   	push   di
    64f7:	6a 01                	push   0x1
    64f9:	9a 0a 12 b2 65       	call   0x65b2:0x120a
    64fe:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6501:	ff 76 fa             	push   WORD PTR [bp-0x6]
    6504:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6507:	06                   	push   es
    6508:	57                   	push   di
    6509:	26 c4 3d             	les    di,DWORD PTR es:[di]
    650c:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    6510:	c9                   	leave
    6511:	ca 08 00             	retf   0x8
    6514:	55                   	push   bp
    6515:	89 e5                	mov    bp,sp
    6517:	ff 76 0c             	push   WORD PTR [bp+0xc]
    651a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    651d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6520:	26 ff 75 6a          	push   WORD PTR es:[di+0x6a]
    6524:	26 ff 75 68          	push   WORD PTR es:[di+0x68]
    6528:	26 ff 75 6e          	push   WORD PTR es:[di+0x6e]
    652c:	26 ff 75 6c          	push   WORD PTR es:[di+0x6c]
    6530:	06                   	push   es
    6531:	57                   	push   di
    6532:	9a d1 61 6d 65       	call   0x656d:0x61d1
    6537:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    653a:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    653d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6540:	26 89 45 74          	mov    WORD PTR es:[di+0x74],ax
    6544:	26 89 55 76          	mov    WORD PTR es:[di+0x76],dx
    6548:	c9                   	leave
    6549:	ca 08 00             	retf   0x8
    654c:	55                   	push   bp
    654d:	89 e5                	mov    bp,sp
    654f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6552:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6555:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6558:	26 ff 75 6a          	push   WORD PTR es:[di+0x6a]
    655c:	26 ff 75 68          	push   WORD PTR es:[di+0x68]
    6560:	26 ff 75 6e          	push   WORD PTR es:[di+0x6e]
    6564:	26 ff 75 6c          	push   WORD PTR es:[di+0x6c]
    6568:	06                   	push   es
    6569:	57                   	push   di
    656a:	9a d1 61 a6 65       	call   0x65a6:0x61d1
    656f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6572:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    6575:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6578:	26 89 45 70          	mov    WORD PTR es:[di+0x70],ax
    657c:	26 89 55 72          	mov    WORD PTR es:[di+0x72],dx
    6580:	c9                   	leave
    6581:	ca 08 00             	retf   0x8
    6584:	55                   	push   bp
    6585:	89 e5                	mov    bp,sp
    6587:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    658b:	74 08                	je     0x6595
    658d:	83 ec 08             	sub    sp,0x8
    6590:	9a e2 1f f5 65       	call   0x65f5:0x1fe2
    6595:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6598:	ff 76 0c             	push   WORD PTR [bp+0xc]
    659b:	31 c0                	xor    ax,ax
    659d:	50                   	push   ax
    659e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65a1:	06                   	push   es
    65a2:	57                   	push   di
    65a3:	9a 6f 61 08 66       	call   0x6608:0x616f
    65a8:	6a 02                	push   0x2
    65aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65ad:	06                   	push   es
    65ae:	57                   	push   di
    65af:	9a 85 6e 14 66       	call   0x6614:0x6e85
    65b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65b7:	26 c7 45 68 00 80    	mov    WORD PTR es:[di+0x68],0x8000
    65bd:	26 c7 45 6a ff ff    	mov    WORD PTR es:[di+0x6a],0xffff
    65c3:	26 c7 45 6c ff 7f    	mov    WORD PTR es:[di+0x6c],0x7fff
    65c9:	26 c7 45 6e 00 00    	mov    WORD PTR es:[di+0x6e],0x0
    65cf:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    65d3:	74 07                	je     0x65dc
    65d5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    65d9:	83 c4 06             	add    sp,0x6
    65dc:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    65df:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    65e2:	c9                   	leave
    65e3:	ca 0a 00             	retf   0xa
    65e6:	55                   	push   bp
    65e7:	89 e5                	mov    bp,sp
    65e9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    65ed:	74 08                	je     0x65f7
    65ef:	83 ec 08             	sub    sp,0x8
    65f2:	9a e2 1f 55 66       	call   0x6655:0x1fe2
    65f7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    65fa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    65fd:	31 c0                	xor    ax,ax
    65ff:	50                   	push   ax
    6600:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6603:	06                   	push   es
    6604:	57                   	push   di
    6605:	9a 6f 61 68 66       	call   0x6668:0x616f
    660a:	6a 04                	push   0x4
    660c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    660f:	06                   	push   es
    6610:	57                   	push   di
    6611:	9a 85 6e 74 66       	call   0x6674:0x6e85
    6616:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6619:	31 c0                	xor    ax,ax
    661b:	26 89 45 68          	mov    WORD PTR es:[di+0x68],ax
    661f:	26 89 45 6a          	mov    WORD PTR es:[di+0x6a],ax
    6623:	26 c7 45 6c ff ff    	mov    WORD PTR es:[di+0x6c],0xffff
    6629:	26 c7 45 6e 00 00    	mov    WORD PTR es:[di+0x6e],0x0
    662f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6633:	74 07                	je     0x663c
    6635:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6639:	83 c4 06             	add    sp,0x6
    663c:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    663f:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6642:	c9                   	leave
    6643:	ca 0a 00             	retf   0xa
    6646:	55                   	push   bp
    6647:	89 e5                	mov    bp,sp
    6649:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    664d:	74 08                	je     0x6657
    664f:	83 ec 08             	sub    sp,0x8
    6652:	9a e2 1f da 66       	call   0x66da:0x1fe2
    6657:	ff 76 0e             	push   WORD PTR [bp+0xe]
    665a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    665d:	31 c0                	xor    ax,ax
    665f:	50                   	push   ax
    6660:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6663:	06                   	push   es
    6664:	57                   	push   di
    6665:	9a a0 5f ab 66       	call   0x66ab:0x5fa0
    666a:	6a 06                	push   0x6
    666c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    666f:	06                   	push   es
    6670:	57                   	push   di
    6671:	9a 85 6e 51 68       	call   0x6851:0x6e85
    6676:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6679:	26 c7 45 6a 0f 00    	mov    WORD PTR es:[di+0x6a],0xf
    667f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6683:	74 07                	je     0x668c
    6685:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6689:	83 c4 06             	add    sp,0x6
    668c:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    668f:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6692:	c9                   	leave
    6693:	ca 0a 00             	retf   0xa
    6696:	00 00                	add    BYTE PTR [bx+si],al
    6698:	00 00                	add    BYTE PTR [bx+si],al
    669a:	c8 08 00 00          	enter  0x8,0x0
    669e:	8d 7e f8             	lea    di,[bp-0x8]
    66a1:	16                   	push   ss
    66a2:	57                   	push   di
    66a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66a6:	06                   	push   es
    66a7:	57                   	push   di
    66a8:	9a 36 68 fd 66       	call   0x66fd:0x6836
    66ad:	08 c0                	or     al,al
    66af:	75 0c                	jne    0x66bd
    66b1:	9b 2e d9 06 96 66    	fld    DWORD PTR cs:0x6696
    66b7:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    66bb:	90                   	nop
    66bc:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    66c1:	90                   	nop
    66c2:	9b                   	fwait
    66c3:	c9                   	leave
    66c4:	ca 04 00             	retf   0x4
    66c7:	c8 04 00 00          	enter  0x4,0x0
    66cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66ce:	06                   	push   es
    66cf:	57                   	push   di
    66d0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    66d3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    66d7:	9a 2f 10 28 67       	call   0x6728:0x102f
    66dc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    66df:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    66e2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    66e5:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    66e8:	c9                   	leave
    66e9:	ca 04 00             	retf   0x4
    66ec:	c8 08 01 00          	enter  0x108,0x0
    66f0:	8d 7e f8             	lea    di,[bp-0x8]
    66f3:	16                   	push   ss
    66f4:	57                   	push   di
    66f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66f8:	06                   	push   es
    66f9:	57                   	push   di
    66fa:	9a 36 68 48 67       	call   0x6748:0x6836
    66ff:	08 c0                	or     al,al
    6701:	74 29                	je     0x672c
    6703:	8d be f8 fe          	lea    di,[bp-0x108]
    6707:	16                   	push   ss
    6708:	57                   	push   di
    6709:	9b dd 46 f8          	fld    QWORD PTR [bp-0x8]
    670d:	83 ec 0a             	sub    sp,0xa
    6710:	89 e3                	mov    bx,sp
    6712:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    6716:	90                   	nop
    6717:	9b                   	fwait
    6718:	9a a4 10 e7 67       	call   0x67e7:0x10a4
    671d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6720:	06                   	push   es
    6721:	57                   	push   di
    6722:	68 ff 00             	push   0xff
    6725:	9a e7 17 b5 68       	call   0x68b5:0x17e7
    672a:	eb 07                	jmp    0x6733
    672c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    672f:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    6733:	c9                   	leave
    6734:	ca 04 00             	retf   0x4
    6737:	c8 f0 00 00          	enter  0xf0,0x0
    673b:	8d 7e f0             	lea    di,[bp-0x10]
    673e:	16                   	push   ss
    673f:	57                   	push   di
    6740:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6743:	06                   	push   es
    6744:	57                   	push   di
    6745:	9a 36 68 58 69       	call   0x6958:0x6836
    674a:	08 c0                	or     al,al
    674c:	75 03                	jne    0x6751
    674e:	e9 da 00             	jmp    0x682b
    6751:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6755:	75 0d                	jne    0x6764
    6757:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    675a:	26 c4 7d 64          	les    di,DWORD PTR es:[di+0x64]
    675e:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    6762:	75 13                	jne    0x6777
    6764:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6767:	26 8b 45 60          	mov    ax,WORD PTR es:[di+0x60]
    676b:	26 8b 55 62          	mov    dx,WORD PTR es:[di+0x62]
    676f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6772:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    6775:	eb 11                	jmp    0x6788
    6777:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    677a:	26 8b 45 64          	mov    ax,WORD PTR es:[di+0x64]
    677e:	26 8b 55 66          	mov    dx,WORD PTR es:[di+0x66]
    6782:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    6785:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    6788:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    678b:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    678f:	75 60                	jne    0x67f1
    6791:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6794:	26 80 7d 68 00       	cmp    BYTE PTR es:[di+0x68],0x0
    6799:	74 1a                	je     0x67b5
    679b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    679f:	74 06                	je     0x67a7
    67a1:	c6 46 ff 04          	mov    BYTE PTR [bp-0x1],0x4
    67a5:	eb 04                	jmp    0x67ab
    67a7:	c6 46 ff 02          	mov    BYTE PTR [bp-0x1],0x2
    67ab:	a0 64 2c             	mov    al,ds:0x2c64
    67ae:	30 e4                	xor    ah,ah
    67b0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    67b3:	eb 09                	jmp    0x67be
    67b5:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    67b9:	31 c0                	xor    ax,ax
    67bb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    67be:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    67c1:	81 c7 01 00          	add    di,0x1
    67c5:	06                   	push   es
    67c6:	57                   	push   di
    67c7:	9b dd 46 f0          	fld    QWORD PTR [bp-0x10]
    67cb:	83 ec 0a             	sub    sp,0xa
    67ce:	89 e3                	mov    bx,sp
    67d0:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    67d4:	90                   	nop
    67d5:	9b                   	fwait
    67d6:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    67d9:	50                   	push   ax
    67da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67dd:	26 ff 75 6a          	push   WORD PTR es:[di+0x6a]
    67e1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    67e4:	9a a0 31 1a 68       	call   0x681a:0x31a0
    67e9:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    67ec:	26 88 05             	mov    BYTE PTR es:[di],al
    67ef:	eb 38                	jmp    0x6829
    67f1:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    67f4:	81 c7 01 00          	add    di,0x1
    67f8:	06                   	push   es
    67f9:	57                   	push   di
    67fa:	9b dd 46 f0          	fld    QWORD PTR [bp-0x10]
    67fe:	83 ec 0a             	sub    sp,0xa
    6801:	89 e3                	mov    bx,sp
    6803:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    6807:	90                   	nop
    6808:	9b                   	fwait
    6809:	8d be 10 ff          	lea    di,[bp-0xf0]
    680d:	16                   	push   ss
    680e:	57                   	push   di
    680f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    6812:	06                   	push   es
    6813:	57                   	push   di
    6814:	68 df 00             	push   0xdf
    6817:	9a 6a 0d 21 68       	call   0x6821:0xd6a
    681c:	52                   	push   dx
    681d:	50                   	push   ax
    681e:	9a 19 34 ec 69       	call   0x69ec:0x3419
    6823:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    6826:	26 88 05             	mov    BYTE PTR es:[di],al
    6829:	eb 07                	jmp    0x6832
    682b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    682e:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    6832:	c9                   	leave
    6833:	ca 0c 00             	retf   0xc
    6836:	c8 24 00 00          	enter  0x24,0x0
    683a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    683d:	26 80 7d 22 08       	cmp    BYTE PTR es:[di+0x22],0x8
    6842:	74 14                	je     0x6858
    6844:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6847:	06                   	push   es
    6848:	57                   	push   di
    6849:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    684c:	06                   	push   es
    684d:	57                   	push   di
    684e:	9a 35 66 65 68       	call   0x6865:0x6635
    6853:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6856:	eb 27                	jmp    0x687f
    6858:	8d 7e dc             	lea    di,[bp-0x24]
    685b:	16                   	push   ss
    685c:	57                   	push   di
    685d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6860:	06                   	push   es
    6861:	57                   	push   di
    6862:	9a 35 66 71 69       	call   0x6971:0x6635
    6867:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    686a:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    686e:	74 0f                	je     0x687f
    6870:	8d 7e dc             	lea    di,[bp-0x24]
    6873:	16                   	push   ss
    6874:	57                   	push   di
    6875:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6878:	06                   	push   es
    6879:	57                   	push   di
    687a:	9a 0d 22 8b 69       	call   0x698b:0x220d
    687f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6882:	c9                   	leave
    6883:	ca 08 00             	retf   0x8
    6886:	00 00                	add    BYTE PTR [bx+si],al
    6888:	00 00                	add    BYTE PTR [bx+si],al
    688a:	00 28                	add    BYTE PTR [bx+si],ch
    688c:	ff 03                	inc    WORD PTR [bp+di]
    688e:	20 00                	and    BYTE PTR [bx+si],al
    6890:	00 00                	add    BYTE PTR [bx+si],al
    6892:	20 00                	and    BYTE PTR [bx+si],al
	...
    68a4:	00 00                	add    BYTE PTR [bx+si],al
    68a6:	c8 22 00 00          	enter  0x22,0x0
    68aa:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    68ad:	b4 01                	mov    ah,0x1
    68af:	ba 20 00             	mov    dx,0x20
    68b2:	9a 99 1a c8 68       	call   0x68c8:0x1a99
    68b7:	52                   	push   dx
    68b8:	50                   	push   ax
    68b9:	8d 7e de             	lea    di,[bp-0x22]
    68bc:	16                   	push   ss
    68bd:	57                   	push   di
    68be:	bf 86 68             	mov    di,0x6886
    68c1:	0e                   	push   cs
    68c2:	57                   	push   di
    68c3:	6a 20                	push   0x20
    68c5:	9a e4 19 d1 68       	call   0x68d1:0x19e4
    68ca:	a0 63 2c             	mov    al,ds:0x2c63
    68cd:	50                   	push   ax
    68ce:	9a 24 1a 46 6b       	call   0x6b46:0x1a24
    68d3:	83 c4 04             	add    sp,0x4
    68d6:	59                   	pop    cx
    68d7:	5b                   	pop    bx
    68d8:	8b fb                	mov    di,bx
    68da:	84 4b de             	test   BYTE PTR [bp+di-0x22],cl
    68dd:	b0 00                	mov    al,0x0
    68df:	74 01                	je     0x68e2
    68e1:	40                   	inc    ax
    68e2:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    68e5:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    68e8:	c9                   	leave
    68e9:	ca 06 00             	retf   0x6
    68ec:	c8 26 00 00          	enter  0x26,0x0
    68f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68f3:	26 80 7d 69 00       	cmp    BYTE PTR es:[di+0x69],0x0
    68f8:	74 60                	je     0x695a
    68fa:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    68fe:	9b 26 dc 5d 6c       	fcomp  QWORD PTR es:[di+0x6c]
    6903:	9b dd 7e dc          	fstsw  WORD PTR [bp-0x24]
    6907:	90                   	nop
    6908:	9b                   	fwait
    6909:	8a 66 dd             	mov    ah,BYTE PTR [bp-0x23]
    690c:	9e                   	sahf
    690d:	72 15                	jb     0x6924
    690f:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    6913:	9b 26 dc 5d 74       	fcomp  QWORD PTR es:[di+0x74]
    6918:	9b dd 7e da          	fstsw  WORD PTR [bp-0x26]
    691c:	90                   	nop
    691d:	9b                   	fwait
    691e:	8a 66 db             	mov    ah,BYTE PTR [bp-0x25]
    6921:	9e                   	sahf
    6922:	76 36                	jbe    0x695a
    6924:	ff 76 10             	push   WORD PTR [bp+0x10]
    6927:	ff 76 0e             	push   WORD PTR [bp+0xe]
    692a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    692d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    6930:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6933:	26 ff 75 72          	push   WORD PTR es:[di+0x72]
    6937:	26 ff 75 70          	push   WORD PTR es:[di+0x70]
    693b:	26 ff 75 6e          	push   WORD PTR es:[di+0x6e]
    693f:	26 ff 75 6c          	push   WORD PTR es:[di+0x6c]
    6943:	26 ff 75 7a          	push   WORD PTR es:[di+0x7a]
    6947:	26 ff 75 78          	push   WORD PTR es:[di+0x78]
    694b:	26 ff 75 76          	push   WORD PTR es:[di+0x76]
    694f:	26 ff 75 74          	push   WORD PTR es:[di+0x74]
    6953:	06                   	push   es
    6954:	57                   	push   di
    6955:	9a 81 60 92 6a       	call   0x6a92:0x6081
    695a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    695d:	26 80 7d 22 08       	cmp    BYTE PTR es:[di+0x22],0x8
    6962:	74 11                	je     0x6975
    6964:	8d 7e 0a             	lea    di,[bp+0xa]
    6967:	16                   	push   ss
    6968:	57                   	push   di
    6969:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    696c:	06                   	push   es
    696d:	57                   	push   di
    696e:	9a de 6b 9a 69       	call   0x699a:0x6bde
    6973:	eb 27                	jmp    0x699c
    6975:	8d 7e 0a             	lea    di,[bp+0xa]
    6978:	16                   	push   ss
    6979:	57                   	push   di
    697a:	6a 20                	push   0x20
    697c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    697f:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    6983:	8d 7e de             	lea    di,[bp-0x22]
    6986:	16                   	push   ss
    6987:	57                   	push   di
    6988:	9a 1d 22 f1 75       	call   0x75f1:0x221d
    698d:	8d 7e de             	lea    di,[bp-0x22]
    6990:	16                   	push   ss
    6991:	57                   	push   di
    6992:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6995:	06                   	push   es
    6996:	57                   	push   di
    6997:	9a de 6b 1a 6a       	call   0x6a1a:0x6bde
    699c:	c9                   	leave
    699d:	ca 0c 00             	retf   0xc
    69a0:	55                   	push   bp
    69a1:	89 e5                	mov    bp,sp
    69a3:	9b db 46 0a          	fild   DWORD PTR [bp+0xa]
    69a7:	83 ec 08             	sub    sp,0x8
    69aa:	89 e3                	mov    bx,sp
    69ac:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    69b0:	90                   	nop
    69b1:	9b                   	fwait
    69b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69b5:	06                   	push   es
    69b6:	57                   	push   di
    69b7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    69ba:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    69be:	c9                   	leave
    69bf:	ca 08 00             	retf   0x8
    69c2:	c8 5a 00 00          	enter  0x5a,0x0
    69c6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    69c9:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    69cd:	75 0e                	jne    0x69dd
    69cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69d2:	06                   	push   es
    69d3:	57                   	push   di
    69d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    69d7:	26 ff 5d 6c          	call   DWORD PTR es:[di+0x6c]
    69db:	eb 78                	jmp    0x6a55
    69dd:	8d 7e b6             	lea    di,[bp-0x4a]
    69e0:	16                   	push   ss
    69e1:	57                   	push   di
    69e2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    69e5:	06                   	push   es
    69e6:	57                   	push   di
    69e7:	6a 3f                	push   0x3f
    69e9:	9a 6a 0d f8 69       	call   0x69f8:0xd6a
    69ee:	52                   	push   dx
    69ef:	50                   	push   ax
    69f0:	8d 7e f6             	lea    di,[bp-0xa]
    69f3:	16                   	push   ss
    69f4:	57                   	push   di
    69f5:	9a e9 37 4a 6c       	call   0x6c4a:0x37e9
    69fa:	08 c0                	or     al,al
    69fc:	75 3c                	jne    0x6a3a
    69fe:	68 10 f2             	push   0xf210
    6a01:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6a04:	89 f8                	mov    ax,di
    6a06:	8c c2                	mov    dx,es
    6a08:	89 46 a6             	mov    WORD PTR [bp-0x5a],ax
    6a0b:	89 56 a8             	mov    WORD PTR [bp-0x58],dx
    6a0e:	c6 46 aa 04          	mov    BYTE PTR [bp-0x56],0x4
    6a12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a15:	06                   	push   es
    6a16:	57                   	push   di
    6a17:	9a f6 67 38 6a       	call   0x6a38:0x67f6
    6a1c:	89 c7                	mov    di,ax
    6a1e:	8e c2                	mov    es,dx
    6a20:	89 f8                	mov    ax,di
    6a22:	8c c2                	mov    dx,es
    6a24:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    6a27:	89 56 b0             	mov    WORD PTR [bp-0x50],dx
    6a2a:	c6 46 b2 04          	mov    BYTE PTR [bp-0x4e],0x4
    6a2e:	8d 7e a6             	lea    di,[bp-0x5a]
    6a31:	16                   	push   ss
    6a32:	57                   	push   di
    6a33:	6a 01                	push   0x1
    6a35:	9a 0a 12 76 6a       	call   0x6a76:0x120a
    6a3a:	9b db 6e f6          	fld    TBYTE PTR [bp-0xa]
    6a3e:	83 ec 08             	sub    sp,0x8
    6a41:	89 e3                	mov    bx,sp
    6a43:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    6a47:	90                   	nop
    6a48:	9b                   	fwait
    6a49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a4c:	06                   	push   es
    6a4d:	57                   	push   di
    6a4e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a51:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    6a55:	c9                   	leave
    6a56:	ca 08 00             	retf   0x8
    6a59:	55                   	push   bp
    6a5a:	89 e5                	mov    bp,sp
    6a5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a5f:	26 8a 45 68          	mov    al,BYTE PTR es:[di+0x68]
    6a63:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    6a66:	74 10                	je     0x6a78
    6a68:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6a6b:	26 88 45 68          	mov    BYTE PTR es:[di+0x68],al
    6a6f:	6a 00                	push   0x0
    6a71:	06                   	push   es
    6a72:	57                   	push   di
    6a73:	9a 7c 6a e7 6a       	call   0x6ae7:0x6a7c
    6a78:	c9                   	leave
    6a79:	ca 06 00             	retf   0x6
    6a7c:	55                   	push   bp
    6a7d:	89 e5                	mov    bp,sp
    6a7f:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    6a83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a86:	9b 26 dd 5d 74       	fstp   QWORD PTR es:[di+0x74]
    6a8b:	90                   	nop
    6a8c:	9b                   	fwait
    6a8d:	06                   	push   es
    6a8e:	57                   	push   di
    6a8f:	9a f1 6a ae 6a       	call   0x6aae:0x6af1
    6a94:	c9                   	leave
    6a95:	ca 0c 00             	retf   0xc
    6a98:	55                   	push   bp
    6a99:	89 e5                	mov    bp,sp
    6a9b:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    6a9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6aa2:	9b 26 dd 5d 6c       	fstp   QWORD PTR es:[di+0x6c]
    6aa7:	90                   	nop
    6aa8:	9b                   	fwait
    6aa9:	06                   	push   es
    6aaa:	57                   	push   di
    6aab:	9a f1 6a 59 6b       	call   0x6b59:0x6af1
    6ab0:	c9                   	leave
    6ab1:	ca 0c 00             	retf   0xc
    6ab4:	55                   	push   bp
    6ab5:	89 e5                	mov    bp,sp
    6ab7:	83 7e 0a 02          	cmp    WORD PTR [bp+0xa],0x2
    6abb:	7d 05                	jge    0x6ac2
    6abd:	c7 46 0a 02 00       	mov    WORD PTR [bp+0xa],0x2
    6ac2:	83 7e 0a 0f          	cmp    WORD PTR [bp+0xa],0xf
    6ac6:	7e 05                	jle    0x6acd
    6ac8:	c7 46 0a 0f 00       	mov    WORD PTR [bp+0xa],0xf
    6acd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ad0:	26 8b 45 6a          	mov    ax,WORD PTR es:[di+0x6a]
    6ad4:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    6ad7:	74 10                	je     0x6ae9
    6ad9:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    6adc:	26 89 45 6a          	mov    WORD PTR es:[di+0x6a],ax
    6ae0:	6a 00                	push   0x0
    6ae2:	06                   	push   es
    6ae3:	57                   	push   di
    6ae4:	9a 7c 6a 65 6b       	call   0x6b65:0x6a7c
    6ae9:	c9                   	leave
    6aea:	ca 06 00             	retf   0x6
    6aed:	00 00                	add    BYTE PTR [bx+si],al
    6aef:	00 00                	add    BYTE PTR [bx+si],al
    6af1:	c8 04 00 00          	enter  0x4,0x0
    6af5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6af8:	9b 26 dd 45 6c       	fld    QWORD PTR es:[di+0x6c]
    6afd:	9b 2e d8 1e ed 6a    	fcomp  DWORD PTR cs:0x6aed
    6b03:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    6b07:	90                   	nop
    6b08:	9b                   	fwait
    6b09:	8a 66 ff             	mov    ah,BYTE PTR [bp-0x1]
    6b0c:	9e                   	sahf
    6b0d:	75 1b                	jne    0x6b2a
    6b0f:	9b 26 dd 45 74       	fld    QWORD PTR es:[di+0x74]
    6b14:	9b 2e d8 1e ed 6a    	fcomp  DWORD PTR cs:0x6aed
    6b1a:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
    6b1e:	90                   	nop
    6b1f:	9b                   	fwait
    6b20:	8a 66 fd             	mov    ah,BYTE PTR [bp-0x3]
    6b23:	9e                   	sahf
    6b24:	75 04                	jne    0x6b2a
    6b26:	b0 00                	mov    al,0x0
    6b28:	eb 02                	jmp    0x6b2c
    6b2a:	b0 01                	mov    al,0x1
    6b2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b2f:	26 88 45 69          	mov    BYTE PTR es:[di+0x69],al
    6b33:	c9                   	leave
    6b34:	ca 04 00             	retf   0x4
    6b37:	55                   	push   bp
    6b38:	89 e5                	mov    bp,sp
    6b3a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6b3e:	74 08                	je     0x6b48
    6b40:	83 ec 08             	sub    sp,0x8
    6b43:	9a e2 1f 95 6b       	call   0x6b95:0x1fe2
    6b48:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6b4b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6b4e:	31 c0                	xor    ax,ax
    6b50:	50                   	push   ax
    6b51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b54:	06                   	push   es
    6b55:	57                   	push   di
    6b56:	9a 46 66 a8 6b       	call   0x6ba8:0x6646
    6b5b:	6a 07                	push   0x7
    6b5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b60:	06                   	push   es
    6b61:	57                   	push   di
    6b62:	9a 85 6e b4 6b       	call   0x6bb4:0x6e85
    6b67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b6a:	26 c6 45 68 01       	mov    BYTE PTR es:[di+0x68],0x1
    6b6f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6b73:	74 07                	je     0x6b7c
    6b75:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6b79:	83 c4 06             	add    sp,0x6
    6b7c:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6b7f:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6b82:	c9                   	leave
    6b83:	ca 0a 00             	retf   0xa
    6b86:	55                   	push   bp
    6b87:	89 e5                	mov    bp,sp
    6b89:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6b8d:	74 08                	je     0x6b97
    6b8f:	83 ec 08             	sub    sp,0x8
    6b92:	9a e2 1f e8 6b       	call   0x6be8:0x1fe2
    6b97:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6b9a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6b9d:	31 c0                	xor    ax,ax
    6b9f:	50                   	push   ax
    6ba0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ba3:	06                   	push   es
    6ba4:	57                   	push   di
    6ba5:	9a 46 66 20 6c       	call   0x6c20:0x6646
    6baa:	6a 08                	push   0x8
    6bac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6baf:	06                   	push   es
    6bb0:	57                   	push   di
    6bb1:	9a 85 6e c0 6b       	call   0x6bc0:0x6e85
    6bb6:	6a 04                	push   0x4
    6bb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bbb:	06                   	push   es
    6bbc:	57                   	push   di
    6bbd:	9a c6 70 fb 6b       	call   0x6bfb:0x70c6
    6bc2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6bc6:	74 07                	je     0x6bcf
    6bc8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6bcc:	83 c4 06             	add    sp,0x6
    6bcf:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6bd2:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6bd5:	c9                   	leave
    6bd6:	ca 0a 00             	retf   0xa
    6bd9:	55                   	push   bp
    6bda:	89 e5                	mov    bp,sp
    6bdc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6be0:	74 08                	je     0x6bea
    6be2:	83 ec 08             	sub    sp,0x8
    6be5:	9a e2 1f 62 6c       	call   0x6c62:0x1fe2
    6bea:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6bed:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6bf0:	31 c0                	xor    ax,ax
    6bf2:	50                   	push   ax
    6bf3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bf6:	06                   	push   es
    6bf7:	57                   	push   di
    6bf8:	9a ee 5f 07 6c       	call   0x6c07:0x5fee
    6bfd:	6a 05                	push   0x5
    6bff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c02:	06                   	push   es
    6c03:	57                   	push   di
    6c04:	9a 85 6e 57 6c       	call   0x6c57:0x6e85
    6c09:	a1 16 17             	mov    ax,ds:0x1716
    6c0c:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    6c10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c13:	26 89 45 60          	mov    WORD PTR es:[di+0x60],ax
    6c17:	26 89 55 62          	mov    WORD PTR es:[di+0x62],dx
    6c1b:	06                   	push   es
    6c1c:	57                   	push   di
    6c1d:	9a 2d 6d d8 6e       	call   0x6ed8:0x6d2d
    6c22:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6c26:	74 07                	je     0x6c2f
    6c28:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6c2c:	83 c4 06             	add    sp,0x6
    6c2f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6c32:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6c35:	c9                   	leave
    6c36:	ca 0a 00             	retf   0xa
    6c39:	55                   	push   bp
    6c3a:	89 e5                	mov    bp,sp
    6c3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c3f:	26 ff 75 62          	push   WORD PTR es:[di+0x62]
    6c43:	26 ff 75 60          	push   WORD PTR es:[di+0x60]
    6c47:	9a 24 06 3d 6d       	call   0x6d3d:0x624
    6c4c:	31 c0                	xor    ax,ax
    6c4e:	50                   	push   ax
    6c4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c52:	06                   	push   es
    6c53:	57                   	push   di
    6c54:	9a 5e 60 79 6c       	call   0x6c79:0x605e
    6c59:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6c5d:	74 05                	je     0x6c64
    6c5f:	9a 0f 20 d2 6c       	call   0x6cd2:0x200f
    6c64:	c9                   	leave
    6c65:	ca 06 00             	retf   0x6
    6c68:	c8 04 00 00          	enter  0x4,0x0
    6c6c:	8d 7e fc             	lea    di,[bp-0x4]
    6c6f:	16                   	push   ss
    6c70:	57                   	push   di
    6c71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c74:	06                   	push   es
    6c75:	57                   	push   di
    6c76:	9a 35 66 a9 6c       	call   0x6ca9:0x6635
    6c7b:	08 c0                	or     al,al
    6c7d:	74 0e                	je     0x6c8d
    6c7f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    6c82:	f7 d8                	neg    ax
    6c84:	18 c0                	sbb    al,al
    6c86:	f6 d8                	neg    al
    6c88:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    6c8b:	eb 04                	jmp    0x6c91
    6c8d:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    6c91:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    6c94:	c9                   	leave
    6c95:	ca 04 00             	retf   0x4
    6c98:	c8 02 00 00          	enter  0x2,0x0
    6c9c:	8d 7e fe             	lea    di,[bp-0x2]
    6c9f:	16                   	push   ss
    6ca0:	57                   	push   di
    6ca1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ca4:	06                   	push   es
    6ca5:	57                   	push   di
    6ca6:	9a 35 66 89 6d       	call   0x6d89:0x6635
    6cab:	08 c0                	or     al,al
    6cad:	74 27                	je     0x6cd6
    6caf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6cb2:	f7 d8                	neg    ax
    6cb4:	18 c0                	sbb    al,al
    6cb6:	f6 d8                	neg    al
    6cb8:	98                   	cbw
    6cb9:	c1 e0 04             	shl    ax,0x4
    6cbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6cbf:	03 f8                	add    di,ax
    6cc1:	81 c7 64 00          	add    di,0x64
    6cc5:	06                   	push   es
    6cc6:	57                   	push   di
    6cc7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6cca:	06                   	push   es
    6ccb:	57                   	push   di
    6ccc:	68 ff 00             	push   0xff
    6ccf:	9a e7 17 27 6d       	call   0x6d27:0x17e7
    6cd4:	eb 07                	jmp    0x6cdd
    6cd6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6cd9:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    6cdd:	c9                   	leave
    6cde:	ca 04 00             	retf   0x4
    6ce1:	c8 02 00 00          	enter  0x2,0x0
    6ce5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ce8:	26 8a 45 64          	mov    al,BYTE PTR es:[di+0x64]
    6cec:	26 3a 45 74          	cmp    al,BYTE PTR es:[di+0x74]
    6cf0:	76 0b                	jbe    0x6cfd
    6cf2:	26 8a 45 64          	mov    al,BYTE PTR es:[di+0x64]
    6cf6:	30 e4                	xor    ah,ah
    6cf8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6cfb:	eb 0c                	jmp    0x6d09
    6cfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d00:	26 8a 45 74          	mov    al,BYTE PTR es:[di+0x74]
    6d04:	30 e4                	xor    ah,ah
    6d06:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6d09:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6d0c:	c9                   	leave
    6d0d:	ca 04 00             	retf   0x4
    6d10:	55                   	push   bp
    6d11:	89 e5                	mov    bp,sp
    6d13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d16:	26 c4 7d 60          	les    di,DWORD PTR es:[di+0x60]
    6d1a:	06                   	push   es
    6d1b:	57                   	push   di
    6d1c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6d1f:	06                   	push   es
    6d20:	57                   	push   di
    6d21:	68 ff 00             	push   0xff
    6d24:	9a e7 17 4d 6d       	call   0x6d4d:0x17e7
    6d29:	c9                   	leave
    6d2a:	ca 04 00             	retf   0x4
    6d2d:	c8 00 01 00          	enter  0x100,0x0
    6d31:	8d be 00 ff          	lea    di,[bp-0x100]
    6d35:	16                   	push   ss
    6d36:	57                   	push   di
    6d37:	68 26 f2             	push   0xf226
    6d3a:	9a 2b 09 5b 6d       	call   0x6d5b:0x92b
    6d3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d42:	81 c7 64 00          	add    di,0x64
    6d46:	06                   	push   es
    6d47:	57                   	push   di
    6d48:	6a 0f                	push   0xf
    6d4a:	9a e7 17 6b 6d       	call   0x6d6b:0x17e7
    6d4f:	8d be 00 ff          	lea    di,[bp-0x100]
    6d53:	16                   	push   ss
    6d54:	57                   	push   di
    6d55:	68 27 f2             	push   0xf227
    6d58:	9a 2b 09 02 6e       	call   0x6e02:0x92b
    6d5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d60:	81 c7 74 00          	add    di,0x74
    6d64:	06                   	push   es
    6d65:	57                   	push   di
    6d66:	6a 0f                	push   0xf
    6d68:	9a e7 17 fd 6d       	call   0x6dfd:0x17e7
    6d6d:	c9                   	leave
    6d6e:	ca 04 00             	retf   0x4
    6d71:	c8 02 00 00          	enter  0x2,0x0
    6d75:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    6d78:	98                   	cbw
    6d79:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6d7c:	8d 7e fe             	lea    di,[bp-0x2]
    6d7f:	16                   	push   ss
    6d80:	57                   	push   di
    6d81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d84:	06                   	push   es
    6d85:	57                   	push   di
    6d86:	9a de 6b 6e 6e       	call   0x6e6e:0x6bde
    6d8b:	c9                   	leave
    6d8c:	ca 06 00             	retf   0x6
    6d8f:	c8 12 02 00          	enter  0x212,0x0
    6d93:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6d96:	26 8a 05             	mov    al,BYTE PTR es:[di]
    6d99:	30 e4                	xor    ah,ah
    6d9b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6d9e:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    6da2:	75 3d                	jne    0x6de1
    6da4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6da7:	26 80 7d 64 00       	cmp    BYTE PTR es:[di+0x64],0x0
    6dac:	75 0d                	jne    0x6dbb
    6dae:	6a 00                	push   0x0
    6db0:	06                   	push   es
    6db1:	57                   	push   di
    6db2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6db5:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    6db9:	eb 23                	jmp    0x6dde
    6dbb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dbe:	26 80 7d 74 00       	cmp    BYTE PTR es:[di+0x74],0x0
    6dc3:	75 0d                	jne    0x6dd2
    6dc5:	6a 01                	push   0x1
    6dc7:	06                   	push   es
    6dc8:	57                   	push   di
    6dc9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6dcc:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    6dd0:	eb 0c                	jmp    0x6dde
    6dd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dd5:	06                   	push   es
    6dd6:	57                   	push   di
    6dd7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6dda:	26 ff 5d 6c          	call   DWORD PTR es:[di+0x6c]
    6dde:	e9 b1 00             	jmp    0x6e92
    6de1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6de4:	06                   	push   es
    6de5:	57                   	push   di
    6de6:	8d be fe fe          	lea    di,[bp-0x102]
    6dea:	16                   	push   ss
    6deb:	57                   	push   di
    6dec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6def:	81 c7 64 00          	add    di,0x64
    6df3:	06                   	push   es
    6df4:	57                   	push   di
    6df5:	6a 01                	push   0x1
    6df7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6dfa:	9a 0b 18 34 6e       	call   0x6e34:0x180b
    6dff:	9a ed 07 39 6e       	call   0x6e39:0x7ed
    6e04:	09 c0                	or     ax,ax
    6e06:	75 10                	jne    0x6e18
    6e08:	6a 00                	push   0x0
    6e0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e0d:	06                   	push   es
    6e0e:	57                   	push   di
    6e0f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6e12:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    6e16:	eb 7a                	jmp    0x6e92
    6e18:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6e1b:	06                   	push   es
    6e1c:	57                   	push   di
    6e1d:	8d be fe fd          	lea    di,[bp-0x202]
    6e21:	16                   	push   ss
    6e22:	57                   	push   di
    6e23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e26:	81 c7 74 00          	add    di,0x74
    6e2a:	06                   	push   es
    6e2b:	57                   	push   di
    6e2c:	6a 01                	push   0x1
    6e2e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    6e31:	9a 0b 18 ad 6e       	call   0x6ead:0x180b
    6e36:	9a ed 07 c5 6e       	call   0x6ec5:0x7ed
    6e3b:	09 c0                	or     ax,ax
    6e3d:	75 10                	jne    0x6e4f
    6e3f:	6a 01                	push   0x1
    6e41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e44:	06                   	push   es
    6e45:	57                   	push   di
    6e46:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6e49:	26 ff 5d 54          	call   DWORD PTR es:[di+0x54]
    6e4d:	eb 43                	jmp    0x6e92
    6e4f:	68 11 f2             	push   0xf211
    6e52:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6e55:	89 f8                	mov    ax,di
    6e57:	8c c2                	mov    dx,es
    6e59:	89 86 ee fd          	mov    WORD PTR [bp-0x212],ax
    6e5d:	89 96 f0 fd          	mov    WORD PTR [bp-0x210],dx
    6e61:	c6 86 f2 fd 04       	mov    BYTE PTR [bp-0x20e],0x4
    6e66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e69:	06                   	push   es
    6e6a:	57                   	push   di
    6e6b:	9a f6 67 90 6e       	call   0x6e90:0x67f6
    6e70:	89 c7                	mov    di,ax
    6e72:	8e c2                	mov    es,dx
    6e74:	89 f8                	mov    ax,di
    6e76:	8c c2                	mov    dx,es
    6e78:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    6e7c:	89 96 f8 fd          	mov    WORD PTR [bp-0x208],dx
    6e80:	c6 86 fa fd 04       	mov    BYTE PTR [bp-0x206],0x4
    6e85:	8d be ee fd          	lea    di,[bp-0x212]
    6e89:	16                   	push   ss
    6e8a:	57                   	push   di
    6e8b:	6a 01                	push   0x1
    6e8d:	9a 0a 12 52 6f       	call   0x6f52:0x120a
    6e92:	c9                   	leave
    6e93:	ca 08 00             	retf   0x8
    6e96:	01 3b                	add    WORD PTR [bp+di],di
    6e98:	c8 02 01 00          	enter  0x102,0x0
    6e9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e9f:	26 c4 7d 60          	les    di,DWORD PTR es:[di+0x60]
    6ea3:	06                   	push   es
    6ea4:	57                   	push   di
    6ea5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6ea8:	06                   	push   es
    6ea9:	57                   	push   di
    6eaa:	9a be 18 e9 6e       	call   0x6ee9:0x18be
    6eaf:	75 03                	jne    0x6eb4
    6eb1:	e9 a0 00             	jmp    0x6f54
    6eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6eb7:	81 c7 60 00          	add    di,0x60
    6ebb:	06                   	push   es
    6ebc:	57                   	push   di
    6ebd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6ec0:	06                   	push   es
    6ec1:	57                   	push   di
    6ec2:	9a 51 06 c2 6f       	call   0x6fc2:0x651
    6ec7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6eca:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    6ece:	75 0c                	jne    0x6edc
    6ed0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ed3:	06                   	push   es
    6ed4:	57                   	push   di
    6ed5:	9a 2d 6d f5 6f       	call   0x6ff5:0x6d2d
    6eda:	eb 6c                	jmp    0x6f48
    6edc:	bf 96 6e             	mov    di,0x6e96
    6edf:	0e                   	push   cs
    6ee0:	57                   	push   di
    6ee1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6ee4:	06                   	push   es
    6ee5:	57                   	push   di
    6ee6:	9a 78 18 0f 6f       	call   0x6f0f:0x1878
    6eeb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    6eee:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    6ef2:	75 05                	jne    0x6ef9
    6ef4:	c7 46 fe 00 01       	mov    WORD PTR [bp-0x2],0x100
    6ef9:	8d be fe fe          	lea    di,[bp-0x102]
    6efd:	16                   	push   ss
    6efe:	57                   	push   di
    6eff:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6f02:	06                   	push   es
    6f03:	57                   	push   di
    6f04:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6f07:	40                   	inc    ax
    6f08:	50                   	push   ax
    6f09:	68 ff 00             	push   0xff
    6f0c:	9a 0b 18 1f 6f       	call   0x6f1f:0x180b
    6f11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f14:	81 c7 64 00          	add    di,0x64
    6f18:	06                   	push   es
    6f19:	57                   	push   di
    6f1a:	6a 0f                	push   0xf
    6f1c:	9a e7 17 36 6f       	call   0x6f36:0x17e7
    6f21:	8d be fe fe          	lea    di,[bp-0x102]
    6f25:	16                   	push   ss
    6f26:	57                   	push   di
    6f27:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    6f2a:	06                   	push   es
    6f2b:	57                   	push   di
    6f2c:	6a 01                	push   0x1
    6f2e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    6f31:	48                   	dec    ax
    6f32:	50                   	push   ax
    6f33:	9a 0b 18 46 6f       	call   0x6f46:0x180b
    6f38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f3b:	81 c7 74 00          	add    di,0x74
    6f3f:	06                   	push   es
    6f40:	57                   	push   di
    6f41:	6a 0f                	push   0xf
    6f43:	9a e7 17 67 6f       	call   0x6f67:0x17e7
    6f48:	6a 01                	push   0x1
    6f4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f4d:	06                   	push   es
    6f4e:	57                   	push   di
    6f4f:	9a 7c 6a 7a 6f       	call   0x6f7a:0x6a7c
    6f54:	c9                   	leave
    6f55:	ca 08 00             	retf   0x8
    6f58:	55                   	push   bp
    6f59:	89 e5                	mov    bp,sp
    6f5b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6f5f:	74 08                	je     0x6f69
    6f61:	83 ec 08             	sub    sp,0x8
    6f64:	9a e2 1f da 6f       	call   0x6fda:0x1fe2
    6f69:	ff 76 0e             	push   WORD PTR [bp+0xe]
    6f6c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    6f6f:	31 c0                	xor    ax,ax
    6f71:	50                   	push   ax
    6f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f75:	06                   	push   es
    6f76:	57                   	push   di
    6f77:	9a ee 5f 86 6f       	call   0x6f86:0x5fee
    6f7c:	6a 0b                	push   0xb
    6f7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f81:	06                   	push   es
    6f82:	57                   	push   di
    6f83:	9a 85 6e cf 6f       	call   0x6fcf:0x6e85
    6f88:	a1 16 17             	mov    ax,ds:0x1716
    6f8b:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    6f8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f92:	26 89 45 60          	mov    WORD PTR es:[di+0x60],ax
    6f96:	26 89 55 62          	mov    WORD PTR es:[di+0x62],dx
    6f9a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6f9e:	74 07                	je     0x6fa7
    6fa0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    6fa4:	83 c4 06             	add    sp,0x6
    6fa7:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    6faa:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    6fad:	c9                   	leave
    6fae:	ca 0a 00             	retf   0xa
    6fb1:	55                   	push   bp
    6fb2:	89 e5                	mov    bp,sp
    6fb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fb7:	26 ff 75 62          	push   WORD PTR es:[di+0x62]
    6fbb:	26 ff 75 60          	push   WORD PTR es:[di+0x60]
    6fbf:	9a 24 06 fa 70       	call   0x70fa:0x624
    6fc4:	31 c0                	xor    ax,ax
    6fc6:	50                   	push   ax
    6fc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fca:	06                   	push   es
    6fcb:	57                   	push   di
    6fcc:	9a 5e 60 1e 71       	call   0x711e:0x605e
    6fd1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    6fd5:	74 05                	je     0x6fdc
    6fd7:	9a 0f 20 65 70       	call   0x7065:0x200f
    6fdc:	c9                   	leave
    6fdd:	ca 06 00             	retf   0x6
    6fe0:	00 00                	add    BYTE PTR [bx+si],al
    6fe2:	00 00                	add    BYTE PTR [bx+si],al
    6fe4:	c8 08 00 00          	enter  0x8,0x0
    6fe8:	8d 7e f8             	lea    di,[bp-0x8]
    6feb:	16                   	push   ss
    6fec:	57                   	push   di
    6fed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ff0:	06                   	push   es
    6ff1:	57                   	push   di
    6ff2:	9a 0d 71 7c 70       	call   0x707c:0x710d
    6ff7:	08 c0                	or     al,al
    6ff9:	75 0c                	jne    0x7007
    6ffb:	9b 2e d9 06 e0 6f    	fld    DWORD PTR cs:0x6fe0
    7001:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    7005:	90                   	nop
    7006:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    700b:	90                   	nop
    700c:	9b                   	fwait
    700d:	c9                   	leave
    700e:	ca 04 00             	retf   0x4
    7011:	c8 08 00 00          	enter  0x8,0x0
    7015:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7018:	06                   	push   es
    7019:	57                   	push   di
    701a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    701d:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    7021:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    7025:	90                   	nop
    7026:	9b 9b dd 46 f8       	fld    QWORD PTR [bp-0x8]
    702b:	90                   	nop
    702c:	9b                   	fwait
    702d:	c9                   	leave
    702e:	ca 04 00             	retf   0x4
    7031:	55                   	push   bp
    7032:	89 e5                	mov    bp,sp
    7034:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7037:	06                   	push   es
    7038:	57                   	push   di
    7039:	68 ff 00             	push   0xff
    703c:	6a 00                	push   0x0
    703e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7041:	06                   	push   es
    7042:	57                   	push   di
    7043:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7046:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    704a:	c9                   	leave
    704b:	ca 04 00             	retf   0x4
    704e:	55                   	push   bp
    704f:	89 e5                	mov    bp,sp
    7051:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7054:	26 c4 7d 60          	les    di,DWORD PTR es:[di+0x60]
    7058:	06                   	push   es
    7059:	57                   	push   di
    705a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    705d:	06                   	push   es
    705e:	57                   	push   di
    705f:	68 ff 00             	push   0xff
    7062:	9a e7 17 54 71       	call   0x7154:0x17e7
    7067:	c9                   	leave
    7068:	ca 04 00             	retf   0x4
    706b:	c8 0c 00 00          	enter  0xc,0x0
    706f:	8d 7e f4             	lea    di,[bp-0xc]
    7072:	16                   	push   ss
    7073:	57                   	push   di
    7074:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7077:	06                   	push   es
    7078:	57                   	push   di
    7079:	9a 0d 71 dd 72       	call   0x72dd:0x710d
    707e:	08 c0                	or     al,al
    7080:	74 7c                	je     0x70fe
    7082:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7086:	74 20                	je     0x70a8
    7088:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    708b:	26 c4 7d 60          	les    di,DWORD PTR es:[di+0x60]
    708f:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    7093:	74 13                	je     0x70a8
    7095:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7098:	26 8b 45 60          	mov    ax,WORD PTR es:[di+0x60]
    709c:	26 8b 55 62          	mov    dx,WORD PTR es:[di+0x62]
    70a0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    70a3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    70a6:	eb 36                	jmp    0x70de
    70a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    70ab:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    70af:	3c 09                	cmp    al,0x9
    70b1:	75 0d                	jne    0x70c0
    70b3:	b8 66 2c             	mov    ax,0x2c66
    70b6:	8c da                	mov    dx,ds
    70b8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    70bb:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    70be:	eb 1e                	jmp    0x70de
    70c0:	3c 0a                	cmp    al,0xa
    70c2:	75 0d                	jne    0x70d1
    70c4:	b8 b8 2c             	mov    ax,0x2cb8
    70c7:	8c da                	mov    dx,ds
    70c9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    70cc:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    70cf:	eb 0d                	jmp    0x70de
    70d1:	a1 16 17             	mov    ax,ds:0x1716
    70d4:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    70d8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    70db:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    70de:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    70e1:	06                   	push   es
    70e2:	57                   	push   di
    70e3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    70e6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    70e9:	06                   	push   es
    70ea:	57                   	push   di
    70eb:	ff 76 fa             	push   WORD PTR [bp-0x6]
    70ee:	ff 76 f8             	push   WORD PTR [bp-0x8]
    70f1:	ff 76 f6             	push   WORD PTR [bp-0xa]
    70f4:	ff 76 f4             	push   WORD PTR [bp-0xc]
    70f7:	9a 9c 1c 34 72       	call   0x7234:0x1c9c
    70fc:	eb 07                	jmp    0x7105
    70fe:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    7101:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    7105:	c9                   	leave
    7106:	ca 0c 00             	retf   0xc
    7109:	80 cb a4             	or     bl,0xa4
    710c:	4c                   	dec    sp
    710d:	c8 0a 00 00          	enter  0xa,0x0
    7111:	8d 7e f6             	lea    di,[bp-0xa]
    7114:	16                   	push   ss
    7115:	57                   	push   di
    7116:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7119:	06                   	push   es
    711a:	57                   	push   di
    711b:	9a 35 66 e1 71       	call   0x71e1:0x6635
    7120:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    7123:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    7127:	74 50                	je     0x7179
    7129:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    712c:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    7130:	3c 09                	cmp    al,0x9
    7132:	75 0f                	jne    0x7143
    7134:	9b db 46 f6          	fild   DWORD PTR [bp-0xa]
    7138:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    713b:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    713f:	90                   	nop
    7140:	9b                   	fwait
    7141:	eb 36                	jmp    0x7179
    7143:	3c 0a                	cmp    al,0xa
    7145:	75 1a                	jne    0x7161
    7147:	9b db 46 f6          	fild   DWORD PTR [bp-0xa]
    714b:	9b 2e d9 06 09 71    	fld    DWORD PTR cs:0x7109
    7151:	9a b2 04 6e 71       	call   0x716e:0x4b2
    7156:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7159:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    715d:	90                   	nop
    715e:	9b                   	fwait
    715f:	eb 18                	jmp    0x7179
    7161:	9b dd 46 f6          	fld    QWORD PTR [bp-0xa]
    7165:	9b 2e d9 06 09 71    	fld    DWORD PTR cs:0x7109
    716b:	9a b2 04 9a 71       	call   0x719a:0x4b2
    7170:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7173:	9b 26 dd 1d          	fstp   QWORD PTR es:[di]
    7177:	90                   	nop
    7178:	9b                   	fwait
    7179:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    717c:	c9                   	leave
    717d:	ca 08 00             	retf   0x8
    7180:	80 cb a4             	or     bl,0xa4
    7183:	4c                   	dec    sp
    7184:	c8 08 00 00          	enter  0x8,0x0
    7188:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    718b:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    718f:	3c 09                	cmp    al,0x9
    7191:	75 11                	jne    0x71a4
    7193:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    7197:	9a 0e 10 af 71       	call   0x71af:0x100e
    719c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    719f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    71a2:	eb 30                	jmp    0x71d4
    71a4:	3c 0a                	cmp    al,0xa
    71a6:	75 1c                	jne    0x71c4
    71a8:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    71ac:	9a 57 10 ba 71       	call   0x71ba:0x1057
    71b1:	9b 2e d8 0e 80 71    	fmul   DWORD PTR cs:0x7180
    71b7:	9a 2f 10 94 72       	call   0x7294:0x102f
    71bc:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    71bf:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    71c2:	eb 10                	jmp    0x71d4
    71c4:	9b dd 46 0a          	fld    QWORD PTR [bp+0xa]
    71c8:	9b 2e d8 0e 80 71    	fmul   DWORD PTR cs:0x7180
    71ce:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    71d2:	90                   	nop
    71d3:	9b                   	fwait
    71d4:	8d 7e f8             	lea    di,[bp-0x8]
    71d7:	16                   	push   ss
    71d8:	57                   	push   di
    71d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71dc:	06                   	push   es
    71dd:	57                   	push   di
    71de:	9a de 6b b5 72       	call   0x72b5:0x6bde
    71e3:	c9                   	leave
    71e4:	ca 0c 00             	retf   0xc
    71e7:	55                   	push   bp
    71e8:	89 e5                	mov    bp,sp
    71ea:	ff 76 10             	push   WORD PTR [bp+0x10]
    71ed:	ff 76 0e             	push   WORD PTR [bp+0xe]
    71f0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    71f3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    71f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    71f9:	06                   	push   es
    71fa:	57                   	push   di
    71fb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    71fe:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    7202:	c9                   	leave
    7203:	ca 0c 00             	retf   0xc
    7206:	c8 08 00 00          	enter  0x8,0x0
    720a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    720d:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    7211:	75 0e                	jne    0x7221
    7213:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7216:	06                   	push   es
    7217:	57                   	push   di
    7218:	26 c4 3d             	les    di,DWORD PTR es:[di]
    721b:	26 ff 5d 6c          	call   DWORD PTR es:[di+0x6c]
    721f:	eb 5b                	jmp    0x727c
    7221:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7224:	26 8a 45 22          	mov    al,BYTE PTR es:[di+0x22]
    7228:	3c 09                	cmp    al,0x9
    722a:	75 12                	jne    0x723e
    722c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    722f:	06                   	push   es
    7230:	57                   	push   di
    7231:	9a 54 21 4a 72       	call   0x724a:0x2154
    7236:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    723a:	90                   	nop
    723b:	9b                   	fwait
    723c:	eb 26                	jmp    0x7264
    723e:	3c 0a                	cmp    al,0xa
    7240:	75 12                	jne    0x7254
    7242:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7245:	06                   	push   es
    7246:	57                   	push   di
    7247:	9a b2 21 5c 72       	call   0x725c:0x21b2
    724c:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    7250:	90                   	nop
    7251:	9b                   	fwait
    7252:	eb 10                	jmp    0x7264
    7254:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7257:	06                   	push   es
    7258:	57                   	push   di
    7259:	9a 14 22 a9 72       	call   0x72a9:0x2214
    725e:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    7262:	90                   	nop
    7263:	9b                   	fwait
    7264:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7267:	ff 76 fc             	push   WORD PTR [bp-0x4]
    726a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    726d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    7270:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7273:	06                   	push   es
    7274:	57                   	push   di
    7275:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7278:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    727c:	c9                   	leave
    727d:	ca 08 00             	retf   0x8
    7280:	55                   	push   bp
    7281:	89 e5                	mov    bp,sp
    7283:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7286:	26 c4 7d 60          	les    di,DWORD PTR es:[di+0x60]
    728a:	06                   	push   es
    728b:	57                   	push   di
    728c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    728f:	06                   	push   es
    7290:	57                   	push   di
    7291:	9a be 18 ca 72       	call   0x72ca:0x18be
    7296:	74 1f                	je     0x72b7
    7298:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    729b:	81 c7 60 00          	add    di,0x60
    729f:	06                   	push   es
    72a0:	57                   	push   di
    72a1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    72a4:	06                   	push   es
    72a5:	57                   	push   di
    72a6:	9a 51 06 47 7a       	call   0x7a47:0x651
    72ab:	6a 00                	push   0x0
    72ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72b0:	06                   	push   es
    72b1:	57                   	push   di
    72b2:	9a 7c 6a e9 72       	call   0x72e9:0x6a7c
    72b7:	c9                   	leave
    72b8:	ca 08 00             	retf   0x8
    72bb:	55                   	push   bp
    72bc:	89 e5                	mov    bp,sp
    72be:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    72c2:	74 08                	je     0x72cc
    72c4:	83 ec 08             	sub    sp,0x8
    72c7:	9a e2 1f 11 73       	call   0x7311:0x1fe2
    72cc:	ff 76 0e             	push   WORD PTR [bp+0xe]
    72cf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    72d2:	31 c0                	xor    ax,ax
    72d4:	50                   	push   ax
    72d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72d8:	06                   	push   es
    72d9:	57                   	push   di
    72da:	9a 58 6f 24 73       	call   0x7324:0x6f58
    72df:	6a 09                	push   0x9
    72e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    72e4:	06                   	push   es
    72e5:	57                   	push   di
    72e6:	9a 85 6e 30 73       	call   0x7330:0x6e85
    72eb:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    72ef:	74 07                	je     0x72f8
    72f1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    72f5:	83 c4 06             	add    sp,0x6
    72f8:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    72fb:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    72fe:	c9                   	leave
    72ff:	ca 0a 00             	retf   0xa
    7302:	55                   	push   bp
    7303:	89 e5                	mov    bp,sp
    7305:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7309:	74 08                	je     0x7313
    730b:	83 ec 08             	sub    sp,0x8
    730e:	9a e2 1f 58 73       	call   0x7358:0x1fe2
    7313:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7316:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7319:	31 c0                	xor    ax,ax
    731b:	50                   	push   ax
    731c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    731f:	06                   	push   es
    7320:	57                   	push   di
    7321:	9a 58 6f 2b 74       	call   0x742b:0x6f58
    7326:	6a 0a                	push   0xa
    7328:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    732b:	06                   	push   es
    732c:	57                   	push   di
    732d:	9a 85 6e 6b 73       	call   0x736b:0x6e85
    7332:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7336:	74 07                	je     0x733f
    7338:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    733c:	83 c4 06             	add    sp,0x6
    733f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7342:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    7345:	c9                   	leave
    7346:	ca 0a 00             	retf   0xa
    7349:	55                   	push   bp
    734a:	89 e5                	mov    bp,sp
    734c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7350:	74 08                	je     0x735a
    7352:	83 ec 08             	sub    sp,0x8
    7355:	9a e2 1f 9f 73       	call   0x739f:0x1fe2
    735a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    735d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7360:	31 c0                	xor    ax,ax
    7362:	50                   	push   ax
    7363:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7366:	06                   	push   es
    7367:	57                   	push   di
    7368:	9a ee 5f 77 73       	call   0x7377:0x5fee
    736d:	6a 0c                	push   0xc
    736f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7372:	06                   	push   es
    7373:	57                   	push   di
    7374:	9a 85 6e b2 73       	call   0x73b2:0x6e85
    7379:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    737d:	74 07                	je     0x7386
    737f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7383:	83 c4 06             	add    sp,0x6
    7386:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7389:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    738c:	c9                   	leave
    738d:	ca 0a 00             	retf   0xa
    7390:	55                   	push   bp
    7391:	89 e5                	mov    bp,sp
    7393:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7397:	74 08                	je     0x73a1
    7399:	83 ec 08             	sub    sp,0x8
    739c:	9a e2 1f e6 73       	call   0x73e6:0x1fe2
    73a1:	ff 76 0e             	push   WORD PTR [bp+0xe]
    73a4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    73a7:	31 c0                	xor    ax,ax
    73a9:	50                   	push   ax
    73aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73ad:	06                   	push   es
    73ae:	57                   	push   di
    73af:	9a ee 5f be 73       	call   0x73be:0x5fee
    73b4:	6a 0d                	push   0xd
    73b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73b9:	06                   	push   es
    73ba:	57                   	push   di
    73bb:	9a 85 6e f9 73       	call   0x73f9:0x6e85
    73c0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    73c4:	74 07                	je     0x73cd
    73c6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    73ca:	83 c4 06             	add    sp,0x6
    73cd:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    73d0:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    73d3:	c9                   	leave
    73d4:	ca 0a 00             	retf   0xa
    73d7:	55                   	push   bp
    73d8:	89 e5                	mov    bp,sp
    73da:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    73de:	74 08                	je     0x73e8
    73e0:	83 ec 08             	sub    sp,0x8
    73e3:	9a e2 1f 32 74       	call   0x7432:0x1fe2
    73e8:	ff 76 0e             	push   WORD PTR [bp+0xe]
    73eb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    73ee:	31 c0                	xor    ax,ax
    73f0:	50                   	push   ax
    73f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    73f4:	06                   	push   es
    73f5:	57                   	push   di
    73f6:	9a ee 5f 05 74       	call   0x7405:0x5fee
    73fb:	6a 0e                	push   0xe
    73fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7400:	06                   	push   es
    7401:	57                   	push   di
    7402:	9a 85 6e f6 74       	call   0x74f6:0x6e85
    7407:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    740b:	74 07                	je     0x7414
    740d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7411:	83 c4 06             	add    sp,0x6
    7414:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7417:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    741a:	c9                   	leave
    741b:	ca 0a 00             	retf   0xa
    741e:	55                   	push   bp
    741f:	89 e5                	mov    bp,sp
    7421:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7424:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7427:	bf 81 12             	mov    di,0x1281
    742a:	b8 46 74             	mov    ax,0x7446
    742d:	50                   	push   ax
    742e:	57                   	push   di
    742f:	9a 55 22 5c 74       	call   0x745c:0x2255
    7434:	08 c0                	or     al,al
    7436:	74 13                	je     0x744b
    7438:	ff 76 0c             	push   WORD PTR [bp+0xc]
    743b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    743e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7441:	06                   	push   es
    7442:	57                   	push   di
    7443:	9a e6 76 70 74       	call   0x7470:0x76e6
    7448:	e9 ad 00             	jmp    0x74f8
    744b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    744e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7451:	bf 2a 03             	mov    di,0x32a
    7454:	b8 09 75             	mov    ax,0x7509
    7457:	50                   	push   ax
    7458:	57                   	push   di
    7459:	9a 55 22 86 74       	call   0x7486:0x2255
    745e:	08 c0                	or     al,al
    7460:	74 13                	je     0x7475
    7462:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7465:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7468:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    746b:	06                   	push   es
    746c:	57                   	push   di
    746d:	9a 47 77 9a 74       	call   0x749a:0x7747
    7472:	e9 83 00             	jmp    0x74f8
    7475:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7478:	ff 76 0a             	push   WORD PTR [bp+0xa]
    747b:	bf 3f 08             	mov    di,0x83f
    747e:	b8 a8 74             	mov    ax,0x74a8
    7481:	50                   	push   ax
    7482:	57                   	push   di
    7483:	9a 55 22 af 74       	call   0x74af:0x2255
    7488:	08 c0                	or     al,al
    748a:	74 12                	je     0x749e
    748c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    748f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7492:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7495:	06                   	push   es
    7496:	57                   	push   di
    7497:	9a 05 76 e4 74       	call   0x74e4:0x7605
    749c:	eb 5a                	jmp    0x74f8
    749e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    74a1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    74a4:	bf c6 06             	mov    di,0x6c6
    74a7:	b8 c4 74             	mov    ax,0x74c4
    74aa:	50                   	push   ax
    74ab:	57                   	push   di
    74ac:	9a 55 22 cb 74       	call   0x74cb:0x2255
    74b1:	08 c0                	or     al,al
    74b3:	74 33                	je     0x74e8
    74b5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    74b8:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    74bc:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    74c0:	bf 3f 08             	mov    di,0x83f
    74c3:	b8 32 75             	mov    ax,0x7532
    74c6:	50                   	push   ax
    74c7:	57                   	push   di
    74c8:	9a 55 22 10 75       	call   0x7510:0x2255
    74cd:	08 c0                	or     al,al
    74cf:	74 17                	je     0x74e8
    74d1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    74d4:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    74d8:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    74dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74df:	06                   	push   es
    74e0:	57                   	push   di
    74e1:	9a 05 76 24 75       	call   0x7524:0x7605
    74e6:	eb 10                	jmp    0x74f8
    74e8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    74eb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    74ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    74f1:	06                   	push   es
    74f2:	57                   	push   di
    74f3:	9a 1d 61 e3 75       	call   0x75e3:0x611d
    74f8:	c9                   	leave
    74f9:	ca 08 00             	retf   0x8
    74fc:	55                   	push   bp
    74fd:	89 e5                	mov    bp,sp
    74ff:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7502:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7505:	bf 2a 03             	mov    di,0x32a
    7508:	b8 8e 75             	mov    ax,0x758e
    750b:	50                   	push   ax
    750c:	57                   	push   di
    750d:	9a 55 22 39 75       	call   0x7539:0x2255
    7512:	08 c0                	or     al,al
    7514:	74 12                	je     0x7528
    7516:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7519:	ff 76 0a             	push   WORD PTR [bp+0xa]
    751c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    751f:	06                   	push   es
    7520:	57                   	push   di
    7521:	9a d5 78 4d 75       	call   0x754d:0x78d5
    7526:	eb 68                	jmp    0x7590
    7528:	ff 76 0c             	push   WORD PTR [bp+0xc]
    752b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    752e:	bf 3f 08             	mov    di,0x83f
    7531:	b8 5b 75             	mov    ax,0x755b
    7534:	50                   	push   ax
    7535:	57                   	push   di
    7536:	9a 55 22 62 75       	call   0x7562:0x2255
    753b:	08 c0                	or     al,al
    753d:	74 12                	je     0x7551
    753f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7542:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7545:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7548:	06                   	push   es
    7549:	57                   	push   di
    754a:	9a aa 77 7c 75       	call   0x757c:0x77aa
    754f:	eb 3f                	jmp    0x7590
    7551:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7554:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7557:	bf c6 06             	mov    di,0x6c6
    755a:	b8 70 75             	mov    ax,0x7570
    755d:	50                   	push   ax
    755e:	57                   	push   di
    755f:	9a 55 22 b8 75       	call   0x75b8:0x2255
    7564:	08 c0                	or     al,al
    7566:	74 18                	je     0x7580
    7568:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    756b:	06                   	push   es
    756c:	57                   	push   di
    756d:	9a be 42 ff ff       	call   0xffff:0x42be
    7572:	52                   	push   dx
    7573:	50                   	push   ax
    7574:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7577:	06                   	push   es
    7578:	57                   	push   di
    7579:	9a aa 77 a6 75       	call   0x75a6:0x77aa
    757e:	eb 10                	jmp    0x7590
    7580:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7583:	ff 76 0a             	push   WORD PTR [bp+0xa]
    7586:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7589:	06                   	push   es
    758a:	57                   	push   di
    758b:	9a cd 11 80 76       	call   0x7680:0x11cd
    7590:	c9                   	leave
    7591:	ca 08 00             	retf   0x8
    7594:	55                   	push   bp
    7595:	89 e5                	mov    bp,sp
    7597:	ff 76 08             	push   WORD PTR [bp+0x8]
    759a:	ff 76 06             	push   WORD PTR [bp+0x6]
    759d:	6a 01                	push   0x1
    759f:	b0 01                	mov    al,0x1
    75a1:	50                   	push   ax
    75a2:	b8 e4 14             	mov    ax,0x14e4
    75a5:	ba ad 75             	mov    dx,0x75ad
    75a8:	52                   	push   dx
    75a9:	50                   	push   ax
    75aa:	9a c8 79 03 76       	call   0x7603:0x79c8
    75af:	89 c7                	mov    di,ax
    75b1:	8e c2                	mov    es,dx
    75b3:	06                   	push   es
    75b4:	57                   	push   di
    75b5:	9a 7f 1f d9 76       	call   0x76d9:0x1f7f
    75ba:	c9                   	leave
    75bb:	ca 04 00             	retf   0x4
    75be:	55                   	push   bp
    75bf:	89 e5                	mov    bp,sp
    75c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75c4:	26 80 7d 60 00       	cmp    BYTE PTR es:[di+0x60],0x0
    75c9:	74 30                	je     0x75fb
    75cb:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    75cf:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    75d3:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    75d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75da:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    75de:	06                   	push   es
    75df:	57                   	push   di
    75e0:	9a a7 45 60 79       	call   0x7960:0x45a7
    75e5:	52                   	push   dx
    75e6:	50                   	push   ax
    75e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75ea:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    75ee:	9a bd 05 c8 7a       	call   0x7ac8:0x5bd
    75f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    75f6:	26 c6 45 60 00       	mov    BYTE PTR es:[di+0x60],0x0
    75fb:	c9                   	leave
    75fc:	ca 04 00             	retf   0x4
    75ff:	00 00                	add    BYTE PTR [bx+si],al
    7601:	d1 76 18             	shl    WORD PTR [bp+0x18],1
    7604:	76 c8                	jbe    0x75ce
    7606:	0c 00                	or     al,0x0
    7608:	00 ff                	add    bh,bh
    760a:	76 08                	jbe    0x7614
    760c:	ff 76 06             	push   WORD PTR [bp+0x6]
    760f:	6a 01                	push   0x1
    7611:	b0 01                	mov    al,0x1
    7613:	50                   	push   ax
    7614:	b8 e4 14             	mov    ax,0x14e4
    7617:	ba 1f 76             	mov    dx,0x761f
    761a:	52                   	push   dx
    761b:	50                   	push   ax
    761c:	9a c8 79 e4 76       	call   0x76e4:0x79c8
    7621:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7624:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7627:	b8 ff 75             	mov    ax,0x75ff
    762a:	0e                   	push   cs
    762b:	50                   	push   ax
    762c:	55                   	push   bp
    762d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7631:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7635:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7638:	26 80 7d 22 10       	cmp    BYTE PTR es:[di+0x22],0x10
    763d:	75 74                	jne    0x76b3
    763f:	c7 46 f4 01 00       	mov    WORD PTR [bp-0xc],0x1
    7644:	c7 46 f6 00 01       	mov    WORD PTR [bp-0xa],0x100
    7649:	31 c0                	xor    ax,ax
    764b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    764e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7651:	8d 7e f4             	lea    di,[bp-0xc]
    7654:	16                   	push   ss
    7655:	57                   	push   di
    7656:	6a 00                	push   0x0
    7658:	6a 08                	push   0x8
    765a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    765d:	06                   	push   es
    765e:	57                   	push   di
    765f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7662:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    7666:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7669:	ff 76 fc             	push   WORD PTR [bp-0x4]
    766c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    766f:	06                   	push   es
    7670:	57                   	push   di
    7671:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7674:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    7678:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    767b:	06                   	push   es
    767c:	57                   	push   di
    767d:	9a 7e 23 9a 76       	call   0x769a:0x237e
    7682:	2d 08 00             	sub    ax,0x8
    7685:	83 da 00             	sbb    dx,0x0
    7688:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    768b:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    768e:	6a 00                	push   0x0
    7690:	6a 00                	push   0x0
    7692:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7695:	06                   	push   es
    7696:	57                   	push   di
    7697:	9a a4 23 e2 77       	call   0x77e2:0x23a4
    769c:	8d 7e f4             	lea    di,[bp-0xc]
    769f:	16                   	push   ss
    76a0:	57                   	push   di
    76a1:	6a 00                	push   0x0
    76a3:	6a 08                	push   0x8
    76a5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    76a8:	06                   	push   es
    76a9:	57                   	push   di
    76aa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    76ad:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    76b1:	eb 12                	jmp    0x76c5
    76b3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    76b6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    76b9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    76bc:	06                   	push   es
    76bd:	57                   	push   di
    76be:	26 c4 3d             	les    di,DWORD PTR es:[di]
    76c1:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    76c5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    76c9:	83 c4 06             	add    sp,0x6
    76cc:	b8 dc 76             	mov    ax,0x76dc
    76cf:	0e                   	push   cs
    76d0:	50                   	push   ax
    76d1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    76d4:	06                   	push   es
    76d5:	57                   	push   di
    76d6:	9a 7f 1f 3a 77       	call   0x773a:0x1f7f
    76db:	cb                   	retf
    76dc:	c9                   	leave
    76dd:	ca 08 00             	retf   0x8
    76e0:	00 00                	add    BYTE PTR [bx+si],al
    76e2:	32 77 f9             	xor    dh,BYTE PTR [bx-0x7]
    76e5:	76 c8                	jbe    0x76af
    76e7:	04 00                	add    al,0x0
    76e9:	00 ff                	add    bh,bh
    76eb:	76 08                	jbe    0x76f5
    76ed:	ff 76 06             	push   WORD PTR [bp+0x6]
    76f0:	6a 01                	push   0x1
    76f2:	b0 01                	mov    al,0x1
    76f4:	50                   	push   ax
    76f5:	b8 e4 14             	mov    ax,0x14e4
    76f8:	ba 00 77             	mov    dx,0x7700
    76fb:	52                   	push   dx
    76fc:	50                   	push   ax
    76fd:	9a c8 79 24 77       	call   0x7724:0x79c8
    7702:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7705:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7708:	b8 e0 76             	mov    ax,0x76e0
    770b:	0e                   	push   cs
    770c:	50                   	push   ax
    770d:	55                   	push   bp
    770e:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7712:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7716:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7719:	ff 76 fc             	push   WORD PTR [bp-0x4]
    771c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    771f:	06                   	push   es
    7720:	57                   	push   di
    7721:	9a 70 78 45 77       	call   0x7745:0x7870
    7726:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    772a:	83 c4 06             	add    sp,0x6
    772d:	b8 3d 77             	mov    ax,0x773d
    7730:	0e                   	push   cs
    7731:	50                   	push   ax
    7732:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7735:	06                   	push   es
    7736:	57                   	push   di
    7737:	9a 7f 1f 9d 77       	call   0x779d:0x1f7f
    773c:	cb                   	retf
    773d:	c9                   	leave
    773e:	ca 08 00             	retf   0x8
    7741:	00 00                	add    BYTE PTR [bx+si],al
    7743:	95                   	xchg   bp,ax
    7744:	77 5a                	ja     0x77a0
    7746:	77 c8                	ja     0x7710
    7748:	04 00                	add    al,0x0
    774a:	00 ff                	add    bh,bh
    774c:	76 08                	jbe    0x7756
    774e:	ff 76 06             	push   WORD PTR [bp+0x6]
    7751:	6a 01                	push   0x1
    7753:	b0 01                	mov    al,0x1
    7755:	50                   	push   ax
    7756:	b8 e4 14             	mov    ax,0x14e4
    7759:	ba 61 77             	mov    dx,0x7761
    775c:	52                   	push   dx
    775d:	50                   	push   ax
    775e:	9a c8 79 a8 77       	call   0x77a8:0x79c8
    7763:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7766:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7769:	b8 41 77             	mov    ax,0x7741
    776c:	0e                   	push   cs
    776d:	50                   	push   ax
    776e:	55                   	push   bp
    776f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7773:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7777:	ff 76 fe             	push   WORD PTR [bp-0x2]
    777a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    777d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7780:	06                   	push   es
    7781:	57                   	push   di
    7782:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7785:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    7789:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    778d:	83 c4 06             	add    sp,0x6
    7790:	b8 a0 77             	mov    ax,0x77a0
    7793:	0e                   	push   cs
    7794:	50                   	push   ax
    7795:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7798:	06                   	push   es
    7799:	57                   	push   di
    779a:	9a 7f 1f 63 78       	call   0x7863:0x1f7f
    779f:	cb                   	retf
    77a0:	c9                   	leave
    77a1:	ca 08 00             	retf   0x8
    77a4:	00 00                	add    BYTE PTR [bx+si],al
    77a6:	5b                   	pop    bx
    77a7:	78 bd                	js     0x7766
    77a9:	77 c8                	ja     0x7773
    77ab:	10 00                	adc    BYTE PTR [bx+si],al
    77ad:	00 ff                	add    bh,bh
    77af:	76 08                	jbe    0x77b9
    77b1:	ff 76 06             	push   WORD PTR [bp+0x6]
    77b4:	6a 00                	push   0x0
    77b6:	b0 01                	mov    al,0x1
    77b8:	50                   	push   ax
    77b9:	b8 e4 14             	mov    ax,0x14e4
    77bc:	ba c4 77             	mov    dx,0x77c4
    77bf:	52                   	push   dx
    77c0:	50                   	push   ax
    77c1:	9a c8 79 6e 78       	call   0x786e:0x79c8
    77c6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    77c9:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    77cc:	b8 a4 77             	mov    ax,0x77a4
    77cf:	0e                   	push   cs
    77d0:	50                   	push   ax
    77d1:	55                   	push   bp
    77d2:	ff 36 58 18          	push   WORD PTR ds:0x1858
    77d6:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    77da:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    77dd:	06                   	push   es
    77de:	57                   	push   di
    77df:	9a bf 23 3b 78       	call   0x783b:0x23bf
    77e4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    77e7:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    77ea:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    77ee:	7f 08                	jg     0x77f8
    77f0:	7c 4b                	jl     0x783d
    77f2:	83 7e f8 08          	cmp    WORD PTR [bp-0x8],0x8
    77f6:	72 45                	jb     0x783d
    77f8:	8d 7e f0             	lea    di,[bp-0x10]
    77fb:	16                   	push   ss
    77fc:	57                   	push   di
    77fd:	6a 00                	push   0x0
    77ff:	6a 08                	push   0x8
    7801:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7804:	06                   	push   es
    7805:	57                   	push   di
    7806:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7809:	26 ff 1d             	call   DWORD PTR es:[di]
    780c:	83 7e f0 01          	cmp    WORD PTR [bp-0x10],0x1
    7810:	75 1d                	jne    0x782f
    7812:	81 7e f2 00 01       	cmp    WORD PTR [bp-0xe],0x100
    7817:	75 16                	jne    0x782f
    7819:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    781c:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    781f:	2d 08 00             	sub    ax,0x8
    7822:	83 da 00             	sbb    dx,0x0
    7825:	3b 56 f6             	cmp    dx,WORD PTR [bp-0xa]
    7828:	75 05                	jne    0x782f
    782a:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    782d:	74 0e                	je     0x783d
    782f:	6a 00                	push   0x0
    7831:	6a 00                	push   0x0
    7833:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7836:	06                   	push   es
    7837:	57                   	push   di
    7838:	9a a4 23 b2 78       	call   0x78b2:0x23a4
    783d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7840:	ff 76 fc             	push   WORD PTR [bp-0x4]
    7843:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    7846:	06                   	push   es
    7847:	57                   	push   di
    7848:	26 c4 3d             	les    di,DWORD PTR es:[di]
    784b:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    784f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7853:	83 c4 06             	add    sp,0x6
    7856:	b8 66 78             	mov    ax,0x7866
    7859:	0e                   	push   cs
    785a:	50                   	push   ax
    785b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    785e:	06                   	push   es
    785f:	57                   	push   di
    7860:	9a 7f 1f c8 78       	call   0x78c8:0x1f7f
    7865:	cb                   	retf
    7866:	c9                   	leave
    7867:	ca 08 00             	retf   0x8
    786a:	00 00                	add    BYTE PTR [bx+si],al
    786c:	c0 78 83 78          	sar    BYTE PTR [bx+si-0x7d],0x78
    7870:	c8 04 00 00          	enter  0x4,0x0
    7874:	ff 76 08             	push   WORD PTR [bp+0x8]
    7877:	ff 76 06             	push   WORD PTR [bp+0x6]
    787a:	6a 00                	push   0x0
    787c:	b0 01                	mov    al,0x1
    787e:	50                   	push   ax
    787f:	b8 e4 14             	mov    ax,0x14e4
    7882:	ba 8a 78             	mov    dx,0x788a
    7885:	52                   	push   dx
    7886:	50                   	push   ax
    7887:	9a c8 79 d3 78       	call   0x78d3:0x79c8
    788c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    788f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7892:	b8 6a 78             	mov    ax,0x786a
    7895:	0e                   	push   cs
    7896:	50                   	push   ax
    7897:	55                   	push   bp
    7898:	ff 36 58 18          	push   WORD PTR ds:0x1858
    789c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    78a0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    78a3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    78a6:	6a 00                	push   0x0
    78a8:	6a 00                	push   0x0
    78aa:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    78ad:	06                   	push   es
    78ae:	57                   	push   di
    78af:	9a c2 24 ff ff       	call   0xffff:0x24c2
    78b4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    78b8:	83 c4 06             	add    sp,0x6
    78bb:	b8 cb 78             	mov    ax,0x78cb
    78be:	0e                   	push   cs
    78bf:	50                   	push   ax
    78c0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    78c3:	06                   	push   es
    78c4:	57                   	push   di
    78c5:	9a 7f 1f 2b 79       	call   0x792b:0x1f7f
    78ca:	cb                   	retf
    78cb:	c9                   	leave
    78cc:	ca 08 00             	retf   0x8
    78cf:	00 00                	add    BYTE PTR [bx+si],al
    78d1:	23 79 e8             	and    di,WORD PTR [bx+di-0x18]
    78d4:	78 c8                	js     0x789e
    78d6:	04 00                	add    al,0x0
    78d8:	00 ff                	add    bh,bh
    78da:	76 08                	jbe    0x78e4
    78dc:	ff 76 06             	push   WORD PTR [bp+0x6]
    78df:	6a 00                	push   0x0
    78e1:	b0 01                	mov    al,0x1
    78e3:	50                   	push   ax
    78e4:	b8 e4 14             	mov    ax,0x14e4
    78e7:	ba ef 78             	mov    dx,0x78ef
    78ea:	52                   	push   dx
    78eb:	50                   	push   ax
    78ec:	9a c8 79 54 79       	call   0x7954:0x79c8
    78f1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    78f4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    78f7:	b8 cf 78             	mov    ax,0x78cf
    78fa:	0e                   	push   cs
    78fb:	50                   	push   ax
    78fc:	55                   	push   bp
    78fd:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7901:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7905:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7908:	ff 76 fc             	push   WORD PTR [bp-0x4]
    790b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    790e:	06                   	push   es
    790f:	57                   	push   di
    7910:	26 c4 3d             	les    di,DWORD PTR es:[di]
    7913:	26 ff 5d 48          	call   DWORD PTR es:[di+0x48]
    7917:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    791b:	83 c4 06             	add    sp,0x6
    791e:	b8 2e 79             	mov    ax,0x792e
    7921:	0e                   	push   cs
    7922:	50                   	push   ax
    7923:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    7926:	06                   	push   es
    7927:	57                   	push   di
    7928:	9a 7f 1f 41 79       	call   0x7941:0x1f7f
    792d:	cb                   	retf
    792e:	c9                   	leave
    792f:	ca 08 00             	retf   0x8
    7932:	55                   	push   bp
    7933:	89 e5                	mov    bp,sp
    7935:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7939:	74 08                	je     0x7943
    793b:	83 ec 08             	sub    sp,0x8
    793e:	9a e2 1f 90 79       	call   0x7990:0x1fe2
    7943:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7946:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7949:	31 c0                	xor    ax,ax
    794b:	50                   	push   ax
    794c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    794f:	06                   	push   es
    7950:	57                   	push   di
    7951:	9a d7 73 a3 79       	call   0x79a3:0x73d7
    7956:	6a 0f                	push   0xf
    7958:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    795b:	06                   	push   es
    795c:	57                   	push   di
    795d:	9a 85 6e af 79       	call   0x79af:0x6e85
    7962:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7965:	26 c6 45 61 01       	mov    BYTE PTR es:[di+0x61],0x1
    796a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    796e:	74 07                	je     0x7977
    7970:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7974:	83 c4 06             	add    sp,0x6
    7977:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    797a:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    797d:	c9                   	leave
    797e:	ca 0a 00             	retf   0xa
    7981:	55                   	push   bp
    7982:	89 e5                	mov    bp,sp
    7984:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7988:	74 08                	je     0x7992
    798a:	83 ec 08             	sub    sp,0x8
    798d:	9a e2 1f d8 79       	call   0x79d8:0x1fe2
    7992:	ff 76 0e             	push   WORD PTR [bp+0xe]
    7995:	ff 76 0c             	push   WORD PTR [bp+0xc]
    7998:	31 c0                	xor    ax,ax
    799a:	50                   	push   ax
    799b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    799e:	06                   	push   es
    799f:	57                   	push   di
    79a0:	9a d7 73 e3 7a       	call   0x7ae3:0x73d7
    79a5:	6a 10                	push   0x10
    79a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79aa:	06                   	push   es
    79ab:	57                   	push   di
    79ac:	9a 85 6e 0a 7a       	call   0x7a0a:0x6e85
    79b1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    79b5:	74 07                	je     0x79be
    79b7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    79bb:	83 c4 06             	add    sp,0x6
    79be:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    79c1:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    79c4:	c9                   	leave
    79c5:	ca 0a 00             	retf   0xa
    79c8:	c8 02 00 00          	enter  0x2,0x0
    79cc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    79d0:	74 08                	je     0x79da
    79d2:	83 ec 08             	sub    sp,0x8
    79d5:	9a e2 1f 74 7b       	call   0x7b74:0x1fe2
    79da:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    79dd:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    79e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79e3:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    79e7:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    79eb:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    79ee:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    79f2:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    79f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    79f9:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    79fd:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    7a01:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7a05:	06                   	push   es
    7a06:	57                   	push   di
    7a07:	9a a7 45 75 7a       	call   0x7a75:0x45a7
    7a0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a0f:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    7a13:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    7a17:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    7a1a:	26 8b 45 2e          	mov    ax,WORD PTR es:[di+0x2e]
    7a1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a21:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    7a25:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7a29:	26 80 7d 60 00       	cmp    BYTE PTR es:[di+0x60],0x0
    7a2e:	74 03                	je     0x7a33
    7a30:	e9 9d 00             	jmp    0x7ad0
    7a33:	80 7e 0c 00          	cmp    BYTE PTR [bp+0xc],0x0
    7a37:	75 4b                	jne    0x7a84
    7a39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a3c:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7a40:	26 ff 75 46          	push   WORD PTR es:[di+0x46]
    7a44:	9a 76 04 0c 80       	call   0x800c:0x476
    7a49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a4c:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    7a50:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    7a54:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    7a58:	26 8b 55 12          	mov    dx,WORD PTR es:[di+0x12]
    7a5c:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    7a60:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    7a64:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    7a68:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    7a6c:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7a70:	06                   	push   es
    7a71:	57                   	push   di
    7a72:	9a 67 48 9d 7a       	call   0x7a9d:0x4867
    7a77:	08 c0                	or     al,al
    7a79:	75 02                	jne    0x7a7d
    7a7b:	eb 68                	jmp    0x7ae5
    7a7d:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    7a82:	eb 20                	jmp    0x7aa4
    7a84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7a87:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7a8b:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    7a8f:	3c 02                	cmp    al,0x2
    7a91:	72 04                	jb     0x7a97
    7a93:	3c 03                	cmp    al,0x3
    7a95:	76 08                	jbe    0x7a9f
    7a97:	68 12 f2             	push   0xf212
    7a9a:	9a ef 11 ce 7a       	call   0x7ace:0x11ef
    7a9f:	31 c0                	xor    ax,ax
    7aa1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7aa4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7aa7:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7aab:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    7aaf:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    7ab3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ab6:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    7aba:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    7abe:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    7ac2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    7ac5:	9a 6d 05 52 7b       	call   0x7b52:0x56d
    7aca:	50                   	push   ax
    7acb:	9a 4e 12 97 7b       	call   0x7b97:0x124e
    7ad0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ad3:	26 c6 45 16 01       	mov    BYTE PTR es:[di+0x16],0x1
    7ad8:	80 7e 0c 01          	cmp    BYTE PTR [bp+0xc],0x1
    7adc:	75 07                	jne    0x7ae5
    7ade:	06                   	push   es
    7adf:	57                   	push   di
    7ae0:	9a 22 7f 04 7b       	call   0x7b04:0x7f22
    7ae5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7ae9:	74 07                	je     0x7af2
    7aeb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7aef:	83 c4 06             	add    sp,0x6
    7af2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7af5:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    7af8:	c9                   	leave
    7af9:	ca 0c 00             	retf   0xc
    7afc:	01 00                	add    WORD PTR [bx+si],ax
    7afe:	00 00                	add    BYTE PTR [bx+si],al
    7b00:	00 00                	add    BYTE PTR [bx+si],al
    7b02:	a2 7b 10             	mov    ds:0x107b,al
    7b05:	7d 55                	jge    0x7b5c
    7b07:	89 e5                	mov    bp,sp
    7b09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b0c:	26 80 7d 16 00       	cmp    BYTE PTR es:[di+0x16],0x0
    7b11:	74 41                	je     0x7b54
    7b13:	26 80 7d 17 00       	cmp    BYTE PTR es:[di+0x17],0x0
    7b18:	74 09                	je     0x7b23
    7b1a:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7b1e:	26 c6 45 60 01       	mov    BYTE PTR es:[di+0x60],0x1
    7b23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b26:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7b2a:	26 80 7d 60 00       	cmp    BYTE PTR es:[di+0x60],0x0
    7b2f:	75 23                	jne    0x7b54
    7b31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b34:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7b38:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    7b3c:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    7b40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b43:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    7b47:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    7b4b:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    7b4f:	9a bd 05 69 7c       	call   0x7c69:0x5bd
    7b54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b57:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    7b5b:	26 0b 45 12          	or     ax,WORD PTR es:[di+0x12]
    7b5f:	74 15                	je     0x7b76
    7b61:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    7b65:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    7b69:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7b6d:	26 ff 75 46          	push   WORD PTR es:[di+0x46]
    7b71:	9a 9c 01 b6 7b       	call   0x7bb6:0x19c
    7b76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7b79:	26 80 7d 17 00       	cmp    BYTE PTR es:[di+0x17],0x0
    7b7e:	74 38                	je     0x7bb8
    7b80:	b8 fc 7a             	mov    ax,0x7afc
    7b83:	0e                   	push   cs
    7b84:	50                   	push   ax
    7b85:	55                   	push   bp
    7b86:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7b8a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7b8e:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7b92:	06                   	push   es
    7b93:	57                   	push   di
    7b94:	9a 07 64 aa 7c       	call   0x7caa:0x6407
    7b99:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7b9d:	83 c4 06             	add    sp,0x6
    7ba0:	eb 16                	jmp    0x7bb8
    7ba2:	ff 76 08             	push   WORD PTR [bp+0x8]
    7ba5:	ff 76 06             	push   WORD PTR [bp+0x6]
    7ba8:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    7bac:	06                   	push   es
    7bad:	57                   	push   di
    7bae:	9a 51 75 ff ff       	call   0xffff:0x7551
    7bb3:	9a 34 14 c1 7b       	call   0x7bc1:0x1434
    7bb8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7bbc:	74 05                	je     0x7bc3
    7bbe:	9a 0f 20 9c 7d       	call   0x7d9c:0x200f
    7bc3:	c9                   	leave
    7bc4:	ca 06 00             	retf   0x6
    7bc7:	c8 10 00 00          	enter  0x10,0x0
    7bcb:	31 c0                	xor    ax,ax
    7bcd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7bd0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7bd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7bd6:	26 80 7d 16 00       	cmp    BYTE PTR es:[di+0x16],0x0
    7bdb:	75 03                	jne    0x7be0
    7bdd:	e9 22 01             	jmp    0x7d02
    7be0:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    7be3:	89 f8                	mov    ax,di
    7be5:	8c c2                	mov    dx,es
    7be7:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    7bea:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    7bed:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    7bf1:	7f 0e                	jg     0x7c01
    7bf3:	7d 03                	jge    0x7bf8
    7bf5:	e9 0a 01             	jmp    0x7d02
    7bf8:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    7bfc:	77 03                	ja     0x7c01
    7bfe:	e9 01 01             	jmp    0x7d02
    7c01:	81 7e f0 00 80       	cmp    WORD PTR [bp-0x10],0x8000
    7c06:	73 07                	jae    0x7c0f
    7c08:	c7 46 f8 00 80       	mov    WORD PTR [bp-0x8],0x8000
    7c0d:	eb 08                	jmp    0x7c17
    7c0f:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    7c12:	f7 d8                	neg    ax
    7c14:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7c17:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7c1a:	31 d2                	xor    dx,dx
    7c1c:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    7c1f:	7f 07                	jg     0x7c28
    7c21:	7c 0b                	jl     0x7c2e
    7c23:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7c26:	76 06                	jbe    0x7c2e
    7c28:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7c2b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    7c2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c31:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7c35:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    7c39:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    7c3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c40:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    7c44:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    7c48:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    7c4c:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    7c50:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    7c54:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7c57:	31 d2                	xor    dx,dx
    7c59:	52                   	push   dx
    7c5a:	50                   	push   ax
    7c5b:	ff 76 f2             	push   WORD PTR [bp-0xe]
    7c5e:	ff 76 f0             	push   WORD PTR [bp-0x10]
    7c61:	8d 7e f4             	lea    di,[bp-0xc]
    7c64:	16                   	push   ss
    7c65:	57                   	push   di
    7c66:	9a 8d 05 0b 7e       	call   0x7e0b:0x58d
    7c6b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7c6e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7c71:	3d 00 00             	cmp    ax,0x0
    7c74:	74 05                	je     0x7c7b
    7c76:	3d 07 22             	cmp    ax,0x2207
    7c79:	75 50                	jne    0x7ccb
    7c7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c7e:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7c82:	26 80 7d 61 00       	cmp    BYTE PTR es:[di+0x61],0x0
    7c87:	74 23                	je     0x7cac
    7c89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7c8c:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7c90:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    7c94:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    7c98:	ff 76 f2             	push   WORD PTR [bp-0xe]
    7c9b:	ff 76 f0             	push   WORD PTR [bp-0x10]
    7c9e:	ff 76 f2             	push   WORD PTR [bp-0xe]
    7ca1:	ff 76 f0             	push   WORD PTR [bp-0x10]
    7ca4:	ff 76 f4             	push   WORD PTR [bp-0xc]
    7ca7:	9a a8 0f d8 7c       	call   0x7cd8:0xfa8
    7cac:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    7caf:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    7cb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7cb5:	26 01 45 18          	add    WORD PTR es:[di+0x18],ax
    7cb9:	26 11 55 1a          	adc    WORD PTR es:[di+0x1a],dx
    7cbd:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    7cc0:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    7cc3:	01 46 fc             	add    WORD PTR [bp-0x4],ax
    7cc6:	11 56 fe             	adc    WORD PTR [bp-0x2],dx
    7cc9:	eb 0f                	jmp    0x7cda
    7ccb:	3d 0e 27             	cmp    ax,0x270e
    7cce:	75 02                	jne    0x7cd2
    7cd0:	eb 08                	jmp    0x7cda
    7cd2:	ff 76 fa             	push   WORD PTR [bp-0x6]
    7cd5:	9a 2d 12 d3 7d       	call   0x7dd3:0x122d
    7cda:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    7cde:	74 02                	je     0x7ce2
    7ce0:	eb 20                	jmp    0x7d02
    7ce2:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7ce5:	31 d2                	xor    dx,dx
    7ce7:	29 46 0a             	sub    WORD PTR [bp+0xa],ax
    7cea:	19 56 0c             	sbb    WORD PTR [bp+0xc],dx
    7ced:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    7cf0:	01 46 f0             	add    WORD PTR [bp-0x10],ax
    7cf3:	83 7e f0 00          	cmp    WORD PTR [bp-0x10],0x0
    7cf7:	75 06                	jne    0x7cff
    7cf9:	a1 7e 18             	mov    ax,ds:0x187e
    7cfc:	01 46 f2             	add    WORD PTR [bp-0xe],ax
    7cff:	e9 eb fe             	jmp    0x7bed
    7d02:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7d05:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7d08:	c9                   	leave
    7d09:	ca 0c 00             	retf   0xc
    7d0c:	00 00                	add    BYTE PTR [bx+si],al
    7d0e:	1f                   	pop    ds
    7d0f:	7e f4                	jle    0x7d05
    7d11:	7e c8                	jle    0x7cdb
    7d13:	0e                   	push   cs
    7d14:	00 00                	add    BYTE PTR [bx+si],al
    7d16:	31 c0                	xor    ax,ax
    7d18:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7d1b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7d1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d21:	26 80 7d 16 00       	cmp    BYTE PTR es:[di+0x16],0x0
    7d26:	75 03                	jne    0x7d2b
    7d28:	e9 7b 01             	jmp    0x7ea6
    7d2b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7d2e:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    7d31:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7d34:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7d37:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    7d3a:	89 f8                	mov    ax,di
    7d3c:	8c c2                	mov    dx,es
    7d3e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    7d41:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    7d44:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    7d48:	7f 0e                	jg     0x7d58
    7d4a:	7d 03                	jge    0x7d4f
    7d4c:	e9 4f 01             	jmp    0x7e9e
    7d4f:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    7d53:	77 03                	ja     0x7d58
    7d55:	e9 46 01             	jmp    0x7e9e
    7d58:	81 7e f6 00 80       	cmp    WORD PTR [bp-0xa],0x8000
    7d5d:	73 07                	jae    0x7d66
    7d5f:	c7 46 fa 00 80       	mov    WORD PTR [bp-0x6],0x8000
    7d64:	eb 08                	jmp    0x7d6e
    7d66:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    7d69:	f7 d8                	neg    ax
    7d6b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7d6e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7d71:	31 d2                	xor    dx,dx
    7d73:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    7d76:	7f 07                	jg     0x7d7f
    7d78:	7c 0b                	jl     0x7d85
    7d7a:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    7d7d:	76 06                	jbe    0x7d85
    7d7f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7d82:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    7d85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7d88:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    7d8c:	26 80 7d 61 00       	cmp    BYTE PTR es:[di+0x61],0x0
    7d91:	75 03                	jne    0x7d96
    7d93:	e9 9a 00             	jmp    0x7e30
    7d96:	ff 76 fa             	push   WORD PTR [bp-0x6]
    7d99:	9a 82 01 2b 7e       	call   0x7e2b:0x182
    7d9e:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    7da1:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    7da4:	b8 0c 7d             	mov    ax,0x7d0c
    7da7:	0e                   	push   cs
    7da8:	50                   	push   ax
    7da9:	55                   	push   bp
    7daa:	ff 36 58 18          	push   WORD PTR ds:0x1858
    7dae:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    7db2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7db5:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7db9:	26 ff 75 58          	push   WORD PTR es:[di+0x58]
    7dbd:	26 ff 75 56          	push   WORD PTR es:[di+0x56]
    7dc1:	ff 76 f8             	push   WORD PTR [bp-0x8]
    7dc4:	ff 76 f6             	push   WORD PTR [bp-0xa]
    7dc7:	ff 76 f4             	push   WORD PTR [bp-0xc]
    7dca:	ff 76 f2             	push   WORD PTR [bp-0xe]
    7dcd:	ff 76 fa             	push   WORD PTR [bp-0x6]
    7dd0:	9a 5d 0f 11 7e       	call   0x7e11:0xf5d
    7dd5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7dd8:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7ddc:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    7de0:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    7de4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7de7:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    7deb:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    7def:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    7df3:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    7df7:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    7dfb:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7dfe:	31 d2                	xor    dx,dx
    7e00:	52                   	push   dx
    7e01:	50                   	push   ax
    7e02:	ff 76 f4             	push   WORD PTR [bp-0xc]
    7e05:	ff 76 f2             	push   WORD PTR [bp-0xe]
    7e08:	9a 9d 05 66 7e       	call   0x7e66:0x59d
    7e0d:	50                   	push   ax
    7e0e:	9a 4e 12 6c 7e       	call   0x7e6c:0x124e
    7e13:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7e17:	83 c4 06             	add    sp,0x6
    7e1a:	b8 2e 7e             	mov    ax,0x7e2e
    7e1d:	0e                   	push   cs
    7e1e:	50                   	push   ax
    7e1f:	ff 76 f4             	push   WORD PTR [bp-0xc]
    7e22:	ff 76 f2             	push   WORD PTR [bp-0xe]
    7e25:	ff 76 fa             	push   WORD PTR [bp-0x6]
    7e28:	9a 9c 01 c3 7f       	call   0x7fc3:0x19c
    7e2d:	cb                   	retf
    7e2e:	eb 3e                	jmp    0x7e6e
    7e30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e33:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7e37:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    7e3b:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    7e3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e42:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    7e46:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    7e4a:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    7e4e:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    7e52:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    7e56:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7e59:	31 d2                	xor    dx,dx
    7e5b:	52                   	push   dx
    7e5c:	50                   	push   ax
    7e5d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    7e60:	ff 76 f6             	push   WORD PTR [bp-0xa]
    7e63:	9a 9d 05 55 7f       	call   0x7f55:0x59d
    7e68:	50                   	push   ax
    7e69:	9a 4e 12 5b 7f       	call   0x7f5b:0x124e
    7e6e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7e71:	31 d2                	xor    dx,dx
    7e73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7e76:	26 01 45 18          	add    WORD PTR es:[di+0x18],ax
    7e7a:	26 11 55 1a          	adc    WORD PTR es:[di+0x1a],dx
    7e7e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7e81:	31 d2                	xor    dx,dx
    7e83:	29 46 0a             	sub    WORD PTR [bp+0xa],ax
    7e86:	19 56 0c             	sbb    WORD PTR [bp+0xc],dx
    7e89:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    7e8c:	01 46 f6             	add    WORD PTR [bp-0xa],ax
    7e8f:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    7e93:	75 06                	jne    0x7e9b
    7e95:	a1 7e 18             	mov    ax,ds:0x187e
    7e98:	01 46 f8             	add    WORD PTR [bp-0x8],ax
    7e9b:	e9 a6 fe             	jmp    0x7d44
    7e9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ea1:	26 c6 45 17 01       	mov    BYTE PTR es:[di+0x17],0x1
    7ea6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7ea9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7eac:	c9                   	leave
    7ead:	ca 0c 00             	retf   0xc
    7eb0:	c8 04 00 00          	enter  0x4,0x0
    7eb4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    7eb7:	3d 00 00             	cmp    ax,0x0
    7eba:	75 13                	jne    0x7ecf
    7ebc:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    7ebf:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    7ec2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7ec5:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    7ec9:	26 89 55 1a          	mov    WORD PTR es:[di+0x1a],dx
    7ecd:	eb 38                	jmp    0x7f07
    7ecf:	3d 01 00             	cmp    ax,0x1
    7ed2:	75 13                	jne    0x7ee7
    7ed4:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    7ed7:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    7eda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7edd:	26 01 45 18          	add    WORD PTR es:[di+0x18],ax
    7ee1:	26 11 55 1a          	adc    WORD PTR es:[di+0x1a],dx
    7ee5:	eb 20                	jmp    0x7f07
    7ee7:	3d 02 00             	cmp    ax,0x2
    7eea:	75 1b                	jne    0x7f07
    7eec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7eef:	06                   	push   es
    7ef0:	57                   	push   di
    7ef1:	9a 69 7f b3 80       	call   0x80b3:0x7f69
    7ef6:	03 46 0c             	add    ax,WORD PTR [bp+0xc]
    7ef9:	13 56 0e             	adc    dx,WORD PTR [bp+0xe]
    7efc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7eff:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    7f03:	26 89 55 1a          	mov    WORD PTR es:[di+0x1a],dx
    7f07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f0a:	26 8b 45 18          	mov    ax,WORD PTR es:[di+0x18]
    7f0e:	26 8b 55 1a          	mov    dx,WORD PTR es:[di+0x1a]
    7f12:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7f15:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    7f18:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7f1b:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7f1e:	c9                   	leave
    7f1f:	ca 0a 00             	retf   0xa
    7f22:	55                   	push   bp
    7f23:	89 e5                	mov    bp,sp
    7f25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f28:	26 80 7d 16 00       	cmp    BYTE PTR es:[di+0x16],0x0
    7f2d:	74 36                	je     0x7f65
    7f2f:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7f33:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    7f37:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    7f3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f3e:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    7f42:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    7f46:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    7f4a:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    7f4e:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    7f52:	9a ad 05 a2 7f       	call   0x7fa2:0x5ad
    7f57:	50                   	push   ax
    7f58:	9a 4e 12 a8 7f       	call   0x7fa8:0x124e
    7f5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f60:	26 c6 45 17 01       	mov    BYTE PTR es:[di+0x17],0x1
    7f65:	c9                   	leave
    7f66:	ca 04 00             	retf   0x4
    7f69:	c8 04 00 00          	enter  0x4,0x0
    7f6d:	31 c0                	xor    ax,ax
    7f6f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    7f72:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    7f75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f78:	26 80 7d 16 00       	cmp    BYTE PTR es:[di+0x16],0x0
    7f7d:	74 2b                	je     0x7faa
    7f7f:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    7f83:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    7f87:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    7f8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7f8e:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    7f92:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    7f96:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    7f9a:	8d 7e fc             	lea    di,[bp-0x4]
    7f9d:	16                   	push   ss
    7f9e:	57                   	push   di
    7f9f:	9a 7d 05 ff ff       	call   0xffff:0x57d
    7fa4:	50                   	push   ax
    7fa5:	9a 4e 12 d0 7f       	call   0x7fd0:0x124e
    7faa:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    7fad:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    7fb0:	c9                   	leave
    7fb1:	ca 04 00             	retf   0x4
    7fb4:	55                   	push   bp
    7fb5:	89 e5                	mov    bp,sp
    7fb7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7fbb:	74 08                	je     0x7fc5
    7fbd:	83 ec 08             	sub    sp,0x8
    7fc0:	9a e2 1f 24 80       	call   0x8024:0x1fe2
    7fc5:	31 c0                	xor    ax,ax
    7fc7:	50                   	push   ax
    7fc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7fcb:	06                   	push   es
    7fcc:	57                   	push   di
    7fcd:	9a dc 75 19 80       	call   0x8019:0x75dc
    7fd2:	a1 16 17             	mov    ax,ds:0x1716
    7fd5:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    7fd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7fdc:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    7fe0:	26 89 55 1a          	mov    WORD PTR es:[di+0x1a],dx
    7fe4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    7fe8:	74 07                	je     0x7ff1
    7fea:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    7fee:	83 c4 06             	add    sp,0x6
    7ff1:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    7ff4:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    7ff7:	c9                   	leave
    7ff8:	ca 06 00             	retf   0x6
    7ffb:	55                   	push   bp
    7ffc:	89 e5                	mov    bp,sp
    7ffe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8001:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    8005:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    8009:	9a 24 06 a9 80       	call   0x80a9:0x624
    800e:	31 c0                	xor    ax,ax
    8010:	50                   	push   ax
    8011:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8014:	06                   	push   es
    8015:	57                   	push   di
    8016:	9a 1a 76 3d 81       	call   0x813d:0x761a
    801b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    801f:	74 05                	je     0x8026
    8021:	9a 0f 20 7a 80       	call   0x807a:0x200f
    8026:	c9                   	leave
    8027:	ca 06 00             	retf   0x6
    802a:	55                   	push   bp
    802b:	89 e5                	mov    bp,sp
    802d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8030:	26 8a 45 20          	mov    al,BYTE PTR es:[di+0x20]
    8034:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    8037:	74 26                	je     0x805f
    8039:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    803c:	26 88 45 20          	mov    BYTE PTR es:[di+0x20],al
    8040:	26 c6 45 21 00       	mov    BYTE PTR es:[di+0x21],0x0
    8045:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    8049:	09 c0                	or     ax,ax
    804b:	74 12                	je     0x805f
    804d:	ff 76 08             	push   WORD PTR [bp+0x8]
    8050:	ff 76 06             	push   WORD PTR [bp+0x6]
    8053:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    8057:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    805b:	26 ff 5d 2a          	call   DWORD PTR es:[di+0x2a]
    805f:	c9                   	leave
    8060:	ca 06 00             	retf   0x6
    8063:	55                   	push   bp
    8064:	89 e5                	mov    bp,sp
    8066:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8069:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    806d:	06                   	push   es
    806e:	57                   	push   di
    806f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8072:	06                   	push   es
    8073:	57                   	push   di
    8074:	68 ff 00             	push   0xff
    8077:	9a e7 17 94 80       	call   0x8094:0x17e7
    807c:	c9                   	leave
    807d:	ca 04 00             	retf   0x4
    8080:	55                   	push   bp
    8081:	89 e5                	mov    bp,sp
    8083:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8086:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    808a:	06                   	push   es
    808b:	57                   	push   di
    808c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    808f:	06                   	push   es
    8090:	57                   	push   di
    8091:	9a be 18 ff ff       	call   0xffff:0x18be
    8096:	74 1d                	je     0x80b5
    8098:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    809b:	81 c7 18 00          	add    di,0x18
    809f:	06                   	push   es
    80a0:	57                   	push   di
    80a1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    80a4:	06                   	push   es
    80a5:	57                   	push   di
    80a6:	9a 51 06 ff ff       	call   0xffff:0x651
    80ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80ae:	06                   	push   es
    80af:	57                   	push   di
    80b0:	9a ff 80 0e 81       	call   0x810e:0x80ff
    80b5:	c9                   	leave
    80b6:	ca 08 00             	retf   0x8
    80b9:	55                   	push   bp
    80ba:	89 e5                	mov    bp,sp
    80bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80bf:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    80c3:	26 8b 55 16          	mov    dx,WORD PTR es:[di+0x16]
    80c7:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    80ca:	75 05                	jne    0x80d1
    80cc:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    80cf:	74 2a                	je     0x80fb
    80d1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    80d4:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    80d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80da:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    80de:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    80e2:	06                   	push   es
    80e3:	57                   	push   di
    80e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    80e7:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    80eb:	6a 00                	push   0x0
    80ed:	6a 00                	push   0x0
    80ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    80f2:	06                   	push   es
    80f3:	57                   	push   di
    80f4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    80f7:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    80fb:	c9                   	leave
    80fc:	ca 08 00             	retf   0x8
    80ff:	55                   	push   bp
    8100:	89 e5                	mov    bp,sp
    8102:	6a 00                	push   0x0
    8104:	6a 00                	push   0x0
    8106:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8109:	06                   	push   es
    810a:	57                   	push   di
    810b:	9a b9 80 49 81       	call   0x8149:0x80b9
    8110:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8113:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    8118:	74 31                	je     0x814b
    811a:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    811e:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    8122:	74 27                	je     0x814b
    8124:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8127:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    812b:	06                   	push   es
    812c:	57                   	push   di
    812d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8130:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    8134:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    8138:	06                   	push   es
    8139:	57                   	push   di
    813a:	9a 9b 3b 69 81       	call   0x8169:0x3b9b
    813f:	52                   	push   dx
    8140:	50                   	push   ax
    8141:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8144:	06                   	push   es
    8145:	57                   	push   di
    8146:	9a b9 80 5b 81       	call   0x815b:0x80b9
    814b:	c9                   	leave
    814c:	ca 04 00             	retf   0x4
    814f:	c8 02 00 00          	enter  0x2,0x0
    8153:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8156:	06                   	push   es
    8157:	57                   	push   di
    8158:	9a 7c 81 e4 81       	call   0x81e4:0x817c
    815d:	08 c0                	or     al,al
    815f:	74 0a                	je     0x816b
    8161:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8164:	06                   	push   es
    8165:	57                   	push   di
    8166:	9a 99 78 9d 81       	call   0x819d:0x7899
    816b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    816e:	26 8a 45 20          	mov    al,BYTE PTR es:[di+0x20]
    8172:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    8175:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    8178:	c9                   	leave
    8179:	ca 04 00             	retf   0x4
    817c:	c8 02 00 00          	enter  0x2,0x0
    8180:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8183:	26 80 7d 10 00       	cmp    BYTE PTR es:[di+0x10],0x0
    8188:	75 19                	jne    0x81a3
    818a:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    818e:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    8192:	74 0f                	je     0x81a3
    8194:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    8198:	06                   	push   es
    8199:	57                   	push   di
    819a:	9a ca 65 ff ff       	call   0xffff:0x65ca
    819f:	08 c0                	or     al,al
    81a1:	75 04                	jne    0x81a7
    81a3:	b0 00                	mov    al,0x0
    81a5:	eb 02                	jmp    0x81a9
    81a7:	b0 01                	mov    al,0x1
    81a9:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    81ac:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    81af:	c9                   	leave
    81b0:	ca 04 00             	retf   0x4
    81b3:	55                   	push   bp
    81b4:	89 e5                	mov    bp,sp
    81b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    81b9:	26 c6 45 21 01       	mov    BYTE PTR es:[di+0x21],0x1
    81be:	c9                   	leave
    81bf:	ca 04 00             	retf   0x4
    81c2:	55                   	push   bp
    81c3:	89 e5                	mov    bp,sp
    81c5:	6a 00                	push   0x0
    81c7:	6a 00                	push   0x0
    81c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    81cc:	06                   	push   es
    81cd:	57                   	push   di
    81ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    81d1:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    81d5:	c9                   	leave
    81d6:	ca 04 00             	retf   0x4
    81d9:	55                   	push   bp
    81da:	89 e5                	mov    bp,sp
    81dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    81df:	06                   	push   es
    81e0:	57                   	push   di
    81e1:	9a ff 80 19 82       	call   0x8219:0x80ff
    81e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    81e9:	26 8b 45 3c          	mov    ax,WORD PTR es:[di+0x3c]
    81ed:	09 c0                	or     ax,ax
    81ef:	74 12                	je     0x8203
    81f1:	ff 76 08             	push   WORD PTR [bp+0x8]
    81f4:	ff 76 06             	push   WORD PTR [bp+0x6]
    81f7:	26 ff 75 40          	push   WORD PTR es:[di+0x40]
    81fb:	26 ff 75 3e          	push   WORD PTR es:[di+0x3e]
    81ff:	26 ff 5d 3a          	call   DWORD PTR es:[di+0x3a]
    8203:	c9                   	leave
    8204:	ca 04 00             	retf   0x4
    8207:	55                   	push   bp
    8208:	89 e5                	mov    bp,sp
    820a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    820d:	26 80 7d 12 00       	cmp    BYTE PTR es:[di+0x12],0x0
    8212:	74 0b                	je     0x821f
    8214:	06                   	push   es
    8215:	57                   	push   di
    8216:	9a 7c 81 2e 82       	call   0x822e:0x817c
    821b:	08 c0                	or     al,al
    821d:	75 04                	jne    0x8223
    821f:	b0 00                	mov    al,0x0
    8221:	eb 02                	jmp    0x8225
    8223:	b0 01                	mov    al,0x1
    8225:	50                   	push   ax
    8226:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8229:	06                   	push   es
    822a:	57                   	push   di
    822b:	9a 2a 80 e9 82       	call   0x82e9:0x802a
    8230:	c9                   	leave
    8231:	ca 04 00             	retf   0x4
    8234:	55                   	push   bp
    8235:	89 e5                	mov    bp,sp
    8237:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    823a:	26 8b 05             	mov    ax,WORD PTR es:[di]
    823d:	26 0b 45 02          	or     ax,WORD PTR es:[di+0x2]
    8241:	74 4e                	je     0x8291
    8243:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8246:	26 8b 05             	mov    ax,WORD PTR es:[di]
    8249:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    824d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8250:	26 3b 55 16          	cmp    dx,WORD PTR es:[di+0x16]
    8254:	75 3b                	jne    0x8291
    8256:	26 3b 45 14          	cmp    ax,WORD PTR es:[di+0x14]
    825a:	75 35                	jne    0x8291
    825c:	26 8b 45 1c          	mov    ax,WORD PTR es:[di+0x1c]
    8260:	26 0b 45 1e          	or     ax,WORD PTR es:[di+0x1e]
    8264:	74 2b                	je     0x8291
    8266:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    826a:	06                   	push   es
    826b:	57                   	push   di
    826c:	9a c4 61 ff ff       	call   0xffff:0x61c4
    8271:	08 c0                	or     al,al
    8273:	74 1c                	je     0x8291
    8275:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    8278:	31 c0                	xor    ax,ax
    827a:	26 89 05             	mov    WORD PTR es:[di],ax
    827d:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    8281:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8284:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    8288:	06                   	push   es
    8289:	57                   	push   di
    828a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    828d:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    8291:	c9                   	leave
    8292:	ca 08 00             	retf   0x8
    8295:	55                   	push   bp
    8296:	89 e5                	mov    bp,sp
    8298:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    829b:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    829e:	74 15                	je     0x82b5
    82a0:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    82a3:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    82a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82a9:	26 3b 55 16          	cmp    dx,WORD PTR es:[di+0x16]
    82ad:	75 2b                	jne    0x82da
    82af:	26 3b 45 14          	cmp    ax,WORD PTR es:[di+0x14]
    82b3:	75 25                	jne    0x82da
    82b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82b8:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    82bc:	09 c0                	or     ax,ax
    82be:	74 12                	je     0x82d2
    82c0:	ff 76 08             	push   WORD PTR [bp+0x8]
    82c3:	ff 76 06             	push   WORD PTR [bp+0x6]
    82c6:	26 ff 75 28          	push   WORD PTR es:[di+0x28]
    82ca:	26 ff 75 26          	push   WORD PTR es:[di+0x26]
    82ce:	26 ff 5d 22          	call   DWORD PTR es:[di+0x22]
    82d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82d5:	26 c6 45 21 00       	mov    BYTE PTR es:[di+0x21],0x0
    82da:	c9                   	leave
    82db:	ca 08 00             	retf   0x8
    82de:	55                   	push   bp
    82df:	89 e5                	mov    bp,sp
    82e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82e4:	06                   	push   es
    82e5:	57                   	push   di
    82e6:	9a ff 80 ff ff       	call   0xffff:0x80ff
    82eb:	c9                   	leave
    82ec:	ca 04 00             	retf   0x4
    82ef:	55                   	push   bp
    82f0:	89 e5                	mov    bp,sp
    82f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    82f5:	26 80 7d 21 00       	cmp    BYTE PTR es:[di+0x21],0x0
    82fa:	74 2c                	je     0x8328
    82fc:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    8300:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    8304:	74 1a                	je     0x8320
    8306:	26 8b 45 34          	mov    ax,WORD PTR es:[di+0x34]
    830a:	09 c0                	or     ax,ax
    830c:	74 12                	je     0x8320
    830e:	ff 76 08             	push   WORD PTR [bp+0x8]
    8311:	ff 76 06             	push   WORD PTR [bp+0x6]
    8314:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    8318:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    831c:	26 ff 5d 32          	call   DWORD PTR es:[di+0x32]
    8320:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    8323:	26 c6 45 21 00       	mov    BYTE PTR es:[di+0x21],0x0
    8328:	c9                   	leave
    8329:	ca                   	.byte 0xca
    832a:	04                   	.byte 0x4
