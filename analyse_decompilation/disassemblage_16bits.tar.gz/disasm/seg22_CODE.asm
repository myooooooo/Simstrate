; ================================================================
; seg22_CODE  (13084 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	16                   	push   ss
       1:	00 08                	add    BYTE PTR [bx+si],cl
       3:	10 54 50             	adc    BYTE PTR [si+0x50],dl
       6:	61                   	popa
       7:	67 65 43             	addr32 gs inc bx
       a:	68 61 6e             	push   0x6e61
       d:	67 65 45             	addr32 gs inc bp
      10:	76 65                	jbe    0x77
      12:	6e                   	outs   dx,BYTE PTR ds:[si]
      13:	74 00                	je     0x15
      15:	03 00                	add    ax,WORD PTR [bx+si]
      17:	06                   	push   es
      18:	53                   	push   bx
      19:	65 6e                	outs   dx,BYTE PTR gs:[si]
      1b:	64 65 72 07          	fs gs jb 0x26
      1f:	54                   	push   sp
      20:	4f                   	dec    di
      21:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
      24:	63 74 00             	arpl   WORD PTR [si+0x0],si
      27:	06                   	push   es
      28:	4e                   	dec    si
      29:	65 77 54             	gs ja  0x80
      2c:	61                   	popa
      2d:	62 07                	bound  ax,DWORD PTR [bx]
      2f:	49                   	dec    cx
      30:	6e                   	outs   dx,BYTE PTR ds:[si]
      31:	74 65                	je     0x98
      33:	67 65 72 01          	addr32 gs jb 0x38
      37:	0b 41 6c             	or     ax,WORD PTR [bx+di+0x6c]
      3a:	6c                   	ins    BYTE PTR es:[di],dx
      3b:	6f                   	outs   dx,WORD PTR ds:[si]
      3c:	77 43                	ja     0x81
      3e:	68 61 6e             	push   0x6e61
      41:	67 65 07             	addr32 gs pop es
      44:	42                   	inc    dx
      45:	6f                   	outs   dx,WORD PTR ds:[si]
      46:	6f                   	outs   dx,WORD PTR ds:[si]
      47:	6c                   	ins    BYTE PTR es:[di],dx
      48:	65 61                	gs popa
      4a:	6e                   	outs   dx,BYTE PTR ds:[si]
      4b:	f0 00 00             	lock add BYTE PTR [bx+si],al
      4e:	00 00                	add    BYTE PTR [bx+si],al
      50:	00 00                	add    BYTE PTR [bx+si],al
      52:	00 e7                	add    bh,ah
      54:	00 d8                	add    al,bl
      56:	00 c1                	add    cl,al
      58:	05 00 01             	add    ax,0x100
      5b:	fa                   	cli
      5c:	45                   	inc    bp
      5d:	d1 00                	rol    WORD PTR [bx+si],1
      5f:	9a 1f 31 01 cb       	call   0xcb01:0x311f
      64:	1f                   	pop    ds
      65:	61                   	popa
      66:	00 fc                	add    ah,bh
      68:	2e b1 00             	cs mov cl,0x0
      6b:	cd 11                	int    0x11
      6d:	75 00                	jne    0x6f
      6f:	3a 27                	cmp    ah,BYTE PTR [bx]
      71:	79 00                	jns    0x73
      73:	fa                   	cli
      74:	10 0f                	adc    BYTE PTR [bx],cl
      76:	02 d6                	add    dl,dh
      78:	14 81                	adc    al,0x81
      7a:	00 f4                	add    ah,dh
      7c:	4f                   	dec    di
      7d:	8d 00                	lea    ax,[bx+si]
      7f:	32 16 a9 00          	xor    dl,BYTE PTR ds:0xa9
      83:	57                   	push   di
      84:	1c 91                	sbb    al,0x91
      86:	00 51 1b             	add    BYTE PTR [bx+di+0x1b],dl
      89:	59                   	pop    cx
      8a:	00 38                	add    BYTE PTR [bx+si],bh
      8c:	50                   	push   ax
      8d:	95                   	xchg   bp,ax
      8e:	00 03                	add    BYTE PTR [bp+di],al
      90:	1d 99 00             	sbb    ax,0x99
      93:	21 50 6d             	and    WORD PTR [bx+si+0x6d],dx
      96:	00 db                	add    bl,bl
      98:	1b fc                	sbb    di,sp
      9a:	00 d9                	add    cl,bl
      9c:	62 a1 00 06          	bound  sp,DWORD PTR [bx+di+0x600]
      a0:	63 a5 00 8f          	arpl   WORD PTR [di-0x7100],sp
      a4:	60                   	pusha
      a5:	dd 00                	fld    QWORD PTR [bx+si]
      a7:	3a 1c                	cmp    bl,BYTE PTR [si]
      a9:	89 00                	mov    WORD PTR [bx+si],ax
      ab:	46                   	inc    si
      ac:	44                   	inc    sp
      ad:	69 00 08 61          	imul   ax,WORD PTR [bx+si],0x6108
      b1:	b5 00                	mov    ch,0x0
      b3:	5c                   	pop    sp
      b4:	61                   	popa
      b5:	b9 00 62             	mov    cx,0x6200
      b8:	5c                   	pop    sp
      b9:	e5 00                	in     ax,0x0
      bb:	3a 61 71             	cmp    ah,BYTE PTR [bx+di+0x71]
      be:	00 72 3f             	add    BYTE PTR [bp+si+0x3f],dh
      c1:	c5 00                	lds    ax,DWORD PTR [bx+si]
      c3:	29 3b                	sub    WORD PTR [bp+di],di
      c5:	c9                   	leave
      c6:	00 17                	add    BYTE PTR [bx],dl
      c8:	3e cd 00             	ds int 0x0
      cb:	88 3c                	mov    BYTE PTR [si],bh
      cd:	5d                   	pop    bp
      ce:	00 ed                	add    ch,ch
      d0:	3e d5 00             	ds aad 0x0
      d3:	77 3e                	ja     0x113
      d5:	d9 00                	fld    DWORD PTR [bx+si]
      d7:	c2 35 9d             	ret    0x9d35
      da:	00 1c                	add    BYTE PTR [si],bl
      dc:	48                   	dec    ax
      dd:	e1 00                	loope  0xdf
      df:	ae                   	scas   al,BYTE PTR es:[di]
      e0:	5f                   	pop    di
      e1:	ad                   	lods   ax,WORD PTR ds:[si]
      e2:	00 35                	add    BYTE PTR [di],dh
      e4:	62 bd 00 08          	bound  di,DWORD PTR [di+0x800]
      e8:	54                   	push   sp
      e9:	54                   	push   sp
      ea:	61                   	popa
      eb:	62 50 61             	bound  dx,DWORD PTR [bx+si+0x61]
      ee:	67 65 07             	addr32 gs pop es
      f1:	08 54 54             	or     BYTE PTR [si+0x54],dl
      f4:	61                   	popa
      f5:	62 50 61             	bound  dx,DWORD PTR [bx+si+0x61]
      f8:	67 65 6b 00 ff       	imul   ax,WORD PTR gs:[eax],0xffff
      fd:	01 d7                	add    di,dx
      ff:	07                   	pop    es
     100:	11 01                	adc    WORD PTR [bx+di],ax
     102:	0d 00 08             	or     ax,0x800
     105:	54                   	push   sp
     106:	61                   	popa
     107:	62 4e 6f             	bound  cx,DWORD PTR [bp+0x6f]
     10a:	74 42                	je     0x14e
     10c:	6b 06 00 66 01       	imul   ax,WORD PTR ds:0x6600,0x1
     111:	15 01 53             	adc    ax,0x5301
     114:	1d 19 01             	sbb    ax,0x119
     117:	8c 1d                	mov    WORD PTR [di],ds
     119:	39 01                	cmp    WORD PTR [bx+di],ax
     11b:	01 00                	add    WORD PTR [bx+si],ax
     11d:	00 00                	add    BYTE PTR [bx+si],al
     11f:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     123:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
     127:	07                   	pop    es
     128:	43                   	inc    bx
     129:	61                   	popa
     12a:	70 74                	jo     0x1a0
     12c:	69 6f 6e d4 22       	imul   bp,WORD PTR [bx+0x6e],0x22d4
     131:	71 01                	jno    0x134
     133:	24 00                	and    al,0x0
     135:	ff                   	(bad)
     136:	ff e1                	jmp    cx
     138:	17                   	pop    ss
     139:	50                   	push   ax
     13a:	01 00                	add    WORD PTR [bx+si],ax
     13c:	00 00                	add    BYTE PTR [bx+si],al
     13e:	00 00                	add    BYTE PTR [bx+si],al
     140:	80 00 00             	add    BYTE PTR [bx+si],0x0
     143:	00 80 05 00          	add    BYTE PTR [bx+si+0x5],al
     147:	06                   	push   es
     148:	48                   	dec    ax
     149:	65 69 67 68 74 52    	imul   sp,WORD PTR gs:[bx+0x68],0x5274
     14f:	01 54 01             	add    WORD PTR [si+0x1],dx
     152:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     153:	63 58 01             	arpl   WORD PTR [bx+si+0x1],bx
     156:	60                   	pusha
     157:	64 79 01             	fs jns 0x15b
     15a:	00 00                	add    BYTE PTR [bx+si],al
     15c:	00 00                	add    BYTE PTR [bx+si],al
     15e:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     162:	ff                   	(bad)
     163:	ff 0a                	dec    WORD PTR [bp+si]
     165:	00 08                	add    BYTE PTR [bx+si],cl
     167:	54                   	push   sp
     168:	61                   	popa
     169:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     16c:	64 65 72 07          	fs gs jb 0x177
     170:	23 91 01 29          	and    dx,WORD PTR [bx+di+0x2901]
     174:	00 ff                	add    bh,bh
     176:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     179:	99                   	cwd
     17a:	01 00                	add    WORD PTR [bx+si],ax
     17c:	00 00                	add    BYTE PTR [bx+si],al
     17e:	00 00                	add    BYTE PTR [bx+si],al
     180:	80 01 00             	add    BYTE PTR [bx+di],0x0
     183:	00 00                	add    BYTE PTR [bx+si],al
     185:	0b 00                	or     ax,WORD PTR [bx+si]
     187:	07                   	pop    es
     188:	56                   	push   si
     189:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     18e:	65 d4 22             	gs aam 0x22
     191:	af                   	scas   ax,WORD PTR es:[di]
     192:	01 22                	add    WORD PTR [bp+si],sp
     194:	00 ff                	add    bh,bh
     196:	ff                   	(bad)
     197:	bf 17 b7             	mov    di,0xb717
     19a:	01 00                	add    WORD PTR [bx+si],ax
     19c:	00 00                	add    BYTE PTR [bx+si],al
     19e:	00 00                	add    BYTE PTR [bx+si],al
     1a0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1a3:	00 80 04 00          	add    BYTE PTR [bx+si+0x4],al
     1a7:	05 57 69             	add    ax,0x6957
     1aa:	64 74 68             	fs je  0x215
     1ad:	07                   	pop    es
     1ae:	23 e7                	and    sp,di
     1b0:	01 2a                	add    WORD PTR [bp+si],bp
     1b2:	00 ff                	add    bh,bh
     1b4:	ff                   	(bad)
     1b5:	b8 1c 5f             	mov    ax,0x5f1c
     1b8:	02 00                	add    al,BYTE PTR [bx+si]
     1ba:	00 00                	add    BYTE PTR [bx+si],al
     1bc:	00 00                	add    BYTE PTR [bx+si],al
     1be:	80 01 00             	add    BYTE PTR [bx+di],0x0
     1c1:	00 00                	add    BYTE PTR [bx+si],al
     1c3:	0c 00                	or     al,0x0
     1c5:	07                   	pop    es
     1c6:	45                   	inc    bp
     1c7:	6e                   	outs   dx,BYTE PTR ds:[si]
     1c8:	61                   	popa
     1c9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1cc:	64 a9 02 00          	fs test ax,0x2
     1d0:	00 00                	add    BYTE PTR [bx+si],al
     1d2:	00 7d 02             	add    BYTE PTR [di+0x2],bh
     1d5:	6d                   	ins    WORD PTR es:[di],dx
     1d6:	02 0e 01 f3          	add    cl,BYTE PTR ds:0xf301
     1da:	08 c0                	or     al,al
     1dc:	02 fa                	add    bh,dl
     1de:	45                   	inc    bp
     1df:	53                   	push   bx
     1e0:	02 9a 1f d1          	add    bl,BYTE PTR [bp+si-0x2ee1]
     1e4:	02 cb                	add    cl,bl
     1e6:	1f                   	pop    ds
     1e7:	e3 01                	jcxz   0x1ea
     1e9:	49                   	dec    cx
     1ea:	1f                   	pop    ds
     1eb:	8f 02                	pop    WORD PTR [bp+si]
     1ed:	cd 11                	int    0x11
     1ef:	f7 01 3a 27          	test   WORD PTR [bx+di],0x273a
     1f3:	fb                   	sti
     1f4:	01 fa                	add    dx,di
     1f6:	10 54 03             	adc    BYTE PTR [si+0x3],dl
     1f9:	d6                   	(bad)
     1fa:	14 03                	adc    al,0x3
     1fc:	02 e3                	add    ah,bl
     1fe:	1f                   	pop    ds
     1ff:	07                   	pop    es
     200:	02 32                	add    dh,BYTE PTR [bp+si]
     202:	16                   	push   ss
     203:	2b 02                	sub    ax,WORD PTR [bp+si]
     205:	f6 20                	mul    BYTE PTR [bx+si]
     207:	13 02                	adc    ax,WORD PTR [bp+si]
     209:	51                   	push   cx
     20a:	1b db                	sbb    bx,bx
     20c:	01 38                	add    WORD PTR [bx+si],di
     20e:	50                   	push   ax
     20f:	17                   	pop    ss
     210:	02 6f 23             	add    ch,BYTE PTR [bx+0x23]
     213:	6b 02 21             	imul   ax,WORD PTR [bp+si],0x21
     216:	50                   	push   ax
     217:	ef                   	out    dx,ax
     218:	01 7b 1d             	add    WORD PTR [bp+di+0x1d],di
     21b:	eb 01                	jmp    0x21e
     21d:	d9 62 23             	fldenv [bp+si+0x23]
     220:	02 06 63 27          	add    al,BYTE PTR ds:0x2763
     224:	02 8f 60 2f          	add    cl,BYTE PTR [bx+0x2f60]
     228:	02 3a                	add    bh,BYTE PTR [bp+si]
     22a:	1c 0b                	sbb    al,0xb
     22c:	02 46 44             	add    al,BYTE PTR [bp+0x44]
     22f:	33 02                	xor    ax,WORD PTR [bp+si]
     231:	08 61 37             	or     BYTE PTR [bx+di+0x37],ah
     234:	02 5c 61             	add    bl,BYTE PTR [si+0x61]
     237:	3b 02                	cmp    ax,WORD PTR [bp+si]
     239:	62 5c 67             	bound  bx,DWORD PTR [si+0x67]
     23c:	02 3a                	add    bh,BYTE PTR [bp+si]
     23e:	61                   	popa
     23f:	f3 01 72 3f          	repz add WORD PTR [bp+si+0x3f],si
     243:	4b                   	dec    bx
     244:	02 b3 1f 63          	add    dh,BYTE PTR [bp+di+0x631f]
     248:	02 17                	add    dl,BYTE PTR [bx]
     24a:	3e 4f                	ds dec di
     24c:	02 88 3c df          	add    cl,BYTE PTR [bx+si-0x20c4]
     250:	01 ed                	add    bp,bp
     252:	3e 57                	ds push di
     254:	02 77 3e             	add    dh,BYTE PTR [bx+0x3e]
     257:	1f                   	pop    ds
     258:	02 46 30             	add    al,BYTE PTR [bp+0x30]
     25b:	47                   	inc    di
     25c:	02 26 6d 43          	add    ah,BYTE PTR ds:0x436d
     260:	02 05                	add    al,BYTE PTR [di]
     262:	24 1b                	and    al,0x1b
     264:	02 35                	add    dh,BYTE PTR [di]
     266:	62 3f                	bound  di,DWORD PTR [bx]
     268:	02 7d 2e             	add    bh,BYTE PTR [di+0x2e]
     26b:	5b                   	pop    bx
     26c:	02 0f                	add    cl,BYTE PTR [bx]
     26e:	54                   	push   sp
     26f:	54                   	push   sp
     270:	61                   	popa
     271:	62 62 65             	bound  sp,DWORD PTR [bp+si+0x65]
     274:	64 4e                	fs dec si
     276:	6f                   	outs   dx,WORD PTR ds:[si]
     277:	74 65                	je     0x2de
     279:	62 6f 6f             	bound  bp,DWORD PTR [bx+0x6f]
     27c:	6b 07 00             	imul   ax,WORD PTR [bx],0x0
     27f:	07                   	pop    es
     280:	00 08                	add    BYTE PTR [bx+si],cl
     282:	00 87 00 06          	add    BYTE PTR [bx+0x600],al
     286:	0f 64 0f             	pcmpgtb mm1,QWORD PTR [bx]
     289:	ee                   	out    dx,al
     28a:	ff f1                	push   cx
     28c:	ff 25                	jmp    WORD PTR [di]
     28e:	27                   	daa
     28f:	93                   	xchg   bx,ax
     290:	02 85 27 97          	add    al,BYTE PTR [di-0x68d9]
     294:	02 e5                	add    ah,ch
     296:	27                   	daa
     297:	9b                   	fwait
     298:	02 fb                	add    bh,bl
     29a:	27                   	daa
     29b:	9f                   	lahf
     29c:	02 3f                	add    bh,BYTE PTR [bx]
     29e:	2f                   	das
     29f:	a3 02 ca             	mov    ds:0xca02,ax
     2a2:	32 a7 02 d0          	xor    ah,BYTE PTR [bx-0x2ffe]
     2a6:	28 bc 02 07          	sub    BYTE PTR [si+0x702],bh
     2aa:	0f 54 54 61          	andps  xmm2,XMMWORD PTR [si+0x61]
     2ae:	62 62 65             	bound  sp,DWORD PTR [bp+si+0x65]
     2b1:	64 4e                	fs dec si
     2b3:	6f                   	outs   dx,WORD PTR ds:[si]
     2b4:	74 65                	je     0x31b
     2b6:	62 6f 6f             	bound  bp,DWORD PTR [bx+0x6f]
     2b9:	6b ed 01             	imul   bp,bp,0x1
     2bc:	d5 02                	aad    0x2
     2be:	8a 09                	mov    cl,BYTE PTR [bx+di]
     2c0:	f4                   	hlt
     2c1:	02 1a                	add    bl,BYTE PTR [bp+si]
     2c3:	00 08                	add    BYTE PTR [bx+si],cl
     2c5:	54                   	push   sp
     2c6:	61                   	popa
     2c7:	62 4e 6f             	bound  cx,DWORD PTR [bp+0x6f]
     2ca:	74 42                	je     0x30e
     2cc:	6b 11 00             	imul   dx,WORD PTR [bx+di],0x0
     2cf:	62 23                	bound  sp,DWORD PTR [bp+di]
     2d1:	12 03                	adc    al,BYTE PTR [bp+di]
     2d3:	cb                   	retf
     2d4:	26 d9 02             	fld    DWORD PTR es:[bp+si]
     2d7:	a3 26 3a             	mov    ds:0x3a26,ax
     2da:	03 00                	add    ax,WORD PTR [bx+si]
     2dc:	00 00                	add    BYTE PTR [bx+si],al
     2de:	00 00                	add    BYTE PTR [bx+si],al
     2e0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2e3:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
     2e7:	0a 41 63             	or     al,BYTE PTR [bx+di+0x63]
     2ea:	74 69                	je     0x355
     2ec:	76 65                	jbe    0x353
     2ee:	50                   	push   ax
     2ef:	61                   	popa
     2f0:	67 65 e2 00          	addr32 gs loop 0x2f4
     2f4:	fc                   	cld
     2f5:	02 2d                	add    ch,BYTE PTR [di]
     2f7:	00 ff                	add    bh,bh
     2f9:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     2fc:	1a 03                	sbb    al,BYTE PTR [bp+di]
     2fe:	01 00                	add    WORD PTR [bx+si],ax
     300:	00 00                	add    BYTE PTR [bx+si],al
     302:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     306:	00 00                	add    BYTE PTR [bx+si],al
     308:	0a 00                	or     al,BYTE PTR [bx+si]
     30a:	05 41 6c             	add    ax,0x6c41
     30d:	69 67 6e 07 23       	imul   sp,WORD PTR [bx+0x6e],0x2307
     312:	32 03                	xor    al,BYTE PTR [bp+di]
     314:	2a 00                	sub    al,BYTE PTR [bx+si]
     316:	ff                   	(bad)
     317:	ff                   	(bad)
     318:	b8 1c 7a             	mov    ax,0x7a1c
     31b:	03 01                	add    ax,WORD PTR [bx+di]
     31d:	00 00                	add    BYTE PTR [bx+si],al
     31f:	00 00                	add    BYTE PTR [bx+si],al
     321:	80 01 00             	add    BYTE PTR [bx+di],0x0
     324:	00 00                	add    BYTE PTR [bx+si],al
     326:	0b 00                	or     ax,WORD PTR [bx+si]
     328:	07                   	pop    es
     329:	45                   	inc    bp
     32a:	6e                   	outs   dx,BYTE PTR ds:[si]
     32b:	61                   	popa
     32c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     32f:	64 d4 22             	fs aam 0x22
     332:	8f 03                	pop    WORD PTR [bp+di]
     334:	ee                   	out    dx,al
     335:	00 ff                	add    bh,bh
     337:	ff 6f 24             	jmp    DWORD PTR [bx+0x24]
     33a:	5c                   	pop    sp
     33b:	03 01                	add    ax,WORD PTR [bx+di]
     33d:	00 00                	add    BYTE PTR [bx+si],al
     33f:	00 00                	add    BYTE PTR [bx+si],al
     341:	80 00 00             	add    BYTE PTR [bx+si],0x0
     344:	00 00                	add    BYTE PTR [bx+si],al
     346:	0c 00                	or     al,0x0
     348:	09 50 61             	or     WORD PTR [bx+si+0x61],dx
     34b:	67 65 49             	addr32 gs dec cx
     34e:	6e                   	outs   dx,BYTE PTR ds:[si]
     34f:	64 65 78 8b          	fs gs js 0x2de
     353:	03 7b 04             	add    di,WORD PTR [bp+di+0x4]
     356:	ea 00 ff ff bc       	jmp    0xbcff:0xff00
     35b:	23 97 03 00          	and    dx,WORD PTR [bx+0x3]
     35f:	00 00                	add    BYTE PTR [bx+si],al
     361:	00 00                	add    BYTE PTR [bx+si],al
     363:	80 00 00             	add    BYTE PTR [bx+si],0x0
     366:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     36a:	05 50 61             	add    ax,0x6150
     36d:	67 65 73 22          	addr32 gs jae 0x393
     371:	03 b2 03 34          	add    si,WORD PTR [bp+si+0x3403]
     375:	00 ff                	add    bh,bh
     377:	ff                   	jmp    (bad)
     378:	eb 1d                	jmp    0x397
     37a:	7e 03                	jle    0x37f
     37c:	08 1e da 03          	or     BYTE PTR ds:0x3da,bl
     380:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     384:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
     388:	04 46                	add    al,0x46
     38a:	6f                   	outs   dx,WORD PTR ds:[si]
     38b:	6e                   	outs   dx,BYTE PTR ds:[si]
     38c:	74 d4                	je     0x362
     38e:	22 d2                	and    dl,dl
     390:	03 f8                	add    di,ax
     392:	00 ff                	add    bh,bh
     394:	ff 73 29             	push   WORD PTR [bp+di+0x29]
     397:	ba 03 01             	mov    dx,0x103
     39a:	00 00                	add    BYTE PTR [bx+si],al
     39c:	00 00                	add    BYTE PTR [bx+si],al
     39e:	80 03 00             	add    BYTE PTR [bp+di],0x0
     3a1:	00 00                	add    BYTE PTR [bx+si],al
     3a3:	0f 00 0a             	str    WORD PTR [bp+si]
     3a6:	54                   	push   sp
     3a7:	61                   	popa
     3a8:	62 73 50             	bound  si,DWORD PTR [bp+di+0x50]
     3ab:	65 72 52             	gs jb  0x400
     3ae:	6f                   	outs   dx,WORD PTR ds:[si]
     3af:	77 22                	ja     0x3d3
     3b1:	03 bd 0e f0          	add    di,WORD PTR [di-0xff2]
     3b5:	00 ff                	add    bh,bh
     3b7:	ff 21                	jmp    WORD PTR [bx+di]
     3b9:	2f                   	das
     3ba:	9b                   	fwait
     3bb:	04 01                	add    al,0x1
     3bd:	00 00                	add    BYTE PTR [bx+si],al
     3bf:	00 00                	add    BYTE PTR [bx+si],al
     3c1:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3c4:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     3c8:	07                   	pop    es
     3c9:	54                   	push   sp
     3ca:	61                   	popa
     3cb:	62 46 6f             	bound  ax,DWORD PTR [bp+0x6f]
     3ce:	6e                   	outs   dx,BYTE PTR ds:[si]
     3cf:	74 07                	je     0x3d8
     3d1:	23 f9                	and    di,cx
     3d3:	03 49 00             	add    cx,WORD PTR [bx+di+0x0]
     3d6:	ff                   	(bad)
     3d7:	ff a1 1e 01          	jmp    WORD PTR [bx+di+0x11e]
     3db:	04 01                	add    al,0x1
     3dd:	00 00                	add    BYTE PTR [bx+si],al
     3df:	00 00                	add    BYTE PTR [bx+si],al
     3e1:	80 01 00             	add    BYTE PTR [bx+di],0x0
     3e4:	00 00                	add    BYTE PTR [bx+si],al
     3e6:	11 00                	adc    WORD PTR [bx+si],ax
     3e8:	0e                   	push   cs
     3e9:	50                   	push   ax
     3ea:	61                   	popa
     3eb:	72 65                	jb     0x452
     3ed:	6e                   	outs   dx,BYTE PTR ds:[si]
     3ee:	74 53                	je     0x443
     3f0:	68 6f 77             	push   0x776f
     3f3:	48                   	dec    ax
     3f4:	69 6e 74 07 23       	imul   bp,WORD PTR [bp+0x74],0x2307
     3f9:	3b 04                	cmp    ax,WORD PTR [si]
     3fb:	48                   	dec    ax
     3fc:	00 ff                	add    bh,bh
     3fe:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     401:	05 04 23             	add    ax,0x2304
     404:	1e                   	push   ds
     405:	1a 04                	sbb    al,BYTE PTR [si]
     407:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     40b:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
     40f:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     412:	6f                   	outs   dx,WORD PTR ds:[si]
     413:	77 48                	ja     0x45d
     415:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     41a:	1e                   	push   ds
     41b:	04 a6                	add    al,0xa6
     41d:	63 22                	arpl   WORD PTR [bp+si],sp
     41f:	04 60                	add    al,0x60
     421:	64 43                	fs inc bx
     423:	04 01                	add    al,0x1
     425:	00 00                	add    BYTE PTR [bx+si],al
     427:	00 00                	add    BYTE PTR [bx+si],al
     429:	80 ff ff             	cmp    bh,0xff
     42c:	ff                   	(bad)
     42d:	ff 13                	call   WORD PTR [bp+di]
     42f:	00 08                	add    BYTE PTR [bx+si],cl
     431:	54                   	push   sp
     432:	61                   	popa
     433:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     436:	64 65 72 07          	fs gs jb 0x441
     43a:	23 5b 04             	and    bx,WORD PTR [bp+di+0x4]
     43d:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     43e:	00 ff                	add    bh,bh
     440:	ff 88 64 63          	dec    WORD PTR [bx+si+0x6364]
     444:	04 01                	add    al,0x1
     446:	00 00                	add    BYTE PTR [bx+si],al
     448:	00 00                	add    BYTE PTR [bx+si],al
     44a:	80 01 00             	add    BYTE PTR [bx+di],0x0
     44d:	00 00                	add    BYTE PTR [bx+si],al
     44f:	14 00                	adc    al,0x0
     451:	07                   	pop    es
     452:	54                   	push   sp
     453:	61                   	popa
     454:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     457:	6f                   	outs   dx,WORD PTR ds:[si]
     458:	70 07                	jo     0x461
     45a:	23 17                	and    dx,WORD PTR [bx]
     45c:	05 29 00             	add    ax,0x29
     45f:	ff                   	(bad)
     460:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     463:	f3 05 01 00          	repz add ax,0x1
     467:	00 00                	add    BYTE PTR [bx+si],al
     469:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     46d:	00 00                	add    BYTE PTR [bx+si],al
     46f:	15 00 07             	adc    ax,0x700
     472:	56                   	push   si
     473:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     478:	65 71 00             	gs jno 0x47b
     47b:	bc 04 fe             	mov    sp,0xfe04
     47e:	00 ff                	add    bh,bh
     480:	ff                   	(bad)
     481:	fe 00                	inc    BYTE PTR [bx+si]
     483:	ff                   	(bad)
     484:	ff 01                	inc    WORD PTR [bx+di]
     486:	00 00                	add    BYTE PTR [bx+si],al
     488:	00 00                	add    BYTE PTR [bx+si],al
     48a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     48d:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     491:	07                   	pop    es
     492:	4f                   	dec    di
     493:	6e                   	outs   dx,BYTE PTR ds:[si]
     494:	43                   	inc    bx
     495:	6c                   	ins    BYTE PTR es:[di],dx
     496:	69 63 6b 02 00       	imul   sp,WORD PTR [bp+di+0x6b],0x2
     49b:	2b 05                	sub    ax,WORD PTR [di]
     49d:	06                   	push   es
     49e:	01 ff                	add    di,di
     4a0:	ff 06 01 ff          	inc    WORD PTR ds:0xff01
     4a4:	ff 01                	inc    WORD PTR [bx+di]
     4a6:	00 00                	add    BYTE PTR [bx+si],al
     4a8:	00 00                	add    BYTE PTR [bx+si],al
     4aa:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4ad:	00 80 17 00          	add    BYTE PTR [bx+si+0x17],al
     4b1:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     4b4:	43                   	inc    bx
     4b5:	68 61 6e             	push   0x6e61
     4b8:	67 65 71 00          	addr32 gs jno 0x4bc
     4bc:	dc 04                	fadd   QWORD PTR [si]
     4be:	c8 00 ff ff          	enter  0xff00,0xff
     4c2:	c8 00 ff ff          	enter  0xff00,0xff
     4c6:	01 00                	add    WORD PTR [bx+si],ax
     4c8:	00 00                	add    BYTE PTR [bx+si],al
     4ca:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     4ce:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
     4d2:	07                   	pop    es
     4d3:	4f                   	dec    di
     4d4:	6e                   	outs   dx,BYTE PTR ds:[si]
     4d5:	45                   	inc    bp
     4d6:	6e                   	outs   dx,BYTE PTR ds:[si]
     4d7:	74 65                	je     0x53e
     4d9:	72 71                	jb     0x54c
     4db:	00 1f                	add    BYTE PTR [bx],bl
     4dd:	05 d0 00             	add    ax,0xd0
     4e0:	ff                   	(bad)
     4e1:	ff d0                	call   ax
     4e3:	00 ff                	add    bh,bh
     4e5:	ff 01                	inc    WORD PTR [bx+di]
     4e7:	00 00                	add    BYTE PTR [bx+si],al
     4e9:	00 00                	add    BYTE PTR [bx+si],al
     4eb:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4ee:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
     4f2:	06                   	push   es
     4f3:	4f                   	dec    di
     4f4:	6e                   	outs   dx,BYTE PTR ds:[si]
     4f5:	45                   	inc    bp
     4f6:	78 69                	js     0x561
     4f8:	74 80                	je     0x47a
     4fa:	05 00 00             	add    ax,0x0
     4fd:	00 00                	add    BYTE PTR [bx+si],al
     4ff:	00 00                	add    BYTE PTR [bx+si],al
     501:	71 05                	jno    0x508
     503:	12 00                	adc    al,BYTE PTR [bx+si]
     505:	2a 03                	sub    al,BYTE PTR [bp+di]
     507:	96                   	xchg   si,ax
     508:	05 64 20             	add    ax,0x2064
     50b:	bf 05 9a             	mov    di,0x9a05
     50e:	1f                   	pop    ds
     50f:	0b 05                	or     ax,WORD PTR [di]
     511:	cb                   	retf
     512:	1f                   	pop    ds
     513:	0f 05                	syscall
     515:	66 1f                	popd   ds
     517:	13 05                	adc    ax,WORD PTR [di]
     519:	cd 11                	int    0x11
     51b:	07                   	pop    es
     51c:	05 f0 13             	add    ax,0x13f0
     51f:	37                   	aaa
     520:	05 48 13             	add    ax,0x1348
     523:	53                   	push   bx
     524:	05 e8 06             	add    ax,0x6e8
     527:	33 05                	xor    ax,WORD PTR [di]
     529:	cf                   	iret
     52a:	06                   	push   es
     52b:	27                   	daa
     52c:	05 68 07             	add    ax,0x768
     52f:	3b 05                	cmp    ax,WORD PTR [di]
     531:	1f                   	pop    ds
     532:	07                   	pop    es
     533:	2f                   	das
     534:	05 d8 19             	add    ax,0x19d8
     537:	3f                   	aas
     538:	05 8d 07             	add    ax,0x78d
     53b:	4b                   	dec    bx
     53c:	05 4a 12             	add    ax,0x124a
     53f:	43                   	inc    bx
     540:	05 78 12             	add    ax,0x1278
     543:	47                   	inc    di
     544:	05 b2 12             	add    ax,0x12b2
     547:	23 05                	and    ax,WORD PTR [di]
     549:	94                   	xchg   sp,ax
     54a:	07                   	pop    es
     54b:	4f                   	dec    di
     54c:	05 68 08             	add    ax,0x868
     54f:	5f                   	pop    di
     550:	05 55 14             	add    ax,0x1455
     553:	57                   	push   di
     554:	05 13 16             	add    ax,0x1613
     557:	5b                   	pop    bx
     558:	05 e0 16             	add    ax,0x16e0
     55b:	63 05                	arpl   WORD PTR [di],ax
     55d:	53                   	push   bx
     55e:	09 67 05             	or     WORD PTR [bx+0x5],sp
     561:	78 17                	js     0x57a
     563:	6b 05 62             	imul   ax,WORD PTR [di],0x62
     566:	0a 92 05 39          	or     dl,BYTE PTR [bp+si+0x3905]
     56a:	1a 6f 05             	sbb    ch,BYTE PTR [bx+0x5]
     56d:	ac                   	lods   al,BYTE PTR ds:[si]
     56e:	1b 1b                	sbb    bx,WORD PTR [bp+di]
     570:	05 0e 54             	add    ax,0x540e
     573:	54                   	push   sp
     574:	61                   	popa
     575:	62 50 61             	bound  dx,DWORD PTR [bx+si+0x61]
     578:	67 65 41             	addr32 gs inc cx
     57b:	63 63 65             	arpl   WORD PTR [bp+di+0x65],sp
     57e:	73 73                	jae    0x5f3
     580:	07                   	pop    es
     581:	0e                   	push   cs
     582:	54                   	push   sp
     583:	54                   	push   sp
     584:	61                   	popa
     585:	62 50 61             	bound  dx,DWORD PTR [bx+si+0x61]
     588:	67 65 41             	addr32 gs inc cx
     58b:	63 63 65             	arpl   WORD PTR [bp+di+0x65],sp
     58e:	73 73                	jae    0x603
     590:	19 05                	sbb    WORD PTR [di],ax
     592:	df 05                	fild   WORD PTR [di]
     594:	8b 03                	mov    ax,WORD PTR [bp+di]
     596:	d7                   	xlat   BYTE PTR ds:[bx]
     597:	05 00 00             	add    ax,0x0
     59a:	08 54 61             	or     BYTE PTR [si+0x61],dl
     59d:	62 4e 6f             	bound  cx,DWORD PTR [bp+0x6f]
     5a0:	74 42                	je     0x5e4
     5a2:	6b 00 00             	imul   ax,WORD PTR [bx+si],0x0
     5a5:	4c                   	dec    sp
     5a6:	06                   	push   es
     5a7:	00 00                	add    BYTE PTR [bx+si],al
     5a9:	00 00                	add    BYTE PTR [bx+si],al
     5ab:	2c 06                	sub    al,0x6
     5ad:	21 06 91 00          	and    WORD PTR ds:0x91,ax
     5b1:	3d 08 5e             	cmp    ax,0x5e08
     5b4:	06                   	push   es
     5b5:	10 26 cb 05          	adc    BYTE PTR ds:0x5cb,ah
     5b9:	9a 1f 7c 06 cb       	call   0xcb06:0x7c1f
     5be:	1f                   	pop    ds
     5bf:	bb 05 f0             	mov    bx,0xf005
     5c2:	68 b7 05             	push   0x5b7
     5c5:	cd 11                	int    0x11
     5c7:	cf                   	iret
     5c8:	05 3a 27             	add    ax,0x273a
     5cb:	f7 05 fa 10          	test   WORD PTR [di],0x10fa
     5cf:	01 07                	add    WORD PTR [bx],ax
     5d1:	d6                   	(bad)
     5d2:	14 db                	adc    al,0xdb
     5d4:	05 f4 4f             	add    ax,0x4ff4
     5d7:	e7 05                	out    0x5,ax
     5d9:	32 16 03 06          	xor    dl,BYTE PTR ds:0x603
     5dd:	4b                   	dec    bx
     5de:	16                   	push   ss
     5df:	1f                   	pop    ds
     5e0:	06                   	push   es
     5e1:	51                   	push   cx
     5e2:	1b 07                	sbb    ax,WORD PTR [bx]
     5e4:	06                   	push   es
     5e5:	38 50 eb             	cmp    BYTE PTR [bx+si-0x15],dl
     5e8:	05 1a 50             	add    ax,0x501a
     5eb:	ef                   	out    dx,ax
     5ec:	05 21 50             	add    ax,0x5021
     5ef:	c7 05 86 68          	mov    WORD PTR [di],0x6886
     5f3:	c3                   	ret
     5f4:	05 3f 19             	add    ax,0x193f
     5f7:	fb                   	sti
     5f8:	05 78 18             	add    ax,0x1878
     5fb:	ff 05                	inc    WORD PTR [di]
     5fd:	02 21                	add    ah,BYTE PTR [bx+di]
     5ff:	d3 05                	rol    WORD PTR [di],cl
     601:	3a 1c                	cmp    bl,BYTE PTR [si]
     603:	e3 05                	jcxz   0x60a
     605:	15 25 0b             	adc    ax,0xb25
     608:	06                   	push   es
     609:	37                   	aaa
     60a:	22 0f                	and    cl,BYTE PTR [bx]
     60c:	06                   	push   es
     60d:	df 22                	fbld   TBYTE PTR [bp+si]
     60f:	13 06 f8 16          	adc    ax,WORD PTR ds:0x16f8
     613:	17                   	pop    ss
     614:	06                   	push   es
     615:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     616:	22 b3 05 f9          	and    dh,BYTE PTR [bp+di-0x6fb]
     61a:	0c 3a                	or     al,0x3a
     61c:	06                   	push   es
     61d:	eb 0b                	jmp    0x62a
     61f:	1b 06 0a 54          	sbb    ax,WORD PTR ds:0x540a
     623:	54                   	push   sp
     624:	61                   	popa
     625:	62 42 75             	bound  ax,DWORD PTR [bp+si+0x75]
     628:	74 74                	je     0x69e
     62a:	6f                   	outs   dx,WORD PTR ds:[si]
     62b:	6e                   	outs   dx,BYTE PTR ds:[si]
     62c:	05 00 18             	add    ax,0x1800
     62f:	0f 0e                	femms
     631:	0f 12 0f             	movlps xmm1,QWORD PTR [bx]
     634:	fa                   	cli
     635:	ff                   	(bad)
     636:	fe                   	(bad)
     637:	ff 97 0b 3e          	call   WORD PTR [bx+0x3e0b]
     63b:	06                   	push   es
     63c:	93                   	xchg   bx,ax
     63d:	1b 42 06             	sbb    ax,WORD PTR [bp+si+0x6]
     640:	b6 1b                	mov    dh,0x1b
     642:	46                   	inc    si
     643:	06                   	push   es
     644:	4d                   	dec    bp
     645:	0c 4a                	or     al,0x4a
     647:	06                   	push   es
     648:	86 0c                	xchg   BYTE PTR [si],cl
     64a:	5a                   	pop    dx
     64b:	06                   	push   es
     64c:	07                   	pop    es
     64d:	0a 54 54             	or     dl,BYTE PTR [si+0x54]
     650:	61                   	popa
     651:	62 42 75             	bound  ax,DWORD PTR [bp+si+0x75]
     654:	74 74                	je     0x6ca
     656:	6f                   	outs   dx,WORD PTR ds:[si]
     657:	6e                   	outs   dx,BYTE PTR ds:[si]
     658:	c5 05                	lds    ax,DWORD PTR [di]
     65a:	cd 07                	int    0x7
     65c:	ad                   	lods   ax,WORD PTR ds:[si]
     65d:	08 0c                	or     BYTE PTR [si],cl
     65f:	07                   	pop    es
     660:	08 00                	or     BYTE PTR [bx+si],al
     662:	08 54 61             	or     BYTE PTR [si+0x61],dl
     665:	62 4e 6f             	bound  cx,DWORD PTR [bp+0x6f]
     668:	74 42                	je     0x6ac
     66a:	6b 00 00             	imul   ax,WORD PTR [bx+si],0x0
     66d:	55                   	push   bp
     66e:	89 e5                	mov    bp,sp
     670:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     674:	74 08                	je     0x67e
     676:	83 ec 08             	sub    sp,0x8
     679:	9a e2 1f 89 06       	call   0x689:0x1fe2
     67e:	31 c0                	xor    ax,ax
     680:	50                   	push   ax
     681:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     684:	06                   	push   es
     685:	57                   	push   di
     686:	9a 50 1f 19 07       	call   0x719:0x1f50
     68b:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
     68e:	8b 56 16             	mov    dx,WORD PTR [bp+0x16]
     691:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     694:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
     698:	26 89 55 0c          	mov    WORD PTR es:[di+0xc],dx
     69c:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     69f:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
     6a2:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
     6a6:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
     6aa:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
     6ad:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
     6b0:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
     6b4:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
     6b8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     6bc:	74 07                	je     0x6c5
     6be:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     6c2:	83 c4 06             	add    sp,0x6
     6c5:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     6c8:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     6cb:	c9                   	leave
     6cc:	ca 12 00             	retf   0x12
     6cf:	c8 02 00 00          	enter  0x2,0x0
     6d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     6d6:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     6da:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     6de:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     6e1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     6e4:	c9                   	leave
     6e5:	ca 04 00             	retf   0x4
     6e8:	c8 00 01 00          	enter  0x100,0x0
     6ec:	8d be 00 ff          	lea    di,[bp-0x100]
     6f0:	16                   	push   ss
     6f1:	57                   	push   di
     6f2:	ff 76 0a             	push   WORD PTR [bp+0xa]
     6f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     6f8:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     6fc:	06                   	push   es
     6fd:	57                   	push   di
     6fe:	9a d0 0d 36 07       	call   0x736:0xdd0
     703:	89 c7                	mov    di,ax
     705:	8e c2                	mov    es,dx
     707:	06                   	push   es
     708:	57                   	push   di
     709:	9a 53 1d 41 07       	call   0x741:0x1d53
     70e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     711:	06                   	push   es
     712:	57                   	push   di
     713:	68 ff 00             	push   0xff
     716:	9a e7 17 d4 07       	call   0x7d4:0x17e7
     71b:	c9                   	leave
     71c:	ca 06 00             	retf   0x6
     71f:	55                   	push   bp
     720:	89 e5                	mov    bp,sp
     722:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     725:	06                   	push   es
     726:	57                   	push   di
     727:	ff 76 0e             	push   WORD PTR [bp+0xe]
     72a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     72d:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     731:	06                   	push   es
     732:	57                   	push   di
     733:	9a d0 0d 57 07       	call   0x757:0xdd0
     738:	89 c7                	mov    di,ax
     73a:	8e c2                	mov    es,dx
     73c:	06                   	push   es
     73d:	57                   	push   di
     73e:	9a 8c 1d 62 07       	call   0x762:0x1d8c
     743:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     746:	06                   	push   es
     747:	57                   	push   di
     748:	ff 76 0e             	push   WORD PTR [bp+0xe]
     74b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     74e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     752:	06                   	push   es
     753:	57                   	push   di
     754:	9a d0 0d 7b 07       	call   0x77b:0xdd0
     759:	89 c7                	mov    di,ax
     75b:	8e c2                	mov    es,dx
     75d:	06                   	push   es
     75e:	57                   	push   di
     75f:	9a 8c 1d 62 08       	call   0x862:0x1d8c
     764:	c9                   	leave
     765:	ca 0a 00             	retf   0xa
     768:	c8 04 00 00          	enter  0x4,0x0
     76c:	ff 76 0a             	push   WORD PTR [bp+0xa]
     76f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     772:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     776:	06                   	push   es
     777:	57                   	push   di
     778:	9a d0 0d c5 07       	call   0x7c5:0xdd0
     77d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     780:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     783:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     786:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     789:	c9                   	leave
     78a:	ca 06 00             	retf   0x6
     78d:	55                   	push   bp
     78e:	89 e5                	mov    bp,sp
     790:	c9                   	leave
     791:	ca 06 00             	retf   0x6
     794:	c8 04 00 00          	enter  0x4,0x0
     798:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     79b:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     79f:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     7a3:	48                   	dec    ax
     7a4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     7a7:	31 c0                	xor    ax,ax
     7a9:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     7ac:	7f 3b                	jg     0x7e9
     7ae:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     7b1:	eb 03                	jmp    0x7b6
     7b3:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     7b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
     7b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7bc:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     7c0:	06                   	push   es
     7c1:	57                   	push   di
     7c2:	9a d0 0d f5 07       	call   0x7f5:0xdd0
     7c7:	52                   	push   dx
     7c8:	50                   	push   ax
     7c9:	bf 6b 00             	mov    di,0x6b
     7cc:	b8 2c 08             	mov    ax,0x82c
     7cf:	50                   	push   ax
     7d0:	57                   	push   di
     7d1:	9a 73 22 df 07       	call   0x7df:0x2273
     7d6:	89 c7                	mov    di,ax
     7d8:	8e c2                	mov    es,dx
     7da:	06                   	push   es
     7db:	57                   	push   di
     7dc:	9a 7f 1f 33 08       	call   0x833:0x1f7f
     7e1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     7e4:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     7e7:	75 ca                	jne    0x7b3
     7e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7ec:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     7f0:	06                   	push   es
     7f1:	57                   	push   di
     7f2:	9a 75 0c 24 08       	call   0x824:0xc75
     7f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7fa:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     7fe:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     802:	48                   	dec    ax
     803:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     806:	31 c0                	xor    ax,ax
     808:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     80b:	7f 3b                	jg     0x848
     80d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     810:	eb 03                	jmp    0x815
     812:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     815:	ff 76 fe             	push   WORD PTR [bp-0x2]
     818:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     81b:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     81f:	06                   	push   es
     820:	57                   	push   di
     821:	9a d0 0d 54 08       	call   0x854:0xdd0
     826:	52                   	push   dx
     827:	50                   	push   ax
     828:	bf c5 05             	mov    di,0x5c5
     82b:	b8 82 08             	mov    ax,0x882
     82e:	50                   	push   ax
     82f:	57                   	push   di
     830:	9a 73 22 3e 08       	call   0x83e:0x2273
     835:	89 c7                	mov    di,ax
     837:	8e c2                	mov    es,dx
     839:	06                   	push   es
     83a:	57                   	push   di
     83b:	9a 7f 1f 89 08       	call   0x889:0x1f7f
     840:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     843:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     846:	75 ca                	jne    0x812
     848:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     84b:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     84f:	06                   	push   es
     850:	57                   	push   di
     851:	9a 75 0c 7a 08       	call   0x87a:0xc75
     856:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     859:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     85d:	06                   	push   es
     85e:	57                   	push   di
     85f:	9a f9 36 3d 09       	call   0x93d:0x36f9
     864:	c9                   	leave
     865:	ca 04 00             	retf   0x4
     868:	55                   	push   bp
     869:	89 e5                	mov    bp,sp
     86b:	ff 76 0a             	push   WORD PTR [bp+0xa]
     86e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     871:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     875:	06                   	push   es
     876:	57                   	push   di
     877:	9a d0 0d a5 08       	call   0x8a5:0xdd0
     87c:	52                   	push   dx
     87d:	50                   	push   ax
     87e:	bf 6b 00             	mov    di,0x6b
     881:	b8 be 08             	mov    ax,0x8be
     884:	50                   	push   ax
     885:	57                   	push   di
     886:	9a 73 22 94 08       	call   0x894:0x2273
     88b:	89 c7                	mov    di,ax
     88d:	8e c2                	mov    es,dx
     88f:	06                   	push   es
     890:	57                   	push   di
     891:	9a 7f 1f c5 08       	call   0x8c5:0x1f7f
     896:	ff 76 0a             	push   WORD PTR [bp+0xa]
     899:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     89c:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     8a0:	06                   	push   es
     8a1:	57                   	push   di
     8a2:	9a 94 0c b6 08       	call   0x8b6:0xc94
     8a7:	ff 76 0a             	push   WORD PTR [bp+0xa]
     8aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8ad:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     8b1:	06                   	push   es
     8b2:	57                   	push   di
     8b3:	9a d0 0d e1 08       	call   0x8e1:0xdd0
     8b8:	52                   	push   dx
     8b9:	50                   	push   ax
     8ba:	bf c5 05             	mov    di,0x5c5
     8bd:	b8 10 09             	mov    ax,0x910
     8c0:	50                   	push   ax
     8c1:	57                   	push   di
     8c2:	9a 73 22 d0 08       	call   0x8d0:0x2273
     8c7:	89 c7                	mov    di,ax
     8c9:	8e c2                	mov    es,dx
     8cb:	06                   	push   es
     8cc:	57                   	push   di
     8cd:	9a 7f 1f 36 0b       	call   0xb36:0x1f7f
     8d2:	ff 76 0a             	push   WORD PTR [bp+0xa]
     8d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8d8:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     8dc:	06                   	push   es
     8dd:	57                   	push   di
     8de:	9a 94 0c bc 09       	call   0x9bc:0xc94
     8e3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     8e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8e9:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     8ed:	26 3b 85 ee 00       	cmp    ax,WORD PTR es:[di+0xee]
     8f2:	75 20                	jne    0x914
     8f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8f7:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     8fb:	26 c7 85 ee 00 ff ff 	mov    WORD PTR es:[di+0xee],0xffff
     902:	6a 00                	push   0x0
     904:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     907:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     90b:	06                   	push   es
     90c:	57                   	push   di
     90d:	9a 6f 24 69 09       	call   0x969:0x246f
     912:	eb 1d                	jmp    0x931
     914:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     917:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     91a:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     91e:	26 3b 85 ee 00       	cmp    ax,WORD PTR es:[di+0xee]
     923:	7d 0c                	jge    0x931
     925:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     928:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     92c:	26 ff 8d ee 00       	dec    WORD PTR es:[di+0xee]
     931:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     934:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     938:	06                   	push   es
     939:	57                   	push   di
     93a:	9a f9 36 a5 09       	call   0x9a5:0x36f9
     93f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     942:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     946:	06                   	push   es
     947:	57                   	push   di
     948:	26 c4 3d             	les    di,DWORD PTR es:[di]
     94b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
     94f:	c9                   	leave
     950:	ca 06 00             	retf   0x6
     953:	c8 0c 00 00          	enter  0xc,0x0
     957:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     95a:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     95e:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
     962:	b0 01                	mov    al,0x1
     964:	50                   	push   ax
     965:	b8 6b 00             	mov    ax,0x6b
     968:	ba 70 09             	mov    dx,0x970
     96b:	52                   	push   dx
     96c:	50                   	push   ax
     96d:	9a db 1b da 09       	call   0x9da:0x1bdb
     972:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     975:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     978:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     97b:	89 7e f4             	mov    WORD PTR [bp-0xc],di
     97e:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
     981:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     984:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     988:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
     98c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     98f:	06                   	push   es
     990:	57                   	push   di
     991:	26 c4 3d             	les    di,DWORD PTR es:[di]
     994:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
     998:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     99b:	06                   	push   es
     99c:	57                   	push   di
     99d:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     9a0:	06                   	push   es
     9a1:	57                   	push   di
     9a2:	9a 8c 1d 16 0a       	call   0xa16:0x1d8c
     9a7:	ff 76 0e             	push   WORD PTR [bp+0xe]
     9aa:	ff 76 fe             	push   WORD PTR [bp-0x2]
     9ad:	ff 76 fc             	push   WORD PTR [bp-0x4]
     9b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9b3:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     9b7:	06                   	push   es
     9b8:	57                   	push   di
     9b9:	9a a7 0e 2d 0a       	call   0xa2d:0xea7
     9be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9c1:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     9c5:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
     9c9:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
     9cd:	b0 00                	mov    al,0x0
     9cf:	75 01                	jne    0x9d2
     9d1:	40                   	inc    ax
     9d2:	50                   	push   ax
     9d3:	b0 01                	mov    al,0x1
     9d5:	50                   	push   ax
     9d6:	b8 c5 05             	mov    ax,0x5c5
     9d9:	ba e1 09             	mov    dx,0x9e1
     9dc:	52                   	push   dx
     9dd:	50                   	push   ax
     9de:	9a 27 0b 3e 0a       	call   0xa3e:0xb27
     9e3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     9e6:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     9e9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     9ec:	89 7e f4             	mov    WORD PTR [bp-0xc],di
     9ef:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
     9f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9f5:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
     9f9:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
     9fd:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     a00:	06                   	push   es
     a01:	57                   	push   di
     a02:	26 c4 3d             	les    di,DWORD PTR es:[di]
     a05:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
     a09:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     a0c:	06                   	push   es
     a0d:	57                   	push   di
     a0e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     a11:	06                   	push   es
     a12:	57                   	push   di
     a13:	9a 8c 1d 4c 0a       	call   0xa4c:0x1d8c
     a18:	ff 76 0e             	push   WORD PTR [bp+0xe]
     a1b:	ff 76 fa             	push   WORD PTR [bp-0x6]
     a1e:	ff 76 f8             	push   WORD PTR [bp-0x8]
     a21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a24:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     a28:	06                   	push   es
     a29:	57                   	push   di
     a2a:	9a a7 0e 80 0a       	call   0xa80:0xea7
     a2f:	ff 76 0e             	push   WORD PTR [bp+0xe]
     a32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a35:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     a39:	06                   	push   es
     a3a:	57                   	push   di
     a3b:	9a 6f 24 99 0c       	call   0xc99:0x246f
     a40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a43:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     a47:	06                   	push   es
     a48:	57                   	push   di
     a49:	9a f9 36 21 0b       	call   0xb21:0x36f9
     a4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a51:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     a55:	06                   	push   es
     a56:	57                   	push   di
     a57:	26 c4 3d             	les    di,DWORD PTR es:[di]
     a5a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
     a5e:	c9                   	leave
     a5f:	ca 0a 00             	retf   0xa
     a62:	c8 04 00 00          	enter  0x4,0x0
     a66:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     a69:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
     a6c:	75 03                	jne    0xa71
     a6e:	e9 b2 00             	jmp    0xb23
     a71:	ff 76 0c             	push   WORD PTR [bp+0xc]
     a74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a77:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     a7b:	06                   	push   es
     a7c:	57                   	push   di
     a7d:	9a d0 0d 9a 0a       	call   0xa9a:0xdd0
     a82:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     a85:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     a88:	ff 76 0c             	push   WORD PTR [bp+0xc]
     a8b:	ff 76 0a             	push   WORD PTR [bp+0xa]
     a8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a91:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     a95:	06                   	push   es
     a96:	57                   	push   di
     a97:	9a d0 0d aa 0a       	call   0xaaa:0xdd0
     a9c:	52                   	push   dx
     a9d:	50                   	push   ax
     a9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aa1:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     aa5:	06                   	push   es
     aa6:	57                   	push   di
     aa7:	9a 67 0f c1 0a       	call   0xac1:0xf67
     aac:	ff 76 0a             	push   WORD PTR [bp+0xa]
     aaf:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ab2:	ff 76 fc             	push   WORD PTR [bp-0x4]
     ab5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ab8:	26 c4 7d 0a          	les    di,DWORD PTR es:[di+0xa]
     abc:	06                   	push   es
     abd:	57                   	push   di
     abe:	9a 67 0f d2 0a       	call   0xad2:0xf67
     ac3:	ff 76 0c             	push   WORD PTR [bp+0xc]
     ac6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ac9:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     acd:	06                   	push   es
     ace:	57                   	push   di
     acf:	9a d0 0d ec 0a       	call   0xaec:0xdd0
     ad4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ad7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     ada:	ff 76 0c             	push   WORD PTR [bp+0xc]
     add:	ff 76 0a             	push   WORD PTR [bp+0xa]
     ae0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ae3:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     ae7:	06                   	push   es
     ae8:	57                   	push   di
     ae9:	9a d0 0d fc 0a       	call   0xafc:0xdd0
     aee:	52                   	push   dx
     aef:	50                   	push   ax
     af0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     af3:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     af7:	06                   	push   es
     af8:	57                   	push   di
     af9:	9a 67 0f 13 0b       	call   0xb13:0xf67
     afe:	ff 76 0a             	push   WORD PTR [bp+0xa]
     b01:	ff 76 fe             	push   WORD PTR [bp-0x2]
     b04:	ff 76 fc             	push   WORD PTR [bp-0x4]
     b07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b0a:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
     b0e:	06                   	push   es
     b0f:	57                   	push   di
     b10:	9a 67 0f 82 16       	call   0x1682:0xf67
     b15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b18:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
     b1c:	06                   	push   es
     b1d:	57                   	push   di
     b1e:	9a f9 36 49 0b       	call   0xb49:0x36f9
     b23:	c9                   	leave
     b24:	ca 08 00             	retf   0x8
     b27:	55                   	push   bp
     b28:	89 e5                	mov    bp,sp
     b2a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     b2e:	74 08                	je     0xb38
     b30:	83 ec 08             	sub    sp,0x8
     b33:	9a e2 1f 80 0c       	call   0xc80:0x1fe2
     b38:	ff 76 10             	push   WORD PTR [bp+0x10]
     b3b:	ff 76 0e             	push   WORD PTR [bp+0xe]
     b3e:	31 c0                	xor    ax,ax
     b40:	50                   	push   ax
     b41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b44:	06                   	push   es
     b45:	57                   	push   di
     b46:	9a 86 68 55 0b       	call   0xb55:0x6886
     b4b:	6a 59                	push   0x59
     b4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b50:	06                   	push   es
     b51:	57                   	push   di
     b52:	9a bf 17 61 0b       	call   0xb61:0x17bf
     b57:	6a 17                	push   0x17
     b59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b5c:	06                   	push   es
     b5d:	57                   	push   di
     b5e:	9a e1 17 73 0b       	call   0xb73:0x17e1
     b63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b66:	26 c7 45 26 a0 00    	mov    WORD PTR es:[di+0x26],0xa0
     b6c:	6a 00                	push   0x0
     b6e:	06                   	push   es
     b6f:	57                   	push   di
     b70:	9a 3e 1e e5 0b       	call   0xbe5:0x1e3e
     b75:	8a 46 0c             	mov    al,BYTE PTR [bp+0xc]
     b78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b7b:	26 88 85 8f 00       	mov    BYTE PTR es:[di+0x8f],al
     b80:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     b84:	74 07                	je     0xb8d
     b86:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     b8a:	83 c4 06             	add    sp,0x6
     b8d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     b90:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     b93:	c9                   	leave
     b94:	ca 0c 00             	retf   0xc
     b97:	c8 04 00 00          	enter  0x4,0x0
     b9b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     b9e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     ba2:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
     ba6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ba9:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     bac:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     baf:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
     bb2:	74 33                	je     0xbe7
     bb4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     bb7:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     bba:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
     bbd:	75 05                	jne    0xbc4
     bbf:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
     bc2:	74 23                	je     0xbe7
     bc4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     bc7:	26 80 bd 8e 00 00    	cmp    BYTE PTR es:[di+0x8e],0x0
     bcd:	74 18                	je     0xbe7
     bcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bd2:	26 80 bd 8e 00 00    	cmp    BYTE PTR es:[di+0x8e],0x0
     bd8:	74 0d                	je     0xbe7
     bda:	26 c6 85 8e 00 00    	mov    BYTE PTR es:[di+0x8e],0x0
     be0:	06                   	push   es
     be1:	57                   	push   di
     be2:	9a c6 22 09 0c       	call   0xc09:0x22c6
     be7:	c9                   	leave
     be8:	ca 08 00             	retf   0x8
     beb:	c8 0c 00 00          	enter  0xc,0x0
     bef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bf2:	26 8a 85 8e 00       	mov    al,BYTE PTR es:[di+0x8e]
     bf7:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
     bfa:	74 4d                	je     0xc49
     bfc:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
     bff:	26 88 85 8e 00       	mov    BYTE PTR es:[di+0x8e],al
     c04:	06                   	push   es
     c05:	57                   	push   di
     c06:	9a c6 22 47 0c       	call   0xc47:0x22c6
     c0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c0e:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
     c12:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
     c16:	74 31                	je     0xc49
     c18:	c7 46 f4 18 0f       	mov    WORD PTR [bp-0xc],0xf18
     c1d:	31 c0                	xor    ax,ax
     c1f:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     c22:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     c25:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     c28:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     c2b:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     c2e:	31 c0                	xor    ax,ax
     c30:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c33:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     c36:	8d 7e f4             	lea    di,[bp-0xc]
     c39:	16                   	push   ss
     c3a:	57                   	push   di
     c3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c3e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     c42:	06                   	push   es
     c43:	57                   	push   di
     c44:	9a 43 3a 66 0c       	call   0xc66:0x3a43
     c49:	c9                   	leave
     c4a:	ca 06 00             	retf   0x6
     c4d:	55                   	push   bp
     c4e:	89 e5                	mov    bp,sp
     c50:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
     c53:	50                   	push   ax
     c54:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
     c57:	50                   	push   ax
     c58:	ff 76 0c             	push   WORD PTR [bp+0xc]
     c5b:	ff 76 0a             	push   WORD PTR [bp+0xa]
     c5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c61:	06                   	push   es
     c62:	57                   	push   di
     c63:	9a c0 27 bc 0c       	call   0xcbc:0x27c0
     c68:	80 7e 10 00          	cmp    BYTE PTR [bp+0x10],0x0
     c6c:	75 14                	jne    0xc82
     c6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c71:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
     c76:	74 0a                	je     0xc82
     c78:	06                   	push   es
     c79:	57                   	push   di
     c7a:	b8 fe ff             	mov    ax,0xfffe
     c7d:	9a 6a 20 a0 0c       	call   0xca0:0x206a
     c82:	c9                   	leave
     c83:	ca 0c 00             	retf   0xc
     c86:	c8 04 01 00          	enter  0x104,0x0
     c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c8d:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
     c91:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
     c95:	bf ed 01             	mov    di,0x1ed
     c98:	b8 dc 0c             	mov    ax,0xcdc
     c9b:	50                   	push   ax
     c9c:	57                   	push   di
     c9d:	9a 73 22 f3 0c       	call   0xcf3:0x2273
     ca2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ca5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     ca8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     cab:	06                   	push   es
     cac:	57                   	push   di
     cad:	26 c4 3d             	les    di,DWORD PTR es:[di]
     cb0:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
     cb4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     cb7:	06                   	push   es
     cb8:	57                   	push   di
     cb9:	9a 58 62 d2 0c       	call   0xcd2:0x6258
     cbe:	08 c0                	or     al,al
     cc0:	75 02                	jne    0xcc4
     cc2:	eb 31                	jmp    0xcf5
     cc4:	8d be fc fe          	lea    di,[bp-0x104]
     cc8:	16                   	push   ss
     cc9:	57                   	push   di
     cca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ccd:	06                   	push   es
     cce:	57                   	push   di
     ccf:	9a 53 1d e6 0c       	call   0xce6:0x1d53
     cd4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     cd7:	06                   	push   es
     cd8:	57                   	push   di
     cd9:	9a a3 26 34 0d       	call   0xd34:0x26a3
     cde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ce1:	06                   	push   es
     ce2:	57                   	push   di
     ce3:	9a 73 27 05 0d       	call   0xd05:0x2773
     ce8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     ceb:	06                   	push   es
     cec:	57                   	push   di
     ced:	b8 ee ff             	mov    ax,0xffee
     cf0:	9a 6a 20 e4 0d       	call   0xde4:0x206a
     cf5:	c9                   	leave
     cf6:	ca 04 00             	retf   0x4
     cf9:	c8 04 01 00          	enter  0x104,0x0
     cfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d00:	06                   	push   es
     d01:	57                   	push   di
     d02:	9a 80 69 26 0d       	call   0xd26:0x6980
     d07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d0a:	26 80 bd 8e 00 00    	cmp    BYTE PTR es:[di+0x8e],0x0
     d10:	74 06                	je     0xd18
     d12:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     d16:	eb 5a                	jmp    0xd72
     d18:	8d be fc fe          	lea    di,[bp-0x104]
     d1c:	16                   	push   ss
     d1d:	57                   	push   di
     d1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d21:	06                   	push   es
     d22:	57                   	push   di
     d23:	9a 53 1d 01 0e       	call   0xe01:0x1d53
     d28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d2b:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     d2f:	06                   	push   es
     d30:	57                   	push   di
     d31:	9a 98 2e 7e 0d       	call   0xd7e:0x2e98
     d36:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d3c:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     d40:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
     d45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d48:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     d4c:	99                   	cwd
     d4d:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
     d52:	8b c8                	mov    cx,ax
     d54:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     d57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d5a:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
     d5e:	99                   	cwd
     d5f:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
     d64:	3b c1                	cmp    ax,cx
     d66:	75 06                	jne    0xd6e
     d68:	c6 46 ff 02          	mov    BYTE PTR [bp-0x1],0x2
     d6c:	eb 04                	jmp    0xd72
     d6e:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     d72:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     d75:	50                   	push   ax
     d76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d79:	06                   	push   es
     d7a:	57                   	push   di
     d7b:	9a eb 16 94 0d       	call   0xd94:0x16eb
     d80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d83:	26 80 bd 8e 00 00    	cmp    BYTE PTR es:[di+0x8e],0x0
     d89:	74 0d                	je     0xd98
     d8b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     d8e:	50                   	push   ax
     d8f:	06                   	push   es
     d90:	57                   	push   di
     d91:	9a c0 0d a4 0d       	call   0xda4:0xdc0
     d96:	eb 0e                	jmp    0xda6
     d98:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     d9b:	50                   	push   ax
     d9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d9f:	06                   	push   es
     da0:	57                   	push   di
     da1:	9a f8 10 ba 0d       	call   0xdba:0x10f8
     da6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     da9:	26 80 bd 90 00 00    	cmp    BYTE PTR es:[di+0x90],0x0
     daf:	74 0b                	je     0xdbc
     db1:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     db4:	50                   	push   ax
     db5:	06                   	push   es
     db6:	57                   	push   di
     db7:	9a a2 13 12 0e       	call   0xe12:0x13a2
     dbc:	c9                   	leave
     dbd:	ca 04 00             	retf   0x4
     dc0:	c8 0a 01 00          	enter  0x10a,0x0
     dc4:	31 c0                	xor    ax,ax
     dc6:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     dc9:	8d 7e ee             	lea    di,[bp-0x12]
     dcc:	16                   	push   ss
     dcd:	57                   	push   di
     dce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dd1:	06                   	push   es
     dd2:	57                   	push   di
     dd3:	26 c4 3d             	les    di,DWORD PTR es:[di]
     dd6:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
     dda:	8d 7e f8             	lea    di,[bp-0x8]
     ddd:	16                   	push   ss
     dde:	57                   	push   di
     ddf:	6a 08                	push   0x8
     de1:	9a 1b 16 19 0e       	call   0xe19:0x161b
     de6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     de9:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
     ded:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
     df1:	74 36                	je     0xe29
     df3:	8d be f6 fe          	lea    di,[bp-0x10a]
     df7:	16                   	push   ss
     df8:	57                   	push   di
     df9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dfc:	06                   	push   es
     dfd:	57                   	push   di
     dfe:	9a 53 1d 39 11       	call   0x1139:0x1d53
     e03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e06:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
     e0a:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
     e0e:	bf ed 01             	mov    di,0x1ed
     e11:	b8 24 0e             	mov    ax,0xe24
     e14:	50                   	push   ax
     e15:	57                   	push   di
     e16:	9a 73 22 3f 0e       	call   0xe3f:0x2273
     e1b:	89 c7                	mov    di,ax
     e1d:	8e c2                	mov    es,dx
     e1f:	06                   	push   es
     e20:	57                   	push   di
     e21:	9a 98 2e 38 0e       	call   0xe38:0x2e98
     e26:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     e29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e2c:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
     e30:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
     e34:	bf ed 01             	mov    di,0x1ed
     e37:	b8 59 0e             	mov    ax,0xe59
     e3a:	50                   	push   ax
     e3b:	57                   	push   di
     e3c:	9a 73 22 60 0e       	call   0xe60:0x2273
     e41:	89 c7                	mov    di,ax
     e43:	8e c2                	mov    es,dx
     e45:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
     e4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e4d:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
     e51:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
     e55:	bf ed 01             	mov    di,0x1ed
     e58:	b8 7f 0e             	mov    ax,0xe7f
     e5b:	50                   	push   ax
     e5c:	57                   	push   di
     e5d:	9a 73 22 86 0e       	call   0xe86:0x2273
     e62:	89 c7                	mov    di,ax
     e64:	8e c2                	mov    es,dx
     e66:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
     e6b:	59                   	pop    cx
     e6c:	99                   	cwd
     e6d:	f7 f9                	idiv   cx
     e6f:	50                   	push   ax
     e70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e73:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
     e77:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
     e7b:	bf ed 01             	mov    di,0x1ed
     e7e:	b8 10 10             	mov    ax,0x1010
     e81:	50                   	push   ax
     e82:	57                   	push   di
     e83:	9a 73 22 17 10       	call   0x1017:0x2273
     e88:	89 c7                	mov    di,ax
     e8a:	8e c2                	mov    es,dx
     e8c:	26 8b 8d f8 00       	mov    cx,WORD PTR es:[di+0xf8]
     e91:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     e94:	99                   	cwd
     e95:	f7 f9                	idiv   cx
     e97:	5a                   	pop    dx
     e98:	3b c2                	cmp    ax,dx
     e9a:	74 03                	je     0xe9f
     e9c:	e9 3f 02             	jmp    0x10de
     e9f:	ff 4e fc             	dec    WORD PTR [bp-0x4]
     ea2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ea5:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
     eaa:	89 7e f2             	mov    WORD PTR [bp-0xe],di
     ead:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
     eb0:	6a ff                	push   0xffff
     eb2:	6a eb                	push   0xffeb
     eb4:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
     eb8:	06                   	push   es
     eb9:	57                   	push   di
     eba:	9a da 13 d0 0e       	call   0xed0:0x13da
     ebf:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     ec2:	40                   	inc    ax
     ec3:	40                   	inc    ax
     ec4:	50                   	push   ax
     ec5:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ec8:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     ecb:	06                   	push   es
     ecc:	57                   	push   di
     ecd:	9a b8 1d e7 0e       	call   0xee7:0x1db8
     ed2:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     ed5:	40                   	inc    ax
     ed6:	40                   	inc    ax
     ed7:	50                   	push   ax
     ed8:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     edb:	05 04 00             	add    ax,0x4
     ede:	50                   	push   ax
     edf:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     ee2:	06                   	push   es
     ee3:	57                   	push   di
     ee4:	9a 7b 1d fe 0e       	call   0xefe:0x1d7b
     ee9:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     eec:	05 04 00             	add    ax,0x4
     eef:	50                   	push   ax
     ef0:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     ef3:	40                   	inc    ax
     ef4:	40                   	inc    ax
     ef5:	50                   	push   ax
     ef6:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     ef9:	06                   	push   es
     efa:	57                   	push   di
     efb:	9a 7b 1d 15 0f       	call   0xf15:0x1d7b
     f00:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     f03:	2d 04 00             	sub    ax,0x4
     f06:	50                   	push   ax
     f07:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     f0a:	40                   	inc    ax
     f0b:	40                   	inc    ax
     f0c:	50                   	push   ax
     f0d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     f10:	06                   	push   es
     f11:	57                   	push   di
     f12:	9a 7b 1d 28 0f       	call   0xf28:0x1d7b
     f17:	ff 76 fc             	push   WORD PTR [bp-0x4]
     f1a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f1d:	48                   	dec    ax
     f1e:	48                   	dec    ax
     f1f:	50                   	push   ax
     f20:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     f23:	06                   	push   es
     f24:	57                   	push   di
     f25:	9a b8 1d 3a 0f       	call   0xf3a:0x1db8
     f2a:	ff 76 fc             	push   WORD PTR [bp-0x4]
     f2d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f30:	48                   	dec    ax
     f31:	50                   	push   ax
     f32:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     f35:	06                   	push   es
     f36:	57                   	push   di
     f37:	9a 7b 1d 4f 0f       	call   0xf4f:0x1d7b
     f3c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     f3f:	48                   	dec    ax
     f40:	48                   	dec    ax
     f41:	50                   	push   ax
     f42:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f45:	48                   	dec    ax
     f46:	50                   	push   ax
     f47:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     f4a:	06                   	push   es
     f4b:	57                   	push   di
     f4c:	9a 7b 1d 62 0f       	call   0xf62:0x1d7b
     f51:	ff 76 f8             	push   WORD PTR [bp-0x8]
     f54:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f57:	48                   	dec    ax
     f58:	48                   	dec    ax
     f59:	50                   	push   ax
     f5a:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     f5d:	06                   	push   es
     f5e:	57                   	push   di
     f5f:	9a b8 1d 72 0f       	call   0xf72:0x1db8
     f64:	ff 76 f8             	push   WORD PTR [bp-0x8]
     f67:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f6a:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     f6d:	06                   	push   es
     f6e:	57                   	push   di
     f6f:	9a 7b 1d 84 0f       	call   0xf84:0x1d7b
     f74:	6a ff                	push   0xffff
     f76:	6a ef                	push   0xffef
     f78:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     f7b:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
     f7f:	06                   	push   es
     f80:	57                   	push   di
     f81:	9a da 13 9b 0f       	call   0xf9b:0x13da
     f86:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     f89:	2d 04 00             	sub    ax,0x4
     f8c:	50                   	push   ax
     f8d:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     f90:	40                   	inc    ax
     f91:	40                   	inc    ax
     f92:	50                   	push   ax
     f93:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     f96:	06                   	push   es
     f97:	57                   	push   di
     f98:	9a b8 1d b2 0f       	call   0xfb2:0x1db8
     f9d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     fa0:	48                   	dec    ax
     fa1:	48                   	dec    ax
     fa2:	50                   	push   ax
     fa3:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     fa6:	05 04 00             	add    ax,0x4
     fa9:	50                   	push   ax
     faa:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     fad:	06                   	push   es
     fae:	57                   	push   di
     faf:	9a 7b 1d c5 0f       	call   0xfc5:0x1d7b
     fb4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     fb7:	48                   	dec    ax
     fb8:	48                   	dec    ax
     fb9:	50                   	push   ax
     fba:	ff 76 fe             	push   WORD PTR [bp-0x2]
     fbd:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     fc0:	06                   	push   es
     fc1:	57                   	push   di
     fc2:	9a 7b 1d d7 0f       	call   0xfd7:0x1d7b
     fc7:	6a 00                	push   0x0
     fc9:	6a 00                	push   0x0
     fcb:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     fce:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
     fd2:	06                   	push   es
     fd3:	57                   	push   di
     fd4:	9a da 13 eb 0f       	call   0xfeb:0x13da
     fd9:	ff 76 fc             	push   WORD PTR [bp-0x4]
     fdc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     fdf:	2d 03 00             	sub    ax,0x3
     fe2:	50                   	push   ax
     fe3:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     fe6:	06                   	push   es
     fe7:	57                   	push   di
     fe8:	9a b8 1d ff 0f       	call   0xfff:0x1db8
     fed:	ff 76 fc             	push   WORD PTR [bp-0x4]
     ff0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     ff3:	2d 04 00             	sub    ax,0x4
     ff6:	50                   	push   ax
     ff7:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
     ffa:	06                   	push   es
     ffb:	57                   	push   di
     ffc:	9a 7b 1d 3e 10       	call   0x103e:0x1d7b
    1001:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1004:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1008:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    100c:	bf ed 01             	mov    di,0x1ed
    100f:	b8 62 10             	mov    ax,0x1062
    1012:	50                   	push   ax
    1013:	57                   	push   di
    1014:	9a 73 22 69 10       	call   0x1069:0x2273
    1019:	89 c7                	mov    di,ax
    101b:	8e c2                	mov    es,dx
    101d:	26 8b 8d f8 00       	mov    cx,WORD PTR es:[di+0xf8]
    1022:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1025:	99                   	cwd
    1026:	f7 f9                	idiv   cx
    1028:	92                   	xchg   dx,ax
    1029:	09 c0                	or     ax,ax
    102b:	75 26                	jne    0x1053
    102d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1030:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1033:	48                   	dec    ax
    1034:	48                   	dec    ax
    1035:	50                   	push   ax
    1036:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1039:	06                   	push   es
    103a:	57                   	push   di
    103b:	9a b8 1d 4e 10       	call   0x104e:0x1db8
    1040:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1043:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1046:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1049:	06                   	push   es
    104a:	57                   	push   di
    104b:	9a 7b 1d 92 10       	call   0x1092:0x1d7b
    1050:	e9 8b 00             	jmp    0x10de
    1053:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1056:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    105a:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    105e:	bf ed 01             	mov    di,0x1ed
    1061:	b8 f2 10             	mov    ax,0x10f2
    1064:	50                   	push   ax
    1065:	57                   	push   di
    1066:	9a 73 22 1c 11       	call   0x111c:0x2273
    106b:	89 c7                	mov    di,ax
    106d:	8e c2                	mov    es,dx
    106f:	26 8b 8d f8 00       	mov    cx,WORD PTR es:[di+0xf8]
    1074:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1077:	40                   	inc    ax
    1078:	99                   	cwd
    1079:	f7 f9                	idiv   cx
    107b:	92                   	xchg   dx,ax
    107c:	09 c0                	or     ax,ax
    107e:	75 5e                	jne    0x10de
    1080:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1083:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1086:	2d 03 00             	sub    ax,0x3
    1089:	50                   	push   ax
    108a:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    108d:	06                   	push   es
    108e:	57                   	push   di
    108f:	9a b8 1d a2 10       	call   0x10a2:0x1db8
    1094:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1097:	ff 76 fe             	push   WORD PTR [bp-0x2]
    109a:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    109d:	06                   	push   es
    109e:	57                   	push   di
    109f:	9a 7b 1d b4 10       	call   0x10b4:0x1d7b
    10a4:	6a ff                	push   0xffff
    10a6:	6a ef                	push   0xffef
    10a8:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    10ab:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    10af:	06                   	push   es
    10b0:	57                   	push   di
    10b1:	9a da 13 ca 10       	call   0x10ca:0x13da
    10b6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    10b9:	48                   	dec    ax
    10ba:	50                   	push   ax
    10bb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    10be:	2d 03 00             	sub    ax,0x3
    10c1:	50                   	push   ax
    10c2:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    10c5:	06                   	push   es
    10c6:	57                   	push   di
    10c7:	9a b8 1d dc 10       	call   0x10dc:0x1db8
    10cc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    10cf:	48                   	dec    ax
    10d0:	50                   	push   ax
    10d1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    10d4:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    10d7:	06                   	push   es
    10d8:	57                   	push   di
    10d9:	9a 7b 1d f5 11       	call   0x11f5:0x1d7b
    10de:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    10e1:	8d 7e f8             	lea    di,[bp-0x8]
    10e4:	16                   	push   ss
    10e5:	57                   	push   di
    10e6:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    10e9:	50                   	push   ax
    10ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10ed:	06                   	push   es
    10ee:	57                   	push   di
    10ef:	9a 05 15 4a 11       	call   0x114a:0x1505
    10f4:	c9                   	leave
    10f5:	ca 06 00             	retf   0x6
    10f8:	c8 0a 01 00          	enter  0x10a,0x0
    10fc:	31 c0                	xor    ax,ax
    10fe:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1101:	8d 7e ee             	lea    di,[bp-0x12]
    1104:	16                   	push   ss
    1105:	57                   	push   di
    1106:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1109:	06                   	push   es
    110a:	57                   	push   di
    110b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    110e:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1112:	8d 7e f8             	lea    di,[bp-0x8]
    1115:	16                   	push   ss
    1116:	57                   	push   di
    1117:	6a 08                	push   0x8
    1119:	9a 1b 16 51 11       	call   0x1151:0x161b
    111e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1121:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    1125:	26 0b 45 1c          	or     ax,WORD PTR es:[di+0x1c]
    1129:	74 36                	je     0x1161
    112b:	8d be f6 fe          	lea    di,[bp-0x10a]
    112f:	16                   	push   ss
    1130:	57                   	push   di
    1131:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1134:	06                   	push   es
    1135:	57                   	push   di
    1136:	9a 53 1d 73 14       	call   0x1473:0x1d53
    113b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    113e:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1142:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1146:	bf ed 01             	mov    di,0x1ed
    1149:	b8 5c 11             	mov    ax,0x115c
    114c:	50                   	push   ax
    114d:	57                   	push   di
    114e:	9a 73 22 77 11       	call   0x1177:0x2273
    1153:	89 c7                	mov    di,ax
    1155:	8e c2                	mov    es,dx
    1157:	06                   	push   es
    1158:	57                   	push   di
    1159:	9a 98 2e 70 11       	call   0x1170:0x2e98
    115e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1161:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1164:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1168:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    116c:	bf ed 01             	mov    di,0x1ed
    116f:	b8 91 11             	mov    ax,0x1191
    1172:	50                   	push   ax
    1173:	57                   	push   di
    1174:	9a 73 22 98 11       	call   0x1198:0x2273
    1179:	89 c7                	mov    di,ax
    117b:	8e c2                	mov    es,dx
    117d:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1182:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1185:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1189:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    118d:	bf ed 01             	mov    di,0x1ed
    1190:	b8 b7 11             	mov    ax,0x11b7
    1193:	50                   	push   ax
    1194:	57                   	push   di
    1195:	9a 73 22 be 11       	call   0x11be:0x2273
    119a:	89 c7                	mov    di,ax
    119c:	8e c2                	mov    es,dx
    119e:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    11a3:	59                   	pop    cx
    11a4:	99                   	cwd
    11a5:	f7 f9                	idiv   cx
    11a7:	50                   	push   ax
    11a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11ab:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    11af:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    11b3:	bf ed 01             	mov    di,0x1ed
    11b6:	b8 a2 12             	mov    ax,0x12a2
    11b9:	50                   	push   ax
    11ba:	57                   	push   di
    11bb:	9a 73 22 a9 12       	call   0x12a9:0x2273
    11c0:	89 c7                	mov    di,ax
    11c2:	8e c2                	mov    es,dx
    11c4:	26 8b 8d f8 00       	mov    cx,WORD PTR es:[di+0xf8]
    11c9:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    11cc:	99                   	cwd
    11cd:	f7 f9                	idiv   cx
    11cf:	5a                   	pop    dx
    11d0:	3b c2                	cmp    ax,dx
    11d2:	74 03                	je     0x11d7
    11d4:	e9 b1 01             	jmp    0x1388
    11d7:	ff 4e fc             	dec    WORD PTR [bp-0x4]
    11da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11dd:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    11e2:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    11e5:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    11e8:	6a 00                	push   0x0
    11ea:	6a 00                	push   0x0
    11ec:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    11f0:	06                   	push   es
    11f1:	57                   	push   di
    11f2:	9a da 13 09 12       	call   0x1209:0x13da
    11f7:	ff 76 f8             	push   WORD PTR [bp-0x8]
    11fa:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    11fd:	2d 03 00             	sub    ax,0x3
    1200:	50                   	push   ax
    1201:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1204:	06                   	push   es
    1205:	57                   	push   di
    1206:	9a b8 1d 1f 12       	call   0x121f:0x1db8
    120b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    120e:	40                   	inc    ax
    120f:	50                   	push   ax
    1210:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1213:	2d 03 00             	sub    ax,0x3
    1216:	50                   	push   ax
    1217:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    121a:	06                   	push   es
    121b:	57                   	push   di
    121c:	9a 7b 1d 31 12       	call   0x1231:0x1d7b
    1221:	6a ff                	push   0xffff
    1223:	6a eb                	push   0xffeb
    1225:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1228:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    122c:	06                   	push   es
    122d:	57                   	push   di
    122e:	9a da 13 44 12       	call   0x1244:0x13da
    1233:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1236:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1239:	48                   	dec    ax
    123a:	48                   	dec    ax
    123b:	50                   	push   ax
    123c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    123f:	06                   	push   es
    1240:	57                   	push   di
    1241:	9a b8 1d 59 12       	call   0x1259:0x1db8
    1246:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1249:	40                   	inc    ax
    124a:	50                   	push   ax
    124b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    124e:	48                   	dec    ax
    124f:	48                   	dec    ax
    1250:	50                   	push   ax
    1251:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1254:	06                   	push   es
    1255:	57                   	push   di
    1256:	9a 7b 1d 6b 12       	call   0x126b:0x1d7b
    125b:	ff 76 f8             	push   WORD PTR [bp-0x8]
    125e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1261:	48                   	dec    ax
    1262:	50                   	push   ax
    1263:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1266:	06                   	push   es
    1267:	57                   	push   di
    1268:	9a b8 1d 7f 12       	call   0x127f:0x1db8
    126d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1270:	40                   	inc    ax
    1271:	50                   	push   ax
    1272:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1275:	48                   	dec    ax
    1276:	50                   	push   ax
    1277:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    127a:	06                   	push   es
    127b:	57                   	push   di
    127c:	9a 7b 1d 91 12       	call   0x1291:0x1d7b
    1281:	6a 00                	push   0x0
    1283:	6a 00                	push   0x0
    1285:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1288:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    128c:	06                   	push   es
    128d:	57                   	push   di
    128e:	9a da 13 d1 12       	call   0x12d1:0x13da
    1293:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1296:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    129a:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    129e:	bf ed 01             	mov    di,0x1ed
    12a1:	b8 f5 12             	mov    ax,0x12f5
    12a4:	50                   	push   ax
    12a5:	57                   	push   di
    12a6:	9a 73 22 fc 12       	call   0x12fc:0x2273
    12ab:	89 c7                	mov    di,ax
    12ad:	8e c2                	mov    es,dx
    12af:	26 8b 8d f8 00       	mov    cx,WORD PTR es:[di+0xf8]
    12b4:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    12b7:	99                   	cwd
    12b8:	f7 f9                	idiv   cx
    12ba:	92                   	xchg   dx,ax
    12bb:	09 c0                	or     ax,ax
    12bd:	75 27                	jne    0x12e6
    12bf:	ff 76 f8             	push   WORD PTR [bp-0x8]
    12c2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    12c5:	2d 03 00             	sub    ax,0x3
    12c8:	50                   	push   ax
    12c9:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    12cc:	06                   	push   es
    12cd:	57                   	push   di
    12ce:	9a b8 1d e1 12       	call   0x12e1:0x1db8
    12d3:	ff 76 f8             	push   WORD PTR [bp-0x8]
    12d6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    12d9:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    12dc:	06                   	push   es
    12dd:	57                   	push   di
    12de:	9a 7b 1d 25 13       	call   0x1325:0x1d7b
    12e3:	e9 a2 00             	jmp    0x1388
    12e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12e9:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    12ed:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    12f1:	bf ed 01             	mov    di,0x1ed
    12f4:	b8 9c 13             	mov    ax,0x139c
    12f7:	50                   	push   ax
    12f8:	57                   	push   di
    12f9:	9a 73 22 c4 13       	call   0x13c4:0x2273
    12fe:	89 c7                	mov    di,ax
    1300:	8e c2                	mov    es,dx
    1302:	26 8b 8d f8 00       	mov    cx,WORD PTR es:[di+0xf8]
    1307:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    130a:	40                   	inc    ax
    130b:	99                   	cwd
    130c:	f7 f9                	idiv   cx
    130e:	92                   	xchg   dx,ax
    130f:	09 c0                	or     ax,ax
    1311:	75 75                	jne    0x1388
    1313:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1316:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1319:	2d 03 00             	sub    ax,0x3
    131c:	50                   	push   ax
    131d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1320:	06                   	push   es
    1321:	57                   	push   di
    1322:	9a b8 1d 35 13       	call   0x1335:0x1db8
    1327:	ff 76 fc             	push   WORD PTR [bp-0x4]
    132a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    132d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1330:	06                   	push   es
    1331:	57                   	push   di
    1332:	9a 7b 1d 47 13       	call   0x1347:0x1d7b
    1337:	6a ff                	push   0xffff
    1339:	6a ef                	push   0xffef
    133b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    133e:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1342:	06                   	push   es
    1343:	57                   	push   di
    1344:	9a da 13 5c 13       	call   0x135c:0x13da
    1349:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    134c:	48                   	dec    ax
    134d:	50                   	push   ax
    134e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1351:	48                   	dec    ax
    1352:	48                   	dec    ax
    1353:	50                   	push   ax
    1354:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1357:	06                   	push   es
    1358:	57                   	push   di
    1359:	9a b8 1d 70 13       	call   0x1370:0x1db8
    135e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1361:	48                   	dec    ax
    1362:	50                   	push   ax
    1363:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1366:	48                   	dec    ax
    1367:	50                   	push   ax
    1368:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    136b:	06                   	push   es
    136c:	57                   	push   di
    136d:	9a 7b 1d 86 13       	call   0x1386:0x1d7b
    1372:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1375:	2d 03 00             	sub    ax,0x3
    1378:	50                   	push   ax
    1379:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    137c:	48                   	dec    ax
    137d:	50                   	push   ax
    137e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1381:	06                   	push   es
    1382:	57                   	push   di
    1383:	9a 7b 1d e1 13       	call   0x13e1:0x1d7b
    1388:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    138b:	8d 7e f8             	lea    di,[bp-0x8]
    138e:	16                   	push   ss
    138f:	57                   	push   di
    1390:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1393:	50                   	push   ax
    1394:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1397:	06                   	push   es
    1398:	57                   	push   di
    1399:	9a 05 15 bd 13       	call   0x13bd:0x1505
    139e:	c9                   	leave
    139f:	ca 06 00             	retf   0x6
    13a2:	c8 08 02 00          	enter  0x208,0x0
    13a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13a9:	26 80 bd 8e 00 00    	cmp    BYTE PTR es:[di+0x8e],0x0
    13af:	74 34                	je     0x13e5
    13b1:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    13b5:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    13b9:	bf ed 01             	mov    di,0x1ed
    13bc:	b8 f4 13             	mov    ax,0x13f4
    13bf:	50                   	push   ax
    13c0:	57                   	push   di
    13c1:	9a 73 22 fb 13       	call   0x13fb:0x2273
    13c6:	89 c7                	mov    di,ax
    13c8:	8e c2                	mov    es,dx
    13ca:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    13cf:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    13d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13d7:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    13dc:	06                   	push   es
    13dd:	57                   	push   di
    13de:	9a 99 20 18 14       	call   0x1418:0x2099
    13e3:	eb 35                	jmp    0x141a
    13e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e8:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    13ec:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    13f0:	bf ed 01             	mov    di,0x1ed
    13f3:	b8 60 15             	mov    ax,0x1560
    13f6:	50                   	push   ax
    13f7:	57                   	push   di
    13f8:	9a 73 22 4d 14       	call   0x144d:0x2273
    13fd:	89 c7                	mov    di,ax
    13ff:	8e c2                	mov    es,dx
    1401:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    1406:	26 ff b5 f0 00       	push   WORD PTR es:[di+0xf0]
    140b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    140e:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1413:	06                   	push   es
    1414:	57                   	push   di
    1415:	9a 99 20 3f 14       	call   0x143f:0x2099
    141a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    141d:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1422:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1426:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    142a:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    142e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1431:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1436:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    143a:	06                   	push   es
    143b:	57                   	push   di
    143c:	9a da 13 5c 14       	call   0x145c:0x13da
    1441:	8d 7e f8             	lea    di,[bp-0x8]
    1444:	16                   	push   ss
    1445:	57                   	push   di
    1446:	6a 08                	push   0x8
    1448:	6a 00                	push   0x0
    144a:	9a e5 1e 39 15       	call   0x1539:0x1ee5
    144f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1452:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1457:	06                   	push   es
    1458:	57                   	push   di
    1459:	9a d2 21 ff 14       	call   0x14ff:0x21d2
    145e:	50                   	push   ax
    145f:	8d be f8 fe          	lea    di,[bp-0x108]
    1463:	16                   	push   ss
    1464:	57                   	push   di
    1465:	8d be f8 fd          	lea    di,[bp-0x208]
    1469:	16                   	push   ss
    146a:	57                   	push   di
    146b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    146e:	06                   	push   es
    146f:	57                   	push   di
    1470:	9a 53 1d 93 14       	call   0x1493:0x1d53
    1475:	9a 4c 0d 1b 16       	call   0x161b:0xd4c
    147a:	52                   	push   dx
    147b:	50                   	push   ax
    147c:	6a ff                	push   0xffff
    147e:	8d 7e f8             	lea    di,[bp-0x8]
    1481:	16                   	push   ss
    1482:	57                   	push   di
    1483:	68 20 04             	push   0x420
    1486:	9a 3d 16 00 00       	call   0x0:0x163d
    148b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    148e:	06                   	push   es
    148f:	57                   	push   di
    1490:	9a a9 18 a5 14       	call   0x14a5:0x18a9
    1495:	2d 0a 00             	sub    ax,0xa
    1498:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    149b:	7d 10                	jge    0x14ad
    149d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14a0:	06                   	push   es
    14a1:	57                   	push   di
    14a2:	9a a9 18 ba 14       	call   0x14ba:0x18a9
    14a7:	2d 0a 00             	sub    ax,0xa
    14aa:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    14ad:	8d 7e f8             	lea    di,[bp-0x8]
    14b0:	16                   	push   ss
    14b1:	57                   	push   di
    14b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14b5:	06                   	push   es
    14b6:	57                   	push   di
    14b7:	9a a9 18 ce 14       	call   0x14ce:0x18a9
    14bc:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    14bf:	99                   	cwd
    14c0:	b9 02 00             	mov    cx,0x2
    14c3:	f7 f9                	idiv   cx
    14c5:	50                   	push   ax
    14c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14c9:	06                   	push   es
    14ca:	57                   	push   di
    14cb:	9a f4 18 16 16       	call   0x1616:0x18f4
    14d0:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    14d3:	99                   	cwd
    14d4:	b9 02 00             	mov    cx,0x2
    14d7:	f7 f9                	idiv   cx
    14d9:	50                   	push   ax
    14da:	9a ff ff 00 00       	call   0x0:0xffff
    14df:	8d 7e f8             	lea    di,[bp-0x8]
    14e2:	16                   	push   ss
    14e3:	57                   	push   di
    14e4:	6a 02                	push   0x2
    14e6:	6a 01                	push   0x1
    14e8:	9a 45 15 00 00       	call   0x0:0x1545
    14ed:	8d 7e f8             	lea    di,[bp-0x8]
    14f0:	16                   	push   ss
    14f1:	57                   	push   di
    14f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14f5:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    14fa:	06                   	push   es
    14fb:	57                   	push   di
    14fc:	9a 66 1c 84 15       	call   0x1584:0x1c66
    1501:	c9                   	leave
    1502:	ca 06 00             	retf   0x6
    1505:	c8 10 02 00          	enter  0x210,0x0
    1509:	8c d3                	mov    bx,ss
    150b:	8e c3                	mov    es,bx
    150d:	8c db                	mov    bx,ds
    150f:	fc                   	cld
    1510:	8d 7e f8             	lea    di,[bp-0x8]
    1513:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    1516:	b9 08 00             	mov    cx,0x8
    1519:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    151b:	8e db                	mov    ds,bx
    151d:	8d be e8 fe          	lea    di,[bp-0x118]
    1521:	16                   	push   ss
    1522:	57                   	push   di
    1523:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1526:	06                   	push   es
    1527:	57                   	push   di
    1528:	26 c4 3d             	les    di,DWORD PTR es:[di]
    152b:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    152f:	8d 7e f0             	lea    di,[bp-0x10]
    1532:	16                   	push   ss
    1533:	57                   	push   di
    1534:	6a 08                	push   0x8
    1536:	9a 1b 16 67 15       	call   0x1567:0x161b
    153b:	8d 7e f0             	lea    di,[bp-0x10]
    153e:	16                   	push   ss
    153f:	57                   	push   di
    1540:	6a fc                	push   0xfffc
    1542:	6a fd                	push   0xfffd
    1544:	9a 27 2d 00 00       	call   0x0:0x2d27
    1549:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    154c:	26 80 bd 8e 00 00    	cmp    BYTE PTR es:[di+0x8e],0x0
    1552:	74 34                	je     0x1588
    1554:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1558:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    155c:	bf ed 01             	mov    di,0x1ed
    155f:	b8 97 15             	mov    ax,0x1597
    1562:	50                   	push   ax
    1563:	57                   	push   di
    1564:	9a 73 22 9e 15       	call   0x159e:0x2273
    1569:	89 c7                	mov    di,ax
    156b:	8e c2                	mov    es,dx
    156d:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    1572:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    1577:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    157a:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    157f:	06                   	push   es
    1580:	57                   	push   di
    1581:	9a 99 20 bb 15       	call   0x15bb:0x2099
    1586:	eb 35                	jmp    0x15bd
    1588:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    158b:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    158f:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1593:	bf ed 01             	mov    di,0x1ed
    1596:	b8 49 16             	mov    ax,0x1649
    1599:	50                   	push   ax
    159a:	57                   	push   di
    159b:	9a 73 22 65 16       	call   0x1665:0x2273
    15a0:	89 c7                	mov    di,ax
    15a2:	8e c2                	mov    es,dx
    15a4:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    15a9:	26 ff b5 f0 00       	push   WORD PTR es:[di+0xf0]
    15ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15b1:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    15b6:	06                   	push   es
    15b7:	57                   	push   di
    15b8:	9a 99 20 d9 15       	call   0x15d9:0x2099
    15bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15c0:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    15c5:	75 14                	jne    0x15db
    15c7:	6a ff                	push   0xffff
    15c9:	6a ee                	push   0xffee
    15cb:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    15d0:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    15d4:	06                   	push   es
    15d5:	57                   	push   di
    15d6:	9a df 0f 00 16       	call   0x1600:0xfdf
    15db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15de:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    15e3:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    15e7:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    15eb:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    15ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15f2:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    15f7:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    15fb:	06                   	push   es
    15fc:	57                   	push   di
    15fd:	9a da 13 2a 16       	call   0x162a:0x13da
    1602:	8d be f0 fe          	lea    di,[bp-0x110]
    1606:	16                   	push   ss
    1607:	57                   	push   di
    1608:	8d be f0 fd          	lea    di,[bp-0x210]
    160c:	16                   	push   ss
    160d:	57                   	push   di
    160e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1611:	06                   	push   es
    1612:	57                   	push   di
    1613:	9a 53 1d c7 16       	call   0x16c7:0x1d53
    1618:	9a 4c 0d 13 1f       	call   0x1f13:0xd4c
    161d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1620:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1625:	06                   	push   es
    1626:	57                   	push   di
    1627:	9a d2 21 27 17       	call   0x1727:0x21d2
    162c:	50                   	push   ax
    162d:	8d be f0 fe          	lea    di,[bp-0x110]
    1631:	16                   	push   ss
    1632:	57                   	push   di
    1633:	6a ff                	push   0xffff
    1635:	8d 7e f0             	lea    di,[bp-0x10]
    1638:	16                   	push   ss
    1639:	57                   	push   di
    163a:	6a 21                	push   0x21
    163c:	9a ff ff 00 00       	call   0x0:0xffff
    1641:	c9                   	leave
    1642:	ca 0a 00             	retf   0xa
    1645:	00 00                	add    BYTE PTR [bx+si],al
    1647:	d5 16                	aad    0x16
    1649:	5e                   	pop    si
    164a:	16                   	push   ss
    164b:	c8 04 00 00          	enter  0x4,0x0
    164f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1652:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1656:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    165a:	bf ed 01             	mov    di,0x1ed
    165d:	b8 c2 18             	mov    ax,0x18c2
    1660:	50                   	push   ax
    1661:	57                   	push   di
    1662:	9a 55 22 0a 17       	call   0x170a:0x2255
    1667:	08 c0                	or     al,al
    1669:	74 19                	je     0x1684
    166b:	ff 76 08             	push   WORD PTR [bp+0x8]
    166e:	ff 76 06             	push   WORD PTR [bp+0x6]
    1671:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1674:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1678:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    167d:	06                   	push   es
    167e:	57                   	push   di
    167f:	9a 2b 0c 8e 1c       	call   0x1c8e:0xc2b
    1684:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1687:	26 8b 45 16          	mov    ax,WORD PTR es:[di+0x16]
    168b:	26 8b 55 18          	mov    dx,WORD PTR es:[di+0x18]
    168f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1692:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1695:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1698:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    169c:	26 8b 55 14          	mov    dx,WORD PTR es:[di+0x14]
    16a0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    16a3:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    16a7:	26 89 55 18          	mov    WORD PTR es:[di+0x18],dx
    16ab:	b8 45 16             	mov    ax,0x1645
    16ae:	0e                   	push   cs
    16af:	50                   	push   ax
    16b0:	55                   	push   bp
    16b1:	ff 36 58 18          	push   WORD PTR ds:0x1858
    16b5:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    16b9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    16bc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    16bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16c2:	06                   	push   es
    16c3:	57                   	push   di
    16c4:	9a 98 15 b1 18       	call   0x18b1:0x1598
    16c9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    16cd:	83 c4 06             	add    sp,0x6
    16d0:	b8 e7 16             	mov    ax,0x16e7
    16d3:	0e                   	push   cs
    16d4:	50                   	push   ax
    16d5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    16d8:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    16db:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    16de:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    16e2:	26 89 55 18          	mov    WORD PTR es:[di+0x18],dx
    16e6:	cb                   	retf
    16e7:	c9                   	leave
    16e8:	ca 08 00             	retf   0x8
    16eb:	c8 0e 01 00          	enter  0x10e,0x0
    16ef:	8d 7e ee             	lea    di,[bp-0x12]
    16f2:	16                   	push   ss
    16f3:	57                   	push   di
    16f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16f7:	06                   	push   es
    16f8:	57                   	push   di
    16f9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16fc:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1700:	8d 7e f8             	lea    di,[bp-0x8]
    1703:	16                   	push   ss
    1704:	57                   	push   di
    1705:	6a 08                	push   0x8
    1707:	9a 1b 16 c9 18       	call   0x18c9:0x161b
    170c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    170f:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1714:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    1717:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    171a:	6a ff                	push   0xffff
    171c:	6a f0                	push   0xfff0
    171e:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    1722:	06                   	push   es
    1723:	57                   	push   di
    1724:	9a 84 16 36 17       	call   0x1736:0x1684
    1729:	8d 7e f8             	lea    di,[bp-0x8]
    172c:	16                   	push   ss
    172d:	57                   	push   di
    172e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1731:	06                   	push   es
    1732:	57                   	push   di
    1733:	9a e5 1c 4b 17       	call   0x174b:0x1ce5
    1738:	ff 4e fc             	dec    WORD PTR [bp-0x4]
    173b:	6a 00                	push   0x0
    173d:	6a 00                	push   0x0
    173f:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1742:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1746:	06                   	push   es
    1747:	57                   	push   di
    1748:	9a da 13 61 17       	call   0x1761:0x13da
    174d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1751:	75 72                	jne    0x17c5
    1753:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1756:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1759:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    175c:	06                   	push   es
    175d:	57                   	push   di
    175e:	9a b8 1d 75 17       	call   0x1775:0x1db8
    1763:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1766:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1769:	05 04 00             	add    ax,0x4
    176c:	50                   	push   ax
    176d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1770:	06                   	push   es
    1771:	57                   	push   di
    1772:	9a 7b 1d 89 17       	call   0x1789:0x1d7b
    1777:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    177a:	05 04 00             	add    ax,0x4
    177d:	50                   	push   ax
    177e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1781:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1784:	06                   	push   es
    1785:	57                   	push   di
    1786:	9a 7b 1d 9d 17       	call   0x179d:0x1d7b
    178b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    178e:	2d 04 00             	sub    ax,0x4
    1791:	50                   	push   ax
    1792:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1795:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1798:	06                   	push   es
    1799:	57                   	push   di
    179a:	9a 7b 1d b1 17       	call   0x17b1:0x1d7b
    179f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    17a2:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    17a5:	05 04 00             	add    ax,0x4
    17a8:	50                   	push   ax
    17a9:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    17ac:	06                   	push   es
    17ad:	57                   	push   di
    17ae:	9a 7b 1d c1 17       	call   0x17c1:0x1d7b
    17b3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    17b6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    17b9:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    17bc:	06                   	push   es
    17bd:	57                   	push   di
    17be:	9a 7b 1d d7 17       	call   0x17d7:0x1d7b
    17c3:	eb 78                	jmp    0x183d
    17c5:	ff 76 f8             	push   WORD PTR [bp-0x8]
    17c8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    17cb:	2d 03 00             	sub    ax,0x3
    17ce:	50                   	push   ax
    17cf:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    17d2:	06                   	push   es
    17d3:	57                   	push   di
    17d4:	9a b8 1d eb 17       	call   0x17eb:0x1db8
    17d9:	ff 76 f8             	push   WORD PTR [bp-0x8]
    17dc:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    17df:	05 04 00             	add    ax,0x4
    17e2:	50                   	push   ax
    17e3:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    17e6:	06                   	push   es
    17e7:	57                   	push   di
    17e8:	9a 7b 1d ff 17       	call   0x17ff:0x1d7b
    17ed:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    17f0:	05 04 00             	add    ax,0x4
    17f3:	50                   	push   ax
    17f4:	ff 76 fa             	push   WORD PTR [bp-0x6]
    17f7:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    17fa:	06                   	push   es
    17fb:	57                   	push   di
    17fc:	9a 7b 1d 13 18       	call   0x1813:0x1d7b
    1801:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1804:	2d 04 00             	sub    ax,0x4
    1807:	50                   	push   ax
    1808:	ff 76 fa             	push   WORD PTR [bp-0x6]
    180b:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    180e:	06                   	push   es
    180f:	57                   	push   di
    1810:	9a 7b 1d 27 18       	call   0x1827:0x1d7b
    1815:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1818:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    181b:	05 04 00             	add    ax,0x4
    181e:	50                   	push   ax
    181f:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1822:	06                   	push   es
    1823:	57                   	push   di
    1824:	9a 7b 1d 3b 18       	call   0x183b:0x1d7b
    1829:	ff 76 fc             	push   WORD PTR [bp-0x4]
    182c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    182f:	2d 03 00             	sub    ax,0x3
    1832:	50                   	push   ax
    1833:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1836:	06                   	push   es
    1837:	57                   	push   di
    1838:	9a 7b 1d 4d 18       	call   0x184d:0x1d7b
    183d:	6a ff                	push   0xffff
    183f:	6a eb                	push   0xffeb
    1841:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1844:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1848:	06                   	push   es
    1849:	57                   	push   di
    184a:	9a da 13 5f 18       	call   0x185f:0x13da
    184f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1852:	40                   	inc    ax
    1853:	50                   	push   ax
    1854:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1857:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    185a:	06                   	push   es
    185b:	57                   	push   di
    185c:	9a b8 1d 75 18       	call   0x1875:0x1db8
    1861:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1864:	40                   	inc    ax
    1865:	50                   	push   ax
    1866:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1869:	05 04 00             	add    ax,0x4
    186c:	50                   	push   ax
    186d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1870:	06                   	push   es
    1871:	57                   	push   di
    1872:	9a 7b 1d 8b 18       	call   0x188b:0x1d7b
    1877:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    187a:	05 04 00             	add    ax,0x4
    187d:	50                   	push   ax
    187e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1881:	40                   	inc    ax
    1882:	50                   	push   ax
    1883:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1886:	06                   	push   es
    1887:	57                   	push   di
    1888:	9a 7b 1d a1 18       	call   0x18a1:0x1d7b
    188d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1890:	2d 03 00             	sub    ax,0x3
    1893:	50                   	push   ax
    1894:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1897:	40                   	inc    ax
    1898:	50                   	push   ax
    1899:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    189c:	06                   	push   es
    189d:	57                   	push   di
    189e:	9a 7b 1d 85 1a       	call   0x1a85:0x1d7b
    18a3:	8d be f2 fe          	lea    di,[bp-0x10e]
    18a7:	16                   	push   ss
    18a8:	57                   	push   di
    18a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18ac:	06                   	push   es
    18ad:	57                   	push   di
    18ae:	9a 53 1d a4 1b       	call   0x1ba4:0x1d53
    18b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18b6:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    18ba:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    18be:	bf ed 01             	mov    di,0x1ed
    18c1:	b8 d4 18             	mov    ax,0x18d4
    18c4:	50                   	push   ax
    18c5:	57                   	push   di
    18c6:	9a 73 22 ef 18       	call   0x18ef:0x2273
    18cb:	89 c7                	mov    di,ax
    18cd:	8e c2                	mov    es,dx
    18cf:	06                   	push   es
    18d0:	57                   	push   di
    18d1:	9a 98 2e e8 18       	call   0x18e8:0x2e98
    18d6:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    18d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18dc:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    18e0:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    18e4:	bf ed 01             	mov    di,0x1ed
    18e7:	b8 09 19             	mov    ax,0x1909
    18ea:	50                   	push   ax
    18eb:	57                   	push   di
    18ec:	9a 73 22 10 19       	call   0x1910:0x2273
    18f1:	89 c7                	mov    di,ax
    18f3:	8e c2                	mov    es,dx
    18f5:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    18fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18fd:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1901:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1905:	bf ed 01             	mov    di,0x1ed
    1908:	b8 3a 19             	mov    ax,0x193a
    190b:	50                   	push   ax
    190c:	57                   	push   di
    190d:	9a 73 22 41 19       	call   0x1941:0x2273
    1912:	89 c7                	mov    di,ax
    1914:	8e c2                	mov    es,dx
    1916:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    191b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    191f:	59                   	pop    cx
    1920:	99                   	cwd
    1921:	f7 f9                	idiv   cx
    1923:	92                   	xchg   dx,ax
    1924:	09 c0                	or     ax,ax
    1926:	75 03                	jne    0x192b
    1928:	e9 f7 01             	jmp    0x1b22
    192b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    192e:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1932:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1936:	bf ed 01             	mov    di,0x1ed
    1939:	b8 6a 19             	mov    ax,0x196a
    193c:	50                   	push   ax
    193d:	57                   	push   di
    193e:	9a 73 22 71 19       	call   0x1971:0x2273
    1943:	89 c7                	mov    di,ax
    1945:	8e c2                	mov    es,dx
    1947:	26 8b 8d f8 00       	mov    cx,WORD PTR es:[di+0xf8]
    194c:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    194f:	40                   	inc    ax
    1950:	99                   	cwd
    1951:	f7 f9                	idiv   cx
    1953:	92                   	xchg   dx,ax
    1954:	09 c0                	or     ax,ax
    1956:	74 03                	je     0x195b
    1958:	e9 c7 01             	jmp    0x1b22
    195b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    195e:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1962:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1966:	bf ed 01             	mov    di,0x1ed
    1969:	b8 93 19             	mov    ax,0x1993
    196c:	50                   	push   ax
    196d:	57                   	push   di
    196e:	9a 73 22 9a 19       	call   0x199a:0x2273
    1973:	89 c7                	mov    di,ax
    1975:	8e c2                	mov    es,dx
    1977:	26 8b 8d f8 00       	mov    cx,WORD PTR es:[di+0xf8]
    197c:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    197f:	99                   	cwd
    1980:	f7 f9                	idiv   cx
    1982:	40                   	inc    ax
    1983:	50                   	push   ax
    1984:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1987:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    198b:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    198f:	bf ed 01             	mov    di,0x1ed
    1992:	b8 b4 19             	mov    ax,0x19b4
    1995:	50                   	push   ax
    1996:	57                   	push   di
    1997:	9a 73 22 bb 19       	call   0x19bb:0x2273
    199c:	89 c7                	mov    di,ax
    199e:	8e c2                	mov    es,dx
    19a0:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    19a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a8:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    19ac:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    19b0:	bf ed 01             	mov    di,0x1ed
    19b3:	b8 e5 19             	mov    ax,0x19e5
    19b6:	50                   	push   ax
    19b7:	57                   	push   di
    19b8:	9a 73 22 ec 19       	call   0x19ec:0x2273
    19bd:	89 c7                	mov    di,ax
    19bf:	8e c2                	mov    es,dx
    19c1:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    19c6:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    19ca:	59                   	pop    cx
    19cb:	99                   	cwd
    19cc:	f7 f9                	idiv   cx
    19ce:	5a                   	pop    dx
    19cf:	3b c2                	cmp    ax,dx
    19d1:	74 03                	je     0x19d6
    19d3:	e9 4c 01             	jmp    0x1b22
    19d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19d9:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    19dd:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    19e1:	bf ed 01             	mov    di,0x1ed
    19e4:	b8 0e 1a             	mov    ax,0x1a0e
    19e7:	50                   	push   ax
    19e8:	57                   	push   di
    19e9:	9a 73 22 15 1a       	call   0x1a15:0x2273
    19ee:	89 c7                	mov    di,ax
    19f0:	8e c2                	mov    es,dx
    19f2:	26 8b 8d f8 00       	mov    cx,WORD PTR es:[di+0xf8]
    19f7:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    19fa:	99                   	cwd
    19fb:	f7 f9                	idiv   cx
    19fd:	40                   	inc    ax
    19fe:	50                   	push   ax
    19ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a02:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1a06:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1a0a:	bf ed 01             	mov    di,0x1ed
    1a0d:	b8 2f 1a             	mov    ax,0x1a2f
    1a10:	50                   	push   ax
    1a11:	57                   	push   di
    1a12:	9a 73 22 36 1a       	call   0x1a36:0x2273
    1a17:	89 c7                	mov    di,ax
    1a19:	8e c2                	mov    es,dx
    1a1b:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1a20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a23:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1a27:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1a2b:	bf ed 01             	mov    di,0x1ed
    1a2e:	b8 55 1c             	mov    ax,0x1c55
    1a31:	50                   	push   ax
    1a32:	57                   	push   di
    1a33:	9a 73 22 ea 1b       	call   0x1bea:0x2273
    1a38:	89 c7                	mov    di,ax
    1a3a:	8e c2                	mov    es,dx
    1a3c:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    1a41:	59                   	pop    cx
    1a42:	99                   	cwd
    1a43:	f7 f9                	idiv   cx
    1a45:	5a                   	pop    dx
    1a46:	3b c2                	cmp    ax,dx
    1a48:	75 03                	jne    0x1a4d
    1a4a:	e9 d5 00             	jmp    0x1b22
    1a4d:	8d 7e ea             	lea    di,[bp-0x16]
    1a50:	16                   	push   ss
    1a51:	57                   	push   di
    1a52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a55:	06                   	push   es
    1a56:	57                   	push   di
    1a57:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a5a:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1a5e:	83 c4 04             	add    sp,0x4
    1a61:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1a64:	8d 7e e2             	lea    di,[bp-0x1e]
    1a67:	16                   	push   ss
    1a68:	57                   	push   di
    1a69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a6c:	06                   	push   es
    1a6d:	57                   	push   di
    1a6e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a71:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1a75:	83 c4 04             	add    sp,0x4
    1a78:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    1a7b:	40                   	inc    ax
    1a7c:	50                   	push   ax
    1a7d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1a80:	06                   	push   es
    1a81:	57                   	push   di
    1a82:	9a b8 1d ae 1a       	call   0x1aae:0x1db8
    1a87:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1a8a:	48                   	dec    ax
    1a8b:	48                   	dec    ax
    1a8c:	50                   	push   ax
    1a8d:	8d 7e ea             	lea    di,[bp-0x16]
    1a90:	16                   	push   ss
    1a91:	57                   	push   di
    1a92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a95:	06                   	push   es
    1a96:	57                   	push   di
    1a97:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a9a:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1a9e:	83 c4 04             	add    sp,0x4
    1aa1:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    1aa4:	40                   	inc    ax
    1aa5:	50                   	push   ax
    1aa6:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1aa9:	06                   	push   es
    1aaa:	57                   	push   di
    1aab:	9a 7b 1d c0 1a       	call   0x1ac0:0x1d7b
    1ab0:	6a 00                	push   0x0
    1ab2:	6a 00                	push   0x0
    1ab4:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1ab7:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1abb:	06                   	push   es
    1abc:	57                   	push   di
    1abd:	9a da 13 f8 1a       	call   0x1af8:0x13da
    1ac2:	8d 7e ea             	lea    di,[bp-0x16]
    1ac5:	16                   	push   ss
    1ac6:	57                   	push   di
    1ac7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aca:	06                   	push   es
    1acb:	57                   	push   di
    1acc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1acf:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1ad3:	83 c4 04             	add    sp,0x4
    1ad6:	ff 76 ee             	push   WORD PTR [bp-0x12]
    1ad9:	8d 7e e2             	lea    di,[bp-0x1e]
    1adc:	16                   	push   ss
    1add:	57                   	push   di
    1ade:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ae1:	06                   	push   es
    1ae2:	57                   	push   di
    1ae3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ae6:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1aea:	83 c4 04             	add    sp,0x4
    1aed:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    1af0:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1af3:	06                   	push   es
    1af4:	57                   	push   di
    1af5:	9a b8 1d 20 1b       	call   0x1b20:0x1db8
    1afa:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1afd:	2d 04 00             	sub    ax,0x4
    1b00:	50                   	push   ax
    1b01:	8d 7e ea             	lea    di,[bp-0x16]
    1b04:	16                   	push   ss
    1b05:	57                   	push   di
    1b06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b09:	06                   	push   es
    1b0a:	57                   	push   di
    1b0b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b0e:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1b12:	83 c4 04             	add    sp,0x4
    1b15:	ff 76 ec             	push   WORD PTR [bp-0x14]
    1b18:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1b1b:	06                   	push   es
    1b1c:	57                   	push   di
    1b1d:	9a 7b 1d 32 1b       	call   0x1b32:0x1d7b
    1b22:	6a ff                	push   0xffff
    1b24:	6a ef                	push   0xffef
    1b26:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1b29:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    1b2d:	06                   	push   es
    1b2e:	57                   	push   di
    1b2f:	9a da 13 49 1b       	call   0x1b49:0x13da
    1b34:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b37:	2d 03 00             	sub    ax,0x3
    1b3a:	50                   	push   ax
    1b3b:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1b3e:	40                   	inc    ax
    1b3f:	40                   	inc    ax
    1b40:	50                   	push   ax
    1b41:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1b44:	06                   	push   es
    1b45:	57                   	push   di
    1b46:	9a b8 1d 5f 1b       	call   0x1b5f:0x1db8
    1b4b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b4e:	48                   	dec    ax
    1b4f:	50                   	push   ax
    1b50:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1b53:	05 04 00             	add    ax,0x4
    1b56:	50                   	push   ax
    1b57:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1b5a:	06                   	push   es
    1b5b:	57                   	push   di
    1b5c:	9a 7b 1d 77 1b       	call   0x1b77:0x1d7b
    1b61:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1b65:	75 14                	jne    0x1b7b
    1b67:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b6a:	48                   	dec    ax
    1b6b:	50                   	push   ax
    1b6c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b6f:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1b72:	06                   	push   es
    1b73:	57                   	push   di
    1b74:	9a 7b 1d 8d 1b       	call   0x1b8d:0x1d7b
    1b79:	eb 14                	jmp    0x1b8f
    1b7b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b7e:	48                   	dec    ax
    1b7f:	50                   	push   ax
    1b80:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b83:	48                   	dec    ax
    1b84:	50                   	push   ax
    1b85:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1b88:	06                   	push   es
    1b89:	57                   	push   di
    1b8a:	9a 7b 1d 07 1e       	call   0x1e07:0x1d7b
    1b8f:	c9                   	leave
    1b90:	ca 06 00             	retf   0x6
    1b93:	55                   	push   bp
    1b94:	89 e5                	mov    bp,sp
    1b96:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1b99:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1b9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b9f:	06                   	push   es
    1ba0:	57                   	push   di
    1ba1:	9a 33 2d fd 1b       	call   0x1bfd:0x2d33
    1ba6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ba9:	06                   	push   es
    1baa:	57                   	push   di
    1bab:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bae:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1bb2:	c9                   	leave
    1bb3:	ca 08 00             	retf   0x8
    1bb6:	55                   	push   bp
    1bb7:	89 e5                	mov    bp,sp
    1bb9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bbc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1bbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bc2:	06                   	push   es
    1bc3:	57                   	push   di
    1bc4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bc7:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    1bcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bce:	06                   	push   es
    1bcf:	57                   	push   di
    1bd0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bd3:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1bd7:	c9                   	leave
    1bd8:	ca 08 00             	retf   0x8
    1bdb:	55                   	push   bp
    1bdc:	89 e5                	mov    bp,sp
    1bde:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1be2:	74 08                	je     0x1bec
    1be4:	83 ec 08             	sub    sp,0x8
    1be7:	9a e2 1f 71 1c       	call   0x1c71:0x1fe2
    1bec:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1bef:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bf2:	31 c0                	xor    ax,ax
    1bf4:	50                   	push   ax
    1bf5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf8:	06                   	push   es
    1bf9:	57                   	push   di
    1bfa:	9a 61 2e 14 1c       	call   0x1c14:0x2e61
    1bff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c02:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    1c06:	0d 01 00             	or     ax,0x1
    1c09:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    1c0d:	6a 05                	push   0x5
    1c0f:	06                   	push   es
    1c10:	57                   	push   di
    1c11:	9a 72 16 20 1c       	call   0x1c20:0x1672
    1c16:	6a 00                	push   0x0
    1c18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c1b:	06                   	push   es
    1c1c:	57                   	push   di
    1c1d:	9a 88 64 2c 1c       	call   0x1c2c:0x6488
    1c22:	6a 00                	push   0x0
    1c24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c27:	06                   	push   es
    1c28:	57                   	push   di
    1c29:	9a b8 1c 38 1c       	call   0x1c38:0x1cb8
    1c2e:	6a 00                	push   0x0
    1c30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c33:	06                   	push   es
    1c34:	57                   	push   di
    1c35:	9a 77 1c d3 1c       	call   0x1cd3:0x1c77
    1c3a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1c3e:	74 07                	je     0x1c47
    1c40:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1c44:	83 c4 06             	add    sp,0x6
    1c47:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1c4a:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1c4d:	c9                   	leave
    1c4e:	ca 0a 00             	retf   0xa
    1c51:	00 00                	add    BYTE PTR [bx+si],al
    1c53:	e1 1c                	loope  0x1c71
    1c55:	6a 1c                	push   0x1c
    1c57:	c8 04 00 00          	enter  0x4,0x0
    1c5b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c5e:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1c62:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1c66:	bf ed 01             	mov    di,0x1ed
    1c69:	b8 5b 1e             	mov    ax,0x1e5b
    1c6c:	50                   	push   ax
    1c6d:	57                   	push   di
    1c6e:	9a 55 22 8b 1d       	call   0x1d8b:0x2255
    1c73:	08 c0                	or     al,al
    1c75:	74 19                	je     0x1c90
    1c77:	ff 76 08             	push   WORD PTR [bp+0x8]
    1c7a:	ff 76 06             	push   WORD PTR [bp+0x6]
    1c7d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c80:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1c84:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    1c89:	06                   	push   es
    1c8a:	57                   	push   di
    1c8b:	9a 2b 0c 5f 1d       	call   0x1d5f:0xc2b
    1c90:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c93:	26 8b 45 16          	mov    ax,WORD PTR es:[di+0x16]
    1c97:	26 8b 55 18          	mov    dx,WORD PTR es:[di+0x18]
    1c9b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c9e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1ca1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1ca4:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    1ca8:	26 8b 55 14          	mov    dx,WORD PTR es:[di+0x14]
    1cac:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1caf:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    1cb3:	26 89 55 18          	mov    WORD PTR es:[di+0x18],dx
    1cb7:	b8 51 1c             	mov    ax,0x1c51
    1cba:	0e                   	push   cs
    1cbb:	50                   	push   ax
    1cbc:	55                   	push   bp
    1cbd:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1cc1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1cc5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1cc8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ccb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cce:	06                   	push   es
    1ccf:	57                   	push   di
    1cd0:	9a ec 30 fd 1c       	call   0x1cfd:0x30ec
    1cd5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1cd9:	83 c4 06             	add    sp,0x6
    1cdc:	b8 f3 1c             	mov    ax,0x1cf3
    1cdf:	0e                   	push   cs
    1ce0:	50                   	push   ax
    1ce1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ce4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1ce7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1cea:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    1cee:	26 89 55 18          	mov    WORD PTR es:[di+0x18],dx
    1cf2:	cb                   	retf
    1cf3:	6a 00                	push   0x0
    1cf5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf8:	06                   	push   es
    1cf9:	57                   	push   di
    1cfa:	9a 88 64 0f 1d       	call   0x1d0f:0x6488
    1cff:	c9                   	leave
    1d00:	ca 08 00             	retf   0x8
    1d03:	c8 08 00 00          	enter  0x8,0x0
    1d07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d0a:	06                   	push   es
    1d0b:	57                   	push   di
    1d0c:	9a fd 39 2f 1d       	call   0x1d2f:0x39fd
    1d11:	48                   	dec    ax
    1d12:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1d15:	31 c0                	xor    ax,ax
    1d17:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1d1a:	7f 4d                	jg     0x1d69
    1d1c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d1f:	eb 03                	jmp    0x1d24
    1d21:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1d24:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1d27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d2a:	06                   	push   es
    1d2b:	57                   	push   di
    1d2c:	9a 8f 39 9e 1d       	call   0x1d9e:0x398f
    1d31:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1d34:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1d37:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1d3a:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1d3e:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    1d42:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d45:	26 3b 55 14          	cmp    dx,WORD PTR es:[di+0x14]
    1d49:	75 16                	jne    0x1d61
    1d4b:	26 3b 45 12          	cmp    ax,WORD PTR es:[di+0x12]
    1d4f:	75 10                	jne    0x1d61
    1d51:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1d54:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1d57:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d5a:	06                   	push   es
    1d5b:	57                   	push   di
    1d5c:	9a 2a 43 cd 1d       	call   0x1dcd:0x432a
    1d61:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d64:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1d67:	75 b8                	jne    0x1d21
    1d69:	c9                   	leave
    1d6a:	ca 08 00             	retf   0x8
    1d6d:	0d 4d 53             	or     ax,0x534d
    1d70:	20 53 61             	and    BYTE PTR [bp+di+0x61],dl
    1d73:	6e                   	outs   dx,BYTE PTR ds:[si]
    1d74:	73 20                	jae    0x1d96
    1d76:	53                   	push   bx
    1d77:	65 72 69             	gs jb  0x1de3
    1d7a:	66 c8 00 01 00       	enterd 0x100,0x0
    1d7f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1d83:	74 08                	je     0x1d8d
    1d85:	83 ec 08             	sub    sp,0x8
    1d88:	9a e2 1f d4 1d       	call   0x1dd4:0x1fe2
    1d8d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1d90:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1d93:	31 c0                	xor    ax,ax
    1d95:	50                   	push   ax
    1d96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d99:	06                   	push   es
    1d9a:	57                   	push   di
    1d9b:	9a 72 6c ab 1d       	call   0x1dab:0x6c72
    1da0:	68 2c 01             	push   0x12c
    1da3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1da6:	06                   	push   es
    1da7:	57                   	push   di
    1da8:	9a bf 17 b8 1d       	call   0x1db8:0x17bf
    1dad:	68 fa 00             	push   0xfa
    1db0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1db3:	06                   	push   es
    1db4:	57                   	push   di
    1db5:	9a e1 17 c4 1d       	call   0x1dc4:0x17e1
    1dba:	6a 01                	push   0x1
    1dbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dbf:	06                   	push   es
    1dc0:	57                   	push   di
    1dc1:	9a 88 64 a2 1f       	call   0x1fa2:0x6488
    1dc6:	b0 01                	mov    al,0x1
    1dc8:	50                   	push   ax
    1dc9:	b8 a3 02             	mov    ax,0x2a3
    1dcc:	ba ea 1d             	mov    dx,0x1dea
    1dcf:	52                   	push   dx
    1dd0:	50                   	push   ax
    1dd1:	9a 50 1f f1 1d       	call   0x1df1:0x1f50
    1dd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dd9:	26 89 85 de 00       	mov    WORD PTR es:[di+0xde],ax
    1dde:	26 89 95 e0 00       	mov    WORD PTR es:[di+0xe0],dx
    1de3:	b0 01                	mov    al,0x1
    1de5:	50                   	push   ax
    1de6:	b8 a3 02             	mov    ax,0x2a3
    1de9:	ba ef 1f             	mov    dx,0x1fef
    1dec:	52                   	push   dx
    1ded:	50                   	push   ax
    1dee:	9a 50 1f 59 1f       	call   0x1f59:0x1f50
    1df3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1df6:	26 89 85 e2 00       	mov    WORD PTR es:[di+0xe2],ax
    1dfb:	26 89 95 e4 00       	mov    WORD PTR es:[di+0xe4],dx
    1e00:	b0 01                	mov    al,0x1
    1e02:	50                   	push   ax
    1e03:	b8 10 03             	mov    ax,0x310
    1e06:	ba 0e 1e             	mov    dx,0x1e0e
    1e09:	52                   	push   dx
    1e0a:	50                   	push   ax
    1e0b:	9a 96 0e 2b 1e       	call   0x1e2b:0xe96
    1e10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e13:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
    1e18:	26 89 95 f2 00       	mov    WORD PTR es:[di+0xf2],dx
    1e1d:	6a ff                	push   0xffff
    1e1f:	6a ed                	push   0xffed
    1e21:	26 c4 bd f0 00       	les    di,DWORD PTR es:[di+0xf0]
    1e26:	06                   	push   es
    1e27:	57                   	push   di
    1e28:	9a df 0f 3f 1e       	call   0x1e3f:0xfdf
    1e2d:	bf 6d 1d             	mov    di,0x1d6d
    1e30:	0e                   	push   cs
    1e31:	57                   	push   di
    1e32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e35:	26 c4 bd f0 00       	les    di,DWORD PTR es:[di+0xf0]
    1e3a:	06                   	push   es
    1e3b:	57                   	push   di
    1e3c:	9a 7e 11 50 1e       	call   0x1e50:0x117e
    1e41:	6a 08                	push   0x8
    1e43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e46:	26 c4 bd f0 00       	les    di,DWORD PTR es:[di+0xf0]
    1e4b:	06                   	push   es
    1e4c:	57                   	push   di
    1e4d:	9a f5 11 79 1e       	call   0x1e79:0x11f5
    1e52:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e55:	06                   	push   es
    1e56:	57                   	push   di
    1e57:	b8 b0 32             	mov    ax,0x32b0
    1e5a:	ba ea 1e             	mov    dx,0x1eea
    1e5d:	26 c4 bd f0 00       	les    di,DWORD PTR es:[di+0xf0]
    1e62:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1e66:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1e6a:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    1e6e:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    1e72:	b0 01                	mov    al,0x1
    1e74:	50                   	push   ax
    1e75:	b8 10 03             	mov    ax,0x310
    1e78:	ba 80 1e             	mov    dx,0x1e80
    1e7b:	52                   	push   dx
    1e7c:	50                   	push   ax
    1e7d:	9a 96 0e b6 1e       	call   0x1eb6:0xe96
    1e82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e85:	26 89 85 f4 00       	mov    WORD PTR es:[di+0xf4],ax
    1e8a:	26 89 95 f6 00       	mov    WORD PTR es:[di+0xf6],dx
    1e8f:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    1e94:	26 ff b5 f0 00       	push   WORD PTR es:[di+0xf0]
    1e99:	26 c4 bd f4 00       	les    di,DWORD PTR es:[di+0xf4]
    1e9e:	06                   	push   es
    1e9f:	57                   	push   di
    1ea0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ea3:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    1ea7:	6a 01                	push   0x1
    1ea9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eac:	26 c4 bd f4 00       	les    di,DWORD PTR es:[di+0xf4]
    1eb1:	06                   	push   es
    1eb2:	57                   	push   di
    1eb3:	9a 33 12 ba 2a       	call   0x2aba:0x1233
    1eb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ebb:	26 c7 85 f8 00 03 00 	mov    WORD PTR es:[di+0xf8],0x3
    1ec2:	26 c7 85 dc 00 14 00 	mov    WORD PTR es:[di+0xdc],0x14
    1ec9:	26 ff b5 e0 00       	push   WORD PTR es:[di+0xe0]
    1ece:	26 ff b5 de 00       	push   WORD PTR es:[di+0xde]
    1ed3:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    1ed8:	26 ff b5 e2 00       	push   WORD PTR es:[di+0xe2]
    1edd:	ff 76 08             	push   WORD PTR [bp+0x8]
    1ee0:	ff 76 06             	push   WORD PTR [bp+0x6]
    1ee3:	b0 01                	mov    al,0x1
    1ee5:	50                   	push   ax
    1ee6:	b8 19 05             	mov    ax,0x519
    1ee9:	ba f1 1e             	mov    dx,0x1ef1
    1eec:	52                   	push   dx
    1eed:	50                   	push   ax
    1eee:	9a 6d 06 30 1f       	call   0x1f30:0x66d
    1ef3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ef6:	26 89 85 ea 00       	mov    WORD PTR es:[di+0xea],ax
    1efb:	26 89 95 ec 00       	mov    WORD PTR es:[di+0xec],dx
    1f00:	26 c7 85 ee 00 ff ff 	mov    WORD PTR es:[di+0xee],0xffff
    1f07:	8d be 00 ff          	lea    di,[bp-0x100]
    1f0b:	16                   	push   ss
    1f0c:	57                   	push   di
    1f0d:	68 a9 f0             	push   0xf0a9
    1f10:	9a 2b 09 ff ff       	call   0xffff:0x92b
    1f15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f18:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    1f1d:	06                   	push   es
    1f1e:	57                   	push   di
    1f1f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f22:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1f26:	6a 00                	push   0x0
    1f28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f2b:	06                   	push   es
    1f2c:	57                   	push   di
    1f2d:	9a 6f 24 37 20       	call   0x2037:0x246f
    1f32:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1f36:	74 07                	je     0x1f3f
    1f38:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1f3c:	83 c4 06             	add    sp,0x6
    1f3f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1f42:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1f45:	c9                   	leave
    1f46:	ca 0a 00             	retf   0xa
    1f49:	55                   	push   bp
    1f4a:	89 e5                	mov    bp,sp
    1f4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f4f:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    1f54:	06                   	push   es
    1f55:	57                   	push   di
    1f56:	9a 7f 1f 68 1f       	call   0x1f68:0x1f7f
    1f5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f5e:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    1f63:	06                   	push   es
    1f64:	57                   	push   di
    1f65:	9a 7f 1f 77 1f       	call   0x1f77:0x1f7f
    1f6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f6d:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    1f72:	06                   	push   es
    1f73:	57                   	push   di
    1f74:	9a 7f 1f 86 1f       	call   0x1f86:0x1f7f
    1f79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f7c:	26 c4 bd f0 00       	les    di,DWORD PTR es:[di+0xf0]
    1f81:	06                   	push   es
    1f82:	57                   	push   di
    1f83:	9a 7f 1f 95 1f       	call   0x1f95:0x1f7f
    1f88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f8b:	26 c4 bd f4 00       	les    di,DWORD PTR es:[di+0xf4]
    1f90:	06                   	push   es
    1f91:	57                   	push   di
    1f92:	9a 7f 1f ad 1f       	call   0x1fad:0x1f7f
    1f97:	31 c0                	xor    ax,ax
    1f99:	50                   	push   ax
    1f9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f9d:	06                   	push   es
    1f9e:	57                   	push   di
    1f9f:	9a dc 6c c3 1f       	call   0x1fc3:0x6cdc
    1fa4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1fa8:	74 05                	je     0x1faf
    1faa:	9a 0f 20 3e 20       	call   0x203e:0x200f
    1faf:	c9                   	leave
    1fb0:	ca 06 00             	retf   0x6
    1fb3:	55                   	push   bp
    1fb4:	89 e5                	mov    bp,sp
    1fb6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1fb9:	06                   	push   es
    1fba:	57                   	push   di
    1fbb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fbe:	06                   	push   es
    1fbf:	57                   	push   di
    1fc0:	9a 29 3b 49 20       	call   0x2049:0x3b29
    1fc5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1fc8:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1fcc:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    1fd0:	0d 00 00             	or     ax,0x0
    1fd3:	81 ca 00 02          	or     dx,0x200
    1fd7:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1fdb:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1fdf:	c9                   	leave
    1fe0:	ca 08 00             	retf   0x8
    1fe3:	c8 04 00 00          	enter  0x4,0x0
    1fe7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fea:	06                   	push   es
    1feb:	57                   	push   di
    1fec:	9a f4 4f 2f 20       	call   0x202f:0x4ff4
    1ff1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ff4:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    1ff9:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1ffd:	48                   	dec    ax
    1ffe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2001:	31 c0                	xor    ax,ax
    2003:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2006:	7e 03                	jle    0x200b
    2008:	e9 d7 00             	jmp    0x20e2
    200b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    200e:	eb 03                	jmp    0x2013
    2010:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2013:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2016:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2019:	26 3b 85 ee 00       	cmp    ax,WORD PTR es:[di+0xee]
    201e:	74 5b                	je     0x207b
    2020:	6a 00                	push   0x0
    2022:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2025:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    202a:	06                   	push   es
    202b:	57                   	push   di
    202c:	9a d0 0d 5d 20       	call   0x205d:0xdd0
    2031:	52                   	push   dx
    2032:	50                   	push   ax
    2033:	bf 6b 00             	mov    di,0x6b
    2036:	b8 65 20             	mov    ax,0x2065
    2039:	50                   	push   ax
    203a:	57                   	push   di
    203b:	9a 73 22 6c 20       	call   0x206c:0x2273
    2040:	89 c7                	mov    di,ax
    2042:	8e c2                	mov    es,dx
    2044:	06                   	push   es
    2045:	57                   	push   di
    2046:	9a b8 1c 77 20       	call   0x2077:0x1cb8
    204b:	6a 00                	push   0x0
    204d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2050:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2053:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2058:	06                   	push   es
    2059:	57                   	push   di
    205a:	9a d0 0d 8d 20       	call   0x208d:0xdd0
    205f:	52                   	push   dx
    2060:	50                   	push   ax
    2061:	bf 6b 00             	mov    di,0x6b
    2064:	b8 95 20             	mov    ax,0x2095
    2067:	50                   	push   ax
    2068:	57                   	push   di
    2069:	9a 73 22 9c 20       	call   0x209c:0x2273
    206e:	89 c7                	mov    di,ax
    2070:	8e c2                	mov    es,dx
    2072:	06                   	push   es
    2073:	57                   	push   di
    2074:	9a 77 1c a7 20       	call   0x20a7:0x1c77
    2079:	eb 5c                	jmp    0x20d7
    207b:	6a 01                	push   0x1
    207d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2080:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2083:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2088:	06                   	push   es
    2089:	57                   	push   di
    208a:	9a d0 0d bb 20       	call   0x20bb:0xdd0
    208f:	52                   	push   dx
    2090:	50                   	push   ax
    2091:	bf 6b 00             	mov    di,0x6b
    2094:	b8 c3 20             	mov    ax,0x20c3
    2097:	50                   	push   ax
    2098:	57                   	push   di
    2099:	9a 73 22 ca 20       	call   0x20ca:0x2273
    209e:	89 c7                	mov    di,ax
    20a0:	8e c2                	mov    es,dx
    20a2:	06                   	push   es
    20a3:	57                   	push   di
    20a4:	9a b8 1c d5 20       	call   0x20d5:0x1cb8
    20a9:	6a 01                	push   0x1
    20ab:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20b1:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    20b6:	06                   	push   es
    20b7:	57                   	push   di
    20b8:	9a d0 0d 18 21       	call   0x2118:0xdd0
    20bd:	52                   	push   dx
    20be:	50                   	push   ax
    20bf:	bf 6b 00             	mov    di,0x6b
    20c2:	b8 f4 20             	mov    ax,0x20f4
    20c5:	50                   	push   ax
    20c6:	57                   	push   di
    20c7:	9a 73 22 b4 21       	call   0x21b4:0x2273
    20cc:	89 c7                	mov    di,ax
    20ce:	8e c2                	mov    es,dx
    20d0:	06                   	push   es
    20d1:	57                   	push   di
    20d2:	9a 77 1c ea 20       	call   0x20ea:0x1c77
    20d7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    20da:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    20dd:	74 03                	je     0x20e2
    20df:	e9 2e ff             	jmp    0x2010
    20e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20e5:	06                   	push   es
    20e6:	57                   	push   di
    20e7:	9a f9 36 58 21       	call   0x2158:0x36f9
    20ec:	c9                   	leave
    20ed:	ca 04 00             	retf   0x4
    20f0:	00 00                	add    BYTE PTR [bx+si],al
    20f2:	66 21 ad 21 c8       	and    DWORD PTR [di-0x37df],ebp
    20f7:	10 01                	adc    BYTE PTR [bx+di],al
    20f9:	00 c4                	add    ah,al
    20fb:	7e 06                	jle    0x2103
    20fd:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    2102:	06                   	push   es
    2103:	57                   	push   di
    2104:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2107:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    210b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    210e:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2113:	06                   	push   es
    2114:	57                   	push   di
    2115:	9a 75 0c a5 21       	call   0x21a5:0xc75
    211a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    211d:	26 8b 45 16          	mov    ax,WORD PTR es:[di+0x16]
    2121:	26 8b 55 18          	mov    dx,WORD PTR es:[di+0x18]
    2125:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2128:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    212b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    212e:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2131:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2134:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    2138:	26 89 55 18          	mov    WORD PTR es:[di+0x18],dx
    213c:	b8 f0 20             	mov    ax,0x20f0
    213f:	0e                   	push   cs
    2140:	50                   	push   ax
    2141:	55                   	push   bp
    2142:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2146:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    214a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    214d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2150:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2153:	06                   	push   es
    2154:	57                   	push   di
    2155:	9a ec 30 c7 21       	call   0x21c7:0x30ec
    215a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    215e:	83 c4 06             	add    sp,0x6
    2161:	b8 78 21             	mov    ax,0x2178
    2164:	0e                   	push   cs
    2165:	50                   	push   ax
    2166:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2169:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    216c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    216f:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    2173:	26 89 55 18          	mov    WORD PTR es:[di+0x18],dx
    2177:	cb                   	retf
    2178:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    217b:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    2181:	7c 5e                	jl     0x21e1
    2183:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    2188:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    218d:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    2191:	7d 4e                	jge    0x21e1
    2193:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2196:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    219b:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    21a0:	06                   	push   es
    21a1:	57                   	push   di
    21a2:	9a d0 0d 65 22       	call   0x2265:0xdd0
    21a7:	52                   	push   dx
    21a8:	50                   	push   ax
    21a9:	bf 6b 00             	mov    di,0x6b
    21ac:	b8 f3 21             	mov    ax,0x21f3
    21af:	50                   	push   ax
    21b0:	57                   	push   di
    21b1:	9a 73 22 74 22       	call   0x2274:0x2273
    21b6:	89 c7                	mov    di,ax
    21b8:	8e c2                	mov    es,dx
    21ba:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    21bd:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    21c0:	6a 01                	push   0x1
    21c2:	06                   	push   es
    21c3:	57                   	push   di
    21c4:	9a b8 1c d1 21       	call   0x21d1:0x1cb8
    21c9:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    21cc:	06                   	push   es
    21cd:	57                   	push   di
    21ce:	9a 1c 20 dd 21       	call   0x21dd:0x201c
    21d3:	6a 05                	push   0x5
    21d5:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    21d8:	06                   	push   es
    21d9:	57                   	push   di
    21da:	9a 72 16 7f 22       	call   0x227f:0x1672
    21df:	eb 0a                	jmp    0x21eb
    21e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21e4:	26 c7 85 ee 00 ff ff 	mov    WORD PTR es:[di+0xee],0xffff
    21eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ee:	06                   	push   es
    21ef:	57                   	push   di
    21f0:	9a 07 30 2e 22       	call   0x222e:0x3007
    21f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21f8:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    21fd:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2201:	48                   	dec    ax
    2202:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2205:	31 c0                	xor    ax,ax
    2207:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    220a:	7e 03                	jle    0x220f
    220c:	e9 31 01             	jmp    0x2340
    220f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2212:	eb 03                	jmp    0x2217
    2214:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    2217:	ff 76 08             	push   WORD PTR [bp+0x8]
    221a:	ff 76 06             	push   WORD PTR [bp+0x6]
    221d:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    2221:	b0 00                	mov    al,0x0
    2223:	75 01                	jne    0x2226
    2225:	40                   	inc    ax
    2226:	50                   	push   ax
    2227:	b0 01                	mov    al,0x1
    2229:	50                   	push   ax
    222a:	b8 c5 05             	mov    ax,0x5c5
    222d:	ba 35 22             	mov    dx,0x2235
    2230:	52                   	push   dx
    2231:	50                   	push   ax
    2232:	9a 27 0b 6d 22       	call   0x226d:0xb27
    2237:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    223a:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    223d:	ff 76 08             	push   WORD PTR [bp+0x8]
    2240:	ff 76 06             	push   WORD PTR [bp+0x6]
    2243:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2246:	06                   	push   es
    2247:	57                   	push   di
    2248:	26 c4 3d             	les    di,DWORD PTR es:[di]
    224b:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    224f:	8d be f0 fe          	lea    di,[bp-0x110]
    2253:	16                   	push   ss
    2254:	57                   	push   di
    2255:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2258:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    225b:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2260:	06                   	push   es
    2261:	57                   	push   di
    2262:	9a d0 0d ce 22       	call   0x22ce:0xdd0
    2267:	52                   	push   dx
    2268:	50                   	push   ax
    2269:	bf 6b 00             	mov    di,0x6b
    226c:	b8 d6 22             	mov    ax,0x22d6
    226f:	50                   	push   ax
    2270:	57                   	push   di
    2271:	9a 73 22 dd 22       	call   0x22dd:0x2273
    2276:	89 c7                	mov    di,ax
    2278:	8e c2                	mov    es,dx
    227a:	06                   	push   es
    227b:	57                   	push   di
    227c:	9a 53 1d 89 22       	call   0x2289:0x1d53
    2281:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2284:	06                   	push   es
    2285:	57                   	push   di
    2286:	9a 8c 1d 00 23       	call   0x2300:0x1d8c
    228b:	c7 46 fa 04 00       	mov    WORD PTR [bp-0x6],0x4
    2290:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2293:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2298:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    229d:	7e 56                	jle    0x22f5
    229f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a2:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    22a7:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    22ab:	48                   	dec    ax
    22ac:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    22af:	31 c0                	xor    ax,ax
    22b1:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    22b4:	7f 3f                	jg     0x22f5
    22b6:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    22b9:	eb 03                	jmp    0x22be
    22bb:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    22be:	ff 76 f6             	push   WORD PTR [bp-0xa]
    22c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c4:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    22c9:	06                   	push   es
    22ca:	57                   	push   di
    22cb:	9a d0 0d 33 23       	call   0x2333:0xdd0
    22d0:	52                   	push   dx
    22d1:	50                   	push   ax
    22d2:	bf c5 05             	mov    di,0x5c5
    22d5:	b8 4f 24             	mov    ax,0x244f
    22d8:	50                   	push   ax
    22d9:	57                   	push   di
    22da:	9a 73 22 16 27       	call   0x2716:0x2273
    22df:	89 c7                	mov    di,ax
    22e1:	8e c2                	mov    es,dx
    22e3:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    22e7:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    22ea:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    22ed:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    22f0:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    22f3:	75 c6                	jne    0x22bb
    22f5:	ff 76 fa             	push   WORD PTR [bp-0x6]
    22f8:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    22fb:	06                   	push   es
    22fc:	57                   	push   di
    22fd:	9a 7b 17 0c 23       	call   0x230c:0x177b
    2302:	6a 04                	push   0x4
    2304:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2307:	06                   	push   es
    2308:	57                   	push   di
    2309:	9a 9d 17 1e 23       	call   0x231e:0x179d
    230e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2311:	26 ff b5 dc 00       	push   WORD PTR es:[di+0xdc]
    2316:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    2319:	06                   	push   es
    231a:	57                   	push   di
    231b:	9a e1 17 69 24       	call   0x2469:0x17e1
    2320:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2323:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2326:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2329:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    232e:	06                   	push   es
    232f:	57                   	push   di
    2330:	9a 2b 0c 5c 23       	call   0x235c:0xc2b
    2335:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2338:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    233b:	74 03                	je     0x2340
    233d:	e9 d4 fe             	jmp    0x2214
    2340:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2343:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    2349:	7c 20                	jl     0x236b
    234b:	6a 01                	push   0x1
    234d:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    2352:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2357:	06                   	push   es
    2358:	57                   	push   di
    2359:	9a d0 0d a2 23       	call   0x23a2:0xdd0
    235e:	89 c7                	mov    di,ax
    2360:	8e c2                	mov    es,dx
    2362:	06                   	push   es
    2363:	57                   	push   di
    2364:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2367:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    236b:	c9                   	leave
    236c:	ca 08 00             	retf   0x8
    236f:	c8 04 00 00          	enter  0x4,0x0
    2373:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2376:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    237b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    237f:	48                   	dec    ax
    2380:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2383:	31 c0                	xor    ax,ax
    2385:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2388:	7f 2e                	jg     0x23b8
    238a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    238d:	eb 03                	jmp    0x2392
    238f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2392:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2395:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2398:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    239d:	06                   	push   es
    239e:	57                   	push   di
    239f:	9a d0 0d ae 23       	call   0x23ae:0xdd0
    23a4:	52                   	push   dx
    23a5:	50                   	push   ax
    23a6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    23a9:	06                   	push   es
    23aa:	57                   	push   di
    23ab:	9a 2a 43 38 24       	call   0x2438:0x432a
    23b0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    23b3:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    23b6:	75 d7                	jne    0x238f
    23b8:	c9                   	leave
    23b9:	ca 08 00             	retf   0x8
    23bc:	55                   	push   bp
    23bd:	89 e5                	mov    bp,sp
    23bf:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23c2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c8:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    23cd:	06                   	push   es
    23ce:	57                   	push   di
    23cf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23d2:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    23d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d9:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    23de:	06                   	push   es
    23df:	57                   	push   di
    23e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23e3:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    23e7:	09 c0                	or     ax,ax
    23e9:	7e 0c                	jle    0x23f7
    23eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ee:	31 c0                	xor    ax,ax
    23f0:	26 89 85 ee 00       	mov    WORD PTR es:[di+0xee],ax
    23f5:	eb 0a                	jmp    0x2401
    23f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23fa:	26 c7 85 ee 00 ff ff 	mov    WORD PTR es:[di+0xee],0xffff
    2401:	c9                   	leave
    2402:	ca 08 00             	retf   0x8
    2405:	c8 04 00 00          	enter  0x4,0x0
    2409:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    240c:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2411:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2415:	48                   	dec    ax
    2416:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2419:	31 c0                	xor    ax,ax
    241b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    241e:	7f 3b                	jg     0x245b
    2420:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2423:	eb 03                	jmp    0x2428
    2425:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2428:	ff 76 fe             	push   WORD PTR [bp-0x2]
    242b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    242e:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2433:	06                   	push   es
    2434:	57                   	push   di
    2435:	9a d0 0d 3f 25       	call   0x253f:0xdd0
    243a:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    243d:	75 14                	jne    0x2453
    243f:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    2442:	75 0f                	jne    0x2453
    2444:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2447:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    244a:	06                   	push   es
    244b:	57                   	push   di
    244c:	9a 6f 24 72 26       	call   0x2672:0x246f
    2451:	eb 18                	jmp    0x246b
    2453:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2456:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2459:	75 ca                	jne    0x2425
    245b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    245e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2461:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2464:	06                   	push   es
    2465:	57                   	push   di
    2466:	9a ae 5f 19 25       	call   0x2519:0x5fae
    246b:	c9                   	leave
    246c:	ca 08 00             	retf   0x8
    246f:	c8 0a 00 00          	enter  0xa,0x0
    2473:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2476:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    247b:	74 0b                	je     0x2488
    247d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2480:	26 89 85 ee 00       	mov    WORD PTR es:[di+0xee],ax
    2485:	e9 17 02             	jmp    0x269f
    2488:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    248b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    248e:	26 3b 85 ee 00       	cmp    ax,WORD PTR es:[di+0xee]
    2493:	75 03                	jne    0x2498
    2495:	e9 07 02             	jmp    0x269f
    2498:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    249c:	7d 03                	jge    0x24a1
    249e:	e9 fe 01             	jmp    0x269f
    24a1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    24a4:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    24a9:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    24ad:	7c 03                	jl     0x24b2
    24af:	e9 ed 01             	jmp    0x269f
    24b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24b5:	26 8b 85 08 01       	mov    ax,WORD PTR es:[di+0x108]
    24ba:	09 c0                	or     ax,ax
    24bc:	74 2d                	je     0x24eb
    24be:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    24c2:	ff 76 08             	push   WORD PTR [bp+0x8]
    24c5:	ff 76 06             	push   WORD PTR [bp+0x6]
    24c8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    24cb:	8d 7e ff             	lea    di,[bp-0x1]
    24ce:	16                   	push   ss
    24cf:	57                   	push   di
    24d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24d3:	26 ff b5 0c 01       	push   WORD PTR es:[di+0x10c]
    24d8:	26 ff b5 0a 01       	push   WORD PTR es:[di+0x10a]
    24dd:	26 ff 9d 06 01       	call   DWORD PTR es:[di+0x106]
    24e2:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    24e6:	75 03                	jne    0x24eb
    24e8:	e9 b4 01             	jmp    0x269f
    24eb:	ff 76 08             	push   WORD PTR [bp+0x8]
    24ee:	ff 76 06             	push   WORD PTR [bp+0x6]
    24f1:	9a a8 17 2d 25       	call   0x252d:0x17a8
    24f6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    24f9:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    24fc:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    24ff:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    2502:	74 2b                	je     0x252f
    2504:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2507:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    250c:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    2511:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2514:	06                   	push   es
    2515:	57                   	push   di
    2516:	9a 0e 37 50 25       	call   0x2550:0x370e
    251b:	08 c0                	or     al,al
    251d:	74 10                	je     0x252f
    251f:	ff 76 08             	push   WORD PTR [bp+0x8]
    2522:	ff 76 06             	push   WORD PTR [bp+0x6]
    2525:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2528:	06                   	push   es
    2529:	57                   	push   di
    252a:	9a d0 3f 66 28       	call   0x2866:0x3fd0
    252f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2532:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2535:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    253a:	06                   	push   es
    253b:	57                   	push   di
    253c:	9a d0 0d 97 25       	call   0x2597:0xdd0
    2541:	89 c7                	mov    di,ax
    2543:	8e c2                	mov    es,dx
    2545:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    2548:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    254b:	06                   	push   es
    254c:	57                   	push   di
    254d:	9a 1c 20 5c 25       	call   0x255c:0x201c
    2552:	6a 01                	push   0x1
    2554:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2557:	06                   	push   es
    2558:	57                   	push   di
    2559:	9a 77 1c 68 25       	call   0x2568:0x1c77
    255e:	6a 01                	push   0x1
    2560:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2563:	06                   	push   es
    2564:	57                   	push   di
    2565:	9a b8 1c aa 25       	call   0x25aa:0x1cb8
    256a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    256d:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    2573:	7c 43                	jl     0x25b8
    2575:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    257a:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    257f:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    2583:	7d 33                	jge    0x25b8
    2585:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2588:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    258d:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2592:	06                   	push   es
    2593:	57                   	push   di
    2594:	9a d0 0d f5 25       	call   0x25f5:0xdd0
    2599:	89 c7                	mov    di,ax
    259b:	8e c2                	mov    es,dx
    259d:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    25a0:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    25a3:	6a 00                	push   0x0
    25a5:	06                   	push   es
    25a6:	57                   	push   di
    25a7:	9a 77 1c b6 25       	call   0x25b6:0x1c77
    25ac:	6a 00                	push   0x0
    25ae:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    25b1:	06                   	push   es
    25b2:	57                   	push   di
    25b3:	9a b8 1c c0 25       	call   0x25c0:0x1cb8
    25b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25bb:	06                   	push   es
    25bc:	57                   	push   di
    25bd:	9a fa 64 d4 25       	call   0x25d4:0x64fa
    25c2:	08 c0                	or     al,al
    25c4:	74 57                	je     0x261d
    25c6:	9a ff ff 00 00       	call   0x0:0xffff
    25cb:	50                   	push   ax
    25cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25cf:	06                   	push   es
    25d0:	57                   	push   di
    25d1:	9a b9 62 68 26       	call   0x2668:0x62b9
    25d6:	5a                   	pop    dx
    25d7:	3b c2                	cmp    ax,dx
    25d9:	75 42                	jne    0x261d
    25db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25de:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    25e4:	7c 1b                	jl     0x2601
    25e6:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    25eb:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    25f0:	06                   	push   es
    25f1:	57                   	push   di
    25f2:	9a d0 0d 11 26       	call   0x2611:0xdd0
    25f7:	89 c7                	mov    di,ax
    25f9:	8e c2                	mov    es,dx
    25fb:	26 c6 85 90 00 00    	mov    BYTE PTR es:[di+0x90],0x0
    2601:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2604:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2607:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    260c:	06                   	push   es
    260d:	57                   	push   di
    260e:	9a d0 0d 51 26       	call   0x2651:0xdd0
    2613:	89 c7                	mov    di,ax
    2615:	8e c2                	mov    es,dx
    2617:	26 c6 85 90 00 01    	mov    BYTE PTR es:[di+0x90],0x1
    261d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2620:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2623:	99                   	cwd
    2624:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    2629:	8b c8                	mov    cx,ax
    262b:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    2630:	99                   	cwd
    2631:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    2636:	3b c1                	cmp    ax,cx
    2638:	74 3c                	je     0x2676
    263a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    263d:	26 89 85 ee 00       	mov    WORD PTR es:[di+0xee],ax
    2642:	6a 01                	push   0x1
    2644:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2647:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    264c:	06                   	push   es
    264d:	57                   	push   di
    264e:	9a d0 0d 90 26       	call   0x2690:0xdd0
    2653:	89 c7                	mov    di,ax
    2655:	8e c2                	mov    es,dx
    2657:	06                   	push   es
    2658:	57                   	push   di
    2659:	26 c4 3d             	les    di,DWORD PTR es:[di]
    265c:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    2660:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2663:	06                   	push   es
    2664:	57                   	push   di
    2665:	9a f9 36 61 28       	call   0x2861:0x36f9
    266a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    266d:	06                   	push   es
    266e:	57                   	push   di
    266f:	9a 9e 29 c5 26       	call   0x26c5:0x299e
    2674:	eb 29                	jmp    0x269f
    2676:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2679:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    267c:	26 89 85 ee 00       	mov    WORD PTR es:[di+0xee],ax
    2681:	6a 01                	push   0x1
    2683:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2686:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    268b:	06                   	push   es
    268c:	57                   	push   di
    268d:	9a d0 0d 54 27       	call   0x2754:0xdd0
    2692:	89 c7                	mov    di,ax
    2694:	8e c2                	mov    es,dx
    2696:	06                   	push   es
    2697:	57                   	push   di
    2698:	26 c4 3d             	les    di,DWORD PTR es:[di]
    269b:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    269f:	c9                   	leave
    26a0:	ca 06 00             	retf   0x6
    26a3:	55                   	push   bp
    26a4:	89 e5                	mov    bp,sp
    26a6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    26a9:	06                   	push   es
    26aa:	57                   	push   di
    26ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ae:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    26b3:	06                   	push   es
    26b4:	57                   	push   di
    26b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26b8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    26bc:	50                   	push   ax
    26bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c0:	06                   	push   es
    26c1:	57                   	push   di
    26c2:	9a 6f 24 91 28       	call   0x2891:0x246f
    26c7:	c9                   	leave
    26c8:	ca 08 00             	retf   0x8
    26cb:	c8 00 01 00          	enter  0x100,0x0
    26cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26d2:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    26d7:	06                   	push   es
    26d8:	57                   	push   di
    26d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26dc:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    26e0:	09 c0                	or     ax,ax
    26e2:	7e 36                	jle    0x271a
    26e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e7:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    26ed:	7c 2b                	jl     0x271a
    26ef:	8d be 00 ff          	lea    di,[bp-0x100]
    26f3:	16                   	push   ss
    26f4:	57                   	push   di
    26f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26f8:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    26fd:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    2702:	06                   	push   es
    2703:	57                   	push   di
    2704:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2707:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    270b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    270e:	06                   	push   es
    270f:	57                   	push   di
    2710:	68 ff 00             	push   0xff
    2713:	9a e7 17 9e 28       	call   0x289e:0x17e7
    2718:	eb 07                	jmp    0x2721
    271a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    271d:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    2721:	c9                   	leave
    2722:	ca 04 00             	retf   0x4
    2725:	55                   	push   bp
    2726:	89 e5                	mov    bp,sp
    2728:	ff 76 0c             	push   WORD PTR [bp+0xc]
    272b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    272e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2731:	06                   	push   es
    2732:	57                   	push   di
    2733:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2736:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    273a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    273d:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    2743:	7c 3c                	jl     0x2781
    2745:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    274a:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    274f:	06                   	push   es
    2750:	57                   	push   di
    2751:	9a d0 0d 72 27       	call   0x2772:0xdd0
    2756:	89 c7                	mov    di,ax
    2758:	8e c2                	mov    es,dx
    275a:	26 c6 85 90 00 01    	mov    BYTE PTR es:[di+0x90],0x1
    2760:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2763:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    2768:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    276d:	06                   	push   es
    276e:	57                   	push   di
    276f:	9a d0 0d b4 27       	call   0x27b4:0xdd0
    2774:	89 c7                	mov    di,ax
    2776:	8e c2                	mov    es,dx
    2778:	06                   	push   es
    2779:	57                   	push   di
    277a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    277d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2781:	c9                   	leave
    2782:	ca 08 00             	retf   0x8
    2785:	55                   	push   bp
    2786:	89 e5                	mov    bp,sp
    2788:	ff 76 0c             	push   WORD PTR [bp+0xc]
    278b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    278e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2791:	06                   	push   es
    2792:	57                   	push   di
    2793:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2796:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    279a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    279d:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    27a3:	7c 3c                	jl     0x27e1
    27a5:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    27aa:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    27af:	06                   	push   es
    27b0:	57                   	push   di
    27b1:	9a d0 0d d2 27       	call   0x27d2:0xdd0
    27b6:	89 c7                	mov    di,ax
    27b8:	8e c2                	mov    es,dx
    27ba:	26 c6 85 90 00 00    	mov    BYTE PTR es:[di+0x90],0x0
    27c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c3:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    27c8:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    27cd:	06                   	push   es
    27ce:	57                   	push   di
    27cf:	9a d0 0d 56 28       	call   0x2856:0xdd0
    27d4:	89 c7                	mov    di,ax
    27d6:	8e c2                	mov    es,dx
    27d8:	06                   	push   es
    27d9:	57                   	push   di
    27da:	26 c4 3d             	les    di,DWORD PTR es:[di]
    27dd:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    27e1:	c9                   	leave
    27e2:	ca 08 00             	retf   0x8
    27e5:	55                   	push   bp
    27e6:	89 e5                	mov    bp,sp
    27e8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    27eb:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    27f1:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    27f7:	c9                   	leave
    27f8:	ca 08 00             	retf   0x8
    27fb:	c8 08 01 00          	enter  0x108,0x0
    27ff:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2802:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2805:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2808:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    280b:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    2810:	26 0b 85 e0 00       	or     ax,WORD PTR es:[di+0xe0]
    2815:	75 03                	jne    0x281a
    2817:	e9 a2 00             	jmp    0x28bc
    281a:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    281f:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2823:	48                   	dec    ax
    2824:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2827:	31 c0                	xor    ax,ax
    2829:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    282c:	7e 03                	jle    0x2831
    282e:	e9 8b 00             	jmp    0x28bc
    2831:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2834:	eb 03                	jmp    0x2839
    2836:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2839:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    283c:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2840:	8d be f8 fe          	lea    di,[bp-0x108]
    2844:	16                   	push   ss
    2845:	57                   	push   di
    2846:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2849:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284c:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2851:	06                   	push   es
    2852:	57                   	push   di
    2853:	9a d0 0d 7c 2c       	call   0x2c7c:0xdd0
    2858:	89 c7                	mov    di,ax
    285a:	8e c2                	mov    es,dx
    285c:	06                   	push   es
    285d:	57                   	push   di
    285e:	9a 53 1d 80 28       	call   0x2880:0x1d53
    2863:	9a 3f 17 ff ff       	call   0xffff:0x173f
    2868:	08 c0                	or     al,al
    286a:	74 45                	je     0x28b1
    286c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    286f:	06                   	push   es
    2870:	57                   	push   di
    2871:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2874:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    2878:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    287b:	06                   	push   es
    287c:	57                   	push   di
    287d:	9a 58 62 ca 28       	call   0x28ca:0x6258
    2882:	08 c0                	or     al,al
    2884:	74 1a                	je     0x28a0
    2886:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2889:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    288c:	06                   	push   es
    288d:	57                   	push   di
    288e:	9a 6f 24 01 29       	call   0x2901:0x246f
    2893:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2896:	06                   	push   es
    2897:	57                   	push   di
    2898:	b8 ee ff             	mov    ax,0xffee
    289b:	9a 6a 20 21 29       	call   0x2921:0x206a
    28a0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    28a3:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    28a9:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    28af:	eb 1b                	jmp    0x28cc
    28b1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    28b4:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    28b7:	74 03                	je     0x28bc
    28b9:	e9 7a ff             	jmp    0x2836
    28bc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28bf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    28c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28c5:	06                   	push   es
    28c6:	57                   	push   di
    28c7:	9a 26 56 8c 29       	call   0x298c:0x5626
    28cc:	c9                   	leave
    28cd:	ca 08 00             	retf   0x8
    28d0:	55                   	push   bp
    28d1:	89 e5                	mov    bp,sp
    28d3:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    28d6:	26 8b 05             	mov    ax,WORD PTR es:[di]
    28d9:	3d 27 00             	cmp    ax,0x27
    28dc:	74 05                	je     0x28e3
    28de:	3d 28 00             	cmp    ax,0x28
    28e1:	75 42                	jne    0x2925
    28e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28e6:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    28eb:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    28ef:	48                   	dec    ax
    28f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28f3:	26 3b 85 ee 00       	cmp    ax,WORD PTR es:[di+0xee]
    28f8:	7f 0b                	jg     0x2905
    28fa:	6a 00                	push   0x0
    28fc:	06                   	push   es
    28fd:	57                   	push   di
    28fe:	9a 6f 24 14 29       	call   0x2914:0x246f
    2903:	eb 11                	jmp    0x2916
    2905:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2908:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    290d:	40                   	inc    ax
    290e:	50                   	push   ax
    290f:	06                   	push   es
    2910:	57                   	push   di
    2911:	9a 6f 24 46 29       	call   0x2946:0x246f
    2916:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2919:	06                   	push   es
    291a:	57                   	push   di
    291b:	b8 ee ff             	mov    ax,0xffee
    291e:	9a 6a 20 6d 29       	call   0x296d:0x206a
    2923:	eb 4a                	jmp    0x296f
    2925:	3d 25 00             	cmp    ax,0x25
    2928:	74 05                	je     0x292f
    292a:	3d 26 00             	cmp    ax,0x26
    292d:	75 40                	jne    0x296f
    292f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2932:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    2938:	7e 10                	jle    0x294a
    293a:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    293f:	48                   	dec    ax
    2940:	50                   	push   ax
    2941:	06                   	push   es
    2942:	57                   	push   di
    2943:	9a 6f 24 60 29       	call   0x2960:0x246f
    2948:	eb 18                	jmp    0x2962
    294a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    294d:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2952:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2956:	48                   	dec    ax
    2957:	50                   	push   ax
    2958:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    295b:	06                   	push   es
    295c:	57                   	push   di
    295d:	9a 6f 24 92 2e       	call   0x2e92:0x246f
    2962:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2965:	06                   	push   es
    2966:	57                   	push   di
    2967:	b8 ee ff             	mov    ax,0xffee
    296a:	9a 6a 20 bd 29       	call   0x29bd:0x206a
    296f:	c9                   	leave
    2970:	ca 0a 00             	retf   0xa
    2973:	55                   	push   bp
    2974:	89 e5                	mov    bp,sp
    2976:	83 7e 0a 03          	cmp    WORD PTR [bp+0xa],0x3
    297a:	7c 1e                	jl     0x299a
    297c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    297f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2982:	26 89 85 f8 00       	mov    WORD PTR es:[di+0xf8],ax
    2987:	06                   	push   es
    2988:	57                   	push   di
    2989:	9a f9 36 88 2e       	call   0x2e88:0x36f9
    298e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2991:	06                   	push   es
    2992:	57                   	push   di
    2993:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2996:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    299a:	c9                   	leave
    299b:	ca 06 00             	retf   0x6
    299e:	c8 22 00 00          	enter  0x22,0x0
    29a2:	8d 7e de             	lea    di,[bp-0x22]
    29a5:	16                   	push   ss
    29a6:	57                   	push   di
    29a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29aa:	06                   	push   es
    29ab:	57                   	push   di
    29ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    29af:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    29b3:	8d 7e f8             	lea    di,[bp-0x8]
    29b6:	16                   	push   ss
    29b7:	57                   	push   di
    29b8:	6a 08                	push   0x8
    29ba:	9a 1b 16 f1 2e       	call   0x2ef1:0x161b
    29bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c2:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    29c7:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    29cb:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    29ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29d1:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    29d6:	99                   	cwd
    29d7:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    29dc:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    29df:	26 83 bd fa 00 01    	cmp    WORD PTR es:[di+0xfa],0x1
    29e5:	7f 03                	jg     0x29ea
    29e7:	e9 46 02             	jmp    0x2c30
    29ea:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    29ef:	48                   	dec    ax
    29f0:	c1 e0 03             	shl    ax,0x3
    29f3:	8b d0                	mov    dx,ax
    29f5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    29f8:	2b c2                	sub    ax,dx
    29fa:	48                   	dec    ax
    29fb:	48                   	dec    ax
    29fc:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    29ff:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2a04:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2a08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a0b:	99                   	cwd
    2a0c:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    2a11:	92                   	xchg   dx,ax
    2a12:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    2a15:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    2a1a:	48                   	dec    ax
    2a1b:	3d 01 00             	cmp    ax,0x1
    2a1e:	7d 03                	jge    0x2a23
    2a20:	e9 0d 02             	jmp    0x2c30
    2a23:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    2a26:	eb 03                	jmp    0x2a2b
    2a28:	ff 4e e6             	dec    WORD PTR [bp-0x1a]
    2a2b:	8b 46 e6             	mov    ax,WORD PTR [bp-0x1a]
    2a2e:	48                   	dec    ax
    2a2f:	c1 e0 03             	shl    ax,0x3
    2a32:	8b d0                	mov    dx,ax
    2a34:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2a37:	2b c2                	sub    ax,dx
    2a39:	48                   	dec    ax
    2a3a:	48                   	dec    ax
    2a3b:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2a3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a41:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    2a46:	99                   	cwd
    2a47:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    2a4c:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    2a4f:	75 1f                	jne    0x2a70
    2a51:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    2a56:	2b 46 e6             	sub    ax,WORD PTR [bp-0x1a]
    2a59:	c1 e0 03             	shl    ax,0x3
    2a5c:	8b c8                	mov    cx,ax
    2a5e:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    2a61:	26 f7 a5 fc 00       	mul    WORD PTR es:[di+0xfc]
    2a66:	05 04 00             	add    ax,0x4
    2a69:	03 c1                	add    ax,cx
    2a6b:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    2a6e:	eb 06                	jmp    0x2a76
    2a70:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    2a73:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    2a76:	8b 46 e6             	mov    ax,WORD PTR [bp-0x1a]
    2a79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a7c:	26 f7 a5 dc 00       	mul    WORD PTR es:[di+0xdc]
    2a81:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    2a84:	05 04 00             	add    ax,0x4
    2a87:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2a8a:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    2a8f:	2b 46 e6             	sub    ax,WORD PTR [bp-0x1a]
    2a92:	c1 e0 03             	shl    ax,0x3
    2a95:	8b d0                	mov    dx,ax
    2a97:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a9a:	2b c2                	sub    ax,dx
    2a9c:	2d 06 00             	sub    ax,0x6
    2a9f:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2aa2:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2aa7:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    2aaa:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    2aad:	6a 00                	push   0x0
    2aaf:	6a 00                	push   0x0
    2ab1:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2ab5:	06                   	push   es
    2ab6:	57                   	push   di
    2ab7:	9a da 13 ca 2a       	call   0x2aca:0x13da
    2abc:	ff 76 ea             	push   WORD PTR [bp-0x16]
    2abf:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2ac2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2ac5:	06                   	push   es
    2ac6:	57                   	push   di
    2ac7:	9a b8 1d da 2a       	call   0x2ada:0x1db8
    2acc:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2acf:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2ad2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2ad5:	06                   	push   es
    2ad6:	57                   	push   di
    2ad7:	9a 7b 1d ea 2a       	call   0x2aea:0x1d7b
    2adc:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2adf:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2ae2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2ae5:	06                   	push   es
    2ae6:	57                   	push   di
    2ae7:	9a 7b 1d fa 2a       	call   0x2afa:0x1d7b
    2aec:	ff 76 ec             	push   WORD PTR [bp-0x14]
    2aef:	ff 76 f0             	push   WORD PTR [bp-0x10]
    2af2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2af5:	06                   	push   es
    2af6:	57                   	push   di
    2af7:	9a 7b 1d 36 2b       	call   0x2b36:0x1d7b
    2afc:	83 7e e8 00          	cmp    WORD PTR [bp-0x18],0x0
    2b00:	7e 70                	jle    0x2b72
    2b02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b05:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    2b0a:	99                   	cwd
    2b0b:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    2b10:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    2b13:	74 11                	je     0x2b26
    2b15:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    2b1a:	99                   	cwd
    2b1b:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    2b20:	40                   	inc    ax
    2b21:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    2b24:	75 4c                	jne    0x2b72
    2b26:	6a ff                	push   0xffff
    2b28:	6a eb                	push   0xffeb
    2b2a:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2b2d:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2b31:	06                   	push   es
    2b32:	57                   	push   di
    2b33:	9a da 13 48 2b       	call   0x2b48:0x13da
    2b38:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
    2b3b:	48                   	dec    ax
    2b3c:	50                   	push   ax
    2b3d:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2b40:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2b43:	06                   	push   es
    2b44:	57                   	push   di
    2b45:	9a b8 1d 5a 2b       	call   0x2b5a:0x1db8
    2b4a:	ff 76 ea             	push   WORD PTR [bp-0x16]
    2b4d:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2b50:	40                   	inc    ax
    2b51:	50                   	push   ax
    2b52:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2b55:	06                   	push   es
    2b56:	57                   	push   di
    2b57:	9a 7b 1d 6e 2b       	call   0x2b6e:0x1d7b
    2b5c:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2b5f:	48                   	dec    ax
    2b60:	50                   	push   ax
    2b61:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2b64:	40                   	inc    ax
    2b65:	50                   	push   ax
    2b66:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2b69:	06                   	push   es
    2b6a:	57                   	push   di
    2b6b:	9a 7b 1d 82 2b       	call   0x2b82:0x1d7b
    2b70:	eb 65                	jmp    0x2bd7
    2b72:	6a ff                	push   0xffff
    2b74:	6a f0                	push   0xfff0
    2b76:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2b79:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2b7d:	06                   	push   es
    2b7e:	57                   	push   di
    2b7f:	9a da 13 97 2b       	call   0x2b97:0x13da
    2b84:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2b87:	2d 08 00             	sub    ax,0x8
    2b8a:	40                   	inc    ax
    2b8b:	50                   	push   ax
    2b8c:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2b8f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2b92:	06                   	push   es
    2b93:	57                   	push   di
    2b94:	9a b8 1d aa 2b       	call   0x2baa:0x1db8
    2b99:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2b9c:	48                   	dec    ax
    2b9d:	48                   	dec    ax
    2b9e:	50                   	push   ax
    2b9f:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2ba2:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2ba5:	06                   	push   es
    2ba6:	57                   	push   di
    2ba7:	9a 7b 1d bf 2b       	call   0x2bbf:0x1d7b
    2bac:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2baf:	48                   	dec    ax
    2bb0:	48                   	dec    ax
    2bb1:	50                   	push   ax
    2bb2:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2bb5:	40                   	inc    ax
    2bb6:	50                   	push   ax
    2bb7:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2bba:	06                   	push   es
    2bbb:	57                   	push   di
    2bbc:	9a 7b 1d d5 2b       	call   0x2bd5:0x1d7b
    2bc1:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2bc4:	2d 08 00             	sub    ax,0x8
    2bc7:	50                   	push   ax
    2bc8:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    2bcb:	40                   	inc    ax
    2bcc:	50                   	push   ax
    2bcd:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2bd0:	06                   	push   es
    2bd1:	57                   	push   di
    2bd2:	9a 7b 1d e7 2b       	call   0x2be7:0x1d7b
    2bd7:	6a ff                	push   0xffff
    2bd9:	6a ef                	push   0xffef
    2bdb:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2bde:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2be2:	06                   	push   es
    2be3:	57                   	push   di
    2be4:	9a da 13 f9 2b       	call   0x2bf9:0x13da
    2be9:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2bec:	48                   	dec    ax
    2bed:	50                   	push   ax
    2bee:	ff 76 ee             	push   WORD PTR [bp-0x12]
    2bf1:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2bf4:	06                   	push   es
    2bf5:	57                   	push   di
    2bf6:	9a b8 1d 0d 2c       	call   0x2c0d:0x1db8
    2bfb:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2bfe:	48                   	dec    ax
    2bff:	50                   	push   ax
    2c00:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2c03:	48                   	dec    ax
    2c04:	50                   	push   ax
    2c05:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2c08:	06                   	push   es
    2c09:	57                   	push   di
    2c0a:	9a 7b 1d 1f 2c       	call   0x2c1f:0x1d7b
    2c0f:	ff 76 ec             	push   WORD PTR [bp-0x14]
    2c12:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    2c15:	48                   	dec    ax
    2c16:	50                   	push   ax
    2c17:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2c1a:	06                   	push   es
    2c1b:	57                   	push   di
    2c1c:	9a 7b 1d c3 2c       	call   0x2cc3:0x1d7b
    2c21:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2c24:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2c27:	83 7e e6 01          	cmp    WORD PTR [bp-0x1a],0x1
    2c2b:	74 03                	je     0x2c30
    2c2d:	e9 f8 fd             	jmp    0x2a28
    2c30:	83 46 f8 02          	add    WORD PTR [bp-0x8],0x2
    2c34:	83 6e fe 02          	sub    WORD PTR [bp-0x2],0x2
    2c38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c3b:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    2c40:	48                   	dec    ax
    2c41:	c1 e0 03             	shl    ax,0x3
    2c44:	8b d0                	mov    dx,ax
    2c46:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2c49:	2b c2                	sub    ax,dx
    2c4b:	48                   	dec    ax
    2c4c:	48                   	dec    ax
    2c4d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2c50:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    2c55:	26 f7 a5 dc 00       	mul    WORD PTR es:[di+0xdc]
    2c5a:	05 04 00             	add    ax,0x4
    2c5d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2c60:	31 c0                	xor    ax,ax
    2c62:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2c65:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    2c6b:	7c 3b                	jl     0x2ca8
    2c6d:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    2c72:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2c77:	06                   	push   es
    2c78:	57                   	push   di
    2c79:	9a d0 0d 98 2c       	call   0x2c98:0xdd0
    2c7e:	89 c7                	mov    di,ax
    2c80:	8e c2                	mov    es,dx
    2c82:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    2c86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c89:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    2c8e:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2c93:	06                   	push   es
    2c94:	57                   	push   di
    2c95:	9a d0 0d e2 2e       	call   0x2ee2:0xdd0
    2c9a:	89 c7                	mov    di,ax
    2c9c:	8e c2                	mov    es,dx
    2c9e:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2ca2:	5a                   	pop    dx
    2ca3:	03 c2                	add    ax,dx
    2ca5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2ca8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cab:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2cb0:	89 7e e2             	mov    WORD PTR [bp-0x1e],di
    2cb3:	8c 46 e4             	mov    WORD PTR [bp-0x1c],es
    2cb6:	6a 00                	push   0x0
    2cb8:	6a 00                	push   0x0
    2cba:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2cbe:	06                   	push   es
    2cbf:	57                   	push   di
    2cc0:	9a da 13 d3 2c       	call   0x2cd3:0x13da
    2cc5:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2cc8:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2ccb:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2cce:	06                   	push   es
    2ccf:	57                   	push   di
    2cd0:	9a b8 1d e5 2c       	call   0x2ce5:0x1db8
    2cd5:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2cd8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2cdb:	48                   	dec    ax
    2cdc:	50                   	push   ax
    2cdd:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2ce0:	06                   	push   es
    2ce1:	57                   	push   di
    2ce2:	9a 7b 1d f9 2c       	call   0x2cf9:0x1d7b
    2ce7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2cea:	48                   	dec    ax
    2ceb:	50                   	push   ax
    2cec:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2cef:	48                   	dec    ax
    2cf0:	50                   	push   ax
    2cf1:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2cf4:	06                   	push   es
    2cf5:	57                   	push   di
    2cf6:	9a 7b 1d 0b 2d       	call   0x2d0b:0x1d7b
    2cfb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2cfe:	48                   	dec    ax
    2cff:	50                   	push   ax
    2d00:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2d03:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2d06:	06                   	push   es
    2d07:	57                   	push   di
    2d08:	9a 7b 1d 1b 2d       	call   0x2d1b:0x1d7b
    2d0d:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2d10:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2d13:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2d16:	06                   	push   es
    2d17:	57                   	push   di
    2d18:	9a 7b 1d 3b 2d       	call   0x2d3b:0x1d7b
    2d1d:	8d 7e f8             	lea    di,[bp-0x8]
    2d20:	16                   	push   ss
    2d21:	57                   	push   di
    2d22:	6a ff                	push   0xffff
    2d24:	6a ff                	push   0xffff
    2d26:	9a d5 2d 00 00       	call   0x0:0x2dd5
    2d2b:	6a ff                	push   0xffff
    2d2d:	6a ef                	push   0xffef
    2d2f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2d32:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2d36:	06                   	push   es
    2d37:	57                   	push   di
    2d38:	9a da 13 4d 2d       	call   0x2d4d:0x13da
    2d3d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2d40:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d43:	48                   	dec    ax
    2d44:	50                   	push   ax
    2d45:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2d48:	06                   	push   es
    2d49:	57                   	push   di
    2d4a:	9a b8 1d 61 2d       	call   0x2d61:0x1db8
    2d4f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d52:	48                   	dec    ax
    2d53:	50                   	push   ax
    2d54:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d57:	48                   	dec    ax
    2d58:	50                   	push   ax
    2d59:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2d5c:	06                   	push   es
    2d5d:	57                   	push   di
    2d5e:	9a 7b 1d 73 2d       	call   0x2d73:0x1d7b
    2d63:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d66:	48                   	dec    ax
    2d67:	50                   	push   ax
    2d68:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2d6b:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2d6e:	06                   	push   es
    2d6f:	57                   	push   di
    2d70:	9a 7b 1d 85 2d       	call   0x2d85:0x1d7b
    2d75:	6a ff                	push   0xffff
    2d77:	6a eb                	push   0xffeb
    2d79:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2d7c:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2d80:	06                   	push   es
    2d81:	57                   	push   di
    2d82:	9a da 13 95 2d       	call   0x2d95:0x13da
    2d87:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2d8a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2d8d:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2d90:	06                   	push   es
    2d91:	57                   	push   di
    2d92:	9a b8 1d a7 2d       	call   0x2da7:0x1db8
    2d97:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d9a:	48                   	dec    ax
    2d9b:	50                   	push   ax
    2d9c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2d9f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2da2:	06                   	push   es
    2da3:	57                   	push   di
    2da4:	9a 7b 1d b7 2d       	call   0x2db7:0x1d7b
    2da9:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2dac:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2daf:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2db2:	06                   	push   es
    2db3:	57                   	push   di
    2db4:	9a b8 1d c9 2d       	call   0x2dc9:0x1db8
    2db9:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2dbc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2dbf:	48                   	dec    ax
    2dc0:	50                   	push   ax
    2dc1:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2dc4:	06                   	push   es
    2dc5:	57                   	push   di
    2dc6:	9a 7b 1d e9 2d       	call   0x2de9:0x1d7b
    2dcb:	8d 7e f8             	lea    di,[bp-0x8]
    2dce:	16                   	push   ss
    2dcf:	57                   	push   di
    2dd0:	6a ff                	push   0xffff
    2dd2:	6a ff                	push   0xffff
    2dd4:	9a ff ff 00 00       	call   0x0:0xffff
    2dd9:	6a ff                	push   0xffff
    2ddb:	6a ef                	push   0xffef
    2ddd:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2de0:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2de4:	06                   	push   es
    2de5:	57                   	push   di
    2de6:	9a da 13 fb 2d       	call   0x2dfb:0x13da
    2deb:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2dee:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2df1:	48                   	dec    ax
    2df2:	50                   	push   ax
    2df3:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2df6:	06                   	push   es
    2df7:	57                   	push   di
    2df8:	9a b8 1d 0f 2e       	call   0x2e0f:0x1db8
    2dfd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2e00:	48                   	dec    ax
    2e01:	50                   	push   ax
    2e02:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e05:	48                   	dec    ax
    2e06:	50                   	push   ax
    2e07:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2e0a:	06                   	push   es
    2e0b:	57                   	push   di
    2e0c:	9a 7b 1d 21 2e       	call   0x2e21:0x1d7b
    2e11:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2e14:	48                   	dec    ax
    2e15:	50                   	push   ax
    2e16:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e19:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2e1c:	06                   	push   es
    2e1d:	57                   	push   di
    2e1e:	9a 7b 1d 33 2e       	call   0x2e33:0x1d7b
    2e23:	6a ff                	push   0xffff
    2e25:	6a eb                	push   0xffeb
    2e27:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2e2a:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2e2e:	06                   	push   es
    2e2f:	57                   	push   di
    2e30:	9a da 13 43 2e       	call   0x2e43:0x13da
    2e35:	ff 76 f2             	push   WORD PTR [bp-0xe]
    2e38:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e3b:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2e3e:	06                   	push   es
    2e3f:	57                   	push   di
    2e40:	9a b8 1d 55 2e       	call   0x2e55:0x1db8
    2e45:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2e48:	48                   	dec    ax
    2e49:	50                   	push   ax
    2e4a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e4d:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2e50:	06                   	push   es
    2e51:	57                   	push   di
    2e52:	9a 7b 1d 65 2e       	call   0x2e65:0x1d7b
    2e57:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2e5a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e5d:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2e60:	06                   	push   es
    2e61:	57                   	push   di
    2e62:	9a b8 1d 77 2e       	call   0x2e77:0x1db8
    2e67:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2e6a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e6d:	48                   	dec    ax
    2e6e:	50                   	push   ax
    2e6f:	c4 7e e2             	les    di,DWORD PTR [bp-0x1e]
    2e72:	06                   	push   es
    2e73:	57                   	push   di
    2e74:	9a 7b 1d 6b 2f       	call   0x2f6b:0x1d7b
    2e79:	c9                   	leave
    2e7a:	ca 04 00             	retf   0x4
    2e7d:	55                   	push   bp
    2e7e:	89 e5                	mov    bp,sp
    2e80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e83:	06                   	push   es
    2e84:	57                   	push   di
    2e85:	9a 77 6d fc 2e       	call   0x2efc:0x6d77
    2e8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e8d:	06                   	push   es
    2e8e:	57                   	push   di
    2e8f:	9a 9e 29 ea 2e       	call   0x2eea:0x299e
    2e94:	c9                   	leave
    2e95:	ca 04 00             	retf   0x4
    2e98:	c8 06 01 00          	enter  0x106,0x0
    2e9c:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    2ea1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea4:	26 8b 85 de 00       	mov    ax,WORD PTR es:[di+0xde]
    2ea9:	26 0b 85 e0 00       	or     ax,WORD PTR es:[di+0xe0]
    2eae:	74 6a                	je     0x2f1a
    2eb0:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2eb5:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2eb9:	48                   	dec    ax
    2eba:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2ebd:	31 c0                	xor    ax,ax
    2ebf:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    2ec2:	7f 56                	jg     0x2f1a
    2ec4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2ec7:	eb 03                	jmp    0x2ecc
    2ec9:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2ecc:	8d be fa fe          	lea    di,[bp-0x106]
    2ed0:	16                   	push   ss
    2ed1:	57                   	push   di
    2ed2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2ed5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed8:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    2edd:	06                   	push   es
    2ede:	57                   	push   di
    2edf:	9a d0 0d e0 2f       	call   0x2fe0:0xdd0
    2ee4:	52                   	push   dx
    2ee5:	50                   	push   ax
    2ee6:	bf 6b 00             	mov    di,0x6b
    2ee9:	b8 8f 2f             	mov    ax,0x2f8f
    2eec:	50                   	push   ax
    2eed:	57                   	push   di
    2eee:	9a 73 22 06 2f       	call   0x2f06:0x2273
    2ef3:	89 c7                	mov    di,ax
    2ef5:	8e c2                	mov    es,dx
    2ef7:	06                   	push   es
    2ef8:	57                   	push   di
    2ef9:	9a 53 1d a3 2f       	call   0x2fa3:0x1d53
    2efe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2f01:	06                   	push   es
    2f02:	57                   	push   di
    2f03:	9a be 18 ff ff       	call   0xffff:0x18be
    2f08:	75 08                	jne    0x2f12
    2f0a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f0d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2f10:	eb 08                	jmp    0x2f1a
    2f12:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f15:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    2f18:	75 af                	jne    0x2ec9
    2f1a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f1d:	c9                   	leave
    2f1e:	ca 08 00             	retf   0x8
    2f21:	55                   	push   bp
    2f22:	89 e5                	mov    bp,sp
    2f24:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2f27:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2f2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f2d:	26 c4 bd f0 00       	les    di,DWORD PTR es:[di+0xf0]
    2f32:	06                   	push   es
    2f33:	57                   	push   di
    2f34:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f37:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2f3b:	c9                   	leave
    2f3c:	ca 08 00             	retf   0x8
    2f3f:	c8 38 00 00          	enter  0x38,0x0
    2f43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f46:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    2f4b:	26 ff b5 f0 00       	push   WORD PTR es:[di+0xf0]
    2f50:	26 c4 bd f4 00       	les    di,DWORD PTR es:[di+0xf4]
    2f55:	06                   	push   es
    2f56:	57                   	push   di
    2f57:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f5a:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2f5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f61:	26 c4 bd f4 00       	les    di,DWORD PTR es:[di+0xf4]
    2f66:	06                   	push   es
    2f67:	57                   	push   di
    2f68:	9a 1a 12 7d 2f       	call   0x2f7d:0x121a
    2f6d:	0c 01                	or     al,0x1
    2f6f:	50                   	push   ax
    2f70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f73:	26 c4 bd f4 00       	les    di,DWORD PTR es:[di+0xf4]
    2f78:	06                   	push   es
    2f79:	57                   	push   di
    2f7a:	9a 33 12 21 30       	call   0x3021:0x1233
    2f7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f82:	26 8b 85 dc 00       	mov    ax,WORD PTR es:[di+0xdc]
    2f87:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2f8a:	06                   	push   es
    2f8b:	57                   	push   di
    2f8c:	9a 07 30 fa 32       	call   0x32fa:0x3007
    2f91:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f97:	26 3b 85 dc 00       	cmp    ax,WORD PTR es:[di+0xdc]
    2f9c:	74 07                	je     0x2fa5
    2f9e:	06                   	push   es
    2f9f:	57                   	push   di
    2fa0:	9a f9 36 eb 2f       	call   0x2feb:0x36f9
    2fa5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa8:	26 8b 85 e2 00       	mov    ax,WORD PTR es:[di+0xe2]
    2fad:	26 0b 85 e4 00       	or     ax,WORD PTR es:[di+0xe4]
    2fb2:	74 41                	je     0x2ff5
    2fb4:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2fb9:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2fbd:	48                   	dec    ax
    2fbe:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    2fc1:	31 c0                	xor    ax,ax
    2fc3:	3b 46 c8             	cmp    ax,WORD PTR [bp-0x38]
    2fc6:	7f 2d                	jg     0x2ff5
    2fc8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2fcb:	eb 03                	jmp    0x2fd0
    2fcd:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2fd0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2fd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd6:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    2fdb:	06                   	push   es
    2fdc:	57                   	push   di
    2fdd:	9a d0 0d 08 31       	call   0x3108:0xdd0
    2fe2:	89 c7                	mov    di,ax
    2fe4:	8e c2                	mov    es,dx
    2fe6:	06                   	push   es
    2fe7:	57                   	push   di
    2fe8:	9a c6 22 19 31       	call   0x3119:0x22c6
    2fed:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ff0:	3b 46 c8             	cmp    ax,WORD PTR [bp-0x38]
    2ff3:	75 d8                	jne    0x2fcd
    2ff5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ff8:	06                   	push   es
    2ff9:	57                   	push   di
    2ffa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ffd:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3001:	c9                   	leave
    3002:	ca 08 00             	retf   0x8
    3005:	01 30                	add    WORD PTR [bx+si],si
    3007:	55                   	push   bp
    3008:	89 e5                	mov    bp,sp
    300a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    300d:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    3012:	26 ff b5 f0 00       	push   WORD PTR es:[di+0xf0]
    3017:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    301c:	06                   	push   es
    301d:	57                   	push   di
    301e:	9a 99 20 35 30       	call   0x3035:0x2099
    3023:	bf 05 30             	mov    di,0x3005
    3026:	0e                   	push   cs
    3027:	57                   	push   di
    3028:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    302b:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3030:	06                   	push   es
    3031:	57                   	push   di
    3032:	9a 4e 20 ff ff       	call   0xffff:0x204e
    3037:	05 06 00             	add    ax,0x6
    303a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    303d:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
    3042:	c9                   	leave
    3043:	ca 04 00             	retf   0x4
    3046:	c8 18 00 00          	enter  0x18,0x0
    304a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    304d:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    3052:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3056:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3059:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    305c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    305f:	99                   	cwd
    3060:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    3065:	26 89 85 fa 00       	mov    WORD PTR es:[di+0xfa],ax
    306a:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    306f:	26 f7 a5 f8 00       	mul    WORD PTR es:[di+0xf8]
    3074:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    3077:	7d 05                	jge    0x307e
    3079:	26 ff 85 fa 00       	inc    WORD PTR es:[di+0xfa]
    307e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3081:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3084:	40                   	inc    ax
    3085:	40                   	inc    ax
    3086:	05 03 00             	add    ax,0x3
    3089:	26 89 05             	mov    WORD PTR es:[di],ax
    308c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    308f:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    3094:	48                   	dec    ax
    3095:	c1 e0 03             	shl    ax,0x3
    3098:	8b d0                	mov    dx,ax
    309a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    309d:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    30a1:	2b c2                	sub    ax,dx
    30a3:	48                   	dec    ax
    30a4:	48                   	dec    ax
    30a5:	2d 03 00             	sub    ax,0x3
    30a8:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    30ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30af:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    30b4:	26 f7 a5 dc 00       	mul    WORD PTR es:[di+0xdc]
    30b9:	8b d0                	mov    dx,ax
    30bb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    30be:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    30c2:	05 04 00             	add    ax,0x4
    30c5:	05 03 00             	add    ax,0x3
    30c8:	03 c2                	add    ax,dx
    30ca:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    30ce:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    30d2:	48                   	dec    ax
    30d3:	48                   	dec    ax
    30d4:	2d 03 00             	sub    ax,0x3
    30d7:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    30db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30de:	26 83 bd ee 00 00    	cmp    WORD PTR es:[di+0xee],0x0
    30e4:	7c 35                	jl     0x311b
    30e6:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    30eb:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    30f0:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    30f4:	7d 25                	jge    0x311b
    30f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30f9:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    30fe:	26 c4 bd de 00       	les    di,DWORD PTR es:[di+0xde]
    3103:	06                   	push   es
    3104:	57                   	push   di
    3105:	9a d0 0d 6d 32       	call   0x326d:0xdd0
    310a:	52                   	push   dx
    310b:	50                   	push   ax
    310c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    310f:	06                   	push   es
    3110:	57                   	push   di
    3111:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3114:	06                   	push   es
    3115:	57                   	push   di
    3116:	9a c2 35 c4 32       	call   0x32c4:0x35c2
    311b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    311e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    3122:	26 2b 05             	sub    ax,WORD PTR es:[di]
    3125:	99                   	cwd
    3126:	31 d0                	xor    ax,dx
    3128:	29 d0                	sub    ax,dx
    312a:	05 06 00             	add    ax,0x6
    312d:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3130:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3133:	26 c4 bd ea 00       	les    di,DWORD PTR es:[di+0xea]
    3138:	06                   	push   es
    3139:	57                   	push   di
    313a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    313d:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3141:	3d 01 00             	cmp    ax,0x1
    3144:	7d 03                	jge    0x3149
    3146:	e9 63 01             	jmp    0x32ac
    3149:	31 c0                	xor    ax,ax
    314b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    314e:	31 c0                	xor    ax,ax
    3150:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3153:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    3156:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3159:	99                   	cwd
    315a:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    315f:	26 89 85 fc 00       	mov    WORD PTR es:[di+0xfc],ax
    3164:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    3167:	99                   	cwd
    3168:	b9 03 00             	mov    cx,0x3
    316b:	f7 f9                	idiv   cx
    316d:	26 3b 85 fc 00       	cmp    ax,WORD PTR es:[di+0xfc]
    3172:	7d 0e                	jge    0x3182
    3174:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    3177:	99                   	cwd
    3178:	b9 03 00             	mov    cx,0x3
    317b:	f7 f9                	idiv   cx
    317d:	26 89 85 fc 00       	mov    WORD PTR es:[di+0xfc],ax
    3182:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3185:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    318a:	99                   	cwd
    318b:	26 f7 bd f8 00       	idiv   WORD PTR es:[di+0xf8]
    3190:	26 f7 a5 f8 00       	mul    WORD PTR es:[di+0xf8]
    3195:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3198:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    319c:	7d 05                	jge    0x31a3
    319e:	31 c0                	xor    ax,ax
    31a0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    31a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31a6:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    31ab:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    31af:	48                   	dec    ax
    31b0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    31b3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    31b6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    31b9:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    31bc:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    31bf:	7e 03                	jle    0x31c4
    31c1:	e9 e8 00             	jmp    0x32ac
    31c4:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    31c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31ca:	26 3b 85 f8 00       	cmp    ax,WORD PTR es:[di+0xf8]
    31cf:	75 08                	jne    0x31d9
    31d1:	31 c0                	xor    ax,ax
    31d3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    31d6:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    31d9:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    31dc:	c1 e0 03             	shl    ax,0x3
    31df:	8b c8                	mov    cx,ax
    31e1:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    31e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e7:	26 f7 a5 fc 00       	mul    WORD PTR es:[di+0xfc]
    31ec:	03 c1                	add    ax,cx
    31ee:	40                   	inc    ax
    31ef:	40                   	inc    ax
    31f0:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    31f3:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    31f8:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    31fb:	48                   	dec    ax
    31fc:	26 f7 a5 dc 00       	mul    WORD PTR es:[di+0xdc]
    3201:	05 04 00             	add    ax,0x4
    3204:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    3207:	26 8b 85 dc 00       	mov    ax,WORD PTR es:[di+0xdc]
    320c:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    320f:	26 8b 85 fc 00       	mov    ax,WORD PTR es:[di+0xfc]
    3214:	40                   	inc    ax
    3215:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    3218:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    321c:	75 09                	jne    0x3227
    321e:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    3221:	05 03 00             	add    ax,0x3
    3224:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3227:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    322a:	26 8b 85 f8 00       	mov    ax,WORD PTR es:[di+0xf8]
    322f:	48                   	dec    ax
    3230:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3233:	75 1c                	jne    0x3251
    3235:	26 8b 85 fa 00       	mov    ax,WORD PTR es:[di+0xfa]
    323a:	48                   	dec    ax
    323b:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    323e:	c1 e0 03             	shl    ax,0x3
    3241:	8b d0                	mov    dx,ax
    3243:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3247:	48                   	dec    ax
    3248:	48                   	dec    ax
    3249:	2b c2                	sub    ax,dx
    324b:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    324e:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    3251:	ff 76 ee             	push   WORD PTR [bp-0x12]
    3254:	ff 76 f0             	push   WORD PTR [bp-0x10]
    3257:	ff 76 ea             	push   WORD PTR [bp-0x16]
    325a:	ff 76 ec             	push   WORD PTR [bp-0x14]
    325d:	ff 76 f2             	push   WORD PTR [bp-0xe]
    3260:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3263:	26 c4 bd e2 00       	les    di,DWORD PTR es:[di+0xe2]
    3268:	06                   	push   es
    3269:	57                   	push   di
    326a:	9a d0 0d 18 33       	call   0x3318:0xdd0
    326f:	89 c7                	mov    di,ax
    3271:	8e c2                	mov    es,dx
    3273:	06                   	push   es
    3274:	57                   	push   di
    3275:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3278:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    327c:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    327f:	ff 46 f2             	inc    WORD PTR [bp-0xe]
    3282:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3285:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3288:	7e 1f                	jle    0x32a9
    328a:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    328e:	7e 19                	jle    0x32a9
    3290:	31 c0                	xor    ax,ax
    3292:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3295:	31 c0                	xor    ax,ax
    3297:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    329a:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    329d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    32a0:	48                   	dec    ax
    32a1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    32a4:	31 c0                	xor    ax,ax
    32a6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    32a9:	e9 0d ff             	jmp    0x31b9
    32ac:	c9                   	leave
    32ad:	ca 0c 00             	retf   0xc
    32b0:	55                   	push   bp
    32b1:	89 e5                	mov    bp,sp
    32b3:	68 64 0f             	push   0xf64
    32b6:	6a 00                	push   0x0
    32b8:	6a 00                	push   0x0
    32ba:	6a 00                	push   0x0
    32bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32bf:	06                   	push   es
    32c0:	57                   	push   di
    32c1:	9a bb 24 ff ff       	call   0xffff:0x24bb
    32c6:	c9                   	leave
    32c7:	ca 08 00             	retf   0x8
    32ca:	55                   	push   bp
    32cb:	89 e5                	mov    bp,sp
    32cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32d0:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    32d5:	09 c0                	or     ax,ax
    32d7:	74 15                	je     0x32ee
    32d9:	ff 76 08             	push   WORD PTR [bp+0x8]
    32dc:	ff 76 06             	push   WORD PTR [bp+0x6]
    32df:	26 ff b5 04 01       	push   WORD PTR es:[di+0x104]
    32e4:	26 ff b5 02 01       	push   WORD PTR es:[di+0x102]
    32e9:	26 ff 9d fe 00       	call   DWORD PTR es:[di+0xfe]
    32ee:	c9                   	leave
    32ef:	ca 04 00             	retf   0x4
    32f2:	c8 08 00 00          	enter  0x8,0x0
    32f6:	b8 6b 00             	mov    ax,0x6b
    32f9:	ba 06 33             	mov    dx,0x3306
    32fc:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    32ff:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3302:	b8 c5 05             	mov    ax,0x5c5
    3305:	ba ff ff             	mov    dx,0xffff
    3308:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    330b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    330e:	8d 7e f8             	lea    di,[bp-0x8]
    3311:	16                   	push   ss
    3312:	57                   	push   di
    3313:	6a 01                	push   0x1
    3315:	9a 5a 09 ff ff       	call   0xffff:0x95a
    331a:	c9                   	leave
    331b:	cb                   	retf
