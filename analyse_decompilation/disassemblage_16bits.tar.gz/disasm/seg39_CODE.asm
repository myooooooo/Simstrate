; ================================================================
; seg39_CODE  (8908 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	27                   	daa
	...
       9:	00 22                	add    BYTE PTR [bp+si],ah
       b:	00 0c                	add    BYTE PTR [si],cl
       d:	00 2e 00 c9          	add    BYTE PTR ds:0xc900,ch
      11:	04 64                	add    al,0x64
      13:	20 8e 00 9a          	and    BYTE PTR [bp-0x6600],cl
      17:	1f                   	pop    ds
      18:	14 00                	adc    al,0x0
      1a:	cb                   	retf
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	c4 29                	les    bp,DWORD PTR [bx+di]
      20:	10 00                	adc    BYTE PTR [bx+si],al
      22:	0a 45 4d             	or     al,BYTE PTR [di+0x4d]
      25:	65 6e                	outs   dx,BYTE PTR gs:[si]
      27:	75 45                	jne    0x6e
      29:	72 72                	jb     0x9d
      2b:	6f                   	outs   dx,WORD PTR ds:[si]
      2c:	72 03                	jb     0x31
      2e:	0a 54 4d             	or     dl,BYTE PTR [si+0x4d]
      31:	65 6e                	outs   dx,BYTE PTR gs:[si]
      33:	75 42                	jne    0x77
      35:	72 65                	jb     0x9c
      37:	61                   	popa
      38:	6b 00 00             	imul   ax,WORD PTR [bx+si],0x0
      3b:	00 00                	add    BYTE PTR [bx+si],al
      3d:	00 02                	add    BYTE PTR [bp+si],al
      3f:	00 00                	add    BYTE PTR [bx+si],al
      41:	00 2d                	add    BYTE PTR [di],ch
      43:	00 9a 00 06          	add    BYTE PTR [bp+si+0x600],bl
      47:	6d                   	ins    WORD PTR es:[di],dx
      48:	62 4e 6f             	bound  cx,DWORD PTR [bp+0x6f]
      4b:	6e                   	outs   dx,BYTE PTR ds:[si]
      4c:	65 07                	gs pop es
      4e:	6d                   	ins    WORD PTR es:[di],dx
      4f:	62 42 72             	bound  ax,DWORD PTR [bp+si+0x72]
      52:	65 61                	gs popa
      54:	6b 0a 6d             	imul   cx,WORD PTR [bp+si],0x6d
      57:	62 42 61             	bound  ax,DWORD PTR [bp+si+0x61]
      5a:	72 42                	jb     0x9e
      5c:	72 65                	jb     0xc3
      5e:	61                   	popa
      5f:	6b 01 09             	imul   ax,WORD PTR [bx+di],0x9
      62:	54                   	push   sp
      63:	53                   	push   bx
      64:	68 6f 72             	push   0x726f
      67:	74 43                	je     0xac
      69:	75 74                	jne    0xdf
      6b:	03 00                	add    ax,WORD PTR [bx+si]
      6d:	00 00                	add    BYTE PTR [bx+si],al
      6f:	00 ff                	add    bh,bh
      71:	ff 00                	inc    WORD PTR [bx+si]
      73:	00 da                	add    dl,bl
      75:	00 00                	add    BYTE PTR [bx+si],al
      77:	00 00                	add    BYTE PTR [bx+si],al
      79:	00 d2                	add    dl,dl
      7b:	00 c8                	add    al,cl
      7d:	00 4d 00             	add    BYTE PTR [di+0x0],cl
      80:	da 05                	fiadd  DWORD PTR [di]
      82:	eb 00                	jmp    0x84
      84:	64 20 17             	and    BYTE PTR fs:[bx],dl
      87:	01 9a 1f 86          	add    WORD PTR [bp+si-0x79e1],bx
      8b:	00 cb                	add    bl,cl
      8d:	1f                   	pop    ds
      8e:	8a 00                	mov    al,BYTE PTR [bx+si]
      90:	0e                   	push   cs
      91:	0c c6                	or     al,0xc6
      93:	00 cd                	add    ch,cl
      95:	11 9e 00 12          	adc    WORD PTR [bp+0x1200],bx
      99:	11 a2 00 fa          	adc    WORD PTR [bp+si-0x600],sp
      9d:	10 82 00 7e          	adc    BYTE PTR [bp+si+0x7e00],al
      a1:	11 ae 00 f4          	adc    WORD PTR [bp-0xc00],bp
      a5:	4f                   	dec    di
      a6:	aa                   	stos   BYTE PTR es:[di],al
      a7:	00 05                	add    BYTE PTR [di],al
      a9:	4f                   	dec    di
      aa:	b2 00                	mov    dl,0x0
      ac:	8d 11                	lea    dx,[bx+di]
      ae:	ba 00 46             	mov    dx,0x4600
      b1:	51                   	push   cx
      b2:	b6 00                	mov    dh,0x0
      b4:	38 50 be             	cmp    BYTE PTR [bx+si-0x42],dl
      b7:	00 c2                	add    dl,al
      b9:	13 c2                	adc    ax,dx
      bb:	00 21                	add    BYTE PTR [bx+di],ah
      bd:	50                   	push   ax
      be:	96                   	xchg   si,ax
      bf:	00 9b 0b 92          	add    BYTE PTR [bp+di-0x6df5],bl
      c3:	00 00                	add    BYTE PTR [bx+si],al
      c5:	16                   	push   ss
      c6:	d8 00                	fadd   DWORD PTR [bx+si]
      c8:	09 54 4d             	or     WORD PTR [si+0x4d],dx
      cb:	65 6e                	outs   dx,BYTE PTR gs:[si]
      cd:	75 49                	jne    0x118
      cf:	74 65                	je     0x136
      d1:	6d                   	ins    WORD PTR es:[di],dx
      d2:	01 00                	add    WORD PTR [bx+si],ax
      d4:	ff                   	(bad)
      d5:	ff d1                	call   cx
      d7:	16                   	push   ss
      d8:	e7 00                	out    0x0,ax
      da:	07                   	pop    es
      db:	09 54 4d             	or     WORD PTR [si+0x4d],dx
      de:	65 6e                	outs   dx,BYTE PTR gs:[si]
      e0:	75 49                	jne    0x12b
      e2:	74 65                	je     0x149
      e4:	6d                   	ins    WORD PTR es:[di],dx
      e5:	94                   	xchg   sp,ax
      e6:	00 f9                	add    cl,bh
      e8:	00 15                	add    BYTE PTR [di],dl
      ea:	06                   	push   es
      eb:	9a 01 0c 00 05       	call   0x500:0xc01
      f0:	4d                   	dec    bp
      f1:	65 6e                	outs   dx,BYTE PTR gs:[si]
      f3:	75 73                	jne    0x168
      f5:	0a 00                	or     al,BYTE PTR [bx+si]
      f7:	2d 00 01             	sub    ax,0x100
      fa:	01 1a                	add    WORD PTR [bp+si],bx
      fc:	00 ff                	add    bh,bh
      fe:	ff 11                	call   WORD PTR [bx+di]
     100:	12 1b                	adc    bl,BYTE PTR [bp+di]
     102:	01 01                	add    WORD PTR [bx+di],ax
     104:	00 00                	add    BYTE PTR [bx+si],al
     106:	00 00                	add    BYTE PTR [bx+si],al
     108:	80 00 00             	add    BYTE PTR [bx+si],0x0
     10b:	00 00                	add    BYTE PTR [bx+si],al
     10d:	02 00                	add    al,BYTE PTR [bx+si]
     10f:	05 42 72             	add    ax,0x7242
     112:	65 61                	gs popa
     114:	6b 62 23 37          	imul   sp,WORD PTR [bp+si+0x23],0x37
     118:	01 61 11             	add    WORD PTR [bx+di+0x11],sp
     11b:	1f                   	pop    ds
     11c:	01 37                	add    WORD PTR [bx],si
     11e:	12 3f                	adc    bh,BYTE PTR [bx]
     120:	01 01                	add    WORD PTR [bx+di],ax
     122:	00 00                	add    BYTE PTR [bx+si],al
     124:	00 00                	add    BYTE PTR [bx+si],al
     126:	80 00 00             	add    BYTE PTR [bx+si],0x0
     129:	00 80 03 00          	add    BYTE PTR [bx+si+0x3],al
     12d:	07                   	pop    es
     12e:	43                   	inc    bx
     12f:	61                   	popa
     130:	70 74                	jo     0x1a6
     132:	69 6f 6e 07 23       	imul   bp,WORD PTR [bx+0x6e],0x2307
     137:	57                   	push   di
     138:	01 1f                	add    WORD PTR [bx],bx
     13a:	00 ff                	add    bh,bh
     13c:	ff 75 12             	push   WORD PTR [di+0x12]
     13f:	5f                   	pop    di
     140:	01 01                	add    WORD PTR [bx+di],ax
     142:	00 00                	add    BYTE PTR [bx+si],al
     144:	00 00                	add    BYTE PTR [bx+si],al
     146:	80 00 00             	add    BYTE PTR [bx+si],0x0
     149:	00 00                	add    BYTE PTR [bx+si],al
     14b:	04 00                	add    al,0x0
     14d:	07                   	pop    es
     14e:	43                   	inc    bx
     14f:	68 65 63             	push   0x6365
     152:	6b 65 64 07          	imul   sp,WORD PTR [di+0x64],0x7
     156:	23 77 01             	and    si,WORD PTR [bx+0x1]
     159:	20 00                	and    BYTE PTR [bx+si],al
     15b:	ff                   	(bad)
     15c:	ff 9b 12 7f          	call   DWORD PTR [bp+di+0x7f12]
     160:	01 01                	add    WORD PTR [bx+di],ax
     162:	00 00                	add    BYTE PTR [bx+si],al
     164:	00 00                	add    BYTE PTR [bx+si],al
     166:	80 01 00             	add    BYTE PTR [bx+di],0x0
     169:	00 00                	add    BYTE PTR [bx+si],al
     16b:	05 00 07             	add    ax,0x700
     16e:	45                   	inc    bp
     16f:	6e                   	outs   dx,BYTE PTR ds:[si]
     170:	61                   	popa
     171:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     174:	64 c5 22             	lds    sp,DWORD PTR fs:[bp+si]
     177:	be 01 32             	mov    si,0x3201
     17a:	00 ff                	add    bh,bh
     17c:	ff                   	call   (bad)
     17d:	db 12                	fist   DWORD PTR [bp+si]
     17f:	c2 01 01             	ret    0x101
     182:	00 00                	add    BYTE PTR [bx+si],al
     184:	00 00                	add    BYTE PTR [bx+si],al
     186:	80 00 00             	add    BYTE PTR [bx+si],0x0
     189:	00 00                	add    BYTE PTR [bx+si],al
     18b:	06                   	push   es
     18c:	00 0a                	add    BYTE PTR [bp+si],cl
     18e:	47                   	inc    di
     18f:	72 6f                	jb     0x200
     191:	75 70                	jne    0x203
     193:	49                   	dec    cx
     194:	6e                   	outs   dx,BYTE PTR ds:[si]
     195:	64 65 78 5a          	fs gs js 0x1f3
     199:	00 1c                	add    BYTE PTR [si],bl
     19b:	02 23                	add    ah,BYTE PTR [bp+di]
     19d:	00 ff                	add    bh,bh
     19f:	ff 23                	jmp    WORD PTR [bp+di]
     1a1:	00 ff                	add    bh,bh
     1a3:	ff 01                	inc    WORD PTR [bx+di]
     1a5:	00 00                	add    BYTE PTR [bx+si],al
     1a7:	00 00                	add    BYTE PTR [bx+si],al
     1a9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1ac:	00 00                	add    BYTE PTR [bx+si],al
     1ae:	07                   	pop    es
     1af:	00 0b                	add    BYTE PTR [bp+di],cl
     1b1:	48                   	dec    ax
     1b2:	65 6c                	gs ins BYTE PTR es:[di],dx
     1b4:	70 43                	jo     0x1f9
     1b6:	6f                   	outs   dx,WORD PTR ds:[si]
     1b7:	6e                   	outs   dx,BYTE PTR ds:[si]
     1b8:	74 65                	je     0x21f
     1ba:	78 74                	js     0x230
     1bc:	62 23                	bound  sp,DWORD PTR [bp+di]
     1be:	fc                   	cld
     1bf:	01 e8                	add    ax,bp
     1c1:	10 c6                	adc    dh,al
     1c3:	01 c1                	add    cx,ax
     1c5:	12 db                	adc    bl,bl
     1c7:	01 01                	add    WORD PTR [bx+di],ax
     1c9:	00 00                	add    BYTE PTR [bx+si],al
     1cb:	00 00                	add    BYTE PTR [bx+si],al
     1cd:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1d0:	00 80 08 00          	add    BYTE PTR [bx+si+0x8],al
     1d4:	04 48                	add    al,0x48
     1d6:	69 6e 74 60 00       	imul   bp,WORD PTR [bp+0x74],0x60
     1db:	e3 01                	jcxz   0x1de
     1dd:	2f                   	das
     1de:	00 ff                	add    bh,bh
     1e0:	ff 88 13 04          	dec    WORD PTR [bx+si+0x413]
     1e4:	02 00                	add    al,BYTE PTR [bx+si]
     1e6:	00 00                	add    BYTE PTR [bx+si],al
     1e8:	00 00                	add    BYTE PTR [bx+si],al
     1ea:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1ed:	00 80 09 00          	add    BYTE PTR [bx+si+0x9],al
     1f1:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     1f4:	6f                   	outs   dx,WORD PTR ds:[si]
     1f5:	72 74                	jb     0x26b
     1f7:	43                   	inc    bx
     1f8:	75 74                	jne    0x26e
     1fa:	07                   	pop    es
     1fb:	23 54 02             	and    dx,WORD PTR [si+0x2]
     1fe:	31 00                	xor    WORD PTR [bx+si],ax
     200:	ff                   	(bad)
     201:	ff a5 13 8c          	jmp    WORD PTR [di-0x73ed]
     205:	02 01                	add    al,BYTE PTR [bx+di]
     207:	00 00                	add    BYTE PTR [bx+si],al
     209:	00 00                	add    BYTE PTR [bx+si],al
     20b:	80 01 00             	add    BYTE PTR [bx+di],0x0
     20e:	00 00                	add    BYTE PTR [bx+si],al
     210:	0a 00                	or     al,BYTE PTR [bx+si]
     212:	07                   	pop    es
     213:	56                   	push   si
     214:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     219:	65 71 00             	gs jno 0x21c
     21c:	60                   	pusha
     21d:	02 3b                	add    bh,BYTE PTR [bp+di]
     21f:	00 ff                	add    bh,bh
     221:	ff                   	(bad)
     222:	3b 00                	cmp    ax,WORD PTR [bx+si]
     224:	ff                   	(bad)
     225:	ff 01                	inc    WORD PTR [bx+di]
     227:	00 00                	add    BYTE PTR [bx+si],al
     229:	00 00                	add    BYTE PTR [bx+si],al
     22b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     22e:	00 80 0b 00          	add    BYTE PTR [bx+si+0xb],al
     232:	07                   	pop    es
     233:	4f                   	dec    di
     234:	6e                   	outs   dx,BYTE PTR ds:[si]
     235:	43                   	inc    bx
     236:	6c                   	ins    BYTE PTR es:[di],dx
     237:	69 63 6b 98 02       	imul   sp,WORD PTR [bp+di+0x6b],0x298
     23c:	00 00                	add    BYTE PTR [bx+si],al
     23e:	00 00                	add    BYTE PTR [bx+si],al
     240:	00 00                	add    BYTE PTR [bx+si],al
     242:	92                   	xchg   dx,ax
     243:	02 24                	add    ah,BYTE PTR [si]
     245:	00 da                	add    dl,bl
     247:	05 a5 02             	add    ax,0x2a5
     24a:	64 20 e9             	fs and cl,ch
     24d:	02 9a 1f 4c          	add    bl,BYTE PTR [bp+si+0x4c1f]
     251:	02 cb                	add    cl,bl
     253:	1f                   	pop    ds
     254:	50                   	push   ax
     255:	02 e3                	add    ah,bl
     257:	17                   	pop    ss
     258:	a1 02 cd             	mov    ax,ds:0xcd02
     25b:	11 64 02             	adc    WORD PTR [si+0x2],sp
     25e:	6e                   	outs   dx,BYTE PTR ds:[si]
     25f:	4f                   	dec    di
     260:	68 02 fa             	push   0xfa02
     263:	10 48 02             	adc    BYTE PTR [bx+si+0x2],cl
     266:	e5 4f                	in     ax,0x4f
     268:	6c                   	ins    BYTE PTR es:[di],dx
     269:	02 f4                	add    dh,ah
     26b:	4f                   	dec    di
     26c:	70 02                	jo     0x270
     26e:	05 4f 74             	add    ax,0x744f
     271:	02 03                	add    al,BYTE PTR [bp+di]
     273:	50                   	push   ax
     274:	78 02                	js     0x278
     276:	46                   	inc    si
     277:	51                   	push   cx
     278:	7c 02                	jl     0x27c
     27a:	38 50 84             	cmp    BYTE PTR [bx+si-0x7c],dl
     27d:	02 2c                	add    ch,BYTE PTR [si]
     27f:	18 88 02 21          	sbb    BYTE PTR [bx+si+0x2102],cl
     283:	50                   	push   ax
     284:	5c                   	pop    sp
     285:	02 63 17             	add    ah,BYTE PTR [bp+di+0x17]
     288:	58                   	pop    ax
     289:	02 8f 1d 90          	add    cl,BYTE PTR [bx-0x6fe3]
     28d:	02 10                	add    dl,BYTE PTR [bx+si]
     28f:	18 80 02 05          	sbb    BYTE PTR [bx+si+0x502],al
     293:	54                   	push   sp
     294:	4d                   	dec    bp
     295:	65 6e                	outs   dx,BYTE PTR gs:[si]
     297:	75 07                	jne    0x2a0
     299:	05 54 4d             	add    ax,0x4d54
     29c:	65 6e                	outs   dx,BYTE PTR gs:[si]
     29e:	75 5a                	jne    0x2fa
     2a0:	02 b3 02 15          	add    dh,BYTE PTR [bp+di+0x1502]
     2a4:	06                   	push   es
     2a5:	f5                   	cmc
     2a6:	02 03                	add    al,BYTE PTR [bp+di]
     2a8:	00 05                	add    BYTE PTR [di],al
     2aa:	4d                   	dec    bp
     2ab:	65 6e                	outs   dx,BYTE PTR gs:[si]
     2ad:	75 73                	jne    0x322
     2af:	01 00                	add    WORD PTR [bx+si],ax
     2b1:	da 00                	fiadd  DWORD PTR [bx+si]
     2b3:	21 03                	and    WORD PTR [bp+di],ax
     2b5:	1a 00                	sbb    al,BYTE PTR [bx+si]
     2b7:	ff                   	(bad)
     2b8:	ff 00                	inc    WORD PTR [bx+si]
     2ba:	00 00                	add    BYTE PTR [bx+si],al
     2bc:	00 01                	add    BYTE PTR [bx+di],al
     2be:	00 00                	add    BYTE PTR [bx+si],al
     2c0:	00 00                	add    BYTE PTR [bx+si],al
     2c2:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2c5:	00 80 02 00          	add    BYTE PTR [bx+si+0x2],al
     2c9:	05 49 74             	add    ax,0x7449
     2cc:	65 6d                	gs ins WORD PTR es:[di],dx
     2ce:	73 31                	jae    0x301
     2d0:	03 00                	add    ax,WORD PTR [bx+si]
     2d2:	00 00                	add    BYTE PTR [bx+si],al
     2d4:	00 00                	add    BYTE PTR [bx+si],al
     2d6:	00 27                	add    BYTE PTR [bx],ah
     2d8:	03 2c                	add    bp,WORD PTR [si]
     2da:	00 5a 02             	add    BYTE PTR [bp+si+0x2],bl
     2dd:	3e 03 64 20          	add    sp,WORD PTR ds:[si+0x20]
     2e1:	50                   	push   ax
     2e2:	03 9a 1f e1          	add    bx,WORD PTR [bp+si-0x1ee1]
     2e6:	02 cb                	add    cl,bl
     2e8:	1f                   	pop    ds
     2e9:	e5 02                	in     ax,0x2
     2eb:	e3 17                	jcxz   0x304
     2ed:	dd 02                	fld    QWORD PTR [bp+si]
     2ef:	cd 11                	int    0x11
     2f1:	f9                   	stc
     2f2:	02 6e 4f             	add    ch,BYTE PTR [bp+0x4f]
     2f5:	fd                   	std
     2f6:	02 fa                	add    bh,dl
     2f8:	10 cc                	adc    ah,cl
     2fa:	03 e5                	add    sp,bp
     2fc:	4f                   	dec    di
     2fd:	01 03                	add    WORD PTR [bp+di],ax
     2ff:	f4                   	hlt
     300:	4f                   	dec    di
     301:	05 03 05             	add    ax,0x503
     304:	4f                   	dec    di
     305:	09 03                	or     WORD PTR [bp+di],ax
     307:	03 50 0d             	add    dx,WORD PTR [bx+si+0xd]
     30a:	03 46 51             	add    ax,WORD PTR [bp+0x51]
     30d:	11 03                	adc    WORD PTR [bp+di],ax
     30f:	38 50 19             	cmp    BYTE PTR [bx+si+0x19],dl
     312:	03 2c                	add    bp,WORD PTR [si]
     314:	18 1d                	sbb    BYTE PTR [di],bl
     316:	03 21                	add    sp,WORD PTR [bx+di]
     318:	50                   	push   ax
     319:	f1                   	int1
     31a:	02 63 17             	add    ah,BYTE PTR [bp+di+0x17]
     31d:	ed                   	in     ax,dx
     31e:	02 c9                	add    cl,cl
     320:	1d 25 03             	sbb    ax,0x325
     323:	8f                   	(bad)
     324:	1e                   	push   ds
     325:	15 03 09             	adc    ax,0x903
     328:	54                   	push   sp
     329:	4d                   	dec    bp
     32a:	61                   	popa
     32b:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     330:	75 07                	jne    0x339
     332:	09 54 4d             	or     WORD PTR [si+0x4d],dx
     335:	61                   	popa
     336:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     33b:	75 ef                	jne    0x32c
     33d:	02 42 03             	add    al,BYTE PTR [bp+si+0x3]
     340:	98                   	cbw
     341:	02 58 03             	add    bl,BYTE PTR [bx+si+0x3]
     344:	04 00                	add    al,0x0
     346:	05 4d 65             	add    ax,0x654d
     349:	6e                   	outs   dx,BYTE PTR ds:[si]
     34a:	75 73                	jne    0x3bf
     34c:	01 00                	add    WORD PTR [bx+si],ax
     34e:	07                   	pop    es
     34f:	23 c0                	and    ax,ax
     351:	03 2a                	add    bp,WORD PTR [bp+si]
     353:	00 ff                	add    bh,bh
     355:	ff 96 1d 8c          	call   WORD PTR [bp-0x73e3]
     359:	03 01                	add    ax,WORD PTR [bx+di]
     35b:	00 00                	add    BYTE PTR [bx+si],al
     35d:	00 00                	add    BYTE PTR [bx+si],al
     35f:	80 00 00             	add    BYTE PTR [bx+si],0x0
     362:	00 00                	add    BYTE PTR [bx+si],al
     364:	03 00                	add    ax,WORD PTR [bx+si]
     366:	09 41 75             	or     WORD PTR [bx+di+0x75],ax
     369:	74 6f                	je     0x3da
     36b:	4d                   	dec    bp
     36c:	65 72 67             	gs jb  0x3d6
     36f:	65 03 0f             	add    cx,WORD PTR gs:[bx]
     372:	54                   	push   sp
     373:	50                   	push   ax
     374:	6f                   	outs   dx,WORD PTR ds:[si]
     375:	70 75                	jo     0x3ec
     377:	70 41                	jo     0x3ba
     379:	6c                   	ins    BYTE PTR es:[di],dx
     37a:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
     37f:	6e                   	outs   dx,BYTE PTR ds:[si]
     380:	74 00                	je     0x382
     382:	00 00                	add    BYTE PTR [bx+si],al
     384:	00 00                	add    BYTE PTR [bx+si],al
     386:	02 00                	add    al,BYTE PTR [bx+si]
     388:	00 00                	add    BYTE PTR [bx+si],al
     38a:	70 03                	jo     0x38f
     38c:	f4                   	hlt
     38d:	03 06 70 61          	add    ax,WORD PTR ds:0x6170
     391:	4c                   	dec    sp
     392:	65 66 74 07          	gs data32 je 0x39d
     396:	70 61                	jo     0x3f9
     398:	52                   	push   dx
     399:	69 67 68 74 08       	imul   sp,WORD PTR [bx+0x68],0x874
     39e:	70 61                	jo     0x401
     3a0:	43                   	inc    bx
     3a1:	65 6e                	outs   dx,BYTE PTR gs:[si]
     3a3:	74 65                	je     0x40a
     3a5:	72 0d                	jb     0x3b4
     3a7:	04 00                	add    al,0x0
     3a9:	00 00                	add    BYTE PTR [bx+si],al
     3ab:	00 00                	add    BYTE PTR [bx+si],al
     3ad:	00 02                	add    BYTE PTR [bp+si],al
     3af:	04 32                	add    al,0x32
     3b1:	00 5a 02             	add    BYTE PTR [bp+si+0x2],bl
     3b4:	1b 04                	sbb    ax,WORD PTR [si]
     3b6:	64 20 4f 04          	and    BYTE PTR fs:[bx+0x4],cl
     3ba:	9a 1f b8 03 cb       	call   0xcb03:0xb81f
     3bf:	1f                   	pop    ds
     3c0:	bc 03 98             	mov    sp,0x9803
     3c3:	21 00                	and    WORD PTR [bx+si],ax
     3c5:	04 cd                	add    al,0xcd
     3c7:	11 d0                	adc    ax,dx
     3c9:	03 6e 4f             	add    bp,WORD PTR [bp+0x4f]
     3cc:	d4 03                	aam    0x3
     3ce:	fa                   	cli
     3cf:	10 71 04             	adc    BYTE PTR [bx+di+0x4],dh
     3d2:	e5 4f                	in     ax,0x4f
     3d4:	d8 03                	fadd   DWORD PTR [bp+di]
     3d6:	f4                   	hlt
     3d7:	4f                   	dec    di
     3d8:	dc 03                	fadd   QWORD PTR [bp+di]
     3da:	05 4f e0             	add    ax,0xe04f
     3dd:	03 03                	add    ax,WORD PTR [bp+di]
     3df:	50                   	push   ax
     3e0:	e4 03                	in     al,0x3
     3e2:	46                   	inc    si
     3e3:	51                   	push   cx
     3e4:	e8 03 38             	call   0x3bea
     3e7:	50                   	push   ax
     3e8:	f0 03 2c             	lock add bp,WORD PTR [si]
     3eb:	18 b4 03 21          	sbb    BYTE PTR [si+0x2103],dh
     3ef:	50                   	push   ax
     3f0:	c8 03 38 21          	enter  0x3803,0x21
     3f4:	c4 03                	les    ax,DWORD PTR [bp+di]
     3f6:	8f                   	(bad)
     3f7:	1d fc 03             	sbb    ax,0x3fc
     3fa:	10 18                	adc    BYTE PTR [bx+si],bl
     3fc:	ec                   	in     al,dx
     3fd:	03 07                	add    ax,WORD PTR [bx]
     3ff:	22 f8                	and    bh,al
     401:	03 0a                	add    cx,WORD PTR [bp+si]
     403:	54                   	push   sp
     404:	50                   	push   ax
     405:	6f                   	outs   dx,WORD PTR ds:[si]
     406:	70 75                	jo     0x47d
     408:	70 4d                	jo     0x457
     40a:	65 6e                	outs   dx,BYTE PTR gs:[si]
     40c:	75 07                	jne    0x415
     40e:	0a 54 50             	or     dl,BYTE PTR [si+0x50]
     411:	6f                   	outs   dx,WORD PTR ds:[si]
     412:	70 75                	jo     0x489
     414:	70 4d                	jo     0x463
     416:	65 6e                	outs   dx,BYTE PTR gs:[si]
     418:	75 c6                	jne    0x3e0
     41a:	03 1f                	add    bx,WORD PTR [bx]
     41c:	04 98                	add    al,0x98
     41e:	02 2d                	add    ch,BYTE PTR [di]
     420:	04 07                	add    al,0x7
     422:	00 05                	add    BYTE PTR [di],al
     424:	4d                   	dec    bp
     425:	65 6e                	outs   dx,BYTE PTR gs:[si]
     427:	75 73                	jne    0x49c
     429:	04 00                	add    al,0x0
     42b:	70 03                	jo     0x430
     42d:	75 04                	jne    0x433
     42f:	24 00                	and    al,0x0
     431:	ff                   	(bad)
     432:	ff 24                	jmp    WORD PTR [si]
     434:	00 ff                	add    bh,bh
     436:	ff 01                	inc    WORD PTR [bx+di]
     438:	00 00                	add    BYTE PTR [bx+si],al
     43a:	00 00                	add    BYTE PTR [bx+si],al
     43c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     43f:	00 00                	add    BYTE PTR [bx+si],al
     441:	03 00                	add    ax,WORD PTR [bx+si]
     443:	09 41 6c             	or     WORD PTR [bx+di+0x6c],ax
     446:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
     44b:	6e                   	outs   dx,BYTE PTR ds:[si]
     44c:	74 07                	je     0x455
     44e:	23 d0                	and    dx,ax
     450:	04 25                	add    al,0x25
     452:	00 ff                	add    bh,bh
     454:	ff 25                	jmp    WORD PTR [di]
     456:	00 ff                	add    bh,bh
     458:	ff 01                	inc    WORD PTR [bx+di]
     45a:	00 00                	add    BYTE PTR [bx+si],al
     45c:	00 00                	add    BYTE PTR [bx+si],al
     45e:	80 01 00             	add    BYTE PTR [bx+di],0x0
     461:	00 00                	add    BYTE PTR [bx+si],al
     463:	04 00                	add    al,0x0
     465:	09 41 75             	or     WORD PTR [bx+di+0x75],ax
     468:	74 6f                	je     0x4d9
     46a:	50                   	push   ax
     46b:	6f                   	outs   dx,WORD PTR ds:[si]
     46c:	70 75                	jo     0x4e3
     46e:	70 5a                	jo     0x4ca
     470:	00 95 04 c8          	add    BYTE PTR [di-0x37fc],dl
     474:	21 79 04             	and    WORD PTR [bx+di+0x4],di
     477:	eb 21                	jmp    0x49a
     479:	c2 04 01             	ret    0x104
     47c:	00 00                	add    BYTE PTR [bx+si],al
     47e:	00 00                	add    BYTE PTR [bx+si],al
     480:	80 00 00             	add    BYTE PTR [bx+si],0x0
     483:	00 00                	add    BYTE PTR [bx+si],al
     485:	05 00 0b             	add    ax,0xb00
     488:	48                   	dec    ax
     489:	65 6c                	gs ins BYTE PTR es:[di],dx
     48b:	70 43                	jo     0x4d0
     48d:	6f                   	outs   dx,WORD PTR ds:[si]
     48e:	6e                   	outs   dx,BYTE PTR ds:[si]
     48f:	74 65                	je     0x4f6
     491:	78 74                	js     0x507
     493:	71 00                	jno    0x495
     495:	bd 0b 2a             	mov    bp,0x2a0b
     498:	00 ff                	add    bh,bh
     49a:	ff 2a                	jmp    DWORD PTR [bp+si]
     49c:	00 ff                	add    bh,bh
     49e:	ff 01                	inc    WORD PTR [bx+di]
     4a0:	00 00                	add    BYTE PTR [bx+si],al
     4a2:	00 00                	add    BYTE PTR [bx+si],al
     4a4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4a7:	00 80 06 00          	add    BYTE PTR [bx+si+0x6],al
     4ab:	07                   	pop    es
     4ac:	4f                   	dec    di
     4ad:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ae:	50                   	push   ax
     4af:	6f                   	outs   dx,WORD PTR ds:[si]
     4b0:	70 75                	jo     0x527
     4b2:	70 55                	jo     0x509
     4b4:	89 e5                	mov    bp,sp
     4b6:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     4b9:	06                   	push   es
     4ba:	57                   	push   di
     4bb:	b0 01                	mov    al,0x1
     4bd:	50                   	push   ax
     4be:	b8 22 00             	mov    ax,0x22
     4c1:	ba 98 08             	mov    dx,0x898
     4c4:	52                   	push   dx
     4c5:	50                   	push   ax
     4c6:	9a e6 28 e6 04       	call   0x4e6:0x28e6
     4cb:	52                   	push   dx
     4cc:	50                   	push   ax
     4cd:	9a 99 13 25 05       	call   0x525:0x1399
     4d2:	c9                   	leave
     4d3:	c2 04 00             	ret    0x4
     4d6:	c8 00 01 00          	enter  0x100,0x0
     4da:	8d be 00 ff          	lea    di,[bp-0x100]
     4de:	16                   	push   ss
     4df:	57                   	push   di
     4e0:	68 2f f0             	push   0xf02f
     4e3:	9a 2b 09 0f 05       	call   0x50f:0x92b
     4e8:	e8 c8 ff             	call   0x4b3
     4eb:	c9                   	leave
     4ec:	c3                   	ret
     4ed:	c8 02 01 00          	enter  0x102,0x0
     4f1:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     4f5:	eb 03                	jmp    0x4fa
     4f7:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
     4fa:	8d be fe fe          	lea    di,[bp-0x102]
     4fe:	16                   	push   ss
     4ff:	57                   	push   di
     500:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     503:	98                   	cbw
     504:	8b f8                	mov    di,ax
     506:	d1 e7                	shl    di,1
     508:	ff b5 0c 13          	push   WORD PTR [di+0x130c]
     50c:	9a 2b 09 3c 07       	call   0x73c:0x92b
     511:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     514:	98                   	cbw
     515:	8b f8                	mov    di,ax
     517:	c1 e7 03             	shl    di,0x3
     51a:	81 c7 74 2b          	add    di,0x2b74
     51e:	1e                   	push   ds
     51f:	57                   	push   di
     520:	6a 07                	push   0x7
     522:	9a e7 17 52 05       	call   0x552:0x17e7
     527:	80 7e ff 11          	cmp    BYTE PTR [bp-0x1],0x11
     52b:	75 ca                	jne    0x4f7
     52d:	c9                   	leave
     52e:	c3                   	ret
     52f:	c8 08 02 00          	enter  0x208,0x0
     533:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     536:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
     53a:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     53d:	25 00 20             	and    ax,0x2000
     540:	09 c0                	or     ax,ax
     542:	74 27                	je     0x56b
     544:	8d be fc fe          	lea    di,[bp-0x104]
     548:	16                   	push   ss
     549:	57                   	push   di
     54a:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     54d:	06                   	push   es
     54e:	57                   	push   di
     54f:	9a cd 17 5c 05       	call   0x55c:0x17cd
     554:	bf ec 2b             	mov    di,0x2bec
     557:	1e                   	push   ds
     558:	57                   	push   di
     559:	9a 4c 18 69 05       	call   0x569:0x184c
     55e:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     561:	06                   	push   es
     562:	57                   	push   di
     563:	68 ff 00             	push   0xff
     566:	9a e7 17 83 05       	call   0x583:0x17e7
     56b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     56e:	25 00 40             	and    ax,0x4000
     571:	09 c0                	or     ax,ax
     573:	74 27                	je     0x59c
     575:	8d be fc fe          	lea    di,[bp-0x104]
     579:	16                   	push   ss
     57a:	57                   	push   di
     57b:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     57e:	06                   	push   es
     57f:	57                   	push   di
     580:	9a cd 17 8d 05       	call   0x58d:0x17cd
     585:	bf f4 2b             	mov    di,0x2bf4
     588:	1e                   	push   ds
     589:	57                   	push   di
     58a:	9a 4c 18 9a 05       	call   0x59a:0x184c
     58f:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     592:	06                   	push   es
     593:	57                   	push   di
     594:	68 ff 00             	push   0xff
     597:	9a e7 17 b4 05       	call   0x5b4:0x17e7
     59c:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     59f:	25 00 80             	and    ax,0x8000
     5a2:	09 c0                	or     ax,ax
     5a4:	74 27                	je     0x5cd
     5a6:	8d be fc fe          	lea    di,[bp-0x104]
     5aa:	16                   	push   ss
     5ab:	57                   	push   di
     5ac:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     5af:	06                   	push   es
     5b0:	57                   	push   di
     5b1:	9a cd 17 be 05       	call   0x5be:0x17cd
     5b6:	bf fc 2b             	mov    di,0x2bfc
     5b9:	1e                   	push   ds
     5ba:	57                   	push   di
     5bb:	9a 4c 18 cb 05       	call   0x5cb:0x184c
     5c0:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     5c3:	06                   	push   es
     5c4:	57                   	push   di
     5c5:	68 ff 00             	push   0xff
     5c8:	9a e7 17 1a 06       	call   0x61a:0x17e7
     5cd:	31 c0                	xor    ax,ax
     5cf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     5d2:	eb 03                	jmp    0x5d7
     5d4:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     5d7:	6b 7e fe 07          	imul   di,WORD PTR [bp-0x2],0x7
     5db:	81 c7 54 13          	add    di,0x1354
     5df:	1e                   	push   ds
     5e0:	07                   	pop    es
     5e1:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     5e4:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     5e7:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     5ea:	26 3a 05             	cmp    al,BYTE PTR es:[di]
     5ed:	73 06                	jae    0x5f5
     5ef:	e9 70 01             	jmp    0x762
     5f2:	e9 5d 01             	jmp    0x752
     5f5:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     5f8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     5fb:	26 3a 45 01          	cmp    al,BYTE PTR es:[di+0x1]
     5ff:	76 03                	jbe    0x604
     601:	e9 4e 01             	jmp    0x752
     604:	26 8a 45 02          	mov    al,BYTE PTR es:[di+0x2]
     608:	3c 02                	cmp    al,0x2
     60a:	75 4c                	jne    0x658
     60c:	8d be f8 fe          	lea    di,[bp-0x108]
     610:	16                   	push   ss
     611:	57                   	push   di
     612:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     615:	06                   	push   es
     616:	57                   	push   di
     617:	9a cd 17 46 06       	call   0x646:0x17cd
     61c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     61f:	26 8a 05             	mov    al,BYTE PTR es:[di]
     622:	30 e4                	xor    ah,ah
     624:	8b c8                	mov    cx,ax
     626:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     629:	30 e4                	xor    ah,ah
     62b:	8b d0                	mov    dx,ax
     62d:	26 8a 45 03          	mov    al,BYTE PTR es:[di+0x3]
     631:	30 e4                	xor    ah,ah
     633:	03 c2                	add    ax,dx
     635:	2b c1                	sub    ax,cx
     637:	98                   	cbw
     638:	8b f8                	mov    di,ax
     63a:	c1 e7 03             	shl    di,0x3
     63d:	81 c7 74 2b          	add    di,0x2b74
     641:	1e                   	push   ds
     642:	57                   	push   di
     643:	9a 4c 18 53 06       	call   0x653:0x184c
     648:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     64b:	06                   	push   es
     64c:	57                   	push   di
     64d:	68 ff 00             	push   0xff
     650:	9a e7 17 6a 06       	call   0x66a:0x17e7
     655:	e9 f8 00             	jmp    0x750
     658:	3c 03                	cmp    al,0x3
     65a:	75 4b                	jne    0x6a7
     65c:	8d be f8 fe          	lea    di,[bp-0x108]
     660:	16                   	push   ss
     661:	57                   	push   di
     662:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     665:	06                   	push   es
     666:	57                   	push   di
     667:	9a cd 17 95 06       	call   0x695:0x17cd
     66c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     66f:	26 8a 05             	mov    al,BYTE PTR es:[di]
     672:	30 e4                	xor    ah,ah
     674:	8b c8                	mov    cx,ax
     676:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     679:	30 e4                	xor    ah,ah
     67b:	8b d0                	mov    dx,ax
     67d:	26 8a 45 03          	mov    al,BYTE PTR es:[di+0x3]
     681:	30 e4                	xor    ah,ah
     683:	03 c2                	add    ax,dx
     685:	2b c1                	sub    ax,cx
     687:	98                   	cbw
     688:	8b f8                	mov    di,ax
     68a:	d1 e7                	shl    di,1
     68c:	81 c7 34 13          	add    di,0x1334
     690:	1e                   	push   ds
     691:	57                   	push   di
     692:	9a 4c 18 a2 06       	call   0x6a2:0x184c
     697:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     69a:	06                   	push   es
     69b:	57                   	push   di
     69c:	68 ff 00             	push   0xff
     69f:	9a e7 17 b9 06       	call   0x6b9:0x17e7
     6a4:	e9 a9 00             	jmp    0x750
     6a7:	3c 01                	cmp    al,0x1
     6a9:	75 52                	jne    0x6fd
     6ab:	8d be f8 fe          	lea    di,[bp-0x108]
     6af:	16                   	push   ss
     6b0:	57                   	push   di
     6b1:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     6b4:	06                   	push   es
     6b5:	57                   	push   di
     6b6:	9a cd 17 c7 06       	call   0x6c7:0x17cd
     6bb:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     6be:	26 c4 7d 03          	les    di,DWORD PTR es:[di+0x3]
     6c2:	06                   	push   es
     6c3:	57                   	push   di
     6c4:	9a 4c 18 e7 06       	call   0x6e7:0x184c
     6c9:	8d be f8 fd          	lea    di,[bp-0x208]
     6cd:	16                   	push   ss
     6ce:	57                   	push   di
     6cf:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     6d2:	26 8a 05             	mov    al,BYTE PTR es:[di]
     6d5:	30 e4                	xor    ah,ah
     6d7:	8b d0                	mov    dx,ax
     6d9:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     6dc:	30 e4                	xor    ah,ah
     6de:	2b c2                	sub    ax,dx
     6e0:	05 41 00             	add    ax,0x41
     6e3:	50                   	push   ax
     6e4:	9a e9 18 ec 06       	call   0x6ec:0x18e9
     6e9:	9a 4c 18 f9 06       	call   0x6f9:0x184c
     6ee:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     6f1:	06                   	push   es
     6f2:	57                   	push   di
     6f3:	68 ff 00             	push   0xff
     6f6:	9a e7 17 0f 07       	call   0x70f:0x17e7
     6fb:	eb 53                	jmp    0x750
     6fd:	3c 00                	cmp    al,0x0
     6ff:	75 4f                	jne    0x750
     701:	8d be f8 fe          	lea    di,[bp-0x108]
     705:	16                   	push   ss
     706:	57                   	push   di
     707:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     70a:	06                   	push   es
     70b:	57                   	push   di
     70c:	9a cd 17 1d 07       	call   0x71d:0x17cd
     711:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     714:	26 c4 7d 03          	les    di,DWORD PTR es:[di+0x3]
     718:	06                   	push   es
     719:	57                   	push   di
     71a:	9a 4c 18 41 07       	call   0x741:0x184c
     71f:	8d be f8 fd          	lea    di,[bp-0x208]
     723:	16                   	push   ss
     724:	57                   	push   di
     725:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     728:	26 8a 05             	mov    al,BYTE PTR es:[di]
     72b:	30 e4                	xor    ah,ah
     72d:	8b d0                	mov    dx,ax
     72f:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     732:	30 e4                	xor    ah,ah
     734:	2b c2                	sub    ax,dx
     736:	99                   	cwd
     737:	52                   	push   dx
     738:	50                   	push   ax
     739:	9a a9 08 91 07       	call   0x791:0x8a9
     73e:	9a 4c 18 4e 07       	call   0x74e:0x184c
     743:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     746:	06                   	push   es
     747:	57                   	push   di
     748:	68 ff 00             	push   0xff
     74b:	9a e7 17 87 07       	call   0x787:0x17e7
     750:	eb 10                	jmp    0x762
     752:	83 7e fe 0c          	cmp    WORD PTR [bp-0x2],0xc
     756:	74 03                	je     0x75b
     758:	e9 79 fe             	jmp    0x5d4
     75b:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     75e:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
     762:	c9                   	leave
     763:	ca 02 00             	retf   0x2
     766:	c8 02 01 00          	enter  0x102,0x0
     76a:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     76e:	8d be fe fe          	lea    di,[bp-0x102]
     772:	16                   	push   ss
     773:	57                   	push   di
     774:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     777:	06                   	push   es
     778:	57                   	push   di
     779:	6a 01                	push   0x1
     77b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     77e:	26 8a 05             	mov    al,BYTE PTR es:[di]
     781:	30 e4                	xor    ah,ah
     783:	50                   	push   ax
     784:	9a 0b 18 ae 07       	call   0x7ae:0x180b
     789:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     78c:	06                   	push   es
     78d:	57                   	push   di
     78e:	9a 30 07 9d 08       	call   0x89d:0x730
     793:	09 c0                	or     ax,ax
     795:	75 19                	jne    0x7b0
     797:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     79b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     79e:	06                   	push   es
     79f:	57                   	push   di
     7a0:	6a 01                	push   0x1
     7a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7a5:	26 8a 05             	mov    al,BYTE PTR es:[di]
     7a8:	30 e4                	xor    ah,ah
     7aa:	50                   	push   ax
     7ab:	9a 75 19 dd 08       	call   0x8dd:0x1975
     7b0:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     7b3:	c9                   	leave
     7b4:	c2 0c 00             	ret    0xc
     7b7:	01 5e c8             	add    WORD PTR [bp-0x38],bx
     7ba:	08 02                	or     BYTE PTR [bp+si],al
     7bc:	00 8c d3 8e          	add    BYTE PTR [si-0x712d],cl
     7c0:	c3                   	ret
     7c1:	8c db                	mov    bx,ds
     7c3:	fc                   	cld
     7c4:	8d be fe fe          	lea    di,[bp-0x102]
     7c8:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     7cb:	ac                   	lods   al,BYTE PTR ds:[si]
     7cc:	aa                   	stos   BYTE PTR es:[di],al
     7cd:	91                   	xchg   cx,ax
     7ce:	30 ed                	xor    ch,ch
     7d0:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     7d2:	8e db                	mov    ds,bx
     7d4:	31 c0                	xor    ax,ax
     7d6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     7d9:	31 c0                	xor    ax,ax
     7db:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
     7df:	8d be fe fe          	lea    di,[bp-0x102]
     7e3:	16                   	push   ss
     7e4:	57                   	push   di
     7e5:	68 ff 00             	push   0xff
     7e8:	bf ec 2b             	mov    di,0x2bec
     7eb:	1e                   	push   ds
     7ec:	57                   	push   di
     7ed:	55                   	push   bp
     7ee:	e8 75 ff             	call   0x766
     7f1:	08 c0                	or     al,al
     7f3:	74 0d                	je     0x802
     7f5:	8b 86 f8 fe          	mov    ax,WORD PTR [bp-0x108]
     7f9:	0d 00 20             	or     ax,0x2000
     7fc:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
     800:	eb 6b                	jmp    0x86d
     802:	8d be fe fe          	lea    di,[bp-0x102]
     806:	16                   	push   ss
     807:	57                   	push   di
     808:	68 ff 00             	push   0xff
     80b:	bf b7 07             	mov    di,0x7b7
     80e:	0e                   	push   cs
     80f:	57                   	push   di
     810:	55                   	push   bp
     811:	e8 52 ff             	call   0x766
     814:	08 c0                	or     al,al
     816:	74 0d                	je     0x825
     818:	8b 86 f8 fe          	mov    ax,WORD PTR [bp-0x108]
     81c:	0d 00 40             	or     ax,0x4000
     81f:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
     823:	eb 48                	jmp    0x86d
     825:	8d be fe fe          	lea    di,[bp-0x102]
     829:	16                   	push   ss
     82a:	57                   	push   di
     82b:	68 ff 00             	push   0xff
     82e:	bf f4 2b             	mov    di,0x2bf4
     831:	1e                   	push   ds
     832:	57                   	push   di
     833:	55                   	push   bp
     834:	e8 2f ff             	call   0x766
     837:	08 c0                	or     al,al
     839:	74 0d                	je     0x848
     83b:	8b 86 f8 fe          	mov    ax,WORD PTR [bp-0x108]
     83f:	0d 00 40             	or     ax,0x4000
     842:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
     846:	eb 25                	jmp    0x86d
     848:	8d be fe fe          	lea    di,[bp-0x102]
     84c:	16                   	push   ss
     84d:	57                   	push   di
     84e:	68 ff 00             	push   0xff
     851:	bf fc 2b             	mov    di,0x2bfc
     854:	1e                   	push   ds
     855:	57                   	push   di
     856:	55                   	push   bp
     857:	e8 0c ff             	call   0x766
     85a:	08 c0                	or     al,al
     85c:	74 0d                	je     0x86b
     85e:	8b 86 f8 fe          	mov    ax,WORD PTR [bp-0x108]
     862:	0d 00 80             	or     ax,0x8000
     865:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
     869:	eb 02                	jmp    0x86d
     86b:	eb 03                	jmp    0x870
     86d:	e9 6f ff             	jmp    0x7df
     870:	80 be fe fe 00       	cmp    BYTE PTR [bp-0x102],0x0
     875:	75 02                	jne    0x879
     877:	eb 3f                	jmp    0x8b8
     879:	c7 86 fa fe 08 00    	mov    WORD PTR [bp-0x106],0x8
     87f:	eb 04                	jmp    0x885
     881:	ff 86 fa fe          	inc    WORD PTR [bp-0x106]
     885:	8d be fe fe          	lea    di,[bp-0x102]
     889:	16                   	push   ss
     88a:	57                   	push   di
     88b:	8d be f8 fd          	lea    di,[bp-0x208]
     88f:	16                   	push   ss
     890:	57                   	push   di
     891:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
     895:	9a 2f 05 d7 09       	call   0x9d7:0x52f
     89a:	9a 30 07 c7 0b       	call   0xbc7:0x730
     89f:	09 c0                	or     ax,ax
     8a1:	75 0d                	jne    0x8b0
     8a3:	8b 86 fa fe          	mov    ax,WORD PTR [bp-0x106]
     8a7:	0b 86 f8 fe          	or     ax,WORD PTR [bp-0x108]
     8ab:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     8ae:	eb 08                	jmp    0x8b8
     8b0:	81 be fa fe 87 00    	cmp    WORD PTR [bp-0x106],0x87
     8b6:	75 c9                	jne    0x881
     8b8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     8bb:	c9                   	leave
     8bc:	ca 04 00             	retf   0x4
	...
     8c7:	df 08                	fisttp WORD PTR [bx+si]
     8c9:	04 02                	add    al,0x2
     8cb:	2c 1f                	sub    al,0x1f
     8cd:	aa                   	stos   BYTE PTR es:[di],al
     8ce:	0b 64 20             	or     sp,WORD PTR [si+0x20]
     8d1:	cd 08                	int    0x8
     8d3:	9a 1f d1 08 cb       	call   0xcb08:0xd11f
     8d8:	1f                   	pop    ds
     8d9:	d5 08                	aad    0x8
     8db:	66 1f                	popd   ds
     8dd:	d9 08                	(bad)  [bx+si]
     8df:	08 54 42             	or     BYTE PTR [si+0x42],dl
     8e2:	69 74 50 6f 6f       	imul   si,WORD PTR [si+0x50],0x6f6f
     8e7:	6c                   	ins    BYTE PTR es:[di],dx
     8e8:	55                   	push   bp
     8e9:	89 e5                	mov    bp,sp
     8eb:	ff 4e 0c             	dec    WORD PTR [bp+0xc]
     8ee:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     8f2:	74 2e                	je     0x922
     8f4:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     8f7:	99                   	cwd
     8f8:	b9 10 00             	mov    cx,0x10
     8fb:	f7 f9                	idiv   cx
     8fd:	92                   	xchg   dx,ax
     8fe:	8a c8                	mov    cl,al
     900:	80 f9 10             	cmp    cl,0x10
     903:	73 1b                	jae    0x920
     905:	b8 01 00             	mov    ax,0x1
     908:	d3 c0                	rol    ax,cl
     90a:	8b d8                	mov    bx,ax
     90c:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     90f:	99                   	cwd
     910:	b9 10 00             	mov    cx,0x10
     913:	f7 f9                	idiv   cx
     915:	d1 e0                	shl    ax,1
     917:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     91a:	03 f8                	add    di,ax
     91c:	26 09 5d 04          	or     WORD PTR es:[di+0x4],bx
     920:	eb 2c                	jmp    0x94e
     922:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     925:	99                   	cwd
     926:	b9 10 00             	mov    cx,0x10
     929:	f7 f9                	idiv   cx
     92b:	92                   	xchg   dx,ax
     92c:	8a c8                	mov    cl,al
     92e:	80 f9 10             	cmp    cl,0x10
     931:	73 1b                	jae    0x94e
     933:	b8 fe ff             	mov    ax,0xfffe
     936:	d3 c0                	rol    ax,cl
     938:	8b d8                	mov    bx,ax
     93a:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     93d:	99                   	cwd
     93e:	b9 10 00             	mov    cx,0x10
     941:	f7 f9                	idiv   cx
     943:	d1 e0                	shl    ax,1
     945:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     948:	03 f8                	add    di,ax
     94a:	26 21 5d 04          	and    WORD PTR es:[di+0x4],bx
     94e:	c9                   	leave
     94f:	ca 08 00             	retf   0x8
     952:	c8 08 00 00          	enter  0x8,0x0
     956:	31 c0                	xor    ax,ax
     958:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     95b:	eb 03                	jmp    0x960
     95d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     960:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     963:	d1 e0                	shl    ax,1
     965:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     968:	03 f8                	add    di,ax
     96a:	26 83 7d 04 ff       	cmp    WORD PTR es:[di+0x4],0xffff
     96f:	74 46                	je     0x9b7
     971:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     974:	d1 e0                	shl    ax,1
     976:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     979:	03 f8                	add    di,ax
     97b:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     97f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     982:	c6 46 f9 00          	mov    BYTE PTR [bp-0x7],0x0
     986:	eb 03                	jmp    0x98b
     988:	fe 46 f9             	inc    BYTE PTR [bp-0x7]
     98b:	8a 4e f9             	mov    cl,BYTE PTR [bp-0x7]
     98e:	80 f9 10             	cmp    cl,0x10
     991:	73 0a                	jae    0x99d
     993:	b8 01 00             	mov    ax,0x1
     996:	d3 c0                	rol    ax,cl
     998:	85 46 fa             	test   WORD PTR [bp-0x6],ax
     99b:	75 14                	jne    0x9b1
     99d:	8a 46 f9             	mov    al,BYTE PTR [bp-0x7]
     9a0:	98                   	cbw
     9a1:	8b d0                	mov    dx,ax
     9a3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     9a6:	c1 e0 04             	shl    ax,0x4
     9a9:	03 c2                	add    ax,dx
     9ab:	40                   	inc    ax
     9ac:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     9af:	eb 12                	jmp    0x9c3
     9b1:	80 7e f9 0f          	cmp    BYTE PTR [bp-0x7],0xf
     9b5:	75 d1                	jne    0x988
     9b7:	81 7e fc ff 00       	cmp    WORD PTR [bp-0x4],0xff
     9bc:	75 9f                	jne    0x95d
     9be:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
     9c3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     9c6:	c9                   	leave
     9c7:	ca 04 00             	retf   0x4
     9ca:	c8 02 00 00          	enter  0x2,0x0
     9ce:	c4 3e 04 2c          	les    di,DWORD PTR ds:0x2c04
     9d2:	06                   	push   es
     9d3:	57                   	push   di
     9d4:	9a 52 09 ea 09       	call   0x9ea:0x952
     9d9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     9dc:	ff 76 fe             	push   WORD PTR [bp-0x2]
     9df:	6a 01                	push   0x1
     9e1:	c4 3e 04 2c          	les    di,DWORD PTR ds:0x2c04
     9e5:	06                   	push   es
     9e6:	57                   	push   di
     9e7:	9a e8 08 11 0a       	call   0xa11:0x8e8
     9ec:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     9ef:	c9                   	leave
     9f0:	c3                   	ret
     9f1:	c8 06 00 00          	enter  0x6,0x0
     9f5:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     9f8:	0b 46 0a             	or     ax,WORD PTR [bp+0xa]
     9fb:	75 02                	jne    0x9ff
     9fd:	eb 5b                	jmp    0xa5a
     9ff:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     a03:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
     a07:	75 51                	jne    0xa5a
     a09:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     a0c:	06                   	push   es
     a0d:	57                   	push   di
     a0e:	9a 26 13 26 0a       	call   0xa26:0x1326
     a13:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     a16:	26 3b 05             	cmp    ax,WORD PTR es:[di]
     a19:	7e 3f                	jle    0xa5a
     a1b:	26 ff 35             	push   WORD PTR es:[di]
     a1e:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     a21:	06                   	push   es
     a22:	57                   	push   di
     a23:	9a 53 13 89 0a       	call   0xa89:0x1353
     a28:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     a2b:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     a2e:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     a31:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
     a35:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
     a38:	36 3a 45 fb          	cmp    al,BYTE PTR ss:[di-0x5]
     a3c:	76 02                	jbe    0xa40
     a3e:	eb 1a                	jmp    0xa5a
     a40:	ff 76 fc             	push   WORD PTR [bp-0x4]
     a43:	ff 76 fa             	push   WORD PTR [bp-0x6]
     a46:	8b 5e 04             	mov    bx,WORD PTR [bp+0x4]
     a49:	36 ff 37             	push   WORD PTR ss:[bx]
     a4c:	ff 56 06             	call   WORD PTR [bp+0x6]
     a4f:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     a52:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     a55:	26 ff 05             	inc    WORD PTR es:[di]
     a58:	eb a9                	jmp    0xa03
     a5a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     a5d:	c9                   	leave
     a5e:	c2 0c 00             	ret    0xc
     a61:	c8 0c 00 00          	enter  0xc,0x0
     a65:	31 c0                	xor    ax,ax
     a67:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     a6a:	31 c0                	xor    ax,ax
     a6c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     a6f:	31 c0                	xor    ax,ax
     a71:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     a74:	31 c0                	xor    ax,ax
     a76:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     a79:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     a7c:	0b 46 0a             	or     ax,WORD PTR [bp+0xa]
     a7f:	74 0d                	je     0xa8e
     a81:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     a84:	06                   	push   es
     a85:	57                   	push   di
     a86:	9a 26 13 9e 0a       	call   0xa9e:0x1326
     a8b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     a8e:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     a91:	0b 46 06             	or     ax,WORD PTR [bp+0x6]
     a94:	74 0d                	je     0xaa3
     a96:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     a99:	06                   	push   es
     a9a:	57                   	push   di
     a9b:	9a 26 13 de 0a       	call   0xade:0x1326
     aa0:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     aa3:	c6 46 f5 00          	mov    BYTE PTR [bp-0xb],0x0
     aa7:	80 7e f5 00          	cmp    BYTE PTR [bp-0xb],0x0
     aab:	74 03                	je     0xab0
     aad:	e9 e6 00             	jmp    0xb96
     ab0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     ab3:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     ab6:	7c 0b                	jl     0xac3
     ab8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     abb:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
     abe:	7c 03                	jl     0xac3
     ac0:	e9 d3 00             	jmp    0xb96
     ac3:	c6 46 fb ff          	mov    BYTE PTR [bp-0x5],0xff
     ac7:	c6 46 fa ff          	mov    BYTE PTR [bp-0x6],0xff
     acb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     ace:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     ad1:	7d 18                	jge    0xaeb
     ad3:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ad6:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     ad9:	06                   	push   es
     ada:	57                   	push   di
     adb:	9a 53 13 fe 0a       	call   0xafe:0x1353
     ae0:	89 c7                	mov    di,ax
     ae2:	8e c2                	mov    es,dx
     ae4:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
     ae8:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
     aeb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     aee:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
     af1:	7d 18                	jge    0xb0b
     af3:	ff 76 fc             	push   WORD PTR [bp-0x4]
     af6:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     af9:	06                   	push   es
     afa:	57                   	push   di
     afb:	9a 53 13 58 0b       	call   0xb58:0x1353
     b00:	89 c7                	mov    di,ax
     b02:	8e c2                	mov    es,dx
     b04:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
     b08:	88 46 fa             	mov    BYTE PTR [bp-0x6],al
     b0b:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
     b0e:	3a 46 fa             	cmp    al,BYTE PTR [bp-0x6]
     b11:	77 17                	ja     0xb2a
     b13:	8d 7e fe             	lea    di,[bp-0x2]
     b16:	16                   	push   ss
     b17:	57                   	push   di
     b18:	ff 76 0a             	push   WORD PTR [bp+0xa]
     b1b:	ff 76 08             	push   WORD PTR [bp+0x8]
     b1e:	ff 76 0c             	push   WORD PTR [bp+0xc]
     b21:	55                   	push   bp
     b22:	e8 cc fe             	call   0x9f1
     b25:	88 46 f5             	mov    BYTE PTR [bp-0xb],al
     b28:	eb 1b                	jmp    0xb45
     b2a:	8a 46 fa             	mov    al,BYTE PTR [bp-0x6]
     b2d:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
     b30:	8d 7e fc             	lea    di,[bp-0x4]
     b33:	16                   	push   ss
     b34:	57                   	push   di
     b35:	ff 76 06             	push   WORD PTR [bp+0x6]
     b38:	ff 76 04             	push   WORD PTR [bp+0x4]
     b3b:	ff 76 0c             	push   WORD PTR [bp+0xc]
     b3e:	55                   	push   bp
     b3f:	e8 af fe             	call   0x9f1
     b42:	88 46 f5             	mov    BYTE PTR [bp-0xb],al
     b45:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     b48:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     b4b:	7d 1f                	jge    0xb6c
     b4d:	ff 76 fe             	push   WORD PTR [bp-0x2]
     b50:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     b53:	06                   	push   es
     b54:	57                   	push   di
     b55:	9a 53 13 7f 0b       	call   0xb7f:0x1353
     b5a:	89 c7                	mov    di,ax
     b5c:	8e c2                	mov    es,dx
     b5e:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
     b62:	3a 46 fb             	cmp    al,BYTE PTR [bp-0x5]
     b65:	77 05                	ja     0xb6c
     b67:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     b6a:	eb d9                	jmp    0xb45
     b6c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b6f:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
     b72:	7d 1f                	jge    0xb93
     b74:	ff 76 fc             	push   WORD PTR [bp-0x4]
     b77:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     b7a:	06                   	push   es
     b7b:	57                   	push   di
     b7c:	9a 53 13 2d 0c       	call   0xc2d:0x1353
     b81:	89 c7                	mov    di,ax
     b83:	8e c2                	mov    es,dx
     b85:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
     b89:	3a 46 fb             	cmp    al,BYTE PTR [bp-0x5]
     b8c:	77 05                	ja     0xb93
     b8e:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     b91:	eb d9                	jmp    0xb6c
     b93:	e9 11 ff             	jmp    0xaa7
     b96:	c9                   	leave
     b97:	c2 0c 00             	ret    0xc
     b9a:	00 55 89             	add    BYTE PTR [di-0x77],dl
     b9d:	e5 80                	in     ax,0x80
     b9f:	7e 0a                	jle    0xbab
     ba1:	00 74 08             	add    BYTE PTR [si+0x8],dh
     ba4:	83 ec 08             	sub    sp,0x8
     ba7:	9a e2 1f 8a 0c       	call   0xc8a:0x1fe2
     bac:	ff 76 0e             	push   WORD PTR [bp+0xe]
     baf:	ff 76 0c             	push   WORD PTR [bp+0xc]
     bb2:	31 c0                	xor    ax,ax
     bb4:	50                   	push   ax
     bb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bb8:	06                   	push   es
     bb9:	57                   	push   di
     bba:	9a d9 4b d2 0c       	call   0xcd2:0x4bd9
     bbf:	bf 9a 0b             	mov    di,0xb9a
     bc2:	0e                   	push   cs
     bc3:	57                   	push   di
     bc4:	9a d7 05 aa 0c       	call   0xcaa:0x5d7
     bc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bcc:	26 89 45 1b          	mov    WORD PTR es:[di+0x1b],ax
     bd0:	26 89 55 1d          	mov    WORD PTR es:[di+0x1d],dx
     bd4:	26 c6 45 31 01       	mov    BYTE PTR es:[di+0x31],0x1
     bd9:	26 c6 45 20 01       	mov    BYTE PTR es:[di+0x20],0x1
     bde:	a1 16 17             	mov    ax,ds:0x1716
     be1:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
     be5:	26 89 45 27          	mov    WORD PTR es:[di+0x27],ax
     be9:	26 89 55 29          	mov    WORD PTR es:[di+0x29],dx
     bed:	e8 da fd             	call   0x9ca
     bf0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bf3:	26 89 45 43          	mov    WORD PTR es:[di+0x43],ax
     bf7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     bfb:	74 07                	je     0xc04
     bfd:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     c01:	83 c4 06             	add    sp,0x6
     c04:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     c07:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     c0a:	c9                   	leave
     c0b:	ca 0a 00             	retf   0xa
     c0e:	55                   	push   bp
     c0f:	89 e5                	mov    bp,sp
     c11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c14:	26 8b 45 45          	mov    ax,WORD PTR es:[di+0x45]
     c18:	26 0b 45 47          	or     ax,WORD PTR es:[di+0x47]
     c1c:	74 1e                	je     0xc3c
     c1e:	ff 76 08             	push   WORD PTR [bp+0x8]
     c21:	ff 76 06             	push   WORD PTR [bp+0x6]
     c24:	26 c4 7d 45          	les    di,DWORD PTR es:[di+0x45]
     c28:	06                   	push   es
     c29:	57                   	push   di
     c2a:	9a 7e 16 4f 0c       	call   0xc4f:0x167e
     c2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c32:	31 c0                	xor    ax,ax
     c34:	26 89 45 45          	mov    WORD PTR es:[di+0x45],ax
     c38:	26 89 45 47          	mov    WORD PTR es:[di+0x47],ax
     c3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c3f:	26 83 7d 21 00       	cmp    WORD PTR es:[di+0x21],0x0
     c44:	74 21                	je     0xc67
     c46:	6a 00                	push   0x0
     c48:	6a 00                	push   0x0
     c4a:	06                   	push   es
     c4b:	57                   	push   di
     c4c:	9a 24 0f 65 0c       	call   0xc65:0xf24
     c51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c54:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
     c58:	9a ff ff 00 00       	call   0x0:0xffff
     c5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c60:	06                   	push   es
     c61:	57                   	push   di
     c62:	9a 36 0d 6f 0c       	call   0xc6f:0xd36
     c67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c6a:	06                   	push   es
     c6b:	57                   	push   di
     c6c:	9a 26 13 7f 0c       	call   0xc7f:0x1326
     c71:	09 c0                	or     ax,ax
     c73:	7e 19                	jle    0xc8e
     c75:	6a 00                	push   0x0
     c77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c7a:	06                   	push   es
     c7b:	57                   	push   di
     c7c:	9a 53 13 c5 0c       	call   0xcc5:0x1353
     c81:	89 c7                	mov    di,ax
     c83:	8e c2                	mov    es,dx
     c85:	06                   	push   es
     c86:	57                   	push   di
     c87:	9a 7f 1f 9a 0c       	call   0xc9a:0x1f7f
     c8c:	eb d9                	jmp    0xc67
     c8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c91:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
     c95:	06                   	push   es
     c96:	57                   	push   di
     c97:	9a 7f 1f dd 0c       	call   0xcdd:0x1f7f
     c9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c9f:	26 ff 75 1d          	push   WORD PTR es:[di+0x1d]
     ca3:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
     ca7:	9a 24 06 6c 0d       	call   0xd6c:0x624
     cac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     caf:	26 83 7d 43 00       	cmp    WORD PTR es:[di+0x43],0x0
     cb4:	74 11                	je     0xcc7
     cb6:	26 ff 75 43          	push   WORD PTR es:[di+0x43]
     cba:	6a 00                	push   0x0
     cbc:	c4 3e 04 2c          	les    di,DWORD PTR ds:0x2c04
     cc0:	06                   	push   es
     cc1:	57                   	push   di
     cc2:	9a e8 08 fb 0c       	call   0xcfb:0x8e8
     cc7:	31 c0                	xor    ax,ax
     cc9:	50                   	push   ax
     cca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ccd:	06                   	push   es
     cce:	57                   	push   di
     ccf:	9a 2b 4c 1f 0d       	call   0xd1f:0x4c2b
     cd4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     cd8:	74 05                	je     0xcdf
     cda:	9a 0f 20 7f 0d       	call   0xd7f:0x200f
     cdf:	c9                   	leave
     ce0:	ca 06 00             	retf   0x6
     ce3:	c8 08 00 00          	enter  0x8,0x0
     ce7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cea:	89 7e fa             	mov    WORD PTR [bp-0x6],di
     ced:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
     cf0:	31 c0                	xor    ax,ax
     cf2:	26 89 45 21          	mov    WORD PTR es:[di+0x21],ax
     cf6:	06                   	push   es
     cf7:	57                   	push   di
     cf8:	9a 26 13 f8 0d       	call   0xdf8:0x1326
     cfd:	48                   	dec    ax
     cfe:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     d01:	31 c0                	xor    ax,ax
     d03:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     d06:	7f 2a                	jg     0xd32
     d08:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     d0b:	eb 03                	jmp    0xd10
     d0d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     d10:	ff 76 fe             	push   WORD PTR [bp-0x2]
     d13:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     d16:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
     d1a:	06                   	push   es
     d1b:	57                   	push   di
     d1c:	9a d0 0d 0e 0f       	call   0xf0e:0xdd0
     d21:	52                   	push   dx
     d22:	50                   	push   ax
     d23:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
     d26:	57                   	push   di
     d27:	e8 b9 ff             	call   0xce3
     d2a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     d2d:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     d30:	75 db                	jne    0xd0d
     d32:	c9                   	leave
     d33:	c2 06 00             	ret    0x6
     d36:	55                   	push   bp
     d37:	89 e5                	mov    bp,sp
     d39:	ff 76 08             	push   WORD PTR [bp+0x8]
     d3c:	ff 76 06             	push   WORD PTR [bp+0x6]
     d3f:	55                   	push   bp
     d40:	e8 a0 ff             	call   0xce3
     d43:	c9                   	leave
     d44:	ca 04 00             	retf   0x4
     d47:	01 2d                	add    WORD PTR [di],bp
     d49:	c8 02 02 00          	enter  0x202,0x0
     d4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d50:	26 80 7d 31 00       	cmp    BYTE PTR es:[di+0x31],0x0
     d55:	75 03                	jne    0xd5a
     d57:	e9 57 01             	jmp    0xeb1
     d5a:	8d be 00 ff          	lea    di,[bp-0x100]
     d5e:	16                   	push   ss
     d5f:	57                   	push   di
     d60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d63:	26 c4 7d 1b          	les    di,DWORD PTR es:[di+0x1b]
     d67:	06                   	push   es
     d68:	57                   	push   di
     d69:	9a 4c 0d 6f 0e       	call   0xe6f:0xd4c
     d6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d71:	26 c4 7d 1b          	les    di,DWORD PTR es:[di+0x1b]
     d75:	06                   	push   es
     d76:	57                   	push   di
     d77:	bf 47 0d             	mov    di,0xd47
     d7a:	0e                   	push   cs
     d7b:	57                   	push   di
     d7c:	9a be 18 60 0e       	call   0xe60:0x18be
     d81:	b0 00                	mov    al,0x0
     d83:	75 01                	jne    0xd86
     d85:	40                   	inc    ax
     d86:	98                   	cbw
     d87:	8b f8                	mov    di,ax
     d89:	c1 e7 02             	shl    di,0x2
     d8c:	ff b5 ce 13          	push   WORD PTR [di+0x13ce]
     d90:	ff b5 cc 13          	push   WORD PTR [di+0x13cc]
     d94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d97:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
     d9b:	98                   	cbw
     d9c:	8b f8                	mov    di,ax
     d9e:	c1 e7 02             	shl    di,0x2
     da1:	8b 8d bc 13          	mov    cx,WORD PTR [di+0x13bc]
     da5:	8b 9d be 13          	mov    bx,WORD PTR [di+0x13be]
     da9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dac:	26 8a 45 1a          	mov    al,BYTE PTR es:[di+0x1a]
     db0:	98                   	cbw
     db1:	8b f8                	mov    di,ax
     db3:	c1 e7 02             	shl    di,0x2
     db6:	8b 85 b0 13          	mov    ax,WORD PTR [di+0x13b0]
     dba:	8b 95 b2 13          	mov    dx,WORD PTR [di+0x13b2]
     dbe:	0b c1                	or     ax,cx
     dc0:	0b d3                	or     dx,bx
     dc2:	8b c8                	mov    cx,ax
     dc4:	8b da                	mov    bx,dx
     dc6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dc9:	26 8a 45 20          	mov    al,BYTE PTR es:[di+0x20]
     dcd:	98                   	cbw
     dce:	8b f8                	mov    di,ax
     dd0:	c1 e7 02             	shl    di,0x2
     dd3:	8b 85 c4 13          	mov    ax,WORD PTR [di+0x13c4]
     dd7:	8b 95 c6 13          	mov    dx,WORD PTR [di+0x13c6]
     ddb:	0b c1                	or     ax,cx
     ddd:	0b d3                	or     dx,bx
     ddf:	59                   	pop    cx
     de0:	5b                   	pop    bx
     de1:	0b c1                	or     ax,cx
     de3:	0b d3                	or     dx,bx
     de5:	0d 00 04             	or     ax,0x400
     de8:	81 ca 00 00          	or     dx,0x0
     dec:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
     df0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     df3:	06                   	push   es
     df4:	57                   	push   di
     df5:	9a 26 13 13 0e       	call   0xe13:0x1326
     dfa:	09 c0                	or     ax,ax
     dfc:	7e 26                	jle    0xe24
     dfe:	ff 76 0a             	push   WORD PTR [bp+0xa]
     e01:	6a ff                	push   0xffff
     e03:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
     e07:	0d 10 00             	or     ax,0x10
     e0a:	50                   	push   ax
     e0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e0e:	06                   	push   es
     e0f:	57                   	push   di
     e10:	9a 5d 10 59 0e       	call   0xe59:0x105d
     e15:	50                   	push   ax
     e16:	8d be 00 ff          	lea    di,[bp-0x100]
     e1a:	16                   	push   ss
     e1b:	57                   	push   di
     e1c:	9a ad 0e 00 00       	call   0x0:0xead
     e21:	e9 8d 00             	jmp    0xeb1
     e24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e27:	26 83 7d 2f 00       	cmp    WORD PTR es:[di+0x2f],0x0
     e2c:	74 68                	je     0xe96
     e2e:	26 8b 45 45          	mov    ax,WORD PTR es:[di+0x45]
     e32:	26 0b 45 47          	or     ax,WORD PTR es:[di+0x47]
     e36:	74 2e                	je     0xe66
     e38:	26 c4 7d 45          	les    di,DWORD PTR es:[di+0x45]
     e3c:	26 8b 45 45          	mov    ax,WORD PTR es:[di+0x45]
     e40:	26 0b 45 47          	or     ax,WORD PTR es:[di+0x47]
     e44:	75 20                	jne    0xe66
     e46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e49:	26 c4 7d 45          	les    di,DWORD PTR es:[di+0x45]
     e4d:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     e51:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     e55:	bf ef 02             	mov    di,0x2ef
     e58:	b8 8f 0e             	mov    ax,0xe8f
     e5b:	50                   	push   ax
     e5c:	57                   	push   di
     e5d:	9a 55 22 9d 0f       	call   0xf9d:0x2255
     e62:	08 c0                	or     al,al
     e64:	75 30                	jne    0xe96
     e66:	8d be 00 ff          	lea    di,[bp-0x100]
     e6a:	16                   	push   ss
     e6b:	57                   	push   di
     e6c:	9a a3 0c 7b 0e       	call   0xe7b:0xca3
     e71:	52                   	push   dx
     e72:	50                   	push   ax
     e73:	bf d4 13             	mov    di,0x13d4
     e76:	1e                   	push   ds
     e77:	57                   	push   di
     e78:	9a 01 0d 94 0e       	call   0xe94:0xd01
     e7d:	52                   	push   dx
     e7e:	50                   	push   ax
     e7f:	8d be fe fd          	lea    di,[bp-0x202]
     e83:	16                   	push   ss
     e84:	57                   	push   di
     e85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e88:	26 ff 75 2f          	push   WORD PTR es:[di+0x2f]
     e8c:	9a 2f 05 cc 0e       	call   0xecc:0x52f
     e91:	9a 4c 0d f2 0f       	call   0xff2:0xd4c
     e96:	ff 76 0a             	push   WORD PTR [bp+0xa]
     e99:	6a ff                	push   0xffff
     e9b:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
     e9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ea2:	26 ff 75 43          	push   WORD PTR es:[di+0x43]
     ea6:	8d be 00 ff          	lea    di,[bp-0x100]
     eaa:	16                   	push   ss
     eab:	57                   	push   di
     eac:	9a ff ff 00 00       	call   0x0:0xffff
     eb1:	c9                   	leave
     eb2:	ca 06 00             	retf   0x6
     eb5:	c8 02 00 00          	enter  0x2,0x0
     eb9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
     ebc:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
     ec0:	26 ff 75 21          	push   WORD PTR es:[di+0x21]
     ec4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ec7:	06                   	push   es
     ec8:	57                   	push   di
     ec9:	9a 49 0d e0 0e       	call   0xee0:0xd49
     ece:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     ed2:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     ed5:	c9                   	leave
     ed6:	c2 06 00             	ret    0x6
     ed9:	55                   	push   bp
     eda:	89 e5                	mov    bp,sp
     edc:	bf b5 0e             	mov    di,0xeb5
     edf:	b8 13 0f             	mov    ax,0xf13
     ee2:	50                   	push   ax
     ee3:	57                   	push   di
     ee4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ee7:	26 ff 75 4b          	push   WORD PTR es:[di+0x4b]
     eeb:	26 ff 75 49          	push   WORD PTR es:[di+0x49]
     eef:	ff 76 08             	push   WORD PTR [bp+0x8]
     ef2:	ff 76 06             	push   WORD PTR [bp+0x6]
     ef5:	e8 69 fb             	call   0xa61
     ef8:	c9                   	leave
     ef9:	ca 04 00             	retf   0x4
     efc:	c8 00 01 00          	enter  0x100,0x0
     f00:	8d be 00 ff          	lea    di,[bp-0x100]
     f04:	16                   	push   ss
     f05:	57                   	push   di
     f06:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f09:	06                   	push   es
     f0a:	57                   	push   di
     f0b:	9a 74 3f 57 10       	call   0x1057:0x3f74
     f10:	9a b9 07 1e 0f       	call   0xf1e:0x7b9
     f15:	50                   	push   ax
     f16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f19:	06                   	push   es
     f1a:	57                   	push   di
     f1b:	9a 88 13 52 0f       	call   0xf52:0x1388
     f20:	c9                   	leave
     f21:	ca 08 00             	retf   0x8
     f24:	55                   	push   bp
     f25:	89 e5                	mov    bp,sp
     f27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f2a:	26 8b 45 49          	mov    ax,WORD PTR es:[di+0x49]
     f2e:	26 8b 55 4b          	mov    dx,WORD PTR es:[di+0x4b]
     f32:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
     f35:	75 05                	jne    0xf3c
     f37:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
     f3a:	74 18                	je     0xf54
     f3c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     f3f:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
     f42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f45:	26 89 45 49          	mov    WORD PTR es:[di+0x49],ax
     f49:	26 89 55 4b          	mov    WORD PTR es:[di+0x4b],dx
     f4d:	06                   	push   es
     f4e:	57                   	push   di
     f4f:	9a 58 0f 63 0f       	call   0xf63:0xf58
     f54:	c9                   	leave
     f55:	ca 08 00             	retf   0x8
     f58:	55                   	push   bp
     f59:	89 e5                	mov    bp,sp
     f5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f5e:	06                   	push   es
     f5f:	57                   	push   di
     f60:	9a 5d 10 77 0f       	call   0xf77:0x105d
     f65:	50                   	push   ax
     f66:	9a 01 1c 00 00       	call   0x0:0x1c01
     f6b:	09 c0                	or     ax,ax
     f6d:	7e 17                	jle    0xf86
     f6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f72:	06                   	push   es
     f73:	57                   	push   di
     f74:	9a 5d 10 8e 0f       	call   0xf8e:0x105d
     f79:	50                   	push   ax
     f7a:	6a 00                	push   0x0
     f7c:	68 00 04             	push   0x400
     f7f:	9a ff ff 00 00       	call   0x0:0xffff
     f84:	eb d5                	jmp    0xf5b
     f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f89:	06                   	push   es
     f8a:	57                   	push   di
     f8b:	9a d9 0e af 0f       	call   0xfaf:0xed9
     f90:	6a 00                	push   0x0
     f92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f95:	06                   	push   es
     f96:	57                   	push   di
     f97:	b8 ff ff             	mov    ax,0xffff
     f9a:	9a 6a 20 7e 10       	call   0x107e:0x206a
     f9f:	c9                   	leave
     fa0:	ca 04 00             	retf   0x4
     fa3:	c8 04 01 00          	enter  0x104,0x0
     fa7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     faa:	06                   	push   es
     fab:	57                   	push   di
     fac:	9a 26 13 d7 0f       	call   0xfd7:0x1326
     fb1:	48                   	dec    ax
     fb2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     fb5:	31 c0                	xor    ax,ax
     fb7:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     fba:	7f 79                	jg     0x1035
     fbc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     fbf:	eb 03                	jmp    0xfc4
     fc1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     fc4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     fc7:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
     fca:	7d 2d                	jge    0xff9
     fcc:	ff 76 fe             	push   WORD PTR [bp-0x2]
     fcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fd2:	06                   	push   es
     fd3:	57                   	push   di
     fd4:	9a 53 13 04 10       	call   0x1004:0x1353
     fd9:	89 c7                	mov    di,ax
     fdb:	8e c2                	mov    es,dx
     fdd:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
     fe1:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
     fe4:	76 11                	jbe    0xff7
     fe6:	8d be fc fe          	lea    di,[bp-0x104]
     fea:	16                   	push   ss
     feb:	57                   	push   di
     fec:	68 37 f0             	push   0xf037
     fef:	9a 2b 09 b4 10       	call   0x10b4:0x92b
     ff4:	e8 bc f4             	call   0x4b3
     ff7:	eb 34                	jmp    0x102d
     ff9:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ffc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fff:	06                   	push   es
    1000:	57                   	push   di
    1001:	9a 53 13 22 10       	call   0x1022:0x1353
    1006:	89 c7                	mov    di,ax
    1008:	8e c2                	mov    es,dx
    100a:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
    100e:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1011:	73 1a                	jae    0x102d
    1013:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1016:	50                   	push   ax
    1017:	ff 76 fe             	push   WORD PTR [bp-0x2]
    101a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    101d:	06                   	push   es
    101e:	57                   	push   di
    101f:	9a 53 13 4d 10       	call   0x104d:0x1353
    1024:	89 c7                	mov    di,ax
    1026:	8e c2                	mov    es,dx
    1028:	58                   	pop    ax
    1029:	26 88 45 32          	mov    BYTE PTR es:[di+0x32],al
    102d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1030:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1033:	75 8c                	jne    0xfc1
    1035:	c9                   	leave
    1036:	ca 08 00             	retf   0x8
    1039:	c8 00 01 00          	enter  0x100,0x0
    103d:	8d be 00 ff          	lea    di,[bp-0x100]
    1041:	16                   	push   ss
    1042:	57                   	push   di
    1043:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1046:	26 ff 75 2f          	push   WORD PTR es:[di+0x2f]
    104a:	9a 2f 05 77 10       	call   0x1077:0x52f
    104f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1052:	06                   	push   es
    1053:	57                   	push   di
    1054:	9a 9d 4b 23 11       	call   0x1123:0x4b9d
    1059:	c9                   	leave
    105a:	ca 08 00             	retf   0x8
    105d:	c8 04 01 00          	enter  0x104,0x0
    1061:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1064:	26 83 7d 21 00       	cmp    WORD PTR es:[di+0x21],0x0
    1069:	75 6c                	jne    0x10d7
    106b:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    106f:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1073:	bf c6 03             	mov    di,0x3c6
    1076:	b8 bd 10             	mov    ax,0x10bd
    1079:	50                   	push   ax
    107a:	57                   	push   di
    107b:	9a 55 22 cb 10       	call   0x10cb:0x2255
    1080:	08 c0                	or     al,al
    1082:	74 0e                	je     0x1092
    1084:	9a ff ff 00 00       	call   0x0:0xffff
    1089:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    108c:	26 89 45 21          	mov    WORD PTR es:[di+0x21],ax
    1090:	eb 0c                	jmp    0x109e
    1092:	9a ff ff 00 00       	call   0x0:0xffff
    1097:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    109a:	26 89 45 21          	mov    WORD PTR es:[di+0x21],ax
    109e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10a1:	26 83 7d 21 00       	cmp    WORD PTR es:[di+0x21],0x0
    10a6:	75 25                	jne    0x10cd
    10a8:	8d be fc fe          	lea    di,[bp-0x104]
    10ac:	16                   	push   ss
    10ad:	57                   	push   di
    10ae:	68 20 f0             	push   0xf020
    10b1:	9a 2b 09 c4 10       	call   0x10c4:0x92b
    10b6:	b0 01                	mov    al,0x1
    10b8:	50                   	push   ax
    10b9:	b8 22 00             	mov    ax,0x22
    10bc:	ba d5 10             	mov    dx,0x10d5
    10bf:	52                   	push   dx
    10c0:	50                   	push   ax
    10c1:	9a e6 28 60 12       	call   0x1260:0x28e6
    10c6:	52                   	push   dx
    10c7:	50                   	push   ax
    10c8:	9a 99 13 ff 10       	call   0x10ff:0x1399
    10cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10d0:	06                   	push   es
    10d1:	57                   	push   di
    10d2:	9a d9 0e 33 11       	call   0x1133:0xed9
    10d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10da:	26 8b 45 21          	mov    ax,WORD PTR es:[di+0x21]
    10de:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    10e1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    10e4:	c9                   	leave
    10e5:	ca 04 00             	retf   0x4
    10e8:	55                   	push   bp
    10e9:	89 e5                	mov    bp,sp
    10eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10ee:	26 c4 7d 27          	les    di,DWORD PTR es:[di+0x27]
    10f2:	06                   	push   es
    10f3:	57                   	push   di
    10f4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    10f7:	06                   	push   es
    10f8:	57                   	push   di
    10f9:	68 ff 00             	push   0xff
    10fc:	9a e7 17 78 11       	call   0x1178:0x17e7
    1101:	c9                   	leave
    1102:	ca 04 00             	retf   0x4
    1105:	0c 53                	or     al,0x53
    1107:	68 6f 72             	push   0x726f
    110a:	74 43                	je     0x114f
    110c:	75 74                	jne    0x1182
    110e:	54                   	push   sp
    110f:	65 78 74             	gs js  0x1186
    1112:	55                   	push   bp
    1113:	89 e5                	mov    bp,sp
    1115:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1118:	ff 76 0a             	push   WORD PTR [bp+0xa]
    111b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    111e:	06                   	push   es
    111f:	57                   	push   di
    1120:	9a 6e 4f 0b 12       	call   0x120b:0x4f6e
    1125:	bf 05 11             	mov    di,0x1105
    1128:	0e                   	push   cs
    1129:	57                   	push   di
    112a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    112d:	06                   	push   es
    112e:	57                   	push   di
    112f:	bf fc 0e             	mov    di,0xefc
    1132:	b8 40 11             	mov    ax,0x1140
    1135:	50                   	push   ax
    1136:	57                   	push   di
    1137:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    113a:	06                   	push   es
    113b:	57                   	push   di
    113c:	bf 39 10             	mov    di,0x1039
    113f:	b8 a6 11             	mov    ax,0x11a6
    1142:	50                   	push   ax
    1143:	57                   	push   di
    1144:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1147:	26 83 7d 2f 00       	cmp    WORD PTR es:[di+0x2f],0x0
    114c:	b0 00                	mov    al,0x0
    114e:	74 01                	je     0x1151
    1150:	40                   	inc    ax
    1151:	50                   	push   ax
    1152:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1155:	06                   	push   es
    1156:	57                   	push   di
    1157:	26 c4 3d             	les    di,DWORD PTR es:[di]
    115a:	26 ff 1d             	call   DWORD PTR es:[di]
    115d:	c9                   	leave
    115e:	ca 08 00             	retf   0x8
    1161:	55                   	push   bp
    1162:	89 e5                	mov    bp,sp
    1164:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1167:	26 c4 7d 1b          	les    di,DWORD PTR es:[di+0x1b]
    116b:	06                   	push   es
    116c:	57                   	push   di
    116d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1170:	06                   	push   es
    1171:	57                   	push   di
    1172:	68 ff 00             	push   0xff
    1175:	9a e7 17 ad 11       	call   0x11ad:0x17e7
    117a:	c9                   	leave
    117b:	ca 04 00             	retf   0x4
    117e:	c8 02 00 00          	enter  0x2,0x0
    1182:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1186:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1189:	c9                   	leave
    118a:	ca 04 00             	retf   0x4
    118d:	c8 04 00 00          	enter  0x4,0x0
    1191:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1194:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1197:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    119a:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    119e:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    11a2:	bf 5a 02             	mov    di,0x25a
    11a5:	b8 c9 11             	mov    ax,0x11c9
    11a8:	50                   	push   ax
    11a9:	57                   	push   di
    11aa:	9a 55 22 e3 11       	call   0x11e3:0x2255
    11af:	08 c0                	or     al,al
    11b1:	74 1a                	je     0x11cd
    11b3:	ff 76 08             	push   WORD PTR [bp+0x8]
    11b6:	ff 76 06             	push   WORD PTR [bp+0x6]
    11b9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    11bc:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    11c0:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    11c4:	06                   	push   es
    11c5:	57                   	push   di
    11c6:	9a 5c 16 dc 11       	call   0x11dc:0x165c
    11cb:	eb 30                	jmp    0x11fd
    11cd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    11d0:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    11d4:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    11d8:	bf 94 00             	mov    di,0x94
    11db:	b8 fb 11             	mov    ax,0x11fb
    11de:	50                   	push   ax
    11df:	57                   	push   di
    11e0:	9a 55 22 31 12       	call   0x1231:0x2255
    11e5:	08 c0                	or     al,al
    11e7:	74 14                	je     0x11fd
    11e9:	ff 76 08             	push   WORD PTR [bp+0x8]
    11ec:	ff 76 06             	push   WORD PTR [bp+0x6]
    11ef:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    11f2:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    11f6:	06                   	push   es
    11f7:	57                   	push   di
    11f8:	9a 5c 16 03 13       	call   0x1303:0x165c
    11fd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1200:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1203:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1206:	06                   	push   es
    1207:	57                   	push   di
    1208:	9a 03 50 76 13       	call   0x1376:0x5003
    120d:	c9                   	leave
    120e:	ca 08 00             	retf   0x8
    1211:	55                   	push   bp
    1212:	89 e5                	mov    bp,sp
    1214:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1217:	26 8a 45 1a          	mov    al,BYTE PTR es:[di+0x1a]
    121b:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    121e:	74 13                	je     0x1233
    1220:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1223:	26 88 45 1a          	mov    BYTE PTR es:[di+0x1a],al
    1227:	6a 01                	push   0x1
    1229:	06                   	push   es
    122a:	57                   	push   di
    122b:	b8 ff ff             	mov    ax,0xffff
    122e:	9a 6a 20 4b 12       	call   0x124b:0x206a
    1233:	c9                   	leave
    1234:	ca 06 00             	retf   0x6
    1237:	55                   	push   bp
    1238:	89 e5                	mov    bp,sp
    123a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    123d:	26 c4 7d 1b          	les    di,DWORD PTR es:[di+0x1b]
    1241:	06                   	push   es
    1242:	57                   	push   di
    1243:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1246:	06                   	push   es
    1247:	57                   	push   di
    1248:	9a be 18 6f 12       	call   0x126f:0x18be
    124d:	74 22                	je     0x1271
    124f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1252:	81 c7 1b 00          	add    di,0x1b
    1256:	06                   	push   es
    1257:	57                   	push   di
    1258:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    125b:	06                   	push   es
    125c:	57                   	push   di
    125d:	9a 51 06 d5 12       	call   0x12d5:0x651
    1262:	6a 01                	push   0x1
    1264:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1267:	06                   	push   es
    1268:	57                   	push   di
    1269:	b8 ff ff             	mov    ax,0xffff
    126c:	9a 6a 20 95 12       	call   0x1295:0x206a
    1271:	c9                   	leave
    1272:	ca 08 00             	retf   0x8
    1275:	55                   	push   bp
    1276:	89 e5                	mov    bp,sp
    1278:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    127b:	26 8a 45 1f          	mov    al,BYTE PTR es:[di+0x1f]
    127f:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1282:	74 13                	je     0x1297
    1284:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1287:	26 88 45 1f          	mov    BYTE PTR es:[di+0x1f],al
    128b:	6a 01                	push   0x1
    128d:	06                   	push   es
    128e:	57                   	push   di
    128f:	b8 ff ff             	mov    ax,0xffff
    1292:	9a 6a 20 bb 12       	call   0x12bb:0x206a
    1297:	c9                   	leave
    1298:	ca 06 00             	retf   0x6
    129b:	55                   	push   bp
    129c:	89 e5                	mov    bp,sp
    129e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12a1:	26 8a 45 20          	mov    al,BYTE PTR es:[di+0x20]
    12a5:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    12a8:	74 13                	je     0x12bd
    12aa:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    12ad:	26 88 45 20          	mov    BYTE PTR es:[di+0x20],al
    12b1:	6a 01                	push   0x1
    12b3:	06                   	push   es
    12b4:	57                   	push   di
    12b5:	b8 ff ff             	mov    ax,0xffff
    12b8:	9a 6a 20 9f 13       	call   0x139f:0x206a
    12bd:	c9                   	leave
    12be:	ca 06 00             	retf   0x6
    12c1:	55                   	push   bp
    12c2:	89 e5                	mov    bp,sp
    12c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12c7:	81 c7 27 00          	add    di,0x27
    12cb:	06                   	push   es
    12cc:	57                   	push   di
    12cd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    12d0:	06                   	push   es
    12d1:	57                   	push   di
    12d2:	9a 51 06 49 14       	call   0x1449:0x651
    12d7:	c9                   	leave
    12d8:	ca 08 00             	retf   0x8
    12db:	55                   	push   bp
    12dc:	89 e5                	mov    bp,sp
    12de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12e1:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
    12e5:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    12e8:	74 38                	je     0x1322
    12ea:	26 8b 45 45          	mov    ax,WORD PTR es:[di+0x45]
    12ee:	26 0b 45 47          	or     ax,WORD PTR es:[di+0x47]
    12f2:	74 24                	je     0x1318
    12f4:	ff 76 08             	push   WORD PTR [bp+0x8]
    12f7:	ff 76 06             	push   WORD PTR [bp+0x6]
    12fa:	26 c4 7d 45          	les    di,DWORD PTR es:[di+0x45]
    12fe:	06                   	push   es
    12ff:	57                   	push   di
    1300:	9a 2b 16 16 13       	call   0x1316:0x162b
    1305:	50                   	push   ax
    1306:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1309:	50                   	push   ax
    130a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    130d:	26 c4 7d 45          	les    di,DWORD PTR es:[di+0x45]
    1311:	06                   	push   es
    1312:	57                   	push   di
    1313:	9a a3 0f ce 13       	call   0x13ce:0xfa3
    1318:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    131b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    131e:	26 88 45 32          	mov    BYTE PTR es:[di+0x32],al
    1322:	c9                   	leave
    1323:	ca 06 00             	retf   0x6
    1326:	c8 02 00 00          	enter  0x2,0x0
    132a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    132d:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    1331:	26 0b 45 2d          	or     ax,WORD PTR es:[di+0x2d]
    1335:	75 07                	jne    0x133e
    1337:	31 c0                	xor    ax,ax
    1339:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    133c:	eb 0e                	jmp    0x134c
    133e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1341:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    1345:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1349:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    134c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    134f:	c9                   	leave
    1350:	ca 04 00             	retf   0x4
    1353:	c8 04 00 00          	enter  0x4,0x0
    1357:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    135a:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    135e:	26 0b 45 2d          	or     ax,WORD PTR es:[di+0x2d]
    1362:	75 03                	jne    0x1367
    1364:	e8 6f f1             	call   0x4d6
    1367:	ff 76 0a             	push   WORD PTR [bp+0xa]
    136a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    136d:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    1371:	06                   	push   es
    1372:	57                   	push   di
    1373:	9a d0 0d 1e 14       	call   0x141e:0xdd0
    1378:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    137b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    137e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1381:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1384:	c9                   	leave
    1385:	ca 06 00             	retf   0x6
    1388:	55                   	push   bp
    1389:	89 e5                	mov    bp,sp
    138b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    138e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1391:	26 89 45 2f          	mov    WORD PTR es:[di+0x2f],ax
    1395:	6a 01                	push   0x1
    1397:	06                   	push   es
    1398:	57                   	push   di
    1399:	b8 ff ff             	mov    ax,0xffff
    139c:	9a 6a 20 bc 13       	call   0x13bc:0x206a
    13a1:	c9                   	leave
    13a2:	ca 06 00             	retf   0x6
    13a5:	55                   	push   bp
    13a6:	89 e5                	mov    bp,sp
    13a8:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    13ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ae:	26 88 45 31          	mov    BYTE PTR es:[di+0x31],al
    13b2:	6a 01                	push   0x1
    13b4:	06                   	push   es
    13b5:	57                   	push   di
    13b6:	b8 ff ff             	mov    ax,0xffff
    13b9:	9a 6a 20 60 14       	call   0x1460:0x206a
    13be:	c9                   	leave
    13bf:	ca 06 00             	retf   0x6
    13c2:	c8 08 00 00          	enter  0x8,0x0
    13c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13c9:	06                   	push   es
    13ca:	57                   	push   di
    13cb:	9a 26 13 ee 13       	call   0x13ee:0x1326
    13d0:	48                   	dec    ax
    13d1:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    13d4:	31 c0                	xor    ax,ax
    13d6:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    13d9:	7f 4d                	jg     0x1428
    13db:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    13de:	eb 03                	jmp    0x13e3
    13e0:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    13e3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    13e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e9:	06                   	push   es
    13ea:	57                   	push   di
    13eb:	9a 53 13 52 14       	call   0x1452:0x1353
    13f0:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    13f3:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    13f6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    13f9:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    13fd:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    1401:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1404:	26 3b 55 14          	cmp    dx,WORD PTR es:[di+0x14]
    1408:	75 16                	jne    0x1420
    140a:	26 3b 45 12          	cmp    ax,WORD PTR es:[di+0x12]
    140e:	75 10                	jne    0x1420
    1410:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1413:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1416:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1419:	06                   	push   es
    141a:	57                   	push   di
    141b:	9a 2a 43 76 14       	call   0x1476:0x432a
    1420:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1423:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1426:	75 b8                	jne    0x13e0
    1428:	c9                   	leave
    1429:	ca 08 00             	retf   0x8
    142c:	c8 00 01 00          	enter  0x100,0x0
    1430:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1433:	26 8b 45 45          	mov    ax,WORD PTR es:[di+0x45]
    1437:	26 0b 45 47          	or     ax,WORD PTR es:[di+0x47]
    143b:	74 25                	je     0x1462
    143d:	8d be 00 ff          	lea    di,[bp-0x100]
    1441:	16                   	push   ss
    1442:	57                   	push   di
    1443:	68 30 f0             	push   0xf030
    1446:	9a 2b 09 59 14       	call   0x1459:0x92b
    144b:	b0 01                	mov    al,0x1
    144d:	50                   	push   ax
    144e:	b8 22 00             	mov    ax,0x22
    1451:	ba eb 14             	mov    dx,0x14eb
    1454:	52                   	push   dx
    1455:	50                   	push   ax
    1456:	9a e6 28 a7 16       	call   0x16a7:0x28e6
    145b:	52                   	push   dx
    145c:	50                   	push   ax
    145d:	9a 99 13 7d 14       	call   0x147d:0x1399
    1462:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1465:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    1469:	26 0b 45 2d          	or     ax,WORD PTR es:[di+0x2d]
    146d:	75 1b                	jne    0x148a
    146f:	b0 01                	mov    al,0x1
    1471:	50                   	push   ax
    1472:	b8 a3 02             	mov    ax,0x2a3
    1475:	ba b4 14             	mov    dx,0x14b4
    1478:	52                   	push   dx
    1479:	50                   	push   ax
    147a:	9a 50 1f 66 15       	call   0x1566:0x1f50
    147f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1482:	26 89 45 2b          	mov    WORD PTR es:[di+0x2b],ax
    1486:	26 89 55 2d          	mov    WORD PTR es:[di+0x2d],dx
    148a:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    148d:	48                   	dec    ax
    148e:	09 c0                	or     ax,ax
    1490:	7c 5b                	jl     0x14ed
    1492:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    1495:	48                   	dec    ax
    1496:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1499:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    149d:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    14a1:	7d 4a                	jge    0x14ed
    14a3:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    14a6:	48                   	dec    ax
    14a7:	50                   	push   ax
    14a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14ab:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    14af:	06                   	push   es
    14b0:	57                   	push   di
    14b1:	9a d0 0d d8 14       	call   0x14d8:0xdd0
    14b6:	89 c7                	mov    di,ax
    14b8:	8e c2                	mov    es,dx
    14ba:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
    14be:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    14c1:	26 3a 45 32          	cmp    al,BYTE PTR es:[di+0x32]
    14c5:	76 26                	jbe    0x14ed
    14c7:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    14ca:	48                   	dec    ax
    14cb:	50                   	push   ax
    14cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14cf:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    14d3:	06                   	push   es
    14d4:	57                   	push   di
    14d5:	9a d0 0d 17 15       	call   0x1517:0xdd0
    14da:	89 c7                	mov    di,ax
    14dc:	8e c2                	mov    es,dx
    14de:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
    14e2:	50                   	push   ax
    14e3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    14e6:	06                   	push   es
    14e7:	57                   	push   di
    14e8:	9a db 12 00 15       	call   0x1500:0x12db
    14ed:	ff 76 0e             	push   WORD PTR [bp+0xe]
    14f0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    14f3:	26 8a 45 32          	mov    al,BYTE PTR es:[di+0x32]
    14f7:	50                   	push   ax
    14f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14fb:	06                   	push   es
    14fc:	57                   	push   di
    14fd:	9a a3 0f 33 15       	call   0x1533:0xfa3
    1502:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1505:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1508:	ff 76 0a             	push   WORD PTR [bp+0xa]
    150b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    150e:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    1512:	06                   	push   es
    1513:	57                   	push   di
    1514:	9a a7 0e a1 15       	call   0x15a1:0xea7
    1519:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    151c:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    151f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1522:	26 89 45 45          	mov    WORD PTR es:[di+0x45],ax
    1526:	26 89 55 47          	mov    WORD PTR es:[di+0x47],dx
    152a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    152d:	06                   	push   es
    152e:	57                   	push   di
    152f:	b8 f9 16             	mov    ax,0x16f9
    1532:	ba 57 15             	mov    dx,0x1557
    1535:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1538:	26 89 45 33          	mov    WORD PTR es:[di+0x33],ax
    153c:	26 89 55 35          	mov    WORD PTR es:[di+0x35],dx
    1540:	26 8f 45 37          	pop    WORD PTR es:[di+0x37]
    1544:	26 8f 45 39          	pop    WORD PTR es:[di+0x39]
    1548:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    154b:	26 83 7d 21 00       	cmp    WORD PTR es:[di+0x21],0x0
    1550:	74 07                	je     0x1559
    1552:	06                   	push   es
    1553:	57                   	push   di
    1554:	9a 58 0f 88 15       	call   0x1588:0xf58
    1559:	6a 01                	push   0x1
    155b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    155e:	06                   	push   es
    155f:	57                   	push   di
    1560:	b8 ff ff             	mov    ax,0xffff
    1563:	9a 6a 20 fa 15       	call   0x15fa:0x206a
    1568:	c9                   	leave
    1569:	ca 0a 00             	retf   0xa
    156c:	c8 04 00 00          	enter  0x4,0x0
    1570:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    1574:	7c 19                	jl     0x158f
    1576:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1579:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    157d:	26 0b 45 2d          	or     ax,WORD PTR es:[di+0x2d]
    1581:	74 0c                	je     0x158f
    1583:	06                   	push   es
    1584:	57                   	push   di
    1585:	9a 26 13 eb 15       	call   0x15eb:0x1326
    158a:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    158d:	7f 03                	jg     0x1592
    158f:	e8 44 ef             	call   0x4d6
    1592:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1595:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1598:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    159c:	06                   	push   es
    159d:	57                   	push   di
    159e:	9a d0 0d b8 15       	call   0x15b8:0xdd0
    15a3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    15a6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    15a9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    15ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15af:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    15b3:	06                   	push   es
    15b4:	57                   	push   di
    15b5:	9a 94 0c 50 16       	call   0x1650:0xc94
    15ba:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    15bd:	31 c0                	xor    ax,ax
    15bf:	26 89 45 45          	mov    WORD PTR es:[di+0x45],ax
    15c3:	26 89 45 47          	mov    WORD PTR es:[di+0x47],ax
    15c7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    15ca:	31 c0                	xor    ax,ax
    15cc:	26 89 45 33          	mov    WORD PTR es:[di+0x33],ax
    15d0:	26 89 45 35          	mov    WORD PTR es:[di+0x35],ax
    15d4:	26 89 45 37          	mov    WORD PTR es:[di+0x37],ax
    15d8:	26 89 45 39          	mov    WORD PTR es:[di+0x39],ax
    15dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15df:	26 83 7d 21 00       	cmp    WORD PTR es:[di+0x21],0x0
    15e4:	74 07                	je     0x15ed
    15e6:	06                   	push   es
    15e7:	57                   	push   di
    15e8:	9a 58 0f 67 16       	call   0x1667:0xf58
    15ed:	6a 01                	push   0x1
    15ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15f2:	06                   	push   es
    15f3:	57                   	push   di
    15f4:	b8 ff ff             	mov    ax,0xffff
    15f7:	9a 6a 20 be 16       	call   0x16be:0x206a
    15fc:	c9                   	leave
    15fd:	ca 06 00             	retf   0x6
    1600:	55                   	push   bp
    1601:	89 e5                	mov    bp,sp
    1603:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1606:	26 80 7d 20 00       	cmp    BYTE PTR es:[di+0x20],0x0
    160b:	74 1a                	je     0x1627
    160d:	26 8b 45 3d          	mov    ax,WORD PTR es:[di+0x3d]
    1611:	09 c0                	or     ax,ax
    1613:	74 12                	je     0x1627
    1615:	ff 76 08             	push   WORD PTR [bp+0x8]
    1618:	ff 76 06             	push   WORD PTR [bp+0x6]
    161b:	26 ff 75 41          	push   WORD PTR es:[di+0x41]
    161f:	26 ff 75 3f          	push   WORD PTR es:[di+0x3f]
    1623:	26 ff 5d 3b          	call   DWORD PTR es:[di+0x3b]
    1627:	c9                   	leave
    1628:	ca 04 00             	retf   0x4
    162b:	c8 02 00 00          	enter  0x2,0x0
    162f:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    1634:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1637:	26 8b 45 2b          	mov    ax,WORD PTR es:[di+0x2b]
    163b:	26 0b 45 2d          	or     ax,WORD PTR es:[di+0x2d]
    163f:	74 14                	je     0x1655
    1641:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1644:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1647:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    164b:	06                   	push   es
    164c:	57                   	push   di
    164d:	9a 58 0e ca 17       	call   0x17ca:0xe58
    1652:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1655:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1658:	c9                   	leave
    1659:	ca 08 00             	retf   0x8
    165c:	55                   	push   bp
    165d:	89 e5                	mov    bp,sp
    165f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1662:	06                   	push   es
    1663:	57                   	push   di
    1664:	9a 26 13 78 16       	call   0x1678:0x1326
    1669:	50                   	push   ax
    166a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    166d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1670:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1673:	06                   	push   es
    1674:	57                   	push   di
    1675:	9a 2c 14 90 16       	call   0x1690:0x142c
    167a:	c9                   	leave
    167b:	ca 08 00             	retf   0x8
    167e:	c8 02 01 00          	enter  0x102,0x0
    1682:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1685:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1688:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    168b:	06                   	push   es
    168c:	57                   	push   di
    168d:	9a 2b 16 b0 16       	call   0x16b0:0x162b
    1692:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1695:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    1699:	75 25                	jne    0x16c0
    169b:	8d be fe fe          	lea    di,[bp-0x102]
    169f:	16                   	push   ss
    16a0:	57                   	push   di
    16a1:	68 31 f0             	push   0xf031
    16a4:	9a 2b 09 b7 16       	call   0x16b7:0x92b
    16a9:	b0 01                	mov    al,0x1
    16ab:	50                   	push   ax
    16ac:	b8 22 00             	mov    ax,0x22
    16af:	ba cb 16             	mov    dx,0x16cb
    16b2:	52                   	push   dx
    16b3:	50                   	push   ax
    16b4:	9a e6 28 63 1c       	call   0x1c63:0x28e6
    16b9:	52                   	push   dx
    16ba:	50                   	push   ax
    16bb:	9a 99 13 4b 17       	call   0x174b:0x1399
    16c0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    16c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16c6:	06                   	push   es
    16c7:	57                   	push   di
    16c8:	9a 6c 15 11 17       	call   0x1711:0x156c
    16cd:	c9                   	leave
    16ce:	ca 08 00             	retf   0x8
    16d1:	55                   	push   bp
    16d2:	89 e5                	mov    bp,sp
    16d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16d7:	26 8b 45 35          	mov    ax,WORD PTR es:[di+0x35]
    16db:	09 c0                	or     ax,ax
    16dd:	74 16                	je     0x16f5
    16df:	ff 76 08             	push   WORD PTR [bp+0x8]
    16e2:	ff 76 06             	push   WORD PTR [bp+0x6]
    16e5:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    16e8:	50                   	push   ax
    16e9:	26 ff 75 39          	push   WORD PTR es:[di+0x39]
    16ed:	26 ff 75 37          	push   WORD PTR es:[di+0x37]
    16f1:	26 ff 5d 33          	call   DWORD PTR es:[di+0x33]
    16f5:	c9                   	leave
    16f6:	ca 06 00             	retf   0x6
    16f9:	55                   	push   bp
    16fa:	89 e5                	mov    bp,sp
    16fc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1700:	74 11                	je     0x1713
    1702:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1705:	26 83 7d 21 00       	cmp    WORD PTR es:[di+0x21],0x0
    170a:	74 07                	je     0x1713
    170c:	06                   	push   es
    170d:	57                   	push   di
    170e:	9a 58 0f 31 17       	call   0x1731:0xf58
    1713:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1716:	26 8b 45 45          	mov    ax,WORD PTR es:[di+0x45]
    171a:	26 0b 45 47          	or     ax,WORD PTR es:[di+0x47]
    171e:	74 15                	je     0x1735
    1720:	ff 76 08             	push   WORD PTR [bp+0x8]
    1723:	ff 76 06             	push   WORD PTR [bp+0x6]
    1726:	6a 00                	push   0x0
    1728:	26 c4 7d 45          	les    di,DWORD PTR es:[di+0x45]
    172c:	06                   	push   es
    172d:	57                   	push   di
    172e:	9a f9 16 44 17       	call   0x1744:0x16f9
    1733:	eb 2a                	jmp    0x175f
    1735:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1738:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    173c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1740:	bf ef 02             	mov    di,0x2ef
    1743:	b8 5d 17             	mov    ax,0x175d
    1746:	50                   	push   ax
    1747:	57                   	push   di
    1748:	9a 55 22 72 17       	call   0x1772:0x2255
    174d:	08 c0                	or     al,al
    174f:	74 0e                	je     0x175f
    1751:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1754:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1758:	06                   	push   es
    1759:	57                   	push   di
    175a:	9a 6c 1e 81 17       	call   0x1781:0x1e6c
    175f:	c9                   	leave
    1760:	ca 0a 00             	retf   0xa
    1763:	55                   	push   bp
    1764:	89 e5                	mov    bp,sp
    1766:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    176a:	74 08                	je     0x1774
    176c:	83 ec 08             	sub    sp,0x8
    176f:	9a e2 1f f2 17       	call   0x17f2:0x1fe2
    1774:	ff 76 08             	push   WORD PTR [bp+0x8]
    1777:	ff 76 06             	push   WORD PTR [bp+0x6]
    177a:	b0 01                	mov    al,0x1
    177c:	50                   	push   ax
    177d:	b8 94 00             	mov    ax,0x94
    1780:	ba 88 17             	mov    dx,0x1788
    1783:	52                   	push   dx
    1784:	50                   	push   ax
    1785:	9a 9b 0b 20 18       	call   0x1820:0xb9b
    178a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    178d:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    1791:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    1795:	06                   	push   es
    1796:	57                   	push   di
    1797:	26 c4 3d             	les    di,DWORD PTR es:[di]
    179a:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    179e:	26 8b 55 32          	mov    dx,WORD PTR es:[di+0x32]
    17a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17a5:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    17a9:	26 89 45 33          	mov    WORD PTR es:[di+0x33],ax
    17ad:	26 89 55 35          	mov    WORD PTR es:[di+0x35],dx
    17b1:	26 8f 45 37          	pop    WORD PTR es:[di+0x37]
    17b5:	26 8f 45 39          	pop    WORD PTR es:[di+0x39]
    17b9:	ff 76 0e             	push   WORD PTR [bp+0xe]
    17bc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    17bf:	31 c0                	xor    ax,ax
    17c1:	50                   	push   ax
    17c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17c5:	06                   	push   es
    17c6:	57                   	push   di
    17c7:	9a d9 4b ff 17       	call   0x17ff:0x4bd9
    17cc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    17d0:	74 07                	je     0x17d9
    17d2:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    17d6:	83 c4 06             	add    sp,0x6
    17d9:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    17dc:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    17df:	c9                   	leave
    17e0:	ca 0a 00             	retf   0xa
    17e3:	55                   	push   bp
    17e4:	89 e5                	mov    bp,sp
    17e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e9:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    17ed:	06                   	push   es
    17ee:	57                   	push   di
    17ef:	9a 7f 1f 0a 18       	call   0x180a:0x1f7f
    17f4:	31 c0                	xor    ax,ax
    17f6:	50                   	push   ax
    17f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17fa:	06                   	push   es
    17fb:	57                   	push   di
    17fc:	9a 2b 4c dc 1e       	call   0x1edc:0x4c2b
    1801:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1805:	74 05                	je     0x180c
    1807:	9a 0f 20 1d 1b       	call   0x1b1d:0x200f
    180c:	c9                   	leave
    180d:	ca 06 00             	retf   0x6
    1810:	c8 02 00 00          	enter  0x2,0x0
    1814:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1817:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    181b:	06                   	push   es
    181c:	57                   	push   di
    181d:	9a 5d 10 b7 18       	call   0x18b7:0x105d
    1822:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1825:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1828:	c9                   	leave
    1829:	ca 04 00             	retf   0x4
    182c:	55                   	push   bp
    182d:	89 e5                	mov    bp,sp
    182f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1832:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1835:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1838:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    183c:	06                   	push   es
    183d:	57                   	push   di
    183e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1841:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1845:	c9                   	leave
    1846:	ca 08 00             	retf   0x8
    1849:	c8 06 00 00          	enter  0x6,0x0
    184d:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1851:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1854:	36 80 7d 0a 00       	cmp    BYTE PTR ss:[di+0xa],0x0
    1859:	75 0d                	jne    0x1868
    185b:	36 8b 45 0c          	mov    ax,WORD PTR ss:[di+0xc]
    185f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1862:	26 3b 45 43          	cmp    ax,WORD PTR es:[di+0x43]
    1866:	74 2e                	je     0x1896
    1868:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    186b:	36 80 7d 0a 01       	cmp    BYTE PTR ss:[di+0xa],0x1
    1870:	75 0d                	jne    0x187f
    1872:	36 8b 45 0c          	mov    ax,WORD PTR ss:[di+0xc]
    1876:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1879:	26 3b 45 21          	cmp    ax,WORD PTR es:[di+0x21]
    187d:	74 17                	je     0x1896
    187f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1882:	36 80 7d 0a 02       	cmp    BYTE PTR ss:[di+0xa],0x2
    1887:	75 26                	jne    0x18af
    1889:	36 8b 45 0c          	mov    ax,WORD PTR ss:[di+0xc]
    188d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1890:	26 3b 45 2f          	cmp    ax,WORD PTR es:[di+0x2f]
    1894:	75 19                	jne    0x18af
    1896:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1899:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    189c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    189f:	36 89 45 f8          	mov    WORD PTR ss:[di-0x8],ax
    18a3:	36 89 55 fa          	mov    WORD PTR ss:[di-0x6],dx
    18a7:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    18ab:	eb 47                	jmp    0x18f4
    18ad:	eb 45                	jmp    0x18f4
    18af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18b2:	06                   	push   es
    18b3:	57                   	push   di
    18b4:	9a 26 13 d7 18       	call   0x18d7:0x1326
    18b9:	48                   	dec    ax
    18ba:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    18bd:	31 c0                	xor    ax,ax
    18bf:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    18c2:	7f 30                	jg     0x18f4
    18c4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    18c7:	eb 03                	jmp    0x18cc
    18c9:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    18cc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    18cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18d2:	06                   	push   es
    18d3:	57                   	push   di
    18d4:	9a 53 13 0b 19       	call   0x190b:0x1353
    18d9:	52                   	push   dx
    18da:	50                   	push   ax
    18db:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    18de:	57                   	push   di
    18df:	e8 67 ff             	call   0x1849
    18e2:	08 c0                	or     al,al
    18e4:	74 06                	je     0x18ec
    18e6:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    18ea:	eb 08                	jmp    0x18f4
    18ec:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    18ef:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    18f2:	75 d5                	jne    0x18c9
    18f4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    18f7:	c9                   	leave
    18f8:	c2 06 00             	ret    0x6
    18fb:	c8 08 00 00          	enter  0x8,0x0
    18ff:	31 c0                	xor    ax,ax
    1901:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1904:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1907:	bf 49 18             	mov    di,0x1849
    190a:	b8 6b 19             	mov    ax,0x196b
    190d:	50                   	push   ax
    190e:	57                   	push   di
    190f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1912:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1916:	26 ff 75 4b          	push   WORD PTR es:[di+0x4b]
    191a:	26 ff 75 49          	push   WORD PTR es:[di+0x49]
    191e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1921:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1925:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1929:	e8 35 f1             	call   0xa61
    192c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    192f:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    1932:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1935:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1938:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    193b:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    193e:	c9                   	leave
    193f:	ca 08 00             	retf   0x8
    1942:	c8 0a 00 00          	enter  0xa,0x0
    1946:	31 c0                	xor    ax,ax
    1948:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    194b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    194e:	c6 46 f7 01          	mov    BYTE PTR [bp-0x9],0x1
    1952:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1956:	74 04                	je     0x195c
    1958:	c6 46 f7 00          	mov    BYTE PTR [bp-0x9],0x0
    195c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    195f:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
    1962:	50                   	push   ax
    1963:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1966:	06                   	push   es
    1967:	57                   	push   di
    1968:	9a fb 18 d3 19       	call   0x19d3:0x18fb
    196d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1970:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1973:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1976:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    1979:	74 20                	je     0x199b
    197b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    197e:	26 8b 45 23          	mov    ax,WORD PTR es:[di+0x23]
    1982:	26 0b 45 25          	or     ax,WORD PTR es:[di+0x25]
    1986:	75 13                	jne    0x199b
    1988:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    198b:	26 8b 45 45          	mov    ax,WORD PTR es:[di+0x45]
    198f:	26 8b 55 47          	mov    dx,WORD PTR es:[di+0x47]
    1993:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1996:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1999:	eb d8                	jmp    0x1973
    199b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    199e:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    19a1:	74 11                	je     0x19b4
    19a3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    19a6:	26 8b 45 23          	mov    ax,WORD PTR es:[di+0x23]
    19aa:	26 8b 55 25          	mov    dx,WORD PTR es:[di+0x25]
    19ae:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    19b1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    19b4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    19b7:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    19ba:	c9                   	leave
    19bb:	ca 08 00             	retf   0x8
    19be:	c8 06 00 00          	enter  0x6,0x0
    19c2:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    19c6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    19c9:	6a 00                	push   0x0
    19cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19ce:	06                   	push   es
    19cf:	57                   	push   di
    19d0:	9a fb 18 0f 1a       	call   0x1a0f:0x18fb
    19d5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    19d8:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    19db:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    19de:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    19e1:	74 10                	je     0x19f3
    19e3:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    19e6:	06                   	push   es
    19e7:	57                   	push   di
    19e8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    19eb:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    19ef:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    19f3:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    19f6:	c9                   	leave
    19f7:	ca 06 00             	retf   0x6
    19fa:	c8 06 00 00          	enter  0x6,0x0
    19fe:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1a02:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1a05:	6a 01                	push   0x1
    1a07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a0a:	06                   	push   es
    1a0b:	57                   	push   di
    1a0c:	9a fb 18 7f 1a       	call   0x1a7f:0x18fb
    1a11:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1a14:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1a17:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1a1a:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    1a1d:	74 10                	je     0x1a2f
    1a1f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1a22:	06                   	push   es
    1a23:	57                   	push   di
    1a24:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a27:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    1a2b:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1a2f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1a32:	c9                   	leave
    1a33:	ca 06 00             	retf   0x6
    1a36:	c8 02 00 00          	enter  0x2,0x0
    1a3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a3d:	26 80 7d 20 00       	cmp    BYTE PTR es:[di+0x20],0x0
    1a42:	74 23                	je     0x1a67
    1a44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a47:	26 8b 45 45          	mov    ax,WORD PTR es:[di+0x45]
    1a4b:	26 0b 45 47          	or     ax,WORD PTR es:[di+0x47]
    1a4f:	74 1a                	je     0x1a6b
    1a51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a54:	26 ff 75 47          	push   WORD PTR es:[di+0x47]
    1a58:	26 ff 75 45          	push   WORD PTR es:[di+0x45]
    1a5c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1a5f:	57                   	push   di
    1a60:	e8 d3 ff             	call   0x1a36
    1a63:	08 c0                	or     al,al
    1a65:	75 04                	jne    0x1a6b
    1a67:	b0 00                	mov    al,0x0
    1a69:	eb 02                	jmp    0x1a6d
    1a6b:	b0 01                	mov    al,0x1
    1a6d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1a70:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1a73:	c9                   	leave
    1a74:	c2 06 00             	ret    0x6
    1a77:	01 00                	add    WORD PTR [bx+si],ax
    1a79:	00 00                	add    BYTE PTR [bx+si],al
    1a7b:	00 00                	add    BYTE PTR [bx+si],al
    1a7d:	04 1b                	add    al,0x1b
    1a7f:	93                   	xchg   bx,ax
    1a80:	1b c8                	sbb    cx,ax
    1a82:	02 00                	add    al,BYTE PTR [bx+si]
    1a84:	00 c6                	add    dh,al
    1a86:	46                   	inc    si
    1a87:	ff 00                	inc    WORD PTR [bx+si]
    1a89:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1a8c:	26 80 7d 20 00       	cmp    BYTE PTR es:[di+0x20],0x0
    1a91:	75 03                	jne    0x1a96
    1a93:	e9 8d 00             	jmp    0x1b23
    1a96:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1a99:	26 8b 45 45          	mov    ax,WORD PTR es:[di+0x45]
    1a9d:	26 0b 45 47          	or     ax,WORD PTR es:[di+0x47]
    1aa1:	74 21                	je     0x1ac4
    1aa3:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1aa6:	26 ff 75 47          	push   WORD PTR es:[di+0x47]
    1aaa:	26 ff 75 45          	push   WORD PTR es:[di+0x45]
    1aae:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1ab1:	26 c4 7d 45          	les    di,DWORD PTR es:[di+0x45]
    1ab5:	26 ff 75 2f          	push   WORD PTR es:[di+0x2f]
    1ab9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1abc:	57                   	push   di
    1abd:	e8 c1 ff             	call   0x1a81
    1ac0:	08 c0                	or     al,al
    1ac2:	74 5f                	je     0x1b23
    1ac4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ac7:	ff 76 08             	push   WORD PTR [bp+0x8]
    1aca:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1acd:	57                   	push   di
    1ace:	e8 65 ff             	call   0x1a36
    1ad1:	08 c0                	or     al,al
    1ad3:	74 4e                	je     0x1b23
    1ad5:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1ad8:	26 8b 45 2f          	mov    ax,WORD PTR es:[di+0x2f]
    1adc:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    1adf:	75 42                	jne    0x1b23
    1ae1:	b8 77 1a             	mov    ax,0x1a77
    1ae4:	0e                   	push   cs
    1ae5:	50                   	push   ax
    1ae6:	55                   	push   bp
    1ae7:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1aeb:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1aef:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1af2:	06                   	push   es
    1af3:	57                   	push   di
    1af4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1af7:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    1afb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1aff:	83 c4 06             	add    sp,0x6
    1b02:	eb 1b                	jmp    0x1b1f
    1b04:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1b07:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    1b0b:	36 ff 75 06          	push   WORD PTR ss:[di+0x6]
    1b0f:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1b13:	06                   	push   es
    1b14:	57                   	push   di
    1b15:	9a 51 75 03 20       	call   0x2003:0x7551
    1b1a:	9a 34 14 d4 1e       	call   0x1ed4:0x1434
    1b1f:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1b23:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1b26:	c9                   	leave
    1b27:	c2 08 00             	ret    0x8
    1b2a:	c8 08 00 00          	enter  0x8,0x0
    1b2e:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1b32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b35:	26 83 7d 1e 00       	cmp    WORD PTR es:[di+0x1e],0x0
    1b3a:	75 03                	jne    0x1b3f
    1b3c:	e9 b3 00             	jmp    0x1bf2
    1b3f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b42:	26 8a 45 02          	mov    al,BYTE PTR es:[di+0x2]
    1b46:	30 e4                	xor    ah,ah
    1b48:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b4b:	6a 10                	push   0x10
    1b4d:	9a 5e 1b 00 00       	call   0x0:0x1b5e
    1b52:	09 c0                	or     ax,ax
    1b54:	7d 05                	jge    0x1b5b
    1b56:	81 46 fc 00 20       	add    WORD PTR [bp-0x4],0x2000
    1b5b:	6a 11                	push   0x11
    1b5d:	9a 46 20 00 00       	call   0x0:0x2046
    1b62:	09 c0                	or     ax,ax
    1b64:	7d 05                	jge    0x1b6b
    1b66:	81 46 fc 00 40       	add    WORD PTR [bp-0x4],0x4000
    1b6b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b6e:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1b72:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    1b76:	25 00 00             	and    ax,0x0
    1b79:	81 e2 00 20          	and    dx,0x2000
    1b7d:	09 d0                	or     ax,dx
    1b7f:	74 05                	je     0x1b86
    1b81:	81 46 fc 00 80       	add    WORD PTR [bp-0x4],0x8000
    1b86:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b89:	6a 02                	push   0x2
    1b8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b8e:	06                   	push   es
    1b8f:	57                   	push   di
    1b90:	9a fb 18 d2 1b       	call   0x1bd2:0x18fb
    1b95:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1b98:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1b9b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1b9e:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    1ba1:	74 4f                	je     0x1bf2
    1ba3:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1ba6:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1ba9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1bac:	55                   	push   bp
    1bad:	e8 d1 fe             	call   0x1a81
    1bb0:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1bb3:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1bb7:	75 39                	jne    0x1bf2
    1bb9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1bbc:	26 8b 45 2f          	mov    ax,WORD PTR es:[di+0x2f]
    1bc0:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1bc3:	74 2d                	je     0x1bf2
    1bc5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1bc8:	6a 02                	push   0x2
    1bca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bcd:	06                   	push   es
    1bce:	57                   	push   di
    1bcf:	9a fb 18 89 1d       	call   0x1d89:0x18fb
    1bd4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1bd7:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1bda:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1bdd:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    1be0:	74 10                	je     0x1bf2
    1be2:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1be5:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1be8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1beb:	55                   	push   bp
    1bec:	e8 92 fe             	call   0x1a81
    1bef:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1bf2:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1bf5:	c9                   	leave
    1bf6:	ca 08 00             	retf   0x8
    1bf9:	c8 0e 00 00          	enter  0xe,0x0
    1bfd:	ff 76 06             	push   WORD PTR [bp+0x6]
    1c00:	9a ff ff 00 00       	call   0x0:0xffff
    1c05:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1c08:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1c0b:	36 8d 85 fe fd       	lea    ax,ss:[di-0x202]
    1c10:	8c d2                	mov    dx,ss
    1c12:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c15:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1c18:	36 8d 45 f9          	lea    ax,ss:[di-0x7]
    1c1c:	8c d2                	mov    dx,ss
    1c1e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1c21:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1c24:	31 c0                	xor    ax,ax
    1c26:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1c29:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1c2c:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1c2f:	7c 03                	jl     0x1c34
    1c31:	e9 c4 00             	jmp    0x1cf8
    1c34:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1c37:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1c3a:	72 03                	jb     0x1c3f
    1c3c:	e9 b9 00             	jmp    0x1cf8
    1c3f:	ff 76 06             	push   WORD PTR [bp+0x6]
    1c42:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1c45:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c48:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c4b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1c4e:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    1c51:	50                   	push   ax
    1c52:	68 00 04             	push   0x400
    1c55:	9a ff ff 00 00       	call   0x0:0xffff
    1c5a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c5d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c60:	9a a3 0c 94 1c       	call   0x1c94:0xca3
    1c65:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c68:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1c6b:	ff 76 06             	push   WORD PTR [bp+0x6]
    1c6e:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1c71:	68 00 04             	push   0x400
    1c74:	9a ff ff 00 00       	call   0x0:0xffff
    1c79:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1c7c:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    1c7f:	25 02 00             	and    ax,0x2
    1c82:	09 c0                	or     ax,ax
    1c84:	74 16                	je     0x1c9c
    1c86:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c89:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c8c:	bf d6 13             	mov    di,0x13d6
    1c8f:	1e                   	push   ds
    1c90:	57                   	push   di
    1c91:	9a 01 0d b4 1c       	call   0x1cb4:0xd01
    1c96:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c99:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1c9c:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    1c9f:	25 40 00             	and    ax,0x40
    1ca2:	09 c0                	or     ax,ax
    1ca4:	74 16                	je     0x1cbc
    1ca6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ca9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1cac:	bf d8 13             	mov    di,0x13d8
    1caf:	1e                   	push   ds
    1cb0:	57                   	push   di
    1cb1:	9a 01 0d d4 1c       	call   0x1cd4:0xd01
    1cb6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1cb9:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1cbc:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    1cbf:	25 01 00             	and    ax,0x1
    1cc2:	09 c0                	or     ax,ax
    1cc4:	74 16                	je     0x1cdc
    1cc6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1cc9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ccc:	bf da 13             	mov    di,0x13da
    1ccf:	1e                   	push   ds
    1cd0:	57                   	push   di
    1cd1:	9a 01 0d ea 1c       	call   0x1cea:0xd01
    1cd6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1cd9:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1cdc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1cdf:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ce2:	bf dc 13             	mov    di,0x13dc
    1ce5:	1e                   	push   ds
    1ce6:	57                   	push   di
    1ce7:	9a 01 0d 33 1d       	call   0x1d33:0xd01
    1cec:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1cef:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1cf2:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    1cf5:	e9 31 ff             	jmp    0x1c29
    1cf8:	c9                   	leave
    1cf9:	c2 04 00             	ret    0x4
    1cfc:	c8 02 02 00          	enter  0x202,0x0
    1d00:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1d04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d07:	06                   	push   es
    1d08:	57                   	push   di
    1d09:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d0c:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1d10:	50                   	push   ax
    1d11:	55                   	push   bp
    1d12:	e8 e4 fe             	call   0x1bf9
    1d15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d18:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    1d1c:	26 0b 45 22          	or     ax,WORD PTR es:[di+0x22]
    1d20:	74 17                	je     0x1d39
    1d22:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1d26:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    1d2a:	8d be fe fd          	lea    di,[bp-0x202]
    1d2e:	16                   	push   ss
    1d2f:	57                   	push   di
    1d30:	9a b2 0d 4b 1d       	call   0x1d4b:0xdb2
    1d35:	09 c0                	or     ax,ax
    1d37:	74 37                	je     0x1d70
    1d39:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1d3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d40:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1d44:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    1d48:	9a 23 0f 63 1d       	call   0x1d63:0xf23
    1d4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d50:	31 c0                	xor    ax,ax
    1d52:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    1d56:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    1d5a:	8d be fe fd          	lea    di,[bp-0x202]
    1d5e:	16                   	push   ss
    1d5f:	57                   	push   di
    1d60:	9a d6 0e ff ff       	call   0xffff:0xed6
    1d65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d68:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    1d6c:	26 89 55 22          	mov    WORD PTR es:[di+0x22],dx
    1d70:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1d73:	c9                   	leave
    1d74:	ca 04 00             	retf   0x4
    1d77:	55                   	push   bp
    1d78:	89 e5                	mov    bp,sp
    1d7a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1d7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d80:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    1d84:	06                   	push   es
    1d85:	57                   	push   di
    1d86:	9a fc 1c db 1d       	call   0x1ddb:0x1cfc
    1d8b:	c9                   	leave
    1d8c:	ca 06 00             	retf   0x6
    1d8f:	55                   	push   bp
    1d90:	89 e5                	mov    bp,sp
    1d92:	c9                   	leave
    1d93:	ca 0a 00             	retf   0xa
    1d96:	55                   	push   bp
    1d97:	89 e5                	mov    bp,sp
    1d99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d9c:	26 8a 45 2a          	mov    al,BYTE PTR es:[di+0x2a]
    1da0:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    1da3:	74 20                	je     0x1dc5
    1da5:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1da8:	26 88 45 2a          	mov    BYTE PTR es:[di+0x2a],al
    1dac:	26 83 7d 1e 00       	cmp    WORD PTR es:[di+0x1e],0x0
    1db1:	74 12                	je     0x1dc5
    1db3:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    1db7:	68 15 0f             	push   0xf15
    1dba:	6a 00                	push   0x0
    1dbc:	6a 00                	push   0x0
    1dbe:	6a 00                	push   0x0
    1dc0:	9a 87 1e 00 00       	call   0x0:0x1e87
    1dc5:	c9                   	leave
    1dc6:	ca 06 00             	retf   0x6
    1dc9:	55                   	push   bp
    1dca:	89 e5                	mov    bp,sp
    1dcc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dcf:	26 83 7d 1e 00       	cmp    WORD PTR es:[di+0x1e],0x0
    1dd4:	74 17                	je     0x1ded
    1dd6:	06                   	push   es
    1dd7:	57                   	push   di
    1dd8:	9a fc 1c 13 1e       	call   0x1e13:0x1cfc
    1ddd:	08 c0                	or     al,al
    1ddf:	74 0c                	je     0x1ded
    1de1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1de4:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    1de8:	9a ff ff 00 00       	call   0x0:0xffff
    1ded:	c9                   	leave
    1dee:	ca 0a 00             	retf   0xa
    1df1:	55                   	push   bp
    1df2:	89 e5                	mov    bp,sp
    1df4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1df7:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1dfa:	74 1b                	je     0x1e17
    1dfc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1dff:	26 ff 75 1c          	push   WORD PTR es:[di+0x1c]
    1e03:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1e07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e0a:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1e0e:	06                   	push   es
    1e0f:	57                   	push   di
    1e10:	9a 24 0f 27 1e       	call   0x1e27:0xf24
    1e15:	eb 12                	jmp    0x1e29
    1e17:	6a 00                	push   0x0
    1e19:	6a 00                	push   0x0
    1e1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e1e:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1e22:	06                   	push   es
    1e23:	57                   	push   di
    1e24:	9a 24 0f 66 1e       	call   0x1e66:0xf24
    1e29:	c9                   	leave
    1e2a:	ca 08 00             	retf   0x8
    1e2d:	55                   	push   bp
    1e2e:	89 e5                	mov    bp,sp
    1e30:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1e33:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1e36:	74 30                	je     0x1e68
    1e38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e3b:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1e3f:	26 8b 45 49          	mov    ax,WORD PTR es:[di+0x49]
    1e43:	26 8b 55 4b          	mov    dx,WORD PTR es:[di+0x4b]
    1e47:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e4a:	26 3b 55 1c          	cmp    dx,WORD PTR es:[di+0x1c]
    1e4e:	75 18                	jne    0x1e68
    1e50:	26 3b 45 1a          	cmp    ax,WORD PTR es:[di+0x1a]
    1e54:	75 12                	jne    0x1e68
    1e56:	6a 00                	push   0x0
    1e58:	6a 00                	push   0x0
    1e5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e5d:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1e61:	06                   	push   es
    1e62:	57                   	push   di
    1e63:	9a 24 0f ae 1e       	call   0x1eae:0xf24
    1e68:	c9                   	leave
    1e69:	ca 08 00             	retf   0x8
    1e6c:	55                   	push   bp
    1e6d:	89 e5                	mov    bp,sp
    1e6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e72:	26 83 7d 1e 00       	cmp    WORD PTR es:[di+0x1e],0x0
    1e77:	74 12                	je     0x1e8b
    1e79:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    1e7d:	68 15 0f             	push   0xf15
    1e80:	6a 00                	push   0x0
    1e82:	6a 00                	push   0x0
    1e84:	6a 00                	push   0x0
    1e86:	9a ff ff 00 00       	call   0x0:0xffff
    1e8b:	c9                   	leave
    1e8c:	ca 04 00             	retf   0x4
    1e8f:	c8 02 00 00          	enter  0x2,0x0
    1e93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e96:	26 83 7d 28 00       	cmp    WORD PTR es:[di+0x28],0x0
    1e9b:	74 09                	je     0x1ea6
    1e9d:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    1ea1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ea4:	eb 0d                	jmp    0x1eb3
    1ea6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ea9:	06                   	push   es
    1eaa:	57                   	push   di
    1eab:	9a 10 18 f6 1e       	call   0x1ef6:0x1810
    1eb0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1eb3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1eb6:	c9                   	leave
    1eb7:	ca 04 00             	retf   0x4
	...
    1ec2:	e2 1e                	loop   0x1ee2
    1ec4:	12 00                	adc    al,BYTE PTR [bx+si]
    1ec6:	a3 02 41             	mov    ds:0x4102,ax
    1ec9:	1f                   	pop    ds
    1eca:	64 20 55 1f          	and    BYTE PTR fs:[di+0x1f],dl
    1ece:	9a 1f cc 1e cb       	call   0xcb1e:0xcc1f
    1ed3:	1f                   	pop    ds
    1ed4:	d0 1e 0f 0c          	rcr    BYTE PTR ds:0xc0f,1
    1ed8:	c8 1e fb 0c          	enter  0xfb1e,0xc
    1edc:	e0 1e                	loopne 0x1efc
    1ede:	17                   	pop    ss
    1edf:	0e                   	push   cs
    1ee0:	d8 1e 0a 54          	fcomp  DWORD PTR ds:0x540a
    1ee4:	50                   	push   ax
    1ee5:	6f                   	outs   dx,WORD PTR ds:[si]
    1ee6:	70 75                	jo     0x1f5d
    1ee8:	70 4c                	jo     0x1f36
    1eea:	69 73 74 00 01       	imul   si,WORD PTR [bp+di+0x74],0x100
    1eef:	00 00                	add    BYTE PTR [bx+si],al
    1ef1:	00 00                	add    BYTE PTR [bx+si],al
    1ef3:	00 bd 20 4c          	add    BYTE PTR [di+0x4c20],bh
    1ef7:	1f                   	pop    ds
    1ef8:	c8 0e 01 00          	enter  0x10e,0x0
    1efc:	b8 ee 1e             	mov    ax,0x1eee
    1eff:	0e                   	push   cs
    1f00:	50                   	push   ax
    1f01:	55                   	push   bp
    1f02:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1f06:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1f0a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1f0d:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1f10:	3d 11 01             	cmp    ax,0x111
    1f13:	75 50                	jne    0x1f65
    1f15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f18:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1f1c:	48                   	dec    ax
    1f1d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1f20:	31 c0                	xor    ax,ax
    1f22:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1f25:	7f 3b                	jg     0x1f62
    1f27:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f2a:	eb 03                	jmp    0x1f2f
    1f2c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1f2f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1f32:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1f36:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f3c:	06                   	push   es
    1f3d:	57                   	push   di
    1f3e:	9a d0 0d b9 1f       	call   0x1fb9:0xdd0
    1f43:	89 c7                	mov    di,ax
    1f45:	8e c2                	mov    es,dx
    1f47:	06                   	push   es
    1f48:	57                   	push   di
    1f49:	9a be 19 c4 1f       	call   0x1fc4:0x19be
    1f4e:	08 c0                	or     al,al
    1f50:	74 08                	je     0x1f5a
    1f52:	9a 6a 14 08 20       	call   0x2008:0x146a
    1f57:	e9 79 01             	jmp    0x20d3
    1f5a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f5d:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1f60:	75 ca                	jne    0x1f2c
    1f62:	e9 1d 01             	jmp    0x2082
    1f65:	3d 1f 01             	cmp    ax,0x11f
    1f68:	74 03                	je     0x1f6d
    1f6a:	e9 c7 00             	jmp    0x2034
    1f6d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1f70:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1f73:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1f76:	c6 46 f9 00          	mov    BYTE PTR [bp-0x7],0x0
    1f7a:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1f7e:	25 10 00             	and    ax,0x10
    1f81:	09 c0                	or     ax,ax
    1f83:	74 04                	je     0x1f89
    1f85:	c6 46 f9 01          	mov    BYTE PTR [bp-0x7],0x1
    1f89:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f8c:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1f90:	48                   	dec    ax
    1f91:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1f94:	31 c0                	xor    ax,ax
    1f96:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1f99:	7f 7a                	jg     0x2015
    1f9b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f9e:	eb 03                	jmp    0x1fa3
    1fa0:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1fa3:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1fa6:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1faa:	8a 46 f9             	mov    al,BYTE PTR [bp-0x7]
    1fad:	50                   	push   ax
    1fae:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb4:	06                   	push   es
    1fb5:	57                   	push   di
    1fb6:	9a d0 0d 08 21       	call   0x2108:0xdd0
    1fbb:	89 c7                	mov    di,ax
    1fbd:	8e c2                	mov    es,dx
    1fbf:	06                   	push   es
    1fc0:	57                   	push   di
    1fc1:	9a fb 18 f8 1f       	call   0x1ff8:0x18fb
    1fc6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1fc9:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1fcc:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1fcf:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
    1fd2:	74 39                	je     0x200d
    1fd4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1fd7:	26 8b 45 23          	mov    ax,WORD PTR es:[di+0x23]
    1fdb:	26 8b 55 25          	mov    dx,WORD PTR es:[di+0x25]
    1fdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fe2:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    1fe6:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    1fea:	8d be f2 fe          	lea    di,[bp-0x10e]
    1fee:	16                   	push   ss
    1fef:	57                   	push   di
    1ff0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1ff3:	06                   	push   es
    1ff4:	57                   	push   di
    1ff5:	9a e8 10 ea 20       	call   0x20ea:0x10e8
    1ffa:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1ffe:	06                   	push   es
    1fff:	57                   	push   di
    2000:	9a 9e 80 30 20       	call   0x2030:0x809e
    2005:	9a 6a 14 7e 20       	call   0x207e:0x146a
    200a:	e9 c6 00             	jmp    0x20d3
    200d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2010:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    2013:	75 8b                	jne    0x1fa0
    2015:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2018:	31 c0                	xor    ax,ax
    201a:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    201e:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    2022:	bf ed 1e             	mov    di,0x1eed
    2025:	0e                   	push   cs
    2026:	57                   	push   di
    2027:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    202b:	06                   	push   es
    202c:	57                   	push   di
    202d:	9a 9e 80 6c 20       	call   0x206c:0x809e
    2032:	eb 4e                	jmp    0x2082
    2034:	3d 21 01             	cmp    ax,0x121
    2037:	75 49                	jne    0x2082
    2039:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    203c:	26 83 7d 02 02       	cmp    WORD PTR es:[di+0x2],0x2
    2041:	75 3f                	jne    0x2082
    2043:	6a 70                	push   0x70
    2045:	9a ff ff 00 00       	call   0x0:0xffff
    204a:	09 c0                	or     ax,ax
    204c:	7d 34                	jge    0x2082
    204e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2051:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    2055:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    2059:	74 27                	je     0x2082
    205b:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    205f:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    2063:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2067:	06                   	push   es
    2068:	57                   	push   di
    2069:	9a 92 77 cc 20       	call   0x20cc:0x7792
    206e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2071:	31 c0                	xor    ax,ax
    2073:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    2077:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    207b:	9a 6a 14 d1 20       	call   0x20d1:0x146a
    2080:	eb 51                	jmp    0x20d3
    2082:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2085:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    2088:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    208b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    208e:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    2092:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2095:	26 ff 35             	push   WORD PTR es:[di]
    2098:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    209c:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    20a0:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    20a4:	9a ff ff 00 00       	call   0x0:0xffff
    20a9:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    20ac:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    20b0:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    20b4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    20b8:	83 c4 06             	add    sp,0x6
    20bb:	eb 16                	jmp    0x20d3
    20bd:	ff 76 08             	push   WORD PTR [bp+0x8]
    20c0:	ff 76 06             	push   WORD PTR [bp+0x6]
    20c3:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    20c7:	06                   	push   es
    20c8:	57                   	push   di
    20c9:	9a 51 75 f1 20       	call   0x20f1:0x7551
    20ce:	9a 34 14 47 21       	call   0x2147:0x1434
    20d3:	c9                   	leave
    20d4:	ca 08 00             	retf   0x8
    20d7:	55                   	push   bp
    20d8:	89 e5                	mov    bp,sp
    20da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20dd:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    20e2:	75 16                	jne    0x20fa
    20e4:	06                   	push   es
    20e5:	57                   	push   di
    20e6:	bf f8 1e             	mov    di,0x1ef8
    20e9:	b8 5a 21             	mov    ax,0x215a
    20ec:	50                   	push   ax
    20ed:	57                   	push   di
    20ee:	9a ed 15 32 21       	call   0x2132:0x15ed
    20f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20f6:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    20fa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    20fd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2100:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2103:	06                   	push   es
    2104:	57                   	push   di
    2105:	9a 2b 0c 1f 21       	call   0x211f:0xc2b
    210a:	c9                   	leave
    210b:	ca 08 00             	retf   0x8
    210e:	55                   	push   bp
    210f:	89 e5                	mov    bp,sp
    2111:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2114:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2117:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    211a:	06                   	push   es
    211b:	57                   	push   di
    211c:	9a a7 0f 97 22       	call   0x2297:0xfa7
    2121:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2124:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    2129:	75 09                	jne    0x2134
    212b:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    212f:	9a 6c 16 ff ff       	call   0xffff:0x166c
    2134:	c9                   	leave
    2135:	ca 08 00             	retf   0x8
    2138:	55                   	push   bp
    2139:	89 e5                	mov    bp,sp
    213b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    213f:	74 08                	je     0x2149
    2141:	83 ec 08             	sub    sp,0x8
    2144:	9a e2 1f c2 21       	call   0x21c2:0x1fe2
    2149:	ff 76 0e             	push   WORD PTR [bp+0xe]
    214c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    214f:	31 c0                	xor    ax,ax
    2151:	50                   	push   ax
    2152:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2155:	06                   	push   es
    2156:	57                   	push   di
    2157:	9a 63 17 7f 21       	call   0x217f:0x1763
    215c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2160:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    2164:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2167:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    216b:	26 c6 45 25 01       	mov    BYTE PTR es:[di+0x25],0x1
    2170:	ff 76 08             	push   WORD PTR [bp+0x8]
    2173:	ff 76 06             	push   WORD PTR [bp+0x6]
    2176:	c4 3e 08 2c          	les    di,DWORD PTR ds:0x2c08
    217a:	06                   	push   es
    217b:	57                   	push   di
    217c:	9a d7 20 aa 21       	call   0x21aa:0x20d7
    2181:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2185:	74 07                	je     0x218e
    2187:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    218b:	83 c4 06             	add    sp,0x6
    218e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2191:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2194:	c9                   	leave
    2195:	ca 0a 00             	retf   0xa
    2198:	55                   	push   bp
    2199:	89 e5                	mov    bp,sp
    219b:	ff 76 08             	push   WORD PTR [bp+0x8]
    219e:	ff 76 06             	push   WORD PTR [bp+0x6]
    21a1:	c4 3e 08 2c          	les    di,DWORD PTR ds:0x2c08
    21a5:	06                   	push   es
    21a6:	57                   	push   di
    21a7:	9a 0e 21 b7 21       	call   0x21b7:0x210e
    21ac:	31 c0                	xor    ax,ax
    21ae:	50                   	push   ax
    21af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b2:	06                   	push   es
    21b3:	57                   	push   di
    21b4:	9a e3 17 2f 22       	call   0x222f:0x17e3
    21b9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    21bd:	74 05                	je     0x21c4
    21bf:	9a 0f 20 aa 22       	call   0x22aa:0x200f
    21c4:	c9                   	leave
    21c5:	ca 06 00             	retf   0x6
    21c8:	c8 04 00 00          	enter  0x4,0x0
    21cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21cf:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    21d3:	26 8b 45 23          	mov    ax,WORD PTR es:[di+0x23]
    21d7:	26 8b 55 25          	mov    dx,WORD PTR es:[di+0x25]
    21db:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    21de:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    21e1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    21e4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    21e7:	c9                   	leave
    21e8:	ca 04 00             	retf   0x4
    21eb:	55                   	push   bp
    21ec:	89 e5                	mov    bp,sp
    21ee:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    21f1:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    21f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21f7:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    21fb:	26 89 45 23          	mov    WORD PTR es:[di+0x23],ax
    21ff:	26 89 55 25          	mov    WORD PTR es:[di+0x25],dx
    2203:	c9                   	leave
    2204:	ca 08 00             	retf   0x8
    2207:	55                   	push   bp
    2208:	89 e5                	mov    bp,sp
    220a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    220d:	26 8b 45 2c          	mov    ax,WORD PTR es:[di+0x2c]
    2211:	09 c0                	or     ax,ax
    2213:	74 12                	je     0x2227
    2215:	ff 76 08             	push   WORD PTR [bp+0x8]
    2218:	ff 76 06             	push   WORD PTR [bp+0x6]
    221b:	26 ff 75 30          	push   WORD PTR es:[di+0x30]
    221f:	26 ff 75 2e          	push   WORD PTR es:[di+0x2e]
    2223:	26 ff 5d 2a          	call   DWORD PTR es:[di+0x2a]
    2227:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    222a:	06                   	push   es
    222b:	57                   	push   di
    222c:	9a c8 21 49 22       	call   0x2249:0x21c8
    2231:	c4 3e 08 2c          	les    di,DWORD PTR ds:0x2c08
    2235:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    2239:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    223d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2240:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    2244:	06                   	push   es
    2245:	57                   	push   di
    2246:	9a 5d 10 85 22       	call   0x2285:0x105d
    224b:	50                   	push   ax
    224c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    224f:	26 8a 45 24          	mov    al,BYTE PTR es:[di+0x24]
    2253:	98                   	cbw
    2254:	8b f8                	mov    di,ax
    2256:	d1 e7                	shl    di,1
    2258:	8b 85 de 13          	mov    ax,WORD PTR [di+0x13de]
    225c:	0d 02 00             	or     ax,0x2
    225f:	50                   	push   ax
    2260:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2263:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2266:	6a 00                	push   0x0
    2268:	c4 3e 08 2c          	les    di,DWORD PTR ds:0x2c08
    226c:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    2270:	6a 00                	push   0x0
    2272:	6a 00                	push   0x0
    2274:	9a ff ff 00 00       	call   0x0:0xffff
    2279:	c9                   	leave
    227a:	ca 08 00             	retf   0x8
    227d:	c8 04 00 00          	enter  0x4,0x0
    2281:	b8 94 00             	mov    ax,0x94
    2284:	ba a3 22             	mov    dx,0x22a3
    2287:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    228a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    228d:	8d 7e fc             	lea    di,[bp-0x4]
    2290:	16                   	push   ss
    2291:	57                   	push   di
    2292:	6a 00                	push   0x0
    2294:	9a 5a 09 ff ff       	call   0xffff:0x95a
    2299:	e8 51 e2             	call   0x4ed
    229c:	b0 01                	mov    al,0x1
    229e:	50                   	push   ax
    229f:	b8 df 08             	mov    ax,0x8df
    22a2:	ba ba 22             	mov    dx,0x22ba
    22a5:	52                   	push   dx
    22a6:	50                   	push   ax
    22a7:	9a 50 1f c1 22       	call   0x22c1:0x1f50
    22ac:	a3 04 2c             	mov    ds:0x2c04,ax
    22af:	89 16 06 2c          	mov    WORD PTR ds:0x2c06,dx
    22b3:	b0 01                	mov    al,0x1
    22b5:	50                   	push   ax
    22b6:	b8 da 1e             	mov    ax,0x1eda
    22b9:	ba ff ff             	mov    dx,0xffff
    22bc:	52                   	push   dx
    22bd:	50                   	push   ax
    22be:	9a 50 1f ff ff       	call   0xffff:0x1f50
    22c3:	a3 08 2c             	mov    ds:0x2c08,ax
    22c6:	89 16 0a 2c          	mov    WORD PTR ds:0x2c0a,dx
    22ca:	c9                   	leave
    22cb:	cb                   	retf
