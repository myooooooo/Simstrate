; ================================================================
; seg25_CODE  (16318 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	19 00                	sbb    WORD PTR [bx+si],ax
       2:	03 09                	add    cx,WORD PTR [bx+di]
       4:	54                   	push   sp
       5:	46                   	inc    si
       6:	69 6c 65 41 74       	imul   bp,WORD PTR [si+0x65],0x7441
       b:	74 72                	je     0x7f
       d:	00 00                	add    BYTE PTR [bx+si],al
       f:	00 00                	add    BYTE PTR [bx+si],al
      11:	00 06 00 00          	add    BYTE PTR ds:0x0,al
      15:	00 02                	add    BYTE PTR [bp+si],al
      17:	00 6f 00             	add    BYTE PTR [bx+0x0],ch
      1a:	0a 66 74             	or     ah,BYTE PTR [bp+0x74]
      1d:	52                   	push   dx
      1e:	65 61                	gs popa
      20:	64 4f                	fs dec di
      22:	6e                   	outs   dx,BYTE PTR ds:[si]
      23:	6c                   	ins    BYTE PTR es:[di],dx
      24:	79 08                	jns    0x2e
      26:	66 74 48             	data32 je 0x71
      29:	69 64 64 65 6e       	imul   sp,WORD PTR [si+0x64],0x6e65
      2e:	08 66 74             	or     BYTE PTR [bp+0x74],ah
      31:	53                   	push   bx
      32:	79 73                	jns    0xa7
      34:	74 65                	je     0x9b
      36:	6d                   	ins    WORD PTR es:[di],dx
      37:	0a 66 74             	or     ah,BYTE PTR [bp+0x74]
      3a:	56                   	push   si
      3b:	6f                   	outs   dx,WORD PTR ds:[si]
      3c:	6c                   	ins    BYTE PTR es:[di],dx
      3d:	75 6d                	jne    0xac
      3f:	65 49                	gs dec cx
      41:	44                   	inc    sp
      42:	0b 66 74             	or     sp,WORD PTR [bp+0x74]
      45:	44                   	inc    sp
      46:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
      4b:	6f                   	outs   dx,WORD PTR ds:[si]
      4c:	72 79                	jb     0xc7
      4e:	09 66 74             	or     WORD PTR [bp+0x74],sp
      51:	41                   	inc    cx
      52:	72 63                	jb     0xb7
      54:	68 69 76             	push   0x7669
      57:	65 08 66 74          	or     BYTE PTR gs:[bp+0x74],ah
      5b:	4e                   	dec    si
      5c:	6f                   	outs   dx,WORD PTR ds:[si]
      5d:	72 6d                	jb     0xcc
      5f:	61                   	popa
      60:	6c                   	ins    BYTE PTR es:[di],dx
      61:	06                   	push   es
      62:	09 54 46             	or     WORD PTR [si+0x46],dx
      65:	69 6c 65 54 79       	imul   bp,WORD PTR [si+0x65],0x7954
      6a:	70 65                	jo     0xd1
      6c:	01 02                	add    WORD PTR [bp+si],ax
      6e:	00 f3                	add    bl,dh
      70:	00 44 01             	add    BYTE PTR [si+0x1],al
      73:	00 00                	add    BYTE PTR [bx+si],al
      75:	00 00                	add    BYTE PTR [bx+si],al
      77:	36 01 29             	add    WORD PTR ss:[bx+di],bp
      7a:	01 2a                	add    WORD PTR [bp+si],bp
      7c:	02 59 31             	add    bl,BYTE PTR [bx+di+0x31]
      7f:	58                   	pop    ax
      80:	01 fa                	add    dx,di
      82:	45                   	inc    bp
      83:	f7 00 9a 1f          	test   WORD PTR [bx+si],0x1f9a
      87:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
      88:	01 cb                	add    bx,cx
      8a:	1f                   	pop    ds
      8b:	87 00                	xchg   WORD PTR [bx+si],ax
      8d:	7d 32                	jge    0xc1
      8f:	27                   	daa
      90:	01 cd                	add    bp,cx
      92:	11 9b 00 3a          	adc    WORD PTR [bp+di+0x3a00],bx
      96:	27                   	daa
      97:	9f                   	lahf
      98:	00 fa                	add    dl,bh
      9a:	10 6a 04             	adc    BYTE PTR [bp+si+0x4],ch
      9d:	d6                   	(bad)
      9e:	14 cf                	adc    al,0xcf
      a0:	00 f4                	add    ah,dh
      a2:	4f                   	dec    di
      a3:	b3 00                	mov    bl,0x0
      a5:	31 3f                	xor    WORD PTR [bx],di
      a7:	23 01                	and    ax,WORD PTR [bx+di]
      a9:	ec                   	in     al,dx
      aa:	30 07                	xor    BYTE PTR [bx],al
      ac:	01 51 1b             	add    WORD PTR [bx+di+0x1b],dx
      af:	69 01 38 50          	imul   ax,WORD PTR [bx+di],0x5038
      b3:	bb 00 63             	mov    bx,0x6300
      b6:	31 d7                	xor    di,dx
      b8:	00 21                	add    BYTE PTR [bx+di],ah
      ba:	50                   	push   ax
      bb:	93                   	xchg   bx,ax
      bc:	00 c6                	add    dh,al
      be:	31 8f 00 d9          	xor    WORD PTR [bx-0x2700],cx
      c2:	62 c7 00             	(bad)  {k6}
      c5:	06                   	push   es
      c6:	63 cb                	arpl   bx,cx
      c8:	00 8f 60 03          	add    BYTE PTR [bx+0x360],cl
      cc:	01 3a                	add    WORD PTR [bp+si],di
      ce:	1c af                	sbb    al,0xaf
      d0:	00 f1                	add    cl,dh
      d2:	7c 13                	jl     0xe7
      d4:	01 08                	add    WORD PTR [bx+si],cx
      d6:	61                   	popa
      d7:	db 00                	fild   DWORD PTR [bx+si]
      d9:	5c                   	pop    sp
      da:	61                   	popa
      db:	df 00                	fild   WORD PTR [bx+si]
      dd:	62 5c 0b             	bound  bx,DWORD PTR [si+0xb]
      e0:	01 3a                	add    WORD PTR [bp+si],di
      e2:	61                   	popa
      e3:	97                   	xchg   di,ax
      e4:	00 72 3f             	add    BYTE PTR [bp+si+0x3f],dh
      e7:	ef                   	out    dx,ax
      e8:	00 bb 7a fb          	add    BYTE PTR [bp+di-0x486],bh
      ec:	00 17                	add    BYTE PTR [bx],dl
      ee:	3e 83 00 db          	add    WORD PTR ds:[bx+si],0xffdb
      f2:	32 17                	xor    dl,BYTE PTR [bx]
      f4:	01 ed                	add    bp,bp
      f6:	3e ff 00             	inc    WORD PTR ds:[bx+si]
      f9:	75 7c                	jne    0x177
      fb:	d3 00                	rol    WORD PTR [bx+si],cl
      fd:	c2 35 c3             	ret    0xc335
     100:	00 1c                	add    BYTE PTR [si],bl
     102:	48                   	dec    ax
     103:	ab                   	stos   WORD PTR es:[di],ax
     104:	00 ae 5f b7          	add    BYTE PTR [bp-0x48a1],ch
     108:	00 35                	add    BYTE PTR [di],dh
     10a:	62 e3 00             	(bad)  {k2}{z},{rn-bad}
     10d:	9a 39 a7 00 6f       	call   0x6f00:0xa739
     112:	81 7f 00 68 33       	cmp    WORD PTR [bx+0x0],0x3368
     117:	1b 01                	sbb    ax,WORD PTR [bx+di]
     119:	f7 36 1f 01          	div    WORD PTR ds:0x11f
     11d:	34 34                	xor    al,0x34
     11f:	0f 01                	(bad)
     121:	2b 3e bf 00          	sub    di,WORD PTR ds:0xbf
     125:	67 3c 3e             	addr32 cmp al,0x3e
     128:	01 0c                	add    WORD PTR [si],cx
     12a:	54                   	push   sp
     12b:	46                   	inc    si
     12c:	69 6c 65 4c 69       	imul   bp,WORD PTR [si+0x65],0x694c
     131:	73 74                	jae    0x1a7
     133:	42                   	inc    dx
     134:	6f                   	outs   dx,WORD PTR ds:[si]
     135:	78 02                	js     0x139
     137:	00 0e 0f fe          	add    BYTE PTR ds:0xfe0f,cl
     13b:	ff e2                	jmp    dx
     13d:	3b 42 01             	cmp    ax,WORD PTR [bp+si+0x1]
     140:	c8 36 54 01          	enter  0x5436,0x1
     144:	07                   	pop    es
     145:	0c 54                	or     al,0x54
     147:	46                   	inc    si
     148:	69 6c 65 4c 69       	imul   bp,WORD PTR [si+0x65],0x694c
     14d:	73 74                	jae    0x1c3
     14f:	42                   	inc    dx
     150:	6f                   	outs   dx,WORD PTR ds:[si]
     151:	78 91                	js     0xe4
     153:	00 2f                	add    BYTE PTR [bx],ch
     155:	02 18                	add    bl,BYTE PTR [bx+si]
     157:	32 27                	xor    ah,BYTE PTR [bx]
     159:	02 2e 00 08          	add    ch,BYTE PTR ds:0x800
     15d:	46                   	inc    si
     15e:	69 6c 65 43 74       	imul   bp,WORD PTR [si+0x65],0x7443
     163:	72 6c                	jb     0x1d1
     165:	25 00 e2             	and    ax,0xe200
     168:	00 71 01             	add    BYTE PTR [bx+di+0x1],dh
     16b:	2d 00 ff             	sub    ax,0xff00
     16e:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     171:	8f 01                	pop    WORD PTR [bx+di]
     173:	01 00                	add    WORD PTR [bx+si],ax
     175:	00 00                	add    BYTE PTR [bx+si],al
     177:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     17b:	00 00                	add    BYTE PTR [bx+si],al
     17d:	0a 00                	or     al,BYTE PTR [bx+si]
     17f:	05 41 6c             	add    ax,0x6c41
     182:	69 67 6e 02 00       	imul   sp,WORD PTR [bx+0x6e],0x2
     187:	69 02 38 00          	imul   ax,WORD PTR [bp+si],0x38
     18b:	ff                   	(bad)
     18c:	ff d5                	call   bp
     18e:	1e                   	push   ds
     18f:	93                   	xchg   bx,ax
     190:	01 17                	add    WORD PTR [bx],dx
     192:	1f                   	pop    ds
     193:	ad                   	lods   ax,WORD PTR ds:[si]
     194:	01 00                	add    WORD PTR [bx+si],ax
     196:	80 fa ff             	cmp    dl,0xff
     199:	ff                   	(bad)
     19a:	ff 0b                	dec    WORD PTR [bp+di]
     19c:	00 05                	add    BYTE PTR [di],al
     19e:	43                   	inc    bx
     19f:	6f                   	outs   dx,WORD PTR ds:[si]
     1a0:	6c                   	ins    BYTE PTR es:[di],dx
     1a1:	6f                   	outs   dx,WORD PTR ds:[si]
     1a2:	72 07                	jb     0x1ab
     1a4:	23 07                	and    ax,WORD PTR [bx]
     1a6:	02 a5 00 ff          	add    ah,BYTE PTR [di-0x100]
     1aa:	ff 22                	jmp    WORD PTR [bp+si]
     1ac:	63 b1 01 54          	arpl   WORD PTR [bx+di+0x5401],si
     1b0:	63 c3                	arpl   bx,ax
     1b2:	01 00                	add    WORD PTR [bx+si],ax
     1b4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1b7:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
     1bb:	05 43 74             	add    ax,0x7443
     1be:	6c                   	ins    BYTE PTR es:[di],dx
     1bf:	33 44 64             	xor    ax,WORD PTR [si+0x64]
     1c2:	00 e6                	add    dh,ah
     1c4:	01 3e 00 ff          	add    WORD PTR ds:0xff00,di
     1c8:	ff                   	(bad)
     1c9:	3e 00 ff             	ds add bh,bh
     1cc:	ff 01                	inc    WORD PTR [bx+di]
     1ce:	00 00                	add    BYTE PTR [bx+si],al
     1d0:	00 00                	add    BYTE PTR [bx+si],al
     1d2:	80 f4 ff             	xor    ah,0xff
     1d5:	ff                   	(bad)
     1d6:	ff 0d                	dec    WORD PTR [di]
     1d8:	00 0a                	add    BYTE PTR [bp+si],cl
     1da:	44                   	inc    sp
     1db:	72 61                	jb     0x23e
     1dd:	67 43                	addr32 inc bx
     1df:	75 72                	jne    0x253
     1e1:	73 6f                	jae    0x252
     1e3:	72 25                	jb     0x20a
     1e5:	01 0f                	add    WORD PTR [bx],cx
     1e7:	02 2e 00 ff          	add    ch,BYTE PTR ds:0xff00
     1eb:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     1ef:	ff 01                	inc    WORD PTR [bx+di]
     1f1:	00 00                	add    BYTE PTR [bx+si],al
     1f3:	00 00                	add    BYTE PTR [bx+si],al
     1f5:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1f8:	00 00                	add    BYTE PTR [bx+si],al
     1fa:	0e                   	push   cs
     1fb:	00 08                	add    BYTE PTR [bx+si],cl
     1fd:	44                   	inc    sp
     1fe:	72 61                	jb     0x261
     200:	67 4d                	addr32 dec bp
     202:	6f                   	outs   dx,WORD PTR ds:[si]
     203:	64 65 07             	fs gs pop es
     206:	23 86 02 2a          	and    ax,WORD PTR [bp+0x2a02]
     20a:	00 ff                	add    bh,bh
     20c:	ff                   	(bad)
     20d:	b8 1c 71             	mov    ax,0x711c
     210:	02 01                	add    al,BYTE PTR [bx+di]
     212:	00 00                	add    BYTE PTR [bx+si],al
     214:	00 00                	add    BYTE PTR [bx+si],al
     216:	80 01 00             	add    BYTE PTR [bx+di],0x0
     219:	00 00                	add    BYTE PTR [bx+si],al
     21b:	0f 00 07             	sldt   WORD PTR [bx]
     21e:	45                   	inc    bp
     21f:	6e                   	outs   dx,BYTE PTR ds:[si]
     220:	61                   	popa
     221:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     224:	64 12 0c             	adc    cl,BYTE PTR fs:[si]
     227:	8e 02                	mov    es,WORD PTR [bp+si]
     229:	07                   	pop    es
     22a:	02 ff                	add    bh,bh
     22c:	ff 19                	call   DWORD PTR [bx+di]
     22e:	39 48 02             	cmp    WORD PTR [bx+si+0x2],cx
     231:	01 00                	add    WORD PTR [bx+si],ax
     233:	00 00                	add    BYTE PTR [bx+si],al
     235:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     239:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     23d:	08 46 69             	or     BYTE PTR [bp+0x69],al
     240:	6c                   	ins    BYTE PTR es:[di],dx
     241:	65 45                	gs inc bp
     243:	64 69 74 61 00 4c    	imul   si,WORD PTR fs:[si+0x61],0x4c00
     249:	02 25                	add    ah,BYTE PTR [di]
     24b:	33 50 02             	xor    dx,WORD PTR [bx+si+0x2]
     24e:	51                   	push   cx
     24f:	3b d4                	cmp    dx,sp
     251:	02 01                	add    al,BYTE PTR [bx+di]
     253:	00 00                	add    BYTE PTR [bx+si],al
     255:	00 00                	add    BYTE PTR [bx+si],al
     257:	80 40 00 00          	add    BYTE PTR [bx+si+0x0],0x0
     25b:	00 11                	add    BYTE PTR [bx+di],dl
     25d:	00 08                	add    BYTE PTR [bx+si],cl
     25f:	46                   	inc    si
     260:	69 6c 65 54 79       	imul   bp,WORD PTR [si+0x65],0x7954
     265:	70 65                	jo     0x2cc
     267:	22 03                	and    al,BYTE PTR [bp+di]
     269:	74 06                	je     0x271
     26b:	34 00                	xor    al,0x0
     26d:	ff                   	(bad)
     26e:	ff                   	jmp    (bad)
     26f:	eb 1d                	jmp    0x28e
     271:	75 02                	jne    0x275
     273:	08 1e 19 03          	or     BYTE PTR ds:0x319,bl
     277:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     27b:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
     27f:	04 46                	add    al,0x46
     281:	6f                   	outs   dx,WORD PTR ds:[si]
     282:	6e                   	outs   dx,BYTE PTR ds:[si]
     283:	74 07                	je     0x28c
     285:	23 ad 02 e6          	and    bp,WORD PTR [di-0x19fe]
     289:	00 ff                	add    bh,bh
     28b:	ff 35                	push   WORD PTR [di]
     28d:	78 b1                	js     0x240
     28f:	02 01                	add    al,BYTE PTR [bx+di]
     291:	00 00                	add    BYTE PTR [bx+si],al
     293:	00 00                	add    BYTE PTR [bx+si],al
     295:	80 00 00             	add    BYTE PTR [bx+si],0x0
     298:	00 00                	add    BYTE PTR [bx+si],al
     29a:	13 00                	adc    ax,WORD PTR [bx+si]
     29c:	0e                   	push   cs
     29d:	49                   	dec    cx
     29e:	6e                   	outs   dx,BYTE PTR ds:[si]
     29f:	74 65                	je     0x306
     2a1:	67 72 61             	addr32 jb 0x305
     2a4:	6c                   	ins    BYTE PTR es:[di],dx
     2a5:	48                   	dec    ax
     2a6:	65 69 67 68 74 d4    	imul   sp,WORD PTR gs:[bx+0x68],0xd474
     2ac:	22 d0                	and    dl,al
     2ae:	02 58 78             	add    bl,BYTE PTR [bx+si+0x78]
     2b1:	b5 02                	mov    ch,0x2
     2b3:	93                   	xchg   bx,ax
     2b4:	78 f5                	js     0x2ab
     2b6:	02 01                	add    al,BYTE PTR [bx+di]
     2b8:	00 00                	add    BYTE PTR [bx+si],al
     2ba:	00 00                	add    BYTE PTR [bx+si],al
     2bc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2bf:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     2c3:	0a 49 74             	or     cl,BYTE PTR [bx+di+0x74]
     2c6:	65 6d                	gs ins WORD PTR es:[di],dx
     2c8:	48                   	dec    ax
     2c9:	65 69 67 68 74 62    	imul   sp,WORD PTR gs:[bx+0x68],0x6274
     2cf:	23 ed                	and    bp,bp
     2d1:	02 3b                	add    bh,BYTE PTR [bp+di]
     2d3:	33 d8                	xor    bx,ax
     2d5:	02 77 3b             	add    dh,BYTE PTR [bx+0x3b]
     2d8:	dc 02                	fadd   QWORD PTR [bp+si]
     2da:	f9                   	stc
     2db:	32 cd                	xor    cl,ch
     2dd:	03 00                	add    ax,WORD PTR [bx+si]
     2df:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2e2:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     2e6:	04 4d                	add    al,0x4d
     2e8:	61                   	popa
     2e9:	73 6b                	jae    0x356
     2eb:	07                   	pop    es
     2ec:	23 11                	and    dx,WORD PTR [bx+di]
     2ee:	03 e7                	add    sp,di
     2f0:	00 ff                	add    bh,bh
     2f2:	ff                   	(bad)
     2f3:	bc 78 56             	mov    sp,0x5678
     2f6:	07                   	pop    es
     2f7:	01 00                	add    WORD PTR [bx+si],ax
     2f9:	00 00                	add    BYTE PTR [bx+si],al
     2fb:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     2ff:	00 00                	add    BYTE PTR [bx+si],al
     301:	16                   	push   ss
     302:	00 0b                	add    BYTE PTR [bp+di],cl
     304:	4d                   	dec    bp
     305:	75 6c                	jne    0x373
     307:	74 69                	je     0x372
     309:	53                   	push   bx
     30a:	65 6c                	gs ins BYTE PTR es:[di],dx
     30c:	65 63 74 07          	arpl   WORD PTR gs:[si+0x7],si
     310:	23 35                	and    si,WORD PTR [di]
     312:	03 2c                	add    bp,WORD PTR [si]
     314:	00 ff                	add    bh,bh
     316:	ff 32                	push   WORD PTR [bp+si]
     318:	1f                   	pop    ds
     319:	3d 03 01             	cmp    ax,0x103
     31c:	00 00                	add    BYTE PTR [bx+si],al
     31e:	00 00                	add    BYTE PTR [bx+si],al
     320:	80 00 00             	add    BYTE PTR [bx+si],0x0
     323:	00 00                	add    BYTE PTR [bx+si],al
     325:	17                   	pop    ss
     326:	00 0b                	add    BYTE PTR [bp+di],cl
     328:	50                   	push   ax
     329:	61                   	popa
     32a:	72 65                	jb     0x391
     32c:	6e                   	outs   dx,BYTE PTR ds:[si]
     32d:	74 43                	je     0x372
     32f:	6f                   	outs   dx,WORD PTR ds:[si]
     330:	6c                   	ins    BYTE PTR es:[di],dx
     331:	6f                   	outs   dx,WORD PTR ds:[si]
     332:	72 07                	jb     0x33b
     334:	23 59 03             	and    bx,WORD PTR [bx+di+0x3]
     337:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     338:	00 ff                	add    bh,bh
     33a:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     33d:	61                   	popa
     33e:	03 01                	add    ax,WORD PTR [bx+di]
     340:	00 00                	add    BYTE PTR [bx+si],al
     342:	00 00                	add    BYTE PTR [bx+si],al
     344:	80 01 00             	add    BYTE PTR [bx+di],0x0
     347:	00 00                	add    BYTE PTR [bx+si],al
     349:	18 00                	sbb    BYTE PTR [bx+si],al
     34b:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     34e:	72 65                	jb     0x3b5
     350:	6e                   	outs   dx,BYTE PTR ds:[si]
     351:	74 43                	je     0x396
     353:	74 6c                	je     0x3c1
     355:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     358:	23 7c 03             	and    di,WORD PTR [si+0x3]
     35b:	2b 00                	sub    ax,WORD PTR [bx+si]
     35d:	ff                   	(bad)
     35e:	ff                   	(bad)
     35f:	3e 1e                	ds push ds
     361:	84 03                	test   BYTE PTR [bp+di],al
     363:	01 00                	add    WORD PTR [bx+si],ax
     365:	00 00                	add    BYTE PTR [bx+si],al
     367:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     36b:	00 00                	add    BYTE PTR [bx+si],al
     36d:	19 00                	sbb    WORD PTR [bx+si],ax
     36f:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     372:	72 65                	jb     0x3d9
     374:	6e                   	outs   dx,BYTE PTR ds:[si]
     375:	74 46                	je     0x3bd
     377:	6f                   	outs   dx,WORD PTR ds:[si]
     378:	6e                   	outs   dx,BYTE PTR ds:[si]
     379:	74 07                	je     0x382
     37b:	23 c5                	and    ax,bp
     37d:	03 49 00             	add    cx,WORD PTR [bx+di+0x0]
     380:	ff                   	(bad)
     381:	ff a1 1e f0          	jmp    WORD PTR [bx+di-0xfe2]
     385:	03 01                	add    ax,WORD PTR [bx+di]
     387:	00 00                	add    BYTE PTR [bx+si],al
     389:	00 00                	add    BYTE PTR [bx+si],al
     38b:	80 01 00             	add    BYTE PTR [bx+di],0x0
     38e:	00 00                	add    BYTE PTR [bx+si],al
     390:	1a 00                	sbb    al,BYTE PTR [bx+si]
     392:	0e                   	push   cs
     393:	50                   	push   ax
     394:	61                   	popa
     395:	72 65                	jb     0x3fc
     397:	6e                   	outs   dx,BYTE PTR ds:[si]
     398:	74 53                	je     0x3ed
     39a:	68 6f 77             	push   0x776f
     39d:	48                   	dec    ax
     39e:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     3a3:	f9                   	stc
     3a4:	09 40 00             	or     WORD PTR [bx+si+0x0],ax
     3a7:	ff                   	(bad)
     3a8:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     3ab:	ff                   	(bad)
     3ac:	ff 01                	inc    WORD PTR [bx+di]
     3ae:	00 00                	add    BYTE PTR [bx+si],al
     3b0:	00 00                	add    BYTE PTR [bx+si],al
     3b2:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3b5:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     3b9:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     3bc:	70 75                	jo     0x433
     3be:	70 4d                	jo     0x40d
     3c0:	65 6e                	outs   dx,BYTE PTR gs:[si]
     3c2:	75 07                	jne    0x3cb
     3c4:	23 e8                	and    bp,ax
     3c6:	03 13                	add    dx,WORD PTR [bp+di]
     3c8:	02 ff                	add    bh,bh
     3ca:	ff a7 37 c9          	jmp    WORD PTR [bx-0x36c9]
     3ce:	06                   	push   es
     3cf:	01 00                	add    WORD PTR [bx+si],ax
     3d1:	00 00                	add    BYTE PTR [bx+si],al
     3d3:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     3d7:	00 00                	add    BYTE PTR [bx+si],al
     3d9:	1c 00                	sbb    al,0x0
     3db:	0a 53 68             	or     dl,BYTE PTR [bp+di+0x68]
     3de:	6f                   	outs   dx,WORD PTR ds:[si]
     3df:	77 47                	ja     0x428
     3e1:	6c                   	ins    BYTE PTR es:[di],dx
     3e2:	79 70                	jns    0x454
     3e4:	68 73 07             	push   0x773
     3e7:	23 2a                	and    bp,WORD PTR [bp+si]
     3e9:	04 48                	add    al,0x48
     3eb:	00 ff                	add    bh,bh
     3ed:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     3f0:	f4                   	hlt
     3f1:	03 23                	add    sp,WORD PTR [bp+di]
     3f3:	1e                   	push   ds
     3f4:	09 04                	or     WORD PTR [si],ax
     3f6:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     3fa:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
     3fe:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     401:	6f                   	outs   dx,WORD PTR ds:[si]
     402:	77 48                	ja     0x44c
     404:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     409:	0d 04 a6             	or     ax,0xa604
     40c:	63 11                	arpl   WORD PTR [bx+di],dx
     40e:	04 60                	add    al,0x60
     410:	64 32 04             	xor    al,BYTE PTR fs:[si]
     413:	01 00                	add    WORD PTR [bx+si],ax
     415:	00 00                	add    BYTE PTR [bx+si],al
     417:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     41b:	ff                   	(bad)
     41c:	ff 1e 00 08          	call   DWORD PTR ds:0x800
     420:	54                   	push   sp
     421:	61                   	popa
     422:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     425:	64 65 72 07          	fs gs jb 0x430
     429:	23 4a 04             	and    cx,WORD PTR [bp+si+0x4]
     42c:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     42d:	00 ff                	add    bh,bh
     42f:	ff 88 64 52          	dec    WORD PTR [bx+si+0x5264]
     433:	04 01                	add    al,0x1
     435:	00 00                	add    BYTE PTR [bx+si],al
     437:	00 00                	add    BYTE PTR [bx+si],al
     439:	80 01 00             	add    BYTE PTR [bx+di],0x0
     43c:	00 00                	add    BYTE PTR [bx+si],al
     43e:	09 00                	or     WORD PTR [bx+si],ax
     440:	07                   	pop    es
     441:	54                   	push   sp
     442:	61                   	popa
     443:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     446:	6f                   	outs   dx,WORD PTR ds:[si]
     447:	70 07                	jo     0x450
     449:	23 5c 06             	and    bx,WORD PTR [si+0x6]
     44c:	29 00                	sub    WORD PTR [bx+si],ax
     44e:	ff                   	(bad)
     44f:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     452:	ce                   	into
     453:	04 01                	add    al,0x1
     455:	00 00                	add    BYTE PTR [bx+si],al
     457:	00 00                	add    BYTE PTR [bx+si],al
     459:	80 01 00             	add    BYTE PTR [bx+di],0x0
     45c:	00 00                	add    BYTE PTR [bx+si],al
     45e:	1f                   	pop    ds
     45f:	00 07                	add    BYTE PTR [bx],al
     461:	56                   	push   si
     462:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     467:	65 71 00             	gs jno 0x46a
     46a:	8b 04                	mov    ax,WORD PTR [si]
     46c:	20 02                	and    BYTE PTR [bp+si],al
     46e:	ff                   	(bad)
     46f:	ff 20                	jmp    WORD PTR [bx+si]
     471:	02 ff                	add    bh,bh
     473:	ff 01                	inc    WORD PTR [bx+di]
     475:	00 00                	add    BYTE PTR [bx+si],al
     477:	00 00                	add    BYTE PTR [bx+si],al
     479:	80 00 00             	add    BYTE PTR [bx+si],0x0
     47c:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
     480:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     483:	43                   	inc    bx
     484:	68 61 6e             	push   0x6e61
     487:	67 65 71 00          	addr32 gs jno 0x48b
     48b:	ab                   	stos   WORD PTR es:[di],ax
     48c:	04 7a                	add    al,0x7a
     48e:	00 ff                	add    bh,bh
     490:	ff                   	(bad)
     491:	7a 00                	jp     0x493
     493:	ff                   	(bad)
     494:	ff 01                	inc    WORD PTR [bx+di]
     496:	00 00                	add    BYTE PTR [bx+si],al
     498:	00 00                	add    BYTE PTR [bx+si],al
     49a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     49d:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     4a1:	07                   	pop    es
     4a2:	4f                   	dec    di
     4a3:	6e                   	outs   dx,BYTE PTR ds:[si]
     4a4:	43                   	inc    bx
     4a5:	6c                   	ins    BYTE PTR es:[di],dx
     4a6:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     4ab:	36 05 82 00          	ss add ax,0x82
     4af:	ff                   	(bad)
     4b0:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     4b4:	ff 01                	inc    WORD PTR [bx+di]
     4b6:	00 00                	add    BYTE PTR [bx+si],al
     4b8:	00 00                	add    BYTE PTR [bx+si],al
     4ba:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4bd:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     4c1:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     4c4:	44                   	inc    sp
     4c5:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     4c8:	6c                   	ins    BYTE PTR es:[di],dx
     4c9:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     4ce:	f1                   	int1
     4cf:	04 62                	add    al,0x62
     4d1:	00 ff                	add    bh,bh
     4d3:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     4d6:	ff                   	(bad)
     4d7:	ff 01                	inc    WORD PTR [bx+di]
     4d9:	00 00                	add    BYTE PTR [bx+si],al
     4db:	00 00                	add    BYTE PTR [bx+si],al
     4dd:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4e0:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     4e4:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     4e7:	44                   	inc    sp
     4e8:	72 61                	jb     0x54b
     4ea:	67 44                	addr32 inc sp
     4ec:	72 6f                	jb     0x55d
     4ee:	70 80                	jo     0x470
     4f0:	02 14                	add    dl,BYTE PTR [si]
     4f2:	05 6a 00             	add    ax,0x6a
     4f5:	ff                   	(bad)
     4f6:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     4f9:	ff                   	(bad)
     4fa:	ff 01                	inc    WORD PTR [bx+di]
     4fc:	00 00                	add    BYTE PTR [bx+si],al
     4fe:	00 00                	add    BYTE PTR [bx+si],al
     500:	80 00 00             	add    BYTE PTR [bx+si],0x0
     503:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     507:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     50a:	44                   	inc    sp
     50b:	72 61                	jb     0x56e
     50d:	67 4f                	addr32 dec di
     50f:	76 65                	jbe    0x576
     511:	72 32                	jb     0x545
     513:	03 75 05             	add    si,WORD PTR [di+0x5]
     516:	72 00                	jb     0x518
     518:	ff                   	(bad)
     519:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     51c:	ff                   	(bad)
     51d:	ff 01                	inc    WORD PTR [bx+di]
     51f:	00 00                	add    BYTE PTR [bx+si],al
     521:	00 00                	add    BYTE PTR [bx+si],al
     523:	80 00 00             	add    BYTE PTR [bx+si],0x0
     526:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     52a:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     52d:	45                   	inc    bp
     52e:	6e                   	outs   dx,BYTE PTR ds:[si]
     52f:	64 44                	fs inc sp
     531:	72 61                	jb     0x594
     533:	67 71 00             	addr32 jno 0x536
     536:	56                   	push   si
     537:	05 c8 00             	add    ax,0xc8
     53a:	ff                   	(bad)
     53b:	ff c8                	dec    ax
     53d:	00 ff                	add    bh,bh
     53f:	ff 01                	inc    WORD PTR [bx+di]
     541:	00 00                	add    BYTE PTR [bx+si],al
     543:	00 00                	add    BYTE PTR [bx+si],al
     545:	80 00 00             	add    BYTE PTR [bx+si],0x0
     548:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
     54c:	07                   	pop    es
     54d:	4f                   	dec    di
     54e:	6e                   	outs   dx,BYTE PTR ds:[si]
     54f:	45                   	inc    bp
     550:	6e                   	outs   dx,BYTE PTR ds:[si]
     551:	74 65                	je     0x5b8
     553:	72 71                	jb     0x5c6
     555:	00 64 06             	add    BYTE PTR [si+0x6],ah
     558:	d0 00                	rol    BYTE PTR [bx+si],1
     55a:	ff                   	(bad)
     55b:	ff d0                	call   ax
     55d:	00 ff                	add    bh,bh
     55f:	ff 01                	inc    WORD PTR [bx+di]
     561:	00 00                	add    BYTE PTR [bx+si],al
     563:	00 00                	add    BYTE PTR [bx+si],al
     565:	80 00 00             	add    BYTE PTR [bx+si],0x0
     568:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
     56c:	06                   	push   es
     56d:	4f                   	dec    di
     56e:	6e                   	outs   dx,BYTE PTR ds:[si]
     56f:	45                   	inc    bp
     570:	78 69                	js     0x5db
     572:	74 1a                	je     0x58e
     574:	02 97 05 b0          	add    dl,BYTE PTR [bx-0x4ffb]
     578:	00 ff                	add    bh,bh
     57a:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     57e:	ff 01                	inc    WORD PTR [bx+di]
     580:	00 00                	add    BYTE PTR [bx+si],al
     582:	00 00                	add    BYTE PTR [bx+si],al
     584:	80 00 00             	add    BYTE PTR [bx+si],0x0
     587:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
     58b:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     58e:	4b                   	dec    bx
     58f:	65 79 44             	gs jns 0x5d6
     592:	6f                   	outs   dx,WORD PTR ds:[si]
     593:	77 6e                	ja     0x603
     595:	54                   	push   sp
     596:	02 ba 05 b8          	add    bh,BYTE PTR [bp+si-0x47fb]
     59a:	00 ff                	add    bh,bh
     59c:	ff                   	(bad)
     59d:	b8 00 ff             	mov    ax,0xff00
     5a0:	ff 01                	inc    WORD PTR [bx+di]
     5a2:	00 00                	add    BYTE PTR [bx+si],al
     5a4:	00 00                	add    BYTE PTR [bx+si],al
     5a6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5a9:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
     5ad:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     5b0:	4b                   	dec    bx
     5b1:	65 79 50             	gs jns 0x604
     5b4:	72 65                	jb     0x61b
     5b6:	73 73                	jae    0x62b
     5b8:	1a 02                	sbb    al,BYTE PTR [bp+si]
     5ba:	da 05                	fiadd  DWORD PTR [di]
     5bc:	c0 00 ff             	rol    BYTE PTR [bx+si],0xff
     5bf:	ff c0                	inc    ax
     5c1:	00 ff                	add    bh,bh
     5c3:	ff 01                	inc    WORD PTR [bx+di]
     5c5:	00 00                	add    BYTE PTR [bx+si],al
     5c7:	00 00                	add    BYTE PTR [bx+si],al
     5c9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5cc:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
     5d0:	07                   	pop    es
     5d1:	4f                   	dec    di
     5d2:	6e                   	outs   dx,BYTE PTR ds:[si]
     5d3:	4b                   	dec    bx
     5d4:	65 79 55             	gs jns 0x62c
     5d7:	70 71                	jo     0x64a
     5d9:	01 fe                	add    si,di
     5db:	05 4a 00             	add    ax,0x4a
     5de:	ff                   	(bad)
     5df:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     5e2:	ff                   	(bad)
     5e3:	ff 01                	inc    WORD PTR [bx+di]
     5e5:	00 00                	add    BYTE PTR [bx+si],al
     5e7:	00 00                	add    BYTE PTR [bx+si],al
     5e9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5ec:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
     5f0:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     5f3:	4d                   	dec    bp
     5f4:	6f                   	outs   dx,WORD PTR ds:[si]
     5f5:	75 73                	jne    0x66a
     5f7:	65 44                	gs inc sp
     5f9:	6f                   	outs   dx,WORD PTR ds:[si]
     5fa:	77 6e                	ja     0x66a
     5fc:	ce                   	into
     5fd:	01 22                	add    WORD PTR [bp+si],sp
     5ff:	06                   	push   es
     600:	52                   	push   dx
     601:	00 ff                	add    bh,bh
     603:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     606:	ff                   	(bad)
     607:	ff 01                	inc    WORD PTR [bx+di]
     609:	00 00                	add    BYTE PTR [bx+si],al
     60b:	00 00                	add    BYTE PTR [bx+si],al
     60d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     610:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
     614:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     617:	4d                   	dec    bp
     618:	6f                   	outs   dx,WORD PTR ds:[si]
     619:	75 73                	jne    0x68e
     61b:	65 4d                	gs dec bp
     61d:	6f                   	outs   dx,WORD PTR ds:[si]
     61e:	76 65                	jbe    0x685
     620:	71 01                	jno    0x623
     622:	52                   	push   dx
     623:	07                   	pop    es
     624:	5a                   	pop    dx
     625:	00 ff                	add    bh,bh
     627:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     62a:	ff                   	(bad)
     62b:	ff 01                	inc    WORD PTR [bx+di]
     62d:	00 00                	add    BYTE PTR [bx+si],al
     62f:	00 00                	add    BYTE PTR [bx+si],al
     631:	80 00 00             	add    BYTE PTR [bx+si],0x0
     634:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
     638:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     63b:	4d                   	dec    bp
     63c:	6f                   	outs   dx,WORD PTR ds:[si]
     63d:	75 73                	jne    0x6b2
     63f:	65 55                	gs push bp
     641:	70 b8                	jo     0x5fb
     643:	06                   	push   es
     644:	00 00                	add    BYTE PTR [bx+si],al
     646:	00 00                	add    BYTE PTR [bx+si],al
     648:	00 00                	add    BYTE PTR [bx+si],al
     64a:	aa                   	stos   BYTE PTR es:[di],al
     64b:	06                   	push   es
     64c:	16                   	push   ss
     64d:	00 3f                	add    BYTE PTR [bx],bh
     64f:	08 cd                	or     ch,cl
     651:	06                   	push   es
     652:	64 20 f6             	fs and dh,dh
     655:	06                   	push   es
     656:	9a 1f 54 06 cb       	call   0xcb06:0x541f
     65b:	1f                   	pop    ds
     65c:	58                   	pop    ax
     65d:	06                   	push   es
     65e:	18 57 6c             	sbb    BYTE PTR [bx+0x6c],dl
     661:	06                   	push   es
     662:	cd 11                	int    0x11
     664:	0e                   	push   cs
     665:	07                   	pop    es
     666:	cc                   	int3
     667:	40                   	inc    ax
     668:	94                   	xchg   sp,ax
     669:	06                   	push   es
     66a:	53                   	push   bx
     66b:	57                   	push   di
     66c:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     66d:	06                   	push   es
     66e:	bd 56 60             	mov    bp,0x6056
     671:	06                   	push   es
     672:	df 58 78             	fistp  WORD PTR [bx+si+0x78]
     675:	06                   	push   es
     676:	e3 59                	jcxz   0x6d1
     678:	7c 06                	jl     0x680
     67a:	db 5a 80             	fistp  DWORD PTR [bp+si-0x80]
     67d:	06                   	push   es
     67e:	8c 5b 84             	mov    WORD PTR [bp+di-0x7c],ds
     681:	06                   	push   es
     682:	16                   	push   ss
     683:	5f                   	pop    di
     684:	8c 06 e0 61          	mov    WORD PTR ds:0x61e0,es
     688:	90                   	nop
     689:	06                   	push   es
     68a:	6c                   	ins    BYTE PTR es:[di],dx
     68b:	62 88 06 b2          	bound  cx,DWORD PTR [bx+si-0x4dfa]
     68f:	62 70 06             	bound  si,DWORD PTR [bx+si+0x6]
     692:	22 41 98             	and    al,BYTE PTR [bx+di-0x68]
     695:	06                   	push   es
     696:	84 41 50             	test   BYTE PTR [bx+di+0x50],al
     699:	06                   	push   es
     69a:	11 5e a8             	adc    WORD PTR [bp-0x58],bx
     69d:	06                   	push   es
     69e:	3c 63                	cmp    al,0x63
     6a0:	68 06 1d             	push   0x1d06
     6a3:	5d                   	pop    bp
     6a4:	9c                   	pushf
     6a5:	06                   	push   es
     6a6:	5f                   	pop    di
     6a7:	63 a0 06 0d          	arpl   WORD PTR [bx+si+0xd06],sp
     6ab:	54                   	push   sp
     6ac:	46                   	inc    si
     6ad:	6f                   	outs   dx,WORD PTR ds:[si]
     6ae:	6c                   	ins    BYTE PTR es:[di],dx
     6af:	64 65 72 42          	fs gs jb 0x6f5
     6b3:	69 74 6d 61 70       	imul   si,WORD PTR [si+0x6d],0x7061
     6b8:	07                   	pop    es
     6b9:	0d 54 46             	or     ax,0x4654
     6bc:	6f                   	outs   dx,WORD PTR ds:[si]
     6bd:	6c                   	ins    BYTE PTR es:[di],dx
     6be:	64 65 72 42          	fs gs jb 0x704
     6c2:	69 74 6d 61 70       	imul   si,WORD PTR [si+0x6d],0x7061
     6c7:	62 06 82 07          	bound  ax,DWORD PTR ds:0x782
     6cb:	8f 08 fe 07          	(bad)
     6cf:	00 00                	add    BYTE PTR [bx+si],al
     6d1:	08 46 69             	or     BYTE PTR [bp+0x69],al
     6d4:	6c                   	ins    BYTE PTR es:[di],dx
     6d5:	65 43                	gs inc bx
     6d7:	74 72                	je     0x74b
     6d9:	6c                   	ins    BYTE PTR es:[di],dx
     6da:	00 00                	add    BYTE PTR [bx+si],al
     6dc:	b6 07                	mov    dh,0x7
     6de:	00 00                	add    BYTE PTR [bx+si],al
     6e0:	00 00                	add    BYTE PTR [bx+si],al
     6e2:	a2 07 90             	mov    ds:0x9007,al
     6e5:	07                   	pop    es
     6e6:	23 02                	and    ax,WORD PTR [bp+si]
     6e8:	59                   	pop    cx
     6e9:	31 cf                	xor    di,cx
     6eb:	07                   	pop    es
     6ec:	fa                   	cli
     6ed:	45                   	inc    bp
     6ee:	62 07                	bound  ax,DWORD PTR [bx]
     6f0:	9a 1f 1c 08 cb       	call   0xcb08:0x1c1f
     6f5:	1f                   	pop    ds
     6f6:	f2 06                	repnz push es
     6f8:	bf 24 ac             	mov    di,0xac24
     6fb:	07                   	pop    es
     6fc:	cd 11                	int    0x11
     6fe:	06                   	push   es
     6ff:	07                   	pop    es
     700:	3a 27                	cmp    ah,BYTE PTR [bx]
     702:	0a 07                	or     al,BYTE PTR [bx]
     704:	fa                   	cli
     705:	10 9d 0a d6          	adc    BYTE PTR [di-0x29f6],bl
     709:	14 3a                	adc    al,0x3a
     70b:	07                   	pop    es
     70c:	f4                   	hlt
     70d:	4f                   	dec    di
     70e:	1e                   	push   ds
     70f:	07                   	pop    es
     710:	bf 30 2a             	mov    di,0x2a30
     713:	07                   	pop    es
     714:	ec                   	in     al,dx
     715:	30 72 07             	xor    BYTE PTR [bp+si+0x7],dh
     718:	51                   	push   cx
     719:	1b e0                	sbb    sp,ax
     71b:	07                   	pop    es
     71c:	38 50 26             	cmp    BYTE PTR [bx+si+0x26],dl
     71f:	07                   	pop    es
     720:	63 31                	arpl   WORD PTR [bx+di],si
     722:	42                   	inc    dx
     723:	07                   	pop    es
     724:	21 50 fe             	and    WORD PTR [bx+si-0x2],dx
     727:	06                   	push   es
     728:	26 24 fa             	es and al,0xfa
     72b:	06                   	push   es
     72c:	d9 62 32             	fldenv [bp+si+0x32]
     72f:	07                   	pop    es
     730:	06                   	push   es
     731:	63 36 07 8f          	arpl   WORD PTR ds:0x8f07,si
     735:	60                   	pusha
     736:	6e                   	outs   dx,BYTE PTR ds:[si]
     737:	07                   	pop    es
     738:	3a 1c                	cmp    bl,BYTE PTR [si]
     73a:	1a 07                	sbb    al,BYTE PTR [bx]
     73c:	f1                   	int1
     73d:	7c 7e                	jl     0x7bd
     73f:	07                   	pop    es
     740:	08 61 46             	or     BYTE PTR [bx+di+0x46],ah
     743:	07                   	pop    es
     744:	5c                   	pop    sp
     745:	61                   	popa
     746:	4a                   	dec    dx
     747:	07                   	pop    es
     748:	62 5c 76             	bound  bx,DWORD PTR [si+0x76]
     74b:	07                   	pop    es
     74c:	3a 61 02             	cmp    ah,BYTE PTR [bx+di+0x2]
     74f:	07                   	pop    es
     750:	72 3f                	jb     0x791
     752:	5a                   	pop    dx
     753:	07                   	pop    es
     754:	bb 7a 66             	mov    bx,0x667a
     757:	07                   	pop    es
     758:	17                   	pop    ss
     759:	3e ee                	ds out dx,al
     75b:	06                   	push   es
     75c:	9b                   	fwait
     75d:	2e 7a 07             	cs jp  0x767
     760:	ed                   	in     ax,dx
     761:	3e 6a 07             	ds push 0x7
     764:	75 7c                	jne    0x7e2
     766:	3e 07                	ds pop es
     768:	c2 35 2e             	ret    0x2e35
     76b:	07                   	pop    es
     76c:	1c 48                	sbb    al,0x48
     76e:	16                   	push   ss
     76f:	07                   	pop    es
     770:	ae                   	scas   al,BYTE PTR es:[di]
     771:	5f                   	pop    di
     772:	22 07                	and    al,BYTE PTR [bx]
     774:	35 62 4e             	xor    ax,0x4e62
     777:	07                   	pop    es
     778:	08 2b                	or     BYTE PTR [bp+di],ch
     77a:	8e 07                	mov    es,WORD PTR [bx]
     77c:	6f                   	outs   dx,WORD PTR ds:[si]
     77d:	81 ea 06 c0          	sub    dx,0xc006
     781:	2f                   	das
     782:	86 07                	xchg   BYTE PTR [bx],al
     784:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     785:	2a 8a 07 d4          	sub    cl,BYTE PTR [bp+si-0x2bf9]
     789:	29 5e 07             	sub    WORD PTR [bp+0x7],bx
     78c:	0a 27                	or     ah,BYTE PTR [bx]
     78e:	12 07                	adc    al,BYTE PTR [bx]
     790:	11 54 44             	adc    WORD PTR [si+0x44],dx
     793:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
     798:	6f                   	outs   dx,WORD PTR ds:[si]
     799:	72 79                	jb     0x814
     79b:	4c                   	dec    sp
     79c:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
     7a1:	78 03                	js     0x7a6
     7a3:	00 0e 0f fd          	add    BYTE PTR ds:0xfd0f,cl
     7a7:	ff                   	jmp    (bad)
     7a8:	ef                   	out    dx,ax
     7a9:	ff                   	call   (bad)
     7aa:	d8 2e b0 07          	fsubr  DWORD PTR ds:0x7b0
     7ae:	8c 2a                	mov    WORD PTR [bp+si],gs
     7b0:	b4 07                	mov    ah,0x7
     7b2:	92                   	xchg   dx,ax
     7b3:	30 cb                	xor    bl,cl
     7b5:	07                   	pop    es
     7b6:	07                   	pop    es
     7b7:	11 54 44             	adc    WORD PTR [si+0x44],dx
     7ba:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
     7bf:	6f                   	outs   dx,WORD PTR ds:[si]
     7c0:	72 79                	jb     0x83b
     7c2:	4c                   	dec    sp
     7c3:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
     7c8:	78 fc                	js     0x7c6
     7ca:	06                   	push   es
     7cb:	62 08                	bound  cx,DWORD PTR [bx+si]
     7cd:	18 32                	sbb    BYTE PTR [bp+si],dh
     7cf:	24 08                	and    al,0x8
     7d1:	2c 00                	sub    al,0x0
     7d3:	08 46 69             	or     BYTE PTR [bp+0x69],al
     7d6:	6c                   	ins    BYTE PTR es:[di],dx
     7d7:	65 43                	gs inc bx
     7d9:	74 72                	je     0x84d
     7db:	6c                   	ins    BYTE PTR es:[di],dx
     7dc:	23 00                	and    ax,WORD PTR [bx+si]
     7de:	e2 00                	loop   0x7e0
     7e0:	e8 07 2d             	call   0x34ea
     7e3:	00 ff                	add    bh,bh
     7e5:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     7e8:	06                   	push   es
     7e9:	08 01                	or     BYTE PTR [bx+di],al
     7eb:	00 00                	add    BYTE PTR [bx+si],al
     7ed:	00 00                	add    BYTE PTR [bx+si],al
     7ef:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7f2:	00 00                	add    BYTE PTR [bx+si],al
     7f4:	0a 00                	or     al,BYTE PTR [bx+si]
     7f6:	05 41 6c             	add    ax,0x6c41
     7f9:	69 67 6e 02 00       	imul   sp,WORD PTR [bx+0x6e],0x2
     7fe:	00 09                	add    BYTE PTR [bx+di],cl
     800:	38 00                	cmp    BYTE PTR [bx+si],al
     802:	ff                   	(bad)
     803:	ff d5                	call   bp
     805:	1e                   	push   ds
     806:	0a 08                	or     cl,BYTE PTR [bx+si]
     808:	17                   	pop    ss
     809:	1f                   	pop    ds
     80a:	44                   	inc    sp
     80b:	08 00                	or     BYTE PTR [bx+si],al
     80d:	80 fa ff             	cmp    dl,0xff
     810:	ff                   	(bad)
     811:	ff 0b                	dec    WORD PTR [bp+di]
     813:	00 05                	add    BYTE PTR [di],al
     815:	43                   	inc    bx
     816:	6f                   	outs   dx,WORD PTR ds:[si]
     817:	6c                   	ins    BYTE PTR es:[di],dx
     818:	6f                   	outs   dx,WORD PTR ds:[si]
     819:	72 d4                	jb     0x7ef
     81b:	22 3c                	and    bh,BYTE PTR [si]
     81d:	08 e1                	or     cl,ah
     81f:	00 ff                	add    bh,bh
     821:	ff 65 77             	jmp    WORD PTR [di+0x77]
     824:	5a                   	pop    dx
     825:	08 01                	or     BYTE PTR [bx+di],al
     827:	00 00                	add    BYTE PTR [bx+si],al
     829:	00 00                	add    BYTE PTR [bx+si],al
     82b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     82e:	00 00                	add    BYTE PTR [bx+si],al
     830:	0c 00                	or     al,0x0
     832:	07                   	pop    es
     833:	43                   	inc    bx
     834:	6f                   	outs   dx,WORD PTR ds:[si]
     835:	6c                   	ins    BYTE PTR es:[di],dx
     836:	75 6d                	jne    0x8a5
     838:	6e                   	outs   dx,BYTE PTR ds:[si]
     839:	73 07                	jae    0x842
     83b:	23 bf 08 a5          	and    di,WORD PTR [bx-0x5af8]
     83f:	00 ff                	add    bh,bh
     841:	ff 22                	jmp    WORD PTR [bp+si]
     843:	63 48 08             	arpl   WORD PTR [bx+si+0x8],cx
     846:	54                   	push   sp
     847:	63 7b 08             	arpl   WORD PTR [bp+di+0x8],di
     84a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     84e:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     852:	05 43 74             	add    ax,0x7443
     855:	6c                   	ins    BYTE PTR es:[di],dx
     856:	33 44 76             	xor    ax,WORD PTR [si+0x76]
     859:	06                   	push   es
     85a:	25 09 0a             	and    ax,0xa09
     85d:	01 ff                	add    di,di
     85f:	ff f5                	push   bp
     861:	25 df 08             	and    ax,0x8df
     864:	01 00                	add    WORD PTR [bx+si],ax
     866:	00 00                	add    BYTE PTR [bx+si],al
     868:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     86c:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
     870:	08 44 69             	or     BYTE PTR [si+0x69],al
     873:	72 4c                	jb     0x8c1
     875:	61                   	popa
     876:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     879:	64 00 9e 08 3e       	add    BYTE PTR fs:[bp+0x3e08],bl
     87e:	00 ff                	add    bh,bh
     880:	ff                   	(bad)
     881:	3e 00 ff             	ds add bh,bh
     884:	ff 01                	inc    WORD PTR [bx+di]
     886:	00 00                	add    BYTE PTR [bx+si],al
     888:	00 00                	add    BYTE PTR [bx+si],al
     88a:	80 f4 ff             	xor    ah,0xff
     88d:	ff                   	(bad)
     88e:	ff 0f                	dec    WORD PTR [bx]
     890:	00 0a                	add    BYTE PTR [bp+si],cl
     892:	44                   	inc    sp
     893:	72 61                	jb     0x8f6
     895:	67 43                	addr32 inc bx
     897:	75 72                	jne    0x90b
     899:	73 6f                	jae    0x90a
     89b:	72 25                	jb     0x8c2
     89d:	01 c7                	add    di,ax
     89f:	08 2e 00 ff          	or     BYTE PTR ds:0xff00,ch
     8a3:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     8a7:	ff 01                	inc    WORD PTR [bx+di]
     8a9:	00 00                	add    BYTE PTR [bx+si],al
     8ab:	00 00                	add    BYTE PTR [bx+si],al
     8ad:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8b0:	00 00                	add    BYTE PTR [bx+si],al
     8b2:	10 00                	adc    BYTE PTR [bx+si],al
     8b4:	08 44 72             	or     BYTE PTR [si+0x72],al
     8b7:	61                   	popa
     8b8:	67 4d                	addr32 dec bp
     8ba:	6f                   	outs   dx,WORD PTR ds:[si]
     8bb:	64 65 07             	fs gs pop es
     8be:	23 1d                	and    bx,WORD PTR [di]
     8c0:	09 2a                	or     WORD PTR [bp+si],bp
     8c2:	00 ff                	add    bh,bh
     8c4:	ff                   	(bad)
     8c5:	b8 1c 08             	mov    ax,0x81c
     8c8:	09 01                	or     WORD PTR [bx+di],ax
     8ca:	00 00                	add    BYTE PTR [bx+si],al
     8cc:	00 00                	add    BYTE PTR [bx+si],al
     8ce:	80 01 00             	add    BYTE PTR [bx+di],0x0
     8d1:	00 00                	add    BYTE PTR [bx+si],al
     8d3:	11 00                	adc    WORD PTR [bx+si],ax
     8d5:	07                   	pop    es
     8d6:	45                   	inc    bp
     8d7:	6e                   	outs   dx,BYTE PTR ds:[si]
     8d8:	61                   	popa
     8d9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8dc:	64 44                	fs inc sp
     8de:	01 e7                	add    di,sp
     8e0:	08 02                	or     BYTE PTR [bp+si],al
     8e2:	01 ff                	add    di,di
     8e4:	ff 9a 25 8b          	call   DWORD PTR [bp+si-0x74db]
     8e8:	0c 01                	or     al,0x1
     8ea:	00 00                	add    BYTE PTR [bx+si],al
     8ec:	00 00                	add    BYTE PTR [bx+si],al
     8ee:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8f1:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
     8f5:	08 46 69             	or     BYTE PTR [bp+0x69],al
     8f8:	6c                   	ins    BYTE PTR es:[di],dx
     8f9:	65 4c                	gs dec sp
     8fb:	69 73 74 22 03       	imul   si,WORD PTR [bp+di+0x74],0x322
     900:	9b                   	fwait
     901:	0d 34 00             	or     ax,0x34
     904:	ff                   	(bad)
     905:	ff                   	jmp    (bad)
     906:	eb 1d                	jmp    0x925
     908:	0c 09                	or     al,0x9
     90a:	08 1e 6f 09          	or     BYTE PTR ds:0x96f,bl
     90e:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     912:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
     916:	04 46                	add    al,0x46
     918:	6f                   	outs   dx,WORD PTR ds:[si]
     919:	6e                   	outs   dx,BYTE PTR ds:[si]
     91a:	74 07                	je     0x923
     91c:	23 44 09             	and    ax,WORD PTR [si+0x9]
     91f:	e6 00                	out    0x0,al
     921:	ff                   	(bad)
     922:	ff 35                	push   WORD PTR [di]
     924:	78 48                	js     0x96e
     926:	09 01                	or     WORD PTR [bx+di],ax
     928:	00 00                	add    BYTE PTR [bx+si],al
     92a:	00 00                	add    BYTE PTR [bx+si],al
     92c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     92f:	00 00                	add    BYTE PTR [bx+si],al
     931:	14 00                	adc    al,0x0
     933:	0e                   	push   cs
     934:	49                   	dec    cx
     935:	6e                   	outs   dx,BYTE PTR ds:[si]
     936:	74 65                	je     0x99d
     938:	67 72 61             	addr32 jb 0x99c
     93b:	6c                   	ins    BYTE PTR es:[di],dx
     93c:	48                   	dec    ax
     93d:	65 69 67 68 74 d4    	imul   sp,WORD PTR gs:[bx+0x68],0xd474
     943:	22 67 09             	and    ah,BYTE PTR [bx+0x9]
     946:	58                   	pop    ax
     947:	78 4c                	js     0x995
     949:	09 93 78 43          	or     WORD PTR [bp+di+0x4378],dx
     94d:	0d 01 00             	or     ax,0x1
     950:	00 00                	add    BYTE PTR [bx+si],al
     952:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     956:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     95a:	0a 49 74             	or     cl,BYTE PTR [bx+di+0x74]
     95d:	65 6d                	gs ins WORD PTR es:[di],dx
     95f:	48                   	dec    ax
     960:	65 69 67 68 74 07    	imul   sp,WORD PTR gs:[bx+0x68],0x774
     966:	23 8b 09 2c          	and    cx,WORD PTR [bp+di+0x2c09]
     96a:	00 ff                	add    bh,bh
     96c:	ff 32                	push   WORD PTR [bp+si]
     96e:	1f                   	pop    ds
     96f:	93                   	xchg   bx,ax
     970:	09 01                	or     WORD PTR [bx+di],ax
     972:	00 00                	add    BYTE PTR [bx+si],al
     974:	00 00                	add    BYTE PTR [bx+si],al
     976:	80 00 00             	add    BYTE PTR [bx+si],0x0
     979:	00 00                	add    BYTE PTR [bx+si],al
     97b:	16                   	push   ss
     97c:	00 0b                	add    BYTE PTR [bp+di],cl
     97e:	50                   	push   ax
     97f:	61                   	popa
     980:	72 65                	jb     0x9e7
     982:	6e                   	outs   dx,BYTE PTR ds:[si]
     983:	74 43                	je     0x9c8
     985:	6f                   	outs   dx,WORD PTR ds:[si]
     986:	6c                   	ins    BYTE PTR es:[di],dx
     987:	6f                   	outs   dx,WORD PTR ds:[si]
     988:	72 07                	jb     0x991
     98a:	23 af 09 a6          	and    bp,WORD PTR [bx-0x59f7]
     98e:	00 ff                	add    bh,bh
     990:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     993:	b7 09                	mov    bh,0x9
     995:	01 00                	add    WORD PTR [bx+si],ax
     997:	00 00                	add    BYTE PTR [bx+si],al
     999:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     99d:	00 00                	add    BYTE PTR [bx+si],al
     99f:	17                   	pop    ss
     9a0:	00 0b                	add    BYTE PTR [bp+di],cl
     9a2:	50                   	push   ax
     9a3:	61                   	popa
     9a4:	72 65                	jb     0xa0b
     9a6:	6e                   	outs   dx,BYTE PTR ds:[si]
     9a7:	74 43                	je     0x9ec
     9a9:	74 6c                	je     0xa17
     9ab:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     9ae:	23 d2                	and    dx,dx
     9b0:	09 2b                	or     WORD PTR [bp+di],bp
     9b2:	00 ff                	add    bh,bh
     9b4:	ff                   	(bad)
     9b5:	3e 1e                	ds push ds
     9b7:	da 09                	fimul  DWORD PTR [bx+di]
     9b9:	01 00                	add    WORD PTR [bx+si],ax
     9bb:	00 00                	add    BYTE PTR [bx+si],al
     9bd:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     9c1:	00 00                	add    BYTE PTR [bx+si],al
     9c3:	18 00                	sbb    BYTE PTR [bx+si],al
     9c5:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     9c8:	72 65                	jb     0xa2f
     9ca:	6e                   	outs   dx,BYTE PTR ds:[si]
     9cb:	74 46                	je     0xa13
     9cd:	6f                   	outs   dx,WORD PTR ds:[si]
     9ce:	6e                   	outs   dx,BYTE PTR ds:[si]
     9cf:	74 07                	je     0x9d8
     9d1:	23 1b                	and    bx,WORD PTR [bp+di]
     9d3:	0a 49 00             	or     cl,BYTE PTR [bx+di+0x0]
     9d6:	ff                   	(bad)
     9d7:	ff a1 1e 23          	jmp    WORD PTR [bx+di+0x231e]
     9db:	0a 01                	or     al,BYTE PTR [bx+di]
     9dd:	00 00                	add    BYTE PTR [bx+si],al
     9df:	00 00                	add    BYTE PTR [bx+si],al
     9e1:	80 01 00             	add    BYTE PTR [bx+di],0x0
     9e4:	00 00                	add    BYTE PTR [bx+si],al
     9e6:	19 00                	sbb    WORD PTR [bx+si],ax
     9e8:	0e                   	push   cs
     9e9:	50                   	push   ax
     9ea:	61                   	popa
     9eb:	72 65                	jb     0xa52
     9ed:	6e                   	outs   dx,BYTE PTR ds:[si]
     9ee:	74 53                	je     0xa43
     9f0:	68 6f 77             	push   0x776f
     9f3:	48                   	dec    ax
     9f4:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     9f9:	0a 0f                	or     cl,BYTE PTR [bx]
     9fb:	40                   	inc    ax
     9fc:	00 ff                	add    bh,bh
     9fe:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     a01:	ff                   	(bad)
     a02:	ff 01                	inc    WORD PTR [bx+di]
     a04:	00 00                	add    BYTE PTR [bx+si],al
     a06:	00 00                	add    BYTE PTR [bx+si],al
     a08:	80 00 00             	add    BYTE PTR [bx+si],0x0
     a0b:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     a0f:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     a12:	70 75                	jo     0xa89
     a14:	70 4d                	jo     0xa63
     a16:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a18:	75 07                	jne    0xa21
     a1a:	23 5d 0a             	and    bx,WORD PTR [di+0xa]
     a1d:	48                   	dec    ax
     a1e:	00 ff                	add    bh,bh
     a20:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     a23:	27                   	daa
     a24:	0a 23                	or     ah,BYTE PTR [bp+di]
     a26:	1e                   	push   ds
     a27:	3c 0a                	cmp    al,0xa
     a29:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     a2d:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     a31:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     a34:	6f                   	outs   dx,WORD PTR ds:[si]
     a35:	77 48                	ja     0xa7f
     a37:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     a3c:	40                   	inc    ax
     a3d:	0a a6 63 44          	or     ah,BYTE PTR [bp+0x4463]
     a41:	0a 60 64             	or     ah,BYTE PTR [bx+si+0x64]
     a44:	65 0a 01             	or     al,BYTE PTR gs:[bx+di]
     a47:	00 00                	add    BYTE PTR [bx+si],al
     a49:	00 00                	add    BYTE PTR [bx+si],al
     a4b:	80 ff ff             	cmp    bh,0xff
     a4e:	ff                   	(bad)
     a4f:	ff 1c                	call   DWORD PTR [si]
     a51:	00 08                	add    BYTE PTR [bx+si],cl
     a53:	54                   	push   sp
     a54:	61                   	popa
     a55:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     a58:	64 65 72 07          	fs gs jb 0xa63
     a5c:	23 7d 0a             	and    di,WORD PTR [di+0xa]
     a5f:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     a60:	00 ff                	add    bh,bh
     a62:	ff 88 64 85          	dec    WORD PTR [bx+si-0x7a9c]
     a66:	0a 01                	or     al,BYTE PTR [bx+di]
     a68:	00 00                	add    BYTE PTR [bx+si],al
     a6a:	00 00                	add    BYTE PTR [bx+si],al
     a6c:	80 01 00             	add    BYTE PTR [bx+di],0x0
     a6f:	00 00                	add    BYTE PTR [bx+si],al
     a71:	09 00                	or     WORD PTR [bx+si],ax
     a73:	07                   	pop    es
     a74:	54                   	push   sp
     a75:	61                   	popa
     a76:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     a79:	6f                   	outs   dx,WORD PTR ds:[si]
     a7a:	70 07                	jo     0xa83
     a7c:	23 bf 0c 29          	and    di,WORD PTR [bx+0x290c]
     a80:	00 ff                	add    bh,bh
     a82:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     a85:	01 0b                	add    WORD PTR [bp+di],cx
     a87:	01 00                	add    WORD PTR [bx+si],ax
     a89:	00 00                	add    BYTE PTR [bx+si],al
     a8b:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     a8f:	00 00                	add    BYTE PTR [bx+si],al
     a91:	1d 00 07             	sbb    ax,0x700
     a94:	56                   	push   si
     a95:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     a9a:	65 71 00             	gs jno 0xa9d
     a9d:	be 0a 1b             	mov    si,0x1b0a
     aa0:	02 ff                	add    bh,bh
     aa2:	ff 1b                	call   DWORD PTR [bp+di]
     aa4:	02 ff                	add    bh,bh
     aa6:	ff 01                	inc    WORD PTR [bx+di]
     aa8:	00 00                	add    BYTE PTR [bx+si],al
     aaa:	00 00                	add    BYTE PTR [bx+si],al
     aac:	80 00 00             	add    BYTE PTR [bx+si],0x0
     aaf:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
     ab3:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     ab6:	43                   	inc    bx
     ab7:	68 61 6e             	push   0x6e61
     aba:	67 65 71 00          	addr32 gs jno 0xabe
     abe:	de 0a                	fimul  WORD PTR [bp+si]
     ac0:	7a 00                	jp     0xac2
     ac2:	ff                   	(bad)
     ac3:	ff                   	(bad)
     ac4:	7a 00                	jp     0xac6
     ac6:	ff                   	(bad)
     ac7:	ff 01                	inc    WORD PTR [bx+di]
     ac9:	00 00                	add    BYTE PTR [bx+si],al
     acb:	00 00                	add    BYTE PTR [bx+si],al
     acd:	80 00 00             	add    BYTE PTR [bx+si],0x0
     ad0:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
     ad4:	07                   	pop    es
     ad5:	4f                   	dec    di
     ad6:	6e                   	outs   dx,BYTE PTR ds:[si]
     ad7:	43                   	inc    bx
     ad8:	6c                   	ins    BYTE PTR es:[di],dx
     ad9:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     ade:	69 0b 82 00          	imul   cx,WORD PTR [bp+di],0x82
     ae2:	ff                   	(bad)
     ae3:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     ae7:	ff 01                	inc    WORD PTR [bx+di]
     ae9:	00 00                	add    BYTE PTR [bx+si],al
     aeb:	00 00                	add    BYTE PTR [bx+si],al
     aed:	80 00 00             	add    BYTE PTR [bx+si],0x0
     af0:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
     af4:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     af7:	44                   	inc    sp
     af8:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     afb:	6c                   	ins    BYTE PTR es:[di],dx
     afc:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     b01:	24 0b                	and    al,0xb
     b03:	62 00                	bound  ax,DWORD PTR [bx+si]
     b05:	ff                   	(bad)
     b06:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     b09:	ff                   	(bad)
     b0a:	ff 01                	inc    WORD PTR [bx+di]
     b0c:	00 00                	add    BYTE PTR [bx+si],al
     b0e:	00 00                	add    BYTE PTR [bx+si],al
     b10:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b13:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     b17:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     b1a:	44                   	inc    sp
     b1b:	72 61                	jb     0xb7e
     b1d:	67 44                	addr32 inc sp
     b1f:	72 6f                	jb     0xb90
     b21:	70 80                	jo     0xaa3
     b23:	02 47 0b             	add    al,BYTE PTR [bx+0xb]
     b26:	6a 00                	push   0x0
     b28:	ff                   	(bad)
     b29:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     b2c:	ff                   	(bad)
     b2d:	ff 01                	inc    WORD PTR [bx+di]
     b2f:	00 00                	add    BYTE PTR [bx+si],al
     b31:	00 00                	add    BYTE PTR [bx+si],al
     b33:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b36:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     b3a:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     b3d:	44                   	inc    sp
     b3e:	72 61                	jb     0xba1
     b40:	67 4f                	addr32 dec di
     b42:	76 65                	jbe    0xba9
     b44:	72 32                	jb     0xb78
     b46:	03 a8 0b 72          	add    bp,WORD PTR [bx+si+0x720b]
     b4a:	00 ff                	add    bh,bh
     b4c:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     b4f:	ff                   	(bad)
     b50:	ff 01                	inc    WORD PTR [bx+di]
     b52:	00 00                	add    BYTE PTR [bx+si],al
     b54:	00 00                	add    BYTE PTR [bx+si],al
     b56:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b59:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     b5d:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     b60:	45                   	inc    bp
     b61:	6e                   	outs   dx,BYTE PTR ds:[si]
     b62:	64 44                	fs inc sp
     b64:	72 61                	jb     0xbc7
     b66:	67 71 00             	addr32 jno 0xb69
     b69:	89 0b                	mov    WORD PTR [bp+di],cx
     b6b:	c8 00 ff ff          	enter  0xff00,0xff
     b6f:	c8 00 ff ff          	enter  0xff00,0xff
     b73:	01 00                	add    WORD PTR [bx+si],ax
     b75:	00 00                	add    BYTE PTR [bx+si],al
     b77:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     b7b:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     b7f:	07                   	pop    es
     b80:	4f                   	dec    di
     b81:	6e                   	outs   dx,BYTE PTR ds:[si]
     b82:	45                   	inc    bp
     b83:	6e                   	outs   dx,BYTE PTR ds:[si]
     b84:	74 65                	je     0xbeb
     b86:	72 71                	jb     0xbf9
     b88:	00 d7                	add    bh,dl
     b8a:	0c d0                	or     al,0xd0
     b8c:	00 ff                	add    bh,bh
     b8e:	ff d0                	call   ax
     b90:	00 ff                	add    bh,bh
     b92:	ff 01                	inc    WORD PTR [bx+di]
     b94:	00 00                	add    BYTE PTR [bx+si],al
     b96:	00 00                	add    BYTE PTR [bx+si],al
     b98:	80 00 00             	add    BYTE PTR [bx+si],0x0
     b9b:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     b9f:	06                   	push   es
     ba0:	4f                   	dec    di
     ba1:	6e                   	outs   dx,BYTE PTR ds:[si]
     ba2:	45                   	inc    bp
     ba3:	78 69                	js     0xc0e
     ba5:	74 1a                	je     0xbc1
     ba7:	02 ca                	add    cl,dl
     ba9:	0b b0 00 ff          	or     si,WORD PTR [bx+si-0x100]
     bad:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     bb1:	ff 01                	inc    WORD PTR [bx+di]
     bb3:	00 00                	add    BYTE PTR [bx+si],al
     bb5:	00 00                	add    BYTE PTR [bx+si],al
     bb7:	80 00 00             	add    BYTE PTR [bx+si],0x0
     bba:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
     bbe:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     bc1:	4b                   	dec    bx
     bc2:	65 79 44             	gs jns 0xc09
     bc5:	6f                   	outs   dx,WORD PTR ds:[si]
     bc6:	77 6e                	ja     0xc36
     bc8:	54                   	push   sp
     bc9:	02 ed                	add    ch,ch
     bcb:	0b b8 00 ff          	or     di,WORD PTR [bx+si-0x100]
     bcf:	ff                   	(bad)
     bd0:	b8 00 ff             	mov    ax,0xff00
     bd3:	ff 01                	inc    WORD PTR [bx+di]
     bd5:	00 00                	add    BYTE PTR [bx+si],al
     bd7:	00 00                	add    BYTE PTR [bx+si],al
     bd9:	80 00 00             	add    BYTE PTR [bx+si],0x0
     bdc:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
     be0:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     be3:	4b                   	dec    bx
     be4:	65 79 50             	gs jns 0xc37
     be7:	72 65                	jb     0xc4e
     be9:	73 73                	jae    0xc5e
     beb:	1a 02                	sbb    al,BYTE PTR [bp+si]
     bed:	0d 0c c0             	or     ax,0xc00c
     bf0:	00 ff                	add    bh,bh
     bf2:	ff c0                	inc    ax
     bf4:	00 ff                	add    bh,bh
     bf6:	ff 01                	inc    WORD PTR [bx+di]
     bf8:	00 00                	add    BYTE PTR [bx+si],al
     bfa:	00 00                	add    BYTE PTR [bx+si],al
     bfc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     bff:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
     c03:	07                   	pop    es
     c04:	4f                   	dec    di
     c05:	6e                   	outs   dx,BYTE PTR ds:[si]
     c06:	4b                   	dec    bx
     c07:	65 79 55             	gs jns 0xc5f
     c0a:	70 71                	jo     0xc7d
     c0c:	01 31                	add    WORD PTR [bx+di],si
     c0e:	0c 4a                	or     al,0x4a
     c10:	00 ff                	add    bh,bh
     c12:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     c15:	ff                   	(bad)
     c16:	ff 01                	inc    WORD PTR [bx+di]
     c18:	00 00                	add    BYTE PTR [bx+si],al
     c1a:	00 00                	add    BYTE PTR [bx+si],al
     c1c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c1f:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
     c23:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     c26:	4d                   	dec    bp
     c27:	6f                   	outs   dx,WORD PTR ds:[si]
     c28:	75 73                	jne    0xc9d
     c2a:	65 44                	gs inc sp
     c2c:	6f                   	outs   dx,WORD PTR ds:[si]
     c2d:	77 6e                	ja     0xc9d
     c2f:	ce                   	into
     c30:	01 55 0c             	add    WORD PTR [di+0xc],dx
     c33:	52                   	push   dx
     c34:	00 ff                	add    bh,bh
     c36:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     c39:	ff                   	(bad)
     c3a:	ff 01                	inc    WORD PTR [bx+di]
     c3c:	00 00                	add    BYTE PTR [bx+si],al
     c3e:	00 00                	add    BYTE PTR [bx+si],al
     c40:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c43:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
     c47:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     c4a:	4d                   	dec    bp
     c4b:	6f                   	outs   dx,WORD PTR ds:[si]
     c4c:	75 73                	jne    0xcc1
     c4e:	65 4d                	gs dec bp
     c50:	6f                   	outs   dx,WORD PTR ds:[si]
     c51:	76 65                	jbe    0xcb8
     c53:	71 01                	jno    0xc56
     c55:	1b 0d                	sbb    cx,WORD PTR [di]
     c57:	5a                   	pop    dx
     c58:	00 ff                	add    bh,bh
     c5a:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     c5d:	ff                   	(bad)
     c5e:	ff 01                	inc    WORD PTR [bx+di]
     c60:	00 00                	add    BYTE PTR [bx+si],al
     c62:	00 00                	add    BYTE PTR [bx+si],al
     c64:	80 00 00             	add    BYTE PTR [bx+si],0x0
     c67:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
     c6b:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     c6e:	4d                   	dec    bp
     c6f:	6f                   	outs   dx,WORD PTR ds:[si]
     c70:	75 73                	jne    0xce5
     c72:	65 55                	gs push bp
     c74:	70 03                	jo     0xc79
     c76:	09 54 54             	or     WORD PTR [si+0x54],dx
     c79:	65 78 74             	gs js  0xcf0
     c7c:	43                   	inc    bx
     c7d:	61                   	popa
     c7e:	73 65                	jae    0xce5
     c80:	00 00                	add    BYTE PTR [bx+si],al
     c82:	00 00                	add    BYTE PTR [bx+si],al
     c84:	00 01                	add    BYTE PTR [bx+di],al
     c86:	00 00                	add    BYTE PTR [bx+si],al
     c88:	00 75 0c             	add    BYTE PTR [di+0xc],dh
     c8b:	27                   	daa
     c8c:	0d 0b 74             	or     ax,0x740b
     c8f:	63 4c 6f             	arpl   WORD PTR [si+0x6f],cx
     c92:	77 65                	ja     0xcf9
     c94:	72 43                	jb     0xcd9
     c96:	61                   	popa
     c97:	73 65                	jae    0xcfe
     c99:	0b 74 63             	or     si,WORD PTR [si+0x63]
     c9c:	55                   	push   bp
     c9d:	70 70                	jo     0xd0f
     c9f:	65 72 43             	gs jb  0xce5
     ca2:	61                   	popa
     ca3:	73 65                	jae    0xd0a
     ca5:	74 0d                	je     0xcb4
     ca7:	00 00                	add    BYTE PTR [bx+si],al
     ca9:	00 00                	add    BYTE PTR [bx+si],al
     cab:	60                   	pusha
     cac:	0d 51 0d             	or     ax,0xd51
     caf:	44                   	inc    sp
     cb0:	01 ba 19 8a          	add    WORD PTR [bp+si-0x75e7],di
     cb4:	0d fa 45             	or     ax,0x45fa
     cb7:	2b 0d                	sub    cx,WORD PTR [di]
     cb9:	9a 1f b9 0d cb       	call   0xcb0d:0xb91f
     cbe:	1f                   	pop    ds
     cbf:	bb 0c 99             	mov    bx,0x990c
     cc2:	1a 6a 0d             	sbb    ch,BYTE PTR [bp+si+0xd]
     cc5:	cd 11                	int    0x11
     cc7:	cf                   	iret
     cc8:	0c 3a                	or     al,0x3a
     cca:	27                   	daa
     ccb:	d3 0c                	ror    WORD PTR [si],cl
     ccd:	fa                   	cli
     cce:	10 cf                	adc    bh,cl
     cd0:	0f d6                	(bad)
     cd2:	14 03                	adc    al,0x3
     cd4:	0d f4 4f             	or     ax,0x4ff4
     cd7:	e7 0c                	out    0xc,ax
     cd9:	17                   	pop    ss
     cda:	22 f3                	and    dh,bl
     cdc:	0c ec                	or     al,0xec
     cde:	30 3b                	xor    BYTE PTR [bp+di],bh
     ce0:	0d 51 1b             	or     ax,0x1b51
     ce3:	a3 0d 38             	mov    ds:0x380d,ax
     ce6:	50                   	push   ax
     ce7:	ef                   	out    dx,ax
     ce8:	0c 63                	or     al,0x63
     cea:	31 0b                	xor    WORD PTR [bp+di],cx
     cec:	0d 21 50             	or     ax,0x5021
     cef:	c7                   	(bad)
     cf0:	0c 27                	or     al,0x27
     cf2:	1a c3                	sbb    al,bl
     cf4:	0c d9                	or     al,0xd9
     cf6:	62 fb 0c             	(bad)  {k6}
     cf9:	06                   	push   es
     cfa:	63 ff                	arpl   di,di
     cfc:	0c 8f                	or     al,0x8f
     cfe:	60                   	pusha
     cff:	37                   	aaa
     d00:	0d 3a 1c             	or     ax,0x1c3a
     d03:	e3 0c                	jcxz   0xd11
     d05:	15 64 1f             	adc    ax,0x1f64
     d08:	0d 08 61             	or     ax,0x6108
     d0b:	0f 0d 5c 61          	prefetch BYTE PTR [si+0x61]
     d0f:	13 0d                	adc    cx,WORD PTR [di]
     d11:	62 5c 3f             	bound  bx,DWORD PTR [si+0x3f]
     d14:	0d 3a 61             	or     ax,0x613a
     d17:	cb                   	retf
     d18:	0c 72                	or     al,0x72
     d1a:	3f                   	aas
     d1b:	23 0d                	and    cx,WORD PTR [di]
     d1d:	6b 5d 2f 0d          	imul   bx,WORD PTR [di+0x2f],0xd
     d21:	17                   	pop    ss
     d22:	3e b7 0c             	ds mov bh,0xc
     d25:	6e                   	outs   dx,BYTE PTR ds:[si]
     d26:	1e                   	push   ds
     d27:	47                   	inc    di
     d28:	0d ed 3e             	or     ax,0x3eed
     d2b:	33 0d                	xor    cx,WORD PTR [di]
     d2d:	43                   	inc    bx
     d2e:	5f                   	pop    di
     d2f:	4b                   	dec    bx
     d30:	0d c2 35             	or     ax,0x35c2
     d33:	f7 0c 1c 48          	test   WORD PTR [si],0x481c
     d37:	df 0c                	fisttp WORD PTR [si]
     d39:	ae                   	scas   al,BYTE PTR es:[di]
     d3a:	5f                   	pop    di
     d3b:	eb 0c                	jmp    0xd49
     d3d:	35 62 17             	xor    ax,0x1762
     d40:	0d 72 62             	or     ax,0x6272
     d43:	07                   	pop    es
     d44:	0d 9c 1e             	or     ax,0x1e9c
     d47:	4f                   	dec    di
     d48:	0d 56 67             	or     ax,0x6756
     d4b:	b3 0c                	mov    bl,0xc
     d4d:	0f 1b db             	nop    bx
     d50:	0c 0e                	or     al,0xe
     d52:	54                   	push   sp
     d53:	44                   	inc    sp
     d54:	72 69                	jb     0xdbf
     d56:	76 65                	jbe    0xdbd
     d58:	43                   	inc    bx
     d59:	6f                   	outs   dx,WORD PTR ds:[si]
     d5a:	6d                   	ins    WORD PTR es:[di],dx
     d5b:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     d5e:	6f                   	outs   dx,WORD PTR ds:[si]
     d5f:	78 03                	js     0xd64
     d61:	00 0e 0f fe          	add    BYTE PTR ds:0xfe0f,cl
     d65:	ff                   	jmp    (bad)
     d66:	ec                   	in     al,dx
     d67:	ff 6e 20             	jmp    DWORD PTR [bp+0x20]
     d6a:	6e                   	outs   dx,BYTE PTR ds:[si]
     d6b:	0d 1a 20             	or     ax,0x201a
     d6e:	72 0d                	jb     0xd7d
     d70:	5b                   	pop    bx
     d71:	22 86 0d 07          	and    al,BYTE PTR [bp+0x70d]
     d75:	0e                   	push   cs
     d76:	54                   	push   sp
     d77:	44                   	inc    sp
     d78:	72 69                	jb     0xde3
     d7a:	76 65                	jbe    0xde1
     d7c:	43                   	inc    bx
     d7d:	6f                   	outs   dx,WORD PTR ds:[si]
     d7e:	6d                   	ins    WORD PTR es:[di],dx
     d7f:	62 6f 42             	bound  bp,DWORD PTR [bx+0x42]
     d82:	6f                   	outs   dx,WORD PTR ds:[si]
     d83:	78 c5                	js     0xd4a
     d85:	0c d7                	or     al,0xd7
     d87:	0d ae 1a             	or     ax,0x1aae
     d8a:	4a                   	dec    dx
     d8b:	1a 26 00 08          	sbb    ah,BYTE PTR ds:0x800
     d8f:	46                   	inc    si
     d90:	69 6c 65 43 74       	imul   bp,WORD PTR [si+0x65],0x7443
     d95:	72 6c                	jb     0xe03
     d97:	1d 00 02             	sbb    ax,0x200
     d9a:	00 5b 0e             	add    BYTE PTR [bp+di+0xe],bl
     d9d:	38 00                	cmp    BYTE PTR [bx+si],al
     d9f:	ff                   	(bad)
     da0:	ff d5                	call   bp
     da2:	1e                   	push   ds
     da3:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     da4:	0d 17 1f             	or     ax,0x1f17
     da7:	c1 0d 00             	ror    WORD PTR [di],0x0
     daa:	80 fa ff             	cmp    dl,0xff
     dad:	ff                   	(bad)
     dae:	ff 0a                	dec    WORD PTR [bp+si]
     db0:	00 05                	add    BYTE PTR [di],al
     db2:	43                   	inc    bx
     db3:	6f                   	outs   dx,WORD PTR ds:[si]
     db4:	6c                   	ins    BYTE PTR es:[di],dx
     db5:	6f                   	outs   dx,WORD PTR ds:[si]
     db6:	72 07                	jb     0xdbf
     db8:	23 3b                	and    di,WORD PTR [bp+di]
     dba:	0e                   	push   cs
     dbb:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     dbc:	00 ff                	add    bh,bh
     dbe:	ff 22                	jmp    WORD PTR [bp+si]
     dc0:	63 c5                	arpl   bp,ax
     dc2:	0d 54 63             	or     ax,0x6354
     dc5:	f7 0d 00 80          	test   WORD PTR [di],0x8000
     dc9:	00 00                	add    BYTE PTR [bx+si],al
     dcb:	00 80 0b 00          	add    BYTE PTR [bx+si+0xb],al
     dcf:	05 43 74             	add    ax,0x7443
     dd2:	6c                   	ins    BYTE PTR es:[di],dx
     dd3:	33 44 b6             	xor    ax,WORD PTR [si-0x4a]
     dd6:	07                   	pop    es
     dd7:	df 0d                	fisttp WORD PTR [di]
     dd9:	22 01                	and    al,BYTE PTR [bx+di]
     ddb:	ff                   	(bad)
     ddc:	ff 13                	call   WORD PTR [bp+di]
     dde:	1e                   	push   ds
     ddf:	8e 0f                	mov    cs,WORD PTR [bx]
     de1:	01 00                	add    WORD PTR [bx+si],ax
     de3:	00 00                	add    BYTE PTR [bx+si],al
     de5:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     de9:	00 80 0c 00          	add    BYTE PTR [bx+si+0xc],al
     ded:	07                   	pop    es
     dee:	44                   	inc    sp
     def:	69 72 4c 69 73       	imul   si,WORD PTR [bp+si+0x4c],0x7369
     df4:	74 25                	je     0xe1b
     df6:	01 18                	add    WORD PTR [bx+si],bx
     df8:	0e                   	push   cs
     df9:	2e 00 ff             	cs add bh,bh
     dfc:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     e00:	ff 01                	inc    WORD PTR [bx+di]
     e02:	00 00                	add    BYTE PTR [bx+si],al
     e04:	00 00                	add    BYTE PTR [bx+si],al
     e06:	80 00 00             	add    BYTE PTR [bx+si],0x0
     e09:	00 00                	add    BYTE PTR [bx+si],al
     e0b:	0d 00 08             	or     ax,0x800
     e0e:	44                   	inc    sp
     e0f:	72 61                	jb     0xe72
     e11:	67 4d                	addr32 dec bp
     e13:	6f                   	outs   dx,WORD PTR ds:[si]
     e14:	64 65 64 00 43 0e    	fs gs add BYTE PTR fs:[bp+di+0xe],al
     e1a:	3e 00 ff             	ds add bh,bh
     e1d:	ff                   	(bad)
     e1e:	3e 00 ff             	ds add bh,bh
     e21:	ff 01                	inc    WORD PTR [bx+di]
     e23:	00 00                	add    BYTE PTR [bx+si],al
     e25:	00 00                	add    BYTE PTR [bx+si],al
     e27:	80 f4 ff             	xor    ah,0xff
     e2a:	ff                   	(bad)
     e2b:	ff 0e 00 0a          	dec    WORD PTR ds:0xa00
     e2f:	44                   	inc    sp
     e30:	72 61                	jb     0xe93
     e32:	67 43                	addr32 inc bx
     e34:	75 72                	jne    0xea8
     e36:	73 6f                	jae    0xea7
     e38:	72 07                	jb     0xe41
     e3a:	23 78 0e             	and    di,WORD PTR [bx+si+0xe]
     e3d:	2a 00                	sub    al,BYTE PTR [bx+si]
     e3f:	ff                   	(bad)
     e40:	ff                   	(bad)
     e41:	b8 1c 63             	mov    ax,0x631c
     e44:	0e                   	push   cs
     e45:	01 00                	add    WORD PTR [bx+si],ax
     e47:	00 00                	add    BYTE PTR [bx+si],al
     e49:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     e4d:	00 00                	add    BYTE PTR [bx+si],al
     e4f:	0f 00 07             	sldt   WORD PTR [bx]
     e52:	45                   	inc    bp
     e53:	6e                   	outs   dx,BYTE PTR ds:[si]
     e54:	61                   	popa
     e55:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e58:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     e5b:	29 14                	sub    WORD PTR [si],dx
     e5d:	34 00                	xor    al,0x0
     e5f:	ff                   	(bad)
     e60:	ff                   	jmp    (bad)
     e61:	eb 1d                	jmp    0xe80
     e63:	67 0e                	addr32 push cs
     e65:	08 1e 80 0e          	or     BYTE PTR ds:0xe80,bl
     e69:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     e6d:	00 80 10 00          	add    BYTE PTR [bx+si+0x10],al
     e71:	04 46                	add    al,0x46
     e73:	6f                   	outs   dx,WORD PTR ds:[si]
     e74:	6e                   	outs   dx,BYTE PTR ds:[si]
     e75:	74 07                	je     0xe7e
     e77:	23 9c 0e 2c          	and    bx,WORD PTR [si+0x2c0e]
     e7b:	00 ff                	add    bh,bh
     e7d:	ff 32                	push   WORD PTR [bp+si]
     e7f:	1f                   	pop    ds
     e80:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     e81:	0e                   	push   cs
     e82:	01 00                	add    WORD PTR [bx+si],ax
     e84:	00 00                	add    BYTE PTR [bx+si],al
     e86:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     e8a:	00 00                	add    BYTE PTR [bx+si],al
     e8c:	11 00                	adc    WORD PTR [bx+si],ax
     e8e:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     e91:	72 65                	jb     0xef8
     e93:	6e                   	outs   dx,BYTE PTR ds:[si]
     e94:	74 43                	je     0xed9
     e96:	6f                   	outs   dx,WORD PTR ds:[si]
     e97:	6c                   	ins    BYTE PTR es:[di],dx
     e98:	6f                   	outs   dx,WORD PTR ds:[si]
     e99:	72 07                	jb     0xea2
     e9b:	23 c0                	and    ax,ax
     e9d:	0e                   	push   cs
     e9e:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     e9f:	00 ff                	add    bh,bh
     ea1:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     ea4:	c8 0e 01 00          	enter  0x10e,0x0
     ea8:	00 00                	add    BYTE PTR [bx+si],al
     eaa:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     eae:	00 00                	add    BYTE PTR [bx+si],al
     eb0:	12 00                	adc    al,BYTE PTR [bx+si]
     eb2:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     eb5:	72 65                	jb     0xf1c
     eb7:	6e                   	outs   dx,BYTE PTR ds:[si]
     eb8:	74 43                	je     0xefd
     eba:	74 6c                	je     0xf28
     ebc:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     ebf:	23 e3                	and    sp,bx
     ec1:	0e                   	push   cs
     ec2:	2b 00                	sub    ax,WORD PTR [bx+si]
     ec4:	ff                   	(bad)
     ec5:	ff                   	(bad)
     ec6:	3e 1e                	ds push ds
     ec8:	eb 0e                	jmp    0xed8
     eca:	01 00                	add    WORD PTR [bx+si],ax
     ecc:	00 00                	add    BYTE PTR [bx+si],al
     ece:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     ed2:	00 00                	add    BYTE PTR [bx+si],al
     ed4:	13 00                	adc    ax,WORD PTR [bx+si]
     ed6:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     ed9:	72 65                	jb     0xf40
     edb:	6e                   	outs   dx,BYTE PTR ds:[si]
     edc:	74 46                	je     0xf24
     ede:	6f                   	outs   dx,WORD PTR ds:[si]
     edf:	6e                   	outs   dx,BYTE PTR ds:[si]
     ee0:	74 07                	je     0xee9
     ee2:	23 2c                	and    bp,WORD PTR [si]
     ee4:	0f 49 00             	cmovns ax,WORD PTR [bx+si]
     ee7:	ff                   	(bad)
     ee8:	ff a1 1e 34          	jmp    WORD PTR [bx+di+0x341e]
     eec:	0f 01 00             	sgdtw  [bx+si]
     eef:	00 00                	add    BYTE PTR [bx+si],al
     ef1:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     ef5:	00 00                	add    BYTE PTR [bx+si],al
     ef7:	14 00                	adc    al,0x0
     ef9:	0e                   	push   cs
     efa:	50                   	push   ax
     efb:	61                   	popa
     efc:	72 65                	jb     0xf63
     efe:	6e                   	outs   dx,BYTE PTR ds:[si]
     eff:	74 53                	je     0xf54
     f01:	68 6f 77             	push   0x776f
     f04:	48                   	dec    ax
     f05:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     f0a:	ff                   	(bad)
     f0b:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     f0e:	ff                   	(bad)
     f0f:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     f12:	ff                   	(bad)
     f13:	ff 01                	inc    WORD PTR [bx+di]
     f15:	00 00                	add    BYTE PTR [bx+si],al
     f17:	00 00                	add    BYTE PTR [bx+si],al
     f19:	80 00 00             	add    BYTE PTR [bx+si],0x0
     f1c:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     f20:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     f23:	70 75                	jo     0xf9a
     f25:	70 4d                	jo     0xf74
     f27:	65 6e                	outs   dx,BYTE PTR gs:[si]
     f29:	75 07                	jne    0xf32
     f2b:	23 6e 0f             	and    bp,WORD PTR [bp+0xf]
     f2e:	48                   	dec    ax
     f2f:	00 ff                	add    bh,bh
     f31:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     f34:	38 0f                	cmp    BYTE PTR [bx],cl
     f36:	23 1e 4d 0f          	and    bx,WORD PTR ds:0xf4d
     f3a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     f3e:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     f42:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     f45:	6f                   	outs   dx,WORD PTR ds:[si]
     f46:	77 48                	ja     0xf90
     f48:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     f4d:	51                   	push   cx
     f4e:	0f a6                	(bad)
     f50:	63 55 0f             	arpl   WORD PTR [di+0xf],dx
     f53:	60                   	pusha
     f54:	64 76 0f             	fs jbe 0xf66
     f57:	01 00                	add    WORD PTR [bx+si],ax
     f59:	00 00                	add    BYTE PTR [bx+si],al
     f5b:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     f5f:	ff                   	(bad)
     f60:	ff 17                	call   WORD PTR [bx]
     f62:	00 08                	add    BYTE PTR [bx+si],cl
     f64:	54                   	push   sp
     f65:	61                   	popa
     f66:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     f69:	64 65 72 07          	fs gs jb 0xf74
     f6d:	23 af 0f a4          	and    bp,WORD PTR [bx-0x5bf1]
     f71:	00 ff                	add    bh,bh
     f73:	ff 88 64 b7          	dec    WORD PTR [bx+si-0x489c]
     f77:	0f 01 00             	sgdtw  [bx+si]
     f7a:	00 00                	add    BYTE PTR [bx+si],al
     f7c:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     f80:	00 00                	add    BYTE PTR [bx+si],al
     f82:	09 00                	or     WORD PTR [bx+si],ax
     f84:	07                   	pop    es
     f85:	54                   	push   sp
     f86:	61                   	popa
     f87:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     f8a:	6f                   	outs   dx,WORD PTR ds:[si]
     f8b:	70 75                	jo     0x1002
     f8d:	0c 92                	or     al,0x92
     f8f:	0f ca                	bswap  dx
     f91:	1d 96 0f             	sbb    ax,0xf96
     f94:	e0 1d                	loopne 0xfb3
     f96:	c2 14 01             	ret    0x114
     f99:	00 00                	add    BYTE PTR [bx+si],al
     f9b:	00 00                	add    BYTE PTR [bx+si],al
     f9d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     fa0:	00 00                	add    BYTE PTR [bx+si],al
     fa2:	18 00                	sbb    BYTE PTR [bx+si],al
     fa4:	08 54 65             	or     BYTE PTR [si+0x65],dl
     fa7:	78 74                	js     0x101d
     fa9:	43                   	inc    bx
     faa:	61                   	popa
     fab:	73 65                	jae    0x1012
     fad:	07                   	pop    es
     fae:	23 2c                	and    bp,WORD PTR [si]
     fb0:	12 29                	adc    ch,BYTE PTR [bx+di]
     fb2:	00 ff                	add    bh,bh
     fb4:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     fb7:	33 10                	xor    dx,WORD PTR [bx+si]
     fb9:	01 00                	add    WORD PTR [bx+si],ax
     fbb:	00 00                	add    BYTE PTR [bx+si],al
     fbd:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     fc1:	00 00                	add    BYTE PTR [bx+si],al
     fc3:	19 00                	sbb    WORD PTR [bx+si],ax
     fc5:	07                   	pop    es
     fc6:	56                   	push   si
     fc7:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     fcc:	65 71 00             	gs jno 0xfcf
     fcf:	f0 0f 3c             	lock (bad)
     fd2:	01 ff                	add    di,di
     fd4:	ff                   	(bad)
     fd5:	3c 01                	cmp    al,0x1
     fd7:	ff                   	(bad)
     fd8:	ff 01                	inc    WORD PTR [bx+di]
     fda:	00 00                	add    BYTE PTR [bx+si],al
     fdc:	00 00                	add    BYTE PTR [bx+si],al
     fde:	80 00 00             	add    BYTE PTR [bx+si],0x0
     fe1:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     fe5:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     fe8:	43                   	inc    bx
     fe9:	68 61 6e             	push   0x6e61
     fec:	67 65 71 00          	addr32 gs jno 0xff0
     ff0:	10 10                	adc    BYTE PTR [bx+si],dl
     ff2:	7a 00                	jp     0xff4
     ff4:	ff                   	(bad)
     ff5:	ff                   	(bad)
     ff6:	7a 00                	jp     0xff8
     ff8:	ff                   	(bad)
     ff9:	ff 01                	inc    WORD PTR [bx+di]
     ffb:	00 00                	add    BYTE PTR [bx+si],al
     ffd:	00 00                	add    BYTE PTR [bx+si],al
     fff:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1002:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
    1006:	07                   	pop    es
    1007:	4f                   	dec    di
    1008:	6e                   	outs   dx,BYTE PTR ds:[si]
    1009:	43                   	inc    bx
    100a:	6c                   	ins    BYTE PTR es:[di],dx
    100b:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
    1010:	79 10                	jns    0x1022
    1012:	82 00 ff             	add    BYTE PTR [bx+si],0xff
    1015:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
    1019:	ff 01                	inc    WORD PTR [bx+di]
    101b:	00 00                	add    BYTE PTR [bx+si],al
    101d:	00 00                	add    BYTE PTR [bx+si],al
    101f:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1022:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
    1026:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1029:	44                   	inc    sp
    102a:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
    102d:	6c                   	ins    BYTE PTR es:[di],dx
    102e:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
    1033:	56                   	push   si
    1034:	10 62 00             	adc    BYTE PTR [bp+si+0x0],ah
    1037:	ff                   	(bad)
    1038:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
    103b:	ff                   	(bad)
    103c:	ff 01                	inc    WORD PTR [bx+di]
    103e:	00 00                	add    BYTE PTR [bx+si],al
    1040:	00 00                	add    BYTE PTR [bx+si],al
    1042:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1045:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
    1049:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    104c:	44                   	inc    sp
    104d:	72 61                	jb     0x10b0
    104f:	67 44                	addr32 inc sp
    1051:	72 6f                	jb     0x10c2
    1053:	70 80                	jo     0xfd5
    1055:	02 9c 10 6a          	add    bl,BYTE PTR [si+0x6a10]
    1059:	00 ff                	add    bh,bh
    105b:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
    105e:	ff                   	(bad)
    105f:	ff 01                	inc    WORD PTR [bx+di]
    1061:	00 00                	add    BYTE PTR [bx+si],al
    1063:	00 00                	add    BYTE PTR [bx+si],al
    1065:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1068:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
    106c:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    106f:	44                   	inc    sp
    1070:	72 61                	jb     0x10d3
    1072:	67 4f                	addr32 dec di
    1074:	76 65                	jbe    0x10db
    1076:	72 71                	jb     0x10e9
    1078:	00 be 10 fe          	add    BYTE PTR [bp-0x1f0],bh
    107c:	00 ff                	add    bh,bh
    107e:	ff                   	(bad)
    107f:	fe 00                	inc    BYTE PTR [bx+si]
    1081:	ff                   	(bad)
    1082:	ff 01                	inc    WORD PTR [bx+di]
    1084:	00 00                	add    BYTE PTR [bx+si],al
    1086:	00 00                	add    BYTE PTR [bx+si],al
    1088:	80 00 00             	add    BYTE PTR [bx+si],0x0
    108b:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
    108f:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1092:	44                   	inc    sp
    1093:	72 6f                	jb     0x1104
    1095:	70 44                	jo     0x10db
    1097:	6f                   	outs   dx,WORD PTR ds:[si]
    1098:	77 6e                	ja     0x1108
    109a:	32 03                	xor    al,BYTE PTR [bp+di]
    109c:	fd                   	std
    109d:	10 72 00             	adc    BYTE PTR [bp+si+0x0],dh
    10a0:	ff                   	(bad)
    10a1:	ff 72 00             	push   WORD PTR [bp+si+0x0]
    10a4:	ff                   	(bad)
    10a5:	ff 01                	inc    WORD PTR [bx+di]
    10a7:	00 00                	add    BYTE PTR [bx+si],al
    10a9:	00 00                	add    BYTE PTR [bx+si],al
    10ab:	80 00 00             	add    BYTE PTR [bx+si],0x0
    10ae:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
    10b2:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    10b5:	45                   	inc    bp
    10b6:	6e                   	outs   dx,BYTE PTR ds:[si]
    10b7:	64 44                	fs inc sp
    10b9:	72 61                	jb     0x111c
    10bb:	67 71 00             	addr32 jno 0x10be
    10be:	de 10                	ficom  WORD PTR [bx+si]
    10c0:	c8 00 ff ff          	enter  0xff00,0xff
    10c4:	c8 00 ff ff          	enter  0xff00,0xff
    10c8:	01 00                	add    WORD PTR [bx+si],ax
    10ca:	00 00                	add    BYTE PTR [bx+si],al
    10cc:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
    10d0:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
    10d4:	07                   	pop    es
    10d5:	4f                   	dec    di
    10d6:	6e                   	outs   dx,BYTE PTR ds:[si]
    10d7:	45                   	inc    bp
    10d8:	6e                   	outs   dx,BYTE PTR ds:[si]
    10d9:	74 65                	je     0x1140
    10db:	72 71                	jb     0x114e
    10dd:	00 53 1f             	add    BYTE PTR [bp+di+0x1f],dl
    10e0:	d0 00                	rol    BYTE PTR [bx+si],1
    10e2:	ff                   	(bad)
    10e3:	ff d0                	call   ax
    10e5:	00 ff                	add    bh,bh
    10e7:	ff 01                	inc    WORD PTR [bx+di]
    10e9:	00 00                	add    BYTE PTR [bx+si],al
    10eb:	00 00                	add    BYTE PTR [bx+si],al
    10ed:	80 00 00             	add    BYTE PTR [bx+si],0x0
    10f0:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
    10f4:	06                   	push   es
    10f5:	4f                   	dec    di
    10f6:	6e                   	outs   dx,BYTE PTR ds:[si]
    10f7:	45                   	inc    bp
    10f8:	78 69                	js     0x1163
    10fa:	74 1a                	je     0x1116
    10fc:	02 1f                	add    bl,BYTE PTR [bx]
    10fe:	11 b0 00 ff          	adc    WORD PTR [bx+si-0x100],si
    1102:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
    1106:	ff 01                	inc    WORD PTR [bx+di]
    1108:	00 00                	add    BYTE PTR [bx+si],al
    110a:	00 00                	add    BYTE PTR [bx+si],al
    110c:	80 00 00             	add    BYTE PTR [bx+si],0x0
    110f:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
    1113:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
    1116:	4b                   	dec    bx
    1117:	65 79 44             	gs jns 0x115e
    111a:	6f                   	outs   dx,WORD PTR ds:[si]
    111b:	77 6e                	ja     0x118b
    111d:	54                   	push   sp
    111e:	02 42 11             	add    al,BYTE PTR [bp+si+0x11]
    1121:	b8 00 ff             	mov    ax,0xff00
    1124:	ff                   	(bad)
    1125:	b8 00 ff             	mov    ax,0xff00
    1128:	ff 01                	inc    WORD PTR [bx+di]
    112a:	00 00                	add    BYTE PTR [bx+si],al
    112c:	00 00                	add    BYTE PTR [bx+si],al
    112e:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1131:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
    1135:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
    1138:	4b                   	dec    bx
    1139:	65 79 50             	gs jns 0x118c
    113c:	72 65                	jb     0x11a3
    113e:	73 73                	jae    0x11b3
    1140:	1a 02                	sbb    al,BYTE PTR [bp+si]
    1142:	26 20 c0             	es and al,al
    1145:	00 ff                	add    bh,bh
    1147:	ff c0                	inc    ax
    1149:	00 ff                	add    bh,bh
    114b:	ff 01                	inc    WORD PTR [bx+di]
    114d:	00 00                	add    BYTE PTR [bx+si],al
    114f:	00 00                	add    BYTE PTR [bx+si],al
    1151:	80 00 00             	add    BYTE PTR [bx+si],0x0
    1154:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
    1158:	07                   	pop    es
    1159:	4f                   	dec    di
    115a:	6e                   	outs   dx,BYTE PTR ds:[si]
    115b:	4b                   	dec    bx
    115c:	65 79 55             	gs jns 0x11b4
    115f:	70 55                	jo     0x11b6
    1161:	89 e5                	mov    bp,sp
    1163:	b8 00 15             	mov    ax,0x1500
    1166:	31 db                	xor    bx,bx
    1168:	cd 2f                	int    0x2f
    116a:	09 db                	or     bx,bx
    116c:	74 0a                	je     0x1178
    116e:	b8 0b 15             	mov    ax,0x150b
    1171:	8b 4e 04             	mov    cx,WORD PTR [bp+0x4]
    1174:	cd 2f                	int    0x2f
    1176:	09 c0                	or     ax,ax
    1178:	c9                   	leave
    1179:	c2 02 00             	ret    0x2
    117c:	c8 02 00 00          	enter  0x2,0x0
    1180:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1184:	1e                   	push   ds
    1185:	8c d3                	mov    bx,ss
    1187:	8e db                	mov    ds,bx
    1189:	81 ec 00 02          	sub    sp,0x200
    118d:	89 e3                	mov    bx,sp
    118f:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    1192:	b9 01 00             	mov    cx,0x1
    1195:	31 d2                	xor    dx,dx
    1197:	cd 25                	int    0x25
    1199:	83 c4 02             	add    sp,0x2
    119c:	72 14                	jb     0x11b2
    119e:	89 e3                	mov    bx,sp
    11a0:	36 80 7f 15 f8       	cmp    BYTE PTR ss:[bx+0x15],0xf8
    11a5:	75 0b                	jne    0x11b2
    11a7:	36 80 7f 10 01       	cmp    BYTE PTR ss:[bx+0x10],0x1
    11ac:	75 04                	jne    0x11b2
    11ae:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    11b2:	81 c4 00 02          	add    sp,0x200
    11b6:	1f                   	pop    ds
    11b7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    11ba:	c9                   	leave
    11bb:	c2 02 00             	ret    0x2
    11be:	c8 02 00 00          	enter  0x2,0x0
    11c2:	ff 76 04             	push   WORD PTR [bp+0x4]
    11c5:	9a ff ff 00 00       	call   0x0:0xffff
    11ca:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    11cd:	80 7e ff 03          	cmp    BYTE PTR [bp-0x1],0x3
    11d1:	74 06                	je     0x11d9
    11d3:	80 7e ff 04          	cmp    BYTE PTR [bp-0x1],0x4
    11d7:	75 34                	jne    0x120d
    11d9:	ff 76 04             	push   WORD PTR [bp+0x4]
    11dc:	e8 81 ff             	call   0x1160
    11df:	08 c0                	or     al,al
    11e1:	74 06                	je     0x11e9
    11e3:	c6 46 ff 05          	mov    BYTE PTR [bp-0x1],0x5
    11e7:	eb 24                	jmp    0x120d
    11e9:	80 7e ff 03          	cmp    BYTE PTR [bp-0x1],0x3
    11ed:	75 1e                	jne    0x120d
    11ef:	9a ff ff 00 00       	call   0x0:0xffff
    11f4:	25 00 40             	and    ax,0x4000
    11f7:	81 e2 00 00          	and    dx,0x0
    11fb:	09 d0                	or     ax,dx
    11fd:	75 0e                	jne    0x120d
    11ff:	ff 76 04             	push   WORD PTR [bp+0x4]
    1202:	e8 77 ff             	call   0x117c
    1205:	08 c0                	or     al,al
    1207:	74 04                	je     0x120d
    1209:	c6 46 ff 06          	mov    BYTE PTR [bp-0x1],0x6
    120d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1210:	c9                   	leave
    1211:	c2 02 00             	ret    0x2
    1214:	01 5c 04             	add    WORD PTR [si+0x4],bx
    1217:	2e 2e 2e 5c          	cs cs cs pop sp
    121b:	c8 04 02 00          	enter  0x204,0x0
    121f:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1222:	06                   	push   es
    1223:	57                   	push   di
    1224:	bf 14 12             	mov    di,0x1214
    1227:	0e                   	push   cs
    1228:	57                   	push   di
    1229:	9a be 18 5b 12       	call   0x125b:0x18be
    122e:	75 0a                	jne    0x123a
    1230:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1233:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1237:	e9 e6 00             	jmp    0x1320
    123a:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    123d:	26 80 7d 01 5c       	cmp    BYTE PTR es:[di+0x1],0x5c
    1242:	75 27                	jne    0x126b
    1244:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1248:	8d be fc fe          	lea    di,[bp-0x104]
    124c:	16                   	push   ss
    124d:	57                   	push   di
    124e:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1251:	06                   	push   es
    1252:	57                   	push   di
    1253:	6a 02                	push   0x2
    1255:	68 ff 00             	push   0xff
    1258:	9a 0b 18 67 12       	call   0x1267:0x180b
    125d:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1260:	06                   	push   es
    1261:	57                   	push   di
    1262:	6a 4f                	push   0x4f
    1264:	9a e7 17 8c 12       	call   0x128c:0x17e7
    1269:	eb 04                	jmp    0x126f
    126b:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    126f:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1272:	26 80 7d 01 2e       	cmp    BYTE PTR es:[di+0x1],0x2e
    1277:	75 21                	jne    0x129a
    1279:	8d be fc fe          	lea    di,[bp-0x104]
    127d:	16                   	push   ss
    127e:	57                   	push   di
    127f:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1282:	06                   	push   es
    1283:	57                   	push   di
    1284:	6a 05                	push   0x5
    1286:	68 ff 00             	push   0xff
    1289:	9a 0b 18 98 12       	call   0x1298:0x180b
    128e:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1291:	06                   	push   es
    1292:	57                   	push   di
    1293:	6a 4f                	push   0x4f
    1295:	9a e7 17 a7 12       	call   0x12a7:0x17e7
    129a:	bf 14 12             	mov    di,0x1214
    129d:	0e                   	push   cs
    129e:	57                   	push   di
    129f:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    12a2:	06                   	push   es
    12a3:	57                   	push   di
    12a4:	9a 78 18 c0 12       	call   0x12c0:0x1878
    12a9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    12ac:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    12b0:	74 3b                	je     0x12ed
    12b2:	8d be fc fd          	lea    di,[bp-0x204]
    12b6:	16                   	push   ss
    12b7:	57                   	push   di
    12b8:	bf 16 12             	mov    di,0x1216
    12bb:	0e                   	push   cs
    12bc:	57                   	push   di
    12bd:	9a cd 17 d8 12       	call   0x12d8:0x17cd
    12c2:	8d be fc fe          	lea    di,[bp-0x104]
    12c6:	16                   	push   ss
    12c7:	57                   	push   di
    12c8:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    12cb:	06                   	push   es
    12cc:	57                   	push   di
    12cd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    12d0:	40                   	inc    ax
    12d1:	50                   	push   ax
    12d2:	68 ff 00             	push   0xff
    12d5:	9a 0b 18 dd 12       	call   0x12dd:0x180b
    12da:	9a 4c 18 e9 12       	call   0x12e9:0x184c
    12df:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    12e2:	06                   	push   es
    12e3:	57                   	push   di
    12e4:	6a 4f                	push   0x4f
    12e6:	9a e7 17 08 13       	call   0x1308:0x17e7
    12eb:	eb 07                	jmp    0x12f4
    12ed:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    12f0:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    12f4:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    12f8:	74 26                	je     0x1320
    12fa:	8d be fc fe          	lea    di,[bp-0x104]
    12fe:	16                   	push   ss
    12ff:	57                   	push   di
    1300:	bf 14 12             	mov    di,0x1214
    1303:	0e                   	push   cs
    1304:	57                   	push   di
    1305:	9a cd 17 12 13       	call   0x1312:0x17cd
    130a:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    130d:	06                   	push   es
    130e:	57                   	push   di
    130f:	9a 4c 18 1e 13       	call   0x131e:0x184c
    1314:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1317:	06                   	push   es
    1318:	57                   	push   di
    1319:	6a 4f                	push   0x4f
    131b:	9a e7 17 44 13       	call   0x1344:0x17e7
    1320:	c9                   	leave
    1321:	c2 04 00             	ret    0x4
    1324:	01 2e 05 5c          	add    WORD PTR ds:0x5c05,bp
    1328:	2e 2e 2e 5c          	cs cs cs pop sp
    132c:	04 2e                	add    al,0x2e
    132e:	2e 2e 5c             	cs cs pop sp
    1331:	c8 f6 01 00          	enter  0x1f6,0x0
    1335:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1338:	06                   	push   es
    1339:	57                   	push   di
    133a:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    133d:	06                   	push   es
    133e:	57                   	push   di
    133f:	6a 4f                	push   0x4f
    1341:	9a e7 17 60 13       	call   0x1360:0x17e7
    1346:	8d be 0a fe          	lea    di,[bp-0x1f6]
    134a:	16                   	push   ss
    134b:	57                   	push   di
    134c:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    134f:	06                   	push   es
    1350:	57                   	push   di
    1351:	9a 6e 0b 70 13       	call   0x1370:0xb6e
    1356:	8d 7e ac             	lea    di,[bp-0x54]
    1359:	16                   	push   ss
    135a:	57                   	push   di
    135b:	6a 4f                	push   0x4f
    135d:	9a e7 17 7d 13       	call   0x137d:0x17e7
    1362:	8d be 0a fe          	lea    di,[bp-0x1f6]
    1366:	16                   	push   ss
    1367:	57                   	push   di
    1368:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    136b:	06                   	push   es
    136c:	57                   	push   di
    136d:	9a c1 0b b1 13       	call   0x13b1:0xbc1
    1372:	8d be 5c ff          	lea    di,[bp-0xa4]
    1376:	16                   	push   ss
    1377:	57                   	push   di
    1378:	6a 4f                	push   0x4f
    137a:	9a e7 17 8d 13       	call   0x138d:0x17e7
    137f:	bf 24 13             	mov    di,0x1324
    1382:	0e                   	push   cs
    1383:	57                   	push   di
    1384:	8d be 5c ff          	lea    di,[bp-0xa4]
    1388:	16                   	push   ss
    1389:	57                   	push   di
    138a:	9a 78 18 be 13       	call   0x13be:0x1878
    138f:	89 86 0a ff          	mov    WORD PTR [bp-0xf6],ax
    1393:	83 be 0a ff 00       	cmp    WORD PTR [bp-0xf6],0x0
    1398:	7e 09                	jle    0x13a3
    139a:	8b 86 0a ff          	mov    ax,WORD PTR [bp-0xf6]
    139e:	48                   	dec    ax
    139f:	88 86 5c ff          	mov    BYTE PTR [bp-0xa4],al
    13a3:	8d be 0a fe          	lea    di,[bp-0x1f6]
    13a7:	16                   	push   ss
    13a8:	57                   	push   di
    13a9:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    13ac:	06                   	push   es
    13ad:	57                   	push   di
    13ae:	9a 17 0c 06 15       	call   0x1506:0xc17
    13b3:	8d be 0c ff          	lea    di,[bp-0xf4]
    13b7:	16                   	push   ss
    13b8:	57                   	push   di
    13b9:	6a 4f                	push   0x4f
    13bb:	9a e7 17 d8 13       	call   0x13d8:0x17e7
    13c0:	80 7e ae 3a          	cmp    BYTE PTR [bp-0x52],0x3a
    13c4:	75 43                	jne    0x1409
    13c6:	8d be 0a fe          	lea    di,[bp-0x1f6]
    13ca:	16                   	push   ss
    13cb:	57                   	push   di
    13cc:	8d 7e ac             	lea    di,[bp-0x54]
    13cf:	16                   	push   ss
    13d0:	57                   	push   di
    13d1:	6a 01                	push   0x1
    13d3:	6a 02                	push   0x2
    13d5:	9a 0b 18 e4 13       	call   0x13e4:0x180b
    13da:	8d 7e fc             	lea    di,[bp-0x4]
    13dd:	16                   	push   ss
    13de:	57                   	push   di
    13df:	6a 03                	push   0x3
    13e1:	9a e7 17 f9 13       	call   0x13f9:0x17e7
    13e6:	8d be 0a fe          	lea    di,[bp-0x1f6]
    13ea:	16                   	push   ss
    13eb:	57                   	push   di
    13ec:	8d 7e ac             	lea    di,[bp-0x54]
    13ef:	16                   	push   ss
    13f0:	57                   	push   di
    13f1:	6a 03                	push   0x3
    13f3:	68 ff 00             	push   0xff
    13f6:	9a 0b 18 05 14       	call   0x1405:0x180b
    13fb:	8d 7e ac             	lea    di,[bp-0x54]
    13fe:	16                   	push   ss
    13ff:	57                   	push   di
    1400:	6a 4f                	push   0x4f
    1402:	9a e7 17 3d 14       	call   0x143d:0x17e7
    1407:	eb 04                	jmp    0x140d
    1409:	c6 46 fc 00          	mov    BYTE PTR [bp-0x4],0x0
    140d:	80 7e ac 00          	cmp    BYTE PTR [bp-0x54],0x0
    1411:	75 09                	jne    0x141c
    1413:	80 7e fc 00          	cmp    BYTE PTR [bp-0x4],0x0
    1417:	75 03                	jne    0x141c
    1419:	e9 8f 00             	jmp    0x14ab
    141c:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    141f:	06                   	push   es
    1420:	57                   	push   di
    1421:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1424:	06                   	push   es
    1425:	57                   	push   di
    1426:	9a 03 20 ed 19       	call   0x19ed:0x2003
    142b:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    142e:	7e 7b                	jle    0x14ab
    1430:	8d 7e ac             	lea    di,[bp-0x54]
    1433:	16                   	push   ss
    1434:	57                   	push   di
    1435:	bf 26 13             	mov    di,0x1326
    1438:	0e                   	push   cs
    1439:	57                   	push   di
    143a:	9a be 18 54 14       	call   0x1454:0x18be
    143f:	75 17                	jne    0x1458
    1441:	c6 46 fc 00          	mov    BYTE PTR [bp-0x4],0x0
    1445:	bf 2c 13             	mov    di,0x132c
    1448:	0e                   	push   cs
    1449:	57                   	push   di
    144a:	8d 7e ac             	lea    di,[bp-0x54]
    144d:	16                   	push   ss
    144e:	57                   	push   di
    144f:	6a 4f                	push   0x4f
    1451:	9a e7 17 7a 14       	call   0x147a:0x17e7
    1456:	eb 14                	jmp    0x146c
    1458:	80 7e ac 00          	cmp    BYTE PTR [bp-0x54],0x0
    145c:	75 06                	jne    0x1464
    145e:	c6 46 fc 00          	mov    BYTE PTR [bp-0x4],0x0
    1462:	eb 08                	jmp    0x146c
    1464:	8d 7e ac             	lea    di,[bp-0x54]
    1467:	16                   	push   ss
    1468:	57                   	push   di
    1469:	e8 af fd             	call   0x121b
    146c:	8d be 0a fe          	lea    di,[bp-0x1f6]
    1470:	16                   	push   ss
    1471:	57                   	push   di
    1472:	8d 7e fc             	lea    di,[bp-0x4]
    1475:	16                   	push   ss
    1476:	57                   	push   di
    1477:	9a cd 17 84 14       	call   0x1484:0x17cd
    147c:	8d 7e ac             	lea    di,[bp-0x54]
    147f:	16                   	push   ss
    1480:	57                   	push   di
    1481:	9a 4c 18 8f 14       	call   0x148f:0x184c
    1486:	8d be 5c ff          	lea    di,[bp-0xa4]
    148a:	16                   	push   ss
    148b:	57                   	push   di
    148c:	9a 4c 18 9a 14       	call   0x149a:0x184c
    1491:	8d be 0c ff          	lea    di,[bp-0xf4]
    1495:	16                   	push   ss
    1496:	57                   	push   di
    1497:	9a 4c 18 a6 14       	call   0x14a6:0x184c
    149c:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    149f:	06                   	push   es
    14a0:	57                   	push   di
    14a1:	6a 4f                	push   0x4f
    14a3:	9a e7 17 ef 14       	call   0x14ef:0x17e7
    14a8:	e9 62 ff             	jmp    0x140d
    14ab:	c9                   	leave
    14ac:	ca 0a 00             	retf   0xa
    14af:	06                   	push   es
    14b0:	63 3a                	arpl   WORD PTR [bp+si],di
    14b2:	5c                   	pop    sp
    14b3:	2a 2e 2a 01          	sub    ch,BYTE PTR ds:0x12a
    14b7:	2e 03 3a             	add    di,WORD PTR cs:[bp+si]
    14ba:	20 5b 01             	and    BYTE PTR [bp+di+0x1],bl
    14bd:	5d                   	pop    bp
    14be:	00 00                	add    BYTE PTR [bx+si],al
    14c0:	f4                   	hlt
    14c1:	15 e9 16             	adc    ax,0x16e9
    14c4:	c8 38 02 00          	enter  0x238,0x0
    14c8:	6a 01                	push   0x1
    14ca:	9a f8 15 00 00       	call   0x0:0x15f8
    14cf:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    14d2:	b8 be 14             	mov    ax,0x14be
    14d5:	0e                   	push   cs
    14d6:	50                   	push   ax
    14d7:	55                   	push   bp
    14d8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    14dc:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    14e0:	bf af 14             	mov    di,0x14af
    14e3:	0e                   	push   cs
    14e4:	57                   	push   di
    14e5:	8d 7e f8             	lea    di,[bp-0x8]
    14e8:	16                   	push   ss
    14e9:	57                   	push   di
    14ea:	6a 07                	push   0x7
    14ec:	9a e7 17 1f 15       	call   0x151f:0x17e7
    14f1:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
    14f4:	88 46 f9             	mov    BYTE PTR [bp-0x7],al
    14f7:	8d 7e f8             	lea    di,[bp-0x8]
    14fa:	16                   	push   ss
    14fb:	57                   	push   di
    14fc:	6a 08                	push   0x8
    14fe:	8d 7e cc             	lea    di,[bp-0x34]
    1501:	16                   	push   ss
    1502:	57                   	push   di
    1503:	9a 85 0a 6f 15       	call   0x156f:0xa85
    1508:	09 c0                	or     ax,ax
    150a:	74 03                	je     0x150f
    150c:	e9 be 00             	jmp    0x15cd
    150f:	8d 7e ea             	lea    di,[bp-0x16]
    1512:	16                   	push   ss
    1513:	57                   	push   di
    1514:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1517:	06                   	push   es
    1518:	57                   	push   di
    1519:	68 ff 00             	push   0xff
    151c:	9a e7 17 2e 15       	call   0x152e:0x17e7
    1521:	bf b6 14             	mov    di,0x14b6
    1524:	0e                   	push   cs
    1525:	57                   	push   di
    1526:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1529:	06                   	push   es
    152a:	57                   	push   di
    152b:	9a 78 18 49 15       	call   0x1549:0x1878
    1530:	88 46 cb             	mov    BYTE PTR [bp-0x35],al
    1533:	80 7e cb 00          	cmp    BYTE PTR [bp-0x35],0x0
    1537:	74 12                	je     0x154b
    1539:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    153c:	06                   	push   es
    153d:	57                   	push   di
    153e:	8a 46 cb             	mov    al,BYTE PTR [bp-0x35]
    1541:	30 e4                	xor    ah,ah
    1543:	50                   	push   ax
    1544:	6a 01                	push   0x1
    1546:	9a 75 19 5f 15       	call   0x155f:0x1975
    154b:	80 7e 04 61          	cmp    BYTE PTR [bp+0x4],0x61
    154f:	73 3e                	jae    0x158f
    1551:	8d be c8 fd          	lea    di,[bp-0x238]
    1555:	16                   	push   ss
    1556:	57                   	push   di
    1557:	bf b8 14             	mov    di,0x14b8
    155a:	0e                   	push   cs
    155b:	57                   	push   di
    155c:	9a cd 17 74 15       	call   0x1574:0x17cd
    1561:	8d be c8 fe          	lea    di,[bp-0x138]
    1565:	16                   	push   ss
    1566:	57                   	push   di
    1567:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    156a:	06                   	push   es
    156b:	57                   	push   di
    156c:	9a 81 07 ad 15       	call   0x15ad:0x781
    1571:	9a 4c 18 7e 15       	call   0x157e:0x184c
    1576:	bf bc 14             	mov    di,0x14bc
    1579:	0e                   	push   cs
    157a:	57                   	push   di
    157b:	9a 4c 18 8b 15       	call   0x158b:0x184c
    1580:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1583:	06                   	push   es
    1584:	57                   	push   di
    1585:	68 ff 00             	push   0xff
    1588:	9a e7 17 9d 15       	call   0x159d:0x17e7
    158d:	eb 3c                	jmp    0x15cb
    158f:	8d be c8 fd          	lea    di,[bp-0x238]
    1593:	16                   	push   ss
    1594:	57                   	push   di
    1595:	bf b8 14             	mov    di,0x14b8
    1598:	0e                   	push   cs
    1599:	57                   	push   di
    159a:	9a cd 17 b2 15       	call   0x15b2:0x17cd
    159f:	8d be c8 fe          	lea    di,[bp-0x138]
    15a3:	16                   	push   ss
    15a4:	57                   	push   di
    15a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15a8:	06                   	push   es
    15a9:	57                   	push   di
    15aa:	9a b7 07 d9 15       	call   0x15d9:0x7b7
    15af:	9a 4c 18 bc 15       	call   0x15bc:0x184c
    15b4:	bf bc 14             	mov    di,0x14bc
    15b7:	0e                   	push   cs
    15b8:	57                   	push   di
    15b9:	9a 4c 18 c9 15       	call   0x15c9:0x184c
    15be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15c1:	06                   	push   es
    15c2:	57                   	push   di
    15c3:	68 ff 00             	push   0xff
    15c6:	9a e7 17 e6 15       	call   0x15e6:0x17e7
    15cb:	eb 1b                	jmp    0x15e8
    15cd:	8d be c8 fe          	lea    di,[bp-0x138]
    15d1:	16                   	push   ss
    15d2:	57                   	push   di
    15d3:	68 9c f0             	push   0xf09c
    15d6:	9a 2b 09 5a 16       	call   0x165a:0x92b
    15db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15de:	06                   	push   es
    15df:	57                   	push   di
    15e0:	68 ff 00             	push   0xff
    15e3:	9a e7 17 43 16       	call   0x1643:0x17e7
    15e8:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    15ec:	83 c4 06             	add    sp,0x6
    15ef:	b8 fd 15             	mov    ax,0x15fd
    15f2:	0e                   	push   cs
    15f3:	50                   	push   ax
    15f4:	ff 76 c8             	push   WORD PTR [bp-0x38]
    15f7:	9a ff ff 00 00       	call   0x0:0xffff
    15fc:	cb                   	retf
    15fd:	c9                   	leave
    15fe:	c2 02 00             	ret    0x2
    1601:	02 3a                	add    bh,BYTE PTR [bp+si]
    1603:	20 c8                	and    al,cl
    1605:	84 03                	test   BYTE PTR [bp+di],al
    1607:	00 8a 46 04          	add    BYTE PTR [bp+si+0x446],cl
    160b:	a2 70 09             	mov    ds:0x970,al
    160e:	c7 46 fe 80 00       	mov    WORD PTR [bp-0x2],0x80
    1613:	bf 70 09             	mov    di,0x970
    1616:	1e                   	push   ds
    1617:	57                   	push   di
    1618:	8d be 7c ff          	lea    di,[bp-0x84]
    161c:	16                   	push   ss
    161d:	57                   	push   di
    161e:	8d 7e fe             	lea    di,[bp-0x2]
    1621:	16                   	push   ss
    1622:	57                   	push   di
    1623:	9a ff ff 00 00       	call   0x0:0xffff
    1628:	09 c0                	or     ax,ax
    162a:	74 03                	je     0x162f
    162c:	e9 86 00             	jmp    0x16b5
    162f:	80 7e 04 61          	cmp    BYTE PTR [bp+0x4],0x61
    1633:	73 40                	jae    0x1675
    1635:	8d be 7c fc          	lea    di,[bp-0x384]
    1639:	16                   	push   ss
    163a:	57                   	push   di
    163b:	bf 01 16             	mov    di,0x1601
    163e:	0e                   	push   cs
    163f:	57                   	push   di
    1640:	9a cd 17 64 16       	call   0x1664:0x17cd
    1645:	8d be 7c fd          	lea    di,[bp-0x284]
    1649:	16                   	push   ss
    164a:	57                   	push   di
    164b:	8d be 7c fe          	lea    di,[bp-0x184]
    164f:	16                   	push   ss
    1650:	57                   	push   di
    1651:	8d be 7c ff          	lea    di,[bp-0x84]
    1655:	16                   	push   ss
    1656:	57                   	push   di
    1657:	9a 6e 0e 5f 16       	call   0x165f:0xe6e
    165c:	9a 81 07 9a 16       	call   0x169a:0x781
    1661:	9a 4c 18 71 16       	call   0x1671:0x184c
    1666:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1669:	06                   	push   es
    166a:	57                   	push   di
    166b:	68 ff 00             	push   0xff
    166e:	9a e7 17 83 16       	call   0x1683:0x17e7
    1673:	eb 3e                	jmp    0x16b3
    1675:	8d be 7c fc          	lea    di,[bp-0x384]
    1679:	16                   	push   ss
    167a:	57                   	push   di
    167b:	bf 01 16             	mov    di,0x1601
    167e:	0e                   	push   cs
    167f:	57                   	push   di
    1680:	9a cd 17 a4 16       	call   0x16a4:0x17cd
    1685:	8d be 7c fd          	lea    di,[bp-0x284]
    1689:	16                   	push   ss
    168a:	57                   	push   di
    168b:	8d be 7c fe          	lea    di,[bp-0x184]
    168f:	16                   	push   ss
    1690:	57                   	push   di
    1691:	8d be 7c ff          	lea    di,[bp-0x84]
    1695:	16                   	push   ss
    1696:	57                   	push   di
    1697:	9a 6e 0e 9f 16       	call   0x169f:0xe6e
    169c:	9a b7 07 f9 17       	call   0x17f9:0x7b7
    16a1:	9a 4c 18 b1 16       	call   0x16b1:0x184c
    16a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16a9:	06                   	push   es
    16aa:	57                   	push   di
    16ab:	68 ff 00             	push   0xff
    16ae:	9a e7 17 cd 16       	call   0x16cd:0x17e7
    16b3:	eb 1a                	jmp    0x16cf
    16b5:	8d be 7c fe          	lea    di,[bp-0x184]
    16b9:	16                   	push   ss
    16ba:	57                   	push   di
    16bb:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
    16be:	50                   	push   ax
    16bf:	e8 02 fe             	call   0x14c4
    16c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16c5:	06                   	push   es
    16c6:	57                   	push   di
    16c7:	68 ff 00             	push   0xff
    16ca:	9a e7 17 fd 16       	call   0x16fd:0x17e7
    16cf:	c9                   	leave
    16d0:	c2 02 00             	ret    0x2
    16d3:	01 3a                	add    WORD PTR [bp+si],di
    16d5:	01 5c 01             	add    WORD PTR [si+0x1],bx
    16d8:	2a 01                	sub    al,BYTE PTR [bx+di]
    16da:	3f                   	aas
    16db:	03 5c 25             	add    bx,WORD PTR [si+0x25]
    16de:	73 05                	jae    0x16e5
    16e0:	25 73 5c             	and    ax,0x5c73
    16e3:	25 73 00             	and    ax,0x73
    16e6:	00 bf 19 60          	add    BYTE PTR [bx+0x6019],bh
    16ea:	1a c8                	sbb    cl,al
    16ec:	12 02                	adc    al,BYTE PTR [bp+si]
    16ee:	00 6a 00             	add    BYTE PTR [bp+si+0x0],ch
    16f1:	8d be 00 ff          	lea    di,[bp-0x100]
    16f5:	16                   	push   ss
    16f6:	57                   	push   di
    16f7:	68 ff 00             	push   0xff
    16fa:	9a 58 0e 21 17       	call   0x1721:0xe58
    16ff:	8a 86 01 ff          	mov    al,BYTE PTR [bp-0xff]
    1703:	88 86 ff fe          	mov    BYTE PTR [bp-0x101],al
    1707:	8a 86 ff fe          	mov    al,BYTE PTR [bp-0x101]
    170b:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    170e:	26 88 05             	mov    BYTE PTR es:[di],al
    1711:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    1714:	06                   	push   es
    1715:	57                   	push   di
    1716:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1719:	06                   	push   es
    171a:	57                   	push   di
    171b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    171e:	9a e7 17 52 17       	call   0x1752:0x17e7
    1723:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1726:	26 80 7d 01 5b       	cmp    BYTE PTR es:[di+0x1],0x5b
    172b:	75 36                	jne    0x1763
    172d:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1730:	30 e4                	xor    ah,ah
    1732:	03 f8                	add    di,ax
    1734:	26 80 3d 5d          	cmp    BYTE PTR es:[di],0x5d
    1738:	75 29                	jne    0x1763
    173a:	8d be fe fd          	lea    di,[bp-0x202]
    173e:	16                   	push   ss
    173f:	57                   	push   di
    1740:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1743:	06                   	push   es
    1744:	57                   	push   di
    1745:	6a 02                	push   0x2
    1747:	26 8a 05             	mov    al,BYTE PTR es:[di]
    174a:	30 e4                	xor    ah,ah
    174c:	48                   	dec    ax
    174d:	48                   	dec    ax
    174e:	50                   	push   ax
    174f:	9a 0b 18 5f 17       	call   0x175f:0x180b
    1754:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1757:	06                   	push   es
    1758:	57                   	push   di
    1759:	ff 76 0c             	push   WORD PTR [bp+0xc]
    175c:	9a e7 17 70 17       	call   0x1770:0x17e7
    1761:	eb 48                	jmp    0x17ab
    1763:	bf d3 16             	mov    di,0x16d3
    1766:	0e                   	push   cs
    1767:	57                   	push   di
    1768:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    176b:	06                   	push   es
    176c:	57                   	push   di
    176d:	9a 78 18 9c 17       	call   0x179c:0x1878
    1772:	3d 02 00             	cmp    ax,0x2
    1775:	75 34                	jne    0x17ab
    1777:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    177a:	26 8a 45 01          	mov    al,BYTE PTR es:[di+0x1]
    177e:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1781:	26 88 05             	mov    BYTE PTR es:[di],al
    1784:	8d be fe fd          	lea    di,[bp-0x202]
    1788:	16                   	push   ss
    1789:	57                   	push   di
    178a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    178d:	06                   	push   es
    178e:	57                   	push   di
    178f:	6a 03                	push   0x3
    1791:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1794:	30 e4                	xor    ah,ah
    1796:	48                   	dec    ax
    1797:	48                   	dec    ax
    1798:	50                   	push   ax
    1799:	9a 0b 18 a9 17       	call   0x17a9:0x180b
    179e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    17a1:	06                   	push   es
    17a2:	57                   	push   di
    17a3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    17a6:	9a e7 17 d5 17       	call   0x17d5:0x17e7
    17ab:	b8 e5 16             	mov    ax,0x16e5
    17ae:	0e                   	push   cs
    17af:	50                   	push   ax
    17b0:	55                   	push   bp
    17b1:	ff 36 58 18          	push   WORD PTR ds:0x1858
    17b5:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    17b9:	8a 86 ff fe          	mov    al,BYTE PTR [bp-0x101]
    17bd:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    17c0:	26 3a 05             	cmp    al,BYTE PTR es:[di]
    17c3:	74 26                	je     0x17eb
    17c5:	8d be fe fd          	lea    di,[bp-0x202]
    17c9:	16                   	push   ss
    17ca:	57                   	push   di
    17cb:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    17ce:	26 8a 05             	mov    al,BYTE PTR es:[di]
    17d1:	50                   	push   ax
    17d2:	9a e9 18 df 17       	call   0x17df:0x18e9
    17d7:	bf d3 16             	mov    di,0x16d3
    17da:	0e                   	push   cs
    17db:	57                   	push   di
    17dc:	9a 4c 18 e4 17       	call   0x17e4:0x184c
    17e1:	9a b2 0e e9 17       	call   0x17e9:0xeb2
    17e6:	9a 08 04 06 18       	call   0x1806:0x408
    17eb:	8d be fe fd          	lea    di,[bp-0x202]
    17ef:	16                   	push   ss
    17f0:	57                   	push   di
    17f1:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    17f4:	06                   	push   es
    17f5:	57                   	push   di
    17f6:	9a c1 0b 03 19       	call   0x1903:0xbc1
    17fb:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    17fe:	06                   	push   es
    17ff:	57                   	push   di
    1800:	ff 76 06             	push   WORD PTR [bp+0x6]
    1803:	9a e7 17 2f 18       	call   0x182f:0x17e7
    1808:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    180b:	26 8a 05             	mov    al,BYTE PTR es:[di]
    180e:	30 e4                	xor    ah,ah
    1810:	40                   	inc    ax
    1811:	8b d0                	mov    dx,ax
    1813:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1816:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1819:	30 e4                	xor    ah,ah
    181b:	3b c2                	cmp    ax,dx
    181d:	75 14                	jne    0x1833
    181f:	bf d5 16             	mov    di,0x16d5
    1822:	0e                   	push   cs
    1823:	57                   	push   di
    1824:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1827:	06                   	push   es
    1828:	57                   	push   di
    1829:	ff 76 0c             	push   WORD PTR [bp+0xc]
    182c:	9a e7 17 67 18       	call   0x1867:0x17e7
    1831:	eb 7b                	jmp    0x18ae
    1833:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1836:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1839:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    183c:	26 3a 05             	cmp    al,BYTE PTR es:[di]
    183f:	76 37                	jbe    0x1878
    1841:	8d be fe fd          	lea    di,[bp-0x202]
    1845:	16                   	push   ss
    1846:	57                   	push   di
    1847:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    184a:	06                   	push   es
    184b:	57                   	push   di
    184c:	6a 01                	push   0x1
    184e:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1851:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1854:	30 e4                	xor    ah,ah
    1856:	8b d0                	mov    dx,ax
    1858:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    185b:	26 8a 05             	mov    al,BYTE PTR es:[di]
    185e:	30 e4                	xor    ah,ah
    1860:	2b c2                	sub    ax,dx
    1862:	48                   	dec    ax
    1863:	50                   	push   ax
    1864:	9a 0b 18 74 18       	call   0x1874:0x180b
    1869:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    186c:	06                   	push   es
    186d:	57                   	push   di
    186e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1871:	9a e7 17 85 18       	call   0x1885:0x17e7
    1876:	eb 36                	jmp    0x18ae
    1878:	6a 00                	push   0x0
    187a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    187d:	06                   	push   es
    187e:	57                   	push   di
    187f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1882:	9a 58 0e 9f 18       	call   0x189f:0xe58
    1887:	8d be fe fd          	lea    di,[bp-0x202]
    188b:	16                   	push   ss
    188c:	57                   	push   di
    188d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1890:	06                   	push   es
    1891:	57                   	push   di
    1892:	6a 03                	push   0x3
    1894:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1897:	30 e4                	xor    ah,ah
    1899:	48                   	dec    ax
    189a:	48                   	dec    ax
    189b:	50                   	push   ax
    189c:	9a 0b 18 ac 18       	call   0x18ac:0x180b
    18a1:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    18a4:	06                   	push   es
    18a5:	57                   	push   di
    18a6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    18a9:	9a e7 17 bc 18       	call   0x18bc:0x17e7
    18ae:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    18b1:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    18b5:	76 0c                	jbe    0x18c3
    18b7:	06                   	push   es
    18b8:	57                   	push   di
    18b9:	9a b2 0e c1 18       	call   0x18c1:0xeb2
    18be:	9a 08 04 dc 18       	call   0x18dc:0x408
    18c3:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    18c6:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    18ca:	77 03                	ja     0x18cf
    18cc:	e9 e4 00             	jmp    0x19b3
    18cf:	bf d7 16             	mov    di,0x16d7
    18d2:	0e                   	push   cs
    18d3:	57                   	push   di
    18d4:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    18d7:	06                   	push   es
    18d8:	57                   	push   di
    18d9:	9a 78 18 f2 18       	call   0x18f2:0x1878
    18de:	09 c0                	or     ax,ax
    18e0:	7e 03                	jle    0x18e5
    18e2:	e9 ce 00             	jmp    0x19b3
    18e5:	bf d9 16             	mov    di,0x16d9
    18e8:	0e                   	push   cs
    18e9:	57                   	push   di
    18ea:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    18ed:	06                   	push   es
    18ee:	57                   	push   di
    18ef:	9a 78 18 14 19       	call   0x1914:0x1878
    18f4:	09 c0                	or     ax,ax
    18f6:	7e 03                	jle    0x18fb
    18f8:	e9 b8 00             	jmp    0x19b3
    18fb:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    18fe:	06                   	push   es
    18ff:	57                   	push   di
    1900:	9a 26 0a 4e 19       	call   0x194e:0xa26
    1905:	08 c0                	or     al,al
    1907:	74 03                	je     0x190c
    1909:	e9 a7 00             	jmp    0x19b3
    190c:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    190f:	06                   	push   es
    1910:	57                   	push   di
    1911:	9a b2 0e 19 19       	call   0x1919:0xeb2
    1916:	9a 08 04 5b 19       	call   0x195b:0x408
    191b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    191e:	26 80 3d 01          	cmp    BYTE PTR es:[di],0x1
    1922:	75 3b                	jne    0x195f
    1924:	8d be f6 fd          	lea    di,[bp-0x20a]
    1928:	16                   	push   ss
    1929:	57                   	push   di
    192a:	bf db 16             	mov    di,0x16db
    192d:	0e                   	push   cs
    192e:	57                   	push   di
    192f:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1932:	89 f8                	mov    ax,di
    1934:	8c c2                	mov    dx,es
    1936:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    193a:	89 96 f8 fe          	mov    WORD PTR [bp-0x108],dx
    193e:	c6 86 fa fe 04       	mov    BYTE PTR [bp-0x106],0x4
    1943:	8d be f6 fe          	lea    di,[bp-0x10a]
    1947:	16                   	push   ss
    1948:	57                   	push   di
    1949:	6a 00                	push   0x0
    194b:	9a 34 10 9d 19       	call   0x199d:0x1034
    1950:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1953:	06                   	push   es
    1954:	57                   	push   di
    1955:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1958:	9a e7 17 aa 19       	call   0x19aa:0x17e7
    195d:	eb 4d                	jmp    0x19ac
    195f:	8d be ee fd          	lea    di,[bp-0x212]
    1963:	16                   	push   ss
    1964:	57                   	push   di
    1965:	bf df 16             	mov    di,0x16df
    1968:	0e                   	push   cs
    1969:	57                   	push   di
    196a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    196d:	89 f8                	mov    ax,di
    196f:	8c c2                	mov    dx,es
    1971:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    1975:	89 96 f0 fe          	mov    WORD PTR [bp-0x110],dx
    1979:	c6 86 f2 fe 04       	mov    BYTE PTR [bp-0x10e],0x4
    197e:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1981:	89 f8                	mov    ax,di
    1983:	8c c2                	mov    dx,es
    1985:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    1989:	89 96 f8 fe          	mov    WORD PTR [bp-0x108],dx
    198d:	c6 86 fa fe 04       	mov    BYTE PTR [bp-0x106],0x4
    1992:	8d be ee fe          	lea    di,[bp-0x112]
    1996:	16                   	push   ss
    1997:	57                   	push   di
    1998:	6a 01                	push   0x1
    199a:	9a 34 10 d9 1f       	call   0x1fd9:0x1034
    199f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    19a2:	06                   	push   es
    19a3:	57                   	push   di
    19a4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    19a7:	9a e7 17 c8 19       	call   0x19c8:0x17e7
    19ac:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    19af:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    19b3:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    19b7:	83 c4 06             	add    sp,0x6
    19ba:	b8 d0 19             	mov    ax,0x19d0
    19bd:	0e                   	push   cs
    19be:	50                   	push   ax
    19bf:	8d be 00 ff          	lea    di,[bp-0x100]
    19c3:	16                   	push   ss
    19c4:	57                   	push   di
    19c5:	9a b2 0e cd 19       	call   0x19cd:0xeb2
    19ca:	9a 08 04 37 1a       	call   0x1a37:0x408
    19cf:	cb                   	retf
    19d0:	c9                   	leave
    19d1:	ca 14 00             	retf   0x14
    19d4:	c8 2a 00 00          	enter  0x2a,0x0
    19d8:	6a 00                	push   0x0
    19da:	9a ff ff 00 00       	call   0x0:0xffff
    19df:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    19e2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19e5:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    19e8:	06                   	push   es
    19e9:	57                   	push   di
    19ea:	9a 16 10 d2 1e       	call   0x1ed2:0x1016
    19ef:	50                   	push   ax
    19f0:	9a 0c 1a 00 00       	call   0x0:0x1a0c
    19f5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    19f8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19fb:	8d 7e d6             	lea    di,[bp-0x2a]
    19fe:	16                   	push   ss
    19ff:	57                   	push   di
    1a00:	9a ff ff 00 00       	call   0x0:0xffff
    1a05:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1a08:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1a0b:	9a ff ff 00 00       	call   0x0:0xffff
    1a10:	6a 00                	push   0x0
    1a12:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1a15:	9a ff ff 00 00       	call   0x0:0xffff
    1a1a:	8b 46 d6             	mov    ax,WORD PTR [bp-0x2a]
    1a1d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a20:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1a23:	c9                   	leave
    1a24:	c2 04 00             	ret    0x4
    1a27:	c8 50 00 00          	enter  0x50,0x0
    1a2b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1a2f:	74 08                	je     0x1a39
    1a31:	83 ec 08             	sub    sp,0x8
    1a34:	9a e2 1f 6e 1a       	call   0x1a6e:0x1fe2
    1a39:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1a3c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1a3f:	31 c0                	xor    ax,ax
    1a41:	50                   	push   ax
    1a42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a45:	06                   	push   es
    1a46:	57                   	push   di
    1a47:	9a 20 5a 56 1a       	call   0x1a56:0x5a20
    1a4c:	6a 03                	push   0x3
    1a4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a51:	06                   	push   es
    1a52:	57                   	push   di
    1a53:	9a b3 5c f2 1a       	call   0x1af2:0x5cb3
    1a58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a5b:	06                   	push   es
    1a5c:	57                   	push   di
    1a5d:	9a e9 20 80 1a       	call   0x1a80:0x20e9
    1a62:	6a 00                	push   0x0
    1a64:	8d 7e b0             	lea    di,[bp-0x50]
    1a67:	16                   	push   ss
    1a68:	57                   	push   di
    1a69:	6a 4f                	push   0x4f
    1a6b:	9a 58 0e a9 1a       	call   0x1aa9:0xe58
    1a70:	8a 46 b1             	mov    al,BYTE PTR [bp-0x4f]
    1a73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a76:	26 88 85 26 01       	mov    BYTE PTR es:[di+0x126],al
    1a7b:	06                   	push   es
    1a7c:	57                   	push   di
    1a7d:	9a 99 20 41 1b       	call   0x1b41:0x2099
    1a82:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1a86:	74 07                	je     0x1a8f
    1a88:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1a8c:	83 c4 06             	add    sp,0x6
    1a8f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1a92:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1a95:	c9                   	leave
    1a96:	ca 0a 00             	retf   0xa
    1a99:	55                   	push   bp
    1a9a:	89 e5                	mov    bp,sp
    1a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a9f:	26 c4 bd 28 01       	les    di,DWORD PTR es:[di+0x128]
    1aa4:	06                   	push   es
    1aa5:	57                   	push   di
    1aa6:	9a 7f 1f b8 1a       	call   0x1ab8:0x1f7f
    1aab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aae:	26 c4 bd 2c 01       	les    di,DWORD PTR es:[di+0x12c]
    1ab3:	06                   	push   es
    1ab4:	57                   	push   di
    1ab5:	9a 7f 1f c7 1a       	call   0x1ac7:0x1f7f
    1aba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1abd:	26 c4 bd 30 01       	les    di,DWORD PTR es:[di+0x130]
    1ac2:	06                   	push   es
    1ac3:	57                   	push   di
    1ac4:	9a 7f 1f d6 1a       	call   0x1ad6:0x1f7f
    1ac9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1acc:	26 c4 bd 34 01       	les    di,DWORD PTR es:[di+0x134]
    1ad1:	06                   	push   es
    1ad2:	57                   	push   di
    1ad3:	9a 7f 1f e5 1a       	call   0x1ae5:0x1f7f
    1ad8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1adb:	26 c4 bd 38 01       	les    di,DWORD PTR es:[di+0x138]
    1ae0:	06                   	push   es
    1ae1:	57                   	push   di
    1ae2:	9a 7f 1f fd 1a       	call   0x1afd:0x1f7f
    1ae7:	31 c0                	xor    ax,ax
    1ae9:	50                   	push   ax
    1aea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aed:	06                   	push   es
    1aee:	57                   	push   di
    1aef:	9a 36 5b 1b 1b       	call   0x1b1b:0x5b36
    1af4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1af8:	74 05                	je     0x1aff
    1afa:	9a 0f 20 4e 1b       	call   0x1b4e:0x200f
    1aff:	c9                   	leave
    1b00:	ca 06 00             	retf   0x6
    1b03:	01 3a                	add    WORD PTR [bp+si],di
    1b05:	69 1b a0 1b          	imul   bx,WORD PTR [bp+di],0x1ba0
    1b09:	df 1b                	fistp  WORD PTR [bp+di]
    1b0b:	1d 1c 5b             	sbb    ax,0x5b1c
    1b0e:	1c c8                	sbb    al,0xc8
    1b10:	04 02                	add    al,0x2
    1b12:	00 c4                	add    ah,al
    1b14:	7e 06                	jle    0x1b1c
    1b16:	06                   	push   es
    1b17:	57                   	push   di
    1b18:	9a c0 5b b0 1c       	call   0x1cb0:0x5bc0
    1b1d:	31 c0                	xor    ax,ax
    1b1f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b22:	eb 03                	jmp    0x1b27
    1b24:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1b27:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b2a:	e8 91 f6             	call   0x11be
    1b2d:	88 46 fc             	mov    BYTE PTR [bp-0x4],al
    1b30:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b33:	05 61 00             	add    ax,0x61
    1b36:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    1b39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b3c:	06                   	push   es
    1b3d:	57                   	push   di
    1b3e:	9a ca 1d de 1c       	call   0x1cde:0x1dca
    1b43:	3c 01                	cmp    al,0x1
    1b45:	75 0c                	jne    0x1b53
    1b47:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1b4a:	50                   	push   ax
    1b4b:	9a f9 1e 76 1b       	call   0x1b76:0x1ef9
    1b50:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    1b53:	8a 46 fc             	mov    al,BYTE PTR [bp-0x4]
    1b56:	2c 02                	sub    al,0x2
    1b58:	3c 04                	cmp    al,0x4
    1b5a:	76 03                	jbe    0x1b5f
    1b5c:	e9 38 01             	jmp    0x1c97
    1b5f:	98                   	cbw
    1b60:	89 c3                	mov    bx,ax
    1b62:	d1 e3                	shl    bx,1
    1b64:	2e ff a7 05 1b       	jmp    WORD PTR cs:[bx+0x1b05]
    1b69:	8d be fc fe          	lea    di,[bp-0x104]
    1b6d:	16                   	push   ss
    1b6e:	57                   	push   di
    1b6f:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1b72:	50                   	push   ax
    1b73:	9a e9 18 80 1b       	call   0x1b80:0x18e9
    1b78:	bf 03 1b             	mov    di,0x1b03
    1b7b:	0e                   	push   cs
    1b7c:	57                   	push   di
    1b7d:	9a 4c 18 ad 1b       	call   0x1bad:0x184c
    1b82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b85:	26 ff b5 2a 01       	push   WORD PTR es:[di+0x12a]
    1b8a:	26 ff b5 28 01       	push   WORD PTR es:[di+0x128]
    1b8f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1b94:	06                   	push   es
    1b95:	57                   	push   di
    1b96:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b99:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    1b9d:	e9 f7 00             	jmp    0x1c97
    1ba0:	8d be fc fd          	lea    di,[bp-0x204]
    1ba4:	16                   	push   ss
    1ba5:	57                   	push   di
    1ba6:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1ba9:	50                   	push   ax
    1baa:	9a e9 18 bf 1b       	call   0x1bbf:0x18e9
    1baf:	8d be fc fe          	lea    di,[bp-0x104]
    1bb3:	16                   	push   ss
    1bb4:	57                   	push   di
    1bb5:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1bb8:	50                   	push   ax
    1bb9:	e8 48 fa             	call   0x1604
    1bbc:	9a 4c 18 ec 1b       	call   0x1bec:0x184c
    1bc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bc4:	26 ff b5 2e 01       	push   WORD PTR es:[di+0x12e]
    1bc9:	26 ff b5 2c 01       	push   WORD PTR es:[di+0x12c]
    1bce:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1bd3:	06                   	push   es
    1bd4:	57                   	push   di
    1bd5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bd8:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    1bdc:	e9 b8 00             	jmp    0x1c97
    1bdf:	8d be fc fd          	lea    di,[bp-0x204]
    1be3:	16                   	push   ss
    1be4:	57                   	push   di
    1be5:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1be8:	50                   	push   ax
    1be9:	9a e9 18 fe 1b       	call   0x1bfe:0x18e9
    1bee:	8d be fc fe          	lea    di,[bp-0x104]
    1bf2:	16                   	push   ss
    1bf3:	57                   	push   di
    1bf4:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1bf7:	50                   	push   ax
    1bf8:	e8 09 fa             	call   0x1604
    1bfb:	9a 4c 18 2a 1c       	call   0x1c2a:0x184c
    1c00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c03:	26 ff b5 32 01       	push   WORD PTR es:[di+0x132]
    1c08:	26 ff b5 30 01       	push   WORD PTR es:[di+0x130]
    1c0d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1c12:	06                   	push   es
    1c13:	57                   	push   di
    1c14:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c17:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    1c1b:	eb 7a                	jmp    0x1c97
    1c1d:	8d be fc fd          	lea    di,[bp-0x204]
    1c21:	16                   	push   ss
    1c22:	57                   	push   di
    1c23:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1c26:	50                   	push   ax
    1c27:	9a e9 18 3c 1c       	call   0x1c3c:0x18e9
    1c2c:	8d be fc fe          	lea    di,[bp-0x104]
    1c30:	16                   	push   ss
    1c31:	57                   	push   di
    1c32:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1c35:	50                   	push   ax
    1c36:	e8 cb f9             	call   0x1604
    1c39:	9a 4c 18 68 1c       	call   0x1c68:0x184c
    1c3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c41:	26 ff b5 36 01       	push   WORD PTR es:[di+0x136]
    1c46:	26 ff b5 34 01       	push   WORD PTR es:[di+0x134]
    1c4b:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1c50:	06                   	push   es
    1c51:	57                   	push   di
    1c52:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c55:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    1c59:	eb 3c                	jmp    0x1c97
    1c5b:	8d be fc fd          	lea    di,[bp-0x204]
    1c5f:	16                   	push   ss
    1c60:	57                   	push   di
    1c61:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1c64:	50                   	push   ax
    1c65:	9a e9 18 7a 1c       	call   0x1c7a:0x18e9
    1c6a:	8d be fc fe          	lea    di,[bp-0x104]
    1c6e:	16                   	push   ss
    1c6f:	57                   	push   di
    1c70:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1c73:	50                   	push   ax
    1c74:	e8 4d f8             	call   0x14c4
    1c77:	9a 4c 18 c2 1c       	call   0x1cc2:0x184c
    1c7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c7f:	26 ff b5 3a 01       	push   WORD PTR es:[di+0x13a]
    1c84:	26 ff b5 38 01       	push   WORD PTR es:[di+0x138]
    1c89:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1c8e:	06                   	push   es
    1c8f:	57                   	push   di
    1c90:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c93:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    1c97:	83 7e fe 19          	cmp    WORD PTR [bp-0x2],0x19
    1c9b:	74 03                	je     0x1ca0
    1c9d:	e9 84 fe             	jmp    0x1b24
    1ca0:	c9                   	leave
    1ca1:	ca 04 00             	retf   0x4
    1ca4:	c8 04 02 00          	enter  0x204,0x0
    1ca8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cab:	06                   	push   es
    1cac:	57                   	push   di
    1cad:	9a 07 5c 8b 1d       	call   0x1d8b:0x5c07
    1cb2:	09 c0                	or     ax,ax
    1cb4:	7c 20                	jl     0x1cd6
    1cb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cb9:	26 8a 85 26 01       	mov    al,BYTE PTR es:[di+0x126]
    1cbe:	50                   	push   ax
    1cbf:	9a f9 1e cc 1c       	call   0x1ccc:0x1ef9
    1cc4:	50                   	push   ax
    1cc5:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1cc8:	50                   	push   ax
    1cc9:	9a f9 1e eb 1c       	call   0x1ceb:0x1ef9
    1cce:	5a                   	pop    dx
    1ccf:	3a c2                	cmp    al,dl
    1cd1:	75 03                	jne    0x1cd6
    1cd3:	e9 f0 00             	jmp    0x1dc6
    1cd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cd9:	06                   	push   es
    1cda:	57                   	push   di
    1cdb:	9a ca 1d b7 1d       	call   0x1db7:0x1dca
    1ce0:	3c 01                	cmp    al,0x1
    1ce2:	75 13                	jne    0x1cf7
    1ce4:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1ce7:	50                   	push   ax
    1ce8:	9a f9 1e fe 1c       	call   0x1cfe:0x1ef9
    1ced:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf0:	26 88 85 26 01       	mov    BYTE PTR es:[di+0x126],al
    1cf5:	eb 16                	jmp    0x1d0d
    1cf7:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1cfa:	50                   	push   ax
    1cfb:	9a f9 1e 59 1d       	call   0x1d59:0x1ef9
    1d00:	30 e4                	xor    ah,ah
    1d02:	05 20 00             	add    ax,0x20
    1d05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d08:	26 88 85 26 01       	mov    BYTE PTR es:[di+0x126],al
    1d0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d10:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1d15:	06                   	push   es
    1d16:	57                   	push   di
    1d17:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d1a:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1d1e:	48                   	dec    ax
    1d1f:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    1d23:	31 c0                	xor    ax,ax
    1d25:	3b 86 fc fe          	cmp    ax,WORD PTR [bp-0x104]
    1d29:	7f 6d                	jg     0x1d98
    1d2b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d2e:	eb 03                	jmp    0x1d33
    1d30:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1d33:	8d be fc fd          	lea    di,[bp-0x204]
    1d37:	16                   	push   ss
    1d38:	57                   	push   di
    1d39:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1d3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d3f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1d44:	06                   	push   es
    1d45:	57                   	push   di
    1d46:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d49:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1d4d:	8d be fe fe          	lea    di,[bp-0x102]
    1d51:	16                   	push   ss
    1d52:	57                   	push   di
    1d53:	68 ff 00             	push   0xff
    1d56:	9a e7 17 67 1d       	call   0x1d67:0x17e7
    1d5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d5e:	26 8a 85 26 01       	mov    al,BYTE PTR es:[di+0x126]
    1d63:	50                   	push   ax
    1d64:	9a f9 1e 72 1d       	call   0x1d72:0x1ef9
    1d69:	50                   	push   ax
    1d6a:	8a 86 ff fe          	mov    al,BYTE PTR [bp-0x101]
    1d6e:	50                   	push   ax
    1d6f:	9a f9 1e c4 1d       	call   0x1dc4:0x1ef9
    1d74:	5a                   	pop    dx
    1d75:	3a c2                	cmp    al,dl
    1d77:	75 16                	jne    0x1d8f
    1d79:	80 be 00 ff 3a       	cmp    BYTE PTR [bp-0x100],0x3a
    1d7e:	75 0f                	jne    0x1d8f
    1d80:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1d83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d86:	06                   	push   es
    1d87:	57                   	push   di
    1d88:	9a 2e 5c 79 1e       	call   0x1e79:0x5c2e
    1d8d:	eb 09                	jmp    0x1d98
    1d8f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d92:	3b 86 fc fe          	cmp    ax,WORD PTR [bp-0x104]
    1d96:	75 98                	jne    0x1d30
    1d98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d9b:	26 8b 85 22 01       	mov    ax,WORD PTR es:[di+0x122]
    1da0:	26 0b 85 24 01       	or     ax,WORD PTR es:[di+0x124]
    1da5:	74 12                	je     0x1db9
    1da7:	26 8a 85 26 01       	mov    al,BYTE PTR es:[di+0x126]
    1dac:	50                   	push   ax
    1dad:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    1db2:	06                   	push   es
    1db3:	57                   	push   di
    1db4:	9a 0d 25 0d 1e       	call   0x1e0d:0x250d
    1db9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dbc:	06                   	push   es
    1dbd:	57                   	push   di
    1dbe:	b8 ec ff             	mov    ax,0xffec
    1dc1:	9a 6a 20 f1 22       	call   0x22f1:0x206a
    1dc6:	c9                   	leave
    1dc7:	ca 06 00             	retf   0x6
    1dca:	c8 02 00 00          	enter  0x2,0x0
    1dce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dd1:	26 8a 85 27 01       	mov    al,BYTE PTR es:[di+0x127]
    1dd6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1dd9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1ddc:	c9                   	leave
    1ddd:	ca 04 00             	retf   0x4
    1de0:	c8 02 00 00          	enter  0x2,0x0
    1de4:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1de7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dea:	26 88 85 27 01       	mov    BYTE PTR es:[di+0x127],al
    1def:	26 8a 85 26 01       	mov    al,BYTE PTR es:[di+0x126]
    1df4:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1df7:	06                   	push   es
    1df8:	57                   	push   di
    1df9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1dfc:	26 ff 9d 88 00       	call   DWORD PTR es:[di+0x88]
    1e01:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1e04:	50                   	push   ax
    1e05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e08:	06                   	push   es
    1e09:	57                   	push   di
    1e0a:	9a a4 1c 96 1e       	call   0x1e96:0x1ca4
    1e0f:	c9                   	leave
    1e10:	ca 06 00             	retf   0x6
    1e13:	55                   	push   bp
    1e14:	89 e5                	mov    bp,sp
    1e16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e19:	26 8b 85 22 01       	mov    ax,WORD PTR es:[di+0x122]
    1e1e:	26 0b 85 24 01       	or     ax,WORD PTR es:[di+0x124]
    1e23:	74 11                	je     0x1e36
    1e25:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    1e2a:	31 c0                	xor    ax,ax
    1e2c:	26 89 85 06 01       	mov    WORD PTR es:[di+0x106],ax
    1e31:	26 89 85 08 01       	mov    WORD PTR es:[di+0x108],ax
    1e36:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1e39:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    1e3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e3f:	26 89 85 22 01       	mov    WORD PTR es:[di+0x122],ax
    1e44:	26 89 95 24 01       	mov    WORD PTR es:[di+0x124],dx
    1e49:	26 8b 85 22 01       	mov    ax,WORD PTR es:[di+0x122]
    1e4e:	26 0b 85 24 01       	or     ax,WORD PTR es:[di+0x124]
    1e53:	74 15                	je     0x1e6a
    1e55:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1e58:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1e5b:	26 c4 bd 22 01       	les    di,DWORD PTR es:[di+0x122]
    1e60:	26 89 85 06 01       	mov    WORD PTR es:[di+0x106],ax
    1e65:	26 89 95 08 01       	mov    WORD PTR es:[di+0x108],dx
    1e6a:	c9                   	leave
    1e6b:	ca 08 00             	retf   0x8
    1e6e:	55                   	push   bp
    1e6f:	89 e5                	mov    bp,sp
    1e71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e74:	06                   	push   es
    1e75:	57                   	push   di
    1e76:	9a f4 5d 30 20       	call   0x2030:0x5df4
    1e7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e7e:	06                   	push   es
    1e7f:	57                   	push   di
    1e80:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e83:	26 ff 9d 88 00       	call   DWORD PTR es:[di+0x88]
    1e88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e8b:	26 8a 85 26 01       	mov    al,BYTE PTR es:[di+0x126]
    1e90:	50                   	push   ax
    1e91:	06                   	push   es
    1e92:	57                   	push   di
    1e93:	9a a4 1c 68 20       	call   0x2068:0x1ca4
    1e98:	c9                   	leave
    1e99:	ca 04 00             	retf   0x4
    1e9c:	c8 12 02 00          	enter  0x212,0x0
    1ea0:	8c d3                	mov    bx,ss
    1ea2:	8e c3                	mov    es,bx
    1ea4:	8c db                	mov    bx,ds
    1ea6:	fc                   	cld
    1ea7:	8d 7e f8             	lea    di,[bp-0x8]
    1eaa:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    1ead:	b9 08 00             	mov    cx,0x8
    1eb0:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1eb2:	8e db                	mov    ds,bx
    1eb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb7:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    1ebc:	89 be ee fe          	mov    WORD PTR [bp-0x112],di
    1ec0:	8c 86 f0 fe          	mov    WORD PTR [bp-0x110],es
    1ec4:	8d 7e f8             	lea    di,[bp-0x8]
    1ec7:	16                   	push   ss
    1ec8:	57                   	push   di
    1ec9:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    1ecd:	06                   	push   es
    1ece:	57                   	push   di
    1ecf:	9a e5 1c 9c 1f       	call   0x1f9c:0x1ce5
    1ed4:	c7 46 f2 10 00       	mov    WORD PTR [bp-0xe],0x10
    1ed9:	ff 76 10             	push   WORD PTR [bp+0x10]
    1edc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1edf:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1ee4:	06                   	push   es
    1ee5:	57                   	push   di
    1ee6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ee9:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    1eed:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1ef0:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    1ef3:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1ef6:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    1ef9:	75 03                	jne    0x1efe
    1efb:	e9 b8 00             	jmp    0x1fb6
    1efe:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f01:	06                   	push   es
    1f02:	57                   	push   di
    1f03:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f06:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    1f0a:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1f0d:	8d be e6 fe          	lea    di,[bp-0x11a]
    1f11:	16                   	push   ss
    1f12:	57                   	push   di
    1f13:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1f16:	40                   	inc    ax
    1f17:	40                   	inc    ax
    1f18:	50                   	push   ax
    1f19:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f1c:	06                   	push   es
    1f1d:	57                   	push   di
    1f1e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f21:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1f25:	8b d0                	mov    dx,ax
    1f27:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1f2a:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    1f2d:	2b c2                	sub    ax,dx
    1f2f:	99                   	cwd
    1f30:	b9 02 00             	mov    cx,0x2
    1f33:	f7 f9                	idiv   cx
    1f35:	50                   	push   ax
    1f36:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f39:	06                   	push   es
    1f3a:	57                   	push   di
    1f3b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f3e:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    1f42:	50                   	push   ax
    1f43:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f46:	06                   	push   es
    1f47:	57                   	push   di
    1f48:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f4b:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1f4f:	50                   	push   ax
    1f50:	9a ae 06 82 1f       	call   0x1f82:0x6ae
    1f55:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1f58:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1f5b:	8d be de fe          	lea    di,[bp-0x122]
    1f5f:	16                   	push   ss
    1f60:	57                   	push   di
    1f61:	6a 00                	push   0x0
    1f63:	6a 00                	push   0x0
    1f65:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f68:	06                   	push   es
    1f69:	57                   	push   di
    1f6a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f6d:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    1f71:	50                   	push   ax
    1f72:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f75:	06                   	push   es
    1f76:	57                   	push   di
    1f77:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f7a:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1f7e:	50                   	push   ax
    1f7f:	9a ae 06 29 27       	call   0x2729:0x6ae
    1f84:	6a 00                	push   0x0
    1f86:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f89:	06                   	push   es
    1f8a:	57                   	push   di
    1f8b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f8e:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1f92:	48                   	dec    ax
    1f93:	50                   	push   ax
    1f94:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1f97:	06                   	push   es
    1f98:	57                   	push   di
    1f99:	9a 0f 5a a7 1f       	call   0x1fa7:0x5a0f
    1f9e:	89 c7                	mov    di,ax
    1fa0:	8e c2                	mov    es,dx
    1fa2:	06                   	push   es
    1fa3:	57                   	push   di
    1fa4:	9a 32 21 b4 1f       	call   0x1fb4:0x2132
    1fa9:	52                   	push   dx
    1faa:	50                   	push   ax
    1fab:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    1faf:	06                   	push   es
    1fb0:	57                   	push   di
    1fb1:	9a 23 19 f4 1f       	call   0x1ff4:0x1923
    1fb6:	8d be f2 fe          	lea    di,[bp-0x10e]
    1fba:	16                   	push   ss
    1fbb:	57                   	push   di
    1fbc:	8d be ee fd          	lea    di,[bp-0x212]
    1fc0:	16                   	push   ss
    1fc1:	57                   	push   di
    1fc2:	ff 76 10             	push   WORD PTR [bp+0x10]
    1fc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fc8:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1fcd:	06                   	push   es
    1fce:	57                   	push   di
    1fcf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1fd2:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1fd6:	9a 4c 0d 06 20       	call   0x2006:0xd4c
    1fdb:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1fde:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    1fe1:	05 06 00             	add    ax,0x6
    1fe4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1fe7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fea:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    1fef:	06                   	push   es
    1ff0:	57                   	push   di
    1ff1:	9a d2 21 f3 20       	call   0x20f3:0x21d2
    1ff6:	50                   	push   ax
    1ff7:	8d be f2 fe          	lea    di,[bp-0x10e]
    1ffb:	16                   	push   ss
    1ffc:	57                   	push   di
    1ffd:	8d be f2 fe          	lea    di,[bp-0x10e]
    2001:	16                   	push   ss
    2002:	57                   	push   di
    2003:	9a 8c 0c 51 23       	call   0x2351:0xc8c
    2008:	50                   	push   ax
    2009:	8d 7e f8             	lea    di,[bp-0x8]
    200c:	16                   	push   ss
    200d:	57                   	push   di
    200e:	68 24 08             	push   0x824
    2011:	9a ff ff 00 00       	call   0x0:0xffff
    2016:	c9                   	leave
    2017:	ca 0c 00             	retf   0xc
    201a:	c8 00 01 00          	enter  0x100,0x0
    201e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2021:	06                   	push   es
    2022:	57                   	push   di
    2023:	9a 73 27 7f 20       	call   0x207f:0x2773
    2028:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    202b:	06                   	push   es
    202c:	57                   	push   di
    202d:	9a 07 5c 44 20       	call   0x2044:0x5c07
    2032:	09 c0                	or     ax,ax
    2034:	7c 34                	jl     0x206a
    2036:	8d be 00 ff          	lea    di,[bp-0x100]
    203a:	16                   	push   ss
    203b:	57                   	push   di
    203c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    203f:	06                   	push   es
    2040:	57                   	push   di
    2041:	9a 07 5c e3 20       	call   0x20e3:0x5c07
    2046:	50                   	push   ax
    2047:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    204a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    204f:	06                   	push   es
    2050:	57                   	push   di
    2051:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2054:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    2058:	83 c4 04             	add    sp,0x4
    205b:	8a 86 01 ff          	mov    al,BYTE PTR [bp-0xff]
    205f:	50                   	push   ax
    2060:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2063:	06                   	push   es
    2064:	57                   	push   di
    2065:	9a a4 1c 89 20       	call   0x2089:0x1ca4
    206a:	c9                   	leave
    206b:	ca 04 00             	retf   0x4
    206e:	55                   	push   bp
    206f:	89 e5                	mov    bp,sp
    2071:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2074:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2077:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    207a:	06                   	push   es
    207b:	57                   	push   di
    207c:	9a 3a 57 93 20       	call   0x2093:0x573a
    2081:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2084:	06                   	push   es
    2085:	57                   	push   di
    2086:	9a 99 20 8b 24       	call   0x248b:0x2099
    208b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    208e:	06                   	push   es
    208f:	57                   	push   di
    2090:	9a 5a 40 2c 22       	call   0x222c:0x405a
    2095:	c9                   	leave
    2096:	ca 08 00             	retf   0x8
    2099:	c8 02 00 00          	enter  0x2,0x0
    209d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a0:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    20a4:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    20a8:	e8 29 f9             	call   0x19d4
    20ab:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    20ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20b1:	26 c4 bd 28 01       	les    di,DWORD PTR es:[di+0x128]
    20b6:	06                   	push   es
    20b7:	57                   	push   di
    20b8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20bb:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    20bf:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    20c2:	7e 14                	jle    0x20d8
    20c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20c7:	26 c4 bd 28 01       	les    di,DWORD PTR es:[di+0x128]
    20cc:	06                   	push   es
    20cd:	57                   	push   di
    20ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20d1:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    20d5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    20d8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20de:	06                   	push   es
    20df:	57                   	push   di
    20e0:	9a 35 5d 49 24       	call   0x2449:0x5d35
    20e5:	c9                   	leave
    20e6:	ca 04 00             	retf   0x4
    20e9:	55                   	push   bp
    20ea:	89 e5                	mov    bp,sp
    20ec:	b0 01                	mov    al,0x1
    20ee:	50                   	push   ax
    20ef:	b8 3f 08             	mov    ax,0x83f
    20f2:	ba fa 20             	mov    dx,0x20fa
    20f5:	52                   	push   dx
    20f6:	50                   	push   ax
    20f7:	9a bd 56 25 21       	call   0x2125:0x56bd
    20fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20ff:	26 89 85 28 01       	mov    WORD PTR es:[di+0x128],ax
    2104:	26 89 95 2a 01       	mov    WORD PTR es:[di+0x12a],dx
    2109:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    210d:	bf 74 09             	mov    di,0x974
    2110:	1e                   	push   ds
    2111:	57                   	push   di
    2112:	9a 4e 21 00 00       	call   0x0:0x214e
    2117:	50                   	push   ax
    2118:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    211b:	26 c4 bd 28 01       	les    di,DWORD PTR es:[di+0x128]
    2120:	06                   	push   es
    2121:	57                   	push   di
    2122:	9a 04 61 2e 21       	call   0x212e:0x6104
    2127:	b0 01                	mov    al,0x1
    2129:	50                   	push   ax
    212a:	b8 3f 08             	mov    ax,0x83f
    212d:	ba 35 21             	mov    dx,0x2135
    2130:	52                   	push   dx
    2131:	50                   	push   ax
    2132:	9a bd 56 60 21       	call   0x2160:0x56bd
    2137:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    213a:	26 89 85 2c 01       	mov    WORD PTR es:[di+0x12c],ax
    213f:	26 89 95 2e 01       	mov    WORD PTR es:[di+0x12e],dx
    2144:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    2148:	bf 7b 09             	mov    di,0x97b
    214b:	1e                   	push   ds
    214c:	57                   	push   di
    214d:	9a 89 21 00 00       	call   0x0:0x2189
    2152:	50                   	push   ax
    2153:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2156:	26 c4 bd 2c 01       	les    di,DWORD PTR es:[di+0x12c]
    215b:	06                   	push   es
    215c:	57                   	push   di
    215d:	9a 04 61 69 21       	call   0x2169:0x6104
    2162:	b0 01                	mov    al,0x1
    2164:	50                   	push   ax
    2165:	b8 3f 08             	mov    ax,0x83f
    2168:	ba 70 21             	mov    dx,0x2170
    216b:	52                   	push   dx
    216c:	50                   	push   ax
    216d:	9a bd 56 9b 21       	call   0x219b:0x56bd
    2172:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2175:	26 89 85 30 01       	mov    WORD PTR es:[di+0x130],ax
    217a:	26 89 95 32 01       	mov    WORD PTR es:[di+0x132],dx
    217f:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    2183:	bf 80 09             	mov    di,0x980
    2186:	1e                   	push   ds
    2187:	57                   	push   di
    2188:	9a c4 21 00 00       	call   0x0:0x21c4
    218d:	50                   	push   ax
    218e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2191:	26 c4 bd 30 01       	les    di,DWORD PTR es:[di+0x130]
    2196:	06                   	push   es
    2197:	57                   	push   di
    2198:	9a 04 61 a4 21       	call   0x21a4:0x6104
    219d:	b0 01                	mov    al,0x1
    219f:	50                   	push   ax
    21a0:	b8 3f 08             	mov    ax,0x83f
    21a3:	ba ab 21             	mov    dx,0x21ab
    21a6:	52                   	push   dx
    21a7:	50                   	push   ax
    21a8:	9a bd 56 d6 21       	call   0x21d6:0x56bd
    21ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b0:	26 89 85 34 01       	mov    WORD PTR es:[di+0x134],ax
    21b5:	26 89 95 36 01       	mov    WORD PTR es:[di+0x136],dx
    21ba:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    21be:	bf 88 09             	mov    di,0x988
    21c1:	1e                   	push   ds
    21c2:	57                   	push   di
    21c3:	9a ff 21 00 00       	call   0x0:0x21ff
    21c8:	50                   	push   ax
    21c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21cc:	26 c4 bd 34 01       	les    di,DWORD PTR es:[di+0x134]
    21d1:	06                   	push   es
    21d2:	57                   	push   di
    21d3:	9a 04 61 df 21       	call   0x21df:0x6104
    21d8:	b0 01                	mov    al,0x1
    21da:	50                   	push   ax
    21db:	b8 3f 08             	mov    ax,0x83f
    21de:	ba e6 21             	mov    dx,0x21e6
    21e1:	52                   	push   dx
    21e2:	50                   	push   ax
    21e3:	9a bd 56 11 22       	call   0x2211:0x56bd
    21e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21eb:	26 89 85 38 01       	mov    WORD PTR es:[di+0x138],ax
    21f0:	26 89 95 3a 01       	mov    WORD PTR es:[di+0x13a],dx
    21f5:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    21f9:	bf 8e 09             	mov    di,0x98e
    21fc:	1e                   	push   ds
    21fd:	57                   	push   di
    21fe:	9a fe 29 00 00       	call   0x0:0x29fe
    2203:	50                   	push   ax
    2204:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2207:	26 c4 bd 38 01       	les    di,DWORD PTR es:[di+0x138]
    220c:	06                   	push   es
    220d:	57                   	push   di
    220e:	9a 04 61 f1 23       	call   0x23f1:0x6104
    2213:	c9                   	leave
    2214:	ca 04 00             	retf   0x4
    2217:	55                   	push   bp
    2218:	89 e5                	mov    bp,sp
    221a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    221d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2220:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2223:	50                   	push   ax
    2224:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2227:	06                   	push   es
    2228:	57                   	push   di
    2229:	9a 32 16 56 24       	call   0x2456:0x1632
    222e:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    2232:	75 23                	jne    0x2257
    2234:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2237:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    223a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    223d:	26 3b 95 24 01       	cmp    dx,WORD PTR es:[di+0x124]
    2242:	75 13                	jne    0x2257
    2244:	26 3b 85 22 01       	cmp    ax,WORD PTR es:[di+0x122]
    2249:	75 0c                	jne    0x2257
    224b:	31 c0                	xor    ax,ax
    224d:	26 89 85 22 01       	mov    WORD PTR es:[di+0x122],ax
    2252:	26 89 85 24 01       	mov    WORD PTR es:[di+0x124],ax
    2257:	c9                   	leave
    2258:	ca 0a 00             	retf   0xa
    225b:	55                   	push   bp
    225c:	89 e5                	mov    bp,sp
    225e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2261:	26 8b 85 3e 01       	mov    ax,WORD PTR es:[di+0x13e]
    2266:	09 c0                	or     ax,ax
    2268:	74 15                	je     0x227f
    226a:	ff 76 08             	push   WORD PTR [bp+0x8]
    226d:	ff 76 06             	push   WORD PTR [bp+0x6]
    2270:	26 ff b5 42 01       	push   WORD PTR es:[di+0x142]
    2275:	26 ff b5 40 01       	push   WORD PTR es:[di+0x140]
    227a:	26 ff 9d 3c 01       	call   DWORD PTR es:[di+0x13c]
    227f:	c9                   	leave
    2280:	ca 04 00             	retf   0x4
    2283:	c8 06 00 00          	enter  0x6,0x0
    2287:	31 c0                	xor    ax,ax
    2289:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    228c:	31 c0                	xor    ax,ax
    228e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2291:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2294:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2297:	30 e4                	xor    ah,ah
    2299:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    229c:	b8 01 00             	mov    ax,0x1
    229f:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    22a2:	7f 21                	jg     0x22c5
    22a4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    22a7:	eb 03                	jmp    0x22ac
    22a9:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    22ac:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    22af:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    22b2:	03 f8                	add    di,ax
    22b4:	26 80 3d 5c          	cmp    BYTE PTR es:[di],0x5c
    22b8:	75 03                	jne    0x22bd
    22ba:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    22bd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    22c0:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    22c3:	75 e4                	jne    0x22a9
    22c5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    22c8:	c9                   	leave
    22c9:	c2 04 00             	ret    0x4
    22cc:	01 5c 03             	add    WORD PTR [si+0x3],bx
    22cf:	2a 2e 2a 01          	sub    ch,BYTE PTR ds:0x12a
    22d3:	2e 02 2e 2e c8       	add    ch,BYTE PTR cs:0xc82e
    22d8:	30 03                	xor    BYTE PTR [bp+di],al
    22da:	00 31                	add    BYTE PTR [bx+di],dh
    22dc:	c0 89 46 fe c4       	ror    BYTE PTR [bx+di-0x1ba],0xc4
    22e1:	7e 08                	jle    0x22eb
    22e3:	06                   	push   es
    22e4:	57                   	push   di
    22e5:	8d be fc fe          	lea    di,[bp-0x104]
    22e9:	16                   	push   ss
    22ea:	57                   	push   di
    22eb:	68 ff 00             	push   0xff
    22ee:	9a e7 17 11 23       	call   0x2311:0x17e7
    22f3:	8a 86 fc fe          	mov    al,BYTE PTR [bp-0x104]
    22f7:	30 e4                	xor    ah,ah
    22f9:	8b f8                	mov    di,ax
    22fb:	80 bb fc fe 5c       	cmp    BYTE PTR [bp+di-0x104],0x5c
    2300:	74 29                	je     0x232b
    2302:	8d be d0 fc          	lea    di,[bp-0x330]
    2306:	16                   	push   ss
    2307:	57                   	push   di
    2308:	8d be fc fe          	lea    di,[bp-0x104]
    230c:	16                   	push   ss
    230d:	57                   	push   di
    230e:	9a cd 17 1b 23       	call   0x231b:0x17cd
    2313:	bf cc 22             	mov    di,0x22cc
    2316:	0e                   	push   cs
    2317:	57                   	push   di
    2318:	9a 4c 18 29 23       	call   0x2329:0x184c
    231d:	8d be fc fe          	lea    di,[bp-0x104]
    2321:	16                   	push   ss
    2322:	57                   	push   di
    2323:	68 ff 00             	push   0xff
    2326:	9a e7 17 3a 23       	call   0x233a:0x17e7
    232b:	8d be d0 fc          	lea    di,[bp-0x330]
    232f:	16                   	push   ss
    2330:	57                   	push   di
    2331:	8d be fc fe          	lea    di,[bp-0x104]
    2335:	16                   	push   ss
    2336:	57                   	push   di
    2337:	9a cd 17 44 23       	call   0x2344:0x17cd
    233c:	bf ce 22             	mov    di,0x22ce
    233f:	0e                   	push   cs
    2340:	57                   	push   di
    2341:	9a 4c 18 83 23       	call   0x2383:0x184c
    2346:	6a 10                	push   0x10
    2348:	8d be d0 fd          	lea    di,[bp-0x230]
    234c:	16                   	push   ss
    234d:	57                   	push   di
    234e:	9a 85 0a 75 23       	call   0x2375:0xa85
    2353:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2356:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    235a:	75 72                	jne    0x23ce
    235c:	8a 86 e5 fd          	mov    al,BYTE PTR [bp-0x21b]
    2360:	24 10                	and    al,0x10
    2362:	3c 10                	cmp    al,0x10
    2364:	75 58                	jne    0x23be
    2366:	8d be d0 fc          	lea    di,[bp-0x330]
    236a:	16                   	push   ss
    236b:	57                   	push   di
    236c:	8d be ee fd          	lea    di,[bp-0x212]
    2370:	16                   	push   ss
    2371:	57                   	push   di
    2372:	9a b7 07 c7 23       	call   0x23c7:0x7b7
    2377:	8d be fc fd          	lea    di,[bp-0x204]
    237b:	16                   	push   ss
    237c:	57                   	push   di
    237d:	68 ff 00             	push   0xff
    2380:	9a e7 17 93 23       	call   0x2393:0x17e7
    2385:	8d be fc fd          	lea    di,[bp-0x204]
    2389:	16                   	push   ss
    238a:	57                   	push   di
    238b:	bf d2 22             	mov    di,0x22d2
    238e:	0e                   	push   cs
    238f:	57                   	push   di
    2390:	9a be 18 a5 23       	call   0x23a5:0x18be
    2395:	74 27                	je     0x23be
    2397:	8d be fc fd          	lea    di,[bp-0x204]
    239b:	16                   	push   ss
    239c:	57                   	push   di
    239d:	bf d4 22             	mov    di,0x22d4
    23a0:	0e                   	push   cs
    23a1:	57                   	push   di
    23a2:	9a be 18 e4 23       	call   0x23e4:0x18be
    23a7:	74 15                	je     0x23be
    23a9:	8d be fc fd          	lea    di,[bp-0x204]
    23ad:	16                   	push   ss
    23ae:	57                   	push   di
    23af:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    23b2:	06                   	push   es
    23b3:	57                   	push   di
    23b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23b7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    23bb:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    23be:	8d be d0 fd          	lea    di,[bp-0x230]
    23c2:	16                   	push   ss
    23c3:	57                   	push   di
    23c4:	9a c8 0a 37 26       	call   0x2637:0xac8
    23c9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    23cc:	eb 88                	jmp    0x2356
    23ce:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    23d1:	c9                   	leave
    23d2:	c2 08 00             	ret    0x8
    23d5:	55                   	push   bp
    23d6:	89 e5                	mov    bp,sp
    23d8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    23dc:	74 08                	je     0x23e6
    23de:	83 ec 08             	sub    sp,0x8
    23e1:	9a e2 1f 36 24       	call   0x2436:0x1fe2
    23e6:	31 c0                	xor    ax,ax
    23e8:	50                   	push   ax
    23e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23ec:	06                   	push   es
    23ed:	57                   	push   di
    23ee:	9a bd 56 10 2a       	call   0x2a10:0x56bd
    23f3:	6a 10                	push   0x10
    23f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23f8:	06                   	push   es
    23f9:	57                   	push   di
    23fa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23fd:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    2401:	6a 10                	push   0x10
    2403:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2406:	06                   	push   es
    2407:	57                   	push   di
    2408:	26 c4 3d             	les    di,DWORD PTR es:[di]
    240b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    240f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2413:	74 07                	je     0x241c
    2415:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2419:	83 c4 06             	add    sp,0x6
    241c:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    241f:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2422:	c9                   	leave
    2423:	ca 06 00             	retf   0x6
    2426:	c8 00 01 00          	enter  0x100,0x0
    242a:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    242e:	74 08                	je     0x2438
    2430:	83 ec 08             	sub    sp,0x8
    2433:	9a e2 1f 9c 24       	call   0x249c:0x1fe2
    2438:	ff 76 0e             	push   WORD PTR [bp+0xe]
    243b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    243e:	31 c0                	xor    ax,ax
    2440:	50                   	push   ax
    2441:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2444:	06                   	push   es
    2445:	57                   	push   di
    2446:	9a dc 75 62 24       	call   0x2462:0x75dc
    244b:	68 91 00             	push   0x91
    244e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2451:	06                   	push   es
    2452:	57                   	push   di
    2453:	9a bf 17 bc 29       	call   0x29bc:0x17bf
    2458:	6a 01                	push   0x1
    245a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    245d:	06                   	push   es
    245e:	57                   	push   di
    245f:	9a 6f 79 6e 24       	call   0x246e:0x796f
    2464:	6a 00                	push   0x0
    2466:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2469:	06                   	push   es
    246a:	57                   	push   di
    246b:	9a 4c 79 fa 24       	call   0x24fa:0x794c
    2470:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2473:	06                   	push   es
    2474:	57                   	push   di
    2475:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2478:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    247d:	8d be 00 ff          	lea    di,[bp-0x100]
    2481:	16                   	push   ss
    2482:	57                   	push   di
    2483:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2486:	06                   	push   es
    2487:	57                   	push   di
    2488:	9a 16 26 a6 24       	call   0x24a6:0x2616
    248d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2490:	81 c7 1b 01          	add    di,0x11b
    2494:	06                   	push   es
    2495:	57                   	push   di
    2496:	68 ff 00             	push   0xff
    2499:	9a e7 17 cf 24       	call   0x24cf:0x17e7
    249e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24a1:	06                   	push   es
    24a2:	57                   	push   di
    24a3:	9a f9 2e 19 25       	call   0x2519:0x2ef9
    24a8:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    24ac:	74 07                	je     0x24b5
    24ae:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    24b2:	83 c4 06             	add    sp,0x6
    24b5:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    24b8:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    24bb:	c9                   	leave
    24bc:	ca 0a 00             	retf   0xa
    24bf:	55                   	push   bp
    24c0:	89 e5                	mov    bp,sp
    24c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c5:	26 c4 bd 0f 01       	les    di,DWORD PTR es:[di+0x10f]
    24ca:	06                   	push   es
    24cb:	57                   	push   di
    24cc:	9a 7f 1f de 24       	call   0x24de:0x1f7f
    24d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24d4:	26 c4 bd 13 01       	les    di,DWORD PTR es:[di+0x113]
    24d9:	06                   	push   es
    24da:	57                   	push   di
    24db:	9a 7f 1f ed 24       	call   0x24ed:0x1f7f
    24e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24e3:	26 c4 bd 17 01       	les    di,DWORD PTR es:[di+0x117]
    24e8:	06                   	push   es
    24e9:	57                   	push   di
    24ea:	9a 7f 1f 05 25       	call   0x2505:0x1f7f
    24ef:	31 c0                	xor    ax,ax
    24f1:	50                   	push   ax
    24f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24f5:	06                   	push   es
    24f6:	57                   	push   di
    24f7:	9a c5 76 de 26       	call   0x26de:0x76c5
    24fc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2500:	74 05                	je     0x2507
    2502:	9a 0f 20 1f 25       	call   0x251f:0x200f
    2507:	c9                   	leave
    2508:	ca 06 00             	retf   0x6
    250b:	01 3a                	add    WORD PTR [bp+si],di
    250d:	c8 00 01 00          	enter  0x100,0x0
    2511:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2514:	06                   	push   es
    2515:	57                   	push   di
    2516:	9a 4b 2f 61 25       	call   0x2561:0x2f4b
    251b:	50                   	push   ax
    251c:	9a f9 1e 29 25       	call   0x2529:0x1ef9
    2521:	50                   	push   ax
    2522:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2525:	50                   	push   ax
    2526:	9a f9 1e 3d 25       	call   0x253d:0x1ef9
    252b:	5a                   	pop    dx
    252c:	3a c2                	cmp    al,dl
    252e:	74 66                	je     0x2596
    2530:	8d be 00 ff          	lea    di,[bp-0x100]
    2534:	16                   	push   ss
    2535:	57                   	push   di
    2536:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2539:	50                   	push   ax
    253a:	9a e9 18 47 25       	call   0x2547:0x18e9
    253f:	bf 0b 25             	mov    di,0x250b
    2542:	0e                   	push   cs
    2543:	57                   	push   di
    2544:	9a 4c 18 4c 25       	call   0x254c:0x184c
    2549:	9a b2 0e 51 25       	call   0x2551:0xeb2
    254e:	9a 08 04 72 25       	call   0x2572:0x408
    2553:	8d be 00 ff          	lea    di,[bp-0x100]
    2557:	16                   	push   ss
    2558:	57                   	push   di
    2559:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    255c:	06                   	push   es
    255d:	57                   	push   di
    255e:	9a 16 26 10 26       	call   0x2610:0x2616
    2563:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2566:	81 c7 1b 01          	add    di,0x11b
    256a:	06                   	push   es
    256b:	57                   	push   di
    256c:	68 ff 00             	push   0xff
    256f:	9a e7 17 27 26       	call   0x2627:0x17e7
    2574:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2577:	26 80 bd 0e 01 00    	cmp    BYTE PTR es:[di+0x10e],0x0
    257d:	75 17                	jne    0x2596
    257f:	06                   	push   es
    2580:	57                   	push   di
    2581:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2584:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    2589:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    258c:	06                   	push   es
    258d:	57                   	push   di
    258e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2591:	26 ff 9d 88 00       	call   DWORD PTR es:[di+0x88]
    2596:	c9                   	leave
    2597:	ca 06 00             	retf   0x6
    259a:	55                   	push   bp
    259b:	89 e5                	mov    bp,sp
    259d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a0:	26 8b 85 02 01       	mov    ax,WORD PTR es:[di+0x102]
    25a5:	26 0b 85 04 01       	or     ax,WORD PTR es:[di+0x104]
    25aa:	74 11                	je     0x25bd
    25ac:	26 c4 bd 02 01       	les    di,DWORD PTR es:[di+0x102]
    25b1:	31 c0                	xor    ax,ax
    25b3:	26 89 85 0b 02       	mov    WORD PTR es:[di+0x20b],ax
    25b8:	26 89 85 0d 02       	mov    WORD PTR es:[di+0x20d],ax
    25bd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    25c0:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    25c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c6:	26 89 85 02 01       	mov    WORD PTR es:[di+0x102],ax
    25cb:	26 89 95 04 01       	mov    WORD PTR es:[di+0x104],dx
    25d0:	26 8b 85 02 01       	mov    ax,WORD PTR es:[di+0x102]
    25d5:	26 0b 85 04 01       	or     ax,WORD PTR es:[di+0x104]
    25da:	74 15                	je     0x25f1
    25dc:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    25df:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    25e2:	26 c4 bd 02 01       	les    di,DWORD PTR es:[di+0x102]
    25e7:	26 89 85 0b 02       	mov    WORD PTR es:[di+0x20b],ax
    25ec:	26 89 95 0d 02       	mov    WORD PTR es:[di+0x20d],dx
    25f1:	c9                   	leave
    25f2:	ca 08 00             	retf   0x8
    25f5:	55                   	push   bp
    25f6:	89 e5                	mov    bp,sp
    25f8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    25fb:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    25fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2601:	26 89 85 0a 01       	mov    WORD PTR es:[di+0x10a],ax
    2606:	26 89 95 0c 01       	mov    WORD PTR es:[di+0x10c],dx
    260b:	06                   	push   es
    260c:	57                   	push   di
    260d:	9a 4d 31 9b 26       	call   0x269b:0x314d
    2612:	c9                   	leave
    2613:	ca 08 00             	retf   0x8
    2616:	c8 00 01 00          	enter  0x100,0x0
    261a:	6a 00                	push   0x0
    261c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    261f:	06                   	push   es
    2620:	57                   	push   di
    2621:	68 ff 00             	push   0xff
    2624:	9a 58 0e 44 26       	call   0x2644:0xe58
    2629:	8d be 00 ff          	lea    di,[bp-0x100]
    262d:	16                   	push   ss
    262e:	57                   	push   di
    262f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2632:	06                   	push   es
    2633:	57                   	push   di
    2634:	9a b7 07 5b 27       	call   0x275b:0x7b7
    2639:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    263c:	06                   	push   es
    263d:	57                   	push   di
    263e:	68 ff 00             	push   0xff
    2641:	9a e7 17 61 26       	call   0x2661:0x17e7
    2646:	c9                   	leave
    2647:	ca 04 00             	retf   0x4
    264a:	55                   	push   bp
    264b:	89 e5                	mov    bp,sp
    264d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2650:	81 c7 1b 01          	add    di,0x11b
    2654:	06                   	push   es
    2655:	57                   	push   di
    2656:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2659:	06                   	push   es
    265a:	57                   	push   di
    265b:	68 ff 00             	push   0xff
    265e:	9a e7 17 77 26       	call   0x2677:0x17e7
    2663:	c9                   	leave
    2664:	ca 04 00             	retf   0x4
    2667:	c8 00 01 00          	enter  0x100,0x0
    266b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    266e:	81 c7 1b 01          	add    di,0x11b
    2672:	06                   	push   es
    2673:	57                   	push   di
    2674:	9a b2 0e 7c 26       	call   0x267c:0xeb2
    2679:	9a 08 04 86 26       	call   0x2686:0x408
    267e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2681:	06                   	push   es
    2682:	57                   	push   di
    2683:	9a b2 0e 8b 26       	call   0x268b:0xeb2
    2688:	9a 08 04 ac 26       	call   0x26ac:0x408
    268d:	8d be 00 ff          	lea    di,[bp-0x100]
    2691:	16                   	push   ss
    2692:	57                   	push   di
    2693:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2696:	06                   	push   es
    2697:	57                   	push   di
    2698:	9a 16 26 e9 26       	call   0x26e9:0x2616
    269d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26a0:	81 c7 1b 01          	add    di,0x11b
    26a4:	06                   	push   es
    26a5:	57                   	push   di
    26a6:	68 ff 00             	push   0xff
    26a9:	9a e7 17 69 27       	call   0x2769:0x17e7
    26ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b1:	06                   	push   es
    26b2:	57                   	push   di
    26b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26b6:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    26bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26be:	06                   	push   es
    26bf:	57                   	push   di
    26c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26c3:	26 ff 9d 88 00       	call   DWORD PTR es:[di+0x88]
    26c8:	c9                   	leave
    26c9:	ca 08 00             	retf   0x8
    26cc:	c8 00 01 00          	enter  0x100,0x0
    26d0:	8d be 00 ff          	lea    di,[bp-0x100]
    26d4:	16                   	push   ss
    26d5:	57                   	push   di
    26d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26d9:	06                   	push   es
    26da:	57                   	push   di
    26db:	9a bb 77 ce 29       	call   0x29ce:0x77bb
    26e0:	50                   	push   ax
    26e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e4:	06                   	push   es
    26e5:	57                   	push   di
    26e6:	9a 98 2c 02 27       	call   0x2702:0x2c98
    26eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ee:	06                   	push   es
    26ef:	57                   	push   di
    26f0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    26f3:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    26f8:	c9                   	leave
    26f9:	ca 04 00             	retf   0x4
    26fc:	01 5c 00             	add    WORD PTR [si+0x0],bx
    26ff:	00 8c 29 08          	add    BYTE PTR [si+0x829],cl
    2703:	27                   	daa
    2704:	00 00                	add    BYTE PTR [bx+si],al
    2706:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    2707:	29 56 27             	sub    WORD PTR [bp+0x27],dx
    270a:	c8 0e 05 00          	enter  0x50e,0x0
    270e:	b8 04 27             	mov    ax,0x2704
    2711:	0e                   	push   cs
    2712:	50                   	push   ax
    2713:	55                   	push   bp
    2714:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2718:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    271c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    271f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2724:	06                   	push   es
    2725:	57                   	push   di
    2726:	9a c5 13 e7 28       	call   0x28e7:0x13c5
    272b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    272e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2733:	06                   	push   es
    2734:	57                   	push   di
    2735:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2738:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    273c:	31 c0                	xor    ax,ax
    273e:	89 86 fe fc          	mov    WORD PTR [bp-0x302],ax
    2742:	8d be f2 fa          	lea    di,[bp-0x50e]
    2746:	16                   	push   ss
    2747:	57                   	push   di
    2748:	8d be f2 fb          	lea    di,[bp-0x40e]
    274c:	16                   	push   ss
    274d:	57                   	push   di
    274e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2751:	06                   	push   es
    2752:	57                   	push   di
    2753:	9a 4a 26 bd 28       	call   0x28bd:0x264a
    2758:	9a b7 07 8c 27       	call   0x278c:0x7b7
    275d:	8d be 00 ff          	lea    di,[bp-0x100]
    2761:	16                   	push   ss
    2762:	57                   	push   di
    2763:	68 ff 00             	push   0xff
    2766:	9a e7 17 9a 27       	call   0x279a:0x17e7
    276b:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    276f:	30 e4                	xor    ah,ah
    2771:	8b f8                	mov    di,ax
    2773:	80 bb 00 ff 5c       	cmp    BYTE PTR [bp+di-0x100],0x5c
    2778:	75 03                	jne    0x277d
    277a:	e9 f5 00             	jmp    0x2872
    277d:	8d be f2 fb          	lea    di,[bp-0x40e]
    2781:	16                   	push   ss
    2782:	57                   	push   di
    2783:	8d be 00 ff          	lea    di,[bp-0x100]
    2787:	16                   	push   ss
    2788:	57                   	push   di
    2789:	9a c1 0b c2 28       	call   0x28c2:0xbc1
    278e:	8d be 00 fd          	lea    di,[bp-0x300]
    2792:	16                   	push   ss
    2793:	57                   	push   di
    2794:	68 ff 00             	push   0xff
    2797:	9a e7 17 aa 27       	call   0x27aa:0x17e7
    279c:	bf fc 26             	mov    di,0x26fc
    279f:	0e                   	push   cs
    27a0:	57                   	push   di
    27a1:	8d be 00 ff          	lea    di,[bp-0x100]
    27a5:	16                   	push   ss
    27a6:	57                   	push   di
    27a7:	9a 78 18 c1 27       	call   0x27c1:0x1878
    27ac:	09 c0                	or     ax,ax
    27ae:	75 03                	jne    0x27b3
    27b0:	e9 bf 00             	jmp    0x2872
    27b3:	bf fc 26             	mov    di,0x26fc
    27b6:	0e                   	push   cs
    27b7:	57                   	push   di
    27b8:	8d be 00 ff          	lea    di,[bp-0x100]
    27bc:	16                   	push   ss
    27bd:	57                   	push   di
    27be:	9a 78 18 de 27       	call   0x27de:0x1878
    27c3:	89 86 fc fc          	mov    WORD PTR [bp-0x304],ax
    27c7:	8d be f2 fb          	lea    di,[bp-0x40e]
    27cb:	16                   	push   ss
    27cc:	57                   	push   di
    27cd:	8d be 00 ff          	lea    di,[bp-0x100]
    27d1:	16                   	push   ss
    27d2:	57                   	push   di
    27d3:	6a 01                	push   0x1
    27d5:	8b 86 fc fc          	mov    ax,WORD PTR [bp-0x304]
    27d9:	48                   	dec    ax
    27da:	50                   	push   ax
    27db:	9a 0b 18 ec 27       	call   0x27ec:0x180b
    27e0:	8d be 00 fe          	lea    di,[bp-0x200]
    27e4:	16                   	push   ss
    27e5:	57                   	push   di
    27e6:	68 ff 00             	push   0xff
    27e9:	9a e7 17 04 28       	call   0x2804:0x17e7
    27ee:	83 be fe fc 00       	cmp    WORD PTR [bp-0x302],0x0
    27f3:	75 29                	jne    0x281e
    27f5:	8d be f2 fb          	lea    di,[bp-0x40e]
    27f9:	16                   	push   ss
    27fa:	57                   	push   di
    27fb:	8d be 00 fe          	lea    di,[bp-0x200]
    27ff:	16                   	push   ss
    2800:	57                   	push   di
    2801:	9a cd 17 0e 28       	call   0x280e:0x17cd
    2806:	bf fc 26             	mov    di,0x26fc
    2809:	0e                   	push   cs
    280a:	57                   	push   di
    280b:	9a 4c 18 1c 28       	call   0x281c:0x184c
    2810:	8d be 00 fe          	lea    di,[bp-0x200]
    2814:	16                   	push   ss
    2815:	57                   	push   di
    2816:	68 ff 00             	push   0xff
    2819:	9a e7 17 3a 28       	call   0x283a:0x17e7
    281e:	8d be f2 fb          	lea    di,[bp-0x40e]
    2822:	16                   	push   ss
    2823:	57                   	push   di
    2824:	8d be 00 ff          	lea    di,[bp-0x100]
    2828:	16                   	push   ss
    2829:	57                   	push   di
    282a:	8b 86 fc fc          	mov    ax,WORD PTR [bp-0x304]
    282e:	40                   	inc    ax
    282f:	50                   	push   ax
    2830:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    2834:	30 e4                	xor    ah,ah
    2836:	50                   	push   ax
    2837:	9a 0b 18 48 28       	call   0x2848:0x180b
    283c:	8d be 00 ff          	lea    di,[bp-0x100]
    2840:	16                   	push   ss
    2841:	57                   	push   di
    2842:	68 ff 00             	push   0xff
    2845:	9a e7 17 d0 28       	call   0x28d0:0x17e7
    284a:	8d be 00 fe          	lea    di,[bp-0x200]
    284e:	16                   	push   ss
    284f:	57                   	push   di
    2850:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2853:	26 ff b5 15 01       	push   WORD PTR es:[di+0x115]
    2858:	26 ff b5 13 01       	push   WORD PTR es:[di+0x113]
    285d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2862:	06                   	push   es
    2863:	57                   	push   di
    2864:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2867:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    286b:	ff 86 fe fc          	inc    WORD PTR [bp-0x302]
    286f:	e9 2a ff             	jmp    0x279c
    2872:	8d be 00 ff          	lea    di,[bp-0x100]
    2876:	16                   	push   ss
    2877:	57                   	push   di
    2878:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    287b:	26 ff b5 19 01       	push   WORD PTR es:[di+0x119]
    2880:	26 ff b5 17 01       	push   WORD PTR es:[di+0x117]
    2885:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    288a:	06                   	push   es
    288b:	57                   	push   di
    288c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    288f:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    2893:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2896:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    289b:	06                   	push   es
    289c:	57                   	push   di
    289d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28a0:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    28a4:	48                   	dec    ax
    28a5:	89 86 f2 fc          	mov    WORD PTR [bp-0x30e],ax
    28a9:	8d be f2 fa          	lea    di,[bp-0x50e]
    28ad:	16                   	push   ss
    28ae:	57                   	push   di
    28af:	8d be f2 fb          	lea    di,[bp-0x40e]
    28b3:	16                   	push   ss
    28b4:	57                   	push   di
    28b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b8:	06                   	push   es
    28b9:	57                   	push   di
    28ba:	9a 4a 26 13 29       	call   0x2913:0x264a
    28bf:	9a c1 0b 88 2e       	call   0x2e88:0xbc1
    28c4:	8d be 00 fe          	lea    di,[bp-0x200]
    28c8:	16                   	push   ss
    28c9:	57                   	push   di
    28ca:	68 ff 00             	push   0xff
    28cd:	9a e7 17 95 29       	call   0x2995:0x17e7
    28d2:	b8 fe 26             	mov    ax,0x26fe
    28d5:	0e                   	push   cs
    28d6:	50                   	push   ax
    28d7:	55                   	push   bp
    28d8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    28dc:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    28e0:	b0 01                	mov    al,0x1
    28e2:	50                   	push   ax
    28e3:	b8 c9 03             	mov    ax,0x3c9
    28e6:	ba ee 28             	mov    dx,0x28ee
    28e9:	52                   	push   dx
    28ea:	50                   	push   ax
    28eb:	9a 08 1d 03 29       	call   0x2903:0x1d08
    28f0:	89 86 f6 fc          	mov    WORD PTR [bp-0x30a],ax
    28f4:	89 96 f8 fc          	mov    WORD PTR [bp-0x308],dx
    28f8:	6a 01                	push   0x1
    28fa:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    28fe:	06                   	push   es
    28ff:	57                   	push   di
    2900:	9a de 22 b1 29       	call   0x29b1:0x22de
    2905:	8d be f2 fb          	lea    di,[bp-0x40e]
    2909:	16                   	push   ss
    290a:	57                   	push   di
    290b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290e:	06                   	push   es
    290f:	57                   	push   di
    2910:	9a 4a 26 de 29       	call   0x29de:0x264a
    2915:	ff b6 f8 fc          	push   WORD PTR [bp-0x308]
    2919:	ff b6 f6 fc          	push   WORD PTR [bp-0x30a]
    291d:	e8 b7 f9             	call   0x22d7
    2920:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    2924:	06                   	push   es
    2925:	57                   	push   di
    2926:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2929:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    292d:	48                   	dec    ax
    292e:	89 86 f0 fc          	mov    WORD PTR [bp-0x310],ax
    2932:	31 c0                	xor    ax,ax
    2934:	3b 86 f0 fc          	cmp    ax,WORD PTR [bp-0x310]
    2938:	7f 46                	jg     0x2980
    293a:	89 86 fa fc          	mov    WORD PTR [bp-0x306],ax
    293e:	eb 04                	jmp    0x2944
    2940:	ff 86 fa fc          	inc    WORD PTR [bp-0x306]
    2944:	8d be f0 fb          	lea    di,[bp-0x410]
    2948:	16                   	push   ss
    2949:	57                   	push   di
    294a:	ff b6 fa fc          	push   WORD PTR [bp-0x306]
    294e:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    2952:	06                   	push   es
    2953:	57                   	push   di
    2954:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2957:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    295b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    295e:	26 ff b5 11 01       	push   WORD PTR es:[di+0x111]
    2963:	26 ff b5 0f 01       	push   WORD PTR es:[di+0x10f]
    2968:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    296d:	06                   	push   es
    296e:	57                   	push   di
    296f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2972:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    2976:	8b 86 fa fc          	mov    ax,WORD PTR [bp-0x306]
    297a:	3b 86 f0 fc          	cmp    ax,WORD PTR [bp-0x310]
    297e:	75 c0                	jne    0x2940
    2980:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2984:	83 c4 06             	add    sp,0x6
    2987:	b8 98 29             	mov    ax,0x2998
    298a:	0e                   	push   cs
    298b:	50                   	push   ax
    298c:	c4 be f6 fc          	les    di,DWORD PTR [bp-0x30a]
    2990:	06                   	push   es
    2991:	57                   	push   di
    2992:	9a 7f 1f d8 2c       	call   0x2cd8:0x1f7f
    2997:	cb                   	retf
    2998:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    299c:	83 c4 06             	add    sp,0x6
    299f:	b8 b4 29             	mov    ax,0x29b4
    29a2:	0e                   	push   cs
    29a3:	50                   	push   ax
    29a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a7:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    29ac:	06                   	push   es
    29ad:	57                   	push   di
    29ae:	9a 35 14 fa 2b       	call   0x2bfa:0x1435
    29b3:	cb                   	retf
    29b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29b7:	06                   	push   es
    29b8:	57                   	push   di
    29b9:	9a fa 64 97 2a       	call   0x2a97:0x64fa
    29be:	08 c0                	or     al,al
    29c0:	74 0e                	je     0x29d0
    29c2:	ff b6 f2 fc          	push   WORD PTR [bp-0x30e]
    29c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c9:	06                   	push   es
    29ca:	57                   	push   di
    29cb:	9a e2 77 a7 2e       	call   0x2ea7:0x77e2
    29d0:	c9                   	leave
    29d1:	ca 04 00             	retf   0x4
    29d4:	55                   	push   bp
    29d5:	89 e5                	mov    bp,sp
    29d7:	b0 01                	mov    al,0x1
    29d9:	50                   	push   ax
    29da:	b8 62 06             	mov    ax,0x662
    29dd:	ba e5 29             	mov    dx,0x29e5
    29e0:	52                   	push   dx
    29e1:	50                   	push   ax
    29e2:	9a d5 23 19 2a       	call   0x2a19:0x23d5
    29e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ea:	26 89 85 13 01       	mov    WORD PTR es:[di+0x113],ax
    29ef:	26 89 95 15 01       	mov    WORD PTR es:[di+0x115],dx
    29f4:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    29f8:	bf 92 09             	mov    di,0x992
    29fb:	1e                   	push   ds
    29fc:	57                   	push   di
    29fd:	9a 39 2a 00 00       	call   0x0:0x2a39
    2a02:	50                   	push   ax
    2a03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a06:	26 c4 bd 13 01       	les    di,DWORD PTR es:[di+0x113]
    2a0b:	06                   	push   es
    2a0c:	57                   	push   di
    2a0d:	9a 04 61 4b 2a       	call   0x2a4b:0x6104
    2a12:	b0 01                	mov    al,0x1
    2a14:	50                   	push   ax
    2a15:	b8 62 06             	mov    ax,0x662
    2a18:	ba 20 2a             	mov    dx,0x2a20
    2a1b:	52                   	push   dx
    2a1c:	50                   	push   ax
    2a1d:	9a d5 23 54 2a       	call   0x2a54:0x23d5
    2a22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a25:	26 89 85 0f 01       	mov    WORD PTR es:[di+0x10f],ax
    2a2a:	26 89 95 11 01       	mov    WORD PTR es:[di+0x111],dx
    2a2f:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    2a33:	bf 9d 09             	mov    di,0x99d
    2a36:	1e                   	push   ds
    2a37:	57                   	push   di
    2a38:	9a 74 2a 00 00       	call   0x0:0x2a74
    2a3d:	50                   	push   ax
    2a3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a41:	26 c4 bd 0f 01       	les    di,DWORD PTR es:[di+0x10f]
    2a46:	06                   	push   es
    2a47:	57                   	push   di
    2a48:	9a 04 61 86 2a       	call   0x2a86:0x6104
    2a4d:	b0 01                	mov    al,0x1
    2a4f:	50                   	push   ax
    2a50:	b8 62 06             	mov    ax,0x662
    2a53:	ba 5b 2a             	mov    dx,0x2a5b
    2a56:	52                   	push   dx
    2a57:	50                   	push   ax
    2a58:	9a d5 23 a1 2a       	call   0x2aa1:0x23d5
    2a5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a60:	26 89 85 17 01       	mov    WORD PTR es:[di+0x117],ax
    2a65:	26 89 95 19 01       	mov    WORD PTR es:[di+0x119],dx
    2a6a:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    2a6e:	bf aa 09             	mov    di,0x9aa
    2a71:	1e                   	push   ds
    2a72:	57                   	push   di
    2a73:	9a 92 33 00 00       	call   0x0:0x3392
    2a78:	50                   	push   ax
    2a79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a7c:	26 c4 bd 17 01       	les    di,DWORD PTR es:[di+0x117]
    2a81:	06                   	push   es
    2a82:	57                   	push   di
    2a83:	9a 04 61 3b 2b       	call   0x2b3b:0x6104
    2a88:	c9                   	leave
    2a89:	ca 04 00             	retf   0x4
    2a8c:	55                   	push   bp
    2a8d:	89 e5                	mov    bp,sp
    2a8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a92:	06                   	push   es
    2a93:	57                   	push   di
    2a94:	9a 98 27 e9 2e       	call   0x2ee9:0x2798
    2a99:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a9c:	06                   	push   es
    2a9d:	57                   	push   di
    2a9e:	9a cc 26 c8 2a       	call   0x2ac8:0x26cc
    2aa3:	c9                   	leave
    2aa4:	ca 04 00             	retf   0x4
    2aa7:	c8 00 01 00          	enter  0x100,0x0
    2aab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aae:	26 8b 85 02 01       	mov    ax,WORD PTR es:[di+0x102]
    2ab3:	26 0b 85 04 01       	or     ax,WORD PTR es:[di+0x104]
    2ab8:	74 1f                	je     0x2ad9
    2aba:	8d be 00 ff          	lea    di,[bp-0x100]
    2abe:	16                   	push   ss
    2abf:	57                   	push   di
    2ac0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac3:	06                   	push   es
    2ac4:	57                   	push   di
    2ac5:	9a 4a 26 d7 2a       	call   0x2ad7:0x264a
    2aca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2acd:	26 c4 bd 02 01       	les    di,DWORD PTR es:[di+0x102]
    2ad2:	06                   	push   es
    2ad3:	57                   	push   di
    2ad4:	9a f1 3a e1 2a       	call   0x2ae1:0x3af1
    2ad9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2adc:	06                   	push   es
    2add:	57                   	push   di
    2ade:	9a 4d 31 97 2b       	call   0x2b97:0x314d
    2ae3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae6:	26 8b 85 1d 02       	mov    ax,WORD PTR es:[di+0x21d]
    2aeb:	09 c0                	or     ax,ax
    2aed:	74 15                	je     0x2b04
    2aef:	ff 76 08             	push   WORD PTR [bp+0x8]
    2af2:	ff 76 06             	push   WORD PTR [bp+0x6]
    2af5:	26 ff b5 21 02       	push   WORD PTR es:[di+0x221]
    2afa:	26 ff b5 1f 02       	push   WORD PTR es:[di+0x21f]
    2aff:	26 ff 9d 1b 02       	call   DWORD PTR es:[di+0x21b]
    2b04:	c9                   	leave
    2b05:	ca 04 00             	retf   0x4
    2b08:	c8 14 01 00          	enter  0x114,0x0
    2b0c:	8c d3                	mov    bx,ss
    2b0e:	8e c3                	mov    es,bx
    2b10:	8c db                	mov    bx,ds
    2b12:	fc                   	cld
    2b13:	8d 7e f8             	lea    di,[bp-0x8]
    2b16:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    2b19:	b9 08 00             	mov    cx,0x8
    2b1c:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2b1e:	8e db                	mov    ds,bx
    2b20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b23:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    2b28:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    2b2b:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    2b2e:	8d 7e f8             	lea    di,[bp-0x8]
    2b31:	16                   	push   ss
    2b32:	57                   	push   di
    2b33:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    2b36:	06                   	push   es
    2b37:	57                   	push   di
    2b38:	9a e5 1c 42 2c       	call   0x2c42:0x1ce5
    2b3d:	c7 46 f2 10 00       	mov    WORD PTR [bp-0xe],0x10
    2b42:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
    2b45:	c1 e0 02             	shl    ax,0x2
    2b48:	40                   	inc    ax
    2b49:	40                   	inc    ax
    2b4a:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2b4d:	ff 76 10             	push   WORD PTR [bp+0x10]
    2b50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b53:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2b58:	06                   	push   es
    2b59:	57                   	push   di
    2b5a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b5d:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    2b61:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2b64:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    2b67:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    2b6a:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    2b6d:	75 03                	jne    0x2b72
    2b6f:	e9 e9 00             	jmp    0x2c5b
    2b72:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    2b75:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    2b78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b7b:	26 3b 95 11 01       	cmp    dx,WORD PTR es:[di+0x111]
    2b80:	75 23                	jne    0x2ba5
    2b82:	26 3b 85 0f 01       	cmp    ax,WORD PTR es:[di+0x10f]
    2b87:	75 1c                	jne    0x2ba5
    2b89:	8d be ec fe          	lea    di,[bp-0x114]
    2b8d:	16                   	push   ss
    2b8e:	57                   	push   di
    2b8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b92:	06                   	push   es
    2b93:	57                   	push   di
    2b94:	9a 4a 26 ca 2c       	call   0x2cca:0x264a
    2b99:	e8 e7 f6             	call   0x2283
    2b9c:	40                   	inc    ax
    2b9d:	c1 e0 02             	shl    ax,0x2
    2ba0:	40                   	inc    ax
    2ba1:	40                   	inc    ax
    2ba2:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2ba5:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2ba8:	06                   	push   es
    2ba9:	57                   	push   di
    2baa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bad:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    2bb1:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2bb4:	8d 7e e4             	lea    di,[bp-0x1c]
    2bb7:	16                   	push   ss
    2bb8:	57                   	push   di
    2bb9:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2bbc:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    2bbf:	50                   	push   ax
    2bc0:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2bc3:	06                   	push   es
    2bc4:	57                   	push   di
    2bc5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bc8:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    2bcc:	8b d0                	mov    dx,ax
    2bce:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2bd1:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    2bd4:	2b c2                	sub    ax,dx
    2bd6:	99                   	cwd
    2bd7:	b9 02 00             	mov    cx,0x2
    2bda:	f7 f9                	idiv   cx
    2bdc:	50                   	push   ax
    2bdd:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2be0:	06                   	push   es
    2be1:	57                   	push   di
    2be2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2be5:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    2be9:	50                   	push   ax
    2bea:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2bed:	06                   	push   es
    2bee:	57                   	push   di
    2bef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bf2:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    2bf6:	50                   	push   ax
    2bf7:	9a ae 06 28 2c       	call   0x2c28:0x6ae
    2bfc:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2bff:	ff 76 f4             	push   WORD PTR [bp-0xc]
    2c02:	8d 7e dc             	lea    di,[bp-0x24]
    2c05:	16                   	push   ss
    2c06:	57                   	push   di
    2c07:	6a 00                	push   0x0
    2c09:	6a 00                	push   0x0
    2c0b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2c0e:	06                   	push   es
    2c0f:	57                   	push   di
    2c10:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c13:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    2c17:	50                   	push   ax
    2c18:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2c1b:	06                   	push   es
    2c1c:	57                   	push   di
    2c1d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c20:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    2c24:	50                   	push   ax
    2c25:	9a ae 06 4c 3a       	call   0x3a4c:0x6ae
    2c2a:	6a 00                	push   0x0
    2c2c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2c2f:	06                   	push   es
    2c30:	57                   	push   di
    2c31:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c34:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    2c38:	48                   	dec    ax
    2c39:	50                   	push   ax
    2c3a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2c3d:	06                   	push   es
    2c3e:	57                   	push   di
    2c3f:	9a 0f 5a 4d 2c       	call   0x2c4d:0x5a0f
    2c44:	89 c7                	mov    di,ax
    2c46:	8e c2                	mov    es,dx
    2c48:	06                   	push   es
    2c49:	57                   	push   di
    2c4a:	9a 32 21 59 2c       	call   0x2c59:0x2132
    2c4f:	52                   	push   dx
    2c50:	50                   	push   ax
    2c51:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    2c54:	06                   	push   es
    2c55:	57                   	push   di
    2c56:	9a 23 19 8d 2c       	call   0x2c8d:0x1923
    2c5b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2c5e:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    2c61:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    2c64:	05 04 00             	add    ax,0x4
    2c67:	50                   	push   ax
    2c68:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c6b:	8d be ec fe          	lea    di,[bp-0x114]
    2c6f:	16                   	push   ss
    2c70:	57                   	push   di
    2c71:	ff 76 10             	push   WORD PTR [bp+0x10]
    2c74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c77:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2c7c:	06                   	push   es
    2c7d:	57                   	push   di
    2c7e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c81:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    2c85:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    2c88:	06                   	push   es
    2c89:	57                   	push   di
    2c8a:	9a 09 1f 72 33       	call   0x3372:0x1f09
    2c8f:	c9                   	leave
    2c90:	ca 0c 00             	retf   0xc
    2c93:	02 3a                	add    bh,BYTE PTR [bp+si]
    2c95:	5c                   	pop    sp
    2c96:	01 5c c8             	add    WORD PTR [si-0x38],bx
    2c99:	08 03                	or     BYTE PTR [bp+di],al
    2c9b:	00 c4                	add    ah,al
    2c9d:	7e 0c                	jle    0x2cab
    2c9f:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    2ca3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ca6:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2cab:	06                   	push   es
    2cac:	57                   	push   di
    2cad:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2cb0:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2cb4:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    2cb7:	7f 03                	jg     0x2cbc
    2cb9:	e9 db 01             	jmp    0x2e97
    2cbc:	8d be f8 fd          	lea    di,[bp-0x208]
    2cc0:	16                   	push   ss
    2cc1:	57                   	push   di
    2cc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cc5:	06                   	push   es
    2cc6:	57                   	push   di
    2cc7:	9a 4a 26 0a 2d       	call   0x2d0a:0x264a
    2ccc:	8d be 00 ff          	lea    di,[bp-0x100]
    2cd0:	16                   	push   ss
    2cd1:	57                   	push   di
    2cd2:	68 ff 00             	push   0xff
    2cd5:	9a e7 17 10 2d       	call   0x2d10:0x17e7
    2cda:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2cdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ce0:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2ce5:	06                   	push   es
    2ce6:	57                   	push   di
    2ce7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2cea:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    2cee:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    2cf2:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
    2cf6:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    2cfa:	75 30                	jne    0x2d2c
    2cfc:	8d be f8 fd          	lea    di,[bp-0x208]
    2d00:	16                   	push   ss
    2d01:	57                   	push   di
    2d02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d05:	06                   	push   es
    2d06:	57                   	push   di
    2d07:	9a 4b 2f c4 2e       	call   0x2ec4:0x2f4b
    2d0c:	50                   	push   ax
    2d0d:	9a e9 18 1a 2d       	call   0x2d1a:0x18e9
    2d12:	bf 93 2c             	mov    di,0x2c93
    2d15:	0e                   	push   cs
    2d16:	57                   	push   di
    2d17:	9a 4c 18 27 2d       	call   0x2d27:0x184c
    2d1c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2d1f:	06                   	push   es
    2d20:	57                   	push   di
    2d21:	68 ff 00             	push   0xff
    2d24:	9a e7 17 69 2d       	call   0x2d69:0x17e7
    2d29:	e9 4e 01             	jmp    0x2e7a
    2d2c:	8b 86 f8 fe          	mov    ax,WORD PTR [bp-0x108]
    2d30:	8b 96 fa fe          	mov    dx,WORD PTR [bp-0x106]
    2d34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d37:	26 3b 95 11 01       	cmp    dx,WORD PTR es:[di+0x111]
    2d3c:	74 03                	je     0x2d41
    2d3e:	e9 a2 00             	jmp    0x2de3
    2d41:	26 3b 85 0f 01       	cmp    ax,WORD PTR es:[di+0x10f]
    2d46:	74 03                	je     0x2d4b
    2d48:	e9 98 00             	jmp    0x2de3
    2d4b:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    2d4f:	30 e4                	xor    ah,ah
    2d51:	8b f8                	mov    di,ax
    2d53:	80 bb 00 ff 5c       	cmp    BYTE PTR [bp+di-0x100],0x5c
    2d58:	75 3f                	jne    0x2d99
    2d5a:	8d be f8 fc          	lea    di,[bp-0x308]
    2d5e:	16                   	push   ss
    2d5f:	57                   	push   di
    2d60:	8d be 00 ff          	lea    di,[bp-0x100]
    2d64:	16                   	push   ss
    2d65:	57                   	push   di
    2d66:	9a cd 17 88 2d       	call   0x2d88:0x17cd
    2d6b:	8d be f8 fd          	lea    di,[bp-0x208]
    2d6f:	16                   	push   ss
    2d70:	57                   	push   di
    2d71:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2d74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d77:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2d7c:	06                   	push   es
    2d7d:	57                   	push   di
    2d7e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d81:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    2d85:	9a 4c 18 95 2d       	call   0x2d95:0x184c
    2d8a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2d8d:	06                   	push   es
    2d8e:	57                   	push   di
    2d8f:	68 ff 00             	push   0xff
    2d92:	9a e7 17 a8 2d       	call   0x2da8:0x17e7
    2d97:	eb 47                	jmp    0x2de0
    2d99:	8d be f8 fd          	lea    di,[bp-0x208]
    2d9d:	16                   	push   ss
    2d9e:	57                   	push   di
    2d9f:	8d be 00 ff          	lea    di,[bp-0x100]
    2da3:	16                   	push   ss
    2da4:	57                   	push   di
    2da5:	9a cd 17 b2 2d       	call   0x2db2:0x17cd
    2daa:	bf 96 2c             	mov    di,0x2c96
    2dad:	0e                   	push   cs
    2dae:	57                   	push   di
    2daf:	9a 4c 18 d1 2d       	call   0x2dd1:0x184c
    2db4:	8d be f8 fc          	lea    di,[bp-0x308]
    2db8:	16                   	push   ss
    2db9:	57                   	push   di
    2dba:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2dbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dc0:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2dc5:	06                   	push   es
    2dc6:	57                   	push   di
    2dc7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2dca:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    2dce:	9a 4c 18 de 2d       	call   0x2dde:0x184c
    2dd3:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2dd6:	06                   	push   es
    2dd7:	57                   	push   di
    2dd8:	68 ff 00             	push   0xff
    2ddb:	9a e7 17 0d 2e       	call   0x2e0d:0x17e7
    2de0:	e9 97 00             	jmp    0x2e7a
    2de3:	8b 86 f8 fe          	mov    ax,WORD PTR [bp-0x108]
    2de7:	8b 96 fa fe          	mov    dx,WORD PTR [bp-0x106]
    2deb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dee:	26 3b 95 19 01       	cmp    dx,WORD PTR es:[di+0x119]
    2df3:	75 1c                	jne    0x2e11
    2df5:	26 3b 85 17 01       	cmp    ax,WORD PTR es:[di+0x117]
    2dfa:	75 15                	jne    0x2e11
    2dfc:	8d be 00 ff          	lea    di,[bp-0x100]
    2e00:	16                   	push   ss
    2e01:	57                   	push   di
    2e02:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2e05:	06                   	push   es
    2e06:	57                   	push   di
    2e07:	68 ff 00             	push   0xff
    2e0a:	9a e7 17 6b 2e       	call   0x2e6b:0x17e7
    2e0f:	eb 69                	jmp    0x2e7a
    2e11:	31 c0                	xor    ax,ax
    2e13:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    2e17:	31 c0                	xor    ax,ax
    2e19:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    2e1d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2e20:	40                   	inc    ax
    2e21:	3b 86 fc fe          	cmp    ax,WORD PTR [bp-0x104]
    2e25:	74 2d                	je     0x2e54
    2e27:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    2e2b:	40                   	inc    ax
    2e2c:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    2e30:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    2e34:	30 e4                	xor    ah,ah
    2e36:	3b 86 fe fe          	cmp    ax,WORD PTR [bp-0x102]
    2e3a:	7d 02                	jge    0x2e3e
    2e3c:	eb 16                	jmp    0x2e54
    2e3e:	8b be fe fe          	mov    di,WORD PTR [bp-0x102]
    2e42:	80 bb 00 ff 5c       	cmp    BYTE PTR [bp+di-0x100],0x5c
    2e47:	75 09                	jne    0x2e52
    2e49:	8b 86 fc fe          	mov    ax,WORD PTR [bp-0x104]
    2e4d:	40                   	inc    ax
    2e4e:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    2e52:	eb c9                	jmp    0x2e1d
    2e54:	8d be f8 fd          	lea    di,[bp-0x208]
    2e58:	16                   	push   ss
    2e59:	57                   	push   di
    2e5a:	8d be 00 ff          	lea    di,[bp-0x100]
    2e5e:	16                   	push   ss
    2e5f:	57                   	push   di
    2e60:	6a 01                	push   0x1
    2e62:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    2e66:	48                   	dec    ax
    2e67:	50                   	push   ax
    2e68:	9a 0b 18 78 2e       	call   0x2e78:0x180b
    2e6d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2e70:	06                   	push   es
    2e71:	57                   	push   di
    2e72:	68 ff 00             	push   0xff
    2e75:	9a e7 17 95 2e       	call   0x2e95:0x17e7
    2e7a:	8d be f8 fd          	lea    di,[bp-0x208]
    2e7e:	16                   	push   ss
    2e7f:	57                   	push   di
    2e80:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2e83:	06                   	push   es
    2e84:	57                   	push   di
    2e85:	9a 81 07 a7 2f       	call   0x2fa7:0x781
    2e8a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2e8d:	06                   	push   es
    2e8e:	57                   	push   di
    2e8f:	68 ff 00             	push   0xff
    2e92:	9a e7 17 77 2f       	call   0x2f77:0x17e7
    2e97:	c9                   	leave
    2e98:	ca 06 00             	retf   0x6
    2e9b:	c8 00 01 00          	enter  0x100,0x0
    2e9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ea2:	06                   	push   es
    2ea3:	57                   	push   di
    2ea4:	9a f7 7b d2 2e       	call   0x2ed2:0x7bf7
    2ea9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eac:	06                   	push   es
    2ead:	57                   	push   di
    2eae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2eb1:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    2eb6:	8d be 00 ff          	lea    di,[bp-0x100]
    2eba:	16                   	push   ss
    2ebb:	57                   	push   di
    2ebc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ebf:	06                   	push   es
    2ec0:	57                   	push   di
    2ec1:	9a 4a 26 f3 2e       	call   0x2ef3:0x264a
    2ec6:	e8 ba f3             	call   0x2283
    2ec9:	50                   	push   ax
    2eca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ecd:	06                   	push   es
    2ece:	57                   	push   di
    2ecf:	9a e2 77 45 2f       	call   0x2f45:0x77e2
    2ed4:	c9                   	leave
    2ed5:	ca 04 00             	retf   0x4
    2ed8:	55                   	push   bp
    2ed9:	89 e5                	mov    bp,sp
    2edb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ede:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ee1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ee4:	06                   	push   es
    2ee5:	57                   	push   di
    2ee6:	9a 3a 57 a2 30       	call   0x30a2:0x573a
    2eeb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eee:	06                   	push   es
    2eef:	57                   	push   di
    2ef0:	9a f9 2e 71 2f       	call   0x2f71:0x2ef9
    2ef5:	c9                   	leave
    2ef6:	ca 08 00             	retf   0x8
    2ef9:	c8 02 00 00          	enter  0x2,0x0
    2efd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f00:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    2f04:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    2f08:	e8 c9 ea             	call   0x19d4
    2f0b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2f0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f11:	26 c4 bd 13 01       	les    di,DWORD PTR es:[di+0x113]
    2f16:	06                   	push   es
    2f17:	57                   	push   di
    2f18:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f1b:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    2f1f:	40                   	inc    ax
    2f20:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    2f23:	7e 15                	jle    0x2f3a
    2f25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f28:	26 c4 bd 13 01       	les    di,DWORD PTR es:[di+0x113]
    2f2d:	06                   	push   es
    2f2e:	57                   	push   di
    2f2f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f32:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    2f36:	40                   	inc    ax
    2f37:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2f3a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2f3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f40:	06                   	push   es
    2f41:	57                   	push   di
    2f42:	9a 93 78 e8 31       	call   0x31e8:0x7893
    2f47:	c9                   	leave
    2f48:	ca 04 00             	retf   0x4
    2f4b:	c8 02 00 00          	enter  0x2,0x0
    2f4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f52:	26 8a 85 1c 01       	mov    al,BYTE PTR es:[di+0x11c]
    2f57:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2f5a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2f5d:	c9                   	leave
    2f5e:	ca 04 00             	retf   0x4
    2f61:	03 25                	add    sp,WORD PTR [di]
    2f63:	73 3a                	jae    0x2f9f
    2f65:	c8 08 01 00          	enter  0x108,0x0
    2f69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f6c:	06                   	push   es
    2f6d:	57                   	push   di
    2f6e:	9a 4b 2f be 2f       	call   0x2fbe:0x2f4b
    2f73:	50                   	push   ax
    2f74:	9a f9 1e 81 2f       	call   0x2f81:0x1ef9
    2f79:	50                   	push   ax
    2f7a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f7d:	50                   	push   ax
    2f7e:	9a f9 1e d5 31       	call   0x31d5:0x1ef9
    2f83:	5a                   	pop    dx
    2f84:	3a c2                	cmp    al,dl
    2f86:	74 2e                	je     0x2fb6
    2f88:	8d be f8 fe          	lea    di,[bp-0x108]
    2f8c:	16                   	push   ss
    2f8d:	57                   	push   di
    2f8e:	bf 61 2f             	mov    di,0x2f61
    2f91:	0e                   	push   cs
    2f92:	57                   	push   di
    2f93:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f96:	88 46 f8             	mov    BYTE PTR [bp-0x8],al
    2f99:	c6 46 fc 02          	mov    BYTE PTR [bp-0x4],0x2
    2f9d:	8d 7e f8             	lea    di,[bp-0x8]
    2fa0:	16                   	push   ss
    2fa1:	57                   	push   di
    2fa2:	6a 00                	push   0x0
    2fa4:	9a 34 10 e8 2f       	call   0x2fe8:0x1034
    2fa9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fac:	06                   	push   es
    2fad:	57                   	push   di
    2fae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2fb1:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    2fb6:	c9                   	leave
    2fb7:	ca 06 00             	retf   0x6
    2fba:	00 00                	add    BYTE PTR [bx+si],al
    2fbc:	74 30                	je     0x2fee
    2fbe:	e3 2f                	jcxz   0x2fef
    2fc0:	c8 02 03 00          	enter  0x302,0x0
    2fc4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2fc7:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2fcb:	75 03                	jne    0x2fd0
    2fcd:	e9 be 00             	jmp    0x308e
    2fd0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2fd3:	06                   	push   es
    2fd4:	57                   	push   di
    2fd5:	8d be fe fc          	lea    di,[bp-0x302]
    2fd9:	16                   	push   ss
    2fda:	57                   	push   di
    2fdb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fde:	06                   	push   es
    2fdf:	57                   	push   di
    2fe0:	9a 4a 26 11 30       	call   0x3011:0x264a
    2fe5:	9a ed 07 18 32       	call   0x3218:0x7ed
    2fea:	09 c0                	or     ax,ax
    2fec:	75 03                	jne    0x2ff1
    2fee:	e9 9d 00             	jmp    0x308e
    2ff1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ff4:	06                   	push   es
    2ff5:	57                   	push   di
    2ff6:	8d be ff fd          	lea    di,[bp-0x201]
    2ffa:	16                   	push   ss
    2ffb:	57                   	push   di
    2ffc:	8d be 00 ff          	lea    di,[bp-0x100]
    3000:	16                   	push   ss
    3001:	57                   	push   di
    3002:	68 ff 00             	push   0xff
    3005:	8d be 00 fe          	lea    di,[bp-0x200]
    3009:	16                   	push   ss
    300a:	57                   	push   di
    300b:	68 ff 00             	push   0xff
    300e:	9a eb 16 29 30       	call   0x3029:0x16eb
    3013:	b8 ba 2f             	mov    ax,0x2fba
    3016:	0e                   	push   cs
    3017:	50                   	push   ax
    3018:	55                   	push   bp
    3019:	ff 36 58 18          	push   WORD PTR ds:0x1858
    301d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3021:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3024:	06                   	push   es
    3025:	57                   	push   di
    3026:	9a 4b 2f 55 30       	call   0x3055:0x2f4b
    302b:	3a 86 ff fd          	cmp    al,BYTE PTR [bp-0x201]
    302f:	74 37                	je     0x3068
    3031:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3034:	26 c6 85 0e 01 01    	mov    BYTE PTR es:[di+0x10e],0x1
    303a:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    303f:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    3044:	74 13                	je     0x3059
    3046:	8a 86 ff fd          	mov    al,BYTE PTR [bp-0x201]
    304a:	50                   	push   ax
    304b:	26 c4 bd 06 01       	les    di,DWORD PTR es:[di+0x106]
    3050:	06                   	push   es
    3051:	57                   	push   di
    3052:	9a a4 1c 66 30       	call   0x3066:0x1ca4
    3057:	eb 0f                	jmp    0x3068
    3059:	8a 86 ff fd          	mov    al,BYTE PTR [bp-0x201]
    305d:	50                   	push   ax
    305e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3061:	06                   	push   es
    3062:	57                   	push   di
    3063:	9a 0d 25 8c 30       	call   0x308c:0x250d
    3068:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    306c:	83 c4 06             	add    sp,0x6
    306f:	b8 7e 30             	mov    ax,0x307e
    3072:	0e                   	push   cs
    3073:	50                   	push   ax
    3074:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3077:	26 c6 85 0e 01 00    	mov    BYTE PTR es:[di+0x10e],0x0
    307d:	cb                   	retf
    307e:	8d be 00 ff          	lea    di,[bp-0x100]
    3082:	16                   	push   ss
    3083:	57                   	push   di
    3084:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3087:	06                   	push   es
    3088:	57                   	push   di
    3089:	9a 67 26 b9 30       	call   0x30b9:0x2667
    308e:	c9                   	leave
    308f:	ca 08 00             	retf   0x8
    3092:	55                   	push   bp
    3093:	89 e5                	mov    bp,sp
    3095:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3098:	06                   	push   es
    3099:	57                   	push   di
    309a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    309d:	06                   	push   es
    309e:	57                   	push   di
    309f:	9a 1f 52 d4 30       	call   0x30d4:0x521f
    30a4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    30a7:	26 8a 05             	mov    al,BYTE PTR es:[di]
    30aa:	30 e4                	xor    ah,ah
    30ac:	3d 0d 00             	cmp    ax,0xd
    30af:	75 0a                	jne    0x30bb
    30b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30b4:	06                   	push   es
    30b5:	57                   	push   di
    30b6:	9a cc 26 97 31       	call   0x3197:0x26cc
    30bb:	c9                   	leave
    30bc:	ca 08 00             	retf   0x8
    30bf:	55                   	push   bp
    30c0:	89 e5                	mov    bp,sp
    30c2:	ff 76 0e             	push   WORD PTR [bp+0xe]
    30c5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    30c8:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    30cb:	50                   	push   ax
    30cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30cf:	06                   	push   es
    30d0:	57                   	push   di
    30d1:	9a 32 16 c0 31       	call   0x31c0:0x1632
    30d6:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    30da:	75 6d                	jne    0x3149
    30dc:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    30df:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    30e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30e5:	26 3b 95 04 01       	cmp    dx,WORD PTR es:[di+0x104]
    30ea:	75 15                	jne    0x3101
    30ec:	26 3b 85 02 01       	cmp    ax,WORD PTR es:[di+0x102]
    30f1:	75 0e                	jne    0x3101
    30f3:	31 c0                	xor    ax,ax
    30f5:	26 89 85 02 01       	mov    WORD PTR es:[di+0x102],ax
    30fa:	26 89 85 04 01       	mov    WORD PTR es:[di+0x104],ax
    30ff:	eb 48                	jmp    0x3149
    3101:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    3104:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    3107:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    310a:	26 3b 95 08 01       	cmp    dx,WORD PTR es:[di+0x108]
    310f:	75 15                	jne    0x3126
    3111:	26 3b 85 06 01       	cmp    ax,WORD PTR es:[di+0x106]
    3116:	75 0e                	jne    0x3126
    3118:	31 c0                	xor    ax,ax
    311a:	26 89 85 06 01       	mov    WORD PTR es:[di+0x106],ax
    311f:	26 89 85 08 01       	mov    WORD PTR es:[di+0x108],ax
    3124:	eb 23                	jmp    0x3149
    3126:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    3129:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    312c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    312f:	26 3b 95 0c 01       	cmp    dx,WORD PTR es:[di+0x10c]
    3134:	75 13                	jne    0x3149
    3136:	26 3b 85 0a 01       	cmp    ax,WORD PTR es:[di+0x10a]
    313b:	75 0c                	jne    0x3149
    313d:	31 c0                	xor    ax,ax
    313f:	26 89 85 0a 01       	mov    WORD PTR es:[di+0x10a],ax
    3144:	26 89 85 0c 01       	mov    WORD PTR es:[di+0x10c],ax
    3149:	c9                   	leave
    314a:	ca 0a 00             	retf   0xa
    314d:	c8 02 02 00          	enter  0x202,0x0
    3151:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3154:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    3159:	26 0b 85 0c 01       	or     ax,WORD PTR es:[di+0x10c]
    315e:	74 62                	je     0x31c2
    3160:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3164:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3167:	26 c4 bd 0a 01       	les    di,DWORD PTR es:[di+0x10a]
    316c:	26 80 bd 93 00 00    	cmp    BYTE PTR es:[di+0x93],0x0
    3172:	75 0f                	jne    0x3183
    3174:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3177:	26 c4 bd 0a 01       	les    di,DWORD PTR es:[di+0x10a]
    317c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3180:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3183:	8d be fe fd          	lea    di,[bp-0x202]
    3187:	16                   	push   ss
    3188:	57                   	push   di
    3189:	8d be fe fe          	lea    di,[bp-0x102]
    318d:	16                   	push   ss
    318e:	57                   	push   di
    318f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3192:	06                   	push   es
    3193:	57                   	push   di
    3194:	9a 4a 26 b1 31       	call   0x31b1:0x264a
    3199:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    319c:	26 c4 bd 0a 01       	les    di,DWORD PTR es:[di+0x10a]
    31a1:	26 ff b5 8c 00       	push   WORD PTR es:[di+0x8c]
    31a6:	26 ff b5 8a 00       	push   WORD PTR es:[di+0x8a]
    31ab:	ff 76 fe             	push   WORD PTR [bp-0x2]
    31ae:	9a 31 13 64 32       	call   0x3264:0x1331
    31b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31b6:	26 c4 bd 0a 01       	les    di,DWORD PTR es:[di+0x10a]
    31bb:	06                   	push   es
    31bc:	57                   	push   di
    31bd:	9a 8c 1d f5 31       	call   0x31f5:0x1d8c
    31c2:	c9                   	leave
    31c3:	ca 04 00             	retf   0x4
    31c6:	55                   	push   bp
    31c7:	89 e5                	mov    bp,sp
    31c9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    31cd:	74 08                	je     0x31d7
    31cf:	83 ec 08             	sub    sp,0x8
    31d2:	9a e2 1f 0e 32       	call   0x320e:0x1fe2
    31d7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    31da:	ff 76 0c             	push   WORD PTR [bp+0xc]
    31dd:	31 c0                	xor    ax,ax
    31df:	50                   	push   ax
    31e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31e3:	06                   	push   es
    31e4:	57                   	push   di
    31e5:	9a dc 75 2e 32       	call   0x322e:0x75dc
    31ea:	68 91 00             	push   0x91
    31ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31f0:	06                   	push   es
    31f1:	57                   	push   di
    31f2:	9a bf 17 46 34       	call   0x3446:0x17bf
    31f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31fa:	26 c6 85 06 02 40    	mov    BYTE PTR es:[di+0x206],0x40
    3200:	6a 00                	push   0x0
    3202:	81 c7 02 01          	add    di,0x102
    3206:	06                   	push   es
    3207:	57                   	push   di
    3208:	68 ff 00             	push   0xff
    320b:	9a 58 0e 8d 32       	call   0x328d:0xe58
    3210:	bf b8 09             	mov    di,0x9b8
    3213:	1e                   	push   ds
    3214:	57                   	push   di
    3215:	9a d6 0e bd 32       	call   0x32bd:0xed6
    321a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    321d:	26 89 85 02 02       	mov    WORD PTR es:[di+0x202],ax
    3222:	26 89 95 04 02       	mov    WORD PTR es:[di+0x204],dx
    3227:	6a 00                	push   0x0
    3229:	06                   	push   es
    322a:	57                   	push   di
    322b:	9a bc 78 4e 32       	call   0x324e:0x78bc
    3230:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3233:	26 c7 85 28 02 ff ff 	mov    WORD PTR es:[di+0x228],0xffff
    323a:	06                   	push   es
    323b:	57                   	push   di
    323c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    323f:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    3244:	6a 01                	push   0x1
    3246:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3249:	06                   	push   es
    324a:	57                   	push   di
    324b:	9a 4c 79 5a 32       	call   0x325a:0x794c
    3250:	6a 01                	push   0x1
    3252:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3255:	06                   	push   es
    3256:	57                   	push   di
    3257:	9a 6f 79 ca 32       	call   0x32ca:0x796f
    325c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    325f:	06                   	push   es
    3260:	57                   	push   di
    3261:	9a 03 3c 6d 34       	call   0x346d:0x3c03
    3266:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    326a:	74 07                	je     0x3273
    326c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3270:	83 c4 06             	add    sp,0x6
    3273:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3276:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    3279:	c9                   	leave
    327a:	ca 0a 00             	retf   0xa
    327d:	55                   	push   bp
    327e:	89 e5                	mov    bp,sp
    3280:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3283:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    3288:	06                   	push   es
    3289:	57                   	push   di
    328a:	9a 7f 1f 9c 32       	call   0x329c:0x1f7f
    328f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3292:	26 c4 bd 18 02       	les    di,DWORD PTR es:[di+0x218]
    3297:	06                   	push   es
    3298:	57                   	push   di
    3299:	9a 7f 1f ab 32       	call   0x32ab:0x1f7f
    329e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32a1:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    32a6:	06                   	push   es
    32a7:	57                   	push   di
    32a8:	9a 7f 1f d5 32       	call   0x32d5:0x1f7f
    32ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32b0:	26 ff b5 04 02       	push   WORD PTR es:[di+0x204]
    32b5:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    32ba:	9a 23 0f 12 33       	call   0x3312:0xf23
    32bf:	31 c0                	xor    ax,ax
    32c1:	50                   	push   ax
    32c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32c5:	06                   	push   es
    32c6:	57                   	push   di
    32c7:	9a c5 76 e6 32       	call   0x32e6:0x76c5
    32cc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    32d0:	74 05                	je     0x32d7
    32d2:	9a 0f 20 62 33       	call   0x3362:0x200f
    32d7:	c9                   	leave
    32d8:	ca 06 00             	retf   0x6
    32db:	55                   	push   bp
    32dc:	89 e5                	mov    bp,sp
    32de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32e1:	06                   	push   es
    32e2:	57                   	push   di
    32e3:	9a f7 7b c2 34       	call   0x34c2:0x7bf7
    32e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32eb:	06                   	push   es
    32ec:	57                   	push   di
    32ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32f0:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    32f5:	c9                   	leave
    32f6:	ca 04 00             	retf   0x4
    32f9:	c8 02 00 00          	enter  0x2,0x0
    32fd:	bf bc 09             	mov    di,0x9bc
    3300:	1e                   	push   ds
    3301:	57                   	push   di
    3302:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3305:	26 ff b5 04 02       	push   WORD PTR es:[di+0x204]
    330a:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    330f:	9a b2 0d 55 33       	call   0x3355:0xdb2
    3314:	09 c0                	or     ax,ax
    3316:	b0 00                	mov    al,0x0
    3318:	74 01                	je     0x331b
    331a:	40                   	inc    ax
    331b:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    331e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3321:	c9                   	leave
    3322:	ca 04 00             	retf   0x4
    3325:	c8 02 00 00          	enter  0x2,0x0
    3329:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    332c:	26 8a 85 06 02       	mov    al,BYTE PTR es:[di+0x206]
    3331:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    3334:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3337:	c9                   	leave
    3338:	ca 04 00             	retf   0x4
    333b:	c8 00 01 00          	enter  0x100,0x0
    333f:	8d be 00 ff          	lea    di,[bp-0x100]
    3343:	16                   	push   ss
    3344:	57                   	push   di
    3345:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3348:	26 ff b5 04 02       	push   WORD PTR es:[di+0x204]
    334d:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    3352:	9a 6e 0e f0 34       	call   0x34f0:0xe6e
    3357:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    335a:	06                   	push   es
    335b:	57                   	push   di
    335c:	68 ff 00             	push   0xff
    335f:	9a e7 17 b3 34       	call   0x34b3:0x17e7
    3364:	c9                   	leave
    3365:	ca 04 00             	retf   0x4
    3368:	55                   	push   bp
    3369:	89 e5                	mov    bp,sp
    336b:	b0 01                	mov    al,0x1
    336d:	50                   	push   ax
    336e:	b8 3f 08             	mov    ax,0x83f
    3371:	ba 79 33             	mov    dx,0x3379
    3374:	52                   	push   dx
    3375:	50                   	push   ax
    3376:	9a bd 56 a4 33       	call   0x33a4:0x56bd
    337b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    337e:	26 89 85 14 02       	mov    WORD PTR es:[di+0x214],ax
    3383:	26 89 95 16 02       	mov    WORD PTR es:[di+0x216],dx
    3388:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    338c:	bf c0 09             	mov    di,0x9c0
    338f:	1e                   	push   ds
    3390:	57                   	push   di
    3391:	9a cd 33 00 00       	call   0x0:0x33cd
    3396:	50                   	push   ax
    3397:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    339a:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    339f:	06                   	push   es
    33a0:	57                   	push   di
    33a1:	9a 04 61 ad 33       	call   0x33ad:0x6104
    33a6:	b0 01                	mov    al,0x1
    33a8:	50                   	push   ax
    33a9:	b8 3f 08             	mov    ax,0x83f
    33ac:	ba b4 33             	mov    dx,0x33b4
    33af:	52                   	push   dx
    33b0:	50                   	push   ax
    33b1:	9a bd 56 df 33       	call   0x33df:0x56bd
    33b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33b9:	26 89 85 18 02       	mov    WORD PTR es:[di+0x218],ax
    33be:	26 89 95 1a 02       	mov    WORD PTR es:[di+0x21a],dx
    33c3:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    33c7:	bf cb 09             	mov    di,0x9cb
    33ca:	1e                   	push   ds
    33cb:	57                   	push   di
    33cc:	9a 08 34 00 00       	call   0x0:0x3408
    33d1:	50                   	push   ax
    33d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33d5:	26 c4 bd 18 02       	les    di,DWORD PTR es:[di+0x218]
    33da:	06                   	push   es
    33db:	57                   	push   di
    33dc:	9a 04 61 e8 33       	call   0x33e8:0x6104
    33e1:	b0 01                	mov    al,0x1
    33e3:	50                   	push   ax
    33e4:	b8 3f 08             	mov    ax,0x83f
    33e7:	ba ef 33             	mov    dx,0x33ef
    33ea:	52                   	push   dx
    33eb:	50                   	push   ax
    33ec:	9a bd 56 1a 34       	call   0x341a:0x56bd
    33f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33f4:	26 89 85 1c 02       	mov    WORD PTR es:[di+0x21c],ax
    33f9:	26 89 95 1e 02       	mov    WORD PTR es:[di+0x21e],dx
    33fe:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    3402:	bf d8 09             	mov    di,0x9d8
    3405:	1e                   	push   ds
    3406:	57                   	push   di
    3407:	9a ff ff 00 00       	call   0x0:0xffff
    340c:	50                   	push   ax
    340d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3410:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    3415:	06                   	push   es
    3416:	57                   	push   di
    3417:	9a 04 61 cd 39       	call   0x39cd:0x6104
    341c:	c9                   	leave
    341d:	ca 04 00             	retf   0x4
    3420:	04 2e                	add    al,0x2e
    3422:	65 78 65             	gs js  0x348a
    3425:	04 2e                	add    al,0x2e
    3427:	63 6f 6d             	arpl   WORD PTR [bx+0x6d],bp
    342a:	04 2e                	add    al,0x2e
    342c:	62 61 74             	bound  sp,DWORD PTR [bx+di+0x74]
    342f:	04 2e                	add    al,0x2e
    3431:	70 69                	jo     0x349c
    3433:	66 c8 10 03 00       	enterd 0x310,0x0
    3438:	31 c0                	xor    ax,ax
    343a:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    343e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3441:	06                   	push   es
    3442:	57                   	push   di
    3443:	9a fa 64 14 35       	call   0x3514:0x64fa
    3448:	08 c0                	or     al,al
    344a:	75 03                	jne    0x344f
    344c:	e9 75 02             	jmp    0x36c4
    344f:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    3453:	eb 03                	jmp    0x3458
    3455:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    3458:	8a 4e ff             	mov    cl,BYTE PTR [bp-0x1]
    345b:	80 f9 08             	cmp    cl,0x8
    345e:	73 28                	jae    0x3488
    3460:	b0 01                	mov    al,0x1
    3462:	d2 c0                	rol    al,cl
    3464:	50                   	push   ax
    3465:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3468:	06                   	push   es
    3469:	57                   	push   di
    346a:	9a 25 33 96 34       	call   0x3496:0x3325
    346f:	5a                   	pop    dx
    3470:	84 d0                	test   al,dl
    3472:	74 14                	je     0x3488
    3474:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3477:	98                   	cbw
    3478:	8b f8                	mov    di,ax
    347a:	d1 e7                	shl    di,1
    347c:	8b 85 e4 09          	mov    ax,WORD PTR [di+0x9e4]
    3480:	0b 86 f2 fe          	or     ax,WORD PTR [bp-0x10e]
    3484:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    3488:	80 7e ff 05          	cmp    BYTE PTR [bp-0x1],0x5
    348c:	75 c7                	jne    0x3455
    348e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3491:	06                   	push   es
    3492:	57                   	push   di
    3493:	9a 25 33 fe 35       	call   0x35fe:0x3325
    3498:	a8 40                	test   al,0x40
    349a:	75 0b                	jne    0x34a7
    349c:	8b 86 f2 fe          	mov    ax,WORD PTR [bp-0x10e]
    34a0:	0d 00 80             	or     ax,0x8000
    34a3:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    34a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34aa:	81 c7 02 01          	add    di,0x102
    34ae:	06                   	push   es
    34af:	57                   	push   di
    34b0:	9a b2 0e b8 34       	call   0x34b8:0xeb2
    34b5:	9a 08 04 ad 35       	call   0x35ad:0x408
    34ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34bd:	06                   	push   es
    34be:	57                   	push   di
    34bf:	9a 11 77 dd 36       	call   0x36dd:0x7711
    34c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c7:	26 8b 85 02 02       	mov    ax,WORD PTR es:[di+0x202]
    34cc:	26 8b 95 04 02       	mov    dx,WORD PTR es:[di+0x204]
    34d1:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    34d5:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
    34d9:	8b 86 f8 fe          	mov    ax,WORD PTR [bp-0x108]
    34dd:	0b 86 fa fe          	or     ax,WORD PTR [bp-0x106]
    34e1:	74 70                	je     0x3553
    34e3:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    34e7:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    34eb:	6a 3b                	push   0x3b
    34ed:	9a 1f 0e 9f 35       	call   0x359f:0xe1f
    34f2:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    34f6:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    34fa:	8b 86 f4 fe          	mov    ax,WORD PTR [bp-0x10c]
    34fe:	0b 86 f6 fe          	or     ax,WORD PTR [bp-0x10a]
    3502:	74 08                	je     0x350c
    3504:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    3508:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    350c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    350f:	06                   	push   es
    3510:	57                   	push   di
    3511:	9a b9 62 d3 36       	call   0x36d3:0x62b9
    3516:	50                   	push   ax
    3517:	68 0e 04             	push   0x40e
    351a:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    351e:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    3522:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    3526:	9a ff ff 00 00       	call   0x0:0xffff
    352b:	8b 86 f4 fe          	mov    ax,WORD PTR [bp-0x10c]
    352f:	0b 86 f6 fe          	or     ax,WORD PTR [bp-0x10a]
    3533:	74 0c                	je     0x3541
    3535:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    3539:	26 c6 05 3b          	mov    BYTE PTR es:[di],0x3b
    353d:	ff 86 f4 fe          	inc    WORD PTR [bp-0x10c]
    3541:	8b 86 f4 fe          	mov    ax,WORD PTR [bp-0x10c]
    3545:	8b 96 f6 fe          	mov    dx,WORD PTR [bp-0x10a]
    3549:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    354d:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
    3551:	eb 86                	jmp    0x34d9
    3553:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3556:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    355b:	06                   	push   es
    355c:	57                   	push   di
    355d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3560:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3564:	48                   	dec    ax
    3565:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    3569:	31 c0                	xor    ax,ax
    356b:	3b 86 f0 fe          	cmp    ax,WORD PTR [bp-0x110]
    356f:	7e 03                	jle    0x3574
    3571:	e9 43 01             	jmp    0x36b7
    3574:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3577:	eb 03                	jmp    0x357c
    3579:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    357c:	8d be f0 fc          	lea    di,[bp-0x310]
    3580:	16                   	push   ss
    3581:	57                   	push   di
    3582:	8d be f0 fd          	lea    di,[bp-0x210]
    3586:	16                   	push   ss
    3587:	57                   	push   di
    3588:	ff 76 fc             	push   WORD PTR [bp-0x4]
    358b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    358e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3593:	06                   	push   es
    3594:	57                   	push   di
    3595:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3598:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    359c:	9a 17 0c cc 35       	call   0x35cc:0xc17
    35a1:	8d be fc fe          	lea    di,[bp-0x104]
    35a5:	16                   	push   ss
    35a6:	57                   	push   di
    35a7:	68 ff 00             	push   0xff
    35aa:	9a e7 17 33 36       	call   0x3633:0x17e7
    35af:	8d be f0 fd          	lea    di,[bp-0x210]
    35b3:	16                   	push   ss
    35b4:	57                   	push   di
    35b5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    35b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35bb:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    35c0:	06                   	push   es
    35c1:	57                   	push   di
    35c2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35c5:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    35c9:	9a 26 0a 8d 38       	call   0x388d:0xa26
    35ce:	08 c0                	or     al,al
    35d0:	75 53                	jne    0x3625
    35d2:	8d be f0 fc          	lea    di,[bp-0x310]
    35d6:	16                   	push   ss
    35d7:	57                   	push   di
    35d8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    35db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35de:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    35e3:	06                   	push   es
    35e4:	57                   	push   di
    35e5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35e8:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    35ec:	83 c4 04             	add    sp,0x4
    35ef:	80 be f1 fc 5b       	cmp    BYTE PTR [bp-0x30f],0x5b
    35f4:	75 2f                	jne    0x3625
    35f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35f9:	06                   	push   es
    35fa:	57                   	push   di
    35fb:	9a 25 33 27 37       	call   0x3727:0x3325
    3600:	a8 10                	test   al,0x10
    3602:	74 21                	je     0x3625
    3604:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3607:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    360a:	26 ff b5 1a 02       	push   WORD PTR es:[di+0x21a]
    360f:	26 ff b5 18 02       	push   WORD PTR es:[di+0x218]
    3614:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3619:	06                   	push   es
    361a:	57                   	push   di
    361b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    361e:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    3622:	e9 86 00             	jmp    0x36ab
    3625:	8d be fc fe          	lea    di,[bp-0x104]
    3629:	16                   	push   ss
    362a:	57                   	push   di
    362b:	bf 20 34             	mov    di,0x3420
    362e:	0e                   	push   cs
    362f:	57                   	push   di
    3630:	9a be 18 45 36       	call   0x3645:0x18be
    3635:	74 36                	je     0x366d
    3637:	8d be fc fe          	lea    di,[bp-0x104]
    363b:	16                   	push   ss
    363c:	57                   	push   di
    363d:	bf 25 34             	mov    di,0x3425
    3640:	0e                   	push   cs
    3641:	57                   	push   di
    3642:	9a be 18 57 36       	call   0x3657:0x18be
    3647:	74 24                	je     0x366d
    3649:	8d be fc fe          	lea    di,[bp-0x104]
    364d:	16                   	push   ss
    364e:	57                   	push   di
    364f:	bf 2a 34             	mov    di,0x342a
    3652:	0e                   	push   cs
    3653:	57                   	push   di
    3654:	9a be 18 69 36       	call   0x3669:0x18be
    3659:	74 12                	je     0x366d
    365b:	8d be fc fe          	lea    di,[bp-0x104]
    365f:	16                   	push   ss
    3660:	57                   	push   di
    3661:	bf 2f 34             	mov    di,0x342f
    3664:	0e                   	push   cs
    3665:	57                   	push   di
    3666:	9a be 18 6b 38       	call   0x386b:0x18be
    366b:	75 20                	jne    0x368d
    366d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3670:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3673:	26 ff b5 16 02       	push   WORD PTR es:[di+0x216]
    3678:	26 ff b5 14 02       	push   WORD PTR es:[di+0x214]
    367d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3682:	06                   	push   es
    3683:	57                   	push   di
    3684:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3687:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    368b:	eb 1e                	jmp    0x36ab
    368d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3690:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3693:	26 ff b5 1e 02       	push   WORD PTR es:[di+0x21e]
    3698:	26 ff b5 1c 02       	push   WORD PTR es:[di+0x21c]
    369d:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    36a2:	06                   	push   es
    36a3:	57                   	push   di
    36a4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36a7:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    36ab:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    36ae:	3b 86 f0 fe          	cmp    ax,WORD PTR [bp-0x110]
    36b2:	74 03                	je     0x36b7
    36b4:	e9 c2 fe             	jmp    0x3579
    36b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36ba:	06                   	push   es
    36bb:	57                   	push   di
    36bc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36bf:	26 ff 9d 88 00       	call   DWORD PTR es:[di+0x88]
    36c4:	c9                   	leave
    36c5:	ca 04 00             	retf   0x4
    36c8:	55                   	push   bp
    36c9:	89 e5                	mov    bp,sp
    36cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36ce:	06                   	push   es
    36cf:	57                   	push   di
    36d0:	9a 73 27 50 37       	call   0x3750:0x2773
    36d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36d8:	06                   	push   es
    36d9:	57                   	push   di
    36da:	9a bb 77 03 37       	call   0x3703:0x77bb
    36df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36e2:	26 3b 85 28 02       	cmp    ax,WORD PTR es:[di+0x228]
    36e7:	74 0a                	je     0x36f3
    36e9:	06                   	push   es
    36ea:	57                   	push   di
    36eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36ee:	26 ff 9d 88 00       	call   DWORD PTR es:[di+0x88]
    36f3:	c9                   	leave
    36f4:	ca 04 00             	retf   0x4
    36f7:	c8 00 02 00          	enter  0x200,0x0
    36fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36fe:	06                   	push   es
    36ff:	57                   	push   di
    3700:	9a bb 77 80 37       	call   0x3780:0x77bb
    3705:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3708:	26 89 85 28 02       	mov    WORD PTR es:[di+0x228],ax
    370d:	26 8b 85 07 02       	mov    ax,WORD PTR es:[di+0x207]
    3712:	26 0b 85 09 02       	or     ax,WORD PTR es:[di+0x209]
    3717:	74 69                	je     0x3782
    3719:	8d be 00 ff          	lea    di,[bp-0x100]
    371d:	16                   	push   ss
    371e:	57                   	push   di
    371f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3722:	06                   	push   es
    3723:	57                   	push   di
    3724:	9a 00 38 41 37       	call   0x3741:0x3800
    3729:	83 c4 04             	add    sp,0x4
    372c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3731:	75 21                	jne    0x3754
    3733:	8d be 00 fe          	lea    di,[bp-0x200]
    3737:	16                   	push   ss
    3738:	57                   	push   di
    3739:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    373c:	06                   	push   es
    373d:	57                   	push   di
    373e:	9a 3b 33 62 37       	call   0x3762:0x333b
    3743:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3746:	26 c4 bd 07 02       	les    di,DWORD PTR es:[di+0x207]
    374b:	06                   	push   es
    374c:	57                   	push   di
    374d:	9a 8c 1d 71 37       	call   0x3771:0x1d8c
    3752:	eb 1f                	jmp    0x3773
    3754:	8d be 00 fe          	lea    di,[bp-0x200]
    3758:	16                   	push   ss
    3759:	57                   	push   di
    375a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    375d:	06                   	push   es
    375e:	57                   	push   di
    375f:	9a 00 38 ee 37       	call   0x37ee:0x3800
    3764:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3767:	26 c4 bd 07 02       	les    di,DWORD PTR es:[di+0x207]
    376c:	06                   	push   es
    376d:	57                   	push   di
    376e:	9a 8c 1d 73 39       	call   0x3973:0x1d8c
    3773:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3776:	26 c4 bd 07 02       	les    di,DWORD PTR es:[di+0x207]
    377b:	06                   	push   es
    377c:	57                   	push   di
    377d:	9a 3f 4a df 37       	call   0x37df:0x4a3f
    3782:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3785:	26 8b 85 22 02       	mov    ax,WORD PTR es:[di+0x222]
    378a:	09 c0                	or     ax,ax
    378c:	74 15                	je     0x37a3
    378e:	ff 76 08             	push   WORD PTR [bp+0x8]
    3791:	ff 76 06             	push   WORD PTR [bp+0x6]
    3794:	26 ff b5 26 02       	push   WORD PTR es:[di+0x226]
    3799:	26 ff b5 24 02       	push   WORD PTR es:[di+0x224]
    379e:	26 ff 9d 20 02       	call   DWORD PTR es:[di+0x220]
    37a3:	c9                   	leave
    37a4:	ca 04 00             	retf   0x4
    37a7:	55                   	push   bp
    37a8:	89 e5                	mov    bp,sp
    37aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37ad:	26 8a 85 13 02       	mov    al,BYTE PTR es:[di+0x213]
    37b2:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    37b5:	74 45                	je     0x37fc
    37b7:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    37ba:	26 88 85 13 02       	mov    BYTE PTR es:[di+0x213],al
    37bf:	26 80 bd 13 02 01    	cmp    BYTE PTR es:[di+0x213],0x1
    37c5:	75 29                	jne    0x37f0
    37c7:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    37cc:	06                   	push   es
    37cd:	57                   	push   di
    37ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    37d1:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    37d5:	40                   	inc    ax
    37d6:	50                   	push   ax
    37d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37da:	06                   	push   es
    37db:	57                   	push   di
    37dc:	9a 58 78 0c 38       	call   0x380c:0x7858
    37e1:	5a                   	pop    dx
    37e2:	3b c2                	cmp    ax,dx
    37e4:	7d 0a                	jge    0x37f0
    37e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37e9:	06                   	push   es
    37ea:	57                   	push   di
    37eb:	9a 03 3c 88 38       	call   0x3888:0x3c03
    37f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37f3:	06                   	push   es
    37f4:	57                   	push   di
    37f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    37f8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    37fc:	c9                   	leave
    37fd:	ca 06 00             	retf   0x6
    3800:	c8 02 01 00          	enter  0x102,0x0
    3804:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3807:	06                   	push   es
    3808:	57                   	push   di
    3809:	9a bb 77 37 38       	call   0x3837:0x77bb
    380e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3811:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3815:	7c 26                	jl     0x383d
    3817:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    381a:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    381f:	06                   	push   es
    3820:	57                   	push   di
    3821:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3824:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3828:	09 c0                	or     ax,ax
    382a:	74 11                	je     0x383d
    382c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    382f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3832:	06                   	push   es
    3833:	57                   	push   di
    3834:	9a df 78 a0 38       	call   0x38a0:0x78df
    3839:	08 c0                	or     al,al
    383b:	75 09                	jne    0x3846
    383d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3840:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    3844:	eb 27                	jmp    0x386d
    3846:	8d be fe fe          	lea    di,[bp-0x102]
    384a:	16                   	push   ss
    384b:	57                   	push   di
    384c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    384f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3852:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3857:	06                   	push   es
    3858:	57                   	push   di
    3859:	26 c4 3d             	les    di,DWORD PTR es:[di]
    385c:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    3860:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3863:	06                   	push   es
    3864:	57                   	push   di
    3865:	68 ff 00             	push   0xff
    3868:	9a e7 17 17 3b       	call   0x3b17:0x17e7
    386d:	c9                   	leave
    386e:	ca 04 00             	retf   0x4
    3871:	c8 04 02 00          	enter  0x204,0x0
    3875:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3878:	06                   	push   es
    3879:	57                   	push   di
    387a:	8d be fe fe          	lea    di,[bp-0x102]
    387e:	16                   	push   ss
    387f:	57                   	push   di
    3880:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3883:	06                   	push   es
    3884:	57                   	push   di
    3885:	9a 00 38 4a 39       	call   0x394a:0x3800
    388a:	9a ed 07 ea 38       	call   0x38ea:0x7ed
    388f:	09 c0                	or     ax,ax
    3891:	75 03                	jne    0x3896
    3893:	e9 7f 00             	jmp    0x3915
    3896:	6a ff                	push   0xffff
    3898:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    389b:	06                   	push   es
    389c:	57                   	push   di
    389d:	9a e2 77 fb 38       	call   0x38fb:0x77e2
    38a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38a5:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    38aa:	06                   	push   es
    38ab:	57                   	push   di
    38ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    38af:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    38b3:	48                   	dec    ax
    38b4:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    38b8:	31 c0                	xor    ax,ax
    38ba:	3b 86 fc fe          	cmp    ax,WORD PTR [bp-0x104]
    38be:	7f 48                	jg     0x3908
    38c0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    38c3:	eb 03                	jmp    0x38c8
    38c5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    38c8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    38cb:	06                   	push   es
    38cc:	57                   	push   di
    38cd:	8d be fc fd          	lea    di,[bp-0x204]
    38d1:	16                   	push   ss
    38d2:	57                   	push   di
    38d3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    38d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38d9:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    38de:	06                   	push   es
    38df:	57                   	push   di
    38e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    38e3:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    38e7:	9a ed 07 05 3b       	call   0x3b05:0x7ed
    38ec:	09 c0                	or     ax,ax
    38ee:	75 0f                	jne    0x38ff
    38f0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    38f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38f6:	06                   	push   es
    38f7:	57                   	push   di
    38f8:	9a e2 77 57 3c       	call   0x3c57:0x77e2
    38fd:	eb 09                	jmp    0x3908
    38ff:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3902:	3b 86 fc fe          	cmp    ax,WORD PTR [bp-0x104]
    3906:	75 bd                	jne    0x38c5
    3908:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    390b:	06                   	push   es
    390c:	57                   	push   di
    390d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3910:	26 ff 9d 88 00       	call   DWORD PTR es:[di+0x88]
    3915:	c9                   	leave
    3916:	ca 08 00             	retf   0x8
    3919:	c8 00 02 00          	enter  0x200,0x0
    391d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3920:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3923:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3926:	26 89 85 07 02       	mov    WORD PTR es:[di+0x207],ax
    392b:	26 89 95 09 02       	mov    WORD PTR es:[di+0x209],dx
    3930:	26 8b 85 07 02       	mov    ax,WORD PTR es:[di+0x207]
    3935:	26 0b 85 09 02       	or     ax,WORD PTR es:[di+0x209]
    393a:	74 5a                	je     0x3996
    393c:	8d be 00 ff          	lea    di,[bp-0x100]
    3940:	16                   	push   ss
    3941:	57                   	push   di
    3942:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3945:	06                   	push   es
    3946:	57                   	push   di
    3947:	9a 00 38 64 39       	call   0x3964:0x3800
    394c:	83 c4 04             	add    sp,0x4
    394f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3954:	74 21                	je     0x3977
    3956:	8d be 00 fe          	lea    di,[bp-0x200]
    395a:	16                   	push   ss
    395b:	57                   	push   di
    395c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    395f:	06                   	push   es
    3960:	57                   	push   di
    3961:	9a 00 38 85 39       	call   0x3985:0x3800
    3966:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3969:	26 c4 bd 07 02       	les    di,DWORD PTR es:[di+0x207]
    396e:	06                   	push   es
    396f:	57                   	push   di
    3970:	9a 8c 1d 94 39       	call   0x3994:0x1d8c
    3975:	eb 1f                	jmp    0x3996
    3977:	8d be 00 fe          	lea    di,[bp-0x200]
    397b:	16                   	push   ss
    397c:	57                   	push   di
    397d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3980:	06                   	push   es
    3981:	57                   	push   di
    3982:	9a 3b 33 fd 3b       	call   0x3bfd:0x333b
    3987:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    398a:	26 c4 bd 07 02       	les    di,DWORD PTR es:[di+0x207]
    398f:	06                   	push   es
    3990:	57                   	push   di
    3991:	9a 8c 1d f3 3b       	call   0x3bf3:0x1d8c
    3996:	c9                   	leave
    3997:	ca 08 00             	retf   0x8
    399a:	c8 12 01 00          	enter  0x112,0x0
    399e:	8c d3                	mov    bx,ss
    39a0:	8e c3                	mov    es,bx
    39a2:	8c db                	mov    bx,ds
    39a4:	fc                   	cld
    39a5:	8d 7e f8             	lea    di,[bp-0x8]
    39a8:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    39ab:	b9 08 00             	mov    cx,0x8
    39ae:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    39b0:	8e db                	mov    ds,bx
    39b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39b5:	26 c4 bd dd 00       	les    di,DWORD PTR es:[di+0xdd]
    39ba:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    39bd:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    39c0:	8d 7e f8             	lea    di,[bp-0x8]
    39c3:	16                   	push   ss
    39c4:	57                   	push   di
    39c5:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    39c8:	06                   	push   es
    39c9:	57                   	push   di
    39ca:	9a e5 1c 94 3a       	call   0x3a94:0x1ce5
    39cf:	c7 46 f2 02 00       	mov    WORD PTR [bp-0xe],0x2
    39d4:	ff 76 10             	push   WORD PTR [bp+0x10]
    39d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39da:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    39df:	06                   	push   es
    39e0:	57                   	push   di
    39e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39e4:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    39e8:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    39eb:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    39ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39f1:	26 80 bd 13 02 01    	cmp    BYTE PTR es:[di+0x213],0x1
    39f7:	74 03                	je     0x39fc
    39f9:	e9 c3 00             	jmp    0x3abf
    39fc:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    39ff:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    3a02:	75 03                	jne    0x3a07
    3a04:	e9 b8 00             	jmp    0x3abf
    3a07:	8d 7e e6             	lea    di,[bp-0x1a]
    3a0a:	16                   	push   ss
    3a0b:	57                   	push   di
    3a0c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3a0f:	40                   	inc    ax
    3a10:	40                   	inc    ax
    3a11:	50                   	push   ax
    3a12:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a15:	06                   	push   es
    3a16:	57                   	push   di
    3a17:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a1a:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    3a1e:	8b d0                	mov    dx,ax
    3a20:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3a23:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    3a26:	2b c2                	sub    ax,dx
    3a28:	99                   	cwd
    3a29:	b9 02 00             	mov    cx,0x2
    3a2c:	f7 f9                	idiv   cx
    3a2e:	50                   	push   ax
    3a2f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a32:	06                   	push   es
    3a33:	57                   	push   di
    3a34:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a37:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    3a3b:	50                   	push   ax
    3a3c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a3f:	06                   	push   es
    3a40:	57                   	push   di
    3a41:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a44:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    3a48:	50                   	push   ax
    3a49:	9a ae 06 7a 3a       	call   0x3a7a:0x6ae
    3a4e:	ff 76 f6             	push   WORD PTR [bp-0xa]
    3a51:	ff 76 f4             	push   WORD PTR [bp-0xc]
    3a54:	8d 7e de             	lea    di,[bp-0x22]
    3a57:	16                   	push   ss
    3a58:	57                   	push   di
    3a59:	6a 00                	push   0x0
    3a5b:	6a 00                	push   0x0
    3a5d:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a60:	06                   	push   es
    3a61:	57                   	push   di
    3a62:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a65:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    3a69:	50                   	push   ax
    3a6a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a6d:	06                   	push   es
    3a6e:	57                   	push   di
    3a6f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a72:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    3a76:	50                   	push   ax
    3a77:	9a ae 06 ff ff       	call   0xffff:0x6ae
    3a7c:	6a 00                	push   0x0
    3a7e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a81:	06                   	push   es
    3a82:	57                   	push   di
    3a83:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a86:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    3a8a:	48                   	dec    ax
    3a8b:	50                   	push   ax
    3a8c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a8f:	06                   	push   es
    3a90:	57                   	push   di
    3a91:	9a 0f 5a 9f 3a       	call   0x3a9f:0x5a0f
    3a96:	89 c7                	mov    di,ax
    3a98:	8e c2                	mov    es,dx
    3a9a:	06                   	push   es
    3a9b:	57                   	push   di
    3a9c:	9a 32 21 ab 3a       	call   0x3aab:0x2132
    3aa1:	52                   	push   dx
    3aa2:	50                   	push   ax
    3aa3:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    3aa6:	06                   	push   es
    3aa7:	57                   	push   di
    3aa8:	9a 23 19 eb 3a       	call   0x3aeb:0x1923
    3aad:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3ab0:	06                   	push   es
    3ab1:	57                   	push   di
    3ab2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ab5:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    3ab9:	05 06 00             	add    ax,0x6
    3abc:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3abf:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3ac2:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    3ac5:	50                   	push   ax
    3ac6:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3ac9:	8d be ee fe          	lea    di,[bp-0x112]
    3acd:	16                   	push   ss
    3ace:	57                   	push   di
    3acf:	ff 76 10             	push   WORD PTR [bp+0x10]
    3ad2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ad5:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    3ada:	06                   	push   es
    3adb:	57                   	push   di
    3adc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3adf:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    3ae3:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    3ae6:	06                   	push   es
    3ae7:	57                   	push   di
    3ae8:	9a 09 1f ff ff       	call   0xffff:0x1f09
    3aed:	c9                   	leave
    3aee:	ca 0c 00             	retf   0xc
    3af1:	55                   	push   bp
    3af2:	89 e5                	mov    bp,sp
    3af4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3af7:	06                   	push   es
    3af8:	57                   	push   di
    3af9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3afc:	81 c7 02 01          	add    di,0x102
    3b00:	06                   	push   es
    3b01:	57                   	push   di
    3b02:	9a ed 07 91 3b       	call   0x3b91:0x7ed
    3b07:	09 c0                	or     ax,ax
    3b09:	74 42                	je     0x3b4d
    3b0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b0e:	81 c7 02 01          	add    di,0x102
    3b12:	06                   	push   es
    3b13:	57                   	push   di
    3b14:	9a b2 0e 1c 3b       	call   0x3b1c:0xeb2
    3b19:	9a 08 04 26 3b       	call   0x3b26:0x408
    3b1e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3b21:	06                   	push   es
    3b22:	57                   	push   di
    3b23:	9a b2 0e 2b 3b       	call   0x3b2b:0xeb2
    3b28:	9a 08 04 3e 3b       	call   0x3b3e:0x408
    3b2d:	6a 00                	push   0x0
    3b2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b32:	81 c7 02 01          	add    di,0x102
    3b36:	06                   	push   es
    3b37:	57                   	push   di
    3b38:	68 ff 00             	push   0xff
    3b3b:	9a 58 0e 9b 3b       	call   0x3b9b:0xe58
    3b40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b43:	06                   	push   es
    3b44:	57                   	push   di
    3b45:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b48:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    3b4d:	c9                   	leave
    3b4e:	ca 08 00             	retf   0x8
    3b51:	55                   	push   bp
    3b52:	89 e5                	mov    bp,sp
    3b54:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3b57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b5a:	26 3a 85 06 02       	cmp    al,BYTE PTR es:[di+0x206]
    3b5f:	74 12                	je     0x3b73
    3b61:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3b64:	26 88 85 06 02       	mov    BYTE PTR es:[di+0x206],al
    3b69:	06                   	push   es
    3b6a:	57                   	push   di
    3b6b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b6e:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    3b73:	c9                   	leave
    3b74:	ca 06 00             	retf   0x6
    3b77:	c8 80 01 00          	enter  0x180,0x0
    3b7b:	8d be 80 fe          	lea    di,[bp-0x180]
    3b7f:	16                   	push   ss
    3b80:	57                   	push   di
    3b81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b84:	26 ff b5 04 02       	push   WORD PTR es:[di+0x204]
    3b89:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    3b8e:	9a 6e 0e af 3b       	call   0x3baf:0xe6e
    3b93:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3b96:	06                   	push   es
    3b97:	57                   	push   di
    3b98:	9a be 18 29 3d       	call   0x3d29:0x18be
    3b9d:	74 3f                	je     0x3bde
    3b9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ba2:	26 ff b5 04 02       	push   WORD PTR es:[di+0x204]
    3ba7:	26 ff b5 02 02       	push   WORD PTR es:[di+0x202]
    3bac:	9a 23 0f be 3b       	call   0x3bbe:0xf23
    3bb1:	8d 7e 80             	lea    di,[bp-0x80]
    3bb4:	16                   	push   ss
    3bb5:	57                   	push   di
    3bb6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3bb9:	06                   	push   es
    3bba:	57                   	push   di
    3bbb:	9a 4c 0d c5 3b       	call   0x3bc5:0xd4c
    3bc0:	52                   	push   dx
    3bc1:	50                   	push   ax
    3bc2:	9a d6 0e 86 3c       	call   0x3c86:0xed6
    3bc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bca:	26 89 85 02 02       	mov    WORD PTR es:[di+0x202],ax
    3bcf:	26 89 95 04 02       	mov    WORD PTR es:[di+0x204],dx
    3bd4:	06                   	push   es
    3bd5:	57                   	push   di
    3bd6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bd9:	26 ff 9d 8c 00       	call   DWORD PTR es:[di+0x8c]
    3bde:	c9                   	leave
    3bdf:	ca 08 00             	retf   0x8
    3be2:	55                   	push   bp
    3be3:	89 e5                	mov    bp,sp
    3be5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3be8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3beb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bee:	06                   	push   es
    3bef:	57                   	push   di
    3bf0:	9a 3a 57 0c 3e       	call   0x3e0c:0x573a
    3bf5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bf8:	06                   	push   es
    3bf9:	57                   	push   di
    3bfa:	9a 03 3c bb 3c       	call   0x3cbb:0x3c03
    3bff:	c9                   	leave
    3c00:	ca 08 00             	retf   0x8
    3c03:	c8 02 00 00          	enter  0x2,0x0
    3c07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c0a:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    3c0e:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3c12:	e8 bf dd             	call   0x19d4
    3c15:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3c18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c1b:	26 80 bd 13 02 01    	cmp    BYTE PTR es:[di+0x213],0x1
    3c21:	75 29                	jne    0x3c4c
    3c23:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    3c28:	06                   	push   es
    3c29:	57                   	push   di
    3c2a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c2d:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    3c31:	40                   	inc    ax
    3c32:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    3c35:	7e 15                	jle    0x3c4c
    3c37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c3a:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    3c3f:	06                   	push   es
    3c40:	57                   	push   di
    3c41:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c44:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    3c48:	40                   	inc    ax
    3c49:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3c4c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3c4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c52:	06                   	push   es
    3c53:	57                   	push   di
    3c54:	9a 93 78 ff ff       	call   0xffff:0x7893
    3c59:	c9                   	leave
    3c5a:	ca 04 00             	retf   0x4
    3c5d:	05 25 73             	add    ax,0x7325
    3c60:	3a 25                	cmp    ah,BYTE PTR [di]
    3c62:	73 01                	jae    0x3c65
    3c64:	2a 01                	sub    al,BYTE PTR [bx+di]
    3c66:	3f                   	aas
    3c67:	c8 12 03 00          	enter  0x312,0x0
    3c6b:	8d be fe fc          	lea    di,[bp-0x302]
    3c6f:	16                   	push   ss
    3c70:	57                   	push   di
    3c71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c74:	06                   	push   es
    3c75:	57                   	push   di
    3c76:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c79:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    3c7e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c81:	06                   	push   es
    3c82:	57                   	push   di
    3c83:	9a ed 07 1b 3d       	call   0x3d1b:0x7ed
    3c88:	09 c0                	or     ax,ax
    3c8a:	75 03                	jne    0x3c8f
    3c8c:	e9 8d 01             	jmp    0x3e1c
    3c8f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c92:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    3c96:	75 03                	jne    0x3c9b
    3c98:	e9 81 01             	jmp    0x3e1c
    3c9b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3c9e:	06                   	push   es
    3c9f:	57                   	push   di
    3ca0:	8d be ff fd          	lea    di,[bp-0x201]
    3ca4:	16                   	push   ss
    3ca5:	57                   	push   di
    3ca6:	8d be 00 ff          	lea    di,[bp-0x100]
    3caa:	16                   	push   ss
    3cab:	57                   	push   di
    3cac:	68 ff 00             	push   0xff
    3caf:	8d be 00 fe          	lea    di,[bp-0x200]
    3cb3:	16                   	push   ss
    3cb4:	57                   	push   di
    3cb5:	68 ff 00             	push   0xff
    3cb8:	9a eb 16 39 3d       	call   0x3d39:0x16eb
    3cbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cc0:	26 8b 85 0b 02       	mov    ax,WORD PTR es:[di+0x20b]
    3cc5:	26 0b 85 0d 02       	or     ax,WORD PTR es:[di+0x20d]
    3cca:	74 19                	je     0x3ce5
    3ccc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3ccf:	06                   	push   es
    3cd0:	57                   	push   di
    3cd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cd4:	26 c4 bd 0b 02       	les    di,DWORD PTR es:[di+0x20b]
    3cd9:	06                   	push   es
    3cda:	57                   	push   di
    3cdb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cde:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    3ce3:	eb 56                	jmp    0x3d3b
    3ce5:	8d be ee fc          	lea    di,[bp-0x312]
    3ce9:	16                   	push   ss
    3cea:	57                   	push   di
    3ceb:	bf 5d 3c             	mov    di,0x3c5d
    3cee:	0e                   	push   cs
    3cef:	57                   	push   di
    3cf0:	8a 86 ff fd          	mov    al,BYTE PTR [bp-0x201]
    3cf4:	88 86 ee fd          	mov    BYTE PTR [bp-0x212],al
    3cf8:	c6 86 f2 fd 02       	mov    BYTE PTR [bp-0x20e],0x2
    3cfd:	8d 86 00 ff          	lea    ax,[bp-0x100]
    3d01:	8c d2                	mov    dx,ss
    3d03:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    3d07:	89 96 f8 fd          	mov    WORD PTR [bp-0x208],dx
    3d0b:	c6 86 fa fd 04       	mov    BYTE PTR [bp-0x206],0x4
    3d10:	8d be ee fd          	lea    di,[bp-0x212]
    3d14:	16                   	push   ss
    3d15:	57                   	push   di
    3d16:	6a 01                	push   0x1
    3d18:	9a 34 10 99 3d       	call   0x3d99:0x1034
    3d1d:	8d be 00 ff          	lea    di,[bp-0x100]
    3d21:	16                   	push   ss
    3d22:	57                   	push   di
    3d23:	68 ff 00             	push   0xff
    3d26:	9a e7 17 49 3d       	call   0x3d49:0x17e7
    3d2b:	8d be 00 ff          	lea    di,[bp-0x100]
    3d2f:	16                   	push   ss
    3d30:	57                   	push   di
    3d31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d34:	06                   	push   es
    3d35:	57                   	push   di
    3d36:	9a f1 3a 71 3d       	call   0x3d71:0x3af1
    3d3b:	bf 63 3c             	mov    di,0x3c63
    3d3e:	0e                   	push   cs
    3d3f:	57                   	push   di
    3d40:	8d be 00 fe          	lea    di,[bp-0x200]
    3d44:	16                   	push   ss
    3d45:	57                   	push   di
    3d46:	9a 78 18 5d 3d       	call   0x3d5d:0x1878
    3d4b:	09 c0                	or     ax,ax
    3d4d:	7f 14                	jg     0x3d63
    3d4f:	bf 65 3c             	mov    di,0x3c65
    3d52:	0e                   	push   cs
    3d53:	57                   	push   di
    3d54:	8d be 00 fe          	lea    di,[bp-0x200]
    3d58:	16                   	push   ss
    3d59:	57                   	push   di
    3d5a:	9a 78 18 1a 3e       	call   0x3e1a:0x1878
    3d5f:	09 c0                	or     ax,ax
    3d61:	7e 13                	jle    0x3d76
    3d63:	8d be 00 fe          	lea    di,[bp-0x200]
    3d67:	16                   	push   ss
    3d68:	57                   	push   di
    3d69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d6c:	06                   	push   es
    3d6d:	57                   	push   di
    3d6e:	9a 77 3b 8e 3d       	call   0x3d8e:0x3b77
    3d73:	e9 a6 00             	jmp    0x3e1c
    3d76:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3d7b:	77 03                	ja     0x3d80
    3d7d:	e9 9c 00             	jmp    0x3e1c
    3d80:	8d be 00 fe          	lea    di,[bp-0x200]
    3d84:	16                   	push   ss
    3d85:	57                   	push   di
    3d86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d89:	06                   	push   es
    3d8a:	57                   	push   di
    3d8b:	9a 71 38 ad 3d       	call   0x3dad:0x3871
    3d90:	8d be 00 fe          	lea    di,[bp-0x200]
    3d94:	16                   	push   ss
    3d95:	57                   	push   di
    3d96:	9a 26 0a 03 3e       	call   0x3e03:0xa26
    3d9b:	08 c0                	or     al,al
    3d9d:	74 3c                	je     0x3ddb
    3d9f:	8d be fe fc          	lea    di,[bp-0x302]
    3da3:	16                   	push   ss
    3da4:	57                   	push   di
    3da5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3da8:	06                   	push   es
    3da9:	57                   	push   di
    3daa:	9a 00 38 c7 3d       	call   0x3dc7:0x3800
    3daf:	83 c4 04             	add    sp,0x4
    3db2:	80 be fe fc 00       	cmp    BYTE PTR [bp-0x302],0x0
    3db7:	75 20                	jne    0x3dd9
    3db9:	8d be 00 fe          	lea    di,[bp-0x200]
    3dbd:	16                   	push   ss
    3dbe:	57                   	push   di
    3dbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dc2:	06                   	push   es
    3dc3:	57                   	push   di
    3dc4:	9a 77 3b d7 3d       	call   0x3dd7:0x3b77
    3dc9:	8d be 00 fe          	lea    di,[bp-0x200]
    3dcd:	16                   	push   ss
    3dce:	57                   	push   di
    3dcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dd2:	06                   	push   es
    3dd3:	57                   	push   di
    3dd4:	9a 71 38 44 3e       	call   0x3e44:0x3871
    3dd9:	eb 41                	jmp    0x3e1c
    3ddb:	8d be f6 fc          	lea    di,[bp-0x30a]
    3ddf:	16                   	push   ss
    3de0:	57                   	push   di
    3de1:	68 99 f0             	push   0xf099
    3de4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3de7:	89 f8                	mov    ax,di
    3de9:	8c c2                	mov    dx,es
    3deb:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    3def:	89 96 f8 fd          	mov    WORD PTR [bp-0x208],dx
    3df3:	c6 86 fa fd 04       	mov    BYTE PTR [bp-0x206],0x4
    3df8:	8d be f6 fd          	lea    di,[bp-0x20a]
    3dfc:	16                   	push   ss
    3dfd:	57                   	push   di
    3dfe:	6a 00                	push   0x0
    3e00:	9a 50 09 13 3e       	call   0x3e13:0x950
    3e05:	b0 01                	mov    al,0x1
    3e07:	50                   	push   ax
    3e08:	b8 52 00             	mov    ax,0x52
    3e0b:	ba 46 3f             	mov    dx,0x3f46
    3e0e:	52                   	push   dx
    3e0f:	50                   	push   ax
    3e10:	9a e6 28 ba 3e       	call   0x3eba:0x28e6
    3e15:	52                   	push   dx
    3e16:	50                   	push   ax
    3e17:	9a 99 13 c7 3e       	call   0x3ec7:0x1399
    3e1c:	c9                   	leave
    3e1d:	ca 08 00             	retf   0x8
    3e20:	04 25                	add    al,0x25
    3e22:	73 25                	jae    0x3e49
    3e24:	73 05                	jae    0x3e2b
    3e26:	25 73 5c             	and    ax,0x5c73
    3e29:	25 73 c8             	and    ax,0xc873
    3e2c:	10 03                	adc    BYTE PTR [bp+di],al
    3e2e:	00 c4                	add    ah,al
    3e30:	7e 0a                	jle    0x3e3c
    3e32:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    3e36:	8d be 00 ff          	lea    di,[bp-0x100]
    3e3a:	16                   	push   ss
    3e3b:	57                   	push   di
    3e3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e3f:	06                   	push   es
    3e40:	57                   	push   di
    3e41:	9a 00 38 97 3e       	call   0x3e97:0x3800
    3e46:	83 c4 04             	add    sp,0x4
    3e49:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3e4e:	75 03                	jne    0x3e53
    3e50:	e9 da 00             	jmp    0x3f2d
    3e53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e56:	26 8a 85 02 01       	mov    al,BYTE PTR es:[di+0x102]
    3e5b:	30 e4                	xor    ah,ah
    3e5d:	03 f8                	add    di,ax
    3e5f:	26 80 bd 02 01 5c    	cmp    BYTE PTR es:[di+0x102],0x5c
    3e65:	75 64                	jne    0x3ecb
    3e67:	8d be f0 fc          	lea    di,[bp-0x310]
    3e6b:	16                   	push   ss
    3e6c:	57                   	push   di
    3e6d:	bf 20 3e             	mov    di,0x3e20
    3e70:	0e                   	push   cs
    3e71:	57                   	push   di
    3e72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e75:	26 8d 85 02 01       	lea    ax,es:[di+0x102]
    3e7a:	8c c2                	mov    dx,es
    3e7c:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    3e80:	89 96 f2 fd          	mov    WORD PTR [bp-0x20e],dx
    3e84:	c6 86 f4 fd 04       	mov    BYTE PTR [bp-0x20c],0x4
    3e89:	8d be 00 fe          	lea    di,[bp-0x200]
    3e8d:	16                   	push   ss
    3e8e:	57                   	push   di
    3e8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e92:	06                   	push   es
    3e93:	57                   	push   di
    3e94:	9a 00 38 fb 3e       	call   0x3efb:0x3800
    3e99:	83 c4 04             	add    sp,0x4
    3e9c:	8d 86 00 fe          	lea    ax,[bp-0x200]
    3ea0:	8c d2                	mov    dx,ss
    3ea2:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    3ea6:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    3eaa:	c6 86 fc fd 04       	mov    BYTE PTR [bp-0x204],0x4
    3eaf:	8d be f0 fd          	lea    di,[bp-0x210]
    3eb3:	16                   	push   ss
    3eb4:	57                   	push   di
    3eb5:	6a 01                	push   0x1
    3eb7:	9a 34 10 1e 3f       	call   0x3f1e:0x1034
    3ebc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3ebf:	06                   	push   es
    3ec0:	57                   	push   di
    3ec1:	68 ff 00             	push   0xff
    3ec4:	9a e7 17 2b 3f       	call   0x3f2b:0x17e7
    3ec9:	eb 62                	jmp    0x3f2d
    3ecb:	8d be f0 fc          	lea    di,[bp-0x310]
    3ecf:	16                   	push   ss
    3ed0:	57                   	push   di
    3ed1:	bf 25 3e             	mov    di,0x3e25
    3ed4:	0e                   	push   cs
    3ed5:	57                   	push   di
    3ed6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ed9:	26 8d 85 02 01       	lea    ax,es:[di+0x102]
    3ede:	8c c2                	mov    dx,es
    3ee0:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    3ee4:	89 96 f2 fd          	mov    WORD PTR [bp-0x20e],dx
    3ee8:	c6 86 f4 fd 04       	mov    BYTE PTR [bp-0x20c],0x4
    3eed:	8d be 00 fe          	lea    di,[bp-0x200]
    3ef1:	16                   	push   ss
    3ef2:	57                   	push   di
    3ef3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ef6:	06                   	push   es
    3ef7:	57                   	push   di
    3ef8:	9a 00 38 ff ff       	call   0xffff:0x3800
    3efd:	83 c4 04             	add    sp,0x4
    3f00:	8d 86 00 fe          	lea    ax,[bp-0x200]
    3f04:	8c d2                	mov    dx,ss
    3f06:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    3f0a:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    3f0e:	c6 86 fc fd 04       	mov    BYTE PTR [bp-0x204],0x4
    3f13:	8d be f0 fd          	lea    di,[bp-0x210]
    3f17:	16                   	push   ss
    3f18:	57                   	push   di
    3f19:	6a 01                	push   0x1
    3f1b:	9a 34 10 ff ff       	call   0xffff:0x1034
    3f20:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f23:	06                   	push   es
    3f24:	57                   	push   di
    3f25:	68 ff 00             	push   0xff
    3f28:	9a e7 17 ff ff       	call   0xffff:0x17e7
    3f2d:	c9                   	leave
    3f2e:	ca 04 00             	retf   0x4
    3f31:	55                   	push   bp
    3f32:	89 e5                	mov    bp,sp
    3f34:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3f37:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3f3a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    3f3d:	50                   	push   ax
    3f3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f41:	06                   	push   es
    3f42:	57                   	push   di
    3f43:	9a 32 16 ff ff       	call   0xffff:0x1632
    3f48:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    3f4c:	75 6d                	jne    0x3fbb
    3f4e:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    3f51:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    3f54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f57:	26 3b 95 09 02       	cmp    dx,WORD PTR es:[di+0x209]
    3f5c:	75 15                	jne    0x3f73
    3f5e:	26 3b 85 07 02       	cmp    ax,WORD PTR es:[di+0x207]
    3f63:	75 0e                	jne    0x3f73
    3f65:	31 c0                	xor    ax,ax
    3f67:	26 89 85 07 02       	mov    WORD PTR es:[di+0x207],ax
    3f6c:	26 89 85 09 02       	mov    WORD PTR es:[di+0x209],ax
    3f71:	eb 48                	jmp    0x3fbb
    3f73:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    3f76:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    3f79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f7c:	26 3b 95 0d 02       	cmp    dx,WORD PTR es:[di+0x20d]
    3f81:	75 15                	jne    0x3f98
    3f83:	26 3b 85 0b 02       	cmp    ax,WORD PTR es:[di+0x20b]
    3f88:	75 0e                	jne    0x3f98
    3f8a:	31 c0                	xor    ax,ax
    3f8c:	26 89 85 0b 02       	mov    WORD PTR es:[di+0x20b],ax
    3f91:	26 89 85 0d 02       	mov    WORD PTR es:[di+0x20d],ax
    3f96:	eb 23                	jmp    0x3fbb
    3f98:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    3f9b:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    3f9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fa1:	26 3b 95 11 02       	cmp    dx,WORD PTR es:[di+0x211]
    3fa6:	75 13                	jne    0x3fbb
    3fa8:	26 3b 85 0f 02       	cmp    ax,WORD PTR es:[di+0x20f]
    3fad:	75 0c                	jne    0x3fbb
    3faf:	31 c0                	xor    ax,ax
    3fb1:	26 89 85 0f 02       	mov    WORD PTR es:[di+0x20f],ax
    3fb6:	26 89 85 11 02       	mov    WORD PTR es:[di+0x211],ax
    3fbb:	c9                   	leave
    3fbc:	ca                   	.byte 0xca
    3fbd:	0a                   	.byte 0xa
