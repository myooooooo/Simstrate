; ================================================================
; seg06_CODE  (16245 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	06                   	push   es
       1:	00 3d                	add    BYTE PTR [di],bh
       3:	0d 70 03             	or     ax,0x370
       6:	b4 00                	mov    ah,0x0
       8:	00 00                	add    BYTE PTR [bx+si],al
       a:	9e                   	sahf
       b:	00 a4 03 fb          	add    BYTE PTR [si-0x4fd],ah
       f:	04 5a                	add    al,0x5a
      11:	0d 39 3f             	or     ax,0x3f39
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 74 0d cb       	call   0xcb0d:0x741f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 ac 26 d6          	adc    BYTE PTR [si-0x29da],ch
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 38                	sbb    al,0x38
      61:	17                   	pop    ss
      62:	e2 2f                	loop   0x93
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	15 54 46             	adc    ax,0x4654
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	4a                   	dec    dx
      a6:	53                   	push   bx
      a7:	49                   	dec    cx
      a8:	5f                   	pop    di
      a9:	44                   	inc    sp
      aa:	6c                   	ins    BYTE PTR es:[di],dx
      ab:	67 49                	addr32 dec cx
      ad:	6d                   	ins    WORD PTR es:[di],dx
      ae:	70 72                	jo     0x122
      b0:	69 6d 65 72 20       	imul   bp,WORD PTR [di+0x65],0x2072
      b5:	00 c5                	add    ch,al
      b7:	2f                   	das
      b8:	c9                   	leave
      b9:	00 0c                	add    BYTE PTR [si],cl
      bb:	48                   	dec    ax
      bc:	65 6c                	gs ins BYTE PTR es:[di],dx
      be:	70 42                	jo     0x102
      c0:	74 6e                	je     0x130
      c2:	43                   	inc    bx
      c3:	6c                   	ins    BYTE PTR es:[di],dx
      c4:	69 63 6b 28 30       	imul   sp,WORD PTR [bp+di+0x6b],0x3028
      c9:	de 00                	fiadd  WORD PTR [bx+si]
      cb:	10 49 6d             	adc    BYTE PTR [bx+di+0x6d],cl
      ce:	70 72                	jo     0x142
      d0:	69 6d 65 72 42       	imul   bp,WORD PTR [di+0x65],0x4272
      d5:	74 6e                	je     0x145
      d7:	43                   	inc    bx
      d8:	6c                   	ins    BYTE PTR es:[di],dx
      d9:	69 63 6b 15 38       	imul   sp,WORD PTR [bp+di+0x6b],0x3815
      de:	ef                   	out    dx,ax
      df:	00 0c                	add    BYTE PTR [si],cl
      e1:	54                   	push   sp
      e2:	65 73 74             	gs jae 0x159
      e5:	42                   	inc    dx
      e6:	74 6e                	je     0x156
      e8:	43                   	inc    bx
      e9:	6c                   	ins    BYTE PTR es:[di],dx
      ea:	69 63 6b 14 28       	imul   sp,WORD PTR [bp+di+0x6b],0x2814
      ef:	fd                   	std
      f0:	00 09                	add    BYTE PTR [bx+di],cl
      f2:	46                   	inc    si
      f3:	6f                   	outs   dx,WORD PTR ds:[si]
      f4:	72 6d                	jb     0x163
      f6:	43                   	inc    bx
      f7:	6c                   	ins    BYTE PTR es:[di],dx
      f8:	6f                   	outs   dx,WORD PTR ds:[si]
      f9:	73 65                	jae    0x160
      fb:	35 28 10             	xor    ax,0x1028
      fe:	01 0e 46 6f          	add    WORD PTR ds:0x6f46,cx
     102:	72 6d                	jb     0x171
     104:	43                   	inc    bx
     105:	6c                   	ins    BYTE PTR es:[di],dx
     106:	6f                   	outs   dx,WORD PTR ds:[si]
     107:	73 65                	jae    0x16e
     109:	51                   	push   cx
     10a:	75 65                	jne    0x171
     10c:	72 79                	jb     0x187
     10e:	a8 37                	test   al,0x37
     110:	2a 01                	sub    al,BYTE PTR [bx+di]
     112:	15 54 61             	adc    ax,0x6154
     115:	62 62 65             	bound  sp,DWORD PTR [bp+si+0x65]
     118:	64 4e                	fs dec si
     11a:	6f                   	outs   dx,WORD PTR ds:[si]
     11b:	74 65                	je     0x182
     11d:	62 6f 6f             	bound  bp,DWORD PTR [bx+0x6f]
     120:	6b 31 43             	imul   si,WORD PTR [bx+di],0x43
     123:	68 61 6e             	push   0x6e61
     126:	67 65 e1 27          	addr32 gs loope 0x151
     12a:	37                   	aaa
     12b:	01 08                	add    WORD PTR [bx+si],cx
     12d:	46                   	inc    si
     12e:	6f                   	outs   dx,WORD PTR ds:[si]
     12f:	72 6d                	jb     0x19e
     131:	53                   	push   bx
     132:	68 6f 77             	push   0x776f
     135:	ed                   	in     ax,dx
     136:	22 4c 01             	and    cl,BYTE PTR [si+0x1]
     139:	10 43 68             	adc    BYTE PTR [bp+di+0x68],al
     13c:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     140:	6f                   	outs   dx,WORD PTR ds:[si]
     141:	78 45                	js     0x188
     143:	31 44 43             	xor    WORD PTR [si+0x43],ax
     146:	6c                   	ins    BYTE PTR es:[di],dx
     147:	69 63 6b c7 23       	imul   sp,WORD PTR [bp+di+0x6b],0x23c7
     14c:	65 01 14             	add    WORD PTR gs:[si],dx
     14f:	43                   	inc    bx
     150:	68 65 63             	push   0x6365
     153:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     157:	45                   	inc    bp
     158:	31 52 54             	xor    WORD PTR [bp+si+0x54],dx
     15b:	6f                   	outs   dx,WORD PTR ds:[si]
     15c:	75 73                	jne    0x1d1
     15e:	43                   	inc    bx
     15f:	6c                   	ins    BYTE PTR es:[di],dx
     160:	69 63 6b 47 22       	imul   sp,WORD PTR [bp+di+0x6b],0x2247
     165:	79 01                	jns    0x168
     167:	0f 43 68 65          	cmovae bp,WORD PTR [bx+si+0x65]
     16b:	63 6b 42             	arpl   WORD PTR [bp+di+0x42],bp
     16e:	6f                   	outs   dx,WORD PTR ds:[si]
     16f:	78 41                	js     0x1b2
     171:	44                   	inc    sp
     172:	43                   	inc    bx
     173:	6c                   	ins    BYTE PTR es:[di],dx
     174:	69 63 6b 08 17       	imul   sp,WORD PTR [bp+di+0x6b],0x1708
     179:	8e 01                	mov    es,WORD PTR [bx+di]
     17b:	10 43 68             	adc    BYTE PTR [bp+di+0x68],al
     17e:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     182:	6f                   	outs   dx,WORD PTR ds:[si]
     183:	78 47                	js     0x1cc
     185:	41                   	inc    cx
     186:	44                   	inc    sp
     187:	43                   	inc    bx
     188:	6c                   	ins    BYTE PTR es:[di],dx
     189:	69 63 6b 5b 17       	imul   sp,WORD PTR [bp+di+0x6b],0x175b
     18e:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
     18f:	01 14                	add    WORD PTR [si],dx
     191:	43                   	inc    bx
     192:	68 65 63             	push   0x6365
     195:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     199:	47                   	inc    di
     19a:	41                   	inc    cx
     19b:	52                   	push   dx
     19c:	54                   	push   sp
     19d:	6f                   	outs   dx,WORD PTR ds:[si]
     19e:	75 73                	jne    0x213
     1a0:	43                   	inc    bx
     1a1:	6c                   	ins    BYTE PTR es:[di],dx
     1a2:	69 63 6b b6 17       	imul   sp,WORD PTR [bp+di+0x6b],0x17b6
     1a7:	bc 01 10             	mov    sp,0x1001
     1aa:	43                   	inc    bx
     1ab:	68 65 63             	push   0x6365
     1ae:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     1b2:	47                   	inc    di
     1b3:	45                   	inc    bp
     1b4:	44                   	inc    sp
     1b5:	43                   	inc    bx
     1b6:	6c                   	ins    BYTE PTR es:[di],dx
     1b7:	69 63 6b cc 19       	imul   sp,WORD PTR [bp+di+0x6b],0x19cc
     1bc:	d5 01                	aad    0x1
     1be:	14 43                	adc    al,0x43
     1c0:	68 65 63             	push   0x6365
     1c3:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     1c7:	47                   	inc    di
     1c8:	45                   	inc    bp
     1c9:	52                   	push   dx
     1ca:	54                   	push   sp
     1cb:	6f                   	outs   dx,WORD PTR ds:[si]
     1cc:	75 73                	jne    0x241
     1ce:	43                   	inc    bx
     1cf:	6c                   	ins    BYTE PTR es:[di],dx
     1d0:	69 63 6b c0 18       	imul   sp,WORD PTR [bp+di+0x6b],0x18c0
     1d5:	ea 01 10 43 68       	jmp    0x6843:0x1001
     1da:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     1de:	6f                   	outs   dx,WORD PTR ds:[si]
     1df:	78 47                	js     0x228
     1e1:	45                   	inc    bp
     1e2:	45                   	inc    bp
     1e3:	43                   	inc    bx
     1e4:	6c                   	ins    BYTE PTR es:[di],dx
     1e5:	69 63 6b b9 1b       	imul   sp,WORD PTR [bp+di+0x6b],0x1bb9
     1ea:	08 02                	or     BYTE PTR [bp+si],al
     1ec:	19 43 68             	sbb    WORD PTR [bp+di+0x68],ax
     1ef:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     1f3:	6f                   	outs   dx,WORD PTR ds:[si]
     1f4:	78 47                	js     0x23d
     1f6:	45                   	inc    bp
     1f7:	52                   	push   dx
     1f8:	53                   	push   bx
     1f9:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     1fe:	69 6f 6e 43 6c       	imul   bp,WORD PTR [bx+0x6e],0x6c43
     203:	69 63 6b d2 1c       	imul   sp,WORD PTR [bp+di+0x6b],0x1cd2
     208:	23 02                	and    ax,WORD PTR [bp+si]
     20a:	16                   	push   ss
     20b:	43                   	inc    bx
     20c:	68 65 63             	push   0x6365
     20f:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     213:	47                   	inc    di
     214:	45                   	inc    bp
     215:	52                   	push   dx
     216:	43                   	inc    bx
     217:	6f                   	outs   dx,WORD PTR ds:[si]
     218:	6d                   	ins    WORD PTR es:[di],dx
     219:	70 74                	jo     0x28f
     21b:	65 43                	gs inc bx
     21d:	6c                   	ins    BYTE PTR es:[di],dx
     21e:	69 63 6b eb 1d       	imul   sp,WORD PTR [bp+di+0x6b],0x1deb
     223:	3d 02 15             	cmp    ax,0x1502
     226:	43                   	inc    bx
     227:	68 65 63             	push   0x6365
     22a:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     22e:	47                   	inc    di
     22f:	45                   	inc    bp
     230:	52                   	push   dx
     231:	42                   	inc    dx
     232:	69 6c 61 6e 43       	imul   bp,WORD PTR [si+0x61],0x436e
     237:	6c                   	ins    BYTE PTR es:[di],dx
     238:	69 63 6b 04 1f       	imul   sp,WORD PTR [bp+di+0x6b],0x1f04
     23d:	59                   	pop    cx
     23e:	02 17                	add    dl,BYTE PTR [bx]
     240:	43                   	inc    bx
     241:	68 65 63             	push   0x6365
     244:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     248:	47                   	inc    di
     249:	45                   	inc    bp
     24a:	52                   	push   dx
     24b:	46                   	inc    si
     24c:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     251:	65 43                	gs inc bx
     253:	6c                   	ins    BYTE PTR es:[di],dx
     254:	69 63 6b 1d 20       	imul   sp,WORD PTR [bp+di+0x6b],0x201d
     259:	78 02                	js     0x25d
     25b:	1a 43 68             	sbb    al,BYTE PTR [bp+di+0x68]
     25e:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     262:	6f                   	outs   dx,WORD PTR ds:[si]
     263:	78 47                	js     0x2ac
     265:	45                   	inc    bp
     266:	52                   	push   dx
     267:	54                   	push   sp
     268:	72 65                	jb     0x2cf
     26a:	73 6f                	jae    0x2db
     26c:	72 65                	jb     0x2d3
     26e:	72 69                	jb     0x2d9
     270:	65 43                	gs inc bx
     272:	6c                   	ins    BYTE PTR es:[di],dx
     273:	69 63 6b 26 23       	imul   sp,WORD PTR [bp+di+0x6b],0x2326
     278:	8d 02                	lea    ax,[bp+si]
     27a:	10 43 68             	adc    BYTE PTR [bp+di+0x68],al
     27d:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     281:	6f                   	outs   dx,WORD PTR ds:[si]
     282:	78 45                	js     0x2c9
     284:	31 45 43             	xor    WORD PTR [di+0x43],ax
     287:	6c                   	ins    BYTE PTR es:[di],dx
     288:	69 63 6b 5f 23       	imul   sp,WORD PTR [bp+di+0x6b],0x235f
     28d:	ab                   	stos   WORD PTR es:[di],ax
     28e:	02 19                	add    bl,BYTE PTR [bx+di]
     290:	43                   	inc    bx
     291:	68 65 63             	push   0x6365
     294:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     298:	45                   	inc    bp
     299:	31 52 53             	xor    WORD PTR [bp+si+0x53],dx
     29c:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     2a1:	69 6f 6e 43 6c       	imul   bp,WORD PTR [bx+0x6e],0x6c43
     2a6:	69 63 6b 9a 22       	imul   sp,WORD PTR [bp+di+0x6b],0x229a
     2ab:	c3                   	ret
     2ac:	02 13                	add    dl,BYTE PTR [bp+di]
     2ae:	43                   	inc    bx
     2af:	68 65 63             	push   0x6365
     2b2:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     2b6:	41                   	inc    cx
     2b7:	52                   	push   dx
     2b8:	54                   	push   sp
     2b9:	6f                   	outs   dx,WORD PTR ds:[si]
     2ba:	75 73                	jne    0x32f
     2bc:	43                   	inc    bx
     2bd:	6c                   	ins    BYTE PTR es:[di],dx
     2be:	69 63 6b 7e 2f       	imul   sp,WORD PTR [bp+di+0x6b],0x2f7e
     2c3:	d7                   	xlat   BYTE PTR ds:[bx]
     2c4:	02 0f                	add    cl,BYTE PTR [bx]
     2c6:	53                   	push   bx
     2c7:	70 69                	jo     0x332
     2c9:	6e                   	outs   dx,BYTE PTR ds:[si]
     2ca:	45                   	inc    bp
     2cb:	64 69 74 31 43 68    	imul   si,WORD PTR fs:[si+0x31],0x6843
     2d1:	61                   	popa
     2d2:	6e                   	outs   dx,BYTE PTR ds:[si]
     2d3:	67 65 42             	addr32 gs inc dx
     2d6:	2f                   	das
     2d7:	eb 02                	jmp    0x2db
     2d9:	0f 42 69 74          	cmovb  bp,WORD PTR [bx+di+0x74]
     2dd:	42                   	inc    dx
     2de:	74 6e                	je     0x34e
     2e0:	54                   	push   sp
     2e1:	6f                   	outs   dx,WORD PTR ds:[si]
     2e2:	75 74                	jne    0x358
     2e4:	43                   	inc    bx
     2e5:	6c                   	ins    BYTE PTR es:[di],dx
     2e6:	69 63 6b 5c 2f       	imul   sp,WORD PTR [bp+di+0x6b],0x2f5c
     2eb:	ff 02                	inc    WORD PTR [bp+si]
     2ed:	0f 42 69 74          	cmovb  bp,WORD PTR [bx+di+0x74]
     2f1:	42                   	inc    dx
     2f2:	74 6e                	je     0x362
     2f4:	52                   	push   dx
     2f5:	69 65 6e 43 6c       	imul   sp,WORD PTR [di+0x6e],0x6c43
     2fa:	69 63 6b 93 25       	imul   sp,WORD PTR [bp+di+0x6b],0x2593
     2ff:	0e                   	push   cs
     300:	03 0a                	add    cx,WORD PTR [bp+si]
     302:	46                   	inc    si
     303:	6f                   	outs   dx,WORD PTR ds:[si]
     304:	72 6d                	jb     0x373
     306:	43                   	inc    bx
     307:	72 65                	jb     0x36e
     309:	61                   	popa
     30a:	74 65                	je     0x371
     30c:	8f                   	(bad)
     30d:	38 1e 03 0b          	cmp    BYTE PTR ds:0xb03,bl
     311:	50                   	push   ax
     312:	72 69                	jb     0x37d
     314:	6e                   	outs   dx,BYTE PTR ds:[si]
     315:	74 31                	je     0x348
     317:	43                   	inc    bx
     318:	6c                   	ins    BYTE PTR es:[di],dx
     319:	69 63 6b d2 38       	imul   sp,WORD PTR [bp+di+0x6b],0x38d2
     31e:	2d 03 0a             	sub    ax,0xa03
     321:	43                   	inc    bx
     322:	6f                   	outs   dx,WORD PTR ds:[si]
     323:	70 79                	jo     0x39e
     325:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     328:	69 63 6b 04 30       	imul   sp,WORD PTR [bp+di+0x6b],0x3004
     32d:	43                   	inc    bx
     32e:	03 11                	add    dx,WORD PTR [bx+di]
     330:	49                   	dec    cx
     331:	6d                   	ins    WORD PTR es:[di],dx
     332:	70 52                	jo     0x386
     334:	61                   	popa
     335:	70 69                	jo     0x3a0
     337:	64 65 42             	fs gs inc dx
     33a:	74 6e                	je     0x3aa
     33c:	43                   	inc    bx
     33d:	6c                   	ins    BYTE PTR es:[di],dx
     33e:	69 63 6b ed 2f       	imul   sp,WORD PTR [bp+di+0x6b],0x2fed
     343:	5a                   	pop    dx
     344:	03 12                	add    dx,WORD PTR [bp+si]
     346:	49                   	dec    cx
     347:	6d                   	ins    WORD PTR es:[di],dx
     348:	70 52                	jo     0x39c
     34a:	43                   	inc    bx
     34b:	61                   	popa
     34c:	6e                   	outs   dx,BYTE PTR ds:[si]
     34d:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
     350:	42                   	inc    dx
     351:	74 6e                	je     0x3c1
     353:	43                   	inc    bx
     354:	6c                   	ins    BYTE PTR es:[di],dx
     355:	69 63 6b 36 21       	imul   sp,WORD PTR [bp+di+0x6b],0x2136
     35a:	56                   	push   si
     35b:	0d 13 43             	or     ax,0x4313
     35e:	68 65 63             	push   0x6365
     361:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     365:	47                   	inc    di
     366:	45                   	inc    bp
     367:	52                   	push   dx
     368:	53                   	push   bx
     369:	49                   	dec    cx
     36a:	47                   	inc    di
     36b:	43                   	inc    bx
     36c:	6c                   	ins    BYTE PTR es:[di],dx
     36d:	69 63 6b 89 00       	imul   sp,WORD PTR [bp+di+0x6b],0x89
     372:	03 0d                	add    cx,WORD PTR [di]
     374:	7c 01                	jl     0x377
     376:	00 00                	add    BYTE PTR [bx+si],al
     378:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     37c:	62 65 64             	bound  sp,DWORD PTR [di+0x64]
     37f:	4e                   	dec    si
     380:	6f                   	outs   dx,WORD PTR ds:[si]
     381:	74 65                	je     0x3e8
     383:	62 6f 6f             	bound  bp,DWORD PTR [bx+0x6f]
     386:	6b 31 80             	imul   si,WORD PTR [bx+di],0xff80
     389:	01 04                	add    WORD PTR [si],ax
     38b:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     38f:	6e                   	outs   dx,BYTE PTR ds:[si]
     390:	65 6c                	gs ins BYTE PTR es:[di],dx
     392:	31 84 01 08          	xor    WORD PTR [si+0x801],ax
     396:	00 0a                	add    BYTE PTR [bp+si],cl
     398:	43                   	inc    bx
     399:	68 65 63             	push   0x6365
     39c:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     3a0:	41                   	inc    cx
     3a1:	44                   	inc    sp
     3a2:	88 01                	mov    BYTE PTR [bx+di],al
     3a4:	08 00                	or     BYTE PTR [bx+si],al
     3a6:	0e                   	push   cs
     3a7:	43                   	inc    bx
     3a8:	68 65 63             	push   0x6365
     3ab:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     3af:	41                   	inc    cx
     3b0:	52                   	push   dx
     3b1:	54                   	push   sp
     3b2:	6f                   	outs   dx,WORD PTR ds:[si]
     3b3:	75 73                	jne    0x428
     3b5:	8c 01                	mov    WORD PTR [bx+di],es
     3b7:	04 00                	add    al,0x0
     3b9:	06                   	push   es
     3ba:	50                   	push   ax
     3bb:	61                   	popa
     3bc:	6e                   	outs   dx,BYTE PTR ds:[si]
     3bd:	65 6c                	gs ins BYTE PTR es:[di],dx
     3bf:	32 90 01 08          	xor    dl,BYTE PTR [bx+si+0x801]
     3c3:	00 0b                	add    BYTE PTR [bp+di],cl
     3c5:	43                   	inc    bx
     3c6:	68 65 63             	push   0x6365
     3c9:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     3cd:	45                   	inc    bp
     3ce:	31 44 94             	xor    WORD PTR [si-0x6c],ax
     3d1:	01 0c                	add    WORD PTR [si],cx
     3d3:	00 09                	add    BYTE PTR [bx+di],cl
     3d5:	47                   	inc    di
     3d6:	72 6f                	jb     0x447
     3d8:	75 70                	jne    0x44a
     3da:	42                   	inc    dx
     3db:	6f                   	outs   dx,WORD PTR ds:[si]
     3dc:	78 32                	js     0x410
     3de:	98                   	cbw
     3df:	01 08                	add    WORD PTR [bx+si],cx
     3e1:	00 14                	add    BYTE PTR [si],dl
     3e3:	43                   	inc    bx
     3e4:	68 65 63             	push   0x6365
     3e7:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     3eb:	45                   	inc    bp
     3ec:	31 52 53             	xor    WORD PTR [bp+si+0x53],dx
     3ef:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     3f4:	69 6f 6e 9c 01       	imul   bp,WORD PTR [bx+0x6e],0x19c
     3f9:	08 00                	or     BYTE PTR [bx+si],al
     3fb:	11 43 68             	adc    WORD PTR [bp+di+0x68],ax
     3fe:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     402:	6f                   	outs   dx,WORD PTR ds:[si]
     403:	78 45                	js     0x44a
     405:	31 52 43             	xor    WORD PTR [bp+si+0x43],dx
     408:	6f                   	outs   dx,WORD PTR ds:[si]
     409:	6d                   	ins    WORD PTR es:[di],dx
     40a:	70 74                	jo     0x480
     40c:	65 a0 01 08          	mov    al,gs:0x801
     410:	00 10                	add    BYTE PTR [bx+si],dl
     412:	43                   	inc    bx
     413:	68 65 63             	push   0x6365
     416:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     41a:	45                   	inc    bp
     41b:	31 52 42             	xor    WORD PTR [bp+si+0x42],dx
     41e:	69 6c 61 6e a4       	imul   bp,WORD PTR [si+0x61],0xa46e
     423:	01 08                	add    WORD PTR [bx+si],cx
     425:	00 12                	add    BYTE PTR [bp+si],dl
     427:	43                   	inc    bx
     428:	68 65 63             	push   0x6365
     42b:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     42f:	45                   	inc    bp
     430:	31 52 46             	xor    WORD PTR [bp+si+0x46],dx
     433:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     438:	65 a8 01             	gs test al,0x1
     43b:	08 00                	or     BYTE PTR [bx+si],al
     43d:	15 43 68             	adc    ax,0x6843
     440:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     444:	6f                   	outs   dx,WORD PTR ds:[si]
     445:	78 45                	js     0x48c
     447:	31 52 54             	xor    WORD PTR [bp+si+0x54],dx
     44a:	72 65                	jb     0x4b1
     44c:	73 6f                	jae    0x4bd
     44e:	72 65                	jb     0x4b5
     450:	72 69                	jb     0x4bb
     452:	65 ac                	lods   al,BYTE PTR gs:[si]
     454:	01 10                	add    WORD PTR [bx+si],dx
     456:	00 06 42 65          	add    BYTE PTR ds:0x6542,al
     45a:	76 65                	jbe    0x4c1
     45c:	6c                   	ins    BYTE PTR es:[di],dx
     45d:	31 b0 01 08          	xor    WORD PTR [bx+si+0x801],si
     461:	00 0f                	add    BYTE PTR [bx],cl
     463:	43                   	inc    bx
     464:	68 65 63             	push   0x6365
     467:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     46b:	45                   	inc    bp
     46c:	31 52 54             	xor    WORD PTR [bp+si+0x54],dx
     46f:	6f                   	outs   dx,WORD PTR ds:[si]
     470:	75 73                	jne    0x4e5
     472:	b4 01                	mov    ah,0x1
     474:	04 00                	add    al,0x0
     476:	06                   	push   es
     477:	50                   	push   ax
     478:	61                   	popa
     479:	6e                   	outs   dx,BYTE PTR ds:[si]
     47a:	65 6c                	gs ins BYTE PTR es:[di],dx
     47c:	33 b8 01 08          	xor    di,WORD PTR [bx+si+0x801]
     480:	00 0b                	add    BYTE PTR [bp+di],cl
     482:	43                   	inc    bx
     483:	68 65 63             	push   0x6365
     486:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     48a:	45                   	inc    bp
     48b:	32 44 bc             	xor    al,BYTE PTR [si-0x44]
     48e:	01 0c                	add    WORD PTR [si],cx
     490:	00 09                	add    BYTE PTR [bx+di],cl
     492:	47                   	inc    di
     493:	72 6f                	jb     0x504
     495:	75 70                	jne    0x507
     497:	42                   	inc    dx
     498:	6f                   	outs   dx,WORD PTR ds:[si]
     499:	78 33                	js     0x4ce
     49b:	c0 01 10             	rol    BYTE PTR [bx+di],0x10
     49e:	00 06 42 65          	add    BYTE PTR ds:0x6542,al
     4a2:	76 65                	jbe    0x509
     4a4:	6c                   	ins    BYTE PTR es:[di],dx
     4a5:	32 c4                	xor    al,ah
     4a7:	01 08                	add    WORD PTR [bx+si],cx
     4a9:	00 14                	add    BYTE PTR [si],dl
     4ab:	43                   	inc    bx
     4ac:	68 65 63             	push   0x6365
     4af:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     4b3:	45                   	inc    bp
     4b4:	32 52 53             	xor    dl,BYTE PTR [bp+si+0x53]
     4b7:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     4bc:	69 6f 6e c8 01       	imul   bp,WORD PTR [bx+0x6e],0x1c8
     4c1:	08 00                	or     BYTE PTR [bx+si],al
     4c3:	11 43 68             	adc    WORD PTR [bp+di+0x68],ax
     4c6:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     4ca:	6f                   	outs   dx,WORD PTR ds:[si]
     4cb:	78 45                	js     0x512
     4cd:	32 52 43             	xor    dl,BYTE PTR [bp+si+0x43]
     4d0:	6f                   	outs   dx,WORD PTR ds:[si]
     4d1:	6d                   	ins    WORD PTR es:[di],dx
     4d2:	70 74                	jo     0x548
     4d4:	65 cc                	gs int3
     4d6:	01 08                	add    WORD PTR [bx+si],cx
     4d8:	00 10                	add    BYTE PTR [bx+si],dl
     4da:	43                   	inc    bx
     4db:	68 65 63             	push   0x6365
     4de:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     4e2:	45                   	inc    bp
     4e3:	32 52 42             	xor    dl,BYTE PTR [bp+si+0x42]
     4e6:	69 6c 61 6e d0       	imul   bp,WORD PTR [si+0x61],0xd06e
     4eb:	01 08                	add    WORD PTR [bx+si],cx
     4ed:	00 12                	add    BYTE PTR [bp+si],dl
     4ef:	43                   	inc    bx
     4f0:	68 65 63             	push   0x6365
     4f3:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     4f7:	45                   	inc    bp
     4f8:	32 52 46             	xor    dl,BYTE PTR [bp+si+0x46]
     4fb:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     500:	65 d4 01             	gs aam 0x1
     503:	08 00                	or     BYTE PTR [bx+si],al
     505:	15 43 68             	adc    ax,0x6843
     508:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     50c:	6f                   	outs   dx,WORD PTR ds:[si]
     50d:	78 45                	js     0x554
     50f:	32 52 54             	xor    dl,BYTE PTR [bp+si+0x54]
     512:	72 65                	jb     0x579
     514:	73 6f                	jae    0x585
     516:	72 65                	jb     0x57d
     518:	72 69                	jb     0x583
     51a:	65 d8 01             	fadd   DWORD PTR gs:[bx+di]
     51d:	08 00                	or     BYTE PTR [bx+si],al
     51f:	0f 43 68 65          	cmovae bp,WORD PTR [bx+si+0x65]
     523:	63 6b 42             	arpl   WORD PTR [bp+di+0x42],bp
     526:	6f                   	outs   dx,WORD PTR ds:[si]
     527:	78 45                	js     0x56e
     529:	32 52 54             	xor    dl,BYTE PTR [bp+si+0x54]
     52c:	6f                   	outs   dx,WORD PTR ds:[si]
     52d:	75 73                	jne    0x5a2
     52f:	dc 01                	fadd   QWORD PTR [bx+di]
     531:	04 00                	add    al,0x0
     533:	06                   	push   es
     534:	50                   	push   ax
     535:	61                   	popa
     536:	6e                   	outs   dx,BYTE PTR ds:[si]
     537:	65 6c                	gs ins BYTE PTR es:[di],dx
     539:	34 e0                	xor    al,0xe0
     53b:	01 08                	add    WORD PTR [bx+si],cx
     53d:	00 0b                	add    BYTE PTR [bp+di],cl
     53f:	43                   	inc    bx
     540:	68 65 63             	push   0x6365
     543:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     547:	45                   	inc    bp
     548:	33 44 e4             	xor    ax,WORD PTR [si-0x1c]
     54b:	01 0c                	add    WORD PTR [si],cx
     54d:	00 09                	add    BYTE PTR [bx+di],cl
     54f:	47                   	inc    di
     550:	72 6f                	jb     0x5c1
     552:	75 70                	jne    0x5c4
     554:	42                   	inc    dx
     555:	6f                   	outs   dx,WORD PTR ds:[si]
     556:	78 34                	js     0x58c
     558:	e8 01 10             	call   0x155c
     55b:	00 06 42 65          	add    BYTE PTR ds:0x6542,al
     55f:	76 65                	jbe    0x5c6
     561:	6c                   	ins    BYTE PTR es:[di],dx
     562:	33 ec                	xor    bp,sp
     564:	01 08                	add    WORD PTR [bx+si],cx
     566:	00 14                	add    BYTE PTR [si],dl
     568:	43                   	inc    bx
     569:	68 65 63             	push   0x6365
     56c:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     570:	45                   	inc    bp
     571:	33 52 53             	xor    dx,WORD PTR [bp+si+0x53]
     574:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     579:	69 6f 6e f0 01       	imul   bp,WORD PTR [bx+0x6e],0x1f0
     57e:	08 00                	or     BYTE PTR [bx+si],al
     580:	11 43 68             	adc    WORD PTR [bp+di+0x68],ax
     583:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     587:	6f                   	outs   dx,WORD PTR ds:[si]
     588:	78 45                	js     0x5cf
     58a:	33 52 43             	xor    dx,WORD PTR [bp+si+0x43]
     58d:	6f                   	outs   dx,WORD PTR ds:[si]
     58e:	6d                   	ins    WORD PTR es:[di],dx
     58f:	70 74                	jo     0x605
     591:	65 f4                	gs hlt
     593:	01 08                	add    WORD PTR [bx+si],cx
     595:	00 10                	add    BYTE PTR [bx+si],dl
     597:	43                   	inc    bx
     598:	68 65 63             	push   0x6365
     59b:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     59f:	45                   	inc    bp
     5a0:	33 52 42             	xor    dx,WORD PTR [bp+si+0x42]
     5a3:	69 6c 61 6e f8       	imul   bp,WORD PTR [si+0x61],0xf86e
     5a8:	01 08                	add    WORD PTR [bx+si],cx
     5aa:	00 12                	add    BYTE PTR [bp+si],dl
     5ac:	43                   	inc    bx
     5ad:	68 65 63             	push   0x6365
     5b0:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     5b4:	45                   	inc    bp
     5b5:	33 52 46             	xor    dx,WORD PTR [bp+si+0x46]
     5b8:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     5bd:	65 fc                	gs cld
     5bf:	01 08                	add    WORD PTR [bx+si],cx
     5c1:	00 15                	add    BYTE PTR [di],dl
     5c3:	43                   	inc    bx
     5c4:	68 65 63             	push   0x6365
     5c7:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     5cb:	45                   	inc    bp
     5cc:	33 52 54             	xor    dx,WORD PTR [bp+si+0x54]
     5cf:	72 65                	jb     0x636
     5d1:	73 6f                	jae    0x642
     5d3:	72 65                	jb     0x63a
     5d5:	72 69                	jb     0x640
     5d7:	65 00 02             	add    BYTE PTR gs:[bp+si],al
     5da:	08 00                	or     BYTE PTR [bx+si],al
     5dc:	0f 43 68 65          	cmovae bp,WORD PTR [bx+si+0x65]
     5e0:	63 6b 42             	arpl   WORD PTR [bp+di+0x42],bp
     5e3:	6f                   	outs   dx,WORD PTR ds:[si]
     5e4:	78 45                	js     0x62b
     5e6:	33 52 54             	xor    dx,WORD PTR [bp+si+0x54]
     5e9:	6f                   	outs   dx,WORD PTR ds:[si]
     5ea:	75 73                	jne    0x65f
     5ec:	04 02                	add    al,0x2
     5ee:	04 00                	add    al,0x0
     5f0:	06                   	push   es
     5f1:	50                   	push   ax
     5f2:	61                   	popa
     5f3:	6e                   	outs   dx,BYTE PTR ds:[si]
     5f4:	65 6c                	gs ins BYTE PTR es:[di],dx
     5f6:	35 08 02             	xor    ax,0x208
     5f9:	08 00                	or     BYTE PTR [bx+si],al
     5fb:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     5fe:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     602:	6f                   	outs   dx,WORD PTR ds:[si]
     603:	78 45                	js     0x64a
     605:	34 44                	xor    al,0x44
     607:	0c 02                	or     al,0x2
     609:	0c 00                	or     al,0x0
     60b:	09 47 72             	or     WORD PTR [bx+0x72],ax
     60e:	6f                   	outs   dx,WORD PTR ds:[si]
     60f:	75 70                	jne    0x681
     611:	42                   	inc    dx
     612:	6f                   	outs   dx,WORD PTR ds:[si]
     613:	78 35                	js     0x64a
     615:	10 02                	adc    BYTE PTR [bp+si],al
     617:	10 00                	adc    BYTE PTR [bx+si],al
     619:	06                   	push   es
     61a:	42                   	inc    dx
     61b:	65 76 65             	gs jbe 0x683
     61e:	6c                   	ins    BYTE PTR es:[di],dx
     61f:	34 14                	xor    al,0x14
     621:	02 08                	add    cl,BYTE PTR [bx+si]
     623:	00 14                	add    BYTE PTR [si],dl
     625:	43                   	inc    bx
     626:	68 65 63             	push   0x6365
     629:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     62d:	45                   	inc    bp
     62e:	34 52                	xor    al,0x52
     630:	53                   	push   bx
     631:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     636:	69 6f 6e 18 02       	imul   bp,WORD PTR [bx+0x6e],0x218
     63b:	08 00                	or     BYTE PTR [bx+si],al
     63d:	11 43 68             	adc    WORD PTR [bp+di+0x68],ax
     640:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     644:	6f                   	outs   dx,WORD PTR ds:[si]
     645:	78 45                	js     0x68c
     647:	34 52                	xor    al,0x52
     649:	43                   	inc    bx
     64a:	6f                   	outs   dx,WORD PTR ds:[si]
     64b:	6d                   	ins    WORD PTR es:[di],dx
     64c:	70 74                	jo     0x6c2
     64e:	65 1c 02             	gs sbb al,0x2
     651:	08 00                	or     BYTE PTR [bx+si],al
     653:	10 43 68             	adc    BYTE PTR [bp+di+0x68],al
     656:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     65a:	6f                   	outs   dx,WORD PTR ds:[si]
     65b:	78 45                	js     0x6a2
     65d:	34 52                	xor    al,0x52
     65f:	42                   	inc    dx
     660:	69 6c 61 6e 20       	imul   bp,WORD PTR [si+0x61],0x206e
     665:	02 08                	add    cl,BYTE PTR [bx+si]
     667:	00 12                	add    BYTE PTR [bp+si],dl
     669:	43                   	inc    bx
     66a:	68 65 63             	push   0x6365
     66d:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     671:	45                   	inc    bp
     672:	34 52                	xor    al,0x52
     674:	46                   	inc    si
     675:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     67a:	65 24 02             	gs and al,0x2
     67d:	08 00                	or     BYTE PTR [bx+si],al
     67f:	15 43 68             	adc    ax,0x6843
     682:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     686:	6f                   	outs   dx,WORD PTR ds:[si]
     687:	78 45                	js     0x6ce
     689:	34 52                	xor    al,0x52
     68b:	54                   	push   sp
     68c:	72 65                	jb     0x6f3
     68e:	73 6f                	jae    0x6ff
     690:	72 65                	jb     0x6f7
     692:	72 69                	jb     0x6fd
     694:	65 28 02             	sub    BYTE PTR gs:[bp+si],al
     697:	08 00                	or     BYTE PTR [bx+si],al
     699:	0f 43 68 65          	cmovae bp,WORD PTR [bx+si+0x65]
     69d:	63 6b 42             	arpl   WORD PTR [bp+di+0x42],bp
     6a0:	6f                   	outs   dx,WORD PTR ds:[si]
     6a1:	78 45                	js     0x6e8
     6a3:	34 52                	xor    al,0x52
     6a5:	54                   	push   sp
     6a6:	6f                   	outs   dx,WORD PTR ds:[si]
     6a7:	75 73                	jne    0x71c
     6a9:	2c 02                	sub    al,0x2
     6ab:	0c 00                	or     al,0x0
     6ad:	09 47 72             	or     WORD PTR [bx+0x72],ax
     6b0:	6f                   	outs   dx,WORD PTR ds:[si]
     6b1:	75 70                	jne    0x723
     6b3:	42                   	inc    dx
     6b4:	6f                   	outs   dx,WORD PTR ds:[si]
     6b5:	78 36                	js     0x6ed
     6b7:	30 02                	xor    BYTE PTR [bp+si],al
     6b9:	08 00                	or     BYTE PTR [bx+si],al
     6bb:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     6be:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     6c2:	6f                   	outs   dx,WORD PTR ds:[si]
     6c3:	78 47                	js     0x70c
     6c5:	41                   	inc    cx
     6c6:	44                   	inc    sp
     6c7:	34 02                	xor    al,0x2
     6c9:	08 00                	or     BYTE PTR [bx+si],al
     6cb:	0f 43 68 65          	cmovae bp,WORD PTR [bx+si+0x65]
     6cf:	63 6b 42             	arpl   WORD PTR [bp+di+0x42],bp
     6d2:	6f                   	outs   dx,WORD PTR ds:[si]
     6d3:	78 47                	js     0x71c
     6d5:	41                   	inc    cx
     6d6:	52                   	push   dx
     6d7:	54                   	push   sp
     6d8:	6f                   	outs   dx,WORD PTR ds:[si]
     6d9:	75 73                	jne    0x74e
     6db:	38 02                	cmp    BYTE PTR [bp+si],al
     6dd:	0c 00                	or     al,0x0
     6df:	09 47 72             	or     WORD PTR [bx+0x72],ax
     6e2:	6f                   	outs   dx,WORD PTR ds:[si]
     6e3:	75 70                	jne    0x755
     6e5:	42                   	inc    dx
     6e6:	6f                   	outs   dx,WORD PTR ds:[si]
     6e7:	78 37                	js     0x720
     6e9:	3c 02                	cmp    al,0x2
     6eb:	08 00                	or     BYTE PTR [bx+si],al
     6ed:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     6f0:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     6f4:	6f                   	outs   dx,WORD PTR ds:[si]
     6f5:	78 47                	js     0x73e
     6f7:	45                   	inc    bp
     6f8:	44                   	inc    sp
     6f9:	40                   	inc    ax
     6fa:	02 08                	add    cl,BYTE PTR [bx+si]
     6fc:	00 0b                	add    BYTE PTR [bp+di],cl
     6fe:	43                   	inc    bx
     6ff:	68 65 63             	push   0x6365
     702:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     706:	47                   	inc    di
     707:	45                   	inc    bp
     708:	45                   	inc    bp
     709:	44                   	inc    sp
     70a:	02 10                	add    dl,BYTE PTR [bx+si]
     70c:	00 06 42 65          	add    BYTE PTR ds:0x6542,al
     710:	76 65                	jbe    0x777
     712:	6c                   	ins    BYTE PTR es:[di],dx
     713:	35 48 02             	xor    ax,0x248
     716:	08 00                	or     BYTE PTR [bx+si],al
     718:	0f 43 68 65          	cmovae bp,WORD PTR [bx+si+0x65]
     71c:	63 6b 42             	arpl   WORD PTR [bp+di+0x42],bp
     71f:	6f                   	outs   dx,WORD PTR ds:[si]
     720:	78 47                	js     0x769
     722:	45                   	inc    bp
     723:	52                   	push   dx
     724:	54                   	push   sp
     725:	6f                   	outs   dx,WORD PTR ds:[si]
     726:	75 73                	jne    0x79b
     728:	4c                   	dec    sp
     729:	02 08                	add    cl,BYTE PTR [bx+si]
     72b:	00 14                	add    BYTE PTR [si],dl
     72d:	43                   	inc    bx
     72e:	68 65 63             	push   0x6365
     731:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     735:	47                   	inc    di
     736:	45                   	inc    bp
     737:	52                   	push   dx
     738:	53                   	push   bx
     739:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     73e:	69 6f 6e 50 02       	imul   bp,WORD PTR [bx+0x6e],0x250
     743:	08 00                	or     BYTE PTR [bx+si],al
     745:	11 43 68             	adc    WORD PTR [bp+di+0x68],ax
     748:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     74c:	6f                   	outs   dx,WORD PTR ds:[si]
     74d:	78 47                	js     0x796
     74f:	45                   	inc    bp
     750:	52                   	push   dx
     751:	43                   	inc    bx
     752:	6f                   	outs   dx,WORD PTR ds:[si]
     753:	6d                   	ins    WORD PTR es:[di],dx
     754:	70 74                	jo     0x7ca
     756:	65 54                	gs push sp
     758:	02 08                	add    cl,BYTE PTR [bx+si]
     75a:	00 10                	add    BYTE PTR [bx+si],dl
     75c:	43                   	inc    bx
     75d:	68 65 63             	push   0x6365
     760:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     764:	47                   	inc    di
     765:	45                   	inc    bp
     766:	52                   	push   dx
     767:	42                   	inc    dx
     768:	69 6c 61 6e 58       	imul   bp,WORD PTR [si+0x61],0x586e
     76d:	02 08                	add    cl,BYTE PTR [bx+si]
     76f:	00 12                	add    BYTE PTR [bp+si],dl
     771:	43                   	inc    bx
     772:	68 65 63             	push   0x6365
     775:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     779:	47                   	inc    di
     77a:	45                   	inc    bp
     77b:	52                   	push   dx
     77c:	46                   	inc    si
     77d:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     782:	65 5c                	gs pop sp
     784:	02 08                	add    cl,BYTE PTR [bx+si]
     786:	00 15                	add    BYTE PTR [di],dl
     788:	43                   	inc    bx
     789:	68 65 63             	push   0x6365
     78c:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     790:	47                   	inc    di
     791:	45                   	inc    bp
     792:	52                   	push   dx
     793:	54                   	push   sp
     794:	72 65                	jb     0x7fb
     796:	73 6f                	jae    0x807
     798:	72 65                	jb     0x7ff
     79a:	72 69                	jb     0x805
     79c:	65 60                	gs pusha
     79e:	02 04                	add    al,BYTE PTR [si]
     7a0:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     7a4:	6e                   	outs   dx,BYTE PTR ds:[si]
     7a5:	65 6c                	gs ins BYTE PTR es:[di],dx
     7a7:	37                   	aaa
     7a8:	64 02 08             	add    cl,BYTE PTR fs:[bx+si]
     7ab:	00 0b                	add    BYTE PTR [bp+di],cl
     7ad:	43                   	inc    bx
     7ae:	68 65 63             	push   0x6365
     7b1:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     7b5:	45                   	inc    bp
     7b6:	35 44 68             	xor    ax,0x6844
     7b9:	02 0c                	add    cl,BYTE PTR [si]
     7bb:	00 09                	add    BYTE PTR [bx+di],cl
     7bd:	47                   	inc    di
     7be:	72 6f                	jb     0x82f
     7c0:	75 70                	jne    0x832
     7c2:	42                   	inc    dx
     7c3:	6f                   	outs   dx,WORD PTR ds:[si]
     7c4:	78 31                	js     0x7f7
     7c6:	6c                   	ins    BYTE PTR es:[di],dx
     7c7:	02 10                	add    dl,BYTE PTR [bx+si]
     7c9:	00 06 42 65          	add    BYTE PTR ds:0x6542,al
     7cd:	76 65                	jbe    0x834
     7cf:	6c                   	ins    BYTE PTR es:[di],dx
     7d0:	36 70 02             	ss jo  0x7d5
     7d3:	08 00                	or     BYTE PTR [bx+si],al
     7d5:	14 43                	adc    al,0x43
     7d7:	68 65 63             	push   0x6365
     7da:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     7de:	45                   	inc    bp
     7df:	35 52 53             	xor    ax,0x5352
     7e2:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     7e7:	69 6f 6e 74 02       	imul   bp,WORD PTR [bx+0x6e],0x274
     7ec:	08 00                	or     BYTE PTR [bx+si],al
     7ee:	11 43 68             	adc    WORD PTR [bp+di+0x68],ax
     7f1:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     7f5:	6f                   	outs   dx,WORD PTR ds:[si]
     7f6:	78 45                	js     0x83d
     7f8:	35 52 43             	xor    ax,0x4352
     7fb:	6f                   	outs   dx,WORD PTR ds:[si]
     7fc:	6d                   	ins    WORD PTR es:[di],dx
     7fd:	70 74                	jo     0x873
     7ff:	65 78 02             	gs js  0x804
     802:	08 00                	or     BYTE PTR [bx+si],al
     804:	10 43 68             	adc    BYTE PTR [bp+di+0x68],al
     807:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     80b:	6f                   	outs   dx,WORD PTR ds:[si]
     80c:	78 45                	js     0x853
     80e:	35 52 42             	xor    ax,0x4252
     811:	69 6c 61 6e 7c       	imul   bp,WORD PTR [si+0x61],0x7c6e
     816:	02 08                	add    cl,BYTE PTR [bx+si]
     818:	00 12                	add    BYTE PTR [bp+si],dl
     81a:	43                   	inc    bx
     81b:	68 65 63             	push   0x6365
     81e:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     822:	45                   	inc    bp
     823:	35 52 46             	xor    ax,0x4652
     826:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     82b:	65 80 02 08          	add    BYTE PTR gs:[bp+si],0x8
     82f:	00 15                	add    BYTE PTR [di],dl
     831:	43                   	inc    bx
     832:	68 65 63             	push   0x6365
     835:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     839:	45                   	inc    bp
     83a:	35 52 54             	xor    ax,0x5452
     83d:	72 65                	jb     0x8a4
     83f:	73 6f                	jae    0x8b0
     841:	72 65                	jb     0x8a8
     843:	72 69                	jb     0x8ae
     845:	65 84 02             	test   BYTE PTR gs:[bp+si],al
     848:	08 00                	or     BYTE PTR [bx+si],al
     84a:	0f 43 68 65          	cmovae bp,WORD PTR [bx+si+0x65]
     84e:	63 6b 42             	arpl   WORD PTR [bp+di+0x42],bp
     851:	6f                   	outs   dx,WORD PTR ds:[si]
     852:	78 45                	js     0x899
     854:	35 52 54             	xor    ax,0x5452
     857:	6f                   	outs   dx,WORD PTR ds:[si]
     858:	75 73                	jne    0x8cd
     85a:	88 02                	mov    BYTE PTR [bp+si],al
     85c:	04 00                	add    al,0x0
     85e:	07                   	pop    es
     85f:	50                   	push   ax
     860:	61                   	popa
     861:	6e                   	outs   dx,BYTE PTR ds:[si]
     862:	65 6c                	gs ins BYTE PTR es:[di],dx
     864:	31 33                	xor    WORD PTR [bp+di],si
     866:	8c 02                	mov    WORD PTR [bp+si],es
     868:	08 00                	or     BYTE PTR [bx+si],al
     86a:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     86d:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     871:	6f                   	outs   dx,WORD PTR ds:[si]
     872:	78 45                	js     0x8b9
     874:	36 44                	ss inc sp
     876:	90                   	nop
     877:	02 0c                	add    cl,BYTE PTR [si]
     879:	00 09                	add    BYTE PTR [bx+di],cl
     87b:	47                   	inc    di
     87c:	72 6f                	jb     0x8ed
     87e:	75 70                	jne    0x8f0
     880:	42                   	inc    dx
     881:	6f                   	outs   dx,WORD PTR ds:[si]
     882:	78 38                	js     0x8bc
     884:	94                   	xchg   sp,ax
     885:	02 10                	add    dl,BYTE PTR [bx+si]
     887:	00 06 42 65          	add    BYTE PTR ds:0x6542,al
     88b:	76 65                	jbe    0x8f2
     88d:	6c                   	ins    BYTE PTR es:[di],dx
     88e:	37                   	aaa
     88f:	98                   	cbw
     890:	02 08                	add    cl,BYTE PTR [bx+si]
     892:	00 14                	add    BYTE PTR [si],dl
     894:	43                   	inc    bx
     895:	68 65 63             	push   0x6365
     898:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     89c:	45                   	inc    bp
     89d:	36 52                	ss push dx
     89f:	53                   	push   bx
     8a0:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     8a5:	69 6f 6e 9c 02       	imul   bp,WORD PTR [bx+0x6e],0x29c
     8aa:	08 00                	or     BYTE PTR [bx+si],al
     8ac:	11 43 68             	adc    WORD PTR [bp+di+0x68],ax
     8af:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     8b3:	6f                   	outs   dx,WORD PTR ds:[si]
     8b4:	78 45                	js     0x8fb
     8b6:	36 52                	ss push dx
     8b8:	43                   	inc    bx
     8b9:	6f                   	outs   dx,WORD PTR ds:[si]
     8ba:	6d                   	ins    WORD PTR es:[di],dx
     8bb:	70 74                	jo     0x931
     8bd:	65 a0 02 08          	mov    al,gs:0x802
     8c1:	00 10                	add    BYTE PTR [bx+si],dl
     8c3:	43                   	inc    bx
     8c4:	68 65 63             	push   0x6365
     8c7:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     8cb:	45                   	inc    bp
     8cc:	36 52                	ss push dx
     8ce:	42                   	inc    dx
     8cf:	69 6c 61 6e a4       	imul   bp,WORD PTR [si+0x61],0xa46e
     8d4:	02 08                	add    cl,BYTE PTR [bx+si]
     8d6:	00 12                	add    BYTE PTR [bp+si],dl
     8d8:	43                   	inc    bx
     8d9:	68 65 63             	push   0x6365
     8dc:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     8e0:	45                   	inc    bp
     8e1:	36 52                	ss push dx
     8e3:	46                   	inc    si
     8e4:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     8e9:	65 a8 02             	gs test al,0x2
     8ec:	08 00                	or     BYTE PTR [bx+si],al
     8ee:	15 43 68             	adc    ax,0x6843
     8f1:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     8f5:	6f                   	outs   dx,WORD PTR ds:[si]
     8f6:	78 45                	js     0x93d
     8f8:	36 52                	ss push dx
     8fa:	54                   	push   sp
     8fb:	72 65                	jb     0x962
     8fd:	73 6f                	jae    0x96e
     8ff:	72 65                	jb     0x966
     901:	72 69                	jb     0x96c
     903:	65 ac                	lods   al,BYTE PTR gs:[si]
     905:	02 08                	add    cl,BYTE PTR [bx+si]
     907:	00 0f                	add    BYTE PTR [bx],cl
     909:	43                   	inc    bx
     90a:	68 65 63             	push   0x6365
     90d:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     911:	45                   	inc    bp
     912:	36 52                	ss push dx
     914:	54                   	push   sp
     915:	6f                   	outs   dx,WORD PTR ds:[si]
     916:	75 73                	jne    0x98b
     918:	b0 02                	mov    al,0x2
     91a:	04 00                	add    al,0x0
     91c:	07                   	pop    es
     91d:	50                   	push   ax
     91e:	61                   	popa
     91f:	6e                   	outs   dx,BYTE PTR ds:[si]
     920:	65 6c                	gs ins BYTE PTR es:[di],dx
     922:	31 35                	xor    WORD PTR [di],si
     924:	b4 02                	mov    ah,0x2
     926:	08 00                	or     BYTE PTR [bx+si],al
     928:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     92b:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     92f:	6f                   	outs   dx,WORD PTR ds:[si]
     930:	78 45                	js     0x977
     932:	37                   	aaa
     933:	44                   	inc    sp
     934:	b8 02 0c             	mov    ax,0xc02
     937:	00 09                	add    BYTE PTR [bx+di],cl
     939:	47                   	inc    di
     93a:	72 6f                	jb     0x9ab
     93c:	75 70                	jne    0x9ae
     93e:	42                   	inc    dx
     93f:	6f                   	outs   dx,WORD PTR ds:[si]
     940:	78 39                	js     0x97b
     942:	bc 02 10             	mov    sp,0x1002
     945:	00 06 42 65          	add    BYTE PTR ds:0x6542,al
     949:	76 65                	jbe    0x9b0
     94b:	6c                   	ins    BYTE PTR es:[di],dx
     94c:	38 c0                	cmp    al,al
     94e:	02 08                	add    cl,BYTE PTR [bx+si]
     950:	00 14                	add    BYTE PTR [si],dl
     952:	43                   	inc    bx
     953:	68 65 63             	push   0x6365
     956:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     95a:	45                   	inc    bp
     95b:	37                   	aaa
     95c:	52                   	push   dx
     95d:	53                   	push   bx
     95e:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     963:	69 6f 6e c4 02       	imul   bp,WORD PTR [bx+0x6e],0x2c4
     968:	08 00                	or     BYTE PTR [bx+si],al
     96a:	11 43 68             	adc    WORD PTR [bp+di+0x68],ax
     96d:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     971:	6f                   	outs   dx,WORD PTR ds:[si]
     972:	78 45                	js     0x9b9
     974:	37                   	aaa
     975:	52                   	push   dx
     976:	43                   	inc    bx
     977:	6f                   	outs   dx,WORD PTR ds:[si]
     978:	6d                   	ins    WORD PTR es:[di],dx
     979:	70 74                	jo     0x9ef
     97b:	65 c8 02 08 00       	gs enter 0x802,0x0
     980:	10 43 68             	adc    BYTE PTR [bp+di+0x68],al
     983:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     987:	6f                   	outs   dx,WORD PTR ds:[si]
     988:	78 45                	js     0x9cf
     98a:	37                   	aaa
     98b:	52                   	push   dx
     98c:	42                   	inc    dx
     98d:	69 6c 61 6e cc       	imul   bp,WORD PTR [si+0x61],0xcc6e
     992:	02 08                	add    cl,BYTE PTR [bx+si]
     994:	00 12                	add    BYTE PTR [bp+si],dl
     996:	43                   	inc    bx
     997:	68 65 63             	push   0x6365
     99a:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     99e:	45                   	inc    bp
     99f:	37                   	aaa
     9a0:	52                   	push   dx
     9a1:	46                   	inc    si
     9a2:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     9a7:	65 d0 02             	rol    BYTE PTR gs:[bp+si],1
     9aa:	08 00                	or     BYTE PTR [bx+si],al
     9ac:	15 43 68             	adc    ax,0x6843
     9af:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     9b3:	6f                   	outs   dx,WORD PTR ds:[si]
     9b4:	78 45                	js     0x9fb
     9b6:	37                   	aaa
     9b7:	52                   	push   dx
     9b8:	54                   	push   sp
     9b9:	72 65                	jb     0xa20
     9bb:	73 6f                	jae    0xa2c
     9bd:	72 65                	jb     0xa24
     9bf:	72 69                	jb     0xa2a
     9c1:	65 d4 02             	gs aam 0x2
     9c4:	08 00                	or     BYTE PTR [bx+si],al
     9c6:	0f 43 68 65          	cmovae bp,WORD PTR [bx+si+0x65]
     9ca:	63 6b 42             	arpl   WORD PTR [bp+di+0x42],bp
     9cd:	6f                   	outs   dx,WORD PTR ds:[si]
     9ce:	78 45                	js     0xa15
     9d0:	37                   	aaa
     9d1:	52                   	push   dx
     9d2:	54                   	push   sp
     9d3:	6f                   	outs   dx,WORD PTR ds:[si]
     9d4:	75 73                	jne    0xa49
     9d6:	d8 02                	fadd   DWORD PTR [bp+si]
     9d8:	04 00                	add    al,0x0
     9da:	07                   	pop    es
     9db:	50                   	push   ax
     9dc:	61                   	popa
     9dd:	6e                   	outs   dx,BYTE PTR ds:[si]
     9de:	65 6c                	gs ins BYTE PTR es:[di],dx
     9e0:	31 37                	xor    WORD PTR [bx],si
     9e2:	dc 02                	fadd   QWORD PTR [bp+si]
     9e4:	08 00                	or     BYTE PTR [bx+si],al
     9e6:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     9e9:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     9ed:	6f                   	outs   dx,WORD PTR ds:[si]
     9ee:	78 45                	js     0xa35
     9f0:	38 44 e0             	cmp    BYTE PTR [si-0x20],al
     9f3:	02 0c                	add    cl,BYTE PTR [si]
     9f5:	00 0a                	add    BYTE PTR [bp+si],cl
     9f7:	47                   	inc    di
     9f8:	72 6f                	jb     0xa69
     9fa:	75 70                	jne    0xa6c
     9fc:	42                   	inc    dx
     9fd:	6f                   	outs   dx,WORD PTR ds:[si]
     9fe:	78 31                	js     0xa31
     a00:	30 e4                	xor    ah,ah
     a02:	02 10                	add    dl,BYTE PTR [bx+si]
     a04:	00 06 42 65          	add    BYTE PTR ds:0x6542,al
     a08:	76 65                	jbe    0xa6f
     a0a:	6c                   	ins    BYTE PTR es:[di],dx
     a0b:	39 e8                	cmp    ax,bp
     a0d:	02 08                	add    cl,BYTE PTR [bx+si]
     a0f:	00 14                	add    BYTE PTR [si],dl
     a11:	43                   	inc    bx
     a12:	68 65 63             	push   0x6365
     a15:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     a19:	45                   	inc    bp
     a1a:	38 52 53             	cmp    BYTE PTR [bp+si+0x53],dl
     a1d:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     a22:	69 6f 6e ec 02       	imul   bp,WORD PTR [bx+0x6e],0x2ec
     a27:	08 00                	or     BYTE PTR [bx+si],al
     a29:	11 43 68             	adc    WORD PTR [bp+di+0x68],ax
     a2c:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     a30:	6f                   	outs   dx,WORD PTR ds:[si]
     a31:	78 45                	js     0xa78
     a33:	38 52 43             	cmp    BYTE PTR [bp+si+0x43],dl
     a36:	6f                   	outs   dx,WORD PTR ds:[si]
     a37:	6d                   	ins    WORD PTR es:[di],dx
     a38:	70 74                	jo     0xaae
     a3a:	65 f0 02 08          	lock add cl,BYTE PTR gs:[bx+si]
     a3e:	00 10                	add    BYTE PTR [bx+si],dl
     a40:	43                   	inc    bx
     a41:	68 65 63             	push   0x6365
     a44:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     a48:	45                   	inc    bp
     a49:	38 52 42             	cmp    BYTE PTR [bp+si+0x42],dl
     a4c:	69 6c 61 6e f4       	imul   bp,WORD PTR [si+0x61],0xf46e
     a51:	02 08                	add    cl,BYTE PTR [bx+si]
     a53:	00 12                	add    BYTE PTR [bp+si],dl
     a55:	43                   	inc    bx
     a56:	68 65 63             	push   0x6365
     a59:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     a5d:	45                   	inc    bp
     a5e:	38 52 46             	cmp    BYTE PTR [bp+si+0x46],dl
     a61:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     a66:	65 f8                	gs clc
     a68:	02 08                	add    cl,BYTE PTR [bx+si]
     a6a:	00 15                	add    BYTE PTR [di],dl
     a6c:	43                   	inc    bx
     a6d:	68 65 63             	push   0x6365
     a70:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     a74:	45                   	inc    bp
     a75:	38 52 54             	cmp    BYTE PTR [bp+si+0x54],dl
     a78:	72 65                	jb     0xadf
     a7a:	73 6f                	jae    0xaeb
     a7c:	72 65                	jb     0xae3
     a7e:	72 69                	jb     0xae9
     a80:	65 fc                	gs cld
     a82:	02 08                	add    cl,BYTE PTR [bx+si]
     a84:	00 0f                	add    BYTE PTR [bx],cl
     a86:	43                   	inc    bx
     a87:	68 65 63             	push   0x6365
     a8a:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     a8e:	45                   	inc    bp
     a8f:	38 52 54             	cmp    BYTE PTR [bp+si+0x54],dl
     a92:	6f                   	outs   dx,WORD PTR ds:[si]
     a93:	75 73                	jne    0xb08
     a95:	00 03                	add    BYTE PTR [bp+di],al
     a97:	08 00                	or     BYTE PTR [bx+si],al
     a99:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     a9c:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     aa0:	6f                   	outs   dx,WORD PTR ds:[si]
     aa1:	78 45                	js     0xae8
     aa3:	31 45 04             	xor    WORD PTR [di+0x4],ax
     aa6:	03 08                	add    cx,WORD PTR [bx+si]
     aa8:	00 0b                	add    BYTE PTR [bp+di],cl
     aaa:	43                   	inc    bx
     aab:	68 65 63             	push   0x6365
     aae:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     ab2:	45                   	inc    bp
     ab3:	32 45 08             	xor    al,BYTE PTR [di+0x8]
     ab6:	03 08                	add    cx,WORD PTR [bx+si]
     ab8:	00 0b                	add    BYTE PTR [bp+di],cl
     aba:	43                   	inc    bx
     abb:	68 65 63             	push   0x6365
     abe:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     ac2:	45                   	inc    bp
     ac3:	33 45 0c             	xor    ax,WORD PTR [di+0xc]
     ac6:	03 08                	add    cx,WORD PTR [bx+si]
     ac8:	00 0b                	add    BYTE PTR [bp+di],cl
     aca:	43                   	inc    bx
     acb:	68 65 63             	push   0x6365
     ace:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     ad2:	45                   	inc    bp
     ad3:	34 45                	xor    al,0x45
     ad5:	10 03                	adc    BYTE PTR [bp+di],al
     ad7:	08 00                	or     BYTE PTR [bx+si],al
     ad9:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     adc:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     ae0:	6f                   	outs   dx,WORD PTR ds:[si]
     ae1:	78 45                	js     0xb28
     ae3:	35 45 14             	xor    ax,0x1445
     ae6:	03 08                	add    cx,WORD PTR [bx+si]
     ae8:	00 0b                	add    BYTE PTR [bp+di],cl
     aea:	43                   	inc    bx
     aeb:	68 65 63             	push   0x6365
     aee:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     af2:	45                   	inc    bp
     af3:	36 45                	ss inc bp
     af5:	18 03                	sbb    BYTE PTR [bp+di],al
     af7:	08 00                	or     BYTE PTR [bx+si],al
     af9:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     afc:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     b00:	6f                   	outs   dx,WORD PTR ds:[si]
     b01:	78 45                	js     0xb48
     b03:	37                   	aaa
     b04:	45                   	inc    bp
     b05:	1c 03                	sbb    al,0x3
     b07:	08 00                	or     BYTE PTR [bx+si],al
     b09:	0b 43 68             	or     ax,WORD PTR [bp+di+0x68]
     b0c:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     b10:	6f                   	outs   dx,WORD PTR ds:[si]
     b11:	78 45                	js     0xb58
     b13:	38 45 20             	cmp    BYTE PTR [di+0x20],al
     b16:	03 0c                	add    cx,WORD PTR [si]
     b18:	00 0a                	add    BYTE PTR [bp+si],cl
     b1a:	47                   	inc    di
     b1b:	72 6f                	jb     0xb8c
     b1d:	75 70                	jne    0xb8f
     b1f:	42                   	inc    dx
     b20:	6f                   	outs   dx,WORD PTR ds:[si]
     b21:	78 31                	js     0xb54
     b23:	31 24                	xor    WORD PTR [si],sp
     b25:	03 08                	add    cx,WORD PTR [bx+si]
     b27:	00 0b                	add    BYTE PTR [bp+di],cl
     b29:	43                   	inc    bx
     b2a:	68 65 63             	push   0x6365
     b2d:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     b31:	41                   	inc    cx
     b32:	44                   	inc    sp
     b33:	43                   	inc    bx
     b34:	28 03                	sub    BYTE PTR [bp+di],al
     b36:	04 00                	add    al,0x0
     b38:	06                   	push   es
     b39:	50                   	push   ax
     b3a:	61                   	popa
     b3b:	6e                   	outs   dx,BYTE PTR ds:[si]
     b3c:	65 6c                	gs ins BYTE PTR es:[di],dx
     b3e:	36 2c 03             	ss sub al,0x3
     b41:	14 00                	adc    al,0x0
     b43:	07                   	pop    es
     b44:	4c                   	dec    sp
     b45:	61                   	popa
     b46:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     b49:	32 39                	xor    bh,BYTE PTR [bx+di]
     b4b:	30 03                	xor    BYTE PTR [bp+di],al
     b4d:	18 00                	sbb    BYTE PTR [bx+si],al
     b4f:	09 53 70             	or     WORD PTR [bp+di+0x70],dx
     b52:	69 6e 45 64 69       	imul   bp,WORD PTR [bp+0x45],0x6964
     b57:	74 31                	je     0xb8a
     b59:	34 03                	xor    al,0x3
     b5b:	1c 00                	sbb    al,0x0
     b5d:	0b 49 6d             	or     cx,WORD PTR [bx+di+0x6d]
     b60:	70 72                	jo     0xbd4
     b62:	69 6d 65 72 42       	imul   bp,WORD PTR [di+0x65],0x4272
     b67:	74 6e                	je     0xbd7
     b69:	38 03                	cmp    BYTE PTR [bp+di],al
     b6b:	1c 00                	sbb    al,0x0
     b6d:	09 43 61             	or     WORD PTR [bp+di+0x61],ax
     b70:	6e                   	outs   dx,BYTE PTR ds:[si]
     b71:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
     b74:	42                   	inc    dx
     b75:	74 6e                	je     0xbe5
     b77:	3c 03                	cmp    al,0x3
     b79:	1c 00                	sbb    al,0x0
     b7b:	07                   	pop    es
     b7c:	48                   	dec    ax
     b7d:	65 6c                	gs ins BYTE PTR es:[di],dx
     b7f:	70 42                	jo     0xbc3
     b81:	74 6e                	je     0xbf1
     b83:	40                   	inc    ax
     b84:	03 20                	add    sp,WORD PTR [bx+si]
     b86:	00 0c                	add    BYTE PTR [si],cl
     b88:	50                   	push   ax
     b89:	72 69                	jb     0xbf4
     b8b:	6e                   	outs   dx,BYTE PTR ds:[si]
     b8c:	74 44                	je     0xbd2
     b8e:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     b93:	31 44 03             	xor    WORD PTR [si+0x3],ax
     b96:	1c 00                	sbb    al,0x0
     b98:	07                   	pop    es
     b99:	54                   	push   sp
     b9a:	65 73 74             	gs jae 0xc11
     b9d:	42                   	inc    dx
     b9e:	74 6e                	je     0xc0e
     ba0:	48                   	dec    ax
     ba1:	03 1c                	add    bx,WORD PTR [si]
     ba3:	00 0a                	add    BYTE PTR [bp+si],cl
     ba5:	42                   	inc    dx
     ba6:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
     bab:	54                   	push   sp
     bac:	6f                   	outs   dx,WORD PTR ds:[si]
     bad:	75 74                	jne    0xc23
     baf:	4c                   	dec    sp
     bb0:	03 1c                	add    bx,WORD PTR [si]
     bb2:	00 0a                	add    BYTE PTR [bp+si],cl
     bb4:	42                   	inc    dx
     bb5:	69 74 42 74 6e       	imul   si,WORD PTR [si+0x42],0x6e74
     bba:	52                   	push   dx
     bbb:	69 65 6e 50 03       	imul   sp,WORD PTR [di+0x6e],0x350
     bc0:	24 00                	and    al,0x0
     bc2:	08 54 61             	or     BYTE PTR [si+0x61],dl
     bc5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bc8:	41                   	inc    cx
     bc9:	44                   	inc    sp
     bca:	47                   	inc    di
     bcb:	54                   	push   sp
     bcc:	03 24                	add    sp,WORD PTR [si]
     bce:	00 08                	add    BYTE PTR [bx+si],cl
     bd0:	54                   	push   sp
     bd1:	61                   	popa
     bd2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bd5:	45                   	inc    bp
     bd6:	44                   	inc    sp
     bd7:	47                   	inc    di
     bd8:	58                   	pop    ax
     bd9:	03 28                	add    bp,WORD PTR [bx+si]
     bdb:	00 0a                	add    BYTE PTR [bp+si],cl
     bdd:	50                   	push   ax
     bde:	6f                   	outs   dx,WORD PTR ds:[si]
     bdf:	70 75                	jo     0xc56
     be1:	70 4d                	jo     0xc30
     be3:	65 6e                	outs   dx,BYTE PTR gs:[si]
     be5:	75 31                	jne    0xc18
     be7:	5c                   	pop    sp
     be8:	03 2c                	add    bp,WORD PTR [si]
     bea:	00 06 50 72          	add    BYTE PTR ds:0x7250,al
     bee:	69 6e 74 31 60       	imul   bp,WORD PTR [bp+0x74],0x6031
     bf3:	03 2c                	add    bp,WORD PTR [si]
     bf5:	00 05                	add    BYTE PTR [di],al
     bf7:	43                   	inc    bx
     bf8:	6f                   	outs   dx,WORD PTR ds:[si]
     bf9:	70 79                	jo     0xc74
     bfb:	31 64 03             	xor    WORD PTR [si+0x3],sp
     bfe:	30 00                	xor    BYTE PTR [bx+si],al
     c00:	06                   	push   es
     c01:	49                   	dec    cx
     c02:	6d                   	ins    WORD PTR es:[di],dx
     c03:	61                   	popa
     c04:	67 65 31 68 03       	xor    WORD PTR gs:[eax+0x3],bp
     c09:	34 00                	xor    al,0x0
     c0b:	13 50 72             	adc    dx,WORD PTR [bx+si+0x72]
     c0e:	69 6e 74 65 72       	imul   bp,WORD PTR [bp+0x74],0x7265
     c13:	53                   	push   bx
     c14:	65 74 75             	gs je  0xc8c
     c17:	70 44                	jo     0xc5d
     c19:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     c1e:	31 6c 03             	xor    WORD PTR [si+0x3],bp
     c21:	1c 00                	sbb    al,0x0
     c23:	0c 49                	or     al,0x49
     c25:	6d                   	ins    WORD PTR es:[di],dx
     c26:	70 52                	jo     0xc7a
     c28:	61                   	popa
     c29:	70 69                	jo     0xc94
     c2b:	64 65 42             	fs gs inc dx
     c2e:	74 6e                	je     0xc9e
     c30:	70 03                	jo     0xc35
     c32:	04 00                	add    al,0x0
     c34:	06                   	push   es
     c35:	50                   	push   ax
     c36:	61                   	popa
     c37:	6e                   	outs   dx,BYTE PTR ds:[si]
     c38:	65 6c                	gs ins BYTE PTR es:[di],dx
     c3a:	38 74 03             	cmp    BYTE PTR [si+0x3],dh
     c3d:	1c 00                	sbb    al,0x0
     c3f:	0d 49 6d             	or     ax,0x6d49
     c42:	70 52                	jo     0xc96
     c44:	43                   	inc    bx
     c45:	61                   	popa
     c46:	6e                   	outs   dx,BYTE PTR ds:[si]
     c47:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
     c4a:	42                   	inc    dx
     c4b:	74 6e                	je     0xcbb
     c4d:	78 03                	js     0xc52
     c4f:	14 00                	adc    al,0x0
     c51:	06                   	push   es
     c52:	4c                   	dec    sp
     c53:	61                   	popa
     c54:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     c57:	31 7c 03             	xor    WORD PTR [si+0x3],di
     c5a:	08 00                	or     BYTE PTR [bx+si],al
     c5c:	0e                   	push   cs
     c5d:	43                   	inc    bx
     c5e:	68 65 63             	push   0x6365
     c61:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     c65:	45                   	inc    bp
     c66:	31 52 53             	xor    WORD PTR [bp+si+0x53],dx
     c69:	49                   	dec    cx
     c6a:	47                   	inc    di
     c6b:	80 03 08             	add    BYTE PTR [bp+di],0x8
     c6e:	00 0e 43 68          	add    BYTE PTR ds:0x6843,cl
     c72:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     c76:	6f                   	outs   dx,WORD PTR ds:[si]
     c77:	78 45                	js     0xcbe
     c79:	32 52 53             	xor    dl,BYTE PTR [bp+si+0x53]
     c7c:	49                   	dec    cx
     c7d:	47                   	inc    di
     c7e:	84 03                	test   BYTE PTR [bp+di],al
     c80:	08 00                	or     BYTE PTR [bx+si],al
     c82:	0e                   	push   cs
     c83:	43                   	inc    bx
     c84:	68 65 63             	push   0x6365
     c87:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     c8b:	45                   	inc    bp
     c8c:	33 52 53             	xor    dx,WORD PTR [bp+si+0x53]
     c8f:	49                   	dec    cx
     c90:	47                   	inc    di
     c91:	88 03                	mov    BYTE PTR [bp+di],al
     c93:	08 00                	or     BYTE PTR [bx+si],al
     c95:	0e                   	push   cs
     c96:	43                   	inc    bx
     c97:	68 65 63             	push   0x6365
     c9a:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     c9e:	45                   	inc    bp
     c9f:	34 52                	xor    al,0x52
     ca1:	53                   	push   bx
     ca2:	49                   	dec    cx
     ca3:	47                   	inc    di
     ca4:	8c 03                	mov    WORD PTR [bp+di],es
     ca6:	08 00                	or     BYTE PTR [bx+si],al
     ca8:	0e                   	push   cs
     ca9:	43                   	inc    bx
     caa:	68 65 63             	push   0x6365
     cad:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     cb1:	45                   	inc    bp
     cb2:	35 52 53             	xor    ax,0x5352
     cb5:	49                   	dec    cx
     cb6:	47                   	inc    di
     cb7:	90                   	nop
     cb8:	03 08                	add    cx,WORD PTR [bx+si]
     cba:	00 0e 43 68          	add    BYTE PTR ds:0x6843,cl
     cbe:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     cc2:	6f                   	outs   dx,WORD PTR ds:[si]
     cc3:	78 45                	js     0xd0a
     cc5:	36 52                	ss push dx
     cc7:	53                   	push   bx
     cc8:	49                   	dec    cx
     cc9:	47                   	inc    di
     cca:	94                   	xchg   sp,ax
     ccb:	03 08                	add    cx,WORD PTR [bx+si]
     ccd:	00 0e 43 68          	add    BYTE PTR ds:0x6843,cl
     cd1:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     cd5:	6f                   	outs   dx,WORD PTR ds:[si]
     cd6:	78 45                	js     0xd1d
     cd8:	37                   	aaa
     cd9:	52                   	push   dx
     cda:	53                   	push   bx
     cdb:	49                   	dec    cx
     cdc:	47                   	inc    di
     cdd:	98                   	cbw
     cde:	03 08                	add    cx,WORD PTR [bx+si]
     ce0:	00 0e 43 68          	add    BYTE PTR ds:0x6843,cl
     ce4:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     ce8:	6f                   	outs   dx,WORD PTR ds:[si]
     ce9:	78 45                	js     0xd30
     ceb:	38 52 53             	cmp    BYTE PTR [bp+si+0x53],dl
     cee:	49                   	dec    cx
     cef:	47                   	inc    di
     cf0:	9c                   	pushf
     cf1:	03 08                	add    cx,WORD PTR [bx+si]
     cf3:	00 0e 43 68          	add    BYTE PTR ds:0x6843,cl
     cf7:	65 63 6b 42          	arpl   WORD PTR gs:[bp+di+0x42],bp
     cfb:	6f                   	outs   dx,WORD PTR ds:[si]
     cfc:	78 47                	js     0xd45
     cfe:	45                   	inc    bp
     cff:	52                   	push   dx
     d00:	53                   	push   bx
     d01:	49                   	dec    cx
     d02:	47                   	inc    di
     d03:	0e                   	push   cs
     d04:	00 ed                	add    ch,ch
     d06:	01 6b 26             	add    WORD PTR [bp+di+0x26],bp
     d09:	ad                   	lods   ax,WORD PTR ds:[si]
     d0a:	0d 17 0d             	or     ax,0xd17
     d0d:	22 27                	and    ah,BYTE PTR [bx]
     d0f:	13 0d                	adc    cx,WORD PTR [di]
     d11:	0c 01                	or     al,0x1
     d13:	1b 0d                	sbb    cx,WORD PTR [di]
     d15:	2d 0a 37             	sub    ax,0x370a
     d18:	0d 17 06             	or     ax,0x617
     d1b:	12 13                	adc    dl,BYTE PTR [bp+di]
     d1d:	eb 03                	jmp    0xd22
     d1f:	ab                   	stos   WORD PTR es:[di],ax
     d20:	29 ac 04 2d          	sub    WORD PTR [si+0x2d04],bp
     d24:	38 7e 08             	cmp    BYTE PTR [bp+0x8],bh
     d27:	3b 0d                	cmp    cx,WORD PTR [di]
     d29:	38 01                	cmp    BYTE PTR [bx+di],al
     d2b:	c7                   	(bad)
     d2c:	27                   	daa
     d2d:	c6 03 33             	mov    BYTE PTR [bp+di],0x33
     d30:	0d 94 00             	or     ax,0x94
     d33:	ff                   	(bad)
     d34:	ff 65 06             	jmp    WORD PTR [di+0x6]
     d37:	e3 39                	jcxz   0xd72
     d39:	2b 07                	sub    ax,WORD PTR [bx]
     d3b:	ab                   	stos   WORD PTR es:[di],ax
     d3c:	32 07                	xor    al,BYTE PTR [bx]
     d3e:	15 54 46             	adc    ax,0x4654
     d41:	6f                   	outs   dx,WORD PTR ds:[si]
     d42:	72 6d                	jb     0xdb1
     d44:	53                   	push   bx
     d45:	4a                   	dec    dx
     d46:	53                   	push   bx
     d47:	49                   	dec    cx
     d48:	5f                   	pop    di
     d49:	44                   	inc    sp
     d4a:	6c                   	ins    BYTE PTR es:[di],dx
     d4b:	67 49                	addr32 dec cx
     d4d:	6d                   	ins    WORD PTR es:[di],dx
     d4e:	70 72                	jo     0xdc2
     d50:	69 6d 65 72 22       	imul   bp,WORD PTR [di+0x65],0x2272
     d55:	00 69 0d             	add    BYTE PTR [bx+di+0xd],ch
     d58:	7b 06                	jnp    0xd60
     d5a:	8f                   	(bad)
     d5b:	0d 38 00             	or     ax,0x38
     d5e:	04 53                	add    al,0x53
     d60:	6a 73                	push   0x73
     d62:	69 00 00 00          	imul   ax,WORD PTR [bx+si],0x0
     d66:	00 cb                	add    bl,cl
     d68:	0d 88 0d             	or     ax,0xd88
     d6b:	55                   	push   bp
     d6c:	89 e5                	mov    bp,sp
     d6e:	b8 08 00             	mov    ax,0x8
     d71:	9a 44 04 e0 0d       	call   0xde0:0x444
     d76:	83 ec 08             	sub    sp,0x8
     d79:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     d7d:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     d81:	b0 01                	mov    al,0x1
     d83:	50                   	push   ax
     d84:	b8 22 00             	mov    ax,0x22
     d87:	ba b3 0d             	mov    dx,0xdb3
     d8a:	52                   	push   dx
     d8b:	50                   	push   ax
     d8c:	9a 53 25 bd 0d       	call   0xdbd:0x2553
     d91:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d94:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     d97:	b8 65 0d             	mov    ax,0xd65
     d9a:	0e                   	push   cs
     d9b:	50                   	push   ax
     d9c:	55                   	push   bp
     d9d:	ff 36 58 18          	push   WORD PTR ds:0x1858
     da1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     da5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     da8:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     dab:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     dae:	06                   	push   es
     daf:	57                   	push   di
     db0:	9a ad 28 8c 1c       	call   0x1c8c:0x28ad
     db5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     db8:	06                   	push   es
     db9:	57                   	push   di
     dba:	9a 45 5d d3 0d       	call   0xdd3:0x5d45
     dbf:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     dc3:	83 c4 06             	add    sp,0x6
     dc6:	b8 d6 0d             	mov    ax,0xdd6
     dc9:	0e                   	push   cs
     dca:	50                   	push   ax
     dcb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     dce:	06                   	push   es
     dcf:	57                   	push   di
     dd0:	9a 1d 5f 0e 28       	call   0x280e:0x5f1d
     dd5:	cb                   	retf
     dd6:	c9                   	leave
     dd7:	cb                   	retf
     dd8:	55                   	push   bp
     dd9:	89 e5                	mov    bp,sp
     ddb:	31 c0                	xor    ax,ax
     ddd:	9a 44 04 fa 0d       	call   0xdfa:0x444
     de2:	6a 00                	push   0x0
     de4:	9a c2 38 09 33       	call   0x3309:0x38c2
     de9:	9a c3 28 ff ff       	call   0xffff:0x28c3
     dee:	c9                   	leave
     def:	ca 04 00             	retf   0x4
     df2:	55                   	push   bp
     df3:	89 e5                	mov    bp,sp
     df5:	31 c0                	xor    ax,ax
     df7:	9a 44 04 d8 12       	call   0x12d8:0x444
     dfc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dff:	26 8d 85 30 02       	lea    ax,es:[di+0x230]
     e04:	8c c2                	mov    dx,es
     e06:	a3 d8 1f             	mov    ds:0x1fd8,ax
     e09:	89 16 da 1f          	mov    WORD PTR ds:0x1fda,dx
     e0d:	26 8d 85 34 02       	lea    ax,es:[di+0x234]
     e12:	8c c2                	mov    dx,es
     e14:	a3 dc 1f             	mov    ds:0x1fdc,ax
     e17:	89 16 de 1f          	mov    WORD PTR ds:0x1fde,dx
     e1b:	26 8d 85 3c 02       	lea    ax,es:[di+0x23c]
     e20:	8c c2                	mov    dx,es
     e22:	a3 e0 1f             	mov    ds:0x1fe0,ax
     e25:	89 16 e2 1f          	mov    WORD PTR ds:0x1fe2,dx
     e29:	26 8d 85 40 02       	lea    ax,es:[di+0x240]
     e2e:	8c c2                	mov    dx,es
     e30:	a3 e4 1f             	mov    ds:0x1fe4,ax
     e33:	89 16 e6 1f          	mov    WORD PTR ds:0x1fe6,dx
     e37:	26 8d 85 48 02       	lea    ax,es:[di+0x248]
     e3c:	8c c2                	mov    dx,es
     e3e:	a3 e8 1f             	mov    ds:0x1fe8,ax
     e41:	89 16 ea 1f          	mov    WORD PTR ds:0x1fea,dx
     e45:	26 8d 85 4c 02       	lea    ax,es:[di+0x24c]
     e4a:	8c c2                	mov    dx,es
     e4c:	a3 ec 1f             	mov    ds:0x1fec,ax
     e4f:	89 16 ee 1f          	mov    WORD PTR ds:0x1fee,dx
     e53:	26 8d 85 50 02       	lea    ax,es:[di+0x250]
     e58:	8c c2                	mov    dx,es
     e5a:	a3 f0 1f             	mov    ds:0x1ff0,ax
     e5d:	89 16 f2 1f          	mov    WORD PTR ds:0x1ff2,dx
     e61:	26 8d 85 54 02       	lea    ax,es:[di+0x254]
     e66:	8c c2                	mov    dx,es
     e68:	a3 f4 1f             	mov    ds:0x1ff4,ax
     e6b:	89 16 f6 1f          	mov    WORD PTR ds:0x1ff6,dx
     e6f:	26 8d 85 58 02       	lea    ax,es:[di+0x258]
     e74:	8c c2                	mov    dx,es
     e76:	a3 f8 1f             	mov    ds:0x1ff8,ax
     e79:	89 16 fa 1f          	mov    WORD PTR ds:0x1ffa,dx
     e7d:	26 8d 85 5c 02       	lea    ax,es:[di+0x25c]
     e82:	8c c2                	mov    dx,es
     e84:	a3 fc 1f             	mov    ds:0x1ffc,ax
     e87:	89 16 fe 1f          	mov    WORD PTR ds:0x1ffe,dx
     e8b:	26 8d 85 9c 03       	lea    ax,es:[di+0x39c]
     e90:	8c c2                	mov    dx,es
     e92:	a3 00 20             	mov    ds:0x2000,ax
     e95:	89 16 02 20          	mov    WORD PTR ds:0x2002,dx
     e99:	26 8d 85 24 03       	lea    ax,es:[di+0x324]
     e9e:	8c c2                	mov    dx,es
     ea0:	a3 c4 1f             	mov    ds:0x1fc4,ax
     ea3:	89 16 c6 1f          	mov    WORD PTR ds:0x1fc6,dx
     ea7:	26 8d 85 84 01       	lea    ax,es:[di+0x184]
     eac:	8c c2                	mov    dx,es
     eae:	a3 c8 1f             	mov    ds:0x1fc8,ax
     eb1:	89 16 ca 1f          	mov    WORD PTR ds:0x1fca,dx
     eb5:	26 8d 85 88 01       	lea    ax,es:[di+0x188]
     eba:	8c c2                	mov    dx,es
     ebc:	a3 cc 1f             	mov    ds:0x1fcc,ax
     ebf:	89 16 ce 1f          	mov    WORD PTR ds:0x1fce,dx
     ec3:	31 c0                	xor    ax,ax
     ec5:	a3 d0 1f             	mov    ds:0x1fd0,ax
     ec8:	a3 d2 1f             	mov    ds:0x1fd2,ax
     ecb:	31 c0                	xor    ax,ax
     ecd:	a3 d4 1f             	mov    ds:0x1fd4,ax
     ed0:	a3 d6 1f             	mov    ds:0x1fd6,ax
     ed3:	26 8d 85 90 01       	lea    ax,es:[di+0x190]
     ed8:	8c c2                	mov    dx,es
     eda:	a3 a4 1e             	mov    ds:0x1ea4,ax
     edd:	89 16 a6 1e          	mov    WORD PTR ds:0x1ea6,dx
     ee1:	26 8d 85 b0 01       	lea    ax,es:[di+0x1b0]
     ee6:	8c c2                	mov    dx,es
     ee8:	a3 a8 1e             	mov    ds:0x1ea8,ax
     eeb:	89 16 aa 1e          	mov    WORD PTR ds:0x1eaa,dx
     eef:	26 8d 85 98 01       	lea    ax,es:[di+0x198]
     ef4:	8c c2                	mov    dx,es
     ef6:	a3 ac 1e             	mov    ds:0x1eac,ax
     ef9:	89 16 ae 1e          	mov    WORD PTR ds:0x1eae,dx
     efd:	26 8d 85 9c 01       	lea    ax,es:[di+0x19c]
     f02:	8c c2                	mov    dx,es
     f04:	a3 b0 1e             	mov    ds:0x1eb0,ax
     f07:	89 16 b2 1e          	mov    WORD PTR ds:0x1eb2,dx
     f0b:	26 8d 85 a0 01       	lea    ax,es:[di+0x1a0]
     f10:	8c c2                	mov    dx,es
     f12:	a3 b4 1e             	mov    ds:0x1eb4,ax
     f15:	89 16 b6 1e          	mov    WORD PTR ds:0x1eb6,dx
     f19:	26 8d 85 a4 01       	lea    ax,es:[di+0x1a4]
     f1e:	8c c2                	mov    dx,es
     f20:	a3 b8 1e             	mov    ds:0x1eb8,ax
     f23:	89 16 ba 1e          	mov    WORD PTR ds:0x1eba,dx
     f27:	26 8d 85 a8 01       	lea    ax,es:[di+0x1a8]
     f2c:	8c c2                	mov    dx,es
     f2e:	a3 bc 1e             	mov    ds:0x1ebc,ax
     f31:	89 16 be 1e          	mov    WORD PTR ds:0x1ebe,dx
     f35:	26 8d 85 7c 03       	lea    ax,es:[di+0x37c]
     f3a:	8c c2                	mov    dx,es
     f3c:	a3 c0 1e             	mov    ds:0x1ec0,ax
     f3f:	89 16 c2 1e          	mov    WORD PTR ds:0x1ec2,dx
     f43:	26 8d 85 00 03       	lea    ax,es:[di+0x300]
     f48:	8c c2                	mov    dx,es
     f4a:	a3 c4 1e             	mov    ds:0x1ec4,ax
     f4d:	89 16 c6 1e          	mov    WORD PTR ds:0x1ec6,dx
     f51:	26 8d 85 b8 01       	lea    ax,es:[di+0x1b8]
     f56:	8c c2                	mov    dx,es
     f58:	a3 c8 1e             	mov    ds:0x1ec8,ax
     f5b:	89 16 ca 1e          	mov    WORD PTR ds:0x1eca,dx
     f5f:	26 8d 85 d8 01       	lea    ax,es:[di+0x1d8]
     f64:	8c c2                	mov    dx,es
     f66:	a3 cc 1e             	mov    ds:0x1ecc,ax
     f69:	89 16 ce 1e          	mov    WORD PTR ds:0x1ece,dx
     f6d:	26 8d 85 c4 01       	lea    ax,es:[di+0x1c4]
     f72:	8c c2                	mov    dx,es
     f74:	a3 d0 1e             	mov    ds:0x1ed0,ax
     f77:	89 16 d2 1e          	mov    WORD PTR ds:0x1ed2,dx
     f7b:	26 8d 85 c8 01       	lea    ax,es:[di+0x1c8]
     f80:	8c c2                	mov    dx,es
     f82:	a3 d4 1e             	mov    ds:0x1ed4,ax
     f85:	89 16 d6 1e          	mov    WORD PTR ds:0x1ed6,dx
     f89:	26 8d 85 cc 01       	lea    ax,es:[di+0x1cc]
     f8e:	8c c2                	mov    dx,es
     f90:	a3 d8 1e             	mov    ds:0x1ed8,ax
     f93:	89 16 da 1e          	mov    WORD PTR ds:0x1eda,dx
     f97:	26 8d 85 d0 01       	lea    ax,es:[di+0x1d0]
     f9c:	8c c2                	mov    dx,es
     f9e:	a3 dc 1e             	mov    ds:0x1edc,ax
     fa1:	89 16 de 1e          	mov    WORD PTR ds:0x1ede,dx
     fa5:	26 8d 85 d4 01       	lea    ax,es:[di+0x1d4]
     faa:	8c c2                	mov    dx,es
     fac:	a3 e0 1e             	mov    ds:0x1ee0,ax
     faf:	89 16 e2 1e          	mov    WORD PTR ds:0x1ee2,dx
     fb3:	26 8d 85 80 03       	lea    ax,es:[di+0x380]
     fb8:	8c c2                	mov    dx,es
     fba:	a3 e4 1e             	mov    ds:0x1ee4,ax
     fbd:	89 16 e6 1e          	mov    WORD PTR ds:0x1ee6,dx
     fc1:	26 8d 85 04 03       	lea    ax,es:[di+0x304]
     fc6:	8c c2                	mov    dx,es
     fc8:	a3 e8 1e             	mov    ds:0x1ee8,ax
     fcb:	89 16 ea 1e          	mov    WORD PTR ds:0x1eea,dx
     fcf:	26 8d 85 e0 01       	lea    ax,es:[di+0x1e0]
     fd4:	8c c2                	mov    dx,es
     fd6:	a3 ec 1e             	mov    ds:0x1eec,ax
     fd9:	89 16 ee 1e          	mov    WORD PTR ds:0x1eee,dx
     fdd:	26 8d 85 00 02       	lea    ax,es:[di+0x200]
     fe2:	8c c2                	mov    dx,es
     fe4:	a3 f0 1e             	mov    ds:0x1ef0,ax
     fe7:	89 16 f2 1e          	mov    WORD PTR ds:0x1ef2,dx
     feb:	26 8d 85 ec 01       	lea    ax,es:[di+0x1ec]
     ff0:	8c c2                	mov    dx,es
     ff2:	a3 f4 1e             	mov    ds:0x1ef4,ax
     ff5:	89 16 f6 1e          	mov    WORD PTR ds:0x1ef6,dx
     ff9:	26 8d 85 f0 01       	lea    ax,es:[di+0x1f0]
     ffe:	8c c2                	mov    dx,es
    1000:	a3 f8 1e             	mov    ds:0x1ef8,ax
    1003:	89 16 fa 1e          	mov    WORD PTR ds:0x1efa,dx
    1007:	26 8d 85 f4 01       	lea    ax,es:[di+0x1f4]
    100c:	8c c2                	mov    dx,es
    100e:	a3 fc 1e             	mov    ds:0x1efc,ax
    1011:	89 16 fe 1e          	mov    WORD PTR ds:0x1efe,dx
    1015:	26 8d 85 f8 01       	lea    ax,es:[di+0x1f8]
    101a:	8c c2                	mov    dx,es
    101c:	a3 00 1f             	mov    ds:0x1f00,ax
    101f:	89 16 02 1f          	mov    WORD PTR ds:0x1f02,dx
    1023:	26 8d 85 fc 01       	lea    ax,es:[di+0x1fc]
    1028:	8c c2                	mov    dx,es
    102a:	a3 04 1f             	mov    ds:0x1f04,ax
    102d:	89 16 06 1f          	mov    WORD PTR ds:0x1f06,dx
    1031:	26 8d 85 84 03       	lea    ax,es:[di+0x384]
    1036:	8c c2                	mov    dx,es
    1038:	a3 08 1f             	mov    ds:0x1f08,ax
    103b:	89 16 0a 1f          	mov    WORD PTR ds:0x1f0a,dx
    103f:	26 8d 85 08 03       	lea    ax,es:[di+0x308]
    1044:	8c c2                	mov    dx,es
    1046:	a3 0c 1f             	mov    ds:0x1f0c,ax
    1049:	89 16 0e 1f          	mov    WORD PTR ds:0x1f0e,dx
    104d:	26 8d 85 08 02       	lea    ax,es:[di+0x208]
    1052:	8c c2                	mov    dx,es
    1054:	a3 10 1f             	mov    ds:0x1f10,ax
    1057:	89 16 12 1f          	mov    WORD PTR ds:0x1f12,dx
    105b:	26 8d 85 28 02       	lea    ax,es:[di+0x228]
    1060:	8c c2                	mov    dx,es
    1062:	a3 14 1f             	mov    ds:0x1f14,ax
    1065:	89 16 16 1f          	mov    WORD PTR ds:0x1f16,dx
    1069:	26 8d 85 14 02       	lea    ax,es:[di+0x214]
    106e:	8c c2                	mov    dx,es
    1070:	a3 18 1f             	mov    ds:0x1f18,ax
    1073:	89 16 1a 1f          	mov    WORD PTR ds:0x1f1a,dx
    1077:	26 8d 85 18 02       	lea    ax,es:[di+0x218]
    107c:	8c c2                	mov    dx,es
    107e:	a3 1c 1f             	mov    ds:0x1f1c,ax
    1081:	89 16 1e 1f          	mov    WORD PTR ds:0x1f1e,dx
    1085:	26 8d 85 1c 02       	lea    ax,es:[di+0x21c]
    108a:	8c c2                	mov    dx,es
    108c:	a3 20 1f             	mov    ds:0x1f20,ax
    108f:	89 16 22 1f          	mov    WORD PTR ds:0x1f22,dx
    1093:	26 8d 85 20 02       	lea    ax,es:[di+0x220]
    1098:	8c c2                	mov    dx,es
    109a:	a3 24 1f             	mov    ds:0x1f24,ax
    109d:	89 16 26 1f          	mov    WORD PTR ds:0x1f26,dx
    10a1:	26 8d 85 24 02       	lea    ax,es:[di+0x224]
    10a6:	8c c2                	mov    dx,es
    10a8:	a3 28 1f             	mov    ds:0x1f28,ax
    10ab:	89 16 2a 1f          	mov    WORD PTR ds:0x1f2a,dx
    10af:	26 8d 85 88 03       	lea    ax,es:[di+0x388]
    10b4:	8c c2                	mov    dx,es
    10b6:	a3 2c 1f             	mov    ds:0x1f2c,ax
    10b9:	89 16 2e 1f          	mov    WORD PTR ds:0x1f2e,dx
    10bd:	26 8d 85 0c 03       	lea    ax,es:[di+0x30c]
    10c2:	8c c2                	mov    dx,es
    10c4:	a3 30 1f             	mov    ds:0x1f30,ax
    10c7:	89 16 32 1f          	mov    WORD PTR ds:0x1f32,dx
    10cb:	26 8d 85 64 02       	lea    ax,es:[di+0x264]
    10d0:	8c c2                	mov    dx,es
    10d2:	a3 34 1f             	mov    ds:0x1f34,ax
    10d5:	89 16 36 1f          	mov    WORD PTR ds:0x1f36,dx
    10d9:	26 8d 85 84 02       	lea    ax,es:[di+0x284]
    10de:	8c c2                	mov    dx,es
    10e0:	a3 38 1f             	mov    ds:0x1f38,ax
    10e3:	89 16 3a 1f          	mov    WORD PTR ds:0x1f3a,dx
    10e7:	26 8d 85 70 02       	lea    ax,es:[di+0x270]
    10ec:	8c c2                	mov    dx,es
    10ee:	a3 3c 1f             	mov    ds:0x1f3c,ax
    10f1:	89 16 3e 1f          	mov    WORD PTR ds:0x1f3e,dx
    10f5:	26 8d 85 74 02       	lea    ax,es:[di+0x274]
    10fa:	8c c2                	mov    dx,es
    10fc:	a3 40 1f             	mov    ds:0x1f40,ax
    10ff:	89 16 42 1f          	mov    WORD PTR ds:0x1f42,dx
    1103:	26 8d 85 78 02       	lea    ax,es:[di+0x278]
    1108:	8c c2                	mov    dx,es
    110a:	a3 44 1f             	mov    ds:0x1f44,ax
    110d:	89 16 46 1f          	mov    WORD PTR ds:0x1f46,dx
    1111:	26 8d 85 7c 02       	lea    ax,es:[di+0x27c]
    1116:	8c c2                	mov    dx,es
    1118:	a3 48 1f             	mov    ds:0x1f48,ax
    111b:	89 16 4a 1f          	mov    WORD PTR ds:0x1f4a,dx
    111f:	26 8d 85 80 02       	lea    ax,es:[di+0x280]
    1124:	8c c2                	mov    dx,es
    1126:	a3 4c 1f             	mov    ds:0x1f4c,ax
    1129:	89 16 4e 1f          	mov    WORD PTR ds:0x1f4e,dx
    112d:	26 8d 85 8c 03       	lea    ax,es:[di+0x38c]
    1132:	8c c2                	mov    dx,es
    1134:	a3 50 1f             	mov    ds:0x1f50,ax
    1137:	89 16 52 1f          	mov    WORD PTR ds:0x1f52,dx
    113b:	26 8d 85 10 03       	lea    ax,es:[di+0x310]
    1140:	8c c2                	mov    dx,es
    1142:	a3 54 1f             	mov    ds:0x1f54,ax
    1145:	89 16 56 1f          	mov    WORD PTR ds:0x1f56,dx
    1149:	26 8d 85 8c 02       	lea    ax,es:[di+0x28c]
    114e:	8c c2                	mov    dx,es
    1150:	a3 58 1f             	mov    ds:0x1f58,ax
    1153:	89 16 5a 1f          	mov    WORD PTR ds:0x1f5a,dx
    1157:	26 8d 85 ac 02       	lea    ax,es:[di+0x2ac]
    115c:	8c c2                	mov    dx,es
    115e:	a3 5c 1f             	mov    ds:0x1f5c,ax
    1161:	89 16 5e 1f          	mov    WORD PTR ds:0x1f5e,dx
    1165:	26 8d 85 98 02       	lea    ax,es:[di+0x298]
    116a:	8c c2                	mov    dx,es
    116c:	a3 60 1f             	mov    ds:0x1f60,ax
    116f:	89 16 62 1f          	mov    WORD PTR ds:0x1f62,dx
    1173:	26 8d 85 9c 02       	lea    ax,es:[di+0x29c]
    1178:	8c c2                	mov    dx,es
    117a:	a3 64 1f             	mov    ds:0x1f64,ax
    117d:	89 16 66 1f          	mov    WORD PTR ds:0x1f66,dx
    1181:	26 8d 85 a0 02       	lea    ax,es:[di+0x2a0]
    1186:	8c c2                	mov    dx,es
    1188:	a3 68 1f             	mov    ds:0x1f68,ax
    118b:	89 16 6a 1f          	mov    WORD PTR ds:0x1f6a,dx
    118f:	26 8d 85 a4 02       	lea    ax,es:[di+0x2a4]
    1194:	8c c2                	mov    dx,es
    1196:	a3 6c 1f             	mov    ds:0x1f6c,ax
    1199:	89 16 6e 1f          	mov    WORD PTR ds:0x1f6e,dx
    119d:	26 8d 85 a8 02       	lea    ax,es:[di+0x2a8]
    11a2:	8c c2                	mov    dx,es
    11a4:	a3 70 1f             	mov    ds:0x1f70,ax
    11a7:	89 16 72 1f          	mov    WORD PTR ds:0x1f72,dx
    11ab:	26 8d 85 90 03       	lea    ax,es:[di+0x390]
    11b0:	8c c2                	mov    dx,es
    11b2:	a3 74 1f             	mov    ds:0x1f74,ax
    11b5:	89 16 76 1f          	mov    WORD PTR ds:0x1f76,dx
    11b9:	26 8d 85 14 03       	lea    ax,es:[di+0x314]
    11be:	8c c2                	mov    dx,es
    11c0:	a3 78 1f             	mov    ds:0x1f78,ax
    11c3:	89 16 7a 1f          	mov    WORD PTR ds:0x1f7a,dx
    11c7:	26 8d 85 b4 02       	lea    ax,es:[di+0x2b4]
    11cc:	8c c2                	mov    dx,es
    11ce:	a3 7c 1f             	mov    ds:0x1f7c,ax
    11d1:	89 16 7e 1f          	mov    WORD PTR ds:0x1f7e,dx
    11d5:	26 8d 85 d4 02       	lea    ax,es:[di+0x2d4]
    11da:	8c c2                	mov    dx,es
    11dc:	a3 80 1f             	mov    ds:0x1f80,ax
    11df:	89 16 82 1f          	mov    WORD PTR ds:0x1f82,dx
    11e3:	26 8d 85 c0 02       	lea    ax,es:[di+0x2c0]
    11e8:	8c c2                	mov    dx,es
    11ea:	a3 84 1f             	mov    ds:0x1f84,ax
    11ed:	89 16 86 1f          	mov    WORD PTR ds:0x1f86,dx
    11f1:	26 8d 85 c4 02       	lea    ax,es:[di+0x2c4]
    11f6:	8c c2                	mov    dx,es
    11f8:	a3 88 1f             	mov    ds:0x1f88,ax
    11fb:	89 16 8a 1f          	mov    WORD PTR ds:0x1f8a,dx
    11ff:	26 8d 85 c8 02       	lea    ax,es:[di+0x2c8]
    1204:	8c c2                	mov    dx,es
    1206:	a3 8c 1f             	mov    ds:0x1f8c,ax
    1209:	89 16 8e 1f          	mov    WORD PTR ds:0x1f8e,dx
    120d:	26 8d 85 cc 02       	lea    ax,es:[di+0x2cc]
    1212:	8c c2                	mov    dx,es
    1214:	a3 90 1f             	mov    ds:0x1f90,ax
    1217:	89 16 92 1f          	mov    WORD PTR ds:0x1f92,dx
    121b:	26 8d 85 d0 02       	lea    ax,es:[di+0x2d0]
    1220:	8c c2                	mov    dx,es
    1222:	a3 94 1f             	mov    ds:0x1f94,ax
    1225:	89 16 96 1f          	mov    WORD PTR ds:0x1f96,dx
    1229:	26 8d 85 94 03       	lea    ax,es:[di+0x394]
    122e:	8c c2                	mov    dx,es
    1230:	a3 98 1f             	mov    ds:0x1f98,ax
    1233:	89 16 9a 1f          	mov    WORD PTR ds:0x1f9a,dx
    1237:	26 8d 85 18 03       	lea    ax,es:[di+0x318]
    123c:	8c c2                	mov    dx,es
    123e:	a3 9c 1f             	mov    ds:0x1f9c,ax
    1241:	89 16 9e 1f          	mov    WORD PTR ds:0x1f9e,dx
    1245:	26 8d 85 dc 02       	lea    ax,es:[di+0x2dc]
    124a:	8c c2                	mov    dx,es
    124c:	a3 a0 1f             	mov    ds:0x1fa0,ax
    124f:	89 16 a2 1f          	mov    WORD PTR ds:0x1fa2,dx
    1253:	26 8d 85 fc 02       	lea    ax,es:[di+0x2fc]
    1258:	8c c2                	mov    dx,es
    125a:	a3 a4 1f             	mov    ds:0x1fa4,ax
    125d:	89 16 a6 1f          	mov    WORD PTR ds:0x1fa6,dx
    1261:	26 8d 85 e8 02       	lea    ax,es:[di+0x2e8]
    1266:	8c c2                	mov    dx,es
    1268:	a3 a8 1f             	mov    ds:0x1fa8,ax
    126b:	89 16 aa 1f          	mov    WORD PTR ds:0x1faa,dx
    126f:	26 8d 85 ec 02       	lea    ax,es:[di+0x2ec]
    1274:	8c c2                	mov    dx,es
    1276:	a3 ac 1f             	mov    ds:0x1fac,ax
    1279:	89 16 ae 1f          	mov    WORD PTR ds:0x1fae,dx
    127d:	26 8d 85 f0 02       	lea    ax,es:[di+0x2f0]
    1282:	8c c2                	mov    dx,es
    1284:	a3 b0 1f             	mov    ds:0x1fb0,ax
    1287:	89 16 b2 1f          	mov    WORD PTR ds:0x1fb2,dx
    128b:	26 8d 85 f4 02       	lea    ax,es:[di+0x2f4]
    1290:	8c c2                	mov    dx,es
    1292:	a3 b4 1f             	mov    ds:0x1fb4,ax
    1295:	89 16 b6 1f          	mov    WORD PTR ds:0x1fb6,dx
    1299:	26 8d 85 f8 02       	lea    ax,es:[di+0x2f8]
    129e:	8c c2                	mov    dx,es
    12a0:	a3 b8 1f             	mov    ds:0x1fb8,ax
    12a3:	89 16 ba 1f          	mov    WORD PTR ds:0x1fba,dx
    12a7:	26 8d 85 98 03       	lea    ax,es:[di+0x398]
    12ac:	8c c2                	mov    dx,es
    12ae:	a3 bc 1f             	mov    ds:0x1fbc,ax
    12b1:	89 16 be 1f          	mov    WORD PTR ds:0x1fbe,dx
    12b5:	26 8d 85 1c 03       	lea    ax,es:[di+0x31c]
    12ba:	8c c2                	mov    dx,es
    12bc:	a3 c0 1f             	mov    ds:0x1fc0,ax
    12bf:	89 16 c2 1f          	mov    WORD PTR ds:0x1fc2,dx
    12c3:	c9                   	leave
    12c4:	ca 04 00             	retf   0x4
    12c7:	01 00                	add    WORD PTR [bx+si],ax
    12c9:	00 00                	add    BYTE PTR [bx+si],al
    12cb:	08 00                	or     BYTE PTR [bx+si],al
    12cd:	00 00                	add    BYTE PTR [bx+si],al
    12cf:	55                   	push   bp
    12d0:	89 e5                	mov    bp,sp
    12d2:	b8 06 00             	mov    ax,0x6
    12d5:	9a 44 04 01 13       	call   0x1301:0x444
    12da:	83 ec 06             	sub    sp,0x6
    12dd:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    12e1:	a1 4e 01             	mov    ax,ds:0x14e
    12e4:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    12e7:	b8 01 00             	mov    ax,0x1
    12ea:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    12ed:	7f 33                	jg     0x1322
    12ef:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    12f2:	eb 03                	jmp    0x12f7
    12f4:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    12f7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    12fa:	99                   	cwd
    12fb:	bf c7 12             	mov    di,0x12c7
    12fe:	9a 16 04 47 13       	call   0x1347:0x416
    1303:	6b f8 24             	imul   di,ax,0x24
    1306:	c4 bd 80 1e          	les    di,DWORD PTR [di+0x1e80]
    130a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    130d:	06                   	push   es
    130e:	57                   	push   di
    130f:	9a d2 6d 32 13       	call   0x1332:0x6dd2
    1314:	22 46 ff             	and    al,BYTE PTR [bp-0x1]
    1317:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    131a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    131d:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1320:	75 d2                	jne    0x12f4
    1322:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1325:	50                   	push   ax
    1326:	c4 3e e0 1f          	les    di,DWORD PTR ds:0x1fe0
    132a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    132d:	06                   	push   es
    132e:	57                   	push   di
    132f:	9a 11 6e 81 13       	call   0x1381:0x6e11
    1334:	c9                   	leave
    1335:	cb                   	retf
    1336:	01 00                	add    WORD PTR [bx+si],ax
    1338:	00 00                	add    BYTE PTR [bx+si],al
    133a:	08 00                	or     BYTE PTR [bx+si],al
    133c:	00 00                	add    BYTE PTR [bx+si],al
    133e:	55                   	push   bp
    133f:	89 e5                	mov    bp,sp
    1341:	b8 06 00             	mov    ax,0x6
    1344:	9a 44 04 70 13       	call   0x1370:0x444
    1349:	83 ec 06             	sub    sp,0x6
    134c:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1350:	a1 4e 01             	mov    ax,ds:0x14e
    1353:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1356:	b8 01 00             	mov    ax,0x1
    1359:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    135c:	7f 33                	jg     0x1391
    135e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1361:	eb 03                	jmp    0x1366
    1363:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1366:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1369:	99                   	cwd
    136a:	bf 36 13             	mov    di,0x1336
    136d:	9a 16 04 ad 13       	call   0x13ad:0x416
    1372:	6b f8 24             	imul   di,ax,0x24
    1375:	c4 bd a0 1e          	les    di,DWORD PTR [di+0x1ea0]
    1379:	26 c4 3d             	les    di,DWORD PTR es:[di]
    137c:	06                   	push   es
    137d:	57                   	push   di
    137e:	9a d2 6d a1 13       	call   0x13a1:0x6dd2
    1383:	22 46 ff             	and    al,BYTE PTR [bp-0x1]
    1386:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1389:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    138c:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    138f:	75 d2                	jne    0x1363
    1391:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1394:	50                   	push   ax
    1395:	c4 3e e4 1f          	les    di,DWORD PTR ds:0x1fe4
    1399:	26 c4 3d             	les    di,DWORD PTR es:[di]
    139c:	06                   	push   es
    139d:	57                   	push   di
    139e:	9a 11 6e bb 13       	call   0x13bb:0x6e11
    13a3:	c9                   	leave
    13a4:	cb                   	retf
    13a5:	55                   	push   bp
    13a6:	89 e5                	mov    bp,sp
    13a8:	31 c0                	xor    ax,ax
    13aa:	9a 44 04 39 14       	call   0x1439:0x444
    13af:	c4 3e 00 20          	les    di,DWORD PTR ds:0x2000
    13b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13b6:	06                   	push   es
    13b7:	57                   	push   di
    13b8:	9a d2 6d ca 13       	call   0x13ca:0x6dd2
    13bd:	50                   	push   ax
    13be:	c4 3e fc 1f          	les    di,DWORD PTR ds:0x1ffc
    13c2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13c5:	06                   	push   es
    13c6:	57                   	push   di
    13c7:	9a d2 6d d9 13       	call   0x13d9:0x6dd2
    13cc:	50                   	push   ax
    13cd:	c4 3e f8 1f          	les    di,DWORD PTR ds:0x1ff8
    13d1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13d4:	06                   	push   es
    13d5:	57                   	push   di
    13d6:	9a d2 6d e8 13       	call   0x13e8:0x6dd2
    13db:	50                   	push   ax
    13dc:	c4 3e f4 1f          	les    di,DWORD PTR ds:0x1ff4
    13e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13e3:	06                   	push   es
    13e4:	57                   	push   di
    13e5:	9a d2 6d f7 13       	call   0x13f7:0x6dd2
    13ea:	50                   	push   ax
    13eb:	c4 3e f0 1f          	les    di,DWORD PTR ds:0x1ff0
    13ef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13f2:	06                   	push   es
    13f3:	57                   	push   di
    13f4:	9a d2 6d 06 14       	call   0x1406:0x6dd2
    13f9:	50                   	push   ax
    13fa:	c4 3e ec 1f          	les    di,DWORD PTR ds:0x1fec
    13fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1401:	06                   	push   es
    1402:	57                   	push   di
    1403:	9a d2 6d 24 14       	call   0x1424:0x6dd2
    1408:	5a                   	pop    dx
    1409:	22 c2                	and    al,dl
    140b:	5a                   	pop    dx
    140c:	22 c2                	and    al,dl
    140e:	5a                   	pop    dx
    140f:	22 c2                	and    al,dl
    1411:	5a                   	pop    dx
    1412:	22 c2                	and    al,dl
    1414:	5a                   	pop    dx
    1415:	22 c2                	and    al,dl
    1417:	50                   	push   ax
    1418:	c4 3e e8 1f          	les    di,DWORD PTR ds:0x1fe8
    141c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    141f:	06                   	push   es
    1420:	57                   	push   di
    1421:	9a 11 6e 73 14       	call   0x1473:0x6e11
    1426:	c9                   	leave
    1427:	cb                   	retf
    1428:	01 00                	add    WORD PTR [bx+si],ax
    142a:	00 00                	add    BYTE PTR [bx+si],al
    142c:	08 00                	or     BYTE PTR [bx+si],al
    142e:	00 00                	add    BYTE PTR [bx+si],al
    1430:	55                   	push   bp
    1431:	89 e5                	mov    bp,sp
    1433:	b8 06 00             	mov    ax,0x6
    1436:	9a 44 04 62 14       	call   0x1462:0x444
    143b:	83 ec 06             	sub    sp,0x6
    143e:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1442:	a1 4e 01             	mov    ax,ds:0x14e
    1445:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1448:	b8 01 00             	mov    ax,0x1
    144b:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    144e:	7f 33                	jg     0x1483
    1450:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1453:	eb 03                	jmp    0x1458
    1455:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1458:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    145b:	99                   	cwd
    145c:	bf 28 14             	mov    di,0x1428
    145f:	9a 16 04 b9 14       	call   0x14b9:0x416
    1464:	6b f8 24             	imul   di,ax,0x24
    1467:	c4 bd 88 1e          	les    di,DWORD PTR [di+0x1e88]
    146b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    146e:	06                   	push   es
    146f:	57                   	push   di
    1470:	9a d2 6d 93 14       	call   0x1493:0x6dd2
    1475:	22 46 ff             	and    al,BYTE PTR [bp-0x1]
    1478:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    147b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    147e:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1481:	75 d2                	jne    0x1455
    1483:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1486:	50                   	push   ax
    1487:	c4 3e ec 1f          	les    di,DWORD PTR ds:0x1fec
    148b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    148e:	06                   	push   es
    148f:	57                   	push   di
    1490:	9a 11 6e ca 14       	call   0x14ca:0x6e11
    1495:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1499:	a1 4e 01             	mov    ax,ds:0x14e
    149c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    149f:	b8 01 00             	mov    ax,0x1
    14a2:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    14a5:	7f 33                	jg     0x14da
    14a7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    14aa:	eb 03                	jmp    0x14af
    14ac:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    14af:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    14b2:	99                   	cwd
    14b3:	bf 28 14             	mov    di,0x1428
    14b6:	9a 16 04 10 15       	call   0x1510:0x416
    14bb:	6b f8 24             	imul   di,ax,0x24
    14be:	c4 bd 8c 1e          	les    di,DWORD PTR [di+0x1e8c]
    14c2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14c5:	06                   	push   es
    14c6:	57                   	push   di
    14c7:	9a d2 6d ea 14       	call   0x14ea:0x6dd2
    14cc:	22 46 ff             	and    al,BYTE PTR [bp-0x1]
    14cf:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    14d2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    14d5:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    14d8:	75 d2                	jne    0x14ac
    14da:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    14dd:	50                   	push   ax
    14de:	c4 3e f0 1f          	les    di,DWORD PTR ds:0x1ff0
    14e2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14e5:	06                   	push   es
    14e6:	57                   	push   di
    14e7:	9a 11 6e 21 15       	call   0x1521:0x6e11
    14ec:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    14f0:	a1 4e 01             	mov    ax,ds:0x14e
    14f3:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    14f6:	b8 01 00             	mov    ax,0x1
    14f9:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    14fc:	7f 33                	jg     0x1531
    14fe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1501:	eb 03                	jmp    0x1506
    1503:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1506:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1509:	99                   	cwd
    150a:	bf 28 14             	mov    di,0x1428
    150d:	9a 16 04 67 15       	call   0x1567:0x416
    1512:	6b f8 24             	imul   di,ax,0x24
    1515:	c4 bd 90 1e          	les    di,DWORD PTR [di+0x1e90]
    1519:	26 c4 3d             	les    di,DWORD PTR es:[di]
    151c:	06                   	push   es
    151d:	57                   	push   di
    151e:	9a d2 6d 41 15       	call   0x1541:0x6dd2
    1523:	22 46 ff             	and    al,BYTE PTR [bp-0x1]
    1526:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1529:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    152c:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    152f:	75 d2                	jne    0x1503
    1531:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1534:	50                   	push   ax
    1535:	c4 3e f4 1f          	les    di,DWORD PTR ds:0x1ff4
    1539:	26 c4 3d             	les    di,DWORD PTR es:[di]
    153c:	06                   	push   es
    153d:	57                   	push   di
    153e:	9a 11 6e 78 15       	call   0x1578:0x6e11
    1543:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1547:	a1 4e 01             	mov    ax,ds:0x14e
    154a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    154d:	b8 01 00             	mov    ax,0x1
    1550:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1553:	7f 33                	jg     0x1588
    1555:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1558:	eb 03                	jmp    0x155d
    155a:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    155d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1560:	99                   	cwd
    1561:	bf 28 14             	mov    di,0x1428
    1564:	9a 16 04 be 15       	call   0x15be:0x416
    1569:	6b f8 24             	imul   di,ax,0x24
    156c:	c4 bd 94 1e          	les    di,DWORD PTR [di+0x1e94]
    1570:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1573:	06                   	push   es
    1574:	57                   	push   di
    1575:	9a d2 6d 98 15       	call   0x1598:0x6dd2
    157a:	22 46 ff             	and    al,BYTE PTR [bp-0x1]
    157d:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1580:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1583:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1586:	75 d2                	jne    0x155a
    1588:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    158b:	50                   	push   ax
    158c:	c4 3e f8 1f          	les    di,DWORD PTR ds:0x1ff8
    1590:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1593:	06                   	push   es
    1594:	57                   	push   di
    1595:	9a 11 6e cf 15       	call   0x15cf:0x6e11
    159a:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    159e:	a1 4e 01             	mov    ax,ds:0x14e
    15a1:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    15a4:	b8 01 00             	mov    ax,0x1
    15a7:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    15aa:	7f 33                	jg     0x15df
    15ac:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    15af:	eb 03                	jmp    0x15b4
    15b1:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    15b4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    15b7:	99                   	cwd
    15b8:	bf 28 14             	mov    di,0x1428
    15bb:	9a 16 04 15 16       	call   0x1615:0x416
    15c0:	6b f8 24             	imul   di,ax,0x24
    15c3:	c4 bd 98 1e          	les    di,DWORD PTR [di+0x1e98]
    15c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    15ca:	06                   	push   es
    15cb:	57                   	push   di
    15cc:	9a d2 6d ef 15       	call   0x15ef:0x6dd2
    15d1:	22 46 ff             	and    al,BYTE PTR [bp-0x1]
    15d4:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    15d7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    15da:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    15dd:	75 d2                	jne    0x15b1
    15df:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    15e2:	50                   	push   ax
    15e3:	c4 3e fc 1f          	les    di,DWORD PTR ds:0x1ffc
    15e7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    15ea:	06                   	push   es
    15eb:	57                   	push   di
    15ec:	9a 11 6e 26 16       	call   0x1626:0x6e11
    15f1:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    15f5:	a1 4e 01             	mov    ax,ds:0x14e
    15f8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    15fb:	b8 01 00             	mov    ax,0x1
    15fe:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1601:	7f 33                	jg     0x1636
    1603:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1606:	eb 03                	jmp    0x160b
    1608:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    160b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    160e:	99                   	cwd
    160f:	bf 28 14             	mov    di,0x1428
    1612:	9a 16 04 5b 16       	call   0x165b:0x416
    1617:	6b f8 24             	imul   di,ax,0x24
    161a:	c4 bd 9c 1e          	les    di,DWORD PTR [di+0x1e9c]
    161e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1621:	06                   	push   es
    1622:	57                   	push   di
    1623:	9a d2 6d 46 16       	call   0x1646:0x6dd2
    1628:	22 46 ff             	and    al,BYTE PTR [bp-0x1]
    162b:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    162e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1631:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1634:	75 d2                	jne    0x1608
    1636:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1639:	50                   	push   ax
    163a:	c4 3e 00 20          	les    di,DWORD PTR ds:0x2000
    163e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1641:	06                   	push   es
    1642:	57                   	push   di
    1643:	9a 11 6e 87 16       	call   0x1687:0x6e11
    1648:	c9                   	leave
    1649:	cb                   	retf
    164a:	01 00                	add    WORD PTR [bx+si],ax
    164c:	00 00                	add    BYTE PTR [bx+si],al
    164e:	08 00                	or     BYTE PTR [bx+si],al
    1650:	00 00                	add    BYTE PTR [bx+si],al
    1652:	55                   	push   bp
    1653:	89 e5                	mov    bp,sp
    1655:	b8 04 00             	mov    ax,0x4
    1658:	9a 44 04 6a 16       	call   0x166a:0x444
    165d:	83 ec 04             	sub    sp,0x4
    1660:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1663:	99                   	cwd
    1664:	bf 4a 16             	mov    di,0x164a
    1667:	9a 16 04 11 17       	call   0x1711:0x416
    166c:	6b f8 24             	imul   di,ax,0x24
    166f:	81 c7 80 1e          	add    di,0x1e80
    1673:	1e                   	push   ds
    1674:	07                   	pop    es
    1675:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1678:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    167b:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    167f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1682:	06                   	push   es
    1683:	57                   	push   di
    1684:	9a d2 6d 99 16       	call   0x1699:0x6dd2
    1689:	50                   	push   ax
    168a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    168d:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    1691:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1694:	06                   	push   es
    1695:	57                   	push   di
    1696:	9a d2 6d ab 16       	call   0x16ab:0x6dd2
    169b:	50                   	push   ax
    169c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    169f:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    16a3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16a6:	06                   	push   es
    16a7:	57                   	push   di
    16a8:	9a d2 6d bd 16       	call   0x16bd:0x6dd2
    16ad:	50                   	push   ax
    16ae:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    16b1:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    16b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16b8:	06                   	push   es
    16b9:	57                   	push   di
    16ba:	9a d2 6d cf 16       	call   0x16cf:0x6dd2
    16bf:	50                   	push   ax
    16c0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    16c3:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    16c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16ca:	06                   	push   es
    16cb:	57                   	push   di
    16cc:	9a d2 6d e1 16       	call   0x16e1:0x6dd2
    16d1:	50                   	push   ax
    16d2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    16d5:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    16d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16dc:	06                   	push   es
    16dd:	57                   	push   di
    16de:	9a d2 6d 02 17       	call   0x1702:0x6dd2
    16e3:	5a                   	pop    dx
    16e4:	22 c2                	and    al,dl
    16e6:	5a                   	pop    dx
    16e7:	22 c2                	and    al,dl
    16e9:	5a                   	pop    dx
    16ea:	22 c2                	and    al,dl
    16ec:	5a                   	pop    dx
    16ed:	22 c2                	and    al,dl
    16ef:	5a                   	pop    dx
    16f0:	22 c2                	and    al,dl
    16f2:	50                   	push   ax
    16f3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    16f6:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    16fa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16fd:	06                   	push   es
    16fe:	57                   	push   di
    16ff:	9a 11 6e 20 17       	call   0x1720:0x6e11
    1704:	c9                   	leave
    1705:	ca 02 00             	retf   0x2
    1708:	55                   	push   bp
    1709:	89 e5                	mov    bp,sp
    170b:	b8 04 00             	mov    ax,0x4
    170e:	9a 44 04 27 17       	call   0x1727:0x444
    1713:	83 ec 04             	sub    sp,0x4
    1716:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1719:	ff 76 0a             	push   WORD PTR [bp+0xa]
    171c:	bf 22 27             	mov    di,0x2722
    171f:	b8 46 17             	mov    ax,0x1746
    1722:	50                   	push   ax
    1723:	57                   	push   di
    1724:	9a 73 22 64 17       	call   0x1764:0x2273
    1729:	89 c7                	mov    di,ax
    172b:	8e c2                	mov    es,dx
    172d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1730:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1733:	06                   	push   es
    1734:	57                   	push   di
    1735:	9a 58 62 8b 17       	call   0x178b:0x6258
    173a:	08 c0                	or     al,al
    173c:	74 19                	je     0x1757
    173e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1741:	06                   	push   es
    1742:	57                   	push   di
    1743:	9a d2 6d 55 17       	call   0x1755:0x6dd2
    1748:	50                   	push   ax
    1749:	c4 3e c8 1f          	les    di,DWORD PTR ds:0x1fc8
    174d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1750:	06                   	push   es
    1751:	57                   	push   di
    1752:	9a 11 6e 73 17       	call   0x1773:0x6e11
    1757:	c9                   	leave
    1758:	ca 08 00             	retf   0x8
    175b:	55                   	push   bp
    175c:	89 e5                	mov    bp,sp
    175e:	b8 04 00             	mov    ax,0x4
    1761:	9a 44 04 7a 17       	call   0x177a:0x444
    1766:	83 ec 04             	sub    sp,0x4
    1769:	ff 76 0c             	push   WORD PTR [bp+0xc]
    176c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    176f:	bf 22 27             	mov    di,0x2722
    1772:	b8 99 17             	mov    ax,0x1799
    1775:	50                   	push   ax
    1776:	57                   	push   di
    1777:	9a 73 22 bf 17       	call   0x17bf:0x2273
    177c:	89 c7                	mov    di,ax
    177e:	8e c2                	mov    es,dx
    1780:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1783:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1786:	06                   	push   es
    1787:	57                   	push   di
    1788:	9a 58 62 e6 17       	call   0x17e6:0x6258
    178d:	08 c0                	or     al,al
    178f:	74 19                	je     0x17aa
    1791:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1794:	06                   	push   es
    1795:	57                   	push   di
    1796:	9a d2 6d a8 17       	call   0x17a8:0x6dd2
    179b:	50                   	push   ax
    179c:	c4 3e cc 1f          	les    di,DWORD PTR ds:0x1fcc
    17a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17a3:	06                   	push   es
    17a4:	57                   	push   di
    17a5:	9a 11 6e ce 17       	call   0x17ce:0x6e11
    17aa:	c9                   	leave
    17ab:	ca 08 00             	retf   0x8
    17ae:	01 00                	add    WORD PTR [bx+si],ax
    17b0:	00 00                	add    BYTE PTR [bx+si],al
    17b2:	08 00                	or     BYTE PTR [bx+si],al
    17b4:	00 00                	add    BYTE PTR [bx+si],al
    17b6:	55                   	push   bp
    17b7:	89 e5                	mov    bp,sp
    17b9:	b8 0e 00             	mov    ax,0xe
    17bc:	9a 44 04 d5 17       	call   0x17d5:0x444
    17c1:	83 ec 0e             	sub    sp,0xe
    17c4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    17c7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    17ca:	bf 22 27             	mov    di,0x2722
    17cd:	b8 29 18             	mov    ax,0x1829
    17d0:	50                   	push   ax
    17d1:	57                   	push   di
    17d2:	9a 73 22 13 18       	call   0x1813:0x2273
    17d7:	89 c7                	mov    di,ax
    17d9:	8e c2                	mov    es,dx
    17db:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    17de:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    17e1:	06                   	push   es
    17e2:	57                   	push   di
    17e3:	9a 58 62 f0 18       	call   0x18f0:0x6258
    17e8:	08 c0                	or     al,al
    17ea:	75 03                	jne    0x17ef
    17ec:	e9 c5 00             	jmp    0x18b4
    17ef:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    17f3:	a1 4e 01             	mov    ax,ds:0x14e
    17f6:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    17f9:	b8 01 00             	mov    ax,0x1
    17fc:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    17ff:	7f 38                	jg     0x1839
    1801:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1804:	eb 03                	jmp    0x1809
    1806:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1809:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    180c:	99                   	cwd
    180d:	bf ae 17             	mov    di,0x17ae
    1810:	9a 16 04 67 18       	call   0x1867:0x416
    1815:	6b f8 24             	imul   di,ax,0x24
    1818:	81 c7 80 1e          	add    di,0x1e80
    181c:	1e                   	push   ds
    181d:	07                   	pop    es
    181e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1821:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1824:	06                   	push   es
    1825:	57                   	push   di
    1826:	9a d2 6d 41 18       	call   0x1841:0x6dd2
    182b:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    182e:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    1831:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1834:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1837:	75 cd                	jne    0x1806
    1839:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    183c:	06                   	push   es
    183d:	57                   	push   di
    183e:	9a d2 6d 7f 18       	call   0x187f:0x6dd2
    1843:	08 c0                	or     al,al
    1845:	74 42                	je     0x1889
    1847:	a1 4e 01             	mov    ax,ds:0x14e
    184a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    184d:	b8 01 00             	mov    ax,0x1
    1850:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1853:	7f 34                	jg     0x1889
    1855:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1858:	eb 03                	jmp    0x185d
    185a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    185d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1860:	99                   	cwd
    1861:	bf ae 17             	mov    di,0x17ae
    1864:	9a 16 04 c9 18       	call   0x18c9:0x416
    1869:	6b f8 24             	imul   di,ax,0x24
    186c:	81 c7 80 1e          	add    di,0x1e80
    1870:	1e                   	push   ds
    1871:	07                   	pop    es
    1872:	6a 01                	push   0x1
    1874:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1877:	26 c4 3d             	les    di,DWORD PTR es:[di]
    187a:	06                   	push   es
    187b:	57                   	push   di
    187c:	9a 11 6e 91 18       	call   0x1891:0x6e11
    1881:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1884:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1887:	75 d1                	jne    0x185a
    1889:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    188c:	06                   	push   es
    188d:	57                   	push   di
    188e:	9a d2 6d b2 18       	call   0x18b2:0x6dd2
    1893:	08 c0                	or     al,al
    1895:	b0 00                	mov    al,0x0
    1897:	75 01                	jne    0x189a
    1899:	40                   	inc    ax
    189a:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    189d:	08 c0                	or     al,al
    189f:	74 13                	je     0x18b4
    18a1:	6a 00                	push   0x0
    18a3:	9a b0 19 00 00       	call   0x0:0x19b0
    18a8:	6a 01                	push   0x1
    18aa:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    18ad:	06                   	push   es
    18ae:	57                   	push   di
    18af:	9a 11 6e d8 18       	call   0x18d8:0x6e11
    18b4:	c9                   	leave
    18b5:	ca 08 00             	retf   0x8
    18b8:	01 00                	add    WORD PTR [bx+si],ax
    18ba:	00 00                	add    BYTE PTR [bx+si],al
    18bc:	08 00                	or     BYTE PTR [bx+si],al
    18be:	00 00                	add    BYTE PTR [bx+si],al
    18c0:	55                   	push   bp
    18c1:	89 e5                	mov    bp,sp
    18c3:	b8 0e 00             	mov    ax,0xe
    18c6:	9a 44 04 df 18       	call   0x18df:0x444
    18cb:	83 ec 0e             	sub    sp,0xe
    18ce:	ff 76 0c             	push   WORD PTR [bp+0xc]
    18d1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    18d4:	bf 22 27             	mov    di,0x2722
    18d7:	b8 34 19             	mov    ax,0x1934
    18da:	50                   	push   ax
    18db:	57                   	push   di
    18dc:	9a 73 22 1d 19       	call   0x191d:0x2273
    18e1:	89 c7                	mov    di,ax
    18e3:	8e c2                	mov    es,dx
    18e5:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    18e8:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    18eb:	06                   	push   es
    18ec:	57                   	push   di
    18ed:	9a 58 62 fc 19       	call   0x19fc:0x6258
    18f2:	08 c0                	or     al,al
    18f4:	75 03                	jne    0x18f9
    18f6:	e9 c7 00             	jmp    0x19c0
    18f9:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    18fd:	a1 4e 01             	mov    ax,ds:0x14e
    1900:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1903:	b8 01 00             	mov    ax,0x1
    1906:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1909:	7f 39                	jg     0x1944
    190b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    190e:	eb 03                	jmp    0x1913
    1910:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1913:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1916:	99                   	cwd
    1917:	bf b8 18             	mov    di,0x18b8
    191a:	9a 16 04 72 19       	call   0x1972:0x416
    191f:	6b f8 24             	imul   di,ax,0x24
    1922:	81 c7 80 1e          	add    di,0x1e80
    1926:	1e                   	push   ds
    1927:	07                   	pop    es
    1928:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    192c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    192f:	06                   	push   es
    1930:	57                   	push   di
    1931:	9a d2 6d 4c 19       	call   0x194c:0x6dd2
    1936:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1939:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    193c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    193f:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1942:	75 cc                	jne    0x1910
    1944:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1947:	06                   	push   es
    1948:	57                   	push   di
    1949:	9a d2 6d 8b 19       	call   0x198b:0x6dd2
    194e:	08 c0                	or     al,al
    1950:	74 43                	je     0x1995
    1952:	a1 4e 01             	mov    ax,ds:0x14e
    1955:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1958:	b8 01 00             	mov    ax,0x1
    195b:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    195e:	7f 35                	jg     0x1995
    1960:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1963:	eb 03                	jmp    0x1968
    1965:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1968:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    196b:	99                   	cwd
    196c:	bf b8 18             	mov    di,0x18b8
    196f:	9a 16 04 d5 19       	call   0x19d5:0x416
    1974:	6b f8 24             	imul   di,ax,0x24
    1977:	81 c7 80 1e          	add    di,0x1e80
    197b:	1e                   	push   ds
    197c:	07                   	pop    es
    197d:	6a 01                	push   0x1
    197f:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    1983:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1986:	06                   	push   es
    1987:	57                   	push   di
    1988:	9a 11 6e 9d 19       	call   0x199d:0x6e11
    198d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1990:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1993:	75 d0                	jne    0x1965
    1995:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1998:	06                   	push   es
    1999:	57                   	push   di
    199a:	9a d2 6d be 19       	call   0x19be:0x6dd2
    199f:	08 c0                	or     al,al
    19a1:	b0 00                	mov    al,0x0
    19a3:	75 01                	jne    0x19a6
    19a5:	40                   	inc    ax
    19a6:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    19a9:	08 c0                	or     al,al
    19ab:	74 13                	je     0x19c0
    19ad:	6a 00                	push   0x0
    19af:	9a 9d 1b 00 00       	call   0x0:0x1b9d
    19b4:	6a 01                	push   0x1
    19b6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    19b9:	06                   	push   es
    19ba:	57                   	push   di
    19bb:	9a 11 6e e4 19       	call   0x19e4:0x6e11
    19c0:	c9                   	leave
    19c1:	ca 08 00             	retf   0x8
    19c4:	01 00                	add    WORD PTR [bx+si],ax
    19c6:	00 00                	add    BYTE PTR [bx+si],al
    19c8:	08 00                	or     BYTE PTR [bx+si],al
    19ca:	00 00                	add    BYTE PTR [bx+si],al
    19cc:	55                   	push   bp
    19cd:	89 e5                	mov    bp,sp
    19cf:	b8 0e 00             	mov    ax,0xe
    19d2:	9a 44 04 eb 19       	call   0x19eb:0x444
    19d7:	83 ec 0e             	sub    sp,0xe
    19da:	ff 76 0c             	push   WORD PTR [bp+0xc]
    19dd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    19e0:	bf 22 27             	mov    di,0x2722
    19e3:	b8 40 1a             	mov    ax,0x1a40
    19e6:	50                   	push   ax
    19e7:	57                   	push   di
    19e8:	9a 73 22 29 1a       	call   0x1a29:0x2273
    19ed:	89 c7                	mov    di,ax
    19ef:	8e c2                	mov    es,dx
    19f1:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    19f4:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    19f7:	06                   	push   es
    19f8:	57                   	push   di
    19f9:	9a 58 62 e9 1b       	call   0x1be9:0x6258
    19fe:	08 c0                	or     al,al
    1a00:	75 03                	jne    0x1a05
    1a02:	e9 a8 01             	jmp    0x1bad
    1a05:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    1a09:	a1 4e 01             	mov    ax,ds:0x14e
    1a0c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1a0f:	b8 01 00             	mov    ax,0x1
    1a12:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1a15:	7f 39                	jg     0x1a50
    1a17:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a1a:	eb 03                	jmp    0x1a1f
    1a1c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1a1f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1a22:	99                   	cwd
    1a23:	bf c4 19             	mov    di,0x19c4
    1a26:	9a 16 04 84 1a       	call   0x1a84:0x416
    1a2b:	6b f8 24             	imul   di,ax,0x24
    1a2e:	81 c7 80 1e          	add    di,0x1e80
    1a32:	1e                   	push   ds
    1a33:	07                   	pop    es
    1a34:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1a38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a3b:	06                   	push   es
    1a3c:	57                   	push   di
    1a3d:	9a d2 6d 58 1a       	call   0x1a58:0x6dd2
    1a42:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1a45:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    1a48:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1a4b:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1a4e:	75 cc                	jne    0x1a1c
    1a50:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1a53:	06                   	push   es
    1a54:	57                   	push   di
    1a55:	9a d2 6d a3 1a       	call   0x1aa3:0x6dd2
    1a5a:	08 c0                	or     al,al
    1a5c:	75 03                	jne    0x1a61
    1a5e:	e9 21 01             	jmp    0x1b82
    1a61:	a1 4e 01             	mov    ax,ds:0x14e
    1a64:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1a67:	b8 01 00             	mov    ax,0x1
    1a6a:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1a6d:	7e 03                	jle    0x1a72
    1a6f:	e9 b0 00             	jmp    0x1b22
    1a72:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a75:	eb 03                	jmp    0x1a7a
    1a77:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1a7a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1a7d:	99                   	cwd
    1a7e:	bf c4 19             	mov    di,0x19c4
    1a81:	9a 16 04 c2 1b       	call   0x1bc2:0x416
    1a86:	6b f8 24             	imul   di,ax,0x24
    1a89:	81 c7 80 1e          	add    di,0x1e80
    1a8d:	1e                   	push   ds
    1a8e:	07                   	pop    es
    1a8f:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    1a92:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    1a95:	6a 01                	push   0x1
    1a97:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1a9b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a9e:	06                   	push   es
    1a9f:	57                   	push   di
    1aa0:	9a 11 6e b6 1a       	call   0x1ab6:0x6e11
    1aa5:	6a 01                	push   0x1
    1aa7:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1aaa:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1aae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ab1:	06                   	push   es
    1ab2:	57                   	push   di
    1ab3:	9a 11 6e c9 1a       	call   0x1ac9:0x6e11
    1ab8:	6a 01                	push   0x1
    1aba:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1abd:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1ac1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ac4:	06                   	push   es
    1ac5:	57                   	push   di
    1ac6:	9a 11 6e dc 1a       	call   0x1adc:0x6e11
    1acb:	6a 01                	push   0x1
    1acd:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1ad0:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    1ad4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ad7:	06                   	push   es
    1ad8:	57                   	push   di
    1ad9:	9a 11 6e ef 1a       	call   0x1aef:0x6e11
    1ade:	6a 01                	push   0x1
    1ae0:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1ae3:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1ae7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1aea:	06                   	push   es
    1aeb:	57                   	push   di
    1aec:	9a 11 6e 02 1b       	call   0x1b02:0x6e11
    1af1:	6a 01                	push   0x1
    1af3:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1af6:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    1afa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1afd:	06                   	push   es
    1afe:	57                   	push   di
    1aff:	9a 11 6e 15 1b       	call   0x1b15:0x6e11
    1b04:	6a 01                	push   0x1
    1b06:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1b09:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    1b0d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b10:	06                   	push   es
    1b11:	57                   	push   di
    1b12:	9a 11 6e 30 1b       	call   0x1b30:0x6e11
    1b17:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b1a:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1b1d:	74 03                	je     0x1b22
    1b1f:	e9 55 ff             	jmp    0x1a77
    1b22:	6a 01                	push   0x1
    1b24:	c4 3e ec 1f          	les    di,DWORD PTR ds:0x1fec
    1b28:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b2b:	06                   	push   es
    1b2c:	57                   	push   di
    1b2d:	9a 11 6e 40 1b       	call   0x1b40:0x6e11
    1b32:	6a 01                	push   0x1
    1b34:	c4 3e f0 1f          	les    di,DWORD PTR ds:0x1ff0
    1b38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b3b:	06                   	push   es
    1b3c:	57                   	push   di
    1b3d:	9a 11 6e 50 1b       	call   0x1b50:0x6e11
    1b42:	6a 01                	push   0x1
    1b44:	c4 3e f4 1f          	les    di,DWORD PTR ds:0x1ff4
    1b48:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b4b:	06                   	push   es
    1b4c:	57                   	push   di
    1b4d:	9a 11 6e 60 1b       	call   0x1b60:0x6e11
    1b52:	6a 01                	push   0x1
    1b54:	c4 3e f8 1f          	les    di,DWORD PTR ds:0x1ff8
    1b58:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b5b:	06                   	push   es
    1b5c:	57                   	push   di
    1b5d:	9a 11 6e 70 1b       	call   0x1b70:0x6e11
    1b62:	6a 01                	push   0x1
    1b64:	c4 3e fc 1f          	les    di,DWORD PTR ds:0x1ffc
    1b68:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b6b:	06                   	push   es
    1b6c:	57                   	push   di
    1b6d:	9a 11 6e 80 1b       	call   0x1b80:0x6e11
    1b72:	6a 01                	push   0x1
    1b74:	c4 3e 00 20          	les    di,DWORD PTR ds:0x2000
    1b78:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b7b:	06                   	push   es
    1b7c:	57                   	push   di
    1b7d:	9a 11 6e 8a 1b       	call   0x1b8a:0x6e11
    1b82:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1b85:	06                   	push   es
    1b86:	57                   	push   di
    1b87:	9a d2 6d ab 1b       	call   0x1bab:0x6dd2
    1b8c:	08 c0                	or     al,al
    1b8e:	b0 00                	mov    al,0x0
    1b90:	75 01                	jne    0x1b93
    1b92:	40                   	inc    ax
    1b93:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1b96:	08 c0                	or     al,al
    1b98:	74 13                	je     0x1bad
    1b9a:	6a 00                	push   0x0
    1b9c:	9a b1 1c 00 00       	call   0x0:0x1cb1
    1ba1:	6a 01                	push   0x1
    1ba3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ba6:	06                   	push   es
    1ba7:	57                   	push   di
    1ba8:	9a 11 6e d1 1b       	call   0x1bd1:0x6e11
    1bad:	c9                   	leave
    1bae:	ca 08 00             	retf   0x8
    1bb1:	01 00                	add    WORD PTR [bx+si],ax
    1bb3:	00 00                	add    BYTE PTR [bx+si],al
    1bb5:	08 00                	or     BYTE PTR [bx+si],al
    1bb7:	00 00                	add    BYTE PTR [bx+si],al
    1bb9:	55                   	push   bp
    1bba:	89 e5                	mov    bp,sp
    1bbc:	b8 0e 00             	mov    ax,0xe
    1bbf:	9a 44 04 d8 1b       	call   0x1bd8:0x444
    1bc4:	83 ec 0e             	sub    sp,0xe
    1bc7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bca:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1bcd:	bf 22 27             	mov    di,0x2722
    1bd0:	b8 2d 1c             	mov    ax,0x1c2d
    1bd3:	50                   	push   ax
    1bd4:	57                   	push   di
    1bd5:	9a 73 22 16 1c       	call   0x1c16:0x2273
    1bda:	89 c7                	mov    di,ax
    1bdc:	8e c2                	mov    es,dx
    1bde:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1be1:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1be4:	06                   	push   es
    1be5:	57                   	push   di
    1be6:	9a 58 62 02 1d       	call   0x1d02:0x6258
    1beb:	08 c0                	or     al,al
    1bed:	75 03                	jne    0x1bf2
    1bef:	e9 d4 00             	jmp    0x1cc6
    1bf2:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    1bf6:	a1 4e 01             	mov    ax,ds:0x14e
    1bf9:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1bfc:	b8 01 00             	mov    ax,0x1
    1bff:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1c02:	7f 39                	jg     0x1c3d
    1c04:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1c07:	eb 03                	jmp    0x1c0c
    1c09:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1c0c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c0f:	99                   	cwd
    1c10:	bf b1 1b             	mov    di,0x1bb1
    1c13:	9a 16 04 6b 1c       	call   0x1c6b:0x416
    1c18:	6b f8 24             	imul   di,ax,0x24
    1c1b:	81 c7 80 1e          	add    di,0x1e80
    1c1f:	1e                   	push   ds
    1c20:	07                   	pop    es
    1c21:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1c25:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c28:	06                   	push   es
    1c29:	57                   	push   di
    1c2a:	9a d2 6d 45 1c       	call   0x1c45:0x6dd2
    1c2f:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1c32:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    1c35:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c38:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1c3b:	75 cc                	jne    0x1c09
    1c3d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c40:	06                   	push   es
    1c41:	57                   	push   di
    1c42:	9a d2 6d 84 1c       	call   0x1c84:0x6dd2
    1c47:	08 c0                	or     al,al
    1c49:	74 4b                	je     0x1c96
    1c4b:	a1 4e 01             	mov    ax,ds:0x14e
    1c4e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1c51:	b8 01 00             	mov    ax,0x1
    1c54:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1c57:	7f 3d                	jg     0x1c96
    1c59:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1c5c:	eb 03                	jmp    0x1c61
    1c5e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1c61:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c64:	99                   	cwd
    1c65:	bf b1 1b             	mov    di,0x1bb1
    1c68:	9a 16 04 db 1c       	call   0x1cdb:0x416
    1c6d:	6b f8 24             	imul   di,ax,0x24
    1c70:	81 c7 80 1e          	add    di,0x1e80
    1c74:	1e                   	push   ds
    1c75:	07                   	pop    es
    1c76:	6a 01                	push   0x1
    1c78:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    1c7c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c7f:	06                   	push   es
    1c80:	57                   	push   di
    1c81:	9a 11 6e 9e 1c       	call   0x1c9e:0x6e11
    1c86:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c89:	9a 52 16 c4 1c       	call   0x1cc4:0x1652
    1c8e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c91:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1c94:	75 c8                	jne    0x1c5e
    1c96:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c99:	06                   	push   es
    1c9a:	57                   	push   di
    1c9b:	9a d2 6d bf 1c       	call   0x1cbf:0x6dd2
    1ca0:	08 c0                	or     al,al
    1ca2:	b0 00                	mov    al,0x0
    1ca4:	75 01                	jne    0x1ca7
    1ca6:	40                   	inc    ax
    1ca7:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1caa:	08 c0                	or     al,al
    1cac:	74 13                	je     0x1cc1
    1cae:	6a 00                	push   0x0
    1cb0:	9a ca 1d 00 00       	call   0x0:0x1dca
    1cb5:	6a 01                	push   0x1
    1cb7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1cba:	06                   	push   es
    1cbb:	57                   	push   di
    1cbc:	9a 11 6e ea 1c       	call   0x1cea:0x6e11
    1cc1:	9a a5 13 a5 1d       	call   0x1da5:0x13a5
    1cc6:	c9                   	leave
    1cc7:	ca 08 00             	retf   0x8
    1cca:	01 00                	add    WORD PTR [bx+si],ax
    1ccc:	00 00                	add    BYTE PTR [bx+si],al
    1cce:	08 00                	or     BYTE PTR [bx+si],al
    1cd0:	00 00                	add    BYTE PTR [bx+si],al
    1cd2:	55                   	push   bp
    1cd3:	89 e5                	mov    bp,sp
    1cd5:	b8 0e 00             	mov    ax,0xe
    1cd8:	9a 44 04 f1 1c       	call   0x1cf1:0x444
    1cdd:	83 ec 0e             	sub    sp,0xe
    1ce0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ce3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1ce6:	bf 22 27             	mov    di,0x2722
    1ce9:	b8 46 1d             	mov    ax,0x1d46
    1cec:	50                   	push   ax
    1ced:	57                   	push   di
    1cee:	9a 73 22 2f 1d       	call   0x1d2f:0x2273
    1cf3:	89 c7                	mov    di,ax
    1cf5:	8e c2                	mov    es,dx
    1cf7:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1cfa:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1cfd:	06                   	push   es
    1cfe:	57                   	push   di
    1cff:	9a 58 62 1b 1e       	call   0x1e1b:0x6258
    1d04:	08 c0                	or     al,al
    1d06:	75 03                	jne    0x1d0b
    1d08:	e9 d4 00             	jmp    0x1ddf
    1d0b:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    1d0f:	a1 4e 01             	mov    ax,ds:0x14e
    1d12:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1d15:	b8 01 00             	mov    ax,0x1
    1d18:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1d1b:	7f 39                	jg     0x1d56
    1d1d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d20:	eb 03                	jmp    0x1d25
    1d22:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1d25:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d28:	99                   	cwd
    1d29:	bf ca 1c             	mov    di,0x1cca
    1d2c:	9a 16 04 84 1d       	call   0x1d84:0x416
    1d31:	6b f8 24             	imul   di,ax,0x24
    1d34:	81 c7 80 1e          	add    di,0x1e80
    1d38:	1e                   	push   ds
    1d39:	07                   	pop    es
    1d3a:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1d3e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d41:	06                   	push   es
    1d42:	57                   	push   di
    1d43:	9a d2 6d 5e 1d       	call   0x1d5e:0x6dd2
    1d48:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1d4b:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    1d4e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d51:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1d54:	75 cc                	jne    0x1d22
    1d56:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d59:	06                   	push   es
    1d5a:	57                   	push   di
    1d5b:	9a d2 6d 9d 1d       	call   0x1d9d:0x6dd2
    1d60:	08 c0                	or     al,al
    1d62:	74 4b                	je     0x1daf
    1d64:	a1 4e 01             	mov    ax,ds:0x14e
    1d67:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1d6a:	b8 01 00             	mov    ax,0x1
    1d6d:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1d70:	7f 3d                	jg     0x1daf
    1d72:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1d75:	eb 03                	jmp    0x1d7a
    1d77:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1d7a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d7d:	99                   	cwd
    1d7e:	bf ca 1c             	mov    di,0x1cca
    1d81:	9a 16 04 f4 1d       	call   0x1df4:0x416
    1d86:	6b f8 24             	imul   di,ax,0x24
    1d89:	81 c7 80 1e          	add    di,0x1e80
    1d8d:	1e                   	push   ds
    1d8e:	07                   	pop    es
    1d8f:	6a 01                	push   0x1
    1d91:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    1d95:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d98:	06                   	push   es
    1d99:	57                   	push   di
    1d9a:	9a 11 6e b7 1d       	call   0x1db7:0x6e11
    1d9f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1da2:	9a 52 16 dd 1d       	call   0x1ddd:0x1652
    1da7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1daa:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1dad:	75 c8                	jne    0x1d77
    1daf:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1db2:	06                   	push   es
    1db3:	57                   	push   di
    1db4:	9a d2 6d d8 1d       	call   0x1dd8:0x6dd2
    1db9:	08 c0                	or     al,al
    1dbb:	b0 00                	mov    al,0x0
    1dbd:	75 01                	jne    0x1dc0
    1dbf:	40                   	inc    ax
    1dc0:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1dc3:	08 c0                	or     al,al
    1dc5:	74 13                	je     0x1dda
    1dc7:	6a 00                	push   0x0
    1dc9:	9a e3 1e 00 00       	call   0x0:0x1ee3
    1dce:	6a 01                	push   0x1
    1dd0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1dd3:	06                   	push   es
    1dd4:	57                   	push   di
    1dd5:	9a 11 6e 03 1e       	call   0x1e03:0x6e11
    1dda:	9a a5 13 be 1e       	call   0x1ebe:0x13a5
    1ddf:	c9                   	leave
    1de0:	ca 08 00             	retf   0x8
    1de3:	01 00                	add    WORD PTR [bx+si],ax
    1de5:	00 00                	add    BYTE PTR [bx+si],al
    1de7:	08 00                	or     BYTE PTR [bx+si],al
    1de9:	00 00                	add    BYTE PTR [bx+si],al
    1deb:	55                   	push   bp
    1dec:	89 e5                	mov    bp,sp
    1dee:	b8 0e 00             	mov    ax,0xe
    1df1:	9a 44 04 0a 1e       	call   0x1e0a:0x444
    1df6:	83 ec 0e             	sub    sp,0xe
    1df9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1dfc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1dff:	bf 22 27             	mov    di,0x2722
    1e02:	b8 5f 1e             	mov    ax,0x1e5f
    1e05:	50                   	push   ax
    1e06:	57                   	push   di
    1e07:	9a 73 22 48 1e       	call   0x1e48:0x2273
    1e0c:	89 c7                	mov    di,ax
    1e0e:	8e c2                	mov    es,dx
    1e10:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1e13:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1e16:	06                   	push   es
    1e17:	57                   	push   di
    1e18:	9a 58 62 34 1f       	call   0x1f34:0x6258
    1e1d:	08 c0                	or     al,al
    1e1f:	75 03                	jne    0x1e24
    1e21:	e9 d4 00             	jmp    0x1ef8
    1e24:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    1e28:	a1 4e 01             	mov    ax,ds:0x14e
    1e2b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1e2e:	b8 01 00             	mov    ax,0x1
    1e31:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1e34:	7f 39                	jg     0x1e6f
    1e36:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e39:	eb 03                	jmp    0x1e3e
    1e3b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1e3e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e41:	99                   	cwd
    1e42:	bf e3 1d             	mov    di,0x1de3
    1e45:	9a 16 04 9d 1e       	call   0x1e9d:0x416
    1e4a:	6b f8 24             	imul   di,ax,0x24
    1e4d:	81 c7 80 1e          	add    di,0x1e80
    1e51:	1e                   	push   ds
    1e52:	07                   	pop    es
    1e53:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    1e57:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e5a:	06                   	push   es
    1e5b:	57                   	push   di
    1e5c:	9a d2 6d 77 1e       	call   0x1e77:0x6dd2
    1e61:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1e64:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    1e67:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e6a:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1e6d:	75 cc                	jne    0x1e3b
    1e6f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1e72:	06                   	push   es
    1e73:	57                   	push   di
    1e74:	9a d2 6d b6 1e       	call   0x1eb6:0x6dd2
    1e79:	08 c0                	or     al,al
    1e7b:	74 4b                	je     0x1ec8
    1e7d:	a1 4e 01             	mov    ax,ds:0x14e
    1e80:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1e83:	b8 01 00             	mov    ax,0x1
    1e86:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1e89:	7f 3d                	jg     0x1ec8
    1e8b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e8e:	eb 03                	jmp    0x1e93
    1e90:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1e93:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e96:	99                   	cwd
    1e97:	bf e3 1d             	mov    di,0x1de3
    1e9a:	9a 16 04 0d 1f       	call   0x1f0d:0x416
    1e9f:	6b f8 24             	imul   di,ax,0x24
    1ea2:	81 c7 80 1e          	add    di,0x1e80
    1ea6:	1e                   	push   ds
    1ea7:	07                   	pop    es
    1ea8:	6a 01                	push   0x1
    1eaa:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    1eae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1eb1:	06                   	push   es
    1eb2:	57                   	push   di
    1eb3:	9a 11 6e d0 1e       	call   0x1ed0:0x6e11
    1eb8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ebb:	9a 52 16 f6 1e       	call   0x1ef6:0x1652
    1ec0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ec3:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1ec6:	75 c8                	jne    0x1e90
    1ec8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ecb:	06                   	push   es
    1ecc:	57                   	push   di
    1ecd:	9a d2 6d f1 1e       	call   0x1ef1:0x6dd2
    1ed2:	08 c0                	or     al,al
    1ed4:	b0 00                	mov    al,0x0
    1ed6:	75 01                	jne    0x1ed9
    1ed8:	40                   	inc    ax
    1ed9:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1edc:	08 c0                	or     al,al
    1ede:	74 13                	je     0x1ef3
    1ee0:	6a 00                	push   0x0
    1ee2:	9a fc 1f 00 00       	call   0x0:0x1ffc
    1ee7:	6a 01                	push   0x1
    1ee9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1eec:	06                   	push   es
    1eed:	57                   	push   di
    1eee:	9a 11 6e 1c 1f       	call   0x1f1c:0x6e11
    1ef3:	9a a5 13 d7 1f       	call   0x1fd7:0x13a5
    1ef8:	c9                   	leave
    1ef9:	ca 08 00             	retf   0x8
    1efc:	01 00                	add    WORD PTR [bx+si],ax
    1efe:	00 00                	add    BYTE PTR [bx+si],al
    1f00:	08 00                	or     BYTE PTR [bx+si],al
    1f02:	00 00                	add    BYTE PTR [bx+si],al
    1f04:	55                   	push   bp
    1f05:	89 e5                	mov    bp,sp
    1f07:	b8 0e 00             	mov    ax,0xe
    1f0a:	9a 44 04 23 1f       	call   0x1f23:0x444
    1f0f:	83 ec 0e             	sub    sp,0xe
    1f12:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f15:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f18:	bf 22 27             	mov    di,0x2722
    1f1b:	b8 78 1f             	mov    ax,0x1f78
    1f1e:	50                   	push   ax
    1f1f:	57                   	push   di
    1f20:	9a 73 22 61 1f       	call   0x1f61:0x2273
    1f25:	89 c7                	mov    di,ax
    1f27:	8e c2                	mov    es,dx
    1f29:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1f2c:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1f2f:	06                   	push   es
    1f30:	57                   	push   di
    1f31:	9a 58 62 4d 20       	call   0x204d:0x6258
    1f36:	08 c0                	or     al,al
    1f38:	75 03                	jne    0x1f3d
    1f3a:	e9 d4 00             	jmp    0x2011
    1f3d:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    1f41:	a1 4e 01             	mov    ax,ds:0x14e
    1f44:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1f47:	b8 01 00             	mov    ax,0x1
    1f4a:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1f4d:	7f 39                	jg     0x1f88
    1f4f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f52:	eb 03                	jmp    0x1f57
    1f54:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1f57:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f5a:	99                   	cwd
    1f5b:	bf fc 1e             	mov    di,0x1efc
    1f5e:	9a 16 04 b6 1f       	call   0x1fb6:0x416
    1f63:	6b f8 24             	imul   di,ax,0x24
    1f66:	81 c7 80 1e          	add    di,0x1e80
    1f6a:	1e                   	push   ds
    1f6b:	07                   	pop    es
    1f6c:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1f70:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f73:	06                   	push   es
    1f74:	57                   	push   di
    1f75:	9a d2 6d 90 1f       	call   0x1f90:0x6dd2
    1f7a:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1f7d:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    1f80:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f83:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1f86:	75 cc                	jne    0x1f54
    1f88:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1f8b:	06                   	push   es
    1f8c:	57                   	push   di
    1f8d:	9a d2 6d cf 1f       	call   0x1fcf:0x6dd2
    1f92:	08 c0                	or     al,al
    1f94:	74 4b                	je     0x1fe1
    1f96:	a1 4e 01             	mov    ax,ds:0x14e
    1f99:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1f9c:	b8 01 00             	mov    ax,0x1
    1f9f:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1fa2:	7f 3d                	jg     0x1fe1
    1fa4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1fa7:	eb 03                	jmp    0x1fac
    1fa9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1fac:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1faf:	99                   	cwd
    1fb0:	bf fc 1e             	mov    di,0x1efc
    1fb3:	9a 16 04 26 20       	call   0x2026:0x416
    1fb8:	6b f8 24             	imul   di,ax,0x24
    1fbb:	81 c7 80 1e          	add    di,0x1e80
    1fbf:	1e                   	push   ds
    1fc0:	07                   	pop    es
    1fc1:	6a 01                	push   0x1
    1fc3:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    1fc7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1fca:	06                   	push   es
    1fcb:	57                   	push   di
    1fcc:	9a 11 6e e9 1f       	call   0x1fe9:0x6e11
    1fd1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fd4:	9a 52 16 0f 20       	call   0x200f:0x1652
    1fd9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1fdc:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1fdf:	75 c8                	jne    0x1fa9
    1fe1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1fe4:	06                   	push   es
    1fe5:	57                   	push   di
    1fe6:	9a d2 6d 0a 20       	call   0x200a:0x6dd2
    1feb:	08 c0                	or     al,al
    1fed:	b0 00                	mov    al,0x0
    1fef:	75 01                	jne    0x1ff2
    1ff1:	40                   	inc    ax
    1ff2:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    1ff5:	08 c0                	or     al,al
    1ff7:	74 13                	je     0x200c
    1ff9:	6a 00                	push   0x0
    1ffb:	9a 15 21 00 00       	call   0x0:0x2115
    2000:	6a 01                	push   0x1
    2002:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2005:	06                   	push   es
    2006:	57                   	push   di
    2007:	9a 11 6e 35 20       	call   0x2035:0x6e11
    200c:	9a a5 13 f0 20       	call   0x20f0:0x13a5
    2011:	c9                   	leave
    2012:	ca 08 00             	retf   0x8
    2015:	01 00                	add    WORD PTR [bx+si],ax
    2017:	00 00                	add    BYTE PTR [bx+si],al
    2019:	08 00                	or     BYTE PTR [bx+si],al
    201b:	00 00                	add    BYTE PTR [bx+si],al
    201d:	55                   	push   bp
    201e:	89 e5                	mov    bp,sp
    2020:	b8 0e 00             	mov    ax,0xe
    2023:	9a 44 04 3c 20       	call   0x203c:0x444
    2028:	83 ec 0e             	sub    sp,0xe
    202b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    202e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2031:	bf 22 27             	mov    di,0x2722
    2034:	b8 91 20             	mov    ax,0x2091
    2037:	50                   	push   ax
    2038:	57                   	push   di
    2039:	9a 73 22 7a 20       	call   0x207a:0x2273
    203e:	89 c7                	mov    di,ax
    2040:	8e c2                	mov    es,dx
    2042:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2045:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2048:	06                   	push   es
    2049:	57                   	push   di
    204a:	9a 58 62 66 21       	call   0x2166:0x6258
    204f:	08 c0                	or     al,al
    2051:	75 03                	jne    0x2056
    2053:	e9 d4 00             	jmp    0x212a
    2056:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    205a:	a1 4e 01             	mov    ax,ds:0x14e
    205d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2060:	b8 01 00             	mov    ax,0x1
    2063:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2066:	7f 39                	jg     0x20a1
    2068:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    206b:	eb 03                	jmp    0x2070
    206d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2070:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2073:	99                   	cwd
    2074:	bf 15 20             	mov    di,0x2015
    2077:	9a 16 04 cf 20       	call   0x20cf:0x416
    207c:	6b f8 24             	imul   di,ax,0x24
    207f:	81 c7 80 1e          	add    di,0x1e80
    2083:	1e                   	push   ds
    2084:	07                   	pop    es
    2085:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    2089:	26 c4 3d             	les    di,DWORD PTR es:[di]
    208c:	06                   	push   es
    208d:	57                   	push   di
    208e:	9a d2 6d a9 20       	call   0x20a9:0x6dd2
    2093:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    2096:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    2099:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    209c:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    209f:	75 cc                	jne    0x206d
    20a1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    20a4:	06                   	push   es
    20a5:	57                   	push   di
    20a6:	9a d2 6d e8 20       	call   0x20e8:0x6dd2
    20ab:	08 c0                	or     al,al
    20ad:	74 4b                	je     0x20fa
    20af:	a1 4e 01             	mov    ax,ds:0x14e
    20b2:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    20b5:	b8 01 00             	mov    ax,0x1
    20b8:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    20bb:	7f 3d                	jg     0x20fa
    20bd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    20c0:	eb 03                	jmp    0x20c5
    20c2:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    20c5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    20c8:	99                   	cwd
    20c9:	bf 15 20             	mov    di,0x2015
    20cc:	9a 16 04 3f 21       	call   0x213f:0x416
    20d1:	6b f8 24             	imul   di,ax,0x24
    20d4:	81 c7 80 1e          	add    di,0x1e80
    20d8:	1e                   	push   ds
    20d9:	07                   	pop    es
    20da:	6a 01                	push   0x1
    20dc:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    20e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20e3:	06                   	push   es
    20e4:	57                   	push   di
    20e5:	9a 11 6e 02 21       	call   0x2102:0x6e11
    20ea:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20ed:	9a 52 16 28 21       	call   0x2128:0x1652
    20f2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    20f5:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    20f8:	75 c8                	jne    0x20c2
    20fa:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    20fd:	06                   	push   es
    20fe:	57                   	push   di
    20ff:	9a d2 6d 23 21       	call   0x2123:0x6dd2
    2104:	08 c0                	or     al,al
    2106:	b0 00                	mov    al,0x0
    2108:	75 01                	jne    0x210b
    210a:	40                   	inc    ax
    210b:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    210e:	08 c0                	or     al,al
    2110:	74 13                	je     0x2125
    2112:	6a 00                	push   0x0
    2114:	9a 2e 22 00 00       	call   0x0:0x222e
    2119:	6a 01                	push   0x1
    211b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    211e:	06                   	push   es
    211f:	57                   	push   di
    2120:	9a 11 6e 4e 21       	call   0x214e:0x6e11
    2125:	9a a5 13 09 22       	call   0x2209:0x13a5
    212a:	c9                   	leave
    212b:	ca 08 00             	retf   0x8
    212e:	01 00                	add    WORD PTR [bx+si],ax
    2130:	00 00                	add    BYTE PTR [bx+si],al
    2132:	08 00                	or     BYTE PTR [bx+si],al
    2134:	00 00                	add    BYTE PTR [bx+si],al
    2136:	55                   	push   bp
    2137:	89 e5                	mov    bp,sp
    2139:	b8 0e 00             	mov    ax,0xe
    213c:	9a 44 04 55 21       	call   0x2155:0x444
    2141:	83 ec 0e             	sub    sp,0xe
    2144:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2147:	ff 76 0a             	push   WORD PTR [bp+0xa]
    214a:	bf 22 27             	mov    di,0x2722
    214d:	b8 aa 21             	mov    ax,0x21aa
    2150:	50                   	push   ax
    2151:	57                   	push   di
    2152:	9a 73 22 93 21       	call   0x2193:0x2273
    2157:	89 c7                	mov    di,ax
    2159:	8e c2                	mov    es,dx
    215b:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    215e:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2161:	06                   	push   es
    2162:	57                   	push   di
    2163:	9a 58 62 77 22       	call   0x2277:0x6258
    2168:	08 c0                	or     al,al
    216a:	75 03                	jne    0x216f
    216c:	e9 d4 00             	jmp    0x2243
    216f:	c6 46 fd 01          	mov    BYTE PTR [bp-0x3],0x1
    2173:	a1 4e 01             	mov    ax,ds:0x14e
    2176:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2179:	b8 01 00             	mov    ax,0x1
    217c:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    217f:	7f 39                	jg     0x21ba
    2181:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2184:	eb 03                	jmp    0x2189
    2186:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2189:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    218c:	99                   	cwd
    218d:	bf 2e 21             	mov    di,0x212e
    2190:	9a 16 04 e8 21       	call   0x21e8:0x416
    2195:	6b f8 24             	imul   di,ax,0x24
    2198:	81 c7 80 1e          	add    di,0x1e80
    219c:	1e                   	push   ds
    219d:	07                   	pop    es
    219e:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    21a2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21a5:	06                   	push   es
    21a6:	57                   	push   di
    21a7:	9a d2 6d c2 21       	call   0x21c2:0x6dd2
    21ac:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    21af:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    21b2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    21b5:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    21b8:	75 cc                	jne    0x2186
    21ba:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    21bd:	06                   	push   es
    21be:	57                   	push   di
    21bf:	9a d2 6d 01 22       	call   0x2201:0x6dd2
    21c4:	08 c0                	or     al,al
    21c6:	74 4b                	je     0x2213
    21c8:	a1 4e 01             	mov    ax,ds:0x14e
    21cb:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    21ce:	b8 01 00             	mov    ax,0x1
    21d1:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    21d4:	7f 3d                	jg     0x2213
    21d6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    21d9:	eb 03                	jmp    0x21de
    21db:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    21de:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    21e1:	99                   	cwd
    21e2:	bf 2e 21             	mov    di,0x212e
    21e5:	9a 16 04 50 22       	call   0x2250:0x416
    21ea:	6b f8 24             	imul   di,ax,0x24
    21ed:	81 c7 80 1e          	add    di,0x1e80
    21f1:	1e                   	push   ds
    21f2:	07                   	pop    es
    21f3:	6a 01                	push   0x1
    21f5:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    21f9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21fc:	06                   	push   es
    21fd:	57                   	push   di
    21fe:	9a 11 6e 1b 22       	call   0x221b:0x6e11
    2203:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2206:	9a 52 16 41 22       	call   0x2241:0x1652
    220b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    220e:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2211:	75 c8                	jne    0x21db
    2213:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2216:	06                   	push   es
    2217:	57                   	push   di
    2218:	9a d2 6d 3c 22       	call   0x223c:0x6dd2
    221d:	08 c0                	or     al,al
    221f:	b0 00                	mov    al,0x0
    2221:	75 01                	jne    0x2224
    2223:	40                   	inc    ax
    2224:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    2227:	08 c0                	or     al,al
    2229:	74 13                	je     0x223e
    222b:	6a 00                	push   0x0
    222d:	9a 65 25 00 00       	call   0x0:0x2565
    2232:	6a 01                	push   0x1
    2234:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2237:	06                   	push   es
    2238:	57                   	push   di
    2239:	9a 11 6e 5f 22       	call   0x225f:0x6e11
    223e:	9a a5 13 20 23       	call   0x2320:0x13a5
    2243:	c9                   	leave
    2244:	ca 08 00             	retf   0x8
    2247:	55                   	push   bp
    2248:	89 e5                	mov    bp,sp
    224a:	b8 04 00             	mov    ax,0x4
    224d:	9a 44 04 66 22       	call   0x2266:0x444
    2252:	83 ec 04             	sub    sp,0x4
    2255:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2258:	ff 76 0a             	push   WORD PTR [bp+0xa]
    225b:	bf 22 27             	mov    di,0x2722
    225e:	b8 85 22             	mov    ax,0x2285
    2261:	50                   	push   ax
    2262:	57                   	push   di
    2263:	9a 73 22 a3 22       	call   0x22a3:0x2273
    2268:	89 c7                	mov    di,ax
    226a:	8e c2                	mov    es,dx
    226c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    226f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2272:	06                   	push   es
    2273:	57                   	push   di
    2274:	9a 58 62 ca 22       	call   0x22ca:0x6258
    2279:	08 c0                	or     al,al
    227b:	74 19                	je     0x2296
    227d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2280:	06                   	push   es
    2281:	57                   	push   di
    2282:	9a d2 6d 94 22       	call   0x2294:0x6dd2
    2287:	50                   	push   ax
    2288:	c4 3e d8 1f          	les    di,DWORD PTR ds:0x1fd8
    228c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    228f:	06                   	push   es
    2290:	57                   	push   di
    2291:	9a 11 6e b2 22       	call   0x22b2:0x6e11
    2296:	c9                   	leave
    2297:	ca 08 00             	retf   0x8
    229a:	55                   	push   bp
    229b:	89 e5                	mov    bp,sp
    229d:	b8 04 00             	mov    ax,0x4
    22a0:	9a 44 04 b9 22       	call   0x22b9:0x444
    22a5:	83 ec 04             	sub    sp,0x4
    22a8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    22ab:	ff 76 0a             	push   WORD PTR [bp+0xa]
    22ae:	bf 22 27             	mov    di,0x2722
    22b1:	b8 d8 22             	mov    ax,0x22d8
    22b4:	50                   	push   ax
    22b5:	57                   	push   di
    22b6:	9a 73 22 f6 22       	call   0x22f6:0x2273
    22bb:	89 c7                	mov    di,ax
    22bd:	8e c2                	mov    es,dx
    22bf:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    22c2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    22c5:	06                   	push   es
    22c6:	57                   	push   di
    22c7:	9a 58 62 17 23       	call   0x2317:0x6258
    22cc:	08 c0                	or     al,al
    22ce:	74 19                	je     0x22e9
    22d0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22d3:	06                   	push   es
    22d4:	57                   	push   di
    22d5:	9a d2 6d e7 22       	call   0x22e7:0x6dd2
    22da:	50                   	push   ax
    22db:	c4 3e dc 1f          	les    di,DWORD PTR ds:0x1fdc
    22df:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22e2:	06                   	push   es
    22e3:	57                   	push   di
    22e4:	9a 11 6e 05 23       	call   0x2305:0x6e11
    22e9:	c9                   	leave
    22ea:	ca 08 00             	retf   0x8
    22ed:	55                   	push   bp
    22ee:	89 e5                	mov    bp,sp
    22f0:	b8 04 00             	mov    ax,0x4
    22f3:	9a 44 04 0c 23       	call   0x230c:0x444
    22f8:	83 ec 04             	sub    sp,0x4
    22fb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    22fe:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2301:	bf 22 27             	mov    di,0x2722
    2304:	b8 3e 23             	mov    ax,0x233e
    2307:	50                   	push   ax
    2308:	57                   	push   di
    2309:	9a 73 22 2f 23       	call   0x232f:0x2273
    230e:	89 c7                	mov    di,ax
    2310:	8e c2                	mov    es,dx
    2312:	06                   	push   es
    2313:	57                   	push   di
    2314:	9a 58 62 50 23       	call   0x2350:0x6258
    2319:	08 c0                	or     al,al
    231b:	74 05                	je     0x2322
    231d:	9a cf 12 59 23       	call   0x2359:0x12cf
    2322:	c9                   	leave
    2323:	ca 08 00             	retf   0x8
    2326:	55                   	push   bp
    2327:	89 e5                	mov    bp,sp
    2329:	b8 04 00             	mov    ax,0x4
    232c:	9a 44 04 45 23       	call   0x2345:0x444
    2331:	83 ec 04             	sub    sp,0x4
    2334:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2337:	ff 76 0a             	push   WORD PTR [bp+0xa]
    233a:	bf 22 27             	mov    di,0x2722
    233d:	b8 77 23             	mov    ax,0x2377
    2340:	50                   	push   ax
    2341:	57                   	push   di
    2342:	9a 73 22 68 23       	call   0x2368:0x2273
    2347:	89 c7                	mov    di,ax
    2349:	8e c2                	mov    es,dx
    234b:	06                   	push   es
    234c:	57                   	push   di
    234d:	9a 58 62 89 23       	call   0x2389:0x6258
    2352:	08 c0                	or     al,al
    2354:	74 05                	je     0x235b
    2356:	9a 3e 13 af 23       	call   0x23af:0x133e
    235b:	c9                   	leave
    235c:	ca 08 00             	retf   0x8
    235f:	55                   	push   bp
    2360:	89 e5                	mov    bp,sp
    2362:	b8 06 00             	mov    ax,0x6
    2365:	9a 44 04 7e 23       	call   0x237e:0x444
    236a:	83 ec 06             	sub    sp,0x6
    236d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2370:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2373:	bf 22 27             	mov    di,0x2722
    2376:	b8 df 23             	mov    ax,0x23df
    2379:	50                   	push   ax
    237a:	57                   	push   di
    237b:	9a 73 22 a4 23       	call   0x23a4:0x2273
    2380:	89 c7                	mov    di,ax
    2382:	8e c2                	mov    es,dx
    2384:	06                   	push   es
    2385:	57                   	push   di
    2386:	9a 58 62 f7 23       	call   0x23f7:0x6258
    238b:	08 c0                	or     al,al
    238d:	74 2c                	je     0x23bb
    238f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2392:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2397:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    239c:	05 01 00             	add    ax,0x1
    239f:	71 05                	jno    0x23a6
    23a1:	9a 3e 04 d0 23       	call   0x23d0:0x43e
    23a6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    23a9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    23ac:	9a 52 16 b4 23       	call   0x23b4:0x1652
    23b1:	9a 30 14 b9 23       	call   0x23b9:0x1430
    23b6:	9a a5 13 78 25       	call   0x2578:0x13a5
    23bb:	c9                   	leave
    23bc:	ca 08 00             	retf   0x8
    23bf:	01 00                	add    WORD PTR [bx+si],ax
    23c1:	00 00                	add    BYTE PTR [bx+si],al
    23c3:	08 00                	or     BYTE PTR [bx+si],al
    23c5:	00 00                	add    BYTE PTR [bx+si],al
    23c7:	55                   	push   bp
    23c8:	89 e5                	mov    bp,sp
    23ca:	b8 0c 00             	mov    ax,0xc
    23cd:	9a 44 04 e6 23       	call   0x23e6:0x444
    23d2:	83 ec 0c             	sub    sp,0xc
    23d5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23d8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23db:	bf 22 27             	mov    di,0x2722
    23de:	b8 41 24             	mov    ax,0x2441
    23e1:	50                   	push   ax
    23e2:	57                   	push   di
    23e3:	9a 73 22 15 24       	call   0x2415:0x2273
    23e8:	89 c7                	mov    di,ax
    23ea:	8e c2                	mov    es,dx
    23ec:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    23ef:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    23f2:	06                   	push   es
    23f3:	57                   	push   di
    23f4:	9a 58 62 cd 25       	call   0x25cd:0x6258
    23f9:	08 c0                	or     al,al
    23fb:	75 03                	jne    0x2400
    23fd:	e9 7f 01             	jmp    0x257f
    2400:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2403:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2408:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    240d:	05 01 00             	add    ax,0x1
    2410:	71 05                	jno    0x2417
    2412:	9a 3e 04 24 24       	call   0x2424:0x43e
    2417:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    241a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    241d:	99                   	cwd
    241e:	bf bf 23             	mov    di,0x23bf
    2421:	9a 16 04 ca 24       	call   0x24ca:0x416
    2426:	6b f8 24             	imul   di,ax,0x24
    2429:	81 c7 80 1e          	add    di,0x1e80
    242d:	1e                   	push   ds
    242e:	07                   	pop    es
    242f:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    2432:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    2435:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    2439:	26 c4 3d             	les    di,DWORD PTR es:[di]
    243c:	06                   	push   es
    243d:	57                   	push   di
    243e:	9a d2 6d 53 24       	call   0x2453:0x6dd2
    2443:	50                   	push   ax
    2444:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2447:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    244b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    244e:	06                   	push   es
    244f:	57                   	push   di
    2450:	9a d2 6d 65 24       	call   0x2465:0x6dd2
    2455:	50                   	push   ax
    2456:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2459:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    245d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2460:	06                   	push   es
    2461:	57                   	push   di
    2462:	9a d2 6d 77 24       	call   0x2477:0x6dd2
    2467:	50                   	push   ax
    2468:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    246b:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    246f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2472:	06                   	push   es
    2473:	57                   	push   di
    2474:	9a d2 6d 89 24       	call   0x2489:0x6dd2
    2479:	50                   	push   ax
    247a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    247d:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    2481:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2484:	06                   	push   es
    2485:	57                   	push   di
    2486:	9a d2 6d 9b 24       	call   0x249b:0x6dd2
    248b:	50                   	push   ax
    248c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    248f:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2493:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2496:	06                   	push   es
    2497:	57                   	push   di
    2498:	9a d2 6d b7 24       	call   0x24b7:0x6dd2
    249d:	5a                   	pop    dx
    249e:	22 c2                	and    al,dl
    24a0:	5a                   	pop    dx
    24a1:	22 c2                	and    al,dl
    24a3:	5a                   	pop    dx
    24a4:	22 c2                	and    al,dl
    24a6:	5a                   	pop    dx
    24a7:	22 c2                	and    al,dl
    24a9:	5a                   	pop    dx
    24aa:	22 c2                	and    al,dl
    24ac:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    24af:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    24b2:	06                   	push   es
    24b3:	57                   	push   di
    24b4:	9a d2 6d e9 24       	call   0x24e9:0x6dd2
    24b9:	08 c0                	or     al,al
    24bb:	75 03                	jne    0x24c0
    24bd:	e9 8a 00             	jmp    0x254a
    24c0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    24c3:	99                   	cwd
    24c4:	bf bf 23             	mov    di,0x23bf
    24c7:	9a 16 04 9c 25       	call   0x259c:0x416
    24cc:	6b f8 24             	imul   di,ax,0x24
    24cf:	81 c7 80 1e          	add    di,0x1e80
    24d3:	1e                   	push   ds
    24d4:	07                   	pop    es
    24d5:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    24d8:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    24db:	6a 01                	push   0x1
    24dd:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    24e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24e4:	06                   	push   es
    24e5:	57                   	push   di
    24e6:	9a 11 6e fc 24       	call   0x24fc:0x6e11
    24eb:	6a 01                	push   0x1
    24ed:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    24f0:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    24f4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24f7:	06                   	push   es
    24f8:	57                   	push   di
    24f9:	9a 11 6e 0f 25       	call   0x250f:0x6e11
    24fe:	6a 01                	push   0x1
    2500:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2503:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    2507:	26 c4 3d             	les    di,DWORD PTR es:[di]
    250a:	06                   	push   es
    250b:	57                   	push   di
    250c:	9a 11 6e 22 25       	call   0x2522:0x6e11
    2511:	6a 01                	push   0x1
    2513:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2516:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    251a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    251d:	06                   	push   es
    251e:	57                   	push   di
    251f:	9a 11 6e 35 25       	call   0x2535:0x6e11
    2524:	6a 01                	push   0x1
    2526:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2529:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    252d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2530:	06                   	push   es
    2531:	57                   	push   di
    2532:	9a 11 6e 48 25       	call   0x2548:0x6e11
    2537:	6a 01                	push   0x1
    2539:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    253c:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    2540:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2543:	06                   	push   es
    2544:	57                   	push   di
    2545:	9a 11 6e 52 25       	call   0x2552:0x6e11
    254a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    254d:	06                   	push   es
    254e:	57                   	push   di
    254f:	9a d2 6d 73 25       	call   0x2573:0x6dd2
    2554:	08 c0                	or     al,al
    2556:	b0 00                	mov    al,0x0
    2558:	75 01                	jne    0x255b
    255a:	40                   	inc    ax
    255b:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    255e:	08 c0                	or     al,al
    2560:	74 13                	je     0x2575
    2562:	6a 00                	push   0x0
    2564:	9a 04 38 00 00       	call   0x0:0x3804
    2569:	6a 01                	push   0x1
    256b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    256e:	06                   	push   es
    256f:	57                   	push   di
    2570:	9a 11 6e 6d 27       	call   0x276d:0x6e11
    2575:	9a 30 14 7d 25       	call   0x257d:0x1430
    257a:	9a a5 13 f3 27       	call   0x27f3:0x13a5
    257f:	c9                   	leave
    2580:	ca 08 00             	retf   0x8
    2583:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    2586:	6d                   	ins    WORD PTR es:[di],dx
    2587:	73 74                	jae    0x25fd
    2589:	72 61                	jb     0x25ec
    258b:	74 20                	je     0x25ad
    258d:	2d 20 03             	sub    ax,0x320
    2590:	20 2d                	and    BYTE PTR [di],ch
    2592:	20 55 89             	and    BYTE PTR [di-0x77],dl
    2595:	e5 b8                	in     ax,0xb8
    2597:	02 02                	add    al,BYTE PTR [bp+si]
    2599:	9a 44 04 b7 25       	call   0x25b7:0x444
    259e:	81 ec 02 02          	sub    sp,0x202
    25a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a5:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    25a9:	26 c4 bd 70 03       	les    di,DWORD PTR es:[di+0x370]
    25ae:	26 2b 45 24          	sub    ax,WORD PTR es:[di+0x24]
    25b2:	71 05                	jno    0x25b9
    25b4:	9a 3e 04 e4 25       	call   0x25e4:0x43e
    25b9:	99                   	cwd
    25ba:	b9 02 00             	mov    cx,0x2
    25bd:	f7 f9                	idiv   cx
    25bf:	50                   	push   ax
    25c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c3:	26 c4 bd 70 03       	les    di,DWORD PTR es:[di+0x370]
    25c8:	06                   	push   es
    25c9:	57                   	push   di
    25ca:	9a 9d 17 fa 25       	call   0x25fa:0x179d
    25cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25d2:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    25d6:	26 c4 bd 70 03       	les    di,DWORD PTR es:[di+0x370]
    25db:	26 2b 45 1e          	sub    ax,WORD PTR es:[di+0x1e]
    25df:	71 05                	jno    0x25e6
    25e1:	9a 3e 04 27 26       	call   0x2627:0x43e
    25e6:	99                   	cwd
    25e7:	b9 02 00             	mov    cx,0x2
    25ea:	f7 f9                	idiv   cx
    25ec:	50                   	push   ax
    25ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f0:	26 c4 bd 70 03       	les    di,DWORD PTR es:[di+0x370]
    25f5:	06                   	push   es
    25f6:	57                   	push   di
    25f7:	9a 7b 17 17 26       	call   0x2617:0x177b
    25fc:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2600:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    2605:	26 8a 45 31          	mov    al,BYTE PTR es:[di+0x31]
    2609:	50                   	push   ax
    260a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    260d:	26 c4 bd 44 03       	les    di,DWORD PTR es:[di+0x344]
    2612:	06                   	push   es
    2613:	57                   	push   di
    2614:	9a 77 1c 4b 26       	call   0x264b:0x1c77
    2619:	8d be fe fe          	lea    di,[bp-0x102]
    261d:	16                   	push   ss
    261e:	57                   	push   di
    261f:	bf 83 25             	mov    di,0x2583
    2622:	0e                   	push   cs
    2623:	57                   	push   di
    2624:	9a cd 17 31 26       	call   0x2631:0x17cd
    2629:	bf fa 1d             	mov    di,0x1dfa
    262c:	1e                   	push   ds
    262d:	57                   	push   di
    262e:	9a 4c 18 3b 26       	call   0x263b:0x184c
    2633:	bf 8f 25             	mov    di,0x258f
    2636:	0e                   	push   cs
    2637:	57                   	push   di
    2638:	9a 4c 18 50 26       	call   0x2650:0x184c
    263d:	8d be fe fd          	lea    di,[bp-0x202]
    2641:	16                   	push   ss
    2642:	57                   	push   di
    2643:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2646:	06                   	push   es
    2647:	57                   	push   di
    2648:	9a 53 1d 5a 26       	call   0x265a:0x1d53
    264d:	9a 4c 18 b6 26       	call   0x26b6:0x184c
    2652:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2655:	06                   	push   es
    2656:	57                   	push   di
    2657:	9a 8c 1d a2 26       	call   0x26a2:0x1d8c
    265c:	6a 00                	push   0x0
    265e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2661:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2666:	06                   	push   es
    2667:	57                   	push   di
    2668:	9a 6f 24 ff ff       	call   0xffff:0x246f
    266d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2670:	26 c4 bd 30 03       	les    di,DWORD PTR es:[di+0x330]
    2675:	a1 4c 01             	mov    ax,ds:0x14c
    2678:	99                   	cwd
    2679:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
    267e:	26 89 95 f2 00       	mov    WORD PTR es:[di+0xf2],dx
    2683:	26 8b 85 f0 00       	mov    ax,WORD PTR es:[di+0xf0]
    2688:	26 8b 95 f2 00       	mov    dx,WORD PTR es:[di+0xf2]
    268d:	26 3b 95 ee 00       	cmp    dx,WORD PTR es:[di+0xee]
    2692:	75 10                	jne    0x26a4
    2694:	26 3b 85 ec 00       	cmp    ax,WORD PTR es:[di+0xec]
    2699:	75 09                	jne    0x26a4
    269b:	6a 00                	push   0x0
    269d:	06                   	push   es
    269e:	57                   	push   di
    269f:	9a b8 1c e0 26       	call   0x26e0:0x1cb8
    26a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26a7:	06                   	push   es
    26a8:	57                   	push   di
    26a9:	9a 7d 52 d8 26       	call   0x26d8:0x527d
    26ae:	2d 01 00             	sub    ax,0x1
    26b1:	71 05                	jno    0x26b8
    26b3:	9a 3e 04 e7 26       	call   0x26e7:0x43e
    26b8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26bb:	31 c0                	xor    ax,ax
    26bd:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    26c0:	7e 03                	jle    0x26c5
    26c2:	e9 f0 00             	jmp    0x27b5
    26c5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    26c8:	eb 03                	jmp    0x26cd
    26ca:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    26cd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    26d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26d3:	06                   	push   es
    26d4:	57                   	push   di
    26d5:	9a 46 52 f8 26       	call   0x26f8:0x5246
    26da:	52                   	push   dx
    26db:	50                   	push   ax
    26dc:	bf 99 03             	mov    di,0x399
    26df:	b8 00 27             	mov    ax,0x2700
    26e2:	50                   	push   ax
    26e3:	57                   	push   di
    26e4:	9a 55 22 07 27       	call   0x2707:0x2255
    26e9:	08 c0                	or     al,al
    26eb:	74 6d                	je     0x275a
    26ed:	ff 76 fe             	push   WORD PTR [bp-0x2]
    26f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26f3:	06                   	push   es
    26f4:	57                   	push   di
    26f5:	9a 46 52 65 27       	call   0x2765:0x5246
    26fa:	52                   	push   dx
    26fb:	50                   	push   ax
    26fc:	bf 99 03             	mov    di,0x399
    26ff:	b8 58 27             	mov    ax,0x2758
    2702:	50                   	push   ax
    2703:	57                   	push   di
    2704:	9a 73 22 3d 27       	call   0x273d:0x2273
    2709:	89 c7                	mov    di,ax
    270b:	8e c2                	mov    es,dx
    270d:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2710:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2713:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2717:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    271b:	74 3d                	je     0x275a
    271d:	a1 06 1e             	mov    ax,ds:0x1e06
    2720:	99                   	cwd
    2721:	8b c8                	mov    cx,ax
    2723:	8b da                	mov    bx,dx
    2725:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2729:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    272d:	09 d2                	or     dx,dx
    272f:	79 07                	jns    0x2738
    2731:	f7 d2                	not    dx
    2733:	f7 d8                	neg    ax
    2735:	83 da ff             	sbb    dx,0xffff
    2738:	71 05                	jno    0x273f
    273a:	9a 3e 04 74 27       	call   0x2774:0x43e
    273f:	3b d3                	cmp    dx,bx
    2741:	7c 0a                	jl     0x274d
    2743:	7f 04                	jg     0x2749
    2745:	3b c1                	cmp    ax,cx
    2747:	76 04                	jbe    0x274d
    2749:	b0 00                	mov    al,0x0
    274b:	eb 02                	jmp    0x274f
    274d:	b0 01                	mov    al,0x1
    274f:	50                   	push   ax
    2750:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2753:	06                   	push   es
    2754:	57                   	push   di
    2755:	9a 77 1c 64 28       	call   0x2864:0x1c77
    275a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    275d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2760:	06                   	push   es
    2761:	57                   	push   di
    2762:	9a 46 52 85 27       	call   0x2785:0x5246
    2767:	52                   	push   dx
    2768:	50                   	push   ax
    2769:	bf 22 27             	mov    di,0x2722
    276c:	b8 8d 27             	mov    ax,0x278d
    276f:	50                   	push   ax
    2770:	57                   	push   di
    2771:	9a 55 22 94 27       	call   0x2794:0x2255
    2776:	08 c0                	or     al,al
    2778:	74 30                	je     0x27aa
    277a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    277d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2780:	06                   	push   es
    2781:	57                   	push   di
    2782:	9a 46 52 b6 2c       	call   0x2cb6:0x5246
    2787:	52                   	push   dx
    2788:	50                   	push   ax
    2789:	bf 22 27             	mov    di,0x2722
    278c:	b8 a8 27             	mov    ax,0x27a8
    278f:	50                   	push   ax
    2790:	57                   	push   di
    2791:	9a 73 22 e9 27       	call   0x27e9:0x2273
    2796:	89 c7                	mov    di,ax
    2798:	8e c2                	mov    es,dx
    279a:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    279f:	75 09                	jne    0x27aa
    27a1:	6a 01                	push   0x1
    27a3:	06                   	push   es
    27a4:	57                   	push   di
    27a5:	9a 11 6e e7 2c       	call   0x2ce7:0x6e11
    27aa:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    27ad:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    27b0:	74 03                	je     0x27b5
    27b2:	e9 15 ff             	jmp    0x26ca
    27b5:	bf 32 1e             	mov    di,0x1e32
    27b8:	1e                   	push   ds
    27b9:	57                   	push   di
    27ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27bd:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    27c2:	06                   	push   es
    27c3:	57                   	push   di
    27c4:	9a 17 30 db 27       	call   0x27db:0x3017
    27c9:	bf 4e 1e             	mov    di,0x1e4e
    27cc:	1e                   	push   ds
    27cd:	57                   	push   di
    27ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27d1:	26 c4 bd 54 03       	les    di,DWORD PTR es:[di+0x354]
    27d6:	06                   	push   es
    27d7:	57                   	push   di
    27d8:	9a 17 30 da 28       	call   0x28da:0x3017
    27dd:	c9                   	leave
    27de:	ca 08 00             	retf   0x8
    27e1:	55                   	push   bp
    27e2:	89 e5                	mov    bp,sp
    27e4:	31 c0                	xor    ax,ax
    27e6:	9a 44 04 1c 28       	call   0x281c:0x444
    27eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27ee:	06                   	push   es
    27ef:	57                   	push   di
    27f0:	9a f2 0d 01 28       	call   0x2801:0xdf2
    27f5:	ff 36 4c 01          	push   WORD PTR ds:0x14c
    27f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27fc:	06                   	push   es
    27fd:	57                   	push   di
    27fe:	9a 72 29 26 28       	call   0x2826:0x2972
    2803:	6a fe                	push   0xfffe
    2805:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    2809:	06                   	push   es
    280a:	57                   	push   di
    280b:	9a a9 63 e7 2f       	call   0x2fe7:0x63a9
    2810:	c9                   	leave
    2811:	ca 08 00             	retf   0x8
    2814:	55                   	push   bp
    2815:	89 e5                	mov    bp,sp
    2817:	31 c0                	xor    ax,ax
    2819:	9a 44 04 3e 28       	call   0x283e:0x444
    281e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2821:	06                   	push   es
    2822:	57                   	push   di
    2823:	9a 2d 29 70 29       	call   0x2970:0x292d
    2828:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    282b:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    282f:	c9                   	leave
    2830:	ca 0c 00             	retf   0xc
    2833:	01 00                	add    WORD PTR [bx+si],ax
    2835:	55                   	push   bp
    2836:	89 e5                	mov    bp,sp
    2838:	b8 00 02             	mov    ax,0x200
    283b:	9a 44 04 6e 28       	call   0x286e:0x444
    2840:	81 ec 00 02          	sub    sp,0x200
    2844:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2847:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    284b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284e:	26 83 bd 04 01 03    	cmp    WORD PTR es:[di+0x104],0x3
    2854:	74 53                	je     0x28a9
    2856:	8d be 00 fe          	lea    di,[bp-0x200]
    285a:	16                   	push   ss
    285b:	57                   	push   di
    285c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    285f:	06                   	push   es
    2860:	57                   	push   di
    2861:	9a 53 1d 86 28       	call   0x2886:0x1d53
    2866:	bf 33 28             	mov    di,0x2833
    2869:	0e                   	push   cs
    286a:	57                   	push   di
    286b:	9a 4c 18 7c 28       	call   0x287c:0x184c
    2870:	8d be 00 ff          	lea    di,[bp-0x100]
    2874:	16                   	push   ss
    2875:	57                   	push   di
    2876:	68 ff 00             	push   0xff
    2879:	9a e7 17 b6 28       	call   0x28b6:0x17e7
    287e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2881:	06                   	push   es
    2882:	57                   	push   di
    2883:	9a b9 62 2b 2a       	call   0x2a2b:0x62b9
    2888:	50                   	push   ax
    2889:	bf a2 01             	mov    di,0x1a2
    288c:	1e                   	push   ds
    288d:	57                   	push   di
    288e:	8d be 01 ff          	lea    di,[bp-0xff]
    2892:	16                   	push   ss
    2893:	57                   	push   di
    2894:	6a 04                	push   0x4
    2896:	9a 8f 32 00 00       	call   0x0:0x328f
    289b:	3d 06 00             	cmp    ax,0x6
    289e:	b0 00                	mov    al,0x0
    28a0:	75 01                	jne    0x28a3
    28a2:	40                   	inc    ax
    28a3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    28a6:	26 88 05             	mov    BYTE PTR es:[di],al
    28a9:	c9                   	leave
    28aa:	ca 0c 00             	retf   0xc
    28ad:	55                   	push   bp
    28ae:	89 e5                	mov    bp,sp
    28b0:	b8 04 00             	mov    ax,0x4
    28b3:	9a 44 04 35 29       	call   0x2935:0x444
    28b8:	83 ec 04             	sub    sp,0x4
    28bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28be:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    28c3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    28c6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    28c9:	06                   	push   es
    28ca:	57                   	push   di
    28cb:	9a d2 31 f0 28       	call   0x28f0:0x31d2
    28d0:	6a 01                	push   0x1
    28d2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    28d5:	06                   	push   es
    28d6:	57                   	push   di
    28d7:	9a fb 2f e6 28       	call   0x28e6:0x2ffb
    28dc:	6a 00                	push   0x0
    28de:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    28e1:	06                   	push   es
    28e2:	57                   	push   di
    28e3:	9a d2 2e 11 29       	call   0x2911:0x2ed2
    28e8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    28eb:	06                   	push   es
    28ec:	57                   	push   di
    28ed:	9a bf 31 05 29       	call   0x2905:0x31bf
    28f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28f5:	26 c4 bd 54 03       	les    di,DWORD PTR es:[di+0x354]
    28fa:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    28fd:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2900:	06                   	push   es
    2901:	57                   	push   di
    2902:	9a d2 31 27 29       	call   0x2927:0x31d2
    2907:	6a 01                	push   0x1
    2909:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    290c:	06                   	push   es
    290d:	57                   	push   di
    290e:	9a fb 2f 1d 29       	call   0x291d:0x2ffb
    2913:	6a 00                	push   0x0
    2915:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2918:	06                   	push   es
    2919:	57                   	push   di
    291a:	9a d2 2e f2 29       	call   0x29f2:0x2ed2
    291f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2922:	06                   	push   es
    2923:	57                   	push   di
    2924:	9a bf 31 44 29       	call   0x2944:0x31bf
    2929:	c9                   	leave
    292a:	ca 04 00             	retf   0x4
    292d:	55                   	push   bp
    292e:	89 e5                	mov    bp,sp
    2930:	31 c0                	xor    ax,ax
    2932:	9a 44 04 7b 29       	call   0x297b:0x444
    2937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    293a:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    293f:	06                   	push   es
    2940:	57                   	push   di
    2941:	9a d2 31 53 29       	call   0x2953:0x31d2
    2946:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2949:	26 c4 bd 54 03       	les    di,DWORD PTR es:[di+0x354]
    294e:	06                   	push   es
    294f:	57                   	push   di
    2950:	9a d2 31 0f 2a       	call   0x2a0f:0x31d2
    2955:	c9                   	leave
    2956:	ca 04 00             	retf   0x4
    2959:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
    295c:	6c                   	ins    BYTE PTR es:[di],dx
    295d:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    2962:	6f                   	outs   dx,WORD PTR ds:[si]
    2963:	6e                   	outs   dx,BYTE PTR ds:[si]
    2964:	01 00                	add    WORD PTR [bx+si],ax
    2966:	00 00                	add    BYTE PTR [bx+si],al
    2968:	08 00                	or     BYTE PTR [bx+si],al
    296a:	00 00                	add    BYTE PTR [bx+si],al
    296c:	00 00                	add    BYTE PTR [bx+si],al
    296e:	9b                   	fwait
    296f:	2c 00                	sub    al,0x0
    2971:	2a 55 89             	sub    dl,BYTE PTR [di-0x77]
    2974:	e5 b8                	in     ax,0xb8
    2976:	20 00                	and    BYTE PTR [bx+si],al
    2978:	9a 44 04 9b 2a       	call   0x2a9b:0x444
    297d:	83 ec 20             	sub    sp,0x20
    2980:	b8 6c 29             	mov    ax,0x296c
    2983:	0e                   	push   cs
    2984:	50                   	push   ax
    2985:	55                   	push   bp
    2986:	ff 36 58 18          	push   WORD PTR ds:0x1858
    298a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    298e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2991:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2994:	26 89 85 a0 03       	mov    WORD PTR es:[di+0x3a0],ax
    2999:	26 8b 85 a0 03       	mov    ax,WORD PTR es:[di+0x3a0]
    299e:	99                   	cwd
    299f:	52                   	push   dx
    29a0:	50                   	push   ax
    29a1:	26 c4 bd 30 03       	les    di,DWORD PTR es:[di+0x330]
    29a6:	06                   	push   es
    29a7:	57                   	push   di
    29a8:	9a 8b 17 92 2f       	call   0x2f92:0x178b
    29ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29b0:	26 8b 85 a0 03       	mov    ax,WORD PTR es:[di+0x3a0]
    29b5:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    29b9:	b0 00                	mov    al,0x0
    29bb:	7d 01                	jge    0x29be
    29bd:	40                   	inc    ax
    29be:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    29c1:	c6 46 fe 01          	mov    BYTE PTR [bp-0x2],0x1
    29c5:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    29ca:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    29cd:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    29d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29d3:	26 8b 85 a0 03       	mov    ax,WORD PTR es:[di+0x3a0]
    29d8:	99                   	cwd
    29d9:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    29dc:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    29df:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    29e3:	8d 7e ee             	lea    di,[bp-0x12]
    29e6:	16                   	push   ss
    29e7:	57                   	push   di
    29e8:	6a 00                	push   0x0
    29ea:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    29ed:	06                   	push   es
    29ee:	57                   	push   di
    29ef:	9a 95 28 dc 2a       	call   0x2adc:0x2895
    29f4:	08 c0                	or     al,al
    29f6:	75 0a                	jne    0x2a02
    29f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29fb:	06                   	push   es
    29fc:	57                   	push   di
    29fd:	9a d8 0d ea 2a       	call   0x2aea:0xdd8
    2a02:	bf 59 29             	mov    di,0x2959
    2a05:	0e                   	push   cs
    2a06:	57                   	push   di
    2a07:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2a0a:	06                   	push   es
    2a0b:	57                   	push   di
    2a0c:	9a 9b 3b 3a 2a       	call   0x2a3a:0x3b9b
    2a11:	89 c7                	mov    di,ax
    2a13:	8e c2                	mov    es,dx
    2a15:	06                   	push   es
    2a16:	57                   	push   di
    2a17:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a1a:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    2a1e:	50                   	push   ax
    2a1f:	c4 3e c8 1f          	les    di,DWORD PTR ds:0x1fc8
    2a23:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a26:	06                   	push   es
    2a27:	57                   	push   di
    2a28:	9a b8 1c 56 2a       	call   0x2a56:0x1cb8
    2a2d:	bf 59 29             	mov    di,0x2959
    2a30:	0e                   	push   cs
    2a31:	57                   	push   di
    2a32:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2a35:	06                   	push   es
    2a36:	57                   	push   di
    2a37:	9a 9b 3b f9 2a       	call   0x2af9:0x3b9b
    2a3c:	89 c7                	mov    di,ax
    2a3e:	8e c2                	mov    es,dx
    2a40:	06                   	push   es
    2a41:	57                   	push   di
    2a42:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a45:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    2a49:	50                   	push   ax
    2a4a:	c4 3e d8 1f          	les    di,DWORD PTR ds:0x1fd8
    2a4e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a51:	06                   	push   es
    2a52:	57                   	push   di
    2a53:	9a b8 1c 68 2a       	call   0x2a68:0x1cb8
    2a58:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2a5b:	50                   	push   ax
    2a5c:	c4 3e cc 1f          	les    di,DWORD PTR ds:0x1fcc
    2a60:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a63:	06                   	push   es
    2a64:	57                   	push   di
    2a65:	9a b8 1c 1d 2b       	call   0x2b1d:0x1cb8
    2a6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a6d:	26 c4 bd 54 03       	les    di,DWORD PTR es:[di+0x354]
    2a72:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    2a75:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    2a78:	a1 4e 01             	mov    ax,ds:0x14e
    2a7b:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2a7e:	b8 01 00             	mov    ax,0x1
    2a81:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2a84:	7e 03                	jle    0x2a89
    2a86:	e9 52 01             	jmp    0x2bdb
    2a89:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2a8c:	eb 03                	jmp    0x2a91
    2a8e:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2a91:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2a94:	99                   	cwd
    2a95:	bf 64 29             	mov    di,0x2964
    2a98:	9a 16 04 a9 2c       	call   0x2ca9:0x416
    2a9d:	6b f8 24             	imul   di,ax,0x24
    2aa0:	81 c7 80 1e          	add    di,0x1e80
    2aa4:	1e                   	push   ds
    2aa5:	07                   	pop    es
    2aa6:	89 7e f0             	mov    WORD PTR [bp-0x10],di
    2aa9:	8c 46 f2             	mov    WORD PTR [bp-0xe],es
    2aac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aaf:	26 8b 85 a0 03       	mov    ax,WORD PTR es:[di+0x3a0]
    2ab4:	99                   	cwd
    2ab5:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2ab8:	89 56 e2             	mov    WORD PTR [bp-0x1e],dx
    2abb:	c6 46 e4 00          	mov    BYTE PTR [bp-0x1c],0x0
    2abf:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2ac2:	99                   	cwd
    2ac3:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    2ac6:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    2ac9:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    2acd:	8d 7e e0             	lea    di,[bp-0x20]
    2ad0:	16                   	push   ss
    2ad1:	57                   	push   di
    2ad2:	6a 01                	push   0x1
    2ad4:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2ad7:	06                   	push   es
    2ad8:	57                   	push   di
    2ad9:	9a 95 28 ff ff       	call   0xffff:0x2895
    2ade:	08 c0                	or     al,al
    2ae0:	75 0a                	jne    0x2aec
    2ae2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae5:	06                   	push   es
    2ae6:	57                   	push   di
    2ae7:	9a d8 0d 88 2e       	call   0x2e88:0xdd8
    2aec:	bf 59 29             	mov    di,0x2959
    2aef:	0e                   	push   cs
    2af0:	57                   	push   di
    2af1:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2af4:	06                   	push   es
    2af5:	57                   	push   di
    2af6:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    2afb:	89 c7                	mov    di,ax
    2afd:	8e c2                	mov    es,dx
    2aff:	06                   	push   es
    2b00:	57                   	push   di
    2b01:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b04:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    2b08:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    2b0b:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    2b0e:	50                   	push   ax
    2b0f:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    2b12:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b15:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b18:	06                   	push   es
    2b19:	57                   	push   di
    2b1a:	9a b8 1c 3b 2b       	call   0x2b3b:0x1cb8
    2b1f:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    2b22:	22 46 fd             	and    al,BYTE PTR [bp-0x3]
    2b25:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    2b28:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2b2b:	50                   	push   ax
    2b2c:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    2b2f:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2b33:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b36:	06                   	push   es
    2b37:	57                   	push   di
    2b38:	9a b8 1c 50 2b       	call   0x2b50:0x1cb8
    2b3d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2b40:	50                   	push   ax
    2b41:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    2b44:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2b48:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b4b:	06                   	push   es
    2b4c:	57                   	push   di
    2b4d:	9a b8 1c 65 2b       	call   0x2b65:0x1cb8
    2b52:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2b55:	50                   	push   ax
    2b56:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    2b59:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    2b5d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b60:	06                   	push   es
    2b61:	57                   	push   di
    2b62:	9a b8 1c 7a 2b       	call   0x2b7a:0x1cb8
    2b67:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2b6a:	50                   	push   ax
    2b6b:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    2b6e:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    2b72:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b75:	06                   	push   es
    2b76:	57                   	push   di
    2b77:	9a b8 1c 8f 2b       	call   0x2b8f:0x1cb8
    2b7c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2b7f:	50                   	push   ax
    2b80:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    2b83:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    2b87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b8a:	06                   	push   es
    2b8b:	57                   	push   di
    2b8c:	9a b8 1c a4 2b       	call   0x2ba4:0x1cb8
    2b91:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2b94:	50                   	push   ax
    2b95:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    2b98:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    2b9c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b9f:	06                   	push   es
    2ba0:	57                   	push   di
    2ba1:	9a b8 1c b9 2b       	call   0x2bb9:0x1cb8
    2ba6:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2ba9:	50                   	push   ax
    2baa:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    2bad:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    2bb1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bb4:	06                   	push   es
    2bb5:	57                   	push   di
    2bb6:	9a b8 1c ce 2b       	call   0x2bce:0x1cb8
    2bbb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2bbe:	50                   	push   ax
    2bbf:	c4 7e f0             	les    di,DWORD PTR [bp-0x10]
    2bc2:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    2bc6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bc9:	06                   	push   es
    2bca:	57                   	push   di
    2bcb:	9a b8 1c eb 2b       	call   0x2beb:0x1cb8
    2bd0:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2bd3:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2bd6:	74 03                	je     0x2bdb
    2bd8:	e9 b3 fe             	jmp    0x2a8e
    2bdb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2bde:	50                   	push   ax
    2bdf:	c4 3e dc 1f          	les    di,DWORD PTR ds:0x1fdc
    2be3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2be6:	06                   	push   es
    2be7:	57                   	push   di
    2be8:	9a b8 1c fd 2b       	call   0x2bfd:0x1cb8
    2bed:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    2bf0:	50                   	push   ax
    2bf1:	c4 3e e0 1f          	les    di,DWORD PTR ds:0x1fe0
    2bf5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2bf8:	06                   	push   es
    2bf9:	57                   	push   di
    2bfa:	9a b8 1c 0f 2c       	call   0x2c0f:0x1cb8
    2bff:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2c02:	50                   	push   ax
    2c03:	c4 3e e4 1f          	les    di,DWORD PTR ds:0x1fe4
    2c07:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c0a:	06                   	push   es
    2c0b:	57                   	push   di
    2c0c:	9a b8 1c 21 2c       	call   0x2c21:0x1cb8
    2c11:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2c14:	50                   	push   ax
    2c15:	c4 3e e8 1f          	les    di,DWORD PTR ds:0x1fe8
    2c19:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c1c:	06                   	push   es
    2c1d:	57                   	push   di
    2c1e:	9a b8 1c 33 2c       	call   0x2c33:0x1cb8
    2c23:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2c26:	50                   	push   ax
    2c27:	c4 3e ec 1f          	les    di,DWORD PTR ds:0x1fec
    2c2b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c2e:	06                   	push   es
    2c2f:	57                   	push   di
    2c30:	9a b8 1c 45 2c       	call   0x2c45:0x1cb8
    2c35:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2c38:	50                   	push   ax
    2c39:	c4 3e f0 1f          	les    di,DWORD PTR ds:0x1ff0
    2c3d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c40:	06                   	push   es
    2c41:	57                   	push   di
    2c42:	9a b8 1c 57 2c       	call   0x2c57:0x1cb8
    2c47:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2c4a:	50                   	push   ax
    2c4b:	c4 3e f4 1f          	les    di,DWORD PTR ds:0x1ff4
    2c4f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c52:	06                   	push   es
    2c53:	57                   	push   di
    2c54:	9a b8 1c 69 2c       	call   0x2c69:0x1cb8
    2c59:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2c5c:	50                   	push   ax
    2c5d:	c4 3e f8 1f          	les    di,DWORD PTR ds:0x1ff8
    2c61:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c64:	06                   	push   es
    2c65:	57                   	push   di
    2c66:	9a b8 1c 7b 2c       	call   0x2c7b:0x1cb8
    2c6b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2c6e:	50                   	push   ax
    2c6f:	c4 3e fc 1f          	les    di,DWORD PTR ds:0x1ffc
    2c73:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c76:	06                   	push   es
    2c77:	57                   	push   di
    2c78:	9a b8 1c 8d 2c       	call   0x2c8d:0x1cb8
    2c7d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2c80:	50                   	push   ax
    2c81:	c4 3e 00 20          	les    di,DWORD PTR ds:0x2000
    2c85:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c88:	06                   	push   es
    2c89:	57                   	push   di
    2c8a:	9a b8 1c 7e 32       	call   0x327e:0x1cb8
    2c8f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2c93:	83 c4 06             	add    sp,0x6
    2c96:	b8 9c 2c             	mov    ax,0x2c9c
    2c99:	0e                   	push   cs
    2c9a:	50                   	push   ax
    2c9b:	cb                   	retf
    2c9c:	c9                   	leave
    2c9d:	ca 06 00             	retf   0x6
    2ca0:	55                   	push   bp
    2ca1:	89 e5                	mov    bp,sp
    2ca3:	b8 08 00             	mov    ax,0x8
    2ca6:	9a 44 04 c0 2c       	call   0x2cc0:0x444
    2cab:	83 ec 08             	sub    sp,0x8
    2cae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cb1:	06                   	push   es
    2cb2:	57                   	push   di
    2cb3:	9a 7d 52 df 2c       	call   0x2cdf:0x527d
    2cb8:	2d 01 00             	sub    ax,0x1
    2cbb:	71 05                	jno    0x2cc2
    2cbd:	9a 3e 04 ee 2c       	call   0x2cee:0x43e
    2cc2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2cc5:	31 c0                	xor    ax,ax
    2cc7:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2cca:	7f 67                	jg     0x2d33
    2ccc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2ccf:	eb 03                	jmp    0x2cd4
    2cd1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2cd4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2cd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cda:	06                   	push   es
    2cdb:	57                   	push   di
    2cdc:	9a 46 52 ff 2c       	call   0x2cff:0x5246
    2ce1:	52                   	push   dx
    2ce2:	50                   	push   ax
    2ce3:	bf 22 27             	mov    di,0x2722
    2ce6:	b8 07 2d             	mov    ax,0x2d07
    2ce9:	50                   	push   ax
    2cea:	57                   	push   di
    2ceb:	9a 55 22 0e 2d       	call   0x2d0e:0x2255
    2cf0:	08 c0                	or     al,al
    2cf2:	74 37                	je     0x2d2b
    2cf4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2cf7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cfa:	06                   	push   es
    2cfb:	57                   	push   di
    2cfc:	9a 46 52 56 3a       	call   0x3a56:0x5246
    2d01:	52                   	push   dx
    2d02:	50                   	push   ax
    2d03:	bf 22 27             	mov    di,0x2722
    2d06:	b8 29 2d             	mov    ax,0x2d29
    2d09:	50                   	push   ax
    2d0a:	57                   	push   di
    2d0b:	9a 73 22 48 2d       	call   0x2d48:0x2273
    2d10:	89 c7                	mov    di,ax
    2d12:	8e c2                	mov    es,dx
    2d14:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    2d18:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    2d1c:	08 c0                	or     al,al
    2d1e:	74 0b                	je     0x2d2b
    2d20:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2d23:	50                   	push   ax
    2d24:	06                   	push   es
    2d25:	57                   	push   di
    2d26:	9a 11 6e ad 2d       	call   0x2dad:0x6e11
    2d2b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d2e:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2d31:	75 9e                	jne    0x2cd1
    2d33:	c9                   	leave
    2d34:	ca 06 00             	retf   0x6
    2d37:	01 00                	add    WORD PTR [bx+si],ax
    2d39:	00 00                	add    BYTE PTR [bx+si],al
    2d3b:	08 00                	or     BYTE PTR [bx+si],al
    2d3d:	00 00                	add    BYTE PTR [bx+si],al
    2d3f:	55                   	push   bp
    2d40:	89 e5                	mov    bp,sp
    2d42:	b8 0e 00             	mov    ax,0xe
    2d45:	9a 44 04 77 2d       	call   0x2d77:0x444
    2d4a:	83 ec 0e             	sub    sp,0xe
    2d4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d50:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    2d55:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    2d5a:	3d 00 00             	cmp    ax,0x0
    2d5d:	7d 03                	jge    0x2d62
    2d5f:	e9 3f 01             	jmp    0x2ea1
    2d62:	3d 07 00             	cmp    ax,0x7
    2d65:	7e 03                	jle    0x2d6a
    2d67:	e9 37 01             	jmp    0x2ea1
    2d6a:	26 8b 85 ee 00       	mov    ax,WORD PTR es:[di+0xee]
    2d6f:	05 01 00             	add    ax,0x1
    2d72:	71 05                	jno    0x2d79
    2d74:	9a 3e 04 86 2d       	call   0x2d86:0x43e
    2d79:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d7c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d7f:	99                   	cwd
    2d80:	bf 37 2d             	mov    di,0x2d37
    2d83:	9a 16 04 4a 2f       	call   0x2f4a:0x416
    2d88:	6b f8 24             	imul   di,ax,0x24
    2d8b:	81 c7 80 1e          	add    di,0x1e80
    2d8f:	1e                   	push   ds
    2d90:	07                   	pop    es
    2d91:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    2d94:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    2d97:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d9a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d9d:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2da2:	74 0b                	je     0x2daf
    2da4:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2da7:	50                   	push   ax
    2da8:	06                   	push   es
    2da9:	57                   	push   di
    2daa:	9a 11 6e c9 2d       	call   0x2dc9:0x6e11
    2daf:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2db2:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2db6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2db9:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2dbe:	74 0b                	je     0x2dcb
    2dc0:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2dc3:	50                   	push   ax
    2dc4:	06                   	push   es
    2dc5:	57                   	push   di
    2dc6:	9a 11 6e e5 2d       	call   0x2de5:0x6e11
    2dcb:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2dce:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    2dd2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2dd5:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2dda:	74 0b                	je     0x2de7
    2ddc:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2ddf:	50                   	push   ax
    2de0:	06                   	push   es
    2de1:	57                   	push   di
    2de2:	9a 11 6e 01 2e       	call   0x2e01:0x6e11
    2de7:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2dea:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    2dee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2df1:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2df6:	74 0b                	je     0x2e03
    2df8:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2dfb:	50                   	push   ax
    2dfc:	06                   	push   es
    2dfd:	57                   	push   di
    2dfe:	9a 11 6e 22 2e       	call   0x2e22:0x6e11
    2e03:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2e06:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    2e0a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e0d:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    2e11:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    2e15:	08 c0                	or     al,al
    2e17:	74 0b                	je     0x2e24
    2e19:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2e1c:	50                   	push   ax
    2e1d:	06                   	push   es
    2e1e:	57                   	push   di
    2e1f:	9a 11 6e 43 2e       	call   0x2e43:0x6e11
    2e24:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2e27:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    2e2b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e2e:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    2e32:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    2e36:	08 c0                	or     al,al
    2e38:	74 0b                	je     0x2e45
    2e3a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2e3d:	50                   	push   ax
    2e3e:	06                   	push   es
    2e3f:	57                   	push   di
    2e40:	9a 11 6e 64 2e       	call   0x2e64:0x6e11
    2e45:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2e48:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    2e4c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e4f:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    2e53:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    2e57:	08 c0                	or     al,al
    2e59:	74 0b                	je     0x2e66
    2e5b:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2e5e:	50                   	push   ax
    2e5f:	06                   	push   es
    2e60:	57                   	push   di
    2e61:	9a 11 6e 80 2e       	call   0x2e80:0x6e11
    2e66:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2e69:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    2e6d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2e70:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2e75:	74 0b                	je     0x2e82
    2e77:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2e7a:	50                   	push   ax
    2e7b:	06                   	push   es
    2e7c:	57                   	push   di
    2e7d:	9a 11 6e d6 2e       	call   0x2ed6:0x6e11
    2e82:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e85:	9a 52 16 8d 2e       	call   0x2e8d:0x1652
    2e8a:	9a cf 12 92 2e       	call   0x2e92:0x12cf
    2e8f:	9a 30 14 97 2e       	call   0x2e97:0x1430
    2e94:	9a a5 13 9c 2e       	call   0x2e9c:0x13a5
    2e99:	9a 3e 13 b2 2e       	call   0x2eb2:0x133e
    2e9e:	e9 9d 00             	jmp    0x2f3e
    2ea1:	3d 08 00             	cmp    ax,0x8
    2ea4:	75 11                	jne    0x2eb7
    2ea6:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2ea9:	50                   	push   ax
    2eaa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ead:	06                   	push   es
    2eae:	57                   	push   di
    2eaf:	9a a0 2c 56 2f       	call   0x2f56:0x2ca0
    2eb4:	e9 87 00             	jmp    0x2f3e
    2eb7:	3d 09 00             	cmp    ax,0x9
    2eba:	74 03                	je     0x2ebf
    2ebc:	e9 7f 00             	jmp    0x2f3e
    2ebf:	c4 3e c4 1f          	les    di,DWORD PTR ds:0x1fc4
    2ec3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ec6:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2ecb:	74 0b                	je     0x2ed8
    2ecd:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2ed0:	50                   	push   ax
    2ed1:	06                   	push   es
    2ed2:	57                   	push   di
    2ed3:	9a 11 6e ef 2e       	call   0x2eef:0x6e11
    2ed8:	c4 3e c8 1f          	les    di,DWORD PTR ds:0x1fc8
    2edc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2edf:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2ee4:	74 0b                	je     0x2ef1
    2ee6:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2ee9:	50                   	push   ax
    2eea:	06                   	push   es
    2eeb:	57                   	push   di
    2eec:	9a 11 6e 08 2f       	call   0x2f08:0x6e11
    2ef1:	c4 3e cc 1f          	les    di,DWORD PTR ds:0x1fcc
    2ef5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ef8:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2efd:	74 0b                	je     0x2f0a
    2eff:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f02:	50                   	push   ax
    2f03:	06                   	push   es
    2f04:	57                   	push   di
    2f05:	9a 11 6e 21 2f       	call   0x2f21:0x6e11
    2f0a:	c4 3e d8 1f          	les    di,DWORD PTR ds:0x1fd8
    2f0e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f11:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2f16:	74 0b                	je     0x2f23
    2f18:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f1b:	50                   	push   ax
    2f1c:	06                   	push   es
    2f1d:	57                   	push   di
    2f1e:	9a 11 6e 3a 2f       	call   0x2f3a:0x6e11
    2f23:	c4 3e dc 1f          	les    di,DWORD PTR ds:0x1fdc
    2f27:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f2a:	26 80 7d 2a 00       	cmp    BYTE PTR es:[di+0x2a],0x0
    2f2f:	74 0b                	je     0x2f3c
    2f31:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2f34:	50                   	push   ax
    2f35:	06                   	push   es
    2f36:	57                   	push   di
    2f37:	9a 11 6e 8a 30       	call   0x308a:0x6e11
    2f3c:	eb 00                	jmp    0x2f3e
    2f3e:	c9                   	leave
    2f3f:	ca 06 00             	retf   0x6
    2f42:	55                   	push   bp
    2f43:	89 e5                	mov    bp,sp
    2f45:	31 c0                	xor    ax,ax
    2f47:	9a 44 04 64 2f       	call   0x2f64:0x444
    2f4c:	6a 01                	push   0x1
    2f4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f51:	06                   	push   es
    2f52:	57                   	push   di
    2f53:	9a 3f 2d 70 2f       	call   0x2f70:0x2d3f
    2f58:	c9                   	leave
    2f59:	ca 08 00             	retf   0x8
    2f5c:	55                   	push   bp
    2f5d:	89 e5                	mov    bp,sp
    2f5f:	31 c0                	xor    ax,ax
    2f61:	9a 44 04 86 2f       	call   0x2f86:0x444
    2f66:	6a 00                	push   0x0
    2f68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f6b:	06                   	push   es
    2f6c:	57                   	push   di
    2f6d:	9a 3f 2d bf 2f       	call   0x2fbf:0x2d3f
    2f72:	c9                   	leave
    2f73:	ca 08 00             	retf   0x8
    2f76:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    2f7a:	ff                   	(bad)
    2f7b:	7f 00                	jg     0x2f7d
    2f7d:	00 55 89             	add    BYTE PTR [di-0x77],dl
    2f80:	e5 31                	in     ax,0x31
    2f82:	c0 9a 44 04 99       	rcr    BYTE PTR [bp+si+0x444],0x99
    2f87:	2f                   	das
    2f88:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2f8b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2f8e:	bf eb 03             	mov    di,0x3eb
    2f91:	b8 ac 2f             	mov    ax,0x2fac
    2f94:	50                   	push   ax
    2f95:	57                   	push   di
    2f96:	9a 55 22 b4 2f       	call   0x2fb4:0x2255
    2f9b:	08 c0                	or     al,al
    2f9d:	74 22                	je     0x2fc1
    2f9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa2:	26 c4 bd 30 03       	les    di,DWORD PTR es:[di+0x330]
    2fa7:	06                   	push   es
    2fa8:	57                   	push   di
    2fa9:	9a 33 17 ff ff       	call   0xffff:0x1733
    2fae:	bf 76 2f             	mov    di,0x2f76
    2fb1:	9a 16 04 cd 2f       	call   0x2fcd:0x416
    2fb6:	50                   	push   ax
    2fb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fba:	06                   	push   es
    2fbb:	57                   	push   di
    2fbc:	9a 72 29 22 30       	call   0x3022:0x2972
    2fc1:	c9                   	leave
    2fc2:	ca 08 00             	retf   0x8
    2fc5:	55                   	push   bp
    2fc6:	89 e5                	mov    bp,sp
    2fc8:	31 c0                	xor    ax,ax
    2fca:	9a 44 04 f5 2f       	call   0x2ff5:0x444
    2fcf:	6a 01                	push   0x1
    2fd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd4:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    2fd9:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    2fde:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2fe2:	06                   	push   es
    2fe3:	57                   	push   di
    2fe4:	9a b2 77 71 30       	call   0x3071:0x77b2
    2fe9:	c9                   	leave
    2fea:	ca 08 00             	retf   0x8
    2fed:	55                   	push   bp
    2fee:	89 e5                	mov    bp,sp
    2ff0:	31 c0                	xor    ax,ax
    2ff2:	9a 44 04 0c 30       	call   0x300c:0x444
    2ff7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ffa:	26 c6 85 a3 03 01    	mov    BYTE PTR es:[di+0x3a3],0x1
    3000:	c9                   	leave
    3001:	ca 08 00             	retf   0x8
    3004:	55                   	push   bp
    3005:	89 e5                	mov    bp,sp
    3007:	31 c0                	xor    ax,ax
    3009:	9a 44 04 30 30       	call   0x3030:0x444
    300e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3011:	26 c6 85 a2 03 01    	mov    BYTE PTR es:[di+0x3a2],0x1
    3017:	ff 76 0c             	push   WORD PTR [bp+0xc]
    301a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    301d:	06                   	push   es
    301e:	57                   	push   di
    301f:	9a 5a 30 46 30       	call   0x3046:0x305a
    3024:	c9                   	leave
    3025:	ca 08 00             	retf   0x8
    3028:	55                   	push   bp
    3029:	89 e5                	mov    bp,sp
    302b:	31 c0                	xor    ax,ax
    302d:	9a 44 04 63 30       	call   0x3063:0x444
    3032:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3035:	26 c6 85 a2 03 00    	mov    BYTE PTR es:[di+0x3a2],0x0
    303b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    303e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3041:	06                   	push   es
    3042:	57                   	push   di
    3043:	9a 5a 30 58 30       	call   0x3058:0x305a
    3048:	c9                   	leave
    3049:	ca 08 00             	retf   0x8
    304c:	01 00                	add    WORD PTR [bx+si],ax
    304e:	00 00                	add    BYTE PTR [bx+si],al
    3050:	08 00                	or     BYTE PTR [bx+si],al
    3052:	00 00                	add    BYTE PTR [bx+si],al
    3054:	00 00                	add    BYTE PTR [bx+si],al
    3056:	70 33                	jo     0x308b
    3058:	d0 32                	shl    BYTE PTR [bp+si],1
    305a:	55                   	push   bp
    305b:	89 e5                	mov    bp,sp
    305d:	b8 0e 00             	mov    ax,0xe
    3060:	9a 44 04 e6 30       	call   0x30e6:0x444
    3065:	83 ec 0e             	sub    sp,0xe
    3068:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    306c:	06                   	push   es
    306d:	57                   	push   di
    306e:	9a 03 73 10 33       	call   0x3310:0x7303
    3073:	31 c0                	xor    ax,ax
    3075:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3078:	c4 3e c4 1f          	les    di,DWORD PTR ds:0x1fc4
    307c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    307f:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3082:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3085:	06                   	push   es
    3086:	57                   	push   di
    3087:	9a d2 6d ac 30       	call   0x30ac:0x6dd2
    308c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    308f:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3093:	08 c0                	or     al,al
    3095:	74 03                	je     0x309a
    3097:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    309a:	c4 3e c8 1f          	les    di,DWORD PTR ds:0x1fc8
    309e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30a1:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    30a4:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    30a7:	06                   	push   es
    30a8:	57                   	push   di
    30a9:	9a d2 6d ce 30       	call   0x30ce:0x6dd2
    30ae:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    30b1:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    30b5:	08 c0                	or     al,al
    30b7:	74 03                	je     0x30bc
    30b9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    30bc:	c4 3e cc 1f          	les    di,DWORD PTR ds:0x1fcc
    30c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30c3:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    30c6:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    30c9:	06                   	push   es
    30ca:	57                   	push   di
    30cb:	9a d2 6d 3a 31       	call   0x313a:0x6dd2
    30d0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    30d3:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    30d7:	08 c0                	or     al,al
    30d9:	74 1a                	je     0x30f5
    30db:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    30de:	05 02 00             	add    ax,0x2
    30e1:	71 05                	jno    0x30e8
    30e3:	9a 3e 04 18 31       	call   0x3118:0x43e
    30e8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    30eb:	83 3e 4e 01 04       	cmp    WORD PTR ds:0x14e,0x4
    30f0:	7e 03                	jle    0x30f5
    30f2:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    30f5:	a1 4e 01             	mov    ax,ds:0x14e
    30f8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    30fb:	b8 01 00             	mov    ax,0x1
    30fe:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    3101:	7e 03                	jle    0x3106
    3103:	e9 6a 01             	jmp    0x3270
    3106:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3109:	eb 03                	jmp    0x310e
    310b:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    310e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3111:	99                   	cwd
    3112:	bf 4c 30             	mov    di,0x304c
    3115:	9a 16 04 91 33       	call   0x3391:0x416
    311a:	6b f8 24             	imul   di,ax,0x24
    311d:	81 c7 80 1e          	add    di,0x1e80
    3121:	1e                   	push   ds
    3122:	07                   	pop    es
    3123:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    3126:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    3129:	26 c4 3d             	les    di,DWORD PTR es:[di]
    312c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    312f:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    3132:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    3135:	06                   	push   es
    3136:	57                   	push   di
    3137:	9a d2 6d 5f 31       	call   0x315f:0x6dd2
    313c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    313f:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3143:	08 c0                	or     al,al
    3145:	74 03                	je     0x314a
    3147:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    314a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    314d:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    3151:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3154:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    3157:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    315a:	06                   	push   es
    315b:	57                   	push   di
    315c:	9a d2 6d 84 31       	call   0x3184:0x6dd2
    3161:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3164:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3168:	08 c0                	or     al,al
    316a:	74 03                	je     0x316f
    316c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    316f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3172:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    3176:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3179:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    317c:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    317f:	06                   	push   es
    3180:	57                   	push   di
    3181:	9a d2 6d a9 31       	call   0x31a9:0x6dd2
    3186:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3189:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    318d:	08 c0                	or     al,al
    318f:	74 03                	je     0x3194
    3191:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3194:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3197:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    319b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    319e:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    31a1:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    31a4:	06                   	push   es
    31a5:	57                   	push   di
    31a6:	9a d2 6d ce 31       	call   0x31ce:0x6dd2
    31ab:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    31ae:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    31b2:	08 c0                	or     al,al
    31b4:	74 03                	je     0x31b9
    31b6:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    31b9:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    31bc:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    31c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31c3:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    31c6:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    31c9:	06                   	push   es
    31ca:	57                   	push   di
    31cb:	9a d2 6d fb 31       	call   0x31fb:0x6dd2
    31d0:	8a d0                	mov    dl,al
    31d2:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    31d5:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    31d9:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    31dd:	22 c2                	and    al,dl
    31df:	08 c0                	or     al,al
    31e1:	74 03                	je     0x31e6
    31e3:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    31e6:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    31e9:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    31ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31f0:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    31f3:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    31f6:	06                   	push   es
    31f7:	57                   	push   di
    31f8:	9a d2 6d 28 32       	call   0x3228:0x6dd2
    31fd:	8a d0                	mov    dl,al
    31ff:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3202:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    3206:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    320a:	22 c2                	and    al,dl
    320c:	08 c0                	or     al,al
    320e:	74 03                	je     0x3213
    3210:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3213:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3216:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    321a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    321d:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    3220:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    3223:	06                   	push   es
    3224:	57                   	push   di
    3225:	9a d2 6d 55 32       	call   0x3255:0x6dd2
    322a:	8a d0                	mov    dl,al
    322c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    322f:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    3233:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3237:	22 c2                	and    al,dl
    3239:	08 c0                	or     al,al
    323b:	74 03                	je     0x3240
    323d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3240:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3243:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    3247:	26 c4 3d             	les    di,DWORD PTR es:[di]
    324a:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    324d:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    3250:	06                   	push   es
    3251:	57                   	push   di
    3252:	9a d2 6d fd 33       	call   0x33fd:0x6dd2
    3257:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    325a:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    325e:	08 c0                	or     al,al
    3260:	74 03                	je     0x3265
    3262:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3265:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3268:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    326b:	74 03                	je     0x3270
    326d:	e9 9b fe             	jmp    0x310b
    3270:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3274:	75 20                	jne    0x3296
    3276:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3279:	06                   	push   es
    327a:	57                   	push   di
    327b:	9a b9 62 c0 32       	call   0x32c0:0x62b9
    3280:	50                   	push   ax
    3281:	bf ba 01             	mov    di,0x1ba
    3284:	1e                   	push   ds
    3285:	57                   	push   di
    3286:	bf ca 01             	mov    di,0x1ca
    3289:	1e                   	push   ds
    328a:	57                   	push   di
    328b:	68 00 20             	push   0x2000
    328e:	9a ff ff 00 00       	call   0x0:0xffff
    3293:	e9 e6 00             	jmp    0x337c
    3296:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3299:	26 80 bd a2 03 00    	cmp    BYTE PTR es:[di+0x3a2],0x0
    329f:	74 45                	je     0x32e6
    32a1:	26 c4 bd 40 03       	les    di,DWORD PTR es:[di+0x340]
    32a6:	06                   	push   es
    32a7:	57                   	push   di
    32a8:	9a 17 2f f3 32       	call   0x32f3:0x2f17
    32ad:	08 c0                	or     al,al
    32af:	74 32                	je     0x32e3
    32b1:	6a 01                	push   0x1
    32b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32b6:	26 c4 bd 70 03       	les    di,DWORD PTR es:[di+0x370]
    32bb:	06                   	push   es
    32bc:	57                   	push   di
    32bd:	9a 77 1c e1 32       	call   0x32e1:0x1c77
    32c2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    32c5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    32c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32cb:	06                   	push   es
    32cc:	57                   	push   di
    32cd:	9a 88 33 44 33       	call   0x3344:0x3388
    32d2:	6a 00                	push   0x0
    32d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32d7:	26 c4 bd 70 03       	les    di,DWORD PTR es:[di+0x370]
    32dc:	06                   	push   es
    32dd:	57                   	push   di
    32de:	9a 77 1c ad 33       	call   0x33ad:0x1c77
    32e3:	e9 96 00             	jmp    0x337c
    32e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32e9:	26 c4 bd 40 03       	les    di,DWORD PTR es:[di+0x340]
    32ee:	06                   	push   es
    32ef:	57                   	push   di
    32f0:	9a 17 2f ff ff       	call   0xffff:0x2f17
    32f5:	08 c0                	or     al,al
    32f7:	75 03                	jne    0x32fc
    32f9:	e9 80 00             	jmp    0x337c
    32fc:	ff 76 08             	push   WORD PTR [bp+0x8]
    32ff:	ff 76 06             	push   WORD PTR [bp+0x6]
    3302:	b0 01                	mov    al,0x1
    3304:	50                   	push   ax
    3305:	b8 b4 25             	mov    ax,0x25b4
    3308:	ba 39 33             	mov    dx,0x3339
    330b:	52                   	push   dx
    330c:	50                   	push   ax
    330d:	9a 53 25 62 33       	call   0x3362:0x2553
    3312:	a3 04 20             	mov    ds:0x2004,ax
    3315:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    3319:	b8 54 30             	mov    ax,0x3054
    331c:	0e                   	push   cs
    331d:	50                   	push   ax
    331e:	55                   	push   bp
    331f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3323:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3327:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    332b:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    332e:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3331:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3334:	06                   	push   es
    3335:	57                   	push   di
    3336:	9a 8d 2f 9c 38       	call   0x389c:0x2f8d
    333b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    333e:	06                   	push   es
    333f:	57                   	push   di
    3340:	b8 88 33             	mov    ax,0x3388
    3343:	ba d6 3a             	mov    dx,0x3ad6
    3346:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3349:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    334e:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    3353:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    3358:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    335d:	06                   	push   es
    335e:	57                   	push   di
    335f:	9a 45 5d 79 33       	call   0x3379:0x5d45
    3364:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3368:	83 c4 06             	add    sp,0x6
    336b:	b8 7c 33             	mov    ax,0x337c
    336e:	0e                   	push   cs
    336f:	50                   	push   ax
    3370:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    3374:	06                   	push   es
    3375:	57                   	push   di
    3376:	9a 1d 5f bb 38       	call   0x38bb:0x5f1d
    337b:	cb                   	retf
    337c:	c9                   	leave
    337d:	ca 08 00             	retf   0x8
    3380:	01 00                	add    WORD PTR [bx+si],ax
    3382:	00 00                	add    BYTE PTR [bx+si],al
    3384:	08 00                	or     BYTE PTR [bx+si],al
    3386:	00 00                	add    BYTE PTR [bx+si],al
    3388:	55                   	push   bp
    3389:	89 e5                	mov    bp,sp
    338b:	b8 0c 00             	mov    ax,0xc
    338e:	9a 44 04 c8 34       	call   0x34c8:0x444
    3393:	83 ec 0c             	sub    sp,0xc
    3396:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3399:	26 80 bd a2 03 00    	cmp    BYTE PTR es:[di+0x3a2],0x0
    339f:	74 4a                	je     0x33eb
    33a1:	6a 00                	push   0x0
    33a3:	26 c4 bd 34 03       	les    di,DWORD PTR es:[di+0x334]
    33a8:	06                   	push   es
    33a9:	57                   	push   di
    33aa:	9a b8 1c be 33       	call   0x33be:0x1cb8
    33af:	6a 00                	push   0x0
    33b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33b4:	26 c4 bd 38 03       	les    di,DWORD PTR es:[di+0x338]
    33b9:	06                   	push   es
    33ba:	57                   	push   di
    33bb:	9a b8 1c cf 33       	call   0x33cf:0x1cb8
    33c0:	6a 00                	push   0x0
    33c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33c5:	26 c4 bd 3c 03       	les    di,DWORD PTR es:[di+0x33c]
    33ca:	06                   	push   es
    33cb:	57                   	push   di
    33cc:	9a b8 1c e0 33       	call   0x33e0:0x1cb8
    33d1:	6a 00                	push   0x0
    33d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33d6:	26 c4 bd 6c 03       	les    di,DWORD PTR es:[di+0x36c]
    33db:	06                   	push   es
    33dc:	57                   	push   di
    33dd:	9a b8 1c 67 37       	call   0x3767:0x1cb8
    33e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33e5:	26 c6 85 a3 03 00    	mov    BYTE PTR es:[di+0x3a3],0x0
    33eb:	c4 3e c4 1f          	les    di,DWORD PTR ds:0x1fc4
    33ef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33f2:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    33f5:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    33f8:	06                   	push   es
    33f9:	57                   	push   di
    33fa:	9a d2 6d 2e 34       	call   0x342e:0x6dd2
    33ff:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3402:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3406:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    340a:	08 c0                	or     al,al
    340c:	74 0e                	je     0x341c
    340e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3411:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    3416:	50                   	push   ax
    3417:	9a a5 13 ff ff       	call   0xffff:0x13a5
    341c:	c4 3e c8 1f          	les    di,DWORD PTR ds:0x1fc8
    3420:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3423:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3426:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3429:	06                   	push   es
    342a:	57                   	push   di
    342b:	9a d2 6d 64 34       	call   0x3464:0x6dd2
    3430:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3433:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3437:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    343b:	08 c0                	or     al,al
    343d:	74 13                	je     0x3452
    343f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3442:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    3447:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    344c:	50                   	push   ax
    344d:	9a b6 13 ff ff       	call   0xffff:0x13b6
    3452:	c4 3e cc 1f          	les    di,DWORD PTR ds:0x1fcc
    3456:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3459:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    345c:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    345f:	06                   	push   es
    3460:	57                   	push   di
    3461:	9a d2 6d ea 34       	call   0x34ea:0x6dd2
    3466:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3469:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    346d:	08 c0                	or     al,al
    346f:	74 34                	je     0x34a5
    3471:	80 3e 4a 01 00       	cmp    BYTE PTR ds:0x14a,0x0
    3476:	74 13                	je     0x348b
    3478:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    347b:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    3480:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    3485:	50                   	push   ax
    3486:	9a f9 0c ff ff       	call   0xffff:0xcf9
    348b:	80 3e 4a 01 00       	cmp    BYTE PTR ds:0x14a,0x0
    3490:	74 13                	je     0x34a5
    3492:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3495:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    349a:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    349f:	50                   	push   ax
    34a0:	9a 57 0d ff ff       	call   0xffff:0xd57
    34a5:	a1 4e 01             	mov    ax,ds:0x14e
    34a8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    34ab:	b8 01 00             	mov    ax,0x1
    34ae:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    34b1:	7e 03                	jle    0x34b6
    34b3:	e9 9a 02             	jmp    0x3750
    34b6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    34b9:	eb 03                	jmp    0x34be
    34bb:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    34be:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    34c1:	99                   	cwd
    34c2:	bf 80 33             	mov    di,0x3380
    34c5:	9a 16 04 b1 37       	call   0x37b1:0x416
    34ca:	6b f8 24             	imul   di,ax,0x24
    34cd:	81 c7 80 1e          	add    di,0x1e80
    34d1:	1e                   	push   ds
    34d2:	07                   	pop    es
    34d3:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    34d6:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    34d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    34dc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    34df:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    34e2:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    34e5:	06                   	push   es
    34e6:	57                   	push   di
    34e7:	9a d2 6d 35 35       	call   0x3535:0x6dd2
    34ec:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    34ef:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    34f3:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    34f7:	8a d0                	mov    dl,al
    34f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34fc:	26 80 bd a3 03 00    	cmp    BYTE PTR es:[di+0x3a3],0x0
    3502:	b0 00                	mov    al,0x0
    3504:	75 01                	jne    0x3507
    3506:	40                   	inc    ax
    3507:	22 c2                	and    al,dl
    3509:	08 c0                	or     al,al
    350b:	74 13                	je     0x3520
    350d:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    3512:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3515:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    351a:	50                   	push   ax
    351b:	9a b8 11 ff ff       	call   0xffff:0x11b8
    3520:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3523:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    3527:	26 c4 3d             	les    di,DWORD PTR es:[di]
    352a:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    352d:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    3530:	06                   	push   es
    3531:	57                   	push   di
    3532:	9a d2 6d 80 35       	call   0x3580:0x6dd2
    3537:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    353a:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    353e:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    3542:	8a d0                	mov    dl,al
    3544:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3547:	26 80 bd a3 03 00    	cmp    BYTE PTR es:[di+0x3a3],0x0
    354d:	b0 00                	mov    al,0x0
    354f:	75 01                	jne    0x3552
    3551:	40                   	inc    ax
    3552:	22 c2                	and    al,dl
    3554:	08 c0                	or     al,al
    3556:	74 13                	je     0x356b
    3558:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    355d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3560:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    3565:	50                   	push   ax
    3566:	9a 85 23 ff ff       	call   0xffff:0x2385
    356b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    356e:	26 c4 7d 0c          	les    di,DWORD PTR es:[di+0xc]
    3572:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3575:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    3578:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    357b:	06                   	push   es
    357c:	57                   	push   di
    357d:	9a d2 6d cb 35       	call   0x35cb:0x6dd2
    3582:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3585:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3589:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    358d:	8a d0                	mov    dl,al
    358f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3592:	26 80 bd a3 03 00    	cmp    BYTE PTR es:[di+0x3a3],0x0
    3598:	b0 00                	mov    al,0x0
    359a:	75 01                	jne    0x359d
    359c:	40                   	inc    ax
    359d:	22 c2                	and    al,dl
    359f:	08 c0                	or     al,al
    35a1:	74 13                	je     0x35b6
    35a3:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    35a8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    35ab:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    35b0:	50                   	push   ax
    35b1:	9a aa 1d ff ff       	call   0xffff:0x1daa
    35b6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35b9:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    35bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35c0:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    35c3:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    35c6:	06                   	push   es
    35c7:	57                   	push   di
    35c8:	9a d2 6d 16 36       	call   0x3616:0x6dd2
    35cd:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    35d0:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    35d4:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    35d8:	8a d0                	mov    dl,al
    35da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35dd:	26 80 bd a3 03 00    	cmp    BYTE PTR es:[di+0x3a3],0x0
    35e3:	b0 00                	mov    al,0x0
    35e5:	75 01                	jne    0x35e8
    35e7:	40                   	inc    ax
    35e8:	22 c2                	and    al,dl
    35ea:	08 c0                	or     al,al
    35ec:	74 13                	je     0x3601
    35ee:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    35f3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    35f6:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    35fb:	50                   	push   ax
    35fc:	9a b9 0e ff ff       	call   0xffff:0xeb9
    3601:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3604:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    3608:	26 c4 3d             	les    di,DWORD PTR es:[di]
    360b:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    360e:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    3611:	06                   	push   es
    3612:	57                   	push   di
    3613:	9a d2 6d 69 36       	call   0x3669:0x6dd2
    3618:	8a d0                	mov    dl,al
    361a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    361d:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    3621:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3625:	22 c2                	and    al,dl
    3627:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    362b:	8a d0                	mov    dl,al
    362d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3630:	26 80 bd a3 03 00    	cmp    BYTE PTR es:[di+0x3a3],0x0
    3636:	b0 00                	mov    al,0x0
    3638:	75 01                	jne    0x363b
    363a:	40                   	inc    ax
    363b:	22 c2                	and    al,dl
    363d:	08 c0                	or     al,al
    363f:	74 13                	je     0x3654
    3641:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    3646:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3649:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    364e:	50                   	push   ax
    364f:	9a dc 13 ff ff       	call   0xffff:0x13dc
    3654:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3657:	26 c4 7d 18          	les    di,DWORD PTR es:[di+0x18]
    365b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    365e:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    3661:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    3664:	06                   	push   es
    3665:	57                   	push   di
    3666:	9a d2 6d bc 36       	call   0x36bc:0x6dd2
    366b:	8a d0                	mov    dl,al
    366d:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3670:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    3674:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3678:	22 c2                	and    al,dl
    367a:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    367e:	8a d0                	mov    dl,al
    3680:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3683:	26 80 bd a3 03 00    	cmp    BYTE PTR es:[di+0x3a3],0x0
    3689:	b0 00                	mov    al,0x0
    368b:	75 01                	jne    0x368e
    368d:	40                   	inc    ax
    368e:	22 c2                	and    al,dl
    3690:	08 c0                	or     al,al
    3692:	74 13                	je     0x36a7
    3694:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    3699:	ff 76 fe             	push   WORD PTR [bp-0x2]
    369c:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    36a1:	50                   	push   ax
    36a2:	9a f2 14 ff ff       	call   0xffff:0x14f2
    36a7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36aa:	26 c4 7d 1c          	les    di,DWORD PTR es:[di+0x1c]
    36ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36b1:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    36b4:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    36b7:	06                   	push   es
    36b8:	57                   	push   di
    36b9:	9a d2 6d 0f 37       	call   0x370f:0x6dd2
    36be:	8a d0                	mov    dl,al
    36c0:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    36c3:	26 8a 45 29          	mov    al,BYTE PTR es:[di+0x29]
    36c7:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    36cb:	22 c2                	and    al,dl
    36cd:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    36d1:	8a d0                	mov    dl,al
    36d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36d6:	26 80 bd a3 03 00    	cmp    BYTE PTR es:[di+0x3a3],0x0
    36dc:	b0 00                	mov    al,0x0
    36de:	75 01                	jne    0x36e1
    36e0:	40                   	inc    ax
    36e1:	22 c2                	and    al,dl
    36e3:	08 c0                	or     al,al
    36e5:	74 13                	je     0x36fa
    36e7:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    36ec:	ff 76 fe             	push   WORD PTR [bp-0x2]
    36ef:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    36f4:	50                   	push   ax
    36f5:	9a fb 14 ff ff       	call   0xffff:0x14fb
    36fa:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36fd:	26 c4 7d 20          	les    di,DWORD PTR es:[di+0x20]
    3701:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3704:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    3707:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    370a:	06                   	push   es
    370b:	57                   	push   di
    370c:	9a d2 6d 4e 3c       	call   0x3c4e:0x6dd2
    3711:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3714:	26 22 45 2a          	and    al,BYTE PTR es:[di+0x2a]
    3718:	22 06 4a 01          	and    al,BYTE PTR ds:0x14a
    371c:	8a d0                	mov    dl,al
    371e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3721:	26 80 bd a3 03 00    	cmp    BYTE PTR es:[di+0x3a3],0x0
    3727:	b0 00                	mov    al,0x0
    3729:	75 01                	jne    0x372c
    372b:	40                   	inc    ax
    372c:	22 c2                	and    al,dl
    372e:	08 c0                	or     al,al
    3730:	74 13                	je     0x3745
    3732:	26 ff b5 a0 03       	push   WORD PTR es:[di+0x3a0]
    3737:	ff 76 fe             	push   WORD PTR [bp-0x2]
    373a:	26 8a 85 a2 03       	mov    al,BYTE PTR es:[di+0x3a2]
    373f:	50                   	push   ax
    3740:	9a 1c 08 ff ff       	call   0xffff:0x81c
    3745:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3748:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    374b:	74 03                	je     0x3750
    374d:	e9 6b fd             	jmp    0x34bb
    3750:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3753:	26 80 bd a2 03 00    	cmp    BYTE PTR es:[di+0x3a2],0x0
    3759:	74 41                	je     0x379c
    375b:	6a 01                	push   0x1
    375d:	26 c4 bd 34 03       	les    di,DWORD PTR es:[di+0x334]
    3762:	06                   	push   es
    3763:	57                   	push   di
    3764:	9a b8 1c 78 37       	call   0x3778:0x1cb8
    3769:	6a 01                	push   0x1
    376b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    376e:	26 c4 bd 38 03       	les    di,DWORD PTR es:[di+0x338]
    3773:	06                   	push   es
    3774:	57                   	push   di
    3775:	9a b8 1c 89 37       	call   0x3789:0x1cb8
    377a:	6a 01                	push   0x1
    377c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    377f:	26 c4 bd 3c 03       	les    di,DWORD PTR es:[di+0x33c]
    3784:	06                   	push   es
    3785:	57                   	push   di
    3786:	9a b8 1c 9a 37       	call   0x379a:0x1cb8
    378b:	6a 01                	push   0x1
    378d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3790:	26 c4 bd 6c 03       	les    di,DWORD PTR es:[di+0x36c]
    3795:	06                   	push   es
    3796:	57                   	push   di
    3797:	9a b8 1c 5f 38       	call   0x385f:0x1cb8
    379c:	c9                   	leave
    379d:	ca 08 00             	retf   0x8
    37a0:	00 00                	add    BYTE PTR [bx+si],al
    37a2:	00 00                	add    BYTE PTR [bx+si],al
    37a4:	ff 00                	inc    WORD PTR [bx+si]
    37a6:	00 00                	add    BYTE PTR [bx+si],al
    37a8:	55                   	push   bp
    37a9:	89 e5                	mov    bp,sp
    37ab:	b8 20 00             	mov    ax,0x20
    37ae:	9a 44 04 c7 37       	call   0x37c7:0x444
    37b3:	83 ec 20             	sub    sp,0x20
    37b6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    37b9:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    37bd:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    37c0:	99                   	cwd
    37c1:	bf a0 37             	mov    di,0x37a0
    37c4:	9a 16 04 d1 37       	call   0x37d1:0x416
    37c9:	b4 01                	mov    ah,0x1
    37cb:	ba 20 00             	mov    dx,0x20
    37ce:	9a 99 1a df 37       	call   0x37df:0x1a99
    37d3:	52                   	push   dx
    37d4:	50                   	push   ax
    37d5:	8d 7e e0             	lea    di,[bp-0x20]
    37d8:	16                   	push   ss
    37d9:	57                   	push   di
    37da:	6a 00                	push   0x0
    37dc:	9a 0e 1a eb 37       	call   0x37eb:0x1a0e
    37e1:	a1 4e 01             	mov    ax,ds:0x14e
    37e4:	99                   	cwd
    37e5:	bf a0 37             	mov    di,0x37a0
    37e8:	9a 16 04 f3 37       	call   0x37f3:0x416
    37ed:	50                   	push   ax
    37ee:	6a 07                	push   0x7
    37f0:	9a 45 1a 1e 38       	call   0x381e:0x1a45
    37f5:	83 c4 04             	add    sp,0x4
    37f8:	59                   	pop    cx
    37f9:	5b                   	pop    bx
    37fa:	8b fb                	mov    di,bx
    37fc:	84 4b e0             	test   BYTE PTR [bp+di-0x20],cl
    37ff:	74 09                	je     0x380a
    3801:	6a 00                	push   0x0
    3803:	9a ff ff 00 00       	call   0x0:0xffff
    3808:	eb 07                	jmp    0x3811
    380a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    380d:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    3811:	c9                   	leave
    3812:	ca 0e 00             	retf   0xe
    3815:	55                   	push   bp
    3816:	89 e5                	mov    bp,sp
    3818:	b8 08 00             	mov    ax,0x8
    381b:	9a 44 04 34 38       	call   0x3834:0x444
    3820:	83 ec 08             	sub    sp,0x8
    3823:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3826:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3829:	bf ac 04             	mov    di,0x4ac
    382c:	b8 ff ff             	mov    ax,0xffff
    382f:	50                   	push   ax
    3830:	57                   	push   di
    3831:	9a 73 22 97 38       	call   0x3897:0x2273
    3836:	89 c7                	mov    di,ax
    3838:	8e c2                	mov    es,dx
    383a:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    383e:	99                   	cwd
    383f:	b9 02 00             	mov    cx,0x2
    3842:	f7 f9                	idiv   cx
    3844:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3847:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    384b:	99                   	cwd
    384c:	b9 02 00             	mov    cx,0x2
    384f:	f7 f9                	idiv   cx
    3851:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3854:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3857:	ff 76 fc             	push   WORD PTR [bp-0x4]
    385a:	06                   	push   es
    385b:	57                   	push   di
    385c:	9a d4 19 b1 38       	call   0x38b1:0x19d4
    3861:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3864:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3867:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    386a:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    386f:	26 c6 45 25 00       	mov    BYTE PTR es:[di+0x25],0x0
    3874:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3877:	ff 76 fe             	push   WORD PTR [bp-0x2]
    387a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    387d:	26 c4 bd 58 03       	les    di,DWORD PTR es:[di+0x358]
    3882:	06                   	push   es
    3883:	57                   	push   di
    3884:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3887:	26 ff 5d 38          	call   DWORD PTR es:[di+0x38]
    388b:	c9                   	leave
    388c:	ca 08 00             	retf   0x8
    388f:	55                   	push   bp
    3890:	89 e5                	mov    bp,sp
    3892:	31 c0                	xor    ax,ax
    3894:	9a 44 04 db 38       	call   0x38db:0x444
    3899:	9a c6 34 ff ff       	call   0xffff:0x34c6
    389e:	08 c0                	or     al,al
    38a0:	74 2c                	je     0x38ce
    38a2:	6a 00                	push   0x0
    38a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38a7:	26 c4 bd 44 03       	les    di,DWORD PTR es:[di+0x344]
    38ac:	06                   	push   es
    38ad:	57                   	push   di
    38ae:	9a 77 1c cc 38       	call   0x38cc:0x1c77
    38b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38b6:	06                   	push   es
    38b7:	57                   	push   di
    38b8:	9a 2d 5a cd 39       	call   0x39cd:0x5a2d
    38bd:	6a 01                	push   0x1
    38bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38c2:	26 c4 bd 44 03       	les    di,DWORD PTR es:[di+0x344]
    38c7:	06                   	push   es
    38c8:	57                   	push   di
    38c9:	9a 77 1c ef 38       	call   0x38ef:0x1c77
    38ce:	c9                   	leave
    38cf:	ca 08 00             	retf   0x8
    38d2:	55                   	push   bp
    38d3:	89 e5                	mov    bp,sp
    38d5:	b8 14 00             	mov    ax,0x14
    38d8:	9a 44 04 46 39       	call   0x3946:0x444
    38dd:	83 ec 14             	sub    sp,0x14
    38e0:	6a 00                	push   0x0
    38e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38e5:	26 c4 bd 44 03       	les    di,DWORD PTR es:[di+0x344]
    38ea:	06                   	push   es
    38eb:	57                   	push   di
    38ec:	9a 77 1c 02 39       	call   0x3902:0x1c77
    38f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38f4:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    38f8:	26 c4 bd 64 03       	les    di,DWORD PTR es:[di+0x364]
    38fd:	06                   	push   es
    38fe:	57                   	push   di
    38ff:	9a bf 17 15 39       	call   0x3915:0x17bf
    3904:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3907:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    390b:	26 c4 bd 64 03       	les    di,DWORD PTR es:[di+0x364]
    3910:	06                   	push   es
    3911:	57                   	push   di
    3912:	9a e1 17 2f 39       	call   0x392f:0x17e1
    3917:	31 c0                	xor    ax,ax
    3919:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    391c:	31 c0                	xor    ax,ax
    391e:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    3921:	ff 76 ee             	push   WORD PTR [bp-0x12]
    3924:	ff 76 ec             	push   WORD PTR [bp-0x14]
    3927:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    392a:	06                   	push   es
    392b:	57                   	push   di
    392c:	9a d4 19 be 39       	call   0x39be:0x19d4
    3931:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3934:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    3937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    393a:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    393e:	2b 46 ec             	sub    ax,WORD PTR [bp-0x14]
    3941:	71 05                	jno    0x3948
    3943:	9a 3e 04 5a 39       	call   0x395a:0x43e
    3948:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    394b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    394e:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    3952:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    3955:	71 05                	jno    0x395c
    3957:	9a 3e 04 6e 39       	call   0x396e:0x43e
    395c:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    395f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3962:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    3966:	03 46 f0             	add    ax,WORD PTR [bp-0x10]
    3969:	71 05                	jno    0x3970
    396b:	9a 3e 04 82 39       	call   0x3982:0x43e
    3970:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3973:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3976:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    397a:	03 46 f2             	add    ax,WORD PTR [bp-0xe]
    397d:	71 05                	jno    0x3984
    397f:	9a 3e 04 3e 3a       	call   0x3a3e:0x43e
    3984:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    3987:	31 c0                	xor    ax,ax
    3989:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    398c:	31 c0                	xor    ax,ax
    398e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3991:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3994:	26 c4 bd 64 03       	les    di,DWORD PTR es:[di+0x364]
    3999:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    399d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    39a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39a3:	26 c4 bd 64 03       	les    di,DWORD PTR es:[di+0x364]
    39a8:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    39ac:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    39af:	6a 00                	push   0x0
    39b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39b4:	26 c4 bd 64 03       	les    di,DWORD PTR es:[di+0x364]
    39b9:	06                   	push   es
    39ba:	57                   	push   di
    39bb:	9a 77 1c 1e 3a       	call   0x3a1e:0x1c77
    39c0:	8d 7e f8             	lea    di,[bp-0x8]
    39c3:	16                   	push   ss
    39c4:	57                   	push   di
    39c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39c8:	06                   	push   es
    39c9:	57                   	push   di
    39ca:	9a d5 33 b2 3a       	call   0x3ab2:0x33d5
    39cf:	52                   	push   dx
    39d0:	50                   	push   ax
    39d1:	8d 7e f0             	lea    di,[bp-0x10]
    39d4:	16                   	push   ss
    39d5:	57                   	push   di
    39d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39d9:	26 c4 bd 64 03       	les    di,DWORD PTR es:[di+0x364]
    39de:	06                   	push   es
    39df:	57                   	push   di
    39e0:	9a 94 1f 42 3c       	call   0x3c42:0x1f94
    39e5:	89 c7                	mov    di,ax
    39e7:	8e c2                	mov    es,dx
    39e9:	06                   	push   es
    39ea:	57                   	push   di
    39eb:	9a 10 1b ff ff       	call   0xffff:0x1b10
    39f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39f3:	26 c4 bd 64 03       	les    di,DWORD PTR es:[di+0x364]
    39f8:	26 ff b5 90 00       	push   WORD PTR es:[di+0x90]
    39fd:	26 ff b5 8e 00       	push   WORD PTR es:[di+0x8e]
    3a02:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    3a06:	06                   	push   es
    3a07:	57                   	push   di
    3a08:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a0b:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    3a0f:	6a 01                	push   0x1
    3a11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a14:	26 c4 bd 44 03       	les    di,DWORD PTR es:[di+0x344]
    3a19:	06                   	push   es
    3a1a:	57                   	push   di
    3a1b:	9a 77 1c 9a 3a       	call   0x3a9a:0x1c77
    3a20:	c9                   	leave
    3a21:	ca 08 00             	retf   0x8
    3a24:	54                   	push   sp
    3a25:	3c 1f                	cmp    al,0x1f
    3a27:	3b d2                	cmp    dx,dx
    3a29:	3a 00                	cmp    al,BYTE PTR [bx+si]
    3a2b:	00 c0                	add    al,al
    3a2d:	3a e1                	cmp    ah,cl
    3a2f:	01 fb                	add    bx,di
    3a31:	04 6d                	add    al,0x6d
    3a33:	3c 39                	cmp    al,0x39
    3a35:	3f                   	aas
    3a36:	4a                   	dec    dx
    3a37:	3a 9a 1f 81          	cmp    bl,BYTE PTR [bp+si-0x7ee1]
    3a3b:	3c cb                	cmp    al,0xcb
    3a3d:	1f                   	pop    ds
    3a3e:	3a 3a                	cmp    bh,BYTE PTR [bp+si]
    3a40:	ad                   	lods   ax,WORD PTR ds:[si]
    3a41:	27                   	daa
    3a42:	be 3a cd             	mov    si,0xcd3a
    3a45:	11 4e 3a             	adc    WORD PTR [bp+0x3a],cx
    3a48:	f7 2a                	imul   WORD PTR [bp+si]
    3a4a:	aa                   	stos   BYTE PTR es:[di],al
    3a4b:	3a fa                	cmp    bh,dl
    3a4d:	10 ff                	adc    bh,bh
    3a4f:	ff d6                	call   si
    3a51:	14 82                	adc    al,0x82
    3a53:	3a f4                	cmp    dh,ah
    3a55:	4f                   	dec    di
    3a56:	6e                   	outs   dx,BYTE PTR ds:[si]
    3a57:	3a 9a 28 b6          	cmp    bl,BYTE PTR [bp+si-0x49d8]
    3a5b:	3a 85 29 62          	cmp    al,BYTE PTR [di+0x6229]
    3a5f:	3a 57 4d             	cmp    dl,BYTE PTR [bx+0x4d]
    3a62:	66 3a 91 2f 86       	data32 cmp dl,BYTE PTR [bx+di-0x79d1]
    3a67:	3a 63 31             	cmp    ah,BYTE PTR [bp+di+0x31]
    3a6a:	8a 3a                	mov    bh,BYTE PTR [bp+si]
    3a6c:	21 50 46             	and    WORD PTR [bx+si+0x46],dx
    3a6f:	3a 53 25             	cmp    dl,BYTE PTR [bp+di+0x25]
    3a72:	42                   	inc    dx
    3a73:	3a d9                	cmp    bl,cl
    3a75:	62 7e 3a             	bound  di,DWORD PTR [bp+0x3a]
    3a78:	55                   	push   bp
    3a79:	2e 5a                	cs pop dx
    3a7b:	3a 8f 60 ba          	cmp    cl,BYTE PTR [bx-0x45a0]
    3a7f:	3a 3a                	cmp    bh,BYTE PTR [bp+si]
    3a81:	1c 9e                	sbb    al,0x9e
    3a83:	3c e2                	cmp    al,0xe2
    3a85:	2f                   	das
    3a86:	72 3a                	jb     0x3ac2
    3a88:	08 61 8e             	or     BYTE PTR [bx+di-0x72],ah
    3a8b:	3a 5c 61             	cmp    bl,BYTE PTR [si+0x61]
    3a8e:	92                   	xchg   dx,ax
    3a8f:	3a 62 5c             	cmp    ah,BYTE PTR [bp+si+0x5c]
    3a92:	96                   	xchg   si,ax
    3a93:	3a 3a                	cmp    bh,BYTE PTR [bp+si]
    3a95:	61                   	popa
    3a96:	52                   	push   dx
    3a97:	3a 72 3f             	cmp    dh,BYTE PTR [bp+si+0x3f]
    3a9a:	ae                   	scas   al,BYTE PTR es:[di]
    3a9b:	3a 58 3a             	cmp    bl,BYTE PTR [bx+si+0x3a]
    3a9e:	a2 3a ec             	mov    ds:0xec3a,al
    3aa1:	3d a6 3a             	cmp    ax,0x3aa6
    3aa4:	e4 3c                	in     al,0x3c
    3aa6:	36 3a ed             	ss cmp ch,ch
    3aa9:	3e 7a 3a             	ds jp  0x3ae6
    3aac:	77 3e                	ja     0x3aec
    3aae:	76 3a                	jbe    0x3aea
    3ab0:	e6 31                	out    0x31,al
    3ab2:	9e                   	sahf
    3ab3:	3a 3c                	cmp    bh,BYTE PTR [si]
    3ab5:	47                   	inc    di
    3ab6:	5e                   	pop    si
    3ab7:	3a ae 5f 6a          	cmp    ch,BYTE PTR [bp+0x6a5f]
    3abb:	3a e9                	cmp    ch,cl
    3abd:	5c                   	pop    sp
    3abe:	32 3a                	xor    bh,BYTE PTR [bp+si]
    3ac0:	11 54 46             	adc    WORD PTR [si+0x46],dx
    3ac3:	6f                   	outs   dx,WORD PTR ds:[si]
    3ac4:	72 6d                	jb     0x3b33
    3ac6:	53                   	push   bx
    3ac7:	4d                   	dec    bp
    3ac8:	41                   	inc    cx
    3ac9:	50                   	push   ax
    3aca:	5f                   	pop    di
    3acb:	41                   	inc    cx
    3acc:	50                   	push   ax
    3acd:	72 6f                	jb     0x3b3e
    3acf:	70 6f                	jo     0x3b40
    3ad1:	73 05                	jae    0x3ad8
    3ad3:	00 09                	add    BYTE PTR [bx+di],cl
    3ad5:	3d e6 3a             	cmp    ax,0x3ae6
    3ad8:	0b 54 69             	or     dx,WORD PTR [si+0x69]
    3adb:	6d                   	ins    WORD PTR es:[di],dx
    3adc:	65 72 31             	gs jb  0x3b10
    3adf:	54                   	push   sp
    3ae0:	69 6d 65 72 e0       	imul   bp,WORD PTR [di+0x65],0xe072
    3ae5:	3c f4                	cmp    al,0xf4
    3ae7:	3a 09                	cmp    cl,BYTE PTR [bx+di]
    3ae9:	46                   	inc    si
    3aea:	6f                   	outs   dx,WORD PTR ds:[si]
    3aeb:	72 6d                	jb     0x3b5a
    3aed:	43                   	inc    bx
    3aee:	6c                   	ins    BYTE PTR es:[di],dx
    3aef:	6f                   	outs   dx,WORD PTR ds:[si]
    3af0:	73 65                	jae    0x3b57
    3af2:	79 3c                	jns    0x3b30
    3af4:	03 3b                	add    di,WORD PTR [bp+di]
    3af6:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
    3af9:	72 6d                	jb     0x3b68
    3afb:	43                   	inc    bx
    3afc:	72 65                	jb     0x3b63
    3afe:	61                   	popa
    3aff:	74 65                	je     0x3b66
    3b01:	d8 3d                	fdivr  DWORD PTR [di]
    3b03:	10 3b                	adc    BYTE PTR [bp+di],bh
    3b05:	08 46 6f             	or     BYTE PTR [bp+0x6f],al
    3b08:	72 6d                	jb     0x3b77
    3b0a:	53                   	push   bx
    3b0b:	68 6f 77             	push   0x776f
    3b0e:	8d 3e 69 3c          	lea    di,ds:0x3c69
    3b12:	0c 42                	or     al,0x42
    3b14:	75 74                	jne    0x3b8a
    3b16:	74 6f                	je     0x3b87
    3b18:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b19:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
    3b1c:	69 63 6b 19 00       	imul   sp,WORD PTR [bp+di+0x6b],0x19
    3b21:	3e 3c 7c             	ds cmp al,0x7c
    3b24:	01 00                	add    WORD PTR [bx+si],ax
    3b26:	00 06 54 69          	add    BYTE PTR ds:0x6954,al
    3b2a:	6d                   	ins    WORD PTR es:[di],dx
    3b2b:	65 72 31             	gs jb  0x3b5f
    3b2e:	80 01 04             	add    BYTE PTR [bx+di],0x4
    3b31:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    3b35:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b36:	65 6c                	gs ins BYTE PTR es:[di],dx
    3b38:	30 84 01 04          	xor    BYTE PTR [si+0x401],al
    3b3c:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    3b40:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b41:	65 6c                	gs ins BYTE PTR es:[di],dx
    3b43:	31 88 01 08          	xor    WORD PTR [bx+si+0x801],cx
    3b47:	00 06 49 6d          	add    BYTE PTR ds:0x6d49,al
    3b4b:	61                   	popa
    3b4c:	67 65 31 8c 01 04 00 	xor    WORD PTR gs:[ecx+eax*1+0x50060004],cx
    3b53:	06 50 
    3b55:	61                   	popa
    3b56:	6e                   	outs   dx,BYTE PTR ds:[si]
    3b57:	65 6c                	gs ins BYTE PTR es:[di],dx
    3b59:	35 90 01             	xor    ax,0x190
    3b5c:	0c 00                	or     al,0x0
    3b5e:	06                   	push   es
    3b5f:	4c                   	dec    sp
    3b60:	61                   	popa
    3b61:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3b64:	31 94 01 0c          	xor    WORD PTR [si+0xc01],dx
    3b68:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3b6c:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3b6f:	32 98 01 0c          	xor    bl,BYTE PTR [bx+si+0xc01]
    3b73:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3b77:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3b7a:	34 9c                	xor    al,0x9c
    3b7c:	01 0c                	add    WORD PTR [si],cx
    3b7e:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3b82:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3b85:	35 a0 01             	xor    ax,0x1a0
    3b88:	0c 00                	or     al,0x0
    3b8a:	06                   	push   es
    3b8b:	4c                   	dec    sp
    3b8c:	61                   	popa
    3b8d:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3b90:	37                   	aaa
    3b91:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    3b92:	01 0c                	add    WORD PTR [si],cx
    3b94:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3b98:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3b9b:	36 a8 01             	ss test al,0x1
    3b9e:	0c 00                	or     al,0x0
    3ba0:	06                   	push   es
    3ba1:	4c                   	dec    sp
    3ba2:	61                   	popa
    3ba3:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3ba6:	38 ac 01 0c          	cmp    BYTE PTR [si+0xc01],ch
    3baa:	00 07                	add    BYTE PTR [bx],al
    3bac:	4c                   	dec    sp
    3bad:	61                   	popa
    3bae:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3bb1:	31 30                	xor    WORD PTR [bx+si],si
    3bb3:	b0 01                	mov    al,0x1
    3bb5:	0c 00                	or     al,0x0
    3bb7:	07                   	pop    es
    3bb8:	4c                   	dec    sp
    3bb9:	61                   	popa
    3bba:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3bbd:	31 32                	xor    WORD PTR [bp+si],si
    3bbf:	b4 01                	mov    ah,0x1
    3bc1:	04 00                	add    al,0x0
    3bc3:	06                   	push   es
    3bc4:	50                   	push   ax
    3bc5:	61                   	popa
    3bc6:	6e                   	outs   dx,BYTE PTR ds:[si]
    3bc7:	65 6c                	gs ins BYTE PTR es:[di],dx
    3bc9:	34 b8                	xor    al,0xb8
    3bcb:	01 04                	add    WORD PTR [si],ax
    3bcd:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    3bd1:	6e                   	outs   dx,BYTE PTR ds:[si]
    3bd2:	65 6c                	gs ins BYTE PTR es:[di],dx
    3bd4:	32 bc 01 04          	xor    bh,BYTE PTR [si+0x401]
    3bd8:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    3bdc:	6e                   	outs   dx,BYTE PTR ds:[si]
    3bdd:	65 6c                	gs ins BYTE PTR es:[di],dx
    3bdf:	33 c0                	xor    ax,ax
    3be1:	01 0c                	add    WORD PTR [si],cx
    3be3:	00 07                	add    BYTE PTR [bx],al
    3be5:	4c                   	dec    sp
    3be6:	61                   	popa
    3be7:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3bea:	55                   	push   bp
    3beb:	31 c4                	xor    sp,ax
    3bed:	01 0c                	add    WORD PTR [si],cx
    3bef:	00 07                	add    BYTE PTR [bx],al
    3bf1:	4c                   	dec    sp
    3bf2:	61                   	popa
    3bf3:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3bf6:	55                   	push   bp
    3bf7:	32 c8                	xor    cl,al
    3bf9:	01 0c                	add    WORD PTR [si],cx
    3bfb:	00 07                	add    BYTE PTR [bx],al
    3bfd:	4c                   	dec    sp
    3bfe:	61                   	popa
    3bff:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3c02:	55                   	push   bp
    3c03:	30 cc                	xor    ah,cl
    3c05:	01 0c                	add    WORD PTR [si],cx
    3c07:	00 07                	add    BYTE PTR [bx],al
    3c09:	4c                   	dec    sp
    3c0a:	61                   	popa
    3c0b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3c0e:	55                   	push   bp
    3c0f:	33 d0                	xor    dx,ax
    3c11:	01 10                	add    WORD PTR [bx+si],dx
    3c13:	00 07                	add    BYTE PTR [bx],al
    3c15:	42                   	inc    dx
    3c16:	75 74                	jne    0x3c8c
    3c18:	74 6f                	je     0x3c89
    3c1a:	6e                   	outs   dx,BYTE PTR ds:[si]
    3c1b:	31 d4                	xor    sp,dx
    3c1d:	01 0c                	add    WORD PTR [si],cx
    3c1f:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3c23:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3c26:	33 d8                	xor    bx,ax
    3c28:	01 0c                	add    WORD PTR [si],cx
    3c2a:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
    3c2e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3c31:	39 dc                	cmp    sp,bx
    3c33:	01 0c                	add    WORD PTR [si],cx
    3c35:	00 07                	add    BYTE PTR [bx],al
    3c37:	4c                   	dec    sp
    3c38:	61                   	popa
    3c39:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
    3c3c:	31 31                	xor    WORD PTR [bx+di],si
    3c3e:	05 00 8b             	add    ax,0x8b00
    3c41:	0b 46 3c             	or     ax,WORD PTR [bp+0x3c]
    3c44:	ad                   	lods   ax,WORD PTR ds:[si]
    3c45:	0d 4a 3c             	or     ax,0x3c4a
    3c48:	65 06                	gs push es
    3c4a:	22 3d                	and    bh,BYTE PTR [di]
    3c4c:	17                   	pop    ss
    3c4d:	06                   	push   es
    3c4e:	52                   	push   dx
    3c4f:	3c 68                	cmp    al,0x68
    3c51:	21 ff                	and    di,di
    3c53:	ff 07                	inc    WORD PTR [bx]
    3c55:	11 54 46             	adc    WORD PTR [si+0x46],dx
    3c58:	6f                   	outs   dx,WORD PTR ds:[si]
    3c59:	72 6d                	jb     0x3cc8
    3c5b:	53                   	push   bx
    3c5c:	4d                   	dec    bp
    3c5d:	41                   	inc    cx
    3c5e:	50                   	push   ax
    3c5f:	5f                   	pop    di
    3c60:	41                   	inc    cx
    3c61:	50                   	push   ax
    3c62:	72 6f                	jb     0x3cd3
    3c64:	70 6f                	jo     0x3cd5
    3c66:	73 44                	jae    0x3cac
    3c68:	3a c2                	cmp    al,dl
    3c6a:	3e 7b 06             	ds jnp 0x3c73
    3c6d:	3d 3d 38             	cmp    ax,0x383d
    3c70:	00 04                	add    BYTE PTR [si],al
    3c72:	53                   	push   bx
    3c73:	6d                   	ins    WORD PTR es:[di],dx
    3c74:	61                   	popa
    3c75:	70 00                	jo     0x3c77
    3c77:	00 00                	add    BYTE PTR [bx+si],al
    3c79:	55                   	push   bp
    3c7a:	89 e5                	mov    bp,sp
    3c7c:	31 c0                	xor    ax,ax
    3c7e:	9a 44 04 e8 3c       	call   0x3ce8:0x444
    3c83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c86:	26 c6 85 e0 01 01    	mov    BYTE PTR es:[di+0x1e0],0x1
    3c8c:	bf 78 3c             	mov    di,0x3c78
    3c8f:	0e                   	push   cs
    3c90:	57                   	push   di
    3c91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c94:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    3c99:	06                   	push   es
    3c9a:	57                   	push   di
    3c9b:	9a 8c 1d b2 3c       	call   0x3cb2:0x1d8c
    3ca0:	bf 78 3c             	mov    di,0x3c78
    3ca3:	0e                   	push   cs
    3ca4:	57                   	push   di
    3ca5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ca8:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3cad:	06                   	push   es
    3cae:	57                   	push   di
    3caf:	9a 8c 1d c6 3c       	call   0x3cc6:0x1d8c
    3cb4:	bf 78 3c             	mov    di,0x3c78
    3cb7:	0e                   	push   cs
    3cb8:	57                   	push   di
    3cb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cbc:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3cc1:	06                   	push   es
    3cc2:	57                   	push   di
    3cc3:	9a 8c 1d da 3c       	call   0x3cda:0x1d8c
    3cc8:	bf 78 3c             	mov    di,0x3c78
    3ccb:	0e                   	push   cs
    3ccc:	57                   	push   di
    3ccd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cd0:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    3cd5:	06                   	push   es
    3cd6:	57                   	push   di
    3cd7:	9a 8c 1d 33 3d       	call   0x3d33:0x1d8c
    3cdc:	c9                   	leave
    3cdd:	ca 08 00             	retf   0x8
    3ce0:	55                   	push   bp
    3ce1:	89 e5                	mov    bp,sp
    3ce3:	31 c0                	xor    ax,ax
    3ce5:	9a 44 04 11 3d       	call   0x3d11:0x444
    3cea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ced:	26 80 bd e0 01 00    	cmp    BYTE PTR es:[di+0x1e0],0x0
    3cf3:	75 09                	jne    0x3cfe
    3cf5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3cf8:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
    3cfc:	eb 07                	jmp    0x3d05
    3cfe:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3d01:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    3d05:	c9                   	leave
    3d06:	ca 0c 00             	retf   0xc
    3d09:	55                   	push   bp
    3d0a:	89 e5                	mov    bp,sp
    3d0c:	31 c0                	xor    ax,ax
    3d0e:	9a 44 04 4b 3d       	call   0x3d4b:0x444
    3d13:	6a 00                	push   0x0
    3d15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d18:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3d1d:	06                   	push   es
    3d1e:	57                   	push   di
    3d1f:	9a 49 27 a0 3d       	call   0x3da0:0x2749
    3d24:	6a 00                	push   0x0
    3d26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d29:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    3d2e:	06                   	push   es
    3d2f:	57                   	push   di
    3d30:	9a 77 1c 79 3d       	call   0x3d79:0x1c77
    3d35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d38:	06                   	push   es
    3d39:	57                   	push   di
    3d3a:	9a 56 55 57 3d       	call   0x3d57:0x5556
    3d3f:	c9                   	leave
    3d40:	ca 08 00             	retf   0x8
    3d43:	55                   	push   bp
    3d44:	89 e5                	mov    bp,sp
    3d46:	31 c0                	xor    ax,ax
    3d48:	9a 44 04 e1 3d       	call   0x3de1:0x444
    3d4d:	6a 00                	push   0x0
    3d4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d52:	06                   	push   es
    3d53:	57                   	push   di
    3d54:	9a 6e 32 63 3d       	call   0x3d63:0x326e
    3d59:	6a 00                	push   0x0
    3d5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d5e:	06                   	push   es
    3d5f:	57                   	push   di
    3d60:	9a 44 32 d2 3d       	call   0x3dd2:0x3244
    3d65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d68:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3d6d:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    3d71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d74:	06                   	push   es
    3d75:	57                   	push   di
    3d76:	9a e1 17 8f 3d       	call   0x3d8f:0x17e1
    3d7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d7e:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3d83:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    3d87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d8a:	06                   	push   es
    3d8b:	57                   	push   di
    3d8c:	9a bf 17 09 3e       	call   0x3e09:0x17bf
    3d91:	6a 02                	push   0x2
    3d93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d96:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3d9b:	06                   	push   es
    3d9c:	57                   	push   di
    3d9d:	9a 3e 2c b1 3d       	call   0x3db1:0x2c3e
    3da2:	6a 01                	push   0x1
    3da4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3da7:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    3dac:	06                   	push   es
    3dad:	57                   	push   di
    3dae:	9a ad 2c c8 3d       	call   0x3dc8:0x2cad
    3db3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3db6:	26 c6 85 e0 01 00    	mov    BYTE PTR es:[di+0x1e0],0x0
    3dbc:	6a 01                	push   0x1
    3dbe:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    3dc3:	06                   	push   es
    3dc4:	57                   	push   di
    3dc5:	9a 49 27 ff ff       	call   0xffff:0x2749
    3dca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dcd:	06                   	push   es
    3dce:	57                   	push   di
    3dcf:	9a cc 5c 9f 3e       	call   0x3e9f:0x5ccc
    3dd4:	c9                   	leave
    3dd5:	ca 04 00             	retf   0x4
    3dd8:	55                   	push   bp
    3dd9:	89 e5                	mov    bp,sp
    3ddb:	b8 00 01             	mov    ax,0x100
    3dde:	9a 44 04 95 3e       	call   0x3e95:0x444
    3de3:	81 ec 00 01          	sub    sp,0x100
    3de7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dea:	26 80 bd e0 01 00    	cmp    BYTE PTR es:[di+0x1e0],0x0
    3df0:	75 03                	jne    0x3df5
    3df2:	e9 94 00             	jmp    0x3e89
    3df5:	8d be 00 ff          	lea    di,[bp-0x100]
    3df9:	16                   	push   ss
    3dfa:	57                   	push   di
    3dfb:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3dff:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    3e04:	06                   	push   es
    3e05:	57                   	push   di
    3e06:	9a 53 1d 18 3e       	call   0x3e18:0x1d53
    3e0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e0e:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    3e13:	06                   	push   es
    3e14:	57                   	push   di
    3e15:	9a 8c 1d 2e 3e       	call   0x3e2e:0x1d8c
    3e1a:	8d be 00 ff          	lea    di,[bp-0x100]
    3e1e:	16                   	push   ss
    3e1f:	57                   	push   di
    3e20:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3e24:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    3e29:	06                   	push   es
    3e2a:	57                   	push   di
    3e2b:	9a 53 1d 3d 3e       	call   0x3e3d:0x1d53
    3e30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e33:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3e38:	06                   	push   es
    3e39:	57                   	push   di
    3e3a:	9a 8c 1d 53 3e       	call   0x3e53:0x1d8c
    3e3f:	8d be 00 ff          	lea    di,[bp-0x100]
    3e43:	16                   	push   ss
    3e44:	57                   	push   di
    3e45:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3e49:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    3e4e:	06                   	push   es
    3e4f:	57                   	push   di
    3e50:	9a 53 1d 62 3e       	call   0x3e62:0x1d53
    3e55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e58:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3e5d:	06                   	push   es
    3e5e:	57                   	push   di
    3e5f:	9a 8c 1d 78 3e       	call   0x3e78:0x1d8c
    3e64:	8d be 00 ff          	lea    di,[bp-0x100]
    3e68:	16                   	push   ss
    3e69:	57                   	push   di
    3e6a:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    3e6e:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    3e73:	06                   	push   es
    3e74:	57                   	push   di
    3e75:	9a 53 1d 87 3e       	call   0x3e87:0x1d53
    3e7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e7d:	26 c4 bd cc 01       	les    di,DWORD PTR es:[di+0x1cc]
    3e82:	06                   	push   es
    3e83:	57                   	push   di
    3e84:	9a 8c 1d ff ff       	call   0xffff:0x1d8c
    3e89:	c9                   	leave
    3e8a:	ca 08 00             	retf   0x8
    3e8d:	55                   	push   bp
    3e8e:	89 e5                	mov    bp,sp
    3e90:	31 c0                	xor    ax,ax
    3e92:	9a 44 04 ae 3e       	call   0x3eae:0x444
    3e97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e9a:	06                   	push   es
    3e9b:	57                   	push   di
    3e9c:	9a 56 55 c9 3e       	call   0x3ec9:0x5556
    3ea1:	c9                   	leave
    3ea2:	ca 08 00             	retf   0x8
    3ea5:	55                   	push   bp
    3ea6:	89 e5                	mov    bp,sp
    3ea8:	b8 08 00             	mov    ax,0x8
    3eab:	9a 44 04 e5 3e       	call   0x3ee5:0x444
    3eb0:	83 ec 08             	sub    sp,0x8
    3eb3:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    3eb7:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    3ebb:	b0 01                	mov    al,0x1
    3ebd:	50                   	push   ax
    3ebe:	b8 44 3a             	mov    ax,0x3a44
    3ec1:	ba d9 3e             	mov    dx,0x3ed9
    3ec4:	52                   	push   dx
    3ec5:	50                   	push   ax
    3ec6:	9a 53 25 ff ff       	call   0xffff:0x2553
    3ecb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3ece:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3ed1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3ed4:	06                   	push   es
    3ed5:	57                   	push   di
    3ed6:	9a 43 3d ff ff       	call   0xffff:0x3d43
    3edb:	c9                   	leave
    3edc:	cb                   	retf
    3edd:	55                   	push   bp
    3ede:	89 e5                	mov    bp,sp
    3ee0:	31 c0                	xor    ax,ax
    3ee2:	9a 44 04 07 3f       	call   0x3f07:0x444
    3ee7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3eea:	ff 76 08             	push   WORD PTR [bp+0x8]
    3eed:	ff 76 06             	push   WORD PTR [bp+0x6]
    3ef0:	9a ff ff 00 00       	call   0x0:0xffff
    3ef5:	50                   	push   ax
    3ef6:	9a 28 3f 00 00       	call   0x0:0x3f28
    3efb:	c9                   	leave
    3efc:	ca 06 00             	retf   0x6
    3eff:	55                   	push   bp
    3f00:	89 e5                	mov    bp,sp
    3f02:	31 c0                	xor    ax,ax
    3f04:	9a 44 04 38 3f       	call   0x3f38:0x444
    3f09:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3f0c:	9a 3e 3f 00 00       	call   0x0:0x3f3e
    3f11:	50                   	push   ax
    3f12:	50                   	push   ax
    3f13:	9a 45 3f 00 00       	call   0x0:0x3f45
    3f18:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3f1b:	ff 76 08             	push   WORD PTR [bp+0x8]
    3f1e:	ff 76 06             	push   WORD PTR [bp+0x6]
    3f21:	9a ff ff 00 00       	call   0x0:0xffff
    3f26:	50                   	push   ax
    3f27:	9a ff ff 00 00       	call   0x0:0xffff
    3f2c:	c9                   	leave
    3f2d:	ca 0a 00             	retf   0xa
    3f30:	55                   	push   bp
    3f31:	89 e5                	mov    bp,sp
    3f33:	31 c0                	xor    ax,ax
    3f35:	9a 44 04 5b 3f       	call   0x3f5b:0x444
    3f3a:	ff 76 08             	push   WORD PTR [bp+0x8]
    3f3d:	9a ff ff 00 00       	call   0x0:0xffff
    3f42:	50                   	push   ax
    3f43:	50                   	push   ax
    3f44:	9a ff ff 00 00       	call   0x0:0xffff
    3f49:	9a ff ff 00 00       	call   0x0:0xffff
    3f4e:	c9                   	leave
    3f4f:	ca 04 00             	retf   0x4
    3f52:	55                   	push   bp
    3f53:	89 e5                	mov    bp,sp
    3f55:	b8 02 00             	mov    ax,0x2
    3f58:	9a 44 04 ff ff       	call   0xffff:0x444
    3f5d:	83 ec 02             	sub    sp,0x2
    3f60:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3f63:	31 d2                	xor    dx,dx
    3f65:	52                   	push   dx
    3f66:	50                   	push   ax
    3f67:	9a ff ff 00 00       	call   0x0:0xffff
    3f6c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3f6f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3f72:	c9                   	leave
    3f73:	ca                   	.byte 0xca
    3f74:	02                   	.byte 0x2
