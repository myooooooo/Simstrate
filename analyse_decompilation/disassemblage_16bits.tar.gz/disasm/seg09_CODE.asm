; ================================================================
; seg09_CODE  (28787 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	09 00                	or     WORD PTR [bx+si],ax
       2:	d7                   	xlat   BYTE PTR ds:[bx]
       3:	13 24                	adc    sp,WORD PTR [si]
       5:	03 b3 00 00          	add    si,WORD PTR [bp+di+0x0]
       9:	00 9e 00 82          	add    BYTE PTR [bp-0x7e00],bl
       d:	06                   	push   es
       e:	fb                   	sti
       f:	04 f3                	add    al,0xf3
      11:	13 39                	adc    di,WORD PTR [bx+di]
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 07 14 cb       	call   0xcb14:0x71f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 b1 20 d6          	adc    BYTE PTR [bx+di-0x29e0],dh
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c b9                	sbb    al,0xb9
      61:	14 e2                	adc    al,0xe2
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	14 54                	adc    al,0x54
      a0:	46                   	inc    si
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	45                   	inc    bp
      a6:	52                   	push   dx
      a7:	55                   	push   bp
      a8:	5f                   	pop    di
      a9:	54                   	push   sp
      aa:	72 65                	jb     0x111
      ac:	73 6f                	jae    0x11d
      ae:	72 65                	jb     0x115
      b0:	72 69                	jb     0x11b
      b2:	65 20 00             	and    BYTE PTR gs:[bx+si],al
      b5:	8b 38                	mov    di,WORD PTR [bx+si]
      b7:	ce                   	into
      b8:	00 12                	add    BYTE PTR [bp+si],dl
      ba:	54                   	push   sp
      bb:	61                   	popa
      bc:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      bf:	45                   	inc    bp
      c0:	52                   	push   dx
      c1:	47                   	inc    di
      c2:	43                   	inc    bx
      c3:	61                   	popa
      c4:	6c                   	ins    BYTE PTR es:[di],dx
      c5:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
      c8:	65 6c                	gs ins BYTE PTR es:[di],dx
      ca:	64 73 67             	fs jae 0x134
      cd:	16                   	push   ss
      ce:	e1 00                	loope  0xd0
      d0:	0e                   	push   cs
      d1:	49                   	dec    cx
      d2:	6d                   	ins    WORD PTR es:[di],dx
      d3:	70 72                	jo     0x147
      d5:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
      da:	43                   	inc    bx
      db:	6c                   	ins    BYTE PTR es:[di],dx
      dc:	69 63 6b c5 30       	imul   sp,WORD PTR [bp+di+0x6b],0x30c5
      e1:	f3 00 0d             	repz add BYTE PTR [di],cl
      e4:	51                   	push   cx
      e5:	75 69                	jne    0x150
      e7:	74 74                	je     0x15d
      e9:	65 72 31             	gs jb  0x11d
      ec:	43                   	inc    bx
      ed:	6c                   	ins    BYTE PTR es:[di],dx
      ee:	69 63 6b dd 30       	imul   sp,WORD PTR [bp+di+0x6b],0x30dd
      f3:	08 01                	or     BYTE PTR [bx+di],al
      f5:	10 50 6c             	adc    BYTE PTR [bx+si+0x6c],dl
      f8:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
      fe:	61                   	popa
      ff:	6e                   	outs   dx,BYTE PTR ds:[si]
     100:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     103:	69 63 6b 83 4f       	imul   sp,WORD PTR [bp+di+0x6b],0x4f83
     108:	18 01                	sbb    BYTE PTR [bx+di],al
     10a:	0b 49 6e             	or     cx,WORD PTR [bx+di+0x6e]
     10d:	64 65 78 31          	fs gs js 0x142
     111:	43                   	inc    bx
     112:	6c                   	ins    BYTE PTR es:[di],dx
     113:	69 63 6b a2 4f       	imul   sp,WORD PTR [bp+di+0x6b],0x4fa2
     118:	2d 01 10             	sub    ax,0x1001
     11b:	52                   	push   dx
     11c:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     120:	72 63                	jb     0x185
     122:	68 65 72             	push   0x7265
     125:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     128:	69 63 6b c3 4f       	imul   sp,WORD PTR [bp+di+0x6b],0x4fc3
     12d:	45                   	inc    bp
     12e:	01 13                	add    WORD PTR [bp+di],dx
     130:	55                   	push   bp
     131:	74 69                	je     0x19c
     133:	6c                   	ins    BYTE PTR es:[di],dx
     134:	69 73 65 72 6c       	imul   si,WORD PTR [bp+di+0x65],0x6c72
     139:	61                   	popa
     13a:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     13f:	6c                   	ins    BYTE PTR es:[di],dx
     140:	69 63 6b e2 4f       	imul   sp,WORD PTR [bp+di+0x6b],0x4fe2
     145:	57                   	push   di
     146:	01 0d                	add    WORD PTR [di],cx
     148:	41                   	inc    cx
     149:	70 72                	jo     0x1bd
     14b:	6f                   	outs   dx,WORD PTR ds:[si]
     14c:	70 6f                	jo     0x1bd
     14e:	73 31                	jae    0x181
     150:	43                   	inc    bx
     151:	6c                   	ins    BYTE PTR es:[di],dx
     152:	69 63 6b a6 30       	imul   sp,WORD PTR [bp+di+0x6b],0x30a6
     157:	65 01 09             	add    WORD PTR gs:[bx+di],cx
     15a:	46                   	inc    si
     15b:	6f                   	outs   dx,WORD PTR ds:[si]
     15c:	72 6d                	jb     0x1cb
     15e:	43                   	inc    bx
     15f:	6c                   	ins    BYTE PTR es:[di],dx
     160:	6f                   	outs   dx,WORD PTR ds:[si]
     161:	73 65                	jae    0x1c8
     163:	4e                   	dec    si
     164:	2c 74                	sub    al,0x74
     166:	01 0a                	add    WORD PTR [bp+si],cx
     168:	46                   	inc    si
     169:	6f                   	outs   dx,WORD PTR ds:[si]
     16a:	72 6d                	jb     0x1d9
     16c:	43                   	inc    bx
     16d:	72 65                	jb     0x1d4
     16f:	61                   	popa
     170:	74 65                	je     0x1d7
     172:	8c 4d 84             	mov    WORD PTR [di-0x7c],cs
     175:	01 0b                	add    WORD PTR [bp+di],cx
     177:	46                   	inc    si
     178:	6f                   	outs   dx,WORD PTR ds:[si]
     179:	72 6d                	jb     0x1e8
     17b:	4b                   	dec    bx
     17c:	65 79 44             	gs jns 0x1c3
     17f:	6f                   	outs   dx,WORD PTR ds:[si]
     180:	77 6e                	ja     0x1f0
     182:	36 32 93 01 0a       	xor    dl,BYTE PTR ss:[bp+di+0xa01]
     187:	46                   	inc    si
     188:	6f                   	outs   dx,WORD PTR ds:[si]
     189:	72 6d                	jb     0x1f8
     18b:	52                   	push   dx
     18c:	65 73 69             	gs jae 0x1f8
     18f:	7a 65                	jp     0x1f6
     191:	5f                   	pop    di
     192:	32 a5 01 0d          	xor    ah,BYTE PTR [di+0xd01]
     196:	50                   	push   ax
     197:	65 72 69             	gs jb  0x203
     19a:	6f                   	outs   dx,WORD PTR ds:[si]
     19b:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     1a0:	69 63 6b a4 33       	imul   sp,WORD PTR [bp+di+0x6b],0x33a4
     1a5:	b2 01                	mov    dl,0x1
     1a7:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     1aa:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     1ad:	69 63 6b d8 1b       	imul   sp,WORD PTR [bp+di+0x6b],0x1bd8
     1b2:	c4 01                	les    ax,DWORD PTR [bx+di]
     1b4:	0d 44 42             	or     ax,0x4244
     1b7:	45                   	inc    bp
     1b8:	64 69 74 31 30 32    	imul   si,WORD PTR fs:[si+0x31],0x3230
     1be:	45                   	inc    bp
     1bf:	78 69                	js     0x22a
     1c1:	74 88                	je     0x14b
     1c3:	1c d9                	sbb    al,0xd9
     1c5:	01 10                	add    WORD PTR [bx+si],dx
     1c7:	44                   	inc    sp
     1c8:	42                   	inc    dx
     1c9:	45                   	inc    bp
     1ca:	64 69 74 31 30 32    	imul   si,WORD PTR fs:[si+0x31],0x3230
     1d0:	4b                   	dec    bx
     1d1:	65 79 44             	gs jns 0x218
     1d4:	6f                   	outs   dx,WORD PTR ds:[si]
     1d5:	77 6e                	ja     0x245
     1d7:	25 1c ec             	and    ax,0xec1c
     1da:	01 0e 44 42          	add    WORD PTR ds:0x4244,cx
     1de:	45                   	inc    bp
     1df:	64 69 74 31 30 32    	imul   si,WORD PTR fs:[si+0x31],0x3230
     1e5:	4b                   	dec    bx
     1e6:	65 79 55             	gs jns 0x23e
     1e9:	70 8b                	jo     0x176
     1eb:	30 f9                	xor    cl,bh
     1ed:	01 08                	add    WORD PTR [bx+si],cx
     1ef:	46                   	inc    si
     1f0:	6f                   	outs   dx,WORD PTR ds:[si]
     1f1:	72 6d                	jb     0x260
     1f3:	53                   	push   bx
     1f4:	68 6f 77             	push   0x776f
     1f7:	7a 50                	jp     0x249
     1f9:	10 02                	adc    BYTE PTR [bp+si],al
     1fb:	12 44 42             	adc    al,BYTE PTR [si+0x42]
     1fe:	45                   	inc    bp
     1ff:	64 69 74 31 30 32    	imul   si,WORD PTR fs:[si+0x31],0x3230
     205:	4d                   	dec    bp
     206:	6f                   	outs   dx,WORD PTR ds:[si]
     207:	75 73                	jne    0x27c
     209:	65 44                	gs inc sp
     20b:	6f                   	outs   dx,WORD PTR ds:[si]
     20c:	77 6e                	ja     0x27c
     20e:	58                   	pop    ax
     20f:	4f                   	dec    di
     210:	20 02                	and    BYTE PTR [bp+si],al
     212:	0b 46 69             	or     ax,WORD PTR [bp+0x69]
     215:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     218:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     21b:	69 63 6b 85 56       	imul   sp,WORD PTR [bp+di+0x6b],0x5685
     220:	31 02                	xor    WORD PTR [bp+si],ax
     222:	0c 43                	or     al,0x43
     224:	6f                   	outs   dx,WORD PTR ds:[si]
     225:	70 69                	jo     0x290
     227:	65 72 31             	gs jb  0x25b
     22a:	43                   	inc    bx
     22b:	6c                   	ins    BYTE PTR es:[di],dx
     22c:	69 63 6b 31 51       	imul   sp,WORD PTR [bp+di+0x6b],0x5131
     231:	47                   	inc    di
     232:	02 11                	add    dl,BYTE PTR [bx+di]
     234:	50                   	push   ax
     235:	61                   	popa
     236:	6e                   	outs   dx,BYTE PTR ds:[si]
     237:	65 6c                	gs ins BYTE PTR es:[di],dx
     239:	31 33                	xor    WORD PTR [bp+di],si
     23b:	36 4d                	ss dec bp
     23d:	6f                   	outs   dx,WORD PTR ds:[si]
     23e:	75 73                	jne    0x2b3
     240:	65 44                	gs inc sp
     242:	6f                   	outs   dx,WORD PTR ds:[si]
     243:	77 6e                	ja     0x2b3
     245:	3c 6f                	cmp    al,0x6f
     247:	5b                   	pop    bx
     248:	02 0f                	add    cl,BYTE PTR [bx]
     24a:	53                   	push   bx
     24b:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     250:	69 6f 6e 31 43       	imul   bp,WORD PTR [bx+0x6e],0x4331
     255:	6c                   	ins    BYTE PTR es:[di],dx
     256:	69 63 6b 6a 6f       	imul   sp,WORD PTR [bp+di+0x6b],0x6f6a
     25b:	77 02                	ja     0x25f
     25d:	17                   	pop    ss
     25e:	43                   	inc    bx
     25f:	6f                   	outs   dx,WORD PTR ds:[si]
     260:	6d                   	ins    WORD PTR es:[di],dx
     261:	70 74                	jo     0x2d7
     263:	65 44                	gs inc sp
     265:	65 52                	gs push dx
     267:	65 73 75             	gs jae 0x2df
     26a:	6c                   	ins    BYTE PTR es:[di],dx
     26b:	74 61                	je     0x2ce
     26d:	74 73                	je     0x2e2
     26f:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     272:	69 63 6b 98 6f       	imul   sp,WORD PTR [bp+di+0x6b],0x6f98
     277:	87 02                	xchg   WORD PTR [bp+si],ax
     279:	0b 42 69             	or     ax,WORD PTR [bp+si+0x69]
     27c:	6c                   	ins    BYTE PTR es:[di],dx
     27d:	61                   	popa
     27e:	6e                   	outs   dx,BYTE PTR ds:[si]
     27f:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     282:	69 63 6b c6 6f       	imul   sp,WORD PTR [bp+di+0x6b],0x6fc6
     287:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     288:	02 1a                	add    bl,BYTE PTR [bp+si]
     28a:	54                   	push   sp
     28b:	61                   	popa
     28c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     28f:	61                   	popa
     290:	75 44                	jne    0x2d6
     292:	65 46                	gs inc si
     294:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     299:	65 6d                	gs ins WORD PTR es:[di],dx
     29b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     29d:	74 31                	je     0x2d0
     29f:	43                   	inc    bx
     2a0:	6c                   	ins    BYTE PTR es:[di],dx
     2a1:	69 63 6b f4 6f       	imul   sp,WORD PTR [bp+di+0x6b],0x6ff4
     2a6:	c4 02                	les    ax,DWORD PTR [bp+si]
     2a8:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     2ab:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2ae:	61                   	popa
     2af:	75 44                	jne    0x2f5
     2b1:	65 54                	gs push sp
     2b3:	72 65                	jb     0x31a
     2b5:	73 6f                	jae    0x326
     2b7:	72 65                	jb     0x31e
     2b9:	72 69                	jb     0x324
     2bb:	65 31 43 6c          	xor    WORD PTR gs:[bp+di+0x6c],ax
     2bf:	69 63 6b 50 70       	imul   sp,WORD PTR [bp+di+0x6b],0x7050
     2c4:	e1 02                	loope  0x2c8
     2c6:	18 52 61             	sbb    BYTE PTR [bp+si+0x61],dl
     2c9:	70 70                	jo     0x33b
     2cb:	65 6c                	gs ins BYTE PTR es:[di],dx
     2cd:	44                   	inc    sp
     2ce:	65 73 44             	gs jae 0x315
     2d1:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     2d5:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     2da:	43                   	inc    bx
     2db:	6c                   	ins    BYTE PTR es:[di],dx
     2dc:	69 63 6b 19 31       	imul   sp,WORD PTR [bp+di+0x6b],0x3119
     2e1:	f0 02 0a             	lock add cl,BYTE PTR [bp+si]
     2e4:	4e                   	dec    si
     2e5:	31 30                	xor    WORD PTR [bx+si],si
     2e7:	30 31                	xor    BYTE PTR [bx+di],dh
     2e9:	43                   	inc    bx
     2ea:	6c                   	ins    BYTE PTR es:[di],dx
     2eb:	69 63 6b 9a 51       	imul   sp,WORD PTR [bp+di+0x6b],0x519a
     2f0:	0b 03                	or     ax,WORD PTR [bp+di]
     2f2:	16                   	push   ss
     2f3:	49                   	dec    cx
     2f4:	6d                   	ins    WORD PTR es:[di],dx
     2f5:	70 72                	jo     0x369
     2f7:	65 73 73             	gs jae 0x36d
     2fa:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     2ff:	70 69                	jo     0x36a
     301:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     306:	69 63 6b a6 32       	imul   sp,WORD PTR [bp+di+0x6b],0x32a6
     30b:	18 03                	sbb    BYTE PTR [bp+di],al
     30d:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     310:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     313:	69 63 6b 22 70       	imul   sp,WORD PTR [bp+di+0x6b],0x7022
     318:	ef                   	out    dx,ax
     319:	13 09                	adc    cx,WORD PTR [bx+di]
     31b:	53                   	push   bx
     31c:	49                   	dec    cx
     31d:	47                   	inc    di
     31e:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     321:	69 63 6b 00 01       	imul   sp,WORD PTR [bp+di+0x6b],0x100
     326:	a1 13 7c             	mov    ax,ds:0x7c13
     329:	01 00                	add    WORD PTR [bx+si],ax
     32b:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     32f:	6e                   	outs   dx,BYTE PTR ds:[si]
     330:	65 6c                	gs ins BYTE PTR es:[di],dx
     332:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
     336:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     33a:	6e                   	outs   dx,BYTE PTR ds:[si]
     33b:	65 6c                	gs ins BYTE PTR es:[di],dx
     33d:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
     341:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     345:	6e                   	outs   dx,BYTE PTR ds:[si]
     346:	65 6c                	gs ins BYTE PTR es:[di],dx
     348:	35 88 01             	xor    ax,0x188
     34b:	00 00                	add    BYTE PTR [bx+si],al
     34d:	06                   	push   es
     34e:	50                   	push   ax
     34f:	61                   	popa
     350:	6e                   	outs   dx,BYTE PTR ds:[si]
     351:	65 6c                	gs ins BYTE PTR es:[di],dx
     353:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     357:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     35b:	6e                   	outs   dx,BYTE PTR ds:[si]
     35c:	65 6c                	gs ins BYTE PTR es:[di],dx
     35e:	36 90                	ss nop
     360:	01 00                	add    WORD PTR [bx+si],ax
     362:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     366:	6e                   	outs   dx,BYTE PTR ds:[si]
     367:	65 6c                	gs ins BYTE PTR es:[di],dx
     369:	37                   	aaa
     36a:	94                   	xchg   sp,ax
     36b:	01 00                	add    WORD PTR [bx+si],ax
     36d:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     371:	6e                   	outs   dx,BYTE PTR ds:[si]
     372:	65 6c                	gs ins BYTE PTR es:[di],dx
     374:	38 98 01 00          	cmp    BYTE PTR [bx+si+0x1],bl
     378:	00 07                	add    BYTE PTR [bx],al
     37a:	50                   	push   ax
     37b:	61                   	popa
     37c:	6e                   	outs   dx,BYTE PTR ds:[si]
     37d:	65 6c                	gs ins BYTE PTR es:[di],dx
     37f:	33 37                	xor    si,WORD PTR [bx]
     381:	9c                   	pushf
     382:	01 00                	add    WORD PTR [bx+si],ax
     384:	00 07                	add    BYTE PTR [bx],al
     386:	50                   	push   ax
     387:	61                   	popa
     388:	6e                   	outs   dx,BYTE PTR ds:[si]
     389:	65 6c                	gs ins BYTE PTR es:[di],dx
     38b:	33 38                	xor    di,WORD PTR [bx+si]
     38d:	a0 01 04             	mov    al,ds:0x401
     390:	00 08                	add    BYTE PTR [bx+si],cl
     392:	54                   	push   sp
     393:	61                   	popa
     394:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     397:	41                   	inc    cx
     398:	44                   	inc    sp
     399:	47                   	inc    di
     39a:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     39b:	01 04                	add    WORD PTR [si],ax
     39d:	00 09                	add    BYTE PTR [bx+di],cl
     39f:	54                   	push   sp
     3a0:	61                   	popa
     3a1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3a4:	41                   	inc    cx
     3a5:	44                   	inc    sp
     3a6:	50                   	push   ax
     3a7:	31 a8 01 04          	xor    WORD PTR [bx+si+0x401],bp
     3ab:	00 09                	add    BYTE PTR [bx+di],cl
     3ad:	54                   	push   sp
     3ae:	61                   	popa
     3af:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3b2:	41                   	inc    cx
     3b3:	44                   	inc    sp
     3b4:	50                   	push   ax
     3b5:	32 ac 01 04          	xor    ch,BYTE PTR [si+0x401]
     3b9:	00 08                	add    BYTE PTR [bx+si],cl
     3bb:	54                   	push   sp
     3bc:	61                   	popa
     3bd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3c0:	45                   	inc    bp
     3c1:	44                   	inc    sp
     3c2:	47                   	inc    di
     3c3:	b0 01                	mov    al,0x1
     3c5:	04 00                	add    al,0x0
     3c7:	09 54 61             	or     WORD PTR [si+0x61],dx
     3ca:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3cd:	45                   	inc    bp
     3ce:	44                   	inc    sp
     3cf:	50                   	push   ax
     3d0:	31 b4 01 04          	xor    WORD PTR [si+0x401],si
     3d4:	00 09                	add    BYTE PTR [bx+di],cl
     3d6:	54                   	push   sp
     3d7:	61                   	popa
     3d8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3db:	45                   	inc    bp
     3dc:	44                   	inc    sp
     3dd:	50                   	push   ax
     3de:	32 b8 01 04          	xor    bh,BYTE PTR [bx+si+0x401]
     3e2:	00 0c                	add    BYTE PTR [si],cl
     3e4:	54                   	push   sp
     3e5:	61                   	popa
     3e6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3e9:	45                   	inc    bp
     3ea:	52                   	push   dx
     3eb:	47                   	inc    di
     3ec:	5f                   	pop    di
     3ed:	4f                   	dec    di
     3ee:	6c                   	ins    BYTE PTR es:[di],dx
     3ef:	64 bc 01 04          	fs mov sp,0x401
     3f3:	00 08                	add    BYTE PTR [bx+si],cl
     3f5:	54                   	push   sp
     3f6:	61                   	popa
     3f7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3fa:	45                   	inc    bp
     3fb:	52                   	push   dx
     3fc:	47                   	inc    di
     3fd:	c0 01 04             	rol    BYTE PTR [bx+di],0x4
     400:	00 09                	add    BYTE PTR [bx+di],cl
     402:	54                   	push   sp
     403:	61                   	popa
     404:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     407:	45                   	inc    bp
     408:	52                   	push   dx
     409:	50                   	push   ax
     40a:	31 c4                	xor    sp,ax
     40c:	01 04                	add    WORD PTR [si],ax
     40e:	00 09                	add    BYTE PTR [bx+di],cl
     410:	54                   	push   sp
     411:	61                   	popa
     412:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     415:	45                   	inc    bp
     416:	52                   	push   dx
     417:	50                   	push   ax
     418:	32 c8                	xor    cl,al
     41a:	01 08                	add    WORD PTR [bx+si],cx
     41c:	00 0d                	add    BYTE PTR [di],cl
     41e:	44                   	inc    sp
     41f:	61                   	popa
     420:	74 61                	je     0x483
     422:	53                   	push   bx
     423:	6f                   	outs   dx,WORD PTR ds:[si]
     424:	75 72                	jne    0x498
     426:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     429:	52                   	push   dx
     42a:	47                   	inc    di
     42b:	cc                   	int3
     42c:	01 0c                	add    WORD PTR [si],cx
     42e:	00 18                	add    BYTE PTR [bx+si],bl
     430:	54                   	push   sp
     431:	61                   	popa
     432:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     435:	45                   	inc    bp
     436:	52                   	push   dx
     437:	47                   	inc    di
     438:	50                   	push   ax
     439:	72 6f                	jb     0x4aa
     43b:	64 75 69             	fs jne 0x4a7
     43e:	74 46                	je     0x486
     440:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     445:	69 65 72 d0 01       	imul   sp,WORD PTR [di+0x72],0x1d0
     44a:	0c 00                	or     al,0x0
     44c:	10 54 61             	adc    BYTE PTR [si+0x61],dl
     44f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     452:	45                   	inc    bp
     453:	52                   	push   dx
     454:	47                   	inc    di
     455:	53                   	push   bx
     456:	61                   	popa
     457:	6c                   	ins    BYTE PTR es:[di],dx
     458:	61                   	popa
     459:	69 72 65 73 d4       	imul   si,WORD PTR [bp+si+0x65],0xd473
     45e:	01 0c                	add    WORD PTR [si],cx
     460:	00 12                	add    BYTE PTR [bp+si],dl
     462:	54                   	push   sp
     463:	61                   	popa
     464:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     467:	45                   	inc    bp
     468:	52                   	push   dx
     469:	47                   	inc    di
     46a:	46                   	inc    si
     46b:	72 61                	jb     0x4ce
     46d:	69 73 53 74 6f       	imul   si,WORD PTR [bp+di+0x53],0x6f74
     472:	63 6b d8             	arpl   WORD PTR [bp+di-0x28],bp
     475:	01 0c                	add    WORD PTR [si],cx
     477:	00 15                	add    BYTE PTR [di],dl
     479:	54                   	push   sp
     47a:	61                   	popa
     47b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     47e:	45                   	inc    bp
     47f:	52                   	push   dx
     480:	47                   	inc    di
     481:	56                   	push   si
     482:	61                   	popa
     483:	72 54                	jb     0x4d9
     485:	72 65                	jb     0x4ec
     487:	73 6f                	jae    0x4f8
     489:	72 65                	jb     0x4f0
     48b:	72 69                	jb     0x4f6
     48d:	65 dc 01             	fadd   QWORD PTR gs:[bx+di]
     490:	10 00                	adc    BYTE PTR [bx+si],al
     492:	09 4d 61             	or     WORD PTR [di+0x61],cx
     495:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     49a:	75 31                	jne    0x4cd
     49c:	e0 01                	loopne 0x49f
     49e:	14 00                	adc    al,0x0
     4a0:	08 46 69             	or     BYTE PTR [bp+0x69],al
     4a3:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     4a6:	65 72 31             	gs jb  0x4da
     4a9:	e4 01                	in     al,0x1
     4ab:	14 00                	adc    al,0x0
     4ad:	09 49 6d             	or     WORD PTR [bx+di+0x6d],cx
     4b0:	70 72                	jo     0x524
     4b2:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     4b7:	e8 01 14             	call   0x18bb
     4ba:	00 02                	add    BYTE PTR [bp+si],al
     4bc:	4e                   	dec    si
     4bd:	31 ec                	xor    sp,bp
     4bf:	01 14                	add    WORD PTR [si],dx
     4c1:	00 08                	add    BYTE PTR [bx+si],cl
     4c3:	51                   	push   cx
     4c4:	75 69                	jne    0x52f
     4c6:	74 74                	je     0x53c
     4c8:	65 72 31             	gs jb  0x4fc
     4cb:	f0 01 14             	lock add WORD PTR [si],dx
     4ce:	00 0a                	add    BYTE PTR [bp+si],cl
     4d0:	41                   	inc    cx
     4d1:	66 66 69 63 68 61 67 	data32 imul esp,DWORD PTR [bp+di+0x68],0x31656761
     4d8:	65 31 
     4da:	f4                   	hlt
     4db:	01 14                	add    WORD PTR [si],dx
     4dd:	00 0d                	add    BYTE PTR [di],cl
     4df:	42                   	inc    dx
     4e0:	61                   	popa
     4e1:	72 72                	jb     0x555
     4e3:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     4e6:	75 74                	jne    0x55c
     4e8:	69 6c 73 31 f8       	imul   bp,WORD PTR [si+0x73],0xf831
     4ed:	01 14                	add    WORD PTR [si],dx
     4ef:	00 0b                	add    BYTE PTR [bp+di],cl
     4f1:	50                   	push   ax
     4f2:	6c                   	ins    BYTE PTR es:[di],dx
     4f3:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     4f9:	61                   	popa
     4fa:	6e                   	outs   dx,BYTE PTR ds:[si]
     4fb:	31 fc                	xor    sp,di
     4fd:	01 14                	add    WORD PTR [si],dx
     4ff:	00 02                	add    BYTE PTR [bp+si],al
     501:	4e                   	dec    si
     502:	32 00                	xor    al,BYTE PTR [bx+si]
     504:	02 14                	add    dl,BYTE PTR [si]
     506:	00 05                	add    BYTE PTR [di],al
     508:	5a                   	pop    dx
     509:	6f                   	outs   dx,WORD PTR ds:[si]
     50a:	6f                   	outs   dx,WORD PTR ds:[si]
     50b:	6d                   	ins    WORD PTR es:[di],dx
     50c:	31 04                	xor    WORD PTR [si],ax
     50e:	02 14                	add    dl,BYTE PTR [si]
     510:	00 05                	add    BYTE PTR [di],al
     512:	41                   	inc    cx
     513:	69 64 65 31 08       	imul   sp,WORD PTR [si+0x65],0x831
     518:	02 14                	add    dl,BYTE PTR [si]
     51a:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     51e:	64 65 78 31          	fs gs js 0x553
     522:	0c 02                	or     al,0x2
     524:	14 00                	adc    al,0x0
     526:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
     529:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     52c:	72 63                	jb     0x591
     52e:	68 65 72             	push   0x7265
     531:	31 10                	xor    WORD PTR [bx+si],dx
     533:	02 14                	add    dl,BYTE PTR [si]
     535:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     539:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     53e:	72 6c                	jb     0x5ac
     540:	61                   	popa
     541:	69 64 65 31 14       	imul   sp,WORD PTR [si+0x65],0x1431
     546:	02 14                	add    dl,BYTE PTR [si]
     548:	00 08                	add    BYTE PTR [bx+si],cl
     54a:	41                   	inc    cx
     54b:	70 72                	jo     0x5bf
     54d:	6f                   	outs   dx,WORD PTR ds:[si]
     54e:	70 6f                	jo     0x5bf
     550:	73 31                	jae    0x583
     552:	18 02                	sbb    BYTE PTR [bp+si],al
     554:	14 00                	adc    al,0x0
     556:	08 50 65             	or     BYTE PTR [bx+si+0x65],dl
     559:	72 69                	jb     0x5c4
     55b:	6f                   	outs   dx,WORD PTR ds:[si]
     55c:	64 65 31 1c          	fs xor WORD PTR gs:[si],bx
     560:	02 14                	add    dl,BYTE PTR [si]
     562:	00 0b                	add    BYTE PTR [bp+di],cl
     564:	45                   	inc    bp
     565:	6e                   	outs   dx,BYTE PTR ds:[si]
     566:	74 72                	je     0x5da
     568:	65 70 72             	gs jo  0x5dd
     56b:	69 73 65 31 20       	imul   si,WORD PTR [bp+di+0x65],0x2031
     570:	02 18                	add    bl,BYTE PTR [bx+si]
     572:	00 0c                	add    BYTE PTR [si],cl
     574:	50                   	push   ax
     575:	72 69                	jb     0x5e0
     577:	6e                   	outs   dx,BYTE PTR ds:[si]
     578:	74 44                	je     0x5be
     57a:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     57f:	31 24                	xor    WORD PTR [si],sp
     581:	02 04                	add    al,BYTE PTR [si]
     583:	00 0c                	add    BYTE PTR [si],cl
     585:	54                   	push   sp
     586:	61                   	popa
     587:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     58a:	41                   	inc    cx
     58b:	44                   	inc    sp
     58c:	47                   	inc    di
     58d:	5f                   	pop    di
     58e:	4f                   	dec    di
     58f:	6c                   	ins    BYTE PTR es:[di],dx
     590:	64 28 02             	sub    BYTE PTR fs:[bp+si],al
     593:	14 00                	adc    al,0x0
     595:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
     598:	31 2c                	xor    WORD PTR [si],bp
     59a:	02 14                	add    dl,BYTE PTR [si]
     59c:	00 03                	add    BYTE PTR [bp+di],al
     59e:	4e                   	dec    si
     59f:	32 31                	xor    dh,BYTE PTR [bx+di]
     5a1:	30 02                	xor    BYTE PTR [bp+si],al
     5a3:	14 00                	adc    al,0x0
     5a5:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     5a8:	31 34                	xor    WORD PTR [si],si
     5aa:	02 14                	add    dl,BYTE PTR [si]
     5ac:	00 03                	add    BYTE PTR [bp+di],al
     5ae:	4e                   	dec    si
     5af:	34 31                	xor    al,0x31
     5b1:	38 02                	cmp    BYTE PTR [bp+si],al
     5b3:	14 00                	adc    al,0x0
     5b5:	03 4e 35             	add    cx,WORD PTR [bp+0x35]
     5b8:	31 3c                	xor    WORD PTR [si],di
     5ba:	02 14                	add    dl,BYTE PTR [si]
     5bc:	00 03                	add    BYTE PTR [bp+di],al
     5be:	4e                   	dec    si
     5bf:	36 31 40 02          	xor    WORD PTR ss:[bx+si+0x2],ax
     5c3:	14 00                	adc    al,0x0
     5c5:	03 4e 37             	add    cx,WORD PTR [bp+0x37]
     5c8:	31 44 02             	xor    WORD PTR [si+0x2],ax
     5cb:	14 00                	adc    al,0x0
     5cd:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
     5d0:	31 48 02             	xor    WORD PTR [bx+si+0x2],cx
     5d3:	00 00                	add    BYTE PTR [bx+si],al
     5d5:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     5d8:	6e                   	outs   dx,BYTE PTR ds:[si]
     5d9:	65 6c                	gs ins BYTE PTR es:[di],dx
     5db:	4c                   	dec    sp
     5dc:	4f                   	dec    di
     5dd:	55                   	push   bp
     5de:	50                   	push   ax
     5df:	45                   	inc    bp
     5e0:	4c                   	dec    sp
     5e1:	02 04                	add    al,BYTE PTR [si]
     5e3:	00 0d                	add    BYTE PTR [di],cl
     5e5:	54                   	push   sp
     5e6:	61                   	popa
     5e7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5ea:	45                   	inc    bp
     5eb:	52                   	push   dx
     5ec:	50                   	push   ax
     5ed:	31 5f 4f             	xor    WORD PTR [bx+0x4f],bx
     5f0:	6c                   	ins    BYTE PTR es:[di],dx
     5f1:	64 50                	fs push ax
     5f3:	02 04                	add    al,BYTE PTR [si]
     5f5:	00 0d                	add    BYTE PTR [di],cl
     5f7:	54                   	push   sp
     5f8:	61                   	popa
     5f9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5fc:	45                   	inc    bp
     5fd:	52                   	push   dx
     5fe:	50                   	push   ax
     5ff:	32 5f 4f             	xor    bl,BYTE PTR [bx+0x4f]
     602:	6c                   	ins    BYTE PTR es:[di],dx
     603:	64 54                	fs push sp
     605:	02 1c                	add    bl,BYTE PTR [si]
     607:	00 11                	add    BYTE PTR [bx+di],dl
     609:	54                   	push   sp
     60a:	61                   	popa
     60b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     60e:	45                   	inc    bp
     60f:	52                   	push   dx
     610:	47                   	inc    di
     611:	50                   	push   ax
     612:	65 72 69             	gs jb  0x67e
     615:	6f                   	outs   dx,WORD PTR ds:[si]
     616:	64 65 4e             	fs gs dec si
     619:	6f                   	outs   dx,WORD PTR ds:[si]
     61a:	58                   	pop    ax
     61b:	02 1c                	add    bl,BYTE PTR [si]
     61d:	00 14                	add    BYTE PTR [si],dl
     61f:	54                   	push   sp
     620:	61                   	popa
     621:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     624:	45                   	inc    bp
     625:	52                   	push   dx
     626:	47                   	inc    di
     627:	45                   	inc    bp
     628:	6e                   	outs   dx,BYTE PTR ds:[si]
     629:	74 72                	je     0x69d
     62b:	65 70 72             	gs jo  0x6a0
     62e:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     633:	5c                   	pop    sp
     634:	02 20                	add    ah,BYTE PTR [bx+si]
     636:	00 15                	add    BYTE PTR [di],dl
     638:	54                   	push   sp
     639:	61                   	popa
     63a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     63d:	45                   	inc    bp
     63e:	52                   	push   dx
     63f:	47                   	inc    di
     640:	43                   	inc    bx
     641:	61                   	popa
     642:	70 69                	jo     0x6ad
     644:	74 61                	je     0x6a7
     646:	6c                   	ins    BYTE PTR es:[di],dx
     647:	53                   	push   bx
     648:	6f                   	outs   dx,WORD PTR ds:[si]
     649:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     64c:	6c                   	ins    BYTE PTR es:[di],dx
     64d:	60                   	pusha
     64e:	02 20                	add    ah,BYTE PTR [bx+si]
     650:	00 10                	add    BYTE PTR [bx+si],dl
     652:	54                   	push   sp
     653:	61                   	popa
     654:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     657:	45                   	inc    bp
     658:	52                   	push   dx
     659:	47                   	inc    di
     65a:	52                   	push   dx
     65b:	65 73 65             	gs jae 0x6c3
     65e:	72 76                	jb     0x6d6
     660:	65 73 64             	gs jae 0x6c7
     663:	02 20                	add    ah,BYTE PTR [bx+si]
     665:	00 13                	add    BYTE PTR [bp+di],dl
     667:	54                   	push   sp
     668:	61                   	popa
     669:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     66c:	45                   	inc    bp
     66d:	52                   	push   dx
     66e:	47                   	inc    di
     66f:	52                   	push   dx
     670:	65 73 75             	gs jae 0x6e8
     673:	6c                   	ins    BYTE PTR es:[di],dx
     674:	74 61                	je     0x6d7
     676:	74 4e                	je     0x6c6
     678:	65 74 68             	gs je  0x6e3
     67b:	02 20                	add    ah,BYTE PTR [bx+si]
     67d:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     681:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     684:	45                   	inc    bp
     685:	52                   	push   dx
     686:	47                   	inc    di
     687:	53                   	push   bx
     688:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     68d:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
     692:	74 74                	je     0x708
     694:	65 6c                	gs ins BYTE PTR es:[di],dx
     696:	02 20                	add    ah,BYTE PTR [bx+si]
     698:	00 0b                	add    BYTE PTR [bp+di],cl
     69a:	54                   	push   sp
     69b:	61                   	popa
     69c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     69f:	45                   	inc    bp
     6a0:	52                   	push   dx
     6a1:	47                   	inc    di
     6a2:	43                   	inc    bx
     6a3:	41                   	inc    cx
     6a4:	46                   	inc    si
     6a5:	70 02                	jo     0x6a9
     6a7:	20 00                	and    BYTE PTR [bx+si],al
     6a9:	0d 54 61             	or     ax,0x6154
     6ac:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6af:	45                   	inc    bp
     6b0:	52                   	push   dx
     6b1:	47                   	inc    di
     6b2:	49                   	dec    cx
     6b3:	6d                   	ins    WORD PTR es:[di],dx
     6b4:	70 6f                	jo     0x725
     6b6:	74 74                	je     0x72c
     6b8:	02 20                	add    ah,BYTE PTR [bx+si]
     6ba:	00 0b                	add    BYTE PTR [bp+di],cl
     6bc:	54                   	push   sp
     6bd:	61                   	popa
     6be:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6c1:	45                   	inc    bp
     6c2:	52                   	push   dx
     6c3:	47                   	inc    di
     6c4:	49                   	dec    cx
     6c5:	46                   	inc    si
     6c6:	41                   	inc    cx
     6c7:	78 02                	js     0x6cb
     6c9:	20 00                	and    BYTE PTR [bx+si],al
     6cb:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     6cf:	6c                   	ins    BYTE PTR es:[di],dx
     6d0:	65 45                	gs inc bp
     6d2:	52                   	push   dx
     6d3:	47                   	inc    di
     6d4:	43                   	inc    bx
     6d5:	6c                   	ins    BYTE PTR es:[di],dx
     6d6:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
     6db:	7c 02                	jl     0x6df
     6dd:	20 00                	and    BYTE PTR [bx+si],al
     6df:	14 54                	adc    al,0x54
     6e1:	61                   	popa
     6e2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6e5:	45                   	inc    bp
     6e6:	52                   	push   dx
     6e7:	47                   	inc    di
     6e8:	46                   	inc    si
     6e9:	6f                   	outs   dx,WORD PTR ds:[si]
     6ea:	75 72                	jne    0x75e
     6ec:	6e                   	outs   dx,BYTE PTR ds:[si]
     6ed:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
     6f2:	72 73                	jb     0x767
     6f4:	80 02 20             	add    BYTE PTR [bp+si],0x20
     6f7:	00 12                	add    BYTE PTR [bp+si],dl
     6f9:	54                   	push   sp
     6fa:	61                   	popa
     6fb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6fe:	45                   	inc    bp
     6ff:	52                   	push   dx
     700:	47                   	inc    di
     701:	54                   	push   sp
     702:	72 65                	jb     0x769
     704:	73 6f                	jae    0x775
     706:	72 65                	jb     0x76d
     708:	72 69                	jb     0x773
     70a:	65 84 02             	test   BYTE PTR gs:[bp+si],al
     70d:	20 00                	and    BYTE PTR [bx+si],al
     70f:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     713:	6c                   	ins    BYTE PTR es:[di],dx
     714:	65 45                	gs inc bp
     716:	52                   	push   dx
     717:	47                   	inc    di
     718:	45                   	inc    bp
     719:	6d                   	ins    WORD PTR es:[di],dx
     71a:	70 72                	jo     0x78e
     71c:	75 6e                	jne    0x78c
     71e:	74 88                	je     0x6a8
     720:	02 20                	add    ah,BYTE PTR [bx+si]
     722:	00 15                	add    BYTE PTR [di],dl
     724:	54                   	push   sp
     725:	61                   	popa
     726:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     729:	45                   	inc    bp
     72a:	52                   	push   dx
     72b:	47                   	inc    di
     72c:	44                   	inc    sp
     72d:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     731:	76 65                	jbe    0x798
     733:	72 74                	jb     0x7a9
     735:	41                   	inc    cx
     736:	75 74                	jne    0x7ac
     738:	6f                   	outs   dx,WORD PTR ds:[si]
     739:	8c 02                	mov    WORD PTR [bp+si],es
     73b:	20 00                	and    BYTE PTR [bx+si],al
     73d:	16                   	push   ss
     73e:	54                   	push   sp
     73f:	61                   	popa
     740:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     743:	45                   	inc    bp
     744:	52                   	push   dx
     745:	47                   	inc    di
     746:	44                   	inc    sp
     747:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     74b:	76 65                	jbe    0x7b2
     74d:	72 74                	jb     0x7c3
     74f:	4e                   	dec    si
     750:	41                   	inc    cx
     751:	75 74                	jne    0x7c7
     753:	6f                   	outs   dx,WORD PTR ds:[si]
     754:	90                   	nop
     755:	02 20                	add    ah,BYTE PTR [bx+si]
     757:	00 15                	add    BYTE PTR [di],dl
     759:	54                   	push   sp
     75a:	61                   	popa
     75b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     75e:	45                   	inc    bp
     75f:	52                   	push   dx
     760:	47                   	inc    di
     761:	41                   	inc    cx
     762:	6d                   	ins    WORD PTR es:[di],dx
     763:	6f                   	outs   dx,WORD PTR ds:[si]
     764:	72 74                	jb     0x7da
     766:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     76b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     76d:	74 94                	je     0x703
     76f:	02 20                	add    ah,BYTE PTR [bx+si]
     771:	00 10                	add    BYTE PTR [bx+si],dl
     773:	54                   	push   sp
     774:	61                   	popa
     775:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     778:	45                   	inc    bp
     779:	52                   	push   dx
     77a:	47                   	inc    di
     77b:	43                   	inc    bx
     77c:	65 73 73             	gs jae 0x7f2
     77f:	69 6f 6e 73 98       	imul   bp,WORD PTR [bx+0x6e],0x9873
     784:	02 1c                	add    bl,BYTE PTR [si]
     786:	00 10                	add    BYTE PTR [bx+si],dl
     788:	54                   	push   sp
     789:	61                   	popa
     78a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     78d:	45                   	inc    bp
     78e:	52                   	push   dx
     78f:	47                   	inc    di
     790:	4d                   	dec    bp
     791:	61                   	popa
     792:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     795:	6e                   	outs   dx,BYTE PTR ds:[si]
     796:	65 73 9c             	gs jae 0x735
     799:	02 20                	add    ah,BYTE PTR [bx+si]
     79b:	00 1d                	add    BYTE PTR [di],bl
     79d:	54                   	push   sp
     79e:	61                   	popa
     79f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7a2:	45                   	inc    bp
     7a3:	52                   	push   dx
     7a4:	47                   	inc    di
     7a5:	49                   	dec    cx
     7a6:	6d                   	ins    WORD PTR es:[di],dx
     7a7:	6d                   	ins    WORD PTR es:[di],dx
     7a8:	6f                   	outs   dx,WORD PTR ds:[si]
     7a9:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     7ac:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     7b1:	6f                   	outs   dx,WORD PTR ds:[si]
     7b2:	6e                   	outs   dx,BYTE PTR ds:[si]
     7b3:	73 42                	jae    0x7f7
     7b5:	72 75                	jb     0x82c
     7b7:	74 65                	je     0x81e
     7b9:	73 a0                	jae    0x75b
     7bb:	02 20                	add    ah,BYTE PTR [bx+si]
     7bd:	00 1c                	add    BYTE PTR [si],bl
     7bf:	54                   	push   sp
     7c0:	61                   	popa
     7c1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7c4:	45                   	inc    bp
     7c5:	52                   	push   dx
     7c6:	47                   	inc    di
     7c7:	43                   	inc    bx
     7c8:	6f                   	outs   dx,WORD PTR ds:[si]
     7c9:	75 74                	jne    0x83f
     7cb:	73 46                	jae    0x813
     7cd:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
     7d2:	72 6f                	jb     0x843
     7d4:	64 75 63             	fs jne 0x83a
     7d7:	74 69                	je     0x842
     7d9:	6f                   	outs   dx,WORD PTR ds:[si]
     7da:	6e                   	outs   dx,BYTE PTR ds:[si]
     7db:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     7dc:	02 1c                	add    bl,BYTE PTR [si]
     7de:	00 12                	add    BYTE PTR [bp+si],dl
     7e0:	54                   	push   sp
     7e1:	61                   	popa
     7e2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7e5:	45                   	inc    bp
     7e6:	52                   	push   dx
     7e7:	47                   	inc    di
     7e8:	50                   	push   ax
     7e9:	72 6f                	jb     0x85a
     7eb:	64 75 63             	fs jne 0x851
     7ee:	74 69                	je     0x859
     7f0:	66 73 a8             	data32 jae 0x79b
     7f3:	02 1c                	add    bl,BYTE PTR [si]
     7f5:	00 10                	add    BYTE PTR [bx+si],dl
     7f7:	54                   	push   sp
     7f8:	61                   	popa
     7f9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7fc:	45                   	inc    bp
     7fd:	52                   	push   dx
     7fe:	47                   	inc    di
     7ff:	56                   	push   si
     800:	65 6e                	outs   dx,BYTE PTR gs:[si]
     802:	64 65 75 72          	fs gs jne 0x878
     806:	73 ac                	jae    0x7b4
     808:	02 1c                	add    bl,BYTE PTR [si]
     80a:	00 0e 54 61          	add    BYTE PTR ds:0x6154,cl
     80e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     811:	45                   	inc    bp
     812:	52                   	push   dx
     813:	47                   	inc    di
     814:	43                   	inc    bx
     815:	61                   	popa
     816:	64 72 65             	fs jb  0x87e
     819:	73 b0                	jae    0x7cb
     81b:	02 20                	add    ah,BYTE PTR [bx+si]
     81d:	00 14                	add    BYTE PTR [si],dl
     81f:	54                   	push   sp
     820:	61                   	popa
     821:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     824:	45                   	inc    bp
     825:	52                   	push   dx
     826:	47                   	inc    di
     827:	43                   	inc    bx
     828:	6f                   	outs   dx,WORD PTR ds:[si]
     829:	75 74                	jne    0x89f
     82b:	45                   	inc    bp
     82c:	6d                   	ins    WORD PTR es:[di],dx
     82d:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
     830:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     833:	b4 02                	mov    ah,0x2
     835:	20 00                	and    BYTE PTR [bx+si],al
     837:	14 54                	adc    al,0x54
     839:	61                   	popa
     83a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     83d:	45                   	inc    bp
     83e:	52                   	push   dx
     83f:	47                   	inc    di
     840:	43                   	inc    bx
     841:	6f                   	outs   dx,WORD PTR ds:[si]
     842:	75 74                	jne    0x8b8
     844:	4c                   	dec    sp
     845:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
     84a:	69 65 b8 02 20       	imul   sp,WORD PTR [di-0x48],0x2002
     84f:	00 15                	add    BYTE PTR [di],dl
     851:	54                   	push   sp
     852:	61                   	popa
     853:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     856:	45                   	inc    bp
     857:	52                   	push   dx
     858:	47                   	inc    di
     859:	43                   	inc    bx
     85a:	6f                   	outs   dx,WORD PTR ds:[si]
     85b:	75 74                	jne    0x8d1
     85d:	46                   	inc    si
     85e:	6f                   	outs   dx,WORD PTR ds:[si]
     85f:	72 6d                	jb     0x8ce
     861:	61                   	popa
     862:	74 69                	je     0x8cd
     864:	6f                   	outs   dx,WORD PTR ds:[si]
     865:	6e                   	outs   dx,BYTE PTR ds:[si]
     866:	bc 02 20             	mov    sp,0x2002
     869:	00 15                	add    BYTE PTR [di],dl
     86b:	54                   	push   sp
     86c:	61                   	popa
     86d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     870:	45                   	inc    bp
     871:	52                   	push   dx
     872:	47                   	inc    di
     873:	44                   	inc    sp
     874:	69 73 74 72 69       	imul   si,WORD PTR [bp+di+0x74],0x6972
     879:	62 75 74             	bound  si,DWORD PTR [di+0x74]
     87c:	69 6f 6e 73 c0       	imul   bp,WORD PTR [bx+0x6e],0xc073
     881:	02 1c                	add    bl,BYTE PTR [si]
     883:	00 0f                	add    BYTE PTR [bx],cl
     885:	54                   	push   sp
     886:	61                   	popa
     887:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     88a:	45                   	inc    bp
     88b:	52                   	push   dx
     88c:	47                   	inc    di
     88d:	53                   	push   bx
     88e:	70 65                	jo     0x8f5
     890:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     893:	6c                   	ins    BYTE PTR es:[di],dx
     894:	c4 02                	les    ax,DWORD PTR [bp+si]
     896:	0c 00                	or     al,0x0
     898:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     89b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     89e:	45                   	inc    bp
     89f:	52                   	push   dx
     8a0:	47                   	inc    di
     8a1:	43                   	inc    bx
     8a2:	68 69 66             	push   0x6669
     8a5:	66 72 65             	data32 jb 0x90d
     8a8:	41                   	inc    cx
     8a9:	66 66 61             	data32 popad
     8ac:	69 72 65 54 54       	imul   si,WORD PTR [bp+si+0x65],0x5454
     8b1:	43                   	inc    bx
     8b2:	c8 02 0c 00          	enter  0xc02,0x0
     8b6:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
     8b9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8bc:	45                   	inc    bp
     8bd:	52                   	push   dx
     8be:	47                   	inc    di
     8bf:	4d                   	dec    bp
     8c0:	61                   	popa
     8c1:	74 69                	je     0x92c
     8c3:	65 72 65             	gs jb  0x92b
     8c6:	43                   	inc    bx
     8c7:	6f                   	outs   dx,WORD PTR ds:[si]
     8c8:	6e                   	outs   dx,BYTE PTR ds:[si]
     8c9:	73 6f                	jae    0x93a
     8cb:	6d                   	ins    WORD PTR es:[di],dx
     8cc:	6d                   	ins    WORD PTR es:[di],dx
     8cd:	65 65 54             	gs gs push sp
     8d0:	54                   	push   sp
     8d1:	43                   	inc    bx
     8d2:	cc                   	int3
     8d3:	02 0c                	add    cl,BYTE PTR [si]
     8d5:	00 11                	add    BYTE PTR [bx+di],dl
     8d7:	54                   	push   sp
     8d8:	61                   	popa
     8d9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8dc:	45                   	inc    bp
     8dd:	52                   	push   dx
     8de:	47                   	inc    di
     8df:	45                   	inc    bp
     8e0:	74 75                	je     0x957
     8e2:	64 65 73 54          	fs gs jae 0x93a
     8e6:	54                   	push   sp
     8e7:	43                   	inc    bx
     8e8:	d0 02                	rol    BYTE PTR [bp+si],1
     8ea:	0c 00                	or     al,0x0
     8ec:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     8ef:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8f2:	45                   	inc    bp
     8f3:	52                   	push   dx
     8f4:	47                   	inc    di
     8f5:	50                   	push   ax
     8f6:	75 62                	jne    0x95a
     8f8:	45                   	inc    bp
     8f9:	74 41                	je     0x93c
     8fb:	63 74 69             	arpl   WORD PTR [si+0x69],si
     8fe:	6f                   	outs   dx,WORD PTR ds:[si]
     8ff:	6e                   	outs   dx,BYTE PTR ds:[si]
     900:	43                   	inc    bx
     901:	6f                   	outs   dx,WORD PTR ds:[si]
     902:	6d                   	ins    WORD PTR es:[di],dx
     903:	54                   	push   sp
     904:	54                   	push   sp
     905:	43                   	inc    bx
     906:	d4 02                	aam    0x2
     908:	0c 00                	or     al,0x0
     90a:	15 54 61             	adc    ax,0x6154
     90d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     910:	45                   	inc    bp
     911:	52                   	push   dx
     912:	47                   	inc    di
     913:	54                   	push   sp
     914:	56                   	push   si
     915:	41                   	inc    cx
     916:	61                   	popa
     917:	44                   	inc    sp
     918:	65 63 61 69          	arpl   WORD PTR gs:[bx+di+0x69],sp
     91c:	73 73                	jae    0x991
     91e:	65 72 d8             	gs jb  0x8f9
     921:	02 0c                	add    cl,BYTE PTR [si]
     923:	00 1a                	add    BYTE PTR [bp+si],bl
     925:	54                   	push   sp
     926:	61                   	popa
     927:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     92a:	45                   	inc    bp
     92b:	52                   	push   dx
     92c:	47                   	inc    di
     92d:	49                   	dec    cx
     92e:	6e                   	outs   dx,BYTE PTR ds:[si]
     92f:	76 65                	jbe    0x996
     931:	73 74                	jae    0x9a7
     933:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     938:	65 6e                	outs   dx,BYTE PTR gs:[si]
     93a:	74 73                	je     0x9af
     93c:	54                   	push   sp
     93d:	54                   	push   sp
     93e:	43                   	inc    bx
     93f:	dc 02                	fadd   QWORD PTR [bp+si]
     941:	0c 00                	or     al,0x0
     943:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     946:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     949:	45                   	inc    bp
     94a:	52                   	push   dx
     94b:	47                   	inc    di
     94c:	43                   	inc    bx
     94d:	65 73 73             	gs jae 0x9c3
     950:	69 6f 6e 73 54       	imul   bp,WORD PTR [bx+0x6e],0x5473
     955:	54                   	push   sp
     956:	43                   	inc    bx
     957:	e0 02                	loopne 0x95b
     959:	20 00                	and    BYTE PTR [bx+si],al
     95b:	15 54 61             	adc    ax,0x6154
     95e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     961:	45                   	inc    bp
     962:	52                   	push   dx
     963:	47                   	inc    di
     964:	54                   	push   sp
     965:	56                   	push   si
     966:	41                   	inc    cx
     967:	44                   	inc    sp
     968:	65 64 75 63          	gs fs jne 0x9cf
     96c:	74 69                	je     0x9d7
     96e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     971:	e4 02                	in     al,0x2
     973:	20 00                	and    BYTE PTR [bx+si],al
     975:	1a 54 61             	sbb    dl,BYTE PTR [si+0x61]
     978:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     97b:	45                   	inc    bp
     97c:	52                   	push   dx
     97d:	47                   	inc    di
     97e:	52                   	push   dx
     97f:	65 6d                	gs ins WORD PTR es:[di],dx
     981:	75 6e                	jne    0x9f1
     983:	65 72 61             	gs jb  0x9e7
     986:	74 69                	je     0x9f1
     988:	6f                   	outs   dx,WORD PTR ds:[si]
     989:	6e                   	outs   dx,BYTE PTR ds:[si]
     98a:	43                   	inc    bx
     98b:	61                   	popa
     98c:	64 72 65             	fs jb  0x9f4
     98f:	73 e8                	jae    0x979
     991:	02 20                	add    ah,BYTE PTR [bx+si]
     993:	00 14                	add    BYTE PTR [si],dl
     995:	54                   	push   sp
     996:	61                   	popa
     997:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     99a:	45                   	inc    bp
     99b:	52                   	push   dx
     99c:	47                   	inc    di
     99d:	54                   	push   sp
     99e:	56                   	push   si
     99f:	41                   	inc    cx
     9a0:	43                   	inc    bx
     9a1:	6f                   	outs   dx,WORD PTR ds:[si]
     9a2:	6c                   	ins    BYTE PTR es:[di],dx
     9a3:	6c                   	ins    BYTE PTR es:[di],dx
     9a4:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
     9a8:	65 ec                	gs in  al,dx
     9aa:	02 14                	add    dl,BYTE PTR [si]
     9ac:	00 06 46 69          	add    BYTE PTR ds:0x6946,al
     9b0:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     9b3:	31 f0                	xor    ax,si
     9b5:	02 14                	add    dl,BYTE PTR [si]
     9b7:	00 02                	add    BYTE PTR [bp+si],al
     9b9:	4e                   	dec    si
     9ba:	33 f4                	xor    si,sp
     9bc:	02 00                	add    al,BYTE PTR [bx+si]
     9be:	00 07                	add    BYTE PTR [bx],al
     9c0:	50                   	push   ax
     9c1:	61                   	popa
     9c2:	6e                   	outs   dx,BYTE PTR ds:[si]
     9c3:	65 6c                	gs ins BYTE PTR es:[di],dx
     9c5:	34 34                	xor    al,0x34
     9c7:	f8                   	clc
     9c8:	02 24                	add    ah,BYTE PTR [si]
     9ca:	00 07                	add    BYTE PTR [bx],al
     9cc:	4c                   	dec    sp
     9cd:	61                   	popa
     9ce:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     9d1:	55                   	push   bp
     9d2:	30 fc                	xor    ah,bh
     9d4:	02 24                	add    ah,BYTE PTR [si]
     9d6:	00 07                	add    BYTE PTR [bx],al
     9d8:	4c                   	dec    sp
     9d9:	61                   	popa
     9da:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     9dd:	55                   	push   bp
     9de:	31 00                	xor    WORD PTR [bx+si],ax
     9e0:	03 24                	add    sp,WORD PTR [si]
     9e2:	00 07                	add    BYTE PTR [bx],al
     9e4:	4c                   	dec    sp
     9e5:	61                   	popa
     9e6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     9e9:	55                   	push   bp
     9ea:	32 04                	xor    al,BYTE PTR [si]
     9ec:	03 24                	add    sp,WORD PTR [si]
     9ee:	00 07                	add    BYTE PTR [bx],al
     9f0:	4c                   	dec    sp
     9f1:	61                   	popa
     9f2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     9f5:	55                   	push   bp
     9f6:	33 08                	xor    cx,WORD PTR [bx+si]
     9f8:	03 28                	add    bp,WORD PTR [bx+si]
     9fa:	00 05                	add    BYTE PTR [di],al
     9fc:	4d                   	dec    bp
     9fd:	65 6d                	gs ins WORD PTR es:[di],dx
     9ff:	6f                   	outs   dx,WORD PTR ds:[si]
     a00:	31 0c                	xor    WORD PTR [si],cx
     a02:	03 14                	add    dx,WORD PTR [si]
     a04:	00 08                	add    BYTE PTR [bx+si],cl
     a06:	45                   	inc    bp
     a07:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
     a0d:	31 10                	xor    WORD PTR [bx+si],dx
     a0f:	03 14                	add    dx,WORD PTR [si]
     a11:	00 07                	add    BYTE PTR [bx],al
     a13:	43                   	inc    bx
     a14:	6f                   	outs   dx,WORD PTR ds:[si]
     a15:	70 69                	jo     0xa80
     a17:	65 72 31             	gs jb  0xa4b
     a1a:	14 03                	adc    al,0x3
     a1c:	20 00                	and    BYTE PTR [bx+si],al
     a1e:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     a21:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a24:	45                   	inc    bp
     a25:	52                   	push   dx
     a26:	47                   	inc    di
     a27:	52                   	push   dx
     a28:	65 70 61             	gs jo  0xa8c
     a2b:	72 61                	jb     0xa8e
     a2d:	74 69                	je     0xa98
     a2f:	6f                   	outs   dx,WORD PTR ds:[si]
     a30:	6e                   	outs   dx,BYTE PTR ds:[si]
     a31:	73 18                	jae    0xa4b
     a33:	03 20                	add    sp,WORD PTR [bx+si]
     a35:	00 15                	add    BYTE PTR [di],dl
     a37:	54                   	push   sp
     a38:	61                   	popa
     a39:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a3c:	45                   	inc    bp
     a3d:	52                   	push   dx
     a3e:	47                   	inc    di
     a3f:	52                   	push   dx
     a40:	65 6d                	gs ins WORD PTR es:[di],dx
     a42:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
     a45:	72 73                	jb     0xaba
     a47:	41                   	inc    cx
     a48:	73 73                	jae    0xabd
     a4a:	75 72                	jne    0xabe
     a4c:	1c 03                	sbb    al,0x3
     a4e:	20 00                	and    BYTE PTR [bx+si],al
     a50:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     a53:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a56:	45                   	inc    bp
     a57:	52                   	push   dx
     a58:	47                   	inc    di
     a59:	49                   	dec    cx
     a5a:	6e                   	outs   dx,BYTE PTR ds:[si]
     a5b:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
     a61:	74 69                	je     0xacc
     a63:	73 50                	jae    0xab5
     a65:	65 72 73             	gs jb  0xadb
     a68:	6f                   	outs   dx,WORD PTR ds:[si]
     a69:	6e                   	outs   dx,BYTE PTR ds:[si]
     a6a:	20 03                	and    BYTE PTR [bp+di],al
     a6c:	20 00                	and    BYTE PTR [bx+si],al
     a6e:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     a71:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a74:	45                   	inc    bp
     a75:	52                   	push   dx
     a76:	47                   	inc    di
     a77:	49                   	dec    cx
     a78:	6e                   	outs   dx,BYTE PTR ds:[si]
     a79:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
     a7f:	74 69                	je     0xaea
     a81:	73 41                	jae    0xac4
     a83:	63 74 69             	arpl   WORD PTR [si+0x69],si
     a86:	6f                   	outs   dx,WORD PTR ds:[si]
     a87:	6e                   	outs   dx,BYTE PTR ds:[si]
     a88:	24 03                	and    al,0x3
     a8a:	20 00                	and    BYTE PTR [bx+si],al
     a8c:	10 54 61             	adc    BYTE PTR [si+0x61],dl
     a8f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a92:	45                   	inc    bp
     a93:	52                   	push   dx
     a94:	47                   	inc    di
     a95:	50                   	push   ax
     a96:	61                   	popa
     a97:	6e                   	outs   dx,BYTE PTR ds:[si]
     a98:	6e                   	outs   dx,BYTE PTR ds:[si]
     a99:	65 73 50             	gs jae 0xaec
     a9c:	63 28                	arpl   WORD PTR [bx+si],bp
     a9e:	03 20                	add    sp,WORD PTR [bx+si]
     aa0:	00 10                	add    BYTE PTR [bx+si],dl
     aa2:	54                   	push   sp
     aa3:	61                   	popa
     aa4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     aa7:	45                   	inc    bp
     aa8:	52                   	push   dx
     aa9:	47                   	inc    di
     aaa:	47                   	inc    di
     aab:	72 65                	jb     0xb12
     aad:	76 65                	jbe    0xb14
     aaf:	73 50                	jae    0xb01
     ab1:	63 2c                	arpl   WORD PTR [si],bp
     ab3:	03 1c                	add    bx,WORD PTR [si]
     ab5:	00 1c                	add    BYTE PTR [si],bl
     ab7:	54                   	push   sp
     ab8:	61                   	popa
     ab9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     abc:	45                   	inc    bp
     abd:	52                   	push   dx
     abe:	47                   	inc    di
     abf:	4d                   	dec    bp
     ac0:	61                   	popa
     ac1:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     ac4:	6e                   	outs   dx,BYTE PTR ds:[si]
     ac5:	65 73 44             	gs jae 0xb0c
     ac8:	65 74 72             	gs je  0xb3d
     acb:	75 69                	jne    0xb36
     acd:	74 65                	je     0xb34
     acf:	73 51                	jae    0xb22
     ad1:	74 65                	je     0xb38
     ad3:	30 03                	xor    BYTE PTR [bp+di],al
     ad5:	1c 00                	sbb    al,0x0
     ad7:	17                   	pop    ss
     ad8:	54                   	push   sp
     ad9:	61                   	popa
     ada:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     add:	45                   	inc    bp
     ade:	52                   	push   dx
     adf:	47                   	inc    di
     ae0:	53                   	push   bx
     ae1:	74 6f                	je     0xb52
     ae3:	63 6b 44             	arpl   WORD PTR [bp+di+0x44],bp
     ae6:	65 74 72             	gs je  0xb5b
     ae9:	75 69                	jne    0xb54
     aeb:	74 51                	je     0xb3e
     aed:	74 65                	je     0xb54
     aef:	34 03                	xor    al,0x3
     af1:	1c 00                	sbb    al,0x0
     af3:	1c 54                	sbb    al,0x54
     af5:	61                   	popa
     af6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     af9:	45                   	inc    bp
     afa:	52                   	push   dx
     afb:	47                   	inc    di
     afc:	44                   	inc    sp
     afd:	65 6d                	gs ins WORD PTR es:[di],dx
     aff:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
     b04:	6e                   	outs   dx,BYTE PTR ds:[si]
     b05:	73 50                	jae    0xb57
     b07:	72 6f                	jb     0xb78
     b09:	64 75 63             	fs jne 0xb6f
     b0c:	74 69                	je     0xb77
     b0e:	66 73 38             	data32 jae 0xb49
     b11:	03 1c                	add    bx,WORD PTR [si]
     b13:	00 1a                	add    BYTE PTR [bp+si],bl
     b15:	54                   	push   sp
     b16:	61                   	popa
     b17:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b1a:	45                   	inc    bp
     b1b:	52                   	push   dx
     b1c:	47                   	inc    di
     b1d:	44                   	inc    sp
     b1e:	65 6d                	gs ins WORD PTR es:[di],dx
     b20:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
     b25:	6e                   	outs   dx,BYTE PTR ds:[si]
     b26:	73 56                	jae    0xb7e
     b28:	65 6e                	outs   dx,BYTE PTR gs:[si]
     b2a:	64 65 75 72          	fs gs jne 0xba0
     b2e:	73 3c                	jae    0xb6c
     b30:	03 20                	add    sp,WORD PTR [bx+si]
     b32:	00 18                	add    BYTE PTR [bx+si],bl
     b34:	54                   	push   sp
     b35:	61                   	popa
     b36:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b39:	45                   	inc    bp
     b3a:	52                   	push   dx
     b3b:	47                   	inc    di
     b3c:	41                   	inc    cx
     b3d:	67 65 4d             	addr32 gs dec bp
     b40:	6f                   	outs   dx,WORD PTR ds:[si]
     b41:	79 65                	jns    0xba8
     b43:	6e                   	outs   dx,BYTE PTR ds:[si]
     b44:	4d                   	dec    bp
     b45:	61                   	popa
     b46:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     b49:	6e                   	outs   dx,BYTE PTR ds:[si]
     b4a:	65 73 40             	gs jae 0xb8d
     b4d:	03 20                	add    sp,WORD PTR [bx+si]
     b4f:	00 19                	add    BYTE PTR [bx+di],bl
     b51:	54                   	push   sp
     b52:	61                   	popa
     b53:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b56:	45                   	inc    bp
     b57:	52                   	push   dx
     b58:	47                   	inc    di
     b59:	45                   	inc    bp
     b5a:	6e                   	outs   dx,BYTE PTR ds:[si]
     b5b:	74 72                	je     0xbcf
     b5d:	65 74 69             	gs je  0xbc9
     b60:	65 6e                	outs   dx,BYTE PTR gs:[si]
     b62:	4d                   	dec    bp
     b63:	61                   	popa
     b64:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     b67:	6e                   	outs   dx,BYTE PTR ds:[si]
     b68:	65 73 44             	gs jae 0xbaf
     b6b:	03 20                	add    sp,WORD PTR [bx+si]
     b6d:	00 17                	add    BYTE PTR [bx],dl
     b6f:	54                   	push   sp
     b70:	61                   	popa
     b71:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b74:	45                   	inc    bp
     b75:	52                   	push   dx
     b76:	47                   	inc    di
     b77:	50                   	push   ax
     b78:	72 69                	jb     0xbe3
     b7a:	6d                   	ins    WORD PTR es:[di],dx
     b7b:	65 73 41             	gs jae 0xbbf
     b7e:	73 73                	jae    0xbf3
     b80:	75 72                	jne    0xbf4
     b82:	61                   	popa
     b83:	6e                   	outs   dx,BYTE PTR ds:[si]
     b84:	63 65 48             	arpl   WORD PTR [di+0x48],sp
     b87:	03 14                	add    dx,WORD PTR [si]
     b89:	00 0f                	add    BYTE PTR [bx],cl
     b8b:	41                   	inc    cx
     b8c:	75 74                	jne    0xc02
     b8e:	72 65                	jb     0xbf5
     b90:	73 72                	jae    0xc04
     b92:	73 75                	jae    0xc09
     b94:	6c                   	ins    BYTE PTR es:[di],dx
     b95:	74 61                	je     0xbf8
     b97:	74 73                	je     0xc0c
     b99:	31 4c 03             	xor    WORD PTR [si+0x3],cx
     b9c:	14 00                	adc    al,0x0
     b9e:	13 52 61             	adc    dx,WORD PTR [bp+si+0x61]
     ba1:	70 70                	jo     0xc13
     ba3:	65 6c                	gs ins BYTE PTR es:[di],dx
     ba5:	44                   	inc    sp
     ba6:	65 73 44             	gs jae 0xbed
     ba9:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     bad:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     bb2:	50                   	push   ax
     bb3:	03 14                	add    dx,WORD PTR [si]
     bb5:	00 02                	add    BYTE PTR [bp+si],al
     bb7:	4e                   	dec    si
     bb8:	34 54                	xor    al,0x54
     bba:	03 14                	add    dx,WORD PTR [si]
     bbc:	00 14                	add    BYTE PTR [si],dl
     bbe:	54                   	push   sp
     bbf:	61                   	popa
     bc0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bc3:	61                   	popa
     bc4:	75 44                	jne    0xc0a
     bc6:	65 54                	gs push sp
     bc8:	72 65                	jb     0xc2f
     bca:	73 6f                	jae    0xc3b
     bcc:	72 65                	jb     0xc33
     bce:	72 69                	jb     0xc39
     bd0:	65 31 58 03          	xor    WORD PTR gs:[bx+si+0x3],bx
     bd4:	14 00                	adc    al,0x0
     bd6:	15 54 61             	adc    ax,0x6154
     bd9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bdc:	61                   	popa
     bdd:	75 44                	jne    0xc23
     bdf:	65 46                	gs inc si
     be1:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     be6:	65 6d                	gs ins WORD PTR es:[di],dx
     be8:	65 6e                	outs   dx,BYTE PTR gs:[si]
     bea:	74 31                	je     0xc1d
     bec:	5c                   	pop    sp
     bed:	03 14                	add    dx,WORD PTR [si]
     bef:	00 06 42 69          	add    BYTE PTR ds:0x6942,al
     bf3:	6c                   	ins    BYTE PTR es:[di],dx
     bf4:	61                   	popa
     bf5:	6e                   	outs   dx,BYTE PTR ds:[si]
     bf6:	31 60 03             	xor    WORD PTR [bx+si+0x3],sp
     bf9:	14 00                	adc    al,0x0
     bfb:	12 43 6f             	adc    al,BYTE PTR [bp+di+0x6f]
     bfe:	6d                   	ins    WORD PTR es:[di],dx
     bff:	70 74                	jo     0xc75
     c01:	65 44                	gs inc sp
     c03:	65 52                	gs push dx
     c05:	65 73 75             	gs jae 0xc7d
     c08:	6c                   	ins    BYTE PTR es:[di],dx
     c09:	74 61                	je     0xc6c
     c0b:	74 73                	je     0xc80
     c0d:	31 64 03             	xor    WORD PTR [si+0x3],sp
     c10:	14 00                	adc    al,0x0
     c12:	0a 53 69             	or     dl,BYTE PTR [bp+di+0x69]
     c15:	74 75                	je     0xc8c
     c17:	61                   	popa
     c18:	74 69                	je     0xc83
     c1a:	6f                   	outs   dx,WORD PTR ds:[si]
     c1b:	6e                   	outs   dx,BYTE PTR ds:[si]
     c1c:	31 68 03             	xor    WORD PTR [bx+si+0x3],bp
     c1f:	14 00                	adc    al,0x0
     c21:	05 4e 31             	add    ax,0x314e
     c24:	30 30                	xor    BYTE PTR [bx+si],dh
     c26:	31 6c 03             	xor    WORD PTR [si+0x3],bp
     c29:	14 00                	adc    al,0x0
     c2b:	05 4e 31             	add    ax,0x314e
     c2e:	35 30 31             	xor    ax,0x3130
     c31:	70 03                	jo     0xc36
     c33:	14 00                	adc    al,0x0
     c35:	05 4e 32             	add    ax,0x324e
     c38:	30 30                	xor    BYTE PTR [bx+si],dh
     c3a:	31 74 03             	xor    WORD PTR [si+0x3],si
     c3d:	14 00                	adc    al,0x0
     c3f:	04 4e                	add    al,0x4e
     c41:	37                   	aaa
     c42:	35 31 78             	xor    ax,0x7831
     c45:	03 14                	add    dx,WORD PTR [si]
     c47:	00 04                	add    BYTE PTR [si],al
     c49:	4e                   	dec    si
     c4a:	35 30 31             	xor    ax,0x3130
     c4d:	7c 03                	jl     0xc52
     c4f:	14 00                	adc    al,0x0
     c51:	02 4e 35             	add    cl,BYTE PTR [bp+0x35]
     c54:	80 03 0c             	add    BYTE PTR [bp+di],0xc
     c57:	00 12                	add    BYTE PTR [bp+si],dl
     c59:	54                   	push   sp
     c5a:	61                   	popa
     c5b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c5e:	45                   	inc    bp
     c5f:	52                   	push   dx
     c60:	47                   	inc    di
     c61:	51                   	push   cx
     c62:	75 61                	jne    0xcc5
     c64:	6c                   	ins    BYTE PTR es:[di],dx
     c65:	69 74 65 54 54       	imul   si,WORD PTR [si+0x65],0x5454
     c6a:	43                   	inc    bx
     c6b:	84 03                	test   BYTE PTR [bp+di],al
     c6d:	14 00                	adc    al,0x0
     c6f:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
     c72:	70 72                	jo     0xce6
     c74:	65 73 73             	gs jae 0xcea
     c77:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     c7c:	70 69                	jo     0xce7
     c7e:	64 65 31 88 03 14    	fs xor WORD PTR gs:[bx+si+0x1403],cx
     c84:	00 02                	add    BYTE PTR [bp+si],al
     c86:	4e                   	dec    si
     c87:	36 8c 03             	mov    WORD PTR ss:[bp+di],es
     c8a:	14 00                	adc    al,0x0
     c8c:	05 4e 31             	add    ax,0x314e
     c8f:	32 35                	xor    dh,BYTE PTR [di]
     c91:	31 90 03 14          	xor    WORD PTR [bx+si+0x1403],dx
     c95:	00 08                	add    BYTE PTR [bx+si],cl
     c97:	50                   	push   ax
     c98:	65 72 69             	gs jb  0xd04
     c9b:	6f                   	outs   dx,WORD PTR ds:[si]
     c9c:	64 65 32 94 03 14    	fs xor dl,BYTE PTR gs:[si+0x1403]
     ca2:	00 06 61 75          	add    BYTE PTR ds:0x7561,al
     ca6:	74 72                	je     0xd1a
     ca8:	65 31 98 03 14       	xor    WORD PTR gs:[bx+si+0x1403],bx
     cad:	00 04                	add    BYTE PTR [si],al
     caf:	4e                   	dec    si
     cb0:	32 30                	xor    dh,BYTE PTR [bx+si]
     cb2:	31 9c 03 14          	xor    WORD PTR [si+0x1403],bx
     cb6:	00 04                	add    BYTE PTR [si],al
     cb8:	4e                   	dec    si
     cb9:	31 39                	xor    WORD PTR [bx+di],di
     cbb:	31 a0 03 14          	xor    WORD PTR [bx+si+0x1403],sp
     cbf:	00 04                	add    BYTE PTR [si],al
     cc1:	4e                   	dec    si
     cc2:	31 38                	xor    WORD PTR [bx+si],di
     cc4:	31 a4 03 14          	xor    WORD PTR [si+0x1403],sp
     cc8:	00 04                	add    BYTE PTR [si],al
     cca:	4e                   	dec    si
     ccb:	31 37                	xor    WORD PTR [bx],si
     ccd:	31 a8 03 14          	xor    WORD PTR [bx+si+0x1403],bp
     cd1:	00 04                	add    BYTE PTR [si],al
     cd3:	4e                   	dec    si
     cd4:	31 36 31 ac          	xor    WORD PTR ds:0xac31,si
     cd8:	03 14                	add    dx,WORD PTR [si]
     cda:	00 04                	add    BYTE PTR [si],al
     cdc:	4e                   	dec    si
     cdd:	31 35                	xor    WORD PTR [di],si
     cdf:	31 b0 03 14          	xor    WORD PTR [bx+si+0x1403],si
     ce3:	00 04                	add    BYTE PTR [si],al
     ce5:	4e                   	dec    si
     ce6:	31 34                	xor    WORD PTR [si],si
     ce8:	31 b4 03 14          	xor    WORD PTR [si+0x1403],si
     cec:	00 04                	add    BYTE PTR [si],al
     cee:	4e                   	dec    si
     cef:	31 33                	xor    WORD PTR [bp+di],si
     cf1:	31 b8 03 14          	xor    WORD PTR [bx+si+0x1403],di
     cf5:	00 04                	add    BYTE PTR [si],al
     cf7:	4e                   	dec    si
     cf8:	31 32                	xor    WORD PTR [bp+si],si
     cfa:	31 bc 03 14          	xor    WORD PTR [si+0x1403],di
     cfe:	00 04                	add    BYTE PTR [si],al
     d00:	4e                   	dec    si
     d01:	31 31                	xor    WORD PTR [bx+di],si
     d03:	31 c0                	xor    ax,ax
     d05:	03 14                	add    dx,WORD PTR [si]
     d07:	00 04                	add    BYTE PTR [si],al
     d09:	4e                   	dec    si
     d0a:	31 30                	xor    WORD PTR [bx+si],si
     d0c:	31 c4                	xor    sp,ax
     d0e:	03 14                	add    dx,WORD PTR [si]
     d10:	00 03                	add    BYTE PTR [bp+di],al
     d12:	4e                   	dec    si
     d13:	39 31                	cmp    WORD PTR [bx+di],si
     d15:	c8 03 14 00          	enter  0x1403,0x0
     d19:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
     d1c:	32 cc                	xor    cl,ah
     d1e:	03 14                	add    dx,WORD PTR [si]
     d20:	00 03                	add    BYTE PTR [bp+di],al
     d22:	4e                   	dec    si
     d23:	37                   	aaa
     d24:	32 d0                	xor    dl,al
     d26:	03 14                	add    dx,WORD PTR [si]
     d28:	00 03                	add    BYTE PTR [bp+di],al
     d2a:	4e                   	dec    si
     d2b:	36 32 d4             	ss xor dl,ah
     d2e:	03 14                	add    dx,WORD PTR [si]
     d30:	00 03                	add    BYTE PTR [bp+di],al
     d32:	4e                   	dec    si
     d33:	35 32 d8             	xor    ax,0xd832
     d36:	03 14                	add    dx,WORD PTR [si]
     d38:	00 03                	add    BYTE PTR [bp+di],al
     d3a:	4e                   	dec    si
     d3b:	34 32                	xor    al,0x32
     d3d:	dc 03                	fadd   QWORD PTR [bp+di]
     d3f:	14 00                	adc    al,0x0
     d41:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     d44:	32 e0                	xor    ah,al
     d46:	03 14                	add    dx,WORD PTR [si]
     d48:	00 03                	add    BYTE PTR [bp+di],al
     d4a:	4e                   	dec    si
     d4b:	32 32                	xor    dh,BYTE PTR [bp+si]
     d4d:	e4 03                	in     al,0x3
     d4f:	14 00                	adc    al,0x0
     d51:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
     d54:	32 e8                	xor    ch,al
     d56:	03 14                	add    dx,WORD PTR [si]
     d58:	00 04                	add    BYTE PTR [si],al
     d5a:	53                   	push   bx
     d5b:	49                   	dec    cx
     d5c:	47                   	inc    di
     d5d:	31 ec                	xor    sp,bp
     d5f:	03 00                	add    ax,WORD PTR [bx+si]
     d61:	00 07                	add    BYTE PTR [bx],al
     d63:	50                   	push   ax
     d64:	61                   	popa
     d65:	6e                   	outs   dx,BYTE PTR ds:[si]
     d66:	65 6c                	gs ins BYTE PTR es:[di],dx
     d68:	34 36                	xor    al,0x36
     d6a:	f0 03 00             	lock add ax,WORD PTR [bx+si]
     d6d:	00 07                	add    BYTE PTR [bx],al
     d6f:	50                   	push   ax
     d70:	61                   	popa
     d71:	6e                   	outs   dx,BYTE PTR ds:[si]
     d72:	65 6c                	gs ins BYTE PTR es:[di],dx
     d74:	34 39                	xor    al,0x39
     d76:	f4                   	hlt
     d77:	03 2c                	add    bp,WORD PTR [si]
     d79:	00 09                	add    BYTE PTR [bx+di],cl
     d7b:	44                   	inc    sp
     d7c:	42                   	inc    dx
     d7d:	45                   	inc    bp
     d7e:	64 69 74 33 30 31    	imul   si,WORD PTR fs:[si+0x33],0x3130
     d84:	f8                   	clc
     d85:	03 00                	add    ax,WORD PTR [bx+si]
     d87:	00 07                	add    BYTE PTR [bx],al
     d89:	50                   	push   ax
     d8a:	61                   	popa
     d8b:	6e                   	outs   dx,BYTE PTR ds:[si]
     d8c:	65 6c                	gs ins BYTE PTR es:[di],dx
     d8e:	35 30 fc             	xor    ax,0xfc30
     d91:	03 2c                	add    bp,WORD PTR [si]
     d93:	00 09                	add    BYTE PTR [bx+di],cl
     d95:	44                   	inc    sp
     d96:	42                   	inc    dx
     d97:	45                   	inc    bp
     d98:	64 69 74 32 31 30    	imul   si,WORD PTR fs:[si+0x32],0x3031
     d9e:	00 04                	add    BYTE PTR [si],al
     da0:	00 00                	add    BYTE PTR [bx+si],al
     da2:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     da5:	6e                   	outs   dx,BYTE PTR ds:[si]
     da6:	65 6c                	gs ins BYTE PTR es:[di],dx
     da8:	32 30                	xor    dh,BYTE PTR [bx+si]
     daa:	30 04                	xor    BYTE PTR [si],al
     dac:	04 00                	add    al,0x0
     dae:	00 07                	add    BYTE PTR [bx],al
     db0:	50                   	push   ax
     db1:	61                   	popa
     db2:	6e                   	outs   dx,BYTE PTR ds:[si]
     db3:	65 6c                	gs ins BYTE PTR es:[di],dx
     db5:	32 32                	xor    dh,BYTE PTR [bp+si]
     db7:	08 04                	or     BYTE PTR [si],al
     db9:	00 00                	add    BYTE PTR [bx+si],al
     dbb:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     dbe:	6e                   	outs   dx,BYTE PTR ds:[si]
     dbf:	65 6c                	gs ins BYTE PTR es:[di],dx
     dc1:	31 30                	xor    WORD PTR [bx+si],si
     dc3:	32 0c                	xor    cl,BYTE PTR [si]
     dc5:	04 00                	add    al,0x0
     dc7:	00 08                	add    BYTE PTR [bx+si],cl
     dc9:	50                   	push   ax
     dca:	61                   	popa
     dcb:	6e                   	outs   dx,BYTE PTR ds:[si]
     dcc:	65 6c                	gs ins BYTE PTR es:[di],dx
     dce:	31 30                	xor    WORD PTR [bx+si],si
     dd0:	33 10                	xor    dx,WORD PTR [bx+si]
     dd2:	04 00                	add    al,0x0
     dd4:	00 08                	add    BYTE PTR [bx+si],cl
     dd6:	50                   	push   ax
     dd7:	61                   	popa
     dd8:	6e                   	outs   dx,BYTE PTR ds:[si]
     dd9:	65 6c                	gs ins BYTE PTR es:[di],dx
     ddb:	31 30                	xor    WORD PTR [bx+si],si
     ddd:	35 14 04             	xor    ax,0x414
     de0:	00 00                	add    BYTE PTR [bx+si],al
     de2:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     de5:	6e                   	outs   dx,BYTE PTR ds:[si]
     de6:	65 6c                	gs ins BYTE PTR es:[di],dx
     de8:	31 30                	xor    WORD PTR [bx+si],si
     dea:	37                   	aaa
     deb:	18 04                	sbb    BYTE PTR [si],al
     ded:	00 00                	add    BYTE PTR [bx+si],al
     def:	07                   	pop    es
     df0:	50                   	push   ax
     df1:	61                   	popa
     df2:	6e                   	outs   dx,BYTE PTR ds:[si]
     df3:	65 6c                	gs ins BYTE PTR es:[di],dx
     df5:	36 39 1c             	cmp    WORD PTR ss:[si],bx
     df8:	04 00                	add    al,0x0
     dfa:	00 08                	add    BYTE PTR [bx+si],cl
     dfc:	50                   	push   ax
     dfd:	61                   	popa
     dfe:	6e                   	outs   dx,BYTE PTR ds:[si]
     dff:	65 6c                	gs ins BYTE PTR es:[di],dx
     e01:	31 31                	xor    WORD PTR [bx+di],si
     e03:	31 20                	xor    WORD PTR [bx+si],sp
     e05:	04 00                	add    al,0x0
     e07:	00 08                	add    BYTE PTR [bx+si],cl
     e09:	50                   	push   ax
     e0a:	61                   	popa
     e0b:	6e                   	outs   dx,BYTE PTR ds:[si]
     e0c:	65 6c                	gs ins BYTE PTR es:[di],dx
     e0e:	31 31                	xor    WORD PTR [bx+di],si
     e10:	32 24                	xor    ah,BYTE PTR [si]
     e12:	04 00                	add    al,0x0
     e14:	00 08                	add    BYTE PTR [bx+si],cl
     e16:	50                   	push   ax
     e17:	61                   	popa
     e18:	6e                   	outs   dx,BYTE PTR ds:[si]
     e19:	65 6c                	gs ins BYTE PTR es:[di],dx
     e1b:	31 31                	xor    WORD PTR [bx+di],si
     e1d:	34 28                	xor    al,0x28
     e1f:	04 00                	add    al,0x0
     e21:	00 08                	add    BYTE PTR [bx+si],cl
     e23:	50                   	push   ax
     e24:	61                   	popa
     e25:	6e                   	outs   dx,BYTE PTR ds:[si]
     e26:	65 6c                	gs ins BYTE PTR es:[di],dx
     e28:	31 31                	xor    WORD PTR [bx+di],si
     e2a:	35 2c 04             	xor    ax,0x42c
     e2d:	00 00                	add    BYTE PTR [bx+si],al
     e2f:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     e32:	6e                   	outs   dx,BYTE PTR ds:[si]
     e33:	65 6c                	gs ins BYTE PTR es:[di],dx
     e35:	31 31                	xor    WORD PTR [bx+di],si
     e37:	36 30 04             	xor    BYTE PTR ss:[si],al
     e3a:	00 00                	add    BYTE PTR [bx+si],al
     e3c:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     e3f:	6e                   	outs   dx,BYTE PTR ds:[si]
     e40:	65 6c                	gs ins BYTE PTR es:[di],dx
     e42:	31 31                	xor    WORD PTR [bx+di],si
     e44:	37                   	aaa
     e45:	34 04                	xor    al,0x4
     e47:	00 00                	add    BYTE PTR [bx+si],al
     e49:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     e4c:	6e                   	outs   dx,BYTE PTR ds:[si]
     e4d:	65 6c                	gs ins BYTE PTR es:[di],dx
     e4f:	31 31                	xor    WORD PTR [bx+di],si
     e51:	38 38                	cmp    BYTE PTR [bx+si],bh
     e53:	04 00                	add    al,0x0
     e55:	00 08                	add    BYTE PTR [bx+si],cl
     e57:	50                   	push   ax
     e58:	61                   	popa
     e59:	6e                   	outs   dx,BYTE PTR ds:[si]
     e5a:	65 6c                	gs ins BYTE PTR es:[di],dx
     e5c:	31 31                	xor    WORD PTR [bx+di],si
     e5e:	39 3c                	cmp    WORD PTR [si],di
     e60:	04 00                	add    al,0x0
     e62:	00 08                	add    BYTE PTR [bx+si],cl
     e64:	50                   	push   ax
     e65:	61                   	popa
     e66:	6e                   	outs   dx,BYTE PTR ds:[si]
     e67:	65 6c                	gs ins BYTE PTR es:[di],dx
     e69:	31 32                	xor    WORD PTR [bp+si],si
     e6b:	31 40 04             	xor    WORD PTR [bx+si+0x4],ax
     e6e:	00 00                	add    BYTE PTR [bx+si],al
     e70:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     e73:	6e                   	outs   dx,BYTE PTR ds:[si]
     e74:	65 6c                	gs ins BYTE PTR es:[di],dx
     e76:	31 32                	xor    WORD PTR [bp+si],si
     e78:	33 44 04             	xor    ax,WORD PTR [si+0x4]
     e7b:	00 00                	add    BYTE PTR [bx+si],al
     e7d:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     e80:	6e                   	outs   dx,BYTE PTR ds:[si]
     e81:	65 6c                	gs ins BYTE PTR es:[di],dx
     e83:	31 32                	xor    WORD PTR [bp+si],si
     e85:	32 48 04             	xor    cl,BYTE PTR [bx+si+0x4]
     e88:	00 00                	add    BYTE PTR [bx+si],al
     e8a:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     e8d:	6e                   	outs   dx,BYTE PTR ds:[si]
     e8e:	65 6c                	gs ins BYTE PTR es:[di],dx
     e90:	31 32                	xor    WORD PTR [bp+si],si
     e92:	34 4c                	xor    al,0x4c
     e94:	04 00                	add    al,0x0
     e96:	00 08                	add    BYTE PTR [bx+si],cl
     e98:	50                   	push   ax
     e99:	61                   	popa
     e9a:	6e                   	outs   dx,BYTE PTR ds:[si]
     e9b:	65 6c                	gs ins BYTE PTR es:[di],dx
     e9d:	31 32                	xor    WORD PTR [bp+si],si
     e9f:	35 50 04             	xor    ax,0x450
     ea2:	00 00                	add    BYTE PTR [bx+si],al
     ea4:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     ea7:	6e                   	outs   dx,BYTE PTR ds:[si]
     ea8:	65 6c                	gs ins BYTE PTR es:[di],dx
     eaa:	31 32                	xor    WORD PTR [bp+si],si
     eac:	36 54                	ss push sp
     eae:	04 00                	add    al,0x0
     eb0:	00 08                	add    BYTE PTR [bx+si],cl
     eb2:	50                   	push   ax
     eb3:	61                   	popa
     eb4:	6e                   	outs   dx,BYTE PTR ds:[si]
     eb5:	65 6c                	gs ins BYTE PTR es:[di],dx
     eb7:	31 32                	xor    WORD PTR [bp+si],si
     eb9:	37                   	aaa
     eba:	58                   	pop    ax
     ebb:	04 00                	add    al,0x0
     ebd:	00 08                	add    BYTE PTR [bx+si],cl
     ebf:	50                   	push   ax
     ec0:	61                   	popa
     ec1:	6e                   	outs   dx,BYTE PTR ds:[si]
     ec2:	65 6c                	gs ins BYTE PTR es:[di],dx
     ec4:	31 32                	xor    WORD PTR [bp+si],si
     ec6:	38 5c 04             	cmp    BYTE PTR [si+0x4],bl
     ec9:	00 00                	add    BYTE PTR [bx+si],al
     ecb:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     ece:	6e                   	outs   dx,BYTE PTR ds:[si]
     ecf:	65 6c                	gs ins BYTE PTR es:[di],dx
     ed1:	31 32                	xor    WORD PTR [bp+si],si
     ed3:	39 60 04             	cmp    WORD PTR [bx+si+0x4],sp
     ed6:	00 00                	add    BYTE PTR [bx+si],al
     ed8:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     edb:	6e                   	outs   dx,BYTE PTR ds:[si]
     edc:	65 6c                	gs ins BYTE PTR es:[di],dx
     ede:	31 33                	xor    WORD PTR [bp+di],si
     ee0:	30 64 04             	xor    BYTE PTR [si+0x4],ah
     ee3:	00 00                	add    BYTE PTR [bx+si],al
     ee5:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     ee8:	6e                   	outs   dx,BYTE PTR ds:[si]
     ee9:	65 6c                	gs ins BYTE PTR es:[di],dx
     eeb:	31 33                	xor    WORD PTR [bp+di],si
     eed:	31 68 04             	xor    WORD PTR [bx+si+0x4],bp
     ef0:	00 00                	add    BYTE PTR [bx+si],al
     ef2:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     ef5:	6e                   	outs   dx,BYTE PTR ds:[si]
     ef6:	65 6c                	gs ins BYTE PTR es:[di],dx
     ef8:	31 33                	xor    WORD PTR [bp+di],si
     efa:	32 6c 04             	xor    ch,BYTE PTR [si+0x4]
     efd:	00 00                	add    BYTE PTR [bx+si],al
     eff:	06                   	push   es
     f00:	50                   	push   ax
     f01:	61                   	popa
     f02:	6e                   	outs   dx,BYTE PTR ds:[si]
     f03:	65 6c                	gs ins BYTE PTR es:[di],dx
     f05:	31 70 04             	xor    WORD PTR [bx+si+0x4],si
     f08:	00 00                	add    BYTE PTR [bx+si],al
     f0a:	06                   	push   es
     f0b:	50                   	push   ax
     f0c:	61                   	popa
     f0d:	6e                   	outs   dx,BYTE PTR ds:[si]
     f0e:	65 6c                	gs ins BYTE PTR es:[di],dx
     f10:	39 74 04             	cmp    WORD PTR [si+0x4],si
     f13:	2c 00                	sub    al,0x0
     f15:	09 44 42             	or     WORD PTR [si+0x42],ax
     f18:	45                   	inc    bp
     f19:	64 69 74 31 30 32    	imul   si,WORD PTR fs:[si+0x31],0x3230
     f1f:	78 04                	js     0xf25
     f21:	2c 00                	sub    al,0x0
     f23:	09 44 42             	or     WORD PTR [si+0x42],ax
     f26:	45                   	inc    bp
     f27:	64 69 74 31 30 33    	imul   si,WORD PTR fs:[si+0x31],0x3330
     f2d:	7c 04                	jl     0xf33
     f2f:	00 00                	add    BYTE PTR [bx+si],al
     f31:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     f34:	6e                   	outs   dx,BYTE PTR ds:[si]
     f35:	65 6c                	gs ins BYTE PTR es:[di],dx
     f37:	31 30                	xor    WORD PTR [bx+si],si
     f39:	31 80 04 00          	xor    WORD PTR [bx+si+0x4],ax
     f3d:	00 08                	add    BYTE PTR [bx+si],cl
     f3f:	50                   	push   ax
     f40:	61                   	popa
     f41:	6e                   	outs   dx,BYTE PTR ds:[si]
     f42:	65 6c                	gs ins BYTE PTR es:[di],dx
     f44:	31 31                	xor    WORD PTR [bx+di],si
     f46:	30 84 04 2c          	xor    BYTE PTR [si+0x2c04],al
     f4a:	00 09                	add    BYTE PTR [bx+di],cl
     f4c:	44                   	inc    sp
     f4d:	42                   	inc    dx
     f4e:	45                   	inc    bp
     f4f:	64 69 74 31 31 31    	imul   si,WORD PTR fs:[si+0x31],0x3131
     f55:	88 04                	mov    BYTE PTR [si],al
     f57:	2c 00                	sub    al,0x0
     f59:	09 44 42             	or     WORD PTR [si+0x42],ax
     f5c:	45                   	inc    bp
     f5d:	64 69 74 31 31 32    	imul   si,WORD PTR fs:[si+0x31],0x3231
     f63:	8c 04                	mov    WORD PTR [si],es
     f65:	2c 00                	sub    al,0x0
     f67:	09 44 42             	or     WORD PTR [si+0x42],ax
     f6a:	45                   	inc    bp
     f6b:	64 69 74 33 30 35    	imul   si,WORD PTR fs:[si+0x33],0x3530
     f71:	90                   	nop
     f72:	04 2c                	add    al,0x2c
     f74:	00 09                	add    BYTE PTR [bx+di],cl
     f76:	44                   	inc    sp
     f77:	42                   	inc    dx
     f78:	45                   	inc    bp
     f79:	64 69 74 33 30 37    	imul   si,WORD PTR fs:[si+0x33],0x3730
     f7f:	94                   	xchg   sp,ax
     f80:	04 2c                	add    al,0x2c
     f82:	00 09                	add    BYTE PTR [bx+di],cl
     f84:	44                   	inc    sp
     f85:	42                   	inc    dx
     f86:	45                   	inc    bp
     f87:	64 69 74 32 31 34    	imul   si,WORD PTR fs:[si+0x32],0x3431
     f8d:	98                   	cbw
     f8e:	04 2c                	add    al,0x2c
     f90:	00 09                	add    BYTE PTR [bx+di],cl
     f92:	44                   	inc    sp
     f93:	42                   	inc    dx
     f94:	45                   	inc    bp
     f95:	64 69 74 32 31 35    	imul   si,WORD PTR fs:[si+0x32],0x3531
     f9b:	9c                   	pushf
     f9c:	04 2c                	add    al,0x2c
     f9e:	00 09                	add    BYTE PTR [bx+di],cl
     fa0:	44                   	inc    sp
     fa1:	42                   	inc    dx
     fa2:	45                   	inc    bp
     fa3:	64 69 74 32 31 36    	imul   si,WORD PTR fs:[si+0x32],0x3631
     fa9:	a0 04 2c             	mov    al,ds:0x2c04
     fac:	00 09                	add    BYTE PTR [bx+di],cl
     fae:	44                   	inc    sp
     faf:	42                   	inc    dx
     fb0:	45                   	inc    bp
     fb1:	64 69 74 32 31 37    	imul   si,WORD PTR fs:[si+0x32],0x3731
     fb7:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     fb8:	04 2c                	add    al,0x2c
     fba:	00 09                	add    BYTE PTR [bx+di],cl
     fbc:	44                   	inc    sp
     fbd:	42                   	inc    dx
     fbe:	45                   	inc    bp
     fbf:	64 69 74 32 31 38    	imul   si,WORD PTR fs:[si+0x32],0x3831
     fc5:	a8 04                	test   al,0x4
     fc7:	2c 00                	sub    al,0x0
     fc9:	09 44 42             	or     WORD PTR [si+0x42],ax
     fcc:	45                   	inc    bp
     fcd:	64 69 74 32 31 39    	imul   si,WORD PTR fs:[si+0x32],0x3931
     fd3:	ac                   	lods   al,BYTE PTR ds:[si]
     fd4:	04 2c                	add    al,0x2c
     fd6:	00 09                	add    BYTE PTR [bx+di],cl
     fd8:	44                   	inc    sp
     fd9:	42                   	inc    dx
     fda:	45                   	inc    bp
     fdb:	64 69 74 32 32 31    	imul   si,WORD PTR fs:[si+0x32],0x3132
     fe1:	b0 04                	mov    al,0x4
     fe3:	2c 00                	sub    al,0x0
     fe5:	09 44 42             	or     WORD PTR [si+0x42],ax
     fe8:	45                   	inc    bp
     fe9:	64 69 74 32 32 32    	imul   si,WORD PTR fs:[si+0x32],0x3232
     fef:	b4 04                	mov    ah,0x4
     ff1:	2c 00                	sub    al,0x0
     ff3:	09 44 42             	or     WORD PTR [si+0x42],ax
     ff6:	45                   	inc    bp
     ff7:	64 69 74 32 32 33    	imul   si,WORD PTR fs:[si+0x32],0x3332
     ffd:	b8 04 2c             	mov    ax,0x2c04
    1000:	00 09                	add    BYTE PTR [bx+di],cl
    1002:	44                   	inc    sp
    1003:	42                   	inc    dx
    1004:	45                   	inc    bp
    1005:	64 69 74 32 32 34    	imul   si,WORD PTR fs:[si+0x32],0x3432
    100b:	bc 04 2c             	mov    sp,0x2c04
    100e:	00 09                	add    BYTE PTR [bx+di],cl
    1010:	44                   	inc    sp
    1011:	42                   	inc    dx
    1012:	45                   	inc    bp
    1013:	64 69 74 32 32 35    	imul   si,WORD PTR fs:[si+0x32],0x3532
    1019:	c0 04 2c             	rol    BYTE PTR [si],0x2c
    101c:	00 09                	add    BYTE PTR [bx+di],cl
    101e:	44                   	inc    sp
    101f:	42                   	inc    dx
    1020:	45                   	inc    bp
    1021:	64 69 74 32 32 37    	imul   si,WORD PTR fs:[si+0x32],0x3732
    1027:	c4 04                	les    ax,DWORD PTR [si]
    1029:	2c 00                	sub    al,0x0
    102b:	09 44 42             	or     WORD PTR [si+0x42],ax
    102e:	45                   	inc    bp
    102f:	64 69 74 32 32 39    	imul   si,WORD PTR fs:[si+0x32],0x3932
    1035:	c8 04 2c 00          	enter  0x2c04,0x0
    1039:	09 44 42             	or     WORD PTR [si+0x42],ax
    103c:	45                   	inc    bp
    103d:	64 69 74 32 33 30    	imul   si,WORD PTR fs:[si+0x32],0x3033
    1043:	cc                   	int3
    1044:	04 2c                	add    al,0x2c
    1046:	00 09                	add    BYTE PTR [bx+di],cl
    1048:	44                   	inc    sp
    1049:	42                   	inc    dx
    104a:	45                   	inc    bp
    104b:	64 69 74 32 33 32    	imul   si,WORD PTR fs:[si+0x32],0x3233
    1051:	d0 04                	rol    BYTE PTR [si],1
    1053:	2c 00                	sub    al,0x0
    1055:	09 44 42             	or     WORD PTR [si+0x42],ax
    1058:	45                   	inc    bp
    1059:	64 69 74 33 32 36    	imul   si,WORD PTR fs:[si+0x33],0x3632
    105f:	d4 04                	aam    0x4
    1061:	2c 00                	sub    al,0x0
    1063:	09 44 42             	or     WORD PTR [si+0x42],ax
    1066:	45                   	inc    bp
    1067:	64 69 74 33 32 38    	imul   si,WORD PTR fs:[si+0x33],0x3832
    106d:	d8 04                	fadd   DWORD PTR [si]
    106f:	2c 00                	sub    al,0x0
    1071:	09 44 42             	or     WORD PTR [si+0x42],ax
    1074:	45                   	inc    bp
    1075:	64 69 74 33 33 31    	imul   si,WORD PTR fs:[si+0x33],0x3133
    107b:	dc 04                	fadd   QWORD PTR [si]
    107d:	30 00                	xor    BYTE PTR [bx+si],al
    107f:	06                   	push   es
    1080:	53                   	push   bx
    1081:	68 61 70             	push   0x7061
    1084:	65 31 e0             	gs xor ax,sp
    1087:	04 30                	add    al,0x30
    1089:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
    108d:	61                   	popa
    108e:	70 65                	jo     0x10f5
    1090:	34 e4                	xor    al,0xe4
    1092:	04 2c                	add    al,0x2c
    1094:	00 09                	add    BYTE PTR [bx+di],cl
    1096:	44                   	inc    sp
    1097:	42                   	inc    dx
    1098:	45                   	inc    bp
    1099:	64 69 74 32 33 34    	imul   si,WORD PTR fs:[si+0x32],0x3433
    109f:	e8 04 2c             	call   0x3ca6
    10a2:	00 09                	add    BYTE PTR [bx+di],cl
    10a4:	44                   	inc    sp
    10a5:	42                   	inc    dx
    10a6:	45                   	inc    bp
    10a7:	64 69 74 33 33 34    	imul   si,WORD PTR fs:[si+0x33],0x3433
    10ad:	ec                   	in     al,dx
    10ae:	04 00                	add    al,0x0
    10b0:	00 08                	add    BYTE PTR [bx+si],cl
    10b2:	50                   	push   ax
    10b3:	61                   	popa
    10b4:	6e                   	outs   dx,BYTE PTR ds:[si]
    10b5:	65 6c                	gs ins BYTE PTR es:[di],dx
    10b7:	31 33                	xor    WORD PTR [bp+di],si
    10b9:	34 f0                	xor    al,0xf0
    10bb:	04 00                	add    al,0x0
    10bd:	00 08                	add    BYTE PTR [bx+si],cl
    10bf:	50                   	push   ax
    10c0:	61                   	popa
    10c1:	6e                   	outs   dx,BYTE PTR ds:[si]
    10c2:	65 6c                	gs ins BYTE PTR es:[di],dx
    10c4:	31 33                	xor    WORD PTR [bp+di],si
    10c6:	36 f4                	ss hlt
    10c8:	04 00                	add    al,0x0
    10ca:	00 07                	add    BYTE PTR [bx],al
    10cc:	50                   	push   ax
    10cd:	61                   	popa
    10ce:	6e                   	outs   dx,BYTE PTR ds:[si]
    10cf:	65 6c                	gs ins BYTE PTR es:[di],dx
    10d1:	31 32                	xor    WORD PTR [bp+si],si
    10d3:	f8                   	clc
    10d4:	04 2c                	add    al,0x2c
    10d6:	00 09                	add    BYTE PTR [bx+di],cl
    10d8:	44                   	inc    sp
    10d9:	42                   	inc    dx
    10da:	45                   	inc    bp
    10db:	64 69 74 33 33 36    	imul   si,WORD PTR fs:[si+0x33],0x3633
    10e1:	fc                   	cld
    10e2:	04 2c                	add    al,0x2c
    10e4:	00 09                	add    BYTE PTR [bx+di],cl
    10e6:	44                   	inc    sp
    10e7:	42                   	inc    dx
    10e8:	45                   	inc    bp
    10e9:	64 69 74 33 33 37    	imul   si,WORD PTR fs:[si+0x33],0x3733
    10ef:	00 05                	add    BYTE PTR [di],al
    10f1:	2c 00                	sub    al,0x0
    10f3:	09 44 42             	or     WORD PTR [si+0x42],ax
    10f6:	45                   	inc    bp
    10f7:	64 69 74 33 33 38    	imul   si,WORD PTR fs:[si+0x33],0x3833
    10fd:	04 05                	add    al,0x5
    10ff:	30 00                	xor    BYTE PTR [bx+si],al
    1101:	06                   	push   es
    1102:	53                   	push   bx
    1103:	68 61 70             	push   0x7061
    1106:	65 36 08 05          	gs or  BYTE PTR ss:[di],al
    110a:	00 00                	add    BYTE PTR [bx+si],al
    110c:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    110f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1110:	65 6c                	gs ins BYTE PTR es:[di],dx
    1112:	31 33                	xor    WORD PTR [bp+di],si
    1114:	37                   	aaa
    1115:	0c 05                	or     al,0x5
    1117:	00 00                	add    BYTE PTR [bx+si],al
    1119:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    111c:	6e                   	outs   dx,BYTE PTR ds:[si]
    111d:	65 6c                	gs ins BYTE PTR es:[di],dx
    111f:	31 33                	xor    WORD PTR [bp+di],si
    1121:	38 10                	cmp    BYTE PTR [bx+si],dl
    1123:	05 0c 00             	add    ax,0xc
    1126:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1129:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    112c:	45                   	inc    bp
    112d:	52                   	push   dx
    112e:	47                   	inc    di
    112f:	56                   	push   si
    1130:	61                   	popa
    1131:	72 43                	jb     0x1176
    1133:	6f                   	outs   dx,WORD PTR ds:[si]
    1134:	6d                   	ins    WORD PTR es:[di],dx
    1135:	70 74                	jo     0x11ab
    1137:	65 73 43             	gs jae 0x117d
    113a:	6c                   	ins    BYTE PTR es:[di],dx
    113b:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    1140:	14 05                	adc    al,0x5
    1142:	0c 00                	or     al,0x0
    1144:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    1147:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    114a:	45                   	inc    bp
    114b:	52                   	push   dx
    114c:	47                   	inc    di
    114d:	52                   	push   dx
    114e:	65 67 6c             	gs ins BYTE PTR es:[edi],dx
    1151:	65 6d                	gs ins WORD PTR es:[di],dx
    1153:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1155:	74 73                	je     0x11ca
    1157:	43                   	inc    bx
    1158:	6c                   	ins    BYTE PTR es:[di],dx
    1159:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    115e:	18 05                	sbb    BYTE PTR [di],al
    1160:	0c 00                	or     al,0x0
    1162:	13 54 61             	adc    dx,WORD PTR [si+0x61]
    1165:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1168:	45                   	inc    bp
    1169:	52                   	push   dx
    116a:	47                   	inc    di
    116b:	53                   	push   bx
    116c:	75 62                	jne    0x11d0
    116e:	76 65                	jbe    0x11d5
    1170:	6e                   	outs   dx,BYTE PTR ds:[si]
    1171:	74 69                	je     0x11dc
    1173:	6f                   	outs   dx,WORD PTR ds:[si]
    1174:	6e                   	outs   dx,BYTE PTR ds:[si]
    1175:	73 1c                	jae    0x1193
    1177:	05 0c 00             	add    ax,0xc
    117a:	16                   	push   ss
    117b:	54                   	push   sp
    117c:	61                   	popa
    117d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1180:	45                   	inc    bp
    1181:	52                   	push   dx
    1182:	47                   	inc    di
    1183:	50                   	push   ax
    1184:	72 6f                	jb     0x11f5
    1186:	64 75 69             	fs jne 0x11f2
    1189:	74 73                	je     0x11fe
    118b:	45                   	inc    bp
    118c:	78 63                	js     0x11f1
    118e:	65 70 74             	gs jo  0x1205
    1191:	20 05                	and    BYTE PTR [di],al
    1193:	0c 00                	or     al,0x0
    1195:	15 54 61             	adc    ax,0x6154
    1198:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    119b:	45                   	inc    bp
    119c:	52                   	push   dx
    119d:	47                   	inc    di
    119e:	43                   	inc    bx
    119f:	68 61 72             	push   0x7261
    11a2:	67 65 73 45          	addr32 gs jae 0x11eb
    11a6:	78 63                	js     0x120b
    11a8:	65 70 74             	gs jo  0x121f
    11ab:	24 05                	and    al,0x5
    11ad:	0c 00                	or     al,0x0
    11af:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    11b2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11b5:	45                   	inc    bp
    11b6:	52                   	push   dx
    11b7:	47                   	inc    di
    11b8:	56                   	push   si
    11b9:	61                   	popa
    11ba:	72 43                	jb     0x11ff
    11bc:	6f                   	outs   dx,WORD PTR ds:[si]
    11bd:	6d                   	ins    WORD PTR es:[di],dx
    11be:	70 74                	jo     0x1234
    11c0:	65 73 46             	gs jae 0x1209
    11c3:	6f                   	outs   dx,WORD PTR ds:[si]
    11c4:	75 72                	jne    0x1238
    11c6:	6e                   	outs   dx,BYTE PTR ds:[si]
    11c7:	69 73 28 05 0c       	imul   si,WORD PTR [bp+di+0x28],0xc05
    11cc:	00 18                	add    BYTE PTR [bx+si],bl
    11ce:	54                   	push   sp
    11cf:	61                   	popa
    11d0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11d3:	45                   	inc    bp
    11d4:	52                   	push   dx
    11d5:	47                   	inc    di
    11d6:	50                   	push   ax
    11d7:	61                   	popa
    11d8:	69 65 6d 65 6e       	imul   sp,WORD PTR [di+0x6d],0x6e65
    11dd:	74 73                	je     0x1252
    11df:	46                   	inc    si
    11e0:	6f                   	outs   dx,WORD PTR ds:[si]
    11e1:	75 72                	jne    0x1255
    11e3:	6e                   	outs   dx,BYTE PTR ds:[si]
    11e4:	69 73 2c 05 0c       	imul   si,WORD PTR [bp+di+0x2c],0xc05
    11e9:	00 1a                	add    BYTE PTR [bp+si],bl
    11eb:	54                   	push   sp
    11ec:	61                   	popa
    11ed:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11f0:	45                   	inc    bp
    11f1:	52                   	push   dx
    11f2:	47                   	inc    di
    11f3:	43                   	inc    bx
    11f4:	68 61 72             	push   0x7261
    11f7:	67 65 73 46          	addr32 gs jae 0x1241
    11fb:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    1200:	69 65 72 65 73       	imul   sp,WORD PTR [di+0x72],0x7365
    1205:	30 05                	xor    BYTE PTR [di],al
    1207:	0c 00                	or     al,0x0
    1209:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
    120c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    120f:	45                   	inc    bp
    1210:	52                   	push   dx
    1211:	47                   	inc    di
    1212:	41                   	inc    cx
    1213:	75 67                	jne    0x127c
    1215:	6d                   	ins    WORD PTR es:[di],dx
    1216:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1218:	74 61                	je     0x127b
    121a:	74 69                	je     0x1285
    121c:	6f                   	outs   dx,WORD PTR ds:[si]
    121d:	6e                   	outs   dx,BYTE PTR ds:[si]
    121e:	43                   	inc    bx
    121f:	61                   	popa
    1220:	70 69                	jo     0x128b
    1222:	74 61                	je     0x1285
    1224:	6c                   	ins    BYTE PTR es:[di],dx
    1225:	34 05                	xor    al,0x5
    1227:	0c 00                	or     al,0x0
    1229:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    122c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    122f:	45                   	inc    bp
    1230:	52                   	push   dx
    1231:	47                   	inc    di
    1232:	52                   	push   dx
    1233:	65 64 75 63          	gs fs jne 0x129a
    1237:	74 69                	je     0x12a2
    1239:	6f                   	outs   dx,WORD PTR ds:[si]
    123a:	6e                   	outs   dx,BYTE PTR ds:[si]
    123b:	43                   	inc    bx
    123c:	61                   	popa
    123d:	70 69                	jo     0x12a8
    123f:	74 61                	je     0x12a2
    1241:	6c                   	ins    BYTE PTR es:[di],dx
    1242:	38 05                	cmp    BYTE PTR [di],al
    1244:	0c 00                	or     al,0x0
    1246:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    1249:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    124c:	45                   	inc    bp
    124d:	52                   	push   dx
    124e:	47                   	inc    di
    124f:	4e                   	dec    si
    1250:	6f                   	outs   dx,WORD PTR ds:[si]
    1251:	75 76                	jne    0x12c9
    1253:	65 61                	gs popa
    1255:	75 78                	jne    0x12cf
    1257:	45                   	inc    bp
    1258:	6d                   	ins    WORD PTR es:[di],dx
    1259:	70 72                	jo     0x12cd
    125b:	75 6e                	jne    0x12cb
    125d:	74 73                	je     0x12d2
    125f:	3c 05                	cmp    al,0x5
    1261:	0c 00                	or     al,0x0
    1263:	1d 54 61             	sbb    ax,0x6154
    1266:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1269:	45                   	inc    bp
    126a:	52                   	push   dx
    126b:	47                   	inc    di
    126c:	52                   	push   dx
    126d:	65 6d                	gs ins WORD PTR es:[di],dx
    126f:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    1272:	72 73                	jb     0x12e7
    1274:	65 6d                	gs ins WORD PTR es:[di],dx
    1276:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1278:	74 45                	je     0x12bf
    127a:	6d                   	ins    WORD PTR es:[di],dx
    127b:	70 72                	jo     0x12ef
    127d:	75 6e                	jne    0x12ed
    127f:	74 73                	je     0x12f4
    1281:	40                   	inc    ax
    1282:	05 0c 00             	add    ax,0xc
    1285:	10 54 61             	adc    BYTE PTR [si+0x61],dl
    1288:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    128b:	45                   	inc    bp
    128c:	52                   	push   dx
    128d:	47                   	inc    di
    128e:	44                   	inc    sp
    128f:	65 70 65             	gs jo  0x12f7
    1292:	6e                   	outs   dx,BYTE PTR ds:[si]
    1293:	73 65                	jae    0x12fa
    1295:	73 44                	jae    0x12db
    1297:	05 0c 00             	add    ax,0xc
    129a:	10 54 61             	adc    BYTE PTR [si+0x61],dl
    129d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    12a0:	45                   	inc    bp
    12a1:	52                   	push   dx
    12a2:	47                   	inc    di
    12a3:	52                   	push   dx
    12a4:	65 63 65 74          	arpl   WORD PTR gs:[di+0x74],sp
    12a8:	74 65                	je     0x130f
    12aa:	73 48                	jae    0x12f4
    12ac:	05 0c 00             	add    ax,0xc
    12af:	1b 54 61             	sbb    dx,WORD PTR [si+0x61]
    12b2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    12b5:	45                   	inc    bp
    12b6:	52                   	push   dx
    12b7:	47                   	inc    di
    12b8:	53                   	push   bx
    12b9:	6f                   	outs   dx,WORD PTR ds:[si]
    12ba:	6c                   	ins    BYTE PTR es:[di],dx
    12bb:	64 65 41             	fs gs inc cx
    12be:	6e                   	outs   dx,BYTE PTR ds:[si]
    12bf:	74 65                	je     0x1326
    12c1:	72 69                	jb     0x132c
    12c3:	65 75 72             	gs jne 0x1338
    12c6:	54                   	push   sp
    12c7:	72 65                	jb     0x132e
    12c9:	73 6f                	jae    0x133a
    12cb:	4c                   	dec    sp
    12cc:	05 0c 00             	add    ax,0xc
    12cf:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    12d2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    12d5:	45                   	inc    bp
    12d6:	52                   	push   dx
    12d7:	47                   	inc    di
    12d8:	53                   	push   bx
    12d9:	69 74 75 61 54       	imul   si,WORD PTR [si+0x75],0x5461
    12de:	72 65                	jb     0x1345
    12e0:	73 6f                	jae    0x1351
    12e2:	72 46                	jb     0x132a
    12e4:	69 6e 50 65 72       	imul   bp,WORD PTR [bp+0x50],0x7265
    12e9:	50                   	push   ax
    12ea:	05 00 00             	add    ax,0x0
    12ed:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    12f0:	6e                   	outs   dx,BYTE PTR ds:[si]
    12f1:	65 6c                	gs ins BYTE PTR es:[di],dx
    12f3:	33 30                	xor    si,WORD PTR [bx+si]
    12f5:	30 54 05             	xor    BYTE PTR [si+0x5],dl
    12f8:	00 00                	add    BYTE PTR [bx+si],al
    12fa:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    12fd:	6e                   	outs   dx,BYTE PTR ds:[si]
    12fe:	65 6c                	gs ins BYTE PTR es:[di],dx
    1300:	31 30                	xor    WORD PTR [bx+si],si
    1302:	30 58 05             	xor    BYTE PTR [bx+si+0x5],bl
    1305:	00 00                	add    BYTE PTR [bx+si],al
    1307:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    130a:	6e                   	outs   dx,BYTE PTR ds:[si]
    130b:	65 6c                	gs ins BYTE PTR es:[di],dx
    130d:	31 30                	xor    WORD PTR [bx+si],si
    130f:	36 5c                	ss pop sp
    1311:	05 00 00             	add    ax,0x0
    1314:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    1317:	6e                   	outs   dx,BYTE PTR ds:[si]
    1318:	65 6c                	gs ins BYTE PTR es:[di],dx
    131a:	31 30                	xor    WORD PTR [bx+si],si
    131c:	38 60 05             	cmp    BYTE PTR [bx+si+0x5],ah
    131f:	2c 00                	sub    al,0x0
    1321:	09 44 42             	or     WORD PTR [si+0x42],ax
    1324:	45                   	inc    bp
    1325:	64 69 74 33 30 36    	imul   si,WORD PTR fs:[si+0x33],0x3630
    132b:	64 05 2c 00          	fs add ax,0x2c
    132f:	09 44 42             	or     WORD PTR [si+0x42],ax
    1332:	45                   	inc    bp
    1333:	64 69 74 33 30 38    	imul   si,WORD PTR fs:[si+0x33],0x3830
    1339:	68 05 00             	push   0x5
    133c:	00 08                	add    BYTE PTR [bx+si],cl
    133e:	50                   	push   ax
    133f:	61                   	popa
    1340:	6e                   	outs   dx,BYTE PTR ds:[si]
    1341:	65 6c                	gs ins BYTE PTR es:[di],dx
    1343:	31 32                	xor    WORD PTR [bp+si],si
    1345:	30 6c 05             	xor    BYTE PTR [si+0x5],ch
    1348:	2c 00                	sub    al,0x0
    134a:	09 44 42             	or     WORD PTR [si+0x42],ax
    134d:	45                   	inc    bp
    134e:	64 69 74 32 32 30    	imul   si,WORD PTR fs:[si+0x32],0x3032
    1354:	70 05                	jo     0x135b
    1356:	0c 00                	or     al,0x0
    1358:	15 54 61             	adc    ax,0x6154
    135b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    135e:	45                   	inc    bp
    135f:	52                   	push   dx
    1360:	47                   	inc    di
    1361:	43                   	inc    bx
    1362:	6f                   	outs   dx,WORD PTR ds:[si]
    1363:	75 74                	jne    0x13d9
    1365:	73 46                	jae    0x13ad
    1367:	69 78 65 73 54       	imul   di,WORD PTR [bx+si+0x65],0x5473
    136c:	54                   	push   sp
    136d:	43                   	inc    bx
    136e:	74 05                	je     0x1375
    1370:	0c 00                	or     al,0x0
    1372:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    1375:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1378:	45                   	inc    bp
    1379:	52                   	push   dx
    137a:	47                   	inc    di
    137b:	41                   	inc    cx
    137c:	75 74                	jne    0x13f2
    137e:	72 65                	jb     0x13e5
    1380:	73 43                	jae    0x13c5
    1382:	68 61 72             	push   0x7261
    1385:	67 65 73 54          	addr32 gs jae 0x13dd
    1389:	54                   	push   sp
    138a:	43                   	inc    bx
    138b:	78 05                	js     0x1392
    138d:	0c 00                	or     al,0x0
    138f:	11 54 61             	adc    WORD PTR [si+0x61],dx
    1392:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1395:	45                   	inc    bp
    1396:	52                   	push   dx
    1397:	47                   	inc    di
    1398:	49                   	dec    cx
    1399:	6d                   	ins    WORD PTR es:[di],dx
    139a:	70 6f                	jo     0x140b
    139c:	74 50                	je     0x13ee
    139e:	72 65                	jb     0x1405
    13a0:	63 0d                	arpl   WORD PTR [di],cx
    13a2:	00 ad 0d d5          	add    BYTE PTR [di-0x2af3],ch
    13a6:	13 38                	adc    di,WORD PTR [bx+si]
    13a8:	01 b1 13 c8          	add    WORD PTR [bx+di-0x37ed],si
    13ac:	08 ea                	or     dl,ch
    13ae:	17                   	pop    ss
    13af:	58                   	pop    ax
    13b0:	0a c1                	or     al,cl
    13b2:	13 ef                	adc    bp,di
    13b4:	02 b9 13 94          	add    bh,BYTE PTR [bx+di-0x6bed]
    13b8:	00 8d 25 7e          	add    BYTE PTR [di+0x7e25],cl
    13bc:	08 82 16 c8          	or     BYTE PTR [bp+si-0x37ea],al
    13c0:	07                   	pop    es
    13c1:	c5 13                	lds    dx,DWORD PTR [bp+di]
    13c3:	67 0c fc             	addr32 or al,0xfc
    13c6:	17                   	pop    ss
    13c7:	17                   	pop    ss
    13c8:	06                   	push   es
    13c9:	cd 13                	int    0x13
    13cb:	91                   	xchg   cx,ax
    13cc:	12 7e 56             	adc    bh,BYTE PTR [bp+0x56]
    13cf:	22 00                	and    al,BYTE PTR [bx+si]
    13d1:	d0 17                	rcl    BYTE PTR [bx],1
    13d3:	7d 00                	jge    0x13d5
    13d5:	04 58                	add    al,0x58
    13d7:	07                   	pop    es
    13d8:	14 54                	adc    al,0x54
    13da:	46                   	inc    si
    13db:	6f                   	outs   dx,WORD PTR ds:[si]
    13dc:	72 6d                	jb     0x144b
    13de:	53                   	push   bx
    13df:	45                   	inc    bp
    13e0:	52                   	push   dx
    13e1:	55                   	push   bp
    13e2:	5f                   	pop    di
    13e3:	54                   	push   sp
    13e4:	72 65                	jb     0x144b
    13e6:	73 6f                	jae    0x1457
    13e8:	72 65                	jb     0x144f
    13ea:	72 69                	jb     0x1455
    13ec:	65 22 00             	and    al,BYTE PTR gs:[bx+si]
    13ef:	2e 14 7b             	cs adc al,0x7b
    13f2:	06                   	push   es
    13f3:	1f                   	pop    ds
    13f4:	14 38                	adc    al,0x38
    13f6:	00 05                	add    BYTE PTR [di],al
    13f8:	53                   	push   bx
    13f9:	65 72 74             	gs jb  0x1470
    13fc:	32 00                	xor    al,BYTE PTR [bx+si]
    13fe:	00 55 89             	add    BYTE PTR [di-0x77],dl
    1401:	e5 31                	in     ax,0x31
    1403:	c0 9a 44 04 39       	rcr    BYTE PTR [bp+si+0x444],0x39
    1408:	14 6a                	adc    al,0x6a
    140a:	00 9a c2 38          	add    BYTE PTR [bp+si+0x38c2],bl
    140e:	17                   	pop    ss
    140f:	16                   	push   ss
    1410:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1413:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
    141a:	06                   	push   es
    141b:	57                   	push   di
    141c:	9a 56 55 47 14       	call   0x1447:0x5556
    1421:	9a c3 28 65 18       	call   0x1865:0x28c3
    1426:	c9                   	leave
    1427:	ca 04 00             	retf   0x4
    142a:	00 00                	add    BYTE PTR [bx+si],al
    142c:	dd 14                	fst    QWORD PTR [si]
    142e:	61                   	popa
    142f:	14 55                	adc    al,0x55
    1431:	89 e5                	mov    bp,sp
    1433:	b8 08 00             	mov    ax,0x8
    1436:	9a 44 04 fb 14       	call   0x14fb:0x444
    143b:	83 ec 08             	sub    sp,0x8
    143e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1442:	06                   	push   es
    1443:	57                   	push   di
    1444:	9a 03 73 68 14       	call   0x1468:0x7303
    1449:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    144d:	7f 03                	jg     0x1452
    144f:	e9 96 00             	jmp    0x14e8
    1452:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1456:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    145a:	b0 01                	mov    al,0x1
    145c:	50                   	push   ax
    145d:	b8 22 00             	mov    ax,0x22
    1460:	ba 9c 14             	mov    dx,0x149c
    1463:	52                   	push   dx
    1464:	50                   	push   ax
    1465:	9a 53 25 c5 14       	call   0x14c5:0x2553
    146a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    146d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1470:	b8 2a 14             	mov    ax,0x142a
    1473:	0e                   	push   cs
    1474:	50                   	push   ax
    1475:	55                   	push   bp
    1476:	ff 36 58 18          	push   WORD PTR ds:0x1858
    147a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    147e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1481:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1484:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1487:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    148a:	26 89 85 80 05       	mov    WORD PTR es:[di+0x580],ax
    148f:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1492:	26 89 85 7e 05       	mov    WORD PTR es:[di+0x57e],ax
    1497:	06                   	push   es
    1498:	57                   	push   di
    1499:	9a 23 21 ab 14       	call   0x14ab:0x2123
    149e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14a1:	26 ff b5 7e 05       	push   WORD PTR es:[di+0x57e]
    14a6:	06                   	push   es
    14a7:	57                   	push   di
    14a8:	9a fe 2b f0 14       	call   0x14f0:0x2bfe
    14ad:	6a ff                	push   0xffff
    14af:	6a f0                	push   0xfff0
    14b1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14b4:	06                   	push   es
    14b5:	57                   	push   di
    14b6:	9a d5 1e a4 15       	call   0x15a4:0x1ed5
    14bb:	6a 02                	push   0x2
    14bd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14c0:	06                   	push   es
    14c1:	57                   	push   di
    14c2:	9a 14 3a cf 14       	call   0x14cf:0x3a14
    14c7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14ca:	06                   	push   es
    14cb:	57                   	push   di
    14cc:	9a 45 5d e5 14       	call   0x14e5:0x5d45
    14d1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    14d5:	83 c4 06             	add    sp,0x6
    14d8:	b8 e8 14             	mov    ax,0x14e8
    14db:	0e                   	push   cs
    14dc:	50                   	push   ax
    14dd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    14e0:	06                   	push   es
    14e1:	57                   	push   di
    14e2:	9a 1d 5f 09 15       	call   0x1509:0x5f1d
    14e7:	cb                   	retf
    14e8:	c9                   	leave
    14e9:	ca 04 00             	retf   0x4
    14ec:	00 00                	add    BYTE PTR [bx+si],al
    14ee:	30 16 4b 15          	xor    BYTE PTR ds:0x154b,dl
    14f2:	55                   	push   bp
    14f3:	89 e5                	mov    bp,sp
    14f5:	b8 0a 00             	mov    ax,0xa
    14f8:	9a 44 04 47 16       	call   0x1647:0x444
    14fd:	83 ec 0a             	sub    sp,0xa
    1500:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1504:	06                   	push   es
    1505:	57                   	push   di
    1506:	9a 03 73 52 15       	call   0x1552:0x7303
    150b:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    150f:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    1513:	7e 1e                	jle    0x1533
    1515:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    1519:	75 14                	jne    0x152f
    151b:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    151f:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    1525:	b0 00                	mov    al,0x0
    1527:	75 01                	jne    0x152a
    1529:	40                   	inc    ax
    152a:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    152d:	eb 04                	jmp    0x1533
    152f:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    1533:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    1537:	75 03                	jne    0x153c
    1539:	e9 ff 00             	jmp    0x163b
    153c:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1540:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1544:	b0 01                	mov    al,0x1
    1546:	50                   	push   ax
    1547:	b8 22 00             	mov    ax,0x22
    154a:	ba 86 15             	mov    dx,0x1586
    154d:	52                   	push   dx
    154e:	50                   	push   ax
    154f:	9a 53 25 b2 15       	call   0x15b2:0x2553
    1554:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1557:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    155a:	b8 ec 14             	mov    ax,0x14ec
    155d:	0e                   	push   cs
    155e:	50                   	push   ax
    155f:	55                   	push   bp
    1560:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1564:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1568:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    156b:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    156e:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1571:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1574:	26 89 85 80 05       	mov    WORD PTR es:[di+0x580],ax
    1579:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    157c:	26 89 85 7e 05       	mov    WORD PTR es:[di+0x57e],ax
    1581:	06                   	push   es
    1582:	57                   	push   di
    1583:	9a 23 21 95 15       	call   0x1595:0x2123
    1588:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    158b:	26 ff b5 7e 05       	push   WORD PTR es:[di+0x57e]
    1590:	06                   	push   es
    1591:	57                   	push   di
    1592:	9a fe 2b ec 15       	call   0x15ec:0x2bfe
    1597:	68 ff 00             	push   0xff
    159a:	6a ff                	push   0xffff
    159c:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    159f:	06                   	push   es
    15a0:	57                   	push   di
    15a1:	9a d5 1e d4 15       	call   0x15d4:0x1ed5
    15a6:	6a 00                	push   0x0
    15a8:	6a 00                	push   0x0
    15aa:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15ad:	06                   	push   es
    15ae:	57                   	push   di
    15af:	9a b2 36 be 15       	call   0x15be:0x36b2
    15b4:	6a 02                	push   0x2
    15b6:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15b9:	06                   	push   es
    15ba:	57                   	push   di
    15bb:	9a 14 3a ca 15       	call   0x15ca:0x3a14
    15c0:	6a 01                	push   0x1
    15c2:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15c5:	06                   	push   es
    15c6:	57                   	push   di
    15c7:	9a e5 34 f9 15       	call   0x15f9:0x34e5
    15cc:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15cf:	06                   	push   es
    15d0:	57                   	push   di
    15d1:	9a b9 62 1f 1c       	call   0x1c1f:0x62b9
    15d6:	50                   	push   ax
    15d7:	6a 04                	push   0x4
    15d9:	9a ff ff 00 00       	call   0x0:0xffff
    15de:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    15e2:	74 0c                	je     0x15f0
    15e4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    15e7:	06                   	push   es
    15e8:	57                   	push   di
    15e9:	9a 29 52 5b 16       	call   0x165b:0x5229
    15ee:	eb 34                	jmp    0x1624
    15f0:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    15f4:	06                   	push   es
    15f5:	57                   	push   di
    15f6:	9a 03 73 22 16       	call   0x1622:0x7303
    15fb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    15fe:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1601:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1604:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    1609:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    160e:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1612:	06                   	push   es
    1613:	57                   	push   di
    1614:	9a 1a 31 bc 16       	call   0x16bc:0x311a
    1619:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    161d:	06                   	push   es
    161e:	57                   	push   di
    161f:	9a 03 73 38 16       	call   0x1638:0x7303
    1624:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1628:	83 c4 06             	add    sp,0x6
    162b:	b8 3b 16             	mov    ax,0x163b
    162e:	0e                   	push   cs
    162f:	50                   	push   ax
    1630:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1633:	06                   	push   es
    1634:	57                   	push   di
    1635:	9a 1d 5f ad 16       	call   0x16ad:0x5f1d
    163a:	cb                   	retf
    163b:	c9                   	leave
    163c:	ca 06 00             	retf   0x6
    163f:	55                   	push   bp
    1640:	89 e5                	mov    bp,sp
    1642:	31 c0                	xor    ax,ax
    1644:	9a 44 04 70 16       	call   0x1670:0x444
    1649:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    164c:	26 ff b5 7e 05       	push   WORD PTR es:[di+0x57e]
    1651:	26 ff b5 80 05       	push   WORD PTR es:[di+0x580]
    1656:	6a 00                	push   0x0
    1658:	9a f2 14 65 16       	call   0x1665:0x14f2
    165d:	c9                   	leave
    165e:	ca 08 00             	retf   0x8
    1661:	00 00                	add    BYTE PTR [bx+si],al
    1663:	22 17                	and    dl,BYTE PTR [bx]
    1665:	f6 16 55 89          	not    BYTE PTR ds:0x8955
    1669:	e5 b8                	in     ax,0xb8
    166b:	08 00                	or     BYTE PTR [bx+si],al
    166d:	9a 44 04 71 17       	call   0x1771:0x444
    1672:	83 ec 08             	sub    sp,0x8
    1675:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1678:	26 c4 bd 20 02       	les    di,DWORD PTR es:[di+0x220]
    167d:	06                   	push   es
    167e:	57                   	push   di
    167f:	9a 17 2f b1 51       	call   0x51b1:0x2f17
    1684:	08 c0                	or     al,al
    1686:	75 03                	jne    0x168b
    1688:	e9 b3 00             	jmp    0x173e
    168b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    168e:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    1693:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    1698:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    169b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    169e:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    16a3:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    16a8:	06                   	push   es
    16a9:	57                   	push   di
    16aa:	9a d0 3f c3 16       	call   0x16c3:0x3fd0
    16af:	ff 76 08             	push   WORD PTR [bp+0x8]
    16b2:	ff 76 06             	push   WORD PTR [bp+0x6]
    16b5:	b0 01                	mov    al,0x1
    16b7:	50                   	push   ax
    16b8:	b8 b4 25             	mov    ax,0x25b4
    16bb:	ba eb 16             	mov    dx,0x16eb
    16be:	52                   	push   dx
    16bf:	50                   	push   ax
    16c0:	9a 53 25 14 17       	call   0x1714:0x2553
    16c5:	a3 04 20             	mov    ds:0x2004,ax
    16c8:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    16cc:	b8 61 16             	mov    ax,0x1661
    16cf:	0e                   	push   cs
    16d0:	50                   	push   ax
    16d1:	55                   	push   bp
    16d2:	ff 36 58 18          	push   WORD PTR ds:0x1858
    16d6:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    16da:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    16de:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    16e1:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    16e4:	6a 01                	push   0x1
    16e6:	06                   	push   es
    16e7:	57                   	push   di
    16e8:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    16ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16f0:	06                   	push   es
    16f1:	57                   	push   di
    16f2:	b8 3f 16             	mov    ax,0x163f
    16f5:	ba 15 21             	mov    dx,0x2115
    16f8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    16fb:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    1700:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    1705:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    170a:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    170f:	06                   	push   es
    1710:	57                   	push   di
    1711:	9a 45 5d 2b 17       	call   0x172b:0x5d45
    1716:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    171a:	83 c4 06             	add    sp,0x6
    171d:	b8 2e 17             	mov    ax,0x172e
    1720:	0e                   	push   cs
    1721:	50                   	push   ax
    1722:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1726:	06                   	push   es
    1727:	57                   	push   di
    1728:	9a 1d 5f 3c 17       	call   0x173c:0x5f1d
    172d:	cb                   	retf
    172e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1731:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1734:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1737:	06                   	push   es
    1738:	57                   	push   di
    1739:	9a d0 3f 8a 17       	call   0x178a:0x3fd0
    173e:	c9                   	leave
    173f:	ca 08 00             	retf   0x8
    1742:	0a 23                	or     ah,BYTE PTR [bp+di]
    1744:	2c 23                	sub    al,0x23
    1746:	23 30                	and    si,WORD PTR [bx+si]
    1748:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    174b:	23 23                	and    sp,WORD PTR [bp+di]
    174d:	07                   	pop    es
    174e:	23 30                	and    si,WORD PTR [bx+si]
    1750:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1753:	23 23                	and    sp,WORD PTR [bp+di]
    1755:	07                   	pop    es
    1756:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    175a:	2b 30                	sub    si,WORD PTR [bx+si]
    175c:	30 01                	xor    BYTE PTR [bx+di],al
    175e:	30 05                	xor    BYTE PTR [di],al
    1760:	23 2c                	and    bp,WORD PTR [si]
    1762:	23 23                	and    sp,WORD PTR [bp+di]
    1764:	30 02                	xor    BYTE PTR [bp+si],al
    1766:	23 30                	and    si,WORD PTR [bx+si]
    1768:	55                   	push   bp
    1769:	89 e5                	mov    bp,sp
    176b:	b8 14 03             	mov    ax,0x314
    176e:	9a 44 04 03 18       	call   0x1803:0x444
    1773:	81 ec 14 03          	sub    sp,0x314
    1777:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    177a:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    177e:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    1782:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1785:	06                   	push   es
    1786:	57                   	push   di
    1787:	9a d5 33 b4 17       	call   0x17b4:0x33d5
    178c:	89 c7                	mov    di,ax
    178e:	8e c2                	mov    es,dx
    1790:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    1794:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    1798:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    179c:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    17a0:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    17a4:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    17a8:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    17ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17af:	06                   	push   es
    17b0:	57                   	push   di
    17b1:	9a d5 33 83 18       	call   0x1883:0x33d5
    17b6:	89 c7                	mov    di,ax
    17b8:	8e c2                	mov    es,dx
    17ba:	06                   	push   es
    17bb:	57                   	push   di
    17bc:	9a 99 20 8e 18       	call   0x188e:0x2099
    17c1:	8d be f4 fc          	lea    di,[bp-0x30c]
    17c5:	16                   	push   ss
    17c6:	57                   	push   di
    17c7:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    17cb:	06                   	push   es
    17cc:	57                   	push   di
    17cd:	9a 9f 1a db 17       	call   0x17db:0x1a9f
    17d2:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    17d6:	06                   	push   es
    17d7:	57                   	push   di
    17d8:	9a 5f 1a ec 1b       	call   0x1bec:0x1a5f
    17dd:	89 c7                	mov    di,ax
    17df:	8e c2                	mov    es,dx
    17e1:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    17e5:	06                   	push   es
    17e6:	57                   	push   di
    17e7:	9a 9b 3b 72 1d       	call   0x1d72:0x3b9b
    17ec:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    17ef:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    17f2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    17f5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    17f8:	bf 58 0a             	mov    di,0xa58
    17fb:	b8 16 18             	mov    ax,0x1816
    17fe:	50                   	push   ax
    17ff:	57                   	push   di
    1800:	9a 55 22 1d 18       	call   0x181d:0x2255
    1805:	08 c0                	or     al,al
    1807:	75 03                	jne    0x180c
    1809:	e9 bb 01             	jmp    0x19c7
    180c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    180f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1812:	bf 58 0a             	mov    di,0xa58
    1815:	b8 c2 19             	mov    ax,0x19c2
    1818:	50                   	push   ax
    1819:	57                   	push   di
    181a:	9a 73 22 3c 18       	call   0x183c:0x2273
    181f:	89 c7                	mov    di,ax
    1821:	8e c2                	mov    es,dx
    1823:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    1827:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    182b:	bf 42 17             	mov    di,0x1742
    182e:	0e                   	push   cs
    182f:	57                   	push   di
    1830:	8d be fc fd          	lea    di,[bp-0x204]
    1834:	16                   	push   ss
    1835:	57                   	push   di
    1836:	68 ff 00             	push   0xff
    1839:	9a e7 17 73 18       	call   0x1873:0x17e7
    183e:	8d be f0 fc          	lea    di,[bp-0x310]
    1842:	16                   	push   ss
    1843:	57                   	push   di
    1844:	8d be fc fd          	lea    di,[bp-0x204]
    1848:	16                   	push   ss
    1849:	57                   	push   di
    184a:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    184e:	06                   	push   es
    184f:	57                   	push   di
    1850:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1853:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1857:	83 ec 0a             	sub    sp,0xa
    185a:	89 e3                	mov    bx,sp
    185c:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1860:	90                   	nop
    1861:	9b                   	fwait
    1862:	9a d4 10 e5 18       	call   0x18e5:0x10d4
    1867:	8d be fc fe          	lea    di,[bp-0x104]
    186b:	16                   	push   ss
    186c:	57                   	push   di
    186d:	68 ff 00             	push   0xff
    1870:	9a e7 17 a2 18       	call   0x18a2:0x17e7
    1875:	8d be fc fe          	lea    di,[bp-0x104]
    1879:	16                   	push   ss
    187a:	57                   	push   di
    187b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    187e:	06                   	push   es
    187f:	57                   	push   di
    1880:	9a d5 33 03 19       	call   0x1903:0x33d5
    1885:	89 c7                	mov    di,ax
    1887:	8e c2                	mov    es,dx
    1889:	06                   	push   es
    188a:	57                   	push   di
    188b:	9a 03 20 0e 19       	call   0x190e:0x2003
    1890:	8b d0                	mov    dx,ax
    1892:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1896:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    189a:	2d 05 00             	sub    ax,0x5
    189d:	71 05                	jno    0x18a4
    189f:	9a 3e 04 bc 18       	call   0x18bc:0x43e
    18a4:	3b c2                	cmp    ax,dx
    18a6:	7e 03                	jle    0x18ab
    18a8:	e9 08 01             	jmp    0x19b3
    18ab:	bf 4d 17             	mov    di,0x174d
    18ae:	0e                   	push   cs
    18af:	57                   	push   di
    18b0:	8d be fc fd          	lea    di,[bp-0x204]
    18b4:	16                   	push   ss
    18b5:	57                   	push   di
    18b6:	68 ff 00             	push   0xff
    18b9:	9a e7 17 f3 18       	call   0x18f3:0x17e7
    18be:	8d be f0 fc          	lea    di,[bp-0x310]
    18c2:	16                   	push   ss
    18c3:	57                   	push   di
    18c4:	8d be fc fd          	lea    di,[bp-0x204]
    18c8:	16                   	push   ss
    18c9:	57                   	push   di
    18ca:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    18ce:	06                   	push   es
    18cf:	57                   	push   di
    18d0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    18d3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    18d7:	83 ec 0a             	sub    sp,0xa
    18da:	89 e3                	mov    bx,sp
    18dc:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    18e0:	90                   	nop
    18e1:	9b                   	fwait
    18e2:	9a d4 10 47 1a       	call   0x1a47:0x10d4
    18e7:	8d be fc fe          	lea    di,[bp-0x104]
    18eb:	16                   	push   ss
    18ec:	57                   	push   di
    18ed:	68 ff 00             	push   0xff
    18f0:	9a e7 17 22 19       	call   0x1922:0x17e7
    18f5:	8d be fc fe          	lea    di,[bp-0x104]
    18f9:	16                   	push   ss
    18fa:	57                   	push   di
    18fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18fe:	06                   	push   es
    18ff:	57                   	push   di
    1900:	9a d5 33 4c 19       	call   0x194c:0x33d5
    1905:	89 c7                	mov    di,ax
    1907:	8e c2                	mov    es,dx
    1909:	06                   	push   es
    190a:	57                   	push   di
    190b:	9a 03 20 57 19       	call   0x1957:0x2003
    1910:	8b d0                	mov    dx,ax
    1912:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1916:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    191a:	2d 05 00             	sub    ax,0x5
    191d:	71 05                	jno    0x1924
    191f:	9a 3e 04 3c 19       	call   0x193c:0x43e
    1924:	3b c2                	cmp    ax,dx
    1926:	7e 03                	jle    0x192b
    1928:	e9 88 00             	jmp    0x19b3
    192b:	bf 55 17             	mov    di,0x1755
    192e:	0e                   	push   cs
    192f:	57                   	push   di
    1930:	8d be fc fd          	lea    di,[bp-0x204]
    1934:	16                   	push   ss
    1935:	57                   	push   di
    1936:	68 ff 00             	push   0xff
    1939:	9a e7 17 6b 19       	call   0x196b:0x17e7
    193e:	8d be fc fd          	lea    di,[bp-0x204]
    1942:	16                   	push   ss
    1943:	57                   	push   di
    1944:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1947:	06                   	push   es
    1948:	57                   	push   di
    1949:	9a d5 33 65 1a       	call   0x1a65:0x33d5
    194e:	89 c7                	mov    di,ax
    1950:	8e c2                	mov    es,dx
    1952:	06                   	push   es
    1953:	57                   	push   di
    1954:	9a 03 20 70 1a       	call   0x1a70:0x2003
    1959:	8b d0                	mov    dx,ax
    195b:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    195f:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1963:	2d 05 00             	sub    ax,0x5
    1966:	71 05                	jno    0x196d
    1968:	9a 3e 04 99 19       	call   0x1999:0x43e
    196d:	3b c2                	cmp    ax,dx
    196f:	b0 00                	mov    al,0x0
    1971:	7e 01                	jle    0x1974
    1973:	40                   	inc    ax
    1974:	8a d0                	mov    dl,al
    1976:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    197b:	b0 00                	mov    al,0x0
    197d:	73 01                	jae    0x1980
    197f:	40                   	inc    ax
    1980:	22 c2                	and    al,dl
    1982:	08 c0                	or     al,al
    1984:	74 17                	je     0x199d
    1986:	bf 5d 17             	mov    di,0x175d
    1989:	0e                   	push   cs
    198a:	57                   	push   di
    198b:	8d be fc fd          	lea    di,[bp-0x204]
    198f:	16                   	push   ss
    1990:	57                   	push   di
    1991:	68 ff 00             	push   0xff
    1994:	6a 03                	push   0x3
    1996:	9a 16 19 b1 19       	call   0x19b1:0x1916
    199b:	eb a1                	jmp    0x193e
    199d:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    19a2:	76 0f                	jbe    0x19b3
    19a4:	8d be fc fd          	lea    di,[bp-0x204]
    19a8:	16                   	push   ss
    19a9:	57                   	push   di
    19aa:	6a 03                	push   0x3
    19ac:	6a 01                	push   0x1
    19ae:	9a 75 19 d8 19       	call   0x19d8:0x1975
    19b3:	8d be fc fd          	lea    di,[bp-0x204]
    19b7:	16                   	push   ss
    19b8:	57                   	push   di
    19b9:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    19bd:	06                   	push   es
    19be:	57                   	push   di
    19bf:	9a f9 60 d1 19       	call   0x19d1:0x60f9
    19c4:	e9 ec 01             	jmp    0x1bb3
    19c7:	ff 76 fe             	push   WORD PTR [bp-0x2]
    19ca:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19cd:	bf c8 07             	mov    di,0x7c8
    19d0:	b8 eb 19             	mov    ax,0x19eb
    19d3:	50                   	push   ax
    19d4:	57                   	push   di
    19d5:	9a 55 22 f2 19       	call   0x19f2:0x2255
    19da:	08 c0                	or     al,al
    19dc:	75 03                	jne    0x19e1
    19de:	e9 d2 01             	jmp    0x1bb3
    19e1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    19e4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19e7:	bf c8 07             	mov    di,0x7c8
    19ea:	b8 b1 1b             	mov    ax,0x1bb1
    19ed:	50                   	push   ax
    19ee:	57                   	push   di
    19ef:	9a 73 22 11 1a       	call   0x1a11:0x2273
    19f4:	89 c7                	mov    di,ax
    19f6:	8e c2                	mov    es,dx
    19f8:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    19fc:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    1a00:	bf 5f 17             	mov    di,0x175f
    1a03:	0e                   	push   cs
    1a04:	57                   	push   di
    1a05:	8d be fc fd          	lea    di,[bp-0x204]
    1a09:	16                   	push   ss
    1a0a:	57                   	push   di
    1a0b:	68 ff 00             	push   0xff
    1a0e:	9a e7 17 55 1a       	call   0x1a55:0x17e7
    1a13:	8d be ec fc          	lea    di,[bp-0x314]
    1a17:	16                   	push   ss
    1a18:	57                   	push   di
    1a19:	8d be fc fd          	lea    di,[bp-0x204]
    1a1d:	16                   	push   ss
    1a1e:	57                   	push   di
    1a1f:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1a23:	06                   	push   es
    1a24:	57                   	push   di
    1a25:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a28:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1a2c:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    1a30:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1a34:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1a39:	83 ec 0a             	sub    sp,0xa
    1a3c:	89 e3                	mov    bx,sp
    1a3e:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1a42:	90                   	nop
    1a43:	9b                   	fwait
    1a44:	9a d4 10 d4 1a       	call   0x1ad4:0x10d4
    1a49:	8d be fc fe          	lea    di,[bp-0x104]
    1a4d:	16                   	push   ss
    1a4e:	57                   	push   di
    1a4f:	68 ff 00             	push   0xff
    1a52:	9a e7 17 84 1a       	call   0x1a84:0x17e7
    1a57:	8d be fc fe          	lea    di,[bp-0x104]
    1a5b:	16                   	push   ss
    1a5c:	57                   	push   di
    1a5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a60:	06                   	push   es
    1a61:	57                   	push   di
    1a62:	9a d5 33 f2 1a       	call   0x1af2:0x33d5
    1a67:	89 c7                	mov    di,ax
    1a69:	8e c2                	mov    es,dx
    1a6b:	06                   	push   es
    1a6c:	57                   	push   di
    1a6d:	9a 03 20 fd 1a       	call   0x1afd:0x2003
    1a72:	8b d0                	mov    dx,ax
    1a74:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1a78:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1a7c:	2d 05 00             	sub    ax,0x5
    1a7f:	71 05                	jno    0x1a86
    1a81:	9a 3e 04 9e 1a       	call   0x1a9e:0x43e
    1a86:	3b c2                	cmp    ax,dx
    1a88:	7e 03                	jle    0x1a8d
    1a8a:	e9 15 01             	jmp    0x1ba2
    1a8d:	bf 65 17             	mov    di,0x1765
    1a90:	0e                   	push   cs
    1a91:	57                   	push   di
    1a92:	8d be fc fd          	lea    di,[bp-0x204]
    1a96:	16                   	push   ss
    1a97:	57                   	push   di
    1a98:	68 ff 00             	push   0xff
    1a9b:	9a e7 17 e2 1a       	call   0x1ae2:0x17e7
    1aa0:	8d be ec fc          	lea    di,[bp-0x314]
    1aa4:	16                   	push   ss
    1aa5:	57                   	push   di
    1aa6:	8d be fc fd          	lea    di,[bp-0x204]
    1aaa:	16                   	push   ss
    1aab:	57                   	push   di
    1aac:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1ab0:	06                   	push   es
    1ab1:	57                   	push   di
    1ab2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ab5:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1ab9:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    1abd:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1ac1:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1ac6:	83 ec 0a             	sub    sp,0xa
    1ac9:	89 e3                	mov    bx,sp
    1acb:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1acf:	90                   	nop
    1ad0:	9b                   	fwait
    1ad1:	9a d4 10 d6 1d       	call   0x1dd6:0x10d4
    1ad6:	8d be fc fe          	lea    di,[bp-0x104]
    1ada:	16                   	push   ss
    1adb:	57                   	push   di
    1adc:	68 ff 00             	push   0xff
    1adf:	9a e7 17 11 1b       	call   0x1b11:0x17e7
    1ae4:	8d be fc fe          	lea    di,[bp-0x104]
    1ae8:	16                   	push   ss
    1ae9:	57                   	push   di
    1aea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aed:	06                   	push   es
    1aee:	57                   	push   di
    1aef:	9a d5 33 3b 1b       	call   0x1b3b:0x33d5
    1af4:	89 c7                	mov    di,ax
    1af6:	8e c2                	mov    es,dx
    1af8:	06                   	push   es
    1af9:	57                   	push   di
    1afa:	9a 03 20 46 1b       	call   0x1b46:0x2003
    1aff:	8b d0                	mov    dx,ax
    1b01:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1b05:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1b09:	2d 05 00             	sub    ax,0x5
    1b0c:	71 05                	jno    0x1b13
    1b0e:	9a 3e 04 2b 1b       	call   0x1b2b:0x43e
    1b13:	3b c2                	cmp    ax,dx
    1b15:	7e 03                	jle    0x1b1a
    1b17:	e9 88 00             	jmp    0x1ba2
    1b1a:	bf 55 17             	mov    di,0x1755
    1b1d:	0e                   	push   cs
    1b1e:	57                   	push   di
    1b1f:	8d be fc fd          	lea    di,[bp-0x204]
    1b23:	16                   	push   ss
    1b24:	57                   	push   di
    1b25:	68 ff 00             	push   0xff
    1b28:	9a e7 17 5a 1b       	call   0x1b5a:0x17e7
    1b2d:	8d be fc fd          	lea    di,[bp-0x204]
    1b31:	16                   	push   ss
    1b32:	57                   	push   di
    1b33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b36:	06                   	push   es
    1b37:	57                   	push   di
    1b38:	9a d5 33 c7 1b       	call   0x1bc7:0x33d5
    1b3d:	89 c7                	mov    di,ax
    1b3f:	8e c2                	mov    es,dx
    1b41:	06                   	push   es
    1b42:	57                   	push   di
    1b43:	9a 03 20 d2 1b       	call   0x1bd2:0x2003
    1b48:	8b d0                	mov    dx,ax
    1b4a:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1b4e:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1b52:	2d 05 00             	sub    ax,0x5
    1b55:	71 05                	jno    0x1b5c
    1b57:	9a 3e 04 88 1b       	call   0x1b88:0x43e
    1b5c:	3b c2                	cmp    ax,dx
    1b5e:	b0 00                	mov    al,0x0
    1b60:	7e 01                	jle    0x1b63
    1b62:	40                   	inc    ax
    1b63:	8a d0                	mov    dl,al
    1b65:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1b6a:	b0 00                	mov    al,0x0
    1b6c:	73 01                	jae    0x1b6f
    1b6e:	40                   	inc    ax
    1b6f:	22 c2                	and    al,dl
    1b71:	08 c0                	or     al,al
    1b73:	74 17                	je     0x1b8c
    1b75:	bf 5d 17             	mov    di,0x175d
    1b78:	0e                   	push   cs
    1b79:	57                   	push   di
    1b7a:	8d be fc fd          	lea    di,[bp-0x204]
    1b7e:	16                   	push   ss
    1b7f:	57                   	push   di
    1b80:	68 ff 00             	push   0xff
    1b83:	6a 03                	push   0x3
    1b85:	9a 16 19 a0 1b       	call   0x1ba0:0x1916
    1b8a:	eb a1                	jmp    0x1b2d
    1b8c:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1b91:	76 0f                	jbe    0x1ba2
    1b93:	8d be fc fd          	lea    di,[bp-0x204]
    1b97:	16                   	push   ss
    1b98:	57                   	push   di
    1b99:	6a 03                	push   0x3
    1b9b:	6a 01                	push   0x1
    1b9d:	9a 75 19 e0 1b       	call   0x1be0:0x1975
    1ba2:	8d be fc fd          	lea    di,[bp-0x204]
    1ba6:	16                   	push   ss
    1ba7:	57                   	push   di
    1ba8:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1bac:	06                   	push   es
    1bad:	57                   	push   di
    1bae:	9a f9 60 84 1d       	call   0x1d84:0x60f9
    1bb3:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1bb7:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1bbb:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1bbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bc2:	06                   	push   es
    1bc3:	57                   	push   di
    1bc4:	9a d5 33 eb 1c       	call   0x1ceb:0x33d5
    1bc9:	89 c7                	mov    di,ax
    1bcb:	8e c2                	mov    es,dx
    1bcd:	06                   	push   es
    1bce:	57                   	push   di
    1bcf:	9a 99 20 4e 1f       	call   0x1f4e:0x2099
    1bd4:	c9                   	leave
    1bd5:	ca 08 00             	retf   0x8
    1bd8:	55                   	push   bp
    1bd9:	89 e5                	mov    bp,sp
    1bdb:	31 c0                	xor    ax,ax
    1bdd:	9a 44 04 f3 1b       	call   0x1bf3:0x444
    1be2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1be5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1be8:	bf a2 0b             	mov    di,0xba2
    1beb:	b8 00 1c             	mov    ax,0x1c00
    1bee:	50                   	push   ax
    1bef:	57                   	push   di
    1bf0:	9a 55 22 07 1c       	call   0x1c07:0x2255
    1bf5:	50                   	push   ax
    1bf6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bf9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1bfc:	bf 22 00             	mov    di,0x22
    1bff:	b8 42 1c             	mov    ax,0x1c42
    1c02:	50                   	push   ax
    1c03:	57                   	push   di
    1c04:	9a 55 22 2d 1c       	call   0x1c2d:0x2255
    1c09:	5a                   	pop    dx
    1c0a:	0a c2                	or     al,dl
    1c0c:	08 c0                	or     al,al
    1c0e:	74 11                	je     0x1c21
    1c10:	6a 00                	push   0x0
    1c12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c15:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1c1a:	06                   	push   es
    1c1b:	57                   	push   di
    1c1c:	9a 77 1c 75 1c       	call   0x1c75:0x1c77
    1c21:	c9                   	leave
    1c22:	ca 08 00             	retf   0x8
    1c25:	55                   	push   bp
    1c26:	89 e5                	mov    bp,sp
    1c28:	31 c0                	xor    ax,ax
    1c2a:	9a 44 04 49 1c       	call   0x1c49:0x444
    1c2f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1c32:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    1c36:	75 3f                	jne    0x1c77
    1c38:	ff 76 12             	push   WORD PTR [bp+0x12]
    1c3b:	ff 76 10             	push   WORD PTR [bp+0x10]
    1c3e:	bf a2 0b             	mov    di,0xba2
    1c41:	b8 56 1c             	mov    ax,0x1c56
    1c44:	50                   	push   ax
    1c45:	57                   	push   di
    1c46:	9a 55 22 5d 1c       	call   0x1c5d:0x2255
    1c4b:	50                   	push   ax
    1c4c:	ff 76 12             	push   WORD PTR [bp+0x12]
    1c4f:	ff 76 10             	push   WORD PTR [bp+0x10]
    1c52:	bf 22 00             	mov    di,0x22
    1c55:	b8 1a 1d             	mov    ax,0x1d1a
    1c58:	50                   	push   ax
    1c59:	57                   	push   di
    1c5a:	9a 55 22 91 1c       	call   0x1c91:0x2255
    1c5f:	5a                   	pop    dx
    1c60:	0a c2                	or     al,dl
    1c62:	08 c0                	or     al,al
    1c64:	74 11                	je     0x1c77
    1c66:	6a 00                	push   0x0
    1c68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c6b:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1c70:	06                   	push   es
    1c71:	57                   	push   di
    1c72:	9a 77 1c aa 1c       	call   0x1caa:0x1c77
    1c77:	c9                   	leave
    1c78:	ca 0e 00             	retf   0xe
    1c7b:	0a 23                	or     ah,BYTE PTR [bp+di]
    1c7d:	2c 23                	sub    al,0x23
    1c7f:	23 30                	and    si,WORD PTR [bx+si]
    1c81:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1c84:	23 23                	and    sp,WORD PTR [bp+di]
    1c86:	01 20                	add    WORD PTR [bx+si],sp
    1c88:	55                   	push   bp
    1c89:	89 e5                	mov    bp,sp
    1c8b:	b8 10 02             	mov    ax,0x210
    1c8e:	9a 44 04 b1 1c       	call   0x1cb1:0x444
    1c93:	81 ec 10 02          	sub    sp,0x210
    1c97:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1c9a:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    1c9e:	75 4d                	jne    0x1ced
    1ca0:	ff 76 12             	push   WORD PTR [bp+0x12]
    1ca3:	ff 76 10             	push   WORD PTR [bp+0x10]
    1ca6:	bf c1 05             	mov    di,0x5c1
    1ca9:	b8 cb 1c             	mov    ax,0x1ccb
    1cac:	50                   	push   ax
    1cad:	57                   	push   di
    1cae:	9a 55 22 d2 1c       	call   0x1cd2:0x2255
    1cb3:	08 c0                	or     al,al
    1cb5:	74 36                	je     0x1ced
    1cb7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1cba:	31 c0                	xor    ax,ax
    1cbc:	26 89 05             	mov    WORD PTR es:[di],ax
    1cbf:	6a 08                	push   0x8
    1cc1:	ff 76 12             	push   WORD PTR [bp+0x12]
    1cc4:	ff 76 10             	push   WORD PTR [bp+0x10]
    1cc7:	bf c1 05             	mov    di,0x5c1
    1cca:	b8 40 1e             	mov    ax,0x1e40
    1ccd:	50                   	push   ax
    1cce:	57                   	push   di
    1ccf:	9a 73 22 21 1d       	call   0x1d21:0x2273
    1cd4:	89 c7                	mov    di,ax
    1cd6:	8e c2                	mov    es,dx
    1cd8:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    1cdd:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    1ce2:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1ce6:	06                   	push   es
    1ce7:	57                   	push   di
    1ce8:	9a b2 77 27 1f       	call   0x1f27:0x77b2
    1ced:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1cf0:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    1cf4:	74 03                	je     0x1cf9
    1cf6:	e9 9e 03             	jmp    0x2097
    1cf9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cfc:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1d01:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    1d06:	74 03                	je     0x1d0b
    1d08:	e9 8c 03             	jmp    0x2097
    1d0b:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    1d10:	ff 76 12             	push   WORD PTR [bp+0x12]
    1d13:	ff 76 10             	push   WORD PTR [bp+0x10]
    1d16:	bf 22 00             	mov    di,0x22
    1d19:	b8 34 1d             	mov    ax,0x1d34
    1d1c:	50                   	push   ax
    1d1d:	57                   	push   di
    1d1e:	9a 55 22 3b 1d       	call   0x1d3b:0x2255
    1d23:	08 c0                	or     al,al
    1d25:	75 03                	jne    0x1d2a
    1d27:	e9 1e 01             	jmp    0x1e48
    1d2a:	ff 76 12             	push   WORD PTR [bp+0x12]
    1d2d:	ff 76 10             	push   WORD PTR [bp+0x10]
    1d30:	bf 22 00             	mov    di,0x22
    1d33:	b8 58 1d             	mov    ax,0x1d58
    1d36:	50                   	push   ax
    1d37:	57                   	push   di
    1d38:	9a 73 22 8b 1d       	call   0x1d8b:0x2273
    1d3d:	89 c7                	mov    di,ax
    1d3f:	8e c2                	mov    es,dx
    1d41:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1d45:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1d49:	8d be f4 fd          	lea    di,[bp-0x20c]
    1d4d:	16                   	push   ss
    1d4e:	57                   	push   di
    1d4f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1d53:	06                   	push   es
    1d54:	57                   	push   di
    1d55:	9a 9f 1a 63 1d       	call   0x1d63:0x1a9f
    1d5a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1d5e:	06                   	push   es
    1d5f:	57                   	push   di
    1d60:	9a 5f 1a 52 1e       	call   0x1e52:0x1a5f
    1d65:	89 c7                	mov    di,ax
    1d67:	8e c2                	mov    es,dx
    1d69:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1d6d:	06                   	push   es
    1d6e:	57                   	push   di
    1d6f:	9a 9b 3b 44 21       	call   0x2144:0x3b9b
    1d74:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1d77:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1d7a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1d7d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1d80:	bf 58 0a             	mov    di,0xa58
    1d83:	b8 9b 1d             	mov    ax,0x1d9b
    1d86:	50                   	push   ax
    1d87:	57                   	push   di
    1d88:	9a 55 22 a2 1d       	call   0x1da2:0x2255
    1d8d:	08 c0                	or     al,al
    1d8f:	74 57                	je     0x1de8
    1d91:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1d94:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1d97:	bf 58 0a             	mov    di,0xa58
    1d9a:	b8 50 21             	mov    ax,0x2150
    1d9d:	50                   	push   ax
    1d9e:	57                   	push   di
    1d9f:	9a 73 22 e4 1d       	call   0x1de4:0x2273
    1da4:	89 c7                	mov    di,ax
    1da6:	8e c2                	mov    es,dx
    1da8:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    1dac:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    1db0:	8d be f0 fd          	lea    di,[bp-0x210]
    1db4:	16                   	push   ss
    1db5:	57                   	push   di
    1db6:	bf 7b 1c             	mov    di,0x1c7b
    1db9:	0e                   	push   cs
    1dba:	57                   	push   di
    1dbb:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    1dbf:	06                   	push   es
    1dc0:	57                   	push   di
    1dc1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1dc4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1dc8:	83 ec 0a             	sub    sp,0xa
    1dcb:	89 e3                	mov    bx,sp
    1dcd:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1dd1:	90                   	nop
    1dd2:	9b                   	fwait
    1dd3:	9a d4 10 2d 24       	call   0x242d:0x10d4
    1dd8:	8d be f8 fe          	lea    di,[bp-0x108]
    1ddc:	16                   	push   ss
    1ddd:	57                   	push   di
    1dde:	68 ff 00             	push   0xff
    1de1:	9a e7 17 05 1e       	call   0x1e05:0x17e7
    1de6:	eb 1f                	jmp    0x1e07
    1de8:	8d be f4 fd          	lea    di,[bp-0x20c]
    1dec:	16                   	push   ss
    1ded:	57                   	push   di
    1dee:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1df2:	06                   	push   es
    1df3:	57                   	push   di
    1df4:	9a 24 15 46 59       	call   0x5946:0x1524
    1df9:	8d be f8 fe          	lea    di,[bp-0x108]
    1dfd:	16                   	push   ss
    1dfe:	57                   	push   di
    1dff:	68 ff 00             	push   0xff
    1e02:	9a e7 17 17 1e       	call   0x1e17:0x17e7
    1e07:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e0b:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1e0f:	2d 04 00             	sub    ax,0x4
    1e12:	71 05                	jno    0x1e19
    1e14:	9a 3e 04 2c 1e       	call   0x1e2c:0x43e
    1e19:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1e1c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e20:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1e24:	2d 04 00             	sub    ax,0x4
    1e27:	71 05                	jno    0x1e2e
    1e29:	9a 3e 04 59 1e       	call   0x1e59:0x43e
    1e2e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e31:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1e34:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1e37:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e3b:	06                   	push   es
    1e3c:	57                   	push   di
    1e3d:	9a d4 19 90 1e       	call   0x1e90:0x19d4
    1e42:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1e45:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1e48:	ff 76 12             	push   WORD PTR [bp+0x12]
    1e4b:	ff 76 10             	push   WORD PTR [bp+0x10]
    1e4e:	bf a2 0b             	mov    di,0xba2
    1e51:	b8 6c 1e             	mov    ax,0x1e6c
    1e54:	50                   	push   ax
    1e55:	57                   	push   di
    1e56:	9a 55 22 73 1e       	call   0x1e73:0x2255
    1e5b:	08 c0                	or     al,al
    1e5d:	75 03                	jne    0x1e62
    1e5f:	e9 7f 00             	jmp    0x1ee1
    1e62:	ff 76 12             	push   WORD PTR [bp+0x12]
    1e65:	ff 76 10             	push   WORD PTR [bp+0x10]
    1e68:	bf a2 0b             	mov    di,0xba2
    1e6b:	b8 e2 20             	mov    ax,0x20e2
    1e6e:	50                   	push   ax
    1e6f:	57                   	push   di
    1e70:	9a 73 22 9e 1e       	call   0x1e9e:0x2273
    1e75:	89 c7                	mov    di,ax
    1e77:	8e c2                	mov    es,dx
    1e79:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1e7d:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1e81:	8d be f4 fd          	lea    di,[bp-0x20c]
    1e85:	16                   	push   ss
    1e86:	57                   	push   di
    1e87:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e8b:	06                   	push   es
    1e8c:	57                   	push   di
    1e8d:	9a 53 1d d9 1e       	call   0x1ed9:0x1d53
    1e92:	8d be f8 fe          	lea    di,[bp-0x108]
    1e96:	16                   	push   ss
    1e97:	57                   	push   di
    1e98:	68 ff 00             	push   0xff
    1e9b:	9a e7 17 b0 1e       	call   0x1eb0:0x17e7
    1ea0:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1ea4:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1ea8:	2d 04 00             	sub    ax,0x4
    1eab:	71 05                	jno    0x1eb2
    1ead:	9a 3e 04 c5 1e       	call   0x1ec5:0x43e
    1eb2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1eb5:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1eb9:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1ebd:	2d 04 00             	sub    ax,0x4
    1ec0:	71 05                	jno    0x1ec7
    1ec2:	9a 3e 04 f9 1e       	call   0x1ef9:0x43e
    1ec7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1eca:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ecd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ed0:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1ed4:	06                   	push   es
    1ed5:	57                   	push   di
    1ed6:	9a d4 19 1d 1f       	call   0x1f1d:0x19d4
    1edb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1ede:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1ee1:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    1ee6:	77 03                	ja     0x1eeb
    1ee8:	e9 ac 01             	jmp    0x2097
    1eeb:	8d be f8 fd          	lea    di,[bp-0x208]
    1eef:	16                   	push   ss
    1ef0:	57                   	push   di
    1ef1:	bf 86 1c             	mov    di,0x1c86
    1ef4:	0e                   	push   cs
    1ef5:	57                   	push   di
    1ef6:	9a cd 17 04 1f       	call   0x1f04:0x17cd
    1efb:	8d be f8 fe          	lea    di,[bp-0x108]
    1eff:	16                   	push   ss
    1f00:	57                   	push   di
    1f01:	9a 4c 18 0e 1f       	call   0x1f0e:0x184c
    1f06:	bf 86 1c             	mov    di,0x1c86
    1f09:	0e                   	push   cs
    1f0a:	57                   	push   di
    1f0b:	9a 4c 18 aa 1f       	call   0x1faa:0x184c
    1f10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f13:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1f18:	06                   	push   es
    1f19:	57                   	push   di
    1f1a:	9a 8c 1d 63 1f       	call   0x1f63:0x1d8c
    1f1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f22:	06                   	push   es
    1f23:	57                   	push   di
    1f24:	9a d5 33 97 2d       	call   0x2d97:0x33d5
    1f29:	89 c7                	mov    di,ax
    1f2b:	8e c2                	mov    es,dx
    1f2d:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1f31:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1f35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f38:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1f3d:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1f41:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1f45:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f49:	06                   	push   es
    1f4a:	57                   	push   di
    1f4b:	9a 99 20 6e 1f       	call   0x1f6e:0x2099
    1f50:	8d be f4 fd          	lea    di,[bp-0x20c]
    1f54:	16                   	push   ss
    1f55:	57                   	push   di
    1f56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f59:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1f5e:	06                   	push   es
    1f5f:	57                   	push   di
    1f60:	9a 53 1d 7e 1f       	call   0x1f7e:0x1d53
    1f65:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f69:	06                   	push   es
    1f6a:	57                   	push   di
    1f6b:	9a 03 20 9e 1f       	call   0x1f9e:0x2003
    1f70:	50                   	push   ax
    1f71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f74:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1f79:	06                   	push   es
    1f7a:	57                   	push   di
    1f7b:	9a bf 17 93 1f       	call   0x1f93:0x17bf
    1f80:	8d be f4 fd          	lea    di,[bp-0x20c]
    1f84:	16                   	push   ss
    1f85:	57                   	push   di
    1f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f89:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1f8e:	06                   	push   es
    1f8f:	57                   	push   di
    1f90:	9a 53 1d c0 1f       	call   0x1fc0:0x1d53
    1f95:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f99:	06                   	push   es
    1f9a:	57                   	push   di
    1f9b:	9a 4e 20 ef 51       	call   0x51ef:0x204e
    1fa0:	b9 03 00             	mov    cx,0x3
    1fa3:	f7 e9                	imul   cx
    1fa5:	71 05                	jno    0x1fac
    1fa7:	9a 3e 04 1d 20       	call   0x201d:0x43e
    1fac:	99                   	cwd
    1fad:	b9 02 00             	mov    cx,0x2
    1fb0:	f7 f9                	idiv   cx
    1fb2:	50                   	push   ax
    1fb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb6:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1fbb:	06                   	push   es
    1fbc:	57                   	push   di
    1fbd:	9a e1 17 d0 1f       	call   0x1fd0:0x17e1
    1fc2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fc5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1fc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fcb:	06                   	push   es
    1fcc:	57                   	push   di
    1fcd:	9a 06 1a f0 1f       	call   0x1ff0:0x1a06
    1fd2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1fd5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1fd8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fdb:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1fe0:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1fe4:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1fe8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1feb:	06                   	push   es
    1fec:	57                   	push   di
    1fed:	9a 7b 17 fe 1f       	call   0x1ffe:0x177b
    1ff2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ff5:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1ff9:	06                   	push   es
    1ffa:	57                   	push   di
    1ffb:	9a 9d 17 08 20       	call   0x2008:0x179d
    2000:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2003:	06                   	push   es
    2004:	57                   	push   di
    2005:	9a a9 18 3f 20       	call   0x203f:0x18a9
    200a:	8b d0                	mov    dx,ax
    200c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2010:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2014:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    2018:	71 05                	jno    0x201f
    201a:	9a 3e 04 33 20       	call   0x2033:0x43e
    201f:	3b c2                	cmp    ax,dx
    2021:	7e 20                	jle    0x2043
    2023:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2027:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    202b:	2d 08 00             	sub    ax,0x8
    202e:	71 05                	jno    0x2035
    2030:	9a 3e 04 60 20       	call   0x2060:0x43e
    2035:	50                   	push   ax
    2036:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    203a:	06                   	push   es
    203b:	57                   	push   di
    203c:	9a 7b 17 4b 20       	call   0x204b:0x177b
    2041:	eb bd                	jmp    0x2000
    2043:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2046:	06                   	push   es
    2047:	57                   	push   di
    2048:	9a f4 18 82 20       	call   0x2082:0x18f4
    204d:	8b d0                	mov    dx,ax
    204f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2053:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2057:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    205b:	71 05                	jno    0x2062
    205d:	9a 3e 04 76 20       	call   0x2076:0x43e
    2062:	3b c2                	cmp    ax,dx
    2064:	7e 20                	jle    0x2086
    2066:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    206a:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    206e:	2d 08 00             	sub    ax,0x8
    2071:	71 05                	jno    0x2078
    2073:	9a 3e 04 a4 20       	call   0x20a4:0x43e
    2078:	50                   	push   ax
    2079:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    207d:	06                   	push   es
    207e:	57                   	push   di
    207f:	9a 9d 17 95 20       	call   0x2095:0x179d
    2084:	eb bd                	jmp    0x2043
    2086:	6a 01                	push   0x1
    2088:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    208b:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    2090:	06                   	push   es
    2091:	57                   	push   di
    2092:	9a 77 1c 3c 24       	call   0x243c:0x1c77
    2097:	c9                   	leave
    2098:	ca 0e 00             	retf   0xe
    209b:	55                   	push   bp
    209c:	89 e5                	mov    bp,sp
    209e:	b8 04 00             	mov    ax,0x4
    20a1:	9a 44 04 bb 20       	call   0x20bb:0x444
    20a6:	83 ec 04             	sub    sp,0x4
    20a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20ac:	06                   	push   es
    20ad:	57                   	push   di
    20ae:	9a 7d 52 da 20       	call   0x20da:0x527d
    20b3:	2d 01 00             	sub    ax,0x1
    20b6:	71 05                	jno    0x20bd
    20b8:	9a 3e 04 e9 20       	call   0x20e9:0x43e
    20bd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    20c0:	31 c0                	xor    ax,ax
    20c2:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    20c5:	7f 58                	jg     0x211f
    20c7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    20ca:	eb 03                	jmp    0x20cf
    20cc:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    20cf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20d5:	06                   	push   es
    20d6:	57                   	push   di
    20d7:	9a 46 52 fa 20       	call   0x20fa:0x5246
    20dc:	52                   	push   dx
    20dd:	50                   	push   ax
    20de:	bf 22 00             	mov    di,0x22
    20e1:	b8 02 21             	mov    ax,0x2102
    20e4:	50                   	push   ax
    20e5:	57                   	push   di
    20e6:	9a 55 22 09 21       	call   0x2109:0x2255
    20eb:	08 c0                	or     al,al
    20ed:	74 28                	je     0x2117
    20ef:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20f5:	06                   	push   es
    20f6:	57                   	push   di
    20f7:	9a 46 52 b2 2d       	call   0x2db2:0x5246
    20fc:	52                   	push   dx
    20fd:	50                   	push   ax
    20fe:	bf 22 00             	mov    di,0x22
    2101:	b8 08 59             	mov    ax,0x5908
    2104:	50                   	push   ax
    2105:	57                   	push   di
    2106:	9a 73 22 2c 21       	call   0x212c:0x2273
    210b:	52                   	push   dx
    210c:	50                   	push   ax
    210d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2110:	06                   	push   es
    2111:	57                   	push   di
    2112:	9a 68 17 6f 26       	call   0x266f:0x1768
    2117:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    211a:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    211d:	75 ad                	jne    0x20cc
    211f:	c9                   	leave
    2120:	ca 04 00             	retf   0x4
    2123:	55                   	push   bp
    2124:	89 e5                	mov    bp,sp
    2126:	b8 04 00             	mov    ax,0x4
    2129:	9a 44 04 13 24       	call   0x2413:0x444
    212e:	83 ec 04             	sub    sp,0x4
    2131:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2134:	26 c4 bd 24 02       	les    di,DWORD PTR es:[di+0x224]
    2139:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    213c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    213f:	06                   	push   es
    2140:	57                   	push   di
    2141:	9a d2 31 66 21       	call   0x2166:0x31d2
    2146:	6a 01                	push   0x1
    2148:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    214b:	06                   	push   es
    214c:	57                   	push   di
    214d:	9a fb 2f 5c 21       	call   0x215c:0x2ffb
    2152:	6a 00                	push   0x0
    2154:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2157:	06                   	push   es
    2158:	57                   	push   di
    2159:	9a d2 2e 87 21       	call   0x2187:0x2ed2
    215e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2161:	06                   	push   es
    2162:	57                   	push   di
    2163:	9a bf 31 7b 21       	call   0x217b:0x31bf
    2168:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    216b:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2170:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2173:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2176:	06                   	push   es
    2177:	57                   	push   di
    2178:	9a d2 31 9d 21       	call   0x219d:0x31d2
    217d:	6a 01                	push   0x1
    217f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2182:	06                   	push   es
    2183:	57                   	push   di
    2184:	9a fb 2f 93 21       	call   0x2193:0x2ffb
    2189:	6a 00                	push   0x0
    218b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    218e:	06                   	push   es
    218f:	57                   	push   di
    2190:	9a d2 2e be 21       	call   0x21be:0x2ed2
    2195:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2198:	06                   	push   es
    2199:	57                   	push   di
    219a:	9a bf 31 b2 21       	call   0x21b2:0x31bf
    219f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21a2:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    21a7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    21aa:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    21ad:	06                   	push   es
    21ae:	57                   	push   di
    21af:	9a d2 31 d4 21       	call   0x21d4:0x31d2
    21b4:	6a 01                	push   0x1
    21b6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21b9:	06                   	push   es
    21ba:	57                   	push   di
    21bb:	9a fb 2f ca 21       	call   0x21ca:0x2ffb
    21c0:	6a 00                	push   0x0
    21c2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21c5:	06                   	push   es
    21c6:	57                   	push   di
    21c7:	9a d2 2e f5 21       	call   0x21f5:0x2ed2
    21cc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21cf:	06                   	push   es
    21d0:	57                   	push   di
    21d1:	9a bf 31 e9 21       	call   0x21e9:0x31bf
    21d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21d9:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    21de:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    21e1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    21e4:	06                   	push   es
    21e5:	57                   	push   di
    21e6:	9a d2 31 0b 22       	call   0x220b:0x31d2
    21eb:	6a 01                	push   0x1
    21ed:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21f0:	06                   	push   es
    21f1:	57                   	push   di
    21f2:	9a fb 2f 01 22       	call   0x2201:0x2ffb
    21f7:	6a 00                	push   0x0
    21f9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21fc:	06                   	push   es
    21fd:	57                   	push   di
    21fe:	9a d2 2e 2c 22       	call   0x222c:0x2ed2
    2203:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2206:	06                   	push   es
    2207:	57                   	push   di
    2208:	9a bf 31 20 22       	call   0x2220:0x31bf
    220d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2210:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    2215:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2218:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    221b:	06                   	push   es
    221c:	57                   	push   di
    221d:	9a d2 31 42 22       	call   0x2242:0x31d2
    2222:	6a 01                	push   0x1
    2224:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2227:	06                   	push   es
    2228:	57                   	push   di
    2229:	9a fb 2f 38 22       	call   0x2238:0x2ffb
    222e:	6a 00                	push   0x0
    2230:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2233:	06                   	push   es
    2234:	57                   	push   di
    2235:	9a d2 2e 63 22       	call   0x2263:0x2ed2
    223a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    223d:	06                   	push   es
    223e:	57                   	push   di
    223f:	9a bf 31 57 22       	call   0x2257:0x31bf
    2244:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2247:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    224c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    224f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2252:	06                   	push   es
    2253:	57                   	push   di
    2254:	9a d2 31 79 22       	call   0x2279:0x31d2
    2259:	6a 01                	push   0x1
    225b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    225e:	06                   	push   es
    225f:	57                   	push   di
    2260:	9a fb 2f 6f 22       	call   0x226f:0x2ffb
    2265:	6a 00                	push   0x0
    2267:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    226a:	06                   	push   es
    226b:	57                   	push   di
    226c:	9a d2 2e 9a 22       	call   0x229a:0x2ed2
    2271:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2274:	06                   	push   es
    2275:	57                   	push   di
    2276:	9a bf 31 8e 22       	call   0x228e:0x31bf
    227b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    227e:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    2283:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2286:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2289:	06                   	push   es
    228a:	57                   	push   di
    228b:	9a d2 31 b0 22       	call   0x22b0:0x31d2
    2290:	6a 01                	push   0x1
    2292:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2295:	06                   	push   es
    2296:	57                   	push   di
    2297:	9a fb 2f a6 22       	call   0x22a6:0x2ffb
    229c:	6a 00                	push   0x0
    229e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22a1:	06                   	push   es
    22a2:	57                   	push   di
    22a3:	9a d2 2e d1 22       	call   0x22d1:0x2ed2
    22a8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22ab:	06                   	push   es
    22ac:	57                   	push   di
    22ad:	9a bf 31 c5 22       	call   0x22c5:0x31bf
    22b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22b5:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    22ba:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    22bd:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    22c0:	06                   	push   es
    22c1:	57                   	push   di
    22c2:	9a d2 31 e7 22       	call   0x22e7:0x31d2
    22c7:	6a 01                	push   0x1
    22c9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22cc:	06                   	push   es
    22cd:	57                   	push   di
    22ce:	9a fb 2f dd 22       	call   0x22dd:0x2ffb
    22d3:	6a 00                	push   0x0
    22d5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22d8:	06                   	push   es
    22d9:	57                   	push   di
    22da:	9a d2 2e 08 23       	call   0x2308:0x2ed2
    22df:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22e2:	06                   	push   es
    22e3:	57                   	push   di
    22e4:	9a bf 31 fc 22       	call   0x22fc:0x31bf
    22e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ec:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    22f1:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    22f4:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    22f7:	06                   	push   es
    22f8:	57                   	push   di
    22f9:	9a d2 31 1e 23       	call   0x231e:0x31d2
    22fe:	6a 01                	push   0x1
    2300:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2303:	06                   	push   es
    2304:	57                   	push   di
    2305:	9a fb 2f 14 23       	call   0x2314:0x2ffb
    230a:	6a 00                	push   0x0
    230c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    230f:	06                   	push   es
    2310:	57                   	push   di
    2311:	9a d2 2e 3f 23       	call   0x233f:0x2ed2
    2316:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2319:	06                   	push   es
    231a:	57                   	push   di
    231b:	9a bf 31 33 23       	call   0x2333:0x31bf
    2320:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2323:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    2328:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    232b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    232e:	06                   	push   es
    232f:	57                   	push   di
    2330:	9a d2 31 55 23       	call   0x2355:0x31d2
    2335:	6a 01                	push   0x1
    2337:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    233a:	06                   	push   es
    233b:	57                   	push   di
    233c:	9a fb 2f 4b 23       	call   0x234b:0x2ffb
    2341:	6a 00                	push   0x0
    2343:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2346:	06                   	push   es
    2347:	57                   	push   di
    2348:	9a d2 2e 76 23       	call   0x2376:0x2ed2
    234d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2350:	06                   	push   es
    2351:	57                   	push   di
    2352:	9a bf 31 6a 23       	call   0x236a:0x31bf
    2357:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    235a:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    235f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2362:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2365:	06                   	push   es
    2366:	57                   	push   di
    2367:	9a d2 31 8c 23       	call   0x238c:0x31d2
    236c:	6a 01                	push   0x1
    236e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2371:	06                   	push   es
    2372:	57                   	push   di
    2373:	9a fb 2f 82 23       	call   0x2382:0x2ffb
    2378:	6a 00                	push   0x0
    237a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    237d:	06                   	push   es
    237e:	57                   	push   di
    237f:	9a d2 2e ad 23       	call   0x23ad:0x2ed2
    2384:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2387:	06                   	push   es
    2388:	57                   	push   di
    2389:	9a bf 31 a1 23       	call   0x23a1:0x31bf
    238e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2391:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2396:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2399:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    239c:	06                   	push   es
    239d:	57                   	push   di
    239e:	9a d2 31 c3 23       	call   0x23c3:0x31d2
    23a3:	6a 01                	push   0x1
    23a5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23a8:	06                   	push   es
    23a9:	57                   	push   di
    23aa:	9a fb 2f b9 23       	call   0x23b9:0x2ffb
    23af:	6a 00                	push   0x0
    23b1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23b4:	06                   	push   es
    23b5:	57                   	push   di
    23b6:	9a d2 2e e4 23       	call   0x23e4:0x2ed2
    23bb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23be:	06                   	push   es
    23bf:	57                   	push   di
    23c0:	9a bf 31 d8 23       	call   0x23d8:0x31bf
    23c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c8:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    23cd:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    23d0:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    23d3:	06                   	push   es
    23d4:	57                   	push   di
    23d5:	9a d2 31 fa 23       	call   0x23fa:0x31d2
    23da:	6a 01                	push   0x1
    23dc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23df:	06                   	push   es
    23e0:	57                   	push   di
    23e1:	9a fb 2f f0 23       	call   0x23f0:0x2ffb
    23e6:	6a 00                	push   0x0
    23e8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23eb:	06                   	push   es
    23ec:	57                   	push   di
    23ed:	9a d2 2e 61 26       	call   0x2661:0x2ed2
    23f2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23f5:	06                   	push   es
    23f6:	57                   	push   di
    23f7:	9a bf 31 44 2b       	call   0x2b44:0x31bf
    23fc:	c9                   	leave
    23fd:	ca 04 00             	retf   0x4
    2400:	01 23                	add    WORD PTR [bp+di],sp
    2402:	00 00                	add    BYTE PTR [bx+si],al
    2404:	00 00                	add    BYTE PTR [bx+si],al
    2406:	ff 00                	inc    WORD PTR [bx+si]
    2408:	00 00                	add    BYTE PTR [bx+si],al
    240a:	55                   	push   bp
    240b:	89 e5                	mov    bp,sp
    240d:	b8 02 02             	mov    ax,0x202
    2410:	9a 44 04 78 24       	call   0x2478:0x444
    2415:	81 ec 02 02          	sub    sp,0x202
    2419:	8d be fe fd          	lea    di,[bp-0x202]
    241d:	16                   	push   ss
    241e:	57                   	push   di
    241f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2422:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    2427:	99                   	cwd
    2428:	52                   	push   dx
    2429:	50                   	push   ax
    242a:	9a a9 08 52 24       	call   0x2452:0x8a9
    242f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2432:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    2437:	06                   	push   es
    2438:	57                   	push   di
    2439:	9a 8c 1d 61 24       	call   0x2461:0x1d8c
    243e:	8d be fe fd          	lea    di,[bp-0x202]
    2442:	16                   	push   ss
    2443:	57                   	push   di
    2444:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2447:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    244c:	99                   	cwd
    244d:	52                   	push   dx
    244e:	50                   	push   ax
    244f:	9a a9 08 c3 24       	call   0x24c3:0x8a9
    2454:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2457:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    245c:	06                   	push   es
    245d:	57                   	push   di
    245e:	9a 8c 1d 46 25       	call   0x2546:0x1d8c
    2463:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2466:	81 c7 82 05          	add    di,0x582
    246a:	06                   	push   es
    246b:	57                   	push   di
    246c:	8d be fe fe          	lea    di,[bp-0x102]
    2470:	16                   	push   ss
    2471:	57                   	push   di
    2472:	68 ff 00             	push   0xff
    2475:	9a e7 17 88 24       	call   0x2488:0x17e7
    247a:	bf 00 24             	mov    di,0x2400
    247d:	0e                   	push   cs
    247e:	57                   	push   di
    247f:	8d be fe fe          	lea    di,[bp-0x102]
    2483:	16                   	push   ss
    2484:	57                   	push   di
    2485:	9a 78 18 91 24       	call   0x2491:0x1878
    248a:	99                   	cwd
    248b:	bf 02 24             	mov    di,0x2402
    248e:	9a 16 04 ad 24       	call   0x24ad:0x416
    2493:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2496:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    249a:	76 3d                	jbe    0x24d9
    249c:	8d be fe fe          	lea    di,[bp-0x102]
    24a0:	16                   	push   ss
    24a1:	57                   	push   di
    24a2:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    24a5:	30 e4                	xor    ah,ah
    24a7:	50                   	push   ax
    24a8:	6a 01                	push   0x1
    24aa:	9a 75 19 d7 24       	call   0x24d7:0x1975
    24af:	8d be fe fd          	lea    di,[bp-0x202]
    24b3:	16                   	push   ss
    24b4:	57                   	push   di
    24b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24b8:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    24bd:	99                   	cwd
    24be:	52                   	push   dx
    24bf:	50                   	push   ax
    24c0:	9a a9 08 22 25       	call   0x2522:0x8a9
    24c5:	8d be fe fe          	lea    di,[bp-0x102]
    24c9:	16                   	push   ss
    24ca:	57                   	push   di
    24cb:	68 ff 00             	push   0xff
    24ce:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    24d1:	30 e4                	xor    ah,ah
    24d3:	50                   	push   ax
    24d4:	9a 16 19 e7 24       	call   0x24e7:0x1916
    24d9:	bf 00 24             	mov    di,0x2400
    24dc:	0e                   	push   cs
    24dd:	57                   	push   di
    24de:	8d be fe fe          	lea    di,[bp-0x102]
    24e2:	16                   	push   ss
    24e3:	57                   	push   di
    24e4:	9a 78 18 f0 24       	call   0x24f0:0x1878
    24e9:	99                   	cwd
    24ea:	bf 02 24             	mov    di,0x2402
    24ed:	9a 16 04 0c 25       	call   0x250c:0x416
    24f2:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    24f5:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    24f9:	76 3d                	jbe    0x2538
    24fb:	8d be fe fe          	lea    di,[bp-0x102]
    24ff:	16                   	push   ss
    2500:	57                   	push   di
    2501:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2504:	30 e4                	xor    ah,ah
    2506:	50                   	push   ax
    2507:	6a 01                	push   0x1
    2509:	9a 75 19 36 25       	call   0x2536:0x1975
    250e:	8d be fe fd          	lea    di,[bp-0x202]
    2512:	16                   	push   ss
    2513:	57                   	push   di
    2514:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2517:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    251c:	99                   	cwd
    251d:	52                   	push   dx
    251e:	50                   	push   ax
    251f:	9a a9 08 0a 2f       	call   0x2f0a:0x8a9
    2524:	8d be fe fe          	lea    di,[bp-0x102]
    2528:	16                   	push   ss
    2529:	57                   	push   di
    252a:	68 ff 00             	push   0xff
    252d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2530:	30 e4                	xor    ah,ah
    2532:	50                   	push   ax
    2533:	9a 16 19 6e 25       	call   0x256e:0x1916
    2538:	8d be fe fe          	lea    di,[bp-0x102]
    253c:	16                   	push   ss
    253d:	57                   	push   di
    253e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2541:	06                   	push   es
    2542:	57                   	push   di
    2543:	9a 8c 1d 8f 2c       	call   0x2c8f:0x1d8c
    2548:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    254b:	26 c4 bd 90 03       	les    di,DWORD PTR es:[di+0x390]
    2550:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2554:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2558:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    255c:	eb 03                	jmp    0x2561
    255e:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    2561:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2564:	30 e4                	xor    ah,ah
    2566:	05 01 00             	add    ax,0x1
    2569:	71 05                	jno    0x2570
    256b:	9a 3e 04 bf 25       	call   0x25bf:0x43e
    2570:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2573:	26 3b 85 7e 05       	cmp    ax,WORD PTR es:[di+0x57e]
    2578:	b0 00                	mov    al,0x0
    257a:	75 01                	jne    0x257d
    257c:	40                   	inc    ax
    257d:	50                   	push   ax
    257e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2581:	30 e4                	xor    ah,ah
    2583:	50                   	push   ax
    2584:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2588:	06                   	push   es
    2589:	57                   	push   di
    258a:	9a 53 13 98 25       	call   0x2598:0x1353
    258f:	89 c7                	mov    di,ax
    2591:	8e c2                	mov    es,dx
    2593:	06                   	push   es
    2594:	57                   	push   di
    2595:	9a 75 12 b5 25       	call   0x25b5:0x1275
    259a:	80 7e ff 13          	cmp    BYTE PTR [bp-0x1],0x13
    259e:	75 be                	jne    0x255e
    25a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25a3:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    25a8:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    25ac:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    25b0:	06                   	push   es
    25b1:	57                   	push   di
    25b2:	9a 26 13 0a 26       	call   0x260a:0x1326
    25b7:	2d 01 00             	sub    ax,0x1
    25ba:	71 05                	jno    0x25c1
    25bc:	9a 3e 04 c8 25       	call   0x25c8:0x43e
    25c1:	99                   	cwd
    25c2:	bf 02 24             	mov    di,0x2402
    25c5:	9a 16 04 eb 25       	call   0x25eb:0x416
    25ca:	88 86 f9 fe          	mov    BYTE PTR [bp-0x107],al
    25ce:	b0 00                	mov    al,0x0
    25d0:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    25d4:	77 4a                	ja     0x2620
    25d6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    25d9:	eb 03                	jmp    0x25de
    25db:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    25de:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    25e1:	30 e4                	xor    ah,ah
    25e3:	05 01 00             	add    ax,0x1
    25e6:	71 05                	jno    0x25ed
    25e8:	9a 3e 04 40 26       	call   0x2640:0x43e
    25ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f0:	26 3b 85 80 05       	cmp    ax,WORD PTR es:[di+0x580]
    25f5:	b0 00                	mov    al,0x0
    25f7:	75 01                	jne    0x25fa
    25f9:	40                   	inc    ax
    25fa:	50                   	push   ax
    25fb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    25fe:	30 e4                	xor    ah,ah
    2600:	50                   	push   ax
    2601:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2605:	06                   	push   es
    2606:	57                   	push   di
    2607:	9a 53 13 15 26       	call   0x2615:0x1353
    260c:	89 c7                	mov    di,ax
    260e:	8e c2                	mov    es,dx
    2610:	06                   	push   es
    2611:	57                   	push   di
    2612:	9a 75 12 e7 2c       	call   0x2ce7:0x1275
    2617:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    261a:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    261e:	75 bb                	jne    0x25db
    2620:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2623:	26 c4 bd 24 02       	les    di,DWORD PTR es:[di+0x224]
    2628:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    262c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2630:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2633:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    2638:	2d 01 00             	sub    ax,0x1
    263b:	71 05                	jno    0x2642
    263d:	9a 3e 04 88 27       	call   0x2788:0x43e
    2642:	99                   	cwd
    2643:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2647:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    264b:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2650:	8d be f2 fe          	lea    di,[bp-0x10e]
    2654:	16                   	push   ss
    2655:	57                   	push   di
    2656:	6a 00                	push   0x0
    2658:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    265c:	06                   	push   es
    265d:	57                   	push   di
    265e:	9a 95 28 a8 26       	call   0x26a8:0x2895
    2663:	08 c0                	or     al,al
    2665:	75 0a                	jne    0x2671
    2667:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    266a:	06                   	push   es
    266b:	57                   	push   di
    266c:	9a ff 13 b6 26       	call   0x26b6:0x13ff
    2671:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2674:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2679:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    267d:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2681:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2684:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    2689:	99                   	cwd
    268a:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    268e:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    2692:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2697:	8d be f2 fe          	lea    di,[bp-0x10e]
    269b:	16                   	push   ss
    269c:	57                   	push   di
    269d:	6a 00                	push   0x0
    269f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    26a3:	06                   	push   es
    26a4:	57                   	push   di
    26a5:	9a 95 28 00 27       	call   0x2700:0x2895
    26aa:	08 c0                	or     al,al
    26ac:	75 0a                	jne    0x26b8
    26ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b1:	06                   	push   es
    26b2:	57                   	push   di
    26b3:	9a ff 13 0e 27       	call   0x270e:0x13ff
    26b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26bb:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    26c0:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    26c4:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    26c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26cb:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    26d0:	99                   	cwd
    26d1:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    26d5:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    26d9:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    26de:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    26e4:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    26ea:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    26ef:	8d be ea fe          	lea    di,[bp-0x116]
    26f3:	16                   	push   ss
    26f4:	57                   	push   di
    26f5:	6a 01                	push   0x1
    26f7:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    26fb:	06                   	push   es
    26fc:	57                   	push   di
    26fd:	9a 95 28 58 27       	call   0x2758:0x2895
    2702:	08 c0                	or     al,al
    2704:	75 0a                	jne    0x2710
    2706:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2709:	06                   	push   es
    270a:	57                   	push   di
    270b:	9a ff 13 66 27       	call   0x2766:0x13ff
    2710:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2713:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    2718:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    271c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2720:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2723:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    2728:	99                   	cwd
    2729:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    272d:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2731:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2736:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    273c:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2742:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2747:	8d be ea fe          	lea    di,[bp-0x116]
    274b:	16                   	push   ss
    274c:	57                   	push   di
    274d:	6a 01                	push   0x1
    274f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2753:	06                   	push   es
    2754:	57                   	push   di
    2755:	9a 95 28 bf 27       	call   0x27bf:0x2895
    275a:	08 c0                	or     al,al
    275c:	75 0a                	jne    0x2768
    275e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2761:	06                   	push   es
    2762:	57                   	push   di
    2763:	9a ff 13 cd 27       	call   0x27cd:0x13ff
    2768:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    276b:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    2770:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2774:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2778:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    277b:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    2780:	2d 01 00             	sub    ax,0x1
    2783:	71 05                	jno    0x278a
    2785:	9a 3e 04 ef 27       	call   0x27ef:0x43e
    278a:	99                   	cwd
    278b:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    278f:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2793:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2798:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    279b:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    27a0:	99                   	cwd
    27a1:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    27a5:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    27a9:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    27ae:	8d be ea fe          	lea    di,[bp-0x116]
    27b2:	16                   	push   ss
    27b3:	57                   	push   di
    27b4:	6a 01                	push   0x1
    27b6:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    27ba:	06                   	push   es
    27bb:	57                   	push   di
    27bc:	9a 95 28 37 28       	call   0x2837:0x2895
    27c1:	08 c0                	or     al,al
    27c3:	75 0a                	jne    0x27cf
    27c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c8:	06                   	push   es
    27c9:	57                   	push   di
    27ca:	9a ff 13 45 28       	call   0x2845:0x13ff
    27cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27d2:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    27d7:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    27db:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    27df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e2:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    27e7:	2d 01 00             	sub    ax,0x1
    27ea:	71 05                	jno    0x27f1
    27ec:	9a 3e 04 67 28       	call   0x2867:0x43e
    27f1:	99                   	cwd
    27f2:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    27f6:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    27fa:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    27ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2802:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    2807:	99                   	cwd
    2808:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    280c:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2810:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2815:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    281b:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2821:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2826:	8d be e2 fe          	lea    di,[bp-0x11e]
    282a:	16                   	push   ss
    282b:	57                   	push   di
    282c:	6a 02                	push   0x2
    282e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2832:	06                   	push   es
    2833:	57                   	push   di
    2834:	9a 95 28 af 28       	call   0x28af:0x2895
    2839:	08 c0                	or     al,al
    283b:	75 0a                	jne    0x2847
    283d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2840:	06                   	push   es
    2841:	57                   	push   di
    2842:	9a ff 13 bd 28       	call   0x28bd:0x13ff
    2847:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284a:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    284f:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2853:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2857:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    285a:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    285f:	2d 01 00             	sub    ax,0x1
    2862:	71 05                	jno    0x2869
    2864:	9a 3e 04 35 2b       	call   0x2b35:0x43e
    2869:	99                   	cwd
    286a:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    286e:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2872:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2877:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    287a:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    287f:	99                   	cwd
    2880:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2884:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2888:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    288d:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    2893:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2899:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    289e:	8d be e2 fe          	lea    di,[bp-0x11e]
    28a2:	16                   	push   ss
    28a3:	57                   	push   di
    28a4:	6a 02                	push   0x2
    28a6:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    28aa:	06                   	push   es
    28ab:	57                   	push   di
    28ac:	9a 95 28 1a 29       	call   0x291a:0x2895
    28b1:	08 c0                	or     al,al
    28b3:	75 0a                	jne    0x28bf
    28b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b8:	06                   	push   es
    28b9:	57                   	push   di
    28ba:	9a ff 13 28 29       	call   0x2928:0x13ff
    28bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28c2:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    28c7:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    28cb:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    28cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d2:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    28d7:	99                   	cwd
    28d8:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    28dc:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    28e0:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    28e5:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    28ea:	99                   	cwd
    28eb:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    28ef:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    28f3:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    28f8:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    28fe:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2904:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2909:	8d be e2 fe          	lea    di,[bp-0x11e]
    290d:	16                   	push   ss
    290e:	57                   	push   di
    290f:	6a 02                	push   0x2
    2911:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2915:	06                   	push   es
    2916:	57                   	push   di
    2917:	9a 95 28 85 29       	call   0x2985:0x2895
    291c:	08 c0                	or     al,al
    291e:	75 0a                	jne    0x292a
    2920:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2923:	06                   	push   es
    2924:	57                   	push   di
    2925:	9a ff 13 93 29       	call   0x2993:0x13ff
    292a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    292d:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    2932:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2936:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    293a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    293d:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    2942:	99                   	cwd
    2943:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2947:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    294b:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2950:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    2955:	99                   	cwd
    2956:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    295a:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    295e:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2963:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    2969:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    296f:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2974:	8d be e2 fe          	lea    di,[bp-0x11e]
    2978:	16                   	push   ss
    2979:	57                   	push   di
    297a:	6a 02                	push   0x2
    297c:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2980:	06                   	push   es
    2981:	57                   	push   di
    2982:	9a 95 28 df 29       	call   0x29df:0x2895
    2987:	08 c0                	or     al,al
    2989:	75 0a                	jne    0x2995
    298b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    298e:	06                   	push   es
    298f:	57                   	push   di
    2990:	9a ff 13 ed 29       	call   0x29ed:0x13ff
    2995:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2998:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    299d:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    29a1:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    29a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a8:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    29ad:	99                   	cwd
    29ae:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    29b2:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    29b6:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    29bb:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    29c0:	99                   	cwd
    29c1:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    29c5:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    29c9:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    29ce:	8d be ea fe          	lea    di,[bp-0x116]
    29d2:	16                   	push   ss
    29d3:	57                   	push   di
    29d4:	6a 01                	push   0x1
    29d6:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    29da:	06                   	push   es
    29db:	57                   	push   di
    29dc:	9a 95 28 4a 2a       	call   0x2a4a:0x2895
    29e1:	08 c0                	or     al,al
    29e3:	75 0a                	jne    0x29ef
    29e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29e8:	06                   	push   es
    29e9:	57                   	push   di
    29ea:	9a ff 13 58 2a       	call   0x2a58:0x13ff
    29ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29f2:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    29f7:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    29fb:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    29ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a02:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    2a07:	99                   	cwd
    2a08:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2a0c:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2a10:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2a15:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    2a1a:	99                   	cwd
    2a1b:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2a1f:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2a23:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2a28:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    2a2e:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2a34:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2a39:	8d be e2 fe          	lea    di,[bp-0x11e]
    2a3d:	16                   	push   ss
    2a3e:	57                   	push   di
    2a3f:	6a 02                	push   0x2
    2a41:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2a45:	06                   	push   es
    2a46:	57                   	push   di
    2a47:	9a 95 28 b5 2a       	call   0x2ab5:0x2895
    2a4c:	08 c0                	or     al,al
    2a4e:	75 0a                	jne    0x2a5a
    2a50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a53:	06                   	push   es
    2a54:	57                   	push   di
    2a55:	9a ff 13 c3 2a       	call   0x2ac3:0x13ff
    2a5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a5d:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2a62:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2a66:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2a6a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a6d:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    2a72:	99                   	cwd
    2a73:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2a77:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2a7b:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2a80:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    2a85:	99                   	cwd
    2a86:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2a8a:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2a8e:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2a93:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    2a99:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2a9f:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2aa4:	8d be e2 fe          	lea    di,[bp-0x11e]
    2aa8:	16                   	push   ss
    2aa9:	57                   	push   di
    2aaa:	6a 02                	push   0x2
    2aac:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2ab0:	06                   	push   es
    2ab1:	57                   	push   di
    2ab2:	9a 95 28 0f 2b       	call   0x2b0f:0x2895
    2ab7:	08 c0                	or     al,al
    2ab9:	75 0a                	jne    0x2ac5
    2abb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2abe:	06                   	push   es
    2abf:	57                   	push   di
    2ac0:	9a ff 13 1d 2b       	call   0x2b1d:0x13ff
    2ac5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac8:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2acd:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2ad1:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2ad5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad8:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    2add:	99                   	cwd
    2ade:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2ae2:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2ae6:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2aeb:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    2af0:	99                   	cwd
    2af1:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2af5:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    2af9:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2afe:	8d be ea fe          	lea    di,[bp-0x116]
    2b02:	16                   	push   ss
    2b03:	57                   	push   di
    2b04:	6a 01                	push   0x1
    2b06:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2b0a:	06                   	push   es
    2b0b:	57                   	push   di
    2b0c:	9a 95 28 76 2f       	call   0x2f76:0x2895
    2b11:	08 c0                	or     al,al
    2b13:	75 0a                	jne    0x2b1f
    2b15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b18:	06                   	push   es
    2b19:	57                   	push   di
    2b1a:	9a ff 13 27 2b       	call   0x2b27:0x13ff
    2b1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b22:	06                   	push   es
    2b23:	57                   	push   di
    2b24:	9a 9b 20 18 2c       	call   0x2c18:0x209b
    2b29:	c9                   	leave
    2b2a:	ca 04 00             	retf   0x4
    2b2d:	55                   	push   bp
    2b2e:	89 e5                	mov    bp,sp
    2b30:	31 c0                	xor    ax,ax
    2b32:	9a 44 04 06 2c       	call   0x2c06:0x444
    2b37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b3a:	26 c4 bd 24 02       	les    di,DWORD PTR es:[di+0x224]
    2b3f:	06                   	push   es
    2b40:	57                   	push   di
    2b41:	9a d2 31 53 2b       	call   0x2b53:0x31d2
    2b46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b49:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2b4e:	06                   	push   es
    2b4f:	57                   	push   di
    2b50:	9a d2 31 62 2b       	call   0x2b62:0x31d2
    2b55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b58:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    2b5d:	06                   	push   es
    2b5e:	57                   	push   di
    2b5f:	9a d2 31 71 2b       	call   0x2b71:0x31d2
    2b64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b67:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    2b6c:	06                   	push   es
    2b6d:	57                   	push   di
    2b6e:	9a d2 31 80 2b       	call   0x2b80:0x31d2
    2b73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b76:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    2b7b:	06                   	push   es
    2b7c:	57                   	push   di
    2b7d:	9a d2 31 8f 2b       	call   0x2b8f:0x31d2
    2b82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b85:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    2b8a:	06                   	push   es
    2b8b:	57                   	push   di
    2b8c:	9a d2 31 9e 2b       	call   0x2b9e:0x31d2
    2b91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b94:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    2b99:	06                   	push   es
    2b9a:	57                   	push   di
    2b9b:	9a d2 31 ad 2b       	call   0x2bad:0x31d2
    2ba0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ba3:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    2ba8:	06                   	push   es
    2ba9:	57                   	push   di
    2baa:	9a d2 31 bc 2b       	call   0x2bbc:0x31d2
    2baf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bb2:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    2bb7:	06                   	push   es
    2bb8:	57                   	push   di
    2bb9:	9a d2 31 cb 2b       	call   0x2bcb:0x31d2
    2bbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bc1:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    2bc6:	06                   	push   es
    2bc7:	57                   	push   di
    2bc8:	9a d2 31 da 2b       	call   0x2bda:0x31d2
    2bcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bd0:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2bd5:	06                   	push   es
    2bd6:	57                   	push   di
    2bd7:	9a d2 31 e9 2b       	call   0x2be9:0x31d2
    2bdc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bdf:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    2be4:	06                   	push   es
    2be5:	57                   	push   di
    2be6:	9a d2 31 f8 2b       	call   0x2bf8:0x31d2
    2beb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bee:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2bf3:	06                   	push   es
    2bf4:	57                   	push   di
    2bf5:	9a d2 31 ac 38       	call   0x38ac:0x31d2
    2bfa:	c9                   	leave
    2bfb:	ca 04 00             	retf   0x4
    2bfe:	55                   	push   bp
    2bff:	89 e5                	mov    bp,sp
    2c01:	31 c0                	xor    ax,ax
    2c03:	9a 44 04 26 2c       	call   0x2c26:0x444
    2c08:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2c0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c0e:	26 89 85 7e 05       	mov    WORD PTR es:[di+0x57e],ax
    2c13:	06                   	push   es
    2c14:	57                   	push   di
    2c15:	9a 0a 24 38 2c       	call   0x2c38:0x240a
    2c1a:	c9                   	leave
    2c1b:	ca 06 00             	retf   0x6
    2c1e:	55                   	push   bp
    2c1f:	89 e5                	mov    bp,sp
    2c21:	31 c0                	xor    ax,ax
    2c23:	9a 44 04 57 2c       	call   0x2c57:0x444
    2c28:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2c2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c2e:	26 89 85 80 05       	mov    WORD PTR es:[di+0x580],ax
    2c33:	06                   	push   es
    2c34:	57                   	push   di
    2c35:	9a 0a 24 b8 30       	call   0x30b8:0x240a
    2c3a:	c9                   	leave
    2c3b:	ca 06 00             	retf   0x6
    2c3e:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    2c41:	6d                   	ins    WORD PTR es:[di],dx
    2c42:	73 74                	jae    0x2cb8
    2c44:	72 61                	jb     0x2ca7
    2c46:	74 20                	je     0x2c68
    2c48:	2d 20 03             	sub    ax,0x320
    2c4b:	20 2d                	and    BYTE PTR [di],ch
    2c4d:	20 55 89             	and    BYTE PTR [di-0x77],dl
    2c50:	e5 b8                	in     ax,0xb8
    2c52:	02 03                	add    al,BYTE PTR [bp+di]
    2c54:	9a 44 04 6b 2c       	call   0x2c6b:0x444
    2c59:	81 ec 02 03          	sub    sp,0x302
    2c5d:	8d be fe fe          	lea    di,[bp-0x102]
    2c61:	16                   	push   ss
    2c62:	57                   	push   di
    2c63:	bf 3e 2c             	mov    di,0x2c3e
    2c66:	0e                   	push   cs
    2c67:	57                   	push   di
    2c68:	9a cd 17 75 2c       	call   0x2c75:0x17cd
    2c6d:	bf fa 1d             	mov    di,0x1dfa
    2c70:	1e                   	push   ds
    2c71:	57                   	push   di
    2c72:	9a 4c 18 7f 2c       	call   0x2c7f:0x184c
    2c77:	bf 4a 2c             	mov    di,0x2c4a
    2c7a:	0e                   	push   cs
    2c7b:	57                   	push   di
    2c7c:	9a 4c 18 94 2c       	call   0x2c94:0x184c
    2c81:	8d be fe fd          	lea    di,[bp-0x202]
    2c85:	16                   	push   ss
    2c86:	57                   	push   di
    2c87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c8a:	06                   	push   es
    2c8b:	57                   	push   di
    2c8c:	9a 53 1d b9 2c       	call   0x2cb9:0x1d53
    2c91:	9a 4c 18 a5 2c       	call   0x2ca5:0x184c
    2c96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c99:	81 c7 82 05          	add    di,0x582
    2c9d:	06                   	push   es
    2c9e:	57                   	push   di
    2c9f:	68 ff 00             	push   0xff
    2ca2:	9a e7 17 f1 2c       	call   0x2cf1:0x17e7
    2ca7:	bf fa 1d             	mov    di,0x1dfa
    2caa:	1e                   	push   ds
    2cab:	57                   	push   di
    2cac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2caf:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    2cb4:	06                   	push   es
    2cb5:	57                   	push   di
    2cb6:	9a 8c 1d e6 2d       	call   0x2de6:0x1d8c
    2cbb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cbe:	26 c7 85 7c 05 64 00 	mov    WORD PTR es:[di+0x57c],0x64
    2cc5:	c7 06 44 01 ff ff    	mov    WORD PTR ds:0x144,0xffff
    2ccb:	c7 06 46 01 ff ff    	mov    WORD PTR ds:0x146,0xffff
    2cd1:	c7 06 48 01 ff ff    	mov    WORD PTR ds:0x148,0xffff
    2cd7:	26 c4 bd 1c 02       	les    di,DWORD PTR es:[di+0x21c]
    2cdc:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2cdf:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2ce2:	06                   	push   es
    2ce3:	57                   	push   di
    2ce4:	9a 26 13 1b 2d       	call   0x2d1b:0x1326
    2ce9:	2d 01 00             	sub    ax,0x1
    2cec:	71 05                	jno    0x2cf3
    2cee:	9a 3e 04 53 2d       	call   0x2d53:0x43e
    2cf3:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2cf6:	31 c0                	xor    ax,ax
    2cf8:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2cfb:	7f 33                	jg     0x2d30
    2cfd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d00:	eb 03                	jmp    0x2d05
    2d02:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2d05:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d08:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    2d0c:	7c 1a                	jl     0x2d28
    2d0e:	6a 00                	push   0x0
    2d10:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d13:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2d16:	06                   	push   es
    2d17:	57                   	push   di
    2d18:	9a 53 13 26 2d       	call   0x2d26:0x1353
    2d1d:	89 c7                	mov    di,ax
    2d1f:	8e c2                	mov    es,dx
    2d21:	06                   	push   es
    2d22:	57                   	push   di
    2d23:	9a a5 13 75 2d       	call   0x2d75:0x13a5
    2d28:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d2b:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2d2e:	75 d2                	jne    0x2d02
    2d30:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d33:	26 c4 bd 90 03       	les    di,DWORD PTR es:[di+0x390]
    2d38:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2d3b:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2d3e:	31 c0                	xor    ax,ax
    2d40:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d43:	eb 03                	jmp    0x2d48
    2d45:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2d48:	a1 4c 01             	mov    ax,ds:0x14c
    2d4b:	2d 01 00             	sub    ax,0x1
    2d4e:	71 05                	jno    0x2d55
    2d50:	9a 3e 04 62 2d       	call   0x2d62:0x43e
    2d55:	8b d0                	mov    dx,ax
    2d57:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d5a:	05 01 00             	add    ax,0x1
    2d5d:	71 05                	jno    0x2d64
    2d5f:	9a 3e 04 bc 2d       	call   0x2dbc:0x43e
    2d64:	3b c2                	cmp    ax,dx
    2d66:	7e 1a                	jle    0x2d82
    2d68:	6a 00                	push   0x0
    2d6a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d6d:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2d70:	06                   	push   es
    2d71:	57                   	push   di
    2d72:	9a 53 13 80 2d       	call   0x2d80:0x1353
    2d77:	89 c7                	mov    di,ax
    2d79:	8e c2                	mov    es,dx
    2d7b:	06                   	push   es
    2d7c:	57                   	push   di
    2d7d:	9a a5 13 3c 31       	call   0x313c:0x13a5
    2d82:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    2d86:	75 bd                	jne    0x2d45
    2d88:	6a 00                	push   0x0
    2d8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d8d:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2d92:	06                   	push   es
    2d93:	57                   	push   di
    2d94:	9a d0 1c a8 2d       	call   0x2da8:0x1cd0
    2d99:	6a 00                	push   0x0
    2d9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d9e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2da3:	06                   	push   es
    2da4:	57                   	push   di
    2da5:	9a d0 1c a0 30       	call   0x30a0:0x1cd0
    2daa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dad:	06                   	push   es
    2dae:	57                   	push   di
    2daf:	9a 7d 52 de 2d       	call   0x2dde:0x527d
    2db4:	2d 01 00             	sub    ax,0x1
    2db7:	71 05                	jno    0x2dbe
    2db9:	9a 3e 04 ed 2d       	call   0x2ded:0x43e
    2dbe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2dc1:	31 c0                	xor    ax,ax
    2dc3:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2dc6:	7e 03                	jle    0x2dcb
    2dc8:	e9 a7 00             	jmp    0x2e72
    2dcb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2dce:	eb 03                	jmp    0x2dd3
    2dd0:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2dd3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2dd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dd9:	06                   	push   es
    2dda:	57                   	push   di
    2ddb:	9a 46 52 fe 2d       	call   0x2dfe:0x5246
    2de0:	52                   	push   dx
    2de1:	50                   	push   ax
    2de2:	bf 99 03             	mov    di,0x399
    2de5:	b8 06 2e             	mov    ax,0x2e06
    2de8:	50                   	push   ax
    2de9:	57                   	push   di
    2dea:	9a 55 22 0d 2e       	call   0x2e0d:0x2255
    2def:	08 c0                	or     al,al
    2df1:	74 74                	je     0x2e67
    2df3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2df6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2df9:	06                   	push   es
    2dfa:	57                   	push   di
    2dfb:	9a 46 52 fb 33       	call   0x33fb:0x5246
    2e00:	52                   	push   dx
    2e01:	50                   	push   ax
    2e02:	bf 99 03             	mov    di,0x399
    2e05:	b8 65 2e             	mov    ax,0x2e65
    2e08:	50                   	push   ax
    2e09:	57                   	push   di
    2e0a:	9a 73 22 4a 2e       	call   0x2e4a:0x2273
    2e0f:	89 c7                	mov    di,ax
    2e11:	8e c2                	mov    es,dx
    2e13:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2e16:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2e19:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2e1e:	74 47                	je     0x2e67
    2e20:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2e24:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    2e28:	74 3d                	je     0x2e67
    2e2a:	a1 06 1e             	mov    ax,ds:0x1e06
    2e2d:	99                   	cwd
    2e2e:	8b c8                	mov    cx,ax
    2e30:	8b da                	mov    bx,dx
    2e32:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2e36:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    2e3a:	09 d2                	or     dx,dx
    2e3c:	79 07                	jns    0x2e45
    2e3e:	f7 d2                	not    dx
    2e40:	f7 d8                	neg    ax
    2e42:	83 da ff             	sbb    dx,0xffff
    2e45:	71 05                	jno    0x2e4c
    2e47:	9a 3e 04 ff 2e       	call   0x2eff:0x43e
    2e4c:	3b d3                	cmp    dx,bx
    2e4e:	7c 0a                	jl     0x2e5a
    2e50:	7f 04                	jg     0x2e56
    2e52:	3b c1                	cmp    ax,cx
    2e54:	76 04                	jbe    0x2e5a
    2e56:	b0 00                	mov    al,0x0
    2e58:	eb 02                	jmp    0x2e5c
    2e5a:	b0 01                	mov    al,0x1
    2e5c:	50                   	push   ax
    2e5d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2e60:	06                   	push   es
    2e61:	57                   	push   di
    2e62:	9a 77 1c 86 2e       	call   0x2e86:0x1c77
    2e67:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e6a:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2e6d:	74 03                	je     0x2e72
    2e6f:	e9 5e ff             	jmp    0x2dd0
    2e72:	8d be fe fe          	lea    di,[bp-0x102]
    2e76:	16                   	push   ss
    2e77:	57                   	push   di
    2e78:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2e7c:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    2e81:	06                   	push   es
    2e82:	57                   	push   di
    2e83:	9a 53 1d 95 2e       	call   0x2e95:0x1d53
    2e88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e8b:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    2e90:	06                   	push   es
    2e91:	57                   	push   di
    2e92:	9a 8c 1d ab 2e       	call   0x2eab:0x1d8c
    2e97:	8d be fe fe          	lea    di,[bp-0x102]
    2e9b:	16                   	push   ss
    2e9c:	57                   	push   di
    2e9d:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2ea1:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    2ea6:	06                   	push   es
    2ea7:	57                   	push   di
    2ea8:	9a 53 1d ba 2e       	call   0x2eba:0x1d53
    2ead:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eb0:	26 c4 bd fc 02       	les    di,DWORD PTR es:[di+0x2fc]
    2eb5:	06                   	push   es
    2eb6:	57                   	push   di
    2eb7:	9a 8c 1d d0 2e       	call   0x2ed0:0x1d8c
    2ebc:	8d be fe fe          	lea    di,[bp-0x102]
    2ec0:	16                   	push   ss
    2ec1:	57                   	push   di
    2ec2:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2ec6:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    2ecb:	06                   	push   es
    2ecc:	57                   	push   di
    2ecd:	9a 53 1d df 2e       	call   0x2edf:0x1d53
    2ed2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed5:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    2eda:	06                   	push   es
    2edb:	57                   	push   di
    2edc:	9a 8c 1d f5 2e       	call   0x2ef5:0x1d8c
    2ee1:	8d be fe fe          	lea    di,[bp-0x102]
    2ee5:	16                   	push   ss
    2ee6:	57                   	push   di
    2ee7:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2eeb:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    2ef0:	06                   	push   es
    2ef1:	57                   	push   di
    2ef2:	9a 53 1d 62 2f       	call   0x2f62:0x1d53
    2ef7:	bf 4a 2c             	mov    di,0x2c4a
    2efa:	0e                   	push   cs
    2efb:	57                   	push   di
    2efc:	9a 4c 18 1f 2f       	call   0x2f1f:0x184c
    2f01:	8d be fe fd          	lea    di,[bp-0x202]
    2f05:	16                   	push   ss
    2f06:	57                   	push   di
    2f07:	9a fe 15 1a 2f       	call   0x2f1a:0x15fe
    2f0c:	83 ec 08             	sub    sp,0x8
    2f0f:	89 e3                	mov    bx,sp
    2f11:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2f15:	90                   	nop
    2f16:	9b                   	fwait
    2f17:	9a bf 1c 34 2f       	call   0x2f34:0x1cbf
    2f1c:	9a 4c 18 29 2f       	call   0x2f29:0x184c
    2f21:	bf 4a 2c             	mov    di,0x2c4a
    2f24:	0e                   	push   cs
    2f25:	57                   	push   di
    2f26:	9a 4c 18 49 2f       	call   0x2f49:0x184c
    2f2b:	8d be fe fc          	lea    di,[bp-0x302]
    2f2f:	16                   	push   ss
    2f30:	57                   	push   di
    2f31:	9a fe 15 44 2f       	call   0x2f44:0x15fe
    2f36:	83 ec 08             	sub    sp,0x8
    2f39:	89 e3                	mov    bx,sp
    2f3b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2f3f:	90                   	nop
    2f40:	9b                   	fwait
    2f41:	9a e4 1c 0d 34       	call   0x340d:0x1ce4
    2f46:	9a 4c 18 53 2f       	call   0x2f53:0x184c
    2f4b:	bf 4a 2c             	mov    di,0x2c4a
    2f4e:	0e                   	push   cs
    2f4f:	57                   	push   di
    2f50:	9a 4c 18 7d 30       	call   0x307d:0x184c
    2f55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f58:	26 c4 bd 04 03       	les    di,DWORD PTR es:[di+0x304]
    2f5d:	06                   	push   es
    2f5e:	57                   	push   di
    2f5f:	9a 8c 1d 25 32       	call   0x3225:0x1d8c
    2f64:	bf 32 1e             	mov    di,0x1e32
    2f67:	1e                   	push   ds
    2f68:	57                   	push   di
    2f69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f6c:	26 c4 bd 24 02       	les    di,DWORD PTR es:[di+0x224]
    2f71:	06                   	push   es
    2f72:	57                   	push   di
    2f73:	9a 17 30 8a 2f       	call   0x2f8a:0x3017
    2f78:	bf 32 1e             	mov    di,0x1e32
    2f7b:	1e                   	push   ds
    2f7c:	57                   	push   di
    2f7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f80:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2f85:	06                   	push   es
    2f86:	57                   	push   di
    2f87:	9a 17 30 9e 2f       	call   0x2f9e:0x3017
    2f8c:	bf 40 1e             	mov    di,0x1e40
    2f8f:	1e                   	push   ds
    2f90:	57                   	push   di
    2f91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f94:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    2f99:	06                   	push   es
    2f9a:	57                   	push   di
    2f9b:	9a 17 30 b2 2f       	call   0x2fb2:0x3017
    2fa0:	bf 40 1e             	mov    di,0x1e40
    2fa3:	1e                   	push   ds
    2fa4:	57                   	push   di
    2fa5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa8:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    2fad:	06                   	push   es
    2fae:	57                   	push   di
    2faf:	9a 17 30 c6 2f       	call   0x2fc6:0x3017
    2fb4:	bf 78 1e             	mov    di,0x1e78
    2fb7:	1e                   	push   ds
    2fb8:	57                   	push   di
    2fb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fbc:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    2fc1:	06                   	push   es
    2fc2:	57                   	push   di
    2fc3:	9a 17 30 da 2f       	call   0x2fda:0x3017
    2fc8:	bf 86 1e             	mov    di,0x1e86
    2fcb:	1e                   	push   ds
    2fcc:	57                   	push   di
    2fcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd0:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    2fd5:	06                   	push   es
    2fd6:	57                   	push   di
    2fd7:	9a 17 30 ee 2f       	call   0x2fee:0x3017
    2fdc:	bf 86 1e             	mov    di,0x1e86
    2fdf:	1e                   	push   ds
    2fe0:	57                   	push   di
    2fe1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fe4:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    2fe9:	06                   	push   es
    2fea:	57                   	push   di
    2feb:	9a 17 30 02 30       	call   0x3002:0x3017
    2ff0:	bf 4e 1e             	mov    di,0x1e4e
    2ff3:	1e                   	push   ds
    2ff4:	57                   	push   di
    2ff5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ff8:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    2ffd:	06                   	push   es
    2ffe:	57                   	push   di
    2fff:	9a 17 30 16 30       	call   0x3016:0x3017
    3004:	bf 5c 1e             	mov    di,0x1e5c
    3007:	1e                   	push   ds
    3008:	57                   	push   di
    3009:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    300c:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    3011:	06                   	push   es
    3012:	57                   	push   di
    3013:	9a 17 30 2a 30       	call   0x302a:0x3017
    3018:	bf 5c 1e             	mov    di,0x1e5c
    301b:	1e                   	push   ds
    301c:	57                   	push   di
    301d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3020:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    3025:	06                   	push   es
    3026:	57                   	push   di
    3027:	9a 17 30 3e 30       	call   0x303e:0x3017
    302c:	bf 78 1e             	mov    di,0x1e78
    302f:	1e                   	push   ds
    3030:	57                   	push   di
    3031:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3034:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    3039:	06                   	push   es
    303a:	57                   	push   di
    303b:	9a 17 30 52 30       	call   0x3052:0x3017
    3040:	bf 86 1e             	mov    di,0x1e86
    3043:	1e                   	push   ds
    3044:	57                   	push   di
    3045:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3048:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    304d:	06                   	push   es
    304e:	57                   	push   di
    304f:	9a 17 30 66 30       	call   0x3066:0x3017
    3054:	bf 86 1e             	mov    di,0x1e86
    3057:	1e                   	push   ds
    3058:	57                   	push   di
    3059:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    305c:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3061:	06                   	push   es
    3062:	57                   	push   di
    3063:	9a 17 30 e6 38       	call   0x38e6:0x3017
    3068:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    306b:	26 c7 85 80 05 01 00 	mov    WORD PTR es:[di+0x580],0x1
    3072:	a1 4c 01             	mov    ax,ds:0x14c
    3075:	2d 01 00             	sub    ax,0x1
    3078:	71 05                	jno    0x307f
    307a:	9a 3e 04 93 30       	call   0x3093:0x43e
    307f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3082:	26 89 85 7e 05       	mov    WORD PTR es:[di+0x57e],ax
    3087:	c9                   	leave
    3088:	ca 08 00             	retf   0x8
    308b:	55                   	push   bp
    308c:	89 e5                	mov    bp,sp
    308e:	31 c0                	xor    ax,ax
    3090:	9a 44 04 ae 30       	call   0x30ae:0x444
    3095:	6a fe                	push   0xfffe
    3097:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    309b:	06                   	push   es
    309c:	57                   	push   di
    309d:	9a a9 63 d7 30       	call   0x30d7:0x63a9
    30a2:	c9                   	leave
    30a3:	ca 08 00             	retf   0x8
    30a6:	55                   	push   bp
    30a7:	89 e5                	mov    bp,sp
    30a9:	31 c0                	xor    ax,ax
    30ab:	9a 44 04 cd 30       	call   0x30cd:0x444
    30b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30b3:	06                   	push   es
    30b4:	57                   	push   di
    30b5:	9a 2d 2b a0 32       	call   0x32a0:0x2b2d
    30ba:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    30bd:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    30c1:	c9                   	leave
    30c2:	ca 0c 00             	retf   0xc
    30c5:	55                   	push   bp
    30c6:	89 e5                	mov    bp,sp
    30c8:	31 c0                	xor    ax,ax
    30ca:	9a 44 04 e5 30       	call   0x30e5:0x444
    30cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30d2:	06                   	push   es
    30d3:	57                   	push   di
    30d4:	9a 56 55 f9 30       	call   0x30f9:0x5556
    30d9:	c9                   	leave
    30da:	ca 08 00             	retf   0x8
    30dd:	55                   	push   bp
    30de:	89 e5                	mov    bp,sp
    30e0:	31 c0                	xor    ax,ax
    30e2:	9a 44 04 22 31       	call   0x3122:0x444
    30e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30ea:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    30f0:	75 0b                	jne    0x30fd
    30f2:	6a 00                	push   0x0
    30f4:	06                   	push   es
    30f5:	57                   	push   di
    30f6:	9a 14 3a 07 31       	call   0x3107:0x3a14
    30fb:	eb 0c                	jmp    0x3109
    30fd:	6a 02                	push   0x2
    30ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3102:	06                   	push   es
    3103:	57                   	push   di
    3104:	9a 14 3a e0 4d       	call   0x4de0:0x3a14
    3109:	c9                   	leave
    310a:	ca 08 00             	retf   0x8
    310d:	84 31                	test   BYTE PTR [bx+di],dh
    310f:	8b 31                	mov    si,WORD PTR [bx+di]
    3111:	92                   	xchg   dx,ax
    3112:	31 99 31 a0          	xor    WORD PTR [bx+di-0x5fcf],bx
    3116:	31 a7 31 55          	xor    WORD PTR [bx+0x5531],sp
    311a:	89 e5                	mov    bp,sp
    311c:	b8 0e 00             	mov    ax,0xe
    311f:	9a 44 04 43 31       	call   0x3143:0x444
    3124:	83 ec 0e             	sub    sp,0xe
    3127:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    312a:	26 8b 85 7c 05       	mov    ax,WORD PTR es:[di+0x57c]
    312f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3132:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3135:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3138:	bf 94 00             	mov    di,0x94
    313b:	b8 56 31             	mov    ax,0x3156
    313e:	50                   	push   ax
    313f:	57                   	push   di
    3140:	9a 55 22 5d 31       	call   0x315d:0x2255
    3145:	08 c0                	or     al,al
    3147:	75 03                	jne    0x314c
    3149:	e9 bf 00             	jmp    0x320b
    314c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    314f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3152:	bf 94 00             	mov    di,0x94
    3155:	b8 6e 31             	mov    ax,0x316e
    3158:	50                   	push   ax
    3159:	57                   	push   di
    315a:	9a 73 22 cb 31       	call   0x31cb:0x2273
    315f:	52                   	push   dx
    3160:	50                   	push   ax
    3161:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3164:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    3169:	06                   	push   es
    316a:	57                   	push   di
    316b:	9a 2b 16 c1 31       	call   0x31c1:0x162b
    3170:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3173:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3176:	3d 05 00             	cmp    ax,0x5
    3179:	77 33                	ja     0x31ae
    317b:	89 c3                	mov    bx,ax
    317d:	d1 e3                	shl    bx,1
    317f:	2e ff a7 0d 31       	jmp    WORD PTR cs:[bx+0x310d]
    3184:	c7 46 fe 64 00       	mov    WORD PTR [bp-0x2],0x64
    3189:	eb 23                	jmp    0x31ae
    318b:	c7 46 fe 7d 00       	mov    WORD PTR [bp-0x2],0x7d
    3190:	eb 1c                	jmp    0x31ae
    3192:	c7 46 fe 96 00       	mov    WORD PTR [bp-0x2],0x96
    3197:	eb 15                	jmp    0x31ae
    3199:	c7 46 fe c8 00       	mov    WORD PTR [bp-0x2],0xc8
    319e:	eb 0e                	jmp    0x31ae
    31a0:	c7 46 fe 4b 00       	mov    WORD PTR [bp-0x2],0x4b
    31a5:	eb 07                	jmp    0x31ae
    31a7:	c7 46 fe 32 00       	mov    WORD PTR [bp-0x2],0x32
    31ac:	eb 00                	jmp    0x31ae
    31ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31b1:	26 c4 bd 00 02       	les    di,DWORD PTR es:[di+0x200]
    31b6:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    31b9:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    31bc:	06                   	push   es
    31bd:	57                   	push   di
    31be:	9a 26 13 f6 31       	call   0x31f6:0x1326
    31c3:	2d 01 00             	sub    ax,0x1
    31c6:	71 05                	jno    0x31cd
    31c8:	9a 3e 04 3e 32       	call   0x323e:0x43e
    31cd:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    31d0:	31 c0                	xor    ax,ax
    31d2:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    31d5:	7f 34                	jg     0x320b
    31d7:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    31da:	eb 03                	jmp    0x31df
    31dc:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    31df:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    31e2:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    31e5:	b0 00                	mov    al,0x0
    31e7:	75 01                	jne    0x31ea
    31e9:	40                   	inc    ax
    31ea:	50                   	push   ax
    31eb:	ff 76 f8             	push   WORD PTR [bp-0x8]
    31ee:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    31f1:	06                   	push   es
    31f2:	57                   	push   di
    31f3:	9a 53 13 01 32       	call   0x3201:0x1353
    31f8:	89 c7                	mov    di,ax
    31fa:	8e c2                	mov    es,dx
    31fc:	06                   	push   es
    31fd:	57                   	push   di
    31fe:	9a 75 12 59 32       	call   0x3259:0x1275
    3203:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3206:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    3209:	75 d1                	jne    0x31dc
    320b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    320e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3211:	26 3b 85 7c 05       	cmp    ax,WORD PTR es:[di+0x57c]
    3216:	74 1a                	je     0x3232
    3218:	ff 76 fe             	push   WORD PTR [bp-0x2]
    321b:	26 ff b5 7c 05       	push   WORD PTR es:[di+0x57c]
    3220:	06                   	push   es
    3221:	57                   	push   di
    3222:	9a f4 5d 3c 4e       	call   0x4e3c:0x5df4
    3227:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    322a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    322d:	26 89 85 7c 05       	mov    WORD PTR es:[di+0x57c],ax
    3232:	c9                   	leave
    3233:	ca 08 00             	retf   0x8
    3236:	55                   	push   bp
    3237:	89 e5                	mov    bp,sp
    3239:	31 c0                	xor    ax,ax
    323b:	9a 44 04 68 32       	call   0x3268:0x444
    3240:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3243:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    3249:	b0 00                	mov    al,0x0
    324b:	75 01                	jne    0x324e
    324d:	40                   	inc    ax
    324e:	50                   	push   ax
    324f:	26 c4 bd f8 01       	les    di,DWORD PTR es:[di+0x1f8]
    3254:	06                   	push   es
    3255:	57                   	push   di
    3256:	9a 75 12 be 32       	call   0x32be:0x1275
    325b:	c9                   	leave
    325c:	ca 08 00             	retf   0x8
    325f:	55                   	push   bp
    3260:	89 e5                	mov    bp,sp
    3262:	b8 02 00             	mov    ax,0x2
    3265:	9a 44 04 78 32       	call   0x3278:0x444
    326a:	83 ec 02             	sub    sp,0x2
    326d:	a1 4c 01             	mov    ax,ds:0x14c
    3270:	2d 01 00             	sub    ax,0x1
    3273:	71 05                	jno    0x327a
    3275:	9a 3e 04 af 32       	call   0x32af:0x43e
    327a:	50                   	push   ax
    327b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    327e:	26 ff b5 7e 05       	push   WORD PTR es:[di+0x57e]
    3283:	9a 32 3e 7c 33       	call   0x337c:0x3e32
    3288:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    328b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    328e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3291:	26 3b 85 7e 05       	cmp    ax,WORD PTR es:[di+0x57e]
    3296:	74 0a                	je     0x32a2
    3298:	ff 76 fe             	push   WORD PTR [bp-0x2]
    329b:	06                   	push   es
    329c:	57                   	push   di
    329d:	9a fe 2b 96 33       	call   0x3396:0x2bfe
    32a2:	c9                   	leave
    32a3:	ca 08 00             	retf   0x8
    32a6:	55                   	push   bp
    32a7:	89 e5                	mov    bp,sp
    32a9:	b8 08 00             	mov    ax,0x8
    32ac:	9a 44 04 c5 32       	call   0x32c5:0x444
    32b1:	83 ec 08             	sub    sp,0x8
    32b4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    32b7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    32ba:	bf 94 00             	mov    di,0x94
    32bd:	b8 d8 32             	mov    ax,0x32d8
    32c0:	50                   	push   ax
    32c1:	57                   	push   di
    32c2:	9a 55 22 df 32       	call   0x32df:0x2255
    32c7:	08 c0                	or     al,al
    32c9:	75 03                	jne    0x32ce
    32cb:	e9 ca 00             	jmp    0x3398
    32ce:	ff 76 0c             	push   WORD PTR [bp+0xc]
    32d1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    32d4:	bf 94 00             	mov    di,0x94
    32d7:	b8 fa 32             	mov    ax,0x32fa
    32da:	50                   	push   ax
    32db:	57                   	push   di
    32dc:	9a 73 22 01 33       	call   0x3301:0x2273
    32e1:	89 c7                	mov    di,ax
    32e3:	8e c2                	mov    es,dx
    32e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32e8:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    32ed:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    32f0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    32f3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    32f6:	bf 94 00             	mov    di,0x94
    32f9:	b8 12 33             	mov    ax,0x3312
    32fc:	50                   	push   ax
    32fd:	57                   	push   di
    32fe:	9a 73 22 22 33       	call   0x3322:0x2273
    3303:	52                   	push   dx
    3304:	50                   	push   ax
    3305:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3308:	26 c4 bd 90 03       	les    di,DWORD PTR es:[di+0x390]
    330d:	06                   	push   es
    330e:	57                   	push   di
    330f:	9a 2b 16 bd 33       	call   0x33bd:0x162b
    3314:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3317:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    331a:	05 01 00             	add    ax,0x1
    331d:	71 05                	jno    0x3324
    331f:	9a 3e 04 56 33       	call   0x3356:0x43e
    3324:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    3328:	b0 00                	mov    al,0x0
    332a:	7d 01                	jge    0x332d
    332c:	40                   	inc    ax
    332d:	8a c8                	mov    cl,al
    332f:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    3333:	b0 00                	mov    al,0x0
    3335:	7d 01                	jge    0x3338
    3337:	40                   	inc    ax
    3338:	8a d0                	mov    dl,al
    333a:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    333e:	b0 00                	mov    al,0x0
    3340:	7c 01                	jl     0x3343
    3342:	40                   	inc    ax
    3343:	22 c2                	and    al,dl
    3345:	22 c1                	and    al,cl
    3347:	08 c0                	or     al,al
    3349:	74 12                	je     0x335d
    334b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    334e:	05 01 00             	add    ax,0x1
    3351:	71 05                	jno    0x3358
    3353:	9a 3e 04 6e 33       	call   0x336e:0x43e
    3358:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    335b:	eb 24                	jmp    0x3381
    335d:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    3361:	75 1e                	jne    0x3381
    3363:	a1 4c 01             	mov    ax,ds:0x14c
    3366:	2d 01 00             	sub    ax,0x1
    3369:	71 05                	jno    0x3370
    336b:	9a 3e 04 ad 33       	call   0x33ad:0x43e
    3370:	50                   	push   ax
    3371:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3374:	26 ff b5 7e 05       	push   WORD PTR es:[di+0x57e]
    3379:	9a 32 3e ff ff       	call   0xffff:0x3e32
    337e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3381:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3384:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3387:	26 3b 85 7e 05       	cmp    ax,WORD PTR es:[di+0x57e]
    338c:	74 0a                	je     0x3398
    338e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3391:	06                   	push   es
    3392:	57                   	push   di
    3393:	9a fe 2b 42 34       	call   0x3442:0x2bfe
    3398:	c9                   	leave
    3399:	ca 08 00             	retf   0x8
    339c:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    33a0:	ff                   	(bad)
    33a1:	7f 00                	jg     0x33a3
    33a3:	00 55 89             	add    BYTE PTR [di-0x77],dl
    33a6:	e5 b8                	in     ax,0xb8
    33a8:	06                   	push   es
    33a9:	02 9a 44 04          	add    bl,BYTE PTR [bp+si+0x444]
    33ad:	c4 33                	les    si,DWORD PTR [bp+di]
    33af:	81 ec 06 02          	sub    sp,0x206
    33b3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    33b6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    33b9:	bf 94 00             	mov    di,0x94
    33bc:	b8 d4 33             	mov    ax,0x33d4
    33bf:	50                   	push   ax
    33c0:	57                   	push   di
    33c1:	9a 55 22 db 33       	call   0x33db:0x2255
    33c6:	08 c0                	or     al,al
    33c8:	74 7a                	je     0x3444
    33ca:	ff 76 0c             	push   WORD PTR [bp+0xc]
    33cd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    33d0:	bf 94 00             	mov    di,0x94
    33d3:	b8 ff ff             	mov    ax,0xffff
    33d6:	50                   	push   ax
    33d7:	57                   	push   di
    33d8:	9a 73 22 08 34       	call   0x3408:0x2273
    33dd:	89 c7                	mov    di,ax
    33df:	8e c2                	mov    es,dx
    33e1:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    33e4:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    33e7:	8d be fa fd          	lea    di,[bp-0x206]
    33eb:	16                   	push   ss
    33ec:	57                   	push   di
    33ed:	8d be fa fe          	lea    di,[bp-0x106]
    33f1:	16                   	push   ss
    33f2:	57                   	push   di
    33f3:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    33f6:	06                   	push   es
    33f7:	57                   	push   di
    33f8:	9a 2a 51 ff ff       	call   0xffff:0x512a
    33fd:	83 c4 04             	add    sp,0x4
    3400:	8a 86 fc fe          	mov    al,BYTE PTR [bp-0x104]
    3404:	50                   	push   ax
    3405:	9a e9 18 15 34       	call   0x3415:0x18e9
    340a:	9a da 08 ff ff       	call   0xffff:0x8da
    340f:	bf 9c 33             	mov    di,0x339c
    3412:	9a 16 04 94 38       	call   0x3894:0x416
    3417:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    341a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    341d:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    3421:	b0 00                	mov    al,0x0
    3423:	7f 01                	jg     0x3426
    3425:	40                   	inc    ax
    3426:	8a d0                	mov    dl,al
    3428:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    342c:	b0 00                	mov    al,0x0
    342e:	7e 01                	jle    0x3431
    3430:	40                   	inc    ax
    3431:	22 c2                	and    al,dl
    3433:	08 c0                	or     al,al
    3435:	74 0d                	je     0x3444
    3437:	ff 76 fe             	push   WORD PTR [bp-0x2]
    343a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    343d:	06                   	push   es
    343e:	57                   	push   di
    343f:	9a 1e 2c 18 51       	call   0x5118:0x2c1e
    3444:	c9                   	leave
    3445:	ca 08 00             	retf   0x8
    3448:	07                   	pop    es
    3449:	54                   	push   sp
    344a:	61                   	popa
    344b:	75 78                	jne    0x34c5
    344d:	54                   	push   sp
    344e:	56                   	push   si
    344f:	41                   	inc    cx
    3450:	00 00                	add    BYTE PTR [bx+si],al
    3452:	c8 42 06 56          	enter  0x642,0x56
    3456:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3458:	74 65                	je     0x34bf
    345a:	73 04                	jae    0x3460
    345c:	50                   	push   ax
    345d:	72 69                	jb     0x34c8
    345f:	78 10                	js     0x3471
    3461:	56                   	push   si
    3462:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3464:	74 65                	je     0x34cb
    3466:	73 53                	jae    0x34bb
    3468:	6f                   	outs   dx,WORD PTR ds:[si]
    3469:	6c                   	ins    BYTE PTR es:[di],dx
    346a:	64 65 65 73 51       	fs gs gs jae 0x34c0
    346f:	74 65                	je     0x34d6
    3471:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    3474:	6e                   	outs   dx,BYTE PTR ds:[si]
    3475:	74 65                	je     0x34dc
    3477:	73 53                	jae    0x34cc
    3479:	6f                   	outs   dx,WORD PTR ds:[si]
    347a:	6c                   	ins    BYTE PTR es:[di],dx
    347b:	64 65 65 73 50       	fs gs gs jae 0x34d0
    3480:	72 69                	jb     0x34eb
    3482:	78 0c                	js     0x3490
    3484:	56                   	push   si
    3485:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3487:	74 65                	je     0x34ee
    3489:	73 53                	jae    0x34de
    348b:	70 65                	jo     0x34f2
    348d:	51                   	push   cx
    348e:	74 65                	je     0x34f5
    3490:	0d 56 65             	or     ax,0x6556
    3493:	6e                   	outs   dx,BYTE PTR ds:[si]
    3494:	74 65                	je     0x34fb
    3496:	73 53                	jae    0x34eb
    3498:	70 65                	jo     0x34ff
    349a:	50                   	push   ax
    349b:	72 69                	jb     0x3506
    349d:	78 11                	js     0x34b0
    349f:	43                   	inc    bx
    34a0:	68 69 66             	push   0x6669
    34a3:	66 72 65             	data32 jb 0x350b
    34a6:	41                   	inc    cx
    34a7:	66 66 61             	data32 popad
    34aa:	69 72 65 54 54       	imul   si,WORD PTR [bp+si+0x65],0x5454
    34af:	43                   	inc    bx
    34b0:	07                   	pop    es
    34b1:	43                   	inc    bx
    34b2:	6c                   	ins    BYTE PTR es:[di],dx
    34b3:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    34b8:	11 56 61             	adc    WORD PTR [bp+0x61],dx
    34bb:	72 43                	jb     0x3500
    34bd:	6f                   	outs   dx,WORD PTR ds:[si]
    34be:	6d                   	ins    WORD PTR es:[di],dx
    34bf:	70 74                	jo     0x3535
    34c1:	65 73 43             	gs jae 0x3507
    34c4:	6c                   	ins    BYTE PTR es:[di],dx
    34c5:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    34ca:	11 52 65             	adc    WORD PTR [bp+si+0x65],dx
    34cd:	67 6c                	ins    BYTE PTR es:[edi],dx
    34cf:	65 6d                	gs ins WORD PTR es:[di],dx
    34d1:	65 6e                	outs   dx,BYTE PTR gs:[si]
    34d3:	74 73                	je     0x3548
    34d5:	43                   	inc    bx
    34d6:	6c                   	ins    BYTE PTR es:[di],dx
    34d7:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    34dc:	0b 53 75             	or     dx,WORD PTR [bp+di+0x75]
    34df:	62 76 65             	bound  si,DWORD PTR [bp+0x65]
    34e2:	6e                   	outs   dx,BYTE PTR ds:[si]
    34e3:	74 69                	je     0x354e
    34e5:	6f                   	outs   dx,WORD PTR ds:[si]
    34e6:	6e                   	outs   dx,BYTE PTR ds:[si]
    34e7:	73 0a                	jae    0x34f3
    34e9:	54                   	push   sp
    34ea:	72 65                	jb     0x3551
    34ec:	73 6f                	jae    0x355d
    34ee:	72 65                	jb     0x3555
    34f0:	72 69                	jb     0x355b
    34f2:	65 0d 54 61          	gs or  ax,0x6154
    34f6:	75 78                	jne    0x3570
    34f8:	50                   	push   ax
    34f9:	6c                   	ins    BYTE PTR es:[di],dx
    34fa:	61                   	popa
    34fb:	63 65 6d             	arpl   WORD PTR [di+0x6d],sp
    34fe:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3500:	74 10                	je     0x3512
    3502:	50                   	push   ax
    3503:	72 6f                	jb     0x3574
    3505:	64 75 69             	fs jne 0x3571
    3508:	74 46                	je     0x3550
    350a:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    350f:	69 65 72 13 50       	imul   sp,WORD PTR [di+0x72],0x5013
    3514:	72 6f                	jb     0x3585
    3516:	64 75 69             	fs jne 0x3582
    3519:	74 73                	je     0x358e
    351b:	4f                   	dec    di
    351c:	75 43                	jne    0x3561
    351e:	68 61 72             	push   0x7261
    3521:	67 65 73 45          	addr32 gs jae 0x356a
    3525:	78 00                	js     0x3527
    3527:	00 00                	add    BYTE PTR [bx+si],al
    3529:	00 0e 50 72          	add    BYTE PTR ds:0x7250,cl
    352d:	6f                   	outs   dx,WORD PTR ds:[si]
    352e:	64 75 69             	fs jne 0x359a
    3531:	74 73                	je     0x35a6
    3533:	45                   	inc    bp
    3534:	78 63                	js     0x3599
    3536:	65 70 74             	gs jo  0x35ad
    3539:	0d 43 68             	or     ax,0x6843
    353c:	61                   	popa
    353d:	72 67                	jb     0x35a6
    353f:	65 73 45             	gs jae 0x3587
    3542:	78 63                	js     0x35a7
    3544:	65 70 74             	gs jo  0x35bb
    3547:	0d 52 65             	or     ax,0x6552
    354a:	6d                   	ins    WORD PTR es:[di],dx
    354b:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    354e:	72 73                	jb     0x35c3
    3550:	41                   	inc    cx
    3551:	73 73                	jae    0x35c6
    3553:	75 72                	jne    0x35c7
    3555:	13 43 6f             	adc    ax,WORD PTR [bp+di+0x6f]
    3558:	6e                   	outs   dx,BYTE PTR ds:[si]
    3559:	73 6f                	jae    0x35ca
    355b:	6d                   	ins    WORD PTR es:[di],dx
    355c:	6d                   	ins    WORD PTR es:[di],dx
    355d:	61                   	popa
    355e:	74 69                	je     0x35c9
    3560:	6f                   	outs   dx,WORD PTR ds:[si]
    3561:	6e                   	outs   dx,BYTE PTR ds:[si]
    3562:	4d                   	dec    bp
    3563:	61                   	popa
    3564:	74 69                	je     0x35cf
    3566:	65 72 65             	gs jb  0x35ce
    3569:	13 4d 61             	adc    cx,WORD PTR [di+0x61]
    356c:	74 69                	je     0x35d7
    356e:	65 72 65             	gs jb  0x35d6
    3571:	43                   	inc    bx
    3572:	6f                   	outs   dx,WORD PTR ds:[si]
    3573:	6e                   	outs   dx,BYTE PTR ds:[si]
    3574:	73 6f                	jae    0x35e5
    3576:	6d                   	ins    WORD PTR es:[di],dx
    3577:	6d                   	ins    WORD PTR es:[di],dx
    3578:	65 65 54             	gs gs push sp
    357b:	54                   	push   sp
    357c:	43                   	inc    bx
    357d:	0c 46                	or     al,0x46
    357f:	6f                   	outs   dx,WORD PTR ds:[si]
    3580:	75 72                	jne    0x35f4
    3582:	6e                   	outs   dx,BYTE PTR ds:[si]
    3583:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    3588:	72 73                	jb     0x35fd
    358a:	11 56 61             	adc    WORD PTR [bp+0x61],dx
    358d:	72 43                	jb     0x35d2
    358f:	6f                   	outs   dx,WORD PTR ds:[si]
    3590:	6d                   	ins    WORD PTR es:[di],dx
    3591:	70 74                	jo     0x3607
    3593:	65 73 46             	gs jae 0x35dc
    3596:	6f                   	outs   dx,WORD PTR ds:[si]
    3597:	75 72                	jne    0x360b
    3599:	6e                   	outs   dx,BYTE PTR ds:[si]
    359a:	69 73 10 50 61       	imul   si,WORD PTR [bp+di+0x10],0x6150
    359f:	69 65 6d 65 6e       	imul   sp,WORD PTR [di+0x6d],0x6e65
    35a4:	74 73                	je     0x3619
    35a6:	46                   	inc    si
    35a7:	6f                   	outs   dx,WORD PTR ds:[si]
    35a8:	75 72                	jne    0x361c
    35aa:	6e                   	outs   dx,BYTE PTR ds:[si]
    35ab:	69 73 0f 44 65       	imul   si,WORD PTR [bp+di+0xf],0x6544
    35b0:	70 65                	jo     0x3617
    35b2:	6e                   	outs   dx,BYTE PTR ds:[si]
    35b3:	73 65                	jae    0x361a
    35b5:	73 51                	jae    0x3608
    35b7:	75 61                	jne    0x361a
    35b9:	6c                   	ins    BYTE PTR es:[di],dx
    35ba:	69 74 65 0a 51       	imul   si,WORD PTR [si+0x65],0x510a
    35bf:	75 61                	jne    0x3622
    35c1:	6c                   	ins    BYTE PTR es:[di],dx
    35c2:	69 74 65 54 54       	imul   si,WORD PTR [si+0x65],0x5454
    35c7:	43                   	inc    bx
    35c8:	09 50 75             	or     WORD PTR [bx+si+0x75],dx
    35cb:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
    35ce:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    35d1:	65 11 41 63          	adc    WORD PTR gs:[bx+di+0x63],ax
    35d5:	74 69                	je     0x3640
    35d7:	6f                   	outs   dx,WORD PTR ds:[si]
    35d8:	6e                   	outs   dx,BYTE PTR ds:[si]
    35d9:	43                   	inc    bx
    35da:	6f                   	outs   dx,WORD PTR ds:[si]
    35db:	6d                   	ins    WORD PTR es:[di],dx
    35dc:	6d                   	ins    WORD PTR es:[di],dx
    35dd:	65 72 63             	gs jb  0x3643
    35e0:	69 61 6c 65 11       	imul   sp,WORD PTR [bx+di+0x6c],0x1165
    35e5:	50                   	push   ax
    35e6:	75 62                	jne    0x364a
    35e8:	45                   	inc    bp
    35e9:	74 41                	je     0x362c
    35eb:	63 74 69             	arpl   WORD PTR [si+0x69],si
    35ee:	6f                   	outs   dx,WORD PTR ds:[si]
    35ef:	6e                   	outs   dx,BYTE PTR ds:[si]
    35f0:	43                   	inc    bx
    35f1:	6f                   	outs   dx,WORD PTR ds:[si]
    35f2:	6d                   	ins    WORD PTR es:[di],dx
    35f3:	54                   	push   sp
    35f4:	54                   	push   sp
    35f5:	43                   	inc    bx
    35f6:	06                   	push   es
    35f7:	45                   	inc    bp
    35f8:	74 75                	je     0x366f
    35fa:	64 65 73 09          	fs gs jae 0x3607
    35fe:	45                   	inc    bp
    35ff:	74 75                	je     0x3676
    3601:	64 65 73 54          	fs gs jae 0x3659
    3605:	54                   	push   sp
    3606:	43                   	inc    bx
    3607:	11 4d 61             	adc    WORD PTR [di+0x61],cx
    360a:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    360f:	76 72                	jbe    0x3683
    3611:	65 44                	gs inc sp
    3613:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    3618:	65 0e                	gs push cs
    361a:	52                   	push   dx
    361b:	65 6d                	gs ins WORD PTR es:[di],dx
    361d:	75 6e                	jne    0x368d
    361f:	65 72 61             	gs jb  0x3683
    3622:	74 69                	je     0x368d
    3624:	6f                   	outs   dx,WORD PTR ds:[si]
    3625:	6e                   	outs   dx,BYTE PTR ds:[si]
    3626:	46                   	inc    si
    3627:	56                   	push   si
    3628:	12 52 65             	adc    dl,BYTE PTR [bp+si+0x65]
    362b:	6d                   	ins    WORD PTR es:[di],dx
    362c:	75 6e                	jne    0x369c
    362e:	65 72 61             	gs jb  0x3692
    3631:	74 69                	je     0x369c
    3633:	6f                   	outs   dx,WORD PTR ds:[si]
    3634:	6e                   	outs   dx,BYTE PTR ds:[si]
    3635:	43                   	inc    bx
    3636:	61                   	popa
    3637:	64 72 65             	fs jb  0x369f
    363a:	73 0c                	jae    0x3648
    363c:	43                   	inc    bx
    363d:	6f                   	outs   dx,WORD PTR ds:[si]
    363e:	75 74                	jne    0x36b4
    3640:	4c                   	dec    sp
    3641:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    3646:	69 65 0c 43 6f       	imul   sp,WORD PTR [di+0xc],0x6f43
    364b:	75 74                	jne    0x36c1
    364d:	45                   	inc    bp
    364e:	6d                   	ins    WORD PTR es:[di],dx
    364f:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    3652:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    3655:	0d 43 6f             	or     ax,0x6f43
    3658:	75 74                	jne    0x36ce
    365a:	46                   	inc    si
    365b:	6f                   	outs   dx,WORD PTR ds:[si]
    365c:	72 6d                	jb     0x36cb
    365e:	61                   	popa
    365f:	74 69                	je     0x36ca
    3661:	6f                   	outs   dx,WORD PTR ds:[si]
    3662:	6e                   	outs   dx,BYTE PTR ds:[si]
    3663:	08 53 61             	or     BYTE PTR [bp+di+0x61],dl
    3666:	6c                   	ins    BYTE PTR es:[di],dx
    3667:	61                   	popa
    3668:	69 72 65 73 08       	imul   si,WORD PTR [bp+si+0x65],0x873
    366d:	51                   	push   cx
    366e:	74 65                	je     0x36d5
    3670:	53                   	push   bx
    3671:	74 6f                	je     0x36e2
    3673:	63 6b 0e             	arpl   WORD PTR [bp+di+0xe],bp
    3676:	43                   	inc    bx
    3677:	6f                   	outs   dx,WORD PTR ds:[si]
    3678:	75 74                	jne    0x36ee
    367a:	55                   	push   bp
    367b:	6e                   	outs   dx,BYTE PTR ds:[si]
    367c:	69 74 65 53 74       	imul   si,WORD PTR [si+0x65],0x7453
    3681:	6f                   	outs   dx,WORD PTR ds:[si]
    3682:	63 6b 0a             	arpl   WORD PTR [bp+di+0xa],bp
    3685:	46                   	inc    si
    3686:	72 61                	jb     0x36e9
    3688:	69 73 53 74 6f       	imul   si,WORD PTR [bp+di+0x53],0x6f74
    368d:	63 6b 14             	arpl   WORD PTR [bp+di+0x14],bp
    3690:	43                   	inc    bx
    3691:	6f                   	outs   dx,WORD PTR ds:[si]
    3692:	75 74                	jne    0x3708
    3694:	73 46                	jae    0x36dc
    3696:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
    369b:	72 6f                	jb     0x370c
    369d:	64 75 63             	fs jne 0x3703
    36a0:	74 69                	je     0x370b
    36a2:	6f                   	outs   dx,WORD PTR ds:[si]
    36a3:	6e                   	outs   dx,BYTE PTR ds:[si]
    36a4:	0d 43 6f             	or     ax,0x6f43
    36a7:	75 74                	jne    0x371d
    36a9:	73 46                	jae    0x36f1
    36ab:	69 78 65 73 54       	imul   di,WORD PTR [bx+si+0x65],0x5473
    36b0:	54                   	push   sp
    36b1:	43                   	inc    bx
    36b2:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
    36b5:	70 61                	jo     0x3718
    36b7:	72 61                	jb     0x371a
    36b9:	74 69                	je     0x3724
    36bb:	6f                   	outs   dx,WORD PTR ds:[si]
    36bc:	6e                   	outs   dx,BYTE PTR ds:[si]
    36bd:	73 11                	jae    0x36d0
    36bf:	45                   	inc    bp
    36c0:	6e                   	outs   dx,BYTE PTR ds:[si]
    36c1:	74 72                	je     0x3735
    36c3:	65 74 69             	gs je  0x372f
    36c6:	65 6e                	outs   dx,BYTE PTR gs:[si]
    36c8:	4d                   	dec    bp
    36c9:	61                   	popa
    36ca:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    36cd:	6e                   	outs   dx,BYTE PTR ds:[si]
    36ce:	65 73 10             	gs jae 0x36e1
    36d1:	41                   	inc    cx
    36d2:	75 74                	jne    0x3748
    36d4:	72 65                	jb     0x373b
    36d6:	73 43                	jae    0x371b
    36d8:	68 61 72             	push   0x7261
    36db:	67 65 73 54          	addr32 gs jae 0x3733
    36df:	54                   	push   sp
    36e0:	43                   	inc    bx
    36e1:	0f                   	movmskps esi,(bad)
    36e2:	50                   	push   ax
    36e3:	72 69                	jb     0x374e
    36e5:	6d                   	ins    WORD PTR es:[di],dx
    36e6:	65 73 41             	gs jae 0x372a
    36e9:	73 73                	jae    0x375e
    36eb:	75 72                	jne    0x375f
    36ed:	61                   	popa
    36ee:	6e                   	outs   dx,BYTE PTR ds:[si]
    36ef:	63 65 0d             	arpl   WORD PTR [di+0xd],sp
    36f2:	44                   	inc    sp
    36f3:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    36f7:	76 65                	jbe    0x375e
    36f9:	72 74                	jb     0x376f
    36fb:	41                   	inc    cx
    36fc:	75 74                	jne    0x3772
    36fe:	6f                   	outs   dx,WORD PTR ds:[si]
    36ff:	11 54 61             	adc    WORD PTR [si+0x61],dx
    3702:	75 78                	jne    0x377c
    3704:	44                   	inc    sp
    3705:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    3709:	76 65                	jbe    0x3770
    370b:	72 74                	jb     0x3781
    370d:	41                   	inc    cx
    370e:	75 74                	jne    0x3784
    3710:	6f                   	outs   dx,WORD PTR ds:[si]
    3711:	0e                   	push   cs
    3712:	44                   	inc    sp
    3713:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    3717:	76 65                	jbe    0x377e
    3719:	72 74                	jb     0x378f
    371b:	4e                   	dec    si
    371c:	41                   	inc    cx
    371d:	75 74                	jne    0x3793
    371f:	6f                   	outs   dx,WORD PTR ds:[si]
    3720:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
    3723:	75 78                	jne    0x379d
    3725:	44                   	inc    sp
    3726:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    372a:	76 65                	jbe    0x3791
    372c:	72 74                	jb     0x37a2
    372e:	4e                   	dec    si
    372f:	41                   	inc    cx
    3730:	75 74                	jne    0x37a6
    3732:	6f                   	outs   dx,WORD PTR ds:[si]
    3733:	07                   	pop    es
    3734:	45                   	inc    bp
    3735:	6d                   	ins    WORD PTR es:[di],dx
    3736:	70 72                	jo     0x37aa
    3738:	75 6e                	jne    0x37a8
    373a:	74 0b                	je     0x3747
    373c:	54                   	push   sp
    373d:	61                   	popa
    373e:	75 78                	jne    0x37b8
    3740:	45                   	inc    bp
    3741:	6d                   	ins    WORD PTR es:[di],dx
    3742:	70 72                	jo     0x37b6
    3744:	75 6e                	jne    0x37b4
    3746:	74 12                	je     0x375a
    3748:	43                   	inc    bx
    3749:	68 61 72             	push   0x7261
    374c:	67 65 73 46          	addr32 gs jae 0x3796
    3750:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    3755:	69 65 72 65 73       	imul   sp,WORD PTR [di+0x72],0x7365
    375a:	05 49 6d             	add    ax,0x6d49
    375d:	70 6f                	jo     0x37ce
    375f:	74 09                	je     0x376a
    3761:	49                   	dec    cx
    3762:	6d                   	ins    WORD PTR es:[di],dx
    3763:	70 6f                	jo     0x37d4
    3765:	74 50                	je     0x37b7
    3767:	72 65                	jb     0x37ce
    3769:	63 0c                	arpl   WORD PTR [si],cx
    376b:	54                   	push   sp
    376c:	56                   	push   si
    376d:	41                   	inc    cx
    376e:	43                   	inc    bx
    376f:	6f                   	outs   dx,WORD PTR ds:[si]
    3770:	6c                   	ins    BYTE PTR es:[di],dx
    3771:	6c                   	ins    BYTE PTR es:[di],dx
    3772:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
    3776:	65 0d 54 56          	gs or  ax,0x5654
    377a:	41                   	inc    cx
    377b:	44                   	inc    sp
    377c:	65 64 75 63          	gs fs jne 0x37e3
    3780:	74 69                	je     0x37eb
    3782:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    3785:	0d 54 56             	or     ax,0x5654
    3788:	41                   	inc    cx
    3789:	61                   	popa
    378a:	44                   	inc    sp
    378b:	65 63 61 69          	arpl   WORD PTR gs:[bx+di+0x69],sp
    378f:	73 73                	jae    0x3804
    3791:	65 72 10             	gs jb  0x37a4
    3794:	56                   	push   si
    3795:	61                   	popa
    3796:	72 69                	jb     0x3801
    3798:	61                   	popa
    3799:	74 69                	je     0x3804
    379b:	6f                   	outs   dx,WORD PTR ds:[si]
    379c:	6e                   	outs   dx,BYTE PTR ds:[si]
    379d:	43                   	inc    bx
    379e:	61                   	popa
    379f:	70 69                	jo     0x380a
    37a1:	74 61                	je     0x3804
    37a3:	6c                   	ins    BYTE PTR es:[di],dx
    37a4:	13 41 75             	adc    ax,WORD PTR [bx+di+0x75]
    37a7:	67 6d                	ins    WORD PTR es:[edi],dx
    37a9:	65 6e                	outs   dx,BYTE PTR gs:[si]
    37ab:	74 61                	je     0x380e
    37ad:	74 69                	je     0x3818
    37af:	6f                   	outs   dx,WORD PTR ds:[si]
    37b0:	6e                   	outs   dx,BYTE PTR ds:[si]
    37b1:	43                   	inc    bx
    37b2:	61                   	popa
    37b3:	70 69                	jo     0x381e
    37b5:	74 61                	je     0x3818
    37b7:	6c                   	ins    BYTE PTR es:[di],dx
    37b8:	10 52 65             	adc    BYTE PTR [bp+si+0x65],dl
    37bb:	64 75 63             	fs jne 0x3821
    37be:	74 69                	je     0x3829
    37c0:	6f                   	outs   dx,WORD PTR ds:[si]
    37c1:	6e                   	outs   dx,BYTE PTR ds:[si]
    37c2:	43                   	inc    bx
    37c3:	61                   	popa
    37c4:	70 69                	jo     0x382f
    37c6:	74 61                	je     0x3829
    37c8:	6c                   	ins    BYTE PTR es:[di],dx
    37c9:	10 4e 6f             	adc    BYTE PTR [bp+0x6f],cl
    37cc:	75 76                	jne    0x3844
    37ce:	65 61                	gs popa
    37d0:	75 78                	jne    0x384a
    37d2:	45                   	inc    bp
    37d3:	6d                   	ins    WORD PTR es:[di],dx
    37d4:	70 72                	jo     0x3848
    37d6:	75 6e                	jne    0x3846
    37d8:	74 73                	je     0x384d
    37da:	15 52 65             	adc    ax,0x6552
    37dd:	6d                   	ins    WORD PTR es:[di],dx
    37de:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    37e1:	72 73                	jb     0x3856
    37e3:	65 6d                	gs ins WORD PTR es:[di],dx
    37e5:	65 6e                	outs   dx,BYTE PTR gs:[si]
    37e7:	74 45                	je     0x382e
    37e9:	6d                   	ins    WORD PTR es:[di],dx
    37ea:	70 72                	jo     0x385e
    37ec:	75 6e                	jne    0x385c
    37ee:	74 73                	je     0x3863
    37f0:	0d 41 63             	or     ax,0x6341
    37f3:	68 61 74             	push   0x7461
    37f6:	4d                   	dec    bp
    37f7:	61                   	popa
    37f8:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    37fb:	6e                   	outs   dx,BYTE PTR ds:[si]
    37fc:	65 73 10             	gs jae 0x380f
    37ff:	43                   	inc    bx
    3800:	6f                   	outs   dx,WORD PTR ds:[si]
    3801:	75 74                	jne    0x3877
    3803:	55                   	push   bp
    3804:	6e                   	outs   dx,BYTE PTR ds:[si]
    3805:	69 74 65 4d 61       	imul   si,WORD PTR [si+0x65],0x614d
    380a:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    380d:	6e                   	outs   dx,BYTE PTR ds:[si]
    380e:	65 12 49 6e          	adc    cl,BYTE PTR gs:[bx+di+0x6e]
    3812:	76 65                	jbe    0x3879
    3814:	73 74                	jae    0x388a
    3816:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    381b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    381d:	74 73                	je     0x3892
    381f:	54                   	push   sp
    3820:	54                   	push   sp
    3821:	43                   	inc    bx
    3822:	08 43 65             	or     BYTE PTR [bp+di+0x65],al
    3825:	73 73                	jae    0x389a
    3827:	69 6f 6e 73 0b       	imul   bp,WORD PTR [bx+0x6e],0xb73
    382c:	43                   	inc    bx
    382d:	65 73 73             	gs jae 0x38a3
    3830:	69 6f 6e 73 54       	imul   bp,WORD PTR [bx+0x6e],0x5473
    3835:	54                   	push   sp
    3836:	43                   	inc    bx
    3837:	0d 44 69             	or     ax,0x6944
    383a:	73 74                	jae    0x38b0
    383c:	72 69                	jb     0x38a7
    383e:	62 75 74             	bound  si,DWORD PTR [di+0x74]
    3841:	69 6f 6e 73 08       	imul   bp,WORD PTR [bx+0x6e],0x873
    3846:	44                   	inc    sp
    3847:	65 70 65             	gs jo  0x38af
    384a:	6e                   	outs   dx,BYTE PTR ds:[si]
    384b:	73 65                	jae    0x38b2
    384d:	73 08                	jae    0x3857
    384f:	52                   	push   dx
    3850:	65 63 65 74          	arpl   WORD PTR gs:[di+0x74],sp
    3854:	74 65                	je     0x38bb
    3856:	73 0d                	jae    0x3865
    3858:	56                   	push   si
    3859:	61                   	popa
    385a:	72 54                	jb     0x38b0
    385c:	72 65                	jb     0x38c3
    385e:	73 6f                	jae    0x38cf
    3860:	72 65                	jb     0x38c7
    3862:	72 69                	jb     0x38cd
    3864:	65 13 53 6f          	adc    dx,WORD PTR gs:[bp+di+0x6f]
    3868:	6c                   	ins    BYTE PTR es:[di],dx
    3869:	64 65 41             	fs gs inc cx
    386c:	6e                   	outs   dx,BYTE PTR ds:[si]
    386d:	74 65                	je     0x38d4
    386f:	72 69                	jb     0x38da
    3871:	65 75 72             	gs jne 0x38e6
    3874:	54                   	push   sp
    3875:	72 65                	jb     0x38dc
    3877:	73 6f                	jae    0x38e8
    3879:	11 53 69             	adc    WORD PTR [bp+di+0x69],dx
    387c:	74 75                	je     0x38f3
    387e:	61                   	popa
    387f:	54                   	push   sp
    3880:	72 65                	jb     0x38e7
    3882:	73 6f                	jae    0x38f3
    3884:	72 46                	jb     0x38cc
    3886:	69 6e 50 65 72       	imul   bp,WORD PTR [bp+0x50],0x7265
    388b:	55                   	push   bp
    388c:	89 e5                	mov    bp,sp
    388e:	b8 ca 01             	mov    ax,0x1ca
    3891:	9a 44 04 d4 38       	call   0x38d4:0x444
    3896:	81 ec ca 01          	sub    sp,0x1ca
    389a:	bf 48 34             	mov    di,0x3448
    389d:	0e                   	push   cs
    389e:	57                   	push   di
    389f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38a2:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    38a7:	06                   	push   es
    38a8:	57                   	push   di
    38a9:	9a 9b 3b 0d 39       	call   0x390d:0x3b9b
    38ae:	89 c7                	mov    di,ax
    38b0:	8e c2                	mov    es,dx
    38b2:	06                   	push   es
    38b3:	57                   	push   di
    38b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    38b7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    38bb:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    38bf:	90                   	nop
    38c0:	9b                   	fwait
    38c1:	9b 2e d9 06 50 34    	fld    DWORD PTR cs:0x3450
    38c7:	9b dc 46 f8          	fadd   QWORD PTR [bp-0x8]
    38cb:	9b 2e d9 06 50 34    	fld    DWORD PTR cs:0x3450
    38d1:	9a b2 04 ed 38       	call   0x38ed:0x4b2
    38d6:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    38da:	90                   	nop
    38db:	9b                   	fwait
    38dc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    38df:	ff 76 0a             	push   WORD PTR [bp+0xa]
    38e2:	bf 38 01             	mov    di,0x138
    38e5:	b8 ff ff             	mov    ax,0xffff
    38e8:	50                   	push   ax
    38e9:	57                   	push   di
    38ea:	9a 73 22 6d 3d       	call   0x3d6d:0x2273
    38ef:	89 c7                	mov    di,ax
    38f1:	8e c2                	mov    es,dx
    38f3:	89 be bc fe          	mov    WORD PTR [bp-0x144],di
    38f7:	8c 86 be fe          	mov    WORD PTR [bp-0x142],es
    38fb:	bf 54 34             	mov    di,0x3454
    38fe:	0e                   	push   cs
    38ff:	57                   	push   di
    3900:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3903:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3908:	06                   	push   es
    3909:	57                   	push   di
    390a:	9a 9b 3b 40 39       	call   0x3940:0x3b9b
    390f:	89 c7                	mov    di,ax
    3911:	8e c2                	mov    es,dx
    3913:	06                   	push   es
    3914:	57                   	push   di
    3915:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3918:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    391c:	89 86 b8 fe          	mov    WORD PTR [bp-0x148],ax
    3920:	89 96 ba fe          	mov    WORD PTR [bp-0x146],dx
    3924:	9b db 86 b8 fe       	fild   DWORD PTR [bp-0x148]
    3929:	9b db be ae fe       	fstp   TBYTE PTR [bp-0x152]
    392e:	bf 5b 34             	mov    di,0x345b
    3931:	0e                   	push   cs
    3932:	57                   	push   di
    3933:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3936:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    393b:	06                   	push   es
    393c:	57                   	push   di
    393d:	9a 9b 3b 7e 39       	call   0x397e:0x3b9b
    3942:	89 c7                	mov    di,ax
    3944:	8e c2                	mov    es,dx
    3946:	06                   	push   es
    3947:	57                   	push   di
    3948:	26 c4 3d             	les    di,DWORD PTR es:[di]
    394b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    394f:	9b db ae ae fe       	fld    TBYTE PTR [bp-0x152]
    3954:	9b de c9             	fmulp  st(1),st
    3957:	83 ec 08             	sub    sp,0x8
    395a:	89 e3                	mov    bx,sp
    395c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3960:	90                   	nop
    3961:	9b                   	fwait
    3962:	9a a6 2f d6 39       	call   0x39d6:0x2fa6
    3967:	9b db be 96 fe       	fstp   TBYTE PTR [bp-0x16a]
    396c:	bf 60 34             	mov    di,0x3460
    396f:	0e                   	push   cs
    3970:	57                   	push   di
    3971:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3974:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3979:	06                   	push   es
    397a:	57                   	push   di
    397b:	9a 9b 3b b1 39       	call   0x39b1:0x3b9b
    3980:	89 c7                	mov    di,ax
    3982:	8e c2                	mov    es,dx
    3984:	06                   	push   es
    3985:	57                   	push   di
    3986:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3989:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    398d:	89 86 aa fe          	mov    WORD PTR [bp-0x156],ax
    3991:	89 96 ac fe          	mov    WORD PTR [bp-0x154],dx
    3995:	9b db 86 aa fe       	fild   DWORD PTR [bp-0x156]
    399a:	9b db be a0 fe       	fstp   TBYTE PTR [bp-0x160]
    399f:	bf 71 34             	mov    di,0x3471
    39a2:	0e                   	push   cs
    39a3:	57                   	push   di
    39a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39a7:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    39ac:	06                   	push   es
    39ad:	57                   	push   di
    39ae:	9a 9b 3b f7 39       	call   0x39f7:0x3b9b
    39b3:	89 c7                	mov    di,ax
    39b5:	8e c2                	mov    es,dx
    39b7:	06                   	push   es
    39b8:	57                   	push   di
    39b9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39bc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    39c0:	9b db ae a0 fe       	fld    TBYTE PTR [bp-0x160]
    39c5:	9b de c9             	fmulp  st(1),st
    39c8:	83 ec 08             	sub    sp,0x8
    39cb:	89 e3                	mov    bx,sp
    39cd:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    39d1:	90                   	nop
    39d2:	9b                   	fwait
    39d3:	9a a6 2f 4f 3a       	call   0x3a4f:0x2fa6
    39d8:	9b db ae 96 fe       	fld    TBYTE PTR [bp-0x16a]
    39dd:	9b de c1             	faddp  st(1),st
    39e0:	9b db be 7e fe       	fstp   TBYTE PTR [bp-0x182]
    39e5:	bf 83 34             	mov    di,0x3483
    39e8:	0e                   	push   cs
    39e9:	57                   	push   di
    39ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39ed:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    39f2:	06                   	push   es
    39f3:	57                   	push   di
    39f4:	9a 9b 3b 2a 3a       	call   0x3a2a:0x3b9b
    39f9:	89 c7                	mov    di,ax
    39fb:	8e c2                	mov    es,dx
    39fd:	06                   	push   es
    39fe:	57                   	push   di
    39ff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a02:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3a06:	89 86 92 fe          	mov    WORD PTR [bp-0x16e],ax
    3a0a:	89 96 94 fe          	mov    WORD PTR [bp-0x16c],dx
    3a0e:	9b db 86 92 fe       	fild   DWORD PTR [bp-0x16e]
    3a13:	9b db be 88 fe       	fstp   TBYTE PTR [bp-0x178]
    3a18:	bf 90 34             	mov    di,0x3490
    3a1b:	0e                   	push   cs
    3a1c:	57                   	push   di
    3a1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a20:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3a25:	06                   	push   es
    3a26:	57                   	push   di
    3a27:	9a 9b 3b 70 3a       	call   0x3a70:0x3b9b
    3a2c:	89 c7                	mov    di,ax
    3a2e:	8e c2                	mov    es,dx
    3a30:	06                   	push   es
    3a31:	57                   	push   di
    3a32:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a35:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3a39:	9b db ae 88 fe       	fld    TBYTE PTR [bp-0x178]
    3a3e:	9b de c9             	fmulp  st(1),st
    3a41:	83 ec 08             	sub    sp,0x8
    3a44:	89 e3                	mov    bx,sp
    3a46:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3a4a:	90                   	nop
    3a4b:	9b                   	fwait
    3a4c:	9a a6 2f c8 3a       	call   0x3ac8:0x2fa6
    3a51:	9b db ae 7e fe       	fld    TBYTE PTR [bp-0x182]
    3a56:	9b de c1             	faddp  st(1),st
    3a59:	9b db be 66 fe       	fstp   TBYTE PTR [bp-0x19a]
    3a5e:	bf 54 34             	mov    di,0x3454
    3a61:	0e                   	push   cs
    3a62:	57                   	push   di
    3a63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a66:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3a6b:	06                   	push   es
    3a6c:	57                   	push   di
    3a6d:	9a 9b 3b a3 3a       	call   0x3aa3:0x3b9b
    3a72:	89 c7                	mov    di,ax
    3a74:	8e c2                	mov    es,dx
    3a76:	06                   	push   es
    3a77:	57                   	push   di
    3a78:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a7b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3a7f:	89 86 7a fe          	mov    WORD PTR [bp-0x186],ax
    3a83:	89 96 7c fe          	mov    WORD PTR [bp-0x184],dx
    3a87:	9b db 86 7a fe       	fild   DWORD PTR [bp-0x186]
    3a8c:	9b db be 70 fe       	fstp   TBYTE PTR [bp-0x190]
    3a91:	bf 5b 34             	mov    di,0x345b
    3a94:	0e                   	push   cs
    3a95:	57                   	push   di
    3a96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a99:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    3a9e:	06                   	push   es
    3a9f:	57                   	push   di
    3aa0:	9a 9b 3b e9 3a       	call   0x3ae9:0x3b9b
    3aa5:	89 c7                	mov    di,ax
    3aa7:	8e c2                	mov    es,dx
    3aa9:	06                   	push   es
    3aaa:	57                   	push   di
    3aab:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3aae:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ab2:	9b db ae 70 fe       	fld    TBYTE PTR [bp-0x190]
    3ab7:	9b de c9             	fmulp  st(1),st
    3aba:	83 ec 08             	sub    sp,0x8
    3abd:	89 e3                	mov    bx,sp
    3abf:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3ac3:	90                   	nop
    3ac4:	9b                   	fwait
    3ac5:	9a a6 2f 41 3b       	call   0x3b41:0x2fa6
    3aca:	9b db ae 66 fe       	fld    TBYTE PTR [bp-0x19a]
    3acf:	9b de c1             	faddp  st(1),st
    3ad2:	9b db be 4e fe       	fstp   TBYTE PTR [bp-0x1b2]
    3ad7:	bf 60 34             	mov    di,0x3460
    3ada:	0e                   	push   cs
    3adb:	57                   	push   di
    3adc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3adf:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3ae4:	06                   	push   es
    3ae5:	57                   	push   di
    3ae6:	9a 9b 3b 1c 3b       	call   0x3b1c:0x3b9b
    3aeb:	89 c7                	mov    di,ax
    3aed:	8e c2                	mov    es,dx
    3aef:	06                   	push   es
    3af0:	57                   	push   di
    3af1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3af4:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3af8:	89 86 62 fe          	mov    WORD PTR [bp-0x19e],ax
    3afc:	89 96 64 fe          	mov    WORD PTR [bp-0x19c],dx
    3b00:	9b db 86 62 fe       	fild   DWORD PTR [bp-0x19e]
    3b05:	9b db be 58 fe       	fstp   TBYTE PTR [bp-0x1a8]
    3b0a:	bf 71 34             	mov    di,0x3471
    3b0d:	0e                   	push   cs
    3b0e:	57                   	push   di
    3b0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b12:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3b17:	06                   	push   es
    3b18:	57                   	push   di
    3b19:	9a 9b 3b 62 3b       	call   0x3b62:0x3b9b
    3b1e:	89 c7                	mov    di,ax
    3b20:	8e c2                	mov    es,dx
    3b22:	06                   	push   es
    3b23:	57                   	push   di
    3b24:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b27:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3b2b:	9b db ae 58 fe       	fld    TBYTE PTR [bp-0x1a8]
    3b30:	9b de c9             	fmulp  st(1),st
    3b33:	83 ec 08             	sub    sp,0x8
    3b36:	89 e3                	mov    bx,sp
    3b38:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3b3c:	90                   	nop
    3b3d:	9b                   	fwait
    3b3e:	9a a6 2f ba 3b       	call   0x3bba:0x2fa6
    3b43:	9b db ae 4e fe       	fld    TBYTE PTR [bp-0x1b2]
    3b48:	9b de c1             	faddp  st(1),st
    3b4b:	9b db be 36 fe       	fstp   TBYTE PTR [bp-0x1ca]
    3b50:	bf 83 34             	mov    di,0x3483
    3b53:	0e                   	push   cs
    3b54:	57                   	push   di
    3b55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b58:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3b5d:	06                   	push   es
    3b5e:	57                   	push   di
    3b5f:	9a 9b 3b 95 3b       	call   0x3b95:0x3b9b
    3b64:	89 c7                	mov    di,ax
    3b66:	8e c2                	mov    es,dx
    3b68:	06                   	push   es
    3b69:	57                   	push   di
    3b6a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b6d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3b71:	89 86 4a fe          	mov    WORD PTR [bp-0x1b6],ax
    3b75:	89 96 4c fe          	mov    WORD PTR [bp-0x1b4],dx
    3b79:	9b db 86 4a fe       	fild   DWORD PTR [bp-0x1b6]
    3b7e:	9b db be 40 fe       	fstp   TBYTE PTR [bp-0x1c0]
    3b83:	bf 90 34             	mov    di,0x3490
    3b86:	0e                   	push   cs
    3b87:	57                   	push   di
    3b88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b8b:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3b90:	06                   	push   es
    3b91:	57                   	push   di
    3b92:	9a 9b 3b 02 3c       	call   0x3c02:0x3b9b
    3b97:	89 c7                	mov    di,ax
    3b99:	8e c2                	mov    es,dx
    3b9b:	06                   	push   es
    3b9c:	57                   	push   di
    3b9d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ba0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ba4:	9b db ae 40 fe       	fld    TBYTE PTR [bp-0x1c0]
    3ba9:	9b de c9             	fmulp  st(1),st
    3bac:	83 ec 08             	sub    sp,0x8
    3baf:	89 e3                	mov    bx,sp
    3bb1:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3bb5:	90                   	nop
    3bb6:	9b                   	fwait
    3bb7:	9a a6 2f e0 3b       	call   0x3be0:0x2fa6
    3bbc:	9b db ae 36 fe       	fld    TBYTE PTR [bp-0x1ca]
    3bc1:	9b de c1             	faddp  st(1),st
    3bc4:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    3bc8:	90                   	nop
    3bc9:	9b 9b dd 46 e8       	fld    QWORD PTR [bp-0x18]
    3bce:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    3bd2:	83 ec 08             	sub    sp,0x8
    3bd5:	89 e3                	mov    bx,sp
    3bd7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3bdb:	90                   	nop
    3bdc:	9b                   	fwait
    3bdd:	9a a6 2f 7d 3d       	call   0x3d7d:0x2fa6
    3be2:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    3be6:	90                   	nop
    3be7:	9b                   	fwait
    3be8:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3beb:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    3bee:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    3bf1:	ff 76 e0             	push   WORD PTR [bp-0x20]
    3bf4:	bf 9e 34             	mov    di,0x349e
    3bf7:	0e                   	push   cs
    3bf8:	57                   	push   di
    3bf9:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3bfd:	06                   	push   es
    3bfe:	57                   	push   di
    3bff:	9a 9b 3b 1f 3c       	call   0x3c1f:0x3b9b
    3c04:	89 c7                	mov    di,ax
    3c06:	8e c2                	mov    es,dx
    3c08:	06                   	push   es
    3c09:	57                   	push   di
    3c0a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c0d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3c11:	bf b0 34             	mov    di,0x34b0
    3c14:	0e                   	push   cs
    3c15:	57                   	push   di
    3c16:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3c1a:	06                   	push   es
    3c1b:	57                   	push   di
    3c1c:	9a 9b 3b 48 3c       	call   0x3c48:0x3b9b
    3c21:	89 c7                	mov    di,ax
    3c23:	8e c2                	mov    es,dx
    3c25:	06                   	push   es
    3c26:	57                   	push   di
    3c27:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c2a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3c2e:	9b d9 e0             	fchs
    3c31:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    3c36:	bf b0 34             	mov    di,0x34b0
    3c39:	0e                   	push   cs
    3c3a:	57                   	push   di
    3c3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c3e:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    3c43:	06                   	push   es
    3c44:	57                   	push   di
    3c45:	9a 9b 3b 7f 3c       	call   0x3c7f:0x3b9b
    3c4a:	89 c7                	mov    di,ax
    3c4c:	8e c2                	mov    es,dx
    3c4e:	06                   	push   es
    3c4f:	57                   	push   di
    3c50:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c53:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3c57:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    3c5c:	9b de c1             	faddp  st(1),st
    3c5f:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    3c63:	90                   	nop
    3c64:	9b                   	fwait
    3c65:	ff 76 de             	push   WORD PTR [bp-0x22]
    3c68:	ff 76 dc             	push   WORD PTR [bp-0x24]
    3c6b:	ff 76 da             	push   WORD PTR [bp-0x26]
    3c6e:	ff 76 d8             	push   WORD PTR [bp-0x28]
    3c71:	bf b8 34             	mov    di,0x34b8
    3c74:	0e                   	push   cs
    3c75:	57                   	push   di
    3c76:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3c7a:	06                   	push   es
    3c7b:	57                   	push   di
    3c7c:	9a 9b 3b b6 3c       	call   0x3cb6:0x3b9b
    3c81:	89 c7                	mov    di,ax
    3c83:	8e c2                	mov    es,dx
    3c85:	06                   	push   es
    3c86:	57                   	push   di
    3c87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c8a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3c8e:	9b dd 46 e0          	fld    QWORD PTR [bp-0x20]
    3c92:	9b dc 46 d8          	fadd   QWORD PTR [bp-0x28]
    3c96:	9b dd 5e d0          	fstp   QWORD PTR [bp-0x30]
    3c9a:	90                   	nop
    3c9b:	9b                   	fwait
    3c9c:	ff 76 d6             	push   WORD PTR [bp-0x2a]
    3c9f:	ff 76 d4             	push   WORD PTR [bp-0x2c]
    3ca2:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    3ca5:	ff 76 d0             	push   WORD PTR [bp-0x30]
    3ca8:	bf ca 34             	mov    di,0x34ca
    3cab:	0e                   	push   cs
    3cac:	57                   	push   di
    3cad:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3cb1:	06                   	push   es
    3cb2:	57                   	push   di
    3cb3:	9a 9b 3b d7 3c       	call   0x3cd7:0x3b9b
    3cb8:	89 c7                	mov    di,ax
    3cba:	8e c2                	mov    es,dx
    3cbc:	06                   	push   es
    3cbd:	57                   	push   di
    3cbe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cc1:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3cc5:	bf dc 34             	mov    di,0x34dc
    3cc8:	0e                   	push   cs
    3cc9:	57                   	push   di
    3cca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ccd:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    3cd2:	06                   	push   es
    3cd3:	57                   	push   di
    3cd4:	9a 9b 3b 06 3d       	call   0x3d06:0x3b9b
    3cd9:	89 c7                	mov    di,ax
    3cdb:	8e c2                	mov    es,dx
    3cdd:	06                   	push   es
    3cde:	57                   	push   di
    3cdf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ce2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ce6:	9b dd 5e c8          	fstp   QWORD PTR [bp-0x38]
    3cea:	90                   	nop
    3ceb:	9b                   	fwait
    3cec:	ff 76 ce             	push   WORD PTR [bp-0x32]
    3cef:	ff 76 cc             	push   WORD PTR [bp-0x34]
    3cf2:	ff 76 ca             	push   WORD PTR [bp-0x36]
    3cf5:	ff 76 c8             	push   WORD PTR [bp-0x38]
    3cf8:	bf dc 34             	mov    di,0x34dc
    3cfb:	0e                   	push   cs
    3cfc:	57                   	push   di
    3cfd:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3d01:	06                   	push   es
    3d02:	57                   	push   di
    3d03:	9a 9b 3b 27 3d       	call   0x3d27:0x3b9b
    3d08:	89 c7                	mov    di,ax
    3d0a:	8e c2                	mov    es,dx
    3d0c:	06                   	push   es
    3d0d:	57                   	push   di
    3d0e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d11:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3d15:	bf e8 34             	mov    di,0x34e8
    3d18:	0e                   	push   cs
    3d19:	57                   	push   di
    3d1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d1d:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    3d22:	06                   	push   es
    3d23:	57                   	push   di
    3d24:	9a 9b 3b 4d 3d       	call   0x3d4d:0x3b9b
    3d29:	89 c7                	mov    di,ax
    3d2b:	8e c2                	mov    es,dx
    3d2d:	06                   	push   es
    3d2e:	57                   	push   di
    3d2f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d32:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3d36:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    3d3b:	bf f3 34             	mov    di,0x34f3
    3d3e:	0e                   	push   cs
    3d3f:	57                   	push   di
    3d40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d43:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    3d48:	06                   	push   es
    3d49:	57                   	push   di
    3d4a:	9a 9b 3b 9f 3d       	call   0x3d9f:0x3b9b
    3d4f:	89 c7                	mov    di,ax
    3d51:	8e c2                	mov    es,dx
    3d53:	06                   	push   es
    3d54:	57                   	push   di
    3d55:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d58:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3d5c:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    3d61:	9b de c9             	fmulp  st(1),st
    3d64:	9b 2e d9 06 50 34    	fld    DWORD PTR cs:0x3450
    3d6a:	9a b2 04 41 46       	call   0x4641:0x4b2
    3d6f:	83 ec 08             	sub    sp,0x8
    3d72:	89 e3                	mov    bx,sp
    3d74:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3d78:	90                   	nop
    3d79:	9b                   	fwait
    3d7a:	9a a6 2f d0 3e       	call   0x3ed0:0x2fa6
    3d7f:	9b dd 5e c0          	fstp   QWORD PTR [bp-0x40]
    3d83:	90                   	nop
    3d84:	9b                   	fwait
    3d85:	ff 76 c6             	push   WORD PTR [bp-0x3a]
    3d88:	ff 76 c4             	push   WORD PTR [bp-0x3c]
    3d8b:	ff 76 c2             	push   WORD PTR [bp-0x3e]
    3d8e:	ff 76 c0             	push   WORD PTR [bp-0x40]
    3d91:	bf 01 35             	mov    di,0x3501
    3d94:	0e                   	push   cs
    3d95:	57                   	push   di
    3d96:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3d9a:	06                   	push   es
    3d9b:	57                   	push   di
    3d9c:	9a 9b 3b c0 3d       	call   0x3dc0:0x3b9b
    3da1:	89 c7                	mov    di,ax
    3da3:	8e c2                	mov    es,dx
    3da5:	06                   	push   es
    3da6:	57                   	push   di
    3da7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3daa:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3dae:	bf 12 35             	mov    di,0x3512
    3db1:	0e                   	push   cs
    3db2:	57                   	push   di
    3db3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3db6:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    3dbb:	06                   	push   es
    3dbc:	57                   	push   di
    3dbd:	9a 9b 3b 3e 3e       	call   0x3e3e:0x3b9b
    3dc2:	89 c7                	mov    di,ax
    3dc4:	8e c2                	mov    es,dx
    3dc6:	06                   	push   es
    3dc7:	57                   	push   di
    3dc8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3dcb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3dcf:	9b dd 9e c0 fe       	fstp   QWORD PTR [bp-0x140]
    3dd4:	90                   	nop
    3dd5:	9b 9b dd 86 c0 fe    	fld    QWORD PTR [bp-0x140]
    3ddb:	9b 2e d8 1e 26 35    	fcomp  DWORD PTR cs:0x3526
    3de1:	9b dd be ba fe       	fstsw  WORD PTR [bp-0x146]
    3de6:	90                   	nop
    3de7:	9b                   	fwait
    3de8:	8a a6 bb fe          	mov    ah,BYTE PTR [bp-0x145]
    3dec:	9e                   	sahf
    3ded:	76 1a                	jbe    0x3e09
    3def:	9b dd 86 c0 fe       	fld    QWORD PTR [bp-0x140]
    3df4:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    3df8:	90                   	nop
    3df9:	9b                   	fwait
    3dfa:	9b 2e d9 06 26 35    	fld    DWORD PTR cs:0x3526
    3e00:	9b dd 9e 48 ff       	fstp   QWORD PTR [bp-0xb8]
    3e05:	90                   	nop
    3e06:	9b                   	fwait
    3e07:	eb 1b                	jmp    0x3e24
    3e09:	9b dd 86 c0 fe       	fld    QWORD PTR [bp-0x140]
    3e0e:	9b d9 e0             	fchs
    3e11:	9b dd 9e 48 ff       	fstp   QWORD PTR [bp-0xb8]
    3e16:	90                   	nop
    3e17:	9b                   	fwait
    3e18:	9b 2e d9 06 26 35    	fld    DWORD PTR cs:0x3526
    3e1e:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    3e22:	90                   	nop
    3e23:	9b                   	fwait
    3e24:	ff 76 be             	push   WORD PTR [bp-0x42]
    3e27:	ff 76 bc             	push   WORD PTR [bp-0x44]
    3e2a:	ff 76 ba             	push   WORD PTR [bp-0x46]
    3e2d:	ff 76 b8             	push   WORD PTR [bp-0x48]
    3e30:	bf 2a 35             	mov    di,0x352a
    3e33:	0e                   	push   cs
    3e34:	57                   	push   di
    3e35:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3e39:	06                   	push   es
    3e3a:	57                   	push   di
    3e3b:	9a 9b 3b 6b 3e       	call   0x3e6b:0x3b9b
    3e40:	89 c7                	mov    di,ax
    3e42:	8e c2                	mov    es,dx
    3e44:	06                   	push   es
    3e45:	57                   	push   di
    3e46:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e49:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3e4d:	ff b6 4e ff          	push   WORD PTR [bp-0xb2]
    3e51:	ff b6 4c ff          	push   WORD PTR [bp-0xb4]
    3e55:	ff b6 4a ff          	push   WORD PTR [bp-0xb6]
    3e59:	ff b6 48 ff          	push   WORD PTR [bp-0xb8]
    3e5d:	bf 39 35             	mov    di,0x3539
    3e60:	0e                   	push   cs
    3e61:	57                   	push   di
    3e62:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3e66:	06                   	push   es
    3e67:	57                   	push   di
    3e68:	9a 9b 3b 88 3e       	call   0x3e88:0x3b9b
    3e6d:	89 c7                	mov    di,ax
    3e6f:	8e c2                	mov    es,dx
    3e71:	06                   	push   es
    3e72:	57                   	push   di
    3e73:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e76:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3e7a:	bf 47 35             	mov    di,0x3547
    3e7d:	0e                   	push   cs
    3e7e:	57                   	push   di
    3e7f:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3e83:	06                   	push   es
    3e84:	57                   	push   di
    3e85:	9a 9b 3b af 3e       	call   0x3eaf:0x3b9b
    3e8a:	89 c7                	mov    di,ax
    3e8c:	8e c2                	mov    es,dx
    3e8e:	06                   	push   es
    3e8f:	57                   	push   di
    3e90:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e93:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e97:	9b dd 5e b0          	fstp   QWORD PTR [bp-0x50]
    3e9b:	90                   	nop
    3e9c:	9b                   	fwait
    3e9d:	bf 55 35             	mov    di,0x3555
    3ea0:	0e                   	push   cs
    3ea1:	57                   	push   di
    3ea2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ea5:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3eaa:	06                   	push   es
    3eab:	57                   	push   di
    3eac:	9a 9b 3b e9 3e       	call   0x3ee9:0x3b9b
    3eb1:	89 c7                	mov    di,ax
    3eb3:	8e c2                	mov    es,dx
    3eb5:	06                   	push   es
    3eb6:	57                   	push   di
    3eb7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3eba:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ebe:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    3ec2:	83 ec 08             	sub    sp,0x8
    3ec5:	89 e3                	mov    bx,sp
    3ec7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3ecb:	90                   	nop
    3ecc:	9b                   	fwait
    3ecd:	9a a6 2f 0a 3f       	call   0x3f0a:0x2fa6
    3ed2:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    3ed7:	bf 55 35             	mov    di,0x3555
    3eda:	0e                   	push   cs
    3edb:	57                   	push   di
    3edc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3edf:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3ee4:	06                   	push   es
    3ee5:	57                   	push   di
    3ee6:	9a 9b 3b 34 3f       	call   0x3f34:0x3b9b
    3eeb:	89 c7                	mov    di,ax
    3eed:	8e c2                	mov    es,dx
    3eef:	06                   	push   es
    3ef0:	57                   	push   di
    3ef1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ef4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ef8:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    3efc:	83 ec 08             	sub    sp,0x8
    3eff:	89 e3                	mov    bx,sp
    3f01:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f05:	90                   	nop
    3f06:	9b                   	fwait
    3f07:	9a a6 2f a8 40       	call   0x40a8:0x2fa6
    3f0c:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    3f11:	9b de c1             	faddp  st(1),st
    3f14:	9b dd 5e a8          	fstp   QWORD PTR [bp-0x58]
    3f18:	90                   	nop
    3f19:	9b                   	fwait
    3f1a:	ff 76 ae             	push   WORD PTR [bp-0x52]
    3f1d:	ff 76 ac             	push   WORD PTR [bp-0x54]
    3f20:	ff 76 aa             	push   WORD PTR [bp-0x56]
    3f23:	ff 76 a8             	push   WORD PTR [bp-0x58]
    3f26:	bf 69 35             	mov    di,0x3569
    3f29:	0e                   	push   cs
    3f2a:	57                   	push   di
    3f2b:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3f2f:	06                   	push   es
    3f30:	57                   	push   di
    3f31:	9a 9b 3b 51 3f       	call   0x3f51:0x3b9b
    3f36:	89 c7                	mov    di,ax
    3f38:	8e c2                	mov    es,dx
    3f3a:	06                   	push   es
    3f3b:	57                   	push   di
    3f3c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f3f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3f43:	bf 7d 35             	mov    di,0x357d
    3f46:	0e                   	push   cs
    3f47:	57                   	push   di
    3f48:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3f4c:	06                   	push   es
    3f4d:	57                   	push   di
    3f4e:	9a 9b 3b 7a 3f       	call   0x3f7a:0x3b9b
    3f53:	89 c7                	mov    di,ax
    3f55:	8e c2                	mov    es,dx
    3f57:	06                   	push   es
    3f58:	57                   	push   di
    3f59:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f5c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3f60:	9b d9 e0             	fchs
    3f63:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    3f68:	bf 7d 35             	mov    di,0x357d
    3f6b:	0e                   	push   cs
    3f6c:	57                   	push   di
    3f6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f70:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    3f75:	06                   	push   es
    3f76:	57                   	push   di
    3f77:	9a 9b 3b b1 3f       	call   0x3fb1:0x3b9b
    3f7c:	89 c7                	mov    di,ax
    3f7e:	8e c2                	mov    es,dx
    3f80:	06                   	push   es
    3f81:	57                   	push   di
    3f82:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f85:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3f89:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    3f8e:	9b de c1             	faddp  st(1),st
    3f91:	9b dd 5e a0          	fstp   QWORD PTR [bp-0x60]
    3f95:	90                   	nop
    3f96:	9b                   	fwait
    3f97:	ff 76 a6             	push   WORD PTR [bp-0x5a]
    3f9a:	ff 76 a4             	push   WORD PTR [bp-0x5c]
    3f9d:	ff 76 a2             	push   WORD PTR [bp-0x5e]
    3fa0:	ff 76 a0             	push   WORD PTR [bp-0x60]
    3fa3:	bf 8a 35             	mov    di,0x358a
    3fa6:	0e                   	push   cs
    3fa7:	57                   	push   di
    3fa8:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3fac:	06                   	push   es
    3fad:	57                   	push   di
    3fae:	9a 9b 3b e8 3f       	call   0x3fe8:0x3b9b
    3fb3:	89 c7                	mov    di,ax
    3fb5:	8e c2                	mov    es,dx
    3fb7:	06                   	push   es
    3fb8:	57                   	push   di
    3fb9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3fbc:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3fc0:	9b dd 46 a8          	fld    QWORD PTR [bp-0x58]
    3fc4:	9b dc 46 a0          	fadd   QWORD PTR [bp-0x60]
    3fc8:	9b dd 5e 98          	fstp   QWORD PTR [bp-0x68]
    3fcc:	90                   	nop
    3fcd:	9b                   	fwait
    3fce:	ff 76 9e             	push   WORD PTR [bp-0x62]
    3fd1:	ff 76 9c             	push   WORD PTR [bp-0x64]
    3fd4:	ff 76 9a             	push   WORD PTR [bp-0x66]
    3fd7:	ff 76 98             	push   WORD PTR [bp-0x68]
    3fda:	bf 9c 35             	mov    di,0x359c
    3fdd:	0e                   	push   cs
    3fde:	57                   	push   di
    3fdf:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    3fe3:	06                   	push   es
    3fe4:	57                   	push   di
    3fe5:	9a 9b 3b 09 40       	call   0x4009:0x3b9b
    3fea:	89 c7                	mov    di,ax
    3fec:	8e c2                	mov    es,dx
    3fee:	06                   	push   es
    3fef:	57                   	push   di
    3ff0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ff3:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3ff7:	bf ad 35             	mov    di,0x35ad
    3ffa:	0e                   	push   cs
    3ffb:	57                   	push   di
    3ffc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fff:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    4004:	06                   	push   es
    4005:	57                   	push   di
    4006:	9a 9b 3b 2f 40       	call   0x402f:0x3b9b
    400b:	89 c7                	mov    di,ax
    400d:	8e c2                	mov    es,dx
    400f:	06                   	push   es
    4010:	57                   	push   di
    4011:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4014:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4018:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    401d:	bf ad 35             	mov    di,0x35ad
    4020:	0e                   	push   cs
    4021:	57                   	push   di
    4022:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4025:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    402a:	06                   	push   es
    402b:	57                   	push   di
    402c:	9a 9b 3b 66 40       	call   0x4066:0x3b9b
    4031:	89 c7                	mov    di,ax
    4033:	8e c2                	mov    es,dx
    4035:	06                   	push   es
    4036:	57                   	push   di
    4037:	26 c4 3d             	les    di,DWORD PTR es:[di]
    403a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    403e:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    4043:	9b de c1             	faddp  st(1),st
    4046:	9b dd 5e 90          	fstp   QWORD PTR [bp-0x70]
    404a:	90                   	nop
    404b:	9b                   	fwait
    404c:	ff 76 96             	push   WORD PTR [bp-0x6a]
    404f:	ff 76 94             	push   WORD PTR [bp-0x6c]
    4052:	ff 76 92             	push   WORD PTR [bp-0x6e]
    4055:	ff 76 90             	push   WORD PTR [bp-0x70]
    4058:	bf bd 35             	mov    di,0x35bd
    405b:	0e                   	push   cs
    405c:	57                   	push   di
    405d:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4061:	06                   	push   es
    4062:	57                   	push   di
    4063:	9a 9b 3b 87 40       	call   0x4087:0x3b9b
    4068:	89 c7                	mov    di,ax
    406a:	8e c2                	mov    es,dx
    406c:	06                   	push   es
    406d:	57                   	push   di
    406e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4071:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4075:	bf c8 35             	mov    di,0x35c8
    4078:	0e                   	push   cs
    4079:	57                   	push   di
    407a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    407d:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    4082:	06                   	push   es
    4083:	57                   	push   di
    4084:	9a 9b 3b c1 40       	call   0x40c1:0x3b9b
    4089:	89 c7                	mov    di,ax
    408b:	8e c2                	mov    es,dx
    408d:	06                   	push   es
    408e:	57                   	push   di
    408f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4092:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4096:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    409a:	83 ec 08             	sub    sp,0x8
    409d:	89 e3                	mov    bx,sp
    409f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    40a3:	90                   	nop
    40a4:	9b                   	fwait
    40a5:	9a a6 2f e2 40       	call   0x40e2:0x2fa6
    40aa:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    40af:	bf d2 35             	mov    di,0x35d2
    40b2:	0e                   	push   cs
    40b3:	57                   	push   di
    40b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40b7:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    40bc:	06                   	push   es
    40bd:	57                   	push   di
    40be:	9a 9b 3b 03 41       	call   0x4103:0x3b9b
    40c3:	89 c7                	mov    di,ax
    40c5:	8e c2                	mov    es,dx
    40c7:	06                   	push   es
    40c8:	57                   	push   di
    40c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40cc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    40d0:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    40d4:	83 ec 08             	sub    sp,0x8
    40d7:	89 e3                	mov    bx,sp
    40d9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    40dd:	90                   	nop
    40de:	9b                   	fwait
    40df:	9a a6 2f 24 41       	call   0x4124:0x2fa6
    40e4:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    40e9:	9b de c1             	faddp  st(1),st
    40ec:	9b db be a8 fe       	fstp   TBYTE PTR [bp-0x158]
    40f1:	bf c8 35             	mov    di,0x35c8
    40f4:	0e                   	push   cs
    40f5:	57                   	push   di
    40f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40f9:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    40fe:	06                   	push   es
    40ff:	57                   	push   di
    4100:	9a 9b 3b 45 41       	call   0x4145:0x3b9b
    4105:	89 c7                	mov    di,ax
    4107:	8e c2                	mov    es,dx
    4109:	06                   	push   es
    410a:	57                   	push   di
    410b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    410e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4112:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    4116:	83 ec 08             	sub    sp,0x8
    4119:	89 e3                	mov    bx,sp
    411b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    411f:	90                   	nop
    4120:	9b                   	fwait
    4121:	9a a6 2f 66 41       	call   0x4166:0x2fa6
    4126:	9b db ae a8 fe       	fld    TBYTE PTR [bp-0x158]
    412b:	9b de c1             	faddp  st(1),st
    412e:	9b db be 9e fe       	fstp   TBYTE PTR [bp-0x162]
    4133:	bf d2 35             	mov    di,0x35d2
    4136:	0e                   	push   cs
    4137:	57                   	push   di
    4138:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    413b:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    4140:	06                   	push   es
    4141:	57                   	push   di
    4142:	9a 9b 3b 90 41       	call   0x4190:0x3b9b
    4147:	89 c7                	mov    di,ax
    4149:	8e c2                	mov    es,dx
    414b:	06                   	push   es
    414c:	57                   	push   di
    414d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4150:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4154:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    4158:	83 ec 08             	sub    sp,0x8
    415b:	89 e3                	mov    bx,sp
    415d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4161:	90                   	nop
    4162:	9b                   	fwait
    4163:	9a a6 2f dc 41       	call   0x41dc:0x2fa6
    4168:	9b db ae 9e fe       	fld    TBYTE PTR [bp-0x162]
    416d:	9b de c1             	faddp  st(1),st
    4170:	9b dd 5e 88          	fstp   QWORD PTR [bp-0x78]
    4174:	90                   	nop
    4175:	9b                   	fwait
    4176:	ff 76 8e             	push   WORD PTR [bp-0x72]
    4179:	ff 76 8c             	push   WORD PTR [bp-0x74]
    417c:	ff 76 8a             	push   WORD PTR [bp-0x76]
    417f:	ff 76 88             	push   WORD PTR [bp-0x78]
    4182:	bf e4 35             	mov    di,0x35e4
    4185:	0e                   	push   cs
    4186:	57                   	push   di
    4187:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    418b:	06                   	push   es
    418c:	57                   	push   di
    418d:	9a 9b 3b b1 41       	call   0x41b1:0x3b9b
    4192:	89 c7                	mov    di,ax
    4194:	8e c2                	mov    es,dx
    4196:	06                   	push   es
    4197:	57                   	push   di
    4198:	26 c4 3d             	les    di,DWORD PTR es:[di]
    419b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    419f:	bf f6 35             	mov    di,0x35f6
    41a2:	0e                   	push   cs
    41a3:	57                   	push   di
    41a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41a7:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    41ac:	06                   	push   es
    41ad:	57                   	push   di
    41ae:	9a 9b 3b fe 41       	call   0x41fe:0x3b9b
    41b3:	89 c7                	mov    di,ax
    41b5:	8e c2                	mov    es,dx
    41b7:	06                   	push   es
    41b8:	57                   	push   di
    41b9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41bc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    41c0:	9b dd 5e 80          	fstp   QWORD PTR [bp-0x80]
    41c4:	90                   	nop
    41c5:	9b 9b dd 46 80       	fld    QWORD PTR [bp-0x80]
    41ca:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    41ce:	83 ec 08             	sub    sp,0x8
    41d1:	89 e3                	mov    bx,sp
    41d3:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    41d7:	90                   	nop
    41d8:	9b                   	fwait
    41d9:	9a a6 2f 0e 44       	call   0x440e:0x2fa6
    41de:	9b dd 5e 80          	fstp   QWORD PTR [bp-0x80]
    41e2:	90                   	nop
    41e3:	9b                   	fwait
    41e4:	ff 76 86             	push   WORD PTR [bp-0x7a]
    41e7:	ff 76 84             	push   WORD PTR [bp-0x7c]
    41ea:	ff 76 82             	push   WORD PTR [bp-0x7e]
    41ed:	ff 76 80             	push   WORD PTR [bp-0x80]
    41f0:	bf fd 35             	mov    di,0x35fd
    41f3:	0e                   	push   cs
    41f4:	57                   	push   di
    41f5:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    41f9:	06                   	push   es
    41fa:	57                   	push   di
    41fb:	9a 9b 3b 1f 42       	call   0x421f:0x3b9b
    4200:	89 c7                	mov    di,ax
    4202:	8e c2                	mov    es,dx
    4204:	06                   	push   es
    4205:	57                   	push   di
    4206:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4209:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    420d:	bf 07 36             	mov    di,0x3607
    4210:	0e                   	push   cs
    4211:	57                   	push   di
    4212:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4215:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    421a:	06                   	push   es
    421b:	57                   	push   di
    421c:	9a 9b 3b 45 42       	call   0x4245:0x3b9b
    4221:	89 c7                	mov    di,ax
    4223:	8e c2                	mov    es,dx
    4225:	06                   	push   es
    4226:	57                   	push   di
    4227:	26 c4 3d             	les    di,DWORD PTR es:[di]
    422a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    422e:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    4233:	bf 19 36             	mov    di,0x3619
    4236:	0e                   	push   cs
    4237:	57                   	push   di
    4238:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    423b:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4240:	06                   	push   es
    4241:	57                   	push   di
    4242:	9a 9b 3b 73 42       	call   0x4273:0x3b9b
    4247:	89 c7                	mov    di,ax
    4249:	8e c2                	mov    es,dx
    424b:	06                   	push   es
    424c:	57                   	push   di
    424d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4250:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4254:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    4259:	9b de c1             	faddp  st(1),st
    425c:	9b db be a8 fe       	fstp   TBYTE PTR [bp-0x158]
    4261:	bf 07 36             	mov    di,0x3607
    4264:	0e                   	push   cs
    4265:	57                   	push   di
    4266:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4269:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    426e:	06                   	push   es
    426f:	57                   	push   di
    4270:	9a 9b 3b a1 42       	call   0x42a1:0x3b9b
    4275:	89 c7                	mov    di,ax
    4277:	8e c2                	mov    es,dx
    4279:	06                   	push   es
    427a:	57                   	push   di
    427b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    427e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4282:	9b db ae a8 fe       	fld    TBYTE PTR [bp-0x158]
    4287:	9b de c1             	faddp  st(1),st
    428a:	9b db be 9e fe       	fstp   TBYTE PTR [bp-0x162]
    428f:	bf 19 36             	mov    di,0x3619
    4292:	0e                   	push   cs
    4293:	57                   	push   di
    4294:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4297:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    429c:	06                   	push   es
    429d:	57                   	push   di
    429e:	9a 9b 3b cf 42       	call   0x42cf:0x3b9b
    42a3:	89 c7                	mov    di,ax
    42a5:	8e c2                	mov    es,dx
    42a7:	06                   	push   es
    42a8:	57                   	push   di
    42a9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42ac:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    42b0:	9b db ae 9e fe       	fld    TBYTE PTR [bp-0x162]
    42b5:	9b de c1             	faddp  st(1),st
    42b8:	9b db be 94 fe       	fstp   TBYTE PTR [bp-0x16c]
    42bd:	bf 28 36             	mov    di,0x3628
    42c0:	0e                   	push   cs
    42c1:	57                   	push   di
    42c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42c5:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    42ca:	06                   	push   es
    42cb:	57                   	push   di
    42cc:	9a 9b 3b fd 42       	call   0x42fd:0x3b9b
    42d1:	89 c7                	mov    di,ax
    42d3:	8e c2                	mov    es,dx
    42d5:	06                   	push   es
    42d6:	57                   	push   di
    42d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42da:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    42de:	9b db ae 94 fe       	fld    TBYTE PTR [bp-0x16c]
    42e3:	9b de c1             	faddp  st(1),st
    42e6:	9b db be 8a fe       	fstp   TBYTE PTR [bp-0x176]
    42eb:	bf 3b 36             	mov    di,0x363b
    42ee:	0e                   	push   cs
    42ef:	57                   	push   di
    42f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42f3:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    42f8:	06                   	push   es
    42f9:	57                   	push   di
    42fa:	9a 9b 3b 2b 43       	call   0x432b:0x3b9b
    42ff:	89 c7                	mov    di,ax
    4301:	8e c2                	mov    es,dx
    4303:	06                   	push   es
    4304:	57                   	push   di
    4305:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4308:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    430c:	9b db ae 8a fe       	fld    TBYTE PTR [bp-0x176]
    4311:	9b de c1             	faddp  st(1),st
    4314:	9b db be 80 fe       	fstp   TBYTE PTR [bp-0x180]
    4319:	bf 48 36             	mov    di,0x3648
    431c:	0e                   	push   cs
    431d:	57                   	push   di
    431e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4321:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    4326:	06                   	push   es
    4327:	57                   	push   di
    4328:	9a 9b 3b 59 43       	call   0x4359:0x3b9b
    432d:	89 c7                	mov    di,ax
    432f:	8e c2                	mov    es,dx
    4331:	06                   	push   es
    4332:	57                   	push   di
    4333:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4336:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    433a:	9b db ae 80 fe       	fld    TBYTE PTR [bp-0x180]
    433f:	9b de c1             	faddp  st(1),st
    4342:	9b db be 76 fe       	fstp   TBYTE PTR [bp-0x18a]
    4347:	bf 55 36             	mov    di,0x3655
    434a:	0e                   	push   cs
    434b:	57                   	push   di
    434c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    434f:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    4354:	06                   	push   es
    4355:	57                   	push   di
    4356:	9a 9b 3b 95 43       	call   0x4395:0x3b9b
    435b:	89 c7                	mov    di,ax
    435d:	8e c2                	mov    es,dx
    435f:	06                   	push   es
    4360:	57                   	push   di
    4361:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4364:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4368:	9b db ae 76 fe       	fld    TBYTE PTR [bp-0x18a]
    436d:	9b de c1             	faddp  st(1),st
    4370:	9b dd 9e 78 ff       	fstp   QWORD PTR [bp-0x88]
    4375:	90                   	nop
    4376:	9b                   	fwait
    4377:	ff b6 7e ff          	push   WORD PTR [bp-0x82]
    437b:	ff b6 7c ff          	push   WORD PTR [bp-0x84]
    437f:	ff b6 7a ff          	push   WORD PTR [bp-0x86]
    4383:	ff b6 78 ff          	push   WORD PTR [bp-0x88]
    4387:	bf 63 36             	mov    di,0x3663
    438a:	0e                   	push   cs
    438b:	57                   	push   di
    438c:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4390:	06                   	push   es
    4391:	57                   	push   di
    4392:	9a 9b 3b b6 43       	call   0x43b6:0x3b9b
    4397:	89 c7                	mov    di,ax
    4399:	8e c2                	mov    es,dx
    439b:	06                   	push   es
    439c:	57                   	push   di
    439d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43a0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    43a4:	bf 6c 36             	mov    di,0x366c
    43a7:	0e                   	push   cs
    43a8:	57                   	push   di
    43a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43ac:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    43b1:	06                   	push   es
    43b2:	57                   	push   di
    43b3:	9a 9b 3b e9 43       	call   0x43e9:0x3b9b
    43b8:	89 c7                	mov    di,ax
    43ba:	8e c2                	mov    es,dx
    43bc:	06                   	push   es
    43bd:	57                   	push   di
    43be:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43c1:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    43c5:	89 86 b8 fe          	mov    WORD PTR [bp-0x148],ax
    43c9:	89 96 ba fe          	mov    WORD PTR [bp-0x146],dx
    43cd:	9b db 86 b8 fe       	fild   DWORD PTR [bp-0x148]
    43d2:	9b db be ae fe       	fstp   TBYTE PTR [bp-0x152]
    43d7:	bf 75 36             	mov    di,0x3675
    43da:	0e                   	push   cs
    43db:	57                   	push   di
    43dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43df:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    43e4:	06                   	push   es
    43e5:	57                   	push   di
    43e6:	9a 9b 3b 27 44       	call   0x4427:0x3b9b
    43eb:	89 c7                	mov    di,ax
    43ed:	8e c2                	mov    es,dx
    43ef:	06                   	push   es
    43f0:	57                   	push   di
    43f1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43f4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    43f8:	9b db ae ae fe       	fld    TBYTE PTR [bp-0x152]
    43fd:	9b de c9             	fmulp  st(1),st
    4400:	83 ec 08             	sub    sp,0x8
    4403:	89 e3                	mov    bx,sp
    4405:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4409:	90                   	nop
    440a:	9b                   	fwait
    440b:	9a a6 2f 7f 44       	call   0x447f:0x2fa6
    4410:	9b db be 96 fe       	fstp   TBYTE PTR [bp-0x16a]
    4415:	bf 6c 36             	mov    di,0x366c
    4418:	0e                   	push   cs
    4419:	57                   	push   di
    441a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    441d:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    4422:	06                   	push   es
    4423:	57                   	push   di
    4424:	9a 9b 3b 5a 44       	call   0x445a:0x3b9b
    4429:	89 c7                	mov    di,ax
    442b:	8e c2                	mov    es,dx
    442d:	06                   	push   es
    442e:	57                   	push   di
    442f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4432:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4436:	89 86 aa fe          	mov    WORD PTR [bp-0x156],ax
    443a:	89 96 ac fe          	mov    WORD PTR [bp-0x154],dx
    443e:	9b db 86 aa fe       	fild   DWORD PTR [bp-0x156]
    4443:	9b db be a0 fe       	fstp   TBYTE PTR [bp-0x160]
    4448:	bf 75 36             	mov    di,0x3675
    444b:	0e                   	push   cs
    444c:	57                   	push   di
    444d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4450:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    4455:	06                   	push   es
    4456:	57                   	push   di
    4457:	9a 9b 3b ae 44       	call   0x44ae:0x3b9b
    445c:	89 c7                	mov    di,ax
    445e:	8e c2                	mov    es,dx
    4460:	06                   	push   es
    4461:	57                   	push   di
    4462:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4465:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4469:	9b db ae a0 fe       	fld    TBYTE PTR [bp-0x160]
    446e:	9b de c9             	fmulp  st(1),st
    4471:	83 ec 08             	sub    sp,0x8
    4474:	89 e3                	mov    bx,sp
    4476:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    447a:	90                   	nop
    447b:	9b                   	fwait
    447c:	9a a6 2f ec 44       	call   0x44ec:0x2fa6
    4481:	9b db ae 96 fe       	fld    TBYTE PTR [bp-0x16a]
    4486:	9b de c1             	faddp  st(1),st
    4489:	9b dd 9e 70 ff       	fstp   QWORD PTR [bp-0x90]
    448e:	90                   	nop
    448f:	9b                   	fwait
    4490:	ff b6 76 ff          	push   WORD PTR [bp-0x8a]
    4494:	ff b6 74 ff          	push   WORD PTR [bp-0x8c]
    4498:	ff b6 72 ff          	push   WORD PTR [bp-0x8e]
    449c:	ff b6 70 ff          	push   WORD PTR [bp-0x90]
    44a0:	bf 84 36             	mov    di,0x3684
    44a3:	0e                   	push   cs
    44a4:	57                   	push   di
    44a5:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    44a9:	06                   	push   es
    44aa:	57                   	push   di
    44ab:	9a 9b 3b cb 44       	call   0x44cb:0x3b9b
    44b0:	89 c7                	mov    di,ax
    44b2:	8e c2                	mov    es,dx
    44b4:	06                   	push   es
    44b5:	57                   	push   di
    44b6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44b9:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    44bd:	bf 8f 36             	mov    di,0x368f
    44c0:	0e                   	push   cs
    44c1:	57                   	push   di
    44c2:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    44c6:	06                   	push   es
    44c7:	57                   	push   di
    44c8:	9a 9b 3b 13 45       	call   0x4513:0x3b9b
    44cd:	89 c7                	mov    di,ax
    44cf:	8e c2                	mov    es,dx
    44d1:	06                   	push   es
    44d2:	57                   	push   di
    44d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44d6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    44da:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    44de:	83 ec 08             	sub    sp,0x8
    44e1:	89 e3                	mov    bx,sp
    44e3:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    44e7:	90                   	nop
    44e8:	9b                   	fwait
    44e9:	9a a6 2f 51 45       	call   0x4551:0x2fa6
    44ee:	9b dd 9e 68 ff       	fstp   QWORD PTR [bp-0x98]
    44f3:	90                   	nop
    44f4:	9b                   	fwait
    44f5:	ff b6 6e ff          	push   WORD PTR [bp-0x92]
    44f9:	ff b6 6c ff          	push   WORD PTR [bp-0x94]
    44fd:	ff b6 6a ff          	push   WORD PTR [bp-0x96]
    4501:	ff b6 68 ff          	push   WORD PTR [bp-0x98]
    4505:	bf a4 36             	mov    di,0x36a4
    4508:	0e                   	push   cs
    4509:	57                   	push   di
    450a:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    450e:	06                   	push   es
    450f:	57                   	push   di
    4510:	9a 9b 3b 30 45       	call   0x4530:0x3b9b
    4515:	89 c7                	mov    di,ax
    4517:	8e c2                	mov    es,dx
    4519:	06                   	push   es
    451a:	57                   	push   di
    451b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    451e:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4522:	bf b2 36             	mov    di,0x36b2
    4525:	0e                   	push   cs
    4526:	57                   	push   di
    4527:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    452b:	06                   	push   es
    452c:	57                   	push   di
    452d:	9a 9b 3b 66 45       	call   0x4566:0x3b9b
    4532:	89 c7                	mov    di,ax
    4534:	8e c2                	mov    es,dx
    4536:	06                   	push   es
    4537:	57                   	push   di
    4538:	26 c4 3d             	les    di,DWORD PTR es:[di]
    453b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    453f:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    4543:	83 ec 08             	sub    sp,0x8
    4546:	89 e3                	mov    bx,sp
    4548:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    454c:	90                   	nop
    454d:	9b                   	fwait
    454e:	9a a6 2f 87 45       	call   0x4587:0x2fa6
    4553:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    4558:	bf be 36             	mov    di,0x36be
    455b:	0e                   	push   cs
    455c:	57                   	push   di
    455d:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4561:	06                   	push   es
    4562:	57                   	push   di
    4563:	9a 9b 3b b6 45       	call   0x45b6:0x3b9b
    4568:	89 c7                	mov    di,ax
    456a:	8e c2                	mov    es,dx
    456c:	06                   	push   es
    456d:	57                   	push   di
    456e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4571:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4575:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    4579:	83 ec 08             	sub    sp,0x8
    457c:	89 e3                	mov    bx,sp
    457e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4582:	90                   	nop
    4583:	9b                   	fwait
    4584:	9a a6 2f 51 46       	call   0x4651:0x2fa6
    4589:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    458e:	9b de c1             	faddp  st(1),st
    4591:	9b dd 9e 60 ff       	fstp   QWORD PTR [bp-0xa0]
    4596:	90                   	nop
    4597:	9b                   	fwait
    4598:	ff b6 66 ff          	push   WORD PTR [bp-0x9a]
    459c:	ff b6 64 ff          	push   WORD PTR [bp-0x9c]
    45a0:	ff b6 62 ff          	push   WORD PTR [bp-0x9e]
    45a4:	ff b6 60 ff          	push   WORD PTR [bp-0xa0]
    45a8:	bf d0 36             	mov    di,0x36d0
    45ab:	0e                   	push   cs
    45ac:	57                   	push   di
    45ad:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    45b1:	06                   	push   es
    45b2:	57                   	push   di
    45b3:	9a 9b 3b d3 45       	call   0x45d3:0x3b9b
    45b8:	89 c7                	mov    di,ax
    45ba:	8e c2                	mov    es,dx
    45bc:	06                   	push   es
    45bd:	57                   	push   di
    45be:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45c1:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    45c5:	bf e1 36             	mov    di,0x36e1
    45c8:	0e                   	push   cs
    45c9:	57                   	push   di
    45ca:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    45ce:	06                   	push   es
    45cf:	57                   	push   di
    45d0:	9a 9b 3b fb 45       	call   0x45fb:0x3b9b
    45d5:	89 c7                	mov    di,ax
    45d7:	8e c2                	mov    es,dx
    45d9:	06                   	push   es
    45da:	57                   	push   di
    45db:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45de:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    45e2:	9b dd 9e 58 ff       	fstp   QWORD PTR [bp-0xa8]
    45e7:	90                   	nop
    45e8:	9b                   	fwait
    45e9:	bf f1 36             	mov    di,0x36f1
    45ec:	0e                   	push   cs
    45ed:	57                   	push   di
    45ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45f1:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    45f6:	06                   	push   es
    45f7:	57                   	push   di
    45f8:	9a 9b 3b 21 46       	call   0x4621:0x3b9b
    45fd:	89 c7                	mov    di,ax
    45ff:	8e c2                	mov    es,dx
    4601:	06                   	push   es
    4602:	57                   	push   di
    4603:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4606:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    460a:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    460f:	bf ff 36             	mov    di,0x36ff
    4612:	0e                   	push   cs
    4613:	57                   	push   di
    4614:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4617:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    461c:	06                   	push   es
    461d:	57                   	push   di
    461e:	9a 9b 3b 6a 46       	call   0x466a:0x3b9b
    4623:	89 c7                	mov    di,ax
    4625:	8e c2                	mov    es,dx
    4627:	06                   	push   es
    4628:	57                   	push   di
    4629:	26 c4 3d             	les    di,DWORD PTR es:[di]
    462c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4630:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    4635:	9b de c9             	fmulp  st(1),st
    4638:	9b 2e d9 06 50 34    	fld    DWORD PTR cs:0x3450
    463e:	9a b2 04 b0 46       	call   0x46b0:0x4b2
    4643:	83 ec 08             	sub    sp,0x8
    4646:	89 e3                	mov    bx,sp
    4648:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    464c:	90                   	nop
    464d:	9b                   	fwait
    464e:	9a a6 2f c0 46       	call   0x46c0:0x2fa6
    4653:	9b db be 9e fe       	fstp   TBYTE PTR [bp-0x162]
    4658:	bf 11 37             	mov    di,0x3711
    465b:	0e                   	push   cs
    465c:	57                   	push   di
    465d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4660:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4665:	06                   	push   es
    4666:	57                   	push   di
    4667:	9a 9b 3b 90 46       	call   0x4690:0x3b9b
    466c:	89 c7                	mov    di,ax
    466e:	8e c2                	mov    es,dx
    4670:	06                   	push   es
    4671:	57                   	push   di
    4672:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4675:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4679:	9b db be a8 fe       	fstp   TBYTE PTR [bp-0x158]
    467e:	bf 20 37             	mov    di,0x3720
    4681:	0e                   	push   cs
    4682:	57                   	push   di
    4683:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4686:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    468b:	06                   	push   es
    468c:	57                   	push   di
    468d:	9a 9b 3b e1 46       	call   0x46e1:0x3b9b
    4692:	89 c7                	mov    di,ax
    4694:	8e c2                	mov    es,dx
    4696:	06                   	push   es
    4697:	57                   	push   di
    4698:	26 c4 3d             	les    di,DWORD PTR es:[di]
    469b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    469f:	9b db ae a8 fe       	fld    TBYTE PTR [bp-0x158]
    46a4:	9b de c9             	fmulp  st(1),st
    46a7:	9b 2e d9 06 50 34    	fld    DWORD PTR cs:0x3450
    46ad:	9a b2 04 27 47       	call   0x4727:0x4b2
    46b2:	83 ec 08             	sub    sp,0x8
    46b5:	89 e3                	mov    bx,sp
    46b7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    46bb:	90                   	nop
    46bc:	9b                   	fwait
    46bd:	9a a6 2f 37 47       	call   0x4737:0x2fa6
    46c2:	9b db ae 9e fe       	fld    TBYTE PTR [bp-0x162]
    46c7:	9b de c1             	faddp  st(1),st
    46ca:	9b db be 8a fe       	fstp   TBYTE PTR [bp-0x176]
    46cf:	bf 33 37             	mov    di,0x3733
    46d2:	0e                   	push   cs
    46d3:	57                   	push   di
    46d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46d7:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    46dc:	06                   	push   es
    46dd:	57                   	push   di
    46de:	9a 9b 3b 07 47       	call   0x4707:0x3b9b
    46e3:	89 c7                	mov    di,ax
    46e5:	8e c2                	mov    es,dx
    46e7:	06                   	push   es
    46e8:	57                   	push   di
    46e9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46ec:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    46f0:	9b db be 94 fe       	fstp   TBYTE PTR [bp-0x16c]
    46f5:	bf 3b 37             	mov    di,0x373b
    46f8:	0e                   	push   cs
    46f9:	57                   	push   di
    46fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46fd:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    4702:	06                   	push   es
    4703:	57                   	push   di
    4704:	9a 9b 3b 66 47       	call   0x4766:0x3b9b
    4709:	89 c7                	mov    di,ax
    470b:	8e c2                	mov    es,dx
    470d:	06                   	push   es
    470e:	57                   	push   di
    470f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4712:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4716:	9b db ae 94 fe       	fld    TBYTE PTR [bp-0x16c]
    471b:	9b de c9             	fmulp  st(1),st
    471e:	9b 2e d9 06 50 34    	fld    DWORD PTR cs:0x3450
    4724:	9a b2 04 95 4d       	call   0x4d95:0x4b2
    4729:	83 ec 08             	sub    sp,0x8
    472c:	89 e3                	mov    bx,sp
    472e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4732:	90                   	nop
    4733:	9b                   	fwait
    4734:	9a a6 2f 88 4a       	call   0x4a88:0x2fa6
    4739:	9b db ae 8a fe       	fld    TBYTE PTR [bp-0x176]
    473e:	9b de c1             	faddp  st(1),st
    4741:	9b dd 9e 50 ff       	fstp   QWORD PTR [bp-0xb0]
    4746:	90                   	nop
    4747:	9b                   	fwait
    4748:	ff b6 56 ff          	push   WORD PTR [bp-0xaa]
    474c:	ff b6 54 ff          	push   WORD PTR [bp-0xac]
    4750:	ff b6 52 ff          	push   WORD PTR [bp-0xae]
    4754:	ff b6 50 ff          	push   WORD PTR [bp-0xb0]
    4758:	bf 47 37             	mov    di,0x3747
    475b:	0e                   	push   cs
    475c:	57                   	push   di
    475d:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4761:	06                   	push   es
    4762:	57                   	push   di
    4763:	9a 9b 3b 87 47       	call   0x4787:0x3b9b
    4768:	89 c7                	mov    di,ax
    476a:	8e c2                	mov    es,dx
    476c:	06                   	push   es
    476d:	57                   	push   di
    476e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4771:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4775:	bf 5a 37             	mov    di,0x375a
    4778:	0e                   	push   cs
    4779:	57                   	push   di
    477a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    477d:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4782:	06                   	push   es
    4783:	57                   	push   di
    4784:	9a 9b 3b bb 47       	call   0x47bb:0x3b9b
    4789:	89 c7                	mov    di,ax
    478b:	8e c2                	mov    es,dx
    478d:	06                   	push   es
    478e:	57                   	push   di
    478f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4792:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4796:	9b dd 9e 40 ff       	fstp   QWORD PTR [bp-0xc0]
    479b:	90                   	nop
    479c:	9b                   	fwait
    479d:	ff b6 46 ff          	push   WORD PTR [bp-0xba]
    47a1:	ff b6 44 ff          	push   WORD PTR [bp-0xbc]
    47a5:	ff b6 42 ff          	push   WORD PTR [bp-0xbe]
    47a9:	ff b6 40 ff          	push   WORD PTR [bp-0xc0]
    47ad:	bf 60 37             	mov    di,0x3760
    47b0:	0e                   	push   cs
    47b1:	57                   	push   di
    47b2:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    47b6:	06                   	push   es
    47b7:	57                   	push   di
    47b8:	9a 9b 3b d8 47       	call   0x47d8:0x3b9b
    47bd:	89 c7                	mov    di,ax
    47bf:	8e c2                	mov    es,dx
    47c1:	06                   	push   es
    47c2:	57                   	push   di
    47c3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47c6:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    47ca:	bf 6a 37             	mov    di,0x376a
    47cd:	0e                   	push   cs
    47ce:	57                   	push   di
    47cf:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    47d3:	06                   	push   es
    47d4:	57                   	push   di
    47d5:	9a 9b 3b fc 47       	call   0x47fc:0x3b9b
    47da:	89 c7                	mov    di,ax
    47dc:	8e c2                	mov    es,dx
    47de:	06                   	push   es
    47df:	57                   	push   di
    47e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47e3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    47e7:	9b dd 9e d0 fe       	fstp   QWORD PTR [bp-0x130]
    47ec:	90                   	nop
    47ed:	9b                   	fwait
    47ee:	bf 77 37             	mov    di,0x3777
    47f1:	0e                   	push   cs
    47f2:	57                   	push   di
    47f3:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    47f7:	06                   	push   es
    47f8:	57                   	push   di
    47f9:	9a 9b 3b 41 48       	call   0x4841:0x3b9b
    47fe:	89 c7                	mov    di,ax
    4800:	8e c2                	mov    es,dx
    4802:	06                   	push   es
    4803:	57                   	push   di
    4804:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4807:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    480b:	9b dd 9e c8 fe       	fstp   QWORD PTR [bp-0x138]
    4810:	90                   	nop
    4811:	9b 9b dd 86 d0 fe    	fld    QWORD PTR [bp-0x130]
    4817:	9b dc a6 c8 fe       	fsub   QWORD PTR [bp-0x138]
    481c:	9b dd 9e 38 ff       	fstp   QWORD PTR [bp-0xc8]
    4821:	90                   	nop
    4822:	9b                   	fwait
    4823:	ff b6 3e ff          	push   WORD PTR [bp-0xc2]
    4827:	ff b6 3c ff          	push   WORD PTR [bp-0xc4]
    482b:	ff b6 3a ff          	push   WORD PTR [bp-0xc6]
    482f:	ff b6 38 ff          	push   WORD PTR [bp-0xc8]
    4833:	bf 85 37             	mov    di,0x3785
    4836:	0e                   	push   cs
    4837:	57                   	push   di
    4838:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    483c:	06                   	push   es
    483d:	57                   	push   di
    483e:	9a 9b 3b 62 48       	call   0x4862:0x3b9b
    4843:	89 c7                	mov    di,ax
    4845:	8e c2                	mov    es,dx
    4847:	06                   	push   es
    4848:	57                   	push   di
    4849:	26 c4 3d             	les    di,DWORD PTR es:[di]
    484c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4850:	bf 93 37             	mov    di,0x3793
    4853:	0e                   	push   cs
    4854:	57                   	push   di
    4855:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4858:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    485d:	06                   	push   es
    485e:	57                   	push   di
    485f:	9a 9b 3b e6 48       	call   0x48e6:0x3b9b
    4864:	89 c7                	mov    di,ax
    4866:	8e c2                	mov    es,dx
    4868:	06                   	push   es
    4869:	57                   	push   di
    486a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    486d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4871:	9b dd 9e c0 fe       	fstp   QWORD PTR [bp-0x140]
    4876:	90                   	nop
    4877:	9b 9b dd 86 c0 fe    	fld    QWORD PTR [bp-0x140]
    487d:	9b 2e d8 1e 26 35    	fcomp  DWORD PTR cs:0x3526
    4883:	9b dd be ba fe       	fstsw  WORD PTR [bp-0x146]
    4888:	90                   	nop
    4889:	9b                   	fwait
    488a:	8a a6 bb fe          	mov    ah,BYTE PTR [bp-0x145]
    488e:	9e                   	sahf
    488f:	76 1b                	jbe    0x48ac
    4891:	9b dd 86 c0 fe       	fld    QWORD PTR [bp-0x140]
    4896:	9b dd 9e 30 ff       	fstp   QWORD PTR [bp-0xd0]
    489b:	90                   	nop
    489c:	9b                   	fwait
    489d:	9b 2e d9 06 26 35    	fld    DWORD PTR cs:0x3526
    48a3:	9b dd 9e 28 ff       	fstp   QWORD PTR [bp-0xd8]
    48a8:	90                   	nop
    48a9:	9b                   	fwait
    48aa:	eb 1c                	jmp    0x48c8
    48ac:	9b 2e d9 06 26 35    	fld    DWORD PTR cs:0x3526
    48b2:	9b dd 9e 30 ff       	fstp   QWORD PTR [bp-0xd0]
    48b7:	90                   	nop
    48b8:	9b 9b dd 86 c0 fe    	fld    QWORD PTR [bp-0x140]
    48be:	9b d9 e0             	fchs
    48c1:	9b dd 9e 28 ff       	fstp   QWORD PTR [bp-0xd8]
    48c6:	90                   	nop
    48c7:	9b                   	fwait
    48c8:	ff b6 36 ff          	push   WORD PTR [bp-0xca]
    48cc:	ff b6 34 ff          	push   WORD PTR [bp-0xcc]
    48d0:	ff b6 32 ff          	push   WORD PTR [bp-0xce]
    48d4:	ff b6 30 ff          	push   WORD PTR [bp-0xd0]
    48d8:	bf a4 37             	mov    di,0x37a4
    48db:	0e                   	push   cs
    48dc:	57                   	push   di
    48dd:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    48e1:	06                   	push   es
    48e2:	57                   	push   di
    48e3:	9a 9b 3b 13 49       	call   0x4913:0x3b9b
    48e8:	89 c7                	mov    di,ax
    48ea:	8e c2                	mov    es,dx
    48ec:	06                   	push   es
    48ed:	57                   	push   di
    48ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48f1:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    48f5:	ff b6 2e ff          	push   WORD PTR [bp-0xd2]
    48f9:	ff b6 2c ff          	push   WORD PTR [bp-0xd4]
    48fd:	ff b6 2a ff          	push   WORD PTR [bp-0xd6]
    4901:	ff b6 28 ff          	push   WORD PTR [bp-0xd8]
    4905:	bf b8 37             	mov    di,0x37b8
    4908:	0e                   	push   cs
    4909:	57                   	push   di
    490a:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    490e:	06                   	push   es
    490f:	57                   	push   di
    4910:	9a 9b 3b 30 49       	call   0x4930:0x3b9b
    4915:	89 c7                	mov    di,ax
    4917:	8e c2                	mov    es,dx
    4919:	06                   	push   es
    491a:	57                   	push   di
    491b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    491e:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4922:	bf 33 37             	mov    di,0x3733
    4925:	0e                   	push   cs
    4926:	57                   	push   di
    4927:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    492b:	06                   	push   es
    492c:	57                   	push   di
    492d:	9a 9b 3b 56 49       	call   0x4956:0x3b9b
    4932:	89 c7                	mov    di,ax
    4934:	8e c2                	mov    es,dx
    4936:	06                   	push   es
    4937:	57                   	push   di
    4938:	26 c4 3d             	les    di,DWORD PTR es:[di]
    493b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    493f:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    4944:	bf 33 37             	mov    di,0x3733
    4947:	0e                   	push   cs
    4948:	57                   	push   di
    4949:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    494c:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4951:	06                   	push   es
    4952:	57                   	push   di
    4953:	9a 9b 3b e2 49       	call   0x49e2:0x3b9b
    4958:	89 c7                	mov    di,ax
    495a:	8e c2                	mov    es,dx
    495c:	06                   	push   es
    495d:	57                   	push   di
    495e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4961:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4965:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    496a:	9b de e1             	fsubrp st(1),st
    496d:	9b dd 9e c0 fe       	fstp   QWORD PTR [bp-0x140]
    4972:	90                   	nop
    4973:	9b 9b dd 86 c0 fe    	fld    QWORD PTR [bp-0x140]
    4979:	9b 2e d8 1e 26 35    	fcomp  DWORD PTR cs:0x3526
    497f:	9b dd be ba fe       	fstsw  WORD PTR [bp-0x146]
    4984:	90                   	nop
    4985:	9b                   	fwait
    4986:	8a a6 bb fe          	mov    ah,BYTE PTR [bp-0x145]
    498a:	9e                   	sahf
    498b:	76 1b                	jbe    0x49a8
    498d:	9b dd 86 c0 fe       	fld    QWORD PTR [bp-0x140]
    4992:	9b dd 9e 20 ff       	fstp   QWORD PTR [bp-0xe0]
    4997:	90                   	nop
    4998:	9b                   	fwait
    4999:	9b 2e d9 06 26 35    	fld    DWORD PTR cs:0x3526
    499f:	9b dd 9e 18 ff       	fstp   QWORD PTR [bp-0xe8]
    49a4:	90                   	nop
    49a5:	9b                   	fwait
    49a6:	eb 1c                	jmp    0x49c4
    49a8:	9b 2e d9 06 26 35    	fld    DWORD PTR cs:0x3526
    49ae:	9b dd 9e 20 ff       	fstp   QWORD PTR [bp-0xe0]
    49b3:	90                   	nop
    49b4:	9b 9b dd 86 c0 fe    	fld    QWORD PTR [bp-0x140]
    49ba:	9b d9 e0             	fchs
    49bd:	9b dd 9e 18 ff       	fstp   QWORD PTR [bp-0xe8]
    49c2:	90                   	nop
    49c3:	9b                   	fwait
    49c4:	ff b6 26 ff          	push   WORD PTR [bp-0xda]
    49c8:	ff b6 24 ff          	push   WORD PTR [bp-0xdc]
    49cc:	ff b6 22 ff          	push   WORD PTR [bp-0xde]
    49d0:	ff b6 20 ff          	push   WORD PTR [bp-0xe0]
    49d4:	bf c9 37             	mov    di,0x37c9
    49d7:	0e                   	push   cs
    49d8:	57                   	push   di
    49d9:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    49dd:	06                   	push   es
    49de:	57                   	push   di
    49df:	9a 9b 3b 0f 4a       	call   0x4a0f:0x3b9b
    49e4:	89 c7                	mov    di,ax
    49e6:	8e c2                	mov    es,dx
    49e8:	06                   	push   es
    49e9:	57                   	push   di
    49ea:	26 c4 3d             	les    di,DWORD PTR es:[di]
    49ed:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    49f1:	ff b6 1e ff          	push   WORD PTR [bp-0xe2]
    49f5:	ff b6 1c ff          	push   WORD PTR [bp-0xe4]
    49f9:	ff b6 1a ff          	push   WORD PTR [bp-0xe6]
    49fd:	ff b6 18 ff          	push   WORD PTR [bp-0xe8]
    4a01:	bf da 37             	mov    di,0x37da
    4a04:	0e                   	push   cs
    4a05:	57                   	push   di
    4a06:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4a0a:	06                   	push   es
    4a0b:	57                   	push   di
    4a0c:	9a 9b 3b 30 4a       	call   0x4a30:0x3b9b
    4a11:	89 c7                	mov    di,ax
    4a13:	8e c2                	mov    es,dx
    4a15:	06                   	push   es
    4a16:	57                   	push   di
    4a17:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a1a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4a1e:	bf f0 37             	mov    di,0x37f0
    4a21:	0e                   	push   cs
    4a22:	57                   	push   di
    4a23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a26:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    4a2b:	06                   	push   es
    4a2c:	57                   	push   di
    4a2d:	9a 9b 3b 63 4a       	call   0x4a63:0x3b9b
    4a32:	89 c7                	mov    di,ax
    4a34:	8e c2                	mov    es,dx
    4a36:	06                   	push   es
    4a37:	57                   	push   di
    4a38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a3b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4a3f:	89 86 b8 fe          	mov    WORD PTR [bp-0x148],ax
    4a43:	89 96 ba fe          	mov    WORD PTR [bp-0x146],dx
    4a47:	9b db 86 b8 fe       	fild   DWORD PTR [bp-0x148]
    4a4c:	9b db be ae fe       	fstp   TBYTE PTR [bp-0x152]
    4a51:	bf fe 37             	mov    di,0x37fe
    4a54:	0e                   	push   cs
    4a55:	57                   	push   di
    4a56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a59:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    4a5e:	06                   	push   es
    4a5f:	57                   	push   di
    4a60:	9a 9b 3b cf 4a       	call   0x4acf:0x3b9b
    4a65:	89 c7                	mov    di,ax
    4a67:	8e c2                	mov    es,dx
    4a69:	06                   	push   es
    4a6a:	57                   	push   di
    4a6b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4a6e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4a72:	9b db ae ae fe       	fld    TBYTE PTR [bp-0x152]
    4a77:	9b de c9             	fmulp  st(1),st
    4a7a:	83 ec 08             	sub    sp,0x8
    4a7d:	89 e3                	mov    bx,sp
    4a7f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4a83:	90                   	nop
    4a84:	9b                   	fwait
    4a85:	9a a6 2f a8 4a       	call   0x4aa8:0x2fa6
    4a8a:	9b dd 9e 10 ff       	fstp   QWORD PTR [bp-0xf0]
    4a8f:	90                   	nop
    4a90:	9b 9b dd 86 10 ff    	fld    QWORD PTR [bp-0xf0]
    4a96:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    4a9a:	83 ec 08             	sub    sp,0x8
    4a9d:	89 e3                	mov    bx,sp
    4a9f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4aa3:	90                   	nop
    4aa4:	9b                   	fwait
    4aa5:	9a a6 2f 0d 4b       	call   0x4b0d:0x2fa6
    4aaa:	9b dd 9e 10 ff       	fstp   QWORD PTR [bp-0xf0]
    4aaf:	90                   	nop
    4ab0:	9b                   	fwait
    4ab1:	ff b6 16 ff          	push   WORD PTR [bp-0xea]
    4ab5:	ff b6 14 ff          	push   WORD PTR [bp-0xec]
    4ab9:	ff b6 12 ff          	push   WORD PTR [bp-0xee]
    4abd:	ff b6 10 ff          	push   WORD PTR [bp-0xf0]
    4ac1:	bf 0f 38             	mov    di,0x380f
    4ac4:	0e                   	push   cs
    4ac5:	57                   	push   di
    4ac6:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4aca:	06                   	push   es
    4acb:	57                   	push   di
    4acc:	9a 9b 3b ec 4a       	call   0x4aec:0x3b9b
    4ad1:	89 c7                	mov    di,ax
    4ad3:	8e c2                	mov    es,dx
    4ad5:	06                   	push   es
    4ad6:	57                   	push   di
    4ad7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ada:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4ade:	bf 22 38             	mov    di,0x3822
    4ae1:	0e                   	push   cs
    4ae2:	57                   	push   di
    4ae3:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4ae7:	06                   	push   es
    4ae8:	57                   	push   di
    4ae9:	9a 9b 3b 34 4b       	call   0x4b34:0x3b9b
    4aee:	89 c7                	mov    di,ax
    4af0:	8e c2                	mov    es,dx
    4af2:	06                   	push   es
    4af3:	57                   	push   di
    4af4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4af7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4afb:	9b dc 4e f0          	fmul   QWORD PTR [bp-0x10]
    4aff:	83 ec 08             	sub    sp,0x8
    4b02:	89 e3                	mov    bx,sp
    4b04:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4b08:	90                   	nop
    4b09:	9b                   	fwait
    4b0a:	9a a6 2f ff ff       	call   0xffff:0x2fa6
    4b0f:	9b dd 9e 08 ff       	fstp   QWORD PTR [bp-0xf8]
    4b14:	90                   	nop
    4b15:	9b                   	fwait
    4b16:	ff b6 0e ff          	push   WORD PTR [bp-0xf2]
    4b1a:	ff b6 0c ff          	push   WORD PTR [bp-0xf4]
    4b1e:	ff b6 0a ff          	push   WORD PTR [bp-0xf6]
    4b22:	ff b6 08 ff          	push   WORD PTR [bp-0xf8]
    4b26:	bf 2b 38             	mov    di,0x382b
    4b29:	0e                   	push   cs
    4b2a:	57                   	push   di
    4b2b:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4b2f:	06                   	push   es
    4b30:	57                   	push   di
    4b31:	9a 9b 3b 51 4b       	call   0x4b51:0x3b9b
    4b36:	89 c7                	mov    di,ax
    4b38:	8e c2                	mov    es,dx
    4b3a:	06                   	push   es
    4b3b:	57                   	push   di
    4b3c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b3f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4b43:	bf 37 38             	mov    di,0x3837
    4b46:	0e                   	push   cs
    4b47:	57                   	push   di
    4b48:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4b4c:	06                   	push   es
    4b4d:	57                   	push   di
    4b4e:	9a 9b 3b dd 4b       	call   0x4bdd:0x3b9b
    4b53:	89 c7                	mov    di,ax
    4b55:	8e c2                	mov    es,dx
    4b57:	06                   	push   es
    4b58:	57                   	push   di
    4b59:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b5c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4b60:	9b dd 9e 00 ff       	fstp   QWORD PTR [bp-0x100]
    4b65:	90                   	nop
    4b66:	9b 9b dd 46 98       	fld    QWORD PTR [bp-0x68]
    4b6b:	9b dc 46 90          	fadd   QWORD PTR [bp-0x70]
    4b6f:	9b dc 46 88          	fadd   QWORD PTR [bp-0x78]
    4b73:	9b dc 46 80          	fadd   QWORD PTR [bp-0x80]
    4b77:	9b dc 86 78 ff       	fadd   QWORD PTR [bp-0x88]
    4b7c:	9b dc 86 70 ff       	fadd   QWORD PTR [bp-0x90]
    4b81:	9b dc 86 68 ff       	fadd   QWORD PTR [bp-0x98]
    4b86:	9b dc 86 60 ff       	fadd   QWORD PTR [bp-0xa0]
    4b8b:	9b dc 86 58 ff       	fadd   QWORD PTR [bp-0xa8]
    4b90:	9b dc 86 50 ff       	fadd   QWORD PTR [bp-0xb0]
    4b95:	9b dc 86 48 ff       	fadd   QWORD PTR [bp-0xb8]
    4b9a:	9b dc 86 40 ff       	fadd   QWORD PTR [bp-0xc0]
    4b9f:	9b dc 86 38 ff       	fadd   QWORD PTR [bp-0xc8]
    4ba4:	9b dc 86 28 ff       	fadd   QWORD PTR [bp-0xd8]
    4ba9:	9b dc 86 18 ff       	fadd   QWORD PTR [bp-0xe8]
    4bae:	9b dc 86 10 ff       	fadd   QWORD PTR [bp-0xf0]
    4bb3:	9b dc 86 00 ff       	fadd   QWORD PTR [bp-0x100]
    4bb8:	9b dd 9e f8 fe       	fstp   QWORD PTR [bp-0x108]
    4bbd:	90                   	nop
    4bbe:	9b                   	fwait
    4bbf:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    4bc3:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    4bc7:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    4bcb:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    4bcf:	bf 45 38             	mov    di,0x3845
    4bd2:	0e                   	push   cs
    4bd3:	57                   	push   di
    4bd4:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4bd8:	06                   	push   es
    4bd9:	57                   	push   di
    4bda:	9a 9b 3b 34 4c       	call   0x4c34:0x3b9b
    4bdf:	89 c7                	mov    di,ax
    4be1:	8e c2                	mov    es,dx
    4be3:	06                   	push   es
    4be4:	57                   	push   di
    4be5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4be8:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4bec:	9b dd 46 d0          	fld    QWORD PTR [bp-0x30]
    4bf0:	9b dc 46 c8          	fadd   QWORD PTR [bp-0x38]
    4bf4:	9b dc 46 c0          	fadd   QWORD PTR [bp-0x40]
    4bf8:	9b dc 46 b0          	fadd   QWORD PTR [bp-0x50]
    4bfc:	9b dc 46 b8          	fadd   QWORD PTR [bp-0x48]
    4c00:	9b dc 86 30 ff       	fadd   QWORD PTR [bp-0xd0]
    4c05:	9b dc 86 20 ff       	fadd   QWORD PTR [bp-0xe0]
    4c0a:	9b dc 86 08 ff       	fadd   QWORD PTR [bp-0xf8]
    4c0f:	9b dd 9e f0 fe       	fstp   QWORD PTR [bp-0x110]
    4c14:	90                   	nop
    4c15:	9b                   	fwait
    4c16:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    4c1a:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    4c1e:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    4c22:	ff b6 f0 fe          	push   WORD PTR [bp-0x110]
    4c26:	bf 4e 38             	mov    di,0x384e
    4c29:	0e                   	push   cs
    4c2a:	57                   	push   di
    4c2b:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4c2f:	06                   	push   es
    4c30:	57                   	push   di
    4c31:	9a 9b 3b 72 4c       	call   0x4c72:0x3b9b
    4c36:	89 c7                	mov    di,ax
    4c38:	8e c2                	mov    es,dx
    4c3a:	06                   	push   es
    4c3b:	57                   	push   di
    4c3c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c3f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4c43:	9b dd 86 f0 fe       	fld    QWORD PTR [bp-0x110]
    4c48:	9b dc a6 f8 fe       	fsub   QWORD PTR [bp-0x108]
    4c4d:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    4c52:	90                   	nop
    4c53:	9b                   	fwait
    4c54:	ff b6 ee fe          	push   WORD PTR [bp-0x112]
    4c58:	ff b6 ec fe          	push   WORD PTR [bp-0x114]
    4c5c:	ff b6 ea fe          	push   WORD PTR [bp-0x116]
    4c60:	ff b6 e8 fe          	push   WORD PTR [bp-0x118]
    4c64:	bf 57 38             	mov    di,0x3857
    4c67:	0e                   	push   cs
    4c68:	57                   	push   di
    4c69:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4c6d:	06                   	push   es
    4c6e:	57                   	push   di
    4c6f:	9a 9b 3b 93 4c       	call   0x4c93:0x3b9b
    4c74:	89 c7                	mov    di,ax
    4c76:	8e c2                	mov    es,dx
    4c78:	06                   	push   es
    4c79:	57                   	push   di
    4c7a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c7d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4c81:	bf e8 34             	mov    di,0x34e8
    4c84:	0e                   	push   cs
    4c85:	57                   	push   di
    4c86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c89:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4c8e:	06                   	push   es
    4c8f:	57                   	push   di
    4c90:	9a 9b 3b b9 4c       	call   0x4cb9:0x3b9b
    4c95:	89 c7                	mov    di,ax
    4c97:	8e c2                	mov    es,dx
    4c99:	06                   	push   es
    4c9a:	57                   	push   di
    4c9b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c9e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ca2:	9b db be b2 fe       	fstp   TBYTE PTR [bp-0x14e]
    4ca7:	bf f1 36             	mov    di,0x36f1
    4caa:	0e                   	push   cs
    4cab:	57                   	push   di
    4cac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4caf:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4cb4:	06                   	push   es
    4cb5:	57                   	push   di
    4cb6:	9a 9b 3b e7 4c       	call   0x4ce7:0x3b9b
    4cbb:	89 c7                	mov    di,ax
    4cbd:	8e c2                	mov    es,dx
    4cbf:	06                   	push   es
    4cc0:	57                   	push   di
    4cc1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cc4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4cc8:	9b db ae b2 fe       	fld    TBYTE PTR [bp-0x14e]
    4ccd:	9b de e1             	fsubrp st(1),st
    4cd0:	9b db be a8 fe       	fstp   TBYTE PTR [bp-0x158]
    4cd5:	bf 11 37             	mov    di,0x3711
    4cd8:	0e                   	push   cs
    4cd9:	57                   	push   di
    4cda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cdd:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4ce2:	06                   	push   es
    4ce3:	57                   	push   di
    4ce4:	9a 9b 3b 23 4d       	call   0x4d23:0x3b9b
    4ce9:	89 c7                	mov    di,ax
    4ceb:	8e c2                	mov    es,dx
    4ced:	06                   	push   es
    4cee:	57                   	push   di
    4cef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cf2:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4cf6:	9b db ae a8 fe       	fld    TBYTE PTR [bp-0x158]
    4cfb:	9b de e1             	fsubrp st(1),st
    4cfe:	9b dd 9e e0 fe       	fstp   QWORD PTR [bp-0x120]
    4d03:	90                   	nop
    4d04:	9b                   	fwait
    4d05:	ff b6 e6 fe          	push   WORD PTR [bp-0x11a]
    4d09:	ff b6 e4 fe          	push   WORD PTR [bp-0x11c]
    4d0d:	ff b6 e2 fe          	push   WORD PTR [bp-0x11e]
    4d11:	ff b6 e0 fe          	push   WORD PTR [bp-0x120]
    4d15:	bf 65 38             	mov    di,0x3865
    4d18:	0e                   	push   cs
    4d19:	57                   	push   di
    4d1a:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4d1e:	06                   	push   es
    4d1f:	57                   	push   di
    4d20:	9a 9b 3b 61 4d       	call   0x4d61:0x3b9b
    4d25:	89 c7                	mov    di,ax
    4d27:	8e c2                	mov    es,dx
    4d29:	06                   	push   es
    4d2a:	57                   	push   di
    4d2b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d2e:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4d32:	9b dd 86 e8 fe       	fld    QWORD PTR [bp-0x118]
    4d37:	9b dc 86 e0 fe       	fadd   QWORD PTR [bp-0x120]
    4d3c:	9b dd 9e d8 fe       	fstp   QWORD PTR [bp-0x128]
    4d41:	90                   	nop
    4d42:	9b                   	fwait
    4d43:	ff b6 de fe          	push   WORD PTR [bp-0x122]
    4d47:	ff b6 dc fe          	push   WORD PTR [bp-0x124]
    4d4b:	ff b6 da fe          	push   WORD PTR [bp-0x126]
    4d4f:	ff b6 d8 fe          	push   WORD PTR [bp-0x128]
    4d53:	bf 79 38             	mov    di,0x3879
    4d56:	0e                   	push   cs
    4d57:	57                   	push   di
    4d58:	c4 be bc fe          	les    di,DWORD PTR [bp-0x144]
    4d5c:	06                   	push   es
    4d5d:	57                   	push   di
    4d5e:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    4d63:	89 c7                	mov    di,ax
    4d65:	8e c2                	mov    es,dx
    4d67:	06                   	push   es
    4d68:	57                   	push   di
    4d69:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d6c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4d70:	c9                   	leave
    4d71:	ca 08 00             	retf   0x8
    4d74:	59                   	pop    cx
    4d75:	4e                   	dec    si
    4d76:	34 4e                	xor    al,0x4e
    4d78:	e5 4d                	in     ax,0x4d
    4d7a:	d6                   	(bad)
    4d7b:	4d                   	dec    bp
    4d7c:	82 4e 15 4e          	or     BYTE PTR [bp+0x15],0x4e
    4d80:	82 4e f6 4d          	or     BYTE PTR [bp-0xa],0x4d
    4d84:	00 00                	add    BYTE PTR [bx+si],al
    4d86:	00 00                	add    BYTE PTR [bx+si],al
    4d88:	ff 00                	inc    WORD PTR [bx+si]
    4d8a:	00 00                	add    BYTE PTR [bx+si],al
    4d8c:	55                   	push   bp
    4d8d:	89 e5                	mov    bp,sp
    4d8f:	b8 04 00             	mov    ax,0x4
    4d92:	9a 44 04 06 4e       	call   0x4e06:0x444
    4d97:	83 ec 04             	sub    sp,0x4
    4d9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d9d:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    4da2:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4da5:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4da8:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    4dac:	b0 00                	mov    al,0x0
    4dae:	74 01                	je     0x4db1
    4db0:	40                   	inc    ax
    4db1:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    4db5:	08 c0                	or     al,al
    4db7:	75 03                	jne    0x4dbc
    4db9:	e9 ee 00             	jmp    0x4eaa
    4dbc:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4dbf:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4dc2:	2d 21 00             	sub    ax,0x21
    4dc5:	3d 07 00             	cmp    ax,0x7
    4dc8:	76 03                	jbe    0x4dcd
    4dca:	e9 b5 00             	jmp    0x4e82
    4dcd:	89 c3                	mov    bx,ax
    4dcf:	d1 e3                	shl    bx,1
    4dd1:	2e ff a7 74 4d       	jmp    WORD PTR cs:[bx+0x4d74]
    4dd6:	6a 00                	push   0x0
    4dd8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4ddb:	06                   	push   es
    4ddc:	57                   	push   di
    4ddd:	9a d0 1c f1 4d       	call   0x4df1:0x1cd0
    4de2:	e9 9d 00             	jmp    0x4e82
    4de5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4de8:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    4dec:	06                   	push   es
    4ded:	57                   	push   di
    4dee:	9a d0 1c 11 4e       	call   0x4e11:0x1cd0
    4df3:	e9 8c 00             	jmp    0x4e82
    4df6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4df9:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4dfd:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    4e01:	71 05                	jno    0x4e08
    4e03:	9a 3e 04 25 4e       	call   0x4e25:0x43e
    4e08:	50                   	push   ax
    4e09:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4e0c:	06                   	push   es
    4e0d:	57                   	push   di
    4e0e:	9a d0 1c 30 4e       	call   0x4e30:0x1cd0
    4e13:	eb 6d                	jmp    0x4e82
    4e15:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4e18:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4e1c:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    4e20:	71 05                	jno    0x4e27
    4e22:	9a 3e 04 4a 4e       	call   0x4e4a:0x43e
    4e27:	50                   	push   ax
    4e28:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4e2b:	06                   	push   es
    4e2c:	57                   	push   di
    4e2d:	9a d0 1c 55 4e       	call   0x4e55:0x1cd0
    4e32:	eb 4e                	jmp    0x4e82
    4e34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e37:	06                   	push   es
    4e38:	57                   	push   di
    4e39:	9a f4 18 61 4e       	call   0x4e61:0x18f4
    4e3e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4e41:	26 03 45 0a          	add    ax,WORD PTR es:[di+0xa]
    4e45:	71 05                	jno    0x4e4c
    4e47:	9a 3e 04 73 4e       	call   0x4e73:0x43e
    4e4c:	50                   	push   ax
    4e4d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4e50:	06                   	push   es
    4e51:	57                   	push   di
    4e52:	9a d0 1c 7e 4e       	call   0x4e7e:0x1cd0
    4e57:	eb 29                	jmp    0x4e82
    4e59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e5c:	06                   	push   es
    4e5d:	57                   	push   di
    4e5e:	9a f4 18 9b 50       	call   0x509b:0x18f4
    4e63:	8b d0                	mov    dx,ax
    4e65:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4e68:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4e6c:	2b c2                	sub    ax,dx
    4e6e:	71 05                	jno    0x4e75
    4e70:	9a 3e 04 90 4e       	call   0x4e90:0x43e
    4e75:	50                   	push   ax
    4e76:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4e79:	06                   	push   es
    4e7a:	57                   	push   di
    4e7b:	9a d0 1c ef 4e       	call   0x4eef:0x1cd0
    4e80:	eb 00                	jmp    0x4e82
    4e82:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4e85:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4e88:	31 d2                	xor    dx,dx
    4e8a:	bf 84 4d             	mov    di,0x4d84
    4e8d:	9a 16 04 e4 4e       	call   0x4ee4:0x416
    4e92:	3c 21                	cmp    al,0x21
    4e94:	72 14                	jb     0x4eaa
    4e96:	3c 24                	cmp    al,0x24
    4e98:	76 08                	jbe    0x4ea2
    4e9a:	3c 26                	cmp    al,0x26
    4e9c:	74 04                	je     0x4ea2
    4e9e:	3c 28                	cmp    al,0x28
    4ea0:	75 08                	jne    0x4eaa
    4ea2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4ea5:	31 c0                	xor    ax,ax
    4ea7:	26 89 05             	mov    WORD PTR es:[di],ax
    4eaa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ead:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    4eb2:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4eb5:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4eb8:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    4ebc:	b0 00                	mov    al,0x0
    4ebe:	74 01                	je     0x4ec1
    4ec0:	40                   	inc    ax
    4ec1:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    4ec5:	08 c0                	or     al,al
    4ec7:	74 6e                	je     0x4f37
    4ec9:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4ecc:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4ecf:	3d 27 00             	cmp    ax,0x27
    4ed2:	75 1f                	jne    0x4ef3
    4ed4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4ed7:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4edb:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    4edf:	71 05                	jno    0x4ee6
    4ee1:	9a 3e 04 08 4f       	call   0x4f08:0x43e
    4ee6:	50                   	push   ax
    4ee7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4eea:	06                   	push   es
    4eeb:	57                   	push   di
    4eec:	9a d0 1c 13 4f       	call   0x4f13:0x1cd0
    4ef1:	eb 24                	jmp    0x4f17
    4ef3:	3d 25 00             	cmp    ax,0x25
    4ef6:	75 1f                	jne    0x4f17
    4ef8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4efb:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4eff:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    4f03:	71 05                	jno    0x4f0a
    4f05:	9a 3e 04 25 4f       	call   0x4f25:0x43e
    4f0a:	50                   	push   ax
    4f0b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4f0e:	06                   	push   es
    4f0f:	57                   	push   di
    4f10:	9a d0 1c 52 4f       	call   0x4f52:0x1cd0
    4f15:	eb 00                	jmp    0x4f17
    4f17:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4f1a:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4f1d:	31 d2                	xor    dx,dx
    4f1f:	bf 84 4d             	mov    di,0x4d84
    4f22:	9a 16 04 60 4f       	call   0x4f60:0x416
    4f27:	3c 25                	cmp    al,0x25
    4f29:	74 04                	je     0x4f2f
    4f2b:	3c 27                	cmp    al,0x27
    4f2d:	75 08                	jne    0x4f37
    4f2f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4f32:	31 c0                	xor    ax,ax
    4f34:	26 89 05             	mov    WORD PTR es:[di],ax
    4f37:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4f3a:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    4f3e:	74 14                	je     0x4f54
    4f40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f43:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    4f48:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    4f4d:	06                   	push   es
    4f4e:	57                   	push   di
    4f4f:	9a 30 22 7d 4f       	call   0x4f7d:0x2230
    4f54:	c9                   	leave
    4f55:	ca 0e 00             	retf   0xe
    4f58:	55                   	push   bp
    4f59:	89 e5                	mov    bp,sp
    4f5b:	31 c0                	xor    ax,ax
    4f5d:	9a 44 04 8b 4f       	call   0x4f8b:0x444
    4f62:	6a 01                	push   0x1
    4f64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f67:	26 c4 bd ec 02       	les    di,DWORD PTR es:[di+0x2ec]
    4f6c:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    4f70:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    4f74:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4f78:	06                   	push   es
    4f79:	57                   	push   di
    4f7a:	9a b2 77 9c 4f       	call   0x4f9c:0x77b2
    4f7f:	c9                   	leave
    4f80:	ca 08 00             	retf   0x8
    4f83:	55                   	push   bp
    4f84:	89 e5                	mov    bp,sp
    4f86:	31 c0                	xor    ax,ax
    4f88:	9a 44 04 aa 4f       	call   0x4faa:0x444
    4f8d:	6a 03                	push   0x3
    4f8f:	6a 00                	push   0x0
    4f91:	6a 00                	push   0x0
    4f93:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4f97:	06                   	push   es
    4f98:	57                   	push   di
    4f99:	9a b2 77 bd 4f       	call   0x4fbd:0x77b2
    4f9e:	c9                   	leave
    4f9f:	ca 08 00             	retf   0x8
    4fa2:	55                   	push   bp
    4fa3:	89 e5                	mov    bp,sp
    4fa5:	31 c0                	xor    ax,ax
    4fa7:	9a 44 04 cb 4f       	call   0x4fcb:0x444
    4fac:	68 05 01             	push   0x105
    4faf:	bf ea 01             	mov    di,0x1ea
    4fb2:	1e                   	push   ds
    4fb3:	57                   	push   di
    4fb4:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4fb8:	06                   	push   es
    4fb9:	57                   	push   di
    4fba:	9a b2 77 dc 4f       	call   0x4fdc:0x77b2
    4fbf:	c9                   	leave
    4fc0:	ca 08 00             	retf   0x8
    4fc3:	55                   	push   bp
    4fc4:	89 e5                	mov    bp,sp
    4fc6:	31 c0                	xor    ax,ax
    4fc8:	9a 44 04 eb 4f       	call   0x4feb:0x444
    4fcd:	6a 04                	push   0x4
    4fcf:	6a 00                	push   0x0
    4fd1:	6a 00                	push   0x0
    4fd3:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4fd7:	06                   	push   es
    4fd8:	57                   	push   di
    4fd9:	9a b2 77 f9 4f       	call   0x4ff9:0x77b2
    4fde:	c9                   	leave
    4fdf:	ca 08 00             	retf   0x8
    4fe2:	55                   	push   bp
    4fe3:	89 e5                	mov    bp,sp
    4fe5:	b8 04 00             	mov    ax,0x4
    4fe8:	9a 44 04 08 50       	call   0x5008:0x444
    4fed:	83 ec 04             	sub    sp,0x4
    4ff0:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    4ff4:	06                   	push   es
    4ff5:	57                   	push   di
    4ff6:	9a 45 5d 74 50       	call   0x5074:0x5d45
    4ffb:	c9                   	leave
    4ffc:	ca 08 00             	retf   0x8
    4fff:	55                   	push   bp
    5000:	89 e5                	mov    bp,sp
    5002:	b8 04 00             	mov    ax,0x4
    5005:	9a 44 04 83 50       	call   0x5083:0x444
    500a:	83 ec 04             	sub    sp,0x4
    500d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5010:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    5015:	b0 00                	mov    al,0x0
    5017:	75 01                	jne    0x501a
    5019:	40                   	inc    ax
    501a:	8a c8                	mov    cl,al
    501c:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    5022:	b0 00                	mov    al,0x0
    5024:	77 01                	ja     0x5027
    5026:	40                   	inc    ax
    5027:	8a d0                	mov    dl,al
    5029:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    502f:	b0 00                	mov    al,0x0
    5031:	76 01                	jbe    0x5034
    5033:	40                   	inc    ax
    5034:	22 c2                	and    al,dl
    5036:	0a c1                	or     al,cl
    5038:	08 c0                	or     al,al
    503a:	74 3a                	je     0x5076
    503c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5040:	31 c0                	xor    ax,ax
    5042:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    5046:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    504a:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    504e:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    5052:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5055:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    5059:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    505c:	06                   	push   es
    505d:	57                   	push   di
    505e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5061:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    5065:	6a 02                	push   0x2
    5067:	6a 00                	push   0x0
    5069:	6a 00                	push   0x0
    506b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    506f:	06                   	push   es
    5070:	57                   	push   di
    5071:	9a b2 77 03 51       	call   0x5103:0x77b2
    5076:	c9                   	leave
    5077:	ca 0c 00             	retf   0xc
    507a:	55                   	push   bp
    507b:	89 e5                	mov    bp,sp
    507d:	b8 04 00             	mov    ax,0x4
    5080:	9a 44 04 a2 50       	call   0x50a2:0x444
    5085:	83 ec 04             	sub    sp,0x4
    5088:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    508c:	74 03                	je     0x5091
    508e:	e9 9c 00             	jmp    0x512d
    5091:	ff 76 14             	push   WORD PTR [bp+0x14]
    5094:	ff 76 12             	push   WORD PTR [bp+0x12]
    5097:	bf c1 05             	mov    di,0x5c1
    509a:	b8 b5 50             	mov    ax,0x50b5
    509d:	50                   	push   ax
    509e:	57                   	push   di
    509f:	9a 55 22 bc 50       	call   0x50bc:0x2255
    50a4:	08 c0                	or     al,al
    50a6:	75 03                	jne    0x50ab
    50a8:	e9 82 00             	jmp    0x512d
    50ab:	ff 76 14             	push   WORD PTR [bp+0x14]
    50ae:	ff 76 12             	push   WORD PTR [bp+0x12]
    50b1:	bf c1 05             	mov    di,0x5c1
    50b4:	b8 e4 50             	mov    ax,0x50e4
    50b7:	50                   	push   ax
    50b8:	57                   	push   di
    50b9:	9a 73 22 eb 50       	call   0x50eb:0x2273
    50be:	89 c7                	mov    di,ax
    50c0:	8e c2                	mov    es,dx
    50c2:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    50c7:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    50cc:	74 5f                	je     0x512d
    50ce:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    50d2:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    50d5:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    50d8:	6a 08                	push   0x8
    50da:	ff 76 14             	push   WORD PTR [bp+0x14]
    50dd:	ff 76 12             	push   WORD PTR [bp+0x12]
    50e0:	bf c1 05             	mov    di,0x5c1
    50e3:	b8 4f 51             	mov    ax,0x514f
    50e6:	50                   	push   ax
    50e7:	57                   	push   di
    50e8:	9a 73 22 3a 51       	call   0x513a:0x2273
    50ed:	89 c7                	mov    di,ax
    50ef:	8e c2                	mov    es,dx
    50f1:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    50f6:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    50fb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50fe:	06                   	push   es
    50ff:	57                   	push   di
    5100:	9a b2 77 0d 51       	call   0x510d:0x77b2
    5105:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5108:	06                   	push   es
    5109:	57                   	push   di
    510a:	9a 03 73 94 51       	call   0x5194:0x7303
    510f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5112:	06                   	push   es
    5113:	57                   	push   di
    5114:	b8 ff 4f             	mov    ax,0x4fff
    5117:	ba bf 51             	mov    dx,0x51bf
    511a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    511d:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    5121:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    5125:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    5129:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    512d:	c9                   	leave
    512e:	ca 10 00             	retf   0x10
    5131:	55                   	push   bp
    5132:	89 e5                	mov    bp,sp
    5134:	b8 04 00             	mov    ax,0x4
    5137:	9a 44 04 56 51       	call   0x5156:0x444
    513c:	83 ec 04             	sub    sp,0x4
    513f:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    5143:	75 51                	jne    0x5196
    5145:	ff 76 14             	push   WORD PTR [bp+0x14]
    5148:	ff 76 12             	push   WORD PTR [bp+0x12]
    514b:	bf c1 05             	mov    di,0x5c1
    514e:	b8 66 51             	mov    ax,0x5166
    5151:	50                   	push   ax
    5152:	57                   	push   di
    5153:	9a 55 22 6d 51       	call   0x516d:0x2255
    5158:	08 c0                	or     al,al
    515a:	74 3a                	je     0x5196
    515c:	ff 76 14             	push   WORD PTR [bp+0x14]
    515f:	ff 76 12             	push   WORD PTR [bp+0x12]
    5162:	bf c1 05             	mov    di,0x5c1
    5165:	b8 84 54             	mov    ax,0x5484
    5168:	50                   	push   ax
    5169:	57                   	push   di
    516a:	9a 73 22 a2 51       	call   0x51a2:0x2273
    516f:	89 c7                	mov    di,ax
    5171:	8e c2                	mov    es,dx
    5173:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    5178:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    517d:	74 17                	je     0x5196
    517f:	6a 08                	push   0x8
    5181:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    5186:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    518b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    518f:	06                   	push   es
    5190:	57                   	push   di
    5191:	9a b2 77 64 6f       	call   0x6f64:0x77b2
    5196:	c9                   	leave
    5197:	ca 10 00             	retf   0x10
    519a:	55                   	push   bp
    519b:	89 e5                	mov    bp,sp
    519d:	31 c0                	xor    ax,ax
    519f:	9a 44 04 d6 51       	call   0x51d6:0x444
    51a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51a7:	26 c4 bd 20 02       	les    di,DWORD PTR es:[di+0x220]
    51ac:	06                   	push   es
    51ad:	57                   	push   di
    51ae:	9a 17 2f ff ff       	call   0xffff:0x2f17
    51b3:	08 c0                	or     al,al
    51b5:	74 0a                	je     0x51c1
    51b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51ba:	06                   	push   es
    51bb:	57                   	push   di
    51bc:	9a 29 52 27 52       	call   0x5227:0x5229
    51c1:	c9                   	leave
    51c2:	ca 08 00             	retf   0x8
    51c5:	00 00                	add    BYTE PTR [bx+si],al
    51c7:	00 00                	add    BYTE PTR [bx+si],al
    51c9:	ff                   	(bad)
    51ca:	ff 00                	inc    WORD PTR [bx+si]
    51cc:	00 55 89             	add    BYTE PTR [di-0x77],dl
    51cf:	e5 b8                	in     ax,0xb8
    51d1:	22 00                	and    al,BYTE PTR [bx+si]
    51d3:	9a 44 04 06 52       	call   0x5206:0x444
    51d8:	83 ec 22             	sub    sp,0x22
    51db:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    51df:	06                   	push   es
    51e0:	57                   	push   di
    51e1:	9a 04 2a 4d 52       	call   0x524d:0x2a04
    51e6:	89 c7                	mov    di,ax
    51e8:	8e c2                	mov    es,dx
    51ea:	06                   	push   es
    51eb:	57                   	push   di
    51ec:	9a d2 21 9e 52       	call   0x529e:0x21d2
    51f1:	50                   	push   ax
    51f2:	8d 7e de             	lea    di,[bp-0x22]
    51f5:	16                   	push   ss
    51f6:	57                   	push   di
    51f7:	9a ff ff 00 00       	call   0x0:0xffff
    51fc:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    51ff:	99                   	cwd
    5200:	bf c5 51             	mov    di,0x51c5
    5203:	9a 16 04 32 52       	call   0x5232:0x416
    5208:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    520b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    520e:	c9                   	leave
    520f:	ca 02 00             	retf   0x2
    5212:	00 01                	add    BYTE PTR [bx+di],al
    5214:	09 01                	or     WORD PTR [bx+di],ax
    5216:	20 03                	and    BYTE PTR [bp+di],al
    5218:	20 20                	and    BYTE PTR [bx+si],ah
    521a:	20 00                	and    BYTE PTR [bx+si],al
    521c:	80 ff ff             	cmp    bh,0xff
    521f:	ff                   	(bad)
    5220:	7f 00                	jg     0x5222
    5222:	00 00                	add    BYTE PTR [bx+si],al
    5224:	00 61 56             	add    BYTE PTR [bx+di+0x56],ah
    5227:	42                   	inc    dx
    5228:	52                   	push   dx
    5229:	55                   	push   bp
    522a:	89 e5                	mov    bp,sp
    522c:	b8 0e 04             	mov    ax,0x40e
    522f:	9a 44 04 58 52       	call   0x5258:0x444
    5234:	81 ec 0e 04          	sub    sp,0x40e
    5238:	6a 01                	push   0x1
    523a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    523d:	06                   	push   es
    523e:	57                   	push   di
    523f:	9a cd 59 47 54       	call   0x5447:0x59cd
    5244:	8d be fc fe          	lea    di,[bp-0x104]
    5248:	16                   	push   ss
    5249:	57                   	push   di
    524a:	9a 4e 20 76 52       	call   0x5276:0x204e
    524f:	8d be fc fe          	lea    di,[bp-0x104]
    5253:	16                   	push   ss
    5254:	57                   	push   di
    5255:	9a f5 09 5d 52       	call   0x525d:0x9f5
    525a:	9a 08 04 f2 52       	call   0x52f2:0x408
    525f:	b8 23 52             	mov    ax,0x5223
    5262:	0e                   	push   cs
    5263:	50                   	push   ax
    5264:	55                   	push   bp
    5265:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5269:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    526d:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5271:	06                   	push   es
    5272:	57                   	push   di
    5273:	9a 04 2a ab 52       	call   0x52ab:0x2a04
    5278:	89 c7                	mov    di,ax
    527a:	8e c2                	mov    es,dx
    527c:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    5280:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    5284:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    5288:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    528d:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    5291:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    5295:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5299:	06                   	push   es
    529a:	57                   	push   di
    529b:	9a 99 20 ba 52       	call   0x52ba:0x2099
    52a0:	6a 0a                	push   0xa
    52a2:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    52a6:	06                   	push   es
    52a7:	57                   	push   di
    52a8:	9a 04 2a c7 52       	call   0x52c7:0x2a04
    52ad:	89 c7                	mov    di,ax
    52af:	8e c2                	mov    es,dx
    52b1:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    52b5:	06                   	push   es
    52b6:	57                   	push   di
    52b7:	9a f5 11 d6 52       	call   0x52d6:0x11f5
    52bc:	6a 02                	push   0x2
    52be:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    52c2:	06                   	push   es
    52c3:	57                   	push   di
    52c4:	9a 04 2a 16 54       	call   0x5416:0x2a04
    52c9:	89 c7                	mov    di,ax
    52cb:	8e c2                	mov    es,dx
    52cd:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    52d1:	06                   	push   es
    52d2:	57                   	push   di
    52d3:	9a 78 12 25 54       	call   0x5425:0x1278
    52d8:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    52dd:	eb 03                	jmp    0x52e2
    52df:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    52e2:	8d be fc fe          	lea    di,[bp-0x104]
    52e6:	16                   	push   ss
    52e7:	57                   	push   di
    52e8:	bf 12 52             	mov    di,0x5212
    52eb:	0e                   	push   cs
    52ec:	57                   	push   di
    52ed:	6a 00                	push   0x0
    52ef:	9a b5 0d f7 52       	call   0x52f7:0xdb5
    52f4:	9a 78 0c fc 52       	call   0x52fc:0xc78
    52f9:	9a 08 04 2a 53       	call   0x532a:0x408
    52fe:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    5302:	75 db                	jne    0x52df
    5304:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5307:	26 c4 bd 08 03       	les    di,DWORD PTR es:[di+0x308]
    530c:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    5310:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    5314:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5319:	06                   	push   es
    531a:	57                   	push   di
    531b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    531e:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    5322:	2d 01 00             	sub    ax,0x1
    5325:	71 05                	jno    0x532c
    5327:	9a 3e 04 6a 53       	call   0x536a:0x43e
    532c:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    5330:	31 c0                	xor    ax,ax
    5332:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    5336:	7e 03                	jle    0x533b
    5338:	e9 c8 00             	jmp    0x5403
    533b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    533e:	eb 03                	jmp    0x5343
    5340:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    5343:	8d be f0 fc          	lea    di,[bp-0x310]
    5347:	16                   	push   ss
    5348:	57                   	push   di
    5349:	ff 76 fe             	push   WORD PTR [bp-0x2]
    534c:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5350:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5355:	06                   	push   es
    5356:	57                   	push   di
    5357:	26 c4 3d             	les    di,DWORD PTR es:[di]
    535a:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    535e:	8d be fc fd          	lea    di,[bp-0x204]
    5362:	16                   	push   ss
    5363:	57                   	push   di
    5364:	68 ff 00             	push   0xff
    5367:	9a e7 17 7a 53       	call   0x537a:0x17e7
    536c:	bf 13 52             	mov    di,0x5213
    536f:	0e                   	push   cs
    5370:	57                   	push   di
    5371:	8d be fc fd          	lea    di,[bp-0x204]
    5375:	16                   	push   ss
    5376:	57                   	push   di
    5377:	9a 78 18 93 53       	call   0x5393:0x1878
    537c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    537f:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    5383:	7e 26                	jle    0x53ab
    5385:	8d be fc fd          	lea    di,[bp-0x204]
    5389:	16                   	push   ss
    538a:	57                   	push   di
    538b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    538e:	6a 01                	push   0x1
    5390:	9a 75 19 a9 53       	call   0x53a9:0x1975
    5395:	bf 15 52             	mov    di,0x5215
    5398:	0e                   	push   cs
    5399:	57                   	push   di
    539a:	8d be fc fd          	lea    di,[bp-0x204]
    539e:	16                   	push   ss
    539f:	57                   	push   di
    53a0:	68 ff 00             	push   0xff
    53a3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    53a6:	9a 16 19 bf 53       	call   0x53bf:0x1916
    53ab:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    53af:	75 bb                	jne    0x536c
    53b1:	8d be f0 fc          	lea    di,[bp-0x310]
    53b5:	16                   	push   ss
    53b6:	57                   	push   di
    53b7:	bf 17 52             	mov    di,0x5217
    53ba:	0e                   	push   cs
    53bb:	57                   	push   di
    53bc:	9a cd 17 ca 53       	call   0x53ca:0x17cd
    53c1:	8d be fc fd          	lea    di,[bp-0x204]
    53c5:	16                   	push   ss
    53c6:	57                   	push   di
    53c7:	9a 4c 18 d8 53       	call   0x53d8:0x184c
    53cc:	8d be fc fd          	lea    di,[bp-0x204]
    53d0:	16                   	push   ss
    53d1:	57                   	push   di
    53d2:	68 ff 00             	push   0xff
    53d5:	9a e7 17 eb 53       	call   0x53eb:0x17e7
    53da:	8d be fc fe          	lea    di,[bp-0x104]
    53de:	16                   	push   ss
    53df:	57                   	push   di
    53e0:	8d be fc fd          	lea    di,[bp-0x204]
    53e4:	16                   	push   ss
    53e5:	57                   	push   di
    53e6:	6a 00                	push   0x0
    53e8:	9a b5 0d f0 53       	call   0x53f0:0xdb5
    53ed:	9a 78 0c f5 53       	call   0x53f5:0xc78
    53f2:	9a 08 04 51 54       	call   0x5451:0x408
    53f7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    53fa:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    53fe:	74 03                	je     0x5403
    5400:	e9 3d ff             	jmp    0x5340
    5403:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    5407:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    540b:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    540f:	6a 06                	push   0x6
    5411:	06                   	push   es
    5412:	57                   	push   di
    5413:	9a 04 2a 32 54       	call   0x5432:0x2a04
    5418:	89 c7                	mov    di,ax
    541a:	8e c2                	mov    es,dx
    541c:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    5420:	06                   	push   es
    5421:	57                   	push   di
    5422:	9a f5 11 41 54       	call   0x5441:0x11f5
    5427:	6a 00                	push   0x0
    5429:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    542d:	06                   	push   es
    542e:	57                   	push   di
    542f:	9a 04 2a b5 54       	call   0x54b5:0x2a04
    5434:	89 c7                	mov    di,ax
    5436:	8e c2                	mov    es,dx
    5438:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    543c:	06                   	push   es
    543d:	57                   	push   di
    543e:	9a 78 12 dc 54       	call   0x54dc:0x1278
    5443:	55                   	push   bp
    5444:	9a cd 51 9d 56       	call   0x569d:0x51cd
    5449:	05 02 00             	add    ax,0x2
    544c:	73 05                	jae    0x5453
    544e:	9a 3e 04 5b 54       	call   0x545b:0x43e
    5453:	31 d2                	xor    dx,dx
    5455:	bf 1b 52             	mov    di,0x521b
    5458:	9a 16 04 6f 54       	call   0x546f:0x416
    545d:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    5461:	8d be f2 fb          	lea    di,[bp-0x40e]
    5465:	16                   	push   ss
    5466:	57                   	push   di
    5467:	bf 17 52             	mov    di,0x5217
    546a:	0e                   	push   cs
    546b:	57                   	push   di
    546c:	9a cd 17 89 54       	call   0x5489:0x17cd
    5471:	8d be f2 fc          	lea    di,[bp-0x30e]
    5475:	16                   	push   ss
    5476:	57                   	push   di
    5477:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    547a:	26 c4 bd f8 02       	les    di,DWORD PTR es:[di+0x2f8]
    547f:	06                   	push   es
    5480:	57                   	push   di
    5481:	9a 53 1d 01 55       	call   0x5501:0x1d53
    5486:	9a 4c 18 97 54       	call   0x5497:0x184c
    548b:	8d be fc fd          	lea    di,[bp-0x204]
    548f:	16                   	push   ss
    5490:	57                   	push   di
    5491:	68 ff 00             	push   0xff
    5494:	9a e7 17 a9 54       	call   0x54a9:0x17e7
    5499:	6a 00                	push   0x0
    549b:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    549f:	b9 05 00             	mov    cx,0x5
    54a2:	f7 e9                	imul   cx
    54a4:	71 05                	jno    0x54ab
    54a6:	9a 3e 04 bf 54       	call   0x54bf:0x43e
    54ab:	50                   	push   ax
    54ac:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    54b0:	06                   	push   es
    54b1:	57                   	push   di
    54b2:	9a 72 2a d1 54       	call   0x54d1:0x2a72
    54b7:	5a                   	pop    dx
    54b8:	2b c2                	sub    ax,dx
    54ba:	71 05                	jno    0x54c1
    54bc:	9a 3e 04 ec 54       	call   0x54ec:0x43e
    54c1:	50                   	push   ax
    54c2:	8d be fc fd          	lea    di,[bp-0x204]
    54c6:	16                   	push   ss
    54c7:	57                   	push   di
    54c8:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    54cc:	06                   	push   es
    54cd:	57                   	push   di
    54ce:	9a 04 2a 32 55       	call   0x5532:0x2a04
    54d3:	89 c7                	mov    di,ax
    54d5:	8e c2                	mov    es,dx
    54d7:	06                   	push   es
    54d8:	57                   	push   di
    54d9:	9a 09 1f 59 55       	call   0x5559:0x1f09
    54de:	8d be f2 fb          	lea    di,[bp-0x40e]
    54e2:	16                   	push   ss
    54e3:	57                   	push   di
    54e4:	bf 17 52             	mov    di,0x5217
    54e7:	0e                   	push   cs
    54e8:	57                   	push   di
    54e9:	9a cd 17 06 55       	call   0x5506:0x17cd
    54ee:	8d be f2 fc          	lea    di,[bp-0x30e]
    54f2:	16                   	push   ss
    54f3:	57                   	push   di
    54f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    54f7:	26 c4 bd fc 02       	les    di,DWORD PTR es:[di+0x2fc]
    54fc:	06                   	push   es
    54fd:	57                   	push   di
    54fe:	9a 53 1d 7e 55       	call   0x557e:0x1d53
    5503:	9a 4c 18 14 55       	call   0x5514:0x184c
    5508:	8d be fc fd          	lea    di,[bp-0x204]
    550c:	16                   	push   ss
    550d:	57                   	push   di
    550e:	68 ff 00             	push   0xff
    5511:	9a e7 17 26 55       	call   0x5526:0x17e7
    5516:	6a 00                	push   0x0
    5518:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    551c:	b9 04 00             	mov    cx,0x4
    551f:	f7 e9                	imul   cx
    5521:	71 05                	jno    0x5528
    5523:	9a 3e 04 3c 55       	call   0x553c:0x43e
    5528:	50                   	push   ax
    5529:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    552d:	06                   	push   es
    552e:	57                   	push   di
    552f:	9a 72 2a 4e 55       	call   0x554e:0x2a72
    5534:	5a                   	pop    dx
    5535:	2b c2                	sub    ax,dx
    5537:	71 05                	jno    0x553e
    5539:	9a 3e 04 69 55       	call   0x5569:0x43e
    553e:	50                   	push   ax
    553f:	8d be fc fd          	lea    di,[bp-0x204]
    5543:	16                   	push   ss
    5544:	57                   	push   di
    5545:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5549:	06                   	push   es
    554a:	57                   	push   di
    554b:	9a 04 2a af 55       	call   0x55af:0x2a04
    5550:	89 c7                	mov    di,ax
    5552:	8e c2                	mov    es,dx
    5554:	06                   	push   es
    5555:	57                   	push   di
    5556:	9a 09 1f d6 55       	call   0x55d6:0x1f09
    555b:	8d be f2 fb          	lea    di,[bp-0x40e]
    555f:	16                   	push   ss
    5560:	57                   	push   di
    5561:	bf 17 52             	mov    di,0x5217
    5564:	0e                   	push   cs
    5565:	57                   	push   di
    5566:	9a cd 17 83 55       	call   0x5583:0x17cd
    556b:	8d be f2 fc          	lea    di,[bp-0x30e]
    556f:	16                   	push   ss
    5570:	57                   	push   di
    5571:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5574:	26 c4 bd 00 03       	les    di,DWORD PTR es:[di+0x300]
    5579:	06                   	push   es
    557a:	57                   	push   di
    557b:	9a 53 1d fb 55       	call   0x55fb:0x1d53
    5580:	9a 4c 18 91 55       	call   0x5591:0x184c
    5585:	8d be fc fd          	lea    di,[bp-0x204]
    5589:	16                   	push   ss
    558a:	57                   	push   di
    558b:	68 ff 00             	push   0xff
    558e:	9a e7 17 a3 55       	call   0x55a3:0x17e7
    5593:	6a 00                	push   0x0
    5595:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5599:	b9 03 00             	mov    cx,0x3
    559c:	f7 e9                	imul   cx
    559e:	71 05                	jno    0x55a5
    55a0:	9a 3e 04 b9 55       	call   0x55b9:0x43e
    55a5:	50                   	push   ax
    55a6:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    55aa:	06                   	push   es
    55ab:	57                   	push   di
    55ac:	9a 72 2a cb 55       	call   0x55cb:0x2a72
    55b1:	5a                   	pop    dx
    55b2:	2b c2                	sub    ax,dx
    55b4:	71 05                	jno    0x55bb
    55b6:	9a 3e 04 e6 55       	call   0x55e6:0x43e
    55bb:	50                   	push   ax
    55bc:	8d be fc fd          	lea    di,[bp-0x204]
    55c0:	16                   	push   ss
    55c1:	57                   	push   di
    55c2:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    55c6:	06                   	push   es
    55c7:	57                   	push   di
    55c8:	9a 04 2a 2c 56       	call   0x562c:0x2a04
    55cd:	89 c7                	mov    di,ax
    55cf:	8e c2                	mov    es,dx
    55d1:	06                   	push   es
    55d2:	57                   	push   di
    55d3:	9a 09 1f 53 56       	call   0x5653:0x1f09
    55d8:	8d be f2 fb          	lea    di,[bp-0x40e]
    55dc:	16                   	push   ss
    55dd:	57                   	push   di
    55de:	bf 17 52             	mov    di,0x5217
    55e1:	0e                   	push   cs
    55e2:	57                   	push   di
    55e3:	9a cd 17 00 56       	call   0x5600:0x17cd
    55e8:	8d be f2 fc          	lea    di,[bp-0x30e]
    55ec:	16                   	push   ss
    55ed:	57                   	push   di
    55ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55f1:	26 c4 bd 04 03       	les    di,DWORD PTR es:[di+0x304]
    55f6:	06                   	push   es
    55f7:	57                   	push   di
    55f8:	9a 53 1d bd 57       	call   0x57bd:0x1d53
    55fd:	9a 4c 18 0e 56       	call   0x560e:0x184c
    5602:	8d be fc fd          	lea    di,[bp-0x204]
    5606:	16                   	push   ss
    5607:	57                   	push   di
    5608:	68 ff 00             	push   0xff
    560b:	9a e7 17 20 56       	call   0x5620:0x17e7
    5610:	6a 00                	push   0x0
    5612:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5616:	b9 02 00             	mov    cx,0x2
    5619:	f7 e9                	imul   cx
    561b:	71 05                	jno    0x5622
    561d:	9a 3e 04 36 56       	call   0x5636:0x43e
    5622:	50                   	push   ax
    5623:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5627:	06                   	push   es
    5628:	57                   	push   di
    5629:	9a 72 2a 48 56       	call   0x5648:0x2a72
    562e:	5a                   	pop    dx
    562f:	2b c2                	sub    ax,dx
    5631:	71 05                	jno    0x5638
    5633:	9a 3e 04 6a 56       	call   0x566a:0x43e
    5638:	50                   	push   ax
    5639:	8d be fc fd          	lea    di,[bp-0x204]
    563d:	16                   	push   ss
    563e:	57                   	push   di
    563f:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5643:	06                   	push   es
    5644:	57                   	push   di
    5645:	9a 04 2a ff ff       	call   0xffff:0x2a04
    564a:	89 c7                	mov    di,ax
    564c:	8e c2                	mov    es,dx
    564e:	06                   	push   es
    564f:	57                   	push   di
    5650:	9a 09 1f ff ff       	call   0xffff:0x1f09
    5655:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5659:	83 c4 06             	add    sp,0x6
    565c:	b8 81 56             	mov    ax,0x5681
    565f:	0e                   	push   cs
    5660:	50                   	push   ax
    5661:	8d be fc fe          	lea    di,[bp-0x104]
    5665:	16                   	push   ss
    5666:	57                   	push   di
    5667:	9a 4f 0a 6f 56       	call   0x566f:0xa4f
    566c:	9a 08 04 8e 56       	call   0x568e:0x408
    5671:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5674:	26 c4 bd 08 03       	les    di,DWORD PTR es:[di+0x308]
    5679:	06                   	push   es
    567a:	57                   	push   di
    567b:	9a e3 49 b2 56       	call   0x56b2:0x49e3
    5680:	cb                   	retf
    5681:	c9                   	leave
    5682:	ca 04 00             	retf   0x4
    5685:	55                   	push   bp
    5686:	89 e5                	mov    bp,sp
    5688:	b8 04 00             	mov    ax,0x4
    568b:	9a 44 04 d9 56       	call   0x56d9:0x444
    5690:	83 ec 04             	sub    sp,0x4
    5693:	6a 00                	push   0x0
    5695:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5698:	06                   	push   es
    5699:	57                   	push   di
    569a:	9a cd 59 14 5a       	call   0x5a14:0x59cd
    569f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56a2:	26 c4 bd 08 03       	les    di,DWORD PTR es:[di+0x308]
    56a7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    56aa:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    56ad:	06                   	push   es
    56ae:	57                   	push   di
    56af:	9a 3f 4a bc 56       	call   0x56bc:0x4a3f
    56b4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    56b7:	06                   	push   es
    56b8:	57                   	push   di
    56b9:	9a ff 49 c6 56       	call   0x56c6:0x49ff
    56be:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    56c1:	06                   	push   es
    56c2:	57                   	push   di
    56c3:	9a e3 49 82 57       	call   0x5782:0x49e3
    56c8:	c9                   	leave
    56c9:	ca 08 00             	retf   0x8
    56cc:	01 09                	add    WORD PTR [bx+di],cx
    56ce:	01 20                	add    WORD PTR [bx+si],sp
    56d0:	55                   	push   bp
    56d1:	89 e5                	mov    bp,sp
    56d3:	b8 06 02             	mov    ax,0x206
    56d6:	9a 44 04 14 57       	call   0x5714:0x444
    56db:	81 ec 06 02          	sub    sp,0x206
    56df:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    56e2:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    56e7:	75 03                	jne    0x56ec
    56e9:	e9 d8 02             	jmp    0x59c4
    56ec:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    56f1:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    56f4:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    56f8:	3d 00 00             	cmp    ax,0x0
    56fb:	75 32                	jne    0x572f
    56fd:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5700:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    5704:	76 27                	jbe    0x572d
    5706:	8d be fe fd          	lea    di,[bp-0x202]
    570a:	16                   	push   ss
    570b:	57                   	push   di
    570c:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    570f:	06                   	push   es
    5710:	57                   	push   di
    5711:	9a cd 17 1e 57       	call   0x571e:0x17cd
    5716:	bf cc 56             	mov    di,0x56cc
    5719:	0e                   	push   cs
    571a:	57                   	push   di
    571b:	9a 4c 18 2b 57       	call   0x572b:0x184c
    5720:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5723:	06                   	push   es
    5724:	57                   	push   di
    5725:	ff 76 0e             	push   WORD PTR [bp+0xe]
    5728:	9a e7 17 5b 57       	call   0x575b:0x17e7
    572d:	eb 49                	jmp    0x5778
    572f:	3d 01 00             	cmp    ax,0x1
    5732:	75 44                	jne    0x5778
    5734:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5737:	26 8a 05             	mov    al,BYTE PTR es:[di]
    573a:	30 e4                	xor    ah,ah
    573c:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    5740:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    5744:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    5747:	7d 2d                	jge    0x5776
    5749:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    574d:	8d be fe fd          	lea    di,[bp-0x202]
    5751:	16                   	push   ss
    5752:	57                   	push   di
    5753:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5756:	06                   	push   es
    5757:	57                   	push   di
    5758:	9a cd 17 65 57       	call   0x5765:0x17cd
    575d:	bf ce 56             	mov    di,0x56ce
    5760:	0e                   	push   cs
    5761:	57                   	push   di
    5762:	9a 4c 18 72 57       	call   0x5772:0x184c
    5767:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    576a:	06                   	push   es
    576b:	57                   	push   di
    576c:	ff 76 0e             	push   WORD PTR [bp+0xe]
    576f:	9a e7 17 89 57       	call   0x5789:0x17e7
    5774:	eb ca                	jmp    0x5740
    5776:	eb 00                	jmp    0x5778
    5778:	ff 76 0c             	push   WORD PTR [bp+0xc]
    577b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    577e:	bf 0c 01             	mov    di,0x10c
    5781:	b8 99 57             	mov    ax,0x5799
    5784:	50                   	push   ax
    5785:	57                   	push   di
    5786:	9a 55 22 a0 57       	call   0x57a0:0x2255
    578b:	08 c0                	or     al,al
    578d:	74 6b                	je     0x57fa
    578f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5792:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5795:	bf 0c 01             	mov    di,0x10c
    5798:	b8 86 58             	mov    ax,0x5886
    579b:	50                   	push   ax
    579c:	57                   	push   di
    579d:	9a 73 22 cb 57       	call   0x57cb:0x2273
    57a2:	89 c7                	mov    di,ax
    57a4:	8e c2                	mov    es,dx
    57a6:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    57aa:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    57ae:	8d be fa fd          	lea    di,[bp-0x206]
    57b2:	16                   	push   ss
    57b3:	57                   	push   di
    57b4:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    57b8:	06                   	push   es
    57b9:	57                   	push   di
    57ba:	9a 53 1d 3f 58       	call   0x583f:0x1d53
    57bf:	8d be 00 ff          	lea    di,[bp-0x100]
    57c3:	16                   	push   ss
    57c4:	57                   	push   di
    57c5:	68 ff 00             	push   0xff
    57c8:	9a e7 17 f6 57       	call   0x57f6:0x17e7
    57cd:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    57d2:	b0 00                	mov    al,0x0
    57d4:	76 01                	jbe    0x57d7
    57d6:	40                   	inc    ax
    57d7:	8a d0                	mov    dl,al
    57d9:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    57de:	b0 00                	mov    al,0x0
    57e0:	75 01                	jne    0x57e3
    57e2:	40                   	inc    ax
    57e3:	22 c2                	and    al,dl
    57e5:	08 c0                	or     al,al
    57e7:	74 11                	je     0x57fa
    57e9:	8d be 00 ff          	lea    di,[bp-0x100]
    57ed:	16                   	push   ss
    57ee:	57                   	push   di
    57ef:	6a 01                	push   0x1
    57f1:	6a 01                	push   0x1
    57f3:	9a 75 19 0b 58       	call   0x580b:0x1975
    57f8:	eb d3                	jmp    0x57cd
    57fa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    57fd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5800:	bf ad 0d             	mov    di,0xdad
    5803:	b8 1b 58             	mov    ax,0x581b
    5806:	50                   	push   ax
    5807:	57                   	push   di
    5808:	9a 55 22 22 58       	call   0x5822:0x2255
    580d:	08 c0                	or     al,al
    580f:	74 6b                	je     0x587c
    5811:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5814:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5817:	bf ad 0d             	mov    di,0xdad
    581a:	b8 ff ff             	mov    ax,0xffff
    581d:	50                   	push   ax
    581e:	57                   	push   di
    581f:	9a 73 22 4d 58       	call   0x584d:0x2273
    5824:	89 c7                	mov    di,ax
    5826:	8e c2                	mov    es,dx
    5828:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    582c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    5830:	8d be fa fd          	lea    di,[bp-0x206]
    5834:	16                   	push   ss
    5835:	57                   	push   di
    5836:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    583a:	06                   	push   es
    583b:	57                   	push   di
    583c:	9a 53 1d c1 58       	call   0x58c1:0x1d53
    5841:	8d be 00 ff          	lea    di,[bp-0x100]
    5845:	16                   	push   ss
    5846:	57                   	push   di
    5847:	68 ff 00             	push   0xff
    584a:	9a e7 17 78 58       	call   0x5878:0x17e7
    584f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5854:	b0 00                	mov    al,0x0
    5856:	76 01                	jbe    0x5859
    5858:	40                   	inc    ax
    5859:	8a d0                	mov    dl,al
    585b:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    5860:	b0 00                	mov    al,0x0
    5862:	75 01                	jne    0x5865
    5864:	40                   	inc    ax
    5865:	22 c2                	and    al,dl
    5867:	08 c0                	or     al,al
    5869:	74 11                	je     0x587c
    586b:	8d be 00 ff          	lea    di,[bp-0x100]
    586f:	16                   	push   ss
    5870:	57                   	push   di
    5871:	6a 01                	push   0x1
    5873:	6a 01                	push   0x1
    5875:	9a 75 19 8d 58       	call   0x588d:0x1975
    587a:	eb d3                	jmp    0x584f
    587c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    587f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5882:	bf 17 06             	mov    di,0x617
    5885:	b8 9d 58             	mov    ax,0x589d
    5888:	50                   	push   ax
    5889:	57                   	push   di
    588a:	9a 55 22 a4 58       	call   0x58a4:0x2255
    588f:	08 c0                	or     al,al
    5891:	74 6b                	je     0x58fe
    5893:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5896:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5899:	bf 17 06             	mov    di,0x617
    589c:	b8 f1 59             	mov    ax,0x59f1
    589f:	50                   	push   ax
    58a0:	57                   	push   di
    58a1:	9a 73 22 cf 58       	call   0x58cf:0x2273
    58a6:	89 c7                	mov    di,ax
    58a8:	8e c2                	mov    es,dx
    58aa:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    58ae:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    58b2:	8d be fa fd          	lea    di,[bp-0x206]
    58b6:	16                   	push   ss
    58b7:	57                   	push   di
    58b8:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    58bc:	06                   	push   es
    58bd:	57                   	push   di
    58be:	9a 53 1d 44 5a       	call   0x5a44:0x1d53
    58c3:	8d be 00 ff          	lea    di,[bp-0x100]
    58c7:	16                   	push   ss
    58c8:	57                   	push   di
    58c9:	68 ff 00             	push   0xff
    58cc:	9a e7 17 fa 58       	call   0x58fa:0x17e7
    58d1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    58d6:	b0 00                	mov    al,0x0
    58d8:	76 01                	jbe    0x58db
    58da:	40                   	inc    ax
    58db:	8a d0                	mov    dl,al
    58dd:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    58e2:	b0 00                	mov    al,0x0
    58e4:	75 01                	jne    0x58e7
    58e6:	40                   	inc    ax
    58e7:	22 c2                	and    al,dl
    58e9:	08 c0                	or     al,al
    58eb:	74 11                	je     0x58fe
    58ed:	8d be 00 ff          	lea    di,[bp-0x100]
    58f1:	16                   	push   ss
    58f2:	57                   	push   di
    58f3:	6a 01                	push   0x1
    58f5:	6a 01                	push   0x1
    58f7:	9a 75 19 0f 59       	call   0x590f:0x1975
    58fc:	eb d3                	jmp    0x58d1
    58fe:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5901:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5904:	bf 22 00             	mov    di,0x22
    5907:	b8 22 59             	mov    ax,0x5922
    590a:	50                   	push   ax
    590b:	57                   	push   di
    590c:	9a 55 22 29 59       	call   0x5929:0x2255
    5911:	08 c0                	or     al,al
    5913:	75 03                	jne    0x5918
    5915:	e9 84 00             	jmp    0x599c
    5918:	ff 76 0c             	push   WORD PTR [bp+0xc]
    591b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    591e:	bf 22 00             	mov    di,0x22
    5921:	b8 ff ff             	mov    ax,0xffff
    5924:	50                   	push   ax
    5925:	57                   	push   di
    5926:	9a 73 22 54 59       	call   0x5954:0x2273
    592b:	89 c7                	mov    di,ax
    592d:	8e c2                	mov    es,dx
    592f:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    5933:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    5937:	8d be fa fd          	lea    di,[bp-0x206]
    593b:	16                   	push   ss
    593c:	57                   	push   di
    593d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    5941:	06                   	push   es
    5942:	57                   	push   di
    5943:	9a 24 15 ff ff       	call   0xffff:0x1524
    5948:	8d be 00 ff          	lea    di,[bp-0x100]
    594c:	16                   	push   ss
    594d:	57                   	push   di
    594e:	68 ff 00             	push   0xff
    5951:	9a e7 17 7f 59       	call   0x597f:0x17e7
    5956:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    595a:	7e 40                	jle    0x599c
    595c:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    5960:	30 e4                	xor    ah,ah
    5962:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    5966:	83 be fe fe 12       	cmp    WORD PTR [bp-0x102],0x12
    596b:	7d 2f                	jge    0x599c
    596d:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    5971:	8d be fa fd          	lea    di,[bp-0x206]
    5975:	16                   	push   ss
    5976:	57                   	push   di
    5977:	bf ce 56             	mov    di,0x56ce
    597a:	0e                   	push   cs
    597b:	57                   	push   di
    597c:	9a cd 17 8a 59       	call   0x598a:0x17cd
    5981:	8d be 00 ff          	lea    di,[bp-0x100]
    5985:	16                   	push   ss
    5986:	57                   	push   di
    5987:	9a 4c 18 98 59       	call   0x5998:0x184c
    598c:	8d be 00 ff          	lea    di,[bp-0x100]
    5990:	16                   	push   ss
    5991:	57                   	push   di
    5992:	68 ff 00             	push   0xff
    5995:	9a e7 17 aa 59       	call   0x59aa:0x17e7
    599a:	eb ca                	jmp    0x5966
    599c:	8d be fe fd          	lea    di,[bp-0x202]
    59a0:	16                   	push   ss
    59a1:	57                   	push   di
    59a2:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    59a5:	06                   	push   es
    59a6:	57                   	push   di
    59a7:	9a cd 17 b5 59       	call   0x59b5:0x17cd
    59ac:	8d be 00 ff          	lea    di,[bp-0x100]
    59b0:	16                   	push   ss
    59b1:	57                   	push   di
    59b2:	9a 4c 18 c2 59       	call   0x59c2:0x184c
    59b7:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    59ba:	06                   	push   es
    59bb:	57                   	push   di
    59bc:	ff 76 0e             	push   WORD PTR [bp+0xe]
    59bf:	9a e7 17 d6 59       	call   0x59d6:0x17e7
    59c4:	c9                   	leave
    59c5:	ca 0e 00             	retf   0xe
    59c8:	01 09                	add    WORD PTR [bx+di],cx
    59ca:	00 01                	add    BYTE PTR [bx+di],al
    59cc:	20 55 89             	and    BYTE PTR [di-0x77],dl
    59cf:	e5 b8                	in     ax,0xb8
    59d1:	04 03                	add    al,0x3
    59d3:	9a 44 04 25 5a       	call   0x5a25:0x444
    59d8:	81 ec 04 03          	sub    sp,0x304
    59dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59df:	26 c4 bd 08 03       	les    di,DWORD PTR es:[di+0x308]
    59e4:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    59e8:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    59ec:	06                   	push   es
    59ed:	57                   	push   di
    59ee:	9a e3 49 ff ff       	call   0xffff:0x49e3
    59f3:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    59f8:	8d be 00 ff          	lea    di,[bp-0x100]
    59fc:	16                   	push   ss
    59fd:	57                   	push   di
    59fe:	68 ff 00             	push   0xff
    5a01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a04:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    5a09:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    5a0e:	6a 00                	push   0x0
    5a10:	55                   	push   bp
    5a11:	9a d0 56 af 5a       	call   0x5aaf:0x56d0
    5a16:	8d be fc fd          	lea    di,[bp-0x204]
    5a1a:	16                   	push   ss
    5a1b:	57                   	push   di
    5a1c:	8d be 00 ff          	lea    di,[bp-0x100]
    5a20:	16                   	push   ss
    5a21:	57                   	push   di
    5a22:	9a cd 17 2f 5a       	call   0x5a2f:0x17cd
    5a27:	bf c8 59             	mov    di,0x59c8
    5a2a:	0e                   	push   cs
    5a2b:	57                   	push   di
    5a2c:	9a 4c 18 49 5a       	call   0x5a49:0x184c
    5a31:	8d be fc fc          	lea    di,[bp-0x304]
    5a35:	16                   	push   ss
    5a36:	57                   	push   di
    5a37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a3a:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    5a3f:	06                   	push   es
    5a40:	57                   	push   di
    5a41:	9a 53 1d df 5a       	call   0x5adf:0x1d53
    5a46:	9a 4c 18 57 5a       	call   0x5a57:0x184c
    5a4b:	8d be 00 ff          	lea    di,[bp-0x100]
    5a4f:	16                   	push   ss
    5a50:	57                   	push   di
    5a51:	68 ff 00             	push   0xff
    5a54:	9a e7 17 c0 5a       	call   0x5ac0:0x17e7
    5a59:	8d be 00 ff          	lea    di,[bp-0x100]
    5a5d:	16                   	push   ss
    5a5e:	57                   	push   di
    5a5f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5a63:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5a68:	06                   	push   es
    5a69:	57                   	push   di
    5a6a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a6d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5a71:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    5a75:	75 17                	jne    0x5a8e
    5a77:	bf ca 59             	mov    di,0x59ca
    5a7a:	0e                   	push   cs
    5a7b:	57                   	push   di
    5a7c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5a80:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5a85:	06                   	push   es
    5a86:	57                   	push   di
    5a87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a8a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5a8e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5a93:	8d be 00 ff          	lea    di,[bp-0x100]
    5a97:	16                   	push   ss
    5a98:	57                   	push   di
    5a99:	68 ff 00             	push   0xff
    5a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a9f:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    5aa4:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    5aa9:	6a 0a                	push   0xa
    5aab:	55                   	push   bp
    5aac:	9a d0 56 10 5b       	call   0x5b10:0x56d0
    5ab1:	8d be fc fd          	lea    di,[bp-0x204]
    5ab5:	16                   	push   ss
    5ab6:	57                   	push   di
    5ab7:	8d be 00 ff          	lea    di,[bp-0x100]
    5abb:	16                   	push   ss
    5abc:	57                   	push   di
    5abd:	9a cd 17 ca 5a       	call   0x5aca:0x17cd
    5ac2:	bf cb 59             	mov    di,0x59cb
    5ac5:	0e                   	push   cs
    5ac6:	57                   	push   di
    5ac7:	9a 4c 18 e4 5a       	call   0x5ae4:0x184c
    5acc:	8d be fc fc          	lea    di,[bp-0x304]
    5ad0:	16                   	push   ss
    5ad1:	57                   	push   di
    5ad2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ad5:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    5ada:	06                   	push   es
    5adb:	57                   	push   di
    5adc:	9a 53 1d 5e 5b       	call   0x5b5e:0x1d53
    5ae1:	9a 4c 18 f2 5a       	call   0x5af2:0x184c
    5ae6:	8d be 00 ff          	lea    di,[bp-0x100]
    5aea:	16                   	push   ss
    5aeb:	57                   	push   di
    5aec:	68 ff 00             	push   0xff
    5aef:	9a e7 17 3f 5b       	call   0x5b3f:0x17e7
    5af4:	8d be 00 ff          	lea    di,[bp-0x100]
    5af8:	16                   	push   ss
    5af9:	57                   	push   di
    5afa:	68 ff 00             	push   0xff
    5afd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b00:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    5b05:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    5b0a:	6a 25                	push   0x25
    5b0c:	55                   	push   bp
    5b0d:	9a d0 56 2e 5b       	call   0x5b2e:0x56d0
    5b12:	8d be 00 ff          	lea    di,[bp-0x100]
    5b16:	16                   	push   ss
    5b17:	57                   	push   di
    5b18:	68 ff 00             	push   0xff
    5b1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b1e:	26 ff b5 96 01       	push   WORD PTR es:[di+0x196]
    5b23:	26 ff b5 94 01       	push   WORD PTR es:[di+0x194]
    5b28:	6a 46                	push   0x46
    5b2a:	55                   	push   bp
    5b2b:	9a d0 56 d5 5b       	call   0x5bd5:0x56d0
    5b30:	8d be fc fd          	lea    di,[bp-0x204]
    5b34:	16                   	push   ss
    5b35:	57                   	push   di
    5b36:	8d be 00 ff          	lea    di,[bp-0x100]
    5b3a:	16                   	push   ss
    5b3b:	57                   	push   di
    5b3c:	9a cd 17 49 5b       	call   0x5b49:0x17cd
    5b41:	bf cb 59             	mov    di,0x59cb
    5b44:	0e                   	push   cs
    5b45:	57                   	push   di
    5b46:	9a 4c 18 63 5b       	call   0x5b63:0x184c
    5b4b:	8d be fc fc          	lea    di,[bp-0x304]
    5b4f:	16                   	push   ss
    5b50:	57                   	push   di
    5b51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b54:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    5b59:	06                   	push   es
    5b5a:	57                   	push   di
    5b5b:	9a 53 1d ff ff       	call   0xffff:0x1d53
    5b60:	9a 4c 18 71 5b       	call   0x5b71:0x184c
    5b65:	8d be 00 ff          	lea    di,[bp-0x100]
    5b69:	16                   	push   ss
    5b6a:	57                   	push   di
    5b6b:	68 ff 00             	push   0xff
    5b6e:	9a e7 17 ce 5b       	call   0x5bce:0x17e7
    5b73:	8d be 00 ff          	lea    di,[bp-0x100]
    5b77:	16                   	push   ss
    5b78:	57                   	push   di
    5b79:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5b7d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5b82:	06                   	push   es
    5b83:	57                   	push   di
    5b84:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5b87:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5b8b:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    5b8f:	75 17                	jne    0x5ba8
    5b91:	bf ca 59             	mov    di,0x59ca
    5b94:	0e                   	push   cs
    5b95:	57                   	push   di
    5b96:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5b9a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5b9f:	06                   	push   es
    5ba0:	57                   	push   di
    5ba1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ba4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5ba8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5bad:	8d be 00 ff          	lea    di,[bp-0x100]
    5bb1:	16                   	push   ss
    5bb2:	57                   	push   di
    5bb3:	68 ff 00             	push   0xff
    5bb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bb9:	26 ff b5 56 05       	push   WORD PTR es:[di+0x556]
    5bbe:	26 ff b5 54 05       	push   WORD PTR es:[di+0x554]
    5bc3:	a1 ec 01             	mov    ax,ds:0x1ec
    5bc6:	05 0a 00             	add    ax,0xa
    5bc9:	71 05                	jno    0x5bd0
    5bcb:	9a 3e 04 e6 5b       	call   0x5be6:0x43e
    5bd0:	50                   	push   ax
    5bd1:	55                   	push   bp
    5bd2:	9a d0 56 28 5c       	call   0x5c28:0x56d0
    5bd7:	8d be fc fd          	lea    di,[bp-0x204]
    5bdb:	16                   	push   ss
    5bdc:	57                   	push   di
    5bdd:	8d be 00 ff          	lea    di,[bp-0x100]
    5be1:	16                   	push   ss
    5be2:	57                   	push   di
    5be3:	9a cd 17 f0 5b       	call   0x5bf0:0x17cd
    5be8:	bf c8 59             	mov    di,0x59c8
    5beb:	0e                   	push   cs
    5bec:	57                   	push   di
    5bed:	9a 4c 18 fe 5b       	call   0x5bfe:0x184c
    5bf2:	8d be 00 ff          	lea    di,[bp-0x100]
    5bf6:	16                   	push   ss
    5bf7:	57                   	push   di
    5bf8:	68 ff 00             	push   0xff
    5bfb:	9a e7 17 21 5c       	call   0x5c21:0x17e7
    5c00:	8d be 00 ff          	lea    di,[bp-0x100]
    5c04:	16                   	push   ss
    5c05:	57                   	push   di
    5c06:	68 ff 00             	push   0xff
    5c09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c0c:	26 ff b5 02 04       	push   WORD PTR es:[di+0x402]
    5c11:	26 ff b5 00 04       	push   WORD PTR es:[di+0x400]
    5c16:	a1 f6 01             	mov    ax,ds:0x1f6
    5c19:	05 06 00             	add    ax,0x6
    5c1c:	71 05                	jno    0x5c23
    5c1e:	9a 3e 04 4b 5c       	call   0x5c4b:0x43e
    5c23:	50                   	push   ax
    5c24:	55                   	push   bp
    5c25:	9a d0 56 52 5c       	call   0x5c52:0x56d0
    5c2a:	8d be 00 ff          	lea    di,[bp-0x100]
    5c2e:	16                   	push   ss
    5c2f:	57                   	push   di
    5c30:	68 ff 00             	push   0xff
    5c33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c36:	26 ff b5 52 05       	push   WORD PTR es:[di+0x552]
    5c3b:	26 ff b5 50 05       	push   WORD PTR es:[di+0x550]
    5c40:	a1 f8 01             	mov    ax,ds:0x1f8
    5c43:	05 06 00             	add    ax,0x6
    5c46:	71 05                	jno    0x5c4d
    5c48:	9a 3e 04 a7 5c       	call   0x5ca7:0x43e
    5c4d:	50                   	push   ax
    5c4e:	55                   	push   bp
    5c4f:	9a d0 56 96 5c       	call   0x5c96:0x56d0
    5c54:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5c59:	76 18                	jbe    0x5c73
    5c5b:	8d be 00 ff          	lea    di,[bp-0x100]
    5c5f:	16                   	push   ss
    5c60:	57                   	push   di
    5c61:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5c65:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5c6a:	06                   	push   es
    5c6b:	57                   	push   di
    5c6c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5c6f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5c73:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5c78:	8d be 00 ff          	lea    di,[bp-0x100]
    5c7c:	16                   	push   ss
    5c7d:	57                   	push   di
    5c7e:	68 ff 00             	push   0xff
    5c81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c84:	26 ff b5 7e 04       	push   WORD PTR es:[di+0x47e]
    5c89:	26 ff b5 7c 04       	push   WORD PTR es:[di+0x47c]
    5c8e:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    5c92:	55                   	push   bp
    5c93:	9a d0 56 e9 5c       	call   0x5ce9:0x56d0
    5c98:	8d be fc fd          	lea    di,[bp-0x204]
    5c9c:	16                   	push   ss
    5c9d:	57                   	push   di
    5c9e:	8d be 00 ff          	lea    di,[bp-0x100]
    5ca2:	16                   	push   ss
    5ca3:	57                   	push   di
    5ca4:	9a cd 17 b1 5c       	call   0x5cb1:0x17cd
    5ca9:	bf c8 59             	mov    di,0x59c8
    5cac:	0e                   	push   cs
    5cad:	57                   	push   di
    5cae:	9a 4c 18 bb 5c       	call   0x5cbb:0x184c
    5cb3:	bf c8 59             	mov    di,0x59c8
    5cb6:	0e                   	push   cs
    5cb7:	57                   	push   di
    5cb8:	9a 4c 18 c9 5c       	call   0x5cc9:0x184c
    5cbd:	8d be 00 ff          	lea    di,[bp-0x100]
    5cc1:	16                   	push   ss
    5cc2:	57                   	push   di
    5cc3:	68 ff 00             	push   0xff
    5cc6:	9a e7 17 23 5e       	call   0x5e23:0x17e7
    5ccb:	8d be 00 ff          	lea    di,[bp-0x100]
    5ccf:	16                   	push   ss
    5cd0:	57                   	push   di
    5cd1:	68 ff 00             	push   0xff
    5cd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cd7:	26 ff b5 f6 03       	push   WORD PTR es:[di+0x3f6]
    5cdc:	26 ff b5 f4 03       	push   WORD PTR es:[di+0x3f4]
    5ce1:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    5ce5:	55                   	push   bp
    5ce6:	9a d0 56 2d 5d       	call   0x5d2d:0x56d0
    5ceb:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5cf0:	76 18                	jbe    0x5d0a
    5cf2:	8d be 00 ff          	lea    di,[bp-0x100]
    5cf6:	16                   	push   ss
    5cf7:	57                   	push   di
    5cf8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5cfc:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5d01:	06                   	push   es
    5d02:	57                   	push   di
    5d03:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5d06:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5d0a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5d0f:	8d be 00 ff          	lea    di,[bp-0x100]
    5d13:	16                   	push   ss
    5d14:	57                   	push   di
    5d15:	68 ff 00             	push   0xff
    5d18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d1b:	26 ff b5 0a 04       	push   WORD PTR es:[di+0x40a]
    5d20:	26 ff b5 08 04       	push   WORD PTR es:[di+0x408]
    5d25:	ff 36 ee 01          	push   WORD PTR ds:0x1ee
    5d29:	55                   	push   bp
    5d2a:	9a d0 56 4d 5d       	call   0x5d4d:0x56d0
    5d2f:	8d be 00 ff          	lea    di,[bp-0x100]
    5d33:	16                   	push   ss
    5d34:	57                   	push   di
    5d35:	68 ff 00             	push   0xff
    5d38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d3b:	26 ff b5 76 04       	push   WORD PTR es:[di+0x476]
    5d40:	26 ff b5 74 04       	push   WORD PTR es:[di+0x474]
    5d45:	ff 36 f4 01          	push   WORD PTR ds:0x1f4
    5d49:	55                   	push   bp
    5d4a:	9a d0 56 91 5d       	call   0x5d91:0x56d0
    5d4f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5d54:	76 18                	jbe    0x5d6e
    5d56:	8d be 00 ff          	lea    di,[bp-0x100]
    5d5a:	16                   	push   ss
    5d5b:	57                   	push   di
    5d5c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5d60:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5d65:	06                   	push   es
    5d66:	57                   	push   di
    5d67:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5d6a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5d6e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5d73:	8d be 00 ff          	lea    di,[bp-0x100]
    5d77:	16                   	push   ss
    5d78:	57                   	push   di
    5d79:	68 ff 00             	push   0xff
    5d7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d7f:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    5d84:	26 ff b5 0c 04       	push   WORD PTR es:[di+0x40c]
    5d89:	ff 36 ee 01          	push   WORD PTR ds:0x1ee
    5d8d:	55                   	push   bp
    5d8e:	9a d0 56 b1 5d       	call   0x5db1:0x56d0
    5d93:	8d be 00 ff          	lea    di,[bp-0x100]
    5d97:	16                   	push   ss
    5d98:	57                   	push   di
    5d99:	68 ff 00             	push   0xff
    5d9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d9f:	26 ff b5 7a 04       	push   WORD PTR es:[di+0x47a]
    5da4:	26 ff b5 78 04       	push   WORD PTR es:[di+0x478]
    5da9:	ff 36 f4 01          	push   WORD PTR ds:0x1f4
    5dad:	55                   	push   bp
    5dae:	9a d0 56 12 5e       	call   0x5e12:0x56d0
    5db3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5db8:	76 18                	jbe    0x5dd2
    5dba:	8d be 00 ff          	lea    di,[bp-0x100]
    5dbe:	16                   	push   ss
    5dbf:	57                   	push   di
    5dc0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5dc4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5dc9:	06                   	push   es
    5dca:	57                   	push   di
    5dcb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5dce:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5dd2:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    5dd6:	75 17                	jne    0x5def
    5dd8:	bf ca 59             	mov    di,0x59ca
    5ddb:	0e                   	push   cs
    5ddc:	57                   	push   di
    5ddd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5de1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5de6:	06                   	push   es
    5de7:	57                   	push   di
    5de8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5deb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5def:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5df4:	8d be 00 ff          	lea    di,[bp-0x100]
    5df8:	16                   	push   ss
    5df9:	57                   	push   di
    5dfa:	68 ff 00             	push   0xff
    5dfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e00:	26 ff b5 12 04       	push   WORD PTR es:[di+0x412]
    5e05:	26 ff b5 10 04       	push   WORD PTR es:[di+0x410]
    5e0a:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    5e0e:	55                   	push   bp
    5e0f:	9a d0 56 65 5e       	call   0x5e65:0x56d0
    5e14:	8d be fc fd          	lea    di,[bp-0x204]
    5e18:	16                   	push   ss
    5e19:	57                   	push   di
    5e1a:	8d be 00 ff          	lea    di,[bp-0x100]
    5e1e:	16                   	push   ss
    5e1f:	57                   	push   di
    5e20:	9a cd 17 2d 5e       	call   0x5e2d:0x17cd
    5e25:	bf c8 59             	mov    di,0x59c8
    5e28:	0e                   	push   cs
    5e29:	57                   	push   di
    5e2a:	9a 4c 18 37 5e       	call   0x5e37:0x184c
    5e2f:	bf c8 59             	mov    di,0x59c8
    5e32:	0e                   	push   cs
    5e33:	57                   	push   di
    5e34:	9a 4c 18 45 5e       	call   0x5e45:0x184c
    5e39:	8d be 00 ff          	lea    di,[bp-0x100]
    5e3d:	16                   	push   ss
    5e3e:	57                   	push   di
    5e3f:	68 ff 00             	push   0xff
    5e42:	9a e7 17 ba 5e       	call   0x5eba:0x17e7
    5e47:	8d be 00 ff          	lea    di,[bp-0x100]
    5e4b:	16                   	push   ss
    5e4c:	57                   	push   di
    5e4d:	68 ff 00             	push   0xff
    5e50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e53:	26 ff b5 8e 04       	push   WORD PTR es:[di+0x48e]
    5e58:	26 ff b5 8c 04       	push   WORD PTR es:[di+0x48c]
    5e5d:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    5e61:	55                   	push   bp
    5e62:	9a d0 56 a9 5e       	call   0x5ea9:0x56d0
    5e67:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5e6c:	76 18                	jbe    0x5e86
    5e6e:	8d be 00 ff          	lea    di,[bp-0x100]
    5e72:	16                   	push   ss
    5e73:	57                   	push   di
    5e74:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5e78:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5e7d:	06                   	push   es
    5e7e:	57                   	push   di
    5e7f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e82:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5e86:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5e8b:	8d be 00 ff          	lea    di,[bp-0x100]
    5e8f:	16                   	push   ss
    5e90:	57                   	push   di
    5e91:	68 ff 00             	push   0xff
    5e94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e97:	26 ff b5 5a 05       	push   WORD PTR es:[di+0x55a]
    5e9c:	26 ff b5 58 05       	push   WORD PTR es:[di+0x558]
    5ea1:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    5ea5:	55                   	push   bp
    5ea6:	9a d0 56 fc 5e       	call   0x5efc:0x56d0
    5eab:	8d be fc fd          	lea    di,[bp-0x204]
    5eaf:	16                   	push   ss
    5eb0:	57                   	push   di
    5eb1:	8d be 00 ff          	lea    di,[bp-0x100]
    5eb5:	16                   	push   ss
    5eb6:	57                   	push   di
    5eb7:	9a cd 17 c4 5e       	call   0x5ec4:0x17cd
    5ebc:	bf c8 59             	mov    di,0x59c8
    5ebf:	0e                   	push   cs
    5ec0:	57                   	push   di
    5ec1:	9a 4c 18 ce 5e       	call   0x5ece:0x184c
    5ec6:	bf c8 59             	mov    di,0x59c8
    5ec9:	0e                   	push   cs
    5eca:	57                   	push   di
    5ecb:	9a 4c 18 dc 5e       	call   0x5edc:0x184c
    5ed0:	8d be 00 ff          	lea    di,[bp-0x100]
    5ed4:	16                   	push   ss
    5ed5:	57                   	push   di
    5ed6:	68 ff 00             	push   0xff
    5ed9:	9a e7 17 51 5f       	call   0x5f51:0x17e7
    5ede:	8d be 00 ff          	lea    di,[bp-0x100]
    5ee2:	16                   	push   ss
    5ee3:	57                   	push   di
    5ee4:	68 ff 00             	push   0xff
    5ee7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5eea:	26 ff b5 62 05       	push   WORD PTR es:[di+0x562]
    5eef:	26 ff b5 60 05       	push   WORD PTR es:[di+0x560]
    5ef4:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    5ef8:	55                   	push   bp
    5ef9:	9a d0 56 40 5f       	call   0x5f40:0x56d0
    5efe:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5f03:	76 18                	jbe    0x5f1d
    5f05:	8d be 00 ff          	lea    di,[bp-0x100]
    5f09:	16                   	push   ss
    5f0a:	57                   	push   di
    5f0b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5f0f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5f14:	06                   	push   es
    5f15:	57                   	push   di
    5f16:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f19:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5f1d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5f22:	8d be 00 ff          	lea    di,[bp-0x100]
    5f26:	16                   	push   ss
    5f27:	57                   	push   di
    5f28:	68 ff 00             	push   0xff
    5f2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f2e:	26 ff b5 16 04       	push   WORD PTR es:[di+0x416]
    5f33:	26 ff b5 14 04       	push   WORD PTR es:[di+0x414]
    5f38:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    5f3c:	55                   	push   bp
    5f3d:	9a d0 56 93 5f       	call   0x5f93:0x56d0
    5f42:	8d be fc fd          	lea    di,[bp-0x204]
    5f46:	16                   	push   ss
    5f47:	57                   	push   di
    5f48:	8d be 00 ff          	lea    di,[bp-0x100]
    5f4c:	16                   	push   ss
    5f4d:	57                   	push   di
    5f4e:	9a cd 17 5b 5f       	call   0x5f5b:0x17cd
    5f53:	bf c8 59             	mov    di,0x59c8
    5f56:	0e                   	push   cs
    5f57:	57                   	push   di
    5f58:	9a 4c 18 65 5f       	call   0x5f65:0x184c
    5f5d:	bf c8 59             	mov    di,0x59c8
    5f60:	0e                   	push   cs
    5f61:	57                   	push   di
    5f62:	9a 4c 18 73 5f       	call   0x5f73:0x184c
    5f67:	8d be 00 ff          	lea    di,[bp-0x100]
    5f6b:	16                   	push   ss
    5f6c:	57                   	push   di
    5f6d:	68 ff 00             	push   0xff
    5f70:	9a e7 17 e8 5f       	call   0x5fe8:0x17e7
    5f75:	8d be 00 ff          	lea    di,[bp-0x100]
    5f79:	16                   	push   ss
    5f7a:	57                   	push   di
    5f7b:	68 ff 00             	push   0xff
    5f7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f81:	26 ff b5 92 04       	push   WORD PTR es:[di+0x492]
    5f86:	26 ff b5 90 04       	push   WORD PTR es:[di+0x490]
    5f8b:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    5f8f:	55                   	push   bp
    5f90:	9a d0 56 d7 5f       	call   0x5fd7:0x56d0
    5f95:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5f9a:	76 18                	jbe    0x5fb4
    5f9c:	8d be 00 ff          	lea    di,[bp-0x100]
    5fa0:	16                   	push   ss
    5fa1:	57                   	push   di
    5fa2:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5fa6:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5fab:	06                   	push   es
    5fac:	57                   	push   di
    5fad:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5fb0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5fb4:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5fb9:	8d be 00 ff          	lea    di,[bp-0x100]
    5fbd:	16                   	push   ss
    5fbe:	57                   	push   di
    5fbf:	68 ff 00             	push   0xff
    5fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fc5:	26 ff b5 5e 05       	push   WORD PTR es:[di+0x55e]
    5fca:	26 ff b5 5c 05       	push   WORD PTR es:[di+0x55c]
    5fcf:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    5fd3:	55                   	push   bp
    5fd4:	9a d0 56 2a 60       	call   0x602a:0x56d0
    5fd9:	8d be fc fd          	lea    di,[bp-0x204]
    5fdd:	16                   	push   ss
    5fde:	57                   	push   di
    5fdf:	8d be 00 ff          	lea    di,[bp-0x100]
    5fe3:	16                   	push   ss
    5fe4:	57                   	push   di
    5fe5:	9a cd 17 f2 5f       	call   0x5ff2:0x17cd
    5fea:	bf c8 59             	mov    di,0x59c8
    5fed:	0e                   	push   cs
    5fee:	57                   	push   di
    5fef:	9a 4c 18 fc 5f       	call   0x5ffc:0x184c
    5ff4:	bf c8 59             	mov    di,0x59c8
    5ff7:	0e                   	push   cs
    5ff8:	57                   	push   di
    5ff9:	9a 4c 18 0a 60       	call   0x600a:0x184c
    5ffe:	8d be 00 ff          	lea    di,[bp-0x100]
    6002:	16                   	push   ss
    6003:	57                   	push   di
    6004:	68 ff 00             	push   0xff
    6007:	9a e7 17 9c 60       	call   0x609c:0x17e7
    600c:	8d be 00 ff          	lea    di,[bp-0x100]
    6010:	16                   	push   ss
    6011:	57                   	push   di
    6012:	68 ff 00             	push   0xff
    6015:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6018:	26 ff b5 66 05       	push   WORD PTR es:[di+0x566]
    601d:	26 ff b5 64 05       	push   WORD PTR es:[di+0x564]
    6022:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    6026:	55                   	push   bp
    6027:	9a d0 56 8b 60       	call   0x608b:0x56d0
    602c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6031:	76 18                	jbe    0x604b
    6033:	8d be 00 ff          	lea    di,[bp-0x100]
    6037:	16                   	push   ss
    6038:	57                   	push   di
    6039:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    603d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6042:	06                   	push   es
    6043:	57                   	push   di
    6044:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6047:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    604b:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    604f:	75 17                	jne    0x6068
    6051:	bf ca 59             	mov    di,0x59ca
    6054:	0e                   	push   cs
    6055:	57                   	push   di
    6056:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    605a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    605f:	06                   	push   es
    6060:	57                   	push   di
    6061:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6064:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6068:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    606d:	8d be 00 ff          	lea    di,[bp-0x100]
    6071:	16                   	push   ss
    6072:	57                   	push   di
    6073:	68 ff 00             	push   0xff
    6076:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6079:	26 ff b5 82 04       	push   WORD PTR es:[di+0x482]
    607e:	26 ff b5 80 04       	push   WORD PTR es:[di+0x480]
    6083:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6087:	55                   	push   bp
    6088:	9a d0 56 d4 60       	call   0x60d4:0x56d0
    608d:	8d be fc fd          	lea    di,[bp-0x204]
    6091:	16                   	push   ss
    6092:	57                   	push   di
    6093:	8d be 00 ff          	lea    di,[bp-0x100]
    6097:	16                   	push   ss
    6098:	57                   	push   di
    6099:	9a cd 17 a6 60       	call   0x60a6:0x17cd
    609e:	bf c8 59             	mov    di,0x59c8
    60a1:	0e                   	push   cs
    60a2:	57                   	push   di
    60a3:	9a 4c 18 b4 60       	call   0x60b4:0x184c
    60a8:	8d be 00 ff          	lea    di,[bp-0x100]
    60ac:	16                   	push   ss
    60ad:	57                   	push   di
    60ae:	68 ff 00             	push   0xff
    60b1:	9a e7 17 0e 62       	call   0x620e:0x17e7
    60b6:	8d be 00 ff          	lea    di,[bp-0x100]
    60ba:	16                   	push   ss
    60bb:	57                   	push   di
    60bc:	68 ff 00             	push   0xff
    60bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60c2:	26 ff b5 fe 03       	push   WORD PTR es:[di+0x3fe]
    60c7:	26 ff b5 fc 03       	push   WORD PTR es:[di+0x3fc]
    60cc:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    60d0:	55                   	push   bp
    60d1:	9a d0 56 18 61       	call   0x6118:0x56d0
    60d6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    60db:	76 18                	jbe    0x60f5
    60dd:	8d be 00 ff          	lea    di,[bp-0x100]
    60e1:	16                   	push   ss
    60e2:	57                   	push   di
    60e3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    60e7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    60ec:	06                   	push   es
    60ed:	57                   	push   di
    60ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    60f1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    60f5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    60fa:	8d be 00 ff          	lea    di,[bp-0x100]
    60fe:	16                   	push   ss
    60ff:	57                   	push   di
    6100:	68 ff 00             	push   0xff
    6103:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6106:	26 ff b5 1e 04       	push   WORD PTR es:[di+0x41e]
    610b:	26 ff b5 1c 04       	push   WORD PTR es:[di+0x41c]
    6110:	ff 36 ee 01          	push   WORD PTR ds:0x1ee
    6114:	55                   	push   bp
    6115:	9a d0 56 38 61       	call   0x6138:0x56d0
    611a:	8d be 00 ff          	lea    di,[bp-0x100]
    611e:	16                   	push   ss
    611f:	57                   	push   di
    6120:	68 ff 00             	push   0xff
    6123:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6126:	26 ff b5 86 04       	push   WORD PTR es:[di+0x486]
    612b:	26 ff b5 84 04       	push   WORD PTR es:[di+0x484]
    6130:	ff 36 f4 01          	push   WORD PTR ds:0x1f4
    6134:	55                   	push   bp
    6135:	9a d0 56 7c 61       	call   0x617c:0x56d0
    613a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    613f:	76 18                	jbe    0x6159
    6141:	8d be 00 ff          	lea    di,[bp-0x100]
    6145:	16                   	push   ss
    6146:	57                   	push   di
    6147:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    614b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6150:	06                   	push   es
    6151:	57                   	push   di
    6152:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6155:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6159:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    615e:	8d be 00 ff          	lea    di,[bp-0x100]
    6162:	16                   	push   ss
    6163:	57                   	push   di
    6164:	68 ff 00             	push   0xff
    6167:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    616a:	26 ff b5 22 04       	push   WORD PTR es:[di+0x422]
    616f:	26 ff b5 20 04       	push   WORD PTR es:[di+0x420]
    6174:	ff 36 ee 01          	push   WORD PTR ds:0x1ee
    6178:	55                   	push   bp
    6179:	9a d0 56 9c 61       	call   0x619c:0x56d0
    617e:	8d be 00 ff          	lea    di,[bp-0x100]
    6182:	16                   	push   ss
    6183:	57                   	push   di
    6184:	68 ff 00             	push   0xff
    6187:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    618a:	26 ff b5 8a 04       	push   WORD PTR es:[di+0x48a]
    618f:	26 ff b5 88 04       	push   WORD PTR es:[di+0x488]
    6194:	ff 36 f4 01          	push   WORD PTR ds:0x1f4
    6198:	55                   	push   bp
    6199:	9a d0 56 fd 61       	call   0x61fd:0x56d0
    619e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    61a3:	76 18                	jbe    0x61bd
    61a5:	8d be 00 ff          	lea    di,[bp-0x100]
    61a9:	16                   	push   ss
    61aa:	57                   	push   di
    61ab:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    61af:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    61b4:	06                   	push   es
    61b5:	57                   	push   di
    61b6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    61b9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    61bd:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    61c1:	75 17                	jne    0x61da
    61c3:	bf ca 59             	mov    di,0x59ca
    61c6:	0e                   	push   cs
    61c7:	57                   	push   di
    61c8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    61cc:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    61d1:	06                   	push   es
    61d2:	57                   	push   di
    61d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    61d6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    61da:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    61df:	8d be 00 ff          	lea    di,[bp-0x100]
    61e3:	16                   	push   ss
    61e4:	57                   	push   di
    61e5:	68 ff 00             	push   0xff
    61e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61eb:	26 ff b5 26 04       	push   WORD PTR es:[di+0x426]
    61f0:	26 ff b5 24 04       	push   WORD PTR es:[di+0x424]
    61f5:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    61f9:	55                   	push   bp
    61fa:	9a d0 56 46 62       	call   0x6246:0x56d0
    61ff:	8d be fc fd          	lea    di,[bp-0x204]
    6203:	16                   	push   ss
    6204:	57                   	push   di
    6205:	8d be 00 ff          	lea    di,[bp-0x100]
    6209:	16                   	push   ss
    620a:	57                   	push   di
    620b:	9a cd 17 18 62       	call   0x6218:0x17cd
    6210:	bf c8 59             	mov    di,0x59c8
    6213:	0e                   	push   cs
    6214:	57                   	push   di
    6215:	9a 4c 18 26 62       	call   0x6226:0x184c
    621a:	8d be 00 ff          	lea    di,[bp-0x100]
    621e:	16                   	push   ss
    621f:	57                   	push   di
    6220:	68 ff 00             	push   0xff
    6223:	9a e7 17 9b 62       	call   0x629b:0x17e7
    6228:	8d be 00 ff          	lea    di,[bp-0x100]
    622c:	16                   	push   ss
    622d:	57                   	push   di
    622e:	68 ff 00             	push   0xff
    6231:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6234:	26 ff b5 96 04       	push   WORD PTR es:[di+0x496]
    6239:	26 ff b5 94 04       	push   WORD PTR es:[di+0x494]
    623e:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6242:	55                   	push   bp
    6243:	9a d0 56 8a 62       	call   0x628a:0x56d0
    6248:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    624d:	76 18                	jbe    0x6267
    624f:	8d be 00 ff          	lea    di,[bp-0x100]
    6253:	16                   	push   ss
    6254:	57                   	push   di
    6255:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6259:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    625e:	06                   	push   es
    625f:	57                   	push   di
    6260:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6263:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6267:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    626c:	8d be 00 ff          	lea    di,[bp-0x100]
    6270:	16                   	push   ss
    6271:	57                   	push   di
    6272:	68 ff 00             	push   0xff
    6275:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6278:	26 ff b5 2a 04       	push   WORD PTR es:[di+0x42a]
    627d:	26 ff b5 28 04       	push   WORD PTR es:[di+0x428]
    6282:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6286:	55                   	push   bp
    6287:	9a d0 56 d3 62       	call   0x62d3:0x56d0
    628c:	8d be fc fd          	lea    di,[bp-0x204]
    6290:	16                   	push   ss
    6291:	57                   	push   di
    6292:	8d be 00 ff          	lea    di,[bp-0x100]
    6296:	16                   	push   ss
    6297:	57                   	push   di
    6298:	9a cd 17 a5 62       	call   0x62a5:0x17cd
    629d:	bf c8 59             	mov    di,0x59c8
    62a0:	0e                   	push   cs
    62a1:	57                   	push   di
    62a2:	9a 4c 18 b3 62       	call   0x62b3:0x184c
    62a7:	8d be 00 ff          	lea    di,[bp-0x100]
    62ab:	16                   	push   ss
    62ac:	57                   	push   di
    62ad:	68 ff 00             	push   0xff
    62b0:	9a e7 17 28 63       	call   0x6328:0x17e7
    62b5:	8d be 00 ff          	lea    di,[bp-0x100]
    62b9:	16                   	push   ss
    62ba:	57                   	push   di
    62bb:	68 ff 00             	push   0xff
    62be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62c1:	26 ff b5 9a 04       	push   WORD PTR es:[di+0x49a]
    62c6:	26 ff b5 98 04       	push   WORD PTR es:[di+0x498]
    62cb:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    62cf:	55                   	push   bp
    62d0:	9a d0 56 17 63       	call   0x6317:0x56d0
    62d5:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    62da:	76 18                	jbe    0x62f4
    62dc:	8d be 00 ff          	lea    di,[bp-0x100]
    62e0:	16                   	push   ss
    62e1:	57                   	push   di
    62e2:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    62e6:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    62eb:	06                   	push   es
    62ec:	57                   	push   di
    62ed:	26 c4 3d             	les    di,DWORD PTR es:[di]
    62f0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    62f4:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    62f9:	8d be 00 ff          	lea    di,[bp-0x100]
    62fd:	16                   	push   ss
    62fe:	57                   	push   di
    62ff:	68 ff 00             	push   0xff
    6302:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6305:	26 ff b5 2e 04       	push   WORD PTR es:[di+0x42e]
    630a:	26 ff b5 2c 04       	push   WORD PTR es:[di+0x42c]
    630f:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6313:	55                   	push   bp
    6314:	9a d0 56 60 63       	call   0x6360:0x56d0
    6319:	8d be fc fd          	lea    di,[bp-0x204]
    631d:	16                   	push   ss
    631e:	57                   	push   di
    631f:	8d be 00 ff          	lea    di,[bp-0x100]
    6323:	16                   	push   ss
    6324:	57                   	push   di
    6325:	9a cd 17 32 63       	call   0x6332:0x17cd
    632a:	bf c8 59             	mov    di,0x59c8
    632d:	0e                   	push   cs
    632e:	57                   	push   di
    632f:	9a 4c 18 40 63       	call   0x6340:0x184c
    6334:	8d be 00 ff          	lea    di,[bp-0x100]
    6338:	16                   	push   ss
    6339:	57                   	push   di
    633a:	68 ff 00             	push   0xff
    633d:	9a e7 17 b5 63       	call   0x63b5:0x17e7
    6342:	8d be 00 ff          	lea    di,[bp-0x100]
    6346:	16                   	push   ss
    6347:	57                   	push   di
    6348:	68 ff 00             	push   0xff
    634b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    634e:	26 ff b5 9e 04       	push   WORD PTR es:[di+0x49e]
    6353:	26 ff b5 9c 04       	push   WORD PTR es:[di+0x49c]
    6358:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    635c:	55                   	push   bp
    635d:	9a d0 56 a4 63       	call   0x63a4:0x56d0
    6362:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6367:	76 18                	jbe    0x6381
    6369:	8d be 00 ff          	lea    di,[bp-0x100]
    636d:	16                   	push   ss
    636e:	57                   	push   di
    636f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6373:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6378:	06                   	push   es
    6379:	57                   	push   di
    637a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    637d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6381:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6386:	8d be 00 ff          	lea    di,[bp-0x100]
    638a:	16                   	push   ss
    638b:	57                   	push   di
    638c:	68 ff 00             	push   0xff
    638f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6392:	26 ff b5 32 04       	push   WORD PTR es:[di+0x432]
    6397:	26 ff b5 30 04       	push   WORD PTR es:[di+0x430]
    639c:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    63a0:	55                   	push   bp
    63a1:	9a d0 56 ed 63       	call   0x63ed:0x56d0
    63a6:	8d be fc fd          	lea    di,[bp-0x204]
    63aa:	16                   	push   ss
    63ab:	57                   	push   di
    63ac:	8d be 00 ff          	lea    di,[bp-0x100]
    63b0:	16                   	push   ss
    63b1:	57                   	push   di
    63b2:	9a cd 17 bf 63       	call   0x63bf:0x17cd
    63b7:	bf c8 59             	mov    di,0x59c8
    63ba:	0e                   	push   cs
    63bb:	57                   	push   di
    63bc:	9a 4c 18 cd 63       	call   0x63cd:0x184c
    63c1:	8d be 00 ff          	lea    di,[bp-0x100]
    63c5:	16                   	push   ss
    63c6:	57                   	push   di
    63c7:	68 ff 00             	push   0xff
    63ca:	9a e7 17 42 64       	call   0x6442:0x17e7
    63cf:	8d be 00 ff          	lea    di,[bp-0x100]
    63d3:	16                   	push   ss
    63d4:	57                   	push   di
    63d5:	68 ff 00             	push   0xff
    63d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63db:	26 ff b5 a2 04       	push   WORD PTR es:[di+0x4a2]
    63e0:	26 ff b5 a0 04       	push   WORD PTR es:[di+0x4a0]
    63e5:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    63e9:	55                   	push   bp
    63ea:	9a d0 56 31 64       	call   0x6431:0x56d0
    63ef:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    63f4:	76 18                	jbe    0x640e
    63f6:	8d be 00 ff          	lea    di,[bp-0x100]
    63fa:	16                   	push   ss
    63fb:	57                   	push   di
    63fc:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6400:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6405:	06                   	push   es
    6406:	57                   	push   di
    6407:	26 c4 3d             	les    di,DWORD PTR es:[di]
    640a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    640e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6413:	8d be 00 ff          	lea    di,[bp-0x100]
    6417:	16                   	push   ss
    6418:	57                   	push   di
    6419:	68 ff 00             	push   0xff
    641c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    641f:	26 ff b5 36 04       	push   WORD PTR es:[di+0x436]
    6424:	26 ff b5 34 04       	push   WORD PTR es:[di+0x434]
    6429:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    642d:	55                   	push   bp
    642e:	9a d0 56 7a 64       	call   0x647a:0x56d0
    6433:	8d be fc fd          	lea    di,[bp-0x204]
    6437:	16                   	push   ss
    6438:	57                   	push   di
    6439:	8d be 00 ff          	lea    di,[bp-0x100]
    643d:	16                   	push   ss
    643e:	57                   	push   di
    643f:	9a cd 17 4c 64       	call   0x644c:0x17cd
    6444:	bf c8 59             	mov    di,0x59c8
    6447:	0e                   	push   cs
    6448:	57                   	push   di
    6449:	9a 4c 18 5a 64       	call   0x645a:0x184c
    644e:	8d be 00 ff          	lea    di,[bp-0x100]
    6452:	16                   	push   ss
    6453:	57                   	push   di
    6454:	68 ff 00             	push   0xff
    6457:	9a e7 17 cf 64       	call   0x64cf:0x17e7
    645c:	8d be 00 ff          	lea    di,[bp-0x100]
    6460:	16                   	push   ss
    6461:	57                   	push   di
    6462:	68 ff 00             	push   0xff
    6465:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6468:	26 ff b5 a6 04       	push   WORD PTR es:[di+0x4a6]
    646d:	26 ff b5 a4 04       	push   WORD PTR es:[di+0x4a4]
    6472:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6476:	55                   	push   bp
    6477:	9a d0 56 be 64       	call   0x64be:0x56d0
    647c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6481:	76 18                	jbe    0x649b
    6483:	8d be 00 ff          	lea    di,[bp-0x100]
    6487:	16                   	push   ss
    6488:	57                   	push   di
    6489:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    648d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6492:	06                   	push   es
    6493:	57                   	push   di
    6494:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6497:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    649b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    64a0:	8d be 00 ff          	lea    di,[bp-0x100]
    64a4:	16                   	push   ss
    64a5:	57                   	push   di
    64a6:	68 ff 00             	push   0xff
    64a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64ac:	26 ff b5 3a 04       	push   WORD PTR es:[di+0x43a]
    64b1:	26 ff b5 38 04       	push   WORD PTR es:[di+0x438]
    64b6:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    64ba:	55                   	push   bp
    64bb:	9a d0 56 07 65       	call   0x6507:0x56d0
    64c0:	8d be fc fd          	lea    di,[bp-0x204]
    64c4:	16                   	push   ss
    64c5:	57                   	push   di
    64c6:	8d be 00 ff          	lea    di,[bp-0x100]
    64ca:	16                   	push   ss
    64cb:	57                   	push   di
    64cc:	9a cd 17 d9 64       	call   0x64d9:0x17cd
    64d1:	bf c8 59             	mov    di,0x59c8
    64d4:	0e                   	push   cs
    64d5:	57                   	push   di
    64d6:	9a 4c 18 e7 64       	call   0x64e7:0x184c
    64db:	8d be 00 ff          	lea    di,[bp-0x100]
    64df:	16                   	push   ss
    64e0:	57                   	push   di
    64e1:	68 ff 00             	push   0xff
    64e4:	9a e7 17 5c 65       	call   0x655c:0x17e7
    64e9:	8d be 00 ff          	lea    di,[bp-0x100]
    64ed:	16                   	push   ss
    64ee:	57                   	push   di
    64ef:	68 ff 00             	push   0xff
    64f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64f5:	26 ff b5 aa 04       	push   WORD PTR es:[di+0x4aa]
    64fa:	26 ff b5 a8 04       	push   WORD PTR es:[di+0x4a8]
    64ff:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6503:	55                   	push   bp
    6504:	9a d0 56 4b 65       	call   0x654b:0x56d0
    6509:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    650e:	76 18                	jbe    0x6528
    6510:	8d be 00 ff          	lea    di,[bp-0x100]
    6514:	16                   	push   ss
    6515:	57                   	push   di
    6516:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    651a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    651f:	06                   	push   es
    6520:	57                   	push   di
    6521:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6524:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6528:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    652d:	8d be 00 ff          	lea    di,[bp-0x100]
    6531:	16                   	push   ss
    6532:	57                   	push   di
    6533:	68 ff 00             	push   0xff
    6536:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6539:	26 ff b5 6a 05       	push   WORD PTR es:[di+0x56a]
    653e:	26 ff b5 68 05       	push   WORD PTR es:[di+0x568]
    6543:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6547:	55                   	push   bp
    6548:	9a d0 56 94 65       	call   0x6594:0x56d0
    654d:	8d be fc fd          	lea    di,[bp-0x204]
    6551:	16                   	push   ss
    6552:	57                   	push   di
    6553:	8d be 00 ff          	lea    di,[bp-0x100]
    6557:	16                   	push   ss
    6558:	57                   	push   di
    6559:	9a cd 17 66 65       	call   0x6566:0x17cd
    655e:	bf c8 59             	mov    di,0x59c8
    6561:	0e                   	push   cs
    6562:	57                   	push   di
    6563:	9a 4c 18 74 65       	call   0x6574:0x184c
    6568:	8d be 00 ff          	lea    di,[bp-0x100]
    656c:	16                   	push   ss
    656d:	57                   	push   di
    656e:	68 ff 00             	push   0xff
    6571:	9a e7 17 e9 65       	call   0x65e9:0x17e7
    6576:	8d be 00 ff          	lea    di,[bp-0x100]
    657a:	16                   	push   ss
    657b:	57                   	push   di
    657c:	68 ff 00             	push   0xff
    657f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6582:	26 ff b5 6e 05       	push   WORD PTR es:[di+0x56e]
    6587:	26 ff b5 6c 05       	push   WORD PTR es:[di+0x56c]
    658c:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6590:	55                   	push   bp
    6591:	9a d0 56 d8 65       	call   0x65d8:0x56d0
    6596:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    659b:	76 18                	jbe    0x65b5
    659d:	8d be 00 ff          	lea    di,[bp-0x100]
    65a1:	16                   	push   ss
    65a2:	57                   	push   di
    65a3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    65a7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    65ac:	06                   	push   es
    65ad:	57                   	push   di
    65ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    65b1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    65b5:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    65ba:	8d be 00 ff          	lea    di,[bp-0x100]
    65be:	16                   	push   ss
    65bf:	57                   	push   di
    65c0:	68 ff 00             	push   0xff
    65c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65c6:	26 ff b5 3e 04       	push   WORD PTR es:[di+0x43e]
    65cb:	26 ff b5 3c 04       	push   WORD PTR es:[di+0x43c]
    65d0:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    65d4:	55                   	push   bp
    65d5:	9a d0 56 21 66       	call   0x6621:0x56d0
    65da:	8d be fc fd          	lea    di,[bp-0x204]
    65de:	16                   	push   ss
    65df:	57                   	push   di
    65e0:	8d be 00 ff          	lea    di,[bp-0x100]
    65e4:	16                   	push   ss
    65e5:	57                   	push   di
    65e6:	9a cd 17 f3 65       	call   0x65f3:0x17cd
    65eb:	bf c8 59             	mov    di,0x59c8
    65ee:	0e                   	push   cs
    65ef:	57                   	push   di
    65f0:	9a 4c 18 01 66       	call   0x6601:0x184c
    65f5:	8d be 00 ff          	lea    di,[bp-0x100]
    65f9:	16                   	push   ss
    65fa:	57                   	push   di
    65fb:	68 ff 00             	push   0xff
    65fe:	9a e7 17 76 66       	call   0x6676:0x17e7
    6603:	8d be 00 ff          	lea    di,[bp-0x100]
    6607:	16                   	push   ss
    6608:	57                   	push   di
    6609:	68 ff 00             	push   0xff
    660c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    660f:	26 ff b5 ae 04       	push   WORD PTR es:[di+0x4ae]
    6614:	26 ff b5 ac 04       	push   WORD PTR es:[di+0x4ac]
    6619:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    661d:	55                   	push   bp
    661e:	9a d0 56 65 66       	call   0x6665:0x56d0
    6623:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6628:	76 18                	jbe    0x6642
    662a:	8d be 00 ff          	lea    di,[bp-0x100]
    662e:	16                   	push   ss
    662f:	57                   	push   di
    6630:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6634:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6639:	06                   	push   es
    663a:	57                   	push   di
    663b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    663e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6642:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6647:	8d be 00 ff          	lea    di,[bp-0x100]
    664b:	16                   	push   ss
    664c:	57                   	push   di
    664d:	68 ff 00             	push   0xff
    6650:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6653:	26 ff b5 46 04       	push   WORD PTR es:[di+0x446]
    6658:	26 ff b5 44 04       	push   WORD PTR es:[di+0x444]
    665d:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6661:	55                   	push   bp
    6662:	9a d0 56 ae 66       	call   0x66ae:0x56d0
    6667:	8d be fc fd          	lea    di,[bp-0x204]
    666b:	16                   	push   ss
    666c:	57                   	push   di
    666d:	8d be 00 ff          	lea    di,[bp-0x100]
    6671:	16                   	push   ss
    6672:	57                   	push   di
    6673:	9a cd 17 80 66       	call   0x6680:0x17cd
    6678:	bf c8 59             	mov    di,0x59c8
    667b:	0e                   	push   cs
    667c:	57                   	push   di
    667d:	9a 4c 18 8e 66       	call   0x668e:0x184c
    6682:	8d be 00 ff          	lea    di,[bp-0x100]
    6686:	16                   	push   ss
    6687:	57                   	push   di
    6688:	68 ff 00             	push   0xff
    668b:	9a e7 17 03 67       	call   0x6703:0x17e7
    6690:	8d be 00 ff          	lea    di,[bp-0x100]
    6694:	16                   	push   ss
    6695:	57                   	push   di
    6696:	68 ff 00             	push   0xff
    6699:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    669c:	26 ff b5 b2 04       	push   WORD PTR es:[di+0x4b2]
    66a1:	26 ff b5 b0 04       	push   WORD PTR es:[di+0x4b0]
    66a6:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    66aa:	55                   	push   bp
    66ab:	9a d0 56 f2 66       	call   0x66f2:0x56d0
    66b0:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    66b5:	76 18                	jbe    0x66cf
    66b7:	8d be 00 ff          	lea    di,[bp-0x100]
    66bb:	16                   	push   ss
    66bc:	57                   	push   di
    66bd:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    66c1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    66c6:	06                   	push   es
    66c7:	57                   	push   di
    66c8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    66cb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    66cf:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    66d4:	8d be 00 ff          	lea    di,[bp-0x100]
    66d8:	16                   	push   ss
    66d9:	57                   	push   di
    66da:	68 ff 00             	push   0xff
    66dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66e0:	26 ff b5 42 04       	push   WORD PTR es:[di+0x442]
    66e5:	26 ff b5 40 04       	push   WORD PTR es:[di+0x440]
    66ea:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    66ee:	55                   	push   bp
    66ef:	9a d0 56 3b 67       	call   0x673b:0x56d0
    66f4:	8d be fc fd          	lea    di,[bp-0x204]
    66f8:	16                   	push   ss
    66f9:	57                   	push   di
    66fa:	8d be 00 ff          	lea    di,[bp-0x100]
    66fe:	16                   	push   ss
    66ff:	57                   	push   di
    6700:	9a cd 17 0d 67       	call   0x670d:0x17cd
    6705:	bf c8 59             	mov    di,0x59c8
    6708:	0e                   	push   cs
    6709:	57                   	push   di
    670a:	9a 4c 18 1b 67       	call   0x671b:0x184c
    670f:	8d be 00 ff          	lea    di,[bp-0x100]
    6713:	16                   	push   ss
    6714:	57                   	push   di
    6715:	68 ff 00             	push   0xff
    6718:	9a e7 17 90 67       	call   0x6790:0x17e7
    671d:	8d be 00 ff          	lea    di,[bp-0x100]
    6721:	16                   	push   ss
    6722:	57                   	push   di
    6723:	68 ff 00             	push   0xff
    6726:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6729:	26 ff b5 b6 04       	push   WORD PTR es:[di+0x4b6]
    672e:	26 ff b5 b4 04       	push   WORD PTR es:[di+0x4b4]
    6733:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6737:	55                   	push   bp
    6738:	9a d0 56 7f 67       	call   0x677f:0x56d0
    673d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6742:	76 18                	jbe    0x675c
    6744:	8d be 00 ff          	lea    di,[bp-0x100]
    6748:	16                   	push   ss
    6749:	57                   	push   di
    674a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    674e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6753:	06                   	push   es
    6754:	57                   	push   di
    6755:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6758:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    675c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6761:	8d be 00 ff          	lea    di,[bp-0x100]
    6765:	16                   	push   ss
    6766:	57                   	push   di
    6767:	68 ff 00             	push   0xff
    676a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    676d:	26 ff b5 4a 04       	push   WORD PTR es:[di+0x44a]
    6772:	26 ff b5 48 04       	push   WORD PTR es:[di+0x448]
    6777:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    677b:	55                   	push   bp
    677c:	9a d0 56 c8 67       	call   0x67c8:0x56d0
    6781:	8d be fc fd          	lea    di,[bp-0x204]
    6785:	16                   	push   ss
    6786:	57                   	push   di
    6787:	8d be 00 ff          	lea    di,[bp-0x100]
    678b:	16                   	push   ss
    678c:	57                   	push   di
    678d:	9a cd 17 9a 67       	call   0x679a:0x17cd
    6792:	bf c8 59             	mov    di,0x59c8
    6795:	0e                   	push   cs
    6796:	57                   	push   di
    6797:	9a 4c 18 a8 67       	call   0x67a8:0x184c
    679c:	8d be 00 ff          	lea    di,[bp-0x100]
    67a0:	16                   	push   ss
    67a1:	57                   	push   di
    67a2:	68 ff 00             	push   0xff
    67a5:	9a e7 17 1d 68       	call   0x681d:0x17e7
    67aa:	8d be 00 ff          	lea    di,[bp-0x100]
    67ae:	16                   	push   ss
    67af:	57                   	push   di
    67b0:	68 ff 00             	push   0xff
    67b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67b6:	26 ff b5 ba 04       	push   WORD PTR es:[di+0x4ba]
    67bb:	26 ff b5 b8 04       	push   WORD PTR es:[di+0x4b8]
    67c0:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    67c4:	55                   	push   bp
    67c5:	9a d0 56 0c 68       	call   0x680c:0x56d0
    67ca:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    67cf:	76 18                	jbe    0x67e9
    67d1:	8d be 00 ff          	lea    di,[bp-0x100]
    67d5:	16                   	push   ss
    67d6:	57                   	push   di
    67d7:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    67db:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    67e0:	06                   	push   es
    67e1:	57                   	push   di
    67e2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    67e5:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    67e9:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    67ee:	8d be 00 ff          	lea    di,[bp-0x100]
    67f2:	16                   	push   ss
    67f3:	57                   	push   di
    67f4:	68 ff 00             	push   0xff
    67f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67fa:	26 ff b5 4e 04       	push   WORD PTR es:[di+0x44e]
    67ff:	26 ff b5 4c 04       	push   WORD PTR es:[di+0x44c]
    6804:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6808:	55                   	push   bp
    6809:	9a d0 56 55 68       	call   0x6855:0x56d0
    680e:	8d be fc fd          	lea    di,[bp-0x204]
    6812:	16                   	push   ss
    6813:	57                   	push   di
    6814:	8d be 00 ff          	lea    di,[bp-0x100]
    6818:	16                   	push   ss
    6819:	57                   	push   di
    681a:	9a cd 17 27 68       	call   0x6827:0x17cd
    681f:	bf c8 59             	mov    di,0x59c8
    6822:	0e                   	push   cs
    6823:	57                   	push   di
    6824:	9a 4c 18 35 68       	call   0x6835:0x184c
    6829:	8d be 00 ff          	lea    di,[bp-0x100]
    682d:	16                   	push   ss
    682e:	57                   	push   di
    682f:	68 ff 00             	push   0xff
    6832:	9a e7 17 aa 68       	call   0x68aa:0x17e7
    6837:	8d be 00 ff          	lea    di,[bp-0x100]
    683b:	16                   	push   ss
    683c:	57                   	push   di
    683d:	68 ff 00             	push   0xff
    6840:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6843:	26 ff b5 be 04       	push   WORD PTR es:[di+0x4be]
    6848:	26 ff b5 bc 04       	push   WORD PTR es:[di+0x4bc]
    684d:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6851:	55                   	push   bp
    6852:	9a d0 56 99 68       	call   0x6899:0x56d0
    6857:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    685c:	76 18                	jbe    0x6876
    685e:	8d be 00 ff          	lea    di,[bp-0x100]
    6862:	16                   	push   ss
    6863:	57                   	push   di
    6864:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6868:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    686d:	06                   	push   es
    686e:	57                   	push   di
    686f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6872:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6876:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    687b:	8d be 00 ff          	lea    di,[bp-0x100]
    687f:	16                   	push   ss
    6880:	57                   	push   di
    6881:	68 ff 00             	push   0xff
    6884:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6887:	26 ff b5 52 04       	push   WORD PTR es:[di+0x452]
    688c:	26 ff b5 50 04       	push   WORD PTR es:[di+0x450]
    6891:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6895:	55                   	push   bp
    6896:	9a d0 56 ec 68       	call   0x68ec:0x56d0
    689b:	8d be fc fd          	lea    di,[bp-0x204]
    689f:	16                   	push   ss
    68a0:	57                   	push   di
    68a1:	8d be 00 ff          	lea    di,[bp-0x100]
    68a5:	16                   	push   ss
    68a6:	57                   	push   di
    68a7:	9a cd 17 b4 68       	call   0x68b4:0x17cd
    68ac:	bf c8 59             	mov    di,0x59c8
    68af:	0e                   	push   cs
    68b0:	57                   	push   di
    68b1:	9a 4c 18 be 68       	call   0x68be:0x184c
    68b6:	bf c8 59             	mov    di,0x59c8
    68b9:	0e                   	push   cs
    68ba:	57                   	push   di
    68bb:	9a 4c 18 cc 68       	call   0x68cc:0x184c
    68c0:	8d be 00 ff          	lea    di,[bp-0x100]
    68c4:	16                   	push   ss
    68c5:	57                   	push   di
    68c6:	68 ff 00             	push   0xff
    68c9:	9a e7 17 41 69       	call   0x6941:0x17e7
    68ce:	8d be 00 ff          	lea    di,[bp-0x100]
    68d2:	16                   	push   ss
    68d3:	57                   	push   di
    68d4:	68 ff 00             	push   0xff
    68d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    68da:	26 ff b5 d2 04       	push   WORD PTR es:[di+0x4d2]
    68df:	26 ff b5 d0 04       	push   WORD PTR es:[di+0x4d0]
    68e4:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    68e8:	55                   	push   bp
    68e9:	9a d0 56 30 69       	call   0x6930:0x56d0
    68ee:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    68f3:	76 18                	jbe    0x690d
    68f5:	8d be 00 ff          	lea    di,[bp-0x100]
    68f9:	16                   	push   ss
    68fa:	57                   	push   di
    68fb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    68ff:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6904:	06                   	push   es
    6905:	57                   	push   di
    6906:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6909:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    690d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6912:	8d be 00 ff          	lea    di,[bp-0x100]
    6916:	16                   	push   ss
    6917:	57                   	push   di
    6918:	68 ff 00             	push   0xff
    691b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    691e:	26 ff b5 56 04       	push   WORD PTR es:[di+0x456]
    6923:	26 ff b5 54 04       	push   WORD PTR es:[di+0x454]
    6928:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    692c:	55                   	push   bp
    692d:	9a d0 56 79 69       	call   0x6979:0x56d0
    6932:	8d be fc fd          	lea    di,[bp-0x204]
    6936:	16                   	push   ss
    6937:	57                   	push   di
    6938:	8d be 00 ff          	lea    di,[bp-0x100]
    693c:	16                   	push   ss
    693d:	57                   	push   di
    693e:	9a cd 17 4b 69       	call   0x694b:0x17cd
    6943:	bf c8 59             	mov    di,0x59c8
    6946:	0e                   	push   cs
    6947:	57                   	push   di
    6948:	9a 4c 18 59 69       	call   0x6959:0x184c
    694d:	8d be 00 ff          	lea    di,[bp-0x100]
    6951:	16                   	push   ss
    6952:	57                   	push   di
    6953:	68 ff 00             	push   0xff
    6956:	9a e7 17 ce 69       	call   0x69ce:0x17e7
    695b:	8d be 00 ff          	lea    di,[bp-0x100]
    695f:	16                   	push   ss
    6960:	57                   	push   di
    6961:	68 ff 00             	push   0xff
    6964:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6967:	26 ff b5 c2 04       	push   WORD PTR es:[di+0x4c2]
    696c:	26 ff b5 c0 04       	push   WORD PTR es:[di+0x4c0]
    6971:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6975:	55                   	push   bp
    6976:	9a d0 56 bd 69       	call   0x69bd:0x56d0
    697b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6980:	76 18                	jbe    0x699a
    6982:	8d be 00 ff          	lea    di,[bp-0x100]
    6986:	16                   	push   ss
    6987:	57                   	push   di
    6988:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    698c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6991:	06                   	push   es
    6992:	57                   	push   di
    6993:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6996:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    699a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    699f:	8d be 00 ff          	lea    di,[bp-0x100]
    69a3:	16                   	push   ss
    69a4:	57                   	push   di
    69a5:	68 ff 00             	push   0xff
    69a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69ab:	26 ff b5 5a 04       	push   WORD PTR es:[di+0x45a]
    69b0:	26 ff b5 58 04       	push   WORD PTR es:[di+0x458]
    69b5:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    69b9:	55                   	push   bp
    69ba:	9a d0 56 10 6a       	call   0x6a10:0x56d0
    69bf:	8d be fc fd          	lea    di,[bp-0x204]
    69c3:	16                   	push   ss
    69c4:	57                   	push   di
    69c5:	8d be 00 ff          	lea    di,[bp-0x100]
    69c9:	16                   	push   ss
    69ca:	57                   	push   di
    69cb:	9a cd 17 d8 69       	call   0x69d8:0x17cd
    69d0:	bf c8 59             	mov    di,0x59c8
    69d3:	0e                   	push   cs
    69d4:	57                   	push   di
    69d5:	9a 4c 18 e2 69       	call   0x69e2:0x184c
    69da:	bf c8 59             	mov    di,0x59c8
    69dd:	0e                   	push   cs
    69de:	57                   	push   di
    69df:	9a 4c 18 f0 69       	call   0x69f0:0x184c
    69e4:	8d be 00 ff          	lea    di,[bp-0x100]
    69e8:	16                   	push   ss
    69e9:	57                   	push   di
    69ea:	68 ff 00             	push   0xff
    69ed:	9a e7 17 65 6a       	call   0x6a65:0x17e7
    69f2:	8d be 00 ff          	lea    di,[bp-0x100]
    69f6:	16                   	push   ss
    69f7:	57                   	push   di
    69f8:	68 ff 00             	push   0xff
    69fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    69fe:	26 ff b5 d6 04       	push   WORD PTR es:[di+0x4d6]
    6a03:	26 ff b5 d4 04       	push   WORD PTR es:[di+0x4d4]
    6a08:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    6a0c:	55                   	push   bp
    6a0d:	9a d0 56 54 6a       	call   0x6a54:0x56d0
    6a12:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6a17:	76 18                	jbe    0x6a31
    6a19:	8d be 00 ff          	lea    di,[bp-0x100]
    6a1d:	16                   	push   ss
    6a1e:	57                   	push   di
    6a1f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6a23:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6a28:	06                   	push   es
    6a29:	57                   	push   di
    6a2a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6a2d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6a31:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6a36:	8d be 00 ff          	lea    di,[bp-0x100]
    6a3a:	16                   	push   ss
    6a3b:	57                   	push   di
    6a3c:	68 ff 00             	push   0xff
    6a3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a42:	26 ff b5 5e 04       	push   WORD PTR es:[di+0x45e]
    6a47:	26 ff b5 5c 04       	push   WORD PTR es:[di+0x45c]
    6a4c:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6a50:	55                   	push   bp
    6a51:	9a d0 56 9d 6a       	call   0x6a9d:0x56d0
    6a56:	8d be fc fd          	lea    di,[bp-0x204]
    6a5a:	16                   	push   ss
    6a5b:	57                   	push   di
    6a5c:	8d be 00 ff          	lea    di,[bp-0x100]
    6a60:	16                   	push   ss
    6a61:	57                   	push   di
    6a62:	9a cd 17 6f 6a       	call   0x6a6f:0x17cd
    6a67:	bf c8 59             	mov    di,0x59c8
    6a6a:	0e                   	push   cs
    6a6b:	57                   	push   di
    6a6c:	9a 4c 18 7d 6a       	call   0x6a7d:0x184c
    6a71:	8d be 00 ff          	lea    di,[bp-0x100]
    6a75:	16                   	push   ss
    6a76:	57                   	push   di
    6a77:	68 ff 00             	push   0xff
    6a7a:	9a e7 17 f2 6a       	call   0x6af2:0x17e7
    6a7f:	8d be 00 ff          	lea    di,[bp-0x100]
    6a83:	16                   	push   ss
    6a84:	57                   	push   di
    6a85:	68 ff 00             	push   0xff
    6a88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6a8b:	26 ff b5 c6 04       	push   WORD PTR es:[di+0x4c6]
    6a90:	26 ff b5 c4 04       	push   WORD PTR es:[di+0x4c4]
    6a95:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6a99:	55                   	push   bp
    6a9a:	9a d0 56 e1 6a       	call   0x6ae1:0x56d0
    6a9f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6aa4:	76 18                	jbe    0x6abe
    6aa6:	8d be 00 ff          	lea    di,[bp-0x100]
    6aaa:	16                   	push   ss
    6aab:	57                   	push   di
    6aac:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6ab0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6ab5:	06                   	push   es
    6ab6:	57                   	push   di
    6ab7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6aba:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6abe:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6ac3:	8d be 00 ff          	lea    di,[bp-0x100]
    6ac7:	16                   	push   ss
    6ac8:	57                   	push   di
    6ac9:	68 ff 00             	push   0xff
    6acc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6acf:	26 ff b5 62 04       	push   WORD PTR es:[di+0x462]
    6ad4:	26 ff b5 60 04       	push   WORD PTR es:[di+0x460]
    6ad9:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6add:	55                   	push   bp
    6ade:	9a d0 56 2a 6b       	call   0x6b2a:0x56d0
    6ae3:	8d be fc fd          	lea    di,[bp-0x204]
    6ae7:	16                   	push   ss
    6ae8:	57                   	push   di
    6ae9:	8d be 00 ff          	lea    di,[bp-0x100]
    6aed:	16                   	push   ss
    6aee:	57                   	push   di
    6aef:	9a cd 17 fc 6a       	call   0x6afc:0x17cd
    6af4:	bf c8 59             	mov    di,0x59c8
    6af7:	0e                   	push   cs
    6af8:	57                   	push   di
    6af9:	9a 4c 18 0a 6b       	call   0x6b0a:0x184c
    6afe:	8d be 00 ff          	lea    di,[bp-0x100]
    6b02:	16                   	push   ss
    6b03:	57                   	push   di
    6b04:	68 ff 00             	push   0xff
    6b07:	9a e7 17 7f 6b       	call   0x6b7f:0x17e7
    6b0c:	8d be 00 ff          	lea    di,[bp-0x100]
    6b10:	16                   	push   ss
    6b11:	57                   	push   di
    6b12:	68 ff 00             	push   0xff
    6b15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b18:	26 ff b5 ca 04       	push   WORD PTR es:[di+0x4ca]
    6b1d:	26 ff b5 c8 04       	push   WORD PTR es:[di+0x4c8]
    6b22:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6b26:	55                   	push   bp
    6b27:	9a d0 56 6e 6b       	call   0x6b6e:0x56d0
    6b2c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6b31:	76 18                	jbe    0x6b4b
    6b33:	8d be 00 ff          	lea    di,[bp-0x100]
    6b37:	16                   	push   ss
    6b38:	57                   	push   di
    6b39:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6b3d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6b42:	06                   	push   es
    6b43:	57                   	push   di
    6b44:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6b47:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6b4b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6b50:	8d be 00 ff          	lea    di,[bp-0x100]
    6b54:	16                   	push   ss
    6b55:	57                   	push   di
    6b56:	68 ff 00             	push   0xff
    6b59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6b5c:	26 ff b5 66 04       	push   WORD PTR es:[di+0x466]
    6b61:	26 ff b5 64 04       	push   WORD PTR es:[di+0x464]
    6b66:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6b6a:	55                   	push   bp
    6b6b:	9a d0 56 c1 6b       	call   0x6bc1:0x56d0
    6b70:	8d be fc fd          	lea    di,[bp-0x204]
    6b74:	16                   	push   ss
    6b75:	57                   	push   di
    6b76:	8d be 00 ff          	lea    di,[bp-0x100]
    6b7a:	16                   	push   ss
    6b7b:	57                   	push   di
    6b7c:	9a cd 17 89 6b       	call   0x6b89:0x17cd
    6b81:	bf c8 59             	mov    di,0x59c8
    6b84:	0e                   	push   cs
    6b85:	57                   	push   di
    6b86:	9a 4c 18 93 6b       	call   0x6b93:0x184c
    6b8b:	bf c8 59             	mov    di,0x59c8
    6b8e:	0e                   	push   cs
    6b8f:	57                   	push   di
    6b90:	9a 4c 18 a1 6b       	call   0x6ba1:0x184c
    6b95:	8d be 00 ff          	lea    di,[bp-0x100]
    6b99:	16                   	push   ss
    6b9a:	57                   	push   di
    6b9b:	68 ff 00             	push   0xff
    6b9e:	9a e7 17 16 6c       	call   0x6c16:0x17e7
    6ba3:	8d be 00 ff          	lea    di,[bp-0x100]
    6ba7:	16                   	push   ss
    6ba8:	57                   	push   di
    6ba9:	68 ff 00             	push   0xff
    6bac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6baf:	26 ff b5 da 04       	push   WORD PTR es:[di+0x4da]
    6bb4:	26 ff b5 d8 04       	push   WORD PTR es:[di+0x4d8]
    6bb9:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    6bbd:	55                   	push   bp
    6bbe:	9a d0 56 05 6c       	call   0x6c05:0x56d0
    6bc3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6bc8:	76 18                	jbe    0x6be2
    6bca:	8d be 00 ff          	lea    di,[bp-0x100]
    6bce:	16                   	push   ss
    6bcf:	57                   	push   di
    6bd0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6bd4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6bd9:	06                   	push   es
    6bda:	57                   	push   di
    6bdb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6bde:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6be2:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6be7:	8d be 00 ff          	lea    di,[bp-0x100]
    6beb:	16                   	push   ss
    6bec:	57                   	push   di
    6bed:	68 ff 00             	push   0xff
    6bf0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6bf3:	26 ff b5 6a 04       	push   WORD PTR es:[di+0x46a]
    6bf8:	26 ff b5 68 04       	push   WORD PTR es:[di+0x468]
    6bfd:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6c01:	55                   	push   bp
    6c02:	9a d0 56 4e 6c       	call   0x6c4e:0x56d0
    6c07:	8d be fc fd          	lea    di,[bp-0x204]
    6c0b:	16                   	push   ss
    6c0c:	57                   	push   di
    6c0d:	8d be 00 ff          	lea    di,[bp-0x100]
    6c11:	16                   	push   ss
    6c12:	57                   	push   di
    6c13:	9a cd 17 20 6c       	call   0x6c20:0x17cd
    6c18:	bf c8 59             	mov    di,0x59c8
    6c1b:	0e                   	push   cs
    6c1c:	57                   	push   di
    6c1d:	9a 4c 18 2e 6c       	call   0x6c2e:0x184c
    6c22:	8d be 00 ff          	lea    di,[bp-0x100]
    6c26:	16                   	push   ss
    6c27:	57                   	push   di
    6c28:	68 ff 00             	push   0xff
    6c2b:	9a e7 17 c0 6c       	call   0x6cc0:0x17e7
    6c30:	8d be 00 ff          	lea    di,[bp-0x100]
    6c34:	16                   	push   ss
    6c35:	57                   	push   di
    6c36:	68 ff 00             	push   0xff
    6c39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c3c:	26 ff b5 ce 04       	push   WORD PTR es:[di+0x4ce]
    6c41:	26 ff b5 cc 04       	push   WORD PTR es:[di+0x4cc]
    6c46:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6c4a:	55                   	push   bp
    6c4b:	9a d0 56 af 6c       	call   0x6caf:0x56d0
    6c50:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6c55:	76 18                	jbe    0x6c6f
    6c57:	8d be 00 ff          	lea    di,[bp-0x100]
    6c5b:	16                   	push   ss
    6c5c:	57                   	push   di
    6c5d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6c61:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6c66:	06                   	push   es
    6c67:	57                   	push   di
    6c68:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c6b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6c6f:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    6c73:	75 17                	jne    0x6c8c
    6c75:	bf ca 59             	mov    di,0x59ca
    6c78:	0e                   	push   cs
    6c79:	57                   	push   di
    6c7a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6c7e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6c83:	06                   	push   es
    6c84:	57                   	push   di
    6c85:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6c88:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6c8c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6c91:	8d be 00 ff          	lea    di,[bp-0x100]
    6c95:	16                   	push   ss
    6c96:	57                   	push   di
    6c97:	68 ff 00             	push   0xff
    6c9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6c9d:	26 ff b5 ee 04       	push   WORD PTR es:[di+0x4ee]
    6ca2:	26 ff b5 ec 04       	push   WORD PTR es:[di+0x4ec]
    6ca7:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6cab:	55                   	push   bp
    6cac:	9a d0 56 f8 6c       	call   0x6cf8:0x56d0
    6cb1:	8d be fc fd          	lea    di,[bp-0x204]
    6cb5:	16                   	push   ss
    6cb6:	57                   	push   di
    6cb7:	8d be 00 ff          	lea    di,[bp-0x100]
    6cbb:	16                   	push   ss
    6cbc:	57                   	push   di
    6cbd:	9a cd 17 ca 6c       	call   0x6cca:0x17cd
    6cc2:	bf c8 59             	mov    di,0x59c8
    6cc5:	0e                   	push   cs
    6cc6:	57                   	push   di
    6cc7:	9a 4c 18 d8 6c       	call   0x6cd8:0x184c
    6ccc:	8d be 00 ff          	lea    di,[bp-0x100]
    6cd0:	16                   	push   ss
    6cd1:	57                   	push   di
    6cd2:	68 ff 00             	push   0xff
    6cd5:	9a e7 17 8a 6d       	call   0x6d8a:0x17e7
    6cda:	8d be 00 ff          	lea    di,[bp-0x100]
    6cde:	16                   	push   ss
    6cdf:	57                   	push   di
    6ce0:	68 ff 00             	push   0xff
    6ce3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6ce6:	26 ff b5 e6 04       	push   WORD PTR es:[di+0x4e6]
    6ceb:	26 ff b5 e4 04       	push   WORD PTR es:[di+0x4e4]
    6cf0:	ff 36 f6 01          	push   WORD PTR ds:0x1f6
    6cf4:	55                   	push   bp
    6cf5:	9a d0 56 18 6d       	call   0x6d18:0x56d0
    6cfa:	8d be 00 ff          	lea    di,[bp-0x100]
    6cfe:	16                   	push   ss
    6cff:	57                   	push   di
    6d00:	68 ff 00             	push   0xff
    6d03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d06:	26 ff b5 ea 04       	push   WORD PTR es:[di+0x4ea]
    6d0b:	26 ff b5 e8 04       	push   WORD PTR es:[di+0x4e8]
    6d10:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    6d14:	55                   	push   bp
    6d15:	9a d0 56 79 6d       	call   0x6d79:0x56d0
    6d1a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6d1f:	76 18                	jbe    0x6d39
    6d21:	8d be 00 ff          	lea    di,[bp-0x100]
    6d25:	16                   	push   ss
    6d26:	57                   	push   di
    6d27:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6d2b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6d30:	06                   	push   es
    6d31:	57                   	push   di
    6d32:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d35:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6d39:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    6d3d:	75 17                	jne    0x6d56
    6d3f:	bf ca 59             	mov    di,0x59ca
    6d42:	0e                   	push   cs
    6d43:	57                   	push   di
    6d44:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6d48:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6d4d:	06                   	push   es
    6d4e:	57                   	push   di
    6d4f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6d52:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6d56:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6d5b:	8d be 00 ff          	lea    di,[bp-0x100]
    6d5f:	16                   	push   ss
    6d60:	57                   	push   di
    6d61:	68 ff 00             	push   0xff
    6d64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6d67:	26 ff b5 f2 04       	push   WORD PTR es:[di+0x4f2]
    6d6c:	26 ff b5 f0 04       	push   WORD PTR es:[di+0x4f0]
    6d71:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6d75:	55                   	push   bp
    6d76:	9a d0 56 cc 6d       	call   0x6dcc:0x56d0
    6d7b:	8d be fc fd          	lea    di,[bp-0x204]
    6d7f:	16                   	push   ss
    6d80:	57                   	push   di
    6d81:	8d be 00 ff          	lea    di,[bp-0x100]
    6d85:	16                   	push   ss
    6d86:	57                   	push   di
    6d87:	9a cd 17 94 6d       	call   0x6d94:0x17cd
    6d8c:	bf c8 59             	mov    di,0x59c8
    6d8f:	0e                   	push   cs
    6d90:	57                   	push   di
    6d91:	9a 4c 18 9e 6d       	call   0x6d9e:0x184c
    6d96:	bf c8 59             	mov    di,0x59c8
    6d99:	0e                   	push   cs
    6d9a:	57                   	push   di
    6d9b:	9a 4c 18 ac 6d       	call   0x6dac:0x184c
    6da0:	8d be 00 ff          	lea    di,[bp-0x100]
    6da4:	16                   	push   ss
    6da5:	57                   	push   di
    6da6:	68 ff 00             	push   0xff
    6da9:	9a e7 17 21 6e       	call   0x6e21:0x17e7
    6dae:	8d be 00 ff          	lea    di,[bp-0x100]
    6db2:	16                   	push   ss
    6db3:	57                   	push   di
    6db4:	68 ff 00             	push   0xff
    6db7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dba:	26 ff b5 fa 04       	push   WORD PTR es:[di+0x4fa]
    6dbf:	26 ff b5 f8 04       	push   WORD PTR es:[di+0x4f8]
    6dc4:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    6dc8:	55                   	push   bp
    6dc9:	9a d0 56 10 6e       	call   0x6e10:0x56d0
    6dce:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6dd3:	76 18                	jbe    0x6ded
    6dd5:	8d be 00 ff          	lea    di,[bp-0x100]
    6dd9:	16                   	push   ss
    6dda:	57                   	push   di
    6ddb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6ddf:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6de4:	06                   	push   es
    6de5:	57                   	push   di
    6de6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6de9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6ded:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6df2:	8d be 00 ff          	lea    di,[bp-0x100]
    6df6:	16                   	push   ss
    6df7:	57                   	push   di
    6df8:	68 ff 00             	push   0xff
    6dfb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6dfe:	26 ff b5 0a 05       	push   WORD PTR es:[di+0x50a]
    6e03:	26 ff b5 08 05       	push   WORD PTR es:[di+0x508]
    6e08:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6e0c:	55                   	push   bp
    6e0d:	9a d0 56 63 6e       	call   0x6e63:0x56d0
    6e12:	8d be fc fd          	lea    di,[bp-0x204]
    6e16:	16                   	push   ss
    6e17:	57                   	push   di
    6e18:	8d be 00 ff          	lea    di,[bp-0x100]
    6e1c:	16                   	push   ss
    6e1d:	57                   	push   di
    6e1e:	9a cd 17 2b 6e       	call   0x6e2b:0x17cd
    6e23:	bf c8 59             	mov    di,0x59c8
    6e26:	0e                   	push   cs
    6e27:	57                   	push   di
    6e28:	9a 4c 18 35 6e       	call   0x6e35:0x184c
    6e2d:	bf c8 59             	mov    di,0x59c8
    6e30:	0e                   	push   cs
    6e31:	57                   	push   di
    6e32:	9a 4c 18 43 6e       	call   0x6e43:0x184c
    6e37:	8d be 00 ff          	lea    di,[bp-0x100]
    6e3b:	16                   	push   ss
    6e3c:	57                   	push   di
    6e3d:	68 ff 00             	push   0xff
    6e40:	9a e7 17 d5 6e       	call   0x6ed5:0x17e7
    6e45:	8d be 00 ff          	lea    di,[bp-0x100]
    6e49:	16                   	push   ss
    6e4a:	57                   	push   di
    6e4b:	68 ff 00             	push   0xff
    6e4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6e51:	26 ff b5 fe 04       	push   WORD PTR es:[di+0x4fe]
    6e56:	26 ff b5 fc 04       	push   WORD PTR es:[di+0x4fc]
    6e5b:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    6e5f:	55                   	push   bp
    6e60:	9a d0 56 c4 6e       	call   0x6ec4:0x56d0
    6e65:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6e6a:	76 18                	jbe    0x6e84
    6e6c:	8d be 00 ff          	lea    di,[bp-0x100]
    6e70:	16                   	push   ss
    6e71:	57                   	push   di
    6e72:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6e76:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6e7b:	06                   	push   es
    6e7c:	57                   	push   di
    6e7d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6e80:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6e84:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    6e88:	75 17                	jne    0x6ea1
    6e8a:	bf ca 59             	mov    di,0x59ca
    6e8d:	0e                   	push   cs
    6e8e:	57                   	push   di
    6e8f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6e93:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6e98:	06                   	push   es
    6e99:	57                   	push   di
    6e9a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6e9d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6ea1:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6ea6:	8d be 00 ff          	lea    di,[bp-0x100]
    6eaa:	16                   	push   ss
    6eab:	57                   	push   di
    6eac:	68 ff 00             	push   0xff
    6eaf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6eb2:	26 ff b5 0e 05       	push   WORD PTR es:[di+0x50e]
    6eb7:	26 ff b5 0c 05       	push   WORD PTR es:[di+0x50c]
    6ebc:	ff 36 ec 01          	push   WORD PTR ds:0x1ec
    6ec0:	55                   	push   bp
    6ec1:	9a d0 56 17 6f       	call   0x6f17:0x56d0
    6ec6:	8d be fc fd          	lea    di,[bp-0x204]
    6eca:	16                   	push   ss
    6ecb:	57                   	push   di
    6ecc:	8d be 00 ff          	lea    di,[bp-0x100]
    6ed0:	16                   	push   ss
    6ed1:	57                   	push   di
    6ed2:	9a cd 17 df 6e       	call   0x6edf:0x17cd
    6ed7:	bf c8 59             	mov    di,0x59c8
    6eda:	0e                   	push   cs
    6edb:	57                   	push   di
    6edc:	9a 4c 18 e9 6e       	call   0x6ee9:0x184c
    6ee1:	bf c8 59             	mov    di,0x59c8
    6ee4:	0e                   	push   cs
    6ee5:	57                   	push   di
    6ee6:	9a 4c 18 f7 6e       	call   0x6ef7:0x184c
    6eeb:	8d be 00 ff          	lea    di,[bp-0x100]
    6eef:	16                   	push   ss
    6ef0:	57                   	push   di
    6ef1:	68 ff 00             	push   0xff
    6ef4:	9a e7 17 44 6f       	call   0x6f44:0x17e7
    6ef9:	8d be 00 ff          	lea    di,[bp-0x100]
    6efd:	16                   	push   ss
    6efe:	57                   	push   di
    6eff:	68 ff 00             	push   0xff
    6f02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f05:	26 ff b5 02 05       	push   WORD PTR es:[di+0x502]
    6f0a:	26 ff b5 00 05       	push   WORD PTR es:[di+0x500]
    6f0f:	ff 36 f8 01          	push   WORD PTR ds:0x1f8
    6f13:	55                   	push   bp
    6f14:	9a d0 56 ff ff       	call   0xffff:0x56d0
    6f19:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6f1e:	76 18                	jbe    0x6f38
    6f20:	8d be 00 ff          	lea    di,[bp-0x100]
    6f24:	16                   	push   ss
    6f25:	57                   	push   di
    6f26:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6f2a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6f2f:	06                   	push   es
    6f30:	57                   	push   di
    6f31:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6f34:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6f38:	c9                   	leave
    6f39:	ca 06 00             	retf   0x6
    6f3c:	55                   	push   bp
    6f3d:	89 e5                	mov    bp,sp
    6f3f:	31 c0                	xor    ax,ax
    6f41:	9a 44 04 72 6f       	call   0x6f72:0x444
    6f46:	c7 06 44 01 15 00    	mov    WORD PTR ds:0x144,0x15
    6f4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f4f:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    6f54:	a3 46 01             	mov    ds:0x146,ax
    6f57:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    6f5c:	a3 48 01             	mov    ds:0x148,ax
    6f5f:	06                   	push   es
    6f60:	57                   	push   di
    6f61:	9a 56 55 92 6f       	call   0x6f92:0x5556
    6f66:	c9                   	leave
    6f67:	ca 08 00             	retf   0x8
    6f6a:	55                   	push   bp
    6f6b:	89 e5                	mov    bp,sp
    6f6d:	31 c0                	xor    ax,ax
    6f6f:	9a 44 04 a0 6f       	call   0x6fa0:0x444
    6f74:	c7 06 44 01 16 00    	mov    WORD PTR ds:0x144,0x16
    6f7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6f7d:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    6f82:	a3 46 01             	mov    ds:0x146,ax
    6f85:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    6f8a:	a3 48 01             	mov    ds:0x148,ax
    6f8d:	06                   	push   es
    6f8e:	57                   	push   di
    6f8f:	9a 56 55 c0 6f       	call   0x6fc0:0x5556
    6f94:	c9                   	leave
    6f95:	ca 08 00             	retf   0x8
    6f98:	55                   	push   bp
    6f99:	89 e5                	mov    bp,sp
    6f9b:	31 c0                	xor    ax,ax
    6f9d:	9a 44 04 ce 6f       	call   0x6fce:0x444
    6fa2:	c7 06 44 01 17 00    	mov    WORD PTR ds:0x144,0x17
    6fa8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fab:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    6fb0:	a3 46 01             	mov    ds:0x146,ax
    6fb3:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    6fb8:	a3 48 01             	mov    ds:0x148,ax
    6fbb:	06                   	push   es
    6fbc:	57                   	push   di
    6fbd:	9a 56 55 ee 6f       	call   0x6fee:0x5556
    6fc2:	c9                   	leave
    6fc3:	ca 08 00             	retf   0x8
    6fc6:	55                   	push   bp
    6fc7:	89 e5                	mov    bp,sp
    6fc9:	31 c0                	xor    ax,ax
    6fcb:	9a 44 04 fc 6f       	call   0x6ffc:0x444
    6fd0:	c7 06 44 01 18 00    	mov    WORD PTR ds:0x144,0x18
    6fd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6fd9:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    6fde:	a3 46 01             	mov    ds:0x146,ax
    6fe1:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    6fe6:	a3 48 01             	mov    ds:0x148,ax
    6fe9:	06                   	push   es
    6fea:	57                   	push   di
    6feb:	9a 56 55 1c 70       	call   0x701c:0x5556
    6ff0:	c9                   	leave
    6ff1:	ca 08 00             	retf   0x8
    6ff4:	55                   	push   bp
    6ff5:	89 e5                	mov    bp,sp
    6ff7:	31 c0                	xor    ax,ax
    6ff9:	9a 44 04 2a 70       	call   0x702a:0x444
    6ffe:	c7 06 44 01 19 00    	mov    WORD PTR ds:0x144,0x19
    7004:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7007:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    700c:	a3 46 01             	mov    ds:0x146,ax
    700f:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    7014:	a3 48 01             	mov    ds:0x148,ax
    7017:	06                   	push   es
    7018:	57                   	push   di
    7019:	9a 56 55 4a 70       	call   0x704a:0x5556
    701e:	c9                   	leave
    701f:	ca 08 00             	retf   0x8
    7022:	55                   	push   bp
    7023:	89 e5                	mov    bp,sp
    7025:	31 c0                	xor    ax,ax
    7027:	9a 44 04 58 70       	call   0x7058:0x444
    702c:	c7 06 44 01 1a 00    	mov    WORD PTR ds:0x144,0x1a
    7032:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7035:	26 8b 85 80 05       	mov    ax,WORD PTR es:[di+0x580]
    703a:	a3 46 01             	mov    ds:0x146,ax
    703d:	26 8b 85 7e 05       	mov    ax,WORD PTR es:[di+0x57e]
    7042:	a3 48 01             	mov    ds:0x148,ax
    7045:	06                   	push   es
    7046:	57                   	push   di
    7047:	9a 56 55 ff ff       	call   0xffff:0x5556
    704c:	c9                   	leave
    704d:	ca 08 00             	retf   0x8
    7050:	55                   	push   bp
    7051:	89 e5                	mov    bp,sp
    7053:	31 c0                	xor    ax,ax
    7055:	9a 44 04 ff ff       	call   0xffff:0x444
    705a:	ff 36 50 01          	push   WORD PTR ds:0x150
    705e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    7061:	26 ff b5 7e 05       	push   WORD PTR es:[di+0x57e]
    7066:	26 ff b5 80 05       	push   WORD PTR es:[di+0x580]
    706b:	9a a1 0c ff ff       	call   0xffff:0xca1
    7070:	c9                   	leave
    7071:	ca                   	.byte 0xca
    7072:	08                   	.byte 0x8
