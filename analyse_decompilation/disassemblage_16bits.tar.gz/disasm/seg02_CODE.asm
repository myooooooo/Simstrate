; ================================================================
; seg02_CODE  (24629 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	02 00                	add    al,BYTE PTR [bx+si]
       2:	f4                   	hlt
       3:	0b e9                	or     bp,cx
       5:	02 b1 00 00          	add    dh,BYTE PTR [bx+di+0x0]
       9:	00 9e 00 e7          	add    BYTE PTR [bp-0x1900],bl
       d:	04 fb                	add    al,0xfb
       f:	04 0e                	add    al,0xe
      11:	0c 39                	or     al,0x39
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 21 0c cb       	call   0xcb0c:0x211f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 bf 1c d6          	adc    BYTE PTR [bx-0x29e4],bh
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c b8                	sbb    al,0xb8
      61:	0c e2                	or     al,0xe2
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	12 54 46             	adc    dl,BYTE PTR [si+0x46]
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	41                   	inc    cx
      a6:	52                   	push   dx
      a7:	50                   	push   ax
      a8:	5f                   	pop    di
      a9:	50                   	push   ax
      aa:	72 6f                	jb     0x11b
      ac:	64 75 69             	fs jne 0x118
      af:	74 73                	je     0x124
      b1:	1d 00 72             	sbb    ax,0x7200
      b4:	11 c3                	adc    bx,ax
      b6:	00 09                	add    BYTE PTR [bx+di],cl
      b8:	46                   	inc    si
      b9:	6f                   	outs   dx,WORD PTR ds:[si]
      ba:	72 6d                	jb     0x129
      bc:	43                   	inc    bx
      bd:	6c                   	ins    BYTE PTR es:[di],dx
      be:	6f                   	outs   dx,WORD PTR ds:[si]
      bf:	73 65                	jae    0x126
      c1:	ed                   	in     ax,dx
      c2:	11 d2                	adc    dx,dx
      c4:	00 0a                	add    BYTE PTR [bp+si],cl
      c6:	46                   	inc    si
      c7:	6f                   	outs   dx,WORD PTR ds:[si]
      c8:	72 6d                	jb     0x137
      ca:	43                   	inc    bx
      cb:	72 65                	jb     0x132
      cd:	61                   	popa
      ce:	74 65                	je     0x135
      d0:	fc                   	cld
      d1:	36 e4 00             	ss in  al,0x0
      d4:	0d 51 75             	or     ax,0x7551
      d7:	69 74 74 65 72       	imul   si,WORD PTR [si+0x74],0x7265
      dc:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
      df:	69 63 6b 14 37       	imul   sp,WORD PTR [bp+di+0x6b],0x3714
      e4:	f9                   	stc
      e5:	00 10                	add    BYTE PTR [bx+si],dl
      e7:	50                   	push   ax
      e8:	6c                   	ins    BYTE PTR es:[di],dx
      e9:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
      ef:	61                   	popa
      f0:	6e                   	outs   dx,BYTE PTR ds:[si]
      f1:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
      f4:	69 63 6b 56 14       	imul   sp,WORD PTR [bp+di+0x6b],0x1456
      f9:	08 01                	or     BYTE PTR [bx+di],al
      fb:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
      fe:	72 6d                	jb     0x16d
     100:	52                   	push   dx
     101:	65 73 69             	gs jae 0x16d
     104:	7a 65                	jp     0x16b
     106:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     107:	10 1b                	adc    BYTE PTR [bp+di],bl
     109:	01 0e 49 6d          	add    WORD PTR ds:0x6d49,cx
     10d:	70 72                	jo     0x181
     10f:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     114:	43                   	inc    bx
     115:	6c                   	ins    BYTE PTR es:[di],dx
     116:	69 63 6b d7 4a       	imul   sp,WORD PTR [bp+di+0x6b],0x4ad7
     11b:	32 01                	xor    al,BYTE PTR [bx+di]
     11d:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     120:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     123:	45                   	inc    bp
     124:	52                   	push   dx
     125:	50                   	push   ax
     126:	43                   	inc    bx
     127:	61                   	popa
     128:	6c                   	ins    BYTE PTR es:[di],dx
     129:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     12c:	65 6c                	gs ins BYTE PTR es:[di],dx
     12e:	64 73 81             	fs jae 0xb2
     131:	38 49 01             	cmp    BYTE PTR [bx+di+0x1],cl
     134:	12 42 61             	adc    al,BYTE PTR [bp+si+0x61]
     137:	72 72                	jb     0x1ab
     139:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     13c:	75 74                	jne    0x1b2
     13e:	69 6c 73 31 43       	imul   bp,WORD PTR [si+0x73],0x4331
     143:	6c                   	ins    BYTE PTR es:[di],dx
     144:	69 63 6b 13 59       	imul   sp,WORD PTR [bp+di+0x6b],0x5913
     149:	59                   	pop    cx
     14a:	01 0b                	add    WORD PTR [bp+di],cx
     14c:	49                   	dec    cx
     14d:	6e                   	outs   dx,BYTE PTR ds:[si]
     14e:	64 65 78 31          	fs gs js 0x183
     152:	43                   	inc    bx
     153:	6c                   	ins    BYTE PTR es:[di],dx
     154:	69 63 6b 32 59       	imul   sp,WORD PTR [bp+di+0x6b],0x5932
     159:	6e                   	outs   dx,BYTE PTR ds:[si]
     15a:	01 10                	add    WORD PTR [bx+si],dx
     15c:	52                   	push   dx
     15d:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     161:	72 63                	jb     0x1c6
     163:	68 65 72             	push   0x7265
     166:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     169:	69 63 6b 53 59       	imul   sp,WORD PTR [bp+di+0x6b],0x5953
     16e:	86 01                	xchg   BYTE PTR [bx+di],al
     170:	13 55 74             	adc    dx,WORD PTR [di+0x74]
     173:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     178:	72 6c                	jb     0x1e6
     17a:	61                   	popa
     17b:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     180:	6c                   	ins    BYTE PTR es:[di],dx
     181:	69 63 6b 72 59       	imul   sp,WORD PTR [bp+di+0x6b],0x5972
     186:	98                   	cbw
     187:	01 0d                	add    WORD PTR [di],cx
     189:	41                   	inc    cx
     18a:	70 72                	jo     0x1fe
     18c:	6f                   	outs   dx,WORD PTR ds:[si]
     18d:	70 6f                	jo     0x1fe
     18f:	73 31                	jae    0x1c2
     191:	43                   	inc    bx
     192:	6c                   	ins    BYTE PTR es:[di],dx
     193:	69 63 6b 44 37       	imul   sp,WORD PTR [bp+di+0x6b],0x3744
     198:	aa                   	stos   BYTE PTR es:[di],al
     199:	01 0d                	add    WORD PTR [di],cx
     19b:	50                   	push   ax
     19c:	65 72 69             	gs jb  0x208
     19f:	6f                   	outs   dx,WORD PTR ds:[si]
     1a0:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     1a5:	69 63 6b 87 11       	imul   sp,WORD PTR [bp+di+0x6b],0x1187
     1aa:	b7 01                	mov    bh,0x1
     1ac:	08 46 6f             	or     BYTE PTR [bp+0x6f],al
     1af:	72 6d                	jb     0x21e
     1b1:	53                   	push   bx
     1b2:	68 6f 77             	push   0x776f
     1b5:	53                   	push   bx
     1b6:	58                   	pop    ax
     1b7:	c7 01 0b 46          	mov    WORD PTR [bx+di],0x460b
     1bb:	6f                   	outs   dx,WORD PTR ds:[si]
     1bc:	72 6d                	jb     0x22b
     1be:	4b                   	dec    bx
     1bf:	65 79 44             	gs jns 0x206
     1c2:	6f                   	outs   dx,WORD PTR ds:[si]
     1c3:	77 6e                	ja     0x233
     1c5:	e8 58 d7             	call   0xd920
     1c8:	01 0b                	add    WORD PTR [bp+di],cx
     1ca:	46                   	inc    si
     1cb:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     1d0:	43                   	inc    bx
     1d1:	6c                   	ins    BYTE PTR es:[di],dx
     1d2:	69 63 6b 89 3e       	imul   sp,WORD PTR [bp+di+0x6b],0x3e89
     1d7:	e8 01 0c             	call   0xddb
     1da:	43                   	inc    bx
     1db:	6f                   	outs   dx,WORD PTR ds:[si]
     1dc:	70 69                	jo     0x247
     1de:	65 72 31             	gs jb  0x212
     1e1:	43                   	inc    bx
     1e2:	6c                   	ins    BYTE PTR es:[di],dx
     1e3:	69 63 6b d8 33       	imul   sp,WORD PTR [bp+di+0x6b],0x33d8
     1e8:	f7 01 0a 4e          	test   WORD PTR [bx+di],0x4e0a
     1ec:	31 30                	xor    WORD PTR [bx+si],si
     1ee:	30 31                	xor    BYTE PTR [bx+di],dh
     1f0:	43                   	inc    bx
     1f1:	6c                   	ins    BYTE PTR es:[di],dx
     1f2:	69 63 6b 96 38       	imul   sp,WORD PTR [bp+di+0x6b],0x3896
     1f7:	12 02                	adc    al,BYTE PTR [bp+si]
     1f9:	16                   	push   ss
     1fa:	49                   	dec    cx
     1fb:	6d                   	ins    WORD PTR es:[di],dx
     1fc:	70 72                	jo     0x270
     1fe:	65 73 73             	gs jae 0x274
     201:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     206:	70 69                	jo     0x271
     208:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     20d:	69 63 6b bd 5b       	imul   sp,WORD PTR [bp+di+0x6b],0x5bbd
     212:	31 02                	xor    WORD PTR [bp+si],ax
     214:	1a 52 65             	sbb    dl,BYTE PTR [bp+si+0x65]
     217:	73 75                	jae    0x28e
     219:	6c                   	ins    BYTE PTR es:[di],dx
     21a:	74 61                	je     0x27d
     21c:	74 73                	je     0x291
     21e:	70 61                	jo     0x281
     220:	72 50                	jb     0x272
     222:	72 6f                	jb     0x293
     224:	64 75 69             	fs jne 0x290
     227:	74 73                	je     0x29c
     229:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     22c:	69 63 6b e8 5b       	imul   sp,WORD PTR [bp+di+0x6b],0x5be8
     231:	4d                   	dec    bp
     232:	02 17                	add    dl,BYTE PTR [bx]
     234:	52                   	push   dx
     235:	65 73 75             	gs jae 0x2ad
     238:	6c                   	ins    BYTE PTR es:[di],dx
     239:	74 61                	je     0x29c
     23b:	74 73                	je     0x2b0
     23d:	47                   	inc    di
     23e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     240:	65 72 61             	gs jb  0x2a4
     243:	75 78                	jne    0x2bd
     245:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     248:	69 63 6b 13 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5c13
     24d:	61                   	popa
     24e:	02 0f                	add    cl,BYTE PTR [bx]
     250:	41                   	inc    cx
     251:	6e                   	outs   dx,BYTE PTR ds:[si]
     252:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
     257:	75 72                	jne    0x2cb
     259:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     25c:	69 63 6b 2e 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5c2e
     261:	77 02                	ja     0x265
     263:	11 45 6e             	adc    WORD PTR [di+0x6e],ax
     266:	74 72                	je     0x2da
     268:	65 70 72             	gs jo  0x2dd
     26b:	69 73 65 73 31       	imul   si,WORD PTR [bp+di+0x65],0x3173
     270:	43                   	inc    bx
     271:	6c                   	ins    BYTE PTR es:[di],dx
     272:	69 63 6b 4f 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5c4f
     277:	8a 02                	mov    al,BYTE PTR [bp+si]
     279:	0e                   	push   cs
     27a:	43                   	inc    bx
     27b:	72 65                	jb     0x2e2
     27d:	61                   	popa
     27e:	74 69                	je     0x2e9
     280:	6f                   	outs   dx,WORD PTR ds:[si]
     281:	6e                   	outs   dx,BYTE PTR ds:[si]
     282:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     285:	69 63 6b 82 5c       	imul   sp,WORD PTR [bp+di+0x6b],0x5c82
     28a:	9a 02 0b 43 6f       	call   0x6f43:0xb02
     28f:	75 72                	jne    0x303
     291:	74 31                	je     0x2c4
     293:	43                   	inc    bx
     294:	6c                   	ins    BYTE PTR es:[di],dx
     295:	69 63 6b 23 5f       	imul   sp,WORD PTR [bp+di+0x6b],0x5f23
     29a:	ad                   	lods   ax,WORD PTR ds:[si]
     29b:	02 0e 45 67          	add    cl,BYTE PTR ds:0x6745
     29f:	61                   	popa
     2a0:	6c                   	ins    BYTE PTR es:[di],dx
     2a1:	69 73 65 72 31       	imul   si,WORD PTR [bp+di+0x65],0x3172
     2a6:	43                   	inc    bx
     2a7:	6c                   	ins    BYTE PTR es:[di],dx
     2a8:	69 63 6b f1 5a       	imul   sp,WORD PTR [bp+di+0x6b],0x5af1
     2ad:	cd 02                	int    0x2
     2af:	1b 53 70             	sbb    dx,WORD PTR [bp+di+0x70]
     2b2:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     2b6:	6c                   	ins    BYTE PTR es:[di],dx
     2b7:	53                   	push   bx
     2b8:	74 72                	je     0x32c
     2ba:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     2bf:	69 64 31 4d 6f       	imul   sp,WORD PTR [si+0x31],0x6f4d
     2c4:	75 73                	jne    0x339
     2c6:	65 44                	gs inc sp
     2c8:	6f                   	outs   dx,WORD PTR ds:[si]
     2c9:	77 6e                	ja     0x339
     2cb:	8f                   	(bad)
     2cc:	14 de                	adc    al,0xde
     2ce:	02 0c                	add    cl,BYTE PTR [si]
     2d0:	50                   	push   ax
     2d1:	61                   	popa
     2d2:	6e                   	outs   dx,BYTE PTR ds:[si]
     2d3:	65 6c                	gs ins BYTE PTR es:[di],dx
     2d5:	30 52 65             	xor    BYTE PTR [bp+si+0x65],dl
     2d8:	73 69                	jae    0x343
     2da:	7a 65                	jp     0x341
     2dc:	8b 37                	mov    si,WORD PTR [bx]
     2de:	0a 0c                	or     cl,BYTE PTR [si]
     2e0:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     2e3:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     2e6:	69 63 6b 88 00       	imul   sp,WORD PTR [bp+di+0x6b],0x88
     2eb:	be 0b 7c             	mov    si,0x7c0b
     2ee:	01 00                	add    WORD PTR [bx+si],ax
     2f0:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     2f4:	6e                   	outs   dx,BYTE PTR ds:[si]
     2f5:	65 6c                	gs ins BYTE PTR es:[di],dx
     2f7:	30 80 01 04          	xor    BYTE PTR [bx+si+0x401],al
     2fb:	00 09                	add    BYTE PTR [bx+di],cl
     2fd:	4d                   	dec    bp
     2fe:	61                   	popa
     2ff:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     304:	75 31                	jne    0x337
     306:	84 01                	test   BYTE PTR [bx+di],al
     308:	08 00                	or     BYTE PTR [bx+si],al
     30a:	08 46 69             	or     BYTE PTR [bp+0x69],al
     30d:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     310:	65 72 31             	gs jb  0x344
     313:	88 01                	mov    BYTE PTR [bx+di],al
     315:	08 00                	or     BYTE PTR [bx+si],al
     317:	09 49 6d             	or     WORD PTR [bx+di+0x6d],cx
     31a:	70 72                	jo     0x38e
     31c:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     321:	8c 01                	mov    WORD PTR [bx+di],es
     323:	08 00                	or     BYTE PTR [bx+si],al
     325:	02 4e 31             	add    cl,BYTE PTR [bp+0x31]
     328:	90                   	nop
     329:	01 08                	add    WORD PTR [bx+si],cx
     32b:	00 08                	add    BYTE PTR [bx+si],cl
     32d:	51                   	push   cx
     32e:	75 69                	jne    0x399
     330:	74 74                	je     0x3a6
     332:	65 72 31             	gs jb  0x366
     335:	94                   	xchg   sp,ax
     336:	01 08                	add    WORD PTR [bx+si],cx
     338:	00 0a                	add    BYTE PTR [bp+si],cl
     33a:	41                   	inc    cx
     33b:	66 66 69 63 68 61 67 	data32 imul esp,DWORD PTR [bp+di+0x68],0x31656761
     342:	65 31 
     344:	98                   	cbw
     345:	01 08                	add    WORD PTR [bx+si],cx
     347:	00 0d                	add    BYTE PTR [di],cl
     349:	42                   	inc    dx
     34a:	61                   	popa
     34b:	72 72                	jb     0x3bf
     34d:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     350:	75 74                	jne    0x3c6
     352:	69 6c 73 31 9c       	imul   bp,WORD PTR [si+0x73],0x9c31
     357:	01 08                	add    WORD PTR [bx+si],cx
     359:	00 0b                	add    BYTE PTR [bp+di],cl
     35b:	50                   	push   ax
     35c:	6c                   	ins    BYTE PTR es:[di],dx
     35d:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     363:	61                   	popa
     364:	6e                   	outs   dx,BYTE PTR ds:[si]
     365:	31 a0 01 08          	xor    WORD PTR [bx+si+0x801],sp
     369:	00 02                	add    BYTE PTR [bp+si],al
     36b:	4e                   	dec    si
     36c:	32 a4 01 08          	xor    ah,BYTE PTR [si+0x801]
     370:	00 05                	add    BYTE PTR [di],al
     372:	5a                   	pop    dx
     373:	6f                   	outs   dx,WORD PTR ds:[si]
     374:	6f                   	outs   dx,WORD PTR ds:[si]
     375:	6d                   	ins    WORD PTR es:[di],dx
     376:	31 a8 01 08          	xor    WORD PTR [bx+si+0x801],bp
     37a:	00 05                	add    BYTE PTR [di],al
     37c:	41                   	inc    cx
     37d:	69 64 65 31 ac       	imul   sp,WORD PTR [si+0x65],0xac31
     382:	01 08                	add    WORD PTR [bx+si],cx
     384:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     388:	64 65 78 31          	fs gs js 0x3bd
     38c:	b0 01                	mov    al,0x1
     38e:	08 00                	or     BYTE PTR [bx+si],al
     390:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
     393:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     396:	72 63                	jb     0x3fb
     398:	68 65 72             	push   0x7265
     39b:	31 b4 01 08          	xor    WORD PTR [si+0x801],si
     39f:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     3a3:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     3a8:	72 6c                	jb     0x416
     3aa:	61                   	popa
     3ab:	69 64 65 31 b8       	imul   sp,WORD PTR [si+0x65],0xb831
     3b0:	01 08                	add    WORD PTR [bx+si],cx
     3b2:	00 08                	add    BYTE PTR [bx+si],cl
     3b4:	41                   	inc    cx
     3b5:	70 72                	jo     0x429
     3b7:	6f                   	outs   dx,WORD PTR ds:[si]
     3b8:	70 6f                	jo     0x429
     3ba:	73 31                	jae    0x3ed
     3bc:	bc 01 0c             	mov    sp,0xc01
     3bf:	00 08                	add    BYTE PTR [bx+si],cl
     3c1:	54                   	push   sp
     3c2:	61                   	popa
     3c3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3c6:	45                   	inc    bp
     3c7:	52                   	push   dx
     3c8:	50                   	push   ax
     3c9:	c0 01 0c             	rol    BYTE PTR [bx+di],0xc
     3cc:	00 08                	add    BYTE PTR [bx+si],cl
     3ce:	54                   	push   sp
     3cf:	61                   	popa
     3d0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3d3:	45                   	inc    bp
     3d4:	44                   	inc    sp
     3d5:	50                   	push   ax
     3d6:	c4 01                	les    ax,DWORD PTR [bx+di]
     3d8:	0c 00                	or     al,0x0
     3da:	0c 54                	or     al,0x54
     3dc:	61                   	popa
     3dd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3e0:	45                   	inc    bp
     3e1:	52                   	push   dx
     3e2:	47                   	inc    di
     3e3:	5f                   	pop    di
     3e4:	4f                   	dec    di
     3e5:	6c                   	ins    BYTE PTR es:[di],dx
     3e6:	64 c8 01 0c 00       	fs enter 0xc01,0x0
     3eb:	08 54 61             	or     BYTE PTR [si+0x61],dl
     3ee:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3f1:	41                   	inc    cx
     3f2:	44                   	inc    sp
     3f3:	47                   	inc    di
     3f4:	cc                   	int3
     3f5:	01 10                	add    WORD PTR [bx+si],dx
     3f7:	00 13                	add    BYTE PTR [bp+di],dl
     3f9:	54                   	push   sp
     3fa:	61                   	popa
     3fb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3fe:	45                   	inc    bp
     3ff:	52                   	push   dx
     400:	50                   	push   ax
     401:	55                   	push   bp
     402:	74 69                	je     0x46d
     404:	6c                   	ins    BYTE PTR es:[di],dx
     405:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     40a:	6f                   	outs   dx,WORD PTR ds:[si]
     40b:	6e                   	outs   dx,BYTE PTR ds:[si]
     40c:	d0 01                	rol    BYTE PTR [bx+di],1
     40e:	0c 00                	or     al,0x0
     410:	08 54 61             	or     BYTE PTR [si+0x61],dl
     413:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     416:	41                   	inc    cx
     417:	44                   	inc    sp
     418:	50                   	push   ax
     419:	d4 01                	aam    0x1
     41b:	0c 00                	or     al,0x0
     41d:	0c 54                	or     al,0x54
     41f:	61                   	popa
     420:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     423:	45                   	inc    bp
     424:	52                   	push   dx
     425:	50                   	push   ax
     426:	5f                   	pop    di
     427:	4f                   	dec    di
     428:	6c                   	ins    BYTE PTR es:[di],dx
     429:	64 d8 01             	fadd   DWORD PTR fs:[bx+di]
     42c:	10 00                	adc    BYTE PTR [bx+si],al
     42e:	17                   	pop    ss
     42f:	54                   	push   sp
     430:	61                   	popa
     431:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     434:	45                   	inc    bp
     435:	52                   	push   dx
     436:	50                   	push   ax
     437:	43                   	inc    bx
     438:	6f                   	outs   dx,WORD PTR ds:[si]
     439:	75 74                	jne    0x4af
     43b:	50                   	push   ax
     43c:	72 6f                	jb     0x4ad
     43e:	64 75 63             	fs jne 0x4a4
     441:	74 69                	je     0x4ac
     443:	6f                   	outs   dx,WORD PTR ds:[si]
     444:	6e                   	outs   dx,BYTE PTR ds:[si]
     445:	55                   	push   bp
     446:	dc 01                	fadd   QWORD PTR [bx+di]
     448:	10 00                	adc    BYTE PTR [bx+si],al
     44a:	16                   	push   ss
     44b:	54                   	push   sp
     44c:	61                   	popa
     44d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     450:	45                   	inc    bp
     451:	52                   	push   dx
     452:	50                   	push   ax
     453:	50                   	push   ax
     454:	72 69                	jb     0x4bf
     456:	78 53                	js     0x4ab
     458:	75 72                	jne    0x4cc
     45a:	4d                   	dec    bp
     45b:	6f                   	outs   dx,WORD PTR ds:[si]
     45c:	79 65                	jns    0x4c3
     45e:	6e                   	outs   dx,BYTE PTR ds:[si]
     45f:	6e                   	outs   dx,BYTE PTR ds:[si]
     460:	65 e0 01             	gs loopne 0x464
     463:	10 00                	adc    BYTE PTR [bx+si],al
     465:	16                   	push   ss
     466:	54                   	push   sp
     467:	61                   	popa
     468:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     46b:	45                   	inc    bp
     46c:	52                   	push   dx
     46d:	50                   	push   ax
     46e:	50                   	push   ax
     46f:	75 62                	jne    0x4d3
     471:	43                   	inc    bx
     472:	41                   	inc    cx
     473:	54                   	push   sp
     474:	68 65 6f             	push   0x6f65
     477:	72 69                	jb     0x4e2
     479:	71 75                	jno    0x4f0
     47b:	65 e4 01             	gs in  al,0x1
     47e:	10 00                	adc    BYTE PTR [bx+si],al
     480:	11 54 61             	adc    WORD PTR [si+0x61],dx
     483:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     486:	45                   	inc    bp
     487:	52                   	push   dx
     488:	50                   	push   ax
     489:	50                   	push   ax
     48a:	75 62                	jne    0x4ee
     48c:	43                   	inc    bx
     48d:	41                   	inc    cx
     48e:	52                   	push   dx
     48f:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
     492:	e8 01 10             	call   0x1496
     495:	00 15                	add    BYTE PTR [di],dl
     497:	54                   	push   sp
     498:	61                   	popa
     499:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     49c:	45                   	inc    bp
     49d:	52                   	push   dx
     49e:	50                   	push   ax
     49f:	50                   	push   ax
     4a0:	75 62                	jne    0x504
     4a2:	53                   	push   bx
     4a3:	75 72                	jne    0x517
     4a5:	4d                   	dec    bp
     4a6:	6f                   	outs   dx,WORD PTR ds:[si]
     4a7:	79 65                	jns    0x50e
     4a9:	6e                   	outs   dx,BYTE PTR ds:[si]
     4aa:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ab:	65 ec                	gs in  al,dx
     4ad:	01 10                	add    WORD PTR [bx+si],dx
     4af:	00 1b                	add    BYTE PTR [bp+di],bl
     4b1:	54                   	push   sp
     4b2:	61                   	popa
     4b3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4b6:	45                   	inc    bp
     4b7:	52                   	push   dx
     4b8:	50                   	push   ax
     4b9:	56                   	push   si
     4ba:	65 6e                	outs   dx,BYTE PTR gs:[si]
     4bc:	64 65 75 72          	fs gs jne 0x532
     4c0:	50                   	push   ax
     4c1:	72 6f                	jb     0x532
     4c3:	64 75 63             	fs jne 0x529
     4c6:	74 69                	je     0x531
     4c8:	76 69                	jbe    0x533
     4ca:	74 65                	je     0x531
     4cc:	f0 01 10             	lock add WORD PTR [bx+si],dx
     4cf:	00 19                	add    BYTE PTR [bx+di],bl
     4d1:	54                   	push   sp
     4d2:	61                   	popa
     4d3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4d6:	45                   	inc    bp
     4d7:	52                   	push   dx
     4d8:	50                   	push   ax
     4d9:	56                   	push   si
     4da:	65 6e                	outs   dx,BYTE PTR gs:[si]
     4dc:	64 65 75 72          	fs gs jne 0x552
     4e0:	53                   	push   bx
     4e1:	75 72                	jne    0x555
     4e3:	4d                   	dec    bp
     4e4:	6f                   	outs   dx,WORD PTR ds:[si]
     4e5:	79 65                	jns    0x54c
     4e7:	6e                   	outs   dx,BYTE PTR ds:[si]
     4e8:	6e                   	outs   dx,BYTE PTR ds:[si]
     4e9:	65 f4                	gs hlt
     4eb:	01 10                	add    WORD PTR [bx+si],dx
     4ed:	00 18                	add    BYTE PTR [bx+si],bl
     4ef:	54                   	push   sp
     4f0:	61                   	popa
     4f1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     4f4:	45                   	inc    bp
     4f5:	52                   	push   dx
     4f6:	50                   	push   ax
     4f7:	43                   	inc    bx
     4f8:	72 65                	jb     0x55f
     4fa:	64 69 74 53 75 72    	imul   si,WORD PTR fs:[si+0x53],0x7275
     500:	4d                   	dec    bp
     501:	6f                   	outs   dx,WORD PTR ds:[si]
     502:	79 65                	jns    0x569
     504:	6e                   	outs   dx,BYTE PTR ds:[si]
     505:	6e                   	outs   dx,BYTE PTR ds:[si]
     506:	65 f8                	gs clc
     508:	01 10                	add    WORD PTR [bx+si],dx
     50a:	00 0a                	add    BYTE PTR [bp+si],cl
     50c:	54                   	push   sp
     50d:	61                   	popa
     50e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     511:	45                   	inc    bp
     512:	52                   	push   dx
     513:	50                   	push   ax
     514:	43                   	inc    bx
     515:	41                   	inc    cx
     516:	fc                   	cld
     517:	01 10                	add    WORD PTR [bx+si],dx
     519:	00 12                	add    BYTE PTR [bp+si],dl
     51b:	54                   	push   sp
     51c:	61                   	popa
     51d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     520:	45                   	inc    bp
     521:	52                   	push   dx
     522:	50                   	push   ax
     523:	4d                   	dec    bp
     524:	61                   	popa
     525:	72 67                	jb     0x58e
     527:	65 53                	gs push bx
     529:	75 72                	jne    0x59d
     52b:	43                   	inc    bx
     52c:	64 00 02             	add    BYTE PTR fs:[bp+si],al
     52f:	10 00                	adc    BYTE PTR [bx+si],al
     531:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     534:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     537:	45                   	inc    bp
     538:	52                   	push   dx
     539:	50                   	push   ax
     53a:	4d                   	dec    bp
     53b:	61                   	popa
     53c:	72 67                	jb     0x5a5
     53e:	65 53                	gs push bx
     540:	75 72                	jne    0x5b4
     542:	43                   	inc    bx
     543:	41                   	inc    cx
     544:	04 02                	add    al,0x2
     546:	08 00                	or     BYTE PTR [bx+si],al
     548:	08 50 65             	or     BYTE PTR [bx+si+0x65],dl
     54b:	72 69                	jb     0x5b6
     54d:	6f                   	outs   dx,WORD PTR ds:[si]
     54e:	64 65 31 08          	fs xor WORD PTR gs:[bx+si],cx
     552:	02 14                	add    dl,BYTE PTR [si]
     554:	00 0c                	add    BYTE PTR [si],cl
     556:	50                   	push   ax
     557:	72 69                	jb     0x5c2
     559:	6e                   	outs   dx,BYTE PTR ds:[si]
     55a:	74 44                	je     0x5a0
     55c:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     561:	31 0c                	xor    WORD PTR [si],cx
     563:	02 0c                	add    cl,BYTE PTR [si]
     565:	00 08                	add    BYTE PTR [bx+si],cl
     567:	54                   	push   sp
     568:	61                   	popa
     569:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     56c:	41                   	inc    cx
     56d:	43                   	inc    bx
     56e:	50                   	push   ax
     56f:	10 02                	adc    BYTE PTR [bp+si],al
     571:	18 00                	sbb    BYTE PTR [bx+si],al
     573:	11 54 61             	adc    WORD PTR [si+0x61],dx
     576:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     579:	45                   	inc    bp
     57a:	52                   	push   dx
     57b:	50                   	push   ax
     57c:	50                   	push   ax
     57d:	65 72 69             	gs jb  0x5e9
     580:	6f                   	outs   dx,WORD PTR ds:[si]
     581:	64 65 4e             	fs gs dec si
     584:	6f                   	outs   dx,WORD PTR ds:[si]
     585:	14 02                	adc    al,0x2
     587:	18 00                	sbb    BYTE PTR [bx+si],al
     589:	14 54                	adc    al,0x54
     58b:	61                   	popa
     58c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     58f:	45                   	inc    bp
     590:	52                   	push   dx
     591:	50                   	push   ax
     592:	45                   	inc    bp
     593:	6e                   	outs   dx,BYTE PTR ds:[si]
     594:	74 72                	je     0x608
     596:	65 70 72             	gs jo  0x60b
     599:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     59e:	18 02                	sbb    BYTE PTR [bp+si],al
     5a0:	18 00                	sbb    BYTE PTR [bx+si],al
     5a2:	11 54 61             	adc    WORD PTR [si+0x61],dx
     5a5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5a8:	45                   	inc    bp
     5a9:	52                   	push   dx
     5aa:	50                   	push   ax
     5ab:	50                   	push   ax
     5ac:	72 6f                	jb     0x61d
     5ae:	64 75 69             	fs jne 0x61a
     5b1:	74 4e                	je     0x601
     5b3:	6f                   	outs   dx,WORD PTR ds:[si]
     5b4:	1c 02                	sbb    al,0x2
     5b6:	1c 00                	sbb    al,0x0
     5b8:	11 54 61             	adc    WORD PTR [si+0x61],dx
     5bb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5be:	45                   	inc    bp
     5bf:	52                   	push   dx
     5c0:	50                   	push   ax
     5c1:	45                   	inc    bp
     5c2:	66 66 65 74 50       	data32 data32 gs je 0x617
     5c7:	72 69                	jb     0x632
     5c9:	78 20                	js     0x5eb
     5cb:	02 1c                	add    bl,BYTE PTR [si]
     5cd:	00 10                	add    BYTE PTR [bx+si],dl
     5cf:	54                   	push   sp
     5d0:	61                   	popa
     5d1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5d4:	45                   	inc    bp
     5d5:	52                   	push   dx
     5d6:	50                   	push   ax
     5d7:	45                   	inc    bp
     5d8:	66 66 65 74 50       	data32 data32 gs je 0x62d
     5dd:	75 62                	jne    0x641
     5df:	24 02                	and    al,0x2
     5e1:	1c 00                	sbb    al,0x0
     5e3:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     5e7:	6c                   	ins    BYTE PTR es:[di],dx
     5e8:	65 45                	gs inc bp
     5ea:	52                   	push   dx
     5eb:	50                   	push   ax
     5ec:	45                   	inc    bp
     5ed:	66 66 65 74 46       	data32 data32 gs je 0x638
     5f2:	56                   	push   si
     5f3:	28 02                	sub    BYTE PTR [bp+si],al
     5f5:	1c 00                	sbb    al,0x0
     5f7:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     5fa:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5fd:	45                   	inc    bp
     5fe:	52                   	push   dx
     5ff:	50                   	push   ax
     600:	45                   	inc    bp
     601:	66 66 65 74 43       	data32 data32 gs je 0x649
     606:	72 65                	jb     0x66d
     608:	64 69 74 2c 02 1c    	imul   si,WORD PTR fs:[si+0x2c],0x1c02
     60e:	00 13                	add    BYTE PTR [bp+di],dl
     610:	54                   	push   sp
     611:	61                   	popa
     612:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     615:	45                   	inc    bp
     616:	52                   	push   dx
     617:	50                   	push   ax
     618:	45                   	inc    bp
     619:	66 66 65 74 47       	data32 data32 gs je 0x665
     61e:	6c                   	ins    BYTE PTR es:[di],dx
     61f:	6f                   	outs   dx,WORD PTR ds:[si]
     620:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
     623:	30 02                	xor    BYTE PTR [bp+si],al
     625:	18 00                	sbb    BYTE PTR [bx+si],al
     627:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     62b:	6c                   	ins    BYTE PTR es:[di],dx
     62c:	65 45                	gs inc bp
     62e:	52                   	push   dx
     62f:	50                   	push   ax
     630:	44                   	inc    sp
     631:	65 6d                	gs ins WORD PTR es:[di],dx
     633:	61                   	popa
     634:	6e                   	outs   dx,BYTE PTR ds:[si]
     635:	64 65 34 02          	fs gs xor al,0x2
     639:	18 00                	sbb    BYTE PTR [bx+si],al
     63b:	0e                   	push   cs
     63c:	54                   	push   sp
     63d:	61                   	popa
     63e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     641:	45                   	inc    bp
     642:	52                   	push   dx
     643:	50                   	push   ax
     644:	56                   	push   si
     645:	65 6e                	outs   dx,BYTE PTR gs:[si]
     647:	74 65                	je     0x6ae
     649:	73 38                	jae    0x683
     64b:	02 18                	add    bl,BYTE PTR [bx+si]
     64d:	00 1c                	add    BYTE PTR [si],bl
     64f:	54                   	push   sp
     650:	61                   	popa
     651:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     654:	45                   	inc    bp
     655:	52                   	push   dx
     656:	50                   	push   ax
     657:	44                   	inc    sp
     658:	65 6d                	gs ins WORD PTR es:[di],dx
     65a:	61                   	popa
     65b:	6e                   	outs   dx,BYTE PTR ds:[si]
     65c:	64 65 4e             	fs gs dec si
     65f:	6f                   	outs   dx,WORD PTR ds:[si]
     660:	6e                   	outs   dx,BYTE PTR ds:[si]
     661:	53                   	push   bx
     662:	61                   	popa
     663:	74 69                	je     0x6ce
     665:	73 66                	jae    0x6cd
     667:	61                   	popa
     668:	69 74 65 3c 02       	imul   si,WORD PTR [si+0x65],0x23c
     66d:	18 00                	sbb    BYTE PTR [bx+si],al
     66f:	14 54                	adc    al,0x54
     671:	61                   	popa
     672:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     675:	45                   	inc    bp
     676:	52                   	push   dx
     677:	50                   	push   ax
     678:	56                   	push   si
     679:	65 6e                	outs   dx,BYTE PTR gs:[si]
     67b:	74 65                	je     0x6e2
     67d:	73 50                	jae    0x6cf
     67f:	72 69                	jb     0x6ea
     681:	73 65                	jae    0x6e8
     683:	73 40                	jae    0x6c5
     685:	02 1c                	add    bl,BYTE PTR [si]
     687:	00 12                	add    BYTE PTR [bp+si],dl
     689:	54                   	push   sp
     68a:	61                   	popa
     68b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     68e:	45                   	inc    bp
     68f:	52                   	push   dx
     690:	50                   	push   ax
     691:	50                   	push   ax
     692:	61                   	popa
     693:	72 74                	jb     0x709
     695:	4d                   	dec    bp
     696:	61                   	popa
     697:	72 63                	jb     0x6fc
     699:	68 65 44             	push   0x4465
     69c:	02 18                	add    bl,BYTE PTR [bx+si]
     69e:	00 10                	add    BYTE PTR [bx+si],dl
     6a0:	54                   	push   sp
     6a1:	61                   	popa
     6a2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6a5:	45                   	inc    bp
     6a6:	52                   	push   dx
     6a7:	50                   	push   ax
     6a8:	51                   	push   cx
     6a9:	74 65                	je     0x710
     6ab:	53                   	push   bx
     6ac:	74 6f                	je     0x71d
     6ae:	63 6b 48             	arpl   WORD PTR [bp+di+0x48],bp
     6b1:	02 1c                	add    bl,BYTE PTR [si]
     6b3:	00 13                	add    BYTE PTR [bp+di],dl
     6b5:	54                   	push   sp
     6b6:	61                   	popa
     6b7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6ba:	45                   	inc    bp
     6bb:	52                   	push   dx
     6bc:	50                   	push   ax
     6bd:	56                   	push   si
     6be:	61                   	popa
     6bf:	6c                   	ins    BYTE PTR es:[di],dx
     6c0:	65 75 72             	gs jne 0x735
     6c3:	53                   	push   bx
     6c4:	74 6f                	je     0x735
     6c6:	63 6b 4c             	arpl   WORD PTR [bp+di+0x4c],bp
     6c9:	02 1c                	add    bl,BYTE PTR [si]
     6cb:	00 18                	add    BYTE PTR [bx+si],bl
     6cd:	54                   	push   sp
     6ce:	61                   	popa
     6cf:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6d2:	45                   	inc    bp
     6d3:	52                   	push   dx
     6d4:	50                   	push   ax
     6d5:	44                   	inc    sp
     6d6:	6f                   	outs   dx,WORD PTR ds:[si]
     6d7:	74 41                	je     0x71a
     6d9:	6d                   	ins    WORD PTR es:[di],dx
     6da:	6f                   	outs   dx,WORD PTR ds:[si]
     6db:	72 74                	jb     0x751
     6dd:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     6e2:	65 6e                	outs   dx,BYTE PTR gs:[si]
     6e4:	74 50                	je     0x736
     6e6:	02 18                	add    bl,BYTE PTR [bx+si]
     6e8:	00 18                	add    BYTE PTR [bx+si],bl
     6ea:	54                   	push   sp
     6eb:	61                   	popa
     6ec:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6ef:	45                   	inc    bp
     6f0:	52                   	push   dx
     6f1:	50                   	push   ax
     6f2:	56                   	push   si
     6f3:	65 6e                	outs   dx,BYTE PTR gs:[si]
     6f5:	74 65                	je     0x75c
     6f7:	73 53                	jae    0x74c
     6f9:	6f                   	outs   dx,WORD PTR ds:[si]
     6fa:	6c                   	ins    BYTE PTR es:[di],dx
     6fb:	64 65 65 73 51       	fs gs gs jae 0x751
     700:	74 65                	je     0x767
     702:	54                   	push   sp
     703:	02 1c                	add    bl,BYTE PTR [si]
     705:	00 19                	add    BYTE PTR [bx+di],bl
     707:	54                   	push   sp
     708:	61                   	popa
     709:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     70c:	45                   	inc    bp
     70d:	52                   	push   dx
     70e:	50                   	push   ax
     70f:	56                   	push   si
     710:	65 6e                	outs   dx,BYTE PTR gs:[si]
     712:	74 65                	je     0x779
     714:	73 53                	jae    0x769
     716:	6f                   	outs   dx,WORD PTR ds:[si]
     717:	6c                   	ins    BYTE PTR es:[di],dx
     718:	64 65 65 73 50       	fs gs gs jae 0x76d
     71d:	72 69                	jb     0x788
     71f:	78 58                	js     0x779
     721:	02 18                	add    bl,BYTE PTR [bx+si]
     723:	00 14                	add    BYTE PTR [si],dl
     725:	54                   	push   sp
     726:	61                   	popa
     727:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     72a:	45                   	inc    bp
     72b:	52                   	push   dx
     72c:	50                   	push   ax
     72d:	56                   	push   si
     72e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     730:	74 65                	je     0x797
     732:	73 53                	jae    0x787
     734:	70 65                	jo     0x79b
     736:	51                   	push   cx
     737:	74 65                	je     0x79e
     739:	5c                   	pop    sp
     73a:	02 1c                	add    bl,BYTE PTR [si]
     73c:	00 15                	add    BYTE PTR [di],dl
     73e:	54                   	push   sp
     73f:	61                   	popa
     740:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     743:	45                   	inc    bp
     744:	52                   	push   dx
     745:	50                   	push   ax
     746:	56                   	push   si
     747:	65 6e                	outs   dx,BYTE PTR gs:[si]
     749:	74 65                	je     0x7b0
     74b:	73 53                	jae    0x7a0
     74d:	70 65                	jo     0x7b4
     74f:	50                   	push   ax
     750:	72 69                	jb     0x7bb
     752:	78 60                	js     0x7b4
     754:	02 1c                	add    bl,BYTE PTR [si]
     756:	00 19                	add    BYTE PTR [bx+di],bl
     758:	54                   	push   sp
     759:	61                   	popa
     75a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     75d:	45                   	inc    bp
     75e:	52                   	push   dx
     75f:	50                   	push   ax
     760:	4d                   	dec    bp
     761:	61                   	popa
     762:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
     767:	76 72                	jbe    0x7db
     769:	65 44                	gs inc sp
     76b:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
     770:	65 64 02 1c          	gs add bl,BYTE PTR fs:[si]
     774:	00 1b                	add    BYTE PTR [bp+di],bl
     776:	54                   	push   sp
     777:	61                   	popa
     778:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     77b:	45                   	inc    bp
     77c:	52                   	push   dx
     77d:	50                   	push   ax
     77e:	43                   	inc    bx
     77f:	6f                   	outs   dx,WORD PTR ds:[si]
     780:	6e                   	outs   dx,BYTE PTR ds:[si]
     781:	73 6f                	jae    0x7f2
     783:	6d                   	ins    WORD PTR es:[di],dx
     784:	6d                   	ins    WORD PTR es:[di],dx
     785:	61                   	popa
     786:	74 69                	je     0x7f1
     788:	6f                   	outs   dx,WORD PTR ds:[si]
     789:	6e                   	outs   dx,BYTE PTR ds:[si]
     78a:	4d                   	dec    bp
     78b:	61                   	popa
     78c:	74 69                	je     0x7f7
     78e:	65 72 65             	gs jb  0x7f6
     791:	68 02 10             	push   0x1002
     794:	00 1d                	add    BYTE PTR [di],bl
     796:	54                   	push   sp
     797:	61                   	popa
     798:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     79b:	45                   	inc    bp
     79c:	52                   	push   dx
     79d:	50                   	push   ax
     79e:	54                   	push   sp
     79f:	65 6d                	gs ins WORD PTR es:[di],dx
     7a1:	70 73                	jo     0x816
     7a3:	46                   	inc    si
     7a4:	61                   	popa
     7a5:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
     7a8:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
     7ab:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
     7b0:	74 75                	je     0x827
     7b2:	72 6c                	jb     0x820
     7b4:	02 18                	add    bl,BYTE PTR [bx+si]
     7b6:	00 0f                	add    BYTE PTR [bx],cl
     7b8:	54                   	push   sp
     7b9:	61                   	popa
     7ba:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7bd:	45                   	inc    bp
     7be:	52                   	push   dx
     7bf:	50                   	push   ax
     7c0:	53                   	push   bx
     7c1:	70 65                	jo     0x828
     7c3:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     7c6:	6c                   	ins    BYTE PTR es:[di],dx
     7c7:	70 02                	jo     0x7cb
     7c9:	1c 00                	sbb    al,0x0
     7cb:	16                   	push   ss
     7cc:	54                   	push   sp
     7cd:	61                   	popa
     7ce:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7d1:	45                   	inc    bp
     7d2:	52                   	push   dx
     7d3:	50                   	push   ax
     7d4:	52                   	push   dx
     7d5:	65 6d                	gs ins WORD PTR es:[di],dx
     7d7:	75 6e                	jne    0x847
     7d9:	65 72 61             	gs jb  0x83d
     7dc:	74 69                	je     0x847
     7de:	6f                   	outs   dx,WORD PTR ds:[si]
     7df:	6e                   	outs   dx,BYTE PTR ds:[si]
     7e0:	46                   	inc    si
     7e1:	56                   	push   si
     7e2:	74 02                	je     0x7e6
     7e4:	08 00                	or     BYTE PTR [bx+si],al
     7e6:	06                   	push   es
     7e7:	46                   	inc    si
     7e8:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     7ed:	78 02                	js     0x7f1
     7ef:	08 00                	or     BYTE PTR [bx+si],al
     7f1:	02 4e 33             	add    cl,BYTE PTR [bp+0x33]
     7f4:	7c 02                	jl     0x7f8
     7f6:	1c 00                	sbb    al,0x0
     7f8:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     7fb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7fe:	45                   	inc    bp
     7ff:	52                   	push   dx
     800:	50                   	push   ax
     801:	48                   	dec    ax
     802:	65 75 72             	gs jne 0x877
     805:	65 73 53             	gs jae 0x85b
     808:	75 70                	jne    0x87a
     80a:	50                   	push   ax
     80b:	63 80 02 00          	arpl   WORD PTR [bx+si+0x2],ax
     80f:	00 07                	add    BYTE PTR [bx],al
     811:	50                   	push   ax
     812:	61                   	popa
     813:	6e                   	outs   dx,BYTE PTR ds:[si]
     814:	65 6c                	gs ins BYTE PTR es:[di],dx
     816:	34 34                	xor    al,0x34
     818:	84 02                	test   BYTE PTR [bp+si],al
     81a:	20 00                	and    BYTE PTR [bx+si],al
     81c:	07                   	pop    es
     81d:	4c                   	dec    sp
     81e:	61                   	popa
     81f:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     822:	55                   	push   bp
     823:	30 88 02 20          	xor    BYTE PTR [bx+si+0x2002],cl
     827:	00 07                	add    BYTE PTR [bx],al
     829:	4c                   	dec    sp
     82a:	61                   	popa
     82b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     82e:	55                   	push   bp
     82f:	31 8c 02 20          	xor    WORD PTR [si+0x2002],cx
     833:	00 07                	add    BYTE PTR [bx],al
     835:	4c                   	dec    sp
     836:	61                   	popa
     837:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     83a:	55                   	push   bp
     83b:	32 90 02 20          	xor    dl,BYTE PTR [bx+si+0x2002]
     83f:	00 07                	add    BYTE PTR [bx],al
     841:	4c                   	dec    sp
     842:	61                   	popa
     843:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     846:	55                   	push   bp
     847:	33 94 02 24          	xor    dx,WORD PTR [si+0x2402]
     84b:	00 08                	add    BYTE PTR [bx+si],cl
     84d:	4c                   	dec    sp
     84e:	69 73 74 42 6f       	imul   si,WORD PTR [bp+di+0x74],0x6f42
     853:	78 31                	js     0x886
     855:	98                   	cbw
     856:	02 08                	add    cl,BYTE PTR [bx+si]
     858:	00 08                	add    BYTE PTR [bx+si],cl
     85a:	45                   	inc    bp
     85b:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
     861:	31 9c 02 08          	xor    WORD PTR [si+0x802],bx
     865:	00 07                	add    BYTE PTR [bx],al
     867:	43                   	inc    bx
     868:	6f                   	outs   dx,WORD PTR ds:[si]
     869:	70 69                	jo     0x8d4
     86b:	65 72 31             	gs jb  0x89f
     86e:	a0 02 28             	mov    al,ds:0x2802
     871:	00 05                	add    BYTE PTR [di],al
     873:	4d                   	dec    bp
     874:	65 6d                	gs ins WORD PTR es:[di],dx
     876:	6f                   	outs   dx,WORD PTR ds:[si]
     877:	31 a4 02 18          	xor    WORD PTR [si+0x1802],sp
     87b:	00 18                	add    BYTE PTR [bx+si],bl
     87d:	54                   	push   sp
     87e:	61                   	popa
     87f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     882:	45                   	inc    bp
     883:	52                   	push   dx
     884:	50                   	push   ax
     885:	50                   	push   ax
     886:	72 6f                	jb     0x8f7
     888:	64 75 63             	fs jne 0x8ee
     88b:	74 69                	je     0x8f6
     88d:	6f                   	outs   dx,WORD PTR ds:[si]
     88e:	6e                   	outs   dx,BYTE PTR ds:[si]
     88f:	52                   	push   dx
     890:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
     893:	6c                   	ins    BYTE PTR es:[di],dx
     894:	65 a8 02             	gs test al,0x2
     897:	1c 00                	sbb    al,0x0
     899:	14 54                	adc    al,0x54
     89b:	61                   	popa
     89c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     89f:	45                   	inc    bp
     8a0:	52                   	push   dx
     8a1:	50                   	push   ax
     8a2:	45                   	inc    bp
     8a3:	66 66 65 74 51       	data32 data32 gs je 0x8f9
     8a8:	75 61                	jne    0x90b
     8aa:	6c                   	ins    BYTE PTR es:[di],dx
     8ab:	69 74 65 ac 02       	imul   si,WORD PTR [si+0x65],0x2ac
     8b0:	08 00                	or     BYTE PTR [bx+si],al
     8b2:	05 4e 31             	add    ax,0x314e
     8b5:	30 30                	xor    BYTE PTR [bx+si],dh
     8b7:	31 b0 02 08          	xor    WORD PTR [bx+si+0x802],si
     8bb:	00 05                	add    BYTE PTR [di],al
     8bd:	4e                   	dec    si
     8be:	31 35                	xor    WORD PTR [di],si
     8c0:	30 31                	xor    BYTE PTR [bx+di],dh
     8c2:	b4 02                	mov    ah,0x2
     8c4:	08 00                	or     BYTE PTR [bx+si],al
     8c6:	05 4e 32             	add    ax,0x324e
     8c9:	30 30                	xor    BYTE PTR [bx+si],dh
     8cb:	31 b8 02 08          	xor    WORD PTR [bx+si+0x802],di
     8cf:	00 04                	add    BYTE PTR [si],al
     8d1:	4e                   	dec    si
     8d2:	37                   	aaa
     8d3:	35 31 bc             	xor    ax,0xbc31
     8d6:	02 08                	add    cl,BYTE PTR [bx+si]
     8d8:	00 04                	add    BYTE PTR [si],al
     8da:	4e                   	dec    si
     8db:	35 30 31             	xor    ax,0x3130
     8de:	c0 02 08             	rol    BYTE PTR [bp+si],0x8
     8e1:	00 02                	add    BYTE PTR [bp+si],al
     8e3:	4e                   	dec    si
     8e4:	34 c4                	xor    al,0xc4
     8e6:	02 08                	add    cl,BYTE PTR [bx+si]
     8e8:	00 10                	add    BYTE PTR [bx+si],dl
     8ea:	41                   	inc    cx
     8eb:	75 74                	jne    0x961
     8ed:	72 65                	jb     0x954
     8ef:	73 52                	jae    0x943
     8f1:	65 73 75             	gs jae 0x969
     8f4:	6c                   	ins    BYTE PTR es:[di],dx
     8f5:	74 61                	je     0x958
     8f7:	74 73                	je     0x96c
     8f9:	31 c8                	xor    ax,cx
     8fb:	02 08                	add    cl,BYTE PTR [bx+si]
     8fd:	00 12                	add    BYTE PTR [bp+si],dl
     8ff:	52                   	push   dx
     900:	61                   	popa
     901:	70 70                	jo     0x973
     903:	65 6c                	gs ins BYTE PTR es:[di],dx
     905:	44                   	inc    sp
     906:	65 44                	gs inc sp
     908:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     90c:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     911:	cc                   	int3
     912:	02 08                	add    cl,BYTE PTR [bx+si]
     914:	00 09                	add    BYTE PTR [bx+di],cl
     916:	43                   	inc    bx
     917:	72 65                	jb     0x97e
     919:	61                   	popa
     91a:	74 69                	je     0x985
     91c:	6f                   	outs   dx,WORD PTR ds:[si]
     91d:	6e                   	outs   dx,BYTE PTR ds:[si]
     91e:	31 d0                	xor    ax,dx
     920:	02 08                	add    cl,BYTE PTR [bx+si]
     922:	00 0c                	add    BYTE PTR [si],cl
     924:	45                   	inc    bp
     925:	6e                   	outs   dx,BYTE PTR ds:[si]
     926:	74 72                	je     0x99a
     928:	65 70 72             	gs jo  0x99d
     92b:	69 73 65 73 31       	imul   si,WORD PTR [bp+di+0x65],0x3173
     930:	d4 02                	aam    0x2
     932:	08 00                	or     BYTE PTR [bx+si],al
     934:	0a 41 6e             	or     al,BYTE PTR [bx+di+0x6e]
     937:	69 6d 61 74 65       	imul   bp,WORD PTR [di+0x61],0x6574
     93c:	75 72                	jne    0x9b0
     93e:	31 d8                	xor    ax,bx
     940:	02 08                	add    cl,BYTE PTR [bx+si]
     942:	00 02                	add    BYTE PTR [bp+si],al
     944:	4e                   	dec    si
     945:	35 dc 02             	xor    ax,0x2dc
     948:	08 00                	or     BYTE PTR [bx+si],al
     94a:	12 52 65             	adc    dl,BYTE PTR [bp+si+0x65]
     94d:	73 75                	jae    0x9c4
     94f:	6c                   	ins    BYTE PTR es:[di],dx
     950:	74 61                	je     0x9b3
     952:	74 73                	je     0x9c7
     954:	47                   	inc    di
     955:	65 6e                	outs   dx,BYTE PTR gs:[si]
     957:	65 72 61             	gs jb  0x9bb
     95a:	75 78                	jne    0x9d4
     95c:	31 e0                	xor    ax,sp
     95e:	02 08                	add    cl,BYTE PTR [bx+si]
     960:	00 15                	add    BYTE PTR [di],dl
     962:	52                   	push   dx
     963:	65 73 75             	gs jae 0x9db
     966:	6c                   	ins    BYTE PTR es:[di],dx
     967:	74 61                	je     0x9ca
     969:	74 73                	je     0x9de
     96b:	70 61                	jo     0x9ce
     96d:	72 50                	jb     0x9bf
     96f:	72 6f                	jb     0x9e0
     971:	64 75 69             	fs jne 0x9dd
     974:	74 73                	je     0x9e9
     976:	31 e4                	xor    sp,sp
     978:	02 08                	add    cl,BYTE PTR [bx+si]
     97a:	00 11                	add    BYTE PTR [bx+di],dl
     97c:	49                   	dec    cx
     97d:	6d                   	ins    WORD PTR es:[di],dx
     97e:	70 72                	jo     0x9f2
     980:	65 73 73             	gs jae 0x9f6
     983:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     988:	70 69                	jo     0x9f3
     98a:	64 65 31 e8          	fs gs xor ax,bp
     98e:	02 08                	add    cl,BYTE PTR [bx+si]
     990:	00 02                	add    BYTE PTR [bp+si],al
     992:	4e                   	dec    si
     993:	36 ec                	ss in  al,dx
     995:	02 08                	add    cl,BYTE PTR [bx+si]
     997:	00 07                	add    BYTE PTR [bx],al
     999:	46                   	inc    si
     99a:	6f                   	outs   dx,WORD PTR ds:[si]
     99b:	72 6d                	jb     0xa0a
     99d:	61                   	popa
     99e:	74 31                	je     0x9d1
     9a0:	f0 02 08             	lock add cl,BYTE PTR [bx+si]
     9a3:	00 06 53 74          	add    BYTE PTR ds:0x7453,al
     9a7:	79 6c                	jns    0xa15
     9a9:	65 31 f4             	gs xor sp,si
     9ac:	02 08                	add    cl,BYTE PTR [bx+si]
     9ae:	00 05                	add    BYTE PTR [di],al
     9b0:	4c                   	dec    sp
     9b1:	6f                   	outs   dx,WORD PTR ds:[si]
     9b2:	6e                   	outs   dx,BYTE PTR ds:[si]
     9b3:	67 31 f8             	addr32 xor ax,di
     9b6:	02 08                	add    cl,BYTE PTR [bx+si]
     9b8:	00 07                	add    BYTE PTR [bx],al
     9ba:	4e                   	dec    si
     9bb:	6f                   	outs   dx,WORD PTR ds:[si]
     9bc:	72 6d                	jb     0xa2b
     9be:	61                   	popa
     9bf:	6c                   	ins    BYTE PTR es:[di],dx
     9c0:	31 fc                	xor    sp,di
     9c2:	02 08                	add    cl,BYTE PTR [bx+si]
     9c4:	00 06 43 6f          	add    BYTE PTR ds:0x6f43,al
     9c8:	75 72                	jne    0xa3c
     9ca:	74 31                	je     0x9fd
     9cc:	00 03                	add    BYTE PTR [bp+di],al
     9ce:	08 00                	or     BYTE PTR [bx+si],al
     9d0:	09 45 67             	or     WORD PTR [di+0x67],ax
     9d3:	61                   	popa
     9d4:	6c                   	ins    BYTE PTR es:[di],dx
     9d5:	69 73 65 72 31       	imul   si,WORD PTR [bp+di+0x65],0x3172
     9da:	04 03                	add    al,0x3
     9dc:	00 00                	add    BYTE PTR [bx+si],al
     9de:	06                   	push   es
     9df:	50                   	push   ax
     9e0:	61                   	popa
     9e1:	6e                   	outs   dx,BYTE PTR ds:[si]
     9e2:	65 6c                	gs ins BYTE PTR es:[di],dx
     9e4:	31 08                	xor    WORD PTR [bx+si],cx
     9e6:	03 00                	add    ax,WORD PTR [bx+si]
     9e8:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     9ec:	6e                   	outs   dx,BYTE PTR ds:[si]
     9ed:	65 6c                	gs ins BYTE PTR es:[di],dx
     9ef:	32 0c                	xor    cl,BYTE PTR [si]
     9f1:	03 00                	add    ax,WORD PTR [bx+si]
     9f3:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     9f7:	6e                   	outs   dx,BYTE PTR ds:[si]
     9f8:	65 6c                	gs ins BYTE PTR es:[di],dx
     9fa:	34 10                	xor    al,0x10
     9fc:	03 00                	add    ax,WORD PTR [bx+si]
     9fe:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     a02:	6e                   	outs   dx,BYTE PTR ds:[si]
     a03:	65 6c                	gs ins BYTE PTR es:[di],dx
     a05:	33 14                	xor    dx,WORD PTR [si]
     a07:	03 00                	add    ax,WORD PTR [bx+si]
     a09:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     a0d:	6e                   	outs   dx,BYTE PTR ds:[si]
     a0e:	65 6c                	gs ins BYTE PTR es:[di],dx
     a10:	35 18 03             	xor    ax,0x318
     a13:	2c 00                	sub    al,0x0
     a15:	05 45 64             	add    ax,0x6445
     a18:	69 74 31 1c 03       	imul   si,WORD PTR [si+0x31],0x31c
     a1d:	30 00                	xor    BYTE PTR [bx+si],al
     a1f:	12 53 70             	adc    dl,BYTE PTR [bp+di+0x70]
     a22:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     a26:	6c                   	ins    BYTE PTR es:[di],dx
     a27:	53                   	push   bx
     a28:	74 72                	je     0xa9c
     a2a:	69 6e 67 47 72       	imul   bp,WORD PTR [bp+0x67],0x7247
     a2f:	69 64 31 20 03       	imul   sp,WORD PTR [si+0x31],0x320
     a34:	00 00                	add    BYTE PTR [bx+si],al
     a36:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     a39:	6e                   	outs   dx,BYTE PTR ds:[si]
     a3a:	65 6c                	gs ins BYTE PTR es:[di],dx
     a3c:	4c                   	dec    sp
     a3d:	6f                   	outs   dx,WORD PTR ds:[si]
     a3e:	75 70                	jne    0xab0
     a40:	65 24 03             	gs and al,0x3
     a43:	10 00                	adc    BYTE PTR [bx+si],al
     a45:	11 54 61             	adc    WORD PTR [si+0x61],dx
     a48:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a4b:	45                   	inc    bp
     a4c:	52                   	push   dx
     a4d:	50                   	push   ax
     a4e:	43                   	inc    bx
     a4f:	61                   	popa
     a50:	70 50                	jo     0xaa2
     a52:	72 6f                	jb     0xac3
     a54:	64 75 63             	fs jne 0xaba
     a57:	28 03                	sub    BYTE PTR [bp+di],al
     a59:	08 00                	or     BYTE PTR [bx+si],al
     a5b:	05 4e 31             	add    ax,0x314e
     a5e:	32 35                	xor    dh,BYTE PTR [di]
     a60:	31 2c                	xor    WORD PTR [si],bp
     a62:	03 08                	add    cx,WORD PTR [bx+si]
     a64:	00 08                	add    BYTE PTR [bx+si],cl
     a66:	50                   	push   ax
     a67:	65 72 69             	gs jb  0xad3
     a6a:	6f                   	outs   dx,WORD PTR ds:[si]
     a6b:	64 65 32 30          	fs xor dh,BYTE PTR gs:[bx+si]
     a6f:	03 08                	add    cx,WORD PTR [bx+si]
     a71:	00 06 61 75          	add    BYTE PTR ds:0x7561,al
     a75:	74 72                	je     0xae9
     a77:	65 31 34             	xor    WORD PTR gs:[si],si
     a7a:	03 08                	add    cx,WORD PTR [bx+si]
     a7c:	00 04                	add    BYTE PTR [si],al
     a7e:	4e                   	dec    si
     a7f:	32 30                	xor    dh,BYTE PTR [bx+si]
     a81:	31 38                	xor    WORD PTR [bx+si],di
     a83:	03 08                	add    cx,WORD PTR [bx+si]
     a85:	00 04                	add    BYTE PTR [si],al
     a87:	4e                   	dec    si
     a88:	31 39                	xor    WORD PTR [bx+di],di
     a8a:	31 3c                	xor    WORD PTR [si],di
     a8c:	03 08                	add    cx,WORD PTR [bx+si]
     a8e:	00 04                	add    BYTE PTR [si],al
     a90:	4e                   	dec    si
     a91:	31 38                	xor    WORD PTR [bx+si],di
     a93:	31 40 03             	xor    WORD PTR [bx+si+0x3],ax
     a96:	08 00                	or     BYTE PTR [bx+si],al
     a98:	04 4e                	add    al,0x4e
     a9a:	31 37                	xor    WORD PTR [bx],si
     a9c:	31 44 03             	xor    WORD PTR [si+0x3],ax
     a9f:	08 00                	or     BYTE PTR [bx+si],al
     aa1:	04 4e                	add    al,0x4e
     aa3:	31 36 31 48          	xor    WORD PTR ds:0x4831,si
     aa7:	03 08                	add    cx,WORD PTR [bx+si]
     aa9:	00 04                	add    BYTE PTR [si],al
     aab:	4e                   	dec    si
     aac:	31 35                	xor    WORD PTR [di],si
     aae:	31 4c 03             	xor    WORD PTR [si+0x3],cx
     ab1:	08 00                	or     BYTE PTR [bx+si],al
     ab3:	04 4e                	add    al,0x4e
     ab5:	31 34                	xor    WORD PTR [si],si
     ab7:	31 50 03             	xor    WORD PTR [bx+si+0x3],dx
     aba:	08 00                	or     BYTE PTR [bx+si],al
     abc:	04 4e                	add    al,0x4e
     abe:	31 33                	xor    WORD PTR [bp+di],si
     ac0:	31 54 03             	xor    WORD PTR [si+0x3],dx
     ac3:	08 00                	or     BYTE PTR [bx+si],al
     ac5:	04 4e                	add    al,0x4e
     ac7:	31 32                	xor    WORD PTR [bp+si],si
     ac9:	31 58 03             	xor    WORD PTR [bx+si+0x3],bx
     acc:	08 00                	or     BYTE PTR [bx+si],al
     ace:	04 4e                	add    al,0x4e
     ad0:	31 31                	xor    WORD PTR [bx+di],si
     ad2:	31 5c 03             	xor    WORD PTR [si+0x3],bx
     ad5:	08 00                	or     BYTE PTR [bx+si],al
     ad7:	04 4e                	add    al,0x4e
     ad9:	31 30                	xor    WORD PTR [bx+si],si
     adb:	31 60 03             	xor    WORD PTR [bx+si+0x3],sp
     ade:	08 00                	or     BYTE PTR [bx+si],al
     ae0:	03 4e 39             	add    cx,WORD PTR [bp+0x39]
     ae3:	31 64 03             	xor    WORD PTR [si+0x3],sp
     ae6:	08 00                	or     BYTE PTR [bx+si],al
     ae8:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
     aeb:	31 68 03             	xor    WORD PTR [bx+si+0x3],bp
     aee:	08 00                	or     BYTE PTR [bx+si],al
     af0:	03 4e 37             	add    cx,WORD PTR [bp+0x37]
     af3:	31 6c 03             	xor    WORD PTR [si+0x3],bp
     af6:	08 00                	or     BYTE PTR [bx+si],al
     af8:	03 4e 36             	add    cx,WORD PTR [bp+0x36]
     afb:	31 70 03             	xor    WORD PTR [bx+si+0x3],si
     afe:	08 00                	or     BYTE PTR [bx+si],al
     b00:	03 4e 35             	add    cx,WORD PTR [bp+0x35]
     b03:	31 74 03             	xor    WORD PTR [si+0x3],si
     b06:	08 00                	or     BYTE PTR [bx+si],al
     b08:	03 4e 34             	add    cx,WORD PTR [bp+0x34]
     b0b:	31 78 03             	xor    WORD PTR [bx+si+0x3],di
     b0e:	08 00                	or     BYTE PTR [bx+si],al
     b10:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     b13:	31 7c 03             	xor    WORD PTR [si+0x3],di
     b16:	08 00                	or     BYTE PTR [bx+si],al
     b18:	03 4e 32             	add    cx,WORD PTR [bp+0x32]
     b1b:	31 80 03 08          	xor    WORD PTR [bx+si+0x803],ax
     b1f:	00 03                	add    BYTE PTR [bp+di],al
     b21:	4e                   	dec    si
     b22:	31 31                	xor    WORD PTR [bx+di],si
     b24:	84 03                	test   BYTE PTR [bp+di],al
     b26:	10 00                	adc    BYTE PTR [bx+si],al
     b28:	14 54                	adc    al,0x54
     b2a:	61                   	popa
     b2b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b2e:	45                   	inc    bp
     b2f:	52                   	push   dx
     b30:	50                   	push   ax
     b31:	45                   	inc    bp
     b32:	66 66 65 74 50       	data32 data32 gs je 0xb87
     b37:	72 69                	jb     0xba2
     b39:	78 31                	js     0xb6c
     b3b:	30 30                	xor    BYTE PTR [bx+si],dh
     b3d:	88 03                	mov    BYTE PTR [bp+di],al
     b3f:	10 00                	adc    BYTE PTR [bx+si],al
     b41:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     b44:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b47:	45                   	inc    bp
     b48:	52                   	push   dx
     b49:	50                   	push   ax
     b4a:	45                   	inc    bp
     b4b:	66 66 65 74 46       	data32 data32 gs je 0xb96
     b50:	56                   	push   si
     b51:	31 30                	xor    WORD PTR [bx+si],si
     b53:	30 8c 03 10          	xor    BYTE PTR [si+0x1003],cl
     b57:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     b5b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b5e:	45                   	inc    bp
     b5f:	52                   	push   dx
     b60:	50                   	push   ax
     b61:	45                   	inc    bp
     b62:	66 66 65 74 43       	data32 data32 gs je 0xbaa
     b67:	72 65                	jb     0xbce
     b69:	64 69 74 31 30 30    	imul   si,WORD PTR fs:[si+0x31],0x3030
     b6f:	90                   	nop
     b70:	03 10                	add    dx,WORD PTR [bx+si]
     b72:	00 17                	add    BYTE PTR [bx],dl
     b74:	54                   	push   sp
     b75:	61                   	popa
     b76:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b79:	45                   	inc    bp
     b7a:	52                   	push   dx
     b7b:	50                   	push   ax
     b7c:	45                   	inc    bp
     b7d:	66 66 65 74 51       	data32 data32 gs je 0xbd3
     b82:	75 61                	jne    0xbe5
     b84:	6c                   	ins    BYTE PTR es:[di],dx
     b85:	69 74 65 31 30       	imul   si,WORD PTR [si+0x65],0x3031
     b8a:	30 94 03 10          	xor    BYTE PTR [si+0x1003],dl
     b8e:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     b92:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b95:	45                   	inc    bp
     b96:	52                   	push   dx
     b97:	50                   	push   ax
     b98:	45                   	inc    bp
     b99:	66 66 65 74 47       	data32 data32 gs je 0xbe5
     b9e:	6c                   	ins    BYTE PTR es:[di],dx
     b9f:	6f                   	outs   dx,WORD PTR ds:[si]
     ba0:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
     ba3:	31 30                	xor    WORD PTR [bx+si],si
     ba5:	30 98 03 10          	xor    BYTE PTR [bx+si+0x1003],bl
     ba9:	00 13                	add    BYTE PTR [bp+di],dl
     bab:	54                   	push   sp
     bac:	61                   	popa
     bad:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bb0:	45                   	inc    bp
     bb1:	52                   	push   dx
     bb2:	50                   	push   ax
     bb3:	45                   	inc    bp
     bb4:	66 66 65 74 50       	data32 data32 gs je 0xc09
     bb9:	75 62                	jne    0xc1d
     bbb:	31 30                	xor    WORD PTR [bx+si],si
     bbd:	30 0d                	xor    BYTE PTR [di],cl
     bbf:	00 ad 0d ff          	add    BYTE PTR [di-0xf3],ch
     bc3:	ff                   	jmp    (bad)
     bc4:	ef                   	out    dx,ax
     bc5:	02 ca                	add    cl,dl
     bc7:	0b 94 00 92          	or     dx,WORD PTR [si-0x6e00]
     bcb:	12 38                	adc    bh,BYTE PTR [bx+si]
     bcd:	01 d2                	add    dx,dx
     bcf:	0b 58 0a             	or     bx,WORD PTR [bx+si+0xa]
     bd2:	da 0b                	fimul  DWORD PTR [bp+di]
     bd4:	7e 08                	jle    0xbde
     bd6:	bf 10 c8             	mov    di,0xc810
     bd9:	07                   	pop    es
     bda:	de 0b                	fimul  WORD PTR [bp+di]
     bdc:	67 0c d8             	addr32 or al,0xd8
     bdf:	13 17                	adc    dx,WORD PTR [bx]
     be1:	06                   	push   es
     be2:	e6 0b                	out    0xb,al
     be4:	7d 32                	jge    0xc18
     be6:	ea 0b 91 12 ee       	jmp    0xee12:0x910b
     beb:	0b 90 0b 3b          	or     dx,WORD PTR [bx+si+0x3b0b]
     bef:	3e e7 18             	ds out 0x18,ax
     bf2:	ba 14 07             	mov    dx,0x714
     bf5:	12 54 46             	adc    dl,BYTE PTR [si+0x46]
     bf8:	6f                   	outs   dx,WORD PTR ds:[si]
     bf9:	72 6d                	jb     0xc68
     bfb:	53                   	push   bx
     bfc:	41                   	inc    cx
     bfd:	52                   	push   dx
     bfe:	50                   	push   ax
     bff:	5f                   	pop    di
     c00:	50                   	push   ax
     c01:	72 6f                	jb     0xc72
     c03:	64 75 69             	fs jne 0xc6f
     c06:	74 73                	je     0xc7b
     c08:	22 00                	and    al,BYTE PTR [bx+si]
     c0a:	48                   	dec    ax
     c0b:	0c 7b                	or     al,0x7b
     c0d:	06                   	push   es
     c0e:	39 0c                	cmp    WORD PTR [si],cx
     c10:	38 00                	cmp    BYTE PTR [bx+si],al
     c12:	04 53                	add    al,0x53
     c14:	61                   	popa
     c15:	72 70                	jb     0xc87
     c17:	00 00                	add    BYTE PTR [bx+si],al
     c19:	55                   	push   bp
     c1a:	89 e5                	mov    bp,sp
     c1c:	31 c0                	xor    ax,ax
     c1e:	9a 44 04 53 0c       	call   0xc53:0x444
     c23:	6a 00                	push   0x0
     c25:	9a c2 38 7c 0f       	call   0xf7c:0x38c2
     c2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c2d:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     c34:	06                   	push   es
     c35:	57                   	push   di
     c36:	9a 56 55 77 0c       	call   0xc77:0x5556
     c3b:	9a c3 28 6c 13       	call   0x136c:0x28c3
     c40:	c9                   	leave
     c41:	ca 04 00             	retf   0x4
     c44:	00 00                	add    BYTE PTR [bx+si],al
     c46:	dc 0c                	fmul   QWORD PTR [si]
     c48:	70 0c                	jo     0xc56
     c4a:	55                   	push   bp
     c4b:	89 e5                	mov    bp,sp
     c4d:	b8 08 00             	mov    ax,0x8
     c50:	9a 44 04 02 0d       	call   0xd02:0x444
     c55:	83 ec 08             	sub    sp,0x8
     c58:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
     c5c:	7f 03                	jg     0xc61
     c5e:	e9 86 00             	jmp    0xce7
     c61:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     c65:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     c69:	b0 01                	mov    al,0x1
     c6b:	50                   	push   ax
     c6c:	b8 22 00             	mov    ax,0x22
     c6f:	ba 9d 0c             	mov    dx,0xc9d
     c72:	52                   	push   dx
     c73:	50                   	push   ax
     c74:	9a 53 25 c4 0c       	call   0xcc4:0x2553
     c79:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c7c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     c7f:	b8 44 0c             	mov    ax,0xc44
     c82:	0e                   	push   cs
     c83:	50                   	push   ax
     c84:	55                   	push   bp
     c85:	ff 36 58 18          	push   WORD PTR ds:0x1858
     c89:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     c8d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     c90:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     c93:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     c96:	6a 00                	push   0x0
     c98:	06                   	push   es
     c99:	57                   	push   di
     c9a:	9a af 0f aa 0c       	call   0xcaa:0xfaf
     c9f:	ff 76 06             	push   WORD PTR [bp+0x6]
     ca2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     ca5:	06                   	push   es
     ca6:	57                   	push   di
     ca7:	9a ca 14 f7 0c       	call   0xcf7:0x14ca
     cac:	6a ff                	push   0xffff
     cae:	6a f0                	push   0xfff0
     cb0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     cb3:	06                   	push   es
     cb4:	57                   	push   di
     cb5:	9a d5 1e 90 0d       	call   0xd90:0x1ed5
     cba:	6a 02                	push   0x2
     cbc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     cbf:	06                   	push   es
     cc0:	57                   	push   di
     cc1:	9a 14 3a ce 0c       	call   0xcce:0x3a14
     cc6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     cc9:	06                   	push   es
     cca:	57                   	push   di
     ccb:	9a 45 5d e4 0c       	call   0xce4:0x5d45
     cd0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     cd4:	83 c4 06             	add    sp,0x6
     cd7:	b8 e7 0c             	mov    ax,0xce7
     cda:	0e                   	push   cs
     cdb:	50                   	push   ax
     cdc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     cdf:	06                   	push   es
     ce0:	57                   	push   di
     ce1:	9a 1d 5f 4e 0d       	call   0xd4e:0x5f1d
     ce6:	cb                   	retf
     ce7:	c9                   	leave
     ce8:	ca 02 00             	retf   0x2
     ceb:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     cef:	ff                   	(bad)
     cf0:	7f 00                	jg     0xcf2
     cf2:	00 00                	add    BYTE PTR [bx+si],al
     cf4:	00 a0 0f 47          	add    BYTE PTR [bx+si+0x470f],ah
     cf8:	0d 55 89             	or     ax,0x8955
     cfb:	e5 b8                	in     ax,0xb8
     cfd:	1a 00                	sbb    al,BYTE PTR [bx+si]
     cff:	9a 44 04 33 0e       	call   0xe33:0x444
     d04:	83 ec 1a             	sub    sp,0x1a
     d07:	c6 46 f3 00          	mov    BYTE PTR [bp-0xd],0x0
     d0b:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
     d0f:	7e 1e                	jle    0xd2f
     d11:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
     d15:	75 14                	jne    0xd2b
     d17:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
     d1b:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
     d21:	b0 00                	mov    al,0x0
     d23:	75 01                	jne    0xd26
     d25:	40                   	inc    ax
     d26:	88 46 f3             	mov    BYTE PTR [bp-0xd],al
     d29:	eb 04                	jmp    0xd2f
     d2b:	c6 46 f3 01          	mov    BYTE PTR [bp-0xd],0x1
     d2f:	80 7e f3 00          	cmp    BYTE PTR [bp-0xd],0x0
     d33:	75 03                	jne    0xd38
     d35:	e9 73 02             	jmp    0xfab
     d38:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
     d3c:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
     d40:	b0 01                	mov    al,0x1
     d42:	50                   	push   ax
     d43:	b8 22 00             	mov    ax,0x22
     d46:	ba 74 0d             	mov    dx,0xd74
     d49:	52                   	push   dx
     d4a:	50                   	push   ax
     d4b:	9a 53 25 9e 0d       	call   0xd9e:0x2553
     d50:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d53:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     d56:	b8 f3 0c             	mov    ax,0xcf3
     d59:	0e                   	push   cs
     d5a:	50                   	push   ax
     d5b:	55                   	push   bp
     d5c:	ff 36 58 18          	push   WORD PTR ds:0x1858
     d60:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     d64:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     d67:	89 7e ee             	mov    WORD PTR [bp-0x12],di
     d6a:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
     d6d:	6a 01                	push   0x1
     d6f:	06                   	push   es
     d70:	57                   	push   di
     d71:	9a af 0f 81 0d       	call   0xd81:0xfaf
     d76:	ff 76 08             	push   WORD PTR [bp+0x8]
     d79:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     d7c:	06                   	push   es
     d7d:	57                   	push   di
     d7e:	9a ca 14 13 0e       	call   0xe13:0x14ca
     d83:	68 ff 00             	push   0xff
     d86:	6a ff                	push   0xffff
     d88:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     d8b:	06                   	push   es
     d8c:	57                   	push   di
     d8d:	9a d5 1e cc 0d       	call   0xdcc:0x1ed5
     d92:	6a 00                	push   0x0
     d94:	6a 00                	push   0x0
     d96:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     d99:	06                   	push   es
     d9a:	57                   	push   di
     d9b:	9a b2 36 aa 0d       	call   0xdaa:0x36b2
     da0:	6a 02                	push   0x2
     da2:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     da5:	06                   	push   es
     da6:	57                   	push   di
     da7:	9a 14 3a b6 0d       	call   0xdb6:0x3a14
     dac:	6a 01                	push   0x1
     dae:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     db1:	06                   	push   es
     db2:	57                   	push   di
     db3:	9a e5 34 03 0e       	call   0xe03:0x34e5
     db8:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
     dbc:	06                   	push   es
     dbd:	57                   	push   di
     dbe:	9a 9a 2a e0 38       	call   0x38e0:0x2a9a
     dc3:	50                   	push   ax
     dc4:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     dc7:	06                   	push   es
     dc8:	57                   	push   di
     dc9:	9a bf 17 e7 0d       	call   0xde7:0x17bf
     dce:	6a 00                	push   0x0
     dd0:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     dd3:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
     dd8:	06                   	push   es
     dd9:	57                   	push   di
     dda:	9a 4c 75 a3 0e       	call   0xea3:0x754c
     ddf:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     de2:	06                   	push   es
     de3:	57                   	push   di
     de4:	9a b9 62 20 10       	call   0x1020:0x62b9
     de9:	50                   	push   ax
     dea:	6a 04                	push   0x4
     dec:	9a ff ff 00 00       	call   0x0:0xffff
     df1:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     df4:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
     df9:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
     dfe:	06                   	push   es
     dff:	57                   	push   di
     e00:	9a d0 3f 21 0e       	call   0xe21:0x3fd0
     e05:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
     e09:	74 0d                	je     0xe18
     e0b:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e0e:	06                   	push   es
     e0f:	57                   	push   di
     e10:	9a 25 39 7b 10       	call   0x107b:0x3925
     e15:	e9 7c 01             	jmp    0xf94
     e18:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     e1c:	06                   	push   es
     e1d:	57                   	push   di
     e1e:	9a 03 73 92 0f       	call   0xf92:0x7303
     e23:	a1 4e 01             	mov    ax,ds:0x14e
     e26:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e29:	26 03 85 a1 03       	add    ax,WORD PTR es:[di+0x3a1]
     e2e:	71 05                	jno    0xe35
     e30:	9a 3e 04 3d 0e       	call   0xe3d:0x43e
     e35:	2d 01 00             	sub    ax,0x1
     e38:	71 05                	jno    0xe3f
     e3a:	9a 3e 04 69 0e       	call   0xe69:0x43e
     e3f:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e42:	99                   	cwd
     e43:	26 f7 bd a1 03       	idiv   WORD PTR es:[di+0x3a1]
     e48:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     e4b:	b8 01 00             	mov    ax,0x1
     e4e:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
     e51:	7e 03                	jle    0xe56
     e53:	e9 33 01             	jmp    0xf89
     e56:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     e59:	eb 03                	jmp    0xe5e
     e5b:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     e5e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     e61:	2d 01 00             	sub    ax,0x1
     e64:	71 05                	jno    0xe6b
     e66:	9a 3e 04 78 0e       	call   0xe78:0x43e
     e6b:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e6e:	26 f7 ad a1 03       	imul   WORD PTR es:[di+0x3a1]
     e73:	71 05                	jno    0xe7a
     e75:	9a 3e 04 87 0e       	call   0xe87:0x43e
     e7a:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e7d:	26 f7 ad a5 04       	imul   WORD PTR es:[di+0x4a5]
     e82:	71 05                	jno    0xe89
     e84:	9a 3e 04 91 0e       	call   0xe91:0x43e
     e89:	05 01 00             	add    ax,0x1
     e8c:	71 05                	jno    0xe93
     e8e:	9a 3e 04 c5 0e       	call   0xec5:0x43e
     e93:	99                   	cwd
     e94:	52                   	push   dx
     e95:	50                   	push   ax
     e96:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     e99:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
     e9e:	06                   	push   es
     e9f:	57                   	push   di
     ea0:	9a 45 73 e6 0e       	call   0xee6:0x7345
     ea5:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     ea8:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
     ead:	89 7e e8             	mov    WORD PTR [bp-0x18],di
     eb0:	8c 46 ea             	mov    WORD PTR [bp-0x16],es
     eb3:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
     eb6:	26 8b 85 a1 03       	mov    ax,WORD PTR es:[di+0x3a1]
     ebb:	26 f7 ad a5 04       	imul   WORD PTR es:[di+0x4a5]
     ec0:	71 05                	jno    0xec7
     ec2:	9a 3e 04 d7 0e       	call   0xed7:0x43e
     ec7:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     eca:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     ecd:	b9 02 00             	mov    cx,0x2
     ed0:	f7 e9                	imul   cx
     ed2:	71 05                	jno    0xed9
     ed4:	9a 3e 04 fd 0e       	call   0xefd:0x43e
     ed9:	50                   	push   ax
     eda:	6a 00                	push   0x0
     edc:	6a 00                	push   0x0
     ede:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
     ee1:	06                   	push   es
     ee2:	57                   	push   di
     ee3:	9a 30 6e 56 0f       	call   0xf56:0x6e30
     ee8:	8b d0                	mov    dx,ax
     eea:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     eed:	26 c4 bd 04 03       	les    di,DWORD PTR es:[di+0x304]
     ef2:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
     ef6:	2b c2                	sub    ax,dx
     ef8:	71 05                	jno    0xeff
     efa:	9a 3e 04 07 0f       	call   0xf07:0x43e
     eff:	5a                   	pop    dx
     f00:	2b c2                	sub    ax,dx
     f02:	71 05                	jno    0xf09
     f04:	9a 3e 04 28 0f       	call   0xf28:0x43e
     f09:	99                   	cwd
     f0a:	f7 7e f6             	idiv   WORD PTR [bp-0xa]
     f0d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     f10:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
     f13:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
     f18:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
     f1d:	2d 01 00             	sub    ax,0x1
     f20:	83 da 00             	sbb    dx,0x0
     f23:	71 05                	jno    0xf2a
     f25:	9a 3e 04 30 0f       	call   0xf30:0x43e
     f2a:	bf eb 0c             	mov    di,0xceb
     f2d:	9a 16 04 b7 0f       	call   0xfb7:0x416
     f32:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
     f35:	b8 01 00             	mov    ax,0x1
     f38:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
     f3b:	7f 23                	jg     0xf60
     f3d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     f40:	eb 03                	jmp    0xf45
     f42:	ff 46 f4             	inc    WORD PTR [bp-0xc]
     f45:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     f48:	99                   	cwd
     f49:	52                   	push   dx
     f4a:	50                   	push   ax
     f4b:	ff 76 f8             	push   WORD PTR [bp-0x8]
     f4e:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
     f51:	06                   	push   es
     f52:	57                   	push   di
     f53:	9a c9 70 c9 1a       	call   0x1ac9:0x70c9
     f58:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     f5b:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
     f5e:	75 e2                	jne    0xf42
     f60:	ff 76 fe             	push   WORD PTR [bp-0x2]
     f63:	ff 76 fc             	push   WORD PTR [bp-0x4]
     f66:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     f69:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
     f6e:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
     f73:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
     f77:	06                   	push   es
     f78:	57                   	push   di
     f79:	9a 1a 31 d5 10       	call   0x10d5:0x311a
     f7e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     f81:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
     f84:	74 03                	je     0xf89
     f86:	e9 d2 fe             	jmp    0xe5b
     f89:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
     f8d:	06                   	push   es
     f8e:	57                   	push   di
     f8f:	9a 03 73 a8 0f       	call   0xfa8:0x7303
     f94:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     f98:	83 c4 06             	add    sp,0x6
     f9b:	b8 ab 0f             	mov    ax,0xfab
     f9e:	0e                   	push   cs
     f9f:	50                   	push   ax
     fa0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     fa3:	06                   	push   es
     fa4:	57                   	push   di
     fa5:	9a 1d 5f d4 0f       	call   0xfd4:0x5f1d
     faa:	cb                   	retf
     fab:	c9                   	leave
     fac:	ca 04 00             	retf   0x4
     faf:	55                   	push   bp
     fb0:	89 e5                	mov    bp,sp
     fb2:	31 c0                	xor    ax,ax
     fb4:	9a 44 04 89 10       	call   0x1089:0x444
     fb9:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
     fbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fbf:	26 88 85 9e 03       	mov    BYTE PTR es:[di+0x39e],al
     fc4:	26 8a 85 9e 03       	mov    al,BYTE PTR es:[di+0x39e]
     fc9:	50                   	push   ax
     fca:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     fcf:	06                   	push   es
     fd0:	57                   	push   di
     fd1:	9a 62 1e e9 0f       	call   0xfe9:0x1e62
     fd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fd9:	26 8a 85 9e 03       	mov    al,BYTE PTR es:[di+0x39e]
     fde:	50                   	push   ax
     fdf:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
     fe4:	06                   	push   es
     fe5:	57                   	push   di
     fe6:	9a 62 1e fa 0f       	call   0xffa:0x1e62
     feb:	6a 00                	push   0x0
     fed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ff0:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     ff5:	06                   	push   es
     ff6:	57                   	push   di
     ff7:	9a d0 1c 0b 10       	call   0x100b:0x1cd0
     ffc:	6a 00                	push   0x0
     ffe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1001:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    1006:	06                   	push   es
    1007:	57                   	push   di
    1008:	9a d0 1c dc 10       	call   0x10dc:0x1cd0
    100d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1010:	26 8a 85 9e 03       	mov    al,BYTE PTR es:[di+0x39e]
    1015:	50                   	push   ax
    1016:	26 c4 bd 80 02       	les    di,DWORD PTR es:[di+0x280]
    101b:	06                   	push   es
    101c:	57                   	push   di
    101d:	9a 77 1c 68 10       	call   0x1068:0x1c77
    1022:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1025:	26 80 bd 9e 03 00    	cmp    BYTE PTR es:[di+0x39e],0x0
    102b:	74 17                	je     0x1044
    102d:	b8 04 00             	mov    ax,0x4
    1030:	99                   	cwd
    1031:	26 f7 bd a5 04       	idiv   WORD PTR es:[di+0x4a5]
    1036:	26 89 85 a1 03       	mov    WORD PTR es:[di+0x3a1],ax
    103b:	26 c7 85 a3 03 14 00 	mov    WORD PTR es:[di+0x3a3],0x14
    1042:	eb 26                	jmp    0x106a
    1044:	b8 04 00             	mov    ax,0x4
    1047:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    104a:	99                   	cwd
    104b:	26 f7 bd a5 04       	idiv   WORD PTR es:[di+0x4a5]
    1050:	26 89 85 a1 03       	mov    WORD PTR es:[di+0x3a1],ax
    1055:	26 c7 85 a3 03 0f 00 	mov    WORD PTR es:[di+0x3a3],0xf
    105c:	6a 05                	push   0x5
    105e:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    1063:	06                   	push   es
    1064:	57                   	push   di
    1065:	9a 72 16 ba 11       	call   0x11ba:0x1672
    106a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    106d:	81 c7 1c 03          	add    di,0x31c
    1071:	06                   	push   es
    1072:	57                   	push   di
    1073:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1076:	06                   	push   es
    1077:	57                   	push   di
    1078:	9a 6a 1a 98 10       	call   0x1098:0x1a6a
    107d:	c9                   	leave
    107e:	ca 06 00             	retf   0x6
    1081:	55                   	push   bp
    1082:	89 e5                	mov    bp,sp
    1084:	31 c0                	xor    ax,ax
    1086:	9a 44 04 ad 10       	call   0x10ad:0x444
    108b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    108e:	26 ff b5 9f 03       	push   WORD PTR es:[di+0x39f]
    1093:	6a 00                	push   0x0
    1095:	9a f9 0c a2 10       	call   0x10a2:0xcf9
    109a:	c9                   	leave
    109b:	ca 08 00             	retf   0x8
    109e:	00 00                	add    BYTE PTR [bx+si],al
    10a0:	62 11                	bound  dx,DWORD PTR [bx+di]
    10a2:	36 11 55 89          	adc    WORD PTR ss:[di-0x77],dx
    10a6:	e5 b8                	in     ax,0xb8
    10a8:	04 00                	add    al,0x0
    10aa:	9a 44 04 0d 11       	call   0x110d:0x444
    10af:	83 ec 04             	sub    sp,0x4
    10b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10b5:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    10ba:	06                   	push   es
    10bb:	57                   	push   di
    10bc:	9a 17 2f ad 38       	call   0x38ad:0x2f17
    10c1:	08 c0                	or     al,al
    10c3:	75 03                	jne    0x10c8
    10c5:	e9 a6 00             	jmp    0x116e
    10c8:	ff 76 08             	push   WORD PTR [bp+0x8]
    10cb:	ff 76 06             	push   WORD PTR [bp+0x6]
    10ce:	b0 01                	mov    al,0x1
    10d0:	50                   	push   ax
    10d1:	b8 b4 25             	mov    ax,0x25b4
    10d4:	ba 2b 11             	mov    dx,0x112b
    10d7:	52                   	push   dx
    10d8:	50                   	push   ax
    10d9:	9a 53 25 54 11       	call   0x1154:0x2553
    10de:	a3 04 20             	mov    ds:0x2004,ax
    10e1:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    10e5:	b8 9e 10             	mov    ax,0x109e
    10e8:	0e                   	push   cs
    10e9:	50                   	push   ax
    10ea:	55                   	push   bp
    10eb:	ff 36 58 18          	push   WORD PTR ds:0x1858
    10ef:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    10f3:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    10f7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    10fa:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    10fd:	a1 4e 01             	mov    ax,ds:0x14e
    1100:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1103:	26 03 85 a1 03       	add    ax,WORD PTR es:[di+0x3a1]
    1108:	71 05                	jno    0x110f
    110a:	9a 3e 04 17 11       	call   0x1117:0x43e
    110f:	2d 01 00             	sub    ax,0x1
    1112:	71 05                	jno    0x1119
    1114:	9a 3e 04 7a 11       	call   0x117a:0x43e
    1119:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    111c:	99                   	cwd
    111d:	26 f7 bd a1 03       	idiv   WORD PTR es:[di+0x3a1]
    1122:	50                   	push   ax
    1123:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1126:	06                   	push   es
    1127:	57                   	push   di
    1128:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    112d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1130:	06                   	push   es
    1131:	57                   	push   di
    1132:	b8 81 10             	mov    ax,0x1081
    1135:	ba ca 11             	mov    dx,0x11ca
    1138:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    113b:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    1140:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    1145:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    114a:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    114f:	06                   	push   es
    1150:	57                   	push   di
    1151:	9a 45 5d 6b 11       	call   0x116b:0x5d45
    1156:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    115a:	83 c4 06             	add    sp,0x6
    115d:	b8 6e 11             	mov    ax,0x116e
    1160:	0e                   	push   cs
    1161:	50                   	push   ax
    1162:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1166:	06                   	push   es
    1167:	57                   	push   di
    1168:	9a 1d 5f d7 11       	call   0x11d7:0x5f1d
    116d:	cb                   	retf
    116e:	c9                   	leave
    116f:	ca 08 00             	retf   0x8
    1172:	55                   	push   bp
    1173:	89 e5                	mov    bp,sp
    1175:	31 c0                	xor    ax,ax
    1177:	9a 44 04 90 11       	call   0x1190:0x444
    117c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    117f:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    1183:	c9                   	leave
    1184:	ca 0c 00             	retf   0xc
    1187:	55                   	push   bp
    1188:	89 e5                	mov    bp,sp
    118a:	b8 04 00             	mov    ax,0x4
    118d:	9a 44 04 af 11       	call   0x11af:0x444
    1192:	83 ec 04             	sub    sp,0x4
    1195:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1198:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    119d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    11a0:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    11a3:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    11a7:	05 01 00             	add    ax,0x1
    11aa:	71 05                	jno    0x11b1
    11ac:	9a 3e 04 f6 11       	call   0x11f6:0x43e
    11b1:	50                   	push   ax
    11b2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    11b5:	06                   	push   es
    11b6:	57                   	push   di
    11b7:	9a bf 17 2e 12       	call   0x122e:0x17bf
    11bc:	ff 76 08             	push   WORD PTR [bp+0x8]
    11bf:	ff 76 06             	push   WORD PTR [bp+0x6]
    11c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11c5:	06                   	push   es
    11c6:	57                   	push   di
    11c7:	9a 8f 14 89 14       	call   0x1489:0x148f
    11cc:	6a fe                	push   0xfffe
    11ce:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    11d2:	06                   	push   es
    11d3:	57                   	push   di
    11d4:	9a a9 63 e2 14       	call   0x14e2:0x63a9
    11d9:	c9                   	leave
    11da:	ca 08 00             	retf   0x8
    11dd:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    11e0:	6d                   	ins    WORD PTR es:[di],dx
    11e1:	73 74                	jae    0x1257
    11e3:	72 61                	jb     0x1246
    11e5:	74 20                	je     0x1207
    11e7:	2d 20 03             	sub    ax,0x320
    11ea:	20 2d                	and    BYTE PTR [di],ch
    11ec:	20 55 89             	and    BYTE PTR [di-0x77],dl
    11ef:	e5 b8                	in     ax,0xb8
    11f1:	02 03                	add    al,BYTE PTR [bp+di]
    11f3:	9a 44 04 0a 12       	call   0x120a:0x444
    11f8:	81 ec 02 03          	sub    sp,0x302
    11fc:	8d be fe fe          	lea    di,[bp-0x102]
    1200:	16                   	push   ss
    1201:	57                   	push   di
    1202:	bf dd 11             	mov    di,0x11dd
    1205:	0e                   	push   cs
    1206:	57                   	push   di
    1207:	9a cd 17 14 12       	call   0x1214:0x17cd
    120c:	bf fa 1d             	mov    di,0x1dfa
    120f:	1e                   	push   ds
    1210:	57                   	push   di
    1211:	9a 4c 18 1e 12       	call   0x121e:0x184c
    1216:	bf e9 11             	mov    di,0x11e9
    1219:	0e                   	push   cs
    121a:	57                   	push   di
    121b:	9a 4c 18 33 12       	call   0x1233:0x184c
    1220:	8d be fe fd          	lea    di,[bp-0x202]
    1224:	16                   	push   ss
    1225:	57                   	push   di
    1226:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1229:	06                   	push   es
    122a:	57                   	push   di
    122b:	9a 53 1d e8 12       	call   0x12e8:0x1d53
    1230:	9a 4c 18 44 12       	call   0x1244:0x184c
    1235:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1238:	81 c7 a5 03          	add    di,0x3a5
    123c:	06                   	push   es
    123d:	57                   	push   di
    123e:	68 ff 00             	push   0xff
    1241:	9a e7 17 70 12       	call   0x1270:0x17e7
    1246:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1249:	26 c7 85 9c 03 64 00 	mov    WORD PTR es:[di+0x39c],0x64
    1250:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    1255:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    1258:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    125b:	31 c0                	xor    ax,ax
    125d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1260:	eb 03                	jmp    0x1265
    1262:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1265:	a1 4c 01             	mov    ax,ds:0x14c
    1268:	2d 01 00             	sub    ax,0x1
    126b:	71 05                	jno    0x1272
    126d:	9a 3e 04 7f 12       	call   0x127f:0x43e
    1272:	8b d0                	mov    dx,ax
    1274:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1277:	05 01 00             	add    ax,0x1
    127a:	71 05                	jno    0x1281
    127c:	9a 3e 04 b0 12       	call   0x12b0:0x43e
    1281:	3b c2                	cmp    ax,dx
    1283:	7e 1a                	jle    0x129f
    1285:	6a 00                	push   0x0
    1287:	ff 76 fe             	push   WORD PTR [bp-0x2]
    128a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    128d:	06                   	push   es
    128e:	57                   	push   di
    128f:	9a 53 13 9d 12       	call   0x129d:0x1353
    1294:	89 c7                	mov    di,ax
    1296:	8e c2                	mov    es,dx
    1298:	06                   	push   es
    1299:	57                   	push   di
    129a:	9a a5 13 79 14       	call   0x1479:0x13a5
    129f:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    12a3:	75 bd                	jne    0x1262
    12a5:	a1 4c 01             	mov    ax,ds:0x14c
    12a8:	2d 01 00             	sub    ax,0x1
    12ab:	71 05                	jno    0x12b2
    12ad:	9a 3e 04 61 13       	call   0x1361:0x43e
    12b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12b5:	26 89 85 9f 03       	mov    WORD PTR es:[di+0x39f],ax
    12ba:	83 3e 06 1e 03       	cmp    WORD PTR ds:0x1e06,0x3
    12bf:	7c 09                	jl     0x12ca
    12c1:	26 c7 85 a5 04 02 00 	mov    WORD PTR es:[di+0x4a5],0x2
    12c8:	eb 0a                	jmp    0x12d4
    12ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12cd:	26 c7 85 a5 04 01 00 	mov    WORD PTR es:[di+0x4a5],0x1
    12d4:	8d be fe fe          	lea    di,[bp-0x102]
    12d8:	16                   	push   ss
    12d9:	57                   	push   di
    12da:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    12de:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    12e3:	06                   	push   es
    12e4:	57                   	push   di
    12e5:	9a 53 1d f7 12       	call   0x12f7:0x1d53
    12ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12ed:	26 c4 bd 84 02       	les    di,DWORD PTR es:[di+0x284]
    12f2:	06                   	push   es
    12f3:	57                   	push   di
    12f4:	9a 8c 1d 0d 13       	call   0x130d:0x1d8c
    12f9:	8d be fe fe          	lea    di,[bp-0x102]
    12fd:	16                   	push   ss
    12fe:	57                   	push   di
    12ff:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    1303:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    1308:	06                   	push   es
    1309:	57                   	push   di
    130a:	9a 53 1d 1c 13       	call   0x131c:0x1d53
    130f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1312:	26 c4 bd 88 02       	les    di,DWORD PTR es:[di+0x288]
    1317:	06                   	push   es
    1318:	57                   	push   di
    1319:	9a 8c 1d 32 13       	call   0x1332:0x1d8c
    131e:	8d be fe fe          	lea    di,[bp-0x102]
    1322:	16                   	push   ss
    1323:	57                   	push   di
    1324:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    1328:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    132d:	06                   	push   es
    132e:	57                   	push   di
    132f:	9a 53 1d 41 13       	call   0x1341:0x1d53
    1334:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1337:	26 c4 bd 8c 02       	les    di,DWORD PTR es:[di+0x28c]
    133c:	06                   	push   es
    133d:	57                   	push   di
    133e:	9a 8c 1d 57 13       	call   0x1357:0x1d8c
    1343:	8d be fe fe          	lea    di,[bp-0x102]
    1347:	16                   	push   ss
    1348:	57                   	push   di
    1349:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    134d:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    1352:	06                   	push   es
    1353:	57                   	push   di
    1354:	9a 53 1d c4 13       	call   0x13c4:0x1d53
    1359:	bf e9 11             	mov    di,0x11e9
    135c:	0e                   	push   cs
    135d:	57                   	push   di
    135e:	9a 4c 18 81 13       	call   0x1381:0x184c
    1363:	8d be fe fd          	lea    di,[bp-0x202]
    1367:	16                   	push   ss
    1368:	57                   	push   di
    1369:	9a fe 15 7c 13       	call   0x137c:0x15fe
    136e:	83 ec 08             	sub    sp,0x8
    1371:	89 e3                	mov    bx,sp
    1373:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    1377:	90                   	nop
    1378:	9b                   	fwait
    1379:	9a bf 1c 96 13       	call   0x1396:0x1cbf
    137e:	9a 4c 18 8b 13       	call   0x138b:0x184c
    1383:	bf e9 11             	mov    di,0x11e9
    1386:	0e                   	push   cs
    1387:	57                   	push   di
    1388:	9a 4c 18 ab 13       	call   0x13ab:0x184c
    138d:	8d be fe fc          	lea    di,[bp-0x302]
    1391:	16                   	push   ss
    1392:	57                   	push   di
    1393:	9a fe 15 a6 13       	call   0x13a6:0x15fe
    1398:	83 ec 08             	sub    sp,0x8
    139b:	89 e3                	mov    bx,sp
    139d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    13a1:	90                   	nop
    13a2:	9b                   	fwait
    13a3:	9a e4 1c 5f 15       	call   0x155f:0x1ce4
    13a8:	9a 4c 18 b5 13       	call   0x13b5:0x184c
    13ad:	bf e9 11             	mov    di,0x11e9
    13b0:	0e                   	push   cs
    13b1:	57                   	push   di
    13b2:	9a 4c 18 5e 14       	call   0x145e:0x184c
    13b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ba:	26 c4 bd 90 02       	les    di,DWORD PTR es:[di+0x290]
    13bf:	06                   	push   es
    13c0:	57                   	push   di
    13c1:	9a 8c 1d 83 15       	call   0x1583:0x1d8c
    13c6:	bf 78 1e             	mov    di,0x1e78
    13c9:	1e                   	push   ds
    13ca:	57                   	push   di
    13cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ce:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    13d3:	06                   	push   es
    13d4:	57                   	push   di
    13d5:	9a 17 30 ec 13       	call   0x13ec:0x3017
    13da:	bf 86 1e             	mov    di,0x1e86
    13dd:	1e                   	push   ds
    13de:	57                   	push   di
    13df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e2:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    13e7:	06                   	push   es
    13e8:	57                   	push   di
    13e9:	9a 17 30 00 14       	call   0x1400:0x3017
    13ee:	bf 5c 1e             	mov    di,0x1e5c
    13f1:	1e                   	push   ds
    13f2:	57                   	push   di
    13f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13f6:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    13fb:	06                   	push   es
    13fc:	57                   	push   di
    13fd:	9a 17 30 14 14       	call   0x1414:0x3017
    1402:	bf 86 1e             	mov    di,0x1e86
    1405:	1e                   	push   ds
    1406:	57                   	push   di
    1407:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    140a:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    140f:	06                   	push   es
    1410:	57                   	push   di
    1411:	9a 17 30 28 14       	call   0x1428:0x3017
    1416:	bf 24 1e             	mov    di,0x1e24
    1419:	1e                   	push   ds
    141a:	57                   	push   di
    141b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    141e:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    1423:	06                   	push   es
    1424:	57                   	push   di
    1425:	9a 17 30 3c 14       	call   0x143c:0x3017
    142a:	bf 32 1e             	mov    di,0x1e32
    142d:	1e                   	push   ds
    142e:	57                   	push   di
    142f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1432:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    1437:	06                   	push   es
    1438:	57                   	push   di
    1439:	9a 17 30 50 14       	call   0x1450:0x3017
    143e:	bf 40 1e             	mov    di,0x1e40
    1441:	1e                   	push   ds
    1442:	57                   	push   di
    1443:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1446:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    144b:	06                   	push   es
    144c:	57                   	push   di
    144d:	9a 17 30 4c 16       	call   0x164c:0x3017
    1452:	c9                   	leave
    1453:	ca 08 00             	retf   0x8
    1456:	55                   	push   bp
    1457:	89 e5                	mov    bp,sp
    1459:	31 c0                	xor    ax,ax
    145b:	9a 44 04 98 14       	call   0x1498:0x444
    1460:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1463:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    1469:	b0 00                	mov    al,0x0
    146b:	75 01                	jne    0x146e
    146d:	40                   	inc    ax
    146e:	50                   	push   ax
    146f:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    1474:	06                   	push   es
    1475:	57                   	push   di
    1476:	9a 75 12 ca 15       	call   0x15ca:0x1275
    147b:	ff 76 08             	push   WORD PTR [bp+0x8]
    147e:	ff 76 06             	push   WORD PTR [bp+0x6]
    1481:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1484:	06                   	push   es
    1485:	57                   	push   di
    1486:	9a 8f 14 fd 14       	call   0x14fd:0x148f
    148b:	c9                   	leave
    148c:	ca 08 00             	retf   0x8
    148f:	55                   	push   bp
    1490:	89 e5                	mov    bp,sp
    1492:	b8 04 00             	mov    ax,0x4
    1495:	9a 44 04 d3 14       	call   0x14d3:0x444
    149a:	83 ec 04             	sub    sp,0x4
    149d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14a0:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    14a5:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    14a9:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    14ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14b0:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    14b5:	06                   	push   es
    14b6:	57                   	push   di
    14b7:	9a fd 1a 12 5b       	call   0x5b12:0x1afd
    14bc:	c9                   	leave
    14bd:	ca 08 00             	retf   0x8
    14c0:	01 23                	add    WORD PTR [bp+di],sp
    14c2:	00 00                	add    BYTE PTR [bx+si],al
    14c4:	00 00                	add    BYTE PTR [bx+si],al
    14c6:	ff 00                	inc    WORD PTR [bx+si]
    14c8:	00 00                	add    BYTE PTR [bx+si],al
    14ca:	55                   	push   bp
    14cb:	89 e5                	mov    bp,sp
    14cd:	b8 02 02             	mov    ax,0x202
    14d0:	9a 44 04 14 15       	call   0x1514:0x444
    14d5:	81 ec 02 02          	sub    sp,0x202
    14d9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    14dd:	06                   	push   es
    14de:	57                   	push   di
    14df:	9a 03 73 55 33       	call   0x3355:0x7303
    14e4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    14e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14ea:	26 89 85 9f 03       	mov    WORD PTR es:[di+0x39f],ax
    14ef:	81 c7 1c 03          	add    di,0x31c
    14f3:	06                   	push   es
    14f4:	57                   	push   di
    14f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14f8:	06                   	push   es
    14f9:	57                   	push   di
    14fa:	9a 58 28 6e 17       	call   0x176e:0x2858
    14ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1502:	81 c7 a5 03          	add    di,0x3a5
    1506:	06                   	push   es
    1507:	57                   	push   di
    1508:	8d be fe fe          	lea    di,[bp-0x102]
    150c:	16                   	push   ss
    150d:	57                   	push   di
    150e:	68 ff 00             	push   0xff
    1511:	9a e7 17 24 15       	call   0x1524:0x17e7
    1516:	bf c0 14             	mov    di,0x14c0
    1519:	0e                   	push   cs
    151a:	57                   	push   di
    151b:	8d be fe fe          	lea    di,[bp-0x102]
    151f:	16                   	push   ss
    1520:	57                   	push   di
    1521:	9a 78 18 2d 15       	call   0x152d:0x1878
    1526:	99                   	cwd
    1527:	bf c2 14             	mov    di,0x14c2
    152a:	9a 16 04 49 15       	call   0x1549:0x416
    152f:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1532:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1536:	76 3d                	jbe    0x1575
    1538:	8d be fe fe          	lea    di,[bp-0x102]
    153c:	16                   	push   ss
    153d:	57                   	push   di
    153e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1541:	30 e4                	xor    ah,ah
    1543:	50                   	push   ax
    1544:	6a 01                	push   0x1
    1546:	9a 75 19 73 15       	call   0x1573:0x1975
    154b:	8d be fe fd          	lea    di,[bp-0x202]
    154f:	16                   	push   ss
    1550:	57                   	push   di
    1551:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1554:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    1559:	99                   	cwd
    155a:	52                   	push   dx
    155b:	50                   	push   ax
    155c:	9a a9 08 48 1d       	call   0x1d48:0x8a9
    1561:	8d be fe fe          	lea    di,[bp-0x102]
    1565:	16                   	push   ss
    1566:	57                   	push   di
    1567:	68 ff 00             	push   0xff
    156a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    156d:	30 e4                	xor    ah,ah
    156f:	50                   	push   ax
    1570:	9a 16 19 ab 15       	call   0x15ab:0x1916
    1575:	8d be fe fe          	lea    di,[bp-0x102]
    1579:	16                   	push   ss
    157a:	57                   	push   di
    157b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    157e:	06                   	push   es
    157f:	57                   	push   di
    1580:	9a 8c 1d 8b 1a       	call   0x1a8b:0x1d8c
    1585:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1588:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    158d:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1591:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1595:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1599:	eb 03                	jmp    0x159e
    159b:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    159e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    15a1:	30 e4                	xor    ah,ah
    15a3:	05 01 00             	add    ax,0x1
    15a6:	71 05                	jno    0x15ad
    15a8:	9a 3e 04 28 16       	call   0x1628:0x43e
    15ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15b0:	26 3b 85 9f 03       	cmp    ax,WORD PTR es:[di+0x39f]
    15b5:	b0 00                	mov    al,0x0
    15b7:	75 01                	jne    0x15ba
    15b9:	40                   	inc    ax
    15ba:	50                   	push   ax
    15bb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    15be:	30 e4                	xor    ah,ah
    15c0:	50                   	push   ax
    15c1:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    15c5:	06                   	push   es
    15c6:	57                   	push   di
    15c7:	9a 53 13 d5 15       	call   0x15d5:0x1353
    15cc:	89 c7                	mov    di,ax
    15ce:	8e c2                	mov    es,dx
    15d0:	06                   	push   es
    15d1:	57                   	push   di
    15d2:	9a 75 12 fb 33       	call   0x33fb:0x1275
    15d7:	80 7e ff 13          	cmp    BYTE PTR [bp-0x1],0x13
    15db:	75 be                	jne    0x159b
    15dd:	c9                   	leave
    15de:	ca 06 00             	retf   0x6
    15e1:	01 00                	add    WORD PTR [bx+si],ax
    15e3:	00 00                	add    BYTE PTR [bx+si],al
    15e5:	02 00                	add    al,BYTE PTR [bx+si]
    15e7:	00 00                	add    BYTE PTR [bx+si],al
    15e9:	00 00                	add    BYTE PTR [bx+si],al
    15eb:	00 00                	add    BYTE PTR [bx+si],al
    15ed:	04 50                	add    al,0x50
    15ef:	72 69                	jb     0x165a
    15f1:	78 09                	js     0x15fc
    15f3:	50                   	push   ax
    15f4:	75 62                	jne    0x1658
    15f6:	6c                   	ins    BYTE PTR es:[di],dx
    15f7:	69 63 69 74 65       	imul   sp,WORD PTR [bp+di+0x69],0x6574
    15fc:	10 56 65             	adc    BYTE PTR [bp+0x65],dl
    15ff:	6e                   	outs   dx,BYTE PTR ds:[si]
    1600:	64 65 75 72          	fs gs jne 0x1676
    1604:	73 41                	jae    0x1647
    1606:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    160c:	73 11                	jae    0x161f
    160e:	44                   	inc    sp
    160f:	75 72                	jne    0x1683
    1611:	65 65 43             	gs gs inc bx
    1614:	72 65                	jb     0x167b
    1616:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    161c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    161e:	74 55                	je     0x1675
    1620:	89 e5                	mov    bp,sp
    1622:	b8 44 00             	mov    ax,0x44
    1625:	9a 44 04 7e 16       	call   0x167e:0x444
    162a:	83 ec 44             	sub    sp,0x44
    162d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1630:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    1635:	89 7e d6             	mov    WORD PTR [bp-0x2a],di
    1638:	8c 46 d8             	mov    WORD PTR [bp-0x28],es
    163b:	06                   	push   es
    163c:	57                   	push   di
    163d:	9a d2 31 62 16       	call   0x1662:0x31d2
    1642:	6a 01                	push   0x1
    1644:	c4 7e d6             	les    di,DWORD PTR [bp-0x2a]
    1647:	06                   	push   es
    1648:	57                   	push   di
    1649:	9a fb 2f 58 16       	call   0x1658:0x2ffb
    164e:	6a 00                	push   0x0
    1650:	c4 7e d6             	les    di,DWORD PTR [bp-0x2a]
    1653:	06                   	push   es
    1654:	57                   	push   di
    1655:	9a d2 2e 60 17       	call   0x1760:0x2ed2
    165a:	c4 7e d6             	les    di,DWORD PTR [bp-0x2a]
    165d:	06                   	push   es
    165e:	57                   	push   di
    165f:	9a bf 31 7d 17       	call   0x177d:0x31bf
    1664:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    1669:	eb 03                	jmp    0x166e
    166b:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    166e:	9b 2e d9 06 e9 15    	fld    DWORD PTR cs:0x15e9
    1674:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1677:	99                   	cwd
    1678:	bf e1 15             	mov    di,0x15e1
    167b:	9a 16 04 a0 16       	call   0x16a0:0x416
    1680:	c1 e0 03             	shl    ax,0x3
    1683:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1686:	03 f8                	add    di,ax
    1688:	9b 26 dd 9d 9f 04    	fstp   QWORD PTR es:[di+0x49f]
    168e:	90                   	nop
    168f:	9b                   	fwait
    1690:	9b 2e d9 06 e6 15    	fld    DWORD PTR cs:0x15e6
    1696:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1699:	99                   	cwd
    169a:	bf e1 15             	mov    di,0x15e1
    169d:	9a 16 04 c2 16       	call   0x16c2:0x416
    16a2:	c1 e0 03             	shl    ax,0x3
    16a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16a8:	03 f8                	add    di,ax
    16aa:	9b 26 dd 9d af 04    	fstp   QWORD PTR es:[di+0x4af]
    16b0:	90                   	nop
    16b1:	9b                   	fwait
    16b2:	9b 2e d9 06 e6 15    	fld    DWORD PTR cs:0x15e6
    16b8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    16bb:	99                   	cwd
    16bc:	bf e1 15             	mov    di,0x15e1
    16bf:	9a 16 04 e4 16       	call   0x16e4:0x416
    16c4:	c1 e0 03             	shl    ax,0x3
    16c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16ca:	03 f8                	add    di,ax
    16cc:	9b 26 dd 9d bf 04    	fstp   QWORD PTR es:[di+0x4bf]
    16d2:	90                   	nop
    16d3:	9b                   	fwait
    16d4:	9b 2e d9 06 e6 15    	fld    DWORD PTR cs:0x15e6
    16da:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    16dd:	99                   	cwd
    16de:	bf e1 15             	mov    di,0x15e1
    16e1:	9a 16 04 2f 18       	call   0x182f:0x416
    16e6:	c1 e0 03             	shl    ax,0x3
    16e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16ec:	03 f8                	add    di,ax
    16ee:	9b 26 dd 9d cf 04    	fstp   QWORD PTR es:[di+0x4cf]
    16f4:	90                   	nop
    16f5:	9b                   	fwait
    16f6:	31 c0                	xor    ax,ax
    16f8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    16fb:	a1 4e 01             	mov    ax,ds:0x14e
    16fe:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    1701:	b8 01 00             	mov    ax,0x1
    1704:	3b 46 d8             	cmp    ax,WORD PTR [bp-0x28]
    1707:	7e 03                	jle    0x170c
    1709:	e9 0f 02             	jmp    0x191b
    170c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    170f:	eb 03                	jmp    0x1714
    1711:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1714:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1717:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    171c:	89 7e d4             	mov    WORD PTR [bp-0x2c],di
    171f:	8c 46 d6             	mov    WORD PTR [bp-0x2a],es
    1722:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1725:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    172a:	99                   	cwd
    172b:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    172e:	89 56 be             	mov    WORD PTR [bp-0x42],dx
    1731:	c6 46 c0 00          	mov    BYTE PTR [bp-0x40],0x0
    1735:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1738:	99                   	cwd
    1739:	89 46 c4             	mov    WORD PTR [bp-0x3c],ax
    173c:	89 56 c6             	mov    WORD PTR [bp-0x3a],dx
    173f:	c6 46 c8 00          	mov    BYTE PTR [bp-0x38],0x0
    1743:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1746:	99                   	cwd
    1747:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    174a:	89 56 ce             	mov    WORD PTR [bp-0x32],dx
    174d:	c6 46 d0 00          	mov    BYTE PTR [bp-0x30],0x0
    1751:	8d 7e bc             	lea    di,[bp-0x44]
    1754:	16                   	push   ss
    1755:	57                   	push   di
    1756:	6a 02                	push   0x2
    1758:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    175b:	06                   	push   es
    175c:	57                   	push   di
    175d:	9a 95 28 90 28       	call   0x2890:0x2895
    1762:	08 c0                	or     al,al
    1764:	75 0a                	jne    0x1770
    1766:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1769:	06                   	push   es
    176a:	57                   	push   di
    176b:	9a 19 0c 6f 28       	call   0x286f:0xc19
    1770:	bf ed 15             	mov    di,0x15ed
    1773:	0e                   	push   cs
    1774:	57                   	push   di
    1775:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    1778:	06                   	push   es
    1779:	57                   	push   di
    177a:	9a 9b 3b 9f 17       	call   0x179f:0x3b9b
    177f:	89 c7                	mov    di,ax
    1781:	8e c2                	mov    es,dx
    1783:	06                   	push   es
    1784:	57                   	push   di
    1785:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1788:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    178c:	9b dd 5e f2          	fstp   QWORD PTR [bp-0xe]
    1790:	90                   	nop
    1791:	9b                   	fwait
    1792:	bf f2 15             	mov    di,0x15f2
    1795:	0e                   	push   cs
    1796:	57                   	push   di
    1797:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    179a:	06                   	push   es
    179b:	57                   	push   di
    179c:	9a 9b 3b c1 17       	call   0x17c1:0x3b9b
    17a1:	89 c7                	mov    di,ax
    17a3:	8e c2                	mov    es,dx
    17a5:	06                   	push   es
    17a6:	57                   	push   di
    17a7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17aa:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    17ae:	9b dd 5e ea          	fstp   QWORD PTR [bp-0x16]
    17b2:	90                   	nop
    17b3:	9b                   	fwait
    17b4:	bf fc 15             	mov    di,0x15fc
    17b7:	0e                   	push   cs
    17b8:	57                   	push   di
    17b9:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    17bc:	06                   	push   es
    17bd:	57                   	push   di
    17be:	9a 9b 3b ed 17       	call   0x17ed:0x3b9b
    17c3:	89 c7                	mov    di,ax
    17c5:	8e c2                	mov    es,dx
    17c7:	06                   	push   es
    17c8:	57                   	push   di
    17c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17cc:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    17d0:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    17d3:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    17d6:	9b db 46 d0          	fild   DWORD PTR [bp-0x30]
    17da:	9b dd 5e e2          	fstp   QWORD PTR [bp-0x1e]
    17de:	90                   	nop
    17df:	9b                   	fwait
    17e0:	bf 0d 16             	mov    di,0x160d
    17e3:	0e                   	push   cs
    17e4:	57                   	push   di
    17e5:	c4 7e d4             	les    di,DWORD PTR [bp-0x2c]
    17e8:	06                   	push   es
    17e9:	57                   	push   di
    17ea:	9a 9b 3b 36 1a       	call   0x1a36:0x3b9b
    17ef:	89 c7                	mov    di,ax
    17f1:	8e c2                	mov    es,dx
    17f3:	06                   	push   es
    17f4:	57                   	push   di
    17f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17f8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    17fc:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    17ff:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    1802:	9b db 46 d0          	fild   DWORD PTR [bp-0x30]
    1806:	9b dd 5e da          	fstp   QWORD PTR [bp-0x26]
    180a:	90                   	nop
    180b:	9b 9b dd 46 f2       	fld    QWORD PTR [bp-0xe]
    1810:	9b 2e d8 1e e6 15    	fcomp  DWORD PTR cs:0x15e6
    1816:	9b dd 7e d2          	fstsw  WORD PTR [bp-0x2e]
    181a:	90                   	nop
    181b:	9b                   	fwait
    181c:	8a 66 d3             	mov    ah,BYTE PTR [bp-0x2d]
    181f:	9e                   	sahf
    1820:	75 03                	jne    0x1825
    1822:	e9 eb 00             	jmp    0x1910
    1825:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1828:	99                   	cwd
    1829:	bf e1 15             	mov    di,0x15e1
    182c:	9a 16 04 4d 18       	call   0x184d:0x416
    1831:	c1 e0 03             	shl    ax,0x3
    1834:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1837:	03 f8                	add    di,ax
    1839:	9b 26 dd 85 9f 04    	fld    QWORD PTR es:[di+0x49f]
    183f:	9b dc 46 f2          	fadd   QWORD PTR [bp-0xe]
    1843:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1846:	99                   	cwd
    1847:	bf e1 15             	mov    di,0x15e1
    184a:	9a 16 04 69 18       	call   0x1869:0x416
    184f:	c1 e0 03             	shl    ax,0x3
    1852:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1855:	03 f8                	add    di,ax
    1857:	9b 26 dd 9d 9f 04    	fstp   QWORD PTR es:[di+0x49f]
    185d:	90                   	nop
    185e:	9b                   	fwait
    185f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1862:	99                   	cwd
    1863:	bf e1 15             	mov    di,0x15e1
    1866:	9a 16 04 87 18       	call   0x1887:0x416
    186b:	c1 e0 03             	shl    ax,0x3
    186e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1871:	03 f8                	add    di,ax
    1873:	9b 26 dd 85 af 04    	fld    QWORD PTR es:[di+0x4af]
    1879:	9b dc 46 ea          	fadd   QWORD PTR [bp-0x16]
    187d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1880:	99                   	cwd
    1881:	bf e1 15             	mov    di,0x15e1
    1884:	9a 16 04 a3 18       	call   0x18a3:0x416
    1889:	c1 e0 03             	shl    ax,0x3
    188c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    188f:	03 f8                	add    di,ax
    1891:	9b 26 dd 9d af 04    	fstp   QWORD PTR es:[di+0x4af]
    1897:	90                   	nop
    1898:	9b                   	fwait
    1899:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    189c:	99                   	cwd
    189d:	bf e1 15             	mov    di,0x15e1
    18a0:	9a 16 04 c1 18       	call   0x18c1:0x416
    18a5:	c1 e0 03             	shl    ax,0x3
    18a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18ab:	03 f8                	add    di,ax
    18ad:	9b 26 dd 85 bf 04    	fld    QWORD PTR es:[di+0x4bf]
    18b3:	9b dc 46 e2          	fadd   QWORD PTR [bp-0x1e]
    18b7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    18ba:	99                   	cwd
    18bb:	bf e1 15             	mov    di,0x15e1
    18be:	9a 16 04 dd 18       	call   0x18dd:0x416
    18c3:	c1 e0 03             	shl    ax,0x3
    18c6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18c9:	03 f8                	add    di,ax
    18cb:	9b 26 dd 9d bf 04    	fstp   QWORD PTR es:[di+0x4bf]
    18d1:	90                   	nop
    18d2:	9b                   	fwait
    18d3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    18d6:	99                   	cwd
    18d7:	bf e1 15             	mov    di,0x15e1
    18da:	9a 16 04 fb 18       	call   0x18fb:0x416
    18df:	c1 e0 03             	shl    ax,0x3
    18e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18e5:	03 f8                	add    di,ax
    18e7:	9b 26 dd 85 cf 04    	fld    QWORD PTR es:[di+0x4cf]
    18ed:	9b dc 46 da          	fadd   QWORD PTR [bp-0x26]
    18f1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    18f4:	99                   	cwd
    18f5:	bf e1 15             	mov    di,0x15e1
    18f8:	9a 16 04 32 19       	call   0x1932:0x416
    18fd:	c1 e0 03             	shl    ax,0x3
    1900:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1903:	03 f8                	add    di,ax
    1905:	9b 26 dd 9d cf 04    	fstp   QWORD PTR es:[di+0x4cf]
    190b:	90                   	nop
    190c:	9b                   	fwait
    190d:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    1910:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1913:	3b 46 d8             	cmp    ax,WORD PTR [bp-0x28]
    1916:	74 03                	je     0x191b
    1918:	e9 f6 fd             	jmp    0x1711
    191b:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    191f:	75 03                	jne    0x1924
    1921:	e9 fc 00             	jmp    0x1a20
    1924:	9b df 46 fa          	fild   WORD PTR [bp-0x6]
    1928:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    192b:	99                   	cwd
    192c:	bf e1 15             	mov    di,0x15e1
    192f:	9a 16 04 45 19       	call   0x1945:0x416
    1934:	c1 e0 03             	shl    ax,0x3
    1937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    193a:	03 f8                	add    di,ax
    193c:	9b 26 dd 85 9f 04    	fld    QWORD PTR es:[di+0x49f]
    1942:	9a af 04 51 19       	call   0x1951:0x4af
    1947:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    194a:	99                   	cwd
    194b:	bf e1 15             	mov    di,0x15e1
    194e:	9a 16 04 71 19       	call   0x1971:0x416
    1953:	c1 e0 03             	shl    ax,0x3
    1956:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1959:	03 f8                	add    di,ax
    195b:	9b 26 dd 9d 9f 04    	fstp   QWORD PTR es:[di+0x49f]
    1961:	90                   	nop
    1962:	9b 9b df 46 fa       	fild   WORD PTR [bp-0x6]
    1967:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    196a:	99                   	cwd
    196b:	bf e1 15             	mov    di,0x15e1
    196e:	9a 16 04 84 19       	call   0x1984:0x416
    1973:	c1 e0 03             	shl    ax,0x3
    1976:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1979:	03 f8                	add    di,ax
    197b:	9b 26 dd 85 af 04    	fld    QWORD PTR es:[di+0x4af]
    1981:	9a af 04 90 19       	call   0x1990:0x4af
    1986:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1989:	99                   	cwd
    198a:	bf e1 15             	mov    di,0x15e1
    198d:	9a 16 04 b0 19       	call   0x19b0:0x416
    1992:	c1 e0 03             	shl    ax,0x3
    1995:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1998:	03 f8                	add    di,ax
    199a:	9b 26 dd 9d af 04    	fstp   QWORD PTR es:[di+0x4af]
    19a0:	90                   	nop
    19a1:	9b 9b df 46 fa       	fild   WORD PTR [bp-0x6]
    19a6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    19a9:	99                   	cwd
    19aa:	bf e1 15             	mov    di,0x15e1
    19ad:	9a 16 04 c3 19       	call   0x19c3:0x416
    19b2:	c1 e0 03             	shl    ax,0x3
    19b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19b8:	03 f8                	add    di,ax
    19ba:	9b 26 dd 85 bf 04    	fld    QWORD PTR es:[di+0x4bf]
    19c0:	9a af 04 cf 19       	call   0x19cf:0x4af
    19c5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    19c8:	99                   	cwd
    19c9:	bf e1 15             	mov    di,0x15e1
    19cc:	9a 16 04 ef 19       	call   0x19ef:0x416
    19d1:	c1 e0 03             	shl    ax,0x3
    19d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19d7:	03 f8                	add    di,ax
    19d9:	9b 26 dd 9d bf 04    	fstp   QWORD PTR es:[di+0x4bf]
    19df:	90                   	nop
    19e0:	9b 9b df 46 fa       	fild   WORD PTR [bp-0x6]
    19e5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    19e8:	99                   	cwd
    19e9:	bf e1 15             	mov    di,0x15e1
    19ec:	9a 16 04 02 1a       	call   0x1a02:0x416
    19f1:	c1 e0 03             	shl    ax,0x3
    19f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19f7:	03 f8                	add    di,ax
    19f9:	9b 26 dd 85 cf 04    	fld    QWORD PTR es:[di+0x4cf]
    19ff:	9a af 04 0e 1a       	call   0x1a0e:0x4af
    1a04:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1a07:	99                   	cwd
    1a08:	bf e1 15             	mov    di,0x15e1
    1a0b:	9a 16 04 73 1a       	call   0x1a73:0x416
    1a10:	c1 e0 03             	shl    ax,0x3
    1a13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a16:	03 f8                	add    di,ax
    1a18:	9b 26 dd 9d cf 04    	fstp   QWORD PTR es:[di+0x4cf]
    1a1e:	90                   	nop
    1a1f:	9b                   	fwait
    1a20:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    1a24:	74 03                	je     0x1a29
    1a26:	e9 42 fc             	jmp    0x166b
    1a29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a2c:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    1a31:	06                   	push   es
    1a32:	57                   	push   di
    1a33:	9a d2 31 24 24       	call   0x2424:0x31d2
    1a38:	c9                   	leave
    1a39:	ca 04 00             	retf   0x4
    1a3c:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1a40:	ff                   	(bad)
    1a41:	7f 00                	jg     0x1a43
    1a43:	00 02                	add    BYTE PTR [bp+si],al
    1a45:	23 56 03             	and    dx,WORD PTR [bp+0x3]
    1a48:	23 43 31             	and    ax,WORD PTR [bp+di+0x31]
    1a4b:	06                   	push   es
    1a4c:	23 43 32             	and    ax,WORD PTR [bp+di+0x32]
    1a4f:	23 41 63             	and    ax,WORD PTR [bx+di+0x63]
    1a52:	06                   	push   es
    1a53:	23 43 31             	and    ax,WORD PTR [bp+di+0x31]
    1a56:	23 41 63             	and    ax,WORD PTR [bx+di+0x63]
    1a59:	03 43 2c             	add    ax,WORD PTR [bp+di+0x2c]
    1a5c:	30 01                	xor    BYTE PTR [bx+di],al
    1a5e:	20 03                	and    BYTE PTR [bp+di],al
    1a60:	43                   	inc    bx
    1a61:	2c 31                	sub    al,0x31
    1a63:	03 23                	add    sp,WORD PTR [bp+di]
    1a65:	41                   	inc    cx
    1a66:	63 02                	arpl   WORD PTR [bp+si],ax
    1a68:	30 2c                	xor    BYTE PTR [si],ch
    1a6a:	55                   	push   bp
    1a6b:	89 e5                	mov    bp,sp
    1a6d:	b8 10 05             	mov    ax,0x510
    1a70:	9a 44 04 ab 1a       	call   0x1aab:0x444
    1a75:	81 ec 10 05          	sub    sp,0x510
    1a79:	bf fa 1d             	mov    di,0x1dfa
    1a7c:	1e                   	push   ds
    1a7d:	57                   	push   di
    1a7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a81:	26 c4 bd 10 03       	les    di,DWORD PTR es:[di+0x310]
    1a86:	06                   	push   es
    1a87:	57                   	push   di
    1a88:	9a 8c 1d e8 1a       	call   0x1ae8:0x1d8c
    1a8d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a90:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a93:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    1a97:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    1a9b:	a1 4e 01             	mov    ax,ds:0x14e
    1a9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aa1:	26 f7 ad a5 04       	imul   WORD PTR es:[di+0x4a5]
    1aa6:	71 05                	jno    0x1aad
    1aa8:	9a 3e 04 bb 1a       	call   0x1abb:0x43e
    1aad:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1ab1:	26 03 85 fe 00       	add    ax,WORD PTR es:[di+0xfe]
    1ab6:	71 05                	jno    0x1abd
    1ab8:	9a 3e 04 fc 1a       	call   0x1afc:0x43e
    1abd:	99                   	cwd
    1abe:	52                   	push   dx
    1abf:	50                   	push   ax
    1ac0:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1ac4:	06                   	push   es
    1ac5:	57                   	push   di
    1ac6:	9a 1b 70 19 1b       	call   0x1b19:0x701b
    1acb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ace:	26 80 bd 9e 03 00    	cmp    BYTE PTR es:[di+0x39e],0x0
    1ad4:	b0 00                	mov    al,0x0
    1ad6:	75 01                	jne    0x1ad9
    1ad8:	40                   	inc    ax
    1ad9:	50                   	push   ax
    1ada:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1ade:	26 c4 bd 96 01       	les    di,DWORD PTR es:[di+0x196]
    1ae3:	06                   	push   es
    1ae4:	57                   	push   di
    1ae5:	9a 77 1c d1 36       	call   0x36d1:0x1c77
    1aea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aed:	26 8b 85 a1 03       	mov    ax,WORD PTR es:[di+0x3a1]
    1af2:	26 f7 ad a5 04       	imul   WORD PTR es:[di+0x4a5]
    1af7:	71 05                	jno    0x1afe
    1af9:	9a 3e 04 06 1b       	call   0x1b06:0x43e
    1afe:	05 01 00             	add    ax,0x1
    1b01:	71 05                	jno    0x1b08
    1b03:	9a 3e 04 2b 1b       	call   0x1b2b:0x43e
    1b08:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    1b0c:	6a 00                	push   0x0
    1b0e:	6a 00                	push   0x0
    1b10:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1b14:	06                   	push   es
    1b15:	57                   	push   di
    1b16:	9a 30 6e 81 1b       	call   0x1b81:0x6e30
    1b1b:	8b d0                	mov    dx,ax
    1b1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b20:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1b24:	2b c2                	sub    ax,dx
    1b26:	71 05                	jno    0x1b2d
    1b28:	9a 3e 04 4f 1b       	call   0x1b4f:0x43e
    1b2d:	99                   	cwd
    1b2e:	f7 be f8 fe          	idiv   WORD PTR [bp-0x108]
    1b32:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    1b36:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1b3a:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1b3f:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1b44:	2d 01 00             	sub    ax,0x1
    1b47:	83 da 00             	sbb    dx,0x0
    1b4a:	71 05                	jno    0x1b51
    1b4c:	9a 3e 04 57 1b       	call   0x1b57:0x43e
    1b51:	bf 3c 1a             	mov    di,0x1a3c
    1b54:	9a 16 04 a5 1b       	call   0x1ba5:0x416
    1b59:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    1b5d:	b8 01 00             	mov    ax,0x1
    1b60:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1b64:	7f 26                	jg     0x1b8c
    1b66:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b69:	eb 03                	jmp    0x1b6e
    1b6b:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1b6e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b71:	99                   	cwd
    1b72:	52                   	push   dx
    1b73:	50                   	push   ax
    1b74:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    1b78:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1b7c:	06                   	push   es
    1b7d:	57                   	push   di
    1b7e:	9a c9 70 28 1c       	call   0x1c28:0x70c9
    1b83:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b86:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1b8a:	75 df                	jne    0x1b6b
    1b8c:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1b90:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1b95:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1b9a:	2d 01 00             	sub    ax,0x1
    1b9d:	83 da 00             	sbb    dx,0x0
    1ba0:	71 05                	jno    0x1ba7
    1ba2:	9a 3e 04 ad 1b       	call   0x1bad:0x43e
    1ba7:	bf 3c 1a             	mov    di,0x1a3c
    1baa:	9a 16 04 df 1b       	call   0x1bdf:0x416
    1baf:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    1bb3:	31 c0                	xor    ax,ax
    1bb5:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1bb9:	7e 03                	jle    0x1bbe
    1bbb:	e9 b1 00             	jmp    0x1c6f
    1bbe:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1bc1:	eb 03                	jmp    0x1bc6
    1bc3:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1bc6:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1bca:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    1bcf:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    1bd4:	2d 01 00             	sub    ax,0x1
    1bd7:	83 da 00             	sbb    dx,0x0
    1bda:	71 05                	jno    0x1be1
    1bdc:	9a 3e 04 e7 1b       	call   0x1be7:0x43e
    1be1:	bf 3c 1a             	mov    di,0x1a3c
    1be4:	9a 16 04 8b 1c       	call   0x1c8b:0x416
    1be9:	89 86 ee fd          	mov    WORD PTR [bp-0x212],ax
    1bed:	31 c0                	xor    ax,ax
    1bef:	3b 86 ee fd          	cmp    ax,WORD PTR [bp-0x212]
    1bf3:	7f 6e                	jg     0x1c63
    1bf5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1bf8:	eb 03                	jmp    0x1bfd
    1bfa:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    1bfd:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    1c01:	7e 41                	jle    0x1c44
    1c03:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1c06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c09:	99                   	cwd
    1c0a:	26 f7 bd a5 04       	idiv   WORD PTR es:[di+0x4a5]
    1c0f:	92                   	xchg   dx,ax
    1c10:	09 c0                	or     ax,ax
    1c12:	75 18                	jne    0x1c2c
    1c14:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c17:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1c1a:	bf 44 1a             	mov    di,0x1a44
    1c1d:	0e                   	push   cs
    1c1e:	57                   	push   di
    1c1f:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1c23:	06                   	push   es
    1c24:	57                   	push   di
    1c25:	9a 08 9b 40 1c       	call   0x1c40:0x9b08
    1c2a:	eb 16                	jmp    0x1c42
    1c2c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c2f:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1c32:	bf 47 1a             	mov    di,0x1a47
    1c35:	0e                   	push   cs
    1c36:	57                   	push   di
    1c37:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1c3b:	06                   	push   es
    1c3c:	57                   	push   di
    1c3d:	9a 08 9b 58 1c       	call   0x1c58:0x9b08
    1c42:	eb 16                	jmp    0x1c5a
    1c44:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c47:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1c4a:	bf 3c 1a             	mov    di,0x1a3c
    1c4d:	0e                   	push   cs
    1c4e:	57                   	push   di
    1c4f:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1c53:	06                   	push   es
    1c54:	57                   	push   di
    1c55:	9a 08 9b 58 1d       	call   0x1d58:0x9b08
    1c5a:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1c5d:	3b 86 ee fd          	cmp    ax,WORD PTR [bp-0x212]
    1c61:	75 97                	jne    0x1bfa
    1c63:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1c66:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1c6a:	74 03                	je     0x1c6f
    1c6c:	e9 54 ff             	jmp    0x1bc3
    1c6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c72:	26 83 bd a5 04 02    	cmp    WORD PTR es:[di+0x4a5],0x2
    1c78:	75 15                	jne    0x1c8f
    1c7a:	bf 4b 1a             	mov    di,0x1a4b
    1c7d:	0e                   	push   cs
    1c7e:	57                   	push   di
    1c7f:	8d be f6 fd          	lea    di,[bp-0x20a]
    1c83:	16                   	push   ss
    1c84:	57                   	push   di
    1c85:	68 ff 00             	push   0xff
    1c88:	9a e7 17 a0 1c       	call   0x1ca0:0x17e7
    1c8d:	eb 13                	jmp    0x1ca2
    1c8f:	bf 52 1a             	mov    di,0x1a52
    1c92:	0e                   	push   cs
    1c93:	57                   	push   di
    1c94:	8d be f6 fd          	lea    di,[bp-0x20a]
    1c98:	16                   	push   ss
    1c99:	57                   	push   di
    1c9a:	68 ff 00             	push   0xff
    1c9d:	9a e7 17 cd 1c       	call   0x1ccd:0x17e7
    1ca2:	8d be f2 fc          	lea    di,[bp-0x30e]
    1ca6:	16                   	push   ss
    1ca7:	57                   	push   di
    1ca8:	bf 59 1a             	mov    di,0x1a59
    1cab:	0e                   	push   cs
    1cac:	57                   	push   di
    1cad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cb0:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    1cb5:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1cba:	06                   	push   es
    1cbb:	57                   	push   di
    1cbc:	9a 19 15 80 1d       	call   0x1d80:0x1519
    1cc1:	8d be fa fe          	lea    di,[bp-0x106]
    1cc5:	16                   	push   ss
    1cc6:	57                   	push   di
    1cc7:	68 ff 00             	push   0xff
    1cca:	9a e7 17 f5 1c       	call   0x1cf5:0x17e7
    1ccf:	a1 4e 01             	mov    ax,ds:0x14e
    1cd2:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    1cd6:	b8 01 00             	mov    ax,0x1
    1cd9:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1cdd:	7e 03                	jle    0x1ce2
    1cdf:	e9 81 00             	jmp    0x1d63
    1ce2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ce5:	eb 03                	jmp    0x1cea
    1ce7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1cea:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ced:	2d 01 00             	sub    ax,0x1
    1cf0:	71 05                	jno    0x1cf7
    1cf2:	9a 3e 04 04 1d       	call   0x1d04:0x43e
    1cf7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cfa:	26 f7 ad a5 04       	imul   WORD PTR es:[di+0x4a5]
    1cff:	71 05                	jno    0x1d06
    1d01:	9a 3e 04 0e 1d       	call   0x1d0e:0x43e
    1d06:	05 01 00             	add    ax,0x1
    1d09:	71 05                	jno    0x1d10
    1d0b:	9a 3e 04 22 1d       	call   0x1d22:0x43e
    1d10:	50                   	push   ax
    1d11:	6a 00                	push   0x0
    1d13:	8d be f0 fc          	lea    di,[bp-0x310]
    1d17:	16                   	push   ss
    1d18:	57                   	push   di
    1d19:	8d be f6 fd          	lea    di,[bp-0x20a]
    1d1d:	16                   	push   ss
    1d1e:	57                   	push   di
    1d1f:	9a cd 17 2d 1d       	call   0x1d2d:0x17cd
    1d24:	8d be fa fe          	lea    di,[bp-0x106]
    1d28:	16                   	push   ss
    1d29:	57                   	push   di
    1d2a:	9a 4c 18 37 1d       	call   0x1d37:0x184c
    1d2f:	bf 5d 1a             	mov    di,0x1a5d
    1d32:	0e                   	push   cs
    1d33:	57                   	push   di
    1d34:	9a 4c 18 4d 1d       	call   0x1d4d:0x184c
    1d39:	8d be f0 fb          	lea    di,[bp-0x410]
    1d3d:	16                   	push   ss
    1d3e:	57                   	push   di
    1d3f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d42:	99                   	cwd
    1d43:	52                   	push   dx
    1d44:	50                   	push   ax
    1d45:	9a a9 08 1f 1e       	call   0x1e1f:0x8a9
    1d4a:	9a 4c 18 8e 1d       	call   0x1d8e:0x184c
    1d4f:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1d53:	06                   	push   es
    1d54:	57                   	push   di
    1d55:	9a 08 9b 2f 1e       	call   0x1e2f:0x9b08
    1d5a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d5d:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1d61:	75 84                	jne    0x1ce7
    1d63:	8d be f2 fc          	lea    di,[bp-0x30e]
    1d67:	16                   	push   ss
    1d68:	57                   	push   di
    1d69:	bf 5f 1a             	mov    di,0x1a5f
    1d6c:	0e                   	push   cs
    1d6d:	57                   	push   di
    1d6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d71:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    1d76:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1d7b:	06                   	push   es
    1d7c:	57                   	push   di
    1d7d:	9a 19 15 b2 1e       	call   0x1eb2:0x1519
    1d82:	8d be fa fe          	lea    di,[bp-0x106]
    1d86:	16                   	push   ss
    1d87:	57                   	push   di
    1d88:	68 ff 00             	push   0xff
    1d8b:	9a e7 17 a9 1d       	call   0x1da9:0x17e7
    1d90:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1d94:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1d99:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1d9e:	2d 01 00             	sub    ax,0x1
    1da1:	83 da 00             	sbb    dx,0x0
    1da4:	71 05                	jno    0x1dab
    1da6:	9a 3e 04 b1 1d       	call   0x1db1:0x43e
    1dab:	bf 3c 1a             	mov    di,0x1a3c
    1dae:	9a 16 04 db 1d       	call   0x1ddb:0x416
    1db3:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    1db7:	b8 01 00             	mov    ax,0x1
    1dba:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1dbe:	7f 7a                	jg     0x1e3a
    1dc0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1dc3:	eb 03                	jmp    0x1dc8
    1dc5:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    1dc8:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1dcb:	6a 01                	push   0x1
    1dcd:	8d be f0 fc          	lea    di,[bp-0x310]
    1dd1:	16                   	push   ss
    1dd2:	57                   	push   di
    1dd3:	bf 63 1a             	mov    di,0x1a63
    1dd6:	0e                   	push   cs
    1dd7:	57                   	push   di
    1dd8:	9a cd 17 e6 1d       	call   0x1de6:0x17cd
    1ddd:	8d be fa fe          	lea    di,[bp-0x106]
    1de1:	16                   	push   ss
    1de2:	57                   	push   di
    1de3:	9a 4c 18 f0 1d       	call   0x1df0:0x184c
    1de8:	bf 5d 1a             	mov    di,0x1a5d
    1deb:	0e                   	push   cs
    1dec:	57                   	push   di
    1ded:	9a 4c 18 03 1e       	call   0x1e03:0x184c
    1df2:	8d be f0 fb          	lea    di,[bp-0x410]
    1df6:	16                   	push   ss
    1df7:	57                   	push   di
    1df8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1dfb:	2d 01 00             	sub    ax,0x1
    1dfe:	71 05                	jno    0x1e05
    1e00:	9a 3e 04 17 1e       	call   0x1e17:0x43e
    1e05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e08:	99                   	cwd
    1e09:	26 f7 bd a5 04       	idiv   WORD PTR es:[di+0x4a5]
    1e0e:	92                   	xchg   dx,ax
    1e0f:	05 01 00             	add    ax,0x1
    1e12:	71 05                	jno    0x1e19
    1e14:	9a 3e 04 24 1e       	call   0x1e24:0x43e
    1e19:	99                   	cwd
    1e1a:	52                   	push   dx
    1e1b:	50                   	push   ax
    1e1c:	9a a9 08 99 1e       	call   0x1e99:0x8a9
    1e21:	9a 4c 18 58 1e       	call   0x1e58:0x184c
    1e26:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1e2a:	06                   	push   es
    1e2b:	57                   	push   di
    1e2c:	9a 08 9b bd 1e       	call   0x1ebd:0x9b08
    1e31:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1e34:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1e38:	75 8b                	jne    0x1dc5
    1e3a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e3d:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    1e42:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1e47:	06                   	push   es
    1e48:	57                   	push   di
    1e49:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e4c:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1e50:	2d 01 00             	sub    ax,0x1
    1e53:	71 05                	jno    0x1e5a
    1e55:	9a 3e 04 88 1e       	call   0x1e88:0x43e
    1e5a:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    1e5e:	b8 02 00             	mov    ax,0x2
    1e61:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1e65:	7f 61                	jg     0x1ec8
    1e67:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1e6a:	eb 03                	jmp    0x1e6f
    1e6c:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    1e6f:	6a 00                	push   0x0
    1e71:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1e74:	8d be f0 fa          	lea    di,[bp-0x510]
    1e78:	16                   	push   ss
    1e79:	57                   	push   di
    1e7a:	8d be f0 fb          	lea    di,[bp-0x410]
    1e7e:	16                   	push   ss
    1e7f:	57                   	push   di
    1e80:	bf 67 1a             	mov    di,0x1a67
    1e83:	0e                   	push   cs
    1e84:	57                   	push   di
    1e85:	9a cd 17 9e 1e       	call   0x1e9e:0x17cd
    1e8a:	8d be f0 fc          	lea    di,[bp-0x310]
    1e8e:	16                   	push   ss
    1e8f:	57                   	push   di
    1e90:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1e93:	99                   	cwd
    1e94:	52                   	push   dx
    1e95:	50                   	push   ax
    1e96:	9a a9 08 89 21       	call   0x2189:0x8a9
    1e9b:	9a 4c 18 18 1f       	call   0x1f18:0x184c
    1ea0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ea3:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    1ea8:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1ead:	06                   	push   es
    1eae:	57                   	push   di
    1eaf:	9a 19 15 63 2a       	call   0x2a63:0x1519
    1eb4:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    1eb8:	06                   	push   es
    1eb9:	57                   	push   di
    1eba:	9a 08 9b ca 1f       	call   0x1fca:0x9b08
    1ebf:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1ec2:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    1ec6:	75 a4                	jne    0x1e6c
    1ec8:	c9                   	leave
    1ec9:	ca 08 00             	retf   0x8
    1ecc:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    1ed0:	ff                   	(bad)
    1ed1:	7f 00                	jg     0x1ed3
    1ed3:	00 06 23 43          	add    BYTE PTR ds:0x4323,al
    1ed7:	32 23                	xor    ah,BYTE PTR [bp+di]
    1ed9:	41                   	inc    cx
    1eda:	63 06 23 43          	arpl   WORD PTR ds:0x4323,ax
    1ede:	31 23                	xor    WORD PTR [bp+di],sp
    1ee0:	41                   	inc    cx
    1ee1:	63 0a                	arpl   WORD PTR [bp+si],cx
    1ee3:	45                   	inc    bp
    1ee4:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ee5:	74 72                	je     0x1f59
    1ee7:	65 70 72             	gs jo  0x1f5c
    1eea:	69 73 65 04 45       	imul   si,WORD PTR [bp+di+0x65],0x4504
    1eef:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ef0:	74 2e                	je     0x1f20
    1ef2:	02 20                	add    ah,BYTE PTR [bx+si]
    1ef4:	35 02 45             	xor    ax,0x4502
    1ef7:	2e 01 20             	add    WORD PTR cs:[bx+si],sp
    1efa:	07                   	pop    es
    1efb:	50                   	push   ax
    1efc:	72 6f                	jb     0x1f6d
    1efe:	64 75 69             	fs jne 0x1f6a
    1f01:	74 05                	je     0x1f08
    1f03:	50                   	push   ax
    1f04:	72 6f                	jb     0x1f75
    1f06:	64 2e 02 50 2e       	fs add dl,BYTE PTR cs:[bx+si+0x2e]
    1f0b:	03 23                	add    sp,WORD PTR [bp+di]
    1f0d:	41                   	inc    cx
    1f0e:	63 55 89             	arpl   WORD PTR [di-0x77],dx
    1f11:	e5 b8                	in     ax,0xb8
    1f13:	0e                   	push   cs
    1f14:	06                   	push   es
    1f15:	9a 44 04 68 1f       	call   0x1f68:0x444
    1f1a:	81 ec 0e 06          	sub    sp,0x60e
    1f1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f21:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    1f26:	89 be f4 fb          	mov    WORD PTR [bp-0x40c],di
    1f2a:	8c 86 f6 fb          	mov    WORD PTR [bp-0x40a],es
    1f2e:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1f32:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1f36:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1f3b:	06                   	push   es
    1f3c:	57                   	push   di
    1f3d:	9a 99 20 5c 1f       	call   0x1f5c:0x2099
    1f42:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    1f46:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1f4b:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    1f4f:	89 be f0 fb          	mov    WORD PTR [bp-0x410],di
    1f53:	8c 86 f2 fb          	mov    WORD PTR [bp-0x40e],es
    1f57:	06                   	push   es
    1f58:	57                   	push   di
    1f59:	9a cc 11 95 1f       	call   0x1f95:0x11cc
    1f5e:	b9 0d 00             	mov    cx,0xd
    1f61:	f7 e9                	imul   cx
    1f63:	71 05                	jno    0x1f6a
    1f65:	9a 3e 04 81 1f       	call   0x1f81:0x43e
    1f6a:	99                   	cwd
    1f6b:	b9 0a 00             	mov    cx,0xa
    1f6e:	f7 f9                	idiv   cx
    1f70:	99                   	cwd
    1f71:	89 86 ec fb          	mov    WORD PTR [bp-0x414],ax
    1f75:	89 96 ee fb          	mov    WORD PTR [bp-0x412],dx
    1f79:	9b db 86 ec fb       	fild   DWORD PTR [bp-0x414]
    1f7e:	9a 2f 10 89 1f       	call   0x1f89:0x102f
    1f83:	bf cc 1e             	mov    di,0x1ecc
    1f86:	9a 16 04 d9 1f       	call   0x1fd9:0x416
    1f8b:	50                   	push   ax
    1f8c:	c4 be f0 fb          	les    di,DWORD PTR [bp-0x410]
    1f90:	06                   	push   es
    1f91:	57                   	push   di
    1f92:	9a f5 11 a0 1f       	call   0x1fa0:0x11f5
    1f97:	c4 be f0 fb          	les    di,DWORD PTR [bp-0x410]
    1f9b:	06                   	push   es
    1f9c:	57                   	push   di
    1f9d:	9a 1a 12 ae 1f       	call   0x1fae:0x121a
    1fa2:	0c 01                	or     al,0x1
    1fa4:	50                   	push   ax
    1fa5:	c4 be f0 fb          	les    di,DWORD PTR [bp-0x410]
    1fa9:	06                   	push   es
    1faa:	57                   	push   di
    1fab:	9a 33 12 bb 1f       	call   0x1fbb:0x1233
    1fb0:	6a 02                	push   0x2
    1fb2:	c4 be f0 fb          	les    di,DWORD PTR [bp-0x410]
    1fb6:	06                   	push   es
    1fb7:	57                   	push   di
    1fb8:	9a 78 12 78 20       	call   0x2078:0x1278
    1fbd:	6a 00                	push   0x0
    1fbf:	6a 01                	push   0x1
    1fc1:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    1fc5:	06                   	push   es
    1fc6:	57                   	push   di
    1fc7:	9a 30 6e 99 21       	call   0x2199:0x6e30
    1fcc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fcf:	26 f7 ad a5 04       	imul   WORD PTR es:[di+0x4a5]
    1fd4:	71 05                	jno    0x1fdb
    1fd6:	9a 3e 04 fe 1f       	call   0x1ffe:0x43e
    1fdb:	99                   	cwd
    1fdc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1fdf:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1fe2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fe5:	26 83 bd a5 04 02    	cmp    WORD PTR es:[di+0x4a5],0x2
    1feb:	75 15                	jne    0x2002
    1fed:	bf d4 1e             	mov    di,0x1ed4
    1ff0:	0e                   	push   cs
    1ff1:	57                   	push   di
    1ff2:	8d be f8 fb          	lea    di,[bp-0x408]
    1ff6:	16                   	push   ss
    1ff7:	57                   	push   di
    1ff8:	68 ff 00             	push   0xff
    1ffb:	9a e7 17 13 20       	call   0x2013:0x17e7
    2000:	eb 13                	jmp    0x2015
    2002:	bf db 1e             	mov    di,0x1edb
    2005:	0e                   	push   cs
    2006:	57                   	push   di
    2007:	8d be f8 fb          	lea    di,[bp-0x408]
    200b:	16                   	push   ss
    200c:	57                   	push   di
    200d:	68 ff 00             	push   0xff
    2010:	9a e7 17 26 20       	call   0x2026:0x17e7
    2015:	bf e2 1e             	mov    di,0x1ee2
    2018:	0e                   	push   cs
    2019:	57                   	push   di
    201a:	8d be f8 fe          	lea    di,[bp-0x108]
    201e:	16                   	push   ss
    201f:	57                   	push   di
    2020:	68 ff 00             	push   0xff
    2023:	9a e7 17 39 20       	call   0x2039:0x17e7
    2028:	bf ed 1e             	mov    di,0x1eed
    202b:	0e                   	push   cs
    202c:	57                   	push   di
    202d:	8d be f8 fd          	lea    di,[bp-0x208]
    2031:	16                   	push   ss
    2032:	57                   	push   di
    2033:	68 ff 00             	push   0xff
    2036:	9a e7 17 4d 20       	call   0x204d:0x17e7
    203b:	8d be f8 fe          	lea    di,[bp-0x108]
    203f:	16                   	push   ss
    2040:	57                   	push   di
    2041:	8d be f8 fc          	lea    di,[bp-0x308]
    2045:	16                   	push   ss
    2046:	57                   	push   di
    2047:	68 ff 00             	push   0xff
    204a:	9a e7 17 5e 20       	call   0x205e:0x17e7
    204f:	8d be f4 fa          	lea    di,[bp-0x50c]
    2053:	16                   	push   ss
    2054:	57                   	push   di
    2055:	8d be f8 fe          	lea    di,[bp-0x108]
    2059:	16                   	push   ss
    205a:	57                   	push   di
    205b:	9a cd 17 68 20       	call   0x2068:0x17cd
    2060:	bf f2 1e             	mov    di,0x1ef2
    2063:	0e                   	push   cs
    2064:	57                   	push   di
    2065:	9a 4c 18 90 20       	call   0x2090:0x184c
    206a:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    206e:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2073:	06                   	push   es
    2074:	57                   	push   di
    2075:	9a 03 20 d9 20       	call   0x20d9:0x2003
    207a:	99                   	cwd
    207b:	8b c8                	mov    cx,ax
    207d:	8b da                	mov    bx,dx
    207f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2082:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2085:	2d 0a 00             	sub    ax,0xa
    2088:	83 da 00             	sbb    dx,0x0
    208b:	71 05                	jno    0x2092
    208d:	9a 3e 04 ae 20       	call   0x20ae:0x43e
    2092:	3b d3                	cmp    dx,bx
    2094:	7c 06                	jl     0x209c
    2096:	7f 18                	jg     0x20b0
    2098:	3b c1                	cmp    ax,cx
    209a:	73 14                	jae    0x20b0
    209c:	8d be f8 fd          	lea    di,[bp-0x208]
    20a0:	16                   	push   ss
    20a1:	57                   	push   di
    20a2:	8d be f8 fc          	lea    di,[bp-0x308]
    20a6:	16                   	push   ss
    20a7:	57                   	push   di
    20a8:	68 ff 00             	push   0xff
    20ab:	9a e7 17 bf 20       	call   0x20bf:0x17e7
    20b0:	8d be f4 fa          	lea    di,[bp-0x50c]
    20b4:	16                   	push   ss
    20b5:	57                   	push   di
    20b6:	8d be f8 fd          	lea    di,[bp-0x208]
    20ba:	16                   	push   ss
    20bb:	57                   	push   di
    20bc:	9a cd 17 c9 20       	call   0x20c9:0x17cd
    20c1:	bf f2 1e             	mov    di,0x1ef2
    20c4:	0e                   	push   cs
    20c5:	57                   	push   di
    20c6:	9a 4c 18 f1 20       	call   0x20f1:0x184c
    20cb:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    20cf:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    20d4:	06                   	push   es
    20d5:	57                   	push   di
    20d6:	9a 03 20 1d 22       	call   0x221d:0x2003
    20db:	99                   	cwd
    20dc:	8b c8                	mov    cx,ax
    20de:	8b da                	mov    bx,dx
    20e0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    20e3:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    20e6:	2d 0a 00             	sub    ax,0xa
    20e9:	83 da 00             	sbb    dx,0x0
    20ec:	71 05                	jno    0x20f3
    20ee:	9a 3e 04 0e 21       	call   0x210e:0x43e
    20f3:	3b d3                	cmp    dx,bx
    20f5:	7c 06                	jl     0x20fd
    20f7:	7f 17                	jg     0x2110
    20f9:	3b c1                	cmp    ax,cx
    20fb:	73 13                	jae    0x2110
    20fd:	bf f5 1e             	mov    di,0x1ef5
    2100:	0e                   	push   cs
    2101:	57                   	push   di
    2102:	8d be f8 fc          	lea    di,[bp-0x308]
    2106:	16                   	push   ss
    2107:	57                   	push   di
    2108:	68 ff 00             	push   0xff
    210b:	9a e7 17 36 21       	call   0x2136:0x17e7
    2110:	a1 4e 01             	mov    ax,ds:0x14e
    2113:	89 86 f2 fb          	mov    WORD PTR [bp-0x40e],ax
    2117:	b8 01 00             	mov    ax,0x1
    211a:	3b 86 f2 fb          	cmp    ax,WORD PTR [bp-0x40e]
    211e:	7e 03                	jle    0x2123
    2120:	e9 81 00             	jmp    0x21a4
    2123:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2126:	eb 03                	jmp    0x212b
    2128:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    212b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    212e:	2d 01 00             	sub    ax,0x1
    2131:	71 05                	jno    0x2138
    2133:	9a 3e 04 45 21       	call   0x2145:0x43e
    2138:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    213b:	26 f7 ad a5 04       	imul   WORD PTR es:[di+0x4a5]
    2140:	71 05                	jno    0x2147
    2142:	9a 3e 04 4f 21       	call   0x214f:0x43e
    2147:	05 01 00             	add    ax,0x1
    214a:	71 05                	jno    0x2151
    214c:	9a 3e 04 63 21       	call   0x2163:0x43e
    2151:	50                   	push   ax
    2152:	6a 00                	push   0x0
    2154:	8d be f2 fa          	lea    di,[bp-0x50e]
    2158:	16                   	push   ss
    2159:	57                   	push   di
    215a:	8d be f8 fb          	lea    di,[bp-0x408]
    215e:	16                   	push   ss
    215f:	57                   	push   di
    2160:	9a cd 17 6e 21       	call   0x216e:0x17cd
    2165:	8d be f8 fc          	lea    di,[bp-0x308]
    2169:	16                   	push   ss
    216a:	57                   	push   di
    216b:	9a 4c 18 78 21       	call   0x2178:0x184c
    2170:	bf f8 1e             	mov    di,0x1ef8
    2173:	0e                   	push   cs
    2174:	57                   	push   di
    2175:	9a 4c 18 8e 21       	call   0x218e:0x184c
    217a:	8d be f2 f9          	lea    di,[bp-0x60e]
    217e:	16                   	push   ss
    217f:	57                   	push   di
    2180:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2183:	99                   	cwd
    2184:	52                   	push   dx
    2185:	50                   	push   ax
    2186:	9a a9 08 44 23       	call   0x2344:0x8a9
    218b:	9a 4c 18 cb 21       	call   0x21cb:0x184c
    2190:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    2194:	06                   	push   es
    2195:	57                   	push   di
    2196:	9a 08 9b b1 21       	call   0x21b1:0x9b08
    219b:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    219e:	3b 86 f2 fb          	cmp    ax,WORD PTR [bp-0x40e]
    21a2:	75 84                	jne    0x2128
    21a4:	6a 00                	push   0x0
    21a6:	6a 01                	push   0x1
    21a8:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    21ac:	06                   	push   es
    21ad:	57                   	push   di
    21ae:	9a 30 6e 54 23       	call   0x2354:0x6e30
    21b3:	99                   	cwd
    21b4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    21b7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    21ba:	bf fa 1e             	mov    di,0x1efa
    21bd:	0e                   	push   cs
    21be:	57                   	push   di
    21bf:	8d be f8 fe          	lea    di,[bp-0x108]
    21c3:	16                   	push   ss
    21c4:	57                   	push   di
    21c5:	68 ff 00             	push   0xff
    21c8:	9a e7 17 de 21       	call   0x21de:0x17e7
    21cd:	bf 02 1f             	mov    di,0x1f02
    21d0:	0e                   	push   cs
    21d1:	57                   	push   di
    21d2:	8d be f8 fd          	lea    di,[bp-0x208]
    21d6:	16                   	push   ss
    21d7:	57                   	push   di
    21d8:	68 ff 00             	push   0xff
    21db:	9a e7 17 f2 21       	call   0x21f2:0x17e7
    21e0:	8d be f8 fe          	lea    di,[bp-0x108]
    21e4:	16                   	push   ss
    21e5:	57                   	push   di
    21e6:	8d be f8 fc          	lea    di,[bp-0x308]
    21ea:	16                   	push   ss
    21eb:	57                   	push   di
    21ec:	68 ff 00             	push   0xff
    21ef:	9a e7 17 03 22       	call   0x2203:0x17e7
    21f4:	8d be f4 fa          	lea    di,[bp-0x50c]
    21f8:	16                   	push   ss
    21f9:	57                   	push   di
    21fa:	8d be f8 fe          	lea    di,[bp-0x108]
    21fe:	16                   	push   ss
    21ff:	57                   	push   di
    2200:	9a cd 17 0d 22       	call   0x220d:0x17cd
    2205:	bf f2 1e             	mov    di,0x1ef2
    2208:	0e                   	push   cs
    2209:	57                   	push   di
    220a:	9a 4c 18 35 22       	call   0x2235:0x184c
    220f:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    2213:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2218:	06                   	push   es
    2219:	57                   	push   di
    221a:	9a 03 20 7e 22       	call   0x227e:0x2003
    221f:	99                   	cwd
    2220:	8b c8                	mov    cx,ax
    2222:	8b da                	mov    bx,dx
    2224:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2227:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    222a:	2d 0a 00             	sub    ax,0xa
    222d:	83 da 00             	sbb    dx,0x0
    2230:	71 05                	jno    0x2237
    2232:	9a 3e 04 53 22       	call   0x2253:0x43e
    2237:	3b d3                	cmp    dx,bx
    2239:	7c 06                	jl     0x2241
    223b:	7f 18                	jg     0x2255
    223d:	3b c1                	cmp    ax,cx
    223f:	73 14                	jae    0x2255
    2241:	8d be f8 fd          	lea    di,[bp-0x208]
    2245:	16                   	push   ss
    2246:	57                   	push   di
    2247:	8d be f8 fc          	lea    di,[bp-0x308]
    224b:	16                   	push   ss
    224c:	57                   	push   di
    224d:	68 ff 00             	push   0xff
    2250:	9a e7 17 64 22       	call   0x2264:0x17e7
    2255:	8d be f4 fa          	lea    di,[bp-0x50c]
    2259:	16                   	push   ss
    225a:	57                   	push   di
    225b:	8d be f8 fd          	lea    di,[bp-0x208]
    225f:	16                   	push   ss
    2260:	57                   	push   di
    2261:	9a cd 17 6e 22       	call   0x226e:0x17cd
    2266:	bf f2 1e             	mov    di,0x1ef2
    2269:	0e                   	push   cs
    226a:	57                   	push   di
    226b:	9a 4c 18 96 22       	call   0x2296:0x184c
    2270:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    2274:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2279:	06                   	push   es
    227a:	57                   	push   di
    227b:	9a 03 20 f6 36       	call   0x36f6:0x2003
    2280:	99                   	cwd
    2281:	8b c8                	mov    cx,ax
    2283:	8b da                	mov    bx,dx
    2285:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2288:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    228b:	2d 0a 00             	sub    ax,0xa
    228e:	83 da 00             	sbb    dx,0x0
    2291:	71 05                	jno    0x2298
    2293:	9a 3e 04 b3 22       	call   0x22b3:0x43e
    2298:	3b d3                	cmp    dx,bx
    229a:	7c 06                	jl     0x22a2
    229c:	7f 17                	jg     0x22b5
    229e:	3b c1                	cmp    ax,cx
    22a0:	73 13                	jae    0x22b5
    22a2:	bf 08 1f             	mov    di,0x1f08
    22a5:	0e                   	push   cs
    22a6:	57                   	push   di
    22a7:	8d be f8 fc          	lea    di,[bp-0x308]
    22ab:	16                   	push   ss
    22ac:	57                   	push   di
    22ad:	68 ff 00             	push   0xff
    22b0:	9a e7 17 ce 22       	call   0x22ce:0x17e7
    22b5:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    22b9:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    22be:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    22c3:	2d 01 00             	sub    ax,0x1
    22c6:	83 da 00             	sbb    dx,0x0
    22c9:	71 05                	jno    0x22d0
    22cb:	9a 3e 04 d6 22       	call   0x22d6:0x43e
    22d0:	bf cc 1e             	mov    di,0x1ecc
    22d3:	9a 16 04 00 23       	call   0x2300:0x416
    22d8:	89 86 f2 fb          	mov    WORD PTR [bp-0x40e],ax
    22dc:	b8 01 00             	mov    ax,0x1
    22df:	3b 86 f2 fb          	cmp    ax,WORD PTR [bp-0x40e]
    22e3:	7f 7a                	jg     0x235f
    22e5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    22e8:	eb 03                	jmp    0x22ed
    22ea:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    22ed:	ff 76 fa             	push   WORD PTR [bp-0x6]
    22f0:	6a 01                	push   0x1
    22f2:	8d be f2 fa          	lea    di,[bp-0x50e]
    22f6:	16                   	push   ss
    22f7:	57                   	push   di
    22f8:	bf 0b 1f             	mov    di,0x1f0b
    22fb:	0e                   	push   cs
    22fc:	57                   	push   di
    22fd:	9a cd 17 0b 23       	call   0x230b:0x17cd
    2302:	8d be f8 fc          	lea    di,[bp-0x308]
    2306:	16                   	push   ss
    2307:	57                   	push   di
    2308:	9a 4c 18 15 23       	call   0x2315:0x184c
    230d:	bf f8 1e             	mov    di,0x1ef8
    2310:	0e                   	push   cs
    2311:	57                   	push   di
    2312:	9a 4c 18 28 23       	call   0x2328:0x184c
    2317:	8d be f2 f9          	lea    di,[bp-0x60e]
    231b:	16                   	push   ss
    231c:	57                   	push   di
    231d:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2320:	2d 01 00             	sub    ax,0x1
    2323:	71 05                	jno    0x232a
    2325:	9a 3e 04 3c 23       	call   0x233c:0x43e
    232a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    232d:	99                   	cwd
    232e:	26 f7 bd a5 04       	idiv   WORD PTR es:[di+0x4a5]
    2333:	92                   	xchg   dx,ax
    2334:	05 01 00             	add    ax,0x1
    2337:	71 05                	jno    0x233e
    2339:	9a 3e 04 49 23       	call   0x2349:0x43e
    233e:	99                   	cwd
    233f:	52                   	push   dx
    2340:	50                   	push   ax
    2341:	9a a9 08 4b 24       	call   0x244b:0x8a9
    2346:	9a 4c 18 76 23       	call   0x2376:0x184c
    234b:	c4 be f4 fb          	les    di,DWORD PTR [bp-0x40c]
    234f:	06                   	push   es
    2350:	57                   	push   di
    2351:	9a 08 9b 00 25       	call   0x2500:0x9b08
    2356:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2359:	3b 86 f2 fb          	cmp    ax,WORD PTR [bp-0x40e]
    235d:	75 8b                	jne    0x22ea
    235f:	c9                   	leave
    2360:	ca 04 00             	retf   0x4
    2363:	02 23                	add    ah,BYTE PTR [bp+di]
    2365:	56                   	push   si
    2366:	03 23                	add    sp,WORD PTR [bp+di]
    2368:	41                   	inc    cx
    2369:	64 02 25             	add    ah,BYTE PTR fs:[di]
    236c:	64 55                	fs push bp
    236e:	89 e5                	mov    bp,sp
    2370:	b8 16 03             	mov    ax,0x316
    2373:	9a 44 04 af 23       	call   0x23af:0x444
    2378:	81 ec 16 03          	sub    sp,0x316
    237c:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    237f:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    2383:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2386:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    238a:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    238e:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    2391:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2394:	99                   	cwd
    2395:	36 f7 7d f8          	idiv   WORD PTR ss:[di-0x8]
    2399:	92                   	xchg   dx,ax
    239a:	09 c0                	or     ax,ax
    239c:	75 15                	jne    0x23b3
    239e:	bf 63 23             	mov    di,0x2363
    23a1:	0e                   	push   cs
    23a2:	57                   	push   di
    23a3:	8d be 00 ff          	lea    di,[bp-0x100]
    23a7:	16                   	push   ss
    23a8:	57                   	push   di
    23a9:	68 ff 00             	push   0xff
    23ac:	9a e7 17 c7 23       	call   0x23c7:0x17e7
    23b1:	eb 05                	jmp    0x23b8
    23b3:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    23b8:	8d be fc fd          	lea    di,[bp-0x204]
    23bc:	16                   	push   ss
    23bd:	57                   	push   di
    23be:	8d be 00 ff          	lea    di,[bp-0x100]
    23c2:	16                   	push   ss
    23c3:	57                   	push   di
    23c4:	9a cd 17 d1 23       	call   0x23d1:0x17cd
    23c9:	bf 66 23             	mov    di,0x2366
    23cc:	0e                   	push   cs
    23cd:	57                   	push   di
    23ce:	9a 4c 18 df 23       	call   0x23df:0x184c
    23d3:	8d be 00 ff          	lea    di,[bp-0x100]
    23d7:	16                   	push   ss
    23d8:	57                   	push   di
    23d9:	68 ff 00             	push   0xff
    23dc:	9a e7 17 ee 23       	call   0x23ee:0x17e7
    23e1:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    23e4:	06                   	push   es
    23e5:	57                   	push   di
    23e6:	bf 6a 23             	mov    di,0x236a
    23e9:	0e                   	push   cs
    23ea:	57                   	push   di
    23eb:	9a be 18 01 24       	call   0x2401:0x18be
    23f0:	75 71                	jne    0x2463
    23f2:	8d be f4 fc          	lea    di,[bp-0x30c]
    23f6:	16                   	push   ss
    23f7:	57                   	push   di
    23f8:	8d be 00 ff          	lea    di,[bp-0x100]
    23fc:	16                   	push   ss
    23fd:	57                   	push   di
    23fe:	9a cd 17 50 24       	call   0x2450:0x17cd
    2403:	8d be f4 fd          	lea    di,[bp-0x20c]
    2407:	16                   	push   ss
    2408:	57                   	push   di
    2409:	bf 6a 23             	mov    di,0x236a
    240c:	0e                   	push   cs
    240d:	57                   	push   di
    240e:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2411:	06                   	push   es
    2412:	57                   	push   di
    2413:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2416:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    241a:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    241f:	06                   	push   es
    2420:	57                   	push   di
    2421:	9a 9b 3b a1 24       	call   0x24a1:0x3b9b
    2426:	89 c7                	mov    di,ax
    2428:	8e c2                	mov    es,dx
    242a:	06                   	push   es
    242b:	57                   	push   di
    242c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    242f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    2433:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    2437:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    243b:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    2440:	8d be f4 fe          	lea    di,[bp-0x10c]
    2444:	16                   	push   ss
    2445:	57                   	push   di
    2446:	6a 00                	push   0x0
    2448:	9a 34 10 f4 25       	call   0x25f4:0x1034
    244d:	9a 4c 18 5e 24       	call   0x245e:0x184c
    2452:	8d be 00 ff          	lea    di,[bp-0x100]
    2456:	16                   	push   ss
    2457:	57                   	push   di
    2458:	68 ff 00             	push   0xff
    245b:	9a e7 17 72 24       	call   0x2472:0x17e7
    2460:	e9 85 00             	jmp    0x24e8
    2463:	8d be ea fc          	lea    di,[bp-0x316]
    2467:	16                   	push   ss
    2468:	57                   	push   di
    2469:	8d be 00 ff          	lea    di,[bp-0x100]
    246d:	16                   	push   ss
    246e:	57                   	push   di
    246f:	9a cd 17 d8 24       	call   0x24d8:0x17cd
    2474:	8d be ea fd          	lea    di,[bp-0x216]
    2478:	16                   	push   ss
    2479:	57                   	push   di
    247a:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    247d:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2481:	26 ff b5 a3 03       	push   WORD PTR es:[di+0x3a3]
    2486:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2489:	06                   	push   es
    248a:	57                   	push   di
    248b:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    248e:	06                   	push   es
    248f:	57                   	push   di
    2490:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2493:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2497:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    249c:	06                   	push   es
    249d:	57                   	push   di
    249e:	9a 9b 3b cd 25       	call   0x25cd:0x3b9b
    24a3:	89 c7                	mov    di,ax
    24a5:	8e c2                	mov    es,dx
    24a7:	06                   	push   es
    24a8:	57                   	push   di
    24a9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24ac:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    24b0:	9b db be f2 fe       	fstp   TBYTE PTR [bp-0x10e]
    24b5:	8d 86 f2 fe          	lea    ax,[bp-0x10e]
    24b9:	8c d2                	mov    dx,ss
    24bb:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    24bf:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    24c3:	c6 86 ee fe 03       	mov    BYTE PTR [bp-0x112],0x3
    24c8:	8d be ea fe          	lea    di,[bp-0x116]
    24cc:	16                   	push   ss
    24cd:	57                   	push   di
    24ce:	6a 00                	push   0x0
    24d0:	9a 93 30 7c 26       	call   0x267c:0x3093
    24d5:	9a 4c 18 e6 24       	call   0x24e6:0x184c
    24da:	8d be 00 ff          	lea    di,[bp-0x100]
    24de:	16                   	push   ss
    24df:	57                   	push   di
    24e0:	68 ff 00             	push   0xff
    24e3:	9a e7 17 1f 25       	call   0x251f:0x17e7
    24e8:	ff 76 14             	push   WORD PTR [bp+0x14]
    24eb:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    24ee:	26 ff 35             	push   WORD PTR es:[di]
    24f1:	8d be 00 ff          	lea    di,[bp-0x100]
    24f5:	16                   	push   ss
    24f6:	57                   	push   di
    24f7:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    24fb:	06                   	push   es
    24fc:	57                   	push   di
    24fd:	9a 08 9b a9 26       	call   0x26a9:0x9b08
    2502:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2505:	26 ff 05             	inc    WORD PTR es:[di]
    2508:	c9                   	leave
    2509:	ca 10 00             	retf   0x10
    250c:	02 23                	add    ah,BYTE PTR [bp+di]
    250e:	56                   	push   si
    250f:	03 23                	add    sp,WORD PTR [bp+di]
    2511:	41                   	inc    cx
    2512:	64 02 25             	add    ah,BYTE PTR fs:[di]
    2515:	64 55                	fs push bp
    2517:	89 e5                	mov    bp,sp
    2519:	b8 16 03             	mov    ax,0x316
    251c:	9a 44 04 58 25       	call   0x2558:0x444
    2521:	81 ec 16 03          	sub    sp,0x316
    2525:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2528:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    252c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    252f:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    2533:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    2537:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    253a:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    253d:	99                   	cwd
    253e:	36 f7 7d f8          	idiv   WORD PTR ss:[di-0x8]
    2542:	92                   	xchg   dx,ax
    2543:	09 c0                	or     ax,ax
    2545:	75 15                	jne    0x255c
    2547:	bf 0c 25             	mov    di,0x250c
    254a:	0e                   	push   cs
    254b:	57                   	push   di
    254c:	8d be 00 ff          	lea    di,[bp-0x100]
    2550:	16                   	push   ss
    2551:	57                   	push   di
    2552:	68 ff 00             	push   0xff
    2555:	9a e7 17 70 25       	call   0x2570:0x17e7
    255a:	eb 05                	jmp    0x2561
    255c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2561:	8d be fc fd          	lea    di,[bp-0x204]
    2565:	16                   	push   ss
    2566:	57                   	push   di
    2567:	8d be 00 ff          	lea    di,[bp-0x100]
    256b:	16                   	push   ss
    256c:	57                   	push   di
    256d:	9a cd 17 7a 25       	call   0x257a:0x17cd
    2572:	bf 0f 25             	mov    di,0x250f
    2575:	0e                   	push   cs
    2576:	57                   	push   di
    2577:	9a 4c 18 88 25       	call   0x2588:0x184c
    257c:	8d be 00 ff          	lea    di,[bp-0x100]
    2580:	16                   	push   ss
    2581:	57                   	push   di
    2582:	68 ff 00             	push   0xff
    2585:	9a e7 17 97 25       	call   0x2597:0x17e7
    258a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    258d:	06                   	push   es
    258e:	57                   	push   di
    258f:	bf 13 25             	mov    di,0x2513
    2592:	0e                   	push   cs
    2593:	57                   	push   di
    2594:	9a be 18 aa 25       	call   0x25aa:0x18be
    2599:	75 71                	jne    0x260c
    259b:	8d be f4 fc          	lea    di,[bp-0x30c]
    259f:	16                   	push   ss
    25a0:	57                   	push   di
    25a1:	8d be 00 ff          	lea    di,[bp-0x100]
    25a5:	16                   	push   ss
    25a6:	57                   	push   di
    25a7:	9a cd 17 f9 25       	call   0x25f9:0x17cd
    25ac:	8d be f4 fd          	lea    di,[bp-0x20c]
    25b0:	16                   	push   ss
    25b1:	57                   	push   di
    25b2:	bf 13 25             	mov    di,0x2513
    25b5:	0e                   	push   cs
    25b6:	57                   	push   di
    25b7:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    25ba:	06                   	push   es
    25bb:	57                   	push   di
    25bc:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    25bf:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    25c3:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    25c8:	06                   	push   es
    25c9:	57                   	push   di
    25ca:	9a 9b 3b 4a 26       	call   0x264a:0x3b9b
    25cf:	89 c7                	mov    di,ax
    25d1:	8e c2                	mov    es,dx
    25d3:	06                   	push   es
    25d4:	57                   	push   di
    25d5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    25d8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    25dc:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    25e0:	89 96 f6 fe          	mov    WORD PTR [bp-0x10a],dx
    25e4:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    25e9:	8d be f4 fe          	lea    di,[bp-0x10c]
    25ed:	16                   	push   ss
    25ee:	57                   	push   di
    25ef:	6a 00                	push   0x0
    25f1:	9a 34 10 88 2a       	call   0x2a88:0x1034
    25f6:	9a 4c 18 07 26       	call   0x2607:0x184c
    25fb:	8d be 00 ff          	lea    di,[bp-0x100]
    25ff:	16                   	push   ss
    2600:	57                   	push   di
    2601:	68 ff 00             	push   0xff
    2604:	9a e7 17 1b 26       	call   0x261b:0x17e7
    2609:	e9 85 00             	jmp    0x2691
    260c:	8d be ea fc          	lea    di,[bp-0x316]
    2610:	16                   	push   ss
    2611:	57                   	push   di
    2612:	8d be 00 ff          	lea    di,[bp-0x100]
    2616:	16                   	push   ss
    2617:	57                   	push   di
    2618:	9a cd 17 81 26       	call   0x2681:0x17cd
    261d:	8d be ea fd          	lea    di,[bp-0x216]
    2621:	16                   	push   ss
    2622:	57                   	push   di
    2623:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2626:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    262a:	26 ff b5 a3 03       	push   WORD PTR es:[di+0x3a3]
    262f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2632:	06                   	push   es
    2633:	57                   	push   di
    2634:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2637:	06                   	push   es
    2638:	57                   	push   di
    2639:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    263c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2640:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2645:	06                   	push   es
    2646:	57                   	push   di
    2647:	9a 9b 3b 84 28       	call   0x2884:0x3b9b
    264c:	89 c7                	mov    di,ax
    264e:	8e c2                	mov    es,dx
    2650:	06                   	push   es
    2651:	57                   	push   di
    2652:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2655:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2659:	9b db be f2 fe       	fstp   TBYTE PTR [bp-0x10e]
    265e:	8d 86 f2 fe          	lea    ax,[bp-0x10e]
    2662:	8c d2                	mov    dx,ss
    2664:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2668:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    266c:	c6 86 ee fe 03       	mov    BYTE PTR [bp-0x112],0x3
    2671:	8d be ea fe          	lea    di,[bp-0x116]
    2675:	16                   	push   ss
    2676:	57                   	push   di
    2677:	6a 00                	push   0x0
    2679:	9a 93 30 99 4b       	call   0x4b99:0x3093
    267e:	9a 4c 18 8f 26       	call   0x268f:0x184c
    2683:	8d be 00 ff          	lea    di,[bp-0x100]
    2687:	16                   	push   ss
    2688:	57                   	push   di
    2689:	68 ff 00             	push   0xff
    268c:	9a e7 17 61 28       	call   0x2861:0x17e7
    2691:	ff 76 14             	push   WORD PTR [bp+0x14]
    2694:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2697:	26 ff 35             	push   WORD PTR es:[di]
    269a:	8d be 00 ff          	lea    di,[bp-0x100]
    269e:	16                   	push   ss
    269f:	57                   	push   di
    26a0:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    26a4:	06                   	push   es
    26a5:	57                   	push   di
    26a6:	9a 08 9b 9a 2a       	call   0x2a9a:0x9b08
    26ab:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    26ae:	26 ff 05             	inc    WORD PTR es:[di]
    26b1:	c9                   	leave
    26b2:	ca 10 00             	retf   0x10
    26b5:	03 30                	add    si,WORD PTR [bx+si]
    26b7:	2c 30                	sub    al,0x30
    26b9:	03 23                	add    sp,WORD PTR [bp+di]
    26bb:	41                   	inc    cx
    26bc:	63 01                	arpl   WORD PTR [bx+di],ax
    26be:	20 02                	and    BYTE PTR [bp+si],al
    26c0:	25 67 11             	and    ax,0x1167
    26c3:	4d                   	dec    bp
    26c4:	61                   	popa
    26c5:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    26c8:	6e                   	outs   dx,BYTE PTR ds:[si]
    26c9:	65 73 41             	gs jae 0x270d
    26cc:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    26d2:	65 73 06             	gs jae 0x26db
    26d5:	25 31 30             	and    ax,0x3031
    26d8:	2e 32 66 09          	xor    ah,BYTE PTR cs:[bp+0x9]
    26dc:	43                   	inc    bx
    26dd:	61                   	popa
    26de:	70 50                	jo     0x2730
    26e0:	72 6f                	jb     0x2751
    26e2:	64 75 63             	fs jne 0x2748
    26e5:	0b 55 74             	or     dx,WORD PTR [di+0x74]
    26e8:	69 6c 69 73 61       	imul   bp,WORD PTR [si+0x69],0x6173
    26ed:	74 69                	je     0x2758
    26ef:	6f                   	outs   dx,WORD PTR ds:[si]
    26f0:	6e                   	outs   dx,BYTE PTR ds:[si]
    26f1:	0f 43 6f 75          	cmovae bp,WORD PTR [bx+0x75]
    26f5:	74 50                	je     0x2747
    26f7:	72 6f                	jb     0x2768
    26f9:	64 75 63             	fs jne 0x275f
    26fc:	74 69                	je     0x2767
    26fe:	6f                   	outs   dx,WORD PTR ds:[si]
    26ff:	6e                   	outs   dx,BYTE PTR ds:[si]
    2700:	55                   	push   bp
    2701:	0b 48 65             	or     cx,WORD PTR [bx+si+0x65]
    2704:	75 72                	jne    0x2778
    2706:	65 73 53             	gs jae 0x275c
    2709:	75 70                	jne    0x277b
    270b:	50                   	push   ax
    270c:	63 10                	arpl   WORD PTR [bx+si],dx
    270e:	50                   	push   ax
    270f:	72 6f                	jb     0x2780
    2711:	64 75 63             	fs jne 0x2777
    2714:	74 69                	je     0x277f
    2716:	6f                   	outs   dx,WORD PTR ds:[si]
    2717:	6e                   	outs   dx,BYTE PTR ds:[si]
    2718:	52                   	push   dx
    2719:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    271c:	6c                   	ins    BYTE PTR es:[di],dx
    271d:	65 04 50             	gs add al,0x50
    2720:	72 69                	jb     0x278b
    2722:	78 0e                	js     0x2732
    2724:	50                   	push   ax
    2725:	72 69                	jb     0x2790
    2727:	78 53                	js     0x277c
    2729:	75 72                	jne    0x279d
    272b:	4d                   	dec    bp
    272c:	6f                   	outs   dx,WORD PTR ds:[si]
    272d:	79 65                	jns    0x2794
    272f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2730:	6e                   	outs   dx,BYTE PTR ds:[si]
    2731:	65 09 50 75          	or     WORD PTR gs:[bx+si+0x75],dx
    2735:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
    2738:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    273b:	65 0e                	gs push cs
    273d:	50                   	push   ax
    273e:	75 62                	jne    0x27a2
    2740:	43                   	inc    bx
    2741:	41                   	inc    cx
    2742:	54                   	push   sp
    2743:	68 65 6f             	push   0x6f65
    2746:	72 69                	jb     0x27b1
    2748:	71 75                	jno    0x27bf
    274a:	65 09 50 75          	or     WORD PTR gs:[bx+si+0x75],dx
    274e:	62 43 41             	bound  ax,DWORD PTR [bp+di+0x41]
    2751:	52                   	push   dx
    2752:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    2755:	0d 50 75             	or     ax,0x7550
    2758:	62 53 75             	bound  dx,DWORD PTR [bp+di+0x75]
    275b:	72 4d                	jb     0x27aa
    275d:	6f                   	outs   dx,WORD PTR ds:[si]
    275e:	79 65                	jns    0x27c5
    2760:	6e                   	outs   dx,BYTE PTR ds:[si]
    2761:	6e                   	outs   dx,BYTE PTR ds:[si]
    2762:	65 10 56 65          	adc    BYTE PTR gs:[bp+0x65],dl
    2766:	6e                   	outs   dx,BYTE PTR ds:[si]
    2767:	64 65 75 72          	fs gs jne 0x27dd
    276b:	73 41                	jae    0x27ae
    276d:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    2773:	73 13                	jae    0x2788
    2775:	56                   	push   si
    2776:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2778:	64 65 75 72          	fs gs jne 0x27ee
    277c:	50                   	push   ax
    277d:	72 6f                	jb     0x27ee
    277f:	64 75 63             	fs jne 0x27e5
    2782:	74 69                	je     0x27ed
    2784:	76 69                	jbe    0x27ef
    2786:	74 65                	je     0x27ed
    2788:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    278b:	6e                   	outs   dx,BYTE PTR ds:[si]
    278c:	64 65 75 72          	fs gs jne 0x2802
    2790:	53                   	push   bx
    2791:	75 72                	jne    0x2805
    2793:	4d                   	dec    bp
    2794:	6f                   	outs   dx,WORD PTR ds:[si]
    2795:	79 65                	jns    0x27fc
    2797:	6e                   	outs   dx,BYTE PTR ds:[si]
    2798:	6e                   	outs   dx,BYTE PTR ds:[si]
    2799:	65 11 44 75          	adc    WORD PTR gs:[si+0x75],ax
    279d:	72 65                	jb     0x2804
    279f:	65 43                	gs inc bx
    27a1:	72 65                	jb     0x2808
    27a3:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    27a9:	65 6e                	outs   dx,BYTE PTR gs:[si]
    27ab:	74 10                	je     0x27bd
    27ad:	43                   	inc    bx
    27ae:	72 65                	jb     0x2815
    27b0:	64 69 74 53 75 72    	imul   si,WORD PTR fs:[si+0x53],0x7275
    27b6:	4d                   	dec    bp
    27b7:	6f                   	outs   dx,WORD PTR ds:[si]
    27b8:	79 65                	jns    0x281f
    27ba:	6e                   	outs   dx,BYTE PTR ds:[si]
    27bb:	6e                   	outs   dx,BYTE PTR ds:[si]
    27bc:	65 06                	gs push es
    27be:	25 31 30             	and    ax,0x3031
    27c1:	2e 33 66 0c          	xor    sp,WORD PTR cs:[bp+0xc]
    27c5:	45                   	inc    bp
    27c6:	66 66 65 74 50       	data32 data32 gs je 0x281b
    27cb:	72 69                	jb     0x2836
    27cd:	78 31                	js     0x2800
    27cf:	30 30                	xor    BYTE PTR [bx+si],dh
    27d1:	0b 45 66             	or     ax,WORD PTR [di+0x66]
    27d4:	66 65 74 50          	data32 gs je 0x2828
    27d8:	75 62                	jne    0x283c
    27da:	31 30                	xor    WORD PTR [bx+si],si
    27dc:	30 0e 45 66          	xor    BYTE PTR ds:0x6645,cl
    27e0:	66 65 74 43          	data32 gs je 0x2827
    27e4:	72 65                	jb     0x284b
    27e6:	64 69 74 31 30 30    	imul   si,WORD PTR fs:[si+0x31],0x3030
    27ec:	0f 45 66 66          	cmovne sp,WORD PTR [bp+0x66]
    27f0:	65 74 51             	gs je  0x2844
    27f3:	75 61                	jne    0x2856
    27f5:	6c                   	ins    BYTE PTR es:[di],dx
    27f6:	69 74 65 31 30       	imul   si,WORD PTR [si+0x65],0x3031
    27fb:	30 0e 45 66          	xor    BYTE PTR ds:0x6645,cl
    27ff:	66 65 74 47          	data32 gs je 0x284a
    2803:	6c                   	ins    BYTE PTR es:[di],dx
    2804:	6f                   	outs   dx,WORD PTR ds:[si]
    2805:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
    2808:	31 30                	xor    WORD PTR [bx+si],si
    280a:	30 06 56 65          	xor    BYTE PTR ds:0x6556,al
    280e:	6e                   	outs   dx,BYTE PTR ds:[si]
    280f:	74 65                	je     0x2876
    2811:	73 0a                	jae    0x281d
    2813:	50                   	push   ax
    2814:	61                   	popa
    2815:	72 74                	jb     0x288b
    2817:	4d                   	dec    bp
    2818:	61                   	popa
    2819:	72 63                	jb     0x287e
    281b:	68 65 14             	push   0x1465
    281e:	44                   	inc    sp
    281f:	65 6d                	gs ins WORD PTR es:[di],dx
    2821:	61                   	popa
    2822:	6e                   	outs   dx,BYTE PTR ds:[si]
    2823:	64 65 4e             	fs gs dec si
    2826:	6f                   	outs   dx,WORD PTR ds:[si]
    2827:	6e                   	outs   dx,BYTE PTR ds:[si]
    2828:	53                   	push   bx
    2829:	61                   	popa
    282a:	74 69                	je     0x2895
    282c:	73 66                	jae    0x2894
    282e:	61                   	popa
    282f:	69 74 65 0c 56       	imul   si,WORD PTR [si+0x65],0x560c
    2834:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2836:	74 65                	je     0x289d
    2838:	73 50                	jae    0x288a
    283a:	72 69                	jb     0x28a5
    283c:	73 65                	jae    0x28a3
    283e:	73 02                	jae    0x2842
    2840:	43                   	inc    bx
    2841:	41                   	inc    cx
    2842:	0a 4d 61             	or     cl,BYTE PTR [di+0x61]
    2845:	72 67                	jb     0x28ae
    2847:	65 53                	gs push bx
    2849:	75 72                	jne    0x28bd
    284b:	43                   	inc    bx
    284c:	64 0a 4d 61          	or     cl,BYTE PTR fs:[di+0x61]
    2850:	72 67                	jb     0x28b9
    2852:	65 53                	gs push bx
    2854:	75 72                	jne    0x28c8
    2856:	43                   	inc    bx
    2857:	41                   	inc    cx
    2858:	55                   	push   bp
    2859:	89 e5                	mov    bp,sp
    285b:	b8 08 03             	mov    ax,0x308
    285e:	9a 44 04 44 2a       	call   0x2a44:0x444
    2863:	81 ec 08 03          	sub    sp,0x308
    2867:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    286a:	06                   	push   es
    286b:	57                   	push   di
    286c:	9a 1f 16 30 2a       	call   0x2a30:0x161f
    2871:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2874:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    2879:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    287c:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    287f:	06                   	push   es
    2880:	57                   	push   di
    2881:	9a d2 31 a6 28       	call   0x28a6:0x31d2
    2886:	6a 01                	push   0x1
    2888:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    288b:	06                   	push   es
    288c:	57                   	push   di
    288d:	9a fb 2f 9c 28       	call   0x289c:0x2ffb
    2892:	6a 00                	push   0x0
    2894:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2897:	06                   	push   es
    2898:	57                   	push   di
    2899:	9a d2 2e c7 28       	call   0x28c7:0x2ed2
    289e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    28a1:	06                   	push   es
    28a2:	57                   	push   di
    28a3:	9a bf 31 bb 28       	call   0x28bb:0x31bf
    28a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ab:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    28b0:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    28b3:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    28b6:	06                   	push   es
    28b7:	57                   	push   di
    28b8:	9a d2 31 dd 28       	call   0x28dd:0x31d2
    28bd:	6a 01                	push   0x1
    28bf:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    28c2:	06                   	push   es
    28c3:	57                   	push   di
    28c4:	9a fb 2f d3 28       	call   0x28d3:0x2ffb
    28c9:	6a 00                	push   0x0
    28cb:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    28ce:	06                   	push   es
    28cf:	57                   	push   di
    28d0:	9a d2 2e fe 28       	call   0x28fe:0x2ed2
    28d5:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    28d8:	06                   	push   es
    28d9:	57                   	push   di
    28da:	9a bf 31 f2 28       	call   0x28f2:0x31bf
    28df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28e2:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    28e7:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    28ea:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    28ed:	06                   	push   es
    28ee:	57                   	push   di
    28ef:	9a d2 31 14 29       	call   0x2914:0x31d2
    28f4:	6a 01                	push   0x1
    28f6:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    28f9:	06                   	push   es
    28fa:	57                   	push   di
    28fb:	9a fb 2f 0a 29       	call   0x290a:0x2ffb
    2900:	6a 00                	push   0x0
    2902:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2905:	06                   	push   es
    2906:	57                   	push   di
    2907:	9a d2 2e 35 29       	call   0x2935:0x2ed2
    290c:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    290f:	06                   	push   es
    2910:	57                   	push   di
    2911:	9a bf 31 29 29       	call   0x2929:0x31bf
    2916:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2919:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    291e:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    2921:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    2924:	06                   	push   es
    2925:	57                   	push   di
    2926:	9a d2 31 4b 29       	call   0x294b:0x31d2
    292b:	6a 01                	push   0x1
    292d:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2930:	06                   	push   es
    2931:	57                   	push   di
    2932:	9a fb 2f 41 29       	call   0x2941:0x2ffb
    2937:	6a 00                	push   0x0
    2939:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    293c:	06                   	push   es
    293d:	57                   	push   di
    293e:	9a d2 2e 6c 29       	call   0x296c:0x2ed2
    2943:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2946:	06                   	push   es
    2947:	57                   	push   di
    2948:	9a bf 31 60 29       	call   0x2960:0x31bf
    294d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2950:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    2955:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    2958:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    295b:	06                   	push   es
    295c:	57                   	push   di
    295d:	9a d2 31 82 29       	call   0x2982:0x31d2
    2962:	6a 01                	push   0x1
    2964:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2967:	06                   	push   es
    2968:	57                   	push   di
    2969:	9a fb 2f 78 29       	call   0x2978:0x2ffb
    296e:	6a 00                	push   0x0
    2970:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2973:	06                   	push   es
    2974:	57                   	push   di
    2975:	9a d2 2e a3 29       	call   0x29a3:0x2ed2
    297a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    297d:	06                   	push   es
    297e:	57                   	push   di
    297f:	9a bf 31 97 29       	call   0x2997:0x31bf
    2984:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2987:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    298c:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    298f:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    2992:	06                   	push   es
    2993:	57                   	push   di
    2994:	9a d2 31 b9 29       	call   0x29b9:0x31d2
    2999:	6a 01                	push   0x1
    299b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    299e:	06                   	push   es
    299f:	57                   	push   di
    29a0:	9a fb 2f af 29       	call   0x29af:0x2ffb
    29a5:	6a 00                	push   0x0
    29a7:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    29aa:	06                   	push   es
    29ab:	57                   	push   di
    29ac:	9a d2 2e da 29       	call   0x29da:0x2ed2
    29b1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    29b4:	06                   	push   es
    29b5:	57                   	push   di
    29b6:	9a bf 31 ce 29       	call   0x29ce:0x31bf
    29bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29be:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    29c3:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    29c6:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    29c9:	06                   	push   es
    29ca:	57                   	push   di
    29cb:	9a d2 31 f0 29       	call   0x29f0:0x31d2
    29d0:	6a 01                	push   0x1
    29d2:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    29d5:	06                   	push   es
    29d6:	57                   	push   di
    29d7:	9a fb 2f e6 29       	call   0x29e6:0x2ffb
    29dc:	6a 00                	push   0x0
    29de:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    29e1:	06                   	push   es
    29e2:	57                   	push   di
    29e3:	9a d2 2e 22 2a       	call   0x2a22:0x2ed2
    29e8:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    29eb:	06                   	push   es
    29ec:	57                   	push   di
    29ed:	9a bf 31 64 33       	call   0x3364:0x31bf
    29f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29f5:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    29fa:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    29fd:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    2a00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a03:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    2a08:	99                   	cwd
    2a09:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2a0c:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    2a0f:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    2a13:	8d 7e ec             	lea    di,[bp-0x14]
    2a16:	16                   	push   ss
    2a17:	57                   	push   di
    2a18:	6a 00                	push   0x0
    2a1a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2a1d:	06                   	push   es
    2a1e:	57                   	push   di
    2a1f:	9a 95 28 0e 2b       	call   0x2b0e:0x2895
    2a24:	08 c0                	or     al,al
    2a26:	75 0a                	jne    0x2a32
    2a28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a2b:	06                   	push   es
    2a2c:	57                   	push   di
    2a2d:	9a 19 0c 1c 2b       	call   0x2b1c:0xc19
    2a32:	6a 00                	push   0x0
    2a34:	6a 00                	push   0x0
    2a36:	8d be f8 fd          	lea    di,[bp-0x208]
    2a3a:	16                   	push   ss
    2a3b:	57                   	push   di
    2a3c:	bf b9 26             	mov    di,0x26b9
    2a3f:	0e                   	push   cs
    2a40:	57                   	push   di
    2a41:	9a cd 17 68 2a       	call   0x2a68:0x17cd
    2a46:	8d be f8 fe          	lea    di,[bp-0x108]
    2a4a:	16                   	push   ss
    2a4b:	57                   	push   di
    2a4c:	bf b5 26             	mov    di,0x26b5
    2a4f:	0e                   	push   cs
    2a50:	57                   	push   di
    2a51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a54:	26 c4 bd 94 02       	les    di,DWORD PTR es:[di+0x294]
    2a59:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2a5e:	06                   	push   es
    2a5f:	57                   	push   di
    2a60:	9a 19 15 ff ff       	call   0xffff:0x1519
    2a65:	9a 4c 18 72 2a       	call   0x2a72:0x184c
    2a6a:	bf bd 26             	mov    di,0x26bd
    2a6d:	0e                   	push   cs
    2a6e:	57                   	push   di
    2a6f:	9a 4c 18 8d 2a       	call   0x2a8d:0x184c
    2a74:	8d be f8 fc          	lea    di,[bp-0x308]
    2a78:	16                   	push   ss
    2a79:	57                   	push   di
    2a7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a7d:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    2a82:	99                   	cwd
    2a83:	52                   	push   dx
    2a84:	50                   	push   ax
    2a85:	9a a9 08 83 3f       	call   0x3f83:0x8a9
    2a8a:	9a 4c 18 e4 2a       	call   0x2ae4:0x184c
    2a8f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2a92:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a95:	06                   	push   es
    2a96:	57                   	push   di
    2a97:	9a 08 9b 27 35       	call   0x3527:0x9b08
    2a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a9f:	26 8b 85 a5 04       	mov    ax,WORD PTR es:[di+0x4a5]
    2aa4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2aa7:	a1 4e 01             	mov    ax,ds:0x14e
    2aaa:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2aad:	b8 01 00             	mov    ax,0x1
    2ab0:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2ab3:	7e 03                	jle    0x2ab8
    2ab5:	e9 8b 08             	jmp    0x3343
    2ab8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2abb:	eb 03                	jmp    0x2ac0
    2abd:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2ac0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ac3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2ac6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac9:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2ace:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    2ad1:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    2ad4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad7:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    2adc:	2d 01 00             	sub    ax,0x1
    2adf:	71 05                	jno    0x2ae6
    2ae1:	9a 3e 04 de 2b       	call   0x2bde:0x43e
    2ae6:	99                   	cwd
    2ae7:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2aea:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    2aed:	c6 46 e2 00          	mov    BYTE PTR [bp-0x1e],0x0
    2af1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2af4:	99                   	cwd
    2af5:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    2af8:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    2afb:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    2aff:	8d 7e de             	lea    di,[bp-0x22]
    2b02:	16                   	push   ss
    2b03:	57                   	push   di
    2b04:	6a 01                	push   0x1
    2b06:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    2b09:	06                   	push   es
    2b0a:	57                   	push   di
    2b0b:	9a 95 28 62 2b       	call   0x2b62:0x2895
    2b10:	08 c0                	or     al,al
    2b12:	75 0a                	jne    0x2b1e
    2b14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b17:	06                   	push   es
    2b18:	57                   	push   di
    2b19:	9a 19 0c 70 2b       	call   0x2b70:0xc19
    2b1e:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2b21:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2b24:	b8 01 00             	mov    ax,0x1
    2b27:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    2b2a:	7e 03                	jle    0x2b2f
    2b2c:	e9 09 08             	jmp    0x3338
    2b2f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2b32:	eb 03                	jmp    0x2b37
    2b34:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2b37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b3a:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    2b3f:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    2b42:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    2b45:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2b48:	99                   	cwd
    2b49:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2b4c:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    2b4f:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    2b53:	8d 7e e4             	lea    di,[bp-0x1c]
    2b56:	16                   	push   ss
    2b57:	57                   	push   di
    2b58:	6a 00                	push   0x0
    2b5a:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    2b5d:	06                   	push   es
    2b5e:	57                   	push   di
    2b5f:	9a 95 28 b0 2b       	call   0x2bb0:0x2895
    2b64:	08 c0                	or     al,al
    2b66:	75 0a                	jne    0x2b72
    2b68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b6b:	06                   	push   es
    2b6c:	57                   	push   di
    2b6d:	9a 19 0c be 2b       	call   0x2bbe:0xc19
    2b72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b75:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    2b7a:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    2b7d:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    2b80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b83:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    2b88:	99                   	cwd
    2b89:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2b8c:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2b8f:	c6 46 e0 00          	mov    BYTE PTR [bp-0x20],0x0
    2b93:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2b96:	99                   	cwd
    2b97:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2b9a:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    2b9d:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    2ba1:	8d 7e dc             	lea    di,[bp-0x24]
    2ba4:	16                   	push   ss
    2ba5:	57                   	push   di
    2ba6:	6a 01                	push   0x1
    2ba8:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    2bab:	06                   	push   es
    2bac:	57                   	push   di
    2bad:	9a 95 28 16 2c       	call   0x2c16:0x2895
    2bb2:	08 c0                	or     al,al
    2bb4:	75 0a                	jne    0x2bc0
    2bb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bb9:	06                   	push   es
    2bba:	57                   	push   di
    2bbb:	9a 19 0c 24 2c       	call   0x2c24:0xc19
    2bc0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bc3:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    2bc8:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    2bcb:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    2bce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bd1:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    2bd6:	2d 01 00             	sub    ax,0x1
    2bd9:	71 05                	jno    0x2be0
    2bdb:	9a 3e 04 f1 2c       	call   0x2cf1:0x43e
    2be0:	99                   	cwd
    2be1:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    2be4:	89 56 d6             	mov    WORD PTR [bp-0x2a],dx
    2be7:	c6 46 d8 00          	mov    BYTE PTR [bp-0x28],0x0
    2beb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2bee:	99                   	cwd
    2bef:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2bf2:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2bf5:	c6 46 e0 00          	mov    BYTE PTR [bp-0x20],0x0
    2bf9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2bfc:	99                   	cwd
    2bfd:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2c00:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    2c03:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    2c07:	8d 7e d4             	lea    di,[bp-0x2c]
    2c0a:	16                   	push   ss
    2c0b:	57                   	push   di
    2c0c:	6a 02                	push   0x2
    2c0e:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    2c11:	06                   	push   es
    2c12:	57                   	push   di
    2c13:	9a 95 28 72 2c       	call   0x2c72:0x2895
    2c18:	08 c0                	or     al,al
    2c1a:	75 0a                	jne    0x2c26
    2c1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c1f:	06                   	push   es
    2c20:	57                   	push   di
    2c21:	9a 19 0c 80 2c       	call   0x2c80:0xc19
    2c26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c29:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    2c2e:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    2c31:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    2c34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c37:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    2c3c:	99                   	cwd
    2c3d:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    2c40:	89 56 d6             	mov    WORD PTR [bp-0x2a],dx
    2c43:	c6 46 d8 00          	mov    BYTE PTR [bp-0x28],0x0
    2c47:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2c4a:	99                   	cwd
    2c4b:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2c4e:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2c51:	c6 46 e0 00          	mov    BYTE PTR [bp-0x20],0x0
    2c55:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2c58:	99                   	cwd
    2c59:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2c5c:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    2c5f:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    2c63:	8d 7e d4             	lea    di,[bp-0x2c]
    2c66:	16                   	push   ss
    2c67:	57                   	push   di
    2c68:	6a 02                	push   0x2
    2c6a:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    2c6d:	06                   	push   es
    2c6e:	57                   	push   di
    2c6f:	9a 95 28 ce 2c       	call   0x2cce:0x2895
    2c74:	08 c0                	or     al,al
    2c76:	75 0a                	jne    0x2c82
    2c78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c7b:	06                   	push   es
    2c7c:	57                   	push   di
    2c7d:	9a 19 0c dc 2c       	call   0x2cdc:0xc19
    2c82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c85:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2c8a:	89 7e ec             	mov    WORD PTR [bp-0x14],di
    2c8d:	8c 46 ee             	mov    WORD PTR [bp-0x12],es
    2c90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c93:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    2c98:	99                   	cwd
    2c99:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    2c9c:	89 56 d6             	mov    WORD PTR [bp-0x2a],dx
    2c9f:	c6 46 d8 00          	mov    BYTE PTR [bp-0x28],0x0
    2ca3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ca6:	99                   	cwd
    2ca7:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2caa:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2cad:	c6 46 e0 00          	mov    BYTE PTR [bp-0x20],0x0
    2cb1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2cb4:	99                   	cwd
    2cb5:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2cb8:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    2cbb:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    2cbf:	8d 7e d4             	lea    di,[bp-0x2c]
    2cc2:	16                   	push   ss
    2cc3:	57                   	push   di
    2cc4:	6a 02                	push   0x2
    2cc6:	c4 7e ec             	les    di,DWORD PTR [bp-0x14]
    2cc9:	06                   	push   es
    2cca:	57                   	push   di
    2ccb:	9a 95 28 f0 4a       	call   0x4af0:0x2895
    2cd0:	08 c0                	or     al,al
    2cd2:	75 0a                	jne    0x2cde
    2cd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cd7:	06                   	push   es
    2cd8:	57                   	push   di
    2cd9:	9a 19 0c 1b 2d       	call   0x2d1b:0xc19
    2cde:	c7 46 fa 02 00       	mov    WORD PTR [bp-0x6],0x2
    2ce3:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2ce6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ce9:	2d 01 00             	sub    ax,0x1
    2cec:	71 05                	jno    0x2cf3
    2cee:	9a 3e 04 fb 2c       	call   0x2cfb:0x43e
    2cf3:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2cf6:	71 05                	jno    0x2cfd
    2cf8:	9a 3e 04 05 2d       	call   0x2d05:0x43e
    2cfd:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2d00:	71 05                	jno    0x2d07
    2d02:	9a 3e 04 28 2d       	call   0x2d28:0x43e
    2d07:	50                   	push   ax
    2d08:	8d 7e fa             	lea    di,[bp-0x6]
    2d0b:	16                   	push   ss
    2d0c:	57                   	push   di
    2d0d:	bf bf 26             	mov    di,0x26bf
    2d10:	0e                   	push   cs
    2d11:	57                   	push   di
    2d12:	bf c2 26             	mov    di,0x26c2
    2d15:	0e                   	push   cs
    2d16:	57                   	push   di
    2d17:	55                   	push   bp
    2d18:	9a 6d 23 52 2d       	call   0x2d52:0x236d
    2d1d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d20:	2d 01 00             	sub    ax,0x1
    2d23:	71 05                	jno    0x2d2a
    2d25:	9a 3e 04 32 2d       	call   0x2d32:0x43e
    2d2a:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2d2d:	71 05                	jno    0x2d34
    2d2f:	9a 3e 04 3c 2d       	call   0x2d3c:0x43e
    2d34:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2d37:	71 05                	jno    0x2d3e
    2d39:	9a 3e 04 5f 2d       	call   0x2d5f:0x43e
    2d3e:	50                   	push   ax
    2d3f:	8d 7e fa             	lea    di,[bp-0x6]
    2d42:	16                   	push   ss
    2d43:	57                   	push   di
    2d44:	bf d4 26             	mov    di,0x26d4
    2d47:	0e                   	push   cs
    2d48:	57                   	push   di
    2d49:	bf db 26             	mov    di,0x26db
    2d4c:	0e                   	push   cs
    2d4d:	57                   	push   di
    2d4e:	55                   	push   bp
    2d4f:	9a 16 25 89 2d       	call   0x2d89:0x2516
    2d54:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d57:	2d 01 00             	sub    ax,0x1
    2d5a:	71 05                	jno    0x2d61
    2d5c:	9a 3e 04 69 2d       	call   0x2d69:0x43e
    2d61:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2d64:	71 05                	jno    0x2d6b
    2d66:	9a 3e 04 73 2d       	call   0x2d73:0x43e
    2d6b:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2d6e:	71 05                	jno    0x2d75
    2d70:	9a 3e 04 96 2d       	call   0x2d96:0x43e
    2d75:	50                   	push   ax
    2d76:	8d 7e fa             	lea    di,[bp-0x6]
    2d79:	16                   	push   ss
    2d7a:	57                   	push   di
    2d7b:	bf d4 26             	mov    di,0x26d4
    2d7e:	0e                   	push   cs
    2d7f:	57                   	push   di
    2d80:	bf e5 26             	mov    di,0x26e5
    2d83:	0e                   	push   cs
    2d84:	57                   	push   di
    2d85:	55                   	push   bp
    2d86:	9a 16 25 c0 2d       	call   0x2dc0:0x2516
    2d8b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d8e:	2d 01 00             	sub    ax,0x1
    2d91:	71 05                	jno    0x2d98
    2d93:	9a 3e 04 a0 2d       	call   0x2da0:0x43e
    2d98:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2d9b:	71 05                	jno    0x2da2
    2d9d:	9a 3e 04 aa 2d       	call   0x2daa:0x43e
    2da2:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2da5:	71 05                	jno    0x2dac
    2da7:	9a 3e 04 cd 2d       	call   0x2dcd:0x43e
    2dac:	50                   	push   ax
    2dad:	8d 7e fa             	lea    di,[bp-0x6]
    2db0:	16                   	push   ss
    2db1:	57                   	push   di
    2db2:	bf d4 26             	mov    di,0x26d4
    2db5:	0e                   	push   cs
    2db6:	57                   	push   di
    2db7:	bf f1 26             	mov    di,0x26f1
    2dba:	0e                   	push   cs
    2dbb:	57                   	push   di
    2dbc:	55                   	push   bp
    2dbd:	9a 16 25 f7 2d       	call   0x2df7:0x2516
    2dc2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2dc5:	2d 01 00             	sub    ax,0x1
    2dc8:	71 05                	jno    0x2dcf
    2dca:	9a 3e 04 d7 2d       	call   0x2dd7:0x43e
    2dcf:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2dd2:	71 05                	jno    0x2dd9
    2dd4:	9a 3e 04 e1 2d       	call   0x2de1:0x43e
    2dd9:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2ddc:	71 05                	jno    0x2de3
    2dde:	9a 3e 04 04 2e       	call   0x2e04:0x43e
    2de3:	50                   	push   ax
    2de4:	8d 7e fa             	lea    di,[bp-0x6]
    2de7:	16                   	push   ss
    2de8:	57                   	push   di
    2de9:	bf d4 26             	mov    di,0x26d4
    2dec:	0e                   	push   cs
    2ded:	57                   	push   di
    2dee:	bf 01 27             	mov    di,0x2701
    2df1:	0e                   	push   cs
    2df2:	57                   	push   di
    2df3:	55                   	push   bp
    2df4:	9a 16 25 2e 2e       	call   0x2e2e:0x2516
    2df9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2dfc:	2d 01 00             	sub    ax,0x1
    2dff:	71 05                	jno    0x2e06
    2e01:	9a 3e 04 0e 2e       	call   0x2e0e:0x43e
    2e06:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2e09:	71 05                	jno    0x2e10
    2e0b:	9a 3e 04 18 2e       	call   0x2e18:0x43e
    2e10:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2e13:	71 05                	jno    0x2e1a
    2e15:	9a 3e 04 3e 2e       	call   0x2e3e:0x43e
    2e1a:	50                   	push   ax
    2e1b:	8d 7e fa             	lea    di,[bp-0x6]
    2e1e:	16                   	push   ss
    2e1f:	57                   	push   di
    2e20:	bf bf 26             	mov    di,0x26bf
    2e23:	0e                   	push   cs
    2e24:	57                   	push   di
    2e25:	bf 0d 27             	mov    di,0x270d
    2e28:	0e                   	push   cs
    2e29:	57                   	push   di
    2e2a:	55                   	push   bp
    2e2b:	9a 16 25 68 2e       	call   0x2e68:0x2516
    2e30:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2e33:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e36:	2d 01 00             	sub    ax,0x1
    2e39:	71 05                	jno    0x2e40
    2e3b:	9a 3e 04 48 2e       	call   0x2e48:0x43e
    2e40:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2e43:	71 05                	jno    0x2e4a
    2e45:	9a 3e 04 52 2e       	call   0x2e52:0x43e
    2e4a:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2e4d:	71 05                	jno    0x2e54
    2e4f:	9a 3e 04 75 2e       	call   0x2e75:0x43e
    2e54:	50                   	push   ax
    2e55:	8d 7e fa             	lea    di,[bp-0x6]
    2e58:	16                   	push   ss
    2e59:	57                   	push   di
    2e5a:	bf d4 26             	mov    di,0x26d4
    2e5d:	0e                   	push   cs
    2e5e:	57                   	push   di
    2e5f:	bf 1e 27             	mov    di,0x271e
    2e62:	0e                   	push   cs
    2e63:	57                   	push   di
    2e64:	55                   	push   bp
    2e65:	9a 6d 23 9f 2e       	call   0x2e9f:0x236d
    2e6a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e6d:	2d 01 00             	sub    ax,0x1
    2e70:	71 05                	jno    0x2e77
    2e72:	9a 3e 04 7f 2e       	call   0x2e7f:0x43e
    2e77:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2e7a:	71 05                	jno    0x2e81
    2e7c:	9a 3e 04 89 2e       	call   0x2e89:0x43e
    2e81:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2e84:	71 05                	jno    0x2e8b
    2e86:	9a 3e 04 ac 2e       	call   0x2eac:0x43e
    2e8b:	50                   	push   ax
    2e8c:	8d 7e fa             	lea    di,[bp-0x6]
    2e8f:	16                   	push   ss
    2e90:	57                   	push   di
    2e91:	bf d4 26             	mov    di,0x26d4
    2e94:	0e                   	push   cs
    2e95:	57                   	push   di
    2e96:	bf 23 27             	mov    di,0x2723
    2e99:	0e                   	push   cs
    2e9a:	57                   	push   di
    2e9b:	55                   	push   bp
    2e9c:	9a 16 25 d6 2e       	call   0x2ed6:0x2516
    2ea1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ea4:	2d 01 00             	sub    ax,0x1
    2ea7:	71 05                	jno    0x2eae
    2ea9:	9a 3e 04 b6 2e       	call   0x2eb6:0x43e
    2eae:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2eb1:	71 05                	jno    0x2eb8
    2eb3:	9a 3e 04 c0 2e       	call   0x2ec0:0x43e
    2eb8:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2ebb:	71 05                	jno    0x2ec2
    2ebd:	9a 3e 04 e3 2e       	call   0x2ee3:0x43e
    2ec2:	50                   	push   ax
    2ec3:	8d 7e fa             	lea    di,[bp-0x6]
    2ec6:	16                   	push   ss
    2ec7:	57                   	push   di
    2ec8:	bf d4 26             	mov    di,0x26d4
    2ecb:	0e                   	push   cs
    2ecc:	57                   	push   di
    2ecd:	bf 32 27             	mov    di,0x2732
    2ed0:	0e                   	push   cs
    2ed1:	57                   	push   di
    2ed2:	55                   	push   bp
    2ed3:	9a 6d 23 0d 2f       	call   0x2f0d:0x236d
    2ed8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2edb:	2d 01 00             	sub    ax,0x1
    2ede:	71 05                	jno    0x2ee5
    2ee0:	9a 3e 04 ed 2e       	call   0x2eed:0x43e
    2ee5:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2ee8:	71 05                	jno    0x2eef
    2eea:	9a 3e 04 f7 2e       	call   0x2ef7:0x43e
    2eef:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2ef2:	71 05                	jno    0x2ef9
    2ef4:	9a 3e 04 1a 2f       	call   0x2f1a:0x43e
    2ef9:	50                   	push   ax
    2efa:	8d 7e fa             	lea    di,[bp-0x6]
    2efd:	16                   	push   ss
    2efe:	57                   	push   di
    2eff:	bf d4 26             	mov    di,0x26d4
    2f02:	0e                   	push   cs
    2f03:	57                   	push   di
    2f04:	bf 3c 27             	mov    di,0x273c
    2f07:	0e                   	push   cs
    2f08:	57                   	push   di
    2f09:	55                   	push   bp
    2f0a:	9a 16 25 44 2f       	call   0x2f44:0x2516
    2f0f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f12:	2d 01 00             	sub    ax,0x1
    2f15:	71 05                	jno    0x2f1c
    2f17:	9a 3e 04 24 2f       	call   0x2f24:0x43e
    2f1c:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2f1f:	71 05                	jno    0x2f26
    2f21:	9a 3e 04 2e 2f       	call   0x2f2e:0x43e
    2f26:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2f29:	71 05                	jno    0x2f30
    2f2b:	9a 3e 04 51 2f       	call   0x2f51:0x43e
    2f30:	50                   	push   ax
    2f31:	8d 7e fa             	lea    di,[bp-0x6]
    2f34:	16                   	push   ss
    2f35:	57                   	push   di
    2f36:	bf d4 26             	mov    di,0x26d4
    2f39:	0e                   	push   cs
    2f3a:	57                   	push   di
    2f3b:	bf 4b 27             	mov    di,0x274b
    2f3e:	0e                   	push   cs
    2f3f:	57                   	push   di
    2f40:	55                   	push   bp
    2f41:	9a 16 25 7b 2f       	call   0x2f7b:0x2516
    2f46:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f49:	2d 01 00             	sub    ax,0x1
    2f4c:	71 05                	jno    0x2f53
    2f4e:	9a 3e 04 5b 2f       	call   0x2f5b:0x43e
    2f53:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2f56:	71 05                	jno    0x2f5d
    2f58:	9a 3e 04 65 2f       	call   0x2f65:0x43e
    2f5d:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2f60:	71 05                	jno    0x2f67
    2f62:	9a 3e 04 88 2f       	call   0x2f88:0x43e
    2f67:	50                   	push   ax
    2f68:	8d 7e fa             	lea    di,[bp-0x6]
    2f6b:	16                   	push   ss
    2f6c:	57                   	push   di
    2f6d:	bf d4 26             	mov    di,0x26d4
    2f70:	0e                   	push   cs
    2f71:	57                   	push   di
    2f72:	bf 55 27             	mov    di,0x2755
    2f75:	0e                   	push   cs
    2f76:	57                   	push   di
    2f77:	55                   	push   bp
    2f78:	9a 16 25 b2 2f       	call   0x2fb2:0x2516
    2f7d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f80:	2d 01 00             	sub    ax,0x1
    2f83:	71 05                	jno    0x2f8a
    2f85:	9a 3e 04 92 2f       	call   0x2f92:0x43e
    2f8a:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2f8d:	71 05                	jno    0x2f94
    2f8f:	9a 3e 04 9c 2f       	call   0x2f9c:0x43e
    2f94:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2f97:	71 05                	jno    0x2f9e
    2f99:	9a 3e 04 bf 2f       	call   0x2fbf:0x43e
    2f9e:	50                   	push   ax
    2f9f:	8d 7e fa             	lea    di,[bp-0x6]
    2fa2:	16                   	push   ss
    2fa3:	57                   	push   di
    2fa4:	bf bf 26             	mov    di,0x26bf
    2fa7:	0e                   	push   cs
    2fa8:	57                   	push   di
    2fa9:	bf 63 27             	mov    di,0x2763
    2fac:	0e                   	push   cs
    2fad:	57                   	push   di
    2fae:	55                   	push   bp
    2faf:	9a 6d 23 e9 2f       	call   0x2fe9:0x236d
    2fb4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2fb7:	2d 01 00             	sub    ax,0x1
    2fba:	71 05                	jno    0x2fc1
    2fbc:	9a 3e 04 c9 2f       	call   0x2fc9:0x43e
    2fc1:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2fc4:	71 05                	jno    0x2fcb
    2fc6:	9a 3e 04 d3 2f       	call   0x2fd3:0x43e
    2fcb:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    2fce:	71 05                	jno    0x2fd5
    2fd0:	9a 3e 04 f6 2f       	call   0x2ff6:0x43e
    2fd5:	50                   	push   ax
    2fd6:	8d 7e fa             	lea    di,[bp-0x6]
    2fd9:	16                   	push   ss
    2fda:	57                   	push   di
    2fdb:	bf d4 26             	mov    di,0x26d4
    2fde:	0e                   	push   cs
    2fdf:	57                   	push   di
    2fe0:	bf 74 27             	mov    di,0x2774
    2fe3:	0e                   	push   cs
    2fe4:	57                   	push   di
    2fe5:	55                   	push   bp
    2fe6:	9a 16 25 20 30       	call   0x3020:0x2516
    2feb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2fee:	2d 01 00             	sub    ax,0x1
    2ff1:	71 05                	jno    0x2ff8
    2ff3:	9a 3e 04 00 30       	call   0x3000:0x43e
    2ff8:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    2ffb:	71 05                	jno    0x3002
    2ffd:	9a 3e 04 0a 30       	call   0x300a:0x43e
    3002:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    3005:	71 05                	jno    0x300c
    3007:	9a 3e 04 2d 30       	call   0x302d:0x43e
    300c:	50                   	push   ax
    300d:	8d 7e fa             	lea    di,[bp-0x6]
    3010:	16                   	push   ss
    3011:	57                   	push   di
    3012:	bf d4 26             	mov    di,0x26d4
    3015:	0e                   	push   cs
    3016:	57                   	push   di
    3017:	bf 88 27             	mov    di,0x2788
    301a:	0e                   	push   cs
    301b:	57                   	push   di
    301c:	55                   	push   bp
    301d:	9a 16 25 57 30       	call   0x3057:0x2516
    3022:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3025:	2d 01 00             	sub    ax,0x1
    3028:	71 05                	jno    0x302f
    302a:	9a 3e 04 37 30       	call   0x3037:0x43e
    302f:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    3032:	71 05                	jno    0x3039
    3034:	9a 3e 04 41 30       	call   0x3041:0x43e
    3039:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    303c:	71 05                	jno    0x3043
    303e:	9a 3e 04 64 30       	call   0x3064:0x43e
    3043:	50                   	push   ax
    3044:	8d 7e fa             	lea    di,[bp-0x6]
    3047:	16                   	push   ss
    3048:	57                   	push   di
    3049:	bf bf 26             	mov    di,0x26bf
    304c:	0e                   	push   cs
    304d:	57                   	push   di
    304e:	bf 9a 27             	mov    di,0x279a
    3051:	0e                   	push   cs
    3052:	57                   	push   di
    3053:	55                   	push   bp
    3054:	9a 6d 23 8e 30       	call   0x308e:0x236d
    3059:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    305c:	2d 01 00             	sub    ax,0x1
    305f:	71 05                	jno    0x3066
    3061:	9a 3e 04 6e 30       	call   0x306e:0x43e
    3066:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    3069:	71 05                	jno    0x3070
    306b:	9a 3e 04 78 30       	call   0x3078:0x43e
    3070:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    3073:	71 05                	jno    0x307a
    3075:	9a 3e 04 9e 30       	call   0x309e:0x43e
    307a:	50                   	push   ax
    307b:	8d 7e fa             	lea    di,[bp-0x6]
    307e:	16                   	push   ss
    307f:	57                   	push   di
    3080:	bf d4 26             	mov    di,0x26d4
    3083:	0e                   	push   cs
    3084:	57                   	push   di
    3085:	bf ac 27             	mov    di,0x27ac
    3088:	0e                   	push   cs
    3089:	57                   	push   di
    308a:	55                   	push   bp
    308b:	9a 16 25 c8 30       	call   0x30c8:0x2516
    3090:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    3093:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3096:	2d 01 00             	sub    ax,0x1
    3099:	71 05                	jno    0x30a0
    309b:	9a 3e 04 a8 30       	call   0x30a8:0x43e
    30a0:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    30a3:	71 05                	jno    0x30aa
    30a5:	9a 3e 04 b2 30       	call   0x30b2:0x43e
    30aa:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    30ad:	71 05                	jno    0x30b4
    30af:	9a 3e 04 d5 30       	call   0x30d5:0x43e
    30b4:	50                   	push   ax
    30b5:	8d 7e fa             	lea    di,[bp-0x6]
    30b8:	16                   	push   ss
    30b9:	57                   	push   di
    30ba:	bf bd 27             	mov    di,0x27bd
    30bd:	0e                   	push   cs
    30be:	57                   	push   di
    30bf:	bf c4 27             	mov    di,0x27c4
    30c2:	0e                   	push   cs
    30c3:	57                   	push   di
    30c4:	55                   	push   bp
    30c5:	9a 16 25 ff 30       	call   0x30ff:0x2516
    30ca:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    30cd:	2d 01 00             	sub    ax,0x1
    30d0:	71 05                	jno    0x30d7
    30d2:	9a 3e 04 df 30       	call   0x30df:0x43e
    30d7:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    30da:	71 05                	jno    0x30e1
    30dc:	9a 3e 04 e9 30       	call   0x30e9:0x43e
    30e1:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    30e4:	71 05                	jno    0x30eb
    30e6:	9a 3e 04 0c 31       	call   0x310c:0x43e
    30eb:	50                   	push   ax
    30ec:	8d 7e fa             	lea    di,[bp-0x6]
    30ef:	16                   	push   ss
    30f0:	57                   	push   di
    30f1:	bf bd 27             	mov    di,0x27bd
    30f4:	0e                   	push   cs
    30f5:	57                   	push   di
    30f6:	bf d1 27             	mov    di,0x27d1
    30f9:	0e                   	push   cs
    30fa:	57                   	push   di
    30fb:	55                   	push   bp
    30fc:	9a 16 25 36 31       	call   0x3136:0x2516
    3101:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3104:	2d 01 00             	sub    ax,0x1
    3107:	71 05                	jno    0x310e
    3109:	9a 3e 04 16 31       	call   0x3116:0x43e
    310e:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    3111:	71 05                	jno    0x3118
    3113:	9a 3e 04 20 31       	call   0x3120:0x43e
    3118:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    311b:	71 05                	jno    0x3122
    311d:	9a 3e 04 43 31       	call   0x3143:0x43e
    3122:	50                   	push   ax
    3123:	8d 7e fa             	lea    di,[bp-0x6]
    3126:	16                   	push   ss
    3127:	57                   	push   di
    3128:	bf bd 27             	mov    di,0x27bd
    312b:	0e                   	push   cs
    312c:	57                   	push   di
    312d:	bf dd 27             	mov    di,0x27dd
    3130:	0e                   	push   cs
    3131:	57                   	push   di
    3132:	55                   	push   bp
    3133:	9a 16 25 6d 31       	call   0x316d:0x2516
    3138:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    313b:	2d 01 00             	sub    ax,0x1
    313e:	71 05                	jno    0x3145
    3140:	9a 3e 04 4d 31       	call   0x314d:0x43e
    3145:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    3148:	71 05                	jno    0x314f
    314a:	9a 3e 04 57 31       	call   0x3157:0x43e
    314f:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    3152:	71 05                	jno    0x3159
    3154:	9a 3e 04 7a 31       	call   0x317a:0x43e
    3159:	50                   	push   ax
    315a:	8d 7e fa             	lea    di,[bp-0x6]
    315d:	16                   	push   ss
    315e:	57                   	push   di
    315f:	bf bd 27             	mov    di,0x27bd
    3162:	0e                   	push   cs
    3163:	57                   	push   di
    3164:	bf ec 27             	mov    di,0x27ec
    3167:	0e                   	push   cs
    3168:	57                   	push   di
    3169:	55                   	push   bp
    316a:	9a 16 25 a4 31       	call   0x31a4:0x2516
    316f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3172:	2d 01 00             	sub    ax,0x1
    3175:	71 05                	jno    0x317c
    3177:	9a 3e 04 84 31       	call   0x3184:0x43e
    317c:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    317f:	71 05                	jno    0x3186
    3181:	9a 3e 04 8e 31       	call   0x318e:0x43e
    3186:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    3189:	71 05                	jno    0x3190
    318b:	9a 3e 04 b4 31       	call   0x31b4:0x43e
    3190:	50                   	push   ax
    3191:	8d 7e fa             	lea    di,[bp-0x6]
    3194:	16                   	push   ss
    3195:	57                   	push   di
    3196:	bf bd 27             	mov    di,0x27bd
    3199:	0e                   	push   cs
    319a:	57                   	push   di
    319b:	bf fc 27             	mov    di,0x27fc
    319e:	0e                   	push   cs
    319f:	57                   	push   di
    31a0:	55                   	push   bp
    31a1:	9a 16 25 de 31       	call   0x31de:0x2516
    31a6:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    31a9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    31ac:	2d 01 00             	sub    ax,0x1
    31af:	71 05                	jno    0x31b6
    31b1:	9a 3e 04 be 31       	call   0x31be:0x43e
    31b6:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    31b9:	71 05                	jno    0x31c0
    31bb:	9a 3e 04 c8 31       	call   0x31c8:0x43e
    31c0:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    31c3:	71 05                	jno    0x31ca
    31c5:	9a 3e 04 eb 31       	call   0x31eb:0x43e
    31ca:	50                   	push   ax
    31cb:	8d 7e fa             	lea    di,[bp-0x6]
    31ce:	16                   	push   ss
    31cf:	57                   	push   di
    31d0:	bf bf 26             	mov    di,0x26bf
    31d3:	0e                   	push   cs
    31d4:	57                   	push   di
    31d5:	bf 0b 28             	mov    di,0x280b
    31d8:	0e                   	push   cs
    31d9:	57                   	push   di
    31da:	55                   	push   bp
    31db:	9a 16 25 15 32       	call   0x3215:0x2516
    31e0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    31e3:	2d 01 00             	sub    ax,0x1
    31e6:	71 05                	jno    0x31ed
    31e8:	9a 3e 04 f5 31       	call   0x31f5:0x43e
    31ed:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    31f0:	71 05                	jno    0x31f7
    31f2:	9a 3e 04 ff 31       	call   0x31ff:0x43e
    31f7:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    31fa:	71 05                	jno    0x3201
    31fc:	9a 3e 04 22 32       	call   0x3222:0x43e
    3201:	50                   	push   ax
    3202:	8d 7e fa             	lea    di,[bp-0x6]
    3205:	16                   	push   ss
    3206:	57                   	push   di
    3207:	bf bd 27             	mov    di,0x27bd
    320a:	0e                   	push   cs
    320b:	57                   	push   di
    320c:	bf 12 28             	mov    di,0x2812
    320f:	0e                   	push   cs
    3210:	57                   	push   di
    3211:	55                   	push   bp
    3212:	9a 16 25 4c 32       	call   0x324c:0x2516
    3217:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    321a:	2d 01 00             	sub    ax,0x1
    321d:	71 05                	jno    0x3224
    321f:	9a 3e 04 2c 32       	call   0x322c:0x43e
    3224:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    3227:	71 05                	jno    0x322e
    3229:	9a 3e 04 36 32       	call   0x3236:0x43e
    322e:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    3231:	71 05                	jno    0x3238
    3233:	9a 3e 04 59 32       	call   0x3259:0x43e
    3238:	50                   	push   ax
    3239:	8d 7e fa             	lea    di,[bp-0x6]
    323c:	16                   	push   ss
    323d:	57                   	push   di
    323e:	bf bf 26             	mov    di,0x26bf
    3241:	0e                   	push   cs
    3242:	57                   	push   di
    3243:	bf 1d 28             	mov    di,0x281d
    3246:	0e                   	push   cs
    3247:	57                   	push   di
    3248:	55                   	push   bp
    3249:	9a 16 25 83 32       	call   0x3283:0x2516
    324e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3251:	2d 01 00             	sub    ax,0x1
    3254:	71 05                	jno    0x325b
    3256:	9a 3e 04 63 32       	call   0x3263:0x43e
    325b:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    325e:	71 05                	jno    0x3265
    3260:	9a 3e 04 6d 32       	call   0x326d:0x43e
    3265:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    3268:	71 05                	jno    0x326f
    326a:	9a 3e 04 93 32       	call   0x3293:0x43e
    326f:	50                   	push   ax
    3270:	8d 7e fa             	lea    di,[bp-0x6]
    3273:	16                   	push   ss
    3274:	57                   	push   di
    3275:	bf bf 26             	mov    di,0x26bf
    3278:	0e                   	push   cs
    3279:	57                   	push   di
    327a:	bf 32 28             	mov    di,0x2832
    327d:	0e                   	push   cs
    327e:	57                   	push   di
    327f:	55                   	push   bp
    3280:	9a 16 25 bd 32       	call   0x32bd:0x2516
    3285:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    3288:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    328b:	2d 01 00             	sub    ax,0x1
    328e:	71 05                	jno    0x3295
    3290:	9a 3e 04 9d 32       	call   0x329d:0x43e
    3295:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    3298:	71 05                	jno    0x329f
    329a:	9a 3e 04 a7 32       	call   0x32a7:0x43e
    329f:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    32a2:	71 05                	jno    0x32a9
    32a4:	9a 3e 04 ca 32       	call   0x32ca:0x43e
    32a9:	50                   	push   ax
    32aa:	8d 7e fa             	lea    di,[bp-0x6]
    32ad:	16                   	push   ss
    32ae:	57                   	push   di
    32af:	bf d4 26             	mov    di,0x26d4
    32b2:	0e                   	push   cs
    32b3:	57                   	push   di
    32b4:	bf 3f 28             	mov    di,0x283f
    32b7:	0e                   	push   cs
    32b8:	57                   	push   di
    32b9:	55                   	push   bp
    32ba:	9a 16 25 f4 32       	call   0x32f4:0x2516
    32bf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    32c2:	2d 01 00             	sub    ax,0x1
    32c5:	71 05                	jno    0x32cc
    32c7:	9a 3e 04 d4 32       	call   0x32d4:0x43e
    32cc:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    32cf:	71 05                	jno    0x32d6
    32d1:	9a 3e 04 de 32       	call   0x32de:0x43e
    32d6:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    32d9:	71 05                	jno    0x32e0
    32db:	9a 3e 04 01 33       	call   0x3301:0x43e
    32e0:	50                   	push   ax
    32e1:	8d 7e fa             	lea    di,[bp-0x6]
    32e4:	16                   	push   ss
    32e5:	57                   	push   di
    32e6:	bf d4 26             	mov    di,0x26d4
    32e9:	0e                   	push   cs
    32ea:	57                   	push   di
    32eb:	bf 42 28             	mov    di,0x2842
    32ee:	0e                   	push   cs
    32ef:	57                   	push   di
    32f0:	55                   	push   bp
    32f1:	9a 16 25 2b 33       	call   0x332b:0x2516
    32f6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    32f9:	2d 01 00             	sub    ax,0x1
    32fc:	71 05                	jno    0x3303
    32fe:	9a 3e 04 0b 33       	call   0x330b:0x43e
    3303:	f7 6e f8             	imul   WORD PTR [bp-0x8]
    3306:	71 05                	jno    0x330d
    3308:	9a 3e 04 15 33       	call   0x3315:0x43e
    330d:	03 46 fc             	add    ax,WORD PTR [bp-0x4]
    3310:	71 05                	jno    0x3317
    3312:	9a 3e 04 e1 33       	call   0x33e1:0x43e
    3317:	50                   	push   ax
    3318:	8d 7e fa             	lea    di,[bp-0x6]
    331b:	16                   	push   ss
    331c:	57                   	push   di
    331d:	bf d4 26             	mov    di,0x26d4
    3320:	0e                   	push   cs
    3321:	57                   	push   di
    3322:	bf 4d 28             	mov    di,0x284d
    3325:	0e                   	push   cs
    3326:	57                   	push   di
    3327:	55                   	push   bp
    3328:	9a 16 25 85 37       	call   0x3785:0x2516
    332d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3330:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    3333:	74 03                	je     0x3338
    3335:	e9 fc f7             	jmp    0x2b34
    3338:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    333b:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    333e:	74 03                	je     0x3343
    3340:	e9 7a f7             	jmp    0x2abd
    3343:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3346:	26 ff b5 1e 03       	push   WORD PTR es:[di+0x31e]
    334b:	26 ff b5 1c 03       	push   WORD PTR es:[di+0x31c]
    3350:	06                   	push   es
    3351:	57                   	push   di
    3352:	9a d0 3f 0e 37       	call   0x370e:0x3fd0
    3357:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    335a:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    335f:	06                   	push   es
    3360:	57                   	push   di
    3361:	9a d2 31 73 33       	call   0x3373:0x31d2
    3366:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3369:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    336e:	06                   	push   es
    336f:	57                   	push   di
    3370:	9a d2 31 82 33       	call   0x3382:0x31d2
    3375:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3378:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    337d:	06                   	push   es
    337e:	57                   	push   di
    337f:	9a d2 31 91 33       	call   0x3391:0x31d2
    3384:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3387:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    338c:	06                   	push   es
    338d:	57                   	push   di
    338e:	9a d2 31 a0 33       	call   0x33a0:0x31d2
    3393:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3396:	26 c4 bd d0 01       	les    di,DWORD PTR es:[di+0x1d0]
    339b:	06                   	push   es
    339c:	57                   	push   di
    339d:	9a d2 31 af 33       	call   0x33af:0x31d2
    33a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33a5:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    33aa:	06                   	push   es
    33ab:	57                   	push   di
    33ac:	9a d2 31 be 33       	call   0x33be:0x31d2
    33b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33b4:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    33b9:	06                   	push   es
    33ba:	57                   	push   di
    33bb:	9a d2 31 10 4b       	call   0x4b10:0x31d2
    33c0:	c9                   	leave
    33c1:	ca 08 00             	retf   0x8
    33c4:	43                   	inc    bx
    33c5:	34 4a                	xor    al,0x4a
    33c7:	34 51                	xor    al,0x51
    33c9:	34 58                	xor    al,0x58
    33cb:	34 5f                	xor    al,0x5f
    33cd:	34 66                	xor    al,0x66
    33cf:	34 00                	xor    al,0x0
    33d1:	80 ff ff             	cmp    bh,0xff
    33d4:	ff                   	(bad)
    33d5:	7f 00                	jg     0x33d7
    33d7:	00 55 89             	add    BYTE PTR [di-0x77],dl
    33da:	e5 b8                	in     ax,0xb8
    33dc:	18 00                	sbb    BYTE PTR [bx+si],al
    33de:	9a 44 04 02 34       	call   0x3402:0x444
    33e3:	83 ec 18             	sub    sp,0x18
    33e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33e9:	26 8b 85 9c 03       	mov    ax,WORD PTR es:[di+0x39c]
    33ee:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    33f1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    33f4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    33f7:	bf 94 00             	mov    di,0x94
    33fa:	b8 15 34             	mov    ax,0x3415
    33fd:	50                   	push   ax
    33fe:	57                   	push   di
    33ff:	9a 55 22 1c 34       	call   0x341c:0x2255
    3404:	08 c0                	or     al,al
    3406:	75 03                	jne    0x340b
    3408:	e9 bf 00             	jmp    0x34ca
    340b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    340e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3411:	bf 94 00             	mov    di,0x94
    3414:	b8 2d 34             	mov    ax,0x342d
    3417:	50                   	push   ax
    3418:	57                   	push   di
    3419:	9a 73 22 8a 34       	call   0x348a:0x2273
    341e:	52                   	push   dx
    341f:	50                   	push   ax
    3420:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3423:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    3428:	06                   	push   es
    3429:	57                   	push   di
    342a:	9a 2b 16 80 34       	call   0x3480:0x162b
    342f:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    3432:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    3435:	3d 05 00             	cmp    ax,0x5
    3438:	77 33                	ja     0x346d
    343a:	89 c3                	mov    bx,ax
    343c:	d1 e3                	shl    bx,1
    343e:	2e ff a7 c4 33       	jmp    WORD PTR cs:[bx+0x33c4]
    3443:	c7 46 fe 64 00       	mov    WORD PTR [bp-0x2],0x64
    3448:	eb 23                	jmp    0x346d
    344a:	c7 46 fe 7d 00       	mov    WORD PTR [bp-0x2],0x7d
    344f:	eb 1c                	jmp    0x346d
    3451:	c7 46 fe 96 00       	mov    WORD PTR [bp-0x2],0x96
    3456:	eb 15                	jmp    0x346d
    3458:	c7 46 fe c8 00       	mov    WORD PTR [bp-0x2],0xc8
    345d:	eb 0e                	jmp    0x346d
    345f:	c7 46 fe 4b 00       	mov    WORD PTR [bp-0x2],0x4b
    3464:	eb 07                	jmp    0x346d
    3466:	c7 46 fe 32 00       	mov    WORD PTR [bp-0x2],0x32
    346b:	eb 00                	jmp    0x346d
    346d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3470:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    3475:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    3478:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    347b:	06                   	push   es
    347c:	57                   	push   di
    347d:	9a 26 13 b5 34       	call   0x34b5:0x1326
    3482:	2d 01 00             	sub    ax,0x1
    3485:	71 05                	jno    0x348c
    3487:	9a 3e 04 fa 34       	call   0x34fa:0x43e
    348c:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    348f:	31 c0                	xor    ax,ax
    3491:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    3494:	7f 34                	jg     0x34ca
    3496:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    3499:	eb 03                	jmp    0x349e
    349b:	ff 46 ee             	inc    WORD PTR [bp-0x12]
    349e:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    34a1:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    34a4:	b0 00                	mov    al,0x0
    34a6:	75 01                	jne    0x34a9
    34a8:	40                   	inc    ax
    34a9:	50                   	push   ax
    34aa:	ff 76 ee             	push   WORD PTR [bp-0x12]
    34ad:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    34b0:	06                   	push   es
    34b1:	57                   	push   di
    34b2:	9a 53 13 c0 34       	call   0x34c0:0x1353
    34b7:	89 c7                	mov    di,ax
    34b9:	8e c2                	mov    es,dx
    34bb:	06                   	push   es
    34bc:	57                   	push   di
    34bd:	9a 75 12 81 36       	call   0x3681:0x1275
    34c2:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    34c5:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    34c8:	75 d1                	jne    0x349b
    34ca:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    34cd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34d0:	26 3b 85 9c 03       	cmp    ax,WORD PTR es:[di+0x39c]
    34d5:	75 03                	jne    0x34da
    34d7:	e9 1e 02             	jmp    0x36f8
    34da:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    34df:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    34e2:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    34e5:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    34ea:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    34ef:	2d 01 00             	sub    ax,0x1
    34f2:	83 da 00             	sbb    dx,0x0
    34f5:	71 05                	jno    0x34fc
    34f7:	9a 3e 04 02 35       	call   0x3502:0x43e
    34fc:	bf d0 33             	mov    di,0x33d0
    34ff:	9a 16 04 49 35       	call   0x3549:0x416
    3504:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3507:	31 c0                	xor    ax,ax
    3509:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    350c:	7e 03                	jle    0x3511
    350e:	e9 85 00             	jmp    0x3596
    3511:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3514:	eb 03                	jmp    0x3519
    3516:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3519:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    351c:	99                   	cwd
    351d:	52                   	push   dx
    351e:	50                   	push   ax
    351f:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    3522:	06                   	push   es
    3523:	57                   	push   di
    3524:	9a 30 6e 8c 35       	call   0x358c:0x6e30
    3529:	99                   	cwd
    352a:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    352d:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    3530:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3533:	26 8b 85 9c 03       	mov    ax,WORD PTR es:[di+0x39c]
    3538:	99                   	cwd
    3539:	52                   	push   dx
    353a:	50                   	push   ax
    353b:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    353e:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    3541:	b9 64 00             	mov    cx,0x64
    3544:	31 db                	xor    bx,bx
    3546:	9a 5c 17 50 35       	call   0x3550:0x175c
    354b:	59                   	pop    cx
    354c:	5b                   	pop    bx
    354d:	9a 70 16 5d 35       	call   0x355d:0x1670
    3552:	8b c8                	mov    cx,ax
    3554:	8b da                	mov    bx,dx
    3556:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3559:	99                   	cwd
    355a:	9a 5c 17 67 35       	call   0x3567:0x175c
    355f:	b9 64 00             	mov    cx,0x64
    3562:	31 db                	xor    bx,bx
    3564:	9a 70 16 81 35       	call   0x3581:0x1670
    3569:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    356c:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    356f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3572:	99                   	cwd
    3573:	52                   	push   dx
    3574:	50                   	push   ax
    3575:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    3578:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    357b:	bf d0 33             	mov    di,0x33d0
    357e:	9a 16 04 ae 35       	call   0x35ae:0x416
    3583:	50                   	push   ax
    3584:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    3587:	06                   	push   es
    3588:	57                   	push   di
    3589:	9a c9 70 db 35       	call   0x35db:0x70c9
    358e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3591:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    3594:	75 80                	jne    0x3516
    3596:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    3599:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    359e:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    35a3:	2d 01 00             	sub    ax,0x1
    35a6:	83 da 00             	sbb    dx,0x0
    35a9:	71 05                	jno    0x35b0
    35ab:	9a 3e 04 b6 35       	call   0x35b6:0x43e
    35b0:	bf d0 33             	mov    di,0x33d0
    35b3:	9a 16 04 fd 35       	call   0x35fd:0x416
    35b8:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    35bb:	31 c0                	xor    ax,ax
    35bd:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    35c0:	7e 03                	jle    0x35c5
    35c2:	e9 85 00             	jmp    0x364a
    35c5:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    35c8:	eb 03                	jmp    0x35cd
    35ca:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    35cd:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    35d0:	99                   	cwd
    35d1:	52                   	push   dx
    35d2:	50                   	push   ax
    35d3:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    35d6:	06                   	push   es
    35d7:	57                   	push   di
    35d8:	9a 8b 6e 40 36       	call   0x3640:0x6e8b
    35dd:	99                   	cwd
    35de:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    35e1:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    35e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35e7:	26 8b 85 9c 03       	mov    ax,WORD PTR es:[di+0x39c]
    35ec:	99                   	cwd
    35ed:	52                   	push   dx
    35ee:	50                   	push   ax
    35ef:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    35f2:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    35f5:	b9 64 00             	mov    cx,0x64
    35f8:	31 db                	xor    bx,bx
    35fa:	9a 5c 17 04 36       	call   0x3604:0x175c
    35ff:	59                   	pop    cx
    3600:	5b                   	pop    bx
    3601:	9a 70 16 11 36       	call   0x3611:0x1670
    3606:	8b c8                	mov    cx,ax
    3608:	8b da                	mov    bx,dx
    360a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    360d:	99                   	cwd
    360e:	9a 5c 17 1b 36       	call   0x361b:0x175c
    3613:	b9 64 00             	mov    cx,0x64
    3616:	31 db                	xor    bx,bx
    3618:	9a 70 16 35 36       	call   0x3635:0x1670
    361d:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3620:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    3623:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3626:	99                   	cwd
    3627:	52                   	push   dx
    3628:	50                   	push   ax
    3629:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    362c:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    362f:	bf d0 33             	mov    di,0x33d0
    3632:	9a 16 04 8b 36       	call   0x368b:0x416
    3637:	50                   	push   ax
    3638:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    363b:	06                   	push   es
    363c:	57                   	push   di
    363d:	9a a3 74 5a 36       	call   0x365a:0x74a3
    3642:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3645:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    3648:	75 80                	jne    0x35ca
    364a:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    364d:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    3652:	99                   	cwd
    3653:	52                   	push   dx
    3654:	50                   	push   ax
    3655:	06                   	push   es
    3656:	57                   	push   di
    3657:	9a 45 73 6c 36       	call   0x366c:0x7345
    365c:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    365f:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    3664:	99                   	cwd
    3665:	52                   	push   dx
    3666:	50                   	push   ax
    3667:	06                   	push   es
    3668:	57                   	push   di
    3669:	9a dd 75 35 40       	call   0x4035:0x75dd
    366e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3671:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    3676:	89 7e ea             	mov    WORD PTR [bp-0x16],di
    3679:	8c 46 ec             	mov    WORD PTR [bp-0x14],es
    367c:	06                   	push   es
    367d:	57                   	push   di
    367e:	9a 26 13 ac 36       	call   0x36ac:0x1326
    3683:	2d 01 00             	sub    ax,0x1
    3686:	71 05                	jno    0x368d
    3688:	9a 3e 04 04 37       	call   0x3704:0x43e
    368d:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3690:	31 c0                	xor    ax,ax
    3692:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    3695:	7f 2a                	jg     0x36c1
    3697:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    369a:	eb 03                	jmp    0x369f
    369c:	ff 46 ee             	inc    WORD PTR [bp-0x12]
    369f:	6a 00                	push   0x0
    36a1:	ff 76 ee             	push   WORD PTR [bp-0x12]
    36a4:	c4 7e ea             	les    di,DWORD PTR [bp-0x16]
    36a7:	06                   	push   es
    36a8:	57                   	push   di
    36a9:	9a 53 13 b7 36       	call   0x36b7:0x1353
    36ae:	89 c7                	mov    di,ax
    36b0:	8e c2                	mov    es,dx
    36b2:	06                   	push   es
    36b3:	57                   	push   di
    36b4:	9a 75 12 a3 37       	call   0x37a3:0x1275
    36b9:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    36bc:	3b 46 e8             	cmp    ax,WORD PTR [bp-0x18]
    36bf:	75 db                	jne    0x369c
    36c1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    36c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36c7:	26 ff b5 9c 03       	push   WORD PTR es:[di+0x39c]
    36cc:	06                   	push   es
    36cd:	57                   	push   di
    36ce:	9a f4 5d 11 3c       	call   0x3c11:0x5df4
    36d3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36d9:	26 89 85 9c 03       	mov    WORD PTR es:[di+0x39c],ax
    36de:	26 83 bd 9c 03 64    	cmp    WORD PTR es:[di+0x39c],0x64
    36e4:	7d 12                	jge    0x36f8
    36e6:	6a 18                	push   0x18
    36e8:	26 c4 bd 20 03       	les    di,DWORD PTR es:[di+0x320]
    36ed:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    36f1:	06                   	push   es
    36f2:	57                   	push   di
    36f3:	9a f5 11 eb 38       	call   0x38eb:0x11f5
    36f8:	c9                   	leave
    36f9:	ca 08 00             	retf   0x8
    36fc:	55                   	push   bp
    36fd:	89 e5                	mov    bp,sp
    36ff:	31 c0                	xor    ax,ax
    3701:	9a 44 04 1c 37       	call   0x371c:0x444
    3706:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3709:	06                   	push   es
    370a:	57                   	push   di
    370b:	9a 56 55 30 37       	call   0x3730:0x5556
    3710:	c9                   	leave
    3711:	ca 08 00             	retf   0x8
    3714:	55                   	push   bp
    3715:	89 e5                	mov    bp,sp
    3717:	31 c0                	xor    ax,ax
    3719:	9a 44 04 4d 37       	call   0x374d:0x444
    371e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3721:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    3727:	75 0b                	jne    0x3734
    3729:	6a 00                	push   0x0
    372b:	06                   	push   es
    372c:	57                   	push   di
    372d:	9a 14 3a 3e 37       	call   0x373e:0x3a14
    3732:	eb 0c                	jmp    0x3740
    3734:	6a 02                	push   0x2
    3736:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3739:	06                   	push   es
    373a:	57                   	push   di
    373b:	9a 14 3a e2 58       	call   0x58e2:0x3a14
    3740:	c9                   	leave
    3741:	ca 08 00             	retf   0x8
    3744:	55                   	push   bp
    3745:	89 e5                	mov    bp,sp
    3747:	b8 02 00             	mov    ax,0x2
    374a:	9a 44 04 5d 37       	call   0x375d:0x444
    374f:	83 ec 02             	sub    sp,0x2
    3752:	a1 4c 01             	mov    ax,ds:0x14c
    3755:	2d 01 00             	sub    ax,0x1
    3758:	71 05                	jno    0x375f
    375a:	9a 3e 04 94 37       	call   0x3794:0x43e
    375f:	50                   	push   ax
    3760:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3763:	26 ff b5 9f 03       	push   WORD PTR es:[di+0x39f]
    3768:	9a 32 3e 61 38       	call   0x3861:0x3e32
    376d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3770:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3773:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3776:	26 3b 85 9f 03       	cmp    ax,WORD PTR es:[di+0x39f]
    377b:	74 0a                	je     0x3787
    377d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3780:	06                   	push   es
    3781:	57                   	push   di
    3782:	9a ca 14 7b 38       	call   0x387b:0x14ca
    3787:	c9                   	leave
    3788:	ca 08 00             	retf   0x8
    378b:	55                   	push   bp
    378c:	89 e5                	mov    bp,sp
    378e:	b8 08 00             	mov    ax,0x8
    3791:	9a 44 04 aa 37       	call   0x37aa:0x444
    3796:	83 ec 08             	sub    sp,0x8
    3799:	ff 76 0c             	push   WORD PTR [bp+0xc]
    379c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    379f:	bf 94 00             	mov    di,0x94
    37a2:	b8 bd 37             	mov    ax,0x37bd
    37a5:	50                   	push   ax
    37a6:	57                   	push   di
    37a7:	9a 55 22 c4 37       	call   0x37c4:0x2255
    37ac:	08 c0                	or     al,al
    37ae:	75 03                	jne    0x37b3
    37b0:	e9 ca 00             	jmp    0x387d
    37b3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    37b6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    37b9:	bf 94 00             	mov    di,0x94
    37bc:	b8 df 37             	mov    ax,0x37df
    37bf:	50                   	push   ax
    37c0:	57                   	push   di
    37c1:	9a 73 22 e6 37       	call   0x37e6:0x2273
    37c6:	89 c7                	mov    di,ax
    37c8:	8e c2                	mov    es,dx
    37ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37cd:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    37d2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    37d5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    37d8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    37db:	bf 94 00             	mov    di,0x94
    37de:	b8 f7 37             	mov    ax,0x37f7
    37e1:	50                   	push   ax
    37e2:	57                   	push   di
    37e3:	9a 73 22 07 38       	call   0x3807:0x2273
    37e8:	52                   	push   dx
    37e9:	50                   	push   ax
    37ea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37ed:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    37f2:	06                   	push   es
    37f3:	57                   	push   di
    37f4:	9a 2b 16 9a 5c       	call   0x5c9a:0x162b
    37f9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    37fc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    37ff:	05 01 00             	add    ax,0x1
    3802:	71 05                	jno    0x3809
    3804:	9a 3e 04 3b 38       	call   0x383b:0x43e
    3809:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    380d:	b0 00                	mov    al,0x0
    380f:	7d 01                	jge    0x3812
    3811:	40                   	inc    ax
    3812:	8a c8                	mov    cl,al
    3814:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    3818:	b0 00                	mov    al,0x0
    381a:	7d 01                	jge    0x381d
    381c:	40                   	inc    ax
    381d:	8a d0                	mov    dl,al
    381f:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    3823:	b0 00                	mov    al,0x0
    3825:	7c 01                	jl     0x3828
    3827:	40                   	inc    ax
    3828:	22 c2                	and    al,dl
    382a:	22 c1                	and    al,cl
    382c:	08 c0                	or     al,al
    382e:	74 12                	je     0x3842
    3830:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3833:	05 01 00             	add    ax,0x1
    3836:	71 05                	jno    0x383d
    3838:	9a 3e 04 53 38       	call   0x3853:0x43e
    383d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3840:	eb 24                	jmp    0x3866
    3842:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    3846:	75 1e                	jne    0x3866
    3848:	a1 4c 01             	mov    ax,ds:0x14c
    384b:	2d 01 00             	sub    ax,0x1
    384e:	71 05                	jno    0x3855
    3850:	9a 3e 04 89 38       	call   0x3889:0x43e
    3855:	50                   	push   ax
    3856:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3859:	26 ff b5 9f 03       	push   WORD PTR es:[di+0x39f]
    385e:	9a 32 3e ff ff       	call   0xffff:0x3e32
    3863:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3866:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3869:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    386c:	26 3b 85 9f 03       	cmp    ax,WORD PTR es:[di+0x39f]
    3871:	74 0a                	je     0x387d
    3873:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3876:	06                   	push   es
    3877:	57                   	push   di
    3878:	9a ca 14 bb 38       	call   0x38bb:0x14ca
    387d:	c9                   	leave
    387e:	ca 08 00             	retf   0x8
    3881:	55                   	push   bp
    3882:	89 e5                	mov    bp,sp
    3884:	31 c0                	xor    ax,ax
    3886:	9a 44 04 9e 38       	call   0x389e:0x444
    388b:	6a 00                	push   0x0
    388d:	9a ff ff 00 00       	call   0x0:0xffff
    3892:	c9                   	leave
    3893:	ca 08 00             	retf   0x8
    3896:	55                   	push   bp
    3897:	89 e5                	mov    bp,sp
    3899:	31 c0                	xor    ax,ax
    389b:	9a 44 04 d2 38       	call   0x38d2:0x444
    38a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38a3:	26 c4 bd 08 02       	les    di,DWORD PTR es:[di+0x208]
    38a8:	06                   	push   es
    38a9:	57                   	push   di
    38aa:	9a 17 2f ff ff       	call   0xffff:0x2f17
    38af:	08 c0                	or     al,al
    38b1:	74 0a                	je     0x38bd
    38b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38b6:	06                   	push   es
    38b7:	57                   	push   di
    38b8:	9a 25 39 23 39       	call   0x3923:0x3925
    38bd:	c9                   	leave
    38be:	ca 08 00             	retf   0x8
    38c1:	00 00                	add    BYTE PTR [bx+si],al
    38c3:	00 00                	add    BYTE PTR [bx+si],al
    38c5:	ff                   	(bad)
    38c6:	ff 00                	inc    WORD PTR [bx+si]
    38c8:	00 55 89             	add    BYTE PTR [di-0x77],dl
    38cb:	e5 b8                	in     ax,0xb8
    38cd:	22 00                	and    al,BYTE PTR [bx+si]
    38cf:	9a 44 04 02 39       	call   0x3902:0x444
    38d4:	83 ec 22             	sub    sp,0x22
    38d7:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    38db:	06                   	push   es
    38dc:	57                   	push   di
    38dd:	9a 04 2a 60 39       	call   0x3960:0x2a04
    38e2:	89 c7                	mov    di,ax
    38e4:	8e c2                	mov    es,dx
    38e6:	06                   	push   es
    38e7:	57                   	push   di
    38e8:	9a d2 21 b1 39       	call   0x39b1:0x21d2
    38ed:	50                   	push   ax
    38ee:	8d 7e de             	lea    di,[bp-0x22]
    38f1:	16                   	push   ss
    38f2:	57                   	push   di
    38f3:	9a ff ff 00 00       	call   0x0:0xffff
    38f8:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    38fb:	99                   	cwd
    38fc:	bf c1 38             	mov    di,0x38c1
    38ff:	9a 16 04 2e 39       	call   0x392e:0x416
    3904:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3907:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    390a:	c9                   	leave
    390b:	ca 02 00             	retf   0x2
    390e:	00 01                	add    BYTE PTR [bx+di],al
    3910:	09 01                	or     WORD PTR [bx+di],ax
    3912:	20 03                	and    BYTE PTR [bp+di],al
    3914:	20 20                	and    BYTE PTR [bx+si],ah
    3916:	20 00                	and    BYTE PTR [bx+si],al
    3918:	80 ff ff             	cmp    bh,0xff
    391b:	ff                   	(bad)
    391c:	7f 00                	jg     0x391e
    391e:	00 00                	add    BYTE PTR [bx+si],al
    3920:	00 1e 3e 55          	add    BYTE PTR ds:0x553e,bl
    3924:	39 55 89             	cmp    WORD PTR [di-0x77],dx
    3927:	e5 b8                	in     ax,0xb8
    3929:	16                   	push   ss
    392a:	04 9a                	add    al,0x9a
    392c:	44                   	inc    sp
    392d:	04 6b                	add    al,0x6b
    392f:	39 81 ec 16          	cmp    WORD PTR [bx+di+0x16ec],ax
    3933:	04 c4                	add    al,0xc4
    3935:	7e 06                	jle    0x393d
    3937:	26 8b 85 a3 03       	mov    ax,WORD PTR es:[di+0x3a3]
    393c:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    3940:	26 c7 85 a3 03 14 00 	mov    WORD PTR es:[di+0x3a3],0x14
    3947:	81 c7 1c 03          	add    di,0x31c
    394b:	06                   	push   es
    394c:	57                   	push   di
    394d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3950:	06                   	push   es
    3951:	57                   	push   di
    3952:	9a 58 28 08 3a       	call   0x3a08:0x2858
    3957:	8d be fc fe          	lea    di,[bp-0x104]
    395b:	16                   	push   ss
    395c:	57                   	push   di
    395d:	9a 4e 20 89 39       	call   0x3989:0x204e
    3962:	8d be fc fe          	lea    di,[bp-0x104]
    3966:	16                   	push   ss
    3967:	57                   	push   di
    3968:	9a f5 09 70 39       	call   0x3970:0x9f5
    396d:	9a 08 04 c3 39       	call   0x39c3:0x408
    3972:	b8 1f 39             	mov    ax,0x391f
    3975:	0e                   	push   cs
    3976:	50                   	push   ax
    3977:	55                   	push   bp
    3978:	ff 36 58 18          	push   WORD PTR ds:0x1858
    397c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3980:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3984:	06                   	push   es
    3985:	57                   	push   di
    3986:	9a 04 2a 15 3a       	call   0x3a15:0x2a04
    398b:	89 c7                	mov    di,ax
    398d:	8e c2                	mov    es,dx
    398f:	89 be ec fd          	mov    WORD PTR [bp-0x214],di
    3993:	8c 86 ee fd          	mov    WORD PTR [bp-0x212],es
    3997:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    399b:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    39a0:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    39a4:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    39a8:	c4 be ec fd          	les    di,DWORD PTR [bp-0x214]
    39ac:	06                   	push   es
    39ad:	57                   	push   di
    39ae:	9a 99 20 24 3a       	call   0x3a24:0x2099
    39b3:	a1 4e 01             	mov    ax,ds:0x14e
    39b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39b9:	26 03 85 a1 03       	add    ax,WORD PTR es:[di+0x3a1]
    39be:	71 05                	jno    0x39c5
    39c0:	9a 3e 04 cd 39       	call   0x39cd:0x43e
    39c5:	2d 01 00             	sub    ax,0x1
    39c8:	71 05                	jno    0x39cf
    39ca:	9a 3e 04 5c 3a       	call   0x3a5c:0x43e
    39cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39d2:	99                   	cwd
    39d3:	26 f7 bd a1 03       	idiv   WORD PTR es:[di+0x3a1]
    39d8:	89 86 f2 fd          	mov    WORD PTR [bp-0x20e],ax
    39dc:	8b 86 f2 fd          	mov    ax,WORD PTR [bp-0x20e]
    39e0:	89 86 ee fd          	mov    WORD PTR [bp-0x212],ax
    39e4:	b8 01 00             	mov    ax,0x1
    39e7:	3b 86 ee fd          	cmp    ax,WORD PTR [bp-0x212]
    39eb:	7e 03                	jle    0x39f0
    39ed:	e9 22 04             	jmp    0x3e12
    39f0:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    39f4:	eb 04                	jmp    0x39fa
    39f6:	ff 86 f0 fd          	inc    WORD PTR [bp-0x210]
    39fa:	6a 01                	push   0x1
    39fc:	ff b6 f0 fd          	push   WORD PTR [bp-0x210]
    3a00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a03:	06                   	push   es
    3a04:	57                   	push   di
    3a05:	9a 0d 43 d4 3b       	call   0x3bd4:0x430d
    3a0a:	6a 08                	push   0x8
    3a0c:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3a10:	06                   	push   es
    3a11:	57                   	push   di
    3a12:	9a 04 2a 31 3a       	call   0x3a31:0x2a04
    3a17:	89 c7                	mov    di,ax
    3a19:	8e c2                	mov    es,dx
    3a1b:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    3a1f:	06                   	push   es
    3a20:	57                   	push   di
    3a21:	9a f5 11 40 3a       	call   0x3a40:0x11f5
    3a26:	6a 02                	push   0x2
    3a28:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3a2c:	06                   	push   es
    3a2d:	57                   	push   di
    3a2e:	9a 04 2a a3 3b       	call   0x3ba3:0x2a04
    3a33:	89 c7                	mov    di,ax
    3a35:	8e c2                	mov    es,dx
    3a37:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    3a3b:	06                   	push   es
    3a3c:	57                   	push   di
    3a3d:	9a 78 12 b2 3b       	call   0x3bb2:0x1278
    3a42:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    3a47:	eb 03                	jmp    0x3a4c
    3a49:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3a4c:	8d be fc fe          	lea    di,[bp-0x104]
    3a50:	16                   	push   ss
    3a51:	57                   	push   di
    3a52:	bf 0e 39             	mov    di,0x390e
    3a55:	0e                   	push   cs
    3a56:	57                   	push   di
    3a57:	6a 00                	push   0x0
    3a59:	9a b5 0d 61 3a       	call   0x3a61:0xdb5
    3a5e:	9a 78 0c 66 3a       	call   0x3a66:0xc78
    3a63:	9a 08 04 94 3a       	call   0x3a94:0x408
    3a68:	83 7e fe 02          	cmp    WORD PTR [bp-0x2],0x2
    3a6c:	75 db                	jne    0x3a49
    3a6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a71:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    3a76:	89 be ea fd          	mov    WORD PTR [bp-0x216],di
    3a7a:	8c 86 ec fd          	mov    WORD PTR [bp-0x214],es
    3a7e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3a83:	06                   	push   es
    3a84:	57                   	push   di
    3a85:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a88:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3a8c:	2d 01 00             	sub    ax,0x1
    3a8f:	71 05                	jno    0x3a96
    3a91:	9a 3e 04 d4 3a       	call   0x3ad4:0x43e
    3a96:	89 86 e8 fd          	mov    WORD PTR [bp-0x218],ax
    3a9a:	31 c0                	xor    ax,ax
    3a9c:	3b 86 e8 fd          	cmp    ax,WORD PTR [bp-0x218]
    3aa0:	7e 03                	jle    0x3aa5
    3aa2:	e9 c8 00             	jmp    0x3b6d
    3aa5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3aa8:	eb 03                	jmp    0x3aad
    3aaa:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3aad:	8d be e8 fc          	lea    di,[bp-0x318]
    3ab1:	16                   	push   ss
    3ab2:	57                   	push   di
    3ab3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3ab6:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3aba:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3abf:	06                   	push   es
    3ac0:	57                   	push   di
    3ac1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ac4:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    3ac8:	8d be fc fd          	lea    di,[bp-0x204]
    3acc:	16                   	push   ss
    3acd:	57                   	push   di
    3ace:	68 ff 00             	push   0xff
    3ad1:	9a e7 17 e4 3a       	call   0x3ae4:0x17e7
    3ad6:	bf 0f 39             	mov    di,0x390f
    3ad9:	0e                   	push   cs
    3ada:	57                   	push   di
    3adb:	8d be fc fd          	lea    di,[bp-0x204]
    3adf:	16                   	push   ss
    3ae0:	57                   	push   di
    3ae1:	9a 78 18 fd 3a       	call   0x3afd:0x1878
    3ae6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3ae9:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    3aed:	7e 26                	jle    0x3b15
    3aef:	8d be fc fd          	lea    di,[bp-0x204]
    3af3:	16                   	push   ss
    3af4:	57                   	push   di
    3af5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3af8:	6a 01                	push   0x1
    3afa:	9a 75 19 13 3b       	call   0x3b13:0x1975
    3aff:	bf 11 39             	mov    di,0x3911
    3b02:	0e                   	push   cs
    3b03:	57                   	push   di
    3b04:	8d be fc fd          	lea    di,[bp-0x204]
    3b08:	16                   	push   ss
    3b09:	57                   	push   di
    3b0a:	68 ff 00             	push   0xff
    3b0d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3b10:	9a 16 19 29 3b       	call   0x3b29:0x1916
    3b15:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    3b19:	75 bb                	jne    0x3ad6
    3b1b:	8d be e8 fc          	lea    di,[bp-0x318]
    3b1f:	16                   	push   ss
    3b20:	57                   	push   di
    3b21:	bf 13 39             	mov    di,0x3913
    3b24:	0e                   	push   cs
    3b25:	57                   	push   di
    3b26:	9a cd 17 34 3b       	call   0x3b34:0x17cd
    3b2b:	8d be fc fd          	lea    di,[bp-0x204]
    3b2f:	16                   	push   ss
    3b30:	57                   	push   di
    3b31:	9a 4c 18 42 3b       	call   0x3b42:0x184c
    3b36:	8d be fc fd          	lea    di,[bp-0x204]
    3b3a:	16                   	push   ss
    3b3b:	57                   	push   di
    3b3c:	68 ff 00             	push   0xff
    3b3f:	9a e7 17 55 3b       	call   0x3b55:0x17e7
    3b44:	8d be fc fe          	lea    di,[bp-0x104]
    3b48:	16                   	push   ss
    3b49:	57                   	push   di
    3b4a:	8d be fc fd          	lea    di,[bp-0x204]
    3b4e:	16                   	push   ss
    3b4f:	57                   	push   di
    3b50:	6a 00                	push   0x0
    3b52:	9a b5 0d 5a 3b       	call   0x3b5a:0xdb5
    3b57:	9a 78 0c 5f 3b       	call   0x3b5f:0xc78
    3b5c:	9a 08 04 de 3b       	call   0x3bde:0x408
    3b61:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3b64:	3b 86 e8 fd          	cmp    ax,WORD PTR [bp-0x218]
    3b68:	74 03                	je     0x3b6d
    3b6a:	e9 3d ff             	jmp    0x3aaa
    3b6d:	8b 86 f0 fd          	mov    ax,WORD PTR [bp-0x210]
    3b71:	3b 86 f2 fd          	cmp    ax,WORD PTR [bp-0x20e]
    3b75:	b0 00                	mov    al,0x0
    3b77:	75 01                	jne    0x3b7a
    3b79:	40                   	inc    ax
    3b7a:	8a d0                	mov    dl,al
    3b7c:	8a 86 f0 fd          	mov    al,BYTE PTR [bp-0x210]
    3b80:	d0 e8                	shr    al,1
    3b82:	b0 00                	mov    al,0x0
    3b84:	72 01                	jb     0x3b87
    3b86:	40                   	inc    ax
    3b87:	0a c2                	or     al,dl
    3b89:	08 c0                	or     al,al
    3b8b:	75 03                	jne    0x3b90
    3b8d:	e9 75 02             	jmp    0x3e05
    3b90:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    3b94:	89 be ea fd          	mov    WORD PTR [bp-0x216],di
    3b98:	8c 86 ec fd          	mov    WORD PTR [bp-0x214],es
    3b9c:	6a 06                	push   0x6
    3b9e:	06                   	push   es
    3b9f:	57                   	push   di
    3ba0:	9a 04 2a bf 3b       	call   0x3bbf:0x2a04
    3ba5:	89 c7                	mov    di,ax
    3ba7:	8e c2                	mov    es,dx
    3ba9:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    3bad:	06                   	push   es
    3bae:	57                   	push   di
    3baf:	9a f5 11 ce 3b       	call   0x3bce:0x11f5
    3bb4:	6a 00                	push   0x0
    3bb6:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3bba:	06                   	push   es
    3bbb:	57                   	push   di
    3bbc:	9a 04 2a 42 3c       	call   0x3c42:0x2a04
    3bc1:	89 c7                	mov    di,ax
    3bc3:	8e c2                	mov    es,dx
    3bc5:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    3bc9:	06                   	push   es
    3bca:	57                   	push   di
    3bcb:	9a 78 12 69 3c       	call   0x3c69:0x1278
    3bd0:	55                   	push   bp
    3bd1:	9a c9 38 57 3e       	call   0x3e57:0x38c9
    3bd6:	05 02 00             	add    ax,0x2
    3bd9:	73 05                	jae    0x3be0
    3bdb:	9a 3e 04 e8 3b       	call   0x3be8:0x43e
    3be0:	31 d2                	xor    dx,dx
    3be2:	bf 17 39             	mov    di,0x3917
    3be5:	9a 16 04 fc 3b       	call   0x3bfc:0x416
    3bea:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    3bee:	8d be ea fb          	lea    di,[bp-0x416]
    3bf2:	16                   	push   ss
    3bf3:	57                   	push   di
    3bf4:	bf 13 39             	mov    di,0x3913
    3bf7:	0e                   	push   cs
    3bf8:	57                   	push   di
    3bf9:	9a cd 17 16 3c       	call   0x3c16:0x17cd
    3bfe:	8d be ea fc          	lea    di,[bp-0x316]
    3c02:	16                   	push   ss
    3c03:	57                   	push   di
    3c04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c07:	26 c4 bd 84 02       	les    di,DWORD PTR es:[di+0x284]
    3c0c:	06                   	push   es
    3c0d:	57                   	push   di
    3c0e:	9a 53 1d 8e 3c       	call   0x3c8e:0x1d53
    3c13:	9a 4c 18 24 3c       	call   0x3c24:0x184c
    3c18:	8d be fc fd          	lea    di,[bp-0x204]
    3c1c:	16                   	push   ss
    3c1d:	57                   	push   di
    3c1e:	68 ff 00             	push   0xff
    3c21:	9a e7 17 36 3c       	call   0x3c36:0x17e7
    3c26:	6a 00                	push   0x0
    3c28:	8b 86 f8 fd          	mov    ax,WORD PTR [bp-0x208]
    3c2c:	b9 05 00             	mov    cx,0x5
    3c2f:	f7 e9                	imul   cx
    3c31:	71 05                	jno    0x3c38
    3c33:	9a 3e 04 4c 3c       	call   0x3c4c:0x43e
    3c38:	50                   	push   ax
    3c39:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3c3d:	06                   	push   es
    3c3e:	57                   	push   di
    3c3f:	9a 72 2a 5e 3c       	call   0x3c5e:0x2a72
    3c44:	5a                   	pop    dx
    3c45:	2b c2                	sub    ax,dx
    3c47:	71 05                	jno    0x3c4e
    3c49:	9a 3e 04 79 3c       	call   0x3c79:0x43e
    3c4e:	50                   	push   ax
    3c4f:	8d be fc fd          	lea    di,[bp-0x204]
    3c53:	16                   	push   ss
    3c54:	57                   	push   di
    3c55:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3c59:	06                   	push   es
    3c5a:	57                   	push   di
    3c5b:	9a 04 2a bf 3c       	call   0x3cbf:0x2a04
    3c60:	89 c7                	mov    di,ax
    3c62:	8e c2                	mov    es,dx
    3c64:	06                   	push   es
    3c65:	57                   	push   di
    3c66:	9a 09 1f e6 3c       	call   0x3ce6:0x1f09
    3c6b:	8d be ea fb          	lea    di,[bp-0x416]
    3c6f:	16                   	push   ss
    3c70:	57                   	push   di
    3c71:	bf 13 39             	mov    di,0x3913
    3c74:	0e                   	push   cs
    3c75:	57                   	push   di
    3c76:	9a cd 17 93 3c       	call   0x3c93:0x17cd
    3c7b:	8d be ea fc          	lea    di,[bp-0x316]
    3c7f:	16                   	push   ss
    3c80:	57                   	push   di
    3c81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c84:	26 c4 bd 88 02       	les    di,DWORD PTR es:[di+0x288]
    3c89:	06                   	push   es
    3c8a:	57                   	push   di
    3c8b:	9a 53 1d 0b 3d       	call   0x3d0b:0x1d53
    3c90:	9a 4c 18 a1 3c       	call   0x3ca1:0x184c
    3c95:	8d be fc fd          	lea    di,[bp-0x204]
    3c99:	16                   	push   ss
    3c9a:	57                   	push   di
    3c9b:	68 ff 00             	push   0xff
    3c9e:	9a e7 17 b3 3c       	call   0x3cb3:0x17e7
    3ca3:	6a 00                	push   0x0
    3ca5:	8b 86 f8 fd          	mov    ax,WORD PTR [bp-0x208]
    3ca9:	b9 04 00             	mov    cx,0x4
    3cac:	f7 e9                	imul   cx
    3cae:	71 05                	jno    0x3cb5
    3cb0:	9a 3e 04 c9 3c       	call   0x3cc9:0x43e
    3cb5:	50                   	push   ax
    3cb6:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3cba:	06                   	push   es
    3cbb:	57                   	push   di
    3cbc:	9a 72 2a db 3c       	call   0x3cdb:0x2a72
    3cc1:	5a                   	pop    dx
    3cc2:	2b c2                	sub    ax,dx
    3cc4:	71 05                	jno    0x3ccb
    3cc6:	9a 3e 04 f6 3c       	call   0x3cf6:0x43e
    3ccb:	50                   	push   ax
    3ccc:	8d be fc fd          	lea    di,[bp-0x204]
    3cd0:	16                   	push   ss
    3cd1:	57                   	push   di
    3cd2:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3cd6:	06                   	push   es
    3cd7:	57                   	push   di
    3cd8:	9a 04 2a 3c 3d       	call   0x3d3c:0x2a04
    3cdd:	89 c7                	mov    di,ax
    3cdf:	8e c2                	mov    es,dx
    3ce1:	06                   	push   es
    3ce2:	57                   	push   di
    3ce3:	9a 09 1f 63 3d       	call   0x3d63:0x1f09
    3ce8:	8d be ea fb          	lea    di,[bp-0x416]
    3cec:	16                   	push   ss
    3ced:	57                   	push   di
    3cee:	bf 13 39             	mov    di,0x3913
    3cf1:	0e                   	push   cs
    3cf2:	57                   	push   di
    3cf3:	9a cd 17 10 3d       	call   0x3d10:0x17cd
    3cf8:	8d be ea fc          	lea    di,[bp-0x316]
    3cfc:	16                   	push   ss
    3cfd:	57                   	push   di
    3cfe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d01:	26 c4 bd 8c 02       	les    di,DWORD PTR es:[di+0x28c]
    3d06:	06                   	push   es
    3d07:	57                   	push   di
    3d08:	9a 53 1d 88 3d       	call   0x3d88:0x1d53
    3d0d:	9a 4c 18 1e 3d       	call   0x3d1e:0x184c
    3d12:	8d be fc fd          	lea    di,[bp-0x204]
    3d16:	16                   	push   ss
    3d17:	57                   	push   di
    3d18:	68 ff 00             	push   0xff
    3d1b:	9a e7 17 30 3d       	call   0x3d30:0x17e7
    3d20:	6a 00                	push   0x0
    3d22:	8b 86 f8 fd          	mov    ax,WORD PTR [bp-0x208]
    3d26:	b9 03 00             	mov    cx,0x3
    3d29:	f7 e9                	imul   cx
    3d2b:	71 05                	jno    0x3d32
    3d2d:	9a 3e 04 46 3d       	call   0x3d46:0x43e
    3d32:	50                   	push   ax
    3d33:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3d37:	06                   	push   es
    3d38:	57                   	push   di
    3d39:	9a 72 2a 58 3d       	call   0x3d58:0x2a72
    3d3e:	5a                   	pop    dx
    3d3f:	2b c2                	sub    ax,dx
    3d41:	71 05                	jno    0x3d48
    3d43:	9a 3e 04 73 3d       	call   0x3d73:0x43e
    3d48:	50                   	push   ax
    3d49:	8d be fc fd          	lea    di,[bp-0x204]
    3d4d:	16                   	push   ss
    3d4e:	57                   	push   di
    3d4f:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3d53:	06                   	push   es
    3d54:	57                   	push   di
    3d55:	9a 04 2a b9 3d       	call   0x3db9:0x2a04
    3d5a:	89 c7                	mov    di,ax
    3d5c:	8e c2                	mov    es,dx
    3d5e:	06                   	push   es
    3d5f:	57                   	push   di
    3d60:	9a 09 1f e0 3d       	call   0x3de0:0x1f09
    3d65:	8d be ea fb          	lea    di,[bp-0x416]
    3d69:	16                   	push   ss
    3d6a:	57                   	push   di
    3d6b:	bf 13 39             	mov    di,0x3913
    3d6e:	0e                   	push   cs
    3d6f:	57                   	push   di
    3d70:	9a cd 17 8d 3d       	call   0x3d8d:0x17cd
    3d75:	8d be ea fc          	lea    di,[bp-0x316]
    3d79:	16                   	push   ss
    3d7a:	57                   	push   di
    3d7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d7e:	26 c4 bd 90 02       	les    di,DWORD PTR es:[di+0x290]
    3d83:	06                   	push   es
    3d84:	57                   	push   di
    3d85:	9a 53 1d 49 3f       	call   0x3f49:0x1d53
    3d8a:	9a 4c 18 9b 3d       	call   0x3d9b:0x184c
    3d8f:	8d be fc fd          	lea    di,[bp-0x204]
    3d93:	16                   	push   ss
    3d94:	57                   	push   di
    3d95:	68 ff 00             	push   0xff
    3d98:	9a e7 17 ad 3d       	call   0x3dad:0x17e7
    3d9d:	6a 00                	push   0x0
    3d9f:	8b 86 f8 fd          	mov    ax,WORD PTR [bp-0x208]
    3da3:	b9 02 00             	mov    cx,0x2
    3da6:	f7 e9                	imul   cx
    3da8:	71 05                	jno    0x3daf
    3daa:	9a 3e 04 c3 3d       	call   0x3dc3:0x43e
    3daf:	50                   	push   ax
    3db0:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3db4:	06                   	push   es
    3db5:	57                   	push   di
    3db6:	9a 72 2a d5 3d       	call   0x3dd5:0x2a72
    3dbb:	5a                   	pop    dx
    3dbc:	2b c2                	sub    ax,dx
    3dbe:	71 05                	jno    0x3dc5
    3dc0:	9a 3e 04 f9 3d       	call   0x3df9:0x43e
    3dc5:	50                   	push   ax
    3dc6:	8d be fc fd          	lea    di,[bp-0x204]
    3dca:	16                   	push   ss
    3dcb:	57                   	push   di
    3dcc:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    3dd0:	06                   	push   es
    3dd1:	57                   	push   di
    3dd2:	9a 04 2a ff ff       	call   0xffff:0x2a04
    3dd7:	89 c7                	mov    di,ax
    3dd9:	8e c2                	mov    es,dx
    3ddb:	06                   	push   es
    3ddc:	57                   	push   di
    3ddd:	9a 09 1f ff ff       	call   0xffff:0x1f09
    3de2:	8b 86 f0 fd          	mov    ax,WORD PTR [bp-0x210]
    3de6:	3b 86 f2 fd          	cmp    ax,WORD PTR [bp-0x20e]
    3dea:	7d 19                	jge    0x3e05
    3dec:	8d be fc fe          	lea    di,[bp-0x104]
    3df0:	16                   	push   ss
    3df1:	57                   	push   di
    3df2:	6a 0c                	push   0xc
    3df4:	6a 00                	push   0x0
    3df6:	9a 25 0d fe 3d       	call   0x3dfe:0xd25
    3dfb:	9a 78 0c 03 3e       	call   0x3e03:0xc78
    3e00:	9a 08 04 27 3e       	call   0x3e27:0x408
    3e05:	8b 86 f0 fd          	mov    ax,WORD PTR [bp-0x210]
    3e09:	3b 86 ee fd          	cmp    ax,WORD PTR [bp-0x212]
    3e0d:	74 03                	je     0x3e12
    3e0f:	e9 e4 fb             	jmp    0x39f6
    3e12:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3e16:	83 c4 06             	add    sp,0x6
    3e19:	b8 5a 3e             	mov    ax,0x3e5a
    3e1c:	0e                   	push   cs
    3e1d:	50                   	push   ax
    3e1e:	8d be fc fe          	lea    di,[bp-0x104]
    3e22:	16                   	push   ss
    3e23:	57                   	push   di
    3e24:	9a 4f 0a 2c 3e       	call   0x3e2c:0xa4f
    3e29:	9a 08 04 92 3e       	call   0x3e92:0x408
    3e2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e31:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    3e36:	06                   	push   es
    3e37:	57                   	push   di
    3e38:	9a e3 49 99 43       	call   0x4399:0x49e3
    3e3d:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    3e41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e44:	26 89 85 a3 03       	mov    WORD PTR es:[di+0x3a3],ax
    3e49:	81 c7 1c 03          	add    di,0x31c
    3e4d:	06                   	push   es
    3e4e:	57                   	push   di
    3e4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e52:	06                   	push   es
    3e53:	57                   	push   di
    3e54:	9a 58 28 87 3e       	call   0x3e87:0x2858
    3e59:	cb                   	retf
    3e5a:	c9                   	leave
    3e5b:	ca 04 00             	retf   0x4
    3e5e:	01 09                	add    WORD PTR [bx+di],cx
    3e60:	01 0d                	add    WORD PTR [di],cx
    3e62:	01 0a                	add    WORD PTR [bp+si],cx
    3e64:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    3e68:	ff                   	(bad)
    3e69:	7f 00                	jg     0x3e6b
    3e6b:	00 02                	add    BYTE PTR [bp+si],al
    3e6d:	23 56 02             	and    dx,WORD PTR [bp+0x2]
    3e70:	23 43 02             	and    ax,WORD PTR [bp+di+0x2]
    3e73:	23 41 02             	and    ax,WORD PTR [bx+di+0x2]
    3e76:	23 26 00 00          	and    sp,WORD PTR ds:0x0
    3e7a:	00 00                	add    BYTE PTR [bx+si],al
    3e7c:	ff 00                	inc    WORD PTR [bx+si]
    3e7e:	00 00                	add    BYTE PTR [bx+si],al
    3e80:	02 0d                	add    cl,BYTE PTR [di]
    3e82:	0a 00                	or     al,BYTE PTR [bx+si]
    3e84:	00 ad 42 dd          	add    BYTE PTR [di-0x22be],ch
    3e88:	3e 55                	ds push bp
    3e8a:	89 e5                	mov    bp,sp
    3e8c:	b8 14 03             	mov    ax,0x314
    3e8f:	9a 44 04 9b 3e       	call   0x3e9b:0x444
    3e94:	81 ec 14 03          	sub    sp,0x314
    3e98:	9a ea 01 e5 3e       	call   0x3ee5:0x1ea
    3e9d:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    3ea1:	89 96 f0 fe          	mov    WORD PTR [bp-0x110],dx
    3ea5:	83 be f0 fe 00       	cmp    WORD PTR [bp-0x110],0x0
    3eaa:	7f 10                	jg     0x3ebc
    3eac:	7d 03                	jge    0x3eb1
    3eae:	e9 38 04             	jmp    0x42e9
    3eb1:	81 be ee fe 30 75    	cmp    WORD PTR [bp-0x112],0x7530
    3eb7:	77 03                	ja     0x3ebc
    3eb9:	e9 2d 04             	jmp    0x42e9
    3ebc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ebf:	26 8b 85 a3 03       	mov    ax,WORD PTR es:[di+0x3a3]
    3ec4:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    3ec8:	26 c7 85 a3 03 14 00 	mov    WORD PTR es:[di+0x3a3],0x14
    3ecf:	81 c7 1c 03          	add    di,0x31c
    3ed3:	06                   	push   es
    3ed4:	57                   	push   di
    3ed5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ed8:	06                   	push   es
    3ed9:	57                   	push   di
    3eda:	9a 58 28 e6 42       	call   0x42e6:0x2858
    3edf:	68 30 75             	push   0x7530
    3ee2:	9a 82 01 f4 3e       	call   0x3ef4:0x182
    3ee7:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    3eeb:	89 96 f8 fe          	mov    WORD PTR [bp-0x108],dx
    3eef:	6a 64                	push   0x64
    3ef1:	9a 82 01 2a 3f       	call   0x3f2a:0x182
    3ef6:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    3efa:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    3efe:	b8 83 3e             	mov    ax,0x3e83
    3f01:	0e                   	push   cs
    3f02:	50                   	push   ax
    3f03:	55                   	push   bp
    3f04:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3f08:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3f0c:	c4 be f6 fe          	les    di,DWORD PTR [bp-0x10a]
    3f10:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    3f14:	c4 be f2 fe          	les    di,DWORD PTR [bp-0x10e]
    3f18:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    3f1c:	8d be ec fd          	lea    di,[bp-0x214]
    3f20:	16                   	push   ss
    3f21:	57                   	push   di
    3f22:	bf fa 1d             	mov    di,0x1dfa
    3f25:	1e                   	push   ds
    3f26:	57                   	push   di
    3f27:	9a cd 17 34 3f       	call   0x3f34:0x17cd
    3f2c:	bf 5e 3e             	mov    di,0x3e5e
    3f2f:	0e                   	push   cs
    3f30:	57                   	push   di
    3f31:	9a 4c 18 4e 3f       	call   0x3f4e:0x184c
    3f36:	8d be ec fc          	lea    di,[bp-0x314]
    3f3a:	16                   	push   ss
    3f3b:	57                   	push   di
    3f3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f3f:	26 c4 bd 0c 03       	les    di,DWORD PTR es:[di+0x30c]
    3f44:	06                   	push   es
    3f45:	57                   	push   di
    3f46:	9a 53 1d c8 43       	call   0x43c8:0x1d53
    3f4b:	9a 4c 18 58 3f       	call   0x3f58:0x184c
    3f50:	bf 60 3e             	mov    di,0x3e60
    3f53:	0e                   	push   cs
    3f54:	57                   	push   di
    3f55:	9a 4c 18 62 3f       	call   0x3f62:0x184c
    3f5a:	bf 62 3e             	mov    di,0x3e62
    3f5d:	0e                   	push   cs
    3f5e:	57                   	push   di
    3f5f:	9a 4c 18 70 3f       	call   0x3f70:0x184c
    3f64:	8d be 00 ff          	lea    di,[bp-0x100]
    3f68:	16                   	push   ss
    3f69:	57                   	push   di
    3f6a:	68 ff 00             	push   0xff
    3f6d:	9a e7 17 bf 3f       	call   0x3fbf:0x17e7
    3f72:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    3f76:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    3f7a:	8d be 00 ff          	lea    di,[bp-0x100]
    3f7e:	16                   	push   ss
    3f7f:	57                   	push   di
    3f80:	9a 4c 0d 98 3f       	call   0x3f98:0xd4c
    3f85:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    3f89:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    3f8d:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    3f91:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    3f95:	9a 8f 0d 10 42       	call   0x4210:0xd8f
    3f9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f9d:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    3fa2:	89 be e8 fe          	mov    WORD PTR [bp-0x118],di
    3fa6:	8c 86 ea fe          	mov    WORD PTR [bp-0x116],es
    3faa:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    3faf:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    3fb4:	2d 01 00             	sub    ax,0x1
    3fb7:	83 da 00             	sbb    dx,0x0
    3fba:	71 05                	jno    0x3fc1
    3fbc:	9a 3e 04 c7 3f       	call   0x3fc7:0x43e
    3fc1:	bf 64 3e             	mov    di,0x3e64
    3fc4:	9a 16 04 fb 3f       	call   0x3ffb:0x416
    3fc9:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    3fcd:	31 c0                	xor    ax,ax
    3fcf:	3b 86 e6 fe          	cmp    ax,WORD PTR [bp-0x11a]
    3fd3:	7e 03                	jle    0x3fd8
    3fd5:	e9 a4 02             	jmp    0x427c
    3fd8:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    3fdc:	eb 04                	jmp    0x3fe2
    3fde:	ff 86 fc fe          	inc    WORD PTR [bp-0x104]
    3fe2:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    3fe6:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    3feb:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    3ff0:	2d 01 00             	sub    ax,0x1
    3ff3:	83 da 00             	sbb    dx,0x0
    3ff6:	71 05                	jno    0x3ffd
    3ff8:	9a 3e 04 03 40       	call   0x4003:0x43e
    3ffd:	bf 64 3e             	mov    di,0x3e64
    4000:	9a 16 04 43 40       	call   0x4043:0x416
    4005:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    4009:	31 c0                	xor    ax,ax
    400b:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    400f:	7e 03                	jle    0x4014
    4011:	e9 20 02             	jmp    0x4234
    4014:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    4018:	eb 04                	jmp    0x401e
    401a:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    401e:	8d be e4 fd          	lea    di,[bp-0x21c]
    4022:	16                   	push   ss
    4023:	57                   	push   di
    4024:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    4028:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    402c:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    4030:	06                   	push   es
    4031:	57                   	push   di
    4032:	9a 68 9a fa 44       	call   0x44fa:0x9a68
    4037:	8d be 00 ff          	lea    di,[bp-0x100]
    403b:	16                   	push   ss
    403c:	57                   	push   di
    403d:	68 ff 00             	push   0xff
    4040:	9a e7 17 53 40       	call   0x4053:0x17e7
    4045:	bf 6c 3e             	mov    di,0x3e6c
    4048:	0e                   	push   cs
    4049:	57                   	push   di
    404a:	8d be 00 ff          	lea    di,[bp-0x100]
    404e:	16                   	push   ss
    404f:	57                   	push   di
    4050:	9a 78 18 6f 40       	call   0x406f:0x1878
    4055:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    4059:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    405e:	7e 11                	jle    0x4071
    4060:	8d be 00 ff          	lea    di,[bp-0x100]
    4064:	16                   	push   ss
    4065:	57                   	push   di
    4066:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    406a:	6a 02                	push   0x2
    406c:	9a 75 19 86 40       	call   0x4086:0x1975
    4071:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    4076:	75 cd                	jne    0x4045
    4078:	bf 6f 3e             	mov    di,0x3e6f
    407b:	0e                   	push   cs
    407c:	57                   	push   di
    407d:	8d be 00 ff          	lea    di,[bp-0x100]
    4081:	16                   	push   ss
    4082:	57                   	push   di
    4083:	9a 78 18 a2 40       	call   0x40a2:0x1878
    4088:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    408c:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    4091:	7e 11                	jle    0x40a4
    4093:	8d be 00 ff          	lea    di,[bp-0x100]
    4097:	16                   	push   ss
    4098:	57                   	push   di
    4099:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    409d:	6a 03                	push   0x3
    409f:	9a 75 19 b9 40       	call   0x40b9:0x1975
    40a4:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    40a9:	75 cd                	jne    0x4078
    40ab:	bf 72 3e             	mov    di,0x3e72
    40ae:	0e                   	push   cs
    40af:	57                   	push   di
    40b0:	8d be 00 ff          	lea    di,[bp-0x100]
    40b4:	16                   	push   ss
    40b5:	57                   	push   di
    40b6:	9a 78 18 d5 40       	call   0x40d5:0x1878
    40bb:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    40bf:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    40c4:	7e 11                	jle    0x40d7
    40c6:	8d be 00 ff          	lea    di,[bp-0x100]
    40ca:	16                   	push   ss
    40cb:	57                   	push   di
    40cc:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    40d0:	6a 03                	push   0x3
    40d2:	9a 75 19 ec 40       	call   0x40ec:0x1975
    40d7:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    40dc:	75 cd                	jne    0x40ab
    40de:	bf 75 3e             	mov    di,0x3e75
    40e1:	0e                   	push   cs
    40e2:	57                   	push   di
    40e3:	8d be 00 ff          	lea    di,[bp-0x100]
    40e7:	16                   	push   ss
    40e8:	57                   	push   di
    40e9:	9a 78 18 08 41       	call   0x4108:0x1878
    40ee:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    40f2:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    40f7:	7e 2f                	jle    0x4128
    40f9:	8d be 00 ff          	lea    di,[bp-0x100]
    40fd:	16                   	push   ss
    40fe:	57                   	push   di
    40ff:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    4103:	6a 02                	push   0x2
    4105:	9a 75 19 26 41       	call   0x4126:0x1975
    410a:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    410f:	7e 17                	jle    0x4128
    4111:	bf 5e 3e             	mov    di,0x3e5e
    4114:	0e                   	push   cs
    4115:	57                   	push   di
    4116:	8d be 00 ff          	lea    di,[bp-0x100]
    411a:	16                   	push   ss
    411b:	57                   	push   di
    411c:	68 ff 00             	push   0xff
    411f:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    4123:	9a 16 19 58 41       	call   0x4158:0x1916
    4128:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    412d:	75 af                	jne    0x40de
    412f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4134:	b0 00                	mov    al,0x0
    4136:	76 01                	jbe    0x4139
    4138:	40                   	inc    ax
    4139:	8a d0                	mov    dl,al
    413b:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    4140:	b0 00                	mov    al,0x0
    4142:	75 01                	jne    0x4145
    4144:	40                   	inc    ax
    4145:	22 c2                	and    al,dl
    4147:	08 c0                	or     al,al
    4149:	74 11                	je     0x415c
    414b:	8d be 00 ff          	lea    di,[bp-0x100]
    414f:	16                   	push   ss
    4150:	57                   	push   di
    4151:	6a 01                	push   0x1
    4153:	6a 01                	push   0x1
    4155:	9a 75 19 71 41       	call   0x4171:0x1975
    415a:	eb d3                	jmp    0x412f
    415c:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    4160:	30 e4                	xor    ah,ah
    4162:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    4166:	8b 86 fa fe          	mov    ax,WORD PTR [bp-0x106]
    416a:	99                   	cwd
    416b:	bf 78 3e             	mov    di,0x3e78
    416e:	9a 16 04 a0 41       	call   0x41a0:0x416
    4173:	8b f8                	mov    di,ax
    4175:	80 bb 00 ff 20       	cmp    BYTE PTR [bp+di-0x100],0x20
    417a:	b0 00                	mov    al,0x0
    417c:	75 01                	jne    0x417f
    417e:	40                   	inc    ax
    417f:	8a d0                	mov    dl,al
    4181:	83 be fa fe 00       	cmp    WORD PTR [bp-0x106],0x0
    4186:	b0 00                	mov    al,0x0
    4188:	7e 01                	jle    0x418b
    418a:	40                   	inc    ax
    418b:	22 c2                	and    al,dl
    418d:	08 c0                	or     al,al
    418f:	74 17                	je     0x41a8
    4191:	8d be 00 ff          	lea    di,[bp-0x100]
    4195:	16                   	push   ss
    4196:	57                   	push   di
    4197:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    419b:	6a 01                	push   0x1
    419d:	9a 75 19 c1 41       	call   0x41c1:0x1975
    41a2:	ff 8e fa fe          	dec    WORD PTR [bp-0x106]
    41a6:	eb be                	jmp    0x4166
    41a8:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
    41ac:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    41b1:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    41b6:	2d 01 00             	sub    ax,0x1
    41b9:	83 da 00             	sbb    dx,0x0
    41bc:	71 05                	jno    0x41c3
    41be:	9a 3e 04 e5 41       	call   0x41e5:0x43e
    41c3:	8b c8                	mov    cx,ax
    41c5:	8b da                	mov    bx,dx
    41c7:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    41cb:	99                   	cwd
    41cc:	3b d3                	cmp    dx,bx
    41ce:	7c 06                	jl     0x41d6
    41d0:	7f 2d                	jg     0x41ff
    41d2:	3b c1                	cmp    ax,cx
    41d4:	73 29                	jae    0x41ff
    41d6:	8d be e4 fd          	lea    di,[bp-0x21c]
    41da:	16                   	push   ss
    41db:	57                   	push   di
    41dc:	8d be 00 ff          	lea    di,[bp-0x100]
    41e0:	16                   	push   ss
    41e1:	57                   	push   di
    41e2:	9a cd 17 ef 41       	call   0x41ef:0x17cd
    41e7:	bf 5e 3e             	mov    di,0x3e5e
    41ea:	0e                   	push   cs
    41eb:	57                   	push   di
    41ec:	9a 4c 18 fd 41       	call   0x41fd:0x184c
    41f1:	8d be 00 ff          	lea    di,[bp-0x100]
    41f5:	16                   	push   ss
    41f6:	57                   	push   di
    41f7:	68 ff 00             	push   0xff
    41fa:	9a e7 17 45 42       	call   0x4245:0x17e7
    41ff:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    4203:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    4207:	8d be 00 ff          	lea    di,[bp-0x100]
    420b:	16                   	push   ss
    420c:	57                   	push   di
    420d:	9a 4c 0d 25 42       	call   0x4225:0xd4c
    4212:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    4216:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    421a:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    421e:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    4222:	9a 8f 0d 58 42       	call   0x4258:0xd8f
    4227:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    422b:	3b 86 e4 fe          	cmp    ax,WORD PTR [bp-0x11c]
    422f:	74 03                	je     0x4234
    4231:	e9 e6 fd             	jmp    0x401a
    4234:	bf 80 3e             	mov    di,0x3e80
    4237:	0e                   	push   cs
    4238:	57                   	push   di
    4239:	8d be 00 ff          	lea    di,[bp-0x100]
    423d:	16                   	push   ss
    423e:	57                   	push   di
    423f:	68 ff 00             	push   0xff
    4242:	9a e7 17 ba 42       	call   0x42ba:0x17e7
    4247:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    424b:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    424f:	8d be 00 ff          	lea    di,[bp-0x100]
    4253:	16                   	push   ss
    4254:	57                   	push   di
    4255:	9a 4c 0d 6d 42       	call   0x426d:0xd4c
    425a:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    425e:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    4262:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    4266:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    426a:	9a 8f 0d 92 42       	call   0x4292:0xd8f
    426f:	8b 86 fc fe          	mov    ax,WORD PTR [bp-0x104]
    4273:	3b 86 e6 fe          	cmp    ax,WORD PTR [bp-0x11a]
    4277:	74 03                	je     0x427c
    4279:	e9 62 fd             	jmp    0x3fde
    427c:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    4280:	06                   	push   es
    4281:	57                   	push   di
    4282:	9a a1 36 9f 42       	call   0x429f:0x36a1
    4287:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    428b:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    428f:	9a d6 0e ff ff       	call   0xffff:0xed6
    4294:	52                   	push   dx
    4295:	50                   	push   ax
    4296:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    429a:	06                   	push   es
    429b:	57                   	push   di
    429c:	9a 99 39 ff ff       	call   0xffff:0x3999
    42a1:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    42a5:	83 c4 06             	add    sp,0x6
    42a8:	b8 e9 42             	mov    ax,0x42e9
    42ab:	0e                   	push   cs
    42ac:	50                   	push   ax
    42ad:	ff b6 f4 fe          	push   WORD PTR [bp-0x10c]
    42b1:	ff b6 f2 fe          	push   WORD PTR [bp-0x10e]
    42b5:	6a 64                	push   0x64
    42b7:	9a 9c 01 ca 42       	call   0x42ca:0x19c
    42bc:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    42c0:	ff b6 f6 fe          	push   WORD PTR [bp-0x10a]
    42c4:	68 30 75             	push   0x7530
    42c7:	9a 9c 01 16 43       	call   0x4316:0x19c
    42cc:	8b 86 ec fe          	mov    ax,WORD PTR [bp-0x114]
    42d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42d3:	26 89 85 a3 03       	mov    WORD PTR es:[di+0x3a3],ax
    42d8:	81 c7 1c 03          	add    di,0x31c
    42dc:	06                   	push   es
    42dd:	57                   	push   di
    42de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42e1:	06                   	push   es
    42e2:	57                   	push   di
    42e3:	9a 58 28 c5 58       	call   0x58c5:0x2858
    42e8:	cb                   	retf
    42e9:	c9                   	leave
    42ea:	ca 08 00             	retf   0x8
    42ed:	01 09                	add    WORD PTR [bx+di],cx
    42ef:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    42f3:	ff                   	(bad)
    42f4:	7f 00                	jg     0x42f6
    42f6:	00 02                	add    BYTE PTR [bp+si],al
    42f8:	23 56 02             	and    dx,WORD PTR [bp+0x2]
    42fb:	23 43 02             	and    ax,WORD PTR [bp+di+0x2]
    42fe:	23 41 02             	and    ax,WORD PTR [bx+di+0x2]
    4301:	23 26 01 20          	and    sp,WORD PTR ds:0x2001
    4305:	00 00                	add    BYTE PTR [bx+si],al
    4307:	00 00                	add    BYTE PTR [bx+si],al
    4309:	ff 00                	inc    WORD PTR [bx+si]
    430b:	00 00                	add    BYTE PTR [bx+si],al
    430d:	55                   	push   bp
    430e:	89 e5                	mov    bp,sp
    4310:	b8 12 04             	mov    ax,0x412
    4313:	9a 44 04 3e 43       	call   0x433e:0x444
    4318:	81 ec 12 04          	sub    sp,0x412
    431c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    431f:	3d 00 00             	cmp    ax,0x0
    4322:	75 0f                	jne    0x4333
    4324:	c7 86 f6 fd 01 00    	mov    WORD PTR [bp-0x20a],0x1
    432a:	a1 4e 01             	mov    ax,ds:0x14e
    432d:	89 86 f4 fd          	mov    WORD PTR [bp-0x20c],ax
    4331:	eb 40                	jmp    0x4373
    4333:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4336:	2d 01 00             	sub    ax,0x1
    4339:	71 05                	jno    0x4340
    433b:	9a 3e 04 4d 43       	call   0x434d:0x43e
    4340:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4343:	26 f7 ad a1 03       	imul   WORD PTR es:[di+0x3a1]
    4348:	71 05                	jno    0x434f
    434a:	9a 3e 04 57 43       	call   0x4357:0x43e
    434f:	05 01 00             	add    ax,0x1
    4352:	71 05                	jno    0x4359
    4354:	9a 3e 04 6d 43       	call   0x436d:0x43e
    4359:	89 86 f6 fd          	mov    WORD PTR [bp-0x20a],ax
    435d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4360:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4363:	26 f7 ad a1 03       	imul   WORD PTR es:[di+0x3a1]
    4368:	71 05                	jno    0x436f
    436a:	9a 3e 04 a9 43       	call   0x43a9:0x43e
    436f:	89 86 f4 fd          	mov    WORD PTR [bp-0x20c],ax
    4373:	8b 86 f4 fd          	mov    ax,WORD PTR [bp-0x20c]
    4377:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    437b:	7e 07                	jle    0x4384
    437d:	a1 4e 01             	mov    ax,ds:0x14e
    4380:	89 86 f4 fd          	mov    WORD PTR [bp-0x20c],ax
    4384:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4387:	26 c4 bd a0 02       	les    di,DWORD PTR es:[di+0x2a0]
    438c:	89 be ee fd          	mov    WORD PTR [bp-0x212],di
    4390:	8c 86 f0 fd          	mov    WORD PTR [bp-0x210],es
    4394:	06                   	push   es
    4395:	57                   	push   di
    4396:	9a e3 49 ff ff       	call   0xffff:0x49e3
    439b:	8d be ee fc          	lea    di,[bp-0x312]
    439f:	16                   	push   ss
    43a0:	57                   	push   di
    43a1:	bf fa 1d             	mov    di,0x1dfa
    43a4:	1e                   	push   ds
    43a5:	57                   	push   di
    43a6:	9a cd 17 b3 43       	call   0x43b3:0x17cd
    43ab:	bf ed 42             	mov    di,0x42ed
    43ae:	0e                   	push   cs
    43af:	57                   	push   di
    43b0:	9a 4c 18 cd 43       	call   0x43cd:0x184c
    43b5:	8d be ee fb          	lea    di,[bp-0x412]
    43b9:	16                   	push   ss
    43ba:	57                   	push   di
    43bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43be:	26 c4 bd 0c 03       	les    di,DWORD PTR es:[di+0x30c]
    43c3:	06                   	push   es
    43c4:	57                   	push   di
    43c5:	9a 53 1d ff ff       	call   0xffff:0x1d53
    43ca:	9a 4c 18 db 43       	call   0x43db:0x184c
    43cf:	8d be 00 ff          	lea    di,[bp-0x100]
    43d3:	16                   	push   ss
    43d4:	57                   	push   di
    43d5:	68 ff 00             	push   0xff
    43d8:	9a e7 17 1a 44       	call   0x441a:0x17e7
    43dd:	8d be 00 ff          	lea    di,[bp-0x100]
    43e1:	16                   	push   ss
    43e2:	57                   	push   di
    43e3:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    43e7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    43ec:	06                   	push   es
    43ed:	57                   	push   di
    43ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43f1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    43f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43f8:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    43fd:	89 be ea fd          	mov    WORD PTR [bp-0x216],di
    4401:	8c 86 ec fd          	mov    WORD PTR [bp-0x214],es
    4405:	26 8b 85 0a 01       	mov    ax,WORD PTR es:[di+0x10a]
    440a:	26 8b 95 0c 01       	mov    dx,WORD PTR es:[di+0x10c]
    440f:	2d 01 00             	sub    ax,0x1
    4412:	83 da 00             	sbb    dx,0x0
    4415:	71 05                	jno    0x441c
    4417:	9a 3e 04 22 44       	call   0x4422:0x43e
    441c:	bf ef 42             	mov    di,0x42ef
    441f:	9a 16 04 5b 44       	call   0x445b:0x416
    4424:	89 86 e8 fd          	mov    WORD PTR [bp-0x218],ax
    4428:	31 c0                	xor    ax,ax
    442a:	3b 86 e8 fd          	cmp    ax,WORD PTR [bp-0x218]
    442e:	7e 03                	jle    0x4433
    4430:	e9 f3 03             	jmp    0x4826
    4433:	89 86 fc fd          	mov    WORD PTR [bp-0x204],ax
    4437:	eb 04                	jmp    0x443d
    4439:	ff 86 fc fd          	inc    WORD PTR [bp-0x204]
    443d:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    4442:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    4446:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    444b:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    4450:	2d 01 00             	sub    ax,0x1
    4453:	83 da 00             	sbb    dx,0x0
    4456:	71 05                	jno    0x445d
    4458:	9a 3e 04 63 44       	call   0x4463:0x43e
    445d:	bf ef 42             	mov    di,0x42ef
    4460:	9a 16 04 8f 44       	call   0x448f:0x416
    4465:	89 86 e6 fd          	mov    WORD PTR [bp-0x21a],ax
    4469:	31 c0                	xor    ax,ax
    446b:	3b 86 e6 fd          	cmp    ax,WORD PTR [bp-0x21a]
    446f:	7e 03                	jle    0x4474
    4471:	e9 8d 03             	jmp    0x4801
    4474:	89 86 fe fd          	mov    WORD PTR [bp-0x202],ax
    4478:	eb 04                	jmp    0x447e
    447a:	ff 86 fe fd          	inc    WORD PTR [bp-0x202]
    447e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4481:	26 8b 85 a5 04       	mov    ax,WORD PTR es:[di+0x4a5]
    4486:	f7 ae f4 fd          	imul   WORD PTR [bp-0x20c]
    448a:	71 05                	jno    0x4491
    448c:	9a 3e 04 a8 44       	call   0x44a8:0x43e
    4491:	3b 86 fe fd          	cmp    ax,WORD PTR [bp-0x202]
    4495:	b0 00                	mov    al,0x0
    4497:	7c 01                	jl     0x449a
    4499:	40                   	inc    ax
    449a:	8a c8                	mov    cl,al
    449c:	8b 86 f6 fd          	mov    ax,WORD PTR [bp-0x20a]
    44a0:	2d 01 00             	sub    ax,0x1
    44a3:	71 05                	jno    0x44aa
    44a5:	9a 3e 04 b7 44       	call   0x44b7:0x43e
    44aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44ad:	26 f7 ad a5 04       	imul   WORD PTR es:[di+0x4a5]
    44b2:	71 05                	jno    0x44b9
    44b4:	9a 3e 04 c1 44       	call   0x44c1:0x43e
    44b9:	05 01 00             	add    ax,0x1
    44bc:	71 05                	jno    0x44c3
    44be:	9a 3e 04 08 45       	call   0x4508:0x43e
    44c3:	3b 86 fe fd          	cmp    ax,WORD PTR [bp-0x202]
    44c7:	b0 00                	mov    al,0x0
    44c9:	7f 01                	jg     0x44cc
    44cb:	40                   	inc    ax
    44cc:	22 c1                	and    al,cl
    44ce:	8a d0                	mov    dl,al
    44d0:	83 be fe fd 01       	cmp    WORD PTR [bp-0x202],0x1
    44d5:	b0 00                	mov    al,0x0
    44d7:	7d 01                	jge    0x44da
    44d9:	40                   	inc    ax
    44da:	0a c2                	or     al,dl
    44dc:	08 c0                	or     al,al
    44de:	75 03                	jne    0x44e3
    44e0:	e9 11 03             	jmp    0x47f4
    44e3:	8d be e6 fc          	lea    di,[bp-0x31a]
    44e7:	16                   	push   ss
    44e8:	57                   	push   di
    44e9:	ff b6 fe fd          	push   WORD PTR [bp-0x202]
    44ed:	ff b6 fc fd          	push   WORD PTR [bp-0x204]
    44f1:	c4 be ea fd          	les    di,DWORD PTR [bp-0x216]
    44f5:	06                   	push   es
    44f6:	57                   	push   di
    44f7:	9a 68 9a 57 5b       	call   0x5b57:0x9a68
    44fc:	8d be 00 fe          	lea    di,[bp-0x200]
    4500:	16                   	push   ss
    4501:	57                   	push   di
    4502:	68 ff 00             	push   0xff
    4505:	9a e7 17 18 45       	call   0x4518:0x17e7
    450a:	bf f7 42             	mov    di,0x42f7
    450d:	0e                   	push   cs
    450e:	57                   	push   di
    450f:	8d be 00 fe          	lea    di,[bp-0x200]
    4513:	16                   	push   ss
    4514:	57                   	push   di
    4515:	9a 78 18 34 45       	call   0x4534:0x1878
    451a:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    451e:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    4523:	7e 11                	jle    0x4536
    4525:	8d be 00 fe          	lea    di,[bp-0x200]
    4529:	16                   	push   ss
    452a:	57                   	push   di
    452b:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    452f:	6a 02                	push   0x2
    4531:	9a 75 19 4b 45       	call   0x454b:0x1975
    4536:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    453b:	75 cd                	jne    0x450a
    453d:	bf fa 42             	mov    di,0x42fa
    4540:	0e                   	push   cs
    4541:	57                   	push   di
    4542:	8d be 00 fe          	lea    di,[bp-0x200]
    4546:	16                   	push   ss
    4547:	57                   	push   di
    4548:	9a 78 18 67 45       	call   0x4567:0x1878
    454d:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    4551:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    4556:	7e 11                	jle    0x4569
    4558:	8d be 00 fe          	lea    di,[bp-0x200]
    455c:	16                   	push   ss
    455d:	57                   	push   di
    455e:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    4562:	6a 03                	push   0x3
    4564:	9a 75 19 7e 45       	call   0x457e:0x1975
    4569:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    456e:	75 cd                	jne    0x453d
    4570:	bf fd 42             	mov    di,0x42fd
    4573:	0e                   	push   cs
    4574:	57                   	push   di
    4575:	8d be 00 fe          	lea    di,[bp-0x200]
    4579:	16                   	push   ss
    457a:	57                   	push   di
    457b:	9a 78 18 9a 45       	call   0x459a:0x1878
    4580:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    4584:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    4589:	7e 11                	jle    0x459c
    458b:	8d be 00 fe          	lea    di,[bp-0x200]
    458f:	16                   	push   ss
    4590:	57                   	push   di
    4591:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    4595:	6a 03                	push   0x3
    4597:	9a 75 19 b7 45       	call   0x45b7:0x1975
    459c:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    45a1:	75 cd                	jne    0x4570
    45a3:	c7 86 f2 fd 01 00    	mov    WORD PTR [bp-0x20e],0x1
    45a9:	bf 00 43             	mov    di,0x4300
    45ac:	0e                   	push   cs
    45ad:	57                   	push   di
    45ae:	8d be 00 fe          	lea    di,[bp-0x200]
    45b2:	16                   	push   ss
    45b3:	57                   	push   di
    45b4:	9a 78 18 d7 45       	call   0x45d7:0x1878
    45b9:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    45bd:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    45c2:	7e 77                	jle    0x463b
    45c4:	ff 86 f2 fd          	inc    WORD PTR [bp-0x20e]
    45c8:	8d be 00 fe          	lea    di,[bp-0x200]
    45cc:	16                   	push   ss
    45cd:	57                   	push   di
    45ce:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    45d2:	6a 02                	push   0x2
    45d4:	9a 75 19 f5 45       	call   0x45f5:0x1975
    45d9:	83 be fe fd 00       	cmp    WORD PTR [bp-0x202],0x0
    45de:	7e 5b                	jle    0x463b
    45e0:	bf ed 42             	mov    di,0x42ed
    45e3:	0e                   	push   cs
    45e4:	57                   	push   di
    45e5:	8d be 00 fe          	lea    di,[bp-0x200]
    45e9:	16                   	push   ss
    45ea:	57                   	push   di
    45eb:	68 ff 00             	push   0xff
    45ee:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    45f2:	9a 16 19 06 46       	call   0x4606:0x1916
    45f7:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    45fb:	30 e4                	xor    ah,ah
    45fd:	2b 86 fa fd          	sub    ax,WORD PTR [bp-0x206]
    4601:	71 05                	jno    0x4608
    4603:	9a 3e 04 31 46       	call   0x4631:0x43e
    4608:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    460c:	83 be f8 fd 13       	cmp    WORD PTR [bp-0x208],0x13
    4611:	7d 28                	jge    0x463b
    4613:	ff 86 f8 fd          	inc    WORD PTR [bp-0x208]
    4617:	bf 03 43             	mov    di,0x4303
    461a:	0e                   	push   cs
    461b:	57                   	push   di
    461c:	8d be 00 fe          	lea    di,[bp-0x200]
    4620:	16                   	push   ss
    4621:	57                   	push   di
    4622:	68 ff 00             	push   0xff
    4625:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    4629:	05 01 00             	add    ax,0x1
    462c:	71 05                	jno    0x4633
    462e:	9a 3e 04 37 46       	call   0x4637:0x43e
    4633:	50                   	push   ax
    4634:	9a 16 19 74 46       	call   0x4674:0x1916
    4639:	eb d1                	jmp    0x460c
    463b:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    4640:	74 03                	je     0x4645
    4642:	e9 64 ff             	jmp    0x45a9
    4645:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    4649:	75 79                	jne    0x46c4
    464b:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    4650:	b0 00                	mov    al,0x0
    4652:	76 01                	jbe    0x4655
    4654:	40                   	inc    ax
    4655:	8a d0                	mov    dl,al
    4657:	80 be 01 fe 20       	cmp    BYTE PTR [bp-0x1ff],0x20
    465c:	b0 00                	mov    al,0x0
    465e:	75 01                	jne    0x4661
    4660:	40                   	inc    ax
    4661:	22 c2                	and    al,dl
    4663:	08 c0                	or     al,al
    4665:	74 11                	je     0x4678
    4667:	8d be 00 fe          	lea    di,[bp-0x200]
    466b:	16                   	push   ss
    466c:	57                   	push   di
    466d:	6a 01                	push   0x1
    466f:	6a 01                	push   0x1
    4671:	9a 75 19 8d 46       	call   0x468d:0x1975
    4676:	eb d3                	jmp    0x464b
    4678:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    467c:	30 e4                	xor    ah,ah
    467e:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    4682:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    4686:	99                   	cwd
    4687:	bf 05 43             	mov    di,0x4305
    468a:	9a 16 04 bc 46       	call   0x46bc:0x416
    468f:	8b f8                	mov    di,ax
    4691:	80 bb 00 fe 20       	cmp    BYTE PTR [bp+di-0x200],0x20
    4696:	b0 00                	mov    al,0x0
    4698:	75 01                	jne    0x469b
    469a:	40                   	inc    ax
    469b:	8a d0                	mov    dl,al
    469d:	83 be fa fd 00       	cmp    WORD PTR [bp-0x206],0x0
    46a2:	b0 00                	mov    al,0x0
    46a4:	7e 01                	jle    0x46a7
    46a6:	40                   	inc    ax
    46a7:	22 c2                	and    al,dl
    46a9:	08 c0                	or     al,al
    46ab:	74 17                	je     0x46c4
    46ad:	8d be 00 fe          	lea    di,[bp-0x200]
    46b1:	16                   	push   ss
    46b2:	57                   	push   di
    46b3:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    46b7:	6a 01                	push   0x1
    46b9:	9a 75 19 f4 46       	call   0x46f4:0x1975
    46be:	ff 8e fa fd          	dec    WORD PTR [bp-0x206]
    46c2:	eb be                	jmp    0x4682
    46c4:	83 7e 0c 01          	cmp    WORD PTR [bp+0xc],0x1
    46c8:	74 03                	je     0x46cd
    46ca:	e9 c0 00             	jmp    0x478d
    46cd:	83 be fe fd 00       	cmp    WORD PTR [bp-0x202],0x0
    46d2:	75 6a                	jne    0x473e
    46d4:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    46d8:	30 e4                	xor    ah,ah
    46da:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    46de:	83 be fa fd 1e       	cmp    WORD PTR [bp-0x206],0x1e
    46e3:	7e 17                	jle    0x46fc
    46e5:	8d be 00 fe          	lea    di,[bp-0x200]
    46e9:	16                   	push   ss
    46ea:	57                   	push   di
    46eb:	ff b6 fa fd          	push   WORD PTR [bp-0x206]
    46ef:	6a 01                	push   0x1
    46f1:	9a 75 19 20 47       	call   0x4720:0x1975
    46f6:	ff 8e fa fd          	dec    WORD PTR [bp-0x206]
    46fa:	eb e2                	jmp    0x46de
    46fc:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    4700:	30 e4                	xor    ah,ah
    4702:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    4706:	83 be fa fd 1e       	cmp    WORD PTR [bp-0x206],0x1e
    470b:	7d 2f                	jge    0x473c
    470d:	ff 86 fa fd          	inc    WORD PTR [bp-0x206]
    4711:	8d be e6 fc          	lea    di,[bp-0x31a]
    4715:	16                   	push   ss
    4716:	57                   	push   di
    4717:	8d be 00 fe          	lea    di,[bp-0x200]
    471b:	16                   	push   ss
    471c:	57                   	push   di
    471d:	9a cd 17 2a 47       	call   0x472a:0x17cd
    4722:	bf 03 43             	mov    di,0x4303
    4725:	0e                   	push   cs
    4726:	57                   	push   di
    4727:	9a 4c 18 38 47       	call   0x4738:0x184c
    472c:	8d be 00 fe          	lea    di,[bp-0x200]
    4730:	16                   	push   ss
    4731:	57                   	push   di
    4732:	68 ff 00             	push   0xff
    4735:	9a e7 17 56 47       	call   0x4756:0x17e7
    473a:	eb ca                	jmp    0x4706
    473c:	eb 4f                	jmp    0x478d
    473e:	8a 86 00 fe          	mov    al,BYTE PTR [bp-0x200]
    4742:	30 e4                	xor    ah,ah
    4744:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    4748:	8b 86 f2 fd          	mov    ax,WORD PTR [bp-0x20e]
    474c:	b9 13 00             	mov    cx,0x13
    474f:	f7 e9                	imul   cx
    4751:	71 05                	jno    0x4758
    4753:	9a 3e 04 70 47       	call   0x4770:0x43e
    4758:	3b 86 fa fd          	cmp    ax,WORD PTR [bp-0x206]
    475c:	7e 2f                	jle    0x478d
    475e:	ff 86 fa fd          	inc    WORD PTR [bp-0x206]
    4762:	8d be e6 fc          	lea    di,[bp-0x31a]
    4766:	16                   	push   ss
    4767:	57                   	push   di
    4768:	bf 03 43             	mov    di,0x4303
    476b:	0e                   	push   cs
    476c:	57                   	push   di
    476d:	9a cd 17 7b 47       	call   0x477b:0x17cd
    4772:	8d be 00 fe          	lea    di,[bp-0x200]
    4776:	16                   	push   ss
    4777:	57                   	push   di
    4778:	9a 4c 18 89 47       	call   0x4789:0x184c
    477d:	8d be 00 fe          	lea    di,[bp-0x200]
    4781:	16                   	push   ss
    4782:	57                   	push   di
    4783:	68 ff 00             	push   0xff
    4786:	9a e7 17 99 47       	call   0x4799:0x17e7
    478b:	eb bb                	jmp    0x4748
    478d:	8b 86 f4 fd          	mov    ax,WORD PTR [bp-0x20c]
    4791:	2d 01 00             	sub    ax,0x1
    4794:	71 05                	jno    0x479b
    4796:	9a 3e 04 b0 47       	call   0x47b0:0x43e
    479b:	3b 86 fe fd          	cmp    ax,WORD PTR [bp-0x202]
    479f:	7e 29                	jle    0x47ca
    47a1:	8d be e6 fc          	lea    di,[bp-0x31a]
    47a5:	16                   	push   ss
    47a6:	57                   	push   di
    47a7:	8d be 00 fe          	lea    di,[bp-0x200]
    47ab:	16                   	push   ss
    47ac:	57                   	push   di
    47ad:	9a cd 17 ba 47       	call   0x47ba:0x17cd
    47b2:	bf ed 42             	mov    di,0x42ed
    47b5:	0e                   	push   cs
    47b6:	57                   	push   di
    47b7:	9a 4c 18 c8 47       	call   0x47c8:0x184c
    47bc:	8d be 00 fe          	lea    di,[bp-0x200]
    47c0:	16                   	push   ss
    47c1:	57                   	push   di
    47c2:	68 ff 00             	push   0xff
    47c5:	9a e7 17 d9 47       	call   0x47d9:0x17e7
    47ca:	8d be e6 fc          	lea    di,[bp-0x31a]
    47ce:	16                   	push   ss
    47cf:	57                   	push   di
    47d0:	8d be 00 ff          	lea    di,[bp-0x100]
    47d4:	16                   	push   ss
    47d5:	57                   	push   di
    47d6:	9a cd 17 e4 47       	call   0x47e4:0x17cd
    47db:	8d be 00 fe          	lea    di,[bp-0x200]
    47df:	16                   	push   ss
    47e0:	57                   	push   di
    47e1:	9a 4c 18 f2 47       	call   0x47f2:0x184c
    47e6:	8d be 00 ff          	lea    di,[bp-0x100]
    47ea:	16                   	push   ss
    47eb:	57                   	push   di
    47ec:	68 ff 00             	push   0xff
    47ef:	9a e7 17 e0 4a       	call   0x4ae0:0x17e7
    47f4:	8b 86 fe fd          	mov    ax,WORD PTR [bp-0x202]
    47f8:	3b 86 e6 fd          	cmp    ax,WORD PTR [bp-0x21a]
    47fc:	74 03                	je     0x4801
    47fe:	e9 79 fc             	jmp    0x447a
    4801:	8d be 00 ff          	lea    di,[bp-0x100]
    4805:	16                   	push   ss
    4806:	57                   	push   di
    4807:	c4 be ee fd          	les    di,DWORD PTR [bp-0x212]
    480b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4810:	06                   	push   es
    4811:	57                   	push   di
    4812:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4815:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4819:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    481d:	3b 86 e8 fd          	cmp    ax,WORD PTR [bp-0x218]
    4821:	74 03                	je     0x4826
    4823:	e9 13 fc             	jmp    0x4439
    4826:	c9                   	leave
    4827:	ca 08 00             	retf   0x8
    482a:	09 50 72             	or     WORD PTR [bx+si+0x72],dx
    482d:	6f                   	outs   dx,WORD PTR ds:[si]
    482e:	64 75 69             	fs jne 0x489a
    4831:	74 4e                	je     0x4881
    4833:	6f                   	outs   dx,WORD PTR ds:[si]
    4834:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    4838:	ff                   	(bad)
    4839:	7f 00                	jg     0x483b
    483b:	00 09                	add    BYTE PTR [bx+di],cl
    483d:	43                   	inc    bx
    483e:	61                   	popa
    483f:	70 50                	jo     0x4891
    4841:	72 6f                	jb     0x48b2
    4843:	64 75 63             	fs jne 0x48a9
    4846:	11 4d 61             	adc    WORD PTR [di+0x61],cx
    4849:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    484c:	6e                   	outs   dx,BYTE PTR ds:[si]
    484d:	65 73 41             	gs jae 0x4891
    4850:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    4856:	65 73 08             	gs jae 0x4861
    4859:	4d                   	dec    bp
    485a:	61                   	popa
    485b:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    485e:	6e                   	outs   dx,BYTE PTR ds:[si]
    485f:	65 73 00             	gs jae 0x4862
    4862:	00 c8                	add    al,cl
    4864:	42                   	inc    dx
    4865:	0b 55 74             	or     dx,WORD PTR [di+0x74]
    4868:	69 6c 69 73 61       	imul   bp,WORD PTR [si+0x69],0x6173
    486d:	74 69                	je     0x48d8
    486f:	6f                   	outs   dx,WORD PTR ds:[si]
    4870:	6e                   	outs   dx,BYTE PTR ds:[si]
    4871:	10 54 65             	adc    BYTE PTR [si+0x65],dl
    4874:	6d                   	ins    WORD PTR es:[di],dx
    4875:	70 73                	jo     0x48ea
    4877:	46                   	inc    si
    4878:	61                   	popa
    4879:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    487c:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    487f:	69 6f 6e 10 50       	imul   bp,WORD PTR [bx+0x6e],0x5010
    4884:	72 6f                	jb     0x48f5
    4886:	64 75 63             	fs jne 0x48ec
    4889:	74 69                	je     0x48f4
    488b:	6f                   	outs   dx,WORD PTR ds:[si]
    488c:	6e                   	outs   dx,BYTE PTR ds:[si]
    488d:	52                   	push   dx
    488e:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    4891:	6c                   	ins    BYTE PTR es:[di],dx
    4892:	65 10 48 65          	adc    BYTE PTR gs:[bx+si+0x65],cl
    4896:	75 72                	jne    0x490a
    4898:	65 73 50             	gs jae 0x48eb
    489b:	61                   	popa
    489c:	72 4d                	jb     0x48eb
    489e:	61                   	popa
    489f:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    48a2:	6e                   	outs   dx,BYTE PTR ds:[si]
    48a3:	65 0f 43 6f 75       	cmovae bp,WORD PTR gs:[bx+0x75]
    48a8:	74 50                	je     0x48fa
    48aa:	72 6f                	jb     0x491b
    48ac:	64 75 63             	fs jne 0x4912
    48af:	74 69                	je     0x491a
    48b1:	6f                   	outs   dx,WORD PTR ds:[si]
    48b2:	6e                   	outs   dx,BYTE PTR ds:[si]
    48b3:	55                   	push   bp
    48b4:	13 43 6f             	adc    ax,WORD PTR [bp+di+0x6f]
    48b7:	6e                   	outs   dx,BYTE PTR ds:[si]
    48b8:	73 6f                	jae    0x4929
    48ba:	6d                   	ins    WORD PTR es:[di],dx
    48bb:	6d                   	ins    WORD PTR es:[di],dx
    48bc:	61                   	popa
    48bd:	74 69                	je     0x4928
    48bf:	6f                   	outs   dx,WORD PTR ds:[si]
    48c0:	6e                   	outs   dx,BYTE PTR ds:[si]
    48c1:	4d                   	dec    bp
    48c2:	61                   	popa
    48c3:	74 69                	je     0x492e
    48c5:	65 72 65             	gs jb  0x492d
    48c8:	11 4d 61             	adc    WORD PTR [di+0x61],cx
    48cb:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    48d0:	76 72                	jbe    0x4944
    48d2:	65 44                	gs inc sp
    48d4:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    48d9:	65 0f 44 65 70       	cmove  sp,WORD PTR gs:[di+0x70]
    48de:	65 6e                	outs   dx,BYTE PTR gs:[si]
    48e0:	73 65                	jae    0x4947
    48e2:	73 51                	jae    0x4935
    48e4:	75 61                	jne    0x4947
    48e6:	6c                   	ins    BYTE PTR es:[di],dx
    48e7:	69 74 65 10 44       	imul   si,WORD PTR [si+0x65],0x4410
    48ec:	6f                   	outs   dx,WORD PTR ds:[si]
    48ed:	74 41                	je     0x4930
    48ef:	6d                   	ins    WORD PTR es:[di],dx
    48f0:	6f                   	outs   dx,WORD PTR ds:[si]
    48f1:	72 74                	jb     0x4967
    48f3:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    48f8:	65 6e                	outs   dx,BYTE PTR gs:[si]
    48fa:	74 0b                	je     0x4907
    48fc:	56                   	push   si
    48fd:	61                   	popa
    48fe:	6c                   	ins    BYTE PTR es:[di],dx
    48ff:	65 75 72             	gs jne 0x4974
    4902:	53                   	push   bx
    4903:	74 6f                	je     0x4974
    4905:	63 6b 08             	arpl   WORD PTR [bp+di+0x8],bp
    4908:	51                   	push   cx
    4909:	74 65                	je     0x4970
    490b:	53                   	push   bx
    490c:	74 6f                	je     0x497d
    490e:	63 6b 0e             	arpl   WORD PTR [bp+di+0xe],bp
    4911:	50                   	push   ax
    4912:	72 69                	jb     0x497d
    4914:	78 53                	js     0x4969
    4916:	75 72                	jne    0x498a
    4918:	4d                   	dec    bp
    4919:	6f                   	outs   dx,WORD PTR ds:[si]
    491a:	79 65                	jns    0x4981
    491c:	6e                   	outs   dx,BYTE PTR ds:[si]
    491d:	6e                   	outs   dx,BYTE PTR ds:[si]
    491e:	65 04 50             	gs add al,0x50
    4921:	72 69                	jb     0x498c
    4923:	78 01                	js     0x4926
    4925:	00 00                	add    BYTE PTR [bx+si],al
    4927:	00 02                	add    BYTE PTR [bp+si],al
    4929:	00 00                	add    BYTE PTR [bx+si],al
    492b:	00 0e 50 75          	add    BYTE PTR ds:0x7550,cl
    492f:	62 43 41             	bound  ax,DWORD PTR [bp+di+0x41]
    4932:	54                   	push   sp
    4933:	68 65 6f             	push   0x6f65
    4936:	72 69                	jb     0x49a1
    4938:	71 75                	jno    0x49af
    493a:	65 09 50 75          	or     WORD PTR gs:[bx+si+0x75],dx
    493e:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
    4941:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    4944:	65 06                	gs push es
    4946:	56                   	push   si
    4947:	65 6e                	outs   dx,BYTE PTR gs:[si]
    4949:	74 65                	je     0x49b0
    494b:	73 09                	jae    0x4956
    494d:	50                   	push   ax
    494e:	75 62                	jne    0x49b2
    4950:	43                   	inc    bx
    4951:	41                   	inc    cx
    4952:	52                   	push   dx
    4953:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    4956:	0d 50 75             	or     ax,0x7550
    4959:	62 53 75             	bound  dx,DWORD PTR [bp+di+0x75]
    495c:	72 4d                	jb     0x49ab
    495e:	6f                   	outs   dx,WORD PTR ds:[si]
    495f:	79 65                	jns    0x49c6
    4961:	6e                   	outs   dx,BYTE PTR ds:[si]
    4962:	6e                   	outs   dx,BYTE PTR ds:[si]
    4963:	65 13 56 65          	adc    dx,WORD PTR gs:[bp+0x65]
    4967:	6e                   	outs   dx,BYTE PTR ds:[si]
    4968:	64 65 75 72          	fs gs jne 0x49de
    496c:	50                   	push   ax
    496d:	72 6f                	jb     0x49de
    496f:	64 75 63             	fs jne 0x49d5
    4972:	74 69                	je     0x49dd
    4974:	76 69                	jbe    0x49df
    4976:	74 65                	je     0x49dd
    4978:	10 56 65             	adc    BYTE PTR [bp+0x65],dl
    497b:	6e                   	outs   dx,BYTE PTR ds:[si]
    497c:	64 65 75 72          	fs gs jne 0x49f2
    4980:	73 41                	jae    0x49c3
    4982:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    4988:	73 11                	jae    0x499b
    498a:	56                   	push   si
    498b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    498d:	64 65 75 72          	fs gs jne 0x4a03
    4991:	53                   	push   bx
    4992:	75 72                	jne    0x4a06
    4994:	4d                   	dec    bp
    4995:	6f                   	outs   dx,WORD PTR ds:[si]
    4996:	79 65                	jns    0x49fd
    4998:	6e                   	outs   dx,BYTE PTR ds:[si]
    4999:	6e                   	outs   dx,BYTE PTR ds:[si]
    499a:	65 10 43 72          	adc    BYTE PTR gs:[bp+di+0x72],al
    499e:	65 64 69 74 53 75 72 	gs imul si,WORD PTR fs:[si+0x53],0x7275
    49a5:	4d                   	dec    bp
    49a6:	6f                   	outs   dx,WORD PTR ds:[si]
    49a7:	79 65                	jns    0x4a0e
    49a9:	6e                   	outs   dx,BYTE PTR ds:[si]
    49aa:	6e                   	outs   dx,BYTE PTR ds:[si]
    49ab:	65 11 44 75          	adc    WORD PTR gs:[si+0x75],ax
    49af:	72 65                	jb     0x4a16
    49b1:	65 43                	gs inc bx
    49b3:	72 65                	jb     0x4a1a
    49b5:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    49bb:	65 6e                	outs   dx,BYTE PTR gs:[si]
    49bd:	74 02                	je     0x49c1
    49bf:	43                   	inc    bx
    49c0:	41                   	inc    cx
    49c1:	10 56 65             	adc    BYTE PTR [bp+0x65],dl
    49c4:	6e                   	outs   dx,BYTE PTR ds:[si]
    49c5:	74 65                	je     0x4a2c
    49c7:	73 53                	jae    0x4a1c
    49c9:	6f                   	outs   dx,WORD PTR ds:[si]
    49ca:	6c                   	ins    BYTE PTR es:[di],dx
    49cb:	64 65 65 73 51       	fs gs gs jae 0x4a21
    49d0:	74 65                	je     0x4a37
    49d2:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    49d5:	6e                   	outs   dx,BYTE PTR ds:[si]
    49d6:	74 65                	je     0x4a3d
    49d8:	73 53                	jae    0x4a2d
    49da:	6f                   	outs   dx,WORD PTR ds:[si]
    49db:	6c                   	ins    BYTE PTR es:[di],dx
    49dc:	64 65 65 73 50       	fs gs gs jae 0x4a31
    49e1:	72 69                	jb     0x4a4c
    49e3:	78 0c                	js     0x49f1
    49e5:	56                   	push   si
    49e6:	65 6e                	outs   dx,BYTE PTR gs:[si]
    49e8:	74 65                	je     0x4a4f
    49ea:	73 53                	jae    0x4a3f
    49ec:	70 65                	jo     0x4a53
    49ee:	51                   	push   cx
    49ef:	74 65                	je     0x4a56
    49f1:	0d 56 65             	or     ax,0x6556
    49f4:	6e                   	outs   dx,BYTE PTR ds:[si]
    49f5:	74 65                	je     0x4a5c
    49f7:	73 53                	jae    0x4a4c
    49f9:	70 65                	jo     0x4a60
    49fb:	50                   	push   ax
    49fc:	72 69                	jb     0x4a67
    49fe:	78 0c                	js     0x4a0c
    4a00:	45                   	inc    bp
    4a01:	66 66 65 74 50       	data32 data32 gs je 0x4a56
    4a06:	72 69                	jb     0x4a71
    4a08:	78 31                	js     0x4a3b
    4a0a:	30 30                	xor    BYTE PTR [bx+si],dh
    4a0c:	09 45 66             	or     WORD PTR [di+0x66],ax
    4a0f:	66 65 74 50          	data32 gs je 0x4a63
    4a13:	72 69                	jb     0x4a7e
    4a15:	78 0b                	js     0x4a22
    4a17:	45                   	inc    bp
    4a18:	66 66 65 74 50       	data32 data32 gs je 0x4a6d
    4a1d:	75 62                	jne    0x4a81
    4a1f:	31 30                	xor    WORD PTR [bx+si],si
    4a21:	30 08                	xor    BYTE PTR [bx+si],cl
    4a23:	45                   	inc    bp
    4a24:	66 66 65 74 50       	data32 data32 gs je 0x4a79
    4a29:	75 62                	jne    0x4a8d
    4a2b:	0a 45 66             	or     al,BYTE PTR [di+0x66]
    4a2e:	66 65 74 46          	data32 gs je 0x4a78
    4a32:	56                   	push   si
    4a33:	31 30                	xor    WORD PTR [bx+si],si
    4a35:	30 07                	xor    BYTE PTR [bx],al
    4a37:	45                   	inc    bp
    4a38:	66 66 65 74 46       	data32 data32 gs je 0x4a83
    4a3d:	56                   	push   si
    4a3e:	0e                   	push   cs
    4a3f:	45                   	inc    bp
    4a40:	66 66 65 74 43       	data32 data32 gs je 0x4a88
    4a45:	72 65                	jb     0x4aac
    4a47:	64 69 74 31 30 30    	imul   si,WORD PTR fs:[si+0x31],0x3030
    4a4d:	0b 45 66             	or     ax,WORD PTR [di+0x66]
    4a50:	66 65 74 43          	data32 gs je 0x4a97
    4a54:	72 65                	jb     0x4abb
    4a56:	64 69 74 0f 45 66    	imul   si,WORD PTR fs:[si+0xf],0x6645
    4a5c:	66 65 74 51          	data32 gs je 0x4ab1
    4a60:	75 61                	jne    0x4ac3
    4a62:	6c                   	ins    BYTE PTR es:[di],dx
    4a63:	69 74 65 31 30       	imul   si,WORD PTR [si+0x65],0x3031
    4a68:	30 0c                	xor    BYTE PTR [si],cl
    4a6a:	45                   	inc    bp
    4a6b:	66 66 65 74 51       	data32 data32 gs je 0x4ac1
    4a70:	75 61                	jne    0x4ad3
    4a72:	6c                   	ins    BYTE PTR es:[di],dx
    4a73:	69 74 65 0e 45       	imul   si,WORD PTR [si+0x65],0x450e
    4a78:	66 66 65 74 47       	data32 data32 gs je 0x4ac4
    4a7d:	6c                   	ins    BYTE PTR es:[di],dx
    4a7e:	6f                   	outs   dx,WORD PTR ds:[si]
    4a7f:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
    4a82:	31 30                	xor    WORD PTR [bx+si],si
    4a84:	30 0b                	xor    BYTE PTR [bp+di],cl
    4a86:	45                   	inc    bp
    4a87:	66 66 65 74 47       	data32 data32 gs je 0x4ad3
    4a8c:	6c                   	ins    BYTE PTR es:[di],dx
    4a8d:	6f                   	outs   dx,WORD PTR ds:[si]
    4a8e:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
    4a91:	0a 4d 61             	or     cl,BYTE PTR [di+0x61]
    4a94:	72 67                	jb     0x4afd
    4a96:	65 53                	gs push bx
    4a98:	75 72                	jne    0x4b0c
    4a9a:	43                   	inc    bx
    4a9b:	64 11 41 63          	adc    WORD PTR fs:[bx+di+0x63],ax
    4a9f:	74 69                	je     0x4b0a
    4aa1:	6f                   	outs   dx,WORD PTR ds:[si]
    4aa2:	6e                   	outs   dx,BYTE PTR ds:[si]
    4aa3:	43                   	inc    bx
    4aa4:	6f                   	outs   dx,WORD PTR ds:[si]
    4aa5:	6d                   	ins    WORD PTR es:[di],dx
    4aa6:	6d                   	ins    WORD PTR es:[di],dx
    4aa7:	65 72 63             	gs jb  0x4b0d
    4aaa:	69 61 6c 65 0e       	imul   sp,WORD PTR [bx+di+0x6c],0xe65
    4aaf:	52                   	push   dx
    4ab0:	65 6d                	gs ins WORD PTR es:[di],dx
    4ab2:	75 6e                	jne    0x4b22
    4ab4:	65 72 61             	gs jb  0x4b18
    4ab7:	74 69                	je     0x4b22
    4ab9:	6f                   	outs   dx,WORD PTR ds:[si]
    4aba:	6e                   	outs   dx,BYTE PTR ds:[si]
    4abb:	46                   	inc    si
    4abc:	56                   	push   si
    4abd:	0e                   	push   cs
    4abe:	43                   	inc    bx
    4abf:	6f                   	outs   dx,WORD PTR ds:[si]
    4ac0:	75 74                	jne    0x4b36
    4ac2:	55                   	push   bp
    4ac3:	6e                   	outs   dx,BYTE PTR ds:[si]
    4ac4:	69 74 65 53 74       	imul   si,WORD PTR [si+0x65],0x7453
    4ac9:	6f                   	outs   dx,WORD PTR ds:[si]
    4aca:	63 6b 0a             	arpl   WORD PTR [bp+di+0xa],bp
    4acd:	4d                   	dec    bp
    4ace:	61                   	popa
    4acf:	72 67                	jb     0x4b38
    4ad1:	65 53                	gs push bx
    4ad3:	75 72                	jne    0x4b47
    4ad5:	43                   	inc    bx
    4ad6:	41                   	inc    cx
    4ad7:	55                   	push   bp
    4ad8:	89 e5                	mov    bp,sp
    4ada:	b8 98 00             	mov    ax,0x98
    4add:	9a 44 04 f7 4a       	call   0x4af7:0x444
    4ae2:	81 ec 98 00          	sub    sp,0x98
    4ae6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4ae9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4aec:	bf 38 01             	mov    di,0x138
    4aef:	b8 ff ff             	mov    ax,0xffff
    4af2:	50                   	push   ax
    4af3:	57                   	push   di
    4af4:	9a 73 22 25 4b       	call   0x4b25:0x2273
    4af9:	89 c7                	mov    di,ax
    4afb:	8e c2                	mov    es,dx
    4afd:	89 7e da             	mov    WORD PTR [bp-0x26],di
    4b00:	8c 46 dc             	mov    WORD PTR [bp-0x24],es
    4b03:	bf 2a 48             	mov    di,0x482a
    4b06:	0e                   	push   cs
    4b07:	57                   	push   di
    4b08:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4b0b:	06                   	push   es
    4b0c:	57                   	push   di
    4b0d:	9a 9b 3b 3c 4b       	call   0x4b3c:0x3b9b
    4b12:	89 c7                	mov    di,ax
    4b14:	8e c2                	mov    es,dx
    4b16:	06                   	push   es
    4b17:	57                   	push   di
    4b18:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b1b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4b1f:	bf 34 48             	mov    di,0x4834
    4b22:	9a 16 04 da 4d       	call   0x4dda:0x416
    4b27:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4b2a:	bf 46 48             	mov    di,0x4846
    4b2d:	0e                   	push   cs
    4b2e:	57                   	push   di
    4b2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b32:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4b37:	06                   	push   es
    4b38:	57                   	push   di
    4b39:	9a 9b 3b 72 4b       	call   0x4b72:0x3b9b
    4b3e:	89 c7                	mov    di,ax
    4b40:	8e c2                	mov    es,dx
    4b42:	06                   	push   es
    4b43:	57                   	push   di
    4b44:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b47:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4b4b:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    4b4e:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    4b51:	9b db 46 d6          	fild   DWORD PTR [bp-0x2a]
    4b55:	83 ec 08             	sub    sp,0x8
    4b58:	89 e3                	mov    bx,sp
    4b5a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4b5e:	90                   	nop
    4b5f:	9b                   	fwait
    4b60:	bf 58 48             	mov    di,0x4858
    4b63:	0e                   	push   cs
    4b64:	57                   	push   di
    4b65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b68:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    4b6d:	06                   	push   es
    4b6e:	57                   	push   di
    4b6f:	9a 9b 3b b9 4b       	call   0x4bb9:0x3b9b
    4b74:	89 c7                	mov    di,ax
    4b76:	8e c2                	mov    es,dx
    4b78:	06                   	push   es
    4b79:	57                   	push   di
    4b7a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4b7d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4b81:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    4b84:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    4b87:	9b db 46 d2          	fild   DWORD PTR [bp-0x2e]
    4b8b:	83 ec 08             	sub    sp,0x8
    4b8e:	89 e3                	mov    bx,sp
    4b90:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4b94:	90                   	nop
    4b95:	9b                   	fwait
    4b96:	9a a7 2e 8a 4c       	call   0x4c8a:0x2ea7
    4b9b:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    4ba1:	83 ec 08             	sub    sp,0x8
    4ba4:	89 e3                	mov    bx,sp
    4ba6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4baa:	90                   	nop
    4bab:	9b                   	fwait
    4bac:	bf 3c 48             	mov    di,0x483c
    4baf:	0e                   	push   cs
    4bb0:	57                   	push   di
    4bb1:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4bb4:	06                   	push   es
    4bb5:	57                   	push   di
    4bb6:	9a 9b 3b da 4b       	call   0x4bda:0x3b9b
    4bbb:	89 c7                	mov    di,ax
    4bbd:	8e c2                	mov    es,dx
    4bbf:	06                   	push   es
    4bc0:	57                   	push   di
    4bc1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4bc4:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4bc8:	bf 71 48             	mov    di,0x4871
    4bcb:	0e                   	push   cs
    4bcc:	57                   	push   di
    4bcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bd0:	26 c4 bd 0c 02       	les    di,DWORD PTR es:[di+0x20c]
    4bd5:	06                   	push   es
    4bd6:	57                   	push   di
    4bd7:	9a 9b 3b fa 4b       	call   0x4bfa:0x3b9b
    4bdc:	89 c7                	mov    di,ax
    4bde:	8e c2                	mov    es,dx
    4be0:	06                   	push   es
    4be1:	57                   	push   di
    4be2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4be5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4be9:	9b db 7e cc          	fstp   TBYTE PTR [bp-0x34]
    4bed:	bf 82 48             	mov    di,0x4882
    4bf0:	0e                   	push   cs
    4bf1:	57                   	push   di
    4bf2:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4bf5:	06                   	push   es
    4bf6:	57                   	push   di
    4bf7:	9a 9b 3b 37 4c       	call   0x4c37:0x3b9b
    4bfc:	89 c7                	mov    di,ax
    4bfe:	8e c2                	mov    es,dx
    4c00:	06                   	push   es
    4c01:	57                   	push   di
    4c02:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c05:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4c09:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    4c0c:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    4c0f:	9b db 46 d6          	fild   DWORD PTR [bp-0x2a]
    4c13:	9b db 6e cc          	fld    TBYTE PTR [bp-0x34]
    4c17:	9b de c9             	fmulp  st(1),st
    4c1a:	83 ec 08             	sub    sp,0x8
    4c1d:	89 e3                	mov    bx,sp
    4c1f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4c23:	90                   	nop
    4c24:	9b                   	fwait
    4c25:	bf 46 48             	mov    di,0x4846
    4c28:	0e                   	push   cs
    4c29:	57                   	push   di
    4c2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c2d:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4c32:	06                   	push   es
    4c33:	57                   	push   di
    4c34:	9a 9b 3b 66 4c       	call   0x4c66:0x3b9b
    4c39:	89 c7                	mov    di,ax
    4c3b:	8e c2                	mov    es,dx
    4c3d:	06                   	push   es
    4c3e:	57                   	push   di
    4c3f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c42:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4c46:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    4c49:	89 56 ca             	mov    WORD PTR [bp-0x36],dx
    4c4c:	9b db 46 c8          	fild   DWORD PTR [bp-0x38]
    4c50:	9b db 7e be          	fstp   TBYTE PTR [bp-0x42]
    4c54:	bf 93 48             	mov    di,0x4893
    4c57:	0e                   	push   cs
    4c58:	57                   	push   di
    4c59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c5c:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    4c61:	06                   	push   es
    4c62:	57                   	push   di
    4c63:	9a 9b 3b aa 4c       	call   0x4caa:0x3b9b
    4c68:	89 c7                	mov    di,ax
    4c6a:	8e c2                	mov    es,dx
    4c6c:	06                   	push   es
    4c6d:	57                   	push   di
    4c6e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c71:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4c75:	9b db 6e be          	fld    TBYTE PTR [bp-0x42]
    4c79:	9b de c9             	fmulp  st(1),st
    4c7c:	83 ec 08             	sub    sp,0x8
    4c7f:	89 e3                	mov    bx,sp
    4c81:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4c85:	90                   	nop
    4c86:	9b                   	fwait
    4c87:	9a a7 2e f4 4d       	call   0x4df4:0x2ea7
    4c8c:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    4c92:	83 ec 08             	sub    sp,0x8
    4c95:	89 e3                	mov    bx,sp
    4c97:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4c9b:	90                   	nop
    4c9c:	9b                   	fwait
    4c9d:	bf 65 48             	mov    di,0x4865
    4ca0:	0e                   	push   cs
    4ca1:	57                   	push   di
    4ca2:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4ca5:	06                   	push   es
    4ca6:	57                   	push   di
    4ca7:	9a 9b 3b cb 4c       	call   0x4ccb:0x3b9b
    4cac:	89 c7                	mov    di,ax
    4cae:	8e c2                	mov    es,dx
    4cb0:	06                   	push   es
    4cb1:	57                   	push   di
    4cb2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cb5:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4cb9:	bf b4 48             	mov    di,0x48b4
    4cbc:	0e                   	push   cs
    4cbd:	57                   	push   di
    4cbe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cc1:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    4cc6:	06                   	push   es
    4cc7:	57                   	push   di
    4cc8:	9a 9b 3b f0 4c       	call   0x4cf0:0x3b9b
    4ccd:	89 c7                	mov    di,ax
    4ccf:	8e c2                	mov    es,dx
    4cd1:	06                   	push   es
    4cd2:	57                   	push   di
    4cd3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cd6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4cda:	9b db 7e d0          	fstp   TBYTE PTR [bp-0x30]
    4cde:	bf c8 48             	mov    di,0x48c8
    4ce1:	0e                   	push   cs
    4ce2:	57                   	push   di
    4ce3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ce6:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    4ceb:	06                   	push   es
    4cec:	57                   	push   di
    4ced:	9a 9b 3b 1c 4d       	call   0x4d1c:0x3b9b
    4cf2:	89 c7                	mov    di,ax
    4cf4:	8e c2                	mov    es,dx
    4cf6:	06                   	push   es
    4cf7:	57                   	push   di
    4cf8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4cfb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4cff:	9b db 6e d0          	fld    TBYTE PTR [bp-0x30]
    4d03:	9b de c1             	faddp  st(1),st
    4d06:	9b db 7e c6          	fstp   TBYTE PTR [bp-0x3a]
    4d0a:	bf da 48             	mov    di,0x48da
    4d0d:	0e                   	push   cs
    4d0e:	57                   	push   di
    4d0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d12:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4d17:	06                   	push   es
    4d18:	57                   	push   di
    4d19:	9a 9b 3b 43 4d       	call   0x4d43:0x3b9b
    4d1e:	89 c7                	mov    di,ax
    4d20:	8e c2                	mov    es,dx
    4d22:	06                   	push   es
    4d23:	57                   	push   di
    4d24:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d27:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4d2b:	9b db 6e c6          	fld    TBYTE PTR [bp-0x3a]
    4d2f:	9b de c1             	faddp  st(1),st
    4d32:	9b db 7e bc          	fstp   TBYTE PTR [bp-0x44]
    4d36:	bf ea 48             	mov    di,0x48ea
    4d39:	0e                   	push   cs
    4d3a:	57                   	push   di
    4d3b:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4d3e:	06                   	push   es
    4d3f:	57                   	push   di
    4d40:	9a 9b 3b 6f 4d       	call   0x4d6f:0x3b9b
    4d45:	89 c7                	mov    di,ax
    4d47:	8e c2                	mov    es,dx
    4d49:	06                   	push   es
    4d4a:	57                   	push   di
    4d4b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d4e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4d52:	9b db 6e bc          	fld    TBYTE PTR [bp-0x44]
    4d56:	9b de c1             	faddp  st(1),st
    4d59:	9b db 7e b2          	fstp   TBYTE PTR [bp-0x4e]
    4d5d:	bf fb 48             	mov    di,0x48fb
    4d60:	0e                   	push   cs
    4d61:	57                   	push   di
    4d62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d65:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    4d6a:	06                   	push   es
    4d6b:	57                   	push   di
    4d6c:	9a 9b 3b 9d 4d       	call   0x4d9d:0x3b9b
    4d71:	89 c7                	mov    di,ax
    4d73:	8e c2                	mov    es,dx
    4d75:	06                   	push   es
    4d76:	57                   	push   di
    4d77:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4d7a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4d7e:	9b db 6e b2          	fld    TBYTE PTR [bp-0x4e]
    4d82:	9b de c1             	faddp  st(1),st
    4d85:	83 ec 08             	sub    sp,0x8
    4d88:	89 e3                	mov    bx,sp
    4d8a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4d8e:	90                   	nop
    4d8f:	9b                   	fwait
    4d90:	bf 82 48             	mov    di,0x4882
    4d93:	0e                   	push   cs
    4d94:	57                   	push   di
    4d95:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4d98:	06                   	push   es
    4d99:	57                   	push   di
    4d9a:	9a 9b 3b c0 4d       	call   0x4dc0:0x3b9b
    4d9f:	89 c7                	mov    di,ax
    4da1:	8e c2                	mov    es,dx
    4da3:	06                   	push   es
    4da4:	57                   	push   di
    4da5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4da8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4dac:	52                   	push   dx
    4dad:	50                   	push   ax
    4dae:	bf 07 49             	mov    di,0x4907
    4db1:	0e                   	push   cs
    4db2:	57                   	push   di
    4db3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4db6:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    4dbb:	06                   	push   es
    4dbc:	57                   	push   di
    4dbd:	9a 9b 3b 0e 4e       	call   0x4e0e:0x3b9b
    4dc2:	89 c7                	mov    di,ax
    4dc4:	8e c2                	mov    es,dx
    4dc6:	06                   	push   es
    4dc7:	57                   	push   di
    4dc8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4dcb:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4dcf:	59                   	pop    cx
    4dd0:	5b                   	pop    bx
    4dd1:	03 c1                	add    ax,cx
    4dd3:	13 d3                	adc    dx,bx
    4dd5:	71 05                	jno    0x4ddc
    4dd7:	9a 3e 04 53 4e       	call   0x4e53:0x43e
    4ddc:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    4ddf:	89 56 b0             	mov    WORD PTR [bp-0x50],dx
    4de2:	9b db 46 ae          	fild   DWORD PTR [bp-0x52]
    4de6:	83 ec 08             	sub    sp,0x8
    4de9:	89 e3                	mov    bx,sp
    4deb:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4def:	90                   	nop
    4df0:	9b                   	fwait
    4df1:	9a a7 2e 74 4e       	call   0x4e74:0x2ea7
    4df6:	83 ec 08             	sub    sp,0x8
    4df9:	89 e3                	mov    bx,sp
    4dfb:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4dff:	90                   	nop
    4e00:	9b                   	fwait
    4e01:	bf a4 48             	mov    di,0x48a4
    4e04:	0e                   	push   cs
    4e05:	57                   	push   di
    4e06:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4e09:	06                   	push   es
    4e0a:	57                   	push   di
    4e0b:	9a 9b 3b 2f 4e       	call   0x4e2f:0x3b9b
    4e10:	89 c7                	mov    di,ax
    4e12:	8e c2                	mov    es,dx
    4e14:	06                   	push   es
    4e15:	57                   	push   di
    4e16:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e19:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4e1d:	bf 1f 49             	mov    di,0x491f
    4e20:	0e                   	push   cs
    4e21:	57                   	push   di
    4e22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e25:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4e2a:	06                   	push   es
    4e2b:	57                   	push   di
    4e2c:	9a 9b 3b 94 4e       	call   0x4e94:0x3b9b
    4e31:	89 c7                	mov    di,ax
    4e33:	8e c2                	mov    es,dx
    4e35:	06                   	push   es
    4e36:	57                   	push   di
    4e37:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e3a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4e3e:	83 ec 08             	sub    sp,0x8
    4e41:	89 e3                	mov    bx,sp
    4e43:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4e47:	90                   	nop
    4e48:	9b                   	fwait
    4e49:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4e4c:	99                   	cwd
    4e4d:	bf 24 49             	mov    di,0x4924
    4e50:	9a 16 04 19 4f       	call   0x4f19:0x416
    4e55:	c1 e0 03             	shl    ax,0x3
    4e58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e5b:	03 f8                	add    di,ax
    4e5d:	26 ff b5 a5 04       	push   WORD PTR es:[di+0x4a5]
    4e62:	26 ff b5 a3 04       	push   WORD PTR es:[di+0x4a3]
    4e67:	26 ff b5 a1 04       	push   WORD PTR es:[di+0x4a1]
    4e6c:	26 ff b5 9f 04       	push   WORD PTR es:[di+0x49f]
    4e71:	9a a7 2e 5f 4f       	call   0x4f5f:0x2ea7
    4e76:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    4e7c:	83 ec 08             	sub    sp,0x8
    4e7f:	89 e3                	mov    bx,sp
    4e81:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4e85:	90                   	nop
    4e86:	9b                   	fwait
    4e87:	bf 10 49             	mov    di,0x4910
    4e8a:	0e                   	push   cs
    4e8b:	57                   	push   di
    4e8c:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4e8f:	06                   	push   es
    4e90:	57                   	push   di
    4e91:	9a 9b 3b b5 4e       	call   0x4eb5:0x3b9b
    4e96:	89 c7                	mov    di,ax
    4e98:	8e c2                	mov    es,dx
    4e9a:	06                   	push   es
    4e9b:	57                   	push   di
    4e9c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e9f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4ea3:	bf 3b 49             	mov    di,0x493b
    4ea6:	0e                   	push   cs
    4ea7:	57                   	push   di
    4ea8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eab:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4eb0:	06                   	push   es
    4eb1:	57                   	push   di
    4eb2:	9a 9b 3b dc 4e       	call   0x4edc:0x3b9b
    4eb7:	89 c7                	mov    di,ax
    4eb9:	8e c2                	mov    es,dx
    4ebb:	06                   	push   es
    4ebc:	57                   	push   di
    4ebd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ec0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4ec4:	83 ec 08             	sub    sp,0x8
    4ec7:	89 e3                	mov    bx,sp
    4ec9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4ecd:	90                   	nop
    4ece:	9b                   	fwait
    4ecf:	bf 82 48             	mov    di,0x4882
    4ed2:	0e                   	push   cs
    4ed3:	57                   	push   di
    4ed4:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4ed7:	06                   	push   es
    4ed8:	57                   	push   di
    4ed9:	9a 9b 3b ff 4e       	call   0x4eff:0x3b9b
    4ede:	89 c7                	mov    di,ax
    4ee0:	8e c2                	mov    es,dx
    4ee2:	06                   	push   es
    4ee3:	57                   	push   di
    4ee4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ee7:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4eeb:	52                   	push   dx
    4eec:	50                   	push   ax
    4eed:	bf 07 49             	mov    di,0x4907
    4ef0:	0e                   	push   cs
    4ef1:	57                   	push   di
    4ef2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ef5:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    4efa:	06                   	push   es
    4efb:	57                   	push   di
    4efc:	9a 9b 3b 3b 4f       	call   0x4f3b:0x3b9b
    4f01:	89 c7                	mov    di,ax
    4f03:	8e c2                	mov    es,dx
    4f05:	06                   	push   es
    4f06:	57                   	push   di
    4f07:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f0a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4f0e:	59                   	pop    cx
    4f0f:	5b                   	pop    bx
    4f10:	03 c1                	add    ax,cx
    4f12:	13 d3                	adc    dx,bx
    4f14:	71 05                	jno    0x4f1b
    4f16:	9a 3e 04 8b 50       	call   0x508b:0x43e
    4f1b:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    4f1e:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    4f21:	9b db 46 d6          	fild   DWORD PTR [bp-0x2a]
    4f25:	9b db 7e cc          	fstp   TBYTE PTR [bp-0x34]
    4f29:	bf 1f 49             	mov    di,0x491f
    4f2c:	0e                   	push   cs
    4f2d:	57                   	push   di
    4f2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f31:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4f36:	06                   	push   es
    4f37:	57                   	push   di
    4f38:	9a 9b 3b 7f 4f       	call   0x4f7f:0x3b9b
    4f3d:	89 c7                	mov    di,ax
    4f3f:	8e c2                	mov    es,dx
    4f41:	06                   	push   es
    4f42:	57                   	push   di
    4f43:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f46:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4f4a:	9b db 6e cc          	fld    TBYTE PTR [bp-0x34]
    4f4e:	9b de c9             	fmulp  st(1),st
    4f51:	83 ec 08             	sub    sp,0x8
    4f54:	89 e3                	mov    bx,sp
    4f56:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4f5a:	90                   	nop
    4f5b:	9b                   	fwait
    4f5c:	9a a7 2e 26 50       	call   0x5026:0x2ea7
    4f61:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    4f67:	83 ec 08             	sub    sp,0x8
    4f6a:	89 e3                	mov    bx,sp
    4f6c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4f70:	90                   	nop
    4f71:	9b                   	fwait
    4f72:	bf 2c 49             	mov    di,0x492c
    4f75:	0e                   	push   cs
    4f76:	57                   	push   di
    4f77:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    4f7a:	06                   	push   es
    4f7b:	57                   	push   di
    4f7c:	9a 9b 3b a0 4f       	call   0x4fa0:0x3b9b
    4f81:	89 c7                	mov    di,ax
    4f83:	8e c2                	mov    es,dx
    4f85:	06                   	push   es
    4f86:	57                   	push   di
    4f87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f8a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4f8e:	bf 45 49             	mov    di,0x4945
    4f91:	0e                   	push   cs
    4f92:	57                   	push   di
    4f93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f96:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    4f9b:	06                   	push   es
    4f9c:	57                   	push   di
    4f9d:	9a 9b 3b cf 4f       	call   0x4fcf:0x3b9b
    4fa2:	89 c7                	mov    di,ax
    4fa4:	8e c2                	mov    es,dx
    4fa6:	06                   	push   es
    4fa7:	57                   	push   di
    4fa8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fab:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4faf:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    4fb2:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    4fb5:	9b db 46 d6          	fild   DWORD PTR [bp-0x2a]
    4fb9:	9b db 7e cc          	fstp   TBYTE PTR [bp-0x34]
    4fbd:	bf 1f 49             	mov    di,0x491f
    4fc0:	0e                   	push   cs
    4fc1:	57                   	push   di
    4fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fc5:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4fca:	06                   	push   es
    4fcb:	57                   	push   di
    4fcc:	9a 9b 3b fd 4f       	call   0x4ffd:0x3b9b
    4fd1:	89 c7                	mov    di,ax
    4fd3:	8e c2                	mov    es,dx
    4fd5:	06                   	push   es
    4fd6:	57                   	push   di
    4fd7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fda:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4fde:	9b db 6e cc          	fld    TBYTE PTR [bp-0x34]
    4fe2:	9b de c9             	fmulp  st(1),st
    4fe5:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    4fe9:	90                   	nop
    4fea:	9b                   	fwait
    4feb:	bf 3b 49             	mov    di,0x493b
    4fee:	0e                   	push   cs
    4fef:	57                   	push   di
    4ff0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ff3:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4ff8:	06                   	push   es
    4ff9:	57                   	push   di
    4ffa:	9a 9b 3b 46 50       	call   0x5046:0x3b9b
    4fff:	89 c7                	mov    di,ax
    5001:	8e c2                	mov    es,dx
    5003:	06                   	push   es
    5004:	57                   	push   di
    5005:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5008:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    500c:	83 ec 08             	sub    sp,0x8
    500f:	89 e3                	mov    bx,sp
    5011:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5015:	90                   	nop
    5016:	9b                   	fwait
    5017:	ff 76 fc             	push   WORD PTR [bp-0x4]
    501a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    501d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5020:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5023:	9a a7 2e ac 50       	call   0x50ac:0x2ea7
    5028:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    502e:	83 ec 08             	sub    sp,0x8
    5031:	89 e3                	mov    bx,sp
    5033:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5037:	90                   	nop
    5038:	9b                   	fwait
    5039:	bf 4c 49             	mov    di,0x494c
    503c:	0e                   	push   cs
    503d:	57                   	push   di
    503e:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5041:	06                   	push   es
    5042:	57                   	push   di
    5043:	9a 9b 3b 67 50       	call   0x5067:0x3b9b
    5048:	89 c7                	mov    di,ax
    504a:	8e c2                	mov    es,dx
    504c:	06                   	push   es
    504d:	57                   	push   di
    504e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5051:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5055:	bf 3b 49             	mov    di,0x493b
    5058:	0e                   	push   cs
    5059:	57                   	push   di
    505a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    505d:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    5062:	06                   	push   es
    5063:	57                   	push   di
    5064:	9a 9b 3b cc 50       	call   0x50cc:0x3b9b
    5069:	89 c7                	mov    di,ax
    506b:	8e c2                	mov    es,dx
    506d:	06                   	push   es
    506e:	57                   	push   di
    506f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5072:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5076:	83 ec 08             	sub    sp,0x8
    5079:	89 e3                	mov    bx,sp
    507b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    507f:	90                   	nop
    5080:	9b                   	fwait
    5081:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5084:	99                   	cwd
    5085:	bf 24 49             	mov    di,0x4924
    5088:	9a 16 04 89 51       	call   0x5189:0x416
    508d:	c1 e0 03             	shl    ax,0x3
    5090:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5093:	03 f8                	add    di,ax
    5095:	26 ff b5 b5 04       	push   WORD PTR es:[di+0x4b5]
    509a:	26 ff b5 b3 04       	push   WORD PTR es:[di+0x4b3]
    509f:	26 ff b5 b1 04       	push   WORD PTR es:[di+0x4b1]
    50a4:	26 ff b5 af 04       	push   WORD PTR es:[di+0x4af]
    50a9:	9a a7 2e 20 51       	call   0x5120:0x2ea7
    50ae:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    50b4:	83 ec 08             	sub    sp,0x8
    50b7:	89 e3                	mov    bx,sp
    50b9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    50bd:	90                   	nop
    50be:	9b                   	fwait
    50bf:	bf 56 49             	mov    di,0x4956
    50c2:	0e                   	push   cs
    50c3:	57                   	push   di
    50c4:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    50c7:	06                   	push   es
    50c8:	57                   	push   di
    50c9:	9a 9b 3b f9 50       	call   0x50f9:0x3b9b
    50ce:	89 c7                	mov    di,ax
    50d0:	8e c2                	mov    es,dx
    50d2:	06                   	push   es
    50d3:	57                   	push   di
    50d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    50d7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    50db:	ff 76 fc             	push   WORD PTR [bp-0x4]
    50de:	ff 76 fa             	push   WORD PTR [bp-0x6]
    50e1:	ff 76 f8             	push   WORD PTR [bp-0x8]
    50e4:	ff 76 f6             	push   WORD PTR [bp-0xa]
    50e7:	bf 78 49             	mov    di,0x4978
    50ea:	0e                   	push   cs
    50eb:	57                   	push   di
    50ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50ef:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    50f4:	06                   	push   es
    50f5:	57                   	push   di
    50f6:	9a 9b 3b 3a 51       	call   0x513a:0x3b9b
    50fb:	89 c7                	mov    di,ax
    50fd:	8e c2                	mov    es,dx
    50ff:	06                   	push   es
    5100:	57                   	push   di
    5101:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5104:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5108:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    510b:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    510e:	9b db 46 d6          	fild   DWORD PTR [bp-0x2a]
    5112:	83 ec 08             	sub    sp,0x8
    5115:	89 e3                	mov    bx,sp
    5117:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    511b:	90                   	nop
    511c:	9b                   	fwait
    511d:	9a a7 2e aa 51       	call   0x51aa:0x2ea7
    5122:	83 ec 08             	sub    sp,0x8
    5125:	89 e3                	mov    bx,sp
    5127:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    512b:	90                   	nop
    512c:	9b                   	fwait
    512d:	bf 64 49             	mov    di,0x4964
    5130:	0e                   	push   cs
    5131:	57                   	push   di
    5132:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5135:	06                   	push   es
    5136:	57                   	push   di
    5137:	9a 9b 3b 5b 51       	call   0x515b:0x3b9b
    513c:	89 c7                	mov    di,ax
    513e:	8e c2                	mov    es,dx
    5140:	06                   	push   es
    5141:	57                   	push   di
    5142:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5145:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5149:	bf 78 49             	mov    di,0x4978
    514c:	0e                   	push   cs
    514d:	57                   	push   di
    514e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5151:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    5156:	06                   	push   es
    5157:	57                   	push   di
    5158:	9a 9b 3b ca 51       	call   0x51ca:0x3b9b
    515d:	89 c7                	mov    di,ax
    515f:	8e c2                	mov    es,dx
    5161:	06                   	push   es
    5162:	57                   	push   di
    5163:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5166:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    516a:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    516d:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    5170:	9b db 46 d6          	fild   DWORD PTR [bp-0x2a]
    5174:	83 ec 08             	sub    sp,0x8
    5177:	89 e3                	mov    bx,sp
    5179:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    517d:	90                   	nop
    517e:	9b                   	fwait
    517f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5182:	99                   	cwd
    5183:	bf 24 49             	mov    di,0x4924
    5186:	9a 16 04 19 52       	call   0x5219:0x416
    518b:	c1 e0 03             	shl    ax,0x3
    518e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5191:	03 f8                	add    di,ax
    5193:	26 ff b5 c5 04       	push   WORD PTR es:[di+0x4c5]
    5198:	26 ff b5 c3 04       	push   WORD PTR es:[di+0x4c3]
    519d:	26 ff b5 c1 04       	push   WORD PTR es:[di+0x4c1]
    51a2:	26 ff b5 bf 04       	push   WORD PTR es:[di+0x4bf]
    51a7:	9a a7 2e 3a 52       	call   0x523a:0x2ea7
    51ac:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    51b2:	83 ec 08             	sub    sp,0x8
    51b5:	89 e3                	mov    bx,sp
    51b7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    51bb:	90                   	nop
    51bc:	9b                   	fwait
    51bd:	bf 89 49             	mov    di,0x4989
    51c0:	0e                   	push   cs
    51c1:	57                   	push   di
    51c2:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    51c5:	06                   	push   es
    51c6:	57                   	push   di
    51c7:	9a 9b 3b eb 51       	call   0x51eb:0x3b9b
    51cc:	89 c7                	mov    di,ax
    51ce:	8e c2                	mov    es,dx
    51d0:	06                   	push   es
    51d1:	57                   	push   di
    51d2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51d5:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    51d9:	bf ac 49             	mov    di,0x49ac
    51dc:	0e                   	push   cs
    51dd:	57                   	push   di
    51de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51e1:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    51e6:	06                   	push   es
    51e7:	57                   	push   di
    51e8:	9a 9b 3b 5a 52       	call   0x525a:0x3b9b
    51ed:	89 c7                	mov    di,ax
    51ef:	8e c2                	mov    es,dx
    51f1:	06                   	push   es
    51f2:	57                   	push   di
    51f3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51f6:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    51fa:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    51fd:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    5200:	9b db 46 d6          	fild   DWORD PTR [bp-0x2a]
    5204:	83 ec 08             	sub    sp,0x8
    5207:	89 e3                	mov    bx,sp
    5209:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    520d:	90                   	nop
    520e:	9b                   	fwait
    520f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5212:	99                   	cwd
    5213:	bf 24 49             	mov    di,0x4924
    5216:	9a 16 04 5c 58       	call   0x585c:0x416
    521b:	c1 e0 03             	shl    ax,0x3
    521e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5221:	03 f8                	add    di,ax
    5223:	26 ff b5 d5 04       	push   WORD PTR es:[di+0x4d5]
    5228:	26 ff b5 d3 04       	push   WORD PTR es:[di+0x4d3]
    522d:	26 ff b5 d1 04       	push   WORD PTR es:[di+0x4d1]
    5232:	26 ff b5 cf 04       	push   WORD PTR es:[di+0x4cf]
    5237:	9a a7 2e ce 52       	call   0x52ce:0x2ea7
    523c:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    5242:	83 ec 08             	sub    sp,0x8
    5245:	89 e3                	mov    bx,sp
    5247:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    524b:	90                   	nop
    524c:	9b                   	fwait
    524d:	bf 9b 49             	mov    di,0x499b
    5250:	0e                   	push   cs
    5251:	57                   	push   di
    5252:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5255:	06                   	push   es
    5256:	57                   	push   di
    5257:	9a 9b 3b 7b 52       	call   0x527b:0x3b9b
    525c:	89 c7                	mov    di,ax
    525e:	8e c2                	mov    es,dx
    5260:	06                   	push   es
    5261:	57                   	push   di
    5262:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5265:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5269:	bf 45 49             	mov    di,0x4945
    526c:	0e                   	push   cs
    526d:	57                   	push   di
    526e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5271:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    5276:	06                   	push   es
    5277:	57                   	push   di
    5278:	9a 9b 3b aa 52       	call   0x52aa:0x3b9b
    527d:	89 c7                	mov    di,ax
    527f:	8e c2                	mov    es,dx
    5281:	06                   	push   es
    5282:	57                   	push   di
    5283:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5286:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    528a:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    528d:	89 56 d8             	mov    WORD PTR [bp-0x28],dx
    5290:	9b db 46 d6          	fild   DWORD PTR [bp-0x2a]
    5294:	9b db 7e cc          	fstp   TBYTE PTR [bp-0x34]
    5298:	bf 1f 49             	mov    di,0x491f
    529b:	0e                   	push   cs
    529c:	57                   	push   di
    529d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52a0:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    52a5:	06                   	push   es
    52a6:	57                   	push   di
    52a7:	9a 9b 3b e6 52       	call   0x52e6:0x3b9b
    52ac:	89 c7                	mov    di,ax
    52ae:	8e c2                	mov    es,dx
    52b0:	06                   	push   es
    52b1:	57                   	push   di
    52b2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52b5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    52b9:	9b db 6e cc          	fld    TBYTE PTR [bp-0x34]
    52bd:	9b de c9             	fmulp  st(1),st
    52c0:	83 ec 08             	sub    sp,0x8
    52c3:	89 e3                	mov    bx,sp
    52c5:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    52c9:	90                   	nop
    52ca:	9b                   	fwait
    52cb:	9a a6 2f 39 53       	call   0x5339:0x2fa6
    52d0:	9b db 7e b4          	fstp   TBYTE PTR [bp-0x4c]
    52d4:	bf c1 49             	mov    di,0x49c1
    52d7:	0e                   	push   cs
    52d8:	57                   	push   di
    52d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52dc:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    52e1:	06                   	push   es
    52e2:	57                   	push   di
    52e3:	9a 9b 3b 15 53       	call   0x5315:0x3b9b
    52e8:	89 c7                	mov    di,ax
    52ea:	8e c2                	mov    es,dx
    52ec:	06                   	push   es
    52ed:	57                   	push   di
    52ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    52f1:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    52f5:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    52f8:	89 56 ca             	mov    WORD PTR [bp-0x36],dx
    52fb:	9b db 46 c8          	fild   DWORD PTR [bp-0x38]
    52ff:	9b db 7e be          	fstp   TBYTE PTR [bp-0x42]
    5303:	bf d2 49             	mov    di,0x49d2
    5306:	0e                   	push   cs
    5307:	57                   	push   di
    5308:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    530b:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    5310:	06                   	push   es
    5311:	57                   	push   di
    5312:	9a 9b 3b 58 53       	call   0x5358:0x3b9b
    5317:	89 c7                	mov    di,ax
    5319:	8e c2                	mov    es,dx
    531b:	06                   	push   es
    531c:	57                   	push   di
    531d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5320:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5324:	9b db 6e be          	fld    TBYTE PTR [bp-0x42]
    5328:	9b de c9             	fmulp  st(1),st
    532b:	83 ec 08             	sub    sp,0x8
    532e:	89 e3                	mov    bx,sp
    5330:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5334:	90                   	nop
    5335:	9b                   	fwait
    5336:	9a a6 2f ab 53       	call   0x53ab:0x2fa6
    533b:	9b db 6e b4          	fld    TBYTE PTR [bp-0x4c]
    533f:	9b de c1             	faddp  st(1),st
    5342:	9b db 7e 9c          	fstp   TBYTE PTR [bp-0x64]
    5346:	bf e4 49             	mov    di,0x49e4
    5349:	0e                   	push   cs
    534a:	57                   	push   di
    534b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    534e:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    5353:	06                   	push   es
    5354:	57                   	push   di
    5355:	9a 9b 3b 87 53       	call   0x5387:0x3b9b
    535a:	89 c7                	mov    di,ax
    535c:	8e c2                	mov    es,dx
    535e:	06                   	push   es
    535f:	57                   	push   di
    5360:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5363:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5367:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    536a:	89 56 b2             	mov    WORD PTR [bp-0x4e],dx
    536d:	9b db 46 b0          	fild   DWORD PTR [bp-0x50]
    5371:	9b db 7e a6          	fstp   TBYTE PTR [bp-0x5a]
    5375:	bf f1 49             	mov    di,0x49f1
    5378:	0e                   	push   cs
    5379:	57                   	push   di
    537a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    537d:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    5382:	06                   	push   es
    5383:	57                   	push   di
    5384:	9a 9b 3b cc 53       	call   0x53cc:0x3b9b
    5389:	89 c7                	mov    di,ax
    538b:	8e c2                	mov    es,dx
    538d:	06                   	push   es
    538e:	57                   	push   di
    538f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5392:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5396:	9b db 6e a6          	fld    TBYTE PTR [bp-0x5a]
    539a:	9b de c9             	fmulp  st(1),st
    539d:	83 ec 08             	sub    sp,0x8
    53a0:	89 e3                	mov    bx,sp
    53a2:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    53a6:	90                   	nop
    53a7:	9b                   	fwait
    53a8:	9a a6 2f 9e 57       	call   0x579e:0x2fa6
    53ad:	9b db 6e 9c          	fld    TBYTE PTR [bp-0x64]
    53b1:	9b de c1             	faddp  st(1),st
    53b4:	83 ec 08             	sub    sp,0x8
    53b7:	89 e3                	mov    bx,sp
    53b9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    53bd:	90                   	nop
    53be:	9b                   	fwait
    53bf:	bf be 49             	mov    di,0x49be
    53c2:	0e                   	push   cs
    53c3:	57                   	push   di
    53c4:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    53c7:	06                   	push   es
    53c8:	57                   	push   di
    53c9:	9a 9b 3b e8 53       	call   0x53e8:0x3b9b
    53ce:	89 c7                	mov    di,ax
    53d0:	8e c2                	mov    es,dx
    53d2:	06                   	push   es
    53d3:	57                   	push   di
    53d4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53d7:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    53db:	bf 0c 4a             	mov    di,0x4a0c
    53de:	0e                   	push   cs
    53df:	57                   	push   di
    53e0:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    53e3:	06                   	push   es
    53e4:	57                   	push   di
    53e5:	9a 9b 3b 15 54       	call   0x5415:0x3b9b
    53ea:	89 c7                	mov    di,ax
    53ec:	8e c2                	mov    es,dx
    53ee:	06                   	push   es
    53ef:	57                   	push   di
    53f0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    53f3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    53f7:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    53fd:	83 ec 08             	sub    sp,0x8
    5400:	89 e3                	mov    bx,sp
    5402:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5406:	90                   	nop
    5407:	9b                   	fwait
    5408:	bf ff 49             	mov    di,0x49ff
    540b:	0e                   	push   cs
    540c:	57                   	push   di
    540d:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5410:	06                   	push   es
    5411:	57                   	push   di
    5412:	9a 9b 3b 31 54       	call   0x5431:0x3b9b
    5417:	89 c7                	mov    di,ax
    5419:	8e c2                	mov    es,dx
    541b:	06                   	push   es
    541c:	57                   	push   di
    541d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5420:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5424:	bf 22 4a             	mov    di,0x4a22
    5427:	0e                   	push   cs
    5428:	57                   	push   di
    5429:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    542c:	06                   	push   es
    542d:	57                   	push   di
    542e:	9a 9b 3b 5e 54       	call   0x545e:0x3b9b
    5433:	89 c7                	mov    di,ax
    5435:	8e c2                	mov    es,dx
    5437:	06                   	push   es
    5438:	57                   	push   di
    5439:	26 c4 3d             	les    di,DWORD PTR es:[di]
    543c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5440:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    5446:	83 ec 08             	sub    sp,0x8
    5449:	89 e3                	mov    bx,sp
    544b:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    544f:	90                   	nop
    5450:	9b                   	fwait
    5451:	bf 16 4a             	mov    di,0x4a16
    5454:	0e                   	push   cs
    5455:	57                   	push   di
    5456:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5459:	06                   	push   es
    545a:	57                   	push   di
    545b:	9a 9b 3b 7a 54       	call   0x547a:0x3b9b
    5460:	89 c7                	mov    di,ax
    5462:	8e c2                	mov    es,dx
    5464:	06                   	push   es
    5465:	57                   	push   di
    5466:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5469:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    546d:	bf 36 4a             	mov    di,0x4a36
    5470:	0e                   	push   cs
    5471:	57                   	push   di
    5472:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5475:	06                   	push   es
    5476:	57                   	push   di
    5477:	9a 9b 3b a7 54       	call   0x54a7:0x3b9b
    547c:	89 c7                	mov    di,ax
    547e:	8e c2                	mov    es,dx
    5480:	06                   	push   es
    5481:	57                   	push   di
    5482:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5485:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5489:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    548f:	83 ec 08             	sub    sp,0x8
    5492:	89 e3                	mov    bx,sp
    5494:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5498:	90                   	nop
    5499:	9b                   	fwait
    549a:	bf 2b 4a             	mov    di,0x4a2b
    549d:	0e                   	push   cs
    549e:	57                   	push   di
    549f:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    54a2:	06                   	push   es
    54a3:	57                   	push   di
    54a4:	9a 9b 3b c3 54       	call   0x54c3:0x3b9b
    54a9:	89 c7                	mov    di,ax
    54ab:	8e c2                	mov    es,dx
    54ad:	06                   	push   es
    54ae:	57                   	push   di
    54af:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54b2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    54b6:	bf 4d 4a             	mov    di,0x4a4d
    54b9:	0e                   	push   cs
    54ba:	57                   	push   di
    54bb:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    54be:	06                   	push   es
    54bf:	57                   	push   di
    54c0:	9a 9b 3b f0 54       	call   0x54f0:0x3b9b
    54c5:	89 c7                	mov    di,ax
    54c7:	8e c2                	mov    es,dx
    54c9:	06                   	push   es
    54ca:	57                   	push   di
    54cb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54ce:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    54d2:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    54d8:	83 ec 08             	sub    sp,0x8
    54db:	89 e3                	mov    bx,sp
    54dd:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    54e1:	90                   	nop
    54e2:	9b                   	fwait
    54e3:	bf 3e 4a             	mov    di,0x4a3e
    54e6:	0e                   	push   cs
    54e7:	57                   	push   di
    54e8:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    54eb:	06                   	push   es
    54ec:	57                   	push   di
    54ed:	9a 9b 3b 0c 55       	call   0x550c:0x3b9b
    54f2:	89 c7                	mov    di,ax
    54f4:	8e c2                	mov    es,dx
    54f6:	06                   	push   es
    54f7:	57                   	push   di
    54f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    54fb:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    54ff:	bf 69 4a             	mov    di,0x4a69
    5502:	0e                   	push   cs
    5503:	57                   	push   di
    5504:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5507:	06                   	push   es
    5508:	57                   	push   di
    5509:	9a 9b 3b 39 55       	call   0x5539:0x3b9b
    550e:	89 c7                	mov    di,ax
    5510:	8e c2                	mov    es,dx
    5512:	06                   	push   es
    5513:	57                   	push   di
    5514:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5517:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    551b:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    5521:	83 ec 08             	sub    sp,0x8
    5524:	89 e3                	mov    bx,sp
    5526:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    552a:	90                   	nop
    552b:	9b                   	fwait
    552c:	bf 59 4a             	mov    di,0x4a59
    552f:	0e                   	push   cs
    5530:	57                   	push   di
    5531:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5534:	06                   	push   es
    5535:	57                   	push   di
    5536:	9a 9b 3b 55 55       	call   0x5555:0x3b9b
    553b:	89 c7                	mov    di,ax
    553d:	8e c2                	mov    es,dx
    553f:	06                   	push   es
    5540:	57                   	push   di
    5541:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5544:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5548:	bf 85 4a             	mov    di,0x4a85
    554b:	0e                   	push   cs
    554c:	57                   	push   di
    554d:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5550:	06                   	push   es
    5551:	57                   	push   di
    5552:	9a 9b 3b 82 55       	call   0x5582:0x3b9b
    5557:	89 c7                	mov    di,ax
    5559:	8e c2                	mov    es,dx
    555b:	06                   	push   es
    555c:	57                   	push   di
    555d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5560:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5564:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    556a:	83 ec 08             	sub    sp,0x8
    556d:	89 e3                	mov    bx,sp
    556f:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5573:	90                   	nop
    5574:	9b                   	fwait
    5575:	bf 76 4a             	mov    di,0x4a76
    5578:	0e                   	push   cs
    5579:	57                   	push   di
    557a:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    557d:	06                   	push   es
    557e:	57                   	push   di
    557f:	9a 9b 3b 9e 55       	call   0x559e:0x3b9b
    5584:	89 c7                	mov    di,ax
    5586:	8e c2                	mov    es,dx
    5588:	06                   	push   es
    5589:	57                   	push   di
    558a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    558d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    5591:	bf be 49             	mov    di,0x49be
    5594:	0e                   	push   cs
    5595:	57                   	push   di
    5596:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5599:	06                   	push   es
    559a:	57                   	push   di
    559b:	9a 9b 3b be 55       	call   0x55be:0x3b9b
    55a0:	89 c7                	mov    di,ax
    55a2:	8e c2                	mov    es,dx
    55a4:	06                   	push   es
    55a5:	57                   	push   di
    55a6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55a9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    55ad:	9b db 7e c6          	fstp   TBYTE PTR [bp-0x3a]
    55b1:	bf fb 48             	mov    di,0x48fb
    55b4:	0e                   	push   cs
    55b5:	57                   	push   di
    55b6:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    55b9:	06                   	push   es
    55ba:	57                   	push   di
    55bb:	9a 9b 3b e3 55       	call   0x55e3:0x3b9b
    55c0:	89 c7                	mov    di,ax
    55c2:	8e c2                	mov    es,dx
    55c4:	06                   	push   es
    55c5:	57                   	push   di
    55c6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55c9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    55cd:	9b db 7e d0          	fstp   TBYTE PTR [bp-0x30]
    55d1:	bf fb 48             	mov    di,0x48fb
    55d4:	0e                   	push   cs
    55d5:	57                   	push   di
    55d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55d9:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    55de:	06                   	push   es
    55df:	57                   	push   di
    55e0:	9a 9b 3b 16 56       	call   0x5616:0x3b9b
    55e5:	89 c7                	mov    di,ax
    55e7:	8e c2                	mov    es,dx
    55e9:	06                   	push   es
    55ea:	57                   	push   di
    55eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    55ee:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    55f2:	9b db 6e d0          	fld    TBYTE PTR [bp-0x30]
    55f6:	9b de e1             	fsubrp st(1),st
    55f9:	9b db 6e c6          	fld    TBYTE PTR [bp-0x3a]
    55fd:	9b de c1             	faddp  st(1),st
    5600:	9b db 7e bc          	fstp   TBYTE PTR [bp-0x44]
    5604:	bf b4 48             	mov    di,0x48b4
    5607:	0e                   	push   cs
    5608:	57                   	push   di
    5609:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    560c:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    5611:	06                   	push   es
    5612:	57                   	push   di
    5613:	9a 9b 3b 42 56       	call   0x5642:0x3b9b
    5618:	89 c7                	mov    di,ax
    561a:	8e c2                	mov    es,dx
    561c:	06                   	push   es
    561d:	57                   	push   di
    561e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5621:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5625:	9b db 6e bc          	fld    TBYTE PTR [bp-0x44]
    5629:	9b de e1             	fsubrp st(1),st
    562c:	9b db 7e b2          	fstp   TBYTE PTR [bp-0x4e]
    5630:	bf c8 48             	mov    di,0x48c8
    5633:	0e                   	push   cs
    5634:	57                   	push   di
    5635:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5638:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    563d:	06                   	push   es
    563e:	57                   	push   di
    563f:	9a 9b 3b 6e 56       	call   0x566e:0x3b9b
    5644:	89 c7                	mov    di,ax
    5646:	8e c2                	mov    es,dx
    5648:	06                   	push   es
    5649:	57                   	push   di
    564a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    564d:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5651:	9b db 6e b2          	fld    TBYTE PTR [bp-0x4e]
    5655:	9b de e1             	fsubrp st(1),st
    5658:	9b db 7e a8          	fstp   TBYTE PTR [bp-0x58]
    565c:	bf da 48             	mov    di,0x48da
    565f:	0e                   	push   cs
    5660:	57                   	push   di
    5661:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5664:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    5669:	06                   	push   es
    566a:	57                   	push   di
    566b:	9a 9b 3b 95 56       	call   0x5695:0x3b9b
    5670:	89 c7                	mov    di,ax
    5672:	8e c2                	mov    es,dx
    5674:	06                   	push   es
    5675:	57                   	push   di
    5676:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5679:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    567d:	9b db 6e a8          	fld    TBYTE PTR [bp-0x58]
    5681:	9b de e1             	fsubrp st(1),st
    5684:	9b db 7e 9e          	fstp   TBYTE PTR [bp-0x62]
    5688:	bf ea 48             	mov    di,0x48ea
    568b:	0e                   	push   cs
    568c:	57                   	push   di
    568d:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    5690:	06                   	push   es
    5691:	57                   	push   di
    5692:	9a 9b 3b c1 56       	call   0x56c1:0x3b9b
    5697:	89 c7                	mov    di,ax
    5699:	8e c2                	mov    es,dx
    569b:	06                   	push   es
    569c:	57                   	push   di
    569d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    56a0:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    56a4:	9b db 6e 9e          	fld    TBYTE PTR [bp-0x62]
    56a8:	9b de e1             	fsubrp st(1),st
    56ab:	9b db 7e 94          	fstp   TBYTE PTR [bp-0x6c]
    56af:	bf 3b 49             	mov    di,0x493b
    56b2:	0e                   	push   cs
    56b3:	57                   	push   di
    56b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56b7:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    56bc:	06                   	push   es
    56bd:	57                   	push   di
    56be:	9a 9b 3b ed 56       	call   0x56ed:0x3b9b
    56c3:	89 c7                	mov    di,ax
    56c5:	8e c2                	mov    es,dx
    56c7:	06                   	push   es
    56c8:	57                   	push   di
    56c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    56cc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    56d0:	9b db 6e 94          	fld    TBYTE PTR [bp-0x6c]
    56d4:	9b de e1             	fsubrp st(1),st
    56d7:	9b db 7e 8a          	fstp   TBYTE PTR [bp-0x76]
    56db:	bf 9c 4a             	mov    di,0x4a9c
    56de:	0e                   	push   cs
    56df:	57                   	push   di
    56e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56e3:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    56e8:	06                   	push   es
    56e9:	57                   	push   di
    56ea:	9a 9b 3b 19 57       	call   0x5719:0x3b9b
    56ef:	89 c7                	mov    di,ax
    56f1:	8e c2                	mov    es,dx
    56f3:	06                   	push   es
    56f4:	57                   	push   di
    56f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    56f8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    56fc:	9b db 6e 8a          	fld    TBYTE PTR [bp-0x76]
    5700:	9b de e1             	fsubrp st(1),st
    5703:	9b db 7e 80          	fstp   TBYTE PTR [bp-0x80]
    5707:	bf ae 4a             	mov    di,0x4aae
    570a:	0e                   	push   cs
    570b:	57                   	push   di
    570c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    570f:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    5714:	06                   	push   es
    5715:	57                   	push   di
    5716:	9a 9b 3b 46 57       	call   0x5746:0x3b9b
    571b:	89 c7                	mov    di,ax
    571d:	8e c2                	mov    es,dx
    571f:	06                   	push   es
    5720:	57                   	push   di
    5721:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5724:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5728:	9b db 6e 80          	fld    TBYTE PTR [bp-0x80]
    572c:	9b de e1             	fsubrp st(1),st
    572f:	9b db be 68 ff       	fstp   TBYTE PTR [bp-0x98]
    5734:	bf 07 49             	mov    di,0x4907
    5737:	0e                   	push   cs
    5738:	57                   	push   di
    5739:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    573c:	26 c4 bd d4 01       	les    di,DWORD PTR es:[di+0x1d4]
    5741:	06                   	push   es
    5742:	57                   	push   di
    5743:	9a 9b 3b 79 57       	call   0x5779:0x3b9b
    5748:	89 c7                	mov    di,ax
    574a:	8e c2                	mov    es,dx
    574c:	06                   	push   es
    574d:	57                   	push   di
    574e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5751:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    5755:	89 86 7c ff          	mov    WORD PTR [bp-0x84],ax
    5759:	89 96 7e ff          	mov    WORD PTR [bp-0x82],dx
    575d:	9b db 86 7c ff       	fild   DWORD PTR [bp-0x84]
    5762:	9b db be 72 ff       	fstp   TBYTE PTR [bp-0x8e]
    5767:	bf bd 4a             	mov    di,0x4abd
    576a:	0e                   	push   cs
    576b:	57                   	push   di
    576c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    576f:	26 c4 bd c8 01       	les    di,DWORD PTR es:[di+0x1c8]
    5774:	06                   	push   es
    5775:	57                   	push   di
    5776:	9a 9b 3b c0 57       	call   0x57c0:0x3b9b
    577b:	89 c7                	mov    di,ax
    577d:	8e c2                	mov    es,dx
    577f:	06                   	push   es
    5780:	57                   	push   di
    5781:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5784:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5788:	9b db ae 72 ff       	fld    TBYTE PTR [bp-0x8e]
    578d:	9b de c9             	fmulp  st(1),st
    5790:	83 ec 08             	sub    sp,0x8
    5793:	89 e3                	mov    bx,sp
    5795:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5799:	90                   	nop
    579a:	9b                   	fwait
    579b:	9a a6 2f 20 58       	call   0x5820:0x2fa6
    57a0:	9b db ae 68 ff       	fld    TBYTE PTR [bp-0x98]
    57a5:	9b de e1             	fsubrp st(1),st
    57a8:	83 ec 08             	sub    sp,0x8
    57ab:	89 e3                	mov    bx,sp
    57ad:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    57b1:	90                   	nop
    57b2:	9b                   	fwait
    57b3:	bf 91 4a             	mov    di,0x4a91
    57b6:	0e                   	push   cs
    57b7:	57                   	push   di
    57b8:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    57bb:	06                   	push   es
    57bc:	57                   	push   di
    57bd:	9a 9b 3b dc 57       	call   0x57dc:0x3b9b
    57c2:	89 c7                	mov    di,ax
    57c4:	8e c2                	mov    es,dx
    57c6:	06                   	push   es
    57c7:	57                   	push   di
    57c8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57cb:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    57cf:	bf 91 4a             	mov    di,0x4a91
    57d2:	0e                   	push   cs
    57d3:	57                   	push   di
    57d4:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    57d7:	06                   	push   es
    57d8:	57                   	push   di
    57d9:	9a 9b 3b 03 58       	call   0x5803:0x3b9b
    57de:	89 c7                	mov    di,ax
    57e0:	8e c2                	mov    es,dx
    57e2:	06                   	push   es
    57e3:	57                   	push   di
    57e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57e7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    57eb:	83 ec 08             	sub    sp,0x8
    57ee:	89 e3                	mov    bx,sp
    57f0:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    57f4:	90                   	nop
    57f5:	9b                   	fwait
    57f6:	bf be 49             	mov    di,0x49be
    57f9:	0e                   	push   cs
    57fa:	57                   	push   di
    57fb:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    57fe:	06                   	push   es
    57ff:	57                   	push   di
    5800:	9a 9b 3b 40 58       	call   0x5840:0x3b9b
    5805:	89 c7                	mov    di,ax
    5807:	8e c2                	mov    es,dx
    5809:	06                   	push   es
    580a:	57                   	push   di
    580b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    580e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    5812:	83 ec 08             	sub    sp,0x8
    5815:	89 e3                	mov    bx,sp
    5817:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    581b:	90                   	nop
    581c:	9b                   	fwait
    581d:	9a a7 2e ff ff       	call   0xffff:0x2ea7
    5822:	9b 2e d8 0e 61 48    	fmul   DWORD PTR cs:0x4861
    5828:	83 ec 08             	sub    sp,0x8
    582b:	89 e3                	mov    bx,sp
    582d:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    5831:	90                   	nop
    5832:	9b                   	fwait
    5833:	bf cc 4a             	mov    di,0x4acc
    5836:	0e                   	push   cs
    5837:	57                   	push   di
    5838:	c4 7e da             	les    di,DWORD PTR [bp-0x26]
    583b:	06                   	push   es
    583c:	57                   	push   di
    583d:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    5842:	89 c7                	mov    di,ax
    5844:	8e c2                	mov    es,dx
    5846:	06                   	push   es
    5847:	57                   	push   di
    5848:	26 c4 3d             	les    di,DWORD PTR es:[di]
    584b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    584f:	c9                   	leave
    5850:	ca 08 00             	retf   0x8
    5853:	55                   	push   bp
    5854:	89 e5                	mov    bp,sp
    5856:	b8 04 00             	mov    ax,0x4
    5859:	9a 44 04 f0 58       	call   0x58f0:0x444
    585e:	83 ec 04             	sub    sp,0x4
    5861:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    5865:	b0 00                	mov    al,0x0
    5867:	75 01                	jne    0x586a
    5869:	40                   	inc    ax
    586a:	8a d0                	mov    dl,al
    586c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    586f:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    5873:	b0 00                	mov    al,0x0
    5875:	75 01                	jne    0x5878
    5877:	40                   	inc    ax
    5878:	22 c2                	and    al,dl
    587a:	08 c0                	or     al,al
    587c:	74 49                	je     0x58c7
    587e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5881:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    5886:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    588b:	26 3b 95 1e 03       	cmp    dx,WORD PTR es:[di+0x31e]
    5890:	75 35                	jne    0x58c7
    5892:	26 3b 85 1c 03       	cmp    ax,WORD PTR es:[di+0x31c]
    5897:	75 2e                	jne    0x58c7
    5899:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    589c:	31 c0                	xor    ax,ax
    589e:	26 89 05             	mov    WORD PTR es:[di],ax
    58a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58a4:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    58a9:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    58ae:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    58b3:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    58b8:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    58bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58c0:	06                   	push   es
    58c1:	57                   	push   di
    58c2:	9a 97 59 b7 5b       	call   0x5bb7:0x5997
    58c7:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    58ca:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    58ce:	74 14                	je     0x58e4
    58d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58d3:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    58d8:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    58dd:	06                   	push   es
    58de:	57                   	push   di
    58df:	9a 30 22 0d 59       	call   0x590d:0x2230
    58e4:	c9                   	leave
    58e5:	ca 0e 00             	retf   0xe
    58e8:	55                   	push   bp
    58e9:	89 e5                	mov    bp,sp
    58eb:	31 c0                	xor    ax,ax
    58ed:	9a 44 04 1b 59       	call   0x591b:0x444
    58f2:	6a 01                	push   0x1
    58f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58f7:	26 c4 bd 74 02       	les    di,DWORD PTR es:[di+0x274]
    58fc:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    5900:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    5904:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5908:	06                   	push   es
    5909:	57                   	push   di
    590a:	9a b2 77 2c 59       	call   0x592c:0x77b2
    590f:	c9                   	leave
    5910:	ca 08 00             	retf   0x8
    5913:	55                   	push   bp
    5914:	89 e5                	mov    bp,sp
    5916:	31 c0                	xor    ax,ax
    5918:	9a 44 04 3a 59       	call   0x593a:0x444
    591d:	6a 03                	push   0x3
    591f:	6a 00                	push   0x0
    5921:	6a 00                	push   0x0
    5923:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5927:	06                   	push   es
    5928:	57                   	push   di
    5929:	9a b2 77 4d 59       	call   0x594d:0x77b2
    592e:	c9                   	leave
    592f:	ca 08 00             	retf   0x8
    5932:	55                   	push   bp
    5933:	89 e5                	mov    bp,sp
    5935:	31 c0                	xor    ax,ax
    5937:	9a 44 04 5b 59       	call   0x595b:0x444
    593c:	68 05 01             	push   0x105
    593f:	bf 40 00             	mov    di,0x40
    5942:	1e                   	push   ds
    5943:	57                   	push   di
    5944:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5948:	06                   	push   es
    5949:	57                   	push   di
    594a:	9a b2 77 6c 59       	call   0x596c:0x77b2
    594f:	c9                   	leave
    5950:	ca 08 00             	retf   0x8
    5953:	55                   	push   bp
    5954:	89 e5                	mov    bp,sp
    5956:	31 c0                	xor    ax,ax
    5958:	9a 44 04 7b 59       	call   0x597b:0x444
    595d:	6a 04                	push   0x4
    595f:	6a 00                	push   0x0
    5961:	6a 00                	push   0x0
    5963:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5967:	06                   	push   es
    5968:	57                   	push   di
    5969:	9a b2 77 89 59       	call   0x5989:0x77b2
    596e:	c9                   	leave
    596f:	ca 08 00             	retf   0x8
    5972:	55                   	push   bp
    5973:	89 e5                	mov    bp,sp
    5975:	b8 04 00             	mov    ax,0x4
    5978:	9a 44 04 a0 59       	call   0x59a0:0x444
    597d:	83 ec 04             	sub    sp,0x4
    5980:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    5984:	06                   	push   es
    5985:	57                   	push   di
    5986:	9a 45 5d eb 5a       	call   0x5aeb:0x5d45
    598b:	c9                   	leave
    598c:	ca 08 00             	retf   0x8
    598f:	00 00                	add    BYTE PTR [bx+si],al
    5991:	00 00                	add    BYTE PTR [bx+si],al
    5993:	ff 00                	inc    WORD PTR [bx+si]
    5995:	00 00                	add    BYTE PTR [bx+si],al
    5997:	55                   	push   bp
    5998:	89 e5                	mov    bp,sp
    599a:	b8 08 00             	mov    ax,0x8
    599d:	9a 44 04 b9 59       	call   0x59b9:0x444
    59a2:	83 ec 08             	sub    sp,0x8
    59a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59a8:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    59ad:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    59b0:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    59b3:	bf 8f 59             	mov    di,0x598f
    59b6:	9a 16 04 fb 59       	call   0x59fb:0x416
    59bb:	3c 02                	cmp    al,0x2
    59bd:	76 10                	jbe    0x59cf
    59bf:	3c 09                	cmp    al,0x9
    59c1:	74 0c                	je     0x59cf
    59c3:	3c 15                	cmp    al,0x15
    59c5:	74 08                	je     0x59cf
    59c7:	3c 1b                	cmp    al,0x1b
    59c9:	74 04                	je     0x59cf
    59cb:	3c 20                	cmp    al,0x20
    59cd:	75 0d                	jne    0x59dc
    59cf:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    59d4:	c7 46 fe 00 00       	mov    WORD PTR [bp-0x2],0x0
    59d9:	e9 fe 00             	jmp    0x5ada
    59dc:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    59e0:	7c 08                	jl     0x59ea
    59e2:	7f 2f                	jg     0x5a13
    59e4:	83 7e 0a 09          	cmp    WORD PTR [bp+0xa],0x9
    59e8:	73 29                	jae    0x5a13
    59ea:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    59ed:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    59f0:	05 c8 e3             	add    ax,0xe3c8
    59f3:	83 d2 21             	adc    dx,0x21
    59f6:	71 05                	jno    0x59fd
    59f8:	9a 3e 04 08 5a       	call   0x5a08:0x43e
    59fd:	2d 02 00             	sub    ax,0x2
    5a00:	83 da 00             	sbb    dx,0x0
    5a03:	71 05                	jno    0x5a0a
    5a05:	9a 3e 04 32 5a       	call   0x5a32:0x43e
    5a0a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5a0d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5a10:	e9 c7 00             	jmp    0x5ada
    5a13:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    5a17:	7c 08                	jl     0x5a21
    5a19:	7f 2f                	jg     0x5a4a
    5a1b:	83 7e 0a 15          	cmp    WORD PTR [bp+0xa],0x15
    5a1f:	73 29                	jae    0x5a4a
    5a21:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5a24:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    5a27:	05 b0 e7             	add    ax,0xe7b0
    5a2a:	83 d2 21             	adc    dx,0x21
    5a2d:	71 05                	jno    0x5a34
    5a2f:	9a 3e 04 3f 5a       	call   0x5a3f:0x43e
    5a34:	2d 09 00             	sub    ax,0x9
    5a37:	83 da 00             	sbb    dx,0x0
    5a3a:	71 05                	jno    0x5a41
    5a3c:	9a 3e 04 83 5a       	call   0x5a83:0x43e
    5a41:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5a44:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5a47:	e9 90 00             	jmp    0x5ada
    5a4a:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    5a4e:	7c 08                	jl     0x5a58
    5a50:	7f 12                	jg     0x5a64
    5a52:	83 7e 0a 1b          	cmp    WORD PTR [bp+0xa],0x1b
    5a56:	73 0c                	jae    0x5a64
    5a58:	c7 46 fc 98 eb       	mov    WORD PTR [bp-0x4],0xeb98
    5a5d:	c7 46 fe 21 00       	mov    WORD PTR [bp-0x2],0x21
    5a62:	eb 76                	jmp    0x5ada
    5a64:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    5a68:	7c 08                	jl     0x5a72
    5a6a:	7f 2e                	jg     0x5a9a
    5a6c:	83 7e 0a 20          	cmp    WORD PTR [bp+0xa],0x20
    5a70:	73 28                	jae    0x5a9a
    5a72:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5a75:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    5a78:	05 80 ef             	add    ax,0xef80
    5a7b:	83 d2 21             	adc    dx,0x21
    5a7e:	71 05                	jno    0x5a85
    5a80:	9a 3e 04 90 5a       	call   0x5a90:0x43e
    5a85:	2d 1b 00             	sub    ax,0x1b
    5a88:	83 da 00             	sbb    dx,0x0
    5a8b:	71 05                	jno    0x5a92
    5a8d:	9a 3e 04 b9 5a       	call   0x5ab9:0x43e
    5a92:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5a95:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5a98:	eb 40                	jmp    0x5ada
    5a9a:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    5a9e:	7c 08                	jl     0x5aa8
    5aa0:	7f 2e                	jg     0x5ad0
    5aa2:	83 7e 0a 24          	cmp    WORD PTR [bp+0xa],0x24
    5aa6:	73 28                	jae    0x5ad0
    5aa8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    5aab:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    5aae:	05 68 f3             	add    ax,0xf368
    5ab1:	83 d2 21             	adc    dx,0x21
    5ab4:	71 05                	jno    0x5abb
    5ab6:	9a 3e 04 c6 5a       	call   0x5ac6:0x43e
    5abb:	2d 20 00             	sub    ax,0x20
    5abe:	83 da 00             	sbb    dx,0x0
    5ac1:	71 05                	jno    0x5ac8
    5ac3:	9a 3e 04 fa 5a       	call   0x5afa:0x43e
    5ac8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5acb:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5ace:	eb 0a                	jmp    0x5ada
    5ad0:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    5ad5:	c7 46 fe 00 00       	mov    WORD PTR [bp-0x2],0x0
    5ada:	6a 08                	push   0x8
    5adc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5adf:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5ae2:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    5ae6:	06                   	push   es
    5ae7:	57                   	push   di
    5ae8:	9a b2 77 e2 5b       	call   0x5be2:0x77b2
    5aed:	c9                   	leave
    5aee:	ca 0c 00             	retf   0xc
    5af1:	55                   	push   bp
    5af2:	89 e5                	mov    bp,sp
    5af4:	b8 0c 00             	mov    ax,0xc
    5af7:	9a 44 04 19 5b       	call   0x5b19:0x444
    5afc:	83 ec 0c             	sub    sp,0xc
    5aff:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    5b03:	74 03                	je     0x5b08
    5b05:	e9 b1 00             	jmp    0x5bb9
    5b08:	ff 76 14             	push   WORD PTR [bp+0x14]
    5b0b:	ff 76 12             	push   WORD PTR [bp+0x12]
    5b0e:	bf e7 18             	mov    di,0x18e7
    5b11:	b8 2c 5b             	mov    ax,0x5b2c
    5b14:	50                   	push   ax
    5b15:	57                   	push   di
    5b16:	9a 55 22 33 5b       	call   0x5b33:0x2255
    5b1b:	08 c0                	or     al,al
    5b1d:	75 03                	jne    0x5b22
    5b1f:	e9 97 00             	jmp    0x5bb9
    5b22:	ff 76 14             	push   WORD PTR [bp+0x14]
    5b25:	ff 76 12             	push   WORD PTR [bp+0x12]
    5b28:	bf e7 18             	mov    di,0x18e7
    5b2b:	b8 ff ff             	mov    ax,0xffff
    5b2e:	50                   	push   ax
    5b2f:	57                   	push   di
    5b30:	9a 73 22 c5 5b       	call   0x5bc5:0x2273
    5b35:	89 c7                	mov    di,ax
    5b37:	8e c2                	mov    es,dx
    5b39:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    5b3c:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    5b3f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5b42:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5b45:	8d 7e fc             	lea    di,[bp-0x4]
    5b48:	16                   	push   ss
    5b49:	57                   	push   di
    5b4a:	8d 7e f8             	lea    di,[bp-0x8]
    5b4d:	16                   	push   ss
    5b4e:	57                   	push   di
    5b4f:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    5b52:	06                   	push   es
    5b53:	57                   	push   di
    5b54:	9a 64 7f 7c 5b       	call   0x5b7c:0x7f64
    5b59:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    5b5c:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    5b61:	99                   	cwd
    5b62:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    5b65:	7c 07                	jl     0x5b6e
    5b67:	7f 15                	jg     0x5b7e
    5b69:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    5b6c:	77 10                	ja     0x5b7e
    5b6e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5b71:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5b74:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    5b77:	06                   	push   es
    5b78:	57                   	push   di
    5b79:	9a e1 6f a1 5b       	call   0x5ba1:0x6fe1
    5b7e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    5b81:	26 8b 85 00 01       	mov    ax,WORD PTR es:[di+0x100]
    5b86:	99                   	cwd
    5b87:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    5b8a:	7c 07                	jl     0x5b93
    5b8c:	7f 15                	jg     0x5ba3
    5b8e:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    5b91:	77 10                	ja     0x5ba3
    5b93:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5b96:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5b99:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    5b9c:	06                   	push   es
    5b9d:	57                   	push   di
    5b9e:	9a ec 73 25 5e       	call   0x5e25:0x73ec
    5ba3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    5ba6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    5ba9:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5bac:	ff 76 f8             	push   WORD PTR [bp-0x8]
    5baf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bb2:	06                   	push   es
    5bb3:	57                   	push   di
    5bb4:	9a 97 59 f2 5e       	call   0x5ef2:0x5997
    5bb9:	c9                   	leave
    5bba:	ca 10 00             	retf   0x10
    5bbd:	55                   	push   bp
    5bbe:	89 e5                	mov    bp,sp
    5bc0:	31 c0                	xor    ax,ax
    5bc2:	9a 44 04 f0 5b       	call   0x5bf0:0x444
    5bc7:	c7 06 44 01 0b 00    	mov    WORD PTR ds:0x144,0xb
    5bcd:	31 c0                	xor    ax,ax
    5bcf:	a3 46 01             	mov    ds:0x146,ax
    5bd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bd5:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    5bda:	a3 48 01             	mov    ds:0x148,ax
    5bdd:	06                   	push   es
    5bde:	57                   	push   di
    5bdf:	9a 56 55 0d 5c       	call   0x5c0d:0x5556
    5be4:	c9                   	leave
    5be5:	ca 08 00             	retf   0x8
    5be8:	55                   	push   bp
    5be9:	89 e5                	mov    bp,sp
    5beb:	31 c0                	xor    ax,ax
    5bed:	9a 44 04 1b 5c       	call   0x5c1b:0x444
    5bf2:	c7 06 44 01 0c 00    	mov    WORD PTR ds:0x144,0xc
    5bf8:	31 c0                	xor    ax,ax
    5bfa:	a3 46 01             	mov    ds:0x146,ax
    5bfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c00:	26 8b 85 9f 03       	mov    ax,WORD PTR es:[di+0x39f]
    5c05:	a3 48 01             	mov    ds:0x148,ax
    5c08:	06                   	push   es
    5c09:	57                   	push   di
    5c0a:	9a 56 55 ff ff       	call   0xffff:0x5556
    5c0f:	c9                   	leave
    5c10:	ca 08 00             	retf   0x8
    5c13:	55                   	push   bp
    5c14:	89 e5                	mov    bp,sp
    5c16:	31 c0                	xor    ax,ax
    5c18:	9a 44 04 36 5c       	call   0x5c36:0x444
    5c1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c20:	26 ff b5 9f 03       	push   WORD PTR es:[di+0x39f]
    5c25:	9a 44 0e ff ff       	call   0xffff:0xe44
    5c2a:	c9                   	leave
    5c2b:	ca 08 00             	retf   0x8
    5c2e:	55                   	push   bp
    5c2f:	89 e5                	mov    bp,sp
    5c31:	31 c0                	xor    ax,ax
    5c33:	9a 44 04 57 5c       	call   0x5c57:0x444
    5c38:	ff 36 50 01          	push   WORD PTR ds:0x150
    5c3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c3f:	26 ff b5 9f 03       	push   WORD PTR es:[di+0x39f]
    5c44:	6a 00                	push   0x0
    5c46:	9a a1 0c ff ff       	call   0xffff:0xca1
    5c4b:	c9                   	leave
    5c4c:	ca 08 00             	retf   0x8
    5c4f:	55                   	push   bp
    5c50:	89 e5                	mov    bp,sp
    5c52:	31 c0                	xor    ax,ax
    5c54:	9a 44 04 8b 5c       	call   0x5c8b:0x444
    5c59:	9a 42 09 ff ff       	call   0xffff:0x942
    5c5e:	c9                   	leave
    5c5f:	ca 08 00             	retf   0x8
    5c62:	cd cc                	int    0xcc
    5c64:	cc                   	int3
    5c65:	cc                   	int3
    5c66:	cc                   	int3
    5c67:	cc                   	int3
    5c68:	cc                   	int3
    5c69:	cc                   	int3
    5c6a:	fe                   	(bad)
    5c6b:	3f                   	aas
    5c6c:	00 00                	add    BYTE PTR [bx+si],al
    5c6e:	c8 42 66 66          	enter  0x6642,0x66
    5c72:	66 66 66 66 66 a6    	data32 data32 data32 data32 data32 cmps BYTE PTR ds:[si],BYTE PTR es:[di]
    5c78:	ff                   	(bad)
    5c79:	3f                   	aas
    5c7a:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    5c7e:	ff                   	(bad)
    5c7f:	7f 00                	jg     0x5c81
    5c81:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5c84:	e5 b8                	in     ax,0xb8
    5c86:	1c 00                	sbb    al,0x0
    5c88:	9a 44 04 a1 5c       	call   0x5ca1:0x444
    5c8d:	83 ec 1c             	sub    sp,0x1c
    5c90:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5c93:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5c96:	bf 94 00             	mov    di,0x94
    5c99:	b8 b4 5c             	mov    ax,0x5cb4
    5c9c:	50                   	push   ax
    5c9d:	57                   	push   di
    5c9e:	9a 55 22 bb 5c       	call   0x5cbb:0x2255
    5ca3:	08 c0                	or     al,al
    5ca5:	75 03                	jne    0x5caa
    5ca7:	e9 6d 02             	jmp    0x5f17
    5caa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5cad:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5cb0:	bf 94 00             	mov    di,0x94
    5cb3:	b8 cc 5c             	mov    ax,0x5ccc
    5cb6:	50                   	push   ax
    5cb7:	57                   	push   di
    5cb8:	9a 73 22 03 5d       	call   0x5d03:0x2273
    5cbd:	52                   	push   dx
    5cbe:	50                   	push   ax
    5cbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cc2:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    5cc7:	06                   	push   es
    5cc8:	57                   	push   di
    5cc9:	9a 2b 16 c0 5d       	call   0x5dc0:0x162b
    5cce:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5cd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5cd4:	26 8b 85 a3 03       	mov    ax,WORD PTR es:[di+0x3a3]
    5cd9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5cdc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5cdf:	3d 00 00             	cmp    ax,0x0
    5ce2:	75 2a                	jne    0x5d0e
    5ce4:	26 c7 85 a3 03 0a 00 	mov    WORD PTR es:[di+0x3a3],0xa
    5ceb:	9b 26 df 85 9c 03    	fild   WORD PTR es:[di+0x39c]
    5cf1:	9b 2e db 2e 62 5c    	fld    TBYTE PTR cs:0x5c62
    5cf7:	9b de c9             	fmulp  st(1),st
    5cfa:	9b 2e d9 06 6c 5c    	fld    DWORD PTR cs:0x5c6c
    5d00:	9a b2 04 2c 5d       	call   0x5d2c:0x4b2
    5d05:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    5d09:	90                   	nop
    5d0a:	9b                   	fwait
    5d0b:	e9 9f 00             	jmp    0x5dad
    5d0e:	3d 01 00             	cmp    ax,0x1
    5d11:	75 39                	jne    0x5d4c
    5d13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d16:	26 c7 85 a3 03 0f 00 	mov    WORD PTR es:[di+0x3a3],0xf
    5d1d:	26 8b 85 9c 03       	mov    ax,WORD PTR es:[di+0x39c]
    5d22:	b9 01 00             	mov    cx,0x1
    5d25:	f7 e9                	imul   cx
    5d27:	71 05                	jno    0x5d2e
    5d29:	9a 3e 04 42 5d       	call   0x5d42:0x43e
    5d2e:	99                   	cwd
    5d2f:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5d32:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5d35:	9b db 46 e8          	fild   DWORD PTR [bp-0x18]
    5d39:	9b 2e d9 06 6c 5c    	fld    DWORD PTR cs:0x5c6c
    5d3f:	9a b2 04 73 5d       	call   0x5d73:0x4b2
    5d44:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    5d48:	90                   	nop
    5d49:	9b                   	fwait
    5d4a:	eb 61                	jmp    0x5dad
    5d4c:	3d 02 00             	cmp    ax,0x2
    5d4f:	75 2c                	jne    0x5d7d
    5d51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d54:	26 c7 85 a3 03 14 00 	mov    WORD PTR es:[di+0x3a3],0x14
    5d5b:	9b 26 df 85 9c 03    	fild   WORD PTR es:[di+0x39c]
    5d61:	9b 2e db 2e 70 5c    	fld    TBYTE PTR cs:0x5c70
    5d67:	9b de c9             	fmulp  st(1),st
    5d6a:	9b 2e d9 06 6c 5c    	fld    DWORD PTR cs:0x5c6c
    5d70:	9a b2 04 8f 5d       	call   0x5d8f:0x4b2
    5d75:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    5d79:	90                   	nop
    5d7a:	9b                   	fwait
    5d7b:	eb 30                	jmp    0x5dad
    5d7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d80:	26 8b 85 9c 03       	mov    ax,WORD PTR es:[di+0x39c]
    5d85:	b9 01 00             	mov    cx,0x1
    5d88:	f7 e9                	imul   cx
    5d8a:	71 05                	jno    0x5d91
    5d8c:	9a 3e 04 a5 5d       	call   0x5da5:0x43e
    5d91:	99                   	cwd
    5d92:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    5d95:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    5d98:	9b db 46 e8          	fild   DWORD PTR [bp-0x18]
    5d9c:	9b 2e d9 06 6c 5c    	fld    DWORD PTR cs:0x5c6c
    5da2:	9a b2 04 ca 5d       	call   0x5dca:0x4b2
    5da7:	9b dd 5e ec          	fstp   QWORD PTR [bp-0x14]
    5dab:	90                   	nop
    5dac:	9b                   	fwait
    5dad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5db0:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    5db5:	89 7e e8             	mov    WORD PTR [bp-0x18],di
    5db8:	8c 46 ea             	mov    WORD PTR [bp-0x16],es
    5dbb:	06                   	push   es
    5dbc:	57                   	push   di
    5dbd:	9a 26 13 f5 5d       	call   0x5df5:0x1326
    5dc2:	2d 01 00             	sub    ax,0x1
    5dc5:	71 05                	jno    0x5dcc
    5dc7:	9a 3e 04 39 5e       	call   0x5e39:0x43e
    5dcc:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    5dcf:	31 c0                	xor    ax,ax
    5dd1:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    5dd4:	7f 34                	jg     0x5e0a
    5dd6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5dd9:	eb 03                	jmp    0x5dde
    5ddb:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    5dde:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    5de1:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    5de4:	b0 00                	mov    al,0x0
    5de6:	75 01                	jne    0x5de9
    5de8:	40                   	inc    ax
    5de9:	50                   	push   ax
    5dea:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5ded:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5df0:	06                   	push   es
    5df1:	57                   	push   di
    5df2:	9a 53 13 00 5e       	call   0x5e00:0x1353
    5df7:	89 c7                	mov    di,ax
    5df9:	8e c2                	mov    es,dx
    5dfb:	06                   	push   es
    5dfc:	57                   	push   di
    5dfd:	9a 75 12 e2 5f       	call   0x5fe2:0x1275
    5e02:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    5e05:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    5e08:	75 d1                	jne    0x5ddb
    5e0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e0d:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    5e12:	89 7e e8             	mov    WORD PTR [bp-0x18],di
    5e15:	8c 46 ea             	mov    WORD PTR [bp-0x16],es
    5e18:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    5e1d:	99                   	cwd
    5e1e:	52                   	push   dx
    5e1f:	50                   	push   ax
    5e20:	06                   	push   es
    5e21:	57                   	push   di
    5e22:	9a 45 73 54 5e       	call   0x5e54:0x7345
    5e27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e2a:	26 8b 85 a1 03       	mov    ax,WORD PTR es:[di+0x3a1]
    5e2f:	26 f7 ad a5 04       	imul   WORD PTR es:[di+0x4a5]
    5e34:	71 05                	jno    0x5e3b
    5e36:	9a 3e 04 43 5e       	call   0x5e43:0x43e
    5e3b:	05 01 00             	add    ax,0x1
    5e3e:	71 05                	jno    0x5e45
    5e40:	9a 3e 04 66 5e       	call   0x5e66:0x43e
    5e45:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5e48:	6a 00                	push   0x0
    5e4a:	6a 00                	push   0x0
    5e4c:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5e4f:	06                   	push   es
    5e50:	57                   	push   di
    5e51:	9a 30 6e d6 5e       	call   0x5ed6:0x6e30
    5e56:	8b d0                	mov    dx,ax
    5e58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e5b:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    5e5f:	2b c2                	sub    ax,dx
    5e61:	71 05                	jno    0x5e68
    5e63:	9a 3e 04 7e 5e       	call   0x5e7e:0x43e
    5e68:	99                   	cwd
    5e69:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    5e6c:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    5e6f:	9b db 46 e4          	fild   DWORD PTR [bp-0x1c]
    5e73:	9b dc 4e ec          	fmul   QWORD PTR [bp-0x14]
    5e77:	9b df 46 f8          	fild   WORD PTR [bp-0x8]
    5e7b:	9a b2 04 83 5e       	call   0x5e83:0x4b2
    5e80:	9a 2f 10 8b 5e       	call   0x5e8b:0x102f
    5e85:	bf 7a 5c             	mov    di,0x5c7a
    5e88:	9a 16 04 a8 5e       	call   0x5ea8:0x416
    5e8d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    5e90:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5e93:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    5e98:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    5e9d:	2d 01 00             	sub    ax,0x1
    5ea0:	83 da 00             	sbb    dx,0x0
    5ea3:	71 05                	jno    0x5eaa
    5ea5:	9a 3e 04 b0 5e       	call   0x5eb0:0x43e
    5eaa:	bf 7a 5c             	mov    di,0x5c7a
    5ead:	9a 16 04 2c 5f       	call   0x5f2c:0x416
    5eb2:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    5eb5:	b8 01 00             	mov    ax,0x1
    5eb8:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    5ebb:	7f 23                	jg     0x5ee0
    5ebd:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5ec0:	eb 03                	jmp    0x5ec5
    5ec2:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    5ec5:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    5ec8:	99                   	cwd
    5ec9:	52                   	push   dx
    5eca:	50                   	push   ax
    5ecb:	ff 76 f6             	push   WORD PTR [bp-0xa]
    5ece:	c4 7e e8             	les    di,DWORD PTR [bp-0x18]
    5ed1:	06                   	push   es
    5ed2:	57                   	push   di
    5ed3:	9a c9 70 56 5f       	call   0x5f56:0x70c9
    5ed8:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    5edb:	3b 46 e6             	cmp    ax,WORD PTR [bp-0x1a]
    5ede:	75 e2                	jne    0x5ec2
    5ee0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ee3:	26 8b 85 a3 03       	mov    ax,WORD PTR es:[di+0x3a3]
    5ee8:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    5eeb:	74 1a                	je     0x5f07
    5eed:	06                   	push   es
    5eee:	57                   	push   di
    5eef:	9a 0f 1f 05 5f       	call   0x5f05:0x1f0f
    5ef4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ef7:	81 c7 1c 03          	add    di,0x31c
    5efb:	06                   	push   es
    5efc:	57                   	push   di
    5efd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f00:	06                   	push   es
    5f01:	57                   	push   di
    5f02:	9a 58 28 15 5f       	call   0x5f15:0x2858
    5f07:	ff 76 08             	push   WORD PTR [bp+0x8]
    5f0a:	ff 76 06             	push   WORD PTR [bp+0x6]
    5f0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f10:	06                   	push   es
    5f11:	57                   	push   di
    5f12:	9a 56 14 cd 5f       	call   0x5fcd:0x1456
    5f17:	c9                   	leave
    5f18:	ca 08 00             	retf   0x8
    5f1b:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    5f1f:	ff                   	(bad)
    5f20:	7f 00                	jg     0x5f22
    5f22:	00 55 89             	add    BYTE PTR [di-0x77],dl
    5f25:	e5 b8                	in     ax,0xb8
    5f27:	10 00                	adc    BYTE PTR [bx+si],al
    5f29:	9a 44 04 8d 5f       	call   0x5f8d:0x444
    5f2e:	83 ec 10             	sub    sp,0x10
    5f31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f34:	26 c4 bd 1c 03       	les    di,DWORD PTR es:[di+0x31c]
    5f39:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    5f3c:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    5f3f:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    5f44:	75 03                	jne    0x5f49
    5f46:	e9 e9 00             	jmp    0x6032
    5f49:	26 8b 85 fe 00       	mov    ax,WORD PTR es:[di+0xfe]
    5f4e:	99                   	cwd
    5f4f:	52                   	push   dx
    5f50:	50                   	push   ax
    5f51:	06                   	push   es
    5f52:	57                   	push   di
    5f53:	9a 45 73 6a 5f       	call   0x5f6a:0x7345
    5f58:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    5f5b:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
    5f60:	26 ff b5 f2 00       	push   WORD PTR es:[di+0xf2]
    5f65:	06                   	push   es
    5f66:	57                   	push   di
    5f67:	9a 30 6e bb 5f       	call   0x5fbb:0x6e30
    5f6c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    5f6f:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    5f73:	7e 50                	jle    0x5fc5
    5f75:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    5f78:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    5f7d:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    5f82:	2d 01 00             	sub    ax,0x1
    5f85:	83 da 00             	sbb    dx,0x0
    5f88:	71 05                	jno    0x5f8f
    5f8a:	9a 3e 04 95 5f       	call   0x5f95:0x43e
    5f8f:	bf 1b 5f             	mov    di,0x5f1b
    5f92:	9a 16 04 ec 5f       	call   0x5fec:0x416
    5f97:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    5f9a:	b8 01 00             	mov    ax,0x1
    5f9d:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    5fa0:	7f 23                	jg     0x5fc5
    5fa2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5fa5:	eb 03                	jmp    0x5faa
    5fa7:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    5faa:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5fad:	99                   	cwd
    5fae:	52                   	push   dx
    5faf:	50                   	push   ax
    5fb0:	ff 76 fa             	push   WORD PTR [bp-0x6]
    5fb3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    5fb6:	06                   	push   es
    5fb7:	57                   	push   di
    5fb8:	9a c9 70 ff ff       	call   0xffff:0x70c9
    5fbd:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    5fc0:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    5fc3:	75 e2                	jne    0x5fa7
    5fc5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fc8:	06                   	push   es
    5fc9:	57                   	push   di
    5fca:	9a 0f 1f 30 60       	call   0x6030:0x1f0f
    5fcf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fd2:	26 c4 bd f0 02       	les    di,DWORD PTR es:[di+0x2f0]
    5fd7:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    5fda:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    5fdd:	06                   	push   es
    5fde:	57                   	push   di
    5fdf:	9a 26 13 0d 60       	call   0x600d:0x1326
    5fe4:	2d 01 00             	sub    ax,0x1
    5fe7:	71 05                	jno    0x5fee
    5fe9:	9a 3e 04 ff ff       	call   0xffff:0x43e
    5fee:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    5ff1:	31 c0                	xor    ax,ax
    5ff3:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    5ff6:	7f 2a                	jg     0x6022
    5ff8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5ffb:	eb 03                	jmp    0x6000
    5ffd:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    6000:	6a 00                	push   0x0
    6002:	ff 76 fc             	push   WORD PTR [bp-0x4]
    6005:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    6008:	06                   	push   es
    6009:	57                   	push   di
    600a:	9a 53 13 18 60       	call   0x6018:0x1353
    600f:	89 c7                	mov    di,ax
    6011:	8e c2                	mov    es,dx
    6013:	06                   	push   es
    6014:	57                   	push   di
    6015:	9a 75 12 ff ff       	call   0xffff:0x1275
    601a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    601d:	3b 46 f0             	cmp    ax,WORD PTR [bp-0x10]
    6020:	75 db                	jne    0x5ffd
    6022:	ff 76 08             	push   WORD PTR [bp+0x8]
    6025:	ff 76 06             	push   WORD PTR [bp+0x6]
    6028:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    602b:	06                   	push   es
    602c:	57                   	push   di
    602d:	9a 56 14 ff ff       	call   0xffff:0x1456
    6032:	c9                   	leave
    6033:	ca                   	.byte 0xca
    6034:	08                   	.byte 0x8
