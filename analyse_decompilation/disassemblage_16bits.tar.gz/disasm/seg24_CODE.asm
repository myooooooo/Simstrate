; ================================================================
; seg24_CODE  (20858 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	18 00                	sbb    BYTE PTR [bx+si],al
       2:	87 01                	xchg   WORD PTR [bx+di],ax
       4:	c2 00 b1             	ret    0xb100
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 9e 00 a8          	add    BYTE PTR [bp-0x5800],bl
       d:	01 fb                	add    bx,di
       f:	04 a1                	add    al,0xa1
      11:	01 39                	add    WORD PTR [bx+di],di
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 25 02 cb       	call   0xcb02:0x251f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 ff                	adc    bh,bh
      2d:	ff d6                	call   si
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c fc                	sbb    al,0xfc
      61:	4c                   	dec    sp
      62:	e2 2f                	loop   0x93
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	12 54 46             	adc    dl,BYTE PTR [si+0x46]
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	43                   	inc    bx
      a6:	44                   	inc    sp
      a7:	46                   	inc    si
      a8:	5f                   	pop    di
      a9:	46                   	inc    si
      aa:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
      af:	72 73                	jb     0x124
      b1:	01 00                	add    WORD PTR [bx+si],ax
      b3:	6d                   	ins    WORD PTR es:[di],dx
      b4:	51                   	push   cx
      b5:	9d                   	popf
      b6:	01 0a                	add    WORD PTR [bp+si],cx
      b8:	46                   	inc    si
      b9:	6f                   	outs   dx,WORD PTR ds:[si]
      ba:	72 6d                	jb     0x129
      bc:	43                   	inc    bx
      bd:	72 65                	jb     0x124
      bf:	61                   	popa
      c0:	74 65                	je     0x127
      c2:	0b 00                	or     ax,WORD PTR [bx+si]
      c4:	81 01 7c 01          	add    WORD PTR [bx+di],0x17c
      c8:	00 00                	add    BYTE PTR [bx+si],al
      ca:	0c 43                	or     al,0x43
      cc:	72 65                	jb     0x133
      ce:	54                   	push   sp
      cf:	61                   	popa
      d0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      d3:	53                   	push   bx
      d4:	49                   	dec    cx
      d5:	4d                   	dec    bp
      d6:	53                   	push   bx
      d7:	80 01 00             	add    BYTE PTR [bx+di],0x0
      da:	00 0c                	add    BYTE PTR [si],cl
      dc:	43                   	inc    bx
      dd:	72 65                	jb     0x144
      df:	54                   	push   sp
      e0:	61                   	popa
      e1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      e4:	53                   	push   bx
      e5:	41                   	inc    cx
      e6:	43                   	inc    bx
      e7:	47                   	inc    di
      e8:	84 01                	test   BYTE PTR [bx+di],al
      ea:	00 00                	add    BYTE PTR [bx+si],al
      ec:	0c 43                	or     al,0x43
      ee:	72 65                	jb     0x155
      f0:	54                   	push   sp
      f1:	61                   	popa
      f2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      f5:	53                   	push   bx
      f6:	41                   	inc    cx
      f7:	43                   	inc    bx
      f8:	50                   	push   ax
      f9:	88 01                	mov    BYTE PTR [bx+di],al
      fb:	00 00                	add    BYTE PTR [bx+si],al
      fd:	0c 43                	or     al,0x43
      ff:	72 65                	jb     0x166
     101:	54                   	push   sp
     102:	61                   	popa
     103:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     106:	53                   	push   bx
     107:	41                   	inc    cx
     108:	44                   	inc    sp
     109:	47                   	inc    di
     10a:	8c 01                	mov    WORD PTR [bx+di],es
     10c:	00 00                	add    BYTE PTR [bx+si],al
     10e:	0c 43                	or     al,0x43
     110:	72 65                	jb     0x177
     112:	54                   	push   sp
     113:	61                   	popa
     114:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     117:	53                   	push   bx
     118:	41                   	inc    cx
     119:	44                   	inc    sp
     11a:	50                   	push   ax
     11b:	90                   	nop
     11c:	01 00                	add    WORD PTR [bx+si],ax
     11e:	00 0c                	add    BYTE PTR [si],cl
     120:	43                   	inc    bx
     121:	72 65                	jb     0x188
     123:	54                   	push   sp
     124:	61                   	popa
     125:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     128:	53                   	push   bx
     129:	45                   	inc    bp
     12a:	44                   	inc    sp
     12b:	47                   	inc    di
     12c:	94                   	xchg   sp,ax
     12d:	01 00                	add    WORD PTR [bx+si],ax
     12f:	00 0c                	add    BYTE PTR [si],cl
     131:	43                   	inc    bx
     132:	72 65                	jb     0x199
     134:	54                   	push   sp
     135:	61                   	popa
     136:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     139:	53                   	push   bx
     13a:	45                   	inc    bp
     13b:	44                   	inc    sp
     13c:	50                   	push   ax
     13d:	98                   	cbw
     13e:	01 00                	add    WORD PTR [bx+si],ax
     140:	00 0c                	add    BYTE PTR [si],cl
     142:	43                   	inc    bx
     143:	72 65                	jb     0x1aa
     145:	54                   	push   sp
     146:	61                   	popa
     147:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     14a:	53                   	push   bx
     14b:	45                   	inc    bp
     14c:	44                   	inc    sp
     14d:	4d                   	dec    bp
     14e:	9c                   	pushf
     14f:	01 00                	add    WORD PTR [bx+si],ax
     151:	00 0c                	add    BYTE PTR [si],cl
     153:	43                   	inc    bx
     154:	72 65                	jb     0x1bb
     156:	54                   	push   sp
     157:	61                   	popa
     158:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     15b:	53                   	push   bx
     15c:	45                   	inc    bp
     15d:	52                   	push   dx
     15e:	47                   	inc    di
     15f:	a0 01 00             	mov    al,ds:0x1
     162:	00 0c                	add    BYTE PTR [si],cl
     164:	43                   	inc    bx
     165:	72 65                	jb     0x1cc
     167:	54                   	push   sp
     168:	61                   	popa
     169:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     16c:	53                   	push   bx
     16d:	45                   	inc    bp
     16e:	52                   	push   dx
     16f:	50                   	push   ax
     170:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     171:	01 00                	add    WORD PTR [bx+si],ax
     173:	00 0c                	add    BYTE PTR [si],cl
     175:	43                   	inc    bx
     176:	72 65                	jb     0x1dd
     178:	54                   	push   sp
     179:	61                   	popa
     17a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     17d:	53                   	push   bx
     17e:	4d                   	dec    bp
     17f:	52                   	push   dx
     180:	50                   	push   ax
     181:	01 00                	add    WORD PTR [bx+si],ax
     183:	38 01                	cmp    BYTE PTR [bx+di],al
     185:	1c 03                	sbb    al,0x3
     187:	07                   	pop    es
     188:	12 54 46             	adc    dl,BYTE PTR [si+0x46]
     18b:	6f                   	outs   dx,WORD PTR ds:[si]
     18c:	72 6d                	jb     0x1fb
     18e:	53                   	push   bx
     18f:	43                   	inc    bx
     190:	44                   	inc    sp
     191:	46                   	inc    si
     192:	5f                   	pop    di
     193:	46                   	inc    si
     194:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     199:	72 73                	jb     0x20e
     19b:	22 00                	and    al,BYTE PTR [bx+si]
     19d:	ac                   	lods   al,BYTE PTR ds:[si]
     19e:	48                   	dec    ax
     19f:	7b 06                	jnp    0x1a7
     1a1:	ff                   	(bad)
     1a2:	ff                   	(bad)
     1a3:	38 00                	cmp    BYTE PTR [bx+si],al
     1a5:	04 53                	add    al,0x53
     1a7:	63 64 66             	arpl   WORD PTR [si+0x66],sp
     1aa:	00 00                	add    BYTE PTR [bx+si],al
     1ac:	09 43 6c             	or     WORD PTR [bp+di+0x6c],ax
     1af:	65 55                	gs push bp
     1b1:	6e                   	outs   dx,BYTE PTR ds:[si]
     1b2:	69 71 75 65 0b       	imul   si,WORD PTR [bx+di+0x75],0xb65
     1b7:	50                   	push   ax
     1b8:	72 6f                	jb     0x229
     1ba:	67 72 61             	addr32 jb 0x21e
     1bd:	6d                   	ins    WORD PTR es:[di],dx
     1be:	4e                   	dec    si
     1bf:	61                   	popa
     1c0:	6d                   	ins    WORD PTR es:[di],dx
     1c1:	65 0e                	gs push cs
     1c3:	49                   	dec    cx
     1c4:	64 65 6e             	fs outs dx,BYTE PTR gs:[si]
     1c7:	74 69                	je     0x232
     1c9:	66 69 63 61 74 69 6f 	imul   esp,DWORD PTR [bp+di+0x61],0x6e6f6974
     1d0:	6e 
     1d1:	07                   	pop    es
     1d2:	56                   	push   si
     1d3:	65 72 73             	gs jb  0x249
     1d6:	69 6f 6e 0b 44       	imul   bp,WORD PTR [bx+0x6e],0x440b
     1db:	61                   	popa
     1dc:	74 65                	je     0x243
     1de:	56                   	push   si
     1df:	65 72 73             	gs jb  0x255
     1e2:	69 6f 6e 04 4e       	imul   bp,WORD PTR [bx+0x6e],0x4e04
     1e7:	6f                   	outs   dx,WORD PTR ds:[si]
     1e8:	6d                   	ins    WORD PTR es:[di],dx
     1e9:	34 0c                	xor    al,0xc
     1eb:	44                   	inc    sp
     1ec:	61                   	popa
     1ed:	74 65                	je     0x254
     1ef:	43                   	inc    bx
     1f0:	72 65                	jb     0x257
     1f2:	61                   	popa
     1f3:	74 69                	je     0x25e
     1f5:	6f                   	outs   dx,WORD PTR ds:[si]
     1f6:	6e                   	outs   dx,BYTE PTR ds:[si]
     1f7:	06                   	push   es
     1f8:	4e                   	dec    si
     1f9:	69 76 65 61 75       	imul   si,WORD PTR [bp+0x65],0x7561
     1fe:	0e                   	push   cs
     1ff:	50                   	push   ax
     200:	65 72 69             	gs jb  0x26c
     203:	6f                   	outs   dx,WORD PTR ds:[si]
     204:	64 65 45             	fs gs inc bp
     207:	6e                   	outs   dx,BYTE PTR ds:[si]
     208:	43                   	inc    bx
     209:	6f                   	outs   dx,WORD PTR ds:[si]
     20a:	75 72                	jne    0x27e
     20c:	73 0e                	jae    0x21c
     20e:	43                   	inc    bx
     20f:	6c                   	ins    BYTE PTR es:[di],dx
     210:	65 55                	gs push bp
     212:	6e                   	outs   dx,BYTE PTR ds:[si]
     213:	69 71 75 65 49       	imul   si,WORD PTR [bx+di+0x75],0x4965
     218:	6e                   	outs   dx,BYTE PTR ds:[si]
     219:	64 65 78 55          	fs gs js 0x272
     21d:	89 e5                	mov    bp,sp
     21f:	b8 08 00             	mov    ax,0x8
     222:	9a 44 04 3f 03       	call   0x33f:0x444
     227:	83 ec 08             	sub    sp,0x8
     22a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     22d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     230:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     233:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
     237:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     23a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     23d:	bf ac 01             	mov    di,0x1ac
     240:	0e                   	push   cs
     241:	57                   	push   di
     242:	6a 03                	push   0x3
     244:	6a 00                	push   0x0
     246:	6a 00                	push   0x0
     248:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     24b:	06                   	push   es
     24c:	57                   	push   di
     24d:	9a a1 2a 65 02       	call   0x265:0x2aa1
     252:	bf b6 01             	mov    di,0x1b6
     255:	0e                   	push   cs
     256:	57                   	push   di
     257:	6a 01                	push   0x1
     259:	6a 08                	push   0x8
     25b:	6a 00                	push   0x0
     25d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     260:	06                   	push   es
     261:	57                   	push   di
     262:	9a a1 2a 7a 02       	call   0x27a:0x2aa1
     267:	bf c2 01             	mov    di,0x1c2
     26a:	0e                   	push   cs
     26b:	57                   	push   di
     26c:	6a 08                	push   0x8
     26e:	6a 02                	push   0x2
     270:	6a 00                	push   0x0
     272:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     275:	06                   	push   es
     276:	57                   	push   di
     277:	9a a1 2a 8f 02       	call   0x28f:0x2aa1
     27c:	bf d1 01             	mov    di,0x1d1
     27f:	0e                   	push   cs
     280:	57                   	push   di
     281:	6a 08                	push   0x8
     283:	6a 02                	push   0x2
     285:	6a 00                	push   0x0
     287:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     28a:	06                   	push   es
     28b:	57                   	push   di
     28c:	9a a1 2a a4 02       	call   0x2a4:0x2aa1
     291:	bf d9 01             	mov    di,0x1d9
     294:	0e                   	push   cs
     295:	57                   	push   di
     296:	6a 09                	push   0x9
     298:	6a 00                	push   0x0
     29a:	6a 00                	push   0x0
     29c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     29f:	06                   	push   es
     2a0:	57                   	push   di
     2a1:	9a a1 2a b9 02       	call   0x2b9:0x2aa1
     2a6:	bf e5 01             	mov    di,0x1e5
     2a9:	0e                   	push   cs
     2aa:	57                   	push   di
     2ab:	6a 01                	push   0x1
     2ad:	6a 04                	push   0x4
     2af:	6a 00                	push   0x0
     2b1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     2b4:	06                   	push   es
     2b5:	57                   	push   di
     2b6:	9a a1 2a ce 02       	call   0x2ce:0x2aa1
     2bb:	bf ea 01             	mov    di,0x1ea
     2be:	0e                   	push   cs
     2bf:	57                   	push   di
     2c0:	6a 09                	push   0x9
     2c2:	6a 00                	push   0x0
     2c4:	6a 00                	push   0x0
     2c6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     2c9:	06                   	push   es
     2ca:	57                   	push   di
     2cb:	9a a1 2a e3 02       	call   0x2e3:0x2aa1
     2d0:	bf f7 01             	mov    di,0x1f7
     2d3:	0e                   	push   cs
     2d4:	57                   	push   di
     2d5:	6a 03                	push   0x3
     2d7:	6a 00                	push   0x0
     2d9:	6a 00                	push   0x0
     2db:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     2de:	06                   	push   es
     2df:	57                   	push   di
     2e0:	9a a1 2a f8 02       	call   0x2f8:0x2aa1
     2e5:	bf fe 01             	mov    di,0x1fe
     2e8:	0e                   	push   cs
     2e9:	57                   	push   di
     2ea:	6a 03                	push   0x3
     2ec:	6a 00                	push   0x0
     2ee:	6a 00                	push   0x0
     2f0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     2f3:	06                   	push   es
     2f4:	57                   	push   di
     2f5:	9a a1 2a 8e 04       	call   0x48e:0x2aa1
     2fa:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     2fd:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
     302:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     305:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     308:	bf 0d 02             	mov    di,0x20d
     30b:	0e                   	push   cs
     30c:	57                   	push   di
     30d:	bf ac 01             	mov    di,0x1ac
     310:	0e                   	push   cs
     311:	57                   	push   di
     312:	6a 03                	push   0x3
     314:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     317:	06                   	push   es
     318:	57                   	push   di
     319:	9a f6 18 a0 03       	call   0x3a0:0x18f6
     31e:	c9                   	leave
     31f:	ca 04 00             	retf   0x4
     322:	08 53 69             	or     BYTE PTR [bp+di+0x69],dl
     325:	6d                   	ins    WORD PTR es:[di],dx
     326:	73 74                	jae    0x39c
     328:	72 61                	jb     0x38b
     32a:	74 0a                	je     0x336
     32c:	31 34                	xor    WORD PTR [si],si
     32e:	2f                   	das
     32f:	30 35                	xor    BYTE PTR [di],dh
     331:	2f                   	das
     332:	31 39                	xor    WORD PTR [bx+di],di
     334:	39 39                	cmp    WORD PTR [bx+di],di
     336:	55                   	push   bp
     337:	89 e5                	mov    bp,sp
     339:	b8 18 01             	mov    ax,0x118
     33c:	9a 44 04 54 03       	call   0x354:0x444
     341:	81 ec 18 01          	sub    sp,0x118
     345:	bf 22 03             	mov    di,0x322
     348:	0e                   	push   cs
     349:	57                   	push   di
     34a:	8d 7e f0             	lea    di,[bp-0x10]
     34d:	16                   	push   ss
     34e:	57                   	push   di
     34f:	6a 08                	push   0x8
     351:	9a e7 17 6c 03       	call   0x36c:0x17e7
     356:	8d be e8 fe          	lea    di,[bp-0x118]
     35a:	16                   	push   ss
     35b:	57                   	push   di
     35c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     35f:	81 c7 84 01          	add    di,0x184
     363:	06                   	push   es
     364:	57                   	push   di
     365:	6a 05                	push   0x5
     367:	6a 08                	push   0x8
     369:	9a 0b 18 78 03       	call   0x378:0x180b
     36e:	8d 7e fa             	lea    di,[bp-0x6]
     371:	16                   	push   ss
     372:	57                   	push   di
     373:	6a 04                	push   0x4
     375:	9a e7 17 ea 03       	call   0x3ea:0x17e7
     37a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     37d:	89 7e e4             	mov    WORD PTR [bp-0x1c],di
     380:	8c 46 e6             	mov    WORD PTR [bp-0x1a],es
     383:	c7 46 dc 01 00       	mov    WORD PTR [bp-0x24],0x1
     388:	c7 46 de 00 00       	mov    WORD PTR [bp-0x22],0x0
     38d:	c6 46 e0 00          	mov    BYTE PTR [bp-0x20],0x0
     391:	8d 7e dc             	lea    di,[bp-0x24]
     394:	16                   	push   ss
     395:	57                   	push   di
     396:	6a 00                	push   0x0
     398:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
     39b:	06                   	push   es
     39c:	57                   	push   di
     39d:	9a 95 28 6a 09       	call   0x96a:0x2895
     3a2:	08 c0                	or     al,al
     3a4:	74 03                	je     0x3a9
     3a6:	e9 e7 00             	jmp    0x490
     3a9:	bf 2b 03             	mov    di,0x32b
     3ac:	0e                   	push   cs
     3ad:	57                   	push   di
     3ae:	9a 54 21 4d 04       	call   0x44d:0x2154
     3b3:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
     3b7:	90                   	nop
     3b8:	9b                   	fwait
     3b9:	c7 86 6c ff 01 00    	mov    WORD PTR [bp-0x94],0x1
     3bf:	c7 86 6e ff 00 00    	mov    WORD PTR [bp-0x92],0x0
     3c5:	c6 86 70 ff 00       	mov    BYTE PTR [bp-0x90],0x0
     3ca:	8d 46 f0             	lea    ax,[bp-0x10]
     3cd:	8c d2                	mov    dx,ss
     3cf:	89 86 74 ff          	mov    WORD PTR [bp-0x8c],ax
     3d3:	89 96 76 ff          	mov    WORD PTR [bp-0x8a],dx
     3d7:	c6 86 78 ff 04       	mov    BYTE PTR [bp-0x88],0x4
     3dc:	a1 42 05             	mov    ax,ds:0x542
     3df:	8b 1e 44 05          	mov    bx,WORD PTR ds:0x544
     3e3:	8b 16 46 05          	mov    dx,WORD PTR ds:0x546
     3e7:	9a 9d 0f 0f 04       	call   0x40f:0xf9d
     3ec:	9b db 7e d2          	fstp   TBYTE PTR [bp-0x2e]
     3f0:	8d 46 d2             	lea    ax,[bp-0x2e]
     3f3:	8c d2                	mov    dx,ss
     3f5:	89 86 7c ff          	mov    WORD PTR [bp-0x84],ax
     3f9:	89 96 7e ff          	mov    WORD PTR [bp-0x82],dx
     3fd:	c6 46 80 03          	mov    BYTE PTR [bp-0x80],0x3
     401:	a1 48 05             	mov    ax,ds:0x548
     404:	8b 1e 4a 05          	mov    bx,WORD PTR ds:0x54a
     408:	8b 16 4c 05          	mov    dx,WORD PTR ds:0x54c
     40c:	9a 9d 0f 51 06       	call   0x651:0xf9d
     411:	9b db 7e c8          	fstp   TBYTE PTR [bp-0x38]
     415:	8d 46 c8             	lea    ax,[bp-0x38]
     418:	8c d2                	mov    dx,ss
     41a:	89 46 84             	mov    WORD PTR [bp-0x7c],ax
     41d:	89 56 86             	mov    WORD PTR [bp-0x7a],dx
     420:	c6 46 88 03          	mov    BYTE PTR [bp-0x78],0x3
     424:	9b dd 46 e8          	fld    QWORD PTR [bp-0x18]
     428:	9b db 7e be          	fstp   TBYTE PTR [bp-0x42]
     42c:	8d 46 be             	lea    ax,[bp-0x42]
     42f:	8c d2                	mov    dx,ss
     431:	89 46 8c             	mov    WORD PTR [bp-0x74],ax
     434:	89 56 8e             	mov    WORD PTR [bp-0x72],dx
     437:	c6 46 90 03          	mov    BYTE PTR [bp-0x70],0x3
     43b:	8d 46 fa             	lea    ax,[bp-0x6]
     43e:	8c d2                	mov    dx,ss
     440:	89 46 94             	mov    WORD PTR [bp-0x6c],ax
     443:	89 56 96             	mov    WORD PTR [bp-0x6a],dx
     446:	c6 46 98 04          	mov    BYTE PTR [bp-0x68],0x4
     44a:	9a 89 15 ff ff       	call   0xffff:0x1589
     44f:	9b db 7e b4          	fstp   TBYTE PTR [bp-0x4c]
     453:	8d 46 b4             	lea    ax,[bp-0x4c]
     456:	8c d2                	mov    dx,ss
     458:	89 46 9c             	mov    WORD PTR [bp-0x64],ax
     45b:	89 56 9e             	mov    WORD PTR [bp-0x62],dx
     45e:	c6 46 a0 03          	mov    BYTE PTR [bp-0x60],0x3
     462:	a1 6e 01             	mov    ax,ds:0x16e
     465:	99                   	cwd
     466:	89 46 a4             	mov    WORD PTR [bp-0x5c],ax
     469:	89 56 a6             	mov    WORD PTR [bp-0x5a],dx
     46c:	c6 46 a8 00          	mov    BYTE PTR [bp-0x58],0x0
     470:	c7 46 ac 01 00       	mov    WORD PTR [bp-0x54],0x1
     475:	c7 46 ae 00 00       	mov    WORD PTR [bp-0x52],0x0
     47a:	c6 46 b0 00          	mov    BYTE PTR [bp-0x50],0x0
     47e:	8d be 6c ff          	lea    di,[bp-0x94]
     482:	16                   	push   ss
     483:	57                   	push   di
     484:	6a 08                	push   0x8
     486:	c4 7e e4             	les    di,DWORD PTR [bp-0x1c]
     489:	06                   	push   es
     48a:	57                   	push   di
     48b:	9a 21 53 7c 06       	call   0x67c:0x5321
     490:	c9                   	leave
     491:	ca 04 00             	retf   0x4
     494:	09 43 6c             	or     WORD PTR [bp+di+0x6c],ax
     497:	65 55                	gs push bp
     499:	6e                   	outs   dx,BYTE PTR ds:[si]
     49a:	69 71 75 65 14       	imul   si,WORD PTR [bx+di+0x75],0x1465
     49f:	44                   	inc    sp
     4a0:	61                   	popa
     4a1:	74 65                	je     0x508
     4a3:	56                   	push   si
     4a4:	61                   	popa
     4a5:	6c                   	ins    BYTE PTR es:[di],dx
     4a6:	69 64 69 74 65       	imul   sp,WORD PTR [si+0x69],0x6574
     4ab:	46                   	inc    si
     4ac:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     4b1:	72 73                	jb     0x526
     4b3:	06                   	push   es
     4b4:	4e                   	dec    si
     4b5:	69 76 65 61 75       	imul   si,WORD PTR [bp+0x65],0x7561
     4ba:	11 4e 6f             	adc    WORD PTR [bp+0x6f],cx
     4bd:	6d                   	ins    WORD PTR es:[di],dx
     4be:	62 72 65             	bound  si,DWORD PTR [bp+si+0x65]
     4c1:	45                   	inc    bp
     4c2:	6e                   	outs   dx,BYTE PTR ds:[si]
     4c3:	74 72                	je     0x537
     4c5:	65 70 72             	gs jo  0x53a
     4c8:	69 73 65 73 14       	imul   si,WORD PTR [bp+di+0x65],0x1473
     4cd:	43                   	inc    bx
     4ce:	61                   	popa
     4cf:	70 69                	jo     0x53a
     4d1:	74 61                	je     0x534
     4d3:	6c                   	ins    BYTE PTR es:[di],dx
     4d4:	53                   	push   bx
     4d5:	6f                   	outs   dx,WORD PTR ds:[si]
     4d6:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     4d9:	6c                   	ins    BYTE PTR es:[di],dx
     4da:	49                   	dec    cx
     4db:	6e                   	outs   dx,BYTE PTR ds:[si]
     4dc:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
     4e1:	11 4d 61             	adc    WORD PTR [di+0x61],cx
     4e4:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     4e7:	6e                   	outs   dx,BYTE PTR ds:[si]
     4e8:	65 73 49             	gs jae 0x534
     4eb:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ec:	69 74 69 61 6c       	imul   si,WORD PTR [si+0x69],0x6c61
     4f1:	65 73 12             	gs jae 0x506
     4f4:	44                   	inc    sp
     4f5:	75 72                	jne    0x569
     4f7:	65 65 41             	gs gs inc cx
     4fa:	6d                   	ins    WORD PTR es:[di],dx
     4fb:	6f                   	outs   dx,WORD PTR ds:[si]
     4fc:	72 74                	jb     0x572
     4fe:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     503:	65 6e                	outs   dx,BYTE PTR gs:[si]
     505:	74 11                	je     0x518
     507:	4d                   	dec    bp
     508:	6f                   	outs   dx,WORD PTR ds:[si]
     509:	64 65 41             	fs gs inc cx
     50c:	6d                   	ins    WORD PTR es:[di],dx
     50d:	6f                   	outs   dx,WORD PTR ds:[si]
     50e:	72 74                	jb     0x584
     510:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     515:	65 6e                	outs   dx,BYTE PTR gs:[si]
     517:	74 13                	je     0x52c
     519:	43                   	inc    bx
     51a:	6f                   	outs   dx,WORD PTR ds:[si]
     51b:	65 66 66 41          	gs data32 inc ecx
     51f:	6d                   	ins    WORD PTR es:[di],dx
     520:	6f                   	outs   dx,WORD PTR ds:[si]
     521:	72 74                	jb     0x597
     523:	44                   	inc    sp
     524:	65 67 72 65          	gs addr32 jb 0x58d
     528:	73 73                	jae    0x59d
     52a:	69 66 0a 48 53       	imul   sp,WORD PTR [bp+0xa],0x5348
     52f:	56                   	push   si
     530:	6f                   	outs   dx,WORD PTR ds:[si]
     531:	6c                   	ins    BYTE PTR es:[di],dx
     532:	75 6d                	jne    0x5a1
     534:	65 50                	gs push ax
     536:	63 0b                	arpl   WORD PTR [bp+di],cx
     538:	48                   	dec    ax
     539:	53                   	push   bx
     53a:	53                   	push   bx
     53b:	75 72                	jne    0x5af
     53d:	43                   	inc    bx
     53e:	6f                   	outs   dx,WORD PTR ds:[si]
     53f:	75 74                	jne    0x5b5
     541:	50                   	push   ax
     542:	63 0d                	arpl   WORD PTR [di],cx
     544:	49                   	dec    cx
     545:	46                   	inc    si
     546:	41                   	inc    cx
     547:	4e                   	dec    si
     548:	62 54 72             	bound  dx,DWORD PTR [si+0x72]
     54b:	61                   	popa
     54c:	6e                   	outs   dx,BYTE PTR ds:[si]
     54d:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     550:	73 09                	jae    0x55b
     552:	49                   	dec    cx
     553:	46                   	inc    si
     554:	41                   	inc    cx
     555:	53                   	push   bx
     556:	65 75 69             	gs jne 0x5c2
     559:	6c                   	ins    BYTE PTR es:[di],dx
     55a:	31 09                	xor    WORD PTR [bx+di],cx
     55c:	49                   	dec    cx
     55d:	46                   	inc    si
     55e:	41                   	inc    cx
     55f:	53                   	push   bx
     560:	65 75 69             	gs jne 0x5cc
     563:	6c                   	ins    BYTE PTR es:[di],dx
     564:	32 09                	xor    cl,BYTE PTR [bx+di]
     566:	49                   	dec    cx
     567:	46                   	inc    si
     568:	41                   	inc    cx
     569:	53                   	push   bx
     56a:	65 75 69             	gs jne 0x5d6
     56d:	6c                   	ins    BYTE PTR es:[di],dx
     56e:	33 09                	xor    cx,WORD PTR [bx+di]
     570:	49                   	dec    cx
     571:	46                   	inc    si
     572:	41                   	inc    cx
     573:	53                   	push   bx
     574:	65 75 69             	gs jne 0x5e0
     577:	6c                   	ins    BYTE PTR es:[di],dx
     578:	34 09                	xor    al,0x9
     57a:	49                   	dec    cx
     57b:	46                   	inc    si
     57c:	41                   	inc    cx
     57d:	53                   	push   bx
     57e:	65 75 69             	gs jne 0x5ea
     581:	6c                   	ins    BYTE PTR es:[di],dx
     582:	35 09 49             	xor    ax,0x4909
     585:	46                   	inc    si
     586:	41                   	inc    cx
     587:	53                   	push   bx
     588:	65 75 69             	gs jne 0x5f4
     58b:	6c                   	ins    BYTE PTR es:[di],dx
     58c:	36 09 49 46          	or     WORD PTR ss:[bx+di+0x46],cx
     590:	41                   	inc    cx
     591:	53                   	push   bx
     592:	65 75 69             	gs jne 0x5fe
     595:	6c                   	ins    BYTE PTR es:[di],dx
     596:	37                   	aaa
     597:	09 49 46             	or     WORD PTR [bx+di+0x46],cx
     59a:	41                   	inc    cx
     59b:	53                   	push   bx
     59c:	65 75 69             	gs jne 0x608
     59f:	6c                   	ins    BYTE PTR es:[di],dx
     5a0:	38 09                	cmp    BYTE PTR [bx+di],cl
     5a2:	49                   	dec    cx
     5a3:	46                   	inc    si
     5a4:	41                   	inc    cx
     5a5:	53                   	push   bx
     5a6:	65 75 69             	gs jne 0x612
     5a9:	6c                   	ins    BYTE PTR es:[di],dx
     5aa:	39 0a                	cmp    WORD PTR [bp+si],cx
     5ac:	49                   	dec    cx
     5ad:	46                   	inc    si
     5ae:	41                   	inc    cx
     5af:	53                   	push   bx
     5b0:	65 75 69             	gs jne 0x61c
     5b3:	6c                   	ins    BYTE PTR es:[di],dx
     5b4:	31 30                	xor    WORD PTR [bx+si],si
     5b6:	09 49 46             	or     WORD PTR [bx+di+0x46],cx
     5b9:	41                   	inc    cx
     5ba:	54                   	push   sp
     5bb:	61                   	popa
     5bc:	72 69                	jb     0x627
     5be:	66 31 09             	xor    DWORD PTR [bx+di],ecx
     5c1:	49                   	dec    cx
     5c2:	46                   	inc    si
     5c3:	41                   	inc    cx
     5c4:	54                   	push   sp
     5c5:	61                   	popa
     5c6:	72 69                	jb     0x631
     5c8:	66 32 09             	data32 xor cl,BYTE PTR [bx+di]
     5cb:	49                   	dec    cx
     5cc:	46                   	inc    si
     5cd:	41                   	inc    cx
     5ce:	54                   	push   sp
     5cf:	61                   	popa
     5d0:	72 69                	jb     0x63b
     5d2:	66 33 09             	xor    ecx,DWORD PTR [bx+di]
     5d5:	49                   	dec    cx
     5d6:	46                   	inc    si
     5d7:	41                   	inc    cx
     5d8:	54                   	push   sp
     5d9:	61                   	popa
     5da:	72 69                	jb     0x645
     5dc:	66 34 09             	data32 xor al,0x9
     5df:	49                   	dec    cx
     5e0:	46                   	inc    si
     5e1:	41                   	inc    cx
     5e2:	54                   	push   sp
     5e3:	61                   	popa
     5e4:	72 69                	jb     0x64f
     5e6:	66 35 09 49 46 41    	xor    eax,0x41464909
     5ec:	54                   	push   sp
     5ed:	61                   	popa
     5ee:	72 69                	jb     0x659
     5f0:	66 36 09 49 46       	or     DWORD PTR ss:[bx+di+0x46],ecx
     5f5:	41                   	inc    cx
     5f6:	54                   	push   sp
     5f7:	61                   	popa
     5f8:	72 69                	jb     0x663
     5fa:	66 37                	data32 aaa
     5fc:	09 49 46             	or     WORD PTR [bx+di+0x46],cx
     5ff:	41                   	inc    cx
     600:	54                   	push   sp
     601:	61                   	popa
     602:	72 69                	jb     0x66d
     604:	66 38 09             	data32 cmp BYTE PTR [bx+di],cl
     607:	49                   	dec    cx
     608:	46                   	inc    si
     609:	41                   	inc    cx
     60a:	54                   	push   sp
     60b:	61                   	popa
     60c:	72 69                	jb     0x677
     60e:	66 39 0a             	cmp    DWORD PTR [bp+si],ecx
     611:	49                   	dec    cx
     612:	46                   	inc    si
     613:	41                   	inc    cx
     614:	54                   	push   sp
     615:	61                   	popa
     616:	72 69                	jb     0x681
     618:	66 31 30             	xor    DWORD PTR [bx+si],esi
     61b:	0a 49 46             	or     cl,BYTE PTR [bx+di+0x46]
     61e:	41                   	inc    cx
     61f:	54                   	push   sp
     620:	61                   	popa
     621:	72 69                	jb     0x68c
     623:	66 31 31             	xor    DWORD PTR [bx+di],esi
     626:	0a 56 61             	or     dl,BYTE PTR [bp+0x61]
     629:	6c                   	ins    BYTE PTR es:[di],dx
     62a:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
     62f:	6f                   	outs   dx,WORD PTR ds:[si]
     630:	6e                   	outs   dx,BYTE PTR ds:[si]
     631:	07                   	pop    es
     632:	53                   	push   bx
     633:	70 65                	jo     0x69a
     635:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     638:	6c                   	ins    BYTE PTR es:[di],dx
     639:	0e                   	push   cs
     63a:	43                   	inc    bx
     63b:	6c                   	ins    BYTE PTR es:[di],dx
     63c:	65 55                	gs push bp
     63e:	6e                   	outs   dx,BYTE PTR ds:[si]
     63f:	69 71 75 65 49       	imul   si,WORD PTR [bx+di+0x75],0x4965
     644:	6e                   	outs   dx,BYTE PTR ds:[si]
     645:	64 65 78 55          	fs gs js 0x69e
     649:	89 e5                	mov    bp,sp
     64b:	b8 08 00             	mov    ax,0x8
     64e:	9a 44 04 7d 09       	call   0x97d:0x444
     653:	83 ec 08             	sub    sp,0x8
     656:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     659:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     65c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     65f:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
     663:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     666:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     669:	bf 94 04             	mov    di,0x494
     66c:	0e                   	push   cs
     66d:	57                   	push   di
     66e:	6a 03                	push   0x3
     670:	6a 00                	push   0x0
     672:	6a 00                	push   0x0
     674:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     677:	06                   	push   es
     678:	57                   	push   di
     679:	9a a1 2a 91 06       	call   0x691:0x2aa1
     67e:	bf 9e 04             	mov    di,0x49e
     681:	0e                   	push   cs
     682:	57                   	push   di
     683:	6a 03                	push   0x3
     685:	6a 00                	push   0x0
     687:	6a 00                	push   0x0
     689:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     68c:	06                   	push   es
     68d:	57                   	push   di
     68e:	9a a1 2a a6 06       	call   0x6a6:0x2aa1
     693:	bf b3 04             	mov    di,0x4b3
     696:	0e                   	push   cs
     697:	57                   	push   di
     698:	6a 03                	push   0x3
     69a:	6a 00                	push   0x0
     69c:	6a 00                	push   0x0
     69e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     6a1:	06                   	push   es
     6a2:	57                   	push   di
     6a3:	9a a1 2a bb 06       	call   0x6bb:0x2aa1
     6a8:	bf ba 04             	mov    di,0x4ba
     6ab:	0e                   	push   cs
     6ac:	57                   	push   di
     6ad:	6a 03                	push   0x3
     6af:	6a 00                	push   0x0
     6b1:	6a 00                	push   0x0
     6b3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     6b6:	06                   	push   es
     6b7:	57                   	push   di
     6b8:	9a a1 2a d0 06       	call   0x6d0:0x2aa1
     6bd:	bf cc 04             	mov    di,0x4cc
     6c0:	0e                   	push   cs
     6c1:	57                   	push   di
     6c2:	6a 08                	push   0x8
     6c4:	6a 02                	push   0x2
     6c6:	6a 00                	push   0x0
     6c8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     6cb:	06                   	push   es
     6cc:	57                   	push   di
     6cd:	9a a1 2a e5 06       	call   0x6e5:0x2aa1
     6d2:	bf e1 04             	mov    di,0x4e1
     6d5:	0e                   	push   cs
     6d6:	57                   	push   di
     6d7:	6a 03                	push   0x3
     6d9:	6a 00                	push   0x0
     6db:	6a 00                	push   0x0
     6dd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     6e0:	06                   	push   es
     6e1:	57                   	push   di
     6e2:	9a a1 2a fa 06       	call   0x6fa:0x2aa1
     6e7:	bf f3 04             	mov    di,0x4f3
     6ea:	0e                   	push   cs
     6eb:	57                   	push   di
     6ec:	6a 03                	push   0x3
     6ee:	6a 00                	push   0x0
     6f0:	6a 00                	push   0x0
     6f2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     6f5:	06                   	push   es
     6f6:	57                   	push   di
     6f7:	9a a1 2a 0f 07       	call   0x70f:0x2aa1
     6fc:	bf 06 05             	mov    di,0x506
     6ff:	0e                   	push   cs
     700:	57                   	push   di
     701:	6a 03                	push   0x3
     703:	6a 00                	push   0x0
     705:	6a 00                	push   0x0
     707:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     70a:	06                   	push   es
     70b:	57                   	push   di
     70c:	9a a1 2a 24 07       	call   0x724:0x2aa1
     711:	bf 18 05             	mov    di,0x518
     714:	0e                   	push   cs
     715:	57                   	push   di
     716:	6a 08                	push   0x8
     718:	6a 02                	push   0x2
     71a:	6a 00                	push   0x0
     71c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     71f:	06                   	push   es
     720:	57                   	push   di
     721:	9a a1 2a 39 07       	call   0x739:0x2aa1
     726:	bf 2c 05             	mov    di,0x52c
     729:	0e                   	push   cs
     72a:	57                   	push   di
     72b:	6a 08                	push   0x8
     72d:	6a 02                	push   0x2
     72f:	6a 00                	push   0x0
     731:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     734:	06                   	push   es
     735:	57                   	push   di
     736:	9a a1 2a 4e 07       	call   0x74e:0x2aa1
     73b:	bf 37 05             	mov    di,0x537
     73e:	0e                   	push   cs
     73f:	57                   	push   di
     740:	6a 08                	push   0x8
     742:	6a 02                	push   0x2
     744:	6a 00                	push   0x0
     746:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     749:	06                   	push   es
     74a:	57                   	push   di
     74b:	9a a1 2a 63 07       	call   0x763:0x2aa1
     750:	bf 43 05             	mov    di,0x543
     753:	0e                   	push   cs
     754:	57                   	push   di
     755:	6a 03                	push   0x3
     757:	6a 00                	push   0x0
     759:	6a 00                	push   0x0
     75b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     75e:	06                   	push   es
     75f:	57                   	push   di
     760:	9a a1 2a 78 07       	call   0x778:0x2aa1
     765:	bf 51 05             	mov    di,0x551
     768:	0e                   	push   cs
     769:	57                   	push   di
     76a:	6a 08                	push   0x8
     76c:	6a 02                	push   0x2
     76e:	6a 00                	push   0x0
     770:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     773:	06                   	push   es
     774:	57                   	push   di
     775:	9a a1 2a 8d 07       	call   0x78d:0x2aa1
     77a:	bf 5b 05             	mov    di,0x55b
     77d:	0e                   	push   cs
     77e:	57                   	push   di
     77f:	6a 08                	push   0x8
     781:	6a 02                	push   0x2
     783:	6a 00                	push   0x0
     785:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     788:	06                   	push   es
     789:	57                   	push   di
     78a:	9a a1 2a a2 07       	call   0x7a2:0x2aa1
     78f:	bf 65 05             	mov    di,0x565
     792:	0e                   	push   cs
     793:	57                   	push   di
     794:	6a 08                	push   0x8
     796:	6a 02                	push   0x2
     798:	6a 00                	push   0x0
     79a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     79d:	06                   	push   es
     79e:	57                   	push   di
     79f:	9a a1 2a b7 07       	call   0x7b7:0x2aa1
     7a4:	bf 6f 05             	mov    di,0x56f
     7a7:	0e                   	push   cs
     7a8:	57                   	push   di
     7a9:	6a 08                	push   0x8
     7ab:	6a 02                	push   0x2
     7ad:	6a 00                	push   0x0
     7af:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     7b2:	06                   	push   es
     7b3:	57                   	push   di
     7b4:	9a a1 2a cc 07       	call   0x7cc:0x2aa1
     7b9:	bf 79 05             	mov    di,0x579
     7bc:	0e                   	push   cs
     7bd:	57                   	push   di
     7be:	6a 08                	push   0x8
     7c0:	6a 02                	push   0x2
     7c2:	6a 00                	push   0x0
     7c4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     7c7:	06                   	push   es
     7c8:	57                   	push   di
     7c9:	9a a1 2a e1 07       	call   0x7e1:0x2aa1
     7ce:	bf 83 05             	mov    di,0x583
     7d1:	0e                   	push   cs
     7d2:	57                   	push   di
     7d3:	6a 08                	push   0x8
     7d5:	6a 02                	push   0x2
     7d7:	6a 00                	push   0x0
     7d9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     7dc:	06                   	push   es
     7dd:	57                   	push   di
     7de:	9a a1 2a f6 07       	call   0x7f6:0x2aa1
     7e3:	bf 8d 05             	mov    di,0x58d
     7e6:	0e                   	push   cs
     7e7:	57                   	push   di
     7e8:	6a 08                	push   0x8
     7ea:	6a 02                	push   0x2
     7ec:	6a 00                	push   0x0
     7ee:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     7f1:	06                   	push   es
     7f2:	57                   	push   di
     7f3:	9a a1 2a 0b 08       	call   0x80b:0x2aa1
     7f8:	bf 97 05             	mov    di,0x597
     7fb:	0e                   	push   cs
     7fc:	57                   	push   di
     7fd:	6a 08                	push   0x8
     7ff:	6a 02                	push   0x2
     801:	6a 00                	push   0x0
     803:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     806:	06                   	push   es
     807:	57                   	push   di
     808:	9a a1 2a 20 08       	call   0x820:0x2aa1
     80d:	bf a1 05             	mov    di,0x5a1
     810:	0e                   	push   cs
     811:	57                   	push   di
     812:	6a 08                	push   0x8
     814:	6a 02                	push   0x2
     816:	6a 00                	push   0x0
     818:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     81b:	06                   	push   es
     81c:	57                   	push   di
     81d:	9a a1 2a 35 08       	call   0x835:0x2aa1
     822:	bf ab 05             	mov    di,0x5ab
     825:	0e                   	push   cs
     826:	57                   	push   di
     827:	6a 08                	push   0x8
     829:	6a 02                	push   0x2
     82b:	6a 00                	push   0x0
     82d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     830:	06                   	push   es
     831:	57                   	push   di
     832:	9a a1 2a 4a 08       	call   0x84a:0x2aa1
     837:	bf b6 05             	mov    di,0x5b6
     83a:	0e                   	push   cs
     83b:	57                   	push   di
     83c:	6a 08                	push   0x8
     83e:	6a 02                	push   0x2
     840:	6a 00                	push   0x0
     842:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     845:	06                   	push   es
     846:	57                   	push   di
     847:	9a a1 2a 5f 08       	call   0x85f:0x2aa1
     84c:	bf c0 05             	mov    di,0x5c0
     84f:	0e                   	push   cs
     850:	57                   	push   di
     851:	6a 08                	push   0x8
     853:	6a 02                	push   0x2
     855:	6a 00                	push   0x0
     857:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     85a:	06                   	push   es
     85b:	57                   	push   di
     85c:	9a a1 2a 74 08       	call   0x874:0x2aa1
     861:	bf ca 05             	mov    di,0x5ca
     864:	0e                   	push   cs
     865:	57                   	push   di
     866:	6a 08                	push   0x8
     868:	6a 02                	push   0x2
     86a:	6a 00                	push   0x0
     86c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     86f:	06                   	push   es
     870:	57                   	push   di
     871:	9a a1 2a 89 08       	call   0x889:0x2aa1
     876:	bf d4 05             	mov    di,0x5d4
     879:	0e                   	push   cs
     87a:	57                   	push   di
     87b:	6a 08                	push   0x8
     87d:	6a 02                	push   0x2
     87f:	6a 00                	push   0x0
     881:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     884:	06                   	push   es
     885:	57                   	push   di
     886:	9a a1 2a 9e 08       	call   0x89e:0x2aa1
     88b:	bf de 05             	mov    di,0x5de
     88e:	0e                   	push   cs
     88f:	57                   	push   di
     890:	6a 08                	push   0x8
     892:	6a 02                	push   0x2
     894:	6a 00                	push   0x0
     896:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     899:	06                   	push   es
     89a:	57                   	push   di
     89b:	9a a1 2a b3 08       	call   0x8b3:0x2aa1
     8a0:	bf e8 05             	mov    di,0x5e8
     8a3:	0e                   	push   cs
     8a4:	57                   	push   di
     8a5:	6a 08                	push   0x8
     8a7:	6a 02                	push   0x2
     8a9:	6a 00                	push   0x0
     8ab:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     8ae:	06                   	push   es
     8af:	57                   	push   di
     8b0:	9a a1 2a c8 08       	call   0x8c8:0x2aa1
     8b5:	bf f2 05             	mov    di,0x5f2
     8b8:	0e                   	push   cs
     8b9:	57                   	push   di
     8ba:	6a 08                	push   0x8
     8bc:	6a 02                	push   0x2
     8be:	6a 00                	push   0x0
     8c0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     8c3:	06                   	push   es
     8c4:	57                   	push   di
     8c5:	9a a1 2a dd 08       	call   0x8dd:0x2aa1
     8ca:	bf fc 05             	mov    di,0x5fc
     8cd:	0e                   	push   cs
     8ce:	57                   	push   di
     8cf:	6a 08                	push   0x8
     8d1:	6a 02                	push   0x2
     8d3:	6a 00                	push   0x0
     8d5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     8d8:	06                   	push   es
     8d9:	57                   	push   di
     8da:	9a a1 2a f2 08       	call   0x8f2:0x2aa1
     8df:	bf 06 06             	mov    di,0x606
     8e2:	0e                   	push   cs
     8e3:	57                   	push   di
     8e4:	6a 08                	push   0x8
     8e6:	6a 02                	push   0x2
     8e8:	6a 00                	push   0x0
     8ea:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     8ed:	06                   	push   es
     8ee:	57                   	push   di
     8ef:	9a a1 2a 07 09       	call   0x907:0x2aa1
     8f4:	bf 10 06             	mov    di,0x610
     8f7:	0e                   	push   cs
     8f8:	57                   	push   di
     8f9:	6a 08                	push   0x8
     8fb:	6a 02                	push   0x2
     8fd:	6a 00                	push   0x0
     8ff:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     902:	06                   	push   es
     903:	57                   	push   di
     904:	9a a1 2a 1c 09       	call   0x91c:0x2aa1
     909:	bf 1b 06             	mov    di,0x61b
     90c:	0e                   	push   cs
     90d:	57                   	push   di
     90e:	6a 08                	push   0x8
     910:	6a 02                	push   0x2
     912:	6a 00                	push   0x0
     914:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     917:	06                   	push   es
     918:	57                   	push   di
     919:	9a a1 2a 31 09       	call   0x931:0x2aa1
     91e:	bf 26 06             	mov    di,0x626
     921:	0e                   	push   cs
     922:	57                   	push   di
     923:	6a 05                	push   0x5
     925:	6a 00                	push   0x0
     927:	6a 00                	push   0x0
     929:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     92c:	06                   	push   es
     92d:	57                   	push   di
     92e:	9a a1 2a 46 09       	call   0x946:0x2aa1
     933:	bf 31 06             	mov    di,0x631
     936:	0e                   	push   cs
     937:	57                   	push   di
     938:	6a 03                	push   0x3
     93a:	6a 00                	push   0x0
     93c:	6a 00                	push   0x0
     93e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     941:	06                   	push   es
     942:	57                   	push   di
     943:	9a a1 2a ec 0b       	call   0xbec:0x2aa1
     948:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     94b:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
     950:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     953:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     956:	bf 39 06             	mov    di,0x639
     959:	0e                   	push   cs
     95a:	57                   	push   di
     95b:	bf 94 04             	mov    di,0x494
     95e:	0e                   	push   cs
     95f:	57                   	push   di
     960:	6a 03                	push   0x3
     962:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     965:	06                   	push   es
     966:	57                   	push   di
     967:	9a f6 18 ae 09       	call   0x9ae:0x18f6
     96c:	c9                   	leave
     96d:	ca 04 00             	retf   0x4
     970:	00 00                	add    BYTE PTR [bx+si],al
     972:	a0 3f 55             	mov    al,ds:0x553f
     975:	89 e5                	mov    bp,sp
     977:	b8 30 01             	mov    ax,0x130
     97a:	9a 44 04 6f 0c       	call   0xc6f:0x444
     97f:	81 ec 30 01          	sub    sp,0x130
     983:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
     988:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     98b:	89 7e fa             	mov    WORD PTR [bp-0x6],di
     98e:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
     991:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     994:	99                   	cwd
     995:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     998:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     99b:	c6 46 f6 00          	mov    BYTE PTR [bp-0xa],0x0
     99f:	8d 7e f2             	lea    di,[bp-0xe]
     9a2:	16                   	push   ss
     9a3:	57                   	push   di
     9a4:	6a 00                	push   0x0
     9a6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     9a9:	06                   	push   es
     9aa:	57                   	push   di
     9ab:	9a 95 28 3c 0d       	call   0xd3c:0x2895
     9b0:	08 c0                	or     al,al
     9b2:	74 03                	je     0x9b7
     9b4:	e9 37 02             	jmp    0xbee
     9b7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     9ba:	99                   	cwd
     9bb:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
     9bf:	89 96 d2 fe          	mov    WORD PTR [bp-0x12e],dx
     9c3:	c6 86 d4 fe 00       	mov    BYTE PTR [bp-0x12c],0x0
     9c8:	c7 86 d8 fe 3a cb    	mov    WORD PTR [bp-0x128],0xcb3a
     9ce:	c7 86 da fe 31 01    	mov    WORD PTR [bp-0x126],0x131
     9d4:	c6 86 dc fe 00       	mov    BYTE PTR [bp-0x124],0x0
     9d9:	a1 6e 01             	mov    ax,ds:0x16e
     9dc:	99                   	cwd
     9dd:	89 86 e0 fe          	mov    WORD PTR [bp-0x120],ax
     9e1:	89 96 e2 fe          	mov    WORD PTR [bp-0x11e],dx
     9e5:	c6 86 e4 fe 00       	mov    BYTE PTR [bp-0x11c],0x0
     9ea:	c7 86 e8 fe 04 00    	mov    WORD PTR [bp-0x118],0x4
     9f0:	c7 86 ea fe 00 00    	mov    WORD PTR [bp-0x116],0x0
     9f6:	c6 86 ec fe 00       	mov    BYTE PTR [bp-0x114],0x0
     9fb:	c7 86 f0 fe 40 42    	mov    WORD PTR [bp-0x110],0x4240
     a01:	c7 86 f2 fe 0f 00    	mov    WORD PTR [bp-0x10e],0xf
     a07:	c6 86 f4 fe 00       	mov    BYTE PTR [bp-0x10c],0x0
     a0c:	c7 86 f8 fe 0a 00    	mov    WORD PTR [bp-0x108],0xa
     a12:	c7 86 fa fe 00 00    	mov    WORD PTR [bp-0x106],0x0
     a18:	c6 86 fc fe 00       	mov    BYTE PTR [bp-0x104],0x0
     a1d:	31 c0                	xor    ax,ax
     a1f:	89 86 00 ff          	mov    WORD PTR [bp-0x100],ax
     a23:	89 86 02 ff          	mov    WORD PTR [bp-0xfe],ax
     a27:	c6 86 04 ff 00       	mov    BYTE PTR [bp-0xfc],0x0
     a2c:	31 c0                	xor    ax,ax
     a2e:	89 86 08 ff          	mov    WORD PTR [bp-0xf8],ax
     a32:	89 86 0a ff          	mov    WORD PTR [bp-0xf6],ax
     a36:	c6 86 0c ff 00       	mov    BYTE PTR [bp-0xf4],0x0
     a3b:	9b 2e d9 06 70 09    	fld    DWORD PTR cs:0x970
     a41:	9b db 7e e8          	fstp   TBYTE PTR [bp-0x18]
     a45:	8d 46 e8             	lea    ax,[bp-0x18]
     a48:	8c d2                	mov    dx,ss
     a4a:	89 86 10 ff          	mov    WORD PTR [bp-0xf0],ax
     a4e:	89 96 12 ff          	mov    WORD PTR [bp-0xee],dx
     a52:	c6 86 14 ff 03       	mov    BYTE PTR [bp-0xec],0x3
     a57:	31 c0                	xor    ax,ax
     a59:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
     a5d:	89 86 1a ff          	mov    WORD PTR [bp-0xe6],ax
     a61:	c6 86 1c ff 00       	mov    BYTE PTR [bp-0xe4],0x0
     a66:	31 c0                	xor    ax,ax
     a68:	89 86 20 ff          	mov    WORD PTR [bp-0xe0],ax
     a6c:	89 86 22 ff          	mov    WORD PTR [bp-0xde],ax
     a70:	c6 86 24 ff 00       	mov    BYTE PTR [bp-0xdc],0x0
     a75:	c7 86 28 ff 08 00    	mov    WORD PTR [bp-0xd8],0x8
     a7b:	c7 86 2a ff 00 00    	mov    WORD PTR [bp-0xd6],0x0
     a81:	c6 86 2c ff 00       	mov    BYTE PTR [bp-0xd4],0x0
     a86:	c7 86 30 ff e0 28    	mov    WORD PTR [bp-0xd0],0x28e0
     a8c:	c7 86 32 ff 01 00    	mov    WORD PTR [bp-0xce],0x1
     a92:	c6 86 34 ff 00       	mov    BYTE PTR [bp-0xcc],0x0
     a97:	c7 86 38 ff f0 49    	mov    WORD PTR [bp-0xc8],0x49f0
     a9d:	c7 86 3a ff 02 00    	mov    WORD PTR [bp-0xc6],0x2
     aa3:	c6 86 3c ff 00       	mov    BYTE PTR [bp-0xc4],0x0
     aa8:	c7 86 40 ff e0 93    	mov    WORD PTR [bp-0xc0],0x93e0
     aae:	c7 86 42 ff 04 00    	mov    WORD PTR [bp-0xbe],0x4
     ab4:	c6 86 44 ff 00       	mov    BYTE PTR [bp-0xbc],0x0
     ab9:	c7 86 48 ff b0 71    	mov    WORD PTR [bp-0xb8],0x71b0
     abf:	c7 86 4a ff 0b 00    	mov    WORD PTR [bp-0xb6],0xb
     ac5:	c6 86 4c ff 00       	mov    BYTE PTR [bp-0xb4],0x0
     aca:	c7 86 50 ff 60 e3    	mov    WORD PTR [bp-0xb0],0xe360
     ad0:	c7 86 52 ff 16 00    	mov    WORD PTR [bp-0xae],0x16
     ad6:	c6 86 54 ff 00       	mov    BYTE PTR [bp-0xac],0x0
     adb:	c7 86 58 ff e0 70    	mov    WORD PTR [bp-0xa8],0x70e0
     ae1:	c7 86 5a ff 72 00    	mov    WORD PTR [bp-0xa6],0x72
     ae7:	c6 86 5c ff 00       	mov    BYTE PTR [bp-0xa4],0x0
     aec:	c7 86 60 ff c0 e1    	mov    WORD PTR [bp-0xa0],0xe1c0
     af2:	c7 86 62 ff e4 00    	mov    WORD PTR [bp-0x9e],0xe4
     af8:	c6 86 64 ff 00       	mov    BYTE PTR [bp-0x9c],0x0
     afd:	c7 86 68 ff c0 68    	mov    WORD PTR [bp-0x98],0x68c0
     b03:	c7 86 6a ff 78 04    	mov    WORD PTR [bp-0x96],0x478
     b09:	c6 86 6c ff 00       	mov    BYTE PTR [bp-0x94],0x0
     b0e:	c7 86 70 ff 80 d1    	mov    WORD PTR [bp-0x90],0xd180
     b14:	c7 86 72 ff f0 08    	mov    WORD PTR [bp-0x8e],0x8f0
     b1a:	c6 86 74 ff 00       	mov    BYTE PTR [bp-0x8c],0x0
     b1f:	c7 86 78 ff 00 a3    	mov    WORD PTR [bp-0x88],0xa300
     b25:	c7 86 7a ff e1 11    	mov    WORD PTR [bp-0x86],0x11e1
     b2b:	c6 86 7c ff 00       	mov    BYTE PTR [bp-0x84],0x0
     b30:	31 c0                	xor    ax,ax
     b32:	89 46 80             	mov    WORD PTR [bp-0x80],ax
     b35:	89 46 82             	mov    WORD PTR [bp-0x7e],ax
     b38:	c6 46 84 00          	mov    BYTE PTR [bp-0x7c],0x0
     b3c:	c7 46 88 ee 02       	mov    WORD PTR [bp-0x78],0x2ee
     b41:	c7 46 8a 00 00       	mov    WORD PTR [bp-0x76],0x0
     b46:	c6 46 8c 00          	mov    BYTE PTR [bp-0x74],0x0
     b4a:	c7 46 90 65 04       	mov    WORD PTR [bp-0x70],0x465
     b4f:	c7 46 92 00 00       	mov    WORD PTR [bp-0x6e],0x0
     b54:	c6 46 94 00          	mov    BYTE PTR [bp-0x6c],0x0
     b58:	c7 46 98 27 06       	mov    WORD PTR [bp-0x68],0x627
     b5d:	c7 46 9a 00 00       	mov    WORD PTR [bp-0x66],0x0
     b62:	c6 46 9c 00          	mov    BYTE PTR [bp-0x64],0x0
     b66:	c7 46 a0 7f 08       	mov    WORD PTR [bp-0x60],0x87f
     b6b:	c7 46 a2 00 00       	mov    WORD PTR [bp-0x5e],0x0
     b70:	c6 46 a4 00          	mov    BYTE PTR [bp-0x5c],0x0
     b74:	c7 46 a8 a6 0e       	mov    WORD PTR [bp-0x58],0xea6
     b79:	c7 46 aa 00 00       	mov    WORD PTR [bp-0x56],0x0
     b7e:	c6 46 ac 00          	mov    BYTE PTR [bp-0x54],0x0
     b82:	c7 46 b0 98 3a       	mov    WORD PTR [bp-0x50],0x3a98
     b87:	c7 46 b2 00 00       	mov    WORD PTR [bp-0x4e],0x0
     b8c:	c6 46 b4 00          	mov    BYTE PTR [bp-0x4c],0x0
     b90:	c7 46 b8 3e 49       	mov    WORD PTR [bp-0x48],0x493e
     b95:	c7 46 ba 00 00       	mov    WORD PTR [bp-0x46],0x0
     b9a:	c6 46 bc 00          	mov    BYTE PTR [bp-0x44],0x0
     b9e:	c7 46 c0 30 75       	mov    WORD PTR [bp-0x40],0x7530
     ba3:	c7 46 c2 00 00       	mov    WORD PTR [bp-0x3e],0x0
     ba8:	c6 46 c4 00          	mov    BYTE PTR [bp-0x3c],0x0
     bac:	c7 46 c8 50 c3       	mov    WORD PTR [bp-0x38],0xc350
     bb1:	c7 46 ca 00 00       	mov    WORD PTR [bp-0x36],0x0
     bb6:	c6 46 cc 00          	mov    BYTE PTR [bp-0x34],0x0
     bba:	c7 46 d0 80 38       	mov    WORD PTR [bp-0x30],0x3880
     bbf:	c7 46 d2 01 00       	mov    WORD PTR [bp-0x2e],0x1
     bc4:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
     bc8:	c6 46 d8 00          	mov    BYTE PTR [bp-0x28],0x0
     bcc:	c6 46 dc 01          	mov    BYTE PTR [bp-0x24],0x1
     bd0:	31 c0                	xor    ax,ax
     bd2:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     bd5:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
     bd8:	c6 46 e4 00          	mov    BYTE PTR [bp-0x1c],0x0
     bdc:	8d be d0 fe          	lea    di,[bp-0x130]
     be0:	16                   	push   ss
     be1:	57                   	push   di
     be2:	6a 22                	push   0x22
     be4:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     be7:	06                   	push   es
     be8:	57                   	push   di
     be9:	9a 21 53 9a 0c       	call   0xc9a:0x5321
     bee:	c9                   	leave
     bef:	ca 04 00             	retf   0x4
     bf2:	09 50 72             	or     WORD PTR [bx+si+0x72],dx
     bf5:	6f                   	outs   dx,WORD PTR ds:[si]
     bf6:	64 75 69             	fs jne 0xc62
     bf9:	74 4e                	je     0xc49
     bfb:	6f                   	outs   dx,WORD PTR ds:[si]
     bfc:	10 54 65             	adc    BYTE PTR [si+0x65],dl
     bff:	6d                   	ins    WORD PTR es:[di],dx
     c00:	70 73                	jo     0xc75
     c02:	46                   	inc    si
     c03:	61                   	popa
     c04:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
     c07:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
     c0a:	69 6f 6e 0d 44       	imul   bp,WORD PTR [bx+0x6e],0x440d
     c0f:	65 6d                	gs ins WORD PTR es:[di],dx
     c11:	61                   	popa
     c12:	6e                   	outs   dx,BYTE PTR ds:[si]
     c13:	64 65 50             	fs gs push ax
     c16:	6f                   	outs   dx,WORD PTR ds:[si]
     c17:	74 45                	je     0xc5e
     c19:	6e                   	outs   dx,BYTE PTR ds:[si]
     c1a:	74 10                	je     0xc2c
     c1c:	44                   	inc    sp
     c1d:	65 6d                	gs ins WORD PTR es:[di],dx
     c1f:	61                   	popa
     c20:	6e                   	outs   dx,BYTE PTR ds:[si]
     c21:	64 65 45             	fs gs inc bp
     c24:	76 6f                	jbe    0xc95
     c26:	6c                   	ins    BYTE PTR es:[di],dx
     c27:	75 74                	jne    0xc9d
     c29:	69 6f 6e 10 44       	imul   bp,WORD PTR [bx+0x6e],0x4410
     c2e:	65 6d                	gs ins WORD PTR es:[di],dx
     c30:	61                   	popa
     c31:	6e                   	outs   dx,BYTE PTR ds:[si]
     c32:	64 65 50             	fs gs push ax
     c35:	61                   	popa
     c36:	72 61                	jb     0xc99
     c38:	6d                   	ins    WORD PTR es:[di],dx
     c39:	65 74 72             	gs je  0xcae
     c3c:	65 11 46 61          	adc    WORD PTR gs:[bp+0x61],ax
     c40:	63 74 65             	arpl   WORD PTR [si+0x65],si
     c43:	75 72                	jne    0xcb7
     c45:	54                   	push   sp
     c46:	65 6d                	gs ins WORD PTR es:[di],dx
     c48:	70 73                	jo     0xcbd
     c4a:	46                   	inc    si
     c4b:	61                   	popa
     c4c:	62 50 63             	bound  dx,DWORD PTR [bx+si+0x63]
     c4f:	07                   	pop    es
     c50:	53                   	push   bx
     c51:	70 65                	jo     0xcb8
     c53:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     c56:	6c                   	ins    BYTE PTR es:[di],dx
     c57:	0e                   	push   cs
     c58:	50                   	push   ax
     c59:	72 6f                	jb     0xcca
     c5b:	64 75 69             	fs jne 0xcc7
     c5e:	74 4e                	je     0xcae
     c60:	6f                   	outs   dx,WORD PTR ds:[si]
     c61:	49                   	dec    cx
     c62:	6e                   	outs   dx,BYTE PTR ds:[si]
     c63:	64 65 78 55          	fs gs js 0xcbc
     c67:	89 e5                	mov    bp,sp
     c69:	b8 08 00             	mov    ax,0x8
     c6c:	9a 44 04 59 0d       	call   0xd59:0x444
     c71:	83 ec 08             	sub    sp,0x8
     c74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c77:	89 7e fc             	mov    WORD PTR [bp-0x4],di
     c7a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
     c7d:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
     c81:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     c84:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     c87:	bf f2 0b             	mov    di,0xbf2
     c8a:	0e                   	push   cs
     c8b:	57                   	push   di
     c8c:	6a 03                	push   0x3
     c8e:	6a 00                	push   0x0
     c90:	6a 00                	push   0x0
     c92:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     c95:	06                   	push   es
     c96:	57                   	push   di
     c97:	9a a1 2a af 0c       	call   0xcaf:0x2aa1
     c9c:	bf fc 0b             	mov    di,0xbfc
     c9f:	0e                   	push   cs
     ca0:	57                   	push   di
     ca1:	6a 06                	push   0x6
     ca3:	6a 00                	push   0x0
     ca5:	6a 00                	push   0x0
     ca7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     caa:	06                   	push   es
     cab:	57                   	push   di
     cac:	9a a1 2a c4 0c       	call   0xcc4:0x2aa1
     cb1:	bf 0d 0c             	mov    di,0xc0d
     cb4:	0e                   	push   cs
     cb5:	57                   	push   di
     cb6:	6a 03                	push   0x3
     cb8:	6a 00                	push   0x0
     cba:	6a 00                	push   0x0
     cbc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     cbf:	06                   	push   es
     cc0:	57                   	push   di
     cc1:	9a a1 2a d9 0c       	call   0xcd9:0x2aa1
     cc6:	bf 1b 0c             	mov    di,0xc1b
     cc9:	0e                   	push   cs
     cca:	57                   	push   di
     ccb:	6a 03                	push   0x3
     ccd:	6a 00                	push   0x0
     ccf:	6a 00                	push   0x0
     cd1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     cd4:	06                   	push   es
     cd5:	57                   	push   di
     cd6:	9a a1 2a ee 0c       	call   0xcee:0x2aa1
     cdb:	bf 2c 0c             	mov    di,0xc2c
     cde:	0e                   	push   cs
     cdf:	57                   	push   di
     ce0:	6a 06                	push   0x6
     ce2:	6a 00                	push   0x0
     ce4:	6a 00                	push   0x0
     ce6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     ce9:	06                   	push   es
     cea:	57                   	push   di
     ceb:	9a a1 2a 03 0d       	call   0xd03:0x2aa1
     cf0:	bf 3d 0c             	mov    di,0xc3d
     cf3:	0e                   	push   cs
     cf4:	57                   	push   di
     cf5:	6a 03                	push   0x3
     cf7:	6a 00                	push   0x0
     cf9:	6a 00                	push   0x0
     cfb:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     cfe:	06                   	push   es
     cff:	57                   	push   di
     d00:	9a a1 2a 18 0d       	call   0xd18:0x2aa1
     d05:	bf 4f 0c             	mov    di,0xc4f
     d08:	0e                   	push   cs
     d09:	57                   	push   di
     d0a:	6a 03                	push   0x3
     d0c:	6a 00                	push   0x0
     d0e:	6a 00                	push   0x0
     d10:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d13:	06                   	push   es
     d14:	57                   	push   di
     d15:	9a a1 2a 04 0e       	call   0xe04:0x2aa1
     d1a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     d1d:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
     d22:	89 7e f8             	mov    WORD PTR [bp-0x8],di
     d25:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
     d28:	bf 57 0c             	mov    di,0xc57
     d2b:	0e                   	push   cs
     d2c:	57                   	push   di
     d2d:	bf f2 0b             	mov    di,0xbf2
     d30:	0e                   	push   cs
     d31:	57                   	push   di
     d32:	6a 03                	push   0x3
     d34:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
     d37:	06                   	push   es
     d38:	57                   	push   di
     d39:	9a f6 18 84 0d       	call   0xd84:0x18f6
     d3e:	c9                   	leave
     d3f:	ca 04 00             	retf   0x4
     d42:	cd cc                	int    0xcc
     d44:	cc                   	int3
     d45:	cc                   	int3
     d46:	cc                   	int3
     d47:	cc                   	int3
     d48:	cc                   	int3
     d49:	cc                   	int3
     d4a:	fa                   	cli
     d4b:	3f                   	aas
     d4c:	00 00                	add    BYTE PTR [bx+si],al
     d4e:	c0 3f 55             	sar    BYTE PTR [bx],0x55
     d51:	89 e5                	mov    bp,sp
     d53:	b8 50 00             	mov    ax,0x50
     d56:	9a 44 04 25 11       	call   0x1125:0x444
     d5b:	83 ec 50             	sub    sp,0x50
     d5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d61:	89 7e fa             	mov    WORD PTR [bp-0x6],di
     d64:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
     d67:	c7 46 f2 01 00       	mov    WORD PTR [bp-0xe],0x1
     d6c:	c7 46 f4 00 00       	mov    WORD PTR [bp-0xc],0x0
     d71:	c6 46 f6 00          	mov    BYTE PTR [bp-0xa],0x0
     d75:	8d 7e f2             	lea    di,[bp-0xe]
     d78:	16                   	push   ss
     d79:	57                   	push   di
     d7a:	6a 00                	push   0x0
     d7c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     d7f:	06                   	push   es
     d80:	57                   	push   di
     d81:	9a 95 28 23 0e       	call   0xe23:0x2895
     d86:	08 c0                	or     al,al
     d88:	75 7c                	jne    0xe06
     d8a:	c7 46 b0 01 00       	mov    WORD PTR [bp-0x50],0x1
     d8f:	c7 46 b2 00 00       	mov    WORD PTR [bp-0x4e],0x0
     d94:	c6 46 b4 00          	mov    BYTE PTR [bp-0x4c],0x0
     d98:	9b 2e db 2e 42 0d    	fld    TBYTE PTR cs:0xd42
     d9e:	9b db 7e e8          	fstp   TBYTE PTR [bp-0x18]
     da2:	8d 46 e8             	lea    ax,[bp-0x18]
     da5:	8c d2                	mov    dx,ss
     da7:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
     daa:	89 56 ba             	mov    WORD PTR [bp-0x46],dx
     dad:	c6 46 bc 03          	mov    BYTE PTR [bp-0x44],0x3
     db1:	c7 46 c0 90 d0       	mov    WORD PTR [bp-0x40],0xd090
     db6:	c7 46 c2 03 00       	mov    WORD PTR [bp-0x3e],0x3
     dbb:	c6 46 c4 00          	mov    BYTE PTR [bp-0x3c],0x0
     dbf:	c7 46 c8 02 00       	mov    WORD PTR [bp-0x38],0x2
     dc4:	c7 46 ca 00 00       	mov    WORD PTR [bp-0x36],0x0
     dc9:	c6 46 cc 00          	mov    BYTE PTR [bp-0x34],0x0
     dcd:	c7 46 d0 03 00       	mov    WORD PTR [bp-0x30],0x3
     dd2:	c7 46 d2 00 00       	mov    WORD PTR [bp-0x2e],0x0
     dd7:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
     ddb:	c7 46 d8 64 00       	mov    WORD PTR [bp-0x28],0x64
     de0:	c7 46 da 00 00       	mov    WORD PTR [bp-0x26],0x0
     de5:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
     de9:	31 c0                	xor    ax,ax
     deb:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     dee:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
     df1:	c6 46 e4 00          	mov    BYTE PTR [bp-0x1c],0x0
     df5:	8d 7e b0             	lea    di,[bp-0x50]
     df8:	16                   	push   ss
     df9:	57                   	push   di
     dfa:	6a 06                	push   0x6
     dfc:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     dff:	06                   	push   es
     e00:	57                   	push   di
     e01:	9a 21 53 a1 0e       	call   0xea1:0x5321
     e06:	c7 46 f2 02 00       	mov    WORD PTR [bp-0xe],0x2
     e0b:	c7 46 f4 00 00       	mov    WORD PTR [bp-0xc],0x0
     e10:	c6 46 f6 00          	mov    BYTE PTR [bp-0xa],0x0
     e14:	8d 7e f2             	lea    di,[bp-0xe]
     e17:	16                   	push   ss
     e18:	57                   	push   di
     e19:	6a 00                	push   0x0
     e1b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     e1e:	06                   	push   es
     e1f:	57                   	push   di
     e20:	9a 95 28 d1 14       	call   0x14d1:0x2895
     e25:	08 c0                	or     al,al
     e27:	75 7a                	jne    0xea3
     e29:	c7 46 b0 02 00       	mov    WORD PTR [bp-0x50],0x2
     e2e:	c7 46 b2 00 00       	mov    WORD PTR [bp-0x4e],0x0
     e33:	c6 46 b4 00          	mov    BYTE PTR [bp-0x4c],0x0
     e37:	9b 2e d9 06 4c 0d    	fld    DWORD PTR cs:0xd4c
     e3d:	9b db 7e e8          	fstp   TBYTE PTR [bp-0x18]
     e41:	8d 46 e8             	lea    ax,[bp-0x18]
     e44:	8c d2                	mov    dx,ss
     e46:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
     e49:	89 56 ba             	mov    WORD PTR [bp-0x46],dx
     e4c:	c6 46 bc 03          	mov    BYTE PTR [bp-0x44],0x3
     e50:	c7 46 c0 20 4e       	mov    WORD PTR [bp-0x40],0x4e20
     e55:	c7 46 c2 00 00       	mov    WORD PTR [bp-0x3e],0x0
     e5a:	c6 46 c4 00          	mov    BYTE PTR [bp-0x3c],0x0
     e5e:	31 c0                	xor    ax,ax
     e60:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
     e63:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
     e66:	c6 46 cc 00          	mov    BYTE PTR [bp-0x34],0x0
     e6a:	c7 46 d0 0a 00       	mov    WORD PTR [bp-0x30],0xa
     e6f:	c7 46 d2 00 00       	mov    WORD PTR [bp-0x2e],0x0
     e74:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
     e78:	c7 46 d8 64 00       	mov    WORD PTR [bp-0x28],0x64
     e7d:	c7 46 da 00 00       	mov    WORD PTR [bp-0x26],0x0
     e82:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
     e86:	31 c0                	xor    ax,ax
     e88:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
     e8b:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
     e8e:	c6 46 e4 00          	mov    BYTE PTR [bp-0x1c],0x0
     e92:	8d 7e b0             	lea    di,[bp-0x50]
     e95:	16                   	push   ss
     e96:	57                   	push   di
     e97:	6a 06                	push   0x6
     e99:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     e9c:	06                   	push   es
     e9d:	57                   	push   di
     e9e:	9a 21 53 50 11       	call   0x1150:0x5321
     ea3:	c9                   	leave
     ea4:	ca 04 00             	retf   0x4
     ea7:	09 50 65             	or     WORD PTR [bx+si+0x65],dx
     eaa:	72 69                	jb     0xf15
     eac:	6f                   	outs   dx,WORD PTR ds:[si]
     ead:	64 65 4e             	fs gs dec si
     eb0:	6f                   	outs   dx,WORD PTR ds:[si]
     eb1:	0b 54 61             	or     dx,WORD PTR [si+0x61]
     eb4:	75 78                	jne    0xf2e
     eb6:	45                   	inc    bp
     eb7:	6d                   	ins    WORD PTR es:[di],dx
     eb8:	70 72                	jo     0xf2c
     eba:	75 6e                	jne    0xf2a
     ebc:	74 11                	je     0xecf
     ebe:	54                   	push   sp
     ebf:	61                   	popa
     ec0:	75 78                	jne    0xf3a
     ec2:	44                   	inc    sp
     ec3:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     ec7:	76 65                	jbe    0xf2e
     ec9:	72 74                	jb     0xf3f
     ecb:	41                   	inc    cx
     ecc:	75 74                	jne    0xf42
     ece:	6f                   	outs   dx,WORD PTR ds:[si]
     ecf:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     ed2:	75 78                	jne    0xf4c
     ed4:	44                   	inc    sp
     ed5:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     ed9:	76 65                	jbe    0xf40
     edb:	72 74                	jb     0xf51
     edd:	4e                   	dec    si
     ede:	41                   	inc    cx
     edf:	75 74                	jne    0xf55
     ee1:	6f                   	outs   dx,WORD PTR ds:[si]
     ee2:	11 54 61             	adc    WORD PTR [si+0x61],dx
     ee5:	75 78                	jne    0xf5f
     ee7:	45                   	inc    bp
     ee8:	73 63                	jae    0xf4d
     eea:	6f                   	outs   dx,WORD PTR ds:[si]
     eeb:	6d                   	ins    WORD PTR es:[di],dx
     eec:	70 74                	jo     0xf62
     eee:	65 41                	gs inc cx
     ef0:	63 68 61             	arpl   WORD PTR [bx+si+0x61],bp
     ef3:	74 07                	je     0xefc
     ef5:	54                   	push   sp
     ef6:	61                   	popa
     ef7:	75 78                	jne    0xf71
     ef9:	54                   	push   sp
     efa:	56                   	push   si
     efb:	41                   	inc    cx
     efc:	06                   	push   es
     efd:	54                   	push   sp
     efe:	61                   	popa
     eff:	75 78                	jne    0xf79
     f01:	49                   	dec    cx
     f02:	53                   	push   bx
     f03:	0d 54 61             	or     ax,0x6154
     f06:	75 78                	jne    0xf80
     f08:	50                   	push   ax
     f09:	6c                   	ins    BYTE PTR es:[di],dx
     f0a:	61                   	popa
     f0b:	63 65 6d             	arpl   WORD PTR [di+0x6d],sp
     f0e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     f10:	74 10                	je     0xf22
     f12:	48                   	dec    ax
     f13:	65 75 72             	gs jne 0xf88
     f16:	65 73 50             	gs jae 0xf69
     f19:	61                   	popa
     f1a:	72 4d                	jb     0xf69
     f1c:	61                   	popa
     f1d:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     f20:	6e                   	outs   dx,BYTE PTR ds:[si]
     f21:	65 12 48 65          	adc    cl,BYTE PTR gs:[bx+si+0x65]
     f25:	75 72                	jne    0xf99
     f27:	65 73 50             	gs jae 0xf7a
     f2a:	61                   	popa
     f2b:	72 50                	jb     0xf7d
     f2d:	72 6f                	jb     0xf9e
     f2f:	64 75 63             	fs jne 0xf95
     f32:	74 69                	je     0xf9d
     f34:	66 10 43 6f          	data32 adc BYTE PTR [bp+di+0x6f],al
     f38:	75 74                	jne    0xfae
     f3a:	55                   	push   bp
     f3b:	6e                   	outs   dx,BYTE PTR ds:[si]
     f3c:	69 74 65 4d 61       	imul   si,WORD PTR [si+0x65],0x614d
     f41:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     f44:	6e                   	outs   dx,BYTE PTR ds:[si]
     f45:	65 13 43 6f          	adc    ax,WORD PTR gs:[bp+di+0x6f]
     f49:	75 74                	jne    0xfbf
     f4b:	50                   	push   ax
     f4c:	6f                   	outs   dx,WORD PTR ds:[si]
     f4d:	69 6e 74 52 65       	imul   bp,WORD PTR [bp+0x74],0x6552
     f52:	70 61                	jo     0xfb5
     f54:	72 61                	jb     0xfb7
     f56:	74 69                	je     0xfc1
     f58:	6f                   	outs   dx,WORD PTR ds:[si]
     f59:	6e                   	outs   dx,BYTE PTR ds:[si]
     f5a:	0e                   	push   cs
     f5b:	43                   	inc    bx
     f5c:	6f                   	outs   dx,WORD PTR ds:[si]
     f5d:	75 74                	jne    0xfd3
     f5f:	55                   	push   bp
     f60:	6e                   	outs   dx,BYTE PTR ds:[si]
     f61:	69 74 65 53 74       	imul   si,WORD PTR [si+0x65],0x7453
     f66:	6f                   	outs   dx,WORD PTR ds:[si]
     f67:	63 6b 12             	arpl   WORD PTR [bp+di+0x12],bp
     f6a:	43                   	inc    bx
     f6b:	6f                   	outs   dx,WORD PTR ds:[si]
     f6c:	75 74                	jne    0xfe2
     f6e:	55                   	push   bp
     f6f:	6e                   	outs   dx,BYTE PTR ds:[si]
     f70:	69 74 65 50 72       	imul   si,WORD PTR [si+0x65],0x7250
     f75:	6f                   	outs   dx,WORD PTR ds:[si]
     f76:	64 75 63             	fs jne 0xfdc
     f79:	74 69                	je     0xfe4
     f7b:	66 10 43 6f          	data32 adc BYTE PTR [bp+di+0x6f],al
     f7f:	75 74                	jne    0xff5
     f81:	55                   	push   bp
     f82:	6e                   	outs   dx,BYTE PTR ds:[si]
     f83:	69 74 65 56 65       	imul   si,WORD PTR [si+0x65],0x6556
     f88:	6e                   	outs   dx,BYTE PTR ds:[si]
     f89:	64 65 75 72          	fs gs jne 0xfff
     f8d:	0e                   	push   cs
     f8e:	43                   	inc    bx
     f8f:	6f                   	outs   dx,WORD PTR ds:[si]
     f90:	75 74                	jne    0x1006
     f92:	55                   	push   bp
     f93:	6e                   	outs   dx,BYTE PTR ds:[si]
     f94:	69 74 65 43 61       	imul   si,WORD PTR [si+0x65],0x6143
     f99:	64 72 65             	fs jb  0x1001
     f9c:	0e                   	push   cs
     f9d:	43                   	inc    bx
     f9e:	6f                   	outs   dx,WORD PTR ds:[si]
     f9f:	75 74                	jne    0x1015
     fa1:	45                   	inc    bp
     fa2:	6d                   	ins    WORD PTR es:[di],dx
     fa3:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
     fa6:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     fa9:	50                   	push   ax
     faa:	63 12                	arpl   WORD PTR [bp+si],dx
     fac:	43                   	inc    bx
     fad:	6f                   	outs   dx,WORD PTR ds:[si]
     fae:	75 74                	jne    0x1024
     fb0:	4c                   	dec    sp
     fb1:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
     fb6:	69 65 6d 65 6e       	imul   sp,WORD PTR [di+0x6d],0x6e65
     fbb:	74 50                	je     0x100d
     fbd:	63 0f                	arpl   WORD PTR [bx],cx
     fbf:	46                   	inc    si
     fc0:	6f                   	outs   dx,WORD PTR ds:[si]
     fc1:	72 6d                	jb     0x1030
     fc3:	61                   	popa
     fc4:	74 69                	je     0x102f
     fc6:	6f                   	outs   dx,WORD PTR ds:[si]
     fc7:	6e                   	outs   dx,BYTE PTR ds:[si]
     fc8:	4d                   	dec    bp
     fc9:	69 6e 69 50 63       	imul   bp,WORD PTR [bp+0x69],0x6350
     fce:	08 43 6f             	or     BYTE PTR [bp+di+0x6f],al
     fd1:	75 74                	jne    0x1047
     fd3:	46                   	inc    si
     fd4:	69 78 65 0d 54       	imul   di,WORD PTR [bx+si+0x65],0x540d
     fd9:	72 61                	jb     0x103c
     fdb:	6e                   	outs   dx,BYTE PTR ds:[si]
     fdc:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     fdf:	73 49                	jae    0x102a
     fe1:	6d                   	ins    WORD PTR es:[di],dx
     fe2:	6d                   	ins    WORD PTR es:[di],dx
     fe3:	6f                   	outs   dx,WORD PTR ds:[si]
     fe4:	62 11                	bound  dx,DWORD PTR [bx+di]
     fe6:	53                   	push   bx
     fe7:	75 70                	jne    0x1059
     fe9:	70 6c                	jo     0x1057
     feb:	65 6d                	gs ins WORD PTR es:[di],dx
     fed:	65 6e                	outs   dx,BYTE PTR gs:[si]
     fef:	74 54                	je     0x1045
     ff1:	72 61                	jb     0x1054
     ff3:	6e                   	outs   dx,BYTE PTR ds:[si]
     ff4:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     ff7:	12 50 72             	adc    dl,BYTE PTR [bx+si+0x72]
     ffa:	6f                   	outs   dx,WORD PTR ds:[si]
     ffb:	64 75 63             	fs jne 0x1061
     ffe:	74 69                	je     0x1069
    1000:	66 73 50             	data32 jae 0x1053
    1003:	61                   	popa
    1004:	72 43                	jb     0x1049
    1006:	61                   	popa
    1007:	64 72 65             	fs jb  0x106f
    100a:	0b 41 73             	or     ax,WORD PTR [bx+di+0x73]
    100d:	73 75                	jae    0x1084
    100f:	72 61                	jb     0x1072
    1011:	6e                   	outs   dx,BYTE PTR ds:[si]
    1012:	63 65 50             	arpl   WORD PTR [di+0x50],sp
    1015:	63 11                	arpl   WORD PTR [bx+di],dx
    1017:	43                   	inc    bx
    1018:	72 65                	jb     0x107f
    101a:	64 69 74 46 6f 75    	imul   si,WORD PTR fs:[si+0x46],0x756f
    1020:	72 6e                	jb     0x1090
    1022:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    1027:	72 0f                	jb     0x1038
    1029:	44                   	inc    sp
    102a:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    102e:	76 65                	jbe    0x1095
    1030:	72 74                	jb     0x10a6
    1032:	41                   	inc    cx
    1033:	75 74                	jne    0x10a9
    1035:	6f                   	outs   dx,WORD PTR ds:[si]
    1036:	50                   	push   ax
    1037:	63 0a                	arpl   WORD PTR [bp+si],cx
    1039:	49                   	dec    cx
    103a:	6e                   	outs   dx,BYTE PTR ds:[si]
    103b:	64 69 63 65 50 72    	imul   sp,WORD PTR fs:[bp+di+0x65],0x7250
    1041:	69 78 08 47 72       	imul   di,WORD PTR [bx+si+0x8],0x7247
    1046:	65 76 65             	gs jbe 0x10ae
    1049:	73 50                	jae    0x109b
    104b:	63 08                	arpl   WORD PTR [bx+si],cx
    104d:	50                   	push   ax
    104e:	61                   	popa
    104f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1050:	6e                   	outs   dx,BYTE PTR ds:[si]
    1051:	65 73 50             	gs jae 0x10a4
    1054:	63 09                	arpl   WORD PTR [bx+di],cx
    1056:	43                   	inc    bx
    1057:	61                   	popa
    1058:	74 61                	je     0x10bb
    105a:	53                   	push   bx
    105b:	74 79                	je     0x10d6
    105d:	6c                   	ins    BYTE PTR es:[di],dx
    105e:	65 0e                	gs push cs
    1060:	43                   	inc    bx
    1061:	61                   	popa
    1062:	74 61                	je     0x10c5
    1064:	44                   	inc    sp
    1065:	65 73 74             	gs jae 0x10dc
    1068:	72 4d                	jb     0x10b7
    106a:	6f                   	outs   dx,WORD PTR ds:[si]
    106b:	79 50                	jns    0x10bd
    106d:	63 0b                	arpl   WORD PTR [bp+di],cx
    106f:	43                   	inc    bx
    1070:	61                   	popa
    1071:	74 61                	je     0x10d4
    1073:	50                   	push   ax
    1074:	72 6f                	jb     0x10e5
    1076:	62 61 50             	bound  sp,DWORD PTR [bx+di+0x50]
    1079:	63 0f                	arpl   WORD PTR [bx],cx
    107b:	43                   	inc    bx
    107c:	61                   	popa
    107d:	74 61                	je     0x10e0
    107f:	44                   	inc    sp
    1080:	65 73 74             	gs jae 0x10f7
    1083:	72 45                	jb     0x10ca
    1085:	6e                   	outs   dx,BYTE PTR ds:[si]
    1086:	74 31                	je     0x10b9
    1088:	50                   	push   ax
    1089:	63 0f                	arpl   WORD PTR [bx],cx
    108b:	43                   	inc    bx
    108c:	61                   	popa
    108d:	74 61                	je     0x10f0
    108f:	44                   	inc    sp
    1090:	65 73 74             	gs jae 0x1107
    1093:	72 45                	jb     0x10da
    1095:	6e                   	outs   dx,BYTE PTR ds:[si]
    1096:	74 32                	je     0x10ca
    1098:	50                   	push   ax
    1099:	63 0f                	arpl   WORD PTR [bx],cx
    109b:	43                   	inc    bx
    109c:	61                   	popa
    109d:	74 61                	je     0x1100
    109f:	44                   	inc    sp
    10a0:	65 73 74             	gs jae 0x1117
    10a3:	72 45                	jb     0x10ea
    10a5:	6e                   	outs   dx,BYTE PTR ds:[si]
    10a6:	74 33                	je     0x10db
    10a8:	50                   	push   ax
    10a9:	63 0f                	arpl   WORD PTR [bx],cx
    10ab:	43                   	inc    bx
    10ac:	61                   	popa
    10ad:	74 61                	je     0x1110
    10af:	44                   	inc    sp
    10b0:	65 73 74             	gs jae 0x1127
    10b3:	72 45                	jb     0x10fa
    10b5:	6e                   	outs   dx,BYTE PTR ds:[si]
    10b6:	74 34                	je     0x10ec
    10b8:	50                   	push   ax
    10b9:	63 0f                	arpl   WORD PTR [bx],cx
    10bb:	43                   	inc    bx
    10bc:	61                   	popa
    10bd:	74 61                	je     0x1120
    10bf:	44                   	inc    sp
    10c0:	65 73 74             	gs jae 0x1137
    10c3:	72 45                	jb     0x110a
    10c5:	6e                   	outs   dx,BYTE PTR ds:[si]
    10c6:	74 35                	je     0x10fd
    10c8:	50                   	push   ax
    10c9:	63 0f                	arpl   WORD PTR [bx],cx
    10cb:	43                   	inc    bx
    10cc:	61                   	popa
    10cd:	74 61                	je     0x1130
    10cf:	44                   	inc    sp
    10d0:	65 73 74             	gs jae 0x1147
    10d3:	72 45                	jb     0x111a
    10d5:	6e                   	outs   dx,BYTE PTR ds:[si]
    10d6:	74 36                	je     0x110e
    10d8:	50                   	push   ax
    10d9:	63 0f                	arpl   WORD PTR [bx],cx
    10db:	43                   	inc    bx
    10dc:	61                   	popa
    10dd:	74 61                	je     0x1140
    10df:	44                   	inc    sp
    10e0:	65 73 74             	gs jae 0x1157
    10e3:	72 45                	jb     0x112a
    10e5:	6e                   	outs   dx,BYTE PTR ds:[si]
    10e6:	74 37                	je     0x111f
    10e8:	50                   	push   ax
    10e9:	63 0f                	arpl   WORD PTR [bx],cx
    10eb:	43                   	inc    bx
    10ec:	61                   	popa
    10ed:	74 61                	je     0x1150
    10ef:	44                   	inc    sp
    10f0:	65 73 74             	gs jae 0x1167
    10f3:	72 45                	jb     0x113a
    10f5:	6e                   	outs   dx,BYTE PTR ds:[si]
    10f6:	74 38                	je     0x1130
    10f8:	50                   	push   ax
    10f9:	63 0a                	arpl   WORD PTR [bp+si],cx
    10fb:	56                   	push   si
    10fc:	61                   	popa
    10fd:	6c                   	ins    BYTE PTR es:[di],dx
    10fe:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    1103:	6f                   	outs   dx,WORD PTR ds:[si]
    1104:	6e                   	outs   dx,BYTE PTR ds:[si]
    1105:	07                   	pop    es
    1106:	53                   	push   bx
    1107:	70 65                	jo     0x116e
    1109:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    110c:	6c                   	ins    BYTE PTR es:[di],dx
    110d:	0e                   	push   cs
    110e:	50                   	push   ax
    110f:	65 72 69             	gs jb  0x117b
    1112:	6f                   	outs   dx,WORD PTR ds:[si]
    1113:	64 65 4e             	fs gs dec si
    1116:	6f                   	outs   dx,WORD PTR ds:[si]
    1117:	49                   	dec    cx
    1118:	6e                   	outs   dx,BYTE PTR ds:[si]
    1119:	64 65 78 55          	fs gs js 0x1172
    111d:	89 e5                	mov    bp,sp
    111f:	b8 08 00             	mov    ax,0x8
    1122:	9a 44 04 02 15       	call   0x1502:0x444
    1127:	83 ec 08             	sub    sp,0x8
    112a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    112d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1130:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1133:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    1137:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    113a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    113d:	bf a7 0e             	mov    di,0xea7
    1140:	0e                   	push   cs
    1141:	57                   	push   di
    1142:	6a 03                	push   0x3
    1144:	6a 00                	push   0x0
    1146:	6a 00                	push   0x0
    1148:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    114b:	06                   	push   es
    114c:	57                   	push   di
    114d:	9a a1 2a 65 11       	call   0x1165:0x2aa1
    1152:	bf b1 0e             	mov    di,0xeb1
    1155:	0e                   	push   cs
    1156:	57                   	push   di
    1157:	6a 08                	push   0x8
    1159:	6a 02                	push   0x2
    115b:	6a 00                	push   0x0
    115d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1160:	06                   	push   es
    1161:	57                   	push   di
    1162:	9a a1 2a 7a 11       	call   0x117a:0x2aa1
    1167:	bf bd 0e             	mov    di,0xebd
    116a:	0e                   	push   cs
    116b:	57                   	push   di
    116c:	6a 08                	push   0x8
    116e:	6a 02                	push   0x2
    1170:	6a 00                	push   0x0
    1172:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1175:	06                   	push   es
    1176:	57                   	push   di
    1177:	9a a1 2a 8f 11       	call   0x118f:0x2aa1
    117c:	bf cf 0e             	mov    di,0xecf
    117f:	0e                   	push   cs
    1180:	57                   	push   di
    1181:	6a 08                	push   0x8
    1183:	6a 02                	push   0x2
    1185:	6a 00                	push   0x0
    1187:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    118a:	06                   	push   es
    118b:	57                   	push   di
    118c:	9a a1 2a a4 11       	call   0x11a4:0x2aa1
    1191:	bf e2 0e             	mov    di,0xee2
    1194:	0e                   	push   cs
    1195:	57                   	push   di
    1196:	6a 08                	push   0x8
    1198:	6a 02                	push   0x2
    119a:	6a 00                	push   0x0
    119c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    119f:	06                   	push   es
    11a0:	57                   	push   di
    11a1:	9a a1 2a b9 11       	call   0x11b9:0x2aa1
    11a6:	bf f4 0e             	mov    di,0xef4
    11a9:	0e                   	push   cs
    11aa:	57                   	push   di
    11ab:	6a 08                	push   0x8
    11ad:	6a 02                	push   0x2
    11af:	6a 00                	push   0x0
    11b1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    11b4:	06                   	push   es
    11b5:	57                   	push   di
    11b6:	9a a1 2a ce 11       	call   0x11ce:0x2aa1
    11bb:	bf fc 0e             	mov    di,0xefc
    11be:	0e                   	push   cs
    11bf:	57                   	push   di
    11c0:	6a 08                	push   0x8
    11c2:	6a 02                	push   0x2
    11c4:	6a 00                	push   0x0
    11c6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    11c9:	06                   	push   es
    11ca:	57                   	push   di
    11cb:	9a a1 2a e3 11       	call   0x11e3:0x2aa1
    11d0:	bf 03 0f             	mov    di,0xf03
    11d3:	0e                   	push   cs
    11d4:	57                   	push   di
    11d5:	6a 08                	push   0x8
    11d7:	6a 02                	push   0x2
    11d9:	6a 00                	push   0x0
    11db:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    11de:	06                   	push   es
    11df:	57                   	push   di
    11e0:	9a a1 2a f8 11       	call   0x11f8:0x2aa1
    11e5:	bf 11 0f             	mov    di,0xf11
    11e8:	0e                   	push   cs
    11e9:	57                   	push   di
    11ea:	6a 06                	push   0x6
    11ec:	6a 00                	push   0x0
    11ee:	6a 00                	push   0x0
    11f0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    11f3:	06                   	push   es
    11f4:	57                   	push   di
    11f5:	9a a1 2a 0d 12       	call   0x120d:0x2aa1
    11fa:	bf 22 0f             	mov    di,0xf22
    11fd:	0e                   	push   cs
    11fe:	57                   	push   di
    11ff:	6a 06                	push   0x6
    1201:	6a 00                	push   0x0
    1203:	6a 00                	push   0x0
    1205:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1208:	06                   	push   es
    1209:	57                   	push   di
    120a:	9a a1 2a 22 12       	call   0x1222:0x2aa1
    120f:	bf 35 0f             	mov    di,0xf35
    1212:	0e                   	push   cs
    1213:	57                   	push   di
    1214:	6a 08                	push   0x8
    1216:	6a 02                	push   0x2
    1218:	6a 00                	push   0x0
    121a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    121d:	06                   	push   es
    121e:	57                   	push   di
    121f:	9a a1 2a 37 12       	call   0x1237:0x2aa1
    1224:	bf 46 0f             	mov    di,0xf46
    1227:	0e                   	push   cs
    1228:	57                   	push   di
    1229:	6a 08                	push   0x8
    122b:	6a 02                	push   0x2
    122d:	6a 00                	push   0x0
    122f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1232:	06                   	push   es
    1233:	57                   	push   di
    1234:	9a a1 2a 4c 12       	call   0x124c:0x2aa1
    1239:	bf 5a 0f             	mov    di,0xf5a
    123c:	0e                   	push   cs
    123d:	57                   	push   di
    123e:	6a 08                	push   0x8
    1240:	6a 02                	push   0x2
    1242:	6a 00                	push   0x0
    1244:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1247:	06                   	push   es
    1248:	57                   	push   di
    1249:	9a a1 2a 61 12       	call   0x1261:0x2aa1
    124e:	bf 69 0f             	mov    di,0xf69
    1251:	0e                   	push   cs
    1252:	57                   	push   di
    1253:	6a 08                	push   0x8
    1255:	6a 02                	push   0x2
    1257:	6a 00                	push   0x0
    1259:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    125c:	06                   	push   es
    125d:	57                   	push   di
    125e:	9a a1 2a 76 12       	call   0x1276:0x2aa1
    1263:	bf 7c 0f             	mov    di,0xf7c
    1266:	0e                   	push   cs
    1267:	57                   	push   di
    1268:	6a 08                	push   0x8
    126a:	6a 02                	push   0x2
    126c:	6a 00                	push   0x0
    126e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1271:	06                   	push   es
    1272:	57                   	push   di
    1273:	9a a1 2a 8b 12       	call   0x128b:0x2aa1
    1278:	bf 8d 0f             	mov    di,0xf8d
    127b:	0e                   	push   cs
    127c:	57                   	push   di
    127d:	6a 08                	push   0x8
    127f:	6a 02                	push   0x2
    1281:	6a 00                	push   0x0
    1283:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1286:	06                   	push   es
    1287:	57                   	push   di
    1288:	9a a1 2a a0 12       	call   0x12a0:0x2aa1
    128d:	bf 9c 0f             	mov    di,0xf9c
    1290:	0e                   	push   cs
    1291:	57                   	push   di
    1292:	6a 08                	push   0x8
    1294:	6a 02                	push   0x2
    1296:	6a 00                	push   0x0
    1298:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    129b:	06                   	push   es
    129c:	57                   	push   di
    129d:	9a a1 2a b5 12       	call   0x12b5:0x2aa1
    12a2:	bf ab 0f             	mov    di,0xfab
    12a5:	0e                   	push   cs
    12a6:	57                   	push   di
    12a7:	6a 08                	push   0x8
    12a9:	6a 02                	push   0x2
    12ab:	6a 00                	push   0x0
    12ad:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    12b0:	06                   	push   es
    12b1:	57                   	push   di
    12b2:	9a a1 2a ca 12       	call   0x12ca:0x2aa1
    12b7:	bf be 0f             	mov    di,0xfbe
    12ba:	0e                   	push   cs
    12bb:	57                   	push   di
    12bc:	6a 08                	push   0x8
    12be:	6a 02                	push   0x2
    12c0:	6a 00                	push   0x0
    12c2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    12c5:	06                   	push   es
    12c6:	57                   	push   di
    12c7:	9a a1 2a df 12       	call   0x12df:0x2aa1
    12cc:	bf ce 0f             	mov    di,0xfce
    12cf:	0e                   	push   cs
    12d0:	57                   	push   di
    12d1:	6a 08                	push   0x8
    12d3:	6a 02                	push   0x2
    12d5:	6a 00                	push   0x0
    12d7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    12da:	06                   	push   es
    12db:	57                   	push   di
    12dc:	9a a1 2a f4 12       	call   0x12f4:0x2aa1
    12e1:	bf d7 0f             	mov    di,0xfd7
    12e4:	0e                   	push   cs
    12e5:	57                   	push   di
    12e6:	6a 08                	push   0x8
    12e8:	6a 02                	push   0x2
    12ea:	6a 00                	push   0x0
    12ec:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    12ef:	06                   	push   es
    12f0:	57                   	push   di
    12f1:	9a a1 2a 09 13       	call   0x1309:0x2aa1
    12f6:	bf e5 0f             	mov    di,0xfe5
    12f9:	0e                   	push   cs
    12fa:	57                   	push   di
    12fb:	6a 08                	push   0x8
    12fd:	6a 02                	push   0x2
    12ff:	6a 00                	push   0x0
    1301:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1304:	06                   	push   es
    1305:	57                   	push   di
    1306:	9a a1 2a 1e 13       	call   0x131e:0x2aa1
    130b:	bf f7 0f             	mov    di,0xff7
    130e:	0e                   	push   cs
    130f:	57                   	push   di
    1310:	6a 03                	push   0x3
    1312:	6a 00                	push   0x0
    1314:	6a 00                	push   0x0
    1316:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1319:	06                   	push   es
    131a:	57                   	push   di
    131b:	9a a1 2a 33 13       	call   0x1333:0x2aa1
    1320:	bf 0a 10             	mov    di,0x100a
    1323:	0e                   	push   cs
    1324:	57                   	push   di
    1325:	6a 08                	push   0x8
    1327:	6a 02                	push   0x2
    1329:	6a 00                	push   0x0
    132b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    132e:	06                   	push   es
    132f:	57                   	push   di
    1330:	9a a1 2a 48 13       	call   0x1348:0x2aa1
    1335:	bf 16 10             	mov    di,0x1016
    1338:	0e                   	push   cs
    1339:	57                   	push   di
    133a:	6a 05                	push   0x5
    133c:	6a 00                	push   0x0
    133e:	6a 00                	push   0x0
    1340:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1343:	06                   	push   es
    1344:	57                   	push   di
    1345:	9a a1 2a 5d 13       	call   0x135d:0x2aa1
    134a:	bf 28 10             	mov    di,0x1028
    134d:	0e                   	push   cs
    134e:	57                   	push   di
    134f:	6a 08                	push   0x8
    1351:	6a 02                	push   0x2
    1353:	6a 00                	push   0x0
    1355:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1358:	06                   	push   es
    1359:	57                   	push   di
    135a:	9a a1 2a 72 13       	call   0x1372:0x2aa1
    135f:	bf 38 10             	mov    di,0x1038
    1362:	0e                   	push   cs
    1363:	57                   	push   di
    1364:	6a 08                	push   0x8
    1366:	6a 02                	push   0x2
    1368:	6a 00                	push   0x0
    136a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    136d:	06                   	push   es
    136e:	57                   	push   di
    136f:	9a a1 2a 87 13       	call   0x1387:0x2aa1
    1374:	bf 43 10             	mov    di,0x1043
    1377:	0e                   	push   cs
    1378:	57                   	push   di
    1379:	6a 03                	push   0x3
    137b:	6a 00                	push   0x0
    137d:	6a 00                	push   0x0
    137f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1382:	06                   	push   es
    1383:	57                   	push   di
    1384:	9a a1 2a 9c 13       	call   0x139c:0x2aa1
    1389:	bf 4c 10             	mov    di,0x104c
    138c:	0e                   	push   cs
    138d:	57                   	push   di
    138e:	6a 03                	push   0x3
    1390:	6a 00                	push   0x0
    1392:	6a 00                	push   0x0
    1394:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1397:	06                   	push   es
    1398:	57                   	push   di
    1399:	9a a1 2a b1 13       	call   0x13b1:0x2aa1
    139e:	bf 55 10             	mov    di,0x1055
    13a1:	0e                   	push   cs
    13a2:	57                   	push   di
    13a3:	6a 03                	push   0x3
    13a5:	6a 00                	push   0x0
    13a7:	6a 00                	push   0x0
    13a9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    13ac:	06                   	push   es
    13ad:	57                   	push   di
    13ae:	9a a1 2a c6 13       	call   0x13c6:0x2aa1
    13b3:	bf 5f 10             	mov    di,0x105f
    13b6:	0e                   	push   cs
    13b7:	57                   	push   di
    13b8:	6a 03                	push   0x3
    13ba:	6a 00                	push   0x0
    13bc:	6a 00                	push   0x0
    13be:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    13c1:	06                   	push   es
    13c2:	57                   	push   di
    13c3:	9a a1 2a db 13       	call   0x13db:0x2aa1
    13c8:	bf 6e 10             	mov    di,0x106e
    13cb:	0e                   	push   cs
    13cc:	57                   	push   di
    13cd:	6a 03                	push   0x3
    13cf:	6a 00                	push   0x0
    13d1:	6a 00                	push   0x0
    13d3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    13d6:	06                   	push   es
    13d7:	57                   	push   di
    13d8:	9a a1 2a f0 13       	call   0x13f0:0x2aa1
    13dd:	bf 7a 10             	mov    di,0x107a
    13e0:	0e                   	push   cs
    13e1:	57                   	push   di
    13e2:	6a 03                	push   0x3
    13e4:	6a 00                	push   0x0
    13e6:	6a 00                	push   0x0
    13e8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    13eb:	06                   	push   es
    13ec:	57                   	push   di
    13ed:	9a a1 2a 05 14       	call   0x1405:0x2aa1
    13f2:	bf 8a 10             	mov    di,0x108a
    13f5:	0e                   	push   cs
    13f6:	57                   	push   di
    13f7:	6a 03                	push   0x3
    13f9:	6a 00                	push   0x0
    13fb:	6a 00                	push   0x0
    13fd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1400:	06                   	push   es
    1401:	57                   	push   di
    1402:	9a a1 2a 1a 14       	call   0x141a:0x2aa1
    1407:	bf 9a 10             	mov    di,0x109a
    140a:	0e                   	push   cs
    140b:	57                   	push   di
    140c:	6a 03                	push   0x3
    140e:	6a 00                	push   0x0
    1410:	6a 00                	push   0x0
    1412:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1415:	06                   	push   es
    1416:	57                   	push   di
    1417:	9a a1 2a 2f 14       	call   0x142f:0x2aa1
    141c:	bf aa 10             	mov    di,0x10aa
    141f:	0e                   	push   cs
    1420:	57                   	push   di
    1421:	6a 03                	push   0x3
    1423:	6a 00                	push   0x0
    1425:	6a 00                	push   0x0
    1427:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    142a:	06                   	push   es
    142b:	57                   	push   di
    142c:	9a a1 2a 44 14       	call   0x1444:0x2aa1
    1431:	bf ba 10             	mov    di,0x10ba
    1434:	0e                   	push   cs
    1435:	57                   	push   di
    1436:	6a 03                	push   0x3
    1438:	6a 00                	push   0x0
    143a:	6a 00                	push   0x0
    143c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    143f:	06                   	push   es
    1440:	57                   	push   di
    1441:	9a a1 2a 59 14       	call   0x1459:0x2aa1
    1446:	bf ca 10             	mov    di,0x10ca
    1449:	0e                   	push   cs
    144a:	57                   	push   di
    144b:	6a 03                	push   0x3
    144d:	6a 00                	push   0x0
    144f:	6a 00                	push   0x0
    1451:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1454:	06                   	push   es
    1455:	57                   	push   di
    1456:	9a a1 2a 6e 14       	call   0x146e:0x2aa1
    145b:	bf da 10             	mov    di,0x10da
    145e:	0e                   	push   cs
    145f:	57                   	push   di
    1460:	6a 03                	push   0x3
    1462:	6a 00                	push   0x0
    1464:	6a 00                	push   0x0
    1466:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1469:	06                   	push   es
    146a:	57                   	push   di
    146b:	9a a1 2a 83 14       	call   0x1483:0x2aa1
    1470:	bf ea 10             	mov    di,0x10ea
    1473:	0e                   	push   cs
    1474:	57                   	push   di
    1475:	6a 03                	push   0x3
    1477:	6a 00                	push   0x0
    1479:	6a 00                	push   0x0
    147b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    147e:	06                   	push   es
    147f:	57                   	push   di
    1480:	9a a1 2a 98 14       	call   0x1498:0x2aa1
    1485:	bf fa 10             	mov    di,0x10fa
    1488:	0e                   	push   cs
    1489:	57                   	push   di
    148a:	6a 05                	push   0x5
    148c:	6a 00                	push   0x0
    148e:	6a 00                	push   0x0
    1490:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1493:	06                   	push   es
    1494:	57                   	push   di
    1495:	9a a1 2a ad 14       	call   0x14ad:0x2aa1
    149a:	bf 05 11             	mov    di,0x1105
    149d:	0e                   	push   cs
    149e:	57                   	push   di
    149f:	6a 03                	push   0x3
    14a1:	6a 00                	push   0x0
    14a3:	6a 00                	push   0x0
    14a5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14a8:	06                   	push   es
    14a9:	57                   	push   di
    14aa:	9a a1 2a 34 18       	call   0x1834:0x2aa1
    14af:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    14b2:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    14b7:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    14ba:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    14bd:	bf 0d 11             	mov    di,0x110d
    14c0:	0e                   	push   cs
    14c1:	57                   	push   di
    14c2:	bf a7 0e             	mov    di,0xea7
    14c5:	0e                   	push   cs
    14c6:	57                   	push   di
    14c7:	6a 03                	push   0x3
    14c9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14cc:	06                   	push   es
    14cd:	57                   	push   di
    14ce:	9a f6 18 62 15       	call   0x1562:0x18f6
    14d3:	c9                   	leave
    14d4:	ca 04 00             	retf   0x4
    14d7:	00 00                	add    BYTE PTR [bx+si],al
    14d9:	00 00                	add    BYTE PTR [bx+si],al
    14db:	cd cc                	int    0xcc
    14dd:	cc                   	int3
    14de:	cc                   	int3
    14df:	cc                   	int3
    14e0:	cc                   	int3
    14e1:	cc                   	int3
    14e2:	9c                   	pushf
    14e3:	03 40 ec             	add    ax,WORD PTR [bx+si-0x14]
    14e6:	51                   	push   cx
    14e7:	b8 1e 85             	mov    ax,0x851e
    14ea:	eb 51                	jmp    0x153d
    14ec:	85 04                	test   WORD PTR [si],ax
    14ee:	40                   	inc    ax
    14ef:	cd cc                	int    0xcc
    14f1:	cc                   	int3
    14f2:	cc                   	int3
    14f3:	cc                   	int3
    14f4:	cc                   	int3
    14f5:	cc                   	int3
    14f6:	cc                   	int3
    14f7:	ff                   	(bad)
    14f8:	3f                   	aas
    14f9:	55                   	push   bp
    14fa:	89 e5                	mov    bp,sp
    14fc:	b8 8e 01             	mov    ax,0x18e
    14ff:	9a 44 04 2a 15       	call   0x152a:0x444
    1504:	81 ec 8e 01          	sub    sp,0x18e
    1508:	83 3e 5c 01 00       	cmp    WORD PTR ds:0x15c,0x0
    150d:	75 0e                	jne    0x151d
    150f:	9b 2e d9 06 d7 14    	fld    DWORD PTR cs:0x14d7
    1515:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    1519:	90                   	nop
    151a:	9b                   	fwait
    151b:	eb 15                	jmp    0x1532
    151d:	9b df 06 5c 01       	fild   WORD PTR ds:0x15c
    1522:	9b dd 06 52 01       	fld    QWORD PTR ds:0x152
    1527:	9a af 04 4c 18       	call   0x184c:0x4af
    152c:	9b dd 5e f6          	fstp   QWORD PTR [bp-0xa]
    1530:	90                   	nop
    1531:	9b                   	fwait
    1532:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1535:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    1538:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    153b:	31 c0                	xor    ax,ax
    153d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1540:	eb 03                	jmp    0x1545
    1542:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1545:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1548:	99                   	cwd
    1549:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    154c:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    154f:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    1553:	8d 7e ea             	lea    di,[bp-0x16]
    1556:	16                   	push   ss
    1557:	57                   	push   di
    1558:	6a 00                	push   0x0
    155a:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    155d:	06                   	push   es
    155e:	57                   	push   di
    155f:	9a 95 28 78 18       	call   0x1878:0x2895
    1564:	08 c0                	or     al,al
    1566:	74 03                	je     0x156b
    1568:	e9 cb 02             	jmp    0x1836
    156b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    156e:	99                   	cwd
    156f:	89 86 72 fe          	mov    WORD PTR [bp-0x18e],ax
    1573:	89 96 74 fe          	mov    WORD PTR [bp-0x18c],dx
    1577:	c6 86 76 fe 00       	mov    BYTE PTR [bp-0x18a],0x0
    157c:	c7 86 7a fe 08 00    	mov    WORD PTR [bp-0x186],0x8
    1582:	c7 86 7c fe 00 00    	mov    WORD PTR [bp-0x184],0x0
    1588:	c6 86 7e fe 00       	mov    BYTE PTR [bp-0x182],0x0
    158d:	c7 86 82 fe 0c 00    	mov    WORD PTR [bp-0x17e],0xc
    1593:	c7 86 84 fe 00 00    	mov    WORD PTR [bp-0x17c],0x0
    1599:	c6 86 86 fe 00       	mov    BYTE PTR [bp-0x17a],0x0
    159e:	c7 86 8a fe 10 00    	mov    WORD PTR [bp-0x176],0x10
    15a4:	c7 86 8c fe 00 00    	mov    WORD PTR [bp-0x174],0x0
    15aa:	c6 86 8e fe 00       	mov    BYTE PTR [bp-0x172],0x0
    15af:	c7 86 92 fe 04 00    	mov    WORD PTR [bp-0x16e],0x4
    15b5:	c7 86 94 fe 00 00    	mov    WORD PTR [bp-0x16c],0x0
    15bb:	c6 86 96 fe 00       	mov    BYTE PTR [bp-0x16a],0x0
    15c0:	9b 2e db 2e db 14    	fld    TBYTE PTR cs:0x14db
    15c6:	9b db 7e e0          	fstp   TBYTE PTR [bp-0x20]
    15ca:	8d 46 e0             	lea    ax,[bp-0x20]
    15cd:	8c d2                	mov    dx,ss
    15cf:	89 86 9a fe          	mov    WORD PTR [bp-0x166],ax
    15d3:	89 96 9c fe          	mov    WORD PTR [bp-0x164],dx
    15d7:	c6 86 9e fe 03       	mov    BYTE PTR [bp-0x162],0x3
    15dc:	9b 2e db 2e e5 14    	fld    TBYTE PTR cs:0x14e5
    15e2:	9b db 7e d6          	fstp   TBYTE PTR [bp-0x2a]
    15e6:	8d 46 d6             	lea    ax,[bp-0x2a]
    15e9:	8c d2                	mov    dx,ss
    15eb:	89 86 a2 fe          	mov    WORD PTR [bp-0x15e],ax
    15ef:	89 96 a4 fe          	mov    WORD PTR [bp-0x15c],dx
    15f3:	c6 86 a6 fe 03       	mov    BYTE PTR [bp-0x15a],0x3
    15f8:	c7 86 aa fe 04 00    	mov    WORD PTR [bp-0x156],0x4
    15fe:	c7 86 ac fe 00 00    	mov    WORD PTR [bp-0x154],0x0
    1604:	c6 86 ae fe 00       	mov    BYTE PTR [bp-0x152],0x0
    1609:	c7 86 b2 fe d0 07    	mov    WORD PTR [bp-0x14e],0x7d0
    160f:	c7 86 b4 fe 00 00    	mov    WORD PTR [bp-0x14c],0x0
    1615:	c6 86 b6 fe 00       	mov    BYTE PTR [bp-0x14a],0x0
    161a:	c7 86 ba fe dc 05    	mov    WORD PTR [bp-0x146],0x5dc
    1620:	c7 86 bc fe 00 00    	mov    WORD PTR [bp-0x144],0x0
    1626:	c6 86 be fe 00       	mov    BYTE PTR [bp-0x142],0x0
    162b:	9b dd 46 f6          	fld    QWORD PTR [bp-0xa]
    162f:	9b db 7e cc          	fstp   TBYTE PTR [bp-0x34]
    1633:	8d 46 cc             	lea    ax,[bp-0x34]
    1636:	8c d2                	mov    dx,ss
    1638:	89 86 c2 fe          	mov    WORD PTR [bp-0x13e],ax
    163c:	89 96 c4 fe          	mov    WORD PTR [bp-0x13c],dx
    1640:	c6 86 c6 fe 03       	mov    BYTE PTR [bp-0x13a],0x3
    1645:	c7 86 ca fe c8 00    	mov    WORD PTR [bp-0x136],0xc8
    164b:	c7 86 cc fe 00 00    	mov    WORD PTR [bp-0x134],0x0
    1651:	c6 86 ce fe 00       	mov    BYTE PTR [bp-0x132],0x0
    1656:	c7 86 d2 fe 02 00    	mov    WORD PTR [bp-0x12e],0x2
    165c:	c7 86 d4 fe 00 00    	mov    WORD PTR [bp-0x12c],0x0
    1662:	c6 86 d6 fe 00       	mov    BYTE PTR [bp-0x12a],0x0
    1667:	c7 86 da fe 30 75    	mov    WORD PTR [bp-0x126],0x7530
    166d:	c7 86 dc fe 00 00    	mov    WORD PTR [bp-0x124],0x0
    1673:	c6 86 de fe 00       	mov    BYTE PTR [bp-0x122],0x0
    1678:	c7 86 e2 fe 40 9c    	mov    WORD PTR [bp-0x11e],0x9c40
    167e:	c7 86 e4 fe 00 00    	mov    WORD PTR [bp-0x11c],0x0
    1684:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    1689:	c7 86 ea fe c0 d4    	mov    WORD PTR [bp-0x116],0xd4c0
    168f:	c7 86 ec fe 01 00    	mov    WORD PTR [bp-0x114],0x1
    1695:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    169a:	c7 86 f2 fe 4b 00    	mov    WORD PTR [bp-0x10e],0x4b
    16a0:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    16a6:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    16ab:	c7 86 fa fe 19 00    	mov    WORD PTR [bp-0x106],0x19
    16b1:	c7 86 fc fe 00 00    	mov    WORD PTR [bp-0x104],0x0
    16b7:	c6 86 fe fe 00       	mov    BYTE PTR [bp-0x102],0x0
    16bc:	9b 2e db 2e ef 14    	fld    TBYTE PTR cs:0x14ef
    16c2:	9b db 7e c2          	fstp   TBYTE PTR [bp-0x3e]
    16c6:	8d 46 c2             	lea    ax,[bp-0x3e]
    16c9:	8c d2                	mov    dx,ss
    16cb:	89 86 02 ff          	mov    WORD PTR [bp-0xfe],ax
    16cf:	89 96 04 ff          	mov    WORD PTR [bp-0xfc],dx
    16d3:	c6 86 06 ff 03       	mov    BYTE PTR [bp-0xfa],0x3
    16d8:	c7 86 0a ff 40 42    	mov    WORD PTR [bp-0xf6],0x4240
    16de:	c7 86 0c ff 0f 00    	mov    WORD PTR [bp-0xf4],0xf
    16e4:	c6 86 0e ff 00       	mov    BYTE PTR [bp-0xf2],0x0
    16e9:	c7 86 12 ff 80 1a    	mov    WORD PTR [bp-0xee],0x1a80
    16ef:	c7 86 14 ff 06 00    	mov    WORD PTR [bp-0xec],0x6
    16f5:	c6 86 16 ff 00       	mov    BYTE PTR [bp-0xea],0x0
    16fa:	c7 86 1a ff a0 86    	mov    WORD PTR [bp-0xe6],0x86a0
    1700:	c7 86 1c ff 01 00    	mov    WORD PTR [bp-0xe4],0x1
    1706:	c6 86 1e ff 00       	mov    BYTE PTR [bp-0xe2],0x0
    170b:	c7 86 22 ff 0a 00    	mov    WORD PTR [bp-0xde],0xa
    1711:	c7 86 24 ff 00 00    	mov    WORD PTR [bp-0xdc],0x0
    1717:	c6 86 26 ff 00       	mov    BYTE PTR [bp-0xda],0x0
    171c:	c7 86 2a ff 03 00    	mov    WORD PTR [bp-0xd6],0x3
    1722:	c7 86 2c ff 00 00    	mov    WORD PTR [bp-0xd4],0x0
    1728:	c6 86 2e ff 00       	mov    BYTE PTR [bp-0xd2],0x0
    172d:	c6 86 32 ff 01       	mov    BYTE PTR [bp-0xce],0x1
    1732:	c6 86 36 ff 01       	mov    BYTE PTR [bp-0xca],0x1
    1737:	c7 86 3a ff 0f 00    	mov    WORD PTR [bp-0xc6],0xf
    173d:	c7 86 3c ff 00 00    	mov    WORD PTR [bp-0xc4],0x0
    1743:	c6 86 3e ff 00       	mov    BYTE PTR [bp-0xc2],0x0
    1748:	31 c0                	xor    ax,ax
    174a:	89 86 42 ff          	mov    WORD PTR [bp-0xbe],ax
    174e:	89 86 44 ff          	mov    WORD PTR [bp-0xbc],ax
    1752:	c6 86 46 ff 00       	mov    BYTE PTR [bp-0xba],0x0
    1757:	31 c0                	xor    ax,ax
    1759:	89 86 4a ff          	mov    WORD PTR [bp-0xb6],ax
    175d:	89 86 4c ff          	mov    WORD PTR [bp-0xb4],ax
    1761:	c6 86 4e ff 00       	mov    BYTE PTR [bp-0xb2],0x0
    1766:	31 c0                	xor    ax,ax
    1768:	89 86 52 ff          	mov    WORD PTR [bp-0xae],ax
    176c:	89 86 54 ff          	mov    WORD PTR [bp-0xac],ax
    1770:	c6 86 56 ff 00       	mov    BYTE PTR [bp-0xaa],0x0
    1775:	31 c0                	xor    ax,ax
    1777:	89 86 5a ff          	mov    WORD PTR [bp-0xa6],ax
    177b:	89 86 5c ff          	mov    WORD PTR [bp-0xa4],ax
    177f:	c6 86 5e ff 00       	mov    BYTE PTR [bp-0xa2],0x0
    1784:	31 c0                	xor    ax,ax
    1786:	89 86 62 ff          	mov    WORD PTR [bp-0x9e],ax
    178a:	89 86 64 ff          	mov    WORD PTR [bp-0x9c],ax
    178e:	c6 86 66 ff 00       	mov    BYTE PTR [bp-0x9a],0x0
    1793:	31 c0                	xor    ax,ax
    1795:	89 86 6a ff          	mov    WORD PTR [bp-0x96],ax
    1799:	89 86 6c ff          	mov    WORD PTR [bp-0x94],ax
    179d:	c6 86 6e ff 00       	mov    BYTE PTR [bp-0x92],0x0
    17a2:	31 c0                	xor    ax,ax
    17a4:	89 86 72 ff          	mov    WORD PTR [bp-0x8e],ax
    17a8:	89 86 74 ff          	mov    WORD PTR [bp-0x8c],ax
    17ac:	c6 86 76 ff 00       	mov    BYTE PTR [bp-0x8a],0x0
    17b1:	31 c0                	xor    ax,ax
    17b3:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    17b7:	89 86 7c ff          	mov    WORD PTR [bp-0x84],ax
    17bb:	c6 86 7e ff 00       	mov    BYTE PTR [bp-0x82],0x0
    17c0:	31 c0                	xor    ax,ax
    17c2:	89 46 82             	mov    WORD PTR [bp-0x7e],ax
    17c5:	89 46 84             	mov    WORD PTR [bp-0x7c],ax
    17c8:	c6 46 86 00          	mov    BYTE PTR [bp-0x7a],0x0
    17cc:	31 c0                	xor    ax,ax
    17ce:	89 46 8a             	mov    WORD PTR [bp-0x76],ax
    17d1:	89 46 8c             	mov    WORD PTR [bp-0x74],ax
    17d4:	c6 46 8e 00          	mov    BYTE PTR [bp-0x72],0x0
    17d8:	31 c0                	xor    ax,ax
    17da:	89 46 92             	mov    WORD PTR [bp-0x6e],ax
    17dd:	89 46 94             	mov    WORD PTR [bp-0x6c],ax
    17e0:	c6 46 96 00          	mov    BYTE PTR [bp-0x6a],0x0
    17e4:	31 c0                	xor    ax,ax
    17e6:	89 46 9a             	mov    WORD PTR [bp-0x66],ax
    17e9:	89 46 9c             	mov    WORD PTR [bp-0x64],ax
    17ec:	c6 46 9e 00          	mov    BYTE PTR [bp-0x62],0x0
    17f0:	31 c0                	xor    ax,ax
    17f2:	89 46 a2             	mov    WORD PTR [bp-0x5e],ax
    17f5:	89 46 a4             	mov    WORD PTR [bp-0x5c],ax
    17f8:	c6 46 a6 00          	mov    BYTE PTR [bp-0x5a],0x0
    17fc:	31 c0                	xor    ax,ax
    17fe:	89 46 aa             	mov    WORD PTR [bp-0x56],ax
    1801:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    1804:	c6 46 ae 00          	mov    BYTE PTR [bp-0x52],0x0
    1808:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    180c:	b0 00                	mov    al,0x0
    180e:	75 01                	jne    0x1811
    1810:	40                   	inc    ax
    1811:	88 46 b2             	mov    BYTE PTR [bp-0x4e],al
    1814:	c6 46 b6 01          	mov    BYTE PTR [bp-0x4a],0x1
    1818:	31 c0                	xor    ax,ax
    181a:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    181d:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    1820:	c6 46 be 00          	mov    BYTE PTR [bp-0x42],0x0
    1824:	8d be 72 fe          	lea    di,[bp-0x18e]
    1828:	16                   	push   ss
    1829:	57                   	push   di
    182a:	6a 29                	push   0x29
    182c:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    182f:	06                   	push   es
    1830:	57                   	push   di
    1831:	9a 21 53 d5 1a       	call   0x1ad5:0x5321
    1836:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    183a:	74 03                	je     0x183f
    183c:	e9 03 fd             	jmp    0x1542
    183f:	c9                   	leave
    1840:	ca 04 00             	retf   0x4
    1843:	55                   	push   bp
    1844:	89 e5                	mov    bp,sp
    1846:	b8 5c 01             	mov    ax,0x15c
    1849:	9a 44 04 cb 1b       	call   0x1bcb:0x444
    184e:	81 ec 5c 01          	sub    sp,0x15c
    1852:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1855:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1858:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    185b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    185e:	99                   	cwd
    185f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1862:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    1865:	c6 46 f8 00          	mov    BYTE PTR [bp-0x8],0x0
    1869:	8d 7e f4             	lea    di,[bp-0xc]
    186c:	16                   	push   ss
    186d:	57                   	push   di
    186e:	6a 00                	push   0x0
    1870:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1873:	06                   	push   es
    1874:	57                   	push   di
    1875:	9a 95 28 40 1d       	call   0x1d40:0x2895
    187a:	08 c0                	or     al,al
    187c:	74 03                	je     0x1881
    187e:	e9 56 02             	jmp    0x1ad7
    1881:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1884:	99                   	cwd
    1885:	89 86 a4 fe          	mov    WORD PTR [bp-0x15c],ax
    1889:	89 96 a6 fe          	mov    WORD PTR [bp-0x15a],dx
    188d:	c6 86 a8 fe 00       	mov    BYTE PTR [bp-0x158],0x0
    1892:	31 c0                	xor    ax,ax
    1894:	89 86 ac fe          	mov    WORD PTR [bp-0x154],ax
    1898:	89 86 ae fe          	mov    WORD PTR [bp-0x152],ax
    189c:	c6 86 b0 fe 00       	mov    BYTE PTR [bp-0x150],0x0
    18a1:	31 c0                	xor    ax,ax
    18a3:	89 86 b4 fe          	mov    WORD PTR [bp-0x14c],ax
    18a7:	89 86 b6 fe          	mov    WORD PTR [bp-0x14a],ax
    18ab:	c6 86 b8 fe 00       	mov    BYTE PTR [bp-0x148],0x0
    18b0:	31 c0                	xor    ax,ax
    18b2:	89 86 bc fe          	mov    WORD PTR [bp-0x144],ax
    18b6:	89 86 be fe          	mov    WORD PTR [bp-0x142],ax
    18ba:	c6 86 c0 fe 00       	mov    BYTE PTR [bp-0x140],0x0
    18bf:	31 c0                	xor    ax,ax
    18c1:	89 86 c4 fe          	mov    WORD PTR [bp-0x13c],ax
    18c5:	89 86 c6 fe          	mov    WORD PTR [bp-0x13a],ax
    18c9:	c6 86 c8 fe 00       	mov    BYTE PTR [bp-0x138],0x0
    18ce:	31 c0                	xor    ax,ax
    18d0:	89 86 cc fe          	mov    WORD PTR [bp-0x134],ax
    18d4:	89 86 ce fe          	mov    WORD PTR [bp-0x132],ax
    18d8:	c6 86 d0 fe 00       	mov    BYTE PTR [bp-0x130],0x0
    18dd:	31 c0                	xor    ax,ax
    18df:	89 86 d4 fe          	mov    WORD PTR [bp-0x12c],ax
    18e3:	89 86 d6 fe          	mov    WORD PTR [bp-0x12a],ax
    18e7:	c6 86 d8 fe 00       	mov    BYTE PTR [bp-0x128],0x0
    18ec:	31 c0                	xor    ax,ax
    18ee:	89 86 dc fe          	mov    WORD PTR [bp-0x124],ax
    18f2:	89 86 de fe          	mov    WORD PTR [bp-0x122],ax
    18f6:	c6 86 e0 fe 00       	mov    BYTE PTR [bp-0x120],0x0
    18fb:	31 c0                	xor    ax,ax
    18fd:	89 86 e4 fe          	mov    WORD PTR [bp-0x11c],ax
    1901:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    1905:	c6 86 e8 fe 00       	mov    BYTE PTR [bp-0x118],0x0
    190a:	31 c0                	xor    ax,ax
    190c:	89 86 ec fe          	mov    WORD PTR [bp-0x114],ax
    1910:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    1914:	c6 86 f0 fe 00       	mov    BYTE PTR [bp-0x110],0x0
    1919:	31 c0                	xor    ax,ax
    191b:	89 86 f4 fe          	mov    WORD PTR [bp-0x10c],ax
    191f:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    1923:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    1928:	31 c0                	xor    ax,ax
    192a:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    192e:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    1932:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    1937:	31 c0                	xor    ax,ax
    1939:	89 86 04 ff          	mov    WORD PTR [bp-0xfc],ax
    193d:	89 86 06 ff          	mov    WORD PTR [bp-0xfa],ax
    1941:	c6 86 08 ff 00       	mov    BYTE PTR [bp-0xf8],0x0
    1946:	31 c0                	xor    ax,ax
    1948:	89 86 0c ff          	mov    WORD PTR [bp-0xf4],ax
    194c:	89 86 0e ff          	mov    WORD PTR [bp-0xf2],ax
    1950:	c6 86 10 ff 00       	mov    BYTE PTR [bp-0xf0],0x0
    1955:	31 c0                	xor    ax,ax
    1957:	89 86 14 ff          	mov    WORD PTR [bp-0xec],ax
    195b:	89 86 16 ff          	mov    WORD PTR [bp-0xea],ax
    195f:	c6 86 18 ff 00       	mov    BYTE PTR [bp-0xe8],0x0
    1964:	31 c0                	xor    ax,ax
    1966:	89 86 1c ff          	mov    WORD PTR [bp-0xe4],ax
    196a:	89 86 1e ff          	mov    WORD PTR [bp-0xe2],ax
    196e:	c6 86 20 ff 00       	mov    BYTE PTR [bp-0xe0],0x0
    1973:	31 c0                	xor    ax,ax
    1975:	89 86 24 ff          	mov    WORD PTR [bp-0xdc],ax
    1979:	89 86 26 ff          	mov    WORD PTR [bp-0xda],ax
    197d:	c6 86 28 ff 00       	mov    BYTE PTR [bp-0xd8],0x0
    1982:	31 c0                	xor    ax,ax
    1984:	89 86 2c ff          	mov    WORD PTR [bp-0xd4],ax
    1988:	89 86 2e ff          	mov    WORD PTR [bp-0xd2],ax
    198c:	c6 86 30 ff 00       	mov    BYTE PTR [bp-0xd0],0x0
    1991:	31 c0                	xor    ax,ax
    1993:	89 86 34 ff          	mov    WORD PTR [bp-0xcc],ax
    1997:	89 86 36 ff          	mov    WORD PTR [bp-0xca],ax
    199b:	c6 86 38 ff 00       	mov    BYTE PTR [bp-0xc8],0x0
    19a0:	31 c0                	xor    ax,ax
    19a2:	89 86 3c ff          	mov    WORD PTR [bp-0xc4],ax
    19a6:	89 86 3e ff          	mov    WORD PTR [bp-0xc2],ax
    19aa:	c6 86 40 ff 00       	mov    BYTE PTR [bp-0xc0],0x0
    19af:	31 c0                	xor    ax,ax
    19b1:	89 86 44 ff          	mov    WORD PTR [bp-0xbc],ax
    19b5:	89 86 46 ff          	mov    WORD PTR [bp-0xba],ax
    19b9:	c6 86 48 ff 00       	mov    BYTE PTR [bp-0xb8],0x0
    19be:	31 c0                	xor    ax,ax
    19c0:	89 86 4c ff          	mov    WORD PTR [bp-0xb4],ax
    19c4:	89 86 4e ff          	mov    WORD PTR [bp-0xb2],ax
    19c8:	c6 86 50 ff 00       	mov    BYTE PTR [bp-0xb0],0x0
    19cd:	31 c0                	xor    ax,ax
    19cf:	89 86 54 ff          	mov    WORD PTR [bp-0xac],ax
    19d3:	89 86 56 ff          	mov    WORD PTR [bp-0xaa],ax
    19d7:	c6 86 58 ff 00       	mov    BYTE PTR [bp-0xa8],0x0
    19dc:	31 c0                	xor    ax,ax
    19de:	89 86 5c ff          	mov    WORD PTR [bp-0xa4],ax
    19e2:	89 86 5e ff          	mov    WORD PTR [bp-0xa2],ax
    19e6:	c6 86 60 ff 00       	mov    BYTE PTR [bp-0xa0],0x0
    19eb:	c6 86 64 ff 00       	mov    BYTE PTR [bp-0x9c],0x0
    19f0:	c6 86 68 ff 01       	mov    BYTE PTR [bp-0x98],0x1
    19f5:	31 c0                	xor    ax,ax
    19f7:	89 86 6c ff          	mov    WORD PTR [bp-0x94],ax
    19fb:	89 86 6e ff          	mov    WORD PTR [bp-0x92],ax
    19ff:	c6 86 70 ff 00       	mov    BYTE PTR [bp-0x90],0x0
    1a04:	31 c0                	xor    ax,ax
    1a06:	89 86 74 ff          	mov    WORD PTR [bp-0x8c],ax
    1a0a:	89 86 76 ff          	mov    WORD PTR [bp-0x8a],ax
    1a0e:	c6 86 78 ff 00       	mov    BYTE PTR [bp-0x88],0x0
    1a13:	31 c0                	xor    ax,ax
    1a15:	89 86 7c ff          	mov    WORD PTR [bp-0x84],ax
    1a19:	89 86 7e ff          	mov    WORD PTR [bp-0x82],ax
    1a1d:	c6 46 80 00          	mov    BYTE PTR [bp-0x80],0x0
    1a21:	31 c0                	xor    ax,ax
    1a23:	89 46 84             	mov    WORD PTR [bp-0x7c],ax
    1a26:	89 46 86             	mov    WORD PTR [bp-0x7a],ax
    1a29:	c6 46 88 00          	mov    BYTE PTR [bp-0x78],0x0
    1a2d:	31 c0                	xor    ax,ax
    1a2f:	89 46 8c             	mov    WORD PTR [bp-0x74],ax
    1a32:	89 46 8e             	mov    WORD PTR [bp-0x72],ax
    1a35:	c6 46 90 00          	mov    BYTE PTR [bp-0x70],0x0
    1a39:	31 c0                	xor    ax,ax
    1a3b:	89 46 94             	mov    WORD PTR [bp-0x6c],ax
    1a3e:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    1a41:	c6 46 98 00          	mov    BYTE PTR [bp-0x68],0x0
    1a45:	31 c0                	xor    ax,ax
    1a47:	89 46 9c             	mov    WORD PTR [bp-0x64],ax
    1a4a:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    1a4d:	c6 46 a0 00          	mov    BYTE PTR [bp-0x60],0x0
    1a51:	31 c0                	xor    ax,ax
    1a53:	89 46 a4             	mov    WORD PTR [bp-0x5c],ax
    1a56:	89 46 a6             	mov    WORD PTR [bp-0x5a],ax
    1a59:	c6 46 a8 00          	mov    BYTE PTR [bp-0x58],0x0
    1a5d:	31 c0                	xor    ax,ax
    1a5f:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    1a62:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    1a65:	c6 46 b0 00          	mov    BYTE PTR [bp-0x50],0x0
    1a69:	31 c0                	xor    ax,ax
    1a6b:	89 46 b4             	mov    WORD PTR [bp-0x4c],ax
    1a6e:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    1a71:	c6 46 b8 00          	mov    BYTE PTR [bp-0x48],0x0
    1a75:	31 c0                	xor    ax,ax
    1a77:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    1a7a:	89 46 be             	mov    WORD PTR [bp-0x42],ax
    1a7d:	c6 46 c0 00          	mov    BYTE PTR [bp-0x40],0x0
    1a81:	31 c0                	xor    ax,ax
    1a83:	89 46 c4             	mov    WORD PTR [bp-0x3c],ax
    1a86:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    1a89:	c6 46 c8 00          	mov    BYTE PTR [bp-0x38],0x0
    1a8d:	31 c0                	xor    ax,ax
    1a8f:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    1a92:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    1a95:	c6 46 d0 00          	mov    BYTE PTR [bp-0x30],0x0
    1a99:	31 c0                	xor    ax,ax
    1a9b:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    1a9e:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    1aa1:	c6 46 d8 00          	mov    BYTE PTR [bp-0x28],0x0
    1aa5:	31 c0                	xor    ax,ax
    1aa7:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    1aaa:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    1aad:	c6 46 e0 00          	mov    BYTE PTR [bp-0x20],0x0
    1ab1:	c6 46 e4 00          	mov    BYTE PTR [bp-0x1c],0x0
    1ab5:	c6 46 e8 01          	mov    BYTE PTR [bp-0x18],0x1
    1ab9:	31 c0                	xor    ax,ax
    1abb:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    1abe:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    1ac1:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    1ac5:	8d be a4 fe          	lea    di,[bp-0x15c]
    1ac9:	16                   	push   ss
    1aca:	57                   	push   di
    1acb:	6a 29                	push   0x29
    1acd:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1ad0:	06                   	push   es
    1ad1:	57                   	push   di
    1ad2:	9a 06 53 f6 1b       	call   0x1bf6:0x5306
    1ad7:	c9                   	leave
    1ad8:	ca 06 00             	retf   0x6
    1adb:	09 50 65             	or     WORD PTR [bx+si+0x65],dx
    1ade:	72 69                	jb     0x1b49
    1ae0:	6f                   	outs   dx,WORD PTR ds:[si]
    1ae1:	64 65 4e             	fs gs dec si
    1ae4:	6f                   	outs   dx,WORD PTR ds:[si]
    1ae5:	09 50 72             	or     WORD PTR [bx+si+0x72],dx
    1ae8:	6f                   	outs   dx,WORD PTR ds:[si]
    1ae9:	64 75 69             	fs jne 0x1b55
    1aec:	74 4e                	je     0x1b3c
    1aee:	6f                   	outs   dx,WORD PTR ds:[si]
    1aef:	0b 50 72             	or     dx,WORD PTR [bx+si+0x72]
    1af2:	69 78 4d 69 6e       	imul   di,WORD PTR [bx+si+0x4d],0x6e69
    1af7:	69 6d 75 6d 0b       	imul   bp,WORD PTR [di+0x75],0xb6d
    1afc:	50                   	push   ax
    1afd:	72 69                	jb     0x1b68
    1aff:	78 4d                	js     0x1b4e
    1b01:	61                   	popa
    1b02:	78 69                	js     0x1b6d
    1b04:	6d                   	ins    WORD PTR es:[di],dx
    1b05:	75 6d                	jne    0x1b74
    1b07:	12 49 6e             	adc    cl,BYTE PTR [bx+di+0x6e]
    1b0a:	64 69 63 65 43 6f    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6f43
    1b10:	6e                   	outs   dx,BYTE PTR ds:[si]
    1b11:	6a 6f                	push   0x6f
    1b13:	6e                   	outs   dx,BYTE PTR ds:[si]
    1b14:	63 74 75             	arpl   WORD PTR [si+0x75],si
    1b17:	72 65                	jb     0x1b7e
    1b19:	6c                   	ins    BYTE PTR es:[di],dx
    1b1a:	0b 43 6f             	or     ax,WORD PTR [bp+di+0x6f]
    1b1d:	75 74                	jne    0x1b93
    1b1f:	4d                   	dec    bp
    1b20:	61                   	popa
    1b21:	74 69                	je     0x1b8c
    1b23:	65 72 65             	gs jb  0x1b8b
    1b26:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
    1b29:	69 64 73 50 72       	imul   sp,WORD PTR [si+0x73],0x7250
    1b2e:	69 78 0e 50 6f       	imul   di,WORD PTR [bx+si+0xe],0x6f50
    1b33:	69 64 73 50 75       	imul   sp,WORD PTR [si+0x73],0x7550
    1b38:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
    1b3b:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
    1b3e:	65 0f                	gs movmskps ebp,(bad)
    1b40:	50                   	push   ax
    1b41:	6f                   	outs   dx,WORD PTR ds:[si]
    1b42:	69 64 73 46 6f       	imul   sp,WORD PTR [si+0x73],0x6f46
    1b47:	72 63                	jb     0x1bac
    1b49:	65 56                	gs push si
    1b4b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    1b4d:	74 65                	je     0x1bb4
    1b4f:	0b 50 6f             	or     dx,WORD PTR [bx+si+0x6f]
    1b52:	69 64 73 43 72       	imul   sp,WORD PTR [si+0x73],0x7243
    1b57:	65 64 69 74 0c 50 6f 	gs imul si,WORD PTR fs:[si+0xc],0x6f50
    1b5e:	69 64 73 51 75       	imul   sp,WORD PTR [si+0x73],0x7551
    1b63:	61                   	popa
    1b64:	6c                   	ins    BYTE PTR es:[di],dx
    1b65:	69 74 65 11 50       	imul   si,WORD PTR [si+0x65],0x5011
    1b6a:	6f                   	outs   dx,WORD PTR ds:[si]
    1b6b:	69 64 73 46 69       	imul   sp,WORD PTR [si+0x73],0x6946
    1b70:	64 65 6c             	fs gs ins BYTE PTR es:[di],dx
    1b73:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    1b78:	6f                   	outs   dx,WORD PTR ds:[si]
    1b79:	6e                   	outs   dx,BYTE PTR ds:[si]
    1b7a:	12 41 70             	adc    al,BYTE PTR [bx+di+0x70]
    1b7d:	70 65                	jo     0x1be4
    1b7f:	6c                   	ins    BYTE PTR es:[di],dx
    1b80:	4f                   	dec    di
    1b81:	66 66 72 65          	data32 data32 jb 0x1bea
    1b85:	51                   	push   cx
    1b86:	75 61                	jne    0x1be9
    1b88:	6e                   	outs   dx,BYTE PTR ds:[si]
    1b89:	74 69                	je     0x1bf4
    1b8b:	74 65                	je     0x1bf2
    1b8d:	11 41 70             	adc    WORD PTR [bx+di+0x70],ax
    1b90:	70 65                	jo     0x1bf7
    1b92:	6c                   	ins    BYTE PTR es:[di],dx
    1b93:	4f                   	dec    di
    1b94:	66 66 72 65          	data32 data32 jb 0x1bfd
    1b98:	50                   	push   ax
    1b99:	72 69                	jb     0x1c04
    1b9b:	78 4d                	js     0x1bea
    1b9d:	61                   	popa
    1b9e:	78 07                	js     0x1ba7
    1ba0:	53                   	push   bx
    1ba1:	70 65                	jo     0x1c08
    1ba3:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    1ba6:	6c                   	ins    BYTE PTR es:[di],dx
    1ba7:	06                   	push   es
    1ba8:	4d                   	dec    bp
    1ba9:	61                   	popa
    1baa:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    1bad:	6e                   	outs   dx,BYTE PTR ds:[si]
    1bae:	13 50 65             	adc    dx,WORD PTR [bx+si+0x65]
    1bb1:	72 69                	jb     0x1c1c
    1bb3:	6f                   	outs   dx,WORD PTR ds:[si]
    1bb4:	64 65 4e             	fs gs dec si
    1bb7:	6f                   	outs   dx,WORD PTR ds:[si]
    1bb8:	3b 50 72             	cmp    dx,WORD PTR [bx+si+0x72]
    1bbb:	6f                   	outs   dx,WORD PTR ds:[si]
    1bbc:	64 75 69             	fs jne 0x1c28
    1bbf:	74 4e                	je     0x1c0f
    1bc1:	6f                   	outs   dx,WORD PTR ds:[si]
    1bc2:	55                   	push   bp
    1bc3:	89 e5                	mov    bp,sp
    1bc5:	b8 08 00             	mov    ax,0x8
    1bc8:	9a 44 04 9b 1d       	call   0x1d9b:0x444
    1bcd:	83 ec 08             	sub    sp,0x8
    1bd0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bd3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1bd6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1bd9:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    1bdd:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1be0:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1be3:	bf db 1a             	mov    di,0x1adb
    1be6:	0e                   	push   cs
    1be7:	57                   	push   di
    1be8:	6a 03                	push   0x3
    1bea:	6a 00                	push   0x0
    1bec:	6a 00                	push   0x0
    1bee:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1bf1:	06                   	push   es
    1bf2:	57                   	push   di
    1bf3:	9a a1 2a 0b 1c       	call   0x1c0b:0x2aa1
    1bf8:	bf e5 1a             	mov    di,0x1ae5
    1bfb:	0e                   	push   cs
    1bfc:	57                   	push   di
    1bfd:	6a 03                	push   0x3
    1bff:	6a 00                	push   0x0
    1c01:	6a 00                	push   0x0
    1c03:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c06:	06                   	push   es
    1c07:	57                   	push   di
    1c08:	9a a1 2a 20 1c       	call   0x1c20:0x2aa1
    1c0d:	bf ef 1a             	mov    di,0x1aef
    1c10:	0e                   	push   cs
    1c11:	57                   	push   di
    1c12:	6a 08                	push   0x8
    1c14:	6a 02                	push   0x2
    1c16:	6a 00                	push   0x0
    1c18:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c1b:	06                   	push   es
    1c1c:	57                   	push   di
    1c1d:	9a a1 2a 35 1c       	call   0x1c35:0x2aa1
    1c22:	bf fb 1a             	mov    di,0x1afb
    1c25:	0e                   	push   cs
    1c26:	57                   	push   di
    1c27:	6a 08                	push   0x8
    1c29:	6a 02                	push   0x2
    1c2b:	6a 00                	push   0x0
    1c2d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c30:	06                   	push   es
    1c31:	57                   	push   di
    1c32:	9a a1 2a 4a 1c       	call   0x1c4a:0x2aa1
    1c37:	bf 07 1b             	mov    di,0x1b07
    1c3a:	0e                   	push   cs
    1c3b:	57                   	push   di
    1c3c:	6a 08                	push   0x8
    1c3e:	6a 02                	push   0x2
    1c40:	6a 00                	push   0x0
    1c42:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c45:	06                   	push   es
    1c46:	57                   	push   di
    1c47:	9a a1 2a 5f 1c       	call   0x1c5f:0x2aa1
    1c4c:	bf 1a 1b             	mov    di,0x1b1a
    1c4f:	0e                   	push   cs
    1c50:	57                   	push   di
    1c51:	6a 08                	push   0x8
    1c53:	6a 02                	push   0x2
    1c55:	6a 00                	push   0x0
    1c57:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c5a:	06                   	push   es
    1c5b:	57                   	push   di
    1c5c:	9a a1 2a 74 1c       	call   0x1c74:0x2aa1
    1c61:	bf 26 1b             	mov    di,0x1b26
    1c64:	0e                   	push   cs
    1c65:	57                   	push   di
    1c66:	6a 08                	push   0x8
    1c68:	6a 02                	push   0x2
    1c6a:	6a 00                	push   0x0
    1c6c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c6f:	06                   	push   es
    1c70:	57                   	push   di
    1c71:	9a a1 2a 89 1c       	call   0x1c89:0x2aa1
    1c76:	bf 30 1b             	mov    di,0x1b30
    1c79:	0e                   	push   cs
    1c7a:	57                   	push   di
    1c7b:	6a 08                	push   0x8
    1c7d:	6a 02                	push   0x2
    1c7f:	6a 00                	push   0x0
    1c81:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c84:	06                   	push   es
    1c85:	57                   	push   di
    1c86:	9a a1 2a 9e 1c       	call   0x1c9e:0x2aa1
    1c8b:	bf 3f 1b             	mov    di,0x1b3f
    1c8e:	0e                   	push   cs
    1c8f:	57                   	push   di
    1c90:	6a 08                	push   0x8
    1c92:	6a 02                	push   0x2
    1c94:	6a 00                	push   0x0
    1c96:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1c99:	06                   	push   es
    1c9a:	57                   	push   di
    1c9b:	9a a1 2a b3 1c       	call   0x1cb3:0x2aa1
    1ca0:	bf 4f 1b             	mov    di,0x1b4f
    1ca3:	0e                   	push   cs
    1ca4:	57                   	push   di
    1ca5:	6a 08                	push   0x8
    1ca7:	6a 02                	push   0x2
    1ca9:	6a 00                	push   0x0
    1cab:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1cae:	06                   	push   es
    1caf:	57                   	push   di
    1cb0:	9a a1 2a c8 1c       	call   0x1cc8:0x2aa1
    1cb5:	bf 5b 1b             	mov    di,0x1b5b
    1cb8:	0e                   	push   cs
    1cb9:	57                   	push   di
    1cba:	6a 08                	push   0x8
    1cbc:	6a 02                	push   0x2
    1cbe:	6a 00                	push   0x0
    1cc0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1cc3:	06                   	push   es
    1cc4:	57                   	push   di
    1cc5:	9a a1 2a dd 1c       	call   0x1cdd:0x2aa1
    1cca:	bf 68 1b             	mov    di,0x1b68
    1ccd:	0e                   	push   cs
    1cce:	57                   	push   di
    1ccf:	6a 08                	push   0x8
    1cd1:	6a 02                	push   0x2
    1cd3:	6a 00                	push   0x0
    1cd5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1cd8:	06                   	push   es
    1cd9:	57                   	push   di
    1cda:	9a a1 2a f2 1c       	call   0x1cf2:0x2aa1
    1cdf:	bf 7a 1b             	mov    di,0x1b7a
    1ce2:	0e                   	push   cs
    1ce3:	57                   	push   di
    1ce4:	6a 03                	push   0x3
    1ce6:	6a 00                	push   0x0
    1ce8:	6a 00                	push   0x0
    1cea:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ced:	06                   	push   es
    1cee:	57                   	push   di
    1cef:	9a a1 2a 07 1d       	call   0x1d07:0x2aa1
    1cf4:	bf 8d 1b             	mov    di,0x1b8d
    1cf7:	0e                   	push   cs
    1cf8:	57                   	push   di
    1cf9:	6a 08                	push   0x8
    1cfb:	6a 02                	push   0x2
    1cfd:	6a 00                	push   0x0
    1cff:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d02:	06                   	push   es
    1d03:	57                   	push   di
    1d04:	9a a1 2a 1c 1d       	call   0x1d1c:0x2aa1
    1d09:	bf 9f 1b             	mov    di,0x1b9f
    1d0c:	0e                   	push   cs
    1d0d:	57                   	push   di
    1d0e:	6a 03                	push   0x3
    1d10:	6a 00                	push   0x0
    1d12:	6a 00                	push   0x0
    1d14:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d17:	06                   	push   es
    1d18:	57                   	push   di
    1d19:	9a a1 2a 0e 1f       	call   0x1f0e:0x2aa1
    1d1e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1d21:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    1d26:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1d29:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1d2c:	bf a7 1b             	mov    di,0x1ba7
    1d2f:	0e                   	push   cs
    1d30:	57                   	push   di
    1d31:	bf ae 1b             	mov    di,0x1bae
    1d34:	0e                   	push   cs
    1d35:	57                   	push   di
    1d36:	6a 03                	push   0x3
    1d38:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d3b:	06                   	push   es
    1d3c:	57                   	push   di
    1d3d:	9a f6 18 df 1d       	call   0x1ddf:0x18f6
    1d42:	c9                   	leave
    1d43:	ca 04 00             	retf   0x4
    1d46:	00 00                	add    BYTE PTR [bx+si],al
    1d48:	90                   	nop
    1d49:	40                   	inc    ax
    1d4a:	00 00                	add    BYTE PTR [bx+si],al
    1d4c:	00 3f                	add    BYTE PTR [bx],bh
    1d4e:	00 00                	add    BYTE PTR [bx+si],al
    1d50:	80 3e 9a 99 99       	cmp    BYTE PTR ds:0x999a,0x99
    1d55:	99                   	cwd
    1d56:	99                   	cwd
    1d57:	99                   	cwd
    1d58:	99                   	cwd
    1d59:	99                   	cwd
    1d5a:	fe                   	(bad)
    1d5b:	3f                   	aas
    1d5c:	00 00                	add    BYTE PTR [bx+si],al
    1d5e:	b7 42                	mov    bh,0x42
    1d60:	cd cc                	int    0xcc
    1d62:	cc                   	int3
    1d63:	cc                   	int3
    1d64:	cc                   	int3
    1d65:	cc                   	int3
    1d66:	cc                   	int3
    1d67:	cc                   	int3
    1d68:	fb                   	sti
    1d69:	3f                   	aas
    1d6a:	9a 99 99 99 99       	call   0x9999:0x9999
    1d6f:	99                   	cwd
    1d70:	99                   	cwd
    1d71:	99                   	cwd
    1d72:	fc                   	cld
    1d73:	3f                   	aas
    1d74:	cd cc                	int    0xcc
    1d76:	cc                   	int3
    1d77:	cc                   	int3
    1d78:	cc                   	int3
    1d79:	cc                   	int3
    1d7a:	cc                   	int3
    1d7b:	cc                   	int3
    1d7c:	fc                   	cld
    1d7d:	3f                   	aas
    1d7e:	33 33                	xor    si,WORD PTR [bp+di]
    1d80:	33 33                	xor    si,WORD PTR [bp+di]
    1d82:	33 33                	xor    si,WORD PTR [bp+di]
    1d84:	33 b3 fd 3f          	xor    si,WORD PTR [bp+di+0x3ffd]
    1d88:	cd cc                	int    0xcc
    1d8a:	cc                   	int3
    1d8b:	cc                   	int3
    1d8c:	cc                   	int3
    1d8d:	cc                   	int3
    1d8e:	cc                   	int3
    1d8f:	cc                   	int3
    1d90:	fd                   	std
    1d91:	3f                   	aas
    1d92:	55                   	push   bp
    1d93:	89 e5                	mov    bp,sp
    1d95:	b8 d6 00             	mov    ax,0xd6
    1d98:	9a 44 04 a4 20       	call   0x20a4:0x444
    1d9d:	81 ec d6 00          	sub    sp,0xd6
    1da1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1da4:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1da7:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1daa:	31 c0                	xor    ax,ax
    1dac:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1daf:	eb 03                	jmp    0x1db4
    1db1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1db4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1db7:	99                   	cwd
    1db8:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    1dbb:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    1dbe:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    1dc2:	c7 46 f0 01 00       	mov    WORD PTR [bp-0x10],0x1
    1dc7:	c7 46 f2 00 00       	mov    WORD PTR [bp-0xe],0x0
    1dcc:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    1dd0:	8d 7e e8             	lea    di,[bp-0x18]
    1dd3:	16                   	push   ss
    1dd4:	57                   	push   di
    1dd5:	6a 01                	push   0x1
    1dd7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1dda:	06                   	push   es
    1ddb:	57                   	push   di
    1ddc:	9a 95 28 3b 1f       	call   0x1f3b:0x2895
    1de1:	08 c0                	or     al,al
    1de3:	74 03                	je     0x1de8
    1de5:	e9 28 01             	jmp    0x1f10
    1de8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1deb:	99                   	cwd
    1dec:	89 86 3e ff          	mov    WORD PTR [bp-0xc2],ax
    1df0:	89 96 40 ff          	mov    WORD PTR [bp-0xc0],dx
    1df4:	c6 86 42 ff 00       	mov    BYTE PTR [bp-0xbe],0x0
    1df9:	c7 86 46 ff 01 00    	mov    WORD PTR [bp-0xba],0x1
    1dff:	c7 86 48 ff 00 00    	mov    WORD PTR [bp-0xb8],0x0
    1e05:	c6 86 4a ff 00       	mov    BYTE PTR [bp-0xb6],0x0
    1e0a:	c7 86 4e ff 08 00    	mov    WORD PTR [bp-0xb2],0x8
    1e10:	c7 86 50 ff 00 00    	mov    WORD PTR [bp-0xb0],0x0
    1e16:	c6 86 52 ff 00       	mov    BYTE PTR [bp-0xae],0x0
    1e1b:	c7 86 56 ff 0f 00    	mov    WORD PTR [bp-0xaa],0xf
    1e21:	c7 86 58 ff 00 00    	mov    WORD PTR [bp-0xa8],0x0
    1e27:	c6 86 5a ff 00       	mov    BYTE PTR [bp-0xa6],0x0
    1e2c:	31 c0                	xor    ax,ax
    1e2e:	89 86 5e ff          	mov    WORD PTR [bp-0xa2],ax
    1e32:	89 86 60 ff          	mov    WORD PTR [bp-0xa0],ax
    1e36:	c6 86 62 ff 00       	mov    BYTE PTR [bp-0x9e],0x0
    1e3b:	9b 2e d9 06 46 1d    	fld    DWORD PTR cs:0x1d46
    1e41:	9b db 7e de          	fstp   TBYTE PTR [bp-0x22]
    1e45:	8d 46 de             	lea    ax,[bp-0x22]
    1e48:	8c d2                	mov    dx,ss
    1e4a:	89 86 66 ff          	mov    WORD PTR [bp-0x9a],ax
    1e4e:	89 96 68 ff          	mov    WORD PTR [bp-0x98],dx
    1e52:	c6 86 6a ff 03       	mov    BYTE PTR [bp-0x96],0x3
    1e57:	9b 2e d9 06 4a 1d    	fld    DWORD PTR cs:0x1d4a
    1e5d:	9b db 7e d4          	fstp   TBYTE PTR [bp-0x2c]
    1e61:	8d 46 d4             	lea    ax,[bp-0x2c]
    1e64:	8c d2                	mov    dx,ss
    1e66:	89 86 6e ff          	mov    WORD PTR [bp-0x92],ax
    1e6a:	89 96 70 ff          	mov    WORD PTR [bp-0x90],dx
    1e6e:	c6 86 72 ff 03       	mov    BYTE PTR [bp-0x8e],0x3
    1e73:	9b 2e d9 06 4e 1d    	fld    DWORD PTR cs:0x1d4e
    1e79:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    1e7d:	8d 46 ca             	lea    ax,[bp-0x36]
    1e80:	8c d2                	mov    dx,ss
    1e82:	89 86 76 ff          	mov    WORD PTR [bp-0x8a],ax
    1e86:	89 96 78 ff          	mov    WORD PTR [bp-0x88],dx
    1e8a:	c6 86 7a ff 03       	mov    BYTE PTR [bp-0x86],0x3
    1e8f:	9b 2e d9 06 4e 1d    	fld    DWORD PTR cs:0x1d4e
    1e95:	9b db 7e c0          	fstp   TBYTE PTR [bp-0x40]
    1e99:	8d 46 c0             	lea    ax,[bp-0x40]
    1e9c:	8c d2                	mov    dx,ss
    1e9e:	89 86 7e ff          	mov    WORD PTR [bp-0x82],ax
    1ea2:	89 56 80             	mov    WORD PTR [bp-0x80],dx
    1ea5:	c6 46 82 03          	mov    BYTE PTR [bp-0x7e],0x3
    1ea9:	31 c0                	xor    ax,ax
    1eab:	89 46 86             	mov    WORD PTR [bp-0x7a],ax
    1eae:	89 46 88             	mov    WORD PTR [bp-0x78],ax
    1eb1:	c6 46 8a 00          	mov    BYTE PTR [bp-0x76],0x0
    1eb5:	31 c0                	xor    ax,ax
    1eb7:	89 46 8e             	mov    WORD PTR [bp-0x72],ax
    1eba:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    1ebd:	c6 46 92 00          	mov    BYTE PTR [bp-0x6e],0x0
    1ec1:	9b 2e db 2e 52 1d    	fld    TBYTE PTR cs:0x1d52
    1ec7:	9b db 7e b6          	fstp   TBYTE PTR [bp-0x4a]
    1ecb:	8d 46 b6             	lea    ax,[bp-0x4a]
    1ece:	8c d2                	mov    dx,ss
    1ed0:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    1ed3:	89 56 98             	mov    WORD PTR [bp-0x68],dx
    1ed6:	c6 46 9a 03          	mov    BYTE PTR [bp-0x66],0x3
    1eda:	31 c0                	xor    ax,ax
    1edc:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    1edf:	89 46 a0             	mov    WORD PTR [bp-0x60],ax
    1ee2:	c6 46 a2 00          	mov    BYTE PTR [bp-0x5e],0x0
    1ee6:	31 c0                	xor    ax,ax
    1ee8:	89 46 a6             	mov    WORD PTR [bp-0x5a],ax
    1eeb:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    1eee:	c6 46 aa 00          	mov    BYTE PTR [bp-0x56],0x0
    1ef2:	31 c0                	xor    ax,ax
    1ef4:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    1ef7:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    1efa:	c6 46 b2 00          	mov    BYTE PTR [bp-0x4e],0x0
    1efe:	8d be 3e ff          	lea    di,[bp-0xc2]
    1f02:	16                   	push   ss
    1f03:	57                   	push   di
    1f04:	6a 0e                	push   0xe
    1f06:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1f09:	06                   	push   es
    1f0a:	57                   	push   di
    1f0b:	9a 21 53 8c 20       	call   0x208c:0x5321
    1f10:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f13:	99                   	cwd
    1f14:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    1f17:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    1f1a:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    1f1e:	c7 46 f0 02 00       	mov    WORD PTR [bp-0x10],0x2
    1f23:	c7 46 f2 00 00       	mov    WORD PTR [bp-0xe],0x0
    1f28:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    1f2c:	8d 7e e8             	lea    di,[bp-0x18]
    1f2f:	16                   	push   ss
    1f30:	57                   	push   di
    1f31:	6a 01                	push   0x1
    1f33:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1f36:	06                   	push   es
    1f37:	57                   	push   di
    1f38:	9a 95 28 e8 20       	call   0x20e8:0x2895
    1f3d:	08 c0                	or     al,al
    1f3f:	74 03                	je     0x1f44
    1f41:	e9 4a 01             	jmp    0x208e
    1f44:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f47:	99                   	cwd
    1f48:	89 86 2a ff          	mov    WORD PTR [bp-0xd6],ax
    1f4c:	89 96 2c ff          	mov    WORD PTR [bp-0xd4],dx
    1f50:	c6 86 2e ff 00       	mov    BYTE PTR [bp-0xd2],0x0
    1f55:	c7 86 32 ff 02 00    	mov    WORD PTR [bp-0xce],0x2
    1f5b:	c7 86 34 ff 00 00    	mov    WORD PTR [bp-0xcc],0x0
    1f61:	c6 86 36 ff 00       	mov    BYTE PTR [bp-0xca],0x0
    1f66:	c7 86 3a ff af 00    	mov    WORD PTR [bp-0xc6],0xaf
    1f6c:	c7 86 3c ff 00 00    	mov    WORD PTR [bp-0xc4],0x0
    1f72:	c6 86 3e ff 00       	mov    BYTE PTR [bp-0xc2],0x0
    1f77:	c7 86 42 ff 77 01    	mov    WORD PTR [bp-0xbe],0x177
    1f7d:	c7 86 44 ff 00 00    	mov    WORD PTR [bp-0xbc],0x0
    1f83:	c6 86 46 ff 00       	mov    BYTE PTR [bp-0xba],0x0
    1f88:	31 c0                	xor    ax,ax
    1f8a:	89 86 4a ff          	mov    WORD PTR [bp-0xb6],ax
    1f8e:	89 86 4c ff          	mov    WORD PTR [bp-0xb4],ax
    1f92:	c6 86 4e ff 00       	mov    BYTE PTR [bp-0xb2],0x0
    1f97:	9b 2e d9 06 5c 1d    	fld    DWORD PTR cs:0x1d5c
    1f9d:	9b db 7e de          	fstp   TBYTE PTR [bp-0x22]
    1fa1:	8d 46 de             	lea    ax,[bp-0x22]
    1fa4:	8c d2                	mov    dx,ss
    1fa6:	89 86 52 ff          	mov    WORD PTR [bp-0xae],ax
    1faa:	89 96 54 ff          	mov    WORD PTR [bp-0xac],dx
    1fae:	c6 86 56 ff 03       	mov    BYTE PTR [bp-0xaa],0x3
    1fb3:	9b 2e db 2e 60 1d    	fld    TBYTE PTR cs:0x1d60
    1fb9:	9b db 7e d4          	fstp   TBYTE PTR [bp-0x2c]
    1fbd:	8d 46 d4             	lea    ax,[bp-0x2c]
    1fc0:	8c d2                	mov    dx,ss
    1fc2:	89 86 5a ff          	mov    WORD PTR [bp-0xa6],ax
    1fc6:	89 96 5c ff          	mov    WORD PTR [bp-0xa4],dx
    1fca:	c6 86 5e ff 03       	mov    BYTE PTR [bp-0xa2],0x3
    1fcf:	9b 2e db 2e 6a 1d    	fld    TBYTE PTR cs:0x1d6a
    1fd5:	9b db 7e ca          	fstp   TBYTE PTR [bp-0x36]
    1fd9:	8d 46 ca             	lea    ax,[bp-0x36]
    1fdc:	8c d2                	mov    dx,ss
    1fde:	89 86 62 ff          	mov    WORD PTR [bp-0x9e],ax
    1fe2:	89 96 64 ff          	mov    WORD PTR [bp-0x9c],dx
    1fe6:	c6 86 66 ff 03       	mov    BYTE PTR [bp-0x9a],0x3
    1feb:	9b 2e db 2e 74 1d    	fld    TBYTE PTR cs:0x1d74
    1ff1:	9b db 7e c0          	fstp   TBYTE PTR [bp-0x40]
    1ff5:	8d 46 c0             	lea    ax,[bp-0x40]
    1ff8:	8c d2                	mov    dx,ss
    1ffa:	89 86 6a ff          	mov    WORD PTR [bp-0x96],ax
    1ffe:	89 96 6c ff          	mov    WORD PTR [bp-0x94],dx
    2002:	c6 86 6e ff 03       	mov    BYTE PTR [bp-0x92],0x3
    2007:	9b 2e db 2e 74 1d    	fld    TBYTE PTR cs:0x1d74
    200d:	9b db 7e b6          	fstp   TBYTE PTR [bp-0x4a]
    2011:	8d 46 b6             	lea    ax,[bp-0x4a]
    2014:	8c d2                	mov    dx,ss
    2016:	89 86 72 ff          	mov    WORD PTR [bp-0x8e],ax
    201a:	89 96 74 ff          	mov    WORD PTR [bp-0x8c],dx
    201e:	c6 86 76 ff 03       	mov    BYTE PTR [bp-0x8a],0x3
    2023:	9b 2e db 2e 7e 1d    	fld    TBYTE PTR cs:0x1d7e
    2029:	9b db 7e ac          	fstp   TBYTE PTR [bp-0x54]
    202d:	8d 46 ac             	lea    ax,[bp-0x54]
    2030:	8c d2                	mov    dx,ss
    2032:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    2036:	89 96 7c ff          	mov    WORD PTR [bp-0x84],dx
    203a:	c6 86 7e ff 03       	mov    BYTE PTR [bp-0x82],0x3
    203f:	9b 2e db 2e 88 1d    	fld    TBYTE PTR cs:0x1d88
    2045:	9b db 7e a2          	fstp   TBYTE PTR [bp-0x5e]
    2049:	8d 46 a2             	lea    ax,[bp-0x5e]
    204c:	8c d2                	mov    dx,ss
    204e:	89 46 82             	mov    WORD PTR [bp-0x7e],ax
    2051:	89 56 84             	mov    WORD PTR [bp-0x7c],dx
    2054:	c6 46 86 03          	mov    BYTE PTR [bp-0x7a],0x3
    2058:	31 c0                	xor    ax,ax
    205a:	89 46 8a             	mov    WORD PTR [bp-0x76],ax
    205d:	89 46 8c             	mov    WORD PTR [bp-0x74],ax
    2060:	c6 46 8e 00          	mov    BYTE PTR [bp-0x72],0x0
    2064:	31 c0                	xor    ax,ax
    2066:	89 46 92             	mov    WORD PTR [bp-0x6e],ax
    2069:	89 46 94             	mov    WORD PTR [bp-0x6c],ax
    206c:	c6 46 96 00          	mov    BYTE PTR [bp-0x6a],0x0
    2070:	31 c0                	xor    ax,ax
    2072:	89 46 9a             	mov    WORD PTR [bp-0x66],ax
    2075:	89 46 9c             	mov    WORD PTR [bp-0x64],ax
    2078:	c6 46 9e 00          	mov    BYTE PTR [bp-0x62],0x0
    207c:	8d be 2a ff          	lea    di,[bp-0xd6]
    2080:	16                   	push   ss
    2081:	57                   	push   di
    2082:	6a 0e                	push   0xe
    2084:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2087:	06                   	push   es
    2088:	57                   	push   di
    2089:	9a 21 53 bf 21       	call   0x21bf:0x5321
    208e:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    2092:	74 03                	je     0x2097
    2094:	e9 1a fd             	jmp    0x1db1
    2097:	c9                   	leave
    2098:	ca 04 00             	retf   0x4
    209b:	55                   	push   bp
    209c:	89 e5                	mov    bp,sp
    209e:	b8 8e 00             	mov    ax,0x8e
    20a1:	9a 44 04 ed 22       	call   0x22ed:0x444
    20a6:	81 ec 8e 00          	sub    sp,0x8e
    20aa:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    20ad:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    20b0:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    20b3:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    20b8:	eb 03                	jmp    0x20bd
    20ba:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    20bd:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    20c0:	99                   	cwd
    20c1:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    20c4:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    20c7:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    20cb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    20ce:	99                   	cwd
    20cf:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    20d2:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    20d5:	c6 46 f6 00          	mov    BYTE PTR [bp-0xa],0x0
    20d9:	8d 7e ea             	lea    di,[bp-0x16]
    20dc:	16                   	push   ss
    20dd:	57                   	push   di
    20de:	6a 01                	push   0x1
    20e0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    20e3:	06                   	push   es
    20e4:	57                   	push   di
    20e5:	9a 95 28 a1 24       	call   0x24a1:0x2895
    20ea:	08 c0                	or     al,al
    20ec:	74 03                	je     0x20f1
    20ee:	e9 d0 00             	jmp    0x21c1
    20f1:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    20f4:	99                   	cwd
    20f5:	89 86 72 ff          	mov    WORD PTR [bp-0x8e],ax
    20f9:	89 96 74 ff          	mov    WORD PTR [bp-0x8c],dx
    20fd:	c6 86 76 ff 00       	mov    BYTE PTR [bp-0x8a],0x0
    2102:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2105:	99                   	cwd
    2106:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    210a:	89 96 7c ff          	mov    WORD PTR [bp-0x84],dx
    210e:	c6 86 7e ff 00       	mov    BYTE PTR [bp-0x82],0x0
    2113:	31 c0                	xor    ax,ax
    2115:	89 46 82             	mov    WORD PTR [bp-0x7e],ax
    2118:	89 46 84             	mov    WORD PTR [bp-0x7c],ax
    211b:	c6 46 86 00          	mov    BYTE PTR [bp-0x7a],0x0
    211f:	31 c0                	xor    ax,ax
    2121:	89 46 8a             	mov    WORD PTR [bp-0x76],ax
    2124:	89 46 8c             	mov    WORD PTR [bp-0x74],ax
    2127:	c6 46 8e 00          	mov    BYTE PTR [bp-0x72],0x0
    212b:	31 c0                	xor    ax,ax
    212d:	89 46 92             	mov    WORD PTR [bp-0x6e],ax
    2130:	89 46 94             	mov    WORD PTR [bp-0x6c],ax
    2133:	c6 46 96 00          	mov    BYTE PTR [bp-0x6a],0x0
    2137:	31 c0                	xor    ax,ax
    2139:	89 46 9a             	mov    WORD PTR [bp-0x66],ax
    213c:	89 46 9c             	mov    WORD PTR [bp-0x64],ax
    213f:	c6 46 9e 00          	mov    BYTE PTR [bp-0x62],0x0
    2143:	31 c0                	xor    ax,ax
    2145:	89 46 a2             	mov    WORD PTR [bp-0x5e],ax
    2148:	89 46 a4             	mov    WORD PTR [bp-0x5c],ax
    214b:	c6 46 a6 00          	mov    BYTE PTR [bp-0x5a],0x0
    214f:	31 c0                	xor    ax,ax
    2151:	89 46 aa             	mov    WORD PTR [bp-0x56],ax
    2154:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    2157:	c6 46 ae 00          	mov    BYTE PTR [bp-0x52],0x0
    215b:	31 c0                	xor    ax,ax
    215d:	89 46 b2             	mov    WORD PTR [bp-0x4e],ax
    2160:	89 46 b4             	mov    WORD PTR [bp-0x4c],ax
    2163:	c6 46 b6 00          	mov    BYTE PTR [bp-0x4a],0x0
    2167:	31 c0                	xor    ax,ax
    2169:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    216c:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    216f:	c6 46 be 00          	mov    BYTE PTR [bp-0x42],0x0
    2173:	31 c0                	xor    ax,ax
    2175:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    2178:	89 46 c4             	mov    WORD PTR [bp-0x3c],ax
    217b:	c6 46 c6 00          	mov    BYTE PTR [bp-0x3a],0x0
    217f:	31 c0                	xor    ax,ax
    2181:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    2184:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    2187:	c6 46 ce 00          	mov    BYTE PTR [bp-0x32],0x0
    218b:	31 c0                	xor    ax,ax
    218d:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    2190:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    2193:	c6 46 d6 00          	mov    BYTE PTR [bp-0x2a],0x0
    2197:	31 c0                	xor    ax,ax
    2199:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    219c:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    219f:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    21a3:	31 c0                	xor    ax,ax
    21a5:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    21a8:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    21ab:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    21af:	8d be 72 ff          	lea    di,[bp-0x8e]
    21b3:	16                   	push   ss
    21b4:	57                   	push   di
    21b5:	6a 0e                	push   0xe
    21b7:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    21ba:	06                   	push   es
    21bb:	57                   	push   di
    21bc:	9a 21 53 18 23       	call   0x2318:0x5321
    21c1:	83 7e fe 02          	cmp    WORD PTR [bp-0x2],0x2
    21c5:	74 03                	je     0x21ca
    21c7:	e9 f0 fe             	jmp    0x20ba
    21ca:	c9                   	leave
    21cb:	ca 06 00             	retf   0x6
    21ce:	09 50 65             	or     WORD PTR [bx+si+0x65],dx
    21d1:	72 69                	jb     0x223c
    21d3:	6f                   	outs   dx,WORD PTR ds:[si]
    21d4:	64 65 4e             	fs gs dec si
    21d7:	6f                   	outs   dx,WORD PTR ds:[si]
    21d8:	0c 45                	or     al,0x45
    21da:	6e                   	outs   dx,BYTE PTR ds:[si]
    21db:	74 72                	je     0x224f
    21dd:	65 70 72             	gs jo  0x2252
    21e0:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    21e5:	10 56 61             	adc    BYTE PTR [bp+0x61],dl
    21e8:	72 69                	jb     0x2253
    21ea:	61                   	popa
    21eb:	74 69                	je     0x2256
    21ed:	6f                   	outs   dx,WORD PTR ds:[si]
    21ee:	6e                   	outs   dx,BYTE PTR ds:[si]
    21ef:	43                   	inc    bx
    21f0:	61                   	popa
    21f1:	70 69                	jo     0x225c
    21f3:	74 61                	je     0x2256
    21f5:	6c                   	ins    BYTE PTR es:[di],dx
    21f6:	0a 44 69             	or     al,BYTE PTR [si+0x69]
    21f9:	76 69                	jbe    0x2264
    21fb:	64 65 6e             	fs outs dx,BYTE PTR gs:[si]
    21fe:	64 65 73 10          	fs gs jae 0x2212
    2202:	56                   	push   si
    2203:	61                   	popa
    2204:	72 69                	jb     0x226f
    2206:	61                   	popa
    2207:	74 69                	je     0x2272
    2209:	6f                   	outs   dx,WORD PTR ds:[si]
    220a:	6e                   	outs   dx,BYTE PTR ds:[si]
    220b:	45                   	inc    bp
    220c:	6d                   	ins    WORD PTR es:[di],dx
    220d:	70 72                	jo     0x2281
    220f:	75 6e                	jne    0x227f
    2211:	74 0b                	je     0x221e
    2213:	53                   	push   bx
    2214:	75 62                	jne    0x2278
    2216:	76 65                	jbe    0x227d
    2218:	6e                   	outs   dx,BYTE PTR ds:[si]
    2219:	74 69                	je     0x2284
    221b:	6f                   	outs   dx,WORD PTR ds:[si]
    221c:	6e                   	outs   dx,BYTE PTR ds:[si]
    221d:	73 13                	jae    0x2232
    221f:	50                   	push   ax
    2220:	72 6f                	jb     0x2291
    2222:	64 75 69             	fs jne 0x228e
    2225:	74 73                	je     0x229a
    2227:	4f                   	dec    di
    2228:	75 43                	jne    0x226d
    222a:	68 61 72             	push   0x7261
    222d:	67 65 73 45          	addr32 gs jae 0x2276
    2231:	78 0d                	js     0x2240
    2233:	41                   	inc    cx
    2234:	63 68 61             	arpl   WORD PTR [bx+si+0x61],bp
    2237:	74 4d                	je     0x2286
    2239:	61                   	popa
    223a:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    223d:	6e                   	outs   dx,BYTE PTR ds:[si]
    223e:	65 73 0d             	gs jae 0x224e
    2241:	56                   	push   si
    2242:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2244:	74 65                	je     0x22ab
    2246:	4d                   	dec    bp
    2247:	61                   	popa
    2248:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    224b:	6e                   	outs   dx,BYTE PTR ds:[si]
    224c:	65 73 13             	gs jae 0x2262
    224f:	45                   	inc    bp
    2250:	6e                   	outs   dx,BYTE PTR ds:[si]
    2251:	74 72                	je     0x22c5
    2253:	65 74 69             	gs je  0x22bf
    2256:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2258:	4d                   	dec    bp
    2259:	61                   	popa
    225a:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    225d:	6e                   	outs   dx,BYTE PTR ds:[si]
    225e:	65 73 50             	gs jae 0x22b1
    2261:	63 0f                	arpl   WORD PTR [bx],cx
    2263:	43                   	inc    bx
    2264:	61                   	popa
    2265:	64 72 65             	fs jb  0x22cd
    2268:	73 45                	jae    0x22af
    226a:	6d                   	ins    WORD PTR es:[di],dx
    226b:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    226e:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    2271:	73 0f                	jae    0x2282
    2273:	43                   	inc    bx
    2274:	61                   	popa
    2275:	64 72 65             	fs jb  0x22dd
    2278:	73 4c                	jae    0x22c6
    227a:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    227f:	69 65 73 0e 49       	imul   sp,WORD PTR [di+0x73],0x490e
    2284:	6e                   	outs   dx,BYTE PTR ds:[si]
    2285:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    228b:	6c                   	ins    BYTE PTR es:[di],dx
    228c:	61                   	popa
    228d:	69 72 65 73 0e       	imul   si,WORD PTR [bp+si+0x65],0xe73
    2292:	43                   	inc    bx
    2293:	6f                   	outs   dx,WORD PTR ds:[si]
    2294:	6d                   	ins    WORD PTR es:[di],dx
    2295:	6d                   	ins    WORD PTR es:[di],dx
    2296:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    229b:	6e                   	outs   dx,BYTE PTR ds:[si]
    229c:	46                   	inc    si
    229d:	56                   	push   si
    229e:	50                   	push   ax
    229f:	63 0b                	arpl   WORD PTR [bp+di],cx
    22a1:	46                   	inc    si
    22a2:	6f                   	outs   dx,WORD PTR ds:[si]
    22a3:	72 6d                	jb     0x2312
    22a5:	61                   	popa
    22a6:	74 69                	je     0x2311
    22a8:	6f                   	outs   dx,WORD PTR ds:[si]
    22a9:	6e                   	outs   dx,BYTE PTR ds:[si]
    22aa:	50                   	push   ax
    22ab:	63 06 45 74          	arpl   WORD PTR ds:0x7445,ax
    22af:	75 64                	jne    0x2315
    22b1:	65 73 0a             	gs jae 0x22be
    22b4:	56                   	push   si
    22b5:	61                   	popa
    22b6:	6c                   	ins    BYTE PTR es:[di],dx
    22b7:	69 64 61 74 69       	imul   sp,WORD PTR [si+0x61],0x6974
    22bc:	6f                   	outs   dx,WORD PTR ds:[si]
    22bd:	6e                   	outs   dx,BYTE PTR ds:[si]
    22be:	07                   	pop    es
    22bf:	53                   	push   bx
    22c0:	70 65                	jo     0x2327
    22c2:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    22c5:	6c                   	ins    BYTE PTR es:[di],dx
    22c6:	06                   	push   es
    22c7:	4d                   	dec    bp
    22c8:	61                   	popa
    22c9:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    22cc:	6e                   	outs   dx,BYTE PTR ds:[si]
    22cd:	16                   	push   ss
    22ce:	50                   	push   ax
    22cf:	65 72 69             	gs jb  0x233b
    22d2:	6f                   	outs   dx,WORD PTR ds:[si]
    22d3:	64 65 4e             	fs gs dec si
    22d6:	6f                   	outs   dx,WORD PTR ds:[si]
    22d7:	3b 45 6e             	cmp    ax,WORD PTR [di+0x6e]
    22da:	74 72                	je     0x234e
    22dc:	65 70 72             	gs jo  0x2351
    22df:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    22e4:	55                   	push   bp
    22e5:	89 e5                	mov    bp,sp
    22e7:	b8 08 00             	mov    ax,0x8
    22ea:	9a 44 04 b0 24       	call   0x24b0:0x444
    22ef:	83 ec 08             	sub    sp,0x8
    22f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22f5:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    22f8:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    22fb:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    22ff:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2302:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2305:	bf ce 21             	mov    di,0x21ce
    2308:	0e                   	push   cs
    2309:	57                   	push   di
    230a:	6a 03                	push   0x3
    230c:	6a 00                	push   0x0
    230e:	6a 00                	push   0x0
    2310:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2313:	06                   	push   es
    2314:	57                   	push   di
    2315:	9a a1 2a 2d 23       	call   0x232d:0x2aa1
    231a:	bf d8 21             	mov    di,0x21d8
    231d:	0e                   	push   cs
    231e:	57                   	push   di
    231f:	6a 03                	push   0x3
    2321:	6a 00                	push   0x0
    2323:	6a 00                	push   0x0
    2325:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2328:	06                   	push   es
    2329:	57                   	push   di
    232a:	9a a1 2a 42 23       	call   0x2342:0x2aa1
    232f:	bf e5 21             	mov    di,0x21e5
    2332:	0e                   	push   cs
    2333:	57                   	push   di
    2334:	6a 08                	push   0x8
    2336:	6a 02                	push   0x2
    2338:	6a 00                	push   0x0
    233a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    233d:	06                   	push   es
    233e:	57                   	push   di
    233f:	9a a1 2a 57 23       	call   0x2357:0x2aa1
    2344:	bf f6 21             	mov    di,0x21f6
    2347:	0e                   	push   cs
    2348:	57                   	push   di
    2349:	6a 08                	push   0x8
    234b:	6a 02                	push   0x2
    234d:	6a 00                	push   0x0
    234f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2352:	06                   	push   es
    2353:	57                   	push   di
    2354:	9a a1 2a 6c 23       	call   0x236c:0x2aa1
    2359:	bf 01 22             	mov    di,0x2201
    235c:	0e                   	push   cs
    235d:	57                   	push   di
    235e:	6a 08                	push   0x8
    2360:	6a 02                	push   0x2
    2362:	6a 00                	push   0x0
    2364:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2367:	06                   	push   es
    2368:	57                   	push   di
    2369:	9a a1 2a 81 23       	call   0x2381:0x2aa1
    236e:	bf 12 22             	mov    di,0x2212
    2371:	0e                   	push   cs
    2372:	57                   	push   di
    2373:	6a 08                	push   0x8
    2375:	6a 02                	push   0x2
    2377:	6a 00                	push   0x0
    2379:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    237c:	06                   	push   es
    237d:	57                   	push   di
    237e:	9a a1 2a 96 23       	call   0x2396:0x2aa1
    2383:	bf 1e 22             	mov    di,0x221e
    2386:	0e                   	push   cs
    2387:	57                   	push   di
    2388:	6a 08                	push   0x8
    238a:	6a 02                	push   0x2
    238c:	6a 00                	push   0x0
    238e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2391:	06                   	push   es
    2392:	57                   	push   di
    2393:	9a a1 2a ab 23       	call   0x23ab:0x2aa1
    2398:	bf 32 22             	mov    di,0x2232
    239b:	0e                   	push   cs
    239c:	57                   	push   di
    239d:	6a 03                	push   0x3
    239f:	6a 00                	push   0x0
    23a1:	6a 00                	push   0x0
    23a3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23a6:	06                   	push   es
    23a7:	57                   	push   di
    23a8:	9a a1 2a c0 23       	call   0x23c0:0x2aa1
    23ad:	bf 40 22             	mov    di,0x2240
    23b0:	0e                   	push   cs
    23b1:	57                   	push   di
    23b2:	6a 03                	push   0x3
    23b4:	6a 00                	push   0x0
    23b6:	6a 00                	push   0x0
    23b8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23bb:	06                   	push   es
    23bc:	57                   	push   di
    23bd:	9a a1 2a d5 23       	call   0x23d5:0x2aa1
    23c2:	bf 4e 22             	mov    di,0x224e
    23c5:	0e                   	push   cs
    23c6:	57                   	push   di
    23c7:	6a 08                	push   0x8
    23c9:	6a 02                	push   0x2
    23cb:	6a 00                	push   0x0
    23cd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23d0:	06                   	push   es
    23d1:	57                   	push   di
    23d2:	9a a1 2a ea 23       	call   0x23ea:0x2aa1
    23d7:	bf 62 22             	mov    di,0x2262
    23da:	0e                   	push   cs
    23db:	57                   	push   di
    23dc:	6a 03                	push   0x3
    23de:	6a 00                	push   0x0
    23e0:	6a 00                	push   0x0
    23e2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23e5:	06                   	push   es
    23e6:	57                   	push   di
    23e7:	9a a1 2a ff 23       	call   0x23ff:0x2aa1
    23ec:	bf 72 22             	mov    di,0x2272
    23ef:	0e                   	push   cs
    23f0:	57                   	push   di
    23f1:	6a 03                	push   0x3
    23f3:	6a 00                	push   0x0
    23f5:	6a 00                	push   0x0
    23f7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    23fa:	06                   	push   es
    23fb:	57                   	push   di
    23fc:	9a a1 2a 14 24       	call   0x2414:0x2aa1
    2401:	bf 82 22             	mov    di,0x2282
    2404:	0e                   	push   cs
    2405:	57                   	push   di
    2406:	6a 08                	push   0x8
    2408:	6a 02                	push   0x2
    240a:	6a 00                	push   0x0
    240c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    240f:	06                   	push   es
    2410:	57                   	push   di
    2411:	9a a1 2a 29 24       	call   0x2429:0x2aa1
    2416:	bf 91 22             	mov    di,0x2291
    2419:	0e                   	push   cs
    241a:	57                   	push   di
    241b:	6a 08                	push   0x8
    241d:	6a 02                	push   0x2
    241f:	6a 00                	push   0x0
    2421:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2424:	06                   	push   es
    2425:	57                   	push   di
    2426:	9a a1 2a 3e 24       	call   0x243e:0x2aa1
    242b:	bf a0 22             	mov    di,0x22a0
    242e:	0e                   	push   cs
    242f:	57                   	push   di
    2430:	6a 08                	push   0x8
    2432:	6a 02                	push   0x2
    2434:	6a 00                	push   0x0
    2436:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2439:	06                   	push   es
    243a:	57                   	push   di
    243b:	9a a1 2a 53 24       	call   0x2453:0x2aa1
    2440:	bf ac 22             	mov    di,0x22ac
    2443:	0e                   	push   cs
    2444:	57                   	push   di
    2445:	6a 08                	push   0x8
    2447:	6a 02                	push   0x2
    2449:	6a 00                	push   0x0
    244b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    244e:	06                   	push   es
    244f:	57                   	push   di
    2450:	9a a1 2a 68 24       	call   0x2468:0x2aa1
    2455:	bf b3 22             	mov    di,0x22b3
    2458:	0e                   	push   cs
    2459:	57                   	push   di
    245a:	6a 05                	push   0x5
    245c:	6a 00                	push   0x0
    245e:	6a 00                	push   0x0
    2460:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2463:	06                   	push   es
    2464:	57                   	push   di
    2465:	9a a1 2a 7d 24       	call   0x247d:0x2aa1
    246a:	bf be 22             	mov    di,0x22be
    246d:	0e                   	push   cs
    246e:	57                   	push   di
    246f:	6a 03                	push   0x3
    2471:	6a 00                	push   0x0
    2473:	6a 00                	push   0x0
    2475:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2478:	06                   	push   es
    2479:	57                   	push   di
    247a:	9a a1 2a 18 26       	call   0x2618:0x2aa1
    247f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2482:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    2487:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    248a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    248d:	bf c6 22             	mov    di,0x22c6
    2490:	0e                   	push   cs
    2491:	57                   	push   di
    2492:	bf cd 22             	mov    di,0x22cd
    2495:	0e                   	push   cs
    2496:	57                   	push   di
    2497:	6a 03                	push   0x3
    2499:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    249c:	06                   	push   es
    249d:	57                   	push   di
    249e:	9a f6 18 0d 25       	call   0x250d:0x18f6
    24a3:	c9                   	leave
    24a4:	ca 04 00             	retf   0x4
    24a7:	55                   	push   bp
    24a8:	89 e5                	mov    bp,sp
    24aa:	b8 aa 00             	mov    ax,0xaa
    24ad:	9a 44 04 3b 26       	call   0x263b:0x444
    24b2:	81 ec aa 00          	sub    sp,0xaa
    24b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24b9:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    24bc:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    24bf:	31 c0                	xor    ax,ax
    24c1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    24c4:	eb 03                	jmp    0x24c9
    24c6:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    24c9:	a1 4e 01             	mov    ax,ds:0x14e
    24cc:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    24cf:	b8 01 00             	mov    ax,0x1
    24d2:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    24d5:	7e 03                	jle    0x24da
    24d7:	e9 4b 01             	jmp    0x2625
    24da:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    24dd:	eb 03                	jmp    0x24e2
    24df:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    24e2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    24e5:	99                   	cwd
    24e6:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    24e9:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    24ec:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    24f0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    24f3:	99                   	cwd
    24f4:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    24f7:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    24fa:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    24fe:	8d 7e e6             	lea    di,[bp-0x1a]
    2501:	16                   	push   ss
    2502:	57                   	push   di
    2503:	6a 01                	push   0x1
    2505:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2508:	06                   	push   es
    2509:	57                   	push   di
    250a:	9a 95 28 8e 26       	call   0x268e:0x2895
    250f:	08 c0                	or     al,al
    2511:	74 03                	je     0x2516
    2513:	e9 04 01             	jmp    0x261a
    2516:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2519:	99                   	cwd
    251a:	89 86 56 ff          	mov    WORD PTR [bp-0xaa],ax
    251e:	89 96 58 ff          	mov    WORD PTR [bp-0xa8],dx
    2522:	c6 86 5a ff 00       	mov    BYTE PTR [bp-0xa6],0x0
    2527:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    252a:	99                   	cwd
    252b:	89 86 5e ff          	mov    WORD PTR [bp-0xa2],ax
    252f:	89 96 60 ff          	mov    WORD PTR [bp-0xa0],dx
    2533:	c6 86 62 ff 00       	mov    BYTE PTR [bp-0x9e],0x0
    2538:	31 c0                	xor    ax,ax
    253a:	89 86 66 ff          	mov    WORD PTR [bp-0x9a],ax
    253e:	89 86 68 ff          	mov    WORD PTR [bp-0x98],ax
    2542:	c6 86 6a ff 00       	mov    BYTE PTR [bp-0x96],0x0
    2547:	31 c0                	xor    ax,ax
    2549:	89 86 6e ff          	mov    WORD PTR [bp-0x92],ax
    254d:	89 86 70 ff          	mov    WORD PTR [bp-0x90],ax
    2551:	c6 86 72 ff 00       	mov    BYTE PTR [bp-0x8e],0x0
    2556:	31 c0                	xor    ax,ax
    2558:	89 86 76 ff          	mov    WORD PTR [bp-0x8a],ax
    255c:	89 86 78 ff          	mov    WORD PTR [bp-0x88],ax
    2560:	c6 86 7a ff 00       	mov    BYTE PTR [bp-0x86],0x0
    2565:	31 c0                	xor    ax,ax
    2567:	89 86 7e ff          	mov    WORD PTR [bp-0x82],ax
    256b:	89 46 80             	mov    WORD PTR [bp-0x80],ax
    256e:	c6 46 82 00          	mov    BYTE PTR [bp-0x7e],0x0
    2572:	31 c0                	xor    ax,ax
    2574:	89 46 86             	mov    WORD PTR [bp-0x7a],ax
    2577:	89 46 88             	mov    WORD PTR [bp-0x78],ax
    257a:	c6 46 8a 00          	mov    BYTE PTR [bp-0x76],0x0
    257e:	31 c0                	xor    ax,ax
    2580:	89 46 8e             	mov    WORD PTR [bp-0x72],ax
    2583:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    2586:	c6 46 92 00          	mov    BYTE PTR [bp-0x6e],0x0
    258a:	31 c0                	xor    ax,ax
    258c:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    258f:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    2592:	c6 46 9a 00          	mov    BYTE PTR [bp-0x66],0x0
    2596:	31 c0                	xor    ax,ax
    2598:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    259b:	89 46 a0             	mov    WORD PTR [bp-0x60],ax
    259e:	c6 46 a2 00          	mov    BYTE PTR [bp-0x5e],0x0
    25a2:	31 c0                	xor    ax,ax
    25a4:	89 46 a6             	mov    WORD PTR [bp-0x5a],ax
    25a7:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    25aa:	c6 46 aa 00          	mov    BYTE PTR [bp-0x56],0x0
    25ae:	31 c0                	xor    ax,ax
    25b0:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    25b3:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    25b6:	c6 46 b2 00          	mov    BYTE PTR [bp-0x4e],0x0
    25ba:	c7 46 b6 64 00       	mov    WORD PTR [bp-0x4a],0x64
    25bf:	c7 46 b8 00 00       	mov    WORD PTR [bp-0x48],0x0
    25c4:	c6 46 ba 00          	mov    BYTE PTR [bp-0x46],0x0
    25c8:	31 c0                	xor    ax,ax
    25ca:	89 46 be             	mov    WORD PTR [bp-0x42],ax
    25cd:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    25d0:	c6 46 c2 00          	mov    BYTE PTR [bp-0x3e],0x0
    25d4:	31 c0                	xor    ax,ax
    25d6:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    25d9:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    25dc:	c6 46 ca 00          	mov    BYTE PTR [bp-0x36],0x0
    25e0:	31 c0                	xor    ax,ax
    25e2:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    25e5:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    25e8:	c6 46 d2 00          	mov    BYTE PTR [bp-0x2e],0x0
    25ec:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    25f0:	b0 00                	mov    al,0x0
    25f2:	75 01                	jne    0x25f5
    25f4:	40                   	inc    ax
    25f5:	88 46 d6             	mov    BYTE PTR [bp-0x2a],al
    25f8:	c6 46 da 01          	mov    BYTE PTR [bp-0x26],0x1
    25fc:	31 c0                	xor    ax,ax
    25fe:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2601:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2604:	c6 46 e2 00          	mov    BYTE PTR [bp-0x1e],0x0
    2608:	8d be 56 ff          	lea    di,[bp-0xaa]
    260c:	16                   	push   ss
    260d:	57                   	push   di
    260e:	6a 11                	push   0x11
    2610:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2613:	06                   	push   es
    2614:	57                   	push   di
    2615:	9a 21 53 90 27       	call   0x2790:0x5321
    261a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    261d:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2620:	74 03                	je     0x2625
    2622:	e9 ba fe             	jmp    0x24df
    2625:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    2629:	74 03                	je     0x262e
    262b:	e9 98 fe             	jmp    0x24c6
    262e:	c9                   	leave
    262f:	ca 04 00             	retf   0x4
    2632:	55                   	push   bp
    2633:	89 e5                	mov    bp,sp
    2635:	b8 a8 00             	mov    ax,0xa8
    2638:	9a 44 04 ad 28       	call   0x28ad:0x444
    263d:	81 ec a8 00          	sub    sp,0xa8
    2641:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2644:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2647:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    264a:	a1 4e 01             	mov    ax,ds:0x14e
    264d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2650:	b8 01 00             	mov    ax,0x1
    2653:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2656:	7e 03                	jle    0x265b
    2658:	e9 42 01             	jmp    0x279d
    265b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    265e:	eb 03                	jmp    0x2663
    2660:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2663:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2666:	99                   	cwd
    2667:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    266a:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    266d:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    2671:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2674:	99                   	cwd
    2675:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    2678:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    267b:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    267f:	8d 7e e8             	lea    di,[bp-0x18]
    2682:	16                   	push   ss
    2683:	57                   	push   di
    2684:	6a 01                	push   0x1
    2686:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2689:	06                   	push   es
    268a:	57                   	push   di
    268b:	9a 95 28 37 2a       	call   0x2a37:0x2895
    2690:	08 c0                	or     al,al
    2692:	74 03                	je     0x2697
    2694:	e9 fb 00             	jmp    0x2792
    2697:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    269a:	99                   	cwd
    269b:	89 86 58 ff          	mov    WORD PTR [bp-0xa8],ax
    269f:	89 96 5a ff          	mov    WORD PTR [bp-0xa6],dx
    26a3:	c6 86 5c ff 00       	mov    BYTE PTR [bp-0xa4],0x0
    26a8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    26ab:	99                   	cwd
    26ac:	89 86 60 ff          	mov    WORD PTR [bp-0xa0],ax
    26b0:	89 96 62 ff          	mov    WORD PTR [bp-0x9e],dx
    26b4:	c6 86 64 ff 00       	mov    BYTE PTR [bp-0x9c],0x0
    26b9:	31 c0                	xor    ax,ax
    26bb:	89 86 68 ff          	mov    WORD PTR [bp-0x98],ax
    26bf:	89 86 6a ff          	mov    WORD PTR [bp-0x96],ax
    26c3:	c6 86 6c ff 00       	mov    BYTE PTR [bp-0x94],0x0
    26c8:	31 c0                	xor    ax,ax
    26ca:	89 86 70 ff          	mov    WORD PTR [bp-0x90],ax
    26ce:	89 86 72 ff          	mov    WORD PTR [bp-0x8e],ax
    26d2:	c6 86 74 ff 00       	mov    BYTE PTR [bp-0x8c],0x0
    26d7:	31 c0                	xor    ax,ax
    26d9:	89 86 78 ff          	mov    WORD PTR [bp-0x88],ax
    26dd:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    26e1:	c6 86 7c ff 00       	mov    BYTE PTR [bp-0x84],0x0
    26e6:	31 c0                	xor    ax,ax
    26e8:	89 46 80             	mov    WORD PTR [bp-0x80],ax
    26eb:	89 46 82             	mov    WORD PTR [bp-0x7e],ax
    26ee:	c6 46 84 00          	mov    BYTE PTR [bp-0x7c],0x0
    26f2:	31 c0                	xor    ax,ax
    26f4:	89 46 88             	mov    WORD PTR [bp-0x78],ax
    26f7:	89 46 8a             	mov    WORD PTR [bp-0x76],ax
    26fa:	c6 46 8c 00          	mov    BYTE PTR [bp-0x74],0x0
    26fe:	31 c0                	xor    ax,ax
    2700:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    2703:	89 46 92             	mov    WORD PTR [bp-0x6e],ax
    2706:	c6 46 94 00          	mov    BYTE PTR [bp-0x6c],0x0
    270a:	31 c0                	xor    ax,ax
    270c:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    270f:	89 46 9a             	mov    WORD PTR [bp-0x66],ax
    2712:	c6 46 9c 00          	mov    BYTE PTR [bp-0x64],0x0
    2716:	31 c0                	xor    ax,ax
    2718:	89 46 a0             	mov    WORD PTR [bp-0x60],ax
    271b:	89 46 a2             	mov    WORD PTR [bp-0x5e],ax
    271e:	c6 46 a4 00          	mov    BYTE PTR [bp-0x5c],0x0
    2722:	31 c0                	xor    ax,ax
    2724:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    2727:	89 46 aa             	mov    WORD PTR [bp-0x56],ax
    272a:	c6 46 ac 00          	mov    BYTE PTR [bp-0x54],0x0
    272e:	31 c0                	xor    ax,ax
    2730:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    2733:	89 46 b2             	mov    WORD PTR [bp-0x4e],ax
    2736:	c6 46 b4 00          	mov    BYTE PTR [bp-0x4c],0x0
    273a:	c7 46 b8 64 00       	mov    WORD PTR [bp-0x48],0x64
    273f:	c7 46 ba 00 00       	mov    WORD PTR [bp-0x46],0x0
    2744:	c6 46 bc 00          	mov    BYTE PTR [bp-0x44],0x0
    2748:	31 c0                	xor    ax,ax
    274a:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    274d:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    2750:	c6 46 c4 00          	mov    BYTE PTR [bp-0x3c],0x0
    2754:	31 c0                	xor    ax,ax
    2756:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    2759:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    275c:	c6 46 cc 00          	mov    BYTE PTR [bp-0x34],0x0
    2760:	31 c0                	xor    ax,ax
    2762:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    2765:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    2768:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
    276c:	c6 46 d8 00          	mov    BYTE PTR [bp-0x28],0x0
    2770:	c6 46 dc 01          	mov    BYTE PTR [bp-0x24],0x1
    2774:	31 c0                	xor    ax,ax
    2776:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2779:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    277c:	c6 46 e4 00          	mov    BYTE PTR [bp-0x1c],0x0
    2780:	8d be 58 ff          	lea    di,[bp-0xa8]
    2784:	16                   	push   ss
    2785:	57                   	push   di
    2786:	6a 11                	push   0x11
    2788:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    278b:	06                   	push   es
    278c:	57                   	push   di
    278d:	9a 21 53 d8 28       	call   0x28d8:0x5321
    2792:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2795:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2798:	74 03                	je     0x279d
    279a:	e9 c3 fe             	jmp    0x2660
    279d:	c9                   	leave
    279e:	ca 06 00             	retf   0x6
    27a1:	09 50 65             	or     WORD PTR [bx+si+0x65],dx
    27a4:	72 69                	jb     0x280f
    27a6:	6f                   	outs   dx,WORD PTR ds:[si]
    27a7:	64 65 4e             	fs gs dec si
    27aa:	6f                   	outs   dx,WORD PTR ds:[si]
    27ab:	0c 45                	or     al,0x45
    27ad:	6e                   	outs   dx,BYTE PTR ds:[si]
    27ae:	74 72                	je     0x2822
    27b0:	65 70 72             	gs jo  0x2825
    27b3:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    27b8:	09 50 72             	or     WORD PTR [bx+si+0x72],dx
    27bb:	6f                   	outs   dx,WORD PTR ds:[si]
    27bc:	64 75 69             	fs jne 0x2828
    27bf:	74 4e                	je     0x280f
    27c1:	6f                   	outs   dx,WORD PTR ds:[si]
    27c2:	0a 50 72             	or     dl,BYTE PTR [bx+si+0x72]
    27c5:	6f                   	outs   dx,WORD PTR ds:[si]
    27c6:	64 75 63             	fs jne 0x282c
    27c9:	74 69                	je     0x2834
    27cb:	6f                   	outs   dx,WORD PTR ds:[si]
    27cc:	6e                   	outs   dx,BYTE PTR ds:[si]
    27cd:	11 4d 61             	adc    WORD PTR [di+0x61],cx
    27d0:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    27d3:	6e                   	outs   dx,BYTE PTR ds:[si]
    27d4:	65 73 41             	gs jae 0x2818
    27d7:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    27dd:	65 73 12             	gs jae 0x27f2
    27e0:	50                   	push   ax
    27e1:	72 6f                	jb     0x2852
    27e3:	64 75 63             	fs jne 0x2849
    27e6:	74 69                	je     0x2851
    27e8:	66 73 41             	data32 jae 0x282c
    27eb:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    27f1:	73 0f                	jae    0x2802
    27f3:	44                   	inc    sp
    27f4:	65 70 65             	gs jo  0x285c
    27f7:	6e                   	outs   dx,BYTE PTR ds:[si]
    27f8:	73 65                	jae    0x285f
    27fa:	73 51                	jae    0x284d
    27fc:	75 61                	jne    0x285f
    27fe:	6c                   	ins    BYTE PTR es:[di],dx
    27ff:	69 74 65 04 50       	imul   si,WORD PTR [si+0x65],0x5004
    2804:	72 69                	jb     0x286f
    2806:	78 09                	js     0x2811
    2808:	50                   	push   ax
    2809:	75 62                	jne    0x286d
    280b:	6c                   	ins    BYTE PTR es:[di],dx
    280c:	69 63 69 74 65       	imul   sp,WORD PTR [bp+di+0x69],0x6574
    2811:	11 41 63             	adc    WORD PTR [bx+di+0x63],ax
    2814:	74 69                	je     0x287f
    2816:	6f                   	outs   dx,WORD PTR ds:[si]
    2817:	6e                   	outs   dx,BYTE PTR ds:[si]
    2818:	43                   	inc    bx
    2819:	6f                   	outs   dx,WORD PTR ds:[si]
    281a:	6d                   	ins    WORD PTR es:[di],dx
    281b:	6d                   	ins    WORD PTR es:[di],dx
    281c:	65 72 63             	gs jb  0x2882
    281f:	69 61 6c 65 10       	imul   sp,WORD PTR [bx+di+0x6c],0x1065
    2824:	56                   	push   si
    2825:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2827:	64 65 75 72          	fs gs jne 0x289d
    282b:	73 41                	jae    0x286e
    282d:	66 66 65 63 74 65    	data32 arpl WORD PTR gs:[si+0x65],esi
    2833:	73 11                	jae    0x2846
    2835:	44                   	inc    sp
    2836:	75 72                	jne    0x28aa
    2838:	65 65 43             	gs gs inc bx
    283b:	72 65                	jb     0x28a2
    283d:	64 69 74 43 6c 69    	imul   si,WORD PTR fs:[si+0x43],0x696c
    2843:	65 6e                	outs   dx,BYTE PTR gs:[si]
    2845:	74 0b                	je     0x2852
    2847:	4c                   	dec    sp
    2848:	69 71 75 69 64       	imul   si,WORD PTR [bx+di+0x75],0x6469
    284d:	61                   	popa
    284e:	74 69                	je     0x28b9
    2850:	6f                   	outs   dx,WORD PTR ds:[si]
    2851:	6e                   	outs   dx,BYTE PTR ds:[si]
    2852:	12 53 6f             	adc    dl,BYTE PTR [bp+di+0x6f]
    2855:	75 6d                	jne    0x28c4
    2857:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    285c:	6e                   	outs   dx,BYTE PTR ds:[si]
    285d:	51                   	push   cx
    285e:	75 61                	jne    0x28c1
    2860:	6e                   	outs   dx,BYTE PTR ds:[si]
    2861:	74 69                	je     0x28cc
    2863:	74 65                	je     0x28ca
    2865:	0e                   	push   cs
    2866:	53                   	push   bx
    2867:	6f                   	outs   dx,WORD PTR ds:[si]
    2868:	75 6d                	jne    0x28d7
    286a:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    286f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2870:	50                   	push   ax
    2871:	72 69                	jb     0x28dc
    2873:	78 07                	js     0x287c
    2875:	53                   	push   bx
    2876:	70 65                	jo     0x28dd
    2878:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    287b:	6c                   	ins    BYTE PTR es:[di],dx
    287c:	06                   	push   es
    287d:	4d                   	dec    bp
    287e:	61                   	popa
    287f:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    2882:	6e                   	outs   dx,BYTE PTR ds:[si]
    2883:	20 50 65             	and    BYTE PTR [bx+si+0x65],dl
    2886:	72 69                	jb     0x28f1
    2888:	6f                   	outs   dx,WORD PTR ds:[si]
    2889:	64 65 4e             	fs gs dec si
    288c:	6f                   	outs   dx,WORD PTR ds:[si]
    288d:	3b 45 6e             	cmp    ax,WORD PTR [di+0x6e]
    2890:	74 72                	je     0x2904
    2892:	65 70 72             	gs jo  0x2907
    2895:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    289a:	3b 50 72             	cmp    dx,WORD PTR [bx+si+0x72]
    289d:	6f                   	outs   dx,WORD PTR ds:[si]
    289e:	64 75 69             	fs jne 0x290a
    28a1:	74 4e                	je     0x28f1
    28a3:	6f                   	outs   dx,WORD PTR ds:[si]
    28a4:	55                   	push   bp
    28a5:	89 e5                	mov    bp,sp
    28a7:	b8 08 00             	mov    ax,0x8
    28aa:	9a 44 04 46 2a       	call   0x2a46:0x444
    28af:	83 ec 08             	sub    sp,0x8
    28b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b5:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    28b8:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    28bb:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    28bf:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    28c2:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    28c5:	bf a1 27             	mov    di,0x27a1
    28c8:	0e                   	push   cs
    28c9:	57                   	push   di
    28ca:	6a 03                	push   0x3
    28cc:	6a 00                	push   0x0
    28ce:	6a 00                	push   0x0
    28d0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    28d3:	06                   	push   es
    28d4:	57                   	push   di
    28d5:	9a a1 2a ed 28       	call   0x28ed:0x2aa1
    28da:	bf ab 27             	mov    di,0x27ab
    28dd:	0e                   	push   cs
    28de:	57                   	push   di
    28df:	6a 03                	push   0x3
    28e1:	6a 00                	push   0x0
    28e3:	6a 00                	push   0x0
    28e5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    28e8:	06                   	push   es
    28e9:	57                   	push   di
    28ea:	9a a1 2a 02 29       	call   0x2902:0x2aa1
    28ef:	bf b8 27             	mov    di,0x27b8
    28f2:	0e                   	push   cs
    28f3:	57                   	push   di
    28f4:	6a 03                	push   0x3
    28f6:	6a 00                	push   0x0
    28f8:	6a 00                	push   0x0
    28fa:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    28fd:	06                   	push   es
    28fe:	57                   	push   di
    28ff:	9a a1 2a 17 29       	call   0x2917:0x2aa1
    2904:	bf c2 27             	mov    di,0x27c2
    2907:	0e                   	push   cs
    2908:	57                   	push   di
    2909:	6a 03                	push   0x3
    290b:	6a 00                	push   0x0
    290d:	6a 00                	push   0x0
    290f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2912:	06                   	push   es
    2913:	57                   	push   di
    2914:	9a a1 2a 2c 29       	call   0x292c:0x2aa1
    2919:	bf cd 27             	mov    di,0x27cd
    291c:	0e                   	push   cs
    291d:	57                   	push   di
    291e:	6a 03                	push   0x3
    2920:	6a 00                	push   0x0
    2922:	6a 00                	push   0x0
    2924:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2927:	06                   	push   es
    2928:	57                   	push   di
    2929:	9a a1 2a 41 29       	call   0x2941:0x2aa1
    292e:	bf df 27             	mov    di,0x27df
    2931:	0e                   	push   cs
    2932:	57                   	push   di
    2933:	6a 03                	push   0x3
    2935:	6a 00                	push   0x0
    2937:	6a 00                	push   0x0
    2939:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    293c:	06                   	push   es
    293d:	57                   	push   di
    293e:	9a a1 2a 56 29       	call   0x2956:0x2aa1
    2943:	bf f2 27             	mov    di,0x27f2
    2946:	0e                   	push   cs
    2947:	57                   	push   di
    2948:	6a 08                	push   0x8
    294a:	6a 02                	push   0x2
    294c:	6a 00                	push   0x0
    294e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2951:	06                   	push   es
    2952:	57                   	push   di
    2953:	9a a1 2a 6b 29       	call   0x296b:0x2aa1
    2958:	bf 02 28             	mov    di,0x2802
    295b:	0e                   	push   cs
    295c:	57                   	push   di
    295d:	6a 08                	push   0x8
    295f:	6a 02                	push   0x2
    2961:	6a 00                	push   0x0
    2963:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2966:	06                   	push   es
    2967:	57                   	push   di
    2968:	9a a1 2a 80 29       	call   0x2980:0x2aa1
    296d:	bf 07 28             	mov    di,0x2807
    2970:	0e                   	push   cs
    2971:	57                   	push   di
    2972:	6a 08                	push   0x8
    2974:	6a 02                	push   0x2
    2976:	6a 00                	push   0x0
    2978:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    297b:	06                   	push   es
    297c:	57                   	push   di
    297d:	9a a1 2a 95 29       	call   0x2995:0x2aa1
    2982:	bf 11 28             	mov    di,0x2811
    2985:	0e                   	push   cs
    2986:	57                   	push   di
    2987:	6a 08                	push   0x8
    2989:	6a 02                	push   0x2
    298b:	6a 00                	push   0x0
    298d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2990:	06                   	push   es
    2991:	57                   	push   di
    2992:	9a a1 2a aa 29       	call   0x29aa:0x2aa1
    2997:	bf 23 28             	mov    di,0x2823
    299a:	0e                   	push   cs
    299b:	57                   	push   di
    299c:	6a 03                	push   0x3
    299e:	6a 00                	push   0x0
    29a0:	6a 00                	push   0x0
    29a2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    29a5:	06                   	push   es
    29a6:	57                   	push   di
    29a7:	9a a1 2a bf 29       	call   0x29bf:0x2aa1
    29ac:	bf 34 28             	mov    di,0x2834
    29af:	0e                   	push   cs
    29b0:	57                   	push   di
    29b1:	6a 03                	push   0x3
    29b3:	6a 00                	push   0x0
    29b5:	6a 00                	push   0x0
    29b7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    29ba:	06                   	push   es
    29bb:	57                   	push   di
    29bc:	9a a1 2a d4 29       	call   0x29d4:0x2aa1
    29c1:	bf 46 28             	mov    di,0x2846
    29c4:	0e                   	push   cs
    29c5:	57                   	push   di
    29c6:	6a 03                	push   0x3
    29c8:	6a 00                	push   0x0
    29ca:	6a 00                	push   0x0
    29cc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    29cf:	06                   	push   es
    29d0:	57                   	push   di
    29d1:	9a a1 2a e9 29       	call   0x29e9:0x2aa1
    29d6:	bf 52 28             	mov    di,0x2852
    29d9:	0e                   	push   cs
    29da:	57                   	push   di
    29db:	6a 03                	push   0x3
    29dd:	6a 00                	push   0x0
    29df:	6a 00                	push   0x0
    29e1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    29e4:	06                   	push   es
    29e5:	57                   	push   di
    29e6:	9a a1 2a fe 29       	call   0x29fe:0x2aa1
    29eb:	bf 65 28             	mov    di,0x2865
    29ee:	0e                   	push   cs
    29ef:	57                   	push   di
    29f0:	6a 08                	push   0x8
    29f2:	6a 02                	push   0x2
    29f4:	6a 00                	push   0x0
    29f6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    29f9:	06                   	push   es
    29fa:	57                   	push   di
    29fb:	9a a1 2a 13 2a       	call   0x2a13:0x2aa1
    2a00:	bf 74 28             	mov    di,0x2874
    2a03:	0e                   	push   cs
    2a04:	57                   	push   di
    2a05:	6a 03                	push   0x3
    2a07:	6a 00                	push   0x0
    2a09:	6a 00                	push   0x0
    2a0b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2a0e:	06                   	push   es
    2a0f:	57                   	push   di
    2a10:	9a a1 2a a8 2b       	call   0x2ba8:0x2aa1
    2a15:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2a18:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    2a1d:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2a20:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2a23:	bf 7c 28             	mov    di,0x287c
    2a26:	0e                   	push   cs
    2a27:	57                   	push   di
    2a28:	bf 83 28             	mov    di,0x2883
    2a2b:	0e                   	push   cs
    2a2c:	57                   	push   di
    2a2d:	6a 03                	push   0x3
    2a2f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2a32:	06                   	push   es
    2a33:	57                   	push   di
    2a34:	9a f6 18 bb 2a       	call   0x2abb:0x18f6
    2a39:	c9                   	leave
    2a3a:	ca 04 00             	retf   0x4
    2a3d:	55                   	push   bp
    2a3e:	89 e5                	mov    bp,sp
    2a40:	b8 a4 00             	mov    ax,0xa4
    2a43:	9a 44 04 d4 2b       	call   0x2bd4:0x444
    2a48:	81 ec a4 00          	sub    sp,0xa4
    2a4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a4f:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    2a52:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    2a55:	31 c0                	xor    ax,ax
    2a57:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a5a:	eb 03                	jmp    0x2a5f
    2a5c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2a5f:	a1 4e 01             	mov    ax,ds:0x14e
    2a62:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2a65:	b8 01 00             	mov    ax,0x1
    2a68:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2a6b:	7e 03                	jle    0x2a70
    2a6d:	e9 4e 01             	jmp    0x2bbe
    2a70:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a73:	eb 03                	jmp    0x2a78
    2a75:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2a78:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    2a7d:	eb 03                	jmp    0x2a82
    2a7f:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2a82:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a85:	99                   	cwd
    2a86:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    2a89:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    2a8c:	c6 46 e0 00          	mov    BYTE PTR [bp-0x20],0x0
    2a90:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2a93:	99                   	cwd
    2a94:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    2a97:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    2a9a:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    2a9e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2aa1:	99                   	cwd
    2aa2:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    2aa5:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    2aa8:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    2aac:	8d 7e dc             	lea    di,[bp-0x24]
    2aaf:	16                   	push   ss
    2ab0:	57                   	push   di
    2ab1:	6a 02                	push   0x2
    2ab3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2ab6:	06                   	push   es
    2ab7:	57                   	push   di
    2ab8:	9a 95 28 3f 2c       	call   0x2c3f:0x2895
    2abd:	08 c0                	or     al,al
    2abf:	74 03                	je     0x2ac4
    2ac1:	e9 e6 00             	jmp    0x2baa
    2ac4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ac7:	99                   	cwd
    2ac8:	89 86 5c ff          	mov    WORD PTR [bp-0xa4],ax
    2acc:	89 96 5e ff          	mov    WORD PTR [bp-0xa2],dx
    2ad0:	c6 86 60 ff 00       	mov    BYTE PTR [bp-0xa0],0x0
    2ad5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2ad8:	99                   	cwd
    2ad9:	89 86 64 ff          	mov    WORD PTR [bp-0x9c],ax
    2add:	89 96 66 ff          	mov    WORD PTR [bp-0x9a],dx
    2ae1:	c6 86 68 ff 00       	mov    BYTE PTR [bp-0x98],0x0
    2ae6:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2ae9:	99                   	cwd
    2aea:	89 86 6c ff          	mov    WORD PTR [bp-0x94],ax
    2aee:	89 96 6e ff          	mov    WORD PTR [bp-0x92],dx
    2af2:	c6 86 70 ff 00       	mov    BYTE PTR [bp-0x90],0x0
    2af7:	31 c0                	xor    ax,ax
    2af9:	89 86 74 ff          	mov    WORD PTR [bp-0x8c],ax
    2afd:	89 86 76 ff          	mov    WORD PTR [bp-0x8a],ax
    2b01:	c6 86 78 ff 00       	mov    BYTE PTR [bp-0x88],0x0
    2b06:	31 c0                	xor    ax,ax
    2b08:	89 86 7c ff          	mov    WORD PTR [bp-0x84],ax
    2b0c:	89 86 7e ff          	mov    WORD PTR [bp-0x82],ax
    2b10:	c6 46 80 00          	mov    BYTE PTR [bp-0x80],0x0
    2b14:	31 c0                	xor    ax,ax
    2b16:	89 46 84             	mov    WORD PTR [bp-0x7c],ax
    2b19:	89 46 86             	mov    WORD PTR [bp-0x7a],ax
    2b1c:	c6 46 88 00          	mov    BYTE PTR [bp-0x78],0x0
    2b20:	31 c0                	xor    ax,ax
    2b22:	89 46 8c             	mov    WORD PTR [bp-0x74],ax
    2b25:	89 46 8e             	mov    WORD PTR [bp-0x72],ax
    2b28:	c6 46 90 00          	mov    BYTE PTR [bp-0x70],0x0
    2b2c:	31 c0                	xor    ax,ax
    2b2e:	89 46 94             	mov    WORD PTR [bp-0x6c],ax
    2b31:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    2b34:	c6 46 98 00          	mov    BYTE PTR [bp-0x68],0x0
    2b38:	31 c0                	xor    ax,ax
    2b3a:	89 46 9c             	mov    WORD PTR [bp-0x64],ax
    2b3d:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    2b40:	c6 46 a0 00          	mov    BYTE PTR [bp-0x60],0x0
    2b44:	31 c0                	xor    ax,ax
    2b46:	89 46 a4             	mov    WORD PTR [bp-0x5c],ax
    2b49:	89 46 a6             	mov    WORD PTR [bp-0x5a],ax
    2b4c:	c6 46 a8 00          	mov    BYTE PTR [bp-0x58],0x0
    2b50:	31 c0                	xor    ax,ax
    2b52:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
    2b55:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    2b58:	c6 46 b0 00          	mov    BYTE PTR [bp-0x50],0x0
    2b5c:	31 c0                	xor    ax,ax
    2b5e:	89 46 b4             	mov    WORD PTR [bp-0x4c],ax
    2b61:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    2b64:	c6 46 b8 00          	mov    BYTE PTR [bp-0x48],0x0
    2b68:	31 c0                	xor    ax,ax
    2b6a:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    2b6d:	89 46 be             	mov    WORD PTR [bp-0x42],ax
    2b70:	c6 46 c0 00          	mov    BYTE PTR [bp-0x40],0x0
    2b74:	31 c0                	xor    ax,ax
    2b76:	89 46 c4             	mov    WORD PTR [bp-0x3c],ax
    2b79:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    2b7c:	c6 46 c8 00          	mov    BYTE PTR [bp-0x38],0x0
    2b80:	31 c0                	xor    ax,ax
    2b82:	89 46 cc             	mov    WORD PTR [bp-0x34],ax
    2b85:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    2b88:	c6 46 d0 00          	mov    BYTE PTR [bp-0x30],0x0
    2b8c:	31 c0                	xor    ax,ax
    2b8e:	89 46 d4             	mov    WORD PTR [bp-0x2c],ax
    2b91:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    2b94:	c6 46 d8 00          	mov    BYTE PTR [bp-0x28],0x0
    2b98:	8d be 5c ff          	lea    di,[bp-0xa4]
    2b9c:	16                   	push   ss
    2b9d:	57                   	push   di
    2b9e:	6a 0f                	push   0xf
    2ba0:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2ba3:	06                   	push   es
    2ba4:	57                   	push   di
    2ba5:	9a 21 53 2b 2d       	call   0x2d2b:0x5321
    2baa:	83 7e fa 02          	cmp    WORD PTR [bp-0x6],0x2
    2bae:	74 03                	je     0x2bb3
    2bb0:	e9 cc fe             	jmp    0x2a7f
    2bb3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2bb6:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2bb9:	74 03                	je     0x2bbe
    2bbb:	e9 b7 fe             	jmp    0x2a75
    2bbe:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    2bc2:	74 03                	je     0x2bc7
    2bc4:	e9 95 fe             	jmp    0x2a5c
    2bc7:	c9                   	leave
    2bc8:	ca 04 00             	retf   0x4
    2bcb:	55                   	push   bp
    2bcc:	89 e5                	mov    bp,sp
    2bce:	b8 a2 00             	mov    ax,0xa2
    2bd1:	9a 44 04 12 2e       	call   0x2e12:0x444
    2bd6:	81 ec a2 00          	sub    sp,0xa2
    2bda:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2bdd:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2be0:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2be3:	a1 4e 01             	mov    ax,ds:0x14e
    2be6:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2be9:	b8 01 00             	mov    ax,0x1
    2bec:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2bef:	7e 03                	jle    0x2bf4
    2bf1:	e9 4d 01             	jmp    0x2d41
    2bf4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2bf7:	eb 03                	jmp    0x2bfc
    2bf9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2bfc:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    2c01:	eb 03                	jmp    0x2c06
    2c03:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2c06:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2c09:	99                   	cwd
    2c0a:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2c0d:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    2c10:	c6 46 e2 00          	mov    BYTE PTR [bp-0x1e],0x0
    2c14:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2c17:	99                   	cwd
    2c18:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    2c1b:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    2c1e:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    2c22:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2c25:	99                   	cwd
    2c26:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2c29:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    2c2c:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    2c30:	8d 7e de             	lea    di,[bp-0x22]
    2c33:	16                   	push   ss
    2c34:	57                   	push   di
    2c35:	6a 02                	push   0x2
    2c37:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2c3a:	06                   	push   es
    2c3b:	57                   	push   di
    2c3c:	9a 95 28 1e 2f       	call   0x2f1e:0x2895
    2c41:	08 c0                	or     al,al
    2c43:	74 03                	je     0x2c48
    2c45:	e9 e5 00             	jmp    0x2d2d
    2c48:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2c4b:	99                   	cwd
    2c4c:	89 86 5e ff          	mov    WORD PTR [bp-0xa2],ax
    2c50:	89 96 60 ff          	mov    WORD PTR [bp-0xa0],dx
    2c54:	c6 86 62 ff 00       	mov    BYTE PTR [bp-0x9e],0x0
    2c59:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2c5c:	99                   	cwd
    2c5d:	89 86 66 ff          	mov    WORD PTR [bp-0x9a],ax
    2c61:	89 96 68 ff          	mov    WORD PTR [bp-0x98],dx
    2c65:	c6 86 6a ff 00       	mov    BYTE PTR [bp-0x96],0x0
    2c6a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2c6d:	99                   	cwd
    2c6e:	89 86 6e ff          	mov    WORD PTR [bp-0x92],ax
    2c72:	89 96 70 ff          	mov    WORD PTR [bp-0x90],dx
    2c76:	c6 86 72 ff 00       	mov    BYTE PTR [bp-0x8e],0x0
    2c7b:	31 c0                	xor    ax,ax
    2c7d:	89 86 76 ff          	mov    WORD PTR [bp-0x8a],ax
    2c81:	89 86 78 ff          	mov    WORD PTR [bp-0x88],ax
    2c85:	c6 86 7a ff 00       	mov    BYTE PTR [bp-0x86],0x0
    2c8a:	31 c0                	xor    ax,ax
    2c8c:	89 86 7e ff          	mov    WORD PTR [bp-0x82],ax
    2c90:	89 46 80             	mov    WORD PTR [bp-0x80],ax
    2c93:	c6 46 82 00          	mov    BYTE PTR [bp-0x7e],0x0
    2c97:	31 c0                	xor    ax,ax
    2c99:	89 46 86             	mov    WORD PTR [bp-0x7a],ax
    2c9c:	89 46 88             	mov    WORD PTR [bp-0x78],ax
    2c9f:	c6 46 8a 00          	mov    BYTE PTR [bp-0x76],0x0
    2ca3:	31 c0                	xor    ax,ax
    2ca5:	89 46 8e             	mov    WORD PTR [bp-0x72],ax
    2ca8:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    2cab:	c6 46 92 00          	mov    BYTE PTR [bp-0x6e],0x0
    2caf:	31 c0                	xor    ax,ax
    2cb1:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    2cb4:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    2cb7:	c6 46 9a 00          	mov    BYTE PTR [bp-0x66],0x0
    2cbb:	31 c0                	xor    ax,ax
    2cbd:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    2cc0:	89 46 a0             	mov    WORD PTR [bp-0x60],ax
    2cc3:	c6 46 a2 00          	mov    BYTE PTR [bp-0x5e],0x0
    2cc7:	31 c0                	xor    ax,ax
    2cc9:	89 46 a6             	mov    WORD PTR [bp-0x5a],ax
    2ccc:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    2ccf:	c6 46 aa 00          	mov    BYTE PTR [bp-0x56],0x0
    2cd3:	31 c0                	xor    ax,ax
    2cd5:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    2cd8:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    2cdb:	c6 46 b2 00          	mov    BYTE PTR [bp-0x4e],0x0
    2cdf:	31 c0                	xor    ax,ax
    2ce1:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    2ce4:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    2ce7:	c6 46 ba 00          	mov    BYTE PTR [bp-0x46],0x0
    2ceb:	31 c0                	xor    ax,ax
    2ced:	89 46 be             	mov    WORD PTR [bp-0x42],ax
    2cf0:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    2cf3:	c6 46 c2 00          	mov    BYTE PTR [bp-0x3e],0x0
    2cf7:	31 c0                	xor    ax,ax
    2cf9:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    2cfc:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    2cff:	c6 46 ca 00          	mov    BYTE PTR [bp-0x36],0x0
    2d03:	31 c0                	xor    ax,ax
    2d05:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    2d08:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    2d0b:	c6 46 d2 00          	mov    BYTE PTR [bp-0x2e],0x0
    2d0f:	31 c0                	xor    ax,ax
    2d11:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    2d14:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    2d17:	c6 46 da 00          	mov    BYTE PTR [bp-0x26],0x0
    2d1b:	8d be 5e ff          	lea    di,[bp-0xa2]
    2d1f:	16                   	push   ss
    2d20:	57                   	push   di
    2d21:	6a 0f                	push   0xf
    2d23:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2d26:	06                   	push   es
    2d27:	57                   	push   di
    2d28:	9a 21 53 3d 2e       	call   0x2e3d:0x5321
    2d2d:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    2d31:	74 03                	je     0x2d36
    2d33:	e9 cd fe             	jmp    0x2c03
    2d36:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d39:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2d3c:	74 03                	je     0x2d41
    2d3e:	e9 b8 fe             	jmp    0x2bf9
    2d41:	c9                   	leave
    2d42:	ca 06 00             	retf   0x6
    2d45:	09 50 65             	or     WORD PTR [bx+si+0x65],dx
    2d48:	72 69                	jb     0x2db3
    2d4a:	6f                   	outs   dx,WORD PTR ds:[si]
    2d4b:	64 65 4e             	fs gs dec si
    2d4e:	6f                   	outs   dx,WORD PTR ds:[si]
    2d4f:	0c 45                	or     al,0x45
    2d51:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d52:	74 72                	je     0x2dc6
    2d54:	65 70 72             	gs jo  0x2dc9
    2d57:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    2d5c:	13 43 6f             	adc    ax,WORD PTR [bp+di+0x6f]
    2d5f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d60:	63 75 72             	arpl   WORD PTR [di+0x72],si
    2d63:	72 65                	jb     0x2dca
    2d65:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d66:	74 73                	je     0x2ddb
    2d68:	50                   	push   ax
    2d69:	72 6f                	jb     0x2dda
    2d6b:	64 75 69             	fs jne 0x2dd7
    2d6e:	74 31                	je     0x2da1
    2d70:	13 43 6f             	adc    ax,WORD PTR [bp+di+0x6f]
    2d73:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d74:	63 75 72             	arpl   WORD PTR [di+0x72],si
    2d77:	72 65                	jb     0x2dde
    2d79:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d7a:	74 73                	je     0x2def
    2d7c:	50                   	push   ax
    2d7d:	72 6f                	jb     0x2dee
    2d7f:	64 75 69             	fs jne 0x2deb
    2d82:	74 32                	je     0x2db6
    2d84:	15 43 6f             	adc    ax,0x6f43
    2d87:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d88:	63 75 72             	arpl   WORD PTR [di+0x72],si
    2d8b:	72 65                	jb     0x2df2
    2d8d:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d8e:	74 73                	je     0x2e03
    2d90:	50                   	push   ax
    2d91:	61                   	popa
    2d92:	72 74                	jb     0x2e08
    2d94:	4d                   	dec    bp
    2d95:	61                   	popa
    2d96:	72 63                	jb     0x2dfb
    2d98:	68 65 13             	push   0x1365
    2d9b:	43                   	inc    bx
    2d9c:	6f                   	outs   dx,WORD PTR ds:[si]
    2d9d:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d9e:	63 75 72             	arpl   WORD PTR [di+0x72],si
    2da1:	72 65                	jb     0x2e08
    2da3:	6e                   	outs   dx,BYTE PTR ds:[si]
    2da4:	74 73                	je     0x2e19
    2da6:	52                   	push   dx
    2da7:	65 73 75             	gs jae 0x2e1f
    2daa:	6c                   	ins    BYTE PTR es:[di],dx
    2dab:	74 61                	je     0x2e0e
    2dad:	74 14                	je     0x2dc3
    2daf:	43                   	inc    bx
    2db0:	6f                   	outs   dx,WORD PTR ds:[si]
    2db1:	6e                   	outs   dx,BYTE PTR ds:[si]
    2db2:	63 75 72             	arpl   WORD PTR [di+0x72],si
    2db5:	72 65                	jb     0x2e1c
    2db7:	6e                   	outs   dx,BYTE PTR ds:[si]
    2db8:	74 73                	je     0x2e2d
    2dba:	53                   	push   bx
    2dbb:	74 72                	je     0x2e2f
    2dbd:	75 63                	jne    0x2e22
    2dbf:	74 75                	je     0x2e36
    2dc1:	72 65                	jb     0x2e28
    2dc3:	0f 53 69 74          	rcpps  xmm5,XMMWORD PTR [bx+di+0x74]
    2dc7:	75 61                	jne    0x2e2a
    2dc9:	74 69                	je     0x2e34
    2dcb:	6f                   	outs   dx,WORD PTR ds:[si]
    2dcc:	6e                   	outs   dx,BYTE PTR ds:[si]
    2dcd:	4d                   	dec    bp
    2dce:	61                   	popa
    2dcf:	72 63                	jb     0x2e34
    2dd1:	68 65 0f             	push   0xf65
    2dd4:	41                   	inc    cx
    2dd5:	75 74                	jne    0x2e4b
    2dd7:	6f                   	outs   dx,WORD PTR ds:[si]
    2dd8:	50                   	push   ax
    2dd9:	65 72 66             	gs jb  0x2e42
    2ddc:	6f                   	outs   dx,WORD PTR ds:[si]
    2ddd:	72 6d                	jb     0x2e4c
    2ddf:	61                   	popa
    2de0:	6e                   	outs   dx,BYTE PTR ds:[si]
    2de1:	63 65 07             	arpl   WORD PTR [di+0x7],sp
    2de4:	53                   	push   bx
    2de5:	70 65                	jo     0x2e4c
    2de7:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    2dea:	6c                   	ins    BYTE PTR es:[di],dx
    2deb:	06                   	push   es
    2dec:	4d                   	dec    bp
    2ded:	61                   	popa
    2dee:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    2df1:	6e                   	outs   dx,BYTE PTR ds:[si]
    2df2:	16                   	push   ss
    2df3:	50                   	push   ax
    2df4:	65 72 69             	gs jb  0x2e60
    2df7:	6f                   	outs   dx,WORD PTR ds:[si]
    2df8:	64 65 4e             	fs gs dec si
    2dfb:	6f                   	outs   dx,WORD PTR ds:[si]
    2dfc:	3b 45 6e             	cmp    ax,WORD PTR [di+0x6e]
    2dff:	74 72                	je     0x2e73
    2e01:	65 70 72             	gs jo  0x2e76
    2e04:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    2e09:	55                   	push   bp
    2e0a:	89 e5                	mov    bp,sp
    2e0c:	b8 08 00             	mov    ax,0x8
    2e0f:	9a 44 04 2d 2f       	call   0x2f2d:0x444
    2e14:	83 ec 08             	sub    sp,0x8
    2e17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e1a:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2e1d:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2e20:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    2e24:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2e27:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2e2a:	bf 45 2d             	mov    di,0x2d45
    2e2d:	0e                   	push   cs
    2e2e:	57                   	push   di
    2e2f:	6a 03                	push   0x3
    2e31:	6a 00                	push   0x0
    2e33:	6a 00                	push   0x0
    2e35:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2e38:	06                   	push   es
    2e39:	57                   	push   di
    2e3a:	9a a1 2a 52 2e       	call   0x2e52:0x2aa1
    2e3f:	bf 4f 2d             	mov    di,0x2d4f
    2e42:	0e                   	push   cs
    2e43:	57                   	push   di
    2e44:	6a 03                	push   0x3
    2e46:	6a 00                	push   0x0
    2e48:	6a 00                	push   0x0
    2e4a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2e4d:	06                   	push   es
    2e4e:	57                   	push   di
    2e4f:	9a a1 2a 67 2e       	call   0x2e67:0x2aa1
    2e54:	bf 5c 2d             	mov    di,0x2d5c
    2e57:	0e                   	push   cs
    2e58:	57                   	push   di
    2e59:	6a 05                	push   0x5
    2e5b:	6a 00                	push   0x0
    2e5d:	6a 00                	push   0x0
    2e5f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2e62:	06                   	push   es
    2e63:	57                   	push   di
    2e64:	9a a1 2a 7c 2e       	call   0x2e7c:0x2aa1
    2e69:	bf 70 2d             	mov    di,0x2d70
    2e6c:	0e                   	push   cs
    2e6d:	57                   	push   di
    2e6e:	6a 05                	push   0x5
    2e70:	6a 00                	push   0x0
    2e72:	6a 00                	push   0x0
    2e74:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2e77:	06                   	push   es
    2e78:	57                   	push   di
    2e79:	9a a1 2a 91 2e       	call   0x2e91:0x2aa1
    2e7e:	bf 84 2d             	mov    di,0x2d84
    2e81:	0e                   	push   cs
    2e82:	57                   	push   di
    2e83:	6a 05                	push   0x5
    2e85:	6a 00                	push   0x0
    2e87:	6a 00                	push   0x0
    2e89:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2e8c:	06                   	push   es
    2e8d:	57                   	push   di
    2e8e:	9a a1 2a a6 2e       	call   0x2ea6:0x2aa1
    2e93:	bf 9a 2d             	mov    di,0x2d9a
    2e96:	0e                   	push   cs
    2e97:	57                   	push   di
    2e98:	6a 05                	push   0x5
    2e9a:	6a 00                	push   0x0
    2e9c:	6a 00                	push   0x0
    2e9e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2ea1:	06                   	push   es
    2ea2:	57                   	push   di
    2ea3:	9a a1 2a bb 2e       	call   0x2ebb:0x2aa1
    2ea8:	bf ae 2d             	mov    di,0x2dae
    2eab:	0e                   	push   cs
    2eac:	57                   	push   di
    2ead:	6a 05                	push   0x5
    2eaf:	6a 00                	push   0x0
    2eb1:	6a 00                	push   0x0
    2eb3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2eb6:	06                   	push   es
    2eb7:	57                   	push   di
    2eb8:	9a a1 2a d0 2e       	call   0x2ed0:0x2aa1
    2ebd:	bf c3 2d             	mov    di,0x2dc3
    2ec0:	0e                   	push   cs
    2ec1:	57                   	push   di
    2ec2:	6a 05                	push   0x5
    2ec4:	6a 00                	push   0x0
    2ec6:	6a 00                	push   0x0
    2ec8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2ecb:	06                   	push   es
    2ecc:	57                   	push   di
    2ecd:	9a a1 2a e5 2e       	call   0x2ee5:0x2aa1
    2ed2:	bf d3 2d             	mov    di,0x2dd3
    2ed5:	0e                   	push   cs
    2ed6:	57                   	push   di
    2ed7:	6a 05                	push   0x5
    2ed9:	6a 00                	push   0x0
    2edb:	6a 00                	push   0x0
    2edd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2ee0:	06                   	push   es
    2ee1:	57                   	push   di
    2ee2:	9a a1 2a fa 2e       	call   0x2efa:0x2aa1
    2ee7:	bf e3 2d             	mov    di,0x2de3
    2eea:	0e                   	push   cs
    2eeb:	57                   	push   di
    2eec:	6a 03                	push   0x3
    2eee:	6a 00                	push   0x0
    2ef0:	6a 00                	push   0x0
    2ef2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2ef5:	06                   	push   es
    2ef6:	57                   	push   di
    2ef7:	9a a1 2a fe 2f       	call   0x2ffe:0x2aa1
    2efc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2eff:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    2f04:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2f07:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2f0a:	bf eb 2d             	mov    di,0x2deb
    2f0d:	0e                   	push   cs
    2f0e:	57                   	push   di
    2f0f:	bf f2 2d             	mov    di,0x2df2
    2f12:	0e                   	push   cs
    2f13:	57                   	push   di
    2f14:	6a 03                	push   0x3
    2f16:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2f19:	06                   	push   es
    2f1a:	57                   	push   di
    2f1b:	9a f6 18 89 2f       	call   0x2f89:0x18f6
    2f20:	c9                   	leave
    2f21:	ca 04 00             	retf   0x4
    2f24:	55                   	push   bp
    2f25:	89 e5                	mov    bp,sp
    2f27:	b8 6a 00             	mov    ax,0x6a
    2f2a:	9a 44 04 21 30       	call   0x3021:0x444
    2f2f:	83 ec 6a             	sub    sp,0x6a
    2f32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f35:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2f38:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2f3b:	31 c0                	xor    ax,ax
    2f3d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2f40:	eb 03                	jmp    0x2f45
    2f42:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2f45:	a1 4e 01             	mov    ax,ds:0x14e
    2f48:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2f4b:	b8 01 00             	mov    ax,0x1
    2f4e:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2f51:	7e 03                	jle    0x2f56
    2f53:	e9 b5 00             	jmp    0x300b
    2f56:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2f59:	eb 03                	jmp    0x2f5e
    2f5b:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2f5e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f61:	99                   	cwd
    2f62:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    2f65:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    2f68:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    2f6c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f6f:	99                   	cwd
    2f70:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    2f73:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    2f76:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    2f7a:	8d 7e e6             	lea    di,[bp-0x1a]
    2f7d:	16                   	push   ss
    2f7e:	57                   	push   di
    2f7f:	6a 01                	push   0x1
    2f81:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2f84:	06                   	push   es
    2f85:	57                   	push   di
    2f86:	9a 95 28 73 30       	call   0x3073:0x2895
    2f8b:	08 c0                	or     al,al
    2f8d:	75 71                	jne    0x3000
    2f8f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2f92:	99                   	cwd
    2f93:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    2f96:	89 56 98             	mov    WORD PTR [bp-0x68],dx
    2f99:	c6 46 9a 00          	mov    BYTE PTR [bp-0x66],0x0
    2f9d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2fa0:	99                   	cwd
    2fa1:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    2fa4:	89 56 a0             	mov    WORD PTR [bp-0x60],dx
    2fa7:	c6 46 a2 00          	mov    BYTE PTR [bp-0x5e],0x0
    2fab:	c6 46 a6 00          	mov    BYTE PTR [bp-0x5a],0x0
    2faf:	c6 46 aa 01          	mov    BYTE PTR [bp-0x56],0x1
    2fb3:	c6 46 ae 00          	mov    BYTE PTR [bp-0x52],0x0
    2fb7:	c6 46 b2 01          	mov    BYTE PTR [bp-0x4e],0x1
    2fbb:	c6 46 b6 00          	mov    BYTE PTR [bp-0x4a],0x0
    2fbf:	c6 46 ba 01          	mov    BYTE PTR [bp-0x46],0x1
    2fc3:	c6 46 be 00          	mov    BYTE PTR [bp-0x42],0x0
    2fc7:	c6 46 c2 01          	mov    BYTE PTR [bp-0x3e],0x1
    2fcb:	c6 46 c6 00          	mov    BYTE PTR [bp-0x3a],0x0
    2fcf:	c6 46 ca 01          	mov    BYTE PTR [bp-0x36],0x1
    2fd3:	c6 46 ce 00          	mov    BYTE PTR [bp-0x32],0x0
    2fd7:	c6 46 d2 01          	mov    BYTE PTR [bp-0x2e],0x1
    2fdb:	c6 46 d6 00          	mov    BYTE PTR [bp-0x2a],0x0
    2fdf:	c6 46 da 01          	mov    BYTE PTR [bp-0x26],0x1
    2fe3:	31 c0                	xor    ax,ax
    2fe5:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2fe8:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    2feb:	c6 46 e2 00          	mov    BYTE PTR [bp-0x1e],0x0
    2fef:	8d 7e 96             	lea    di,[bp-0x6a]
    2ff2:	16                   	push   ss
    2ff3:	57                   	push   di
    2ff4:	6a 09                	push   0x9
    2ff6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2ff9:	06                   	push   es
    2ffa:	57                   	push   di
    2ffb:	9a 21 53 e8 30       	call   0x30e8:0x5321
    3000:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3003:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    3006:	74 03                	je     0x300b
    3008:	e9 50 ff             	jmp    0x2f5b
    300b:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    300f:	74 03                	je     0x3014
    3011:	e9 2e ff             	jmp    0x2f42
    3014:	c9                   	leave
    3015:	ca 04 00             	retf   0x4
    3018:	55                   	push   bp
    3019:	89 e5                	mov    bp,sp
    301b:	b8 68 00             	mov    ax,0x68
    301e:	9a 44 04 5e 33       	call   0x335e:0x444
    3023:	83 ec 68             	sub    sp,0x68
    3026:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3029:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    302c:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    302f:	a1 4e 01             	mov    ax,ds:0x14e
    3032:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3035:	b8 01 00             	mov    ax,0x1
    3038:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    303b:	7e 03                	jle    0x3040
    303d:	e9 b5 00             	jmp    0x30f5
    3040:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3043:	eb 03                	jmp    0x3048
    3045:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3048:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    304b:	99                   	cwd
    304c:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    304f:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    3052:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    3056:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3059:	99                   	cwd
    305a:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    305d:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    3060:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    3064:	8d 7e e8             	lea    di,[bp-0x18]
    3067:	16                   	push   ss
    3068:	57                   	push   di
    3069:	6a 01                	push   0x1
    306b:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    306e:	06                   	push   es
    306f:	57                   	push   di
    3070:	9a 95 28 34 37       	call   0x3734:0x2895
    3075:	08 c0                	or     al,al
    3077:	75 71                	jne    0x30ea
    3079:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    307c:	99                   	cwd
    307d:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    3080:	89 56 9a             	mov    WORD PTR [bp-0x66],dx
    3083:	c6 46 9c 00          	mov    BYTE PTR [bp-0x64],0x0
    3087:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    308a:	99                   	cwd
    308b:	89 46 a0             	mov    WORD PTR [bp-0x60],ax
    308e:	89 56 a2             	mov    WORD PTR [bp-0x5e],dx
    3091:	c6 46 a4 00          	mov    BYTE PTR [bp-0x5c],0x0
    3095:	c6 46 a8 00          	mov    BYTE PTR [bp-0x58],0x0
    3099:	c6 46 ac 01          	mov    BYTE PTR [bp-0x54],0x1
    309d:	c6 46 b0 00          	mov    BYTE PTR [bp-0x50],0x0
    30a1:	c6 46 b4 01          	mov    BYTE PTR [bp-0x4c],0x1
    30a5:	c6 46 b8 00          	mov    BYTE PTR [bp-0x48],0x0
    30a9:	c6 46 bc 01          	mov    BYTE PTR [bp-0x44],0x1
    30ad:	c6 46 c0 00          	mov    BYTE PTR [bp-0x40],0x0
    30b1:	c6 46 c4 01          	mov    BYTE PTR [bp-0x3c],0x1
    30b5:	c6 46 c8 00          	mov    BYTE PTR [bp-0x38],0x0
    30b9:	c6 46 cc 01          	mov    BYTE PTR [bp-0x34],0x1
    30bd:	c6 46 d0 00          	mov    BYTE PTR [bp-0x30],0x0
    30c1:	c6 46 d4 01          	mov    BYTE PTR [bp-0x2c],0x1
    30c5:	c6 46 d8 00          	mov    BYTE PTR [bp-0x28],0x0
    30c9:	c6 46 dc 01          	mov    BYTE PTR [bp-0x24],0x1
    30cd:	31 c0                	xor    ax,ax
    30cf:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    30d2:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    30d5:	c6 46 e4 00          	mov    BYTE PTR [bp-0x1c],0x0
    30d9:	8d 7e 98             	lea    di,[bp-0x68]
    30dc:	16                   	push   ss
    30dd:	57                   	push   di
    30de:	6a 09                	push   0x9
    30e0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    30e3:	06                   	push   es
    30e4:	57                   	push   di
    30e5:	9a 21 53 89 33       	call   0x3389:0x5321
    30ea:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    30ed:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    30f0:	74 03                	je     0x30f5
    30f2:	e9 50 ff             	jmp    0x3045
    30f5:	c9                   	leave
    30f6:	ca 06 00             	retf   0x6
    30f9:	09 50 65             	or     WORD PTR [bx+si+0x65],dx
    30fc:	72 69                	jb     0x3167
    30fe:	6f                   	outs   dx,WORD PTR ds:[si]
    30ff:	64 65 4e             	fs gs dec si
    3102:	6f                   	outs   dx,WORD PTR ds:[si]
    3103:	0c 45                	or     al,0x45
    3105:	6e                   	outs   dx,BYTE PTR ds:[si]
    3106:	74 72                	je     0x317a
    3108:	65 70 72             	gs jo  0x317d
    310b:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    3110:	0d 43 61             	or     ax,0x6143
    3113:	70 69                	jo     0x317e
    3115:	74 61                	je     0x3178
    3117:	6c                   	ins    BYTE PTR es:[di],dx
    3118:	53                   	push   bx
    3119:	6f                   	outs   dx,WORD PTR ds:[si]
    311a:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    311d:	6c                   	ins    BYTE PTR es:[di],dx
    311e:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
    3121:	73 65                	jae    0x3188
    3123:	72 76                	jb     0x319b
    3125:	65 73 0b             	gs jae 0x3133
    3128:	52                   	push   dx
    3129:	65 73 75             	gs jae 0x31a1
    312c:	6c                   	ins    BYTE PTR es:[di],dx
    312d:	74 61                	je     0x3190
    312f:	74 4e                	je     0x317f
    3131:	65 74 0e             	gs je  0x3142
    3134:	53                   	push   bx
    3135:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
    313a:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
    313f:	74 74                	je     0x31b5
    3141:	65 03 43 41          	add    ax,WORD PTR gs:[bp+di+0x41]
    3145:	46                   	inc    si
    3146:	05 49 6d             	add    ax,0x6d49
    3149:	70 6f                	jo     0x31ba
    314b:	74 03                	je     0x3150
    314d:	49                   	dec    cx
    314e:	46                   	inc    si
    314f:	41                   	inc    cx
    3150:	0c 54                	or     al,0x54
    3152:	56                   	push   si
    3153:	41                   	inc    cx
    3154:	43                   	inc    bx
    3155:	6f                   	outs   dx,WORD PTR ds:[si]
    3156:	6c                   	ins    BYTE PTR es:[di],dx
    3157:	6c                   	ins    BYTE PTR es:[di],dx
    3158:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
    315c:	65 0d 54 56          	gs or  ax,0x5654
    3160:	41                   	inc    cx
    3161:	44                   	inc    sp
    3162:	65 64 75 63          	gs fs jne 0x31c9
    3166:	74 69                	je     0x31d1
    3168:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    316b:	07                   	pop    es
    316c:	43                   	inc    bx
    316d:	6c                   	ins    BYTE PTR es:[di],dx
    316e:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
    3173:	0c 46                	or     al,0x46
    3175:	6f                   	outs   dx,WORD PTR ds:[si]
    3176:	75 72                	jne    0x31ea
    3178:	6e                   	outs   dx,BYTE PTR ds:[si]
    3179:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
    317e:	72 73                	jb     0x31f3
    3180:	0a 54 72             	or     dl,BYTE PTR [si+0x72]
    3183:	65 73 6f             	gs jae 0x31f5
    3186:	72 65                	jb     0x31ed
    3188:	72 69                	jb     0x31f3
    318a:	65 07                	gs pop es
    318c:	45                   	inc    bp
    318d:	6d                   	ins    WORD PTR es:[di],dx
    318e:	70 72                	jo     0x3202
    3190:	75 6e                	jne    0x3200
    3192:	74 0d                	je     0x31a1
    3194:	44                   	inc    sp
    3195:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    3199:	76 65                	jbe    0x3200
    319b:	72 74                	jb     0x3211
    319d:	41                   	inc    cx
    319e:	75 74                	jne    0x3214
    31a0:	6f                   	outs   dx,WORD PTR ds:[si]
    31a1:	0e                   	push   cs
    31a2:	44                   	inc    sp
    31a3:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    31a7:	76 65                	jbe    0x320e
    31a9:	72 74                	jb     0x321f
    31ab:	4e                   	dec    si
    31ac:	41                   	inc    cx
    31ad:	75 74                	jne    0x3223
    31af:	6f                   	outs   dx,WORD PTR ds:[si]
    31b0:	0d 41 6d             	or     ax,0x6d41
    31b3:	6f                   	outs   dx,WORD PTR ds:[si]
    31b4:	72 74                	jb     0x322a
    31b6:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    31bb:	65 6e                	outs   dx,BYTE PTR gs:[si]
    31bd:	74 08                	je     0x31c7
    31bf:	43                   	inc    bx
    31c0:	65 73 73             	gs jae 0x3236
    31c3:	69 6f 6e 73 08       	imul   bp,WORD PTR [bx+0x6e],0x873
    31c8:	4d                   	dec    bp
    31c9:	61                   	popa
    31ca:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    31cd:	6e                   	outs   dx,BYTE PTR ds:[si]
    31ce:	65 73 10             	gs jae 0x31e1
    31d1:	41                   	inc    cx
    31d2:	67 65 4d             	addr32 gs dec bp
    31d5:	6f                   	outs   dx,WORD PTR ds:[si]
    31d6:	79 65                	jns    0x323d
    31d8:	6e                   	outs   dx,BYTE PTR ds:[si]
    31d9:	4d                   	dec    bp
    31da:	61                   	popa
    31db:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    31de:	6e                   	outs   dx,BYTE PTR ds:[si]
    31df:	65 73 15             	gs jae 0x31f7
    31e2:	49                   	dec    cx
    31e3:	6d                   	ins    WORD PTR es:[di],dx
    31e4:	6d                   	ins    WORD PTR es:[di],dx
    31e5:	6f                   	outs   dx,WORD PTR ds:[si]
    31e6:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
    31e9:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
    31ee:	6f                   	outs   dx,WORD PTR ds:[si]
    31ef:	6e                   	outs   dx,BYTE PTR ds:[si]
    31f0:	73 42                	jae    0x3234
    31f2:	72 75                	jb     0x3269
    31f4:	74 65                	je     0x325b
    31f6:	73 14                	jae    0x320c
    31f8:	43                   	inc    bx
    31f9:	6f                   	outs   dx,WORD PTR ds:[si]
    31fa:	75 74                	jne    0x3270
    31fc:	73 46                	jae    0x3244
    31fe:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
    3203:	72 6f                	jb     0x3274
    3205:	64 75 63             	fs jne 0x326b
    3208:	74 69                	je     0x3273
    320a:	6f                   	outs   dx,WORD PTR ds:[si]
    320b:	6e                   	outs   dx,BYTE PTR ds:[si]
    320c:	0f                   	movmskps esi,(bad)
    320d:	50                   	push   ax
    320e:	72 69                	jb     0x3279
    3210:	6d                   	ins    WORD PTR es:[di],dx
    3211:	65 73 41             	gs jae 0x3255
    3214:	73 73                	jae    0x3289
    3216:	75 72                	jne    0x328a
    3218:	61                   	popa
    3219:	6e                   	outs   dx,BYTE PTR ds:[si]
    321a:	63 65 0a             	arpl   WORD PTR [di+0xa],sp
    321d:	50                   	push   ax
    321e:	72 6f                	jb     0x328f
    3220:	64 75 63             	fs jne 0x3286
    3223:	74 69                	je     0x328e
    3225:	66 73 08             	data32 jae 0x3230
    3228:	56                   	push   si
    3229:	65 6e                	outs   dx,BYTE PTR gs:[si]
    322b:	64 65 75 72          	fs gs jne 0x32a1
    322f:	73 06                	jae    0x3237
    3231:	43                   	inc    bx
    3232:	61                   	popa
    3233:	64 72 65             	fs jb  0x329b
    3236:	73 12                	jae    0x324a
    3238:	52                   	push   dx
    3239:	65 6d                	gs ins WORD PTR es:[di],dx
    323b:	75 6e                	jne    0x32ab
    323d:	65 72 61             	gs jb  0x32a1
    3240:	74 69                	je     0x32ab
    3242:	6f                   	outs   dx,WORD PTR ds:[si]
    3243:	6e                   	outs   dx,BYTE PTR ds:[si]
    3244:	43                   	inc    bx
    3245:	61                   	popa
    3246:	64 72 65             	fs jb  0x32ae
    3249:	73 0c                	jae    0x3257
    324b:	43                   	inc    bx
    324c:	6f                   	outs   dx,WORD PTR ds:[si]
    324d:	75 74                	jne    0x32c3
    324f:	45                   	inc    bp
    3250:	6d                   	ins    WORD PTR es:[di],dx
    3251:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    3254:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    3257:	0c 43                	or     al,0x43
    3259:	6f                   	outs   dx,WORD PTR ds:[si]
    325a:	75 74                	jne    0x32d0
    325c:	4c                   	dec    sp
    325d:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    3262:	69 65 0d 43 6f       	imul   sp,WORD PTR [di+0xd],0x6f43
    3267:	75 74                	jne    0x32dd
    3269:	46                   	inc    si
    326a:	6f                   	outs   dx,WORD PTR ds:[si]
    326b:	72 6d                	jb     0x32da
    326d:	61                   	popa
    326e:	74 69                	je     0x32d9
    3270:	6f                   	outs   dx,WORD PTR ds:[si]
    3271:	6e                   	outs   dx,BYTE PTR ds:[si]
    3272:	0d 44 69             	or     ax,0x6944
    3275:	73 74                	jae    0x32eb
    3277:	72 69                	jb     0x32e2
    3279:	62 75 74             	bound  si,DWORD PTR [di+0x74]
    327c:	69 6f 6e 73 0b       	imul   bp,WORD PTR [bx+0x6e],0xb73
    3281:	52                   	push   dx
    3282:	65 70 61             	gs jo  0x32e6
    3285:	72 61                	jb     0x32e8
    3287:	74 69                	je     0x32f2
    3289:	6f                   	outs   dx,WORD PTR ds:[si]
    328a:	6e                   	outs   dx,BYTE PTR ds:[si]
    328b:	73 11                	jae    0x329e
    328d:	45                   	inc    bp
    328e:	6e                   	outs   dx,BYTE PTR ds:[si]
    328f:	74 72                	je     0x3303
    3291:	65 74 69             	gs je  0x32fd
    3294:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3296:	4d                   	dec    bp
    3297:	61                   	popa
    3298:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    329b:	6e                   	outs   dx,BYTE PTR ds:[si]
    329c:	65 73 0d             	gs jae 0x32ac
    329f:	52                   	push   dx
    32a0:	65 6d                	gs ins WORD PTR es:[di],dx
    32a2:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    32a5:	72 73                	jb     0x331a
    32a7:	41                   	inc    cx
    32a8:	73 73                	jae    0x331d
    32aa:	75 72                	jne    0x331e
    32ac:	11 49 6e             	adc    WORD PTR [bx+di+0x6e],cx
    32af:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    32b5:	74 69                	je     0x3320
    32b7:	73 50                	jae    0x3309
    32b9:	65 72 73             	gs jb  0x332f
    32bc:	6f                   	outs   dx,WORD PTR ds:[si]
    32bd:	6e                   	outs   dx,BYTE PTR ds:[si]
    32be:	11 49 6e             	adc    WORD PTR [bx+di+0x6e],cx
    32c1:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
    32c7:	74 69                	je     0x3332
    32c9:	73 41                	jae    0x330c
    32cb:	63 74 69             	arpl   WORD PTR [si+0x69],si
    32ce:	6f                   	outs   dx,WORD PTR ds:[si]
    32cf:	6e                   	outs   dx,BYTE PTR ds:[si]
    32d0:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    32d3:	6e                   	outs   dx,BYTE PTR ds:[si]
    32d4:	6e                   	outs   dx,BYTE PTR ds:[si]
    32d5:	65 73 50             	gs jae 0x3328
    32d8:	63 08                	arpl   WORD PTR [bx+si],cx
    32da:	47                   	inc    di
    32db:	72 65                	jb     0x3342
    32dd:	76 65                	jbe    0x3344
    32df:	73 50                	jae    0x3331
    32e1:	63 14                	arpl   WORD PTR [si],dx
    32e3:	4d                   	dec    bp
    32e4:	61                   	popa
    32e5:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    32e8:	6e                   	outs   dx,BYTE PTR ds:[si]
    32e9:	65 73 44             	gs jae 0x3330
    32ec:	65 74 72             	gs je  0x3361
    32ef:	75 69                	jne    0x335a
    32f1:	74 65                	je     0x3358
    32f3:	73 51                	jae    0x3346
    32f5:	74 65                	je     0x335c
    32f7:	0f 53 74 6f          	rcpps  xmm6,XMMWORD PTR [si+0x6f]
    32fb:	63 6b 44             	arpl   WORD PTR [bp+di+0x44],bp
    32fe:	65 74 72             	gs je  0x3373
    3301:	75 69                	jne    0x336c
    3303:	74 51                	je     0x3356
    3305:	74 65                	je     0x336c
    3307:	14 44                	adc    al,0x44
    3309:	65 6d                	gs ins WORD PTR es:[di],dx
    330b:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    3310:	6e                   	outs   dx,BYTE PTR ds:[si]
    3311:	73 50                	jae    0x3363
    3313:	72 6f                	jb     0x3384
    3315:	64 75 63             	fs jne 0x337b
    3318:	74 69                	je     0x3383
    331a:	66 73 12             	data32 jae 0x332f
    331d:	44                   	inc    sp
    331e:	65 6d                	gs ins WORD PTR es:[di],dx
    3320:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
    3325:	6e                   	outs   dx,BYTE PTR ds:[si]
    3326:	73 56                	jae    0x337e
    3328:	65 6e                	outs   dx,BYTE PTR gs:[si]
    332a:	64 65 75 72          	fs gs jne 0x33a0
    332e:	73 07                	jae    0x3337
    3330:	53                   	push   bx
    3331:	70 65                	jo     0x3398
    3333:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    3336:	6c                   	ins    BYTE PTR es:[di],dx
    3337:	06                   	push   es
    3338:	4d                   	dec    bp
    3339:	61                   	popa
    333a:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    333d:	6e                   	outs   dx,BYTE PTR ds:[si]
    333e:	16                   	push   ss
    333f:	50                   	push   ax
    3340:	65 72 69             	gs jb  0x33ac
    3343:	6f                   	outs   dx,WORD PTR ds:[si]
    3344:	64 65 4e             	fs gs dec si
    3347:	6f                   	outs   dx,WORD PTR ds:[si]
    3348:	3b 45 6e             	cmp    ax,WORD PTR [di+0x6e]
    334b:	74 72                	je     0x33bf
    334d:	65 70 72             	gs jo  0x33c2
    3350:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    3355:	55                   	push   bp
    3356:	89 e5                	mov    bp,sp
    3358:	b8 08 00             	mov    ax,0x8
    335b:	9a 44 04 43 37       	call   0x3743:0x444
    3360:	83 ec 08             	sub    sp,0x8
    3363:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3366:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3369:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    336c:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3370:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3373:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3376:	bf f9 30             	mov    di,0x30f9
    3379:	0e                   	push   cs
    337a:	57                   	push   di
    337b:	6a 03                	push   0x3
    337d:	6a 00                	push   0x0
    337f:	6a 00                	push   0x0
    3381:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3384:	06                   	push   es
    3385:	57                   	push   di
    3386:	9a a1 2a 9e 33       	call   0x339e:0x2aa1
    338b:	bf 03 31             	mov    di,0x3103
    338e:	0e                   	push   cs
    338f:	57                   	push   di
    3390:	6a 03                	push   0x3
    3392:	6a 00                	push   0x0
    3394:	6a 00                	push   0x0
    3396:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3399:	06                   	push   es
    339a:	57                   	push   di
    339b:	9a a1 2a b3 33       	call   0x33b3:0x2aa1
    33a0:	bf 10 31             	mov    di,0x3110
    33a3:	0e                   	push   cs
    33a4:	57                   	push   di
    33a5:	6a 08                	push   0x8
    33a7:	6a 02                	push   0x2
    33a9:	6a 00                	push   0x0
    33ab:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    33ae:	06                   	push   es
    33af:	57                   	push   di
    33b0:	9a a1 2a c8 33       	call   0x33c8:0x2aa1
    33b5:	bf 1e 31             	mov    di,0x311e
    33b8:	0e                   	push   cs
    33b9:	57                   	push   di
    33ba:	6a 08                	push   0x8
    33bc:	6a 02                	push   0x2
    33be:	6a 00                	push   0x0
    33c0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    33c3:	06                   	push   es
    33c4:	57                   	push   di
    33c5:	9a a1 2a dd 33       	call   0x33dd:0x2aa1
    33ca:	bf 27 31             	mov    di,0x3127
    33cd:	0e                   	push   cs
    33ce:	57                   	push   di
    33cf:	6a 08                	push   0x8
    33d1:	6a 02                	push   0x2
    33d3:	6a 00                	push   0x0
    33d5:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    33d8:	06                   	push   es
    33d9:	57                   	push   di
    33da:	9a a1 2a f2 33       	call   0x33f2:0x2aa1
    33df:	bf 33 31             	mov    di,0x3133
    33e2:	0e                   	push   cs
    33e3:	57                   	push   di
    33e4:	6a 08                	push   0x8
    33e6:	6a 02                	push   0x2
    33e8:	6a 00                	push   0x0
    33ea:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    33ed:	06                   	push   es
    33ee:	57                   	push   di
    33ef:	9a a1 2a 07 34       	call   0x3407:0x2aa1
    33f4:	bf 42 31             	mov    di,0x3142
    33f7:	0e                   	push   cs
    33f8:	57                   	push   di
    33f9:	6a 08                	push   0x8
    33fb:	6a 02                	push   0x2
    33fd:	6a 00                	push   0x0
    33ff:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3402:	06                   	push   es
    3403:	57                   	push   di
    3404:	9a a1 2a 1c 34       	call   0x341c:0x2aa1
    3409:	bf 46 31             	mov    di,0x3146
    340c:	0e                   	push   cs
    340d:	57                   	push   di
    340e:	6a 08                	push   0x8
    3410:	6a 02                	push   0x2
    3412:	6a 00                	push   0x0
    3414:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3417:	06                   	push   es
    3418:	57                   	push   di
    3419:	9a a1 2a 31 34       	call   0x3431:0x2aa1
    341e:	bf 4c 31             	mov    di,0x314c
    3421:	0e                   	push   cs
    3422:	57                   	push   di
    3423:	6a 08                	push   0x8
    3425:	6a 02                	push   0x2
    3427:	6a 00                	push   0x0
    3429:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    342c:	06                   	push   es
    342d:	57                   	push   di
    342e:	9a a1 2a 46 34       	call   0x3446:0x2aa1
    3433:	bf 50 31             	mov    di,0x3150
    3436:	0e                   	push   cs
    3437:	57                   	push   di
    3438:	6a 08                	push   0x8
    343a:	6a 02                	push   0x2
    343c:	6a 00                	push   0x0
    343e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3441:	06                   	push   es
    3442:	57                   	push   di
    3443:	9a a1 2a 5b 34       	call   0x345b:0x2aa1
    3448:	bf 5d 31             	mov    di,0x315d
    344b:	0e                   	push   cs
    344c:	57                   	push   di
    344d:	6a 08                	push   0x8
    344f:	6a 02                	push   0x2
    3451:	6a 00                	push   0x0
    3453:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3456:	06                   	push   es
    3457:	57                   	push   di
    3458:	9a a1 2a 70 34       	call   0x3470:0x2aa1
    345d:	bf 6b 31             	mov    di,0x316b
    3460:	0e                   	push   cs
    3461:	57                   	push   di
    3462:	6a 08                	push   0x8
    3464:	6a 02                	push   0x2
    3466:	6a 00                	push   0x0
    3468:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    346b:	06                   	push   es
    346c:	57                   	push   di
    346d:	9a a1 2a 85 34       	call   0x3485:0x2aa1
    3472:	bf 73 31             	mov    di,0x3173
    3475:	0e                   	push   cs
    3476:	57                   	push   di
    3477:	6a 08                	push   0x8
    3479:	6a 02                	push   0x2
    347b:	6a 00                	push   0x0
    347d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3480:	06                   	push   es
    3481:	57                   	push   di
    3482:	9a a1 2a 9a 34       	call   0x349a:0x2aa1
    3487:	bf 80 31             	mov    di,0x3180
    348a:	0e                   	push   cs
    348b:	57                   	push   di
    348c:	6a 08                	push   0x8
    348e:	6a 02                	push   0x2
    3490:	6a 00                	push   0x0
    3492:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3495:	06                   	push   es
    3496:	57                   	push   di
    3497:	9a a1 2a af 34       	call   0x34af:0x2aa1
    349c:	bf 8b 31             	mov    di,0x318b
    349f:	0e                   	push   cs
    34a0:	57                   	push   di
    34a1:	6a 08                	push   0x8
    34a3:	6a 02                	push   0x2
    34a5:	6a 00                	push   0x0
    34a7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    34aa:	06                   	push   es
    34ab:	57                   	push   di
    34ac:	9a a1 2a c4 34       	call   0x34c4:0x2aa1
    34b1:	bf 93 31             	mov    di,0x3193
    34b4:	0e                   	push   cs
    34b5:	57                   	push   di
    34b6:	6a 08                	push   0x8
    34b8:	6a 02                	push   0x2
    34ba:	6a 00                	push   0x0
    34bc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    34bf:	06                   	push   es
    34c0:	57                   	push   di
    34c1:	9a a1 2a d9 34       	call   0x34d9:0x2aa1
    34c6:	bf a1 31             	mov    di,0x31a1
    34c9:	0e                   	push   cs
    34ca:	57                   	push   di
    34cb:	6a 08                	push   0x8
    34cd:	6a 02                	push   0x2
    34cf:	6a 00                	push   0x0
    34d1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    34d4:	06                   	push   es
    34d5:	57                   	push   di
    34d6:	9a a1 2a ee 34       	call   0x34ee:0x2aa1
    34db:	bf b0 31             	mov    di,0x31b0
    34de:	0e                   	push   cs
    34df:	57                   	push   di
    34e0:	6a 08                	push   0x8
    34e2:	6a 02                	push   0x2
    34e4:	6a 00                	push   0x0
    34e6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    34e9:	06                   	push   es
    34ea:	57                   	push   di
    34eb:	9a a1 2a 03 35       	call   0x3503:0x2aa1
    34f0:	bf be 31             	mov    di,0x31be
    34f3:	0e                   	push   cs
    34f4:	57                   	push   di
    34f5:	6a 08                	push   0x8
    34f7:	6a 02                	push   0x2
    34f9:	6a 00                	push   0x0
    34fb:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    34fe:	06                   	push   es
    34ff:	57                   	push   di
    3500:	9a a1 2a 18 35       	call   0x3518:0x2aa1
    3505:	bf c7 31             	mov    di,0x31c7
    3508:	0e                   	push   cs
    3509:	57                   	push   di
    350a:	6a 03                	push   0x3
    350c:	6a 00                	push   0x0
    350e:	6a 00                	push   0x0
    3510:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3513:	06                   	push   es
    3514:	57                   	push   di
    3515:	9a a1 2a 2d 35       	call   0x352d:0x2aa1
    351a:	bf d0 31             	mov    di,0x31d0
    351d:	0e                   	push   cs
    351e:	57                   	push   di
    351f:	6a 08                	push   0x8
    3521:	6a 02                	push   0x2
    3523:	6a 00                	push   0x0
    3525:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3528:	06                   	push   es
    3529:	57                   	push   di
    352a:	9a a1 2a 42 35       	call   0x3542:0x2aa1
    352f:	bf e1 31             	mov    di,0x31e1
    3532:	0e                   	push   cs
    3533:	57                   	push   di
    3534:	6a 08                	push   0x8
    3536:	6a 02                	push   0x2
    3538:	6a 00                	push   0x0
    353a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    353d:	06                   	push   es
    353e:	57                   	push   di
    353f:	9a a1 2a 57 35       	call   0x3557:0x2aa1
    3544:	bf f7 31             	mov    di,0x31f7
    3547:	0e                   	push   cs
    3548:	57                   	push   di
    3549:	6a 08                	push   0x8
    354b:	6a 02                	push   0x2
    354d:	6a 00                	push   0x0
    354f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3552:	06                   	push   es
    3553:	57                   	push   di
    3554:	9a a1 2a 6c 35       	call   0x356c:0x2aa1
    3559:	bf 0c 32             	mov    di,0x320c
    355c:	0e                   	push   cs
    355d:	57                   	push   di
    355e:	6a 08                	push   0x8
    3560:	6a 02                	push   0x2
    3562:	6a 00                	push   0x0
    3564:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3567:	06                   	push   es
    3568:	57                   	push   di
    3569:	9a a1 2a 81 35       	call   0x3581:0x2aa1
    356e:	bf 1c 32             	mov    di,0x321c
    3571:	0e                   	push   cs
    3572:	57                   	push   di
    3573:	6a 03                	push   0x3
    3575:	6a 00                	push   0x0
    3577:	6a 00                	push   0x0
    3579:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    357c:	06                   	push   es
    357d:	57                   	push   di
    357e:	9a a1 2a 96 35       	call   0x3596:0x2aa1
    3583:	bf 27 32             	mov    di,0x3227
    3586:	0e                   	push   cs
    3587:	57                   	push   di
    3588:	6a 03                	push   0x3
    358a:	6a 00                	push   0x0
    358c:	6a 00                	push   0x0
    358e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3591:	06                   	push   es
    3592:	57                   	push   di
    3593:	9a a1 2a ab 35       	call   0x35ab:0x2aa1
    3598:	bf 30 32             	mov    di,0x3230
    359b:	0e                   	push   cs
    359c:	57                   	push   di
    359d:	6a 03                	push   0x3
    359f:	6a 00                	push   0x0
    35a1:	6a 00                	push   0x0
    35a3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35a6:	06                   	push   es
    35a7:	57                   	push   di
    35a8:	9a a1 2a c0 35       	call   0x35c0:0x2aa1
    35ad:	bf 37 32             	mov    di,0x3237
    35b0:	0e                   	push   cs
    35b1:	57                   	push   di
    35b2:	6a 08                	push   0x8
    35b4:	6a 02                	push   0x2
    35b6:	6a 00                	push   0x0
    35b8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35bb:	06                   	push   es
    35bc:	57                   	push   di
    35bd:	9a a1 2a d5 35       	call   0x35d5:0x2aa1
    35c2:	bf 4a 32             	mov    di,0x324a
    35c5:	0e                   	push   cs
    35c6:	57                   	push   di
    35c7:	6a 08                	push   0x8
    35c9:	6a 02                	push   0x2
    35cb:	6a 00                	push   0x0
    35cd:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35d0:	06                   	push   es
    35d1:	57                   	push   di
    35d2:	9a a1 2a ea 35       	call   0x35ea:0x2aa1
    35d7:	bf 57 32             	mov    di,0x3257
    35da:	0e                   	push   cs
    35db:	57                   	push   di
    35dc:	6a 08                	push   0x8
    35de:	6a 02                	push   0x2
    35e0:	6a 00                	push   0x0
    35e2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35e5:	06                   	push   es
    35e6:	57                   	push   di
    35e7:	9a a1 2a ff 35       	call   0x35ff:0x2aa1
    35ec:	bf 64 32             	mov    di,0x3264
    35ef:	0e                   	push   cs
    35f0:	57                   	push   di
    35f1:	6a 08                	push   0x8
    35f3:	6a 02                	push   0x2
    35f5:	6a 00                	push   0x0
    35f7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    35fa:	06                   	push   es
    35fb:	57                   	push   di
    35fc:	9a a1 2a 14 36       	call   0x3614:0x2aa1
    3601:	bf 72 32             	mov    di,0x3272
    3604:	0e                   	push   cs
    3605:	57                   	push   di
    3606:	6a 08                	push   0x8
    3608:	6a 02                	push   0x2
    360a:	6a 00                	push   0x0
    360c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    360f:	06                   	push   es
    3610:	57                   	push   di
    3611:	9a a1 2a 29 36       	call   0x3629:0x2aa1
    3616:	bf 80 32             	mov    di,0x3280
    3619:	0e                   	push   cs
    361a:	57                   	push   di
    361b:	6a 08                	push   0x8
    361d:	6a 02                	push   0x2
    361f:	6a 00                	push   0x0
    3621:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3624:	06                   	push   es
    3625:	57                   	push   di
    3626:	9a a1 2a 3e 36       	call   0x363e:0x2aa1
    362b:	bf 8c 32             	mov    di,0x328c
    362e:	0e                   	push   cs
    362f:	57                   	push   di
    3630:	6a 08                	push   0x8
    3632:	6a 02                	push   0x2
    3634:	6a 00                	push   0x0
    3636:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3639:	06                   	push   es
    363a:	57                   	push   di
    363b:	9a a1 2a 53 36       	call   0x3653:0x2aa1
    3640:	bf 9e 32             	mov    di,0x329e
    3643:	0e                   	push   cs
    3644:	57                   	push   di
    3645:	6a 08                	push   0x8
    3647:	6a 02                	push   0x2
    3649:	6a 00                	push   0x0
    364b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    364e:	06                   	push   es
    364f:	57                   	push   di
    3650:	9a a1 2a 68 36       	call   0x3668:0x2aa1
    3655:	bf ac 32             	mov    di,0x32ac
    3658:	0e                   	push   cs
    3659:	57                   	push   di
    365a:	6a 08                	push   0x8
    365c:	6a 02                	push   0x2
    365e:	6a 00                	push   0x0
    3660:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3663:	06                   	push   es
    3664:	57                   	push   di
    3665:	9a a1 2a 7d 36       	call   0x367d:0x2aa1
    366a:	bf be 32             	mov    di,0x32be
    366d:	0e                   	push   cs
    366e:	57                   	push   di
    366f:	6a 08                	push   0x8
    3671:	6a 02                	push   0x2
    3673:	6a 00                	push   0x0
    3675:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3678:	06                   	push   es
    3679:	57                   	push   di
    367a:	9a a1 2a 92 36       	call   0x3692:0x2aa1
    367f:	bf d0 32             	mov    di,0x32d0
    3682:	0e                   	push   cs
    3683:	57                   	push   di
    3684:	6a 08                	push   0x8
    3686:	6a 02                	push   0x2
    3688:	6a 00                	push   0x0
    368a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    368d:	06                   	push   es
    368e:	57                   	push   di
    368f:	9a a1 2a a7 36       	call   0x36a7:0x2aa1
    3694:	bf d9 32             	mov    di,0x32d9
    3697:	0e                   	push   cs
    3698:	57                   	push   di
    3699:	6a 08                	push   0x8
    369b:	6a 02                	push   0x2
    369d:	6a 00                	push   0x0
    369f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36a2:	06                   	push   es
    36a3:	57                   	push   di
    36a4:	9a a1 2a bc 36       	call   0x36bc:0x2aa1
    36a9:	bf e2 32             	mov    di,0x32e2
    36ac:	0e                   	push   cs
    36ad:	57                   	push   di
    36ae:	6a 03                	push   0x3
    36b0:	6a 00                	push   0x0
    36b2:	6a 00                	push   0x0
    36b4:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36b7:	06                   	push   es
    36b8:	57                   	push   di
    36b9:	9a a1 2a d1 36       	call   0x36d1:0x2aa1
    36be:	bf f7 32             	mov    di,0x32f7
    36c1:	0e                   	push   cs
    36c2:	57                   	push   di
    36c3:	6a 03                	push   0x3
    36c5:	6a 00                	push   0x0
    36c7:	6a 00                	push   0x0
    36c9:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36cc:	06                   	push   es
    36cd:	57                   	push   di
    36ce:	9a a1 2a e6 36       	call   0x36e6:0x2aa1
    36d3:	bf 07 33             	mov    di,0x3307
    36d6:	0e                   	push   cs
    36d7:	57                   	push   di
    36d8:	6a 03                	push   0x3
    36da:	6a 00                	push   0x0
    36dc:	6a 00                	push   0x0
    36de:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36e1:	06                   	push   es
    36e2:	57                   	push   di
    36e3:	9a a1 2a fb 36       	call   0x36fb:0x2aa1
    36e8:	bf 1c 33             	mov    di,0x331c
    36eb:	0e                   	push   cs
    36ec:	57                   	push   di
    36ed:	6a 03                	push   0x3
    36ef:	6a 00                	push   0x0
    36f1:	6a 00                	push   0x0
    36f3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    36f6:	06                   	push   es
    36f7:	57                   	push   di
    36f8:	9a a1 2a 10 37       	call   0x3710:0x2aa1
    36fd:	bf 2f 33             	mov    di,0x332f
    3700:	0e                   	push   cs
    3701:	57                   	push   di
    3702:	6a 03                	push   0x3
    3704:	6a 00                	push   0x0
    3706:	6a 00                	push   0x0
    3708:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    370b:	06                   	push   es
    370c:	57                   	push   di
    370d:	9a a1 2a 70 3a       	call   0x3a70:0x2aa1
    3712:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3715:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    371a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    371d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3720:	bf 37 33             	mov    di,0x3337
    3723:	0e                   	push   cs
    3724:	57                   	push   di
    3725:	bf 3e 33             	mov    di,0x333e
    3728:	0e                   	push   cs
    3729:	57                   	push   di
    372a:	6a 03                	push   0x3
    372c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    372f:	06                   	push   es
    3730:	57                   	push   di
    3731:	9a f6 18 b1 37       	call   0x37b1:0x18f6
    3736:	c9                   	leave
    3737:	ca 04 00             	retf   0x4
    373a:	55                   	push   bp
    373b:	89 e5                	mov    bp,sp
    373d:	b8 a2 01             	mov    ax,0x1a2
    3740:	9a 44 04 93 3a       	call   0x3a93:0x444
    3745:	81 ec a2 01          	sub    sp,0x1a2
    3749:	9b dd 06 52 01       	fld    QWORD PTR ds:0x152
    374e:	9b dd 5e f4          	fstp   QWORD PTR [bp-0xc]
    3752:	90                   	nop
    3753:	9b                   	fwait
    3754:	a1 5c 01             	mov    ax,ds:0x15c
    3757:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    375a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    375d:	89 7e ee             	mov    WORD PTR [bp-0x12],di
    3760:	8c 46 f0             	mov    WORD PTR [bp-0x10],es
    3763:	31 c0                	xor    ax,ax
    3765:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3768:	eb 03                	jmp    0x376d
    376a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    376d:	a1 4e 01             	mov    ax,ds:0x14e
    3770:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    3773:	b8 01 00             	mov    ax,0x1
    3776:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    3779:	7e 03                	jle    0x377e
    377b:	e9 ff 02             	jmp    0x3a7d
    377e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3781:	eb 03                	jmp    0x3786
    3783:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    3786:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3789:	99                   	cwd
    378a:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    378d:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    3790:	c6 46 e0 00          	mov    BYTE PTR [bp-0x20],0x0
    3794:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3797:	99                   	cwd
    3798:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    379b:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    379e:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    37a2:	8d 7e dc             	lea    di,[bp-0x24]
    37a5:	16                   	push   ss
    37a6:	57                   	push   di
    37a7:	6a 01                	push   0x1
    37a9:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    37ac:	06                   	push   es
    37ad:	57                   	push   di
    37ae:	9a 95 28 e6 3a       	call   0x3ae6:0x2895
    37b3:	08 c0                	or     al,al
    37b5:	74 03                	je     0x37ba
    37b7:	e9 b8 02             	jmp    0x3a72
    37ba:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    37bd:	99                   	cwd
    37be:	89 86 5e fe          	mov    WORD PTR [bp-0x1a2],ax
    37c2:	89 96 60 fe          	mov    WORD PTR [bp-0x1a0],dx
    37c6:	c6 86 62 fe 00       	mov    BYTE PTR [bp-0x19e],0x0
    37cb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    37ce:	99                   	cwd
    37cf:	89 86 66 fe          	mov    WORD PTR [bp-0x19a],ax
    37d3:	89 96 68 fe          	mov    WORD PTR [bp-0x198],dx
    37d7:	c6 86 6a fe 00       	mov    BYTE PTR [bp-0x196],0x0
    37dc:	9b dd 46 f4          	fld    QWORD PTR [bp-0xc]
    37e0:	9b db 7e d2          	fstp   TBYTE PTR [bp-0x2e]
    37e4:	8d 46 d2             	lea    ax,[bp-0x2e]
    37e7:	8c d2                	mov    dx,ss
    37e9:	89 86 6e fe          	mov    WORD PTR [bp-0x192],ax
    37ed:	89 96 70 fe          	mov    WORD PTR [bp-0x190],dx
    37f1:	c6 86 72 fe 03       	mov    BYTE PTR [bp-0x18e],0x3
    37f6:	31 c0                	xor    ax,ax
    37f8:	89 86 76 fe          	mov    WORD PTR [bp-0x18a],ax
    37fc:	89 86 78 fe          	mov    WORD PTR [bp-0x188],ax
    3800:	c6 86 7a fe 00       	mov    BYTE PTR [bp-0x186],0x0
    3805:	31 c0                	xor    ax,ax
    3807:	89 86 7e fe          	mov    WORD PTR [bp-0x182],ax
    380b:	89 86 80 fe          	mov    WORD PTR [bp-0x180],ax
    380f:	c6 86 82 fe 00       	mov    BYTE PTR [bp-0x17e],0x0
    3814:	9b dd 46 f4          	fld    QWORD PTR [bp-0xc]
    3818:	9b db 7e c8          	fstp   TBYTE PTR [bp-0x38]
    381c:	8d 46 c8             	lea    ax,[bp-0x38]
    381f:	8c d2                	mov    dx,ss
    3821:	89 86 86 fe          	mov    WORD PTR [bp-0x17a],ax
    3825:	89 96 88 fe          	mov    WORD PTR [bp-0x178],dx
    3829:	c6 86 8a fe 03       	mov    BYTE PTR [bp-0x176],0x3
    382e:	31 c0                	xor    ax,ax
    3830:	89 86 8e fe          	mov    WORD PTR [bp-0x172],ax
    3834:	89 86 90 fe          	mov    WORD PTR [bp-0x170],ax
    3838:	c6 86 92 fe 00       	mov    BYTE PTR [bp-0x16e],0x0
    383d:	31 c0                	xor    ax,ax
    383f:	89 86 96 fe          	mov    WORD PTR [bp-0x16a],ax
    3843:	89 86 98 fe          	mov    WORD PTR [bp-0x168],ax
    3847:	c6 86 9a fe 00       	mov    BYTE PTR [bp-0x166],0x0
    384c:	31 c0                	xor    ax,ax
    384e:	89 86 9e fe          	mov    WORD PTR [bp-0x162],ax
    3852:	89 86 a0 fe          	mov    WORD PTR [bp-0x160],ax
    3856:	c6 86 a2 fe 00       	mov    BYTE PTR [bp-0x15e],0x0
    385b:	31 c0                	xor    ax,ax
    385d:	89 86 a6 fe          	mov    WORD PTR [bp-0x15a],ax
    3861:	89 86 a8 fe          	mov    WORD PTR [bp-0x158],ax
    3865:	c6 86 aa fe 00       	mov    BYTE PTR [bp-0x156],0x0
    386a:	31 c0                	xor    ax,ax
    386c:	89 86 ae fe          	mov    WORD PTR [bp-0x152],ax
    3870:	89 86 b0 fe          	mov    WORD PTR [bp-0x150],ax
    3874:	c6 86 b2 fe 00       	mov    BYTE PTR [bp-0x14e],0x0
    3879:	31 c0                	xor    ax,ax
    387b:	89 86 b6 fe          	mov    WORD PTR [bp-0x14a],ax
    387f:	89 86 b8 fe          	mov    WORD PTR [bp-0x148],ax
    3883:	c6 86 ba fe 00       	mov    BYTE PTR [bp-0x146],0x0
    3888:	31 c0                	xor    ax,ax
    388a:	89 86 be fe          	mov    WORD PTR [bp-0x142],ax
    388e:	89 86 c0 fe          	mov    WORD PTR [bp-0x140],ax
    3892:	c6 86 c2 fe 00       	mov    BYTE PTR [bp-0x13e],0x0
    3897:	31 c0                	xor    ax,ax
    3899:	89 86 c6 fe          	mov    WORD PTR [bp-0x13a],ax
    389d:	89 86 c8 fe          	mov    WORD PTR [bp-0x138],ax
    38a1:	c6 86 ca fe 00       	mov    BYTE PTR [bp-0x136],0x0
    38a6:	31 c0                	xor    ax,ax
    38a8:	89 86 ce fe          	mov    WORD PTR [bp-0x132],ax
    38ac:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    38b0:	c6 86 d2 fe 00       	mov    BYTE PTR [bp-0x12e],0x0
    38b5:	31 c0                	xor    ax,ax
    38b7:	89 86 d6 fe          	mov    WORD PTR [bp-0x12a],ax
    38bb:	89 86 d8 fe          	mov    WORD PTR [bp-0x128],ax
    38bf:	c6 86 da fe 00       	mov    BYTE PTR [bp-0x126],0x0
    38c4:	31 c0                	xor    ax,ax
    38c6:	89 86 de fe          	mov    WORD PTR [bp-0x122],ax
    38ca:	89 86 e0 fe          	mov    WORD PTR [bp-0x120],ax
    38ce:	c6 86 e2 fe 00       	mov    BYTE PTR [bp-0x11e],0x0
    38d3:	31 c0                	xor    ax,ax
    38d5:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    38d9:	89 86 e8 fe          	mov    WORD PTR [bp-0x118],ax
    38dd:	c6 86 ea fe 00       	mov    BYTE PTR [bp-0x116],0x0
    38e2:	31 c0                	xor    ax,ax
    38e4:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
    38e8:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    38ec:	c6 86 f2 fe 00       	mov    BYTE PTR [bp-0x10e],0x0
    38f1:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    38f4:	99                   	cwd
    38f5:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
    38f9:	89 96 f8 fe          	mov    WORD PTR [bp-0x108],dx
    38fd:	c6 86 fa fe 00       	mov    BYTE PTR [bp-0x106],0x0
    3902:	c7 86 fe fe 01 00    	mov    WORD PTR [bp-0x102],0x1
    3908:	c7 86 00 ff 00 00    	mov    WORD PTR [bp-0x100],0x0
    390e:	c6 86 02 ff 00       	mov    BYTE PTR [bp-0xfe],0x0
    3913:	9b dd 46 f4          	fld    QWORD PTR [bp-0xc]
    3917:	9b db 7e be          	fstp   TBYTE PTR [bp-0x42]
    391b:	8d 46 be             	lea    ax,[bp-0x42]
    391e:	8c d2                	mov    dx,ss
    3920:	89 86 06 ff          	mov    WORD PTR [bp-0xfa],ax
    3924:	89 96 08 ff          	mov    WORD PTR [bp-0xf8],dx
    3928:	c6 86 0a ff 03       	mov    BYTE PTR [bp-0xf6],0x3
    392d:	31 c0                	xor    ax,ax
    392f:	89 86 0e ff          	mov    WORD PTR [bp-0xf2],ax
    3933:	89 86 10 ff          	mov    WORD PTR [bp-0xf0],ax
    3937:	c6 86 12 ff 00       	mov    BYTE PTR [bp-0xee],0x0
    393c:	31 c0                	xor    ax,ax
    393e:	89 86 16 ff          	mov    WORD PTR [bp-0xea],ax
    3942:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
    3946:	c6 86 1a ff 00       	mov    BYTE PTR [bp-0xe6],0x0
    394b:	31 c0                	xor    ax,ax
    394d:	89 86 1e ff          	mov    WORD PTR [bp-0xe2],ax
    3951:	89 86 20 ff          	mov    WORD PTR [bp-0xe0],ax
    3955:	c6 86 22 ff 00       	mov    BYTE PTR [bp-0xde],0x0
    395a:	31 c0                	xor    ax,ax
    395c:	89 86 26 ff          	mov    WORD PTR [bp-0xda],ax
    3960:	89 86 28 ff          	mov    WORD PTR [bp-0xd8],ax
    3964:	c6 86 2a ff 00       	mov    BYTE PTR [bp-0xd6],0x0
    3969:	31 c0                	xor    ax,ax
    396b:	89 86 2e ff          	mov    WORD PTR [bp-0xd2],ax
    396f:	89 86 30 ff          	mov    WORD PTR [bp-0xd0],ax
    3973:	c6 86 32 ff 00       	mov    BYTE PTR [bp-0xce],0x0
    3978:	31 c0                	xor    ax,ax
    397a:	89 86 36 ff          	mov    WORD PTR [bp-0xca],ax
    397e:	89 86 38 ff          	mov    WORD PTR [bp-0xc8],ax
    3982:	c6 86 3a ff 00       	mov    BYTE PTR [bp-0xc6],0x0
    3987:	31 c0                	xor    ax,ax
    3989:	89 86 3e ff          	mov    WORD PTR [bp-0xc2],ax
    398d:	89 86 40 ff          	mov    WORD PTR [bp-0xc0],ax
    3991:	c6 86 42 ff 00       	mov    BYTE PTR [bp-0xbe],0x0
    3996:	31 c0                	xor    ax,ax
    3998:	89 86 46 ff          	mov    WORD PTR [bp-0xba],ax
    399c:	89 86 48 ff          	mov    WORD PTR [bp-0xb8],ax
    39a0:	c6 86 4a ff 00       	mov    BYTE PTR [bp-0xb6],0x0
    39a5:	31 c0                	xor    ax,ax
    39a7:	89 86 4e ff          	mov    WORD PTR [bp-0xb2],ax
    39ab:	89 86 50 ff          	mov    WORD PTR [bp-0xb0],ax
    39af:	c6 86 52 ff 00       	mov    BYTE PTR [bp-0xae],0x0
    39b4:	31 c0                	xor    ax,ax
    39b6:	89 86 56 ff          	mov    WORD PTR [bp-0xaa],ax
    39ba:	89 86 58 ff          	mov    WORD PTR [bp-0xa8],ax
    39be:	c6 86 5a ff 00       	mov    BYTE PTR [bp-0xa6],0x0
    39c3:	31 c0                	xor    ax,ax
    39c5:	89 86 5e ff          	mov    WORD PTR [bp-0xa2],ax
    39c9:	89 86 60 ff          	mov    WORD PTR [bp-0xa0],ax
    39cd:	c6 86 62 ff 00       	mov    BYTE PTR [bp-0x9e],0x0
    39d2:	31 c0                	xor    ax,ax
    39d4:	89 86 66 ff          	mov    WORD PTR [bp-0x9a],ax
    39d8:	89 86 68 ff          	mov    WORD PTR [bp-0x98],ax
    39dc:	c6 86 6a ff 00       	mov    BYTE PTR [bp-0x96],0x0
    39e1:	31 c0                	xor    ax,ax
    39e3:	89 86 6e ff          	mov    WORD PTR [bp-0x92],ax
    39e7:	89 86 70 ff          	mov    WORD PTR [bp-0x90],ax
    39eb:	c6 86 72 ff 00       	mov    BYTE PTR [bp-0x8e],0x0
    39f0:	31 c0                	xor    ax,ax
    39f2:	89 86 76 ff          	mov    WORD PTR [bp-0x8a],ax
    39f6:	89 86 78 ff          	mov    WORD PTR [bp-0x88],ax
    39fa:	c6 86 7a ff 00       	mov    BYTE PTR [bp-0x86],0x0
    39ff:	31 c0                	xor    ax,ax
    3a01:	89 86 7e ff          	mov    WORD PTR [bp-0x82],ax
    3a05:	89 46 80             	mov    WORD PTR [bp-0x80],ax
    3a08:	c6 46 82 00          	mov    BYTE PTR [bp-0x7e],0x0
    3a0c:	31 c0                	xor    ax,ax
    3a0e:	89 46 86             	mov    WORD PTR [bp-0x7a],ax
    3a11:	89 46 88             	mov    WORD PTR [bp-0x78],ax
    3a14:	c6 46 8a 00          	mov    BYTE PTR [bp-0x76],0x0
    3a18:	31 c0                	xor    ax,ax
    3a1a:	89 46 8e             	mov    WORD PTR [bp-0x72],ax
    3a1d:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    3a20:	c6 46 92 00          	mov    BYTE PTR [bp-0x6e],0x0
    3a24:	31 c0                	xor    ax,ax
    3a26:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    3a29:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    3a2c:	c6 46 9a 00          	mov    BYTE PTR [bp-0x66],0x0
    3a30:	31 c0                	xor    ax,ax
    3a32:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    3a35:	89 46 a0             	mov    WORD PTR [bp-0x60],ax
    3a38:	c6 46 a2 00          	mov    BYTE PTR [bp-0x5e],0x0
    3a3c:	31 c0                	xor    ax,ax
    3a3e:	89 46 a6             	mov    WORD PTR [bp-0x5a],ax
    3a41:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    3a44:	c6 46 aa 00          	mov    BYTE PTR [bp-0x56],0x0
    3a48:	31 c0                	xor    ax,ax
    3a4a:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    3a4d:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    3a50:	c6 46 b2 00          	mov    BYTE PTR [bp-0x4e],0x0
    3a54:	31 c0                	xor    ax,ax
    3a56:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    3a59:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    3a5c:	c6 46 ba 00          	mov    BYTE PTR [bp-0x46],0x0
    3a60:	8d be 5e fe          	lea    di,[bp-0x1a2]
    3a64:	16                   	push   ss
    3a65:	57                   	push   di
    3a66:	6a 2b                	push   0x2b
    3a68:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    3a6b:	06                   	push   es
    3a6c:	57                   	push   di
    3a6d:	9a 21 53 72 3d       	call   0x3d72:0x5321
    3a72:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3a75:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    3a78:	74 03                	je     0x3a7d
    3a7a:	e9 06 fd             	jmp    0x3783
    3a7d:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3a81:	74 03                	je     0x3a86
    3a83:	e9 e4 fc             	jmp    0x376a
    3a86:	c9                   	leave
    3a87:	ca 04 00             	retf   0x4
    3a8a:	55                   	push   bp
    3a8b:	89 e5                	mov    bp,sp
    3a8d:	b8 78 01             	mov    ax,0x178
    3a90:	9a 44 04 25 3f       	call   0x3f25:0x444
    3a95:	81 ec 78 01          	sub    sp,0x178
    3a99:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    3a9c:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    3a9f:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    3aa2:	a1 4e 01             	mov    ax,ds:0x14e
    3aa5:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3aa8:	b8 01 00             	mov    ax,0x1
    3aab:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3aae:	7e 03                	jle    0x3ab3
    3ab0:	e9 cc 02             	jmp    0x3d7f
    3ab3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3ab6:	eb 03                	jmp    0x3abb
    3ab8:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3abb:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3abe:	99                   	cwd
    3abf:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    3ac2:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    3ac5:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    3ac9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3acc:	99                   	cwd
    3acd:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    3ad0:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    3ad3:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    3ad7:	8d 7e e8             	lea    di,[bp-0x18]
    3ada:	16                   	push   ss
    3adb:	57                   	push   di
    3adc:	6a 01                	push   0x1
    3ade:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3ae1:	06                   	push   es
    3ae2:	57                   	push   di
    3ae3:	9a 95 28 ab 41       	call   0x41ab:0x2895
    3ae8:	08 c0                	or     al,al
    3aea:	74 03                	je     0x3aef
    3aec:	e9 85 02             	jmp    0x3d74
    3aef:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    3af2:	99                   	cwd
    3af3:	89 86 88 fe          	mov    WORD PTR [bp-0x178],ax
    3af7:	89 96 8a fe          	mov    WORD PTR [bp-0x176],dx
    3afb:	c6 86 8c fe 00       	mov    BYTE PTR [bp-0x174],0x0
    3b00:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3b03:	99                   	cwd
    3b04:	89 86 90 fe          	mov    WORD PTR [bp-0x170],ax
    3b08:	89 96 92 fe          	mov    WORD PTR [bp-0x16e],dx
    3b0c:	c6 86 94 fe 00       	mov    BYTE PTR [bp-0x16c],0x0
    3b11:	31 c0                	xor    ax,ax
    3b13:	89 86 98 fe          	mov    WORD PTR [bp-0x168],ax
    3b17:	89 86 9a fe          	mov    WORD PTR [bp-0x166],ax
    3b1b:	c6 86 9c fe 00       	mov    BYTE PTR [bp-0x164],0x0
    3b20:	31 c0                	xor    ax,ax
    3b22:	89 86 a0 fe          	mov    WORD PTR [bp-0x160],ax
    3b26:	89 86 a2 fe          	mov    WORD PTR [bp-0x15e],ax
    3b2a:	c6 86 a4 fe 00       	mov    BYTE PTR [bp-0x15c],0x0
    3b2f:	31 c0                	xor    ax,ax
    3b31:	89 86 a8 fe          	mov    WORD PTR [bp-0x158],ax
    3b35:	89 86 aa fe          	mov    WORD PTR [bp-0x156],ax
    3b39:	c6 86 ac fe 00       	mov    BYTE PTR [bp-0x154],0x0
    3b3e:	31 c0                	xor    ax,ax
    3b40:	89 86 b0 fe          	mov    WORD PTR [bp-0x150],ax
    3b44:	89 86 b2 fe          	mov    WORD PTR [bp-0x14e],ax
    3b48:	c6 86 b4 fe 00       	mov    BYTE PTR [bp-0x14c],0x0
    3b4d:	31 c0                	xor    ax,ax
    3b4f:	89 86 b8 fe          	mov    WORD PTR [bp-0x148],ax
    3b53:	89 86 ba fe          	mov    WORD PTR [bp-0x146],ax
    3b57:	c6 86 bc fe 00       	mov    BYTE PTR [bp-0x144],0x0
    3b5c:	31 c0                	xor    ax,ax
    3b5e:	89 86 c0 fe          	mov    WORD PTR [bp-0x140],ax
    3b62:	89 86 c2 fe          	mov    WORD PTR [bp-0x13e],ax
    3b66:	c6 86 c4 fe 00       	mov    BYTE PTR [bp-0x13c],0x0
    3b6b:	31 c0                	xor    ax,ax
    3b6d:	89 86 c8 fe          	mov    WORD PTR [bp-0x138],ax
    3b71:	89 86 ca fe          	mov    WORD PTR [bp-0x136],ax
    3b75:	c6 86 cc fe 00       	mov    BYTE PTR [bp-0x134],0x0
    3b7a:	31 c0                	xor    ax,ax
    3b7c:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    3b80:	89 86 d2 fe          	mov    WORD PTR [bp-0x12e],ax
    3b84:	c6 86 d4 fe 00       	mov    BYTE PTR [bp-0x12c],0x0
    3b89:	31 c0                	xor    ax,ax
    3b8b:	89 86 d8 fe          	mov    WORD PTR [bp-0x128],ax
    3b8f:	89 86 da fe          	mov    WORD PTR [bp-0x126],ax
    3b93:	c6 86 dc fe 00       	mov    BYTE PTR [bp-0x124],0x0
    3b98:	31 c0                	xor    ax,ax
    3b9a:	89 86 e0 fe          	mov    WORD PTR [bp-0x120],ax
    3b9e:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    3ba2:	c6 86 e4 fe 00       	mov    BYTE PTR [bp-0x11c],0x0
    3ba7:	31 c0                	xor    ax,ax
    3ba9:	89 86 e8 fe          	mov    WORD PTR [bp-0x118],ax
    3bad:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    3bb1:	c6 86 ec fe 00       	mov    BYTE PTR [bp-0x114],0x0
    3bb6:	31 c0                	xor    ax,ax
    3bb8:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    3bbc:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    3bc0:	c6 86 f4 fe 00       	mov    BYTE PTR [bp-0x10c],0x0
    3bc5:	31 c0                	xor    ax,ax
    3bc7:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    3bcb:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    3bcf:	c6 86 fc fe 00       	mov    BYTE PTR [bp-0x104],0x0
    3bd4:	31 c0                	xor    ax,ax
    3bd6:	89 86 00 ff          	mov    WORD PTR [bp-0x100],ax
    3bda:	89 86 02 ff          	mov    WORD PTR [bp-0xfe],ax
    3bde:	c6 86 04 ff 00       	mov    BYTE PTR [bp-0xfc],0x0
    3be3:	31 c0                	xor    ax,ax
    3be5:	89 86 08 ff          	mov    WORD PTR [bp-0xf8],ax
    3be9:	89 86 0a ff          	mov    WORD PTR [bp-0xf6],ax
    3bed:	c6 86 0c ff 00       	mov    BYTE PTR [bp-0xf4],0x0
    3bf2:	31 c0                	xor    ax,ax
    3bf4:	89 86 10 ff          	mov    WORD PTR [bp-0xf0],ax
    3bf8:	89 86 12 ff          	mov    WORD PTR [bp-0xee],ax
    3bfc:	c6 86 14 ff 00       	mov    BYTE PTR [bp-0xec],0x0
    3c01:	31 c0                	xor    ax,ax
    3c03:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
    3c07:	89 86 1a ff          	mov    WORD PTR [bp-0xe6],ax
    3c0b:	c6 86 1c ff 00       	mov    BYTE PTR [bp-0xe4],0x0
    3c10:	31 c0                	xor    ax,ax
    3c12:	89 86 20 ff          	mov    WORD PTR [bp-0xe0],ax
    3c16:	89 86 22 ff          	mov    WORD PTR [bp-0xde],ax
    3c1a:	c6 86 24 ff 00       	mov    BYTE PTR [bp-0xdc],0x0
    3c1f:	c7 86 28 ff 01 00    	mov    WORD PTR [bp-0xd8],0x1
    3c25:	c7 86 2a ff 00 00    	mov    WORD PTR [bp-0xd6],0x0
    3c2b:	c6 86 2c ff 00       	mov    BYTE PTR [bp-0xd4],0x0
    3c30:	31 c0                	xor    ax,ax
    3c32:	89 86 30 ff          	mov    WORD PTR [bp-0xd0],ax
    3c36:	89 86 32 ff          	mov    WORD PTR [bp-0xce],ax
    3c3a:	c6 86 34 ff 00       	mov    BYTE PTR [bp-0xcc],0x0
    3c3f:	31 c0                	xor    ax,ax
    3c41:	89 86 38 ff          	mov    WORD PTR [bp-0xc8],ax
    3c45:	89 86 3a ff          	mov    WORD PTR [bp-0xc6],ax
    3c49:	c6 86 3c ff 00       	mov    BYTE PTR [bp-0xc4],0x0
    3c4e:	31 c0                	xor    ax,ax
    3c50:	89 86 40 ff          	mov    WORD PTR [bp-0xc0],ax
    3c54:	89 86 42 ff          	mov    WORD PTR [bp-0xbe],ax
    3c58:	c6 86 44 ff 00       	mov    BYTE PTR [bp-0xbc],0x0
    3c5d:	31 c0                	xor    ax,ax
    3c5f:	89 86 48 ff          	mov    WORD PTR [bp-0xb8],ax
    3c63:	89 86 4a ff          	mov    WORD PTR [bp-0xb6],ax
    3c67:	c6 86 4c ff 00       	mov    BYTE PTR [bp-0xb4],0x0
    3c6c:	31 c0                	xor    ax,ax
    3c6e:	89 86 50 ff          	mov    WORD PTR [bp-0xb0],ax
    3c72:	89 86 52 ff          	mov    WORD PTR [bp-0xae],ax
    3c76:	c6 86 54 ff 00       	mov    BYTE PTR [bp-0xac],0x0
    3c7b:	31 c0                	xor    ax,ax
    3c7d:	89 86 58 ff          	mov    WORD PTR [bp-0xa8],ax
    3c81:	89 86 5a ff          	mov    WORD PTR [bp-0xa6],ax
    3c85:	c6 86 5c ff 00       	mov    BYTE PTR [bp-0xa4],0x0
    3c8a:	31 c0                	xor    ax,ax
    3c8c:	89 86 60 ff          	mov    WORD PTR [bp-0xa0],ax
    3c90:	89 86 62 ff          	mov    WORD PTR [bp-0x9e],ax
    3c94:	c6 86 64 ff 00       	mov    BYTE PTR [bp-0x9c],0x0
    3c99:	31 c0                	xor    ax,ax
    3c9b:	89 86 68 ff          	mov    WORD PTR [bp-0x98],ax
    3c9f:	89 86 6a ff          	mov    WORD PTR [bp-0x96],ax
    3ca3:	c6 86 6c ff 00       	mov    BYTE PTR [bp-0x94],0x0
    3ca8:	31 c0                	xor    ax,ax
    3caa:	89 86 70 ff          	mov    WORD PTR [bp-0x90],ax
    3cae:	89 86 72 ff          	mov    WORD PTR [bp-0x8e],ax
    3cb2:	c6 86 74 ff 00       	mov    BYTE PTR [bp-0x8c],0x0
    3cb7:	31 c0                	xor    ax,ax
    3cb9:	89 86 78 ff          	mov    WORD PTR [bp-0x88],ax
    3cbd:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    3cc1:	c6 86 7c ff 00       	mov    BYTE PTR [bp-0x84],0x0
    3cc6:	31 c0                	xor    ax,ax
    3cc8:	89 46 80             	mov    WORD PTR [bp-0x80],ax
    3ccb:	89 46 82             	mov    WORD PTR [bp-0x7e],ax
    3cce:	c6 46 84 00          	mov    BYTE PTR [bp-0x7c],0x0
    3cd2:	31 c0                	xor    ax,ax
    3cd4:	89 46 88             	mov    WORD PTR [bp-0x78],ax
    3cd7:	89 46 8a             	mov    WORD PTR [bp-0x76],ax
    3cda:	c6 46 8c 00          	mov    BYTE PTR [bp-0x74],0x0
    3cde:	31 c0                	xor    ax,ax
    3ce0:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    3ce3:	89 46 92             	mov    WORD PTR [bp-0x6e],ax
    3ce6:	c6 46 94 00          	mov    BYTE PTR [bp-0x6c],0x0
    3cea:	31 c0                	xor    ax,ax
    3cec:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    3cef:	89 46 9a             	mov    WORD PTR [bp-0x66],ax
    3cf2:	c6 46 9c 00          	mov    BYTE PTR [bp-0x64],0x0
    3cf6:	31 c0                	xor    ax,ax
    3cf8:	89 46 a0             	mov    WORD PTR [bp-0x60],ax
    3cfb:	89 46 a2             	mov    WORD PTR [bp-0x5e],ax
    3cfe:	c6 46 a4 00          	mov    BYTE PTR [bp-0x5c],0x0
    3d02:	31 c0                	xor    ax,ax
    3d04:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    3d07:	89 46 aa             	mov    WORD PTR [bp-0x56],ax
    3d0a:	c6 46 ac 00          	mov    BYTE PTR [bp-0x54],0x0
    3d0e:	31 c0                	xor    ax,ax
    3d10:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    3d13:	89 46 b2             	mov    WORD PTR [bp-0x4e],ax
    3d16:	c6 46 b4 00          	mov    BYTE PTR [bp-0x4c],0x0
    3d1a:	31 c0                	xor    ax,ax
    3d1c:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    3d1f:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    3d22:	c6 46 bc 00          	mov    BYTE PTR [bp-0x44],0x0
    3d26:	31 c0                	xor    ax,ax
    3d28:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    3d2b:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    3d2e:	c6 46 c4 00          	mov    BYTE PTR [bp-0x3c],0x0
    3d32:	31 c0                	xor    ax,ax
    3d34:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    3d37:	89 46 ca             	mov    WORD PTR [bp-0x36],ax
    3d3a:	c6 46 cc 00          	mov    BYTE PTR [bp-0x34],0x0
    3d3e:	31 c0                	xor    ax,ax
    3d40:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    3d43:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    3d46:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
    3d4a:	31 c0                	xor    ax,ax
    3d4c:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    3d4f:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    3d52:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
    3d56:	31 c0                	xor    ax,ax
    3d58:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    3d5b:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    3d5e:	c6 46 e4 00          	mov    BYTE PTR [bp-0x1c],0x0
    3d62:	8d be 88 fe          	lea    di,[bp-0x178]
    3d66:	16                   	push   ss
    3d67:	57                   	push   di
    3d68:	6a 2b                	push   0x2b
    3d6a:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    3d6d:	06                   	push   es
    3d6e:	57                   	push   di
    3d6f:	9a 21 53 50 3f       	call   0x3f50:0x5321
    3d74:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3d77:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3d7a:	74 03                	je     0x3d7f
    3d7c:	e9 39 fd             	jmp    0x3ab8
    3d7f:	c9                   	leave
    3d80:	ca 06 00             	retf   0x6
    3d83:	09 50 65             	or     WORD PTR [bx+si+0x65],dx
    3d86:	72 69                	jb     0x3df1
    3d88:	6f                   	outs   dx,WORD PTR ds:[si]
    3d89:	64 65 4e             	fs gs dec si
    3d8c:	6f                   	outs   dx,WORD PTR ds:[si]
    3d8d:	0c 45                	or     al,0x45
    3d8f:	6e                   	outs   dx,BYTE PTR ds:[si]
    3d90:	74 72                	je     0x3e04
    3d92:	65 70 72             	gs jo  0x3e07
    3d95:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    3d9a:	09 50 72             	or     WORD PTR [bx+si+0x72],dx
    3d9d:	6f                   	outs   dx,WORD PTR ds:[si]
    3d9e:	64 75 69             	fs jne 0x3e0a
    3da1:	74 4e                	je     0x3df1
    3da3:	6f                   	outs   dx,WORD PTR ds:[si]
    3da4:	09 45 66             	or     WORD PTR [di+0x66],ax
    3da7:	66 65 74 50          	data32 gs je 0x3dfb
    3dab:	72 69                	jb     0x3e16
    3dad:	78 08                	js     0x3db7
    3daf:	45                   	inc    bp
    3db0:	66 66 65 74 50       	data32 data32 gs je 0x3e05
    3db5:	75 62                	jne    0x3e19
    3db7:	07                   	pop    es
    3db8:	45                   	inc    bp
    3db9:	66 66 65 74 46       	data32 data32 gs je 0x3e04
    3dbe:	56                   	push   si
    3dbf:	0b 45 66             	or     ax,WORD PTR [di+0x66]
    3dc2:	66 65 74 43          	data32 gs je 0x3e09
    3dc6:	72 65                	jb     0x3e2d
    3dc8:	64 69 74 0c 45 66    	imul   si,WORD PTR fs:[si+0xc],0x6645
    3dce:	66 65 74 51          	data32 gs je 0x3e23
    3dd2:	75 61                	jne    0x3e35
    3dd4:	6c                   	ins    BYTE PTR es:[di],dx
    3dd5:	69 74 65 0b 45       	imul   si,WORD PTR [si+0x65],0x450b
    3dda:	66 66 65 74 47       	data32 data32 gs je 0x3e26
    3ddf:	6c                   	ins    BYTE PTR es:[di],dx
    3de0:	6f                   	outs   dx,WORD PTR ds:[si]
    3de1:	62 61 6c             	bound  sp,DWORD PTR [bx+di+0x6c]
    3de4:	07                   	pop    es
    3de5:	44                   	inc    sp
    3de6:	65 6d                	gs ins WORD PTR es:[di],dx
    3de8:	61                   	popa
    3de9:	6e                   	outs   dx,BYTE PTR ds:[si]
    3dea:	64 65 06             	fs gs push es
    3ded:	56                   	push   si
    3dee:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3df0:	74 65                	je     0x3e57
    3df2:	73 14                	jae    0x3e08
    3df4:	44                   	inc    sp
    3df5:	65 6d                	gs ins WORD PTR es:[di],dx
    3df7:	61                   	popa
    3df8:	6e                   	outs   dx,BYTE PTR ds:[si]
    3df9:	64 65 4e             	fs gs dec si
    3dfc:	6f                   	outs   dx,WORD PTR ds:[si]
    3dfd:	6e                   	outs   dx,BYTE PTR ds:[si]
    3dfe:	53                   	push   bx
    3dff:	61                   	popa
    3e00:	74 69                	je     0x3e6b
    3e02:	73 66                	jae    0x3e6a
    3e04:	61                   	popa
    3e05:	69 74 65 0c 56       	imul   si,WORD PTR [si+0x65],0x560c
    3e0a:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e0c:	74 65                	je     0x3e73
    3e0e:	73 50                	jae    0x3e60
    3e10:	72 69                	jb     0x3e7b
    3e12:	73 65                	jae    0x3e79
    3e14:	73 0a                	jae    0x3e20
    3e16:	50                   	push   ax
    3e17:	61                   	popa
    3e18:	72 74                	jb     0x3e8e
    3e1a:	4d                   	dec    bp
    3e1b:	61                   	popa
    3e1c:	72 63                	jb     0x3e81
    3e1e:	68 65 08             	push   0x865
    3e21:	51                   	push   cx
    3e22:	74 65                	je     0x3e89
    3e24:	53                   	push   bx
    3e25:	74 6f                	je     0x3e96
    3e27:	63 6b 0b             	arpl   WORD PTR [bp+di+0xb],bp
    3e2a:	56                   	push   si
    3e2b:	61                   	popa
    3e2c:	6c                   	ins    BYTE PTR es:[di],dx
    3e2d:	65 75 72             	gs jne 0x3ea2
    3e30:	53                   	push   bx
    3e31:	74 6f                	je     0x3ea2
    3e33:	63 6b 10             	arpl   WORD PTR [bp+di+0x10],bp
    3e36:	44                   	inc    sp
    3e37:	6f                   	outs   dx,WORD PTR ds:[si]
    3e38:	74 41                	je     0x3e7b
    3e3a:	6d                   	ins    WORD PTR es:[di],dx
    3e3b:	6f                   	outs   dx,WORD PTR ds:[si]
    3e3c:	72 74                	jb     0x3eb2
    3e3e:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    3e43:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e45:	74 10                	je     0x3e57
    3e47:	56                   	push   si
    3e48:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e4a:	74 65                	je     0x3eb1
    3e4c:	73 53                	jae    0x3ea1
    3e4e:	6f                   	outs   dx,WORD PTR ds:[si]
    3e4f:	6c                   	ins    BYTE PTR es:[di],dx
    3e50:	64 65 65 73 51       	fs gs gs jae 0x3ea6
    3e55:	74 65                	je     0x3ebc
    3e57:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    3e5a:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e5b:	74 65                	je     0x3ec2
    3e5d:	73 53                	jae    0x3eb2
    3e5f:	6f                   	outs   dx,WORD PTR ds:[si]
    3e60:	6c                   	ins    BYTE PTR es:[di],dx
    3e61:	64 65 65 73 50       	fs gs gs jae 0x3eb6
    3e66:	72 69                	jb     0x3ed1
    3e68:	78 0c                	js     0x3e76
    3e6a:	56                   	push   si
    3e6b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3e6d:	74 65                	je     0x3ed4
    3e6f:	73 53                	jae    0x3ec4
    3e71:	70 65                	jo     0x3ed8
    3e73:	51                   	push   cx
    3e74:	74 65                	je     0x3edb
    3e76:	0d 56 65             	or     ax,0x6556
    3e79:	6e                   	outs   dx,BYTE PTR ds:[si]
    3e7a:	74 65                	je     0x3ee1
    3e7c:	73 53                	jae    0x3ed1
    3e7e:	70 65                	jo     0x3ee5
    3e80:	50                   	push   ax
    3e81:	72 69                	jb     0x3eec
    3e83:	78 11                	js     0x3e96
    3e85:	4d                   	dec    bp
    3e86:	61                   	popa
    3e87:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    3e8c:	76 72                	jbe    0x3f00
    3e8e:	65 44                	gs inc sp
    3e90:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    3e95:	65 0b 48 65          	or     cx,WORD PTR gs:[bx+si+0x65]
    3e99:	75 72                	jne    0x3f0d
    3e9b:	65 73 53             	gs jae 0x3ef1
    3e9e:	75 70                	jne    0x3f10
    3ea0:	50                   	push   ax
    3ea1:	63 13                	arpl   WORD PTR [bp+di],dx
    3ea3:	43                   	inc    bx
    3ea4:	6f                   	outs   dx,WORD PTR ds:[si]
    3ea5:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ea6:	73 6f                	jae    0x3f17
    3ea8:	6d                   	ins    WORD PTR es:[di],dx
    3ea9:	6d                   	ins    WORD PTR es:[di],dx
    3eaa:	61                   	popa
    3eab:	74 69                	je     0x3f16
    3ead:	6f                   	outs   dx,WORD PTR ds:[si]
    3eae:	6e                   	outs   dx,BYTE PTR ds:[si]
    3eaf:	4d                   	dec    bp
    3eb0:	61                   	popa
    3eb1:	74 69                	je     0x3f1c
    3eb3:	65 72 65             	gs jb  0x3f1b
    3eb6:	0e                   	push   cs
    3eb7:	52                   	push   dx
    3eb8:	65 6d                	gs ins WORD PTR es:[di],dx
    3eba:	75 6e                	jne    0x3f2a
    3ebc:	65 72 61             	gs jb  0x3f20
    3ebf:	74 69                	je     0x3f2a
    3ec1:	6f                   	outs   dx,WORD PTR ds:[si]
    3ec2:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ec3:	46                   	inc    si
    3ec4:	56                   	push   si
    3ec5:	15 54 65             	adc    ax,0x6554
    3ec8:	6d                   	ins    WORD PTR es:[di],dx
    3ec9:	70 73                	jo     0x3f3e
    3ecb:	46                   	inc    si
    3ecc:	61                   	popa
    3ecd:	62 72 69             	bound  si,DWORD PTR [bp+si+0x69]
    3ed0:	63 61 74             	arpl   WORD PTR [bx+di+0x74],sp
    3ed3:	69 6f 6e 46 75       	imul   bp,WORD PTR [bx+0x6e],0x7546
    3ed8:	74 75                	je     0x3f4f
    3eda:	72 10                	jb     0x3eec
    3edc:	50                   	push   ax
    3edd:	72 6f                	jb     0x3f4e
    3edf:	64 75 63             	fs jne 0x3f45
    3ee2:	74 69                	je     0x3f4d
    3ee4:	6f                   	outs   dx,WORD PTR ds:[si]
    3ee5:	6e                   	outs   dx,BYTE PTR ds:[si]
    3ee6:	52                   	push   dx
    3ee7:	65 65 6c             	gs gs ins BYTE PTR es:[di],dx
    3eea:	6c                   	ins    BYTE PTR es:[di],dx
    3eeb:	65 07                	gs pop es
    3eed:	53                   	push   bx
    3eee:	70 65                	jo     0x3f55
    3ef0:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
    3ef3:	6c                   	ins    BYTE PTR es:[di],dx
    3ef4:	06                   	push   es
    3ef5:	4d                   	dec    bp
    3ef6:	61                   	popa
    3ef7:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    3efa:	6e                   	outs   dx,BYTE PTR ds:[si]
    3efb:	20 50 65             	and    BYTE PTR [bx+si+0x65],dl
    3efe:	72 69                	jb     0x3f69
    3f00:	6f                   	outs   dx,WORD PTR ds:[si]
    3f01:	64 65 4e             	fs gs dec si
    3f04:	6f                   	outs   dx,WORD PTR ds:[si]
    3f05:	3b 45 6e             	cmp    ax,WORD PTR [di+0x6e]
    3f08:	74 72                	je     0x3f7c
    3f0a:	65 70 72             	gs jo  0x3f7f
    3f0d:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
    3f12:	3b 50 72             	cmp    dx,WORD PTR [bx+si+0x72]
    3f15:	6f                   	outs   dx,WORD PTR ds:[si]
    3f16:	64 75 69             	fs jne 0x3f82
    3f19:	74 4e                	je     0x3f69
    3f1b:	6f                   	outs   dx,WORD PTR ds:[si]
    3f1c:	55                   	push   bp
    3f1d:	89 e5                	mov    bp,sp
    3f1f:	b8 08 00             	mov    ax,0x8
    3f22:	9a 44 04 cc 41       	call   0x41cc:0x444
    3f27:	83 ec 08             	sub    sp,0x8
    3f2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f2d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    3f30:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    3f33:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3f37:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    3f3a:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    3f3d:	bf 83 3d             	mov    di,0x3d83
    3f40:	0e                   	push   cs
    3f41:	57                   	push   di
    3f42:	6a 03                	push   0x3
    3f44:	6a 00                	push   0x0
    3f46:	6a 00                	push   0x0
    3f48:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3f4b:	06                   	push   es
    3f4c:	57                   	push   di
    3f4d:	9a a1 2a 65 3f       	call   0x3f65:0x2aa1
    3f52:	bf 8d 3d             	mov    di,0x3d8d
    3f55:	0e                   	push   cs
    3f56:	57                   	push   di
    3f57:	6a 03                	push   0x3
    3f59:	6a 00                	push   0x0
    3f5b:	6a 00                	push   0x0
    3f5d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3f60:	06                   	push   es
    3f61:	57                   	push   di
    3f62:	9a a1 2a 7a 3f       	call   0x3f7a:0x2aa1
    3f67:	bf 9a 3d             	mov    di,0x3d9a
    3f6a:	0e                   	push   cs
    3f6b:	57                   	push   di
    3f6c:	6a 03                	push   0x3
    3f6e:	6a 00                	push   0x0
    3f70:	6a 00                	push   0x0
    3f72:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3f75:	06                   	push   es
    3f76:	57                   	push   di
    3f77:	9a a1 2a 8f 3f       	call   0x3f8f:0x2aa1
    3f7c:	bf a4 3d             	mov    di,0x3da4
    3f7f:	0e                   	push   cs
    3f80:	57                   	push   di
    3f81:	6a 08                	push   0x8
    3f83:	6a 02                	push   0x2
    3f85:	6a 00                	push   0x0
    3f87:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3f8a:	06                   	push   es
    3f8b:	57                   	push   di
    3f8c:	9a a1 2a a4 3f       	call   0x3fa4:0x2aa1
    3f91:	bf ae 3d             	mov    di,0x3dae
    3f94:	0e                   	push   cs
    3f95:	57                   	push   di
    3f96:	6a 08                	push   0x8
    3f98:	6a 02                	push   0x2
    3f9a:	6a 00                	push   0x0
    3f9c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3f9f:	06                   	push   es
    3fa0:	57                   	push   di
    3fa1:	9a a1 2a b9 3f       	call   0x3fb9:0x2aa1
    3fa6:	bf b7 3d             	mov    di,0x3db7
    3fa9:	0e                   	push   cs
    3faa:	57                   	push   di
    3fab:	6a 08                	push   0x8
    3fad:	6a 02                	push   0x2
    3faf:	6a 00                	push   0x0
    3fb1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3fb4:	06                   	push   es
    3fb5:	57                   	push   di
    3fb6:	9a a1 2a ce 3f       	call   0x3fce:0x2aa1
    3fbb:	bf bf 3d             	mov    di,0x3dbf
    3fbe:	0e                   	push   cs
    3fbf:	57                   	push   di
    3fc0:	6a 08                	push   0x8
    3fc2:	6a 02                	push   0x2
    3fc4:	6a 00                	push   0x0
    3fc6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3fc9:	06                   	push   es
    3fca:	57                   	push   di
    3fcb:	9a a1 2a e3 3f       	call   0x3fe3:0x2aa1
    3fd0:	bf cb 3d             	mov    di,0x3dcb
    3fd3:	0e                   	push   cs
    3fd4:	57                   	push   di
    3fd5:	6a 08                	push   0x8
    3fd7:	6a 02                	push   0x2
    3fd9:	6a 00                	push   0x0
    3fdb:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3fde:	06                   	push   es
    3fdf:	57                   	push   di
    3fe0:	9a a1 2a f8 3f       	call   0x3ff8:0x2aa1
    3fe5:	bf d8 3d             	mov    di,0x3dd8
    3fe8:	0e                   	push   cs
    3fe9:	57                   	push   di
    3fea:	6a 08                	push   0x8
    3fec:	6a 02                	push   0x2
    3fee:	6a 00                	push   0x0
    3ff0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3ff3:	06                   	push   es
    3ff4:	57                   	push   di
    3ff5:	9a a1 2a 0d 40       	call   0x400d:0x2aa1
    3ffa:	bf e4 3d             	mov    di,0x3de4
    3ffd:	0e                   	push   cs
    3ffe:	57                   	push   di
    3fff:	6a 03                	push   0x3
    4001:	6a 00                	push   0x0
    4003:	6a 00                	push   0x0
    4005:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4008:	06                   	push   es
    4009:	57                   	push   di
    400a:	9a a1 2a 22 40       	call   0x4022:0x2aa1
    400f:	bf ec 3d             	mov    di,0x3dec
    4012:	0e                   	push   cs
    4013:	57                   	push   di
    4014:	6a 03                	push   0x3
    4016:	6a 00                	push   0x0
    4018:	6a 00                	push   0x0
    401a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    401d:	06                   	push   es
    401e:	57                   	push   di
    401f:	9a a1 2a 37 40       	call   0x4037:0x2aa1
    4024:	bf f3 3d             	mov    di,0x3df3
    4027:	0e                   	push   cs
    4028:	57                   	push   di
    4029:	6a 03                	push   0x3
    402b:	6a 00                	push   0x0
    402d:	6a 00                	push   0x0
    402f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4032:	06                   	push   es
    4033:	57                   	push   di
    4034:	9a a1 2a 4c 40       	call   0x404c:0x2aa1
    4039:	bf 08 3e             	mov    di,0x3e08
    403c:	0e                   	push   cs
    403d:	57                   	push   di
    403e:	6a 03                	push   0x3
    4040:	6a 00                	push   0x0
    4042:	6a 00                	push   0x0
    4044:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4047:	06                   	push   es
    4048:	57                   	push   di
    4049:	9a a1 2a 61 40       	call   0x4061:0x2aa1
    404e:	bf 15 3e             	mov    di,0x3e15
    4051:	0e                   	push   cs
    4052:	57                   	push   di
    4053:	6a 08                	push   0x8
    4055:	6a 02                	push   0x2
    4057:	6a 00                	push   0x0
    4059:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    405c:	06                   	push   es
    405d:	57                   	push   di
    405e:	9a a1 2a 76 40       	call   0x4076:0x2aa1
    4063:	bf 20 3e             	mov    di,0x3e20
    4066:	0e                   	push   cs
    4067:	57                   	push   di
    4068:	6a 03                	push   0x3
    406a:	6a 00                	push   0x0
    406c:	6a 00                	push   0x0
    406e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4071:	06                   	push   es
    4072:	57                   	push   di
    4073:	9a a1 2a 8b 40       	call   0x408b:0x2aa1
    4078:	bf 29 3e             	mov    di,0x3e29
    407b:	0e                   	push   cs
    407c:	57                   	push   di
    407d:	6a 08                	push   0x8
    407f:	6a 02                	push   0x2
    4081:	6a 00                	push   0x0
    4083:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4086:	06                   	push   es
    4087:	57                   	push   di
    4088:	9a a1 2a a0 40       	call   0x40a0:0x2aa1
    408d:	bf 35 3e             	mov    di,0x3e35
    4090:	0e                   	push   cs
    4091:	57                   	push   di
    4092:	6a 08                	push   0x8
    4094:	6a 02                	push   0x2
    4096:	6a 00                	push   0x0
    4098:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    409b:	06                   	push   es
    409c:	57                   	push   di
    409d:	9a a1 2a b5 40       	call   0x40b5:0x2aa1
    40a2:	bf 46 3e             	mov    di,0x3e46
    40a5:	0e                   	push   cs
    40a6:	57                   	push   di
    40a7:	6a 03                	push   0x3
    40a9:	6a 00                	push   0x0
    40ab:	6a 00                	push   0x0
    40ad:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    40b0:	06                   	push   es
    40b1:	57                   	push   di
    40b2:	9a a1 2a ca 40       	call   0x40ca:0x2aa1
    40b7:	bf 57 3e             	mov    di,0x3e57
    40ba:	0e                   	push   cs
    40bb:	57                   	push   di
    40bc:	6a 08                	push   0x8
    40be:	6a 02                	push   0x2
    40c0:	6a 00                	push   0x0
    40c2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    40c5:	06                   	push   es
    40c6:	57                   	push   di
    40c7:	9a a1 2a df 40       	call   0x40df:0x2aa1
    40cc:	bf 69 3e             	mov    di,0x3e69
    40cf:	0e                   	push   cs
    40d0:	57                   	push   di
    40d1:	6a 03                	push   0x3
    40d3:	6a 00                	push   0x0
    40d5:	6a 00                	push   0x0
    40d7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    40da:	06                   	push   es
    40db:	57                   	push   di
    40dc:	9a a1 2a f4 40       	call   0x40f4:0x2aa1
    40e1:	bf 76 3e             	mov    di,0x3e76
    40e4:	0e                   	push   cs
    40e5:	57                   	push   di
    40e6:	6a 08                	push   0x8
    40e8:	6a 02                	push   0x2
    40ea:	6a 00                	push   0x0
    40ec:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    40ef:	06                   	push   es
    40f0:	57                   	push   di
    40f1:	9a a1 2a 09 41       	call   0x4109:0x2aa1
    40f6:	bf 84 3e             	mov    di,0x3e84
    40f9:	0e                   	push   cs
    40fa:	57                   	push   di
    40fb:	6a 08                	push   0x8
    40fd:	6a 02                	push   0x2
    40ff:	6a 00                	push   0x0
    4101:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4104:	06                   	push   es
    4105:	57                   	push   di
    4106:	9a a1 2a 1e 41       	call   0x411e:0x2aa1
    410b:	bf 96 3e             	mov    di,0x3e96
    410e:	0e                   	push   cs
    410f:	57                   	push   di
    4110:	6a 08                	push   0x8
    4112:	6a 02                	push   0x2
    4114:	6a 00                	push   0x0
    4116:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4119:	06                   	push   es
    411a:	57                   	push   di
    411b:	9a a1 2a 33 41       	call   0x4133:0x2aa1
    4120:	bf a2 3e             	mov    di,0x3ea2
    4123:	0e                   	push   cs
    4124:	57                   	push   di
    4125:	6a 08                	push   0x8
    4127:	6a 02                	push   0x2
    4129:	6a 00                	push   0x0
    412b:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    412e:	06                   	push   es
    412f:	57                   	push   di
    4130:	9a a1 2a 48 41       	call   0x4148:0x2aa1
    4135:	bf b6 3e             	mov    di,0x3eb6
    4138:	0e                   	push   cs
    4139:	57                   	push   di
    413a:	6a 08                	push   0x8
    413c:	6a 02                	push   0x2
    413e:	6a 00                	push   0x0
    4140:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4143:	06                   	push   es
    4144:	57                   	push   di
    4145:	9a a1 2a 5d 41       	call   0x415d:0x2aa1
    414a:	bf c5 3e             	mov    di,0x3ec5
    414d:	0e                   	push   cs
    414e:	57                   	push   di
    414f:	6a 06                	push   0x6
    4151:	6a 00                	push   0x0
    4153:	6a 00                	push   0x0
    4155:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4158:	06                   	push   es
    4159:	57                   	push   di
    415a:	9a a1 2a 72 41       	call   0x4172:0x2aa1
    415f:	bf db 3e             	mov    di,0x3edb
    4162:	0e                   	push   cs
    4163:	57                   	push   di
    4164:	6a 03                	push   0x3
    4166:	6a 00                	push   0x0
    4168:	6a 00                	push   0x0
    416a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    416d:	06                   	push   es
    416e:	57                   	push   di
    416f:	9a a1 2a 87 41       	call   0x4187:0x2aa1
    4174:	bf ec 3e             	mov    di,0x3eec
    4177:	0e                   	push   cs
    4178:	57                   	push   di
    4179:	6a 03                	push   0x3
    417b:	6a 00                	push   0x0
    417d:	6a 00                	push   0x0
    417f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4182:	06                   	push   es
    4183:	57                   	push   di
    4184:	9a a1 2a 13 44       	call   0x4413:0x2aa1
    4189:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    418c:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    4191:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    4194:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    4197:	bf f4 3e             	mov    di,0x3ef4
    419a:	0e                   	push   cs
    419b:	57                   	push   di
    419c:	bf fb 3e             	mov    di,0x3efb
    419f:	0e                   	push   cs
    41a0:	57                   	push   di
    41a1:	6a 03                	push   0x3
    41a3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    41a6:	06                   	push   es
    41a7:	57                   	push   di
    41a8:	9a f6 18 41 42       	call   0x4241:0x18f6
    41ad:	c9                   	leave
    41ae:	ca 04 00             	retf   0x4
    41b1:	cd cc                	int    0xcc
    41b3:	cc                   	int3
    41b4:	cc                   	int3
    41b5:	cc                   	int3
    41b6:	cc                   	int3
    41b7:	cc                   	int3
    41b8:	cc                   	int3
    41b9:	fd                   	std
    41ba:	3f                   	aas
    41bb:	01 00                	add    WORD PTR [bx+si],ax
    41bd:	00 00                	add    BYTE PTR [bx+si],al
    41bf:	02 00                	add    al,BYTE PTR [bx+si]
    41c1:	00 00                	add    BYTE PTR [bx+si],al
    41c3:	55                   	push   bp
    41c4:	89 e5                	mov    bp,sp
    41c6:	b8 18 01             	mov    ax,0x118
    41c9:	9a 44 04 cc 43       	call   0x43cc:0x444
    41ce:	81 ec 18 01          	sub    sp,0x118
    41d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41d5:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    41d8:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    41db:	31 c0                	xor    ax,ax
    41dd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    41e0:	eb 03                	jmp    0x41e5
    41e2:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    41e5:	a1 4e 01             	mov    ax,ds:0x14e
    41e8:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    41eb:	b8 01 00             	mov    ax,0x1
    41ee:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    41f1:	7e 03                	jle    0x41f6
    41f3:	e9 33 02             	jmp    0x4429
    41f6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    41f9:	eb 03                	jmp    0x41fe
    41fb:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    41fe:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    4203:	eb 03                	jmp    0x4208
    4205:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    4208:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    420b:	99                   	cwd
    420c:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    420f:	89 56 de             	mov    WORD PTR [bp-0x22],dx
    4212:	c6 46 e0 00          	mov    BYTE PTR [bp-0x20],0x0
    4216:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4219:	99                   	cwd
    421a:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    421d:	89 56 e6             	mov    WORD PTR [bp-0x1a],dx
    4220:	c6 46 e8 00          	mov    BYTE PTR [bp-0x18],0x0
    4224:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    4227:	99                   	cwd
    4228:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    422b:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    422e:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
    4232:	8d 7e dc             	lea    di,[bp-0x24]
    4235:	16                   	push   ss
    4236:	57                   	push   di
    4237:	6a 02                	push   0x2
    4239:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    423c:	06                   	push   es
    423d:	57                   	push   di
    423e:	9a 95 28 aa 44       	call   0x44aa:0x2895
    4243:	08 c0                	or     al,al
    4245:	74 03                	je     0x424a
    4247:	e9 cb 01             	jmp    0x4415
    424a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    424d:	99                   	cwd
    424e:	89 86 e8 fe          	mov    WORD PTR [bp-0x118],ax
    4252:	89 96 ea fe          	mov    WORD PTR [bp-0x116],dx
    4256:	c6 86 ec fe 00       	mov    BYTE PTR [bp-0x114],0x0
    425b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    425e:	99                   	cwd
    425f:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    4263:	89 96 f2 fe          	mov    WORD PTR [bp-0x10e],dx
    4267:	c6 86 f4 fe 00       	mov    BYTE PTR [bp-0x10c],0x0
    426c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    426f:	99                   	cwd
    4270:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    4274:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
    4278:	c6 86 fc fe 00       	mov    BYTE PTR [bp-0x104],0x0
    427d:	31 c0                	xor    ax,ax
    427f:	89 86 00 ff          	mov    WORD PTR [bp-0x100],ax
    4283:	89 86 02 ff          	mov    WORD PTR [bp-0xfe],ax
    4287:	c6 86 04 ff 00       	mov    BYTE PTR [bp-0xfc],0x0
    428c:	31 c0                	xor    ax,ax
    428e:	89 86 08 ff          	mov    WORD PTR [bp-0xf8],ax
    4292:	89 86 0a ff          	mov    WORD PTR [bp-0xf6],ax
    4296:	c6 86 0c ff 00       	mov    BYTE PTR [bp-0xf4],0x0
    429b:	31 c0                	xor    ax,ax
    429d:	89 86 10 ff          	mov    WORD PTR [bp-0xf0],ax
    42a1:	89 86 12 ff          	mov    WORD PTR [bp-0xee],ax
    42a5:	c6 86 14 ff 00       	mov    BYTE PTR [bp-0xec],0x0
    42aa:	31 c0                	xor    ax,ax
    42ac:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
    42b0:	89 86 1a ff          	mov    WORD PTR [bp-0xe6],ax
    42b4:	c6 86 1c ff 00       	mov    BYTE PTR [bp-0xe4],0x0
    42b9:	31 c0                	xor    ax,ax
    42bb:	89 86 20 ff          	mov    WORD PTR [bp-0xe0],ax
    42bf:	89 86 22 ff          	mov    WORD PTR [bp-0xde],ax
    42c3:	c6 86 24 ff 00       	mov    BYTE PTR [bp-0xdc],0x0
    42c8:	9b 2e db 2e b1 41    	fld    TBYTE PTR cs:0x41b1
    42ce:	9b db 7e d2          	fstp   TBYTE PTR [bp-0x2e]
    42d2:	8d 46 d2             	lea    ax,[bp-0x2e]
    42d5:	8c d2                	mov    dx,ss
    42d7:	89 86 28 ff          	mov    WORD PTR [bp-0xd8],ax
    42db:	89 96 2a ff          	mov    WORD PTR [bp-0xd6],dx
    42df:	c6 86 2c ff 03       	mov    BYTE PTR [bp-0xd4],0x3
    42e4:	31 c0                	xor    ax,ax
    42e6:	89 86 30 ff          	mov    WORD PTR [bp-0xd0],ax
    42ea:	89 86 32 ff          	mov    WORD PTR [bp-0xce],ax
    42ee:	c6 86 34 ff 00       	mov    BYTE PTR [bp-0xcc],0x0
    42f3:	31 c0                	xor    ax,ax
    42f5:	89 86 38 ff          	mov    WORD PTR [bp-0xc8],ax
    42f9:	89 86 3a ff          	mov    WORD PTR [bp-0xc6],ax
    42fd:	c6 86 3c ff 00       	mov    BYTE PTR [bp-0xc4],0x0
    4302:	31 c0                	xor    ax,ax
    4304:	89 86 40 ff          	mov    WORD PTR [bp-0xc0],ax
    4308:	89 86 42 ff          	mov    WORD PTR [bp-0xbe],ax
    430c:	c6 86 44 ff 00       	mov    BYTE PTR [bp-0xbc],0x0
    4311:	31 c0                	xor    ax,ax
    4313:	89 86 48 ff          	mov    WORD PTR [bp-0xb8],ax
    4317:	89 86 4a ff          	mov    WORD PTR [bp-0xb6],ax
    431b:	c6 86 4c ff 00       	mov    BYTE PTR [bp-0xb4],0x0
    4320:	31 c0                	xor    ax,ax
    4322:	89 86 50 ff          	mov    WORD PTR [bp-0xb0],ax
    4326:	89 86 52 ff          	mov    WORD PTR [bp-0xae],ax
    432a:	c6 86 54 ff 00       	mov    BYTE PTR [bp-0xac],0x0
    432f:	31 c0                	xor    ax,ax
    4331:	89 86 58 ff          	mov    WORD PTR [bp-0xa8],ax
    4335:	89 86 5a ff          	mov    WORD PTR [bp-0xa6],ax
    4339:	c6 86 5c ff 00       	mov    BYTE PTR [bp-0xa4],0x0
    433e:	31 c0                	xor    ax,ax
    4340:	89 86 60 ff          	mov    WORD PTR [bp-0xa0],ax
    4344:	89 86 62 ff          	mov    WORD PTR [bp-0x9e],ax
    4348:	c6 86 64 ff 00       	mov    BYTE PTR [bp-0x9c],0x0
    434d:	31 c0                	xor    ax,ax
    434f:	89 86 68 ff          	mov    WORD PTR [bp-0x98],ax
    4353:	89 86 6a ff          	mov    WORD PTR [bp-0x96],ax
    4357:	c6 86 6c ff 00       	mov    BYTE PTR [bp-0x94],0x0
    435c:	31 c0                	xor    ax,ax
    435e:	89 86 70 ff          	mov    WORD PTR [bp-0x90],ax
    4362:	89 86 72 ff          	mov    WORD PTR [bp-0x8e],ax
    4366:	c6 86 74 ff 00       	mov    BYTE PTR [bp-0x8c],0x0
    436b:	31 c0                	xor    ax,ax
    436d:	89 86 78 ff          	mov    WORD PTR [bp-0x88],ax
    4371:	89 86 7a ff          	mov    WORD PTR [bp-0x86],ax
    4375:	c6 86 7c ff 00       	mov    BYTE PTR [bp-0x84],0x0
    437a:	31 c0                	xor    ax,ax
    437c:	89 46 80             	mov    WORD PTR [bp-0x80],ax
    437f:	89 46 82             	mov    WORD PTR [bp-0x7e],ax
    4382:	c6 46 84 00          	mov    BYTE PTR [bp-0x7c],0x0
    4386:	31 c0                	xor    ax,ax
    4388:	89 46 88             	mov    WORD PTR [bp-0x78],ax
    438b:	89 46 8a             	mov    WORD PTR [bp-0x76],ax
    438e:	c6 46 8c 00          	mov    BYTE PTR [bp-0x74],0x0
    4392:	31 c0                	xor    ax,ax
    4394:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    4397:	89 46 92             	mov    WORD PTR [bp-0x6e],ax
    439a:	c6 46 94 00          	mov    BYTE PTR [bp-0x6c],0x0
    439e:	31 c0                	xor    ax,ax
    43a0:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    43a3:	89 46 9a             	mov    WORD PTR [bp-0x66],ax
    43a6:	c6 46 9c 00          	mov    BYTE PTR [bp-0x64],0x0
    43aa:	31 c0                	xor    ax,ax
    43ac:	89 46 a0             	mov    WORD PTR [bp-0x60],ax
    43af:	89 46 a2             	mov    WORD PTR [bp-0x5e],ax
    43b2:	c6 46 a4 00          	mov    BYTE PTR [bp-0x5c],0x0
    43b6:	31 c0                	xor    ax,ax
    43b8:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    43bb:	89 46 aa             	mov    WORD PTR [bp-0x56],ax
    43be:	c6 46 ac 00          	mov    BYTE PTR [bp-0x54],0x0
    43c2:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    43c5:	99                   	cwd
    43c6:	bf bb 41             	mov    di,0x41bb
    43c9:	9a 16 04 3f 44       	call   0x443f:0x416
    43ce:	8b f8                	mov    di,ax
    43d0:	c1 e7 03             	shl    di,0x3
    43d3:	9b dd 85 56 01       	fld    QWORD PTR [di+0x156]
    43d8:	9b db 7e c8          	fstp   TBYTE PTR [bp-0x38]
    43dc:	8d 46 c8             	lea    ax,[bp-0x38]
    43df:	8c d2                	mov    dx,ss
    43e1:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    43e4:	89 56 b2             	mov    WORD PTR [bp-0x4e],dx
    43e7:	c6 46 b4 03          	mov    BYTE PTR [bp-0x4c],0x3
    43eb:	31 c0                	xor    ax,ax
    43ed:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    43f0:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    43f3:	c6 46 bc 00          	mov    BYTE PTR [bp-0x44],0x0
    43f7:	31 c0                	xor    ax,ax
    43f9:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    43fc:	89 46 c2             	mov    WORD PTR [bp-0x3e],ax
    43ff:	c6 46 c4 00          	mov    BYTE PTR [bp-0x3c],0x0
    4403:	8d be e8 fe          	lea    di,[bp-0x118]
    4407:	16                   	push   ss
    4408:	57                   	push   di
    4409:	6a 1b                	push   0x1b
    440b:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    440e:	06                   	push   es
    440f:	57                   	push   di
    4410:	9a 21 53 4a 46       	call   0x464a:0x5321
    4415:	83 7e fa 02          	cmp    WORD PTR [bp-0x6],0x2
    4419:	74 03                	je     0x441e
    441b:	e9 e7 fd             	jmp    0x4205
    441e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4421:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    4424:	74 03                	je     0x4429
    4426:	e9 d2 fd             	jmp    0x41fb
    4429:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    442d:	74 03                	je     0x4432
    442f:	e9 b0 fd             	jmp    0x41e2
    4432:	c9                   	leave
    4433:	ca 04 00             	retf   0x4
    4436:	55                   	push   bp
    4437:	89 e5                	mov    bp,sp
    4439:	b8 02 01             	mov    ax,0x102
    443c:	9a 44 04 a9 46       	call   0x46a9:0x444
    4441:	81 ec 02 01          	sub    sp,0x102
    4445:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    4448:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    444b:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    444e:	a1 4e 01             	mov    ax,ds:0x14e
    4451:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    4454:	b8 01 00             	mov    ax,0x1
    4457:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    445a:	7e 03                	jle    0x445f
    445c:	e9 01 02             	jmp    0x4660
    445f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4462:	eb 03                	jmp    0x4467
    4464:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4467:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    446c:	eb 03                	jmp    0x4471
    446e:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    4471:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4474:	99                   	cwd
    4475:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    4478:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
    447b:	c6 46 e2 00          	mov    BYTE PTR [bp-0x1e],0x0
    447f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4482:	99                   	cwd
    4483:	89 46 e6             	mov    WORD PTR [bp-0x1a],ax
    4486:	89 56 e8             	mov    WORD PTR [bp-0x18],dx
    4489:	c6 46 ea 00          	mov    BYTE PTR [bp-0x16],0x0
    448d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4490:	99                   	cwd
    4491:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    4494:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    4497:	c6 46 f2 00          	mov    BYTE PTR [bp-0xe],0x0
    449b:	8d 7e de             	lea    di,[bp-0x22]
    449e:	16                   	push   ss
    449f:	57                   	push   di
    44a0:	6a 02                	push   0x2
    44a2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    44a5:	06                   	push   es
    44a6:	57                   	push   di
    44a7:	9a 95 28 22 47       	call   0x4722:0x2895
    44ac:	08 c0                	or     al,al
    44ae:	74 03                	je     0x44b3
    44b0:	e9 99 01             	jmp    0x464c
    44b3:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    44b6:	99                   	cwd
    44b7:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    44bb:	89 96 00 ff          	mov    WORD PTR [bp-0x100],dx
    44bf:	c6 86 02 ff 00       	mov    BYTE PTR [bp-0xfe],0x0
    44c4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    44c7:	99                   	cwd
    44c8:	89 86 06 ff          	mov    WORD PTR [bp-0xfa],ax
    44cc:	89 96 08 ff          	mov    WORD PTR [bp-0xf8],dx
    44d0:	c6 86 0a ff 00       	mov    BYTE PTR [bp-0xf6],0x0
    44d5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    44d8:	99                   	cwd
    44d9:	89 86 0e ff          	mov    WORD PTR [bp-0xf2],ax
    44dd:	89 96 10 ff          	mov    WORD PTR [bp-0xf0],dx
    44e1:	c6 86 12 ff 00       	mov    BYTE PTR [bp-0xee],0x0
    44e6:	31 c0                	xor    ax,ax
    44e8:	89 86 16 ff          	mov    WORD PTR [bp-0xea],ax
    44ec:	89 86 18 ff          	mov    WORD PTR [bp-0xe8],ax
    44f0:	c6 86 1a ff 00       	mov    BYTE PTR [bp-0xe6],0x0
    44f5:	31 c0                	xor    ax,ax
    44f7:	89 86 1e ff          	mov    WORD PTR [bp-0xe2],ax
    44fb:	89 86 20 ff          	mov    WORD PTR [bp-0xe0],ax
    44ff:	c6 86 22 ff 00       	mov    BYTE PTR [bp-0xde],0x0
    4504:	31 c0                	xor    ax,ax
    4506:	89 86 26 ff          	mov    WORD PTR [bp-0xda],ax
    450a:	89 86 28 ff          	mov    WORD PTR [bp-0xd8],ax
    450e:	c6 86 2a ff 00       	mov    BYTE PTR [bp-0xd6],0x0
    4513:	31 c0                	xor    ax,ax
    4515:	89 86 2e ff          	mov    WORD PTR [bp-0xd2],ax
    4519:	89 86 30 ff          	mov    WORD PTR [bp-0xd0],ax
    451d:	c6 86 32 ff 00       	mov    BYTE PTR [bp-0xce],0x0
    4522:	31 c0                	xor    ax,ax
    4524:	89 86 36 ff          	mov    WORD PTR [bp-0xca],ax
    4528:	89 86 38 ff          	mov    WORD PTR [bp-0xc8],ax
    452c:	c6 86 3a ff 00       	mov    BYTE PTR [bp-0xc6],0x0
    4531:	31 c0                	xor    ax,ax
    4533:	89 86 3e ff          	mov    WORD PTR [bp-0xc2],ax
    4537:	89 86 40 ff          	mov    WORD PTR [bp-0xc0],ax
    453b:	c6 86 42 ff 00       	mov    BYTE PTR [bp-0xbe],0x0
    4540:	31 c0                	xor    ax,ax
    4542:	89 86 46 ff          	mov    WORD PTR [bp-0xba],ax
    4546:	89 86 48 ff          	mov    WORD PTR [bp-0xb8],ax
    454a:	c6 86 4a ff 00       	mov    BYTE PTR [bp-0xb6],0x0
    454f:	31 c0                	xor    ax,ax
    4551:	89 86 4e ff          	mov    WORD PTR [bp-0xb2],ax
    4555:	89 86 50 ff          	mov    WORD PTR [bp-0xb0],ax
    4559:	c6 86 52 ff 00       	mov    BYTE PTR [bp-0xae],0x0
    455e:	31 c0                	xor    ax,ax
    4560:	89 86 56 ff          	mov    WORD PTR [bp-0xaa],ax
    4564:	89 86 58 ff          	mov    WORD PTR [bp-0xa8],ax
    4568:	c6 86 5a ff 00       	mov    BYTE PTR [bp-0xa6],0x0
    456d:	31 c0                	xor    ax,ax
    456f:	89 86 5e ff          	mov    WORD PTR [bp-0xa2],ax
    4573:	89 86 60 ff          	mov    WORD PTR [bp-0xa0],ax
    4577:	c6 86 62 ff 00       	mov    BYTE PTR [bp-0x9e],0x0
    457c:	31 c0                	xor    ax,ax
    457e:	89 86 66 ff          	mov    WORD PTR [bp-0x9a],ax
    4582:	89 86 68 ff          	mov    WORD PTR [bp-0x98],ax
    4586:	c6 86 6a ff 00       	mov    BYTE PTR [bp-0x96],0x0
    458b:	31 c0                	xor    ax,ax
    458d:	89 86 6e ff          	mov    WORD PTR [bp-0x92],ax
    4591:	89 86 70 ff          	mov    WORD PTR [bp-0x90],ax
    4595:	c6 86 72 ff 00       	mov    BYTE PTR [bp-0x8e],0x0
    459a:	31 c0                	xor    ax,ax
    459c:	89 86 76 ff          	mov    WORD PTR [bp-0x8a],ax
    45a0:	89 86 78 ff          	mov    WORD PTR [bp-0x88],ax
    45a4:	c6 86 7a ff 00       	mov    BYTE PTR [bp-0x86],0x0
    45a9:	31 c0                	xor    ax,ax
    45ab:	89 86 7e ff          	mov    WORD PTR [bp-0x82],ax
    45af:	89 46 80             	mov    WORD PTR [bp-0x80],ax
    45b2:	c6 46 82 00          	mov    BYTE PTR [bp-0x7e],0x0
    45b6:	31 c0                	xor    ax,ax
    45b8:	89 46 86             	mov    WORD PTR [bp-0x7a],ax
    45bb:	89 46 88             	mov    WORD PTR [bp-0x78],ax
    45be:	c6 46 8a 00          	mov    BYTE PTR [bp-0x76],0x0
    45c2:	31 c0                	xor    ax,ax
    45c4:	89 46 8e             	mov    WORD PTR [bp-0x72],ax
    45c7:	89 46 90             	mov    WORD PTR [bp-0x70],ax
    45ca:	c6 46 92 00          	mov    BYTE PTR [bp-0x6e],0x0
    45ce:	31 c0                	xor    ax,ax
    45d0:	89 46 96             	mov    WORD PTR [bp-0x6a],ax
    45d3:	89 46 98             	mov    WORD PTR [bp-0x68],ax
    45d6:	c6 46 9a 00          	mov    BYTE PTR [bp-0x66],0x0
    45da:	31 c0                	xor    ax,ax
    45dc:	89 46 9e             	mov    WORD PTR [bp-0x62],ax
    45df:	89 46 a0             	mov    WORD PTR [bp-0x60],ax
    45e2:	c6 46 a2 00          	mov    BYTE PTR [bp-0x5e],0x0
    45e6:	31 c0                	xor    ax,ax
    45e8:	89 46 a6             	mov    WORD PTR [bp-0x5a],ax
    45eb:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    45ee:	c6 46 aa 00          	mov    BYTE PTR [bp-0x56],0x0
    45f2:	31 c0                	xor    ax,ax
    45f4:	89 46 ae             	mov    WORD PTR [bp-0x52],ax
    45f7:	89 46 b0             	mov    WORD PTR [bp-0x50],ax
    45fa:	c6 46 b2 00          	mov    BYTE PTR [bp-0x4e],0x0
    45fe:	31 c0                	xor    ax,ax
    4600:	89 46 b6             	mov    WORD PTR [bp-0x4a],ax
    4603:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    4606:	c6 46 ba 00          	mov    BYTE PTR [bp-0x46],0x0
    460a:	31 c0                	xor    ax,ax
    460c:	89 46 be             	mov    WORD PTR [bp-0x42],ax
    460f:	89 46 c0             	mov    WORD PTR [bp-0x40],ax
    4612:	c6 46 c2 00          	mov    BYTE PTR [bp-0x3e],0x0
    4616:	31 c0                	xor    ax,ax
    4618:	89 46 c6             	mov    WORD PTR [bp-0x3a],ax
    461b:	89 46 c8             	mov    WORD PTR [bp-0x38],ax
    461e:	c6 46 ca 00          	mov    BYTE PTR [bp-0x36],0x0
    4622:	31 c0                	xor    ax,ax
    4624:	89 46 ce             	mov    WORD PTR [bp-0x32],ax
    4627:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    462a:	c6 46 d2 00          	mov    BYTE PTR [bp-0x2e],0x0
    462e:	31 c0                	xor    ax,ax
    4630:	89 46 d6             	mov    WORD PTR [bp-0x2a],ax
    4633:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    4636:	c6 46 da 00          	mov    BYTE PTR [bp-0x26],0x0
    463a:	8d be fe fe          	lea    di,[bp-0x102]
    463e:	16                   	push   ss
    463f:	57                   	push   di
    4640:	6a 1b                	push   0x1b
    4642:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4645:	06                   	push   es
    4646:	57                   	push   di
    4647:	9a 21 53 d4 46       	call   0x46d4:0x5321
    464c:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    4650:	74 03                	je     0x4655
    4652:	e9 19 fe             	jmp    0x446e
    4655:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4658:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    465b:	74 03                	je     0x4660
    465d:	e9 04 fe             	jmp    0x4464
    4660:	c9                   	leave
    4661:	ca 06 00             	retf   0x6
    4664:	09 50 65             	or     WORD PTR [bx+si+0x65],dx
    4667:	72 69                	jb     0x46d2
    4669:	6f                   	outs   dx,WORD PTR ds:[si]
    466a:	64 65 4e             	fs gs dec si
    466d:	6f                   	outs   dx,WORD PTR ds:[si]
    466e:	09 50 72             	or     WORD PTR [bx+si+0x72],dx
    4671:	6f                   	outs   dx,WORD PTR ds:[si]
    4672:	64 75 69             	fs jne 0x46de
    4675:	74 4e                	je     0x46c5
    4677:	6f                   	outs   dx,WORD PTR ds:[si]
    4678:	0c 56                	or     al,0x56
    467a:	6f                   	outs   dx,WORD PTR ds:[si]
    467b:	6c                   	ins    BYTE PTR es:[di],dx
    467c:	75 6d                	jne    0x46eb
    467e:	65 4d                	gs dec bp
    4680:	61                   	popa
    4681:	72 63                	jb     0x46e6
    4683:	68 65 06             	push   0x665
    4686:	4d                   	dec    bp
    4687:	61                   	popa
    4688:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    468b:	6e                   	outs   dx,BYTE PTR ds:[si]
    468c:	13 50 65             	adc    dx,WORD PTR [bx+si+0x65]
    468f:	72 69                	jb     0x46fa
    4691:	6f                   	outs   dx,WORD PTR ds:[si]
    4692:	64 65 4e             	fs gs dec si
    4695:	6f                   	outs   dx,WORD PTR ds:[si]
    4696:	3b 50 72             	cmp    dx,WORD PTR [bx+si+0x72]
    4699:	6f                   	outs   dx,WORD PTR ds:[si]
    469a:	64 75 69             	fs jne 0x4706
    469d:	74 4e                	je     0x46ed
    469f:	6f                   	outs   dx,WORD PTR ds:[si]
    46a0:	55                   	push   bp
    46a1:	89 e5                	mov    bp,sp
    46a3:	b8 08 00             	mov    ax,0x8
    46a6:	9a 44 04 31 47       	call   0x4731:0x444
    46ab:	83 ec 08             	sub    sp,0x8
    46ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46b1:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    46b4:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    46b7:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    46bb:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    46be:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    46c1:	bf 64 46             	mov    di,0x4664
    46c4:	0e                   	push   cs
    46c5:	57                   	push   di
    46c6:	6a 03                	push   0x3
    46c8:	6a 00                	push   0x0
    46ca:	6a 00                	push   0x0
    46cc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    46cf:	06                   	push   es
    46d0:	57                   	push   di
    46d1:	9a a1 2a e9 46       	call   0x46e9:0x2aa1
    46d6:	bf 6e 46             	mov    di,0x466e
    46d9:	0e                   	push   cs
    46da:	57                   	push   di
    46db:	6a 03                	push   0x3
    46dd:	6a 00                	push   0x0
    46df:	6a 00                	push   0x0
    46e1:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    46e4:	06                   	push   es
    46e5:	57                   	push   di
    46e6:	9a a1 2a fe 46       	call   0x46fe:0x2aa1
    46eb:	bf 78 46             	mov    di,0x4678
    46ee:	0e                   	push   cs
    46ef:	57                   	push   di
    46f0:	6a 08                	push   0x8
    46f2:	6a 02                	push   0x2
    46f4:	6a 00                	push   0x0
    46f6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    46f9:	06                   	push   es
    46fa:	57                   	push   di
    46fb:	9a a1 2a bb 47       	call   0x47bb:0x2aa1
    4700:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4703:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    4708:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    470b:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    470e:	bf 85 46             	mov    di,0x4685
    4711:	0e                   	push   cs
    4712:	57                   	push   di
    4713:	bf 8c 46             	mov    di,0x468c
    4716:	0e                   	push   cs
    4717:	57                   	push   di
    4718:	6a 03                	push   0x3
    471a:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    471d:	06                   	push   es
    471e:	57                   	push   di
    471f:	9a f6 18 7e 47       	call   0x477e:0x18f6
    4724:	c9                   	leave
    4725:	ca 04 00             	retf   0x4
    4728:	55                   	push   bp
    4729:	89 e5                	mov    bp,sp
    472b:	b8 30 00             	mov    ax,0x30
    472e:	9a 44 04 d9 47       	call   0x47d9:0x444
    4733:	83 ec 30             	sub    sp,0x30
    4736:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4739:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    473c:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    473f:	31 c0                	xor    ax,ax
    4741:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4744:	eb 03                	jmp    0x4749
    4746:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4749:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    474e:	eb 03                	jmp    0x4753
    4750:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    4753:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4756:	99                   	cwd
    4757:	89 46 e8             	mov    WORD PTR [bp-0x18],ax
    475a:	89 56 ea             	mov    WORD PTR [bp-0x16],dx
    475d:	c6 46 ec 00          	mov    BYTE PTR [bp-0x14],0x0
    4761:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4764:	99                   	cwd
    4765:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    4768:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    476b:	c6 46 f4 00          	mov    BYTE PTR [bp-0xc],0x0
    476f:	8d 7e e8             	lea    di,[bp-0x18]
    4772:	16                   	push   ss
    4773:	57                   	push   di
    4774:	6a 01                	push   0x1
    4776:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    4779:	06                   	push   es
    477a:	57                   	push   di
    477b:	9a 95 28 1c 48       	call   0x481c:0x2895
    4780:	08 c0                	or     al,al
    4782:	75 39                	jne    0x47bd
    4784:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4787:	99                   	cwd
    4788:	89 46 d0             	mov    WORD PTR [bp-0x30],ax
    478b:	89 56 d2             	mov    WORD PTR [bp-0x2e],dx
    478e:	c6 46 d4 00          	mov    BYTE PTR [bp-0x2c],0x0
    4792:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4795:	99                   	cwd
    4796:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    4799:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    479c:	c6 46 dc 00          	mov    BYTE PTR [bp-0x24],0x0
    47a0:	31 c0                	xor    ax,ax
    47a2:	89 46 e0             	mov    WORD PTR [bp-0x20],ax
    47a5:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    47a8:	c6 46 e4 00          	mov    BYTE PTR [bp-0x1c],0x0
    47ac:	8d 7e d0             	lea    di,[bp-0x30]
    47af:	16                   	push   ss
    47b0:	57                   	push   di
    47b1:	6a 02                	push   0x2
    47b3:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    47b6:	06                   	push   es
    47b7:	57                   	push   di
    47b8:	9a 21 53 59 48       	call   0x4859:0x5321
    47bd:	83 7e fc 02          	cmp    WORD PTR [bp-0x4],0x2
    47c1:	75 8d                	jne    0x4750
    47c3:	83 7e fe 01          	cmp    WORD PTR [bp-0x2],0x1
    47c7:	74 03                	je     0x47cc
    47c9:	e9 7a ff             	jmp    0x4746
    47cc:	c9                   	leave
    47cd:	ca 04 00             	retf   0x4
    47d0:	55                   	push   bp
    47d1:	89 e5                	mov    bp,sp
    47d3:	b8 2e 00             	mov    ax,0x2e
    47d6:	9a 44 04 6d 48       	call   0x486d:0x444
    47db:	83 ec 2e             	sub    sp,0x2e
    47de:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    47e1:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    47e4:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    47e7:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    47ec:	eb 03                	jmp    0x47f1
    47ee:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    47f1:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    47f4:	99                   	cwd
    47f5:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
    47f8:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
    47fb:	c6 46 ee 00          	mov    BYTE PTR [bp-0x12],0x0
    47ff:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4802:	99                   	cwd
    4803:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    4806:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    4809:	c6 46 f6 00          	mov    BYTE PTR [bp-0xa],0x0
    480d:	8d 7e ea             	lea    di,[bp-0x16]
    4810:	16                   	push   ss
    4811:	57                   	push   di
    4812:	6a 01                	push   0x1
    4814:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4817:	06                   	push   es
    4818:	57                   	push   di
    4819:	9a 95 28 8a 48       	call   0x488a:0x2895
    481e:	08 c0                	or     al,al
    4820:	75 39                	jne    0x485b
    4822:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4825:	99                   	cwd
    4826:	89 46 d2             	mov    WORD PTR [bp-0x2e],ax
    4829:	89 56 d4             	mov    WORD PTR [bp-0x2c],dx
    482c:	c6 46 d6 00          	mov    BYTE PTR [bp-0x2a],0x0
    4830:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4833:	99                   	cwd
    4834:	89 46 da             	mov    WORD PTR [bp-0x26],ax
    4837:	89 56 dc             	mov    WORD PTR [bp-0x24],dx
    483a:	c6 46 de 00          	mov    BYTE PTR [bp-0x22],0x0
    483e:	31 c0                	xor    ax,ax
    4840:	89 46 e2             	mov    WORD PTR [bp-0x1e],ax
    4843:	89 46 e4             	mov    WORD PTR [bp-0x1c],ax
    4846:	c6 46 e6 00          	mov    BYTE PTR [bp-0x1a],0x0
    484a:	8d 7e d2             	lea    di,[bp-0x2e]
    484d:	16                   	push   ss
    484e:	57                   	push   di
    484f:	6a 02                	push   0x2
    4851:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4854:	06                   	push   es
    4855:	57                   	push   di
    4856:	9a 21 53 7b 48       	call   0x487b:0x5321
    485b:	83 7e fe 02          	cmp    WORD PTR [bp-0x2],0x2
    485f:	75 8d                	jne    0x47ee
    4861:	c9                   	leave
    4862:	ca 06 00             	retf   0x6
    4865:	55                   	push   bp
    4866:	89 e5                	mov    bp,sp
    4868:	31 c0                	xor    ax,ax
    486a:	9a 44 04 2f 4a       	call   0x4a2f:0x444
    486f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4872:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    4876:	06                   	push   es
    4877:	57                   	push   di
    4878:	9a a4 2c 47 4a       	call   0x4a47:0x2ca4
    487d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4880:	26 c4 bd 78 01       	les    di,DWORD PTR es:[di+0x178]
    4885:	06                   	push   es
    4886:	57                   	push   di
    4887:	9a 55 19 53 4a       	call   0x4a53:0x1955
    488c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    488f:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4892:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4895:	26 3b 95 7e 01       	cmp    dx,WORD PTR es:[di+0x17e]
    489a:	75 15                	jne    0x48b1
    489c:	26 3b 85 7c 01       	cmp    ax,WORD PTR es:[di+0x17c]
    48a1:	75 0e                	jne    0x48b1
    48a3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    48a6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    48a9:	9a 1c 02 d1 48       	call   0x48d1:0x21c
    48ae:	e9 6c 01             	jmp    0x4a1d
    48b1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    48b4:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    48b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48ba:	26 3b 95 82 01       	cmp    dx,WORD PTR es:[di+0x182]
    48bf:	75 15                	jne    0x48d6
    48c1:	26 3b 85 80 01       	cmp    ax,WORD PTR es:[di+0x180]
    48c6:	75 0e                	jne    0x48d6
    48c8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    48cb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    48ce:	9a 48 06 f6 48       	call   0x48f6:0x648
    48d3:	e9 47 01             	jmp    0x4a1d
    48d6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    48d9:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    48dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    48df:	26 3b 95 86 01       	cmp    dx,WORD PTR es:[di+0x186]
    48e4:	75 15                	jne    0x48fb
    48e6:	26 3b 85 84 01       	cmp    ax,WORD PTR es:[di+0x184]
    48eb:	75 0e                	jne    0x48fb
    48ed:	ff 76 0c             	push   WORD PTR [bp+0xc]
    48f0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    48f3:	9a 66 0c 1b 49       	call   0x491b:0xc66
    48f8:	e9 22 01             	jmp    0x4a1d
    48fb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    48fe:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4901:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4904:	26 3b 95 8a 01       	cmp    dx,WORD PTR es:[di+0x18a]
    4909:	75 15                	jne    0x4920
    490b:	26 3b 85 88 01       	cmp    ax,WORD PTR es:[di+0x188]
    4910:	75 0e                	jne    0x4920
    4912:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4915:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4918:	9a 1c 11 40 49       	call   0x4940:0x111c
    491d:	e9 fd 00             	jmp    0x4a1d
    4920:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4923:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4926:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4929:	26 3b 95 8e 01       	cmp    dx,WORD PTR es:[di+0x18e]
    492e:	75 15                	jne    0x4945
    4930:	26 3b 85 8c 01       	cmp    ax,WORD PTR es:[di+0x18c]
    4935:	75 0e                	jne    0x4945
    4937:	ff 76 0c             	push   WORD PTR [bp+0xc]
    493a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    493d:	9a c2 1b 65 49       	call   0x4965:0x1bc2
    4942:	e9 d8 00             	jmp    0x4a1d
    4945:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4948:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    494b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    494e:	26 3b 95 92 01       	cmp    dx,WORD PTR es:[di+0x192]
    4953:	75 15                	jne    0x496a
    4955:	26 3b 85 90 01       	cmp    ax,WORD PTR es:[di+0x190]
    495a:	75 0e                	jne    0x496a
    495c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    495f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4962:	9a e4 22 8a 49       	call   0x498a:0x22e4
    4967:	e9 b3 00             	jmp    0x4a1d
    496a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    496d:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4970:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4973:	26 3b 95 96 01       	cmp    dx,WORD PTR es:[di+0x196]
    4978:	75 15                	jne    0x498f
    497a:	26 3b 85 94 01       	cmp    ax,WORD PTR es:[di+0x194]
    497f:	75 0e                	jne    0x498f
    4981:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4984:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4987:	9a a4 28 af 49       	call   0x49af:0x28a4
    498c:	e9 8e 00             	jmp    0x4a1d
    498f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4992:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4995:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4998:	26 3b 95 9a 01       	cmp    dx,WORD PTR es:[di+0x19a]
    499d:	75 14                	jne    0x49b3
    499f:	26 3b 85 98 01       	cmp    ax,WORD PTR es:[di+0x198]
    49a4:	75 0d                	jne    0x49b3
    49a6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    49a9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    49ac:	9a 09 2e d3 49       	call   0x49d3:0x2e09
    49b1:	eb 6a                	jmp    0x4a1d
    49b3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    49b6:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    49b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49bc:	26 3b 95 9e 01       	cmp    dx,WORD PTR es:[di+0x19e]
    49c1:	75 14                	jne    0x49d7
    49c3:	26 3b 85 9c 01       	cmp    ax,WORD PTR es:[di+0x19c]
    49c8:	75 0d                	jne    0x49d7
    49ca:	ff 76 0c             	push   WORD PTR [bp+0xc]
    49cd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    49d0:	9a 55 33 f7 49       	call   0x49f7:0x3355
    49d5:	eb 46                	jmp    0x4a1d
    49d7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    49da:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    49dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49e0:	26 3b 95 a2 01       	cmp    dx,WORD PTR es:[di+0x1a2]
    49e5:	75 14                	jne    0x49fb
    49e7:	26 3b 85 a0 01       	cmp    ax,WORD PTR es:[di+0x1a0]
    49ec:	75 0d                	jne    0x49fb
    49ee:	ff 76 0c             	push   WORD PTR [bp+0xc]
    49f1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    49f4:	9a 1c 3f 1b 4a       	call   0x4a1b:0x3f1c
    49f9:	eb 22                	jmp    0x4a1d
    49fb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    49fe:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4a01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a04:	26 3b 95 a6 01       	cmp    dx,WORD PTR es:[di+0x1a6]
    4a09:	75 12                	jne    0x4a1d
    4a0b:	26 3b 85 a4 01       	cmp    ax,WORD PTR es:[di+0x1a4]
    4a10:	75 0b                	jne    0x4a1d
    4a12:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4a15:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4a18:	9a a0 46 25 4a       	call   0x4a25:0x46a0
    4a1d:	c9                   	leave
    4a1e:	ca 08 00             	retf   0x8
    4a21:	00 00                	add    BYTE PTR [bx+si],al
    4a23:	08 4c 8b             	or     BYTE PTR [si-0x75],cl
    4a26:	4a                   	dec    dx
    4a27:	55                   	push   bp
    4a28:	89 e5                	mov    bp,sp
    4a2a:	31 c0                	xor    ax,ax
    4a2c:	9a 44 04 36 4c       	call   0x4c36:0x444
    4a31:	b8 21 4a             	mov    ax,0x4a21
    4a34:	0e                   	push   cs
    4a35:	50                   	push   ax
    4a36:	55                   	push   bp
    4a37:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4a3b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4a3f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a42:	06                   	push   es
    4a43:	57                   	push   di
    4a44:	9a d2 31 69 4a       	call   0x4a69:0x31d2
    4a49:	6a 00                	push   0x0
    4a4b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a4e:	06                   	push   es
    4a4f:	57                   	push   di
    4a50:	9a fb 2f 5f 4a       	call   0x4a5f:0x2ffb
    4a55:	6a 01                	push   0x1
    4a57:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a5a:	06                   	push   es
    4a5b:	57                   	push   di
    4a5c:	9a d2 2e 1c 4c       	call   0x4c1c:0x2ed2
    4a61:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4a64:	06                   	push   es
    4a65:	57                   	push   di
    4a66:	9a bf 31 10 4c       	call   0x4c10:0x31bf
    4a6b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4a6e:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4a71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a74:	26 3b 95 7e 01       	cmp    dx,WORD PTR es:[di+0x17e]
    4a79:	75 15                	jne    0x4a90
    4a7b:	26 3b 85 7c 01       	cmp    ax,WORD PTR es:[di+0x17c]
    4a80:	75 0e                	jne    0x4a90
    4a82:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4a85:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4a88:	9a 36 03 b0 4a       	call   0x4ab0:0x336
    4a8d:	e9 6c 01             	jmp    0x4bfc
    4a90:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4a93:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4a96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a99:	26 3b 95 82 01       	cmp    dx,WORD PTR es:[di+0x182]
    4a9e:	75 15                	jne    0x4ab5
    4aa0:	26 3b 85 80 01       	cmp    ax,WORD PTR es:[di+0x180]
    4aa5:	75 0e                	jne    0x4ab5
    4aa7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4aaa:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4aad:	9a 74 09 d5 4a       	call   0x4ad5:0x974
    4ab2:	e9 47 01             	jmp    0x4bfc
    4ab5:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4ab8:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4abb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4abe:	26 3b 95 86 01       	cmp    dx,WORD PTR es:[di+0x186]
    4ac3:	75 15                	jne    0x4ada
    4ac5:	26 3b 85 84 01       	cmp    ax,WORD PTR es:[di+0x184]
    4aca:	75 0e                	jne    0x4ada
    4acc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4acf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4ad2:	9a 50 0d fa 4a       	call   0x4afa:0xd50
    4ad7:	e9 22 01             	jmp    0x4bfc
    4ada:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4add:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4ae0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ae3:	26 3b 95 8a 01       	cmp    dx,WORD PTR es:[di+0x18a]
    4ae8:	75 15                	jne    0x4aff
    4aea:	26 3b 85 88 01       	cmp    ax,WORD PTR es:[di+0x188]
    4aef:	75 0e                	jne    0x4aff
    4af1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4af4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4af7:	9a f9 14 1f 4b       	call   0x4b1f:0x14f9
    4afc:	e9 fd 00             	jmp    0x4bfc
    4aff:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4b02:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4b05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b08:	26 3b 95 8e 01       	cmp    dx,WORD PTR es:[di+0x18e]
    4b0d:	75 15                	jne    0x4b24
    4b0f:	26 3b 85 8c 01       	cmp    ax,WORD PTR es:[di+0x18c]
    4b14:	75 0e                	jne    0x4b24
    4b16:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4b19:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b1c:	9a 92 1d 44 4b       	call   0x4b44:0x1d92
    4b21:	e9 d8 00             	jmp    0x4bfc
    4b24:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4b27:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4b2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b2d:	26 3b 95 92 01       	cmp    dx,WORD PTR es:[di+0x192]
    4b32:	75 15                	jne    0x4b49
    4b34:	26 3b 85 90 01       	cmp    ax,WORD PTR es:[di+0x190]
    4b39:	75 0e                	jne    0x4b49
    4b3b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4b3e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b41:	9a a7 24 69 4b       	call   0x4b69:0x24a7
    4b46:	e9 b3 00             	jmp    0x4bfc
    4b49:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4b4c:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4b4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b52:	26 3b 95 96 01       	cmp    dx,WORD PTR es:[di+0x196]
    4b57:	75 15                	jne    0x4b6e
    4b59:	26 3b 85 94 01       	cmp    ax,WORD PTR es:[di+0x194]
    4b5e:	75 0e                	jne    0x4b6e
    4b60:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4b63:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b66:	9a 3d 2a 8e 4b       	call   0x4b8e:0x2a3d
    4b6b:	e9 8e 00             	jmp    0x4bfc
    4b6e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4b71:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4b74:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b77:	26 3b 95 9a 01       	cmp    dx,WORD PTR es:[di+0x19a]
    4b7c:	75 14                	jne    0x4b92
    4b7e:	26 3b 85 98 01       	cmp    ax,WORD PTR es:[di+0x198]
    4b83:	75 0d                	jne    0x4b92
    4b85:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4b88:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4b8b:	9a 24 2f b2 4b       	call   0x4bb2:0x2f24
    4b90:	eb 6a                	jmp    0x4bfc
    4b92:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4b95:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4b98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b9b:	26 3b 95 9e 01       	cmp    dx,WORD PTR es:[di+0x19e]
    4ba0:	75 14                	jne    0x4bb6
    4ba2:	26 3b 85 9c 01       	cmp    ax,WORD PTR es:[di+0x19c]
    4ba7:	75 0d                	jne    0x4bb6
    4ba9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4bac:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4baf:	9a 3a 37 d6 4b       	call   0x4bd6:0x373a
    4bb4:	eb 46                	jmp    0x4bfc
    4bb6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4bb9:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4bbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bbf:	26 3b 95 a2 01       	cmp    dx,WORD PTR es:[di+0x1a2]
    4bc4:	75 14                	jne    0x4bda
    4bc6:	26 3b 85 a0 01       	cmp    ax,WORD PTR es:[di+0x1a0]
    4bcb:	75 0d                	jne    0x4bda
    4bcd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4bd0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4bd3:	9a c3 41 fa 4b       	call   0x4bfa:0x41c3
    4bd8:	eb 22                	jmp    0x4bfc
    4bda:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4bdd:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4be0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4be3:	26 3b 95 a6 01       	cmp    dx,WORD PTR es:[di+0x1a6]
    4be8:	75 12                	jne    0x4bfc
    4bea:	26 3b 85 a4 01       	cmp    ax,WORD PTR es:[di+0x1a4]
    4bef:	75 0b                	jne    0x4bfc
    4bf1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4bf4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4bf7:	9a 28 47 2b 4c       	call   0x4c2b:0x4728
    4bfc:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4c00:	83 c4 06             	add    sp,0x6
    4c03:	b8 1f 4c             	mov    ax,0x4c1f
    4c06:	0e                   	push   cs
    4c07:	50                   	push   ax
    4c08:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c0b:	06                   	push   es
    4c0c:	57                   	push   di
    4c0d:	9a d2 31 27 4c       	call   0x4c27:0x31d2
    4c12:	6a 00                	push   0x0
    4c14:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c17:	06                   	push   es
    4c18:	57                   	push   di
    4c19:	9a d2 2e 9f 4c       	call   0x4c9f:0x2ed2
    4c1e:	cb                   	retf
    4c1f:	c9                   	leave
    4c20:	ca 08 00             	retf   0x8
    4c23:	01 00                	add    WORD PTR [bx+si],ax
    4c25:	2f                   	das
    4c26:	00 7d 4c             	add    BYTE PTR [di+0x4c],bh
    4c29:	f4                   	hlt
    4c2a:	4c                   	dec    sp
    4c2b:	bc 4c 55             	mov    sp,0x554c
    4c2e:	89 e5                	mov    bp,sp
    4c30:	b8 56 01             	mov    ax,0x156
    4c33:	9a 44 04 13 4d       	call   0x4d13:0x444
    4c38:	81 ec 56 01          	sub    sp,0x156
    4c3c:	8c d3                	mov    bx,ss
    4c3e:	8e c3                	mov    es,bx
    4c40:	8c db                	mov    bx,ds
    4c42:	fc                   	cld
    4c43:	8d be fe fe          	lea    di,[bp-0x102]
    4c47:	c5 76 0e             	lds    si,DWORD PTR [bp+0xe]
    4c4a:	ac                   	lods   al,BYTE PTR ds:[si]
    4c4b:	aa                   	stos   BYTE PTR es:[di],al
    4c4c:	91                   	xchg   cx,ax
    4c4d:	30 ed                	xor    ch,ch
    4c4f:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    4c51:	8d be ae fe          	lea    di,[bp-0x152]
    4c55:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    4c58:	ac                   	lods   al,BYTE PTR ds:[si]
    4c59:	3c 4f                	cmp    al,0x4f
    4c5b:	72 02                	jb     0x4c5f
    4c5d:	b0 4f                	mov    al,0x4f
    4c5f:	aa                   	stos   BYTE PTR es:[di],al
    4c60:	91                   	xchg   cx,ax
    4c61:	30 ed                	xor    ch,ch
    4c63:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    4c65:	8e db                	mov    ds,bx
    4c67:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    4c6b:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    4c6e:	89 be aa fe          	mov    WORD PTR [bp-0x156],di
    4c72:	8c 86 ac fe          	mov    WORD PTR [bp-0x154],es
    4c76:	6a 00                	push   0x0
    4c78:	06                   	push   es
    4c79:	57                   	push   di
    4c7a:	9a 27 32 8e 4c       	call   0x4c8e:0x3227
    4c7f:	8d be ae fe          	lea    di,[bp-0x152]
    4c83:	16                   	push   ss
    4c84:	57                   	push   di
    4c85:	c4 be aa fe          	les    di,DWORD PTR [bp-0x156]
    4c89:	06                   	push   es
    4c8a:	57                   	push   di
    4c8b:	9a a9 5f b1 4e       	call   0x4eb1:0x5fa9
    4c90:	8d be fe fe          	lea    di,[bp-0x102]
    4c94:	16                   	push   ss
    4c95:	57                   	push   di
    4c96:	c4 be aa fe          	les    di,DWORD PTR [bp-0x156]
    4c9a:	06                   	push   es
    4c9b:	57                   	push   di
    4c9c:	9a 17 30 ac 4c       	call   0x4cac:0x3017
    4ca1:	6a 01                	push   0x1
    4ca3:	c4 be aa fe          	les    di,DWORD PTR [bp-0x156]
    4ca7:	06                   	push   es
    4ca8:	57                   	push   di
    4ca9:	9a 4f 30 d5 4c       	call   0x4cd5:0x304f
    4cae:	ff 76 14             	push   WORD PTR [bp+0x14]
    4cb1:	ff 76 12             	push   WORD PTR [bp+0x12]
    4cb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cb7:	06                   	push   es
    4cb8:	57                   	push   di
    4cb9:	9a 65 48 e5 4c       	call   0x4ce5:0x4865
    4cbe:	b8 23 4c             	mov    ax,0x4c23
    4cc1:	0e                   	push   cs
    4cc2:	50                   	push   ax
    4cc3:	55                   	push   bp
    4cc4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4cc8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4ccc:	c4 be aa fe          	les    di,DWORD PTR [bp-0x156]
    4cd0:	06                   	push   es
    4cd1:	57                   	push   di
    4cd2:	9a eb 1f 3e 4d       	call   0x4d3e:0x1feb
    4cd7:	ff 76 14             	push   WORD PTR [bp+0x14]
    4cda:	ff 76 12             	push   WORD PTR [bp+0x12]
    4cdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ce0:	06                   	push   es
    4ce1:	57                   	push   di
    4ce2:	9a 27 4a 14 4e       	call   0x4e14:0x4a27
    4ce7:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    4ceb:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4cef:	83 c4 06             	add    sp,0x6
    4cf2:	eb 26                	jmp    0x4d1a
    4cf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cf7:	06                   	push   es
    4cf8:	57                   	push   di
    4cf9:	9a b9 62 ff ff       	call   0xffff:0x62b9
    4cfe:	50                   	push   ax
    4cff:	bf 32 05             	mov    di,0x532
    4d02:	1e                   	push   ds
    4d03:	57                   	push   di
    4d04:	bf 3b 05             	mov    di,0x53b
    4d07:	1e                   	push   ds
    4d08:	57                   	push   di
    4d09:	6a 00                	push   0x0
    4d0b:	9a ff ff 00 00       	call   0x0:0xffff
    4d10:	ea 85 13 18 4d       	jmp    0x4d18:0x1385
    4d15:	9a 34 14 2a 4d       	call   0x4d2a:0x1434
    4d1a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4d1d:	c9                   	leave
    4d1e:	ca 10 00             	retf   0x10
    4d21:	00 55 89             	add    BYTE PTR [di-0x77],dl
    4d24:	e5 31                	in     ax,0x31
    4d26:	c0 9a 44 04 83       	rcr    BYTE PTR [bp+si+0x444],0x83
    4d2b:	4e                   	dec    si
    4d2c:	bf 21 4d             	mov    di,0x4d21
    4d2f:	0e                   	push   cs
    4d30:	57                   	push   di
    4d31:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d34:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    4d39:	06                   	push   es
    4d3a:	57                   	push   di
    4d3b:	9a 17 30 52 4d       	call   0x4d52:0x3017
    4d40:	bf 21 4d             	mov    di,0x4d21
    4d43:	0e                   	push   cs
    4d44:	57                   	push   di
    4d45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d48:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    4d4d:	06                   	push   es
    4d4e:	57                   	push   di
    4d4f:	9a 17 30 66 4d       	call   0x4d66:0x3017
    4d54:	bf 21 4d             	mov    di,0x4d21
    4d57:	0e                   	push   cs
    4d58:	57                   	push   di
    4d59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d5c:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    4d61:	06                   	push   es
    4d62:	57                   	push   di
    4d63:	9a 17 30 7a 4d       	call   0x4d7a:0x3017
    4d68:	bf 21 4d             	mov    di,0x4d21
    4d6b:	0e                   	push   cs
    4d6c:	57                   	push   di
    4d6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d70:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    4d75:	06                   	push   es
    4d76:	57                   	push   di
    4d77:	9a 17 30 8e 4d       	call   0x4d8e:0x3017
    4d7c:	bf 21 4d             	mov    di,0x4d21
    4d7f:	0e                   	push   cs
    4d80:	57                   	push   di
    4d81:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d84:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    4d89:	06                   	push   es
    4d8a:	57                   	push   di
    4d8b:	9a 17 30 a2 4d       	call   0x4da2:0x3017
    4d90:	bf 21 4d             	mov    di,0x4d21
    4d93:	0e                   	push   cs
    4d94:	57                   	push   di
    4d95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d98:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    4d9d:	06                   	push   es
    4d9e:	57                   	push   di
    4d9f:	9a 17 30 b6 4d       	call   0x4db6:0x3017
    4da4:	bf 21 4d             	mov    di,0x4d21
    4da7:	0e                   	push   cs
    4da8:	57                   	push   di
    4da9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dac:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    4db1:	06                   	push   es
    4db2:	57                   	push   di
    4db3:	9a 17 30 ca 4d       	call   0x4dca:0x3017
    4db8:	bf 21 4d             	mov    di,0x4d21
    4dbb:	0e                   	push   cs
    4dbc:	57                   	push   di
    4dbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dc0:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    4dc5:	06                   	push   es
    4dc6:	57                   	push   di
    4dc7:	9a 17 30 de 4d       	call   0x4dde:0x3017
    4dcc:	bf 21 4d             	mov    di,0x4d21
    4dcf:	0e                   	push   cs
    4dd0:	57                   	push   di
    4dd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dd4:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    4dd9:	06                   	push   es
    4dda:	57                   	push   di
    4ddb:	9a 17 30 f2 4d       	call   0x4df2:0x3017
    4de0:	bf 21 4d             	mov    di,0x4d21
    4de3:	0e                   	push   cs
    4de4:	57                   	push   di
    4de5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4de8:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    4ded:	06                   	push   es
    4dee:	57                   	push   di
    4def:	9a 17 30 06 4e       	call   0x4e06:0x3017
    4df4:	bf 21 4d             	mov    di,0x4d21
    4df7:	0e                   	push   cs
    4df8:	57                   	push   di
    4df9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dfc:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    4e01:	06                   	push   es
    4e02:	57                   	push   di
    4e03:	9a 17 30 bb 4e       	call   0x4ebb:0x3017
    4e08:	c9                   	leave
    4e09:	ca 04 00             	retf   0x4
    4e0c:	01 00                	add    WORD PTR [bx+si],ax
    4e0e:	00 00                	add    BYTE PTR [bx+si],al
    4e10:	00 00                	add    BYTE PTR [bx+si],al
    4e12:	c6                   	(bad)
    4e13:	4e                   	dec    si
    4e14:	1e                   	push   ds
    4e15:	4e                   	dec    si
    4e16:	01 00                	add    WORD PTR [bx+si],ax
    4e18:	00 00                	add    BYTE PTR [bx+si],al
    4e1a:	00 00                	add    BYTE PTR [bx+si],al
    4e1c:	09 4f 28             	or     WORD PTR [bx+0x28],cx
    4e1f:	4e                   	dec    si
    4e20:	01 00                	add    WORD PTR [bx+si],ax
    4e22:	00 00                	add    BYTE PTR [bx+si],al
    4e24:	00 00                	add    BYTE PTR [bx+si],al
    4e26:	4c                   	dec    sp
    4e27:	4f                   	dec    di
    4e28:	32 4e 01             	xor    cl,BYTE PTR [bp+0x1]
    4e2b:	00 00                	add    BYTE PTR [bx+si],al
    4e2d:	00 00                	add    BYTE PTR [bx+si],al
    4e2f:	00 8f 4f 3c          	add    BYTE PTR [bx+0x3c4f],cl
    4e33:	4e                   	dec    si
    4e34:	01 00                	add    WORD PTR [bx+si],ax
    4e36:	00 00                	add    BYTE PTR [bx+si],al
    4e38:	00 00                	add    BYTE PTR [bx+si],al
    4e3a:	d2 4f 46             	ror    BYTE PTR [bx+0x46],cl
    4e3d:	4e                   	dec    si
    4e3e:	01 00                	add    WORD PTR [bx+si],ax
    4e40:	00 00                	add    BYTE PTR [bx+si],al
    4e42:	00 00                	add    BYTE PTR [bx+si],al
    4e44:	15 50 50             	adc    ax,0x5050
    4e47:	4e                   	dec    si
    4e48:	01 00                	add    WORD PTR [bx+si],ax
    4e4a:	00 00                	add    BYTE PTR [bx+si],al
    4e4c:	00 00                	add    BYTE PTR [bx+si],al
    4e4e:	58                   	pop    ax
    4e4f:	50                   	push   ax
    4e50:	5a                   	pop    dx
    4e51:	4e                   	dec    si
    4e52:	01 00                	add    WORD PTR [bx+si],ax
    4e54:	00 00                	add    BYTE PTR [bx+si],al
    4e56:	00 00                	add    BYTE PTR [bx+si],al
    4e58:	9b                   	fwait
    4e59:	50                   	push   ax
    4e5a:	64 4e                	fs dec si
    4e5c:	01 00                	add    WORD PTR [bx+si],ax
    4e5e:	00 00                	add    BYTE PTR [bx+si],al
    4e60:	00 00                	add    BYTE PTR [bx+si],al
    4e62:	de 50 6e             	ficom  WORD PTR [bx+si+0x6e]
    4e65:	4e                   	dec    si
    4e66:	01 00                	add    WORD PTR [bx+si],ax
    4e68:	00 00                	add    BYTE PTR [bx+si],al
    4e6a:	00 00                	add    BYTE PTR [bx+si],al
    4e6c:	21 51 78             	and    WORD PTR [bx+di+0x78],dx
    4e6f:	4e                   	dec    si
    4e70:	01 00                	add    WORD PTR [bx+si],ax
    4e72:	00 00                	add    BYTE PTR [bx+si],al
    4e74:	00 00                	add    BYTE PTR [bx+si],al
    4e76:	64 51                	fs push cx
    4e78:	ff                   	(bad)
    4e79:	ff 55 89             	call   WORD PTR [di-0x77]
    4e7c:	e5 b8                	in     ax,0xb8
    4e7e:	04 00                	add    al,0x0
    4e80:	9a 44 04 c9 4e       	call   0x4ec9:0x444
    4e85:	83 ec 04             	sub    sp,0x4
    4e88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e8b:	26 c4 bd 7c 01       	les    di,DWORD PTR es:[di+0x17c]
    4e90:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4e93:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4e96:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    4e9c:	74 2d                	je     0x4ecb
    4e9e:	b8 0c 4e             	mov    ax,0x4e0c
    4ea1:	0e                   	push   cs
    4ea2:	50                   	push   ax
    4ea3:	55                   	push   bp
    4ea4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4ea8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4eac:	06                   	push   es
    4ead:	57                   	push   di
    4eae:	9a d2 31 f4 4e       	call   0x4ef4:0x31d2
    4eb3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4eb6:	06                   	push   es
    4eb7:	57                   	push   di
    4eb8:	9a 78 25 fe 4e       	call   0x4efe:0x2578
    4ebd:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4ec1:	83 c4 06             	add    sp,0x6
    4ec4:	eb 05                	jmp    0x4ecb
    4ec6:	9a 34 14 0c 4f       	call   0x4f0c:0x1434
    4ecb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ece:	26 c4 bd 80 01       	les    di,DWORD PTR es:[di+0x180]
    4ed3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4ed6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4ed9:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    4edf:	74 2d                	je     0x4f0e
    4ee1:	b8 16 4e             	mov    ax,0x4e16
    4ee4:	0e                   	push   cs
    4ee5:	50                   	push   ax
    4ee6:	55                   	push   bp
    4ee7:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4eeb:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4eef:	06                   	push   es
    4ef0:	57                   	push   di
    4ef1:	9a d2 31 37 4f       	call   0x4f37:0x31d2
    4ef6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4ef9:	06                   	push   es
    4efa:	57                   	push   di
    4efb:	9a 78 25 41 4f       	call   0x4f41:0x2578
    4f00:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4f04:	83 c4 06             	add    sp,0x6
    4f07:	eb 05                	jmp    0x4f0e
    4f09:	9a 34 14 4f 4f       	call   0x4f4f:0x1434
    4f0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f11:	26 c4 bd 84 01       	les    di,DWORD PTR es:[di+0x184]
    4f16:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4f19:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4f1c:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    4f22:	74 2d                	je     0x4f51
    4f24:	b8 20 4e             	mov    ax,0x4e20
    4f27:	0e                   	push   cs
    4f28:	50                   	push   ax
    4f29:	55                   	push   bp
    4f2a:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4f2e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4f32:	06                   	push   es
    4f33:	57                   	push   di
    4f34:	9a d2 31 7a 4f       	call   0x4f7a:0x31d2
    4f39:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4f3c:	06                   	push   es
    4f3d:	57                   	push   di
    4f3e:	9a 78 25 84 4f       	call   0x4f84:0x2578
    4f43:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4f47:	83 c4 06             	add    sp,0x6
    4f4a:	eb 05                	jmp    0x4f51
    4f4c:	9a 34 14 92 4f       	call   0x4f92:0x1434
    4f51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f54:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    4f59:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4f5c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4f5f:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    4f65:	74 2d                	je     0x4f94
    4f67:	b8 2a 4e             	mov    ax,0x4e2a
    4f6a:	0e                   	push   cs
    4f6b:	50                   	push   ax
    4f6c:	55                   	push   bp
    4f6d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4f71:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4f75:	06                   	push   es
    4f76:	57                   	push   di
    4f77:	9a d2 31 bd 4f       	call   0x4fbd:0x31d2
    4f7c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4f7f:	06                   	push   es
    4f80:	57                   	push   di
    4f81:	9a 78 25 c7 4f       	call   0x4fc7:0x2578
    4f86:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4f8a:	83 c4 06             	add    sp,0x6
    4f8d:	eb 05                	jmp    0x4f94
    4f8f:	9a 34 14 d5 4f       	call   0x4fd5:0x1434
    4f94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f97:	26 c4 bd 8c 01       	les    di,DWORD PTR es:[di+0x18c]
    4f9c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4f9f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4fa2:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    4fa8:	74 2d                	je     0x4fd7
    4faa:	b8 34 4e             	mov    ax,0x4e34
    4fad:	0e                   	push   cs
    4fae:	50                   	push   ax
    4faf:	55                   	push   bp
    4fb0:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4fb4:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4fb8:	06                   	push   es
    4fb9:	57                   	push   di
    4fba:	9a d2 31 00 50       	call   0x5000:0x31d2
    4fbf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4fc2:	06                   	push   es
    4fc3:	57                   	push   di
    4fc4:	9a 78 25 0a 50       	call   0x500a:0x2578
    4fc9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4fcd:	83 c4 06             	add    sp,0x6
    4fd0:	eb 05                	jmp    0x4fd7
    4fd2:	9a 34 14 18 50       	call   0x5018:0x1434
    4fd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fda:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    4fdf:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4fe2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4fe5:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    4feb:	74 2d                	je     0x501a
    4fed:	b8 3e 4e             	mov    ax,0x4e3e
    4ff0:	0e                   	push   cs
    4ff1:	50                   	push   ax
    4ff2:	55                   	push   bp
    4ff3:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4ff7:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4ffb:	06                   	push   es
    4ffc:	57                   	push   di
    4ffd:	9a d2 31 43 50       	call   0x5043:0x31d2
    5002:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5005:	06                   	push   es
    5006:	57                   	push   di
    5007:	9a 78 25 4d 50       	call   0x504d:0x2578
    500c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5010:	83 c4 06             	add    sp,0x6
    5013:	eb 05                	jmp    0x501a
    5015:	9a 34 14 5b 50       	call   0x505b:0x1434
    501a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    501d:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    5022:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5025:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5028:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    502e:	74 2d                	je     0x505d
    5030:	b8 48 4e             	mov    ax,0x4e48
    5033:	0e                   	push   cs
    5034:	50                   	push   ax
    5035:	55                   	push   bp
    5036:	ff 36 58 18          	push   WORD PTR ds:0x1858
    503a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    503e:	06                   	push   es
    503f:	57                   	push   di
    5040:	9a d2 31 86 50       	call   0x5086:0x31d2
    5045:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5048:	06                   	push   es
    5049:	57                   	push   di
    504a:	9a 78 25 90 50       	call   0x5090:0x2578
    504f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5053:	83 c4 06             	add    sp,0x6
    5056:	eb 05                	jmp    0x505d
    5058:	9a 34 14 9e 50       	call   0x509e:0x1434
    505d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5060:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    5065:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5068:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    506b:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    5071:	74 2d                	je     0x50a0
    5073:	b8 52 4e             	mov    ax,0x4e52
    5076:	0e                   	push   cs
    5077:	50                   	push   ax
    5078:	55                   	push   bp
    5079:	ff 36 58 18          	push   WORD PTR ds:0x1858
    507d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5081:	06                   	push   es
    5082:	57                   	push   di
    5083:	9a d2 31 c9 50       	call   0x50c9:0x31d2
    5088:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    508b:	06                   	push   es
    508c:	57                   	push   di
    508d:	9a 78 25 d3 50       	call   0x50d3:0x2578
    5092:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5096:	83 c4 06             	add    sp,0x6
    5099:	eb 05                	jmp    0x50a0
    509b:	9a 34 14 e1 50       	call   0x50e1:0x1434
    50a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50a3:	26 c4 bd 9c 01       	les    di,DWORD PTR es:[di+0x19c]
    50a8:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    50ab:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    50ae:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    50b4:	74 2d                	je     0x50e3
    50b6:	b8 5c 4e             	mov    ax,0x4e5c
    50b9:	0e                   	push   cs
    50ba:	50                   	push   ax
    50bb:	55                   	push   bp
    50bc:	ff 36 58 18          	push   WORD PTR ds:0x1858
    50c0:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    50c4:	06                   	push   es
    50c5:	57                   	push   di
    50c6:	9a d2 31 0c 51       	call   0x510c:0x31d2
    50cb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50ce:	06                   	push   es
    50cf:	57                   	push   di
    50d0:	9a 78 25 16 51       	call   0x5116:0x2578
    50d5:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    50d9:	83 c4 06             	add    sp,0x6
    50dc:	eb 05                	jmp    0x50e3
    50de:	9a 34 14 24 51       	call   0x5124:0x1434
    50e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50e6:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    50eb:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    50ee:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    50f1:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    50f7:	74 2d                	je     0x5126
    50f9:	b8 66 4e             	mov    ax,0x4e66
    50fc:	0e                   	push   cs
    50fd:	50                   	push   ax
    50fe:	55                   	push   bp
    50ff:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5103:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    5107:	06                   	push   es
    5108:	57                   	push   di
    5109:	9a d2 31 4f 51       	call   0x514f:0x31d2
    510e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5111:	06                   	push   es
    5112:	57                   	push   di
    5113:	9a 78 25 59 51       	call   0x5159:0x2578
    5118:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    511c:	83 c4 06             	add    sp,0x6
    511f:	eb 05                	jmp    0x5126
    5121:	9a 34 14 67 51       	call   0x5167:0x1434
    5126:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5129:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    512e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5131:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5134:	26 80 bd 84 01 00    	cmp    BYTE PTR es:[di+0x184],0x0
    513a:	74 2d                	je     0x5169
    513c:	b8 70 4e             	mov    ax,0x4e70
    513f:	0e                   	push   cs
    5140:	50                   	push   ax
    5141:	55                   	push   bp
    5142:	ff 36 58 18          	push   WORD PTR ds:0x1858
    5146:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    514a:	06                   	push   es
    514b:	57                   	push   di
    514c:	9a d2 31 ff ff       	call   0xffff:0x31d2
    5151:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5154:	06                   	push   es
    5155:	57                   	push   di
    5156:	9a 78 25 ff ff       	call   0xffff:0x2578
    515b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    515f:	83 c4 06             	add    sp,0x6
    5162:	eb 05                	jmp    0x5169
    5164:	9a 34 14 75 51       	call   0x5175:0x1434
    5169:	c9                   	leave
    516a:	ca 04 00             	retf   0x4
    516d:	55                   	push   bp
    516e:	89 e5                	mov    bp,sp
    5170:	31 c0                	xor    ax,ax
    5172:	9a 44 04 ff ff       	call   0xffff:0x444
    5177:	c9                   	leave
    5178:	ca                   	.byte 0xca
    5179:	08                   	.byte 0x8
