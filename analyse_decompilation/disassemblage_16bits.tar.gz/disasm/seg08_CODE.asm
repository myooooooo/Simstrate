; ================================================================
; seg08_CODE  (26789 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	08 00                	or     BYTE PTR [bx+si],al
       2:	e6 13                	out    0x13,al
       4:	1d 03 ac             	sbb    ax,0xac03
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 9e 00 96          	add    BYTE PTR [bp-0x6a00],bl
       d:	06                   	push   es
       e:	fb                   	sti
       f:	04 fb                	add    al,0xfb
      11:	13 39                	adc    di,WORD PTR [bx+di]
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 10 14 cb       	call   0xcb14:0x101f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 ba 20 d6          	adc    BYTE PTR [bp+si-0x29e0],bh
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c c2                	sbb    al,0xc2
      61:	14 e2                	adc    al,0xe2
      63:	2f                   	das
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	0d 54 46             	or     ax,0x4654
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	45                   	inc    bp
      a6:	52                   	push   dx
      a7:	47                   	inc    di
      a8:	5f                   	pop    di
      a9:	53                   	push   bx
      aa:	49                   	dec    cx
      ab:	47                   	inc    di
      ac:	20 00                	and    BYTE PTR [bx+si],al
      ae:	03 38                	add    di,WORD PTR [bx+si]
      b0:	c7 00 12 54          	mov    WORD PTR [bx+si],0x5412
      b4:	61                   	popa
      b5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
      b8:	45                   	inc    bp
      b9:	52                   	push   dx
      ba:	47                   	inc    di
      bb:	43                   	inc    bx
      bc:	61                   	popa
      bd:	6c                   	ins    BYTE PTR es:[di],dx
      be:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
      c1:	65 6c                	gs ins BYTE PTR es:[di],dx
      c3:	64 73 70             	fs jae 0x136
      c6:	16                   	push   ss
      c7:	da 00                	fiadd  DWORD PTR [bx+si]
      c9:	0e                   	push   cs
      ca:	49                   	dec    cx
      cb:	6d                   	ins    WORD PTR es:[di],dx
      cc:	70 72                	jo     0x140
      ce:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
      d3:	43                   	inc    bx
      d4:	6c                   	ins    BYTE PTR es:[di],dx
      d5:	69 63 6b ce 30       	imul   sp,WORD PTR [bp+di+0x6b],0x30ce
      da:	ec                   	in     al,dx
      db:	00 0d                	add    BYTE PTR [di],cl
      dd:	51                   	push   cx
      de:	75 69                	jne    0x149
      e0:	74 74                	je     0x156
      e2:	65 72 31             	gs jb  0x116
      e5:	43                   	inc    bx
      e6:	6c                   	ins    BYTE PTR es:[di],dx
      e7:	69 63 6b e6 30       	imul   sp,WORD PTR [bp+di+0x6b],0x30e6
      ec:	01 01                	add    WORD PTR [bx+di],ax
      ee:	10 50 6c             	adc    BYTE PTR [bx+si+0x6c],dl
      f1:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
      f7:	61                   	popa
      f8:	6e                   	outs   dx,BYTE PTR ds:[si]
      f9:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
      fc:	69 63 6b 3e 4b       	imul   sp,WORD PTR [bp+di+0x6b],0x4b3e
     101:	11 01                	adc    WORD PTR [bx+di],ax
     103:	0b 49 6e             	or     cx,WORD PTR [bx+di+0x6e]
     106:	64 65 78 31          	fs gs js 0x13b
     10a:	43                   	inc    bx
     10b:	6c                   	ins    BYTE PTR es:[di],dx
     10c:	69 63 6b 5d 4b       	imul   sp,WORD PTR [bp+di+0x6b],0x4b5d
     111:	26 01 10             	add    WORD PTR es:[bx+si],dx
     114:	52                   	push   dx
     115:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     119:	72 63                	jb     0x17e
     11b:	68 65 72             	push   0x7265
     11e:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     121:	69 63 6b 7e 4b       	imul   sp,WORD PTR [bp+di+0x6b],0x4b7e
     126:	3e 01 13             	add    WORD PTR ds:[bp+di],dx
     129:	55                   	push   bp
     12a:	74 69                	je     0x195
     12c:	6c                   	ins    BYTE PTR es:[di],dx
     12d:	69 73 65 72 6c       	imul   si,WORD PTR [bp+di+0x65],0x6c72
     132:	61                   	popa
     133:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     138:	6c                   	ins    BYTE PTR es:[di],dx
     139:	69 63 6b 9d 4b       	imul   sp,WORD PTR [bp+di+0x6b],0x4b9d
     13e:	50                   	push   ax
     13f:	01 0d                	add    WORD PTR [di],cx
     141:	41                   	inc    cx
     142:	70 72                	jo     0x1b6
     144:	6f                   	outs   dx,WORD PTR ds:[si]
     145:	70 6f                	jo     0x1b6
     147:	73 31                	jae    0x17a
     149:	43                   	inc    bx
     14a:	6c                   	ins    BYTE PTR es:[di],dx
     14b:	69 63 6b af 30       	imul   sp,WORD PTR [bp+di+0x6b],0x30af
     150:	5e                   	pop    si
     151:	01 09                	add    WORD PTR [bx+di],cx
     153:	46                   	inc    si
     154:	6f                   	outs   dx,WORD PTR ds:[si]
     155:	72 6d                	jb     0x1c4
     157:	43                   	inc    bx
     158:	6c                   	ins    BYTE PTR es:[di],dx
     159:	6f                   	outs   dx,WORD PTR ds:[si]
     15a:	73 65                	jae    0x1c1
     15c:	57                   	push   di
     15d:	2c 6d                	sub    al,0x6d
     15f:	01 0a                	add    WORD PTR [bp+si],cx
     161:	46                   	inc    si
     162:	6f                   	outs   dx,WORD PTR ds:[si]
     163:	72 6d                	jb     0x1d2
     165:	43                   	inc    bx
     166:	72 65                	jb     0x1cd
     168:	61                   	popa
     169:	74 65                	je     0x1d0
     16b:	47                   	inc    di
     16c:	49                   	dec    cx
     16d:	7d 01                	jge    0x170
     16f:	0b 46 6f             	or     ax,WORD PTR [bp+0x6f]
     172:	72 6d                	jb     0x1e1
     174:	4b                   	dec    bx
     175:	65 79 44             	gs jns 0x1bc
     178:	6f                   	outs   dx,WORD PTR ds:[si]
     179:	77 6e                	ja     0x1e9
     17b:	3f                   	aas
     17c:	32 8c 01 0a          	xor    cl,BYTE PTR [si+0xa01]
     180:	46                   	inc    si
     181:	6f                   	outs   dx,WORD PTR ds:[si]
     182:	72 6d                	jb     0x1f1
     184:	52                   	push   dx
     185:	65 73 69             	gs jae 0x1f1
     188:	7a 65                	jp     0x1ef
     18a:	68 32 9e             	push   0x9e32
     18d:	01 0d                	add    WORD PTR [di],cx
     18f:	50                   	push   ax
     190:	65 72 69             	gs jb  0x1fc
     193:	6f                   	outs   dx,WORD PTR ds:[si]
     194:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     199:	69 63 6b ad 33       	imul   sp,WORD PTR [bp+di+0x6b],0x33ad
     19e:	ab                   	stos   WORD PTR es:[di],ax
     19f:	01 08                	add    WORD PTR [bx+si],cx
     1a1:	4e                   	dec    si
     1a2:	31 31                	xor    WORD PTR [bx+di],si
     1a4:	43                   	inc    bx
     1a5:	6c                   	ins    BYTE PTR es:[di],dx
     1a6:	69 63 6b e1 1b       	imul   sp,WORD PTR [bp+di+0x6b],0x1be1
     1ab:	bd 01 0d             	mov    bp,0xd01
     1ae:	44                   	inc    sp
     1af:	42                   	inc    dx
     1b0:	45                   	inc    bp
     1b1:	64 69 74 31 30 31    	imul   si,WORD PTR fs:[si+0x31],0x3130
     1b7:	45                   	inc    bp
     1b8:	78 69                	js     0x223
     1ba:	74 91                	je     0x14d
     1bc:	1c d2                	sbb    al,0xd2
     1be:	01 10                	add    WORD PTR [bx+si],dx
     1c0:	44                   	inc    sp
     1c1:	42                   	inc    dx
     1c2:	45                   	inc    bp
     1c3:	64 69 74 31 30 31    	imul   si,WORD PTR fs:[si+0x31],0x3130
     1c9:	4b                   	dec    bx
     1ca:	65 79 44             	gs jns 0x211
     1cd:	6f                   	outs   dx,WORD PTR ds:[si]
     1ce:	77 6e                	ja     0x23e
     1d0:	2e 1c e5             	cs sbb al,0xe5
     1d3:	01 0e 44 42          	add    WORD PTR ds:0x4244,cx
     1d7:	45                   	inc    bp
     1d8:	64 69 74 31 30 31    	imul   si,WORD PTR fs:[si+0x31],0x3130
     1de:	4b                   	dec    bx
     1df:	65 79 55             	gs jns 0x237
     1e2:	70 94                	jo     0x178
     1e4:	30 f2                	xor    dl,dh
     1e6:	01 08                	add    WORD PTR [bx+si],cx
     1e8:	46                   	inc    si
     1e9:	6f                   	outs   dx,WORD PTR ds:[si]
     1ea:	72 6d                	jb     0x259
     1ec:	53                   	push   bx
     1ed:	68 6f 77             	push   0x776f
     1f0:	35 4c 09             	xor    ax,0x94c
     1f3:	02 12                	add    dl,BYTE PTR [bp+si]
     1f5:	44                   	inc    sp
     1f6:	42                   	inc    dx
     1f7:	45                   	inc    bp
     1f8:	64 69 74 31 30 31    	imul   si,WORD PTR fs:[si+0x31],0x3130
     1fe:	4d                   	dec    bp
     1ff:	6f                   	outs   dx,WORD PTR ds:[si]
     200:	75 73                	jne    0x275
     202:	65 44                	gs inc sp
     204:	6f                   	outs   dx,WORD PTR ds:[si]
     205:	77 6e                	ja     0x275
     207:	13 4b 19             	adc    cx,WORD PTR [bp+di+0x19]
     20a:	02 0b                	add    cl,BYTE PTR [bp+di]
     20c:	46                   	inc    si
     20d:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     212:	43                   	inc    bx
     213:	6c                   	ins    BYTE PTR es:[di],dx
     214:	69 63 6b 40 52       	imul   sp,WORD PTR [bp+di+0x6b],0x5240
     219:	2a 02                	sub    al,BYTE PTR [bp+si]
     21b:	0c 43                	or     al,0x43
     21d:	6f                   	outs   dx,WORD PTR ds:[si]
     21e:	70 69                	jo     0x289
     220:	65 72 31             	gs jb  0x254
     223:	43                   	inc    bx
     224:	6c                   	ins    BYTE PTR es:[di],dx
     225:	69 63 6b ec 4c       	imul   sp,WORD PTR [bp+di+0x6b],0x4cec
     22a:	40                   	inc    ax
     22b:	02 11                	add    dl,BYTE PTR [bx+di]
     22d:	50                   	push   ax
     22e:	61                   	popa
     22f:	6e                   	outs   dx,BYTE PTR ds:[si]
     230:	65 6c                	gs ins BYTE PTR es:[di],dx
     232:	31 30                	xor    WORD PTR [bx+si],si
     234:	31 4d 6f             	xor    WORD PTR [di+0x6f],cx
     237:	75 73                	jne    0x2ac
     239:	65 44                	gs inc sp
     23b:	6f                   	outs   dx,WORD PTR ds:[si]
     23c:	77 6e                	ja     0x2ac
     23e:	6e                   	outs   dx,BYTE PTR ds:[si]
     23f:	67 54                	addr32 push sp
     241:	02 0f                	add    cl,BYTE PTR [bx]
     243:	53                   	push   bx
     244:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     249:	69 6f 6e 31 43       	imul   bp,WORD PTR [bx+0x6e],0x4331
     24e:	6c                   	ins    BYTE PTR es:[di],dx
     24f:	69 63 6b 9c 67       	imul   sp,WORD PTR [bp+di+0x6b],0x679c
     254:	70 02                	jo     0x258
     256:	17                   	pop    ss
     257:	43                   	inc    bx
     258:	6f                   	outs   dx,WORD PTR ds:[si]
     259:	6d                   	ins    WORD PTR es:[di],dx
     25a:	70 74                	jo     0x2d0
     25c:	65 44                	gs inc sp
     25e:	65 52                	gs push dx
     260:	65 73 75             	gs jae 0x2d8
     263:	6c                   	ins    BYTE PTR es:[di],dx
     264:	74 61                	je     0x2c7
     266:	74 73                	je     0x2db
     268:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     26b:	69 63 6b ca 67       	imul   sp,WORD PTR [bp+di+0x6b],0x67ca
     270:	80 02 0b             	add    BYTE PTR [bp+si],0xb
     273:	42                   	inc    dx
     274:	69 6c 61 6e 31       	imul   bp,WORD PTR [si+0x61],0x316e
     279:	43                   	inc    bx
     27a:	6c                   	ins    BYTE PTR es:[di],dx
     27b:	69 63 6b f8 67       	imul   sp,WORD PTR [bp+di+0x6b],0x67f8
     280:	9f                   	lahf
     281:	02 1a                	add    bl,BYTE PTR [bp+si]
     283:	54                   	push   sp
     284:	61                   	popa
     285:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     288:	61                   	popa
     289:	75 44                	jne    0x2cf
     28b:	65 46                	gs inc si
     28d:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     292:	65 6d                	gs ins WORD PTR es:[di],dx
     294:	65 6e                	outs   dx,BYTE PTR gs:[si]
     296:	74 31                	je     0x2c9
     298:	43                   	inc    bx
     299:	6c                   	ins    BYTE PTR es:[di],dx
     29a:	69 63 6b 26 68       	imul   sp,WORD PTR [bp+di+0x6b],0x6826
     29f:	bd 02 19             	mov    bp,0x1902
     2a2:	54                   	push   sp
     2a3:	61                   	popa
     2a4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     2a7:	61                   	popa
     2a8:	75 44                	jne    0x2ee
     2aa:	65 54                	gs push sp
     2ac:	72 65                	jb     0x313
     2ae:	73 6f                	jae    0x31f
     2b0:	72 65                	jb     0x317
     2b2:	72 69                	jb     0x31d
     2b4:	65 31 43 6c          	xor    WORD PTR gs:[bp+di+0x6c],ax
     2b8:	69 63 6b 82 68       	imul   sp,WORD PTR [bp+di+0x6b],0x6882
     2bd:	da 02                	fiadd  DWORD PTR [bp+si]
     2bf:	18 52 61             	sbb    BYTE PTR [bp+si+0x61],dl
     2c2:	70 70                	jo     0x334
     2c4:	65 6c                	gs ins BYTE PTR es:[di],dx
     2c6:	44                   	inc    sp
     2c7:	65 73 44             	gs jae 0x30e
     2ca:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     2ce:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     2d3:	43                   	inc    bx
     2d4:	6c                   	ins    BYTE PTR es:[di],dx
     2d5:	69 63 6b 22 31       	imul   sp,WORD PTR [bp+di+0x6b],0x3122
     2da:	e9 02 0a             	jmp    0xcdf
     2dd:	4e                   	dec    si
     2de:	31 30                	xor    WORD PTR [bx+si],si
     2e0:	30 31                	xor    BYTE PTR [bx+di],dh
     2e2:	43                   	inc    bx
     2e3:	6c                   	ins    BYTE PTR es:[di],dx
     2e4:	69 63 6b 55 4d       	imul   sp,WORD PTR [bp+di+0x6b],0x4d55
     2e9:	04 03                	add    al,0x3
     2eb:	16                   	push   ss
     2ec:	49                   	dec    cx
     2ed:	6d                   	ins    WORD PTR es:[di],dx
     2ee:	70 72                	jo     0x362
     2f0:	65 73 73             	gs jae 0x366
     2f3:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     2f8:	70 69                	jo     0x363
     2fa:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     2ff:	69 63 6b af 32       	imul   sp,WORD PTR [bp+di+0x6b],0x32af
     304:	11 03                	adc    WORD PTR [bp+di],ax
     306:	08 4e 31             	or     BYTE PTR [bp+0x31],cl
     309:	32 43 6c             	xor    al,BYTE PTR [bp+di+0x6c]
     30c:	69 63 6b 54 68       	imul   sp,WORD PTR [bp+di+0x6b],0x6854
     311:	f7 13                	not    WORD PTR [bp+di]
     313:	09 53 49             	or     WORD PTR [bp+di+0x49],dx
     316:	47                   	inc    di
     317:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     31a:	69 63 6b 05 01       	imul   sp,WORD PTR [bp+di+0x6b],0x105
     31f:	b0 13                	mov    al,0x13
     321:	7c 01                	jl     0x324
     323:	00 00                	add    BYTE PTR [bx+si],al
     325:	06                   	push   es
     326:	50                   	push   ax
     327:	61                   	popa
     328:	6e                   	outs   dx,BYTE PTR ds:[si]
     329:	65 6c                	gs ins BYTE PTR es:[di],dx
     32b:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
     32f:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     333:	6e                   	outs   dx,BYTE PTR ds:[si]
     334:	65 6c                	gs ins BYTE PTR es:[di],dx
     336:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
     33a:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     33e:	6e                   	outs   dx,BYTE PTR ds:[si]
     33f:	65 6c                	gs ins BYTE PTR es:[di],dx
     341:	35 88 01             	xor    ax,0x188
     344:	00 00                	add    BYTE PTR [bx+si],al
     346:	06                   	push   es
     347:	50                   	push   ax
     348:	61                   	popa
     349:	6e                   	outs   dx,BYTE PTR ds:[si]
     34a:	65 6c                	gs ins BYTE PTR es:[di],dx
     34c:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     350:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     354:	6e                   	outs   dx,BYTE PTR ds:[si]
     355:	65 6c                	gs ins BYTE PTR es:[di],dx
     357:	36 90                	ss nop
     359:	01 00                	add    WORD PTR [bx+si],ax
     35b:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     35f:	6e                   	outs   dx,BYTE PTR ds:[si]
     360:	65 6c                	gs ins BYTE PTR es:[di],dx
     362:	37                   	aaa
     363:	94                   	xchg   sp,ax
     364:	01 00                	add    WORD PTR [bx+si],ax
     366:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     36a:	6e                   	outs   dx,BYTE PTR ds:[si]
     36b:	65 6c                	gs ins BYTE PTR es:[di],dx
     36d:	38 98 01 00          	cmp    BYTE PTR [bx+si+0x1],bl
     371:	00 07                	add    BYTE PTR [bx],al
     373:	50                   	push   ax
     374:	61                   	popa
     375:	6e                   	outs   dx,BYTE PTR ds:[si]
     376:	65 6c                	gs ins BYTE PTR es:[di],dx
     378:	33 37                	xor    si,WORD PTR [bx]
     37a:	9c                   	pushf
     37b:	01 00                	add    WORD PTR [bx+si],ax
     37d:	00 07                	add    BYTE PTR [bx],al
     37f:	50                   	push   ax
     380:	61                   	popa
     381:	6e                   	outs   dx,BYTE PTR ds:[si]
     382:	65 6c                	gs ins BYTE PTR es:[di],dx
     384:	33 38                	xor    di,WORD PTR [bx+si]
     386:	a0 01 04             	mov    al,ds:0x401
     389:	00 08                	add    BYTE PTR [bx+si],cl
     38b:	54                   	push   sp
     38c:	61                   	popa
     38d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     390:	41                   	inc    cx
     391:	44                   	inc    sp
     392:	47                   	inc    di
     393:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     394:	01 04                	add    WORD PTR [si],ax
     396:	00 09                	add    BYTE PTR [bx+di],cl
     398:	54                   	push   sp
     399:	61                   	popa
     39a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     39d:	41                   	inc    cx
     39e:	44                   	inc    sp
     39f:	50                   	push   ax
     3a0:	31 a8 01 04          	xor    WORD PTR [bx+si+0x401],bp
     3a4:	00 09                	add    BYTE PTR [bx+di],cl
     3a6:	54                   	push   sp
     3a7:	61                   	popa
     3a8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3ab:	41                   	inc    cx
     3ac:	44                   	inc    sp
     3ad:	50                   	push   ax
     3ae:	32 ac 01 04          	xor    ch,BYTE PTR [si+0x401]
     3b2:	00 08                	add    BYTE PTR [bx+si],cl
     3b4:	54                   	push   sp
     3b5:	61                   	popa
     3b6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3b9:	45                   	inc    bp
     3ba:	44                   	inc    sp
     3bb:	47                   	inc    di
     3bc:	b0 01                	mov    al,0x1
     3be:	04 00                	add    al,0x0
     3c0:	09 54 61             	or     WORD PTR [si+0x61],dx
     3c3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3c6:	45                   	inc    bp
     3c7:	44                   	inc    sp
     3c8:	50                   	push   ax
     3c9:	31 b4 01 04          	xor    WORD PTR [si+0x401],si
     3cd:	00 09                	add    BYTE PTR [bx+di],cl
     3cf:	54                   	push   sp
     3d0:	61                   	popa
     3d1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3d4:	45                   	inc    bp
     3d5:	44                   	inc    sp
     3d6:	50                   	push   ax
     3d7:	32 b8 01 04          	xor    bh,BYTE PTR [bx+si+0x401]
     3db:	00 0c                	add    BYTE PTR [si],cl
     3dd:	54                   	push   sp
     3de:	61                   	popa
     3df:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3e2:	45                   	inc    bp
     3e3:	52                   	push   dx
     3e4:	47                   	inc    di
     3e5:	5f                   	pop    di
     3e6:	4f                   	dec    di
     3e7:	6c                   	ins    BYTE PTR es:[di],dx
     3e8:	64 bc 01 04          	fs mov sp,0x401
     3ec:	00 08                	add    BYTE PTR [bx+si],cl
     3ee:	54                   	push   sp
     3ef:	61                   	popa
     3f0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     3f3:	45                   	inc    bp
     3f4:	52                   	push   dx
     3f5:	47                   	inc    di
     3f6:	c0 01 04             	rol    BYTE PTR [bx+di],0x4
     3f9:	00 09                	add    BYTE PTR [bx+di],cl
     3fb:	54                   	push   sp
     3fc:	61                   	popa
     3fd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     400:	45                   	inc    bp
     401:	52                   	push   dx
     402:	50                   	push   ax
     403:	31 c4                	xor    sp,ax
     405:	01 04                	add    WORD PTR [si],ax
     407:	00 09                	add    BYTE PTR [bx+di],cl
     409:	54                   	push   sp
     40a:	61                   	popa
     40b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     40e:	45                   	inc    bp
     40f:	52                   	push   dx
     410:	50                   	push   ax
     411:	32 c8                	xor    cl,al
     413:	01 08                	add    WORD PTR [bx+si],cx
     415:	00 0d                	add    BYTE PTR [di],cl
     417:	44                   	inc    sp
     418:	61                   	popa
     419:	74 61                	je     0x47c
     41b:	53                   	push   bx
     41c:	6f                   	outs   dx,WORD PTR ds:[si]
     41d:	75 72                	jne    0x491
     41f:	63 65 45             	arpl   WORD PTR [di+0x45],sp
     422:	52                   	push   dx
     423:	47                   	inc    di
     424:	cc                   	int3
     425:	01 0c                	add    WORD PTR [si],cx
     427:	00 12                	add    BYTE PTR [bp+si],dl
     429:	54                   	push   sp
     42a:	61                   	popa
     42b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     42e:	45                   	inc    bp
     42f:	52                   	push   dx
     430:	47                   	inc    di
     431:	46                   	inc    si
     432:	72 61                	jb     0x495
     434:	69 73 53 74 6f       	imul   si,WORD PTR [bp+di+0x53],0x6f74
     439:	63 6b d0             	arpl   WORD PTR [bp+di-0x30],bp
     43c:	01 10                	add    WORD PTR [bx+si],dx
     43e:	00 09                	add    BYTE PTR [bx+di],cl
     440:	4d                   	dec    bp
     441:	61                   	popa
     442:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     447:	75 31                	jne    0x47a
     449:	d4 01                	aam    0x1
     44b:	14 00                	adc    al,0x0
     44d:	08 46 69             	or     BYTE PTR [bp+0x69],al
     450:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     453:	65 72 31             	gs jb  0x487
     456:	d8 01                	fadd   DWORD PTR [bx+di]
     458:	14 00                	adc    al,0x0
     45a:	09 49 6d             	or     WORD PTR [bx+di+0x6d],cx
     45d:	70 72                	jo     0x4d1
     45f:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     464:	dc 01                	fadd   QWORD PTR [bx+di]
     466:	14 00                	adc    al,0x0
     468:	02 4e 31             	add    cl,BYTE PTR [bp+0x31]
     46b:	e0 01                	loopne 0x46e
     46d:	14 00                	adc    al,0x0
     46f:	08 51 75             	or     BYTE PTR [bx+di+0x75],dl
     472:	69 74 74 65 72       	imul   si,WORD PTR [si+0x74],0x7265
     477:	31 e4                	xor    sp,sp
     479:	01 14                	add    WORD PTR [si],dx
     47b:	00 0a                	add    BYTE PTR [bp+si],cl
     47d:	41                   	inc    cx
     47e:	66 66 69 63 68 61 67 	data32 imul esp,DWORD PTR [bp+di+0x68],0x31656761
     485:	65 31 
     487:	e8 01 14             	call   0x188b
     48a:	00 0d                	add    BYTE PTR [di],cl
     48c:	42                   	inc    dx
     48d:	61                   	popa
     48e:	72 72                	jb     0x502
     490:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     493:	75 74                	jne    0x509
     495:	69 6c 73 31 ec       	imul   bp,WORD PTR [si+0x73],0xec31
     49a:	01 14                	add    WORD PTR [si],dx
     49c:	00 0b                	add    BYTE PTR [bp+di],cl
     49e:	50                   	push   ax
     49f:	6c                   	ins    BYTE PTR es:[di],dx
     4a0:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     4a6:	61                   	popa
     4a7:	6e                   	outs   dx,BYTE PTR ds:[si]
     4a8:	31 f0                	xor    ax,si
     4aa:	01 14                	add    WORD PTR [si],dx
     4ac:	00 02                	add    BYTE PTR [bp+si],al
     4ae:	4e                   	dec    si
     4af:	32 f4                	xor    dh,ah
     4b1:	01 14                	add    WORD PTR [si],dx
     4b3:	00 05                	add    BYTE PTR [di],al
     4b5:	5a                   	pop    dx
     4b6:	6f                   	outs   dx,WORD PTR ds:[si]
     4b7:	6f                   	outs   dx,WORD PTR ds:[si]
     4b8:	6d                   	ins    WORD PTR es:[di],dx
     4b9:	31 f8                	xor    ax,di
     4bb:	01 14                	add    WORD PTR [si],dx
     4bd:	00 05                	add    BYTE PTR [di],al
     4bf:	41                   	inc    cx
     4c0:	69 64 65 31 fc       	imul   sp,WORD PTR [si+0x65],0xfc31
     4c5:	01 14                	add    WORD PTR [si],dx
     4c7:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     4cb:	64 65 78 31          	fs gs js 0x500
     4cf:	00 02                	add    BYTE PTR [bp+si],al
     4d1:	14 00                	adc    al,0x0
     4d3:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
     4d6:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     4d9:	72 63                	jb     0x53e
     4db:	68 65 72             	push   0x7265
     4de:	31 04                	xor    WORD PTR [si],ax
     4e0:	02 14                	add    dl,BYTE PTR [si]
     4e2:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     4e6:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     4eb:	72 6c                	jb     0x559
     4ed:	61                   	popa
     4ee:	69 64 65 31 08       	imul   sp,WORD PTR [si+0x65],0x831
     4f3:	02 14                	add    dl,BYTE PTR [si]
     4f5:	00 08                	add    BYTE PTR [bx+si],cl
     4f7:	41                   	inc    cx
     4f8:	70 72                	jo     0x56c
     4fa:	6f                   	outs   dx,WORD PTR ds:[si]
     4fb:	70 6f                	jo     0x56c
     4fd:	73 31                	jae    0x530
     4ff:	0c 02                	or     al,0x2
     501:	14 00                	adc    al,0x0
     503:	08 50 65             	or     BYTE PTR [bx+si+0x65],dl
     506:	72 69                	jb     0x571
     508:	6f                   	outs   dx,WORD PTR ds:[si]
     509:	64 65 31 10          	fs xor WORD PTR gs:[bx+si],dx
     50d:	02 14                	add    dl,BYTE PTR [si]
     50f:	00 0b                	add    BYTE PTR [bp+di],cl
     511:	45                   	inc    bp
     512:	6e                   	outs   dx,BYTE PTR ds:[si]
     513:	74 72                	je     0x587
     515:	65 70 72             	gs jo  0x58a
     518:	69 73 65 31 14       	imul   si,WORD PTR [bp+di+0x65],0x1431
     51d:	02 18                	add    bl,BYTE PTR [bx+si]
     51f:	00 0c                	add    BYTE PTR [si],cl
     521:	50                   	push   ax
     522:	72 69                	jb     0x58d
     524:	6e                   	outs   dx,BYTE PTR ds:[si]
     525:	74 44                	je     0x56b
     527:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     52c:	31 18                	xor    WORD PTR [bx+si],bx
     52e:	02 04                	add    al,BYTE PTR [si]
     530:	00 0c                	add    BYTE PTR [si],cl
     532:	54                   	push   sp
     533:	61                   	popa
     534:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     537:	41                   	inc    cx
     538:	44                   	inc    sp
     539:	47                   	inc    di
     53a:	5f                   	pop    di
     53b:	4f                   	dec    di
     53c:	6c                   	ins    BYTE PTR es:[di],dx
     53d:	64 1c 02             	fs sbb al,0x2
     540:	14 00                	adc    al,0x0
     542:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
     545:	31 20                	xor    WORD PTR [bx+si],sp
     547:	02 14                	add    dl,BYTE PTR [si]
     549:	00 03                	add    BYTE PTR [bp+di],al
     54b:	4e                   	dec    si
     54c:	32 31                	xor    dh,BYTE PTR [bx+di]
     54e:	24 02                	and    al,0x2
     550:	14 00                	adc    al,0x0
     552:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     555:	31 28                	xor    WORD PTR [bx+si],bp
     557:	02 14                	add    dl,BYTE PTR [si]
     559:	00 03                	add    BYTE PTR [bp+di],al
     55b:	4e                   	dec    si
     55c:	34 31                	xor    al,0x31
     55e:	2c 02                	sub    al,0x2
     560:	14 00                	adc    al,0x0
     562:	03 4e 35             	add    cx,WORD PTR [bp+0x35]
     565:	31 30                	xor    WORD PTR [bx+si],si
     567:	02 14                	add    dl,BYTE PTR [si]
     569:	00 03                	add    BYTE PTR [bp+di],al
     56b:	4e                   	dec    si
     56c:	36 31 34             	xor    WORD PTR ss:[si],si
     56f:	02 14                	add    dl,BYTE PTR [si]
     571:	00 03                	add    BYTE PTR [bp+di],al
     573:	4e                   	dec    si
     574:	37                   	aaa
     575:	31 38                	xor    WORD PTR [bx+si],di
     577:	02 14                	add    dl,BYTE PTR [si]
     579:	00 03                	add    BYTE PTR [bp+di],al
     57b:	4e                   	dec    si
     57c:	38 31                	cmp    BYTE PTR [bx+di],dh
     57e:	3c 02                	cmp    al,0x2
     580:	00 00                	add    BYTE PTR [bx+si],al
     582:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     585:	6e                   	outs   dx,BYTE PTR ds:[si]
     586:	65 6c                	gs ins BYTE PTR es:[di],dx
     588:	4c                   	dec    sp
     589:	4f                   	dec    di
     58a:	55                   	push   bp
     58b:	50                   	push   ax
     58c:	45                   	inc    bp
     58d:	40                   	inc    ax
     58e:	02 04                	add    al,BYTE PTR [si]
     590:	00 0d                	add    BYTE PTR [di],cl
     592:	54                   	push   sp
     593:	61                   	popa
     594:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     597:	45                   	inc    bp
     598:	52                   	push   dx
     599:	50                   	push   ax
     59a:	31 5f 4f             	xor    WORD PTR [bx+0x4f],bx
     59d:	6c                   	ins    BYTE PTR es:[di],dx
     59e:	64 44                	fs inc sp
     5a0:	02 04                	add    al,BYTE PTR [si]
     5a2:	00 0d                	add    BYTE PTR [di],cl
     5a4:	54                   	push   sp
     5a5:	61                   	popa
     5a6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5a9:	45                   	inc    bp
     5aa:	52                   	push   dx
     5ab:	50                   	push   ax
     5ac:	32 5f 4f             	xor    bl,BYTE PTR [bx+0x4f]
     5af:	6c                   	ins    BYTE PTR es:[di],dx
     5b0:	64 48                	fs dec ax
     5b2:	02 1c                	add    bl,BYTE PTR [si]
     5b4:	00 11                	add    BYTE PTR [bx+di],dl
     5b6:	54                   	push   sp
     5b7:	61                   	popa
     5b8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5bb:	45                   	inc    bp
     5bc:	52                   	push   dx
     5bd:	47                   	inc    di
     5be:	50                   	push   ax
     5bf:	65 72 69             	gs jb  0x62b
     5c2:	6f                   	outs   dx,WORD PTR ds:[si]
     5c3:	64 65 4e             	fs gs dec si
     5c6:	6f                   	outs   dx,WORD PTR ds:[si]
     5c7:	4c                   	dec    sp
     5c8:	02 1c                	add    bl,BYTE PTR [si]
     5ca:	00 14                	add    BYTE PTR [si],dl
     5cc:	54                   	push   sp
     5cd:	61                   	popa
     5ce:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5d1:	45                   	inc    bp
     5d2:	52                   	push   dx
     5d3:	47                   	inc    di
     5d4:	45                   	inc    bp
     5d5:	6e                   	outs   dx,BYTE PTR ds:[si]
     5d6:	74 72                	je     0x64a
     5d8:	65 70 72             	gs jo  0x64d
     5db:	69 73 65 4e 6f       	imul   si,WORD PTR [bp+di+0x65],0x6f4e
     5e0:	50                   	push   ax
     5e1:	02 20                	add    ah,BYTE PTR [bx+si]
     5e3:	00 15                	add    BYTE PTR [di],dl
     5e5:	54                   	push   sp
     5e6:	61                   	popa
     5e7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5ea:	45                   	inc    bp
     5eb:	52                   	push   dx
     5ec:	47                   	inc    di
     5ed:	43                   	inc    bx
     5ee:	61                   	popa
     5ef:	70 69                	jo     0x65a
     5f1:	74 61                	je     0x654
     5f3:	6c                   	ins    BYTE PTR es:[di],dx
     5f4:	53                   	push   bx
     5f5:	6f                   	outs   dx,WORD PTR ds:[si]
     5f6:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     5f9:	6c                   	ins    BYTE PTR es:[di],dx
     5fa:	54                   	push   sp
     5fb:	02 20                	add    ah,BYTE PTR [bx+si]
     5fd:	00 10                	add    BYTE PTR [bx+si],dl
     5ff:	54                   	push   sp
     600:	61                   	popa
     601:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     604:	45                   	inc    bp
     605:	52                   	push   dx
     606:	47                   	inc    di
     607:	52                   	push   dx
     608:	65 73 65             	gs jae 0x670
     60b:	72 76                	jb     0x683
     60d:	65 73 58             	gs jae 0x668
     610:	02 20                	add    ah,BYTE PTR [bx+si]
     612:	00 13                	add    BYTE PTR [bp+di],dl
     614:	54                   	push   sp
     615:	61                   	popa
     616:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     619:	45                   	inc    bp
     61a:	52                   	push   dx
     61b:	47                   	inc    di
     61c:	52                   	push   dx
     61d:	65 73 75             	gs jae 0x695
     620:	6c                   	ins    BYTE PTR es:[di],dx
     621:	74 61                	je     0x684
     623:	74 4e                	je     0x673
     625:	65 74 5c             	gs je  0x684
     628:	02 20                	add    ah,BYTE PTR [bx+si]
     62a:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     62e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     631:	45                   	inc    bp
     632:	52                   	push   dx
     633:	47                   	inc    di
     634:	53                   	push   bx
     635:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     63a:	69 6f 6e 4e 65       	imul   bp,WORD PTR [bx+0x6e],0x654e
     63f:	74 74                	je     0x6b5
     641:	65 60                	gs pusha
     643:	02 20                	add    ah,BYTE PTR [bx+si]
     645:	00 0b                	add    BYTE PTR [bp+di],cl
     647:	54                   	push   sp
     648:	61                   	popa
     649:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     64c:	45                   	inc    bp
     64d:	52                   	push   dx
     64e:	47                   	inc    di
     64f:	43                   	inc    bx
     650:	41                   	inc    cx
     651:	46                   	inc    si
     652:	64 02 20             	add    ah,BYTE PTR fs:[bx+si]
     655:	00 0d                	add    BYTE PTR [di],cl
     657:	54                   	push   sp
     658:	61                   	popa
     659:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     65c:	45                   	inc    bp
     65d:	52                   	push   dx
     65e:	47                   	inc    di
     65f:	49                   	dec    cx
     660:	6d                   	ins    WORD PTR es:[di],dx
     661:	70 6f                	jo     0x6d2
     663:	74 68                	je     0x6cd
     665:	02 20                	add    ah,BYTE PTR [bx+si]
     667:	00 0b                	add    BYTE PTR [bp+di],cl
     669:	54                   	push   sp
     66a:	61                   	popa
     66b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     66e:	45                   	inc    bp
     66f:	52                   	push   dx
     670:	47                   	inc    di
     671:	49                   	dec    cx
     672:	46                   	inc    si
     673:	41                   	inc    cx
     674:	6c                   	ins    BYTE PTR es:[di],dx
     675:	02 20                	add    ah,BYTE PTR [bx+si]
     677:	00 0f                	add    BYTE PTR [bx],cl
     679:	54                   	push   sp
     67a:	61                   	popa
     67b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     67e:	45                   	inc    bp
     67f:	52                   	push   dx
     680:	47                   	inc    di
     681:	43                   	inc    bx
     682:	6c                   	ins    BYTE PTR es:[di],dx
     683:	69 65 6e 74 73       	imul   sp,WORD PTR [di+0x6e],0x7374
     688:	70 02                	jo     0x68c
     68a:	20 00                	and    BYTE PTR [bx+si],al
     68c:	14 54                	adc    al,0x54
     68e:	61                   	popa
     68f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     692:	45                   	inc    bp
     693:	52                   	push   dx
     694:	47                   	inc    di
     695:	46                   	inc    si
     696:	6f                   	outs   dx,WORD PTR ds:[si]
     697:	75 72                	jne    0x70b
     699:	6e                   	outs   dx,BYTE PTR ds:[si]
     69a:	69 73 73 65 75       	imul   si,WORD PTR [bp+di+0x73],0x7565
     69f:	72 73                	jb     0x714
     6a1:	74 02                	je     0x6a5
     6a3:	20 00                	and    BYTE PTR [bx+si],al
     6a5:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     6a8:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6ab:	45                   	inc    bp
     6ac:	52                   	push   dx
     6ad:	47                   	inc    di
     6ae:	54                   	push   sp
     6af:	72 65                	jb     0x716
     6b1:	73 6f                	jae    0x722
     6b3:	72 65                	jb     0x71a
     6b5:	72 69                	jb     0x720
     6b7:	65 78 02             	gs js  0x6bc
     6ba:	20 00                	and    BYTE PTR [bx+si],al
     6bc:	0f 54 61 62          	andps  xmm4,XMMWORD PTR [bx+di+0x62]
     6c0:	6c                   	ins    BYTE PTR es:[di],dx
     6c1:	65 45                	gs inc bp
     6c3:	52                   	push   dx
     6c4:	47                   	inc    di
     6c5:	45                   	inc    bp
     6c6:	6d                   	ins    WORD PTR es:[di],dx
     6c7:	70 72                	jo     0x73b
     6c9:	75 6e                	jne    0x739
     6cb:	74 7c                	je     0x749
     6cd:	02 20                	add    ah,BYTE PTR [bx+si]
     6cf:	00 15                	add    BYTE PTR [di],dl
     6d1:	54                   	push   sp
     6d2:	61                   	popa
     6d3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6d6:	45                   	inc    bp
     6d7:	52                   	push   dx
     6d8:	47                   	inc    di
     6d9:	44                   	inc    sp
     6da:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     6de:	76 65                	jbe    0x745
     6e0:	72 74                	jb     0x756
     6e2:	41                   	inc    cx
     6e3:	75 74                	jne    0x759
     6e5:	6f                   	outs   dx,WORD PTR ds:[si]
     6e6:	80 02 20             	add    BYTE PTR [bp+si],0x20
     6e9:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     6ed:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     6f0:	45                   	inc    bp
     6f1:	52                   	push   dx
     6f2:	47                   	inc    di
     6f3:	44                   	inc    sp
     6f4:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
     6f8:	76 65                	jbe    0x75f
     6fa:	72 74                	jb     0x770
     6fc:	4e                   	dec    si
     6fd:	41                   	inc    cx
     6fe:	75 74                	jne    0x774
     700:	6f                   	outs   dx,WORD PTR ds:[si]
     701:	84 02                	test   BYTE PTR [bp+si],al
     703:	20 00                	and    BYTE PTR [bx+si],al
     705:	15 54 61             	adc    ax,0x6154
     708:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     70b:	45                   	inc    bp
     70c:	52                   	push   dx
     70d:	47                   	inc    di
     70e:	41                   	inc    cx
     70f:	6d                   	ins    WORD PTR es:[di],dx
     710:	6f                   	outs   dx,WORD PTR ds:[si]
     711:	72 74                	jb     0x787
     713:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     718:	65 6e                	outs   dx,BYTE PTR gs:[si]
     71a:	74 88                	je     0x6a4
     71c:	02 20                	add    ah,BYTE PTR [bx+si]
     71e:	00 10                	add    BYTE PTR [bx+si],dl
     720:	54                   	push   sp
     721:	61                   	popa
     722:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     725:	45                   	inc    bp
     726:	52                   	push   dx
     727:	47                   	inc    di
     728:	43                   	inc    bx
     729:	65 73 73             	gs jae 0x79f
     72c:	69 6f 6e 73 8c       	imul   bp,WORD PTR [bx+0x6e],0x8c73
     731:	02 1c                	add    bl,BYTE PTR [si]
     733:	00 10                	add    BYTE PTR [bx+si],dl
     735:	54                   	push   sp
     736:	61                   	popa
     737:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     73a:	45                   	inc    bp
     73b:	52                   	push   dx
     73c:	47                   	inc    di
     73d:	4d                   	dec    bp
     73e:	61                   	popa
     73f:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     742:	6e                   	outs   dx,BYTE PTR ds:[si]
     743:	65 73 90             	gs jae 0x6d6
     746:	02 20                	add    ah,BYTE PTR [bx+si]
     748:	00 1d                	add    BYTE PTR [di],bl
     74a:	54                   	push   sp
     74b:	61                   	popa
     74c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     74f:	45                   	inc    bp
     750:	52                   	push   dx
     751:	47                   	inc    di
     752:	49                   	dec    cx
     753:	6d                   	ins    WORD PTR es:[di],dx
     754:	6d                   	ins    WORD PTR es:[di],dx
     755:	6f                   	outs   dx,WORD PTR ds:[si]
     756:	62 69 6c             	bound  bp,DWORD PTR [bx+di+0x6c]
     759:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     75e:	6f                   	outs   dx,WORD PTR ds:[si]
     75f:	6e                   	outs   dx,BYTE PTR ds:[si]
     760:	73 42                	jae    0x7a4
     762:	72 75                	jb     0x7d9
     764:	74 65                	je     0x7cb
     766:	73 94                	jae    0x6fc
     768:	02 1c                	add    bl,BYTE PTR [si]
     76a:	00 12                	add    BYTE PTR [bp+si],dl
     76c:	54                   	push   sp
     76d:	61                   	popa
     76e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     771:	45                   	inc    bp
     772:	52                   	push   dx
     773:	47                   	inc    di
     774:	50                   	push   ax
     775:	72 6f                	jb     0x7e6
     777:	64 75 63             	fs jne 0x7dd
     77a:	74 69                	je     0x7e5
     77c:	66 73 98             	data32 jae 0x717
     77f:	02 1c                	add    bl,BYTE PTR [si]
     781:	00 10                	add    BYTE PTR [bx+si],dl
     783:	54                   	push   sp
     784:	61                   	popa
     785:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     788:	45                   	inc    bp
     789:	52                   	push   dx
     78a:	47                   	inc    di
     78b:	56                   	push   si
     78c:	65 6e                	outs   dx,BYTE PTR gs:[si]
     78e:	64 65 75 72          	fs gs jne 0x804
     792:	73 9c                	jae    0x730
     794:	02 1c                	add    bl,BYTE PTR [si]
     796:	00 0e 54 61          	add    BYTE PTR ds:0x6154,cl
     79a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     79d:	45                   	inc    bp
     79e:	52                   	push   dx
     79f:	47                   	inc    di
     7a0:	43                   	inc    bx
     7a1:	61                   	popa
     7a2:	64 72 65             	fs jb  0x80a
     7a5:	73 a0                	jae    0x747
     7a7:	02 20                	add    ah,BYTE PTR [bx+si]
     7a9:	00 14                	add    BYTE PTR [si],dl
     7ab:	54                   	push   sp
     7ac:	61                   	popa
     7ad:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7b0:	45                   	inc    bp
     7b1:	52                   	push   dx
     7b2:	47                   	inc    di
     7b3:	43                   	inc    bx
     7b4:	6f                   	outs   dx,WORD PTR ds:[si]
     7b5:	75 74                	jne    0x82b
     7b7:	45                   	inc    bp
     7b8:	6d                   	ins    WORD PTR es:[di],dx
     7b9:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
     7bc:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     7bf:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     7c0:	02 20                	add    ah,BYTE PTR [bx+si]
     7c2:	00 14                	add    BYTE PTR [si],dl
     7c4:	54                   	push   sp
     7c5:	61                   	popa
     7c6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7c9:	45                   	inc    bp
     7ca:	52                   	push   dx
     7cb:	47                   	inc    di
     7cc:	43                   	inc    bx
     7cd:	6f                   	outs   dx,WORD PTR ds:[si]
     7ce:	75 74                	jne    0x844
     7d0:	4c                   	dec    sp
     7d1:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
     7d6:	69 65 a8 02 20       	imul   sp,WORD PTR [di-0x58],0x2002
     7db:	00 15                	add    BYTE PTR [di],dl
     7dd:	54                   	push   sp
     7de:	61                   	popa
     7df:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7e2:	45                   	inc    bp
     7e3:	52                   	push   dx
     7e4:	47                   	inc    di
     7e5:	43                   	inc    bx
     7e6:	6f                   	outs   dx,WORD PTR ds:[si]
     7e7:	75 74                	jne    0x85d
     7e9:	46                   	inc    si
     7ea:	6f                   	outs   dx,WORD PTR ds:[si]
     7eb:	72 6d                	jb     0x85a
     7ed:	61                   	popa
     7ee:	74 69                	je     0x859
     7f0:	6f                   	outs   dx,WORD PTR ds:[si]
     7f1:	6e                   	outs   dx,BYTE PTR ds:[si]
     7f2:	ac                   	lods   al,BYTE PTR ds:[si]
     7f3:	02 20                	add    ah,BYTE PTR [bx+si]
     7f5:	00 15                	add    BYTE PTR [di],dl
     7f7:	54                   	push   sp
     7f8:	61                   	popa
     7f9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     7fc:	45                   	inc    bp
     7fd:	52                   	push   dx
     7fe:	47                   	inc    di
     7ff:	44                   	inc    sp
     800:	69 73 74 72 69       	imul   si,WORD PTR [bp+di+0x74],0x6972
     805:	62 75 74             	bound  si,DWORD PTR [di+0x74]
     808:	69 6f 6e 73 b0       	imul   bp,WORD PTR [bx+0x6e],0xb073
     80d:	02 1c                	add    bl,BYTE PTR [si]
     80f:	00 0f                	add    BYTE PTR [bx],cl
     811:	54                   	push   sp
     812:	61                   	popa
     813:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     816:	45                   	inc    bp
     817:	52                   	push   dx
     818:	47                   	inc    di
     819:	53                   	push   bx
     81a:	70 65                	jo     0x881
     81c:	63 69 61             	arpl   WORD PTR [bx+di+0x61],bp
     81f:	6c                   	ins    BYTE PTR es:[di],dx
     820:	b4 02                	mov    ah,0x2
     822:	0c 00                	or     al,0x0
     824:	11 54 61             	adc    WORD PTR [si+0x61],dx
     827:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     82a:	45                   	inc    bp
     82b:	52                   	push   dx
     82c:	47                   	inc    di
     82d:	43                   	inc    bx
     82e:	68 61 72             	push   0x7261
     831:	67 65 73 45          	addr32 gs jae 0x87a
     835:	78 b8                	js     0x7ef
     837:	02 20                	add    ah,BYTE PTR [bx+si]
     839:	00 1a                	add    BYTE PTR [bp+si],bl
     83b:	54                   	push   sp
     83c:	61                   	popa
     83d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     840:	45                   	inc    bp
     841:	52                   	push   dx
     842:	47                   	inc    di
     843:	52                   	push   dx
     844:	65 6d                	gs ins WORD PTR es:[di],dx
     846:	75 6e                	jne    0x8b6
     848:	65 72 61             	gs jb  0x8ac
     84b:	74 69                	je     0x8b6
     84d:	6f                   	outs   dx,WORD PTR ds:[si]
     84e:	6e                   	outs   dx,BYTE PTR ds:[si]
     84f:	43                   	inc    bx
     850:	61                   	popa
     851:	64 72 65             	fs jb  0x8b9
     854:	73 bc                	jae    0x812
     856:	02 14                	add    dl,BYTE PTR [si]
     858:	00 06 46 69          	add    BYTE PTR ds:0x6946,al
     85c:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     85f:	31 c0                	xor    ax,ax
     861:	02 14                	add    dl,BYTE PTR [si]
     863:	00 02                	add    BYTE PTR [bp+si],al
     865:	4e                   	dec    si
     866:	33 c4                	xor    ax,sp
     868:	02 00                	add    al,BYTE PTR [bx+si]
     86a:	00 07                	add    BYTE PTR [bx],al
     86c:	50                   	push   ax
     86d:	61                   	popa
     86e:	6e                   	outs   dx,BYTE PTR ds:[si]
     86f:	65 6c                	gs ins BYTE PTR es:[di],dx
     871:	34 34                	xor    al,0x34
     873:	c8 02 24 00          	enter  0x2402,0x0
     877:	07                   	pop    es
     878:	4c                   	dec    sp
     879:	61                   	popa
     87a:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     87d:	55                   	push   bp
     87e:	30 cc                	xor    ah,cl
     880:	02 24                	add    ah,BYTE PTR [si]
     882:	00 07                	add    BYTE PTR [bx],al
     884:	4c                   	dec    sp
     885:	61                   	popa
     886:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     889:	55                   	push   bp
     88a:	31 d0                	xor    ax,dx
     88c:	02 24                	add    ah,BYTE PTR [si]
     88e:	00 07                	add    BYTE PTR [bx],al
     890:	4c                   	dec    sp
     891:	61                   	popa
     892:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     895:	55                   	push   bp
     896:	32 d4                	xor    dl,ah
     898:	02 24                	add    ah,BYTE PTR [si]
     89a:	00 07                	add    BYTE PTR [bx],al
     89c:	4c                   	dec    sp
     89d:	61                   	popa
     89e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     8a1:	55                   	push   bp
     8a2:	33 d8                	xor    bx,ax
     8a4:	02 28                	add    ch,BYTE PTR [bx+si]
     8a6:	00 05                	add    BYTE PTR [di],al
     8a8:	4d                   	dec    bp
     8a9:	65 6d                	gs ins WORD PTR es:[di],dx
     8ab:	6f                   	outs   dx,WORD PTR ds:[si]
     8ac:	31 dc                	xor    sp,bx
     8ae:	02 14                	add    dl,BYTE PTR [si]
     8b0:	00 08                	add    BYTE PTR [bx+si],cl
     8b2:	45                   	inc    bp
     8b3:	64 69 74 69 6f 6e    	imul   si,WORD PTR fs:[si+0x69],0x6e6f
     8b9:	31 e0                	xor    ax,sp
     8bb:	02 14                	add    dl,BYTE PTR [si]
     8bd:	00 07                	add    BYTE PTR [bx],al
     8bf:	43                   	inc    bx
     8c0:	6f                   	outs   dx,WORD PTR ds:[si]
     8c1:	70 69                	jo     0x92c
     8c3:	65 72 31             	gs jb  0x8f7
     8c6:	e4 02                	in     al,0x2
     8c8:	20 00                	and    BYTE PTR [bx+si],al
     8ca:	15 54 61             	adc    ax,0x6154
     8cd:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8d0:	45                   	inc    bp
     8d1:	52                   	push   dx
     8d2:	47                   	inc    di
     8d3:	52                   	push   dx
     8d4:	65 6d                	gs ins WORD PTR es:[di],dx
     8d6:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
     8d9:	72 73                	jb     0x94e
     8db:	41                   	inc    cx
     8dc:	73 73                	jae    0x951
     8de:	75 72                	jne    0x952
     8e0:	e8 02 20             	call   0x28e5
     8e3:	00 19                	add    BYTE PTR [bx+di],bl
     8e5:	54                   	push   sp
     8e6:	61                   	popa
     8e7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     8ea:	45                   	inc    bp
     8eb:	52                   	push   dx
     8ec:	47                   	inc    di
     8ed:	49                   	dec    cx
     8ee:	6e                   	outs   dx,BYTE PTR ds:[si]
     8ef:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
     8f5:	74 69                	je     0x960
     8f7:	73 41                	jae    0x93a
     8f9:	63 74 69             	arpl   WORD PTR [si+0x69],si
     8fc:	6f                   	outs   dx,WORD PTR ds:[si]
     8fd:	6e                   	outs   dx,BYTE PTR ds:[si]
     8fe:	ec                   	in     al,dx
     8ff:	02 20                	add    ah,BYTE PTR [bx+si]
     901:	00 10                	add    BYTE PTR [bx+si],dl
     903:	54                   	push   sp
     904:	61                   	popa
     905:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     908:	45                   	inc    bp
     909:	52                   	push   dx
     90a:	47                   	inc    di
     90b:	50                   	push   ax
     90c:	61                   	popa
     90d:	6e                   	outs   dx,BYTE PTR ds:[si]
     90e:	6e                   	outs   dx,BYTE PTR ds:[si]
     90f:	65 73 50             	gs jae 0x962
     912:	63 f0                	arpl   ax,si
     914:	02 20                	add    ah,BYTE PTR [bx+si]
     916:	00 10                	add    BYTE PTR [bx+si],dl
     918:	54                   	push   sp
     919:	61                   	popa
     91a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     91d:	45                   	inc    bp
     91e:	52                   	push   dx
     91f:	47                   	inc    di
     920:	47                   	inc    di
     921:	72 65                	jb     0x988
     923:	76 65                	jbe    0x98a
     925:	73 50                	jae    0x977
     927:	63 f4                	arpl   sp,si
     929:	02 1c                	add    bl,BYTE PTR [si]
     92b:	00 1c                	add    BYTE PTR [si],bl
     92d:	54                   	push   sp
     92e:	61                   	popa
     92f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     932:	45                   	inc    bp
     933:	52                   	push   dx
     934:	47                   	inc    di
     935:	4d                   	dec    bp
     936:	61                   	popa
     937:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     93a:	6e                   	outs   dx,BYTE PTR ds:[si]
     93b:	65 73 44             	gs jae 0x982
     93e:	65 74 72             	gs je  0x9b3
     941:	75 69                	jne    0x9ac
     943:	74 65                	je     0x9aa
     945:	73 51                	jae    0x998
     947:	74 65                	je     0x9ae
     949:	f8                   	clc
     94a:	02 1c                	add    bl,BYTE PTR [si]
     94c:	00 17                	add    BYTE PTR [bx],dl
     94e:	54                   	push   sp
     94f:	61                   	popa
     950:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     953:	45                   	inc    bp
     954:	52                   	push   dx
     955:	47                   	inc    di
     956:	53                   	push   bx
     957:	74 6f                	je     0x9c8
     959:	63 6b 44             	arpl   WORD PTR [bp+di+0x44],bp
     95c:	65 74 72             	gs je  0x9d1
     95f:	75 69                	jne    0x9ca
     961:	74 51                	je     0x9b4
     963:	74 65                	je     0x9ca
     965:	fc                   	cld
     966:	02 1c                	add    bl,BYTE PTR [si]
     968:	00 1c                	add    BYTE PTR [si],bl
     96a:	54                   	push   sp
     96b:	61                   	popa
     96c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     96f:	45                   	inc    bp
     970:	52                   	push   dx
     971:	47                   	inc    di
     972:	44                   	inc    sp
     973:	65 6d                	gs ins WORD PTR es:[di],dx
     975:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
     97a:	6e                   	outs   dx,BYTE PTR ds:[si]
     97b:	73 50                	jae    0x9cd
     97d:	72 6f                	jb     0x9ee
     97f:	64 75 63             	fs jne 0x9e5
     982:	74 69                	je     0x9ed
     984:	66 73 00             	data32 jae 0x987
     987:	03 1c                	add    bx,WORD PTR [si]
     989:	00 1a                	add    BYTE PTR [bp+si],bl
     98b:	54                   	push   sp
     98c:	61                   	popa
     98d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     990:	45                   	inc    bp
     991:	52                   	push   dx
     992:	47                   	inc    di
     993:	44                   	inc    sp
     994:	65 6d                	gs ins WORD PTR es:[di],dx
     996:	69 73 73 69 6f       	imul   si,WORD PTR [bp+di+0x73],0x6f69
     99b:	6e                   	outs   dx,BYTE PTR ds:[si]
     99c:	73 56                	jae    0x9f4
     99e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     9a0:	64 65 75 72          	fs gs jne 0xa16
     9a4:	73 04                	jae    0x9aa
     9a6:	03 20                	add    sp,WORD PTR [bx+si]
     9a8:	00 18                	add    BYTE PTR [bx+si],bl
     9aa:	54                   	push   sp
     9ab:	61                   	popa
     9ac:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9af:	45                   	inc    bp
     9b0:	52                   	push   dx
     9b1:	47                   	inc    di
     9b2:	41                   	inc    cx
     9b3:	67 65 4d             	addr32 gs dec bp
     9b6:	6f                   	outs   dx,WORD PTR ds:[si]
     9b7:	79 65                	jns    0xa1e
     9b9:	6e                   	outs   dx,BYTE PTR ds:[si]
     9ba:	4d                   	dec    bp
     9bb:	61                   	popa
     9bc:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     9bf:	6e                   	outs   dx,BYTE PTR ds:[si]
     9c0:	65 73 08             	gs jae 0x9cb
     9c3:	03 20                	add    sp,WORD PTR [bx+si]
     9c5:	00 17                	add    BYTE PTR [bx],dl
     9c7:	54                   	push   sp
     9c8:	61                   	popa
     9c9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9cc:	45                   	inc    bp
     9cd:	52                   	push   dx
     9ce:	47                   	inc    di
     9cf:	50                   	push   ax
     9d0:	72 69                	jb     0xa3b
     9d2:	6d                   	ins    WORD PTR es:[di],dx
     9d3:	65 73 41             	gs jae 0xa17
     9d6:	73 73                	jae    0xa4b
     9d8:	75 72                	jne    0xa4c
     9da:	61                   	popa
     9db:	6e                   	outs   dx,BYTE PTR ds:[si]
     9dc:	63 65 0c             	arpl   WORD PTR [di+0xc],sp
     9df:	03 14                	add    dx,WORD PTR [si]
     9e1:	00 0f                	add    BYTE PTR [bx],cl
     9e3:	41                   	inc    cx
     9e4:	75 74                	jne    0xa5a
     9e6:	72 65                	jb     0xa4d
     9e8:	73 72                	jae    0xa5c
     9ea:	73 75                	jae    0xa61
     9ec:	6c                   	ins    BYTE PTR es:[di],dx
     9ed:	74 61                	je     0xa50
     9ef:	74 73                	je     0xa64
     9f1:	31 10                	xor    WORD PTR [bx+si],dx
     9f3:	03 14                	add    dx,WORD PTR [si]
     9f5:	00 13                	add    BYTE PTR [bp+di],dl
     9f7:	52                   	push   dx
     9f8:	61                   	popa
     9f9:	70 70                	jo     0xa6b
     9fb:	65 6c                	gs ins BYTE PTR es:[di],dx
     9fd:	44                   	inc    sp
     9fe:	65 73 44             	gs jae 0xa45
     a01:	65 63 69 73          	arpl   WORD PTR gs:[bx+di+0x73],bp
     a05:	69 6f 6e 73 31       	imul   bp,WORD PTR [bx+0x6e],0x3173
     a0a:	14 03                	adc    al,0x3
     a0c:	14 00                	adc    al,0x0
     a0e:	02 4e 34             	add    cl,BYTE PTR [bp+0x34]
     a11:	18 03                	sbb    BYTE PTR [bp+di],al
     a13:	14 00                	adc    al,0x0
     a15:	14 54                	adc    al,0x54
     a17:	61                   	popa
     a18:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a1b:	61                   	popa
     a1c:	75 44                	jne    0xa62
     a1e:	65 54                	gs push sp
     a20:	72 65                	jb     0xa87
     a22:	73 6f                	jae    0xa93
     a24:	72 65                	jb     0xa8b
     a26:	72 69                	jb     0xa91
     a28:	65 31 1c             	xor    WORD PTR gs:[si],bx
     a2b:	03 14                	add    dx,WORD PTR [si]
     a2d:	00 15                	add    BYTE PTR [di],dl
     a2f:	54                   	push   sp
     a30:	61                   	popa
     a31:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a34:	61                   	popa
     a35:	75 44                	jne    0xa7b
     a37:	65 46                	gs inc si
     a39:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     a3e:	65 6d                	gs ins WORD PTR es:[di],dx
     a40:	65 6e                	outs   dx,BYTE PTR gs:[si]
     a42:	74 31                	je     0xa75
     a44:	20 03                	and    BYTE PTR [bp+di],al
     a46:	14 00                	adc    al,0x0
     a48:	06                   	push   es
     a49:	42                   	inc    dx
     a4a:	69 6c 61 6e 31       	imul   bp,WORD PTR [si+0x61],0x316e
     a4f:	24 03                	and    al,0x3
     a51:	14 00                	adc    al,0x0
     a53:	12 43 6f             	adc    al,BYTE PTR [bp+di+0x6f]
     a56:	6d                   	ins    WORD PTR es:[di],dx
     a57:	70 74                	jo     0xacd
     a59:	65 44                	gs inc sp
     a5b:	65 52                	gs push dx
     a5d:	65 73 75             	gs jae 0xad5
     a60:	6c                   	ins    BYTE PTR es:[di],dx
     a61:	74 61                	je     0xac4
     a63:	74 73                	je     0xad8
     a65:	31 28                	xor    WORD PTR [bx+si],bp
     a67:	03 14                	add    dx,WORD PTR [si]
     a69:	00 0a                	add    BYTE PTR [bp+si],cl
     a6b:	53                   	push   bx
     a6c:	69 74 75 61 74       	imul   si,WORD PTR [si+0x75],0x7461
     a71:	69 6f 6e 31 2c       	imul   bp,WORD PTR [bx+0x6e],0x2c31
     a76:	03 14                	add    dx,WORD PTR [si]
     a78:	00 05                	add    BYTE PTR [di],al
     a7a:	4e                   	dec    si
     a7b:	31 30                	xor    WORD PTR [bx+si],si
     a7d:	30 31                	xor    BYTE PTR [bx+di],dh
     a7f:	30 03                	xor    BYTE PTR [bp+di],al
     a81:	14 00                	adc    al,0x0
     a83:	05 4e 31             	add    ax,0x314e
     a86:	35 30 31             	xor    ax,0x3130
     a89:	34 03                	xor    al,0x3
     a8b:	14 00                	adc    al,0x0
     a8d:	05 4e 32             	add    ax,0x324e
     a90:	30 30                	xor    BYTE PTR [bx+si],dh
     a92:	31 38                	xor    WORD PTR [bx+si],di
     a94:	03 14                	add    dx,WORD PTR [si]
     a96:	00 04                	add    BYTE PTR [si],al
     a98:	4e                   	dec    si
     a99:	37                   	aaa
     a9a:	35 31 3c             	xor    ax,0x3c31
     a9d:	03 14                	add    dx,WORD PTR [si]
     a9f:	00 04                	add    BYTE PTR [si],al
     aa1:	4e                   	dec    si
     aa2:	35 30 31             	xor    ax,0x3130
     aa5:	40                   	inc    ax
     aa6:	03 14                	add    dx,WORD PTR [si]
     aa8:	00 02                	add    BYTE PTR [bp+si],al
     aaa:	4e                   	dec    si
     aab:	35 44 03             	xor    ax,0x344
     aae:	14 00                	adc    al,0x0
     ab0:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
     ab3:	70 72                	jo     0xb27
     ab5:	65 73 73             	gs jae 0xb2b
     ab8:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     abd:	70 69                	jo     0xb28
     abf:	64 65 31 48 03       	fs xor WORD PTR gs:[bx+si+0x3],cx
     ac4:	14 00                	adc    al,0x0
     ac6:	02 4e 36             	add    cl,BYTE PTR [bp+0x36]
     ac9:	4c                   	dec    sp
     aca:	03 14                	add    dx,WORD PTR [si]
     acc:	00 05                	add    BYTE PTR [di],al
     ace:	4e                   	dec    si
     acf:	31 32                	xor    WORD PTR [bp+si],si
     ad1:	35 31 50             	xor    ax,0x5031
     ad4:	03 14                	add    dx,WORD PTR [si]
     ad6:	00 08                	add    BYTE PTR [bx+si],cl
     ad8:	50                   	push   ax
     ad9:	65 72 69             	gs jb  0xb45
     adc:	6f                   	outs   dx,WORD PTR ds:[si]
     add:	64 65 32 54 03       	fs xor dl,BYTE PTR gs:[si+0x3]
     ae2:	14 00                	adc    al,0x0
     ae4:	06                   	push   es
     ae5:	61                   	popa
     ae6:	75 74                	jne    0xb5c
     ae8:	72 65                	jb     0xb4f
     aea:	31 58 03             	xor    WORD PTR [bx+si+0x3],bx
     aed:	14 00                	adc    al,0x0
     aef:	04 4e                	add    al,0x4e
     af1:	32 30                	xor    dh,BYTE PTR [bx+si]
     af3:	31 5c 03             	xor    WORD PTR [si+0x3],bx
     af6:	14 00                	adc    al,0x0
     af8:	04 4e                	add    al,0x4e
     afa:	31 39                	xor    WORD PTR [bx+di],di
     afc:	31 60 03             	xor    WORD PTR [bx+si+0x3],sp
     aff:	14 00                	adc    al,0x0
     b01:	04 4e                	add    al,0x4e
     b03:	31 38                	xor    WORD PTR [bx+si],di
     b05:	31 64 03             	xor    WORD PTR [si+0x3],sp
     b08:	14 00                	adc    al,0x0
     b0a:	04 4e                	add    al,0x4e
     b0c:	31 37                	xor    WORD PTR [bx],si
     b0e:	31 68 03             	xor    WORD PTR [bx+si+0x3],bp
     b11:	14 00                	adc    al,0x0
     b13:	04 4e                	add    al,0x4e
     b15:	31 36 31 6c          	xor    WORD PTR ds:0x6c31,si
     b19:	03 14                	add    dx,WORD PTR [si]
     b1b:	00 04                	add    BYTE PTR [si],al
     b1d:	4e                   	dec    si
     b1e:	31 35                	xor    WORD PTR [di],si
     b20:	31 70 03             	xor    WORD PTR [bx+si+0x3],si
     b23:	14 00                	adc    al,0x0
     b25:	04 4e                	add    al,0x4e
     b27:	31 34                	xor    WORD PTR [si],si
     b29:	31 74 03             	xor    WORD PTR [si+0x3],si
     b2c:	14 00                	adc    al,0x0
     b2e:	04 4e                	add    al,0x4e
     b30:	31 33                	xor    WORD PTR [bp+di],si
     b32:	31 78 03             	xor    WORD PTR [bx+si+0x3],di
     b35:	14 00                	adc    al,0x0
     b37:	04 4e                	add    al,0x4e
     b39:	31 32                	xor    WORD PTR [bp+si],si
     b3b:	31 7c 03             	xor    WORD PTR [si+0x3],di
     b3e:	14 00                	adc    al,0x0
     b40:	04 4e                	add    al,0x4e
     b42:	31 31                	xor    WORD PTR [bx+di],si
     b44:	31 80 03 14          	xor    WORD PTR [bx+si+0x1403],ax
     b48:	00 04                	add    BYTE PTR [si],al
     b4a:	4e                   	dec    si
     b4b:	31 30                	xor    WORD PTR [bx+si],si
     b4d:	31 84 03 14          	xor    WORD PTR [si+0x1403],ax
     b51:	00 03                	add    BYTE PTR [bp+di],al
     b53:	4e                   	dec    si
     b54:	39 31                	cmp    WORD PTR [bx+di],si
     b56:	88 03                	mov    BYTE PTR [bp+di],al
     b58:	14 00                	adc    al,0x0
     b5a:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
     b5d:	32 8c 03 14          	xor    cl,BYTE PTR [si+0x1403]
     b61:	00 03                	add    BYTE PTR [bp+di],al
     b63:	4e                   	dec    si
     b64:	37                   	aaa
     b65:	32 90 03 14          	xor    dl,BYTE PTR [bx+si+0x1403]
     b69:	00 03                	add    BYTE PTR [bp+di],al
     b6b:	4e                   	dec    si
     b6c:	36 32 94 03 14       	xor    dl,BYTE PTR ss:[si+0x1403]
     b71:	00 03                	add    BYTE PTR [bp+di],al
     b73:	4e                   	dec    si
     b74:	35 32 98             	xor    ax,0x9832
     b77:	03 14                	add    dx,WORD PTR [si]
     b79:	00 03                	add    BYTE PTR [bp+di],al
     b7b:	4e                   	dec    si
     b7c:	34 32                	xor    al,0x32
     b7e:	9c                   	pushf
     b7f:	03 14                	add    dx,WORD PTR [si]
     b81:	00 03                	add    BYTE PTR [bp+di],al
     b83:	4e                   	dec    si
     b84:	33 32                	xor    si,WORD PTR [bp+si]
     b86:	a0 03 14             	mov    al,ds:0x1403
     b89:	00 03                	add    BYTE PTR [bp+di],al
     b8b:	4e                   	dec    si
     b8c:	32 32                	xor    dh,BYTE PTR [bp+si]
     b8e:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     b8f:	03 14                	add    dx,WORD PTR [si]
     b91:	00 03                	add    BYTE PTR [bp+di],al
     b93:	4e                   	dec    si
     b94:	31 32                	xor    WORD PTR [bp+si],si
     b96:	a8 03                	test   al,0x3
     b98:	14 00                	adc    al,0x0
     b9a:	04 53                	add    al,0x53
     b9c:	49                   	dec    cx
     b9d:	47                   	inc    di
     b9e:	31 ac 03 00          	xor    WORD PTR [si+0x3],bp
     ba2:	00 08                	add    BYTE PTR [bx+si],cl
     ba4:	50                   	push   ax
     ba5:	61                   	popa
     ba6:	6e                   	outs   dx,BYTE PTR ds:[si]
     ba7:	65 6c                	gs ins BYTE PTR es:[di],dx
     ba9:	31 30                	xor    WORD PTR [bx+si],si
     bab:	30 b0 03 00          	xor    BYTE PTR [bx+si+0x3],dh
     baf:	00 08                	add    BYTE PTR [bx+si],cl
     bb1:	50                   	push   ax
     bb2:	61                   	popa
     bb3:	6e                   	outs   dx,BYTE PTR ds:[si]
     bb4:	65 6c                	gs ins BYTE PTR es:[di],dx
     bb6:	32 30                	xor    dh,BYTE PTR [bx+si]
     bb8:	30 b4 03 00          	xor    BYTE PTR [si+0x3],dh
     bbc:	00 08                	add    BYTE PTR [bx+si],cl
     bbe:	50                   	push   ax
     bbf:	61                   	popa
     bc0:	6e                   	outs   dx,BYTE PTR ds:[si]
     bc1:	65 6c                	gs ins BYTE PTR es:[di],dx
     bc3:	33 30                	xor    si,WORD PTR [bx+si]
     bc5:	30 b8 03 00          	xor    BYTE PTR [bx+si+0x3],bh
     bc9:	00 07                	add    BYTE PTR [bx],al
     bcb:	50                   	push   ax
     bcc:	61                   	popa
     bcd:	6e                   	outs   dx,BYTE PTR ds:[si]
     bce:	65 6c                	gs ins BYTE PTR es:[di],dx
     bd0:	33 34                	xor    si,WORD PTR [si]
     bd2:	bc 03 00             	mov    sp,0x3
     bd5:	00 08                	add    BYTE PTR [bx+si],cl
     bd7:	50                   	push   ax
     bd8:	61                   	popa
     bd9:	6e                   	outs   dx,BYTE PTR ds:[si]
     bda:	65 6c                	gs ins BYTE PTR es:[di],dx
     bdc:	31 30                	xor    WORD PTR [bx+si],si
     bde:	31 c0                	xor    ax,ax
     be0:	03 00                	add    ax,WORD PTR [bx+si]
     be2:	00 08                	add    BYTE PTR [bx+si],cl
     be4:	50                   	push   ax
     be5:	61                   	popa
     be6:	6e                   	outs   dx,BYTE PTR ds:[si]
     be7:	65 6c                	gs ins BYTE PTR es:[di],dx
     be9:	31 30                	xor    WORD PTR [bx+si],si
     beb:	32 c4                	xor    al,ah
     bed:	03 00                	add    ax,WORD PTR [bx+si]
     bef:	00 08                	add    BYTE PTR [bx+si],cl
     bf1:	50                   	push   ax
     bf2:	61                   	popa
     bf3:	6e                   	outs   dx,BYTE PTR ds:[si]
     bf4:	65 6c                	gs ins BYTE PTR es:[di],dx
     bf6:	31 30                	xor    WORD PTR [bx+si],si
     bf8:	33 c8                	xor    cx,ax
     bfa:	03 00                	add    ax,WORD PTR [bx+si]
     bfc:	00 08                	add    BYTE PTR [bx+si],cl
     bfe:	50                   	push   ax
     bff:	61                   	popa
     c00:	6e                   	outs   dx,BYTE PTR ds:[si]
     c01:	65 6c                	gs ins BYTE PTR es:[di],dx
     c03:	31 30                	xor    WORD PTR [bx+si],si
     c05:	34 cc                	xor    al,0xcc
     c07:	03 00                	add    ax,WORD PTR [bx+si]
     c09:	00 08                	add    BYTE PTR [bx+si],cl
     c0b:	50                   	push   ax
     c0c:	61                   	popa
     c0d:	6e                   	outs   dx,BYTE PTR ds:[si]
     c0e:	65 6c                	gs ins BYTE PTR es:[di],dx
     c10:	31 30                	xor    WORD PTR [bx+si],si
     c12:	35 d0 03             	xor    ax,0x3d0
     c15:	00 00                	add    BYTE PTR [bx+si],al
     c17:	07                   	pop    es
     c18:	50                   	push   ax
     c19:	61                   	popa
     c1a:	6e                   	outs   dx,BYTE PTR ds:[si]
     c1b:	65 6c                	gs ins BYTE PTR es:[di],dx
     c1d:	34 35                	xor    al,0x35
     c1f:	d4 03                	aam    0x3
     c21:	2c 00                	sub    al,0x0
     c23:	06                   	push   es
     c24:	53                   	push   bx
     c25:	68 61 70             	push   0x7061
     c28:	65 31 d8             	gs xor ax,bx
     c2b:	03 30                	add    si,WORD PTR [bx+si]
     c2d:	00 09                	add    BYTE PTR [bx+di],cl
     c2f:	44                   	inc    sp
     c30:	42                   	inc    dx
     c31:	45                   	inc    bp
     c32:	64 69 74 31 30 35    	imul   si,WORD PTR fs:[si+0x31],0x3530
     c38:	dc 03                	fadd   QWORD PTR [bp+di]
     c3a:	00 00                	add    BYTE PTR [bx+si],al
     c3c:	07                   	pop    es
     c3d:	50                   	push   ax
     c3e:	61                   	popa
     c3f:	6e                   	outs   dx,BYTE PTR ds:[si]
     c40:	65 6c                	gs ins BYTE PTR es:[di],dx
     c42:	34 36                	xor    al,0x36
     c44:	e0 03                	loopne 0xc49
     c46:	00 00                	add    BYTE PTR [bx+si],al
     c48:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     c4b:	6e                   	outs   dx,BYTE PTR ds:[si]
     c4c:	65 6c                	gs ins BYTE PTR es:[di],dx
     c4e:	32 30                	xor    dh,BYTE PTR [bx+si]
     c50:	32 e4                	xor    ah,ah
     c52:	03 00                	add    ax,WORD PTR [bx+si]
     c54:	00 08                	add    BYTE PTR [bx+si],cl
     c56:	50                   	push   ax
     c57:	61                   	popa
     c58:	6e                   	outs   dx,BYTE PTR ds:[si]
     c59:	65 6c                	gs ins BYTE PTR es:[di],dx
     c5b:	32 30                	xor    dh,BYTE PTR [bx+si]
     c5d:	33 e8                	xor    bp,ax
     c5f:	03 00                	add    ax,WORD PTR [bx+si]
     c61:	00 08                	add    BYTE PTR [bx+si],cl
     c63:	50                   	push   ax
     c64:	61                   	popa
     c65:	6e                   	outs   dx,BYTE PTR ds:[si]
     c66:	65 6c                	gs ins BYTE PTR es:[di],dx
     c68:	32 30                	xor    dh,BYTE PTR [bx+si]
     c6a:	34 ec                	xor    al,0xec
     c6c:	03 00                	add    ax,WORD PTR [bx+si]
     c6e:	00 08                	add    BYTE PTR [bx+si],cl
     c70:	50                   	push   ax
     c71:	61                   	popa
     c72:	6e                   	outs   dx,BYTE PTR ds:[si]
     c73:	65 6c                	gs ins BYTE PTR es:[di],dx
     c75:	32 30                	xor    dh,BYTE PTR [bx+si]
     c77:	35 f0 03             	xor    ax,0x3f0
     c7a:	00 00                	add    BYTE PTR [bx+si],al
     c7c:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     c7f:	6e                   	outs   dx,BYTE PTR ds:[si]
     c80:	65 6c                	gs ins BYTE PTR es:[di],dx
     c82:	32 30                	xor    dh,BYTE PTR [bx+si]
     c84:	36 f4                	ss hlt
     c86:	03 00                	add    ax,WORD PTR [bx+si]
     c88:	00 08                	add    BYTE PTR [bx+si],cl
     c8a:	50                   	push   ax
     c8b:	61                   	popa
     c8c:	6e                   	outs   dx,BYTE PTR ds:[si]
     c8d:	65 6c                	gs ins BYTE PTR es:[di],dx
     c8f:	32 30                	xor    dh,BYTE PTR [bx+si]
     c91:	37                   	aaa
     c92:	f8                   	clc
     c93:	03 00                	add    ax,WORD PTR [bx+si]
     c95:	00 07                	add    BYTE PTR [bx],al
     c97:	50                   	push   ax
     c98:	61                   	popa
     c99:	6e                   	outs   dx,BYTE PTR ds:[si]
     c9a:	65 6c                	gs ins BYTE PTR es:[di],dx
     c9c:	34 37                	xor    al,0x37
     c9e:	fc                   	cld
     c9f:	03 2c                	add    bp,WORD PTR [si]
     ca1:	00 06 53 68          	add    BYTE PTR ds:0x6853,al
     ca5:	61                   	popa
     ca6:	70 65                	jo     0xd0d
     ca8:	33 00                	xor    ax,WORD PTR [bx+si]
     caa:	04 30                	add    al,0x30
     cac:	00 09                	add    BYTE PTR [bx+di],cl
     cae:	44                   	inc    sp
     caf:	42                   	inc    dx
     cb0:	45                   	inc    bp
     cb1:	64 69 74 32 31 30    	imul   si,WORD PTR fs:[si+0x32],0x3031
     cb7:	04 04                	add    al,0x4
     cb9:	00 00                	add    BYTE PTR [bx+si],al
     cbb:	07                   	pop    es
     cbc:	50                   	push   ax
     cbd:	61                   	popa
     cbe:	6e                   	outs   dx,BYTE PTR ds:[si]
     cbf:	65 6c                	gs ins BYTE PTR es:[di],dx
     cc1:	34 38                	xor    al,0x38
     cc3:	08 04                	or     BYTE PTR [si],al
     cc5:	00 00                	add    BYTE PTR [bx+si],al
     cc7:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
     cca:	6e                   	outs   dx,BYTE PTR ds:[si]
     ccb:	65 6c                	gs ins BYTE PTR es:[di],dx
     ccd:	33 30                	xor    si,WORD PTR [bx+si]
     ccf:	31 0c                	xor    WORD PTR [si],cx
     cd1:	04 00                	add    al,0x0
     cd3:	00 08                	add    BYTE PTR [bx+si],cl
     cd5:	50                   	push   ax
     cd6:	61                   	popa
     cd7:	6e                   	outs   dx,BYTE PTR ds:[si]
     cd8:	65 6c                	gs ins BYTE PTR es:[di],dx
     cda:	33 31                	xor    si,WORD PTR [bx+di]
     cdc:	30 10                	xor    BYTE PTR [bx+si],dl
     cde:	04 00                	add    al,0x0
     ce0:	00 08                	add    BYTE PTR [bx+si],cl
     ce2:	50                   	push   ax
     ce3:	61                   	popa
     ce4:	6e                   	outs   dx,BYTE PTR ds:[si]
     ce5:	65 6c                	gs ins BYTE PTR es:[di],dx
     ce7:	33 31                	xor    si,WORD PTR [bx+di]
     ce9:	31 14                	xor    WORD PTR [si],dx
     ceb:	04 00                	add    al,0x0
     ced:	00 08                	add    BYTE PTR [bx+si],cl
     cef:	50                   	push   ax
     cf0:	61                   	popa
     cf1:	6e                   	outs   dx,BYTE PTR ds:[si]
     cf2:	65 6c                	gs ins BYTE PTR es:[di],dx
     cf4:	33 31                	xor    si,WORD PTR [bx+di]
     cf6:	32 18                	xor    bl,BYTE PTR [bx+si]
     cf8:	04 00                	add    al,0x0
     cfa:	00 08                	add    BYTE PTR [bx+si],cl
     cfc:	50                   	push   ax
     cfd:	61                   	popa
     cfe:	6e                   	outs   dx,BYTE PTR ds:[si]
     cff:	65 6c                	gs ins BYTE PTR es:[di],dx
     d01:	33 31                	xor    si,WORD PTR [bx+di]
     d03:	35 1c 04             	xor    ax,0x41c
     d06:	00 00                	add    BYTE PTR [bx+si],al
     d08:	07                   	pop    es
     d09:	50                   	push   ax
     d0a:	61                   	popa
     d0b:	6e                   	outs   dx,BYTE PTR ds:[si]
     d0c:	65 6c                	gs ins BYTE PTR es:[di],dx
     d0e:	34 39                	xor    al,0x39
     d10:	20 04                	and    BYTE PTR [si],al
     d12:	30 00                	xor    BYTE PTR [bx+si],al
     d14:	09 44 42             	or     WORD PTR [si+0x42],ax
     d17:	45                   	inc    bp
     d18:	64 69 74 33 30 31    	imul   si,WORD PTR fs:[si+0x33],0x3130
     d1e:	24 04                	and    al,0x4
     d20:	2c 00                	sub    al,0x0
     d22:	06                   	push   es
     d23:	53                   	push   bx
     d24:	68 61 70             	push   0x7061
     d27:	65 35 28 04          	gs xor ax,0x428
     d2b:	30 00                	xor    BYTE PTR [bx+si],al
     d2d:	09 44 42             	or     WORD PTR [si+0x42],ax
     d30:	45                   	inc    bp
     d31:	64 69 74 33 31 30    	imul   si,WORD PTR fs:[si+0x33],0x3031
     d37:	2c 04                	sub    al,0x4
     d39:	30 00                	xor    BYTE PTR [bx+si],al
     d3b:	09 44 42             	or     WORD PTR [si+0x42],ax
     d3e:	45                   	inc    bp
     d3f:	64 69 74 33 31 32    	imul   si,WORD PTR fs:[si+0x33],0x3231
     d45:	30 04                	xor    BYTE PTR [si],al
     d47:	30 00                	xor    BYTE PTR [bx+si],al
     d49:	09 44 42             	or     WORD PTR [si+0x42],ax
     d4c:	45                   	inc    bp
     d4d:	64 69 74 33 31 35    	imul   si,WORD PTR fs:[si+0x33],0x3531
     d53:	34 04                	xor    al,0x4
     d55:	2c 00                	sub    al,0x0
     d57:	06                   	push   es
     d58:	53                   	push   bx
     d59:	68 61 70             	push   0x7061
     d5c:	65 37                	gs aaa
     d5e:	38 04                	cmp    BYTE PTR [si],al
     d60:	2c 00                	sub    al,0x0
     d62:	06                   	push   es
     d63:	53                   	push   bx
     d64:	68 61 70             	push   0x7061
     d67:	65 38 3c             	cmp    BYTE PTR gs:[si],bh
     d6a:	04 2c                	add    al,0x2c
     d6c:	00 07                	add    BYTE PTR [bx],al
     d6e:	53                   	push   bx
     d6f:	68 61 70             	push   0x7061
     d72:	65 31 30             	xor    WORD PTR gs:[bx+si],si
     d75:	40                   	inc    ax
     d76:	04 00                	add    al,0x0
     d78:	00 08                	add    BYTE PTR [bx+si],cl
     d7a:	50                   	push   ax
     d7b:	61                   	popa
     d7c:	6e                   	outs   dx,BYTE PTR ds:[si]
     d7d:	65 6c                	gs ins BYTE PTR es:[di],dx
     d7f:	33 32                	xor    si,WORD PTR [bp+si]
     d81:	30 44 04             	xor    BYTE PTR [si+0x4],al
     d84:	30 00                	xor    BYTE PTR [bx+si],al
     d86:	09 44 42             	or     WORD PTR [si+0x42],ax
     d89:	45                   	inc    bp
     d8a:	64 69 74 33 32 30    	imul   si,WORD PTR fs:[si+0x33],0x3032
     d90:	48                   	dec    ax
     d91:	04 0c                	add    al,0xc
     d93:	00 19                	add    BYTE PTR [bx+di],bl
     d95:	54                   	push   sp
     d96:	61                   	popa
     d97:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d9a:	45                   	inc    bp
     d9b:	52                   	push   dx
     d9c:	47                   	inc    di
     d9d:	43                   	inc    bx
     d9e:	6f                   	outs   dx,WORD PTR ds:[si]
     d9f:	6e                   	outs   dx,BYTE PTR ds:[si]
     da0:	73 6f                	jae    0xe11
     da2:	6d                   	ins    WORD PTR es:[di],dx
     da3:	6d                   	ins    WORD PTR es:[di],dx
     da4:	61                   	popa
     da5:	74 69                	je     0xe10
     da7:	6f                   	outs   dx,WORD PTR ds:[si]
     da8:	6e                   	outs   dx,BYTE PTR ds:[si]
     da9:	54                   	push   sp
     daa:	69 65 72 73 4c       	imul   sp,WORD PTR [di+0x72],0x4c73
     daf:	04 0c                	add    al,0xc
     db1:	00 15                	add    BYTE PTR [di],dl
     db3:	54                   	push   sp
     db4:	61                   	popa
     db5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     db8:	45                   	inc    bp
     db9:	52                   	push   dx
     dba:	47                   	inc    di
     dbb:	56                   	push   si
     dbc:	61                   	popa
     dbd:	6c                   	ins    BYTE PTR es:[di],dx
     dbe:	65 75 72             	gs jne 0xe33
     dc1:	41                   	inc    cx
     dc2:	6a 6f                	push   0x6f
     dc4:	75 74                	jne    0xe3a
     dc6:	65 65 50             	gs gs push ax
     dc9:	04 20                	add    al,0x20
     dcb:	00 1c                	add    BYTE PTR [si],bl
     dcd:	54                   	push   sp
     dce:	61                   	popa
     dcf:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     dd2:	45                   	inc    bp
     dd3:	52                   	push   dx
     dd4:	47                   	inc    di
     dd5:	43                   	inc    bx
     dd6:	6f                   	outs   dx,WORD PTR ds:[si]
     dd7:	75 74                	jne    0xe4d
     dd9:	73 46                	jae    0xe21
     ddb:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
     de0:	72 6f                	jb     0xe51
     de2:	64 75 63             	fs jne 0xe48
     de5:	74 69                	je     0xe50
     de7:	6f                   	outs   dx,WORD PTR ds:[si]
     de8:	6e                   	outs   dx,BYTE PTR ds:[si]
     de9:	54                   	push   sp
     dea:	04 20                	add    al,0x20
     dec:	00 13                	add    BYTE PTR [bp+di],dl
     dee:	54                   	push   sp
     def:	61                   	popa
     df0:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     df3:	45                   	inc    bp
     df4:	52                   	push   dx
     df5:	47                   	inc    di
     df6:	52                   	push   dx
     df7:	65 70 61             	gs jo  0xe5b
     dfa:	72 61                	jb     0xe5d
     dfc:	74 69                	je     0xe67
     dfe:	6f                   	outs   dx,WORD PTR ds:[si]
     dff:	6e                   	outs   dx,BYTE PTR ds:[si]
     e00:	73 58                	jae    0xe5a
     e02:	04 20                	add    al,0x20
     e04:	00 19                	add    BYTE PTR [bx+di],bl
     e06:	54                   	push   sp
     e07:	61                   	popa
     e08:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e0b:	45                   	inc    bp
     e0c:	52                   	push   dx
     e0d:	47                   	inc    di
     e0e:	45                   	inc    bp
     e0f:	6e                   	outs   dx,BYTE PTR ds:[si]
     e10:	74 72                	je     0xe84
     e12:	65 74 69             	gs je  0xe7e
     e15:	65 6e                	outs   dx,BYTE PTR gs:[si]
     e17:	4d                   	dec    bp
     e18:	61                   	popa
     e19:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
     e1c:	6e                   	outs   dx,BYTE PTR ds:[si]
     e1d:	65 73 5c             	gs jae 0xe7c
     e20:	04 0c                	add    al,0xc
     e22:	00 13                	add    BYTE PTR [bp+di],dl
     e24:	54                   	push   sp
     e25:	61                   	popa
     e26:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e29:	45                   	inc    bp
     e2a:	52                   	push   dx
     e2b:	47                   	inc    di
     e2c:	53                   	push   bx
     e2d:	75 62                	jne    0xe91
     e2f:	76 65                	jbe    0xe96
     e31:	6e                   	outs   dx,BYTE PTR ds:[si]
     e32:	74 69                	je     0xe9d
     e34:	6f                   	outs   dx,WORD PTR ds:[si]
     e35:	6e                   	outs   dx,BYTE PTR ds:[si]
     e36:	73 60                	jae    0xe98
     e38:	04 0c                	add    al,0xc
     e3a:	00 19                	add    BYTE PTR [bx+di],bl
     e3c:	54                   	push   sp
     e3d:	61                   	popa
     e3e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e41:	45                   	inc    bp
     e42:	52                   	push   dx
     e43:	47                   	inc    di
     e44:	4d                   	dec    bp
     e45:	61                   	popa
     e46:	69 6e 30 65 75       	imul   bp,WORD PTR [bp+0x30],0x7565
     e4b:	76 72                	jbe    0xebf
     e4d:	65 44                	gs inc sp
     e4f:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
     e54:	65 64 04 20          	gs fs add al,0x20
     e58:	00 14                	add    BYTE PTR [si],dl
     e5a:	54                   	push   sp
     e5b:	61                   	popa
     e5c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e5f:	45                   	inc    bp
     e60:	52                   	push   dx
     e61:	47                   	inc    di
     e62:	54                   	push   sp
     e63:	56                   	push   si
     e64:	41                   	inc    cx
     e65:	43                   	inc    bx
     e66:	6f                   	outs   dx,WORD PTR ds:[si]
     e67:	6c                   	ins    BYTE PTR es:[di],dx
     e68:	6c                   	ins    BYTE PTR es:[di],dx
     e69:	65 63 74 65          	arpl   WORD PTR gs:[si+0x65],si
     e6d:	65 68 04 20          	gs push 0x2004
     e71:	00 15                	add    BYTE PTR [di],dl
     e73:	54                   	push   sp
     e74:	61                   	popa
     e75:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e78:	45                   	inc    bp
     e79:	52                   	push   dx
     e7a:	47                   	inc    di
     e7b:	54                   	push   sp
     e7c:	56                   	push   si
     e7d:	41                   	inc    cx
     e7e:	44                   	inc    sp
     e7f:	65 64 75 63          	gs fs jne 0xee6
     e83:	74 69                	je     0xeee
     e85:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e88:	6c                   	ins    BYTE PTR es:[di],dx
     e89:	04 20                	add    al,0x20
     e8b:	00 19                	add    BYTE PTR [bx+di],bl
     e8d:	54                   	push   sp
     e8e:	61                   	popa
     e8f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     e92:	45                   	inc    bp
     e93:	52                   	push   dx
     e94:	47                   	inc    di
     e95:	49                   	dec    cx
     e96:	6e                   	outs   dx,BYTE PTR ds:[si]
     e97:	64 69 63 65 53 61    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6153
     e9d:	74 69                	je     0xf08
     e9f:	73 50                	jae    0xef1
     ea1:	65 72 73             	gs jb  0xf17
     ea4:	6f                   	outs   dx,WORD PTR ds:[si]
     ea5:	6e                   	outs   dx,BYTE PTR ds:[si]
     ea6:	70 04                	jo     0xeac
     ea8:	0c 00                	or     al,0x0
     eaa:	1c 54                	sbb    al,0x54
     eac:	61                   	popa
     ead:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     eb0:	45                   	inc    bp
     eb1:	52                   	push   dx
     eb2:	47                   	inc    di
     eb3:	52                   	push   dx
     eb4:	65 6d                	gs ins WORD PTR es:[di],dx
     eb6:	75 6e                	jne    0xf26
     eb8:	65 72 61             	gs jb  0xf1c
     ebb:	74 69                	je     0xf26
     ebd:	6f                   	outs   dx,WORD PTR ds:[si]
     ebe:	6e                   	outs   dx,BYTE PTR ds:[si]
     ebf:	56                   	push   si
     ec0:	65 6e                	outs   dx,BYTE PTR gs:[si]
     ec2:	64 65 75 72          	fs gs jne 0xf38
     ec6:	73 74                	jae    0xf3c
     ec8:	04 0c                	add    al,0xc
     eca:	00 1f                	add    BYTE PTR [bx],bl
     ecc:	54                   	push   sp
     ecd:	61                   	popa
     ece:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ed1:	45                   	inc    bp
     ed2:	52                   	push   dx
     ed3:	47                   	inc    di
     ed4:	45                   	inc    bp
     ed5:	78 65                	js     0xf3c
     ed7:	64 65 6e             	fs outs dx,BYTE PTR gs:[si]
     eda:	74 42                	je     0xf1e
     edc:	72 75                	jb     0xf53
     ede:	74 45                	je     0xf25
     ee0:	78 70                	js     0xf52
     ee2:	6c                   	ins    BYTE PTR es:[di],dx
     ee3:	6f                   	outs   dx,WORD PTR ds:[si]
     ee4:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
     ee9:	6f                   	outs   dx,WORD PTR ds:[si]
     eea:	6e                   	outs   dx,BYTE PTR ds:[si]
     eeb:	78 04                	js     0xef1
     eed:	0c 00                	or     al,0x0
     eef:	1e                   	push   ds
     ef0:	54                   	push   sp
     ef1:	61                   	popa
     ef2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ef5:	45                   	inc    bp
     ef6:	52                   	push   dx
     ef7:	47                   	inc    di
     ef8:	44                   	inc    sp
     ef9:	6f                   	outs   dx,WORD PTR ds:[si]
     efa:	74 61                	je     0xf5d
     efc:	74 69                	je     0xf67
     efe:	6f                   	outs   dx,WORD PTR ds:[si]
     eff:	6e                   	outs   dx,BYTE PTR ds:[si]
     f00:	73 41                	jae    0xf43
     f02:	6d                   	ins    WORD PTR es:[di],dx
     f03:	6f                   	outs   dx,WORD PTR ds:[si]
     f04:	72 74                	jb     0xf7a
     f06:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
     f0b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     f0d:	74 7c                	je     0xf8b
     f0f:	04 0c                	add    al,0xc
     f11:	00 1c                	add    BYTE PTR [si],bl
     f13:	54                   	push   sp
     f14:	61                   	popa
     f15:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f18:	45                   	inc    bp
     f19:	52                   	push   dx
     f1a:	47                   	inc    di
     f1b:	52                   	push   dx
     f1c:	65 73 75             	gs jae 0xf94
     f1f:	6c                   	ins    BYTE PTR es:[di],dx
     f20:	74 61                	je     0xf83
     f22:	74 45                	je     0xf69
     f24:	78 70                	js     0xf96
     f26:	6c                   	ins    BYTE PTR es:[di],dx
     f27:	6f                   	outs   dx,WORD PTR ds:[si]
     f28:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
     f2d:	6f                   	outs   dx,WORD PTR ds:[si]
     f2e:	6e                   	outs   dx,BYTE PTR ds:[si]
     f2f:	80 04 0c             	add    BYTE PTR [si],0xc
     f32:	00 1a                	add    BYTE PTR [bp+si],bl
     f34:	54                   	push   sp
     f35:	61                   	popa
     f36:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f39:	45                   	inc    bp
     f3a:	52                   	push   dx
     f3b:	47                   	inc    di
     f3c:	50                   	push   ax
     f3d:	72 6f                	jb     0xfae
     f3f:	64 75 69             	fs jne 0xfab
     f42:	74 73                	je     0xfb7
     f44:	46                   	inc    si
     f45:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     f4a:	69 65 72 73 84       	imul   sp,WORD PTR [di+0x72],0x8473
     f4f:	04 0c                	add    al,0xc
     f51:	00 1a                	add    BYTE PTR [bp+si],bl
     f53:	54                   	push   sp
     f54:	61                   	popa
     f55:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f58:	45                   	inc    bp
     f59:	52                   	push   dx
     f5a:	47                   	inc    di
     f5b:	43                   	inc    bx
     f5c:	68 61 72             	push   0x7261
     f5f:	67 65 73 46          	addr32 gs jae 0xfa9
     f63:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
     f68:	69 65 72 65 73       	imul   sp,WORD PTR [di+0x72],0x7365
     f6d:	88 04                	mov    BYTE PTR [si],al
     f6f:	0c 00                	or     al,0x0
     f71:	17                   	pop    ss
     f72:	54                   	push   sp
     f73:	61                   	popa
     f74:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f77:	45                   	inc    bp
     f78:	52                   	push   dx
     f79:	47                   	inc    di
     f7a:	52                   	push   dx
     f7b:	65 73 75             	gs jae 0xff3
     f7e:	6c                   	ins    BYTE PTR es:[di],dx
     f7f:	74 61                	je     0xfe2
     f81:	74 43                	je     0xfc6
     f83:	6f                   	outs   dx,WORD PTR ds:[si]
     f84:	75 72                	jne    0xff8
     f86:	61                   	popa
     f87:	6e                   	outs   dx,BYTE PTR ds:[si]
     f88:	74 8c                	je     0xf16
     f8a:	04 0c                	add    al,0xc
     f8c:	00 1d                	add    BYTE PTR [di],bl
     f8e:	54                   	push   sp
     f8f:	61                   	popa
     f90:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     f93:	45                   	inc    bp
     f94:	52                   	push   dx
     f95:	47                   	inc    di
     f96:	50                   	push   ax
     f97:	72 6f                	jb     0x1008
     f99:	64 75 69             	fs jne 0x1005
     f9c:	74 73                	je     0x1011
     f9e:	45                   	inc    bp
     f9f:	78 63                	js     0x1004
     fa1:	65 70 74             	gs jo  0x1018
     fa4:	69 6f 6e 6e 65       	imul   bp,WORD PTR [bx+0x6e],0x656e
     fa9:	6c                   	ins    BYTE PTR es:[di],dx
     faa:	73 90                	jae    0xf3c
     fac:	04 0c                	add    al,0xc
     fae:	00 1e 54 61          	add    BYTE PTR ds:0x6154,bl
     fb2:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fb5:	45                   	inc    bp
     fb6:	52                   	push   dx
     fb7:	47                   	inc    di
     fb8:	43                   	inc    bx
     fb9:	68 61 72             	push   0x7261
     fbc:	67 65 73 45          	addr32 gs jae 0x1005
     fc0:	78 63                	js     0x1025
     fc2:	65 70 74             	gs jo  0x1039
     fc5:	69 6f 6e 6e 65       	imul   bp,WORD PTR [bx+0x6e],0x656e
     fca:	6c                   	ins    BYTE PTR es:[di],dx
     fcb:	6c                   	ins    BYTE PTR es:[di],dx
     fcc:	65 73 94             	gs jae 0xf63
     fcf:	04 0c                	add    al,0xc
     fd1:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     fd5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     fd8:	45                   	inc    bp
     fd9:	52                   	push   dx
     fda:	47                   	inc    di
     fdb:	52                   	push   dx
     fdc:	65 73 75             	gs jae 0x1054
     fdf:	6c                   	ins    BYTE PTR es:[di],dx
     fe0:	74 61                	je     0x1043
     fe2:	74 4e                	je     0x1032
     fe4:	65 74 53             	gs je  0x103a
     fe7:	49                   	dec    cx
     fe8:	47                   	inc    di
     fe9:	98                   	cbw
     fea:	04 00                	add    al,0x0
     fec:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     ff0:	6e                   	outs   dx,BYTE PTR ds:[si]
     ff1:	65 6c                	gs ins BYTE PTR es:[di],dx
     ff3:	31 9c 04 00          	xor    WORD PTR [si+0x4],bx
     ff7:	00 08                	add    BYTE PTR [bx+si],cl
     ff9:	50                   	push   ax
     ffa:	61                   	popa
     ffb:	6e                   	outs   dx,BYTE PTR ds:[si]
     ffc:	65 6c                	gs ins BYTE PTR es:[di],dx
     ffe:	33 30                	xor    si,WORD PTR [bx+si]
    1000:	32 a0 04 00          	xor    ah,BYTE PTR [bx+si+0x4]
    1004:	00 08                	add    BYTE PTR [bx+si],cl
    1006:	50                   	push   ax
    1007:	61                   	popa
    1008:	6e                   	outs   dx,BYTE PTR ds:[si]
    1009:	65 6c                	gs ins BYTE PTR es:[di],dx
    100b:	33 30                	xor    si,WORD PTR [bx+si]
    100d:	33 a4 04 00          	xor    sp,WORD PTR [si+0x4]
    1011:	00 08                	add    BYTE PTR [bx+si],cl
    1013:	50                   	push   ax
    1014:	61                   	popa
    1015:	6e                   	outs   dx,BYTE PTR ds:[si]
    1016:	65 6c                	gs ins BYTE PTR es:[di],dx
    1018:	33 30                	xor    si,WORD PTR [bx+si]
    101a:	34 a8                	xor    al,0xa8
    101c:	04 00                	add    al,0x0
    101e:	00 08                	add    BYTE PTR [bx+si],cl
    1020:	50                   	push   ax
    1021:	61                   	popa
    1022:	6e                   	outs   dx,BYTE PTR ds:[si]
    1023:	65 6c                	gs ins BYTE PTR es:[di],dx
    1025:	33 30                	xor    si,WORD PTR [bx+si]
    1027:	35 ac 04             	xor    ax,0x4ac
    102a:	00 00                	add    BYTE PTR [bx+si],al
    102c:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    102f:	6e                   	outs   dx,BYTE PTR ds:[si]
    1030:	65 6c                	gs ins BYTE PTR es:[di],dx
    1032:	33 30                	xor    si,WORD PTR [bx+si]
    1034:	36 b0 04             	ss mov al,0x4
    1037:	00 00                	add    BYTE PTR [bx+si],al
    1039:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    103c:	6e                   	outs   dx,BYTE PTR ds:[si]
    103d:	65 6c                	gs ins BYTE PTR es:[di],dx
    103f:	33 30                	xor    si,WORD PTR [bx+si]
    1041:	37                   	aaa
    1042:	b4 04                	mov    ah,0x4
    1044:	00 00                	add    BYTE PTR [bx+si],al
    1046:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    1049:	6e                   	outs   dx,BYTE PTR ds:[si]
    104a:	65 6c                	gs ins BYTE PTR es:[di],dx
    104c:	33 30                	xor    si,WORD PTR [bx+si]
    104e:	38 b8 04 00          	cmp    BYTE PTR [bx+si+0x4],bh
    1052:	00 08                	add    BYTE PTR [bx+si],cl
    1054:	50                   	push   ax
    1055:	61                   	popa
    1056:	6e                   	outs   dx,BYTE PTR ds:[si]
    1057:	65 6c                	gs ins BYTE PTR es:[di],dx
    1059:	33 30                	xor    si,WORD PTR [bx+si]
    105b:	39 bc 04 00          	cmp    WORD PTR [si+0x4],di
    105f:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    1063:	6e                   	outs   dx,BYTE PTR ds:[si]
    1064:	65 6c                	gs ins BYTE PTR es:[di],dx
    1066:	34 c0                	xor    al,0xc0
    1068:	04 00                	add    al,0x0
    106a:	00 08                	add    BYTE PTR [bx+si],cl
    106c:	50                   	push   ax
    106d:	61                   	popa
    106e:	6e                   	outs   dx,BYTE PTR ds:[si]
    106f:	65 6c                	gs ins BYTE PTR es:[di],dx
    1071:	33 31                	xor    si,WORD PTR [bx+di]
    1073:	33 c4                	xor    ax,sp
    1075:	04 00                	add    al,0x0
    1077:	00 08                	add    BYTE PTR [bx+si],cl
    1079:	50                   	push   ax
    107a:	61                   	popa
    107b:	6e                   	outs   dx,BYTE PTR ds:[si]
    107c:	65 6c                	gs ins BYTE PTR es:[di],dx
    107e:	33 31                	xor    si,WORD PTR [bx+di]
    1080:	34 c8                	xor    al,0xc8
    1082:	04 00                	add    al,0x0
    1084:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
    1088:	6e                   	outs   dx,BYTE PTR ds:[si]
    1089:	65 6c                	gs ins BYTE PTR es:[di],dx
    108b:	39 cc                	cmp    sp,cx
    108d:	04 00                	add    al,0x0
    108f:	00 08                	add    BYTE PTR [bx+si],cl
    1091:	50                   	push   ax
    1092:	61                   	popa
    1093:	6e                   	outs   dx,BYTE PTR ds:[si]
    1094:	65 6c                	gs ins BYTE PTR es:[di],dx
    1096:	33 31                	xor    si,WORD PTR [bx+di]
    1098:	36 d0 04             	rol    BYTE PTR ss:[si],1
    109b:	00 00                	add    BYTE PTR [bx+si],al
    109d:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    10a0:	6e                   	outs   dx,BYTE PTR ds:[si]
    10a1:	65 6c                	gs ins BYTE PTR es:[di],dx
    10a3:	33 31                	xor    si,WORD PTR [bx+di]
    10a5:	37                   	aaa
    10a6:	d4 04                	aam    0x4
    10a8:	00 00                	add    BYTE PTR [bx+si],al
    10aa:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    10ad:	6e                   	outs   dx,BYTE PTR ds:[si]
    10ae:	65 6c                	gs ins BYTE PTR es:[di],dx
    10b0:	33 31                	xor    si,WORD PTR [bx+di]
    10b2:	38 d8                	cmp    al,bl
    10b4:	04 00                	add    al,0x0
    10b6:	00 08                	add    BYTE PTR [bx+si],cl
    10b8:	50                   	push   ax
    10b9:	61                   	popa
    10ba:	6e                   	outs   dx,BYTE PTR ds:[si]
    10bb:	65 6c                	gs ins BYTE PTR es:[di],dx
    10bd:	33 31                	xor    si,WORD PTR [bx+di]
    10bf:	39 dc                	cmp    sp,bx
    10c1:	04 0c                	add    al,0xc
    10c3:	00 19                	add    BYTE PTR [bx+di],bl
    10c5:	54                   	push   sp
    10c6:	61                   	popa
    10c7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10ca:	45                   	inc    bp
    10cb:	52                   	push   dx
    10cc:	47                   	inc    di
    10cd:	50                   	push   ax
    10ce:	72 6f                	jb     0x113f
    10d0:	64 75 63             	fs jne 0x1136
    10d3:	74 69                	je     0x113e
    10d5:	6f                   	outs   dx,WORD PTR ds:[si]
    10d6:	6e                   	outs   dx,BYTE PTR ds:[si]
    10d7:	5f                   	pop    di
    10d8:	73 6f                	jae    0x1149
    10da:	6c                   	ins    BYTE PTR es:[di],dx
    10db:	64 65 65 e0 04       	fs gs gs loopne 0x10e4
    10e0:	0c 00                	or     al,0x0
    10e2:	19 54 61             	sbb    WORD PTR [si+0x61],dx
    10e5:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    10e8:	45                   	inc    bp
    10e9:	52                   	push   dx
    10ea:	47                   	inc    di
    10eb:	50                   	push   ax
    10ec:	72 6f                	jb     0x115d
    10ee:	64 75 63             	fs jne 0x1154
    10f1:	74 69                	je     0x115c
    10f3:	6f                   	outs   dx,WORD PTR ds:[si]
    10f4:	6e                   	outs   dx,BYTE PTR ds:[si]
    10f5:	5f                   	pop    di
    10f6:	76 65                	jbe    0x115d
    10f8:	6e                   	outs   dx,BYTE PTR ds:[si]
    10f9:	64 75 65             	fs jne 0x1161
    10fc:	e4 04                	in     al,0x4
    10fe:	0c 00                	or     al,0x0
    1100:	23 54 61             	and    dx,WORD PTR [si+0x61]
    1103:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1106:	45                   	inc    bp
    1107:	52                   	push   dx
    1108:	47                   	inc    di
    1109:	50                   	push   ax
    110a:	72 6f                	jb     0x117b
    110c:	64 75 63             	fs jne 0x1172
    110f:	74 69                	je     0x117a
    1111:	6f                   	outs   dx,WORD PTR ds:[si]
    1112:	6e                   	outs   dx,BYTE PTR ds:[si]
    1113:	5f                   	pop    di
    1114:	6f                   	outs   dx,WORD PTR ds:[si]
    1115:	66 66 72 65          	data32 data32 jb 0x117e
    1119:	73 5f                	jae    0x117a
    111b:	73 70                	jae    0x118d
    111d:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
    1121:	6c                   	ins    BYTE PTR es:[di],dx
    1122:	65 73 e8             	gs jae 0x110d
    1125:	04 0c                	add    al,0xc
    1127:	00 1a                	add    BYTE PTR [bp+si],bl
    1129:	54                   	push   sp
    112a:	61                   	popa
    112b:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    112e:	45                   	inc    bp
    112f:	52                   	push   dx
    1130:	47                   	inc    di
    1131:	50                   	push   ax
    1132:	72 6f                	jb     0x11a3
    1134:	64 75 63             	fs jne 0x119a
    1137:	74 69                	je     0x11a2
    1139:	6f                   	outs   dx,WORD PTR ds:[si]
    113a:	6e                   	outs   dx,BYTE PTR ds:[si]
    113b:	5f                   	pop    di
    113c:	73 74                	jae    0x11b2
    113e:	6f                   	outs   dx,WORD PTR ds:[si]
    113f:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
    1142:	65 ec                	gs in  al,dx
    1144:	04 0c                	add    al,0xc
    1146:	00 1e 54 61          	add    BYTE PTR ds:0x6154,bl
    114a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    114d:	45                   	inc    bp
    114e:	52                   	push   dx
    114f:	47                   	inc    di
    1150:	50                   	push   ax
    1151:	72 6f                	jb     0x11c2
    1153:	64 75 63             	fs jne 0x11b9
    1156:	74 69                	je     0x11c1
    1158:	6f                   	outs   dx,WORD PTR ds:[si]
    1159:	6e                   	outs   dx,BYTE PTR ds:[si]
    115a:	5f                   	pop    di
    115b:	44                   	inc    sp
    115c:	65 5f                	gs pop di
    115e:	45                   	inc    bp
    115f:	78 65                	js     0x11c6
    1161:	72 63                	jb     0x11c6
    1163:	69 63 65 f0 04       	imul   sp,WORD PTR [bp+di+0x65],0x4f0
    1168:	0c 00                	or     al,0x0
    116a:	18 54 61             	sbb    BYTE PTR [si+0x61],dl
    116d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    1170:	45                   	inc    bp
    1171:	52                   	push   dx
    1172:	47                   	inc    di
    1173:	4d                   	dec    bp
    1174:	61                   	popa
    1175:	74 69                	je     0x11e0
    1177:	65 72 65             	gs jb  0x11df
    117a:	43                   	inc    bx
    117b:	6f                   	outs   dx,WORD PTR ds:[si]
    117c:	6e                   	outs   dx,BYTE PTR ds:[si]
    117d:	73 6f                	jae    0x11ee
    117f:	6d                   	ins    WORD PTR es:[di],dx
    1180:	6d                   	ins    WORD PTR es:[di],dx
    1181:	65 65 f4             	gs gs hlt
    1184:	04 0c                	add    al,0xc
    1186:	00 0f                	add    BYTE PTR [bx],cl
    1188:	54                   	push   sp
    1189:	61                   	popa
    118a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    118d:	45                   	inc    bp
    118e:	52                   	push   dx
    118f:	47                   	inc    di
    1190:	51                   	push   cx
    1191:	75 61                	jne    0x11f4
    1193:	6c                   	ins    BYTE PTR es:[di],dx
    1194:	69 74 65 f8 04       	imul   si,WORD PTR [si+0x65],0x4f8
    1199:	0c 00                	or     al,0x0
    119b:	16                   	push   ss
    119c:	54                   	push   sp
    119d:	61                   	popa
    119e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11a1:	45                   	inc    bp
    11a2:	52                   	push   dx
    11a3:	47                   	inc    di
    11a4:	50                   	push   ax
    11a5:	75 62                	jne    0x1209
    11a7:	45                   	inc    bp
    11a8:	74 41                	je     0x11eb
    11aa:	63 74 69             	arpl   WORD PTR [si+0x69],si
    11ad:	6f                   	outs   dx,WORD PTR ds:[si]
    11ae:	6e                   	outs   dx,BYTE PTR ds:[si]
    11af:	43                   	inc    bx
    11b0:	6f                   	outs   dx,WORD PTR ds:[si]
    11b1:	6d                   	ins    WORD PTR es:[di],dx
    11b2:	fc                   	cld
    11b3:	04 0c                	add    al,0xc
    11b5:	00 0e 54 61          	add    BYTE PTR ds:0x6154,cl
    11b9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
    11bc:	45                   	inc    bp
    11bd:	52                   	push   dx
    11be:	47                   	inc    di
    11bf:	45                   	inc    bp
    11c0:	74 75                	je     0x1237
    11c2:	64 65 73 00          	fs gs jae 0x11c6
    11c6:	05 00 00             	add    ax,0x0
    11c9:	07                   	pop    es
    11ca:	50                   	push   ax
    11cb:	61                   	popa
    11cc:	6e                   	outs   dx,BYTE PTR ds:[si]
    11cd:	65 6c                	gs ins BYTE PTR es:[di],dx
    11cf:	31 30                	xor    WORD PTR [bx+si],si
    11d1:	04 05                	add    al,0x5
    11d3:	00 00                	add    BYTE PTR [bx+si],al
    11d5:	07                   	pop    es
    11d6:	50                   	push   ax
    11d7:	61                   	popa
    11d8:	6e                   	outs   dx,BYTE PTR ds:[si]
    11d9:	65 6c                	gs ins BYTE PTR es:[di],dx
    11db:	31 31                	xor    WORD PTR [bx+di],si
    11dd:	08 05                	or     BYTE PTR [di],al
    11df:	30 00                	xor    BYTE PTR [bx+si],al
    11e1:	09 44 42             	or     WORD PTR [si+0x42],ax
    11e4:	45                   	inc    bp
    11e5:	64 69 74 31 30 31    	imul   si,WORD PTR fs:[si+0x31],0x3130
    11eb:	0c 05                	or     al,0x5
    11ed:	30 00                	xor    BYTE PTR [bx+si],al
    11ef:	09 44 42             	or     WORD PTR [si+0x42],ax
    11f2:	45                   	inc    bp
    11f3:	64 69 74 31 30 32    	imul   si,WORD PTR fs:[si+0x31],0x3230
    11f9:	10 05                	adc    BYTE PTR [di],al
    11fb:	30 00                	xor    BYTE PTR [bx+si],al
    11fd:	09 44 42             	or     WORD PTR [si+0x42],ax
    1200:	45                   	inc    bp
    1201:	64 69 74 31 30 33    	imul   si,WORD PTR fs:[si+0x31],0x3330
    1207:	14 05                	adc    al,0x5
    1209:	30 00                	xor    BYTE PTR [bx+si],al
    120b:	09 44 42             	or     WORD PTR [si+0x42],ax
    120e:	45                   	inc    bp
    120f:	64 69 74 31 30 34    	imul   si,WORD PTR fs:[si+0x31],0x3430
    1215:	18 05                	sbb    BYTE PTR [di],al
    1217:	30 00                	xor    BYTE PTR [bx+si],al
    1219:	09 44 42             	or     WORD PTR [si+0x42],ax
    121c:	45                   	inc    bp
    121d:	64 69 74 32 30 32    	imul   si,WORD PTR fs:[si+0x32],0x3230
    1223:	1c 05                	sbb    al,0x5
    1225:	30 00                	xor    BYTE PTR [bx+si],al
    1227:	09 44 42             	or     WORD PTR [si+0x42],ax
    122a:	45                   	inc    bp
    122b:	64 69 74 32 30 33    	imul   si,WORD PTR fs:[si+0x32],0x3330
    1231:	20 05                	and    BYTE PTR [di],al
    1233:	30 00                	xor    BYTE PTR [bx+si],al
    1235:	09 44 42             	or     WORD PTR [si+0x42],ax
    1238:	45                   	inc    bp
    1239:	64 69 74 32 30 34    	imul   si,WORD PTR fs:[si+0x32],0x3430
    123f:	24 05                	and    al,0x5
    1241:	30 00                	xor    BYTE PTR [bx+si],al
    1243:	09 44 42             	or     WORD PTR [si+0x42],ax
    1246:	45                   	inc    bp
    1247:	64 69 74 32 30 35    	imul   si,WORD PTR fs:[si+0x32],0x3530
    124d:	28 05                	sub    BYTE PTR [di],al
    124f:	30 00                	xor    BYTE PTR [bx+si],al
    1251:	09 44 42             	or     WORD PTR [si+0x42],ax
    1254:	45                   	inc    bp
    1255:	64 69 74 32 30 36    	imul   si,WORD PTR fs:[si+0x32],0x3630
    125b:	2c 05                	sub    al,0x5
    125d:	30 00                	xor    BYTE PTR [bx+si],al
    125f:	09 44 42             	or     WORD PTR [si+0x42],ax
    1262:	45                   	inc    bp
    1263:	64 69 74 32 30 37    	imul   si,WORD PTR fs:[si+0x32],0x3730
    1269:	30 05                	xor    BYTE PTR [di],al
    126b:	30 00                	xor    BYTE PTR [bx+si],al
    126d:	09 44 42             	or     WORD PTR [si+0x42],ax
    1270:	45                   	inc    bp
    1271:	64 69 74 32 30 38    	imul   si,WORD PTR fs:[si+0x32],0x3830
    1277:	34 05                	xor    al,0x5
    1279:	30 00                	xor    BYTE PTR [bx+si],al
    127b:	09 44 42             	or     WORD PTR [si+0x42],ax
    127e:	45                   	inc    bp
    127f:	64 69 74 32 30 39    	imul   si,WORD PTR fs:[si+0x32],0x3930
    1285:	38 05                	cmp    BYTE PTR [di],al
    1287:	00 00                	add    BYTE PTR [bx+si],al
    1289:	07                   	pop    es
    128a:	50                   	push   ax
    128b:	61                   	popa
    128c:	6e                   	outs   dx,BYTE PTR ds:[si]
    128d:	65 6c                	gs ins BYTE PTR es:[di],dx
    128f:	31 32                	xor    WORD PTR [bp+si],si
    1291:	3c 05                	cmp    al,0x5
    1293:	30 00                	xor    BYTE PTR [bx+si],al
    1295:	09 44 42             	or     WORD PTR [si+0x42],ax
    1298:	45                   	inc    bp
    1299:	64 69 74 33 30 32    	imul   si,WORD PTR fs:[si+0x33],0x3230
    129f:	40                   	inc    ax
    12a0:	05 30 00             	add    ax,0x30
    12a3:	09 44 42             	or     WORD PTR [si+0x42],ax
    12a6:	45                   	inc    bp
    12a7:	64 69 74 33 30 33    	imul   si,WORD PTR fs:[si+0x33],0x3330
    12ad:	44                   	inc    sp
    12ae:	05 30 00             	add    ax,0x30
    12b1:	09 44 42             	or     WORD PTR [si+0x42],ax
    12b4:	45                   	inc    bp
    12b5:	64 69 74 33 30 34    	imul   si,WORD PTR fs:[si+0x33],0x3430
    12bb:	48                   	dec    ax
    12bc:	05 30 00             	add    ax,0x30
    12bf:	09 44 42             	or     WORD PTR [si+0x42],ax
    12c2:	45                   	inc    bp
    12c3:	64 69 74 33 30 35    	imul   si,WORD PTR fs:[si+0x33],0x3530
    12c9:	4c                   	dec    sp
    12ca:	05 30 00             	add    ax,0x30
    12cd:	09 44 42             	or     WORD PTR [si+0x42],ax
    12d0:	45                   	inc    bp
    12d1:	64 69 74 33 30 36    	imul   si,WORD PTR fs:[si+0x33],0x3630
    12d7:	50                   	push   ax
    12d8:	05 30 00             	add    ax,0x30
    12db:	09 44 42             	or     WORD PTR [si+0x42],ax
    12de:	45                   	inc    bp
    12df:	64 69 74 33 30 37    	imul   si,WORD PTR fs:[si+0x33],0x3730
    12e5:	54                   	push   sp
    12e6:	05 30 00             	add    ax,0x30
    12e9:	09 44 42             	or     WORD PTR [si+0x42],ax
    12ec:	45                   	inc    bp
    12ed:	64 69 74 33 30 38    	imul   si,WORD PTR fs:[si+0x33],0x3830
    12f3:	58                   	pop    ax
    12f4:	05 30 00             	add    ax,0x30
    12f7:	09 44 42             	or     WORD PTR [si+0x42],ax
    12fa:	45                   	inc    bp
    12fb:	64 69 74 33 30 39    	imul   si,WORD PTR fs:[si+0x33],0x3930
    1301:	5c                   	pop    sp
    1302:	05 30 00             	add    ax,0x30
    1305:	09 44 42             	or     WORD PTR [si+0x42],ax
    1308:	45                   	inc    bp
    1309:	64 69 74 33 31 31    	imul   si,WORD PTR fs:[si+0x33],0x3131
    130f:	60                   	pusha
    1310:	05 30 00             	add    ax,0x30
    1313:	09 44 42             	or     WORD PTR [si+0x42],ax
    1316:	45                   	inc    bp
    1317:	64 69 74 33 31 33    	imul   si,WORD PTR fs:[si+0x33],0x3331
    131d:	64 05 30 00          	fs add ax,0x30
    1321:	09 44 42             	or     WORD PTR [si+0x42],ax
    1324:	45                   	inc    bp
    1325:	64 69 74 33 31 34    	imul   si,WORD PTR fs:[si+0x33],0x3431
    132b:	68 05 30             	push   0x3005
    132e:	00 09                	add    BYTE PTR [bx+di],cl
    1330:	44                   	inc    sp
    1331:	42                   	inc    dx
    1332:	45                   	inc    bp
    1333:	64 69 74 33 31 36    	imul   si,WORD PTR fs:[si+0x33],0x3631
    1339:	6c                   	ins    BYTE PTR es:[di],dx
    133a:	05 30 00             	add    ax,0x30
    133d:	09 44 42             	or     WORD PTR [si+0x42],ax
    1340:	45                   	inc    bp
    1341:	64 69 74 33 31 37    	imul   si,WORD PTR fs:[si+0x33],0x3731
    1347:	70 05                	jo     0x134e
    1349:	30 00                	xor    BYTE PTR [bx+si],al
    134b:	09 44 42             	or     WORD PTR [si+0x42],ax
    134e:	45                   	inc    bp
    134f:	64 69 74 33 31 38    	imul   si,WORD PTR fs:[si+0x33],0x3831
    1355:	74 05                	je     0x135c
    1357:	30 00                	xor    BYTE PTR [bx+si],al
    1359:	09 44 42             	or     WORD PTR [si+0x42],ax
    135c:	45                   	inc    bp
    135d:	64 69 74 33 31 39    	imul   si,WORD PTR fs:[si+0x33],0x3931
    1363:	78 05                	js     0x136a
    1365:	00 00                	add    BYTE PTR [bx+si],al
    1367:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    136a:	6e                   	outs   dx,BYTE PTR ds:[si]
    136b:	65 6c                	gs ins BYTE PTR es:[di],dx
    136d:	32 30                	xor    dh,BYTE PTR [bx+si]
    136f:	31 7c 05             	xor    WORD PTR [si+0x5],di
    1372:	00 00                	add    BYTE PTR [bx+si],al
    1374:	08 50 61             	or     BYTE PTR [bx+si+0x61],dl
    1377:	6e                   	outs   dx,BYTE PTR ds:[si]
    1378:	65 6c                	gs ins BYTE PTR es:[di],dx
    137a:	32 30                	xor    dh,BYTE PTR [bx+si]
    137c:	38 80 05 00          	cmp    BYTE PTR [bx+si+0x5],al
    1380:	00 08                	add    BYTE PTR [bx+si],cl
    1382:	50                   	push   ax
    1383:	61                   	popa
    1384:	6e                   	outs   dx,BYTE PTR ds:[si]
    1385:	65 6c                	gs ins BYTE PTR es:[di],dx
    1387:	32 30                	xor    dh,BYTE PTR [bx+si]
    1389:	39 84 05 00          	cmp    WORD PTR [si+0x5],ax
    138d:	00 08                	add    BYTE PTR [bx+si],cl
    138f:	50                   	push   ax
    1390:	61                   	popa
    1391:	6e                   	outs   dx,BYTE PTR ds:[si]
    1392:	65 6c                	gs ins BYTE PTR es:[di],dx
    1394:	32 31                	xor    dh,BYTE PTR [bx+di]
    1396:	30 88 05 30          	xor    BYTE PTR [bx+si+0x3005],cl
    139a:	00 09                	add    BYTE PTR [bx+di],cl
    139c:	44                   	inc    sp
    139d:	42                   	inc    dx
    139e:	45                   	inc    bp
    139f:	64 69 74 32 30 31    	imul   si,WORD PTR fs:[si+0x32],0x3130
    13a5:	8c 05                	mov    WORD PTR [di],es
    13a7:	2c 00                	sub    al,0x0
    13a9:	06                   	push   es
    13aa:	53                   	push   bx
    13ab:	68 61 70             	push   0x7061
    13ae:	65 32 0d             	xor    cl,BYTE PTR gs:[di]
    13b1:	00 ad 0d e0          	add    BYTE PTR [di-0x1ff3],ch
    13b5:	13 38                	adc    di,WORD PTR [bx+si]
    13b7:	01 c0                	add    ax,ax
    13b9:	13 c8                	adc    cx,ax
    13bb:	08 f3                	or     bl,dh
    13bd:	17                   	pop    ss
    13be:	58                   	pop    ax
    13bf:	0a d0                	or     dl,al
    13c1:	13 ef                	adc    bp,di
    13c3:	02 c8                	add    cl,al
    13c5:	13 94 00 96          	adc    dx,WORD PTR [si-0x6a00]
    13c9:	25 7e 08             	and    ax,0x87e
    13cc:	8b 16 c8 07          	mov    dx,WORD PTR ds:0x7c8
    13d0:	d4 13                	aam    0x13
    13d2:	67 0c 05             	addr32 or al,0x5
    13d5:	18 17                	sbb    BYTE PTR [bx],dl
    13d7:	06                   	push   es
    13d8:	dc 13                	fcom   QWORD PTR [bp+di]
    13da:	91                   	xchg   cx,ax
    13db:	12 39                	adc    bh,BYTE PTR [bx+di]
    13dd:	52                   	push   dx
    13de:	7d 00                	jge    0x13e0
    13e0:	bf 53 22             	mov    di,0x2253
    13e3:	00 d9                	add    cl,bl
    13e5:	17                   	pop    ss
    13e6:	07                   	pop    es
    13e7:	0d 54 46             	or     ax,0x4654
    13ea:	6f                   	outs   dx,WORD PTR ds:[si]
    13eb:	72 6d                	jb     0x145a
    13ed:	53                   	push   bx
    13ee:	45                   	inc    bp
    13ef:	52                   	push   dx
    13f0:	47                   	inc    di
    13f1:	5f                   	pop    di
    13f2:	53                   	push   bx
    13f3:	49                   	dec    cx
    13f4:	47                   	inc    di
    13f5:	22 00                	and    al,BYTE PTR [bx+si]
    13f7:	37                   	aaa
    13f8:	14 7b                	adc    al,0x7b
    13fa:	06                   	push   es
    13fb:	28 14                	sub    BYTE PTR [si],dl
    13fd:	38 00                	cmp    BYTE PTR [bx+si],al
    13ff:	06                   	push   es
    1400:	53                   	push   bx
    1401:	65 72 73             	gs jb  0x1477
    1404:	69 67 00 00 55       	imul   sp,WORD PTR [bx+0x0],0x5500
    1409:	89 e5                	mov    bp,sp
    140b:	31 c0                	xor    ax,ax
    140d:	9a 44 04 42 14       	call   0x1442:0x444
    1412:	6a 00                	push   0x0
    1414:	9a c2 38 20 16       	call   0x1620:0x38c2
    1419:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    141c:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
    1423:	06                   	push   es
    1424:	57                   	push   di
    1425:	9a 56 55 50 14       	call   0x1450:0x5556
    142a:	9a c3 28 6e 18       	call   0x186e:0x28c3
    142f:	c9                   	leave
    1430:	ca 04 00             	retf   0x4
    1433:	00 00                	add    BYTE PTR [bx+si],al
    1435:	e6 14                	out    0x14,al
    1437:	6a 14                	push   0x14
    1439:	55                   	push   bp
    143a:	89 e5                	mov    bp,sp
    143c:	b8 08 00             	mov    ax,0x8
    143f:	9a 44 04 04 15       	call   0x1504:0x444
    1444:	83 ec 08             	sub    sp,0x8
    1447:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    144b:	06                   	push   es
    144c:	57                   	push   di
    144d:	9a 03 73 71 14       	call   0x1471:0x7303
    1452:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    1456:	7f 03                	jg     0x145b
    1458:	e9 96 00             	jmp    0x14f1
    145b:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    145f:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1463:	b0 01                	mov    al,0x1
    1465:	50                   	push   ax
    1466:	b8 22 00             	mov    ax,0x22
    1469:	ba a5 14             	mov    dx,0x14a5
    146c:	52                   	push   dx
    146d:	50                   	push   ax
    146e:	9a 53 25 ce 14       	call   0x14ce:0x2553
    1473:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1476:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1479:	b8 33 14             	mov    ax,0x1433
    147c:	0e                   	push   cs
    147d:	50                   	push   ax
    147e:	55                   	push   bp
    147f:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1483:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1487:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    148a:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    148d:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1490:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1493:	26 89 85 94 05       	mov    WORD PTR es:[di+0x594],ax
    1498:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    149b:	26 89 85 92 05       	mov    WORD PTR es:[di+0x592],ax
    14a0:	06                   	push   es
    14a1:	57                   	push   di
    14a2:	9a 2c 21 b4 14       	call   0x14b4:0x212c
    14a7:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14aa:	26 ff b5 92 05       	push   WORD PTR es:[di+0x592]
    14af:	06                   	push   es
    14b0:	57                   	push   di
    14b1:	9a 07 2c f9 14       	call   0x14f9:0x2c07
    14b6:	6a ff                	push   0xffff
    14b8:	6a f0                	push   0xfff0
    14ba:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14bd:	06                   	push   es
    14be:	57                   	push   di
    14bf:	9a d5 1e ad 15       	call   0x15ad:0x1ed5
    14c4:	6a 02                	push   0x2
    14c6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14c9:	06                   	push   es
    14ca:	57                   	push   di
    14cb:	9a 14 3a d8 14       	call   0x14d8:0x3a14
    14d0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    14d3:	06                   	push   es
    14d4:	57                   	push   di
    14d5:	9a 45 5d ee 14       	call   0x14ee:0x5d45
    14da:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    14de:	83 c4 06             	add    sp,0x6
    14e1:	b8 f1 14             	mov    ax,0x14f1
    14e4:	0e                   	push   cs
    14e5:	50                   	push   ax
    14e6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    14e9:	06                   	push   es
    14ea:	57                   	push   di
    14eb:	9a 1d 5f 12 15       	call   0x1512:0x5f1d
    14f0:	cb                   	retf
    14f1:	c9                   	leave
    14f2:	ca 04 00             	retf   0x4
    14f5:	00 00                	add    BYTE PTR [bx+si],al
    14f7:	39 16 54 15          	cmp    WORD PTR ds:0x1554,dx
    14fb:	55                   	push   bp
    14fc:	89 e5                	mov    bp,sp
    14fe:	b8 0a 00             	mov    ax,0xa
    1501:	9a 44 04 50 16       	call   0x1650:0x444
    1506:	83 ec 0a             	sub    sp,0xa
    1509:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    150d:	06                   	push   es
    150e:	57                   	push   di
    150f:	9a 03 73 5b 15       	call   0x155b:0x7303
    1514:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    1518:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    151c:	7e 1e                	jle    0x153c
    151e:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    1522:	75 14                	jne    0x1538
    1524:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1528:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    152e:	b0 00                	mov    al,0x0
    1530:	75 01                	jne    0x1533
    1532:	40                   	inc    ax
    1533:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    1536:	eb 04                	jmp    0x153c
    1538:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    153c:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    1540:	75 03                	jne    0x1545
    1542:	e9 ff 00             	jmp    0x1644
    1545:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1549:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    154d:	b0 01                	mov    al,0x1
    154f:	50                   	push   ax
    1550:	b8 22 00             	mov    ax,0x22
    1553:	ba 8f 15             	mov    dx,0x158f
    1556:	52                   	push   dx
    1557:	50                   	push   ax
    1558:	9a 53 25 bb 15       	call   0x15bb:0x2553
    155d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1560:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1563:	b8 f5 14             	mov    ax,0x14f5
    1566:	0e                   	push   cs
    1567:	50                   	push   ax
    1568:	55                   	push   bp
    1569:	ff 36 58 18          	push   WORD PTR ds:0x1858
    156d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1571:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1574:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1577:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    157a:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    157d:	26 89 85 94 05       	mov    WORD PTR es:[di+0x594],ax
    1582:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1585:	26 89 85 92 05       	mov    WORD PTR es:[di+0x592],ax
    158a:	06                   	push   es
    158b:	57                   	push   di
    158c:	9a 2c 21 9e 15       	call   0x159e:0x212c
    1591:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1594:	26 ff b5 92 05       	push   WORD PTR es:[di+0x592]
    1599:	06                   	push   es
    159a:	57                   	push   di
    159b:	9a 07 2c f5 15       	call   0x15f5:0x2c07
    15a0:	68 ff 00             	push   0xff
    15a3:	6a ff                	push   0xffff
    15a5:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15a8:	06                   	push   es
    15a9:	57                   	push   di
    15aa:	9a d5 1e dd 15       	call   0x15dd:0x1ed5
    15af:	6a 00                	push   0x0
    15b1:	6a 00                	push   0x0
    15b3:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15b6:	06                   	push   es
    15b7:	57                   	push   di
    15b8:	9a b2 36 c7 15       	call   0x15c7:0x36b2
    15bd:	6a 02                	push   0x2
    15bf:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15c2:	06                   	push   es
    15c3:	57                   	push   di
    15c4:	9a 14 3a d3 15       	call   0x15d3:0x3a14
    15c9:	6a 01                	push   0x1
    15cb:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15ce:	06                   	push   es
    15cf:	57                   	push   di
    15d0:	9a e5 34 02 16       	call   0x1602:0x34e5
    15d5:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    15d8:	06                   	push   es
    15d9:	57                   	push   di
    15da:	9a b9 62 28 1c       	call   0x1c28:0x62b9
    15df:	50                   	push   ax
    15e0:	6a 04                	push   0x4
    15e2:	9a ff ff 00 00       	call   0x0:0xffff
    15e7:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    15eb:	74 0c                	je     0x15f9
    15ed:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    15f0:	06                   	push   es
    15f1:	57                   	push   di
    15f2:	9a e4 4d 64 16       	call   0x1664:0x4de4
    15f7:	eb 34                	jmp    0x162d
    15f9:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    15fd:	06                   	push   es
    15fe:	57                   	push   di
    15ff:	9a 03 73 2b 16       	call   0x162b:0x7303
    1604:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1607:	ff 76 fc             	push   WORD PTR [bp-0x4]
    160a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    160d:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    1612:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    1617:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    161b:	06                   	push   es
    161c:	57                   	push   di
    161d:	9a 1a 31 c5 16       	call   0x16c5:0x311a
    1622:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1626:	06                   	push   es
    1627:	57                   	push   di
    1628:	9a 03 73 41 16       	call   0x1641:0x7303
    162d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1631:	83 c4 06             	add    sp,0x6
    1634:	b8 44 16             	mov    ax,0x1644
    1637:	0e                   	push   cs
    1638:	50                   	push   ax
    1639:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    163c:	06                   	push   es
    163d:	57                   	push   di
    163e:	9a 1d 5f b6 16       	call   0x16b6:0x5f1d
    1643:	cb                   	retf
    1644:	c9                   	leave
    1645:	ca 06 00             	retf   0x6
    1648:	55                   	push   bp
    1649:	89 e5                	mov    bp,sp
    164b:	31 c0                	xor    ax,ax
    164d:	9a 44 04 79 16       	call   0x1679:0x444
    1652:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1655:	26 ff b5 92 05       	push   WORD PTR es:[di+0x592]
    165a:	26 ff b5 94 05       	push   WORD PTR es:[di+0x594]
    165f:	6a 00                	push   0x0
    1661:	9a fb 14 6e 16       	call   0x166e:0x14fb
    1666:	c9                   	leave
    1667:	ca 08 00             	retf   0x8
    166a:	00 00                	add    BYTE PTR [bx+si],al
    166c:	2b 17                	sub    dx,WORD PTR [bx]
    166e:	ff 16 55 89          	call   WORD PTR ds:0x8955
    1672:	e5 b8                	in     ax,0xb8
    1674:	08 00                	or     BYTE PTR [bx+si],al
    1676:	9a 44 04 7a 17       	call   0x177a:0x444
    167b:	83 ec 08             	sub    sp,0x8
    167e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1681:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    1686:	06                   	push   es
    1687:	57                   	push   di
    1688:	9a 17 2f 6c 4d       	call   0x4d6c:0x2f17
    168d:	08 c0                	or     al,al
    168f:	75 03                	jne    0x1694
    1691:	e9 b3 00             	jmp    0x1747
    1694:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1697:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    169c:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    16a1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    16a4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    16a7:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    16ac:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    16b1:	06                   	push   es
    16b2:	57                   	push   di
    16b3:	9a d0 3f cc 16       	call   0x16cc:0x3fd0
    16b8:	ff 76 08             	push   WORD PTR [bp+0x8]
    16bb:	ff 76 06             	push   WORD PTR [bp+0x6]
    16be:	b0 01                	mov    al,0x1
    16c0:	50                   	push   ax
    16c1:	b8 b4 25             	mov    ax,0x25b4
    16c4:	ba f4 16             	mov    dx,0x16f4
    16c7:	52                   	push   dx
    16c8:	50                   	push   ax
    16c9:	9a 53 25 1d 17       	call   0x171d:0x2553
    16ce:	a3 04 20             	mov    ds:0x2004,ax
    16d1:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    16d5:	b8 6a 16             	mov    ax,0x166a
    16d8:	0e                   	push   cs
    16d9:	50                   	push   ax
    16da:	55                   	push   bp
    16db:	ff 36 58 18          	push   WORD PTR ds:0x1858
    16df:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    16e3:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    16e7:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    16ea:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    16ed:	6a 01                	push   0x1
    16ef:	06                   	push   es
    16f0:	57                   	push   di
    16f1:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    16f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16f9:	06                   	push   es
    16fa:	57                   	push   di
    16fb:	b8 48 16             	mov    ax,0x1648
    16fe:	ba 1e 21             	mov    dx,0x211e
    1701:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1704:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    1709:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    170e:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    1713:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    1718:	06                   	push   es
    1719:	57                   	push   di
    171a:	9a 45 5d 34 17       	call   0x1734:0x5d45
    171f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1723:	83 c4 06             	add    sp,0x6
    1726:	b8 37 17             	mov    ax,0x1737
    1729:	0e                   	push   cs
    172a:	50                   	push   ax
    172b:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    172f:	06                   	push   es
    1730:	57                   	push   di
    1731:	9a 1d 5f 45 17       	call   0x1745:0x5f1d
    1736:	cb                   	retf
    1737:	ff 76 fe             	push   WORD PTR [bp-0x2]
    173a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    173d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1740:	06                   	push   es
    1741:	57                   	push   di
    1742:	9a d0 3f 93 17       	call   0x1793:0x3fd0
    1747:	c9                   	leave
    1748:	ca 08 00             	retf   0x8
    174b:	0a 23                	or     ah,BYTE PTR [bp+di]
    174d:	2c 23                	sub    al,0x23
    174f:	23 30                	and    si,WORD PTR [bx+si]
    1751:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1754:	23 23                	and    sp,WORD PTR [bp+di]
    1756:	07                   	pop    es
    1757:	23 30                	and    si,WORD PTR [bx+si]
    1759:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    175c:	23 23                	and    sp,WORD PTR [bp+di]
    175e:	07                   	pop    es
    175f:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    1763:	2b 30                	sub    si,WORD PTR [bx+si]
    1765:	30 01                	xor    BYTE PTR [bx+di],al
    1767:	30 05                	xor    BYTE PTR [di],al
    1769:	23 2c                	and    bp,WORD PTR [si]
    176b:	23 23                	and    sp,WORD PTR [bp+di]
    176d:	30 02                	xor    BYTE PTR [bp+si],al
    176f:	23 30                	and    si,WORD PTR [bx+si]
    1771:	55                   	push   bp
    1772:	89 e5                	mov    bp,sp
    1774:	b8 14 03             	mov    ax,0x314
    1777:	9a 44 04 0c 18       	call   0x180c:0x444
    177c:	81 ec 14 03          	sub    sp,0x314
    1780:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1783:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    1787:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    178b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    178e:	06                   	push   es
    178f:	57                   	push   di
    1790:	9a d5 33 bd 17       	call   0x17bd:0x33d5
    1795:	89 c7                	mov    di,ax
    1797:	8e c2                	mov    es,dx
    1799:	26 8b 45 07          	mov    ax,WORD PTR es:[di+0x7]
    179d:	26 8b 55 09          	mov    dx,WORD PTR es:[di+0x9]
    17a1:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    17a5:	89 96 fa fd          	mov    WORD PTR [bp-0x206],dx
    17a9:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    17ad:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    17b1:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    17b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17b8:	06                   	push   es
    17b9:	57                   	push   di
    17ba:	9a d5 33 8c 18       	call   0x188c:0x33d5
    17bf:	89 c7                	mov    di,ax
    17c1:	8e c2                	mov    es,dx
    17c3:	06                   	push   es
    17c4:	57                   	push   di
    17c5:	9a 99 20 97 18       	call   0x1897:0x2099
    17ca:	8d be f4 fc          	lea    di,[bp-0x30c]
    17ce:	16                   	push   ss
    17cf:	57                   	push   di
    17d0:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    17d4:	06                   	push   es
    17d5:	57                   	push   di
    17d6:	9a 9f 1a e4 17       	call   0x17e4:0x1a9f
    17db:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    17df:	06                   	push   es
    17e0:	57                   	push   di
    17e1:	9a 5f 1a f5 1b       	call   0x1bf5:0x1a5f
    17e6:	89 c7                	mov    di,ax
    17e8:	8e c2                	mov    es,dx
    17ea:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    17ee:	06                   	push   es
    17ef:	57                   	push   di
    17f0:	9a 9b 3b 7b 1d       	call   0x1d7b:0x3b9b
    17f5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    17f8:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    17fb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    17fe:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1801:	bf 58 0a             	mov    di,0xa58
    1804:	b8 1f 18             	mov    ax,0x181f
    1807:	50                   	push   ax
    1808:	57                   	push   di
    1809:	9a 55 22 26 18       	call   0x1826:0x2255
    180e:	08 c0                	or     al,al
    1810:	75 03                	jne    0x1815
    1812:	e9 bb 01             	jmp    0x19d0
    1815:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1818:	ff 76 fc             	push   WORD PTR [bp-0x4]
    181b:	bf 58 0a             	mov    di,0xa58
    181e:	b8 cb 19             	mov    ax,0x19cb
    1821:	50                   	push   ax
    1822:	57                   	push   di
    1823:	9a 73 22 45 18       	call   0x1845:0x2273
    1828:	89 c7                	mov    di,ax
    182a:	8e c2                	mov    es,dx
    182c:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    1830:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    1834:	bf 4b 17             	mov    di,0x174b
    1837:	0e                   	push   cs
    1838:	57                   	push   di
    1839:	8d be fc fd          	lea    di,[bp-0x204]
    183d:	16                   	push   ss
    183e:	57                   	push   di
    183f:	68 ff 00             	push   0xff
    1842:	9a e7 17 7c 18       	call   0x187c:0x17e7
    1847:	8d be f0 fc          	lea    di,[bp-0x310]
    184b:	16                   	push   ss
    184c:	57                   	push   di
    184d:	8d be fc fd          	lea    di,[bp-0x204]
    1851:	16                   	push   ss
    1852:	57                   	push   di
    1853:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1857:	06                   	push   es
    1858:	57                   	push   di
    1859:	26 c4 3d             	les    di,DWORD PTR es:[di]
    185c:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1860:	83 ec 0a             	sub    sp,0xa
    1863:	89 e3                	mov    bx,sp
    1865:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1869:	90                   	nop
    186a:	9b                   	fwait
    186b:	9a d4 10 ee 18       	call   0x18ee:0x10d4
    1870:	8d be fc fe          	lea    di,[bp-0x104]
    1874:	16                   	push   ss
    1875:	57                   	push   di
    1876:	68 ff 00             	push   0xff
    1879:	9a e7 17 ab 18       	call   0x18ab:0x17e7
    187e:	8d be fc fe          	lea    di,[bp-0x104]
    1882:	16                   	push   ss
    1883:	57                   	push   di
    1884:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1887:	06                   	push   es
    1888:	57                   	push   di
    1889:	9a d5 33 0c 19       	call   0x190c:0x33d5
    188e:	89 c7                	mov    di,ax
    1890:	8e c2                	mov    es,dx
    1892:	06                   	push   es
    1893:	57                   	push   di
    1894:	9a 03 20 17 19       	call   0x1917:0x2003
    1899:	8b d0                	mov    dx,ax
    189b:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    189f:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    18a3:	2d 05 00             	sub    ax,0x5
    18a6:	71 05                	jno    0x18ad
    18a8:	9a 3e 04 c5 18       	call   0x18c5:0x43e
    18ad:	3b c2                	cmp    ax,dx
    18af:	7e 03                	jle    0x18b4
    18b1:	e9 08 01             	jmp    0x19bc
    18b4:	bf 56 17             	mov    di,0x1756
    18b7:	0e                   	push   cs
    18b8:	57                   	push   di
    18b9:	8d be fc fd          	lea    di,[bp-0x204]
    18bd:	16                   	push   ss
    18be:	57                   	push   di
    18bf:	68 ff 00             	push   0xff
    18c2:	9a e7 17 fc 18       	call   0x18fc:0x17e7
    18c7:	8d be f0 fc          	lea    di,[bp-0x310]
    18cb:	16                   	push   ss
    18cc:	57                   	push   di
    18cd:	8d be fc fd          	lea    di,[bp-0x204]
    18d1:	16                   	push   ss
    18d2:	57                   	push   di
    18d3:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    18d7:	06                   	push   es
    18d8:	57                   	push   di
    18d9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    18dc:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    18e0:	83 ec 0a             	sub    sp,0xa
    18e3:	89 e3                	mov    bx,sp
    18e5:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    18e9:	90                   	nop
    18ea:	9b                   	fwait
    18eb:	9a d4 10 50 1a       	call   0x1a50:0x10d4
    18f0:	8d be fc fe          	lea    di,[bp-0x104]
    18f4:	16                   	push   ss
    18f5:	57                   	push   di
    18f6:	68 ff 00             	push   0xff
    18f9:	9a e7 17 2b 19       	call   0x192b:0x17e7
    18fe:	8d be fc fe          	lea    di,[bp-0x104]
    1902:	16                   	push   ss
    1903:	57                   	push   di
    1904:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1907:	06                   	push   es
    1908:	57                   	push   di
    1909:	9a d5 33 55 19       	call   0x1955:0x33d5
    190e:	89 c7                	mov    di,ax
    1910:	8e c2                	mov    es,dx
    1912:	06                   	push   es
    1913:	57                   	push   di
    1914:	9a 03 20 60 19       	call   0x1960:0x2003
    1919:	8b d0                	mov    dx,ax
    191b:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    191f:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1923:	2d 05 00             	sub    ax,0x5
    1926:	71 05                	jno    0x192d
    1928:	9a 3e 04 45 19       	call   0x1945:0x43e
    192d:	3b c2                	cmp    ax,dx
    192f:	7e 03                	jle    0x1934
    1931:	e9 88 00             	jmp    0x19bc
    1934:	bf 5e 17             	mov    di,0x175e
    1937:	0e                   	push   cs
    1938:	57                   	push   di
    1939:	8d be fc fd          	lea    di,[bp-0x204]
    193d:	16                   	push   ss
    193e:	57                   	push   di
    193f:	68 ff 00             	push   0xff
    1942:	9a e7 17 74 19       	call   0x1974:0x17e7
    1947:	8d be fc fd          	lea    di,[bp-0x204]
    194b:	16                   	push   ss
    194c:	57                   	push   di
    194d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1950:	06                   	push   es
    1951:	57                   	push   di
    1952:	9a d5 33 6e 1a       	call   0x1a6e:0x33d5
    1957:	89 c7                	mov    di,ax
    1959:	8e c2                	mov    es,dx
    195b:	06                   	push   es
    195c:	57                   	push   di
    195d:	9a 03 20 79 1a       	call   0x1a79:0x2003
    1962:	8b d0                	mov    dx,ax
    1964:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1968:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    196c:	2d 05 00             	sub    ax,0x5
    196f:	71 05                	jno    0x1976
    1971:	9a 3e 04 a2 19       	call   0x19a2:0x43e
    1976:	3b c2                	cmp    ax,dx
    1978:	b0 00                	mov    al,0x0
    197a:	7e 01                	jle    0x197d
    197c:	40                   	inc    ax
    197d:	8a d0                	mov    dl,al
    197f:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1984:	b0 00                	mov    al,0x0
    1986:	73 01                	jae    0x1989
    1988:	40                   	inc    ax
    1989:	22 c2                	and    al,dl
    198b:	08 c0                	or     al,al
    198d:	74 17                	je     0x19a6
    198f:	bf 66 17             	mov    di,0x1766
    1992:	0e                   	push   cs
    1993:	57                   	push   di
    1994:	8d be fc fd          	lea    di,[bp-0x204]
    1998:	16                   	push   ss
    1999:	57                   	push   di
    199a:	68 ff 00             	push   0xff
    199d:	6a 03                	push   0x3
    199f:	9a 16 19 ba 19       	call   0x19ba:0x1916
    19a4:	eb a1                	jmp    0x1947
    19a6:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    19ab:	76 0f                	jbe    0x19bc
    19ad:	8d be fc fd          	lea    di,[bp-0x204]
    19b1:	16                   	push   ss
    19b2:	57                   	push   di
    19b3:	6a 03                	push   0x3
    19b5:	6a 01                	push   0x1
    19b7:	9a 75 19 e1 19       	call   0x19e1:0x1975
    19bc:	8d be fc fd          	lea    di,[bp-0x204]
    19c0:	16                   	push   ss
    19c1:	57                   	push   di
    19c2:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    19c6:	06                   	push   es
    19c7:	57                   	push   di
    19c8:	9a f9 60 da 19       	call   0x19da:0x60f9
    19cd:	e9 ec 01             	jmp    0x1bbc
    19d0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    19d3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19d6:	bf c8 07             	mov    di,0x7c8
    19d9:	b8 f4 19             	mov    ax,0x19f4
    19dc:	50                   	push   ax
    19dd:	57                   	push   di
    19de:	9a 55 22 fb 19       	call   0x19fb:0x2255
    19e3:	08 c0                	or     al,al
    19e5:	75 03                	jne    0x19ea
    19e7:	e9 d2 01             	jmp    0x1bbc
    19ea:	ff 76 fe             	push   WORD PTR [bp-0x2]
    19ed:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19f0:	bf c8 07             	mov    di,0x7c8
    19f3:	b8 ba 1b             	mov    ax,0x1bba
    19f6:	50                   	push   ax
    19f7:	57                   	push   di
    19f8:	9a 73 22 1a 1a       	call   0x1a1a:0x2273
    19fd:	89 c7                	mov    di,ax
    19ff:	8e c2                	mov    es,dx
    1a01:	89 be f0 fd          	mov    WORD PTR [bp-0x210],di
    1a05:	8c 86 f2 fd          	mov    WORD PTR [bp-0x20e],es
    1a09:	bf 68 17             	mov    di,0x1768
    1a0c:	0e                   	push   cs
    1a0d:	57                   	push   di
    1a0e:	8d be fc fd          	lea    di,[bp-0x204]
    1a12:	16                   	push   ss
    1a13:	57                   	push   di
    1a14:	68 ff 00             	push   0xff
    1a17:	9a e7 17 5e 1a       	call   0x1a5e:0x17e7
    1a1c:	8d be ec fc          	lea    di,[bp-0x314]
    1a20:	16                   	push   ss
    1a21:	57                   	push   di
    1a22:	8d be fc fd          	lea    di,[bp-0x204]
    1a26:	16                   	push   ss
    1a27:	57                   	push   di
    1a28:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1a2c:	06                   	push   es
    1a2d:	57                   	push   di
    1a2e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a31:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1a35:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    1a39:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1a3d:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1a42:	83 ec 0a             	sub    sp,0xa
    1a45:	89 e3                	mov    bx,sp
    1a47:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1a4b:	90                   	nop
    1a4c:	9b                   	fwait
    1a4d:	9a d4 10 dd 1a       	call   0x1add:0x10d4
    1a52:	8d be fc fe          	lea    di,[bp-0x104]
    1a56:	16                   	push   ss
    1a57:	57                   	push   di
    1a58:	68 ff 00             	push   0xff
    1a5b:	9a e7 17 8d 1a       	call   0x1a8d:0x17e7
    1a60:	8d be fc fe          	lea    di,[bp-0x104]
    1a64:	16                   	push   ss
    1a65:	57                   	push   di
    1a66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a69:	06                   	push   es
    1a6a:	57                   	push   di
    1a6b:	9a d5 33 fb 1a       	call   0x1afb:0x33d5
    1a70:	89 c7                	mov    di,ax
    1a72:	8e c2                	mov    es,dx
    1a74:	06                   	push   es
    1a75:	57                   	push   di
    1a76:	9a 03 20 06 1b       	call   0x1b06:0x2003
    1a7b:	8b d0                	mov    dx,ax
    1a7d:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1a81:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1a85:	2d 05 00             	sub    ax,0x5
    1a88:	71 05                	jno    0x1a8f
    1a8a:	9a 3e 04 a7 1a       	call   0x1aa7:0x43e
    1a8f:	3b c2                	cmp    ax,dx
    1a91:	7e 03                	jle    0x1a96
    1a93:	e9 15 01             	jmp    0x1bab
    1a96:	bf 6e 17             	mov    di,0x176e
    1a99:	0e                   	push   cs
    1a9a:	57                   	push   di
    1a9b:	8d be fc fd          	lea    di,[bp-0x204]
    1a9f:	16                   	push   ss
    1aa0:	57                   	push   di
    1aa1:	68 ff 00             	push   0xff
    1aa4:	9a e7 17 eb 1a       	call   0x1aeb:0x17e7
    1aa9:	8d be ec fc          	lea    di,[bp-0x314]
    1aad:	16                   	push   ss
    1aae:	57                   	push   di
    1aaf:	8d be fc fd          	lea    di,[bp-0x204]
    1ab3:	16                   	push   ss
    1ab4:	57                   	push   di
    1ab5:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1ab9:	06                   	push   es
    1aba:	57                   	push   di
    1abb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1abe:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1ac2:	89 86 ec fd          	mov    WORD PTR [bp-0x214],ax
    1ac6:	89 96 ee fd          	mov    WORD PTR [bp-0x212],dx
    1aca:	9b db 86 ec fd       	fild   DWORD PTR [bp-0x214]
    1acf:	83 ec 0a             	sub    sp,0xa
    1ad2:	89 e3                	mov    bx,sp
    1ad4:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1ad8:	90                   	nop
    1ad9:	9b                   	fwait
    1ada:	9a d4 10 df 1d       	call   0x1ddf:0x10d4
    1adf:	8d be fc fe          	lea    di,[bp-0x104]
    1ae3:	16                   	push   ss
    1ae4:	57                   	push   di
    1ae5:	68 ff 00             	push   0xff
    1ae8:	9a e7 17 1a 1b       	call   0x1b1a:0x17e7
    1aed:	8d be fc fe          	lea    di,[bp-0x104]
    1af1:	16                   	push   ss
    1af2:	57                   	push   di
    1af3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1af6:	06                   	push   es
    1af7:	57                   	push   di
    1af8:	9a d5 33 44 1b       	call   0x1b44:0x33d5
    1afd:	89 c7                	mov    di,ax
    1aff:	8e c2                	mov    es,dx
    1b01:	06                   	push   es
    1b02:	57                   	push   di
    1b03:	9a 03 20 4f 1b       	call   0x1b4f:0x2003
    1b08:	8b d0                	mov    dx,ax
    1b0a:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1b0e:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1b12:	2d 05 00             	sub    ax,0x5
    1b15:	71 05                	jno    0x1b1c
    1b17:	9a 3e 04 34 1b       	call   0x1b34:0x43e
    1b1c:	3b c2                	cmp    ax,dx
    1b1e:	7e 03                	jle    0x1b23
    1b20:	e9 88 00             	jmp    0x1bab
    1b23:	bf 5e 17             	mov    di,0x175e
    1b26:	0e                   	push   cs
    1b27:	57                   	push   di
    1b28:	8d be fc fd          	lea    di,[bp-0x204]
    1b2c:	16                   	push   ss
    1b2d:	57                   	push   di
    1b2e:	68 ff 00             	push   0xff
    1b31:	9a e7 17 63 1b       	call   0x1b63:0x17e7
    1b36:	8d be fc fd          	lea    di,[bp-0x204]
    1b3a:	16                   	push   ss
    1b3b:	57                   	push   di
    1b3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b3f:	06                   	push   es
    1b40:	57                   	push   di
    1b41:	9a d5 33 d0 1b       	call   0x1bd0:0x33d5
    1b46:	89 c7                	mov    di,ax
    1b48:	8e c2                	mov    es,dx
    1b4a:	06                   	push   es
    1b4b:	57                   	push   di
    1b4c:	9a 03 20 db 1b       	call   0x1bdb:0x2003
    1b51:	8b d0                	mov    dx,ax
    1b53:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1b57:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1b5b:	2d 05 00             	sub    ax,0x5
    1b5e:	71 05                	jno    0x1b65
    1b60:	9a 3e 04 91 1b       	call   0x1b91:0x43e
    1b65:	3b c2                	cmp    ax,dx
    1b67:	b0 00                	mov    al,0x0
    1b69:	7e 01                	jle    0x1b6c
    1b6b:	40                   	inc    ax
    1b6c:	8a d0                	mov    dl,al
    1b6e:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    1b73:	b0 00                	mov    al,0x0
    1b75:	73 01                	jae    0x1b78
    1b77:	40                   	inc    ax
    1b78:	22 c2                	and    al,dl
    1b7a:	08 c0                	or     al,al
    1b7c:	74 17                	je     0x1b95
    1b7e:	bf 66 17             	mov    di,0x1766
    1b81:	0e                   	push   cs
    1b82:	57                   	push   di
    1b83:	8d be fc fd          	lea    di,[bp-0x204]
    1b87:	16                   	push   ss
    1b88:	57                   	push   di
    1b89:	68 ff 00             	push   0xff
    1b8c:	6a 03                	push   0x3
    1b8e:	9a 16 19 a9 1b       	call   0x1ba9:0x1916
    1b93:	eb a1                	jmp    0x1b36
    1b95:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1b9a:	76 0f                	jbe    0x1bab
    1b9c:	8d be fc fd          	lea    di,[bp-0x204]
    1ba0:	16                   	push   ss
    1ba1:	57                   	push   di
    1ba2:	6a 03                	push   0x3
    1ba4:	6a 01                	push   0x1
    1ba6:	9a 75 19 e9 1b       	call   0x1be9:0x1975
    1bab:	8d be fc fd          	lea    di,[bp-0x204]
    1baf:	16                   	push   ss
    1bb0:	57                   	push   di
    1bb1:	c4 be f0 fd          	les    di,DWORD PTR [bp-0x210]
    1bb5:	06                   	push   es
    1bb6:	57                   	push   di
    1bb7:	9a f9 60 8d 1d       	call   0x1d8d:0x60f9
    1bbc:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1bc0:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1bc4:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1bc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bcb:	06                   	push   es
    1bcc:	57                   	push   di
    1bcd:	9a d5 33 f4 1c       	call   0x1cf4:0x33d5
    1bd2:	89 c7                	mov    di,ax
    1bd4:	8e c2                	mov    es,dx
    1bd6:	06                   	push   es
    1bd7:	57                   	push   di
    1bd8:	9a 99 20 57 1f       	call   0x1f57:0x2099
    1bdd:	c9                   	leave
    1bde:	ca 08 00             	retf   0x8
    1be1:	55                   	push   bp
    1be2:	89 e5                	mov    bp,sp
    1be4:	31 c0                	xor    ax,ax
    1be6:	9a 44 04 fc 1b       	call   0x1bfc:0x444
    1beb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1bee:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1bf1:	bf a2 0b             	mov    di,0xba2
    1bf4:	b8 09 1c             	mov    ax,0x1c09
    1bf7:	50                   	push   ax
    1bf8:	57                   	push   di
    1bf9:	9a 55 22 10 1c       	call   0x1c10:0x2255
    1bfe:	50                   	push   ax
    1bff:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1c02:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1c05:	bf 22 00             	mov    di,0x22
    1c08:	b8 4b 1c             	mov    ax,0x1c4b
    1c0b:	50                   	push   ax
    1c0c:	57                   	push   di
    1c0d:	9a 55 22 36 1c       	call   0x1c36:0x2255
    1c12:	5a                   	pop    dx
    1c13:	0a c2                	or     al,dl
    1c15:	08 c0                	or     al,al
    1c17:	74 11                	je     0x1c2a
    1c19:	6a 00                	push   0x0
    1c1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c1e:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1c23:	06                   	push   es
    1c24:	57                   	push   di
    1c25:	9a 77 1c 7e 1c       	call   0x1c7e:0x1c77
    1c2a:	c9                   	leave
    1c2b:	ca 08 00             	retf   0x8
    1c2e:	55                   	push   bp
    1c2f:	89 e5                	mov    bp,sp
    1c31:	31 c0                	xor    ax,ax
    1c33:	9a 44 04 52 1c       	call   0x1c52:0x444
    1c38:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1c3b:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    1c3f:	75 3f                	jne    0x1c80
    1c41:	ff 76 12             	push   WORD PTR [bp+0x12]
    1c44:	ff 76 10             	push   WORD PTR [bp+0x10]
    1c47:	bf a2 0b             	mov    di,0xba2
    1c4a:	b8 5f 1c             	mov    ax,0x1c5f
    1c4d:	50                   	push   ax
    1c4e:	57                   	push   di
    1c4f:	9a 55 22 66 1c       	call   0x1c66:0x2255
    1c54:	50                   	push   ax
    1c55:	ff 76 12             	push   WORD PTR [bp+0x12]
    1c58:	ff 76 10             	push   WORD PTR [bp+0x10]
    1c5b:	bf 22 00             	mov    di,0x22
    1c5e:	b8 23 1d             	mov    ax,0x1d23
    1c61:	50                   	push   ax
    1c62:	57                   	push   di
    1c63:	9a 55 22 9a 1c       	call   0x1c9a:0x2255
    1c68:	5a                   	pop    dx
    1c69:	0a c2                	or     al,dl
    1c6b:	08 c0                	or     al,al
    1c6d:	74 11                	je     0x1c80
    1c6f:	6a 00                	push   0x0
    1c71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c74:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1c79:	06                   	push   es
    1c7a:	57                   	push   di
    1c7b:	9a 77 1c b3 1c       	call   0x1cb3:0x1c77
    1c80:	c9                   	leave
    1c81:	ca 0e 00             	retf   0xe
    1c84:	0a 23                	or     ah,BYTE PTR [bp+di]
    1c86:	2c 23                	sub    al,0x23
    1c88:	23 30                	and    si,WORD PTR [bx+si]
    1c8a:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    1c8d:	23 23                	and    sp,WORD PTR [bp+di]
    1c8f:	01 20                	add    WORD PTR [bx+si],sp
    1c91:	55                   	push   bp
    1c92:	89 e5                	mov    bp,sp
    1c94:	b8 10 02             	mov    ax,0x210
    1c97:	9a 44 04 ba 1c       	call   0x1cba:0x444
    1c9c:	81 ec 10 02          	sub    sp,0x210
    1ca0:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1ca3:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    1ca7:	75 4d                	jne    0x1cf6
    1ca9:	ff 76 12             	push   WORD PTR [bp+0x12]
    1cac:	ff 76 10             	push   WORD PTR [bp+0x10]
    1caf:	bf c1 05             	mov    di,0x5c1
    1cb2:	b8 d4 1c             	mov    ax,0x1cd4
    1cb5:	50                   	push   ax
    1cb6:	57                   	push   di
    1cb7:	9a 55 22 db 1c       	call   0x1cdb:0x2255
    1cbc:	08 c0                	or     al,al
    1cbe:	74 36                	je     0x1cf6
    1cc0:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1cc3:	31 c0                	xor    ax,ax
    1cc5:	26 89 05             	mov    WORD PTR es:[di],ax
    1cc8:	6a 08                	push   0x8
    1cca:	ff 76 12             	push   WORD PTR [bp+0x12]
    1ccd:	ff 76 10             	push   WORD PTR [bp+0x10]
    1cd0:	bf c1 05             	mov    di,0x5c1
    1cd3:	b8 49 1e             	mov    ax,0x1e49
    1cd6:	50                   	push   ax
    1cd7:	57                   	push   di
    1cd8:	9a 73 22 2a 1d       	call   0x1d2a:0x2273
    1cdd:	89 c7                	mov    di,ax
    1cdf:	8e c2                	mov    es,dx
    1ce1:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    1ce6:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    1ceb:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1cef:	06                   	push   es
    1cf0:	57                   	push   di
    1cf1:	9a b2 77 30 1f       	call   0x1f30:0x77b2
    1cf6:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1cf9:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    1cfd:	74 03                	je     0x1d02
    1cff:	e9 9e 03             	jmp    0x20a0
    1d02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d05:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1d0a:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    1d0f:	74 03                	je     0x1d14
    1d11:	e9 8c 03             	jmp    0x20a0
    1d14:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    1d19:	ff 76 12             	push   WORD PTR [bp+0x12]
    1d1c:	ff 76 10             	push   WORD PTR [bp+0x10]
    1d1f:	bf 22 00             	mov    di,0x22
    1d22:	b8 3d 1d             	mov    ax,0x1d3d
    1d25:	50                   	push   ax
    1d26:	57                   	push   di
    1d27:	9a 55 22 44 1d       	call   0x1d44:0x2255
    1d2c:	08 c0                	or     al,al
    1d2e:	75 03                	jne    0x1d33
    1d30:	e9 1e 01             	jmp    0x1e51
    1d33:	ff 76 12             	push   WORD PTR [bp+0x12]
    1d36:	ff 76 10             	push   WORD PTR [bp+0x10]
    1d39:	bf 22 00             	mov    di,0x22
    1d3c:	b8 61 1d             	mov    ax,0x1d61
    1d3f:	50                   	push   ax
    1d40:	57                   	push   di
    1d41:	9a 73 22 94 1d       	call   0x1d94:0x2273
    1d46:	89 c7                	mov    di,ax
    1d48:	8e c2                	mov    es,dx
    1d4a:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1d4e:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1d52:	8d be f4 fd          	lea    di,[bp-0x20c]
    1d56:	16                   	push   ss
    1d57:	57                   	push   di
    1d58:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1d5c:	06                   	push   es
    1d5d:	57                   	push   di
    1d5e:	9a 9f 1a 6c 1d       	call   0x1d6c:0x1a9f
    1d63:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1d67:	06                   	push   es
    1d68:	57                   	push   di
    1d69:	9a 5f 1a 5b 1e       	call   0x1e5b:0x1a5f
    1d6e:	89 c7                	mov    di,ax
    1d70:	8e c2                	mov    es,dx
    1d72:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1d76:	06                   	push   es
    1d77:	57                   	push   di
    1d78:	9a 9b 3b 4d 21       	call   0x214d:0x3b9b
    1d7d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1d80:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1d83:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1d86:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1d89:	bf 58 0a             	mov    di,0xa58
    1d8c:	b8 a4 1d             	mov    ax,0x1da4
    1d8f:	50                   	push   ax
    1d90:	57                   	push   di
    1d91:	9a 55 22 ab 1d       	call   0x1dab:0x2255
    1d96:	08 c0                	or     al,al
    1d98:	74 57                	je     0x1df1
    1d9a:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1d9d:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1da0:	bf 58 0a             	mov    di,0xa58
    1da3:	b8 59 21             	mov    ax,0x2159
    1da6:	50                   	push   ax
    1da7:	57                   	push   di
    1da8:	9a 73 22 ed 1d       	call   0x1ded:0x2273
    1dad:	89 c7                	mov    di,ax
    1daf:	8e c2                	mov    es,dx
    1db1:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    1db5:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    1db9:	8d be f0 fd          	lea    di,[bp-0x210]
    1dbd:	16                   	push   ss
    1dbe:	57                   	push   di
    1dbf:	bf 84 1c             	mov    di,0x1c84
    1dc2:	0e                   	push   cs
    1dc3:	57                   	push   di
    1dc4:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    1dc8:	06                   	push   es
    1dc9:	57                   	push   di
    1dca:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1dcd:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    1dd1:	83 ec 0a             	sub    sp,0xa
    1dd4:	89 e3                	mov    bx,sp
    1dd6:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1dda:	90                   	nop
    1ddb:	9b                   	fwait
    1ddc:	9a d4 10 36 24       	call   0x2436:0x10d4
    1de1:	8d be f8 fe          	lea    di,[bp-0x108]
    1de5:	16                   	push   ss
    1de6:	57                   	push   di
    1de7:	68 ff 00             	push   0xff
    1dea:	9a e7 17 0e 1e       	call   0x1e0e:0x17e7
    1def:	eb 1f                	jmp    0x1e10
    1df1:	8d be f4 fd          	lea    di,[bp-0x20c]
    1df5:	16                   	push   ss
    1df6:	57                   	push   di
    1df7:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1dfb:	06                   	push   es
    1dfc:	57                   	push   di
    1dfd:	9a 24 15 01 55       	call   0x5501:0x1524
    1e02:	8d be f8 fe          	lea    di,[bp-0x108]
    1e06:	16                   	push   ss
    1e07:	57                   	push   di
    1e08:	68 ff 00             	push   0xff
    1e0b:	9a e7 17 20 1e       	call   0x1e20:0x17e7
    1e10:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e14:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1e18:	2d 04 00             	sub    ax,0x4
    1e1b:	71 05                	jno    0x1e22
    1e1d:	9a 3e 04 35 1e       	call   0x1e35:0x43e
    1e22:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1e25:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e29:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1e2d:	2d 04 00             	sub    ax,0x4
    1e30:	71 05                	jno    0x1e37
    1e32:	9a 3e 04 62 1e       	call   0x1e62:0x43e
    1e37:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e3a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1e3d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1e40:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e44:	06                   	push   es
    1e45:	57                   	push   di
    1e46:	9a d4 19 99 1e       	call   0x1e99:0x19d4
    1e4b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1e4e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1e51:	ff 76 12             	push   WORD PTR [bp+0x12]
    1e54:	ff 76 10             	push   WORD PTR [bp+0x10]
    1e57:	bf a2 0b             	mov    di,0xba2
    1e5a:	b8 75 1e             	mov    ax,0x1e75
    1e5d:	50                   	push   ax
    1e5e:	57                   	push   di
    1e5f:	9a 55 22 7c 1e       	call   0x1e7c:0x2255
    1e64:	08 c0                	or     al,al
    1e66:	75 03                	jne    0x1e6b
    1e68:	e9 7f 00             	jmp    0x1eea
    1e6b:	ff 76 12             	push   WORD PTR [bp+0x12]
    1e6e:	ff 76 10             	push   WORD PTR [bp+0x10]
    1e71:	bf a2 0b             	mov    di,0xba2
    1e74:	b8 eb 20             	mov    ax,0x20eb
    1e77:	50                   	push   ax
    1e78:	57                   	push   di
    1e79:	9a 73 22 a7 1e       	call   0x1ea7:0x2273
    1e7e:	89 c7                	mov    di,ax
    1e80:	8e c2                	mov    es,dx
    1e82:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1e86:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1e8a:	8d be f4 fd          	lea    di,[bp-0x20c]
    1e8e:	16                   	push   ss
    1e8f:	57                   	push   di
    1e90:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1e94:	06                   	push   es
    1e95:	57                   	push   di
    1e96:	9a 53 1d e2 1e       	call   0x1ee2:0x1d53
    1e9b:	8d be f8 fe          	lea    di,[bp-0x108]
    1e9f:	16                   	push   ss
    1ea0:	57                   	push   di
    1ea1:	68 ff 00             	push   0xff
    1ea4:	9a e7 17 b9 1e       	call   0x1eb9:0x17e7
    1ea9:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1ead:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1eb1:	2d 04 00             	sub    ax,0x4
    1eb4:	71 05                	jno    0x1ebb
    1eb6:	9a 3e 04 ce 1e       	call   0x1ece:0x43e
    1ebb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1ebe:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1ec2:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    1ec6:	2d 04 00             	sub    ax,0x4
    1ec9:	71 05                	jno    0x1ed0
    1ecb:	9a 3e 04 02 1f       	call   0x1f02:0x43e
    1ed0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ed3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ed6:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ed9:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1edd:	06                   	push   es
    1ede:	57                   	push   di
    1edf:	9a d4 19 26 1f       	call   0x1f26:0x19d4
    1ee4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1ee7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1eea:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    1eef:	77 03                	ja     0x1ef4
    1ef1:	e9 ac 01             	jmp    0x20a0
    1ef4:	8d be f8 fd          	lea    di,[bp-0x208]
    1ef8:	16                   	push   ss
    1ef9:	57                   	push   di
    1efa:	bf 8f 1c             	mov    di,0x1c8f
    1efd:	0e                   	push   cs
    1efe:	57                   	push   di
    1eff:	9a cd 17 0d 1f       	call   0x1f0d:0x17cd
    1f04:	8d be f8 fe          	lea    di,[bp-0x108]
    1f08:	16                   	push   ss
    1f09:	57                   	push   di
    1f0a:	9a 4c 18 17 1f       	call   0x1f17:0x184c
    1f0f:	bf 8f 1c             	mov    di,0x1c8f
    1f12:	0e                   	push   cs
    1f13:	57                   	push   di
    1f14:	9a 4c 18 b3 1f       	call   0x1fb3:0x184c
    1f19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f1c:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1f21:	06                   	push   es
    1f22:	57                   	push   di
    1f23:	9a 8c 1d 6c 1f       	call   0x1f6c:0x1d8c
    1f28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f2b:	06                   	push   es
    1f2c:	57                   	push   di
    1f2d:	9a d5 33 a0 2d       	call   0x2da0:0x33d5
    1f32:	89 c7                	mov    di,ax
    1f34:	8e c2                	mov    es,dx
    1f36:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1f3a:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1f3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f41:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1f46:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1f4a:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1f4e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f52:	06                   	push   es
    1f53:	57                   	push   di
    1f54:	9a 99 20 77 1f       	call   0x1f77:0x2099
    1f59:	8d be f4 fd          	lea    di,[bp-0x20c]
    1f5d:	16                   	push   ss
    1f5e:	57                   	push   di
    1f5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f62:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1f67:	06                   	push   es
    1f68:	57                   	push   di
    1f69:	9a 53 1d 87 1f       	call   0x1f87:0x1d53
    1f6e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1f72:	06                   	push   es
    1f73:	57                   	push   di
    1f74:	9a 03 20 a7 1f       	call   0x1fa7:0x2003
    1f79:	50                   	push   ax
    1f7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f7d:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1f82:	06                   	push   es
    1f83:	57                   	push   di
    1f84:	9a bf 17 9c 1f       	call   0x1f9c:0x17bf
    1f89:	8d be f4 fd          	lea    di,[bp-0x20c]
    1f8d:	16                   	push   ss
    1f8e:	57                   	push   di
    1f8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f92:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1f97:	06                   	push   es
    1f98:	57                   	push   di
    1f99:	9a 53 1d c9 1f       	call   0x1fc9:0x1d53
    1f9e:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    1fa2:	06                   	push   es
    1fa3:	57                   	push   di
    1fa4:	9a 4e 20 aa 4d       	call   0x4daa:0x204e
    1fa9:	b9 03 00             	mov    cx,0x3
    1fac:	f7 e9                	imul   cx
    1fae:	71 05                	jno    0x1fb5
    1fb0:	9a 3e 04 26 20       	call   0x2026:0x43e
    1fb5:	99                   	cwd
    1fb6:	b9 02 00             	mov    cx,0x2
    1fb9:	f7 f9                	idiv   cx
    1fbb:	50                   	push   ax
    1fbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fbf:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1fc4:	06                   	push   es
    1fc5:	57                   	push   di
    1fc6:	9a e1 17 d9 1f       	call   0x1fd9:0x17e1
    1fcb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fce:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1fd1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fd4:	06                   	push   es
    1fd5:	57                   	push   di
    1fd6:	9a 06 1a f9 1f       	call   0x1ff9:0x1a06
    1fdb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1fde:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1fe1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fe4:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    1fe9:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    1fed:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    1ff1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ff4:	06                   	push   es
    1ff5:	57                   	push   di
    1ff6:	9a 7b 17 07 20       	call   0x2007:0x177b
    1ffb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ffe:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2002:	06                   	push   es
    2003:	57                   	push   di
    2004:	9a 9d 17 11 20       	call   0x2011:0x179d
    2009:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    200c:	06                   	push   es
    200d:	57                   	push   di
    200e:	9a a9 18 48 20       	call   0x2048:0x18a9
    2013:	8b d0                	mov    dx,ax
    2015:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2019:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    201d:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    2021:	71 05                	jno    0x2028
    2023:	9a 3e 04 3c 20       	call   0x203c:0x43e
    2028:	3b c2                	cmp    ax,dx
    202a:	7e 20                	jle    0x204c
    202c:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2030:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2034:	2d 08 00             	sub    ax,0x8
    2037:	71 05                	jno    0x203e
    2039:	9a 3e 04 69 20       	call   0x2069:0x43e
    203e:	50                   	push   ax
    203f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2043:	06                   	push   es
    2044:	57                   	push   di
    2045:	9a 7b 17 54 20       	call   0x2054:0x177b
    204a:	eb bd                	jmp    0x2009
    204c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    204f:	06                   	push   es
    2050:	57                   	push   di
    2051:	9a f4 18 8b 20       	call   0x208b:0x18f4
    2056:	8b d0                	mov    dx,ax
    2058:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    205c:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2060:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    2064:	71 05                	jno    0x206b
    2066:	9a 3e 04 7f 20       	call   0x207f:0x43e
    206b:	3b c2                	cmp    ax,dx
    206d:	7e 20                	jle    0x208f
    206f:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2073:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    2077:	2d 08 00             	sub    ax,0x8
    207a:	71 05                	jno    0x2081
    207c:	9a 3e 04 ad 20       	call   0x20ad:0x43e
    2081:	50                   	push   ax
    2082:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2086:	06                   	push   es
    2087:	57                   	push   di
    2088:	9a 9d 17 9e 20       	call   0x209e:0x179d
    208d:	eb bd                	jmp    0x204c
    208f:	6a 01                	push   0x1
    2091:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2094:	26 c4 bd 3c 02       	les    di,DWORD PTR es:[di+0x23c]
    2099:	06                   	push   es
    209a:	57                   	push   di
    209b:	9a 77 1c 45 24       	call   0x2445:0x1c77
    20a0:	c9                   	leave
    20a1:	ca 0e 00             	retf   0xe
    20a4:	55                   	push   bp
    20a5:	89 e5                	mov    bp,sp
    20a7:	b8 04 00             	mov    ax,0x4
    20aa:	9a 44 04 c4 20       	call   0x20c4:0x444
    20af:	83 ec 04             	sub    sp,0x4
    20b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20b5:	06                   	push   es
    20b6:	57                   	push   di
    20b7:	9a 7d 52 e3 20       	call   0x20e3:0x527d
    20bc:	2d 01 00             	sub    ax,0x1
    20bf:	71 05                	jno    0x20c6
    20c1:	9a 3e 04 f2 20       	call   0x20f2:0x43e
    20c6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    20c9:	31 c0                	xor    ax,ax
    20cb:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    20ce:	7f 58                	jg     0x2128
    20d0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    20d3:	eb 03                	jmp    0x20d8
    20d5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    20d8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20de:	06                   	push   es
    20df:	57                   	push   di
    20e0:	9a 46 52 03 21       	call   0x2103:0x5246
    20e5:	52                   	push   dx
    20e6:	50                   	push   ax
    20e7:	bf 22 00             	mov    di,0x22
    20ea:	b8 0b 21             	mov    ax,0x210b
    20ed:	50                   	push   ax
    20ee:	57                   	push   di
    20ef:	9a 55 22 12 21       	call   0x2112:0x2255
    20f4:	08 c0                	or     al,al
    20f6:	74 28                	je     0x2120
    20f8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20fe:	06                   	push   es
    20ff:	57                   	push   di
    2100:	9a 46 52 bb 2d       	call   0x2dbb:0x5246
    2105:	52                   	push   dx
    2106:	50                   	push   ax
    2107:	bf 22 00             	mov    di,0x22
    210a:	b8 c3 54             	mov    ax,0x54c3
    210d:	50                   	push   ax
    210e:	57                   	push   di
    210f:	9a 73 22 35 21       	call   0x2135:0x2273
    2114:	52                   	push   dx
    2115:	50                   	push   ax
    2116:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2119:	06                   	push   es
    211a:	57                   	push   di
    211b:	9a 71 17 78 26       	call   0x2678:0x1771
    2120:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2123:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2126:	75 ad                	jne    0x20d5
    2128:	c9                   	leave
    2129:	ca 04 00             	retf   0x4
    212c:	55                   	push   bp
    212d:	89 e5                	mov    bp,sp
    212f:	b8 04 00             	mov    ax,0x4
    2132:	9a 44 04 1c 24       	call   0x241c:0x444
    2137:	83 ec 04             	sub    sp,0x4
    213a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    213d:	26 c4 bd 18 02       	les    di,DWORD PTR es:[di+0x218]
    2142:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2145:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2148:	06                   	push   es
    2149:	57                   	push   di
    214a:	9a d2 31 6f 21       	call   0x216f:0x31d2
    214f:	6a 01                	push   0x1
    2151:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2154:	06                   	push   es
    2155:	57                   	push   di
    2156:	9a fb 2f 65 21       	call   0x2165:0x2ffb
    215b:	6a 00                	push   0x0
    215d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2160:	06                   	push   es
    2161:	57                   	push   di
    2162:	9a d2 2e 90 21       	call   0x2190:0x2ed2
    2167:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    216a:	06                   	push   es
    216b:	57                   	push   di
    216c:	9a bf 31 84 21       	call   0x2184:0x31bf
    2171:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2174:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2179:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    217c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    217f:	06                   	push   es
    2180:	57                   	push   di
    2181:	9a d2 31 a6 21       	call   0x21a6:0x31d2
    2186:	6a 01                	push   0x1
    2188:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    218b:	06                   	push   es
    218c:	57                   	push   di
    218d:	9a fb 2f 9c 21       	call   0x219c:0x2ffb
    2192:	6a 00                	push   0x0
    2194:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2197:	06                   	push   es
    2198:	57                   	push   di
    2199:	9a d2 2e c7 21       	call   0x21c7:0x2ed2
    219e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21a1:	06                   	push   es
    21a2:	57                   	push   di
    21a3:	9a bf 31 bb 21       	call   0x21bb:0x31bf
    21a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ab:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    21b0:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    21b3:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    21b6:	06                   	push   es
    21b7:	57                   	push   di
    21b8:	9a d2 31 dd 21       	call   0x21dd:0x31d2
    21bd:	6a 01                	push   0x1
    21bf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21c2:	06                   	push   es
    21c3:	57                   	push   di
    21c4:	9a fb 2f d3 21       	call   0x21d3:0x2ffb
    21c9:	6a 00                	push   0x0
    21cb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21ce:	06                   	push   es
    21cf:	57                   	push   di
    21d0:	9a d2 2e fe 21       	call   0x21fe:0x2ed2
    21d5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21d8:	06                   	push   es
    21d9:	57                   	push   di
    21da:	9a bf 31 f2 21       	call   0x21f2:0x31bf
    21df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21e2:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    21e7:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    21ea:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    21ed:	06                   	push   es
    21ee:	57                   	push   di
    21ef:	9a d2 31 14 22       	call   0x2214:0x31d2
    21f4:	6a 01                	push   0x1
    21f6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21f9:	06                   	push   es
    21fa:	57                   	push   di
    21fb:	9a fb 2f 0a 22       	call   0x220a:0x2ffb
    2200:	6a 00                	push   0x0
    2202:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2205:	06                   	push   es
    2206:	57                   	push   di
    2207:	9a d2 2e 35 22       	call   0x2235:0x2ed2
    220c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    220f:	06                   	push   es
    2210:	57                   	push   di
    2211:	9a bf 31 29 22       	call   0x2229:0x31bf
    2216:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2219:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    221e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2221:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2224:	06                   	push   es
    2225:	57                   	push   di
    2226:	9a d2 31 4b 22       	call   0x224b:0x31d2
    222b:	6a 01                	push   0x1
    222d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2230:	06                   	push   es
    2231:	57                   	push   di
    2232:	9a fb 2f 41 22       	call   0x2241:0x2ffb
    2237:	6a 00                	push   0x0
    2239:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    223c:	06                   	push   es
    223d:	57                   	push   di
    223e:	9a d2 2e 6c 22       	call   0x226c:0x2ed2
    2243:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2246:	06                   	push   es
    2247:	57                   	push   di
    2248:	9a bf 31 60 22       	call   0x2260:0x31bf
    224d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2250:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    2255:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2258:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    225b:	06                   	push   es
    225c:	57                   	push   di
    225d:	9a d2 31 82 22       	call   0x2282:0x31d2
    2262:	6a 01                	push   0x1
    2264:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2267:	06                   	push   es
    2268:	57                   	push   di
    2269:	9a fb 2f 78 22       	call   0x2278:0x2ffb
    226e:	6a 00                	push   0x0
    2270:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2273:	06                   	push   es
    2274:	57                   	push   di
    2275:	9a d2 2e a3 22       	call   0x22a3:0x2ed2
    227a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    227d:	06                   	push   es
    227e:	57                   	push   di
    227f:	9a bf 31 97 22       	call   0x2297:0x31bf
    2284:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2287:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    228c:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    228f:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2292:	06                   	push   es
    2293:	57                   	push   di
    2294:	9a d2 31 b9 22       	call   0x22b9:0x31d2
    2299:	6a 01                	push   0x1
    229b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    229e:	06                   	push   es
    229f:	57                   	push   di
    22a0:	9a fb 2f af 22       	call   0x22af:0x2ffb
    22a5:	6a 00                	push   0x0
    22a7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22aa:	06                   	push   es
    22ab:	57                   	push   di
    22ac:	9a d2 2e da 22       	call   0x22da:0x2ed2
    22b1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22b4:	06                   	push   es
    22b5:	57                   	push   di
    22b6:	9a bf 31 ce 22       	call   0x22ce:0x31bf
    22bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22be:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    22c3:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    22c6:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    22c9:	06                   	push   es
    22ca:	57                   	push   di
    22cb:	9a d2 31 f0 22       	call   0x22f0:0x31d2
    22d0:	6a 01                	push   0x1
    22d2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22d5:	06                   	push   es
    22d6:	57                   	push   di
    22d7:	9a fb 2f e6 22       	call   0x22e6:0x2ffb
    22dc:	6a 00                	push   0x0
    22de:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22e1:	06                   	push   es
    22e2:	57                   	push   di
    22e3:	9a d2 2e 11 23       	call   0x2311:0x2ed2
    22e8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    22eb:	06                   	push   es
    22ec:	57                   	push   di
    22ed:	9a bf 31 05 23       	call   0x2305:0x31bf
    22f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22f5:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    22fa:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    22fd:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2300:	06                   	push   es
    2301:	57                   	push   di
    2302:	9a d2 31 27 23       	call   0x2327:0x31d2
    2307:	6a 01                	push   0x1
    2309:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    230c:	06                   	push   es
    230d:	57                   	push   di
    230e:	9a fb 2f 1d 23       	call   0x231d:0x2ffb
    2313:	6a 00                	push   0x0
    2315:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2318:	06                   	push   es
    2319:	57                   	push   di
    231a:	9a d2 2e 48 23       	call   0x2348:0x2ed2
    231f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2322:	06                   	push   es
    2323:	57                   	push   di
    2324:	9a bf 31 3c 23       	call   0x233c:0x31bf
    2329:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    232c:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    2331:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2334:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2337:	06                   	push   es
    2338:	57                   	push   di
    2339:	9a d2 31 5e 23       	call   0x235e:0x31d2
    233e:	6a 01                	push   0x1
    2340:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2343:	06                   	push   es
    2344:	57                   	push   di
    2345:	9a fb 2f 54 23       	call   0x2354:0x2ffb
    234a:	6a 00                	push   0x0
    234c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    234f:	06                   	push   es
    2350:	57                   	push   di
    2351:	9a d2 2e 7f 23       	call   0x237f:0x2ed2
    2356:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2359:	06                   	push   es
    235a:	57                   	push   di
    235b:	9a bf 31 73 23       	call   0x2373:0x31bf
    2360:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2363:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    2368:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    236b:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    236e:	06                   	push   es
    236f:	57                   	push   di
    2370:	9a d2 31 95 23       	call   0x2395:0x31d2
    2375:	6a 01                	push   0x1
    2377:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    237a:	06                   	push   es
    237b:	57                   	push   di
    237c:	9a fb 2f 8b 23       	call   0x238b:0x2ffb
    2381:	6a 00                	push   0x0
    2383:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2386:	06                   	push   es
    2387:	57                   	push   di
    2388:	9a d2 2e b6 23       	call   0x23b6:0x2ed2
    238d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2390:	06                   	push   es
    2391:	57                   	push   di
    2392:	9a bf 31 aa 23       	call   0x23aa:0x31bf
    2397:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    239a:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    239f:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    23a2:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    23a5:	06                   	push   es
    23a6:	57                   	push   di
    23a7:	9a d2 31 cc 23       	call   0x23cc:0x31d2
    23ac:	6a 01                	push   0x1
    23ae:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23b1:	06                   	push   es
    23b2:	57                   	push   di
    23b3:	9a fb 2f c2 23       	call   0x23c2:0x2ffb
    23b8:	6a 00                	push   0x0
    23ba:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23bd:	06                   	push   es
    23be:	57                   	push   di
    23bf:	9a d2 2e ed 23       	call   0x23ed:0x2ed2
    23c4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23c7:	06                   	push   es
    23c8:	57                   	push   di
    23c9:	9a bf 31 e1 23       	call   0x23e1:0x31bf
    23ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d1:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    23d6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    23d9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    23dc:	06                   	push   es
    23dd:	57                   	push   di
    23de:	9a d2 31 03 24       	call   0x2403:0x31d2
    23e3:	6a 01                	push   0x1
    23e5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23e8:	06                   	push   es
    23e9:	57                   	push   di
    23ea:	9a fb 2f f9 23       	call   0x23f9:0x2ffb
    23ef:	6a 00                	push   0x0
    23f1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23f4:	06                   	push   es
    23f5:	57                   	push   di
    23f6:	9a d2 2e 6a 26       	call   0x266a:0x2ed2
    23fb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    23fe:	06                   	push   es
    23ff:	57                   	push   di
    2400:	9a bf 31 4d 2b       	call   0x2b4d:0x31bf
    2405:	c9                   	leave
    2406:	ca 04 00             	retf   0x4
    2409:	01 23                	add    WORD PTR [bp+di],sp
    240b:	00 00                	add    BYTE PTR [bx+si],al
    240d:	00 00                	add    BYTE PTR [bx+si],al
    240f:	ff 00                	inc    WORD PTR [bx+si]
    2411:	00 00                	add    BYTE PTR [bx+si],al
    2413:	55                   	push   bp
    2414:	89 e5                	mov    bp,sp
    2416:	b8 02 02             	mov    ax,0x202
    2419:	9a 44 04 81 24       	call   0x2481:0x444
    241e:	81 ec 02 02          	sub    sp,0x202
    2422:	8d be fe fd          	lea    di,[bp-0x202]
    2426:	16                   	push   ss
    2427:	57                   	push   di
    2428:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    242b:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    2430:	99                   	cwd
    2431:	52                   	push   dx
    2432:	50                   	push   ax
    2433:	9a a9 08 5b 24       	call   0x245b:0x8a9
    2438:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    243b:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    2440:	06                   	push   es
    2441:	57                   	push   di
    2442:	9a 8c 1d 6a 24       	call   0x246a:0x1d8c
    2447:	8d be fe fd          	lea    di,[bp-0x202]
    244b:	16                   	push   ss
    244c:	57                   	push   di
    244d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2450:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    2455:	99                   	cwd
    2456:	52                   	push   dx
    2457:	50                   	push   ax
    2458:	9a a9 08 cc 24       	call   0x24cc:0x8a9
    245d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2460:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    2465:	06                   	push   es
    2466:	57                   	push   di
    2467:	9a 8c 1d 4f 25       	call   0x254f:0x1d8c
    246c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    246f:	81 c7 96 05          	add    di,0x596
    2473:	06                   	push   es
    2474:	57                   	push   di
    2475:	8d be fe fe          	lea    di,[bp-0x102]
    2479:	16                   	push   ss
    247a:	57                   	push   di
    247b:	68 ff 00             	push   0xff
    247e:	9a e7 17 91 24       	call   0x2491:0x17e7
    2483:	bf 09 24             	mov    di,0x2409
    2486:	0e                   	push   cs
    2487:	57                   	push   di
    2488:	8d be fe fe          	lea    di,[bp-0x102]
    248c:	16                   	push   ss
    248d:	57                   	push   di
    248e:	9a 78 18 9a 24       	call   0x249a:0x1878
    2493:	99                   	cwd
    2494:	bf 0b 24             	mov    di,0x240b
    2497:	9a 16 04 b6 24       	call   0x24b6:0x416
    249c:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    249f:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    24a3:	76 3d                	jbe    0x24e2
    24a5:	8d be fe fe          	lea    di,[bp-0x102]
    24a9:	16                   	push   ss
    24aa:	57                   	push   di
    24ab:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    24ae:	30 e4                	xor    ah,ah
    24b0:	50                   	push   ax
    24b1:	6a 01                	push   0x1
    24b3:	9a 75 19 e0 24       	call   0x24e0:0x1975
    24b8:	8d be fe fd          	lea    di,[bp-0x202]
    24bc:	16                   	push   ss
    24bd:	57                   	push   di
    24be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24c1:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    24c6:	99                   	cwd
    24c7:	52                   	push   dx
    24c8:	50                   	push   ax
    24c9:	9a a9 08 2b 25       	call   0x252b:0x8a9
    24ce:	8d be fe fe          	lea    di,[bp-0x102]
    24d2:	16                   	push   ss
    24d3:	57                   	push   di
    24d4:	68 ff 00             	push   0xff
    24d7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    24da:	30 e4                	xor    ah,ah
    24dc:	50                   	push   ax
    24dd:	9a 16 19 f0 24       	call   0x24f0:0x1916
    24e2:	bf 09 24             	mov    di,0x2409
    24e5:	0e                   	push   cs
    24e6:	57                   	push   di
    24e7:	8d be fe fe          	lea    di,[bp-0x102]
    24eb:	16                   	push   ss
    24ec:	57                   	push   di
    24ed:	9a 78 18 f9 24       	call   0x24f9:0x1878
    24f2:	99                   	cwd
    24f3:	bf 0b 24             	mov    di,0x240b
    24f6:	9a 16 04 15 25       	call   0x2515:0x416
    24fb:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    24fe:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2502:	76 3d                	jbe    0x2541
    2504:	8d be fe fe          	lea    di,[bp-0x102]
    2508:	16                   	push   ss
    2509:	57                   	push   di
    250a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    250d:	30 e4                	xor    ah,ah
    250f:	50                   	push   ax
    2510:	6a 01                	push   0x1
    2512:	9a 75 19 3f 25       	call   0x253f:0x1975
    2517:	8d be fe fd          	lea    di,[bp-0x202]
    251b:	16                   	push   ss
    251c:	57                   	push   di
    251d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2520:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    2525:	99                   	cwd
    2526:	52                   	push   dx
    2527:	50                   	push   ax
    2528:	9a a9 08 13 2f       	call   0x2f13:0x8a9
    252d:	8d be fe fe          	lea    di,[bp-0x102]
    2531:	16                   	push   ss
    2532:	57                   	push   di
    2533:	68 ff 00             	push   0xff
    2536:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2539:	30 e4                	xor    ah,ah
    253b:	50                   	push   ax
    253c:	9a 16 19 77 25       	call   0x2577:0x1916
    2541:	8d be fe fe          	lea    di,[bp-0x102]
    2545:	16                   	push   ss
    2546:	57                   	push   di
    2547:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    254a:	06                   	push   es
    254b:	57                   	push   di
    254c:	9a 8c 1d 98 2c       	call   0x2c98:0x1d8c
    2551:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2554:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    2559:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    255d:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2561:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2565:	eb 03                	jmp    0x256a
    2567:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    256a:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    256d:	30 e4                	xor    ah,ah
    256f:	05 01 00             	add    ax,0x1
    2572:	71 05                	jno    0x2579
    2574:	9a 3e 04 c8 25       	call   0x25c8:0x43e
    2579:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    257c:	26 3b 85 92 05       	cmp    ax,WORD PTR es:[di+0x592]
    2581:	b0 00                	mov    al,0x0
    2583:	75 01                	jne    0x2586
    2585:	40                   	inc    ax
    2586:	50                   	push   ax
    2587:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    258a:	30 e4                	xor    ah,ah
    258c:	50                   	push   ax
    258d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2591:	06                   	push   es
    2592:	57                   	push   di
    2593:	9a 53 13 a1 25       	call   0x25a1:0x1353
    2598:	89 c7                	mov    di,ax
    259a:	8e c2                	mov    es,dx
    259c:	06                   	push   es
    259d:	57                   	push   di
    259e:	9a 75 12 be 25       	call   0x25be:0x1275
    25a3:	80 7e ff 13          	cmp    BYTE PTR [bp-0x1],0x13
    25a7:	75 be                	jne    0x2567
    25a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25ac:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    25b1:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    25b5:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    25b9:	06                   	push   es
    25ba:	57                   	push   di
    25bb:	9a 26 13 13 26       	call   0x2613:0x1326
    25c0:	2d 01 00             	sub    ax,0x1
    25c3:	71 05                	jno    0x25ca
    25c5:	9a 3e 04 d1 25       	call   0x25d1:0x43e
    25ca:	99                   	cwd
    25cb:	bf 0b 24             	mov    di,0x240b
    25ce:	9a 16 04 f4 25       	call   0x25f4:0x416
    25d3:	88 86 f9 fe          	mov    BYTE PTR [bp-0x107],al
    25d7:	b0 00                	mov    al,0x0
    25d9:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    25dd:	77 4a                	ja     0x2629
    25df:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    25e2:	eb 03                	jmp    0x25e7
    25e4:	fe 46 ff             	inc    BYTE PTR [bp-0x1]
    25e7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    25ea:	30 e4                	xor    ah,ah
    25ec:	05 01 00             	add    ax,0x1
    25ef:	71 05                	jno    0x25f6
    25f1:	9a 3e 04 49 26       	call   0x2649:0x43e
    25f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f9:	26 3b 85 94 05       	cmp    ax,WORD PTR es:[di+0x594]
    25fe:	b0 00                	mov    al,0x0
    2600:	75 01                	jne    0x2603
    2602:	40                   	inc    ax
    2603:	50                   	push   ax
    2604:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2607:	30 e4                	xor    ah,ah
    2609:	50                   	push   ax
    260a:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    260e:	06                   	push   es
    260f:	57                   	push   di
    2610:	9a 53 13 1e 26       	call   0x261e:0x1353
    2615:	89 c7                	mov    di,ax
    2617:	8e c2                	mov    es,dx
    2619:	06                   	push   es
    261a:	57                   	push   di
    261b:	9a 75 12 f0 2c       	call   0x2cf0:0x1275
    2620:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2623:	3a 86 f9 fe          	cmp    al,BYTE PTR [bp-0x107]
    2627:	75 bb                	jne    0x25e4
    2629:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    262c:	26 c4 bd 18 02       	les    di,DWORD PTR es:[di+0x218]
    2631:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2635:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2639:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    263c:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    2641:	2d 01 00             	sub    ax,0x1
    2644:	71 05                	jno    0x264b
    2646:	9a 3e 04 91 27       	call   0x2791:0x43e
    264b:	99                   	cwd
    264c:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2650:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    2654:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2659:	8d be f2 fe          	lea    di,[bp-0x10e]
    265d:	16                   	push   ss
    265e:	57                   	push   di
    265f:	6a 00                	push   0x0
    2661:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2665:	06                   	push   es
    2666:	57                   	push   di
    2667:	9a 95 28 b1 26       	call   0x26b1:0x2895
    266c:	08 c0                	or     al,al
    266e:	75 0a                	jne    0x267a
    2670:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2673:	06                   	push   es
    2674:	57                   	push   di
    2675:	9a 08 14 bf 26       	call   0x26bf:0x1408
    267a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    267d:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2682:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2686:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    268a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    268d:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    2692:	99                   	cwd
    2693:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2697:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    269b:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    26a0:	8d be f2 fe          	lea    di,[bp-0x10e]
    26a4:	16                   	push   ss
    26a5:	57                   	push   di
    26a6:	6a 00                	push   0x0
    26a8:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    26ac:	06                   	push   es
    26ad:	57                   	push   di
    26ae:	9a 95 28 09 27       	call   0x2709:0x2895
    26b3:	08 c0                	or     al,al
    26b5:	75 0a                	jne    0x26c1
    26b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ba:	06                   	push   es
    26bb:	57                   	push   di
    26bc:	9a 08 14 17 27       	call   0x2717:0x1408
    26c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c4:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    26c9:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    26cd:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    26d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26d4:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    26d9:	99                   	cwd
    26da:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    26de:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    26e2:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    26e7:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    26ed:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    26f3:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    26f8:	8d be ea fe          	lea    di,[bp-0x116]
    26fc:	16                   	push   ss
    26fd:	57                   	push   di
    26fe:	6a 01                	push   0x1
    2700:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2704:	06                   	push   es
    2705:	57                   	push   di
    2706:	9a 95 28 61 27       	call   0x2761:0x2895
    270b:	08 c0                	or     al,al
    270d:	75 0a                	jne    0x2719
    270f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2712:	06                   	push   es
    2713:	57                   	push   di
    2714:	9a 08 14 6f 27       	call   0x276f:0x1408
    2719:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    271c:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    2721:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2725:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2729:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    272c:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    2731:	99                   	cwd
    2732:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2736:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    273a:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    273f:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    2745:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    274b:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2750:	8d be ea fe          	lea    di,[bp-0x116]
    2754:	16                   	push   ss
    2755:	57                   	push   di
    2756:	6a 01                	push   0x1
    2758:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    275c:	06                   	push   es
    275d:	57                   	push   di
    275e:	9a 95 28 c8 27       	call   0x27c8:0x2895
    2763:	08 c0                	or     al,al
    2765:	75 0a                	jne    0x2771
    2767:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    276a:	06                   	push   es
    276b:	57                   	push   di
    276c:	9a 08 14 d6 27       	call   0x27d6:0x1408
    2771:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2774:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    2779:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    277d:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2781:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2784:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    2789:	2d 01 00             	sub    ax,0x1
    278c:	71 05                	jno    0x2793
    278e:	9a 3e 04 f8 27       	call   0x27f8:0x43e
    2793:	99                   	cwd
    2794:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2798:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    279c:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    27a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a4:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    27a9:	99                   	cwd
    27aa:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    27ae:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    27b2:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    27b7:	8d be ea fe          	lea    di,[bp-0x116]
    27bb:	16                   	push   ss
    27bc:	57                   	push   di
    27bd:	6a 01                	push   0x1
    27bf:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    27c3:	06                   	push   es
    27c4:	57                   	push   di
    27c5:	9a 95 28 40 28       	call   0x2840:0x2895
    27ca:	08 c0                	or     al,al
    27cc:	75 0a                	jne    0x27d8
    27ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27d1:	06                   	push   es
    27d2:	57                   	push   di
    27d3:	9a 08 14 4e 28       	call   0x284e:0x1408
    27d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27db:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    27e0:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    27e4:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    27e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27eb:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    27f0:	2d 01 00             	sub    ax,0x1
    27f3:	71 05                	jno    0x27fa
    27f5:	9a 3e 04 70 28       	call   0x2870:0x43e
    27fa:	99                   	cwd
    27fb:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    27ff:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2803:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2808:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    280b:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    2810:	99                   	cwd
    2811:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2815:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2819:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    281e:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    2824:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    282a:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    282f:	8d be e2 fe          	lea    di,[bp-0x11e]
    2833:	16                   	push   ss
    2834:	57                   	push   di
    2835:	6a 02                	push   0x2
    2837:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    283b:	06                   	push   es
    283c:	57                   	push   di
    283d:	9a 95 28 b8 28       	call   0x28b8:0x2895
    2842:	08 c0                	or     al,al
    2844:	75 0a                	jne    0x2850
    2846:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2849:	06                   	push   es
    284a:	57                   	push   di
    284b:	9a 08 14 c6 28       	call   0x28c6:0x1408
    2850:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2853:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    2858:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    285c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2860:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2863:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    2868:	2d 01 00             	sub    ax,0x1
    286b:	71 05                	jno    0x2872
    286d:	9a 3e 04 3e 2b       	call   0x2b3e:0x43e
    2872:	99                   	cwd
    2873:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2877:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    287b:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2880:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2883:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    2888:	99                   	cwd
    2889:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    288d:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2891:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2896:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    289c:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    28a2:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    28a7:	8d be e2 fe          	lea    di,[bp-0x11e]
    28ab:	16                   	push   ss
    28ac:	57                   	push   di
    28ad:	6a 02                	push   0x2
    28af:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    28b3:	06                   	push   es
    28b4:	57                   	push   di
    28b5:	9a 95 28 23 29       	call   0x2923:0x2895
    28ba:	08 c0                	or     al,al
    28bc:	75 0a                	jne    0x28c8
    28be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28c1:	06                   	push   es
    28c2:	57                   	push   di
    28c3:	9a 08 14 31 29       	call   0x2931:0x1408
    28c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28cb:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    28d0:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    28d4:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    28d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28db:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    28e0:	99                   	cwd
    28e1:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    28e5:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    28e9:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    28ee:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    28f3:	99                   	cwd
    28f4:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    28f8:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    28fc:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2901:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    2907:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    290d:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2912:	8d be e2 fe          	lea    di,[bp-0x11e]
    2916:	16                   	push   ss
    2917:	57                   	push   di
    2918:	6a 02                	push   0x2
    291a:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    291e:	06                   	push   es
    291f:	57                   	push   di
    2920:	9a 95 28 8e 29       	call   0x298e:0x2895
    2925:	08 c0                	or     al,al
    2927:	75 0a                	jne    0x2933
    2929:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    292c:	06                   	push   es
    292d:	57                   	push   di
    292e:	9a 08 14 9c 29       	call   0x299c:0x1408
    2933:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2936:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    293b:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    293f:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2943:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2946:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    294b:	99                   	cwd
    294c:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2950:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2954:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2959:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    295e:	99                   	cwd
    295f:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2963:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2967:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    296c:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    2972:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2978:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    297d:	8d be e2 fe          	lea    di,[bp-0x11e]
    2981:	16                   	push   ss
    2982:	57                   	push   di
    2983:	6a 02                	push   0x2
    2985:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2989:	06                   	push   es
    298a:	57                   	push   di
    298b:	9a 95 28 e8 29       	call   0x29e8:0x2895
    2990:	08 c0                	or     al,al
    2992:	75 0a                	jne    0x299e
    2994:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2997:	06                   	push   es
    2998:	57                   	push   di
    2999:	9a 08 14 f6 29       	call   0x29f6:0x1408
    299e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a1:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    29a6:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    29aa:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    29ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29b1:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    29b6:	99                   	cwd
    29b7:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    29bb:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    29bf:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    29c4:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    29c9:	99                   	cwd
    29ca:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    29ce:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    29d2:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    29d7:	8d be ea fe          	lea    di,[bp-0x116]
    29db:	16                   	push   ss
    29dc:	57                   	push   di
    29dd:	6a 01                	push   0x1
    29df:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    29e3:	06                   	push   es
    29e4:	57                   	push   di
    29e5:	9a 95 28 53 2a       	call   0x2a53:0x2895
    29ea:	08 c0                	or     al,al
    29ec:	75 0a                	jne    0x29f8
    29ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29f1:	06                   	push   es
    29f2:	57                   	push   di
    29f3:	9a 08 14 61 2a       	call   0x2a61:0x1408
    29f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29fb:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    2a00:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2a04:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2a08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a0b:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    2a10:	99                   	cwd
    2a11:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2a15:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2a19:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2a1e:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    2a23:	99                   	cwd
    2a24:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2a28:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2a2c:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2a31:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    2a37:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2a3d:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2a42:	8d be e2 fe          	lea    di,[bp-0x11e]
    2a46:	16                   	push   ss
    2a47:	57                   	push   di
    2a48:	6a 02                	push   0x2
    2a4a:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2a4e:	06                   	push   es
    2a4f:	57                   	push   di
    2a50:	9a 95 28 be 2a       	call   0x2abe:0x2895
    2a55:	08 c0                	or     al,al
    2a57:	75 0a                	jne    0x2a63
    2a59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a5c:	06                   	push   es
    2a5d:	57                   	push   di
    2a5e:	9a 08 14 cc 2a       	call   0x2acc:0x1408
    2a63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a66:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2a6b:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2a6f:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2a73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a76:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    2a7b:	99                   	cwd
    2a7c:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2a80:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2a84:	c6 86 e6 fe 00       	mov    BYTE PTR [bp-0x11a],0x0
    2a89:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    2a8e:	99                   	cwd
    2a8f:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2a93:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2a97:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2a9c:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    2aa2:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    2aa8:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2aad:	8d be e2 fe          	lea    di,[bp-0x11e]
    2ab1:	16                   	push   ss
    2ab2:	57                   	push   di
    2ab3:	6a 02                	push   0x2
    2ab5:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2ab9:	06                   	push   es
    2aba:	57                   	push   di
    2abb:	9a 95 28 18 2b       	call   0x2b18:0x2895
    2ac0:	08 c0                	or     al,al
    2ac2:	75 0a                	jne    0x2ace
    2ac4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac7:	06                   	push   es
    2ac8:	57                   	push   di
    2ac9:	9a 08 14 26 2b       	call   0x2b26:0x1408
    2ace:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ad1:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2ad6:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2ada:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2ade:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae1:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    2ae6:	99                   	cwd
    2ae7:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2aeb:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2aef:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    2af4:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    2af9:	99                   	cwd
    2afa:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2afe:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    2b02:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    2b07:	8d be ea fe          	lea    di,[bp-0x116]
    2b0b:	16                   	push   ss
    2b0c:	57                   	push   di
    2b0d:	6a 01                	push   0x1
    2b0f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2b13:	06                   	push   es
    2b14:	57                   	push   di
    2b15:	9a 95 28 7f 2f       	call   0x2f7f:0x2895
    2b1a:	08 c0                	or     al,al
    2b1c:	75 0a                	jne    0x2b28
    2b1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b21:	06                   	push   es
    2b22:	57                   	push   di
    2b23:	9a 08 14 30 2b       	call   0x2b30:0x1408
    2b28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b2b:	06                   	push   es
    2b2c:	57                   	push   di
    2b2d:	9a a4 20 21 2c       	call   0x2c21:0x20a4
    2b32:	c9                   	leave
    2b33:	ca 04 00             	retf   0x4
    2b36:	55                   	push   bp
    2b37:	89 e5                	mov    bp,sp
    2b39:	31 c0                	xor    ax,ax
    2b3b:	9a 44 04 0f 2c       	call   0x2c0f:0x444
    2b40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b43:	26 c4 bd 18 02       	les    di,DWORD PTR es:[di+0x218]
    2b48:	06                   	push   es
    2b49:	57                   	push   di
    2b4a:	9a d2 31 5c 2b       	call   0x2b5c:0x31d2
    2b4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b52:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2b57:	06                   	push   es
    2b58:	57                   	push   di
    2b59:	9a d2 31 6b 2b       	call   0x2b6b:0x31d2
    2b5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b61:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    2b66:	06                   	push   es
    2b67:	57                   	push   di
    2b68:	9a d2 31 7a 2b       	call   0x2b7a:0x31d2
    2b6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b70:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    2b75:	06                   	push   es
    2b76:	57                   	push   di
    2b77:	9a d2 31 89 2b       	call   0x2b89:0x31d2
    2b7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b7f:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    2b84:	06                   	push   es
    2b85:	57                   	push   di
    2b86:	9a d2 31 98 2b       	call   0x2b98:0x31d2
    2b8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b8e:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    2b93:	06                   	push   es
    2b94:	57                   	push   di
    2b95:	9a d2 31 a7 2b       	call   0x2ba7:0x31d2
    2b9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b9d:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    2ba2:	06                   	push   es
    2ba3:	57                   	push   di
    2ba4:	9a d2 31 b6 2b       	call   0x2bb6:0x31d2
    2ba9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bac:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    2bb1:	06                   	push   es
    2bb2:	57                   	push   di
    2bb3:	9a d2 31 c5 2b       	call   0x2bc5:0x31d2
    2bb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bbb:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    2bc0:	06                   	push   es
    2bc1:	57                   	push   di
    2bc2:	9a d2 31 d4 2b       	call   0x2bd4:0x31d2
    2bc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bca:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    2bcf:	06                   	push   es
    2bd0:	57                   	push   di
    2bd1:	9a d2 31 e3 2b       	call   0x2be3:0x31d2
    2bd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bd9:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    2bde:	06                   	push   es
    2bdf:	57                   	push   di
    2be0:	9a d2 31 f2 2b       	call   0x2bf2:0x31d2
    2be5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2be8:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    2bed:	06                   	push   es
    2bee:	57                   	push   di
    2bef:	9a d2 31 01 2c       	call   0x2c01:0x31d2
    2bf4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bf7:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    2bfc:	06                   	push   es
    2bfd:	57                   	push   di
    2bfe:	9a d2 31 24 38       	call   0x3824:0x31d2
    2c03:	c9                   	leave
    2c04:	ca 04 00             	retf   0x4
    2c07:	55                   	push   bp
    2c08:	89 e5                	mov    bp,sp
    2c0a:	31 c0                	xor    ax,ax
    2c0c:	9a 44 04 2f 2c       	call   0x2c2f:0x444
    2c11:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2c14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c17:	26 89 85 92 05       	mov    WORD PTR es:[di+0x592],ax
    2c1c:	06                   	push   es
    2c1d:	57                   	push   di
    2c1e:	9a 13 24 41 2c       	call   0x2c41:0x2413
    2c23:	c9                   	leave
    2c24:	ca 06 00             	retf   0x6
    2c27:	55                   	push   bp
    2c28:	89 e5                	mov    bp,sp
    2c2a:	31 c0                	xor    ax,ax
    2c2c:	9a 44 04 60 2c       	call   0x2c60:0x444
    2c31:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2c34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c37:	26 89 85 94 05       	mov    WORD PTR es:[di+0x594],ax
    2c3c:	06                   	push   es
    2c3d:	57                   	push   di
    2c3e:	9a 13 24 c1 30       	call   0x30c1:0x2413
    2c43:	c9                   	leave
    2c44:	ca 06 00             	retf   0x6
    2c47:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
    2c4a:	6d                   	ins    WORD PTR es:[di],dx
    2c4b:	73 74                	jae    0x2cc1
    2c4d:	72 61                	jb     0x2cb0
    2c4f:	74 20                	je     0x2c71
    2c51:	2d 20 03             	sub    ax,0x320
    2c54:	20 2d                	and    BYTE PTR [di],ch
    2c56:	20 55 89             	and    BYTE PTR [di-0x77],dl
    2c59:	e5 b8                	in     ax,0xb8
    2c5b:	02 03                	add    al,BYTE PTR [bp+di]
    2c5d:	9a 44 04 74 2c       	call   0x2c74:0x444
    2c62:	81 ec 02 03          	sub    sp,0x302
    2c66:	8d be fe fe          	lea    di,[bp-0x102]
    2c6a:	16                   	push   ss
    2c6b:	57                   	push   di
    2c6c:	bf 47 2c             	mov    di,0x2c47
    2c6f:	0e                   	push   cs
    2c70:	57                   	push   di
    2c71:	9a cd 17 7e 2c       	call   0x2c7e:0x17cd
    2c76:	bf fa 1d             	mov    di,0x1dfa
    2c79:	1e                   	push   ds
    2c7a:	57                   	push   di
    2c7b:	9a 4c 18 88 2c       	call   0x2c88:0x184c
    2c80:	bf 53 2c             	mov    di,0x2c53
    2c83:	0e                   	push   cs
    2c84:	57                   	push   di
    2c85:	9a 4c 18 9d 2c       	call   0x2c9d:0x184c
    2c8a:	8d be fe fd          	lea    di,[bp-0x202]
    2c8e:	16                   	push   ss
    2c8f:	57                   	push   di
    2c90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c93:	06                   	push   es
    2c94:	57                   	push   di
    2c95:	9a 53 1d c2 2c       	call   0x2cc2:0x1d53
    2c9a:	9a 4c 18 ae 2c       	call   0x2cae:0x184c
    2c9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ca2:	81 c7 96 05          	add    di,0x596
    2ca6:	06                   	push   es
    2ca7:	57                   	push   di
    2ca8:	68 ff 00             	push   0xff
    2cab:	9a e7 17 fa 2c       	call   0x2cfa:0x17e7
    2cb0:	bf fa 1d             	mov    di,0x1dfa
    2cb3:	1e                   	push   ds
    2cb4:	57                   	push   di
    2cb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cb8:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    2cbd:	06                   	push   es
    2cbe:	57                   	push   di
    2cbf:	9a 8c 1d ef 2d       	call   0x2def:0x1d8c
    2cc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cc7:	26 c7 85 90 05 64 00 	mov    WORD PTR es:[di+0x590],0x64
    2cce:	c7 06 44 01 ff ff    	mov    WORD PTR ds:0x144,0xffff
    2cd4:	c7 06 46 01 ff ff    	mov    WORD PTR ds:0x146,0xffff
    2cda:	c7 06 48 01 ff ff    	mov    WORD PTR ds:0x148,0xffff
    2ce0:	26 c4 bd 10 02       	les    di,DWORD PTR es:[di+0x210]
    2ce5:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2ce8:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2ceb:	06                   	push   es
    2cec:	57                   	push   di
    2ced:	9a 26 13 24 2d       	call   0x2d24:0x1326
    2cf2:	2d 01 00             	sub    ax,0x1
    2cf5:	71 05                	jno    0x2cfc
    2cf7:	9a 3e 04 5c 2d       	call   0x2d5c:0x43e
    2cfc:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2cff:	31 c0                	xor    ax,ax
    2d01:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2d04:	7f 33                	jg     0x2d39
    2d06:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d09:	eb 03                	jmp    0x2d0e
    2d0b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2d0e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d11:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    2d15:	7c 1a                	jl     0x2d31
    2d17:	6a 00                	push   0x0
    2d19:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d1c:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2d1f:	06                   	push   es
    2d20:	57                   	push   di
    2d21:	9a 53 13 2f 2d       	call   0x2d2f:0x1353
    2d26:	89 c7                	mov    di,ax
    2d28:	8e c2                	mov    es,dx
    2d2a:	06                   	push   es
    2d2b:	57                   	push   di
    2d2c:	9a a5 13 7e 2d       	call   0x2d7e:0x13a5
    2d31:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d34:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2d37:	75 d2                	jne    0x2d0b
    2d39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d3c:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    2d41:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    2d44:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    2d47:	31 c0                	xor    ax,ax
    2d49:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d4c:	eb 03                	jmp    0x2d51
    2d4e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2d51:	a1 4c 01             	mov    ax,ds:0x14c
    2d54:	2d 01 00             	sub    ax,0x1
    2d57:	71 05                	jno    0x2d5e
    2d59:	9a 3e 04 6b 2d       	call   0x2d6b:0x43e
    2d5e:	8b d0                	mov    dx,ax
    2d60:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d63:	05 01 00             	add    ax,0x1
    2d66:	71 05                	jno    0x2d6d
    2d68:	9a 3e 04 c5 2d       	call   0x2dc5:0x43e
    2d6d:	3b c2                	cmp    ax,dx
    2d6f:	7e 1a                	jle    0x2d8b
    2d71:	6a 00                	push   0x0
    2d73:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d76:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    2d79:	06                   	push   es
    2d7a:	57                   	push   di
    2d7b:	9a 53 13 89 2d       	call   0x2d89:0x1353
    2d80:	89 c7                	mov    di,ax
    2d82:	8e c2                	mov    es,dx
    2d84:	06                   	push   es
    2d85:	57                   	push   di
    2d86:	9a a5 13 45 31       	call   0x3145:0x13a5
    2d8b:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    2d8f:	75 bd                	jne    0x2d4e
    2d91:	6a 00                	push   0x0
    2d93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d96:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    2d9b:	06                   	push   es
    2d9c:	57                   	push   di
    2d9d:	9a d0 1c b1 2d       	call   0x2db1:0x1cd0
    2da2:	6a 00                	push   0x0
    2da4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2da7:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    2dac:	06                   	push   es
    2dad:	57                   	push   di
    2dae:	9a d0 1c a9 30       	call   0x30a9:0x1cd0
    2db3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2db6:	06                   	push   es
    2db7:	57                   	push   di
    2db8:	9a 7d 52 e7 2d       	call   0x2de7:0x527d
    2dbd:	2d 01 00             	sub    ax,0x1
    2dc0:	71 05                	jno    0x2dc7
    2dc2:	9a 3e 04 f6 2d       	call   0x2df6:0x43e
    2dc7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2dca:	31 c0                	xor    ax,ax
    2dcc:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2dcf:	7e 03                	jle    0x2dd4
    2dd1:	e9 a7 00             	jmp    0x2e7b
    2dd4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2dd7:	eb 03                	jmp    0x2ddc
    2dd9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2ddc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ddf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2de2:	06                   	push   es
    2de3:	57                   	push   di
    2de4:	9a 46 52 07 2e       	call   0x2e07:0x5246
    2de9:	52                   	push   dx
    2dea:	50                   	push   ax
    2deb:	bf 99 03             	mov    di,0x399
    2dee:	b8 0f 2e             	mov    ax,0x2e0f
    2df1:	50                   	push   ax
    2df2:	57                   	push   di
    2df3:	9a 55 22 16 2e       	call   0x2e16:0x2255
    2df8:	08 c0                	or     al,al
    2dfa:	74 74                	je     0x2e70
    2dfc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2dff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e02:	06                   	push   es
    2e03:	57                   	push   di
    2e04:	9a 46 52 04 34       	call   0x3404:0x5246
    2e09:	52                   	push   dx
    2e0a:	50                   	push   ax
    2e0b:	bf 99 03             	mov    di,0x399
    2e0e:	b8 6e 2e             	mov    ax,0x2e6e
    2e11:	50                   	push   ax
    2e12:	57                   	push   di
    2e13:	9a 73 22 53 2e       	call   0x2e53:0x2273
    2e18:	89 c7                	mov    di,ax
    2e1a:	8e c2                	mov    es,dx
    2e1c:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2e1f:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    2e22:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2e27:	74 47                	je     0x2e70
    2e29:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2e2d:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    2e31:	74 3d                	je     0x2e70
    2e33:	a1 06 1e             	mov    ax,ds:0x1e06
    2e36:	99                   	cwd
    2e37:	8b c8                	mov    cx,ax
    2e39:	8b da                	mov    bx,dx
    2e3b:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2e3f:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    2e43:	09 d2                	or     dx,dx
    2e45:	79 07                	jns    0x2e4e
    2e47:	f7 d2                	not    dx
    2e49:	f7 d8                	neg    ax
    2e4b:	83 da ff             	sbb    dx,0xffff
    2e4e:	71 05                	jno    0x2e55
    2e50:	9a 3e 04 08 2f       	call   0x2f08:0x43e
    2e55:	3b d3                	cmp    dx,bx
    2e57:	7c 0a                	jl     0x2e63
    2e59:	7f 04                	jg     0x2e5f
    2e5b:	3b c1                	cmp    ax,cx
    2e5d:	76 04                	jbe    0x2e63
    2e5f:	b0 00                	mov    al,0x0
    2e61:	eb 02                	jmp    0x2e65
    2e63:	b0 01                	mov    al,0x1
    2e65:	50                   	push   ax
    2e66:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2e69:	06                   	push   es
    2e6a:	57                   	push   di
    2e6b:	9a 77 1c 8f 2e       	call   0x2e8f:0x1c77
    2e70:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e73:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2e76:	74 03                	je     0x2e7b
    2e78:	e9 5e ff             	jmp    0x2dd9
    2e7b:	8d be fe fe          	lea    di,[bp-0x102]
    2e7f:	16                   	push   ss
    2e80:	57                   	push   di
    2e81:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2e85:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    2e8a:	06                   	push   es
    2e8b:	57                   	push   di
    2e8c:	9a 53 1d 9e 2e       	call   0x2e9e:0x1d53
    2e91:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e94:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    2e99:	06                   	push   es
    2e9a:	57                   	push   di
    2e9b:	9a 8c 1d b4 2e       	call   0x2eb4:0x1d8c
    2ea0:	8d be fe fe          	lea    di,[bp-0x102]
    2ea4:	16                   	push   ss
    2ea5:	57                   	push   di
    2ea6:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2eaa:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    2eaf:	06                   	push   es
    2eb0:	57                   	push   di
    2eb1:	9a 53 1d c3 2e       	call   0x2ec3:0x1d53
    2eb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eb9:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
    2ebe:	06                   	push   es
    2ebf:	57                   	push   di
    2ec0:	9a 8c 1d d9 2e       	call   0x2ed9:0x1d8c
    2ec5:	8d be fe fe          	lea    di,[bp-0x102]
    2ec9:	16                   	push   ss
    2eca:	57                   	push   di
    2ecb:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2ecf:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    2ed4:	06                   	push   es
    2ed5:	57                   	push   di
    2ed6:	9a 53 1d e8 2e       	call   0x2ee8:0x1d53
    2edb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ede:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    2ee3:	06                   	push   es
    2ee4:	57                   	push   di
    2ee5:	9a 8c 1d fe 2e       	call   0x2efe:0x1d8c
    2eea:	8d be fe fe          	lea    di,[bp-0x102]
    2eee:	16                   	push   ss
    2eef:	57                   	push   di
    2ef0:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    2ef4:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    2ef9:	06                   	push   es
    2efa:	57                   	push   di
    2efb:	9a 53 1d 6b 2f       	call   0x2f6b:0x1d53
    2f00:	bf 53 2c             	mov    di,0x2c53
    2f03:	0e                   	push   cs
    2f04:	57                   	push   di
    2f05:	9a 4c 18 28 2f       	call   0x2f28:0x184c
    2f0a:	8d be fe fd          	lea    di,[bp-0x202]
    2f0e:	16                   	push   ss
    2f0f:	57                   	push   di
    2f10:	9a fe 15 23 2f       	call   0x2f23:0x15fe
    2f15:	83 ec 08             	sub    sp,0x8
    2f18:	89 e3                	mov    bx,sp
    2f1a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2f1e:	90                   	nop
    2f1f:	9b                   	fwait
    2f20:	9a bf 1c 3d 2f       	call   0x2f3d:0x1cbf
    2f25:	9a 4c 18 32 2f       	call   0x2f32:0x184c
    2f2a:	bf 53 2c             	mov    di,0x2c53
    2f2d:	0e                   	push   cs
    2f2e:	57                   	push   di
    2f2f:	9a 4c 18 52 2f       	call   0x2f52:0x184c
    2f34:	8d be fe fc          	lea    di,[bp-0x302]
    2f38:	16                   	push   ss
    2f39:	57                   	push   di
    2f3a:	9a fe 15 4d 2f       	call   0x2f4d:0x15fe
    2f3f:	83 ec 08             	sub    sp,0x8
    2f42:	89 e3                	mov    bx,sp
    2f44:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    2f48:	90                   	nop
    2f49:	9b                   	fwait
    2f4a:	9a e4 1c 16 34       	call   0x3416:0x1ce4
    2f4f:	9a 4c 18 5c 2f       	call   0x2f5c:0x184c
    2f54:	bf 53 2c             	mov    di,0x2c53
    2f57:	0e                   	push   cs
    2f58:	57                   	push   di
    2f59:	9a 4c 18 86 30       	call   0x3086:0x184c
    2f5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f61:	26 c4 bd d4 02       	les    di,DWORD PTR es:[di+0x2d4]
    2f66:	06                   	push   es
    2f67:	57                   	push   di
    2f68:	9a 8c 1d 2e 32       	call   0x322e:0x1d8c
    2f6d:	bf 32 1e             	mov    di,0x1e32
    2f70:	1e                   	push   ds
    2f71:	57                   	push   di
    2f72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f75:	26 c4 bd 18 02       	les    di,DWORD PTR es:[di+0x218]
    2f7a:	06                   	push   es
    2f7b:	57                   	push   di
    2f7c:	9a 17 30 93 2f       	call   0x2f93:0x3017
    2f81:	bf 32 1e             	mov    di,0x1e32
    2f84:	1e                   	push   ds
    2f85:	57                   	push   di
    2f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f89:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    2f8e:	06                   	push   es
    2f8f:	57                   	push   di
    2f90:	9a 17 30 a7 2f       	call   0x2fa7:0x3017
    2f95:	bf 40 1e             	mov    di,0x1e40
    2f98:	1e                   	push   ds
    2f99:	57                   	push   di
    2f9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f9d:	26 c4 bd a4 01       	les    di,DWORD PTR es:[di+0x1a4]
    2fa2:	06                   	push   es
    2fa3:	57                   	push   di
    2fa4:	9a 17 30 bb 2f       	call   0x2fbb:0x3017
    2fa9:	bf 40 1e             	mov    di,0x1e40
    2fac:	1e                   	push   ds
    2fad:	57                   	push   di
    2fae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fb1:	26 c4 bd a8 01       	les    di,DWORD PTR es:[di+0x1a8]
    2fb6:	06                   	push   es
    2fb7:	57                   	push   di
    2fb8:	9a 17 30 cf 2f       	call   0x2fcf:0x3017
    2fbd:	bf 78 1e             	mov    di,0x1e78
    2fc0:	1e                   	push   ds
    2fc1:	57                   	push   di
    2fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc5:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    2fca:	06                   	push   es
    2fcb:	57                   	push   di
    2fcc:	9a 17 30 e3 2f       	call   0x2fe3:0x3017
    2fd1:	bf 86 1e             	mov    di,0x1e86
    2fd4:	1e                   	push   ds
    2fd5:	57                   	push   di
    2fd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fd9:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    2fde:	06                   	push   es
    2fdf:	57                   	push   di
    2fe0:	9a 17 30 f7 2f       	call   0x2ff7:0x3017
    2fe5:	bf 86 1e             	mov    di,0x1e86
    2fe8:	1e                   	push   ds
    2fe9:	57                   	push   di
    2fea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fed:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    2ff2:	06                   	push   es
    2ff3:	57                   	push   di
    2ff4:	9a 17 30 0b 30       	call   0x300b:0x3017
    2ff9:	bf 4e 1e             	mov    di,0x1e4e
    2ffc:	1e                   	push   ds
    2ffd:	57                   	push   di
    2ffe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3001:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    3006:	06                   	push   es
    3007:	57                   	push   di
    3008:	9a 17 30 1f 30       	call   0x301f:0x3017
    300d:	bf 5c 1e             	mov    di,0x1e5c
    3010:	1e                   	push   ds
    3011:	57                   	push   di
    3012:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3015:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    301a:	06                   	push   es
    301b:	57                   	push   di
    301c:	9a 17 30 33 30       	call   0x3033:0x3017
    3021:	bf 5c 1e             	mov    di,0x1e5c
    3024:	1e                   	push   ds
    3025:	57                   	push   di
    3026:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3029:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    302e:	06                   	push   es
    302f:	57                   	push   di
    3030:	9a 17 30 47 30       	call   0x3047:0x3017
    3035:	bf 78 1e             	mov    di,0x1e78
    3038:	1e                   	push   ds
    3039:	57                   	push   di
    303a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    303d:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    3042:	06                   	push   es
    3043:	57                   	push   di
    3044:	9a 17 30 5b 30       	call   0x305b:0x3017
    3049:	bf 86 1e             	mov    di,0x1e86
    304c:	1e                   	push   ds
    304d:	57                   	push   di
    304e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3051:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3056:	06                   	push   es
    3057:	57                   	push   di
    3058:	9a 17 30 6f 30       	call   0x306f:0x3017
    305d:	bf 86 1e             	mov    di,0x1e86
    3060:	1e                   	push   ds
    3061:	57                   	push   di
    3062:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3065:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    306a:	06                   	push   es
    306b:	57                   	push   di
    306c:	9a 17 30 5e 38       	call   0x385e:0x3017
    3071:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3074:	26 c7 85 94 05 01 00 	mov    WORD PTR es:[di+0x594],0x1
    307b:	a1 4c 01             	mov    ax,ds:0x14c
    307e:	2d 01 00             	sub    ax,0x1
    3081:	71 05                	jno    0x3088
    3083:	9a 3e 04 9c 30       	call   0x309c:0x43e
    3088:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    308b:	26 89 85 92 05       	mov    WORD PTR es:[di+0x592],ax
    3090:	c9                   	leave
    3091:	ca 08 00             	retf   0x8
    3094:	55                   	push   bp
    3095:	89 e5                	mov    bp,sp
    3097:	31 c0                	xor    ax,ax
    3099:	9a 44 04 b7 30       	call   0x30b7:0x444
    309e:	6a fe                	push   0xfffe
    30a0:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    30a4:	06                   	push   es
    30a5:	57                   	push   di
    30a6:	9a a9 63 e0 30       	call   0x30e0:0x63a9
    30ab:	c9                   	leave
    30ac:	ca 08 00             	retf   0x8
    30af:	55                   	push   bp
    30b0:	89 e5                	mov    bp,sp
    30b2:	31 c0                	xor    ax,ax
    30b4:	9a 44 04 d6 30       	call   0x30d6:0x444
    30b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30bc:	06                   	push   es
    30bd:	57                   	push   di
    30be:	9a 36 2b a9 32       	call   0x32a9:0x2b36
    30c3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    30c6:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    30ca:	c9                   	leave
    30cb:	ca 0c 00             	retf   0xc
    30ce:	55                   	push   bp
    30cf:	89 e5                	mov    bp,sp
    30d1:	31 c0                	xor    ax,ax
    30d3:	9a 44 04 ee 30       	call   0x30ee:0x444
    30d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30db:	06                   	push   es
    30dc:	57                   	push   di
    30dd:	9a 56 55 02 31       	call   0x3102:0x5556
    30e2:	c9                   	leave
    30e3:	ca 08 00             	retf   0x8
    30e6:	55                   	push   bp
    30e7:	89 e5                	mov    bp,sp
    30e9:	31 c0                	xor    ax,ax
    30eb:	9a 44 04 2b 31       	call   0x312b:0x444
    30f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30f3:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    30f9:	75 0b                	jne    0x3106
    30fb:	6a 00                	push   0x0
    30fd:	06                   	push   es
    30fe:	57                   	push   di
    30ff:	9a 14 3a 10 31       	call   0x3110:0x3a14
    3104:	eb 0c                	jmp    0x3112
    3106:	6a 02                	push   0x2
    3108:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    310b:	06                   	push   es
    310c:	57                   	push   di
    310d:	9a 14 3a 9b 49       	call   0x499b:0x3a14
    3112:	c9                   	leave
    3113:	ca 08 00             	retf   0x8
    3116:	8d 31                	lea    si,[bx+di]
    3118:	94                   	xchg   sp,ax
    3119:	31 9b 31 a2          	xor    WORD PTR [bp+di-0x5dcf],bx
    311d:	31 a9 31 b0          	xor    WORD PTR [bx+di-0x4fcf],bp
    3121:	31 55 89             	xor    WORD PTR [di-0x77],dx
    3124:	e5 b8                	in     ax,0xb8
    3126:	0e                   	push   cs
    3127:	00 9a 44 04          	add    BYTE PTR [bp+si+0x444],bl
    312b:	4c                   	dec    sp
    312c:	31 83 ec 0e          	xor    WORD PTR [bp+di+0xeec],ax
    3130:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3133:	26 8b 85 90 05       	mov    ax,WORD PTR es:[di+0x590]
    3138:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    313b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    313e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3141:	bf 94 00             	mov    di,0x94
    3144:	b8 5f 31             	mov    ax,0x315f
    3147:	50                   	push   ax
    3148:	57                   	push   di
    3149:	9a 55 22 66 31       	call   0x3166:0x2255
    314e:	08 c0                	or     al,al
    3150:	75 03                	jne    0x3155
    3152:	e9 bf 00             	jmp    0x3214
    3155:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3158:	ff 76 0a             	push   WORD PTR [bp+0xa]
    315b:	bf 94 00             	mov    di,0x94
    315e:	b8 77 31             	mov    ax,0x3177
    3161:	50                   	push   ax
    3162:	57                   	push   di
    3163:	9a 73 22 d4 31       	call   0x31d4:0x2273
    3168:	52                   	push   dx
    3169:	50                   	push   ax
    316a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    316d:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    3172:	06                   	push   es
    3173:	57                   	push   di
    3174:	9a 2b 16 ca 31       	call   0x31ca:0x162b
    3179:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    317c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    317f:	3d 05 00             	cmp    ax,0x5
    3182:	77 33                	ja     0x31b7
    3184:	89 c3                	mov    bx,ax
    3186:	d1 e3                	shl    bx,1
    3188:	2e ff a7 16 31       	jmp    WORD PTR cs:[bx+0x3116]
    318d:	c7 46 fe 64 00       	mov    WORD PTR [bp-0x2],0x64
    3192:	eb 23                	jmp    0x31b7
    3194:	c7 46 fe 7d 00       	mov    WORD PTR [bp-0x2],0x7d
    3199:	eb 1c                	jmp    0x31b7
    319b:	c7 46 fe 96 00       	mov    WORD PTR [bp-0x2],0x96
    31a0:	eb 15                	jmp    0x31b7
    31a2:	c7 46 fe c8 00       	mov    WORD PTR [bp-0x2],0xc8
    31a7:	eb 0e                	jmp    0x31b7
    31a9:	c7 46 fe 4b 00       	mov    WORD PTR [bp-0x2],0x4b
    31ae:	eb 07                	jmp    0x31b7
    31b0:	c7 46 fe 32 00       	mov    WORD PTR [bp-0x2],0x32
    31b5:	eb 00                	jmp    0x31b7
    31b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31ba:	26 c4 bd f4 01       	les    di,DWORD PTR es:[di+0x1f4]
    31bf:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    31c2:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    31c5:	06                   	push   es
    31c6:	57                   	push   di
    31c7:	9a 26 13 ff 31       	call   0x31ff:0x1326
    31cc:	2d 01 00             	sub    ax,0x1
    31cf:	71 05                	jno    0x31d6
    31d1:	9a 3e 04 47 32       	call   0x3247:0x43e
    31d6:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    31d9:	31 c0                	xor    ax,ax
    31db:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    31de:	7f 34                	jg     0x3214
    31e0:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    31e3:	eb 03                	jmp    0x31e8
    31e5:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    31e8:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    31eb:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    31ee:	b0 00                	mov    al,0x0
    31f0:	75 01                	jne    0x31f3
    31f2:	40                   	inc    ax
    31f3:	50                   	push   ax
    31f4:	ff 76 f8             	push   WORD PTR [bp-0x8]
    31f7:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    31fa:	06                   	push   es
    31fb:	57                   	push   di
    31fc:	9a 53 13 0a 32       	call   0x320a:0x1353
    3201:	89 c7                	mov    di,ax
    3203:	8e c2                	mov    es,dx
    3205:	06                   	push   es
    3206:	57                   	push   di
    3207:	9a 75 12 62 32       	call   0x3262:0x1275
    320c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    320f:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    3212:	75 d1                	jne    0x31e5
    3214:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3217:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    321a:	26 3b 85 90 05       	cmp    ax,WORD PTR es:[di+0x590]
    321f:	74 1a                	je     0x323b
    3221:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3224:	26 ff b5 90 05       	push   WORD PTR es:[di+0x590]
    3229:	06                   	push   es
    322a:	57                   	push   di
    322b:	9a f4 5d f7 49       	call   0x49f7:0x5df4
    3230:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3233:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3236:	26 89 85 90 05       	mov    WORD PTR es:[di+0x590],ax
    323b:	c9                   	leave
    323c:	ca 08 00             	retf   0x8
    323f:	55                   	push   bp
    3240:	89 e5                	mov    bp,sp
    3242:	31 c0                	xor    ax,ax
    3244:	9a 44 04 71 32       	call   0x3271:0x444
    3249:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    324c:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    3252:	b0 00                	mov    al,0x0
    3254:	75 01                	jne    0x3257
    3256:	40                   	inc    ax
    3257:	50                   	push   ax
    3258:	26 c4 bd ec 01       	les    di,DWORD PTR es:[di+0x1ec]
    325d:	06                   	push   es
    325e:	57                   	push   di
    325f:	9a 75 12 c7 32       	call   0x32c7:0x1275
    3264:	c9                   	leave
    3265:	ca 08 00             	retf   0x8
    3268:	55                   	push   bp
    3269:	89 e5                	mov    bp,sp
    326b:	b8 02 00             	mov    ax,0x2
    326e:	9a 44 04 81 32       	call   0x3281:0x444
    3273:	83 ec 02             	sub    sp,0x2
    3276:	a1 4c 01             	mov    ax,ds:0x14c
    3279:	2d 01 00             	sub    ax,0x1
    327c:	71 05                	jno    0x3283
    327e:	9a 3e 04 b8 32       	call   0x32b8:0x43e
    3283:	50                   	push   ax
    3284:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3287:	26 ff b5 92 05       	push   WORD PTR es:[di+0x592]
    328c:	9a 32 3e 85 33       	call   0x3385:0x3e32
    3291:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3294:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3297:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    329a:	26 3b 85 92 05       	cmp    ax,WORD PTR es:[di+0x592]
    329f:	74 0a                	je     0x32ab
    32a1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    32a4:	06                   	push   es
    32a5:	57                   	push   di
    32a6:	9a 07 2c 9f 33       	call   0x339f:0x2c07
    32ab:	c9                   	leave
    32ac:	ca 08 00             	retf   0x8
    32af:	55                   	push   bp
    32b0:	89 e5                	mov    bp,sp
    32b2:	b8 08 00             	mov    ax,0x8
    32b5:	9a 44 04 ce 32       	call   0x32ce:0x444
    32ba:	83 ec 08             	sub    sp,0x8
    32bd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    32c0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    32c3:	bf 94 00             	mov    di,0x94
    32c6:	b8 e1 32             	mov    ax,0x32e1
    32c9:	50                   	push   ax
    32ca:	57                   	push   di
    32cb:	9a 55 22 e8 32       	call   0x32e8:0x2255
    32d0:	08 c0                	or     al,al
    32d2:	75 03                	jne    0x32d7
    32d4:	e9 ca 00             	jmp    0x33a1
    32d7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    32da:	ff 76 0a             	push   WORD PTR [bp+0xa]
    32dd:	bf 94 00             	mov    di,0x94
    32e0:	b8 03 33             	mov    ax,0x3303
    32e3:	50                   	push   ax
    32e4:	57                   	push   di
    32e5:	9a 73 22 0a 33       	call   0x330a:0x2273
    32ea:	89 c7                	mov    di,ax
    32ec:	8e c2                	mov    es,dx
    32ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32f1:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    32f6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    32f9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    32fc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    32ff:	bf 94 00             	mov    di,0x94
    3302:	b8 1b 33             	mov    ax,0x331b
    3305:	50                   	push   ax
    3306:	57                   	push   di
    3307:	9a 73 22 2b 33       	call   0x332b:0x2273
    330c:	52                   	push   dx
    330d:	50                   	push   ax
    330e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3311:	26 c4 bd 50 03       	les    di,DWORD PTR es:[di+0x350]
    3316:	06                   	push   es
    3317:	57                   	push   di
    3318:	9a 2b 16 c6 33       	call   0x33c6:0x162b
    331d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3320:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3323:	05 01 00             	add    ax,0x1
    3326:	71 05                	jno    0x332d
    3328:	9a 3e 04 5f 33       	call   0x335f:0x43e
    332d:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    3331:	b0 00                	mov    al,0x0
    3333:	7d 01                	jge    0x3336
    3335:	40                   	inc    ax
    3336:	8a c8                	mov    cl,al
    3338:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    333c:	b0 00                	mov    al,0x0
    333e:	7d 01                	jge    0x3341
    3340:	40                   	inc    ax
    3341:	8a d0                	mov    dl,al
    3343:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    3347:	b0 00                	mov    al,0x0
    3349:	7c 01                	jl     0x334c
    334b:	40                   	inc    ax
    334c:	22 c2                	and    al,dl
    334e:	22 c1                	and    al,cl
    3350:	08 c0                	or     al,al
    3352:	74 12                	je     0x3366
    3354:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3357:	05 01 00             	add    ax,0x1
    335a:	71 05                	jno    0x3361
    335c:	9a 3e 04 77 33       	call   0x3377:0x43e
    3361:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3364:	eb 24                	jmp    0x338a
    3366:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    336a:	75 1e                	jne    0x338a
    336c:	a1 4c 01             	mov    ax,ds:0x14c
    336f:	2d 01 00             	sub    ax,0x1
    3372:	71 05                	jno    0x3379
    3374:	9a 3e 04 b6 33       	call   0x33b6:0x43e
    3379:	50                   	push   ax
    337a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    337d:	26 ff b5 92 05       	push   WORD PTR es:[di+0x592]
    3382:	9a 32 3e ff ff       	call   0xffff:0x3e32
    3387:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    338a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    338d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3390:	26 3b 85 92 05       	cmp    ax,WORD PTR es:[di+0x592]
    3395:	74 0a                	je     0x33a1
    3397:	ff 76 fe             	push   WORD PTR [bp-0x2]
    339a:	06                   	push   es
    339b:	57                   	push   di
    339c:	9a 07 2c 4b 34       	call   0x344b:0x2c07
    33a1:	c9                   	leave
    33a2:	ca 08 00             	retf   0x8
    33a5:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
    33a9:	ff                   	(bad)
    33aa:	7f 00                	jg     0x33ac
    33ac:	00 55 89             	add    BYTE PTR [di-0x77],dl
    33af:	e5 b8                	in     ax,0xb8
    33b1:	06                   	push   es
    33b2:	02 9a 44 04          	add    bl,BYTE PTR [bp+si+0x444]
    33b6:	cd 33                	int    0x33
    33b8:	81 ec 06 02          	sub    sp,0x206
    33bc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    33bf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    33c2:	bf 94 00             	mov    di,0x94
    33c5:	b8 dd 33             	mov    ax,0x33dd
    33c8:	50                   	push   ax
    33c9:	57                   	push   di
    33ca:	9a 55 22 e4 33       	call   0x33e4:0x2255
    33cf:	08 c0                	or     al,al
    33d1:	74 7a                	je     0x344d
    33d3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    33d6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    33d9:	bf 94 00             	mov    di,0x94
    33dc:	b8 ff ff             	mov    ax,0xffff
    33df:	50                   	push   ax
    33e0:	57                   	push   di
    33e1:	9a 73 22 11 34       	call   0x3411:0x2273
    33e6:	89 c7                	mov    di,ax
    33e8:	8e c2                	mov    es,dx
    33ea:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    33ed:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    33f0:	8d be fa fd          	lea    di,[bp-0x206]
    33f4:	16                   	push   ss
    33f5:	57                   	push   di
    33f6:	8d be fa fe          	lea    di,[bp-0x106]
    33fa:	16                   	push   ss
    33fb:	57                   	push   di
    33fc:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    33ff:	06                   	push   es
    3400:	57                   	push   di
    3401:	9a 2a 51 ff ff       	call   0xffff:0x512a
    3406:	83 c4 04             	add    sp,0x4
    3409:	8a 86 fc fe          	mov    al,BYTE PTR [bp-0x104]
    340d:	50                   	push   ax
    340e:	9a e9 18 1e 34       	call   0x341e:0x18e9
    3413:	9a da 08 ff ff       	call   0xffff:0x8da
    3418:	bf a5 33             	mov    di,0x33a5
    341b:	9a 16 04 0c 38       	call   0x380c:0x416
    3420:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3423:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3426:	3b 06 4e 01          	cmp    ax,WORD PTR ds:0x14e
    342a:	b0 00                	mov    al,0x0
    342c:	7f 01                	jg     0x342f
    342e:	40                   	inc    ax
    342f:	8a d0                	mov    dl,al
    3431:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    3435:	b0 00                	mov    al,0x0
    3437:	7e 01                	jle    0x343a
    3439:	40                   	inc    ax
    343a:	22 c2                	and    al,dl
    343c:	08 c0                	or     al,al
    343e:	74 0d                	je     0x344d
    3440:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3443:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3446:	06                   	push   es
    3447:	57                   	push   di
    3448:	9a 27 2c d3 4c       	call   0x4cd3:0x2c27
    344d:	c9                   	leave
    344e:	ca 08 00             	retf   0x8
    3451:	07                   	pop    es
    3452:	54                   	push   sp
    3453:	61                   	popa
    3454:	75 78                	jne    0x34ce
    3456:	54                   	push   sp
    3457:	56                   	push   si
    3458:	41                   	inc    cx
    3459:	00 00                	add    BYTE PTR [bx+si],al
    345b:	c8 42 06 56          	enter  0x642,0x56
    345f:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3461:	74 65                	je     0x34c8
    3463:	73 04                	jae    0x3469
    3465:	50                   	push   ax
    3466:	72 69                	jb     0x34d1
    3468:	78 10                	js     0x347a
    346a:	56                   	push   si
    346b:	65 6e                	outs   dx,BYTE PTR gs:[si]
    346d:	74 65                	je     0x34d4
    346f:	73 53                	jae    0x34c4
    3471:	6f                   	outs   dx,WORD PTR ds:[si]
    3472:	6c                   	ins    BYTE PTR es:[di],dx
    3473:	64 65 65 73 51       	fs gs gs jae 0x34c9
    3478:	74 65                	je     0x34df
    347a:	11 56 65             	adc    WORD PTR [bp+0x65],dx
    347d:	6e                   	outs   dx,BYTE PTR ds:[si]
    347e:	74 65                	je     0x34e5
    3480:	73 53                	jae    0x34d5
    3482:	6f                   	outs   dx,WORD PTR ds:[si]
    3483:	6c                   	ins    BYTE PTR es:[di],dx
    3484:	64 65 65 73 50       	fs gs gs jae 0x34d9
    3489:	72 69                	jb     0x34f4
    348b:	78 0c                	js     0x3499
    348d:	56                   	push   si
    348e:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3490:	74 65                	je     0x34f7
    3492:	73 53                	jae    0x34e7
    3494:	70 65                	jo     0x34fb
    3496:	51                   	push   cx
    3497:	74 65                	je     0x34fe
    3499:	0d 56 65             	or     ax,0x6556
    349c:	6e                   	outs   dx,BYTE PTR ds:[si]
    349d:	74 65                	je     0x3504
    349f:	73 53                	jae    0x34f4
    34a1:	70 65                	jo     0x3508
    34a3:	50                   	push   ax
    34a4:	72 69                	jb     0x350f
    34a6:	78 0b                	js     0x34b3
    34a8:	56                   	push   si
    34a9:	61                   	popa
    34aa:	6c                   	ins    BYTE PTR es:[di],dx
    34ab:	65 75 72             	gs jne 0x3520
    34ae:	53                   	push   bx
    34af:	74 6f                	je     0x3520
    34b1:	63 6b 11             	arpl   WORD PTR [bp+di+0x11],bp
    34b4:	50                   	push   ax
    34b5:	72 6f                	jb     0x3526
    34b7:	64 75 63             	fs jne 0x351d
    34ba:	74 69                	je     0x3525
    34bc:	6f                   	outs   dx,WORD PTR ds:[si]
    34bd:	6e                   	outs   dx,BYTE PTR ds:[si]
    34be:	5f                   	pop    di
    34bf:	76 65                	jbe    0x3526
    34c1:	6e                   	outs   dx,BYTE PTR ds:[si]
    34c2:	64 75 65             	fs jne 0x352a
    34c5:	11 50 72             	adc    WORD PTR [bx+si+0x72],dx
    34c8:	6f                   	outs   dx,WORD PTR ds:[si]
    34c9:	64 75 63             	fs jne 0x352f
    34cc:	74 69                	je     0x3537
    34ce:	6f                   	outs   dx,WORD PTR ds:[si]
    34cf:	6e                   	outs   dx,BYTE PTR ds:[si]
    34d0:	5f                   	pop    di
    34d1:	73 6f                	jae    0x3542
    34d3:	6c                   	ins    BYTE PTR es:[di],dx
    34d4:	64 65 65 1b 50 72    	fs gs sbb dx,WORD PTR gs:[bx+si+0x72]
    34da:	6f                   	outs   dx,WORD PTR ds:[si]
    34db:	64 75 63             	fs jne 0x3541
    34de:	74 69                	je     0x3549
    34e0:	6f                   	outs   dx,WORD PTR ds:[si]
    34e1:	6e                   	outs   dx,BYTE PTR ds:[si]
    34e2:	5f                   	pop    di
    34e3:	6f                   	outs   dx,WORD PTR ds:[si]
    34e4:	66 66 72 65          	data32 data32 jb 0x354d
    34e8:	73 5f                	jae    0x3549
    34ea:	73 70                	jae    0x355c
    34ec:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
    34f0:	6c                   	ins    BYTE PTR es:[di],dx
    34f1:	65 73 12             	gs jae 0x3506
    34f4:	50                   	push   ax
    34f5:	72 6f                	jb     0x3566
    34f7:	64 75 63             	fs jne 0x355d
    34fa:	74 69                	je     0x3565
    34fc:	6f                   	outs   dx,WORD PTR ds:[si]
    34fd:	6e                   	outs   dx,BYTE PTR ds:[si]
    34fe:	5f                   	pop    di
    34ff:	73 74                	jae    0x3575
    3501:	6f                   	outs   dx,WORD PTR ds:[si]
    3502:	63 6b 65             	arpl   WORD PTR [bp+di+0x65],bp
    3505:	65 16                	gs push ss
    3507:	50                   	push   ax
    3508:	72 6f                	jb     0x3579
    350a:	64 75 63             	fs jne 0x3570
    350d:	74 69                	je     0x3578
    350f:	6f                   	outs   dx,WORD PTR ds:[si]
    3510:	6e                   	outs   dx,BYTE PTR ds:[si]
    3511:	5f                   	pop    di
    3512:	44                   	inc    sp
    3513:	65 5f                	gs pop di
    3515:	45                   	inc    bp
    3516:	78 65                	js     0x357d
    3518:	72 63                	jb     0x357d
    351a:	69 63 65 13 43       	imul   sp,WORD PTR [bp+di+0x65],0x4313
    351f:	6f                   	outs   dx,WORD PTR ds:[si]
    3520:	6e                   	outs   dx,BYTE PTR ds:[si]
    3521:	73 6f                	jae    0x3592
    3523:	6d                   	ins    WORD PTR es:[di],dx
    3524:	6d                   	ins    WORD PTR es:[di],dx
    3525:	61                   	popa
    3526:	74 69                	je     0x3591
    3528:	6f                   	outs   dx,WORD PTR ds:[si]
    3529:	6e                   	outs   dx,BYTE PTR ds:[si]
    352a:	4d                   	dec    bp
    352b:	61                   	popa
    352c:	74 69                	je     0x3597
    352e:	65 72 65             	gs jb  0x3596
    3531:	10 4d 61             	adc    BYTE PTR [di+0x61],cl
    3534:	74 69                	je     0x359f
    3536:	65 72 65             	gs jb  0x359e
    3539:	43                   	inc    bx
    353a:	6f                   	outs   dx,WORD PTR ds:[si]
    353b:	6e                   	outs   dx,BYTE PTR ds:[si]
    353c:	73 6f                	jae    0x35ad
    353e:	6d                   	ins    WORD PTR es:[di],dx
    353f:	6d                   	ins    WORD PTR es:[di],dx
    3540:	65 65 0f 44 65 70    	gs cmove sp,WORD PTR gs:[di+0x70]
    3546:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3548:	73 65                	jae    0x35af
    354a:	73 51                	jae    0x359d
    354c:	75 61                	jne    0x35af
    354e:	6c                   	ins    BYTE PTR es:[di],dx
    354f:	69 74 65 07 51       	imul   si,WORD PTR [si+0x65],0x5107
    3554:	75 61                	jne    0x35b7
    3556:	6c                   	ins    BYTE PTR es:[di],dx
    3557:	69 74 65 09 50       	imul   si,WORD PTR [si+0x65],0x5009
    355c:	75 62                	jne    0x35c0
    355e:	6c                   	ins    BYTE PTR es:[di],dx
    355f:	69 63 69 74 65       	imul   sp,WORD PTR [bp+di+0x69],0x6574
    3564:	11 41 63             	adc    WORD PTR [bx+di+0x63],ax
    3567:	74 69                	je     0x35d2
    3569:	6f                   	outs   dx,WORD PTR ds:[si]
    356a:	6e                   	outs   dx,BYTE PTR ds:[si]
    356b:	43                   	inc    bx
    356c:	6f                   	outs   dx,WORD PTR ds:[si]
    356d:	6d                   	ins    WORD PTR es:[di],dx
    356e:	6d                   	ins    WORD PTR es:[di],dx
    356f:	65 72 63             	gs jb  0x35d5
    3572:	69 61 6c 65 0e       	imul   sp,WORD PTR [bx+di+0x6c],0xe65
    3577:	50                   	push   ax
    3578:	75 62                	jne    0x35dc
    357a:	45                   	inc    bp
    357b:	74 41                	je     0x35be
    357d:	63 74 69             	arpl   WORD PTR [si+0x69],si
    3580:	6f                   	outs   dx,WORD PTR ds:[si]
    3581:	6e                   	outs   dx,BYTE PTR ds:[si]
    3582:	43                   	inc    bx
    3583:	6f                   	outs   dx,WORD PTR ds:[si]
    3584:	6d                   	ins    WORD PTR es:[di],dx
    3585:	08 51 74             	or     BYTE PTR [bx+di+0x74],dl
    3588:	65 53                	gs push bx
    358a:	74 6f                	je     0x35fb
    358c:	63 6b 0e             	arpl   WORD PTR [bp+di+0xe],bp
    358f:	43                   	inc    bx
    3590:	6f                   	outs   dx,WORD PTR ds:[si]
    3591:	75 74                	jne    0x3607
    3593:	55                   	push   bp
    3594:	6e                   	outs   dx,BYTE PTR ds:[si]
    3595:	69 74 65 53 74       	imul   si,WORD PTR [si+0x65],0x7453
    359a:	6f                   	outs   dx,WORD PTR ds:[si]
    359b:	63 6b 0a             	arpl   WORD PTR [bp+di+0xa],bp
    359e:	46                   	inc    si
    359f:	72 61                	jb     0x3602
    35a1:	69 73 53 74 6f       	imul   si,WORD PTR [bp+di+0x53],0x6f74
    35a6:	63 6b 14             	arpl   WORD PTR [bp+di+0x14],bp
    35a9:	43                   	inc    bx
    35aa:	6f                   	outs   dx,WORD PTR ds:[si]
    35ab:	75 74                	jne    0x3621
    35ad:	73 46                	jae    0x35f5
    35af:	69 78 65 73 50       	imul   di,WORD PTR [bx+si+0x65],0x5073
    35b4:	72 6f                	jb     0x3625
    35b6:	64 75 63             	fs jne 0x361c
    35b9:	74 69                	je     0x3624
    35bb:	6f                   	outs   dx,WORD PTR ds:[si]
    35bc:	6e                   	outs   dx,BYTE PTR ds:[si]
    35bd:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
    35c0:	70 61                	jo     0x3623
    35c2:	72 61                	jb     0x3625
    35c4:	74 69                	je     0x362f
    35c6:	6f                   	outs   dx,WORD PTR ds:[si]
    35c7:	6e                   	outs   dx,BYTE PTR ds:[si]
    35c8:	73 11                	jae    0x35db
    35ca:	45                   	inc    bp
    35cb:	6e                   	outs   dx,BYTE PTR ds:[si]
    35cc:	74 72                	je     0x3640
    35ce:	65 74 69             	gs je  0x363a
    35d1:	65 6e                	outs   dx,BYTE PTR gs:[si]
    35d3:	4d                   	dec    bp
    35d4:	61                   	popa
    35d5:	63 68 69             	arpl   WORD PTR [bx+si+0x69],bp
    35d8:	6e                   	outs   dx,BYTE PTR ds:[si]
    35d9:	65 73 0f             	gs jae 0x35eb
    35dc:	50                   	push   ax
    35dd:	72 69                	jb     0x3648
    35df:	6d                   	ins    WORD PTR es:[di],dx
    35e0:	65 73 41             	gs jae 0x3624
    35e3:	73 73                	jae    0x3658
    35e5:	75 72                	jne    0x3659
    35e7:	61                   	popa
    35e8:	6e                   	outs   dx,BYTE PTR ds:[si]
    35e9:	63 65 06             	arpl   WORD PTR [di+0x6],sp
    35ec:	45                   	inc    bp
    35ed:	74 75                	je     0x3664
    35ef:	64 65 73 11          	fs gs jae 0x3604
    35f3:	43                   	inc    bx
    35f4:	6f                   	outs   dx,WORD PTR ds:[si]
    35f5:	6e                   	outs   dx,BYTE PTR ds:[si]
    35f6:	73 6f                	jae    0x3667
    35f8:	6d                   	ins    WORD PTR es:[di],dx
    35f9:	6d                   	ins    WORD PTR es:[di],dx
    35fa:	61                   	popa
    35fb:	74 69                	je     0x3666
    35fd:	6f                   	outs   dx,WORD PTR ds:[si]
    35fe:	6e                   	outs   dx,BYTE PTR ds:[si]
    35ff:	54                   	push   sp
    3600:	69 65 72 73 0d       	imul   sp,WORD PTR [di+0x72],0xd73
    3605:	56                   	push   si
    3606:	61                   	popa
    3607:	6c                   	ins    BYTE PTR es:[di],dx
    3608:	65 75 72             	gs jne 0x367d
    360b:	41                   	inc    cx
    360c:	6a 6f                	push   0x6f
    360e:	75 74                	jne    0x3684
    3610:	65 65 0b 53 75       	gs or  dx,WORD PTR gs:[bp+di+0x75]
    3615:	62 76 65             	bound  si,DWORD PTR [bp+0x65]
    3618:	6e                   	outs   dx,BYTE PTR ds:[si]
    3619:	74 69                	je     0x3684
    361b:	6f                   	outs   dx,WORD PTR ds:[si]
    361c:	6e                   	outs   dx,BYTE PTR ds:[si]
    361d:	73 11                	jae    0x3630
    361f:	4d                   	dec    bp
    3620:	61                   	popa
    3621:	69 6e 4f 65 75       	imul   bp,WORD PTR [bp+0x4f],0x7565
    3626:	76 72                	jbe    0x369a
    3628:	65 44                	gs inc sp
    362a:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    362f:	65 11 4d 61          	adc    WORD PTR gs:[di+0x61],cx
    3633:	69 6e 30 65 75       	imul   bp,WORD PTR [bp+0x30],0x7565
    3638:	76 72                	jbe    0x36ac
    363a:	65 44                	gs inc sp
    363c:	69 72 65 63 74       	imul   si,WORD PTR [bp+si+0x65],0x7463
    3641:	65 0e                	gs push cs
    3643:	52                   	push   dx
    3644:	65 6d                	gs ins WORD PTR es:[di],dx
    3646:	75 6e                	jne    0x36b6
    3648:	65 72 61             	gs jb  0x36ac
    364b:	74 69                	je     0x36b6
    364d:	6f                   	outs   dx,WORD PTR ds:[si]
    364e:	6e                   	outs   dx,BYTE PTR ds:[si]
    364f:	46                   	inc    si
    3650:	56                   	push   si
    3651:	14 52                	adc    al,0x52
    3653:	65 6d                	gs ins WORD PTR es:[di],dx
    3655:	75 6e                	jne    0x36c5
    3657:	65 72 61             	gs jb  0x36bb
    365a:	74 69                	je     0x36c5
    365c:	6f                   	outs   dx,WORD PTR ds:[si]
    365d:	6e                   	outs   dx,BYTE PTR ds:[si]
    365e:	56                   	push   si
    365f:	65 6e                	outs   dx,BYTE PTR gs:[si]
    3661:	64 65 75 72          	fs gs jne 0x36d7
    3665:	73 12                	jae    0x3679
    3667:	52                   	push   dx
    3668:	65 6d                	gs ins WORD PTR es:[di],dx
    366a:	75 6e                	jne    0x36da
    366c:	65 72 61             	gs jb  0x36d0
    366f:	74 69                	je     0x36da
    3671:	6f                   	outs   dx,WORD PTR ds:[si]
    3672:	6e                   	outs   dx,BYTE PTR ds:[si]
    3673:	43                   	inc    bx
    3674:	61                   	popa
    3675:	64 72 65             	fs jb  0x36dd
    3678:	73 0c                	jae    0x3686
    367a:	43                   	inc    bx
    367b:	6f                   	outs   dx,WORD PTR ds:[si]
    367c:	75 74                	jne    0x36f2
    367e:	45                   	inc    bp
    367f:	6d                   	ins    WORD PTR es:[di],dx
    3680:	62 61 75             	bound  sp,DWORD PTR [bx+di+0x75]
    3683:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
    3686:	0c 43                	or     al,0x43
    3688:	6f                   	outs   dx,WORD PTR ds:[si]
    3689:	75 74                	jne    0x36ff
    368b:	4c                   	dec    sp
    368c:	69 63 65 6e 63       	imul   sp,WORD PTR [bp+di+0x65],0x636e
    3691:	69 65 0d 43 6f       	imul   sp,WORD PTR [di+0xd],0x6f43
    3696:	75 74                	jne    0x370c
    3698:	46                   	inc    si
    3699:	6f                   	outs   dx,WORD PTR ds:[si]
    369a:	72 6d                	jb     0x3709
    369c:	61                   	popa
    369d:	74 69                	je     0x3708
    369f:	6f                   	outs   dx,WORD PTR ds:[si]
    36a0:	6e                   	outs   dx,BYTE PTR ds:[si]
    36a1:	17                   	pop    ss
    36a2:	45                   	inc    bp
    36a3:	78 65                	js     0x370a
    36a5:	64 65 6e             	fs outs dx,BYTE PTR gs:[si]
    36a8:	74 42                	je     0x36ec
    36aa:	72 75                	jb     0x3721
    36ac:	74 45                	je     0x36f3
    36ae:	78 70                	js     0x3720
    36b0:	6c                   	ins    BYTE PTR es:[di],dx
    36b1:	6f                   	outs   dx,WORD PTR ds:[si]
    36b2:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
    36b7:	6f                   	outs   dx,WORD PTR ds:[si]
    36b8:	6e                   	outs   dx,BYTE PTR ds:[si]
    36b9:	10 44 6f             	adc    BYTE PTR [si+0x6f],al
    36bc:	74 41                	je     0x36ff
    36be:	6d                   	ins    WORD PTR es:[di],dx
    36bf:	6f                   	outs   dx,WORD PTR ds:[si]
    36c0:	72 74                	jb     0x3736
    36c2:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    36c7:	65 6e                	outs   dx,BYTE PTR gs:[si]
    36c9:	74 16                	je     0x36e1
    36cb:	44                   	inc    sp
    36cc:	6f                   	outs   dx,WORD PTR ds:[si]
    36cd:	74 61                	je     0x3730
    36cf:	74 69                	je     0x373a
    36d1:	6f                   	outs   dx,WORD PTR ds:[si]
    36d2:	6e                   	outs   dx,BYTE PTR ds:[si]
    36d3:	73 41                	jae    0x3716
    36d5:	6d                   	ins    WORD PTR es:[di],dx
    36d6:	6f                   	outs   dx,WORD PTR ds:[si]
    36d7:	72 74                	jb     0x374d
    36d9:	69 73 73 65 6d       	imul   si,WORD PTR [bp+di+0x73],0x6d65
    36de:	65 6e                	outs   dx,BYTE PTR gs:[si]
    36e0:	74 14                	je     0x36f6
    36e2:	52                   	push   dx
    36e3:	65 73 75             	gs jae 0x375b
    36e6:	6c                   	ins    BYTE PTR es:[di],dx
    36e7:	74 61                	je     0x374a
    36e9:	74 45                	je     0x3730
    36eb:	78 70                	js     0x375d
    36ed:	6c                   	ins    BYTE PTR es:[di],dx
    36ee:	6f                   	outs   dx,WORD PTR ds:[si]
    36ef:	69 74 61 74 69       	imul   si,WORD PTR [si+0x61],0x6974
    36f4:	6f                   	outs   dx,WORD PTR ds:[si]
    36f5:	6e                   	outs   dx,BYTE PTR ds:[si]
    36f6:	0a 54 72             	or     dl,BYTE PTR [si+0x72]
    36f9:	65 73 6f             	gs jae 0x376b
    36fc:	72 65                	jb     0x3763
    36fe:	72 69                	jb     0x3769
    3700:	65 0d 54 61          	gs or  ax,0x6154
    3704:	75 78                	jne    0x377e
    3706:	50                   	push   ax
    3707:	6c                   	ins    BYTE PTR es:[di],dx
    3708:	61                   	popa
    3709:	63 65 6d             	arpl   WORD PTR [di+0x6d],sp
    370c:	65 6e                	outs   dx,BYTE PTR gs:[si]
    370e:	74 12                	je     0x3722
    3710:	50                   	push   ax
    3711:	72 6f                	jb     0x3782
    3713:	64 75 69             	fs jne 0x377f
    3716:	74 73                	je     0x378b
    3718:	46                   	inc    si
    3719:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    371e:	69 65 72 73 0d       	imul   sp,WORD PTR [di+0x72],0xd73
    3723:	44                   	inc    sp
    3724:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    3728:	76 65                	jbe    0x378f
    372a:	72 74                	jb     0x37a0
    372c:	41                   	inc    cx
    372d:	75 74                	jne    0x37a3
    372f:	6f                   	outs   dx,WORD PTR ds:[si]
    3730:	11 54 61             	adc    WORD PTR [si+0x61],dx
    3733:	75 78                	jne    0x37ad
    3735:	44                   	inc    sp
    3736:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    373a:	76 65                	jbe    0x37a1
    373c:	72 74                	jb     0x37b2
    373e:	41                   	inc    cx
    373f:	75 74                	jne    0x37b5
    3741:	6f                   	outs   dx,WORD PTR ds:[si]
    3742:	0e                   	push   cs
    3743:	44                   	inc    sp
    3744:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    3748:	76 65                	jbe    0x37af
    374a:	72 74                	jb     0x37c0
    374c:	4e                   	dec    si
    374d:	41                   	inc    cx
    374e:	75 74                	jne    0x37c4
    3750:	6f                   	outs   dx,WORD PTR ds:[si]
    3751:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
    3754:	75 78                	jne    0x37ce
    3756:	44                   	inc    sp
    3757:	65 63 6f 75          	arpl   WORD PTR gs:[bx+0x75],bp
    375b:	76 65                	jbe    0x37c2
    375d:	72 74                	jb     0x37d3
    375f:	4e                   	dec    si
    3760:	41                   	inc    cx
    3761:	75 74                	jne    0x37d7
    3763:	6f                   	outs   dx,WORD PTR ds:[si]
    3764:	07                   	pop    es
    3765:	45                   	inc    bp
    3766:	6d                   	ins    WORD PTR es:[di],dx
    3767:	70 72                	jo     0x37db
    3769:	75 6e                	jne    0x37d9
    376b:	74 0b                	je     0x3778
    376d:	54                   	push   sp
    376e:	61                   	popa
    376f:	75 78                	jne    0x37e9
    3771:	45                   	inc    bp
    3772:	6d                   	ins    WORD PTR es:[di],dx
    3773:	70 72                	jo     0x37e7
    3775:	75 6e                	jne    0x37e5
    3777:	74 12                	je     0x378b
    3779:	43                   	inc    bx
    377a:	68 61 72             	push   0x7261
    377d:	67 65 73 46          	addr32 gs jae 0x37c7
    3781:	69 6e 61 6e 63       	imul   bp,WORD PTR [bp+0x61],0x636e
    3786:	69 65 72 65 73       	imul   sp,WORD PTR [di+0x72],0x7365
    378b:	0f 52 65 73          	rsqrtps xmm4,XMMWORD PTR [di+0x73]
    378f:	75 6c                	jne    0x37fd
    3791:	74 61                	je     0x37f4
    3793:	74 43                	je     0x37d8
    3795:	6f                   	outs   dx,WORD PTR ds:[si]
    3796:	75 72                	jne    0x380a
    3798:	61                   	popa
    3799:	6e                   	outs   dx,BYTE PTR ds:[si]
    379a:	74 13                	je     0x37af
    379c:	50                   	push   ax
    379d:	72 6f                	jb     0x380e
    379f:	64 75 69             	fs jne 0x380b
    37a2:	74 73                	je     0x3817
    37a4:	4f                   	dec    di
    37a5:	75 43                	jne    0x37ea
    37a7:	68 61 72             	push   0x7261
    37aa:	67 65 73 45          	addr32 gs jae 0x37f3
    37ae:	78 00                	js     0x37b0
    37b0:	00 00                	add    BYTE PTR [bx+si],al
    37b2:	00 15                	add    BYTE PTR [di],dl
    37b4:	50                   	push   ax
    37b5:	72 6f                	jb     0x3826
    37b7:	64 75 69             	fs jne 0x3823
    37ba:	74 73                	je     0x382f
    37bc:	45                   	inc    bp
    37bd:	78 63                	js     0x3822
    37bf:	65 70 74             	gs jo  0x3836
    37c2:	69 6f 6e 6e 65       	imul   bp,WORD PTR [bx+0x6e],0x656e
    37c7:	6c                   	ins    BYTE PTR es:[di],dx
    37c8:	73 16                	jae    0x37e0
    37ca:	43                   	inc    bx
    37cb:	68 61 72             	push   0x7261
    37ce:	67 65 73 45          	addr32 gs jae 0x3817
    37d2:	78 63                	js     0x3837
    37d4:	65 70 74             	gs jo  0x384b
    37d7:	69 6f 6e 6e 65       	imul   bp,WORD PTR [bx+0x6e],0x656e
    37dc:	6c                   	ins    BYTE PTR es:[di],dx
    37dd:	6c                   	ins    BYTE PTR es:[di],dx
    37de:	65 73 0d             	gs jae 0x37ee
    37e1:	52                   	push   dx
    37e2:	65 6d                	gs ins WORD PTR es:[di],dx
    37e4:	62 6f 75             	bound  bp,DWORD PTR [bx+0x75]
    37e7:	72 73                	jb     0x385c
    37e9:	41                   	inc    cx
    37ea:	73 73                	jae    0x385f
    37ec:	75 72                	jne    0x3860
    37ee:	05 49 6d             	add    ax,0x6d49
    37f1:	70 6f                	jo     0x3862
    37f3:	74 0e                	je     0x3803
    37f5:	52                   	push   dx
    37f6:	65 73 75             	gs jae 0x386e
    37f9:	6c                   	ins    BYTE PTR es:[di],dx
    37fa:	74 61                	je     0x385d
    37fc:	74 4e                	je     0x384c
    37fe:	65 74 53             	gs je  0x3854
    3801:	49                   	dec    cx
    3802:	47                   	inc    di
    3803:	55                   	push   bp
    3804:	89 e5                	mov    bp,sp
    3806:	b8 5e 01             	mov    ax,0x15e
    3809:	9a 44 04 4c 38       	call   0x384c:0x444
    380e:	81 ec 5e 01          	sub    sp,0x15e
    3812:	bf 51 34             	mov    di,0x3451
    3815:	0e                   	push   cs
    3816:	57                   	push   di
    3817:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    381a:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    381f:	06                   	push   es
    3820:	57                   	push   di
    3821:	9a 9b 3b 85 38       	call   0x3885:0x3b9b
    3826:	89 c7                	mov    di,ax
    3828:	8e c2                	mov    es,dx
    382a:	06                   	push   es
    382b:	57                   	push   di
    382c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    382f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3833:	9b dd 5e f8          	fstp   QWORD PTR [bp-0x8]
    3837:	90                   	nop
    3838:	9b                   	fwait
    3839:	9b 2e d9 06 59 34    	fld    DWORD PTR cs:0x3459
    383f:	9b dc 46 f8          	fadd   QWORD PTR [bp-0x8]
    3843:	9b 2e d9 06 59 34    	fld    DWORD PTR cs:0x3459
    3849:	9a b2 04 65 38       	call   0x3865:0x4b2
    384e:	9b dd 5e f0          	fstp   QWORD PTR [bp-0x10]
    3852:	90                   	nop
    3853:	9b                   	fwait
    3854:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3857:	ff 76 0a             	push   WORD PTR [bp+0xa]
    385a:	bf 38 01             	mov    di,0x138
    385d:	b8 ff ff             	mov    ax,0xffff
    3860:	50                   	push   ax
    3861:	57                   	push   di
    3862:	9a 73 22 af 45       	call   0x45af:0x2273
    3867:	89 c7                	mov    di,ax
    3869:	8e c2                	mov    es,dx
    386b:	89 be d4 fe          	mov    WORD PTR [bp-0x12c],di
    386f:	8c 86 d6 fe          	mov    WORD PTR [bp-0x12a],es
    3873:	bf 5d 34             	mov    di,0x345d
    3876:	0e                   	push   cs
    3877:	57                   	push   di
    3878:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    387b:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3880:	06                   	push   es
    3881:	57                   	push   di
    3882:	9a 9b 3b b8 38       	call   0x38b8:0x3b9b
    3887:	89 c7                	mov    di,ax
    3889:	8e c2                	mov    es,dx
    388b:	06                   	push   es
    388c:	57                   	push   di
    388d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3890:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3894:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    3898:	89 96 d2 fe          	mov    WORD PTR [bp-0x12e],dx
    389c:	9b db 86 d0 fe       	fild   DWORD PTR [bp-0x130]
    38a1:	9b db be c6 fe       	fstp   TBYTE PTR [bp-0x13a]
    38a6:	bf 64 34             	mov    di,0x3464
    38a9:	0e                   	push   cs
    38aa:	57                   	push   di
    38ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38ae:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    38b3:	06                   	push   es
    38b4:	57                   	push   di
    38b5:	9a 9b 3b f6 38       	call   0x38f6:0x3b9b
    38ba:	89 c7                	mov    di,ax
    38bc:	8e c2                	mov    es,dx
    38be:	06                   	push   es
    38bf:	57                   	push   di
    38c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    38c3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    38c7:	9b db ae c6 fe       	fld    TBYTE PTR [bp-0x13a]
    38cc:	9b de c9             	fmulp  st(1),st
    38cf:	83 ec 08             	sub    sp,0x8
    38d2:	89 e3                	mov    bx,sp
    38d4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    38d8:	90                   	nop
    38d9:	9b                   	fwait
    38da:	9a a6 2f 4e 39       	call   0x394e:0x2fa6
    38df:	9b db be ae fe       	fstp   TBYTE PTR [bp-0x152]
    38e4:	bf 5d 34             	mov    di,0x345d
    38e7:	0e                   	push   cs
    38e8:	57                   	push   di
    38e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38ec:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    38f1:	06                   	push   es
    38f2:	57                   	push   di
    38f3:	9a 9b 3b 29 39       	call   0x3929:0x3b9b
    38f8:	89 c7                	mov    di,ax
    38fa:	8e c2                	mov    es,dx
    38fc:	06                   	push   es
    38fd:	57                   	push   di
    38fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3901:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3905:	89 86 c2 fe          	mov    WORD PTR [bp-0x13e],ax
    3909:	89 96 c4 fe          	mov    WORD PTR [bp-0x13c],dx
    390d:	9b db 86 c2 fe       	fild   DWORD PTR [bp-0x13e]
    3912:	9b db be b8 fe       	fstp   TBYTE PTR [bp-0x148]
    3917:	bf 64 34             	mov    di,0x3464
    391a:	0e                   	push   cs
    391b:	57                   	push   di
    391c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    391f:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    3924:	06                   	push   es
    3925:	57                   	push   di
    3926:	9a 9b 3b 8c 39       	call   0x398c:0x3b9b
    392b:	89 c7                	mov    di,ax
    392d:	8e c2                	mov    es,dx
    392f:	06                   	push   es
    3930:	57                   	push   di
    3931:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3934:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3938:	9b db ae b8 fe       	fld    TBYTE PTR [bp-0x148]
    393d:	9b de c9             	fmulp  st(1),st
    3940:	83 ec 08             	sub    sp,0x8
    3943:	89 e3                	mov    bx,sp
    3945:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3949:	90                   	nop
    394a:	9b                   	fwait
    394b:	9a a6 2f 72 39       	call   0x3972:0x2fa6
    3950:	9b db ae ae fe       	fld    TBYTE PTR [bp-0x152]
    3955:	9b de c1             	faddp  st(1),st
    3958:	9b dd 9e d8 fe       	fstp   QWORD PTR [bp-0x128]
    395d:	90                   	nop
    395e:	9b                   	fwait
    395f:	ff b6 de fe          	push   WORD PTR [bp-0x122]
    3963:	ff b6 dc fe          	push   WORD PTR [bp-0x124]
    3967:	ff b6 da fe          	push   WORD PTR [bp-0x126]
    396b:	ff b6 d8 fe          	push   WORD PTR [bp-0x128]
    396f:	9a a6 2f e4 39       	call   0x39e4:0x2fa6
    3974:	9b dd 5e e8          	fstp   QWORD PTR [bp-0x18]
    3978:	90                   	nop
    3979:	9b                   	fwait
    397a:	bf 69 34             	mov    di,0x3469
    397d:	0e                   	push   cs
    397e:	57                   	push   di
    397f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3982:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3987:	06                   	push   es
    3988:	57                   	push   di
    3989:	9a 9b 3b bf 39       	call   0x39bf:0x3b9b
    398e:	89 c7                	mov    di,ax
    3990:	8e c2                	mov    es,dx
    3992:	06                   	push   es
    3993:	57                   	push   di
    3994:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3997:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    399b:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    399f:	89 96 d2 fe          	mov    WORD PTR [bp-0x12e],dx
    39a3:	9b db 86 d0 fe       	fild   DWORD PTR [bp-0x130]
    39a8:	9b db be c6 fe       	fstp   TBYTE PTR [bp-0x13a]
    39ad:	bf 7a 34             	mov    di,0x347a
    39b0:	0e                   	push   cs
    39b1:	57                   	push   di
    39b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39b5:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    39ba:	06                   	push   es
    39bb:	57                   	push   di
    39bc:	9a 9b 3b fd 39       	call   0x39fd:0x3b9b
    39c1:	89 c7                	mov    di,ax
    39c3:	8e c2                	mov    es,dx
    39c5:	06                   	push   es
    39c6:	57                   	push   di
    39c7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39ca:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    39ce:	9b db ae c6 fe       	fld    TBYTE PTR [bp-0x13a]
    39d3:	9b de c9             	fmulp  st(1),st
    39d6:	83 ec 08             	sub    sp,0x8
    39d9:	89 e3                	mov    bx,sp
    39db:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    39df:	90                   	nop
    39e0:	9b                   	fwait
    39e1:	9a a6 2f 55 3a       	call   0x3a55:0x2fa6
    39e6:	9b db be ae fe       	fstp   TBYTE PTR [bp-0x152]
    39eb:	bf 69 34             	mov    di,0x3469
    39ee:	0e                   	push   cs
    39ef:	57                   	push   di
    39f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39f3:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    39f8:	06                   	push   es
    39f9:	57                   	push   di
    39fa:	9a 9b 3b 30 3a       	call   0x3a30:0x3b9b
    39ff:	89 c7                	mov    di,ax
    3a01:	8e c2                	mov    es,dx
    3a03:	06                   	push   es
    3a04:	57                   	push   di
    3a05:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a08:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3a0c:	89 86 c2 fe          	mov    WORD PTR [bp-0x13e],ax
    3a10:	89 96 c4 fe          	mov    WORD PTR [bp-0x13c],dx
    3a14:	9b db 86 c2 fe       	fild   DWORD PTR [bp-0x13e]
    3a19:	9b db be b8 fe       	fstp   TBYTE PTR [bp-0x148]
    3a1e:	bf 7a 34             	mov    di,0x347a
    3a21:	0e                   	push   cs
    3a22:	57                   	push   di
    3a23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a26:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3a2b:	06                   	push   es
    3a2c:	57                   	push   di
    3a2d:	9a 9b 3b 93 3a       	call   0x3a93:0x3b9b
    3a32:	89 c7                	mov    di,ax
    3a34:	8e c2                	mov    es,dx
    3a36:	06                   	push   es
    3a37:	57                   	push   di
    3a38:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a3b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3a3f:	9b db ae b8 fe       	fld    TBYTE PTR [bp-0x148]
    3a44:	9b de c9             	fmulp  st(1),st
    3a47:	83 ec 08             	sub    sp,0x8
    3a4a:	89 e3                	mov    bx,sp
    3a4c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3a50:	90                   	nop
    3a51:	9b                   	fwait
    3a52:	9a a6 2f 79 3a       	call   0x3a79:0x2fa6
    3a57:	9b db ae ae fe       	fld    TBYTE PTR [bp-0x152]
    3a5c:	9b de c1             	faddp  st(1),st
    3a5f:	9b dd 9e d8 fe       	fstp   QWORD PTR [bp-0x128]
    3a64:	90                   	nop
    3a65:	9b                   	fwait
    3a66:	ff b6 de fe          	push   WORD PTR [bp-0x122]
    3a6a:	ff b6 dc fe          	push   WORD PTR [bp-0x124]
    3a6e:	ff b6 da fe          	push   WORD PTR [bp-0x126]
    3a72:	ff b6 d8 fe          	push   WORD PTR [bp-0x128]
    3a76:	9a a6 2f eb 3a       	call   0x3aeb:0x2fa6
    3a7b:	9b dd 5e e0          	fstp   QWORD PTR [bp-0x20]
    3a7f:	90                   	nop
    3a80:	9b                   	fwait
    3a81:	bf 8c 34             	mov    di,0x348c
    3a84:	0e                   	push   cs
    3a85:	57                   	push   di
    3a86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a89:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3a8e:	06                   	push   es
    3a8f:	57                   	push   di
    3a90:	9a 9b 3b c6 3a       	call   0x3ac6:0x3b9b
    3a95:	89 c7                	mov    di,ax
    3a97:	8e c2                	mov    es,dx
    3a99:	06                   	push   es
    3a9a:	57                   	push   di
    3a9b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a9e:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3aa2:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    3aa6:	89 96 d2 fe          	mov    WORD PTR [bp-0x12e],dx
    3aaa:	9b db 86 d0 fe       	fild   DWORD PTR [bp-0x130]
    3aaf:	9b db be c6 fe       	fstp   TBYTE PTR [bp-0x13a]
    3ab4:	bf 99 34             	mov    di,0x3499
    3ab7:	0e                   	push   cs
    3ab8:	57                   	push   di
    3ab9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3abc:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3ac1:	06                   	push   es
    3ac2:	57                   	push   di
    3ac3:	9a 9b 3b 04 3b       	call   0x3b04:0x3b9b
    3ac8:	89 c7                	mov    di,ax
    3aca:	8e c2                	mov    es,dx
    3acc:	06                   	push   es
    3acd:	57                   	push   di
    3ace:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ad1:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ad5:	9b db ae c6 fe       	fld    TBYTE PTR [bp-0x13a]
    3ada:	9b de c9             	fmulp  st(1),st
    3add:	83 ec 08             	sub    sp,0x8
    3ae0:	89 e3                	mov    bx,sp
    3ae2:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3ae6:	90                   	nop
    3ae7:	9b                   	fwait
    3ae8:	9a a6 2f 5c 3b       	call   0x3b5c:0x2fa6
    3aed:	9b db be ae fe       	fstp   TBYTE PTR [bp-0x152]
    3af2:	bf 8c 34             	mov    di,0x348c
    3af5:	0e                   	push   cs
    3af6:	57                   	push   di
    3af7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3afa:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3aff:	06                   	push   es
    3b00:	57                   	push   di
    3b01:	9a 9b 3b 37 3b       	call   0x3b37:0x3b9b
    3b06:	89 c7                	mov    di,ax
    3b08:	8e c2                	mov    es,dx
    3b0a:	06                   	push   es
    3b0b:	57                   	push   di
    3b0c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b0f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3b13:	89 86 c2 fe          	mov    WORD PTR [bp-0x13e],ax
    3b17:	89 96 c4 fe          	mov    WORD PTR [bp-0x13c],dx
    3b1b:	9b db 86 c2 fe       	fild   DWORD PTR [bp-0x13e]
    3b20:	9b db be b8 fe       	fstp   TBYTE PTR [bp-0x148]
    3b25:	bf 99 34             	mov    di,0x3499
    3b28:	0e                   	push   cs
    3b29:	57                   	push   di
    3b2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b2d:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3b32:	06                   	push   es
    3b33:	57                   	push   di
    3b34:	9a 9b 3b 9a 3b       	call   0x3b9a:0x3b9b
    3b39:	89 c7                	mov    di,ax
    3b3b:	8e c2                	mov    es,dx
    3b3d:	06                   	push   es
    3b3e:	57                   	push   di
    3b3f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b42:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3b46:	9b db ae b8 fe       	fld    TBYTE PTR [bp-0x148]
    3b4b:	9b de c9             	fmulp  st(1),st
    3b4e:	83 ec 08             	sub    sp,0x8
    3b51:	89 e3                	mov    bx,sp
    3b53:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3b57:	90                   	nop
    3b58:	9b                   	fwait
    3b59:	9a a6 2f 80 3b       	call   0x3b80:0x2fa6
    3b5e:	9b db ae ae fe       	fld    TBYTE PTR [bp-0x152]
    3b63:	9b de c1             	faddp  st(1),st
    3b66:	9b dd 9e d8 fe       	fstp   QWORD PTR [bp-0x128]
    3b6b:	90                   	nop
    3b6c:	9b                   	fwait
    3b6d:	ff b6 de fe          	push   WORD PTR [bp-0x122]
    3b71:	ff b6 dc fe          	push   WORD PTR [bp-0x124]
    3b75:	ff b6 da fe          	push   WORD PTR [bp-0x126]
    3b79:	ff b6 d8 fe          	push   WORD PTR [bp-0x128]
    3b7d:	9a a6 2f 13 3c       	call   0x3c13:0x2fa6
    3b82:	9b dd 5e d8          	fstp   QWORD PTR [bp-0x28]
    3b86:	90                   	nop
    3b87:	9b                   	fwait
    3b88:	bf a7 34             	mov    di,0x34a7
    3b8b:	0e                   	push   cs
    3b8c:	57                   	push   di
    3b8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b90:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3b95:	06                   	push   es
    3b96:	57                   	push   di
    3b97:	9a 9b 3b c0 3b       	call   0x3bc0:0x3b9b
    3b9c:	89 c7                	mov    di,ax
    3b9e:	8e c2                	mov    es,dx
    3ba0:	06                   	push   es
    3ba1:	57                   	push   di
    3ba2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ba5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ba9:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    3bae:	bf a7 34             	mov    di,0x34a7
    3bb1:	0e                   	push   cs
    3bb2:	57                   	push   di
    3bb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bb6:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    3bbb:	06                   	push   es
    3bbc:	57                   	push   di
    3bbd:	9a 9b 3b ee 3b       	call   0x3bee:0x3b9b
    3bc2:	89 c7                	mov    di,ax
    3bc4:	8e c2                	mov    es,dx
    3bc6:	06                   	push   es
    3bc7:	57                   	push   di
    3bc8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bcb:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3bcf:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    3bd4:	9b de e1             	fsubrp st(1),st
    3bd7:	9b db be c0 fe       	fstp   TBYTE PTR [bp-0x140]
    3bdc:	bf a7 34             	mov    di,0x34a7
    3bdf:	0e                   	push   cs
    3be0:	57                   	push   di
    3be1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3be4:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3be9:	06                   	push   es
    3bea:	57                   	push   di
    3beb:	9a 9b 3b 2c 3c       	call   0x3c2c:0x3b9b
    3bf0:	89 c7                	mov    di,ax
    3bf2:	8e c2                	mov    es,dx
    3bf4:	06                   	push   es
    3bf5:	57                   	push   di
    3bf6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bf9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3bfd:	9b db ae c0 fe       	fld    TBYTE PTR [bp-0x140]
    3c02:	9b de c1             	faddp  st(1),st
    3c05:	83 ec 08             	sub    sp,0x8
    3c08:	89 e3                	mov    bx,sp
    3c0a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3c0e:	90                   	nop
    3c0f:	9b                   	fwait
    3c10:	9a a6 2f 5d 3c       	call   0x3c5d:0x2fa6
    3c15:	9b db be b6 fe       	fstp   TBYTE PTR [bp-0x14a]
    3c1a:	bf a7 34             	mov    di,0x34a7
    3c1d:	0e                   	push   cs
    3c1e:	57                   	push   di
    3c1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c22:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    3c27:	06                   	push   es
    3c28:	57                   	push   di
    3c29:	9a 9b 3b 95 3c       	call   0x3c95:0x3b9b
    3c2e:	89 c7                	mov    di,ax
    3c30:	8e c2                	mov    es,dx
    3c32:	06                   	push   es
    3c33:	57                   	push   di
    3c34:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c37:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3c3b:	9b db ae b6 fe       	fld    TBYTE PTR [bp-0x14a]
    3c40:	9b de e1             	fsubrp st(1),st
    3c43:	9b dd 9e d8 fe       	fstp   QWORD PTR [bp-0x128]
    3c48:	90                   	nop
    3c49:	9b                   	fwait
    3c4a:	ff b6 de fe          	push   WORD PTR [bp-0x122]
    3c4e:	ff b6 dc fe          	push   WORD PTR [bp-0x124]
    3c52:	ff b6 da fe          	push   WORD PTR [bp-0x126]
    3c56:	ff b6 d8 fe          	push   WORD PTR [bp-0x128]
    3c5a:	9a a6 2f 77 3d       	call   0x3d77:0x2fa6
    3c5f:	9b dd 5e d0          	fstp   QWORD PTR [bp-0x30]
    3c63:	90                   	nop
    3c64:	9b 9b dd 46 e8       	fld    QWORD PTR [bp-0x18]
    3c69:	9b dc 46 e0          	fadd   QWORD PTR [bp-0x20]
    3c6d:	9b dc 46 d8          	fadd   QWORD PTR [bp-0x28]
    3c71:	9b dc 46 d0          	fadd   QWORD PTR [bp-0x30]
    3c75:	9b dd 5e c8          	fstp   QWORD PTR [bp-0x38]
    3c79:	90                   	nop
    3c7a:	9b                   	fwait
    3c7b:	ff 76 ee             	push   WORD PTR [bp-0x12]
    3c7e:	ff 76 ec             	push   WORD PTR [bp-0x14]
    3c81:	ff 76 ea             	push   WORD PTR [bp-0x16]
    3c84:	ff 76 e8             	push   WORD PTR [bp-0x18]
    3c87:	bf b3 34             	mov    di,0x34b3
    3c8a:	0e                   	push   cs
    3c8b:	57                   	push   di
    3c8c:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    3c90:	06                   	push   es
    3c91:	57                   	push   di
    3c92:	9a 9b 3b be 3c       	call   0x3cbe:0x3b9b
    3c97:	89 c7                	mov    di,ax
    3c99:	8e c2                	mov    es,dx
    3c9b:	06                   	push   es
    3c9c:	57                   	push   di
    3c9d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ca0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3ca4:	ff 76 e6             	push   WORD PTR [bp-0x1a]
    3ca7:	ff 76 e4             	push   WORD PTR [bp-0x1c]
    3caa:	ff 76 e2             	push   WORD PTR [bp-0x1e]
    3cad:	ff 76 e0             	push   WORD PTR [bp-0x20]
    3cb0:	bf c5 34             	mov    di,0x34c5
    3cb3:	0e                   	push   cs
    3cb4:	57                   	push   di
    3cb5:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    3cb9:	06                   	push   es
    3cba:	57                   	push   di
    3cbb:	9a 9b 3b e7 3c       	call   0x3ce7:0x3b9b
    3cc0:	89 c7                	mov    di,ax
    3cc2:	8e c2                	mov    es,dx
    3cc4:	06                   	push   es
    3cc5:	57                   	push   di
    3cc6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cc9:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3ccd:	ff 76 de             	push   WORD PTR [bp-0x22]
    3cd0:	ff 76 dc             	push   WORD PTR [bp-0x24]
    3cd3:	ff 76 da             	push   WORD PTR [bp-0x26]
    3cd6:	ff 76 d8             	push   WORD PTR [bp-0x28]
    3cd9:	bf d7 34             	mov    di,0x34d7
    3cdc:	0e                   	push   cs
    3cdd:	57                   	push   di
    3cde:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    3ce2:	06                   	push   es
    3ce3:	57                   	push   di
    3ce4:	9a 9b 3b 10 3d       	call   0x3d10:0x3b9b
    3ce9:	89 c7                	mov    di,ax
    3ceb:	8e c2                	mov    es,dx
    3ced:	06                   	push   es
    3cee:	57                   	push   di
    3cef:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cf2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3cf6:	ff 76 d6             	push   WORD PTR [bp-0x2a]
    3cf9:	ff 76 d4             	push   WORD PTR [bp-0x2c]
    3cfc:	ff 76 d2             	push   WORD PTR [bp-0x2e]
    3cff:	ff 76 d0             	push   WORD PTR [bp-0x30]
    3d02:	bf f3 34             	mov    di,0x34f3
    3d05:	0e                   	push   cs
    3d06:	57                   	push   di
    3d07:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    3d0b:	06                   	push   es
    3d0c:	57                   	push   di
    3d0d:	9a 9b 3b 39 3d       	call   0x3d39:0x3b9b
    3d12:	89 c7                	mov    di,ax
    3d14:	8e c2                	mov    es,dx
    3d16:	06                   	push   es
    3d17:	57                   	push   di
    3d18:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d1b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3d1f:	ff 76 ce             	push   WORD PTR [bp-0x32]
    3d22:	ff 76 cc             	push   WORD PTR [bp-0x34]
    3d25:	ff 76 ca             	push   WORD PTR [bp-0x36]
    3d28:	ff 76 c8             	push   WORD PTR [bp-0x38]
    3d2b:	bf 06 35             	mov    di,0x3506
    3d2e:	0e                   	push   cs
    3d2f:	57                   	push   di
    3d30:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    3d34:	06                   	push   es
    3d35:	57                   	push   di
    3d36:	9a 9b 3b 5a 3d       	call   0x3d5a:0x3b9b
    3d3b:	89 c7                	mov    di,ax
    3d3d:	8e c2                	mov    es,dx
    3d3f:	06                   	push   es
    3d40:	57                   	push   di
    3d41:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d44:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3d48:	bf 1d 35             	mov    di,0x351d
    3d4b:	0e                   	push   cs
    3d4c:	57                   	push   di
    3d4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d50:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    3d55:	06                   	push   es
    3d56:	57                   	push   di
    3d57:	9a 9b 3b 90 3d       	call   0x3d90:0x3b9b
    3d5c:	89 c7                	mov    di,ax
    3d5e:	8e c2                	mov    es,dx
    3d60:	06                   	push   es
    3d61:	57                   	push   di
    3d62:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d65:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3d69:	83 ec 08             	sub    sp,0x8
    3d6c:	89 e3                	mov    bx,sp
    3d6e:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3d72:	90                   	nop
    3d73:	9b                   	fwait
    3d74:	9a a6 2f ad 3d       	call   0x3dad:0x2fa6
    3d79:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    3d7e:	bf 1d 35             	mov    di,0x351d
    3d81:	0e                   	push   cs
    3d82:	57                   	push   di
    3d83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d86:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    3d8b:	06                   	push   es
    3d8c:	57                   	push   di
    3d8d:	9a 9b 3b d7 3d       	call   0x3dd7:0x3b9b
    3d92:	89 c7                	mov    di,ax
    3d94:	8e c2                	mov    es,dx
    3d96:	06                   	push   es
    3d97:	57                   	push   di
    3d98:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d9b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3d9f:	83 ec 08             	sub    sp,0x8
    3da2:	89 e3                	mov    bx,sp
    3da4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3da8:	90                   	nop
    3da9:	9b                   	fwait
    3daa:	9a a6 2f 93 3e       	call   0x3e93:0x2fa6
    3daf:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    3db4:	9b de c1             	faddp  st(1),st
    3db7:	9b dd 5e c0          	fstp   QWORD PTR [bp-0x40]
    3dbb:	90                   	nop
    3dbc:	9b                   	fwait
    3dbd:	ff 76 c6             	push   WORD PTR [bp-0x3a]
    3dc0:	ff 76 c4             	push   WORD PTR [bp-0x3c]
    3dc3:	ff 76 c2             	push   WORD PTR [bp-0x3e]
    3dc6:	ff 76 c0             	push   WORD PTR [bp-0x40]
    3dc9:	bf 31 35             	mov    di,0x3531
    3dcc:	0e                   	push   cs
    3dcd:	57                   	push   di
    3dce:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    3dd2:	06                   	push   es
    3dd3:	57                   	push   di
    3dd4:	9a 9b 3b f8 3d       	call   0x3df8:0x3b9b
    3dd9:	89 c7                	mov    di,ax
    3ddb:	8e c2                	mov    es,dx
    3ddd:	06                   	push   es
    3dde:	57                   	push   di
    3ddf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3de2:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3de6:	bf 42 35             	mov    di,0x3542
    3de9:	0e                   	push   cs
    3dea:	57                   	push   di
    3deb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dee:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    3df3:	06                   	push   es
    3df4:	57                   	push   di
    3df5:	9a 9b 3b 1e 3e       	call   0x3e1e:0x3b9b
    3dfa:	89 c7                	mov    di,ax
    3dfc:	8e c2                	mov    es,dx
    3dfe:	06                   	push   es
    3dff:	57                   	push   di
    3e00:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e03:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e07:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    3e0c:	bf 42 35             	mov    di,0x3542
    3e0f:	0e                   	push   cs
    3e10:	57                   	push   di
    3e11:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e14:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    3e19:	06                   	push   es
    3e1a:	57                   	push   di
    3e1b:	9a 9b 3b 55 3e       	call   0x3e55:0x3b9b
    3e20:	89 c7                	mov    di,ax
    3e22:	8e c2                	mov    es,dx
    3e24:	06                   	push   es
    3e25:	57                   	push   di
    3e26:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e29:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e2d:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    3e32:	9b de c1             	faddp  st(1),st
    3e35:	9b dd 5e b8          	fstp   QWORD PTR [bp-0x48]
    3e39:	90                   	nop
    3e3a:	9b                   	fwait
    3e3b:	ff 76 be             	push   WORD PTR [bp-0x42]
    3e3e:	ff 76 bc             	push   WORD PTR [bp-0x44]
    3e41:	ff 76 ba             	push   WORD PTR [bp-0x46]
    3e44:	ff 76 b8             	push   WORD PTR [bp-0x48]
    3e47:	bf 52 35             	mov    di,0x3552
    3e4a:	0e                   	push   cs
    3e4b:	57                   	push   di
    3e4c:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    3e50:	06                   	push   es
    3e51:	57                   	push   di
    3e52:	9a 9b 3b 76 3e       	call   0x3e76:0x3b9b
    3e57:	89 c7                	mov    di,ax
    3e59:	8e c2                	mov    es,dx
    3e5b:	06                   	push   es
    3e5c:	57                   	push   di
    3e5d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e60:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3e64:	bf 5a 35             	mov    di,0x355a
    3e67:	0e                   	push   cs
    3e68:	57                   	push   di
    3e69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e6c:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    3e71:	06                   	push   es
    3e72:	57                   	push   di
    3e73:	9a 9b 3b ac 3e       	call   0x3eac:0x3b9b
    3e78:	89 c7                	mov    di,ax
    3e7a:	8e c2                	mov    es,dx
    3e7c:	06                   	push   es
    3e7d:	57                   	push   di
    3e7e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e81:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3e85:	83 ec 08             	sub    sp,0x8
    3e88:	89 e3                	mov    bx,sp
    3e8a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3e8e:	90                   	nop
    3e8f:	9b                   	fwait
    3e90:	9a a6 2f c9 3e       	call   0x3ec9:0x2fa6
    3e95:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    3e9a:	bf 64 35             	mov    di,0x3564
    3e9d:	0e                   	push   cs
    3e9e:	57                   	push   di
    3e9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ea2:	26 c4 bd b0 01       	les    di,DWORD PTR es:[di+0x1b0]
    3ea7:	06                   	push   es
    3ea8:	57                   	push   di
    3ea9:	9a 9b 3b ea 3e       	call   0x3eea:0x3b9b
    3eae:	89 c7                	mov    di,ax
    3eb0:	8e c2                	mov    es,dx
    3eb2:	06                   	push   es
    3eb3:	57                   	push   di
    3eb4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3eb7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ebb:	83 ec 08             	sub    sp,0x8
    3ebe:	89 e3                	mov    bx,sp
    3ec0:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3ec4:	90                   	nop
    3ec5:	9b                   	fwait
    3ec6:	9a a6 2f 07 3f       	call   0x3f07:0x2fa6
    3ecb:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    3ed0:	9b de c1             	faddp  st(1),st
    3ed3:	9b db be c0 fe       	fstp   TBYTE PTR [bp-0x140]
    3ed8:	bf 5a 35             	mov    di,0x355a
    3edb:	0e                   	push   cs
    3edc:	57                   	push   di
    3edd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ee0:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    3ee5:	06                   	push   es
    3ee6:	57                   	push   di
    3ee7:	9a 9b 3b 28 3f       	call   0x3f28:0x3b9b
    3eec:	89 c7                	mov    di,ax
    3eee:	8e c2                	mov    es,dx
    3ef0:	06                   	push   es
    3ef1:	57                   	push   di
    3ef2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ef5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3ef9:	83 ec 08             	sub    sp,0x8
    3efc:	89 e3                	mov    bx,sp
    3efe:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f02:	90                   	nop
    3f03:	9b                   	fwait
    3f04:	9a a6 2f 45 3f       	call   0x3f45:0x2fa6
    3f09:	9b db ae c0 fe       	fld    TBYTE PTR [bp-0x140]
    3f0e:	9b de c1             	faddp  st(1),st
    3f11:	9b db be b6 fe       	fstp   TBYTE PTR [bp-0x14a]
    3f16:	bf 64 35             	mov    di,0x3564
    3f19:	0e                   	push   cs
    3f1a:	57                   	push   di
    3f1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f1e:	26 c4 bd b4 01       	les    di,DWORD PTR es:[di+0x1b4]
    3f23:	06                   	push   es
    3f24:	57                   	push   di
    3f25:	9a 9b 3b 6f 3f       	call   0x3f6f:0x3b9b
    3f2a:	89 c7                	mov    di,ax
    3f2c:	8e c2                	mov    es,dx
    3f2e:	06                   	push   es
    3f2f:	57                   	push   di
    3f30:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f33:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3f37:	83 ec 08             	sub    sp,0x8
    3f3a:	89 e3                	mov    bx,sp
    3f3c:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3f40:	90                   	nop
    3f41:	9b                   	fwait
    3f42:	9a a6 2f e8 3f       	call   0x3fe8:0x2fa6
    3f47:	9b db ae b6 fe       	fld    TBYTE PTR [bp-0x14a]
    3f4c:	9b de c1             	faddp  st(1),st
    3f4f:	9b dd 5e b0          	fstp   QWORD PTR [bp-0x50]
    3f53:	90                   	nop
    3f54:	9b                   	fwait
    3f55:	ff 76 b6             	push   WORD PTR [bp-0x4a]
    3f58:	ff 76 b4             	push   WORD PTR [bp-0x4c]
    3f5b:	ff 76 b2             	push   WORD PTR [bp-0x4e]
    3f5e:	ff 76 b0             	push   WORD PTR [bp-0x50]
    3f61:	bf 76 35             	mov    di,0x3576
    3f64:	0e                   	push   cs
    3f65:	57                   	push   di
    3f66:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    3f6a:	06                   	push   es
    3f6b:	57                   	push   di
    3f6c:	9a 9b 3b 90 3f       	call   0x3f90:0x3b9b
    3f71:	89 c7                	mov    di,ax
    3f73:	8e c2                	mov    es,dx
    3f75:	06                   	push   es
    3f76:	57                   	push   di
    3f77:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f7a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    3f7e:	bf 85 35             	mov    di,0x3585
    3f81:	0e                   	push   cs
    3f82:	57                   	push   di
    3f83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f86:	26 c4 bd 40 02       	les    di,DWORD PTR es:[di+0x240]
    3f8b:	06                   	push   es
    3f8c:	57                   	push   di
    3f8d:	9a 9b 3b c3 3f       	call   0x3fc3:0x3b9b
    3f92:	89 c7                	mov    di,ax
    3f94:	8e c2                	mov    es,dx
    3f96:	06                   	push   es
    3f97:	57                   	push   di
    3f98:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f9b:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    3f9f:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    3fa3:	89 96 d2 fe          	mov    WORD PTR [bp-0x12e],dx
    3fa7:	9b db 86 d0 fe       	fild   DWORD PTR [bp-0x130]
    3fac:	9b db be c6 fe       	fstp   TBYTE PTR [bp-0x13a]
    3fb1:	bf 8e 35             	mov    di,0x358e
    3fb4:	0e                   	push   cs
    3fb5:	57                   	push   di
    3fb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fb9:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    3fbe:	06                   	push   es
    3fbf:	57                   	push   di
    3fc0:	9a 9b 3b 01 40       	call   0x4001:0x3b9b
    3fc5:	89 c7                	mov    di,ax
    3fc7:	8e c2                	mov    es,dx
    3fc9:	06                   	push   es
    3fca:	57                   	push   di
    3fcb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3fce:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    3fd2:	9b db ae c6 fe       	fld    TBYTE PTR [bp-0x13a]
    3fd7:	9b de c9             	fmulp  st(1),st
    3fda:	83 ec 08             	sub    sp,0x8
    3fdd:	89 e3                	mov    bx,sp
    3fdf:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    3fe3:	90                   	nop
    3fe4:	9b                   	fwait
    3fe5:	9a a6 2f 59 40       	call   0x4059:0x2fa6
    3fea:	9b db be ae fe       	fstp   TBYTE PTR [bp-0x152]
    3fef:	bf 85 35             	mov    di,0x3585
    3ff2:	0e                   	push   cs
    3ff3:	57                   	push   di
    3ff4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ff7:	26 c4 bd 44 02       	les    di,DWORD PTR es:[di+0x244]
    3ffc:	06                   	push   es
    3ffd:	57                   	push   di
    3ffe:	9a 9b 3b 34 40       	call   0x4034:0x3b9b
    4003:	89 c7                	mov    di,ax
    4005:	8e c2                	mov    es,dx
    4007:	06                   	push   es
    4008:	57                   	push   di
    4009:	26 c4 3d             	les    di,DWORD PTR es:[di]
    400c:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    4010:	89 86 c2 fe          	mov    WORD PTR [bp-0x13e],ax
    4014:	89 96 c4 fe          	mov    WORD PTR [bp-0x13c],dx
    4018:	9b db 86 c2 fe       	fild   DWORD PTR [bp-0x13e]
    401d:	9b db be b8 fe       	fstp   TBYTE PTR [bp-0x148]
    4022:	bf 8e 35             	mov    di,0x358e
    4025:	0e                   	push   cs
    4026:	57                   	push   di
    4027:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    402a:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    402f:	06                   	push   es
    4030:	57                   	push   di
    4031:	9a 9b 3b 83 40       	call   0x4083:0x3b9b
    4036:	89 c7                	mov    di,ax
    4038:	8e c2                	mov    es,dx
    403a:	06                   	push   es
    403b:	57                   	push   di
    403c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    403f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4043:	9b db ae b8 fe       	fld    TBYTE PTR [bp-0x148]
    4048:	9b de c9             	fmulp  st(1),st
    404b:	83 ec 08             	sub    sp,0x8
    404e:	89 e3                	mov    bx,sp
    4050:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4054:	90                   	nop
    4055:	9b                   	fwait
    4056:	9a a6 2f bd 40       	call   0x40bd:0x2fa6
    405b:	9b db ae ae fe       	fld    TBYTE PTR [bp-0x152]
    4060:	9b de c1             	faddp  st(1),st
    4063:	9b dd 5e a8          	fstp   QWORD PTR [bp-0x58]
    4067:	90                   	nop
    4068:	9b                   	fwait
    4069:	ff 76 ae             	push   WORD PTR [bp-0x52]
    406c:	ff 76 ac             	push   WORD PTR [bp-0x54]
    406f:	ff 76 aa             	push   WORD PTR [bp-0x56]
    4072:	ff 76 a8             	push   WORD PTR [bp-0x58]
    4075:	bf 9d 35             	mov    di,0x359d
    4078:	0e                   	push   cs
    4079:	57                   	push   di
    407a:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    407e:	06                   	push   es
    407f:	57                   	push   di
    4080:	9a 9b 3b a0 40       	call   0x40a0:0x3b9b
    4085:	89 c7                	mov    di,ax
    4087:	8e c2                	mov    es,dx
    4089:	06                   	push   es
    408a:	57                   	push   di
    408b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    408e:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4092:	bf a8 35             	mov    di,0x35a8
    4095:	0e                   	push   cs
    4096:	57                   	push   di
    4097:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    409b:	06                   	push   es
    409c:	57                   	push   di
    409d:	9a 9b 3b d3 40       	call   0x40d3:0x3b9b
    40a2:	89 c7                	mov    di,ax
    40a4:	8e c2                	mov    es,dx
    40a6:	06                   	push   es
    40a7:	57                   	push   di
    40a8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40ab:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    40af:	83 ec 08             	sub    sp,0x8
    40b2:	89 e3                	mov    bx,sp
    40b4:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    40b8:	90                   	nop
    40b9:	9b                   	fwait
    40ba:	9a a6 2f f0 40       	call   0x40f0:0x2fa6
    40bf:	9b dd 5e a0          	fstp   QWORD PTR [bp-0x60]
    40c3:	90                   	nop
    40c4:	9b                   	fwait
    40c5:	bf bd 35             	mov    di,0x35bd
    40c8:	0e                   	push   cs
    40c9:	57                   	push   di
    40ca:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    40ce:	06                   	push   es
    40cf:	57                   	push   di
    40d0:	9a 9b 3b 06 41       	call   0x4106:0x3b9b
    40d5:	89 c7                	mov    di,ax
    40d7:	8e c2                	mov    es,dx
    40d9:	06                   	push   es
    40da:	57                   	push   di
    40db:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40de:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    40e2:	83 ec 08             	sub    sp,0x8
    40e5:	89 e3                	mov    bx,sp
    40e7:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    40eb:	90                   	nop
    40ec:	9b                   	fwait
    40ed:	9a a6 2f 23 41       	call   0x4123:0x2fa6
    40f2:	9b dd 5e 98          	fstp   QWORD PTR [bp-0x68]
    40f6:	90                   	nop
    40f7:	9b                   	fwait
    40f8:	bf c9 35             	mov    di,0x35c9
    40fb:	0e                   	push   cs
    40fc:	57                   	push   di
    40fd:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4101:	06                   	push   es
    4102:	57                   	push   di
    4103:	9a 9b 3b 39 41       	call   0x4139:0x3b9b
    4108:	89 c7                	mov    di,ax
    410a:	8e c2                	mov    es,dx
    410c:	06                   	push   es
    410d:	57                   	push   di
    410e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4111:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4115:	83 ec 08             	sub    sp,0x8
    4118:	89 e3                	mov    bx,sp
    411a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    411e:	90                   	nop
    411f:	9b                   	fwait
    4120:	9a a6 2f 7d 41       	call   0x417d:0x2fa6
    4125:	9b dd 5e 90          	fstp   QWORD PTR [bp-0x70]
    4129:	90                   	nop
    412a:	9b                   	fwait
    412b:	bf db 35             	mov    di,0x35db
    412e:	0e                   	push   cs
    412f:	57                   	push   di
    4130:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4134:	06                   	push   es
    4135:	57                   	push   di
    4136:	9a 9b 3b 60 41       	call   0x4160:0x3b9b
    413b:	89 c7                	mov    di,ax
    413d:	8e c2                	mov    es,dx
    413f:	06                   	push   es
    4140:	57                   	push   di
    4141:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4144:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4148:	9b dd 5e 88          	fstp   QWORD PTR [bp-0x78]
    414c:	90                   	nop
    414d:	9b                   	fwait
    414e:	bf eb 35             	mov    di,0x35eb
    4151:	0e                   	push   cs
    4152:	57                   	push   di
    4153:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4156:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    415b:	06                   	push   es
    415c:	57                   	push   di
    415d:	9a 9b 3b 9f 41       	call   0x419f:0x3b9b
    4162:	89 c7                	mov    di,ax
    4164:	8e c2                	mov    es,dx
    4166:	06                   	push   es
    4167:	57                   	push   di
    4168:	26 c4 3d             	les    di,DWORD PTR es:[di]
    416b:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    416f:	83 ec 08             	sub    sp,0x8
    4172:	89 e3                	mov    bx,sp
    4174:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4178:	90                   	nop
    4179:	9b                   	fwait
    417a:	9a a6 2f bf 45       	call   0x45bf:0x2fa6
    417f:	9b dd 5e 80          	fstp   QWORD PTR [bp-0x80]
    4183:	90                   	nop
    4184:	9b                   	fwait
    4185:	ff 76 86             	push   WORD PTR [bp-0x7a]
    4188:	ff 76 84             	push   WORD PTR [bp-0x7c]
    418b:	ff 76 82             	push   WORD PTR [bp-0x7e]
    418e:	ff 76 80             	push   WORD PTR [bp-0x80]
    4191:	bf eb 35             	mov    di,0x35eb
    4194:	0e                   	push   cs
    4195:	57                   	push   di
    4196:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    419a:	06                   	push   es
    419b:	57                   	push   di
    419c:	9a 9b 3b f7 41       	call   0x41f7:0x3b9b
    41a1:	89 c7                	mov    di,ax
    41a3:	8e c2                	mov    es,dx
    41a5:	06                   	push   es
    41a6:	57                   	push   di
    41a7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    41aa:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    41ae:	9b dd 46 c0          	fld    QWORD PTR [bp-0x40]
    41b2:	9b dc 46 b8          	fadd   QWORD PTR [bp-0x48]
    41b6:	9b dc 46 b0          	fadd   QWORD PTR [bp-0x50]
    41ba:	9b dc 46 a8          	fadd   QWORD PTR [bp-0x58]
    41be:	9b dc 46 a0          	fadd   QWORD PTR [bp-0x60]
    41c2:	9b dc 46 98          	fadd   QWORD PTR [bp-0x68]
    41c6:	9b dc 46 90          	fadd   QWORD PTR [bp-0x70]
    41ca:	9b dc 46 88          	fadd   QWORD PTR [bp-0x78]
    41ce:	9b dc 46 80          	fadd   QWORD PTR [bp-0x80]
    41d2:	9b dd 9e 78 ff       	fstp   QWORD PTR [bp-0x88]
    41d7:	90                   	nop
    41d8:	9b                   	fwait
    41d9:	ff b6 7e ff          	push   WORD PTR [bp-0x82]
    41dd:	ff b6 7c ff          	push   WORD PTR [bp-0x84]
    41e1:	ff b6 7a ff          	push   WORD PTR [bp-0x86]
    41e5:	ff b6 78 ff          	push   WORD PTR [bp-0x88]
    41e9:	bf f2 35             	mov    di,0x35f2
    41ec:	0e                   	push   cs
    41ed:	57                   	push   di
    41ee:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    41f2:	06                   	push   es
    41f3:	57                   	push   di
    41f4:	9a 9b 3b 34 42       	call   0x4234:0x3b9b
    41f9:	89 c7                	mov    di,ax
    41fb:	8e c2                	mov    es,dx
    41fd:	06                   	push   es
    41fe:	57                   	push   di
    41ff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4202:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4206:	9b dd 46 c8          	fld    QWORD PTR [bp-0x38]
    420a:	9b dc a6 78 ff       	fsub   QWORD PTR [bp-0x88]
    420f:	9b dd 9e 70 ff       	fstp   QWORD PTR [bp-0x90]
    4214:	90                   	nop
    4215:	9b                   	fwait
    4216:	ff b6 76 ff          	push   WORD PTR [bp-0x8a]
    421a:	ff b6 74 ff          	push   WORD PTR [bp-0x8c]
    421e:	ff b6 72 ff          	push   WORD PTR [bp-0x8e]
    4222:	ff b6 70 ff          	push   WORD PTR [bp-0x90]
    4226:	bf 04 36             	mov    di,0x3604
    4229:	0e                   	push   cs
    422a:	57                   	push   di
    422b:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    422f:	06                   	push   es
    4230:	57                   	push   di
    4231:	9a 9b 3b 55 42       	call   0x4255:0x3b9b
    4236:	89 c7                	mov    di,ax
    4238:	8e c2                	mov    es,dx
    423a:	06                   	push   es
    423b:	57                   	push   di
    423c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    423f:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4243:	bf 12 36             	mov    di,0x3612
    4246:	0e                   	push   cs
    4247:	57                   	push   di
    4248:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    424b:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    4250:	06                   	push   es
    4251:	57                   	push   di
    4252:	9a 9b 3b 89 42       	call   0x4289:0x3b9b
    4257:	89 c7                	mov    di,ax
    4259:	8e c2                	mov    es,dx
    425b:	06                   	push   es
    425c:	57                   	push   di
    425d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4260:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4264:	9b dd 9e 68 ff       	fstp   QWORD PTR [bp-0x98]
    4269:	90                   	nop
    426a:	9b                   	fwait
    426b:	ff b6 6e ff          	push   WORD PTR [bp-0x92]
    426f:	ff b6 6c ff          	push   WORD PTR [bp-0x94]
    4273:	ff b6 6a ff          	push   WORD PTR [bp-0x96]
    4277:	ff b6 68 ff          	push   WORD PTR [bp-0x98]
    427b:	bf 12 36             	mov    di,0x3612
    427e:	0e                   	push   cs
    427f:	57                   	push   di
    4280:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4284:	06                   	push   es
    4285:	57                   	push   di
    4286:	9a 9b 3b aa 42       	call   0x42aa:0x3b9b
    428b:	89 c7                	mov    di,ax
    428d:	8e c2                	mov    es,dx
    428f:	06                   	push   es
    4290:	57                   	push   di
    4291:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4294:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4298:	bf 1e 36             	mov    di,0x361e
    429b:	0e                   	push   cs
    429c:	57                   	push   di
    429d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42a0:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    42a5:	06                   	push   es
    42a6:	57                   	push   di
    42a7:	9a 9b 3b d0 42       	call   0x42d0:0x3b9b
    42ac:	89 c7                	mov    di,ax
    42ae:	8e c2                	mov    es,dx
    42b0:	06                   	push   es
    42b1:	57                   	push   di
    42b2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42b5:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    42b9:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    42be:	bf 1e 36             	mov    di,0x361e
    42c1:	0e                   	push   cs
    42c2:	57                   	push   di
    42c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42c6:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    42cb:	06                   	push   es
    42cc:	57                   	push   di
    42cd:	9a 9b 3b 0c 43       	call   0x430c:0x3b9b
    42d2:	89 c7                	mov    di,ax
    42d4:	8e c2                	mov    es,dx
    42d6:	06                   	push   es
    42d7:	57                   	push   di
    42d8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    42db:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    42df:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    42e4:	9b de c1             	faddp  st(1),st
    42e7:	9b dd 9e 60 ff       	fstp   QWORD PTR [bp-0xa0]
    42ec:	90                   	nop
    42ed:	9b                   	fwait
    42ee:	ff b6 66 ff          	push   WORD PTR [bp-0x9a]
    42f2:	ff b6 64 ff          	push   WORD PTR [bp-0x9c]
    42f6:	ff b6 62 ff          	push   WORD PTR [bp-0x9e]
    42fa:	ff b6 60 ff          	push   WORD PTR [bp-0xa0]
    42fe:	bf 30 36             	mov    di,0x3630
    4301:	0e                   	push   cs
    4302:	57                   	push   di
    4303:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4307:	06                   	push   es
    4308:	57                   	push   di
    4309:	9a 9b 3b 2d 43       	call   0x432d:0x3b9b
    430e:	89 c7                	mov    di,ax
    4310:	8e c2                	mov    es,dx
    4312:	06                   	push   es
    4313:	57                   	push   di
    4314:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4317:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    431b:	bf 42 36             	mov    di,0x3642
    431e:	0e                   	push   cs
    431f:	57                   	push   di
    4320:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4323:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    4328:	06                   	push   es
    4329:	57                   	push   di
    432a:	9a 9b 3b 53 43       	call   0x4353:0x3b9b
    432f:	89 c7                	mov    di,ax
    4331:	8e c2                	mov    es,dx
    4333:	06                   	push   es
    4334:	57                   	push   di
    4335:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4338:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    433c:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    4341:	bf 42 36             	mov    di,0x3642
    4344:	0e                   	push   cs
    4345:	57                   	push   di
    4346:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4349:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    434e:	06                   	push   es
    434f:	57                   	push   di
    4350:	9a 9b 3b 8f 43       	call   0x438f:0x3b9b
    4355:	89 c7                	mov    di,ax
    4357:	8e c2                	mov    es,dx
    4359:	06                   	push   es
    435a:	57                   	push   di
    435b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    435e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4362:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    4367:	9b de c1             	faddp  st(1),st
    436a:	9b dd 9e 58 ff       	fstp   QWORD PTR [bp-0xa8]
    436f:	90                   	nop
    4370:	9b                   	fwait
    4371:	ff b6 5e ff          	push   WORD PTR [bp-0xa2]
    4375:	ff b6 5c ff          	push   WORD PTR [bp-0xa4]
    4379:	ff b6 5a ff          	push   WORD PTR [bp-0xa6]
    437d:	ff b6 58 ff          	push   WORD PTR [bp-0xa8]
    4381:	bf 51 36             	mov    di,0x3651
    4384:	0e                   	push   cs
    4385:	57                   	push   di
    4386:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    438a:	06                   	push   es
    438b:	57                   	push   di
    438c:	9a 9b 3b ac 43       	call   0x43ac:0x3b9b
    4391:	89 c7                	mov    di,ax
    4393:	8e c2                	mov    es,dx
    4395:	06                   	push   es
    4396:	57                   	push   di
    4397:	26 c4 3d             	les    di,DWORD PTR es:[di]
    439a:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    439e:	bf 66 36             	mov    di,0x3666
    43a1:	0e                   	push   cs
    43a2:	57                   	push   di
    43a3:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    43a7:	06                   	push   es
    43a8:	57                   	push   di
    43a9:	9a 9b 3b d4 43       	call   0x43d4:0x3b9b
    43ae:	89 c7                	mov    di,ax
    43b0:	8e c2                	mov    es,dx
    43b2:	06                   	push   es
    43b3:	57                   	push   di
    43b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43b7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    43bb:	9b dd 9e 50 ff       	fstp   QWORD PTR [bp-0xb0]
    43c0:	90                   	nop
    43c1:	9b                   	fwait
    43c2:	bf 79 36             	mov    di,0x3679
    43c5:	0e                   	push   cs
    43c6:	57                   	push   di
    43c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43ca:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    43cf:	06                   	push   es
    43d0:	57                   	push   di
    43d1:	9a 9b 3b fc 43       	call   0x43fc:0x3b9b
    43d6:	89 c7                	mov    di,ax
    43d8:	8e c2                	mov    es,dx
    43da:	06                   	push   es
    43db:	57                   	push   di
    43dc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43df:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    43e3:	9b dd 9e 48 ff       	fstp   QWORD PTR [bp-0xb8]
    43e8:	90                   	nop
    43e9:	9b                   	fwait
    43ea:	bf 86 36             	mov    di,0x3686
    43ed:	0e                   	push   cs
    43ee:	57                   	push   di
    43ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43f2:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    43f7:	06                   	push   es
    43f8:	57                   	push   di
    43f9:	9a 9b 3b 24 44       	call   0x4424:0x3b9b
    43fe:	89 c7                	mov    di,ax
    4400:	8e c2                	mov    es,dx
    4402:	06                   	push   es
    4403:	57                   	push   di
    4404:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4407:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    440b:	9b dd 9e 40 ff       	fstp   QWORD PTR [bp-0xc0]
    4410:	90                   	nop
    4411:	9b                   	fwait
    4412:	bf 93 36             	mov    di,0x3693
    4415:	0e                   	push   cs
    4416:	57                   	push   di
    4417:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    441a:	26 c4 bd bc 01       	les    di,DWORD PTR es:[di+0x1bc]
    441f:	06                   	push   es
    4420:	57                   	push   di
    4421:	9a 9b 3b 87 44       	call   0x4487:0x3b9b
    4426:	89 c7                	mov    di,ax
    4428:	8e c2                	mov    es,dx
    442a:	06                   	push   es
    442b:	57                   	push   di
    442c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    442f:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4433:	9b dd 9e 38 ff       	fstp   QWORD PTR [bp-0xc8]
    4438:	90                   	nop
    4439:	9b 9b dd 86 70 ff    	fld    QWORD PTR [bp-0x90]
    443f:	9b dc 86 68 ff       	fadd   QWORD PTR [bp-0x98]
    4444:	9b dc a6 60 ff       	fsub   QWORD PTR [bp-0xa0]
    4449:	9b dc a6 58 ff       	fsub   QWORD PTR [bp-0xa8]
    444e:	9b dc a6 50 ff       	fsub   QWORD PTR [bp-0xb0]
    4453:	9b dc a6 48 ff       	fsub   QWORD PTR [bp-0xb8]
    4458:	9b dc a6 40 ff       	fsub   QWORD PTR [bp-0xc0]
    445d:	9b dc a6 38 ff       	fsub   QWORD PTR [bp-0xc8]
    4462:	9b dd 9e 30 ff       	fstp   QWORD PTR [bp-0xd0]
    4467:	90                   	nop
    4468:	9b                   	fwait
    4469:	ff b6 36 ff          	push   WORD PTR [bp-0xca]
    446d:	ff b6 34 ff          	push   WORD PTR [bp-0xcc]
    4471:	ff b6 32 ff          	push   WORD PTR [bp-0xce]
    4475:	ff b6 30 ff          	push   WORD PTR [bp-0xd0]
    4479:	bf a1 36             	mov    di,0x36a1
    447c:	0e                   	push   cs
    447d:	57                   	push   di
    447e:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4482:	06                   	push   es
    4483:	57                   	push   di
    4484:	9a 9b 3b a8 44       	call   0x44a8:0x3b9b
    4489:	89 c7                	mov    di,ax
    448b:	8e c2                	mov    es,dx
    448d:	06                   	push   es
    448e:	57                   	push   di
    448f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4492:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4496:	bf b9 36             	mov    di,0x36b9
    4499:	0e                   	push   cs
    449a:	57                   	push   di
    449b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    449e:	26 c4 bd c0 01       	les    di,DWORD PTR es:[di+0x1c0]
    44a3:	06                   	push   es
    44a4:	57                   	push   di
    44a5:	9a 9b 3b ce 44       	call   0x44ce:0x3b9b
    44aa:	89 c7                	mov    di,ax
    44ac:	8e c2                	mov    es,dx
    44ae:	06                   	push   es
    44af:	57                   	push   di
    44b0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44b3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    44b7:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    44bc:	bf b9 36             	mov    di,0x36b9
    44bf:	0e                   	push   cs
    44c0:	57                   	push   di
    44c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44c4:	26 c4 bd c4 01       	les    di,DWORD PTR es:[di+0x1c4]
    44c9:	06                   	push   es
    44ca:	57                   	push   di
    44cb:	9a 9b 3b 0a 45       	call   0x450a:0x3b9b
    44d0:	89 c7                	mov    di,ax
    44d2:	8e c2                	mov    es,dx
    44d4:	06                   	push   es
    44d5:	57                   	push   di
    44d6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44d9:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    44dd:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    44e2:	9b de c1             	faddp  st(1),st
    44e5:	9b dd 9e 28 ff       	fstp   QWORD PTR [bp-0xd8]
    44ea:	90                   	nop
    44eb:	9b                   	fwait
    44ec:	ff b6 2e ff          	push   WORD PTR [bp-0xd2]
    44f0:	ff b6 2c ff          	push   WORD PTR [bp-0xd4]
    44f4:	ff b6 2a ff          	push   WORD PTR [bp-0xd6]
    44f8:	ff b6 28 ff          	push   WORD PTR [bp-0xd8]
    44fc:	bf ca 36             	mov    di,0x36ca
    44ff:	0e                   	push   cs
    4500:	57                   	push   di
    4501:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4505:	06                   	push   es
    4506:	57                   	push   di
    4507:	9a 9b 3b 48 45       	call   0x4548:0x3b9b
    450c:	89 c7                	mov    di,ax
    450e:	8e c2                	mov    es,dx
    4510:	06                   	push   es
    4511:	57                   	push   di
    4512:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4515:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4519:	9b dd 86 30 ff       	fld    QWORD PTR [bp-0xd0]
    451e:	9b dc a6 28 ff       	fsub   QWORD PTR [bp-0xd8]
    4523:	9b dd 9e 20 ff       	fstp   QWORD PTR [bp-0xe0]
    4528:	90                   	nop
    4529:	9b                   	fwait
    452a:	ff b6 26 ff          	push   WORD PTR [bp-0xda]
    452e:	ff b6 24 ff          	push   WORD PTR [bp-0xdc]
    4532:	ff b6 22 ff          	push   WORD PTR [bp-0xde]
    4536:	ff b6 20 ff          	push   WORD PTR [bp-0xe0]
    453a:	bf e1 36             	mov    di,0x36e1
    453d:	0e                   	push   cs
    453e:	57                   	push   di
    453f:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4543:	06                   	push   es
    4544:	57                   	push   di
    4545:	9a 9b 3b 69 45       	call   0x4569:0x3b9b
    454a:	89 c7                	mov    di,ax
    454c:	8e c2                	mov    es,dx
    454e:	06                   	push   es
    454f:	57                   	push   di
    4550:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4553:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4557:	bf f6 36             	mov    di,0x36f6
    455a:	0e                   	push   cs
    455b:	57                   	push   di
    455c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    455f:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4564:	06                   	push   es
    4565:	57                   	push   di
    4566:	9a 9b 3b 8f 45       	call   0x458f:0x3b9b
    456b:	89 c7                	mov    di,ax
    456d:	8e c2                	mov    es,dx
    456f:	06                   	push   es
    4570:	57                   	push   di
    4571:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4574:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4578:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    457d:	bf 01 37             	mov    di,0x3701
    4580:	0e                   	push   cs
    4581:	57                   	push   di
    4582:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4585:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    458a:	06                   	push   es
    458b:	57                   	push   di
    458c:	9a 9b 3b e6 45       	call   0x45e6:0x3b9b
    4591:	89 c7                	mov    di,ax
    4593:	8e c2                	mov    es,dx
    4595:	06                   	push   es
    4596:	57                   	push   di
    4597:	26 c4 3d             	les    di,DWORD PTR es:[di]
    459a:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    459e:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    45a3:	9b de c9             	fmulp  st(1),st
    45a6:	9b 2e d9 06 59 34    	fld    DWORD PTR cs:0x3459
    45ac:	9a b2 04 4d 46       	call   0x464d:0x4b2
    45b1:	83 ec 08             	sub    sp,0x8
    45b4:	89 e3                	mov    bx,sp
    45b6:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    45ba:	90                   	nop
    45bb:	9b                   	fwait
    45bc:	9a a6 2f 5d 46       	call   0x465d:0x2fa6
    45c1:	9b dd 9e 18 ff       	fstp   QWORD PTR [bp-0xe8]
    45c6:	90                   	nop
    45c7:	9b                   	fwait
    45c8:	ff b6 1e ff          	push   WORD PTR [bp-0xe2]
    45cc:	ff b6 1c ff          	push   WORD PTR [bp-0xe4]
    45d0:	ff b6 1a ff          	push   WORD PTR [bp-0xe6]
    45d4:	ff b6 18 ff          	push   WORD PTR [bp-0xe8]
    45d8:	bf 0f 37             	mov    di,0x370f
    45db:	0e                   	push   cs
    45dc:	57                   	push   di
    45dd:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    45e1:	06                   	push   es
    45e2:	57                   	push   di
    45e3:	9a 9b 3b 07 46       	call   0x4607:0x3b9b
    45e8:	89 c7                	mov    di,ax
    45ea:	8e c2                	mov    es,dx
    45ec:	06                   	push   es
    45ed:	57                   	push   di
    45ee:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45f1:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    45f5:	bf 22 37             	mov    di,0x3722
    45f8:	0e                   	push   cs
    45f9:	57                   	push   di
    45fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    45fd:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4602:	06                   	push   es
    4603:	57                   	push   di
    4604:	9a 9b 3b 2d 46       	call   0x462d:0x3b9b
    4609:	89 c7                	mov    di,ax
    460b:	8e c2                	mov    es,dx
    460d:	06                   	push   es
    460e:	57                   	push   di
    460f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4612:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4616:	9b db be ca fe       	fstp   TBYTE PTR [bp-0x136]
    461b:	bf 30 37             	mov    di,0x3730
    461e:	0e                   	push   cs
    461f:	57                   	push   di
    4620:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4623:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    4628:	06                   	push   es
    4629:	57                   	push   di
    462a:	9a 9b 3b 76 46       	call   0x4676:0x3b9b
    462f:	89 c7                	mov    di,ax
    4631:	8e c2                	mov    es,dx
    4633:	06                   	push   es
    4634:	57                   	push   di
    4635:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4638:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    463c:	9b db ae ca fe       	fld    TBYTE PTR [bp-0x136]
    4641:	9b de c9             	fmulp  st(1),st
    4644:	9b 2e d9 06 59 34    	fld    DWORD PTR cs:0x3459
    464a:	9a b2 04 bc 46       	call   0x46bc:0x4b2
    464f:	83 ec 08             	sub    sp,0x8
    4652:	89 e3                	mov    bx,sp
    4654:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    4658:	90                   	nop
    4659:	9b                   	fwait
    465a:	9a a6 2f cc 46       	call   0x46cc:0x2fa6
    465f:	9b db be b6 fe       	fstp   TBYTE PTR [bp-0x14a]
    4664:	bf 42 37             	mov    di,0x3742
    4667:	0e                   	push   cs
    4668:	57                   	push   di
    4669:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    466c:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    4671:	06                   	push   es
    4672:	57                   	push   di
    4673:	9a 9b 3b 9c 46       	call   0x469c:0x3b9b
    4678:	89 c7                	mov    di,ax
    467a:	8e c2                	mov    es,dx
    467c:	06                   	push   es
    467d:	57                   	push   di
    467e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4681:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4685:	9b db be c0 fe       	fstp   TBYTE PTR [bp-0x140]
    468a:	bf 51 37             	mov    di,0x3751
    468d:	0e                   	push   cs
    468e:	57                   	push   di
    468f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4692:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    4697:	06                   	push   es
    4698:	57                   	push   di
    4699:	9a 9b 3b ed 46       	call   0x46ed:0x3b9b
    469e:	89 c7                	mov    di,ax
    46a0:	8e c2                	mov    es,dx
    46a2:	06                   	push   es
    46a3:	57                   	push   di
    46a4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46a7:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    46ab:	9b db ae c0 fe       	fld    TBYTE PTR [bp-0x140]
    46b0:	9b de c9             	fmulp  st(1),st
    46b3:	9b 2e d9 06 59 34    	fld    DWORD PTR cs:0x3459
    46b9:	9a b2 04 33 47       	call   0x4733:0x4b2
    46be:	83 ec 08             	sub    sp,0x8
    46c1:	89 e3                	mov    bx,sp
    46c3:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    46c7:	90                   	nop
    46c8:	9b                   	fwait
    46c9:	9a a6 2f 43 47       	call   0x4743:0x2fa6
    46ce:	9b db ae b6 fe       	fld    TBYTE PTR [bp-0x14a]
    46d3:	9b de c1             	faddp  st(1),st
    46d6:	9b db be a2 fe       	fstp   TBYTE PTR [bp-0x15e]
    46db:	bf 64 37             	mov    di,0x3764
    46de:	0e                   	push   cs
    46df:	57                   	push   di
    46e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    46e3:	26 c4 bd b8 01       	les    di,DWORD PTR es:[di+0x1b8]
    46e8:	06                   	push   es
    46e9:	57                   	push   di
    46ea:	9a 9b 3b 13 47       	call   0x4713:0x3b9b
    46ef:	89 c7                	mov    di,ax
    46f1:	8e c2                	mov    es,dx
    46f3:	06                   	push   es
    46f4:	57                   	push   di
    46f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    46f8:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    46fc:	9b db be ac fe       	fstp   TBYTE PTR [bp-0x154]
    4701:	bf 6c 37             	mov    di,0x376c
    4704:	0e                   	push   cs
    4705:	57                   	push   di
    4706:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4709:	26 c4 bd a0 01       	les    di,DWORD PTR es:[di+0x1a0]
    470e:	06                   	push   es
    470f:	57                   	push   di
    4710:	9a 9b 3b 72 47       	call   0x4772:0x3b9b
    4715:	89 c7                	mov    di,ax
    4717:	8e c2                	mov    es,dx
    4719:	06                   	push   es
    471a:	57                   	push   di
    471b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    471e:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    4722:	9b db ae ac fe       	fld    TBYTE PTR [bp-0x154]
    4727:	9b de c9             	fmulp  st(1),st
    472a:	9b 2e d9 06 59 34    	fld    DWORD PTR cs:0x3459
    4730:	9a b2 04 50 49       	call   0x4950:0x4b2
    4735:	83 ec 08             	sub    sp,0x8
    4738:	89 e3                	mov    bx,sp
    473a:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    473e:	90                   	nop
    473f:	9b                   	fwait
    4740:	9a a6 2f ff ff       	call   0xffff:0x2fa6
    4745:	9b db ae a2 fe       	fld    TBYTE PTR [bp-0x15e]
    474a:	9b de c1             	faddp  st(1),st
    474d:	9b dd 9e 10 ff       	fstp   QWORD PTR [bp-0xf0]
    4752:	90                   	nop
    4753:	9b                   	fwait
    4754:	ff b6 16 ff          	push   WORD PTR [bp-0xea]
    4758:	ff b6 14 ff          	push   WORD PTR [bp-0xec]
    475c:	ff b6 12 ff          	push   WORD PTR [bp-0xee]
    4760:	ff b6 10 ff          	push   WORD PTR [bp-0xf0]
    4764:	bf 78 37             	mov    di,0x3778
    4767:	0e                   	push   cs
    4768:	57                   	push   di
    4769:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    476d:	06                   	push   es
    476e:	57                   	push   di
    476f:	9a 9b 3b b5 47       	call   0x47b5:0x3b9b
    4774:	89 c7                	mov    di,ax
    4776:	8e c2                	mov    es,dx
    4778:	06                   	push   es
    4779:	57                   	push   di
    477a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    477d:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4781:	9b dd 86 20 ff       	fld    QWORD PTR [bp-0xe0]
    4786:	9b dc 86 18 ff       	fadd   QWORD PTR [bp-0xe8]
    478b:	9b dc a6 10 ff       	fsub   QWORD PTR [bp-0xf0]
    4790:	9b dd 9e 08 ff       	fstp   QWORD PTR [bp-0xf8]
    4795:	90                   	nop
    4796:	9b                   	fwait
    4797:	ff b6 0e ff          	push   WORD PTR [bp-0xf2]
    479b:	ff b6 0c ff          	push   WORD PTR [bp-0xf4]
    479f:	ff b6 0a ff          	push   WORD PTR [bp-0xf6]
    47a3:	ff b6 08 ff          	push   WORD PTR [bp-0xf8]
    47a7:	bf 8b 37             	mov    di,0x378b
    47aa:	0e                   	push   cs
    47ab:	57                   	push   di
    47ac:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    47b0:	06                   	push   es
    47b1:	57                   	push   di
    47b2:	9a 9b 3b d6 47       	call   0x47d6:0x3b9b
    47b7:	89 c7                	mov    di,ax
    47b9:	8e c2                	mov    es,dx
    47bb:	06                   	push   es
    47bc:	57                   	push   di
    47bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47c0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    47c4:	bf 9b 37             	mov    di,0x379b
    47c7:	0e                   	push   cs
    47c8:	57                   	push   di
    47c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    47cc:	26 c4 bd ac 01       	les    di,DWORD PTR es:[di+0x1ac]
    47d1:	06                   	push   es
    47d2:	57                   	push   di
    47d3:	9a 9b 3b 5a 48       	call   0x485a:0x3b9b
    47d8:	89 c7                	mov    di,ax
    47da:	8e c2                	mov    es,dx
    47dc:	06                   	push   es
    47dd:	57                   	push   di
    47de:	26 c4 3d             	les    di,DWORD PTR es:[di]
    47e1:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    47e5:	9b dd 9e d8 fe       	fstp   QWORD PTR [bp-0x128]
    47ea:	90                   	nop
    47eb:	9b 9b dd 86 d8 fe    	fld    QWORD PTR [bp-0x128]
    47f1:	9b 2e d8 1e af 37    	fcomp  DWORD PTR cs:0x37af
    47f7:	9b dd be d2 fe       	fstsw  WORD PTR [bp-0x12e]
    47fc:	90                   	nop
    47fd:	9b                   	fwait
    47fe:	8a a6 d3 fe          	mov    ah,BYTE PTR [bp-0x12d]
    4802:	9e                   	sahf
    4803:	76 1b                	jbe    0x4820
    4805:	9b dd 86 d8 fe       	fld    QWORD PTR [bp-0x128]
    480a:	9b dd 9e 00 ff       	fstp   QWORD PTR [bp-0x100]
    480f:	90                   	nop
    4810:	9b                   	fwait
    4811:	9b 2e d9 06 af 37    	fld    DWORD PTR cs:0x37af
    4817:	9b dd 9e f8 fe       	fstp   QWORD PTR [bp-0x108]
    481c:	90                   	nop
    481d:	9b                   	fwait
    481e:	eb 1c                	jmp    0x483c
    4820:	9b dd 86 d8 fe       	fld    QWORD PTR [bp-0x128]
    4825:	9b d9 e0             	fchs
    4828:	9b dd 9e f8 fe       	fstp   QWORD PTR [bp-0x108]
    482d:	90                   	nop
    482e:	9b                   	fwait
    482f:	9b 2e d9 06 af 37    	fld    DWORD PTR cs:0x37af
    4835:	9b dd 9e 00 ff       	fstp   QWORD PTR [bp-0x100]
    483a:	90                   	nop
    483b:	9b                   	fwait
    483c:	ff b6 06 ff          	push   WORD PTR [bp-0xfa]
    4840:	ff b6 04 ff          	push   WORD PTR [bp-0xfc]
    4844:	ff b6 02 ff          	push   WORD PTR [bp-0xfe]
    4848:	ff b6 00 ff          	push   WORD PTR [bp-0x100]
    484c:	bf b3 37             	mov    di,0x37b3
    484f:	0e                   	push   cs
    4850:	57                   	push   di
    4851:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4855:	06                   	push   es
    4856:	57                   	push   di
    4857:	9a 9b 3b 87 48       	call   0x4887:0x3b9b
    485c:	89 c7                	mov    di,ax
    485e:	8e c2                	mov    es,dx
    4860:	06                   	push   es
    4861:	57                   	push   di
    4862:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4865:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4869:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    486d:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    4871:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    4875:	ff b6 f8 fe          	push   WORD PTR [bp-0x108]
    4879:	bf c9 37             	mov    di,0x37c9
    487c:	0e                   	push   cs
    487d:	57                   	push   di
    487e:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4882:	06                   	push   es
    4883:	57                   	push   di
    4884:	9a 9b 3b a4 48       	call   0x48a4:0x3b9b
    4889:	89 c7                	mov    di,ax
    488b:	8e c2                	mov    es,dx
    488d:	06                   	push   es
    488e:	57                   	push   di
    488f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4892:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    4896:	bf e0 37             	mov    di,0x37e0
    4899:	0e                   	push   cs
    489a:	57                   	push   di
    489b:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    489f:	06                   	push   es
    48a0:	57                   	push   di
    48a1:	9a 9b 3b c8 48       	call   0x48c8:0x3b9b
    48a6:	89 c7                	mov    di,ax
    48a8:	8e c2                	mov    es,dx
    48aa:	06                   	push   es
    48ab:	57                   	push   di
    48ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48af:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48b3:	9b dd 9e f0 fe       	fstp   QWORD PTR [bp-0x110]
    48b8:	90                   	nop
    48b9:	9b                   	fwait
    48ba:	bf ee 37             	mov    di,0x37ee
    48bd:	0e                   	push   cs
    48be:	57                   	push   di
    48bf:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    48c3:	06                   	push   es
    48c4:	57                   	push   di
    48c5:	9a 9b 3b 1c 49       	call   0x491c:0x3b9b
    48ca:	89 c7                	mov    di,ax
    48cc:	8e c2                	mov    es,dx
    48ce:	06                   	push   es
    48cf:	57                   	push   di
    48d0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    48d3:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    48d7:	9b dd 9e e8 fe       	fstp   QWORD PTR [bp-0x118]
    48dc:	90                   	nop
    48dd:	9b 9b dd 86 08 ff    	fld    QWORD PTR [bp-0xf8]
    48e3:	9b dc 86 00 ff       	fadd   QWORD PTR [bp-0x100]
    48e8:	9b dc 86 f0 fe       	fadd   QWORD PTR [bp-0x110]
    48ed:	9b dc a6 f8 fe       	fsub   QWORD PTR [bp-0x108]
    48f2:	9b dc a6 e8 fe       	fsub   QWORD PTR [bp-0x118]
    48f7:	9b dd 9e e0 fe       	fstp   QWORD PTR [bp-0x120]
    48fc:	90                   	nop
    48fd:	9b                   	fwait
    48fe:	ff b6 e6 fe          	push   WORD PTR [bp-0x11a]
    4902:	ff b6 e4 fe          	push   WORD PTR [bp-0x11c]
    4906:	ff b6 e2 fe          	push   WORD PTR [bp-0x11e]
    490a:	ff b6 e0 fe          	push   WORD PTR [bp-0x120]
    490e:	bf f4 37             	mov    di,0x37f4
    4911:	0e                   	push   cs
    4912:	57                   	push   di
    4913:	c4 be d4 fe          	les    di,DWORD PTR [bp-0x12c]
    4917:	06                   	push   es
    4918:	57                   	push   di
    4919:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    491e:	89 c7                	mov    di,ax
    4920:	8e c2                	mov    es,dx
    4922:	06                   	push   es
    4923:	57                   	push   di
    4924:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4927:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    492b:	c9                   	leave
    492c:	ca 08 00             	retf   0x8
    492f:	14 4a                	adc    al,0x4a
    4931:	ef                   	out    dx,ax
    4932:	49                   	dec    cx
    4933:	a0 49 91             	mov    al,ds:0x9149
    4936:	49                   	dec    cx
    4937:	3d 4a d0             	cmp    ax,0xd04a
    493a:	49                   	dec    cx
    493b:	3d 4a b1             	cmp    ax,0xb14a
    493e:	49                   	dec    cx
    493f:	00 00                	add    BYTE PTR [bx+si],al
    4941:	00 00                	add    BYTE PTR [bx+si],al
    4943:	ff 00                	inc    WORD PTR [bx+si]
    4945:	00 00                	add    BYTE PTR [bx+si],al
    4947:	55                   	push   bp
    4948:	89 e5                	mov    bp,sp
    494a:	b8 04 00             	mov    ax,0x4
    494d:	9a 44 04 c1 49       	call   0x49c1:0x444
    4952:	83 ec 04             	sub    sp,0x4
    4955:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4958:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    495d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4960:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4963:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    4967:	b0 00                	mov    al,0x0
    4969:	74 01                	je     0x496c
    496b:	40                   	inc    ax
    496c:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    4970:	08 c0                	or     al,al
    4972:	75 03                	jne    0x4977
    4974:	e9 ee 00             	jmp    0x4a65
    4977:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    497a:	26 8b 05             	mov    ax,WORD PTR es:[di]
    497d:	2d 21 00             	sub    ax,0x21
    4980:	3d 07 00             	cmp    ax,0x7
    4983:	76 03                	jbe    0x4988
    4985:	e9 b5 00             	jmp    0x4a3d
    4988:	89 c3                	mov    bx,ax
    498a:	d1 e3                	shl    bx,1
    498c:	2e ff a7 2f 49       	jmp    WORD PTR cs:[bx+0x492f]
    4991:	6a 00                	push   0x0
    4993:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4996:	06                   	push   es
    4997:	57                   	push   di
    4998:	9a d0 1c ac 49       	call   0x49ac:0x1cd0
    499d:	e9 9d 00             	jmp    0x4a3d
    49a0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    49a3:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    49a7:	06                   	push   es
    49a8:	57                   	push   di
    49a9:	9a d0 1c cc 49       	call   0x49cc:0x1cd0
    49ae:	e9 8c 00             	jmp    0x4a3d
    49b1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    49b4:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    49b8:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    49bc:	71 05                	jno    0x49c3
    49be:	9a 3e 04 e0 49       	call   0x49e0:0x43e
    49c3:	50                   	push   ax
    49c4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    49c7:	06                   	push   es
    49c8:	57                   	push   di
    49c9:	9a d0 1c eb 49       	call   0x49eb:0x1cd0
    49ce:	eb 6d                	jmp    0x4a3d
    49d0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    49d3:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    49d7:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    49db:	71 05                	jno    0x49e2
    49dd:	9a 3e 04 05 4a       	call   0x4a05:0x43e
    49e2:	50                   	push   ax
    49e3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    49e6:	06                   	push   es
    49e7:	57                   	push   di
    49e8:	9a d0 1c 10 4a       	call   0x4a10:0x1cd0
    49ed:	eb 4e                	jmp    0x4a3d
    49ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    49f2:	06                   	push   es
    49f3:	57                   	push   di
    49f4:	9a f4 18 1c 4a       	call   0x4a1c:0x18f4
    49f9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    49fc:	26 03 45 0a          	add    ax,WORD PTR es:[di+0xa]
    4a00:	71 05                	jno    0x4a07
    4a02:	9a 3e 04 2e 4a       	call   0x4a2e:0x43e
    4a07:	50                   	push   ax
    4a08:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4a0b:	06                   	push   es
    4a0c:	57                   	push   di
    4a0d:	9a d0 1c 39 4a       	call   0x4a39:0x1cd0
    4a12:	eb 29                	jmp    0x4a3d
    4a14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a17:	06                   	push   es
    4a18:	57                   	push   di
    4a19:	9a f4 18 56 4c       	call   0x4c56:0x18f4
    4a1e:	8b d0                	mov    dx,ax
    4a20:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4a23:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4a27:	2b c2                	sub    ax,dx
    4a29:	71 05                	jno    0x4a30
    4a2b:	9a 3e 04 4b 4a       	call   0x4a4b:0x43e
    4a30:	50                   	push   ax
    4a31:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4a34:	06                   	push   es
    4a35:	57                   	push   di
    4a36:	9a d0 1c aa 4a       	call   0x4aaa:0x1cd0
    4a3b:	eb 00                	jmp    0x4a3d
    4a3d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4a40:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4a43:	31 d2                	xor    dx,dx
    4a45:	bf 3f 49             	mov    di,0x493f
    4a48:	9a 16 04 9f 4a       	call   0x4a9f:0x416
    4a4d:	3c 21                	cmp    al,0x21
    4a4f:	72 14                	jb     0x4a65
    4a51:	3c 24                	cmp    al,0x24
    4a53:	76 08                	jbe    0x4a5d
    4a55:	3c 26                	cmp    al,0x26
    4a57:	74 04                	je     0x4a5d
    4a59:	3c 28                	cmp    al,0x28
    4a5b:	75 08                	jne    0x4a65
    4a5d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4a60:	31 c0                	xor    ax,ax
    4a62:	26 89 05             	mov    WORD PTR es:[di],ax
    4a65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4a68:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    4a6d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4a70:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4a73:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    4a77:	b0 00                	mov    al,0x0
    4a79:	74 01                	je     0x4a7c
    4a7b:	40                   	inc    ax
    4a7c:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    4a80:	08 c0                	or     al,al
    4a82:	74 6e                	je     0x4af2
    4a84:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4a87:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4a8a:	3d 27 00             	cmp    ax,0x27
    4a8d:	75 1f                	jne    0x4aae
    4a8f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4a92:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4a96:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    4a9a:	71 05                	jno    0x4aa1
    4a9c:	9a 3e 04 c3 4a       	call   0x4ac3:0x43e
    4aa1:	50                   	push   ax
    4aa2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4aa5:	06                   	push   es
    4aa6:	57                   	push   di
    4aa7:	9a d0 1c ce 4a       	call   0x4ace:0x1cd0
    4aac:	eb 24                	jmp    0x4ad2
    4aae:	3d 25 00             	cmp    ax,0x25
    4ab1:	75 1f                	jne    0x4ad2
    4ab3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4ab6:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    4aba:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    4abe:	71 05                	jno    0x4ac5
    4ac0:	9a 3e 04 e0 4a       	call   0x4ae0:0x43e
    4ac5:	50                   	push   ax
    4ac6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4ac9:	06                   	push   es
    4aca:	57                   	push   di
    4acb:	9a d0 1c 0d 4b       	call   0x4b0d:0x1cd0
    4ad0:	eb 00                	jmp    0x4ad2
    4ad2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4ad5:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4ad8:	31 d2                	xor    dx,dx
    4ada:	bf 3f 49             	mov    di,0x493f
    4add:	9a 16 04 1b 4b       	call   0x4b1b:0x416
    4ae2:	3c 25                	cmp    al,0x25
    4ae4:	74 04                	je     0x4aea
    4ae6:	3c 27                	cmp    al,0x27
    4ae8:	75 08                	jne    0x4af2
    4aea:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4aed:	31 c0                	xor    ax,ax
    4aef:	26 89 05             	mov    WORD PTR es:[di],ax
    4af2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4af5:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    4af9:	74 14                	je     0x4b0f
    4afb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4afe:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    4b03:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    4b08:	06                   	push   es
    4b09:	57                   	push   di
    4b0a:	9a 30 22 38 4b       	call   0x4b38:0x2230
    4b0f:	c9                   	leave
    4b10:	ca 0e 00             	retf   0xe
    4b13:	55                   	push   bp
    4b14:	89 e5                	mov    bp,sp
    4b16:	31 c0                	xor    ax,ax
    4b18:	9a 44 04 46 4b       	call   0x4b46:0x444
    4b1d:	6a 01                	push   0x1
    4b1f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b22:	26 c4 bd bc 02       	les    di,DWORD PTR es:[di+0x2bc]
    4b27:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    4b2b:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    4b2f:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4b33:	06                   	push   es
    4b34:	57                   	push   di
    4b35:	9a b2 77 57 4b       	call   0x4b57:0x77b2
    4b3a:	c9                   	leave
    4b3b:	ca 08 00             	retf   0x8
    4b3e:	55                   	push   bp
    4b3f:	89 e5                	mov    bp,sp
    4b41:	31 c0                	xor    ax,ax
    4b43:	9a 44 04 65 4b       	call   0x4b65:0x444
    4b48:	6a 03                	push   0x3
    4b4a:	6a 00                	push   0x0
    4b4c:	6a 00                	push   0x0
    4b4e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4b52:	06                   	push   es
    4b53:	57                   	push   di
    4b54:	9a b2 77 78 4b       	call   0x4b78:0x77b2
    4b59:	c9                   	leave
    4b5a:	ca 08 00             	retf   0x8
    4b5d:	55                   	push   bp
    4b5e:	89 e5                	mov    bp,sp
    4b60:	31 c0                	xor    ax,ax
    4b62:	9a 44 04 86 4b       	call   0x4b86:0x444
    4b67:	68 05 01             	push   0x105
    4b6a:	bf d6 01             	mov    di,0x1d6
    4b6d:	1e                   	push   ds
    4b6e:	57                   	push   di
    4b6f:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4b73:	06                   	push   es
    4b74:	57                   	push   di
    4b75:	9a b2 77 97 4b       	call   0x4b97:0x77b2
    4b7a:	c9                   	leave
    4b7b:	ca 08 00             	retf   0x8
    4b7e:	55                   	push   bp
    4b7f:	89 e5                	mov    bp,sp
    4b81:	31 c0                	xor    ax,ax
    4b83:	9a 44 04 a6 4b       	call   0x4ba6:0x444
    4b88:	6a 04                	push   0x4
    4b8a:	6a 00                	push   0x0
    4b8c:	6a 00                	push   0x0
    4b8e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4b92:	06                   	push   es
    4b93:	57                   	push   di
    4b94:	9a b2 77 b4 4b       	call   0x4bb4:0x77b2
    4b99:	c9                   	leave
    4b9a:	ca 08 00             	retf   0x8
    4b9d:	55                   	push   bp
    4b9e:	89 e5                	mov    bp,sp
    4ba0:	b8 04 00             	mov    ax,0x4
    4ba3:	9a 44 04 c3 4b       	call   0x4bc3:0x444
    4ba8:	83 ec 04             	sub    sp,0x4
    4bab:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    4baf:	06                   	push   es
    4bb0:	57                   	push   di
    4bb1:	9a 45 5d 2f 4c       	call   0x4c2f:0x5d45
    4bb6:	c9                   	leave
    4bb7:	ca 08 00             	retf   0x8
    4bba:	55                   	push   bp
    4bbb:	89 e5                	mov    bp,sp
    4bbd:	b8 04 00             	mov    ax,0x4
    4bc0:	9a 44 04 3e 4c       	call   0x4c3e:0x444
    4bc5:	83 ec 04             	sub    sp,0x4
    4bc8:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    4bcb:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    4bd0:	b0 00                	mov    al,0x0
    4bd2:	75 01                	jne    0x4bd5
    4bd4:	40                   	inc    ax
    4bd5:	8a c8                	mov    cl,al
    4bd7:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    4bdd:	b0 00                	mov    al,0x0
    4bdf:	77 01                	ja     0x4be2
    4be1:	40                   	inc    ax
    4be2:	8a d0                	mov    dl,al
    4be4:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    4bea:	b0 00                	mov    al,0x0
    4bec:	76 01                	jbe    0x4bef
    4bee:	40                   	inc    ax
    4bef:	22 c2                	and    al,dl
    4bf1:	0a c1                	or     al,cl
    4bf3:	08 c0                	or     al,al
    4bf5:	74 3a                	je     0x4c31
    4bf7:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4bfb:	31 c0                	xor    ax,ax
    4bfd:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    4c01:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    4c05:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    4c09:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    4c0d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c10:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    4c14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c17:	06                   	push   es
    4c18:	57                   	push   di
    4c19:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4c1c:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    4c20:	6a 02                	push   0x2
    4c22:	6a 00                	push   0x0
    4c24:	6a 00                	push   0x0
    4c26:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4c2a:	06                   	push   es
    4c2b:	57                   	push   di
    4c2c:	9a b2 77 be 4c       	call   0x4cbe:0x77b2
    4c31:	c9                   	leave
    4c32:	ca 0c 00             	retf   0xc
    4c35:	55                   	push   bp
    4c36:	89 e5                	mov    bp,sp
    4c38:	b8 04 00             	mov    ax,0x4
    4c3b:	9a 44 04 5d 4c       	call   0x4c5d:0x444
    4c40:	83 ec 04             	sub    sp,0x4
    4c43:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    4c47:	74 03                	je     0x4c4c
    4c49:	e9 9c 00             	jmp    0x4ce8
    4c4c:	ff 76 14             	push   WORD PTR [bp+0x14]
    4c4f:	ff 76 12             	push   WORD PTR [bp+0x12]
    4c52:	bf c1 05             	mov    di,0x5c1
    4c55:	b8 70 4c             	mov    ax,0x4c70
    4c58:	50                   	push   ax
    4c59:	57                   	push   di
    4c5a:	9a 55 22 77 4c       	call   0x4c77:0x2255
    4c5f:	08 c0                	or     al,al
    4c61:	75 03                	jne    0x4c66
    4c63:	e9 82 00             	jmp    0x4ce8
    4c66:	ff 76 14             	push   WORD PTR [bp+0x14]
    4c69:	ff 76 12             	push   WORD PTR [bp+0x12]
    4c6c:	bf c1 05             	mov    di,0x5c1
    4c6f:	b8 9f 4c             	mov    ax,0x4c9f
    4c72:	50                   	push   ax
    4c73:	57                   	push   di
    4c74:	9a 73 22 a6 4c       	call   0x4ca6:0x2273
    4c79:	89 c7                	mov    di,ax
    4c7b:	8e c2                	mov    es,dx
    4c7d:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    4c82:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    4c87:	74 5f                	je     0x4ce8
    4c89:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4c8d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    4c90:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    4c93:	6a 08                	push   0x8
    4c95:	ff 76 14             	push   WORD PTR [bp+0x14]
    4c98:	ff 76 12             	push   WORD PTR [bp+0x12]
    4c9b:	bf c1 05             	mov    di,0x5c1
    4c9e:	b8 0a 4d             	mov    ax,0x4d0a
    4ca1:	50                   	push   ax
    4ca2:	57                   	push   di
    4ca3:	9a 73 22 f5 4c       	call   0x4cf5:0x2273
    4ca8:	89 c7                	mov    di,ax
    4caa:	8e c2                	mov    es,dx
    4cac:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    4cb1:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    4cb6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4cb9:	06                   	push   es
    4cba:	57                   	push   di
    4cbb:	9a b2 77 c8 4c       	call   0x4cc8:0x77b2
    4cc0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4cc3:	06                   	push   es
    4cc4:	57                   	push   di
    4cc5:	9a 03 73 4f 4d       	call   0x4d4f:0x7303
    4cca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ccd:	06                   	push   es
    4cce:	57                   	push   di
    4ccf:	b8 ba 4b             	mov    ax,0x4bba
    4cd2:	ba 7a 4d             	mov    dx,0x4d7a
    4cd5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4cd8:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    4cdc:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    4ce0:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    4ce4:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    4ce8:	c9                   	leave
    4ce9:	ca 10 00             	retf   0x10
    4cec:	55                   	push   bp
    4ced:	89 e5                	mov    bp,sp
    4cef:	b8 04 00             	mov    ax,0x4
    4cf2:	9a 44 04 11 4d       	call   0x4d11:0x444
    4cf7:	83 ec 04             	sub    sp,0x4
    4cfa:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    4cfe:	75 51                	jne    0x4d51
    4d00:	ff 76 14             	push   WORD PTR [bp+0x14]
    4d03:	ff 76 12             	push   WORD PTR [bp+0x12]
    4d06:	bf c1 05             	mov    di,0x5c1
    4d09:	b8 21 4d             	mov    ax,0x4d21
    4d0c:	50                   	push   ax
    4d0d:	57                   	push   di
    4d0e:	9a 55 22 28 4d       	call   0x4d28:0x2255
    4d13:	08 c0                	or     al,al
    4d15:	74 3a                	je     0x4d51
    4d17:	ff 76 14             	push   WORD PTR [bp+0x14]
    4d1a:	ff 76 12             	push   WORD PTR [bp+0x12]
    4d1d:	bf c1 05             	mov    di,0x5c1
    4d20:	b8 3f 50             	mov    ax,0x503f
    4d23:	50                   	push   ax
    4d24:	57                   	push   di
    4d25:	9a 73 22 5d 4d       	call   0x4d5d:0x2273
    4d2a:	89 c7                	mov    di,ax
    4d2c:	8e c2                	mov    es,dx
    4d2e:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    4d33:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    4d38:	74 17                	je     0x4d51
    4d3a:	6a 08                	push   0x8
    4d3c:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    4d41:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    4d46:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    4d4a:	06                   	push   es
    4d4b:	57                   	push   di
    4d4c:	9a b2 77 96 67       	call   0x6796:0x77b2
    4d51:	c9                   	leave
    4d52:	ca 10 00             	retf   0x10
    4d55:	55                   	push   bp
    4d56:	89 e5                	mov    bp,sp
    4d58:	31 c0                	xor    ax,ax
    4d5a:	9a 44 04 91 4d       	call   0x4d91:0x444
    4d5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d62:	26 c4 bd 14 02       	les    di,DWORD PTR es:[di+0x214]
    4d67:	06                   	push   es
    4d68:	57                   	push   di
    4d69:	9a 17 2f ff ff       	call   0xffff:0x2f17
    4d6e:	08 c0                	or     al,al
    4d70:	74 0a                	je     0x4d7c
    4d72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d75:	06                   	push   es
    4d76:	57                   	push   di
    4d77:	9a e4 4d e2 4d       	call   0x4de2:0x4de4
    4d7c:	c9                   	leave
    4d7d:	ca 08 00             	retf   0x8
    4d80:	00 00                	add    BYTE PTR [bx+si],al
    4d82:	00 00                	add    BYTE PTR [bx+si],al
    4d84:	ff                   	(bad)
    4d85:	ff 00                	inc    WORD PTR [bx+si]
    4d87:	00 55 89             	add    BYTE PTR [di-0x77],dl
    4d8a:	e5 b8                	in     ax,0xb8
    4d8c:	22 00                	and    al,BYTE PTR [bx+si]
    4d8e:	9a 44 04 c1 4d       	call   0x4dc1:0x444
    4d93:	83 ec 22             	sub    sp,0x22
    4d96:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    4d9a:	06                   	push   es
    4d9b:	57                   	push   di
    4d9c:	9a 04 2a 08 4e       	call   0x4e08:0x2a04
    4da1:	89 c7                	mov    di,ax
    4da3:	8e c2                	mov    es,dx
    4da5:	06                   	push   es
    4da6:	57                   	push   di
    4da7:	9a d2 21 59 4e       	call   0x4e59:0x21d2
    4dac:	50                   	push   ax
    4dad:	8d 7e de             	lea    di,[bp-0x22]
    4db0:	16                   	push   ss
    4db1:	57                   	push   di
    4db2:	9a ff ff 00 00       	call   0x0:0xffff
    4db7:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    4dba:	99                   	cwd
    4dbb:	bf 80 4d             	mov    di,0x4d80
    4dbe:	9a 16 04 ed 4d       	call   0x4ded:0x416
    4dc3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4dc6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4dc9:	c9                   	leave
    4dca:	ca 02 00             	retf   0x2
    4dcd:	00 01                	add    BYTE PTR [bx+di],al
    4dcf:	09 01                	or     WORD PTR [bx+di],ax
    4dd1:	20 03                	and    BYTE PTR [bp+di],al
    4dd3:	20 20                	and    BYTE PTR [bx+si],ah
    4dd5:	20 00                	and    BYTE PTR [bx+si],al
    4dd7:	80 ff ff             	cmp    bh,0xff
    4dda:	ff                   	(bad)
    4ddb:	7f 00                	jg     0x4ddd
    4ddd:	00 00                	add    BYTE PTR [bx+si],al
    4ddf:	00 1c                	add    BYTE PTR [si],bl
    4de1:	52                   	push   dx
    4de2:	fd                   	std
    4de3:	4d                   	dec    bp
    4de4:	55                   	push   bp
    4de5:	89 e5                	mov    bp,sp
    4de7:	b8 0e 04             	mov    ax,0x40e
    4dea:	9a 44 04 13 4e       	call   0x4e13:0x444
    4def:	81 ec 0e 04          	sub    sp,0x40e
    4df3:	6a 01                	push   0x1
    4df5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4df8:	06                   	push   es
    4df9:	57                   	push   di
    4dfa:	9a 88 55 02 50       	call   0x5002:0x5588
    4dff:	8d be fc fe          	lea    di,[bp-0x104]
    4e03:	16                   	push   ss
    4e04:	57                   	push   di
    4e05:	9a 4e 20 31 4e       	call   0x4e31:0x204e
    4e0a:	8d be fc fe          	lea    di,[bp-0x104]
    4e0e:	16                   	push   ss
    4e0f:	57                   	push   di
    4e10:	9a f5 09 18 4e       	call   0x4e18:0x9f5
    4e15:	9a 08 04 ad 4e       	call   0x4ead:0x408
    4e1a:	b8 de 4d             	mov    ax,0x4dde
    4e1d:	0e                   	push   cs
    4e1e:	50                   	push   ax
    4e1f:	55                   	push   bp
    4e20:	ff 36 58 18          	push   WORD PTR ds:0x1858
    4e24:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    4e28:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    4e2c:	06                   	push   es
    4e2d:	57                   	push   di
    4e2e:	9a 04 2a 66 4e       	call   0x4e66:0x2a04
    4e33:	89 c7                	mov    di,ax
    4e35:	8e c2                	mov    es,dx
    4e37:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    4e3b:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    4e3f:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    4e43:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    4e48:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    4e4c:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4e50:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4e54:	06                   	push   es
    4e55:	57                   	push   di
    4e56:	9a 99 20 75 4e       	call   0x4e75:0x2099
    4e5b:	6a 0a                	push   0xa
    4e5d:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    4e61:	06                   	push   es
    4e62:	57                   	push   di
    4e63:	9a 04 2a 82 4e       	call   0x4e82:0x2a04
    4e68:	89 c7                	mov    di,ax
    4e6a:	8e c2                	mov    es,dx
    4e6c:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    4e70:	06                   	push   es
    4e71:	57                   	push   di
    4e72:	9a f5 11 91 4e       	call   0x4e91:0x11f5
    4e77:	6a 02                	push   0x2
    4e79:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    4e7d:	06                   	push   es
    4e7e:	57                   	push   di
    4e7f:	9a 04 2a d1 4f       	call   0x4fd1:0x2a04
    4e84:	89 c7                	mov    di,ax
    4e86:	8e c2                	mov    es,dx
    4e88:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    4e8c:	06                   	push   es
    4e8d:	57                   	push   di
    4e8e:	9a 78 12 e0 4f       	call   0x4fe0:0x1278
    4e93:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    4e98:	eb 03                	jmp    0x4e9d
    4e9a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4e9d:	8d be fc fe          	lea    di,[bp-0x104]
    4ea1:	16                   	push   ss
    4ea2:	57                   	push   di
    4ea3:	bf cd 4d             	mov    di,0x4dcd
    4ea6:	0e                   	push   cs
    4ea7:	57                   	push   di
    4ea8:	6a 00                	push   0x0
    4eaa:	9a b5 0d b2 4e       	call   0x4eb2:0xdb5
    4eaf:	9a 78 0c b7 4e       	call   0x4eb7:0xc78
    4eb4:	9a 08 04 e5 4e       	call   0x4ee5:0x408
    4eb9:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    4ebd:	75 db                	jne    0x4e9a
    4ebf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ec2:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    4ec7:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    4ecb:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    4ecf:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4ed4:	06                   	push   es
    4ed5:	57                   	push   di
    4ed6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ed9:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    4edd:	2d 01 00             	sub    ax,0x1
    4ee0:	71 05                	jno    0x4ee7
    4ee2:	9a 3e 04 25 4f       	call   0x4f25:0x43e
    4ee7:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    4eeb:	31 c0                	xor    ax,ax
    4eed:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    4ef1:	7e 03                	jle    0x4ef6
    4ef3:	e9 c8 00             	jmp    0x4fbe
    4ef6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4ef9:	eb 03                	jmp    0x4efe
    4efb:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4efe:	8d be f0 fc          	lea    di,[bp-0x310]
    4f02:	16                   	push   ss
    4f03:	57                   	push   di
    4f04:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4f07:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4f0b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4f10:	06                   	push   es
    4f11:	57                   	push   di
    4f12:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f15:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    4f19:	8d be fc fd          	lea    di,[bp-0x204]
    4f1d:	16                   	push   ss
    4f1e:	57                   	push   di
    4f1f:	68 ff 00             	push   0xff
    4f22:	9a e7 17 35 4f       	call   0x4f35:0x17e7
    4f27:	bf ce 4d             	mov    di,0x4dce
    4f2a:	0e                   	push   cs
    4f2b:	57                   	push   di
    4f2c:	8d be fc fd          	lea    di,[bp-0x204]
    4f30:	16                   	push   ss
    4f31:	57                   	push   di
    4f32:	9a 78 18 4e 4f       	call   0x4f4e:0x1878
    4f37:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4f3a:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    4f3e:	7e 26                	jle    0x4f66
    4f40:	8d be fc fd          	lea    di,[bp-0x204]
    4f44:	16                   	push   ss
    4f45:	57                   	push   di
    4f46:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4f49:	6a 01                	push   0x1
    4f4b:	9a 75 19 64 4f       	call   0x4f64:0x1975
    4f50:	bf d0 4d             	mov    di,0x4dd0
    4f53:	0e                   	push   cs
    4f54:	57                   	push   di
    4f55:	8d be fc fd          	lea    di,[bp-0x204]
    4f59:	16                   	push   ss
    4f5a:	57                   	push   di
    4f5b:	68 ff 00             	push   0xff
    4f5e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4f61:	9a 16 19 7a 4f       	call   0x4f7a:0x1916
    4f66:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    4f6a:	75 bb                	jne    0x4f27
    4f6c:	8d be f0 fc          	lea    di,[bp-0x310]
    4f70:	16                   	push   ss
    4f71:	57                   	push   di
    4f72:	bf d2 4d             	mov    di,0x4dd2
    4f75:	0e                   	push   cs
    4f76:	57                   	push   di
    4f77:	9a cd 17 85 4f       	call   0x4f85:0x17cd
    4f7c:	8d be fc fd          	lea    di,[bp-0x204]
    4f80:	16                   	push   ss
    4f81:	57                   	push   di
    4f82:	9a 4c 18 93 4f       	call   0x4f93:0x184c
    4f87:	8d be fc fd          	lea    di,[bp-0x204]
    4f8b:	16                   	push   ss
    4f8c:	57                   	push   di
    4f8d:	68 ff 00             	push   0xff
    4f90:	9a e7 17 a6 4f       	call   0x4fa6:0x17e7
    4f95:	8d be fc fe          	lea    di,[bp-0x104]
    4f99:	16                   	push   ss
    4f9a:	57                   	push   di
    4f9b:	8d be fc fd          	lea    di,[bp-0x204]
    4f9f:	16                   	push   ss
    4fa0:	57                   	push   di
    4fa1:	6a 00                	push   0x0
    4fa3:	9a b5 0d ab 4f       	call   0x4fab:0xdb5
    4fa8:	9a 78 0c b0 4f       	call   0x4fb0:0xc78
    4fad:	9a 08 04 0c 50       	call   0x500c:0x408
    4fb2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4fb5:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    4fb9:	74 03                	je     0x4fbe
    4fbb:	e9 3d ff             	jmp    0x4efb
    4fbe:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    4fc2:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    4fc6:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    4fca:	6a 06                	push   0x6
    4fcc:	06                   	push   es
    4fcd:	57                   	push   di
    4fce:	9a 04 2a ed 4f       	call   0x4fed:0x2a04
    4fd3:	89 c7                	mov    di,ax
    4fd5:	8e c2                	mov    es,dx
    4fd7:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    4fdb:	06                   	push   es
    4fdc:	57                   	push   di
    4fdd:	9a f5 11 fc 4f       	call   0x4ffc:0x11f5
    4fe2:	6a 00                	push   0x0
    4fe4:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    4fe8:	06                   	push   es
    4fe9:	57                   	push   di
    4fea:	9a 04 2a 70 50       	call   0x5070:0x2a04
    4fef:	89 c7                	mov    di,ax
    4ff1:	8e c2                	mov    es,dx
    4ff3:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    4ff7:	06                   	push   es
    4ff8:	57                   	push   di
    4ff9:	9a 78 12 97 50       	call   0x5097:0x1278
    4ffe:	55                   	push   bp
    4fff:	9a 88 4d 58 52       	call   0x5258:0x4d88
    5004:	05 02 00             	add    ax,0x2
    5007:	73 05                	jae    0x500e
    5009:	9a 3e 04 16 50       	call   0x5016:0x43e
    500e:	31 d2                	xor    dx,dx
    5010:	bf d6 4d             	mov    di,0x4dd6
    5013:	9a 16 04 2a 50       	call   0x502a:0x416
    5018:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    501c:	8d be f2 fb          	lea    di,[bp-0x40e]
    5020:	16                   	push   ss
    5021:	57                   	push   di
    5022:	bf d2 4d             	mov    di,0x4dd2
    5025:	0e                   	push   cs
    5026:	57                   	push   di
    5027:	9a cd 17 44 50       	call   0x5044:0x17cd
    502c:	8d be f2 fc          	lea    di,[bp-0x30e]
    5030:	16                   	push   ss
    5031:	57                   	push   di
    5032:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5035:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    503a:	06                   	push   es
    503b:	57                   	push   di
    503c:	9a 53 1d bc 50       	call   0x50bc:0x1d53
    5041:	9a 4c 18 52 50       	call   0x5052:0x184c
    5046:	8d be fc fd          	lea    di,[bp-0x204]
    504a:	16                   	push   ss
    504b:	57                   	push   di
    504c:	68 ff 00             	push   0xff
    504f:	9a e7 17 64 50       	call   0x5064:0x17e7
    5054:	6a 00                	push   0x0
    5056:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    505a:	b9 05 00             	mov    cx,0x5
    505d:	f7 e9                	imul   cx
    505f:	71 05                	jno    0x5066
    5061:	9a 3e 04 7a 50       	call   0x507a:0x43e
    5066:	50                   	push   ax
    5067:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    506b:	06                   	push   es
    506c:	57                   	push   di
    506d:	9a 72 2a 8c 50       	call   0x508c:0x2a72
    5072:	5a                   	pop    dx
    5073:	2b c2                	sub    ax,dx
    5075:	71 05                	jno    0x507c
    5077:	9a 3e 04 a7 50       	call   0x50a7:0x43e
    507c:	50                   	push   ax
    507d:	8d be fc fd          	lea    di,[bp-0x204]
    5081:	16                   	push   ss
    5082:	57                   	push   di
    5083:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5087:	06                   	push   es
    5088:	57                   	push   di
    5089:	9a 04 2a ed 50       	call   0x50ed:0x2a04
    508e:	89 c7                	mov    di,ax
    5090:	8e c2                	mov    es,dx
    5092:	06                   	push   es
    5093:	57                   	push   di
    5094:	9a 09 1f 14 51       	call   0x5114:0x1f09
    5099:	8d be f2 fb          	lea    di,[bp-0x40e]
    509d:	16                   	push   ss
    509e:	57                   	push   di
    509f:	bf d2 4d             	mov    di,0x4dd2
    50a2:	0e                   	push   cs
    50a3:	57                   	push   di
    50a4:	9a cd 17 c1 50       	call   0x50c1:0x17cd
    50a9:	8d be f2 fc          	lea    di,[bp-0x30e]
    50ad:	16                   	push   ss
    50ae:	57                   	push   di
    50af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50b2:	26 c4 bd cc 02       	les    di,DWORD PTR es:[di+0x2cc]
    50b7:	06                   	push   es
    50b8:	57                   	push   di
    50b9:	9a 53 1d 39 51       	call   0x5139:0x1d53
    50be:	9a 4c 18 cf 50       	call   0x50cf:0x184c
    50c3:	8d be fc fd          	lea    di,[bp-0x204]
    50c7:	16                   	push   ss
    50c8:	57                   	push   di
    50c9:	68 ff 00             	push   0xff
    50cc:	9a e7 17 e1 50       	call   0x50e1:0x17e7
    50d1:	6a 00                	push   0x0
    50d3:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    50d7:	b9 04 00             	mov    cx,0x4
    50da:	f7 e9                	imul   cx
    50dc:	71 05                	jno    0x50e3
    50de:	9a 3e 04 f7 50       	call   0x50f7:0x43e
    50e3:	50                   	push   ax
    50e4:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    50e8:	06                   	push   es
    50e9:	57                   	push   di
    50ea:	9a 72 2a 09 51       	call   0x5109:0x2a72
    50ef:	5a                   	pop    dx
    50f0:	2b c2                	sub    ax,dx
    50f2:	71 05                	jno    0x50f9
    50f4:	9a 3e 04 24 51       	call   0x5124:0x43e
    50f9:	50                   	push   ax
    50fa:	8d be fc fd          	lea    di,[bp-0x204]
    50fe:	16                   	push   ss
    50ff:	57                   	push   di
    5100:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5104:	06                   	push   es
    5105:	57                   	push   di
    5106:	9a 04 2a 6a 51       	call   0x516a:0x2a04
    510b:	89 c7                	mov    di,ax
    510d:	8e c2                	mov    es,dx
    510f:	06                   	push   es
    5110:	57                   	push   di
    5111:	9a 09 1f 91 51       	call   0x5191:0x1f09
    5116:	8d be f2 fb          	lea    di,[bp-0x40e]
    511a:	16                   	push   ss
    511b:	57                   	push   di
    511c:	bf d2 4d             	mov    di,0x4dd2
    511f:	0e                   	push   cs
    5120:	57                   	push   di
    5121:	9a cd 17 3e 51       	call   0x513e:0x17cd
    5126:	8d be f2 fc          	lea    di,[bp-0x30e]
    512a:	16                   	push   ss
    512b:	57                   	push   di
    512c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    512f:	26 c4 bd d0 02       	les    di,DWORD PTR es:[di+0x2d0]
    5134:	06                   	push   es
    5135:	57                   	push   di
    5136:	9a 53 1d b6 51       	call   0x51b6:0x1d53
    513b:	9a 4c 18 4c 51       	call   0x514c:0x184c
    5140:	8d be fc fd          	lea    di,[bp-0x204]
    5144:	16                   	push   ss
    5145:	57                   	push   di
    5146:	68 ff 00             	push   0xff
    5149:	9a e7 17 5e 51       	call   0x515e:0x17e7
    514e:	6a 00                	push   0x0
    5150:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    5154:	b9 03 00             	mov    cx,0x3
    5157:	f7 e9                	imul   cx
    5159:	71 05                	jno    0x5160
    515b:	9a 3e 04 74 51       	call   0x5174:0x43e
    5160:	50                   	push   ax
    5161:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5165:	06                   	push   es
    5166:	57                   	push   di
    5167:	9a 72 2a 86 51       	call   0x5186:0x2a72
    516c:	5a                   	pop    dx
    516d:	2b c2                	sub    ax,dx
    516f:	71 05                	jno    0x5176
    5171:	9a 3e 04 a1 51       	call   0x51a1:0x43e
    5176:	50                   	push   ax
    5177:	8d be fc fd          	lea    di,[bp-0x204]
    517b:	16                   	push   ss
    517c:	57                   	push   di
    517d:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    5181:	06                   	push   es
    5182:	57                   	push   di
    5183:	9a 04 2a e7 51       	call   0x51e7:0x2a04
    5188:	89 c7                	mov    di,ax
    518a:	8e c2                	mov    es,dx
    518c:	06                   	push   es
    518d:	57                   	push   di
    518e:	9a 09 1f 0e 52       	call   0x520e:0x1f09
    5193:	8d be f2 fb          	lea    di,[bp-0x40e]
    5197:	16                   	push   ss
    5198:	57                   	push   di
    5199:	bf d2 4d             	mov    di,0x4dd2
    519c:	0e                   	push   cs
    519d:	57                   	push   di
    519e:	9a cd 17 bb 51       	call   0x51bb:0x17cd
    51a3:	8d be f2 fc          	lea    di,[bp-0x30e]
    51a7:	16                   	push   ss
    51a8:	57                   	push   di
    51a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51ac:	26 c4 bd d4 02       	les    di,DWORD PTR es:[di+0x2d4]
    51b1:	06                   	push   es
    51b2:	57                   	push   di
    51b3:	9a 53 1d 78 53       	call   0x5378:0x1d53
    51b8:	9a 4c 18 c9 51       	call   0x51c9:0x184c
    51bd:	8d be fc fd          	lea    di,[bp-0x204]
    51c1:	16                   	push   ss
    51c2:	57                   	push   di
    51c3:	68 ff 00             	push   0xff
    51c6:	9a e7 17 db 51       	call   0x51db:0x17e7
    51cb:	6a 00                	push   0x0
    51cd:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    51d1:	b9 02 00             	mov    cx,0x2
    51d4:	f7 e9                	imul   cx
    51d6:	71 05                	jno    0x51dd
    51d8:	9a 3e 04 f1 51       	call   0x51f1:0x43e
    51dd:	50                   	push   ax
    51de:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    51e2:	06                   	push   es
    51e3:	57                   	push   di
    51e4:	9a 72 2a 03 52       	call   0x5203:0x2a72
    51e9:	5a                   	pop    dx
    51ea:	2b c2                	sub    ax,dx
    51ec:	71 05                	jno    0x51f3
    51ee:	9a 3e 04 25 52       	call   0x5225:0x43e
    51f3:	50                   	push   ax
    51f4:	8d be fc fd          	lea    di,[bp-0x204]
    51f8:	16                   	push   ss
    51f9:	57                   	push   di
    51fa:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    51fe:	06                   	push   es
    51ff:	57                   	push   di
    5200:	9a 04 2a ff ff       	call   0xffff:0x2a04
    5205:	89 c7                	mov    di,ax
    5207:	8e c2                	mov    es,dx
    5209:	06                   	push   es
    520a:	57                   	push   di
    520b:	9a 09 1f ff ff       	call   0xffff:0x1f09
    5210:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    5214:	83 c4 06             	add    sp,0x6
    5217:	b8 3c 52             	mov    ax,0x523c
    521a:	0e                   	push   cs
    521b:	50                   	push   ax
    521c:	8d be fc fe          	lea    di,[bp-0x104]
    5220:	16                   	push   ss
    5221:	57                   	push   di
    5222:	9a 4f 0a 2a 52       	call   0x522a:0xa4f
    5227:	9a 08 04 49 52       	call   0x5249:0x408
    522c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    522f:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    5234:	06                   	push   es
    5235:	57                   	push   di
    5236:	9a e3 49 6d 52       	call   0x526d:0x49e3
    523b:	cb                   	retf
    523c:	c9                   	leave
    523d:	ca 04 00             	retf   0x4
    5240:	55                   	push   bp
    5241:	89 e5                	mov    bp,sp
    5243:	b8 04 00             	mov    ax,0x4
    5246:	9a 44 04 94 52       	call   0x5294:0x444
    524b:	83 ec 04             	sub    sp,0x4
    524e:	6a 00                	push   0x0
    5250:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5253:	06                   	push   es
    5254:	57                   	push   di
    5255:	9a 88 55 cf 55       	call   0x55cf:0x5588
    525a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    525d:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    5262:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    5265:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    5268:	06                   	push   es
    5269:	57                   	push   di
    526a:	9a 3f 4a 77 52       	call   0x5277:0x4a3f
    526f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5272:	06                   	push   es
    5273:	57                   	push   di
    5274:	9a ff 49 81 52       	call   0x5281:0x49ff
    5279:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    527c:	06                   	push   es
    527d:	57                   	push   di
    527e:	9a e3 49 3d 53       	call   0x533d:0x49e3
    5283:	c9                   	leave
    5284:	ca 08 00             	retf   0x8
    5287:	01 09                	add    WORD PTR [bx+di],cx
    5289:	01 20                	add    WORD PTR [bx+si],sp
    528b:	55                   	push   bp
    528c:	89 e5                	mov    bp,sp
    528e:	b8 06 02             	mov    ax,0x206
    5291:	9a 44 04 cf 52       	call   0x52cf:0x444
    5296:	81 ec 06 02          	sub    sp,0x206
    529a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    529d:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    52a2:	75 03                	jne    0x52a7
    52a4:	e9 d8 02             	jmp    0x557f
    52a7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    52ac:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    52af:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    52b3:	3d 00 00             	cmp    ax,0x0
    52b6:	75 32                	jne    0x52ea
    52b8:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    52bb:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    52bf:	76 27                	jbe    0x52e8
    52c1:	8d be fe fd          	lea    di,[bp-0x202]
    52c5:	16                   	push   ss
    52c6:	57                   	push   di
    52c7:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    52ca:	06                   	push   es
    52cb:	57                   	push   di
    52cc:	9a cd 17 d9 52       	call   0x52d9:0x17cd
    52d1:	bf 87 52             	mov    di,0x5287
    52d4:	0e                   	push   cs
    52d5:	57                   	push   di
    52d6:	9a 4c 18 e6 52       	call   0x52e6:0x184c
    52db:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    52de:	06                   	push   es
    52df:	57                   	push   di
    52e0:	ff 76 0e             	push   WORD PTR [bp+0xe]
    52e3:	9a e7 17 16 53       	call   0x5316:0x17e7
    52e8:	eb 49                	jmp    0x5333
    52ea:	3d 01 00             	cmp    ax,0x1
    52ed:	75 44                	jne    0x5333
    52ef:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    52f2:	26 8a 05             	mov    al,BYTE PTR es:[di]
    52f5:	30 e4                	xor    ah,ah
    52f7:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    52fb:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    52ff:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    5302:	7d 2d                	jge    0x5331
    5304:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    5308:	8d be fe fd          	lea    di,[bp-0x202]
    530c:	16                   	push   ss
    530d:	57                   	push   di
    530e:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5311:	06                   	push   es
    5312:	57                   	push   di
    5313:	9a cd 17 20 53       	call   0x5320:0x17cd
    5318:	bf 89 52             	mov    di,0x5289
    531b:	0e                   	push   cs
    531c:	57                   	push   di
    531d:	9a 4c 18 2d 53       	call   0x532d:0x184c
    5322:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5325:	06                   	push   es
    5326:	57                   	push   di
    5327:	ff 76 0e             	push   WORD PTR [bp+0xe]
    532a:	9a e7 17 44 53       	call   0x5344:0x17e7
    532f:	eb ca                	jmp    0x52fb
    5331:	eb 00                	jmp    0x5333
    5333:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5336:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5339:	bf 0c 01             	mov    di,0x10c
    533c:	b8 54 53             	mov    ax,0x5354
    533f:	50                   	push   ax
    5340:	57                   	push   di
    5341:	9a 55 22 5b 53       	call   0x535b:0x2255
    5346:	08 c0                	or     al,al
    5348:	74 6b                	je     0x53b5
    534a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    534d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5350:	bf 0c 01             	mov    di,0x10c
    5353:	b8 41 54             	mov    ax,0x5441
    5356:	50                   	push   ax
    5357:	57                   	push   di
    5358:	9a 73 22 86 53       	call   0x5386:0x2273
    535d:	89 c7                	mov    di,ax
    535f:	8e c2                	mov    es,dx
    5361:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    5365:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    5369:	8d be fa fd          	lea    di,[bp-0x206]
    536d:	16                   	push   ss
    536e:	57                   	push   di
    536f:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    5373:	06                   	push   es
    5374:	57                   	push   di
    5375:	9a 53 1d fa 53       	call   0x53fa:0x1d53
    537a:	8d be 00 ff          	lea    di,[bp-0x100]
    537e:	16                   	push   ss
    537f:	57                   	push   di
    5380:	68 ff 00             	push   0xff
    5383:	9a e7 17 b1 53       	call   0x53b1:0x17e7
    5388:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    538d:	b0 00                	mov    al,0x0
    538f:	76 01                	jbe    0x5392
    5391:	40                   	inc    ax
    5392:	8a d0                	mov    dl,al
    5394:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    5399:	b0 00                	mov    al,0x0
    539b:	75 01                	jne    0x539e
    539d:	40                   	inc    ax
    539e:	22 c2                	and    al,dl
    53a0:	08 c0                	or     al,al
    53a2:	74 11                	je     0x53b5
    53a4:	8d be 00 ff          	lea    di,[bp-0x100]
    53a8:	16                   	push   ss
    53a9:	57                   	push   di
    53aa:	6a 01                	push   0x1
    53ac:	6a 01                	push   0x1
    53ae:	9a 75 19 c6 53       	call   0x53c6:0x1975
    53b3:	eb d3                	jmp    0x5388
    53b5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    53b8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    53bb:	bf ad 0d             	mov    di,0xdad
    53be:	b8 d6 53             	mov    ax,0x53d6
    53c1:	50                   	push   ax
    53c2:	57                   	push   di
    53c3:	9a 55 22 dd 53       	call   0x53dd:0x2255
    53c8:	08 c0                	or     al,al
    53ca:	74 6b                	je     0x5437
    53cc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    53cf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    53d2:	bf ad 0d             	mov    di,0xdad
    53d5:	b8 ff ff             	mov    ax,0xffff
    53d8:	50                   	push   ax
    53d9:	57                   	push   di
    53da:	9a 73 22 08 54       	call   0x5408:0x2273
    53df:	89 c7                	mov    di,ax
    53e1:	8e c2                	mov    es,dx
    53e3:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    53e7:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    53eb:	8d be fa fd          	lea    di,[bp-0x206]
    53ef:	16                   	push   ss
    53f0:	57                   	push   di
    53f1:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    53f5:	06                   	push   es
    53f6:	57                   	push   di
    53f7:	9a 53 1d 7c 54       	call   0x547c:0x1d53
    53fc:	8d be 00 ff          	lea    di,[bp-0x100]
    5400:	16                   	push   ss
    5401:	57                   	push   di
    5402:	68 ff 00             	push   0xff
    5405:	9a e7 17 33 54       	call   0x5433:0x17e7
    540a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    540f:	b0 00                	mov    al,0x0
    5411:	76 01                	jbe    0x5414
    5413:	40                   	inc    ax
    5414:	8a d0                	mov    dl,al
    5416:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    541b:	b0 00                	mov    al,0x0
    541d:	75 01                	jne    0x5420
    541f:	40                   	inc    ax
    5420:	22 c2                	and    al,dl
    5422:	08 c0                	or     al,al
    5424:	74 11                	je     0x5437
    5426:	8d be 00 ff          	lea    di,[bp-0x100]
    542a:	16                   	push   ss
    542b:	57                   	push   di
    542c:	6a 01                	push   0x1
    542e:	6a 01                	push   0x1
    5430:	9a 75 19 48 54       	call   0x5448:0x1975
    5435:	eb d3                	jmp    0x540a
    5437:	ff 76 0c             	push   WORD PTR [bp+0xc]
    543a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    543d:	bf 17 06             	mov    di,0x617
    5440:	b8 58 54             	mov    ax,0x5458
    5443:	50                   	push   ax
    5444:	57                   	push   di
    5445:	9a 55 22 5f 54       	call   0x545f:0x2255
    544a:	08 c0                	or     al,al
    544c:	74 6b                	je     0x54b9
    544e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    5451:	ff 76 0a             	push   WORD PTR [bp+0xa]
    5454:	bf 17 06             	mov    di,0x617
    5457:	b8 ac 55             	mov    ax,0x55ac
    545a:	50                   	push   ax
    545b:	57                   	push   di
    545c:	9a 73 22 8a 54       	call   0x548a:0x2273
    5461:	89 c7                	mov    di,ax
    5463:	8e c2                	mov    es,dx
    5465:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    5469:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    546d:	8d be fa fd          	lea    di,[bp-0x206]
    5471:	16                   	push   ss
    5472:	57                   	push   di
    5473:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    5477:	06                   	push   es
    5478:	57                   	push   di
    5479:	9a 53 1d ff 55       	call   0x55ff:0x1d53
    547e:	8d be 00 ff          	lea    di,[bp-0x100]
    5482:	16                   	push   ss
    5483:	57                   	push   di
    5484:	68 ff 00             	push   0xff
    5487:	9a e7 17 b5 54       	call   0x54b5:0x17e7
    548c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5491:	b0 00                	mov    al,0x0
    5493:	76 01                	jbe    0x5496
    5495:	40                   	inc    ax
    5496:	8a d0                	mov    dl,al
    5498:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    549d:	b0 00                	mov    al,0x0
    549f:	75 01                	jne    0x54a2
    54a1:	40                   	inc    ax
    54a2:	22 c2                	and    al,dl
    54a4:	08 c0                	or     al,al
    54a6:	74 11                	je     0x54b9
    54a8:	8d be 00 ff          	lea    di,[bp-0x100]
    54ac:	16                   	push   ss
    54ad:	57                   	push   di
    54ae:	6a 01                	push   0x1
    54b0:	6a 01                	push   0x1
    54b2:	9a 75 19 ca 54       	call   0x54ca:0x1975
    54b7:	eb d3                	jmp    0x548c
    54b9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    54bc:	ff 76 0a             	push   WORD PTR [bp+0xa]
    54bf:	bf 22 00             	mov    di,0x22
    54c2:	b8 dd 54             	mov    ax,0x54dd
    54c5:	50                   	push   ax
    54c6:	57                   	push   di
    54c7:	9a 55 22 e4 54       	call   0x54e4:0x2255
    54cc:	08 c0                	or     al,al
    54ce:	75 03                	jne    0x54d3
    54d0:	e9 84 00             	jmp    0x5557
    54d3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    54d6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    54d9:	bf 22 00             	mov    di,0x22
    54dc:	b8 ff ff             	mov    ax,0xffff
    54df:	50                   	push   ax
    54e0:	57                   	push   di
    54e1:	9a 73 22 0f 55       	call   0x550f:0x2273
    54e6:	89 c7                	mov    di,ax
    54e8:	8e c2                	mov    es,dx
    54ea:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    54ee:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    54f2:	8d be fa fd          	lea    di,[bp-0x206]
    54f6:	16                   	push   ss
    54f7:	57                   	push   di
    54f8:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    54fc:	06                   	push   es
    54fd:	57                   	push   di
    54fe:	9a 24 15 ff ff       	call   0xffff:0x1524
    5503:	8d be 00 ff          	lea    di,[bp-0x100]
    5507:	16                   	push   ss
    5508:	57                   	push   di
    5509:	68 ff 00             	push   0xff
    550c:	9a e7 17 3a 55       	call   0x553a:0x17e7
    5511:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    5515:	7e 40                	jle    0x5557
    5517:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    551b:	30 e4                	xor    ah,ah
    551d:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    5521:	83 be fe fe 12       	cmp    WORD PTR [bp-0x102],0x12
    5526:	7d 2f                	jge    0x5557
    5528:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    552c:	8d be fa fd          	lea    di,[bp-0x206]
    5530:	16                   	push   ss
    5531:	57                   	push   di
    5532:	bf 89 52             	mov    di,0x5289
    5535:	0e                   	push   cs
    5536:	57                   	push   di
    5537:	9a cd 17 45 55       	call   0x5545:0x17cd
    553c:	8d be 00 ff          	lea    di,[bp-0x100]
    5540:	16                   	push   ss
    5541:	57                   	push   di
    5542:	9a 4c 18 53 55       	call   0x5553:0x184c
    5547:	8d be 00 ff          	lea    di,[bp-0x100]
    554b:	16                   	push   ss
    554c:	57                   	push   di
    554d:	68 ff 00             	push   0xff
    5550:	9a e7 17 65 55       	call   0x5565:0x17e7
    5555:	eb ca                	jmp    0x5521
    5557:	8d be fe fd          	lea    di,[bp-0x202]
    555b:	16                   	push   ss
    555c:	57                   	push   di
    555d:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5560:	06                   	push   es
    5561:	57                   	push   di
    5562:	9a cd 17 70 55       	call   0x5570:0x17cd
    5567:	8d be 00 ff          	lea    di,[bp-0x100]
    556b:	16                   	push   ss
    556c:	57                   	push   di
    556d:	9a 4c 18 7d 55       	call   0x557d:0x184c
    5572:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    5575:	06                   	push   es
    5576:	57                   	push   di
    5577:	ff 76 0e             	push   WORD PTR [bp+0xe]
    557a:	9a e7 17 91 55       	call   0x5591:0x17e7
    557f:	c9                   	leave
    5580:	ca 0e 00             	retf   0xe
    5583:	01 09                	add    WORD PTR [bx+di],cx
    5585:	00 01                	add    BYTE PTR [bx+di],al
    5587:	20 55 89             	and    BYTE PTR [di-0x77],dl
    558a:	e5 b8                	in     ax,0xb8
    558c:	04 03                	add    al,0x3
    558e:	9a 44 04 e0 55       	call   0x55e0:0x444
    5593:	81 ec 04 03          	sub    sp,0x304
    5597:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    559a:	26 c4 bd d8 02       	les    di,DWORD PTR es:[di+0x2d8]
    559f:	89 be fc fe          	mov    WORD PTR [bp-0x104],di
    55a3:	8c 86 fe fe          	mov    WORD PTR [bp-0x102],es
    55a7:	06                   	push   es
    55a8:	57                   	push   di
    55a9:	9a e3 49 ff ff       	call   0xffff:0x49e3
    55ae:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    55b3:	8d be 00 ff          	lea    di,[bp-0x100]
    55b7:	16                   	push   ss
    55b8:	57                   	push   di
    55b9:	68 ff 00             	push   0xff
    55bc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55bf:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    55c4:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    55c9:	6a 00                	push   0x0
    55cb:	55                   	push   bp
    55cc:	9a 8b 52 6a 56       	call   0x566a:0x528b
    55d1:	8d be fc fd          	lea    di,[bp-0x204]
    55d5:	16                   	push   ss
    55d6:	57                   	push   di
    55d7:	8d be 00 ff          	lea    di,[bp-0x100]
    55db:	16                   	push   ss
    55dc:	57                   	push   di
    55dd:	9a cd 17 ea 55       	call   0x55ea:0x17cd
    55e2:	bf 83 55             	mov    di,0x5583
    55e5:	0e                   	push   cs
    55e6:	57                   	push   di
    55e7:	9a 4c 18 04 56       	call   0x5604:0x184c
    55ec:	8d be fc fc          	lea    di,[bp-0x304]
    55f0:	16                   	push   ss
    55f1:	57                   	push   di
    55f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    55f5:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
    55fa:	06                   	push   es
    55fb:	57                   	push   di
    55fc:	9a 53 1d 9a 56       	call   0x569a:0x1d53
    5601:	9a 4c 18 12 56       	call   0x5612:0x184c
    5606:	8d be 00 ff          	lea    di,[bp-0x100]
    560a:	16                   	push   ss
    560b:	57                   	push   di
    560c:	68 ff 00             	push   0xff
    560f:	9a e7 17 7b 56       	call   0x567b:0x17e7
    5614:	8d be 00 ff          	lea    di,[bp-0x100]
    5618:	16                   	push   ss
    5619:	57                   	push   di
    561a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    561e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5623:	06                   	push   es
    5624:	57                   	push   di
    5625:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5628:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    562c:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    5630:	75 17                	jne    0x5649
    5632:	bf 85 55             	mov    di,0x5585
    5635:	0e                   	push   cs
    5636:	57                   	push   di
    5637:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    563b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5640:	06                   	push   es
    5641:	57                   	push   di
    5642:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5645:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5649:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    564e:	8d be 00 ff          	lea    di,[bp-0x100]
    5652:	16                   	push   ss
    5653:	57                   	push   di
    5654:	68 ff 00             	push   0xff
    5657:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    565a:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    565f:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    5664:	6a 0a                	push   0xa
    5666:	55                   	push   bp
    5667:	9a 8b 52 cb 56       	call   0x56cb:0x528b
    566c:	8d be fc fd          	lea    di,[bp-0x204]
    5670:	16                   	push   ss
    5671:	57                   	push   di
    5672:	8d be 00 ff          	lea    di,[bp-0x100]
    5676:	16                   	push   ss
    5677:	57                   	push   di
    5678:	9a cd 17 85 56       	call   0x5685:0x17cd
    567d:	bf 86 55             	mov    di,0x5586
    5680:	0e                   	push   cs
    5681:	57                   	push   di
    5682:	9a 4c 18 9f 56       	call   0x569f:0x184c
    5687:	8d be fc fc          	lea    di,[bp-0x304]
    568b:	16                   	push   ss
    568c:	57                   	push   di
    568d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5690:	26 c4 bd 90 01       	les    di,DWORD PTR es:[di+0x190]
    5695:	06                   	push   es
    5696:	57                   	push   di
    5697:	9a 53 1d 19 57       	call   0x5719:0x1d53
    569c:	9a 4c 18 ad 56       	call   0x56ad:0x184c
    56a1:	8d be 00 ff          	lea    di,[bp-0x100]
    56a5:	16                   	push   ss
    56a6:	57                   	push   di
    56a7:	68 ff 00             	push   0xff
    56aa:	9a e7 17 fa 56       	call   0x56fa:0x17e7
    56af:	8d be 00 ff          	lea    di,[bp-0x100]
    56b3:	16                   	push   ss
    56b4:	57                   	push   di
    56b5:	68 ff 00             	push   0xff
    56b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56bb:	26 ff b5 9e 01       	push   WORD PTR es:[di+0x19e]
    56c0:	26 ff b5 9c 01       	push   WORD PTR es:[di+0x19c]
    56c5:	6a 25                	push   0x25
    56c7:	55                   	push   bp
    56c8:	9a 8b 52 e9 56       	call   0x56e9:0x528b
    56cd:	8d be 00 ff          	lea    di,[bp-0x100]
    56d1:	16                   	push   ss
    56d2:	57                   	push   di
    56d3:	68 ff 00             	push   0xff
    56d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    56d9:	26 ff b5 96 01       	push   WORD PTR es:[di+0x196]
    56de:	26 ff b5 94 01       	push   WORD PTR es:[di+0x194]
    56e3:	6a 46                	push   0x46
    56e5:	55                   	push   bp
    56e6:	9a 8b 52 86 57       	call   0x5786:0x528b
    56eb:	8d be fc fd          	lea    di,[bp-0x204]
    56ef:	16                   	push   ss
    56f0:	57                   	push   di
    56f1:	8d be 00 ff          	lea    di,[bp-0x100]
    56f5:	16                   	push   ss
    56f6:	57                   	push   di
    56f7:	9a cd 17 04 57       	call   0x5704:0x17cd
    56fc:	bf 86 55             	mov    di,0x5586
    56ff:	0e                   	push   cs
    5700:	57                   	push   di
    5701:	9a 4c 18 1e 57       	call   0x571e:0x184c
    5706:	8d be fc fc          	lea    di,[bp-0x304]
    570a:	16                   	push   ss
    570b:	57                   	push   di
    570c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    570f:	26 c4 bd 98 01       	les    di,DWORD PTR es:[di+0x198]
    5714:	06                   	push   es
    5715:	57                   	push   di
    5716:	9a 53 1d ff ff       	call   0xffff:0x1d53
    571b:	9a 4c 18 2c 57       	call   0x572c:0x184c
    5720:	8d be 00 ff          	lea    di,[bp-0x100]
    5724:	16                   	push   ss
    5725:	57                   	push   di
    5726:	68 ff 00             	push   0xff
    5729:	9a e7 17 44 59       	call   0x5944:0x17e7
    572e:	8d be 00 ff          	lea    di,[bp-0x100]
    5732:	16                   	push   ss
    5733:	57                   	push   di
    5734:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5738:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    573d:	06                   	push   es
    573e:	57                   	push   di
    573f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5742:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5746:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    574a:	75 17                	jne    0x5763
    574c:	bf 85 55             	mov    di,0x5585
    574f:	0e                   	push   cs
    5750:	57                   	push   di
    5751:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5755:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    575a:	06                   	push   es
    575b:	57                   	push   di
    575c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    575f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5763:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5768:	8d be 00 ff          	lea    di,[bp-0x100]
    576c:	16                   	push   ss
    576d:	57                   	push   di
    576e:	68 ff 00             	push   0xff
    5771:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5774:	26 ff b5 be 03       	push   WORD PTR es:[di+0x3be]
    5779:	26 ff b5 bc 03       	push   WORD PTR es:[di+0x3bc]
    577e:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5782:	55                   	push   bp
    5783:	9a 8b 52 a6 57       	call   0x57a6:0x528b
    5788:	8d be 00 ff          	lea    di,[bp-0x100]
    578c:	16                   	push   ss
    578d:	57                   	push   di
    578e:	68 ff 00             	push   0xff
    5791:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5794:	26 ff b5 0a 05       	push   WORD PTR es:[di+0x50a]
    5799:	26 ff b5 08 05       	push   WORD PTR es:[di+0x508]
    579e:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    57a2:	55                   	push   bp
    57a3:	9a 8b 52 ea 57       	call   0x57ea:0x528b
    57a8:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    57ad:	76 18                	jbe    0x57c7
    57af:	8d be 00 ff          	lea    di,[bp-0x100]
    57b3:	16                   	push   ss
    57b4:	57                   	push   di
    57b5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    57b9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    57be:	06                   	push   es
    57bf:	57                   	push   di
    57c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    57c3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    57c7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    57cc:	8d be 00 ff          	lea    di,[bp-0x100]
    57d0:	16                   	push   ss
    57d1:	57                   	push   di
    57d2:	68 ff 00             	push   0xff
    57d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57d8:	26 ff b5 c2 03       	push   WORD PTR es:[di+0x3c2]
    57dd:	26 ff b5 c0 03       	push   WORD PTR es:[di+0x3c0]
    57e2:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    57e6:	55                   	push   bp
    57e7:	9a 8b 52 0a 58       	call   0x580a:0x528b
    57ec:	8d be 00 ff          	lea    di,[bp-0x100]
    57f0:	16                   	push   ss
    57f1:	57                   	push   di
    57f2:	68 ff 00             	push   0xff
    57f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    57f8:	26 ff b5 0e 05       	push   WORD PTR es:[di+0x50e]
    57fd:	26 ff b5 0c 05       	push   WORD PTR es:[di+0x50c]
    5802:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5806:	55                   	push   bp
    5807:	9a 8b 52 4e 58       	call   0x584e:0x528b
    580c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5811:	76 18                	jbe    0x582b
    5813:	8d be 00 ff          	lea    di,[bp-0x100]
    5817:	16                   	push   ss
    5818:	57                   	push   di
    5819:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    581d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5822:	06                   	push   es
    5823:	57                   	push   di
    5824:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5827:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    582b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5830:	8d be 00 ff          	lea    di,[bp-0x100]
    5834:	16                   	push   ss
    5835:	57                   	push   di
    5836:	68 ff 00             	push   0xff
    5839:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    583c:	26 ff b5 c6 03       	push   WORD PTR es:[di+0x3c6]
    5841:	26 ff b5 c4 03       	push   WORD PTR es:[di+0x3c4]
    5846:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    584a:	55                   	push   bp
    584b:	9a 8b 52 6e 58       	call   0x586e:0x528b
    5850:	8d be 00 ff          	lea    di,[bp-0x100]
    5854:	16                   	push   ss
    5855:	57                   	push   di
    5856:	68 ff 00             	push   0xff
    5859:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    585c:	26 ff b5 12 05       	push   WORD PTR es:[di+0x512]
    5861:	26 ff b5 10 05       	push   WORD PTR es:[di+0x510]
    5866:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    586a:	55                   	push   bp
    586b:	9a 8b 52 b2 58       	call   0x58b2:0x528b
    5870:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5875:	76 18                	jbe    0x588f
    5877:	8d be 00 ff          	lea    di,[bp-0x100]
    587b:	16                   	push   ss
    587c:	57                   	push   di
    587d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5881:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5886:	06                   	push   es
    5887:	57                   	push   di
    5888:	26 c4 3d             	les    di,DWORD PTR es:[di]
    588b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    588f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5894:	8d be 00 ff          	lea    di,[bp-0x100]
    5898:	16                   	push   ss
    5899:	57                   	push   di
    589a:	68 ff 00             	push   0xff
    589d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58a0:	26 ff b5 ca 03       	push   WORD PTR es:[di+0x3ca]
    58a5:	26 ff b5 c8 03       	push   WORD PTR es:[di+0x3c8]
    58aa:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    58ae:	55                   	push   bp
    58af:	9a 8b 52 d2 58       	call   0x58d2:0x528b
    58b4:	8d be 00 ff          	lea    di,[bp-0x100]
    58b8:	16                   	push   ss
    58b9:	57                   	push   di
    58ba:	68 ff 00             	push   0xff
    58bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    58c0:	26 ff b5 16 05       	push   WORD PTR es:[di+0x516]
    58c5:	26 ff b5 14 05       	push   WORD PTR es:[di+0x514]
    58ca:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    58ce:	55                   	push   bp
    58cf:	9a 8b 52 33 59       	call   0x5933:0x528b
    58d4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    58d9:	76 18                	jbe    0x58f3
    58db:	8d be 00 ff          	lea    di,[bp-0x100]
    58df:	16                   	push   ss
    58e0:	57                   	push   di
    58e1:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    58e5:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    58ea:	06                   	push   es
    58eb:	57                   	push   di
    58ec:	26 c4 3d             	les    di,DWORD PTR es:[di]
    58ef:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    58f3:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    58f7:	75 17                	jne    0x5910
    58f9:	bf 85 55             	mov    di,0x5585
    58fc:	0e                   	push   cs
    58fd:	57                   	push   di
    58fe:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5902:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5907:	06                   	push   es
    5908:	57                   	push   di
    5909:	26 c4 3d             	les    di,DWORD PTR es:[di]
    590c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5910:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5915:	8d be 00 ff          	lea    di,[bp-0x100]
    5919:	16                   	push   ss
    591a:	57                   	push   di
    591b:	68 ff 00             	push   0xff
    591e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5921:	26 ff b5 ce 03       	push   WORD PTR es:[di+0x3ce]
    5926:	26 ff b5 cc 03       	push   WORD PTR es:[di+0x3cc]
    592b:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    592f:	55                   	push   bp
    5930:	9a 8b 52 7c 59       	call   0x597c:0x528b
    5935:	8d be fc fd          	lea    di,[bp-0x204]
    5939:	16                   	push   ss
    593a:	57                   	push   di
    593b:	8d be 00 ff          	lea    di,[bp-0x100]
    593f:	16                   	push   ss
    5940:	57                   	push   di
    5941:	9a cd 17 4e 59       	call   0x594e:0x17cd
    5946:	bf 83 55             	mov    di,0x5583
    5949:	0e                   	push   cs
    594a:	57                   	push   di
    594b:	9a 4c 18 5c 59       	call   0x595c:0x184c
    5950:	8d be 00 ff          	lea    di,[bp-0x100]
    5954:	16                   	push   ss
    5955:	57                   	push   di
    5956:	68 ff 00             	push   0xff
    5959:	9a e7 17 8f 5d       	call   0x5d8f:0x17e7
    595e:	8d be 00 ff          	lea    di,[bp-0x100]
    5962:	16                   	push   ss
    5963:	57                   	push   di
    5964:	68 ff 00             	push   0xff
    5967:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    596a:	26 ff b5 da 03       	push   WORD PTR es:[di+0x3da]
    596f:	26 ff b5 d8 03       	push   WORD PTR es:[di+0x3d8]
    5974:	ff 36 e2 01          	push   WORD PTR ds:0x1e2
    5978:	55                   	push   bp
    5979:	9a 8b 52 dd 59       	call   0x59dd:0x528b
    597e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5983:	76 18                	jbe    0x599d
    5985:	8d be 00 ff          	lea    di,[bp-0x100]
    5989:	16                   	push   ss
    598a:	57                   	push   di
    598b:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    598f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5994:	06                   	push   es
    5995:	57                   	push   di
    5996:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5999:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    599d:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    59a1:	75 17                	jne    0x59ba
    59a3:	bf 85 55             	mov    di,0x5585
    59a6:	0e                   	push   cs
    59a7:	57                   	push   di
    59a8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    59ac:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    59b1:	06                   	push   es
    59b2:	57                   	push   di
    59b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    59b6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    59ba:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    59bf:	8d be 00 ff          	lea    di,[bp-0x100]
    59c3:	16                   	push   ss
    59c4:	57                   	push   di
    59c5:	68 ff 00             	push   0xff
    59c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59cb:	26 ff b5 7a 05       	push   WORD PTR es:[di+0x57a]
    59d0:	26 ff b5 78 05       	push   WORD PTR es:[di+0x578]
    59d5:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    59d9:	55                   	push   bp
    59da:	9a 8b 52 fd 59       	call   0x59fd:0x528b
    59df:	8d be 00 ff          	lea    di,[bp-0x100]
    59e3:	16                   	push   ss
    59e4:	57                   	push   di
    59e5:	68 ff 00             	push   0xff
    59e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    59eb:	26 ff b5 8a 05       	push   WORD PTR es:[di+0x58a]
    59f0:	26 ff b5 88 05       	push   WORD PTR es:[di+0x588]
    59f5:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    59f9:	55                   	push   bp
    59fa:	9a 8b 52 41 5a       	call   0x5a41:0x528b
    59ff:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5a04:	76 18                	jbe    0x5a1e
    5a06:	8d be 00 ff          	lea    di,[bp-0x100]
    5a0a:	16                   	push   ss
    5a0b:	57                   	push   di
    5a0c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5a10:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5a15:	06                   	push   es
    5a16:	57                   	push   di
    5a17:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a1a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5a1e:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5a23:	8d be 00 ff          	lea    di,[bp-0x100]
    5a27:	16                   	push   ss
    5a28:	57                   	push   di
    5a29:	68 ff 00             	push   0xff
    5a2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a2f:	26 ff b5 e2 03       	push   WORD PTR es:[di+0x3e2]
    5a34:	26 ff b5 e0 03       	push   WORD PTR es:[di+0x3e0]
    5a39:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5a3d:	55                   	push   bp
    5a3e:	9a 8b 52 61 5a       	call   0x5a61:0x528b
    5a43:	8d be 00 ff          	lea    di,[bp-0x100]
    5a47:	16                   	push   ss
    5a48:	57                   	push   di
    5a49:	68 ff 00             	push   0xff
    5a4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a4f:	26 ff b5 1a 05       	push   WORD PTR es:[di+0x51a]
    5a54:	26 ff b5 18 05       	push   WORD PTR es:[di+0x518]
    5a59:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5a5d:	55                   	push   bp
    5a5e:	9a 8b 52 a5 5a       	call   0x5aa5:0x528b
    5a63:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5a68:	76 18                	jbe    0x5a82
    5a6a:	8d be 00 ff          	lea    di,[bp-0x100]
    5a6e:	16                   	push   ss
    5a6f:	57                   	push   di
    5a70:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5a74:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5a79:	06                   	push   es
    5a7a:	57                   	push   di
    5a7b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5a7e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5a82:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5a87:	8d be 00 ff          	lea    di,[bp-0x100]
    5a8b:	16                   	push   ss
    5a8c:	57                   	push   di
    5a8d:	68 ff 00             	push   0xff
    5a90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5a93:	26 ff b5 e6 03       	push   WORD PTR es:[di+0x3e6]
    5a98:	26 ff b5 e4 03       	push   WORD PTR es:[di+0x3e4]
    5a9d:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5aa1:	55                   	push   bp
    5aa2:	9a 8b 52 c5 5a       	call   0x5ac5:0x528b
    5aa7:	8d be 00 ff          	lea    di,[bp-0x100]
    5aab:	16                   	push   ss
    5aac:	57                   	push   di
    5aad:	68 ff 00             	push   0xff
    5ab0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ab3:	26 ff b5 1e 05       	push   WORD PTR es:[di+0x51e]
    5ab8:	26 ff b5 1c 05       	push   WORD PTR es:[di+0x51c]
    5abd:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5ac1:	55                   	push   bp
    5ac2:	9a 8b 52 09 5b       	call   0x5b09:0x528b
    5ac7:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5acc:	76 18                	jbe    0x5ae6
    5ace:	8d be 00 ff          	lea    di,[bp-0x100]
    5ad2:	16                   	push   ss
    5ad3:	57                   	push   di
    5ad4:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5ad8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5add:	06                   	push   es
    5ade:	57                   	push   di
    5adf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5ae2:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5ae6:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5aeb:	8d be 00 ff          	lea    di,[bp-0x100]
    5aef:	16                   	push   ss
    5af0:	57                   	push   di
    5af1:	68 ff 00             	push   0xff
    5af4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5af7:	26 ff b5 ea 03       	push   WORD PTR es:[di+0x3ea]
    5afc:	26 ff b5 e8 03       	push   WORD PTR es:[di+0x3e8]
    5b01:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5b05:	55                   	push   bp
    5b06:	9a 8b 52 29 5b       	call   0x5b29:0x528b
    5b0b:	8d be 00 ff          	lea    di,[bp-0x100]
    5b0f:	16                   	push   ss
    5b10:	57                   	push   di
    5b11:	68 ff 00             	push   0xff
    5b14:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b17:	26 ff b5 22 05       	push   WORD PTR es:[di+0x522]
    5b1c:	26 ff b5 20 05       	push   WORD PTR es:[di+0x520]
    5b21:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5b25:	55                   	push   bp
    5b26:	9a 8b 52 6d 5b       	call   0x5b6d:0x528b
    5b2b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5b30:	76 18                	jbe    0x5b4a
    5b32:	8d be 00 ff          	lea    di,[bp-0x100]
    5b36:	16                   	push   ss
    5b37:	57                   	push   di
    5b38:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5b3c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5b41:	06                   	push   es
    5b42:	57                   	push   di
    5b43:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5b46:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5b4a:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5b4f:	8d be 00 ff          	lea    di,[bp-0x100]
    5b53:	16                   	push   ss
    5b54:	57                   	push   di
    5b55:	68 ff 00             	push   0xff
    5b58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b5b:	26 ff b5 ee 03       	push   WORD PTR es:[di+0x3ee]
    5b60:	26 ff b5 ec 03       	push   WORD PTR es:[di+0x3ec]
    5b65:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5b69:	55                   	push   bp
    5b6a:	9a 8b 52 8d 5b       	call   0x5b8d:0x528b
    5b6f:	8d be 00 ff          	lea    di,[bp-0x100]
    5b73:	16                   	push   ss
    5b74:	57                   	push   di
    5b75:	68 ff 00             	push   0xff
    5b78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5b7b:	26 ff b5 26 05       	push   WORD PTR es:[di+0x526]
    5b80:	26 ff b5 24 05       	push   WORD PTR es:[di+0x524]
    5b85:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5b89:	55                   	push   bp
    5b8a:	9a 8b 52 d1 5b       	call   0x5bd1:0x528b
    5b8f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5b94:	76 18                	jbe    0x5bae
    5b96:	8d be 00 ff          	lea    di,[bp-0x100]
    5b9a:	16                   	push   ss
    5b9b:	57                   	push   di
    5b9c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5ba0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5ba5:	06                   	push   es
    5ba6:	57                   	push   di
    5ba7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5baa:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5bae:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5bb3:	8d be 00 ff          	lea    di,[bp-0x100]
    5bb7:	16                   	push   ss
    5bb8:	57                   	push   di
    5bb9:	68 ff 00             	push   0xff
    5bbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bbf:	26 ff b5 f2 03       	push   WORD PTR es:[di+0x3f2]
    5bc4:	26 ff b5 f0 03       	push   WORD PTR es:[di+0x3f0]
    5bc9:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5bcd:	55                   	push   bp
    5bce:	9a 8b 52 f1 5b       	call   0x5bf1:0x528b
    5bd3:	8d be 00 ff          	lea    di,[bp-0x100]
    5bd7:	16                   	push   ss
    5bd8:	57                   	push   di
    5bd9:	68 ff 00             	push   0xff
    5bdc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5bdf:	26 ff b5 2a 05       	push   WORD PTR es:[di+0x52a]
    5be4:	26 ff b5 28 05       	push   WORD PTR es:[di+0x528]
    5be9:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5bed:	55                   	push   bp
    5bee:	9a 8b 52 35 5c       	call   0x5c35:0x528b
    5bf3:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5bf8:	76 18                	jbe    0x5c12
    5bfa:	8d be 00 ff          	lea    di,[bp-0x100]
    5bfe:	16                   	push   ss
    5bff:	57                   	push   di
    5c00:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5c04:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5c09:	06                   	push   es
    5c0a:	57                   	push   di
    5c0b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5c0e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5c12:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5c17:	8d be 00 ff          	lea    di,[bp-0x100]
    5c1b:	16                   	push   ss
    5c1c:	57                   	push   di
    5c1d:	68 ff 00             	push   0xff
    5c20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c23:	26 ff b5 f6 03       	push   WORD PTR es:[di+0x3f6]
    5c28:	26 ff b5 f4 03       	push   WORD PTR es:[di+0x3f4]
    5c2d:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5c31:	55                   	push   bp
    5c32:	9a 8b 52 55 5c       	call   0x5c55:0x528b
    5c37:	8d be 00 ff          	lea    di,[bp-0x100]
    5c3b:	16                   	push   ss
    5c3c:	57                   	push   di
    5c3d:	68 ff 00             	push   0xff
    5c40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c43:	26 ff b5 2e 05       	push   WORD PTR es:[di+0x52e]
    5c48:	26 ff b5 2c 05       	push   WORD PTR es:[di+0x52c]
    5c4d:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5c51:	55                   	push   bp
    5c52:	9a 8b 52 99 5c       	call   0x5c99:0x528b
    5c57:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5c5c:	76 18                	jbe    0x5c76
    5c5e:	8d be 00 ff          	lea    di,[bp-0x100]
    5c62:	16                   	push   ss
    5c63:	57                   	push   di
    5c64:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5c68:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5c6d:	06                   	push   es
    5c6e:	57                   	push   di
    5c6f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5c72:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5c76:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5c7b:	8d be 00 ff          	lea    di,[bp-0x100]
    5c7f:	16                   	push   ss
    5c80:	57                   	push   di
    5c81:	68 ff 00             	push   0xff
    5c84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5c87:	26 ff b5 7e 05       	push   WORD PTR es:[di+0x57e]
    5c8c:	26 ff b5 7c 05       	push   WORD PTR es:[di+0x57c]
    5c91:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5c95:	55                   	push   bp
    5c96:	9a 8b 52 b9 5c       	call   0x5cb9:0x528b
    5c9b:	8d be 00 ff          	lea    di,[bp-0x100]
    5c9f:	16                   	push   ss
    5ca0:	57                   	push   di
    5ca1:	68 ff 00             	push   0xff
    5ca4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ca7:	26 ff b5 32 05       	push   WORD PTR es:[di+0x532]
    5cac:	26 ff b5 30 05       	push   WORD PTR es:[di+0x530]
    5cb1:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5cb5:	55                   	push   bp
    5cb6:	9a 8b 52 fd 5c       	call   0x5cfd:0x528b
    5cbb:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5cc0:	76 18                	jbe    0x5cda
    5cc2:	8d be 00 ff          	lea    di,[bp-0x100]
    5cc6:	16                   	push   ss
    5cc7:	57                   	push   di
    5cc8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5ccc:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5cd1:	06                   	push   es
    5cd2:	57                   	push   di
    5cd3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5cd6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5cda:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5cdf:	8d be 00 ff          	lea    di,[bp-0x100]
    5ce3:	16                   	push   ss
    5ce4:	57                   	push   di
    5ce5:	68 ff 00             	push   0xff
    5ce8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ceb:	26 ff b5 82 05       	push   WORD PTR es:[di+0x582]
    5cf0:	26 ff b5 80 05       	push   WORD PTR es:[di+0x580]
    5cf5:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5cf9:	55                   	push   bp
    5cfa:	9a 8b 52 1d 5d       	call   0x5d1d:0x528b
    5cff:	8d be 00 ff          	lea    di,[bp-0x100]
    5d03:	16                   	push   ss
    5d04:	57                   	push   di
    5d05:	68 ff 00             	push   0xff
    5d08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d0b:	26 ff b5 36 05       	push   WORD PTR es:[di+0x536]
    5d10:	26 ff b5 34 05       	push   WORD PTR es:[di+0x534]
    5d15:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5d19:	55                   	push   bp
    5d1a:	9a 8b 52 7e 5d       	call   0x5d7e:0x528b
    5d1f:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5d24:	76 18                	jbe    0x5d3e
    5d26:	8d be 00 ff          	lea    di,[bp-0x100]
    5d2a:	16                   	push   ss
    5d2b:	57                   	push   di
    5d2c:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5d30:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5d35:	06                   	push   es
    5d36:	57                   	push   di
    5d37:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5d3a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5d3e:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    5d42:	75 17                	jne    0x5d5b
    5d44:	bf 85 55             	mov    di,0x5585
    5d47:	0e                   	push   cs
    5d48:	57                   	push   di
    5d49:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5d4d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5d52:	06                   	push   es
    5d53:	57                   	push   di
    5d54:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5d57:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5d5b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5d60:	8d be 00 ff          	lea    di,[bp-0x100]
    5d64:	16                   	push   ss
    5d65:	57                   	push   di
    5d66:	68 ff 00             	push   0xff
    5d69:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5d6c:	26 ff b5 86 05       	push   WORD PTR es:[di+0x586]
    5d71:	26 ff b5 84 05       	push   WORD PTR es:[di+0x584]
    5d76:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5d7a:	55                   	push   bp
    5d7b:	9a 8b 52 c7 5d       	call   0x5dc7:0x528b
    5d80:	8d be fc fd          	lea    di,[bp-0x204]
    5d84:	16                   	push   ss
    5d85:	57                   	push   di
    5d86:	8d be 00 ff          	lea    di,[bp-0x100]
    5d8a:	16                   	push   ss
    5d8b:	57                   	push   di
    5d8c:	9a cd 17 99 5d       	call   0x5d99:0x17cd
    5d91:	bf 83 55             	mov    di,0x5583
    5d94:	0e                   	push   cs
    5d95:	57                   	push   di
    5d96:	9a 4c 18 a7 5d       	call   0x5da7:0x184c
    5d9b:	8d be 00 ff          	lea    di,[bp-0x100]
    5d9f:	16                   	push   ss
    5da0:	57                   	push   di
    5da1:	68 ff 00             	push   0xff
    5da4:	9a e7 17 39 5e       	call   0x5e39:0x17e7
    5da9:	8d be 00 ff          	lea    di,[bp-0x100]
    5dad:	16                   	push   ss
    5dae:	57                   	push   di
    5daf:	68 ff 00             	push   0xff
    5db2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5db5:	26 ff b5 02 04       	push   WORD PTR es:[di+0x402]
    5dba:	26 ff b5 00 04       	push   WORD PTR es:[di+0x400]
    5dbf:	ff 36 e2 01          	push   WORD PTR ds:0x1e2
    5dc3:	55                   	push   bp
    5dc4:	9a 8b 52 28 5e       	call   0x5e28:0x528b
    5dc9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5dce:	76 18                	jbe    0x5de8
    5dd0:	8d be 00 ff          	lea    di,[bp-0x100]
    5dd4:	16                   	push   ss
    5dd5:	57                   	push   di
    5dd6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5dda:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5ddf:	06                   	push   es
    5de0:	57                   	push   di
    5de1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5de4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5de8:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    5dec:	75 17                	jne    0x5e05
    5dee:	bf 85 55             	mov    di,0x5585
    5df1:	0e                   	push   cs
    5df2:	57                   	push   di
    5df3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5df7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5dfc:	06                   	push   es
    5dfd:	57                   	push   di
    5dfe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e01:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5e05:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5e0a:	8d be 00 ff          	lea    di,[bp-0x100]
    5e0e:	16                   	push   ss
    5e0f:	57                   	push   di
    5e10:	68 ff 00             	push   0xff
    5e13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e16:	26 ff b5 0a 04       	push   WORD PTR es:[di+0x40a]
    5e1b:	26 ff b5 08 04       	push   WORD PTR es:[di+0x408]
    5e20:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5e24:	55                   	push   bp
    5e25:	9a 8b 52 71 5e       	call   0x5e71:0x528b
    5e2a:	8d be fc fd          	lea    di,[bp-0x204]
    5e2e:	16                   	push   ss
    5e2f:	57                   	push   di
    5e30:	8d be 00 ff          	lea    di,[bp-0x100]
    5e34:	16                   	push   ss
    5e35:	57                   	push   di
    5e36:	9a cd 17 43 5e       	call   0x5e43:0x17cd
    5e3b:	bf 83 55             	mov    di,0x5583
    5e3e:	0e                   	push   cs
    5e3f:	57                   	push   di
    5e40:	9a 4c 18 51 5e       	call   0x5e51:0x184c
    5e45:	8d be 00 ff          	lea    di,[bp-0x100]
    5e49:	16                   	push   ss
    5e4a:	57                   	push   di
    5e4b:	68 ff 00             	push   0xff
    5e4e:	9a e7 17 00 62       	call   0x6200:0x17e7
    5e53:	8d be 00 ff          	lea    di,[bp-0x100]
    5e57:	16                   	push   ss
    5e58:	57                   	push   di
    5e59:	68 ff 00             	push   0xff
    5e5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5e5f:	26 ff b5 22 04       	push   WORD PTR es:[di+0x422]
    5e64:	26 ff b5 20 04       	push   WORD PTR es:[di+0x420]
    5e69:	ff 36 e2 01          	push   WORD PTR ds:0x1e2
    5e6d:	55                   	push   bp
    5e6e:	9a 8b 52 d2 5e       	call   0x5ed2:0x528b
    5e73:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5e78:	76 18                	jbe    0x5e92
    5e7a:	8d be 00 ff          	lea    di,[bp-0x100]
    5e7e:	16                   	push   ss
    5e7f:	57                   	push   di
    5e80:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5e84:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5e89:	06                   	push   es
    5e8a:	57                   	push   di
    5e8b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5e8e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5e92:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    5e96:	75 17                	jne    0x5eaf
    5e98:	bf 85 55             	mov    di,0x5585
    5e9b:	0e                   	push   cs
    5e9c:	57                   	push   di
    5e9d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5ea1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5ea6:	06                   	push   es
    5ea7:	57                   	push   di
    5ea8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5eab:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5eaf:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5eb4:	8d be 00 ff          	lea    di,[bp-0x100]
    5eb8:	16                   	push   ss
    5eb9:	57                   	push   di
    5eba:	68 ff 00             	push   0xff
    5ebd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ec0:	26 ff b5 9e 04       	push   WORD PTR es:[di+0x49e]
    5ec5:	26 ff b5 9c 04       	push   WORD PTR es:[di+0x49c]
    5eca:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5ece:	55                   	push   bp
    5ecf:	9a 8b 52 f2 5e       	call   0x5ef2:0x528b
    5ed4:	8d be 00 ff          	lea    di,[bp-0x100]
    5ed8:	16                   	push   ss
    5ed9:	57                   	push   di
    5eda:	68 ff 00             	push   0xff
    5edd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5ee0:	26 ff b5 3e 05       	push   WORD PTR es:[di+0x53e]
    5ee5:	26 ff b5 3c 05       	push   WORD PTR es:[di+0x53c]
    5eea:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5eee:	55                   	push   bp
    5eef:	9a 8b 52 36 5f       	call   0x5f36:0x528b
    5ef4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5ef9:	76 18                	jbe    0x5f13
    5efb:	8d be 00 ff          	lea    di,[bp-0x100]
    5eff:	16                   	push   ss
    5f00:	57                   	push   di
    5f01:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5f05:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5f0a:	06                   	push   es
    5f0b:	57                   	push   di
    5f0c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f0f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5f13:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5f18:	8d be 00 ff          	lea    di,[bp-0x100]
    5f1c:	16                   	push   ss
    5f1d:	57                   	push   di
    5f1e:	68 ff 00             	push   0xff
    5f21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f24:	26 ff b5 a2 04       	push   WORD PTR es:[di+0x4a2]
    5f29:	26 ff b5 a0 04       	push   WORD PTR es:[di+0x4a0]
    5f2e:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5f32:	55                   	push   bp
    5f33:	9a 8b 52 7a 5f       	call   0x5f7a:0x528b
    5f38:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5f3d:	76 18                	jbe    0x5f57
    5f3f:	8d be 00 ff          	lea    di,[bp-0x100]
    5f43:	16                   	push   ss
    5f44:	57                   	push   di
    5f45:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5f49:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5f4e:	06                   	push   es
    5f4f:	57                   	push   di
    5f50:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5f53:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5f57:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5f5c:	8d be 00 ff          	lea    di,[bp-0x100]
    5f60:	16                   	push   ss
    5f61:	57                   	push   di
    5f62:	68 ff 00             	push   0xff
    5f65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f68:	26 ff b5 a6 04       	push   WORD PTR es:[di+0x4a6]
    5f6d:	26 ff b5 a4 04       	push   WORD PTR es:[di+0x4a4]
    5f72:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5f76:	55                   	push   bp
    5f77:	9a 8b 52 9a 5f       	call   0x5f9a:0x528b
    5f7c:	8d be 00 ff          	lea    di,[bp-0x100]
    5f80:	16                   	push   ss
    5f81:	57                   	push   di
    5f82:	68 ff 00             	push   0xff
    5f85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5f88:	26 ff b5 46 05       	push   WORD PTR es:[di+0x546]
    5f8d:	26 ff b5 44 05       	push   WORD PTR es:[di+0x544]
    5f92:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5f96:	55                   	push   bp
    5f97:	9a 8b 52 de 5f       	call   0x5fde:0x528b
    5f9c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    5fa1:	76 18                	jbe    0x5fbb
    5fa3:	8d be 00 ff          	lea    di,[bp-0x100]
    5fa7:	16                   	push   ss
    5fa8:	57                   	push   di
    5fa9:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    5fad:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    5fb2:	06                   	push   es
    5fb3:	57                   	push   di
    5fb4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    5fb7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    5fbb:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    5fc0:	8d be 00 ff          	lea    di,[bp-0x100]
    5fc4:	16                   	push   ss
    5fc5:	57                   	push   di
    5fc6:	68 ff 00             	push   0xff
    5fc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fcc:	26 ff b5 aa 04       	push   WORD PTR es:[di+0x4aa]
    5fd1:	26 ff b5 a8 04       	push   WORD PTR es:[di+0x4a8]
    5fd6:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    5fda:	55                   	push   bp
    5fdb:	9a 8b 52 fe 5f       	call   0x5ffe:0x528b
    5fe0:	8d be 00 ff          	lea    di,[bp-0x100]
    5fe4:	16                   	push   ss
    5fe5:	57                   	push   di
    5fe6:	68 ff 00             	push   0xff
    5fe9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5fec:	26 ff b5 4a 05       	push   WORD PTR es:[di+0x54a]
    5ff1:	26 ff b5 48 05       	push   WORD PTR es:[di+0x548]
    5ff6:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    5ffa:	55                   	push   bp
    5ffb:	9a 8b 52 42 60       	call   0x6042:0x528b
    6000:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6005:	76 18                	jbe    0x601f
    6007:	8d be 00 ff          	lea    di,[bp-0x100]
    600b:	16                   	push   ss
    600c:	57                   	push   di
    600d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6011:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6016:	06                   	push   es
    6017:	57                   	push   di
    6018:	26 c4 3d             	les    di,DWORD PTR es:[di]
    601b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    601f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6024:	8d be 00 ff          	lea    di,[bp-0x100]
    6028:	16                   	push   ss
    6029:	57                   	push   di
    602a:	68 ff 00             	push   0xff
    602d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6030:	26 ff b5 ae 04       	push   WORD PTR es:[di+0x4ae]
    6035:	26 ff b5 ac 04       	push   WORD PTR es:[di+0x4ac]
    603a:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    603e:	55                   	push   bp
    603f:	9a 8b 52 62 60       	call   0x6062:0x528b
    6044:	8d be 00 ff          	lea    di,[bp-0x100]
    6048:	16                   	push   ss
    6049:	57                   	push   di
    604a:	68 ff 00             	push   0xff
    604d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6050:	26 ff b5 4e 05       	push   WORD PTR es:[di+0x54e]
    6055:	26 ff b5 4c 05       	push   WORD PTR es:[di+0x54c]
    605a:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    605e:	55                   	push   bp
    605f:	9a 8b 52 a6 60       	call   0x60a6:0x528b
    6064:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6069:	76 18                	jbe    0x6083
    606b:	8d be 00 ff          	lea    di,[bp-0x100]
    606f:	16                   	push   ss
    6070:	57                   	push   di
    6071:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6075:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    607a:	06                   	push   es
    607b:	57                   	push   di
    607c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    607f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6083:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6088:	8d be 00 ff          	lea    di,[bp-0x100]
    608c:	16                   	push   ss
    608d:	57                   	push   di
    608e:	68 ff 00             	push   0xff
    6091:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6094:	26 ff b5 b2 04       	push   WORD PTR es:[di+0x4b2]
    6099:	26 ff b5 b0 04       	push   WORD PTR es:[di+0x4b0]
    609e:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    60a2:	55                   	push   bp
    60a3:	9a 8b 52 c6 60       	call   0x60c6:0x528b
    60a8:	8d be 00 ff          	lea    di,[bp-0x100]
    60ac:	16                   	push   ss
    60ad:	57                   	push   di
    60ae:	68 ff 00             	push   0xff
    60b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60b4:	26 ff b5 52 05       	push   WORD PTR es:[di+0x552]
    60b9:	26 ff b5 50 05       	push   WORD PTR es:[di+0x550]
    60be:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    60c2:	55                   	push   bp
    60c3:	9a 8b 52 0a 61       	call   0x610a:0x528b
    60c8:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    60cd:	76 18                	jbe    0x60e7
    60cf:	8d be 00 ff          	lea    di,[bp-0x100]
    60d3:	16                   	push   ss
    60d4:	57                   	push   di
    60d5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    60d9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    60de:	06                   	push   es
    60df:	57                   	push   di
    60e0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    60e3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    60e7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    60ec:	8d be 00 ff          	lea    di,[bp-0x100]
    60f0:	16                   	push   ss
    60f1:	57                   	push   di
    60f2:	68 ff 00             	push   0xff
    60f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    60f8:	26 ff b5 b6 04       	push   WORD PTR es:[di+0x4b6]
    60fd:	26 ff b5 b4 04       	push   WORD PTR es:[di+0x4b4]
    6102:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    6106:	55                   	push   bp
    6107:	9a 8b 52 2a 61       	call   0x612a:0x528b
    610c:	8d be 00 ff          	lea    di,[bp-0x100]
    6110:	16                   	push   ss
    6111:	57                   	push   di
    6112:	68 ff 00             	push   0xff
    6115:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6118:	26 ff b5 56 05       	push   WORD PTR es:[di+0x556]
    611d:	26 ff b5 54 05       	push   WORD PTR es:[di+0x554]
    6122:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    6126:	55                   	push   bp
    6127:	9a 8b 52 6e 61       	call   0x616e:0x528b
    612c:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6131:	76 18                	jbe    0x614b
    6133:	8d be 00 ff          	lea    di,[bp-0x100]
    6137:	16                   	push   ss
    6138:	57                   	push   di
    6139:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    613d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6142:	06                   	push   es
    6143:	57                   	push   di
    6144:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6147:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    614b:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6150:	8d be 00 ff          	lea    di,[bp-0x100]
    6154:	16                   	push   ss
    6155:	57                   	push   di
    6156:	68 ff 00             	push   0xff
    6159:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    615c:	26 ff b5 ba 04       	push   WORD PTR es:[di+0x4ba]
    6161:	26 ff b5 b8 04       	push   WORD PTR es:[di+0x4b8]
    6166:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    616a:	55                   	push   bp
    616b:	9a 8b 52 8e 61       	call   0x618e:0x528b
    6170:	8d be 00 ff          	lea    di,[bp-0x100]
    6174:	16                   	push   ss
    6175:	57                   	push   di
    6176:	68 ff 00             	push   0xff
    6179:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    617c:	26 ff b5 5a 05       	push   WORD PTR es:[di+0x55a]
    6181:	26 ff b5 58 05       	push   WORD PTR es:[di+0x558]
    6186:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    618a:	55                   	push   bp
    618b:	9a 8b 52 ef 61       	call   0x61ef:0x528b
    6190:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6195:	76 18                	jbe    0x61af
    6197:	8d be 00 ff          	lea    di,[bp-0x100]
    619b:	16                   	push   ss
    619c:	57                   	push   di
    619d:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    61a1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    61a6:	06                   	push   es
    61a7:	57                   	push   di
    61a8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    61ab:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    61af:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    61b3:	75 17                	jne    0x61cc
    61b5:	bf 85 55             	mov    di,0x5585
    61b8:	0e                   	push   cs
    61b9:	57                   	push   di
    61ba:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    61be:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    61c3:	06                   	push   es
    61c4:	57                   	push   di
    61c5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    61c8:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    61cc:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    61d1:	8d be 00 ff          	lea    di,[bp-0x100]
    61d5:	16                   	push   ss
    61d6:	57                   	push   di
    61d7:	68 ff 00             	push   0xff
    61da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    61dd:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    61e2:	26 ff b5 0c 04       	push   WORD PTR es:[di+0x40c]
    61e7:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    61eb:	55                   	push   bp
    61ec:	9a 8b 52 38 62       	call   0x6238:0x528b
    61f1:	8d be fc fd          	lea    di,[bp-0x204]
    61f5:	16                   	push   ss
    61f6:	57                   	push   di
    61f7:	8d be 00 ff          	lea    di,[bp-0x100]
    61fb:	16                   	push   ss
    61fc:	57                   	push   di
    61fd:	9a cd 17 0a 62       	call   0x620a:0x17cd
    6202:	bf 83 55             	mov    di,0x5583
    6205:	0e                   	push   cs
    6206:	57                   	push   di
    6207:	9a 4c 18 18 62       	call   0x6218:0x184c
    620c:	8d be 00 ff          	lea    di,[bp-0x100]
    6210:	16                   	push   ss
    6211:	57                   	push   di
    6212:	68 ff 00             	push   0xff
    6215:	9a e7 17 2b 63       	call   0x632b:0x17e7
    621a:	8d be 00 ff          	lea    di,[bp-0x100]
    621e:	16                   	push   ss
    621f:	57                   	push   di
    6220:	68 ff 00             	push   0xff
    6223:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6226:	26 ff b5 2a 04       	push   WORD PTR es:[di+0x42a]
    622b:	26 ff b5 28 04       	push   WORD PTR es:[di+0x428]
    6230:	ff 36 e2 01          	push   WORD PTR ds:0x1e2
    6234:	55                   	push   bp
    6235:	9a 8b 52 99 62       	call   0x6299:0x528b
    623a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    623f:	76 18                	jbe    0x6259
    6241:	8d be 00 ff          	lea    di,[bp-0x100]
    6245:	16                   	push   ss
    6246:	57                   	push   di
    6247:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    624b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6250:	06                   	push   es
    6251:	57                   	push   di
    6252:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6255:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6259:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    625d:	75 17                	jne    0x6276
    625f:	bf 85 55             	mov    di,0x5585
    6262:	0e                   	push   cs
    6263:	57                   	push   di
    6264:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6268:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    626d:	06                   	push   es
    626e:	57                   	push   di
    626f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6272:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6276:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    627b:	8d be 00 ff          	lea    di,[bp-0x100]
    627f:	16                   	push   ss
    6280:	57                   	push   di
    6281:	68 ff 00             	push   0xff
    6284:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6287:	26 ff b5 12 04       	push   WORD PTR es:[di+0x412]
    628c:	26 ff b5 10 04       	push   WORD PTR es:[di+0x410]
    6291:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    6295:	55                   	push   bp
    6296:	9a 8b 52 b9 62       	call   0x62b9:0x528b
    629b:	8d be 00 ff          	lea    di,[bp-0x100]
    629f:	16                   	push   ss
    62a0:	57                   	push   di
    62a1:	68 ff 00             	push   0xff
    62a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    62a7:	26 ff b5 5e 05       	push   WORD PTR es:[di+0x55e]
    62ac:	26 ff b5 5c 05       	push   WORD PTR es:[di+0x55c]
    62b1:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    62b5:	55                   	push   bp
    62b6:	9a 8b 52 1a 63       	call   0x631a:0x528b
    62bb:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    62c0:	76 18                	jbe    0x62da
    62c2:	8d be 00 ff          	lea    di,[bp-0x100]
    62c6:	16                   	push   ss
    62c7:	57                   	push   di
    62c8:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    62cc:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    62d1:	06                   	push   es
    62d2:	57                   	push   di
    62d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    62d6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    62da:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    62de:	75 17                	jne    0x62f7
    62e0:	bf 85 55             	mov    di,0x5585
    62e3:	0e                   	push   cs
    62e4:	57                   	push   di
    62e5:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    62e9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    62ee:	06                   	push   es
    62ef:	57                   	push   di
    62f0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    62f3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    62f7:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    62fc:	8d be 00 ff          	lea    di,[bp-0x100]
    6300:	16                   	push   ss
    6301:	57                   	push   di
    6302:	68 ff 00             	push   0xff
    6305:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6308:	26 ff b5 16 04       	push   WORD PTR es:[di+0x416]
    630d:	26 ff b5 14 04       	push   WORD PTR es:[di+0x414]
    6312:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    6316:	55                   	push   bp
    6317:	9a 8b 52 63 63       	call   0x6363:0x528b
    631c:	8d be fc fd          	lea    di,[bp-0x204]
    6320:	16                   	push   ss
    6321:	57                   	push   di
    6322:	8d be 00 ff          	lea    di,[bp-0x100]
    6326:	16                   	push   ss
    6327:	57                   	push   di
    6328:	9a cd 17 35 63       	call   0x6335:0x17cd
    632d:	bf 83 55             	mov    di,0x5583
    6330:	0e                   	push   cs
    6331:	57                   	push   di
    6332:	9a 4c 18 43 63       	call   0x6343:0x184c
    6337:	8d be 00 ff          	lea    di,[bp-0x100]
    633b:	16                   	push   ss
    633c:	57                   	push   di
    633d:	68 ff 00             	push   0xff
    6340:	9a e7 17 ba 64       	call   0x64ba:0x17e7
    6345:	8d be 00 ff          	lea    di,[bp-0x100]
    6349:	16                   	push   ss
    634a:	57                   	push   di
    634b:	68 ff 00             	push   0xff
    634e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6351:	26 ff b5 2e 04       	push   WORD PTR es:[di+0x42e]
    6356:	26 ff b5 2c 04       	push   WORD PTR es:[di+0x42c]
    635b:	ff 36 e2 01          	push   WORD PTR ds:0x1e2
    635f:	55                   	push   bp
    6360:	9a 8b 52 c4 63       	call   0x63c4:0x528b
    6365:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    636a:	76 18                	jbe    0x6384
    636c:	8d be 00 ff          	lea    di,[bp-0x100]
    6370:	16                   	push   ss
    6371:	57                   	push   di
    6372:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6376:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    637b:	06                   	push   es
    637c:	57                   	push   di
    637d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6380:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6384:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    6388:	75 17                	jne    0x63a1
    638a:	bf 85 55             	mov    di,0x5585
    638d:	0e                   	push   cs
    638e:	57                   	push   di
    638f:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6393:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6398:	06                   	push   es
    6399:	57                   	push   di
    639a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    639d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    63a1:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    63a6:	8d be 00 ff          	lea    di,[bp-0x100]
    63aa:	16                   	push   ss
    63ab:	57                   	push   di
    63ac:	68 ff 00             	push   0xff
    63af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63b2:	26 ff b5 c2 04       	push   WORD PTR es:[di+0x4c2]
    63b7:	26 ff b5 c0 04       	push   WORD PTR es:[di+0x4c0]
    63bc:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    63c0:	55                   	push   bp
    63c1:	9a 8b 52 e4 63       	call   0x63e4:0x528b
    63c6:	8d be 00 ff          	lea    di,[bp-0x100]
    63ca:	16                   	push   ss
    63cb:	57                   	push   di
    63cc:	68 ff 00             	push   0xff
    63cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    63d2:	26 ff b5 62 05       	push   WORD PTR es:[di+0x562]
    63d7:	26 ff b5 60 05       	push   WORD PTR es:[di+0x560]
    63dc:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    63e0:	55                   	push   bp
    63e1:	9a 8b 52 28 64       	call   0x6428:0x528b
    63e6:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    63eb:	76 18                	jbe    0x6405
    63ed:	8d be 00 ff          	lea    di,[bp-0x100]
    63f1:	16                   	push   ss
    63f2:	57                   	push   di
    63f3:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    63f7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    63fc:	06                   	push   es
    63fd:	57                   	push   di
    63fe:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6401:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6405:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    640a:	8d be 00 ff          	lea    di,[bp-0x100]
    640e:	16                   	push   ss
    640f:	57                   	push   di
    6410:	68 ff 00             	push   0xff
    6413:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6416:	26 ff b5 c6 04       	push   WORD PTR es:[di+0x4c6]
    641b:	26 ff b5 c4 04       	push   WORD PTR es:[di+0x4c4]
    6420:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    6424:	55                   	push   bp
    6425:	9a 8b 52 48 64       	call   0x6448:0x528b
    642a:	8d be 00 ff          	lea    di,[bp-0x100]
    642e:	16                   	push   ss
    642f:	57                   	push   di
    6430:	68 ff 00             	push   0xff
    6433:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6436:	26 ff b5 66 05       	push   WORD PTR es:[di+0x566]
    643b:	26 ff b5 64 05       	push   WORD PTR es:[di+0x564]
    6440:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    6444:	55                   	push   bp
    6445:	9a 8b 52 a9 64       	call   0x64a9:0x528b
    644a:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    644f:	76 18                	jbe    0x6469
    6451:	8d be 00 ff          	lea    di,[bp-0x100]
    6455:	16                   	push   ss
    6456:	57                   	push   di
    6457:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    645b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6460:	06                   	push   es
    6461:	57                   	push   di
    6462:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6465:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6469:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    646d:	75 17                	jne    0x6486
    646f:	bf 85 55             	mov    di,0x5585
    6472:	0e                   	push   cs
    6473:	57                   	push   di
    6474:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6478:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    647d:	06                   	push   es
    647e:	57                   	push   di
    647f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6482:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6486:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    648b:	8d be 00 ff          	lea    di,[bp-0x100]
    648f:	16                   	push   ss
    6490:	57                   	push   di
    6491:	68 ff 00             	push   0xff
    6494:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6497:	26 ff b5 1a 04       	push   WORD PTR es:[di+0x41a]
    649c:	26 ff b5 18 04       	push   WORD PTR es:[di+0x418]
    64a1:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    64a5:	55                   	push   bp
    64a6:	9a 8b 52 f2 64       	call   0x64f2:0x528b
    64ab:	8d be fc fd          	lea    di,[bp-0x204]
    64af:	16                   	push   ss
    64b0:	57                   	push   di
    64b1:	8d be 00 ff          	lea    di,[bp-0x100]
    64b5:	16                   	push   ss
    64b6:	57                   	push   di
    64b7:	9a cd 17 c4 64       	call   0x64c4:0x17cd
    64bc:	bf 83 55             	mov    di,0x5583
    64bf:	0e                   	push   cs
    64c0:	57                   	push   di
    64c1:	9a 4c 18 d2 64       	call   0x64d2:0x184c
    64c6:	8d be 00 ff          	lea    di,[bp-0x100]
    64ca:	16                   	push   ss
    64cb:	57                   	push   di
    64cc:	68 ff 00             	push   0xff
    64cf:	9a e7 17 11 67       	call   0x6711:0x17e7
    64d4:	8d be 00 ff          	lea    di,[bp-0x100]
    64d8:	16                   	push   ss
    64d9:	57                   	push   di
    64da:	68 ff 00             	push   0xff
    64dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    64e0:	26 ff b5 32 04       	push   WORD PTR es:[di+0x432]
    64e5:	26 ff b5 30 04       	push   WORD PTR es:[di+0x430]
    64ea:	ff 36 e2 01          	push   WORD PTR ds:0x1e2
    64ee:	55                   	push   bp
    64ef:	9a 8b 52 53 65       	call   0x6553:0x528b
    64f4:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    64f9:	76 18                	jbe    0x6513
    64fb:	8d be 00 ff          	lea    di,[bp-0x100]
    64ff:	16                   	push   ss
    6500:	57                   	push   di
    6501:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6505:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    650a:	06                   	push   es
    650b:	57                   	push   di
    650c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    650f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6513:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    6517:	75 17                	jne    0x6530
    6519:	bf 85 55             	mov    di,0x5585
    651c:	0e                   	push   cs
    651d:	57                   	push   di
    651e:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6522:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6527:	06                   	push   es
    6528:	57                   	push   di
    6529:	26 c4 3d             	les    di,DWORD PTR es:[di]
    652c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6530:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6535:	8d be 00 ff          	lea    di,[bp-0x100]
    6539:	16                   	push   ss
    653a:	57                   	push   di
    653b:	68 ff 00             	push   0xff
    653e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6541:	26 ff b5 ce 04       	push   WORD PTR es:[di+0x4ce]
    6546:	26 ff b5 cc 04       	push   WORD PTR es:[di+0x4cc]
    654b:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    654f:	55                   	push   bp
    6550:	9a 8b 52 73 65       	call   0x6573:0x528b
    6555:	8d be 00 ff          	lea    di,[bp-0x100]
    6559:	16                   	push   ss
    655a:	57                   	push   di
    655b:	68 ff 00             	push   0xff
    655e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6561:	26 ff b5 6a 05       	push   WORD PTR es:[di+0x56a]
    6566:	26 ff b5 68 05       	push   WORD PTR es:[di+0x568]
    656b:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    656f:	55                   	push   bp
    6570:	9a 8b 52 b7 65       	call   0x65b7:0x528b
    6575:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    657a:	76 18                	jbe    0x6594
    657c:	8d be 00 ff          	lea    di,[bp-0x100]
    6580:	16                   	push   ss
    6581:	57                   	push   di
    6582:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    6586:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    658b:	06                   	push   es
    658c:	57                   	push   di
    658d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6590:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    6594:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6599:	8d be 00 ff          	lea    di,[bp-0x100]
    659d:	16                   	push   ss
    659e:	57                   	push   di
    659f:	68 ff 00             	push   0xff
    65a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65a5:	26 ff b5 d2 04       	push   WORD PTR es:[di+0x4d2]
    65aa:	26 ff b5 d0 04       	push   WORD PTR es:[di+0x4d0]
    65af:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    65b3:	55                   	push   bp
    65b4:	9a 8b 52 d7 65       	call   0x65d7:0x528b
    65b9:	8d be 00 ff          	lea    di,[bp-0x100]
    65bd:	16                   	push   ss
    65be:	57                   	push   di
    65bf:	68 ff 00             	push   0xff
    65c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    65c5:	26 ff b5 6e 05       	push   WORD PTR es:[di+0x56e]
    65ca:	26 ff b5 6c 05       	push   WORD PTR es:[di+0x56c]
    65cf:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    65d3:	55                   	push   bp
    65d4:	9a 8b 52 1b 66       	call   0x661b:0x528b
    65d9:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    65de:	76 18                	jbe    0x65f8
    65e0:	8d be 00 ff          	lea    di,[bp-0x100]
    65e4:	16                   	push   ss
    65e5:	57                   	push   di
    65e6:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    65ea:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    65ef:	06                   	push   es
    65f0:	57                   	push   di
    65f1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    65f4:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    65f8:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    65fd:	8d be 00 ff          	lea    di,[bp-0x100]
    6601:	16                   	push   ss
    6602:	57                   	push   di
    6603:	68 ff 00             	push   0xff
    6606:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6609:	26 ff b5 d6 04       	push   WORD PTR es:[di+0x4d6]
    660e:	26 ff b5 d4 04       	push   WORD PTR es:[di+0x4d4]
    6613:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    6617:	55                   	push   bp
    6618:	9a 8b 52 3b 66       	call   0x663b:0x528b
    661d:	8d be 00 ff          	lea    di,[bp-0x100]
    6621:	16                   	push   ss
    6622:	57                   	push   di
    6623:	68 ff 00             	push   0xff
    6626:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6629:	26 ff b5 72 05       	push   WORD PTR es:[di+0x572]
    662e:	26 ff b5 70 05       	push   WORD PTR es:[di+0x570]
    6633:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    6637:	55                   	push   bp
    6638:	9a 8b 52 7f 66       	call   0x667f:0x528b
    663d:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6642:	76 18                	jbe    0x665c
    6644:	8d be 00 ff          	lea    di,[bp-0x100]
    6648:	16                   	push   ss
    6649:	57                   	push   di
    664a:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    664e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6653:	06                   	push   es
    6654:	57                   	push   di
    6655:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6658:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    665c:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    6661:	8d be 00 ff          	lea    di,[bp-0x100]
    6665:	16                   	push   ss
    6666:	57                   	push   di
    6667:	68 ff 00             	push   0xff
    666a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    666d:	26 ff b5 da 04       	push   WORD PTR es:[di+0x4da]
    6672:	26 ff b5 d8 04       	push   WORD PTR es:[di+0x4d8]
    6677:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    667b:	55                   	push   bp
    667c:	9a 8b 52 9f 66       	call   0x669f:0x528b
    6681:	8d be 00 ff          	lea    di,[bp-0x100]
    6685:	16                   	push   ss
    6686:	57                   	push   di
    6687:	68 ff 00             	push   0xff
    668a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    668d:	26 ff b5 76 05       	push   WORD PTR es:[di+0x576]
    6692:	26 ff b5 74 05       	push   WORD PTR es:[di+0x574]
    6697:	ff 36 e0 01          	push   WORD PTR ds:0x1e0
    669b:	55                   	push   bp
    669c:	9a 8b 52 00 67       	call   0x6700:0x528b
    66a1:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    66a6:	76 18                	jbe    0x66c0
    66a8:	8d be 00 ff          	lea    di,[bp-0x100]
    66ac:	16                   	push   ss
    66ad:	57                   	push   di
    66ae:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    66b2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    66b7:	06                   	push   es
    66b8:	57                   	push   di
    66b9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    66bc:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    66c0:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    66c4:	75 17                	jne    0x66dd
    66c6:	bf 85 55             	mov    di,0x5585
    66c9:	0e                   	push   cs
    66ca:	57                   	push   di
    66cb:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    66cf:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    66d4:	06                   	push   es
    66d5:	57                   	push   di
    66d6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    66d9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    66dd:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    66e2:	8d be 00 ff          	lea    di,[bp-0x100]
    66e6:	16                   	push   ss
    66e7:	57                   	push   di
    66e8:	68 ff 00             	push   0xff
    66eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    66ee:	26 ff b5 42 04       	push   WORD PTR es:[di+0x442]
    66f3:	26 ff b5 40 04       	push   WORD PTR es:[di+0x440]
    66f8:	ff 36 dc 01          	push   WORD PTR ds:0x1dc
    66fc:	55                   	push   bp
    66fd:	9a 8b 52 49 67       	call   0x6749:0x528b
    6702:	8d be fc fd          	lea    di,[bp-0x204]
    6706:	16                   	push   ss
    6707:	57                   	push   di
    6708:	8d be 00 ff          	lea    di,[bp-0x100]
    670c:	16                   	push   ss
    670d:	57                   	push   di
    670e:	9a cd 17 1b 67       	call   0x671b:0x17cd
    6713:	bf 83 55             	mov    di,0x5583
    6716:	0e                   	push   cs
    6717:	57                   	push   di
    6718:	9a 4c 18 29 67       	call   0x6729:0x184c
    671d:	8d be 00 ff          	lea    di,[bp-0x100]
    6721:	16                   	push   ss
    6722:	57                   	push   di
    6723:	68 ff 00             	push   0xff
    6726:	9a e7 17 76 67       	call   0x6776:0x17e7
    672b:	8d be 00 ff          	lea    di,[bp-0x100]
    672f:	16                   	push   ss
    6730:	57                   	push   di
    6731:	68 ff 00             	push   0xff
    6734:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6737:	26 ff b5 46 04       	push   WORD PTR es:[di+0x446]
    673c:	26 ff b5 44 04       	push   WORD PTR es:[di+0x444]
    6741:	ff 36 e2 01          	push   WORD PTR ds:0x1e2
    6745:	55                   	push   bp
    6746:	9a 8b 52 ff ff       	call   0xffff:0x528b
    674b:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    6750:	76 18                	jbe    0x676a
    6752:	8d be 00 ff          	lea    di,[bp-0x100]
    6756:	16                   	push   ss
    6757:	57                   	push   di
    6758:	c4 be fc fe          	les    di,DWORD PTR [bp-0x104]
    675c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    6761:	06                   	push   es
    6762:	57                   	push   di
    6763:	26 c4 3d             	les    di,DWORD PTR es:[di]
    6766:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    676a:	c9                   	leave
    676b:	ca 06 00             	retf   0x6
    676e:	55                   	push   bp
    676f:	89 e5                	mov    bp,sp
    6771:	31 c0                	xor    ax,ax
    6773:	9a 44 04 a4 67       	call   0x67a4:0x444
    6778:	c7 06 44 01 15 00    	mov    WORD PTR ds:0x144,0x15
    677e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6781:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    6786:	a3 46 01             	mov    ds:0x146,ax
    6789:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    678e:	a3 48 01             	mov    ds:0x148,ax
    6791:	06                   	push   es
    6792:	57                   	push   di
    6793:	9a 56 55 c4 67       	call   0x67c4:0x5556
    6798:	c9                   	leave
    6799:	ca 08 00             	retf   0x8
    679c:	55                   	push   bp
    679d:	89 e5                	mov    bp,sp
    679f:	31 c0                	xor    ax,ax
    67a1:	9a 44 04 d2 67       	call   0x67d2:0x444
    67a6:	c7 06 44 01 16 00    	mov    WORD PTR ds:0x144,0x16
    67ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67af:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    67b4:	a3 46 01             	mov    ds:0x146,ax
    67b7:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    67bc:	a3 48 01             	mov    ds:0x148,ax
    67bf:	06                   	push   es
    67c0:	57                   	push   di
    67c1:	9a 56 55 f2 67       	call   0x67f2:0x5556
    67c6:	c9                   	leave
    67c7:	ca 08 00             	retf   0x8
    67ca:	55                   	push   bp
    67cb:	89 e5                	mov    bp,sp
    67cd:	31 c0                	xor    ax,ax
    67cf:	9a 44 04 00 68       	call   0x6800:0x444
    67d4:	c7 06 44 01 17 00    	mov    WORD PTR ds:0x144,0x17
    67da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    67dd:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    67e2:	a3 46 01             	mov    ds:0x146,ax
    67e5:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    67ea:	a3 48 01             	mov    ds:0x148,ax
    67ed:	06                   	push   es
    67ee:	57                   	push   di
    67ef:	9a 56 55 20 68       	call   0x6820:0x5556
    67f4:	c9                   	leave
    67f5:	ca 08 00             	retf   0x8
    67f8:	55                   	push   bp
    67f9:	89 e5                	mov    bp,sp
    67fb:	31 c0                	xor    ax,ax
    67fd:	9a 44 04 2e 68       	call   0x682e:0x444
    6802:	c7 06 44 01 18 00    	mov    WORD PTR ds:0x144,0x18
    6808:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    680b:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    6810:	a3 46 01             	mov    ds:0x146,ax
    6813:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    6818:	a3 48 01             	mov    ds:0x148,ax
    681b:	06                   	push   es
    681c:	57                   	push   di
    681d:	9a 56 55 4e 68       	call   0x684e:0x5556
    6822:	c9                   	leave
    6823:	ca 08 00             	retf   0x8
    6826:	55                   	push   bp
    6827:	89 e5                	mov    bp,sp
    6829:	31 c0                	xor    ax,ax
    682b:	9a 44 04 5c 68       	call   0x685c:0x444
    6830:	c7 06 44 01 19 00    	mov    WORD PTR ds:0x144,0x19
    6836:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6839:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    683e:	a3 46 01             	mov    ds:0x146,ax
    6841:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    6846:	a3 48 01             	mov    ds:0x148,ax
    6849:	06                   	push   es
    684a:	57                   	push   di
    684b:	9a 56 55 7c 68       	call   0x687c:0x5556
    6850:	c9                   	leave
    6851:	ca 08 00             	retf   0x8
    6854:	55                   	push   bp
    6855:	89 e5                	mov    bp,sp
    6857:	31 c0                	xor    ax,ax
    6859:	9a 44 04 8a 68       	call   0x688a:0x444
    685e:	c7 06 44 01 1a 00    	mov    WORD PTR ds:0x144,0x1a
    6864:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6867:	26 8b 85 94 05       	mov    ax,WORD PTR es:[di+0x594]
    686c:	a3 46 01             	mov    ds:0x146,ax
    686f:	26 8b 85 92 05       	mov    ax,WORD PTR es:[di+0x592]
    6874:	a3 48 01             	mov    ds:0x148,ax
    6877:	06                   	push   es
    6878:	57                   	push   di
    6879:	9a 56 55 ff ff       	call   0xffff:0x5556
    687e:	c9                   	leave
    687f:	ca 08 00             	retf   0x8
    6882:	55                   	push   bp
    6883:	89 e5                	mov    bp,sp
    6885:	31 c0                	xor    ax,ax
    6887:	9a 44 04 ff ff       	call   0xffff:0x444
    688c:	ff 36 50 01          	push   WORD PTR ds:0x150
    6890:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    6893:	26 ff b5 92 05       	push   WORD PTR es:[di+0x592]
    6898:	26 ff b5 94 05       	push   WORD PTR es:[di+0x594]
    689d:	9a a1 0c ff ff       	call   0xffff:0xca1
    68a2:	c9                   	leave
    68a3:	ca                   	.byte 0xca
    68a4:	08                   	.byte 0x8
