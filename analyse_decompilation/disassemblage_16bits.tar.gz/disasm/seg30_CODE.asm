; ================================================================
; seg30_CODE  (12925 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	1e                   	push   ds
       1:	00 c8                	add    al,cl
       3:	02 00                	add    al,BYTE PTR [bx+si]
       5:	00 6a 77             	add    BYTE PTR [bp+si+0x77],ch
       8:	ff 76 08             	push   WORD PTR [bp+0x8]
       b:	ff 76 06             	push   WORD PTR [bp+0x6]
       e:	9a 7f 30 49 00       	call   0x49:0x307f
      13:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
      16:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
      19:	c9                   	leave
      1a:	ca 04 00             	retf   0x4
      1d:	00 00                	add    BYTE PTR [bx+si],al
      1f:	4a                   	dec    dx
      20:	02 10                	add    dl,BYTE PTR [bx+si]
      22:	00 06 00 0e          	add    BYTE PTR ds:0xe00,al
      26:	00 69 64             	add    BYTE PTR [bx+di+0x64],ch
      29:	61                   	popa
      2a:	70 69                	jo     0x95
      2c:	30 31                	xor    BYTE PTR [bx+di],dh
      2e:	2e 44                	cs inc sp
      30:	4c                   	dec    sp
      31:	4c                   	dec    sp
	...
      46:	00 4d 00             	add    BYTE PTR [di+0x0],cl
      49:	56                   	push   si
      4a:	00 00                	add    BYTE PTR [bx+si],al
      4c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
      50:	b8 00 00             	mov    ax,0x0
      53:	ea ed 24 66 00       	jmp    0x66:0x24ed
      58:	00 00                	add    BYTE PTR [bx+si],al
      5a:	00 04                	add    BYTE PTR [si],al
      5c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
      60:	b8 01 00             	mov    ax,0x1
      63:	ea ed 24 76 00       	jmp    0x76:0x24ed
      68:	00 00                	add    BYTE PTR [bx+si],al
      6a:	00 05                	add    BYTE PTR [di],al
      6c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
      70:	b8 02 00             	mov    ax,0x2
      73:	ea ed 24 86 00       	jmp    0x86:0x24ed
      78:	00 00                	add    BYTE PTR [bx+si],al
      7a:	00 06 00 ba          	add    BYTE PTR ds:0xba00,al
      7e:	1d 00 b8             	sbb    ax,0xb800
      81:	03 00                	add    ax,WORD PTR [bx+si]
      83:	ea ed 24 96 00       	jmp    0x96:0x24ed
      88:	00 00                	add    BYTE PTR [bx+si],al
      8a:	00 07                	add    BYTE PTR [bx],al
      8c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
      90:	b8 04 00             	mov    ax,0x4
      93:	ea ed 24 a6 00       	jmp    0xa6:0x24ed
      98:	00 00                	add    BYTE PTR [bx+si],al
      9a:	00 08                	add    BYTE PTR [bx+si],cl
      9c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
      a0:	b8 05 00             	mov    ax,0x5
      a3:	ea ed 24 b6 00       	jmp    0xb6:0x24ed
      a8:	00 00                	add    BYTE PTR [bx+si],al
      aa:	00 09                	add    BYTE PTR [bx+di],cl
      ac:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
      b0:	b8 06 00             	mov    ax,0x6
      b3:	ea ed 24 c6 00       	jmp    0xc6:0x24ed
      b8:	00 00                	add    BYTE PTR [bx+si],al
      ba:	00 0c                	add    BYTE PTR [si],cl
      bc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
      c0:	b8 07 00             	mov    ax,0x7
      c3:	ea ed 24 d6 00       	jmp    0xd6:0x24ed
      c8:	00 00                	add    BYTE PTR [bx+si],al
      ca:	00 0d                	add    BYTE PTR [di],cl
      cc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
      d0:	b8 08 00             	mov    ax,0x8
      d3:	ea ed 24 e6 00       	jmp    0xe6:0x24ed
      d8:	00 00                	add    BYTE PTR [bx+si],al
      da:	00 0e 00 ba          	add    BYTE PTR ds:0xba00,cl
      de:	1d 00 b8             	sbb    ax,0xb800
      e1:	09 00                	or     WORD PTR [bx+si],ax
      e3:	ea ed 24 f6 00       	jmp    0xf6:0x24ed
      e8:	00 00                	add    BYTE PTR [bx+si],al
      ea:	00 0f                	add    BYTE PTR [bx],cl
      ec:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
      f0:	b8 0a 00             	mov    ax,0xa
      f3:	ea ed 24 06 01       	jmp    0x106:0x24ed
      f8:	00 00                	add    BYTE PTR [bx+si],al
      fa:	00 10                	add    BYTE PTR [bx+si],dl
      fc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     100:	b8 0b 00             	mov    ax,0xb
     103:	ea ed 24 16 01       	jmp    0x116:0x24ed
     108:	00 00                	add    BYTE PTR [bx+si],al
     10a:	00 11                	add    BYTE PTR [bx+di],dl
     10c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     110:	b8 0c 00             	mov    ax,0xc
     113:	ea ed 24 26 01       	jmp    0x126:0x24ed
     118:	00 00                	add    BYTE PTR [bx+si],al
     11a:	00 12                	add    BYTE PTR [bp+si],dl
     11c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     120:	b8 0d 00             	mov    ax,0xd
     123:	ea ed 24 36 01       	jmp    0x136:0x24ed
     128:	00 00                	add    BYTE PTR [bx+si],al
     12a:	00 13                	add    BYTE PTR [bp+di],dl
     12c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     130:	b8 0e 00             	mov    ax,0xe
     133:	ea ed 24 46 01       	jmp    0x146:0x24ed
     138:	00 00                	add    BYTE PTR [bx+si],al
     13a:	00 15                	add    BYTE PTR [di],dl
     13c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     140:	b8 0f 00             	mov    ax,0xf
     143:	ea ed 24 56 01       	jmp    0x156:0x24ed
     148:	00 00                	add    BYTE PTR [bx+si],al
     14a:	00 16 00 ba          	add    BYTE PTR ds:0xba00,dl
     14e:	1d 00 b8             	sbb    ax,0xb800
     151:	10 00                	adc    BYTE PTR [bx+si],al
     153:	ea ed 24 66 01       	jmp    0x166:0x24ed
     158:	00 00                	add    BYTE PTR [bx+si],al
     15a:	00 17                	add    BYTE PTR [bx],dl
     15c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     160:	b8 11 00             	mov    ax,0x11
     163:	ea ed 24 76 01       	jmp    0x176:0x24ed
     168:	00 00                	add    BYTE PTR [bx+si],al
     16a:	00 18                	add    BYTE PTR [bx+si],bl
     16c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     170:	b8 12 00             	mov    ax,0x12
     173:	ea ed 24 86 01       	jmp    0x186:0x24ed
     178:	00 00                	add    BYTE PTR [bx+si],al
     17a:	00 19                	add    BYTE PTR [bx+di],bl
     17c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     180:	b8 13 00             	mov    ax,0x13
     183:	ea ed 24 96 01       	jmp    0x196:0x24ed
     188:	00 00                	add    BYTE PTR [bx+si],al
     18a:	00 1c                	add    BYTE PTR [si],bl
     18c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     190:	b8 14 00             	mov    ax,0x14
     193:	ea ed 24 a6 01       	jmp    0x1a6:0x24ed
     198:	00 00                	add    BYTE PTR [bx+si],al
     19a:	00 1d                	add    BYTE PTR [di],bl
     19c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     1a0:	b8 15 00             	mov    ax,0x15
     1a3:	ea ed 24 b6 01       	jmp    0x1b6:0x24ed
     1a8:	00 00                	add    BYTE PTR [bx+si],al
     1aa:	00 1e 00 ba          	add    BYTE PTR ds:0xba00,bl
     1ae:	1d 00 b8             	sbb    ax,0xb800
     1b1:	16                   	push   ss
     1b2:	00 ea                	add    dl,ch
     1b4:	ed                   	in     ax,dx
     1b5:	24 c6                	and    al,0xc6
     1b7:	01 00                	add    WORD PTR [bx+si],ax
     1b9:	00 00                	add    BYTE PTR [bx+si],al
     1bb:	1f                   	pop    ds
     1bc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     1c0:	b8 17 00             	mov    ax,0x17
     1c3:	ea ed 24 d6 01       	jmp    0x1d6:0x24ed
     1c8:	00 00                	add    BYTE PTR [bx+si],al
     1ca:	00 20                	add    BYTE PTR [bx+si],ah
     1cc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     1d0:	b8 18 00             	mov    ax,0x18
     1d3:	ea ed 24 e6 01       	jmp    0x1e6:0x24ed
     1d8:	00 00                	add    BYTE PTR [bx+si],al
     1da:	00 21                	add    BYTE PTR [bx+di],ah
     1dc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     1e0:	b8 19 00             	mov    ax,0x19
     1e3:	ea ed 24 f6 01       	jmp    0x1f6:0x24ed
     1e8:	00 00                	add    BYTE PTR [bx+si],al
     1ea:	00 22                	add    BYTE PTR [bp+si],ah
     1ec:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     1f0:	b8 1a 00             	mov    ax,0x1a
     1f3:	ea ed 24 06 02       	jmp    0x206:0x24ed
     1f8:	00 00                	add    BYTE PTR [bx+si],al
     1fa:	00 23                	add    BYTE PTR [bp+di],ah
     1fc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     200:	b8 1b 00             	mov    ax,0x1b
     203:	ea ed 24 16 02       	jmp    0x216:0x24ed
     208:	00 00                	add    BYTE PTR [bx+si],al
     20a:	00 24                	add    BYTE PTR [si],ah
     20c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     210:	b8 1c 00             	mov    ax,0x1c
     213:	ea ed 24 26 02       	jmp    0x226:0x24ed
     218:	00 00                	add    BYTE PTR [bx+si],al
     21a:	00 25                	add    BYTE PTR [di],ah
     21c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     220:	b8 1d 00             	mov    ax,0x1d
     223:	ea ed 24 36 02       	jmp    0x236:0x24ed
     228:	00 00                	add    BYTE PTR [bx+si],al
     22a:	00 26 00 ba          	add    BYTE PTR ds:0xba00,ah
     22e:	1d 00 b8             	sbb    ax,0xb800
     231:	1e                   	push   ds
     232:	00 ea                	add    dl,ch
     234:	ed                   	in     ax,dx
     235:	24 46                	and    al,0x46
     237:	02 00                	add    al,BYTE PTR [bx+si]
     239:	00 00                	add    BYTE PTR [bx+si],al
     23b:	27                   	daa
     23c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     240:	b8 1f 00             	mov    ax,0x1f
     243:	ea ed 24 56 02       	jmp    0x256:0x24ed
     248:	00 00                	add    BYTE PTR [bx+si],al
     24a:	00 28                	add    BYTE PTR [bx+si],ch
     24c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     250:	b8 20 00             	mov    ax,0x20
     253:	ea ed 24 66 02       	jmp    0x266:0x24ed
     258:	00 00                	add    BYTE PTR [bx+si],al
     25a:	00 29                	add    BYTE PTR [bx+di],ch
     25c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     260:	b8 21 00             	mov    ax,0x21
     263:	ea ed 24 76 02       	jmp    0x276:0x24ed
     268:	00 00                	add    BYTE PTR [bx+si],al
     26a:	00 2a                	add    BYTE PTR [bp+si],ch
     26c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     270:	b8 22 00             	mov    ax,0x22
     273:	ea ed 24 86 02       	jmp    0x286:0x24ed
     278:	00 00                	add    BYTE PTR [bx+si],al
     27a:	00 2d                	add    BYTE PTR [di],ch
     27c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     280:	b8 23 00             	mov    ax,0x23
     283:	ea ed 24 96 02       	jmp    0x296:0x24ed
     288:	00 00                	add    BYTE PTR [bx+si],al
     28a:	00 2e 00 ba          	add    BYTE PTR ds:0xba00,ch
     28e:	1d 00 b8             	sbb    ax,0xb800
     291:	24 00                	and    al,0x0
     293:	ea ed 24 a6 02       	jmp    0x2a6:0x24ed
     298:	00 00                	add    BYTE PTR [bx+si],al
     29a:	00 2f                	add    BYTE PTR [bx],ch
     29c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     2a0:	b8 25 00             	mov    ax,0x25
     2a3:	ea ed 24 b6 02       	jmp    0x2b6:0x24ed
     2a8:	00 00                	add    BYTE PTR [bx+si],al
     2aa:	00 30                	add    BYTE PTR [bx+si],dh
     2ac:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     2b0:	b8 26 00             	mov    ax,0x26
     2b3:	ea ed 24 c6 02       	jmp    0x2c6:0x24ed
     2b8:	00 00                	add    BYTE PTR [bx+si],al
     2ba:	00 31                	add    BYTE PTR [bx+di],dh
     2bc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     2c0:	b8 27 00             	mov    ax,0x27
     2c3:	ea ed 24 d6 02       	jmp    0x2d6:0x24ed
     2c8:	00 00                	add    BYTE PTR [bx+si],al
     2ca:	00 32                	add    BYTE PTR [bp+si],dh
     2cc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     2d0:	b8 28 00             	mov    ax,0x28
     2d3:	ea ed 24 e6 02       	jmp    0x2e6:0x24ed
     2d8:	00 00                	add    BYTE PTR [bx+si],al
     2da:	00 33                	add    BYTE PTR [bp+di],dh
     2dc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     2e0:	b8 29 00             	mov    ax,0x29
     2e3:	ea ed 24 f6 02       	jmp    0x2f6:0x24ed
     2e8:	00 00                	add    BYTE PTR [bx+si],al
     2ea:	00 34                	add    BYTE PTR [si],dh
     2ec:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     2f0:	b8 2a 00             	mov    ax,0x2a
     2f3:	ea ed 24 06 03       	jmp    0x306:0x24ed
     2f8:	00 00                	add    BYTE PTR [bx+si],al
     2fa:	00 35                	add    BYTE PTR [di],dh
     2fc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     300:	b8 2b 00             	mov    ax,0x2b
     303:	ea ed 24 16 03       	jmp    0x316:0x24ed
     308:	00 00                	add    BYTE PTR [bx+si],al
     30a:	00 36 00 ba          	add    BYTE PTR ds:0xba00,dh
     30e:	1d 00 b8             	sbb    ax,0xb800
     311:	2c 00                	sub    al,0x0
     313:	ea ed 24 26 03       	jmp    0x326:0x24ed
     318:	00 00                	add    BYTE PTR [bx+si],al
     31a:	00 37                	add    BYTE PTR [bx],dh
     31c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     320:	b8 2d 00             	mov    ax,0x2d
     323:	ea ed 24 36 03       	jmp    0x336:0x24ed
     328:	00 00                	add    BYTE PTR [bx+si],al
     32a:	00 38                	add    BYTE PTR [bx+si],bh
     32c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     330:	b8 2e 00             	mov    ax,0x2e
     333:	ea ed 24 46 03       	jmp    0x346:0x24ed
     338:	00 00                	add    BYTE PTR [bx+si],al
     33a:	00 39                	add    BYTE PTR [bx+di],bh
     33c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     340:	b8 2f 00             	mov    ax,0x2f
     343:	ea ed 24 56 03       	jmp    0x356:0x24ed
     348:	00 00                	add    BYTE PTR [bx+si],al
     34a:	00 3a                	add    BYTE PTR [bp+si],bh
     34c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     350:	b8 30 00             	mov    ax,0x30
     353:	ea ed 24 66 03       	jmp    0x366:0x24ed
     358:	00 00                	add    BYTE PTR [bx+si],al
     35a:	00 3b                	add    BYTE PTR [bp+di],bh
     35c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     360:	b8 31 00             	mov    ax,0x31
     363:	ea ed 24 76 03       	jmp    0x376:0x24ed
     368:	00 00                	add    BYTE PTR [bx+si],al
     36a:	00 3c                	add    BYTE PTR [si],bh
     36c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     370:	b8 32 00             	mov    ax,0x32
     373:	ea ed 24 86 03       	jmp    0x386:0x24ed
     378:	00 00                	add    BYTE PTR [bx+si],al
     37a:	00 3d                	add    BYTE PTR [di],bh
     37c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     380:	b8 33 00             	mov    ax,0x33
     383:	ea ed 24 96 03       	jmp    0x396:0x24ed
     388:	00 00                	add    BYTE PTR [bx+si],al
     38a:	00 3e 00 ba          	add    BYTE PTR ds:0xba00,bh
     38e:	1d 00 b8             	sbb    ax,0xb800
     391:	34 00                	xor    al,0x0
     393:	ea ed 24 a6 03       	jmp    0x3a6:0x24ed
     398:	00 00                	add    BYTE PTR [bx+si],al
     39a:	00 3f                	add    BYTE PTR [bx],bh
     39c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     3a0:	b8 35 00             	mov    ax,0x35
     3a3:	ea ed 24 b6 03       	jmp    0x3b6:0x24ed
     3a8:	00 00                	add    BYTE PTR [bx+si],al
     3aa:	00 40 00             	add    BYTE PTR [bx+si+0x0],al
     3ad:	ba 1d 00             	mov    dx,0x1d
     3b0:	b8 36 00             	mov    ax,0x36
     3b3:	ea ed 24 c6 03       	jmp    0x3c6:0x24ed
     3b8:	00 00                	add    BYTE PTR [bx+si],al
     3ba:	00 41 00             	add    BYTE PTR [bx+di+0x0],al
     3bd:	ba 1d 00             	mov    dx,0x1d
     3c0:	b8 37 00             	mov    ax,0x37
     3c3:	ea ed 24 d6 03       	jmp    0x3d6:0x24ed
     3c8:	00 00                	add    BYTE PTR [bx+si],al
     3ca:	00 42 00             	add    BYTE PTR [bp+si+0x0],al
     3cd:	ba 1d 00             	mov    dx,0x1d
     3d0:	b8 38 00             	mov    ax,0x38
     3d3:	ea ed 24 e6 03       	jmp    0x3e6:0x24ed
     3d8:	00 00                	add    BYTE PTR [bx+si],al
     3da:	00 43 00             	add    BYTE PTR [bp+di+0x0],al
     3dd:	ba 1d 00             	mov    dx,0x1d
     3e0:	b8 39 00             	mov    ax,0x39
     3e3:	ea ed 24 f6 03       	jmp    0x3f6:0x24ed
     3e8:	00 00                	add    BYTE PTR [bx+si],al
     3ea:	00 44 00             	add    BYTE PTR [si+0x0],al
     3ed:	ba 1d 00             	mov    dx,0x1d
     3f0:	b8 3a 00             	mov    ax,0x3a
     3f3:	ea ed 24 06 04       	jmp    0x406:0x24ed
     3f8:	00 00                	add    BYTE PTR [bx+si],al
     3fa:	00 46 00             	add    BYTE PTR [bp+0x0],al
     3fd:	ba 1d 00             	mov    dx,0x1d
     400:	b8 3b 00             	mov    ax,0x3b
     403:	ea ed 24 16 04       	jmp    0x416:0x24ed
     408:	00 00                	add    BYTE PTR [bx+si],al
     40a:	00 47 00             	add    BYTE PTR [bx+0x0],al
     40d:	ba 1d 00             	mov    dx,0x1d
     410:	b8 3c 00             	mov    ax,0x3c
     413:	ea ed 24 26 04       	jmp    0x426:0x24ed
     418:	00 00                	add    BYTE PTR [bx+si],al
     41a:	00 48 00             	add    BYTE PTR [bx+si+0x0],cl
     41d:	ba 1d 00             	mov    dx,0x1d
     420:	b8 3d 00             	mov    ax,0x3d
     423:	ea ed 24 36 04       	jmp    0x436:0x24ed
     428:	00 00                	add    BYTE PTR [bx+si],al
     42a:	00 49 00             	add    BYTE PTR [bx+di+0x0],cl
     42d:	ba 1d 00             	mov    dx,0x1d
     430:	b8 3e 00             	mov    ax,0x3e
     433:	ea ed 24 46 04       	jmp    0x446:0x24ed
     438:	00 00                	add    BYTE PTR [bx+si],al
     43a:	00 4a 00             	add    BYTE PTR [bp+si+0x0],cl
     43d:	ba 1d 00             	mov    dx,0x1d
     440:	b8 3f 00             	mov    ax,0x3f
     443:	ea ed 24 56 04       	jmp    0x456:0x24ed
     448:	00 00                	add    BYTE PTR [bx+si],al
     44a:	00 4b 00             	add    BYTE PTR [bp+di+0x0],cl
     44d:	ba 1d 00             	mov    dx,0x1d
     450:	b8 40 00             	mov    ax,0x40
     453:	ea ed 24 66 04       	jmp    0x466:0x24ed
     458:	00 00                	add    BYTE PTR [bx+si],al
     45a:	00 4c 00             	add    BYTE PTR [si+0x0],cl
     45d:	ba 1d 00             	mov    dx,0x1d
     460:	b8 41 00             	mov    ax,0x41
     463:	ea ed 24 76 04       	jmp    0x476:0x24ed
     468:	00 00                	add    BYTE PTR [bx+si],al
     46a:	00 4d 00             	add    BYTE PTR [di+0x0],cl
     46d:	ba 1d 00             	mov    dx,0x1d
     470:	b8 42 00             	mov    ax,0x42
     473:	ea ed 24 86 04       	jmp    0x486:0x24ed
     478:	00 00                	add    BYTE PTR [bx+si],al
     47a:	00 4e 00             	add    BYTE PTR [bp+0x0],cl
     47d:	ba 1d 00             	mov    dx,0x1d
     480:	b8 43 00             	mov    ax,0x43
     483:	ea ed 24 96 04       	jmp    0x496:0x24ed
     488:	00 00                	add    BYTE PTR [bx+si],al
     48a:	00 4f 00             	add    BYTE PTR [bx+0x0],cl
     48d:	ba 1d 00             	mov    dx,0x1d
     490:	b8 44 00             	mov    ax,0x44
     493:	ea ed 24 a6 04       	jmp    0x4a6:0x24ed
     498:	00 00                	add    BYTE PTR [bx+si],al
     49a:	00 50 00             	add    BYTE PTR [bx+si+0x0],dl
     49d:	ba 1d 00             	mov    dx,0x1d
     4a0:	b8 45 00             	mov    ax,0x45
     4a3:	ea ed 24 b6 04       	jmp    0x4b6:0x24ed
     4a8:	00 00                	add    BYTE PTR [bx+si],al
     4aa:	00 51 00             	add    BYTE PTR [bx+di+0x0],dl
     4ad:	ba 1d 00             	mov    dx,0x1d
     4b0:	b8 46 00             	mov    ax,0x46
     4b3:	ea ed 24 c6 04       	jmp    0x4c6:0x24ed
     4b8:	00 00                	add    BYTE PTR [bx+si],al
     4ba:	00 52 00             	add    BYTE PTR [bp+si+0x0],dl
     4bd:	ba 1d 00             	mov    dx,0x1d
     4c0:	b8 47 00             	mov    ax,0x47
     4c3:	ea ed 24 d6 04       	jmp    0x4d6:0x24ed
     4c8:	00 00                	add    BYTE PTR [bx+si],al
     4ca:	00 53 00             	add    BYTE PTR [bp+di+0x0],dl
     4cd:	ba 1d 00             	mov    dx,0x1d
     4d0:	b8 48 00             	mov    ax,0x48
     4d3:	ea ed 24 e6 04       	jmp    0x4e6:0x24ed
     4d8:	00 00                	add    BYTE PTR [bx+si],al
     4da:	00 54 00             	add    BYTE PTR [si+0x0],dl
     4dd:	ba 1d 00             	mov    dx,0x1d
     4e0:	b8 49 00             	mov    ax,0x49
     4e3:	ea ed 24 f6 04       	jmp    0x4f6:0x24ed
     4e8:	00 00                	add    BYTE PTR [bx+si],al
     4ea:	00 55 00             	add    BYTE PTR [di+0x0],dl
     4ed:	ba 1d 00             	mov    dx,0x1d
     4f0:	b8 4a 00             	mov    ax,0x4a
     4f3:	ea ed 24 06 05       	jmp    0x506:0x24ed
     4f8:	00 00                	add    BYTE PTR [bx+si],al
     4fa:	00 56 00             	add    BYTE PTR [bp+0x0],dl
     4fd:	ba 1d 00             	mov    dx,0x1d
     500:	b8 4b 00             	mov    ax,0x4b
     503:	ea ed 24 16 05       	jmp    0x516:0x24ed
     508:	00 00                	add    BYTE PTR [bx+si],al
     50a:	00 57 00             	add    BYTE PTR [bx+0x0],dl
     50d:	ba 1d 00             	mov    dx,0x1d
     510:	b8 4c 00             	mov    ax,0x4c
     513:	ea ed 24 26 05       	jmp    0x526:0x24ed
     518:	00 00                	add    BYTE PTR [bx+si],al
     51a:	00 58 00             	add    BYTE PTR [bx+si+0x0],bl
     51d:	ba 1d 00             	mov    dx,0x1d
     520:	b8 4d 00             	mov    ax,0x4d
     523:	ea ed 24 36 05       	jmp    0x536:0x24ed
     528:	00 00                	add    BYTE PTR [bx+si],al
     52a:	00 59 00             	add    BYTE PTR [bx+di+0x0],bl
     52d:	ba 1d 00             	mov    dx,0x1d
     530:	b8 4e 00             	mov    ax,0x4e
     533:	ea ed 24 46 05       	jmp    0x546:0x24ed
     538:	00 00                	add    BYTE PTR [bx+si],al
     53a:	00 5a 00             	add    BYTE PTR [bp+si+0x0],bl
     53d:	ba 1d 00             	mov    dx,0x1d
     540:	b8 4f 00             	mov    ax,0x4f
     543:	ea ed 24 56 05       	jmp    0x556:0x24ed
     548:	00 00                	add    BYTE PTR [bx+si],al
     54a:	00 5b 00             	add    BYTE PTR [bp+di+0x0],bl
     54d:	ba 1d 00             	mov    dx,0x1d
     550:	b8 50 00             	mov    ax,0x50
     553:	ea ed 24 66 05       	jmp    0x566:0x24ed
     558:	00 00                	add    BYTE PTR [bx+si],al
     55a:	00 5c 00             	add    BYTE PTR [si+0x0],bl
     55d:	ba 1d 00             	mov    dx,0x1d
     560:	b8 51 00             	mov    ax,0x51
     563:	ea ed 24 76 05       	jmp    0x576:0x24ed
     568:	00 00                	add    BYTE PTR [bx+si],al
     56a:	00 5d 00             	add    BYTE PTR [di+0x0],bl
     56d:	ba 1d 00             	mov    dx,0x1d
     570:	b8 52 00             	mov    ax,0x52
     573:	ea ed 24 86 05       	jmp    0x586:0x24ed
     578:	00 00                	add    BYTE PTR [bx+si],al
     57a:	00 64 00             	add    BYTE PTR [si+0x0],ah
     57d:	ba 1d 00             	mov    dx,0x1d
     580:	b8 53 00             	mov    ax,0x53
     583:	ea ed 24 96 05       	jmp    0x596:0x24ed
     588:	00 00                	add    BYTE PTR [bx+si],al
     58a:	00 65 00             	add    BYTE PTR [di+0x0],ah
     58d:	ba 1d 00             	mov    dx,0x1d
     590:	b8 54 00             	mov    ax,0x54
     593:	ea ed 24 a6 05       	jmp    0x5a6:0x24ed
     598:	00 00                	add    BYTE PTR [bx+si],al
     59a:	00 66 00             	add    BYTE PTR [bp+0x0],ah
     59d:	ba 1d 00             	mov    dx,0x1d
     5a0:	b8 55 00             	mov    ax,0x55
     5a3:	ea ed 24 b6 05       	jmp    0x5b6:0x24ed
     5a8:	00 00                	add    BYTE PTR [bx+si],al
     5aa:	00 67 00             	add    BYTE PTR [bx+0x0],ah
     5ad:	ba 1d 00             	mov    dx,0x1d
     5b0:	b8 56 00             	mov    ax,0x56
     5b3:	ea ed 24 c6 05       	jmp    0x5c6:0x24ed
     5b8:	00 00                	add    BYTE PTR [bx+si],al
     5ba:	00 68 00             	add    BYTE PTR [bx+si+0x0],ch
     5bd:	ba 1d 00             	mov    dx,0x1d
     5c0:	b8 57 00             	mov    ax,0x57
     5c3:	ea ed 24 d6 05       	jmp    0x5d6:0x24ed
     5c8:	00 00                	add    BYTE PTR [bx+si],al
     5ca:	00 69 00             	add    BYTE PTR [bx+di+0x0],ch
     5cd:	ba 1d 00             	mov    dx,0x1d
     5d0:	b8 58 00             	mov    ax,0x58
     5d3:	ea ed 24 e6 05       	jmp    0x5e6:0x24ed
     5d8:	00 00                	add    BYTE PTR [bx+si],al
     5da:	00 6a 00             	add    BYTE PTR [bp+si+0x0],ch
     5dd:	ba 1d 00             	mov    dx,0x1d
     5e0:	b8 59 00             	mov    ax,0x59
     5e3:	ea ed 24 f6 05       	jmp    0x5f6:0x24ed
     5e8:	00 00                	add    BYTE PTR [bx+si],al
     5ea:	00 77 00             	add    BYTE PTR [bx+0x0],dh
     5ed:	ba 1d 00             	mov    dx,0x1d
     5f0:	b8 5a 00             	mov    ax,0x5a
     5f3:	ea ed 24 06 06       	jmp    0x606:0x24ed
     5f8:	00 00                	add    BYTE PTR [bx+si],al
     5fa:	00 78 00             	add    BYTE PTR [bx+si+0x0],bh
     5fd:	ba 1d 00             	mov    dx,0x1d
     600:	b8 5b 00             	mov    ax,0x5b
     603:	ea ed 24 16 06       	jmp    0x616:0x24ed
     608:	00 00                	add    BYTE PTR [bx+si],al
     60a:	00 79 00             	add    BYTE PTR [bx+di+0x0],bh
     60d:	ba 1d 00             	mov    dx,0x1d
     610:	b8 5c 00             	mov    ax,0x5c
     613:	ea ed 24 26 06       	jmp    0x626:0x24ed
     618:	00 00                	add    BYTE PTR [bx+si],al
     61a:	00 7a 00             	add    BYTE PTR [bp+si+0x0],bh
     61d:	ba 1d 00             	mov    dx,0x1d
     620:	b8 5d 00             	mov    ax,0x5d
     623:	ea ed 24 36 06       	jmp    0x636:0x24ed
     628:	00 00                	add    BYTE PTR [bx+si],al
     62a:	00 7b 00             	add    BYTE PTR [bp+di+0x0],bh
     62d:	ba 1d 00             	mov    dx,0x1d
     630:	b8 5e 00             	mov    ax,0x5e
     633:	ea ed 24 46 06       	jmp    0x646:0x24ed
     638:	00 00                	add    BYTE PTR [bx+si],al
     63a:	00 7d 00             	add    BYTE PTR [di+0x0],bh
     63d:	ba 1d 00             	mov    dx,0x1d
     640:	b8 5f 00             	mov    ax,0x5f
     643:	ea ed 24 56 06       	jmp    0x656:0x24ed
     648:	00 00                	add    BYTE PTR [bx+si],al
     64a:	00 7e 00             	add    BYTE PTR [bp+0x0],bh
     64d:	ba 1d 00             	mov    dx,0x1d
     650:	b8 60 00             	mov    ax,0x60
     653:	ea ed 24 66 06       	jmp    0x666:0x24ed
     658:	00 00                	add    BYTE PTR [bx+si],al
     65a:	00 7f 00             	add    BYTE PTR [bx+0x0],bh
     65d:	ba 1d 00             	mov    dx,0x1d
     660:	b8 61 00             	mov    ax,0x61
     663:	ea ed 24 76 06       	jmp    0x676:0x24ed
     668:	00 00                	add    BYTE PTR [bx+si],al
     66a:	00 80 00 ba          	add    BYTE PTR [bx+si-0x4600],al
     66e:	1d 00 b8             	sbb    ax,0xb800
     671:	62 00                	bound  ax,DWORD PTR [bx+si]
     673:	ea ed 24 86 06       	jmp    0x686:0x24ed
     678:	00 00                	add    BYTE PTR [bx+si],al
     67a:	00 81 00 ba          	add    BYTE PTR [bx+di-0x4600],al
     67e:	1d 00 b8             	sbb    ax,0xb800
     681:	63 00                	arpl   WORD PTR [bx+si],ax
     683:	ea ed 24 96 06       	jmp    0x696:0x24ed
     688:	00 00                	add    BYTE PTR [bx+si],al
     68a:	00 82 00 ba          	add    BYTE PTR [bp+si-0x4600],al
     68e:	1d 00 b8             	sbb    ax,0xb800
     691:	64 00 ea             	fs add dl,ch
     694:	ed                   	in     ax,dx
     695:	24 a6                	and    al,0xa6
     697:	06                   	push   es
     698:	00 00                	add    BYTE PTR [bx+si],al
     69a:	00 83 00 ba          	add    BYTE PTR [bp+di-0x4600],al
     69e:	1d 00 b8             	sbb    ax,0xb800
     6a1:	65 00 ea             	gs add dl,ch
     6a4:	ed                   	in     ax,dx
     6a5:	24 b6                	and    al,0xb6
     6a7:	06                   	push   es
     6a8:	00 00                	add    BYTE PTR [bx+si],al
     6aa:	00 84 00 ba          	add    BYTE PTR [si-0x4600],al
     6ae:	1d 00 b8             	sbb    ax,0xb800
     6b1:	66 00 ea             	data32 add dl,ch
     6b4:	ed                   	in     ax,dx
     6b5:	24 c6                	and    al,0xc6
     6b7:	06                   	push   es
     6b8:	00 00                	add    BYTE PTR [bx+si],al
     6ba:	00 85 00 ba          	add    BYTE PTR [di-0x4600],al
     6be:	1d 00 b8             	sbb    ax,0xb800
     6c1:	67 00 ea             	addr32 add dl,ch
     6c4:	ed                   	in     ax,dx
     6c5:	24 d6                	and    al,0xd6
     6c7:	06                   	push   es
     6c8:	00 00                	add    BYTE PTR [bx+si],al
     6ca:	00 86 00 ba          	add    BYTE PTR [bp-0x4600],al
     6ce:	1d 00 b8             	sbb    ax,0xb800
     6d1:	68 00 ea             	push   0xea00
     6d4:	ed                   	in     ax,dx
     6d5:	24 e6                	and    al,0xe6
     6d7:	06                   	push   es
     6d8:	00 00                	add    BYTE PTR [bx+si],al
     6da:	00 88 00 ba          	add    BYTE PTR [bx+si-0x4600],cl
     6de:	1d 00 b8             	sbb    ax,0xb800
     6e1:	69 00 ea ed          	imul   ax,WORD PTR [bx+si],0xedea
     6e5:	24 f6                	and    al,0xf6
     6e7:	06                   	push   es
     6e8:	00 00                	add    BYTE PTR [bx+si],al
     6ea:	00 ce                	add    dh,cl
     6ec:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     6f0:	b8 6a 00             	mov    ax,0x6a
     6f3:	ea ed 24 06 07       	jmp    0x706:0x24ed
     6f8:	00 00                	add    BYTE PTR [bx+si],al
     6fa:	00 cf                	add    bh,cl
     6fc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     700:	b8 6b 00             	mov    ax,0x6b
     703:	ea ed 24 16 07       	jmp    0x716:0x24ed
     708:	00 00                	add    BYTE PTR [bx+si],al
     70a:	00 d0                	add    al,dl
     70c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     710:	b8 6c 00             	mov    ax,0x6c
     713:	ea ed 24 26 07       	jmp    0x726:0x24ed
     718:	00 00                	add    BYTE PTR [bx+si],al
     71a:	00 d1                	add    cl,dl
     71c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     720:	b8 6d 00             	mov    ax,0x6d
     723:	ea ed 24 36 07       	jmp    0x736:0x24ed
     728:	00 00                	add    BYTE PTR [bx+si],al
     72a:	00 d2                	add    dl,dl
     72c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     730:	b8 6e 00             	mov    ax,0x6e
     733:	ea ed 24 46 07       	jmp    0x746:0x24ed
     738:	00 00                	add    BYTE PTR [bx+si],al
     73a:	00 d3                	add    bl,dl
     73c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     740:	b8 6f 00             	mov    ax,0x6f
     743:	ea ed 24 56 07       	jmp    0x756:0x24ed
     748:	00 00                	add    BYTE PTR [bx+si],al
     74a:	00 d4                	add    ah,dl
     74c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     750:	b8 70 00             	mov    ax,0x70
     753:	ea ed 24 66 07       	jmp    0x766:0x24ed
     758:	00 00                	add    BYTE PTR [bx+si],al
     75a:	00 d5                	add    ch,dl
     75c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     760:	b8 71 00             	mov    ax,0x71
     763:	ea ed 24 76 07       	jmp    0x776:0x24ed
     768:	00 00                	add    BYTE PTR [bx+si],al
     76a:	00 d6                	add    dh,dl
     76c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     770:	b8 72 00             	mov    ax,0x72
     773:	ea ed 24 86 07       	jmp    0x786:0x24ed
     778:	00 00                	add    BYTE PTR [bx+si],al
     77a:	00 d7                	add    bh,dl
     77c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     780:	b8 73 00             	mov    ax,0x73
     783:	ea ed 24 96 07       	jmp    0x796:0x24ed
     788:	00 00                	add    BYTE PTR [bx+si],al
     78a:	00 d8                	add    al,bl
     78c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     790:	b8 74 00             	mov    ax,0x74
     793:	ea ed 24 a6 07       	jmp    0x7a6:0x24ed
     798:	00 00                	add    BYTE PTR [bx+si],al
     79a:	00 d9                	add    cl,bl
     79c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     7a0:	b8 75 00             	mov    ax,0x75
     7a3:	ea ed 24 b6 07       	jmp    0x7b6:0x24ed
     7a8:	00 00                	add    BYTE PTR [bx+si],al
     7aa:	00 da                	add    dl,bl
     7ac:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     7b0:	b8 76 00             	mov    ax,0x76
     7b3:	ea ed 24 c6 07       	jmp    0x7c6:0x24ed
     7b8:	00 00                	add    BYTE PTR [bx+si],al
     7ba:	00 db                	add    bl,bl
     7bc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     7c0:	b8 77 00             	mov    ax,0x77
     7c3:	ea ed 24 d6 07       	jmp    0x7d6:0x24ed
     7c8:	00 00                	add    BYTE PTR [bx+si],al
     7ca:	00 dc                	add    ah,bl
     7cc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     7d0:	b8 78 00             	mov    ax,0x78
     7d3:	ea ed 24 e6 07       	jmp    0x7e6:0x24ed
     7d8:	00 00                	add    BYTE PTR [bx+si],al
     7da:	00 dd                	add    ch,bl
     7dc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     7e0:	b8 79 00             	mov    ax,0x79
     7e3:	ea ed 24 f6 07       	jmp    0x7f6:0x24ed
     7e8:	00 00                	add    BYTE PTR [bx+si],al
     7ea:	00 de                	add    dh,bl
     7ec:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     7f0:	b8 7a 00             	mov    ax,0x7a
     7f3:	ea ed 24 06 08       	jmp    0x806:0x24ed
     7f8:	00 00                	add    BYTE PTR [bx+si],al
     7fa:	00 df                	add    bh,bl
     7fc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     800:	b8 7b 00             	mov    ax,0x7b
     803:	ea ed 24 16 08       	jmp    0x816:0x24ed
     808:	00 00                	add    BYTE PTR [bx+si],al
     80a:	00 e0                	add    al,ah
     80c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     810:	b8 7c 00             	mov    ax,0x7c
     813:	ea ed 24 26 08       	jmp    0x826:0x24ed
     818:	00 00                	add    BYTE PTR [bx+si],al
     81a:	00 e6                	add    dh,ah
     81c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     820:	b8 7d 00             	mov    ax,0x7d
     823:	ea ed 24 36 08       	jmp    0x836:0x24ed
     828:	00 00                	add    BYTE PTR [bx+si],al
     82a:	00 e8                	add    al,ch
     82c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     830:	b8 7e 00             	mov    ax,0x7e
     833:	ea ed 24 46 08       	jmp    0x846:0x24ed
     838:	00 00                	add    BYTE PTR [bx+si],al
     83a:	00 e9                	add    cl,ch
     83c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     840:	b8 7f 00             	mov    ax,0x7f
     843:	ea ed 24 56 08       	jmp    0x856:0x24ed
     848:	00 00                	add    BYTE PTR [bx+si],al
     84a:	00 ea                	add    dl,ch
     84c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     850:	b8 80 00             	mov    ax,0x80
     853:	ea ed 24 66 08       	jmp    0x866:0x24ed
     858:	00 00                	add    BYTE PTR [bx+si],al
     85a:	00 eb                	add    bl,ch
     85c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     860:	b8 81 00             	mov    ax,0x81
     863:	ea ed 24 76 08       	jmp    0x876:0x24ed
     868:	00 00                	add    BYTE PTR [bx+si],al
     86a:	00 ec                	add    ah,ch
     86c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     870:	b8 82 00             	mov    ax,0x82
     873:	ea ed 24 86 08       	jmp    0x886:0x24ed
     878:	00 00                	add    BYTE PTR [bx+si],al
     87a:	00 ed                	add    ch,ch
     87c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     880:	b8 83 00             	mov    ax,0x83
     883:	ea ed 24 96 08       	jmp    0x896:0x24ed
     888:	00 00                	add    BYTE PTR [bx+si],al
     88a:	00 ee                	add    dh,ch
     88c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     890:	b8 84 00             	mov    ax,0x84
     893:	ea ed 24 a6 08       	jmp    0x8a6:0x24ed
     898:	00 00                	add    BYTE PTR [bx+si],al
     89a:	00 ef                	add    bh,ch
     89c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     8a0:	b8 85 00             	mov    ax,0x85
     8a3:	ea ed 24 b6 08       	jmp    0x8b6:0x24ed
     8a8:	00 00                	add    BYTE PTR [bx+si],al
     8aa:	00 f0                	add    al,dh
     8ac:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     8b0:	b8 86 00             	mov    ax,0x86
     8b3:	ea ed 24 c6 08       	jmp    0x8c6:0x24ed
     8b8:	00 00                	add    BYTE PTR [bx+si],al
     8ba:	00 f2                	add    dl,dh
     8bc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     8c0:	b8 87 00             	mov    ax,0x87
     8c3:	ea ed 24 d6 08       	jmp    0x8d6:0x24ed
     8c8:	00 00                	add    BYTE PTR [bx+si],al
     8ca:	00 f3                	add    bl,dh
     8cc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     8d0:	b8 88 00             	mov    ax,0x88
     8d3:	ea ed 24 e6 08       	jmp    0x8e6:0x24ed
     8d8:	00 00                	add    BYTE PTR [bx+si],al
     8da:	00 f4                	add    ah,dh
     8dc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     8e0:	b8 89 00             	mov    ax,0x89
     8e3:	ea ed 24 f6 08       	jmp    0x8f6:0x24ed
     8e8:	00 00                	add    BYTE PTR [bx+si],al
     8ea:	00 f5                	add    ch,dh
     8ec:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     8f0:	b8 8a 00             	mov    ax,0x8a
     8f3:	ea ed 24 06 09       	jmp    0x906:0x24ed
     8f8:	00 00                	add    BYTE PTR [bx+si],al
     8fa:	00 f6                	add    dh,dh
     8fc:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     900:	b8 8b 00             	mov    ax,0x8b
     903:	ea ed 24 16 09       	jmp    0x916:0x24ed
     908:	00 00                	add    BYTE PTR [bx+si],al
     90a:	00 f7                	add    bh,dh
     90c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     910:	b8 8c 00             	mov    ax,0x8c
     913:	ea ed 24 26 09       	jmp    0x926:0x24ed
     918:	00 00                	add    BYTE PTR [bx+si],al
     91a:	00 f8                	add    al,bh
     91c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     920:	b8 8d 00             	mov    ax,0x8d
     923:	ea ed 24 36 09       	jmp    0x936:0x24ed
     928:	00 00                	add    BYTE PTR [bx+si],al
     92a:	00 f9                	add    cl,bh
     92c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     930:	b8 8e 00             	mov    ax,0x8e
     933:	ea ed 24 46 09       	jmp    0x946:0x24ed
     938:	00 00                	add    BYTE PTR [bx+si],al
     93a:	00 fa                	add    dl,bh
     93c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     940:	b8 8f 00             	mov    ax,0x8f
     943:	ea ed 24 56 09       	jmp    0x956:0x24ed
     948:	00 00                	add    BYTE PTR [bx+si],al
     94a:	00 fc                	add    ah,bh
     94c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     950:	b8 90 00             	mov    ax,0x90
     953:	ea ed 24 66 09       	jmp    0x966:0x24ed
     958:	00 00                	add    BYTE PTR [bx+si],al
     95a:	00 fd                	add    ch,bh
     95c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     960:	b8 91 00             	mov    ax,0x91
     963:	ea ed 24 76 09       	jmp    0x976:0x24ed
     968:	00 00                	add    BYTE PTR [bx+si],al
     96a:	00 fe                	add    dh,bh
     96c:	00 ba 1d 00          	add    BYTE PTR [bp+si+0x1d],bh
     970:	b8 92 00             	mov    ax,0x92
     973:	ea ed 24 86 09       	jmp    0x986:0x24ed
     978:	00 00                	add    BYTE PTR [bx+si],al
     97a:	00 01                	add    BYTE PTR [bx+di],al
     97c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     980:	b8 93 00             	mov    ax,0x93
     983:	ea ed 24 96 09       	jmp    0x996:0x24ed
     988:	00 00                	add    BYTE PTR [bx+si],al
     98a:	00 22                	add    BYTE PTR [bp+si],ah
     98c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     990:	b8 94 00             	mov    ax,0x94
     993:	ea ed 24 a6 09       	jmp    0x9a6:0x24ed
     998:	00 00                	add    BYTE PTR [bx+si],al
     99a:	00 23                	add    BYTE PTR [bp+di],ah
     99c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     9a0:	b8 95 00             	mov    ax,0x95
     9a3:	ea ed 24 b6 09       	jmp    0x9b6:0x24ed
     9a8:	00 00                	add    BYTE PTR [bx+si],al
     9aa:	00 24                	add    BYTE PTR [si],ah
     9ac:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     9b0:	b8 96 00             	mov    ax,0x96
     9b3:	ea ed 24 c6 09       	jmp    0x9c6:0x24ed
     9b8:	00 00                	add    BYTE PTR [bx+si],al
     9ba:	00 25                	add    BYTE PTR [di],ah
     9bc:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     9c0:	b8 97 00             	mov    ax,0x97
     9c3:	ea ed 24 d6 09       	jmp    0x9d6:0x24ed
     9c8:	00 00                	add    BYTE PTR [bx+si],al
     9ca:	00 26 01 ba          	add    BYTE PTR ds:0xba01,ah
     9ce:	1d 00 b8             	sbb    ax,0xb800
     9d1:	98                   	cbw
     9d2:	00 ea                	add    dl,ch
     9d4:	ed                   	in     ax,dx
     9d5:	24 e6                	and    al,0xe6
     9d7:	09 00                	or     WORD PTR [bx+si],ax
     9d9:	00 00                	add    BYTE PTR [bx+si],al
     9db:	27                   	daa
     9dc:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     9e0:	b8 99 00             	mov    ax,0x99
     9e3:	ea ed 24 f6 09       	jmp    0x9f6:0x24ed
     9e8:	00 00                	add    BYTE PTR [bx+si],al
     9ea:	00 28                	add    BYTE PTR [bx+si],ch
     9ec:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     9f0:	b8 9a 00             	mov    ax,0x9a
     9f3:	ea ed 24 06 0a       	jmp    0xa06:0x24ed
     9f8:	00 00                	add    BYTE PTR [bx+si],al
     9fa:	00 29                	add    BYTE PTR [bx+di],ch
     9fc:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     a00:	b8 9b 00             	mov    ax,0x9b
     a03:	ea ed 24 16 0a       	jmp    0xa16:0x24ed
     a08:	00 00                	add    BYTE PTR [bx+si],al
     a0a:	00 2a                	add    BYTE PTR [bp+si],ch
     a0c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     a10:	b8 9c 00             	mov    ax,0x9c
     a13:	ea ed 24 26 0a       	jmp    0xa26:0x24ed
     a18:	00 00                	add    BYTE PTR [bx+si],al
     a1a:	00 2b                	add    BYTE PTR [bp+di],ch
     a1c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     a20:	b8 9d 00             	mov    ax,0x9d
     a23:	ea ed 24 36 0a       	jmp    0xa36:0x24ed
     a28:	00 00                	add    BYTE PTR [bx+si],al
     a2a:	00 2c                	add    BYTE PTR [si],ch
     a2c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     a30:	b8 9e 00             	mov    ax,0x9e
     a33:	ea ed 24 46 0a       	jmp    0xa46:0x24ed
     a38:	00 00                	add    BYTE PTR [bx+si],al
     a3a:	00 4a 01             	add    BYTE PTR [bp+si+0x1],cl
     a3d:	ba 1d 00             	mov    dx,0x1d
     a40:	b8 9f 00             	mov    ax,0x9f
     a43:	ea ed 24 56 0a       	jmp    0xa56:0x24ed
     a48:	00 00                	add    BYTE PTR [bx+si],al
     a4a:	00 4b 01             	add    BYTE PTR [bp+di+0x1],cl
     a4d:	ba 1d 00             	mov    dx,0x1d
     a50:	b8 a0 00             	mov    ax,0xa0
     a53:	ea ed 24 66 0a       	jmp    0xa66:0x24ed
     a58:	00 00                	add    BYTE PTR [bx+si],al
     a5a:	00 4c 01             	add    BYTE PTR [si+0x1],cl
     a5d:	ba 1d 00             	mov    dx,0x1d
     a60:	b8 a1 00             	mov    ax,0xa1
     a63:	ea ed 24 76 0a       	jmp    0xa76:0x24ed
     a68:	00 00                	add    BYTE PTR [bx+si],al
     a6a:	00 4d 01             	add    BYTE PTR [di+0x1],cl
     a6d:	ba 1d 00             	mov    dx,0x1d
     a70:	b8 a2 00             	mov    ax,0xa2
     a73:	ea ed 24 86 0a       	jmp    0xa86:0x24ed
     a78:	00 00                	add    BYTE PTR [bx+si],al
     a7a:	00 50 01             	add    BYTE PTR [bx+si+0x1],dl
     a7d:	ba 1d 00             	mov    dx,0x1d
     a80:	b8 a3 00             	mov    ax,0xa3
     a83:	ea ed 24 96 0a       	jmp    0xa96:0x24ed
     a88:	00 00                	add    BYTE PTR [bx+si],al
     a8a:	00 51 01             	add    BYTE PTR [bx+di+0x1],dl
     a8d:	ba 1d 00             	mov    dx,0x1d
     a90:	b8 a4 00             	mov    ax,0xa4
     a93:	ea ed 24 a6 0a       	jmp    0xaa6:0x24ed
     a98:	00 00                	add    BYTE PTR [bx+si],al
     a9a:	00 52 01             	add    BYTE PTR [bp+si+0x1],dl
     a9d:	ba 1d 00             	mov    dx,0x1d
     aa0:	b8 a5 00             	mov    ax,0xa5
     aa3:	ea ed 24 b6 0a       	jmp    0xab6:0x24ed
     aa8:	00 00                	add    BYTE PTR [bx+si],al
     aaa:	00 53 01             	add    BYTE PTR [bp+di+0x1],dl
     aad:	ba 1d 00             	mov    dx,0x1d
     ab0:	b8 a6 00             	mov    ax,0xa6
     ab3:	ea ed 24 c6 0a       	jmp    0xac6:0x24ed
     ab8:	00 00                	add    BYTE PTR [bx+si],al
     aba:	00 55 01             	add    BYTE PTR [di+0x1],dl
     abd:	ba 1d 00             	mov    dx,0x1d
     ac0:	b8 a7 00             	mov    ax,0xa7
     ac3:	ea ed 24 d6 0a       	jmp    0xad6:0x24ed
     ac8:	00 00                	add    BYTE PTR [bx+si],al
     aca:	00 68 01             	add    BYTE PTR [bx+si+0x1],ch
     acd:	ba 1d 00             	mov    dx,0x1d
     ad0:	b8 a8 00             	mov    ax,0xa8
     ad3:	ea ed 24 e6 0a       	jmp    0xae6:0x24ed
     ad8:	00 00                	add    BYTE PTR [bx+si],al
     ada:	00 6a 01             	add    BYTE PTR [bp+si+0x1],ch
     add:	ba 1d 00             	mov    dx,0x1d
     ae0:	b8 a9 00             	mov    ax,0xa9
     ae3:	ea ed 24 f6 0a       	jmp    0xaf6:0x24ed
     ae8:	00 00                	add    BYTE PTR [bx+si],al
     aea:	00 70 01             	add    BYTE PTR [bx+si+0x1],dh
     aed:	ba 1d 00             	mov    dx,0x1d
     af0:	b8 aa 00             	mov    ax,0xaa
     af3:	ea ed 24 06 0b       	jmp    0xb06:0x24ed
     af8:	00 00                	add    BYTE PTR [bx+si],al
     afa:	00 72 01             	add    BYTE PTR [bp+si+0x1],dh
     afd:	ba 1d 00             	mov    dx,0x1d
     b00:	b8 ab 00             	mov    ax,0xab
     b03:	ea ed 24 16 0b       	jmp    0xb16:0x24ed
     b08:	00 00                	add    BYTE PTR [bx+si],al
     b0a:	00 7c 01             	add    BYTE PTR [si+0x1],bh
     b0d:	ba 1d 00             	mov    dx,0x1d
     b10:	b8 ac 00             	mov    ax,0xac
     b13:	ea ed 24 26 0b       	jmp    0xb26:0x24ed
     b18:	00 00                	add    BYTE PTR [bx+si],al
     b1a:	00 7d 01             	add    BYTE PTR [di+0x1],bh
     b1d:	ba 1d 00             	mov    dx,0x1d
     b20:	b8 ad 00             	mov    ax,0xad
     b23:	ea ed 24 36 0b       	jmp    0xb36:0x24ed
     b28:	00 00                	add    BYTE PTR [bx+si],al
     b2a:	00 7e 01             	add    BYTE PTR [bp+0x1],bh
     b2d:	ba 1d 00             	mov    dx,0x1d
     b30:	b8 ae 00             	mov    ax,0xae
     b33:	ea ed 24 46 0b       	jmp    0xb46:0x24ed
     b38:	00 00                	add    BYTE PTR [bx+si],al
     b3a:	00 7f 01             	add    BYTE PTR [bx+0x1],bh
     b3d:	ba 1d 00             	mov    dx,0x1d
     b40:	b8 af 00             	mov    ax,0xaf
     b43:	ea ed 24 56 0b       	jmp    0xb56:0x24ed
     b48:	00 00                	add    BYTE PTR [bx+si],al
     b4a:	00 80 01 ba          	add    BYTE PTR [bx+si-0x45ff],al
     b4e:	1d 00 b8             	sbb    ax,0xb800
     b51:	b0 00                	mov    al,0x0
     b53:	ea ed 24 66 0b       	jmp    0xb66:0x24ed
     b58:	00 00                	add    BYTE PTR [bx+si],al
     b5a:	00 81 01 ba          	add    BYTE PTR [bx+di-0x45ff],al
     b5e:	1d 00 b8             	sbb    ax,0xb800
     b61:	b1 00                	mov    cl,0x0
     b63:	ea ed 24 76 0b       	jmp    0xb76:0x24ed
     b68:	00 00                	add    BYTE PTR [bx+si],al
     b6a:	00 82 01 ba          	add    BYTE PTR [bp+si-0x45ff],al
     b6e:	1d 00 b8             	sbb    ax,0xb800
     b71:	b2 00                	mov    dl,0x0
     b73:	ea ed 24 86 0b       	jmp    0xb86:0x24ed
     b78:	00 00                	add    BYTE PTR [bx+si],al
     b7a:	00 83 01 ba          	add    BYTE PTR [bp+di-0x45ff],al
     b7e:	1d 00 b8             	sbb    ax,0xb800
     b81:	b3 00                	mov    bl,0x0
     b83:	ea ed 24 96 0b       	jmp    0xb96:0x24ed
     b88:	00 00                	add    BYTE PTR [bx+si],al
     b8a:	00 84 01 ba          	add    BYTE PTR [si-0x45ff],al
     b8e:	1d 00 b8             	sbb    ax,0xb800
     b91:	b4 00                	mov    ah,0x0
     b93:	ea ed 24 a6 0b       	jmp    0xba6:0x24ed
     b98:	00 00                	add    BYTE PTR [bx+si],al
     b9a:	00 85 01 ba          	add    BYTE PTR [di-0x45ff],al
     b9e:	1d 00 b8             	sbb    ax,0xb800
     ba1:	b5 00                	mov    ch,0x0
     ba3:	ea ed 24 b6 0b       	jmp    0xbb6:0x24ed
     ba8:	00 00                	add    BYTE PTR [bx+si],al
     baa:	00 86 01 ba          	add    BYTE PTR [bp-0x45ff],al
     bae:	1d 00 b8             	sbb    ax,0xb800
     bb1:	b6 00                	mov    dh,0x0
     bb3:	ea ed 24 c6 0b       	jmp    0xbc6:0x24ed
     bb8:	00 00                	add    BYTE PTR [bx+si],al
     bba:	00 87 01 ba          	add    BYTE PTR [bx-0x45ff],al
     bbe:	1d 00 b8             	sbb    ax,0xb800
     bc1:	b7 00                	mov    bh,0x0
     bc3:	ea ed 24 d6 0b       	jmp    0xbd6:0x24ed
     bc8:	00 00                	add    BYTE PTR [bx+si],al
     bca:	00 88 01 ba          	add    BYTE PTR [bx+si-0x45ff],cl
     bce:	1d 00 b8             	sbb    ax,0xb800
     bd1:	b8 00 ea             	mov    ax,0xea00
     bd4:	ed                   	in     ax,dx
     bd5:	24 e6                	and    al,0xe6
     bd7:	0b 00                	or     ax,WORD PTR [bx+si]
     bd9:	00 00                	add    BYTE PTR [bx+si],al
     bdb:	90                   	nop
     bdc:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     be0:	b8 b9 00             	mov    ax,0xb9
     be3:	ea ed 24 f6 0b       	jmp    0xbf6:0x24ed
     be8:	00 00                	add    BYTE PTR [bx+si],al
     bea:	00 91 01 ba          	add    BYTE PTR [bx+di-0x45ff],dl
     bee:	1d 00 b8             	sbb    ax,0xb800
     bf1:	ba 00 ea             	mov    dx,0xea00
     bf4:	ed                   	in     ax,dx
     bf5:	24 06                	and    al,0x6
     bf7:	0c 00                	or     al,0x0
     bf9:	00 00                	add    BYTE PTR [bx+si],al
     bfb:	92                   	xchg   dx,ax
     bfc:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     c00:	b8 bb 00             	mov    ax,0xbb
     c03:	ea ed 24 16 0c       	jmp    0xc16:0x24ed
     c08:	00 00                	add    BYTE PTR [bx+si],al
     c0a:	00 93 01 ba          	add    BYTE PTR [bp+di-0x45ff],dl
     c0e:	1d 00 b8             	sbb    ax,0xb800
     c11:	bc 00 ea             	mov    sp,0xea00
     c14:	ed                   	in     ax,dx
     c15:	24 26                	and    al,0x26
     c17:	0c 00                	or     al,0x0
     c19:	00 00                	add    BYTE PTR [bx+si],al
     c1b:	94                   	xchg   sp,ax
     c1c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     c20:	b8 bd 00             	mov    ax,0xbd
     c23:	ea ed 24 36 0c       	jmp    0xc36:0x24ed
     c28:	00 00                	add    BYTE PTR [bx+si],al
     c2a:	00 95 01 ba          	add    BYTE PTR [di-0x45ff],dl
     c2e:	1d 00 b8             	sbb    ax,0xb800
     c31:	be 00 ea             	mov    si,0xea00
     c34:	ed                   	in     ax,dx
     c35:	24 46                	and    al,0x46
     c37:	0c 00                	or     al,0x0
     c39:	00 00                	add    BYTE PTR [bx+si],al
     c3b:	96                   	xchg   si,ax
     c3c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     c40:	b8 bf 00             	mov    ax,0xbf
     c43:	ea ed 24 56 0c       	jmp    0xc56:0x24ed
     c48:	00 00                	add    BYTE PTR [bx+si],al
     c4a:	00 97 01 ba          	add    BYTE PTR [bx-0x45ff],dl
     c4e:	1d 00 b8             	sbb    ax,0xb800
     c51:	c0 00 ea             	rol    BYTE PTR [bx+si],0xea
     c54:	ed                   	in     ax,dx
     c55:	24 66                	and    al,0x66
     c57:	0c 00                	or     al,0x0
     c59:	00 00                	add    BYTE PTR [bx+si],al
     c5b:	98                   	cbw
     c5c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     c60:	b8 c1 00             	mov    ax,0xc1
     c63:	ea ed 24 76 0c       	jmp    0xc76:0x24ed
     c68:	00 00                	add    BYTE PTR [bx+si],al
     c6a:	00 99 01 ba          	add    BYTE PTR [bx+di-0x45ff],bl
     c6e:	1d 00 b8             	sbb    ax,0xb800
     c71:	c2 00 ea             	ret    0xea00
     c74:	ed                   	in     ax,dx
     c75:	24 86                	and    al,0x86
     c77:	0c 00                	or     al,0x0
     c79:	00 00                	add    BYTE PTR [bx+si],al
     c7b:	9a 01 ba 1d 00       	call   0x1d:0xba01
     c80:	b8 c3 00             	mov    ax,0xc3
     c83:	ea ed 24 96 0c       	jmp    0xc96:0x24ed
     c88:	00 00                	add    BYTE PTR [bx+si],al
     c8a:	00 f4                	add    ah,dh
     c8c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     c90:	b8 c4 00             	mov    ax,0xc4
     c93:	ea ed 24 a6 0c       	jmp    0xca6:0x24ed
     c98:	00 00                	add    BYTE PTR [bx+si],al
     c9a:	00 f5                	add    ch,dh
     c9c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     ca0:	b8 c5 00             	mov    ax,0xc5
     ca3:	ea ed 24 b6 0c       	jmp    0xcb6:0x24ed
     ca8:	00 00                	add    BYTE PTR [bx+si],al
     caa:	00 f6                	add    dh,dh
     cac:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     cb0:	b8 c6 00             	mov    ax,0xc6
     cb3:	ea ed 24 c6 0c       	jmp    0xcc6:0x24ed
     cb8:	00 00                	add    BYTE PTR [bx+si],al
     cba:	00 f7                	add    bh,dh
     cbc:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     cc0:	b8 c7 00             	mov    ax,0xc7
     cc3:	ea ed 24 d6 0c       	jmp    0xcd6:0x24ed
     cc8:	00 00                	add    BYTE PTR [bx+si],al
     cca:	00 f8                	add    al,bh
     ccc:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     cd0:	b8 c8 00             	mov    ax,0xc8
     cd3:	ea ed 24 e6 0c       	jmp    0xce6:0x24ed
     cd8:	00 00                	add    BYTE PTR [bx+si],al
     cda:	00 f9                	add    cl,bh
     cdc:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     ce0:	b8 c9 00             	mov    ax,0xc9
     ce3:	ea ed 24 f6 0c       	jmp    0xcf6:0x24ed
     ce8:	00 00                	add    BYTE PTR [bx+si],al
     cea:	00 fa                	add    dl,bh
     cec:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     cf0:	b8 ca 00             	mov    ax,0xca
     cf3:	ea ed 24 06 0d       	jmp    0xd06:0x24ed
     cf8:	00 00                	add    BYTE PTR [bx+si],al
     cfa:	00 fb                	add    bl,bh
     cfc:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     d00:	b8 cb 00             	mov    ax,0xcb
     d03:	ea ed 24 16 0d       	jmp    0xd16:0x24ed
     d08:	00 00                	add    BYTE PTR [bx+si],al
     d0a:	00 fc                	add    ah,bh
     d0c:	01 ba 1d 00          	add    WORD PTR [bp+si+0x1d],di
     d10:	b8 cc 00             	mov    ax,0xcc
     d13:	ea ed 24 26 0d       	jmp    0xd26:0x24ed
     d18:	00 00                	add    BYTE PTR [bx+si],al
     d1a:	00 58 02             	add    BYTE PTR [bx+si+0x2],bl
     d1d:	ba 1d 00             	mov    dx,0x1d
     d20:	b8 cd 00             	mov    ax,0xcd
     d23:	ea ed 24 36 0d       	jmp    0xd36:0x24ed
     d28:	00 00                	add    BYTE PTR [bx+si],al
     d2a:	00 59 02             	add    BYTE PTR [bx+di+0x2],bl
     d2d:	ba 1d 00             	mov    dx,0x1d
     d30:	b8 ce 00             	mov    ax,0xce
     d33:	ea ed 24 46 0d       	jmp    0xd46:0x24ed
     d38:	00 00                	add    BYTE PTR [bx+si],al
     d3a:	00 5a 02             	add    BYTE PTR [bp+si+0x2],bl
     d3d:	ba 1d 00             	mov    dx,0x1d
     d40:	b8 cf 00             	mov    ax,0xcf
     d43:	ea ed 24 56 0d       	jmp    0xd56:0x24ed
     d48:	00 00                	add    BYTE PTR [bx+si],al
     d4a:	00 5b 02             	add    BYTE PTR [bp+di+0x2],bl
     d4d:	ba 1d 00             	mov    dx,0x1d
     d50:	b8 d0 00             	mov    ax,0xd0
     d53:	ea ed 24 66 0d       	jmp    0xd66:0x24ed
     d58:	00 00                	add    BYTE PTR [bx+si],al
     d5a:	00 5c 02             	add    BYTE PTR [si+0x2],bl
     d5d:	ba 1d 00             	mov    dx,0x1d
     d60:	b8 d1 00             	mov    ax,0xd1
     d63:	ea ed 24 76 0d       	jmp    0xd76:0x24ed
     d68:	00 00                	add    BYTE PTR [bx+si],al
     d6a:	00 5d 02             	add    BYTE PTR [di+0x2],bl
     d6d:	ba 1d 00             	mov    dx,0x1d
     d70:	b8 d2 00             	mov    ax,0xd2
     d73:	ea ed 24 86 0d       	jmp    0xd86:0x24ed
     d78:	00 00                	add    BYTE PTR [bx+si],al
     d7a:	00 5e 02             	add    BYTE PTR [bp+0x2],bl
     d7d:	ba 1d 00             	mov    dx,0x1d
     d80:	b8 d3 00             	mov    ax,0xd3
     d83:	ea ed 24 96 0d       	jmp    0xd96:0x24ed
     d88:	00 00                	add    BYTE PTR [bx+si],al
     d8a:	00 60 02             	add    BYTE PTR [bx+si+0x2],ah
     d8d:	ba 1d 00             	mov    dx,0x1d
     d90:	b8 d4 00             	mov    ax,0xd4
     d93:	ea ed 24 a6 0d       	jmp    0xda6:0x24ed
     d98:	00 00                	add    BYTE PTR [bx+si],al
     d9a:	00 61 02             	add    BYTE PTR [bx+di+0x2],ah
     d9d:	ba 1d 00             	mov    dx,0x1d
     da0:	b8 d5 00             	mov    ax,0xd5
     da3:	ea ed 24 b6 0d       	jmp    0xdb6:0x24ed
     da8:	00 00                	add    BYTE PTR [bx+si],al
     daa:	00 62 02             	add    BYTE PTR [bp+si+0x2],ah
     dad:	ba 1d 00             	mov    dx,0x1d
     db0:	b8 d6 00             	mov    ax,0xd6
     db3:	ea ed 24 c6 0d       	jmp    0xdc6:0x24ed
     db8:	00 00                	add    BYTE PTR [bx+si],al
     dba:	00 63 02             	add    BYTE PTR [bp+di+0x2],ah
     dbd:	ba 1d 00             	mov    dx,0x1d
     dc0:	b8 d7 00             	mov    ax,0xd7
     dc3:	ea ed 24 d6 0d       	jmp    0xdd6:0x24ed
     dc8:	00 00                	add    BYTE PTR [bx+si],al
     dca:	00 64 02             	add    BYTE PTR [si+0x2],ah
     dcd:	ba 1d 00             	mov    dx,0x1d
     dd0:	b8 d8 00             	mov    ax,0xd8
     dd3:	ea ed 24 e6 0d       	jmp    0xde6:0x24ed
     dd8:	00 00                	add    BYTE PTR [bx+si],al
     dda:	00 65 02             	add    BYTE PTR [di+0x2],ah
     ddd:	ba 1d 00             	mov    dx,0x1d
     de0:	b8 d9 00             	mov    ax,0xd9
     de3:	ea ed 24 f6 0d       	jmp    0xdf6:0x24ed
     de8:	00 00                	add    BYTE PTR [bx+si],al
     dea:	00 66 02             	add    BYTE PTR [bp+0x2],ah
     ded:	ba 1d 00             	mov    dx,0x1d
     df0:	b8 da 00             	mov    ax,0xda
     df3:	ea ed 24 06 0e       	jmp    0xe06:0x24ed
     df8:	00 00                	add    BYTE PTR [bx+si],al
     dfa:	00 67 02             	add    BYTE PTR [bx+0x2],ah
     dfd:	ba 1d 00             	mov    dx,0x1d
     e00:	b8 db 00             	mov    ax,0xdb
     e03:	ea ed 24 16 0e       	jmp    0xe16:0x24ed
     e08:	00 00                	add    BYTE PTR [bx+si],al
     e0a:	00 68 02             	add    BYTE PTR [bx+si+0x2],ch
     e0d:	ba 1d 00             	mov    dx,0x1d
     e10:	b8 dc 00             	mov    ax,0xdc
     e13:	ea ed 24 26 0e       	jmp    0xe26:0x24ed
     e18:	00 00                	add    BYTE PTR [bx+si],al
     e1a:	00 6a 02             	add    BYTE PTR [bp+si+0x2],ch
     e1d:	ba 1d 00             	mov    dx,0x1d
     e20:	b8 dd 00             	mov    ax,0xdd
     e23:	ea ed 24 36 0e       	jmp    0xe36:0x24ed
     e28:	00 00                	add    BYTE PTR [bx+si],al
     e2a:	00 6b 02             	add    BYTE PTR [bp+di+0x2],ch
     e2d:	ba 1d 00             	mov    dx,0x1d
     e30:	b8 de 00             	mov    ax,0xde
     e33:	ea ed 24 46 0e       	jmp    0xe46:0x24ed
     e38:	00 00                	add    BYTE PTR [bx+si],al
     e3a:	00 6c 02             	add    BYTE PTR [si+0x2],ch
     e3d:	ba 1d 00             	mov    dx,0x1d
     e40:	b8 df 00             	mov    ax,0xdf
     e43:	ea ed 24 56 0e       	jmp    0xe56:0x24ed
     e48:	00 00                	add    BYTE PTR [bx+si],al
     e4a:	00 6d 02             	add    BYTE PTR [di+0x2],ch
     e4d:	ba 1d 00             	mov    dx,0x1d
     e50:	b8 e0 00             	mov    ax,0xe0
     e53:	ea ed 24 66 0e       	jmp    0xe66:0x24ed
     e58:	00 00                	add    BYTE PTR [bx+si],al
     e5a:	00 6e 02             	add    BYTE PTR [bp+0x2],ch
     e5d:	ba 1d 00             	mov    dx,0x1d
     e60:	b8 e1 00             	mov    ax,0xe1
     e63:	ea ed 24 76 0e       	jmp    0xe76:0x24ed
     e68:	00 00                	add    BYTE PTR [bx+si],al
     e6a:	00 6f 02             	add    BYTE PTR [bx+0x2],ch
     e6d:	ba 1d 00             	mov    dx,0x1d
     e70:	b8 e2 00             	mov    ax,0xe2
     e73:	ea ed 24 86 0e       	jmp    0xe86:0x24ed
     e78:	00 00                	add    BYTE PTR [bx+si],al
     e7a:	00 70 02             	add    BYTE PTR [bx+si+0x2],dh
     e7d:	ba 1d 00             	mov    dx,0x1d
     e80:	b8 e3 00             	mov    ax,0xe3
     e83:	ea ed 24 96 0e       	jmp    0xe96:0x24ed
     e88:	00 00                	add    BYTE PTR [bx+si],al
     e8a:	00 71 02             	add    BYTE PTR [bx+di+0x2],dh
     e8d:	ba 1d 00             	mov    dx,0x1d
     e90:	b8 e4 00             	mov    ax,0xe4
     e93:	ea ed 24 a6 0e       	jmp    0xea6:0x24ed
     e98:	00 00                	add    BYTE PTR [bx+si],al
     e9a:	00 72 02             	add    BYTE PTR [bp+si+0x2],dh
     e9d:	ba 1d 00             	mov    dx,0x1d
     ea0:	b8 e5 00             	mov    ax,0xe5
     ea3:	ea ed 24 b6 0e       	jmp    0xeb6:0x24ed
     ea8:	00 00                	add    BYTE PTR [bx+si],al
     eaa:	00 73 02             	add    BYTE PTR [bp+di+0x2],dh
     ead:	ba 1d 00             	mov    dx,0x1d
     eb0:	b8 e6 00             	mov    ax,0xe6
     eb3:	ea ed 24 c6 0e       	jmp    0xec6:0x24ed
     eb8:	00 00                	add    BYTE PTR [bx+si],al
     eba:	00 75 02             	add    BYTE PTR [di+0x2],dh
     ebd:	ba 1d 00             	mov    dx,0x1d
     ec0:	b8 e7 00             	mov    ax,0xe7
     ec3:	ea ed 24 d6 0e       	jmp    0xed6:0x24ed
     ec8:	00 00                	add    BYTE PTR [bx+si],al
     eca:	00 76 02             	add    BYTE PTR [bp+0x2],dh
     ecd:	ba 1d 00             	mov    dx,0x1d
     ed0:	b8 e8 00             	mov    ax,0xe8
     ed3:	ea ed 24 e6 0e       	jmp    0xee6:0x24ed
     ed8:	00 00                	add    BYTE PTR [bx+si],al
     eda:	00 77 02             	add    BYTE PTR [bx+0x2],dh
     edd:	ba 1d 00             	mov    dx,0x1d
     ee0:	b8 e9 00             	mov    ax,0xe9
     ee3:	ea ed 24 f6 0e       	jmp    0xef6:0x24ed
     ee8:	00 00                	add    BYTE PTR [bx+si],al
     eea:	00 78 02             	add    BYTE PTR [bx+si+0x2],bh
     eed:	ba 1d 00             	mov    dx,0x1d
     ef0:	b8 ea 00             	mov    ax,0xea
     ef3:	ea ed 24 06 0f       	jmp    0xf06:0x24ed
     ef8:	00 00                	add    BYTE PTR [bx+si],al
     efa:	00 7c 02             	add    BYTE PTR [si+0x2],bh
     efd:	ba 1d 00             	mov    dx,0x1d
     f00:	b8 eb 00             	mov    ax,0xeb
     f03:	ea ed 24 16 0f       	jmp    0xf16:0x24ed
     f08:	00 00                	add    BYTE PTR [bx+si],al
     f0a:	00 88 02 ba          	add    BYTE PTR [bx+si-0x45fe],cl
     f0e:	1d 00 b8             	sbb    ax,0xb800
     f11:	ec                   	in     al,dx
     f12:	00 ea                	add    dl,ch
     f14:	ed                   	in     ax,dx
     f15:	24 26                	and    al,0x26
     f17:	0f 00 00             	sldt   WORD PTR [bx+si]
     f1a:	00 89 02 ba          	add    BYTE PTR [bx+di-0x45fe],cl
     f1e:	1d 00 b8             	sbb    ax,0xb800
     f21:	ed                   	in     ax,dx
     f22:	00 ea                	add    dl,ch
     f24:	ed                   	in     ax,dx
     f25:	24 36                	and    al,0x36
     f27:	0f 00 00             	sldt   WORD PTR [bx+si]
     f2a:	00 8a 02 ba          	add    BYTE PTR [bp+si-0x45fe],cl
     f2e:	1d 00 b8             	sbb    ax,0xb800
     f31:	ee                   	out    dx,al
     f32:	00 ea                	add    dl,ch
     f34:	ed                   	in     ax,dx
     f35:	24 46                	and    al,0x46
     f37:	0f 00 00             	sldt   WORD PTR [bx+si]
     f3a:	00 8b 02 ba          	add    BYTE PTR [bp+di-0x45fe],cl
     f3e:	1d 00 b8             	sbb    ax,0xb800
     f41:	ef                   	out    dx,ax
     f42:	00 ea                	add    dl,ch
     f44:	ed                   	in     ax,dx
     f45:	24 56                	and    al,0x56
     f47:	0f 00 00             	sldt   WORD PTR [bx+si]
     f4a:	00 8c 02 ba          	add    BYTE PTR [si-0x45fe],cl
     f4e:	1d 00 b8             	sbb    ax,0xb800
     f51:	f0 00 ea             	lock add dl,ch
     f54:	ed                   	in     ax,dx
     f55:	24 66                	and    al,0x66
     f57:	0f 00 00             	sldt   WORD PTR [bx+si]
     f5a:	00 8d 02 ba          	add    BYTE PTR [di-0x45fe],cl
     f5e:	1d 00 b8             	sbb    ax,0xb800
     f61:	f1                   	int1
     f62:	00 ea                	add    dl,ch
     f64:	ed                   	in     ax,dx
     f65:	24 76                	and    al,0x76
     f67:	0f 00 00             	sldt   WORD PTR [bx+si]
     f6a:	00 8e 02 ba          	add    BYTE PTR [bp-0x45fe],cl
     f6e:	1d 00 b8             	sbb    ax,0xb800
     f71:	f2 00 ea             	repnz add dl,ch
     f74:	ed                   	in     ax,dx
     f75:	24 86                	and    al,0x86
     f77:	0f 00 00             	sldt   WORD PTR [bx+si]
     f7a:	00 8f 02 ba          	add    BYTE PTR [bx-0x45fe],cl
     f7e:	1d 00 b8             	sbb    ax,0xb800
     f81:	f3 00 ea             	repz add dl,ch
     f84:	ed                   	in     ax,dx
     f85:	24 96                	and    al,0x96
     f87:	0f 00 00             	sldt   WORD PTR [bx+si]
     f8a:	00 90 02 ba          	add    BYTE PTR [bx+si-0x45fe],dl
     f8e:	1d 00 b8             	sbb    ax,0xb800
     f91:	f4                   	hlt
     f92:	00 ea                	add    dl,ch
     f94:	ed                   	in     ax,dx
     f95:	24 a6                	and    al,0xa6
     f97:	0f 00 00             	sldt   WORD PTR [bx+si]
     f9a:	00 91 02 ba          	add    BYTE PTR [bx+di-0x45fe],dl
     f9e:	1d 00 b8             	sbb    ax,0xb800
     fa1:	f5                   	cmc
     fa2:	00 ea                	add    dl,ch
     fa4:	ed                   	in     ax,dx
     fa5:	24 b6                	and    al,0xb6
     fa7:	0f 00 00             	sldt   WORD PTR [bx+si]
     faa:	00 92 02 ba          	add    BYTE PTR [bp+si-0x45fe],dl
     fae:	1d 00 b8             	sbb    ax,0xb800
     fb1:	f6 00 ea             	test   BYTE PTR [bx+si],0xea
     fb4:	ed                   	in     ax,dx
     fb5:	24 c6                	and    al,0xc6
     fb7:	0f 00 00             	sldt   WORD PTR [bx+si]
     fba:	00 93 02 ba          	add    BYTE PTR [bp+di-0x45fe],dl
     fbe:	1d 00 b8             	sbb    ax,0xb800
     fc1:	f7 00 ea ed          	test   WORD PTR [bx+si],0xedea
     fc5:	24 d6                	and    al,0xd6
     fc7:	0f 00 00             	sldt   WORD PTR [bx+si]
     fca:	00 94 02 ba          	add    BYTE PTR [si-0x45fe],dl
     fce:	1d 00 b8             	sbb    ax,0xb800
     fd1:	f8                   	clc
     fd2:	00 ea                	add    dl,ch
     fd4:	ed                   	in     ax,dx
     fd5:	24 e6                	and    al,0xe6
     fd7:	0f 00 00             	sldt   WORD PTR [bx+si]
     fda:	00 95 02 ba          	add    BYTE PTR [di-0x45fe],dl
     fde:	1d 00 b8             	sbb    ax,0xb800
     fe1:	f9                   	stc
     fe2:	00 ea                	add    dl,ch
     fe4:	ed                   	in     ax,dx
     fe5:	24 f6                	and    al,0xf6
     fe7:	0f 00 00             	sldt   WORD PTR [bx+si]
     fea:	00 96 02 ba          	add    BYTE PTR [bp-0x45fe],dl
     fee:	1d 00 b8             	sbb    ax,0xb800
     ff1:	fa                   	cli
     ff2:	00 ea                	add    dl,ch
     ff4:	ed                   	in     ax,dx
     ff5:	24 06                	and    al,0x6
     ff7:	10 00                	adc    BYTE PTR [bx+si],al
     ff9:	00 00                	add    BYTE PTR [bx+si],al
     ffb:	97                   	xchg   di,ax
     ffc:	02 ba 1d 00          	add    bh,BYTE PTR [bp+si+0x1d]
    1000:	b8 fb 00             	mov    ax,0xfb
    1003:	ea ed 24 16 10       	jmp    0x1016:0x24ed
    1008:	00 00                	add    BYTE PTR [bx+si],al
    100a:	00 98 02 ba          	add    BYTE PTR [bx+si-0x45fe],bl
    100e:	1d 00 b8             	sbb    ax,0xb800
    1011:	fc                   	cld
    1012:	00 ea                	add    dl,ch
    1014:	ed                   	in     ax,dx
    1015:	24 26                	and    al,0x26
    1017:	10 00                	adc    BYTE PTR [bx+si],al
    1019:	00 00                	add    BYTE PTR [bx+si],al
    101b:	99                   	cwd
    101c:	02 ba 1d 00          	add    bh,BYTE PTR [bp+si+0x1d]
    1020:	b8 fd 00             	mov    ax,0xfd
    1023:	ea ed 24 36 10       	jmp    0x1036:0x24ed
    1028:	00 00                	add    BYTE PTR [bx+si],al
    102a:	00 9a 02 ba          	add    BYTE PTR [bp+si-0x45fe],bl
    102e:	1d 00 b8             	sbb    ax,0xb800
    1031:	fe 00                	inc    BYTE PTR [bx+si]
    1033:	ea ed 24 46 10       	jmp    0x1046:0x24ed
    1038:	00 00                	add    BYTE PTR [bx+si],al
    103a:	00 9b 02 ba          	add    BYTE PTR [bp+di-0x45fe],bl
    103e:	1d 00 b8             	sbb    ax,0xb800
    1041:	ff 00                	inc    WORD PTR [bx+si]
    1043:	ea ed 24 56 10       	jmp    0x1056:0x24ed
    1048:	00 00                	add    BYTE PTR [bx+si],al
    104a:	00 9c 02 ba          	add    BYTE PTR [si-0x45fe],bl
    104e:	1d 00 b8             	sbb    ax,0xb800
    1051:	00 01                	add    BYTE PTR [bx+di],al
    1053:	ea ed 24 66 10       	jmp    0x1066:0x24ed
    1058:	00 00                	add    BYTE PTR [bx+si],al
    105a:	00 9d 02 ba          	add    BYTE PTR [di-0x45fe],bl
    105e:	1d 00 b8             	sbb    ax,0xb800
    1061:	01 01                	add    WORD PTR [bx+di],ax
    1063:	ea ed 24 76 10       	jmp    0x1076:0x24ed
    1068:	00 00                	add    BYTE PTR [bx+si],al
    106a:	00 9e 02 ba          	add    BYTE PTR [bp-0x45fe],bl
    106e:	1d 00 b8             	sbb    ax,0xb800
    1071:	02 01                	add    al,BYTE PTR [bx+di]
    1073:	ea ed 24 86 10       	jmp    0x1086:0x24ed
    1078:	00 00                	add    BYTE PTR [bx+si],al
    107a:	00 9f 02 ba          	add    BYTE PTR [bx-0x45fe],bl
    107e:	1d 00 b8             	sbb    ax,0xb800
    1081:	03 01                	add    ax,WORD PTR [bx+di]
    1083:	ea ed 24 96 10       	jmp    0x1096:0x24ed
    1088:	00 00                	add    BYTE PTR [bx+si],al
    108a:	00 a0 02 ba          	add    BYTE PTR [bx+si-0x45fe],ah
    108e:	1d 00 b8             	sbb    ax,0xb800
    1091:	04 01                	add    al,0x1
    1093:	ea ed 24 a6 10       	jmp    0x10a6:0x24ed
    1098:	00 00                	add    BYTE PTR [bx+si],al
    109a:	00 a1 02 ba          	add    BYTE PTR [bx+di-0x45fe],ah
    109e:	1d 00 b8             	sbb    ax,0xb800
    10a1:	05 01 ea             	add    ax,0xea01
    10a4:	ed                   	in     ax,dx
    10a5:	24 b6                	and    al,0xb6
    10a7:	10 00                	adc    BYTE PTR [bx+si],al
    10a9:	00 00                	add    BYTE PTR [bx+si],al
    10ab:	a2 02 ba             	mov    ds:0xba02,al
    10ae:	1d 00 b8             	sbb    ax,0xb800
    10b1:	06                   	push   es
    10b2:	01 ea                	add    dx,bp
    10b4:	ed                   	in     ax,dx
    10b5:	24 c6                	and    al,0xc6
    10b7:	10 00                	adc    BYTE PTR [bx+si],al
    10b9:	00 00                	add    BYTE PTR [bx+si],al
    10bb:	a3 02 ba             	mov    ds:0xba02,ax
    10be:	1d 00 b8             	sbb    ax,0xb800
    10c1:	07                   	pop    es
    10c2:	01 ea                	add    dx,bp
    10c4:	ed                   	in     ax,dx
    10c5:	24 d6                	and    al,0xd6
    10c7:	10 00                	adc    BYTE PTR [bx+si],al
    10c9:	00 00                	add    BYTE PTR [bx+si],al
    10cb:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    10cc:	02 ba 1d 00          	add    bh,BYTE PTR [bp+si+0x1d]
    10d0:	b8 08 01             	mov    ax,0x108
    10d3:	ea ed 24 e6 10       	jmp    0x10e6:0x24ed
    10d8:	00 00                	add    BYTE PTR [bx+si],al
    10da:	00 a5 02 ba          	add    BYTE PTR [di-0x45fe],ah
    10de:	1d 00 b8             	sbb    ax,0xb800
    10e1:	09 01                	or     WORD PTR [bx+di],ax
    10e3:	ea ed 24 f6 10       	jmp    0x10f6:0x24ed
    10e8:	00 00                	add    BYTE PTR [bx+si],al
    10ea:	00 a6 02 ba          	add    BYTE PTR [bp-0x45fe],ah
    10ee:	1d 00 b8             	sbb    ax,0xb800
    10f1:	0a 01                	or     al,BYTE PTR [bx+di]
    10f3:	ea ed 24 06 11       	jmp    0x1106:0x24ed
    10f8:	00 00                	add    BYTE PTR [bx+si],al
    10fa:	00 a7 02 ba          	add    BYTE PTR [bx-0x45fe],ah
    10fe:	1d 00 b8             	sbb    ax,0xb800
    1101:	0b 01                	or     ax,WORD PTR [bx+di]
    1103:	ea ed 24 16 11       	jmp    0x1116:0x24ed
    1108:	00 00                	add    BYTE PTR [bx+si],al
    110a:	00 a8 02 ba          	add    BYTE PTR [bx+si-0x45fe],ch
    110e:	1d 00 b8             	sbb    ax,0xb800
    1111:	0c 01                	or     al,0x1
    1113:	ea ed 24 26 11       	jmp    0x1126:0x24ed
    1118:	00 00                	add    BYTE PTR [bx+si],al
    111a:	00 a9 02 ba          	add    BYTE PTR [bx+di-0x45fe],ch
    111e:	1d 00 b8             	sbb    ax,0xb800
    1121:	0d 01 ea             	or     ax,0xea01
    1124:	ed                   	in     ax,dx
    1125:	24 36                	and    al,0x36
    1127:	11 00                	adc    WORD PTR [bx+si],ax
    1129:	00 00                	add    BYTE PTR [bx+si],al
    112b:	aa                   	stos   BYTE PTR es:[di],al
    112c:	02 ba 1d 00          	add    bh,BYTE PTR [bp+si+0x1d]
    1130:	b8 0e 01             	mov    ax,0x10e
    1133:	ea ed 24 46 11       	jmp    0x1146:0x24ed
    1138:	00 00                	add    BYTE PTR [bx+si],al
    113a:	00 ab 02 ba          	add    BYTE PTR [bp+di-0x45fe],ch
    113e:	1d 00 b8             	sbb    ax,0xb800
    1141:	0f 01                	(bad)
    1143:	ea ed 24 56 11       	jmp    0x1156:0x24ed
    1148:	00 00                	add    BYTE PTR [bx+si],al
    114a:	00 ac 02 ba          	add    BYTE PTR [si-0x45fe],ch
    114e:	1d 00 b8             	sbb    ax,0xb800
    1151:	10 01                	adc    BYTE PTR [bx+di],al
    1153:	ea ed 24 66 11       	jmp    0x1166:0x24ed
    1158:	00 00                	add    BYTE PTR [bx+si],al
    115a:	00 ad 02 ba          	add    BYTE PTR [di-0x45fe],ch
    115e:	1d 00 b8             	sbb    ax,0xb800
    1161:	11 01                	adc    WORD PTR [bx+di],ax
    1163:	ea ed 24 76 11       	jmp    0x1176:0x24ed
    1168:	00 00                	add    BYTE PTR [bx+si],al
    116a:	00 ae 02 ba          	add    BYTE PTR [bp-0x45fe],ch
    116e:	1d 00 b8             	sbb    ax,0xb800
    1171:	12 01                	adc    al,BYTE PTR [bx+di]
    1173:	ea ed 24 86 11       	jmp    0x1186:0x24ed
    1178:	00 00                	add    BYTE PTR [bx+si],al
    117a:	00 af 02 ba          	add    BYTE PTR [bx-0x45fe],ch
    117e:	1d 00 b8             	sbb    ax,0xb800
    1181:	13 01                	adc    ax,WORD PTR [bx+di]
    1183:	ea ed 24 96 11       	jmp    0x1196:0x24ed
    1188:	00 00                	add    BYTE PTR [bx+si],al
    118a:	00 b0 02 ba          	add    BYTE PTR [bx+si-0x45fe],dh
    118e:	1d 00 b8             	sbb    ax,0xb800
    1191:	14 01                	adc    al,0x1
    1193:	ea ed 24 a6 11       	jmp    0x11a6:0x24ed
    1198:	00 00                	add    BYTE PTR [bx+si],al
    119a:	00 b1 02 ba          	add    BYTE PTR [bx+di-0x45fe],dh
    119e:	1d 00 b8             	sbb    ax,0xb800
    11a1:	15 01 ea             	adc    ax,0xea01
    11a4:	ed                   	in     ax,dx
    11a5:	24 b6                	and    al,0xb6
    11a7:	11 00                	adc    WORD PTR [bx+si],ax
    11a9:	00 00                	add    BYTE PTR [bx+si],al
    11ab:	b2 02                	mov    dl,0x2
    11ad:	ba 1d 00             	mov    dx,0x1d
    11b0:	b8 16 01             	mov    ax,0x116
    11b3:	ea ed 24 c6 11       	jmp    0x11c6:0x24ed
    11b8:	00 00                	add    BYTE PTR [bx+si],al
    11ba:	00 b3 02 ba          	add    BYTE PTR [bp+di-0x45fe],dh
    11be:	1d 00 b8             	sbb    ax,0xb800
    11c1:	17                   	pop    ss
    11c2:	01 ea                	add    dx,bp
    11c4:	ed                   	in     ax,dx
    11c5:	24 d6                	and    al,0xd6
    11c7:	11 00                	adc    WORD PTR [bx+si],ax
    11c9:	00 00                	add    BYTE PTR [bx+si],al
    11cb:	b4 02                	mov    ah,0x2
    11cd:	ba 1d 00             	mov    dx,0x1d
    11d0:	b8 18 01             	mov    ax,0x118
    11d3:	ea ed 24 e6 11       	jmp    0x11e6:0x24ed
    11d8:	00 00                	add    BYTE PTR [bx+si],al
    11da:	00 b5 02 ba          	add    BYTE PTR [di-0x45fe],dh
    11de:	1d 00 b8             	sbb    ax,0xb800
    11e1:	19 01                	sbb    WORD PTR [bx+di],ax
    11e3:	ea ed 24 f6 11       	jmp    0x11f6:0x24ed
    11e8:	00 00                	add    BYTE PTR [bx+si],al
    11ea:	00 b6 02 ba          	add    BYTE PTR [bp-0x45fe],dh
    11ee:	1d 00 b8             	sbb    ax,0xb800
    11f1:	1a 01                	sbb    al,BYTE PTR [bx+di]
    11f3:	ea ed 24 06 12       	jmp    0x1206:0x24ed
    11f8:	00 00                	add    BYTE PTR [bx+si],al
    11fa:	00 b7 02 ba          	add    BYTE PTR [bx-0x45fe],dh
    11fe:	1d 00 b8             	sbb    ax,0xb800
    1201:	1b 01                	sbb    ax,WORD PTR [bx+di]
    1203:	ea ed 24 16 12       	jmp    0x1216:0x24ed
    1208:	00 00                	add    BYTE PTR [bx+si],al
    120a:	00 b8 02 ba          	add    BYTE PTR [bx+si-0x45fe],bh
    120e:	1d 00 b8             	sbb    ax,0xb800
    1211:	1c 01                	sbb    al,0x1
    1213:	ea ed 24 26 12       	jmp    0x1226:0x24ed
    1218:	00 00                	add    BYTE PTR [bx+si],al
    121a:	00 b9 02 ba          	add    BYTE PTR [bx+di-0x45fe],bh
    121e:	1d 00 b8             	sbb    ax,0xb800
    1221:	1d 01 ea             	sbb    ax,0xea01
    1224:	ed                   	in     ax,dx
    1225:	24 36                	and    al,0x36
    1227:	12 00                	adc    al,BYTE PTR [bx+si]
    1229:	00 00                	add    BYTE PTR [bx+si],al
    122b:	ba 02 ba             	mov    dx,0xba02
    122e:	1d 00 b8             	sbb    ax,0xb800
    1231:	1e                   	push   ds
    1232:	01 ea                	add    dx,bp
    1234:	ed                   	in     ax,dx
    1235:	24 46                	and    al,0x46
    1237:	12 00                	adc    al,BYTE PTR [bx+si]
    1239:	00 00                	add    BYTE PTR [bx+si],al
    123b:	bb 02 ba             	mov    bx,0xba02
    123e:	1d 00 b8             	sbb    ax,0xb800
    1241:	1f                   	pop    ds
    1242:	01 ea                	add    dx,bp
    1244:	ed                   	in     ax,dx
    1245:	24 56                	and    al,0x56
    1247:	12 00                	adc    al,BYTE PTR [bx+si]
    1249:	00 00                	add    BYTE PTR [bx+si],al
    124b:	bd 02 ba             	mov    bp,0xba02
    124e:	1d 00 b8             	sbb    ax,0xb800
    1251:	20 01                	and    BYTE PTR [bx+di],al
    1253:	ea ed 24 66 12       	jmp    0x1266:0x24ed
    1258:	00 00                	add    BYTE PTR [bx+si],al
    125a:	00 be 02 ba          	add    BYTE PTR [bp-0x45fe],bh
    125e:	1d 00 b8             	sbb    ax,0xb800
    1261:	21 01                	and    WORD PTR [bx+di],ax
    1263:	ea ed 24 76 12       	jmp    0x1276:0x24ed
    1268:	00 00                	add    BYTE PTR [bx+si],al
    126a:	00 d3                	add    bl,dl
    126c:	02 ba 1d 00          	add    bh,BYTE PTR [bp+si+0x1d]
    1270:	b8 22 01             	mov    ax,0x122
    1273:	ea ed 24 86 12       	jmp    0x1286:0x24ed
    1278:	00 00                	add    BYTE PTR [bx+si],al
    127a:	00 d4                	add    ah,dl
    127c:	02 ba 1d 00          	add    bh,BYTE PTR [bp+si+0x1d]
    1280:	b8 23 01             	mov    ax,0x123
    1283:	ea ed 24 96 12       	jmp    0x1296:0x24ed
    1288:	00 00                	add    BYTE PTR [bx+si],al
    128a:	00 d5                	add    ch,dl
    128c:	02 ba 1d 00          	add    bh,BYTE PTR [bp+si+0x1d]
    1290:	b8 24 01             	mov    ax,0x124
    1293:	ea ed 24 a6 12       	jmp    0x12a6:0x24ed
    1298:	00 00                	add    BYTE PTR [bx+si],al
    129a:	00 da                	add    dl,bl
    129c:	02 ba 1d 00          	add    bh,BYTE PTR [bp+si+0x1d]
    12a0:	b8 25 01             	mov    ax,0x125
    12a3:	ea ed 24 b6 12       	jmp    0x12b6:0x24ed
    12a8:	00 00                	add    BYTE PTR [bx+si],al
    12aa:	00 db                	add    bl,bl
    12ac:	02 ba 1d 00          	add    bh,BYTE PTR [bp+si+0x1d]
    12b0:	b8 26 01             	mov    ax,0x126
    12b3:	ea ed 24 c6 12       	jmp    0x12c6:0x24ed
    12b8:	00 00                	add    BYTE PTR [bx+si],al
    12ba:	00 04                	add    BYTE PTR [si],al
    12bc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    12c0:	b8 27 01             	mov    ax,0x127
    12c3:	ea ed 24 d6 12       	jmp    0x12d6:0x24ed
    12c8:	00 00                	add    BYTE PTR [bx+si],al
    12ca:	00 05                	add    BYTE PTR [di],al
    12cc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    12d0:	b8 28 01             	mov    ax,0x128
    12d3:	ea ed 24 e6 12       	jmp    0x12e6:0x24ed
    12d8:	00 00                	add    BYTE PTR [bx+si],al
    12da:	00 06 03 ba          	add    BYTE PTR ds:0xba03,al
    12de:	1d 00 b8             	sbb    ax,0xb800
    12e1:	29 01                	sub    WORD PTR [bx+di],ax
    12e3:	ea ed 24 f6 12       	jmp    0x12f6:0x24ed
    12e8:	00 00                	add    BYTE PTR [bx+si],al
    12ea:	00 08                	add    BYTE PTR [bx+si],cl
    12ec:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    12f0:	b8 2a 01             	mov    ax,0x12a
    12f3:	ea ed 24 06 13       	jmp    0x1306:0x24ed
    12f8:	00 00                	add    BYTE PTR [bx+si],al
    12fa:	00 09                	add    BYTE PTR [bx+di],cl
    12fc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1300:	b8 2b 01             	mov    ax,0x12b
    1303:	ea ed 24 16 13       	jmp    0x1316:0x24ed
    1308:	00 00                	add    BYTE PTR [bx+si],al
    130a:	00 0a                	add    BYTE PTR [bp+si],cl
    130c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1310:	b8 2c 01             	mov    ax,0x12c
    1313:	ea ed 24 26 13       	jmp    0x1326:0x24ed
    1318:	00 00                	add    BYTE PTR [bx+si],al
    131a:	00 0b                	add    BYTE PTR [bp+di],cl
    131c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1320:	b8 2d 01             	mov    ax,0x12d
    1323:	ea ed 24 36 13       	jmp    0x1336:0x24ed
    1328:	00 00                	add    BYTE PTR [bx+si],al
    132a:	00 0c                	add    BYTE PTR [si],cl
    132c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1330:	b8 2e 01             	mov    ax,0x12e
    1333:	ea ed 24 46 13       	jmp    0x1346:0x24ed
    1338:	00 00                	add    BYTE PTR [bx+si],al
    133a:	00 0d                	add    BYTE PTR [di],cl
    133c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1340:	b8 2f 01             	mov    ax,0x12f
    1343:	ea ed 24 56 13       	jmp    0x1356:0x24ed
    1348:	00 00                	add    BYTE PTR [bx+si],al
    134a:	00 0e 03 ba          	add    BYTE PTR ds:0xba03,cl
    134e:	1d 00 b8             	sbb    ax,0xb800
    1351:	30 01                	xor    BYTE PTR [bx+di],al
    1353:	ea ed 24 66 13       	jmp    0x1366:0x24ed
    1358:	00 00                	add    BYTE PTR [bx+si],al
    135a:	00 0f                	add    BYTE PTR [bx],cl
    135c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1360:	b8 31 01             	mov    ax,0x131
    1363:	ea ed 24 76 13       	jmp    0x1376:0x24ed
    1368:	00 00                	add    BYTE PTR [bx+si],al
    136a:	00 10                	add    BYTE PTR [bx+si],dl
    136c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1370:	b8 32 01             	mov    ax,0x132
    1373:	ea ed 24 86 13       	jmp    0x1386:0x24ed
    1378:	00 00                	add    BYTE PTR [bx+si],al
    137a:	00 11                	add    BYTE PTR [bx+di],dl
    137c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1380:	b8 33 01             	mov    ax,0x133
    1383:	ea ed 24 96 13       	jmp    0x1396:0x24ed
    1388:	00 00                	add    BYTE PTR [bx+si],al
    138a:	00 12                	add    BYTE PTR [bp+si],dl
    138c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1390:	b8 34 01             	mov    ax,0x134
    1393:	ea ed 24 a6 13       	jmp    0x13a6:0x24ed
    1398:	00 00                	add    BYTE PTR [bx+si],al
    139a:	00 13                	add    BYTE PTR [bp+di],dl
    139c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    13a0:	b8 35 01             	mov    ax,0x135
    13a3:	ea ed 24 b6 13       	jmp    0x13b6:0x24ed
    13a8:	00 00                	add    BYTE PTR [bx+si],al
    13aa:	00 14                	add    BYTE PTR [si],dl
    13ac:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    13b0:	b8 36 01             	mov    ax,0x136
    13b3:	ea ed 24 c6 13       	jmp    0x13c6:0x24ed
    13b8:	00 00                	add    BYTE PTR [bx+si],al
    13ba:	00 15                	add    BYTE PTR [di],dl
    13bc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    13c0:	b8 37 01             	mov    ax,0x137
    13c3:	ea ed 24 d6 13       	jmp    0x13d6:0x24ed
    13c8:	00 00                	add    BYTE PTR [bx+si],al
    13ca:	00 16 03 ba          	add    BYTE PTR ds:0xba03,dl
    13ce:	1d 00 b8             	sbb    ax,0xb800
    13d1:	38 01                	cmp    BYTE PTR [bx+di],al
    13d3:	ea ed 24 e6 13       	jmp    0x13e6:0x24ed
    13d8:	00 00                	add    BYTE PTR [bx+si],al
    13da:	00 17                	add    BYTE PTR [bx],dl
    13dc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    13e0:	b8 39 01             	mov    ax,0x139
    13e3:	ea ed 24 f6 13       	jmp    0x13f6:0x24ed
    13e8:	00 00                	add    BYTE PTR [bx+si],al
    13ea:	00 18                	add    BYTE PTR [bx+si],bl
    13ec:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    13f0:	b8 3a 01             	mov    ax,0x13a
    13f3:	ea ed 24 06 14       	jmp    0x1406:0x24ed
    13f8:	00 00                	add    BYTE PTR [bx+si],al
    13fa:	00 19                	add    BYTE PTR [bx+di],bl
    13fc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1400:	b8 3b 01             	mov    ax,0x13b
    1403:	ea ed 24 16 14       	jmp    0x1416:0x24ed
    1408:	00 00                	add    BYTE PTR [bx+si],al
    140a:	00 1a                	add    BYTE PTR [bp+si],bl
    140c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1410:	b8 3c 01             	mov    ax,0x13c
    1413:	ea ed 24 26 14       	jmp    0x1426:0x24ed
    1418:	00 00                	add    BYTE PTR [bx+si],al
    141a:	00 1b                	add    BYTE PTR [bp+di],bl
    141c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1420:	b8 3d 01             	mov    ax,0x13d
    1423:	ea ed 24 36 14       	jmp    0x1436:0x24ed
    1428:	00 00                	add    BYTE PTR [bx+si],al
    142a:	00 1c                	add    BYTE PTR [si],bl
    142c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1430:	b8 3e 01             	mov    ax,0x13e
    1433:	ea ed 24 46 14       	jmp    0x1446:0x24ed
    1438:	00 00                	add    BYTE PTR [bx+si],al
    143a:	00 1d                	add    BYTE PTR [di],bl
    143c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1440:	b8 3f 01             	mov    ax,0x13f
    1443:	ea ed 24 56 14       	jmp    0x1456:0x24ed
    1448:	00 00                	add    BYTE PTR [bx+si],al
    144a:	00 1e 03 ba          	add    BYTE PTR ds:0xba03,bl
    144e:	1d 00 b8             	sbb    ax,0xb800
    1451:	40                   	inc    ax
    1452:	01 ea                	add    dx,bp
    1454:	ed                   	in     ax,dx
    1455:	24 66                	and    al,0x66
    1457:	14 00                	adc    al,0x0
    1459:	00 00                	add    BYTE PTR [bx+si],al
    145b:	1f                   	pop    ds
    145c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1460:	b8 41 01             	mov    ax,0x141
    1463:	ea ed 24 76 14       	jmp    0x1476:0x24ed
    1468:	00 00                	add    BYTE PTR [bx+si],al
    146a:	00 20                	add    BYTE PTR [bx+si],ah
    146c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1470:	b8 42 01             	mov    ax,0x142
    1473:	ea ed 24 86 14       	jmp    0x1486:0x24ed
    1478:	00 00                	add    BYTE PTR [bx+si],al
    147a:	00 21                	add    BYTE PTR [bx+di],ah
    147c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1480:	b8 43 01             	mov    ax,0x143
    1483:	ea ed 24 96 14       	jmp    0x1496:0x24ed
    1488:	00 00                	add    BYTE PTR [bx+si],al
    148a:	00 22                	add    BYTE PTR [bp+si],ah
    148c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1490:	b8 44 01             	mov    ax,0x144
    1493:	ea ed 24 a6 14       	jmp    0x14a6:0x24ed
    1498:	00 00                	add    BYTE PTR [bx+si],al
    149a:	00 23                	add    BYTE PTR [bp+di],ah
    149c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    14a0:	b8 45 01             	mov    ax,0x145
    14a3:	ea ed 24 b6 14       	jmp    0x14b6:0x24ed
    14a8:	00 00                	add    BYTE PTR [bx+si],al
    14aa:	00 24                	add    BYTE PTR [si],ah
    14ac:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    14b0:	b8 46 01             	mov    ax,0x146
    14b3:	ea ed 24 c6 14       	jmp    0x14c6:0x24ed
    14b8:	00 00                	add    BYTE PTR [bx+si],al
    14ba:	00 25                	add    BYTE PTR [di],ah
    14bc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    14c0:	b8 47 01             	mov    ax,0x147
    14c3:	ea ed 24 d6 14       	jmp    0x14d6:0x24ed
    14c8:	00 00                	add    BYTE PTR [bx+si],al
    14ca:	00 26 03 ba          	add    BYTE PTR ds:0xba03,ah
    14ce:	1d 00 b8             	sbb    ax,0xb800
    14d1:	48                   	dec    ax
    14d2:	01 ea                	add    dx,bp
    14d4:	ed                   	in     ax,dx
    14d5:	24 e6                	and    al,0xe6
    14d7:	14 00                	adc    al,0x0
    14d9:	00 00                	add    BYTE PTR [bx+si],al
    14db:	27                   	daa
    14dc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    14e0:	b8 49 01             	mov    ax,0x149
    14e3:	ea ed 24 f6 14       	jmp    0x14f6:0x24ed
    14e8:	00 00                	add    BYTE PTR [bx+si],al
    14ea:	00 28                	add    BYTE PTR [bx+si],ch
    14ec:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    14f0:	b8 4a 01             	mov    ax,0x14a
    14f3:	ea ed 24 06 15       	jmp    0x1506:0x24ed
    14f8:	00 00                	add    BYTE PTR [bx+si],al
    14fa:	00 29                	add    BYTE PTR [bx+di],ch
    14fc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1500:	b8 4b 01             	mov    ax,0x14b
    1503:	ea ed 24 16 15       	jmp    0x1516:0x24ed
    1508:	00 00                	add    BYTE PTR [bx+si],al
    150a:	00 2a                	add    BYTE PTR [bp+si],ch
    150c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1510:	b8 4c 01             	mov    ax,0x14c
    1513:	ea ed 24 26 15       	jmp    0x1526:0x24ed
    1518:	00 00                	add    BYTE PTR [bx+si],al
    151a:	00 2b                	add    BYTE PTR [bp+di],ch
    151c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1520:	b8 4d 01             	mov    ax,0x14d
    1523:	ea ed 24 36 15       	jmp    0x1536:0x24ed
    1528:	00 00                	add    BYTE PTR [bx+si],al
    152a:	00 2c                	add    BYTE PTR [si],ch
    152c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1530:	b8 4e 01             	mov    ax,0x14e
    1533:	ea ed 24 46 15       	jmp    0x1546:0x24ed
    1538:	00 00                	add    BYTE PTR [bx+si],al
    153a:	00 2d                	add    BYTE PTR [di],ch
    153c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1540:	b8 4f 01             	mov    ax,0x14f
    1543:	ea ed 24 56 15       	jmp    0x1556:0x24ed
    1548:	00 00                	add    BYTE PTR [bx+si],al
    154a:	00 2e 03 ba          	add    BYTE PTR ds:0xba03,ch
    154e:	1d 00 b8             	sbb    ax,0xb800
    1551:	50                   	push   ax
    1552:	01 ea                	add    dx,bp
    1554:	ed                   	in     ax,dx
    1555:	24 66                	and    al,0x66
    1557:	15 00 00             	adc    ax,0x0
    155a:	00 2f                	add    BYTE PTR [bx],ch
    155c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1560:	b8 51 01             	mov    ax,0x151
    1563:	ea ed 24 76 15       	jmp    0x1576:0x24ed
    1568:	00 00                	add    BYTE PTR [bx+si],al
    156a:	00 30                	add    BYTE PTR [bx+si],dh
    156c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1570:	b8 52 01             	mov    ax,0x152
    1573:	ea ed 24 86 15       	jmp    0x1586:0x24ed
    1578:	00 00                	add    BYTE PTR [bx+si],al
    157a:	00 31                	add    BYTE PTR [bx+di],dh
    157c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1580:	b8 53 01             	mov    ax,0x153
    1583:	ea ed 24 96 15       	jmp    0x1596:0x24ed
    1588:	00 00                	add    BYTE PTR [bx+si],al
    158a:	00 37                	add    BYTE PTR [bx],dh
    158c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1590:	b8 54 01             	mov    ax,0x154
    1593:	ea ed 24 a6 15       	jmp    0x15a6:0x24ed
    1598:	00 00                	add    BYTE PTR [bx+si],al
    159a:	00 38                	add    BYTE PTR [bx+si],bh
    159c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    15a0:	b8 55 01             	mov    ax,0x155
    15a3:	ea ed 24 b6 15       	jmp    0x15b6:0x24ed
    15a8:	00 00                	add    BYTE PTR [bx+si],al
    15aa:	00 39                	add    BYTE PTR [bx+di],bh
    15ac:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    15b0:	b8 56 01             	mov    ax,0x156
    15b3:	ea ed 24 c6 15       	jmp    0x15c6:0x24ed
    15b8:	00 00                	add    BYTE PTR [bx+si],al
    15ba:	00 3a                	add    BYTE PTR [bp+si],bh
    15bc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    15c0:	b8 57 01             	mov    ax,0x157
    15c3:	ea ed 24 d6 15       	jmp    0x15d6:0x24ed
    15c8:	00 00                	add    BYTE PTR [bx+si],al
    15ca:	00 3b                	add    BYTE PTR [bp+di],bh
    15cc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    15d0:	b8 58 01             	mov    ax,0x158
    15d3:	ea ed 24 e6 15       	jmp    0x15e6:0x24ed
    15d8:	00 00                	add    BYTE PTR [bx+si],al
    15da:	00 3c                	add    BYTE PTR [si],bh
    15dc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    15e0:	b8 59 01             	mov    ax,0x159
    15e3:	ea ed 24 f6 15       	jmp    0x15f6:0x24ed
    15e8:	00 00                	add    BYTE PTR [bx+si],al
    15ea:	00 3d                	add    BYTE PTR [di],bh
    15ec:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    15f0:	b8 5a 01             	mov    ax,0x15a
    15f3:	ea ed 24 06 16       	jmp    0x1606:0x24ed
    15f8:	00 00                	add    BYTE PTR [bx+si],al
    15fa:	00 3e 03 ba          	add    BYTE PTR ds:0xba03,bh
    15fe:	1d 00 b8             	sbb    ax,0xb800
    1601:	5b                   	pop    bx
    1602:	01 ea                	add    dx,bp
    1604:	ed                   	in     ax,dx
    1605:	24 16                	and    al,0x16
    1607:	16                   	push   ss
    1608:	00 00                	add    BYTE PTR [bx+si],al
    160a:	00 3f                	add    BYTE PTR [bx],bh
    160c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1610:	b8 5c 01             	mov    ax,0x15c
    1613:	ea ed 24 26 16       	jmp    0x1626:0x24ed
    1618:	00 00                	add    BYTE PTR [bx+si],al
    161a:	00 40 03             	add    BYTE PTR [bx+si+0x3],al
    161d:	ba 1d 00             	mov    dx,0x1d
    1620:	b8 5d 01             	mov    ax,0x15d
    1623:	ea ed 24 36 16       	jmp    0x1636:0x24ed
    1628:	00 00                	add    BYTE PTR [bx+si],al
    162a:	00 41 03             	add    BYTE PTR [bx+di+0x3],al
    162d:	ba 1d 00             	mov    dx,0x1d
    1630:	b8 5e 01             	mov    ax,0x15e
    1633:	ea ed 24 46 16       	jmp    0x1646:0x24ed
    1638:	00 00                	add    BYTE PTR [bx+si],al
    163a:	00 48 03             	add    BYTE PTR [bx+si+0x3],cl
    163d:	ba 1d 00             	mov    dx,0x1d
    1640:	b8 5f 01             	mov    ax,0x15f
    1643:	ea ed 24 56 16       	jmp    0x1656:0x24ed
    1648:	00 00                	add    BYTE PTR [bx+si],al
    164a:	00 49 03             	add    BYTE PTR [bx+di+0x3],cl
    164d:	ba 1d 00             	mov    dx,0x1d
    1650:	b8 60 01             	mov    ax,0x160
    1653:	ea ed 24 66 16       	jmp    0x1666:0x24ed
    1658:	00 00                	add    BYTE PTR [bx+si],al
    165a:	00 4a 03             	add    BYTE PTR [bp+si+0x3],cl
    165d:	ba 1d 00             	mov    dx,0x1d
    1660:	b8 61 01             	mov    ax,0x161
    1663:	ea ed 24 76 16       	jmp    0x1676:0x24ed
    1668:	00 00                	add    BYTE PTR [bx+si],al
    166a:	00 4b 03             	add    BYTE PTR [bp+di+0x3],cl
    166d:	ba 1d 00             	mov    dx,0x1d
    1670:	b8 62 01             	mov    ax,0x162
    1673:	ea ed 24 86 16       	jmp    0x1686:0x24ed
    1678:	00 00                	add    BYTE PTR [bx+si],al
    167a:	00 4c 03             	add    BYTE PTR [si+0x3],cl
    167d:	ba 1d 00             	mov    dx,0x1d
    1680:	b8 63 01             	mov    ax,0x163
    1683:	ea ed 24 96 16       	jmp    0x1696:0x24ed
    1688:	00 00                	add    BYTE PTR [bx+si],al
    168a:	00 4d 03             	add    BYTE PTR [di+0x3],cl
    168d:	ba 1d 00             	mov    dx,0x1d
    1690:	b8 64 01             	mov    ax,0x164
    1693:	ea ed 24 a6 16       	jmp    0x16a6:0x24ed
    1698:	00 00                	add    BYTE PTR [bx+si],al
    169a:	00 52 03             	add    BYTE PTR [bp+si+0x3],dl
    169d:	ba 1d 00             	mov    dx,0x1d
    16a0:	b8 65 01             	mov    ax,0x165
    16a3:	ea ed 24 b6 16       	jmp    0x16b6:0x24ed
    16a8:	00 00                	add    BYTE PTR [bx+si],al
    16aa:	00 53 03             	add    BYTE PTR [bp+di+0x3],dl
    16ad:	ba 1d 00             	mov    dx,0x1d
    16b0:	b8 66 01             	mov    ax,0x166
    16b3:	ea ed 24 c6 16       	jmp    0x16c6:0x24ed
    16b8:	00 00                	add    BYTE PTR [bx+si],al
    16ba:	00 5c 03             	add    BYTE PTR [si+0x3],bl
    16bd:	ba 1d 00             	mov    dx,0x1d
    16c0:	b8 67 01             	mov    ax,0x167
    16c3:	ea ed 24 d6 16       	jmp    0x16d6:0x24ed
    16c8:	00 00                	add    BYTE PTR [bx+si],al
    16ca:	00 5d 03             	add    BYTE PTR [di+0x3],bl
    16cd:	ba 1d 00             	mov    dx,0x1d
    16d0:	b8 68 01             	mov    ax,0x168
    16d3:	ea ed 24 e6 16       	jmp    0x16e6:0x24ed
    16d8:	00 00                	add    BYTE PTR [bx+si],al
    16da:	00 5e 03             	add    BYTE PTR [bp+0x3],bl
    16dd:	ba 1d 00             	mov    dx,0x1d
    16e0:	b8 69 01             	mov    ax,0x169
    16e3:	ea ed 24 f6 16       	jmp    0x16f6:0x24ed
    16e8:	00 00                	add    BYTE PTR [bx+si],al
    16ea:	00 61 03             	add    BYTE PTR [bx+di+0x3],ah
    16ed:	ba 1d 00             	mov    dx,0x1d
    16f0:	b8 6a 01             	mov    ax,0x16a
    16f3:	ea ed 24 06 17       	jmp    0x1706:0x24ed
    16f8:	00 00                	add    BYTE PTR [bx+si],al
    16fa:	00 62 03             	add    BYTE PTR [bp+si+0x3],ah
    16fd:	ba 1d 00             	mov    dx,0x1d
    1700:	b8 6b 01             	mov    ax,0x16b
    1703:	ea ed 24 16 17       	jmp    0x1716:0x24ed
    1708:	00 00                	add    BYTE PTR [bx+si],al
    170a:	00 66 03             	add    BYTE PTR [bp+0x3],ah
    170d:	ba 1d 00             	mov    dx,0x1d
    1710:	b8 6c 01             	mov    ax,0x16c
    1713:	ea ed 24 26 17       	jmp    0x1726:0x24ed
    1718:	00 00                	add    BYTE PTR [bx+si],al
    171a:	00 67 03             	add    BYTE PTR [bx+0x3],ah
    171d:	ba 1d 00             	mov    dx,0x1d
    1720:	b8 6d 01             	mov    ax,0x16d
    1723:	ea ed 24 36 17       	jmp    0x1736:0x24ed
    1728:	00 00                	add    BYTE PTR [bx+si],al
    172a:	00 68 03             	add    BYTE PTR [bx+si+0x3],ch
    172d:	ba 1d 00             	mov    dx,0x1d
    1730:	b8 6e 01             	mov    ax,0x16e
    1733:	ea ed 24 46 17       	jmp    0x1746:0x24ed
    1738:	00 00                	add    BYTE PTR [bx+si],al
    173a:	00 69 03             	add    BYTE PTR [bx+di+0x3],ch
    173d:	ba 1d 00             	mov    dx,0x1d
    1740:	b8 6f 01             	mov    ax,0x16f
    1743:	ea ed 24 56 17       	jmp    0x1756:0x24ed
    1748:	00 00                	add    BYTE PTR [bx+si],al
    174a:	00 6c 03             	add    BYTE PTR [si+0x3],ch
    174d:	ba 1d 00             	mov    dx,0x1d
    1750:	b8 70 01             	mov    ax,0x170
    1753:	ea ed 24 66 17       	jmp    0x1766:0x24ed
    1758:	00 00                	add    BYTE PTR [bx+si],al
    175a:	00 6d 03             	add    BYTE PTR [di+0x3],ch
    175d:	ba 1d 00             	mov    dx,0x1d
    1760:	b8 71 01             	mov    ax,0x171
    1763:	ea ed 24 76 17       	jmp    0x1776:0x24ed
    1768:	00 00                	add    BYTE PTR [bx+si],al
    176a:	00 6e 03             	add    BYTE PTR [bp+0x3],ch
    176d:	ba 1d 00             	mov    dx,0x1d
    1770:	b8 72 01             	mov    ax,0x172
    1773:	ea ed 24 86 17       	jmp    0x1786:0x24ed
    1778:	00 00                	add    BYTE PTR [bx+si],al
    177a:	00 6f 03             	add    BYTE PTR [bx+0x3],ch
    177d:	ba 1d 00             	mov    dx,0x1d
    1780:	b8 73 01             	mov    ax,0x173
    1783:	ea ed 24 96 17       	jmp    0x1796:0x24ed
    1788:	00 00                	add    BYTE PTR [bx+si],al
    178a:	00 70 03             	add    BYTE PTR [bx+si+0x3],dh
    178d:	ba 1d 00             	mov    dx,0x1d
    1790:	b8 74 01             	mov    ax,0x174
    1793:	ea ed 24 a6 17       	jmp    0x17a6:0x24ed
    1798:	00 00                	add    BYTE PTR [bx+si],al
    179a:	00 73 03             	add    BYTE PTR [bp+di+0x3],dh
    179d:	ba 1d 00             	mov    dx,0x1d
    17a0:	b8 75 01             	mov    ax,0x175
    17a3:	ea ed 24 b6 17       	jmp    0x17b6:0x24ed
    17a8:	00 00                	add    BYTE PTR [bx+si],al
    17aa:	00 74 03             	add    BYTE PTR [si+0x3],dh
    17ad:	ba 1d 00             	mov    dx,0x1d
    17b0:	b8 76 01             	mov    ax,0x176
    17b3:	ea ed 24 c6 17       	jmp    0x17c6:0x24ed
    17b8:	00 00                	add    BYTE PTR [bx+si],al
    17ba:	00 75 03             	add    BYTE PTR [di+0x3],dh
    17bd:	ba 1d 00             	mov    dx,0x1d
    17c0:	b8 77 01             	mov    ax,0x177
    17c3:	ea ed 24 d6 17       	jmp    0x17d6:0x24ed
    17c8:	00 00                	add    BYTE PTR [bx+si],al
    17ca:	00 76 03             	add    BYTE PTR [bp+0x3],dh
    17cd:	ba 1d 00             	mov    dx,0x1d
    17d0:	b8 78 01             	mov    ax,0x178
    17d3:	ea ed 24 e6 17       	jmp    0x17e6:0x24ed
    17d8:	00 00                	add    BYTE PTR [bx+si],al
    17da:	00 77 03             	add    BYTE PTR [bx+0x3],dh
    17dd:	ba 1d 00             	mov    dx,0x1d
    17e0:	b8 79 01             	mov    ax,0x179
    17e3:	ea ed 24 f6 17       	jmp    0x17f6:0x24ed
    17e8:	00 00                	add    BYTE PTR [bx+si],al
    17ea:	00 78 03             	add    BYTE PTR [bx+si+0x3],bh
    17ed:	ba 1d 00             	mov    dx,0x1d
    17f0:	b8 7a 01             	mov    ax,0x17a
    17f3:	ea ed 24 06 18       	jmp    0x1806:0x24ed
    17f8:	00 00                	add    BYTE PTR [bx+si],al
    17fa:	00 79 03             	add    BYTE PTR [bx+di+0x3],bh
    17fd:	ba 1d 00             	mov    dx,0x1d
    1800:	b8 7b 01             	mov    ax,0x17b
    1803:	ea ed 24 16 18       	jmp    0x1816:0x24ed
    1808:	00 00                	add    BYTE PTR [bx+si],al
    180a:	00 7a 03             	add    BYTE PTR [bp+si+0x3],bh
    180d:	ba 1d 00             	mov    dx,0x1d
    1810:	b8 7c 01             	mov    ax,0x17c
    1813:	ea ed 24 26 18       	jmp    0x1826:0x24ed
    1818:	00 00                	add    BYTE PTR [bx+si],al
    181a:	00 7b 03             	add    BYTE PTR [bp+di+0x3],bh
    181d:	ba 1d 00             	mov    dx,0x1d
    1820:	b8 7d 01             	mov    ax,0x17d
    1823:	ea ed 24 36 18       	jmp    0x1836:0x24ed
    1828:	00 00                	add    BYTE PTR [bx+si],al
    182a:	00 7c 03             	add    BYTE PTR [si+0x3],bh
    182d:	ba 1d 00             	mov    dx,0x1d
    1830:	b8 7e 01             	mov    ax,0x17e
    1833:	ea ed 24 46 18       	jmp    0x1846:0x24ed
    1838:	00 00                	add    BYTE PTR [bx+si],al
    183a:	00 7d 03             	add    BYTE PTR [di+0x3],bh
    183d:	ba 1d 00             	mov    dx,0x1d
    1840:	b8 7f 01             	mov    ax,0x17f
    1843:	ea ed 24 56 18       	jmp    0x1856:0x24ed
    1848:	00 00                	add    BYTE PTR [bx+si],al
    184a:	00 7e 03             	add    BYTE PTR [bp+0x3],bh
    184d:	ba 1d 00             	mov    dx,0x1d
    1850:	b8 80 01             	mov    ax,0x180
    1853:	ea ed 24 66 18       	jmp    0x1866:0x24ed
    1858:	00 00                	add    BYTE PTR [bx+si],al
    185a:	00 7f 03             	add    BYTE PTR [bx+0x3],bh
    185d:	ba 1d 00             	mov    dx,0x1d
    1860:	b8 81 01             	mov    ax,0x181
    1863:	ea ed 24 76 18       	jmp    0x1876:0x24ed
    1868:	00 00                	add    BYTE PTR [bx+si],al
    186a:	00 8e 00 ba          	add    BYTE PTR [bp-0x4600],cl
    186e:	1d 00 b8             	sbb    ax,0xb800
    1871:	82 01 ea             	add    BYTE PTR [bx+di],0xea
    1874:	ed                   	in     ax,dx
    1875:	24 86                	and    al,0x86
    1877:	18 00                	sbb    BYTE PTR [bx+si],al
    1879:	00 00                	add    BYTE PTR [bx+si],al
    187b:	8f 00                	pop    WORD PTR [bx+si]
    187d:	ba 1d 00             	mov    dx,0x1d
    1880:	b8 83 01             	mov    ax,0x183
    1883:	ea ed 24 96 18       	jmp    0x1896:0x24ed
    1888:	00 00                	add    BYTE PTR [bx+si],al
    188a:	00 90 00 ba          	add    BYTE PTR [bx+si-0x4600],dl
    188e:	1d 00 b8             	sbb    ax,0xb800
    1891:	84 01                	test   BYTE PTR [bx+di],al
    1893:	ea ed 24 a6 18       	jmp    0x18a6:0x24ed
    1898:	00 00                	add    BYTE PTR [bx+si],al
    189a:	00 91 00 ba          	add    BYTE PTR [bx+di-0x4600],dl
    189e:	1d 00 b8             	sbb    ax,0xb800
    18a1:	85 01                	test   WORD PTR [bx+di],ax
    18a3:	ea ed 24 b6 18       	jmp    0x18b6:0x24ed
    18a8:	00 00                	add    BYTE PTR [bx+si],al
    18aa:	00 92 00 ba          	add    BYTE PTR [bp+si-0x4600],dl
    18ae:	1d 00 b8             	sbb    ax,0xb800
    18b1:	86 01                	xchg   BYTE PTR [bx+di],al
    18b3:	ea ed 24 c6 18       	jmp    0x18c6:0x24ed
    18b8:	00 00                	add    BYTE PTR [bx+si],al
    18ba:	00 93 00 ba          	add    BYTE PTR [bp+di-0x4600],dl
    18be:	1d 00 b8             	sbb    ax,0xb800
    18c1:	87 01                	xchg   WORD PTR [bx+di],ax
    18c3:	ea ed 24 d6 18       	jmp    0x18d6:0x24ed
    18c8:	00 00                	add    BYTE PTR [bx+si],al
    18ca:	00 94 00 ba          	add    BYTE PTR [si-0x4600],dl
    18ce:	1d 00 b8             	sbb    ax,0xb800
    18d1:	88 01                	mov    BYTE PTR [bx+di],al
    18d3:	ea ed 24 e6 18       	jmp    0x18e6:0x24ed
    18d8:	00 00                	add    BYTE PTR [bx+si],al
    18da:	00 86 03 ba          	add    BYTE PTR [bp-0x45fd],al
    18de:	1d 00 b8             	sbb    ax,0xb800
    18e1:	89 01                	mov    WORD PTR [bx+di],ax
    18e3:	ea ed 24 f6 18       	jmp    0x18f6:0x24ed
    18e8:	00 00                	add    BYTE PTR [bx+si],al
    18ea:	00 87 03 ba          	add    BYTE PTR [bx-0x45fd],al
    18ee:	1d 00 b8             	sbb    ax,0xb800
    18f1:	8a 01                	mov    al,BYTE PTR [bx+di]
    18f3:	ea ed 24 06 19       	jmp    0x1906:0x24ed
    18f8:	00 00                	add    BYTE PTR [bx+si],al
    18fa:	00 88 03 ba          	add    BYTE PTR [bx+si-0x45fd],cl
    18fe:	1d 00 b8             	sbb    ax,0xb800
    1901:	8b 01                	mov    ax,WORD PTR [bx+di]
    1903:	ea ed 24 16 19       	jmp    0x1916:0x24ed
    1908:	00 00                	add    BYTE PTR [bx+si],al
    190a:	00 89 03 ba          	add    BYTE PTR [bx+di-0x45fd],cl
    190e:	1d 00 b8             	sbb    ax,0xb800
    1911:	8c 01                	mov    WORD PTR [bx+di],es
    1913:	ea ed 24 26 19       	jmp    0x1926:0x24ed
    1918:	00 00                	add    BYTE PTR [bx+si],al
    191a:	00 8b 03 ba          	add    BYTE PTR [bp+di-0x45fd],cl
    191e:	1d 00 b8             	sbb    ax,0xb800
    1921:	8d 01                	lea    ax,[bx+di]
    1923:	ea ed 24 36 19       	jmp    0x1936:0x24ed
    1928:	00 00                	add    BYTE PTR [bx+si],al
    192a:	00 8c 03 ba          	add    BYTE PTR [si-0x45fd],cl
    192e:	1d 00 b8             	sbb    ax,0xb800
    1931:	8e 01                	mov    es,WORD PTR [bx+di]
    1933:	ea ed 24 46 19       	jmp    0x1946:0x24ed
    1938:	00 00                	add    BYTE PTR [bx+si],al
    193a:	00 8e 03 ba          	add    BYTE PTR [bp-0x45fd],cl
    193e:	1d 00 b8             	sbb    ax,0xb800
    1941:	8f 01                	pop    WORD PTR [bx+di]
    1943:	ea ed 24 56 19       	jmp    0x1956:0x24ed
    1948:	00 00                	add    BYTE PTR [bx+si],al
    194a:	00 8f 03 ba          	add    BYTE PTR [bx-0x45fd],cl
    194e:	1d 00 b8             	sbb    ax,0xb800
    1951:	90                   	nop
    1952:	01 ea                	add    dx,bp
    1954:	ed                   	in     ax,dx
    1955:	24 66                	and    al,0x66
    1957:	19 00                	sbb    WORD PTR [bx+si],ax
    1959:	00 00                	add    BYTE PTR [bx+si],al
    195b:	90                   	nop
    195c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1960:	b8 91 01             	mov    ax,0x191
    1963:	ea ed 24 76 19       	jmp    0x1976:0x24ed
    1968:	00 00                	add    BYTE PTR [bx+si],al
    196a:	00 91 03 ba          	add    BYTE PTR [bx+di-0x45fd],dl
    196e:	1d 00 b8             	sbb    ax,0xb800
    1971:	92                   	xchg   dx,ax
    1972:	01 ea                	add    dx,bp
    1974:	ed                   	in     ax,dx
    1975:	24 86                	and    al,0x86
    1977:	19 00                	sbb    WORD PTR [bx+si],ax
    1979:	00 00                	add    BYTE PTR [bx+si],al
    197b:	92                   	xchg   dx,ax
    197c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1980:	b8 93 01             	mov    ax,0x193
    1983:	ea ed 24 96 19       	jmp    0x1996:0x24ed
    1988:	00 00                	add    BYTE PTR [bx+si],al
    198a:	00 93 03 ba          	add    BYTE PTR [bp+di-0x45fd],dl
    198e:	1d 00 b8             	sbb    ax,0xb800
    1991:	94                   	xchg   sp,ax
    1992:	01 ea                	add    dx,bp
    1994:	ed                   	in     ax,dx
    1995:	24 a6                	and    al,0xa6
    1997:	19 00                	sbb    WORD PTR [bx+si],ax
    1999:	00 00                	add    BYTE PTR [bx+si],al
    199b:	94                   	xchg   sp,ax
    199c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    19a0:	b8 95 01             	mov    ax,0x195
    19a3:	ea ed 24 b6 19       	jmp    0x19b6:0x24ed
    19a8:	00 00                	add    BYTE PTR [bx+si],al
    19aa:	00 95 03 ba          	add    BYTE PTR [di-0x45fd],dl
    19ae:	1d 00 b8             	sbb    ax,0xb800
    19b1:	96                   	xchg   si,ax
    19b2:	01 ea                	add    dx,bp
    19b4:	ed                   	in     ax,dx
    19b5:	24 c6                	and    al,0xc6
    19b7:	19 00                	sbb    WORD PTR [bx+si],ax
    19b9:	00 00                	add    BYTE PTR [bx+si],al
    19bb:	96                   	xchg   si,ax
    19bc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    19c0:	b8 97 01             	mov    ax,0x197
    19c3:	ea ed 24 d6 19       	jmp    0x19d6:0x24ed
    19c8:	00 00                	add    BYTE PTR [bx+si],al
    19ca:	00 97 03 ba          	add    BYTE PTR [bx-0x45fd],dl
    19ce:	1d 00 b8             	sbb    ax,0xb800
    19d1:	98                   	cbw
    19d2:	01 ea                	add    dx,bp
    19d4:	ed                   	in     ax,dx
    19d5:	24 e6                	and    al,0xe6
    19d7:	19 00                	sbb    WORD PTR [bx+si],ax
    19d9:	00 00                	add    BYTE PTR [bx+si],al
    19db:	98                   	cbw
    19dc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    19e0:	b8 99 01             	mov    ax,0x199
    19e3:	ea ed 24 f6 19       	jmp    0x19f6:0x24ed
    19e8:	00 00                	add    BYTE PTR [bx+si],al
    19ea:	00 99 03 ba          	add    BYTE PTR [bx+di-0x45fd],bl
    19ee:	1d 00 b8             	sbb    ax,0xb800
    19f1:	9a 01 ea ed 24       	call   0x24ed:0xea01
    19f6:	06                   	push   es
    19f7:	1a 00                	sbb    al,BYTE PTR [bx+si]
    19f9:	00 00                	add    BYTE PTR [bx+si],al
    19fb:	9a 03 ba 1d 00       	call   0x1d:0xba03
    1a00:	b8 9b 01             	mov    ax,0x19b
    1a03:	ea ed 24 16 1a       	jmp    0x1a16:0x24ed
    1a08:	00 00                	add    BYTE PTR [bx+si],al
    1a0a:	00 9b 03 ba          	add    BYTE PTR [bp+di-0x45fd],bl
    1a0e:	1d 00 b8             	sbb    ax,0xb800
    1a11:	9c                   	pushf
    1a12:	01 ea                	add    dx,bp
    1a14:	ed                   	in     ax,dx
    1a15:	24 26                	and    al,0x26
    1a17:	1a 00                	sbb    al,BYTE PTR [bx+si]
    1a19:	00 00                	add    BYTE PTR [bx+si],al
    1a1b:	9c                   	pushf
    1a1c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1a20:	b8 9d 01             	mov    ax,0x19d
    1a23:	ea ed 24 36 1a       	jmp    0x1a36:0x24ed
    1a28:	00 00                	add    BYTE PTR [bx+si],al
    1a2a:	00 9d 03 ba          	add    BYTE PTR [di-0x45fd],bl
    1a2e:	1d 00 b8             	sbb    ax,0xb800
    1a31:	9e                   	sahf
    1a32:	01 ea                	add    dx,bp
    1a34:	ed                   	in     ax,dx
    1a35:	24 46                	and    al,0x46
    1a37:	1a 00                	sbb    al,BYTE PTR [bx+si]
    1a39:	00 00                	add    BYTE PTR [bx+si],al
    1a3b:	9e                   	sahf
    1a3c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1a40:	b8 9f 01             	mov    ax,0x19f
    1a43:	ea ed 24 56 1a       	jmp    0x1a56:0x24ed
    1a48:	00 00                	add    BYTE PTR [bx+si],al
    1a4a:	00 9f 03 ba          	add    BYTE PTR [bx-0x45fd],bl
    1a4e:	1d 00 b8             	sbb    ax,0xb800
    1a51:	a0 01 ea             	mov    al,ds:0xea01
    1a54:	ed                   	in     ax,dx
    1a55:	24 66                	and    al,0x66
    1a57:	1a 00                	sbb    al,BYTE PTR [bx+si]
    1a59:	00 00                	add    BYTE PTR [bx+si],al
    1a5b:	a0 03 ba             	mov    al,ds:0xba03
    1a5e:	1d 00 b8             	sbb    ax,0xb800
    1a61:	a1 01 ea             	mov    ax,ds:0xea01
    1a64:	ed                   	in     ax,dx
    1a65:	24 76                	and    al,0x76
    1a67:	1a 00                	sbb    al,BYTE PTR [bx+si]
    1a69:	00 00                	add    BYTE PTR [bx+si],al
    1a6b:	a1 03 ba             	mov    ax,ds:0xba03
    1a6e:	1d 00 b8             	sbb    ax,0xb800
    1a71:	a2 01 ea             	mov    ds:0xea01,al
    1a74:	ed                   	in     ax,dx
    1a75:	24 86                	and    al,0x86
    1a77:	1a 00                	sbb    al,BYTE PTR [bx+si]
    1a79:	00 00                	add    BYTE PTR [bx+si],al
    1a7b:	a2 03 ba             	mov    ds:0xba03,al
    1a7e:	1d 00 b8             	sbb    ax,0xb800
    1a81:	a3 01 ea             	mov    ds:0xea01,ax
    1a84:	ed                   	in     ax,dx
    1a85:	24 96                	and    al,0x96
    1a87:	1a 00                	sbb    al,BYTE PTR [bx+si]
    1a89:	00 00                	add    BYTE PTR [bx+si],al
    1a8b:	a3 03 ba             	mov    ds:0xba03,ax
    1a8e:	1d 00 b8             	sbb    ax,0xb800
    1a91:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1a92:	01 ea                	add    dx,bp
    1a94:	ed                   	in     ax,dx
    1a95:	24 a6                	and    al,0xa6
    1a97:	1a 00                	sbb    al,BYTE PTR [bx+si]
    1a99:	00 00                	add    BYTE PTR [bx+si],al
    1a9b:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1a9c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1aa0:	b8 a5 01             	mov    ax,0x1a5
    1aa3:	ea ed 24 b6 1a       	jmp    0x1ab6:0x24ed
    1aa8:	00 00                	add    BYTE PTR [bx+si],al
    1aaa:	00 a5 03 ba          	add    BYTE PTR [di-0x45fd],ah
    1aae:	1d 00 b8             	sbb    ax,0xb800
    1ab1:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    1ab2:	01 ea                	add    dx,bp
    1ab4:	ed                   	in     ax,dx
    1ab5:	24 c6                	and    al,0xc6
    1ab7:	1a 00                	sbb    al,BYTE PTR [bx+si]
    1ab9:	00 00                	add    BYTE PTR [bx+si],al
    1abb:	b6 03                	mov    dh,0x3
    1abd:	ba 1d 00             	mov    dx,0x1d
    1ac0:	b8 a7 01             	mov    ax,0x1a7
    1ac3:	ea ed 24 d6 1a       	jmp    0x1ad6:0x24ed
    1ac8:	00 00                	add    BYTE PTR [bx+si],al
    1aca:	00 b7 03 ba          	add    BYTE PTR [bx-0x45fd],dh
    1ace:	1d 00 b8             	sbb    ax,0xb800
    1ad1:	a8 01                	test   al,0x1
    1ad3:	ea ed 24 e6 1a       	jmp    0x1ae6:0x24ed
    1ad8:	00 00                	add    BYTE PTR [bx+si],al
    1ada:	00 b8 03 ba          	add    BYTE PTR [bx+si-0x45fd],bh
    1ade:	1d 00 b8             	sbb    ax,0xb800
    1ae1:	a9 01 ea             	test   ax,0xea01
    1ae4:	ed                   	in     ax,dx
    1ae5:	24 f6                	and    al,0xf6
    1ae7:	1a 00                	sbb    al,BYTE PTR [bx+si]
    1ae9:	00 00                	add    BYTE PTR [bx+si],al
    1aeb:	b9 03 ba             	mov    cx,0xba03
    1aee:	1d 00 b8             	sbb    ax,0xb800
    1af1:	aa                   	stos   BYTE PTR es:[di],al
    1af2:	01 ea                	add    dx,bp
    1af4:	ed                   	in     ax,dx
    1af5:	24 06                	and    al,0x6
    1af7:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1af9:	00 00                	add    BYTE PTR [bx+si],al
    1afb:	ba 03 ba             	mov    dx,0xba03
    1afe:	1d 00 b8             	sbb    ax,0xb800
    1b01:	ab                   	stos   WORD PTR es:[di],ax
    1b02:	01 ea                	add    dx,bp
    1b04:	ed                   	in     ax,dx
    1b05:	24 16                	and    al,0x16
    1b07:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1b09:	00 00                	add    BYTE PTR [bx+si],al
    1b0b:	bb 03 ba             	mov    bx,0xba03
    1b0e:	1d 00 b8             	sbb    ax,0xb800
    1b11:	ac                   	lods   al,BYTE PTR ds:[si]
    1b12:	01 ea                	add    dx,bp
    1b14:	ed                   	in     ax,dx
    1b15:	24 26                	and    al,0x26
    1b17:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1b19:	00 00                	add    BYTE PTR [bx+si],al
    1b1b:	bc 03 ba             	mov    sp,0xba03
    1b1e:	1d 00 b8             	sbb    ax,0xb800
    1b21:	ad                   	lods   ax,WORD PTR ds:[si]
    1b22:	01 ea                	add    dx,bp
    1b24:	ed                   	in     ax,dx
    1b25:	24 36                	and    al,0x36
    1b27:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1b29:	00 00                	add    BYTE PTR [bx+si],al
    1b2b:	bd 03 ba             	mov    bp,0xba03
    1b2e:	1d 00 b8             	sbb    ax,0xb800
    1b31:	ae                   	scas   al,BYTE PTR es:[di]
    1b32:	01 ea                	add    dx,bp
    1b34:	ed                   	in     ax,dx
    1b35:	24 46                	and    al,0x46
    1b37:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1b39:	00 00                	add    BYTE PTR [bx+si],al
    1b3b:	bf 03 ba             	mov    di,0xba03
    1b3e:	1d 00 b8             	sbb    ax,0xb800
    1b41:	af                   	scas   ax,WORD PTR es:[di]
    1b42:	01 ea                	add    dx,bp
    1b44:	ed                   	in     ax,dx
    1b45:	24 56                	and    al,0x56
    1b47:	1b 00                	sbb    ax,WORD PTR [bx+si]
    1b49:	00 00                	add    BYTE PTR [bx+si],al
    1b4b:	c0 03 ba             	rol    BYTE PTR [bp+di],0xba
    1b4e:	1d 00 b8             	sbb    ax,0xb800
    1b51:	b0 01                	mov    al,0x1
    1b53:	ea ed 24 66 1b       	jmp    0x1b66:0x24ed
    1b58:	00 00                	add    BYTE PTR [bx+si],al
    1b5a:	00 c1                	add    cl,al
    1b5c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1b60:	b8 b1 01             	mov    ax,0x1b1
    1b63:	ea ed 24 76 1b       	jmp    0x1b76:0x24ed
    1b68:	00 00                	add    BYTE PTR [bx+si],al
    1b6a:	00 c2                	add    dl,al
    1b6c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1b70:	b8 b2 01             	mov    ax,0x1b2
    1b73:	ea ed 24 86 1b       	jmp    0x1b86:0x24ed
    1b78:	00 00                	add    BYTE PTR [bx+si],al
    1b7a:	00 c3                	add    bl,al
    1b7c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1b80:	b8 b3 01             	mov    ax,0x1b3
    1b83:	ea ed 24 96 1b       	jmp    0x1b96:0x24ed
    1b88:	00 00                	add    BYTE PTR [bx+si],al
    1b8a:	00 c4                	add    ah,al
    1b8c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1b90:	b8 b4 01             	mov    ax,0x1b4
    1b93:	ea ed 24 a6 1b       	jmp    0x1ba6:0x24ed
    1b98:	00 00                	add    BYTE PTR [bx+si],al
    1b9a:	00 c6                	add    dh,al
    1b9c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1ba0:	b8 b5 01             	mov    ax,0x1b5
    1ba3:	ea ed 24 b6 1b       	jmp    0x1bb6:0x24ed
    1ba8:	00 00                	add    BYTE PTR [bx+si],al
    1baa:	00 c7                	add    bh,al
    1bac:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1bb0:	b8 b6 01             	mov    ax,0x1b6
    1bb3:	ea ed 24 c6 1b       	jmp    0x1bc6:0x24ed
    1bb8:	00 00                	add    BYTE PTR [bx+si],al
    1bba:	00 c8                	add    al,cl
    1bbc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1bc0:	b8 b7 01             	mov    ax,0x1b7
    1bc3:	ea ed 24 d6 1b       	jmp    0x1bd6:0x24ed
    1bc8:	00 00                	add    BYTE PTR [bx+si],al
    1bca:	00 c9                	add    cl,cl
    1bcc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1bd0:	b8 b8 01             	mov    ax,0x1b8
    1bd3:	ea ed 24 e6 1b       	jmp    0x1be6:0x24ed
    1bd8:	00 00                	add    BYTE PTR [bx+si],al
    1bda:	00 ca                	add    dl,cl
    1bdc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1be0:	b8 b9 01             	mov    ax,0x1b9
    1be3:	ea ed 24 f6 1b       	jmp    0x1bf6:0x24ed
    1be8:	00 00                	add    BYTE PTR [bx+si],al
    1bea:	00 cb                	add    bl,cl
    1bec:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1bf0:	b8 ba 01             	mov    ax,0x1ba
    1bf3:	ea ed 24 06 1c       	jmp    0x1c06:0x24ed
    1bf8:	00 00                	add    BYTE PTR [bx+si],al
    1bfa:	00 cc                	add    ah,cl
    1bfc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c00:	b8 bb 01             	mov    ax,0x1bb
    1c03:	ea ed 24 16 1c       	jmp    0x1c16:0x24ed
    1c08:	00 00                	add    BYTE PTR [bx+si],al
    1c0a:	00 cd                	add    ch,cl
    1c0c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c10:	b8 bc 01             	mov    ax,0x1bc
    1c13:	ea ed 24 26 1c       	jmp    0x1c26:0x24ed
    1c18:	00 00                	add    BYTE PTR [bx+si],al
    1c1a:	00 ce                	add    dh,cl
    1c1c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c20:	b8 bd 01             	mov    ax,0x1bd
    1c23:	ea ed 24 36 1c       	jmp    0x1c36:0x24ed
    1c28:	00 00                	add    BYTE PTR [bx+si],al
    1c2a:	00 cf                	add    bh,cl
    1c2c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c30:	b8 be 01             	mov    ax,0x1be
    1c33:	ea ed 24 46 1c       	jmp    0x1c46:0x24ed
    1c38:	00 00                	add    BYTE PTR [bx+si],al
    1c3a:	00 d0                	add    al,dl
    1c3c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c40:	b8 bf 01             	mov    ax,0x1bf
    1c43:	ea ed 24 56 1c       	jmp    0x1c56:0x24ed
    1c48:	00 00                	add    BYTE PTR [bx+si],al
    1c4a:	00 d1                	add    cl,dl
    1c4c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c50:	b8 c0 01             	mov    ax,0x1c0
    1c53:	ea ed 24 66 1c       	jmp    0x1c66:0x24ed
    1c58:	00 00                	add    BYTE PTR [bx+si],al
    1c5a:	00 d2                	add    dl,dl
    1c5c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c60:	b8 c1 01             	mov    ax,0x1c1
    1c63:	ea ed 24 76 1c       	jmp    0x1c76:0x24ed
    1c68:	00 00                	add    BYTE PTR [bx+si],al
    1c6a:	00 d3                	add    bl,dl
    1c6c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c70:	b8 c2 01             	mov    ax,0x1c2
    1c73:	ea ed 24 86 1c       	jmp    0x1c86:0x24ed
    1c78:	00 00                	add    BYTE PTR [bx+si],al
    1c7a:	00 d4                	add    ah,dl
    1c7c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c80:	b8 c3 01             	mov    ax,0x1c3
    1c83:	ea ed 24 96 1c       	jmp    0x1c96:0x24ed
    1c88:	00 00                	add    BYTE PTR [bx+si],al
    1c8a:	00 d5                	add    ch,dl
    1c8c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1c90:	b8 c4 01             	mov    ax,0x1c4
    1c93:	ea ed 24 a6 1c       	jmp    0x1ca6:0x24ed
    1c98:	00 00                	add    BYTE PTR [bx+si],al
    1c9a:	00 d6                	add    dh,dl
    1c9c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1ca0:	b8 c5 01             	mov    ax,0x1c5
    1ca3:	ea ed 24 b6 1c       	jmp    0x1cb6:0x24ed
    1ca8:	00 00                	add    BYTE PTR [bx+si],al
    1caa:	00 d7                	add    bh,dl
    1cac:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1cb0:	b8 c6 01             	mov    ax,0x1c6
    1cb3:	ea ed 24 c6 1c       	jmp    0x1cc6:0x24ed
    1cb8:	00 00                	add    BYTE PTR [bx+si],al
    1cba:	00 d8                	add    al,bl
    1cbc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1cc0:	b8 c7 01             	mov    ax,0x1c7
    1cc3:	ea ed 24 d6 1c       	jmp    0x1cd6:0x24ed
    1cc8:	00 00                	add    BYTE PTR [bx+si],al
    1cca:	00 d9                	add    cl,bl
    1ccc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1cd0:	b8 c8 01             	mov    ax,0x1c8
    1cd3:	ea ed 24 e6 1c       	jmp    0x1ce6:0x24ed
    1cd8:	00 00                	add    BYTE PTR [bx+si],al
    1cda:	00 da                	add    dl,bl
    1cdc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1ce0:	b8 c9 01             	mov    ax,0x1c9
    1ce3:	ea ed 24 f6 1c       	jmp    0x1cf6:0x24ed
    1ce8:	00 00                	add    BYTE PTR [bx+si],al
    1cea:	00 db                	add    bl,bl
    1cec:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1cf0:	b8 ca 01             	mov    ax,0x1ca
    1cf3:	ea ed 24 06 1d       	jmp    0x1d06:0x24ed
    1cf8:	00 00                	add    BYTE PTR [bx+si],al
    1cfa:	00 dc                	add    ah,bl
    1cfc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d00:	b8 cb 01             	mov    ax,0x1cb
    1d03:	ea ed 24 16 1d       	jmp    0x1d16:0x24ed
    1d08:	00 00                	add    BYTE PTR [bx+si],al
    1d0a:	00 dd                	add    ch,bl
    1d0c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d10:	b8 cc 01             	mov    ax,0x1cc
    1d13:	ea ed 24 26 1d       	jmp    0x1d26:0x24ed
    1d18:	00 00                	add    BYTE PTR [bx+si],al
    1d1a:	00 de                	add    dh,bl
    1d1c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d20:	b8 cd 01             	mov    ax,0x1cd
    1d23:	ea ed 24 36 1d       	jmp    0x1d36:0x24ed
    1d28:	00 00                	add    BYTE PTR [bx+si],al
    1d2a:	00 df                	add    bh,bl
    1d2c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d30:	b8 ce 01             	mov    ax,0x1ce
    1d33:	ea ed 24 46 1d       	jmp    0x1d46:0x24ed
    1d38:	00 00                	add    BYTE PTR [bx+si],al
    1d3a:	00 e0                	add    al,ah
    1d3c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d40:	b8 cf 01             	mov    ax,0x1cf
    1d43:	ea ed 24 56 1d       	jmp    0x1d56:0x24ed
    1d48:	00 00                	add    BYTE PTR [bx+si],al
    1d4a:	00 e1                	add    cl,ah
    1d4c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d50:	b8 d0 01             	mov    ax,0x1d0
    1d53:	ea ed 24 66 1d       	jmp    0x1d66:0x24ed
    1d58:	00 00                	add    BYTE PTR [bx+si],al
    1d5a:	00 e2                	add    dl,ah
    1d5c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d60:	b8 d1 01             	mov    ax,0x1d1
    1d63:	ea ed 24 76 1d       	jmp    0x1d76:0x24ed
    1d68:	00 00                	add    BYTE PTR [bx+si],al
    1d6a:	00 e3                	add    bl,ah
    1d6c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d70:	b8 d2 01             	mov    ax,0x1d2
    1d73:	ea ed 24 86 1d       	jmp    0x1d86:0x24ed
    1d78:	00 00                	add    BYTE PTR [bx+si],al
    1d7a:	00 e4                	add    ah,ah
    1d7c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d80:	b8 d3 01             	mov    ax,0x1d3
    1d83:	ea ed 24 96 1d       	jmp    0x1d96:0x24ed
    1d88:	00 00                	add    BYTE PTR [bx+si],al
    1d8a:	00 e5                	add    ch,ah
    1d8c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1d90:	b8 d4 01             	mov    ax,0x1d4
    1d93:	ea ed 24 a6 1d       	jmp    0x1da6:0x24ed
    1d98:	00 00                	add    BYTE PTR [bx+si],al
    1d9a:	00 e6                	add    dh,ah
    1d9c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1da0:	b8 d5 01             	mov    ax,0x1d5
    1da3:	ea ed 24 b6 1d       	jmp    0x1db6:0x24ed
    1da8:	00 00                	add    BYTE PTR [bx+si],al
    1daa:	00 e8                	add    al,ch
    1dac:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1db0:	b8 d6 01             	mov    ax,0x1d6
    1db3:	ea ed 24 c6 1d       	jmp    0x1dc6:0x24ed
    1db8:	00 00                	add    BYTE PTR [bx+si],al
    1dba:	00 e9                	add    cl,ch
    1dbc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1dc0:	b8 d7 01             	mov    ax,0x1d7
    1dc3:	ea ed 24 d6 1d       	jmp    0x1dd6:0x24ed
    1dc8:	00 00                	add    BYTE PTR [bx+si],al
    1dca:	00 ea                	add    dl,ch
    1dcc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1dd0:	b8 d8 01             	mov    ax,0x1d8
    1dd3:	ea ed 24 e6 1d       	jmp    0x1de6:0x24ed
    1dd8:	00 00                	add    BYTE PTR [bx+si],al
    1dda:	00 eb                	add    bl,ch
    1ddc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1de0:	b8 d9 01             	mov    ax,0x1d9
    1de3:	ea ed 24 f6 1d       	jmp    0x1df6:0x24ed
    1de8:	00 00                	add    BYTE PTR [bx+si],al
    1dea:	00 ed                	add    ch,ch
    1dec:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1df0:	b8 da 01             	mov    ax,0x1da
    1df3:	ea ed 24 06 1e       	jmp    0x1e06:0x24ed
    1df8:	00 00                	add    BYTE PTR [bx+si],al
    1dfa:	00 ee                	add    dh,ch
    1dfc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e00:	b8 db 01             	mov    ax,0x1db
    1e03:	ea ed 24 16 1e       	jmp    0x1e16:0x24ed
    1e08:	00 00                	add    BYTE PTR [bx+si],al
    1e0a:	00 ef                	add    bh,ch
    1e0c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e10:	b8 dc 01             	mov    ax,0x1dc
    1e13:	ea ed 24 26 1e       	jmp    0x1e26:0x24ed
    1e18:	00 00                	add    BYTE PTR [bx+si],al
    1e1a:	00 f0                	add    al,dh
    1e1c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e20:	b8 dd 01             	mov    ax,0x1dd
    1e23:	ea ed 24 36 1e       	jmp    0x1e36:0x24ed
    1e28:	00 00                	add    BYTE PTR [bx+si],al
    1e2a:	00 f1                	add    cl,dh
    1e2c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e30:	b8 de 01             	mov    ax,0x1de
    1e33:	ea ed 24 46 1e       	jmp    0x1e46:0x24ed
    1e38:	00 00                	add    BYTE PTR [bx+si],al
    1e3a:	00 f2                	add    dl,dh
    1e3c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e40:	b8 df 01             	mov    ax,0x1df
    1e43:	ea ed 24 56 1e       	jmp    0x1e56:0x24ed
    1e48:	00 00                	add    BYTE PTR [bx+si],al
    1e4a:	00 f3                	add    bl,dh
    1e4c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e50:	b8 e0 01             	mov    ax,0x1e0
    1e53:	ea ed 24 66 1e       	jmp    0x1e66:0x24ed
    1e58:	00 00                	add    BYTE PTR [bx+si],al
    1e5a:	00 f4                	add    ah,dh
    1e5c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e60:	b8 e1 01             	mov    ax,0x1e1
    1e63:	ea ed 24 76 1e       	jmp    0x1e76:0x24ed
    1e68:	00 00                	add    BYTE PTR [bx+si],al
    1e6a:	00 f5                	add    ch,dh
    1e6c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e70:	b8 e2 01             	mov    ax,0x1e2
    1e73:	ea ed 24 86 1e       	jmp    0x1e86:0x24ed
    1e78:	00 00                	add    BYTE PTR [bx+si],al
    1e7a:	00 f6                	add    dh,dh
    1e7c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e80:	b8 e3 01             	mov    ax,0x1e3
    1e83:	ea ed 24 96 1e       	jmp    0x1e96:0x24ed
    1e88:	00 00                	add    BYTE PTR [bx+si],al
    1e8a:	00 f7                	add    bh,dh
    1e8c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1e90:	b8 e4 01             	mov    ax,0x1e4
    1e93:	ea ed 24 a6 1e       	jmp    0x1ea6:0x24ed
    1e98:	00 00                	add    BYTE PTR [bx+si],al
    1e9a:	00 f8                	add    al,bh
    1e9c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1ea0:	b8 e5 01             	mov    ax,0x1e5
    1ea3:	ea ed 24 b6 1e       	jmp    0x1eb6:0x24ed
    1ea8:	00 00                	add    BYTE PTR [bx+si],al
    1eaa:	00 f9                	add    cl,bh
    1eac:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1eb0:	b8 e6 01             	mov    ax,0x1e6
    1eb3:	ea ed 24 c6 1e       	jmp    0x1ec6:0x24ed
    1eb8:	00 00                	add    BYTE PTR [bx+si],al
    1eba:	00 fa                	add    dl,bh
    1ebc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1ec0:	b8 e7 01             	mov    ax,0x1e7
    1ec3:	ea ed 24 d6 1e       	jmp    0x1ed6:0x24ed
    1ec8:	00 00                	add    BYTE PTR [bx+si],al
    1eca:	00 68 04             	add    BYTE PTR [bx+si+0x4],ch
    1ecd:	ba 1d 00             	mov    dx,0x1d
    1ed0:	b8 e8 01             	mov    ax,0x1e8
    1ed3:	ea ed 24 e6 1e       	jmp    0x1ee6:0x24ed
    1ed8:	00 00                	add    BYTE PTR [bx+si],al
    1eda:	00 fb                	add    bl,bh
    1edc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1ee0:	b8 e9 01             	mov    ax,0x1e9
    1ee3:	ea ed 24 f6 1e       	jmp    0x1ef6:0x24ed
    1ee8:	00 00                	add    BYTE PTR [bx+si],al
    1eea:	00 fc                	add    ah,bh
    1eec:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1ef0:	b8 ea 01             	mov    ax,0x1ea
    1ef3:	ea ed 24 06 1f       	jmp    0x1f06:0x24ed
    1ef8:	00 00                	add    BYTE PTR [bx+si],al
    1efa:	00 fd                	add    ch,bh
    1efc:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1f00:	b8 eb 01             	mov    ax,0x1eb
    1f03:	ea ed 24 16 1f       	jmp    0x1f16:0x24ed
    1f08:	00 00                	add    BYTE PTR [bx+si],al
    1f0a:	00 fe                	add    dh,bh
    1f0c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1f10:	b8 ec 01             	mov    ax,0x1ec
    1f13:	ea ed 24 26 1f       	jmp    0x1f26:0x24ed
    1f18:	00 00                	add    BYTE PTR [bx+si],al
    1f1a:	00 ff                	add    bh,bh
    1f1c:	03 ba 1d 00          	add    di,WORD PTR [bp+si+0x1d]
    1f20:	b8 ed 01             	mov    ax,0x1ed
    1f23:	ea ed 24 36 1f       	jmp    0x1f36:0x24ed
    1f28:	00 00                	add    BYTE PTR [bx+si],al
    1f2a:	00 00                	add    BYTE PTR [bx+si],al
    1f2c:	04 ba                	add    al,0xba
    1f2e:	1d 00 b8             	sbb    ax,0xb800
    1f31:	ee                   	out    dx,al
    1f32:	01 ea                	add    dx,bp
    1f34:	ed                   	in     ax,dx
    1f35:	24 46                	and    al,0x46
    1f37:	1f                   	pop    ds
    1f38:	00 00                	add    BYTE PTR [bx+si],al
    1f3a:	00 01                	add    BYTE PTR [bx+di],al
    1f3c:	04 ba                	add    al,0xba
    1f3e:	1d 00 b8             	sbb    ax,0xb800
    1f41:	ef                   	out    dx,ax
    1f42:	01 ea                	add    dx,bp
    1f44:	ed                   	in     ax,dx
    1f45:	24 56                	and    al,0x56
    1f47:	1f                   	pop    ds
    1f48:	00 00                	add    BYTE PTR [bx+si],al
    1f4a:	00 02                	add    BYTE PTR [bp+si],al
    1f4c:	04 ba                	add    al,0xba
    1f4e:	1d 00 b8             	sbb    ax,0xb800
    1f51:	f0 01 ea             	lock add dx,bp
    1f54:	ed                   	in     ax,dx
    1f55:	24 66                	and    al,0x66
    1f57:	1f                   	pop    ds
    1f58:	00 00                	add    BYTE PTR [bx+si],al
    1f5a:	00 03                	add    BYTE PTR [bp+di],al
    1f5c:	04 ba                	add    al,0xba
    1f5e:	1d 00 b8             	sbb    ax,0xb800
    1f61:	f1                   	int1
    1f62:	01 ea                	add    dx,bp
    1f64:	ed                   	in     ax,dx
    1f65:	24 76                	and    al,0x76
    1f67:	1f                   	pop    ds
    1f68:	00 00                	add    BYTE PTR [bx+si],al
    1f6a:	00 04                	add    BYTE PTR [si],al
    1f6c:	04 ba                	add    al,0xba
    1f6e:	1d 00 b8             	sbb    ax,0xb800
    1f71:	f2 01 ea             	repnz add dx,bp
    1f74:	ed                   	in     ax,dx
    1f75:	24 86                	and    al,0x86
    1f77:	1f                   	pop    ds
    1f78:	00 00                	add    BYTE PTR [bx+si],al
    1f7a:	00 05                	add    BYTE PTR [di],al
    1f7c:	04 ba                	add    al,0xba
    1f7e:	1d 00 b8             	sbb    ax,0xb800
    1f81:	f3 01 ea             	repz add dx,bp
    1f84:	ed                   	in     ax,dx
    1f85:	24 96                	and    al,0x96
    1f87:	1f                   	pop    ds
    1f88:	00 00                	add    BYTE PTR [bx+si],al
    1f8a:	00 06 04 ba          	add    BYTE PTR ds:0xba04,al
    1f8e:	1d 00 b8             	sbb    ax,0xb800
    1f91:	f4                   	hlt
    1f92:	01 ea                	add    dx,bp
    1f94:	ed                   	in     ax,dx
    1f95:	24 a6                	and    al,0xa6
    1f97:	1f                   	pop    ds
    1f98:	00 00                	add    BYTE PTR [bx+si],al
    1f9a:	00 07                	add    BYTE PTR [bx],al
    1f9c:	04 ba                	add    al,0xba
    1f9e:	1d 00 b8             	sbb    ax,0xb800
    1fa1:	f5                   	cmc
    1fa2:	01 ea                	add    dx,bp
    1fa4:	ed                   	in     ax,dx
    1fa5:	24 b6                	and    al,0xb6
    1fa7:	1f                   	pop    ds
    1fa8:	00 00                	add    BYTE PTR [bx+si],al
    1faa:	00 08                	add    BYTE PTR [bx+si],cl
    1fac:	04 ba                	add    al,0xba
    1fae:	1d 00 b8             	sbb    ax,0xb800
    1fb1:	f6 01 ea             	test   BYTE PTR [bx+di],0xea
    1fb4:	ed                   	in     ax,dx
    1fb5:	24 c6                	and    al,0xc6
    1fb7:	1f                   	pop    ds
    1fb8:	00 00                	add    BYTE PTR [bx+si],al
    1fba:	00 09                	add    BYTE PTR [bx+di],cl
    1fbc:	04 ba                	add    al,0xba
    1fbe:	1d 00 b8             	sbb    ax,0xb800
    1fc1:	f7 01 ea ed          	test   WORD PTR [bx+di],0xedea
    1fc5:	24 d6                	and    al,0xd6
    1fc7:	1f                   	pop    ds
    1fc8:	00 00                	add    BYTE PTR [bx+si],al
    1fca:	00 0a                	add    BYTE PTR [bp+si],cl
    1fcc:	04 ba                	add    al,0xba
    1fce:	1d 00 b8             	sbb    ax,0xb800
    1fd1:	f8                   	clc
    1fd2:	01 ea                	add    dx,bp
    1fd4:	ed                   	in     ax,dx
    1fd5:	24 e6                	and    al,0xe6
    1fd7:	1f                   	pop    ds
    1fd8:	00 00                	add    BYTE PTR [bx+si],al
    1fda:	00 10                	add    BYTE PTR [bx+si],dl
    1fdc:	04 ba                	add    al,0xba
    1fde:	1d 00 b8             	sbb    ax,0xb800
    1fe1:	f9                   	stc
    1fe2:	01 ea                	add    dx,bp
    1fe4:	ed                   	in     ax,dx
    1fe5:	24 f6                	and    al,0xf6
    1fe7:	1f                   	pop    ds
    1fe8:	00 00                	add    BYTE PTR [bx+si],al
    1fea:	00 11                	add    BYTE PTR [bx+di],dl
    1fec:	04 ba                	add    al,0xba
    1fee:	1d 00 b8             	sbb    ax,0xb800
    1ff1:	fa                   	cli
    1ff2:	01 ea                	add    dx,bp
    1ff4:	ed                   	in     ax,dx
    1ff5:	24 06                	and    al,0x6
    1ff7:	20 00                	and    BYTE PTR [bx+si],al
    1ff9:	00 00                	add    BYTE PTR [bx+si],al
    1ffb:	12 04                	adc    al,BYTE PTR [si]
    1ffd:	ba 1d 00             	mov    dx,0x1d
    2000:	b8 fb 01             	mov    ax,0x1fb
    2003:	ea ed 24 16 20       	jmp    0x2016:0x24ed
    2008:	00 00                	add    BYTE PTR [bx+si],al
    200a:	00 13                	add    BYTE PTR [bp+di],dl
    200c:	04 ba                	add    al,0xba
    200e:	1d 00 b8             	sbb    ax,0xb800
    2011:	fc                   	cld
    2012:	01 ea                	add    dx,bp
    2014:	ed                   	in     ax,dx
    2015:	24 26                	and    al,0x26
    2017:	20 00                	and    BYTE PTR [bx+si],al
    2019:	00 00                	add    BYTE PTR [bx+si],al
    201b:	14 04                	adc    al,0x4
    201d:	ba 1d 00             	mov    dx,0x1d
    2020:	b8 fd 01             	mov    ax,0x1fd
    2023:	ea ed 24 36 20       	jmp    0x2036:0x24ed
    2028:	00 00                	add    BYTE PTR [bx+si],al
    202a:	00 15                	add    BYTE PTR [di],dl
    202c:	04 ba                	add    al,0xba
    202e:	1d 00 b8             	sbb    ax,0xb800
    2031:	fe 01                	inc    BYTE PTR [bx+di]
    2033:	ea ed 24 46 20       	jmp    0x2046:0x24ed
    2038:	00 00                	add    BYTE PTR [bx+si],al
    203a:	00 16 04 ba          	add    BYTE PTR ds:0xba04,dl
    203e:	1d 00 b8             	sbb    ax,0xb800
    2041:	ff 01                	inc    WORD PTR [bx+di]
    2043:	ea ed 24 56 20       	jmp    0x2056:0x24ed
    2048:	00 00                	add    BYTE PTR [bx+si],al
    204a:	00 17                	add    BYTE PTR [bx],dl
    204c:	04 ba                	add    al,0xba
    204e:	1d 00 b8             	sbb    ax,0xb800
    2051:	00 02                	add    BYTE PTR [bp+si],al
    2053:	ea ed 24 66 20       	jmp    0x2066:0x24ed
    2058:	00 00                	add    BYTE PTR [bx+si],al
    205a:	00 18                	add    BYTE PTR [bx+si],bl
    205c:	04 ba                	add    al,0xba
    205e:	1d 00 b8             	sbb    ax,0xb800
    2061:	01 02                	add    WORD PTR [bp+si],ax
    2063:	ea ed 24 76 20       	jmp    0x2076:0x24ed
    2068:	00 00                	add    BYTE PTR [bx+si],al
    206a:	00 19                	add    BYTE PTR [bx+di],bl
    206c:	04 ba                	add    al,0xba
    206e:	1d 00 b8             	sbb    ax,0xb800
    2071:	02 02                	add    al,BYTE PTR [bp+si]
    2073:	ea ed 24 86 20       	jmp    0x2086:0x24ed
    2078:	00 00                	add    BYTE PTR [bx+si],al
    207a:	00 1a                	add    BYTE PTR [bp+si],bl
    207c:	04 ba                	add    al,0xba
    207e:	1d 00 b8             	sbb    ax,0xb800
    2081:	03 02                	add    ax,WORD PTR [bp+si]
    2083:	ea ed 24 96 20       	jmp    0x2096:0x24ed
    2088:	00 00                	add    BYTE PTR [bx+si],al
    208a:	00 1b                	add    BYTE PTR [bp+di],bl
    208c:	04 ba                	add    al,0xba
    208e:	1d 00 b8             	sbb    ax,0xb800
    2091:	04 02                	add    al,0x2
    2093:	ea ed 24 a6 20       	jmp    0x20a6:0x24ed
    2098:	00 00                	add    BYTE PTR [bx+si],al
    209a:	00 1d                	add    BYTE PTR [di],bl
    209c:	04 ba                	add    al,0xba
    209e:	1d 00 b8             	sbb    ax,0xb800
    20a1:	05 02 ea             	add    ax,0xea02
    20a4:	ed                   	in     ax,dx
    20a5:	24 b6                	and    al,0xb6
    20a7:	20 00                	and    BYTE PTR [bx+si],al
    20a9:	00 00                	add    BYTE PTR [bx+si],al
    20ab:	1e                   	push   ds
    20ac:	04 ba                	add    al,0xba
    20ae:	1d 00 b8             	sbb    ax,0xb800
    20b1:	06                   	push   es
    20b2:	02 ea                	add    ch,dl
    20b4:	ed                   	in     ax,dx
    20b5:	24 c6                	and    al,0xc6
    20b7:	20 00                	and    BYTE PTR [bx+si],al
    20b9:	00 00                	add    BYTE PTR [bx+si],al
    20bb:	1f                   	pop    ds
    20bc:	04 ba                	add    al,0xba
    20be:	1d 00 b8             	sbb    ax,0xb800
    20c1:	07                   	pop    es
    20c2:	02 ea                	add    ch,dl
    20c4:	ed                   	in     ax,dx
    20c5:	24 d6                	and    al,0xd6
    20c7:	20 00                	and    BYTE PTR [bx+si],al
    20c9:	00 00                	add    BYTE PTR [bx+si],al
    20cb:	20 04                	and    BYTE PTR [si],al
    20cd:	ba 1d 00             	mov    dx,0x1d
    20d0:	b8 08 02             	mov    ax,0x208
    20d3:	ea ed 24 e6 20       	jmp    0x20e6:0x24ed
    20d8:	00 00                	add    BYTE PTR [bx+si],al
    20da:	00 21                	add    BYTE PTR [bx+di],ah
    20dc:	04 ba                	add    al,0xba
    20de:	1d 00 b8             	sbb    ax,0xb800
    20e1:	09 02                	or     WORD PTR [bp+si],ax
    20e3:	ea ed 24 f6 20       	jmp    0x20f6:0x24ed
    20e8:	00 00                	add    BYTE PTR [bx+si],al
    20ea:	00 22                	add    BYTE PTR [bp+si],ah
    20ec:	04 ba                	add    al,0xba
    20ee:	1d 00 b8             	sbb    ax,0xb800
    20f1:	0a 02                	or     al,BYTE PTR [bp+si]
    20f3:	ea ed 24 06 21       	jmp    0x2106:0x24ed
    20f8:	00 00                	add    BYTE PTR [bx+si],al
    20fa:	00 23                	add    BYTE PTR [bp+di],ah
    20fc:	04 ba                	add    al,0xba
    20fe:	1d 00 b8             	sbb    ax,0xb800
    2101:	0b 02                	or     ax,WORD PTR [bp+si]
    2103:	ea ed 24 16 21       	jmp    0x2116:0x24ed
    2108:	00 00                	add    BYTE PTR [bx+si],al
    210a:	00 24                	add    BYTE PTR [si],ah
    210c:	04 ba                	add    al,0xba
    210e:	1d 00 b8             	sbb    ax,0xb800
    2111:	0c 02                	or     al,0x2
    2113:	ea ed 24 26 21       	jmp    0x2126:0x24ed
    2118:	00 00                	add    BYTE PTR [bx+si],al
    211a:	00 25                	add    BYTE PTR [di],ah
    211c:	04 ba                	add    al,0xba
    211e:	1d 00 b8             	sbb    ax,0xb800
    2121:	0d 02 ea             	or     ax,0xea02
    2124:	ed                   	in     ax,dx
    2125:	24 36                	and    al,0x36
    2127:	21 00                	and    WORD PTR [bx+si],ax
    2129:	00 00                	add    BYTE PTR [bx+si],al
    212b:	26 04 ba             	es add al,0xba
    212e:	1d 00 b8             	sbb    ax,0xb800
    2131:	0e                   	push   cs
    2132:	02 ea                	add    ch,dl
    2134:	ed                   	in     ax,dx
    2135:	24 46                	and    al,0x46
    2137:	21 00                	and    WORD PTR [bx+si],ax
    2139:	00 00                	add    BYTE PTR [bx+si],al
    213b:	27                   	daa
    213c:	04 ba                	add    al,0xba
    213e:	1d 00 b8             	sbb    ax,0xb800
    2141:	0f 02 ea             	lar    bp,dx
    2144:	ed                   	in     ax,dx
    2145:	24 56                	and    al,0x56
    2147:	21 00                	and    WORD PTR [bx+si],ax
    2149:	00 00                	add    BYTE PTR [bx+si],al
    214b:	28 04                	sub    BYTE PTR [si],al
    214d:	ba 1d 00             	mov    dx,0x1d
    2150:	b8 10 02             	mov    ax,0x210
    2153:	ea ed 24 66 21       	jmp    0x2166:0x24ed
    2158:	00 00                	add    BYTE PTR [bx+si],al
    215a:	00 29                	add    BYTE PTR [bx+di],ch
    215c:	04 ba                	add    al,0xba
    215e:	1d 00 b8             	sbb    ax,0xb800
    2161:	11 02                	adc    WORD PTR [bp+si],ax
    2163:	ea ed 24 76 21       	jmp    0x2176:0x24ed
    2168:	00 00                	add    BYTE PTR [bx+si],al
    216a:	00 2a                	add    BYTE PTR [bp+si],ch
    216c:	04 ba                	add    al,0xba
    216e:	1d 00 b8             	sbb    ax,0xb800
    2171:	12 02                	adc    al,BYTE PTR [bp+si]
    2173:	ea ed 24 86 21       	jmp    0x2186:0x24ed
    2178:	00 00                	add    BYTE PTR [bx+si],al
    217a:	00 2b                	add    BYTE PTR [bp+di],ch
    217c:	04 ba                	add    al,0xba
    217e:	1d 00 b8             	sbb    ax,0xb800
    2181:	13 02                	adc    ax,WORD PTR [bp+si]
    2183:	ea ed 24 96 21       	jmp    0x2196:0x24ed
    2188:	00 00                	add    BYTE PTR [bx+si],al
    218a:	00 2c                	add    BYTE PTR [si],ch
    218c:	04 ba                	add    al,0xba
    218e:	1d 00 b8             	sbb    ax,0xb800
    2191:	14 02                	adc    al,0x2
    2193:	ea ed 24 a6 21       	jmp    0x21a6:0x24ed
    2198:	00 00                	add    BYTE PTR [bx+si],al
    219a:	00 2d                	add    BYTE PTR [di],ch
    219c:	04 ba                	add    al,0xba
    219e:	1d 00 b8             	sbb    ax,0xb800
    21a1:	15 02 ea             	adc    ax,0xea02
    21a4:	ed                   	in     ax,dx
    21a5:	24 b6                	and    al,0xb6
    21a7:	21 00                	and    WORD PTR [bx+si],ax
    21a9:	00 00                	add    BYTE PTR [bx+si],al
    21ab:	2e 04 ba             	cs add al,0xba
    21ae:	1d 00 b8             	sbb    ax,0xb800
    21b1:	16                   	push   ss
    21b2:	02 ea                	add    ch,dl
    21b4:	ed                   	in     ax,dx
    21b5:	24 c6                	and    al,0xc6
    21b7:	21 00                	and    WORD PTR [bx+si],ax
    21b9:	00 00                	add    BYTE PTR [bx+si],al
    21bb:	2f                   	das
    21bc:	04 ba                	add    al,0xba
    21be:	1d 00 b8             	sbb    ax,0xb800
    21c1:	17                   	pop    ss
    21c2:	02 ea                	add    ch,dl
    21c4:	ed                   	in     ax,dx
    21c5:	24 d6                	and    al,0xd6
    21c7:	21 00                	and    WORD PTR [bx+si],ax
    21c9:	00 00                	add    BYTE PTR [bx+si],al
    21cb:	30 04                	xor    BYTE PTR [si],al
    21cd:	ba 1d 00             	mov    dx,0x1d
    21d0:	b8 18 02             	mov    ax,0x218
    21d3:	ea ed 24 e6 21       	jmp    0x21e6:0x24ed
    21d8:	00 00                	add    BYTE PTR [bx+si],al
    21da:	00 31                	add    BYTE PTR [bx+di],dh
    21dc:	04 ba                	add    al,0xba
    21de:	1d 00 b8             	sbb    ax,0xb800
    21e1:	19 02                	sbb    WORD PTR [bp+si],ax
    21e3:	ea ed 24 f6 21       	jmp    0x21f6:0x24ed
    21e8:	00 00                	add    BYTE PTR [bx+si],al
    21ea:	00 32                	add    BYTE PTR [bp+si],dh
    21ec:	04 ba                	add    al,0xba
    21ee:	1d 00 b8             	sbb    ax,0xb800
    21f1:	1a 02                	sbb    al,BYTE PTR [bp+si]
    21f3:	ea ed 24 06 22       	jmp    0x2206:0x24ed
    21f8:	00 00                	add    BYTE PTR [bx+si],al
    21fa:	00 33                	add    BYTE PTR [bp+di],dh
    21fc:	04 ba                	add    al,0xba
    21fe:	1d 00 b8             	sbb    ax,0xb800
    2201:	1b 02                	sbb    ax,WORD PTR [bp+si]
    2203:	ea ed 24 16 22       	jmp    0x2216:0x24ed
    2208:	00 00                	add    BYTE PTR [bx+si],al
    220a:	00 34                	add    BYTE PTR [si],dh
    220c:	04 ba                	add    al,0xba
    220e:	1d 00 b8             	sbb    ax,0xb800
    2211:	1c 02                	sbb    al,0x2
    2213:	ea ed 24 26 22       	jmp    0x2226:0x24ed
    2218:	00 00                	add    BYTE PTR [bx+si],al
    221a:	00 35                	add    BYTE PTR [di],dh
    221c:	04 ba                	add    al,0xba
    221e:	1d 00 b8             	sbb    ax,0xb800
    2221:	1d 02 ea             	sbb    ax,0xea02
    2224:	ed                   	in     ax,dx
    2225:	24 36                	and    al,0x36
    2227:	22 00                	and    al,BYTE PTR [bx+si]
    2229:	00 00                	add    BYTE PTR [bx+si],al
    222b:	36 04 ba             	ss add al,0xba
    222e:	1d 00 b8             	sbb    ax,0xb800
    2231:	1e                   	push   ds
    2232:	02 ea                	add    ch,dl
    2234:	ed                   	in     ax,dx
    2235:	24 46                	and    al,0x46
    2237:	22 00                	and    al,BYTE PTR [bx+si]
    2239:	00 00                	add    BYTE PTR [bx+si],al
    223b:	37                   	aaa
    223c:	04 ba                	add    al,0xba
    223e:	1d 00 b8             	sbb    ax,0xb800
    2241:	1f                   	pop    ds
    2242:	02 ea                	add    ch,dl
    2244:	ed                   	in     ax,dx
    2245:	24 56                	and    al,0x56
    2247:	22 00                	and    al,BYTE PTR [bx+si]
    2249:	00 00                	add    BYTE PTR [bx+si],al
    224b:	38 04                	cmp    BYTE PTR [si],al
    224d:	ba 1d 00             	mov    dx,0x1d
    2250:	b8 20 02             	mov    ax,0x220
    2253:	ea ed 24 66 22       	jmp    0x2266:0x24ed
    2258:	00 00                	add    BYTE PTR [bx+si],al
    225a:	00 39                	add    BYTE PTR [bx+di],bh
    225c:	04 ba                	add    al,0xba
    225e:	1d 00 b8             	sbb    ax,0xb800
    2261:	21 02                	and    WORD PTR [bp+si],ax
    2263:	ea ed 24 76 22       	jmp    0x2276:0x24ed
    2268:	00 00                	add    BYTE PTR [bx+si],al
    226a:	00 3a                	add    BYTE PTR [bp+si],bh
    226c:	04 ba                	add    al,0xba
    226e:	1d 00 b8             	sbb    ax,0xb800
    2271:	22 02                	and    al,BYTE PTR [bp+si]
    2273:	ea ed 24 86 22       	jmp    0x2286:0x24ed
    2278:	00 00                	add    BYTE PTR [bx+si],al
    227a:	00 3b                	add    BYTE PTR [bp+di],bh
    227c:	04 ba                	add    al,0xba
    227e:	1d 00 b8             	sbb    ax,0xb800
    2281:	23 02                	and    ax,WORD PTR [bp+si]
    2283:	ea ed 24 96 22       	jmp    0x2296:0x24ed
    2288:	00 00                	add    BYTE PTR [bx+si],al
    228a:	00 3c                	add    BYTE PTR [si],bh
    228c:	04 ba                	add    al,0xba
    228e:	1d 00 b8             	sbb    ax,0xb800
    2291:	24 02                	and    al,0x2
    2293:	ea ed 24 a6 22       	jmp    0x22a6:0x24ed
    2298:	00 00                	add    BYTE PTR [bx+si],al
    229a:	00 3d                	add    BYTE PTR [di],bh
    229c:	04 ba                	add    al,0xba
    229e:	1d 00 b8             	sbb    ax,0xb800
    22a1:	25 02 ea             	and    ax,0xea02
    22a4:	ed                   	in     ax,dx
    22a5:	24 b6                	and    al,0xb6
    22a7:	22 00                	and    al,BYTE PTR [bx+si]
    22a9:	00 00                	add    BYTE PTR [bx+si],al
    22ab:	3e 04 ba             	ds add al,0xba
    22ae:	1d 00 b8             	sbb    ax,0xb800
    22b1:	26 02 ea             	es add ch,dl
    22b4:	ed                   	in     ax,dx
    22b5:	24 c6                	and    al,0xc6
    22b7:	22 00                	and    al,BYTE PTR [bx+si]
    22b9:	00 00                	add    BYTE PTR [bx+si],al
    22bb:	3f                   	aas
    22bc:	04 ba                	add    al,0xba
    22be:	1d 00 b8             	sbb    ax,0xb800
    22c1:	27                   	daa
    22c2:	02 ea                	add    ch,dl
    22c4:	ed                   	in     ax,dx
    22c5:	24 d6                	and    al,0xd6
    22c7:	22 00                	and    al,BYTE PTR [bx+si]
    22c9:	00 00                	add    BYTE PTR [bx+si],al
    22cb:	40                   	inc    ax
    22cc:	04 ba                	add    al,0xba
    22ce:	1d 00 b8             	sbb    ax,0xb800
    22d1:	28 02                	sub    BYTE PTR [bp+si],al
    22d3:	ea ed 24 e6 22       	jmp    0x22e6:0x24ed
    22d8:	00 00                	add    BYTE PTR [bx+si],al
    22da:	00 41 04             	add    BYTE PTR [bx+di+0x4],al
    22dd:	ba 1d 00             	mov    dx,0x1d
    22e0:	b8 29 02             	mov    ax,0x229
    22e3:	ea ed 24 f6 22       	jmp    0x22f6:0x24ed
    22e8:	00 00                	add    BYTE PTR [bx+si],al
    22ea:	00 42 04             	add    BYTE PTR [bp+si+0x4],al
    22ed:	ba 1d 00             	mov    dx,0x1d
    22f0:	b8 2a 02             	mov    ax,0x22a
    22f3:	ea ed 24 06 23       	jmp    0x2306:0x24ed
    22f8:	00 00                	add    BYTE PTR [bx+si],al
    22fa:	00 43 04             	add    BYTE PTR [bp+di+0x4],al
    22fd:	ba 1d 00             	mov    dx,0x1d
    2300:	b8 2b 02             	mov    ax,0x22b
    2303:	ea ed 24 16 23       	jmp    0x2316:0x24ed
    2308:	00 00                	add    BYTE PTR [bx+si],al
    230a:	00 44 04             	add    BYTE PTR [si+0x4],al
    230d:	ba 1d 00             	mov    dx,0x1d
    2310:	b8 2c 02             	mov    ax,0x22c
    2313:	ea ed 24 26 23       	jmp    0x2326:0x24ed
    2318:	00 00                	add    BYTE PTR [bx+si],al
    231a:	00 45 04             	add    BYTE PTR [di+0x4],al
    231d:	ba 1d 00             	mov    dx,0x1d
    2320:	b8 2d 02             	mov    ax,0x22d
    2323:	ea ed 24 36 23       	jmp    0x2336:0x24ed
    2328:	00 00                	add    BYTE PTR [bx+si],al
    232a:	00 46 04             	add    BYTE PTR [bp+0x4],al
    232d:	ba 1d 00             	mov    dx,0x1d
    2330:	b8 2e 02             	mov    ax,0x22e
    2333:	ea ed 24 46 23       	jmp    0x2346:0x24ed
    2338:	00 00                	add    BYTE PTR [bx+si],al
    233a:	00 47 04             	add    BYTE PTR [bx+0x4],al
    233d:	ba 1d 00             	mov    dx,0x1d
    2340:	b8 2f 02             	mov    ax,0x22f
    2343:	ea ed 24 56 23       	jmp    0x2356:0x24ed
    2348:	00 00                	add    BYTE PTR [bx+si],al
    234a:	00 48 04             	add    BYTE PTR [bx+si+0x4],cl
    234d:	ba 1d 00             	mov    dx,0x1d
    2350:	b8 30 02             	mov    ax,0x230
    2353:	ea ed 24 66 23       	jmp    0x2366:0x24ed
    2358:	00 00                	add    BYTE PTR [bx+si],al
    235a:	00 49 04             	add    BYTE PTR [bx+di+0x4],cl
    235d:	ba 1d 00             	mov    dx,0x1d
    2360:	b8 31 02             	mov    ax,0x231
    2363:	ea ed 24 76 23       	jmp    0x2376:0x24ed
    2368:	00 00                	add    BYTE PTR [bx+si],al
    236a:	00 4a 04             	add    BYTE PTR [bp+si+0x4],cl
    236d:	ba 1d 00             	mov    dx,0x1d
    2370:	b8 32 02             	mov    ax,0x232
    2373:	ea ed 24 86 23       	jmp    0x2386:0x24ed
    2378:	00 00                	add    BYTE PTR [bx+si],al
    237a:	00 4b 04             	add    BYTE PTR [bp+di+0x4],cl
    237d:	ba 1d 00             	mov    dx,0x1d
    2380:	b8 33 02             	mov    ax,0x233
    2383:	ea ed 24 96 23       	jmp    0x2396:0x24ed
    2388:	00 00                	add    BYTE PTR [bx+si],al
    238a:	00 4c 04             	add    BYTE PTR [si+0x4],cl
    238d:	ba 1d 00             	mov    dx,0x1d
    2390:	b8 34 02             	mov    ax,0x234
    2393:	ea ed 24 a6 23       	jmp    0x23a6:0x24ed
    2398:	00 00                	add    BYTE PTR [bx+si],al
    239a:	00 4d 04             	add    BYTE PTR [di+0x4],cl
    239d:	ba 1d 00             	mov    dx,0x1d
    23a0:	b8 35 02             	mov    ax,0x235
    23a3:	ea ed 24 b6 23       	jmp    0x23b6:0x24ed
    23a8:	00 00                	add    BYTE PTR [bx+si],al
    23aa:	00 4e 04             	add    BYTE PTR [bp+0x4],cl
    23ad:	ba 1d 00             	mov    dx,0x1d
    23b0:	b8 36 02             	mov    ax,0x236
    23b3:	ea ed 24 c6 23       	jmp    0x23c6:0x24ed
    23b8:	00 00                	add    BYTE PTR [bx+si],al
    23ba:	00 4f 04             	add    BYTE PTR [bx+0x4],cl
    23bd:	ba 1d 00             	mov    dx,0x1d
    23c0:	b8 37 02             	mov    ax,0x237
    23c3:	ea ed 24 d6 23       	jmp    0x23d6:0x24ed
    23c8:	00 00                	add    BYTE PTR [bx+si],al
    23ca:	00 51 04             	add    BYTE PTR [bx+di+0x4],dl
    23cd:	ba 1d 00             	mov    dx,0x1d
    23d0:	b8 38 02             	mov    ax,0x238
    23d3:	ea ed 24 e6 23       	jmp    0x23e6:0x24ed
    23d8:	00 00                	add    BYTE PTR [bx+si],al
    23da:	00 52 04             	add    BYTE PTR [bp+si+0x4],dl
    23dd:	ba 1d 00             	mov    dx,0x1d
    23e0:	b8 39 02             	mov    ax,0x239
    23e3:	ea ed 24 f6 23       	jmp    0x23f6:0x24ed
    23e8:	00 00                	add    BYTE PTR [bx+si],al
    23ea:	00 53 04             	add    BYTE PTR [bp+di+0x4],dl
    23ed:	ba 1d 00             	mov    dx,0x1d
    23f0:	b8 3a 02             	mov    ax,0x23a
    23f3:	ea ed 24 06 24       	jmp    0x2406:0x24ed
    23f8:	00 00                	add    BYTE PTR [bx+si],al
    23fa:	00 54 04             	add    BYTE PTR [si+0x4],dl
    23fd:	ba 1d 00             	mov    dx,0x1d
    2400:	b8 3b 02             	mov    ax,0x23b
    2403:	ea ed 24 16 24       	jmp    0x2416:0x24ed
    2408:	00 00                	add    BYTE PTR [bx+si],al
    240a:	00 56 04             	add    BYTE PTR [bp+0x4],dl
    240d:	ba 1d 00             	mov    dx,0x1d
    2410:	b8 3c 02             	mov    ax,0x23c
    2413:	ea ed 24 26 24       	jmp    0x2426:0x24ed
    2418:	00 00                	add    BYTE PTR [bx+si],al
    241a:	00 59 04             	add    BYTE PTR [bx+di+0x4],bl
    241d:	ba 1d 00             	mov    dx,0x1d
    2420:	b8 3d 02             	mov    ax,0x23d
    2423:	ea ed 24 36 24       	jmp    0x2436:0x24ed
    2428:	00 00                	add    BYTE PTR [bx+si],al
    242a:	00 5a 04             	add    BYTE PTR [bp+si+0x4],bl
    242d:	ba 1d 00             	mov    dx,0x1d
    2430:	b8 3e 02             	mov    ax,0x23e
    2433:	ea ed 24 46 24       	jmp    0x2446:0x24ed
    2438:	00 00                	add    BYTE PTR [bx+si],al
    243a:	00 5d 04             	add    BYTE PTR [di+0x4],bl
    243d:	ba 1d 00             	mov    dx,0x1d
    2440:	b8 3f 02             	mov    ax,0x23f
    2443:	ea ed 24 56 24       	jmp    0x2456:0x24ed
    2448:	00 00                	add    BYTE PTR [bx+si],al
    244a:	00 5e 04             	add    BYTE PTR [bp+0x4],bl
    244d:	ba 1d 00             	mov    dx,0x1d
    2450:	b8 40 02             	mov    ax,0x240
    2453:	ea ed 24 66 24       	jmp    0x2466:0x24ed
    2458:	00 00                	add    BYTE PTR [bx+si],al
    245a:	00 5f 04             	add    BYTE PTR [bx+0x4],bl
    245d:	ba 1d 00             	mov    dx,0x1d
    2460:	b8 41 02             	mov    ax,0x241
    2463:	ea ed 24 76 24       	jmp    0x2476:0x24ed
    2468:	00 00                	add    BYTE PTR [bx+si],al
    246a:	00 60 04             	add    BYTE PTR [bx+si+0x4],ah
    246d:	ba 1d 00             	mov    dx,0x1d
    2470:	b8 42 02             	mov    ax,0x242
    2473:	ea ed 24 86 24       	jmp    0x2486:0x24ed
    2478:	00 00                	add    BYTE PTR [bx+si],al
    247a:	00 61 04             	add    BYTE PTR [bx+di+0x4],ah
    247d:	ba 1d 00             	mov    dx,0x1d
    2480:	b8 43 02             	mov    ax,0x243
    2483:	ea ed 24 96 24       	jmp    0x2496:0x24ed
    2488:	00 00                	add    BYTE PTR [bx+si],al
    248a:	00 62 04             	add    BYTE PTR [bp+si+0x4],ah
    248d:	ba 1d 00             	mov    dx,0x1d
    2490:	b8 44 02             	mov    ax,0x244
    2493:	ea ed 24 a6 24       	jmp    0x24a6:0x24ed
    2498:	00 00                	add    BYTE PTR [bx+si],al
    249a:	00 63 04             	add    BYTE PTR [bp+di+0x4],ah
    249d:	ba 1d 00             	mov    dx,0x1d
    24a0:	b8 45 02             	mov    ax,0x245
    24a3:	ea ed 24 b6 24       	jmp    0x24b6:0x24ed
    24a8:	00 00                	add    BYTE PTR [bx+si],al
    24aa:	00 64 04             	add    BYTE PTR [si+0x4],ah
    24ad:	ba 1d 00             	mov    dx,0x1d
    24b0:	b8 46 02             	mov    ax,0x246
    24b3:	ea ed 24 c6 24       	jmp    0x24c6:0x24ed
    24b8:	00 00                	add    BYTE PTR [bx+si],al
    24ba:	00 65 04             	add    BYTE PTR [di+0x4],ah
    24bd:	ba 1d 00             	mov    dx,0x1d
    24c0:	b8 47 02             	mov    ax,0x247
    24c3:	ea ed 24 d6 24       	jmp    0x24d6:0x24ed
    24c8:	00 00                	add    BYTE PTR [bx+si],al
    24ca:	00 66 04             	add    BYTE PTR [bp+0x4],ah
    24cd:	ba 1d 00             	mov    dx,0x1d
    24d0:	b8 48 02             	mov    ax,0x248
    24d3:	ea ed 24 e6 24       	jmp    0x24e6:0x24ed
    24d8:	00 00                	add    BYTE PTR [bx+si],al
    24da:	00 67 04             	add    BYTE PTR [bx+0x4],ah
    24dd:	ba 1d 00             	mov    dx,0x1d
    24e0:	b8 49 02             	mov    ax,0x249
    24e3:	ea ed 24 76 2c       	jmp    0x2c76:0x24ed
    24e8:	00 00                	add    BYTE PTR [bx+si],al
    24ea:	00 69 04             	add    BYTE PTR [bx+di+0x4],ch
    24ed:	0e                   	push   cs
    24ee:	52                   	push   dx
    24ef:	50                   	push   ax
    24f0:	e8 ba 08             	call   0x2dad
    24f3:	0b d2                	or     dx,dx
    24f5:	74 02                	je     0x24f9
    24f7:	52                   	push   dx
    24f8:	50                   	push   ax
    24f9:	cb                   	retf
    24fa:	00 00                	add    BYTE PTR [bx+si],al
    24fc:	00 00                	add    BYTE PTR [bx+si],al
    24fe:	20 20                	and    BYTE PTR [bx+si],ah
    2500:	20 20                	and    BYTE PTR [bx+si],ah
    2502:	20 20                	and    BYTE PTR [bx+si],ah
    2504:	20 20                	and    BYTE PTR [bx+si],ah
    2506:	20 20                	and    BYTE PTR [bx+si],ah
    2508:	20 20                	and    BYTE PTR [bx+si],ah
    250a:	20 20                	and    BYTE PTR [bx+si],ah
    250c:	20 20                	and    BYTE PTR [bx+si],ah
    250e:	20 20                	and    BYTE PTR [bx+si],ah
    2510:	20 20                	and    BYTE PTR [bx+si],ah
    2512:	20 20                	and    BYTE PTR [bx+si],ah
    2514:	20 20                	and    BYTE PTR [bx+si],ah
    2516:	20 20                	and    BYTE PTR [bx+si],ah
    2518:	20 20                	and    BYTE PTR [bx+si],ah
    251a:	20 20                	and    BYTE PTR [bx+si],ah
    251c:	20 20                	and    BYTE PTR [bx+si],ah
    251e:	20 20                	and    BYTE PTR [bx+si],ah
    2520:	20 20                	and    BYTE PTR [bx+si],ah
    2522:	20 20                	and    BYTE PTR [bx+si],ah
    2524:	20 20                	and    BYTE PTR [bx+si],ah
    2526:	20 20                	and    BYTE PTR [bx+si],ah
    2528:	20 20                	and    BYTE PTR [bx+si],ah
    252a:	20 20                	and    BYTE PTR [bx+si],ah
    252c:	20 20                	and    BYTE PTR [bx+si],ah
    252e:	20 20                	and    BYTE PTR [bx+si],ah
    2530:	20 20                	and    BYTE PTR [bx+si],ah
    2532:	20 20                	and    BYTE PTR [bx+si],ah
    2534:	20 20                	and    BYTE PTR [bx+si],ah
    2536:	20 20                	and    BYTE PTR [bx+si],ah
    2538:	20 20                	and    BYTE PTR [bx+si],ah
    253a:	20 20                	and    BYTE PTR [bx+si],ah
    253c:	20 20                	and    BYTE PTR [bx+si],ah
    253e:	20 20                	and    BYTE PTR [bx+si],ah
    2540:	20 20                	and    BYTE PTR [bx+si],ah
    2542:	20 20                	and    BYTE PTR [bx+si],ah
    2544:	20 20                	and    BYTE PTR [bx+si],ah
    2546:	20 20                	and    BYTE PTR [bx+si],ah
    2548:	20 20                	and    BYTE PTR [bx+si],ah
    254a:	20 20                	and    BYTE PTR [bx+si],ah
    254c:	20 20                	and    BYTE PTR [bx+si],ah
    254e:	20 20                	and    BYTE PTR [bx+si],ah
    2550:	20 20                	and    BYTE PTR [bx+si],ah
    2552:	20 20                	and    BYTE PTR [bx+si],ah
    2554:	20 20                	and    BYTE PTR [bx+si],ah
    2556:	20 20                	and    BYTE PTR [bx+si],ah
    2558:	20 20                	and    BYTE PTR [bx+si],ah
    255a:	20 20                	and    BYTE PTR [bx+si],ah
    255c:	20 20                	and    BYTE PTR [bx+si],ah
    255e:	20 20                	and    BYTE PTR [bx+si],ah
    2560:	20 20                	and    BYTE PTR [bx+si],ah
    2562:	20 20                	and    BYTE PTR [bx+si],ah
    2564:	20 20                	and    BYTE PTR [bx+si],ah
    2566:	20 20                	and    BYTE PTR [bx+si],ah
    2568:	20 20                	and    BYTE PTR [bx+si],ah
    256a:	20 20                	and    BYTE PTR [bx+si],ah
    256c:	20 20                	and    BYTE PTR [bx+si],ah
    256e:	20 20                	and    BYTE PTR [bx+si],ah
    2570:	20 20                	and    BYTE PTR [bx+si],ah
    2572:	20 20                	and    BYTE PTR [bx+si],ah
    2574:	20 20                	and    BYTE PTR [bx+si],ah
    2576:	20 20                	and    BYTE PTR [bx+si],ah
    2578:	20 20                	and    BYTE PTR [bx+si],ah
    257a:	20 20                	and    BYTE PTR [bx+si],ah
    257c:	20 20                	and    BYTE PTR [bx+si],ah
    257e:	20 20                	and    BYTE PTR [bx+si],ah
    2580:	20 20                	and    BYTE PTR [bx+si],ah
    2582:	20 20                	and    BYTE PTR [bx+si],ah
    2584:	20 20                	and    BYTE PTR [bx+si],ah
    2586:	20 20                	and    BYTE PTR [bx+si],ah
    2588:	20 20                	and    BYTE PTR [bx+si],ah
    258a:	20 20                	and    BYTE PTR [bx+si],ah
    258c:	20 20                	and    BYTE PTR [bx+si],ah
    258e:	20 20                	and    BYTE PTR [bx+si],ah
    2590:	20 20                	and    BYTE PTR [bx+si],ah
    2592:	20 20                	and    BYTE PTR [bx+si],ah
    2594:	20 20                	and    BYTE PTR [bx+si],ah
    2596:	20 20                	and    BYTE PTR [bx+si],ah
    2598:	20 20                	and    BYTE PTR [bx+si],ah
    259a:	20 20                	and    BYTE PTR [bx+si],ah
    259c:	20 20                	and    BYTE PTR [bx+si],ah
    259e:	20 20                	and    BYTE PTR [bx+si],ah
    25a0:	20 20                	and    BYTE PTR [bx+si],ah
    25a2:	20 20                	and    BYTE PTR [bx+si],ah
    25a4:	20 20                	and    BYTE PTR [bx+si],ah
    25a6:	20 20                	and    BYTE PTR [bx+si],ah
    25a8:	20 20                	and    BYTE PTR [bx+si],ah
    25aa:	20 20                	and    BYTE PTR [bx+si],ah
    25ac:	20 20                	and    BYTE PTR [bx+si],ah
    25ae:	20 20                	and    BYTE PTR [bx+si],ah
    25b0:	20 20                	and    BYTE PTR [bx+si],ah
    25b2:	20 20                	and    BYTE PTR [bx+si],ah
    25b4:	20 20                	and    BYTE PTR [bx+si],ah
    25b6:	20 20                	and    BYTE PTR [bx+si],ah
    25b8:	20 20                	and    BYTE PTR [bx+si],ah
    25ba:	20 20                	and    BYTE PTR [bx+si],ah
    25bc:	20 20                	and    BYTE PTR [bx+si],ah
    25be:	20 20                	and    BYTE PTR [bx+si],ah
    25c0:	20 20                	and    BYTE PTR [bx+si],ah
    25c2:	20 20                	and    BYTE PTR [bx+si],ah
    25c4:	20 20                	and    BYTE PTR [bx+si],ah
    25c6:	20 20                	and    BYTE PTR [bx+si],ah
    25c8:	20 20                	and    BYTE PTR [bx+si],ah
    25ca:	20 20                	and    BYTE PTR [bx+si],ah
    25cc:	20 20                	and    BYTE PTR [bx+si],ah
    25ce:	20 20                	and    BYTE PTR [bx+si],ah
    25d0:	20 20                	and    BYTE PTR [bx+si],ah
    25d2:	20 20                	and    BYTE PTR [bx+si],ah
    25d4:	20 20                	and    BYTE PTR [bx+si],ah
    25d6:	20 20                	and    BYTE PTR [bx+si],ah
    25d8:	20 20                	and    BYTE PTR [bx+si],ah
    25da:	20 20                	and    BYTE PTR [bx+si],ah
    25dc:	20 20                	and    BYTE PTR [bx+si],ah
    25de:	20 20                	and    BYTE PTR [bx+si],ah
    25e0:	20 20                	and    BYTE PTR [bx+si],ah
    25e2:	20 20                	and    BYTE PTR [bx+si],ah
    25e4:	20 20                	and    BYTE PTR [bx+si],ah
    25e6:	20 20                	and    BYTE PTR [bx+si],ah
    25e8:	20 20                	and    BYTE PTR [bx+si],ah
    25ea:	20 20                	and    BYTE PTR [bx+si],ah
    25ec:	20 20                	and    BYTE PTR [bx+si],ah
    25ee:	20 20                	and    BYTE PTR [bx+si],ah
    25f0:	20 20                	and    BYTE PTR [bx+si],ah
    25f2:	20 20                	and    BYTE PTR [bx+si],ah
    25f4:	20 20                	and    BYTE PTR [bx+si],ah
    25f6:	20 20                	and    BYTE PTR [bx+si],ah
    25f8:	20 20                	and    BYTE PTR [bx+si],ah
    25fa:	20 20                	and    BYTE PTR [bx+si],ah
    25fc:	20 20                	and    BYTE PTR [bx+si],ah
    25fe:	20 20                	and    BYTE PTR [bx+si],ah
    2600:	20 20                	and    BYTE PTR [bx+si],ah
    2602:	20 20                	and    BYTE PTR [bx+si],ah
    2604:	20 20                	and    BYTE PTR [bx+si],ah
    2606:	20 20                	and    BYTE PTR [bx+si],ah
    2608:	20 20                	and    BYTE PTR [bx+si],ah
    260a:	20 20                	and    BYTE PTR [bx+si],ah
    260c:	20 20                	and    BYTE PTR [bx+si],ah
    260e:	20 20                	and    BYTE PTR [bx+si],ah
    2610:	20 20                	and    BYTE PTR [bx+si],ah
    2612:	20 20                	and    BYTE PTR [bx+si],ah
    2614:	20 20                	and    BYTE PTR [bx+si],ah
    2616:	20 20                	and    BYTE PTR [bx+si],ah
    2618:	20 20                	and    BYTE PTR [bx+si],ah
    261a:	20 20                	and    BYTE PTR [bx+si],ah
    261c:	20 20                	and    BYTE PTR [bx+si],ah
    261e:	20 20                	and    BYTE PTR [bx+si],ah
    2620:	20 20                	and    BYTE PTR [bx+si],ah
    2622:	20 20                	and    BYTE PTR [bx+si],ah
    2624:	20 20                	and    BYTE PTR [bx+si],ah
    2626:	20 20                	and    BYTE PTR [bx+si],ah
    2628:	20 20                	and    BYTE PTR [bx+si],ah
    262a:	20 20                	and    BYTE PTR [bx+si],ah
    262c:	20 20                	and    BYTE PTR [bx+si],ah
    262e:	20 20                	and    BYTE PTR [bx+si],ah
    2630:	20 20                	and    BYTE PTR [bx+si],ah
    2632:	20 20                	and    BYTE PTR [bx+si],ah
    2634:	20 20                	and    BYTE PTR [bx+si],ah
    2636:	20 20                	and    BYTE PTR [bx+si],ah
    2638:	20 20                	and    BYTE PTR [bx+si],ah
    263a:	20 20                	and    BYTE PTR [bx+si],ah
    263c:	20 20                	and    BYTE PTR [bx+si],ah
    263e:	20 20                	and    BYTE PTR [bx+si],ah
    2640:	20 20                	and    BYTE PTR [bx+si],ah
    2642:	20 20                	and    BYTE PTR [bx+si],ah
    2644:	20 20                	and    BYTE PTR [bx+si],ah
    2646:	20 20                	and    BYTE PTR [bx+si],ah
    2648:	20 20                	and    BYTE PTR [bx+si],ah
    264a:	20 20                	and    BYTE PTR [bx+si],ah
    264c:	20 20                	and    BYTE PTR [bx+si],ah
    264e:	00 45 55             	add    BYTE PTR [di+0x55],al
    2651:	8b ec                	mov    bp,sp
    2653:	eb 00                	jmp    0x2655
    2655:	c4 5e 0a             	les    bx,DWORD PTR [bp+0xa]
    2658:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    265c:	74 14                	je     0x2672
    265e:	c4 5e 0a             	les    bx,DWORD PTR [bp+0xa]
    2661:	ff 46 0a             	inc    WORD PTR [bp+0xa]
    2664:	26 8a 07             	mov    al,BYTE PTR es:[bx]
    2667:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    266a:	ff 46 06             	inc    WORD PTR [bp+0x6]
    266d:	26 3a 07             	cmp    al,BYTE PTR es:[bx]
    2670:	74 e3                	je     0x2655
    2672:	c4 5e 0a             	les    bx,DWORD PTR [bp+0xa]
    2675:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    2679:	75 0e                	jne    0x2689
    267b:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    267e:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    2682:	75 05                	jne    0x2689
    2684:	b8 01 00             	mov    ax,0x1
    2687:	eb 04                	jmp    0x268d
    2689:	33 c0                	xor    ax,ax
    268b:	eb 00                	jmp    0x268d
    268d:	5d                   	pop    bp
    268e:	4d                   	dec    bp
    268f:	ca 08 00             	retf   0x8
    2692:	45                   	inc    bp
    2693:	55                   	push   bp
    2694:	8b ec                	mov    bp,sp
    2696:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
    2699:	0b c9                	or     cx,cx
    269b:	75 02                	jne    0x269f
    269d:	eb 30                	jmp    0x26cf
    269f:	33 d2                	xor    dx,dx
    26a1:	eb 11                	jmp    0x26b4
    26a3:	c4 5e 08             	les    bx,DWORD PTR [bp+0x8]
    26a6:	03 da                	add    bx,dx
    26a8:	26 8a 07             	mov    al,BYTE PTR es:[bx]
    26ab:	c4 5e 0c             	les    bx,DWORD PTR [bp+0xc]
    26ae:	03 da                	add    bx,dx
    26b0:	26 88 07             	mov    BYTE PTR es:[bx],al
    26b3:	42                   	inc    dx
    26b4:	c4 5e 08             	les    bx,DWORD PTR [bp+0x8]
    26b7:	03 da                	add    bx,dx
    26b9:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    26bd:	74 07                	je     0x26c6
    26bf:	8b c1                	mov    ax,cx
    26c1:	48                   	dec    ax
    26c2:	3b c2                	cmp    ax,dx
    26c4:	77 dd                	ja     0x26a3
    26c6:	c4 5e 0c             	les    bx,DWORD PTR [bp+0xc]
    26c9:	03 da                	add    bx,dx
    26cb:	26 c6 07 00          	mov    BYTE PTR es:[bx],0x0
    26cf:	5d                   	pop    bp
    26d0:	4d                   	dec    bp
    26d1:	ca 0a 00             	retf   0xa
    26d4:	45                   	inc    bp
    26d5:	55                   	push   bp
    26d6:	8b ec                	mov    bp,sp
    26d8:	1e                   	push   ds
    26d9:	b4 19                	mov    ah,0x19
    26db:	cd 21                	int    0x21
    26dd:	1f                   	pop    ds
    26de:	04 41                	add    al,0x41
    26e0:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    26e3:	26 88 07             	mov    BYTE PTR es:[bx],al
    26e6:	5d                   	pop    bp
    26e7:	4d                   	dec    bp
    26e8:	ca 04 00             	retf   0x4
    26eb:	45                   	inc    bp
    26ec:	55                   	push   bp
    26ed:	8b ec                	mov    bp,sp
    26ef:	1e                   	push   ds
    26f0:	b4 2f                	mov    ah,0x2f
    26f2:	cd 21                	int    0x21
    26f4:	06                   	push   es
    26f5:	53                   	push   bx
    26f6:	b4 1a                	mov    ah,0x1a
    26f8:	c5 56 06             	lds    dx,DWORD PTR [bp+0x6]
    26fb:	cd 21                	int    0x21
    26fd:	b4 4e                	mov    ah,0x4e
    26ff:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
    2702:	c5 56 0c             	lds    dx,DWORD PTR [bp+0xc]
    2705:	cd 21                	int    0x21
    2707:	9c                   	pushf
    2708:	59                   	pop    cx
    2709:	93                   	xchg   bx,ax
    270a:	b4 1a                	mov    ah,0x1a
    270c:	5a                   	pop    dx
    270d:	1f                   	pop    ds
    270e:	cd 21                	int    0x21
    2710:	51                   	push   cx
    2711:	9d                   	popf
    2712:	1f                   	pop    ds
    2713:	72 04                	jb     0x2719
    2715:	33 c0                	xor    ax,ax
    2717:	eb 05                	jmp    0x271e
    2719:	b8 ff ff             	mov    ax,0xffff
    271c:	eb 00                	jmp    0x271e
    271e:	5d                   	pop    bp
    271f:	4d                   	dec    bp
    2720:	ca 0a 00             	retf   0xa
    2723:	45                   	inc    bp
    2724:	55                   	push   bp
    2725:	8b ec                	mov    bp,sp
    2727:	56                   	push   si
    2728:	1e                   	push   ds
    2729:	b4 47                	mov    ah,0x47
    272b:	8a 56 0a             	mov    dl,BYTE PTR [bp+0xa]
    272e:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    2731:	cd 21                	int    0x21
    2733:	1f                   	pop    ds
    2734:	33 c0                	xor    ax,ax
    2736:	eb 00                	jmp    0x2738
    2738:	5e                   	pop    si
    2739:	5d                   	pop    bp
    273a:	4d                   	dec    bp
    273b:	ca 06 00             	retf   0x6
    273e:	45                   	inc    bp
    273f:	55                   	push   bp
    2740:	8b ec                	mov    bp,sp
    2742:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2745:	ff 76 08             	push   WORD PTR [bp+0x8]
    2748:	0e                   	push   cs
    2749:	e8 88 ff             	call   0x26d4
    274c:	c4 5e 08             	les    bx,DWORD PTR [bp+0x8]
    274f:	26 c6 47 01 3a       	mov    BYTE PTR es:[bx+0x1],0x3a
    2754:	c4 5e 08             	les    bx,DWORD PTR [bp+0x8]
    2757:	26 c6 47 02 5c       	mov    BYTE PTR es:[bx+0x2],0x5c
    275c:	6a 00                	push   0x0
    275e:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    2761:	05 03 00             	add    ax,0x3
    2764:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2767:	50                   	push   ax
    2768:	0e                   	push   cs
    2769:	e8 b7 ff             	call   0x2723
    276c:	3d ff ff             	cmp    ax,0xffff
    276f:	75 06                	jne    0x2777
    2771:	33 d2                	xor    dx,dx
    2773:	33 c0                	xor    ax,ax
    2775:	eb 08                	jmp    0x277f
    2777:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    277a:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    277d:	eb 00                	jmp    0x277f
    277f:	5d                   	pop    bp
    2780:	4d                   	dec    bp
    2781:	ca 06 00             	retf   0x6
    2784:	45                   	inc    bp
    2785:	55                   	push   bp
    2786:	8b ec                	mov    bp,sp
    2788:	6a 00                	push   0x0
    278a:	ff 76 08             	push   WORD PTR [bp+0x8]
    278d:	ff 76 06             	push   WORD PTR [bp+0x6]
    2790:	9a ff ff 00 00       	call   0x0:0xffff
    2795:	5d                   	pop    bp
    2796:	4d                   	dec    bp
    2797:	ca 04 00             	retf   0x4
    279a:	45                   	inc    bp
    279b:	55                   	push   bp
    279c:	8b ec                	mov    bp,sp
    279e:	83 ec 08             	sub    sp,0x8
    27a1:	66 8b 46 0e          	mov    eax,DWORD PTR [bp+0xe]
    27a5:	66 89 46 fc          	mov    DWORD PTR [bp-0x4],eax
    27a9:	66 8b 46 0a          	mov    eax,DWORD PTR [bp+0xa]
    27ad:	66 89 46 f8          	mov    DWORD PTR [bp-0x8],eax
    27b1:	eb 12                	jmp    0x27c5
    27b3:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    27b6:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    27b9:	26 8a 07             	mov    al,BYTE PTR es:[bx]
    27bc:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    27bf:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    27c2:	26 88 07             	mov    BYTE PTR es:[bx],al
    27c5:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    27c8:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    27cc:	75 e5                	jne    0x27b3
    27ce:	66 8b 46 fc          	mov    eax,DWORD PTR [bp-0x4]
    27d2:	66 3b 46 0e          	cmp    eax,DWORD PTR [bp+0xe]
    27d6:	74 14                	je     0x27ec
    27d8:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    27db:	26 80 7f ff 5c       	cmp    BYTE PTR es:[bx-0x1],0x5c
    27e0:	74 0a                	je     0x27ec
    27e2:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    27e5:	26 c6 07 5c          	mov    BYTE PTR es:[bx],0x5c
    27e9:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    27ec:	66 8b 46 06          	mov    eax,DWORD PTR [bp+0x6]
    27f0:	66 89 46 f8          	mov    DWORD PTR [bp-0x8],eax
    27f4:	eb 12                	jmp    0x2808
    27f6:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    27f9:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    27fc:	26 8a 07             	mov    al,BYTE PTR es:[bx]
    27ff:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    2802:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2805:	26 88 07             	mov    BYTE PTR es:[bx],al
    2808:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    280b:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    280f:	75 e5                	jne    0x27f6
    2811:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    2814:	26 c6 07 00          	mov    BYTE PTR es:[bx],0x0
    2818:	c9                   	leave
    2819:	4d                   	dec    bp
    281a:	ca 0c 00             	retf   0xc
    281d:	45                   	inc    bp
    281e:	55                   	push   bp
    281f:	8b ec                	mov    bp,sp
    2821:	6a 40                	push   0x40
    2823:	66 0f b7 46 06       	movzx  eax,WORD PTR [bp+0x6]
    2828:	66 50                	push   eax
    282a:	9a ff ff 00 00       	call   0x0:0xffff
    282f:	50                   	push   ax
    2830:	9a 7d 2e 00 00       	call   0x0:0x2e7d
    2835:	eb 00                	jmp    0x2837
    2837:	5d                   	pop    bp
    2838:	4d                   	dec    bp
    2839:	ca 02 00             	retf   0x2
    283c:	45                   	inc    bp
    283d:	55                   	push   bp
    283e:	8b ec                	mov    bp,sp
    2840:	81 ec 8e 00          	sub    sp,0x8e
    2844:	66 83 7e 12 00       	cmp    DWORD PTR [bp+0x12],0x0
    2849:	74 03                	je     0x284e
    284b:	e9 41 01             	jmp    0x298f
    284e:	66 8b 46 1a          	mov    eax,DWORD PTR [bp+0x1a]
    2852:	66 89 46 f8          	mov    DWORD PTR [bp-0x8],eax
    2856:	8d 86 72 ff          	lea    ax,[bp-0x8e]
    285a:	8c 56 f6             	mov    WORD PTR [bp-0xa],ss
    285d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2860:	c6 46 ef 00          	mov    BYTE PTR [bp-0x11],0x0
    2864:	eb 18                	jmp    0x287e
    2866:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    2869:	26 8a 07             	mov    al,BYTE PTR es:[bx]
    286c:	88 46 ef             	mov    BYTE PTR [bp-0x11],al
    286f:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    2872:	c4 5e f4             	les    bx,DWORD PTR [bp-0xc]
    2875:	8a 46 ef             	mov    al,BYTE PTR [bp-0x11]
    2878:	26 88 07             	mov    BYTE PTR es:[bx],al
    287b:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    287e:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    2881:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    2885:	74 11                	je     0x2898
    2887:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    288a:	26 80 3f 3b          	cmp    BYTE PTR es:[bx],0x3b
    288e:	74 08                	je     0x2898
    2890:	8d 46 c1             	lea    ax,[bp-0x3f]
    2893:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2896:	77 ce                	ja     0x2866
    2898:	80 7e ef 5c          	cmp    BYTE PTR [bp-0x11],0x5c
    289c:	74 0a                	je     0x28a8
    289e:	c4 5e f4             	les    bx,DWORD PTR [bp-0xc]
    28a1:	26 c6 07 5c          	mov    BYTE PTR es:[bx],0x5c
    28a5:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    28a8:	66 8b 46 f4          	mov    eax,DWORD PTR [bp-0xc]
    28ac:	66 89 46 f0          	mov    DWORD PTR [bp-0x10],eax
    28b0:	66 8b 46 16          	mov    eax,DWORD PTR [bp+0x16]
    28b4:	66 89 46 fc          	mov    DWORD PTR [bp-0x4],eax
    28b8:	eb 12                	jmp    0x28cc
    28ba:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    28bd:	26 8a 07             	mov    al,BYTE PTR es:[bx]
    28c0:	c4 5e f4             	les    bx,DWORD PTR [bp-0xc]
    28c3:	26 88 07             	mov    BYTE PTR es:[bx],al
    28c6:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    28c9:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    28cc:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    28cf:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    28d3:	74 08                	je     0x28dd
    28d5:	8d 46 c1             	lea    ax,[bp-0x3f]
    28d8:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    28db:	77 dd                	ja     0x28ba
    28dd:	c4 5e f4             	les    bx,DWORD PTR [bp-0xc]
    28e0:	26 c6 07 00          	mov    BYTE PTR es:[bx],0x0
    28e4:	16                   	push   ss
    28e5:	8d 86 72 ff          	lea    ax,[bp-0x8e]
    28e9:	50                   	push   ax
    28ea:	16                   	push   ss
    28eb:	8d 86 72 ff          	lea    ax,[bp-0x8e]
    28ef:	50                   	push   ax
    28f0:	9a ff ff 00 00       	call   0x0:0xffff
    28f5:	16                   	push   ss
    28f6:	8d 86 72 ff          	lea    ax,[bp-0x8e]
    28fa:	50                   	push   ax
    28fb:	6a 00                	push   0x0
    28fd:	16                   	push   ss
    28fe:	8d 46 c2             	lea    ax,[bp-0x3e]
    2901:	50                   	push   ax
    2902:	0e                   	push   cs
    2903:	e8 e5 fd             	call   0x26eb
    2906:	0b c0                	or     ax,ax
    2908:	75 74                	jne    0x297e
    290a:	8d 86 72 ff          	lea    ax,[bp-0x8e]
    290e:	8c 56 fe             	mov    WORD PTR [bp-0x2],ss
    2911:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2914:	66 8b 46 0a          	mov    eax,DWORD PTR [bp+0xa]
    2918:	66 89 46 f4          	mov    DWORD PTR [bp-0xc],eax
    291c:	eb 12                	jmp    0x2930
    291e:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    2921:	26 8a 07             	mov    al,BYTE PTR es:[bx]
    2924:	c4 5e f4             	les    bx,DWORD PTR [bp-0xc]
    2927:	26 88 07             	mov    BYTE PTR es:[bx],al
    292a:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    292d:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    2930:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    2933:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    2937:	74 0e                	je     0x2947
    2939:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    293c:	48                   	dec    ax
    293d:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    2940:	03 d0                	add    dx,ax
    2942:	3b 56 f4             	cmp    dx,WORD PTR [bp-0xc]
    2945:	77 d7                	ja     0x291e
    2947:	c4 5e f4             	les    bx,DWORD PTR [bp-0xc]
    294a:	26 c6 07 00          	mov    BYTE PTR es:[bx],0x0
    294e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2951:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2954:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2957:	ff 76 0a             	push   WORD PTR [bp+0xa]
    295a:	9a ff ff 00 00       	call   0x0:0xffff
    295f:	66 83 7e 06 00       	cmp    DWORD PTR [bp+0x6],0x0
    2964:	74 0b                	je     0x2971
    2966:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    2969:	66 8b 46 f0          	mov    eax,DWORD PTR [bp-0x10]
    296d:	66 26 89 07          	mov    DWORD PTR es:[bx],eax
    2971:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    2974:	33 d2                	xor    dx,dx
    2976:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
    2979:	83 da 00             	sbb    dx,0x0
    297c:	eb 17                	jmp    0x2995
    297e:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    2981:	26 80 3f 00          	cmp    BYTE PTR es:[bx],0x0
    2985:	75 02                	jne    0x2989
    2987:	eb 06                	jmp    0x298f
    2989:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    298c:	e9 c7 fe             	jmp    0x2856
    298f:	33 d2                	xor    dx,dx
    2991:	33 c0                	xor    ax,ax
    2993:	eb 00                	jmp    0x2995
    2995:	c9                   	leave
    2996:	4d                   	dec    bp
    2997:	ca 18 00             	retf   0x18
    299a:	45                   	inc    bp
    299b:	55                   	push   bp
    299c:	8b ec                	mov    bp,sp
    299e:	83 ec 2c             	sub    sp,0x2c
    29a1:	ff 76 08             	push   WORD PTR [bp+0x8]
    29a4:	ff 76 06             	push   WORD PTR [bp+0x6]
    29a7:	6a 00                	push   0x0
    29a9:	16                   	push   ss
    29aa:	8d 46 d4             	lea    ax,[bp-0x2c]
    29ad:	50                   	push   ax
    29ae:	0e                   	push   cs
    29af:	e8 39 fd             	call   0x26eb
    29b2:	0b c0                	or     ax,ax
    29b4:	75 05                	jne    0x29bb
    29b6:	b8 01 00             	mov    ax,0x1
    29b9:	eb 02                	jmp    0x29bd
    29bb:	33 c0                	xor    ax,ax
    29bd:	eb 00                	jmp    0x29bf
    29bf:	c9                   	leave
    29c0:	4d                   	dec    bp
    29c1:	ca 04 00             	retf   0x4
    29c4:	49                   	dec    cx
    29c5:	44                   	inc    sp
    29c6:	41                   	inc    cx
    29c7:	50                   	push   ax
    29c8:	49                   	dec    cx
    29c9:	00 44 4c             	add    BYTE PTR [si+0x4c],al
    29cc:	4c                   	dec    sp
    29cd:	50                   	push   ax
    29ce:	41                   	inc    cx
    29cf:	54                   	push   sp
    29d0:	48                   	dec    ax
    29d1:	00 00                	add    BYTE PTR [bx+si],al
    29d3:	45                   	inc    bp
    29d4:	55                   	push   bp
    29d5:	8b ec                	mov    bp,sp
    29d7:	81 ec f6 00          	sub    sp,0xf6
    29db:	56                   	push   si
    29dc:	68 00 80             	push   0x8000
    29df:	9a ff ff 00 00       	call   0x0:0xffff
    29e4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    29e7:	16                   	push   ss
    29e8:	8d 46 aa             	lea    ax,[bp-0x56]
    29eb:	50                   	push   ax
    29ec:	6a 50                	push   0x50
    29ee:	0e                   	push   cs
    29ef:	e8 4c fd             	call   0x273e
    29f2:	16                   	push   ss
    29f3:	8d 86 0a ff          	lea    ax,[bp-0xf6]
    29f7:	50                   	push   ax
    29f8:	16                   	push   ss
    29f9:	8d 46 aa             	lea    ax,[bp-0x56]
    29fc:	50                   	push   ax
    29fd:	ff 76 08             	push   WORD PTR [bp+0x8]
    2a00:	ff 76 06             	push   WORD PTR [bp+0x6]
    2a03:	0e                   	push   cs
    2a04:	e8 93 fd             	call   0x279a
    2a07:	16                   	push   ss
    2a08:	8d 86 0a ff          	lea    ax,[bp-0xf6]
    2a0c:	50                   	push   ax
    2a0d:	0e                   	push   cs
    2a0e:	e8 89 ff             	call   0x299a
    2a11:	0b c0                	or     ax,ax
    2a13:	74 19                	je     0x2a2e
    2a15:	16                   	push   ss
    2a16:	8d 86 0a ff          	lea    ax,[bp-0xf6]
    2a1a:	50                   	push   ax
    2a1b:	9a ff ff 00 00       	call   0x0:0xffff
    2a20:	8b f0                	mov    si,ax
    2a22:	66 0f b7 c6          	movzx  eax,si
    2a26:	66 83 f8 20          	cmp    eax,0x20
    2a2a:	72 02                	jb     0x2a2e
    2a2c:	eb 7b                	jmp    0x2aa9
    2a2e:	0e                   	push   cs
    2a2f:	68 c4 29             	push   0x29c4
    2a32:	0e                   	push   cs
    2a33:	68 ca 29             	push   0x29ca
    2a36:	0e                   	push   cs
    2a37:	68 d2 29             	push   0x29d2
    2a3a:	16                   	push   ss
    2a3b:	8d 86 5a ff          	lea    ax,[bp-0xa6]
    2a3f:	50                   	push   ax
    2a40:	6a 50                	push   0x50
    2a42:	9a ff ff 00 00       	call   0x0:0xffff
    2a47:	0b c0                	or     ax,ax
    2a49:	7e 45                	jle    0x2a90
    2a4b:	80 be 5a ff 00       	cmp    BYTE PTR [bp-0xa6],0x0
    2a50:	74 3e                	je     0x2a90
    2a52:	16                   	push   ss
    2a53:	8d 86 5a ff          	lea    ax,[bp-0xa6]
    2a57:	50                   	push   ax
    2a58:	ff 76 08             	push   WORD PTR [bp+0x8]
    2a5b:	ff 76 06             	push   WORD PTR [bp+0x6]
    2a5e:	66 6a 00             	pushd  0x0
    2a61:	66 6a 50             	pushd  0x50
    2a64:	16                   	push   ss
    2a65:	8d 86 0a ff          	lea    ax,[bp-0xf6]
    2a69:	50                   	push   ax
    2a6a:	16                   	push   ss
    2a6b:	8d 46 fa             	lea    ax,[bp-0x6]
    2a6e:	50                   	push   ax
    2a6f:	0e                   	push   cs
    2a70:	e8 c9 fd             	call   0x283c
    2a73:	0b c2                	or     ax,dx
    2a75:	74 19                	je     0x2a90
    2a77:	16                   	push   ss
    2a78:	8d 86 0a ff          	lea    ax,[bp-0xf6]
    2a7c:	50                   	push   ax
    2a7d:	9a 1c 2a 00 00       	call   0x0:0x2a1c
    2a82:	8b f0                	mov    si,ax
    2a84:	66 0f b7 c6          	movzx  eax,si
    2a88:	66 83 f8 20          	cmp    eax,0x20
    2a8c:	72 02                	jb     0x2a90
    2a8e:	eb 19                	jmp    0x2aa9
    2a90:	ff 76 08             	push   WORD PTR [bp+0x8]
    2a93:	ff 76 06             	push   WORD PTR [bp+0x6]
    2a96:	9a 7e 2a 00 00       	call   0x0:0x2a7e
    2a9b:	8b f0                	mov    si,ax
    2a9d:	66 0f b7 c6          	movzx  eax,si
    2aa1:	66 83 f8 20          	cmp    eax,0x20
    2aa5:	72 02                	jb     0x2aa9
    2aa7:	eb 00                	jmp    0x2aa9
    2aa9:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2aac:	9a e0 29 00 00       	call   0x0:0x29e0
    2ab1:	8b c6                	mov    ax,si
    2ab3:	eb 00                	jmp    0x2ab5
    2ab5:	5e                   	pop    si
    2ab6:	c9                   	leave
    2ab7:	4d                   	dec    bp
    2ab8:	ca 04 00             	retf   0x4
    2abb:	44                   	inc    sp
    2abc:	4c                   	dec    sp
    2abd:	4c                   	dec    sp
    2abe:	49                   	dec    cx
    2abf:	4e                   	dec    si
    2ac0:	49                   	dec    cx
    2ac1:	54                   	push   sp
    2ac2:	46                   	inc    si
    2ac3:	55                   	push   bp
    2ac4:	4e                   	dec    si
    2ac5:	43                   	inc    bx
    2ac6:	54                   	push   sp
    2ac7:	49                   	dec    cx
    2ac8:	4f                   	dec    di
    2ac9:	4e                   	dec    si
    2aca:	00 49 44             	add    BYTE PTR [bx+di+0x44],cl
    2acd:	41                   	inc    cx
    2ace:	50                   	push   ax
    2acf:	49                   	dec    cx
    2ad0:	30 31                	xor    BYTE PTR [bx+di],dh
    2ad2:	2e 44                	cs inc sp
    2ad4:	4c                   	dec    sp
    2ad5:	4c                   	dec    sp
    2ad6:	00 45 55             	add    BYTE PTR [di+0x55],al
    2ad9:	8b ec                	mov    bp,sp
    2adb:	83 ec 0e             	sub    sp,0xe
    2ade:	56                   	push   si
    2adf:	8b 76 0a             	mov    si,WORD PTR [bp+0xa]
    2ae2:	56                   	push   si
    2ae3:	9a b6 31 00 00       	call   0x0:0x31b6
    2ae8:	0b c0                	or     ax,ax
    2aea:	75 02                	jne    0x2aee
    2aec:	eb 34                	jmp    0x2b22
    2aee:	56                   	push   si
    2aef:	0e                   	push   cs
    2af0:	68 bb 2a             	push   0x2abb
    2af3:	9a 2d 2e 00 00       	call   0x0:0x2e2d
    2af8:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    2afb:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2afe:	c7 46 f6 01 00       	mov    WORD PTR [bp-0xa],0x1
    2b03:	8c 4e fa             	mov    WORD PTR [bp-0x6],cs
    2b06:	c7 46 f8 cb 2a       	mov    WORD PTR [bp-0x8],0x2acb
    2b0b:	66 8b 46 06          	mov    eax,DWORD PTR [bp+0x6]
    2b0f:	66 89 46 fc          	mov    DWORD PTR [bp-0x4],eax
    2b13:	66 83 7e f2 00       	cmp    DWORD PTR [bp-0xe],0x0
    2b18:	74 08                	je     0x2b22
    2b1a:	16                   	push   ss
    2b1b:	8d 46 f6             	lea    ax,[bp-0xa]
    2b1e:	50                   	push   ax
    2b1f:	ff 5e f2             	call   DWORD PTR [bp-0xe]
    2b22:	5e                   	pop    si
    2b23:	c9                   	leave
    2b24:	4d                   	dec    bp
    2b25:	ca 06 00             	retf   0x6
    2b28:	44                   	inc    sp
    2b29:	4c                   	dec    sp
    2b2a:	4c                   	dec    sp
    2b2b:	45                   	inc    bp
    2b2c:	58                   	pop    ax
    2b2d:	49                   	dec    cx
    2b2e:	54                   	push   sp
    2b2f:	46                   	inc    si
    2b30:	55                   	push   bp
    2b31:	4e                   	dec    si
    2b32:	43                   	inc    bx
    2b33:	54                   	push   sp
    2b34:	49                   	dec    cx
    2b35:	4f                   	dec    di
    2b36:	4e                   	dec    si
    2b37:	00 45 55             	add    BYTE PTR [di+0x55],al
    2b3a:	8b ec                	mov    bp,sp
    2b3c:	83 ec 04             	sub    sp,0x4
    2b3f:	56                   	push   si
    2b40:	8b 76 06             	mov    si,WORD PTR [bp+0x6]
    2b43:	56                   	push   si
    2b44:	9a e4 2a 00 00       	call   0x0:0x2ae4
    2b49:	0b c0                	or     ax,ax
    2b4b:	75 02                	jne    0x2b4f
    2b4d:	eb 1a                	jmp    0x2b69
    2b4f:	56                   	push   si
    2b50:	0e                   	push   cs
    2b51:	68 28 2b             	push   0x2b28
    2b54:	9a f4 2a 00 00       	call   0x0:0x2af4
    2b59:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2b5c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2b5f:	66 83 7e fc 00       	cmp    DWORD PTR [bp-0x4],0x0
    2b64:	74 03                	je     0x2b69
    2b66:	ff 5e fc             	call   DWORD PTR [bp-0x4]
    2b69:	5e                   	pop    si
    2b6a:	c9                   	leave
    2b6b:	4d                   	dec    bp
    2b6c:	ca 02 00             	retf   0x2
    2b6f:	45                   	inc    bp
    2b70:	55                   	push   bp
    2b71:	8b ec                	mov    bp,sp
    2b73:	56                   	push   si
    2b74:	6a 00                	push   0x0
    2b76:	9a ff ff 00 00       	call   0x0:0xffff
    2b7b:	8b f0                	mov    si,ax
    2b7d:	0b f6                	or     si,si
    2b7f:	75 06                	jne    0x2b87
    2b81:	33 d2                	xor    dx,dx
    2b83:	33 c0                	xor    ax,ax
    2b85:	eb 18                	jmp    0x2b9f
    2b87:	66 8b 46 06          	mov    eax,DWORD PTR [bp+0x6]
    2b8b:	66 c1 e8 10          	shr    eax,0x10
    2b8f:	50                   	push   ax
    2b90:	56                   	push   si
    2b91:	9a ff ff 00 00       	call   0x0:0xffff
    2b96:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2b99:	33 d2                	xor    dx,dx
    2b9b:	0b d6                	or     dx,si
    2b9d:	eb 00                	jmp    0x2b9f
    2b9f:	5e                   	pop    si
    2ba0:	5d                   	pop    bp
    2ba1:	4d                   	dec    bp
    2ba2:	ca 04 00             	retf   0x4
    2ba5:	45                   	inc    bp
    2ba6:	55                   	push   bp
    2ba7:	8b ec                	mov    bp,sp
    2ba9:	66 8b 46 06          	mov    eax,DWORD PTR [bp+0x6]
    2bad:	66 c1 e8 10          	shr    eax,0x10
    2bb1:	50                   	push   ax
    2bb2:	9a ff ff 00 00       	call   0x0:0xffff
    2bb7:	5d                   	pop    bp
    2bb8:	4d                   	dec    bp
    2bb9:	ca 04 00             	retf   0x4
    2bbc:	45                   	inc    bp
    2bbd:	55                   	push   bp
    2bbe:	8b ec                	mov    bp,sp
    2bc0:	83 ec 06             	sub    sp,0x6
    2bc3:	56                   	push   si
    2bc4:	57                   	push   di
    2bc5:	b8 4d 00             	mov    ax,0x4d
    2bc8:	2d 1d 00             	sub    ax,0x1d
    2bcb:	bb 30 00             	mov    bx,0x30
    2bce:	33 d2                	xor    dx,dx
    2bd0:	f7 f3                	div    bx
    2bd2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2bd5:	33 f6                	xor    si,si
    2bd7:	eb 17                	jmp    0x2bf0
    2bd9:	8b de                	mov    bx,si
    2bdb:	6b db 30             	imul   bx,bx,0x30
    2bde:	b8 ec 30             	mov    ax,0x30ec
    2be1:	8e c0                	mov    es,ax
    2be3:	26 8b 87 1d 00       	mov    ax,WORD PTR es:[bx+0x1d]
    2be8:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    2beb:	75 02                	jne    0x2bef
    2bed:	eb 06                	jmp    0x2bf5
    2bef:	46                   	inc    si
    2bf0:	3b 76 fe             	cmp    si,WORD PTR [bp-0x2]
    2bf3:	72 e4                	jb     0x2bd9
    2bf5:	3b 76 fe             	cmp    si,WORD PTR [bp-0x2]
    2bf8:	72 02                	jb     0x2bfc
    2bfa:	eb 6b                	jmp    0x2c67
    2bfc:	33 ff                	xor    di,di
    2bfe:	eb 17                	jmp    0x2c17
    2c00:	8b c6                	mov    ax,si
    2c02:	6b c0 30             	imul   ax,ax,0x30
    2c05:	05 1d 00             	add    ax,0x1d
    2c08:	68 df 2b             	push   0x2bdf
    2c0b:	50                   	push   ax
    2c0c:	57                   	push   di
    2c0d:	68 09 2c             	push   0x2c09
    2c10:	68 ed 24             	push   0x24ed
    2c13:	e8 29 01             	call   0x2d3f
    2c16:	47                   	inc    di
    2c17:	8b de                	mov    bx,si
    2c19:	6b db 30             	imul   bx,bx,0x30
    2c1c:	b8 0e 2c             	mov    ax,0x2c0e
    2c1f:	8e c0                	mov    es,ax
    2c21:	26 39 bf 1f 00       	cmp    WORD PTR es:[bx+0x1f],di
    2c26:	77 d8                	ja     0x2c00
    2c28:	8b c6                	mov    ax,si
    2c2a:	6b c0 30             	imul   ax,ax,0x30
    2c2d:	05 1d 00             	add    ax,0x1d
    2c30:	68 1d 2c             	push   0x2c1d
    2c33:	50                   	push   ax
    2c34:	0e                   	push   cs
    2c35:	e8 37 ff             	call   0x2b6f
    2c38:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2c3b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2c3e:	8b c6                	mov    ax,si
    2c40:	6b c0 30             	imul   ax,ax,0x30
    2c43:	c4 5e fa             	les    bx,DWORD PTR [bp-0x6]
    2c46:	03 d8                	add    bx,ax
    2c48:	26 c7 07 00 00       	mov    WORD PTR es:[bx],0x0
    2c4d:	8b c6                	mov    ax,si
    2c4f:	6b c0 30             	imul   ax,ax,0x30
    2c52:	c4 5e fa             	les    bx,DWORD PTR [bp-0x6]
    2c55:	03 d8                	add    bx,ax
    2c57:	26 c7 47 2e 00 00    	mov    WORD PTR es:[bx+0x2e],0x0
    2c5d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2c60:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c63:	0e                   	push   cs
    2c64:	e8 3e ff             	call   0x2ba5
    2c67:	5f                   	pop    di
    2c68:	5e                   	pop    si
    2c69:	c9                   	leave
    2c6a:	4d                   	dec    bp
    2c6b:	ca 02 00             	retf   0x2
    2c6e:	43                   	inc    bx
    2c6f:	4a                   	dec    dx
    2c70:	48                   	dec    ax
    2c71:	00 01                	add    BYTE PTR [bx+di],al
    2c73:	00 bc 2b 31          	add    BYTE PTR [si+0x312b],bh
    2c77:	2c 00                	sub    al,0x0
	...
    2c95:	00 00                	add    BYTE PTR [bx+si],al
    2c97:	00 45 55             	add    BYTE PTR [di+0x55],al
    2c9a:	8b ec                	mov    bp,sp
    2c9c:	83 ec 04             	sub    sp,0x4
    2c9f:	56                   	push   si
    2ca0:	57                   	push   di
    2ca1:	33 ff                	xor    di,di
    2ca3:	ff 76 08             	push   WORD PTR [bp+0x8]
    2ca6:	ff 76 06             	push   WORD PTR [bp+0x6]
    2ca9:	0e                   	push   cs
    2caa:	e8 c2 fe             	call   0x2b6f
    2cad:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2cb0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2cb3:	66 83 7e fc 00       	cmp    DWORD PTR [bp-0x4],0x0
    2cb8:	75 05                	jne    0x2cbf
    2cba:	b8 01 25             	mov    ax,0x2501
    2cbd:	eb 67                	jmp    0x2d26
    2cbf:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2cc2:	05 0a 00             	add    ax,0xa
    2cc5:	ff 76 08             	push   WORD PTR [bp+0x8]
    2cc8:	50                   	push   ax
    2cc9:	9a ff ff 00 00       	call   0x0:0xffff
    2cce:	8b f0                	mov    si,ax
    2cd0:	0b f6                	or     si,si
    2cd2:	75 2c                	jne    0x2d00
    2cd4:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2cd7:	05 0a 00             	add    ax,0xa
    2cda:	ff 76 08             	push   WORD PTR [bp+0x8]
    2cdd:	50                   	push   ax
    2cde:	0e                   	push   cs
    2cdf:	e8 f1 fc             	call   0x29d3
    2ce2:	8b f0                	mov    si,ax
    2ce4:	66 0f b7 c6          	movzx  eax,si
    2ce8:	66 83 f8 20          	cmp    eax,0x20
    2cec:	73 0f                	jae    0x2cfd
    2cee:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2cf1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2cf4:	0e                   	push   cs
    2cf5:	e8 ad fe             	call   0x2ba5
    2cf8:	b8 0a 21             	mov    ax,0x210a
    2cfb:	eb 29                	jmp    0x2d26
    2cfd:	bf 01 00             	mov    di,0x1
    2d00:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    2d03:	26 89 37             	mov    WORD PTR es:[bx],si
    2d06:	c4 5e fc             	les    bx,DWORD PTR [bp-0x4]
    2d09:	26 09 7f 2e          	or     WORD PTR es:[bx+0x2e],di
    2d0d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2d10:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2d13:	0e                   	push   cs
    2d14:	e8 8e fe             	call   0x2ba5
    2d17:	56                   	push   si
    2d18:	68 42 32             	push   0x3242
    2d1b:	68 6e 2c             	push   0x2c6e
    2d1e:	0e                   	push   cs
    2d1f:	e8 b5 fd             	call   0x2ad7
    2d22:	33 c0                	xor    ax,ax
    2d24:	eb 00                	jmp    0x2d26
    2d26:	5f                   	pop    di
    2d27:	5e                   	pop    si
    2d28:	c9                   	leave
    2d29:	4d                   	dec    bp
    2d2a:	ca 04 00             	retf   0x4
    2d2d:	4e                   	dec    si
    2d2e:	6f                   	outs   dx,WORD PTR ds:[si]
    2d2f:	74 20                	je     0x2d51
    2d31:	45                   	inc    bp
    2d32:	6e                   	outs   dx,BYTE PTR ds:[si]
    2d33:	6f                   	outs   dx,WORD PTR ds:[si]
    2d34:	75 67                	jne    0x2d9d
    2d36:	68 20 4d             	push   0x4d20
    2d39:	65 6d                	gs ins WORD PTR es:[di],dx
    2d3b:	6f                   	outs   dx,WORD PTR ds:[si]
    2d3c:	72 79                	jb     0x2db7
    2d3e:	00 55 8b             	add    BYTE PTR [di-0x75],dl
    2d41:	ec                   	in     al,dx
    2d42:	83 ec 08             	sub    sp,0x8
    2d45:	56                   	push   si
    2d46:	c4 5e 0a             	les    bx,DWORD PTR [bp+0xa]
    2d49:	26 ff 77 2c          	push   WORD PTR es:[bx+0x2c]
    2d4d:	26 ff 77 2a          	push   WORD PTR es:[bx+0x2a]
    2d51:	0e                   	push   cs
    2d52:	e8 1a fe             	call   0x2b6f
    2d55:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2d58:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2d5b:	66 83 7e fc 00       	cmp    DWORD PTR [bp-0x4],0x0
    2d60:	75 08                	jne    0x2d6a
    2d62:	0e                   	push   cs
    2d63:	68 2d 2d             	push   0x2d2d
    2d66:	0e                   	push   cs
    2d67:	e8 1a fa             	call   0x2784
    2d6a:	c4 5e 0a             	les    bx,DWORD PTR [bp+0xa]
    2d6d:	26 8b 47 04          	mov    ax,WORD PTR es:[bx+0x4]
    2d71:	f7 6e 08             	imul   WORD PTR [bp+0x8]
    2d74:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2d77:	8b 5e fc             	mov    bx,WORD PTR [bp-0x4]
    2d7a:	03 d8                	add    bx,ax
    2d7c:	c4 76 0a             	les    si,DWORD PTR [bp+0xa]
    2d7f:	26 03 5c 06          	add    bx,WORD PTR es:[si+0x6]
    2d83:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2d86:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
    2d89:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    2d8c:	26 c6 07 ea          	mov    BYTE PTR es:[bx],0xea
    2d90:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    2d93:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    2d96:	66 8b 46 04          	mov    eax,DWORD PTR [bp+0x4]
    2d9a:	66 26 89 07          	mov    DWORD PTR es:[bx],eax
    2d9e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2da1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2da4:	0e                   	push   cs
    2da5:	e8 fd fd             	call   0x2ba5
    2da8:	5e                   	pop    si
    2da9:	c9                   	leave
    2daa:	c2 0a 00             	ret    0xa
    2dad:	55                   	push   bp
    2dae:	8b ec                	mov    bp,sp
    2db0:	83 ec 0c             	sub    sp,0xc
    2db3:	56                   	push   si
    2db4:	57                   	push   di
    2db5:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2db8:	33 f6                	xor    si,si
    2dba:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    2dbd:	26 83 3f 00          	cmp    WORD PTR es:[bx],0x0
    2dc1:	75 17                	jne    0x2dda
    2dc3:	ff 76 08             	push   WORD PTR [bp+0x8]
    2dc6:	ff 76 06             	push   WORD PTR [bp+0x6]
    2dc9:	0e                   	push   cs
    2dca:	e8 cb fe             	call   0x2c98
    2dcd:	8b f0                	mov    si,ax
    2dcf:	0b f6                	or     si,si
    2dd1:	74 07                	je     0x2dda
    2dd3:	8b c6                	mov    ax,si
    2dd5:	33 d2                	xor    dx,dx
    2dd7:	e9 83 00             	jmp    0x2e5d
    2dda:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    2ddd:	26 8b 47 2a          	mov    ax,WORD PTR es:[bx+0x2a]
    2de1:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    2de4:	50                   	push   ax
    2de5:	26 8b 47 04          	mov    ax,WORD PTR es:[bx+0x4]
    2de9:	f7 ef                	imul   di
    2deb:	5a                   	pop    dx
    2dec:	03 d0                	add    dx,ax
    2dee:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    2df1:	26 03 57 08          	add    dx,WORD PTR es:[bx+0x8]
    2df5:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    2df8:	66 0f b7 46 f8       	movzx  eax,WORD PTR [bp-0x8]
    2dfd:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    2e00:	66 26 0f b7 57 2c    	movzx  edx,WORD PTR es:[bx+0x2c]
    2e06:	66 c1 e2 10          	shl    edx,0x10
    2e0a:	66 0b c2             	or     eax,edx
    2e0d:	66 0f a4 c2 10       	shld   edx,eax,0x10
    2e12:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    2e15:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2e18:	c4 5e f4             	les    bx,DWORD PTR [bp-0xc]
    2e1b:	26 8b 07             	mov    ax,WORD PTR es:[bx]
    2e1e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2e21:	c4 5e 06             	les    bx,DWORD PTR [bp+0x6]
    2e24:	26 ff 37             	push   WORD PTR es:[bx]
    2e27:	6a 00                	push   0x0
    2e29:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e2c:	9a d3 31 00 00       	call   0x0:0x31d3
    2e31:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2e34:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2e37:	66 83 7e fc 00       	cmp    DWORD PTR [bp-0x4],0x0
    2e3c:	75 07                	jne    0x2e45
    2e3e:	33 d2                	xor    dx,dx
    2e40:	b8 4f 27             	mov    ax,0x274f
    2e43:	eb 18                	jmp    0x2e5d
    2e45:	ff 76 08             	push   WORD PTR [bp+0x8]
    2e48:	ff 76 06             	push   WORD PTR [bp+0x6]
    2e4b:	57                   	push   di
    2e4c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e4f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2e52:	e8 ea fe             	call   0x2d3f
    2e55:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2e58:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2e5b:	eb 00                	jmp    0x2e5d
    2e5d:	5f                   	pop    di
    2e5e:	5e                   	pop    si
    2e5f:	c9                   	leave
    2e60:	c2 06 00             	ret    0x6
    2e63:	45                   	inc    bp
    2e64:	55                   	push   bp
    2e65:	8b ec                	mov    bp,sp
    2e67:	b8 19 2d             	mov    ax,0x2d19
    2e6a:	ba 1d 00             	mov    dx,0x1d
    2e6d:	50                   	push   ax
    2e6e:	52                   	push   dx
    2e6f:	66 5a                	pop    edx
    2e71:	66 c1 ea 10          	shr    edx,0x10
    2e75:	52                   	push   dx
    2e76:	9a ff ff 00 00       	call   0x0:0xffff
    2e7b:	50                   	push   ax
    2e7c:	9a ff ff 00 00       	call   0x0:0xffff
    2e81:	b8 01 00             	mov    ax,0x1
    2e84:	eb 00                	jmp    0x2e86
    2e86:	5d                   	pop    bp
    2e87:	4d                   	dec    bp
    2e88:	cb                   	retf
    2e89:	45                   	inc    bp
    2e8a:	55                   	push   bp
    2e8b:	8b ec                	mov    bp,sp
    2e8d:	83 ec 08             	sub    sp,0x8
    2e90:	56                   	push   si
    2e91:	57                   	push   di
    2e92:	b8 4d 00             	mov    ax,0x4d
    2e95:	2d 1d 00             	sub    ax,0x1d
    2e98:	bb 30 00             	mov    bx,0x30
    2e9b:	33 d2                	xor    dx,dx
    2e9d:	f7 f3                	div    bx
    2e9f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2ea2:	33 f6                	xor    si,si
    2ea4:	eb 66                	jmp    0x2f0c
    2ea6:	8b de                	mov    bx,si
    2ea8:	6b db 30             	imul   bx,bx,0x30
    2eab:	b8 68 2e             	mov    ax,0x2e68
    2eae:	8e c0                	mov    es,ax
    2eb0:	26 8b 87 1d 00       	mov    ax,WORD PTR es:[bx+0x1d]
    2eb5:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2eb8:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    2ebc:	74 21                	je     0x2edf
    2ebe:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2ec1:	0e                   	push   cs
    2ec2:	e8 73 fc             	call   0x2b38
    2ec5:	8b de                	mov    bx,si
    2ec7:	6b db 30             	imul   bx,bx,0x30
    2eca:	b8 ac 2e             	mov    ax,0x2eac
    2ecd:	8e c0                	mov    es,ax
    2ecf:	26 83 bf 4b 00 00    	cmp    WORD PTR es:[bx+0x4b],0x0
    2ed5:	74 08                	je     0x2edf
    2ed7:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2eda:	9a 4c 32 00 00       	call   0x0:0x324c
    2edf:	33 ff                	xor    di,di
    2ee1:	eb 17                	jmp    0x2efa
    2ee3:	8b c6                	mov    ax,si
    2ee5:	6b c0 30             	imul   ax,ax,0x30
    2ee8:	05 1d 00             	add    ax,0x1d
    2eeb:	68 cb 2e             	push   0x2ecb
    2eee:	50                   	push   ax
    2eef:	57                   	push   di
    2ef0:	68 ec 2e             	push   0x2eec
    2ef3:	68 ed 24             	push   0x24ed
    2ef6:	e8 46 fe             	call   0x2d3f
    2ef9:	47                   	inc    di
    2efa:	8b de                	mov    bx,si
    2efc:	6b db 30             	imul   bx,bx,0x30
    2eff:	b8 f1 2e             	mov    ax,0x2ef1
    2f02:	8e c0                	mov    es,ax
    2f04:	26 39 bf 1f 00       	cmp    WORD PTR es:[bx+0x1f],di
    2f09:	77 d8                	ja     0x2ee3
    2f0b:	46                   	inc    si
    2f0c:	3b 76 fe             	cmp    si,WORD PTR [bp-0x2]
    2f0f:	72 95                	jb     0x2ea6
    2f11:	68 00 2f             	push   0x2f00
    2f14:	68 1d 00             	push   0x1d
    2f17:	0e                   	push   cs
    2f18:	e8 54 fc             	call   0x2b6f
    2f1b:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2f1e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2f21:	33 f6                	xor    si,si
    2f23:	eb 20                	jmp    0x2f45
    2f25:	8b c6                	mov    ax,si
    2f27:	6b c0 30             	imul   ax,ax,0x30
    2f2a:	c4 5e fa             	les    bx,DWORD PTR [bp-0x6]
    2f2d:	03 d8                	add    bx,ax
    2f2f:	26 c7 07 00 00       	mov    WORD PTR es:[bx],0x0
    2f34:	8b c6                	mov    ax,si
    2f36:	6b c0 30             	imul   ax,ax,0x30
    2f39:	c4 5e fa             	les    bx,DWORD PTR [bp-0x6]
    2f3c:	03 d8                	add    bx,ax
    2f3e:	26 c7 47 2e 00 00    	mov    WORD PTR es:[bx+0x2e],0x0
    2f44:	46                   	inc    si
    2f45:	3b 76 fe             	cmp    si,WORD PTR [bp-0x2]
    2f48:	72 db                	jb     0x2f25
    2f4a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2f4d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2f50:	0e                   	push   cs
    2f51:	e8 51 fc             	call   0x2ba5
    2f54:	68 12 2f             	push   0x2f12
    2f57:	9a 77 2e 00 00       	call   0x0:0x2e77
    2f5c:	50                   	push   ax
    2f5d:	9a ff ff 00 00       	call   0x0:0xffff
    2f62:	5f                   	pop    di
    2f63:	5e                   	pop    si
    2f64:	c9                   	leave
    2f65:	4d                   	dec    bp
    2f66:	cb                   	retf
    2f67:	4e                   	dec    si
    2f68:	6f                   	outs   dx,WORD PTR ds:[si]
    2f69:	74 20                	je     0x2f8b
    2f6b:	45                   	inc    bp
    2f6c:	6e                   	outs   dx,BYTE PTR ds:[si]
    2f6d:	6f                   	outs   dx,WORD PTR ds:[si]
    2f6e:	75 67                	jne    0x2fd7
    2f70:	68 20 4d             	push   0x4d20
    2f73:	65 6d                	gs ins WORD PTR es:[di],dx
    2f75:	6f                   	outs   dx,WORD PTR ds:[si]
    2f76:	72 79                	jb     0x2ff1
    2f78:	00 45 55             	add    BYTE PTR [di+0x55],al
    2f7b:	8b ec                	mov    bp,sp
    2f7d:	83 ec 06             	sub    sp,0x6
    2f80:	56                   	push   si
    2f81:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2f84:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2f87:	ff 76 08             	push   WORD PTR [bp+0x8]
    2f8a:	ff 76 06             	push   WORD PTR [bp+0x6]
    2f8d:	0e                   	push   cs
    2f8e:	e8 be f6             	call   0x264f
    2f91:	0b c0                	or     ax,ax
    2f93:	74 03                	je     0x2f98
    2f95:	e9 81 00             	jmp    0x3019
    2f98:	b8 4d 00             	mov    ax,0x4d
    2f9b:	2d 1d 00             	sub    ax,0x1d
    2f9e:	bb 30 00             	mov    bx,0x30
    2fa1:	33 d2                	xor    dx,dx
    2fa3:	f7 f3                	div    bx
    2fa5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2fa8:	33 f6                	xor    si,si
    2faa:	eb 73                	jmp    0x301f
    2fac:	8b c6                	mov    ax,si
    2fae:	6b c0 30             	imul   ax,ax,0x30
    2fb1:	05 27 00             	add    ax,0x27
    2fb4:	68 55 2f             	push   0x2f55
    2fb7:	50                   	push   ax
    2fb8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2fbb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2fbe:	0e                   	push   cs
    2fbf:	e8 8d f6             	call   0x264f
    2fc2:	0b c0                	or     ax,ax
    2fc4:	75 58                	jne    0x301e
    2fc6:	8b de                	mov    bx,si
    2fc8:	6b db 30             	imul   bx,bx,0x30
    2fcb:	b8 b5 2f             	mov    ax,0x2fb5
    2fce:	8e c0                	mov    es,ax
    2fd0:	26 83 bf 1d 00 00    	cmp    WORD PTR es:[bx+0x1d],0x0
    2fd6:	74 02                	je     0x2fda
    2fd8:	eb 4a                	jmp    0x3024
    2fda:	68 cc 2f             	push   0x2fcc
    2fdd:	68 1d 00             	push   0x1d
    2fe0:	0e                   	push   cs
    2fe1:	e8 8b fb             	call   0x2b6f
    2fe4:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    2fe7:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2fea:	66 83 7e fa 00       	cmp    DWORD PTR [bp-0x6],0x0
    2fef:	75 08                	jne    0x2ff9
    2ff1:	0e                   	push   cs
    2ff2:	68 67 2f             	push   0x2f67
    2ff5:	0e                   	push   cs
    2ff6:	e8 8b f7             	call   0x2784
    2ff9:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2ffc:	05 0a 00             	add    ax,0xa
    2fff:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3002:	50                   	push   ax
    3003:	ff 76 08             	push   WORD PTR [bp+0x8]
    3006:	ff 76 06             	push   WORD PTR [bp+0x6]
    3009:	6a 20                	push   0x20
    300b:	0e                   	push   cs
    300c:	e8 83 f6             	call   0x2692
    300f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3012:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3015:	0e                   	push   cs
    3016:	e8 8c fb             	call   0x2ba5
    3019:	b8 01 00             	mov    ax,0x1
    301c:	eb 0a                	jmp    0x3028
    301e:	46                   	inc    si
    301f:	3b 76 fe             	cmp    si,WORD PTR [bp-0x2]
    3022:	72 88                	jb     0x2fac
    3024:	33 c0                	xor    ax,ax
    3026:	eb 00                	jmp    0x3028
    3028:	5e                   	pop    si
    3029:	c9                   	leave
    302a:	4d                   	dec    bp
    302b:	ca 08 00             	retf   0x8
    302e:	45                   	inc    bp
    302f:	55                   	push   bp
    3030:	8b ec                	mov    bp,sp
    3032:	8b 5e 06             	mov    bx,WORD PTR [bp+0x6]
    3035:	83 fb 08             	cmp    bx,0x8
    3038:	77 11                	ja     0x304b
    303a:	03 db                	add    bx,bx
    303c:	2e ff a7 57 30       	jmp    WORD PTR cs:[bx+0x3057]
    3041:	ba 01 25             	mov    dx,0x2501
    3044:	eb 08                	jmp    0x304e
    3046:	ba 08 21             	mov    dx,0x2108
    3049:	eb 03                	jmp    0x304e
    304b:	ba 09 21             	mov    dx,0x2109
    304e:	8b c2                	mov    ax,dx
    3050:	eb 00                	jmp    0x3052
    3052:	5d                   	pop    bp
    3053:	4d                   	dec    bp
    3054:	ca 02 00             	retf   0x2
    3057:	41                   	inc    cx
    3058:	30 4b 30             	xor    BYTE PTR [bp+di+0x30],cl
    305b:	46                   	inc    si
    305c:	30 46 30             	xor    BYTE PTR [bp+0x30],al
    305f:	4b                   	dec    bx
    3060:	30 4b 30             	xor    BYTE PTR [bp+di+0x30],cl
    3063:	4b                   	dec    bx
    3064:	30 4b 30             	xor    BYTE PTR [bp+di+0x30],cl
    3067:	41                   	inc    cx
    3068:	30 49 44             	xor    BYTE PTR [bx+di+0x44],cl
    306b:	41                   	inc    cx
    306c:	50                   	push   ax
    306d:	49                   	dec    cx
    306e:	30 31                	xor    BYTE PTR [bx+di],dh
    3070:	2e 44                	cs inc sp
    3072:	4c                   	dec    sp
    3073:	4c                   	dec    sp
    3074:	00 44 42             	add    BYTE PTR [si+0x42],al
    3077:	49                   	dec    cx
    3078:	49                   	dec    cx
    3079:	4e                   	dec    si
    307a:	49                   	dec    cx
    307b:	54                   	push   sp
    307c:	46                   	inc    si
    307d:	4e                   	dec    si
    307e:	00 45 55             	add    BYTE PTR [di+0x55],al
    3081:	8b ec                	mov    bp,sp
    3083:	83 ec 14             	sub    sp,0x14
    3086:	56                   	push   si
    3087:	57                   	push   di
    3088:	33 ff                	xor    di,di
    308a:	33 f6                	xor    si,si
    308c:	c7 46 fa 00 00       	mov    WORD PTR [bp-0x6],0x0
    3091:	c7 46 f8 00 00       	mov    WORD PTR [bp-0x8],0x0
    3096:	b8 db 2f             	mov    ax,0x2fdb
    3099:	8e c0                	mov    es,ax
    309b:	66 26 a1 1d 00       	mov    eax,es:0x1d
    30a0:	66 89 46 ec          	mov    DWORD PTR [bp-0x14],eax
    30a4:	b8 97 30             	mov    ax,0x3097
    30a7:	8e c0                	mov    es,ax
    30a9:	26 83 3e fa 24 00    	cmp    WORD PTR es:0x24fa,0x0
    30af:	75 3a                	jne    0x30eb
    30b1:	0e                   	push   cs
    30b2:	68 69 30             	push   0x3069
    30b5:	0e                   	push   cs
    30b6:	e8 1a f9             	call   0x29d3
    30b9:	8b f0                	mov    si,ax
    30bb:	66 0f b7 c6          	movzx  eax,si
    30bf:	66 83 f8 20          	cmp    eax,0x20
    30c3:	73 0c                	jae    0x30d1
    30c5:	56                   	push   si
    30c6:	0e                   	push   cs
    30c7:	e8 64 ff             	call   0x302e
    30ca:	8b f8                	mov    di,ax
    30cc:	33 f6                	xor    si,si
    30ce:	e9 a5 00             	jmp    0x3176
    30d1:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    30d6:	0e                   	push   cs
    30d7:	e8 89 fd             	call   0x2e63
    30da:	0b c0                	or     ax,ax
    30dc:	75 06                	jne    0x30e4
    30de:	bf 01 25             	mov    di,0x2501
    30e1:	e9 92 00             	jmp    0x3176
    30e4:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    30e9:	eb 0a                	jmp    0x30f5
    30eb:	b8 a5 30             	mov    ax,0x30a5
    30ee:	8e c0                	mov    es,ax
    30f0:	26 8b 36 fa 24       	mov    si,WORD PTR es:0x24fa
    30f5:	56                   	push   si
    30f6:	0e                   	push   cs
    30f7:	68 75 30             	push   0x3075
    30fa:	9a ff ff 00 00       	call   0x0:0xffff
    30ff:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3102:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3105:	66 83 7e fc 00       	cmp    DWORD PTR [bp-0x4],0x0
    310a:	75 05                	jne    0x3111
    310c:	bf 06 2a             	mov    di,0x2a06
    310f:	eb 65                	jmp    0x3176
    3111:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3114:	ff 76 08             	push   WORD PTR [bp+0x8]
    3117:	ff 76 06             	push   WORD PTR [bp+0x6]
    311a:	ff 5e fc             	call   DWORD PTR [bp-0x4]
    311d:	8b f8                	mov    di,ax
    311f:	0b ff                	or     di,di
    3121:	74 02                	je     0x3125
    3123:	eb 51                	jmp    0x3176
    3125:	b8 ff ff             	mov    ax,0xffff
    3128:	8e c0                	mov    es,ax
    312a:	26 83 3e fc 24 00    	cmp    WORD PTR es:0x24fc,0x0
    3130:	75 20                	jne    0x3152
    3132:	68 26 31             	push   0x3126
    3135:	68 fa 24             	push   0x24fa
    3138:	0e                   	push   cs
    3139:	e8 33 fa             	call   0x2b6f
    313c:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    313f:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3142:	c4 5e f4             	les    bx,DWORD PTR [bp-0xc]
    3145:	26 89 37             	mov    WORD PTR es:[bx],si
    3148:	ff 76 f6             	push   WORD PTR [bp-0xa]
    314b:	ff 76 f4             	push   WORD PTR [bp-0xc]
    314e:	0e                   	push   cs
    314f:	e8 53 fa             	call   0x2ba5
    3152:	68 33 31             	push   0x3133
    3155:	68 fc 24             	push   0x24fc
    3158:	0e                   	push   cs
    3159:	e8 13 fa             	call   0x2b6f
    315c:	89 56 f2             	mov    WORD PTR [bp-0xe],dx
    315f:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    3162:	c4 5e f0             	les    bx,DWORD PTR [bp-0x10]
    3165:	26 ff 07             	inc    WORD PTR es:[bx]
    3168:	ff 76 f2             	push   WORD PTR [bp-0xe]
    316b:	ff 76 f0             	push   WORD PTR [bp-0x10]
    316e:	0e                   	push   cs
    316f:	e8 33 fa             	call   0x2ba5
    3172:	33 c0                	xor    ax,ax
    3174:	eb 1e                	jmp    0x3194
    3176:	0b f6                	or     si,si
    3178:	74 0c                	je     0x3186
    317a:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    317e:	74 06                	je     0x3186
    3180:	56                   	push   si
    3181:	9a ff ff 00 00       	call   0x0:0xffff
    3186:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    318a:	74 04                	je     0x3190
    318c:	0e                   	push   cs
    318d:	e8 f9 fc             	call   0x2e89
    3190:	8b c7                	mov    ax,di
    3192:	eb 00                	jmp    0x3194
    3194:	5f                   	pop    di
    3195:	5e                   	pop    si
    3196:	c9                   	leave
    3197:	4d                   	dec    bp
    3198:	ca 06 00             	retf   0x6
    319b:	44                   	inc    sp
    319c:	42                   	inc    dx
    319d:	49                   	dec    cx
    319e:	45                   	inc    bp
    319f:	58                   	pop    ax
    31a0:	49                   	dec    cx
    31a1:	54                   	push   sp
    31a2:	00 45 55             	add    BYTE PTR [di+0x55],al
    31a5:	8b ec                	mov    bp,sp
    31a7:	83 ec 0c             	sub    sp,0xc
    31aa:	56                   	push   si
    31ab:	b8 53 31             	mov    ax,0x3153
    31ae:	8e c0                	mov    es,ax
    31b0:	26 ff 36 fa 24       	push   WORD PTR es:0x24fa
    31b5:	9a ff ff 00 00       	call   0x0:0xffff
    31ba:	0b c0                	or     ax,ax
    31bc:	75 06                	jne    0x31c4
    31be:	b8 06 2a             	mov    ax,0x2a06
    31c1:	e9 b5 00             	jmp    0x3279
    31c4:	b8 ac 31             	mov    ax,0x31ac
    31c7:	8e c0                	mov    es,ax
    31c9:	26 ff 36 fa 24       	push   WORD PTR es:0x24fa
    31ce:	0e                   	push   cs
    31cf:	68 9b 31             	push   0x319b
    31d2:	9a fb 30 00 00       	call   0x0:0x30fb
    31d7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    31da:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    31dd:	66 83 7e fc 00       	cmp    DWORD PTR [bp-0x4],0x0
    31e2:	75 06                	jne    0x31ea
    31e4:	b8 4f 27             	mov    ax,0x274f
    31e7:	e9 8f 00             	jmp    0x3279
    31ea:	ff 5e fc             	call   DWORD PTR [bp-0x4]
    31ed:	8b f0                	mov    si,ax
    31ef:	0b f6                	or     si,si
    31f1:	74 03                	je     0x31f6
    31f3:	e9 7f 00             	jmp    0x3275
    31f6:	b8 c5 31             	mov    ax,0x31c5
    31f9:	8e c0                	mov    es,ax
    31fb:	26 83 3e fc 24 00    	cmp    WORD PTR es:0x24fc,0x0
    3201:	76 70                	jbe    0x3273
    3203:	68 f7 31             	push   0x31f7
    3206:	68 fc 24             	push   0x24fc
    3209:	0e                   	push   cs
    320a:	e8 62 f9             	call   0x2b6f
    320d:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3210:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3213:	66 83 7e f4 00       	cmp    DWORD PTR [bp-0xc],0x0
    3218:	74 06                	je     0x3220
    321a:	c4 5e f4             	les    bx,DWORD PTR [bp-0xc]
    321d:	26 ff 0f             	dec    WORD PTR es:[bx]
    3220:	b8 04 32             	mov    ax,0x3204
    3223:	8e c0                	mov    es,ax
    3225:	26 83 3e fc 24 00    	cmp    WORD PTR es:0x24fc,0x0
    322b:	75 3c                	jne    0x3269
    322d:	0e                   	push   cs
    322e:	e8 58 fc             	call   0x2e89
    3231:	68 21 32             	push   0x3221
    3234:	68 fa 24             	push   0x24fa
    3237:	0e                   	push   cs
    3238:	e8 34 f9             	call   0x2b6f
    323b:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    323e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3241:	b8 32 32             	mov    ax,0x3232
    3244:	8e c0                	mov    es,ax
    3246:	26 ff 36 fa 24       	push   WORD PTR es:0x24fa
    324b:	9a 82 31 00 00       	call   0x0:0x3182
    3250:	66 83 7e f8 00       	cmp    DWORD PTR [bp-0x8],0x0
    3255:	74 08                	je     0x325f
    3257:	c4 5e f8             	les    bx,DWORD PTR [bp-0x8]
    325a:	26 c7 07 00 00       	mov    WORD PTR es:[bx],0x0
    325f:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3262:	ff 76 f8             	push   WORD PTR [bp-0x8]
    3265:	0e                   	push   cs
    3266:	e8 3c f9             	call   0x2ba5
    3269:	ff 76 f6             	push   WORD PTR [bp-0xa]
    326c:	ff 76 f4             	push   WORD PTR [bp-0xc]
    326f:	0e                   	push   cs
    3270:	e8 32 f9             	call   0x2ba5
    3273:	33 f6                	xor    si,si
    3275:	8b c6                	mov    ax,si
    3277:	eb 00                	jmp    0x3279
    3279:	5e                   	pop    si
    327a:	c9                   	leave
    327b:	4d                   	dec    bp
    327c:	cb                   	retf
