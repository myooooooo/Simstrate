; ================================================================
; seg33_CODE  (11928 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	21 00                	and    WORD PTR [bx+si],ax
	...
       a:	22 00                	and    al,BYTE PTR [bx+si]
       c:	0c 00                	or     al,0x0
       e:	2e 00 db             	cs add bl,bl
      11:	11 64 20             	adc    WORD PTR [si+0x20],sp
      14:	49                   	dec    cx
      15:	00 9a 1f 14          	add    BYTE PTR [bp+si+0x141f],bl
      19:	00 cb                	add    bl,cl
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	c4 29                	les    bp,DWORD PTR [bx+di]
      20:	10 00                	adc    BYTE PTR [bx+si],al
      22:	0c 45                	or     al,0x45
      24:	44                   	inc    sp
      25:	42                   	inc    dx
      26:	45                   	inc    bp
      27:	64 69 74 45 72 72    	imul   si,WORD PTR fs:[si+0x45],0x7272
      2d:	6f                   	outs   dx,WORD PTR ds:[si]
      2e:	72 2d                	jb     0x5d
      30:	01 00                	add    WORD PTR [bx+si],ax
      32:	00 00                	add    BYTE PTR [bx+si],al
      34:	00 e3                	add    bl,ah
      36:	00 d3                	add    bl,dl
      38:	00 fd                	add    ch,bh
      3a:	00 86 0a 44          	add    BYTE PTR [bp+0x440a],al
      3e:	01 fa                	add    dx,di
      40:	45                   	inc    bp
      41:	b5 00                	mov    ch,0x0
      43:	9a 1f 69 01 cb       	call   0xcb01:0x691f
      48:	1f                   	pop    ds
      49:	45                   	inc    bp
      4a:	00 c8                	add    al,cl
      4c:	11 ff                	adc    di,di
      4e:	00 cd                	add    ch,cl
      50:	11 59 00             	adc    WORD PTR [bx+di+0x0],bx
      53:	3a 27                	cmp    ah,BYTE PTR [bx]
      55:	5d                   	pop    bp
      56:	00 fa                	add    dl,bh
      58:	10 81 01 d6          	adc    BYTE PTR [bx+di-0x29ff],al
      5c:	14 65                	adc    al,0x65
      5e:	00 f4                	add    ah,dh
      60:	4f                   	dec    di
      61:	71 00                	jno    0x63
      63:	32 16 8d 00          	xor    dl,BYTE PTR ds:0x8d
      67:	ec                   	in     al,dx
      68:	30 c5                	xor    ch,al
      6a:	00 51 1b             	add    BYTE PTR [bx+di+0x1b],dl
      6d:	c5 01                	lds    ax,DWORD PTR [bx+di]
      6f:	38 50 79             	cmp    BYTE PTR [bx+si+0x79],dl
      72:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      75:	95                   	xchg   bp,ax
      76:	00 21                	add    BYTE PTR [bx+di],ah
      78:	50                   	push   ax
      79:	51                   	push   cx
      7a:	00 5a 11             	add    BYTE PTR [bp+si+0x11],bl
      7d:	4d                   	dec    bp
      7e:	00 d9                	add    cl,bl
      80:	62 85 00 06          	bound  ax,DWORD PTR [di+0x600]
      84:	63 89 00 8f          	arpl   WORD PTR [bx+di-0x7100],cx
      88:	60                   	pusha
      89:	c1 00 3a             	rol    WORD PTR [bx+si],0x3a
      8c:	1c 6d                	sbb    al,0x6d
      8e:	00 46 44             	add    BYTE PTR [bp+0x44],al
      91:	75 00                	jne    0x93
      93:	08 61 99             	or     BYTE PTR [bx+di-0x67],ah
      96:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      99:	9d                   	popf
      9a:	00 62 5c             	add    BYTE PTR [bp+si+0x5c],ah
      9d:	c9                   	leave
      9e:	00 3a                	add    BYTE PTR [bp+si],bh
      a0:	61                   	popa
      a1:	55                   	push   bp
      a2:	00 72 3f             	add    BYTE PTR [bp+si+0x3f],dh
      a5:	ad                   	lods   ax,WORD PTR ds:[si]
      a6:	00 5f 4a             	add    BYTE PTR [bx+0x4a],bl
      a9:	b1 00                	mov    cl,0x0
      ab:	17                   	pop    ss
      ac:	3e 41                	ds inc cx
      ae:	00 62 4b             	add    BYTE PTR [bp+si+0x4b],ah
      b1:	3d 00 ed             	cmp    ax,0xed00
      b4:	3e b9 00 77          	ds mov cx,0x7700
      b8:	3e bd 00 c2          	ds mov bp,0xc200
      bc:	35 81 00             	xor    ax,0x81
      bf:	1c 48                	sbb    al,0x48
      c1:	69 00 ae 5f          	imul   ax,WORD PTR [bx+si],0x5fae
      c5:	91                   	xchg   cx,ax
      c6:	00 35                	add    BYTE PTR [di],dh
      c8:	62 a1 00 a1          	bound  sp,DWORD PTR [bx+di-0x5f00]
      cc:	1c d1                	sbb    al,0xd1
      ce:	00 b0 1c 7d          	add    BYTE PTR [bx+si+0x7d1c],dh
      d2:	00 0f                	add    BYTE PTR [bx],cl
      d4:	54                   	push   sp
      d5:	43                   	inc    bx
      d6:	75 73                	jne    0x14b
      d8:	74 6f                	je     0x149
      da:	6d                   	ins    WORD PTR es:[di],dx
      db:	4d                   	dec    bp
      dc:	61                   	popa
      dd:	73 6b                	jae    0x14a
      df:	45                   	inc    bp
      e0:	64 69 74 0c 00 01    	imul   si,WORD PTR fs:[si+0xc],0x100
      e6:	02 02                	add    al,BYTE PTR [bp+si]
      e8:	02 07                	add    al,BYTE PTR [bx]
      ea:	00 00                	add    BYTE PTR [bx+si],al
      ec:	03 02                	add    ax,WORD PTR [bp+si]
      ee:	03 1a                	add    bx,WORD PTR [bp+si]
      f0:	0f 1b 0f             	bndstx (bad),bnd1
      f3:	12 0f                	adc    cl,BYTE PTR [bx]
      f5:	87 00                	xchg   WORD PTR [bx+si],ax
      f7:	f1                   	int1
      f8:	ff f0                	push   ax
      fa:	ff                   	jmp    (bad)
      fb:	ef                   	out    dx,ax
      fc:	ff c7                	inc    di
      fe:	13 03                	adc    ax,WORD PTR [bp+di]
     100:	01 ed                	add    bp,bp
     102:	13 07                	adc    ax,WORD PTR [bx]
     104:	01 5d 14             	add    WORD PTR [di+0x14],bx
     107:	0b 01                	or     ax,WORD PTR [bx+di]
     109:	c1 16 0f 01 00       	rcl    WORD PTR ds:0x10f,0x0
     10e:	17                   	pop    ss
     10f:	13 01                	adc    ax,WORD PTR [bx+di]
     111:	7d 22                	jge    0x135
     113:	17                   	pop    ss
     114:	01 be 23 1b          	add    WORD PTR [bp+0x1b23],di
     118:	01 f2                	add    dx,si
     11a:	22 1f                	and    bl,BYTE PTR [bx]
     11c:	01 6f 23             	add    WORD PTR [bx+0x23],bp
     11f:	23 01                	and    ax,WORD PTR [bx+di]
     121:	0b 12                	or     dx,WORD PTR [bp+si]
     123:	27                   	daa
     124:	01 39                	add    WORD PTR [bx+di],di
     126:	13 2b                	adc    bp,WORD PTR [bp+di]
     128:	01 87 13 40          	add    WORD PTR [bx+0x4013],ax
     12c:	01 07                	add    WORD PTR [bx],ax
     12e:	0f 54 43 75          	andps  xmm0,XMMWORD PTR [bp+di+0x75]
     132:	73 74                	jae    0x1a8
     134:	6f                   	outs   dx,WORD PTR ds:[si]
     135:	6d                   	ins    WORD PTR es:[di],dx
     136:	4d                   	dec    bp
     137:	61                   	popa
     138:	73 6b                	jae    0x1a5
     13a:	45                   	inc    bp
     13b:	64 69 74 4f 00 ed    	imul   si,WORD PTR fs:[si+0x4f],0xed00
     141:	01 2e 0b c9          	add    WORD PTR ds:0xc90b,bp
     145:	01 0a                	add    WORD PTR [bp+si],cx
     147:	00 04                	add    BYTE PTR [si],al
     149:	4d                   	dec    bp
     14a:	61                   	popa
     14b:	73 6b                	jae    0x1b8
     14d:	00 00                	add    BYTE PTR [bx+si],al
     14f:	fd                   	std
     150:	01 00                	add    WORD PTR [bx+si],ax
     152:	00 00                	add    BYTE PTR [bx+si],al
     154:	00 00                	add    BYTE PTR [bx+si],al
     156:	00 f3                	add    bl,dh
     158:	01 fd                	add    bp,di
     15a:	00 4f 00             	add    BYTE PTR [bx+0x0],cl
     15d:	0a 02                	or     al,BYTE PTR [bp+si]
     15f:	fa                   	cli
     160:	45                   	inc    bp
     161:	d5 01                	aad    0x1
     163:	9a 1f 1b 02 cb       	call   0xcb02:0x1b1f
     168:	1f                   	pop    ds
     169:	65 01 c8             	gs add ax,cx
     16c:	11 5d 01             	adc    WORD PTR [di+0x1],bx
     16f:	cd 11                	int    0x11
     171:	79 01                	jns    0x174
     173:	3a 27                	cmp    ah,BYTE PTR [bx]
     175:	7d 01                	jge    0x178
     177:	fa                   	cli
     178:	10 3d                	adc    BYTE PTR [di],bh
     17a:	05 d6 14             	add    ax,0x14d6
     17d:	85 01                	test   WORD PTR [bx+di],ax
     17f:	f4                   	hlt
     180:	4f                   	dec    di
     181:	91                   	xchg   cx,ax
     182:	01 32                	add    WORD PTR [bp+si],si
     184:	16                   	push   ss
     185:	ad                   	lods   ax,WORD PTR ds:[si]
     186:	01 ec                	add    sp,bp
     188:	30 e5                	xor    ch,ah
     18a:	01 51 1b             	add    WORD PTR [bx+di+0x1b],dx
     18d:	ac                   	lods   al,BYTE PTR ds:[si]
     18e:	02 38                	add    bh,BYTE PTR [bx+si]
     190:	50                   	push   ax
     191:	99                   	cwd
     192:	01 63 31             	add    WORD PTR [bp+di+0x31],sp
     195:	b5 01                	mov    ch,0x1
     197:	21 50 71             	and    WORD PTR [bx+si+0x71],dx
     19a:	01 5a 11             	add    WORD PTR [bp+si+0x11],bx
     19d:	6d                   	ins    WORD PTR es:[di],dx
     19e:	01 d9                	add    cx,bx
     1a0:	62 a5 01 06          	bound  sp,DWORD PTR [di+0x601]
     1a4:	63 a9 01 8f          	arpl   WORD PTR [bx+di-0x70ff],bp
     1a8:	60                   	pusha
     1a9:	e1 01                	loope  0x1ac
     1ab:	3a 1c                	cmp    bl,BYTE PTR [si]
     1ad:	8d 01                	lea    ax,[bx+di]
     1af:	46                   	inc    si
     1b0:	44                   	inc    sp
     1b1:	95                   	xchg   bp,ax
     1b2:	01 08                	add    WORD PTR [bx+si],cx
     1b4:	61                   	popa
     1b5:	b9 01 5c             	mov    cx,0x5c01
     1b8:	61                   	popa
     1b9:	bd 01 62             	mov    bp,0x6201
     1bc:	5c                   	pop    sp
     1bd:	e9 01 3a             	jmp    0x3bc1
     1c0:	61                   	popa
     1c1:	75 01                	jne    0x1c4
     1c3:	72 3f                	jb     0x204
     1c5:	cd 01                	int    0x1
     1c7:	5f                   	pop    di
     1c8:	4a                   	dec    dx
     1c9:	d1 01                	rol    WORD PTR [bx+di],1
     1cb:	17                   	pop    ss
     1cc:	3e 61                	ds popa
     1ce:	01 62 4b             	add    WORD PTR [bp+si+0x4b],sp
     1d1:	46                   	inc    si
     1d2:	02 ed                	add    ch,ch
     1d4:	3e d9 01             	fld    DWORD PTR ds:[bx+di]
     1d7:	77 3e                	ja     0x217
     1d9:	dd 01                	fld    QWORD PTR [bx+di]
     1db:	c2 35 a1             	ret    0xa135
     1de:	01 1c                	add    WORD PTR [si],bx
     1e0:	48                   	dec    ax
     1e1:	89 01                	mov    WORD PTR [bx+di],ax
     1e3:	ae                   	scas   al,BYTE PTR es:[di]
     1e4:	5f                   	pop    di
     1e5:	b1 01                	mov    cl,0x1
     1e7:	35 62 c1             	xor    ax,0xc162
     1ea:	01 a1 1c f1          	add    WORD PTR [bx+di-0xee4],sp
     1ee:	01 b0 1c 9d          	add    WORD PTR [bx+si-0x62e4],si
     1f2:	01 09                	add    WORD PTR [bx+di],cx
     1f4:	54                   	push   sp
     1f5:	4d                   	dec    bp
     1f6:	61                   	popa
     1f7:	73 6b                	jae    0x264
     1f9:	45                   	inc    bp
     1fa:	64 69 74 07 09 54    	imul   si,WORD PTR fs:[si+0x7],0x5409
     200:	4d                   	dec    bp
     201:	61                   	popa
     202:	73 6b                	jae    0x26f
     204:	45                   	inc    bp
     205:	64 69 74 6f 01 0e    	imul   si,WORD PTR fs:[si+0x6f],0xe01
     20b:	02 2d                	add    ch,BYTE PTR [di]
     20d:	01 48 03             	add    WORD PTR [bx+si+0x3],cx
     210:	2f                   	das
     211:	00 04                	add    BYTE PTR [si],al
     213:	4d                   	dec    bp
     214:	61                   	popa
     215:	73 6b                	jae    0x282
     217:	26 00 07             	add    BYTE PTR es:[bx],al
     21a:	23 3e 02 de          	and    di,WORD PTR ds:0xde02
     21e:	00 ff                	add    bh,bh
     220:	ff                   	call   (bad)
     221:	de 00                	fiadd  WORD PTR [bx+si]
     223:	ff                   	(bad)
     224:	ff 01                	inc    WORD PTR [bx+di]
     226:	00 00                	add    BYTE PTR [bx+si],al
     228:	00 00                	add    BYTE PTR [bx+si],al
     22a:	80 01 00             	add    BYTE PTR [bx+di],0x0
     22d:	00 00                	add    BYTE PTR [bx+si],al
     22f:	0a 00                	or     al,BYTE PTR [bx+si]
     231:	0a 41 75             	or     al,BYTE PTR [bx+di+0x75]
     234:	74 6f                	je     0x2a5
     236:	53                   	push   bx
     237:	65 6c                	gs ins BYTE PTR es:[di],dx
     239:	65 63 74 07          	arpl   WORD PTR gs:[si+0x7],si
     23d:	23 c2                	and    ax,dx
     23f:	02 dd                	add    bl,ch
     241:	00 ff                	add    bh,bh
     243:	ff 9c 47 67          	call   DWORD PTR [si+0x6747]
     247:	02 01                	add    al,BYTE PTR [bx+di]
     249:	00 00                	add    BYTE PTR [bx+si],al
     24b:	00 00                	add    BYTE PTR [bx+si],al
     24d:	80 01 00             	add    BYTE PTR [bx+di],0x0
     250:	00 00                	add    BYTE PTR [bx+si],al
     252:	0b 00                	or     ax,WORD PTR [bx+si]
     254:	08 41 75             	or     BYTE PTR [bx+di+0x75],al
     257:	74 6f                	je     0x2c8
     259:	53                   	push   bx
     25a:	69 7a 65 d4 02       	imul   di,WORD PTR [bp+si+0x65],0x2d4
     25f:	66 18 da             	data32 sbb dl,bl
     262:	00 ff                	add    bh,bh
     264:	ff                   	(bad)
     265:	bf 47 83             	mov    di,0x8347
     268:	02 01                	add    al,BYTE PTR [bx+di]
     26a:	00 00                	add    BYTE PTR [bx+si],al
     26c:	00 00                	add    BYTE PTR [bx+si],al
     26e:	80 01 00             	add    BYTE PTR [bx+di],0x0
     271:	00 00                	add    BYTE PTR [bx+si],al
     273:	0c 00                	or     al,0x0
     275:	0b 42 6f             	or     ax,WORD PTR [bp+si+0x6f]
     278:	72 64                	jb     0x2de
     27a:	65 72 53             	gs jb  0x2d0
     27d:	74 79                	je     0x2f8
     27f:	6c                   	ins    BYTE PTR es:[di],dx
     280:	65 29 0a             	sub    WORD PTR gs:[bp+si],cx
     283:	8b 02                	mov    ax,WORD PTR [bp+si]
     285:	e1 00                	loope  0x287
     287:	ff                   	(bad)
     288:	ff                   	jmp    (bad)
     289:	ec                   	in     al,dx
     28a:	47                   	inc    di
     28b:	3e 04 01             	ds add al,0x1
     28e:	00 00                	add    BYTE PTR [bx+si],al
     290:	00 00                	add    BYTE PTR [bx+si],al
     292:	80 00 00             	add    BYTE PTR [bx+si],0x0
     295:	00 00                	add    BYTE PTR [bx+si],al
     297:	0d 00 08             	or     ax,0x800
     29a:	43                   	inc    bx
     29b:	68 61 72             	push   0x7261
     29e:	43                   	inc    bx
     29f:	61                   	popa
     2a0:	73 65                	jae    0x307
     2a2:	02 00                	add    al,BYTE PTR [bx+si]
     2a4:	65 03 38             	add    di,WORD PTR gs:[bx+si]
     2a7:	00 ff                	add    bh,bh
     2a9:	ff d5                	call   bp
     2ab:	1e                   	push   ds
     2ac:	b0 02                	mov    al,0x2
     2ae:	17                   	pop    ss
     2af:	1f                   	pop    ds
     2b0:	ca 02 00             	retf   0x2
     2b3:	80 fa ff             	cmp    dl,0xff
     2b6:	ff                   	(bad)
     2b7:	ff 0e 00 05          	dec    WORD PTR ds:0x500
     2bb:	43                   	inc    bx
     2bc:	6f                   	outs   dx,WORD PTR ds:[si]
     2bd:	6c                   	ins    BYTE PTR es:[di],dx
     2be:	6f                   	outs   dx,WORD PTR ds:[si]
     2bf:	72 07                	jb     0x2c8
     2c1:	23 24                	and    sp,WORD PTR [si]
     2c3:	03 a5 00 ff          	add    sp,WORD PTR [di-0x100]
     2c7:	ff 22                	jmp    WORD PTR [bp+si]
     2c9:	63 ce                	arpl   si,cx
     2cb:	02 54 63             	add    dl,BYTE PTR [si+0x63]
     2ce:	e0 02                	loopne 0x2d2
     2d0:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     2d4:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     2d8:	05 43 74             	add    ax,0x7443
     2db:	6c                   	ins    BYTE PTR es:[di],dx
     2dc:	33 44 64             	xor    ax,WORD PTR [si+0x64]
     2df:	00 03                	add    BYTE PTR [bp+di],al
     2e1:	03 3e 00 ff          	add    di,WORD PTR ds:0xff00
     2e5:	ff                   	(bad)
     2e6:	3e 00 ff             	ds add bh,bh
     2e9:	ff 01                	inc    WORD PTR [bx+di]
     2eb:	00 00                	add    BYTE PTR [bx+si],al
     2ed:	00 00                	add    BYTE PTR [bx+si],al
     2ef:	80 f4 ff             	xor    ah,0xff
     2f2:	ff                   	(bad)
     2f3:	ff 10                	call   WORD PTR [bx+si]
     2f5:	00 0a                	add    BYTE PTR [bp+si],cl
     2f7:	44                   	inc    sp
     2f8:	72 61                	jb     0x35b
     2fa:	67 43                	addr32 inc bx
     2fc:	75 72                	jne    0x370
     2fe:	73 6f                	jae    0x36f
     300:	72 25                	jb     0x327
     302:	01 2c                	add    WORD PTR [si],bp
     304:	03 2e 00 ff          	add    bp,WORD PTR ds:0xff00
     308:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     30c:	ff 01                	inc    WORD PTR [bx+di]
     30e:	00 00                	add    BYTE PTR [bx+si],al
     310:	00 00                	add    BYTE PTR [bx+si],al
     312:	80 00 00             	add    BYTE PTR [bx+si],0x0
     315:	00 00                	add    BYTE PTR [bx+si],al
     317:	11 00                	adc    WORD PTR [bx+si],ax
     319:	08 44 72             	or     BYTE PTR [si+0x72],al
     31c:	61                   	popa
     31d:	67 4d                	addr32 dec bp
     31f:	6f                   	outs   dx,WORD PTR ds:[si]
     320:	64 65 07             	fs gs pop es
     323:	23 44 03             	and    ax,WORD PTR [si+0x3]
     326:	2a 00                	sub    al,BYTE PTR [bx+si]
     328:	ff                   	(bad)
     329:	ff                   	(bad)
     32a:	b8 1c 6d             	mov    ax,0x6d1c
     32d:	03 01                	add    ax,WORD PTR [bx+di]
     32f:	00 00                	add    BYTE PTR [bx+si],al
     331:	00 00                	add    BYTE PTR [bx+si],al
     333:	80 01 00             	add    BYTE PTR [bx+di],0x0
     336:	00 00                	add    BYTE PTR [bx+si],al
     338:	12 00                	adc    al,BYTE PTR [bx+si]
     33a:	07                   	pop    es
     33b:	45                   	inc    bp
     33c:	6e                   	outs   dx,BYTE PTR ds:[si]
     33d:	61                   	popa
     33e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     341:	64 62 23             	bound  sp,DWORD PTR fs:[bp+di]
     344:	82 03 fe             	add    BYTE PTR [bp+di],0xfe
     347:	17                   	pop    ss
     348:	4c                   	dec    sp
     349:	03 2a                	add    bp,WORD PTR [bp+si]
     34b:	19 86 03 01          	sbb    WORD PTR [bp+0x103],ax
     34f:	00 00                	add    BYTE PTR [bx+si],al
     351:	00 00                	add    BYTE PTR [bx+si],al
     353:	80 00 00             	add    BYTE PTR [bx+si],0x0
     356:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
     35a:	08 45 64             	or     BYTE PTR [di+0x64],al
     35d:	69 74 4d 61 73       	imul   si,WORD PTR [si+0x4d],0x7361
     362:	6b 22 03             	imul   sp,WORD PTR [bp+si],0x3
     365:	ff                   	(bad)
     366:	ff 34                	push   WORD PTR [si]
     368:	00 ff                	add    bh,bh
     36a:	ff                   	jmp    (bad)
     36b:	eb 1d                	jmp    0x38a
     36d:	71 03                	jno    0x372
     36f:	08 1e ac 03          	or     BYTE PTR ds:0x3ac,bl
     373:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     377:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     37b:	04 46                	add    al,0x46
     37d:	6f                   	outs   dx,WORD PTR ds:[si]
     37e:	6e                   	outs   dx,BYTE PTR ds:[si]
     37f:	74 d4                	je     0x355
     381:	22 a4 03 55          	and    ah,BYTE PTR [si+0x5503]
     385:	1a 8a 03 6b          	sbb    cl,BYTE PTR [bp+si+0x6b03]
     389:	1a 04                	sbb    al,BYTE PTR [si]
     38b:	05 01 00             	add    ax,0x1
     38e:	00 00                	add    BYTE PTR [bx+si],al
     390:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     394:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     398:	09 4d 61             	or     WORD PTR [di+0x61],cx
     39b:	78 4c                	js     0x3e9
     39d:	65 6e                	outs   dx,BYTE PTR gs:[si]
     39f:	67 74 68             	addr32 je 0x40a
     3a2:	07                   	pop    es
     3a3:	23 c8                	and    cx,ax
     3a5:	03 2c                	add    bp,WORD PTR [si]
     3a7:	00 ff                	add    bh,bh
     3a9:	ff 32                	push   WORD PTR [bp+si]
     3ab:	1f                   	pop    ds
     3ac:	d0 03                	rol    BYTE PTR [bp+di],1
     3ae:	01 00                	add    WORD PTR [bx+si],ax
     3b0:	00 00                	add    BYTE PTR [bx+si],al
     3b2:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     3b6:	00 00                	add    BYTE PTR [bx+si],al
     3b8:	16                   	push   ss
     3b9:	00 0b                	add    BYTE PTR [bp+di],cl
     3bb:	50                   	push   ax
     3bc:	61                   	popa
     3bd:	72 65                	jb     0x424
     3bf:	6e                   	outs   dx,BYTE PTR ds:[si]
     3c0:	74 43                	je     0x405
     3c2:	6f                   	outs   dx,WORD PTR ds:[si]
     3c3:	6c                   	ins    BYTE PTR es:[di],dx
     3c4:	6f                   	outs   dx,WORD PTR ds:[si]
     3c5:	72 07                	jb     0x3ce
     3c7:	23 ec                	and    bp,sp
     3c9:	03 a6 00 ff          	add    sp,WORD PTR [bp-0x100]
     3cd:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     3d0:	f4                   	hlt
     3d1:	03 01                	add    ax,WORD PTR [bx+di]
     3d3:	00 00                	add    BYTE PTR [bx+si],al
     3d5:	00 00                	add    BYTE PTR [bx+si],al
     3d7:	80 01 00             	add    BYTE PTR [bx+di],0x0
     3da:	00 00                	add    BYTE PTR [bx+si],al
     3dc:	17                   	pop    ss
     3dd:	00 0b                	add    BYTE PTR [bp+di],cl
     3df:	50                   	push   ax
     3e0:	61                   	popa
     3e1:	72 65                	jb     0x448
     3e3:	6e                   	outs   dx,BYTE PTR ds:[si]
     3e4:	74 43                	je     0x429
     3e6:	74 6c                	je     0x454
     3e8:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     3eb:	23 0f                	and    cx,WORD PTR [bx]
     3ed:	04 2b                	add    al,0x2b
     3ef:	00 ff                	add    bh,bh
     3f1:	ff                   	(bad)
     3f2:	3e 1e                	ds push ds
     3f4:	17                   	pop    ss
     3f5:	04 01                	add    al,0x1
     3f7:	00 00                	add    BYTE PTR [bx+si],al
     3f9:	00 00                	add    BYTE PTR [bx+si],al
     3fb:	80 01 00             	add    BYTE PTR [bx+di],0x0
     3fe:	00 00                	add    BYTE PTR [bx+si],al
     400:	18 00                	sbb    BYTE PTR [bx+si],al
     402:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     405:	72 65                	jb     0x46c
     407:	6e                   	outs   dx,BYTE PTR ds:[si]
     408:	74 46                	je     0x450
     40a:	6f                   	outs   dx,WORD PTR ds:[si]
     40b:	6e                   	outs   dx,BYTE PTR ds:[si]
     40c:	74 07                	je     0x415
     40e:	23 36 04 49          	and    si,WORD PTR ds:0x4904
     412:	00 ff                	add    bh,bh
     414:	ff a1 1e a6          	jmp    WORD PTR [bx+di-0x59e2]
     418:	04 01                	add    al,0x1
     41a:	00 00                	add    BYTE PTR [bx+si],al
     41c:	00 00                	add    BYTE PTR [bx+si],al
     41e:	80 01 00             	add    BYTE PTR [bx+di],0x0
     421:	00 00                	add    BYTE PTR [bx+si],al
     423:	19 00                	sbb    WORD PTR [bx+si],ax
     425:	0e                   	push   cs
     426:	50                   	push   ax
     427:	61                   	popa
     428:	72 65                	jb     0x48f
     42a:	6e                   	outs   dx,BYTE PTR ds:[si]
     42b:	74 53                	je     0x480
     42d:	68 6f 77             	push   0x776f
     430:	48                   	dec    ax
     431:	69 6e 74 28 23       	imul   bp,WORD PTR [bp+0x74],0x2328
     436:	7d 04                	jge    0x43c
     438:	db 00                	fild   DWORD PTR [bx+si]
     43a:	ff                   	(bad)
     43b:	ff 08                	dec    WORD PTR [bx+si]
     43d:	49                   	dec    cx
     43e:	85 04                	test   WORD PTR [si],ax
     440:	01 00                	add    WORD PTR [bx+si],ax
     442:	00 00                	add    BYTE PTR [bx+si],al
     444:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     448:	00 00                	add    BYTE PTR [bx+si],al
     44a:	1a 00                	sbb    al,BYTE PTR [bx+si]
     44c:	0c 50                	or     al,0x50
     44e:	61                   	popa
     44f:	73 73                	jae    0x4c4
     451:	77 6f                	ja     0x4c2
     453:	72 64                	jb     0x4b9
     455:	43                   	inc    bx
     456:	68 61 72             	push   0x7261
     459:	0d 04 ff             	or     ax,0xff04
     45c:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     45f:	ff                   	(bad)
     460:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     463:	ff                   	(bad)
     464:	ff 01                	inc    WORD PTR [bx+di]
     466:	00 00                	add    BYTE PTR [bx+si],al
     468:	00 00                	add    BYTE PTR [bx+si],al
     46a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     46d:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     471:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     474:	70 75                	jo     0x4eb
     476:	70 4d                	jo     0x4c5
     478:	65 6e                	outs   dx,BYTE PTR gs:[si]
     47a:	75 07                	jne    0x483
     47c:	23 9e 04 dc          	and    bx,WORD PTR [bp-0x23fc]
     480:	00 ff                	add    bh,bh
     482:	ff                   	(bad)
     483:	79 49                	jns    0x4ce
     485:	7c 11                	jl     0x498
     487:	01 00                	add    WORD PTR [bx+si],ax
     489:	00 00                	add    BYTE PTR [bx+si],al
     48b:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     48f:	00 00                	add    BYTE PTR [bx+si],al
     491:	1c 00                	sbb    al,0x0
     493:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
     496:	61                   	popa
     497:	64 4f                	fs dec di
     499:	6e                   	outs   dx,BYTE PTR ds:[si]
     49a:	6c                   	ins    BYTE PTR es:[di],dx
     49b:	79 07                	jns    0x4a4
     49d:	23 e0                	and    sp,ax
     49f:	04 48                	add    al,0x48
     4a1:	00 ff                	add    bh,bh
     4a3:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     4a6:	aa                   	stos   BYTE PTR es:[di],al
     4a7:	04 23                	add    al,0x23
     4a9:	1e                   	push   ds
     4aa:	bf 04 00             	mov    di,0x4
     4ad:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4b0:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
     4b4:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     4b7:	6f                   	outs   dx,WORD PTR ds:[si]
     4b8:	77 48                	ja     0x502
     4ba:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     4bf:	c3                   	ret
     4c0:	04 a6                	add    al,0xa6
     4c2:	63 c7                	arpl   di,ax
     4c4:	04 60                	add    al,0x60
     4c6:	64 e8 04 01          	fs call 0x5ce
     4ca:	00 00                	add    BYTE PTR [bx+si],al
     4cc:	00 00                	add    BYTE PTR [bx+si],al
     4ce:	80 ff ff             	cmp    bh,0xff
     4d1:	ff                   	(bad)
     4d2:	ff 1e 00 08          	call   DWORD PTR ds:0x800
     4d6:	54                   	push   sp
     4d7:	61                   	popa
     4d8:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     4db:	64 65 72 07          	fs gs jb 0x4e6
     4df:	23 00                	and    ax,WORD PTR [bx+si]
     4e1:	05 a4 00             	add    ax,0xa4
     4e4:	ff                   	(bad)
     4e5:	ff 88 64 25          	dec    WORD PTR [bx+si+0x2564]
     4e9:	05 01 00             	add    ax,0x1
     4ec:	00 00                	add    BYTE PTR [bx+si],al
     4ee:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     4f2:	00 00                	add    BYTE PTR [bx+si],al
     4f4:	09 00                	or     WORD PTR [bx+si],ax
     4f6:	07                   	pop    es
     4f7:	54                   	push   sp
     4f8:	61                   	popa
     4f9:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     4fc:	6f                   	outs   dx,WORD PTR ds:[si]
     4fd:	70 62                	jo     0x561
     4ff:	23 1d                	and    bx,WORD PTR [di]
     501:	05 24 15             	add    ax,0x1524
     504:	08 05                	or     BYTE PTR [di],al
     506:	b5 15                	mov    ch,0x15
     508:	0a 11                	or     dl,BYTE PTR [bx+di]
     50a:	01 00                	add    WORD PTR [bx+si],ax
     50c:	00 00                	add    BYTE PTR [bx+si],al
     50e:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     512:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
     516:	04 54                	add    al,0x54
     518:	65 78 74             	gs js  0x58f
     51b:	07                   	pop    es
     51c:	23 1d                	and    bx,WORD PTR [di]
     51e:	09 29                	or     WORD PTR [bx+di],bp
     520:	00 ff                	add    bh,bh
     522:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     525:	a1 05 01             	mov    ax,ds:0x105
     528:	00 00                	add    BYTE PTR [bx+si],al
     52a:	00 00                	add    BYTE PTR [bx+si],al
     52c:	80 01 00             	add    BYTE PTR [bx+di],0x0
     52f:	00 00                	add    BYTE PTR [bx+si],al
     531:	20 00                	and    BYTE PTR [bx+si],al
     533:	07                   	pop    es
     534:	56                   	push   si
     535:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     53a:	65 71 00             	gs jno 0x53d
     53d:	5e                   	pop    si
     53e:	05 e4 00             	add    ax,0xe4
     541:	ff                   	(bad)
     542:	ff e4                	jmp    sp
     544:	00 ff                	add    bh,bh
     546:	ff 01                	inc    WORD PTR [bx+di]
     548:	00 00                	add    BYTE PTR [bx+si],al
     54a:	00 00                	add    BYTE PTR [bx+si],al
     54c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     54f:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     553:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     556:	43                   	inc    bx
     557:	68 61 6e             	push   0x6e61
     55a:	67 65 71 00          	addr32 gs jno 0x55e
     55e:	7e 05                	jle    0x565
     560:	7a 00                	jp     0x562
     562:	ff                   	(bad)
     563:	ff                   	(bad)
     564:	7a 00                	jp     0x566
     566:	ff                   	(bad)
     567:	ff 01                	inc    WORD PTR [bx+di]
     569:	00 00                	add    BYTE PTR [bx+si],al
     56b:	00 00                	add    BYTE PTR [bx+si],al
     56d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     570:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     574:	07                   	pop    es
     575:	4f                   	dec    di
     576:	6e                   	outs   dx,BYTE PTR ds:[si]
     577:	43                   	inc    bx
     578:	6c                   	ins    BYTE PTR es:[di],dx
     579:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     57e:	09 06 82 00          	or     WORD PTR ds:0x82,ax
     582:	ff                   	(bad)
     583:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     587:	ff 01                	inc    WORD PTR [bx+di]
     589:	00 00                	add    BYTE PTR [bx+si],al
     58b:	00 00                	add    BYTE PTR [bx+si],al
     58d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     590:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     594:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     597:	44                   	inc    sp
     598:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     59b:	6c                   	ins    BYTE PTR es:[di],dx
     59c:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     5a1:	c4 05                	les    ax,DWORD PTR [di]
     5a3:	62 00                	bound  ax,DWORD PTR [bx+si]
     5a5:	ff                   	(bad)
     5a6:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     5a9:	ff                   	(bad)
     5aa:	ff 01                	inc    WORD PTR [bx+di]
     5ac:	00 00                	add    BYTE PTR [bx+si],al
     5ae:	00 00                	add    BYTE PTR [bx+si],al
     5b0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5b3:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     5b7:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     5ba:	44                   	inc    sp
     5bb:	72 61                	jb     0x61e
     5bd:	67 44                	addr32 inc sp
     5bf:	72 6f                	jb     0x630
     5c1:	70 80                	jo     0x543
     5c3:	02 e7                	add    ah,bh
     5c5:	05 6a 00             	add    ax,0x6a
     5c8:	ff                   	(bad)
     5c9:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     5cc:	ff                   	(bad)
     5cd:	ff 01                	inc    WORD PTR [bx+di]
     5cf:	00 00                	add    BYTE PTR [bx+si],al
     5d1:	00 00                	add    BYTE PTR [bx+si],al
     5d3:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5d6:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     5da:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     5dd:	44                   	inc    sp
     5de:	72 61                	jb     0x641
     5e0:	67 4f                	addr32 dec di
     5e2:	76 65                	jbe    0x649
     5e4:	72 32                	jb     0x618
     5e6:	03 48 06             	add    cx,WORD PTR [bx+si+0x6]
     5e9:	72 00                	jb     0x5eb
     5eb:	ff                   	(bad)
     5ec:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     5ef:	ff                   	(bad)
     5f0:	ff 01                	inc    WORD PTR [bx+di]
     5f2:	00 00                	add    BYTE PTR [bx+si],al
     5f4:	00 00                	add    BYTE PTR [bx+si],al
     5f6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     5f9:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
     5fd:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     600:	45                   	inc    bp
     601:	6e                   	outs   dx,BYTE PTR ds:[si]
     602:	64 44                	fs inc sp
     604:	72 61                	jb     0x667
     606:	67 71 00             	addr32 jno 0x609
     609:	29 06 c8 00          	sub    WORD PTR ds:0xc8,ax
     60d:	ff                   	(bad)
     60e:	ff c8                	dec    ax
     610:	00 ff                	add    bh,bh
     612:	ff 01                	inc    WORD PTR [bx+di]
     614:	00 00                	add    BYTE PTR [bx+si],al
     616:	00 00                	add    BYTE PTR [bx+si],al
     618:	80 00 00             	add    BYTE PTR [bx+si],0x0
     61b:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
     61f:	07                   	pop    es
     620:	4f                   	dec    di
     621:	6e                   	outs   dx,BYTE PTR ds:[si]
     622:	45                   	inc    bp
     623:	6e                   	outs   dx,BYTE PTR ds:[si]
     624:	74 65                	je     0x68b
     626:	72 71                	jb     0x699
     628:	00 ff                	add    bh,bh
     62a:	ff d0                	call   ax
     62c:	00 ff                	add    bh,bh
     62e:	ff d0                	call   ax
     630:	00 ff                	add    bh,bh
     632:	ff 01                	inc    WORD PTR [bx+di]
     634:	00 00                	add    BYTE PTR [bx+si],al
     636:	00 00                	add    BYTE PTR [bx+si],al
     638:	80 00 00             	add    BYTE PTR [bx+si],0x0
     63b:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
     63f:	06                   	push   es
     640:	4f                   	dec    di
     641:	6e                   	outs   dx,BYTE PTR ds:[si]
     642:	45                   	inc    bp
     643:	78 69                	js     0x6ae
     645:	74 1a                	je     0x661
     647:	02 6a 06             	add    ch,BYTE PTR [bp+si+0x6]
     64a:	b0 00                	mov    al,0x0
     64c:	ff                   	(bad)
     64d:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     651:	ff 01                	inc    WORD PTR [bx+di]
     653:	00 00                	add    BYTE PTR [bx+si],al
     655:	00 00                	add    BYTE PTR [bx+si],al
     657:	80 00 00             	add    BYTE PTR [bx+si],0x0
     65a:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
     65e:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     661:	4b                   	dec    bx
     662:	65 79 44             	gs jns 0x6a9
     665:	6f                   	outs   dx,WORD PTR ds:[si]
     666:	77 6e                	ja     0x6d6
     668:	54                   	push   sp
     669:	02 8d 06 b8          	add    cl,BYTE PTR [di-0x47fa]
     66d:	00 ff                	add    bh,bh
     66f:	ff                   	(bad)
     670:	b8 00 ff             	mov    ax,0xff00
     673:	ff 01                	inc    WORD PTR [bx+di]
     675:	00 00                	add    BYTE PTR [bx+si],al
     677:	00 00                	add    BYTE PTR [bx+si],al
     679:	80 00 00             	add    BYTE PTR [bx+si],0x0
     67c:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
     680:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     683:	4b                   	dec    bx
     684:	65 79 50             	gs jns 0x6d7
     687:	72 65                	jb     0x6ee
     689:	73 73                	jae    0x6fe
     68b:	1a 02                	sbb    al,BYTE PTR [bp+si]
     68d:	ad                   	lods   ax,WORD PTR ds:[si]
     68e:	06                   	push   es
     68f:	c0 00 ff             	rol    BYTE PTR [bx+si],0xff
     692:	ff c0                	inc    ax
     694:	00 ff                	add    bh,bh
     696:	ff 01                	inc    WORD PTR [bx+di]
     698:	00 00                	add    BYTE PTR [bx+si],al
     69a:	00 00                	add    BYTE PTR [bx+si],al
     69c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     69f:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
     6a3:	07                   	pop    es
     6a4:	4f                   	dec    di
     6a5:	6e                   	outs   dx,BYTE PTR ds:[si]
     6a6:	4b                   	dec    bx
     6a7:	65 79 55             	gs jns 0x6ff
     6aa:	70 71                	jo     0x71d
     6ac:	01 d1                	add    cx,dx
     6ae:	06                   	push   es
     6af:	4a                   	dec    dx
     6b0:	00 ff                	add    bh,bh
     6b2:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     6b5:	ff                   	(bad)
     6b6:	ff 01                	inc    WORD PTR [bx+di]
     6b8:	00 00                	add    BYTE PTR [bx+si],al
     6ba:	00 00                	add    BYTE PTR [bx+si],al
     6bc:	80 00 00             	add    BYTE PTR [bx+si],0x0
     6bf:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
     6c3:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     6c6:	4d                   	dec    bp
     6c7:	6f                   	outs   dx,WORD PTR ds:[si]
     6c8:	75 73                	jne    0x73d
     6ca:	65 44                	gs inc sp
     6cc:	6f                   	outs   dx,WORD PTR ds:[si]
     6cd:	77 6e                	ja     0x73d
     6cf:	ce                   	into
     6d0:	01 f5                	add    bp,si
     6d2:	06                   	push   es
     6d3:	52                   	push   dx
     6d4:	00 ff                	add    bh,bh
     6d6:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     6d9:	ff                   	(bad)
     6da:	ff 01                	inc    WORD PTR [bx+di]
     6dc:	00 00                	add    BYTE PTR [bx+si],al
     6de:	00 00                	add    BYTE PTR [bx+si],al
     6e0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     6e3:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
     6e7:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     6ea:	4d                   	dec    bp
     6eb:	6f                   	outs   dx,WORD PTR ds:[si]
     6ec:	75 73                	jne    0x761
     6ee:	65 4d                	gs dec bp
     6f0:	6f                   	outs   dx,WORD PTR ds:[si]
     6f1:	76 65                	jbe    0x758
     6f3:	71 01                	jno    0x6f6
     6f5:	fa                   	cli
     6f6:	11 5a 00             	adc    WORD PTR [bp+si+0x0],bx
     6f9:	ff                   	(bad)
     6fa:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     6fd:	ff                   	(bad)
     6fe:	ff 01                	inc    WORD PTR [bx+di]
     700:	00 00                	add    BYTE PTR [bx+si],al
     702:	00 00                	add    BYTE PTR [bx+si],al
     704:	80 00 00             	add    BYTE PTR [bx+si],0x0
     707:	00 80 2e 00          	add    BYTE PTR [bx+si+0x2e],al
     70b:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     70e:	4d                   	dec    bp
     70f:	6f                   	outs   dx,WORD PTR ds:[si]
     710:	75 73                	jne    0x785
     712:	65 55                	gs push bp
     714:	70 c8                	jo     0x6de
     716:	02 00                	add    al,BYTE PTR [bx+si]
     718:	00 c6                	add    dh,al
     71a:	46                   	inc    si
     71b:	ff 01                	inc    WORD PTR [bx+di]
     71d:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     720:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     723:	03 f8                	add    di,ax
     725:	26 8a 05             	mov    al,BYTE PTR es:[di]
     728:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
     72b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     72e:	26 8a 05             	mov    al,BYTE PTR es:[di]
     731:	30 e4                	xor    ah,ah
     733:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
     736:	7d 07                	jge    0x73f
     738:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     73c:	e9 f7 00             	jmp    0x836
     73f:	83 7e 04 01          	cmp    WORD PTR [bp+0x4],0x1
     743:	7e 2c                	jle    0x771
     745:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     748:	48                   	dec    ax
     749:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     74c:	03 f8                	add    di,ax
     74e:	26 80 3d 5c          	cmp    BYTE PTR es:[di],0x5c
     752:	75 1d                	jne    0x771
     754:	83 7e 04 02          	cmp    WORD PTR [bp+0x4],0x2
     758:	7e 10                	jle    0x76a
     75a:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     75d:	48                   	dec    ax
     75e:	48                   	dec    ax
     75f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     762:	03 f8                	add    di,ax
     764:	26 80 3d 5c          	cmp    BYTE PTR es:[di],0x5c
     768:	74 07                	je     0x771
     76a:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     76e:	e9 c5 00             	jmp    0x836
     771:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
     774:	3a 06 fb 0b          	cmp    al,BYTE PTR ds:0xbfb
     778:	75 1d                	jne    0x797
     77a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     77d:	26 80 3d 04          	cmp    BYTE PTR es:[di],0x4
     781:	72 14                	jb     0x797
     783:	26 8a 05             	mov    al,BYTE PTR es:[di]
     786:	30 e4                	xor    ah,ah
     788:	2d 04 00             	sub    ax,0x4
     78b:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
     78e:	7d 07                	jge    0x797
     790:	c6 46 ff 06          	mov    BYTE PTR [bp-0x1],0x6
     794:	e9 9f 00             	jmp    0x836
     797:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     79a:	26 80 3d 04          	cmp    BYTE PTR es:[di],0x4
     79e:	72 38                	jb     0x7d8
     7a0:	26 8a 05             	mov    al,BYTE PTR es:[di]
     7a3:	30 e4                	xor    ah,ah
     7a5:	2d 04 00             	sub    ax,0x4
     7a8:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
     7ab:	7d 2b                	jge    0x7d8
     7ad:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     7b0:	48                   	dec    ax
     7b1:	03 f8                	add    di,ax
     7b3:	26 8a 05             	mov    al,BYTE PTR es:[di]
     7b6:	3a 06 fb 0b          	cmp    al,BYTE PTR ds:0xbfb
     7ba:	75 1c                	jne    0x7d8
     7bc:	83 7e 04 02          	cmp    WORD PTR [bp+0x4],0x2
     7c0:	7e 10                	jle    0x7d2
     7c2:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     7c5:	48                   	dec    ax
     7c6:	48                   	dec    ax
     7c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7ca:	03 f8                	add    di,ax
     7cc:	26 80 3d 5c          	cmp    BYTE PTR es:[di],0x5c
     7d0:	74 06                	je     0x7d8
     7d2:	c6 46 ff 07          	mov    BYTE PTR [bp-0x1],0x7
     7d6:	eb 5e                	jmp    0x836
     7d8:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
     7db:	3c 2f                	cmp    al,0x2f
     7dd:	74 04                	je     0x7e3
     7df:	3c 3a                	cmp    al,0x3a
     7e1:	75 06                	jne    0x7e9
     7e3:	c6 46 ff 02          	mov    BYTE PTR [bp-0x1],0x2
     7e7:	eb 4d                	jmp    0x836
     7e9:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
     7ec:	3c 21                	cmp    al,0x21
     7ee:	74 0c                	je     0x7fc
     7f0:	3c 3c                	cmp    al,0x3c
     7f2:	74 08                	je     0x7fc
     7f4:	3c 3e                	cmp    al,0x3e
     7f6:	74 04                	je     0x7fc
     7f8:	3c 5c                	cmp    al,0x5c
     7fa:	75 06                	jne    0x802
     7fc:	c6 46 ff 03          	mov    BYTE PTR [bp-0x1],0x3
     800:	eb 34                	jmp    0x836
     802:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
     805:	3c 23                	cmp    al,0x23
     807:	74 10                	je     0x819
     809:	3c 39                	cmp    al,0x39
     80b:	74 0c                	je     0x819
     80d:	3c 61                	cmp    al,0x61
     80f:	74 08                	je     0x819
     811:	3c 63                	cmp    al,0x63
     813:	74 04                	je     0x819
     815:	3c 6c                	cmp    al,0x6c
     817:	75 06                	jne    0x81f
     819:	c6 46 ff 05          	mov    BYTE PTR [bp-0x1],0x5
     81d:	eb 17                	jmp    0x836
     81f:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
     822:	3c 30                	cmp    al,0x30
     824:	74 0c                	je     0x832
     826:	3c 41                	cmp    al,0x41
     828:	74 08                	je     0x832
     82a:	3c 43                	cmp    al,0x43
     82c:	74 04                	je     0x832
     82e:	3c 4c                	cmp    al,0x4c
     830:	75 04                	jne    0x836
     832:	c6 46 ff 04          	mov    BYTE PTR [bp-0x1],0x4
     836:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     839:	c9                   	leave
     83a:	c2 06 00             	ret    0x6
     83d:	c8 08 00 00          	enter  0x8,0x0
     841:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     845:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     848:	26 8a 05             	mov    al,BYTE PTR es:[di]
     84b:	30 e4                	xor    ah,ah
     84d:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     850:	b8 01 00             	mov    ax,0x1
     853:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     856:	7f 6d                	jg     0x8c5
     858:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     85b:	eb 03                	jmp    0x860
     85d:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     860:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     863:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     866:	03 f8                	add    di,ax
     868:	26 8a 05             	mov    al,BYTE PTR es:[di]
     86b:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
     86e:	80 7e fb 21          	cmp    BYTE PTR [bp-0x5],0x21
     872:	75 06                	jne    0x87a
     874:	80 4e ff 01          	or     BYTE PTR [bp-0x1],0x1
     878:	eb 43                	jmp    0x8bd
     87a:	80 7e fb 3e          	cmp    BYTE PTR [bp-0x5],0x3e
     87e:	75 27                	jne    0x8a7
     880:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     883:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
     886:	7d 1f                	jge    0x8a7
     888:	80 66 ff fb          	and    BYTE PTR [bp-0x1],0xfb
     88c:	83 7e fc 01          	cmp    WORD PTR [bp-0x4],0x1
     890:	7e 0f                	jle    0x8a1
     892:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     895:	48                   	dec    ax
     896:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     899:	03 f8                	add    di,ax
     89b:	26 80 3d 3c          	cmp    BYTE PTR es:[di],0x3c
     89f:	74 04                	je     0x8a5
     8a1:	80 4e ff 02          	or     BYTE PTR [bp-0x1],0x2
     8a5:	eb 16                	jmp    0x8bd
     8a7:	80 7e fb 3c          	cmp    BYTE PTR [bp-0x5],0x3c
     8ab:	75 10                	jne    0x8bd
     8ad:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     8b0:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
     8b3:	7d 08                	jge    0x8bd
     8b5:	80 66 ff fd          	and    BYTE PTR [bp-0x1],0xfd
     8b9:	80 4e ff 04          	or     BYTE PTR [bp-0x1],0x4
     8bd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     8c0:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     8c3:	75 98                	jne    0x85d
     8c5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8c8:	06                   	push   es
     8c9:	57                   	push   di
     8ca:	ff 76 04             	push   WORD PTR [bp+0x4]
     8cd:	e8 45 fe             	call   0x715
     8d0:	3c 01                	cmp    al,0x1
     8d2:	75 04                	jne    0x8d8
     8d4:	80 4e ff 08          	or     BYTE PTR [bp-0x1],0x8
     8d8:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     8db:	c9                   	leave
     8dc:	c2 06 00             	ret    0x6
     8df:	c8 02 00 00          	enter  0x2,0x0
     8e3:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     8e6:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     8e9:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     8ec:	3c 3a                	cmp    al,0x3a
     8ee:	75 08                	jne    0x8f8
     8f0:	a0 96 2c             	mov    al,ds:0x2c96
     8f3:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     8f6:	eb 0a                	jmp    0x902
     8f8:	3c 2f                	cmp    al,0x2f
     8fa:	75 06                	jne    0x902
     8fc:	a0 65 2c             	mov    al,ds:0x2c65
     8ff:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     902:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     905:	c9                   	leave
     906:	c2 02 00             	ret    0x2
     909:	c8 0c 03 00          	enter  0x30c,0x0
     90d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     910:	06                   	push   es
     911:	57                   	push   di
     912:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     915:	06                   	push   es
     916:	57                   	push   di
     917:	68 ff 00             	push   0xff
     91a:	9a e7 17 86 09       	call   0x986:0x17e7
     91f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     922:	06                   	push   es
     923:	57                   	push   di
     924:	6a 01                	push   0x1
     926:	e8 14 ff             	call   0x83d
     929:	88 46 f6             	mov    BYTE PTR [bp-0xa],al
     92c:	f6 46 f6 01          	test   BYTE PTR [bp-0xa],0x1
     930:	74 03                	je     0x935
     932:	e9 01 01             	jmp    0xa36
     935:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
     93a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     93d:	26 8a 05             	mov    al,BYTE PTR es:[di]
     940:	30 e4                	xor    ah,ah
     942:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     945:	b8 01 00             	mov    ax,0x1
     948:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     94b:	7e 03                	jle    0x950
     94d:	e9 e3 00             	jmp    0xa33
     950:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     953:	eb 03                	jmp    0x958
     955:	ff 46 f8             	inc    WORD PTR [bp-0x8]
     958:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     95b:	06                   	push   es
     95c:	57                   	push   di
     95d:	ff 76 f8             	push   WORD PTR [bp-0x8]
     960:	e8 b2 fd             	call   0x715
     963:	88 46 f7             	mov    BYTE PTR [bp-0x9],al
     966:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
     969:	3c 01                	cmp    al,0x1
     96b:	72 6f                	jb     0x9dc
     96d:	3c 02                	cmp    al,0x2
     96f:	77 6b                	ja     0x9dc
     971:	8d be f4 fe          	lea    di,[bp-0x10c]
     975:	16                   	push   ss
     976:	57                   	push   di
     977:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     97a:	06                   	push   es
     97b:	57                   	push   di
     97c:	6a 01                	push   0x1
     97e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     981:	48                   	dec    ax
     982:	50                   	push   ax
     983:	9a 0b 18 a1 09       	call   0x9a1:0x180b
     988:	8d be f4 fd          	lea    di,[bp-0x20c]
     98c:	16                   	push   ss
     98d:	57                   	push   di
     98e:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     991:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     994:	03 f8                	add    di,ax
     996:	26 8a 05             	mov    al,BYTE PTR es:[di]
     999:	50                   	push   ax
     99a:	e8 42 ff             	call   0x8df
     99d:	50                   	push   ax
     99e:	9a e9 18 a6 09       	call   0x9a6:0x18e9
     9a3:	9a 4c 18 c3 09       	call   0x9c3:0x184c
     9a8:	8d be f4 fc          	lea    di,[bp-0x30c]
     9ac:	16                   	push   ss
     9ad:	57                   	push   di
     9ae:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     9b1:	06                   	push   es
     9b2:	57                   	push   di
     9b3:	ff 76 fa             	push   WORD PTR [bp-0x6]
     9b6:	26 8a 05             	mov    al,BYTE PTR es:[di]
     9b9:	30 e4                	xor    ah,ah
     9bb:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
     9be:	40                   	inc    ax
     9bf:	50                   	push   ax
     9c0:	9a 0b 18 c8 09       	call   0x9c8:0x180b
     9c5:	9a 4c 18 d5 09       	call   0x9d5:0x184c
     9ca:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     9cd:	06                   	push   es
     9ce:	57                   	push   di
     9cf:	68 ff 00             	push   0xff
     9d2:	9a e7 17 02 0a       	call   0xa02:0x17e7
     9d7:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     9da:	eb 4c                	jmp    0xa28
     9dc:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
     9df:	3c 04                	cmp    al,0x4
     9e1:	72 45                	jb     0xa28
     9e3:	3c 05                	cmp    al,0x5
     9e5:	77 41                	ja     0xa28
     9e7:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     9ea:	26 8a 05             	mov    al,BYTE PTR es:[di]
     9ed:	30 e4                	xor    ah,ah
     9ef:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
     9f2:	7d 31                	jge    0xa25
     9f4:	8d be f4 fd          	lea    di,[bp-0x20c]
     9f8:	16                   	push   ss
     9f9:	57                   	push   di
     9fa:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     9fd:	06                   	push   es
     9fe:	57                   	push   di
     9ff:	9a cd 17 11 0a       	call   0xa11:0x17cd
     a04:	8d be f4 fe          	lea    di,[bp-0x10c]
     a08:	16                   	push   ss
     a09:	57                   	push   di
     a0a:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     a0d:	50                   	push   ax
     a0e:	9a e9 18 16 0a       	call   0xa16:0x18e9
     a13:	9a 4c 18 23 0a       	call   0xa23:0x184c
     a18:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     a1b:	06                   	push   es
     a1c:	57                   	push   di
     a1d:	68 ff 00             	push   0xff
     a20:	9a e7 17 96 0a       	call   0xa96:0x17e7
     a25:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     a28:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     a2b:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     a2e:	74 03                	je     0xa33
     a30:	e9 22 ff             	jmp    0x955
     a33:	e9 fb 00             	jmp    0xb31
     a36:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     a39:	26 8a 05             	mov    al,BYTE PTR es:[di]
     a3c:	30 e4                	xor    ah,ah
     a3e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     a41:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     a44:	26 8a 05             	mov    al,BYTE PTR es:[di]
     a47:	30 e4                	xor    ah,ah
     a49:	48                   	dec    ax
     a4a:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     a4d:	31 c0                	xor    ax,ax
     a4f:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     a52:	7e 03                	jle    0xa57
     a54:	e9 da 00             	jmp    0xb31
     a57:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     a5a:	eb 03                	jmp    0xa5f
     a5c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     a5f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     a62:	26 8a 05             	mov    al,BYTE PTR es:[di]
     a65:	30 e4                	xor    ah,ah
     a67:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
     a6a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     a6d:	06                   	push   es
     a6e:	57                   	push   di
     a6f:	ff 76 f8             	push   WORD PTR [bp-0x8]
     a72:	e8 a0 fc             	call   0x715
     a75:	88 46 f7             	mov    BYTE PTR [bp-0x9],al
     a78:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
     a7b:	3c 01                	cmp    al,0x1
     a7d:	72 6b                	jb     0xaea
     a7f:	3c 02                	cmp    al,0x2
     a81:	77 67                	ja     0xaea
     a83:	8d be f4 fe          	lea    di,[bp-0x10c]
     a87:	16                   	push   ss
     a88:	57                   	push   di
     a89:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     a8c:	06                   	push   es
     a8d:	57                   	push   di
     a8e:	6a 01                	push   0x1
     a90:	ff 76 fa             	push   WORD PTR [bp-0x6]
     a93:	9a 0b 18 b1 0a       	call   0xab1:0x180b
     a98:	8d be f4 fd          	lea    di,[bp-0x20c]
     a9c:	16                   	push   ss
     a9d:	57                   	push   di
     a9e:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     aa1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     aa4:	03 f8                	add    di,ax
     aa6:	26 8a 05             	mov    al,BYTE PTR es:[di]
     aa9:	50                   	push   ax
     aaa:	e8 32 fe             	call   0x8df
     aad:	50                   	push   ax
     aae:	9a e9 18 b6 0a       	call   0xab6:0x18e9
     ab3:	9a 4c 18 d4 0a       	call   0xad4:0x184c
     ab8:	8d be f4 fc          	lea    di,[bp-0x30c]
     abc:	16                   	push   ss
     abd:	57                   	push   di
     abe:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     ac1:	06                   	push   es
     ac2:	57                   	push   di
     ac3:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     ac6:	40                   	inc    ax
     ac7:	50                   	push   ax
     ac8:	26 8a 05             	mov    al,BYTE PTR es:[di]
     acb:	30 e4                	xor    ah,ah
     acd:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
     ad0:	50                   	push   ax
     ad1:	9a 0b 18 d9 0a       	call   0xad9:0x180b
     ad6:	9a 4c 18 e6 0a       	call   0xae6:0x184c
     adb:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     ade:	06                   	push   es
     adf:	57                   	push   di
     ae0:	68 ff 00             	push   0xff
     ae3:	9a e7 17 08 0b       	call   0xb08:0x17e7
     ae8:	eb 3c                	jmp    0xb26
     aea:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
     aed:	3c 04                	cmp    al,0x4
     aef:	72 35                	jb     0xb26
     af1:	3c 05                	cmp    al,0x5
     af3:	77 31                	ja     0xb26
     af5:	83 7e fa 01          	cmp    WORD PTR [bp-0x6],0x1
     af9:	7d 28                	jge    0xb23
     afb:	8d be f4 fe          	lea    di,[bp-0x10c]
     aff:	16                   	push   ss
     b00:	57                   	push   di
     b01:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     b04:	50                   	push   ax
     b05:	9a e9 18 12 0b       	call   0xb12:0x18e9
     b0a:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     b0d:	06                   	push   es
     b0e:	57                   	push   di
     b0f:	9a 4c 18 1f 0b       	call   0xb1f:0x184c
     b14:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     b17:	06                   	push   es
     b18:	57                   	push   di
     b19:	68 ff 00             	push   0xff
     b1c:	9a e7 17 88 0d       	call   0xd88:0x17e7
     b21:	eb 03                	jmp    0xb26
     b23:	ff 4e fa             	dec    WORD PTR [bp-0x6]
     b26:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     b29:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     b2c:	74 03                	je     0xb31
     b2e:	e9 2b ff             	jmp    0xa5c
     b31:	c9                   	leave
     b32:	c2 0a 00             	ret    0xa
     b35:	c8 08 00 00          	enter  0x8,0x0
     b39:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     b3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b40:	26 80 3d 04          	cmp    BYTE PTR es:[di],0x4
     b44:	73 03                	jae    0xb49
     b46:	e9 86 00             	jmp    0xbcf
     b49:	c7 46 fa ff ff       	mov    WORD PTR [bp-0x6],0xffff
     b4e:	c7 46 f8 ff ff       	mov    WORD PTR [bp-0x8],0xffff
     b53:	26 8a 05             	mov    al,BYTE PTR es:[di]
     b56:	30 e4                	xor    ah,ah
     b58:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b5b:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
     b5f:	7d 40                	jge    0xba1
     b61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b64:	06                   	push   es
     b65:	57                   	push   di
     b66:	ff 76 fc             	push   WORD PTR [bp-0x4]
     b69:	e8 a9 fb             	call   0x715
     b6c:	3c 06                	cmp    al,0x6
     b6e:	75 14                	jne    0xb84
     b70:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
     b74:	7d 08                	jge    0xb7e
     b76:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b79:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     b7c:	eb 06                	jmp    0xb84
     b7e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b81:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     b84:	ff 4e fc             	dec    WORD PTR [bp-0x4]
     b87:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
     b8b:	7e 10                	jle    0xb9d
     b8d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b90:	26 8a 05             	mov    al,BYTE PTR es:[di]
     b93:	30 e4                	xor    ah,ah
     b95:	2d 04 00             	sub    ax,0x4
     b98:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     b9b:	7e 02                	jle    0xb9f
     b9d:	eb 02                	jmp    0xba1
     b9f:	eb ba                	jmp    0xb5b
     ba1:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
     ba5:	7d 06                	jge    0xbad
     ba7:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     baa:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     bad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bb0:	26 8a 05             	mov    al,BYTE PTR es:[di]
     bb3:	30 e4                	xor    ah,ah
     bb5:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     bb8:	74 15                	je     0xbcf
     bba:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     bbd:	40                   	inc    ax
     bbe:	03 f8                	add    di,ax
     bc0:	26 8a 05             	mov    al,BYTE PTR es:[di]
     bc3:	3a 06 fc 0b          	cmp    al,BYTE PTR ds:0xbfc
     bc7:	b0 00                	mov    al,0x0
     bc9:	74 01                	je     0xbcc
     bcb:	40                   	inc    ax
     bcc:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     bcf:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     bd2:	c9                   	leave
     bd3:	ca 04 00             	retf   0x4
     bd6:	c8 02 00 00          	enter  0x2,0x0
     bda:	a0 fa 0b             	mov    al,ds:0xbfa
     bdd:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     be0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     be3:	26 80 3d 04          	cmp    BYTE PTR es:[di],0x4
     be7:	72 49                	jb     0xc32
     be9:	06                   	push   es
     bea:	57                   	push   di
     beb:	26 8a 05             	mov    al,BYTE PTR es:[di]
     bee:	30 e4                	xor    ah,ah
     bf0:	48                   	dec    ax
     bf1:	50                   	push   ax
     bf2:	e8 20 fb             	call   0x715
     bf5:	3c 06                	cmp    al,0x6
     bf7:	75 39                	jne    0xc32
     bf9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bfc:	06                   	push   es
     bfd:	57                   	push   di
     bfe:	26 8a 05             	mov    al,BYTE PTR es:[di]
     c01:	30 e4                	xor    ah,ah
     c03:	48                   	dec    ax
     c04:	48                   	dec    ax
     c05:	50                   	push   ax
     c06:	e8 0c fb             	call   0x715
     c09:	3c 06                	cmp    al,0x6
     c0b:	74 15                	je     0xc22
     c0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c10:	06                   	push   es
     c11:	57                   	push   di
     c12:	26 8a 05             	mov    al,BYTE PTR es:[di]
     c15:	30 e4                	xor    ah,ah
     c17:	2d 03 00             	sub    ax,0x3
     c1a:	50                   	push   ax
     c1b:	e8 f7 fa             	call   0x715
     c1e:	3c 06                	cmp    al,0x6
     c20:	75 10                	jne    0xc32
     c22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c25:	26 8a 05             	mov    al,BYTE PTR es:[di]
     c28:	30 e4                	xor    ah,ah
     c2a:	03 f8                	add    di,ax
     c2c:	26 8a 05             	mov    al,BYTE PTR es:[di]
     c2f:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     c32:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     c35:	c9                   	leave
     c36:	ca 04 00             	retf   0x4
     c39:	c8 08 00 00          	enter  0x8,0x0
     c3d:	31 c0                	xor    ax,ax
     c3f:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     c42:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     c45:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     c48:	b8 01 00             	mov    ax,0x1
     c4b:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     c4e:	7f 30                	jg     0xc80
     c50:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c53:	eb 03                	jmp    0xc58
     c55:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     c58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c5b:	06                   	push   es
     c5c:	57                   	push   di
     c5d:	ff 76 fc             	push   WORD PTR [bp-0x4]
     c60:	e8 b2 fa             	call   0x715
     c63:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
     c66:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
     c69:	3c 03                	cmp    al,0x3
     c6b:	74 0b                	je     0xc78
     c6d:	3c 06                	cmp    al,0x6
     c6f:	72 04                	jb     0xc75
     c71:	3c 07                	cmp    al,0x7
     c73:	76 03                	jbe    0xc78
     c75:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     c78:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     c7b:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     c7e:	75 d5                	jne    0xc55
     c80:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     c83:	c9                   	leave
     c84:	c2 06 00             	ret    0x6
     c87:	c8 0a 00 00          	enter  0xa,0x0
     c8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c8e:	06                   	push   es
     c8f:	57                   	push   di
     c90:	26 8a 05             	mov    al,BYTE PTR es:[di]
     c93:	30 e4                	xor    ah,ah
     c95:	50                   	push   ax
     c96:	e8 a0 ff             	call   0xc39
     c99:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     c9c:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     c9f:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     ca2:	7e 07                	jle    0xcab
     ca4:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
     ca9:	eb 4b                	jmp    0xcf6
     cab:	31 c0                	xor    ax,ax
     cad:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     cb0:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     cb3:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     cb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cb9:	26 8a 05             	mov    al,BYTE PTR es:[di]
     cbc:	30 e4                	xor    ah,ah
     cbe:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     cc1:	b8 01 00             	mov    ax,0x1
     cc4:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
     cc7:	7f 2d                	jg     0xcf6
     cc9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ccc:	eb 03                	jmp    0xcd1
     cce:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     cd1:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     cd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cd7:	06                   	push   es
     cd8:	57                   	push   di
     cd9:	ff 76 fc             	push   WORD PTR [bp-0x4]
     cdc:	e8 36 fa             	call   0x715
     cdf:	3c 03                	cmp    al,0x3
     ce1:	74 0b                	je     0xcee
     ce3:	ff 4e fa             	dec    WORD PTR [bp-0x6]
     ce6:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
     cea:	7d 02                	jge    0xcee
     cec:	eb 08                	jmp    0xcf6
     cee:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     cf1:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
     cf4:	75 d8                	jne    0xcce
     cf6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     cf9:	c9                   	leave
     cfa:	c2 06 00             	ret    0x6
     cfd:	c8 06 00 00          	enter  0x6,0x0
     d01:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
     d05:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d08:	06                   	push   es
     d09:	57                   	push   di
     d0a:	ff 76 04             	push   WORD PTR [bp+0x4]
     d0d:	e8 77 ff             	call   0xc87
     d10:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d13:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
     d17:	7c 22                	jl     0xd3b
     d19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d1c:	06                   	push   es
     d1d:	57                   	push   di
     d1e:	ff 76 fc             	push   WORD PTR [bp-0x4]
     d21:	e8 f1 f9             	call   0x715
     d24:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
     d27:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
     d2a:	3c 01                	cmp    al,0x1
     d2c:	72 04                	jb     0xd32
     d2e:	3c 02                	cmp    al,0x2
     d30:	76 04                	jbe    0xd36
     d32:	b0 00                	mov    al,0x0
     d34:	eb 02                	jmp    0xd38
     d36:	b0 01                	mov    al,0x1
     d38:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     d3b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     d3e:	c9                   	leave
     d3f:	c2 06 00             	ret    0x6
     d42:	c8 08 02 00          	enter  0x208,0x0
     d46:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     d49:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
     d4c:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
     d4f:	7c 03                	jl     0xd54
     d51:	e9 dc 00             	jmp    0xe30
     d54:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     d57:	06                   	push   es
     d58:	57                   	push   di
     d59:	6a 01                	push   0x1
     d5b:	e8 df fa             	call   0x83d
     d5e:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     d61:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     d64:	48                   	dec    ax
     d65:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d68:	f6 46 ff 01          	test   BYTE PTR [bp-0x1],0x1
     d6c:	74 07                	je     0xd75
     d6e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     d71:	48                   	dec    ax
     d72:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d75:	8d be fa fe          	lea    di,[bp-0x106]
     d79:	16                   	push   ss
     d7a:	57                   	push   di
     d7b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     d7e:	06                   	push   es
     d7f:	57                   	push   di
     d80:	6a 01                	push   0x1
     d82:	ff 76 fc             	push   WORD PTR [bp-0x4]
     d85:	9a 0b 18 95 0d       	call   0xd95:0x180b
     d8a:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
     d8d:	06                   	push   es
     d8e:	57                   	push   di
     d8f:	68 ff 00             	push   0xff
     d92:	9a e7 17 c5 0d       	call   0xdc5:0x17e7
     d97:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     d9a:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
     d9d:	8b d0                	mov    dx,ax
     d9f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     da2:	2b c2                	sub    ax,dx
     da4:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     da7:	b8 01 00             	mov    ax,0x1
     daa:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     dad:	7f 41                	jg     0xdf0
     daf:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     db2:	eb 03                	jmp    0xdb7
     db4:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     db7:	8d be f8 fd          	lea    di,[bp-0x208]
     dbb:	16                   	push   ss
     dbc:	57                   	push   di
     dbd:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
     dc0:	06                   	push   es
     dc1:	57                   	push   di
     dc2:	9a cd 17 d4 0d       	call   0xdd4:0x17cd
     dc7:	8d be f8 fe          	lea    di,[bp-0x108]
     dcb:	16                   	push   ss
     dcc:	57                   	push   di
     dcd:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
     dd0:	50                   	push   ax
     dd1:	9a e9 18 d9 0d       	call   0xdd9:0x18e9
     dd6:	9a 4c 18 e6 0d       	call   0xde6:0x184c
     ddb:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
     dde:	06                   	push   es
     ddf:	57                   	push   di
     de0:	68 ff 00             	push   0xff
     de3:	9a e7 17 fe 0d       	call   0xdfe:0x17e7
     de8:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     deb:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     dee:	75 c4                	jne    0xdb4
     df0:	8d be fa fd          	lea    di,[bp-0x206]
     df4:	16                   	push   ss
     df5:	57                   	push   di
     df6:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
     df9:	06                   	push   es
     dfa:	57                   	push   di
     dfb:	9a cd 17 19 0e       	call   0xe19:0x17cd
     e00:	8d be fa fe          	lea    di,[bp-0x106]
     e04:	16                   	push   ss
     e05:	57                   	push   di
     e06:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     e09:	06                   	push   es
     e0a:	57                   	push   di
     e0b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     e0e:	40                   	inc    ax
     e0f:	50                   	push   ax
     e10:	26 8a 05             	mov    al,BYTE PTR es:[di]
     e13:	30 e4                	xor    ah,ah
     e15:	50                   	push   ax
     e16:	9a 0b 18 1e 0e       	call   0xe1e:0x180b
     e1b:	9a 4c 18 2b 0e       	call   0xe2b:0x184c
     e20:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
     e23:	06                   	push   es
     e24:	57                   	push   di
     e25:	68 ff 00             	push   0xff
     e28:	9a e7 17 66 0e       	call   0xe66:0x17e7
     e2d:	e9 c2 00             	jmp    0xef2
     e30:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     e33:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
     e36:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
     e39:	7f 03                	jg     0xe3e
     e3b:	e9 a2 00             	jmp    0xee0
     e3e:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     e41:	06                   	push   es
     e42:	57                   	push   di
     e43:	6a 01                	push   0x1
     e45:	e8 f5 f9             	call   0x83d
     e48:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     e4b:	f6 46 ff 01          	test   BYTE PTR [bp-0x1],0x1
     e4f:	74 48                	je     0xe99
     e51:	8d be fa fe          	lea    di,[bp-0x106]
     e55:	16                   	push   ss
     e56:	57                   	push   di
     e57:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     e5a:	06                   	push   es
     e5b:	57                   	push   di
     e5c:	6a 01                	push   0x1
     e5e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     e61:	48                   	dec    ax
     e62:	50                   	push   ax
     e63:	9a 0b 18 83 0e       	call   0xe83:0x180b
     e68:	8d be fa fd          	lea    di,[bp-0x206]
     e6c:	16                   	push   ss
     e6d:	57                   	push   di
     e6e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     e71:	06                   	push   es
     e72:	57                   	push   di
     e73:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     e76:	2b 46 06             	sub    ax,WORD PTR [bp+0x6]
     e79:	50                   	push   ax
     e7a:	26 8a 05             	mov    al,BYTE PTR es:[di]
     e7d:	30 e4                	xor    ah,ah
     e7f:	50                   	push   ax
     e80:	9a 0b 18 88 0e       	call   0xe88:0x180b
     e85:	9a 4c 18 95 0e       	call   0xe95:0x184c
     e8a:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
     e8d:	06                   	push   es
     e8e:	57                   	push   di
     e8f:	68 ff 00             	push   0xff
     e92:	9a e7 17 b1 0e       	call   0xeb1:0x17e7
     e97:	eb 45                	jmp    0xede
     e99:	8d be fa fe          	lea    di,[bp-0x106]
     e9d:	16                   	push   ss
     e9e:	57                   	push   di
     e9f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     ea2:	06                   	push   es
     ea3:	57                   	push   di
     ea4:	6a 01                	push   0x1
     ea6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     ea9:	03 46 06             	add    ax,WORD PTR [bp+0x6]
     eac:	48                   	dec    ax
     ead:	50                   	push   ax
     eae:	9a 0b 18 ca 0e       	call   0xeca:0x180b
     eb3:	8d be fa fd          	lea    di,[bp-0x206]
     eb7:	16                   	push   ss
     eb8:	57                   	push   di
     eb9:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     ebc:	06                   	push   es
     ebd:	57                   	push   di
     ebe:	ff 76 08             	push   WORD PTR [bp+0x8]
     ec1:	26 8a 05             	mov    al,BYTE PTR es:[di]
     ec4:	30 e4                	xor    ah,ah
     ec6:	50                   	push   ax
     ec7:	9a 0b 18 cf 0e       	call   0xecf:0x180b
     ecc:	9a 4c 18 dc 0e       	call   0xedc:0x184c
     ed1:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
     ed4:	06                   	push   es
     ed5:	57                   	push   di
     ed6:	68 ff 00             	push   0xff
     ed9:	9a e7 17 f0 0e       	call   0xef0:0x17e7
     ede:	eb 12                	jmp    0xef2
     ee0:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     ee3:	06                   	push   es
     ee4:	57                   	push   di
     ee5:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
     ee8:	06                   	push   es
     ee9:	57                   	push   di
     eea:	68 ff 00             	push   0xff
     eed:	9a e7 17 14 0f       	call   0xf14:0x17e7
     ef2:	c9                   	leave
     ef3:	c2 10 00             	ret    0x10
     ef6:	c8 10 03 00          	enter  0x310,0x0
     efa:	c7 46 f6 01 00       	mov    WORD PTR [bp-0xa],0x1
     eff:	31 c0                	xor    ax,ax
     f01:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f07:	06                   	push   es
     f08:	57                   	push   di
     f09:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     f0c:	06                   	push   es
     f0d:	57                   	push   di
     f0e:	68 ff 00             	push   0xff
     f11:	9a e7 17 d7 0f       	call   0xfd7:0x17e7
     f16:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f19:	26 8a 05             	mov    al,BYTE PTR es:[di]
     f1c:	30 e4                	xor    ah,ah
     f1e:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
     f22:	b8 01 00             	mov    ax,0x1
     f25:	3b 86 f0 fe          	cmp    ax,WORD PTR [bp-0x110]
     f29:	7e 03                	jle    0xf2e
     f2b:	e9 22 01             	jmp    0x1050
     f2e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     f31:	eb 03                	jmp    0xf36
     f33:	ff 46 f6             	inc    WORD PTR [bp-0xa]
     f36:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f39:	06                   	push   es
     f3a:	57                   	push   di
     f3b:	ff 76 f6             	push   WORD PTR [bp-0xa]
     f3e:	e8 d4 f7             	call   0x715
     f41:	88 46 f5             	mov    BYTE PTR [bp-0xb],al
     f44:	8a 46 f5             	mov    al,BYTE PTR [bp-0xb]
     f47:	3c 01                	cmp    al,0x1
     f49:	73 03                	jae    0xf4e
     f4b:	e9 f6 00             	jmp    0x1044
     f4e:	3c 02                	cmp    al,0x2
     f50:	76 03                	jbe    0xf55
     f52:	e9 ef 00             	jmp    0x1044
     f55:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f58:	06                   	push   es
     f59:	57                   	push   di
     f5a:	ff 76 f6             	push   WORD PTR [bp-0xa]
     f5d:	e8 d9 fc             	call   0xc39
     f60:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     f63:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     f66:	26 8a 05             	mov    al,BYTE PTR es:[di]
     f69:	30 e4                	xor    ah,ah
     f6b:	40                   	inc    ax
     f6c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     f6f:	26 8a 05             	mov    al,BYTE PTR es:[di]
     f72:	30 e4                	xor    ah,ah
     f74:	40                   	inc    ax
     f75:	89 86 ee fe          	mov    WORD PTR [bp-0x112],ax
     f79:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     f7c:	40                   	inc    ax
     f7d:	3b 86 ee fe          	cmp    ax,WORD PTR [bp-0x112]
     f81:	7f 39                	jg     0xfbc
     f83:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     f86:	eb 03                	jmp    0xf8b
     f88:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     f8b:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     f8e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     f91:	03 f8                	add    di,ax
     f93:	26 8a 05             	mov    al,BYTE PTR es:[di]
     f96:	50                   	push   ax
     f97:	e8 45 f9             	call   0x8df
     f9a:	8a d0                	mov    dl,al
     f9c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     f9f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     fa2:	03 f8                	add    di,ax
     fa4:	26 8a 05             	mov    al,BYTE PTR es:[di]
     fa7:	3a c2                	cmp    al,dl
     fa9:	75 08                	jne    0xfb3
     fab:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     fae:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     fb1:	eb 09                	jmp    0xfbc
     fb3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     fb6:	3b 86 ee fe          	cmp    ax,WORD PTR [bp-0x112]
     fba:	75 cc                	jne    0xf88
     fbc:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     fbf:	26 8a 05             	mov    al,BYTE PTR es:[di]
     fc2:	30 e4                	xor    ah,ah
     fc4:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
     fc7:	7d 3d                	jge    0x1006
     fc9:	8d be f0 fc          	lea    di,[bp-0x310]
     fcd:	16                   	push   ss
     fce:	57                   	push   di
     fcf:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     fd2:	06                   	push   es
     fd3:	57                   	push   di
     fd4:	9a cd 17 f2 0f       	call   0xff2:0x17cd
     fd9:	8d be f0 fd          	lea    di,[bp-0x210]
     fdd:	16                   	push   ss
     fde:	57                   	push   di
     fdf:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     fe2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     fe5:	03 f8                	add    di,ax
     fe7:	26 8a 05             	mov    al,BYTE PTR es:[di]
     fea:	50                   	push   ax
     feb:	e8 f1 f8             	call   0x8df
     fee:	50                   	push   ax
     fef:	9a e9 18 f7 0f       	call   0xff7:0x18e9
     ff4:	9a 4c 18 04 10       	call   0x1004:0x184c
     ff9:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     ffc:	06                   	push   es
     ffd:	57                   	push   di
     ffe:	68 ff 00             	push   0xff
    1001:	9a e7 17 3c 10       	call   0x103c:0x17e7
    1006:	8d be f0 fd          	lea    di,[bp-0x210]
    100a:	16                   	push   ss
    100b:	57                   	push   di
    100c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    100f:	06                   	push   es
    1010:	57                   	push   di
    1011:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1014:	06                   	push   es
    1015:	57                   	push   di
    1016:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1019:	40                   	inc    ax
    101a:	50                   	push   ax
    101b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    101e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1021:	40                   	inc    ax
    1022:	8b d0                	mov    dx,ax
    1024:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1027:	2b c2                	sub    ax,dx
    1029:	50                   	push   ax
    102a:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
    102d:	50                   	push   ax
    102e:	e8 11 fd             	call   0xd42
    1031:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1034:	06                   	push   es
    1035:	57                   	push   di
    1036:	68 ff 00             	push   0xff
    1039:	9a e7 17 a6 10       	call   0x10a6:0x17e7
    103e:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1041:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1044:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1047:	3b 86 f0 fe          	cmp    ax,WORD PTR [bp-0x110]
    104b:	74 03                	je     0x1050
    104d:	e9 e3 fe             	jmp    0xf33
    1050:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1053:	06                   	push   es
    1054:	57                   	push   di
    1055:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1058:	30 e4                	xor    ah,ah
    105a:	50                   	push   ax
    105b:	e8 db fb             	call   0xc39
    105e:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    1062:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1065:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1068:	30 e4                	xor    ah,ah
    106a:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    106e:	74 38                	je     0x10a8
    1070:	8d be f2 fd          	lea    di,[bp-0x20e]
    1074:	16                   	push   ss
    1075:	57                   	push   di
    1076:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1079:	06                   	push   es
    107a:	57                   	push   di
    107b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    107e:	06                   	push   es
    107f:	57                   	push   di
    1080:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1083:	40                   	inc    ax
    1084:	50                   	push   ax
    1085:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1088:	30 e4                	xor    ah,ah
    108a:	40                   	inc    ax
    108b:	50                   	push   ax
    108c:	8b 86 f2 fe          	mov    ax,WORD PTR [bp-0x10e]
    1090:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    1093:	50                   	push   ax
    1094:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
    1097:	50                   	push   ax
    1098:	e8 a7 fc             	call   0xd42
    109b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    109e:	06                   	push   es
    109f:	57                   	push   di
    10a0:	68 ff 00             	push   0xff
    10a3:	9a e7 17 30 11       	call   0x1130:0x17e7
    10a8:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    10ab:	26 8a 05             	mov    al,BYTE PTR es:[di]
    10ae:	30 e4                	xor    ah,ah
    10b0:	89 86 f0 fe          	mov    WORD PTR [bp-0x110],ax
    10b4:	31 c0                	xor    ax,ax
    10b6:	3b 86 f0 fe          	cmp    ax,WORD PTR [bp-0x110]
    10ba:	7f 3e                	jg     0x10fa
    10bc:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    10bf:	eb 03                	jmp    0x10c4
    10c1:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    10c4:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    10c7:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    10ca:	03 f8                	add    di,ax
    10cc:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    10d0:	75 1f                	jne    0x10f1
    10d2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    10d5:	06                   	push   es
    10d6:	57                   	push   di
    10d7:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    10da:	48                   	dec    ax
    10db:	50                   	push   ax
    10dc:	e8 1e fc             	call   0xcfd
    10df:	08 c0                	or     al,al
    10e1:	75 0e                	jne    0x10f1
    10e3:	8a 56 04             	mov    dl,BYTE PTR [bp+0x4]
    10e6:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    10e9:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    10ec:	03 f8                	add    di,ax
    10ee:	26 88 15             	mov    BYTE PTR es:[di],dl
    10f1:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    10f4:	3b 86 f0 fe          	cmp    ax,WORD PTR [bp-0x110]
    10f8:	75 c7                	jne    0x10c1
    10fa:	c9                   	leave
    10fb:	c2 0a 00             	ret    0xa
    10fe:	c8 00 01 00          	enter  0x100,0x0
    1102:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1105:	06                   	push   es
    1106:	57                   	push   di
    1107:	9a 35 0b 29 12       	call   0x1229:0xb35
    110c:	08 c0                	or     al,al
    110e:	74 24                	je     0x1134
    1110:	8d be 00 ff          	lea    di,[bp-0x100]
    1114:	16                   	push   ss
    1115:	57                   	push   di
    1116:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1119:	06                   	push   es
    111a:	57                   	push   di
    111b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    111e:	06                   	push   es
    111f:	57                   	push   di
    1120:	6a 20                	push   0x20
    1122:	e8 d1 fd             	call   0xef6
    1125:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1128:	06                   	push   es
    1129:	57                   	push   di
    112a:	68 ff 00             	push   0xff
    112d:	9a e7 17 54 11       	call   0x1154:0x17e7
    1132:	eb 22                	jmp    0x1156
    1134:	8d be 00 ff          	lea    di,[bp-0x100]
    1138:	16                   	push   ss
    1139:	57                   	push   di
    113a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    113d:	06                   	push   es
    113e:	57                   	push   di
    113f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1142:	06                   	push   es
    1143:	57                   	push   di
    1144:	6a 20                	push   0x20
    1146:	e8 c0 f7             	call   0x909
    1149:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    114c:	06                   	push   es
    114d:	57                   	push   di
    114e:	68 ff 00             	push   0xff
    1151:	9a e7 17 69 11       	call   0x1169:0x17e7
    1156:	c9                   	leave
    1157:	ca 08 00             	retf   0x8
    115a:	55                   	push   bp
    115b:	89 e5                	mov    bp,sp
    115d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1161:	74 08                	je     0x116b
    1163:	83 ec 08             	sub    sp,0x8
    1166:	9a e2 1f 05 12       	call   0x1205:0x1fe2
    116b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    116e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1171:	31 c0                	xor    ax,ax
    1173:	50                   	push   ax
    1174:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1177:	06                   	push   es
    1178:	57                   	push   di
    1179:	9a 09 47 1f 13       	call   0x131f:0x4709
    117e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1181:	26 c6 85 f4 00 00    	mov    BYTE PTR es:[di+0xf4],0x0
    1187:	a1 16 17             	mov    ax,ds:0x1716
    118a:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    118e:	26 89 85 f9 00       	mov    WORD PTR es:[di+0xf9],ax
    1193:	26 89 95 fb 00       	mov    WORD PTR es:[di+0xfb],dx
    1198:	a0 fa 0b             	mov    al,ds:0xbfa
    119b:	26 88 85 f0 00       	mov    BYTE PTR es:[di+0xf0],al
    11a0:	a1 16 17             	mov    ax,ds:0x1716
    11a3:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    11a7:	26 89 85 ec 00       	mov    WORD PTR es:[di+0xec],ax
    11ac:	26 89 95 ee 00       	mov    WORD PTR es:[di+0xee],dx
    11b1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    11b5:	74 07                	je     0x11be
    11b7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    11bb:	83 c4 06             	add    sp,0x6
    11be:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    11c1:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    11c4:	c9                   	leave
    11c5:	ca 0a 00             	retf   0xa
    11c8:	55                   	push   bp
    11c9:	89 e5                	mov    bp,sp
    11cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11ce:	26 ff b5 fb 00       	push   WORD PTR es:[di+0xfb]
    11d3:	26 ff b5 f9 00       	push   WORD PTR es:[di+0xf9]
    11d8:	9a 24 06 ed 11       	call   0x11ed:0x624
    11dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11e0:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
    11e5:	26 ff b5 ec 00       	push   WORD PTR es:[di+0xec]
    11ea:	9a 24 06 bc 14       	call   0x14bc:0x624
    11ef:	31 c0                	xor    ax,ax
    11f1:	50                   	push   ax
    11f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11f5:	06                   	push   es
    11f6:	57                   	push   di
    11f7:	9a fc 2e 1f 12       	call   0x121f:0x2efc
    11fc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1200:	74 05                	je     0x1207
    1202:	9a 0f 20 aa 14       	call   0x14aa:0x200f
    1207:	c9                   	leave
    1208:	ca 06 00             	retf   0x6
    120b:	55                   	push   bp
    120c:	89 e5                	mov    bp,sp
    120e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1211:	06                   	push   es
    1212:	57                   	push   di
    1213:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1216:	50                   	push   ax
    1217:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    121a:	06                   	push   es
    121b:	57                   	push   di
    121c:	9a 6a 4f 4e 13       	call   0x134e:0x4f6a
    1221:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1224:	06                   	push   es
    1225:	57                   	push   di
    1226:	9a 1c 18 65 12       	call   0x1265:0x181c
    122b:	08 c0                	or     al,al
    122d:	75 03                	jne    0x1232
    122f:	e9 03 01             	jmp    0x1335
    1232:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1235:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    1239:	75 03                	jne    0x123e
    123b:	e9 f7 00             	jmp    0x1335
    123e:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    1242:	74 03                	je     0x1247
    1244:	e9 ee 00             	jmp    0x1335
    1247:	26 83 3d 25          	cmp    WORD PTR es:[di],0x25
    124b:	74 06                	je     0x1253
    124d:	26 83 3d 27          	cmp    WORD PTR es:[di],0x27
    1251:	75 2e                	jne    0x1281
    1253:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1256:	26 ff 35             	push   WORD PTR es:[di]
    1259:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    125c:	50                   	push   ax
    125d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1260:	06                   	push   es
    1261:	57                   	push   di
    1262:	9a 12 1e bf 12       	call   0x12bf:0x1e12
    1267:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    126b:	75 0e                	jne    0x127b
    126d:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    1271:	75 08                	jne    0x127b
    1273:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1276:	31 c0                	xor    ax,ax
    1278:	26 89 05             	mov    WORD PTR es:[di],ax
    127b:	e9 b7 00             	jmp    0x1335
    127e:	e9 aa 00             	jmp    0x132b
    1281:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1284:	26 83 3d 26          	cmp    WORD PTR es:[di],0x26
    1288:	74 06                	je     0x1290
    128a:	26 83 3d 28          	cmp    WORD PTR es:[di],0x28
    128e:	75 0e                	jne    0x129e
    1290:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1293:	31 c0                	xor    ax,ax
    1295:	26 89 05             	mov    WORD PTR es:[di],ax
    1298:	e9 9a 00             	jmp    0x1335
    129b:	e9 8d 00             	jmp    0x132b
    129e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    12a1:	26 83 3d 24          	cmp    WORD PTR es:[di],0x24
    12a5:	74 06                	je     0x12ad
    12a7:	26 83 3d 23          	cmp    WORD PTR es:[di],0x23
    12ab:	75 20                	jne    0x12cd
    12ad:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    12b0:	26 ff 35             	push   WORD PTR es:[di]
    12b3:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    12b6:	50                   	push   ax
    12b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12ba:	06                   	push   es
    12bb:	57                   	push   di
    12bc:	9a 3e 20 fa 12       	call   0x12fa:0x203e
    12c1:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    12c4:	31 c0                	xor    ax,ax
    12c6:	26 89 05             	mov    WORD PTR es:[di],ax
    12c9:	eb 6a                	jmp    0x1335
    12cb:	eb 5e                	jmp    0x132b
    12cd:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    12d0:	26 83 3d 2e          	cmp    WORD PTR es:[di],0x2e
    12d4:	74 06                	je     0x12dc
    12d6:	26 83 3d 08          	cmp    WORD PTR es:[di],0x8
    12da:	75 2c                	jne    0x1308
    12dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12df:	06                   	push   es
    12e0:	57                   	push   di
    12e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    12e4:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    12e8:	08 c0                	or     al,al
    12ea:	74 10                	je     0x12fc
    12ec:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    12ef:	26 ff 35             	push   WORD PTR es:[di]
    12f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12f5:	06                   	push   es
    12f6:	57                   	push   di
    12f7:	9a 13 21 33 13       	call   0x1333:0x2113
    12fc:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    12ff:	31 c0                	xor    ax,ax
    1301:	26 89 05             	mov    WORD PTR es:[di],ax
    1304:	eb 2f                	jmp    0x1335
    1306:	eb 23                	jmp    0x132b
    1308:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    130b:	26 83 3d 2d          	cmp    WORD PTR es:[di],0x2d
    130f:	75 1a                	jne    0x132b
    1311:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    1315:	74 14                	je     0x132b
    1317:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    131a:	06                   	push   es
    131b:	57                   	push   di
    131c:	9a 1f 4a ee 16       	call   0x16ee:0x4a1f
    1321:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1324:	31 c0                	xor    ax,ax
    1326:	26 89 05             	mov    WORD PTR es:[di],ax
    1329:	eb 0a                	jmp    0x1335
    132b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    132e:	06                   	push   es
    132f:	57                   	push   di
    1330:	9a 52 1c 58 13       	call   0x1358:0x1c52
    1335:	c9                   	leave
    1336:	ca 0a 00             	retf   0xa
    1339:	c8 04 00 00          	enter  0x4,0x0
    133d:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1340:	06                   	push   es
    1341:	57                   	push   di
    1342:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1345:	50                   	push   ax
    1346:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1349:	06                   	push   es
    134a:	57                   	push   di
    134b:	9a fe 50 97 13       	call   0x1397:0x50fe
    1350:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1353:	06                   	push   es
    1354:	57                   	push   di
    1355:	9a 1c 18 81 13       	call   0x1381:0x181c
    135a:	08 c0                	or     al,al
    135c:	74 25                	je     0x1383
    135e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1361:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    1365:	74 1c                	je     0x1383
    1367:	26 83 3d 25          	cmp    WORD PTR es:[di],0x25
    136b:	74 06                	je     0x1373
    136d:	26 83 3d 27          	cmp    WORD PTR es:[di],0x27
    1371:	75 10                	jne    0x1383
    1373:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    1377:	74 0a                	je     0x1383
    1379:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    137c:	06                   	push   es
    137d:	57                   	push   di
    137e:	9a 52 1c a1 13       	call   0x13a1:0x1c52
    1383:	c9                   	leave
    1384:	ca 0a 00             	retf   0xa
    1387:	55                   	push   bp
    1388:	89 e5                	mov    bp,sp
    138a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    138d:	06                   	push   es
    138e:	57                   	push   di
    138f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1392:	06                   	push   es
    1393:	57                   	push   di
    1394:	9a 1f 52 d8 13       	call   0x13d8:0x521f
    1399:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    139c:	06                   	push   es
    139d:	57                   	push   di
    139e:	9a 1c 18 ba 13       	call   0x13ba:0x181c
    13a3:	08 c0                	or     al,al
    13a5:	74 1c                	je     0x13c3
    13a7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    13aa:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    13ae:	74 13                	je     0x13c3
    13b0:	06                   	push   es
    13b1:	57                   	push   di
    13b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13b5:	06                   	push   es
    13b6:	57                   	push   di
    13b7:	9a e5 1c 09 14       	call   0x1409:0x1ce5
    13bc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    13bf:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    13c3:	c9                   	leave
    13c4:	ca 08 00             	retf   0x8
    13c7:	55                   	push   bp
    13c8:	89 e5                	mov    bp,sp
    13ca:	ff 76 0c             	push   WORD PTR [bp+0xc]
    13cd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    13d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13d3:	06                   	push   es
    13d4:	57                   	push   di
    13d5:	9a 2c 28 ff 13       	call   0x13ff:0x282c
    13da:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    13dd:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    13e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e4:	26 89 85 f7 00       	mov    WORD PTR es:[di+0xf7],ax
    13e9:	c9                   	leave
    13ea:	ca 08 00             	retf   0x8
    13ed:	c8 04 00 00          	enter  0x4,0x0
    13f1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    13f4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    13f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13fa:	06                   	push   es
    13fb:	57                   	push   di
    13fc:	9a ce 2b c8 14       	call   0x14c8:0x2bce
    1401:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1404:	06                   	push   es
    1405:	57                   	push   di
    1406:	9a 1c 18 21 14       	call   0x1421:0x181c
    140b:	08 c0                	or     al,al
    140d:	74 4a                	je     0x1459
    140f:	8d 7e fe             	lea    di,[bp-0x2]
    1412:	16                   	push   ss
    1413:	57                   	push   di
    1414:	8d 7e fc             	lea    di,[bp-0x4]
    1417:	16                   	push   ss
    1418:	57                   	push   di
    1419:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    141c:	06                   	push   es
    141d:	57                   	push   di
    141e:	9a 9e 1a 57 14       	call   0x1457:0x1a9e
    1423:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1426:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1429:	26 89 85 f5 00       	mov    WORD PTR es:[di+0xf5],ax
    142e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1431:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1434:	74 19                	je     0x144f
    1436:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1439:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    143d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1440:	26 3b 85 f7 00       	cmp    ax,WORD PTR es:[di+0xf7]
    1445:	7e 08                	jle    0x144f
    1447:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    144a:	26 89 85 f5 00       	mov    WORD PTR es:[di+0xf5],ax
    144f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1452:	06                   	push   es
    1453:	57                   	push   di
    1454:	9a 52 1c 7a 14       	call   0x147a:0x1c52
    1459:	c9                   	leave
    145a:	ca 08 00             	retf   0x8
    145d:	55                   	push   bp
    145e:	89 e5                	mov    bp,sp
    1460:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1463:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1466:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1469:	06                   	push   es
    146a:	57                   	push   di
    146b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    146e:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    1472:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1475:	06                   	push   es
    1476:	57                   	push   di
    1477:	9a 1c 18 88 14       	call   0x1488:0x181c
    147c:	08 c0                	or     al,al
    147e:	74 0a                	je     0x148a
    1480:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1483:	06                   	push   es
    1484:	57                   	push   di
    1485:	9a 52 1c a0 14       	call   0x14a0:0x1c52
    148a:	c9                   	leave
    148b:	ca 08 00             	retf   0x8
    148e:	c8 00 02 00          	enter  0x200,0x0
    1492:	8d be 00 fe          	lea    di,[bp-0x200]
    1496:	16                   	push   ss
    1497:	57                   	push   di
    1498:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    149b:	06                   	push   es
    149c:	57                   	push   di
    149d:	9a d8 14 d2 14       	call   0x14d2:0x14d8
    14a2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    14a5:	06                   	push   es
    14a6:	57                   	push   di
    14a7:	9a be 18 f7 14       	call   0x14f7:0x18be
    14ac:	74 26                	je     0x14d4
    14ae:	8d be 00 ff          	lea    di,[bp-0x100]
    14b2:	16                   	push   ss
    14b3:	57                   	push   di
    14b4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    14b7:	06                   	push   es
    14b8:	57                   	push   di
    14b9:	9a 4c 0d 94 16       	call   0x1694:0xd4c
    14be:	52                   	push   dx
    14bf:	50                   	push   ax
    14c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14c3:	06                   	push   es
    14c4:	57                   	push   di
    14c5:	9a 25 1d ea 14       	call   0x14ea:0x1d25
    14ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14cd:	06                   	push   es
    14ce:	57                   	push   di
    14cf:	9a 52 1c 0f 15       	call   0x150f:0x1c52
    14d4:	c9                   	leave
    14d5:	ca 08 00             	retf   0x8
    14d8:	c8 00 01 00          	enter  0x100,0x0
    14dc:	8d be 00 ff          	lea    di,[bp-0x100]
    14e0:	16                   	push   ss
    14e1:	57                   	push   di
    14e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14e5:	06                   	push   es
    14e6:	57                   	push   di
    14e7:	9a 53 1d 44 15       	call   0x1544:0x1d53
    14ec:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    14ef:	06                   	push   es
    14f0:	57                   	push   di
    14f1:	68 ff 00             	push   0xff
    14f4:	9a e7 17 51 15       	call   0x1551:0x17e7
    14f9:	c9                   	leave
    14fa:	ca 04 00             	retf   0x4
    14fd:	c8 02 01 00          	enter  0x102,0x0
    1501:	8d be fe fe          	lea    di,[bp-0x102]
    1505:	16                   	push   ss
    1506:	57                   	push   di
    1507:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    150a:	06                   	push   es
    150b:	57                   	push   di
    150c:	9a 24 15 30 15       	call   0x1530:0x1524
    1511:	83 c4 04             	add    sp,0x4
    1514:	8a 86 fe fe          	mov    al,BYTE PTR [bp-0x102]
    1518:	30 e4                	xor    ah,ah
    151a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    151d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1520:	c9                   	leave
    1521:	ca 04 00             	retf   0x4
    1524:	c8 02 02 00          	enter  0x202,0x0
    1528:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    152b:	06                   	push   es
    152c:	57                   	push   di
    152d:	9a 1c 18 69 15       	call   0x1569:0x181c
    1532:	08 c0                	or     al,al
    1534:	75 1f                	jne    0x1555
    1536:	8d be fe fe          	lea    di,[bp-0x102]
    153a:	16                   	push   ss
    153b:	57                   	push   di
    153c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    153f:	06                   	push   es
    1540:	57                   	push   di
    1541:	9a 53 1d d4 15       	call   0x15d4:0x1d53
    1546:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1549:	06                   	push   es
    154a:	57                   	push   di
    154b:	68 ff 00             	push   0xff
    154e:	9a e7 17 80 15       	call   0x1580:0x17e7
    1553:	eb 5c                	jmp    0x15b1
    1555:	8d be fe fd          	lea    di,[bp-0x202]
    1559:	16                   	push   ss
    155a:	57                   	push   di
    155b:	8d be fe fe          	lea    di,[bp-0x102]
    155f:	16                   	push   ss
    1560:	57                   	push   di
    1561:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1564:	06                   	push   es
    1565:	57                   	push   di
    1566:	9a d8 14 73 15       	call   0x1573:0x14d8
    156b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    156e:	06                   	push   es
    156f:	57                   	push   di
    1570:	9a 72 25 a2 15       	call   0x15a2:0x2572
    1575:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1578:	06                   	push   es
    1579:	57                   	push   di
    157a:	68 ff 00             	push   0xff
    157d:	9a e7 17 af 15       	call   0x15af:0x17e7
    1582:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1585:	26 80 bd f3 00 00    	cmp    BYTE PTR es:[di+0xf3],0x0
    158b:	74 24                	je     0x15b1
    158d:	8d be fe fe          	lea    di,[bp-0x102]
    1591:	16                   	push   ss
    1592:	57                   	push   di
    1593:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1596:	06                   	push   es
    1597:	57                   	push   di
    1598:	6a 00                	push   0x0
    159a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    159d:	06                   	push   es
    159e:	57                   	push   di
    159f:	9a 0d 25 c1 15       	call   0x15c1:0x250d
    15a4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    15a7:	06                   	push   es
    15a8:	57                   	push   di
    15a9:	68 ff 00             	push   0xff
    15ac:	9a e7 17 ea 15       	call   0x15ea:0x17e7
    15b1:	c9                   	leave
    15b2:	ca 04 00             	retf   0x4
    15b5:	c8 04 03 00          	enter  0x304,0x0
    15b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15bc:	06                   	push   es
    15bd:	57                   	push   di
    15be:	9a 1c 18 0b 16       	call   0x160b:0x181c
    15c3:	08 c0                	or     al,al
    15c5:	75 12                	jne    0x15d9
    15c7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    15ca:	06                   	push   es
    15cb:	57                   	push   di
    15cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15cf:	06                   	push   es
    15d0:	57                   	push   di
    15d1:	9a 8c 1d 92 19       	call   0x1992:0x1d8c
    15d6:	e9 e4 00             	jmp    0x16bd
    15d9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    15dc:	06                   	push   es
    15dd:	57                   	push   di
    15de:	8d be 00 ff          	lea    di,[bp-0x100]
    15e2:	16                   	push   ss
    15e3:	57                   	push   di
    15e4:	68 ff 00             	push   0xff
    15e7:	9a e7 17 2b 16       	call   0x162b:0x17e7
    15ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15ef:	26 80 bd f3 00 00    	cmp    BYTE PTR es:[di+0xf3],0x0
    15f5:	74 38                	je     0x162f
    15f7:	8d be fc fc          	lea    di,[bp-0x304]
    15fb:	16                   	push   ss
    15fc:	57                   	push   di
    15fd:	8d be fc fd          	lea    di,[bp-0x204]
    1601:	16                   	push   ss
    1602:	57                   	push   di
    1603:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1606:	06                   	push   es
    1607:	57                   	push   di
    1608:	9a fe 17 45 16       	call   0x1645:0x17fe
    160d:	8d be 00 ff          	lea    di,[bp-0x100]
    1611:	16                   	push   ss
    1612:	57                   	push   di
    1613:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1616:	26 8a 85 f0 00       	mov    al,BYTE PTR es:[di+0xf0]
    161b:	50                   	push   ax
    161c:	e8 d7 f8             	call   0xef6
    161f:	8d be 00 ff          	lea    di,[bp-0x100]
    1623:	16                   	push   ss
    1624:	57                   	push   di
    1625:	68 ff 00             	push   0xff
    1628:	9a e7 17 53 16       	call   0x1653:0x17e7
    162d:	eb 26                	jmp    0x1655
    162f:	8d be fc fd          	lea    di,[bp-0x204]
    1633:	16                   	push   ss
    1634:	57                   	push   di
    1635:	8d be 00 ff          	lea    di,[bp-0x100]
    1639:	16                   	push   ss
    163a:	57                   	push   di
    163b:	6a 01                	push   0x1
    163d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1640:	06                   	push   es
    1641:	57                   	push   di
    1642:	9a 0d 25 82 16       	call   0x1682:0x250d
    1647:	8d be 00 ff          	lea    di,[bp-0x100]
    164b:	16                   	push   ss
    164c:	57                   	push   di
    164d:	68 ff 00             	push   0xff
    1650:	9a e7 17 ab 16       	call   0x16ab:0x17e7
    1655:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1658:	26 f6 85 f4 00 04    	test   BYTE PTR es:[di+0xf4],0x4
    165e:	75 4d                	jne    0x16ad
    1660:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    1665:	74 46                	je     0x16ad
    1667:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    166c:	75 3f                	jne    0x16ad
    166e:	8d be 00 ff          	lea    di,[bp-0x100]
    1672:	16                   	push   ss
    1673:	57                   	push   di
    1674:	8d be fe fe          	lea    di,[bp-0x102]
    1678:	16                   	push   ss
    1679:	57                   	push   di
    167a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    167d:	06                   	push   es
    167e:	57                   	push   di
    167f:	9a 76 2a 9d 16       	call   0x169d:0x2a76
    1684:	08 c0                	or     al,al
    1686:	75 25                	jne    0x16ad
    1688:	8d be fc fd          	lea    di,[bp-0x204]
    168c:	16                   	push   ss
    168d:	57                   	push   di
    168e:	68 67 f0             	push   0xf067
    1691:	9a 2b 09 a4 16       	call   0x16a4:0x92b
    1696:	b0 01                	mov    al,0x1
    1698:	50                   	push   ax
    1699:	b8 22 00             	mov    ax,0x22
    169c:	ba bb 16             	mov    dx,0x16bb
    169f:	52                   	push   dx
    16a0:	50                   	push   ax
    16a1:	9a e6 28 a5 18       	call   0x18a5:0x28e6
    16a6:	52                   	push   dx
    16a7:	50                   	push   ax
    16a8:	9a 99 13 5a 17       	call   0x175a:0x1399
    16ad:	8d be 00 ff          	lea    di,[bp-0x100]
    16b1:	16                   	push   ss
    16b2:	57                   	push   di
    16b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16b6:	06                   	push   es
    16b7:	57                   	push   di
    16b8:	9a 8e 14 cc 16       	call   0x16cc:0x148e
    16bd:	c9                   	leave
    16be:	ca 08 00             	retf   0x8
    16c1:	55                   	push   bp
    16c2:	89 e5                	mov    bp,sp
    16c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16c7:	06                   	push   es
    16c8:	57                   	push   di
    16c9:	9a 1c 18 fa 16       	call   0x16fa:0x181c
    16ce:	08 c0                	or     al,al
    16d0:	75 14                	jne    0x16e6
    16d2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    16d5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    16d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16db:	06                   	push   es
    16dc:	57                   	push   di
    16dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16e0:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    16e4:	eb 16                	jmp    0x16fc
    16e6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16e9:	06                   	push   es
    16ea:	57                   	push   di
    16eb:	9a ff 49 f3 19       	call   0x19f3:0x49ff
    16f0:	6a 2e                	push   0x2e
    16f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16f5:	06                   	push   es
    16f6:	57                   	push   di
    16f7:	9a 13 21 0c 17       	call   0x170c:0x2113
    16fc:	c9                   	leave
    16fd:	ca 08 00             	retf   0x8
    1700:	c8 04 03 00          	enter  0x304,0x0
    1704:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1707:	06                   	push   es
    1708:	57                   	push   di
    1709:	9a 1c 18 7b 17       	call   0x177b:0x181c
    170e:	08 c0                	or     al,al
    1710:	74 0b                	je     0x171d
    1712:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1715:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    171b:	74 15                	je     0x1732
    171d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1720:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1723:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1726:	06                   	push   es
    1727:	57                   	push   di
    1728:	26 c4 3d             	les    di,DWORD PTR es:[di]
    172b:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    172f:	e9 c8 00             	jmp    0x17fa
    1732:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    1736:	06                   	push   es
    1737:	57                   	push   di
    1738:	9a 45 37 4c 17       	call   0x174c:0x3745
    173d:	8d be fc fc          	lea    di,[bp-0x304]
    1741:	16                   	push   ss
    1742:	57                   	push   di
    1743:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    1747:	06                   	push   es
    1748:	57                   	push   di
    1749:	9a be 39 65 17       	call   0x1765:0x39be
    174e:	8d be 00 ff          	lea    di,[bp-0x100]
    1752:	16                   	push   ss
    1753:	57                   	push   di
    1754:	68 ff 00             	push   0xff
    1757:	9a e7 17 99 17       	call   0x1799:0x17e7
    175c:	c4 3e d0 2a          	les    di,DWORD PTR ds:0x2ad0
    1760:	06                   	push   es
    1761:	57                   	push   di
    1762:	9a 03 37 ff ff       	call   0xffff:0x3703
    1767:	8d be fe fd          	lea    di,[bp-0x202]
    176b:	16                   	push   ss
    176c:	57                   	push   di
    176d:	8d be fc fd          	lea    di,[bp-0x204]
    1771:	16                   	push   ss
    1772:	57                   	push   di
    1773:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1776:	06                   	push   es
    1777:	57                   	push   di
    1778:	9a 9e 1a 8b 17       	call   0x178b:0x1a9e
    177d:	8d be fc fc          	lea    di,[bp-0x304]
    1781:	16                   	push   ss
    1782:	57                   	push   di
    1783:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1786:	06                   	push   es
    1787:	57                   	push   di
    1788:	9a d8 14 b9 17       	call   0x17b9:0x14d8
    178d:	8d be 00 fe          	lea    di,[bp-0x200]
    1791:	16                   	push   ss
    1792:	57                   	push   di
    1793:	68 ff 00             	push   0xff
    1796:	9a e7 17 16 18       	call   0x1816:0x17e7
    179b:	8d be 00 fe          	lea    di,[bp-0x200]
    179f:	16                   	push   ss
    17a0:	57                   	push   di
    17a1:	68 ff 00             	push   0xff
    17a4:	ff b6 fe fd          	push   WORD PTR [bp-0x202]
    17a8:	8b 86 fc fd          	mov    ax,WORD PTR [bp-0x204]
    17ac:	2b 86 fe fd          	sub    ax,WORD PTR [bp-0x202]
    17b0:	50                   	push   ax
    17b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17b4:	06                   	push   es
    17b5:	57                   	push   di
    17b6:	9a 2e 2b d6 17       	call   0x17d6:0x2b2e
    17bb:	8d be 00 fe          	lea    di,[bp-0x200]
    17bf:	16                   	push   ss
    17c0:	57                   	push   di
    17c1:	68 ff 00             	push   0xff
    17c4:	8d be 00 ff          	lea    di,[bp-0x100]
    17c8:	16                   	push   ss
    17c9:	57                   	push   di
    17ca:	ff b6 fe fd          	push   WORD PTR [bp-0x202]
    17ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17d1:	06                   	push   es
    17d2:	57                   	push   di
    17d3:	9a e4 2b ea 17       	call   0x17ea:0x2be4
    17d8:	89 86 fe fd          	mov    WORD PTR [bp-0x202],ax
    17dc:	8d be 00 fe          	lea    di,[bp-0x200]
    17e0:	16                   	push   ss
    17e1:	57                   	push   di
    17e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e5:	06                   	push   es
    17e6:	57                   	push   di
    17e7:	9a 8e 14 f8 17       	call   0x17f8:0x148e
    17ec:	ff b6 fe fd          	push   WORD PTR [bp-0x202]
    17f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17f3:	06                   	push   es
    17f4:	57                   	push   di
    17f5:	9a 12 1b 4d 18       	call   0x184d:0x1b12
    17fa:	c9                   	leave
    17fb:	ca 08 00             	retf   0x8
    17fe:	55                   	push   bp
    17ff:	89 e5                	mov    bp,sp
    1801:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1804:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1809:	06                   	push   es
    180a:	57                   	push   di
    180b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    180e:	06                   	push   es
    180f:	57                   	push   di
    1810:	68 ff 00             	push   0xff
    1813:	9a e7 17 5b 18       	call   0x185b:0x17e7
    1818:	c9                   	leave
    1819:	ca 04 00             	retf   0x4
    181c:	c8 02 00 00          	enter  0x2,0x0
    1820:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1823:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    1828:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    182c:	b0 00                	mov    al,0x0
    182e:	74 01                	je     0x1831
    1830:	40                   	inc    ax
    1831:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1834:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1837:	c9                   	leave
    1838:	ca 04 00             	retf   0x4
    183b:	c8 06 02 00          	enter  0x206,0x0
    183f:	8d be fa fd          	lea    di,[bp-0x206]
    1843:	16                   	push   ss
    1844:	57                   	push   di
    1845:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1848:	06                   	push   es
    1849:	57                   	push   di
    184a:	9a d8 14 84 18       	call   0x1884:0x14d8
    184f:	8d be 00 ff          	lea    di,[bp-0x100]
    1853:	16                   	push   ss
    1854:	57                   	push   di
    1855:	68 ff 00             	push   0xff
    1858:	9a e7 17 92 18       	call   0x1892:0x17e7
    185d:	ff 76 08             	push   WORD PTR [bp+0x8]
    1860:	ff 76 06             	push   WORD PTR [bp+0x6]
    1863:	9a a8 17 ff ff       	call   0xffff:0x17a8
    1868:	89 86 fc fe          	mov    WORD PTR [bp-0x104],ax
    186c:	89 96 fe fe          	mov    WORD PTR [bp-0x102],dx
    1870:	8d be fa fd          	lea    di,[bp-0x206]
    1874:	16                   	push   ss
    1875:	57                   	push   di
    1876:	8d be 00 ff          	lea    di,[bp-0x100]
    187a:	16                   	push   ss
    187b:	57                   	push   di
    187c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    187f:	06                   	push   es
    1880:	57                   	push   di
    1881:	9a 72 25 b5 18       	call   0x18b5:0x2572
    1886:	8d be 00 ff          	lea    di,[bp-0x100]
    188a:	16                   	push   ss
    188b:	57                   	push   di
    188c:	68 ff 00             	push   0xff
    188f:	9a e7 17 13 19       	call   0x1913:0x17e7
    1894:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1897:	81 c7 ec 00          	add    di,0xec
    189b:	06                   	push   es
    189c:	57                   	push   di
    189d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    18a0:	06                   	push   es
    18a1:	57                   	push   di
    18a2:	9a 51 06 ff 21       	call   0x21ff:0x651
    18a7:	8d be fa fd          	lea    di,[bp-0x206]
    18ab:	16                   	push   ss
    18ac:	57                   	push   di
    18ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18b0:	06                   	push   es
    18b1:	57                   	push   di
    18b2:	9a fe 17 d3 18       	call   0x18d3:0x17fe
    18b7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    18ba:	26 8a 05             	mov    al,BYTE PTR es:[di]
    18bd:	30 e4                	xor    ah,ah
    18bf:	50                   	push   ax
    18c0:	e8 76 f3             	call   0xc39
    18c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18c6:	26 89 85 f1 00       	mov    WORD PTR es:[di+0xf1],ax
    18cb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    18ce:	06                   	push   es
    18cf:	57                   	push   di
    18d0:	9a 35 0b e5 18       	call   0x18e5:0xb35
    18d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18d8:	26 88 85 f3 00       	mov    BYTE PTR es:[di+0xf3],al
    18dd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    18e0:	06                   	push   es
    18e1:	57                   	push   di
    18e2:	9a d6 0b 05 19       	call   0x1905:0xbd6
    18e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18ea:	26 88 85 f0 00       	mov    BYTE PTR es:[di+0xf0],al
    18ef:	8d be fa fd          	lea    di,[bp-0x206]
    18f3:	16                   	push   ss
    18f4:	57                   	push   di
    18f5:	8d be 00 ff          	lea    di,[bp-0x100]
    18f9:	16                   	push   ss
    18fa:	57                   	push   di
    18fb:	6a 01                	push   0x1
    18fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1900:	06                   	push   es
    1901:	57                   	push   di
    1902:	9a 0d 25 23 19       	call   0x1923:0x250d
    1907:	8d be 00 ff          	lea    di,[bp-0x100]
    190b:	16                   	push   ss
    190c:	57                   	push   di
    190d:	68 ff 00             	push   0xff
    1910:	9a e7 17 46 19       	call   0x1946:0x17e7
    1915:	8d be 00 ff          	lea    di,[bp-0x100]
    1919:	16                   	push   ss
    191a:	57                   	push   di
    191b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    191e:	06                   	push   es
    191f:	57                   	push   di
    1920:	9a 8e 14 41 19       	call   0x1941:0x148e
    1925:	c9                   	leave
    1926:	ca 08 00             	retf   0x8
    1929:	00 c8                	add    al,cl
    192b:	06                   	push   es
    192c:	02 00                	add    al,BYTE PTR [bx+si]
    192e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1931:	06                   	push   es
    1932:	57                   	push   di
    1933:	8d be fa fe          	lea    di,[bp-0x106]
    1937:	16                   	push   ss
    1938:	57                   	push   di
    1939:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    193c:	06                   	push   es
    193d:	57                   	push   di
    193e:	9a fe 17 7b 19       	call   0x197b:0x17fe
    1943:	9a be 18 dc 19       	call   0x19dc:0x18be
    1948:	75 03                	jne    0x194d
    194a:	e9 04 01             	jmp    0x1a51
    194d:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    1951:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1954:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    1959:	74 22                	je     0x197d
    195b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    195e:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1962:	74 19                	je     0x197d
    1964:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1967:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    196c:	75 0f                	jne    0x197d
    196e:	bf 29 19             	mov    di,0x1929
    1971:	0e                   	push   cs
    1972:	57                   	push   di
    1973:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1976:	06                   	push   es
    1977:	57                   	push   di
    1978:	9a 8e 14 85 19       	call   0x1985:0x148e
    197d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1980:	06                   	push   es
    1981:	57                   	push   di
    1982:	9a 1c 18 aa 19       	call   0x19aa:0x181c
    1987:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    198a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    198d:	06                   	push   es
    198e:	57                   	push   di
    198f:	9a fa 64 22 1a       	call   0x1a22:0x64fa
    1994:	08 c0                	or     al,al
    1996:	74 14                	je     0x19ac
    1998:	8d 7e fe             	lea    di,[bp-0x2]
    199b:	16                   	push   ss
    199c:	57                   	push   di
    199d:	8d 7e fc             	lea    di,[bp-0x4]
    19a0:	16                   	push   ss
    19a1:	57                   	push   di
    19a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a5:	06                   	push   es
    19a6:	57                   	push   di
    19a7:	9a 9e 1a b9 19       	call   0x19b9:0x1a9e
    19ac:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19af:	06                   	push   es
    19b0:	57                   	push   di
    19b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19b4:	06                   	push   es
    19b5:	57                   	push   di
    19b6:	9a 3b 18 d2 19       	call   0x19d2:0x183b
    19bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19be:	26 80 a5 f4 00 fe    	and    BYTE PTR es:[di+0xf4],0xfe
    19c4:	8d be fa fd          	lea    di,[bp-0x206]
    19c8:	16                   	push   ss
    19c9:	57                   	push   di
    19ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19cd:	06                   	push   es
    19ce:	57                   	push   di
    19cf:	9a fe 17 fd 19       	call   0x19fd:0x17fe
    19d4:	bf 14 17             	mov    di,0x1714
    19d7:	1e                   	push   ds
    19d8:	57                   	push   di
    19d9:	9a be 18 a6 21       	call   0x21a6:0x18be
    19de:	74 09                	je     0x19e9
    19e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19e3:	26 80 8d f4 00 01    	or     BYTE PTR es:[di+0xf4],0x1
    19e9:	6a 00                	push   0x0
    19eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19ee:	06                   	push   es
    19ef:	57                   	push   di
    19f0:	9a 32 48 18 1a       	call   0x1a18:0x4832
    19f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19f8:	06                   	push   es
    19f9:	57                   	push   di
    19fa:	9a 1c 18 4f 1a       	call   0x1a4f:0x181c
    19ff:	08 c0                	or     al,al
    1a01:	74 17                	je     0x1a1a
    1a03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a06:	26 83 bd f1 00 00    	cmp    WORD PTR es:[di+0xf1],0x0
    1a0c:	7e 0c                	jle    0x1a1a
    1a0e:	26 ff b5 f1 00       	push   WORD PTR es:[di+0xf1]
    1a13:	06                   	push   es
    1a14:	57                   	push   di
    1a15:	9a 32 48 87 1a       	call   0x1a87:0x4832
    1a1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a1d:	06                   	push   es
    1a1e:	57                   	push   di
    1a1f:	9a fa 64 30 1a       	call   0x1a30:0x64fa
    1a24:	08 c0                	or     al,al
    1a26:	74 29                	je     0x1a51
    1a28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a2b:	06                   	push   es
    1a2c:	57                   	push   di
    1a2d:	9a b9 62 aa 1a       	call   0x1aaa:0x62b9
    1a32:	50                   	push   ax
    1a33:	9a ff ff 00 00       	call   0x0:0xffff
    1a38:	5a                   	pop    dx
    1a39:	3b c2                	cmp    ax,dx
    1a3b:	75 14                	jne    0x1a51
    1a3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a40:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    1a45:	75 0a                	jne    0x1a51
    1a47:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1a4a:	06                   	push   es
    1a4b:	57                   	push   di
    1a4c:	9a 12 1b 76 1a       	call   0x1a76:0x1b12
    1a51:	c9                   	leave
    1a52:	ca 08 00             	retf   0x8
    1a55:	c8 02 00 00          	enter  0x2,0x0
    1a59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a5c:	26 8b 85 d8 00       	mov    ax,WORD PTR es:[di+0xd8]
    1a61:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a64:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1a67:	c9                   	leave
    1a68:	ca 04 00             	retf   0x4
    1a6b:	55                   	push   bp
    1a6c:	89 e5                	mov    bp,sp
    1a6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a71:	06                   	push   es
    1a72:	57                   	push   di
    1a73:	9a 1c 18 24 1b       	call   0x1b24:0x181c
    1a78:	08 c0                	or     al,al
    1a7a:	75 0f                	jne    0x1a8b
    1a7c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1a7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a82:	06                   	push   es
    1a83:	57                   	push   di
    1a84:	9a 32 48 98 1a       	call   0x1a98:0x4832
    1a89:	eb 0f                	jmp    0x1a9a
    1a8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a8e:	26 ff b5 f1 00       	push   WORD PTR es:[di+0xf1]
    1a93:	06                   	push   es
    1a94:	57                   	push   di
    1a95:	9a 32 48 bb 1c       	call   0x1cbb:0x4832
    1a9a:	c9                   	leave
    1a9b:	ca 06 00             	retf   0x6
    1a9e:	c8 04 00 00          	enter  0x4,0x0
    1aa2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aa5:	06                   	push   es
    1aa6:	57                   	push   di
    1aa7:	9a b9 62 fb 1a       	call   0x1afb:0x62b9
    1aac:	50                   	push   ax
    1aad:	68 00 04             	push   0x400
    1ab0:	6a 00                	push   0x0
    1ab2:	6a 00                	push   0x0
    1ab4:	6a 00                	push   0x0
    1ab6:	9a 0a 1b 00 00       	call   0x0:0x1b0a
    1abb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1abe:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1ac1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ac4:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ac7:	58                   	pop    ax
    1ac8:	5a                   	pop    dx
    1ac9:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1acc:	26 89 05             	mov    WORD PTR es:[di],ax
    1acf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ad2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1ad5:	5a                   	pop    dx
    1ad6:	58                   	pop    ax
    1ad7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1ada:	26 89 05             	mov    WORD PTR es:[di],ax
    1add:	c9                   	leave
    1ade:	ca 0c 00             	retf   0xc
    1ae1:	c8 04 00 00          	enter  0x4,0x0
    1ae5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1ae8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1aeb:	5a                   	pop    dx
    1aec:	58                   	pop    ax
    1aed:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1af0:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1af3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1af6:	06                   	push   es
    1af7:	57                   	push   di
    1af8:	9a b9 62 b7 1b       	call   0x1bb7:0x62b9
    1afd:	50                   	push   ax
    1afe:	68 01 04             	push   0x401
    1b01:	6a 00                	push   0x0
    1b03:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b06:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b09:	9a c4 1b 00 00       	call   0x0:0x1bc4
    1b0e:	c9                   	leave
    1b0f:	ca 08 00             	retf   0x8
    1b12:	c8 06 04 00          	enter  0x406,0x0
    1b16:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1b19:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b1c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b1f:	06                   	push   es
    1b20:	57                   	push   di
    1b21:	9a 1c 18 68 1b       	call   0x1b68:0x181c
    1b26:	08 c0                	or     al,al
    1b28:	75 03                	jne    0x1b2d
    1b2a:	e9 cc 00             	jmp    0x1bf9
    1b2d:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    1b31:	7d 05                	jge    0x1b38
    1b33:	31 c0                	xor    ax,ax
    1b35:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b38:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b3b:	40                   	inc    ax
    1b3c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b3f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b45:	26 3b 85 f1 00       	cmp    ax,WORD PTR es:[di+0xf1]
    1b4a:	7c 0e                	jl     0x1b5a
    1b4c:	26 8b 85 f1 00       	mov    ax,WORD PTR es:[di+0xf1]
    1b51:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b54:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b57:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b5a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b5d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b63:	06                   	push   es
    1b64:	57                   	push   di
    1b65:	9a e1 1a 12 1c       	call   0x1c12:0x1ae1
    1b6a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1b6d:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1b70:	74 7a                	je     0x1bec
    1b72:	8d be fc fe          	lea    di,[bp-0x104]
    1b76:	16                   	push   ss
    1b77:	57                   	push   di
    1b78:	9a ff ff 00 00       	call   0x0:0xffff
    1b7d:	31 c0                	xor    ax,ax
    1b7f:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    1b83:	eb 04                	jmp    0x1b89
    1b85:	ff 86 fa fd          	inc    WORD PTR [bp-0x206]
    1b89:	8b be fa fd          	mov    di,WORD PTR [bp-0x206]
    1b8d:	c6 83 fc fd 00       	mov    BYTE PTR [bp+di-0x204],0x0
    1b92:	81 be fa fd ff 00    	cmp    WORD PTR [bp-0x206],0xff
    1b98:	75 eb                	jne    0x1b85
    1b9a:	c6 86 0c fe 81       	mov    BYTE PTR [bp-0x1f4],0x81
    1b9f:	c6 86 21 fe 81       	mov    BYTE PTR [bp-0x1df],0x81
    1ba4:	8d be fc fd          	lea    di,[bp-0x204]
    1ba8:	16                   	push   ss
    1ba9:	57                   	push   di
    1baa:	9a e8 1b 00 00       	call   0x0:0x1be8
    1baf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bb2:	06                   	push   es
    1bb3:	57                   	push   di
    1bb4:	9a b9 62 d0 1b       	call   0x1bd0:0x62b9
    1bb9:	50                   	push   ax
    1bba:	68 00 01             	push   0x100
    1bbd:	6a 25                	push   0x25
    1bbf:	6a 00                	push   0x0
    1bc1:	6a 01                	push   0x1
    1bc3:	9a dd 1b 00 00       	call   0x0:0x1bdd
    1bc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bcb:	06                   	push   es
    1bcc:	57                   	push   di
    1bcd:	9a b9 62 5e 1c       	call   0x1c5e:0x62b9
    1bd2:	50                   	push   ax
    1bd3:	68 01 01             	push   0x101
    1bd6:	6a 25                	push   0x25
    1bd8:	6a 00                	push   0x0
    1bda:	6a 01                	push   0x1
    1bdc:	9a e4 1d 00 00       	call   0x0:0x1de4
    1be1:	8d be fc fe          	lea    di,[bp-0x104]
    1be5:	16                   	push   ss
    1be6:	57                   	push   di
    1be7:	9a ff ff 00 00       	call   0x0:0xffff
    1bec:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1bef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf2:	26 89 85 f5 00       	mov    WORD PTR es:[di+0xf5],ax
    1bf7:	eb 55                	jmp    0x1c4e
    1bf9:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    1bfd:	7d 05                	jge    0x1c04
    1bff:	31 c0                	xor    ax,ax
    1c01:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1c04:	8d be fa fc          	lea    di,[bp-0x306]
    1c08:	16                   	push   ss
    1c09:	57                   	push   di
    1c0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c0d:	06                   	push   es
    1c0e:	57                   	push   di
    1c0f:	9a d8 14 30 1c       	call   0x1c30:0x14d8
    1c14:	83 c4 04             	add    sp,0x4
    1c17:	8a 86 fa fc          	mov    al,BYTE PTR [bp-0x306]
    1c1b:	30 e4                	xor    ah,ah
    1c1d:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    1c20:	7f 1c                	jg     0x1c3e
    1c22:	8d be fa fb          	lea    di,[bp-0x406]
    1c26:	16                   	push   ss
    1c27:	57                   	push   di
    1c28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c2b:	06                   	push   es
    1c2c:	57                   	push   di
    1c2d:	9a d8 14 4c 1c       	call   0x1c4c:0x14d8
    1c32:	83 c4 04             	add    sp,0x4
    1c35:	8a 86 fa fb          	mov    al,BYTE PTR [bp-0x406]
    1c39:	30 e4                	xor    ah,ah
    1c3b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1c3e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c41:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c47:	06                   	push   es
    1c48:	57                   	push   di
    1c49:	9a e1 1a 6e 1c       	call   0x1c6e:0x1ae1
    1c4e:	c9                   	leave
    1c4f:	ca 06 00             	retf   0x6
    1c52:	c8 04 00 00          	enter  0x4,0x0
    1c56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c59:	06                   	push   es
    1c5a:	57                   	push   di
    1c5b:	9a fa 64 d5 1d       	call   0x1dd5:0x64fa
    1c60:	08 c0                	or     al,al
    1c62:	75 02                	jne    0x1c66
    1c64:	eb 37                	jmp    0x1c9d
    1c66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c69:	06                   	push   es
    1c6a:	57                   	push   di
    1c6b:	9a 1c 18 86 1c       	call   0x1c86:0x181c
    1c70:	08 c0                	or     al,al
    1c72:	74 29                	je     0x1c9d
    1c74:	8d 7e fe             	lea    di,[bp-0x2]
    1c77:	16                   	push   ss
    1c78:	57                   	push   di
    1c79:	8d 7e fc             	lea    di,[bp-0x4]
    1c7c:	16                   	push   ss
    1c7d:	57                   	push   di
    1c7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c81:	06                   	push   es
    1c82:	57                   	push   di
    1c83:	9a 9e 1a 9b 1c       	call   0x1c9b:0x1a9e
    1c88:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c8b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1c8e:	75 0d                	jne    0x1c9d
    1c90:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c96:	06                   	push   es
    1c97:	57                   	push   di
    1c98:	9a 12 1b d3 1c       	call   0x1cd3:0x1b12
    1c9d:	c9                   	leave
    1c9e:	ca 04 00             	retf   0x4
    1ca1:	c8 02 00 00          	enter  0x2,0x0
    1ca5:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1ca9:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1cac:	c9                   	leave
    1cad:	ca 04 00             	retf   0x4
    1cb0:	55                   	push   bp
    1cb1:	89 e5                	mov    bp,sp
    1cb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cb6:	06                   	push   es
    1cb7:	57                   	push   di
    1cb8:	9a 96 48 df 1c       	call   0x1cdf:0x4896
    1cbd:	08 c0                	or     al,al
    1cbf:	74 20                	je     0x1ce1
    1cc1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cc4:	26 c4 bd f9 00       	les    di,DWORD PTR es:[di+0xf9]
    1cc9:	06                   	push   es
    1cca:	57                   	push   di
    1ccb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cce:	06                   	push   es
    1ccf:	57                   	push   di
    1cd0:	9a 8e 14 4d 1d       	call   0x1d4d:0x148e
    1cd5:	6a 00                	push   0x0
    1cd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cda:	06                   	push   es
    1cdb:	57                   	push   di
    1cdc:	9a d6 48 ca 22       	call   0x22ca:0x48d6
    1ce1:	c9                   	leave
    1ce2:	ca 04 00             	retf   0x4
    1ce5:	c8 0e 00 00          	enter  0xe,0x0
    1ce9:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1ced:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1cf0:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1cf3:	30 e4                	xor    ah,ah
    1cf5:	3d 1b 00             	cmp    ax,0x1b
    1cf8:	75 10                	jne    0x1d0a
    1cfa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cfd:	06                   	push   es
    1cfe:	57                   	push   di
    1cff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d02:	26 ff 9d 80 00       	call   DWORD PTR es:[di+0x80]
    1d07:	e9 01 01             	jmp    0x1e0b
    1d0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d0d:	06                   	push   es
    1d0e:	57                   	push   di
    1d0f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d12:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    1d16:	08 c0                	or     al,al
    1d18:	74 0b                	je     0x1d25
    1d1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d1d:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    1d23:	74 03                	je     0x1d28
    1d25:	e9 e3 00             	jmp    0x1e0b
    1d28:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d2b:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1d2e:	30 e4                	xor    ah,ah
    1d30:	3d 08 00             	cmp    ax,0x8
    1d33:	75 03                	jne    0x1d38
    1d35:	e9 d3 00             	jmp    0x1e0b
    1d38:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d3b:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1d3e:	30 e4                	xor    ah,ah
    1d40:	3d 0d 00             	cmp    ax,0xd
    1d43:	75 0d                	jne    0x1d52
    1d45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d48:	06                   	push   es
    1d49:	57                   	push   di
    1d4a:	9a ff 23 64 1d       	call   0x1d64:0x23ff
    1d4f:	e9 b9 00             	jmp    0x1e0b
    1d52:	8d 7e fc             	lea    di,[bp-0x4]
    1d55:	16                   	push   ss
    1d56:	57                   	push   di
    1d57:	8d 7e fa             	lea    di,[bp-0x6]
    1d5a:	16                   	push   ss
    1d5b:	57                   	push   di
    1d5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d5f:	06                   	push   es
    1d60:	57                   	push   di
    1d61:	9a 9e 1a 7b 1d       	call   0x1d7b:0x1a9e
    1d66:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1d69:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    1d6c:	3d 01 00             	cmp    ax,0x1
    1d6f:	7e 29                	jle    0x1d9a
    1d71:	6a 2e                	push   0x2e
    1d73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d76:	06                   	push   es
    1d77:	57                   	push   di
    1d78:	9a 13 21 88 1d       	call   0x1d88:0x2113
    1d7d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1d80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d83:	06                   	push   es
    1d84:	57                   	push   di
    1d85:	9a b5 1f 98 1d       	call   0x1d98:0x1fb5
    1d8a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1d8d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1d90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d93:	06                   	push   es
    1d94:	57                   	push   di
    1d95:	9a 12 1b aa 1d       	call   0x1daa:0x1b12
    1d9a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d9d:	06                   	push   es
    1d9e:	57                   	push   di
    1d9f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1da2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1da5:	06                   	push   es
    1da6:	57                   	push   di
    1da7:	9a 75 27 fa 1d       	call   0x1dfa:0x2775
    1dac:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1daf:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1db3:	74 56                	je     0x1e0b
    1db5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1db8:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1dbb:	88 46 f6             	mov    BYTE PTR [bp-0xa],al
    1dbe:	c6 46 f7 00          	mov    BYTE PTR [bp-0x9],0x0
    1dc2:	8d 46 f6             	lea    ax,[bp-0xa]
    1dc5:	8c d2                	mov    dx,ss
    1dc7:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1dca:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    1dcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dd0:	06                   	push   es
    1dd1:	57                   	push   di
    1dd2:	9a b9 62 17 22       	call   0x2217:0x62b9
    1dd7:	50                   	push   ax
    1dd8:	68 12 04             	push   0x412
    1ddb:	6a 00                	push   0x0
    1ddd:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1de0:	ff 76 f2             	push   WORD PTR [bp-0xe]
    1de3:	9a 28 22 00 00       	call   0x0:0x2228
    1de8:	8d 7e fc             	lea    di,[bp-0x4]
    1deb:	16                   	push   ss
    1dec:	57                   	push   di
    1ded:	8d 7e fa             	lea    di,[bp-0x6]
    1df0:	16                   	push   ss
    1df1:	57                   	push   di
    1df2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1df5:	06                   	push   es
    1df6:	57                   	push   di
    1df7:	9a 9e 1a 09 1e       	call   0x1e09:0x1a9e
    1dfc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1dff:	6a 00                	push   0x0
    1e01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e04:	06                   	push   es
    1e05:	57                   	push   di
    1e06:	9a 39 1f 31 1e       	call   0x1e31:0x1f39
    1e0b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1e0e:	c9                   	leave
    1e0f:	ca 08 00             	retf   0x8
    1e12:	c8 0a 00 00          	enter  0xa,0x0
    1e16:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    1e1a:	74 03                	je     0x1e1f
    1e1c:	e9 16 01             	jmp    0x1f35
    1e1f:	8d 7e fe             	lea    di,[bp-0x2]
    1e22:	16                   	push   ss
    1e23:	57                   	push   di
    1e24:	8d 7e fc             	lea    di,[bp-0x4]
    1e27:	16                   	push   ss
    1e28:	57                   	push   di
    1e29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e2c:	06                   	push   es
    1e2d:	57                   	push   di
    1e2e:	9a 9e 1a 5e 1e       	call   0x1e5e:0x1a9e
    1e33:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    1e37:	75 03                	jne    0x1e3c
    1e39:	e9 90 00             	jmp    0x1ecc
    1e3c:	83 7e 0c 27          	cmp    WORD PTR [bp+0xc],0x27
    1e40:	75 41                	jne    0x1e83
    1e42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e45:	26 ff 85 f5 00       	inc    WORD PTR es:[di+0xf5]
    1e4a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e4d:	40                   	inc    ax
    1e4e:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1e51:	75 15                	jne    0x1e68
    1e53:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1e56:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1e59:	06                   	push   es
    1e5a:	57                   	push   di
    1e5b:	9a e1 1a ae 1e       	call   0x1eae:0x1ae1
    1e60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e63:	26 ff 85 f5 00       	inc    WORD PTR es:[di+0xf5]
    1e68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e6b:	26 8b 85 f5 00       	mov    ax,WORD PTR es:[di+0xf5]
    1e70:	26 3b 85 f1 00       	cmp    ax,WORD PTR es:[di+0xf1]
    1e75:	7e 0a                	jle    0x1e81
    1e77:	26 8b 85 f1 00       	mov    ax,WORD PTR es:[di+0xf1]
    1e7c:	26 89 85 f5 00       	mov    WORD PTR es:[di+0xf5],ax
    1e81:	eb 47                	jmp    0x1eca
    1e83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e86:	26 ff 8d f5 00       	dec    WORD PTR es:[di+0xf5]
    1e8b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e8e:	40                   	inc    ax
    1e8f:	40                   	inc    ax
    1e90:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1e93:	75 23                	jne    0x1eb8
    1e95:	26 8b 85 f5 00       	mov    ax,WORD PTR es:[di+0xf5]
    1e9a:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    1e9d:	7e 19                	jle    0x1eb8
    1e9f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ea2:	40                   	inc    ax
    1ea3:	50                   	push   ax
    1ea4:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1ea7:	40                   	inc    ax
    1ea8:	50                   	push   ax
    1ea9:	06                   	push   es
    1eaa:	57                   	push   di
    1eab:	9a e1 1a f6 1e       	call   0x1ef6:0x1ae1
    1eb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb3:	26 ff 8d f5 00       	dec    WORD PTR es:[di+0xf5]
    1eb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ebb:	26 83 bd f5 00 00    	cmp    WORD PTR es:[di+0xf5],0x0
    1ec1:	7d 07                	jge    0x1eca
    1ec3:	31 c0                	xor    ax,ax
    1ec5:	26 89 85 f5 00       	mov    WORD PTR es:[di+0xf5],ax
    1eca:	eb 69                	jmp    0x1f35
    1ecc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ecf:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    1ed2:	3d 01 00             	cmp    ax,0x1
    1ed5:	7e 23                	jle    0x1efa
    1ed7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1eda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1edd:	26 3b 85 f5 00       	cmp    ax,WORD PTR es:[di+0xf5]
    1ee2:	75 05                	jne    0x1ee9
    1ee4:	26 ff 8d f5 00       	dec    WORD PTR es:[di+0xf5]
    1ee9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eec:	26 ff b5 f5 00       	push   WORD PTR es:[di+0xf5]
    1ef1:	06                   	push   es
    1ef2:	57                   	push   di
    1ef3:	9a 12 1b 0b 1f       	call   0x1f0b:0x1b12
    1ef8:	eb 3b                	jmp    0x1f35
    1efa:	83 7e 0c 25          	cmp    WORD PTR [bp+0xc],0x25
    1efe:	75 0f                	jne    0x1f0f
    1f00:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f06:	06                   	push   es
    1f07:	57                   	push   di
    1f08:	9a 87 1f 22 1f       	call   0x1f22:0x1f87
    1f0d:	eb 26                	jmp    0x1f35
    1f0f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1f12:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    1f15:	75 0f                	jne    0x1f26
    1f17:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f1a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f1d:	06                   	push   es
    1f1e:	57                   	push   di
    1f1f:	9a 12 1b 33 1f       	call   0x1f33:0x1b12
    1f24:	eb 0f                	jmp    0x1f35
    1f26:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f29:	6a 01                	push   0x1
    1f2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f2e:	06                   	push   es
    1f2f:	57                   	push   di
    1f30:	9a 39 1f 51 1f       	call   0x1f51:0x1f39
    1f35:	c9                   	leave
    1f36:	ca 08 00             	retf   0x8
    1f39:	c8 02 01 00          	enter  0x102,0x0
    1f3d:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1f40:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    1f43:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f46:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f4c:	06                   	push   es
    1f4d:	57                   	push   di
    1f4e:	9a b5 1f 64 1f       	call   0x1f64:0x1fb5
    1f53:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f56:	8d be fe fe          	lea    di,[bp-0x102]
    1f5a:	16                   	push   ss
    1f5b:	57                   	push   di
    1f5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f5f:	06                   	push   es
    1f60:	57                   	push   di
    1f61:	9a fe 17 81 1f       	call   0x1f81:0x17fe
    1f66:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f69:	e8 91 ed             	call   0xcfd
    1f6c:	08 c0                	or     al,al
    1f6e:	74 06                	je     0x1f76
    1f70:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    1f73:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f76:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f7c:	06                   	push   es
    1f7d:	57                   	push   di
    1f7e:	9a 12 1b 9f 1f       	call   0x1f9f:0x1b12
    1f83:	c9                   	leave
    1f84:	ca 08 00             	retf   0x8
    1f87:	c8 02 00 00          	enter  0x2,0x0
    1f8b:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1f8e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f91:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    1f94:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f9a:	06                   	push   es
    1f9b:	57                   	push   di
    1f9c:	9a f2 1f af 1f       	call   0x1faf:0x1ff2
    1fa1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1fa4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fa7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1faa:	06                   	push   es
    1fab:	57                   	push   di
    1fac:	9a 12 1b da 1f       	call   0x1fda:0x1b12
    1fb1:	c9                   	leave
    1fb2:	ca 06 00             	retf   0x6
    1fb5:	c8 02 01 00          	enter  0x102,0x0
    1fb9:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1fbc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1fbf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fc5:	26 3b 85 f1 00       	cmp    ax,WORD PTR es:[di+0xf1]
    1fca:	7d 1f                	jge    0x1feb
    1fcc:	8d be fe fe          	lea    di,[bp-0x102]
    1fd0:	16                   	push   ss
    1fd1:	57                   	push   di
    1fd2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fd5:	06                   	push   es
    1fd6:	57                   	push   di
    1fd7:	9a fe 17 10 20       	call   0x2010:0x17fe
    1fdc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1fdf:	e8 1b ed             	call   0xcfd
    1fe2:	08 c0                	or     al,al
    1fe4:	74 05                	je     0x1feb
    1fe6:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1fe9:	eb d4                	jmp    0x1fbf
    1feb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1fee:	c9                   	leave
    1fef:	ca 06 00             	retf   0x6
    1ff2:	c8 02 01 00          	enter  0x102,0x0
    1ff6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1ff9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ffc:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2000:	7c 1f                	jl     0x2021
    2002:	8d be fe fe          	lea    di,[bp-0x102]
    2006:	16                   	push   ss
    2007:	57                   	push   di
    2008:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    200b:	06                   	push   es
    200c:	57                   	push   di
    200d:	9a fe 17 32 20       	call   0x2032:0x17fe
    2012:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2015:	e8 e5 ec             	call   0xcfd
    2018:	08 c0                	or     al,al
    201a:	74 05                	je     0x2021
    201c:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    201f:	eb db                	jmp    0x1ffc
    2021:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2025:	7d 10                	jge    0x2037
    2027:	ff 76 fe             	push   WORD PTR [bp-0x2]
    202a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    202d:	06                   	push   es
    202e:	57                   	push   di
    202f:	9a b5 1f 54 20       	call   0x2054:0x1fb5
    2034:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2037:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    203a:	c9                   	leave
    203b:	ca 06 00             	retf   0x6
    203e:	c8 04 00 00          	enter  0x4,0x0
    2042:	8d 7e fe             	lea    di,[bp-0x2]
    2045:	16                   	push   ss
    2046:	57                   	push   di
    2047:	8d 7e fc             	lea    di,[bp-0x4]
    204a:	16                   	push   ss
    204b:	57                   	push   di
    204c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    204f:	06                   	push   es
    2050:	57                   	push   di
    2051:	9a 9e 1a 8c 20       	call   0x208c:0x1a9e
    2056:	83 7e 0c 24          	cmp    WORD PTR [bp+0xc],0x24
    205a:	75 56                	jne    0x20b2
    205c:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    2060:	74 38                	je     0x209a
    2062:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2065:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2068:	26 3b 85 f5 00       	cmp    ax,WORD PTR es:[di+0xf5]
    206d:	74 10                	je     0x207f
    206f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2072:	40                   	inc    ax
    2073:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2076:	74 07                	je     0x207f
    2078:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    207b:	40                   	inc    ax
    207c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    207f:	6a 00                	push   0x0
    2081:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2084:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2087:	06                   	push   es
    2088:	57                   	push   di
    2089:	9a e1 1a 96 20       	call   0x2096:0x1ae1
    208e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2091:	06                   	push   es
    2092:	57                   	push   di
    2093:	9a 52 1c a4 20       	call   0x20a4:0x1c52
    2098:	eb 0c                	jmp    0x20a6
    209a:	6a 00                	push   0x0
    209c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    209f:	06                   	push   es
    20a0:	57                   	push   di
    20a1:	9a 12 1b e5 20       	call   0x20e5:0x1b12
    20a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a9:	31 c0                	xor    ax,ax
    20ab:	26 89 85 f5 00       	mov    WORD PTR es:[di+0xf5],ax
    20b0:	eb 5d                	jmp    0x210f
    20b2:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    20b6:	74 3b                	je     0x20f3
    20b8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    20bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20be:	26 3b 85 f5 00       	cmp    ax,WORD PTR es:[di+0xf5]
    20c3:	74 10                	je     0x20d5
    20c5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    20c8:	40                   	inc    ax
    20c9:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    20cc:	74 07                	je     0x20d5
    20ce:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    20d1:	48                   	dec    ax
    20d2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    20d5:	ff 76 fe             	push   WORD PTR [bp-0x2]
    20d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20db:	26 ff b5 f1 00       	push   WORD PTR es:[di+0xf1]
    20e0:	06                   	push   es
    20e1:	57                   	push   di
    20e2:	9a e1 1a ef 20       	call   0x20ef:0x1ae1
    20e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20ea:	06                   	push   es
    20eb:	57                   	push   di
    20ec:	9a 52 1c 00 21       	call   0x2100:0x1c52
    20f1:	eb 0f                	jmp    0x2102
    20f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20f6:	26 ff b5 f1 00       	push   WORD PTR es:[di+0xf1]
    20fb:	06                   	push   es
    20fc:	57                   	push   di
    20fd:	9a 12 1b 37 21       	call   0x2137:0x1b12
    2102:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2105:	26 8b 85 f1 00       	mov    ax,WORD PTR es:[di+0xf1]
    210a:	26 89 85 f5 00       	mov    WORD PTR es:[di+0xf5],ax
    210f:	c9                   	leave
    2110:	ca 08 00             	retf   0x8
    2113:	c8 0e 03 00          	enter  0x30e,0x0
    2117:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    211a:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    2120:	74 03                	je     0x2125
    2122:	e9 54 01             	jmp    0x2279
    2125:	8d 7e fe             	lea    di,[bp-0x2]
    2128:	16                   	push   ss
    2129:	57                   	push   di
    212a:	8d 7e fc             	lea    di,[bp-0x4]
    212d:	16                   	push   ss
    212e:	57                   	push   di
    212f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2132:	06                   	push   es
    2133:	57                   	push   di
    2134:	9a 9e 1a 5b 21       	call   0x215b:0x1a9e
    2139:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    213c:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    213f:	3d 01 00             	cmp    ax,0x1
    2142:	7f 38                	jg     0x217c
    2144:	83 7e 0a 08          	cmp    WORD PTR [bp+0xa],0x8
    2148:	75 32                	jne    0x217c
    214a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    214d:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2150:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2153:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2156:	06                   	push   es
    2157:	57                   	push   di
    2158:	9a 87 1f 6f 21       	call   0x216f:0x1f87
    215d:	8d 7e fe             	lea    di,[bp-0x2]
    2160:	16                   	push   ss
    2161:	57                   	push   di
    2162:	8d 7e fc             	lea    di,[bp-0x4]
    2165:	16                   	push   ss
    2166:	57                   	push   di
    2167:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    216a:	06                   	push   es
    216b:	57                   	push   di
    216c:	9a 9e 1a 98 21       	call   0x2198:0x1a9e
    2171:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2174:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    2177:	75 03                	jne    0x217c
    2179:	e9 fd 00             	jmp    0x2279
    217c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    217f:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    2182:	3d 01 00             	cmp    ax,0x1
    2185:	7d 03                	jge    0x218a
    2187:	e9 ef 00             	jmp    0x2279
    218a:	8d be f2 fc          	lea    di,[bp-0x30e]
    218e:	16                   	push   ss
    218f:	57                   	push   di
    2190:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2193:	06                   	push   es
    2194:	57                   	push   di
    2195:	9a d8 14 c3 21       	call   0x21c3:0x14d8
    219a:	8d be f6 fe          	lea    di,[bp-0x10a]
    219e:	16                   	push   ss
    219f:	57                   	push   di
    21a0:	68 ff 00             	push   0xff
    21a3:	9a e7 17 e0 21       	call   0x21e0:0x17e7
    21a8:	8d be f6 fe          	lea    di,[bp-0x10a]
    21ac:	16                   	push   ss
    21ad:	57                   	push   di
    21ae:	68 ff 00             	push   0xff
    21b1:	ff 76 fe             	push   WORD PTR [bp-0x2]
    21b4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    21b7:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    21ba:	50                   	push   ax
    21bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21be:	06                   	push   es
    21bf:	57                   	push   di
    21c0:	9a 2e 2b 42 22       	call   0x2242:0x2b2e
    21c5:	8d be f2 fc          	lea    di,[bp-0x30e]
    21c9:	16                   	push   ss
    21ca:	57                   	push   di
    21cb:	8d be f6 fe          	lea    di,[bp-0x10a]
    21cf:	16                   	push   ss
    21d0:	57                   	push   di
    21d1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    21d4:	40                   	inc    ax
    21d5:	50                   	push   ax
    21d6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    21d9:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    21dc:	50                   	push   ax
    21dd:	9a 0b 18 ee 21       	call   0x21ee:0x180b
    21e2:	8d be f6 fe          	lea    di,[bp-0x10a]
    21e6:	16                   	push   ss
    21e7:	57                   	push   di
    21e8:	68 ff 00             	push   0xff
    21eb:	9a e7 17 1f 24       	call   0x241f:0x17e7
    21f0:	8d be f6 fd          	lea    di,[bp-0x20a]
    21f4:	16                   	push   ss
    21f5:	57                   	push   di
    21f6:	8d be f6 fe          	lea    di,[bp-0x10a]
    21fa:	16                   	push   ss
    21fb:	57                   	push   di
    21fc:	9a 4c 0d ba 22       	call   0x22ba:0xd4c
    2201:	8d 86 f6 fd          	lea    ax,[bp-0x20a]
    2205:	8c d2                	mov    dx,ss
    2207:	89 86 f2 fd          	mov    WORD PTR [bp-0x20e],ax
    220b:	89 96 f4 fd          	mov    WORD PTR [bp-0x20c],dx
    220f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2212:	06                   	push   es
    2213:	57                   	push   di
    2214:	9a b9 62 2c 23       	call   0x232c:0x62b9
    2219:	50                   	push   ax
    221a:	68 12 04             	push   0x412
    221d:	6a 00                	push   0x0
    221f:	ff b6 f4 fd          	push   WORD PTR [bp-0x20c]
    2223:	ff b6 f2 fd          	push   WORD PTR [bp-0x20e]
    2227:	9a ff ff 00 00       	call   0x0:0xffff
    222c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    222f:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    2232:	3d 01 00             	cmp    ax,0x1
    2235:	74 1f                	je     0x2256
    2237:	ff 76 fe             	push   WORD PTR [bp-0x2]
    223a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    223d:	06                   	push   es
    223e:	57                   	push   di
    223f:	9a b5 1f 52 22       	call   0x2252:0x1fb5
    2244:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2247:	ff 76 fe             	push   WORD PTR [bp-0x2]
    224a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    224d:	06                   	push   es
    224e:	57                   	push   di
    224f:	9a 12 1b 68 22       	call   0x2268:0x1b12
    2254:	eb 23                	jmp    0x2279
    2256:	8d 7e fe             	lea    di,[bp-0x2]
    2259:	16                   	push   ss
    225a:	57                   	push   di
    225b:	8d 7e fc             	lea    di,[bp-0x4]
    225e:	16                   	push   ss
    225f:	57                   	push   di
    2260:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2263:	06                   	push   es
    2264:	57                   	push   di
    2265:	9a 9e 1a 77 22       	call   0x2277:0x1a9e
    226a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    226d:	48                   	dec    ax
    226e:	50                   	push   ax
    226f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2272:	06                   	push   es
    2273:	57                   	push   di
    2274:	9a 12 1b 89 22       	call   0x2289:0x1b12
    2279:	c9                   	leave
    227a:	ca 06 00             	retf   0x6
    227d:	c8 00 01 00          	enter  0x100,0x0
    2281:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2284:	06                   	push   es
    2285:	57                   	push   di
    2286:	9a 1c 18 b5 22       	call   0x22b5:0x181c
    228b:	08 c0                	or     al,al
    228d:	74 4f                	je     0x22de
    228f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2292:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2297:	75 45                	jne    0x22de
    2299:	26 f6 85 f4 00 02    	test   BYTE PTR es:[di+0xf4],0x2
    229f:	75 2b                	jne    0x22cc
    22a1:	81 c7 f9 00          	add    di,0xf9
    22a5:	06                   	push   es
    22a6:	57                   	push   di
    22a7:	8d be 00 ff          	lea    di,[bp-0x100]
    22ab:	16                   	push   ss
    22ac:	57                   	push   di
    22ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22b0:	06                   	push   es
    22b1:	57                   	push   di
    22b2:	9a d8 14 da 22       	call   0x22da:0x14d8
    22b7:	9a 51 06 22 23       	call   0x2322:0x651
    22bc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    22bf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    22c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c5:	06                   	push   es
    22c6:	57                   	push   di
    22c7:	9a 3e 4d ec 22       	call   0x22ec:0x4d3e
    22cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22cf:	26 80 a5 f4 00 fd    	and    BYTE PTR es:[di+0xf4],0xfd
    22d5:	06                   	push   es
    22d6:	57                   	push   di
    22d7:	9a 52 1c 1d 23       	call   0x231d:0x1c52
    22dc:	eb 10                	jmp    0x22ee
    22de:	ff 76 0c             	push   WORD PTR [bp+0xc]
    22e1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    22e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22e7:	06                   	push   es
    22e8:	57                   	push   di
    22e9:	9a 3e 4d 04 23       	call   0x2304:0x4d3e
    22ee:	c9                   	leave
    22ef:	ca 08 00             	retf   0x8
    22f2:	c8 06 01 00          	enter  0x106,0x0
    22f6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    22f9:	ff 76 0a             	push   WORD PTR [bp+0xa]
    22fc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ff:	06                   	push   es
    2300:	57                   	push   di
    2301:	9a 8b 4d 9a 23       	call   0x239a:0x4d8b
    2306:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2309:	81 c7 f9 00          	add    di,0xf9
    230d:	06                   	push   es
    230e:	57                   	push   di
    230f:	8d be fa fe          	lea    di,[bp-0x106]
    2313:	16                   	push   ss
    2314:	57                   	push   di
    2315:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2318:	06                   	push   es
    2319:	57                   	push   di
    231a:	9a d8 14 44 23       	call   0x2344:0x14d8
    231f:	9a 51 06 dc 24       	call   0x24dc:0x651
    2324:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2327:	06                   	push   es
    2328:	57                   	push   di
    2329:	9a fa 64 f9 23       	call   0x23f9:0x64fa
    232e:	08 c0                	or     al,al
    2330:	74 39                	je     0x236b
    2332:	8d 7e fe             	lea    di,[bp-0x2]
    2335:	16                   	push   ss
    2336:	57                   	push   di
    2337:	8d 7e fc             	lea    di,[bp-0x4]
    233a:	16                   	push   ss
    233b:	57                   	push   di
    233c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    233f:	06                   	push   es
    2340:	57                   	push   di
    2341:	9a 9e 1a 51 23       	call   0x2351:0x1a9e
    2346:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2349:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234c:	06                   	push   es
    234d:	57                   	push   di
    234e:	9a b5 1f 69 23       	call   0x2369:0x1fb5
    2353:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2356:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2359:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    235c:	74 0d                	je     0x236b
    235e:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2361:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2364:	06                   	push   es
    2365:	57                   	push   di
    2366:	9a 12 1b 8c 23       	call   0x238c:0x1b12
    236b:	c9                   	leave
    236c:	ca 08 00             	retf   0x8
    236f:	55                   	push   bp
    2370:	89 e5                	mov    bp,sp
    2372:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2375:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2378:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    237b:	06                   	push   es
    237c:	57                   	push   di
    237d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2380:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    2384:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2387:	06                   	push   es
    2388:	57                   	push   di
    2389:	9a 1c 18 ca 23       	call   0x23ca:0x181c
    238e:	08 c0                	or     al,al
    2390:	74 28                	je     0x23ba
    2392:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2395:	06                   	push   es
    2396:	57                   	push   di
    2397:	9a 96 48 37 24       	call   0x2437:0x4896
    239c:	08 c0                	or     al,al
    239e:	74 1a                	je     0x23ba
    23a0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    23a3:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    23a7:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    23ab:	0d 04 00             	or     ax,0x4
    23ae:	81 ca 00 00          	or     dx,0x0
    23b2:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    23b6:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    23ba:	c9                   	leave
    23bb:	ca 08 00             	retf   0x8
    23be:	c8 02 01 00          	enter  0x102,0x0
    23c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c5:	06                   	push   es
    23c6:	57                   	push   di
    23c7:	9a 1c 18 df 23       	call   0x23df:0x181c
    23cc:	08 c0                	or     al,al
    23ce:	74 1b                	je     0x23eb
    23d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d3:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    23d8:	75 11                	jne    0x23eb
    23da:	06                   	push   es
    23db:	57                   	push   di
    23dc:	9a ff 23 e9 23       	call   0x23e9:0x23ff
    23e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e4:	06                   	push   es
    23e5:	57                   	push   di
    23e6:	9a 52 1c 11 24       	call   0x2411:0x1c52
    23eb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23ee:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23f4:	06                   	push   es
    23f5:	57                   	push   di
    23f6:	9a d2 55 ff ff       	call   0xffff:0x55d2
    23fb:	c9                   	leave
    23fc:	ca 08 00             	retf   0x8
    23ff:	c8 02 02 00          	enter  0x202,0x0
    2403:	8d be fe fd          	lea    di,[bp-0x202]
    2407:	16                   	push   ss
    2408:	57                   	push   di
    2409:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    240c:	06                   	push   es
    240d:	57                   	push   di
    240e:	9a d8 14 29 24       	call   0x2429:0x14d8
    2413:	8d be 00 ff          	lea    di,[bp-0x100]
    2417:	16                   	push   ss
    2418:	57                   	push   di
    2419:	68 ff 00             	push   0xff
    241c:	9a e7 17 b3 24       	call   0x24b3:0x17e7
    2421:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2424:	06                   	push   es
    2425:	57                   	push   di
    2426:	9a 1c 18 51 24       	call   0x2451:0x181c
    242b:	08 c0                	or     al,al
    242d:	74 59                	je     0x2488
    242f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2432:	06                   	push   es
    2433:	57                   	push   di
    2434:	9a 96 48 ff ff       	call   0xffff:0x4896
    2439:	08 c0                	or     al,al
    243b:	74 4b                	je     0x2488
    243d:	8d be 00 ff          	lea    di,[bp-0x100]
    2441:	16                   	push   ss
    2442:	57                   	push   di
    2443:	8d be fe fe          	lea    di,[bp-0x102]
    2447:	16                   	push   ss
    2448:	57                   	push   di
    2449:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    244c:	06                   	push   es
    244d:	57                   	push   di
    244e:	9a 76 2a 7c 24       	call   0x247c:0x2a76
    2453:	08 c0                	or     al,al
    2455:	75 31                	jne    0x2488
    2457:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    245a:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    245f:	75 0f                	jne    0x2470
    2461:	26 80 8d f4 00 02    	or     BYTE PTR es:[di+0xf4],0x2
    2467:	06                   	push   es
    2468:	57                   	push   di
    2469:	26 c4 3d             	les    di,DWORD PTR es:[di]
    246c:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    2470:	ff b6 fe fe          	push   WORD PTR [bp-0x102]
    2474:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2477:	06                   	push   es
    2478:	57                   	push   di
    2479:	9a 12 1b 86 24       	call   0x2486:0x1b12
    247e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2481:	06                   	push   es
    2482:	57                   	push   di
    2483:	9a 8c 24 a5 24       	call   0x24a5:0x248c
    2488:	c9                   	leave
    2489:	ca 04 00             	retf   0x4
    248c:	c8 08 02 00          	enter  0x208,0x0
    2490:	6a 00                	push   0x0
    2492:	9a 49 28 00 00       	call   0x0:0x2849
    2497:	8d be 00 fe          	lea    di,[bp-0x200]
    249b:	16                   	push   ss
    249c:	57                   	push   di
    249d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24a0:	06                   	push   es
    24a1:	57                   	push   di
    24a2:	9a fe 17 f9 24       	call   0x24f9:0x17fe
    24a7:	8d be 00 ff          	lea    di,[bp-0x100]
    24ab:	16                   	push   ss
    24ac:	57                   	push   di
    24ad:	68 ff 00             	push   0xff
    24b0:	9a e7 17 ea 24       	call   0x24ea:0x17e7
    24b5:	8d be f8 fd          	lea    di,[bp-0x208]
    24b9:	16                   	push   ss
    24ba:	57                   	push   di
    24bb:	68 68 f0             	push   0xf068
    24be:	8d 86 00 ff          	lea    ax,[bp-0x100]
    24c2:	8c d2                	mov    dx,ss
    24c4:	89 86 f8 fe          	mov    WORD PTR [bp-0x108],ax
    24c8:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
    24cc:	c6 86 fc fe 04       	mov    BYTE PTR [bp-0x104],0x4
    24d1:	8d be f8 fe          	lea    di,[bp-0x108]
    24d5:	16                   	push   ss
    24d6:	57                   	push   di
    24d7:	6a 00                	push   0x0
    24d9:	9a 50 09 00 25       	call   0x2500:0x950
    24de:	8d be 00 ff          	lea    di,[bp-0x100]
    24e2:	16                   	push   ss
    24e3:	57                   	push   di
    24e4:	68 ff 00             	push   0xff
    24e7:	9a e7 17 07 25       	call   0x2507:0x17e7
    24ec:	8d be 00 ff          	lea    di,[bp-0x100]
    24f0:	16                   	push   ss
    24f1:	57                   	push   di
    24f2:	b0 01                	mov    al,0x1
    24f4:	50                   	push   ax
    24f5:	b8 22 00             	mov    ax,0x22
    24f8:	ba ab 27             	mov    dx,0x27ab
    24fb:	52                   	push   dx
    24fc:	50                   	push   ax
    24fd:	9a e6 28 58 29       	call   0x2958:0x28e6
    2502:	52                   	push   dx
    2503:	50                   	push   ax
    2504:	9a 99 13 3c 25       	call   0x253c:0x1399
    2509:	c9                   	leave
    250a:	ca 04 00             	retf   0x4
    250d:	c8 00 01 00          	enter  0x100,0x0
    2511:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2515:	75 29                	jne    0x2540
    2517:	8d be 00 ff          	lea    di,[bp-0x100]
    251b:	16                   	push   ss
    251c:	57                   	push   di
    251d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2520:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2525:	06                   	push   es
    2526:	57                   	push   di
    2527:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    252a:	06                   	push   es
    252b:	57                   	push   di
    252c:	6a 20                	push   0x20
    252e:	e8 d8 e3             	call   0x909
    2531:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2534:	06                   	push   es
    2535:	57                   	push   di
    2536:	68 ff 00             	push   0xff
    2539:	9a e7 17 6c 25       	call   0x256c:0x17e7
    253e:	eb 2e                	jmp    0x256e
    2540:	8d be 00 ff          	lea    di,[bp-0x100]
    2544:	16                   	push   ss
    2545:	57                   	push   di
    2546:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2549:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    254e:	06                   	push   es
    254f:	57                   	push   di
    2550:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2553:	06                   	push   es
    2554:	57                   	push   di
    2555:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2558:	26 8a 85 f0 00       	mov    al,BYTE PTR es:[di+0xf0]
    255d:	50                   	push   ax
    255e:	e8 a8 e3             	call   0x909
    2561:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2564:	06                   	push   es
    2565:	57                   	push   di
    2566:	68 ff 00             	push   0xff
    2569:	9a e7 17 98 25       	call   0x2598:0x17e7
    256e:	c9                   	leave
    256f:	ca 0a 00             	retf   0xa
    2572:	c8 0c 02 00          	enter  0x20c,0x0
    2576:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2579:	26 8a 05             	mov    al,BYTE PTR es:[di]
    257c:	30 e4                	xor    ah,ah
    257e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2581:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
    2586:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    258b:	06                   	push   es
    258c:	57                   	push   di
    258d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2590:	06                   	push   es
    2591:	57                   	push   di
    2592:	68 ff 00             	push   0xff
    2595:	9a e7 17 f0 25       	call   0x25f0:0x17e7
    259a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    259d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    25a2:	26 8a 05             	mov    al,BYTE PTR es:[di]
    25a5:	30 e4                	xor    ah,ah
    25a7:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    25aa:	b8 01 00             	mov    ax,0x1
    25ad:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    25b0:	7e 03                	jle    0x25b5
    25b2:	e9 83 00             	jmp    0x2638
    25b5:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    25b8:	eb 03                	jmp    0x25bd
    25ba:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    25bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    25c5:	06                   	push   es
    25c6:	57                   	push   di
    25c7:	ff 76 f8             	push   WORD PTR [bp-0x8]
    25ca:	e8 48 e1             	call   0x715
    25cd:	88 46 f7             	mov    BYTE PTR [bp-0x9],al
    25d0:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
    25d3:	3c 01                	cmp    al,0x1
    25d5:	72 4b                	jb     0x2622
    25d7:	3c 02                	cmp    al,0x2
    25d9:	77 47                	ja     0x2622
    25db:	8d be f4 fe          	lea    di,[bp-0x10c]
    25df:	16                   	push   ss
    25e0:	57                   	push   di
    25e1:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    25e4:	06                   	push   es
    25e5:	57                   	push   di
    25e6:	6a 01                	push   0x1
    25e8:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    25eb:	48                   	dec    ax
    25ec:	50                   	push   ax
    25ed:	9a 0b 18 0e 26       	call   0x260e:0x180b
    25f2:	8d be f4 fd          	lea    di,[bp-0x20c]
    25f6:	16                   	push   ss
    25f7:	57                   	push   di
    25f8:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    25fb:	06                   	push   es
    25fc:	57                   	push   di
    25fd:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2600:	40                   	inc    ax
    2601:	50                   	push   ax
    2602:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2605:	30 e4                	xor    ah,ah
    2607:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    260a:	50                   	push   ax
    260b:	9a 0b 18 13 26       	call   0x2613:0x180b
    2610:	9a 4c 18 20 26       	call   0x2620:0x184c
    2615:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2618:	06                   	push   es
    2619:	57                   	push   di
    261a:	68 ff 00             	push   0xff
    261d:	9a e7 17 b5 26       	call   0x26b5:0x17e7
    2622:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
    2625:	3c 04                	cmp    al,0x4
    2627:	72 07                	jb     0x2630
    2629:	3c 05                	cmp    al,0x5
    262b:	77 03                	ja     0x2630
    262d:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2630:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2633:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2636:	75 82                	jne    0x25ba
    2638:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    263b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2640:	06                   	push   es
    2641:	57                   	push   di
    2642:	6a 01                	push   0x1
    2644:	e8 f6 e1             	call   0x83d
    2647:	88 46 f6             	mov    BYTE PTR [bp-0xa],al
    264a:	f6 46 f6 01          	test   BYTE PTR [bp-0xa],0x1
    264e:	74 76                	je     0x26c6
    2650:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    2655:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2658:	26 8a 05             	mov    al,BYTE PTR es:[di]
    265b:	30 e4                	xor    ah,ah
    265d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2660:	b8 01 00             	mov    ax,0x1
    2663:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2666:	7f 2c                	jg     0x2694
    2668:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    266b:	eb 03                	jmp    0x2670
    266d:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2670:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2673:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2676:	03 f8                	add    di,ax
    2678:	26 8a 05             	mov    al,BYTE PTR es:[di]
    267b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    267e:	26 3a 85 f0 00       	cmp    al,BYTE PTR es:[di+0xf0]
    2683:	75 05                	jne    0x268a
    2685:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2688:	eb 02                	jmp    0x268c
    268a:	eb 08                	jmp    0x2694
    268c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    268f:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2692:	75 d9                	jne    0x266d
    2694:	83 7e fa 01          	cmp    WORD PTR [bp-0x6],0x1
    2698:	74 2a                	je     0x26c4
    269a:	8d be f6 fe          	lea    di,[bp-0x10a]
    269e:	16                   	push   ss
    269f:	57                   	push   di
    26a0:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    26a3:	06                   	push   es
    26a4:	57                   	push   di
    26a5:	ff 76 fa             	push   WORD PTR [bp-0x6]
    26a8:	26 8a 05             	mov    al,BYTE PTR es:[di]
    26ab:	30 e4                	xor    ah,ah
    26ad:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    26b0:	40                   	inc    ax
    26b1:	50                   	push   ax
    26b2:	9a 0b 18 c2 26       	call   0x26c2:0x180b
    26b7:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    26ba:	06                   	push   es
    26bb:	57                   	push   di
    26bc:	68 ff 00             	push   0xff
    26bf:	9a e7 17 37 29       	call   0x2937:0x17e7
    26c4:	eb 4c                	jmp    0x2712
    26c6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    26c9:	26 8a 05             	mov    al,BYTE PTR es:[di]
    26cc:	30 e4                	xor    ah,ah
    26ce:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26d1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    26d4:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    26d7:	b8 01 00             	mov    ax,0x1
    26da:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    26dd:	7f 33                	jg     0x2712
    26df:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    26e2:	eb 03                	jmp    0x26e7
    26e4:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    26e7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    26ea:	2b 46 fe             	sub    ax,WORD PTR [bp-0x2]
    26ed:	40                   	inc    ax
    26ee:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    26f1:	03 f8                	add    di,ax
    26f3:	26 8a 05             	mov    al,BYTE PTR es:[di]
    26f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26f9:	26 3a 85 f0 00       	cmp    al,BYTE PTR es:[di+0xf0]
    26fe:	75 08                	jne    0x2708
    2700:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2703:	26 fe 0d             	dec    BYTE PTR es:[di]
    2706:	eb 02                	jmp    0x270a
    2708:	eb 08                	jmp    0x2712
    270a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    270d:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2710:	75 d2                	jne    0x26e4
    2712:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2715:	26 80 bd f0 00 20    	cmp    BYTE PTR es:[di+0xf0],0x20
    271b:	74 54                	je     0x2771
    271d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2720:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2723:	30 e4                	xor    ah,ah
    2725:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2728:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    272b:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    272e:	b8 01 00             	mov    ax,0x1
    2731:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    2734:	7f 3b                	jg     0x2771
    2736:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2739:	eb 03                	jmp    0x273e
    273b:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    273e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2741:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2744:	03 f8                	add    di,ax
    2746:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2749:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    274c:	26 3a 85 f0 00       	cmp    al,BYTE PTR es:[di+0xf0]
    2751:	75 0c                	jne    0x275f
    2753:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2756:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2759:	03 f8                	add    di,ax
    275b:	26 c6 05 20          	mov    BYTE PTR es:[di],0x20
    275f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2762:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2765:	7e 02                	jle    0x2769
    2767:	eb 08                	jmp    0x2771
    2769:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    276c:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    276f:	75 ca                	jne    0x273b
    2771:	c9                   	leave
    2772:	ca 08 00             	retf   0x8
    2775:	c8 08 01 00          	enter  0x108,0x0
    2779:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    277d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2780:	26 8b 85 ec 00       	mov    ax,WORD PTR es:[di+0xec]
    2785:	26 8b 95 ee 00       	mov    dx,WORD PTR es:[di+0xee]
    278a:	3b 16 18 17          	cmp    dx,WORD PTR ds:0x1718
    278e:	75 09                	jne    0x2799
    2790:	3b 06 16 17          	cmp    ax,WORD PTR ds:0x1716
    2794:	75 03                	jne    0x2799
    2796:	e9 a7 00             	jmp    0x2840
    2799:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    279d:	8d be f8 fe          	lea    di,[bp-0x108]
    27a1:	16                   	push   ss
    27a2:	57                   	push   di
    27a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a6:	06                   	push   es
    27a7:	57                   	push   di
    27a8:	9a fe 17 e8 27       	call   0x27e8:0x17fe
    27ad:	ff 76 0a             	push   WORD PTR [bp+0xa]
    27b0:	e8 d4 e4             	call   0xc87
    27b3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    27b6:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    27ba:	7d 03                	jge    0x27bf
    27bc:	e9 81 00             	jmp    0x2840
    27bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    27c7:	06                   	push   es
    27c8:	57                   	push   di
    27c9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    27cc:	e8 46 df             	call   0x715
    27cf:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    27d2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    27d5:	26 8a 05             	mov    al,BYTE PTR es:[di]
    27d8:	88 46 fa             	mov    BYTE PTR [bp-0x6],al
    27db:	06                   	push   es
    27dc:	57                   	push   di
    27dd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    27e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e3:	06                   	push   es
    27e4:	57                   	push   di
    27e5:	9a 56 28 0d 28       	call   0x280d:0x2856
    27ea:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    27ed:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    27f1:	75 4d                	jne    0x2840
    27f3:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    27f6:	3c 04                	cmp    al,0x4
    27f8:	72 46                	jb     0x2840
    27fa:	3c 05                	cmp    al,0x5
    27fc:	77 42                	ja     0x2840
    27fe:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2801:	8a 46 fa             	mov    al,BYTE PTR [bp-0x6]
    2804:	50                   	push   ax
    2805:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2808:	06                   	push   es
    2809:	57                   	push   di
    280a:	9a 21 2e 26 28       	call   0x2826:0x2e21
    280f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2812:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    2816:	7e 28                	jle    0x2840
    2818:	8d be f8 fe          	lea    di,[bp-0x108]
    281c:	16                   	push   ss
    281d:	57                   	push   di
    281e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2821:	06                   	push   es
    2822:	57                   	push   di
    2823:	9a fe 17 3c 28       	call   0x283c:0x17fe
    2828:	ff 76 fc             	push   WORD PTR [bp-0x4]
    282b:	e8 0b e4             	call   0xc39
    282e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2831:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2834:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2837:	06                   	push   es
    2838:	57                   	push   di
    2839:	9a 12 1b 54 2b       	call   0x2b54:0x1b12
    283e:	eb 0d                	jmp    0x284d
    2840:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    2844:	75 07                	jne    0x284d
    2846:	6a 00                	push   0x0
    2848:	9a ff ff 00 00       	call   0x0:0xffff
    284d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2850:	c9                   	leave
    2851:	ca 0a 00             	retf   0xa
    2854:	01 20                	add    WORD PTR [bx+si],sp
    2856:	c8 04 02 00          	enter  0x204,0x0
    285a:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    285e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2861:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2866:	06                   	push   es
    2867:	57                   	push   di
    2868:	ff 76 0a             	push   WORD PTR [bp+0xa]
    286b:	e8 a7 de             	call   0x715
    286e:	88 86 fd fe          	mov    BYTE PTR [bp-0x103],al
    2872:	8a 86 fd fe          	mov    al,BYTE PTR [bp-0x103]
    2876:	3c 01                	cmp    al,0x1
    2878:	72 21                	jb     0x289b
    287a:	3c 02                	cmp    al,0x2
    287c:	77 1d                	ja     0x289b
    287e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2881:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2884:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2889:	03 f8                	add    di,ax
    288b:	26 8a 05             	mov    al,BYTE PTR es:[di]
    288e:	50                   	push   ax
    288f:	e8 4d e0             	call   0x8df
    2892:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2895:	26 88 05             	mov    BYTE PTR es:[di],al
    2898:	e9 d4 01             	jmp    0x2a6f
    289b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    289e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    28a3:	06                   	push   es
    28a4:	57                   	push   di
    28a5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    28a8:	e8 92 df             	call   0x83d
    28ab:	88 46 fe             	mov    BYTE PTR [bp-0x2],al
    28ae:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    28b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28b4:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    28b9:	03 f8                	add    di,ax
    28bb:	26 8a 05             	mov    al,BYTE PTR es:[di]
    28be:	3c 30                	cmp    al,0x30
    28c0:	74 04                	je     0x28c6
    28c2:	3c 39                	cmp    al,0x39
    28c4:	75 16                	jne    0x28dc
    28c6:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    28c9:	26 80 3d 30          	cmp    BYTE PTR es:[di],0x30
    28cd:	72 06                	jb     0x28d5
    28cf:	26 80 3d 39          	cmp    BYTE PTR es:[di],0x39
    28d3:	76 04                	jbe    0x28d9
    28d5:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    28d9:	e9 93 01             	jmp    0x2a6f
    28dc:	3c 23                	cmp    al,0x23
    28de:	75 2b                	jne    0x290b
    28e0:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    28e3:	26 80 3d 30          	cmp    BYTE PTR es:[di],0x30
    28e7:	72 06                	jb     0x28ef
    28e9:	26 80 3d 39          	cmp    BYTE PTR es:[di],0x39
    28ed:	76 19                	jbe    0x2908
    28ef:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    28f2:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    28f6:	74 10                	je     0x2908
    28f8:	26 80 3d 2b          	cmp    BYTE PTR es:[di],0x2b
    28fc:	74 0a                	je     0x2908
    28fe:	26 80 3d 2d          	cmp    BYTE PTR es:[di],0x2d
    2902:	74 04                	je     0x2908
    2904:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2908:	e9 64 01             	jmp    0x2a6f
    290b:	3c 43                	cmp    al,0x43
    290d:	74 07                	je     0x2916
    290f:	3c 63                	cmp    al,0x63
    2911:	74 03                	je     0x2916
    2913:	e9 86 00             	jmp    0x299c
    2916:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2919:	26 8a 05             	mov    al,BYTE PTR es:[di]
    291c:	50                   	push   ax
    291d:	9a d1 29 00 00       	call   0x0:0x29d1
    2922:	09 c0                	or     ax,ax
    2924:	74 73                	je     0x2999
    2926:	bf 54 28             	mov    di,0x2854
    2929:	0e                   	push   cs
    292a:	57                   	push   di
    292b:	8d be fe fe          	lea    di,[bp-0x102]
    292f:	16                   	push   ss
    2930:	57                   	push   di
    2931:	68 ff 00             	push   0xff
    2934:	9a e7 17 66 29       	call   0x2966:0x17e7
    2939:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    293c:	26 8a 05             	mov    al,BYTE PTR es:[di]
    293f:	88 86 ff fe          	mov    BYTE PTR [bp-0x101],al
    2943:	f6 46 fe 02          	test   BYTE PTR [bp-0x2],0x2
    2947:	74 21                	je     0x296a
    2949:	8d be fc fd          	lea    di,[bp-0x204]
    294d:	16                   	push   ss
    294e:	57                   	push   di
    294f:	8d be fe fe          	lea    di,[bp-0x102]
    2953:	16                   	push   ss
    2954:	57                   	push   di
    2955:	9a 81 07 7f 29       	call   0x297f:0x781
    295a:	8d be fe fe          	lea    di,[bp-0x102]
    295e:	16                   	push   ss
    295f:	57                   	push   di
    2960:	68 ff 00             	push   0xff
    2963:	9a e7 17 8d 29       	call   0x298d:0x17e7
    2968:	eb 25                	jmp    0x298f
    296a:	f6 46 fe 04          	test   BYTE PTR [bp-0x2],0x4
    296e:	74 1f                	je     0x298f
    2970:	8d be fc fd          	lea    di,[bp-0x204]
    2974:	16                   	push   ss
    2975:	57                   	push   di
    2976:	8d be fe fe          	lea    di,[bp-0x102]
    297a:	16                   	push   ss
    297b:	57                   	push   di
    297c:	9a b7 07 2e 2a       	call   0x2a2e:0x7b7
    2981:	8d be fe fe          	lea    di,[bp-0x102]
    2985:	16                   	push   ss
    2986:	57                   	push   di
    2987:	68 ff 00             	push   0xff
    298a:	9a e7 17 c0 29       	call   0x29c0:0x17e7
    298f:	8a 86 ff fe          	mov    al,BYTE PTR [bp-0x101]
    2993:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2996:	26 88 05             	mov    BYTE PTR es:[di],al
    2999:	e9 d3 00             	jmp    0x2a6f
    299c:	3c 4c                	cmp    al,0x4c
    299e:	74 0f                	je     0x29af
    29a0:	3c 6c                	cmp    al,0x6c
    29a2:	74 0b                	je     0x29af
    29a4:	3c 41                	cmp    al,0x41
    29a6:	74 07                	je     0x29af
    29a8:	3c 61                	cmp    al,0x61
    29aa:	74 03                	je     0x29af
    29ac:	e9 c0 00             	jmp    0x2a6f
    29af:	bf 54 28             	mov    di,0x2854
    29b2:	0e                   	push   cs
    29b3:	57                   	push   di
    29b4:	8d be fe fe          	lea    di,[bp-0x102]
    29b8:	16                   	push   ss
    29b9:	57                   	push   di
    29ba:	68 ff 00             	push   0xff
    29bd:	9a e7 17 3c 2a       	call   0x2a3c:0x17e7
    29c2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    29c5:	26 8a 05             	mov    al,BYTE PTR es:[di]
    29c8:	88 86 ff fe          	mov    BYTE PTR [bp-0x101],al
    29cc:	26 8a 05             	mov    al,BYTE PTR es:[di]
    29cf:	50                   	push   ax
    29d0:	9a ff ff 00 00       	call   0x0:0xffff
    29d5:	09 c0                	or     ax,ax
    29d7:	75 40                	jne    0x2a19
    29d9:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    29dd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    29e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29e3:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    29e8:	03 f8                	add    di,ax
    29ea:	26 80 3d 41          	cmp    BYTE PTR es:[di],0x41
    29ee:	74 13                	je     0x2a03
    29f0:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    29f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29f6:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    29fb:	03 f8                	add    di,ax
    29fd:	26 80 3d 61          	cmp    BYTE PTR es:[di],0x61
    2a01:	75 14                	jne    0x2a17
    2a03:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2a06:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2a09:	50                   	push   ax
    2a0a:	9a ff ff 00 00       	call   0x0:0xffff
    2a0f:	09 c0                	or     ax,ax
    2a11:	74 04                	je     0x2a17
    2a13:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    2a17:	eb 4c                	jmp    0x2a65
    2a19:	f6 46 fe 02          	test   BYTE PTR [bp-0x2],0x2
    2a1d:	74 21                	je     0x2a40
    2a1f:	8d be fc fd          	lea    di,[bp-0x204]
    2a23:	16                   	push   ss
    2a24:	57                   	push   di
    2a25:	8d be fe fe          	lea    di,[bp-0x102]
    2a29:	16                   	push   ss
    2a2a:	57                   	push   di
    2a2b:	9a 81 07 55 2a       	call   0x2a55:0x781
    2a30:	8d be fe fe          	lea    di,[bp-0x102]
    2a34:	16                   	push   ss
    2a35:	57                   	push   di
    2a36:	68 ff 00             	push   0xff
    2a39:	9a e7 17 63 2a       	call   0x2a63:0x17e7
    2a3e:	eb 25                	jmp    0x2a65
    2a40:	f6 46 fe 04          	test   BYTE PTR [bp-0x2],0x4
    2a44:	74 1f                	je     0x2a65
    2a46:	8d be fc fd          	lea    di,[bp-0x204]
    2a4a:	16                   	push   ss
    2a4b:	57                   	push   di
    2a4c:	8d be fe fe          	lea    di,[bp-0x102]
    2a50:	16                   	push   ss
    2a51:	57                   	push   di
    2a52:	9a b7 07 ff ff       	call   0xffff:0x7b7
    2a57:	8d be fe fe          	lea    di,[bp-0x102]
    2a5b:	16                   	push   ss
    2a5c:	57                   	push   di
    2a5d:	68 ff 00             	push   0xff
    2a60:	9a e7 17 fe 2b       	call   0x2bfe:0x17e7
    2a65:	8a 86 ff fe          	mov    al,BYTE PTR [bp-0x101]
    2a69:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2a6c:	26 88 05             	mov    BYTE PTR es:[di],al
    2a6f:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2a72:	c9                   	leave
    2a73:	ca 0a 00             	retf   0xa
    2a76:	c8 0a 00 00          	enter  0xa,0x0
    2a7a:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    2a7e:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    2a83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a86:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2a8b:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2a8e:	30 e4                	xor    ah,ah
    2a90:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2a93:	b8 01 00             	mov    ax,0x1
    2a96:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2a99:	7e 03                	jle    0x2a9e
    2a9b:	e9 89 00             	jmp    0x2b27
    2a9e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2aa1:	eb 03                	jmp    0x2aa6
    2aa3:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2aa6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2aae:	06                   	push   es
    2aaf:	57                   	push   di
    2ab0:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2ab3:	e8 5f dc             	call   0x715
    2ab6:	88 46 f9             	mov    BYTE PTR [bp-0x7],al
    2ab9:	8a 46 f9             	mov    al,BYTE PTR [bp-0x7]
    2abc:	3c 01                	cmp    al,0x1
    2abe:	72 0d                	jb     0x2acd
    2ac0:	3c 02                	cmp    al,0x2
    2ac2:	76 04                	jbe    0x2ac8
    2ac4:	3c 05                	cmp    al,0x5
    2ac6:	75 05                	jne    0x2acd
    2ac8:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2acb:	eb 4f                	jmp    0x2b1c
    2acd:	80 7e f9 04          	cmp    BYTE PTR [bp-0x7],0x4
    2ad1:	75 49                	jne    0x2b1c
    2ad3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2ad6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2ad9:	03 f8                	add    di,ax
    2adb:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2ade:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ae1:	26 3a 85 f0 00       	cmp    al,BYTE PTR es:[di+0xf0]
    2ae6:	74 21                	je     0x2b09
    2ae8:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2aeb:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2aee:	03 f8                	add    di,ax
    2af0:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    2af4:	75 23                	jne    0x2b19
    2af6:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2af9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2afc:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b01:	03 f8                	add    di,ax
    2b03:	26 80 3d 43          	cmp    BYTE PTR es:[di],0x43
    2b07:	74 10                	je     0x2b19
    2b09:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2b0d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2b10:	48                   	dec    ax
    2b11:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b14:	26 89 05             	mov    WORD PTR es:[di],ax
    2b17:	eb 0e                	jmp    0x2b27
    2b19:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2b1c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2b1f:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    2b22:	74 03                	je     0x2b27
    2b24:	e9 7c ff             	jmp    0x2aa3
    2b27:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2b2a:	c9                   	leave
    2b2b:	ca 0c 00             	retf   0xc
    2b2e:	c8 0c 01 00          	enter  0x10c,0x0
    2b32:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    2b36:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2b39:	40                   	inc    ax
    2b3a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2b3d:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2b40:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    2b43:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2b46:	8d be f4 fe          	lea    di,[bp-0x10c]
    2b4a:	16                   	push   ss
    2b4b:	57                   	push   di
    2b4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b4f:	06                   	push   es
    2b50:	57                   	push   di
    2b51:	9a fe 17 0e 2c       	call   0x2c0e:0x17fe
    2b56:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b59:	e8 2b e1             	call   0xc87
    2b5c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    2b5f:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    2b63:	7d 02                	jge    0x2b67
    2b65:	eb 76                	jmp    0x2bdd
    2b67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b6a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b6f:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2b72:	30 e4                	xor    ah,ah
    2b74:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    2b77:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    2b7a:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    2b7d:	7f 5e                	jg     0x2bdd
    2b7f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2b82:	eb 03                	jmp    0x2b87
    2b84:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    2b87:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b8a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2b8f:	06                   	push   es
    2b90:	57                   	push   di
    2b91:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2b94:	e8 7e db             	call   0x715
    2b97:	88 46 f5             	mov    BYTE PTR [bp-0xb],al
    2b9a:	8a 46 f5             	mov    al,BYTE PTR [bp-0xb]
    2b9d:	3c 01                	cmp    al,0x1
    2b9f:	72 09                	jb     0x2baa
    2ba1:	3c 02                	cmp    al,0x2
    2ba3:	77 05                	ja     0x2baa
    2ba5:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2ba8:	eb 21                	jmp    0x2bcb
    2baa:	8a 46 f5             	mov    al,BYTE PTR [bp-0xb]
    2bad:	3c 04                	cmp    al,0x4
    2baf:	72 1a                	jb     0x2bcb
    2bb1:	3c 05                	cmp    al,0x5
    2bb3:	77 16                	ja     0x2bcb
    2bb5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bb8:	26 8a 95 f0 00       	mov    dl,BYTE PTR es:[di+0xf0]
    2bbd:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2bc0:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    2bc3:	03 f8                	add    di,ax
    2bc5:	26 88 15             	mov    BYTE PTR es:[di],dl
    2bc8:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2bcb:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2bce:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2bd1:	7e 02                	jle    0x2bd5
    2bd3:	eb 08                	jmp    0x2bdd
    2bd5:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2bd8:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    2bdb:	75 a7                	jne    0x2b84
    2bdd:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2be0:	c9                   	leave
    2be1:	ca 0e 00             	retf   0xe
    2be4:	c8 0e 04 00          	enter  0x40e,0x0
    2be8:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
    2bed:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2bf0:	06                   	push   es
    2bf1:	57                   	push   di
    2bf2:	8d be f6 fe          	lea    di,[bp-0x10a]
    2bf6:	16                   	push   ss
    2bf7:	57                   	push   di
    2bf8:	68 ff 00             	push   0xff
    2bfb:	9a e7 17 df 2c       	call   0x2cdf:0x17e7
    2c00:	8d be f4 fd          	lea    di,[bp-0x20c]
    2c04:	16                   	push   ss
    2c05:	57                   	push   di
    2c06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c09:	06                   	push   es
    2c0a:	57                   	push   di
    2c0b:	9a fe 17 92 2c       	call   0x2c92:0x17fe
    2c10:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2c13:	e8 71 e0             	call   0xc87
    2c16:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2c19:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    2c1d:	7d 03                	jge    0x2c22
    2c1f:	e9 f8 01             	jmp    0x2e1a
    2c22:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c25:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2c2a:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2c2d:	30 e4                	xor    ah,ah
    2c2f:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    2c33:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2c36:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    2c3a:	7e 03                	jle    0x2c3f
    2c3c:	e9 13 01             	jmp    0x2d52
    2c3f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2c42:	eb 03                	jmp    0x2c47
    2c44:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    2c47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c4a:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2c4f:	06                   	push   es
    2c50:	57                   	push   di
    2c51:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c54:	e8 be da             	call   0x715
    2c57:	88 46 f7             	mov    BYTE PTR [bp-0x9],al
    2c5a:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
    2c5d:	3c 01                	cmp    al,0x1
    2c5f:	73 03                	jae    0x2c64
    2c61:	e9 c3 00             	jmp    0x2d27
    2c64:	3c 02                	cmp    al,0x2
    2c66:	76 0e                	jbe    0x2c76
    2c68:	3c 04                	cmp    al,0x4
    2c6a:	73 03                	jae    0x2c6f
    2c6c:	e9 b8 00             	jmp    0x2d27
    2c6f:	3c 05                	cmp    al,0x5
    2c71:	76 03                	jbe    0x2c76
    2c73:	e9 b1 00             	jmp    0x2d27
    2c76:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
    2c79:	8a 83 f6 fe          	mov    al,BYTE PTR [bp+di-0x10a]
    2c7d:	88 86 f5 fe          	mov    BYTE PTR [bp-0x10b],al
    2c81:	8d be f5 fe          	lea    di,[bp-0x10b]
    2c85:	16                   	push   ss
    2c86:	57                   	push   di
    2c87:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c8d:	06                   	push   es
    2c8e:	57                   	push   di
    2c8f:	9a 56 28 ff ff       	call   0xffff:0x2856
    2c94:	08 c0                	or     al,al
    2c96:	75 0c                	jne    0x2ca4
    2c98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c9b:	26 8a 85 f0 00       	mov    al,BYTE PTR es:[di+0xf0]
    2ca0:	88 86 f5 fe          	mov    BYTE PTR [bp-0x10b],al
    2ca4:	8a 46 f7             	mov    al,BYTE PTR [bp-0x9]
    2ca7:	3c 01                	cmp    al,0x1
    2ca9:	72 11                	jb     0x2cbc
    2cab:	3c 02                	cmp    al,0x2
    2cad:	77 0d                	ja     0x2cbc
    2caf:	8a 86 f5 fe          	mov    al,BYTE PTR [bp-0x10b]
    2cb3:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
    2cb6:	3a 83 f6 fe          	cmp    al,BYTE PTR [bp+di-0x10a]
    2cba:	75 0d                	jne    0x2cc9
    2cbc:	8a 86 f5 fe          	mov    al,BYTE PTR [bp-0x10b]
    2cc0:	8b 7e fc             	mov    di,WORD PTR [bp-0x4]
    2cc3:	88 83 f6 fe          	mov    BYTE PTR [bp+di-0x10a],al
    2cc7:	eb 5b                	jmp    0x2d24
    2cc9:	8d be f2 fd          	lea    di,[bp-0x20e]
    2ccd:	16                   	push   ss
    2cce:	57                   	push   di
    2ccf:	8d be f6 fe          	lea    di,[bp-0x10a]
    2cd3:	16                   	push   ss
    2cd4:	57                   	push   di
    2cd5:	6a 01                	push   0x1
    2cd7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2cda:	48                   	dec    ax
    2cdb:	50                   	push   ax
    2cdc:	9a 0b 18 ef 2c       	call   0x2cef:0x180b
    2ce1:	8d be f2 fc          	lea    di,[bp-0x30e]
    2ce5:	16                   	push   ss
    2ce6:	57                   	push   di
    2ce7:	8a 86 f5 fe          	mov    al,BYTE PTR [bp-0x10b]
    2ceb:	50                   	push   ax
    2cec:	9a e9 18 f4 2c       	call   0x2cf4:0x18e9
    2cf1:	9a 4c 18 0f 2d       	call   0x2d0f:0x184c
    2cf6:	8d be f2 fb          	lea    di,[bp-0x40e]
    2cfa:	16                   	push   ss
    2cfb:	57                   	push   di
    2cfc:	8d be f6 fe          	lea    di,[bp-0x10a]
    2d00:	16                   	push   ss
    2d01:	57                   	push   di
    2d02:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2d05:	8a 86 f6 fe          	mov    al,BYTE PTR [bp-0x10a]
    2d09:	30 e4                	xor    ah,ah
    2d0b:	50                   	push   ax
    2d0c:	9a 0b 18 14 2d       	call   0x2d14:0x180b
    2d11:	9a 4c 18 22 2d       	call   0x2d22:0x184c
    2d16:	8d be f6 fe          	lea    di,[bp-0x10a]
    2d1a:	16                   	push   ss
    2d1b:	57                   	push   di
    2d1c:	68 ff 00             	push   0xff
    2d1f:	9a e7 17 78 2d       	call   0x2d78:0x17e7
    2d24:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    2d27:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2d2a:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    2d2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d30:	26 3b 85 f1 00       	cmp    ax,WORD PTR es:[di+0xf1]
    2d35:	7e 02                	jle    0x2d39
    2d37:	eb 19                	jmp    0x2d52
    2d39:	8a 86 f6 fe          	mov    al,BYTE PTR [bp-0x10a]
    2d3d:	30 e4                	xor    ah,ah
    2d3f:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2d42:	7d 02                	jge    0x2d46
    2d44:	eb 0c                	jmp    0x2d52
    2d46:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2d49:	3b 86 f2 fe          	cmp    ax,WORD PTR [bp-0x10e]
    2d4d:	74 03                	je     0x2d52
    2d4f:	e9 f2 fe             	jmp    0x2c44
    2d52:	8a 86 f6 fe          	mov    al,BYTE PTR [bp-0x10a]
    2d56:	30 e4                	xor    ah,ah
    2d58:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    2d5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d5e:	26 3b 85 f1 00       	cmp    ax,WORD PTR es:[di+0xf1]
    2d63:	7d 65                	jge    0x2dca
    2d65:	8d be f4 fd          	lea    di,[bp-0x20c]
    2d69:	16                   	push   ss
    2d6a:	57                   	push   di
    2d6b:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2d6e:	06                   	push   es
    2d6f:	57                   	push   di
    2d70:	6a 01                	push   0x1
    2d72:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2d75:	9a 0b 18 83 2d       	call   0x2d83:0x180b
    2d7a:	8d be f6 fe          	lea    di,[bp-0x10a]
    2d7e:	16                   	push   ss
    2d7f:	57                   	push   di
    2d80:	9a 4c 18 b4 2d       	call   0x2db4:0x184c
    2d85:	8d be f4 fc          	lea    di,[bp-0x30c]
    2d89:	16                   	push   ss
    2d8a:	57                   	push   di
    2d8b:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2d8e:	06                   	push   es
    2d8f:	57                   	push   di
    2d90:	8a 86 f6 fe          	mov    al,BYTE PTR [bp-0x10a]
    2d94:	30 e4                	xor    ah,ah
    2d96:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    2d99:	40                   	inc    ax
    2d9a:	50                   	push   ax
    2d9b:	8a 86 f6 fe          	mov    al,BYTE PTR [bp-0x10a]
    2d9f:	30 e4                	xor    ah,ah
    2da1:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    2da4:	8b d0                	mov    dx,ax
    2da6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2da9:	26 8b 85 f1 00       	mov    ax,WORD PTR es:[di+0xf1]
    2dae:	2b c2                	sub    ax,dx
    2db0:	50                   	push   ax
    2db1:	9a 0b 18 b9 2d       	call   0x2db9:0x180b
    2db6:	9a 4c 18 c6 2d       	call   0x2dc6:0x184c
    2dbb:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2dbe:	06                   	push   es
    2dbf:	57                   	push   di
    2dc0:	ff 76 10             	push   WORD PTR [bp+0x10]
    2dc3:	9a e7 17 dd 2d       	call   0x2ddd:0x17e7
    2dc8:	eb 46                	jmp    0x2e10
    2dca:	8d be f4 fd          	lea    di,[bp-0x20c]
    2dce:	16                   	push   ss
    2dcf:	57                   	push   di
    2dd0:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2dd3:	06                   	push   es
    2dd4:	57                   	push   di
    2dd5:	6a 01                	push   0x1
    2dd7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2dda:	9a 0b 18 fc 2d       	call   0x2dfc:0x180b
    2ddf:	8d be f4 fc          	lea    di,[bp-0x30c]
    2de3:	16                   	push   ss
    2de4:	57                   	push   di
    2de5:	8d be f6 fe          	lea    di,[bp-0x10a]
    2de9:	16                   	push   ss
    2dea:	57                   	push   di
    2deb:	6a 01                	push   0x1
    2ded:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2df0:	26 8b 85 f1 00       	mov    ax,WORD PTR es:[di+0xf1]
    2df5:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
    2df8:	50                   	push   ax
    2df9:	9a 0b 18 01 2e       	call   0x2e01:0x180b
    2dfe:	9a 4c 18 0e 2e       	call   0x2e0e:0x184c
    2e03:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2e06:	06                   	push   es
    2e07:	57                   	push   di
    2e08:	ff 76 10             	push   WORD PTR [bp+0x10]
    2e0b:	9a e7 17 ff ff       	call   0xffff:0x17e7
    2e10:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2e13:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    2e16:	48                   	dec    ax
    2e17:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e1a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e1d:	c9                   	leave
    2e1e:	ca 10 00             	retf   0x10
    2e21:	c8 04 00 00          	enter  0x4,0x0
    2e25:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    2e2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e2d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2e32:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2e35:	30 e4                	xor    ah,ah
    2e37:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    2e3a:	7e 56                	jle    0x2e92
    2e3c:	ff 46 0c             	inc    WORD PTR [bp+0xc]
    2e3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e42:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2e47:	06                   	push   es
    2e48:	57                   	push   di
    2e49:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2e4c:	e8 c6 d8             	call   0x715
    2e4f:	88 46 fd             	mov    BYTE PTR [bp-0x3],al
    2e52:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    2e55:	3c 01                	cmp    al,0x1
    2e57:	72 37                	jb     0x2e90
    2e59:	3c 02                	cmp    al,0x2
    2e5b:	77 33                	ja     0x2e90
    2e5d:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2e60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e63:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2e68:	03 f8                	add    di,ax
    2e6a:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2e6d:	88 46 fc             	mov    BYTE PTR [bp-0x4],al
    2e70:	80 7e fd 02          	cmp    BYTE PTR [bp-0x3],0x2
    2e74:	75 0a                	jne    0x2e80
    2e76:	8a 46 fc             	mov    al,BYTE PTR [bp-0x4]
    2e79:	50                   	push   ax
    2e7a:	e8 62 da             	call   0x8df
    2e7d:	88 46 fc             	mov    BYTE PTR [bp-0x4],al
    2e80:	8a 46 fc             	mov    al,BYTE PTR [bp-0x4]
    2e83:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    2e86:	75 06                	jne    0x2e8e
    2e88:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2e8b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2e8e:	eb 02                	jmp    0x2e92
    2e90:	eb 98                	jmp    0x2e2a
    2e92:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2e95:	c9                   	leave
    2e96:	ca                   	.byte 0xca
    2e97:	08                   	.byte 0x8
