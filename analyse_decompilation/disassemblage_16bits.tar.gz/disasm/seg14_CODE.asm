; ================================================================
; seg14_CODE  (17966 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	0e                   	push   cs
       1:	00 37                	add    BYTE PTR [bx],dh
       3:	0f 46 02             	cmovbe ax,WORD PTR [bp+si]
       6:	a8 00                	test   al,0x0
       8:	00 00                	add    BYTE PTR [bx+si],al
       a:	9e                   	sahf
       b:	00 26 06 fb          	add    BYTE PTR ds:0xfb06,ah
       f:	04 48                	add    al,0x48
      11:	0f 39                	(bad)
      13:	3f                   	aas
      14:	28 00                	sub    BYTE PTR [bx+si],al
      16:	9a 1f 5b 0f cb       	call   0xcb0f:0x5b1f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	ad                   	lods   ax,WORD PTR ds:[si]
      1f:	27                   	daa
      20:	9c                   	pushf
      21:	00 cd                	add    ch,cl
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 f7                	add    bh,dh
      27:	2a 88 00 fa          	sub    cl,BYTE PTR [bx+si-0x600]
      2b:	10 7e 10             	adc    BYTE PTR [bp+0x10],bh
      2e:	d6                   	(bad)
      2f:	14 60                	adc    al,0x60
      31:	00 f4                	add    ah,dh
      33:	4f                   	dec    di
      34:	4c                   	dec    sp
      35:	00 9a 28 94          	add    BYTE PTR [bp+si-0x6bd8],bl
      39:	00 85 29 40          	add    BYTE PTR [di+0x4029],al
      3d:	00 57 4d             	add    BYTE PTR [bx+0x4d],dl
      40:	44                   	inc    sp
      41:	00 91 2f 64          	add    BYTE PTR [bx+di+0x642f],dl
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	68 00 21             	push   0x2100
      4b:	50                   	push   ax
      4c:	24 00                	and    al,0x0
      4e:	53                   	push   bx
      4f:	25 20 00             	and    ax,0x20
      52:	d9 62 5c             	fldenv [bp+si+0x5c]
      55:	00 55 2e             	add    BYTE PTR [di+0x2e],dl
      58:	38 00                	cmp    BYTE PTR [bx+si],al
      5a:	8f                   	(bad)
      5b:	60                   	pusha
      5c:	98                   	cbw
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c cf                	sbb    al,0xcf
      61:	0f e2 2f             	psrad  mm5,QWORD PTR [bx]
      64:	50                   	push   ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	70 00                	jo     0x6e
      6e:	62 5c 74             	bound  bx,DWORD PTR [si+0x74]
      71:	00 3a                	add    BYTE PTR [bp+si],bh
      73:	61                   	popa
      74:	30 00                	xor    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	8c 00                	mov    WORD PTR [bx+si],es
      7a:	58                   	pop    ax
      7b:	3a 80 00 ec          	cmp    al,BYTE PTR [bx+si-0x1400]
      7f:	3d 84 00             	cmp    ax,0x84
      82:	e4 3c                	in     al,0x3c
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 58                	ds pop ax
      89:	00 77 3e             	add    BYTE PTR [bx+0x3e],dh
      8c:	54                   	push   sp
      8d:	00 e6                	add    dh,ah
      8f:	31 7c 00             	xor    WORD PTR [si+0x0],di
      92:	3c 47                	cmp    al,0x47
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	48                   	dec    ax
      99:	00 e9                	add    cl,ch
      9b:	5c                   	pop    sp
      9c:	10 00                	adc    BYTE PTR [bx+si],al
      9e:	09 54 46             	or     WORD PTR [si+0x46],dx
      a1:	6f                   	outs   dx,WORD PTR ds:[si]
      a2:	72 6d                	jb     0x111
      a4:	53                   	push   bx
      a5:	50                   	push   ax
      a6:	55                   	push   bp
      a7:	42                   	inc    dx
      a8:	17                   	pop    ss
      a9:	00 8e 0f bb          	add    BYTE PTR [bp-0x44f1],cl
      ad:	00 0a                	add    BYTE PTR [bp+si],cl
      af:	46                   	inc    si
      b0:	6f                   	outs   dx,WORD PTR ds:[si]
      b1:	72 6d                	jb     0x120
      b3:	43                   	inc    bx
      b4:	72 65                	jb     0x11b
      b6:	61                   	popa
      b7:	74 65                	je     0x11e
      b9:	8b 12                	mov    dx,WORD PTR [bp+si]
      bb:	c9                   	leave
      bc:	00 09                	add    BYTE PTR [bx+di],cl
      be:	46                   	inc    si
      bf:	6f                   	outs   dx,WORD PTR ds:[si]
      c0:	72 6d                	jb     0x12f
      c2:	43                   	inc    bx
      c3:	6c                   	ins    BYTE PTR es:[di],dx
      c4:	6f                   	outs   dx,WORD PTR ds:[si]
      c5:	73 65                	jae    0x12c
      c7:	42                   	inc    dx
      c8:	1d dc 00             	sbb    ax,0xdc
      cb:	0e                   	push   cs
      cc:	49                   	dec    cx
      cd:	6d                   	ins    WORD PTR es:[di],dx
      ce:	70 72                	jo     0x142
      d0:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
      d5:	43                   	inc    bx
      d6:	6c                   	ins    BYTE PTR es:[di],dx
      d7:	69 63 6b ca 1d       	imul   sp,WORD PTR [bp+di+0x6b],0x1dca
      dc:	ee                   	out    dx,al
      dd:	00 0d                	add    BYTE PTR [di],cl
      df:	51                   	push   cx
      e0:	75 69                	jne    0x14b
      e2:	74 74                	je     0x158
      e4:	65 72 31             	gs jb  0x118
      e7:	43                   	inc    bx
      e8:	6c                   	ins    BYTE PTR es:[di],dx
      e9:	69 63 6b d7 2d       	imul   sp,WORD PTR [bp+di+0x6b],0x2dd7
      ee:	ff 00                	inc    WORD PTR [bx+si]
      f0:	0c 43                	or     al,0x43
      f2:	6f                   	outs   dx,WORD PTR ds:[si]
      f3:	70 69                	jo     0x15e
      f5:	65 72 31             	gs jb  0x129
      f8:	43                   	inc    bx
      f9:	6c                   	ins    BYTE PTR es:[di],dx
      fa:	69 63 6b e2 1d       	imul   sp,WORD PTR [bp+di+0x6b],0x1de2
      ff:	14 01                	adc    al,0x1
     101:	10 50 6c             	adc    BYTE PTR [bx+si+0x6c],dl
     104:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     10a:	61                   	popa
     10b:	6e                   	outs   dx,BYTE PTR ds:[si]
     10c:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     10f:	69 63 6b 3b 1f       	imul   sp,WORD PTR [bp+di+0x6b],0x1f3b
     114:	26 01 0d             	add    WORD PTR es:[di],cx
     117:	50                   	push   ax
     118:	65 72 69             	gs jb  0x184
     11b:	6f                   	outs   dx,WORD PTR ds:[si]
     11c:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     121:	69 63 6b 45 28       	imul   sp,WORD PTR [bp+di+0x6b],0x2845
     126:	36 01 0b             	add    WORD PTR ss:[bp+di],cx
     129:	46                   	inc    si
     12a:	69 63 68 65 31       	imul   sp,WORD PTR [bp+di+0x68],0x3165
     12f:	43                   	inc    bx
     130:	6c                   	ins    BYTE PTR es:[di],dx
     131:	69 63 6b 8f 28       	imul   sp,WORD PTR [bp+di+0x6b],0x288f
     136:	4b                   	dec    bx
     137:	01 10                	add    WORD PTR [bx+si],dx
     139:	52                   	push   dx
     13a:	65 63 68 65          	arpl   WORD PTR gs:[bx+si+0x65],bp
     13e:	72 63                	jb     0x1a3
     140:	68 65 72             	push   0x7265
     143:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     146:	69 63 6b b0 28       	imul   sp,WORD PTR [bp+di+0x6b],0x28b0
     14b:	63 01                	arpl   WORD PTR [bx+di],ax
     14d:	13 55 74             	adc    dx,WORD PTR [di+0x74]
     150:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     155:	72 6c                	jb     0x1c3
     157:	61                   	popa
     158:	69 64 65 31 43       	imul   sp,WORD PTR [si+0x65],0x4331
     15d:	6c                   	ins    BYTE PTR es:[di],dx
     15e:	69 63 6b cf 28       	imul   sp,WORD PTR [bp+di+0x6b],0x28cf
     163:	75 01                	jne    0x166
     165:	0d 41 70             	or     ax,0x7041
     168:	72 6f                	jb     0x1d9
     16a:	70 6f                	jo     0x1db
     16c:	73 31                	jae    0x19f
     16e:	43                   	inc    bx
     16f:	6c                   	ins    BYTE PTR es:[di],dx
     170:	69 63 6b 70 28       	imul   sp,WORD PTR [bp+di+0x6b],0x2870
     175:	85 01                	test   WORD PTR [bx+di],ax
     177:	0b 49 6e             	or     cx,WORD PTR [bx+di+0x6e]
     17a:	64 65 78 31          	fs gs js 0x1af
     17e:	43                   	inc    bx
     17f:	6c                   	ins    BYTE PTR es:[di],dx
     180:	69 63 6b 64 22       	imul   sp,WORD PTR [bp+di+0x6b],0x2264
     185:	95                   	xchg   bp,ax
     186:	01 0b                	add    WORD PTR [bp+di],cx
     188:	44                   	inc    sp
     189:	42                   	inc    dx
     18a:	45                   	inc    bp
     18b:	64 69 74 31 45 78    	imul   si,WORD PTR fs:[si+0x31],0x7845
     191:	69 74 14 23 a8       	imul   si,WORD PTR [si+0x14],0xa823
     196:	01 0e 44 42          	add    WORD PTR ds:0x4244,cx
     19a:	45                   	inc    bp
     19b:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     1a1:	79 44                	jns    0x1e7
     1a3:	6f                   	outs   dx,WORD PTR ds:[si]
     1a4:	77 6e                	ja     0x214
     1a6:	b1 22                	mov    cl,0x22
     1a8:	b9 01 0c             	mov    cx,0xc01
     1ab:	44                   	inc    sp
     1ac:	42                   	inc    dx
     1ad:	45                   	inc    bp
     1ae:	64 69 74 31 4b 65    	imul   si,WORD PTR fs:[si+0x31],0x654b
     1b4:	79 55                	jns    0x20b
     1b6:	70 98                	jo     0x150
     1b8:	20 c9                	and    cl,cl
     1ba:	01 0b                	add    WORD PTR [bp+di],cx
     1bc:	46                   	inc    si
     1bd:	6f                   	outs   dx,WORD PTR ds:[si]
     1be:	72 6d                	jb     0x22d
     1c0:	4b                   	dec    bx
     1c1:	65 79 44             	gs jns 0x208
     1c4:	6f                   	outs   dx,WORD PTR ds:[si]
     1c5:	77 6e                	ja     0x235
     1c7:	7b 45                	jnp    0x20e
     1c9:	e0 01                	loopne 0x1cc
     1cb:	12 54 61             	adc    dl,BYTE PTR [si+0x61]
     1ce:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1d1:	44                   	inc    sp
     1d2:	50                   	push   ax
     1d3:	31 43 61             	xor    WORD PTR [bp+di+0x61],ax
     1d6:	6c                   	ins    BYTE PTR es:[di],dx
     1d7:	63 46 69             	arpl   WORD PTR [bp+0x69],ax
     1da:	65 6c                	gs ins BYTE PTR es:[di],dx
     1dc:	64 73 8e             	fs jae 0x16d
     1df:	27                   	daa
     1e0:	f5                   	cmc
     1e1:	01 10                	add    WORD PTR [bx+si],dx
     1e3:	44                   	inc    sp
     1e4:	42                   	inc    dx
     1e5:	45                   	inc    bp
     1e6:	64 69 74 31 4d 6f    	imul   si,WORD PTR fs:[si+0x31],0x6f4d
     1ec:	75 73                	jne    0x261
     1ee:	65 44                	gs inc sp
     1f0:	6f                   	outs   dx,WORD PTR ds:[si]
     1f1:	77 6e                	ja     0x261
     1f3:	70 12                	jo     0x207
     1f5:	02 02                	add    al,BYTE PTR [bp+si]
     1f7:	08 46 6f             	or     BYTE PTR [bp+0x6f],al
     1fa:	72 6d                	jb     0x269
     1fc:	53                   	push   bx
     1fd:	68 6f 77             	push   0x776f
     200:	ec                   	in     al,dx
     201:	28 1d                	sub    BYTE PTR [di],bl
     203:	02 16 49 6d          	add    dl,BYTE PTR ds:0x6d49
     207:	70 72                	jo     0x27b
     209:	65 73 73             	gs jae 0x27f
     20c:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     211:	70 69                	jo     0x27c
     213:	64 65 31 43 6c       	fs xor WORD PTR gs:[bp+di+0x6c],ax
     218:	69 63 6b 1e 1e       	imul   sp,WORD PTR [bp+di+0x6b],0x1e1e
     21d:	2c 02                	sub    al,0x2
     21f:	0a 4e 31             	or     cl,BYTE PTR [bp+0x31]
     222:	30 30                	xor    BYTE PTR [bx+si],dh
     224:	31 43 6c             	xor    WORD PTR [bp+di+0x6c],ax
     227:	69 63 6b aa 12       	imul   sp,WORD PTR [bp+di+0x6b],0x12aa
     22c:	3b 02                	cmp    ax,WORD PTR [bp+si]
     22e:	0a 46 6f             	or     al,BYTE PTR [bp+0x6f]
     231:	72 6d                	jb     0x2a0
     233:	52                   	push   dx
     234:	65 73 69             	gs jae 0x2a0
     237:	7a 65                	jp     0x29e
     239:	78 1f                	js     0x25a
     23b:	44                   	inc    sp
     23c:	0f 08                	invd
     23e:	4e                   	dec    si
     23f:	31 31                	xor    WORD PTR [bx+di],si
     241:	43                   	inc    bx
     242:	6c                   	ins    BYTE PTR es:[di],dx
     243:	69 63 6b e9 00       	imul   sp,WORD PTR [bp+di+0x6b],0xe9
     248:	fd                   	std
     249:	0e                   	push   cs
     24a:	7c 01                	jl     0x24d
     24c:	00 00                	add    BYTE PTR [bx+si],al
     24e:	06                   	push   es
     24f:	50                   	push   ax
     250:	61                   	popa
     251:	6e                   	outs   dx,BYTE PTR ds:[si]
     252:	65 6c                	gs ins BYTE PTR es:[di],dx
     254:	30 80 01 00          	xor    BYTE PTR [bx+si+0x1],al
     258:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     25c:	6e                   	outs   dx,BYTE PTR ds:[si]
     25d:	65 6c                	gs ins BYTE PTR es:[di],dx
     25f:	32 84 01 00          	xor    al,BYTE PTR [si+0x1]
     263:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     267:	6e                   	outs   dx,BYTE PTR ds:[si]
     268:	65 6c                	gs ins BYTE PTR es:[di],dx
     26a:	35 88 01             	xor    ax,0x188
     26d:	00 00                	add    BYTE PTR [bx+si],al
     26f:	06                   	push   es
     270:	50                   	push   ax
     271:	61                   	popa
     272:	6e                   	outs   dx,BYTE PTR ds:[si]
     273:	65 6c                	gs ins BYTE PTR es:[di],dx
     275:	33 8c 01 00          	xor    cx,WORD PTR [si+0x1]
     279:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     27d:	6e                   	outs   dx,BYTE PTR ds:[si]
     27e:	65 6c                	gs ins BYTE PTR es:[di],dx
     280:	36 90                	ss nop
     282:	01 00                	add    WORD PTR [bx+si],ax
     284:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     288:	6e                   	outs   dx,BYTE PTR ds:[si]
     289:	65 6c                	gs ins BYTE PTR es:[di],dx
     28b:	38 94 01 00          	cmp    BYTE PTR [si+0x1],dl
     28f:	00 07                	add    BYTE PTR [bx],al
     291:	50                   	push   ax
     292:	61                   	popa
     293:	6e                   	outs   dx,BYTE PTR ds:[si]
     294:	65 6c                	gs ins BYTE PTR es:[di],dx
     296:	33 37                	xor    si,WORD PTR [bx]
     298:	98                   	cbw
     299:	01 00                	add    WORD PTR [bx+si],ax
     29b:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     29f:	6e                   	outs   dx,BYTE PTR ds:[si]
     2a0:	65 6c                	gs ins BYTE PTR es:[di],dx
     2a2:	34 9c                	xor    al,0x9c
     2a4:	01 04                	add    WORD PTR [si],ax
     2a6:	00 09                	add    BYTE PTR [bx+di],cl
     2a8:	47                   	inc    di
     2a9:	72 6f                	jb     0x31a
     2ab:	75 70                	jne    0x31d
     2ad:	42                   	inc    dx
     2ae:	6f                   	outs   dx,WORD PTR ds:[si]
     2af:	78 31                	js     0x2e2
     2b1:	a0 01 04             	mov    al,ds:0x401
     2b4:	00 09                	add    BYTE PTR [bx+di],cl
     2b6:	47                   	inc    di
     2b7:	72 6f                	jb     0x328
     2b9:	75 70                	jne    0x32b
     2bb:	42                   	inc    dx
     2bc:	6f                   	outs   dx,WORD PTR ds:[si]
     2bd:	78 34                	js     0x2f3
     2bf:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     2c0:	01 08                	add    WORD PTR [bx+si],cx
     2c2:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     2c6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2c9:	31 a8 01 08          	xor    WORD PTR [bx+si+0x801],bp
     2cd:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     2d1:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2d4:	34 ac                	xor    al,0xac
     2d6:	01 08                	add    WORD PTR [bx+si],cx
     2d8:	00 07                	add    BYTE PTR [bx],al
     2da:	4c                   	dec    sp
     2db:	61                   	popa
     2dc:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2df:	31 30                	xor    WORD PTR [bx+si],si
     2e1:	b0 01                	mov    al,0x1
     2e3:	08 00                	or     BYTE PTR [bx+si],al
     2e5:	07                   	pop    es
     2e6:	4c                   	dec    sp
     2e7:	61                   	popa
     2e8:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2eb:	33 30                	xor    si,WORD PTR [bx+si]
     2ed:	b4 01                	mov    ah,0x1
     2ef:	08 00                	or     BYTE PTR [bx+si],al
     2f1:	06                   	push   es
     2f2:	4c                   	dec    sp
     2f3:	61                   	popa
     2f4:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     2f7:	32 b8 01 08          	xor    bh,BYTE PTR [bx+si+0x801]
     2fb:	00 07                	add    BYTE PTR [bx],al
     2fd:	4c                   	dec    sp
     2fe:	61                   	popa
     2ff:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     302:	31 36 bc 01          	xor    WORD PTR ds:0x1bc,si
     306:	08 00                	or     BYTE PTR [bx+si],al
     308:	06                   	push   es
     309:	4c                   	dec    sp
     30a:	61                   	popa
     30b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     30e:	33 c0                	xor    ax,ax
     310:	01 0c                	add    WORD PTR [si],cx
     312:	00 07                	add    BYTE PTR [bx],al
     314:	44                   	inc    sp
     315:	42                   	inc    dx
     316:	45                   	inc    bp
     317:	64 69 74 31 c4 01    	imul   si,WORD PTR fs:[si+0x31],0x1c4
     31d:	0c 00                	or     al,0x0
     31f:	07                   	pop    es
     320:	44                   	inc    sp
     321:	42                   	inc    dx
     322:	45                   	inc    bp
     323:	64 69 74 34 c8 01    	imul   si,WORD PTR fs:[si+0x34],0x1c8
     329:	0c 00                	or     al,0x0
     32b:	08 44 42             	or     BYTE PTR [si+0x42],al
     32e:	45                   	inc    bp
     32f:	64 69 74 31 32 cc    	imul   si,WORD PTR fs:[si+0x31],0xcc32
     335:	01 0c                	add    WORD PTR [si],cx
     337:	00 08                	add    BYTE PTR [bx+si],cl
     339:	44                   	inc    sp
     33a:	42                   	inc    dx
     33b:	45                   	inc    bp
     33c:	64 69 74 33 32 d0    	imul   si,WORD PTR fs:[si+0x33],0xd032
     342:	01 0c                	add    WORD PTR [si],cx
     344:	00 07                	add    BYTE PTR [bx],al
     346:	44                   	inc    sp
     347:	42                   	inc    dx
     348:	45                   	inc    bp
     349:	64 69 74 32 d4 01    	imul   si,WORD PTR fs:[si+0x32],0x1d4
     34f:	0c 00                	or     al,0x0
     351:	08 44 42             	or     BYTE PTR [si+0x42],al
     354:	45                   	inc    bp
     355:	64 69 74 33 31 d8    	imul   si,WORD PTR fs:[si+0x33],0xd831
     35b:	01 0c                	add    WORD PTR [si],cx
     35d:	00 07                	add    BYTE PTR [bx],al
     35f:	44                   	inc    sp
     360:	42                   	inc    dx
     361:	45                   	inc    bp
     362:	64 69 74 33 dc 01    	imul   si,WORD PTR fs:[si+0x33],0x1dc
     368:	04 00                	add    al,0x0
     36a:	09 47 72             	or     WORD PTR [bx+0x72],ax
     36d:	6f                   	outs   dx,WORD PTR ds:[si]
     36e:	75 70                	jne    0x3e0
     370:	42                   	inc    dx
     371:	6f                   	outs   dx,WORD PTR ds:[si]
     372:	78 37                	js     0x3ab
     374:	e0 01                	loopne 0x377
     376:	08 00                	or     BYTE PTR [bx+si],al
     378:	07                   	pop    es
     379:	4c                   	dec    sp
     37a:	61                   	popa
     37b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     37e:	31 34                	xor    WORD PTR [si],si
     380:	e4 01                	in     al,0x1
     382:	08 00                	or     BYTE PTR [bx+si],al
     384:	07                   	pop    es
     385:	4c                   	dec    sp
     386:	61                   	popa
     387:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     38a:	33 31                	xor    si,WORD PTR [bx+di]
     38c:	e8 01 0c             	call   0xf90
     38f:	00 08                	add    BYTE PTR [bx+si],cl
     391:	44                   	inc    sp
     392:	42                   	inc    dx
     393:	45                   	inc    bp
     394:	64 69 74 31 36 ec    	imul   si,WORD PTR fs:[si+0x31],0xec36
     39a:	01 0c                	add    WORD PTR [si],cx
     39c:	00 08                	add    BYTE PTR [bx+si],cl
     39e:	44                   	inc    sp
     39f:	42                   	inc    dx
     3a0:	45                   	inc    bp
     3a1:	64 69 74 33 33 f0    	imul   si,WORD PTR fs:[si+0x33],0xf033
     3a7:	01 04                	add    WORD PTR [si],ax
     3a9:	00 09                	add    BYTE PTR [bx+di],cl
     3ab:	47                   	inc    di
     3ac:	72 6f                	jb     0x41d
     3ae:	75 70                	jne    0x420
     3b0:	42                   	inc    dx
     3b1:	6f                   	outs   dx,WORD PTR ds:[si]
     3b2:	78 35                	js     0x3e9
     3b4:	f4                   	hlt
     3b5:	01 00                	add    WORD PTR [bx+si],ax
     3b7:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     3bb:	6e                   	outs   dx,BYTE PTR ds:[si]
     3bc:	65 6c                	gs ins BYTE PTR es:[di],dx
     3be:	37                   	aaa
     3bf:	f8                   	clc
     3c0:	01 08                	add    WORD PTR [bx+si],cx
     3c2:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     3c6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3c9:	35 fc 01             	xor    ax,0x1fc
     3cc:	08 00                	or     BYTE PTR [bx+si],al
     3ce:	06                   	push   es
     3cf:	4c                   	dec    sp
     3d0:	61                   	popa
     3d1:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3d4:	39 00                	cmp    WORD PTR [bx+si],ax
     3d6:	02 08                	add    cl,BYTE PTR [bx+si]
     3d8:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     3dc:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3df:	38 04                	cmp    BYTE PTR [si],al
     3e1:	02 08                	add    cl,BYTE PTR [bx+si]
     3e3:	00 06 4c 61          	add    BYTE PTR ds:0x614c,al
     3e7:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     3ea:	37                   	aaa
     3eb:	08 02                	or     BYTE PTR [bp+si],al
     3ed:	0c 00                	or     al,0x0
     3ef:	07                   	pop    es
     3f0:	44                   	inc    sp
     3f1:	42                   	inc    dx
     3f2:	45                   	inc    bp
     3f3:	64 69 74 35 0c 02    	imul   si,WORD PTR fs:[si+0x35],0x20c
     3f9:	0c 00                	or     al,0x0
     3fb:	07                   	pop    es
     3fc:	44                   	inc    sp
     3fd:	42                   	inc    dx
     3fe:	45                   	inc    bp
     3ff:	64 69 74 37 10 02    	imul   si,WORD PTR fs:[si+0x37],0x210
     405:	0c 00                	or     al,0x0
     407:	07                   	pop    es
     408:	44                   	inc    sp
     409:	42                   	inc    dx
     40a:	45                   	inc    bp
     40b:	64 69 74 39 14 02    	imul   si,WORD PTR fs:[si+0x39],0x214
     411:	00 00                	add    BYTE PTR [bx+si],al
     413:	07                   	pop    es
     414:	50                   	push   ax
     415:	61                   	popa
     416:	6e                   	outs   dx,BYTE PTR ds:[si]
     417:	65 6c                	gs ins BYTE PTR es:[di],dx
     419:	31 35                	xor    WORD PTR [di],si
     41b:	18 02                	sbb    BYTE PTR [bp+si],al
     41d:	08 00                	or     BYTE PTR [bx+si],al
     41f:	06                   	push   es
     420:	4c                   	dec    sp
     421:	61                   	popa
     422:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     425:	36 1c 02             	ss sbb al,0x2
     428:	0c 00                	or     al,0x0
     42a:	07                   	pop    es
     42b:	44                   	inc    sp
     42c:	42                   	inc    dx
     42d:	45                   	inc    bp
     42e:	64 69 74 36 20 02    	imul   si,WORD PTR fs:[si+0x36],0x220
     434:	0c 00                	or     al,0x0
     436:	07                   	pop    es
     437:	44                   	inc    sp
     438:	42                   	inc    dx
     439:	45                   	inc    bp
     43a:	64 69 74 38 24 02    	imul   si,WORD PTR fs:[si+0x38],0x224
     440:	0c 00                	or     al,0x0
     442:	08 44 42             	or     BYTE PTR [si+0x42],al
     445:	45                   	inc    bp
     446:	64 69 74 31 30 28    	imul   si,WORD PTR fs:[si+0x31],0x2830
     44c:	02 00                	add    al,BYTE PTR [bx+si]
     44e:	00 06 50 61          	add    BYTE PTR ds:0x6150,al
     452:	6e                   	outs   dx,BYTE PTR ds:[si]
     453:	65 6c                	gs ins BYTE PTR es:[di],dx
     455:	39 2c                	cmp    WORD PTR [si],bp
     457:	02 04                	add    al,BYTE PTR [si]
     459:	00 09                	add    BYTE PTR [bx+di],cl
     45b:	47                   	inc    di
     45c:	72 6f                	jb     0x4cd
     45e:	75 70                	jne    0x4d0
     460:	42                   	inc    dx
     461:	6f                   	outs   dx,WORD PTR ds:[si]
     462:	78 32                	js     0x496
     464:	30 02                	xor    BYTE PTR [bp+si],al
     466:	04 00                	add    al,0x0
     468:	09 47 72             	or     WORD PTR [bx+0x72],ax
     46b:	6f                   	outs   dx,WORD PTR ds:[si]
     46c:	75 70                	jne    0x4de
     46e:	42                   	inc    dx
     46f:	6f                   	outs   dx,WORD PTR ds:[si]
     470:	78 36                	js     0x4a8
     472:	34 02                	xor    al,0x2
     474:	08 00                	or     BYTE PTR [bx+si],al
     476:	07                   	pop    es
     477:	4c                   	dec    sp
     478:	61                   	popa
     479:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     47c:	31 32                	xor    WORD PTR [bp+si],si
     47e:	38 02                	cmp    BYTE PTR [bp+si],al
     480:	08 00                	or     BYTE PTR [bx+si],al
     482:	07                   	pop    es
     483:	4c                   	dec    sp
     484:	61                   	popa
     485:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     488:	31 33                	xor    WORD PTR [bp+di],si
     48a:	3c 02                	cmp    al,0x2
     48c:	0c 00                	or     al,0x0
     48e:	08 44 42             	or     BYTE PTR [si+0x42],al
     491:	45                   	inc    bp
     492:	64 69 74 31 34 40    	imul   si,WORD PTR fs:[si+0x31],0x4034
     498:	02 0c                	add    cl,BYTE PTR [si]
     49a:	00 08                	add    BYTE PTR [bx+si],cl
     49c:	44                   	inc    sp
     49d:	42                   	inc    dx
     49e:	45                   	inc    bp
     49f:	64 69 74 31 35 44    	imul   si,WORD PTR fs:[si+0x31],0x4435
     4a5:	02 04                	add    al,BYTE PTR [si]
     4a7:	00 09                	add    BYTE PTR [bx+di],cl
     4a9:	47                   	inc    di
     4aa:	72 6f                	jb     0x51b
     4ac:	75 70                	jne    0x51e
     4ae:	42                   	inc    dx
     4af:	6f                   	outs   dx,WORD PTR ds:[si]
     4b0:	78 38                	js     0x4ea
     4b2:	48                   	dec    ax
     4b3:	02 00                	add    al,BYTE PTR [bx+si]
     4b5:	00 07                	add    BYTE PTR [bx],al
     4b7:	50                   	push   ax
     4b8:	61                   	popa
     4b9:	6e                   	outs   dx,BYTE PTR ds:[si]
     4ba:	65 6c                	gs ins BYTE PTR es:[di],dx
     4bc:	31 30                	xor    WORD PTR [bx+si],si
     4be:	4c                   	dec    sp
     4bf:	02 08                	add    cl,BYTE PTR [bx+si]
     4c1:	00 07                	add    BYTE PTR [bx],al
     4c3:	4c                   	dec    sp
     4c4:	61                   	popa
     4c5:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4c8:	31 37                	xor    WORD PTR [bx],si
     4ca:	50                   	push   ax
     4cb:	02 08                	add    cl,BYTE PTR [bx+si]
     4cd:	00 07                	add    BYTE PTR [bx],al
     4cf:	4c                   	dec    sp
     4d0:	61                   	popa
     4d1:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4d4:	31 39                	xor    WORD PTR [bx+di],di
     4d6:	54                   	push   sp
     4d7:	02 0c                	add    cl,BYTE PTR [si]
     4d9:	00 08                	add    BYTE PTR [bx+si],cl
     4db:	44                   	inc    sp
     4dc:	42                   	inc    dx
     4dd:	45                   	inc    bp
     4de:	64 69 74 31 37 58    	imul   si,WORD PTR fs:[si+0x31],0x5837
     4e4:	02 00                	add    al,BYTE PTR [bx+si]
     4e6:	00 07                	add    BYTE PTR [bx],al
     4e8:	50                   	push   ax
     4e9:	61                   	popa
     4ea:	6e                   	outs   dx,BYTE PTR ds:[si]
     4eb:	65 6c                	gs ins BYTE PTR es:[di],dx
     4ed:	31 36 5c 02          	xor    WORD PTR ds:0x25c,si
     4f1:	08 00                	or     BYTE PTR [bx+si],al
     4f3:	07                   	pop    es
     4f4:	4c                   	dec    sp
     4f5:	61                   	popa
     4f6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     4f9:	31 38                	xor    WORD PTR [bx+si],di
     4fb:	60                   	pusha
     4fc:	02 0c                	add    cl,BYTE PTR [si]
     4fe:	00 08                	add    BYTE PTR [bx+si],cl
     500:	44                   	inc    sp
     501:	42                   	inc    dx
     502:	45                   	inc    bp
     503:	64 69 74 31 39 64    	imul   si,WORD PTR fs:[si+0x31],0x6439
     509:	02 04                	add    al,BYTE PTR [si]
     50b:	00 0a                	add    BYTE PTR [bp+si],cl
     50d:	47                   	inc    di
     50e:	72 6f                	jb     0x57f
     510:	75 70                	jne    0x582
     512:	42                   	inc    dx
     513:	6f                   	outs   dx,WORD PTR ds:[si]
     514:	78 31                	js     0x547
     516:	30 68 02             	xor    BYTE PTR [bx+si+0x2],ch
     519:	08 00                	or     BYTE PTR [bx+si],al
     51b:	07                   	pop    es
     51c:	4c                   	dec    sp
     51d:	61                   	popa
     51e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     521:	33 34                	xor    si,WORD PTR [si]
     523:	6c                   	ins    BYTE PTR es:[di],dx
     524:	02 08                	add    cl,BYTE PTR [bx+si]
     526:	00 07                	add    BYTE PTR [bx],al
     528:	4c                   	dec    sp
     529:	61                   	popa
     52a:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     52d:	31 31                	xor    WORD PTR [bx+di],si
     52f:	70 02                	jo     0x533
     531:	08 00                	or     BYTE PTR [bx+si],al
     533:	07                   	pop    es
     534:	4c                   	dec    sp
     535:	61                   	popa
     536:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     539:	33 35                	xor    si,WORD PTR [di]
     53b:	74 02                	je     0x53f
     53d:	08 00                	or     BYTE PTR [bx+si],al
     53f:	07                   	pop    es
     540:	4c                   	dec    sp
     541:	61                   	popa
     542:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     545:	33 37                	xor    si,WORD PTR [bx]
     547:	78 02                	js     0x54b
     549:	08 00                	or     BYTE PTR [bx+si],al
     54b:	07                   	pop    es
     54c:	4c                   	dec    sp
     54d:	61                   	popa
     54e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     551:	32 30                	xor    dh,BYTE PTR [bx+si]
     553:	7c 02                	jl     0x557
     555:	08 00                	or     BYTE PTR [bx+si],al
     557:	07                   	pop    es
     558:	4c                   	dec    sp
     559:	61                   	popa
     55a:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     55d:	33 38                	xor    di,WORD PTR [bx+si]
     55f:	80 02 0c             	add    BYTE PTR [bp+si],0xc
     562:	00 08                	add    BYTE PTR [bx+si],cl
     564:	44                   	inc    sp
     565:	42                   	inc    dx
     566:	45                   	inc    bp
     567:	64 69 74 33 36 84    	imul   si,WORD PTR fs:[si+0x33],0x8436
     56d:	02 0c                	add    cl,BYTE PTR [si]
     56f:	00 08                	add    BYTE PTR [bx+si],cl
     571:	44                   	inc    sp
     572:	42                   	inc    dx
     573:	45                   	inc    bp
     574:	64 69 74 31 33 88    	imul   si,WORD PTR fs:[si+0x31],0x8833
     57a:	02 0c                	add    cl,BYTE PTR [si]
     57c:	00 08                	add    BYTE PTR [bx+si],cl
     57e:	44                   	inc    sp
     57f:	42                   	inc    dx
     580:	45                   	inc    bp
     581:	64 69 74 33 37 8c    	imul   si,WORD PTR fs:[si+0x33],0x8c37
     587:	02 0c                	add    cl,BYTE PTR [si]
     589:	00 08                	add    BYTE PTR [bx+si],cl
     58b:	44                   	inc    sp
     58c:	42                   	inc    dx
     58d:	45                   	inc    bp
     58e:	64 69 74 33 39 90    	imul   si,WORD PTR fs:[si+0x33],0x9039
     594:	02 0c                	add    cl,BYTE PTR [si]
     596:	00 08                	add    BYTE PTR [bx+si],cl
     598:	44                   	inc    sp
     599:	42                   	inc    dx
     59a:	45                   	inc    bp
     59b:	64 69 74 31 38 94    	imul   si,WORD PTR fs:[si+0x31],0x9438
     5a1:	02 0c                	add    cl,BYTE PTR [si]
     5a3:	00 08                	add    BYTE PTR [bx+si],cl
     5a5:	44                   	inc    sp
     5a6:	42                   	inc    dx
     5a7:	45                   	inc    bp
     5a8:	64 69 74 34 30 98    	imul   si,WORD PTR fs:[si+0x34],0x9830
     5ae:	02 04                	add    al,BYTE PTR [si]
     5b0:	00 09                	add    BYTE PTR [bx+di],cl
     5b2:	47                   	inc    di
     5b3:	72 6f                	jb     0x624
     5b5:	75 70                	jne    0x627
     5b7:	42                   	inc    dx
     5b8:	6f                   	outs   dx,WORD PTR ds:[si]
     5b9:	78 39                	js     0x5f4
     5bb:	9c                   	pushf
     5bc:	02 08                	add    cl,BYTE PTR [bx+si]
     5be:	00 07                	add    BYTE PTR [bx],al
     5c0:	4c                   	dec    sp
     5c1:	61                   	popa
     5c2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5c5:	31 35                	xor    WORD PTR [di],si
     5c7:	a0 02 08             	mov    al,ds:0x802
     5ca:	00 07                	add    BYTE PTR [bx],al
     5cc:	4c                   	dec    sp
     5cd:	61                   	popa
     5ce:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5d1:	33 32                	xor    si,WORD PTR [bp+si]
     5d3:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     5d4:	02 08                	add    cl,BYTE PTR [bx+si]
     5d6:	00 07                	add    BYTE PTR [bx],al
     5d8:	4c                   	dec    sp
     5d9:	61                   	popa
     5da:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     5dd:	33 33                	xor    si,WORD PTR [bp+di]
     5df:	a8 02                	test   al,0x2
     5e1:	0c 00                	or     al,0x0
     5e3:	08 44 42             	or     BYTE PTR [si+0x42],al
     5e6:	45                   	inc    bp
     5e7:	64 69 74 31 31 ac    	imul   si,WORD PTR fs:[si+0x31],0xac31
     5ed:	02 0c                	add    cl,BYTE PTR [si]
     5ef:	00 08                	add    BYTE PTR [bx+si],cl
     5f1:	44                   	inc    sp
     5f2:	42                   	inc    dx
     5f3:	45                   	inc    bp
     5f4:	64 69 74 33 34 b0    	imul   si,WORD PTR fs:[si+0x33],0xb034
     5fa:	02 0c                	add    cl,BYTE PTR [si]
     5fc:	00 08                	add    BYTE PTR [bx+si],cl
     5fe:	44                   	inc    sp
     5ff:	42                   	inc    dx
     600:	45                   	inc    bp
     601:	64 69 74 33 35 b4    	imul   si,WORD PTR fs:[si+0x33],0xb435
     607:	02 04                	add    al,BYTE PTR [si]
     609:	00 0a                	add    BYTE PTR [bp+si],cl
     60b:	47                   	inc    di
     60c:	72 6f                	jb     0x67d
     60e:	75 70                	jne    0x680
     610:	42                   	inc    dx
     611:	6f                   	outs   dx,WORD PTR ds:[si]
     612:	78 31                	js     0x645
     614:	32 b8 02 08          	xor    bh,BYTE PTR [bx+si+0x802]
     618:	00 07                	add    BYTE PTR [bx],al
     61a:	4c                   	dec    sp
     61b:	61                   	popa
     61c:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     61f:	34 36                	xor    al,0x36
     621:	bc 02 0c             	mov    sp,0xc02
     624:	00 08                	add    BYTE PTR [bx+si],cl
     626:	44                   	inc    sp
     627:	42                   	inc    dx
     628:	45                   	inc    bp
     629:	64 69 74 32 30 c0    	imul   si,WORD PTR fs:[si+0x32],0xc030
     62f:	02 04                	add    al,BYTE PTR [si]
     631:	00 0a                	add    BYTE PTR [bp+si],cl
     633:	47                   	inc    di
     634:	72 6f                	jb     0x6a5
     636:	75 70                	jne    0x6a8
     638:	42                   	inc    dx
     639:	6f                   	outs   dx,WORD PTR ds:[si]
     63a:	78 31                	js     0x66d
     63c:	31 c4                	xor    sp,ax
     63e:	02 08                	add    cl,BYTE PTR [bx+si]
     640:	00 07                	add    BYTE PTR [bx],al
     642:	4c                   	dec    sp
     643:	61                   	popa
     644:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     647:	33 36 c8 02          	xor    si,WORD PTR ds:0x2c8
     64b:	0c 00                	or     al,0x0
     64d:	08 44 42             	or     BYTE PTR [si+0x42],al
     650:	45                   	inc    bp
     651:	64 69 74 33 38 cc    	imul   si,WORD PTR fs:[si+0x33],0xcc38
     657:	02 00                	add    al,BYTE PTR [bx+si]
     659:	00 07                	add    BYTE PTR [bx],al
     65b:	50                   	push   ax
     65c:	61                   	popa
     65d:	6e                   	outs   dx,BYTE PTR ds:[si]
     65e:	65 6c                	gs ins BYTE PTR es:[di],dx
     660:	31 31                	xor    WORD PTR [bx+di],si
     662:	d0 02                	rol    BYTE PTR [bp+si],1
     664:	04 00                	add    al,0x0
     666:	09 47 72             	or     WORD PTR [bx+0x72],ax
     669:	6f                   	outs   dx,WORD PTR ds:[si]
     66a:	75 70                	jne    0x6dc
     66c:	42                   	inc    dx
     66d:	6f                   	outs   dx,WORD PTR ds:[si]
     66e:	78 33                	js     0x6a3
     670:	d4 02                	aam    0x2
     672:	04 00                	add    al,0x0
     674:	0a 47 72             	or     al,BYTE PTR [bx+0x72]
     677:	6f                   	outs   dx,WORD PTR ds:[si]
     678:	75 70                	jne    0x6ea
     67a:	42                   	inc    dx
     67b:	6f                   	outs   dx,WORD PTR ds:[si]
     67c:	78 31                	js     0x6af
     67e:	33 d8                	xor    bx,ax
     680:	02 00                	add    al,BYTE PTR [bx+si]
     682:	00 07                	add    BYTE PTR [bx],al
     684:	50                   	push   ax
     685:	61                   	popa
     686:	6e                   	outs   dx,BYTE PTR ds:[si]
     687:	65 6c                	gs ins BYTE PTR es:[di],dx
     689:	31 32                	xor    WORD PTR [bp+si],si
     68b:	dc 02                	fadd   QWORD PTR [bp+si]
     68d:	08 00                	or     BYTE PTR [bx+si],al
     68f:	07                   	pop    es
     690:	4c                   	dec    sp
     691:	61                   	popa
     692:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     695:	32 36 e0 02          	xor    dh,BYTE PTR ds:0x2e0
     699:	08 00                	or     BYTE PTR [bx+si],al
     69b:	07                   	pop    es
     69c:	4c                   	dec    sp
     69d:	61                   	popa
     69e:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6a1:	33 39                	xor    di,WORD PTR [bx+di]
     6a3:	e4 02                	in     al,0x2
     6a5:	08 00                	or     BYTE PTR [bx+si],al
     6a7:	07                   	pop    es
     6a8:	4c                   	dec    sp
     6a9:	61                   	popa
     6aa:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6ad:	32 33                	xor    dh,BYTE PTR [bp+di]
     6af:	e8 02 08             	call   0xeb4
     6b2:	00 07                	add    BYTE PTR [bx],al
     6b4:	4c                   	dec    sp
     6b5:	61                   	popa
     6b6:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6b9:	32 32                	xor    dh,BYTE PTR [bp+si]
     6bb:	ec                   	in     al,dx
     6bc:	02 08                	add    cl,BYTE PTR [bx+si]
     6be:	00 07                	add    BYTE PTR [bx],al
     6c0:	4c                   	dec    sp
     6c1:	61                   	popa
     6c2:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6c5:	32 31                	xor    dh,BYTE PTR [bx+di]
     6c7:	f0 02 08             	lock add cl,BYTE PTR [bx+si]
     6ca:	00 07                	add    BYTE PTR [bx],al
     6cc:	4c                   	dec    sp
     6cd:	61                   	popa
     6ce:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     6d1:	32 34                	xor    dh,BYTE PTR [si]
     6d3:	f4                   	hlt
     6d4:	02 0c                	add    cl,BYTE PTR [si]
     6d6:	00 08                	add    BYTE PTR [bx+si],cl
     6d8:	44                   	inc    sp
     6d9:	42                   	inc    dx
     6da:	45                   	inc    bp
     6db:	64 69 74 32 31 f8    	imul   si,WORD PTR fs:[si+0x32],0xf831
     6e1:	02 0c                	add    cl,BYTE PTR [si]
     6e3:	00 08                	add    BYTE PTR [bx+si],cl
     6e5:	44                   	inc    sp
     6e6:	42                   	inc    dx
     6e7:	45                   	inc    bp
     6e8:	64 69 74 32 32 fc    	imul   si,WORD PTR fs:[si+0x32],0xfc32
     6ee:	02 0c                	add    cl,BYTE PTR [si]
     6f0:	00 08                	add    BYTE PTR [bx+si],cl
     6f2:	44                   	inc    sp
     6f3:	42                   	inc    dx
     6f4:	45                   	inc    bp
     6f5:	64 69 74 32 33 00    	imul   si,WORD PTR fs:[si+0x32],0x33
     6fb:	03 0c                	add    cx,WORD PTR [si]
     6fd:	00 08                	add    BYTE PTR [bx+si],cl
     6ff:	44                   	inc    sp
     700:	42                   	inc    dx
     701:	45                   	inc    bp
     702:	64 69 74 34 31 04    	imul   si,WORD PTR fs:[si+0x34],0x431
     708:	03 0c                	add    cx,WORD PTR [si]
     70a:	00 08                	add    BYTE PTR [bx+si],cl
     70c:	44                   	inc    sp
     70d:	42                   	inc    dx
     70e:	45                   	inc    bp
     70f:	64 69 74 32 34 08    	imul   si,WORD PTR fs:[si+0x32],0x834
     715:	03 00                	add    ax,WORD PTR [bx+si]
     717:	00 07                	add    BYTE PTR [bx],al
     719:	50                   	push   ax
     71a:	61                   	popa
     71b:	6e                   	outs   dx,BYTE PTR ds:[si]
     71c:	65 6c                	gs ins BYTE PTR es:[di],dx
     71e:	31 37                	xor    WORD PTR [bx],si
     720:	0c 03                	or     al,0x3
     722:	08 00                	or     BYTE PTR [bx+si],al
     724:	07                   	pop    es
     725:	4c                   	dec    sp
     726:	61                   	popa
     727:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     72a:	32 37                	xor    dh,BYTE PTR [bx]
     72c:	10 03                	adc    BYTE PTR [bp+di],al
     72e:	0c 00                	or     al,0x0
     730:	08 44 42             	or     BYTE PTR [si+0x42],al
     733:	45                   	inc    bp
     734:	64 69 74 32 36 14    	imul   si,WORD PTR fs:[si+0x32],0x1436
     73a:	03 0c                	add    cx,WORD PTR [si]
     73c:	00 08                	add    BYTE PTR [bx+si],cl
     73e:	44                   	inc    sp
     73f:	42                   	inc    dx
     740:	45                   	inc    bp
     741:	64 69 74 32 37 18    	imul   si,WORD PTR fs:[si+0x32],0x1837
     747:	03 0c                	add    cx,WORD PTR [si]
     749:	00 08                	add    BYTE PTR [bx+si],cl
     74b:	44                   	inc    sp
     74c:	42                   	inc    dx
     74d:	45                   	inc    bp
     74e:	64 69 74 32 38 1c    	imul   si,WORD PTR fs:[si+0x32],0x1c38
     754:	03 0c                	add    cx,WORD PTR [si]
     756:	00 08                	add    BYTE PTR [bx+si],cl
     758:	44                   	inc    sp
     759:	42                   	inc    dx
     75a:	45                   	inc    bp
     75b:	64 69 74 34 32 20    	imul   si,WORD PTR fs:[si+0x34],0x2032
     761:	03 0c                	add    cx,WORD PTR [si]
     763:	00 08                	add    BYTE PTR [bx+si],cl
     765:	44                   	inc    sp
     766:	42                   	inc    dx
     767:	45                   	inc    bp
     768:	64 69 74 32 39 24    	imul   si,WORD PTR fs:[si+0x32],0x2439
     76e:	03 04                	add    ax,WORD PTR [si]
     770:	00 0a                	add    BYTE PTR [bp+si],cl
     772:	47                   	inc    di
     773:	72 6f                	jb     0x7e4
     775:	75 70                	jne    0x7e7
     777:	42                   	inc    dx
     778:	6f                   	outs   dx,WORD PTR ds:[si]
     779:	78 31                	js     0x7ac
     77b:	35 28 03             	xor    ax,0x328
     77e:	08 00                	or     BYTE PTR [bx+si],al
     780:	07                   	pop    es
     781:	4c                   	dec    sp
     782:	61                   	popa
     783:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     786:	34 30                	xor    al,0x30
     788:	2c 03                	sub    al,0x3
     78a:	10 00                	adc    BYTE PTR [bx+si],al
     78c:	0b 44 42             	or     ax,WORD PTR [si+0x42]
     78f:	43                   	inc    bx
     790:	68 65 63             	push   0x6365
     793:	6b 42 6f 78          	imul   ax,WORD PTR [bp+si+0x6f],0x78
     797:	31 30                	xor    WORD PTR [bx+si],si
     799:	03 0c                	add    cx,WORD PTR [si]
     79b:	00 08                	add    BYTE PTR [bx+si],cl
     79d:	44                   	inc    sp
     79e:	42                   	inc    dx
     79f:	45                   	inc    bp
     7a0:	64 69 74 34 33 34    	imul   si,WORD PTR fs:[si+0x34],0x3433
     7a6:	03 04                	add    ax,WORD PTR [si]
     7a8:	00 0a                	add    BYTE PTR [bp+si],cl
     7aa:	47                   	inc    di
     7ab:	72 6f                	jb     0x81c
     7ad:	75 70                	jne    0x81f
     7af:	42                   	inc    dx
     7b0:	6f                   	outs   dx,WORD PTR ds:[si]
     7b1:	78 31                	js     0x7e4
     7b3:	37                   	aaa
     7b4:	38 03                	cmp    BYTE PTR [bp+di],al
     7b6:	08 00                	or     BYTE PTR [bx+si],al
     7b8:	07                   	pop    es
     7b9:	4c                   	dec    sp
     7ba:	61                   	popa
     7bb:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7be:	32 35                	xor    dh,BYTE PTR [di]
     7c0:	3c 03                	cmp    al,0x3
     7c2:	08 00                	or     BYTE PTR [bx+si],al
     7c4:	07                   	pop    es
     7c5:	4c                   	dec    sp
     7c6:	61                   	popa
     7c7:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7ca:	32 38                	xor    bh,BYTE PTR [bx+si]
     7cc:	40                   	inc    ax
     7cd:	03 0c                	add    cx,WORD PTR [si]
     7cf:	00 08                	add    BYTE PTR [bx+si],cl
     7d1:	44                   	inc    sp
     7d2:	42                   	inc    dx
     7d3:	45                   	inc    bp
     7d4:	64 69 74 32 35 44    	imul   si,WORD PTR fs:[si+0x32],0x4435
     7da:	03 0c                	add    cx,WORD PTR [si]
     7dc:	00 08                	add    BYTE PTR [bx+si],cl
     7de:	44                   	inc    sp
     7df:	42                   	inc    dx
     7e0:	45                   	inc    bp
     7e1:	64 69 74 33 30 48    	imul   si,WORD PTR fs:[si+0x33],0x4830
     7e7:	03 04                	add    ax,WORD PTR [si]
     7e9:	00 0a                	add    BYTE PTR [bp+si],cl
     7eb:	47                   	inc    di
     7ec:	72 6f                	jb     0x85d
     7ee:	75 70                	jne    0x860
     7f0:	42                   	inc    dx
     7f1:	6f                   	outs   dx,WORD PTR ds:[si]
     7f2:	78 31                	js     0x825
     7f4:	36 4c                	ss dec sp
     7f6:	03 08                	add    cx,WORD PTR [bx+si]
     7f8:	00 07                	add    BYTE PTR [bx],al
     7fa:	4c                   	dec    sp
     7fb:	61                   	popa
     7fc:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     7ff:	34 31                	xor    al,0x31
     801:	50                   	push   ax
     802:	03 0c                	add    cx,WORD PTR [si]
     804:	00 08                	add    BYTE PTR [bx+si],cl
     806:	44                   	inc    sp
     807:	42                   	inc    dx
     808:	45                   	inc    bp
     809:	64 69 74 34 34 54    	imul   si,WORD PTR fs:[si+0x34],0x5434
     80f:	03 00                	add    ax,WORD PTR [bx+si]
     811:	00 07                	add    BYTE PTR [bx],al
     813:	50                   	push   ax
     814:	61                   	popa
     815:	6e                   	outs   dx,BYTE PTR ds:[si]
     816:	65 6c                	gs ins BYTE PTR es:[di],dx
     818:	31 33                	xor    WORD PTR [bp+di],si
     81a:	58                   	pop    ax
     81b:	03 04                	add    ax,WORD PTR [si]
     81d:	00 0a                	add    BYTE PTR [bp+si],cl
     81f:	47                   	inc    di
     820:	72 6f                	jb     0x891
     822:	75 70                	jne    0x894
     824:	42                   	inc    dx
     825:	6f                   	outs   dx,WORD PTR ds:[si]
     826:	78 31                	js     0x859
     828:	34 5c                	xor    al,0x5c
     82a:	03 04                	add    ax,WORD PTR [si]
     82c:	00 0a                	add    BYTE PTR [bp+si],cl
     82e:	47                   	inc    di
     82f:	72 6f                	jb     0x8a0
     831:	75 70                	jne    0x8a3
     833:	42                   	inc    dx
     834:	6f                   	outs   dx,WORD PTR ds:[si]
     835:	78 31                	js     0x868
     837:	38 60 03             	cmp    BYTE PTR [bx+si+0x3],ah
     83a:	00 00                	add    BYTE PTR [bx+si],al
     83c:	07                   	pop    es
     83d:	50                   	push   ax
     83e:	61                   	popa
     83f:	6e                   	outs   dx,BYTE PTR ds:[si]
     840:	65 6c                	gs ins BYTE PTR es:[di],dx
     842:	31 34                	xor    WORD PTR [si],si
     844:	64 03 08             	add    cx,WORD PTR fs:[bx+si]
     847:	00 07                	add    BYTE PTR [bx],al
     849:	4c                   	dec    sp
     84a:	61                   	popa
     84b:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     84e:	34 32                	xor    al,0x32
     850:	68 03 08             	push   0x803
     853:	00 07                	add    BYTE PTR [bx],al
     855:	4c                   	dec    sp
     856:	61                   	popa
     857:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     85a:	34 35                	xor    al,0x35
     85c:	6c                   	ins    BYTE PTR es:[di],dx
     85d:	03 08                	add    cx,WORD PTR [bx+si]
     85f:	00 07                	add    BYTE PTR [bx],al
     861:	4c                   	dec    sp
     862:	61                   	popa
     863:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     866:	34 34                	xor    al,0x34
     868:	70 03                	jo     0x86d
     86a:	0c 00                	or     al,0x0
     86c:	08 44 42             	or     BYTE PTR [si+0x42],al
     86f:	45                   	inc    bp
     870:	64 69 74 34 35 74    	imul   si,WORD PTR fs:[si+0x34],0x7435
     876:	03 0c                	add    cx,WORD PTR [si]
     878:	00 08                	add    BYTE PTR [bx+si],cl
     87a:	44                   	inc    sp
     87b:	42                   	inc    dx
     87c:	45                   	inc    bp
     87d:	64 69 74 34 37 78    	imul   si,WORD PTR fs:[si+0x34],0x7837
     883:	03 00                	add    ax,WORD PTR [bx+si]
     885:	00 07                	add    BYTE PTR [bx],al
     887:	50                   	push   ax
     888:	61                   	popa
     889:	6e                   	outs   dx,BYTE PTR ds:[si]
     88a:	65 6c                	gs ins BYTE PTR es:[di],dx
     88c:	31 38                	xor    WORD PTR [bx+si],di
     88e:	7c 03                	jl     0x893
     890:	08 00                	or     BYTE PTR [bx+si],al
     892:	07                   	pop    es
     893:	4c                   	dec    sp
     894:	61                   	popa
     895:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     898:	34 33                	xor    al,0x33
     89a:	80 03 0c             	add    BYTE PTR [bp+di],0xc
     89d:	00 08                	add    BYTE PTR [bx+si],cl
     89f:	44                   	inc    sp
     8a0:	42                   	inc    dx
     8a1:	45                   	inc    bp
     8a2:	64 69 74 34 36 84    	imul   si,WORD PTR fs:[si+0x34],0x8436
     8a8:	03 0c                	add    cx,WORD PTR [si]
     8aa:	00 08                	add    BYTE PTR [bx+si],cl
     8ac:	44                   	inc    sp
     8ad:	42                   	inc    dx
     8ae:	45                   	inc    bp
     8af:	64 69 74 34 38 88    	imul   si,WORD PTR fs:[si+0x34],0x8838
     8b5:	03 00                	add    ax,WORD PTR [bx+si]
     8b7:	00 07                	add    BYTE PTR [bx],al
     8b9:	50                   	push   ax
     8ba:	61                   	popa
     8bb:	6e                   	outs   dx,BYTE PTR ds:[si]
     8bc:	65 6c                	gs ins BYTE PTR es:[di],dx
     8be:	34 34                	xor    al,0x34
     8c0:	8c 03                	mov    WORD PTR [bp+di],es
     8c2:	08 00                	or     BYTE PTR [bx+si],al
     8c4:	07                   	pop    es
     8c5:	4c                   	dec    sp
     8c6:	61                   	popa
     8c7:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     8ca:	55                   	push   bp
     8cb:	30 90 03 08          	xor    BYTE PTR [bx+si+0x803],dl
     8cf:	00 07                	add    BYTE PTR [bx],al
     8d1:	4c                   	dec    sp
     8d2:	61                   	popa
     8d3:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     8d6:	55                   	push   bp
     8d7:	31 94 03 08          	xor    WORD PTR [si+0x803],dx
     8db:	00 07                	add    BYTE PTR [bx],al
     8dd:	4c                   	dec    sp
     8de:	61                   	popa
     8df:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     8e2:	55                   	push   bp
     8e3:	32 98 03 08          	xor    bl,BYTE PTR [bx+si+0x803]
     8e7:	00 07                	add    BYTE PTR [bx],al
     8e9:	4c                   	dec    sp
     8ea:	61                   	popa
     8eb:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     8ee:	55                   	push   bp
     8ef:	33 9c 03 14          	xor    bx,WORD PTR [si+0x1403]
     8f3:	00 09                	add    BYTE PTR [bx+di],cl
     8f5:	4d                   	dec    bp
     8f6:	61                   	popa
     8f7:	69 6e 4d 65 6e       	imul   bp,WORD PTR [bp+0x4d],0x6e65
     8fc:	75 31                	jne    0x92f
     8fe:	a0 03 18             	mov    al,ds:0x1803
     901:	00 08                	add    BYTE PTR [bx+si],cl
     903:	46                   	inc    si
     904:	69 63 68 69 65       	imul   sp,WORD PTR [bp+di+0x68],0x6569
     909:	72 31                	jb     0x93c
     90b:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     90c:	03 18                	add    bx,WORD PTR [bx+si]
     90e:	00 09                	add    BYTE PTR [bx+di],cl
     910:	49                   	dec    cx
     911:	6d                   	ins    WORD PTR es:[di],dx
     912:	70 72                	jo     0x986
     914:	69 6d 65 72 31       	imul   bp,WORD PTR [di+0x65],0x3172
     919:	a8 03                	test   al,0x3
     91b:	18 00                	sbb    BYTE PTR [bx+si],al
     91d:	02 4e 31             	add    cl,BYTE PTR [bp+0x31]
     920:	ac                   	lods   al,BYTE PTR ds:[si]
     921:	03 18                	add    bx,WORD PTR [bx+si]
     923:	00 08                	add    BYTE PTR [bx+si],cl
     925:	51                   	push   cx
     926:	75 69                	jne    0x991
     928:	74 74                	je     0x99e
     92a:	65 72 31             	gs jb  0x95e
     92d:	b0 03                	mov    al,0x3
     92f:	18 00                	sbb    BYTE PTR [bx+si],al
     931:	08 45 64             	or     BYTE PTR [di+0x64],al
     934:	69 74 69 6f 6e       	imul   si,WORD PTR [si+0x69],0x6e6f
     939:	31 b4 03 18          	xor    WORD PTR [si+0x1803],si
     93d:	00 07                	add    BYTE PTR [bx],al
     93f:	43                   	inc    bx
     940:	6f                   	outs   dx,WORD PTR ds:[si]
     941:	70 69                	jo     0x9ac
     943:	65 72 31             	gs jb  0x977
     946:	b8 03 18             	mov    ax,0x1803
     949:	00 0a                	add    BYTE PTR [bp+si],cl
     94b:	41                   	inc    cx
     94c:	66 66 69 63 68 61 67 	data32 imul esp,DWORD PTR [bp+di+0x68],0x31656761
     953:	65 31 
     955:	bc 03 18             	mov    sp,0x1803
     958:	00 0d                	add    BYTE PTR [di],cl
     95a:	42                   	inc    dx
     95b:	61                   	popa
     95c:	72 72                	jb     0x9d0
     95e:	65 64 6f             	gs outs dx,WORD PTR fs:[si]
     961:	75 74                	jne    0x9d7
     963:	69 6c 73 31 c0       	imul   bp,WORD PTR [si+0x73],0xc031
     968:	03 18                	add    bx,WORD PTR [bx+si]
     96a:	00 0b                	add    BYTE PTR [bp+di],cl
     96c:	50                   	push   ax
     96d:	6c                   	ins    BYTE PTR es:[di],dx
     96e:	65 69 6e 45 63 72    	imul   bp,WORD PTR gs:[bp+0x45],0x7263
     974:	61                   	popa
     975:	6e                   	outs   dx,BYTE PTR ds:[si]
     976:	31 c4                	xor    sp,ax
     978:	03 18                	add    bx,WORD PTR [bx+si]
     97a:	00 02                	add    BYTE PTR [bp+si],al
     97c:	4e                   	dec    si
     97d:	32 c8                	xor    cl,al
     97f:	03 18                	add    bx,WORD PTR [bx+si]
     981:	00 05                	add    BYTE PTR [di],al
     983:	5a                   	pop    dx
     984:	6f                   	outs   dx,WORD PTR ds:[si]
     985:	6f                   	outs   dx,WORD PTR ds:[si]
     986:	6d                   	ins    WORD PTR es:[di],dx
     987:	31 cc                	xor    sp,cx
     989:	03 18                	add    bx,WORD PTR [bx+si]
     98b:	00 08                	add    BYTE PTR [bx+si],cl
     98d:	50                   	push   ax
     98e:	65 72 69             	gs jb  0x9fa
     991:	6f                   	outs   dx,WORD PTR ds:[si]
     992:	64 65 31 d0          	fs gs xor ax,dx
     996:	03 18                	add    bx,WORD PTR [bx+si]
     998:	00 05                	add    BYTE PTR [di],al
     99a:	41                   	inc    cx
     99b:	69 64 65 31 d4       	imul   sp,WORD PTR [si+0x65],0xd431
     9a0:	03 18                	add    bx,WORD PTR [bx+si]
     9a2:	00 06 46 69          	add    BYTE PTR ds:0x6946,al
     9a6:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     9a9:	31 d8                	xor    ax,bx
     9ab:	03 18                	add    bx,WORD PTR [bx+si]
     9ad:	00 02                	add    BYTE PTR [bp+si],al
     9af:	4e                   	dec    si
     9b0:	33 dc                	xor    bx,sp
     9b2:	03 18                	add    bx,WORD PTR [bx+si]
     9b4:	00 06 49 6e          	add    BYTE PTR ds:0x6e49,al
     9b8:	64 65 78 31          	fs gs js 0x9ed
     9bc:	e0 03                	loopne 0x9c1
     9be:	18 00                	sbb    BYTE PTR [bx+si],al
     9c0:	0b 52 65             	or     dx,WORD PTR [bp+si+0x65]
     9c3:	63 68 65             	arpl   WORD PTR [bx+si+0x65],bp
     9c6:	72 63                	jb     0xa2b
     9c8:	68 65 72             	push   0x7265
     9cb:	31 e4                	xor    sp,sp
     9cd:	03 18                	add    bx,WORD PTR [bx+si]
     9cf:	00 0e 55 74          	add    BYTE PTR ds:0x7455,cl
     9d3:	69 6c 69 73 65       	imul   bp,WORD PTR [si+0x69],0x6573
     9d8:	72 6c                	jb     0xa46
     9da:	61                   	popa
     9db:	69 64 65 31 e8       	imul   sp,WORD PTR [si+0x65],0xe831
     9e0:	03 18                	add    bx,WORD PTR [bx+si]
     9e2:	00 08                	add    BYTE PTR [bx+si],cl
     9e4:	41                   	inc    cx
     9e5:	70 72                	jo     0xa59
     9e7:	6f                   	outs   dx,WORD PTR ds:[si]
     9e8:	70 6f                	jo     0xa59
     9ea:	73 31                	jae    0xa1d
     9ec:	ec                   	in     al,dx
     9ed:	03 1c                	add    bx,WORD PTR [si]
     9ef:	00 07                	add    BYTE PTR [bx],al
     9f1:	54                   	push   sp
     9f2:	61                   	popa
     9f3:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     9f6:	44                   	inc    sp
     9f7:	47                   	inc    di
     9f8:	f0 03 20             	lock add sp,WORD PTR [bx+si]
     9fb:	00 0c                	add    BYTE PTR [si],cl
     9fd:	44                   	inc    sp
     9fe:	61                   	popa
     9ff:	74 61                	je     0xa62
     a01:	53                   	push   bx
     a02:	6f                   	outs   dx,WORD PTR ds:[si]
     a03:	75 72                	jne    0xa77
     a05:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     a08:	47                   	inc    di
     a09:	f4                   	hlt
     a0a:	03 1c                	add    bx,WORD PTR [si]
     a0c:	00 08                	add    BYTE PTR [bx+si],cl
     a0e:	54                   	push   sp
     a0f:	61                   	popa
     a10:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a13:	44                   	inc    sp
     a14:	50                   	push   ax
     a15:	31 f8                	xor    ax,di
     a17:	03 20                	add    sp,WORD PTR [bx+si]
     a19:	00 0d                	add    BYTE PTR [di],cl
     a1b:	44                   	inc    sp
     a1c:	61                   	popa
     a1d:	74 61                	je     0xa80
     a1f:	53                   	push   bx
     a20:	6f                   	outs   dx,WORD PTR ds:[si]
     a21:	75 72                	jne    0xa95
     a23:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     a26:	50                   	push   ax
     a27:	31 fc                	xor    sp,di
     a29:	03 1c                	add    bx,WORD PTR [si]
     a2b:	00 08                	add    BYTE PTR [bx+si],cl
     a2d:	54                   	push   sp
     a2e:	61                   	popa
     a2f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     a32:	44                   	inc    sp
     a33:	50                   	push   ax
     a34:	32 00                	xor    al,BYTE PTR [bx+si]
     a36:	04 20                	add    al,0x20
     a38:	00 0d                	add    BYTE PTR [di],cl
     a3a:	44                   	inc    sp
     a3b:	61                   	popa
     a3c:	74 61                	je     0xa9f
     a3e:	53                   	push   bx
     a3f:	6f                   	outs   dx,WORD PTR ds:[si]
     a40:	75 72                	jne    0xab4
     a42:	63 65 44             	arpl   WORD PTR [di+0x44],sp
     a45:	50                   	push   ax
     a46:	32 04                	xor    al,BYTE PTR [si]
     a48:	04 24                	add    al,0x24
     a4a:	00 0c                	add    BYTE PTR [si],cl
     a4c:	50                   	push   ax
     a4d:	72 69                	jb     0xab8
     a4f:	6e                   	outs   dx,BYTE PTR ds:[si]
     a50:	74 44                	je     0xa96
     a52:	69 61 6c 6f 67       	imul   sp,WORD PTR [bx+di+0x6c],0x676f
     a57:	31 08                	xor    WORD PTR [bx+si],cx
     a59:	04 08                	add    al,0x8
     a5b:	00 07                	add    BYTE PTR [bx],al
     a5d:	4c                   	dec    sp
     a5e:	61                   	popa
     a5f:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     a62:	34 38                	xor    al,0x38
     a64:	0c 04                	or     al,0x4
     a66:	0c 00                	or     al,0x0
     a68:	08 44 42             	or     BYTE PTR [si+0x42],al
     a6b:	45                   	inc    bp
     a6c:	64 69 74 34 39 10    	imul   si,WORD PTR fs:[si+0x34],0x1039
     a72:	04 28                	add    al,0x28
     a74:	00 05                	add    BYTE PTR [di],al
     a76:	4d                   	dec    bp
     a77:	65 6d                	gs ins WORD PTR es:[di],dx
     a79:	6f                   	outs   dx,WORD PTR ds:[si]
     a7a:	31 14                	xor    WORD PTR [si],dx
     a7c:	04 00                	add    al,0x0
     a7e:	00 0a                	add    BYTE PTR [bp+si],cl
     a80:	50                   	push   ax
     a81:	61                   	popa
     a82:	6e                   	outs   dx,BYTE PTR ds:[si]
     a83:	65 6c                	gs ins BYTE PTR es:[di],dx
     a85:	4c                   	dec    sp
     a86:	4f                   	dec    di
     a87:	55                   	push   bp
     a88:	50                   	push   ax
     a89:	45                   	inc    bp
     a8a:	18 04                	sbb    BYTE PTR [si],al
     a8c:	18 00                	sbb    BYTE PTR [bx+si],al
     a8e:	02 4e 34             	add    cl,BYTE PTR [bp+0x34]
     a91:	1c 04                	sbb    al,0x4
     a93:	08 00                	or     BYTE PTR [bx+si],al
     a95:	07                   	pop    es
     a96:	4c                   	dec    sp
     a97:	61                   	popa
     a98:	62 65 6c             	bound  sp,DWORD PTR [di+0x6c]
     a9b:	32 39                	xor    bh,BYTE PTR [bx+di]
     a9d:	20 04                	and    BYTE PTR [si],al
     a9f:	0c 00                	or     al,0x0
     aa1:	08 44 42             	or     BYTE PTR [si+0x42],al
     aa4:	45                   	inc    bp
     aa5:	64 69 74 35 30 24    	imul   si,WORD PTR fs:[si+0x35],0x2430
     aab:	04 0c                	add    al,0xc
     aad:	00 08                	add    BYTE PTR [bx+si],cl
     aaf:	44                   	inc    sp
     ab0:	42                   	inc    dx
     ab1:	45                   	inc    bp
     ab2:	64 69 74 35 31 28    	imul   si,WORD PTR fs:[si+0x35],0x2831
     ab8:	04 2c                	add    al,0x2c
     aba:	00 11                	add    BYTE PTR [bx+di],dl
     abc:	54                   	push   sp
     abd:	61                   	popa
     abe:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ac1:	44                   	inc    sp
     ac2:	50                   	push   ax
     ac3:	31 50 65             	xor    WORD PTR [bx+si+0x65],dx
     ac6:	72 69                	jb     0xb31
     ac8:	6f                   	outs   dx,WORD PTR ds:[si]
     ac9:	64 65 4e             	fs gs dec si
     acc:	6f                   	outs   dx,WORD PTR ds:[si]
     acd:	2c 04                	sub    al,0x4
     acf:	2c 00                	sub    al,0x0
     ad1:	11 54 61             	adc    WORD PTR [si+0x61],dx
     ad4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ad7:	44                   	inc    sp
     ad8:	50                   	push   ax
     ad9:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     adc:	6f                   	outs   dx,WORD PTR ds:[si]
     add:	64 75 69             	fs jne 0xb49
     ae0:	74 4e                	je     0xb30
     ae2:	6f                   	outs   dx,WORD PTR ds:[si]
     ae3:	30 04                	xor    BYTE PTR [si],al
     ae5:	30 00                	xor    BYTE PTR [bx+si],al
     ae7:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     aea:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     aed:	44                   	inc    sp
     aee:	50                   	push   ax
     aef:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     af2:	69 78 4d 69 6e       	imul   di,WORD PTR [bx+si+0x4d],0x6e69
     af7:	69 6d 75 6d 34       	imul   bp,WORD PTR [di+0x75],0x346d
     afc:	04 30                	add    al,0x30
     afe:	00 13                	add    BYTE PTR [bp+di],dl
     b00:	54                   	push   sp
     b01:	61                   	popa
     b02:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b05:	44                   	inc    sp
     b06:	50                   	push   ax
     b07:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     b0a:	69 78 4d 61 78       	imul   di,WORD PTR [bx+si+0x4d],0x7861
     b0f:	69 6d 75 6d 38       	imul   bp,WORD PTR [di+0x75],0x386d
     b14:	04 30                	add    al,0x30
     b16:	00 1a                	add    BYTE PTR [bp+si],bl
     b18:	54                   	push   sp
     b19:	61                   	popa
     b1a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b1d:	44                   	inc    sp
     b1e:	50                   	push   ax
     b1f:	31 49 6e             	xor    WORD PTR [bx+di+0x6e],cx
     b22:	64 69 63 65 43 6f    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6f43
     b28:	6e                   	outs   dx,BYTE PTR ds:[si]
     b29:	6a 6f                	push   0x6f
     b2b:	6e                   	outs   dx,BYTE PTR ds:[si]
     b2c:	63 74 75             	arpl   WORD PTR [si+0x75],si
     b2f:	72 65                	jb     0xb96
     b31:	6c                   	ins    BYTE PTR es:[di],dx
     b32:	3c 04                	cmp    al,0x4
     b34:	30 00                	xor    BYTE PTR [bx+si],al
     b36:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     b39:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b3c:	44                   	inc    sp
     b3d:	50                   	push   ax
     b3e:	31 43 6f             	xor    WORD PTR [bp+di+0x6f],ax
     b41:	75 74                	jne    0xbb7
     b43:	4d                   	dec    bp
     b44:	61                   	popa
     b45:	74 69                	je     0xbb0
     b47:	65 72 65             	gs jb  0xbaf
     b4a:	40                   	inc    ax
     b4b:	04 30                	add    al,0x30
     b4d:	00 11                	add    BYTE PTR [bx+di],dl
     b4f:	54                   	push   sp
     b50:	61                   	popa
     b51:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b54:	44                   	inc    sp
     b55:	50                   	push   ax
     b56:	31 50 6f             	xor    WORD PTR [bx+si+0x6f],dx
     b59:	69 64 73 50 72       	imul   sp,WORD PTR [si+0x73],0x7250
     b5e:	69 78 44 04 30       	imul   di,WORD PTR [bx+si+0x44],0x3004
     b63:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     b67:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b6a:	44                   	inc    sp
     b6b:	50                   	push   ax
     b6c:	31 50 6f             	xor    WORD PTR [bx+si+0x6f],dx
     b6f:	69 64 73 50 75       	imul   sp,WORD PTR [si+0x73],0x7550
     b74:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
     b77:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
     b7a:	65 48                	gs dec ax
     b7c:	04 30                	add    al,0x30
     b7e:	00 17                	add    BYTE PTR [bx],dl
     b80:	54                   	push   sp
     b81:	61                   	popa
     b82:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     b85:	44                   	inc    sp
     b86:	50                   	push   ax
     b87:	31 50 6f             	xor    WORD PTR [bx+si+0x6f],dx
     b8a:	69 64 73 46 6f       	imul   sp,WORD PTR [si+0x73],0x6f46
     b8f:	72 63                	jb     0xbf4
     b91:	65 56                	gs push si
     b93:	65 6e                	outs   dx,BYTE PTR gs:[si]
     b95:	74 65                	je     0xbfc
     b97:	4c                   	dec    sp
     b98:	04 30                	add    al,0x30
     b9a:	00 13                	add    BYTE PTR [bp+di],dl
     b9c:	54                   	push   sp
     b9d:	61                   	popa
     b9e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     ba1:	44                   	inc    sp
     ba2:	50                   	push   ax
     ba3:	31 50 6f             	xor    WORD PTR [bx+si+0x6f],dx
     ba6:	69 64 73 43 72       	imul   sp,WORD PTR [si+0x73],0x7243
     bab:	65 64 69 74 50 04 30 	gs imul si,WORD PTR fs:[si+0x50],0x3004
     bb2:	00 14                	add    BYTE PTR [si],dl
     bb4:	54                   	push   sp
     bb5:	61                   	popa
     bb6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bb9:	44                   	inc    sp
     bba:	50                   	push   ax
     bbb:	31 50 6f             	xor    WORD PTR [bx+si+0x6f],dx
     bbe:	69 64 73 51 75       	imul   sp,WORD PTR [si+0x73],0x7551
     bc3:	61                   	popa
     bc4:	6c                   	ins    BYTE PTR es:[di],dx
     bc5:	69 74 65 54 04       	imul   si,WORD PTR [si+0x65],0x454
     bca:	30 00                	xor    BYTE PTR [bx+si],al
     bcc:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     bcf:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bd2:	44                   	inc    sp
     bd3:	50                   	push   ax
     bd4:	31 50 6f             	xor    WORD PTR [bx+si+0x6f],dx
     bd7:	69 64 73 46 69       	imul   sp,WORD PTR [si+0x73],0x6946
     bdc:	64 65 6c             	fs gs ins BYTE PTR es:[di],dx
     bdf:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     be4:	6f                   	outs   dx,WORD PTR ds:[si]
     be5:	6e                   	outs   dx,BYTE PTR ds:[si]
     be6:	58                   	pop    ax
     be7:	04 2c                	add    al,0x2c
     be9:	00 1a                	add    BYTE PTR [bp+si],bl
     beb:	54                   	push   sp
     bec:	61                   	popa
     bed:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     bf0:	44                   	inc    sp
     bf1:	50                   	push   ax
     bf2:	31 41 70             	xor    WORD PTR [bx+di+0x70],ax
     bf5:	70 65                	jo     0xc5c
     bf7:	6c                   	ins    BYTE PTR es:[di],dx
     bf8:	4f                   	dec    di
     bf9:	66 66 72 65          	data32 data32 jb 0xc62
     bfd:	51                   	push   cx
     bfe:	75 61                	jne    0xc61
     c00:	6e                   	outs   dx,BYTE PTR ds:[si]
     c01:	74 69                	je     0xc6c
     c03:	74 65                	je     0xc6a
     c05:	5c                   	pop    sp
     c06:	04 30                	add    al,0x30
     c08:	00 19                	add    BYTE PTR [bx+di],bl
     c0a:	54                   	push   sp
     c0b:	61                   	popa
     c0c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c0f:	44                   	inc    sp
     c10:	50                   	push   ax
     c11:	31 41 70             	xor    WORD PTR [bx+di+0x70],ax
     c14:	70 65                	jo     0xc7b
     c16:	6c                   	ins    BYTE PTR es:[di],dx
     c17:	4f                   	dec    di
     c18:	66 66 72 65          	data32 data32 jb 0xc81
     c1c:	50                   	push   ax
     c1d:	72 69                	jb     0xc88
     c1f:	78 4d                	js     0xc6e
     c21:	61                   	popa
     c22:	78 60                	js     0xc84
     c24:	04 2c                	add    al,0x2c
     c26:	00 0f                	add    BYTE PTR [bx],cl
     c28:	54                   	push   sp
     c29:	61                   	popa
     c2a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c2d:	44                   	inc    sp
     c2e:	50                   	push   ax
     c2f:	31 53 70             	xor    WORD PTR [bp+di+0x70],dx
     c32:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     c36:	6c                   	ins    BYTE PTR es:[di],dx
     c37:	64 04 2c             	fs add al,0x2c
     c3a:	00 11                	add    BYTE PTR [bx+di],dl
     c3c:	54                   	push   sp
     c3d:	61                   	popa
     c3e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c41:	44                   	inc    sp
     c42:	50                   	push   ax
     c43:	32 50 65             	xor    dl,BYTE PTR [bx+si+0x65]
     c46:	72 69                	jb     0xcb1
     c48:	6f                   	outs   dx,WORD PTR ds:[si]
     c49:	64 65 4e             	fs gs dec si
     c4c:	6f                   	outs   dx,WORD PTR ds:[si]
     c4d:	68 04 2c             	push   0x2c04
     c50:	00 11                	add    BYTE PTR [bx+di],dl
     c52:	54                   	push   sp
     c53:	61                   	popa
     c54:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c57:	44                   	inc    sp
     c58:	50                   	push   ax
     c59:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     c5c:	6f                   	outs   dx,WORD PTR ds:[si]
     c5d:	64 75 69             	fs jne 0xcc9
     c60:	74 4e                	je     0xcb0
     c62:	6f                   	outs   dx,WORD PTR ds:[si]
     c63:	6c                   	ins    BYTE PTR es:[di],dx
     c64:	04 30                	add    al,0x30
     c66:	00 13                	add    BYTE PTR [bp+di],dl
     c68:	54                   	push   sp
     c69:	61                   	popa
     c6a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c6d:	44                   	inc    sp
     c6e:	50                   	push   ax
     c6f:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     c72:	69 78 4d 69 6e       	imul   di,WORD PTR [bx+si+0x4d],0x6e69
     c77:	69 6d 75 6d 70       	imul   bp,WORD PTR [di+0x75],0x706d
     c7c:	04 30                	add    al,0x30
     c7e:	00 13                	add    BYTE PTR [bp+di],dl
     c80:	54                   	push   sp
     c81:	61                   	popa
     c82:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c85:	44                   	inc    sp
     c86:	50                   	push   ax
     c87:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     c8a:	69 78 4d 61 78       	imul   di,WORD PTR [bx+si+0x4d],0x7861
     c8f:	69 6d 75 6d 74       	imul   bp,WORD PTR [di+0x75],0x746d
     c94:	04 30                	add    al,0x30
     c96:	00 1a                	add    BYTE PTR [bp+si],bl
     c98:	54                   	push   sp
     c99:	61                   	popa
     c9a:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     c9d:	44                   	inc    sp
     c9e:	50                   	push   ax
     c9f:	32 49 6e             	xor    cl,BYTE PTR [bx+di+0x6e]
     ca2:	64 69 63 65 43 6f    	imul   sp,WORD PTR fs:[bp+di+0x65],0x6f43
     ca8:	6e                   	outs   dx,BYTE PTR ds:[si]
     ca9:	6a 6f                	push   0x6f
     cab:	6e                   	outs   dx,BYTE PTR ds:[si]
     cac:	63 74 75             	arpl   WORD PTR [si+0x75],si
     caf:	72 65                	jb     0xd16
     cb1:	6c                   	ins    BYTE PTR es:[di],dx
     cb2:	78 04                	js     0xcb8
     cb4:	30 00                	xor    BYTE PTR [bx+si],al
     cb6:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     cb9:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     cbc:	44                   	inc    sp
     cbd:	50                   	push   ax
     cbe:	32 43 6f             	xor    al,BYTE PTR [bp+di+0x6f]
     cc1:	75 74                	jne    0xd37
     cc3:	4d                   	dec    bp
     cc4:	61                   	popa
     cc5:	74 69                	je     0xd30
     cc7:	65 72 65             	gs jb  0xd2f
     cca:	7c 04                	jl     0xcd0
     ccc:	30 00                	xor    BYTE PTR [bx+si],al
     cce:	11 54 61             	adc    WORD PTR [si+0x61],dx
     cd1:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     cd4:	44                   	inc    sp
     cd5:	50                   	push   ax
     cd6:	32 50 6f             	xor    dl,BYTE PTR [bx+si+0x6f]
     cd9:	69 64 73 50 72       	imul   sp,WORD PTR [si+0x73],0x7250
     cde:	69 78 80 04 30       	imul   di,WORD PTR [bx+si-0x80],0x3004
     ce3:	00 16 54 61          	add    BYTE PTR ds:0x6154,dl
     ce7:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     cea:	44                   	inc    sp
     ceb:	50                   	push   ax
     cec:	32 50 6f             	xor    dl,BYTE PTR [bx+si+0x6f]
     cef:	69 64 73 50 75       	imul   sp,WORD PTR [si+0x73],0x7550
     cf4:	62 6c 69             	bound  bp,DWORD PTR [si+0x69]
     cf7:	63 69 74             	arpl   WORD PTR [bx+di+0x74],bp
     cfa:	65 84 04             	test   BYTE PTR gs:[si],al
     cfd:	30 00                	xor    BYTE PTR [bx+si],al
     cff:	17                   	pop    ss
     d00:	54                   	push   sp
     d01:	61                   	popa
     d02:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d05:	44                   	inc    sp
     d06:	50                   	push   ax
     d07:	32 50 6f             	xor    dl,BYTE PTR [bx+si+0x6f]
     d0a:	69 64 73 46 6f       	imul   sp,WORD PTR [si+0x73],0x6f46
     d0f:	72 63                	jb     0xd74
     d11:	65 56                	gs push si
     d13:	65 6e                	outs   dx,BYTE PTR gs:[si]
     d15:	74 65                	je     0xd7c
     d17:	88 04                	mov    BYTE PTR [si],al
     d19:	30 00                	xor    BYTE PTR [bx+si],al
     d1b:	13 54 61             	adc    dx,WORD PTR [si+0x61]
     d1e:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d21:	44                   	inc    sp
     d22:	50                   	push   ax
     d23:	32 50 6f             	xor    dl,BYTE PTR [bx+si+0x6f]
     d26:	69 64 73 43 72       	imul   sp,WORD PTR [si+0x73],0x7243
     d2b:	65 64 69 74 8c 04 30 	gs imul si,WORD PTR fs:[si-0x74],0x3004
     d32:	00 14                	add    BYTE PTR [si],dl
     d34:	54                   	push   sp
     d35:	61                   	popa
     d36:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d39:	44                   	inc    sp
     d3a:	50                   	push   ax
     d3b:	32 50 6f             	xor    dl,BYTE PTR [bx+si+0x6f]
     d3e:	69 64 73 51 75       	imul   sp,WORD PTR [si+0x73],0x7551
     d43:	61                   	popa
     d44:	6c                   	ins    BYTE PTR es:[di],dx
     d45:	69 74 65 90 04       	imul   si,WORD PTR [si+0x65],0x490
     d4a:	30 00                	xor    BYTE PTR [bx+si],al
     d4c:	19 54 61             	sbb    WORD PTR [si+0x61],dx
     d4f:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d52:	44                   	inc    sp
     d53:	50                   	push   ax
     d54:	32 50 6f             	xor    dl,BYTE PTR [bx+si+0x6f]
     d57:	69 64 73 46 69       	imul   sp,WORD PTR [si+0x73],0x6946
     d5c:	64 65 6c             	fs gs ins BYTE PTR es:[di],dx
     d5f:	69 73 61 74 69       	imul   si,WORD PTR [bp+di+0x61],0x6974
     d64:	6f                   	outs   dx,WORD PTR ds:[si]
     d65:	6e                   	outs   dx,BYTE PTR ds:[si]
     d66:	94                   	xchg   sp,ax
     d67:	04 2c                	add    al,0x2c
     d69:	00 1a                	add    BYTE PTR [bp+si],bl
     d6b:	54                   	push   sp
     d6c:	61                   	popa
     d6d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d70:	44                   	inc    sp
     d71:	50                   	push   ax
     d72:	32 41 70             	xor    al,BYTE PTR [bx+di+0x70]
     d75:	70 65                	jo     0xddc
     d77:	6c                   	ins    BYTE PTR es:[di],dx
     d78:	4f                   	dec    di
     d79:	66 66 72 65          	data32 data32 jb 0xde2
     d7d:	51                   	push   cx
     d7e:	75 61                	jne    0xde1
     d80:	6e                   	outs   dx,BYTE PTR ds:[si]
     d81:	74 69                	je     0xdec
     d83:	74 65                	je     0xdea
     d85:	98                   	cbw
     d86:	04 30                	add    al,0x30
     d88:	00 19                	add    BYTE PTR [bx+di],bl
     d8a:	54                   	push   sp
     d8b:	61                   	popa
     d8c:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     d8f:	44                   	inc    sp
     d90:	50                   	push   ax
     d91:	32 41 70             	xor    al,BYTE PTR [bx+di+0x70]
     d94:	70 65                	jo     0xdfb
     d96:	6c                   	ins    BYTE PTR es:[di],dx
     d97:	4f                   	dec    di
     d98:	66 66 72 65          	data32 data32 jb 0xe01
     d9c:	50                   	push   ax
     d9d:	72 69                	jb     0xe08
     d9f:	78 4d                	js     0xdee
     da1:	61                   	popa
     da2:	78 9c                	js     0xd40
     da4:	04 2c                	add    al,0x2c
     da6:	00 0f                	add    BYTE PTR [bx],cl
     da8:	54                   	push   sp
     da9:	61                   	popa
     daa:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     dad:	44                   	inc    sp
     dae:	50                   	push   ax
     daf:	32 53 70             	xor    dl,BYTE PTR [bp+di+0x70]
     db2:	65 63 69 61          	arpl   WORD PTR gs:[bx+di+0x61],bp
     db6:	6c                   	ins    BYTE PTR es:[di],dx
     db7:	a0 04 34             	mov    al,ds:0x3404
     dba:	00 11                	add    BYTE PTR [bx+di],dl
     dbc:	54                   	push   sp
     dbd:	61                   	popa
     dbe:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     dc1:	44                   	inc    sp
     dc2:	50                   	push   ax
     dc3:	31 50 72             	xor    WORD PTR [bx+si+0x72],dx
     dc6:	69 78 4d 6f 79       	imul   di,WORD PTR [bx+si+0x4d],0x796f
     dcb:	65 6e                	outs   dx,BYTE PTR gs:[si]
     dcd:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     dce:	04 34                	add    al,0x34
     dd0:	00 11                	add    BYTE PTR [bx+di],dl
     dd2:	54                   	push   sp
     dd3:	61                   	popa
     dd4:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     dd7:	44                   	inc    sp
     dd8:	50                   	push   ax
     dd9:	32 50 72             	xor    dl,BYTE PTR [bx+si+0x72]
     ddc:	69 78 4d 6f 79       	imul   di,WORD PTR [bx+si+0x4d],0x796f
     de1:	65 6e                	outs   dx,BYTE PTR gs:[si]
     de3:	a8 04                	test   al,0x4
     de5:	18 00                	sbb    BYTE PTR [bx+si],al
     de7:	11 49 6d             	adc    WORD PTR [bx+di+0x6d],cx
     dea:	70 72                	jo     0xe5e
     dec:	65 73 73             	gs jae 0xe62
     def:	69 6f 6e 52 61       	imul   bp,WORD PTR [bx+0x6e],0x6152
     df4:	70 69                	jo     0xe5f
     df6:	64 65 31 ac 04 18    	fs xor WORD PTR gs:[si+0x1804],bp
     dfc:	00 02                	add    BYTE PTR [bp+si],al
     dfe:	4e                   	dec    si
     dff:	35 b0 04             	xor    ax,0x4b0
     e02:	18 00                	sbb    BYTE PTR [bx+si],al
     e04:	05 4e 31             	add    ax,0x314e
     e07:	30 30                	xor    BYTE PTR [bx+si],dh
     e09:	31 b4 04 18          	xor    WORD PTR [si+0x1804],si
     e0d:	00 05                	add    BYTE PTR [di],al
     e0f:	4e                   	dec    si
     e10:	31 32                	xor    WORD PTR [bp+si],si
     e12:	35 31 b8             	xor    ax,0xb831
     e15:	04 18                	add    al,0x18
     e17:	00 05                	add    BYTE PTR [di],al
     e19:	4e                   	dec    si
     e1a:	31 35                	xor    WORD PTR [di],si
     e1c:	30 31                	xor    BYTE PTR [bx+di],dh
     e1e:	bc 04 18             	mov    sp,0x1804
     e21:	00 05                	add    BYTE PTR [di],al
     e23:	4e                   	dec    si
     e24:	32 30                	xor    dh,BYTE PTR [bx+si]
     e26:	30 31                	xor    BYTE PTR [bx+di],dh
     e28:	c0 04 18             	rol    BYTE PTR [si],0x18
     e2b:	00 04                	add    BYTE PTR [si],al
     e2d:	4e                   	dec    si
     e2e:	37                   	aaa
     e2f:	35 31 c4             	xor    ax,0xc431
     e32:	04 18                	add    al,0x18
     e34:	00 04                	add    BYTE PTR [si],al
     e36:	4e                   	dec    si
     e37:	35 30 31             	xor    ax,0x3130
     e3a:	c8 04 18 00          	enter  0x1804,0x0
     e3e:	08 50 65             	or     BYTE PTR [bx+si+0x65],dl
     e41:	72 69                	jb     0xeac
     e43:	6f                   	outs   dx,WORD PTR ds:[si]
     e44:	64 65 32 cc          	fs gs xor cl,ah
     e48:	04 18                	add    al,0x18
     e4a:	00 06 61 75          	add    BYTE PTR ds:0x7561,al
     e4e:	74 72                	je     0xec2
     e50:	65 31 d0             	gs xor ax,dx
     e53:	04 18                	add    al,0x18
     e55:	00 04                	add    BYTE PTR [si],al
     e57:	4e                   	dec    si
     e58:	32 30                	xor    dh,BYTE PTR [bx+si]
     e5a:	31 d4                	xor    sp,dx
     e5c:	04 18                	add    al,0x18
     e5e:	00 04                	add    BYTE PTR [si],al
     e60:	4e                   	dec    si
     e61:	31 39                	xor    WORD PTR [bx+di],di
     e63:	31 d8                	xor    ax,bx
     e65:	04 18                	add    al,0x18
     e67:	00 04                	add    BYTE PTR [si],al
     e69:	4e                   	dec    si
     e6a:	31 38                	xor    WORD PTR [bx+si],di
     e6c:	31 dc                	xor    sp,bx
     e6e:	04 18                	add    al,0x18
     e70:	00 04                	add    BYTE PTR [si],al
     e72:	4e                   	dec    si
     e73:	31 37                	xor    WORD PTR [bx],si
     e75:	31 e0                	xor    ax,sp
     e77:	04 18                	add    al,0x18
     e79:	00 04                	add    BYTE PTR [si],al
     e7b:	4e                   	dec    si
     e7c:	31 36 31 e4          	xor    WORD PTR ds:0xe431,si
     e80:	04 18                	add    al,0x18
     e82:	00 04                	add    BYTE PTR [si],al
     e84:	4e                   	dec    si
     e85:	31 35                	xor    WORD PTR [di],si
     e87:	31 e8                	xor    ax,bp
     e89:	04 18                	add    al,0x18
     e8b:	00 04                	add    BYTE PTR [si],al
     e8d:	4e                   	dec    si
     e8e:	31 34                	xor    WORD PTR [si],si
     e90:	31 ec                	xor    sp,bp
     e92:	04 18                	add    al,0x18
     e94:	00 04                	add    BYTE PTR [si],al
     e96:	4e                   	dec    si
     e97:	31 33                	xor    WORD PTR [bp+di],si
     e99:	31 f0                	xor    ax,si
     e9b:	04 18                	add    al,0x18
     e9d:	00 04                	add    BYTE PTR [si],al
     e9f:	4e                   	dec    si
     ea0:	31 32                	xor    WORD PTR [bp+si],si
     ea2:	31 f4                	xor    sp,si
     ea4:	04 18                	add    al,0x18
     ea6:	00 04                	add    BYTE PTR [si],al
     ea8:	4e                   	dec    si
     ea9:	31 31                	xor    WORD PTR [bx+di],si
     eab:	31 f8                	xor    ax,di
     ead:	04 18                	add    al,0x18
     eaf:	00 04                	add    BYTE PTR [si],al
     eb1:	4e                   	dec    si
     eb2:	31 30                	xor    WORD PTR [bx+si],si
     eb4:	31 fc                	xor    sp,di
     eb6:	04 18                	add    al,0x18
     eb8:	00 03                	add    BYTE PTR [bp+di],al
     eba:	4e                   	dec    si
     ebb:	39 31                	cmp    WORD PTR [bx+di],si
     ebd:	00 05                	add    BYTE PTR [di],al
     ebf:	18 00                	sbb    BYTE PTR [bx+si],al
     ec1:	03 4e 38             	add    cx,WORD PTR [bp+0x38]
     ec4:	31 04                	xor    WORD PTR [si],ax
     ec6:	05 18 00             	add    ax,0x18
     ec9:	03 4e 37             	add    cx,WORD PTR [bp+0x37]
     ecc:	31 08                	xor    WORD PTR [bx+si],cx
     ece:	05 18 00             	add    ax,0x18
     ed1:	03 4e 36             	add    cx,WORD PTR [bp+0x36]
     ed4:	31 0c                	xor    WORD PTR [si],cx
     ed6:	05 18 00             	add    ax,0x18
     ed9:	03 4e 35             	add    cx,WORD PTR [bp+0x35]
     edc:	31 10                	xor    WORD PTR [bx+si],dx
     ede:	05 18 00             	add    ax,0x18
     ee1:	03 4e 34             	add    cx,WORD PTR [bp+0x34]
     ee4:	31 14                	xor    WORD PTR [si],dx
     ee6:	05 18 00             	add    ax,0x18
     ee9:	03 4e 33             	add    cx,WORD PTR [bp+0x33]
     eec:	31 18                	xor    WORD PTR [bx+si],bx
     eee:	05 18 00             	add    ax,0x18
     ef1:	03 4e 32             	add    cx,WORD PTR [bp+0x32]
     ef4:	31 1c                	xor    WORD PTR [si],bx
     ef6:	05 18 00             	add    ax,0x18
     ef9:	03 4e 31             	add    cx,WORD PTR [bp+0x31]
     efc:	31 0e 00 ad          	xor    WORD PTR ds:0xad00,cx
     f00:	0d 4b 2f             	or     ax,0x2f4b
     f03:	0c 01                	or     al,0x1
     f05:	09 0f                	or     WORD PTR [bx],cx
     f07:	17                   	pop    ss
     f08:	06                   	push   es
     f09:	29 0f                	sub    WORD PTR [bx],cx
     f0b:	22 00                	and    al,BYTE PTR [bx+si]
     f0d:	11 0f                	adc    WORD PTR [bx],cx
     f0f:	26 06                	es push es
     f11:	22 13                	and    dl,BYTE PTR [bp+di]
     f13:	ef                   	out    dx,ax
     f14:	02 19                	add    bl,BYTE PTR [bx+di]
     f16:	0f 94 00             	sete   BYTE PTR [bx+si]
     f19:	3a 10                	cmp    dl,BYTE PTR [bx+si]
     f1b:	38 01                	cmp    BYTE PTR [bx+di],al
     f1d:	2d 0f c8             	sub    ax,0xc80f
     f20:	08 3c                	or     BYTE PTR [si],bh
     f22:	13 7e 08             	adc    di,WORD PTR [bp+0x8]
     f25:	5d                   	pop    bp
     f26:	1d 91 12             	sbb    ax,0x1291
     f29:	d0 2d                	shr    BYTE PTR [di],1
     f2b:	c8 07 31 0f          	enter  0x3107,0xf
     f2f:	67 0c 35             	addr32 or al,0x35
     f32:	0f 58 0a             	addps  xmm1,XMMWORD PTR [bp+si]
     f35:	42                   	inc    dx
     f36:	12 07                	adc    al,BYTE PTR [bx]
     f38:	09 54 46             	or     WORD PTR [si+0x46],dx
     f3b:	6f                   	outs   dx,WORD PTR ds:[si]
     f3c:	72 6d                	jb     0xfab
     f3e:	53                   	push   bx
     f3f:	50                   	push   ax
     f40:	55                   	push   bp
     f41:	42                   	inc    dx
     f42:	22 00                	and    al,BYTE PTR [bx+si]
     f44:	9d                   	popf
     f45:	12 7b 06             	adc    bh,BYTE PTR [bp+di+0x6]
     f48:	73 0f                	jae    0xf59
     f4a:	38 00                	cmp    BYTE PTR [bx+si],al
     f4c:	04 53                	add    al,0x53
     f4e:	70 75                	jo     0xfc5
     f50:	62 00                	bound  ax,DWORD PTR [bx+si]
     f52:	00 55 89             	add    BYTE PTR [di-0x77],dl
     f55:	e5 31                	in     ax,0x31
     f57:	c0 9a 44 04 97       	rcr    BYTE PTR [bp+si+0x444],0x97
     f5c:	0f 6a 00             	punpckhdq mm0,QWORD PTR [bx+si]
     f5f:	9a c2 38 59 1c       	call   0x1c59:0x38c2
     f64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f67:	26 c7 85 04 01 03 00 	mov    WORD PTR es:[di+0x104],0x3
     f6e:	06                   	push   es
     f6f:	57                   	push   di
     f70:	9a 56 55 5c 10       	call   0x105c:0x5556
     f75:	9a c3 28 d6 11       	call   0x11d6:0x28c3
     f7a:	c9                   	leave
     f7b:	ca 04 00             	retf   0x4
     f7e:	0b 53 69             	or     dx,WORD PTR [bp+di+0x69]
     f81:	6d                   	ins    WORD PTR es:[di],dx
     f82:	73 74                	jae    0xff8
     f84:	72 61                	jb     0xfe7
     f86:	74 20                	je     0xfa8
     f88:	2d 20 03             	sub    ax,0x320
     f8b:	20 2d                	and    BYTE PTR [di],ch
     f8d:	20 55 89             	and    BYTE PTR [di-0x77],dl
     f90:	e5 b8                	in     ax,0xb8
     f92:	02 03                	add    al,BYTE PTR [bp+di]
     f94:	9a 44 04 ab 0f       	call   0xfab:0x444
     f99:	81 ec 02 03          	sub    sp,0x302
     f9d:	8d be fe fe          	lea    di,[bp-0x102]
     fa1:	16                   	push   ss
     fa2:	57                   	push   di
     fa3:	bf 7e 0f             	mov    di,0xf7e
     fa6:	0e                   	push   cs
     fa7:	57                   	push   di
     fa8:	9a cd 17 b5 0f       	call   0xfb5:0x17cd
     fad:	bf fa 1d             	mov    di,0x1dfa
     fb0:	1e                   	push   ds
     fb1:	57                   	push   di
     fb2:	9a 4c 18 bf 0f       	call   0xfbf:0x184c
     fb7:	bf 8a 0f             	mov    di,0xf8a
     fba:	0e                   	push   cs
     fbb:	57                   	push   di
     fbc:	9a 4c 18 d4 0f       	call   0xfd4:0x184c
     fc1:	8d be fe fd          	lea    di,[bp-0x202]
     fc5:	16                   	push   ss
     fc6:	57                   	push   di
     fc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fca:	06                   	push   es
     fcb:	57                   	push   di
     fcc:	9a 53 1d f9 0f       	call   0xff9:0x1d53
     fd1:	9a 4c 18 e5 0f       	call   0xfe5:0x184c
     fd6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fd9:	81 c7 26 05          	add    di,0x526
     fdd:	06                   	push   es
     fde:	57                   	push   di
     fdf:	68 ff 00             	push   0xff
     fe2:	9a e7 17 25 10       	call   0x1025:0x17e7
     fe7:	bf fa 1d             	mov    di,0x1dfa
     fea:	1e                   	push   ds
     feb:	57                   	push   di
     fec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fef:	26 c4 bd 88 01       	les    di,DWORD PTR es:[di+0x188]
     ff4:	06                   	push   es
     ff5:	57                   	push   di
     ff6:	9a 8c 1d b2 10       	call   0x10b2:0x1d8c
     ffb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ffe:	26 c7 85 20 05 64 00 	mov    WORD PTR es:[di+0x520],0x64
    1005:	26 c4 bd c8 04       	les    di,DWORD PTR es:[di+0x4c8]
    100a:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    100d:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    1010:	31 c0                	xor    ax,ax
    1012:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1015:	eb 03                	jmp    0x101a
    1017:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    101a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    101d:	05 01 00             	add    ax,0x1
    1020:	71 05                	jno    0x1027
    1022:	9a 3e 04 88 10       	call   0x1088:0x43e
    1027:	3b 06 4c 01          	cmp    ax,WORD PTR ds:0x14c
    102b:	7e 1a                	jle    0x1047
    102d:	6a 00                	push   0x0
    102f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1032:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1035:	06                   	push   es
    1036:	57                   	push   di
    1037:	9a 53 13 45 10       	call   0x1045:0x1353
    103c:	89 c7                	mov    di,ax
    103e:	8e c2                	mov    es,dx
    1040:	06                   	push   es
    1041:	57                   	push   di
    1042:	9a a5 13 cd 12       	call   0x12cd:0x13a5
    1047:	83 7e fe 14          	cmp    WORD PTR [bp-0x2],0x14
    104b:	75 ca                	jne    0x1017
    104d:	6a 00                	push   0x0
    104f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1052:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1057:	06                   	push   es
    1058:	57                   	push   di
    1059:	9a d0 1c 6d 10       	call   0x106d:0x1cd0
    105e:	6a 00                	push   0x0
    1060:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1063:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    1068:	06                   	push   es
    1069:	57                   	push   di
    106a:	9a d0 1c 85 12       	call   0x1285:0x1cd0
    106f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1072:	26 c7 85 24 05 01 00 	mov    WORD PTR es:[di+0x524],0x1
    1079:	06                   	push   es
    107a:	57                   	push   di
    107b:	9a 7d 52 aa 10       	call   0x10aa:0x527d
    1080:	2d 01 00             	sub    ax,0x1
    1083:	71 05                	jno    0x108a
    1085:	9a 3e 04 b9 10       	call   0x10b9:0x43e
    108a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    108d:	31 c0                	xor    ax,ax
    108f:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1092:	7e 03                	jle    0x1097
    1094:	e9 a7 00             	jmp    0x113e
    1097:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    109a:	eb 03                	jmp    0x109f
    109c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    109f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    10a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10a5:	06                   	push   es
    10a6:	57                   	push   di
    10a7:	9a 46 52 ca 10       	call   0x10ca:0x5246
    10ac:	52                   	push   dx
    10ad:	50                   	push   ax
    10ae:	bf 99 03             	mov    di,0x399
    10b1:	b8 d2 10             	mov    ax,0x10d2
    10b4:	50                   	push   ax
    10b5:	57                   	push   di
    10b6:	9a 55 22 d9 10       	call   0x10d9:0x2255
    10bb:	08 c0                	or     al,al
    10bd:	74 74                	je     0x1133
    10bf:	ff 76 fe             	push   WORD PTR [bp-0x2]
    10c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10c5:	06                   	push   es
    10c6:	57                   	push   di
    10c7:	9a 46 52 61 17       	call   0x1761:0x5246
    10cc:	52                   	push   dx
    10cd:	50                   	push   ax
    10ce:	bf 99 03             	mov    di,0x399
    10d1:	b8 31 11             	mov    ax,0x1131
    10d4:	50                   	push   ax
    10d5:	57                   	push   di
    10d6:	9a 73 22 16 11       	call   0x1116:0x2273
    10db:	89 c7                	mov    di,ax
    10dd:	8e c2                	mov    es,dx
    10df:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    10e2:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    10e5:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    10ea:	74 47                	je     0x1133
    10ec:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    10f0:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    10f4:	74 3d                	je     0x1133
    10f6:	a1 06 1e             	mov    ax,ds:0x1e06
    10f9:	99                   	cwd
    10fa:	8b c8                	mov    cx,ax
    10fc:	8b da                	mov    bx,dx
    10fe:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    1102:	26 8b 55 0e          	mov    dx,WORD PTR es:[di+0xe]
    1106:	09 d2                	or     dx,dx
    1108:	79 07                	jns    0x1111
    110a:	f7 d2                	not    dx
    110c:	f7 d8                	neg    ax
    110e:	83 da ff             	sbb    dx,0xffff
    1111:	71 05                	jno    0x1118
    1113:	9a 3e 04 cb 11       	call   0x11cb:0x43e
    1118:	3b d3                	cmp    dx,bx
    111a:	7c 0a                	jl     0x1126
    111c:	7f 04                	jg     0x1122
    111e:	3b c1                	cmp    ax,cx
    1120:	76 04                	jbe    0x1126
    1122:	b0 00                	mov    al,0x0
    1124:	eb 02                	jmp    0x1128
    1126:	b0 01                	mov    al,0x1
    1128:	50                   	push   ax
    1129:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    112c:	06                   	push   es
    112d:	57                   	push   di
    112e:	9a 77 1c 52 11       	call   0x1152:0x1c77
    1133:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1136:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1139:	74 03                	je     0x113e
    113b:	e9 5e ff             	jmp    0x109c
    113e:	8d be fe fe          	lea    di,[bp-0x102]
    1142:	16                   	push   ss
    1143:	57                   	push   di
    1144:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    1148:	26 c4 bd 4c 02       	les    di,DWORD PTR es:[di+0x24c]
    114d:	06                   	push   es
    114e:	57                   	push   di
    114f:	9a 53 1d 61 11       	call   0x1161:0x1d53
    1154:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1157:	26 c4 bd 8c 03       	les    di,DWORD PTR es:[di+0x38c]
    115c:	06                   	push   es
    115d:	57                   	push   di
    115e:	9a 8c 1d 77 11       	call   0x1177:0x1d8c
    1163:	8d be fe fe          	lea    di,[bp-0x102]
    1167:	16                   	push   ss
    1168:	57                   	push   di
    1169:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    116d:	26 c4 bd 50 02       	les    di,DWORD PTR es:[di+0x250]
    1172:	06                   	push   es
    1173:	57                   	push   di
    1174:	9a 53 1d 86 11       	call   0x1186:0x1d53
    1179:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    117c:	26 c4 bd 90 03       	les    di,DWORD PTR es:[di+0x390]
    1181:	06                   	push   es
    1182:	57                   	push   di
    1183:	9a 8c 1d 9c 11       	call   0x119c:0x1d8c
    1188:	8d be fe fe          	lea    di,[bp-0x102]
    118c:	16                   	push   ss
    118d:	57                   	push   di
    118e:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    1192:	26 c4 bd 54 02       	les    di,DWORD PTR es:[di+0x254]
    1197:	06                   	push   es
    1198:	57                   	push   di
    1199:	9a 53 1d ab 11       	call   0x11ab:0x1d53
    119e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11a1:	26 c4 bd 94 03       	les    di,DWORD PTR es:[di+0x394]
    11a6:	06                   	push   es
    11a7:	57                   	push   di
    11a8:	9a 8c 1d c1 11       	call   0x11c1:0x1d8c
    11ad:	8d be fe fe          	lea    di,[bp-0x102]
    11b1:	16                   	push   ss
    11b2:	57                   	push   di
    11b3:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    11b7:	26 c4 bd 48 02       	les    di,DWORD PTR es:[di+0x248]
    11bc:	06                   	push   es
    11bd:	57                   	push   di
    11be:	9a 53 1d 2e 12       	call   0x122e:0x1d53
    11c3:	bf 8a 0f             	mov    di,0xf8a
    11c6:	0e                   	push   cs
    11c7:	57                   	push   di
    11c8:	9a 4c 18 eb 11       	call   0x11eb:0x184c
    11cd:	8d be fe fd          	lea    di,[bp-0x202]
    11d1:	16                   	push   ss
    11d2:	57                   	push   di
    11d3:	9a fe 15 e6 11       	call   0x11e6:0x15fe
    11d8:	83 ec 08             	sub    sp,0x8
    11db:	89 e3                	mov    bx,sp
    11dd:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    11e1:	90                   	nop
    11e2:	9b                   	fwait
    11e3:	9a bf 1c 00 12       	call   0x1200:0x1cbf
    11e8:	9a 4c 18 f5 11       	call   0x11f5:0x184c
    11ed:	bf 8a 0f             	mov    di,0xf8a
    11f0:	0e                   	push   cs
    11f1:	57                   	push   di
    11f2:	9a 4c 18 15 12       	call   0x1215:0x184c
    11f7:	8d be fe fc          	lea    di,[bp-0x302]
    11fb:	16                   	push   ss
    11fc:	57                   	push   di
    11fd:	9a fe 15 10 12       	call   0x1210:0x15fe
    1202:	83 ec 08             	sub    sp,0x8
    1205:	89 e3                	mov    bx,sp
    1207:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    120b:	90                   	nop
    120c:	9b                   	fwait
    120d:	9a e4 1c d8 13       	call   0x13d8:0x1ce4
    1212:	9a 4c 18 1f 12       	call   0x121f:0x184c
    1217:	bf 8a 0f             	mov    di,0xf8a
    121a:	0e                   	push   cs
    121b:	57                   	push   di
    121c:	9a 4c 18 78 12       	call   0x1278:0x184c
    1221:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1224:	26 c4 bd 98 03       	les    di,DWORD PTR es:[di+0x398]
    1229:	06                   	push   es
    122a:	57                   	push   di
    122b:	9a 8c 1d 80 19       	call   0x1980:0x1d8c
    1230:	bf 32 1e             	mov    di,0x1e32
    1233:	1e                   	push   ds
    1234:	57                   	push   di
    1235:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1238:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    123d:	06                   	push   es
    123e:	57                   	push   di
    123f:	9a 17 30 56 12       	call   0x1256:0x3017
    1244:	bf 40 1e             	mov    di,0x1e40
    1247:	1e                   	push   ds
    1248:	57                   	push   di
    1249:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    124c:	26 c4 bd f4 03       	les    di,DWORD PTR es:[di+0x3f4]
    1251:	06                   	push   es
    1252:	57                   	push   di
    1253:	9a 17 30 6a 12       	call   0x126a:0x3017
    1258:	bf 40 1e             	mov    di,0x1e40
    125b:	1e                   	push   ds
    125c:	57                   	push   di
    125d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1260:	26 c4 bd fc 03       	les    di,DWORD PTR es:[di+0x3fc]
    1265:	06                   	push   es
    1266:	57                   	push   di
    1267:	9a 17 30 4e 13       	call   0x134e:0x3017
    126c:	c9                   	leave
    126d:	ca 08 00             	retf   0x8
    1270:	55                   	push   bp
    1271:	89 e5                	mov    bp,sp
    1273:	31 c0                	xor    ax,ax
    1275:	9a 44 04 93 12       	call   0x1293:0x444
    127a:	6a fe                	push   0xfffe
    127c:	c4 3e 2e 2c          	les    di,DWORD PTR ds:0x2c2e
    1280:	06                   	push   es
    1281:	57                   	push   di
    1282:	9a a9 63 91 13       	call   0x1391:0x63a9
    1287:	c9                   	leave
    1288:	ca 08 00             	retf   0x8
    128b:	55                   	push   bp
    128c:	89 e5                	mov    bp,sp
    128e:	31 c0                	xor    ax,ax
    1290:	9a 44 04 b2 12       	call   0x12b2:0x444
    1295:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1298:	06                   	push   es
    1299:	57                   	push   di
    129a:	9a 48 18 c5 17       	call   0x17c5:0x1848
    129f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    12a2:	26 c6 05 02          	mov    BYTE PTR es:[di],0x2
    12a6:	c9                   	leave
    12a7:	ca 0c 00             	retf   0xc
    12aa:	55                   	push   bp
    12ab:	89 e5                	mov    bp,sp
    12ad:	31 c0                	xor    ax,ax
    12af:	9a 44 04 02 13       	call   0x1302:0x444
    12b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12b7:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    12bd:	b0 00                	mov    al,0x0
    12bf:	75 01                	jne    0x12c2
    12c1:	40                   	inc    ax
    12c2:	50                   	push   ax
    12c3:	26 c4 bd c0 03       	les    di,DWORD PTR es:[di+0x3c0]
    12c8:	06                   	push   es
    12c9:	57                   	push   di
    12ca:	9a 75 12 27 18       	call   0x1827:0x1275
    12cf:	c9                   	leave
    12d0:	ca 08 00             	retf   0x8
    12d3:	0a 23                	or     ah,BYTE PTR [bp+di]
    12d5:	2c 23                	sub    al,0x23
    12d7:	23 30                	and    si,WORD PTR [bx+si]
    12d9:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    12dc:	23 23                	and    sp,WORD PTR [bp+di]
    12de:	07                   	pop    es
    12df:	23 30                	and    si,WORD PTR [bx+si]
    12e1:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    12e4:	23 23                	and    sp,WORD PTR [bp+di]
    12e6:	07                   	pop    es
    12e7:	30 2e 30 45          	xor    BYTE PTR ds:0x4530,ch
    12eb:	2b 30                	sub    si,WORD PTR [bx+si]
    12ed:	30 01                	xor    BYTE PTR [bx+di],al
    12ef:	30 05                	xor    BYTE PTR [di],al
    12f1:	23 2c                	and    bp,WORD PTR [si]
    12f3:	23 23                	and    sp,WORD PTR [bp+di]
    12f5:	30 02                	xor    BYTE PTR [bp+si],al
    12f7:	23 30                	and    si,WORD PTR [bx+si]
    12f9:	55                   	push   bp
    12fa:	89 e5                	mov    bp,sp
    12fc:	b8 10 03             	mov    ax,0x310
    12ff:	9a 44 04 55 13       	call   0x1355:0x444
    1304:	81 ec 10 03          	sub    sp,0x310
    1308:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    130b:	89 be f8 fd          	mov    WORD PTR [bp-0x208],di
    130f:	8c 86 fa fd          	mov    WORD PTR [bp-0x206],es
    1313:	8d be f8 fc          	lea    di,[bp-0x308]
    1317:	16                   	push   ss
    1318:	57                   	push   di
    1319:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    131d:	06                   	push   es
    131e:	57                   	push   di
    131f:	9a 9f 1a 2d 13       	call   0x132d:0x1a9f
    1324:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    1328:	06                   	push   es
    1329:	57                   	push   di
    132a:	9a 5f 1a 92 17       	call   0x1792:0x1a5f
    132f:	89 c7                	mov    di,ax
    1331:	8e c2                	mov    es,dx
    1333:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    1337:	06                   	push   es
    1338:	57                   	push   di
    1339:	9a 9b 3b 5f 18       	call   0x185f:0x3b9b
    133e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1341:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1344:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1347:	ff 76 fc             	push   WORD PTR [bp-0x4]
    134a:	bf 58 0a             	mov    di,0xa58
    134d:	b8 68 13             	mov    ax,0x1368
    1350:	50                   	push   ax
    1351:	57                   	push   di
    1352:	9a 55 22 6f 13       	call   0x136f:0x2255
    1357:	08 c0                	or     al,al
    1359:	75 03                	jne    0x135e
    135b:	e9 dc 01             	jmp    0x153a
    135e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1361:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1364:	bf 58 0a             	mov    di,0xa58
    1367:	b8 35 15             	mov    ax,0x1535
    136a:	50                   	push   ax
    136b:	57                   	push   di
    136c:	9a 73 22 af 13       	call   0x13af:0x2273
    1371:	89 c7                	mov    di,ax
    1373:	8e c2                	mov    es,dx
    1375:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    1379:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    137d:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    1381:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1385:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1389:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    138c:	06                   	push   es
    138d:	57                   	push   di
    138e:	9a d5 33 f6 13       	call   0x13f6:0x33d5
    1393:	89 c7                	mov    di,ax
    1395:	8e c2                	mov    es,dx
    1397:	06                   	push   es
    1398:	57                   	push   di
    1399:	9a 99 20 01 14       	call   0x1401:0x2099
    139e:	bf d3 12             	mov    di,0x12d3
    13a1:	0e                   	push   cs
    13a2:	57                   	push   di
    13a3:	8d be fc fd          	lea    di,[bp-0x204]
    13a7:	16                   	push   ss
    13a8:	57                   	push   di
    13a9:	68 ff 00             	push   0xff
    13ac:	9a e7 17 e6 13       	call   0x13e6:0x17e7
    13b1:	8d be f4 fc          	lea    di,[bp-0x30c]
    13b5:	16                   	push   ss
    13b6:	57                   	push   di
    13b7:	8d be fc fd          	lea    di,[bp-0x204]
    13bb:	16                   	push   ss
    13bc:	57                   	push   di
    13bd:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    13c1:	06                   	push   es
    13c2:	57                   	push   di
    13c3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13c6:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    13ca:	83 ec 0a             	sub    sp,0xa
    13cd:	89 e3                	mov    bx,sp
    13cf:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    13d3:	90                   	nop
    13d4:	9b                   	fwait
    13d5:	9a d4 10 58 14       	call   0x1458:0x10d4
    13da:	8d be fc fe          	lea    di,[bp-0x104]
    13de:	16                   	push   ss
    13df:	57                   	push   di
    13e0:	68 ff 00             	push   0xff
    13e3:	9a e7 17 15 14       	call   0x1415:0x17e7
    13e8:	8d be fc fe          	lea    di,[bp-0x104]
    13ec:	16                   	push   ss
    13ed:	57                   	push   di
    13ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13f1:	06                   	push   es
    13f2:	57                   	push   di
    13f3:	9a d5 33 76 14       	call   0x1476:0x33d5
    13f8:	89 c7                	mov    di,ax
    13fa:	8e c2                	mov    es,dx
    13fc:	06                   	push   es
    13fd:	57                   	push   di
    13fe:	9a 03 20 81 14       	call   0x1481:0x2003
    1403:	8b d0                	mov    dx,ax
    1405:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    1409:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    140d:	2d 05 00             	sub    ax,0x5
    1410:	71 05                	jno    0x1417
    1412:	9a 3e 04 2f 14       	call   0x142f:0x43e
    1417:	3b c2                	cmp    ax,dx
    1419:	7e 03                	jle    0x141e
    141b:	e9 08 01             	jmp    0x1526
    141e:	bf de 12             	mov    di,0x12de
    1421:	0e                   	push   cs
    1422:	57                   	push   di
    1423:	8d be fc fd          	lea    di,[bp-0x204]
    1427:	16                   	push   ss
    1428:	57                   	push   di
    1429:	68 ff 00             	push   0xff
    142c:	9a e7 17 66 14       	call   0x1466:0x17e7
    1431:	8d be f4 fc          	lea    di,[bp-0x30c]
    1435:	16                   	push   ss
    1436:	57                   	push   di
    1437:	8d be fc fd          	lea    di,[bp-0x204]
    143b:	16                   	push   ss
    143c:	57                   	push   di
    143d:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1441:	06                   	push   es
    1442:	57                   	push   di
    1443:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1446:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    144a:	83 ec 0a             	sub    sp,0xa
    144d:	89 e3                	mov    bx,sp
    144f:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1453:	90                   	nop
    1454:	9b                   	fwait
    1455:	9a d4 10 db 15       	call   0x15db:0x10d4
    145a:	8d be fc fe          	lea    di,[bp-0x104]
    145e:	16                   	push   ss
    145f:	57                   	push   di
    1460:	68 ff 00             	push   0xff
    1463:	9a e7 17 95 14       	call   0x1495:0x17e7
    1468:	8d be fc fe          	lea    di,[bp-0x104]
    146c:	16                   	push   ss
    146d:	57                   	push   di
    146e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1471:	06                   	push   es
    1472:	57                   	push   di
    1473:	9a d5 33 bf 14       	call   0x14bf:0x33d5
    1478:	89 c7                	mov    di,ax
    147a:	8e c2                	mov    es,dx
    147c:	06                   	push   es
    147d:	57                   	push   di
    147e:	9a 03 20 ca 14       	call   0x14ca:0x2003
    1483:	8b d0                	mov    dx,ax
    1485:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    1489:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    148d:	2d 05 00             	sub    ax,0x5
    1490:	71 05                	jno    0x1497
    1492:	9a 3e 04 af 14       	call   0x14af:0x43e
    1497:	3b c2                	cmp    ax,dx
    1499:	7e 03                	jle    0x149e
    149b:	e9 88 00             	jmp    0x1526
    149e:	bf e6 12             	mov    di,0x12e6
    14a1:	0e                   	push   cs
    14a2:	57                   	push   di
    14a3:	8d be fc fd          	lea    di,[bp-0x204]
    14a7:	16                   	push   ss
    14a8:	57                   	push   di
    14a9:	68 ff 00             	push   0xff
    14ac:	9a e7 17 de 14       	call   0x14de:0x17e7
    14b1:	8d be fc fd          	lea    di,[bp-0x204]
    14b5:	16                   	push   ss
    14b6:	57                   	push   di
    14b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14ba:	06                   	push   es
    14bb:	57                   	push   di
    14bc:	9a d5 33 87 15       	call   0x1587:0x33d5
    14c1:	89 c7                	mov    di,ax
    14c3:	8e c2                	mov    es,dx
    14c5:	06                   	push   es
    14c6:	57                   	push   di
    14c7:	9a 03 20 92 15       	call   0x1592:0x2003
    14cc:	8b d0                	mov    dx,ax
    14ce:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    14d2:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    14d6:	2d 05 00             	sub    ax,0x5
    14d9:	71 05                	jno    0x14e0
    14db:	9a 3e 04 0c 15       	call   0x150c:0x43e
    14e0:	3b c2                	cmp    ax,dx
    14e2:	b0 00                	mov    al,0x0
    14e4:	7e 01                	jle    0x14e7
    14e6:	40                   	inc    ax
    14e7:	8a d0                	mov    dl,al
    14e9:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    14ee:	b0 00                	mov    al,0x0
    14f0:	73 01                	jae    0x14f3
    14f2:	40                   	inc    ax
    14f3:	22 c2                	and    al,dl
    14f5:	08 c0                	or     al,al
    14f7:	74 17                	je     0x1510
    14f9:	bf ee 12             	mov    di,0x12ee
    14fc:	0e                   	push   cs
    14fd:	57                   	push   di
    14fe:	8d be fc fd          	lea    di,[bp-0x204]
    1502:	16                   	push   ss
    1503:	57                   	push   di
    1504:	68 ff 00             	push   0xff
    1507:	6a 03                	push   0x3
    1509:	9a 16 19 24 15       	call   0x1524:0x1916
    150e:	eb a1                	jmp    0x14b1
    1510:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1515:	76 0f                	jbe    0x1526
    1517:	8d be fc fd          	lea    di,[bp-0x204]
    151b:	16                   	push   ss
    151c:	57                   	push   di
    151d:	6a 03                	push   0x3
    151f:	6a 01                	push   0x1
    1521:	9a 75 19 4b 15       	call   0x154b:0x1975
    1526:	8d be fc fd          	lea    di,[bp-0x204]
    152a:	16                   	push   ss
    152b:	57                   	push   di
    152c:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1530:	06                   	push   es
    1531:	57                   	push   di
    1532:	9a f9 60 44 15       	call   0x1544:0x60f9
    1537:	e9 0d 02             	jmp    0x1747
    153a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    153d:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1540:	bf c8 07             	mov    di,0x7c8
    1543:	b8 5e 15             	mov    ax,0x155e
    1546:	50                   	push   ax
    1547:	57                   	push   di
    1548:	9a 55 22 65 15       	call   0x1565:0x2255
    154d:	08 c0                	or     al,al
    154f:	75 03                	jne    0x1554
    1551:	e9 f3 01             	jmp    0x1747
    1554:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1557:	ff 76 fc             	push   WORD PTR [bp-0x4]
    155a:	bf c8 07             	mov    di,0x7c8
    155d:	b8 45 17             	mov    ax,0x1745
    1560:	50                   	push   ax
    1561:	57                   	push   di
    1562:	9a 73 22 a5 15       	call   0x15a5:0x2273
    1567:	89 c7                	mov    di,ax
    1569:	8e c2                	mov    es,dx
    156b:	89 be f4 fd          	mov    WORD PTR [bp-0x20c],di
    156f:	8c 86 f6 fd          	mov    WORD PTR [bp-0x20a],es
    1573:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    1577:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    157b:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    157f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1582:	06                   	push   es
    1583:	57                   	push   di
    1584:	9a d5 33 f9 15       	call   0x15f9:0x33d5
    1589:	89 c7                	mov    di,ax
    158b:	8e c2                	mov    es,dx
    158d:	06                   	push   es
    158e:	57                   	push   di
    158f:	9a 99 20 04 16       	call   0x1604:0x2099
    1594:	bf f0 12             	mov    di,0x12f0
    1597:	0e                   	push   cs
    1598:	57                   	push   di
    1599:	8d be fc fd          	lea    di,[bp-0x204]
    159d:	16                   	push   ss
    159e:	57                   	push   di
    159f:	68 ff 00             	push   0xff
    15a2:	9a e7 17 e9 15       	call   0x15e9:0x17e7
    15a7:	8d be f0 fc          	lea    di,[bp-0x310]
    15ab:	16                   	push   ss
    15ac:	57                   	push   di
    15ad:	8d be fc fd          	lea    di,[bp-0x204]
    15b1:	16                   	push   ss
    15b2:	57                   	push   di
    15b3:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    15b7:	06                   	push   es
    15b8:	57                   	push   di
    15b9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    15bc:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    15c0:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    15c4:	89 96 f2 fd          	mov    WORD PTR [bp-0x20e],dx
    15c8:	9b db 86 f0 fd       	fild   DWORD PTR [bp-0x210]
    15cd:	83 ec 0a             	sub    sp,0xa
    15d0:	89 e3                	mov    bx,sp
    15d2:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    15d6:	90                   	nop
    15d7:	9b                   	fwait
    15d8:	9a d4 10 68 16       	call   0x1668:0x10d4
    15dd:	8d be fc fe          	lea    di,[bp-0x104]
    15e1:	16                   	push   ss
    15e2:	57                   	push   di
    15e3:	68 ff 00             	push   0xff
    15e6:	9a e7 17 18 16       	call   0x1618:0x17e7
    15eb:	8d be fc fe          	lea    di,[bp-0x104]
    15ef:	16                   	push   ss
    15f0:	57                   	push   di
    15f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15f4:	06                   	push   es
    15f5:	57                   	push   di
    15f6:	9a d5 33 86 16       	call   0x1686:0x33d5
    15fb:	89 c7                	mov    di,ax
    15fd:	8e c2                	mov    es,dx
    15ff:	06                   	push   es
    1600:	57                   	push   di
    1601:	9a 03 20 91 16       	call   0x1691:0x2003
    1606:	8b d0                	mov    dx,ax
    1608:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    160c:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1610:	2d 05 00             	sub    ax,0x5
    1613:	71 05                	jno    0x161a
    1615:	9a 3e 04 32 16       	call   0x1632:0x43e
    161a:	3b c2                	cmp    ax,dx
    161c:	7e 03                	jle    0x1621
    161e:	e9 15 01             	jmp    0x1736
    1621:	bf f6 12             	mov    di,0x12f6
    1624:	0e                   	push   cs
    1625:	57                   	push   di
    1626:	8d be fc fd          	lea    di,[bp-0x204]
    162a:	16                   	push   ss
    162b:	57                   	push   di
    162c:	68 ff 00             	push   0xff
    162f:	9a e7 17 76 16       	call   0x1676:0x17e7
    1634:	8d be f0 fc          	lea    di,[bp-0x310]
    1638:	16                   	push   ss
    1639:	57                   	push   di
    163a:	8d be fc fd          	lea    di,[bp-0x204]
    163e:	16                   	push   ss
    163f:	57                   	push   di
    1640:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1644:	06                   	push   es
    1645:	57                   	push   di
    1646:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1649:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    164d:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    1651:	89 96 f2 fd          	mov    WORD PTR [bp-0x20e],dx
    1655:	9b db 86 f0 fd       	fild   DWORD PTR [bp-0x210]
    165a:	83 ec 0a             	sub    sp,0xa
    165d:	89 e3                	mov    bx,sp
    165f:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    1663:	90                   	nop
    1664:	9b                   	fwait
    1665:	9a d4 10 71 19       	call   0x1971:0x10d4
    166a:	8d be fc fe          	lea    di,[bp-0x104]
    166e:	16                   	push   ss
    166f:	57                   	push   di
    1670:	68 ff 00             	push   0xff
    1673:	9a e7 17 a5 16       	call   0x16a5:0x17e7
    1678:	8d be fc fe          	lea    di,[bp-0x104]
    167c:	16                   	push   ss
    167d:	57                   	push   di
    167e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1681:	06                   	push   es
    1682:	57                   	push   di
    1683:	9a d5 33 cf 16       	call   0x16cf:0x33d5
    1688:	89 c7                	mov    di,ax
    168a:	8e c2                	mov    es,dx
    168c:	06                   	push   es
    168d:	57                   	push   di
    168e:	9a 03 20 da 16       	call   0x16da:0x2003
    1693:	8b d0                	mov    dx,ax
    1695:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    1699:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    169d:	2d 05 00             	sub    ax,0x5
    16a0:	71 05                	jno    0x16a7
    16a2:	9a 3e 04 bf 16       	call   0x16bf:0x43e
    16a7:	3b c2                	cmp    ax,dx
    16a9:	7e 03                	jle    0x16ae
    16ab:	e9 88 00             	jmp    0x1736
    16ae:	bf e6 12             	mov    di,0x12e6
    16b1:	0e                   	push   cs
    16b2:	57                   	push   di
    16b3:	8d be fc fd          	lea    di,[bp-0x204]
    16b7:	16                   	push   ss
    16b8:	57                   	push   di
    16b9:	68 ff 00             	push   0xff
    16bc:	9a e7 17 ee 16       	call   0x16ee:0x17e7
    16c1:	8d be fc fd          	lea    di,[bp-0x204]
    16c5:	16                   	push   ss
    16c6:	57                   	push   di
    16c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16ca:	06                   	push   es
    16cb:	57                   	push   di
    16cc:	9a d5 33 55 1b       	call   0x1b55:0x33d5
    16d1:	89 c7                	mov    di,ax
    16d3:	8e c2                	mov    es,dx
    16d5:	06                   	push   es
    16d6:	57                   	push   di
    16d7:	9a 03 20 ab 25       	call   0x25ab:0x2003
    16dc:	8b d0                	mov    dx,ax
    16de:	c4 be f8 fd          	les    di,DWORD PTR [bp-0x208]
    16e2:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    16e6:	2d 05 00             	sub    ax,0x5
    16e9:	71 05                	jno    0x16f0
    16eb:	9a 3e 04 1c 17       	call   0x171c:0x43e
    16f0:	3b c2                	cmp    ax,dx
    16f2:	b0 00                	mov    al,0x0
    16f4:	7e 01                	jle    0x16f7
    16f6:	40                   	inc    ax
    16f7:	8a d0                	mov    dl,al
    16f9:	80 be fc fd 0c       	cmp    BYTE PTR [bp-0x204],0xc
    16fe:	b0 00                	mov    al,0x0
    1700:	73 01                	jae    0x1703
    1702:	40                   	inc    ax
    1703:	22 c2                	and    al,dl
    1705:	08 c0                	or     al,al
    1707:	74 17                	je     0x1720
    1709:	bf ee 12             	mov    di,0x12ee
    170c:	0e                   	push   cs
    170d:	57                   	push   di
    170e:	8d be fc fd          	lea    di,[bp-0x204]
    1712:	16                   	push   ss
    1713:	57                   	push   di
    1714:	68 ff 00             	push   0xff
    1717:	6a 03                	push   0x3
    1719:	9a 16 19 34 17       	call   0x1734:0x1916
    171e:	eb a1                	jmp    0x16c1
    1720:	80 be fc fd 07       	cmp    BYTE PTR [bp-0x204],0x7
    1725:	76 0f                	jbe    0x1736
    1727:	8d be fc fd          	lea    di,[bp-0x204]
    172b:	16                   	push   ss
    172c:	57                   	push   di
    172d:	6a 03                	push   0x3
    172f:	6a 01                	push   0x1
    1731:	9a 75 19 54 17       	call   0x1754:0x1975
    1736:	8d be fc fd          	lea    di,[bp-0x204]
    173a:	16                   	push   ss
    173b:	57                   	push   di
    173c:	c4 be f4 fd          	les    di,DWORD PTR [bp-0x20c]
    1740:	06                   	push   es
    1741:	57                   	push   di
    1742:	9a f9 60 b0 18       	call   0x18b0:0x60f9
    1747:	c9                   	leave
    1748:	ca 08 00             	retf   0x8
    174b:	55                   	push   bp
    174c:	89 e5                	mov    bp,sp
    174e:	b8 04 00             	mov    ax,0x4
    1751:	9a 44 04 6b 17       	call   0x176b:0x444
    1756:	83 ec 04             	sub    sp,0x4
    1759:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    175c:	06                   	push   es
    175d:	57                   	push   di
    175e:	9a 7d 52 8a 17       	call   0x178a:0x527d
    1763:	2d 01 00             	sub    ax,0x1
    1766:	71 05                	jno    0x176d
    1768:	9a 3e 04 99 17       	call   0x1799:0x43e
    176d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1770:	31 c0                	xor    ax,ax
    1772:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1775:	7f 58                	jg     0x17cf
    1777:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    177a:	eb 03                	jmp    0x177f
    177c:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    177f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1782:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1785:	06                   	push   es
    1786:	57                   	push   di
    1787:	9a 46 52 aa 17       	call   0x17aa:0x5246
    178c:	52                   	push   dx
    178d:	50                   	push   ax
    178e:	bf 22 00             	mov    di,0x22
    1791:	b8 b2 17             	mov    ax,0x17b2
    1794:	50                   	push   ax
    1795:	57                   	push   di
    1796:	9a 55 22 b9 17       	call   0x17b9:0x2255
    179b:	08 c0                	or     al,al
    179d:	74 28                	je     0x17c7
    179f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    17a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17a5:	06                   	push   es
    17a6:	57                   	push   di
    17a7:	9a 46 52 ff ff       	call   0xffff:0x5246
    17ac:	52                   	push   dx
    17ad:	50                   	push   ax
    17ae:	bf 22 00             	mov    di,0x22
    17b1:	b8 78 22             	mov    ax,0x2278
    17b4:	50                   	push   ax
    17b5:	57                   	push   di
    17b6:	9a 73 22 dc 17       	call   0x17dc:0x2273
    17bb:	52                   	push   dx
    17bc:	50                   	push   ax
    17bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17c0:	06                   	push   es
    17c1:	57                   	push   di
    17c2:	9a f9 12 42 18       	call   0x1842:0x12f9
    17c7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    17ca:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    17cd:	75 ad                	jne    0x177c
    17cf:	c9                   	leave
    17d0:	ca 04 00             	retf   0x4
    17d3:	55                   	push   bp
    17d4:	89 e5                	mov    bp,sp
    17d6:	b8 06 00             	mov    ax,0x6
    17d9:	9a 44 04 0c 18       	call   0x180c:0x444
    17de:	83 ec 06             	sub    sp,0x6
    17e1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    17e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e7:	26 89 85 24 05       	mov    WORD PTR es:[di+0x524],ax
    17ec:	26 c4 bd c8 04       	les    di,DWORD PTR es:[di+0x4c8]
    17f1:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    17f4:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    17f7:	31 c0                	xor    ax,ax
    17f9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    17fc:	eb 03                	jmp    0x1801
    17fe:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1801:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1804:	05 01 00             	add    ax,0x1
    1807:	71 05                	jno    0x180e
    1809:	9a 3e 04 50 18       	call   0x1850:0x43e
    180e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1811:	26 3b 85 24 05       	cmp    ax,WORD PTR es:[di+0x524]
    1816:	b0 00                	mov    al,0x0
    1818:	75 01                	jne    0x181b
    181a:	40                   	inc    ax
    181b:	50                   	push   ax
    181c:	ff 76 fe             	push   WORD PTR [bp-0x2]
    181f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1822:	06                   	push   es
    1823:	57                   	push   di
    1824:	9a 53 13 32 18       	call   0x1832:0x1353
    1829:	89 c7                	mov    di,ax
    182b:	8e c2                	mov    es,dx
    182d:	06                   	push   es
    182e:	57                   	push   di
    182f:	9a 75 12 41 1e       	call   0x1e41:0x1275
    1834:	83 7e fe 13          	cmp    WORD PTR [bp-0x2],0x13
    1838:	75 c4                	jne    0x17fe
    183a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    183d:	06                   	push   es
    183e:	57                   	push   di
    183f:	9a 4e 19 4c 19       	call   0x194c:0x194e
    1844:	c9                   	leave
    1845:	ca 06 00             	retf   0x6
    1848:	55                   	push   bp
    1849:	89 e5                	mov    bp,sp
    184b:	31 c0                	xor    ax,ax
    184d:	9a 44 04 8c 18       	call   0x188c:0x444
    1852:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1855:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    185a:	06                   	push   es
    185b:	57                   	push   di
    185c:	9a d2 31 6e 18       	call   0x186e:0x31d2
    1861:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1864:	26 c4 bd f4 03       	les    di,DWORD PTR es:[di+0x3f4]
    1869:	06                   	push   es
    186a:	57                   	push   di
    186b:	9a d2 31 7d 18       	call   0x187d:0x31d2
    1870:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1873:	26 c4 bd fc 03       	les    di,DWORD PTR es:[di+0x3fc]
    1878:	06                   	push   es
    1879:	57                   	push   di
    187a:	9a d2 31 a4 18       	call   0x18a4:0x31d2
    187f:	c9                   	leave
    1880:	ca 04 00             	retf   0x4
    1883:	55                   	push   bp
    1884:	89 e5                	mov    bp,sp
    1886:	b8 04 00             	mov    ax,0x4
    1889:	9a 44 04 57 19       	call   0x1957:0x444
    188e:	83 ec 04             	sub    sp,0x4
    1891:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1894:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    1899:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    189c:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    189f:	06                   	push   es
    18a0:	57                   	push   di
    18a1:	9a d2 31 c6 18       	call   0x18c6:0x31d2
    18a6:	6a 01                	push   0x1
    18a8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    18ab:	06                   	push   es
    18ac:	57                   	push   di
    18ad:	9a fb 2f bc 18       	call   0x18bc:0x2ffb
    18b2:	6a 00                	push   0x0
    18b4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    18b7:	06                   	push   es
    18b8:	57                   	push   di
    18b9:	9a d2 2e e7 18       	call   0x18e7:0x2ed2
    18be:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    18c1:	06                   	push   es
    18c2:	57                   	push   di
    18c3:	9a bf 31 db 18       	call   0x18db:0x31bf
    18c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18cb:	26 c4 bd f4 03       	les    di,DWORD PTR es:[di+0x3f4]
    18d0:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    18d3:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    18d6:	06                   	push   es
    18d7:	57                   	push   di
    18d8:	9a d2 31 fd 18       	call   0x18fd:0x31d2
    18dd:	6a 01                	push   0x1
    18df:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    18e2:	06                   	push   es
    18e3:	57                   	push   di
    18e4:	9a fb 2f f3 18       	call   0x18f3:0x2ffb
    18e9:	6a 00                	push   0x0
    18eb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    18ee:	06                   	push   es
    18ef:	57                   	push   di
    18f0:	9a d2 2e 1e 19       	call   0x191e:0x2ed2
    18f5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    18f8:	06                   	push   es
    18f9:	57                   	push   di
    18fa:	9a bf 31 12 19       	call   0x1912:0x31bf
    18ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1902:	26 c4 bd fc 03       	les    di,DWORD PTR es:[di+0x3fc]
    1907:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    190a:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    190d:	06                   	push   es
    190e:	57                   	push   di
    190f:	9a d2 31 34 19       	call   0x1934:0x31d2
    1914:	6a 01                	push   0x1
    1916:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1919:	06                   	push   es
    191a:	57                   	push   di
    191b:	9a fb 2f 2a 19       	call   0x192a:0x2ffb
    1920:	6a 00                	push   0x0
    1922:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1925:	06                   	push   es
    1926:	57                   	push   di
    1927:	9a d2 2e 47 1a       	call   0x1a47:0x2ed2
    192c:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    192f:	06                   	push   es
    1930:	57                   	push   di
    1931:	9a bf 31 48 19       	call   0x1948:0x31bf
    1936:	c9                   	leave
    1937:	ca 04 00             	retf   0x4
    193a:	01 23                	add    WORD PTR [bp+di],sp
    193c:	00 00                	add    BYTE PTR [bx+si],al
    193e:	00 00                	add    BYTE PTR [bx+si],al
    1940:	ff 00                	inc    WORD PTR [bx+si]
    1942:	00 00                	add    BYTE PTR [bx+si],al
    1944:	01 00                	add    WORD PTR [bx+si],ax
    1946:	2f                   	das
    1947:	00 fe                	add    dh,bh
    1949:	23 10                	and    dx,WORD PTR [bx+si]
    194b:	1b 55 1a             	sbb    dx,WORD PTR [di+0x1a]
    194e:	55                   	push   bp
    194f:	89 e5                	mov    bp,sp
    1951:	b8 02 02             	mov    ax,0x202
    1954:	9a 44 04 97 19       	call   0x1997:0x444
    1959:	81 ec 02 02          	sub    sp,0x202
    195d:	8d be fe fd          	lea    di,[bp-0x202]
    1961:	16                   	push   ss
    1962:	57                   	push   di
    1963:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1966:	26 8b 85 24 05       	mov    ax,WORD PTR es:[di+0x524]
    196b:	99                   	cwd
    196c:	52                   	push   dx
    196d:	50                   	push   ax
    196e:	9a a9 08 dc 19       	call   0x19dc:0x8a9
    1973:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1976:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    197b:	06                   	push   es
    197c:	57                   	push   di
    197d:	9a 8c 1d 00 1a       	call   0x1a00:0x1d8c
    1982:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1985:	81 c7 26 05          	add    di,0x526
    1989:	06                   	push   es
    198a:	57                   	push   di
    198b:	8d be fe fe          	lea    di,[bp-0x102]
    198f:	16                   	push   ss
    1990:	57                   	push   di
    1991:	68 ff 00             	push   0xff
    1994:	9a e7 17 a7 19       	call   0x19a7:0x17e7
    1999:	bf 3a 19             	mov    di,0x193a
    199c:	0e                   	push   cs
    199d:	57                   	push   di
    199e:	8d be fe fe          	lea    di,[bp-0x102]
    19a2:	16                   	push   ss
    19a3:	57                   	push   di
    19a4:	9a 78 18 b0 19       	call   0x19b0:0x1878
    19a9:	99                   	cwd
    19aa:	bf 3c 19             	mov    di,0x193c
    19ad:	9a 16 04 c6 19       	call   0x19c6:0x416
    19b2:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    19b5:	8d be fe fe          	lea    di,[bp-0x102]
    19b9:	16                   	push   ss
    19ba:	57                   	push   di
    19bb:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    19be:	30 e4                	xor    ah,ah
    19c0:	50                   	push   ax
    19c1:	6a 01                	push   0x1
    19c3:	9a 75 19 f0 19       	call   0x19f0:0x1975
    19c8:	8d be fe fd          	lea    di,[bp-0x202]
    19cc:	16                   	push   ss
    19cd:	57                   	push   di
    19ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19d1:	26 8b 85 24 05       	mov    ax,WORD PTR es:[di+0x524]
    19d6:	99                   	cwd
    19d7:	52                   	push   dx
    19d8:	50                   	push   ax
    19d9:	9a a9 08 62 24       	call   0x2462:0x8a9
    19de:	8d be fe fe          	lea    di,[bp-0x102]
    19e2:	16                   	push   ss
    19e3:	57                   	push   di
    19e4:	68 ff 00             	push   0xff
    19e7:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    19ea:	30 e4                	xor    ah,ah
    19ec:	50                   	push   ax
    19ed:	9a 16 19 28 1b       	call   0x1b28:0x1916
    19f2:	8d be fe fe          	lea    di,[bp-0x102]
    19f6:	16                   	push   ss
    19f7:	57                   	push   di
    19f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19fb:	06                   	push   es
    19fc:	57                   	push   di
    19fd:	9a 8c 1d e6 1b       	call   0x1be6:0x1d8c
    1a02:	b8 44 19             	mov    ax,0x1944
    1a05:	0e                   	push   cs
    1a06:	50                   	push   ax
    1a07:	55                   	push   bp
    1a08:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1a0c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1a10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a13:	26 c4 bd ec 03       	les    di,DWORD PTR es:[di+0x3ec]
    1a18:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1a1c:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1a20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a23:	26 8b 85 24 05       	mov    ax,WORD PTR es:[di+0x524]
    1a28:	99                   	cwd
    1a29:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
    1a2d:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
    1a31:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1a36:	8d be f2 fe          	lea    di,[bp-0x10e]
    1a3a:	16                   	push   ss
    1a3b:	57                   	push   di
    1a3c:	6a 00                	push   0x0
    1a3e:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1a42:	06                   	push   es
    1a43:	57                   	push   di
    1a44:	9a 95 28 9f 1a       	call   0x1a9f:0x2895
    1a49:	08 c0                	or     al,al
    1a4b:	75 0a                	jne    0x1a57
    1a4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a50:	06                   	push   es
    1a51:	57                   	push   di
    1a52:	9a 53 0f ad 1a       	call   0x1aad:0xf53
    1a57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a5a:	26 c4 bd f4 03       	les    di,DWORD PTR es:[di+0x3f4]
    1a5f:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1a63:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1a67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a6a:	26 8b 85 24 05       	mov    ax,WORD PTR es:[di+0x524]
    1a6f:	99                   	cwd
    1a70:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    1a74:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    1a78:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    1a7d:	c7 86 f2 fe 01 00    	mov    WORD PTR [bp-0x10e],0x1
    1a83:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    1a89:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1a8e:	8d be ea fe          	lea    di,[bp-0x116]
    1a92:	16                   	push   ss
    1a93:	57                   	push   di
    1a94:	6a 01                	push   0x1
    1a96:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1a9a:	06                   	push   es
    1a9b:	57                   	push   di
    1a9c:	9a 95 28 f7 1a       	call   0x1af7:0x2895
    1aa1:	08 c0                	or     al,al
    1aa3:	75 0a                	jne    0x1aaf
    1aa5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aa8:	06                   	push   es
    1aa9:	57                   	push   di
    1aaa:	9a 53 0f 05 1b       	call   0x1b05:0xf53
    1aaf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ab2:	26 c4 bd fc 03       	les    di,DWORD PTR es:[di+0x3fc]
    1ab7:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    1abb:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    1abf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ac2:	26 8b 85 24 05       	mov    ax,WORD PTR es:[di+0x524]
    1ac7:	99                   	cwd
    1ac8:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    1acc:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    1ad0:	c6 86 ee fe 00       	mov    BYTE PTR [bp-0x112],0x0
    1ad5:	c7 86 f2 fe 02 00    	mov    WORD PTR [bp-0x10e],0x2
    1adb:	c7 86 f4 fe 00 00    	mov    WORD PTR [bp-0x10c],0x0
    1ae1:	c6 86 f6 fe 00       	mov    BYTE PTR [bp-0x10a],0x0
    1ae6:	8d be ea fe          	lea    di,[bp-0x116]
    1aea:	16                   	push   ss
    1aeb:	57                   	push   di
    1aec:	6a 01                	push   0x1
    1aee:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    1af2:	06                   	push   es
    1af3:	57                   	push   di
    1af4:	9a 95 28 10 24       	call   0x2410:0x2895
    1af9:	08 c0                	or     al,al
    1afb:	75 0a                	jne    0x1b07
    1afd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b00:	06                   	push   es
    1b01:	57                   	push   di
    1b02:	9a 53 0f 32 1b       	call   0x1b32:0xf53
    1b07:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1b0b:	83 c4 06             	add    sp,0x6
    1b0e:	eb 1a                	jmp    0x1b2a
    1b10:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    1b14:	89 96 fc fe          	mov    WORD PTR [bp-0x104],dx
    1b18:	ff b6 fc fe          	push   WORD PTR [bp-0x104]
    1b1c:	ff b6 fa fe          	push   WORD PTR [bp-0x106]
    1b20:	9a 2d 34 02 46       	call   0x4602:0x342d
    1b25:	9a 34 14 47 1b       	call   0x1b47:0x1434
    1b2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b2d:	06                   	push   es
    1b2e:	57                   	push   di
    1b2f:	9a 4b 17 3c 1b       	call   0x1b3c:0x174b
    1b34:	c9                   	leave
    1b35:	ca 04 00             	retf   0x4
    1b38:	00 00                	add    BYTE PTR [bx+si],al
    1b3a:	72 1c                	jb     0x1b58
    1b3c:	97                   	xchg   di,ax
    1b3d:	1b 55 89             	sbb    dx,WORD PTR [di-0x77]
    1b40:	e5 b8                	in     ax,0xb8
    1b42:	0a 00                	or     al,BYTE PTR [bx+si]
    1b44:	9a 44 04 90 1c       	call   0x1c90:0x444
    1b49:	83 ec 0a             	sub    sp,0xa
    1b4c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1b50:	06                   	push   es
    1b51:	57                   	push   di
    1b52:	9a 03 73 9e 1b       	call   0x1b9e:0x7303
    1b57:	c6 46 fb 00          	mov    BYTE PTR [bp-0x5],0x0
    1b5b:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    1b5f:	7e 1e                	jle    0x1b7f
    1b61:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    1b65:	75 14                	jne    0x1b7b
    1b67:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1b6b:	26 80 bd b4 01 00    	cmp    BYTE PTR es:[di+0x1b4],0x0
    1b71:	b0 00                	mov    al,0x0
    1b73:	75 01                	jne    0x1b76
    1b75:	40                   	inc    ax
    1b76:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    1b79:	eb 04                	jmp    0x1b7f
    1b7b:	c6 46 fb 01          	mov    BYTE PTR [bp-0x5],0x1
    1b7f:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    1b83:	75 03                	jne    0x1b88
    1b85:	e9 f5 00             	jmp    0x1c7d
    1b88:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1b8c:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1b90:	b0 01                	mov    al,0x1
    1b92:	50                   	push   ax
    1b93:	b8 22 00             	mov    ax,0x22
    1b96:	ba ca 1b             	mov    dx,0x1bca
    1b99:	52                   	push   dx
    1b9a:	50                   	push   ax
    1b9b:	9a 53 25 f4 1b       	call   0x1bf4:0x2553
    1ba0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1ba3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1ba6:	b8 38 1b             	mov    ax,0x1b38
    1ba9:	0e                   	push   cs
    1baa:	50                   	push   ax
    1bab:	55                   	push   bp
    1bac:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1bb0:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1bb4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1bb7:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1bba:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1bbd:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1bc0:	26 89 85 22 05       	mov    WORD PTR es:[di+0x522],ax
    1bc5:	06                   	push   es
    1bc6:	57                   	push   di
    1bc7:	9a 83 18 d7 1b       	call   0x1bd7:0x1883
    1bcc:	ff 76 08             	push   WORD PTR [bp+0x8]
    1bcf:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1bd2:	06                   	push   es
    1bd3:	57                   	push   di
    1bd4:	9a d3 17 2e 1c       	call   0x1c2e:0x17d3
    1bd9:	68 ff 00             	push   0xff
    1bdc:	6a ff                	push   0xffff
    1bde:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1be1:	06                   	push   es
    1be2:	57                   	push   di
    1be3:	9a d5 1e 16 1c       	call   0x1c16:0x1ed5
    1be8:	6a 00                	push   0x0
    1bea:	6a 00                	push   0x0
    1bec:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1bef:	06                   	push   es
    1bf0:	57                   	push   di
    1bf1:	9a b2 36 00 1c       	call   0x1c00:0x36b2
    1bf6:	6a 02                	push   0x2
    1bf8:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1bfb:	06                   	push   es
    1bfc:	57                   	push   di
    1bfd:	9a 14 3a 0c 1c       	call   0x1c0c:0x3a14
    1c02:	6a 01                	push   0x1
    1c04:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1c07:	06                   	push   es
    1c08:	57                   	push   di
    1c09:	9a e5 34 3b 1c       	call   0x1c3b:0x34e5
    1c0e:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1c11:	06                   	push   es
    1c12:	57                   	push   di
    1c13:	9a b9 62 f2 1c       	call   0x1cf2:0x62b9
    1c18:	50                   	push   ax
    1c19:	6a 04                	push   0x4
    1c1b:	9a ff ff 00 00       	call   0x0:0xffff
    1c20:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    1c24:	74 0c                	je     0x1c32
    1c26:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1c29:	06                   	push   es
    1c2a:	57                   	push   di
    1c2b:	9a 7b 29 85 1c       	call   0x1c85:0x297b
    1c30:	eb 34                	jmp    0x1c66
    1c32:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1c36:	06                   	push   es
    1c37:	57                   	push   di
    1c38:	9a 03 73 64 1c       	call   0x1c64:0x7303
    1c3d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c40:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1c43:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1c46:	26 ff b5 7e 01       	push   WORD PTR es:[di+0x17e]
    1c4b:	26 ff b5 7c 01       	push   WORD PTR es:[di+0x17c]
    1c50:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1c54:	06                   	push   es
    1c55:	57                   	push   di
    1c56:	9a 1a 31 70 1d       	call   0x1d70:0x311a
    1c5b:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1c5f:	06                   	push   es
    1c60:	57                   	push   di
    1c61:	9a 03 73 7a 1c       	call   0x1c7a:0x7303
    1c66:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1c6a:	83 c4 06             	add    sp,0x6
    1c6d:	b8 7d 1c             	mov    ax,0x1c7d
    1c70:	0e                   	push   cs
    1c71:	50                   	push   ax
    1c72:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1c75:	06                   	push   es
    1c76:	57                   	push   di
    1c77:	9a 1d 5f ab 1c       	call   0x1cab:0x5f1d
    1c7c:	cb                   	retf
    1c7d:	c9                   	leave
    1c7e:	ca 04 00             	retf   0x4
    1c81:	00 00                	add    BYTE PTR [bx+si],al
    1c83:	16                   	push   ss
    1c84:	1d a4 1c             	sbb    ax,0x1ca4
    1c87:	55                   	push   bp
    1c88:	89 e5                	mov    bp,sp
    1c8a:	b8 08 00             	mov    ax,0x8
    1c8d:	9a 44 04 2d 1d       	call   0x1d2d:0x444
    1c92:	83 ec 08             	sub    sp,0x8
    1c95:	ff 36 2c 2c          	push   WORD PTR ds:0x2c2c
    1c99:	ff 36 2a 2c          	push   WORD PTR ds:0x2c2a
    1c9d:	b0 01                	mov    al,0x1
    1c9f:	50                   	push   ax
    1ca0:	b8 22 00             	mov    ax,0x22
    1ca3:	ba d7 1c             	mov    dx,0x1cd7
    1ca6:	52                   	push   dx
    1ca7:	50                   	push   ax
    1ca8:	9a 53 25 fe 1c       	call   0x1cfe:0x2553
    1cad:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1cb0:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1cb3:	b8 81 1c             	mov    ax,0x1c81
    1cb6:	0e                   	push   cs
    1cb7:	50                   	push   ax
    1cb8:	55                   	push   bp
    1cb9:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1cbd:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1cc1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1cc4:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1cc7:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1cca:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1ccd:	26 89 85 22 05       	mov    WORD PTR es:[di+0x522],ax
    1cd2:	06                   	push   es
    1cd3:	57                   	push   di
    1cd4:	9a 83 18 e4 1c       	call   0x1ce4:0x1883
    1cd9:	ff 76 06             	push   WORD PTR [bp+0x6]
    1cdc:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1cdf:	06                   	push   es
    1ce0:	57                   	push   di
    1ce1:	9a d3 17 3c 1d       	call   0x1d3c:0x17d3
    1ce6:	6a ff                	push   0xffff
    1ce8:	6a f0                	push   0xfff0
    1cea:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ced:	06                   	push   es
    1cee:	57                   	push   di
    1cef:	9a d5 1e 2a 1f       	call   0x1f2a:0x1ed5
    1cf4:	6a 02                	push   0x2
    1cf6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1cf9:	06                   	push   es
    1cfa:	57                   	push   di
    1cfb:	9a 14 3a 08 1d       	call   0x1d08:0x3a14
    1d00:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1d03:	06                   	push   es
    1d04:	57                   	push   di
    1d05:	9a 45 5d 1e 1d       	call   0x1d1e:0x5d45
    1d0a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1d0e:	83 c4 06             	add    sp,0x6
    1d11:	b8 21 1d             	mov    ax,0x1d21
    1d14:	0e                   	push   cs
    1d15:	50                   	push   ax
    1d16:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1d19:	06                   	push   es
    1d1a:	57                   	push   di
    1d1b:	9a 1d 5f 77 1d       	call   0x1d77:0x5f1d
    1d20:	cb                   	retf
    1d21:	c9                   	leave
    1d22:	ca 02 00             	retf   0x2
    1d25:	55                   	push   bp
    1d26:	89 e5                	mov    bp,sp
    1d28:	31 c0                	xor    ax,ax
    1d2a:	9a 44 04 4b 1d       	call   0x1d4b:0x444
    1d2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d32:	26 ff b5 24 05       	push   WORD PTR es:[di+0x524]
    1d37:	6a 00                	push   0x0
    1d39:	9a 3e 1b 9c 1d       	call   0x1d9c:0x1b3e
    1d3e:	c9                   	leave
    1d3f:	ca 08 00             	retf   0x8
    1d42:	55                   	push   bp
    1d43:	89 e5                	mov    bp,sp
    1d45:	b8 04 00             	mov    ax,0x4
    1d48:	9a 44 04 d2 1d       	call   0x1dd2:0x444
    1d4d:	83 ec 04             	sub    sp,0x4
    1d50:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d53:	26 c4 bd 04 04       	les    di,DWORD PTR es:[di+0x404]
    1d58:	06                   	push   es
    1d59:	57                   	push   di
    1d5a:	9a 17 2f 03 29       	call   0x2903:0x2f17
    1d5f:	08 c0                	or     al,al
    1d61:	74 63                	je     0x1dc6
    1d63:	ff 76 08             	push   WORD PTR [bp+0x8]
    1d66:	ff 76 06             	push   WORD PTR [bp+0x6]
    1d69:	b0 01                	mov    al,0x1
    1d6b:	50                   	push   ax
    1d6c:	b8 b4 25             	mov    ax,0x25b4
    1d6f:	ba 91 1d             	mov    dx,0x1d91
    1d72:	52                   	push   dx
    1d73:	50                   	push   ax
    1d74:	9a 53 25 ba 1d       	call   0x1dba:0x2553
    1d79:	a3 04 20             	mov    ds:0x2004,ax
    1d7c:	89 16 06 20          	mov    WORD PTR ds:0x2006,dx
    1d80:	c4 3e 04 20          	les    di,DWORD PTR ds:0x2004
    1d84:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1d87:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1d8a:	6a 01                	push   0x1
    1d8c:	06                   	push   es
    1d8d:	57                   	push   di
    1d8e:	9a 8d 2f ff ff       	call   0xffff:0x2f8d
    1d93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d96:	06                   	push   es
    1d97:	57                   	push   di
    1d98:	b8 25 1d             	mov    ax,0x1d25
    1d9b:	ba 72 1f             	mov    dx,0x1f72
    1d9e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1da1:	26 89 85 b9 02       	mov    WORD PTR es:[di+0x2b9],ax
    1da6:	26 89 95 bb 02       	mov    WORD PTR es:[di+0x2bb],dx
    1dab:	26 8f 85 bd 02       	pop    WORD PTR es:[di+0x2bd]
    1db0:	26 8f 85 bf 02       	pop    WORD PTR es:[di+0x2bf]
    1db5:	06                   	push   es
    1db6:	57                   	push   di
    1db7:	9a 45 5d c4 1d       	call   0x1dc4:0x5d45
    1dbc:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1dbf:	06                   	push   es
    1dc0:	57                   	push   di
    1dc1:	9a 1d 5f dc 1d       	call   0x1ddc:0x5f1d
    1dc6:	c9                   	leave
    1dc7:	ca 08 00             	retf   0x8
    1dca:	55                   	push   bp
    1dcb:	89 e5                	mov    bp,sp
    1dcd:	31 c0                	xor    ax,ax
    1dcf:	9a 44 04 ea 1d       	call   0x1dea:0x444
    1dd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dd7:	06                   	push   es
    1dd8:	57                   	push   di
    1dd9:	9a 56 55 fe 1d       	call   0x1dfe:0x5556
    1dde:	c9                   	leave
    1ddf:	ca 08 00             	retf   0x8
    1de2:	55                   	push   bp
    1de3:	89 e5                	mov    bp,sp
    1de5:	31 c0                	xor    ax,ax
    1de7:	9a 44 04 27 1e       	call   0x1e27:0x444
    1dec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1def:	26 80 bd ee 00 02    	cmp    BYTE PTR es:[di+0xee],0x2
    1df5:	75 0b                	jne    0x1e02
    1df7:	6a 00                	push   0x0
    1df9:	06                   	push   es
    1dfa:	57                   	push   di
    1dfb:	9a 14 3a 0c 1e       	call   0x1e0c:0x3a14
    1e00:	eb 0c                	jmp    0x1e0e
    1e02:	6a 02                	push   0x2
    1e04:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e07:	06                   	push   es
    1e08:	57                   	push   di
    1e09:	9a 14 3a ec 20       	call   0x20ec:0x3a14
    1e0e:	c9                   	leave
    1e0f:	ca 08 00             	retf   0x8
    1e12:	89 1e 90 1e          	mov    WORD PTR ds:0x1e90,bx
    1e16:	97                   	xchg   di,ax
    1e17:	1e                   	push   ds
    1e18:	9e                   	sahf
    1e19:	1e                   	push   ds
    1e1a:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    1e1b:	1e                   	push   ds
    1e1c:	ac                   	lods   al,BYTE PTR ds:[si]
    1e1d:	1e                   	push   ds
    1e1e:	55                   	push   bp
    1e1f:	89 e5                	mov    bp,sp
    1e21:	b8 0e 00             	mov    ax,0xe
    1e24:	9a 44 04 48 1e       	call   0x1e48:0x444
    1e29:	83 ec 0e             	sub    sp,0xe
    1e2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e2f:	26 8b 85 20 05       	mov    ax,WORD PTR es:[di+0x520]
    1e34:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e37:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e3a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e3d:	bf 94 00             	mov    di,0x94
    1e40:	b8 5b 1e             	mov    ax,0x1e5b
    1e43:	50                   	push   ax
    1e44:	57                   	push   di
    1e45:	9a 55 22 62 1e       	call   0x1e62:0x2255
    1e4a:	08 c0                	or     al,al
    1e4c:	75 03                	jne    0x1e51
    1e4e:	e9 bf 00             	jmp    0x1f10
    1e51:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1e54:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1e57:	bf 94 00             	mov    di,0x94
    1e5a:	b8 73 1e             	mov    ax,0x1e73
    1e5d:	50                   	push   ax
    1e5e:	57                   	push   di
    1e5f:	9a 73 22 d0 1e       	call   0x1ed0:0x2273
    1e64:	52                   	push   dx
    1e65:	50                   	push   ax
    1e66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e69:	26 c4 bd c8 03       	les    di,DWORD PTR es:[di+0x3c8]
    1e6e:	06                   	push   es
    1e6f:	57                   	push   di
    1e70:	9a 2b 16 c6 1e       	call   0x1ec6:0x162b
    1e75:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1e78:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1e7b:	3d 05 00             	cmp    ax,0x5
    1e7e:	77 33                	ja     0x1eb3
    1e80:	89 c3                	mov    bx,ax
    1e82:	d1 e3                	shl    bx,1
    1e84:	2e ff a7 12 1e       	jmp    WORD PTR cs:[bx+0x1e12]
    1e89:	c7 46 fe 64 00       	mov    WORD PTR [bp-0x2],0x64
    1e8e:	eb 23                	jmp    0x1eb3
    1e90:	c7 46 fe 7d 00       	mov    WORD PTR [bp-0x2],0x7d
    1e95:	eb 1c                	jmp    0x1eb3
    1e97:	c7 46 fe 96 00       	mov    WORD PTR [bp-0x2],0x96
    1e9c:	eb 15                	jmp    0x1eb3
    1e9e:	c7 46 fe c8 00       	mov    WORD PTR [bp-0x2],0xc8
    1ea3:	eb 0e                	jmp    0x1eb3
    1ea5:	c7 46 fe 4b 00       	mov    WORD PTR [bp-0x2],0x4b
    1eaa:	eb 07                	jmp    0x1eb3
    1eac:	c7 46 fe 32 00       	mov    WORD PTR [bp-0x2],0x32
    1eb1:	eb 00                	jmp    0x1eb3
    1eb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb6:	26 c4 bd c8 03       	les    di,DWORD PTR es:[di+0x3c8]
    1ebb:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1ebe:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1ec1:	06                   	push   es
    1ec2:	57                   	push   di
    1ec3:	9a 26 13 fb 1e       	call   0x1efb:0x1326
    1ec8:	2d 01 00             	sub    ax,0x1
    1ecb:	71 05                	jno    0x1ed2
    1ecd:	9a 3e 04 44 1f       	call   0x1f44:0x43e
    1ed2:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1ed5:	31 c0                	xor    ax,ax
    1ed7:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1eda:	7f 34                	jg     0x1f10
    1edc:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1edf:	eb 03                	jmp    0x1ee4
    1ee1:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    1ee4:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1ee7:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1eea:	b0 00                	mov    al,0x0
    1eec:	75 01                	jne    0x1eef
    1eee:	40                   	inc    ax
    1eef:	50                   	push   ax
    1ef0:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1ef3:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1ef6:	06                   	push   es
    1ef7:	57                   	push   di
    1ef8:	9a 53 13 06 1f       	call   0x1f06:0x1353
    1efd:	89 c7                	mov    di,ax
    1eff:	8e c2                	mov    es,dx
    1f01:	06                   	push   es
    1f02:	57                   	push   di
    1f03:	9a 75 12 90 1f       	call   0x1f90:0x1275
    1f08:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1f0b:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1f0e:	75 d1                	jne    0x1ee1
    1f10:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f16:	26 3b 85 20 05       	cmp    ax,WORD PTR es:[di+0x520]
    1f1b:	74 1a                	je     0x1f37
    1f1d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f20:	26 ff b5 20 05       	push   WORD PTR es:[di+0x520]
    1f25:	06                   	push   es
    1f26:	57                   	push   di
    1f27:	9a f4 5d 48 21       	call   0x2148:0x5df4
    1f2c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f32:	26 89 85 20 05       	mov    WORD PTR es:[di+0x520],ax
    1f37:	c9                   	leave
    1f38:	ca 08 00             	retf   0x8
    1f3b:	55                   	push   bp
    1f3c:	89 e5                	mov    bp,sp
    1f3e:	b8 02 00             	mov    ax,0x2
    1f41:	9a 44 04 81 1f       	call   0x1f81:0x444
    1f46:	83 ec 02             	sub    sp,0x2
    1f49:	ff 36 4c 01          	push   WORD PTR ds:0x14c
    1f4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f50:	26 ff b5 24 05       	push   WORD PTR es:[di+0x524]
    1f55:	9a 32 3e 57 20       	call   0x2057:0x3e32
    1f5a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f5d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f63:	26 3b 85 24 05       	cmp    ax,WORD PTR es:[di+0x524]
    1f68:	74 0a                	je     0x1f74
    1f6a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1f6d:	06                   	push   es
    1f6e:	57                   	push   di
    1f6f:	9a d3 17 7a 20       	call   0x207a:0x17d3
    1f74:	c9                   	leave
    1f75:	ca 08 00             	retf   0x8
    1f78:	55                   	push   bp
    1f79:	89 e5                	mov    bp,sp
    1f7b:	b8 08 00             	mov    ax,0x8
    1f7e:	9a 44 04 97 1f       	call   0x1f97:0x444
    1f83:	83 ec 08             	sub    sp,0x8
    1f86:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f89:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f8c:	bf 94 00             	mov    di,0x94
    1f8f:	b8 aa 1f             	mov    ax,0x1faa
    1f92:	50                   	push   ax
    1f93:	57                   	push   di
    1f94:	9a 55 22 b1 1f       	call   0x1fb1:0x2255
    1f99:	08 c0                	or     al,al
    1f9b:	75 03                	jne    0x1fa0
    1f9d:	e9 dc 00             	jmp    0x207c
    1fa0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1fa3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1fa6:	bf 94 00             	mov    di,0x94
    1fa9:	b8 cc 1f             	mov    ax,0x1fcc
    1fac:	50                   	push   ax
    1fad:	57                   	push   di
    1fae:	9a 73 22 d3 1f       	call   0x1fd3:0x2273
    1fb3:	89 c7                	mov    di,ax
    1fb5:	8e c2                	mov    es,dx
    1fb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fba:	26 8b 85 24 05       	mov    ax,WORD PTR es:[di+0x524]
    1fbf:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1fc2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1fc5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1fc8:	bf 94 00             	mov    di,0x94
    1fcb:	b8 e4 1f             	mov    ax,0x1fe4
    1fce:	50                   	push   ax
    1fcf:	57                   	push   di
    1fd0:	9a 73 22 f9 1f       	call   0x1ff9:0x2273
    1fd5:	52                   	push   dx
    1fd6:	50                   	push   ax
    1fd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fda:	26 c4 bd c8 04       	les    di,DWORD PTR es:[di+0x4c8]
    1fdf:	06                   	push   es
    1fe0:	57                   	push   di
    1fe1:	9a 2b 16 ff ff       	call   0xffff:0x162b
    1fe6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1fe9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fec:	26 8b 85 22 05       	mov    ax,WORD PTR es:[di+0x522]
    1ff1:	05 01 00             	add    ax,0x1
    1ff4:	71 05                	jno    0x1ffb
    1ff6:	9a 3e 04 08 20       	call   0x2008:0x43e
    1ffb:	8b d0                	mov    dx,ax
    1ffd:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2000:	05 01 00             	add    ax,0x1
    2003:	71 05                	jno    0x200a
    2005:	9a 3e 04 3a 20       	call   0x203a:0x43e
    200a:	3b c2                	cmp    ax,dx
    200c:	b0 00                	mov    al,0x0
    200e:	7d 01                	jge    0x2011
    2010:	40                   	inc    ax
    2011:	8a c8                	mov    cl,al
    2013:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    2017:	b0 00                	mov    al,0x0
    2019:	7d 01                	jge    0x201c
    201b:	40                   	inc    ax
    201c:	8a d0                	mov    dl,al
    201e:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    2022:	b0 00                	mov    al,0x0
    2024:	7c 01                	jl     0x2027
    2026:	40                   	inc    ax
    2027:	22 c2                	and    al,dl
    2029:	22 c1                	and    al,cl
    202b:	08 c0                	or     al,al
    202d:	74 12                	je     0x2041
    202f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2032:	05 01 00             	add    ax,0x1
    2035:	71 05                	jno    0x203c
    2037:	9a 3e 04 a1 20       	call   0x20a1:0x43e
    203c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    203f:	eb 24                	jmp    0x2065
    2041:	83 7e fc 14          	cmp    WORD PTR [bp-0x4],0x14
    2045:	75 17                	jne    0x205e
    2047:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    204a:	26 ff b5 22 05       	push   WORD PTR es:[di+0x522]
    204f:	26 ff b5 24 05       	push   WORD PTR es:[di+0x524]
    2054:	9a 32 3e ff ff       	call   0xffff:0x3e32
    2059:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    205c:	eb 07                	jmp    0x2065
    205e:	6a 30                	push   0x30
    2060:	9a ff ff 00 00       	call   0x0:0xffff
    2065:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2068:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    206b:	26 3b 85 24 05       	cmp    ax,WORD PTR es:[di+0x524]
    2070:	74 0a                	je     0x207c
    2072:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2075:	06                   	push   es
    2076:	57                   	push   di
    2077:	9a d3 17 2c 28       	call   0x282c:0x17d3
    207c:	c9                   	leave
    207d:	ca 08 00             	retf   0x8
    2080:	65 21 40 21          	and    WORD PTR gs:[bx+si+0x21],ax
    2084:	f1                   	int1
    2085:	20 e2                	and    dl,ah
    2087:	20 8e 21 21          	and    BYTE PTR [bp+0x2121],cl
    208b:	21 8e 21 02          	and    WORD PTR [bp+0x221],cx
    208f:	21 00                	and    WORD PTR [bx+si],ax
    2091:	00 00                	add    BYTE PTR [bx+si],al
    2093:	00 ff                	add    bh,bh
    2095:	00 00                	add    BYTE PTR [bx+si],al
    2097:	00 55 89             	add    BYTE PTR [di-0x77],dl
    209a:	e5 b8                	in     ax,0xb8
    209c:	04 00                	add    al,0x0
    209e:	9a 44 04 12 21       	call   0x2112:0x444
    20a3:	83 ec 04             	sub    sp,0x4
    20a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a9:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    20ae:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    20b1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    20b4:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    20b8:	b0 00                	mov    al,0x0
    20ba:	74 01                	je     0x20bd
    20bc:	40                   	inc    ax
    20bd:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    20c1:	08 c0                	or     al,al
    20c3:	75 03                	jne    0x20c8
    20c5:	e9 ee 00             	jmp    0x21b6
    20c8:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    20cb:	26 8b 05             	mov    ax,WORD PTR es:[di]
    20ce:	2d 21 00             	sub    ax,0x21
    20d1:	3d 07 00             	cmp    ax,0x7
    20d4:	76 03                	jbe    0x20d9
    20d6:	e9 b5 00             	jmp    0x218e
    20d9:	89 c3                	mov    bx,ax
    20db:	d1 e3                	shl    bx,1
    20dd:	2e ff a7 80 20       	jmp    WORD PTR cs:[bx+0x2080]
    20e2:	6a 00                	push   0x0
    20e4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    20e7:	06                   	push   es
    20e8:	57                   	push   di
    20e9:	9a d0 1c fd 20       	call   0x20fd:0x1cd0
    20ee:	e9 9d 00             	jmp    0x218e
    20f1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    20f4:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    20f8:	06                   	push   es
    20f9:	57                   	push   di
    20fa:	9a d0 1c 1d 21       	call   0x211d:0x1cd0
    20ff:	e9 8c 00             	jmp    0x218e
    2102:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2105:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2109:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    210d:	71 05                	jno    0x2114
    210f:	9a 3e 04 31 21       	call   0x2131:0x43e
    2114:	50                   	push   ax
    2115:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2118:	06                   	push   es
    2119:	57                   	push   di
    211a:	9a d0 1c 3c 21       	call   0x213c:0x1cd0
    211f:	eb 6d                	jmp    0x218e
    2121:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2124:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2128:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    212c:	71 05                	jno    0x2133
    212e:	9a 3e 04 56 21       	call   0x2156:0x43e
    2133:	50                   	push   ax
    2134:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2137:	06                   	push   es
    2138:	57                   	push   di
    2139:	9a d0 1c 61 21       	call   0x2161:0x1cd0
    213e:	eb 4e                	jmp    0x218e
    2140:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2143:	06                   	push   es
    2144:	57                   	push   di
    2145:	9a f4 18 6d 21       	call   0x216d:0x18f4
    214a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    214d:	26 03 45 0a          	add    ax,WORD PTR es:[di+0xa]
    2151:	71 05                	jno    0x2158
    2153:	9a 3e 04 7f 21       	call   0x217f:0x43e
    2158:	50                   	push   ax
    2159:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    215c:	06                   	push   es
    215d:	57                   	push   di
    215e:	9a d0 1c 8a 21       	call   0x218a:0x1cd0
    2163:	eb 29                	jmp    0x218e
    2165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2168:	06                   	push   es
    2169:	57                   	push   di
    216a:	9a f4 18 ab 22       	call   0x22ab:0x18f4
    216f:	8b d0                	mov    dx,ax
    2171:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2174:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    2178:	2b c2                	sub    ax,dx
    217a:	71 05                	jno    0x2181
    217c:	9a 3e 04 9c 21       	call   0x219c:0x43e
    2181:	50                   	push   ax
    2182:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2185:	06                   	push   es
    2186:	57                   	push   di
    2187:	9a d0 1c fb 21       	call   0x21fb:0x1cd0
    218c:	eb 00                	jmp    0x218e
    218e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2191:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2194:	31 d2                	xor    dx,dx
    2196:	bf 90 20             	mov    di,0x2090
    2199:	9a 16 04 f0 21       	call   0x21f0:0x416
    219e:	3c 21                	cmp    al,0x21
    21a0:	72 14                	jb     0x21b6
    21a2:	3c 24                	cmp    al,0x24
    21a4:	76 08                	jbe    0x21ae
    21a6:	3c 26                	cmp    al,0x26
    21a8:	74 04                	je     0x21ae
    21aa:	3c 28                	cmp    al,0x28
    21ac:	75 08                	jne    0x21b6
    21ae:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    21b1:	31 c0                	xor    ax,ax
    21b3:	26 89 05             	mov    WORD PTR es:[di],ax
    21b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b9:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    21be:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    21c1:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    21c4:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    21c8:	b0 00                	mov    al,0x0
    21ca:	74 01                	je     0x21cd
    21cc:	40                   	inc    ax
    21cd:	26 22 45 13          	and    al,BYTE PTR es:[di+0x13]
    21d1:	08 c0                	or     al,al
    21d3:	74 6e                	je     0x2243
    21d5:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    21d8:	26 8b 05             	mov    ax,WORD PTR es:[di]
    21db:	3d 27 00             	cmp    ax,0x27
    21de:	75 1f                	jne    0x21ff
    21e0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21e3:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    21e7:	26 03 45 08          	add    ax,WORD PTR es:[di+0x8]
    21eb:	71 05                	jno    0x21f2
    21ed:	9a 3e 04 14 22       	call   0x2214:0x43e
    21f2:	50                   	push   ax
    21f3:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21f6:	06                   	push   es
    21f7:	57                   	push   di
    21f8:	9a d0 1c 1f 22       	call   0x221f:0x1cd0
    21fd:	eb 24                	jmp    0x2223
    21ff:	3d 25 00             	cmp    ax,0x25
    2202:	75 1f                	jne    0x2223
    2204:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2207:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    220b:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    220f:	71 05                	jno    0x2216
    2211:	9a 3e 04 31 22       	call   0x2231:0x43e
    2216:	50                   	push   ax
    2217:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    221a:	06                   	push   es
    221b:	57                   	push   di
    221c:	9a d0 1c 5e 22       	call   0x225e:0x1cd0
    2221:	eb 00                	jmp    0x2223
    2223:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2226:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2229:	31 d2                	xor    dx,dx
    222b:	bf 90 20             	mov    di,0x2090
    222e:	9a 16 04 6c 22       	call   0x226c:0x416
    2233:	3c 25                	cmp    al,0x25
    2235:	74 04                	je     0x223b
    2237:	3c 27                	cmp    al,0x27
    2239:	75 08                	jne    0x2243
    223b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    223e:	31 c0                	xor    ax,ax
    2240:	26 89 05             	mov    WORD PTR es:[di],ax
    2243:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2246:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    224a:	74 14                	je     0x2260
    224c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    224f:	26 ff b5 e6 00       	push   WORD PTR es:[di+0xe6]
    2254:	26 ff b5 e4 00       	push   WORD PTR es:[di+0xe4]
    2259:	06                   	push   es
    225a:	57                   	push   di
    225b:	9a 30 22 77 23       	call   0x2377:0x2230
    2260:	c9                   	leave
    2261:	ca 0e 00             	retf   0xe
    2264:	55                   	push   bp
    2265:	89 e5                	mov    bp,sp
    2267:	31 c0                	xor    ax,ax
    2269:	9a 44 04 7f 22       	call   0x227f:0x444
    226e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2271:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2274:	bf a2 0b             	mov    di,0xba2
    2277:	b8 8c 22             	mov    ax,0x228c
    227a:	50                   	push   ax
    227b:	57                   	push   di
    227c:	9a 55 22 93 22       	call   0x2293:0x2255
    2281:	50                   	push   ax
    2282:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2285:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2288:	bf 22 00             	mov    di,0x22
    228b:	b8 ce 22             	mov    ax,0x22ce
    228e:	50                   	push   ax
    228f:	57                   	push   di
    2290:	9a 55 22 b9 22       	call   0x22b9:0x2255
    2295:	5a                   	pop    dx
    2296:	0a c2                	or     al,dl
    2298:	08 c0                	or     al,al
    229a:	74 11                	je     0x22ad
    229c:	6a 00                	push   0x0
    229e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a1:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    22a6:	06                   	push   es
    22a7:	57                   	push   di
    22a8:	9a 77 1c 01 23       	call   0x2301:0x1c77
    22ad:	c9                   	leave
    22ae:	ca 08 00             	retf   0x8
    22b1:	55                   	push   bp
    22b2:	89 e5                	mov    bp,sp
    22b4:	31 c0                	xor    ax,ax
    22b6:	9a 44 04 d5 22       	call   0x22d5:0x444
    22bb:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    22be:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    22c2:	75 3f                	jne    0x2303
    22c4:	ff 76 12             	push   WORD PTR [bp+0x12]
    22c7:	ff 76 10             	push   WORD PTR [bp+0x10]
    22ca:	bf a2 0b             	mov    di,0xba2
    22cd:	b8 e2 22             	mov    ax,0x22e2
    22d0:	50                   	push   ax
    22d1:	57                   	push   di
    22d2:	9a 55 22 e9 22       	call   0x22e9:0x2255
    22d7:	50                   	push   ax
    22d8:	ff 76 12             	push   WORD PTR [bp+0x12]
    22db:	ff 76 10             	push   WORD PTR [bp+0x10]
    22de:	bf 22 00             	mov    di,0x22
    22e1:	b8 a6 23             	mov    ax,0x23a6
    22e4:	50                   	push   ax
    22e5:	57                   	push   di
    22e6:	9a 55 22 1d 23       	call   0x231d:0x2255
    22eb:	5a                   	pop    dx
    22ec:	0a c2                	or     al,dl
    22ee:	08 c0                	or     al,al
    22f0:	74 11                	je     0x2303
    22f2:	6a 00                	push   0x0
    22f4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22f7:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    22fc:	06                   	push   es
    22fd:	57                   	push   di
    22fe:	9a 77 1c 36 23       	call   0x2336:0x1c77
    2303:	c9                   	leave
    2304:	ca 0e 00             	retf   0xe
    2307:	0a 23                	or     ah,BYTE PTR [bp+di]
    2309:	2c 23                	sub    al,0x23
    230b:	23 30                	and    si,WORD PTR [bx+si]
    230d:	2e 30 30             	xor    BYTE PTR cs:[bx+si],dh
    2310:	23 23                	and    sp,WORD PTR [bp+di]
    2312:	01 20                	add    WORD PTR [bx+si],sp
    2314:	55                   	push   bp
    2315:	89 e5                	mov    bp,sp
    2317:	b8 10 02             	mov    ax,0x210
    231a:	9a 44 04 3d 23       	call   0x233d:0x444
    231f:	81 ec 10 02          	sub    sp,0x210
    2323:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2326:	26 83 3d 70          	cmp    WORD PTR es:[di],0x70
    232a:	75 4d                	jne    0x2379
    232c:	ff 76 12             	push   WORD PTR [bp+0x12]
    232f:	ff 76 10             	push   WORD PTR [bp+0x10]
    2332:	bf c1 05             	mov    di,0x5c1
    2335:	b8 57 23             	mov    ax,0x2357
    2338:	50                   	push   ax
    2339:	57                   	push   di
    233a:	9a 55 22 5e 23       	call   0x235e:0x2255
    233f:	08 c0                	or     al,al
    2341:	74 36                	je     0x2379
    2343:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2346:	31 c0                	xor    ax,ax
    2348:	26 89 05             	mov    WORD PTR es:[di],ax
    234b:	6a 08                	push   0x8
    234d:	ff 76 12             	push   WORD PTR [bp+0x12]
    2350:	ff 76 10             	push   WORD PTR [bp+0x10]
    2353:	bf c1 05             	mov    di,0x5c1
    2356:	b8 d8 24             	mov    ax,0x24d8
    2359:	50                   	push   ax
    235a:	57                   	push   di
    235b:	9a 73 22 ad 23       	call   0x23ad:0x2273
    2360:	89 c7                	mov    di,ax
    2362:	8e c2                	mov    es,dx
    2364:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    2369:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    236e:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2372:	06                   	push   es
    2373:	57                   	push   di
    2374:	9a b2 77 b5 25       	call   0x25b5:0x77b2
    2379:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    237c:	26 83 3d 11          	cmp    WORD PTR es:[di],0x11
    2380:	74 03                	je     0x2385
    2382:	e9 8a 03             	jmp    0x270f
    2385:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2388:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    238d:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2392:	74 03                	je     0x2397
    2394:	e9 78 03             	jmp    0x270f
    2397:	c6 86 f8 fe 00       	mov    BYTE PTR [bp-0x108],0x0
    239c:	ff 76 12             	push   WORD PTR [bp+0x12]
    239f:	ff 76 10             	push   WORD PTR [bp+0x10]
    23a2:	bf 22 00             	mov    di,0x22
    23a5:	b8 c0 23             	mov    ax,0x23c0
    23a8:	50                   	push   ax
    23a9:	57                   	push   di
    23aa:	9a 55 22 c7 23       	call   0x23c7:0x2255
    23af:	08 c0                	or     al,al
    23b1:	75 03                	jne    0x23b6
    23b3:	e9 dd 00             	jmp    0x2493
    23b6:	ff 76 12             	push   WORD PTR [bp+0x12]
    23b9:	ff 76 10             	push   WORD PTR [bp+0x10]
    23bc:	bf 22 00             	mov    di,0x22
    23bf:	b8 e4 23             	mov    ax,0x23e4
    23c2:	50                   	push   ax
    23c3:	57                   	push   di
    23c4:	9a 73 22 17 24       	call   0x2417:0x2273
    23c9:	89 c7                	mov    di,ax
    23cb:	8e c2                	mov    es,dx
    23cd:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    23d1:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    23d5:	8d be f4 fd          	lea    di,[bp-0x20c]
    23d9:	16                   	push   ss
    23da:	57                   	push   di
    23db:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    23df:	06                   	push   es
    23e0:	57                   	push   di
    23e1:	9a 9f 1a ef 23       	call   0x23ef:0x1a9f
    23e6:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    23ea:	06                   	push   es
    23eb:	57                   	push   di
    23ec:	9a 5f 1a 9d 24       	call   0x249d:0x1a5f
    23f1:	89 c7                	mov    di,ax
    23f3:	8e c2                	mov    es,dx
    23f5:	26 c4 7d 1a          	les    di,DWORD PTR es:[di+0x1a]
    23f9:	06                   	push   es
    23fa:	57                   	push   di
    23fb:	9a 9b 3b b3 45       	call   0x45b3:0x3b9b
    2400:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2403:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2406:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2409:	ff 76 f8             	push   WORD PTR [bp-0x8]
    240c:	bf 58 0a             	mov    di,0xa58
    240f:	b8 27 24             	mov    ax,0x2427
    2412:	50                   	push   ax
    2413:	57                   	push   di
    2414:	9a 55 22 2e 24       	call   0x242e:0x2255
    2419:	08 c0                	or     al,al
    241b:	74 57                	je     0x2474
    241d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2420:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2423:	bf 58 0a             	mov    di,0xa58
    2426:	b8 93 45             	mov    ax,0x4593
    2429:	50                   	push   ax
    242a:	57                   	push   di
    242b:	9a 73 22 70 24       	call   0x2470:0x2273
    2430:	89 c7                	mov    di,ax
    2432:	8e c2                	mov    es,dx
    2434:	89 be f0 fe          	mov    WORD PTR [bp-0x110],di
    2438:	8c 86 f2 fe          	mov    WORD PTR [bp-0x10e],es
    243c:	8d be f0 fd          	lea    di,[bp-0x210]
    2440:	16                   	push   ss
    2441:	57                   	push   di
    2442:	bf 07 23             	mov    di,0x2307
    2445:	0e                   	push   cs
    2446:	57                   	push   di
    2447:	c4 be f0 fe          	les    di,DWORD PTR [bp-0x110]
    244b:	06                   	push   es
    244c:	57                   	push   di
    244d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2450:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    2454:	83 ec 0a             	sub    sp,0xa
    2457:	89 e3                	mov    bx,sp
    2459:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    245d:	90                   	nop
    245e:	9b                   	fwait
    245f:	9a d4 10 ff ff       	call   0xffff:0x10d4
    2464:	8d be f8 fe          	lea    di,[bp-0x108]
    2468:	16                   	push   ss
    2469:	57                   	push   di
    246a:	68 ff 00             	push   0xff
    246d:	9a e7 17 91 24       	call   0x2491:0x17e7
    2472:	eb 1f                	jmp    0x2493
    2474:	8d be f4 fd          	lea    di,[bp-0x20c]
    2478:	16                   	push   ss
    2479:	57                   	push   di
    247a:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    247e:	06                   	push   es
    247f:	57                   	push   di
    2480:	9a 24 15 60 30       	call   0x3060:0x1524
    2485:	8d be f8 fe          	lea    di,[bp-0x108]
    2489:	16                   	push   ss
    248a:	57                   	push   di
    248b:	68 ff 00             	push   0xff
    248e:	9a e7 17 a4 24       	call   0x24a4:0x17e7
    2493:	ff 76 12             	push   WORD PTR [bp+0x12]
    2496:	ff 76 10             	push   WORD PTR [bp+0x10]
    2499:	bf a2 0b             	mov    di,0xba2
    249c:	b8 b4 24             	mov    ax,0x24b4
    249f:	50                   	push   ax
    24a0:	57                   	push   di
    24a1:	9a 55 22 bb 24       	call   0x24bb:0x2255
    24a6:	08 c0                	or     al,al
    24a8:	74 3e                	je     0x24e8
    24aa:	ff 76 12             	push   WORD PTR [bp+0x12]
    24ad:	ff 76 10             	push   WORD PTR [bp+0x10]
    24b0:	bf a2 0b             	mov    di,0xba2
    24b3:	b8 25 30             	mov    ax,0x3025
    24b6:	50                   	push   ax
    24b7:	57                   	push   di
    24b8:	9a 73 22 e6 24       	call   0x24e6:0x2273
    24bd:	89 c7                	mov    di,ax
    24bf:	8e c2                	mov    es,dx
    24c1:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    24c5:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    24c9:	8d be f4 fd          	lea    di,[bp-0x20c]
    24cd:	16                   	push   ss
    24ce:	57                   	push   di
    24cf:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    24d3:	06                   	push   es
    24d4:	57                   	push   di
    24d5:	9a 53 1d fc 24       	call   0x24fc:0x1d53
    24da:	8d be f8 fe          	lea    di,[bp-0x108]
    24de:	16                   	push   ss
    24df:	57                   	push   di
    24e0:	68 ff 00             	push   0xff
    24e3:	9a e7 17 03 25       	call   0x2503:0x17e7
    24e8:	80 be f8 fe 00       	cmp    BYTE PTR [bp-0x108],0x0
    24ed:	77 03                	ja     0x24f2
    24ef:	e9 1d 02             	jmp    0x270f
    24f2:	ff 76 12             	push   WORD PTR [bp+0x12]
    24f5:	ff 76 10             	push   WORD PTR [bp+0x10]
    24f8:	bf c1 05             	mov    di,0x5c1
    24fb:	b8 46 25             	mov    ax,0x2546
    24fe:	50                   	push   ax
    24ff:	57                   	push   di
    2500:	9a 73 22 1d 25       	call   0x251d:0x2273
    2505:	89 c7                	mov    di,ax
    2507:	8e c2                	mov    es,dx
    2509:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    250d:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2511:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    2515:	2d 04 00             	sub    ax,0x4
    2518:	71 05                	jno    0x251f
    251a:	9a 3e 04 32 25       	call   0x2532:0x43e
    251f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2522:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2526:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    252a:	2d 04 00             	sub    ax,0x4
    252d:	71 05                	jno    0x2534
    252f:	9a 3e 04 72 25       	call   0x2572:0x43e
    2534:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2537:	ff 76 fe             	push   WORD PTR [bp-0x2]
    253a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    253d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2541:	06                   	push   es
    2542:	57                   	push   di
    2543:	9a d4 19 5c 25       	call   0x255c:0x19d4
    2548:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    254b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    254e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2551:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2554:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2557:	06                   	push   es
    2558:	57                   	push   di
    2559:	9a 06 1a 96 25       	call   0x2596:0x1a06
    255e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2561:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2564:	8d be f8 fd          	lea    di,[bp-0x208]
    2568:	16                   	push   ss
    2569:	57                   	push   di
    256a:	bf 12 23             	mov    di,0x2312
    256d:	0e                   	push   cs
    256e:	57                   	push   di
    256f:	9a cd 17 7d 25       	call   0x257d:0x17cd
    2574:	8d be f8 fe          	lea    di,[bp-0x108]
    2578:	16                   	push   ss
    2579:	57                   	push   di
    257a:	9a 4c 18 87 25       	call   0x2587:0x184c
    257f:	bf 12 23             	mov    di,0x2312
    2582:	0e                   	push   cs
    2583:	57                   	push   di
    2584:	9a 4c 18 38 26       	call   0x2638:0x184c
    2589:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    258c:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    2591:	06                   	push   es
    2592:	57                   	push   di
    2593:	9a 8c 1d f1 25       	call   0x25f1:0x1d8c
    2598:	6a 18                	push   0x18
    259a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    259d:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    25a2:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    25a6:	06                   	push   es
    25a7:	57                   	push   di
    25a8:	9a f5 11 dc 25       	call   0x25dc:0x11f5
    25ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25b0:	06                   	push   es
    25b1:	57                   	push   di
    25b2:	9a d5 33 88 27       	call   0x2788:0x33d5
    25b7:	89 c7                	mov    di,ax
    25b9:	8e c2                	mov    es,dx
    25bb:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    25bf:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    25c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c6:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    25cb:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    25cf:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    25d3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    25d7:	06                   	push   es
    25d8:	57                   	push   di
    25d9:	9a 99 20 fc 25       	call   0x25fc:0x2099
    25de:	8d be f4 fd          	lea    di,[bp-0x20c]
    25e2:	16                   	push   ss
    25e3:	57                   	push   di
    25e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25e7:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    25ec:	06                   	push   es
    25ed:	57                   	push   di
    25ee:	9a 53 1d 0c 26       	call   0x260c:0x1d53
    25f3:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    25f7:	06                   	push   es
    25f8:	57                   	push   di
    25f9:	9a 03 20 2c 26       	call   0x262c:0x2003
    25fe:	50                   	push   ax
    25ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2602:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    2607:	06                   	push   es
    2608:	57                   	push   di
    2609:	9a bf 17 21 26       	call   0x2621:0x17bf
    260e:	8d be f4 fd          	lea    di,[bp-0x20c]
    2612:	16                   	push   ss
    2613:	57                   	push   di
    2614:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2617:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    261c:	06                   	push   es
    261d:	57                   	push   di
    261e:	9a 53 1d 4e 26       	call   0x264e:0x1d53
    2623:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2627:	06                   	push   es
    2628:	57                   	push   di
    2629:	9a 4e 20 41 29       	call   0x2941:0x204e
    262e:	b9 03 00             	mov    cx,0x3
    2631:	f7 e9                	imul   cx
    2633:	71 05                	jno    0x263a
    2635:	9a 3e 04 95 26       	call   0x2695:0x43e
    263a:	99                   	cwd
    263b:	b9 02 00             	mov    cx,0x2
    263e:	f7 f9                	idiv   cx
    2640:	50                   	push   ax
    2641:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2644:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    2649:	06                   	push   es
    264a:	57                   	push   di
    264b:	9a e1 17 68 26       	call   0x2668:0x17e1
    2650:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2653:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    2658:	89 be f4 fe          	mov    WORD PTR [bp-0x10c],di
    265c:	8c 86 f6 fe          	mov    WORD PTR [bp-0x10a],es
    2660:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2663:	06                   	push   es
    2664:	57                   	push   di
    2665:	9a 7b 17 76 26       	call   0x2676:0x177b
    266a:	ff 76 fe             	push   WORD PTR [bp-0x2]
    266d:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2671:	06                   	push   es
    2672:	57                   	push   di
    2673:	9a 9d 17 80 26       	call   0x2680:0x179d
    2678:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    267b:	06                   	push   es
    267c:	57                   	push   di
    267d:	9a a9 18 b7 26       	call   0x26b7:0x18a9
    2682:	8b d0                	mov    dx,ax
    2684:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    2688:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    268c:	26 03 45 22          	add    ax,WORD PTR es:[di+0x22]
    2690:	71 05                	jno    0x2697
    2692:	9a 3e 04 ab 26       	call   0x26ab:0x43e
    2697:	3b c2                	cmp    ax,dx
    2699:	7e 20                	jle    0x26bb
    269b:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    269f:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    26a3:	2d 08 00             	sub    ax,0x8
    26a6:	71 05                	jno    0x26ad
    26a8:	9a 3e 04 d8 26       	call   0x26d8:0x43e
    26ad:	50                   	push   ax
    26ae:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26b2:	06                   	push   es
    26b3:	57                   	push   di
    26b4:	9a 7b 17 c3 26       	call   0x26c3:0x177b
    26b9:	eb bd                	jmp    0x2678
    26bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26be:	06                   	push   es
    26bf:	57                   	push   di
    26c0:	9a f4 18 fa 26       	call   0x26fa:0x18f4
    26c5:	8b d0                	mov    dx,ax
    26c7:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26cb:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    26cf:	26 03 45 24          	add    ax,WORD PTR es:[di+0x24]
    26d3:	71 05                	jno    0x26da
    26d5:	9a 3e 04 ee 26       	call   0x26ee:0x43e
    26da:	3b c2                	cmp    ax,dx
    26dc:	7e 20                	jle    0x26fe
    26de:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26e2:	26 8b 45 20          	mov    ax,WORD PTR es:[di+0x20]
    26e6:	2d 08 00             	sub    ax,0x8
    26e9:	71 05                	jno    0x26f0
    26eb:	9a 3e 04 1c 27       	call   0x271c:0x43e
    26f0:	50                   	push   ax
    26f1:	c4 be f4 fe          	les    di,DWORD PTR [bp-0x10c]
    26f5:	06                   	push   es
    26f6:	57                   	push   di
    26f7:	9a 9d 17 0d 27       	call   0x270d:0x179d
    26fc:	eb bd                	jmp    0x26bb
    26fe:	6a 01                	push   0x1
    2700:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2703:	26 c4 bd 14 04       	les    di,DWORD PTR es:[di+0x414]
    2708:	06                   	push   es
    2709:	57                   	push   di
    270a:	9a 77 1c af 27       	call   0x27af:0x1c77
    270f:	c9                   	leave
    2710:	ca 0e 00             	retf   0xe
    2713:	55                   	push   bp
    2714:	89 e5                	mov    bp,sp
    2716:	b8 04 00             	mov    ax,0x4
    2719:	9a 44 04 97 27       	call   0x2797:0x444
    271e:	83 ec 04             	sub    sp,0x4
    2721:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2724:	26 83 7d 02 07       	cmp    WORD PTR es:[di+0x2],0x7
    2729:	b0 00                	mov    al,0x0
    272b:	75 01                	jne    0x272e
    272d:	40                   	inc    ax
    272e:	8a c8                	mov    cl,al
    2730:	26 81 7d 02 09 02    	cmp    WORD PTR es:[di+0x2],0x209
    2736:	b0 00                	mov    al,0x0
    2738:	77 01                	ja     0x273b
    273a:	40                   	inc    ax
    273b:	8a d0                	mov    dl,al
    273d:	26 81 7d 02 00 02    	cmp    WORD PTR es:[di+0x2],0x200
    2743:	b0 00                	mov    al,0x0
    2745:	76 01                	jbe    0x2748
    2747:	40                   	inc    ax
    2748:	22 c2                	and    al,dl
    274a:	0a c1                	or     al,cl
    274c:	08 c0                	or     al,al
    274e:	74 3a                	je     0x278a
    2750:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2754:	31 c0                	xor    ax,ax
    2756:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    275a:	26 89 45 6f          	mov    WORD PTR es:[di+0x6f],ax
    275e:	26 89 45 71          	mov    WORD PTR es:[di+0x71],ax
    2762:	26 89 45 73          	mov    WORD PTR es:[di+0x73],ax
    2766:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2769:	26 c6 05 01          	mov    BYTE PTR es:[di],0x1
    276d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2770:	06                   	push   es
    2771:	57                   	push   di
    2772:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2775:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    2779:	6a 02                	push   0x2
    277b:	6a 00                	push   0x0
    277d:	6a 00                	push   0x0
    277f:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2783:	06                   	push   es
    2784:	57                   	push   di
    2785:	9a b2 77 17 28       	call   0x2817:0x77b2
    278a:	c9                   	leave
    278b:	ca 0c 00             	retf   0xc
    278e:	55                   	push   bp
    278f:	89 e5                	mov    bp,sp
    2791:	b8 04 00             	mov    ax,0x4
    2794:	9a 44 04 b6 27       	call   0x27b6:0x444
    2799:	83 ec 04             	sub    sp,0x4
    279c:	80 7e 10 01          	cmp    BYTE PTR [bp+0x10],0x1
    27a0:	74 03                	je     0x27a5
    27a2:	e9 9c 00             	jmp    0x2841
    27a5:	ff 76 14             	push   WORD PTR [bp+0x14]
    27a8:	ff 76 12             	push   WORD PTR [bp+0x12]
    27ab:	bf c1 05             	mov    di,0x5c1
    27ae:	b8 c9 27             	mov    ax,0x27c9
    27b1:	50                   	push   ax
    27b2:	57                   	push   di
    27b3:	9a 55 22 d0 27       	call   0x27d0:0x2255
    27b8:	08 c0                	or     al,al
    27ba:	75 03                	jne    0x27bf
    27bc:	e9 82 00             	jmp    0x2841
    27bf:	ff 76 14             	push   WORD PTR [bp+0x14]
    27c2:	ff 76 12             	push   WORD PTR [bp+0x12]
    27c5:	bf c1 05             	mov    di,0x5c1
    27c8:	b8 f8 27             	mov    ax,0x27f8
    27cb:	50                   	push   ax
    27cc:	57                   	push   di
    27cd:	9a 73 22 ff 27       	call   0x27ff:0x2273
    27d2:	89 c7                	mov    di,ax
    27d4:	8e c2                	mov    es,dx
    27d6:	26 8b 85 ac 00       	mov    ax,WORD PTR es:[di+0xac]
    27db:	26 0b 85 ae 00       	or     ax,WORD PTR es:[di+0xae]
    27e0:	74 5f                	je     0x2841
    27e2:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    27e6:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    27e9:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    27ec:	6a 08                	push   0x8
    27ee:	ff 76 14             	push   WORD PTR [bp+0x14]
    27f1:	ff 76 12             	push   WORD PTR [bp+0x12]
    27f4:	bf c1 05             	mov    di,0x5c1
    27f7:	b8 d6 2b             	mov    ax,0x2bd6
    27fa:	50                   	push   ax
    27fb:	57                   	push   di
    27fc:	9a 73 22 4d 28       	call   0x284d:0x2273
    2801:	89 c7                	mov    di,ax
    2803:	8e c2                	mov    es,dx
    2805:	26 ff b5 ae 00       	push   WORD PTR es:[di+0xae]
    280a:	26 ff b5 ac 00       	push   WORD PTR es:[di+0xac]
    280f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2812:	06                   	push   es
    2813:	57                   	push   di
    2814:	9a b2 77 21 28       	call   0x2821:0x77b2
    2819:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    281c:	06                   	push   es
    281d:	57                   	push   di
    281e:	9a 03 73 6a 28       	call   0x286a:0x7303
    2823:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2826:	06                   	push   es
    2827:	57                   	push   di
    2828:	b8 13 27             	mov    ax,0x2713
    282b:	ba 11 29             	mov    dx,0x2911
    282e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2831:	26 89 45 6d          	mov    WORD PTR es:[di+0x6d],ax
    2835:	26 89 55 6f          	mov    WORD PTR es:[di+0x6f],dx
    2839:	26 8f 45 71          	pop    WORD PTR es:[di+0x71]
    283d:	26 8f 45 73          	pop    WORD PTR es:[di+0x73]
    2841:	c9                   	leave
    2842:	ca 10 00             	retf   0x10
    2845:	55                   	push   bp
    2846:	89 e5                	mov    bp,sp
    2848:	31 c0                	xor    ax,ax
    284a:	9a 44 04 78 28       	call   0x2878:0x444
    284f:	6a 01                	push   0x1
    2851:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2854:	26 c4 bd d4 03       	les    di,DWORD PTR es:[di+0x3d4]
    2859:	26 ff 75 25          	push   WORD PTR es:[di+0x25]
    285d:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    2861:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2865:	06                   	push   es
    2866:	57                   	push   di
    2867:	9a b2 77 89 28       	call   0x2889:0x77b2
    286c:	c9                   	leave
    286d:	ca 08 00             	retf   0x8
    2870:	55                   	push   bp
    2871:	89 e5                	mov    bp,sp
    2873:	31 c0                	xor    ax,ax
    2875:	9a 44 04 97 28       	call   0x2897:0x444
    287a:	6a 03                	push   0x3
    287c:	6a 00                	push   0x0
    287e:	6a 00                	push   0x0
    2880:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    2884:	06                   	push   es
    2885:	57                   	push   di
    2886:	9a b2 77 aa 28       	call   0x28aa:0x77b2
    288b:	c9                   	leave
    288c:	ca 08 00             	retf   0x8
    288f:	55                   	push   bp
    2890:	89 e5                	mov    bp,sp
    2892:	31 c0                	xor    ax,ax
    2894:	9a 44 04 b8 28       	call   0x28b8:0x444
    2899:	68 05 01             	push   0x105
    289c:	bf 50 02             	mov    di,0x250
    289f:	1e                   	push   ds
    28a0:	57                   	push   di
    28a1:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    28a5:	06                   	push   es
    28a6:	57                   	push   di
    28a7:	9a b2 77 c9 28       	call   0x28c9:0x77b2
    28ac:	c9                   	leave
    28ad:	ca 08 00             	retf   0x8
    28b0:	55                   	push   bp
    28b1:	89 e5                	mov    bp,sp
    28b3:	31 c0                	xor    ax,ax
    28b5:	9a 44 04 d8 28       	call   0x28d8:0x444
    28ba:	6a 04                	push   0x4
    28bc:	6a 00                	push   0x0
    28be:	6a 00                	push   0x0
    28c0:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    28c4:	06                   	push   es
    28c5:	57                   	push   di
    28c6:	9a b2 77 e6 28       	call   0x28e6:0x77b2
    28cb:	c9                   	leave
    28cc:	ca 08 00             	retf   0x8
    28cf:	55                   	push   bp
    28d0:	89 e5                	mov    bp,sp
    28d2:	b8 04 00             	mov    ax,0x4
    28d5:	9a 44 04 f4 28       	call   0x28f4:0x444
    28da:	83 ec 04             	sub    sp,0x4
    28dd:	c4 3e 08 20          	les    di,DWORD PTR ds:0x2008
    28e1:	06                   	push   es
    28e2:	57                   	push   di
    28e3:	9a 45 5d ff ff       	call   0xffff:0x5d45
    28e8:	c9                   	leave
    28e9:	ca 08 00             	retf   0x8
    28ec:	55                   	push   bp
    28ed:	89 e5                	mov    bp,sp
    28ef:	31 c0                	xor    ax,ax
    28f1:	9a 44 04 28 29       	call   0x2928:0x444
    28f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28f9:	26 c4 bd 04 04       	les    di,DWORD PTR es:[di+0x404]
    28fe:	06                   	push   es
    28ff:	57                   	push   di
    2900:	9a 17 2f ff ff       	call   0xffff:0x2f17
    2905:	08 c0                	or     al,al
    2907:	74 0a                	je     0x2913
    2909:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290c:	06                   	push   es
    290d:	57                   	push   di
    290e:	9a 7b 29 79 29       	call   0x2979:0x297b
    2913:	c9                   	leave
    2914:	ca 08 00             	retf   0x8
    2917:	00 00                	add    BYTE PTR [bx+si],al
    2919:	00 00                	add    BYTE PTR [bx+si],al
    291b:	ff                   	(bad)
    291c:	ff 00                	inc    WORD PTR [bx+si]
    291e:	00 55 89             	add    BYTE PTR [di-0x77],dl
    2921:	e5 b8                	in     ax,0xb8
    2923:	22 00                	and    al,BYTE PTR [bx+si]
    2925:	9a 44 04 58 29       	call   0x2958:0x444
    292a:	83 ec 22             	sub    sp,0x22
    292d:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2931:	06                   	push   es
    2932:	57                   	push   di
    2933:	9a 04 2a 9f 29       	call   0x299f:0x2a04
    2938:	89 c7                	mov    di,ax
    293a:	8e c2                	mov    es,dx
    293c:	06                   	push   es
    293d:	57                   	push   di
    293e:	9a d2 21 f0 29       	call   0x29f0:0x21d2
    2943:	50                   	push   ax
    2944:	8d 7e de             	lea    di,[bp-0x22]
    2947:	16                   	push   ss
    2948:	57                   	push   di
    2949:	9a ff ff 00 00       	call   0x0:0xffff
    294e:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    2951:	99                   	cwd
    2952:	bf 17 29             	mov    di,0x2917
    2955:	9a 16 04 84 29       	call   0x2984:0x416
    295a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    295d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2960:	c9                   	leave
    2961:	ca 02 00             	retf   0x2
    2964:	00 01                	add    BYTE PTR [bx+di],al
    2966:	09 01                	or     WORD PTR [bx+di],ax
    2968:	20 03                	and    BYTE PTR [bp+di],al
    296a:	20 20                	and    BYTE PTR [bx+si],ah
    296c:	20 00                	and    BYTE PTR [bx+si],al
    296e:	80 ff ff             	cmp    bh,0xff
    2971:	ff                   	(bad)
    2972:	7f 00                	jg     0x2974
    2974:	00 00                	add    BYTE PTR [bx+si],al
    2976:	00 b3 2d 94          	add    BYTE PTR [bp+di-0x6bd3],dh
    297a:	29 55 89             	sub    WORD PTR [di-0x77],dx
    297d:	e5 b8                	in     ax,0xb8
    297f:	0e                   	push   cs
    2980:	04 9a                	add    al,0x9a
    2982:	44                   	inc    sp
    2983:	04 aa                	add    al,0xaa
    2985:	29 81 ec 0e          	sub    WORD PTR [bx+di+0xeec],ax
    2989:	04 6a                	add    al,0x6a
    298b:	01 c4                	add    sp,ax
    298d:	7e 06                	jle    0x2995
    298f:	06                   	push   es
    2990:	57                   	push   di
    2991:	9a 4e 32 99 2b       	call   0x2b99:0x324e
    2996:	8d be fc fe          	lea    di,[bp-0x104]
    299a:	16                   	push   ss
    299b:	57                   	push   di
    299c:	9a 4e 20 c8 29       	call   0x29c8:0x204e
    29a1:	8d be fc fe          	lea    di,[bp-0x104]
    29a5:	16                   	push   ss
    29a6:	57                   	push   di
    29a7:	9a f5 09 af 29       	call   0x29af:0x9f5
    29ac:	9a 08 04 44 2a       	call   0x2a44:0x408
    29b1:	b8 75 29             	mov    ax,0x2975
    29b4:	0e                   	push   cs
    29b5:	50                   	push   ax
    29b6:	55                   	push   bp
    29b7:	ff 36 58 18          	push   WORD PTR ds:0x1858
    29bb:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    29bf:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    29c3:	06                   	push   es
    29c4:	57                   	push   di
    29c5:	9a 04 2a fd 29       	call   0x29fd:0x2a04
    29ca:	89 c7                	mov    di,ax
    29cc:	8e c2                	mov    es,dx
    29ce:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    29d2:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    29d6:	c4 3e f6 18          	les    di,DWORD PTR ds:0x18f6
    29da:	26 c4 bd c8 02       	les    di,DWORD PTR es:[di+0x2c8]
    29df:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    29e3:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    29e7:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    29eb:	06                   	push   es
    29ec:	57                   	push   di
    29ed:	9a 99 20 0c 2a       	call   0x2a0c:0x2099
    29f2:	6a 0a                	push   0xa
    29f4:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    29f8:	06                   	push   es
    29f9:	57                   	push   di
    29fa:	9a 04 2a 19 2a       	call   0x2a19:0x2a04
    29ff:	89 c7                	mov    di,ax
    2a01:	8e c2                	mov    es,dx
    2a03:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2a07:	06                   	push   es
    2a08:	57                   	push   di
    2a09:	9a f5 11 28 2a       	call   0x2a28:0x11f5
    2a0e:	6a 02                	push   0x2
    2a10:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2a14:	06                   	push   es
    2a15:	57                   	push   di
    2a16:	9a 04 2a 68 2b       	call   0x2b68:0x2a04
    2a1b:	89 c7                	mov    di,ax
    2a1d:	8e c2                	mov    es,dx
    2a1f:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2a23:	06                   	push   es
    2a24:	57                   	push   di
    2a25:	9a 78 12 77 2b       	call   0x2b77:0x1278
    2a2a:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    2a2f:	eb 03                	jmp    0x2a34
    2a31:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2a34:	8d be fc fe          	lea    di,[bp-0x104]
    2a38:	16                   	push   ss
    2a39:	57                   	push   di
    2a3a:	bf 64 29             	mov    di,0x2964
    2a3d:	0e                   	push   cs
    2a3e:	57                   	push   di
    2a3f:	6a 00                	push   0x0
    2a41:	9a b5 0d 49 2a       	call   0x2a49:0xdb5
    2a46:	9a 78 0c 4e 2a       	call   0x2a4e:0xc78
    2a4b:	9a 08 04 7c 2a       	call   0x2a7c:0x408
    2a50:	83 7e fe 03          	cmp    WORD PTR [bp-0x2],0x3
    2a54:	75 db                	jne    0x2a31
    2a56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a59:	26 c4 bd 10 04       	les    di,DWORD PTR es:[di+0x410]
    2a5e:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    2a62:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    2a66:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2a6b:	06                   	push   es
    2a6c:	57                   	push   di
    2a6d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a70:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2a74:	2d 01 00             	sub    ax,0x1
    2a77:	71 05                	jno    0x2a7e
    2a79:	9a 3e 04 bc 2a       	call   0x2abc:0x43e
    2a7e:	89 86 f0 fd          	mov    WORD PTR [bp-0x210],ax
    2a82:	31 c0                	xor    ax,ax
    2a84:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    2a88:	7e 03                	jle    0x2a8d
    2a8a:	e9 c8 00             	jmp    0x2b55
    2a8d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a90:	eb 03                	jmp    0x2a95
    2a92:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2a95:	8d be f0 fc          	lea    di,[bp-0x310]
    2a99:	16                   	push   ss
    2a9a:	57                   	push   di
    2a9b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2a9e:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2aa2:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    2aa7:	06                   	push   es
    2aa8:	57                   	push   di
    2aa9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2aac:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    2ab0:	8d be fc fd          	lea    di,[bp-0x204]
    2ab4:	16                   	push   ss
    2ab5:	57                   	push   di
    2ab6:	68 ff 00             	push   0xff
    2ab9:	9a e7 17 cc 2a       	call   0x2acc:0x17e7
    2abe:	bf 65 29             	mov    di,0x2965
    2ac1:	0e                   	push   cs
    2ac2:	57                   	push   di
    2ac3:	8d be fc fd          	lea    di,[bp-0x204]
    2ac7:	16                   	push   ss
    2ac8:	57                   	push   di
    2ac9:	9a 78 18 e5 2a       	call   0x2ae5:0x1878
    2ace:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2ad1:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    2ad5:	7e 26                	jle    0x2afd
    2ad7:	8d be fc fd          	lea    di,[bp-0x204]
    2adb:	16                   	push   ss
    2adc:	57                   	push   di
    2add:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2ae0:	6a 01                	push   0x1
    2ae2:	9a 75 19 fb 2a       	call   0x2afb:0x1975
    2ae7:	bf 67 29             	mov    di,0x2967
    2aea:	0e                   	push   cs
    2aeb:	57                   	push   di
    2aec:	8d be fc fd          	lea    di,[bp-0x204]
    2af0:	16                   	push   ss
    2af1:	57                   	push   di
    2af2:	68 ff 00             	push   0xff
    2af5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2af8:	9a 16 19 11 2b       	call   0x2b11:0x1916
    2afd:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    2b01:	75 bb                	jne    0x2abe
    2b03:	8d be f0 fc          	lea    di,[bp-0x310]
    2b07:	16                   	push   ss
    2b08:	57                   	push   di
    2b09:	bf 69 29             	mov    di,0x2969
    2b0c:	0e                   	push   cs
    2b0d:	57                   	push   di
    2b0e:	9a cd 17 1c 2b       	call   0x2b1c:0x17cd
    2b13:	8d be fc fd          	lea    di,[bp-0x204]
    2b17:	16                   	push   ss
    2b18:	57                   	push   di
    2b19:	9a 4c 18 2a 2b       	call   0x2b2a:0x184c
    2b1e:	8d be fc fd          	lea    di,[bp-0x204]
    2b22:	16                   	push   ss
    2b23:	57                   	push   di
    2b24:	68 ff 00             	push   0xff
    2b27:	9a e7 17 3d 2b       	call   0x2b3d:0x17e7
    2b2c:	8d be fc fe          	lea    di,[bp-0x104]
    2b30:	16                   	push   ss
    2b31:	57                   	push   di
    2b32:	8d be fc fd          	lea    di,[bp-0x204]
    2b36:	16                   	push   ss
    2b37:	57                   	push   di
    2b38:	6a 00                	push   0x0
    2b3a:	9a b5 0d 42 2b       	call   0x2b42:0xdb5
    2b3f:	9a 78 0c 47 2b       	call   0x2b47:0xc78
    2b44:	9a 08 04 a3 2b       	call   0x2ba3:0x408
    2b49:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2b4c:	3b 86 f0 fd          	cmp    ax,WORD PTR [bp-0x210]
    2b50:	74 03                	je     0x2b55
    2b52:	e9 3d ff             	jmp    0x2a92
    2b55:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2b59:	89 be f2 fd          	mov    WORD PTR [bp-0x20e],di
    2b5d:	8c 86 f4 fd          	mov    WORD PTR [bp-0x20c],es
    2b61:	6a 06                	push   0x6
    2b63:	06                   	push   es
    2b64:	57                   	push   di
    2b65:	9a 04 2a 84 2b       	call   0x2b84:0x2a04
    2b6a:	89 c7                	mov    di,ax
    2b6c:	8e c2                	mov    es,dx
    2b6e:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2b72:	06                   	push   es
    2b73:	57                   	push   di
    2b74:	9a f5 11 93 2b       	call   0x2b93:0x11f5
    2b79:	6a 00                	push   0x0
    2b7b:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2b7f:	06                   	push   es
    2b80:	57                   	push   di
    2b81:	9a 04 2a 07 2c       	call   0x2c07:0x2a04
    2b86:	89 c7                	mov    di,ax
    2b88:	8e c2                	mov    es,dx
    2b8a:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2b8e:	06                   	push   es
    2b8f:	57                   	push   di
    2b90:	9a 78 12 2e 2c       	call   0x2c2e:0x1278
    2b95:	55                   	push   bp
    2b96:	9a 1f 29 ef 2d       	call   0x2def:0x291f
    2b9b:	05 02 00             	add    ax,0x2
    2b9e:	73 05                	jae    0x2ba5
    2ba0:	9a 3e 04 ad 2b       	call   0x2bad:0x43e
    2ba5:	31 d2                	xor    dx,dx
    2ba7:	bf 6d 29             	mov    di,0x296d
    2baa:	9a 16 04 c1 2b       	call   0x2bc1:0x416
    2baf:	89 86 fa fd          	mov    WORD PTR [bp-0x206],ax
    2bb3:	8d be f2 fb          	lea    di,[bp-0x40e]
    2bb7:	16                   	push   ss
    2bb8:	57                   	push   di
    2bb9:	bf 69 29             	mov    di,0x2969
    2bbc:	0e                   	push   cs
    2bbd:	57                   	push   di
    2bbe:	9a cd 17 db 2b       	call   0x2bdb:0x17cd
    2bc3:	8d be f2 fc          	lea    di,[bp-0x30e]
    2bc7:	16                   	push   ss
    2bc8:	57                   	push   di
    2bc9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bcc:	26 c4 bd 8c 03       	les    di,DWORD PTR es:[di+0x38c]
    2bd1:	06                   	push   es
    2bd2:	57                   	push   di
    2bd3:	9a 53 1d 53 2c       	call   0x2c53:0x1d53
    2bd8:	9a 4c 18 e9 2b       	call   0x2be9:0x184c
    2bdd:	8d be fc fd          	lea    di,[bp-0x204]
    2be1:	16                   	push   ss
    2be2:	57                   	push   di
    2be3:	68 ff 00             	push   0xff
    2be6:	9a e7 17 fb 2b       	call   0x2bfb:0x17e7
    2beb:	6a 00                	push   0x0
    2bed:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    2bf1:	b9 05 00             	mov    cx,0x5
    2bf4:	f7 e9                	imul   cx
    2bf6:	71 05                	jno    0x2bfd
    2bf8:	9a 3e 04 11 2c       	call   0x2c11:0x43e
    2bfd:	50                   	push   ax
    2bfe:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2c02:	06                   	push   es
    2c03:	57                   	push   di
    2c04:	9a 72 2a 23 2c       	call   0x2c23:0x2a72
    2c09:	5a                   	pop    dx
    2c0a:	2b c2                	sub    ax,dx
    2c0c:	71 05                	jno    0x2c13
    2c0e:	9a 3e 04 3e 2c       	call   0x2c3e:0x43e
    2c13:	50                   	push   ax
    2c14:	8d be fc fd          	lea    di,[bp-0x204]
    2c18:	16                   	push   ss
    2c19:	57                   	push   di
    2c1a:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2c1e:	06                   	push   es
    2c1f:	57                   	push   di
    2c20:	9a 04 2a 84 2c       	call   0x2c84:0x2a04
    2c25:	89 c7                	mov    di,ax
    2c27:	8e c2                	mov    es,dx
    2c29:	06                   	push   es
    2c2a:	57                   	push   di
    2c2b:	9a 09 1f ab 2c       	call   0x2cab:0x1f09
    2c30:	8d be f2 fb          	lea    di,[bp-0x40e]
    2c34:	16                   	push   ss
    2c35:	57                   	push   di
    2c36:	bf 69 29             	mov    di,0x2969
    2c39:	0e                   	push   cs
    2c3a:	57                   	push   di
    2c3b:	9a cd 17 58 2c       	call   0x2c58:0x17cd
    2c40:	8d be f2 fc          	lea    di,[bp-0x30e]
    2c44:	16                   	push   ss
    2c45:	57                   	push   di
    2c46:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c49:	26 c4 bd 90 03       	les    di,DWORD PTR es:[di+0x390]
    2c4e:	06                   	push   es
    2c4f:	57                   	push   di
    2c50:	9a 53 1d d0 2c       	call   0x2cd0:0x1d53
    2c55:	9a 4c 18 66 2c       	call   0x2c66:0x184c
    2c5a:	8d be fc fd          	lea    di,[bp-0x204]
    2c5e:	16                   	push   ss
    2c5f:	57                   	push   di
    2c60:	68 ff 00             	push   0xff
    2c63:	9a e7 17 78 2c       	call   0x2c78:0x17e7
    2c68:	6a 00                	push   0x0
    2c6a:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    2c6e:	b9 04 00             	mov    cx,0x4
    2c71:	f7 e9                	imul   cx
    2c73:	71 05                	jno    0x2c7a
    2c75:	9a 3e 04 8e 2c       	call   0x2c8e:0x43e
    2c7a:	50                   	push   ax
    2c7b:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2c7f:	06                   	push   es
    2c80:	57                   	push   di
    2c81:	9a 72 2a a0 2c       	call   0x2ca0:0x2a72
    2c86:	5a                   	pop    dx
    2c87:	2b c2                	sub    ax,dx
    2c89:	71 05                	jno    0x2c90
    2c8b:	9a 3e 04 bb 2c       	call   0x2cbb:0x43e
    2c90:	50                   	push   ax
    2c91:	8d be fc fd          	lea    di,[bp-0x204]
    2c95:	16                   	push   ss
    2c96:	57                   	push   di
    2c97:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2c9b:	06                   	push   es
    2c9c:	57                   	push   di
    2c9d:	9a 04 2a 01 2d       	call   0x2d01:0x2a04
    2ca2:	89 c7                	mov    di,ax
    2ca4:	8e c2                	mov    es,dx
    2ca6:	06                   	push   es
    2ca7:	57                   	push   di
    2ca8:	9a 09 1f 28 2d       	call   0x2d28:0x1f09
    2cad:	8d be f2 fb          	lea    di,[bp-0x40e]
    2cb1:	16                   	push   ss
    2cb2:	57                   	push   di
    2cb3:	bf 69 29             	mov    di,0x2969
    2cb6:	0e                   	push   cs
    2cb7:	57                   	push   di
    2cb8:	9a cd 17 d5 2c       	call   0x2cd5:0x17cd
    2cbd:	8d be f2 fc          	lea    di,[bp-0x30e]
    2cc1:	16                   	push   ss
    2cc2:	57                   	push   di
    2cc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cc6:	26 c4 bd 94 03       	les    di,DWORD PTR es:[di+0x394]
    2ccb:	06                   	push   es
    2ccc:	57                   	push   di
    2ccd:	9a 53 1d 4d 2d       	call   0x2d4d:0x1d53
    2cd2:	9a 4c 18 e3 2c       	call   0x2ce3:0x184c
    2cd7:	8d be fc fd          	lea    di,[bp-0x204]
    2cdb:	16                   	push   ss
    2cdc:	57                   	push   di
    2cdd:	68 ff 00             	push   0xff
    2ce0:	9a e7 17 f5 2c       	call   0x2cf5:0x17e7
    2ce5:	6a 00                	push   0x0
    2ce7:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    2ceb:	b9 03 00             	mov    cx,0x3
    2cee:	f7 e9                	imul   cx
    2cf0:	71 05                	jno    0x2cf7
    2cf2:	9a 3e 04 0b 2d       	call   0x2d0b:0x43e
    2cf7:	50                   	push   ax
    2cf8:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2cfc:	06                   	push   es
    2cfd:	57                   	push   di
    2cfe:	9a 72 2a 1d 2d       	call   0x2d1d:0x2a72
    2d03:	5a                   	pop    dx
    2d04:	2b c2                	sub    ax,dx
    2d06:	71 05                	jno    0x2d0d
    2d08:	9a 3e 04 38 2d       	call   0x2d38:0x43e
    2d0d:	50                   	push   ax
    2d0e:	8d be fc fd          	lea    di,[bp-0x204]
    2d12:	16                   	push   ss
    2d13:	57                   	push   di
    2d14:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2d18:	06                   	push   es
    2d19:	57                   	push   di
    2d1a:	9a 04 2a 7e 2d       	call   0x2d7e:0x2a04
    2d1f:	89 c7                	mov    di,ax
    2d21:	8e c2                	mov    es,dx
    2d23:	06                   	push   es
    2d24:	57                   	push   di
    2d25:	9a 09 1f a5 2d       	call   0x2da5:0x1f09
    2d2a:	8d be f2 fb          	lea    di,[bp-0x40e]
    2d2e:	16                   	push   ss
    2d2f:	57                   	push   di
    2d30:	bf 69 29             	mov    di,0x2969
    2d33:	0e                   	push   cs
    2d34:	57                   	push   di
    2d35:	9a cd 17 52 2d       	call   0x2d52:0x17cd
    2d3a:	8d be f2 fc          	lea    di,[bp-0x30e]
    2d3e:	16                   	push   ss
    2d3f:	57                   	push   di
    2d40:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d43:	26 c4 bd 98 03       	les    di,DWORD PTR es:[di+0x398]
    2d48:	06                   	push   es
    2d49:	57                   	push   di
    2d4a:	9a 53 1d 19 2f       	call   0x2f19:0x1d53
    2d4f:	9a 4c 18 60 2d       	call   0x2d60:0x184c
    2d54:	8d be fc fd          	lea    di,[bp-0x204]
    2d58:	16                   	push   ss
    2d59:	57                   	push   di
    2d5a:	68 ff 00             	push   0xff
    2d5d:	9a e7 17 72 2d       	call   0x2d72:0x17e7
    2d62:	6a 00                	push   0x0
    2d64:	8b 86 fa fd          	mov    ax,WORD PTR [bp-0x206]
    2d68:	b9 02 00             	mov    cx,0x2
    2d6b:	f7 e9                	imul   cx
    2d6d:	71 05                	jno    0x2d74
    2d6f:	9a 3e 04 88 2d       	call   0x2d88:0x43e
    2d74:	50                   	push   ax
    2d75:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2d79:	06                   	push   es
    2d7a:	57                   	push   di
    2d7b:	9a 72 2a 9a 2d       	call   0x2d9a:0x2a72
    2d80:	5a                   	pop    dx
    2d81:	2b c2                	sub    ax,dx
    2d83:	71 05                	jno    0x2d8a
    2d85:	9a 3e 04 bc 2d       	call   0x2dbc:0x43e
    2d8a:	50                   	push   ax
    2d8b:	8d be fc fd          	lea    di,[bp-0x204]
    2d8f:	16                   	push   ss
    2d90:	57                   	push   di
    2d91:	c4 be f2 fd          	les    di,DWORD PTR [bp-0x20e]
    2d95:	06                   	push   es
    2d96:	57                   	push   di
    2d97:	9a 04 2a ff ff       	call   0xffff:0x2a04
    2d9c:	89 c7                	mov    di,ax
    2d9e:	8e c2                	mov    es,dx
    2da0:	06                   	push   es
    2da1:	57                   	push   di
    2da2:	9a 09 1f ff ff       	call   0xffff:0x1f09
    2da7:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2dab:	83 c4 06             	add    sp,0x6
    2dae:	b8 d3 2d             	mov    ax,0x2dd3
    2db1:	0e                   	push   cs
    2db2:	50                   	push   ax
    2db3:	8d be fc fe          	lea    di,[bp-0x104]
    2db7:	16                   	push   ss
    2db8:	57                   	push   di
    2db9:	9a 4f 0a c1 2d       	call   0x2dc1:0xa4f
    2dbe:	9a 08 04 e0 2d       	call   0x2de0:0x408
    2dc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dc6:	26 c4 bd 10 04       	les    di,DWORD PTR es:[di+0x410]
    2dcb:	06                   	push   es
    2dcc:	57                   	push   di
    2dcd:	9a e3 49 04 2e       	call   0x2e04:0x49e3
    2dd2:	cb                   	retf
    2dd3:	c9                   	leave
    2dd4:	ca 04 00             	retf   0x4
    2dd7:	55                   	push   bp
    2dd8:	89 e5                	mov    bp,sp
    2dda:	b8 04 00             	mov    ax,0x4
    2ddd:	9a 44 04 31 2e       	call   0x2e31:0x444
    2de2:	83 ec 04             	sub    sp,0x4
    2de5:	6a 00                	push   0x0
    2de7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dea:	06                   	push   es
    2deb:	57                   	push   di
    2dec:	9a 4e 32 c5 32       	call   0x32c5:0x324e
    2df1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2df4:	26 c4 bd 10 04       	les    di,DWORD PTR es:[di+0x410]
    2df9:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2dfc:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2dff:	06                   	push   es
    2e00:	57                   	push   di
    2e01:	9a 3f 4a 0e 2e       	call   0x2e0e:0x4a3f
    2e06:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e09:	06                   	push   es
    2e0a:	57                   	push   di
    2e0b:	9a ff 49 18 2e       	call   0x2e18:0x49ff
    2e10:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e13:	06                   	push   es
    2e14:	57                   	push   di
    2e15:	9a e3 49 de 2e       	call   0x2ede:0x49e3
    2e1a:	c9                   	leave
    2e1b:	ca 08 00             	retf   0x8
    2e1e:	01 20                	add    WORD PTR [bx+si],sp
    2e20:	03 6f 75             	add    bp,WORD PTR [bx+0x75]
    2e23:	69 03 6e 6f          	imul   ax,WORD PTR [bp+di],0x6f6e
    2e27:	6e                   	outs   dx,BYTE PTR ds:[si]
    2e28:	55                   	push   bp
    2e29:	89 e5                	mov    bp,sp
    2e2b:	b8 06 02             	mov    ax,0x206
    2e2e:	9a 44 04 6c 2e       	call   0x2e6c:0x444
    2e33:	81 ec 06 02          	sub    sp,0x206
    2e37:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2e3a:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    2e3f:	75 03                	jne    0x2e44
    2e41:	e9 fe 03             	jmp    0x3242
    2e44:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    2e49:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2e4c:	36 8b 45 0a          	mov    ax,WORD PTR ss:[di+0xa]
    2e50:	3d 00 00             	cmp    ax,0x0
    2e53:	75 36                	jne    0x2e8b
    2e55:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2e58:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2e5c:	76 2b                	jbe    0x2e89
    2e5e:	8d be fe fd          	lea    di,[bp-0x202]
    2e62:	16                   	push   ss
    2e63:	57                   	push   di
    2e64:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2e67:	06                   	push   es
    2e68:	57                   	push   di
    2e69:	9a cd 17 7a 2e       	call   0x2e7a:0x17cd
    2e6e:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    2e71:	81 c7 00 ff          	add    di,0xff00
    2e75:	16                   	push   ss
    2e76:	57                   	push   di
    2e77:	9a 4c 18 87 2e       	call   0x2e87:0x184c
    2e7c:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2e7f:	06                   	push   es
    2e80:	57                   	push   di
    2e81:	ff 76 10             	push   WORD PTR [bp+0x10]
    2e84:	9a e7 17 b7 2e       	call   0x2eb7:0x17e7
    2e89:	eb 49                	jmp    0x2ed4
    2e8b:	3d 01 00             	cmp    ax,0x1
    2e8e:	75 44                	jne    0x2ed4
    2e90:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2e93:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2e96:	30 e4                	xor    ah,ah
    2e98:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    2e9c:	8b 86 fe fe          	mov    ax,WORD PTR [bp-0x102]
    2ea0:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    2ea3:	7d 2d                	jge    0x2ed2
    2ea5:	ff 86 fe fe          	inc    WORD PTR [bp-0x102]
    2ea9:	8d be fe fd          	lea    di,[bp-0x202]
    2ead:	16                   	push   ss
    2eae:	57                   	push   di
    2eaf:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2eb2:	06                   	push   es
    2eb3:	57                   	push   di
    2eb4:	9a cd 17 c1 2e       	call   0x2ec1:0x17cd
    2eb9:	bf 1e 2e             	mov    di,0x2e1e
    2ebc:	0e                   	push   cs
    2ebd:	57                   	push   di
    2ebe:	9a 4c 18 ce 2e       	call   0x2ece:0x184c
    2ec3:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    2ec6:	06                   	push   es
    2ec7:	57                   	push   di
    2ec8:	ff 76 10             	push   WORD PTR [bp+0x10]
    2ecb:	9a e7 17 e5 2e       	call   0x2ee5:0x17e7
    2ed0:	eb ca                	jmp    0x2e9c
    2ed2:	eb 00                	jmp    0x2ed4
    2ed4:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2ed7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2eda:	bf 0c 01             	mov    di,0x10c
    2edd:	b8 f5 2e             	mov    ax,0x2ef5
    2ee0:	50                   	push   ax
    2ee1:	57                   	push   di
    2ee2:	9a 55 22 fc 2e       	call   0x2efc:0x2255
    2ee7:	08 c0                	or     al,al
    2ee9:	74 56                	je     0x2f41
    2eeb:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2eee:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ef1:	bf 0c 01             	mov    di,0x10c
    2ef4:	b8 b8 2f             	mov    ax,0x2fb8
    2ef7:	50                   	push   ax
    2ef8:	57                   	push   di
    2ef9:	9a 73 22 27 2f       	call   0x2f27:0x2273
    2efe:	89 c7                	mov    di,ax
    2f00:	8e c2                	mov    es,dx
    2f02:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2f06:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2f0a:	8d be fa fd          	lea    di,[bp-0x206]
    2f0e:	16                   	push   ss
    2f0f:	57                   	push   di
    2f10:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2f14:	06                   	push   es
    2f15:	57                   	push   di
    2f16:	9a 53 1d 86 2f       	call   0x2f86:0x1d53
    2f1b:	8d be 00 ff          	lea    di,[bp-0x100]
    2f1f:	16                   	push   ss
    2f20:	57                   	push   di
    2f21:	68 ff 00             	push   0xff
    2f24:	9a e7 17 3d 2f       	call   0x2f3d:0x17e7
    2f29:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    2f2e:	75 11                	jne    0x2f41
    2f30:	8d be 00 ff          	lea    di,[bp-0x100]
    2f34:	16                   	push   ss
    2f35:	57                   	push   di
    2f36:	6a 01                	push   0x1
    2f38:	6a 01                	push   0x1
    2f3a:	9a 75 19 52 2f       	call   0x2f52:0x1975
    2f3f:	eb e8                	jmp    0x2f29
    2f41:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2f44:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2f47:	bf ad 0d             	mov    di,0xdad
    2f4a:	b8 62 2f             	mov    ax,0x2f62
    2f4d:	50                   	push   ax
    2f4e:	57                   	push   di
    2f4f:	9a 55 22 69 2f       	call   0x2f69:0x2255
    2f54:	08 c0                	or     al,al
    2f56:	74 56                	je     0x2fae
    2f58:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2f5b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2f5e:	bf ad 0d             	mov    di,0xdad
    2f61:	b8 ff ff             	mov    ax,0xffff
    2f64:	50                   	push   ax
    2f65:	57                   	push   di
    2f66:	9a 73 22 94 2f       	call   0x2f94:0x2273
    2f6b:	89 c7                	mov    di,ax
    2f6d:	8e c2                	mov    es,dx
    2f6f:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2f73:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2f77:	8d be fa fd          	lea    di,[bp-0x206]
    2f7b:	16                   	push   ss
    2f7c:	57                   	push   di
    2f7d:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2f81:	06                   	push   es
    2f82:	57                   	push   di
    2f83:	9a 53 1d f3 2f       	call   0x2ff3:0x1d53
    2f88:	8d be 00 ff          	lea    di,[bp-0x100]
    2f8c:	16                   	push   ss
    2f8d:	57                   	push   di
    2f8e:	68 ff 00             	push   0xff
    2f91:	9a e7 17 aa 2f       	call   0x2faa:0x17e7
    2f96:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    2f9b:	75 11                	jne    0x2fae
    2f9d:	8d be 00 ff          	lea    di,[bp-0x100]
    2fa1:	16                   	push   ss
    2fa2:	57                   	push   di
    2fa3:	6a 01                	push   0x1
    2fa5:	6a 01                	push   0x1
    2fa7:	9a 75 19 bf 2f       	call   0x2fbf:0x1975
    2fac:	eb e8                	jmp    0x2f96
    2fae:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2fb1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2fb4:	bf 17 06             	mov    di,0x617
    2fb7:	b8 cf 2f             	mov    ax,0x2fcf
    2fba:	50                   	push   ax
    2fbb:	57                   	push   di
    2fbc:	9a 55 22 d6 2f       	call   0x2fd6:0x2255
    2fc1:	08 c0                	or     al,al
    2fc3:	74 56                	je     0x301b
    2fc5:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2fc8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2fcb:	bf 17 06             	mov    di,0x617
    2fce:	b8 7a 30             	mov    ax,0x307a
    2fd1:	50                   	push   ax
    2fd2:	57                   	push   di
    2fd3:	9a 73 22 01 30       	call   0x3001:0x2273
    2fd8:	89 c7                	mov    di,ax
    2fda:	8e c2                	mov    es,dx
    2fdc:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    2fe0:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    2fe4:	8d be fa fd          	lea    di,[bp-0x206]
    2fe8:	16                   	push   ss
    2fe9:	57                   	push   di
    2fea:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    2fee:	06                   	push   es
    2fef:	57                   	push   di
    2ff0:	9a 53 1d b5 30       	call   0x30b5:0x1d53
    2ff5:	8d be 00 ff          	lea    di,[bp-0x100]
    2ff9:	16                   	push   ss
    2ffa:	57                   	push   di
    2ffb:	68 ff 00             	push   0xff
    2ffe:	9a e7 17 17 30       	call   0x3017:0x17e7
    3003:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    3008:	75 11                	jne    0x301b
    300a:	8d be 00 ff          	lea    di,[bp-0x100]
    300e:	16                   	push   ss
    300f:	57                   	push   di
    3010:	6a 01                	push   0x1
    3012:	6a 01                	push   0x1
    3014:	9a 75 19 2c 30       	call   0x302c:0x1975
    3019:	eb e8                	jmp    0x3003
    301b:	ff 76 0e             	push   WORD PTR [bp+0xe]
    301e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3021:	bf 22 00             	mov    di,0x22
    3024:	b8 3c 30             	mov    ax,0x303c
    3027:	50                   	push   ax
    3028:	57                   	push   di
    3029:	9a 55 22 43 30       	call   0x3043:0x2255
    302e:	08 c0                	or     al,al
    3030:	74 3e                	je     0x3070
    3032:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3035:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3038:	bf 22 00             	mov    di,0x22
    303b:	b8 cf 30             	mov    ax,0x30cf
    303e:	50                   	push   ax
    303f:	57                   	push   di
    3040:	9a 73 22 6e 30       	call   0x306e:0x2273
    3045:	89 c7                	mov    di,ax
    3047:	8e c2                	mov    es,dx
    3049:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    304d:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    3051:	8d be fa fd          	lea    di,[bp-0x206]
    3055:	16                   	push   ss
    3056:	57                   	push   di
    3057:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    305b:	06                   	push   es
    305c:	57                   	push   di
    305d:	9a 24 15 ff ff       	call   0xffff:0x1524
    3062:	8d be 00 ff          	lea    di,[bp-0x100]
    3066:	16                   	push   ss
    3067:	57                   	push   di
    3068:	68 ff 00             	push   0xff
    306b:	9a e7 17 81 30       	call   0x3081:0x17e7
    3070:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3073:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3076:	bf 14 1b             	mov    di,0x1b14
    3079:	b8 91 30             	mov    ax,0x3091
    307c:	50                   	push   ax
    307d:	57                   	push   di
    307e:	9a 55 22 98 30       	call   0x3098:0x2255
    3083:	08 c0                	or     al,al
    3085:	74 3e                	je     0x30c5
    3087:	ff 76 0e             	push   WORD PTR [bp+0xe]
    308a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    308d:	bf 14 1b             	mov    di,0x1b14
    3090:	b8 f8 30             	mov    ax,0x30f8
    3093:	50                   	push   ax
    3094:	57                   	push   di
    3095:	9a 73 22 c3 30       	call   0x30c3:0x2273
    309a:	89 c7                	mov    di,ax
    309c:	8e c2                	mov    es,dx
    309e:	89 be fa fe          	mov    WORD PTR [bp-0x106],di
    30a2:	8c 86 fc fe          	mov    WORD PTR [bp-0x104],es
    30a6:	8d be fa fd          	lea    di,[bp-0x206]
    30aa:	16                   	push   ss
    30ab:	57                   	push   di
    30ac:	c4 be fa fe          	les    di,DWORD PTR [bp-0x106]
    30b0:	06                   	push   es
    30b1:	57                   	push   di
    30b2:	9a 53 1d 55 33       	call   0x3355:0x1d53
    30b7:	8d be 00 ff          	lea    di,[bp-0x100]
    30bb:	16                   	push   ss
    30bc:	57                   	push   di
    30bd:	68 ff 00             	push   0xff
    30c0:	9a e7 17 d6 30       	call   0x30d6:0x17e7
    30c5:	ff 76 0e             	push   WORD PTR [bp+0xe]
    30c8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    30cb:	bf 26 06             	mov    di,0x626
    30ce:	b8 e6 30             	mov    ax,0x30e6
    30d1:	50                   	push   ax
    30d2:	57                   	push   di
    30d3:	9a 55 22 ed 30       	call   0x30ed:0x2255
    30d8:	08 c0                	or     al,al
    30da:	74 4a                	je     0x3126
    30dc:	ff 76 0e             	push   WORD PTR [bp+0xe]
    30df:	ff 76 0c             	push   WORD PTR [bp+0xc]
    30e2:	bf 26 06             	mov    di,0x626
    30e5:	b8 ff ff             	mov    ax,0xffff
    30e8:	50                   	push   ax
    30e9:	57                   	push   di
    30ea:	9a 73 22 0f 31       	call   0x310f:0x2273
    30ef:	89 c7                	mov    di,ax
    30f1:	8e c2                	mov    es,dx
    30f3:	06                   	push   es
    30f4:	57                   	push   di
    30f5:	9a d2 6d a0 32       	call   0x32a0:0x6dd2
    30fa:	08 c0                	or     al,al
    30fc:	74 15                	je     0x3113
    30fe:	bf 20 2e             	mov    di,0x2e20
    3101:	0e                   	push   cs
    3102:	57                   	push   di
    3103:	8d be 00 ff          	lea    di,[bp-0x100]
    3107:	16                   	push   ss
    3108:	57                   	push   di
    3109:	68 ff 00             	push   0xff
    310c:	9a e7 17 24 31       	call   0x3124:0x17e7
    3111:	eb 13                	jmp    0x3126
    3113:	bf 24 2e             	mov    di,0x2e24
    3116:	0e                   	push   cs
    3117:	57                   	push   di
    3118:	8d be 00 ff          	lea    di,[bp-0x100]
    311c:	16                   	push   ss
    311d:	57                   	push   di
    311e:	68 ff 00             	push   0xff
    3121:	9a e7 17 3a 31       	call   0x313a:0x17e7
    3126:	8b 7e 06             	mov    di,WORD PTR [bp+0x6]
    3129:	36 83 7d 0a 01       	cmp    WORD PTR ss:[di+0xa],0x1
    312e:	74 03                	je     0x3133
    3130:	e9 e7 00             	jmp    0x321a
    3133:	8a 46 08             	mov    al,BYTE PTR [bp+0x8]
    3136:	50                   	push   ax
    3137:	9a f9 1e 69 31       	call   0x3169:0x1ef9
    313c:	3c 47                	cmp    al,0x47
    313e:	75 30                	jne    0x3170
    3140:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3145:	b0 00                	mov    al,0x0
    3147:	76 01                	jbe    0x314a
    3149:	40                   	inc    ax
    314a:	8a d0                	mov    dl,al
    314c:	80 be 01 ff 20       	cmp    BYTE PTR [bp-0xff],0x20
    3151:	b0 00                	mov    al,0x0
    3153:	75 01                	jne    0x3156
    3155:	40                   	inc    ax
    3156:	22 c2                	and    al,dl
    3158:	08 c0                	or     al,al
    315a:	74 11                	je     0x316d
    315c:	8d be 00 ff          	lea    di,[bp-0x100]
    3160:	16                   	push   ss
    3161:	57                   	push   di
    3162:	6a 01                	push   0x1
    3164:	6a 01                	push   0x1
    3166:	9a 75 19 86 31       	call   0x3186:0x1975
    316b:	eb d3                	jmp    0x3140
    316d:	e9 aa 00             	jmp    0x321a
    3170:	3c 43                	cmp    al,0x43
    3172:	75 52                	jne    0x31c6
    3174:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    3178:	30 e4                	xor    ah,ah
    317a:	8b d0                	mov    dx,ax
    317c:	b8 12 00             	mov    ax,0x12
    317f:	2b c2                	sub    ax,dx
    3181:	71 05                	jno    0x3188
    3183:	9a 3e 04 a7 31       	call   0x31a7:0x43e
    3188:	d1 e8                	shr    ax,1
    318a:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    318e:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    3193:	7e 2f                	jle    0x31c4
    3195:	ff 8e fe fe          	dec    WORD PTR [bp-0x102]
    3199:	8d be fe fd          	lea    di,[bp-0x202]
    319d:	16                   	push   ss
    319e:	57                   	push   di
    319f:	bf 1e 2e             	mov    di,0x2e1e
    31a2:	0e                   	push   cs
    31a3:	57                   	push   di
    31a4:	9a cd 17 b2 31       	call   0x31b2:0x17cd
    31a9:	8d be 00 ff          	lea    di,[bp-0x100]
    31ad:	16                   	push   ss
    31ae:	57                   	push   di
    31af:	9a 4c 18 c0 31       	call   0x31c0:0x184c
    31b4:	8d be 00 ff          	lea    di,[bp-0x100]
    31b8:	16                   	push   ss
    31b9:	57                   	push   di
    31ba:	68 ff 00             	push   0xff
    31bd:	9a e7 17 dc 31       	call   0x31dc:0x17e7
    31c2:	eb ca                	jmp    0x318e
    31c4:	eb 54                	jmp    0x321a
    31c6:	3c 44                	cmp    al,0x44
    31c8:	75 50                	jne    0x321a
    31ca:	8a 86 00 ff          	mov    al,BYTE PTR [bp-0x100]
    31ce:	30 e4                	xor    ah,ah
    31d0:	8b d0                	mov    dx,ax
    31d2:	b8 12 00             	mov    ax,0x12
    31d5:	2b c2                	sub    ax,dx
    31d7:	71 05                	jno    0x31de
    31d9:	9a 3e 04 fb 31       	call   0x31fb:0x43e
    31de:	89 86 fe fe          	mov    WORD PTR [bp-0x102],ax
    31e2:	83 be fe fe 00       	cmp    WORD PTR [bp-0x102],0x0
    31e7:	7e 2f                	jle    0x3218
    31e9:	ff 8e fe fe          	dec    WORD PTR [bp-0x102]
    31ed:	8d be fe fd          	lea    di,[bp-0x202]
    31f1:	16                   	push   ss
    31f2:	57                   	push   di
    31f3:	bf 1e 2e             	mov    di,0x2e1e
    31f6:	0e                   	push   cs
    31f7:	57                   	push   di
    31f8:	9a cd 17 06 32       	call   0x3206:0x17cd
    31fd:	8d be 00 ff          	lea    di,[bp-0x100]
    3201:	16                   	push   ss
    3202:	57                   	push   di
    3203:	9a 4c 18 14 32       	call   0x3214:0x184c
    3208:	8d be 00 ff          	lea    di,[bp-0x100]
    320c:	16                   	push   ss
    320d:	57                   	push   di
    320e:	68 ff 00             	push   0xff
    3211:	9a e7 17 28 32       	call   0x3228:0x17e7
    3216:	eb ca                	jmp    0x31e2
    3218:	eb 00                	jmp    0x321a
    321a:	8d be fe fd          	lea    di,[bp-0x202]
    321e:	16                   	push   ss
    321f:	57                   	push   di
    3220:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3223:	06                   	push   es
    3224:	57                   	push   di
    3225:	9a cd 17 33 32       	call   0x3233:0x17cd
    322a:	8d be 00 ff          	lea    di,[bp-0x100]
    322e:	16                   	push   ss
    322f:	57                   	push   di
    3230:	9a 4c 18 40 32       	call   0x3240:0x184c
    3235:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    3238:	06                   	push   es
    3239:	57                   	push   di
    323a:	ff 76 10             	push   WORD PTR [bp+0x10]
    323d:	9a e7 17 57 32       	call   0x3257:0x17e7
    3242:	c9                   	leave
    3243:	ca 10 00             	retf   0x10
    3246:	01 09                	add    WORD PTR [bx+di],cx
    3248:	01 20                	add    WORD PTR [bx+si],sp
    324a:	00 02                	add    BYTE PTR [bp+si],al
    324c:	3a 20                	cmp    ah,BYTE PTR [bx+si]
    324e:	55                   	push   bp
    324f:	89 e5                	mov    bp,sp
    3251:	b8 06 04             	mov    ax,0x406
    3254:	9a 44 04 76 32       	call   0x3276:0x444
    3259:	81 ec 06 04          	sub    sp,0x406
    325d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3260:	3d 00 00             	cmp    ax,0x0
    3263:	75 15                	jne    0x327a
    3265:	bf 46 32             	mov    di,0x3246
    3268:	0e                   	push   cs
    3269:	57                   	push   di
    326a:	8d be 00 ff          	lea    di,[bp-0x100]
    326e:	16                   	push   ss
    326f:	57                   	push   di
    3270:	68 ff 00             	push   0xff
    3273:	9a e7 17 36 33       	call   0x3336:0x17e7
    3278:	eb 11                	jmp    0x328b
    327a:	3d 01 00             	cmp    ax,0x1
    327d:	75 07                	jne    0x3286
    327f:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    3284:	eb 05                	jmp    0x328b
    3286:	c6 86 00 ff 00       	mov    BYTE PTR [bp-0x100],0x0
    328b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    328e:	26 c4 bd 10 04       	les    di,DWORD PTR es:[di+0x410]
    3293:	89 be fa fd          	mov    WORD PTR [bp-0x206],di
    3297:	8c 86 fc fd          	mov    WORD PTR [bp-0x204],es
    329b:	06                   	push   es
    329c:	57                   	push   di
    329d:	9a e3 49 ff ff       	call   0xffff:0x49e3
    32a2:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    32a7:	8d be 00 fe          	lea    di,[bp-0x200]
    32ab:	16                   	push   ss
    32ac:	57                   	push   di
    32ad:	68 ff 00             	push   0xff
    32b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32b3:	26 ff b5 86 01       	push   WORD PTR es:[di+0x186]
    32b8:	26 ff b5 84 01       	push   WORD PTR es:[di+0x184]
    32bd:	6a 0a                	push   0xa
    32bf:	6a 67                	push   0x67
    32c1:	55                   	push   bp
    32c2:	9a 28 2e e5 32       	call   0x32e5:0x2e28
    32c7:	8d be 00 fe          	lea    di,[bp-0x200]
    32cb:	16                   	push   ss
    32cc:	57                   	push   di
    32cd:	68 ff 00             	push   0xff
    32d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32d3:	26 ff b5 8a 01       	push   WORD PTR es:[di+0x18a]
    32d8:	26 ff b5 88 01       	push   WORD PTR es:[di+0x188]
    32dd:	6a 14                	push   0x14
    32df:	6a 67                	push   0x67
    32e1:	55                   	push   bp
    32e2:	9a 28 2e 05 33       	call   0x3305:0x2e28
    32e7:	8d be 00 fe          	lea    di,[bp-0x200]
    32eb:	16                   	push   ss
    32ec:	57                   	push   di
    32ed:	68 ff 00             	push   0xff
    32f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32f3:	26 ff b5 8e 01       	push   WORD PTR es:[di+0x18e]
    32f8:	26 ff b5 8c 01       	push   WORD PTR es:[di+0x18c]
    32fd:	6a 25                	push   0x25
    32ff:	6a 67                	push   0x67
    3301:	55                   	push   bp
    3302:	9a 28 2e 25 33       	call   0x3325:0x2e28
    3307:	8d be 00 fe          	lea    di,[bp-0x200]
    330b:	16                   	push   ss
    330c:	57                   	push   di
    330d:	68 ff 00             	push   0xff
    3310:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3313:	26 ff b5 92 01       	push   WORD PTR es:[di+0x192]
    3318:	26 ff b5 90 01       	push   WORD PTR es:[di+0x190]
    331d:	6a 46                	push   0x46
    331f:	6a 67                	push   0x67
    3321:	55                   	push   bp
    3322:	9a 28 2e c4 33       	call   0x33c4:0x2e28
    3327:	8d be fa fc          	lea    di,[bp-0x306]
    332b:	16                   	push   ss
    332c:	57                   	push   di
    332d:	8d be 00 fe          	lea    di,[bp-0x200]
    3331:	16                   	push   ss
    3332:	57                   	push   di
    3333:	9a cd 17 40 33       	call   0x3340:0x17cd
    3338:	bf 48 32             	mov    di,0x3248
    333b:	0e                   	push   cs
    333c:	57                   	push   di
    333d:	9a 4c 18 5a 33       	call   0x335a:0x184c
    3342:	8d be fa fb          	lea    di,[bp-0x406]
    3346:	16                   	push   ss
    3347:	57                   	push   di
    3348:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    334b:	26 c4 bd 94 01       	les    di,DWORD PTR es:[di+0x194]
    3350:	06                   	push   es
    3351:	57                   	push   di
    3352:	9a 53 1d 19 41       	call   0x4119:0x1d53
    3357:	9a 4c 18 68 33       	call   0x3368:0x184c
    335c:	8d be 00 fe          	lea    di,[bp-0x200]
    3360:	16                   	push   ss
    3361:	57                   	push   di
    3362:	68 ff 00             	push   0xff
    3365:	9a e7 17 fa 40       	call   0x40fa:0x17e7
    336a:	8d be 00 fe          	lea    di,[bp-0x200]
    336e:	16                   	push   ss
    336f:	57                   	push   di
    3370:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3374:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3379:	06                   	push   es
    337a:	57                   	push   di
    337b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    337e:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3382:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    3386:	75 17                	jne    0x339f
    3388:	bf 4a 32             	mov    di,0x324a
    338b:	0e                   	push   cs
    338c:	57                   	push   di
    338d:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3391:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3396:	06                   	push   es
    3397:	57                   	push   di
    3398:	26 c4 3d             	les    di,DWORD PTR es:[di]
    339b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    339f:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    33a4:	8d be 00 fe          	lea    di,[bp-0x200]
    33a8:	16                   	push   ss
    33a9:	57                   	push   di
    33aa:	68 ff 00             	push   0xff
    33ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33b0:	26 ff b5 a2 01       	push   WORD PTR es:[di+0x1a2]
    33b5:	26 ff b5 a0 01       	push   WORD PTR es:[di+0x1a0]
    33ba:	ff 36 54 02          	push   WORD PTR ds:0x254
    33be:	6a 67                	push   0x67
    33c0:	55                   	push   bp
    33c1:	9a 28 2e 0a 34       	call   0x340a:0x2e28
    33c6:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    33cb:	76 18                	jbe    0x33e5
    33cd:	8d be 00 fe          	lea    di,[bp-0x200]
    33d1:	16                   	push   ss
    33d2:	57                   	push   di
    33d3:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    33d7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    33dc:	06                   	push   es
    33dd:	57                   	push   di
    33de:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33e1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    33e5:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    33ea:	8d be 00 fe          	lea    di,[bp-0x200]
    33ee:	16                   	push   ss
    33ef:	57                   	push   di
    33f0:	68 ff 00             	push   0xff
    33f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33f6:	26 ff b5 a6 01       	push   WORD PTR es:[di+0x1a6]
    33fb:	26 ff b5 a4 01       	push   WORD PTR es:[di+0x1a4]
    3400:	ff 36 56 02          	push   WORD PTR ds:0x256
    3404:	6a 67                	push   0x67
    3406:	55                   	push   bp
    3407:	9a 28 2e 2c 34       	call   0x342c:0x2e28
    340c:	8d be 00 fe          	lea    di,[bp-0x200]
    3410:	16                   	push   ss
    3411:	57                   	push   di
    3412:	68 ff 00             	push   0xff
    3415:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3418:	26 ff b5 c2 01       	push   WORD PTR es:[di+0x1c2]
    341d:	26 ff b5 c0 01       	push   WORD PTR es:[di+0x1c0]
    3422:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3426:	6a 64                	push   0x64
    3428:	55                   	push   bp
    3429:	9a 28 2e 72 34       	call   0x3472:0x2e28
    342e:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3433:	76 18                	jbe    0x344d
    3435:	8d be 00 fe          	lea    di,[bp-0x200]
    3439:	16                   	push   ss
    343a:	57                   	push   di
    343b:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    343f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3444:	06                   	push   es
    3445:	57                   	push   di
    3446:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3449:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    344d:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3452:	8d be 00 fe          	lea    di,[bp-0x200]
    3456:	16                   	push   ss
    3457:	57                   	push   di
    3458:	68 ff 00             	push   0xff
    345b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    345e:	26 ff b5 ba 01       	push   WORD PTR es:[di+0x1ba]
    3463:	26 ff b5 b8 01       	push   WORD PTR es:[di+0x1b8]
    3468:	ff 36 56 02          	push   WORD PTR ds:0x256
    346c:	6a 67                	push   0x67
    346e:	55                   	push   bp
    346f:	9a 28 2e 94 34       	call   0x3494:0x2e28
    3474:	8d be 00 fe          	lea    di,[bp-0x200]
    3478:	16                   	push   ss
    3479:	57                   	push   di
    347a:	68 ff 00             	push   0xff
    347d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3480:	26 ff b5 d6 01       	push   WORD PTR es:[di+0x1d6]
    3485:	26 ff b5 d4 01       	push   WORD PTR es:[di+0x1d4]
    348a:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    348e:	6a 64                	push   0x64
    3490:	55                   	push   bp
    3491:	9a 28 2e da 34       	call   0x34da:0x2e28
    3496:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    349b:	76 18                	jbe    0x34b5
    349d:	8d be 00 fe          	lea    di,[bp-0x200]
    34a1:	16                   	push   ss
    34a2:	57                   	push   di
    34a3:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    34a7:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    34ac:	06                   	push   es
    34ad:	57                   	push   di
    34ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    34b1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    34b5:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    34ba:	8d be 00 fe          	lea    di,[bp-0x200]
    34be:	16                   	push   ss
    34bf:	57                   	push   di
    34c0:	68 ff 00             	push   0xff
    34c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c6:	26 ff b5 be 01       	push   WORD PTR es:[di+0x1be]
    34cb:	26 ff b5 bc 01       	push   WORD PTR es:[di+0x1bc]
    34d0:	ff 36 56 02          	push   WORD PTR ds:0x256
    34d4:	6a 67                	push   0x67
    34d6:	55                   	push   bp
    34d7:	9a 28 2e fc 34       	call   0x34fc:0x2e28
    34dc:	8d be 00 fe          	lea    di,[bp-0x200]
    34e0:	16                   	push   ss
    34e1:	57                   	push   di
    34e2:	68 ff 00             	push   0xff
    34e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34e8:	26 ff b5 da 01       	push   WORD PTR es:[di+0x1da]
    34ed:	26 ff b5 d8 01       	push   WORD PTR es:[di+0x1d8]
    34f2:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    34f6:	6a 64                	push   0x64
    34f8:	55                   	push   bp
    34f9:	9a 28 2e 42 35       	call   0x3542:0x2e28
    34fe:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3503:	76 18                	jbe    0x351d
    3505:	8d be 00 fe          	lea    di,[bp-0x200]
    3509:	16                   	push   ss
    350a:	57                   	push   di
    350b:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    350f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3514:	06                   	push   es
    3515:	57                   	push   di
    3516:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3519:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    351d:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3522:	8d be 00 fe          	lea    di,[bp-0x200]
    3526:	16                   	push   ss
    3527:	57                   	push   di
    3528:	68 ff 00             	push   0xff
    352b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    352e:	26 ff b5 b6 01       	push   WORD PTR es:[di+0x1b6]
    3533:	26 ff b5 b4 01       	push   WORD PTR es:[di+0x1b4]
    3538:	ff 36 56 02          	push   WORD PTR ds:0x256
    353c:	6a 67                	push   0x67
    353e:	55                   	push   bp
    353f:	9a 28 2e 64 35       	call   0x3564:0x2e28
    3544:	8d be 00 fe          	lea    di,[bp-0x200]
    3548:	16                   	push   ss
    3549:	57                   	push   di
    354a:	68 ff 00             	push   0xff
    354d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3550:	26 ff b5 d2 01       	push   WORD PTR es:[di+0x1d2]
    3555:	26 ff b5 d0 01       	push   WORD PTR es:[di+0x1d0]
    355a:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    355e:	6a 64                	push   0x64
    3560:	55                   	push   bp
    3561:	9a 28 2e aa 35       	call   0x35aa:0x2e28
    3566:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    356b:	76 18                	jbe    0x3585
    356d:	8d be 00 fe          	lea    di,[bp-0x200]
    3571:	16                   	push   ss
    3572:	57                   	push   di
    3573:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3577:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    357c:	06                   	push   es
    357d:	57                   	push   di
    357e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3581:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3585:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    358a:	8d be 00 fe          	lea    di,[bp-0x200]
    358e:	16                   	push   ss
    358f:	57                   	push   di
    3590:	68 ff 00             	push   0xff
    3593:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3596:	26 ff b5 ae 01       	push   WORD PTR es:[di+0x1ae]
    359b:	26 ff b5 ac 01       	push   WORD PTR es:[di+0x1ac]
    35a0:	ff 36 56 02          	push   WORD PTR ds:0x256
    35a4:	6a 67                	push   0x67
    35a6:	55                   	push   bp
    35a7:	9a 28 2e cc 35       	call   0x35cc:0x2e28
    35ac:	8d be 00 fe          	lea    di,[bp-0x200]
    35b0:	16                   	push   ss
    35b1:	57                   	push   di
    35b2:	68 ff 00             	push   0xff
    35b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35b8:	26 ff b5 ca 01       	push   WORD PTR es:[di+0x1ca]
    35bd:	26 ff b5 c8 01       	push   WORD PTR es:[di+0x1c8]
    35c2:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    35c6:	6a 64                	push   0x64
    35c8:	55                   	push   bp
    35c9:	9a 28 2e 12 36       	call   0x3612:0x2e28
    35ce:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    35d3:	76 18                	jbe    0x35ed
    35d5:	8d be 00 fe          	lea    di,[bp-0x200]
    35d9:	16                   	push   ss
    35da:	57                   	push   di
    35db:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    35df:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    35e4:	06                   	push   es
    35e5:	57                   	push   di
    35e6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    35e9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    35ed:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    35f2:	8d be 00 fe          	lea    di,[bp-0x200]
    35f6:	16                   	push   ss
    35f7:	57                   	push   di
    35f8:	68 ff 00             	push   0xff
    35fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35fe:	26 ff b5 aa 01       	push   WORD PTR es:[di+0x1aa]
    3603:	26 ff b5 a8 01       	push   WORD PTR es:[di+0x1a8]
    3608:	ff 36 56 02          	push   WORD PTR ds:0x256
    360c:	6a 67                	push   0x67
    360e:	55                   	push   bp
    360f:	9a 28 2e 34 36       	call   0x3634:0x2e28
    3614:	8d be 00 fe          	lea    di,[bp-0x200]
    3618:	16                   	push   ss
    3619:	57                   	push   di
    361a:	68 ff 00             	push   0xff
    361d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3620:	26 ff b5 c6 01       	push   WORD PTR es:[di+0x1c6]
    3625:	26 ff b5 c4 01       	push   WORD PTR es:[di+0x1c4]
    362a:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    362e:	6a 64                	push   0x64
    3630:	55                   	push   bp
    3631:	9a 28 2e 7a 36       	call   0x367a:0x2e28
    3636:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    363b:	76 18                	jbe    0x3655
    363d:	8d be 00 fe          	lea    di,[bp-0x200]
    3641:	16                   	push   ss
    3642:	57                   	push   di
    3643:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3647:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    364c:	06                   	push   es
    364d:	57                   	push   di
    364e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3651:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3655:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    365a:	8d be 00 fe          	lea    di,[bp-0x200]
    365e:	16                   	push   ss
    365f:	57                   	push   di
    3660:	68 ff 00             	push   0xff
    3663:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3666:	26 ff b5 b2 01       	push   WORD PTR es:[di+0x1b2]
    366b:	26 ff b5 b0 01       	push   WORD PTR es:[di+0x1b0]
    3670:	ff 36 56 02          	push   WORD PTR ds:0x256
    3674:	6a 67                	push   0x67
    3676:	55                   	push   bp
    3677:	9a 28 2e 9c 36       	call   0x369c:0x2e28
    367c:	8d be 00 fe          	lea    di,[bp-0x200]
    3680:	16                   	push   ss
    3681:	57                   	push   di
    3682:	68 ff 00             	push   0xff
    3685:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3688:	26 ff b5 ce 01       	push   WORD PTR es:[di+0x1ce]
    368d:	26 ff b5 cc 01       	push   WORD PTR es:[di+0x1cc]
    3692:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3696:	6a 64                	push   0x64
    3698:	55                   	push   bp
    3699:	9a 28 2e ff 36       	call   0x36ff:0x2e28
    369e:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    36a3:	76 18                	jbe    0x36bd
    36a5:	8d be 00 fe          	lea    di,[bp-0x200]
    36a9:	16                   	push   ss
    36aa:	57                   	push   di
    36ab:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    36af:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    36b4:	06                   	push   es
    36b5:	57                   	push   di
    36b6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36b9:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    36bd:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    36c1:	75 17                	jne    0x36da
    36c3:	bf 4a 32             	mov    di,0x324a
    36c6:	0e                   	push   cs
    36c7:	57                   	push   di
    36c8:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    36cc:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    36d1:	06                   	push   es
    36d2:	57                   	push   di
    36d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36d6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    36da:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    36df:	8d be 00 fe          	lea    di,[bp-0x200]
    36e3:	16                   	push   ss
    36e4:	57                   	push   di
    36e5:	68 ff 00             	push   0xff
    36e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36eb:	26 ff b5 de 01       	push   WORD PTR es:[di+0x1de]
    36f0:	26 ff b5 dc 01       	push   WORD PTR es:[di+0x1dc]
    36f5:	ff 36 54 02          	push   WORD PTR ds:0x254
    36f9:	6a 67                	push   0x67
    36fb:	55                   	push   bp
    36fc:	9a 28 2e 3e 37       	call   0x373e:0x2e28
    3701:	8d be 00 fe          	lea    di,[bp-0x200]
    3705:	16                   	push   ss
    3706:	57                   	push   di
    3707:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    370b:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3710:	06                   	push   es
    3711:	57                   	push   di
    3712:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3715:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3719:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    371e:	8d be 00 fe          	lea    di,[bp-0x200]
    3722:	16                   	push   ss
    3723:	57                   	push   di
    3724:	68 ff 00             	push   0xff
    3727:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    372a:	26 ff b5 e2 01       	push   WORD PTR es:[di+0x1e2]
    372f:	26 ff b5 e0 01       	push   WORD PTR es:[di+0x1e0]
    3734:	ff 36 56 02          	push   WORD PTR ds:0x256
    3738:	6a 67                	push   0x67
    373a:	55                   	push   bp
    373b:	9a 28 2e 60 37       	call   0x3760:0x2e28
    3740:	8d be 00 fe          	lea    di,[bp-0x200]
    3744:	16                   	push   ss
    3745:	57                   	push   di
    3746:	68 ff 00             	push   0xff
    3749:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    374c:	26 ff b5 ea 01       	push   WORD PTR es:[di+0x1ea]
    3751:	26 ff b5 e8 01       	push   WORD PTR es:[di+0x1e8]
    3756:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    375a:	6a 64                	push   0x64
    375c:	55                   	push   bp
    375d:	9a 28 2e a6 37       	call   0x37a6:0x2e28
    3762:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3767:	76 18                	jbe    0x3781
    3769:	8d be 00 fe          	lea    di,[bp-0x200]
    376d:	16                   	push   ss
    376e:	57                   	push   di
    376f:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3773:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3778:	06                   	push   es
    3779:	57                   	push   di
    377a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    377d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3781:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3786:	8d be 00 fe          	lea    di,[bp-0x200]
    378a:	16                   	push   ss
    378b:	57                   	push   di
    378c:	68 ff 00             	push   0xff
    378f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3792:	26 ff b5 e6 01       	push   WORD PTR es:[di+0x1e6]
    3797:	26 ff b5 e4 01       	push   WORD PTR es:[di+0x1e4]
    379c:	ff 36 56 02          	push   WORD PTR ds:0x256
    37a0:	6a 67                	push   0x67
    37a2:	55                   	push   bp
    37a3:	9a 28 2e c8 37       	call   0x37c8:0x2e28
    37a8:	8d be 00 fe          	lea    di,[bp-0x200]
    37ac:	16                   	push   ss
    37ad:	57                   	push   di
    37ae:	68 ff 00             	push   0xff
    37b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37b4:	26 ff b5 ee 01       	push   WORD PTR es:[di+0x1ee]
    37b9:	26 ff b5 ec 01       	push   WORD PTR es:[di+0x1ec]
    37be:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    37c2:	6a 64                	push   0x64
    37c4:	55                   	push   bp
    37c5:	9a 28 2e 2b 38       	call   0x382b:0x2e28
    37ca:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    37cf:	76 18                	jbe    0x37e9
    37d1:	8d be 00 fe          	lea    di,[bp-0x200]
    37d5:	16                   	push   ss
    37d6:	57                   	push   di
    37d7:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    37db:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    37e0:	06                   	push   es
    37e1:	57                   	push   di
    37e2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    37e5:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    37e9:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    37ed:	75 17                	jne    0x3806
    37ef:	bf 4a 32             	mov    di,0x324a
    37f2:	0e                   	push   cs
    37f3:	57                   	push   di
    37f4:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    37f8:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    37fd:	06                   	push   es
    37fe:	57                   	push   di
    37ff:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3802:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3806:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    380b:	8d be 00 fe          	lea    di,[bp-0x200]
    380f:	16                   	push   ss
    3810:	57                   	push   di
    3811:	68 ff 00             	push   0xff
    3814:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3817:	26 ff b5 f2 01       	push   WORD PTR es:[di+0x1f2]
    381c:	26 ff b5 f0 01       	push   WORD PTR es:[di+0x1f0]
    3821:	ff 36 54 02          	push   WORD PTR ds:0x254
    3825:	6a 67                	push   0x67
    3827:	55                   	push   bp
    3828:	9a 28 2e 4d 38       	call   0x384d:0x2e28
    382d:	8d be 00 fe          	lea    di,[bp-0x200]
    3831:	16                   	push   ss
    3832:	57                   	push   di
    3833:	68 ff 00             	push   0xff
    3836:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3839:	26 ff b5 fa 01       	push   WORD PTR es:[di+0x1fa]
    383e:	26 ff b5 f8 01       	push   WORD PTR es:[di+0x1f8]
    3843:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3847:	6a 64                	push   0x64
    3849:	55                   	push   bp
    384a:	9a 28 2e 6f 38       	call   0x386f:0x2e28
    384f:	8d be 00 fe          	lea    di,[bp-0x200]
    3853:	16                   	push   ss
    3854:	57                   	push   di
    3855:	68 ff 00             	push   0xff
    3858:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    385b:	26 ff b5 1a 02       	push   WORD PTR es:[di+0x21a]
    3860:	26 ff b5 18 02       	push   WORD PTR es:[di+0x218]
    3865:	ff 36 5c 02          	push   WORD PTR ds:0x25c
    3869:	6a 64                	push   0x64
    386b:	55                   	push   bp
    386c:	9a 28 2e b5 38       	call   0x38b5:0x2e28
    3871:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3876:	76 18                	jbe    0x3890
    3878:	8d be 00 fe          	lea    di,[bp-0x200]
    387c:	16                   	push   ss
    387d:	57                   	push   di
    387e:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3882:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3887:	06                   	push   es
    3888:	57                   	push   di
    3889:	26 c4 3d             	les    di,DWORD PTR es:[di]
    388c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3890:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3895:	8d be 00 fe          	lea    di,[bp-0x200]
    3899:	16                   	push   ss
    389a:	57                   	push   di
    389b:	68 ff 00             	push   0xff
    389e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38a1:	26 ff b5 1e 04       	push   WORD PTR es:[di+0x41e]
    38a6:	26 ff b5 1c 04       	push   WORD PTR es:[di+0x41c]
    38ab:	ff 36 56 02          	push   WORD PTR ds:0x256
    38af:	6a 67                	push   0x67
    38b1:	55                   	push   bp
    38b2:	9a 28 2e d7 38       	call   0x38d7:0x2e28
    38b7:	8d be 00 fe          	lea    di,[bp-0x200]
    38bb:	16                   	push   ss
    38bc:	57                   	push   di
    38bd:	68 ff 00             	push   0xff
    38c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38c3:	26 ff b5 22 04       	push   WORD PTR es:[di+0x422]
    38c8:	26 ff b5 20 04       	push   WORD PTR es:[di+0x420]
    38cd:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    38d1:	6a 64                	push   0x64
    38d3:	55                   	push   bp
    38d4:	9a 28 2e f9 38       	call   0x38f9:0x2e28
    38d9:	8d be 00 fe          	lea    di,[bp-0x200]
    38dd:	16                   	push   ss
    38de:	57                   	push   di
    38df:	68 ff 00             	push   0xff
    38e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38e5:	26 ff b5 26 04       	push   WORD PTR es:[di+0x426]
    38ea:	26 ff b5 24 04       	push   WORD PTR es:[di+0x424]
    38ef:	ff 36 5c 02          	push   WORD PTR ds:0x25c
    38f3:	6a 64                	push   0x64
    38f5:	55                   	push   bp
    38f6:	9a 28 2e 5c 39       	call   0x395c:0x2e28
    38fb:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3900:	76 18                	jbe    0x391a
    3902:	8d be 00 fe          	lea    di,[bp-0x200]
    3906:	16                   	push   ss
    3907:	57                   	push   di
    3908:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    390c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3911:	06                   	push   es
    3912:	57                   	push   di
    3913:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3916:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    391a:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    391e:	75 17                	jne    0x3937
    3920:	bf 4a 32             	mov    di,0x324a
    3923:	0e                   	push   cs
    3924:	57                   	push   di
    3925:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3929:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    392e:	06                   	push   es
    392f:	57                   	push   di
    3930:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3933:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3937:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    393c:	8d be 00 fe          	lea    di,[bp-0x200]
    3940:	16                   	push   ss
    3941:	57                   	push   di
    3942:	68 ff 00             	push   0xff
    3945:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3948:	26 ff b5 32 02       	push   WORD PTR es:[di+0x232]
    394d:	26 ff b5 30 02       	push   WORD PTR es:[di+0x230]
    3952:	ff 36 54 02          	push   WORD PTR ds:0x254
    3956:	6a 67                	push   0x67
    3958:	55                   	push   bp
    3959:	9a 28 2e 9b 39       	call   0x399b:0x2e28
    395e:	8d be 00 fe          	lea    di,[bp-0x200]
    3962:	16                   	push   ss
    3963:	57                   	push   di
    3964:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3968:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    396d:	06                   	push   es
    396e:	57                   	push   di
    396f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3972:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3976:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    397b:	8d be 00 fe          	lea    di,[bp-0x200]
    397f:	16                   	push   ss
    3980:	57                   	push   di
    3981:	68 ff 00             	push   0xff
    3984:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3987:	26 ff b5 3a 02       	push   WORD PTR es:[di+0x23a]
    398c:	26 ff b5 38 02       	push   WORD PTR es:[di+0x238]
    3991:	ff 36 56 02          	push   WORD PTR ds:0x256
    3995:	6a 67                	push   0x67
    3997:	55                   	push   bp
    3998:	9a 28 2e bd 39       	call   0x39bd:0x2e28
    399d:	8d be 00 fe          	lea    di,[bp-0x200]
    39a1:	16                   	push   ss
    39a2:	57                   	push   di
    39a3:	68 ff 00             	push   0xff
    39a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39a9:	26 ff b5 42 02       	push   WORD PTR es:[di+0x242]
    39ae:	26 ff b5 40 02       	push   WORD PTR es:[di+0x240]
    39b3:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    39b7:	6a 64                	push   0x64
    39b9:	55                   	push   bp
    39ba:	9a 28 2e 03 3a       	call   0x3a03:0x2e28
    39bf:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    39c4:	76 18                	jbe    0x39de
    39c6:	8d be 00 fe          	lea    di,[bp-0x200]
    39ca:	16                   	push   ss
    39cb:	57                   	push   di
    39cc:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    39d0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    39d5:	06                   	push   es
    39d6:	57                   	push   di
    39d7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39da:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    39de:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    39e3:	8d be 00 fe          	lea    di,[bp-0x200]
    39e7:	16                   	push   ss
    39e8:	57                   	push   di
    39e9:	68 ff 00             	push   0xff
    39ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39ef:	26 ff b5 36 02       	push   WORD PTR es:[di+0x236]
    39f4:	26 ff b5 34 02       	push   WORD PTR es:[di+0x234]
    39f9:	ff 36 56 02          	push   WORD PTR ds:0x256
    39fd:	6a 67                	push   0x67
    39ff:	55                   	push   bp
    3a00:	9a 28 2e 25 3a       	call   0x3a25:0x2e28
    3a05:	8d be 00 fe          	lea    di,[bp-0x200]
    3a09:	16                   	push   ss
    3a0a:	57                   	push   di
    3a0b:	68 ff 00             	push   0xff
    3a0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a11:	26 ff b5 3e 02       	push   WORD PTR es:[di+0x23e]
    3a16:	26 ff b5 3c 02       	push   WORD PTR es:[di+0x23c]
    3a1b:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3a1f:	6a 64                	push   0x64
    3a21:	55                   	push   bp
    3a22:	9a 28 2e 6b 3a       	call   0x3a6b:0x2e28
    3a27:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3a2c:	76 18                	jbe    0x3a46
    3a2e:	8d be 00 fe          	lea    di,[bp-0x200]
    3a32:	16                   	push   ss
    3a33:	57                   	push   di
    3a34:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3a38:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3a3d:	06                   	push   es
    3a3e:	57                   	push   di
    3a3f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3a42:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3a46:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3a4b:	8d be 00 fe          	lea    di,[bp-0x200]
    3a4f:	16                   	push   ss
    3a50:	57                   	push   di
    3a51:	68 ff 00             	push   0xff
    3a54:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a57:	26 ff b5 0a 04       	push   WORD PTR es:[di+0x40a]
    3a5c:	26 ff b5 08 04       	push   WORD PTR es:[di+0x408]
    3a61:	ff 36 56 02          	push   WORD PTR ds:0x256
    3a65:	6a 67                	push   0x67
    3a67:	55                   	push   bp
    3a68:	9a 28 2e 8d 3a       	call   0x3a8d:0x2e28
    3a6d:	8d be 00 fe          	lea    di,[bp-0x200]
    3a71:	16                   	push   ss
    3a72:	57                   	push   di
    3a73:	68 ff 00             	push   0xff
    3a76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a79:	26 ff b5 0e 04       	push   WORD PTR es:[di+0x40e]
    3a7e:	26 ff b5 0c 04       	push   WORD PTR es:[di+0x40c]
    3a83:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3a87:	6a 64                	push   0x64
    3a89:	55                   	push   bp
    3a8a:	9a 28 2e f0 3a       	call   0x3af0:0x2e28
    3a8f:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3a94:	76 18                	jbe    0x3aae
    3a96:	8d be 00 fe          	lea    di,[bp-0x200]
    3a9a:	16                   	push   ss
    3a9b:	57                   	push   di
    3a9c:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3aa0:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3aa5:	06                   	push   es
    3aa6:	57                   	push   di
    3aa7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3aaa:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3aae:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    3ab2:	75 17                	jne    0x3acb
    3ab4:	bf 4a 32             	mov    di,0x324a
    3ab7:	0e                   	push   cs
    3ab8:	57                   	push   di
    3ab9:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3abd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3ac2:	06                   	push   es
    3ac3:	57                   	push   di
    3ac4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3ac7:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3acb:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3ad0:	8d be 00 fe          	lea    di,[bp-0x200]
    3ad4:	16                   	push   ss
    3ad5:	57                   	push   di
    3ad6:	68 ff 00             	push   0xff
    3ad9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3adc:	26 ff b5 46 02       	push   WORD PTR es:[di+0x246]
    3ae1:	26 ff b5 44 02       	push   WORD PTR es:[di+0x244]
    3ae6:	ff 36 54 02          	push   WORD PTR ds:0x254
    3aea:	6a 67                	push   0x67
    3aec:	55                   	push   bp
    3aed:	9a 28 2e 12 3b       	call   0x3b12:0x2e28
    3af2:	8d be 00 fe          	lea    di,[bp-0x200]
    3af6:	16                   	push   ss
    3af7:	57                   	push   di
    3af8:	68 ff 00             	push   0xff
    3afb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3afe:	26 ff b5 4e 02       	push   WORD PTR es:[di+0x24e]
    3b03:	26 ff b5 4c 02       	push   WORD PTR es:[di+0x24c]
    3b08:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3b0c:	6a 64                	push   0x64
    3b0e:	55                   	push   bp
    3b0f:	9a 28 2e 34 3b       	call   0x3b34:0x2e28
    3b14:	8d be 00 fe          	lea    di,[bp-0x200]
    3b18:	16                   	push   ss
    3b19:	57                   	push   di
    3b1a:	68 ff 00             	push   0xff
    3b1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b20:	26 ff b5 5e 02       	push   WORD PTR es:[di+0x25e]
    3b25:	26 ff b5 5c 02       	push   WORD PTR es:[di+0x25c]
    3b2a:	ff 36 5c 02          	push   WORD PTR ds:0x25c
    3b2e:	6a 64                	push   0x64
    3b30:	55                   	push   bp
    3b31:	9a 28 2e 7a 3b       	call   0x3b7a:0x2e28
    3b36:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3b3b:	76 18                	jbe    0x3b55
    3b3d:	8d be 00 fe          	lea    di,[bp-0x200]
    3b41:	16                   	push   ss
    3b42:	57                   	push   di
    3b43:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3b47:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3b4c:	06                   	push   es
    3b4d:	57                   	push   di
    3b4e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3b51:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3b55:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3b5a:	8d be 00 fe          	lea    di,[bp-0x200]
    3b5e:	16                   	push   ss
    3b5f:	57                   	push   di
    3b60:	68 ff 00             	push   0xff
    3b63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b66:	26 ff b5 52 02       	push   WORD PTR es:[di+0x252]
    3b6b:	26 ff b5 50 02       	push   WORD PTR es:[di+0x250]
    3b70:	ff 36 56 02          	push   WORD PTR ds:0x256
    3b74:	6a 67                	push   0x67
    3b76:	55                   	push   bp
    3b77:	9a 28 2e 9c 3b       	call   0x3b9c:0x2e28
    3b7c:	8d be 00 fe          	lea    di,[bp-0x200]
    3b80:	16                   	push   ss
    3b81:	57                   	push   di
    3b82:	68 ff 00             	push   0xff
    3b85:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b88:	26 ff b5 56 02       	push   WORD PTR es:[di+0x256]
    3b8d:	26 ff b5 54 02       	push   WORD PTR es:[di+0x254]
    3b92:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3b96:	6a 64                	push   0x64
    3b98:	55                   	push   bp
    3b99:	9a 28 2e be 3b       	call   0x3bbe:0x2e28
    3b9e:	8d be 00 fe          	lea    di,[bp-0x200]
    3ba2:	16                   	push   ss
    3ba3:	57                   	push   di
    3ba4:	68 ff 00             	push   0xff
    3ba7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3baa:	26 ff b5 62 02       	push   WORD PTR es:[di+0x262]
    3baf:	26 ff b5 60 02       	push   WORD PTR es:[di+0x260]
    3bb4:	ff 36 5c 02          	push   WORD PTR ds:0x25c
    3bb8:	6a 64                	push   0x64
    3bba:	55                   	push   bp
    3bbb:	9a 28 2e 21 3c       	call   0x3c21:0x2e28
    3bc0:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3bc5:	76 18                	jbe    0x3bdf
    3bc7:	8d be 00 fe          	lea    di,[bp-0x200]
    3bcb:	16                   	push   ss
    3bcc:	57                   	push   di
    3bcd:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3bd1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3bd6:	06                   	push   es
    3bd7:	57                   	push   di
    3bd8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bdb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3bdf:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    3be3:	75 17                	jne    0x3bfc
    3be5:	bf 4a 32             	mov    di,0x324a
    3be8:	0e                   	push   cs
    3be9:	57                   	push   di
    3bea:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3bee:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3bf3:	06                   	push   es
    3bf4:	57                   	push   di
    3bf5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3bf8:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3bfc:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3c01:	8d be 00 fe          	lea    di,[bp-0x200]
    3c05:	16                   	push   ss
    3c06:	57                   	push   di
    3c07:	68 ff 00             	push   0xff
    3c0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c0d:	26 ff b5 9a 02       	push   WORD PTR es:[di+0x29a]
    3c12:	26 ff b5 98 02       	push   WORD PTR es:[di+0x298]
    3c17:	ff 36 54 02          	push   WORD PTR ds:0x254
    3c1b:	6a 67                	push   0x67
    3c1d:	55                   	push   bp
    3c1e:	9a 28 2e 60 3c       	call   0x3c60:0x2e28
    3c23:	8d be 00 fe          	lea    di,[bp-0x200]
    3c27:	16                   	push   ss
    3c28:	57                   	push   di
    3c29:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3c2d:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3c32:	06                   	push   es
    3c33:	57                   	push   di
    3c34:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c37:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3c3b:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3c40:	8d be 00 fe          	lea    di,[bp-0x200]
    3c44:	16                   	push   ss
    3c45:	57                   	push   di
    3c46:	68 ff 00             	push   0xff
    3c49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c4c:	26 ff b5 9e 02       	push   WORD PTR es:[di+0x29e]
    3c51:	26 ff b5 9c 02       	push   WORD PTR es:[di+0x29c]
    3c56:	ff 36 56 02          	push   WORD PTR ds:0x256
    3c5a:	6a 67                	push   0x67
    3c5c:	55                   	push   bp
    3c5d:	9a 28 2e 82 3c       	call   0x3c82:0x2e28
    3c62:	8d be 00 fe          	lea    di,[bp-0x200]
    3c66:	16                   	push   ss
    3c67:	57                   	push   di
    3c68:	68 ff 00             	push   0xff
    3c6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c6e:	26 ff b5 aa 02       	push   WORD PTR es:[di+0x2aa]
    3c73:	26 ff b5 a8 02       	push   WORD PTR es:[di+0x2a8]
    3c78:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3c7c:	6a 64                	push   0x64
    3c7e:	55                   	push   bp
    3c7f:	9a 28 2e c8 3c       	call   0x3cc8:0x2e28
    3c84:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3c89:	76 18                	jbe    0x3ca3
    3c8b:	8d be 00 fe          	lea    di,[bp-0x200]
    3c8f:	16                   	push   ss
    3c90:	57                   	push   di
    3c91:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3c95:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3c9a:	06                   	push   es
    3c9b:	57                   	push   di
    3c9c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c9f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3ca3:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3ca8:	8d be 00 fe          	lea    di,[bp-0x200]
    3cac:	16                   	push   ss
    3cad:	57                   	push   di
    3cae:	68 ff 00             	push   0xff
    3cb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cb4:	26 ff b5 a2 02       	push   WORD PTR es:[di+0x2a2]
    3cb9:	26 ff b5 a0 02       	push   WORD PTR es:[di+0x2a0]
    3cbe:	ff 36 56 02          	push   WORD PTR ds:0x256
    3cc2:	6a 67                	push   0x67
    3cc4:	55                   	push   bp
    3cc5:	9a 28 2e ea 3c       	call   0x3cea:0x2e28
    3cca:	8d be 00 fe          	lea    di,[bp-0x200]
    3cce:	16                   	push   ss
    3ccf:	57                   	push   di
    3cd0:	68 ff 00             	push   0xff
    3cd3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cd6:	26 ff b5 ae 02       	push   WORD PTR es:[di+0x2ae]
    3cdb:	26 ff b5 ac 02       	push   WORD PTR es:[di+0x2ac]
    3ce0:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3ce4:	6a 64                	push   0x64
    3ce6:	55                   	push   bp
    3ce7:	9a 28 2e 30 3d       	call   0x3d30:0x2e28
    3cec:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3cf1:	76 18                	jbe    0x3d0b
    3cf3:	8d be 00 fe          	lea    di,[bp-0x200]
    3cf7:	16                   	push   ss
    3cf8:	57                   	push   di
    3cf9:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3cfd:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3d02:	06                   	push   es
    3d03:	57                   	push   di
    3d04:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d07:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3d0b:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3d10:	8d be 00 fe          	lea    di,[bp-0x200]
    3d14:	16                   	push   ss
    3d15:	57                   	push   di
    3d16:	68 ff 00             	push   0xff
    3d19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d1c:	26 ff b5 a6 02       	push   WORD PTR es:[di+0x2a6]
    3d21:	26 ff b5 a4 02       	push   WORD PTR es:[di+0x2a4]
    3d26:	ff 36 56 02          	push   WORD PTR ds:0x256
    3d2a:	6a 67                	push   0x67
    3d2c:	55                   	push   bp
    3d2d:	9a 28 2e 52 3d       	call   0x3d52:0x2e28
    3d32:	8d be 00 fe          	lea    di,[bp-0x200]
    3d36:	16                   	push   ss
    3d37:	57                   	push   di
    3d38:	68 ff 00             	push   0xff
    3d3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d3e:	26 ff b5 b2 02       	push   WORD PTR es:[di+0x2b2]
    3d43:	26 ff b5 b0 02       	push   WORD PTR es:[di+0x2b0]
    3d48:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3d4c:	6a 64                	push   0x64
    3d4e:	55                   	push   bp
    3d4f:	9a 28 2e b5 3d       	call   0x3db5:0x2e28
    3d54:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3d59:	76 18                	jbe    0x3d73
    3d5b:	8d be 00 fe          	lea    di,[bp-0x200]
    3d5f:	16                   	push   ss
    3d60:	57                   	push   di
    3d61:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3d65:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3d6a:	06                   	push   es
    3d6b:	57                   	push   di
    3d6c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d6f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3d73:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    3d77:	75 17                	jne    0x3d90
    3d79:	bf 4a 32             	mov    di,0x324a
    3d7c:	0e                   	push   cs
    3d7d:	57                   	push   di
    3d7e:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3d82:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3d87:	06                   	push   es
    3d88:	57                   	push   di
    3d89:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d8c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3d90:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3d95:	8d be 00 fe          	lea    di,[bp-0x200]
    3d99:	16                   	push   ss
    3d9a:	57                   	push   di
    3d9b:	68 ff 00             	push   0xff
    3d9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3da1:	26 ff b5 66 02       	push   WORD PTR es:[di+0x266]
    3da6:	26 ff b5 64 02       	push   WORD PTR es:[di+0x264]
    3dab:	ff 36 54 02          	push   WORD PTR ds:0x254
    3daf:	6a 67                	push   0x67
    3db1:	55                   	push   bp
    3db2:	9a 28 2e f4 3d       	call   0x3df4:0x2e28
    3db7:	8d be 00 fe          	lea    di,[bp-0x200]
    3dbb:	16                   	push   ss
    3dbc:	57                   	push   di
    3dbd:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3dc1:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3dc6:	06                   	push   es
    3dc7:	57                   	push   di
    3dc8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3dcb:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3dcf:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3dd4:	8d be 00 fe          	lea    di,[bp-0x200]
    3dd8:	16                   	push   ss
    3dd9:	57                   	push   di
    3dda:	68 ff 00             	push   0xff
    3ddd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3de0:	26 ff b5 6a 02       	push   WORD PTR es:[di+0x26a]
    3de5:	26 ff b5 68 02       	push   WORD PTR es:[di+0x268]
    3dea:	ff 36 56 02          	push   WORD PTR ds:0x256
    3dee:	6a 67                	push   0x67
    3df0:	55                   	push   bp
    3df1:	9a 28 2e 16 3e       	call   0x3e16:0x2e28
    3df6:	8d be 00 fe          	lea    di,[bp-0x200]
    3dfa:	16                   	push   ss
    3dfb:	57                   	push   di
    3dfc:	68 ff 00             	push   0xff
    3dff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e02:	26 ff b5 82 02       	push   WORD PTR es:[di+0x282]
    3e07:	26 ff b5 80 02       	push   WORD PTR es:[di+0x280]
    3e0c:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3e10:	6a 64                	push   0x64
    3e12:	55                   	push   bp
    3e13:	9a 28 2e 5c 3e       	call   0x3e5c:0x2e28
    3e18:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3e1d:	76 18                	jbe    0x3e37
    3e1f:	8d be 00 fe          	lea    di,[bp-0x200]
    3e23:	16                   	push   ss
    3e24:	57                   	push   di
    3e25:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3e29:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3e2e:	06                   	push   es
    3e2f:	57                   	push   di
    3e30:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e33:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3e37:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3e3c:	8d be 00 fe          	lea    di,[bp-0x200]
    3e40:	16                   	push   ss
    3e41:	57                   	push   di
    3e42:	68 ff 00             	push   0xff
    3e45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e48:	26 ff b5 6e 02       	push   WORD PTR es:[di+0x26e]
    3e4d:	26 ff b5 6c 02       	push   WORD PTR es:[di+0x26c]
    3e52:	ff 36 56 02          	push   WORD PTR ds:0x256
    3e56:	6a 67                	push   0x67
    3e58:	55                   	push   bp
    3e59:	9a 28 2e 7e 3e       	call   0x3e7e:0x2e28
    3e5e:	8d be 00 fe          	lea    di,[bp-0x200]
    3e62:	16                   	push   ss
    3e63:	57                   	push   di
    3e64:	68 ff 00             	push   0xff
    3e67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e6a:	26 ff b5 86 02       	push   WORD PTR es:[di+0x286]
    3e6f:	26 ff b5 84 02       	push   WORD PTR es:[di+0x284]
    3e74:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3e78:	6a 64                	push   0x64
    3e7a:	55                   	push   bp
    3e7b:	9a 28 2e c4 3e       	call   0x3ec4:0x2e28
    3e80:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3e85:	76 18                	jbe    0x3e9f
    3e87:	8d be 00 fe          	lea    di,[bp-0x200]
    3e8b:	16                   	push   ss
    3e8c:	57                   	push   di
    3e8d:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3e91:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3e96:	06                   	push   es
    3e97:	57                   	push   di
    3e98:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3e9b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3e9f:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3ea4:	8d be 00 fe          	lea    di,[bp-0x200]
    3ea8:	16                   	push   ss
    3ea9:	57                   	push   di
    3eaa:	68 ff 00             	push   0xff
    3ead:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3eb0:	26 ff b5 72 02       	push   WORD PTR es:[di+0x272]
    3eb5:	26 ff b5 70 02       	push   WORD PTR es:[di+0x270]
    3eba:	ff 36 56 02          	push   WORD PTR ds:0x256
    3ebe:	6a 67                	push   0x67
    3ec0:	55                   	push   bp
    3ec1:	9a 28 2e e6 3e       	call   0x3ee6:0x2e28
    3ec6:	8d be 00 fe          	lea    di,[bp-0x200]
    3eca:	16                   	push   ss
    3ecb:	57                   	push   di
    3ecc:	68 ff 00             	push   0xff
    3ecf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ed2:	26 ff b5 8a 02       	push   WORD PTR es:[di+0x28a]
    3ed7:	26 ff b5 88 02       	push   WORD PTR es:[di+0x288]
    3edc:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3ee0:	6a 64                	push   0x64
    3ee2:	55                   	push   bp
    3ee3:	9a 28 2e 2c 3f       	call   0x3f2c:0x2e28
    3ee8:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3eed:	76 18                	jbe    0x3f07
    3eef:	8d be 00 fe          	lea    di,[bp-0x200]
    3ef3:	16                   	push   ss
    3ef4:	57                   	push   di
    3ef5:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3ef9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3efe:	06                   	push   es
    3eff:	57                   	push   di
    3f00:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f03:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3f07:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3f0c:	8d be 00 fe          	lea    di,[bp-0x200]
    3f10:	16                   	push   ss
    3f11:	57                   	push   di
    3f12:	68 ff 00             	push   0xff
    3f15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f18:	26 ff b5 7e 02       	push   WORD PTR es:[di+0x27e]
    3f1d:	26 ff b5 7c 02       	push   WORD PTR es:[di+0x27c]
    3f22:	ff 36 56 02          	push   WORD PTR ds:0x256
    3f26:	6a 67                	push   0x67
    3f28:	55                   	push   bp
    3f29:	9a 28 2e 4e 3f       	call   0x3f4e:0x2e28
    3f2e:	8d be 00 fe          	lea    di,[bp-0x200]
    3f32:	16                   	push   ss
    3f33:	57                   	push   di
    3f34:	68 ff 00             	push   0xff
    3f37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f3a:	26 ff b5 96 02       	push   WORD PTR es:[di+0x296]
    3f3f:	26 ff b5 94 02       	push   WORD PTR es:[di+0x294]
    3f44:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3f48:	6a 64                	push   0x64
    3f4a:	55                   	push   bp
    3f4b:	9a 28 2e 94 3f       	call   0x3f94:0x2e28
    3f50:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3f55:	76 18                	jbe    0x3f6f
    3f57:	8d be 00 fe          	lea    di,[bp-0x200]
    3f5b:	16                   	push   ss
    3f5c:	57                   	push   di
    3f5d:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3f61:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3f66:	06                   	push   es
    3f67:	57                   	push   di
    3f68:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3f6b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3f6f:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3f74:	8d be 00 fe          	lea    di,[bp-0x200]
    3f78:	16                   	push   ss
    3f79:	57                   	push   di
    3f7a:	68 ff 00             	push   0xff
    3f7d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f80:	26 ff b5 76 02       	push   WORD PTR es:[di+0x276]
    3f85:	26 ff b5 74 02       	push   WORD PTR es:[di+0x274]
    3f8a:	ff 36 56 02          	push   WORD PTR ds:0x256
    3f8e:	6a 67                	push   0x67
    3f90:	55                   	push   bp
    3f91:	9a 28 2e b6 3f       	call   0x3fb6:0x2e28
    3f96:	8d be 00 fe          	lea    di,[bp-0x200]
    3f9a:	16                   	push   ss
    3f9b:	57                   	push   di
    3f9c:	68 ff 00             	push   0xff
    3f9f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fa2:	26 ff b5 8e 02       	push   WORD PTR es:[di+0x28e]
    3fa7:	26 ff b5 8c 02       	push   WORD PTR es:[di+0x28c]
    3fac:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    3fb0:	6a 64                	push   0x64
    3fb2:	55                   	push   bp
    3fb3:	9a 28 2e fc 3f       	call   0x3ffc:0x2e28
    3fb8:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    3fbd:	76 18                	jbe    0x3fd7
    3fbf:	8d be 00 fe          	lea    di,[bp-0x200]
    3fc3:	16                   	push   ss
    3fc4:	57                   	push   di
    3fc5:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    3fc9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    3fce:	06                   	push   es
    3fcf:	57                   	push   di
    3fd0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3fd3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    3fd7:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    3fdc:	8d be 00 fe          	lea    di,[bp-0x200]
    3fe0:	16                   	push   ss
    3fe1:	57                   	push   di
    3fe2:	68 ff 00             	push   0xff
    3fe5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fe8:	26 ff b5 7a 02       	push   WORD PTR es:[di+0x27a]
    3fed:	26 ff b5 78 02       	push   WORD PTR es:[di+0x278]
    3ff2:	ff 36 56 02          	push   WORD PTR ds:0x256
    3ff6:	6a 67                	push   0x67
    3ff8:	55                   	push   bp
    3ff9:	9a 28 2e 1e 40       	call   0x401e:0x2e28
    3ffe:	8d be 00 fe          	lea    di,[bp-0x200]
    4002:	16                   	push   ss
    4003:	57                   	push   di
    4004:	68 ff 00             	push   0xff
    4007:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    400a:	26 ff b5 92 02       	push   WORD PTR es:[di+0x292]
    400f:	26 ff b5 90 02       	push   WORD PTR es:[di+0x290]
    4014:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    4018:	6a 64                	push   0x64
    401a:	55                   	push   bp
    401b:	9a 28 2e 81 40       	call   0x4081:0x2e28
    4020:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    4025:	76 18                	jbe    0x403f
    4027:	8d be 00 fe          	lea    di,[bp-0x200]
    402b:	16                   	push   ss
    402c:	57                   	push   di
    402d:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    4031:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4036:	06                   	push   es
    4037:	57                   	push   di
    4038:	26 c4 3d             	les    di,DWORD PTR es:[di]
    403b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    403f:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    4043:	75 17                	jne    0x405c
    4045:	bf 4a 32             	mov    di,0x324a
    4048:	0e                   	push   cs
    4049:	57                   	push   di
    404a:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    404e:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4053:	06                   	push   es
    4054:	57                   	push   di
    4055:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4058:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    405c:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    4061:	8d be 00 fe          	lea    di,[bp-0x200]
    4065:	16                   	push   ss
    4066:	57                   	push   di
    4067:	68 ff 00             	push   0xff
    406a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    406d:	26 ff b5 ba 02       	push   WORD PTR es:[di+0x2ba]
    4072:	26 ff b5 b8 02       	push   WORD PTR es:[di+0x2b8]
    4077:	ff 36 54 02          	push   WORD PTR ds:0x254
    407b:	6a 67                	push   0x67
    407d:	55                   	push   bp
    407e:	9a 28 2e a3 40       	call   0x40a3:0x2e28
    4083:	8d be 00 fe          	lea    di,[bp-0x200]
    4087:	16                   	push   ss
    4088:	57                   	push   di
    4089:	68 ff 00             	push   0xff
    408c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    408f:	26 ff b5 be 02       	push   WORD PTR es:[di+0x2be]
    4094:	26 ff b5 bc 02       	push   WORD PTR es:[di+0x2bc]
    4099:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    409d:	6a 64                	push   0x64
    409f:	55                   	push   bp
    40a0:	9a 28 2e e9 40       	call   0x40e9:0x2e28
    40a5:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    40aa:	76 18                	jbe    0x40c4
    40ac:	8d be 00 fe          	lea    di,[bp-0x200]
    40b0:	16                   	push   ss
    40b1:	57                   	push   di
    40b2:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    40b6:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    40bb:	06                   	push   es
    40bc:	57                   	push   di
    40bd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    40c0:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    40c4:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    40c9:	8d be 00 fe          	lea    di,[bp-0x200]
    40cd:	16                   	push   ss
    40ce:	57                   	push   di
    40cf:	68 ff 00             	push   0xff
    40d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40d5:	26 ff b5 c2 02       	push   WORD PTR es:[di+0x2c2]
    40da:	26 ff b5 c0 02       	push   WORD PTR es:[di+0x2c0]
    40df:	ff 36 54 02          	push   WORD PTR ds:0x254
    40e3:	6a 67                	push   0x67
    40e5:	55                   	push   bp
    40e6:	9a 28 2e 4e 41       	call   0x414e:0x2e28
    40eb:	8d be fa fc          	lea    di,[bp-0x306]
    40ef:	16                   	push   ss
    40f0:	57                   	push   di
    40f1:	8d be 00 fe          	lea    di,[bp-0x200]
    40f5:	16                   	push   ss
    40f6:	57                   	push   di
    40f7:	9a cd 17 04 41       	call   0x4104:0x17cd
    40fc:	bf 4b 32             	mov    di,0x324b
    40ff:	0e                   	push   cs
    4100:	57                   	push   di
    4101:	9a 4c 18 1e 41       	call   0x411e:0x184c
    4106:	8d be fa fb          	lea    di,[bp-0x406]
    410a:	16                   	push   ss
    410b:	57                   	push   di
    410c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    410f:	26 c4 bd c4 02       	les    di,DWORD PTR es:[di+0x2c4]
    4114:	06                   	push   es
    4115:	57                   	push   di
    4116:	9a 53 1d c4 41       	call   0x41c4:0x1d53
    411b:	9a 4c 18 2c 41       	call   0x412c:0x184c
    4120:	8d be 00 fe          	lea    di,[bp-0x200]
    4124:	16                   	push   ss
    4125:	57                   	push   di
    4126:	68 ff 00             	push   0xff
    4129:	9a e7 17 a5 41       	call   0x41a5:0x17e7
    412e:	8d be 00 fe          	lea    di,[bp-0x200]
    4132:	16                   	push   ss
    4133:	57                   	push   di
    4134:	68 ff 00             	push   0xff
    4137:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    413a:	26 ff b5 ca 02       	push   WORD PTR es:[di+0x2ca]
    413f:	26 ff b5 c8 02       	push   WORD PTR es:[di+0x2c8]
    4144:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    4148:	6a 64                	push   0x64
    414a:	55                   	push   bp
    414b:	9a 28 2e 94 41       	call   0x4194:0x2e28
    4150:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    4155:	76 18                	jbe    0x416f
    4157:	8d be 00 fe          	lea    di,[bp-0x200]
    415b:	16                   	push   ss
    415c:	57                   	push   di
    415d:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    4161:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4166:	06                   	push   es
    4167:	57                   	push   di
    4168:	26 c4 3d             	les    di,DWORD PTR es:[di]
    416b:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    416f:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    4174:	8d be 00 fe          	lea    di,[bp-0x200]
    4178:	16                   	push   ss
    4179:	57                   	push   di
    417a:	68 ff 00             	push   0xff
    417d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4180:	26 ff b5 4a 03       	push   WORD PTR es:[di+0x34a]
    4185:	26 ff b5 48 03       	push   WORD PTR es:[di+0x348]
    418a:	ff 36 54 02          	push   WORD PTR ds:0x254
    418e:	6a 67                	push   0x67
    4190:	55                   	push   bp
    4191:	9a 28 2e f9 41       	call   0x41f9:0x2e28
    4196:	8d be fa fc          	lea    di,[bp-0x306]
    419a:	16                   	push   ss
    419b:	57                   	push   di
    419c:	8d be 00 fe          	lea    di,[bp-0x200]
    41a0:	16                   	push   ss
    41a1:	57                   	push   di
    41a2:	9a cd 17 af 41       	call   0x41af:0x17cd
    41a7:	bf 4b 32             	mov    di,0x324b
    41aa:	0e                   	push   cs
    41ab:	57                   	push   di
    41ac:	9a 4c 18 c9 41       	call   0x41c9:0x184c
    41b1:	8d be fa fb          	lea    di,[bp-0x406]
    41b5:	16                   	push   ss
    41b6:	57                   	push   di
    41b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41ba:	26 c4 bd 4c 03       	les    di,DWORD PTR es:[di+0x34c]
    41bf:	06                   	push   es
    41c0:	57                   	push   di
    41c1:	9a 53 1d 8a 42       	call   0x428a:0x1d53
    41c6:	9a 4c 18 d7 41       	call   0x41d7:0x184c
    41cb:	8d be 00 fe          	lea    di,[bp-0x200]
    41cf:	16                   	push   ss
    41d0:	57                   	push   di
    41d1:	68 ff 00             	push   0xff
    41d4:	9a e7 17 98 42       	call   0x4298:0x17e7
    41d9:	8d be 00 fe          	lea    di,[bp-0x200]
    41dd:	16                   	push   ss
    41de:	57                   	push   di
    41df:	68 ff 00             	push   0xff
    41e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41e5:	26 ff b5 52 03       	push   WORD PTR es:[di+0x352]
    41ea:	26 ff b5 50 03       	push   WORD PTR es:[di+0x350]
    41ef:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    41f3:	6a 64                	push   0x64
    41f5:	55                   	push   bp
    41f6:	9a 28 2e 3f 42       	call   0x423f:0x2e28
    41fb:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    4200:	76 18                	jbe    0x421a
    4202:	8d be 00 fe          	lea    di,[bp-0x200]
    4206:	16                   	push   ss
    4207:	57                   	push   di
    4208:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    420c:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4211:	06                   	push   es
    4212:	57                   	push   di
    4213:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4216:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    421a:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    421f:	8d be 00 fe          	lea    di,[bp-0x200]
    4223:	16                   	push   ss
    4224:	57                   	push   di
    4225:	68 ff 00             	push   0xff
    4228:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    422b:	26 ff b5 26 03       	push   WORD PTR es:[di+0x326]
    4230:	26 ff b5 24 03       	push   WORD PTR es:[di+0x324]
    4235:	ff 36 54 02          	push   WORD PTR ds:0x254
    4239:	6a 67                	push   0x67
    423b:	55                   	push   bp
    423c:	9a 28 2e 0d 43       	call   0x430d:0x2e28
    4241:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    4246:	76 18                	jbe    0x4260
    4248:	8d be 00 fe          	lea    di,[bp-0x200]
    424c:	16                   	push   ss
    424d:	57                   	push   di
    424e:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    4252:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4257:	06                   	push   es
    4258:	57                   	push   di
    4259:	26 c4 3d             	les    di,DWORD PTR es:[di]
    425c:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4260:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    4265:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4268:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    426d:	26 80 7d 29 00       	cmp    BYTE PTR es:[di+0x29],0x0
    4272:	75 03                	jne    0x4277
    4274:	e9 98 00             	jmp    0x430f
    4277:	8d be fa fc          	lea    di,[bp-0x306]
    427b:	16                   	push   ss
    427c:	57                   	push   di
    427d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4280:	26 c4 bd 2c 03       	les    di,DWORD PTR es:[di+0x32c]
    4285:	06                   	push   es
    4286:	57                   	push   di
    4287:	9a 53 1d ff ff       	call   0xffff:0x1d53
    428c:	8d be 00 fe          	lea    di,[bp-0x200]
    4290:	16                   	push   ss
    4291:	57                   	push   di
    4292:	68 ff 00             	push   0xff
    4295:	9a e7 17 c8 42       	call   0x42c8:0x17e7
    429a:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    429e:	75 4d                	jne    0x42ed
    42a0:	a1 56 02             	mov    ax,ds:0x256
    42a3:	89 86 f8 fd          	mov    WORD PTR [bp-0x208],ax
    42a7:	b8 01 00             	mov    ax,0x1
    42aa:	3b 86 f8 fd          	cmp    ax,WORD PTR [bp-0x208]
    42ae:	7f 3d                	jg     0x42ed
    42b0:	89 86 fe fd          	mov    WORD PTR [bp-0x202],ax
    42b4:	eb 04                	jmp    0x42ba
    42b6:	ff 86 fe fd          	inc    WORD PTR [bp-0x202]
    42ba:	8d be f8 fc          	lea    di,[bp-0x308]
    42be:	16                   	push   ss
    42bf:	57                   	push   di
    42c0:	bf 48 32             	mov    di,0x3248
    42c3:	0e                   	push   cs
    42c4:	57                   	push   di
    42c5:	9a cd 17 d3 42       	call   0x42d3:0x17cd
    42ca:	8d be 00 fe          	lea    di,[bp-0x200]
    42ce:	16                   	push   ss
    42cf:	57                   	push   di
    42d0:	9a 4c 18 e1 42       	call   0x42e1:0x184c
    42d5:	8d be 00 fe          	lea    di,[bp-0x200]
    42d9:	16                   	push   ss
    42da:	57                   	push   di
    42db:	68 ff 00             	push   0xff
    42de:	9a e7 17 84 45       	call   0x4584:0x17e7
    42e3:	8b 86 fe fd          	mov    ax,WORD PTR [bp-0x202]
    42e7:	3b 86 f8 fd          	cmp    ax,WORD PTR [bp-0x208]
    42eb:	75 c9                	jne    0x42b6
    42ed:	8d be 00 fe          	lea    di,[bp-0x200]
    42f1:	16                   	push   ss
    42f2:	57                   	push   di
    42f3:	68 ff 00             	push   0xff
    42f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42f9:	26 ff b5 2e 03       	push   WORD PTR es:[di+0x32e]
    42fe:	26 ff b5 2c 03       	push   WORD PTR es:[di+0x32c]
    4303:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    4307:	6a 64                	push   0x64
    4309:	55                   	push   bp
    430a:	9a 28 2e 53 43       	call   0x4353:0x2e28
    430f:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    4314:	76 18                	jbe    0x432e
    4316:	8d be 00 fe          	lea    di,[bp-0x200]
    431a:	16                   	push   ss
    431b:	57                   	push   di
    431c:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    4320:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4325:	06                   	push   es
    4326:	57                   	push   di
    4327:	26 c4 3d             	les    di,DWORD PTR es:[di]
    432a:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    432e:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    4333:	8d be 00 fe          	lea    di,[bp-0x200]
    4337:	16                   	push   ss
    4338:	57                   	push   di
    4339:	68 ff 00             	push   0xff
    433c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    433f:	26 ff b5 2a 03       	push   WORD PTR es:[di+0x32a]
    4344:	26 ff b5 28 03       	push   WORD PTR es:[di+0x328]
    4349:	ff 36 56 02          	push   WORD PTR ds:0x256
    434d:	6a 67                	push   0x67
    434f:	55                   	push   bp
    4350:	9a 28 2e 75 43       	call   0x4375:0x2e28
    4355:	8d be 00 fe          	lea    di,[bp-0x200]
    4359:	16                   	push   ss
    435a:	57                   	push   di
    435b:	68 ff 00             	push   0xff
    435e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4361:	26 ff b5 32 03       	push   WORD PTR es:[di+0x332]
    4366:	26 ff b5 30 03       	push   WORD PTR es:[di+0x330]
    436b:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    436f:	6a 64                	push   0x64
    4371:	55                   	push   bp
    4372:	9a 28 2e d8 43       	call   0x43d8:0x2e28
    4377:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    437c:	76 18                	jbe    0x4396
    437e:	8d be 00 fe          	lea    di,[bp-0x200]
    4382:	16                   	push   ss
    4383:	57                   	push   di
    4384:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    4388:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    438d:	06                   	push   es
    438e:	57                   	push   di
    438f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4392:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4396:	83 7e 0a 01          	cmp    WORD PTR [bp+0xa],0x1
    439a:	75 17                	jne    0x43b3
    439c:	bf 4a 32             	mov    di,0x324a
    439f:	0e                   	push   cs
    43a0:	57                   	push   di
    43a1:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    43a5:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    43aa:	06                   	push   es
    43ab:	57                   	push   di
    43ac:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43af:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    43b3:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    43b8:	8d be 00 fe          	lea    di,[bp-0x200]
    43bc:	16                   	push   ss
    43bd:	57                   	push   di
    43be:	68 ff 00             	push   0xff
    43c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43c4:	26 ff b5 5e 03       	push   WORD PTR es:[di+0x35e]
    43c9:	26 ff b5 5c 03       	push   WORD PTR es:[di+0x35c]
    43ce:	ff 36 54 02          	push   WORD PTR ds:0x254
    43d2:	6a 67                	push   0x67
    43d4:	55                   	push   bp
    43d5:	9a 28 2e fa 43       	call   0x43fa:0x2e28
    43da:	8d be 00 fe          	lea    di,[bp-0x200]
    43de:	16                   	push   ss
    43df:	57                   	push   di
    43e0:	68 ff 00             	push   0xff
    43e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43e6:	26 ff b5 66 03       	push   WORD PTR es:[di+0x366]
    43eb:	26 ff b5 64 03       	push   WORD PTR es:[di+0x364]
    43f0:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    43f4:	6a 64                	push   0x64
    43f6:	55                   	push   bp
    43f7:	9a 28 2e 1c 44       	call   0x441c:0x2e28
    43fc:	8d be 00 fe          	lea    di,[bp-0x200]
    4400:	16                   	push   ss
    4401:	57                   	push   di
    4402:	68 ff 00             	push   0xff
    4405:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4408:	26 ff b5 7e 03       	push   WORD PTR es:[di+0x37e]
    440d:	26 ff b5 7c 03       	push   WORD PTR es:[di+0x37c]
    4412:	ff 36 5c 02          	push   WORD PTR ds:0x25c
    4416:	6a 64                	push   0x64
    4418:	55                   	push   bp
    4419:	9a 28 2e 62 44       	call   0x4462:0x2e28
    441e:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    4423:	76 18                	jbe    0x443d
    4425:	8d be 00 fe          	lea    di,[bp-0x200]
    4429:	16                   	push   ss
    442a:	57                   	push   di
    442b:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    442f:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4434:	06                   	push   es
    4435:	57                   	push   di
    4436:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4439:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    443d:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    4442:	8d be 00 fe          	lea    di,[bp-0x200]
    4446:	16                   	push   ss
    4447:	57                   	push   di
    4448:	68 ff 00             	push   0xff
    444b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    444e:	26 ff b5 6e 03       	push   WORD PTR es:[di+0x36e]
    4453:	26 ff b5 6c 03       	push   WORD PTR es:[di+0x36c]
    4458:	ff 36 56 02          	push   WORD PTR ds:0x256
    445c:	6a 67                	push   0x67
    445e:	55                   	push   bp
    445f:	9a 28 2e 84 44       	call   0x4484:0x2e28
    4464:	8d be 00 fe          	lea    di,[bp-0x200]
    4468:	16                   	push   ss
    4469:	57                   	push   di
    446a:	68 ff 00             	push   0xff
    446d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4470:	26 ff b5 72 03       	push   WORD PTR es:[di+0x372]
    4475:	26 ff b5 70 03       	push   WORD PTR es:[di+0x370]
    447a:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    447e:	6a 64                	push   0x64
    4480:	55                   	push   bp
    4481:	9a 28 2e a6 44       	call   0x44a6:0x2e28
    4486:	8d be 00 fe          	lea    di,[bp-0x200]
    448a:	16                   	push   ss
    448b:	57                   	push   di
    448c:	68 ff 00             	push   0xff
    448f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4492:	26 ff b5 82 03       	push   WORD PTR es:[di+0x382]
    4497:	26 ff b5 80 03       	push   WORD PTR es:[di+0x380]
    449c:	ff 36 5c 02          	push   WORD PTR ds:0x25c
    44a0:	6a 64                	push   0x64
    44a2:	55                   	push   bp
    44a3:	9a 28 2e ec 44       	call   0x44ec:0x2e28
    44a8:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    44ad:	76 18                	jbe    0x44c7
    44af:	8d be 00 fe          	lea    di,[bp-0x200]
    44b3:	16                   	push   ss
    44b4:	57                   	push   di
    44b5:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    44b9:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    44be:	06                   	push   es
    44bf:	57                   	push   di
    44c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    44c3:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    44c7:	c6 86 00 fe 00       	mov    BYTE PTR [bp-0x200],0x0
    44cc:	8d be 00 fe          	lea    di,[bp-0x200]
    44d0:	16                   	push   ss
    44d1:	57                   	push   di
    44d2:	68 ff 00             	push   0xff
    44d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44d8:	26 ff b5 6a 03       	push   WORD PTR es:[di+0x36a]
    44dd:	26 ff b5 68 03       	push   WORD PTR es:[di+0x368]
    44e2:	ff 36 56 02          	push   WORD PTR ds:0x256
    44e6:	6a 67                	push   0x67
    44e8:	55                   	push   bp
    44e9:	9a 28 2e 0e 45       	call   0x450e:0x2e28
    44ee:	8d be 00 fe          	lea    di,[bp-0x200]
    44f2:	16                   	push   ss
    44f3:	57                   	push   di
    44f4:	68 ff 00             	push   0xff
    44f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44fa:	26 ff b5 76 03       	push   WORD PTR es:[di+0x376]
    44ff:	26 ff b5 74 03       	push   WORD PTR es:[di+0x374]
    4504:	ff 36 5a 02          	push   WORD PTR ds:0x25a
    4508:	6a 64                	push   0x64
    450a:	55                   	push   bp
    450b:	9a 28 2e 30 45       	call   0x4530:0x2e28
    4510:	8d be 00 fe          	lea    di,[bp-0x200]
    4514:	16                   	push   ss
    4515:	57                   	push   di
    4516:	68 ff 00             	push   0xff
    4519:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    451c:	26 ff b5 86 03       	push   WORD PTR es:[di+0x386]
    4521:	26 ff b5 84 03       	push   WORD PTR es:[di+0x384]
    4526:	ff 36 5c 02          	push   WORD PTR ds:0x25c
    452a:	6a 64                	push   0x64
    452c:	55                   	push   bp
    452d:	9a 28 2e ff ff       	call   0xffff:0x2e28
    4532:	80 be 00 fe 00       	cmp    BYTE PTR [bp-0x200],0x0
    4537:	76 18                	jbe    0x4551
    4539:	8d be 00 fe          	lea    di,[bp-0x200]
    453d:	16                   	push   ss
    453e:	57                   	push   di
    453f:	c4 be fa fd          	les    di,DWORD PTR [bp-0x206]
    4543:	26 c4 bd ec 00       	les    di,DWORD PTR es:[di+0xec]
    4548:	06                   	push   es
    4549:	57                   	push   di
    454a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    454d:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    4551:	c9                   	leave
    4552:	ca 06 00             	retf   0x6
    4555:	09 50 72             	or     WORD PTR [bx+si+0x72],dx
    4558:	69 78 4d 6f 79       	imul   di,WORD PTR [bx+si+0x4d],0x796f
    455d:	65 6e                	outs   dx,BYTE PTR gs:[si]
    455f:	0b 50 72             	or     dx,WORD PTR [bx+si+0x72]
    4562:	69 78 4d 69 6e       	imul   di,WORD PTR [bx+si+0x4d],0x6e69
    4567:	69 6d 75 6d 0b       	imul   bp,WORD PTR [di+0x75],0xb6d
    456c:	50                   	push   ax
    456d:	72 69                	jb     0x45d8
    456f:	78 4d                	js     0x45be
    4571:	61                   	popa
    4572:	78 69                	js     0x45dd
    4574:	6d                   	ins    WORD PTR es:[di],dx
    4575:	75 6d                	jne    0x45e4
    4577:	00 00                	add    BYTE PTR [bx+si],al
    4579:	00 40 55             	add    BYTE PTR [bx+si+0x55],al
    457c:	89 e5                	mov    bp,sp
    457e:	b8 0e 00             	mov    ax,0xe
    4581:	9a 44 04 9a 45       	call   0x459a:0x444
    4586:	83 ec 0e             	sub    sp,0xe
    4589:	ff 76 0c             	push   WORD PTR [bp+0xc]
    458c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    458f:	bf 38 01             	mov    di,0x138
    4592:	b8 ff ff             	mov    ax,0xffff
    4595:	50                   	push   ax
    4596:	57                   	push   di
    4597:	9a 73 22 f2 45       	call   0x45f2:0x2273
    459c:	89 c7                	mov    di,ax
    459e:	8e c2                	mov    es,dx
    45a0:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    45a3:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    45a6:	bf 5f 45             	mov    di,0x455f
    45a9:	0e                   	push   cs
    45aa:	57                   	push   di
    45ab:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    45ae:	06                   	push   es
    45af:	57                   	push   di
    45b0:	9a 9b 3b d3 45       	call   0x45d3:0x3b9b
    45b5:	89 c7                	mov    di,ax
    45b7:	8e c2                	mov    es,dx
    45b9:	06                   	push   es
    45ba:	57                   	push   di
    45bb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45be:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    45c2:	9b db 7e f2          	fstp   TBYTE PTR [bp-0xe]
    45c6:	bf 6b 45             	mov    di,0x456b
    45c9:	0e                   	push   cs
    45ca:	57                   	push   di
    45cb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    45ce:	06                   	push   es
    45cf:	57                   	push   di
    45d0:	9a 9b 3b 1c 46       	call   0x461c:0x3b9b
    45d5:	89 c7                	mov    di,ax
    45d7:	8e c2                	mov    es,dx
    45d9:	06                   	push   es
    45da:	57                   	push   di
    45db:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45de:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
    45e2:	9b db 6e f2          	fld    TBYTE PTR [bp-0xe]
    45e6:	9b de c1             	faddp  st(1),st
    45e9:	9b 2e d9 06 77 45    	fld    DWORD PTR cs:0x4577
    45ef:	9a b2 04 ff ff       	call   0xffff:0x4b2
    45f4:	83 ec 08             	sub    sp,0x8
    45f7:	89 e3                	mov    bx,sp
    45f9:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    45fd:	90                   	nop
    45fe:	9b                   	fwait
    45ff:	9a a6 2f ff ff       	call   0xffff:0x2fa6
    4604:	83 ec 08             	sub    sp,0x8
    4607:	89 e3                	mov    bx,sp
    4609:	9b 36 dd 1f          	fstp   QWORD PTR ss:[bx]
    460d:	90                   	nop
    460e:	9b                   	fwait
    460f:	bf 55 45             	mov    di,0x4555
    4612:	0e                   	push   cs
    4613:	57                   	push   di
    4614:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4617:	06                   	push   es
    4618:	57                   	push   di
    4619:	9a 9b 3b ff ff       	call   0xffff:0x3b9b
    461e:	89 c7                	mov    di,ax
    4620:	8e c2                	mov    es,dx
    4622:	06                   	push   es
    4623:	57                   	push   di
    4624:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4627:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    462b:	c9                   	leave
    462c:	ca                   	.byte 0xca
    462d:	08                   	.byte 0x8
