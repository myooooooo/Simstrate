; seg01_CODE - Simstra1.dll (module de licence) - x86 16 bits

Disassembly of section .data:

00000000 <.data>:
       0:	01 00                	add    WORD PTR [bx+si],ax
       2:	9a ff ff 00 00       	call   0x0:0xffff
       7:	9a ff ff 00 00       	call   0x0:0xffff
       c:	55                   	push   bp
       d:	89 e5                	mov    bp,sp
       f:	31 c0                	xor    ax,ax
      11:	9a ff ff 00 00       	call   0x0:0xffff
      16:	c9                   	leave
      17:	9a ff ff 00 00       	call   0x0:0xffff
      1c:	8c d8                	mov    ax,ds
      1e:	90                   	nop
      1f:	45                   	inc    bp
      20:	55                   	push   bp
      21:	89 e5                	mov    bp,sp
      23:	1e                   	push   ds
      24:	8e d8                	mov    ds,ax
      26:	b8 02 00             	mov    ax,0x2
      29:	9a ff ff 00 00       	call   0x0:0xffff
      2e:	83 ec 02             	sub    sp,0x2
      31:	56                   	push   si
      32:	57                   	push   di
      33:	c7 46 fc 0d 00       	mov    WORD PTR [bp-0x4],0xd
      38:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
      3b:	5f                   	pop    di
      3c:	5e                   	pop    si
      3d:	8d 66 fe             	lea    sp,[bp-0x2]
      40:	1f                   	pop    ds
      41:	5d                   	pop    bp
      42:	4d                   	dec    bp
      43:	cb                   	retf
      44:	8c d8                	mov    ax,ds
      46:	90                   	nop
      47:	45                   	inc    bp
      48:	55                   	push   bp
      49:	89 e5                	mov    bp,sp
      4b:	1e                   	push   ds
      4c:	8e d8                	mov    ds,ax
      4e:	b8 06 00             	mov    ax,0x6
      51:	9a ff ff 00 00       	call   0x0:0xffff
      56:	83 ec 06             	sub    sp,0x6
      59:	56                   	push   si
      5a:	57                   	push   di
      5b:	c7 46 fa 0a 00       	mov    WORD PTR [bp-0x6],0xa
      60:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
      63:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
      66:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
      69:	5f                   	pop    di
      6a:	5e                   	pop    si
      6b:	8d 66 fe             	lea    sp,[bp-0x2]
      6e:	1f                   	pop    ds
      6f:	5d                   	pop    bp
      70:	4d                   	dec    bp
      71:	cb                   	retf
      72:	8c d8                	mov    ax,ds
      74:	90                   	nop
      75:	45                   	inc    bp
      76:	55                   	push   bp
      77:	89 e5                	mov    bp,sp
      79:	1e                   	push   ds
      7a:	8e d8                	mov    ds,ax
      7c:	b8 06 00             	mov    ax,0x6
      7f:	9a ff ff 00 00       	call   0x0:0xffff
      84:	83 ec 06             	sub    sp,0x6
      87:	56                   	push   si
      88:	57                   	push   di
      89:	9a ff ff 00 00       	call   0x0:0xffff
      8e:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
      91:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
      94:	5f                   	pop    di
      95:	5e                   	pop    si
      96:	8d 66 fe             	lea    sp,[bp-0x2]
      99:	1f                   	pop    ds
      9a:	5d                   	pop    bp
      9b:	4d                   	dec    bp
      9c:	cb                   	retf
      9d:	8c d8                	mov    ax,ds
      9f:	90                   	nop
      a0:	45                   	inc    bp
      a1:	55                   	push   bp
      a2:	89 e5                	mov    bp,sp
      a4:	1e                   	push   ds
      a5:	8e d8                	mov    ds,ax
      a7:	b8 06 00             	mov    ax,0x6
      aa:	9a ff ff 00 00       	call   0x0:0xffff
      af:	83 ec 06             	sub    sp,0x6
      b2:	56                   	push   si
      b3:	57                   	push   di
      b4:	9a ff ff 00 00       	call   0x0:0xffff
      b9:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
      bc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
      bf:	5f                   	pop    di
      c0:	5e                   	pop    si
      c1:	8d 66 fe             	lea    sp,[bp-0x2]
      c4:	1f                   	pop    ds
      c5:	5d                   	pop    bp
      c6:	4d                   	dec    bp
      c7:	cb                   	retf
      c8:	8c d8                	mov    ax,ds
      ca:	90                   	nop
      cb:	45                   	inc    bp
      cc:	55                   	push   bp
      cd:	89 e5                	mov    bp,sp
      cf:	1e                   	push   ds
      d0:	8e d8                	mov    ds,ax
      d2:	b8 06 00             	mov    ax,0x6
      d5:	9a ff ff 00 00       	call   0x0:0xffff
      da:	83 ec 06             	sub    sp,0x6
      dd:	56                   	push   si
      de:	57                   	push   di
      df:	9a ff ff 00 00       	call   0x0:0xffff
      e4:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
      e7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
      ea:	5f                   	pop    di
      eb:	5e                   	pop    si
      ec:	8d 66 fe             	lea    sp,[bp-0x2]
      ef:	1f                   	pop    ds
      f0:	5d                   	pop    bp
      f1:	4d                   	dec    bp
      f2:	cb                   	retf
      f3:	8c d8                	mov    ax,ds
      f5:	90                   	nop
      f6:	45                   	inc    bp
      f7:	55                   	push   bp
      f8:	89 e5                	mov    bp,sp
      fa:	1e                   	push   ds
      fb:	8e d8                	mov    ds,ax
      fd:	b8 06 00             	mov    ax,0x6
     100:	9a ff ff 00 00       	call   0x0:0xffff
     105:	83 ec 06             	sub    sp,0x6
     108:	56                   	push   si
     109:	57                   	push   di
     10a:	c7 46 f8 04 00       	mov    WORD PTR [bp-0x8],0x4
     10f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     112:	40                   	inc    ax
     113:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     116:	9a ff ff 00 00       	call   0x0:0xffff
     11b:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     11e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     121:	5f                   	pop    di
     122:	5e                   	pop    si
     123:	8d 66 fe             	lea    sp,[bp-0x2]
     126:	1f                   	pop    ds
     127:	5d                   	pop    bp
     128:	4d                   	dec    bp
     129:	cb                   	retf
     12a:	35 c2 68             	xor    ax,0x68c2
     12d:	21 a2 da 0f          	and    WORD PTR [bp+si+0xfda],sp
     131:	c9                   	leave
     132:	00 40 8c             	add    BYTE PTR [bx+si-0x74],al
     135:	d8 90 45 55          	fcom   DWORD PTR [bx+si+0x5545]
     139:	89 e5                	mov    bp,sp
     13b:	1e                   	push   ds
     13c:	8e d8                	mov    ds,ax
     13e:	b8 06 00             	mov    ax,0x6
     141:	9a ff ff 00 00       	call   0x0:0xffff
     146:	83 ec 06             	sub    sp,0x6
     149:	56                   	push   si
     14a:	57                   	push   di
     14b:	9b 2e db 2e 2a 01    	fld    TBYTE PTR cs:0x12a
     151:	9a ff ff 00 00       	call   0x0:0xffff
     156:	9a ff ff 00 00       	call   0x0:0xffff
     15b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     15e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     161:	5f                   	pop    di
     162:	5e                   	pop    si
     163:	8d 66 fe             	lea    sp,[bp-0x2]
     166:	1f                   	pop    ds
     167:	5d                   	pop    bp
     168:	4d                   	dec    bp
     169:	cb                   	retf
     16a:	00 00                	add    BYTE PTR [bx+si],al
     16c:	20 41 8c             	and    BYTE PTR [bx+di-0x74],al
     16f:	d8 90 45 55          	fcom   DWORD PTR [bx+si+0x5545]
     173:	89 e5                	mov    bp,sp
     175:	1e                   	push   ds
     176:	8e d8                	mov    ds,ax
     178:	b8 0e 00             	mov    ax,0xe
     17b:	9a ff ff 00 00       	call   0x0:0xffff
     180:	83 ec 0e             	sub    sp,0xe
     183:	56                   	push   si
     184:	57                   	push   di
     185:	9b 2e d9 06 6a 01    	fld    DWORD PTR cs:0x16a
     18b:	9a ff ff 00 00       	call   0x0:0xffff
     190:	9a ff ff 00 00       	call   0x0:0xffff
     195:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     198:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     19b:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     19e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     1a1:	5f                   	pop    di
     1a2:	5e                   	pop    si
     1a3:	8d 66 fe             	lea    sp,[bp-0x2]
     1a6:	1f                   	pop    ds
     1a7:	5d                   	pop    bp
     1a8:	4d                   	dec    bp
     1a9:	cb                   	retf
     1aa:	00 00                	add    BYTE PTR [bx+si],al
     1ac:	80 3f 8c             	cmp    BYTE PTR [bx],0x8c
     1af:	d8 90 45 55          	fcom   DWORD PTR [bx+si+0x5545]
     1b3:	89 e5                	mov    bp,sp
     1b5:	1e                   	push   ds
     1b6:	8e d8                	mov    ds,ax
     1b8:	b8 0e 00             	mov    ax,0xe
     1bb:	9a ff ff 00 00       	call   0x0:0xffff
     1c0:	83 ec 0e             	sub    sp,0xe
     1c3:	56                   	push   si
     1c4:	57                   	push   di
     1c5:	9a ff ff 00 00       	call   0x0:0xffff
     1ca:	99                   	cwd
     1cb:	9a ff ff 00 00       	call   0x0:0xffff
     1d0:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     1d3:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     1d6:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     1d9:	9b 2e d9 06 aa 01    	fld    DWORD PTR cs:0x1aa
     1df:	9a ff ff 00 00       	call   0x0:0xffff
     1e4:	9a ff ff 00 00       	call   0x0:0xffff
     1e9:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     1ec:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     1ef:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     1f2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     1f5:	5f                   	pop    di
     1f6:	5e                   	pop    si
     1f7:	8d 66 fe             	lea    sp,[bp-0x2]
     1fa:	1f                   	pop    ds
     1fb:	5d                   	pop    bp
     1fc:	4d                   	dec    bp
     1fd:	cb                   	retf
     1fe:	00 00                	add    BYTE PTR [bx+si],al
     200:	80 3f 00             	cmp    BYTE PTR [bx],0x0
     203:	00 00                	add    BYTE PTR [bx+si],al
     205:	40                   	inc    ax
     206:	8c d8                	mov    ax,ds
     208:	90                   	nop
     209:	45                   	inc    bp
     20a:	55                   	push   bp
     20b:	89 e5                	mov    bp,sp
     20d:	1e                   	push   ds
     20e:	8e d8                	mov    ds,ax
     210:	b8 0e 00             	mov    ax,0xe
     213:	9a ff ff 00 00       	call   0x0:0xffff
     218:	83 ec 0e             	sub    sp,0xe
     21b:	56                   	push   si
     21c:	57                   	push   di
     21d:	9b 2e d9 06 fe 01    	fld    DWORD PTR cs:0x1fe
     223:	9a ff ff 00 00       	call   0x0:0xffff
     228:	9a ff ff 00 00       	call   0x0:0xffff
     22d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     230:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     233:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     236:	9b 2e d9 06 02 02    	fld    DWORD PTR cs:0x202
     23c:	9a ff ff 00 00       	call   0x0:0xffff
     241:	9a ff ff 00 00       	call   0x0:0xffff
     246:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     249:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     24c:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     24f:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     252:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     255:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     258:	9a ff ff 00 00       	call   0x0:0xffff
     25d:	9a ff ff 00 00       	call   0x0:0xffff
     262:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     265:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     268:	5f                   	pop    di
     269:	5e                   	pop    si
     26a:	8d 66 fe             	lea    sp,[bp-0x2]
     26d:	1f                   	pop    ds
     26e:	5d                   	pop    bp
     26f:	4d                   	dec    bp
     270:	cb                   	retf
     271:	00 00                	add    BYTE PTR [bx+si],al
     273:	00 40 8c             	add    BYTE PTR [bx+si-0x74],al
     276:	d8 90 45 55          	fcom   DWORD PTR [bx+si+0x5545]
     27a:	89 e5                	mov    bp,sp
     27c:	1e                   	push   ds
     27d:	8e d8                	mov    ds,ax
     27f:	b8 0e 00             	mov    ax,0xe
     282:	9a ff ff 00 00       	call   0x0:0xffff
     287:	83 ec 0e             	sub    sp,0xe
     28a:	56                   	push   si
     28b:	57                   	push   di
     28c:	9b 2e d9 06 71 02    	fld    DWORD PTR cs:0x271
     292:	9a ff ff 00 00       	call   0x0:0xffff
     297:	9a ff ff 00 00       	call   0x0:0xffff
     29c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     29f:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     2a2:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     2a5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     2a8:	5f                   	pop    di
     2a9:	5e                   	pop    si
     2aa:	8d 66 fe             	lea    sp,[bp-0x2]
     2ad:	1f                   	pop    ds
     2ae:	5d                   	pop    bp
     2af:	4d                   	dec    bp
     2b0:	cb                   	retf
     2b1:	8c d8                	mov    ax,ds
     2b3:	90                   	nop
     2b4:	45                   	inc    bp
     2b5:	55                   	push   bp
     2b6:	89 e5                	mov    bp,sp
     2b8:	1e                   	push   ds
     2b9:	8e d8                	mov    ds,ax
     2bb:	b8 0e 00             	mov    ax,0xe
     2be:	9a ff ff 00 00       	call   0x0:0xffff
     2c3:	83 ec 0e             	sub    sp,0xe
     2c6:	56                   	push   si
     2c7:	57                   	push   di
     2c8:	9a ff ff 00 00       	call   0x0:0xffff
     2cd:	99                   	cwd
     2ce:	9a ff ff 00 00       	call   0x0:0xffff
     2d3:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     2d6:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     2d9:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     2dc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     2df:	5f                   	pop    di
     2e0:	5e                   	pop    si
     2e1:	8d 66 fe             	lea    sp,[bp-0x2]
     2e4:	1f                   	pop    ds
     2e5:	5d                   	pop    bp
     2e6:	4d                   	dec    bp
     2e7:	cb                   	retf
     2e8:	00 00                	add    BYTE PTR [bx+si],al
     2ea:	00 40 8c             	add    BYTE PTR [bx+si-0x74],al
     2ed:	d8 90 45 55          	fcom   DWORD PTR [bx+si+0x5545]
     2f1:	89 e5                	mov    bp,sp
     2f3:	1e                   	push   ds
     2f4:	8e d8                	mov    ds,ax
     2f6:	b8 0c 00             	mov    ax,0xc
     2f9:	9a ff ff 00 00       	call   0x0:0xffff
     2fe:	83 ec 0c             	sub    sp,0xc
     301:	56                   	push   si
     302:	57                   	push   di
     303:	9b 2e d9 06 e8 02    	fld    DWORD PTR cs:0x2e8
     309:	9a ff ff 00 00       	call   0x0:0xffff
     30e:	9a ff ff 00 00       	call   0x0:0xffff
     313:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     316:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     319:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     31c:	9a ff ff 00 00       	call   0x0:0xffff
     321:	99                   	cwd
     322:	9a ff ff 00 00       	call   0x0:0xffff
     327:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     32a:	89 5e f4             	mov    WORD PTR [bp-0xc],bx
     32d:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
     330:	5f                   	pop    di
     331:	5e                   	pop    si
     332:	8d 66 fe             	lea    sp,[bp-0x2]
     335:	1f                   	pop    ds
     336:	5d                   	pop    bp
     337:	4d                   	dec    bp
     338:	cb                   	retf
     339:	00 00                	add    BYTE PTR [bx+si],al
     33b:	00 40 8c             	add    BYTE PTR [bx+si-0x74],al
     33e:	d8 90 45 55          	fcom   DWORD PTR [bx+si+0x5545]
     342:	89 e5                	mov    bp,sp
     344:	1e                   	push   ds
     345:	8e d8                	mov    ds,ax
     347:	b8 0e 00             	mov    ax,0xe
     34a:	9a ff ff 00 00       	call   0x0:0xffff
     34f:	83 ec 0e             	sub    sp,0xe
     352:	56                   	push   si
     353:	57                   	push   di
     354:	9b 2e d9 06 39 03    	fld    DWORD PTR cs:0x339
     35a:	9a ff ff 00 00       	call   0x0:0xffff
     35f:	9b d9 e1             	fabs
     362:	9a ff ff 00 00       	call   0x0:0xffff
     367:	9a ff ff 00 00       	call   0x0:0xffff
     36c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     36f:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     372:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     375:	9a ff ff 00 00       	call   0x0:0xffff
     37a:	99                   	cwd
     37b:	9a ff ff 00 00       	call   0x0:0xffff
     380:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     383:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     386:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     389:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     38c:	5f                   	pop    di
     38d:	5e                   	pop    si
     38e:	8d 66 fe             	lea    sp,[bp-0x2]
     391:	1f                   	pop    ds
     392:	5d                   	pop    bp
     393:	4d                   	dec    bp
     394:	cb                   	retf
     395:	8c d8                	mov    ax,ds
     397:	90                   	nop
     398:	45                   	inc    bp
     399:	55                   	push   bp
     39a:	89 e5                	mov    bp,sp
     39c:	1e                   	push   ds
     39d:	8e d8                	mov    ds,ax
     39f:	b8 14 00             	mov    ax,0x14
     3a2:	9a ff ff 00 00       	call   0x0:0xffff
     3a7:	83 ec 14             	sub    sp,0x14
     3aa:	56                   	push   si
     3ab:	57                   	push   di
     3ac:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     3af:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     3b2:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     3b5:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
     3b8:	89 5e ec             	mov    WORD PTR [bp-0x14],bx
     3bb:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     3be:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     3c1:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
     3c4:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
     3c7:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     3ca:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     3cd:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     3d0:	8b 46 ea             	mov    ax,WORD PTR [bp-0x16]
     3d3:	8b 5e ec             	mov    bx,WORD PTR [bp-0x14]
     3d6:	8b 56 ee             	mov    dx,WORD PTR [bp-0x12]
     3d9:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     3dc:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     3df:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     3e2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     3e5:	5f                   	pop    di
     3e6:	5e                   	pop    si
     3e7:	8d 66 fe             	lea    sp,[bp-0x2]
     3ea:	1f                   	pop    ds
     3eb:	5d                   	pop    bp
     3ec:	4d                   	dec    bp
     3ed:	cb                   	retf
     3ee:	8c d8                	mov    ax,ds
     3f0:	90                   	nop
     3f1:	45                   	inc    bp
     3f2:	55                   	push   bp
     3f3:	89 e5                	mov    bp,sp
     3f5:	1e                   	push   ds
     3f6:	8e d8                	mov    ds,ax
     3f8:	b8 20 00             	mov    ax,0x20
     3fb:	9a ff ff 00 00       	call   0x0:0xffff
     400:	83 ec 20             	sub    sp,0x20
     403:	56                   	push   si
     404:	57                   	push   di
     405:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     408:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     40b:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     40e:	9a ff ff 00 00       	call   0x0:0xffff
     413:	9b db 7e e0          	fstp   TBYTE PTR [bp-0x20]
     417:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     41a:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
     41d:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
     420:	9a ff ff 00 00       	call   0x0:0xffff
     425:	9b db 6e e0          	fld    TBYTE PTR [bp-0x20]
     429:	9b de d9             	fcompp
     42c:	9b dd 7e de          	fstsw  WORD PTR [bp-0x22]
     430:	90                   	nop
     431:	9b                   	fwait
     432:	8a 66 df             	mov    ah,BYTE PTR [bp-0x21]
     435:	9e                   	sahf
     436:	73 14                	jae    0x44c
     438:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     43b:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     43e:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     441:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
     444:	89 5e ec             	mov    WORD PTR [bp-0x14],bx
     447:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     44a:	eb 12                	jmp    0x45e
     44c:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     44f:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
     452:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
     455:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
     458:	89 5e ec             	mov    WORD PTR [bp-0x14],bx
     45b:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     45e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     461:	5f                   	pop    di
     462:	5e                   	pop    si
     463:	8d 66 fe             	lea    sp,[bp-0x2]
     466:	1f                   	pop    ds
     467:	5d                   	pop    bp
     468:	4d                   	dec    bp
     469:	cb                   	retf
     46a:	8c d8                	mov    ax,ds
     46c:	90                   	nop
     46d:	45                   	inc    bp
     46e:	55                   	push   bp
     46f:	89 e5                	mov    bp,sp
     471:	1e                   	push   ds
     472:	8e d8                	mov    ds,ax
     474:	b8 1e 00             	mov    ax,0x1e
     477:	9a ff ff 00 00       	call   0x0:0xffff
     47c:	83 ec 1e             	sub    sp,0x1e
     47f:	56                   	push   si
     480:	57                   	push   di
     481:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     484:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     487:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     48a:	9a ff ff 00 00       	call   0x0:0xffff
     48f:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     493:	9a ff ff 00 00       	call   0x0:0xffff
     498:	99                   	cwd
     499:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     49c:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     49f:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
     4a3:	9b db 6e e2          	fld    TBYTE PTR [bp-0x1e]
     4a7:	9b de d9             	fcompp
     4aa:	9b dd 7e e0          	fstsw  WORD PTR [bp-0x20]
     4ae:	90                   	nop
     4af:	9b                   	fwait
     4b0:	8a 66 e1             	mov    ah,BYTE PTR [bp-0x1f]
     4b3:	9e                   	sahf
     4b4:	73 14                	jae    0x4ca
     4b6:	9a ff ff 00 00       	call   0x0:0xffff
     4bb:	99                   	cwd
     4bc:	9a ff ff 00 00       	call   0x0:0xffff
     4c1:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     4c4:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     4c7:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     4ca:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     4cd:	5f                   	pop    di
     4ce:	5e                   	pop    si
     4cf:	8d 66 fe             	lea    sp,[bp-0x2]
     4d2:	1f                   	pop    ds
     4d3:	5d                   	pop    bp
     4d4:	4d                   	dec    bp
     4d5:	cb                   	retf
     4d6:	8c d8                	mov    ax,ds
     4d8:	90                   	nop
     4d9:	45                   	inc    bp
     4da:	55                   	push   bp
     4db:	89 e5                	mov    bp,sp
     4dd:	1e                   	push   ds
     4de:	8e d8                	mov    ds,ax
     4e0:	b8 1a 00             	mov    ax,0x1a
     4e3:	9a ff ff 00 00       	call   0x0:0xffff
     4e8:	83 ec 1a             	sub    sp,0x1a
     4eb:	56                   	push   si
     4ec:	57                   	push   di
     4ed:	9a ff ff 00 00       	call   0x0:0xffff
     4f2:	99                   	cwd
     4f3:	9a ff ff 00 00       	call   0x0:0xffff
     4f8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     4fb:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     4fe:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     501:	9a ff ff 00 00       	call   0x0:0xffff
     506:	99                   	cwd
     507:	9a ff ff 00 00       	call   0x0:0xffff
     50c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     50f:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     512:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     515:	9a ff ff 00 00       	call   0x0:0xffff
     51a:	99                   	cwd
     51b:	9a ff ff 00 00       	call   0x0:0xffff
     520:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     523:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     526:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     529:	9a ff ff 00 00       	call   0x0:0xffff
     52e:	99                   	cwd
     52f:	9a ff ff 00 00       	call   0x0:0xffff
     534:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     537:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     53a:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     53d:	9a ff ff 00 00       	call   0x0:0xffff
     542:	99                   	cwd
     543:	9a ff ff 00 00       	call   0x0:0xffff
     548:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     54b:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     54e:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     551:	9a ff ff 00 00       	call   0x0:0xffff
     556:	99                   	cwd
     557:	9a ff ff 00 00       	call   0x0:0xffff
     55c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     55f:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     562:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     565:	9a ff ff 00 00       	call   0x0:0xffff
     56a:	99                   	cwd
     56b:	9a ff ff 00 00       	call   0x0:0xffff
     570:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     573:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     576:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     579:	c7 46 f0 01 00       	mov    WORD PTR [bp-0x10],0x1
     57e:	eb 03                	jmp    0x583
     580:	ff 46 f0             	inc    WORD PTR [bp-0x10]
     583:	9a ff ff 00 00       	call   0x0:0xffff
     588:	99                   	cwd
     589:	9a ff ff 00 00       	call   0x0:0xffff
     58e:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     591:	89 5e f4             	mov    WORD PTR [bp-0xc],bx
     594:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
     597:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     59a:	8b 5e fa             	mov    bx,WORD PTR [bp-0x6]
     59d:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
     5a0:	9a ff ff 00 00       	call   0x0:0xffff
     5a5:	9b db 7e e6          	fstp   TBYTE PTR [bp-0x1a]
     5a9:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
     5ac:	8b 5e f4             	mov    bx,WORD PTR [bp-0xc]
     5af:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     5b2:	9a ff ff 00 00       	call   0x0:0xffff
     5b7:	9b db 6e e6          	fld    TBYTE PTR [bp-0x1a]
     5bb:	9b de d9             	fcompp
     5be:	9b dd 7e e4          	fstsw  WORD PTR [bp-0x1c]
     5c2:	90                   	nop
     5c3:	9b                   	fwait
     5c4:	8a 66 e5             	mov    ah,BYTE PTR [bp-0x1b]
     5c7:	9e                   	sahf
     5c8:	73 16                	jae    0x5e0
     5ca:	9a ff ff 00 00       	call   0x0:0xffff
     5cf:	99                   	cwd
     5d0:	9a ff ff 00 00       	call   0x0:0xffff
     5d5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     5d8:	89 5e f4             	mov    WORD PTR [bp-0xc],bx
     5db:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
     5de:	eb 14                	jmp    0x5f4
     5e0:	9a ff ff 00 00       	call   0x0:0xffff
     5e5:	99                   	cwd
     5e6:	9a ff ff 00 00       	call   0x0:0xffff
     5eb:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     5ee:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     5f1:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     5f4:	83 7e f0 08          	cmp    WORD PTR [bp-0x10],0x8
     5f8:	75 86                	jne    0x580
     5fa:	5f                   	pop    di
     5fb:	5e                   	pop    si
     5fc:	8d 66 fe             	lea    sp,[bp-0x2]
     5ff:	1f                   	pop    ds
     600:	5d                   	pop    bp
     601:	4d                   	dec    bp
     602:	cb                   	retf
     603:	8c d8                	mov    ax,ds
     605:	90                   	nop
     606:	45                   	inc    bp
     607:	55                   	push   bp
     608:	89 e5                	mov    bp,sp
     60a:	1e                   	push   ds
     60b:	8e d8                	mov    ds,ax
     60d:	b8 10 00             	mov    ax,0x10
     610:	9a ff ff 00 00       	call   0x0:0xffff
     615:	83 ec 10             	sub    sp,0x10
     618:	56                   	push   si
     619:	57                   	push   di
     61a:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
     61f:	eb 03                	jmp    0x624
     621:	ff 46 ee             	inc    WORD PTR [bp-0x12]
     624:	9b df 46 ee          	fild   WORD PTR [bp-0x12]
     628:	9a ff ff 00 00       	call   0x0:0xffff
     62d:	9a ff ff 00 00       	call   0x0:0xffff
     632:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     635:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     638:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     63b:	83 7e ee 03          	cmp    WORD PTR [bp-0x12],0x3
     63f:	75 e0                	jne    0x621
     641:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     644:	5f                   	pop    di
     645:	5e                   	pop    si
     646:	8d 66 fe             	lea    sp,[bp-0x2]
     649:	1f                   	pop    ds
     64a:	5d                   	pop    bp
     64b:	4d                   	dec    bp
     64c:	cb                   	retf
     64d:	8c d8                	mov    ax,ds
     64f:	90                   	nop
     650:	45                   	inc    bp
     651:	55                   	push   bp
     652:	89 e5                	mov    bp,sp
     654:	1e                   	push   ds
     655:	8e d8                	mov    ds,ax
     657:	b8 14 00             	mov    ax,0x14
     65a:	9a ff ff 00 00       	call   0x0:0xffff
     65f:	83 ec 14             	sub    sp,0x14
     662:	56                   	push   si
     663:	57                   	push   di
     664:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
     669:	eb 03                	jmp    0x66e
     66b:	ff 46 ee             	inc    WORD PTR [bp-0x12]
     66e:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
     671:	f7 66 ee             	mul    WORD PTR [bp-0x12]
     674:	99                   	cwd
     675:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
     678:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
     67b:	9b db 46 ea          	fild   DWORD PTR [bp-0x16]
     67f:	9a ff ff 00 00       	call   0x0:0xffff
     684:	9a ff ff 00 00       	call   0x0:0xffff
     689:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     68c:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     68f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     692:	83 7e ee 03          	cmp    WORD PTR [bp-0x12],0x3
     696:	75 d3                	jne    0x66b
     698:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     69b:	5f                   	pop    di
     69c:	5e                   	pop    si
     69d:	8d 66 fe             	lea    sp,[bp-0x2]
     6a0:	1f                   	pop    ds
     6a1:	5d                   	pop    bp
     6a2:	4d                   	dec    bp
     6a3:	cb                   	retf
     6a4:	8c d8                	mov    ax,ds
     6a6:	90                   	nop
     6a7:	45                   	inc    bp
     6a8:	55                   	push   bp
     6a9:	89 e5                	mov    bp,sp
     6ab:	1e                   	push   ds
     6ac:	8e d8                	mov    ds,ax
     6ae:	b8 10 00             	mov    ax,0x10
     6b1:	9a ff ff 00 00       	call   0x0:0xffff
     6b6:	83 ec 10             	sub    sp,0x10
     6b9:	56                   	push   si
     6ba:	57                   	push   di
     6bb:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
     6c0:	eb 03                	jmp    0x6c5
     6c2:	ff 46 ee             	inc    WORD PTR [bp-0x12]
     6c5:	9a ff ff 00 00       	call   0x0:0xffff
     6ca:	9a ff ff 00 00       	call   0x0:0xffff
     6cf:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     6d2:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     6d5:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     6d8:	83 7e ee 03          	cmp    WORD PTR [bp-0x12],0x3
     6dc:	75 e4                	jne    0x6c2
     6de:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     6e1:	5f                   	pop    di
     6e2:	5e                   	pop    si
     6e3:	8d 66 fe             	lea    sp,[bp-0x2]
     6e6:	1f                   	pop    ds
     6e7:	5d                   	pop    bp
     6e8:	4d                   	dec    bp
     6e9:	cb                   	retf
     6ea:	8c d8                	mov    ax,ds
     6ec:	90                   	nop
     6ed:	45                   	inc    bp
     6ee:	55                   	push   bp
     6ef:	89 e5                	mov    bp,sp
     6f1:	1e                   	push   ds
     6f2:	8e d8                	mov    ds,ax
     6f4:	b8 14 00             	mov    ax,0x14
     6f7:	9a ff ff 00 00       	call   0x0:0xffff
     6fc:	83 ec 14             	sub    sp,0x14
     6ff:	56                   	push   si
     700:	57                   	push   di
     701:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
     706:	eb 03                	jmp    0x70b
     708:	ff 46 ee             	inc    WORD PTR [bp-0x12]
     70b:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
     70e:	f7 66 ee             	mul    WORD PTR [bp-0x12]
     711:	99                   	cwd
     712:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
     715:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
     718:	9b db 46 ea          	fild   DWORD PTR [bp-0x16]
     71c:	9a ff ff 00 00       	call   0x0:0xffff
     721:	9a ff ff 00 00       	call   0x0:0xffff
     726:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     729:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     72c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     72f:	83 7e ee 03          	cmp    WORD PTR [bp-0x12],0x3
     733:	75 d3                	jne    0x708
     735:	9a ff ff 00 00       	call   0x0:0xffff
     73a:	99                   	cwd
     73b:	9a ff ff 00 00       	call   0x0:0xffff
     740:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     743:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     746:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     749:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     74c:	5f                   	pop    di
     74d:	5e                   	pop    si
     74e:	8d 66 fe             	lea    sp,[bp-0x2]
     751:	1f                   	pop    ds
     752:	5d                   	pop    bp
     753:	4d                   	dec    bp
     754:	cb                   	retf
     755:	8c d8                	mov    ax,ds
     757:	90                   	nop
     758:	45                   	inc    bp
     759:	55                   	push   bp
     75a:	89 e5                	mov    bp,sp
     75c:	1e                   	push   ds
     75d:	8e d8                	mov    ds,ax
     75f:	b8 14 00             	mov    ax,0x14
     762:	9a ff ff 00 00       	call   0x0:0xffff
     767:	83 ec 14             	sub    sp,0x14
     76a:	56                   	push   si
     76b:	57                   	push   di
     76c:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
     771:	eb 03                	jmp    0x776
     773:	ff 46 ee             	inc    WORD PTR [bp-0x12]
     776:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
     779:	f7 66 ee             	mul    WORD PTR [bp-0x12]
     77c:	99                   	cwd
     77d:	89 46 ea             	mov    WORD PTR [bp-0x16],ax
     780:	89 56 ec             	mov    WORD PTR [bp-0x14],dx
     783:	9b db 46 ea          	fild   DWORD PTR [bp-0x16]
     787:	9a ff ff 00 00       	call   0x0:0xffff
     78c:	9a ff ff 00 00       	call   0x0:0xffff
     791:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     794:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     797:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     79a:	83 7e ee 03          	cmp    WORD PTR [bp-0x12],0x3
     79e:	75 d3                	jne    0x773
     7a0:	9a ff ff 00 00       	call   0x0:0xffff
     7a5:	99                   	cwd
     7a6:	9a ff ff 00 00       	call   0x0:0xffff
     7ab:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     7ae:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     7b1:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     7b4:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     7b7:	5f                   	pop    di
     7b8:	5e                   	pop    si
     7b9:	8d 66 fe             	lea    sp,[bp-0x2]
     7bc:	1f                   	pop    ds
     7bd:	5d                   	pop    bp
     7be:	4d                   	dec    bp
     7bf:	cb                   	retf
     7c0:	8c d8                	mov    ax,ds
     7c2:	90                   	nop
     7c3:	45                   	inc    bp
     7c4:	55                   	push   bp
     7c5:	89 e5                	mov    bp,sp
     7c7:	1e                   	push   ds
     7c8:	8e d8                	mov    ds,ax
     7ca:	b8 10 00             	mov    ax,0x10
     7cd:	9a ff ff 00 00       	call   0x0:0xffff
     7d2:	83 ec 10             	sub    sp,0x10
     7d5:	56                   	push   si
     7d6:	57                   	push   di
     7d7:	c7 46 ee 01 00       	mov    WORD PTR [bp-0x12],0x1
     7dc:	eb 03                	jmp    0x7e1
     7de:	ff 46 ee             	inc    WORD PTR [bp-0x12]
     7e1:	9b df 46 ee          	fild   WORD PTR [bp-0x12]
     7e5:	9a ff ff 00 00       	call   0x0:0xffff
     7ea:	9a ff ff 00 00       	call   0x0:0xffff
     7ef:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     7f2:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     7f5:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     7f8:	83 7e ee 04          	cmp    WORD PTR [bp-0x12],0x4
     7fc:	75 e0                	jne    0x7de
     7fe:	9a ff ff 00 00       	call   0x0:0xffff
     803:	99                   	cwd
     804:	9a ff ff 00 00       	call   0x0:0xffff
     809:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     80c:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     80f:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     812:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     815:	5f                   	pop    di
     816:	5e                   	pop    si
     817:	8d 66 fe             	lea    sp,[bp-0x2]
     81a:	1f                   	pop    ds
     81b:	5d                   	pop    bp
     81c:	4d                   	dec    bp
     81d:	cb                   	retf
     81e:	8c d8                	mov    ax,ds
     820:	90                   	nop
     821:	45                   	inc    bp
     822:	55                   	push   bp
     823:	89 e5                	mov    bp,sp
     825:	1e                   	push   ds
     826:	8e d8                	mov    ds,ax
     828:	b8 0e 00             	mov    ax,0xe
     82b:	9a ff ff 00 00       	call   0x0:0xffff
     830:	83 ec 0e             	sub    sp,0xe
     833:	56                   	push   si
     834:	57                   	push   di
     835:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     838:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
     83b:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
     83e:	9a ff ff 00 00       	call   0x0:0xffff
     843:	9a ff ff 00 00       	call   0x0:0xffff
     848:	9a ff ff 00 00       	call   0x0:0xffff
     84d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     850:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     853:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     856:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     859:	5f                   	pop    di
     85a:	5e                   	pop    si
     85b:	8d 66 fe             	lea    sp,[bp-0x2]
     85e:	1f                   	pop    ds
     85f:	5d                   	pop    bp
     860:	4d                   	dec    bp
     861:	cb                   	retf
     862:	8c d8                	mov    ax,ds
     864:	90                   	nop
     865:	45                   	inc    bp
     866:	55                   	push   bp
     867:	89 e5                	mov    bp,sp
     869:	1e                   	push   ds
     86a:	8e d8                	mov    ds,ax
     86c:	b8 0e 00             	mov    ax,0xe
     86f:	9a ff ff 00 00       	call   0x0:0xffff
     874:	83 ec 0e             	sub    sp,0xe
     877:	56                   	push   si
     878:	57                   	push   di
     879:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     87c:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     87f:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     882:	9a ff ff 00 00       	call   0x0:0xffff
     887:	9a ff ff 00 00       	call   0x0:0xffff
     88c:	9a ff ff 00 00       	call   0x0:0xffff
     891:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     894:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     897:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     89a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     89d:	5f                   	pop    di
     89e:	5e                   	pop    si
     89f:	8d 66 fe             	lea    sp,[bp-0x2]
     8a2:	1f                   	pop    ds
     8a3:	5d                   	pop    bp
     8a4:	4d                   	dec    bp
     8a5:	cb                   	retf
     8a6:	8c d8                	mov    ax,ds
     8a8:	90                   	nop
     8a9:	45                   	inc    bp
     8aa:	55                   	push   bp
     8ab:	89 e5                	mov    bp,sp
     8ad:	1e                   	push   ds
     8ae:	8e d8                	mov    ds,ax
     8b0:	b8 0e 00             	mov    ax,0xe
     8b3:	9a ff ff 00 00       	call   0x0:0xffff
     8b8:	83 ec 0e             	sub    sp,0xe
     8bb:	56                   	push   si
     8bc:	57                   	push   di
     8bd:	9a ff ff 00 00       	call   0x0:0xffff
     8c2:	99                   	cwd
     8c3:	9a ff ff 00 00       	call   0x0:0xffff
     8c8:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     8cb:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     8ce:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     8d1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     8d4:	5f                   	pop    di
     8d5:	5e                   	pop    si
     8d6:	8d 66 fe             	lea    sp,[bp-0x2]
     8d9:	1f                   	pop    ds
     8da:	5d                   	pop    bp
     8db:	4d                   	dec    bp
     8dc:	cb                   	retf
     8dd:	8c d8                	mov    ax,ds
     8df:	90                   	nop
     8e0:	45                   	inc    bp
     8e1:	55                   	push   bp
     8e2:	89 e5                	mov    bp,sp
     8e4:	1e                   	push   ds
     8e5:	8e d8                	mov    ds,ax
     8e7:	b8 1c 00             	mov    ax,0x1c
     8ea:	9a ff ff 00 00       	call   0x0:0xffff
     8ef:	83 ec 1c             	sub    sp,0x1c
     8f2:	56                   	push   si
     8f3:	57                   	push   di
     8f4:	9a ff ff 00 00       	call   0x0:0xffff
     8f9:	99                   	cwd
     8fa:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     8fd:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     900:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
     904:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     908:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     90b:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
     90e:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
     911:	9a ff ff 00 00       	call   0x0:0xffff
     916:	9a ff ff 00 00       	call   0x0:0xffff
     91b:	9b db 6e e2          	fld    TBYTE PTR [bp-0x1e]
     91f:	9b de c1             	faddp  st(1),st
     922:	9a ff ff 00 00       	call   0x0:0xffff
     927:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     92a:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     92d:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     930:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     933:	5f                   	pop    di
     934:	5e                   	pop    si
     935:	8d 66 fe             	lea    sp,[bp-0x2]
     938:	1f                   	pop    ds
     939:	5d                   	pop    bp
     93a:	4d                   	dec    bp
     93b:	cb                   	retf
     93c:	8c d8                	mov    ax,ds
     93e:	90                   	nop
     93f:	45                   	inc    bp
     940:	55                   	push   bp
     941:	89 e5                	mov    bp,sp
     943:	1e                   	push   ds
     944:	8e d8                	mov    ds,ax
     946:	b8 1c 00             	mov    ax,0x1c
     949:	9a ff ff 00 00       	call   0x0:0xffff
     94e:	83 ec 1c             	sub    sp,0x1c
     951:	56                   	push   si
     952:	57                   	push   di
     953:	9a ff ff 00 00       	call   0x0:0xffff
     958:	99                   	cwd
     959:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     95c:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     95f:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
     963:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     967:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     96a:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
     96d:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
     970:	9a ff ff 00 00       	call   0x0:0xffff
     975:	9a ff ff 00 00       	call   0x0:0xffff
     97a:	9b db 6e e2          	fld    TBYTE PTR [bp-0x1e]
     97e:	9b de c1             	faddp  st(1),st
     981:	9a ff ff 00 00       	call   0x0:0xffff
     986:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     989:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     98c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     98f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     992:	5f                   	pop    di
     993:	5e                   	pop    si
     994:	8d 66 fe             	lea    sp,[bp-0x2]
     997:	1f                   	pop    ds
     998:	5d                   	pop    bp
     999:	4d                   	dec    bp
     99a:	cb                   	retf
     99b:	8c d8                	mov    ax,ds
     99d:	90                   	nop
     99e:	45                   	inc    bp
     99f:	55                   	push   bp
     9a0:	89 e5                	mov    bp,sp
     9a2:	1e                   	push   ds
     9a3:	8e d8                	mov    ds,ax
     9a5:	b8 26 00             	mov    ax,0x26
     9a8:	9a ff ff 00 00       	call   0x0:0xffff
     9ad:	83 ec 26             	sub    sp,0x26
     9b0:	56                   	push   si
     9b1:	57                   	push   di
     9b2:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     9b5:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     9b8:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     9bb:	9a ff ff 00 00       	call   0x0:0xffff
     9c0:	9a ff ff 00 00       	call   0x0:0xffff
     9c5:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     9c9:	9a ff ff 00 00       	call   0x0:0xffff
     9ce:	99                   	cwd
     9cf:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     9d2:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     9d5:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
     9d9:	9b db 6e e2          	fld    TBYTE PTR [bp-0x1e]
     9dd:	9b de c1             	faddp  st(1),st
     9e0:	9b db 7e d8          	fstp   TBYTE PTR [bp-0x28]
     9e4:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     9e7:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
     9ea:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
     9ed:	9a ff ff 00 00       	call   0x0:0xffff
     9f2:	9a ff ff 00 00       	call   0x0:0xffff
     9f7:	9b db 6e d8          	fld    TBYTE PTR [bp-0x28]
     9fb:	9b de c1             	faddp  st(1),st
     9fe:	9a ff ff 00 00       	call   0x0:0xffff
     a03:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     a06:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     a09:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     a0c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     a0f:	5f                   	pop    di
     a10:	5e                   	pop    si
     a11:	8d 66 fe             	lea    sp,[bp-0x2]
     a14:	1f                   	pop    ds
     a15:	5d                   	pop    bp
     a16:	4d                   	dec    bp
     a17:	cb                   	retf
     a18:	8c d8                	mov    ax,ds
     a1a:	90                   	nop
     a1b:	45                   	inc    bp
     a1c:	55                   	push   bp
     a1d:	89 e5                	mov    bp,sp
     a1f:	1e                   	push   ds
     a20:	8e d8                	mov    ds,ax
     a22:	b8 02 00             	mov    ax,0x2
     a25:	9a ff ff 00 00       	call   0x0:0xffff
     a2a:	83 ec 02             	sub    sp,0x2
     a2d:	56                   	push   si
     a2e:	57                   	push   di
     a2f:	c7 46 fc 08 00       	mov    WORD PTR [bp-0x4],0x8
     a34:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     a37:	5f                   	pop    di
     a38:	5e                   	pop    si
     a39:	8d 66 fe             	lea    sp,[bp-0x2]
     a3c:	1f                   	pop    ds
     a3d:	5d                   	pop    bp
     a3e:	4d                   	dec    bp
     a3f:	cb                   	retf
     a40:	8c d8                	mov    ax,ds
     a42:	90                   	nop
     a43:	45                   	inc    bp
     a44:	55                   	push   bp
     a45:	89 e5                	mov    bp,sp
     a47:	1e                   	push   ds
     a48:	8e d8                	mov    ds,ax
     a4a:	b8 06 00             	mov    ax,0x6
     a4d:	9a ff ff 00 00       	call   0x0:0xffff
     a52:	83 ec 06             	sub    sp,0x6
     a55:	56                   	push   si
     a56:	57                   	push   di
     a57:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
     a5c:	eb 03                	jmp    0xa61
     a5e:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     a61:	9a ff ff 00 00       	call   0x0:0xffff
     a66:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     a69:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
     a6e:	eb 03                	jmp    0xa73
     a70:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     a73:	9a ff ff 00 00       	call   0x0:0xffff
     a78:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     a7b:	9a ff ff 00 00       	call   0x0:0xffff
     a80:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     a83:	83 7e fa 03          	cmp    WORD PTR [bp-0x6],0x3
     a87:	75 e7                	jne    0xa70
     a89:	9a ff ff 00 00       	call   0x0:0xffff
     a8e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     a91:	83 7e fc 04          	cmp    WORD PTR [bp-0x4],0x4
     a95:	75 c7                	jne    0xa5e
     a97:	5f                   	pop    di
     a98:	5e                   	pop    si
     a99:	8d 66 fe             	lea    sp,[bp-0x2]
     a9c:	1f                   	pop    ds
     a9d:	5d                   	pop    bp
     a9e:	4d                   	dec    bp
     a9f:	cb                   	retf
     aa0:	8c d8                	mov    ax,ds
     aa2:	90                   	nop
     aa3:	45                   	inc    bp
     aa4:	55                   	push   bp
     aa5:	89 e5                	mov    bp,sp
     aa7:	1e                   	push   ds
     aa8:	8e d8                	mov    ds,ax
     aaa:	b8 0e 00             	mov    ax,0xe
     aad:	9a ff ff 00 00       	call   0x0:0xffff
     ab2:	83 ec 0e             	sub    sp,0xe
     ab5:	56                   	push   si
     ab6:	57                   	push   di
     ab7:	9a ff ff 00 00       	call   0x0:0xffff
     abc:	99                   	cwd
     abd:	9a ff ff 00 00       	call   0x0:0xffff
     ac2:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     ac5:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     ac8:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     acb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     ace:	5f                   	pop    di
     acf:	5e                   	pop    si
     ad0:	8d 66 fe             	lea    sp,[bp-0x2]
     ad3:	1f                   	pop    ds
     ad4:	5d                   	pop    bp
     ad5:	4d                   	dec    bp
     ad6:	cb                   	retf
     ad7:	8c d8                	mov    ax,ds
     ad9:	90                   	nop
     ada:	45                   	inc    bp
     adb:	55                   	push   bp
     adc:	89 e5                	mov    bp,sp
     ade:	1e                   	push   ds
     adf:	8e d8                	mov    ds,ax
     ae1:	b8 0e 00             	mov    ax,0xe
     ae4:	9a ff ff 00 00       	call   0x0:0xffff
     ae9:	83 ec 0e             	sub    sp,0xe
     aec:	56                   	push   si
     aed:	57                   	push   di
     aee:	9a ff ff 00 00       	call   0x0:0xffff
     af3:	50                   	push   ax
     af4:	9a ff ff 00 00       	call   0x0:0xffff
     af9:	5a                   	pop    dx
     afa:	03 c2                	add    ax,dx
     afc:	99                   	cwd
     afd:	9a ff ff 00 00       	call   0x0:0xffff
     b02:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     b05:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     b08:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     b0b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b0e:	5f                   	pop    di
     b0f:	5e                   	pop    si
     b10:	8d 66 fe             	lea    sp,[bp-0x2]
     b13:	1f                   	pop    ds
     b14:	5d                   	pop    bp
     b15:	4d                   	dec    bp
     b16:	cb                   	retf
     b17:	8c d8                	mov    ax,ds
     b19:	90                   	nop
     b1a:	45                   	inc    bp
     b1b:	55                   	push   bp
     b1c:	89 e5                	mov    bp,sp
     b1e:	1e                   	push   ds
     b1f:	8e d8                	mov    ds,ax
     b21:	b8 0e 00             	mov    ax,0xe
     b24:	9a ff ff 00 00       	call   0x0:0xffff
     b29:	83 ec 0e             	sub    sp,0xe
     b2c:	56                   	push   si
     b2d:	57                   	push   di
     b2e:	9a ff ff 00 00       	call   0x0:0xffff
     b33:	50                   	push   ax
     b34:	9a ff ff 00 00       	call   0x0:0xffff
     b39:	5a                   	pop    dx
     b3a:	03 c2                	add    ax,dx
     b3c:	99                   	cwd
     b3d:	9a ff ff 00 00       	call   0x0:0xffff
     b42:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     b45:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     b48:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     b4b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     b4e:	5f                   	pop    di
     b4f:	5e                   	pop    si
     b50:	8d 66 fe             	lea    sp,[bp-0x2]
     b53:	1f                   	pop    ds
     b54:	5d                   	pop    bp
     b55:	4d                   	dec    bp
     b56:	cb                   	retf
     b57:	00 00                	add    BYTE PTR [bx+si],al
     b59:	00 41 8c             	add    BYTE PTR [bx+di-0x74],al
     b5c:	d8 90 45 55          	fcom   DWORD PTR [bx+si+0x5545]
     b60:	89 e5                	mov    bp,sp
     b62:	1e                   	push   ds
     b63:	8e d8                	mov    ds,ax
     b65:	b8 2a 00             	mov    ax,0x2a
     b68:	9a ff ff 00 00       	call   0x0:0xffff
     b6d:	83 ec 2a             	sub    sp,0x2a
     b70:	56                   	push   si
     b71:	57                   	push   di
     b72:	9b 2e d9 06 57 0b    	fld    DWORD PTR cs:0xb57
     b78:	9a ff ff 00 00       	call   0x0:0xffff
     b7d:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     b81:	9a ff ff 00 00       	call   0x0:0xffff
     b86:	99                   	cwd
     b87:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     b8a:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     b8d:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
     b91:	9b db 6e e2          	fld    TBYTE PTR [bp-0x1e]
     b95:	9b de c1             	faddp  st(1),st
     b98:	9b db 7e d4          	fstp   TBYTE PTR [bp-0x2c]
     b9c:	9a ff ff 00 00       	call   0x0:0xffff
     ba1:	99                   	cwd
     ba2:	89 46 de             	mov    WORD PTR [bp-0x22],ax
     ba5:	89 56 e0             	mov    WORD PTR [bp-0x20],dx
     ba8:	9b db 46 de          	fild   DWORD PTR [bp-0x22]
     bac:	9b db 6e d4          	fld    TBYTE PTR [bp-0x2c]
     bb0:	9b de c1             	faddp  st(1),st
     bb3:	9a ff ff 00 00       	call   0x0:0xffff
     bb8:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
     bbb:	89 5e f2             	mov    WORD PTR [bp-0xe],bx
     bbe:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     bc1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     bc4:	5f                   	pop    di
     bc5:	5e                   	pop    si
     bc6:	8d 66 fe             	lea    sp,[bp-0x2]
     bc9:	1f                   	pop    ds
     bca:	5d                   	pop    bp
     bcb:	4d                   	dec    bp
     bcc:	cb                   	retf
     bcd:	8c d8                	mov    ax,ds
     bcf:	90                   	nop
     bd0:	45                   	inc    bp
     bd1:	55                   	push   bp
     bd2:	89 e5                	mov    bp,sp
     bd4:	1e                   	push   ds
     bd5:	8e d8                	mov    ds,ax
     bd7:	b8 08 00             	mov    ax,0x8
     bda:	9a ff ff 00 00       	call   0x0:0xffff
     bdf:	83 ec 08             	sub    sp,0x8
     be2:	56                   	push   si
     be3:	57                   	push   di
     be4:	9a ff ff 00 00       	call   0x0:0xffff
     be9:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     bec:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
     bf1:	eb 03                	jmp    0xbf6
     bf3:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     bf6:	9a ff ff 00 00       	call   0x0:0xffff
     bfb:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     bfe:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
     c03:	eb 03                	jmp    0xc08
     c05:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     c08:	9a ff ff 00 00       	call   0x0:0xffff
     c0d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     c10:	c7 46 f8 01 00       	mov    WORD PTR [bp-0x8],0x1
     c15:	eb 03                	jmp    0xc1a
     c17:	ff 46 f8             	inc    WORD PTR [bp-0x8]
     c1a:	9a ff ff 00 00       	call   0x0:0xffff
     c1f:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     c22:	9a ff ff 00 00       	call   0x0:0xffff
     c27:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     c2a:	9a ff ff 00 00       	call   0x0:0xffff
     c2f:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     c32:	83 7e f8 03          	cmp    WORD PTR [bp-0x8],0x3
     c36:	75 df                	jne    0xc17
     c38:	9a ff ff 00 00       	call   0x0:0xffff
     c3d:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     c40:	83 7e fa 04          	cmp    WORD PTR [bp-0x6],0x4
     c44:	75 bf                	jne    0xc05
     c46:	9a ff ff 00 00       	call   0x0:0xffff
     c4b:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     c4e:	83 7e fc 08          	cmp    WORD PTR [bp-0x4],0x8
     c52:	75 9f                	jne    0xbf3
     c54:	9a ff ff 00 00       	call   0x0:0xffff
     c59:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     c5c:	5f                   	pop    di
     c5d:	5e                   	pop    si
     c5e:	8d 66 fe             	lea    sp,[bp-0x2]
     c61:	1f                   	pop    ds
     c62:	5d                   	pop    bp
     c63:	4d                   	dec    bp
     c64:	cb                   	retf
     c65:	8c d8                	mov    ax,ds
     c67:	90                   	nop
     c68:	45                   	inc    bp
     c69:	55                   	push   bp
     c6a:	89 e5                	mov    bp,sp
     c6c:	1e                   	push   ds
     c6d:	8e d8                	mov    ds,ax
     c6f:	b8 20 01             	mov    ax,0x120
     c72:	9a ff ff 00 00       	call   0x0:0xffff
     c77:	81 ec 20 01          	sub    sp,0x120
     c7b:	56                   	push   si
     c7c:	57                   	push   di
     c7d:	8b 86 f6 fe          	mov    ax,WORD PTR [bp-0x10a]
     c81:	8b 9e f8 fe          	mov    bx,WORD PTR [bp-0x108]
     c85:	8b 96 fa fe          	mov    dx,WORD PTR [bp-0x106]
     c89:	9a ff ff 00 00       	call   0x0:0xffff
     c8e:	9a ff ff 00 00       	call   0x0:0xffff
     c93:	9b db be e8 fe       	fstp   TBYTE PTR [bp-0x118]
     c98:	9a ff ff 00 00       	call   0x0:0xffff
     c9d:	99                   	cwd
     c9e:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
     ca2:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
     ca6:	9b db 86 f2 fe       	fild   DWORD PTR [bp-0x10e]
     cab:	9b db ae e8 fe       	fld    TBYTE PTR [bp-0x118]
     cb0:	9b de c1             	faddp  st(1),st
     cb3:	9b db be de fe       	fstp   TBYTE PTR [bp-0x122]
     cb8:	8b 86 f6 fe          	mov    ax,WORD PTR [bp-0x10a]
     cbc:	8b 9e f8 fe          	mov    bx,WORD PTR [bp-0x108]
     cc0:	8b 96 fa fe          	mov    dx,WORD PTR [bp-0x106]
     cc4:	9a ff ff 00 00       	call   0x0:0xffff
     cc9:	9a ff ff 00 00       	call   0x0:0xffff
     cce:	9b db ae de fe       	fld    TBYTE PTR [bp-0x122]
     cd3:	9b de c1             	faddp  st(1),st
     cd6:	9a ff ff 00 00       	call   0x0:0xffff
     cdb:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
     cdf:	89 9e f8 fe          	mov    WORD PTR [bp-0x108],bx
     ce3:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
     ce7:	c6 86 fc fe 00       	mov    BYTE PTR [bp-0x104],0x0
     cec:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     cef:	5f                   	pop    di
     cf0:	5e                   	pop    si
     cf1:	8d 66 fe             	lea    sp,[bp-0x2]
     cf4:	1f                   	pop    ds
     cf5:	5d                   	pop    bp
     cf6:	4d                   	dec    bp
     cf7:	cb                   	retf
     cf8:	8c d8                	mov    ax,ds
     cfa:	90                   	nop
     cfb:	45                   	inc    bp
     cfc:	55                   	push   bp
     cfd:	89 e5                	mov    bp,sp
     cff:	1e                   	push   ds
     d00:	8e d8                	mov    ds,ax
     d02:	b8 02 01             	mov    ax,0x102
     d05:	9a ff ff 00 00       	call   0x0:0xffff
     d0a:	81 ec 02 01          	sub    sp,0x102
     d0e:	56                   	push   si
     d0f:	57                   	push   di
     d10:	c6 86 fc fe 00       	mov    BYTE PTR [bp-0x104],0x0
     d15:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     d18:	5f                   	pop    di
     d19:	5e                   	pop    si
     d1a:	8d 66 fe             	lea    sp,[bp-0x2]
     d1d:	1f                   	pop    ds
     d1e:	5d                   	pop    bp
     d1f:	4d                   	dec    bp
     d20:	cb                   	retf
     d21:	8c d8                	mov    ax,ds
     d23:	90                   	nop
     d24:	45                   	inc    bp
     d25:	55                   	push   bp
     d26:	89 e5                	mov    bp,sp
     d28:	1e                   	push   ds
     d29:	8e d8                	mov    ds,ax
     d2b:	b8 16 01             	mov    ax,0x116
     d2e:	9a ff ff 00 00       	call   0x0:0xffff
     d33:	81 ec 16 01          	sub    sp,0x116
     d37:	56                   	push   si
     d38:	57                   	push   di
     d39:	9a ff ff 00 00       	call   0x0:0xffff
     d3e:	05 08 00             	add    ax,0x8
     d41:	99                   	cwd
     d42:	89 86 f2 fe          	mov    WORD PTR [bp-0x10e],ax
     d46:	89 96 f4 fe          	mov    WORD PTR [bp-0x10c],dx
     d4a:	9b db 86 f2 fe       	fild   DWORD PTR [bp-0x10e]
     d4f:	9b db be e8 fe       	fstp   TBYTE PTR [bp-0x118]
     d54:	8b 86 f6 fe          	mov    ax,WORD PTR [bp-0x10a]
     d58:	8b 9e f8 fe          	mov    bx,WORD PTR [bp-0x108]
     d5c:	8b 96 fa fe          	mov    dx,WORD PTR [bp-0x106]
     d60:	9a ff ff 00 00       	call   0x0:0xffff
     d65:	9a ff ff 00 00       	call   0x0:0xffff
     d6a:	9b db ae e8 fe       	fld    TBYTE PTR [bp-0x118]
     d6f:	9b de c1             	faddp  st(1),st
     d72:	9a ff ff 00 00       	call   0x0:0xffff
     d77:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
     d7b:	89 9e f8 fe          	mov    WORD PTR [bp-0x108],bx
     d7f:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
     d83:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     d86:	5f                   	pop    di
     d87:	5e                   	pop    si
     d88:	8d 66 fe             	lea    sp,[bp-0x2]
     d8b:	1f                   	pop    ds
     d8c:	5d                   	pop    bp
     d8d:	4d                   	dec    bp
     d8e:	cb                   	retf
     d8f:	8c d8                	mov    ax,ds
     d91:	90                   	nop
     d92:	45                   	inc    bp
     d93:	55                   	push   bp
     d94:	89 e5                	mov    bp,sp
     d96:	1e                   	push   ds
     d97:	8e d8                	mov    ds,ax
     d99:	b8 1c 00             	mov    ax,0x1c
     d9c:	9a ff ff 00 00       	call   0x0:0xffff
     da1:	83 ec 1c             	sub    sp,0x1c
     da4:	56                   	push   si
     da5:	57                   	push   di
     da6:	9a ff ff 00 00       	call   0x0:0xffff
     dab:	05 04 00             	add    ax,0x4
     dae:	99                   	cwd
     daf:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     db2:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     db5:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
     db9:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     dbd:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     dc0:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     dc3:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     dc6:	9a ff ff 00 00       	call   0x0:0xffff
     dcb:	9a ff ff 00 00       	call   0x0:0xffff
     dd0:	9b db 6e e2          	fld    TBYTE PTR [bp-0x1e]
     dd4:	9b de c1             	faddp  st(1),st
     dd7:	9a ff ff 00 00       	call   0x0:0xffff
     ddc:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     ddf:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     de2:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     de5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     de8:	5f                   	pop    di
     de9:	5e                   	pop    si
     dea:	8d 66 fe             	lea    sp,[bp-0x2]
     ded:	1f                   	pop    ds
     dee:	5d                   	pop    bp
     def:	4d                   	dec    bp
     df0:	cb                   	retf
     df1:	8c d8                	mov    ax,ds
     df3:	90                   	nop
     df4:	45                   	inc    bp
     df5:	55                   	push   bp
     df6:	89 e5                	mov    bp,sp
     df8:	1e                   	push   ds
     df9:	8e d8                	mov    ds,ax
     dfb:	b8 1c 00             	mov    ax,0x1c
     dfe:	9a ff ff 00 00       	call   0x0:0xffff
     e03:	83 ec 1c             	sub    sp,0x1c
     e06:	56                   	push   si
     e07:	57                   	push   di
     e08:	9a ff ff 00 00       	call   0x0:0xffff
     e0d:	05 03 00             	add    ax,0x3
     e10:	99                   	cwd
     e11:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     e14:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     e17:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
     e1b:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     e1f:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     e22:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     e25:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     e28:	9a ff ff 00 00       	call   0x0:0xffff
     e2d:	9a ff ff 00 00       	call   0x0:0xffff
     e32:	9b db 6e e2          	fld    TBYTE PTR [bp-0x1e]
     e36:	9b de c1             	faddp  st(1),st
     e39:	9a ff ff 00 00       	call   0x0:0xffff
     e3e:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     e41:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     e44:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     e47:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     e4a:	5f                   	pop    di
     e4b:	5e                   	pop    si
     e4c:	8d 66 fe             	lea    sp,[bp-0x2]
     e4f:	1f                   	pop    ds
     e50:	5d                   	pop    bp
     e51:	4d                   	dec    bp
     e52:	cb                   	retf
     e53:	8c d8                	mov    ax,ds
     e55:	90                   	nop
     e56:	45                   	inc    bp
     e57:	55                   	push   bp
     e58:	89 e5                	mov    bp,sp
     e5a:	1e                   	push   ds
     e5b:	8e d8                	mov    ds,ax
     e5d:	b8 04 00             	mov    ax,0x4
     e60:	9a ff ff 00 00       	call   0x0:0xffff
     e65:	83 ec 04             	sub    sp,0x4
     e68:	56                   	push   si
     e69:	57                   	push   di
     e6a:	9a ff ff 00 00       	call   0x0:0xffff
     e6f:	50                   	push   ax
     e70:	9a ff ff 00 00       	call   0x0:0xffff
     e75:	5a                   	pop    dx
     e76:	03 c2                	add    ax,dx
     e78:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     e7b:	c7 46 fc 01 00       	mov    WORD PTR [bp-0x4],0x1
     e80:	eb 03                	jmp    0xe85
     e82:	ff 46 fc             	inc    WORD PTR [bp-0x4]
     e85:	9a ff ff 00 00       	call   0x0:0xffff
     e8a:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     e8d:	83 7e fc 08          	cmp    WORD PTR [bp-0x4],0x8
     e91:	75 ef                	jne    0xe82
     e93:	5f                   	pop    di
     e94:	5e                   	pop    si
     e95:	8d 66 fe             	lea    sp,[bp-0x2]
     e98:	1f                   	pop    ds
     e99:	5d                   	pop    bp
     e9a:	4d                   	dec    bp
     e9b:	cb                   	retf
     e9c:	8c d8                	mov    ax,ds
     e9e:	90                   	nop
     e9f:	45                   	inc    bp
     ea0:	55                   	push   bp
     ea1:	89 e5                	mov    bp,sp
     ea3:	1e                   	push   ds
     ea4:	8e d8                	mov    ds,ax
     ea6:	b8 0e 01             	mov    ax,0x10e
     ea9:	9a ff ff 00 00       	call   0x0:0xffff
     eae:	81 ec 0e 01          	sub    sp,0x10e
     eb2:	56                   	push   si
     eb3:	57                   	push   di
     eb4:	9a ff ff 00 00       	call   0x0:0xffff
     eb9:	99                   	cwd
     eba:	9a ff ff 00 00       	call   0x0:0xffff
     ebf:	89 86 f6 fe          	mov    WORD PTR [bp-0x10a],ax
     ec3:	89 9e f8 fe          	mov    WORD PTR [bp-0x108],bx
     ec7:	89 96 fa fe          	mov    WORD PTR [bp-0x106],dx
     ecb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     ece:	5f                   	pop    di
     ecf:	5e                   	pop    si
     ed0:	8d 66 fe             	lea    sp,[bp-0x2]
     ed3:	1f                   	pop    ds
     ed4:	5d                   	pop    bp
     ed5:	4d                   	dec    bp
     ed6:	cb                   	retf
     ed7:	8c d8                	mov    ax,ds
     ed9:	90                   	nop
     eda:	45                   	inc    bp
     edb:	55                   	push   bp
     edc:	89 e5                	mov    bp,sp
     ede:	1e                   	push   ds
     edf:	8e d8                	mov    ds,ax
     ee1:	b8 1c 00             	mov    ax,0x1c
     ee4:	9a ff ff 00 00       	call   0x0:0xffff
     ee9:	83 ec 1c             	sub    sp,0x1c
     eec:	56                   	push   si
     eed:	57                   	push   di
     eee:	9a ff ff 00 00       	call   0x0:0xffff
     ef3:	99                   	cwd
     ef4:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
     ef7:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
     efa:	9b db 46 ec          	fild   DWORD PTR [bp-0x14]
     efe:	9b db 7e e2          	fstp   TBYTE PTR [bp-0x1e]
     f02:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     f05:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
     f08:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
     f0b:	9a ff ff 00 00       	call   0x0:0xffff
     f10:	9b db 6e e2          	fld    TBYTE PTR [bp-0x1e]
     f14:	9b de c1             	faddp  st(1),st
     f17:	9a ff ff 00 00       	call   0x0:0xffff
     f1c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     f1f:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     f22:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     f25:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     f28:	5f                   	pop    di
     f29:	5e                   	pop    si
     f2a:	8d 66 fe             	lea    sp,[bp-0x2]
     f2d:	1f                   	pop    ds
     f2e:	5d                   	pop    bp
     f2f:	4d                   	dec    bp
     f30:	cb                   	retf
     f31:	8c d8                	mov    ax,ds
     f33:	90                   	nop
     f34:	45                   	inc    bp
     f35:	55                   	push   bp
     f36:	89 e5                	mov    bp,sp
     f38:	1e                   	push   ds
     f39:	8e d8                	mov    ds,ax
     f3b:	b8 0c 00             	mov    ax,0xc
     f3e:	9a ff ff 00 00       	call   0x0:0xffff
     f43:	83 ec 0c             	sub    sp,0xc
     f46:	56                   	push   si
     f47:	57                   	push   di
     f48:	9a ff ff 00 00       	call   0x0:0xffff
     f4d:	50                   	push   ax
     f4e:	9a ff ff 00 00       	call   0x0:0xffff
     f53:	50                   	push   ax
     f54:	9a ff ff 00 00       	call   0x0:0xffff
     f59:	5a                   	pop    dx
     f5a:	03 c2                	add    ax,dx
     f5c:	5a                   	pop    dx
     f5d:	03 c2                	add    ax,dx
     f5f:	99                   	cwd
     f60:	9a ff ff 00 00       	call   0x0:0xffff
     f65:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     f68:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
     f6b:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     f6e:	9a ff ff 00 00       	call   0x0:0xffff
     f73:	99                   	cwd
     f74:	9a ff ff 00 00       	call   0x0:0xffff
     f79:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     f7c:	89 5e f4             	mov    WORD PTR [bp-0xc],bx
     f7f:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
     f82:	5f                   	pop    di
     f83:	5e                   	pop    si
     f84:	8d 66 fe             	lea    sp,[bp-0x2]
     f87:	1f                   	pop    ds
     f88:	5d                   	pop    bp
     f89:	4d                   	dec    bp
     f8a:	cb                   	retf
     f8b:	8c d8                	mov    ax,ds
     f8d:	90                   	nop
     f8e:	45                   	inc    bp
     f8f:	55                   	push   bp
     f90:	89 e5                	mov    bp,sp
     f92:	1e                   	push   ds
     f93:	8e d8                	mov    ds,ax
     f95:	b8 22 00             	mov    ax,0x22
     f98:	9a ff ff 00 00       	call   0x0:0xffff
     f9d:	83 ec 22             	sub    sp,0x22
     fa0:	56                   	push   si
     fa1:	57                   	push   di
     fa2:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
     fa5:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
     fa8:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
     fab:	9a ff ff 00 00       	call   0x0:0xffff
     fb0:	9a ff ff 00 00       	call   0x0:0xffff
     fb5:	9b db 7e dc          	fstp   TBYTE PTR [bp-0x24]
     fb9:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     fbc:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     fbf:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     fc2:	9a ff ff 00 00       	call   0x0:0xffff
     fc7:	9b db 7e e6          	fstp   TBYTE PTR [bp-0x1a]
     fcb:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     fce:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
     fd1:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     fd4:	9a ff ff 00 00       	call   0x0:0xffff
     fd9:	9b db 6e e6          	fld    TBYTE PTR [bp-0x1a]
     fdd:	9b de c9             	fmulp  st(1),st
     fe0:	9a ff ff 00 00       	call   0x0:0xffff
     fe5:	9b db 6e dc          	fld    TBYTE PTR [bp-0x24]
     fe9:	9b de c1             	faddp  st(1),st
     fec:	9a ff ff 00 00       	call   0x0:0xffff
     ff1:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     ff4:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
     ff7:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     ffa:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     ffd:	5f                   	pop    di
     ffe:	5e                   	pop    si
     fff:	8d 66 fe             	lea    sp,[bp-0x2]
    1002:	1f                   	pop    ds
    1003:	5d                   	pop    bp
    1004:	4d                   	dec    bp
    1005:	cb                   	retf
    1006:	8c d8                	mov    ax,ds
    1008:	90                   	nop
    1009:	45                   	inc    bp
    100a:	55                   	push   bp
    100b:	89 e5                	mov    bp,sp
    100d:	1e                   	push   ds
    100e:	8e d8                	mov    ds,ax
    1010:	b8 22 00             	mov    ax,0x22
    1013:	9a ff ff 00 00       	call   0x0:0xffff
    1018:	83 ec 22             	sub    sp,0x22
    101b:	56                   	push   si
    101c:	57                   	push   di
    101d:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1020:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
    1023:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    1026:	9a ff ff 00 00       	call   0x0:0xffff
    102b:	9a ff ff 00 00       	call   0x0:0xffff
    1030:	9b db 7e dc          	fstp   TBYTE PTR [bp-0x24]
    1034:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1037:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
    103a:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    103d:	9a ff ff 00 00       	call   0x0:0xffff
    1042:	9b db 7e e6          	fstp   TBYTE PTR [bp-0x1a]
    1046:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1049:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
    104c:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    104f:	9a ff ff 00 00       	call   0x0:0xffff
    1054:	9b db 6e e6          	fld    TBYTE PTR [bp-0x1a]
    1058:	9b de c9             	fmulp  st(1),st
    105b:	9a ff ff 00 00       	call   0x0:0xffff
    1060:	9b db 6e dc          	fld    TBYTE PTR [bp-0x24]
    1064:	9b de c1             	faddp  st(1),st
    1067:	9a ff ff 00 00       	call   0x0:0xffff
    106c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    106f:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
    1072:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1075:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1078:	5f                   	pop    di
    1079:	5e                   	pop    si
    107a:	8d 66 fe             	lea    sp,[bp-0x2]
    107d:	1f                   	pop    ds
    107e:	5d                   	pop    bp
    107f:	4d                   	dec    bp
    1080:	cb                   	retf
    1081:	8c d8                	mov    ax,ds
    1083:	90                   	nop
    1084:	45                   	inc    bp
    1085:	55                   	push   bp
    1086:	89 e5                	mov    bp,sp
    1088:	1e                   	push   ds
    1089:	8e d8                	mov    ds,ax
    108b:	b8 2c 00             	mov    ax,0x2c
    108e:	9a ff ff 00 00       	call   0x0:0xffff
    1093:	83 ec 2c             	sub    sp,0x2c
    1096:	56                   	push   si
    1097:	57                   	push   di
    1098:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    109b:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
    109e:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    10a1:	9a ff ff 00 00       	call   0x0:0xffff
    10a6:	9b db 7e e6          	fstp   TBYTE PTR [bp-0x1a]
    10aa:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    10ad:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
    10b0:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    10b3:	9a ff ff 00 00       	call   0x0:0xffff
    10b8:	9b db 6e e6          	fld    TBYTE PTR [bp-0x1a]
    10bc:	9b de c9             	fmulp  st(1),st
    10bf:	9a ff ff 00 00       	call   0x0:0xffff
    10c4:	9b db 7e d2          	fstp   TBYTE PTR [bp-0x2e]
    10c8:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    10cb:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
    10ce:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    10d1:	9a ff ff 00 00       	call   0x0:0xffff
    10d6:	9b db 7e dc          	fstp   TBYTE PTR [bp-0x24]
    10da:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    10dd:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
    10e0:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    10e3:	9a ff ff 00 00       	call   0x0:0xffff
    10e8:	9b db 6e dc          	fld    TBYTE PTR [bp-0x24]
    10ec:	9b de c9             	fmulp  st(1),st
    10ef:	9a ff ff 00 00       	call   0x0:0xffff
    10f4:	9b db 6e d2          	fld    TBYTE PTR [bp-0x2e]
    10f8:	9b de c1             	faddp  st(1),st
    10fb:	9a ff ff 00 00       	call   0x0:0xffff
    1100:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1103:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
    1106:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1109:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    110c:	5f                   	pop    di
    110d:	5e                   	pop    si
    110e:	8d 66 fe             	lea    sp,[bp-0x2]
    1111:	1f                   	pop    ds
    1112:	5d                   	pop    bp
    1113:	4d                   	dec    bp
    1114:	cb                   	retf
    1115:	8c d8                	mov    ax,ds
    1117:	90                   	nop
    1118:	45                   	inc    bp
    1119:	55                   	push   bp
    111a:	89 e5                	mov    bp,sp
    111c:	1e                   	push   ds
    111d:	8e d8                	mov    ds,ax
    111f:	b8 2a 00             	mov    ax,0x2a
    1122:	9a ff ff 00 00       	call   0x0:0xffff
    1127:	83 ec 2a             	sub    sp,0x2a
    112a:	56                   	push   si
    112b:	57                   	push   di
    112c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    112f:	8b 5e fa             	mov    bx,WORD PTR [bp-0x6]
    1132:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    1135:	9a ff ff 00 00       	call   0x0:0xffff
    113a:	9b db 7e e8          	fstp   TBYTE PTR [bp-0x18]
    113e:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    1141:	8b 5e f4             	mov    bx,WORD PTR [bp-0xc]
    1144:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    1147:	9a ff ff 00 00       	call   0x0:0xffff
    114c:	9b db 6e e8          	fld    TBYTE PTR [bp-0x18]
    1150:	9b de c9             	fmulp  st(1),st
    1153:	9a ff ff 00 00       	call   0x0:0xffff
    1158:	9b db 7e d4          	fstp   TBYTE PTR [bp-0x2c]
    115c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    115f:	8b 5e fa             	mov    bx,WORD PTR [bp-0x6]
    1162:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    1165:	9a ff ff 00 00       	call   0x0:0xffff
    116a:	9b db 7e de          	fstp   TBYTE PTR [bp-0x22]
    116e:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    1171:	8b 5e f4             	mov    bx,WORD PTR [bp-0xc]
    1174:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    1177:	9a ff ff 00 00       	call   0x0:0xffff
    117c:	9b db 6e de          	fld    TBYTE PTR [bp-0x22]
    1180:	9b de c9             	fmulp  st(1),st
    1183:	9a ff ff 00 00       	call   0x0:0xffff
    1188:	9b db 6e d4          	fld    TBYTE PTR [bp-0x2c]
    118c:	9b de c1             	faddp  st(1),st
    118f:	9a ff ff 00 00       	call   0x0:0xffff
    1194:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1197:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
    119a:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    119d:	5f                   	pop    di
    119e:	5e                   	pop    si
    119f:	8d 66 fe             	lea    sp,[bp-0x2]
    11a2:	1f                   	pop    ds
    11a3:	5d                   	pop    bp
    11a4:	4d                   	dec    bp
    11a5:	ca 04 00             	retf   0x4
    11a8:	8c d8                	mov    ax,ds
    11aa:	90                   	nop
    11ab:	45                   	inc    bp
    11ac:	55                   	push   bp
    11ad:	89 e5                	mov    bp,sp
    11af:	1e                   	push   ds
    11b0:	8e d8                	mov    ds,ax
    11b2:	b8 20 00             	mov    ax,0x20
    11b5:	9a ff ff 00 00       	call   0x0:0xffff
    11ba:	83 ec 20             	sub    sp,0x20
    11bd:	56                   	push   si
    11be:	57                   	push   di
    11bf:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    11c2:	8b 5e fa             	mov    bx,WORD PTR [bp-0x6]
    11c5:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    11c8:	9a ff ff 00 00       	call   0x0:0xffff
    11cd:	9b db 7e e8          	fstp   TBYTE PTR [bp-0x18]
    11d1:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    11d4:	8b 5e f4             	mov    bx,WORD PTR [bp-0xc]
    11d7:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    11da:	9a ff ff 00 00       	call   0x0:0xffff
    11df:	9b db 6e e8          	fld    TBYTE PTR [bp-0x18]
    11e3:	9b de c9             	fmulp  st(1),st
    11e6:	9a ff ff 00 00       	call   0x0:0xffff
    11eb:	9b db 7e de          	fstp   TBYTE PTR [bp-0x22]
    11ef:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    11f2:	8b 5e f4             	mov    bx,WORD PTR [bp-0xc]
    11f5:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    11f8:	9a ff ff 00 00       	call   0x0:0xffff
    11fd:	9a ff ff 00 00       	call   0x0:0xffff
    1202:	9b db 6e de          	fld    TBYTE PTR [bp-0x22]
    1206:	9b de c1             	faddp  st(1),st
    1209:	9a ff ff 00 00       	call   0x0:0xffff
    120e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1211:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
    1214:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1217:	5f                   	pop    di
    1218:	5e                   	pop    si
    1219:	8d 66 fe             	lea    sp,[bp-0x2]
    121c:	1f                   	pop    ds
    121d:	5d                   	pop    bp
    121e:	4d                   	dec    bp
    121f:	ca 04 00             	retf   0x4
    1222:	8c d8                	mov    ax,ds
    1224:	90                   	nop
    1225:	45                   	inc    bp
    1226:	55                   	push   bp
    1227:	89 e5                	mov    bp,sp
    1229:	1e                   	push   ds
    122a:	8e d8                	mov    ds,ax
    122c:	b8 20 00             	mov    ax,0x20
    122f:	9a ff ff 00 00       	call   0x0:0xffff
    1234:	83 ec 20             	sub    sp,0x20
    1237:	56                   	push   si
    1238:	57                   	push   di
    1239:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    123c:	8b 5e fa             	mov    bx,WORD PTR [bp-0x6]
    123f:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    1242:	9a ff ff 00 00       	call   0x0:0xffff
    1247:	9b db 7e e8          	fstp   TBYTE PTR [bp-0x18]
    124b:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    124e:	8b 5e f4             	mov    bx,WORD PTR [bp-0xc]
    1251:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    1254:	9a ff ff 00 00       	call   0x0:0xffff
    1259:	9b db 6e e8          	fld    TBYTE PTR [bp-0x18]
    125d:	9b de c9             	fmulp  st(1),st
    1260:	9a ff ff 00 00       	call   0x0:0xffff
    1265:	9b db 7e de          	fstp   TBYTE PTR [bp-0x22]
    1269:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    126c:	8b 5e f4             	mov    bx,WORD PTR [bp-0xc]
    126f:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    1272:	9a ff ff 00 00       	call   0x0:0xffff
    1277:	9a ff ff 00 00       	call   0x0:0xffff
    127c:	9b db 6e de          	fld    TBYTE PTR [bp-0x22]
    1280:	9b de c1             	faddp  st(1),st
    1283:	9a ff ff 00 00       	call   0x0:0xffff
    1288:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    128b:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
    128e:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1291:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1294:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1298:	5f                   	pop    di
    1299:	5e                   	pop    si
    129a:	8d 66 fe             	lea    sp,[bp-0x2]
    129d:	1f                   	pop    ds
    129e:	5d                   	pop    bp
    129f:	4d                   	dec    bp
    12a0:	ca 04 00             	retf   0x4
    12a3:	8c d8                	mov    ax,ds
    12a5:	90                   	nop
    12a6:	45                   	inc    bp
    12a7:	55                   	push   bp
    12a8:	89 e5                	mov    bp,sp
    12aa:	1e                   	push   ds
    12ab:	8e d8                	mov    ds,ax
    12ad:	b8 20 00             	mov    ax,0x20
    12b0:	9a ff ff 00 00       	call   0x0:0xffff
    12b5:	83 ec 20             	sub    sp,0x20
    12b8:	56                   	push   si
    12b9:	57                   	push   di
    12ba:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    12bd:	8b 5e f4             	mov    bx,WORD PTR [bp-0xc]
    12c0:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    12c3:	9a ff ff 00 00       	call   0x0:0xffff
    12c8:	9a ff ff 00 00       	call   0x0:0xffff
    12cd:	9b db 7e de          	fstp   TBYTE PTR [bp-0x22]
    12d1:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    12d4:	8b 5e fa             	mov    bx,WORD PTR [bp-0x6]
    12d7:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    12da:	9a ff ff 00 00       	call   0x0:0xffff
    12df:	9b db 7e e8          	fstp   TBYTE PTR [bp-0x18]
    12e3:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    12e6:	8b 5e f4             	mov    bx,WORD PTR [bp-0xc]
    12e9:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
    12ec:	9a ff ff 00 00       	call   0x0:0xffff
    12f1:	9b db 6e e8          	fld    TBYTE PTR [bp-0x18]
    12f5:	9b de c9             	fmulp  st(1),st
    12f8:	9a ff ff 00 00       	call   0x0:0xffff
    12fd:	9b db 6e de          	fld    TBYTE PTR [bp-0x22]
    1301:	9b de c1             	faddp  st(1),st
    1304:	9a ff ff 00 00       	call   0x0:0xffff
    1309:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    130c:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
    130f:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1312:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1315:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1319:	5f                   	pop    di
    131a:	5e                   	pop    si
    131b:	8d 66 fe             	lea    sp,[bp-0x2]
    131e:	1f                   	pop    ds
    131f:	5d                   	pop    bp
    1320:	4d                   	dec    bp
    1321:	ca 04 00             	retf   0x4
    1324:	8c d8                	mov    ax,ds
    1326:	90                   	nop
    1327:	45                   	inc    bp
    1328:	55                   	push   bp
    1329:	89 e5                	mov    bp,sp
    132b:	1e                   	push   ds
    132c:	8e d8                	mov    ds,ax
    132e:	b8 0c 00             	mov    ax,0xc
    1331:	9a ff ff 00 00       	call   0x0:0xffff
    1336:	83 ec 0c             	sub    sp,0xc
    1339:	56                   	push   si
    133a:	57                   	push   di
    133b:	9a ff ff 00 00       	call   0x0:0xffff
    1340:	99                   	cwd
    1341:	9a ff ff 00 00       	call   0x0:0xffff
    1346:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1349:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
    134c:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    134f:	bf 4d 00             	mov    di,0x4d
    1352:	1e                   	push   ds
    1353:	57                   	push   di
    1354:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1357:	06                   	push   es
    1358:	57                   	push   di
    1359:	68 87 09             	push   0x987
    135c:	9a ff ff 00 00       	call   0x0:0xffff
    1361:	5f                   	pop    di
    1362:	5e                   	pop    si
    1363:	8d 66 fe             	lea    sp,[bp-0x2]
    1366:	1f                   	pop    ds
    1367:	5d                   	pop    bp
    1368:	4d                   	dec    bp
    1369:	ca 04 00             	retf   0x4
    136c:	8c d8                	mov    ax,ds
    136e:	90                   	nop
    136f:	45                   	inc    bp
    1370:	55                   	push   bp
    1371:	89 e5                	mov    bp,sp
    1373:	1e                   	push   ds
    1374:	8e d8                	mov    ds,ax
    1376:	b8 0c 00             	mov    ax,0xc
    1379:	9a ff ff 00 00       	call   0x0:0xffff
    137e:	83 ec 0c             	sub    sp,0xc
    1381:	56                   	push   si
    1382:	57                   	push   di
    1383:	9a ff ff 00 00       	call   0x0:0xffff
    1388:	99                   	cwd
    1389:	9a ff ff 00 00       	call   0x0:0xffff
    138e:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1391:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
    1394:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1397:	bf 4d 00             	mov    di,0x4d
    139a:	1e                   	push   ds
    139b:	57                   	push   di
    139c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    139f:	06                   	push   es
    13a0:	57                   	push   di
    13a1:	68 87 09             	push   0x987
    13a4:	9a ff ff 00 00       	call   0x0:0xffff
    13a9:	5f                   	pop    di
    13aa:	5e                   	pop    si
    13ab:	8d 66 fe             	lea    sp,[bp-0x2]
    13ae:	1f                   	pop    ds
    13af:	5d                   	pop    bp
    13b0:	4d                   	dec    bp
    13b1:	ca 04 00             	retf   0x4
    13b4:	0a 20                	or     ah,BYTE PTR [bx+si]
    13b6:	20 20                	and    BYTE PTR [bx+si],ah
    13b8:	20 20                	and    BYTE PTR [bx+si],ah
    13ba:	20 20                	and    BYTE PTR [bx+si],ah
    13bc:	20 20                	and    BYTE PTR [bx+si],ah
    13be:	20 8c d8 90          	and    BYTE PTR [si-0x6f28],cl
    13c2:	45                   	inc    bp
    13c3:	55                   	push   bp
    13c4:	89 e5                	mov    bp,sp
    13c6:	1e                   	push   ds
    13c7:	8e d8                	mov    ds,ax
    13c9:	b8 04 00             	mov    ax,0x4
    13cc:	9a ff ff 00 00       	call   0x0:0xffff
    13d1:	83 ec 04             	sub    sp,0x4
    13d4:	56                   	push   si
    13d5:	57                   	push   di
    13d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13d9:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    13dc:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    13df:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    13e3:	bf b4 13             	mov    di,0x13b4
    13e6:	0e                   	push   cs
    13e7:	57                   	push   di
    13e8:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    13eb:	81 c7 00 01          	add    di,0x100
    13ef:	06                   	push   es
    13f0:	57                   	push   di
    13f1:	6a 0a                	push   0xa
    13f3:	9a ff ff 00 00       	call   0x0:0xffff
    13f8:	5f                   	pop    di
    13f9:	5e                   	pop    si
    13fa:	8d 66 fe             	lea    sp,[bp-0x2]
    13fd:	1f                   	pop    ds
    13fe:	5d                   	pop    bp
    13ff:	4d                   	dec    bp
    1400:	ca 04 00             	retf   0x4
    1403:	8c d8                	mov    ax,ds
    1405:	90                   	nop
    1406:	45                   	inc    bp
    1407:	55                   	push   bp
    1408:	89 e5                	mov    bp,sp
    140a:	1e                   	push   ds
    140b:	8e d8                	mov    ds,ax
    140d:	b8 0e 00             	mov    ax,0xe
    1410:	9a ff ff 00 00       	call   0x0:0xffff
    1415:	83 ec 0e             	sub    sp,0xe
    1418:	56                   	push   si
    1419:	57                   	push   di
    141a:	c7 46 fc 0d 00       	mov    WORD PTR [bp-0x4],0xd
    141f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1422:	5f                   	pop    di
    1423:	5e                   	pop    si
    1424:	8d 66 fe             	lea    sp,[bp-0x2]
    1427:	1f                   	pop    ds
    1428:	5d                   	pop    bp
    1429:	4d                   	dec    bp
    142a:	cb                   	retf
    142b:	8c d8                	mov    ax,ds
    142d:	90                   	nop
    142e:	45                   	inc    bp
    142f:	55                   	push   bp
    1430:	89 e5                	mov    bp,sp
    1432:	1e                   	push   ds
    1433:	8e d8                	mov    ds,ax
    1435:	b8 0e 00             	mov    ax,0xe
    1438:	9a ff ff 00 00       	call   0x0:0xffff
    143d:	83 ec 0e             	sub    sp,0xe
    1440:	56                   	push   si
    1441:	57                   	push   di
    1442:	c7 46 fc 75 00       	mov    WORD PTR [bp-0x4],0x75
    1447:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    144a:	5f                   	pop    di
    144b:	5e                   	pop    si
    144c:	8d 66 fe             	lea    sp,[bp-0x2]
    144f:	1f                   	pop    ds
    1450:	5d                   	pop    bp
    1451:	4d                   	dec    bp
    1452:	cb                   	retf
    1453:	8c d8                	mov    ax,ds
    1455:	90                   	nop
    1456:	45                   	inc    bp
    1457:	55                   	push   bp
    1458:	89 e5                	mov    bp,sp
    145a:	1e                   	push   ds
    145b:	8e d8                	mov    ds,ax
    145d:	b8 18 00             	mov    ax,0x18
    1460:	9a ff ff 00 00       	call   0x0:0xffff
    1465:	83 ec 18             	sub    sp,0x18
    1468:	56                   	push   si
    1469:	57                   	push   di
    146a:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    146d:	8b 5e f8             	mov    bx,WORD PTR [bp-0x8]
    1470:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    1473:	9a ff ff 00 00       	call   0x0:0xffff
    1478:	9b db 7e e6          	fstp   TBYTE PTR [bp-0x1a]
    147c:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    147f:	8b 5e f2             	mov    bx,WORD PTR [bp-0xe]
    1482:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    1485:	9a ff ff 00 00       	call   0x0:0xffff
    148a:	9b db 6e e6          	fld    TBYTE PTR [bp-0x1a]
    148e:	9b de c1             	faddp  st(1),st
    1491:	9a ff ff 00 00       	call   0x0:0xffff
    1496:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1499:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
    149c:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    149f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    14a2:	5f                   	pop    di
    14a3:	5e                   	pop    si
    14a4:	8d 66 fe             	lea    sp,[bp-0x2]
    14a7:	1f                   	pop    ds
    14a8:	5d                   	pop    bp
    14a9:	4d                   	dec    bp
    14aa:	cb                   	retf
