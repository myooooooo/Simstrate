; ================================================================
; seg26_CODE  (14210 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	1a 00                	sbb    al,BYTE PTR [bx+si]
       2:	60                   	pusha
       3:	00 00                	add    BYTE PTR [bx+si],al
       5:	00 00                	add    BYTE PTR [bx+si],al
       7:	00 00                	add    BYTE PTR [bx+si],al
       9:	00 52 00             	add    BYTE PTR [bp+si+0x0],dl
       c:	22 00                	and    al,BYTE PTR [bx+si]
       e:	1d 0d 75             	sbb    ax,0x750d
      11:	00 64 20             	add    BYTE PTR [si+0x20],ah
      14:	c3                   	ret
      15:	01 9a 1f 14          	add    WORD PTR [bp+si+0x141f],bx
      19:	00 cb                	add    bl,cl
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	37                   	aaa
      1f:	09 71 00             	or     WORD PTR [bx+di+0x0],si
      22:	cd 11                	int    0x11
      24:	28 00                	sub    BYTE PTR [bx+si],al
      26:	e4 11                	in     al,0x11
      28:	2c 00                	sub    al,0x0
      2a:	fa                   	cli
      2b:	10 eb                	adc    bl,ch
      2d:	01 06 0b 38          	add    WORD PTR ds:0x380b,ax
      31:	00 0c                	add    BYTE PTR [si],cl
      33:	7b 40                	jnp    0x75
      35:	00 69 0b             	add    BYTE PTR [bx+di+0xb],ch
      38:	3c 00                	cmp    al,0x0
      3a:	86 0b                	xchg   BYTE PTR [bp+di],cl
      3c:	44                   	inc    sp
      3d:	00 44 7b             	add    BYTE PTR [si+0x7b],al
      40:	10 00                	adc    BYTE PTR [bx+si],al
      42:	b9 0b 48             	mov    cx,0x480b
      45:	00 a1 0b 4c          	add    BYTE PTR [bx+di+0x4c0b],ah
      49:	00 ce                	add    dh,cl
      4b:	0b 50 00             	or     dx,WORD PTR [bx+si+0x0]
      4e:	09 0c                	or     WORD PTR [si],cx
      50:	20 00                	and    BYTE PTR [bx+si],al
      52:	0d 54 47             	or     ax,0x4754
      55:	72 69                	jb     0xc0
      57:	64 44                	fs inc sp
      59:	61                   	popa
      5a:	74 61                	je     0xbd
      5c:	4c                   	dec    sp
      5d:	69 6e 6b 07 0d       	imul   bp,WORD PTR [bp+0x6b],0xd07
      62:	54                   	push   sp
      63:	47                   	inc    di
      64:	72 69                	jb     0xcf
      66:	64 44                	fs inc sp
      68:	61                   	popa
      69:	74 61                	je     0xcc
      6b:	4c                   	dec    sp
      6c:	69 6e 6b 22 00       	imul   bp,WORD PTR [bp+0x6b],0x22
      71:	9d                   	popf
      72:	00 57 0d             	add    BYTE PTR [bx+0xd],dl
      75:	95                   	xchg   bp,ax
      76:	04 00                	add    al,0x0
      78:	00 07                	add    BYTE PTR [bx],al
      7a:	44                   	inc    sp
      7b:	42                   	inc    dx
      7c:	47                   	inc    di
      7d:	72 69                	jb     0xe8
      7f:	64 73 00             	fs jae 0x82
      82:	00 03                	add    BYTE PTR [bp+di],al
      84:	0d 54 44             	or     ax,0x4454
      87:	42                   	inc    dx
      88:	47                   	inc    di
      89:	72 69                	jb     0xf4
      8b:	64 4f                	fs dec di
      8d:	70 74                	jo     0x103
      8f:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
      94:	00 00                	add    BYTE PTR [bx+si],al
      96:	00 0b                	add    BYTE PTR [bp+di],cl
      98:	00 00                	add    BYTE PTR [bx+si],al
      9a:	00 83 00 51          	add    BYTE PTR [bp+di+0x5100],al
      9e:	01 09                	add    WORD PTR [bx+di],cx
      a0:	64 67 45             	fs addr32 inc bp
      a3:	64 69 74 69 6e 67    	imul   si,WORD PTR fs:[si+0x69],0x676e
      a9:	12 64 67             	adc    ah,BYTE PTR [si+0x67]
      ac:	41                   	inc    cx
      ad:	6c                   	ins    BYTE PTR es:[di],dx
      ae:	77 61                	ja     0x111
      b0:	79 73                	jns    0x125
      b2:	53                   	push   bx
      b3:	68 6f 77             	push   0x776f
      b6:	45                   	inc    bp
      b7:	64 69 74 6f 72 08    	imul   si,WORD PTR fs:[si+0x6f],0x872
      bd:	64 67 54             	fs addr32 push sp
      c0:	69 74 6c 65 73       	imul   si,WORD PTR [si+0x6c],0x7365
      c5:	0b 64 67             	or     sp,WORD PTR [si+0x67]
      c8:	49                   	dec    cx
      c9:	6e                   	outs   dx,BYTE PTR ds:[si]
      ca:	64 69 63 61 74 6f    	imul   sp,WORD PTR fs:[bp+di+0x61],0x6f74
      d0:	72 0e                	jb     0xe0
      d2:	64 67 43             	fs addr32 inc bx
      d5:	6f                   	outs   dx,WORD PTR ds:[si]
      d6:	6c                   	ins    BYTE PTR es:[di],dx
      d7:	75 6d                	jne    0x146
      d9:	6e                   	outs   dx,BYTE PTR ds:[si]
      da:	52                   	push   dx
      db:	65 73 69             	gs jae 0x147
      de:	7a 65                	jp     0x145
      e0:	0a 64 67             	or     ah,BYTE PTR [si+0x67]
      e3:	43                   	inc    bx
      e4:	6f                   	outs   dx,WORD PTR ds:[si]
      e5:	6c                   	ins    BYTE PTR es:[di],dx
      e6:	4c                   	dec    sp
      e7:	69 6e 65 73 0a       	imul   bp,WORD PTR [bp+0x65],0xa73
      ec:	64 67 52             	fs addr32 push dx
      ef:	6f                   	outs   dx,WORD PTR ds:[si]
      f0:	77 4c                	ja     0x13e
      f2:	69 6e 65 73 06       	imul   bp,WORD PTR [bp+0x65],0x673
      f7:	64 67 54             	fs addr32 push sp
      fa:	61                   	popa
      fb:	62 73 0b             	bound  si,DWORD PTR [bp+di+0xb]
      fe:	64 67 52             	fs addr32 push dx
     101:	6f                   	outs   dx,WORD PTR ds:[si]
     102:	77 53                	ja     0x157
     104:	65 6c                	gs ins BYTE PTR es:[di],dx
     106:	65 63 74 15          	arpl   WORD PTR gs:[si+0x15],si
     10a:	64 67 41             	fs addr32 inc cx
     10d:	6c                   	ins    BYTE PTR es:[di],dx
     10e:	77 61                	ja     0x171
     110:	79 73                	jns    0x185
     112:	53                   	push   bx
     113:	68 6f 77             	push   0x776f
     116:	53                   	push   bx
     117:	65 6c                	gs ins BYTE PTR es:[di],dx
     119:	65 63 74 69          	arpl   WORD PTR gs:[si+0x69],si
     11d:	6f                   	outs   dx,WORD PTR ds:[si]
     11e:	6e                   	outs   dx,BYTE PTR ds:[si]
     11f:	0f 64 67 43          	pcmpgtb mm4,QWORD PTR [bx+0x43]
     123:	6f                   	outs   dx,WORD PTR ds:[si]
     124:	6e                   	outs   dx,BYTE PTR ds:[si]
     125:	66 69 72 6d 44 65 6c 	imul   esi,DWORD PTR [bp+si+0x6d],0x656c6544
     12c:	65 
     12d:	74 65                	je     0x194
     12f:	0e                   	push   cs
     130:	64 67 43             	fs addr32 inc bx
     133:	61                   	popa
     134:	6e                   	outs   dx,BYTE PTR ds:[si]
     135:	63 65 6c             	arpl   WORD PTR [di+0x6c],sp
     138:	4f                   	dec    di
     139:	6e                   	outs   dx,BYTE PTR ds:[si]
     13a:	45                   	inc    bp
     13b:	78 69                	js     0x1a6
     13d:	74 06                	je     0x145
     13f:	0e                   	push   cs
     140:	54                   	push   sp
     141:	44                   	inc    sp
     142:	42                   	inc    dx
     143:	47                   	inc    di
     144:	72 69                	jb     0x1af
     146:	64 4f                	fs dec di
     148:	70 74                	jo     0x1be
     14a:	69 6f 6e 73 03       	imul   bp,WORD PTR [bx+0x6e],0x373
     14f:	83 00 5b             	add    WORD PTR [bx+si],0x5b
     152:	02 08                	add    cl,BYTE PTR [bx+si]
     154:	12 54 44             	adc    dl,BYTE PTR [si+0x44]
     157:	72 61                	jb     0x1ba
     159:	77 44                	ja     0x19f
     15b:	61                   	popa
     15c:	74 61                	je     0x1bf
     15e:	43                   	inc    bx
     15f:	65 6c                	gs ins BYTE PTR es:[di],dx
     161:	6c                   	ins    BYTE PTR es:[di],dx
     162:	45                   	inc    bp
     163:	76 65                	jbe    0x1ca
     165:	6e                   	outs   dx,BYTE PTR ds:[si]
     166:	74 00                	je     0x168
     168:	04 00                	add    al,0x0
     16a:	06                   	push   es
     16b:	53                   	push   bx
     16c:	65 6e                	outs   dx,BYTE PTR gs:[si]
     16e:	64 65 72 07          	fs gs jb 0x179
     172:	54                   	push   sp
     173:	4f                   	dec    di
     174:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
     177:	63 74 02             	arpl   WORD PTR [si+0x2],si
     17a:	04 52                	add    al,0x52
     17c:	65 63 74 05          	arpl   WORD PTR gs:[si+0x5],si
     180:	54                   	push   sp
     181:	52                   	push   dx
     182:	65 63 74 00          	arpl   WORD PTR gs:[si+0x0],si
     186:	05 46 69             	add    ax,0x6946
     189:	65 6c                	gs ins BYTE PTR es:[di],dx
     18b:	64 06                	fs push es
     18d:	54                   	push   sp
     18e:	46                   	inc    si
     18f:	69 65 6c 64 00       	imul   sp,WORD PTR [di+0x6c],0x64
     194:	05 53 74             	add    ax,0x7453
     197:	61                   	popa
     198:	74 65                	je     0x1ff
     19a:	0e                   	push   cs
     19b:	54                   	push   sp
     19c:	47                   	inc    di
     19d:	72 69                	jb     0x208
     19f:	64 44                	fs inc sp
     1a1:	72 61                	jb     0x204
     1a3:	77 53                	ja     0x1f8
     1a5:	74 61                	je     0x208
     1a7:	74 65                	je     0x20e
     1a9:	05 03 00             	add    ax,0x3
     1ac:	00 00                	add    BYTE PTR [bx+si],al
     1ae:	00 7f 02             	add    BYTE PTR [bx+0x2],bh
     1b1:	71 02                	jno    0x1b5
     1b3:	7b 02                	jnp    0x1b7
     1b5:	f3 02 1a             	repz add bl,BYTE PTR [bp+si]
     1b8:	03 fa                	add    di,dx
     1ba:	45                   	inc    bp
     1bb:	2f                   	das
     1bc:	02 9a 1f 42          	add    bl,BYTE PTR [bp+si+0x421f]
     1c0:	03 cb                	add    cx,bx
     1c2:	1f                   	pop    ds
     1c3:	bf 01 8f             	mov    di,0x8f01
     1c6:	11 af 02 cd          	adc    WORD PTR [bx-0x32fe],bp
     1ca:	11 d3                	adc    bx,dx
     1cc:	01 8d 27 57          	add    WORD PTR [di+0x5727],cx
     1d0:	02 fa                	add    bh,dl
     1d2:	10 6a 03             	adc    BYTE PTR [bp+si+0x3],ch
     1d5:	d6                   	(bad)
     1d6:	14 07                	adc    al,0x7
     1d8:	02 83 36 df          	add    al,BYTE PTR [bp+di-0x20ca]
     1dc:	01 3e 34 2b          	add    WORD PTR ds:0x2b34,di
     1e0:	02 ec                	add    ch,ah
     1e2:	30 3f                	xor    BYTE PTR [bx],bh
     1e4:	02 51 1b             	add    dl,BYTE PTR [bx+di+0x1b]
     1e7:	ba 03 38             	mov    dx,0x3803
     1ea:	50                   	push   ax
     1eb:	f3 01 63 31          	repz add WORD PTR [bp+di+0x31],sp
     1ef:	0f 02 21             	lar    sp,WORD PTR [bx+di]
     1f2:	50                   	push   ax
     1f3:	cb                   	retf
     1f4:	01 4a 0f             	add    WORD PTR [bp+si+0xf],cx
     1f7:	c7 01 d9 62          	mov    WORD PTR [bx+di],0x62d9
     1fb:	ff 01                	inc    WORD PTR [bx+di]
     1fd:	06                   	push   es
     1fe:	63 03                	arpl   WORD PTR [bp+di],ax
     200:	02 8f 60 e3          	add    cl,BYTE PTR [bx-0x1ca0]
     204:	01 3a                	add    WORD PTR [bp+si],di
     206:	1c e7                	sbb    al,0xe7
     208:	01 46 44             	add    WORD PTR [bp+0x44],ax
     20b:	ef                   	out    dx,ax
     20c:	01 08                	add    WORD PTR [bx+si],cx
     20e:	61                   	popa
     20f:	13 02                	adc    ax,WORD PTR [bp+si]
     211:	5c                   	pop    sp
     212:	61                   	popa
     213:	17                   	pop    ss
     214:	02 62 5c             	add    ah,BYTE PTR [bp+si+0x5c]
     217:	43                   	inc    bx
     218:	02 3a                	add    bh,BYTE PTR [bp+si]
     21a:	61                   	popa
     21b:	d7                   	xlat   BYTE PTR ds:[bx]
     21c:	01 72 3f             	add    WORD PTR [bp+si+0x3f],si
     21f:	27                   	daa
     220:	02 dc                	add    bl,ah
     222:	5c                   	pop    sp
     223:	4f                   	dec    di
     224:	02 17                	add    dl,BYTE PTR [bx]
     226:	3e bb 01 30          	ds mov bx,0x3001
     22a:	16                   	push   ss
     22b:	f7 01 ed 3e          	test   WORD PTR [bx+di],0x3eed
     22f:	33 02                	xor    ax,WORD PTR [bp+si]
     231:	77 3e                	ja     0x271
     233:	37                   	aaa
     234:	02 c2                	add    al,dl
     236:	35 fb 01             	xor    ax,0x1fb
     239:	26 6d                	es ins WORD PTR es:[di],dx
     23b:	1f                   	pop    ds
     23c:	02 ae 5f 0b          	add    ch,BYTE PTR [bp+0xb5f]
     240:	02 35                	add    dh,BYTE PTR [di]
     242:	62 1b                	bound  bx,DWORD PTR [bp+di]
     244:	02 ec                	add    ch,ah
     246:	2e b7 01             	cs mov bh,0x1
     249:	b2 5c                	mov    dl,0x5c
     24b:	23 02                	and    ax,WORD PTR [bp+si]
     24d:	93                   	xchg   bx,ax
     24e:	24 cf                	and    al,0xcf
     250:	01 5b 27             	add    WORD PTR [bp+di+0x27],bx
     253:	67 02 81 28 47 02 e7 	add    al,BYTE PTR [ecx-0x18fdb8d8]
     25a:	13 5f 02             	adc    bx,WORD PTR [bx+0x2]
     25d:	e9 1b 63             	jmp    0x657b
     260:	02 7f 26             	add    bh,BYTE PTR [bx+0x26]
     263:	53                   	push   bx
     264:	02 db                	add    bl,bl
     266:	11 6b 02             	adc    WORD PTR [bp+di+0x2],bp
     269:	97                   	xchg   di,ax
     26a:	12 6f 02             	adc    ch,BYTE PTR [bx+0x2]
     26d:	e9 15 db             	jmp    0xdd85
     270:	01 0d                	add    WORD PTR [di],cx
     272:	54                   	push   sp
     273:	43                   	inc    bx
     274:	75 73                	jne    0x2e9
     276:	74 6f                	je     0x2e7
     278:	6d                   	ins    WORD PTR es:[di],dx
     279:	44                   	inc    sp
     27a:	42                   	inc    dx
     27b:	47                   	inc    di
     27c:	72 69                	jb     0x2e7
     27e:	64 16                	fs push ss
     280:	00 1b                	add    BYTE PTR [bp+di],bl
     282:	0f 0e                	femms
     284:	0f 08                	invd
     286:	0f 1c 0f             	nop    WORD PTR [bx]
     289:	20 00                	and    BYTE PTR [bx+si],al
     28b:	05 00 15             	add    ax,0x1500
     28e:	01 ed                	add    bp,bp
     290:	ff                   	jmp    (bad)
     291:	eb ff                	jmp    0x292
     293:	e7 ff                	out    0xff,ax
     295:	e6 ff                	out    0xff,al
     297:	df ff                	(bad)
     299:	de ff                	fdivp  st(7),st
     29b:	e1 ff                	loope  0x29c
     29d:	e8 ff ea             	call   0xed9f
     2a0:	ff                   	jmp    (bad)
     2a1:	e9 ff dd             	jmp    0xe0a3
     2a4:	ff f1                	push   cx
     2a6:	ff                   	jmp    (bad)
     2a7:	ef                   	out    dx,ax
     2a8:	ff                   	(bad)
     2a9:	fa                   	cli
     2aa:	ff e2                	jmp    dx
     2ac:	ff                   	call   (bad)
     2ad:	da 22                	fisub  DWORD PTR [bp+si]
     2af:	b3 02                	mov    bl,0x2
     2b1:	8f                   	(bad)
     2b2:	23 b7 02 69          	and    si,WORD PTR [bx+0x6902]
     2b6:	22 bb 02 b3          	and    bh,BYTE PTR [bp+di-0x4cfe]
     2ba:	23 bf 02 80          	and    di,WORD PTR [bx-0x7ffe]
     2be:	24 c3                	and    al,0xc3
     2c0:	02 e0                	add    ah,al
     2c2:	24 c7                	and    al,0xc7
     2c4:	02 23                	add    ah,BYTE PTR [bp+di]
     2c6:	25 cb 02             	and    ax,0x2cb
     2c9:	7c 16                	jl     0x2e1
     2cb:	cf                   	iret
     2cc:	02 27                	add    ah,BYTE PTR [bx]
     2ce:	17                   	pop    ss
     2cf:	d3 02                	rol    WORD PTR [bp+si],cl
     2d1:	d7                   	xlat   BYTE PTR ds:[bx]
     2d2:	16                   	push   ss
     2d3:	d7                   	xlat   BYTE PTR ds:[bx]
     2d4:	02 bf 33 db          	add    bh,BYTE PTR [bx-0x24cd]
     2d8:	02 6f 33             	add    ch,BYTE PTR [bx+0x33]
     2db:	df 02                	fild   WORD PTR [bp+si]
     2dd:	97                   	xchg   di,ax
     2de:	33 e3                	xor    sp,bx
     2e0:	02 33                	add    dh,BYTE PTR [bp+di]
     2e2:	35 e7 02             	xor    ax,0x2e7
     2e5:	c4 17                	les    dx,DWORD PTR [bx]
     2e7:	eb 02                	jmp    0x2eb
     2e9:	55                   	push   bp
     2ea:	18 ef                	sbb    bh,ch
     2ec:	02 fc                	add    bh,ah
     2ee:	18 f3                	sbb    bl,dh
     2f0:	02 5b 12             	add    bl,BYTE PTR [bp+di+0x12]
     2f3:	f7 02 97 2e          	test   WORD PTR [bp+si],0x2e97
     2f7:	fb                   	sti
     2f8:	02 95 31 ff          	add    dl,BYTE PTR [di-0xcf]
     2fc:	02 d0                	add    dl,al
     2fe:	31 03                	xor    WORD PTR [bp+di],ax
     300:	03 8d 34 16          	add    cx,WORD PTR [di+0x1634]
     304:	03 07                	add    ax,WORD PTR [bx]
     306:	0d 54 43             	or     ax,0x4354
     309:	75 73                	jne    0x37e
     30b:	74 6f                	je     0x37c
     30d:	6d                   	ins    WORD PTR es:[di],dx
     30e:	44                   	inc    sp
     30f:	42                   	inc    dx
     310:	47                   	inc    di
     311:	72 69                	jb     0x37c
     313:	64 c9                	fs leave
     315:	01 da                	add    dx,bx
     317:	03 6f 04             	add    bp,WORD PTR [bx+0x4]
     31a:	ca 03 0a             	retf   0xa03
     31d:	00 07                	add    BYTE PTR [bx],al
     31f:	44                   	inc    sp
     320:	42                   	inc    dx
     321:	47                   	inc    di
     322:	72 69                	jb     0x38d
     324:	64 73 00             	fs jae 0x327
     327:	00 f8                	add    al,bh
     329:	03 00                	add    ax,WORD PTR [bx+si]
     32b:	00 00                	add    BYTE PTR [bx+si],al
     32d:	00 00                	add    BYTE PTR [bx+si],al
     32f:	00 f0                	add    al,dh
     331:	03 7b 02             	add    di,WORD PTR [bp+di+0x2]
     334:	c9                   	leave
     335:	01 03                	add    WORD PTR [bp+di],ax
     337:	04 fa                	add    al,0xfa
     339:	45                   	inc    bp
     33a:	ae                   	scas   al,BYTE PTR es:[di]
     33b:	03 9a 1f 77          	add    bx,WORD PTR [bp+si+0x771f]
     33f:	04 cb                	add    al,0xcb
     341:	1f                   	pop    ds
     342:	3e 03 8f 11 36       	add    cx,WORD PTR ds:[bx+0x3611]
     347:	03 cd                	add    cx,bp
     349:	11 52 03             	adc    WORD PTR [bp+si+0x3],dx
     34c:	8d 27                	lea    sp,[bx]
     34e:	d6                   	(bad)
     34f:	03 fa                	add    di,dx
     351:	10 1c                	adc    BYTE PTR [si],bl
     353:	07                   	pop    es
     354:	d6                   	(bad)
     355:	14 86                	adc    al,0x86
     357:	03 83 36 5e          	add    ax,WORD PTR [bp+di+0x5e36]
     35b:	03 3e 34 aa          	add    di,WORD PTR ds:0xaa34
     35f:	03 ec                	add    bp,sp
     361:	30 be 03 51          	xor    BYTE PTR [bp+0x5103],bh
     365:	1b 17                	sbb    dx,WORD PTR [bx]
     367:	04 38                	add    al,0x38
     369:	50                   	push   ax
     36a:	72 03                	jb     0x36f
     36c:	63 31                	arpl   WORD PTR [bx+di],si
     36e:	8e 03                	mov    es,WORD PTR [bp+di]
     370:	21 50 4a             	and    WORD PTR [bx+si+0x4a],dx
     373:	03 4a 0f             	add    cx,WORD PTR [bp+si+0xf]
     376:	46                   	inc    si
     377:	03 d9                	add    bx,cx
     379:	62 7e 03             	bound  di,DWORD PTR [bp+0x3]
     37c:	06                   	push   es
     37d:	63 82 03 8f          	arpl   WORD PTR [bp+si-0x70fd],ax
     381:	60                   	pusha
     382:	62 03                	bound  ax,DWORD PTR [bp+di]
     384:	3a 1c                	cmp    bl,BYTE PTR [si]
     386:	66 03 46 44          	add    eax,DWORD PTR [bp+0x44]
     38a:	6e                   	outs   dx,BYTE PTR ds:[si]
     38b:	03 08                	add    cx,WORD PTR [bx+si]
     38d:	61                   	popa
     38e:	92                   	xchg   dx,ax
     38f:	03 5c 61             	add    bx,WORD PTR [si+0x61]
     392:	96                   	xchg   si,ax
     393:	03 62 5c             	add    sp,WORD PTR [bp+si+0x5c]
     396:	c2 03 3a             	ret    0x3a03
     399:	61                   	popa
     39a:	56                   	push   si
     39b:	03 72 3f             	add    si,WORD PTR [bp+si+0x3f]
     39e:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     39f:	03 dc                	add    bx,sp
     3a1:	5c                   	pop    sp
     3a2:	ce                   	into
     3a3:	03 17                	add    dx,WORD PTR [bx]
     3a5:	3e 3a 03             	cmp    al,BYTE PTR ds:[bp+di]
     3a8:	30 16 76 03          	xor    BYTE PTR ds:0x376,dl
     3ac:	ed                   	in     ax,dx
     3ad:	3e b2 03             	ds mov dl,0x3
     3b0:	77 3e                	ja     0x3f0
     3b2:	b6 03                	mov    dh,0x3
     3b4:	c2 35 7a             	ret    0x7a35
     3b7:	03 26 6d 9e          	add    sp,WORD PTR ds:0x9e6d
     3bb:	03 ae 5f 8a          	add    bp,WORD PTR [bp-0x75a1]
     3bf:	03 35                	add    si,WORD PTR [di]
     3c1:	62 9a 03 ec          	bound  bx,DWORD PTR [bp+si-0x13fd]
     3c5:	2e 3d 04 b2          	cs cmp ax,0xb204
     3c9:	5c                   	pop    sp
     3ca:	a2 03 93             	mov    ds:0x9303,al
     3cd:	24 4e                	and    al,0x4e
     3cf:	03 5b 27             	add    bx,WORD PTR [bp+di+0x27]
     3d2:	e6 03                	out    0x3,al
     3d4:	81 28 c6 03          	sub    WORD PTR [bx+si],0x3c6
     3d8:	e7 13                	out    0x13,ax
     3da:	de 03                	fiadd  WORD PTR [bp+di]
     3dc:	e9 1b e2             	jmp    0xe5fa
     3df:	03 7f 26             	add    di,WORD PTR [bx+0x26]
     3e2:	d2 03                	rol    BYTE PTR [bp+di],cl
     3e4:	db 11                	fist   DWORD PTR [bx+di]
     3e6:	ea 03 97 12 ee       	jmp    0xee12:0x9703
     3eb:	03 e9                	add    bp,cx
     3ed:	15 5a 03             	adc    ax,0x35a
     3f0:	07                   	pop    es
     3f1:	54                   	push   sp
     3f2:	44                   	inc    sp
     3f3:	42                   	inc    dx
     3f4:	47                   	inc    di
     3f5:	72 69                	jb     0x460
     3f7:	64 07                	fs pop es
     3f9:	07                   	pop    es
     3fa:	54                   	push   sp
     3fb:	44                   	inc    sp
     3fc:	42                   	inc    dx
     3fd:	47                   	inc    di
     3fe:	72 69                	jb     0x469
     400:	64 48                	fs dec ax
     402:	03 07                	add    ax,WORD PTR [bx]
     404:	04 05                	add    al,0x5
     406:	03 99 04 2c          	add    bx,WORD PTR [bx+di+0x2c04]
     40a:	00 07                	add    BYTE PTR [bx],al
     40c:	44                   	inc    sp
     40d:	42                   	inc    dx
     40e:	47                   	inc    di
     40f:	72 69                	jb     0x47a
     411:	64 73 23             	fs jae 0x437
     414:	00 e2                	add    dl,ah
     416:	00 1f                	add    BYTE PTR [bx],bl
     418:	04 2d                	add    al,0x2d
     41a:	00 ff                	add    bh,bh
     41c:	ff 72 16             	push   WORD PTR [bp+si+0x16]
     41f:	61                   	popa
     420:	04 01                	add    al,0x1
     422:	00 00                	add    BYTE PTR [bx+si],al
     424:	00 00                	add    BYTE PTR [bx+si],al
     426:	80 00 00             	add    BYTE PTR [bx+si],0x0
     429:	00 00                	add    BYTE PTR [bx+si],al
     42b:	0a 00                	or     al,BYTE PTR [bx+si]
     42d:	05 41 6c             	add    ax,0x6c41
     430:	69 67 6e d4 02       	imul   sp,WORD PTR [bx+0x6e],0x2d4
     435:	d5 2a                	aad    0x2a
     437:	e4 00                	in     al,0x0
     439:	ff                   	(bad)
     43a:	ff                   	(bad)
     43b:	be 6f 4b             	mov    si,0x4b6f
     43e:	05 01 00             	add    ax,0x1
     441:	00 00                	add    BYTE PTR [bx+si],al
     443:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     447:	00 00                	add    BYTE PTR [bx+si],al
     449:	0b 00                	or     ax,WORD PTR [bx+si]
     44b:	0b 42 6f             	or     ax,WORD PTR [bp+si+0x6f]
     44e:	72 64                	jb     0x4b4
     450:	65 72 53             	gs jb  0x4a6
     453:	74 79                	je     0x4ce
     455:	6c                   	ins    BYTE PTR es:[di],dx
     456:	65 02 00             	add    al,BYTE PTR gs:[bx+si]
     459:	43                   	inc    bx
     45a:	05 38 00             	add    ax,0x38
     45d:	ff                   	(bad)
     45e:	ff d5                	call   bp
     460:	1e                   	push   ds
     461:	65 04 17             	gs add al,0x17
     464:	1f                   	pop    ds
     465:	7f 04                	jg     0x46b
     467:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
     46b:	ff                   	(bad)
     46c:	ff 0c                	dec    WORD PTR [si]
     46e:	00 05                	add    BYTE PTR [di],al
     470:	43                   	inc    bx
     471:	6f                   	outs   dx,WORD PTR ds:[si]
     472:	6c                   	ins    BYTE PTR es:[di],dx
     473:	6f                   	outs   dx,WORD PTR ds:[si]
     474:	72 07                	jb     0x47d
     476:	23 b8 04 a5          	and    di,WORD PTR [bx+si-0x5afc]
     47a:	00 ff                	add    bh,bh
     47c:	ff 22                	jmp    WORD PTR [bp+si]
     47e:	63 83 04 54          	arpl   WORD PTR [bp+di+0x5404],ax
     482:	63 df                	arpl   di,bx
     484:	04 00                	add    al,0x0
     486:	80 00 00             	add    BYTE PTR [bx+si],0x0
     489:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     48d:	05 43 74             	add    ax,0x7443
     490:	6c                   	ins    BYTE PTR es:[di],dx
     491:	33 44 04             	xor    ax,WORD PTR [si+0x4]
     494:	09 0d                	or     WORD PTR [di],cx
     496:	09 58 16             	or     WORD PTR [bx+si+0x16],bx
     499:	9d                   	popf
     49a:	04 59                	add    al,0x59
     49c:	19 83 05 01          	sbb    WORD PTR [bp+di+0x105],ax
     4a0:	00 00                	add    BYTE PTR [bx+si],al
     4a2:	00 00                	add    BYTE PTR [bx+si],al
     4a4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     4a7:	00 80 0e 00          	add    BYTE PTR [bx+si+0xe],al
     4ab:	0a 44 61             	or     al,BYTE PTR [si+0x61]
     4ae:	74 61                	je     0x511
     4b0:	53                   	push   bx
     4b1:	6f                   	outs   dx,WORD PTR ds:[si]
     4b2:	75 72                	jne    0x526
     4b4:	63 65 07             	arpl   WORD PTR [di+0x7],sp
     4b7:	23 23                	and    sp,WORD PTR [bp+di]
     4b9:	05 59 01             	add    ax,0x159
     4bc:	ff                   	(bad)
     4bd:	ff 59 01             	call   DWORD PTR [bx+di+0x1]
     4c0:	ff                   	(bad)
     4c1:	ff 01                	inc    WORD PTR [bx+di]
     4c3:	00 00                	add    BYTE PTR [bx+si],al
     4c5:	00 00                	add    BYTE PTR [bx+si],al
     4c7:	80 01 00             	add    BYTE PTR [bx+di],0x0
     4ca:	00 00                	add    BYTE PTR [bx+si],al
     4cc:	0f 00 0e 44 65       	str    WORD PTR ds:0x6544
     4d1:	66 61                	popad
     4d3:	75 6c                	jne    0x541
     4d5:	74 44                	je     0x51b
     4d7:	72 61                	jb     0x53a
     4d9:	77 69                	ja     0x544
     4db:	6e                   	outs   dx,BYTE PTR ds:[si]
     4dc:	67 64 00 02          	add    BYTE PTR fs:[edx],al
     4e0:	05 3e 00             	add    ax,0x3e
     4e3:	ff                   	(bad)
     4e4:	ff                   	(bad)
     4e5:	3e 00 ff             	ds add bh,bh
     4e8:	ff 01                	inc    WORD PTR [bx+di]
     4ea:	00 00                	add    BYTE PTR [bx+si],al
     4ec:	00 00                	add    BYTE PTR [bx+si],al
     4ee:	80 f4 ff             	xor    ah,0xff
     4f1:	ff                   	(bad)
     4f2:	ff 10                	call   WORD PTR [bx+si]
     4f4:	00 0a                	add    BYTE PTR [bp+si],cl
     4f6:	44                   	inc    sp
     4f7:	72 61                	jb     0x55a
     4f9:	67 43                	addr32 inc bx
     4fb:	75 72                	jne    0x56f
     4fd:	73 6f                	jae    0x56e
     4ff:	72 25                	jb     0x526
     501:	01 2b                	add    WORD PTR [bp+di],bp
     503:	05 2e 00             	add    ax,0x2e
     506:	ff                   	(bad)
     507:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     50b:	ff 01                	inc    WORD PTR [bx+di]
     50d:	00 00                	add    BYTE PTR [bx+si],al
     50f:	00 00                	add    BYTE PTR [bx+si],al
     511:	80 00 00             	add    BYTE PTR [bx+si],0x0
     514:	00 00                	add    BYTE PTR [bx+si],al
     516:	11 00                	adc    WORD PTR [bx+si],ax
     518:	08 44 72             	or     BYTE PTR [si+0x72],al
     51b:	61                   	popa
     51c:	67 4d                	addr32 dec bp
     51e:	6f                   	outs   dx,WORD PTR ds:[si]
     51f:	64 65 07             	fs gs pop es
     522:	23 a3 05 2a          	and    sp,WORD PTR [bp+di+0x2a05]
     526:	00 ff                	add    bh,bh
     528:	ff                   	(bad)
     529:	b8 1c 6e             	mov    ax,0x6e1c
     52c:	05 01 00             	add    ax,0x1
     52f:	00 00                	add    BYTE PTR [bx+si],al
     531:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     535:	00 00                	add    BYTE PTR [bx+si],al
     537:	12 00                	adc    al,BYTE PTR [bx+si]
     539:	07                   	pop    es
     53a:	45                   	inc    bp
     53b:	6e                   	outs   dx,BYTE PTR ds:[si]
     53c:	61                   	popa
     53d:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     540:	64 02 00             	add    al,BYTE PTR fs:[bx+si]
     543:	66 05 02 01 ff ff    	add    eax,0xffff0102
     549:	fa                   	cli
     54a:	71 c4                	jno    0x510
     54c:	08 01                	or     BYTE PTR [bx+di],al
     54e:	00 00                	add    BYTE PTR [bx+si],al
     550:	00 00                	add    BYTE PTR [bx+si],al
     552:	80 f0 ff             	xor    al,0xff
     555:	ff                   	(bad)
     556:	ff 13                	call   WORD PTR [bp+di]
     558:	00 0a                	add    BYTE PTR [bp+si],cl
     55a:	46                   	inc    si
     55b:	69 78 65 64 43       	imul   di,WORD PTR [bx+si+0x65],0x4364
     560:	6f                   	outs   dx,WORD PTR ds:[si]
     561:	6c                   	ins    BYTE PTR es:[di],dx
     562:	6f                   	outs   dx,WORD PTR ds:[si]
     563:	72 22                	jb     0x587
     565:	03 da                	add    bx,dx
     567:	06                   	push   es
     568:	34 00                	xor    al,0x0
     56a:	ff                   	(bad)
     56b:	ff                   	jmp    (bad)
     56c:	eb 1d                	jmp    0x58b
     56e:	72 05                	jb     0x575
     570:	08 1e ab 05          	or     BYTE PTR ds:0x5ab,bl
     574:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     578:	00 80 14 00          	add    BYTE PTR [bx+si+0x14],al
     57c:	04 46                	add    al,0x46
     57e:	6f                   	outs   dx,WORD PTR ds:[si]
     57f:	6e                   	outs   dx,BYTE PTR ds:[si]
     580:	74 3e                	je     0x5c0
     582:	01 8b 05 53          	add    WORD PTR [bp+di+0x5305],cx
     586:	01 ff                	add    di,di
     588:	ff a1 36 e2          	jmp    WORD PTR [bx+di-0x1dca]
     58c:	06                   	push   es
     58d:	01 00                	add    WORD PTR [bx+si],ax
     58f:	00 00                	add    BYTE PTR [bx+si],al
     591:	00 80 fd 0c          	add    BYTE PTR [bx+si+0xcfd],al
     595:	00 00                	add    BYTE PTR [bx+si],al
     597:	15 00 07             	adc    ax,0x700
     59a:	4f                   	dec    di
     59b:	70 74                	jo     0x611
     59d:	69 6f 6e 73 07       	imul   bp,WORD PTR [bx+0x6e],0x773
     5a2:	23 c7                	and    ax,di
     5a4:	05 2c 00             	add    ax,0x2c
     5a7:	ff                   	(bad)
     5a8:	ff 32                	push   WORD PTR [bp+si]
     5aa:	1f                   	pop    ds
     5ab:	cf                   	iret
     5ac:	05 01 00             	add    ax,0x1
     5af:	00 00                	add    BYTE PTR [bx+si],al
     5b1:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     5b5:	00 00                	add    BYTE PTR [bx+si],al
     5b7:	16                   	push   ss
     5b8:	00 0b                	add    BYTE PTR [bp+di],cl
     5ba:	50                   	push   ax
     5bb:	61                   	popa
     5bc:	72 65                	jb     0x623
     5be:	6e                   	outs   dx,BYTE PTR ds:[si]
     5bf:	74 43                	je     0x604
     5c1:	6f                   	outs   dx,WORD PTR ds:[si]
     5c2:	6c                   	ins    BYTE PTR es:[di],dx
     5c3:	6f                   	outs   dx,WORD PTR ds:[si]
     5c4:	72 07                	jb     0x5cd
     5c6:	23 eb                	and    bp,bx
     5c8:	05 a6 00             	add    ax,0xa6
     5cb:	ff                   	(bad)
     5cc:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     5cf:	f3 05 01 00          	repz add ax,0x1
     5d3:	00 00                	add    BYTE PTR [bx+si],al
     5d5:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     5d9:	00 00                	add    BYTE PTR [bx+si],al
     5db:	17                   	pop    ss
     5dc:	00 0b                	add    BYTE PTR [bp+di],cl
     5de:	50                   	push   ax
     5df:	61                   	popa
     5e0:	72 65                	jb     0x647
     5e2:	6e                   	outs   dx,BYTE PTR ds:[si]
     5e3:	74 43                	je     0x628
     5e5:	74 6c                	je     0x653
     5e7:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     5ea:	23 0e 06 2b          	and    cx,WORD PTR ds:0x2b06
     5ee:	00 ff                	add    bh,bh
     5f0:	ff                   	(bad)
     5f1:	3e 1e                	ds push ds
     5f3:	16                   	push   ss
     5f4:	06                   	push   es
     5f5:	01 00                	add    WORD PTR [bx+si],ax
     5f7:	00 00                	add    BYTE PTR [bx+si],al
     5f9:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     5fd:	00 00                	add    BYTE PTR [bx+si],al
     5ff:	18 00                	sbb    BYTE PTR [bx+si],al
     601:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     604:	72 65                	jb     0x66b
     606:	6e                   	outs   dx,BYTE PTR ds:[si]
     607:	74 46                	je     0x64f
     609:	6f                   	outs   dx,WORD PTR ds:[si]
     60a:	6e                   	outs   dx,BYTE PTR ds:[si]
     60b:	74 07                	je     0x614
     60d:	23 57 06             	and    dx,WORD PTR [bx+0x6]
     610:	49                   	dec    cx
     611:	00 ff                	add    bh,bh
     613:	ff a1 1e 80          	jmp    WORD PTR [bx+di-0x7fe2]
     617:	06                   	push   es
     618:	01 00                	add    WORD PTR [bx+si],ax
     61a:	00 00                	add    BYTE PTR [bx+si],al
     61c:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     620:	00 00                	add    BYTE PTR [bx+si],al
     622:	19 00                	sbb    WORD PTR [bx+si],ax
     624:	0e                   	push   cs
     625:	50                   	push   ax
     626:	61                   	popa
     627:	72 65                	jb     0x68e
     629:	6e                   	outs   dx,BYTE PTR ds:[si]
     62a:	74 53                	je     0x67f
     62c:	68 6f 77             	push   0x776f
     62f:	48                   	dec    ax
     630:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     635:	ff                   	(bad)
     636:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     639:	ff                   	(bad)
     63a:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     63d:	ff                   	(bad)
     63e:	ff 01                	inc    WORD PTR [bx+di]
     640:	00 00                	add    BYTE PTR [bx+si],al
     642:	00 00                	add    BYTE PTR [bx+si],al
     644:	80 00 00             	add    BYTE PTR [bx+si],0x0
     647:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     64b:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     64e:	70 75                	jo     0x6c5
     650:	70 4d                	jo     0x69f
     652:	65 6e                	outs   dx,BYTE PTR gs:[si]
     654:	75 07                	jne    0x65d
     656:	23 78 06             	and    di,WORD PTR [bx+si+0x6]
     659:	4d                   	dec    bp
     65a:	01 ff                	add    di,di
     65c:	ff 4d 01             	dec    WORD PTR [di+0x1]
     65f:	ff                   	(bad)
     660:	ff 01                	inc    WORD PTR [bx+di]
     662:	00 00                	add    BYTE PTR [bx+si],al
     664:	00 00                	add    BYTE PTR [bx+si],al
     666:	80 00 00             	add    BYTE PTR [bx+si],0x0
     669:	00 00                	add    BYTE PTR [bx+si],al
     66b:	1b 00                	sbb    ax,WORD PTR [bx+si]
     66d:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
     670:	61                   	popa
     671:	64 4f                	fs dec di
     673:	6e                   	outs   dx,BYTE PTR ds:[si]
     674:	6c                   	ins    BYTE PTR es:[di],dx
     675:	79 07                	jns    0x67e
     677:	23 ba 06 48          	and    di,WORD PTR [bp+si+0x4806]
     67b:	00 ff                	add    bh,bh
     67d:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     680:	84 06 23 1e          	test   BYTE PTR ds:0x1e23,al
     684:	99                   	cwd
     685:	06                   	push   es
     686:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     68a:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
     68e:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     691:	6f                   	outs   dx,WORD PTR ds:[si]
     692:	77 48                	ja     0x6dc
     694:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     699:	9d                   	popf
     69a:	06                   	push   es
     69b:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     69c:	63 a1 06 60          	arpl   WORD PTR [bx+di+0x6006],sp
     6a0:	64 c2 06 01          	fs ret 0x106
     6a4:	00 00                	add    BYTE PTR [bx+si],al
     6a6:	00 00                	add    BYTE PTR [bx+si],al
     6a8:	80 ff ff             	cmp    bh,0xff
     6ab:	ff                   	(bad)
     6ac:	ff 1d                	call   DWORD PTR [di]
     6ae:	00 08                	add    BYTE PTR [bx+si],cl
     6b0:	54                   	push   sp
     6b1:	61                   	popa
     6b2:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     6b5:	64 65 72 07          	fs gs jb 0x6c0
     6b9:	23 fc                	and    di,sp
     6bb:	06                   	push   es
     6bc:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     6bd:	00 ff                	add    bh,bh
     6bf:	ff 88 64 04          	dec    WORD PTR [bx+si+0x464]
     6c3:	07                   	pop    es
     6c4:	01 00                	add    WORD PTR [bx+si],ax
     6c6:	00 00                	add    BYTE PTR [bx+si],al
     6c8:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     6cc:	00 00                	add    BYTE PTR [bx+si],al
     6ce:	09 00                	or     WORD PTR [bx+si],ax
     6d0:	07                   	pop    es
     6d1:	54                   	push   sp
     6d2:	61                   	popa
     6d3:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     6d6:	6f                   	outs   dx,WORD PTR ds:[si]
     6d7:	70 22                	jo     0x6fb
     6d9:	03 9b 0c 45          	add    bx,WORD PTR [bp+di+0x450c]
     6dd:	01 ff                	add    di,di
     6df:	ff 58 37             	call   DWORD PTR [bx+si+0x37]
     6e2:	61                   	popa
     6e3:	07                   	pop    es
     6e4:	01 00                	add    WORD PTR [bx+si],ax
     6e6:	00 00                	add    BYTE PTR [bx+si],al
     6e8:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     6ec:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
     6f0:	09 54 69             	or     WORD PTR [si+0x69],dx
     6f3:	74 6c                	je     0x761
     6f5:	65 46                	gs inc si
     6f7:	6f                   	outs   dx,WORD PTR ds:[si]
     6f8:	6e                   	outs   dx,BYTE PTR ds:[si]
     6f9:	74 07                	je     0x702
     6fb:	23 d2                	and    dx,dx
     6fd:	08 29                	or     BYTE PTR [bx+di],ch
     6ff:	00 ff                	add    bh,bh
     701:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     704:	ab                   	stos   WORD PTR es:[di],ax
     705:	07                   	pop    es
     706:	01 00                	add    WORD PTR [bx+si],ax
     708:	00 00                	add    BYTE PTR [bx+si],al
     70a:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     70e:	00 00                	add    BYTE PTR [bx+si],al
     710:	1f                   	pop    ds
     711:	00 07                	add    BYTE PTR [bx],al
     713:	56                   	push   si
     714:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     719:	65 71 00             	gs jno 0x71c
     71c:	3f                   	aas
     71d:	07                   	pop    es
     71e:	61                   	popa
     71f:	01 ff                	add    di,di
     721:	ff 61 01             	jmp    WORD PTR [bx+di+0x1]
     724:	ff                   	(bad)
     725:	ff 01                	inc    WORD PTR [bx+di]
     727:	00 00                	add    BYTE PTR [bx+si],al
     729:	00 00                	add    BYTE PTR [bx+si],al
     72b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     72e:	00 80 20 00          	add    BYTE PTR [bx+si+0x20],al
     732:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     735:	43                   	inc    bx
     736:	6f                   	outs   dx,WORD PTR ds:[si]
     737:	6c                   	ins    BYTE PTR es:[di],dx
     738:	45                   	inc    bp
     739:	6e                   	outs   dx,BYTE PTR ds:[si]
     73a:	74 65                	je     0x7a1
     73c:	72 71                	jb     0x7af
     73e:	00 88 07 69          	add    BYTE PTR [bx+si+0x6907],cl
     742:	01 ff                	add    di,di
     744:	ff 69 01             	jmp    DWORD PTR [bx+di+0x1]
     747:	ff                   	(bad)
     748:	ff 01                	inc    WORD PTR [bx+di]
     74a:	00 00                	add    BYTE PTR [bx+si],al
     74c:	00 00                	add    BYTE PTR [bx+si],al
     74e:	80 00 00             	add    BYTE PTR [bx+si],0x0
     751:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     755:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     758:	43                   	inc    bx
     759:	6f                   	outs   dx,WORD PTR ds:[si]
     75a:	6c                   	ins    BYTE PTR es:[di],dx
     75b:	45                   	inc    bp
     75c:	78 69                	js     0x7c7
     75e:	74 53                	je     0x7b3
     760:	01 42 09             	add    WORD PTR [bp+si+0x9],ax
     763:	71 01                	jno    0x766
     765:	ff                   	(bad)
     766:	ff 71 01             	push   WORD PTR [bx+di+0x1]
     769:	ff                   	(bad)
     76a:	ff 01                	inc    WORD PTR [bx+di]
     76c:	00 00                	add    BYTE PTR [bx+si],al
     76e:	00 00                	add    BYTE PTR [bx+si],al
     770:	80 00 00             	add    BYTE PTR [bx+si],0x0
     773:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     777:	0e                   	push   cs
     778:	4f                   	dec    di
     779:	6e                   	outs   dx,BYTE PTR ds:[si]
     77a:	44                   	inc    sp
     77b:	72 61                	jb     0x7de
     77d:	77 44                	ja     0x7c3
     77f:	61                   	popa
     780:	74 61                	je     0x7e3
     782:	43                   	inc    bx
     783:	65 6c                	gs ins BYTE PTR es:[di],dx
     785:	6c                   	ins    BYTE PTR es:[di],dx
     786:	71 00                	jno    0x788
     788:	13 08                	adc    cx,WORD PTR [bx+si]
     78a:	82 00 ff             	add    BYTE PTR [bx+si],0xff
     78d:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     791:	ff 01                	inc    WORD PTR [bx+di]
     793:	00 00                	add    BYTE PTR [bx+si],al
     795:	00 00                	add    BYTE PTR [bx+si],al
     797:	80 00 00             	add    BYTE PTR [bx+si],0x0
     79a:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     79e:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     7a1:	44                   	inc    sp
     7a2:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     7a5:	6c                   	ins    BYTE PTR es:[di],dx
     7a6:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     7ab:	ce                   	into
     7ac:	07                   	pop    es
     7ad:	62 00                	bound  ax,DWORD PTR [bx+si]
     7af:	ff                   	(bad)
     7b0:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     7b3:	ff                   	(bad)
     7b4:	ff 01                	inc    WORD PTR [bx+di]
     7b6:	00 00                	add    BYTE PTR [bx+si],al
     7b8:	00 00                	add    BYTE PTR [bx+si],al
     7ba:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7bd:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     7c1:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     7c4:	44                   	inc    sp
     7c5:	72 61                	jb     0x828
     7c7:	67 44                	addr32 inc sp
     7c9:	72 6f                	jb     0x83a
     7cb:	70 80                	jo     0x74d
     7cd:	02 f1                	add    dh,cl
     7cf:	07                   	pop    es
     7d0:	6a 00                	push   0x0
     7d2:	ff                   	(bad)
     7d3:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     7d6:	ff                   	(bad)
     7d7:	ff 01                	inc    WORD PTR [bx+di]
     7d9:	00 00                	add    BYTE PTR [bx+si],al
     7db:	00 00                	add    BYTE PTR [bx+si],al
     7dd:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7e0:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     7e4:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     7e7:	44                   	inc    sp
     7e8:	72 61                	jb     0x84b
     7ea:	67 4f                	addr32 dec di
     7ec:	76 65                	jbe    0x853
     7ee:	72 32                	jb     0x822
     7f0:	03 52 08             	add    dx,WORD PTR [bp+si+0x8]
     7f3:	72 00                	jb     0x7f5
     7f5:	ff                   	(bad)
     7f6:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     7f9:	ff                   	(bad)
     7fa:	ff 01                	inc    WORD PTR [bx+di]
     7fc:	00 00                	add    BYTE PTR [bx+si],al
     7fe:	00 00                	add    BYTE PTR [bx+si],al
     800:	80 00 00             	add    BYTE PTR [bx+si],0x0
     803:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
     807:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     80a:	45                   	inc    bp
     80b:	6e                   	outs   dx,BYTE PTR ds:[si]
     80c:	64 44                	fs inc sp
     80e:	72 61                	jb     0x871
     810:	67 71 00             	addr32 jno 0x813
     813:	33 08                	xor    cx,WORD PTR [bx+si]
     815:	c8 00 ff ff          	enter  0xff00,0xff
     819:	c8 00 ff ff          	enter  0xff00,0xff
     81d:	01 00                	add    WORD PTR [bx+si],ax
     81f:	00 00                	add    BYTE PTR [bx+si],al
     821:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     825:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
     829:	07                   	pop    es
     82a:	4f                   	dec    di
     82b:	6e                   	outs   dx,BYTE PTR ds:[si]
     82c:	45                   	inc    bp
     82d:	6e                   	outs   dx,BYTE PTR ds:[si]
     82e:	74 65                	je     0x895
     830:	72 71                	jb     0x8a3
     832:	00 49 0e             	add    BYTE PTR [bx+di+0xe],cl
     835:	d0 00                	rol    BYTE PTR [bx+si],1
     837:	ff                   	(bad)
     838:	ff d0                	call   ax
     83a:	00 ff                	add    bh,bh
     83c:	ff 01                	inc    WORD PTR [bx+di]
     83e:	00 00                	add    BYTE PTR [bx+si],al
     840:	00 00                	add    BYTE PTR [bx+si],al
     842:	80 00 00             	add    BYTE PTR [bx+si],0x0
     845:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
     849:	06                   	push   es
     84a:	4f                   	dec    di
     84b:	6e                   	outs   dx,BYTE PTR ds:[si]
     84c:	45                   	inc    bp
     84d:	78 69                	js     0x8b8
     84f:	74 1a                	je     0x86b
     851:	02 74 08             	add    dh,BYTE PTR [si+0x8]
     854:	b0 00                	mov    al,0x0
     856:	ff                   	(bad)
     857:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     85b:	ff 01                	inc    WORD PTR [bx+di]
     85d:	00 00                	add    BYTE PTR [bx+si],al
     85f:	00 00                	add    BYTE PTR [bx+si],al
     861:	80 00 00             	add    BYTE PTR [bx+si],0x0
     864:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
     868:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     86b:	4b                   	dec    bx
     86c:	65 79 44             	gs jns 0x8b3
     86f:	6f                   	outs   dx,WORD PTR ds:[si]
     870:	77 6e                	ja     0x8e0
     872:	54                   	push   sp
     873:	02 97 08 b8          	add    dl,BYTE PTR [bx-0x47f8]
     877:	00 ff                	add    bh,bh
     879:	ff                   	(bad)
     87a:	b8 00 ff             	mov    ax,0xff00
     87d:	ff 01                	inc    WORD PTR [bx+di]
     87f:	00 00                	add    BYTE PTR [bx+si],al
     881:	00 00                	add    BYTE PTR [bx+si],al
     883:	80 00 00             	add    BYTE PTR [bx+si],0x0
     886:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
     88a:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     88d:	4b                   	dec    bx
     88e:	65 79 50             	gs jns 0x8e1
     891:	72 65                	jb     0x8f8
     893:	73 73                	jae    0x908
     895:	1a 02                	sbb    al,BYTE PTR [bp+si]
     897:	06                   	push   es
     898:	11 c0                	adc    ax,ax
     89a:	00 ff                	add    bh,bh
     89c:	ff c0                	inc    ax
     89e:	00 ff                	add    bh,bh
     8a0:	ff 01                	inc    WORD PTR [bx+di]
     8a2:	00 00                	add    BYTE PTR [bx+si],al
     8a4:	00 00                	add    BYTE PTR [bx+si],al
     8a6:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8a9:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
     8ad:	07                   	pop    es
     8ae:	4f                   	dec    di
     8af:	6e                   	outs   dx,BYTE PTR ds:[si]
     8b0:	4b                   	dec    bx
     8b1:	65 79 55             	gs jns 0x909
     8b4:	70 55                	jo     0x90b
     8b6:	89 e5                	mov    bp,sp
     8b8:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     8bb:	06                   	push   es
     8bc:	57                   	push   di
     8bd:	b0 01                	mov    al,0x1
     8bf:	50                   	push   ax
     8c0:	b8 22 00             	mov    ax,0x22
     8c3:	ba 6d 0f             	mov    dx,0xf6d
     8c6:	52                   	push   dx
     8c7:	50                   	push   ax
     8c8:	9a e6 28 e8 08       	call   0x8e8:0x28e6
     8cd:	52                   	push   dx
     8ce:	50                   	push   ax
     8cf:	9a 99 13 00 09       	call   0x900:0x1399
     8d4:	c9                   	leave
     8d5:	c2 04 00             	ret    0x4
     8d8:	c8 00 01 00          	enter  0x100,0x0
     8dc:	8d be 00 ff          	lea    di,[bp-0x100]
     8e0:	16                   	push   ss
     8e1:	57                   	push   di
     8e2:	ff 76 04             	push   WORD PTR [bp+0x4]
     8e5:	9a 2b 09 31 0d       	call   0xd31:0x92b
     8ea:	e8 c8 ff             	call   0x8b5
     8ed:	c9                   	leave
     8ee:	c2 02 00             	ret    0x2
     8f1:	55                   	push   bp
     8f2:	89 e5                	mov    bp,sp
     8f4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     8f8:	74 08                	je     0x902
     8fa:	83 ec 08             	sub    sp,0x8
     8fd:	9a e2 1f 5a 09       	call   0x95a:0x1fe2
     902:	31 c0                	xor    ax,ax
     904:	50                   	push   ax
     905:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     908:	06                   	push   es
     909:	57                   	push   di
     90a:	9a dc 75 4f 09       	call   0x94f:0x75dc
     90f:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     912:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
     915:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     918:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
     91c:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
     920:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     924:	74 07                	je     0x92d
     926:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     92a:	83 c4 06             	add    sp,0x6
     92d:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     930:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     933:	c9                   	leave
     934:	ca 0a 00             	retf   0xa
     937:	55                   	push   bp
     938:	89 e5                	mov    bp,sp
     93a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     93d:	06                   	push   es
     93e:	57                   	push   di
     93f:	9a 23 0b 78 0b       	call   0xb78:0xb23
     944:	31 c0                	xor    ax,ax
     946:	50                   	push   ax
     947:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     94a:	06                   	push   es
     94b:	57                   	push   di
     94c:	9a 1a 76 70 09       	call   0x970:0x761a
     951:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     955:	74 05                	je     0x95c
     957:	9a 0f 20 3b 0a       	call   0xa3b:0x200f
     95c:	c9                   	leave
     95d:	ca 06 00             	retf   0x6
     960:	c8 02 00 00          	enter  0x2,0x0
     964:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
     968:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     96b:	06                   	push   es
     96c:	57                   	push   di
     96d:	9a fa 76 7e 09       	call   0x97e:0x76fa
     972:	09 d0                	or     ax,dx
     974:	74 15                	je     0x98b
     976:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     979:	06                   	push   es
     97a:	57                   	push   di
     97b:	9a fa 76 b8 09       	call   0x9b8:0x76fa
     980:	89 c7                	mov    di,ax
     982:	8e c2                	mov    es,dx
     984:	26 8a 45 3c          	mov    al,BYTE PTR es:[di+0x3c]
     988:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     98b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     98e:	c9                   	leave
     98f:	ca 04 00             	retf   0x4
     992:	c8 04 00 00          	enter  0x4,0x0
     996:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     999:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     99c:	26 3b 45 18          	cmp    ax,WORD PTR es:[di+0x18]
     9a0:	7d 29                	jge    0x9cb
     9a2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     9a5:	d1 e0                	shl    ax,1
     9a7:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
     9ab:	03 f8                	add    di,ax
     9ad:	26 ff 35             	push   WORD PTR es:[di]
     9b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9b3:	06                   	push   es
     9b4:	57                   	push   di
     9b5:	9a fa 76 c3 09       	call   0x9c3:0x76fa
     9ba:	89 c7                	mov    di,ax
     9bc:	8e c2                	mov    es,dx
     9be:	06                   	push   es
     9bf:	57                   	push   di
     9c0:	9a 4b 3b f7 09       	call   0x9f7:0x3b4b
     9c5:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     9c8:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     9cb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     9ce:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     9d1:	c9                   	leave
     9d2:	ca 06 00             	retf   0x6
     9d5:	c8 0c 00 00          	enter  0xc,0x0
     9d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9dc:	26 81 7d 18 f8 7f    	cmp    WORD PTR es:[di+0x18],0x7ff8
     9e2:	7c 06                	jl     0x9ea
     9e4:	68 55 f2             	push   0xf255
     9e7:	e8 ee fe             	call   0x8d8
     9ea:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     9ed:	06                   	push   es
     9ee:	57                   	push   di
     9ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9f2:	06                   	push   es
     9f3:	57                   	push   di
     9f4:	9a fa 76 02 0a       	call   0xa02:0x76fa
     9f9:	89 c7                	mov    di,ax
     9fb:	8e c2                	mov    es,dx
     9fd:	06                   	push   es
     9fe:	57                   	push   di
     9ff:	9a 9b 3b e2 0a       	call   0xae2:0x3b9b
     a04:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     a07:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
     a0a:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     a0d:	0b 46 fc             	or     ax,WORD PTR [bp-0x4]
     a10:	b0 00                	mov    al,0x0
     a12:	74 01                	je     0xa15
     a14:	40                   	inc    ax
     a15:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     a18:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
     a1c:	75 03                	jne    0xa21
     a1e:	e9 de 00             	jmp    0xaff
     a21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a24:	26 83 7d 1a 00       	cmp    WORD PTR es:[di+0x1a],0x0
     a29:	75 20                	jne    0xa4b
     a2b:	26 c7 45 1a 08 00    	mov    WORD PTR es:[di+0x1a],0x8
     a31:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
     a35:	d1 e0                	shl    ax,1
     a37:	50                   	push   ax
     a38:	9a 82 01 86 0a       	call   0xa86:0x182
     a3d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a40:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
     a44:	26 89 55 20          	mov    WORD PTR es:[di+0x20],dx
     a48:	e9 8f 00             	jmp    0xada
     a4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a4e:	26 8b 45 18          	mov    ax,WORD PTR es:[di+0x18]
     a52:	26 3b 45 1a          	cmp    ax,WORD PTR es:[di+0x1a]
     a56:	74 03                	je     0xa5b
     a58:	e9 7f 00             	jmp    0xada
     a5b:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
     a5f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     a62:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     a65:	01 46 f8             	add    WORD PTR [bp-0x8],ax
     a68:	81 7e f8 f8 7f       	cmp    WORD PTR [bp-0x8],0x7ff8
     a6d:	7f 09                	jg     0xa78
     a6f:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     a72:	26 3b 45 18          	cmp    ax,WORD PTR es:[di+0x18]
     a76:	7d 05                	jge    0xa7d
     a78:	c7 46 f8 f8 7f       	mov    WORD PTR [bp-0x8],0x7ff8
     a7d:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     a80:	d1 e0                	shl    ax,1
     a82:	50                   	push   ax
     a83:	9a 82 01 a9 0a       	call   0xaa9:0x182
     a88:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     a8b:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
     a8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a91:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
     a95:	06                   	push   es
     a96:	57                   	push   di
     a97:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     a9a:	06                   	push   es
     a9b:	57                   	push   di
     a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a9f:	26 8b 45 18          	mov    ax,WORD PTR es:[di+0x18]
     aa3:	d1 e0                	shl    ax,1
     aa5:	50                   	push   ax
     aa6:	9a c1 1e c0 0a       	call   0xac0:0x1ec1
     aab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aae:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
     ab2:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
     ab6:	26 8b 45 18          	mov    ax,WORD PTR es:[di+0x18]
     aba:	d1 e0                	shl    ax,1
     abc:	50                   	push   ax
     abd:	9a 9c 01 45 0b       	call   0xb45:0x19c
     ac2:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     ac5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ac8:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
     acc:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
     acf:	8b 56 f6             	mov    dx,WORD PTR [bp-0xa]
     ad2:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
     ad6:	26 89 55 20          	mov    WORD PTR es:[di+0x20],dx
     ada:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
     add:	06                   	push   es
     ade:	57                   	push   di
     adf:	9a 3c 69 79 0c       	call   0xc79:0x693c
     ae4:	8b d0                	mov    dx,ax
     ae6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ae9:	26 8b 45 18          	mov    ax,WORD PTR es:[di+0x18]
     aed:	d1 e0                	shl    ax,1
     aef:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
     af3:	03 f8                	add    di,ax
     af5:	26 89 15             	mov    WORD PTR es:[di],dx
     af8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     afb:	26 ff 45 18          	inc    WORD PTR es:[di+0x18]
     aff:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     b02:	c9                   	leave
     b03:	ca 08 00             	retf   0x8
     b06:	55                   	push   bp
     b07:	89 e5                	mov    bp,sp
     b09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b0c:	26 8a 45 11          	mov    al,BYTE PTR es:[di+0x11]
     b10:	50                   	push   ax
     b11:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
     b15:	06                   	push   es
     b16:	57                   	push   di
     b17:	26 c4 3d             	les    di,DWORD PTR es:[di]
     b1a:	26 ff 9d a4 00       	call   DWORD PTR es:[di+0xa4]
     b1f:	c9                   	leave
     b20:	ca 04 00             	retf   0x4
     b23:	55                   	push   bp
     b24:	89 e5                	mov    bp,sp
     b26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b29:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
     b2d:	26 0b 45 20          	or     ax,WORD PTR es:[di+0x20]
     b31:	74 23                	je     0xb56
     b33:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
     b37:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
     b3b:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
     b3f:	d1 e0                	shl    ax,1
     b41:	50                   	push   ax
     b42:	9a 9c 01 d5 0c       	call   0xcd5:0x19c
     b47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b4a:	31 c0                	xor    ax,ax
     b4c:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
     b50:	31 c0                	xor    ax,ax
     b52:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
     b56:	c9                   	leave
     b57:	ca 04 00             	retf   0x4
     b5a:	55                   	push   bp
     b5b:	89 e5                	mov    bp,sp
     b5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b60:	26 c6 45 1c 01       	mov    BYTE PTR es:[di+0x1c],0x1
     b65:	c9                   	leave
     b66:	ca 04 00             	retf   0x4
     b69:	55                   	push   bp
     b6a:	89 e5                	mov    bp,sp
     b6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b6f:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
     b73:	06                   	push   es
     b74:	57                   	push   di
     b75:	9a 06 1a c8 0b       	call   0xbc8:0x1a06
     b7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b7d:	26 c6 45 1c 00       	mov    BYTE PTR es:[di+0x1c],0x0
     b82:	c9                   	leave
     b83:	ca 04 00             	retf   0x4
     b86:	55                   	push   bp
     b87:	89 e5                	mov    bp,sp
     b89:	ff 76 0a             	push   WORD PTR [bp+0xa]
     b8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b8f:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
     b93:	06                   	push   es
     b94:	57                   	push   di
     b95:	26 c4 3d             	les    di,DWORD PTR es:[di]
     b98:	26 ff 9d 94 00       	call   DWORD PTR es:[di+0x94]
     b9d:	c9                   	leave
     b9e:	ca 06 00             	retf   0x6
     ba1:	55                   	push   bp
     ba2:	89 e5                	mov    bp,sp
     ba4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ba7:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
     bab:	06                   	push   es
     bac:	57                   	push   di
     bad:	26 c4 3d             	les    di,DWORD PTR es:[di]
     bb0:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
     bb5:	c9                   	leave
     bb6:	ca 04 00             	retf   0x4
     bb9:	55                   	push   bp
     bba:	89 e5                	mov    bp,sp
     bbc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bbf:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
     bc3:	06                   	push   es
     bc4:	57                   	push   di
     bc5:	9a 65 1a f5 0b       	call   0xbf5:0x1a65
     bca:	c9                   	leave
     bcb:	ca 04 00             	retf   0x4
     bce:	55                   	push   bp
     bcf:	89 e5                	mov    bp,sp
     bd1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     bd4:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
     bd7:	74 0a                	je     0xbe3
     bd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bdc:	26 80 7d 1d 00       	cmp    BYTE PTR es:[di+0x1d],0x0
     be1:	75 1c                	jne    0xbff
     be3:	ff 76 0c             	push   WORD PTR [bp+0xc]
     be6:	ff 76 0a             	push   WORD PTR [bp+0xa]
     be9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bec:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
     bf0:	06                   	push   es
     bf1:	57                   	push   di
     bf2:	9a 8a 1a 07 0c       	call   0xc07:0x1a8a
     bf7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bfa:	26 c6 45 1c 00       	mov    BYTE PTR es:[di+0x1c],0x0
     bff:	c9                   	leave
     c00:	ca 08 00             	retf   0x8
     c03:	00 00                	add    BYTE PTR [bx+si],al
     c05:	48                   	dec    ax
     c06:	0c 32                	or     al,0x32
     c08:	0c 55                	or     al,0x55
     c0a:	89 e5                	mov    bp,sp
     c0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c0f:	26 c6 45 1d 01       	mov    BYTE PTR es:[di+0x1d],0x1
     c14:	b8 03 0c             	mov    ax,0xc03
     c17:	0e                   	push   cs
     c18:	50                   	push   ax
     c19:	55                   	push   bp
     c1a:	ff 36 58 18          	push   WORD PTR ds:0x1858
     c1e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     c22:	26 80 7d 1c 00       	cmp    BYTE PTR es:[di+0x1c],0x0
     c27:	74 0b                	je     0xc34
     c29:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
     c2d:	06                   	push   es
     c2e:	57                   	push   di
     c2f:	9a c9 1e 48 0f       	call   0xf48:0x1ec9
     c34:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c37:	26 c6 45 1c 00       	mov    BYTE PTR es:[di+0x1c],0x0
     c3c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     c40:	83 c4 06             	add    sp,0x6
     c43:	b8 51 0c             	mov    ax,0xc51
     c46:	0e                   	push   cs
     c47:	50                   	push   ax
     c48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c4b:	26 c6 45 1d 00       	mov    BYTE PTR es:[di+0x1d],0x0
     c50:	cb                   	retf
     c51:	c9                   	leave
     c52:	ca 04 00             	retf   0x4
     c55:	55                   	push   bp
     c56:	89 e5                	mov    bp,sp
     c58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c5b:	26 80 7d 1c 00       	cmp    BYTE PTR es:[di+0x1c],0x0
     c60:	74 0f                	je     0xc71
     c62:	6a 00                	push   0x0
     c64:	6a 00                	push   0x0
     c66:	06                   	push   es
     c67:	57                   	push   di
     c68:	26 c4 3d             	les    di,DWORD PTR es:[di]
     c6b:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
     c6f:	eb 15                	jmp    0xc86
     c71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c74:	06                   	push   es
     c75:	57                   	push   di
     c76:	9a fa 76 84 0c       	call   0xc84:0x76fa
     c7b:	89 c7                	mov    di,ax
     c7d:	8e c2                	mov    es,dx
     c7f:	06                   	push   es
     c80:	57                   	push   di
     c81:	9a 8b 55 ec 11       	call   0x11ec:0x558b
     c86:	c9                   	leave
     c87:	ca 04 00             	retf   0x4
     c8a:	55                   	push   bp
     c8b:	89 e5                	mov    bp,sp
     c8d:	83 3e c4 2a 00       	cmp    WORD PTR ds:0x2ac4,0x0
     c92:	75 24                	jne    0xcb8
     c94:	b0 01                	mov    al,0x1
     c96:	50                   	push   ax
     c97:	b8 3f 08             	mov    ax,0x83f
     c9a:	ba a2 0c             	mov    dx,0xca2
     c9d:	52                   	push   dx
     c9e:	50                   	push   ax
     c9f:	9a bd 56 b6 0c       	call   0xcb6:0x56bd
     ca4:	a3 c0 2a             	mov    ds:0x2ac0,ax
     ca7:	89 16 c2 2a          	mov    WORD PTR ds:0x2ac2,dx
     cab:	6a 01                	push   0x1
     cad:	c4 3e c0 2a          	les    di,DWORD PTR ds:0x2ac0
     cb1:	06                   	push   es
     cb2:	57                   	push   di
     cb3:	9a 26 62 0a 0d       	call   0xd0a:0x6226
     cb8:	ff 06 c4 2a          	inc    WORD PTR ds:0x2ac4
     cbc:	c9                   	leave
     cbd:	c3                   	ret
     cbe:	55                   	push   bp
     cbf:	89 e5                	mov    bp,sp
     cc1:	ff 0e c4 2a          	dec    WORD PTR ds:0x2ac4
     cc5:	83 3e c4 2a 00       	cmp    WORD PTR ds:0x2ac4,0x0
     cca:	75 0b                	jne    0xcd7
     ccc:	c4 3e c0 2a          	les    di,DWORD PTR ds:0x2ac0
     cd0:	06                   	push   es
     cd1:	57                   	push   di
     cd2:	9a 7f 1f 56 0e       	call   0xe56:0x1f7f
     cd7:	c9                   	leave
     cd8:	c3                   	ret
     cd9:	c8 02 00 00          	enter  0x2,0x0
     cdd:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     ce0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     ce3:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     ce6:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
     ce9:	7e 06                	jle    0xcf1
     ceb:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     cee:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     cf1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     cf4:	c9                   	leave
     cf5:	c2 04 00             	ret    0x4
     cf8:	c8 20 01 00          	enter  0x120,0x0
     cfc:	83 7e 04 00          	cmp    WORD PTR [bp+0x4],0x0
     d00:	75 48                	jne    0xd4a
     d02:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
     d05:	06                   	push   es
     d06:	57                   	push   di
     d07:	9a d2 21 60 0d       	call   0xd60:0x21d2
     d0c:	50                   	push   ax
     d0d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     d10:	26 8b 05             	mov    ax,WORD PTR es:[di]
     d13:	03 46 0c             	add    ax,WORD PTR [bp+0xc]
     d16:	50                   	push   ax
     d17:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
     d1b:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
     d1e:	50                   	push   ax
     d1f:	6a 06                	push   0x6
     d21:	06                   	push   es
     d22:	57                   	push   di
     d23:	8d be 00 ff          	lea    di,[bp-0x100]
     d27:	16                   	push   ss
     d28:	57                   	push   di
     d29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d2c:	06                   	push   es
     d2d:	57                   	push   di
     d2e:	9a 4c 0d 9c 0d       	call   0xd9c:0xd4c
     d33:	52                   	push   dx
     d34:	50                   	push   ax
     d35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d38:	26 8a 05             	mov    al,BYTE PTR es:[di]
     d3b:	30 e4                	xor    ah,ah
     d3d:	50                   	push   ax
     d3e:	6a 00                	push   0x0
     d40:	6a 00                	push   0x0
     d42:	9a ae 0d 00 00       	call   0x0:0xdae
     d47:	e9 f6 01             	jmp    0xf40
     d4a:	83 7e 04 02          	cmp    WORD PTR [bp+0x4],0x2
     d4e:	75 65                	jne    0xdb5
     d50:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
     d53:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
     d57:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
     d5b:	06                   	push   es
     d5c:	57                   	push   di
     d5d:	9a d2 21 71 0d       	call   0xd71:0x21d2
     d62:	50                   	push   ax
     d63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d66:	06                   	push   es
     d67:	57                   	push   di
     d68:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     d6c:	06                   	push   es
     d6d:	57                   	push   di
     d6e:	9a 03 20 92 0e       	call   0xe92:0x2003
     d73:	8b d0                	mov    dx,ax
     d75:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     d78:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     d7c:	2b c2                	sub    ax,dx
     d7e:	2d 03 00             	sub    ax,0x3
     d81:	50                   	push   ax
     d82:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
     d86:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
     d89:	50                   	push   ax
     d8a:	6a 06                	push   0x6
     d8c:	06                   	push   es
     d8d:	57                   	push   di
     d8e:	8d be 00 ff          	lea    di,[bp-0x100]
     d92:	16                   	push   ss
     d93:	57                   	push   di
     d94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d97:	06                   	push   es
     d98:	57                   	push   di
     d99:	9a 4c 0d f4 0e       	call   0xef4:0xd4c
     d9e:	52                   	push   dx
     d9f:	50                   	push   ax
     da0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     da3:	26 8a 05             	mov    al,BYTE PTR es:[di]
     da6:	30 e4                	xor    ah,ah
     da8:	50                   	push   ax
     da9:	6a 00                	push   0x0
     dab:	6a 00                	push   0x0
     dad:	9a ff ff 00 00       	call   0x0:0xffff
     db2:	e9 8b 01             	jmp    0xf40
     db5:	c4 3e c0 2a          	les    di,DWORD PTR ds:0x2ac0
     db9:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
     dbd:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
     dc1:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     dc4:	89 be e8 fe          	mov    WORD PTR [bp-0x118],di
     dc8:	8c 86 ea fe          	mov    WORD PTR [bp-0x116],es
     dcc:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     dd0:	06                   	push   es
     dd1:	57                   	push   di
     dd2:	26 c4 3d             	les    di,DWORD PTR es:[di]
     dd5:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
     dd9:	50                   	push   ax
     dda:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
     dde:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     de2:	26 2b 05             	sub    ax,WORD PTR es:[di]
     de5:	50                   	push   ax
     de6:	e8 f0 fe             	call   0xcd9
     de9:	50                   	push   ax
     dea:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     dee:	06                   	push   es
     def:	57                   	push   di
     df0:	26 c4 3d             	les    di,DWORD PTR es:[di]
     df3:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
     df7:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     dfb:	06                   	push   es
     dfc:	57                   	push   di
     dfd:	26 c4 3d             	les    di,DWORD PTR es:[di]
     e00:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
     e04:	50                   	push   ax
     e05:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
     e09:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
     e0d:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
     e11:	50                   	push   ax
     e12:	e8 c4 fe             	call   0xcd9
     e15:	50                   	push   ax
     e16:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     e1a:	06                   	push   es
     e1b:	57                   	push   di
     e1c:	26 c4 3d             	les    di,DWORD PTR es:[di]
     e1f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
     e23:	8d be e0 fe          	lea    di,[bp-0x120]
     e27:	16                   	push   ss
     e28:	57                   	push   di
     e29:	ff 76 0c             	push   WORD PTR [bp+0xc]
     e2c:	ff 76 0a             	push   WORD PTR [bp+0xa]
     e2f:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
     e33:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     e37:	26 2b 05             	sub    ax,WORD PTR es:[di]
     e3a:	48                   	dec    ax
     e3b:	50                   	push   ax
     e3c:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
     e40:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
     e44:	48                   	dec    ax
     e45:	50                   	push   ax
     e46:	9a 88 06 7a 0e       	call   0xe7a:0x688
     e4b:	8d be f0 fe          	lea    di,[bp-0x110]
     e4f:	16                   	push   ss
     e50:	57                   	push   di
     e51:	6a 08                	push   0x8
     e53:	9a 1b 16 87 0e       	call   0xe87:0x161b
     e58:	8d be e0 fe          	lea    di,[bp-0x120]
     e5c:	16                   	push   ss
     e5d:	57                   	push   di
     e5e:	6a 00                	push   0x0
     e60:	6a 00                	push   0x0
     e62:	c4 be e8 fe          	les    di,DWORD PTR [bp-0x118]
     e66:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     e6a:	26 2b 05             	sub    ax,WORD PTR es:[di]
     e6d:	50                   	push   ax
     e6e:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
     e72:	26 2b 45 02          	sub    ax,WORD PTR es:[di+0x2]
     e76:	50                   	push   ax
     e77:	9a 88 06 39 2b       	call   0x2b39:0x688
     e7c:	8d be f8 fe          	lea    di,[bp-0x108]
     e80:	16                   	push   ss
     e81:	57                   	push   di
     e82:	6a 08                	push   0x8
     e84:	9a 1b 16 5a 0f       	call   0xf5a:0x161b
     e89:	c4 3e c0 2a          	les    di,DWORD PTR ds:0x2ac0
     e8d:	06                   	push   es
     e8e:	57                   	push   di
     e8f:	9a 0f 5a b4 0e       	call   0xeb4:0x5a0f
     e94:	89 c7                	mov    di,ax
     e96:	8e c2                	mov    es,dx
     e98:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
     e9c:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
     ea0:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
     ea3:	26 ff 75 09          	push   WORD PTR es:[di+0x9]
     ea7:	26 ff 75 07          	push   WORD PTR es:[di+0x7]
     eab:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     eaf:	06                   	push   es
     eb0:	57                   	push   di
     eb1:	9a 99 20 c7 0e       	call   0xec7:0x2099
     eb6:	6a 00                	push   0x0
     eb8:	6a 00                	push   0x0
     eba:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     ebe:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
     ec2:	06                   	push   es
     ec3:	57                   	push   di
     ec4:	9a df 0f d8 0e       	call   0xed8:0xfdf
     ec9:	8d be f8 fe          	lea    di,[bp-0x108]
     ecd:	16                   	push   ss
     ece:	57                   	push   di
     ecf:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     ed3:	06                   	push   es
     ed4:	57                   	push   di
     ed5:	9a e5 1c e3 0e       	call   0xee3:0x1ce5
     eda:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     ede:	06                   	push   es
     edf:	57                   	push   di
     ee0:	9a d2 21 2c 0f       	call   0xf2c:0x21d2
     ee5:	50                   	push   ax
     ee6:	8d be 00 ff          	lea    di,[bp-0x100]
     eea:	16                   	push   ss
     eeb:	57                   	push   di
     eec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eef:	06                   	push   es
     ef0:	57                   	push   di
     ef1:	9a 4c 0d 57 2e       	call   0x2e57:0xd4c
     ef6:	52                   	push   dx
     ef7:	50                   	push   ax
     ef8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     efb:	26 8a 05             	mov    al,BYTE PTR es:[di]
     efe:	30 e4                	xor    ah,ah
     f00:	50                   	push   ax
     f01:	8d be f0 fe          	lea    di,[bp-0x110]
     f05:	16                   	push   ss
     f06:	57                   	push   di
     f07:	ff 76 04             	push   WORD PTR [bp+0x4]
     f0a:	9a ff ff 00 00       	call   0x0:0xffff
     f0f:	c4 3e c0 2a          	les    di,DWORD PTR ds:0x2ac0
     f13:	89 be ec fe          	mov    WORD PTR [bp-0x114],di
     f17:	8c 86 ee fe          	mov    WORD PTR [bp-0x112],es
     f1b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     f1e:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     f21:	06                   	push   es
     f22:	57                   	push   di
     f23:	c4 be ec fe          	les    di,DWORD PTR [bp-0x114]
     f27:	06                   	push   es
     f28:	57                   	push   di
     f29:	9a 0f 5a 3e 0f       	call   0xf3e:0x5a0f
     f2e:	52                   	push   dx
     f2f:	50                   	push   ax
     f30:	8d be f8 fe          	lea    di,[bp-0x108]
     f34:	16                   	push   ss
     f35:	57                   	push   di
     f36:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
     f39:	06                   	push   es
     f3a:	57                   	push   di
     f3b:	9a 10 1b 85 0f       	call   0xf85:0x1b10
     f40:	c9                   	leave
     f41:	c2 12 00             	ret    0x12
     f44:	00 00                	add    BYTE PTR [bx+si],al
     f46:	7b 10                	jnp    0xf58
     f48:	e7 10                	out    0x10,ax
     f4a:	c8 04 00 00          	enter  0x4,0x0
     f4e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     f52:	74 08                	je     0xf5c
     f54:	83 ec 08             	sub    sp,0x8
     f57:	9a e2 1f 83 10       	call   0x1083:0x1fe2
     f5c:	ff 76 0e             	push   WORD PTR [bp+0xe]
     f5f:	ff 76 0c             	push   WORD PTR [bp+0xc]
     f62:	31 c0                	xor    ax,ax
     f64:	50                   	push   ax
     f65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f68:	06                   	push   es
     f69:	57                   	push   di
     f6a:	9a 71 1e af 10       	call   0x10af:0x1e71
     f6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f72:	26 c6 85 3b 01 00    	mov    BYTE PTR es:[di+0x13b],0x0
     f78:	26 c6 85 7a 02 01    	mov    BYTE PTR es:[di+0x27a],0x1
     f7e:	b0 01                	mov    al,0x1
     f80:	50                   	push   ax
     f81:	b8 3f 08             	mov    ax,0x83f
     f84:	ba 8c 0f             	mov    dx,0xf8c
     f87:	52                   	push   dx
     f88:	50                   	push   ax
     f89:	9a bd 56 b9 0f       	call   0xfb9:0x56bd
     f8e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f91:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     f94:	b8 44 0f             	mov    ax,0xf44
     f97:	0e                   	push   cs
     f98:	50                   	push   ax
     f99:	55                   	push   bp
     f9a:	ff 36 58 18          	push   WORD PTR ds:0x1858
     f9e:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     fa2:	ff 36 8c 18          	push   WORD PTR ds:0x188c
     fa6:	bf f2 09             	mov    di,0x9f2
     fa9:	1e                   	push   ds
     faa:	57                   	push   di
     fab:	9a 13 10 00 00       	call   0x0:0x1013
     fb0:	50                   	push   ax
     fb1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     fb4:	06                   	push   es
     fb5:	57                   	push   di
     fb6:	9a 04 61 dc 0f       	call   0xfdc:0x6104
     fbb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     fbe:	06                   	push   es
     fbf:	57                   	push   di
     fc0:	26 c4 3d             	les    di,DWORD PTR es:[di]
     fc3:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
     fc7:	50                   	push   ax
     fc8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     fcb:	06                   	push   es
     fcc:	57                   	push   di
     fcd:	26 c4 3d             	les    di,DWORD PTR es:[di]
     fd0:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
     fd4:	50                   	push   ax
     fd5:	b0 01                	mov    al,0x1
     fd7:	50                   	push   ax
     fd8:	b8 86 09             	mov    ax,0x986
     fdb:	ba e3 0f             	mov    dx,0xfe3
     fde:	52                   	push   dx
     fdf:	50                   	push   ax
     fe0:	9a 45 69 07 10       	call   0x1007:0x6945
     fe5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fe8:	26 89 85 41 01       	mov    WORD PTR es:[di+0x141],ax
     fed:	26 89 95 43 01       	mov    WORD PTR es:[di+0x143],dx
     ff2:	ff 76 fe             	push   WORD PTR [bp-0x2]
     ff5:	ff 76 fc             	push   WORD PTR [bp-0x4]
     ff8:	68 ff 00             	push   0xff
     ffb:	6a ff                	push   0xffff
     ffd:	26 c4 bd 41 01       	les    di,DWORD PTR es:[di+0x141]
    1002:	06                   	push   es
    1003:	57                   	push   di
    1004:	9a a3 6b 20 10       	call   0x1020:0x6ba3
    1009:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    100d:	bf fb 09             	mov    di,0x9fb
    1010:	1e                   	push   ds
    1011:	57                   	push   di
    1012:	9a 46 10 00 00       	call   0x0:0x1046
    1017:	50                   	push   ax
    1018:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    101b:	06                   	push   es
    101c:	57                   	push   di
    101d:	9a 04 61 3a 10       	call   0x103a:0x6104
    1022:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1025:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1028:	68 ff 00             	push   0xff
    102b:	6a ff                	push   0xffff
    102d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1030:	26 c4 bd 41 01       	les    di,DWORD PTR es:[di+0x141]
    1035:	06                   	push   es
    1036:	57                   	push   di
    1037:	9a a3 6b 53 10       	call   0x1053:0x6ba3
    103c:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    1040:	bf 02 0a             	mov    di,0xa02
    1043:	1e                   	push   ds
    1044:	57                   	push   di
    1045:	9a ff ff 00 00       	call   0x0:0xffff
    104a:	50                   	push   ax
    104b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    104e:	06                   	push   es
    104f:	57                   	push   di
    1050:	9a 04 61 6d 10       	call   0x106d:0x6104
    1055:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1058:	ff 76 fc             	push   WORD PTR [bp-0x4]
    105b:	68 ff 00             	push   0xff
    105e:	6a ff                	push   0xffff
    1060:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1063:	26 c4 bd 41 01       	les    di,DWORD PTR es:[di+0x141]
    1068:	06                   	push   es
    1069:	57                   	push   di
    106a:	9a a3 6b 1b 11       	call   0x111b:0x6ba3
    106f:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1073:	83 c4 06             	add    sp,0x6
    1076:	b8 86 10             	mov    ax,0x1086
    1079:	0e                   	push   cs
    107a:	50                   	push   ax
    107b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    107e:	06                   	push   es
    107f:	57                   	push   di
    1080:	9a 7f 1f 9f 11       	call   0x119f:0x1f7f
    1085:	cb                   	retf
    1086:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1089:	26 c6 85 55 01 01    	mov    BYTE PTR es:[di+0x155],0x1
    108f:	26 c6 85 56 01 01    	mov    BYTE PTR es:[di+0x156],0x1
    1095:	26 c6 85 79 02 01    	mov    BYTE PTR es:[di+0x279],0x1
    109b:	26 c7 85 53 01 fd 0c 	mov    WORD PTR es:[di+0x153],0xcfd
    10a2:	e8 e5 fb             	call   0xc8a
    10a5:	6a 01                	push   0x1
    10a7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10aa:	06                   	push   es
    10ab:	57                   	push   di
    10ac:	9a 4c 75 bc 10       	call   0x10bc:0x754c
    10b1:	68 8f 0e             	push   0xe8f
    10b4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10b7:	06                   	push   es
    10b8:	57                   	push   di
    10b9:	9a 7d 73 ca 10       	call   0x10ca:0x737d
    10be:	6a 00                	push   0x0
    10c0:	6a 02                	push   0x2
    10c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10c5:	06                   	push   es
    10c6:	57                   	push   di
    10c7:	9a 26 74 d8 10       	call   0x10d8:0x7426
    10cc:	6a 00                	push   0x0
    10ce:	6a 02                	push   0x2
    10d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10d3:	06                   	push   es
    10d4:	57                   	push   di
    10d5:	9a 1b 70 76 11       	call   0x1176:0x701b
    10da:	ff 76 08             	push   WORD PTR [bp+0x8]
    10dd:	ff 76 06             	push   WORD PTR [bp+0x6]
    10e0:	b0 01                	mov    al,0x1
    10e2:	50                   	push   ax
    10e3:	b8 22 00             	mov    ax,0x22
    10e6:	ba ee 10             	mov    dx,0x10ee
    10e9:	52                   	push   dx
    10ea:	50                   	push   ax
    10eb:	9a f1 08 37 11       	call   0x1137:0x8f1
    10f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10f3:	26 89 85 5d 01       	mov    WORD PTR es:[di+0x15d],ax
    10f8:	26 89 95 5f 01       	mov    WORD PTR es:[di+0x15f],dx
    10fd:	6a ff                	push   0xffff
    10ff:	6a fa                	push   0xfffa
    1101:	06                   	push   es
    1102:	57                   	push   di
    1103:	9a d5 1e 12 11       	call   0x1112:0x1ed5
    1108:	6a 00                	push   0x0
    110a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    110d:	06                   	push   es
    110e:	57                   	push   di
    110f:	9a 32 1f 00 14       	call   0x1400:0x1f32
    1114:	b0 01                	mov    al,0x1
    1116:	50                   	push   ax
    1117:	b8 10 03             	mov    ax,0x310
    111a:	ba 22 11             	mov    dx,0x1122
    111d:	52                   	push   dx
    111e:	50                   	push   ax
    111f:	9a 96 0e e7 12       	call   0x12e7:0xe96
    1124:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1127:	26 89 85 45 01       	mov    WORD PTR es:[di+0x145],ax
    112c:	26 89 95 47 01       	mov    WORD PTR es:[di+0x147],dx
    1131:	06                   	push   es
    1132:	57                   	push   di
    1133:	b8 92 1e             	mov    ax,0x1e92
    1136:	ba 4d 12             	mov    dx,0x124d
    1139:	26 c4 bd 45 01       	les    di,DWORD PTR es:[di+0x145]
    113e:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1142:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1146:	26 8f 45 08          	pop    WORD PTR es:[di+0x8]
    114a:	26 8f 45 0a          	pop    WORD PTR es:[di+0xa]
    114e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1151:	26 c7 85 49 01 f0 ff 	mov    WORD PTR es:[di+0x149],0xfff0
    1158:	26 c7 85 4b 01 ff ff 	mov    WORD PTR es:[di+0x14b],0xffff
    115f:	26 c6 85 40 01 00    	mov    BYTE PTR es:[di+0x140],0x0
    1165:	26 c6 85 4f 01 01    	mov    BYTE PTR es:[di+0x14f],0x1
    116b:	26 c6 85 59 01 01    	mov    BYTE PTR es:[di+0x159],0x1
    1171:	06                   	push   es
    1172:	57                   	push   di
    1173:	9a 32 25 c7 11       	call   0x11c7:0x2532
    1178:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    117c:	74 07                	je     0x1185
    117e:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1182:	83 c4 06             	add    sp,0x6
    1185:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1188:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    118b:	c9                   	leave
    118c:	ca 0a 00             	retf   0xa
    118f:	55                   	push   bp
    1190:	89 e5                	mov    bp,sp
    1192:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1195:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    119a:	06                   	push   es
    119b:	57                   	push   di
    119c:	9a 7f 1f ba 11       	call   0x11ba:0x1f7f
    11a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11a4:	31 c0                	xor    ax,ax
    11a6:	26 89 85 5d 01       	mov    WORD PTR es:[di+0x15d],ax
    11ab:	26 89 85 5f 01       	mov    WORD PTR es:[di+0x15f],ax
    11b0:	26 c4 bd 41 01       	les    di,DWORD PTR es:[di+0x141]
    11b5:	06                   	push   es
    11b6:	57                   	push   di
    11b7:	9a 7f 1f d5 11       	call   0x11d5:0x1f7f
    11bc:	31 c0                	xor    ax,ax
    11be:	50                   	push   ax
    11bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11c2:	06                   	push   es
    11c3:	57                   	push   di
    11c4:	9a a0 1f 96 13       	call   0x1396:0x1fa0
    11c9:	e8 f2 fa             	call   0xcbe
    11cc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    11d0:	74 05                	je     0x11d7
    11d2:	9a 0f 20 05 17       	call   0x1705:0x200f
    11d7:	c9                   	leave
    11d8:	ca 06 00             	retf   0x6
    11db:	c8 0c 01 00          	enter  0x10c,0x0
    11df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11e2:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    11e7:	06                   	push   es
    11e8:	57                   	push   di
    11e9:	9a fa 76 fd 11       	call   0x11fd:0x76fa
    11ee:	89 c7                	mov    di,ax
    11f0:	8e c2                	mov    es,dx
    11f2:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    11f5:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    11f8:	06                   	push   es
    11f9:	57                   	push   di
    11fa:	9a 32 3b 1d 12       	call   0x121d:0x3b32
    11ff:	48                   	dec    ax
    1200:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1203:	31 c0                	xor    ax,ax
    1205:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1208:	7f 4d                	jg     0x1257
    120a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    120d:	eb 03                	jmp    0x1212
    120f:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1212:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1215:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1218:	06                   	push   es
    1219:	57                   	push   di
    121a:	9a 4b 3b 3e 12       	call   0x123e:0x3b4b
    121f:	89 c7                	mov    di,ax
    1221:	8e c2                	mov    es,dx
    1223:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    1226:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    1229:	26 80 7d 26 00       	cmp    BYTE PTR es:[di+0x26],0x0
    122e:	74 1f                	je     0x124f
    1230:	8d be f4 fe          	lea    di,[bp-0x10c]
    1234:	16                   	push   ss
    1235:	57                   	push   di
    1236:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    1239:	06                   	push   es
    123a:	57                   	push   di
    123b:	9a 1f 69 06 13       	call   0x1306:0x691f
    1240:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1243:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1248:	06                   	push   es
    1249:	57                   	push   di
    124a:	9a d5 09 a3 12       	call   0x12a3:0x9d5
    124f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1252:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1255:	75 b8                	jne    0x120f
    1257:	c9                   	leave
    1258:	ca 04 00             	retf   0x4
    125b:	55                   	push   bp
    125c:	89 e5                	mov    bp,sp
    125e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1261:	26 8b 85 73 01       	mov    ax,WORD PTR es:[di+0x173]
    1266:	09 c0                	or     ax,ax
    1268:	74 27                	je     0x1291
    126a:	ff 76 08             	push   WORD PTR [bp+0x8]
    126d:	ff 76 06             	push   WORD PTR [bp+0x6]
    1270:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    1273:	06                   	push   es
    1274:	57                   	push   di
    1275:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1278:	ff 76 0c             	push   WORD PTR [bp+0xc]
    127b:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    127e:	50                   	push   ax
    127f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1282:	26 ff b5 77 01       	push   WORD PTR es:[di+0x177]
    1287:	26 ff b5 75 01       	push   WORD PTR es:[di+0x175]
    128c:	26 ff 9d 71 01       	call   DWORD PTR es:[di+0x171]
    1291:	c9                   	leave
    1292:	ca 0e 00             	retf   0xe
    1295:	01 30                	add    WORD PTR [bx+si],si
    1297:	c8 0a 02 00          	enter  0x20a,0x0
    129b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    129e:	06                   	push   es
    129f:	57                   	push   di
    12a0:	9a 19 19 c6 12       	call   0x12c6:0x1919
    12a5:	48                   	dec    ax
    12a6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    12a9:	31 c0                	xor    ax,ax
    12ab:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    12ae:	7e 03                	jle    0x12b3
    12b0:	e9 22 01             	jmp    0x13d5
    12b3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    12b6:	eb 03                	jmp    0x12bb
    12b8:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    12bb:	ff 76 fe             	push   WORD PTR [bp-0x2]
    12be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12c1:	06                   	push   es
    12c2:	57                   	push   di
    12c3:	9a 33 19 df 13       	call   0x13df:0x1933
    12c8:	89 c7                	mov    di,ax
    12ca:	8e c2                	mov    es,dx
    12cc:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    12cf:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    12d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12d5:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    12d9:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    12dd:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    12e2:	06                   	push   es
    12e3:	57                   	push   di
    12e4:	9a 99 20 fb 12       	call   0x12fb:0x2099
    12e9:	bf 95 12             	mov    di,0x1295
    12ec:	0e                   	push   cs
    12ed:	57                   	push   di
    12ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12f1:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    12f6:	06                   	push   es
    12f7:	57                   	push   di
    12f8:	9a 03 20 30 13       	call   0x1330:0x2003
    12fd:	50                   	push   ax
    12fe:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1301:	06                   	push   es
    1302:	57                   	push   di
    1303:	9a 85 68 40 13       	call   0x1340:0x6885
    1308:	5a                   	pop    dx
    1309:	f7 e2                	mul    dx
    130b:	05 04 00             	add    ax,0x4
    130e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1311:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1314:	26 f6 85 53 01 04    	test   BYTE PTR es:[di+0x153],0x4
    131a:	74 62                	je     0x137e
    131c:	26 ff b5 47 01       	push   WORD PTR es:[di+0x147]
    1321:	26 ff b5 45 01       	push   WORD PTR es:[di+0x145]
    1326:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    132b:	06                   	push   es
    132c:	57                   	push   di
    132d:	9a 99 20 4f 13       	call   0x134f:0x2099
    1332:	8d be f6 fe          	lea    di,[bp-0x10a]
    1336:	16                   	push   ss
    1337:	57                   	push   di
    1338:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    133b:	06                   	push   es
    133c:	57                   	push   di
    133d:	9a d2 67 67 13       	call   0x1367:0x67d2
    1342:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1345:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    134a:	06                   	push   es
    134b:	57                   	push   di
    134c:	9a 03 20 76 13       	call   0x1376:0x2003
    1351:	05 04 00             	add    ax,0x4
    1354:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1357:	7e 25                	jle    0x137e
    1359:	8d be f6 fd          	lea    di,[bp-0x20a]
    135d:	16                   	push   ss
    135e:	57                   	push   di
    135f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1362:	06                   	push   es
    1363:	57                   	push   di
    1364:	9a d2 67 84 17       	call   0x1784:0x67d2
    1369:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    136c:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1371:	06                   	push   es
    1372:	57                   	push   di
    1373:	9a 03 20 6f 14       	call   0x146f:0x2003
    1378:	05 04 00             	add    ax,0x4
    137b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    137e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1381:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    1386:	30 e4                	xor    ah,ah
    1388:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    138b:	99                   	cwd
    138c:	52                   	push   dx
    138d:	50                   	push   ax
    138e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1391:	06                   	push   es
    1392:	57                   	push   di
    1393:	9a c9 70 c8 13       	call   0x13c8:0x70c9
    1398:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    139b:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    13a0:	30 e4                	xor    ah,ah
    13a2:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    13a5:	99                   	cwd
    13a6:	52                   	push   dx
    13a7:	50                   	push   ax
    13a8:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    13ab:	26 80 7d 23 00       	cmp    BYTE PTR es:[di+0x23],0x0
    13b0:	75 07                	jne    0x13b9
    13b2:	26 80 7d 24 00       	cmp    BYTE PTR es:[di+0x24],0x0
    13b7:	74 04                	je     0x13bd
    13b9:	b0 00                	mov    al,0x0
    13bb:	eb 02                	jmp    0x13bf
    13bd:	b0 01                	mov    al,0x1
    13bf:	50                   	push   ax
    13c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13c3:	06                   	push   es
    13c4:	57                   	push   di
    13c5:	9a 6f 75 90 14       	call   0x1490:0x756f
    13ca:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    13cd:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    13d0:	74 03                	je     0x13d5
    13d2:	e9 e3 fe             	jmp    0x12b8
    13d5:	c9                   	leave
    13d6:	ca 04 00             	retf   0x4
    13d9:	01 57 00             	add    WORD PTR [bx+0x0],dx
    13dc:	00 b0 15 e5          	add    BYTE PTR [bx+si-0x1aeb],dh
    13e0:	13 00                	adc    ax,WORD PTR [bx+si]
    13e2:	00 dc                	add    ah,bl
    13e4:	15 16 15             	adc    ax,0x1516
    13e7:	c8 02 00 00          	enter  0x2,0x0
    13eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ee:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    13f3:	74 03                	je     0x13f8
    13f5:	e9 ed 01             	jmp    0x15e5
    13f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13fb:	06                   	push   es
    13fc:	57                   	push   di
    13fd:	9a fa 64 3b 16       	call   0x163b:0x64fa
    1402:	08 c0                	or     al,al
    1404:	75 03                	jne    0x1409
    1406:	e9 dc 01             	jmp    0x15e5
    1409:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    140c:	26 80 bd 57 01 00    	cmp    BYTE PTR es:[di+0x157],0x0
    1412:	74 03                	je     0x1417
    1414:	e9 ce 01             	jmp    0x15e5
    1417:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    141a:	26 fe 85 57 01       	inc    BYTE PTR es:[di+0x157]
    141f:	b8 e1 13             	mov    ax,0x13e1
    1422:	0e                   	push   cs
    1423:	50                   	push   ax
    1424:	55                   	push   bp
    1425:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1429:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    142d:	26 c6 85 52 01 01    	mov    BYTE PTR es:[di+0x152],0x1
    1433:	b8 db 13             	mov    ax,0x13db
    1436:	0e                   	push   cs
    1437:	50                   	push   ax
    1438:	55                   	push   bp
    1439:	ff 36 58 18          	push   WORD PTR ds:0x1858
    143d:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1441:	31 c0                	xor    ax,ax
    1443:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1446:	26 c6 85 55 01 00    	mov    BYTE PTR es:[di+0x155],0x0
    144c:	26 f6 85 53 01 04    	test   BYTE PTR es:[di+0x153],0x4
    1452:	74 06                	je     0x145a
    1454:	26 c6 85 55 01 01    	mov    BYTE PTR es:[di+0x155],0x1
    145a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    145d:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    1461:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    1465:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    146a:	06                   	push   es
    146b:	57                   	push   di
    146c:	9a 99 20 83 14       	call   0x1483:0x2099
    1471:	bf d9 13             	mov    di,0x13d9
    1474:	0e                   	push   cs
    1475:	57                   	push   di
    1476:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1479:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    147e:	06                   	push   es
    147f:	57                   	push   di
    1480:	9a 4e 20 ca 14       	call   0x14ca:0x204e
    1485:	40                   	inc    ax
    1486:	40                   	inc    ax
    1487:	50                   	push   ax
    1488:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    148b:	06                   	push   es
    148c:	57                   	push   di
    148d:	9a b6 71 a9 14       	call   0x14a9:0x71b6
    1492:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1495:	26 f6 85 53 01 40    	test   BYTE PTR es:[di+0x153],0x40
    149b:	74 0e                	je     0x14ab
    149d:	26 8b 85 fc 00       	mov    ax,WORD PTR es:[di+0xfc]
    14a2:	40                   	inc    ax
    14a3:	50                   	push   ax
    14a4:	06                   	push   es
    14a5:	57                   	push   di
    14a6:	9a b6 71 f0 14       	call   0x14f0:0x71b6
    14ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14ae:	26 f6 85 53 01 04    	test   BYTE PTR es:[di+0x153],0x4
    14b4:	74 3c                	je     0x14f2
    14b6:	26 ff b5 47 01       	push   WORD PTR es:[di+0x147]
    14bb:	26 ff b5 45 01       	push   WORD PTR es:[di+0x145]
    14c0:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    14c5:	06                   	push   es
    14c6:	57                   	push   di
    14c7:	9a 99 20 e2 14       	call   0x14e2:0x2099
    14cc:	6a 00                	push   0x0
    14ce:	6a 00                	push   0x0
    14d0:	bf d9 13             	mov    di,0x13d9
    14d3:	0e                   	push   cs
    14d4:	57                   	push   di
    14d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14d8:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    14dd:	06                   	push   es
    14de:	57                   	push   di
    14df:	9a 4e 20 90 27       	call   0x2790:0x204e
    14e4:	05 04 00             	add    ax,0x4
    14e7:	50                   	push   ax
    14e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14eb:	06                   	push   es
    14ec:	57                   	push   di
    14ed:	9a a3 74 61 15       	call   0x1561:0x74a3
    14f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14f5:	26 c6 85 56 01 00    	mov    BYTE PTR es:[di+0x156],0x0
    14fb:	26 f6 85 53 01 08    	test   BYTE PTR es:[di+0x153],0x8
    1501:	74 06                	je     0x1509
    1503:	26 c6 85 56 01 01    	mov    BYTE PTR es:[di+0x156],0x1
    1509:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    150c:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1511:	06                   	push   es
    1512:	57                   	push   di
    1513:	9a 23 0b 3c 15       	call   0x153c:0xb23
    1518:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    151b:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1520:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    1525:	74 0d                	je     0x1534
    1527:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    152a:	06                   	push   es
    152b:	57                   	push   di
    152c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    152f:	26 ff 9d 9c 00       	call   DWORD PTR es:[di+0x9c]
    1534:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1537:	06                   	push   es
    1538:	57                   	push   di
    1539:	9a 19 19 95 15       	call   0x1595:0x1919
    153e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1541:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    1545:	75 05                	jne    0x154c
    1547:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    154c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    154f:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    1554:	30 e4                	xor    ah,ah
    1556:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    1559:	99                   	cwd
    155a:	52                   	push   dx
    155b:	50                   	push   ax
    155c:	06                   	push   es
    155d:	57                   	push   di
    155e:	9a 1b 70 73 15       	call   0x1573:0x701b
    1563:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1566:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    156b:	30 e4                	xor    ah,ah
    156d:	50                   	push   ax
    156e:	06                   	push   es
    156f:	57                   	push   di
    1570:	9a 32 72 8b 15       	call   0x158b:0x7232
    1575:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1578:	26 f6 85 53 01 08    	test   BYTE PTR es:[di+0x153],0x8
    157e:	74 0d                	je     0x158d
    1580:	6a 00                	push   0x0
    1582:	6a 00                	push   0x0
    1584:	6a 0b                	push   0xb
    1586:	06                   	push   es
    1587:	57                   	push   di
    1588:	9a c9 70 fb 15       	call   0x15fb:0x70c9
    158d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1590:	06                   	push   es
    1591:	57                   	push   di
    1592:	9a 1e 21 c2 15       	call   0x15c2:0x211e
    1597:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    159a:	06                   	push   es
    159b:	57                   	push   di
    159c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    159f:	26 ff 9d a0 00       	call   DWORD PTR es:[di+0xa0]
    15a4:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    15a8:	83 c4 06             	add    sp,0x6
    15ab:	b8 ba 15             	mov    ax,0x15ba
    15ae:	0e                   	push   cs
    15af:	50                   	push   ax
    15b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15b3:	26 c6 85 52 01 00    	mov    BYTE PTR es:[di+0x152],0x0
    15b9:	cb                   	retf
    15ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15bd:	06                   	push   es
    15be:	57                   	push   di
    15bf:	9a 11 1f 12 16       	call   0x1612:0x1f11
    15c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15c7:	06                   	push   es
    15c8:	57                   	push   di
    15c9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    15cc:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    15d0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    15d4:	83 c4 06             	add    sp,0x6
    15d7:	b8 e5 15             	mov    ax,0x15e5
    15da:	0e                   	push   cs
    15db:	50                   	push   ax
    15dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15df:	26 fe 8d 57 01       	dec    BYTE PTR es:[di+0x157]
    15e4:	cb                   	retf
    15e5:	c9                   	leave
    15e6:	ca 04 00             	retf   0x4
    15e9:	c8 02 00 00          	enter  0x2,0x0
    15ed:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    15f1:	75 0a                	jne    0x15fd
    15f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    15f6:	06                   	push   es
    15f7:	57                   	push   di
    15f8:	9a 32 25 2a 16       	call   0x162a:0x2532
    15fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1600:	06                   	push   es
    1601:	57                   	push   di
    1602:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1605:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    160a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    160d:	06                   	push   es
    160e:	57                   	push   di
    160f:	9a 68 20 52 16       	call   0x1652:0x2068
    1614:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1618:	74 12                	je     0x162c
    161a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    161d:	26 f6 85 53 01 02    	test   BYTE PTR es:[di+0x153],0x2
    1623:	74 07                	je     0x162c
    1625:	06                   	push   es
    1626:	57                   	push   di
    1627:	9a 49 25 3f 1a       	call   0x1a3f:0x2549
    162c:	c9                   	leave
    162d:	ca 06 00             	retf   0x6
    1630:	55                   	push   bp
    1631:	89 e5                	mov    bp,sp
    1633:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1636:	06                   	push   es
    1637:	57                   	push   di
    1638:	9a 88 3c 11 1a       	call   0x1a11:0x3c88
    163d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1640:	06                   	push   es
    1641:	57                   	push   di
    1642:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1645:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    164a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    164d:	06                   	push   es
    164e:	57                   	push   di
    164f:	9a 68 20 97 16       	call   0x1697:0x2068
    1654:	c9                   	leave
    1655:	ca 04 00             	retf   0x4
    1658:	c8 04 00 00          	enter  0x4,0x0
    165c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    165f:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1664:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1668:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    166c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    166f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1672:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1675:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1678:	c9                   	leave
    1679:	ca 04 00             	retf   0x4
    167c:	c8 02 00 00          	enter  0x2,0x0
    1680:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1683:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1688:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    168d:	74 38                	je     0x16c7
    168f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1692:	06                   	push   es
    1693:	57                   	push   di
    1694:	9a 19 19 a9 16       	call   0x16a9:0x1919
    1699:	09 c0                	or     ax,ax
    169b:	7e 2a                	jle    0x16c7
    169d:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    16a0:	50                   	push   ax
    16a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16a4:	06                   	push   es
    16a5:	57                   	push   di
    16a6:	9a da 19 b4 16       	call   0x16b4:0x19da
    16ab:	50                   	push   ax
    16ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16af:	06                   	push   es
    16b0:	57                   	push   di
    16b1:	9a 33 19 e8 16       	call   0x16e8:0x1933
    16b6:	89 c7                	mov    di,ax
    16b8:	8e c2                	mov    es,dx
    16ba:	06                   	push   es
    16bb:	57                   	push   di
    16bc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16bf:	26 ff 5d 70          	call   DWORD PTR es:[di+0x70]
    16c3:	08 c0                	or     al,al
    16c5:	75 04                	jne    0x16cb
    16c7:	b0 00                	mov    al,0x0
    16c9:	eb 02                	jmp    0x16cd
    16cb:	b0 01                	mov    al,0x1
    16cd:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    16d0:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    16d3:	c9                   	leave
    16d4:	ca 06 00             	retf   0x6
    16d7:	c8 02 00 00          	enter  0x2,0x0
    16db:	31 c0                	xor    ax,ax
    16dd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    16e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16e3:	06                   	push   es
    16e4:	57                   	push   di
    16e5:	9a 19 19 f6 16       	call   0x16f6:0x1919
    16ea:	09 c0                	or     ax,ax
    16ec:	7e 32                	jle    0x1720
    16ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16f1:	06                   	push   es
    16f2:	57                   	push   di
    16f3:	9a 8f 19 13 17       	call   0x1713:0x198f
    16f8:	52                   	push   dx
    16f9:	50                   	push   ax
    16fa:	bf 6f 05             	mov    di,0x56f
    16fd:	b8 ff ff             	mov    ax,0xffff
    1700:	50                   	push   ax
    1701:	57                   	push   di
    1702:	9a 55 22 4f 18       	call   0x184f:0x2255
    1707:	08 c0                	or     al,al
    1709:	74 15                	je     0x1720
    170b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    170e:	06                   	push   es
    170f:	57                   	push   di
    1710:	9a 8f 19 60 17       	call   0x1760:0x198f
    1715:	89 c7                	mov    di,ax
    1717:	8e c2                	mov    es,dx
    1719:	26 8b 45 2a          	mov    ax,WORD PTR es:[di+0x2a]
    171d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1720:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1723:	c9                   	leave
    1724:	ca 04 00             	retf   0x4
    1727:	c8 02 00 00          	enter  0x2,0x0
    172b:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    172f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1732:	26 80 bd 4d 01 00    	cmp    BYTE PTR es:[di+0x14d],0x0
    1738:	74 03                	je     0x173d
    173a:	e9 80 00             	jmp    0x17bd
    173d:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1742:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    1747:	74 74                	je     0x17bd
    1749:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    174c:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1751:	26 80 7d 10 00       	cmp    BYTE PTR es:[di+0x10],0x0
    1756:	75 65                	jne    0x17bd
    1758:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    175b:	06                   	push   es
    175c:	57                   	push   di
    175d:	9a 19 19 6e 17       	call   0x176e:0x1919
    1762:	09 c0                	or     ax,ax
    1764:	7e 57                	jle    0x17bd
    1766:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1769:	06                   	push   es
    176a:	57                   	push   di
    176b:	9a da 19 79 17       	call   0x1779:0x19da
    1770:	50                   	push   ax
    1771:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1774:	06                   	push   es
    1775:	57                   	push   di
    1776:	9a 33 19 bb 17       	call   0x17bb:0x1933
    177b:	89 c7                	mov    di,ax
    177d:	8e c2                	mov    es,dx
    177f:	06                   	push   es
    1780:	57                   	push   di
    1781:	9a ca 65 97 17       	call   0x1797:0x65ca
    1786:	08 c0                	or     al,al
    1788:	74 33                	je     0x17bd
    178a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    178d:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1792:	06                   	push   es
    1793:	57                   	push   di
    1794:	9a 99 78 42 18       	call   0x1842:0x7899
    1799:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    179c:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    17a1:	26 8a 45 12          	mov    al,BYTE PTR es:[di+0x12]
    17a5:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    17a8:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    17ac:	74 0f                	je     0x17bd
    17ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17b1:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    17b6:	06                   	push   es
    17b7:	57                   	push   di
    17b8:	9a 5a 0b e6 17       	call   0x17e6:0xb5a
    17bd:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    17c0:	c9                   	leave
    17c1:	ca 04 00             	retf   0x4
    17c4:	c8 00 01 00          	enter  0x100,0x0
    17c8:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    17cb:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    17cf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17d2:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    17d7:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    17dc:	74 73                	je     0x1851
    17de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17e1:	06                   	push   es
    17e2:	57                   	push   di
    17e3:	9a 19 19 37 18       	call   0x1837:0x1919
    17e8:	99                   	cwd
    17e9:	52                   	push   dx
    17ea:	50                   	push   ax
    17eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17ee:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    17f3:	30 e4                	xor    ah,ah
    17f5:	31 d2                	xor    dx,dx
    17f7:	8b c8                	mov    cx,ax
    17f9:	8b da                	mov    bx,dx
    17fb:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    17fe:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    1801:	2b c1                	sub    ax,cx
    1803:	1b d3                	sbb    dx,bx
    1805:	59                   	pop    cx
    1806:	5b                   	pop    bx
    1807:	3b d3                	cmp    dx,bx
    1809:	7c 06                	jl     0x1811
    180b:	7f 44                	jg     0x1851
    180d:	3b c1                	cmp    ax,cx
    180f:	73 40                	jae    0x1851
    1811:	8d be 00 ff          	lea    di,[bp-0x100]
    1815:	16                   	push   ss
    1816:	57                   	push   di
    1817:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    181a:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    181f:	30 e4                	xor    ah,ah
    1821:	31 d2                	xor    dx,dx
    1823:	8b c8                	mov    cx,ax
    1825:	8b da                	mov    bx,dx
    1827:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    182a:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    182d:	2b c1                	sub    ax,cx
    182f:	1b d3                	sbb    dx,bx
    1831:	50                   	push   ax
    1832:	06                   	push   es
    1833:	57                   	push   di
    1834:	9a 33 19 77 18       	call   0x1877:0x1933
    1839:	89 c7                	mov    di,ax
    183b:	8e c2                	mov    es,dx
    183d:	06                   	push   es
    183e:	57                   	push   di
    183f:	9a b2 68 d3 18       	call   0x18d3:0x68b2
    1844:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    1847:	06                   	push   es
    1848:	57                   	push   di
    1849:	68 ff 00             	push   0xff
    184c:	9a e7 17 e0 18       	call   0x18e0:0x17e7
    1851:	c9                   	leave
    1852:	ca 0c 00             	retf   0xc
    1855:	c8 00 01 00          	enter  0x100,0x0
    1859:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    185c:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1860:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1863:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1868:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    186d:	74 73                	je     0x18e2
    186f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1872:	06                   	push   es
    1873:	57                   	push   di
    1874:	9a 19 19 c8 18       	call   0x18c8:0x1919
    1879:	99                   	cwd
    187a:	52                   	push   dx
    187b:	50                   	push   ax
    187c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    187f:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    1884:	30 e4                	xor    ah,ah
    1886:	31 d2                	xor    dx,dx
    1888:	8b c8                	mov    cx,ax
    188a:	8b da                	mov    bx,dx
    188c:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    188f:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    1892:	2b c1                	sub    ax,cx
    1894:	1b d3                	sbb    dx,bx
    1896:	59                   	pop    cx
    1897:	5b                   	pop    bx
    1898:	3b d3                	cmp    dx,bx
    189a:	7c 06                	jl     0x18a2
    189c:	7f 44                	jg     0x18e2
    189e:	3b c1                	cmp    ax,cx
    18a0:	73 40                	jae    0x18e2
    18a2:	8d be 00 ff          	lea    di,[bp-0x100]
    18a6:	16                   	push   ss
    18a7:	57                   	push   di
    18a8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18ab:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    18b0:	30 e4                	xor    ah,ah
    18b2:	31 d2                	xor    dx,dx
    18b4:	8b c8                	mov    cx,ax
    18b6:	8b da                	mov    bx,dx
    18b8:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    18bb:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    18be:	2b c1                	sub    ax,cx
    18c0:	1b d3                	sbb    dx,bx
    18c2:	50                   	push   ax
    18c3:	06                   	push   es
    18c4:	57                   	push   di
    18c5:	9a 33 19 47 19       	call   0x1947:0x1933
    18ca:	89 c7                	mov    di,ax
    18cc:	8e c2                	mov    es,dx
    18ce:	06                   	push   es
    18cf:	57                   	push   di
    18d0:	9a cf 68 6f 19       	call   0x196f:0x68cf
    18d5:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    18d8:	06                   	push   es
    18d9:	57                   	push   di
    18da:	68 ff 00             	push   0xff
    18dd:	9a e7 17 f6 18       	call   0x18f6:0x17e7
    18e2:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
    18e5:	06                   	push   es
    18e6:	57                   	push   di
    18e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18ea:	81 c7 79 01          	add    di,0x179
    18ee:	06                   	push   es
    18ef:	57                   	push   di
    18f0:	68 ff 00             	push   0xff
    18f3:	9a e7 17 13 19       	call   0x1913:0x17e7
    18f8:	c9                   	leave
    18f9:	ca 0c 00             	retf   0xc
    18fc:	55                   	push   bp
    18fd:	89 e5                	mov    bp,sp
    18ff:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1902:	06                   	push   es
    1903:	57                   	push   di
    1904:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1907:	81 c7 79 01          	add    di,0x179
    190b:	06                   	push   es
    190c:	57                   	push   di
    190d:	68 ff 00             	push   0xff
    1910:	9a e7 17 4f 1b       	call   0x1b4f:0x17e7
    1915:	c9                   	leave
    1916:	ca 10 00             	retf   0x10
    1919:	c8 02 00 00          	enter  0x2,0x0
    191d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1920:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1925:	26 8b 45 18          	mov    ax,WORD PTR es:[di+0x18]
    1929:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    192c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    192f:	c9                   	leave
    1930:	ca 04 00             	retf   0x4
    1933:	c8 04 00 00          	enter  0x4,0x0
    1937:	ff 76 0a             	push   WORD PTR [bp+0xa]
    193a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    193d:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1942:	06                   	push   es
    1943:	57                   	push   di
    1944:	9a 92 09 a3 19       	call   0x19a3:0x992
    1949:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    194c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    194f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1952:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1955:	c9                   	leave
    1956:	ca 06 00             	retf   0x6
    1959:	55                   	push   bp
    195a:	89 e5                	mov    bp,sp
    195c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    195f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1962:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1965:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    196a:	06                   	push   es
    196b:	57                   	push   di
    196c:	9a 31 77 a8 1b       	call   0x1ba8:0x7731
    1971:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1974:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1979:	26 8a 45 11          	mov    al,BYTE PTR es:[di+0x11]
    197d:	50                   	push   ax
    197e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1981:	06                   	push   es
    1982:	57                   	push   di
    1983:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1986:	26 ff 9d a4 00       	call   DWORD PTR es:[di+0xa4]
    198b:	c9                   	leave
    198c:	ca 08 00             	retf   0x8
    198f:	c8 04 00 00          	enter  0x4,0x0
    1993:	31 c0                	xor    ax,ax
    1995:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1998:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    199b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    199e:	06                   	push   es
    199f:	57                   	push   di
    19a0:	9a 19 19 ae 19       	call   0x19ae:0x1919
    19a5:	50                   	push   ax
    19a6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a9:	06                   	push   es
    19aa:	57                   	push   di
    19ab:	9a da 19 bd 19       	call   0x19bd:0x19da
    19b0:	5a                   	pop    dx
    19b1:	3b c2                	cmp    ax,dx
    19b3:	7d 1b                	jge    0x19d0
    19b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19b8:	06                   	push   es
    19b9:	57                   	push   di
    19ba:	9a da 19 c8 19       	call   0x19c8:0x19da
    19bf:	50                   	push   ax
    19c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19c3:	06                   	push   es
    19c4:	57                   	push   di
    19c5:	9a 33 19 21 1a       	call   0x1a21:0x1933
    19ca:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    19cd:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    19d0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    19d3:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    19d6:	c9                   	leave
    19d7:	ca 04 00             	retf   0x4
    19da:	c8 02 00 00          	enter  0x2,0x0
    19de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19e1:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    19e6:	30 e4                	xor    ah,ah
    19e8:	31 d2                	xor    dx,dx
    19ea:	8b c8                	mov    cx,ax
    19ec:	8b da                	mov    bx,dx
    19ee:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    19f3:	26 8b 95 f4 00       	mov    dx,WORD PTR es:[di+0xf4]
    19f8:	2b c1                	sub    ax,cx
    19fa:	1b d3                	sbb    dx,bx
    19fc:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    19ff:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1a02:	c9                   	leave
    1a03:	ca 04 00             	retf   0x4
    1a06:	55                   	push   bp
    1a07:	89 e5                	mov    bp,sp
    1a09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a0c:	06                   	push   es
    1a0d:	57                   	push   di
    1a0e:	9a fa 64 49 1a       	call   0x1a49:0x64fa
    1a13:	08 c0                	or     al,al
    1a15:	75 02                	jne    0x1a19
    1a17:	eb 48                	jmp    0x1a61
    1a19:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a1c:	06                   	push   es
    1a1d:	57                   	push   di
    1a1e:	9a 1e 21 2b 1a       	call   0x1a2b:0x211e
    1a23:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a26:	06                   	push   es
    1a27:	57                   	push   di
    1a28:	9a 68 20 35 1a       	call   0x1a35:0x2068
    1a2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a30:	06                   	push   es
    1a31:	57                   	push   di
    1a32:	9a 11 1f cc 1a       	call   0x1acc:0x1f11
    1a37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a3a:	06                   	push   es
    1a3b:	57                   	push   di
    1a3c:	9a 9f 25 84 1a       	call   0x1a84:0x259f
    1a41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a44:	06                   	push   es
    1a45:	57                   	push   di
    1a46:	9a b9 62 96 1a       	call   0x1a96:0x62b9
    1a4b:	50                   	push   ax
    1a4c:	6a 00                	push   0x0
    1a4e:	6a 00                	push   0x0
    1a50:	9a 9c 1c 00 00       	call   0x0:0x1c9c
    1a55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a58:	06                   	push   es
    1a59:	57                   	push   di
    1a5a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a5d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1a61:	c9                   	leave
    1a62:	ca 04 00             	retf   0x4
    1a65:	55                   	push   bp
    1a66:	89 e5                	mov    bp,sp
    1a68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a6b:	26 f6 85 53 01 08    	test   BYTE PTR es:[di+0x153],0x8
    1a71:	74 13                	je     0x1a86
    1a73:	6a 00                	push   0x0
    1a75:	6a 00                	push   0x0
    1a77:	26 8b 85 5b 01       	mov    ax,WORD PTR es:[di+0x15b]
    1a7c:	99                   	cwd
    1a7d:	52                   	push   dx
    1a7e:	50                   	push   ax
    1a7f:	06                   	push   es
    1a80:	57                   	push   di
    1a81:	9a 3b 48 43 1b       	call   0x1b43:0x483b
    1a86:	c9                   	leave
    1a87:	ca 04 00             	retf   0x4
    1a8a:	c8 0c 01 00          	enter  0x10c,0x0
    1a8e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a91:	06                   	push   es
    1a92:	57                   	push   di
    1a93:	9a fa 64 59 1b       	call   0x1b59:0x64fa
    1a98:	08 c0                	or     al,al
    1a9a:	75 03                	jne    0x1a9f
    1a9c:	e9 40 01             	jmp    0x1bdf
    1a9f:	31 c0                	xor    ax,ax
    1aa1:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1aa4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1aa7:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1aaa:	75 18                	jne    0x1ac4
    1aac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1aaf:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1ab4:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1ab9:	2d 01 00             	sub    ax,0x1
    1abc:	83 da 00             	sbb    dx,0x0
    1abf:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1ac2:	eb 44                	jmp    0x1b08
    1ac4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ac7:	06                   	push   es
    1ac8:	57                   	push   di
    1ac9:	9a 19 19 ec 1a       	call   0x1aec:0x1919
    1ace:	48                   	dec    ax
    1acf:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    1ad2:	31 c0                	xor    ax,ax
    1ad4:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1ad7:	7f 29                	jg     0x1b02
    1ad9:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1adc:	eb 03                	jmp    0x1ae1
    1ade:	ff 46 f6             	inc    WORD PTR [bp-0xa]
    1ae1:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1ae4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ae7:	06                   	push   es
    1ae8:	57                   	push   di
    1ae9:	9a 33 19 78 1b       	call   0x1b78:0x1933
    1aee:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    1af1:	75 07                	jne    0x1afa
    1af3:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    1af6:	75 02                	jne    0x1afa
    1af8:	eb 08                	jmp    0x1b02
    1afa:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1afd:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1b00:	75 dc                	jne    0x1ade
    1b02:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1b05:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1b08:	8d 7e ec             	lea    di,[bp-0x14]
    1b0b:	16                   	push   ss
    1b0c:	57                   	push   di
    1b0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b10:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    1b15:	30 e4                	xor    ah,ah
    1b17:	03 46 f6             	add    ax,WORD PTR [bp-0xa]
    1b1a:	99                   	cwd
    1b1b:	52                   	push   dx
    1b1c:	50                   	push   ax
    1b1d:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1b22:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    1b27:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    1b2c:	30 e4                	xor    ah,ah
    1b2e:	03 46 f4             	add    ax,WORD PTR [bp-0xc]
    1b31:	99                   	cwd
    1b32:	52                   	push   dx
    1b33:	50                   	push   ax
    1b34:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1b39:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    1b3e:	06                   	push   es
    1b3f:	57                   	push   di
    1b40:	9a b3 23 c2 1b       	call   0x1bc2:0x23b3
    1b45:	8d 7e f8             	lea    di,[bp-0x8]
    1b48:	16                   	push   ss
    1b49:	57                   	push   di
    1b4a:	6a 08                	push   0x8
    1b4c:	9a 1b 16 b6 1b       	call   0x1bb6:0x161b
    1b51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b54:	06                   	push   es
    1b55:	57                   	push   di
    1b56:	9a b9 62 93 1c       	call   0x1c93:0x62b9
    1b5b:	50                   	push   ax
    1b5c:	8d 7e f8             	lea    di,[bp-0x8]
    1b5f:	16                   	push   ss
    1b60:	57                   	push   di
    1b61:	6a 00                	push   0x0
    1b63:	9a b3 1c 00 00       	call   0x0:0x1cb3
    1b68:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1b6b:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1b6e:	74 14                	je     0x1b84
    1b70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b73:	06                   	push   es
    1b74:	57                   	push   di
    1b75:	9a 8f 19 92 1b       	call   0x1b92:0x198f
    1b7a:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    1b7d:	75 60                	jne    0x1bdf
    1b7f:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    1b82:	75 5b                	jne    0x1bdf
    1b84:	8d be f4 fe          	lea    di,[bp-0x10c]
    1b88:	16                   	push   ss
    1b89:	57                   	push   di
    1b8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b8d:	06                   	push   es
    1b8e:	57                   	push   di
    1b8f:	9a da 19 9d 1b       	call   0x1b9d:0x19da
    1b94:	50                   	push   ax
    1b95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b98:	06                   	push   es
    1b99:	57                   	push   di
    1b9a:	9a 33 19 e7 1b       	call   0x1be7:0x1933
    1b9f:	89 c7                	mov    di,ax
    1ba1:	8e c2                	mov    es,dx
    1ba3:	06                   	push   es
    1ba4:	57                   	push   di
    1ba5:	9a cf 68 0b 1f       	call   0x1f0b:0x68cf
    1baa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bad:	81 c7 79 01          	add    di,0x179
    1bb1:	06                   	push   es
    1bb2:	57                   	push   di
    1bb3:	9a be 18 30 1c       	call   0x1c30:0x18be
    1bb8:	74 25                	je     0x1bdf
    1bba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bbd:	06                   	push   es
    1bbe:	57                   	push   di
    1bbf:	9a 9f 25 dd 1b       	call   0x1bdd:0x259f
    1bc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bc7:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    1bcc:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    1bd1:	74 0c                	je     0x1bdf
    1bd3:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    1bd8:	06                   	push   es
    1bd9:	57                   	push   di
    1bda:	9a fb 1b 24 1c       	call   0x1c24:0x1bfb
    1bdf:	c9                   	leave
    1be0:	ca 08 00             	retf   0x8
    1be3:	00 00                	add    BYTE PTR [bx+si],al
    1be5:	6f                   	outs   dx,WORD PTR ds:[si]
    1be6:	1e                   	push   ds
    1be7:	3a 1c                	cmp    bl,BYTE PTR [si]
    1be9:	c8 1a 00 00          	enter  0x1a,0x0
    1bed:	8d 7e e6             	lea    di,[bp-0x1a]
    1bf0:	16                   	push   ss
    1bf1:	57                   	push   di
    1bf2:	6a 00                	push   0x0
    1bf4:	6a 00                	push   0x0
    1bf6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bf9:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1bfe:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    1c03:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1c08:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1c0d:	2d 01 00             	sub    ax,0x1
    1c10:	83 da 00             	sbb    dx,0x0
    1c13:	52                   	push   dx
    1c14:	50                   	push   ax
    1c15:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1c1a:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    1c1f:	06                   	push   es
    1c20:	57                   	push   di
    1c21:	9a b3 23 7d 1c       	call   0x1c7d:0x23b3
    1c26:	8d 7e f8             	lea    di,[bp-0x8]
    1c29:	16                   	push   ss
    1c2a:	57                   	push   di
    1c2b:	6a 08                	push   0x8
    1c2d:	9a 1b 16 89 1c       	call   0x1c89:0x161b
    1c32:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c35:	06                   	push   es
    1c36:	57                   	push   di
    1c37:	9a 68 20 44 1c       	call   0x1c44:0x2068
    1c3c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c3f:	06                   	push   es
    1c40:	57                   	push   di
    1c41:	9a 11 1f d5 1e       	call   0x1ed5:0x1f11
    1c46:	8d 7e e6             	lea    di,[bp-0x1a]
    1c49:	16                   	push   ss
    1c4a:	57                   	push   di
    1c4b:	6a 00                	push   0x0
    1c4d:	6a 00                	push   0x0
    1c4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c52:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1c57:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    1c5c:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1c61:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1c66:	2d 01 00             	sub    ax,0x1
    1c69:	83 da 00             	sbb    dx,0x0
    1c6c:	52                   	push   dx
    1c6d:	50                   	push   ax
    1c6e:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1c73:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    1c78:	06                   	push   es
    1c79:	57                   	push   di
    1c7a:	9a b3 23 df 1c       	call   0x1cdf:0x23b3
    1c7f:	8d 7e f0             	lea    di,[bp-0x10]
    1c82:	16                   	push   ss
    1c83:	57                   	push   di
    1c84:	6a 08                	push   0x8
    1c86:	9a 1b 16 16 1d       	call   0x1d16:0x161b
    1c8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c8e:	06                   	push   es
    1c8f:	57                   	push   di
    1c90:	9a b9 62 a8 1c       	call   0x1ca8:0x62b9
    1c95:	50                   	push   ax
    1c96:	8d 7e f8             	lea    di,[bp-0x8]
    1c99:	16                   	push   ss
    1c9a:	57                   	push   di
    1c9b:	9a ff ff 00 00       	call   0x0:0xffff
    1ca0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ca3:	06                   	push   es
    1ca4:	57                   	push   di
    1ca5:	9a b9 62 bf 1c       	call   0x1cbf:0x62b9
    1caa:	50                   	push   ax
    1cab:	8d 7e f8             	lea    di,[bp-0x8]
    1cae:	16                   	push   ss
    1caf:	57                   	push   di
    1cb0:	6a 00                	push   0x0
    1cb2:	9a ca 1c 00 00       	call   0x0:0x1cca
    1cb7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cba:	06                   	push   es
    1cbb:	57                   	push   di
    1cbc:	9a b9 62 84 1d       	call   0x1d84:0x62b9
    1cc1:	50                   	push   ax
    1cc2:	8d 7e f0             	lea    di,[bp-0x10]
    1cc5:	16                   	push   ss
    1cc6:	57                   	push   di
    1cc7:	6a 00                	push   0x0
    1cc9:	9a 03 1e 00 00       	call   0x0:0x1e03
    1cce:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    1cd2:	75 03                	jne    0x1cd7
    1cd4:	e9 ab 01             	jmp    0x1e82
    1cd7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cda:	06                   	push   es
    1cdb:	57                   	push   di
    1cdc:	9a 32 25 f7 1c       	call   0x1cf7:0x2532
    1ce1:	b8 e3 1b             	mov    ax,0x1be3
    1ce4:	0e                   	push   cs
    1ce5:	50                   	push   ax
    1ce6:	55                   	push   bp
    1ce7:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1ceb:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1cef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf2:	06                   	push   es
    1cf3:	57                   	push   di
    1cf4:	9a 88 6f 6e 1d       	call   0x1d6e:0x6f88
    1cf9:	8b c8                	mov    cx,ax
    1cfb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1cfe:	99                   	cwd
    1cff:	31 d0                	xor    ax,dx
    1d01:	29 d0                	sub    ax,dx
    1d03:	3b c1                	cmp    ax,cx
    1d05:	7e 17                	jle    0x1d1e
    1d07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d0a:	06                   	push   es
    1d0b:	57                   	push   di
    1d0c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d0f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1d13:	9a 6a 14 7a 1d       	call   0x1d7a:0x146a
    1d18:	e9 73 01             	jmp    0x1e8e
    1d1b:	e9 45 01             	jmp    0x1e63
    1d1e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d21:	26 8b 85 fc 00       	mov    ax,WORD PTR es:[di+0xfc]
    1d26:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    1d29:	26 f6 85 53 01 40    	test   BYTE PTR es:[di+0x153],0x40
    1d2f:	74 03                	je     0x1d34
    1d31:	ff 46 ee             	inc    WORD PTR [bp-0x12]
    1d34:	8d 7e e6             	lea    di,[bp-0x1a]
    1d37:	16                   	push   ss
    1d38:	57                   	push   di
    1d39:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d3c:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    1d41:	30 e4                	xor    ah,ah
    1d43:	31 d2                	xor    dx,dx
    1d45:	52                   	push   dx
    1d46:	50                   	push   ax
    1d47:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    1d4c:	30 e4                	xor    ah,ah
    1d4e:	31 d2                	xor    dx,dx
    1d50:	52                   	push   dx
    1d51:	50                   	push   ax
    1d52:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1d57:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1d5c:	2d 01 00             	sub    ax,0x1
    1d5f:	83 da 00             	sbb    dx,0x0
    1d62:	52                   	push   dx
    1d63:	50                   	push   ax
    1d64:	6a 00                	push   0x0
    1d66:	68 e8 03             	push   0x3e8
    1d69:	06                   	push   es
    1d6a:	57                   	push   di
    1d6b:	9a b3 23 e2 1d       	call   0x1de2:0x23b3
    1d70:	8d 7e f0             	lea    di,[bp-0x10]
    1d73:	16                   	push   ss
    1d74:	57                   	push   di
    1d75:	6a 08                	push   0x8
    1d77:	9a 1b 16 ee 1d       	call   0x1dee:0x161b
    1d7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d7f:	06                   	push   es
    1d80:	57                   	push   di
    1d81:	9a b9 62 f8 1d       	call   0x1df8:0x62b9
    1d86:	50                   	push   ax
    1d87:	6a 00                	push   0x0
    1d89:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    1d8c:	f7 d8                	neg    ax
    1d8e:	f7 66 0a             	mul    WORD PTR [bp+0xa]
    1d91:	50                   	push   ax
    1d92:	8d 7e f0             	lea    di,[bp-0x10]
    1d95:	16                   	push   ss
    1d96:	57                   	push   di
    1d97:	8d 7e f0             	lea    di,[bp-0x10]
    1d9a:	16                   	push   ss
    1d9b:	57                   	push   di
    1d9c:	9a ff ff 00 00       	call   0x0:0xffff
    1da1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1da4:	26 f6 85 53 01 08    	test   BYTE PTR es:[di+0x153],0x8
    1daa:	75 03                	jne    0x1daf
    1dac:	e9 b4 00             	jmp    0x1e63
    1daf:	8d 7e e6             	lea    di,[bp-0x1a]
    1db2:	16                   	push   ss
    1db3:	57                   	push   di
    1db4:	6a 00                	push   0x0
    1db6:	6a 00                	push   0x0
    1db8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dbb:	26 8b 85 5b 01       	mov    ax,WORD PTR es:[di+0x15b]
    1dc0:	99                   	cwd
    1dc1:	52                   	push   dx
    1dc2:	50                   	push   ax
    1dc3:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1dc8:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1dcd:	2d 01 00             	sub    ax,0x1
    1dd0:	83 da 00             	sbb    dx,0x0
    1dd3:	52                   	push   dx
    1dd4:	50                   	push   ax
    1dd5:	26 8b 85 5b 01       	mov    ax,WORD PTR es:[di+0x15b]
    1dda:	99                   	cwd
    1ddb:	52                   	push   dx
    1ddc:	50                   	push   ax
    1ddd:	06                   	push   es
    1dde:	57                   	push   di
    1ddf:	9a b3 23 3e 1e       	call   0x1e3e:0x23b3
    1de4:	8d 7e f8             	lea    di,[bp-0x8]
    1de7:	16                   	push   ss
    1de8:	57                   	push   di
    1de9:	6a 08                	push   0x8
    1deb:	9a 1b 16 4a 1e       	call   0x1e4a:0x161b
    1df0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1df3:	06                   	push   es
    1df4:	57                   	push   di
    1df5:	9a b9 62 54 1e       	call   0x1e54:0x62b9
    1dfa:	50                   	push   ax
    1dfb:	8d 7e f8             	lea    di,[bp-0x8]
    1dfe:	16                   	push   ss
    1dff:	57                   	push   di
    1e00:	6a 00                	push   0x0
    1e02:	9a 5f 1e 00 00       	call   0x0:0x1e5f
    1e07:	8d 7e e6             	lea    di,[bp-0x1a]
    1e0a:	16                   	push   ss
    1e0b:	57                   	push   di
    1e0c:	6a 00                	push   0x0
    1e0e:	6a 00                	push   0x0
    1e10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e13:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1e18:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    1e1d:	26 8b 85 e6 00       	mov    ax,WORD PTR es:[di+0xe6]
    1e22:	26 8b 95 e8 00       	mov    dx,WORD PTR es:[di+0xe8]
    1e27:	2d 01 00             	sub    ax,0x1
    1e2a:	83 da 00             	sbb    dx,0x0
    1e2d:	52                   	push   dx
    1e2e:	50                   	push   ax
    1e2f:	26 ff b5 f8 00       	push   WORD PTR es:[di+0xf8]
    1e34:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
    1e39:	06                   	push   es
    1e3a:	57                   	push   di
    1e3b:	9a b3 23 7f 1e       	call   0x1e7f:0x23b3
    1e40:	8d 7e f0             	lea    di,[bp-0x10]
    1e43:	16                   	push   ss
    1e44:	57                   	push   di
    1e45:	6a 08                	push   0x8
    1e47:	9a 1b 16 bb 1f       	call   0x1fbb:0x161b
    1e4c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e4f:	06                   	push   es
    1e50:	57                   	push   di
    1e51:	9a b9 62 ae 1e       	call   0x1eae:0x62b9
    1e56:	50                   	push   ax
    1e57:	8d 7e f0             	lea    di,[bp-0x10]
    1e5a:	16                   	push   ss
    1e5b:	57                   	push   di
    1e5c:	6a 00                	push   0x0
    1e5e:	9a ff ff 00 00       	call   0x0:0xffff
    1e63:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1e67:	83 c4 06             	add    sp,0x6
    1e6a:	b8 82 1e             	mov    ax,0x1e82
    1e6d:	0e                   	push   cs
    1e6e:	50                   	push   ax
    1e6f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e72:	26 f6 85 53 01 02    	test   BYTE PTR es:[di+0x153],0x2
    1e78:	74 07                	je     0x1e81
    1e7a:	06                   	push   es
    1e7b:	57                   	push   di
    1e7c:	9a 49 25 69 1f       	call   0x1f69:0x2549
    1e81:	cb                   	retf
    1e82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e85:	06                   	push   es
    1e86:	57                   	push   di
    1e87:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e8a:	26 ff 5d 50          	call   DWORD PTR es:[di+0x50]
    1e8e:	c9                   	leave
    1e8f:	ca 06 00             	retf   0x6
    1e92:	55                   	push   bp
    1e93:	89 e5                	mov    bp,sp
    1e95:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e98:	26 80 bd 5a 01 00    	cmp    BYTE PTR es:[di+0x15a],0x0
    1e9e:	75 10                	jne    0x1eb0
    1ea0:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
    1ea5:	75 09                	jne    0x1eb0
    1ea7:	6a 00                	push   0x0
    1ea9:	06                   	push   es
    1eaa:	57                   	push   di
    1eab:	9a 3e 1e 86 20       	call   0x2086:0x1e3e
    1eb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1eb3:	26 f6 85 53 01 04    	test   BYTE PTR es:[di+0x153],0x4
    1eb9:	74 0a                	je     0x1ec5
    1ebb:	06                   	push   es
    1ebc:	57                   	push   di
    1ebd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ec0:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    1ec5:	c9                   	leave
    1ec6:	ca 08 00             	retf   0x8
    1ec9:	c8 04 00 00          	enter  0x4,0x0
    1ecd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ed0:	06                   	push   es
    1ed1:	57                   	push   di
    1ed2:	9a 19 19 e3 1e       	call   0x1ee3:0x1919
    1ed7:	09 c0                	or     ax,ax
    1ed9:	7e 32                	jle    0x1f0d
    1edb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ede:	06                   	push   es
    1edf:	57                   	push   di
    1ee0:	9a da 19 ee 1e       	call   0x1eee:0x19da
    1ee5:	50                   	push   ax
    1ee6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ee9:	06                   	push   es
    1eea:	57                   	push   di
    1eeb:	9a 33 19 83 1f       	call   0x1f83:0x1933
    1ef0:	89 c7                	mov    di,ax
    1ef2:	8e c2                	mov    es,dx
    1ef4:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1ef7:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1efa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1efd:	81 c7 79 01          	add    di,0x179
    1f01:	06                   	push   es
    1f02:	57                   	push   di
    1f03:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1f06:	06                   	push   es
    1f07:	57                   	push   di
    1f08:	9a 56 6f 34 1f       	call   0x1f34:0x6f56
    1f0d:	c9                   	leave
    1f0e:	ca 04 00             	retf   0x4
    1f11:	c8 04 01 00          	enter  0x104,0x0
    1f15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f18:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1f1d:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    1f22:	75 03                	jne    0x1f27
    1f24:	e9 a2 00             	jmp    0x1fc9
    1f27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f2a:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1f2f:	06                   	push   es
    1f30:	57                   	push   di
    1f31:	9a cd 78 ad 1f       	call   0x1fad:0x78cd
    1f36:	8b d0                	mov    dx,ax
    1f38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f3b:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    1f40:	30 e4                	xor    ah,ah
    1f42:	03 c2                	add    ax,dx
    1f44:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1f47:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1f4a:	99                   	cwd
    1f4b:	26 3b 95 f8 00       	cmp    dx,WORD PTR es:[di+0xf8]
    1f50:	75 07                	jne    0x1f59
    1f52:	26 3b 85 f6 00       	cmp    ax,WORD PTR es:[di+0xf6]
    1f57:	74 22                	je     0x1f7b
    1f59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f5c:	26 f6 85 53 01 02    	test   BYTE PTR es:[di+0x153],0x2
    1f62:	75 07                	jne    0x1f6b
    1f64:	06                   	push   es
    1f65:	57                   	push   di
    1f66:	9a 32 25 79 1f       	call   0x1f79:0x2532
    1f6b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1f6e:	99                   	cwd
    1f6f:	52                   	push   dx
    1f70:	50                   	push   ax
    1f71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f74:	06                   	push   es
    1f75:	57                   	push   di
    1f76:	9a ec 73 c7 1f       	call   0x1fc7:0x73ec
    1f7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f7e:	06                   	push   es
    1f7f:	57                   	push   di
    1f80:	9a 19 19 97 1f       	call   0x1f97:0x1919
    1f85:	09 c0                	or     ax,ax
    1f87:	7e 40                	jle    0x1fc9
    1f89:	8d be fc fe          	lea    di,[bp-0x104]
    1f8d:	16                   	push   ss
    1f8e:	57                   	push   di
    1f8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f92:	06                   	push   es
    1f93:	57                   	push   di
    1f94:	9a da 19 a2 1f       	call   0x1fa2:0x19da
    1f99:	50                   	push   ax
    1f9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f9d:	06                   	push   es
    1f9e:	57                   	push   di
    1f9f:	9a 33 19 0f 20       	call   0x200f:0x1933
    1fa4:	89 c7                	mov    di,ax
    1fa6:	8e c2                	mov    es,dx
    1fa8:	06                   	push   es
    1fa9:	57                   	push   di
    1faa:	9a cf 68 55 20       	call   0x2055:0x68cf
    1faf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb2:	81 c7 79 01          	add    di,0x179
    1fb6:	06                   	push   es
    1fb7:	57                   	push   di
    1fb8:	9a be 18 62 20       	call   0x2062:0x18be
    1fbd:	74 0a                	je     0x1fc9
    1fbf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fc2:	06                   	push   es
    1fc3:	57                   	push   di
    1fc4:	9a 9f 25 51 21       	call   0x2151:0x259f
    1fc9:	c9                   	leave
    1fca:	ca 04 00             	retf   0x4
    1fcd:	c8 04 00 00          	enter  0x4,0x0
    1fd1:	31 c0                	xor    ax,ax
    1fd3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1fd6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1fd9:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    1fdd:	7c 38                	jl     0x2017
    1fdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fe2:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1fe7:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    1fec:	74 29                	je     0x2017
    1fee:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1ff1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ff4:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    1ff9:	26 3b 45 18          	cmp    ax,WORD PTR es:[di+0x18]
    1ffd:	7d 18                	jge    0x2017
    1fff:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2002:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2005:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    200a:	06                   	push   es
    200b:	57                   	push   di
    200c:	9a 92 09 37 20       	call   0x2037:0x992
    2011:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2014:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2017:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    201a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    201d:	c9                   	leave
    201e:	ca 06 00             	retf   0x6
    2021:	c8 04 01 00          	enter  0x104,0x0
    2025:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2028:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    202c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    202f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2032:	06                   	push   es
    2033:	57                   	push   di
    2034:	9a cd 1f ef 21       	call   0x21ef:0x1fcd
    2039:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    203c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    203f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2042:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    2045:	74 1d                	je     0x2064
    2047:	8d be fc fe          	lea    di,[bp-0x104]
    204b:	16                   	push   ss
    204c:	57                   	push   di
    204d:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2050:	06                   	push   es
    2051:	57                   	push   di
    2052:	9a 35 68 9c 20       	call   0x209c:0x6835
    2057:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    205a:	06                   	push   es
    205b:	57                   	push   di
    205c:	68 ff 00             	push   0xff
    205f:	9a e7 17 74 23       	call   0x2374:0x17e7
    2064:	c9                   	leave
    2065:	ca 06 00             	retf   0x6
    2068:	c8 06 00 00          	enter  0x6,0x0
    206c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    206f:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2074:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    2079:	75 03                	jne    0x207e
    207b:	e9 9c 00             	jmp    0x211a
    207e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2081:	06                   	push   es
    2082:	57                   	push   di
    2083:	9a fa 64 b5 20       	call   0x20b5:0x64fa
    2088:	08 c0                	or     al,al
    208a:	75 03                	jne    0x208f
    208c:	e9 8b 00             	jmp    0x211a
    208f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2092:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2097:	06                   	push   es
    2098:	57                   	push   di
    2099:	9a fa 76 7f 21       	call   0x217f:0x76fa
    209e:	89 c7                	mov    di,ax
    20a0:	8e c2                	mov    es,dx
    20a2:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    20a5:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    20a8:	c7 46 fe 02 00       	mov    WORD PTR [bp-0x2],0x2
    20ad:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20b0:	06                   	push   es
    20b1:	57                   	push   di
    20b2:	9a b9 62 f4 20       	call   0x20f4:0x62b9
    20b7:	50                   	push   ax
    20b8:	6a 01                	push   0x1
    20ba:	6a 00                	push   0x0
    20bc:	6a 04                	push   0x4
    20be:	6a 00                	push   0x0
    20c0:	9a ff ff 00 00       	call   0x0:0xffff
    20c5:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    20c8:	26 80 7d 38 00       	cmp    BYTE PTR es:[di+0x38],0x0
    20cd:	74 07                	je     0x20d6
    20cf:	31 c0                	xor    ax,ax
    20d1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    20d4:	eb 16                	jmp    0x20ec
    20d6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    20d9:	26 80 7d 39 00       	cmp    BYTE PTR es:[di+0x39],0x0
    20de:	74 07                	je     0x20e7
    20e0:	c7 46 fe 04 00       	mov    WORD PTR [bp-0x2],0x4
    20e5:	eb 05                	jmp    0x20ec
    20e7:	c7 46 fe 02 00       	mov    WORD PTR [bp-0x2],0x2
    20ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20ef:	06                   	push   es
    20f0:	57                   	push   di
    20f1:	9a b9 62 0b 21       	call   0x210b:0x62b9
    20f6:	50                   	push   ax
    20f7:	6a 01                	push   0x1
    20f9:	9a ff ff 00 00       	call   0x0:0xffff
    20fe:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    2101:	74 17                	je     0x211a
    2103:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2106:	06                   	push   es
    2107:	57                   	push   di
    2108:	9a b9 62 0d 22       	call   0x220d:0x62b9
    210d:	50                   	push   ax
    210e:	6a 01                	push   0x1
    2110:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2113:	6a 01                	push   0x1
    2115:	9a ff ff 00 00       	call   0x0:0xffff
    211a:	c9                   	leave
    211b:	ca 04 00             	retf   0x4
    211e:	c8 04 00 00          	enter  0x4,0x0
    2122:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2125:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    212a:	30 e4                	xor    ah,ah
    212c:	31 d2                	xor    dx,dx
    212e:	26 3b 95 0c 01       	cmp    dx,WORD PTR es:[di+0x10c]
    2133:	7f 09                	jg     0x213e
    2135:	7c 1c                	jl     0x2153
    2137:	26 3b 85 0a 01       	cmp    ax,WORD PTR es:[di+0x10a]
    213c:	72 15                	jb     0x2153
    213e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2141:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    2146:	30 e4                	xor    ah,ah
    2148:	40                   	inc    ax
    2149:	99                   	cwd
    214a:	52                   	push   dx
    214b:	50                   	push   ax
    214c:	06                   	push   es
    214d:	57                   	push   di
    214e:	9a 26 74 63 21       	call   0x2163:0x7426
    2153:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2156:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    215b:	30 e4                	xor    ah,ah
    215d:	50                   	push   ax
    215e:	06                   	push   es
    215f:	57                   	push   di
    2160:	9a 8b 72 98 21       	call   0x2198:0x728b
    2165:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2168:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    216d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2170:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2173:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    2178:	74 0b                	je     0x2185
    217a:	06                   	push   es
    217b:	57                   	push   di
    217c:	9a 78 79 c3 21       	call   0x21c3:0x7978
    2181:	09 c0                	or     ax,ax
    2183:	75 17                	jne    0x219c
    2185:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2188:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    218d:	30 e4                	xor    ah,ah
    218f:	40                   	inc    ax
    2190:	99                   	cwd
    2191:	52                   	push   dx
    2192:	50                   	push   ax
    2193:	06                   	push   es
    2194:	57                   	push   di
    2195:	9a 26 74 a9 21       	call   0x21a9:0x7426
    219a:	eb 55                	jmp    0x21f1
    219c:	6a 00                	push   0x0
    219e:	68 e8 03             	push   0x3e8
    21a1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21a4:	06                   	push   es
    21a5:	57                   	push   di
    21a6:	9a 26 74 b3 21       	call   0x21b3:0x7426
    21ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ae:	06                   	push   es
    21af:	57                   	push   di
    21b0:	9a 88 6f e5 21       	call   0x21e5:0x6f88
    21b5:	50                   	push   ax
    21b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b9:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    21be:	06                   	push   es
    21bf:	57                   	push   di
    21c0:	9a 31 79 cd 21       	call   0x21cd:0x7931
    21c5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    21c8:	06                   	push   es
    21c9:	57                   	push   di
    21ca:	9a 78 79 08 23       	call   0x2308:0x7978
    21cf:	8b d0                	mov    dx,ax
    21d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21d4:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    21d9:	30 e4                	xor    ah,ah
    21db:	03 c2                	add    ax,dx
    21dd:	99                   	cwd
    21de:	52                   	push   dx
    21df:	50                   	push   ax
    21e0:	06                   	push   es
    21e1:	57                   	push   di
    21e2:	9a 26 74 a0 23       	call   0x23a0:0x7426
    21e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21ea:	06                   	push   es
    21eb:	57                   	push   di
    21ec:	9a 11 1f 67 22       	call   0x2267:0x1f11
    21f1:	c9                   	leave
    21f2:	ca 04 00             	retf   0x4
    21f5:	c8 02 00 00          	enter  0x2,0x0
    21f9:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    21fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2200:	26 80 bd 7a 02 00    	cmp    BYTE PTR es:[di+0x27a],0x0
    2206:	74 54                	je     0x225c
    2208:	06                   	push   es
    2209:	57                   	push   di
    220a:	9a c4 61 2e 22       	call   0x222e:0x61c4
    220f:	08 c0                	or     al,al
    2211:	74 49                	je     0x225c
    2213:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2216:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    221b:	75 3f                	jne    0x225c
    221d:	06                   	push   es
    221e:	57                   	push   di
    221f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2222:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    2226:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2229:	06                   	push   es
    222a:	57                   	push   di
    222b:	9a 58 62 4d 22       	call   0x224d:0x6258
    2230:	08 c0                	or     al,al
    2232:	75 23                	jne    0x2257
    2234:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2237:	26 8b 85 2f 01       	mov    ax,WORD PTR es:[di+0x12f]
    223c:	26 0b 85 31 01       	or     ax,WORD PTR es:[di+0x131]
    2241:	74 10                	je     0x2253
    2243:	26 c4 bd 2f 01       	les    di,DWORD PTR es:[di+0x12f]
    2248:	06                   	push   es
    2249:	57                   	push   di
    224a:	9a 58 62 7a 22       	call   0x227a:0x6258
    224f:	08 c0                	or     al,al
    2251:	75 04                	jne    0x2257
    2253:	b0 00                	mov    al,0x0
    2255:	eb 02                	jmp    0x2259
    2257:	b0 01                	mov    al,0x1
    2259:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    225c:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    225f:	c9                   	leave
    2260:	ca 04 00             	retf   0x4
    2263:	00 00                	add    BYTE PTR [bx+si],al
    2265:	b5 22                	mov    ch,0x22
    2267:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
    2268:	22 55 89             	and    dl,BYTE PTR [di-0x77]
    226b:	e5 ff                	in     ax,0xff
    226d:	76 0c                	jbe    0x227b
    226f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2272:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2275:	06                   	push   es
    2276:	57                   	push   di
    2277:	9a b4 2d 89 23       	call   0x2389:0x2db4
    227c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    227f:	26 80 7d 2b 00       	cmp    BYTE PTR es:[di+0x2b],0x0
    2284:	74 46                	je     0x22cc
    2286:	26 c6 85 5a 01 01    	mov    BYTE PTR es:[di+0x15a],0x1
    228c:	b8 63 22             	mov    ax,0x2263
    228f:	0e                   	push   cs
    2290:	50                   	push   ax
    2291:	55                   	push   bp
    2292:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2296:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    229a:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    229e:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    22a2:	06                   	push   es
    22a3:	57                   	push   di
    22a4:	9a 58 37 d8 22       	call   0x22d8:0x3758
    22a9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    22ad:	83 c4 06             	add    sp,0x6
    22b0:	b8 bf 22             	mov    ax,0x22bf
    22b3:	0e                   	push   cs
    22b4:	50                   	push   ax
    22b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22b8:	26 c6 85 5a 01 00    	mov    BYTE PTR es:[di+0x15a],0x0
    22be:	cb                   	retf
    22bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22c2:	06                   	push   es
    22c3:	57                   	push   di
    22c4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22c7:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    22cc:	c9                   	leave
    22cd:	ca 08 00             	retf   0x8
    22d0:	01 00                	add    WORD PTR [bx+si],ax
    22d2:	00 00                	add    BYTE PTR [bx+si],al
    22d4:	00 00                	add    BYTE PTR [bx+si],al
    22d6:	65 23 5a 24          	and    bx,WORD PTR gs:[bp+si+0x24]
    22da:	c8 04 00 00          	enter  0x4,0x0
    22de:	b8 d0 22             	mov    ax,0x22d0
    22e1:	0e                   	push   cs
    22e2:	50                   	push   ax
    22e3:	55                   	push   bp
    22e4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    22e8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    22ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22ef:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    22f4:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    22f9:	74 61                	je     0x235c
    22fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22fe:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2303:	06                   	push   es
    2304:	57                   	push   di
    2305:	9a fa 76 47 23       	call   0x2347:0x76fa
    230a:	89 c7                	mov    di,ax
    230c:	8e c2                	mov    es,dx
    230e:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2311:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2314:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2317:	26 f6 85 54 01 08    	test   BYTE PTR es:[di+0x154],0x8
    231d:	74 2c                	je     0x234b
    231f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2322:	26 80 7d 3a 03       	cmp    BYTE PTR es:[di+0x3a],0x3
    2327:	75 22                	jne    0x234b
    2329:	26 80 7d 3e 00       	cmp    BYTE PTR es:[di+0x3e],0x0
    232e:	75 1b                	jne    0x234b
    2330:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2333:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2338:	26 80 7d 1c 00       	cmp    BYTE PTR es:[di+0x1c],0x0
    233d:	75 0c                	jne    0x234b
    233f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2342:	06                   	push   es
    2343:	57                   	push   di
    2344:	9a 8b 55 60 25       	call   0x2560:0x558b
    2349:	eb 11                	jmp    0x235c
    234b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234e:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2353:	06                   	push   es
    2354:	57                   	push   di
    2355:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2358:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    235c:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2360:	83 c4 06             	add    sp,0x6
    2363:	eb 16                	jmp    0x237b
    2365:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2368:	06                   	push   es
    2369:	57                   	push   di
    236a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    236d:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
    2371:	ea 85 13 79 23       	jmp    0x2379:0x1385
    2376:	9a 34 14 ea 26       	call   0x26ea:0x1434
    237b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    237e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2381:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2384:	06                   	push   es
    2385:	57                   	push   di
    2386:	9a d2 55 99 26       	call   0x2699:0x55d2
    238b:	c9                   	leave
    238c:	ca 08 00             	retf   0x8
    238f:	55                   	push   bp
    2390:	89 e5                	mov    bp,sp
    2392:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2395:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2398:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    239b:	06                   	push   es
    239c:	57                   	push   di
    239d:	9a 8d 7c c5 23       	call   0x23c5:0x7c8d
    23a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23a5:	06                   	push   es
    23a6:	57                   	push   di
    23a7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23aa:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    23af:	c9                   	leave
    23b0:	ca 08 00             	retf   0x8
    23b3:	c8 08 00 00          	enter  0x8,0x0
    23b7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23ba:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c0:	06                   	push   es
    23c1:	57                   	push   di
    23c2:	9a ea 7c ec 23       	call   0x23ec:0x7cea
    23c7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    23ca:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    23ce:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
    23d2:	75 5c                	jne    0x2430
    23d4:	8d 7e f8             	lea    di,[bp-0x8]
    23d7:	16                   	push   ss
    23d8:	57                   	push   di
    23d9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    23dc:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    23e0:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    23e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e7:	06                   	push   es
    23e8:	57                   	push   di
    23e9:	9a 44 28 da 24       	call   0x24da:0x2844
    23ee:	83 c4 04             	add    sp,0x4
    23f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23f4:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    23f9:	30 e4                	xor    ah,ah
    23fb:	31 d2                	xor    dx,dx
    23fd:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    2400:	7c 07                	jl     0x2409
    2402:	7f 2c                	jg     0x2430
    2404:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    2407:	77 27                	ja     0x2430
    2409:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    240c:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    2411:	30 e4                	xor    ah,ah
    2413:	31 d2                	xor    dx,dx
    2415:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    2418:	7f 07                	jg     0x2421
    241a:	7c 14                	jl     0x2430
    241c:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    241f:	76 0f                	jbe    0x2430
    2421:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2424:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
    242a:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
    2430:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2433:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    2438:	75 42                	jne    0x247c
    243a:	26 83 7d 08 01       	cmp    WORD PTR es:[di+0x8],0x1
    243f:	75 3b                	jne    0x247c
    2441:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2444:	26 8b 85 5d 01       	mov    ax,WORD PTR es:[di+0x15d]
    2449:	26 0b 85 5f 01       	or     ax,WORD PTR es:[di+0x15f]
    244e:	74 1f                	je     0x246f
    2450:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2455:	06                   	push   es
    2456:	57                   	push   di
    2457:	9a 60 09 a3 24       	call   0x24a3:0x960
    245c:	08 c0                	or     al,al
    245e:	75 0f                	jne    0x246f
    2460:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2463:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2468:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    246d:	75 0d                	jne    0x247c
    246f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2472:	31 c0                	xor    ax,ax
    2474:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2478:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    247c:	c9                   	leave
    247d:	ca 08 00             	retf   0x8
    2480:	55                   	push   bp
    2481:	89 e5                	mov    bp,sp
    2483:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2486:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    248b:	74 3f                	je     0x24cc
    248d:	26 8b 85 5d 01       	mov    ax,WORD PTR es:[di+0x15d]
    2492:	26 0b 85 5f 01       	or     ax,WORD PTR es:[di+0x15f]
    2497:	74 1f                	je     0x24b8
    2499:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    249e:	06                   	push   es
    249f:	57                   	push   di
    24a0:	9a 60 09 03 25       	call   0x2503:0x960
    24a5:	08 c0                	or     al,al
    24a7:	75 0f                	jne    0x24b8
    24a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24ac:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    24b1:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    24b6:	75 14                	jne    0x24cc
    24b8:	6a 00                	push   0x0
    24ba:	6a 00                	push   0x0
    24bc:	68 00 7f             	push   0x7f00
    24bf:	9a ff ff 00 00       	call   0x0:0xffff
    24c4:	50                   	push   ax
    24c5:	9a ff ff 00 00       	call   0x0:0xffff
    24ca:	eb 10                	jmp    0x24dc
    24cc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    24cf:	ff 76 0a             	push   WORD PTR [bp+0xa]
    24d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24d5:	06                   	push   es
    24d6:	57                   	push   di
    24d7:	9a aa 7a f1 24       	call   0x24f1:0x7aaa
    24dc:	c9                   	leave
    24dd:	ca 08 00             	retf   0x8
    24e0:	55                   	push   bp
    24e1:	89 e5                	mov    bp,sp
    24e3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    24e6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    24e9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24ec:	06                   	push   es
    24ed:	57                   	push   di
    24ee:	9a e8 7b db 25       	call   0x25db:0x7be8
    24f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24f6:	26 80 bd 57 01 00    	cmp    BYTE PTR es:[di+0x157],0x0
    24fc:	75 07                	jne    0x2505
    24fe:	06                   	push   es
    24ff:	57                   	push   di
    2500:	9a 1e 21 2f 25       	call   0x252f:0x211e
    2505:	c9                   	leave
    2506:	ca 08 00             	retf   0x8
    2509:	19 26 25 26          	sbb    WORD PTR ds:0x2625,sp
    250d:	3e 26 42             	ds es inc dx
    2510:	26 59                	es pop cx
    2512:	26 92                	es xchg dx,ax
    2514:	25 ad 25             	and    ax,0x25ad
    2517:	d3 25                	shl    WORD PTR [di],cl
    2519:	ed                   	in     ax,dx
    251a:	25 04 26             	and    ax,0x2604
    251d:	7b 26                	jnp    0x2545
    251f:	71 26                	jno    0x2547
    2521:	65 26 c8 0c 00 00    	gs es enter 0xc,0x0
    2527:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    252a:	06                   	push   es
    252b:	57                   	push   di
    252c:	9a f5 21 59 27       	call   0x2759:0x21f5
    2531:	08 c0                	or     al,al
    2533:	75 03                	jne    0x2538
    2535:	e9 43 01             	jmp    0x267b
    2538:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    253b:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2540:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    2545:	75 03                	jne    0x254a
    2547:	e9 31 01             	jmp    0x267b
    254a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    254d:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2550:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2553:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2556:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    255b:	06                   	push   es
    255c:	57                   	push   di
    255d:	9a fa 76 9a 25       	call   0x259a:0x76fa
    2562:	89 c7                	mov    di,ax
    2564:	8e c2                	mov    es,dx
    2566:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    2569:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    256c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    256f:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2574:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    2577:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    257a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    257d:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    2581:	3d 07 00             	cmp    ax,0x7
    2584:	76 03                	jbe    0x2589
    2586:	e9 f2 00             	jmp    0x267b
    2589:	89 c3                	mov    bx,ax
    258b:	d1 e3                	shl    bx,1
    258d:	2e ff a7 13 25       	jmp    WORD PTR cs:[bx+0x2513]
    2592:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2595:	06                   	push   es
    2596:	57                   	push   di
    2597:	9a cd 78 a8 25       	call   0x25a8:0x78cd
    259c:	f7 d8                	neg    ax
    259e:	48                   	dec    ax
    259f:	50                   	push   ax
    25a0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    25a3:	06                   	push   es
    25a4:	57                   	push   di
    25a5:	9a c7 4d b5 25       	call   0x25b5:0x4dc7
    25aa:	e9 ce 00             	jmp    0x267b
    25ad:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    25b0:	06                   	push   es
    25b1:	57                   	push   di
    25b2:	9a cd 78 c0 25       	call   0x25c0:0x78cd
    25b7:	50                   	push   ax
    25b8:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    25bb:	06                   	push   es
    25bc:	57                   	push   di
    25bd:	9a 78 79 ce 25       	call   0x25ce:0x7978
    25c2:	5a                   	pop    dx
    25c3:	2b c2                	sub    ax,dx
    25c5:	50                   	push   ax
    25c6:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    25c9:	06                   	push   es
    25ca:	57                   	push   di
    25cb:	9a c7 4d e8 25       	call   0x25e8:0x4dc7
    25d0:	e9 a8 00             	jmp    0x267b
    25d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25d6:	06                   	push   es
    25d7:	57                   	push   di
    25d8:	9a 88 6f f5 25       	call   0x25f5:0x6f88
    25dd:	f7 d8                	neg    ax
    25df:	50                   	push   ax
    25e0:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    25e3:	06                   	push   es
    25e4:	57                   	push   di
    25e5:	9a c7 4d 00 26       	call   0x2600:0x4dc7
    25ea:	e9 8e 00             	jmp    0x267b
    25ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25f0:	06                   	push   es
    25f1:	57                   	push   di
    25f2:	9a 88 6f 2d 26       	call   0x262d:0x6f88
    25f7:	50                   	push   ax
    25f8:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    25fb:	06                   	push   es
    25fc:	57                   	push   di
    25fd:	9a c7 4d 21 26       	call   0x2621:0x4dc7
    2602:	eb 77                	jmp    0x267b
    2604:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2607:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    260b:	3d 04 00             	cmp    ax,0x4
    260e:	77 53                	ja     0x2663
    2610:	89 c3                	mov    bx,ax
    2612:	d1 e3                	shl    bx,1
    2614:	2e ff a7 09 25       	jmp    WORD PTR cs:[bx+0x2509]
    2619:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    261c:	06                   	push   es
    261d:	57                   	push   di
    261e:	9a cd 4c 3a 26       	call   0x263a:0x4ccd
    2623:	eb 3e                	jmp    0x2663
    2625:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2628:	06                   	push   es
    2629:	57                   	push   di
    262a:	9a 88 6f 4a 26       	call   0x264a:0x6f88
    262f:	f7 d8                	neg    ax
    2631:	50                   	push   ax
    2632:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2635:	06                   	push   es
    2636:	57                   	push   di
    2637:	9a c7 4d 55 26       	call   0x2655:0x4dc7
    263c:	eb 25                	jmp    0x2663
    263e:	eb 3b                	jmp    0x267b
    2640:	eb 21                	jmp    0x2663
    2642:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2645:	06                   	push   es
    2646:	57                   	push   di
    2647:	9a 88 6f 6b 2c       	call   0x2c6b:0x6f88
    264c:	50                   	push   ax
    264d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2650:	06                   	push   es
    2651:	57                   	push   di
    2652:	9a c7 4d 61 26       	call   0x2661:0x4dc7
    2657:	eb 0a                	jmp    0x2663
    2659:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    265c:	06                   	push   es
    265d:	57                   	push   di
    265e:	9a 4a 4d 6d 26       	call   0x266d:0x4d4a
    2663:	eb 16                	jmp    0x267b
    2665:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2668:	06                   	push   es
    2669:	57                   	push   di
    266a:	9a 4a 4d 79 26       	call   0x2679:0x4d4a
    266f:	eb 0a                	jmp    0x267b
    2671:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2674:	06                   	push   es
    2675:	57                   	push   di
    2676:	9a cd 4c dc 26       	call   0x26dc:0x4ccd
    267b:	c9                   	leave
    267c:	ca 08 00             	retf   0x8
    267f:	c8 02 00 00          	enter  0x2,0x0
    2683:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    2687:	74 16                	je     0x269f
    2689:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    268c:	26 f6 85 54 01 02    	test   BYTE PTR es:[di+0x154],0x2
    2692:	75 0f                	jne    0x26a3
    2694:	06                   	push   es
    2695:	57                   	push   di
    2696:	9a 58 62 53 34       	call   0x3453:0x6258
    269b:	08 c0                	or     al,al
    269d:	75 04                	jne    0x26a3
    269f:	b0 00                	mov    al,0x0
    26a1:	eb 02                	jmp    0x26a5
    26a3:	b0 01                	mov    al,0x1
    26a5:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    26a8:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    26ab:	c9                   	leave
    26ac:	ca 0e 00             	retf   0xe
    26af:	c8 02 02 00          	enter  0x202,0x0
    26b3:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    26b7:	c6 86 fe fe 00       	mov    BYTE PTR [bp-0x102],0x0
    26bc:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    26bf:	0b 46 0e             	or     ax,WORD PTR [bp+0xe]
    26c2:	74 28                	je     0x26ec
    26c4:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    26c7:	26 8a 45 25          	mov    al,BYTE PTR es:[di+0x25]
    26cb:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    26ce:	8d be fe fd          	lea    di,[bp-0x202]
    26d2:	16                   	push   ss
    26d3:	57                   	push   di
    26d4:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    26d7:	06                   	push   es
    26d8:	57                   	push   di
    26d9:	9a 35 68 69 28       	call   0x2869:0x6835
    26de:	8d be fe fe          	lea    di,[bp-0x102]
    26e2:	16                   	push   ss
    26e3:	57                   	push   di
    26e4:	68 ff 00             	push   0xff
    26e7:	9a e7 17 ed 29       	call   0x29ed:0x17e7
    26ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ef:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    26f4:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
    26f9:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    26fc:	06                   	push   es
    26fd:	57                   	push   di
    26fe:	6a 02                	push   0x2
    2700:	6a 02                	push   0x2
    2702:	8d be fe fe          	lea    di,[bp-0x102]
    2706:	16                   	push   ss
    2707:	57                   	push   di
    2708:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    270b:	98                   	cbw
    270c:	8b f8                	mov    di,ax
    270e:	d1 e7                	shl    di,1
    2710:	ff b5 0c 0a          	push   WORD PTR [di+0xa0c]
    2714:	e8 e1 e5             	call   0xcf8
    2717:	c9                   	leave
    2718:	ca 0e 00             	retf   0xe
    271b:	55                   	push   bp
    271c:	89 e5                	mov    bp,sp
    271e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2721:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2725:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    272a:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
    272f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2732:	81 c7 f8 ff          	add    di,0xfff8
    2736:	16                   	push   ss
    2737:	57                   	push   di
    2738:	6a 02                	push   0x2
    273a:	6a 02                	push   0x2
    273c:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    273f:	06                   	push   es
    2740:	57                   	push   di
    2741:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
    2744:	98                   	cbw
    2745:	8b f8                	mov    di,ax
    2747:	d1 e7                	shl    di,1
    2749:	ff b5 12 0a          	push   WORD PTR [di+0xa12]
    274d:	e8 a8 e5             	call   0xcf8
    2750:	c9                   	leave
    2751:	c2 08 00             	ret    0x8
    2754:	00 00                	add    BYTE PTR [bx+si],al
    2756:	00 99 2a 3e          	add    BYTE PTR [bx+di+0x3e2a],bl
    275a:	28 c8                	sub    al,cl
    275c:	12 02                	adc    al,BYTE PTR [bp+si]
    275e:	00 8c d3 8e          	add    BYTE PTR [si-0x712d],cl
    2762:	c3                   	ret
    2763:	8c db                	mov    bx,ds
    2765:	fc                   	cld
    2766:	8d 7e f8             	lea    di,[bp-0x8]
    2769:	c5 76 0c             	lds    si,DWORD PTR [bp+0xc]
    276c:	b9 08 00             	mov    cx,0x8
    276f:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2771:	8e db                	mov    ds,bx
    2773:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    2777:	74 1b                	je     0x2794
    2779:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    277c:	26 ff b5 47 01       	push   WORD PTR es:[di+0x147]
    2781:	26 ff b5 45 01       	push   WORD PTR es:[di+0x145]
    2786:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    278b:	06                   	push   es
    278c:	57                   	push   di
    278d:	9a 99 20 a9 27       	call   0x27a9:0x2099
    2792:	eb 17                	jmp    0x27ab
    2794:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2797:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    279b:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    279f:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    27a4:	06                   	push   es
    27a5:	57                   	push   di
    27a6:	9a 99 20 db 27       	call   0x27db:0x2099
    27ab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27ae:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    27b3:	89 be ee fe          	mov    WORD PTR [bp-0x112],di
    27b7:	8c 86 f0 fe          	mov    WORD PTR [bp-0x110],es
    27bb:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    27bf:	74 1e                	je     0x27df
    27c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27c4:	26 ff b5 4b 01       	push   WORD PTR es:[di+0x14b]
    27c9:	26 ff b5 49 01       	push   WORD PTR es:[di+0x149]
    27ce:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    27d2:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    27d6:	06                   	push   es
    27d7:	57                   	push   di
    27d8:	9a 84 16 f7 27       	call   0x27f7:0x1684
    27dd:	eb 1a                	jmp    0x27f9
    27df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e2:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    27e6:	26 ff 75 38          	push   WORD PTR es:[di+0x38]
    27ea:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    27ee:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    27f2:	06                   	push   es
    27f3:	57                   	push   di
    27f4:	9a 84 16 aa 28       	call   0x28aa:0x1684
    27f9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27fc:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    2801:	30 e4                	xor    ah,ah
    2803:	31 d2                	xor    dx,dx
    2805:	29 46 10             	sub    WORD PTR [bp+0x10],ax
    2808:	19 56 12             	sbb    WORD PTR [bp+0x12],dx
    280b:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    2810:	30 e4                	xor    ah,ah
    2812:	31 d2                	xor    dx,dx
    2814:	29 46 14             	sub    WORD PTR [bp+0x14],ax
    2817:	19 56 16             	sbb    WORD PTR [bp+0x16],dx
    281a:	83 7e 12 00          	cmp    WORD PTR [bp+0x12],0x0
    281e:	7c 08                	jl     0x2828
    2820:	7f 5f                	jg     0x2881
    2822:	83 7e 10 00          	cmp    WORD PTR [bp+0x10],0x0
    2826:	73 59                	jae    0x2881
    2828:	83 7e 16 00          	cmp    WORD PTR [bp+0x16],0x0
    282c:	7f 08                	jg     0x2836
    282e:	7c 43                	jl     0x2873
    2830:	83 7e 14 00          	cmp    WORD PTR [bp+0x14],0x0
    2834:	72 3d                	jb     0x2873
    2836:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2839:	06                   	push   es
    283a:	57                   	push   di
    283b:	9a 19 19 5e 28       	call   0x285e:0x1919
    2840:	99                   	cwd
    2841:	3b 56 16             	cmp    dx,WORD PTR [bp+0x16]
    2844:	7f 07                	jg     0x284d
    2846:	7c 2b                	jl     0x2873
    2848:	3b 46 14             	cmp    ax,WORD PTR [bp+0x14]
    284b:	76 26                	jbe    0x2873
    284d:	8d be ee fd          	lea    di,[bp-0x212]
    2851:	16                   	push   ss
    2852:	57                   	push   di
    2853:	ff 76 14             	push   WORD PTR [bp+0x14]
    2856:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2859:	06                   	push   es
    285a:	57                   	push   di
    285b:	9a 33 19 df 29       	call   0x29df:0x1933
    2860:	89 c7                	mov    di,ax
    2862:	8e c2                	mov    es,dx
    2864:	06                   	push   es
    2865:	57                   	push   di
    2866:	9a d2 67 e0 28       	call   0x28e0:0x67d2
    286b:	6a 00                	push   0x0
    286d:	55                   	push   bp
    286e:	e8 aa fe             	call   0x271b
    2871:	eb 0b                	jmp    0x287e
    2873:	bf 54 27             	mov    di,0x2754
    2876:	0e                   	push   cs
    2877:	57                   	push   di
    2878:	6a 00                	push   0x0
    287a:	55                   	push   bp
    287b:	e8 9d fe             	call   0x271b
    287e:	e9 84 02             	jmp    0x2b05
    2881:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2884:	26 8b 85 5d 01       	mov    ax,WORD PTR es:[di+0x15d]
    2889:	26 0b 85 5f 01       	or     ax,WORD PTR es:[di+0x15f]
    288e:	74 0c                	je     0x289c
    2890:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2895:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    289a:	75 13                	jne    0x28af
    289c:	8d 7e f8             	lea    di,[bp-0x8]
    289f:	16                   	push   ss
    28a0:	57                   	push   di
    28a1:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    28a5:	06                   	push   es
    28a6:	57                   	push   di
    28a7:	9a e5 1c d1 28       	call   0x28d1:0x1ce5
    28ac:	e9 56 02             	jmp    0x2b05
    28af:	83 7e 16 00          	cmp    WORD PTR [bp+0x16],0x0
    28b3:	7c 0e                	jl     0x28c3
    28b5:	7e 03                	jle    0x28ba
    28b7:	e9 dd 00             	jmp    0x2997
    28ba:	83 7e 14 00          	cmp    WORD PTR [bp+0x14],0x0
    28be:	72 03                	jb     0x28c3
    28c0:	e9 d4 00             	jmp    0x2997
    28c3:	8d 7e f8             	lea    di,[bp-0x8]
    28c6:	16                   	push   ss
    28c7:	57                   	push   di
    28c8:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    28cc:	06                   	push   es
    28cd:	57                   	push   di
    28ce:	9a e5 1c 7b 29       	call   0x297b:0x1ce5
    28d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28d6:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    28db:	06                   	push   es
    28dc:	57                   	push   di
    28dd:	9a cd 78 05 29       	call   0x2905:0x78cd
    28e2:	99                   	cwd
    28e3:	3b 56 12             	cmp    dx,WORD PTR [bp+0x12]
    28e6:	74 03                	je     0x28eb
    28e8:	e9 a9 00             	jmp    0x2994
    28eb:	3b 46 10             	cmp    ax,WORD PTR [bp+0x10]
    28ee:	74 03                	je     0x28f3
    28f0:	e9 a1 00             	jmp    0x2994
    28f3:	31 c0                	xor    ax,ax
    28f5:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    28f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28fb:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2900:	06                   	push   es
    2901:	57                   	push   di
    2902:	9a fa 76 18 29       	call   0x2918:0x76fa
    2907:	09 d0                	or     ax,dx
    2909:	74 2b                	je     0x2936
    290b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290e:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2913:	06                   	push   es
    2914:	57                   	push   di
    2915:	9a fa 76 a9 29       	call   0x29a9:0x76fa
    291a:	89 c7                	mov    di,ax
    291c:	8e c2                	mov    es,dx
    291e:	26 8a 45 3a          	mov    al,BYTE PTR es:[di+0x3a]
    2922:	3c 02                	cmp    al,0x2
    2924:	75 07                	jne    0x292d
    2926:	c7 46 f4 01 00       	mov    WORD PTR [bp-0xc],0x1
    292b:	eb 09                	jmp    0x2936
    292d:	3c 03                	cmp    al,0x3
    292f:	75 05                	jne    0x2936
    2931:	c7 46 f4 02 00       	mov    WORD PTR [bp-0xc],0x2
    2936:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2939:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
    293e:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
    2943:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2946:	26 c4 bd 41 01       	les    di,DWORD PTR es:[di+0x141]
    294b:	26 2b 45 04          	sub    ax,WORD PTR es:[di+0x4]
    294f:	48                   	dec    ax
    2950:	48                   	dec    ax
    2951:	50                   	push   ax
    2952:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2955:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    2958:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    295b:	26 c4 bd 41 01       	les    di,DWORD PTR es:[di+0x141]
    2960:	26 2b 45 06          	sub    ax,WORD PTR es:[di+0x6]
    2964:	99                   	cwd
    2965:	b9 02 00             	mov    cx,0x2
    2968:	f7 f9                	idiv   cx
    296a:	50                   	push   ax
    296b:	ff 76 f4             	push   WORD PTR [bp-0xc]
    296e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2971:	26 c4 bd 41 01       	les    di,DWORD PTR es:[di+0x141]
    2976:	06                   	push   es
    2977:	57                   	push   di
    2978:	9a 46 6e 26 2a       	call   0x2a26:0x6e46
    297d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2980:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    2985:	30 e4                	xor    ah,ah
    2987:	31 d2                	xor    dx,dx
    2989:	03 46 10             	add    ax,WORD PTR [bp+0x10]
    298c:	13 56 12             	adc    dx,WORD PTR [bp+0x12]
    298f:	26 89 85 5b 01       	mov    WORD PTR es:[di+0x15b],ax
    2994:	e9 6e 01             	jmp    0x2b05
    2997:	c6 86 f2 fe 00       	mov    BYTE PTR [bp-0x10e],0x0
    299c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    299f:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    29a4:	06                   	push   es
    29a5:	57                   	push   di
    29a6:	9a cd 78 cc 29       	call   0x29cc:0x78cd
    29ab:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    29ae:	b8 55 27             	mov    ax,0x2755
    29b1:	0e                   	push   cs
    29b2:	50                   	push   ax
    29b3:	55                   	push   bp
    29b4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    29b8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    29bc:	ff 76 10             	push   WORD PTR [bp+0x10]
    29bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c2:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    29c7:	06                   	push   es
    29c8:	57                   	push   di
    29c9:	9a 06 79 a9 2a       	call   0x2aa9:0x7906
    29ce:	8d be ee fd          	lea    di,[bp-0x212]
    29d2:	16                   	push   ss
    29d3:	57                   	push   di
    29d4:	ff 76 14             	push   WORD PTR [bp+0x14]
    29d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29da:	06                   	push   es
    29db:	57                   	push   di
    29dc:	9a 21 20 56 2a       	call   0x2a56:0x2021
    29e1:	8d be f2 fe          	lea    di,[bp-0x10e]
    29e5:	16                   	push   ss
    29e6:	57                   	push   di
    29e7:	68 ff 00             	push   0xff
    29ea:	9a e7 17 8b 2a       	call   0x2a8b:0x17e7
    29ef:	ff 76 14             	push   WORD PTR [bp+0x14]
    29f2:	ff 76 10             	push   WORD PTR [bp+0x10]
    29f5:	8d be f2 fe          	lea    di,[bp-0x10e]
    29f9:	16                   	push   ss
    29fa:	57                   	push   di
    29fb:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    29fe:	50                   	push   ax
    29ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a02:	06                   	push   es
    2a03:	57                   	push   di
    2a04:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2a07:	26 ff 9d 98 00       	call   DWORD PTR es:[di+0x98]
    2a0c:	88 46 f3             	mov    BYTE PTR [bp-0xd],al
    2a0f:	80 7e f3 00          	cmp    BYTE PTR [bp-0xd],0x0
    2a13:	74 26                	je     0x2a3b
    2a15:	6a ff                	push   0xffff
    2a17:	6a f2                	push   0xfff2
    2a19:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    2a1d:	26 c4 7d 0f          	les    di,DWORD PTR es:[di+0xf]
    2a21:	06                   	push   es
    2a22:	57                   	push   di
    2a23:	9a 84 16 39 2a       	call   0x2a39:0x1684
    2a28:	6a ff                	push   0xffff
    2a2a:	6a f1                	push   0xfff1
    2a2c:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    2a30:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2a34:	06                   	push   es
    2a35:	57                   	push   di
    2a36:	9a df 0f f8 2a       	call   0x2af8:0xfdf
    2a3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a3e:	26 80 bd 59 01 00    	cmp    BYTE PTR es:[di+0x159],0x0
    2a44:	74 22                	je     0x2a68
    2a46:	8d 7e f8             	lea    di,[bp-0x8]
    2a49:	16                   	push   ss
    2a4a:	57                   	push   di
    2a4b:	ff 76 14             	push   WORD PTR [bp+0x14]
    2a4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a51:	06                   	push   es
    2a52:	57                   	push   di
    2a53:	9a cd 1f 66 2a       	call   0x2a66:0x1fcd
    2a58:	52                   	push   dx
    2a59:	50                   	push   ax
    2a5a:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2a5d:	50                   	push   ax
    2a5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a61:	06                   	push   es
    2a62:	57                   	push   di
    2a63:	9a af 26 78 2a       	call   0x2a78:0x26af
    2a68:	8d 7e f8             	lea    di,[bp-0x8]
    2a6b:	16                   	push   ss
    2a6c:	57                   	push   di
    2a6d:	ff 76 14             	push   WORD PTR [bp+0x14]
    2a70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a73:	06                   	push   es
    2a74:	57                   	push   di
    2a75:	9a cd 1f 84 2b       	call   0x2b84:0x1fcd
    2a7a:	52                   	push   dx
    2a7b:	50                   	push   ax
    2a7c:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2a7f:	50                   	push   ax
    2a80:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a83:	06                   	push   es
    2a84:	57                   	push   di
    2a85:	b8 dd ff             	mov    ax,0xffdd
    2a88:	9a 6a 20 13 2c       	call   0x2c13:0x206a
    2a8d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2a91:	83 c4 06             	add    sp,0x6
    2a94:	b8 ac 2a             	mov    ax,0x2aac
    2a97:	0e                   	push   cs
    2a98:	50                   	push   ax
    2a99:	ff 76 f6             	push   WORD PTR [bp-0xa]
    2a9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a9f:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2aa4:	06                   	push   es
    2aa5:	57                   	push   di
    2aa6:	9a 06 79 aa 2c       	call   0x2caa:0x7906
    2aab:	cb                   	retf
    2aac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aaf:	26 80 bd 59 01 00    	cmp    BYTE PTR es:[di+0x159],0x0
    2ab5:	74 4e                	je     0x2b05
    2ab7:	80 7e f3 00          	cmp    BYTE PTR [bp-0xd],0x0
    2abb:	74 48                	je     0x2b05
    2abd:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    2ac2:	75 41                	jne    0x2b05
    2ac4:	26 f6 85 54 01 01    	test   BYTE PTR es:[di+0x154],0x1
    2aca:	75 39                	jne    0x2b05
    2acc:	ff 76 08             	push   WORD PTR [bp+0x8]
    2acf:	ff 76 06             	push   WORD PTR [bp+0x6]
    2ad2:	9a 01 18 2d 36       	call   0x362d:0x1801
    2ad7:	89 c7                	mov    di,ax
    2ad9:	8e c2                	mov    es,dx
    2adb:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
    2ae0:	26 8b 95 e6 00       	mov    dx,WORD PTR es:[di+0xe6]
    2ae5:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
    2ae8:	75 1b                	jne    0x2b05
    2aea:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    2aed:	75 16                	jne    0x2b05
    2aef:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    2af3:	06                   	push   es
    2af4:	57                   	push   di
    2af5:	9a d2 21 2c 2b       	call   0x2b2c:0x21d2
    2afa:	50                   	push   ax
    2afb:	8d 7e f8             	lea    di,[bp-0x8]
    2afe:	16                   	push   ss
    2aff:	57                   	push   di
    2b00:	9a ff ff 00 00       	call   0x0:0xffff
    2b05:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    2b09:	74 71                	je     0x2b7c
    2b0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b0e:	26 8b 85 53 01       	mov    ax,WORD PTR es:[di+0x153]
    2b13:	25 60 00             	and    ax,0x60
    2b16:	3d 60 00             	cmp    ax,0x60
    2b19:	75 61                	jne    0x2b7c
    2b1b:	6a ff                	push   0xffff
    2b1d:	6a eb                	push   0xffeb
    2b1f:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    2b23:	26 c4 7d 0b          	les    di,DWORD PTR es:[di+0xb]
    2b27:	06                   	push   es
    2b28:	57                   	push   di
    2b29:	9a da 13 7a 2b       	call   0x2b7a:0x13da
    2b2e:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2b31:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2b34:	48                   	dec    ax
    2b35:	50                   	push   ax
    2b36:	9a 6e 06 4c 2b       	call   0x2b4c:0x66e
    2b3b:	89 86 e2 fe          	mov    WORD PTR [bp-0x11e],ax
    2b3f:	89 96 e4 fe          	mov    WORD PTR [bp-0x11c],dx
    2b43:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2b46:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2b49:	9a 6e 06 5f 2b       	call   0x2b5f:0x66e
    2b4e:	89 86 e6 fe          	mov    WORD PTR [bp-0x11a],ax
    2b52:	89 96 e8 fe          	mov    WORD PTR [bp-0x118],dx
    2b56:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2b59:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2b5c:	9a 6e 06 8e 36       	call   0x368e:0x66e
    2b61:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    2b65:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    2b69:	8d be e2 fe          	lea    di,[bp-0x11e]
    2b6d:	16                   	push   ss
    2b6e:	57                   	push   di
    2b6f:	6a 02                	push   0x2
    2b71:	c4 be ee fe          	les    di,DWORD PTR [bp-0x112]
    2b75:	06                   	push   es
    2b76:	57                   	push   di
    2b77:	9a e1 1d a2 35       	call   0x35a2:0x1de1
    2b7c:	c9                   	leave
    2b7d:	ca 12 00             	retf   0x12
    2b80:	00 00                	add    BYTE PTR [bx+si],al
    2b82:	21 2c                	and    WORD PTR [si],bp
    2b84:	a3 2b c8             	mov    ds:0xc82b,ax
    2b87:	02 00                	add    al,BYTE PTR [bx+si]
    2b89:	00 c4                	add    ah,al
    2b8b:	7e 06                	jle    0x2b93
    2b8d:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2b92:	06                   	push   es
    2b93:	57                   	push   di
    2b94:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2b97:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    2b9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b9e:	06                   	push   es
    2b9f:	57                   	push   di
    2ba0:	9a 19 19 b2 2b       	call   0x2bb2:0x1919
    2ba5:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    2ba8:	7f 0e                	jg     0x2bb8
    2baa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bad:	06                   	push   es
    2bae:	57                   	push   di
    2baf:	9a 19 19 9c 2d       	call   0x2d9c:0x1919
    2bb4:	48                   	dec    ax
    2bb5:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    2bb8:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    2bbc:	7d 05                	jge    0x2bc3
    2bbe:	31 c0                	xor    ax,ax
    2bc0:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    2bc3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bc6:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    2bcb:	30 e4                	xor    ah,ah
    2bcd:	31 d2                	xor    dx,dx
    2bcf:	8b c8                	mov    cx,ax
    2bd1:	8b da                	mov    bx,dx
    2bd3:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    2bd8:	26 8b 95 f4 00       	mov    dx,WORD PTR es:[di+0xf4]
    2bdd:	2b c1                	sub    ax,cx
    2bdf:	1b d3                	sbb    dx,bx
    2be1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2be4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2be7:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    2bea:	75 03                	jne    0x2bef
    2bec:	e9 a2 00             	jmp    0x2c91
    2bef:	26 80 bd 58 01 00    	cmp    BYTE PTR es:[di+0x158],0x0
    2bf5:	75 64                	jne    0x2c5b
    2bf7:	26 c6 85 58 01 01    	mov    BYTE PTR es:[di+0x158],0x1
    2bfd:	b8 80 2b             	mov    ax,0x2b80
    2c00:	0e                   	push   cs
    2c01:	50                   	push   ax
    2c02:	55                   	push   bp
    2c03:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2c07:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2c0b:	06                   	push   es
    2c0c:	57                   	push   di
    2c0d:	b8 de ff             	mov    ax,0xffde
    2c10:	9a 6a 20 8f 2c       	call   0x2c8f:0x206a
    2c15:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2c19:	83 c4 06             	add    sp,0x6
    2c1c:	b8 2b 2c             	mov    ax,0x2c2b
    2c1f:	0e                   	push   cs
    2c20:	50                   	push   ax
    2c21:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c24:	26 c6 85 58 01 00    	mov    BYTE PTR es:[di+0x158],0x0
    2c2a:	cb                   	retf
    2c2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c2e:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    2c33:	30 e4                	xor    ah,ah
    2c35:	31 d2                	xor    dx,dx
    2c37:	8b c8                	mov    cx,ax
    2c39:	8b da                	mov    bx,dx
    2c3b:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
    2c40:	26 8b 95 f4 00       	mov    dx,WORD PTR es:[di+0xf4]
    2c45:	2b c1                	sub    ax,cx
    2c47:	1b d3                	sbb    dx,bx
    2c49:	8b c8                	mov    cx,ax
    2c4b:	8b da                	mov    bx,dx
    2c4d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2c50:	99                   	cwd
    2c51:	3b d3                	cmp    dx,bx
    2c53:	75 04                	jne    0x2c59
    2c55:	3b c1                	cmp    ax,cx
    2c57:	74 02                	je     0x2c5b
    2c59:	eb 36                	jmp    0x2c91
    2c5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c5e:	26 f6 85 53 01 02    	test   BYTE PTR es:[di+0x153],0x2
    2c64:	75 07                	jne    0x2c6d
    2c66:	06                   	push   es
    2c67:	57                   	push   di
    2c68:	9a 32 25 82 2c       	call   0x2c82:0x2532
    2c6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c70:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    2c75:	30 e4                	xor    ah,ah
    2c77:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    2c7a:	99                   	cwd
    2c7b:	52                   	push   dx
    2c7c:	50                   	push   ax
    2c7d:	06                   	push   es
    2c7e:	57                   	push   di
    2c7f:	9a e1 6f 18 2e       	call   0x2e18:0x6fe1
    2c84:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c87:	06                   	push   es
    2c88:	57                   	push   di
    2c89:	b8 df ff             	mov    ax,0xffdf
    2c8c:	9a 6a 20 ae 2e       	call   0x2eae:0x206a
    2c91:	c9                   	leave
    2c92:	ca 06 00             	retf   0x6
    2c95:	c8 04 00 00          	enter  0x4,0x0
    2c99:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2c9c:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2ca0:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2ca5:	06                   	push   es
    2ca6:	57                   	push   di
    2ca7:	9a fa 76 ed 2c       	call   0x2ced:0x76fa
    2cac:	89 c7                	mov    di,ax
    2cae:	8e c2                	mov    es,dx
    2cb0:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2cb3:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2cb6:	26 80 7d 3a 03       	cmp    BYTE PTR es:[di+0x3a],0x3
    2cbb:	75 34                	jne    0x2cf1
    2cbd:	26 80 7d 3e 00       	cmp    BYTE PTR es:[di+0x3e],0x0
    2cc2:	75 2d                	jne    0x2cf1
    2cc4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2cc7:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2ccb:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2cd0:	26 80 7d 1c 00       	cmp    BYTE PTR es:[di+0x1c],0x0
    2cd5:	75 1a                	jne    0x2cf1
    2cd7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2cda:	26 80 7d 39 00       	cmp    BYTE PTR es:[di+0x39],0x0
    2cdf:	74 04                	je     0x2ce5
    2ce1:	eb 42                	jmp    0x2d25
    2ce3:	eb 0a                	jmp    0x2cef
    2ce5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2ce8:	06                   	push   es
    2ce9:	57                   	push   di
    2cea:	9a 8b 55 f9 2c       	call   0x2cf9:0x558b
    2cef:	eb 0a                	jmp    0x2cfb
    2cf1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2cf4:	06                   	push   es
    2cf5:	57                   	push   di
    2cf6:	9a ec 4e 23 2d       	call   0x2d23:0x4eec
    2cfb:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2cfe:	26 80 7d 39 00       	cmp    BYTE PTR es:[di+0x39],0x0
    2d03:	74 20                	je     0x2d25
    2d05:	26 80 7d 3d 00       	cmp    BYTE PTR es:[di+0x3d],0x0
    2d0a:	74 19                	je     0x2d25
    2d0c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2d0f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d13:	26 f6 85 53 01 01    	test   BYTE PTR es:[di+0x153],0x1
    2d19:	74 0a                	je     0x2d25
    2d1b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2d1e:	06                   	push   es
    2d1f:	57                   	push   di
    2d20:	9a 49 50 3e 2d       	call   0x2d3e:0x5049
    2d25:	c9                   	leave
    2d26:	c2 02 00             	ret    0x2
    2d29:	c8 04 00 00          	enter  0x4,0x0
    2d2d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2d30:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d34:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2d39:	06                   	push   es
    2d3a:	57                   	push   di
    2d3b:	9a fa 76 7a 2d       	call   0x2d7a:0x76fa
    2d40:	89 c7                	mov    di,ax
    2d42:	8e c2                	mov    es,dx
    2d44:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2d47:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    2d4a:	26 80 7d 3a 03       	cmp    BYTE PTR es:[di+0x3a],0x3
    2d4f:	75 2d                	jne    0x2d7e
    2d51:	26 80 7d 3e 00       	cmp    BYTE PTR es:[di+0x3e],0x0
    2d56:	75 26                	jne    0x2d7e
    2d58:	26 80 7d 39 00       	cmp    BYTE PTR es:[di+0x39],0x0
    2d5d:	74 1f                	je     0x2d7e
    2d5f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2d62:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d66:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2d6b:	26 80 7d 1c 00       	cmp    BYTE PTR es:[di+0x1c],0x0
    2d70:	75 0c                	jne    0x2d7e
    2d72:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2d75:	06                   	push   es
    2d76:	57                   	push   di
    2d77:	9a 8b 55 86 2d       	call   0x2d86:0x558b
    2d7c:	eb 0a                	jmp    0x2d88
    2d7e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2d81:	06                   	push   es
    2d82:	57                   	push   di
    2d83:	9a ff 4e 09 2f       	call   0x2f09:0x4eff
    2d88:	c9                   	leave
    2d89:	c2 02 00             	ret    0x2
    2d8c:	c8 04 00 00          	enter  0x4,0x0
    2d90:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2d93:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2d97:	06                   	push   es
    2d98:	57                   	push   di
    2d99:	9a da 19 c1 2d       	call   0x2dc1:0x19da
    2d9e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2da1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2da4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2da7:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    2dab:	74 05                	je     0x2db2
    2dad:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2db0:	eb 03                	jmp    0x2db5
    2db2:	ff 4e fe             	dec    WORD PTR [bp-0x2]
    2db5:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2db8:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2dbc:	06                   	push   es
    2dbd:	57                   	push   di
    2dbe:	9a 19 19 ef 2d       	call   0x2def:0x1919
    2dc3:	3b 46 fe             	cmp    ax,WORD PTR [bp-0x2]
    2dc6:	7f 0e                	jg     0x2dd6
    2dc8:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2dcb:	57                   	push   di
    2dcc:	e8 c6 fe             	call   0x2c95
    2dcf:	31 c0                	xor    ax,ax
    2dd1:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2dd4:	eb 1f                	jmp    0x2df5
    2dd6:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2dda:	7d 19                	jge    0x2df5
    2ddc:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2ddf:	57                   	push   di
    2de0:	e8 46 ff             	call   0x2d29
    2de3:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2de6:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2dea:	06                   	push   es
    2deb:	57                   	push   di
    2dec:	9a 19 19 2d 2e       	call   0x2e2d:0x1919
    2df1:	48                   	dec    ax
    2df2:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2df5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2df8:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2dfb:	75 02                	jne    0x2dff
    2dfd:	eb 35                	jmp    0x2e34
    2dff:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2e02:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2e06:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    2e0b:	30 e4                	xor    ah,ah
    2e0d:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    2e10:	99                   	cwd
    2e11:	52                   	push   dx
    2e12:	50                   	push   ax
    2e13:	06                   	push   es
    2e14:	57                   	push   di
    2e15:	9a 14 6f f3 30       	call   0x30f3:0x6f14
    2e1a:	08 c0                	or     al,al
    2e1c:	74 13                	je     0x2e31
    2e1e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e21:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2e24:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2e28:	06                   	push   es
    2e29:	57                   	push   di
    2e2a:	9a 86 2b 8e 2f       	call   0x2f8e:0x2b86
    2e2f:	eb 03                	jmp    0x2e34
    2e31:	e9 73 ff             	jmp    0x2da7
    2e34:	c9                   	leave
    2e35:	c2 04 00             	ret    0x4
    2e38:	c8 02 01 00          	enter  0x102,0x0
    2e3c:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    2e3f:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    2e43:	26 f6 85 54 01 04    	test   BYTE PTR es:[di+0x154],0x4
    2e49:	74 24                	je     0x2e6f
    2e4b:	8d be fe fe          	lea    di,[bp-0x102]
    2e4f:	16                   	push   ss
    2e50:	57                   	push   di
    2e51:	68 4d f2             	push   0xf24d
    2e54:	9a 2b 09 ff ff       	call   0xffff:0x92b
    2e59:	6a 03                	push   0x3
    2e5b:	6a 0c                	push   0xc
    2e5d:	6a 00                	push   0x0
    2e5f:	6a 00                	push   0x0
    2e61:	9a 8a 38 ff ff       	call   0xffff:0x388a
    2e66:	3d 02 00             	cmp    ax,0x2
    2e69:	75 04                	jne    0x2e6f
    2e6b:	b0 00                	mov    al,0x0
    2e6d:	eb 02                	jmp    0x2e71
    2e6f:	b0 01                	mov    al,0x1
    2e71:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2e74:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2e77:	c9                   	leave
    2e78:	c2 02 00             	ret    0x2
    2e7b:	38 2f                	cmp    BYTE PTR [bx],ch
    2e7d:	57                   	push   di
    2e7e:	2f                   	das
    2e7f:	b6 2f                	mov    dh,0x2f
    2e81:	aa                   	stos   BYTE PTR es:[di],al
    2e82:	2f                   	das
    2e83:	84 2f                	test   BYTE PTR [bx],ch
    2e85:	38 2f                	cmp    BYTE PTR [bx],ch
    2e87:	92                   	xchg   dx,ax
    2e88:	2f                   	das
    2e89:	57                   	push   di
    2e8a:	2f                   	das
    2e8b:	e9 2f e9             	jmp    0x17bd
    2e8e:	2f                   	das
    2e8f:	e9 2f e9             	jmp    0x17c1
    2e92:	2f                   	das
    2e93:	e9 2f c2             	jmp    0xf0c5
    2e96:	2f                   	das
    2e97:	c8 0c 00 00          	enter  0xc,0x0
    2e9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e9e:	81 c7 b0 00          	add    di,0xb0
    2ea2:	06                   	push   es
    2ea3:	57                   	push   di
    2ea4:	8d 7e f8             	lea    di,[bp-0x8]
    2ea7:	16                   	push   ss
    2ea8:	57                   	push   di
    2ea9:	6a 08                	push   0x8
    2eab:	9a 1b 16 f3 2e       	call   0x2ef3:0x161b
    2eb0:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    2eb3:	09 c0                	or     ax,ax
    2eb5:	74 18                	je     0x2ecf
    2eb7:	ff 76 08             	push   WORD PTR [bp+0x8]
    2eba:	ff 76 06             	push   WORD PTR [bp+0x6]
    2ebd:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2ec0:	06                   	push   es
    2ec1:	57                   	push   di
    2ec2:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2ec5:	50                   	push   ax
    2ec6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2ec9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2ecc:	ff 5e f8             	call   DWORD PTR [bp-0x8]
    2ecf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed2:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2ed7:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    2edc:	74 1b                	je     0x2ef9
    2ede:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2ee1:	26 ff 35             	push   WORD PTR es:[di]
    2ee4:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2ee7:	50                   	push   ax
    2ee8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eeb:	06                   	push   es
    2eec:	57                   	push   di
    2eed:	b8 ec ff             	mov    ax,0xffec
    2ef0:	9a 6a 20 fc 31       	call   0x31fc:0x206a
    2ef5:	08 c0                	or     al,al
    2ef7:	75 03                	jne    0x2efc
    2ef9:	e9 95 02             	jmp    0x3191
    2efc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eff:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2f04:	06                   	push   es
    2f05:	57                   	push   di
    2f06:	9a fa 76 45 2f       	call   0x2f45:0x76fa
    2f0b:	89 c7                	mov    di,ax
    2f0d:	8e c2                	mov    es,dx
    2f0f:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    2f12:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    2f15:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    2f19:	75 03                	jne    0x2f1e
    2f1b:	e9 ce 00             	jmp    0x2fec
    2f1e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2f21:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2f24:	2d 21 00             	sub    ax,0x21
    2f27:	3d 0d 00             	cmp    ax,0xd
    2f2a:	76 03                	jbe    0x2f2f
    2f2c:	e9 ba 00             	jmp    0x2fe9
    2f2f:	89 c3                	mov    bx,ax
    2f31:	d1 e3                	shl    bx,1
    2f33:	2e ff a7 7b 2e       	jmp    WORD PTR cs:[bx+0x2e7b]
    2f38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f3b:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2f40:	06                   	push   es
    2f41:	57                   	push   di
    2f42:	9a cd 78 52 2f       	call   0x2f52:0x78cd
    2f47:	f7 d8                	neg    ax
    2f49:	50                   	push   ax
    2f4a:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2f4d:	06                   	push   es
    2f4e:	57                   	push   di
    2f4f:	9a c7 4d 64 2f       	call   0x2f64:0x4dc7
    2f54:	e9 92 00             	jmp    0x2fe9
    2f57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f5a:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2f5f:	06                   	push   es
    2f60:	57                   	push   di
    2f61:	9a cd 78 80 2f       	call   0x2f80:0x78cd
    2f66:	8b d0                	mov    dx,ax
    2f68:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f6b:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    2f70:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2f74:	2b c2                	sub    ax,dx
    2f76:	48                   	dec    ax
    2f77:	50                   	push   ax
    2f78:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2f7b:	06                   	push   es
    2f7c:	57                   	push   di
    2f7d:	9a c7 4d 9a 2f       	call   0x2f9a:0x4dc7
    2f82:	eb 65                	jmp    0x2fe9
    2f84:	6a 00                	push   0x0
    2f86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f89:	06                   	push   es
    2f8a:	57                   	push   di
    2f8b:	9a 86 2b a6 2f       	call   0x2fa6:0x2b86
    2f90:	eb 57                	jmp    0x2fe9
    2f92:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2f95:	06                   	push   es
    2f96:	57                   	push   di
    2f97:	9a 32 3b b2 2f       	call   0x2fb2:0x3b32
    2f9c:	48                   	dec    ax
    2f9d:	50                   	push   ax
    2f9e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fa1:	06                   	push   es
    2fa2:	57                   	push   di
    2fa3:	9a 86 2b 28 30       	call   0x3028:0x2b86
    2fa8:	eb 3f                	jmp    0x2fe9
    2faa:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2fad:	06                   	push   es
    2fae:	57                   	push   di
    2faf:	9a cd 4c be 2f       	call   0x2fbe:0x4ccd
    2fb4:	eb 33                	jmp    0x2fe9
    2fb6:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2fb9:	06                   	push   es
    2fba:	57                   	push   di
    2fbb:	9a 4a 4d e7 2f       	call   0x2fe7:0x4d4a
    2fc0:	eb 27                	jmp    0x2fe9
    2fc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc5:	26 80 bd 4d 01 00    	cmp    BYTE PTR es:[di+0x14d],0x0
    2fcb:	75 1c                	jne    0x2fe9
    2fcd:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2fd0:	26 80 7d 3d 00       	cmp    BYTE PTR es:[di+0x3d],0x0
    2fd5:	74 12                	je     0x2fe9
    2fd7:	55                   	push   bp
    2fd8:	e8 5d fe             	call   0x2e38
    2fdb:	08 c0                	or     al,al
    2fdd:	74 0a                	je     0x2fe9
    2fdf:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2fe2:	06                   	push   es
    2fe3:	57                   	push   di
    2fe4:	9a 22 56 75 30       	call   0x3075:0x5622
    2fe9:	e9 a5 01             	jmp    0x3191
    2fec:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2fef:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2ff2:	3d 26 00             	cmp    ax,0x26
    2ff5:	75 07                	jne    0x2ffe
    2ff7:	55                   	push   bp
    2ff8:	e8 2e fd             	call   0x2d29
    2ffb:	e9 93 01             	jmp    0x3191
    2ffe:	3d 28 00             	cmp    ax,0x28
    3001:	75 07                	jne    0x300a
    3003:	55                   	push   bp
    3004:	e8 8e fc             	call   0x2c95
    3007:	e9 87 01             	jmp    0x3191
    300a:	3d 25 00             	cmp    ax,0x25
    300d:	75 2a                	jne    0x3039
    300f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3012:	26 f6 85 54 01 01    	test   BYTE PTR es:[di+0x154],0x1
    3018:	74 06                	je     0x3020
    301a:	55                   	push   bp
    301b:	e8 0b fd             	call   0x2d29
    301e:	eb 16                	jmp    0x3036
    3020:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3023:	06                   	push   es
    3024:	57                   	push   di
    3025:	9a da 19 34 30       	call   0x3034:0x19da
    302a:	48                   	dec    ax
    302b:	50                   	push   ax
    302c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    302f:	06                   	push   es
    3030:	57                   	push   di
    3031:	9a 86 2b 57 30       	call   0x3057:0x2b86
    3036:	e9 58 01             	jmp    0x3191
    3039:	3d 27 00             	cmp    ax,0x27
    303c:	75 2a                	jne    0x3068
    303e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3041:	26 f6 85 54 01 01    	test   BYTE PTR es:[di+0x154],0x1
    3047:	74 06                	je     0x304f
    3049:	55                   	push   bp
    304a:	e8 48 fc             	call   0x2c95
    304d:	eb 16                	jmp    0x3065
    304f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3052:	06                   	push   es
    3053:	57                   	push   di
    3054:	9a da 19 63 30       	call   0x3063:0x19da
    3059:	40                   	inc    ax
    305a:	50                   	push   ax
    305b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    305e:	06                   	push   es
    305f:	57                   	push   di
    3060:	9a 86 2b 9d 30       	call   0x309d:0x2b86
    3065:	e9 29 01             	jmp    0x3191
    3068:	3d 24 00             	cmp    ax,0x24
    306b:	75 35                	jne    0x30a2
    306d:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3070:	06                   	push   es
    3071:	57                   	push   di
    3072:	9a 32 3b 8f 30       	call   0x308f:0x3b32
    3077:	3d 01 00             	cmp    ax,0x1
    307a:	74 0b                	je     0x3087
    307c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    307f:	26 f6 85 54 01 01    	test   BYTE PTR es:[di+0x154],0x1
    3085:	74 0c                	je     0x3093
    3087:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    308a:	06                   	push   es
    308b:	57                   	push   di
    308c:	9a cd 4c af 30       	call   0x30af:0x4ccd
    3091:	eb 0c                	jmp    0x309f
    3093:	6a 00                	push   0x0
    3095:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3098:	06                   	push   es
    3099:	57                   	push   di
    309a:	9a 86 2b e1 30       	call   0x30e1:0x2b86
    309f:	e9 ef 00             	jmp    0x3191
    30a2:	3d 23 00             	cmp    ax,0x23
    30a5:	75 3f                	jne    0x30e6
    30a7:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    30aa:	06                   	push   es
    30ab:	57                   	push   di
    30ac:	9a 32 3b c9 30       	call   0x30c9:0x3b32
    30b1:	3d 01 00             	cmp    ax,0x1
    30b4:	74 0b                	je     0x30c1
    30b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30b9:	26 f6 85 54 01 01    	test   BYTE PTR es:[di+0x154],0x1
    30bf:	74 0c                	je     0x30cd
    30c1:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    30c4:	06                   	push   es
    30c5:	57                   	push   di
    30c6:	9a 4a 4d d5 30       	call   0x30d5:0x4d4a
    30cb:	eb 16                	jmp    0x30e3
    30cd:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    30d0:	06                   	push   es
    30d1:	57                   	push   di
    30d2:	9a 32 3b fe 30       	call   0x30fe:0x3b32
    30d7:	48                   	dec    ax
    30d8:	50                   	push   ax
    30d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30dc:	06                   	push   es
    30dd:	57                   	push   di
    30de:	9a 86 2b 6a 31       	call   0x316a:0x2b86
    30e3:	e9 ab 00             	jmp    0x3191
    30e6:	3d 22 00             	cmp    ax,0x22
    30e9:	75 18                	jne    0x3103
    30eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30ee:	06                   	push   es
    30ef:	57                   	push   di
    30f0:	9a 88 6f 10 31       	call   0x3110:0x6f88
    30f5:	50                   	push   ax
    30f6:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    30f9:	06                   	push   es
    30fa:	57                   	push   di
    30fb:	9a c7 4d 1d 31       	call   0x311d:0x4dc7
    3100:	e9 8e 00             	jmp    0x3191
    3103:	3d 21 00             	cmp    ax,0x21
    3106:	75 19                	jne    0x3121
    3108:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    310b:	06                   	push   es
    310c:	57                   	push   di
    310d:	9a 88 6f 7c 31       	call   0x317c:0x6f88
    3112:	f7 d8                	neg    ax
    3114:	50                   	push   ax
    3115:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3118:	06                   	push   es
    3119:	57                   	push   di
    311a:	9a c7 4d 39 31       	call   0x3139:0x4dc7
    311f:	eb 70                	jmp    0x3191
    3121:	3d 2d 00             	cmp    ax,0x2d
    3124:	75 17                	jne    0x313d
    3126:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3129:	26 80 bd 4d 01 00    	cmp    BYTE PTR es:[di+0x14d],0x0
    312f:	75 0a                	jne    0x313b
    3131:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3134:	06                   	push   es
    3135:	57                   	push   di
    3136:	9a 99 4f 5e 33       	call   0x335e:0x4f99
    313b:	eb 54                	jmp    0x3191
    313d:	3d 09 00             	cmp    ax,0x9
    3140:	75 16                	jne    0x3158
    3142:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    3146:	75 0e                	jne    0x3156
    3148:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    314c:	b0 00                	mov    al,0x0
    314e:	75 01                	jne    0x3151
    3150:	40                   	inc    ax
    3151:	50                   	push   ax
    3152:	55                   	push   bp
    3153:	e8 36 fc             	call   0x2d8c
    3156:	eb 39                	jmp    0x3191
    3158:	3d 1b 00             	cmp    ax,0x1b
    315b:	75 23                	jne    0x3180
    315d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3160:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    3165:	06                   	push   es
    3166:	57                   	push   di
    3167:	9a 55 0c dc 31       	call   0x31dc:0xc55
    316c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    316f:	26 f6 85 53 01 02    	test   BYTE PTR es:[di+0x153],0x2
    3175:	75 07                	jne    0x317e
    3177:	06                   	push   es
    3178:	57                   	push   di
    3179:	9a 32 25 8f 31       	call   0x318f:0x2532
    317e:	eb 11                	jmp    0x3191
    3180:	3d 71 00             	cmp    ax,0x71
    3183:	75 0c                	jne    0x3191
    3185:	6a 01                	push   0x1
    3187:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    318a:	06                   	push   es
    318b:	57                   	push   di
    318c:	9a e4 72 ca 31       	call   0x31ca:0x72e4
    3191:	c9                   	leave
    3192:	ca 0a 00             	retf   0xa
    3195:	55                   	push   bp
    3196:	89 e5                	mov    bp,sp
    3198:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    319b:	26 f6 85 53 01 02    	test   BYTE PTR es:[di+0x153],0x2
    31a1:	75 1a                	jne    0x31bd
    31a3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    31a6:	26 80 3d 0d          	cmp    BYTE PTR es:[di],0xd
    31aa:	75 11                	jne    0x31bd
    31ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31af:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    31b4:	06                   	push   es
    31b5:	57                   	push   di
    31b6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    31b9:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    31bd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    31c0:	06                   	push   es
    31c1:	57                   	push   di
    31c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31c5:	06                   	push   es
    31c6:	57                   	push   di
    31c7:	9a b6 63 0f 32       	call   0x320f:0x63b6
    31cc:	c9                   	leave
    31cd:	ca 08 00             	retf   0x8
    31d0:	c8 10 00 00          	enter  0x10,0x0
    31d4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31d7:	06                   	push   es
    31d8:	57                   	push   di
    31d9:	9a f5 21 12 33       	call   0x3312:0x21f5
    31de:	08 c0                	or     al,al
    31e0:	75 03                	jne    0x31e5
    31e2:	e9 86 01             	jmp    0x336b
    31e5:	f6 46 0e 40          	test   BYTE PTR [bp+0xe],0x40
    31e9:	74 16                	je     0x3201
    31eb:	80 7e 10 00          	cmp    BYTE PTR [bp+0x10],0x0
    31ef:	75 10                	jne    0x3201
    31f1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31f4:	06                   	push   es
    31f5:	57                   	push   di
    31f6:	b8 fd ff             	mov    ax,0xfffd
    31f9:	9a 6a 20 4f 32       	call   0x324f:0x206a
    31fe:	e9 6a 01             	jmp    0x336b
    3201:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3204:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3207:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    320a:	06                   	push   es
    320b:	57                   	push   di
    320c:	9a 97 28 2b 32       	call   0x322b:0x2897
    3211:	08 c0                	or     al,al
    3213:	74 1b                	je     0x3230
    3215:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    3218:	50                   	push   ax
    3219:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    321c:	50                   	push   ax
    321d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3220:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3223:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3226:	06                   	push   es
    3227:	57                   	push   di
    3228:	9a 0f 64 43 32       	call   0x3243:0x640f
    322d:	e9 3b 01             	jmp    0x336b
    3230:	8d 7e f0             	lea    di,[bp-0x10]
    3233:	16                   	push   ss
    3234:	57                   	push   di
    3235:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3238:	ff 76 0a             	push   WORD PTR [bp+0xa]
    323b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    323e:	06                   	push   es
    323f:	57                   	push   di
    3240:	9a 44 28 91 32       	call   0x3291:0x2844
    3245:	8d 7e f8             	lea    di,[bp-0x8]
    3248:	16                   	push   ss
    3249:	57                   	push   di
    324a:	6a 08                	push   0x8
    324c:	9a 1b 16 ff ff       	call   0xffff:0x161b
    3251:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3254:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    3259:	75 08                	jne    0x3263
    325b:	26 f6 85 53 01 10    	test   BYTE PTR es:[di+0x153],0x10
    3261:	74 33                	je     0x3296
    3263:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3266:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    326b:	30 e4                	xor    ah,ah
    326d:	31 d2                	xor    dx,dx
    326f:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    3272:	7f 07                	jg     0x327b
    3274:	7c 20                	jl     0x3296
    3276:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3279:	76 1b                	jbe    0x3296
    327b:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    327e:	50                   	push   ax
    327f:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    3282:	50                   	push   ax
    3283:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3286:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3289:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    328c:	06                   	push   es
    328d:	57                   	push   di
    328e:	9a 0f 64 d8 32       	call   0x32d8:0x640f
    3293:	e9 d5 00             	jmp    0x336b
    3296:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3299:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    329e:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    32a3:	75 03                	jne    0x32a8
    32a5:	e9 c3 00             	jmp    0x336b
    32a8:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    32ab:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    32ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32b1:	26 3b 95 f4 00       	cmp    dx,WORD PTR es:[di+0xf4]
    32b6:	75 22                	jne    0x32da
    32b8:	26 3b 85 f2 00       	cmp    ax,WORD PTR es:[di+0xf2]
    32bd:	75 1b                	jne    0x32da
    32bf:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    32c2:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    32c5:	26 3b 95 f8 00       	cmp    dx,WORD PTR es:[di+0xf8]
    32ca:	75 0e                	jne    0x32da
    32cc:	26 3b 85 f6 00       	cmp    ax,WORD PTR es:[di+0xf6]
    32d1:	75 07                	jne    0x32da
    32d3:	06                   	push   es
    32d4:	57                   	push   di
    32d5:	9a 49 25 25 35       	call   0x3525:0x2549
    32da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32dd:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    32e2:	30 e4                	xor    ah,ah
    32e4:	31 d2                	xor    dx,dx
    32e6:	3b 56 fa             	cmp    dx,WORD PTR [bp-0x6]
    32e9:	7c 07                	jl     0x32f2
    32eb:	7f 27                	jg     0x3314
    32ed:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    32f0:	77 22                	ja     0x3314
    32f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32f5:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    32fa:	30 e4                	xor    ah,ah
    32fc:	31 d2                	xor    dx,dx
    32fe:	8b c8                	mov    cx,ax
    3300:	8b da                	mov    bx,dx
    3302:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3305:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    3308:	2b c1                	sub    ax,cx
    330a:	1b d3                	sbb    dx,bx
    330c:	50                   	push   ax
    330d:	06                   	push   es
    330e:	57                   	push   di
    330f:	9a 86 2b d9 33       	call   0x33d9:0x2b86
    3314:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3317:	26 8a 85 55 01       	mov    al,BYTE PTR es:[di+0x155]
    331c:	30 e4                	xor    ah,ah
    331e:	31 d2                	xor    dx,dx
    3320:	3b 56 fe             	cmp    dx,WORD PTR [bp-0x2]
    3323:	7c 07                	jl     0x332c
    3325:	7f 44                	jg     0x336b
    3327:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    332a:	77 3f                	ja     0x336b
    332c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    332f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3332:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3335:	26 2b 85 f6 00       	sub    ax,WORD PTR es:[di+0xf6]
    333a:	26 1b 95 f8 00       	sbb    dx,WORD PTR es:[di+0xf8]
    333f:	09 d0                	or     ax,dx
    3341:	74 28                	je     0x336b
    3343:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3346:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3349:	26 2b 85 f6 00       	sub    ax,WORD PTR es:[di+0xf6]
    334e:	26 1b 95 f8 00       	sbb    dx,WORD PTR es:[di+0xf8]
    3353:	50                   	push   ax
    3354:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    3359:	06                   	push   es
    335a:	57                   	push   di
    335b:	9a fa 76 69 33       	call   0x3369:0x76fa
    3360:	89 c7                	mov    di,ax
    3362:	8e c2                	mov    es,dx
    3364:	06                   	push   es
    3365:	57                   	push   di
    3366:	9a c7 4d 0a 34       	call   0x340a:0x4dc7
    336b:	c9                   	leave
    336c:	ca 0c 00             	retf   0xc
    336f:	55                   	push   bp
    3370:	89 e5                	mov    bp,sp
    3372:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3375:	26 8b 85 63 01       	mov    ax,WORD PTR es:[di+0x163]
    337a:	09 c0                	or     ax,ax
    337c:	74 15                	je     0x3393
    337e:	ff 76 08             	push   WORD PTR [bp+0x8]
    3381:	ff 76 06             	push   WORD PTR [bp+0x6]
    3384:	26 ff b5 67 01       	push   WORD PTR es:[di+0x167]
    3389:	26 ff b5 65 01       	push   WORD PTR es:[di+0x165]
    338e:	26 ff 9d 61 01       	call   DWORD PTR es:[di+0x161]
    3393:	c9                   	leave
    3394:	ca 04 00             	retf   0x4
    3397:	55                   	push   bp
    3398:	89 e5                	mov    bp,sp
    339a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    339d:	26 8b 85 6b 01       	mov    ax,WORD PTR es:[di+0x16b]
    33a2:	09 c0                	or     ax,ax
    33a4:	74 15                	je     0x33bb
    33a6:	ff 76 08             	push   WORD PTR [bp+0x8]
    33a9:	ff 76 06             	push   WORD PTR [bp+0x6]
    33ac:	26 ff b5 6f 01       	push   WORD PTR es:[di+0x16f]
    33b1:	26 ff b5 6d 01       	push   WORD PTR es:[di+0x16d]
    33b6:	26 ff 9d 69 01       	call   DWORD PTR es:[di+0x169]
    33bb:	c9                   	leave
    33bc:	ca 04 00             	retf   0x4
    33bf:	55                   	push   bp
    33c0:	89 e5                	mov    bp,sp
    33c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33c5:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    33ca:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    33cf:	74 69                	je     0x343a
    33d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33d4:	06                   	push   es
    33d5:	57                   	push   di
    33d6:	9a 19 19 ff 33       	call   0x33ff:0x1919
    33db:	09 c0                	or     ax,ax
    33dd:	7e 5b                	jle    0x343a
    33df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33e2:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    33e7:	30 e4                	xor    ah,ah
    33e9:	31 d2                	xor    dx,dx
    33eb:	8b c8                	mov    cx,ax
    33ed:	8b da                	mov    bx,dx
    33ef:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    33f2:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    33f5:	2b c1                	sub    ax,cx
    33f7:	1b d3                	sbb    dx,bx
    33f9:	50                   	push   ax
    33fa:	06                   	push   es
    33fb:	57                   	push   di
    33fc:	9a 33 19 2d 34       	call   0x342d:0x1933
    3401:	89 c7                	mov    di,ax
    3403:	8e c2                	mov    es,dx
    3405:	06                   	push   es
    3406:	57                   	push   di
    3407:	9a 3c 69 38 34       	call   0x3438:0x693c
    340c:	50                   	push   ax
    340d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3410:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    3415:	30 e4                	xor    ah,ah
    3417:	31 d2                	xor    dx,dx
    3419:	8b c8                	mov    cx,ax
    341b:	8b da                	mov    bx,dx
    341d:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    3420:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    3423:	2b c1                	sub    ax,cx
    3425:	1b d3                	sbb    dx,bx
    3427:	50                   	push   ax
    3428:	06                   	push   es
    3429:	57                   	push   di
    342a:	9a 33 19 6f 34       	call   0x346f:0x1933
    342f:	89 c7                	mov    di,ax
    3431:	8e c2                	mov    es,dx
    3433:	06                   	push   es
    3434:	57                   	push   di
    3435:	9a 22 70 bc 34       	call   0x34bc:0x7022
    343a:	c9                   	leave
    343b:	ca 0c 00             	retf   0xc
    343e:	55                   	push   bp
    343f:	89 e5                	mov    bp,sp
    3441:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3444:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3447:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    344a:	50                   	push   ax
    344b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    344e:	06                   	push   es
    344f:	57                   	push   di
    3450:	9a 32 16 71 35       	call   0x3571:0x1632
    3455:	80 7e 0a 01          	cmp    BYTE PTR [bp+0xa],0x1
    3459:	75 2e                	jne    0x3489
    345b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    345e:	26 8b 85 5d 01       	mov    ax,WORD PTR es:[di+0x15d]
    3463:	26 0b 85 5f 01       	or     ax,WORD PTR es:[di+0x15f]
    3468:	74 1f                	je     0x3489
    346a:	06                   	push   es
    346b:	57                   	push   di
    346c:	9a 58 16 87 34       	call   0x3487:0x1658
    3471:	3b 56 0e             	cmp    dx,WORD PTR [bp+0xe]
    3474:	75 13                	jne    0x3489
    3476:	3b 46 0c             	cmp    ax,WORD PTR [bp+0xc]
    3479:	75 0e                	jne    0x3489
    347b:	6a 00                	push   0x0
    347d:	6a 00                	push   0x0
    347f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3482:	06                   	push   es
    3483:	57                   	push   di
    3484:	9a 59 19 31 35       	call   0x3531:0x1959
    3489:	c9                   	leave
    348a:	ca 0a 00             	retf   0xa
    348d:	c8 04 00 00          	enter  0x4,0x0
    3491:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3494:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    3499:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    349e:	75 03                	jne    0x34a3
    34a0:	e9 84 00             	jmp    0x3527
    34a3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34a6:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    34ab:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    34ae:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    34b1:	f6 46 0a 04          	test   BYTE PTR [bp+0xa],0x4
    34b5:	74 24                	je     0x34db
    34b7:	06                   	push   es
    34b8:	57                   	push   di
    34b9:	9a cd 78 ca 34       	call   0x34ca:0x78cd
    34be:	f7 d8                	neg    ax
    34c0:	48                   	dec    ax
    34c1:	50                   	push   ax
    34c2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    34c5:	06                   	push   es
    34c6:	57                   	push   di
    34c7:	9a fa 76 d5 34       	call   0x34d5:0x76fa
    34cc:	89 c7                	mov    di,ax
    34ce:	8e c2                	mov    es,dx
    34d0:	06                   	push   es
    34d1:	57                   	push   di
    34d2:	9a c7 4d e9 34       	call   0x34e9:0x4dc7
    34d7:	80 66 0a fb          	and    BYTE PTR [bp+0xa],0xfb
    34db:	f6 46 0a 08          	test   BYTE PTR [bp+0xa],0x8
    34df:	74 32                	je     0x3513
    34e1:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    34e4:	06                   	push   es
    34e5:	57                   	push   di
    34e6:	9a cd 78 f4 34       	call   0x34f4:0x78cd
    34eb:	50                   	push   ax
    34ec:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    34ef:	06                   	push   es
    34f0:	57                   	push   di
    34f1:	9a 78 79 02 35       	call   0x3502:0x7978
    34f6:	5a                   	pop    dx
    34f7:	2b c2                	sub    ax,dx
    34f9:	50                   	push   ax
    34fa:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    34fd:	06                   	push   es
    34fe:	57                   	push   di
    34ff:	9a fa 76 0d 35       	call   0x350d:0x76fa
    3504:	89 c7                	mov    di,ax
    3506:	8e c2                	mov    es,dx
    3508:	06                   	push   es
    3509:	57                   	push   di
    350a:	9a c7 4d 1a 36       	call   0x361a:0x4dc7
    350f:	80 66 0a f7          	and    BYTE PTR [bp+0xa],0xf7
    3513:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    3517:	74 0e                	je     0x3527
    3519:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    351c:	50                   	push   ax
    351d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3520:	06                   	push   es
    3521:	57                   	push   di
    3522:	9a 4d 7d 3f 35       	call   0x353f:0x7d4d
    3527:	c9                   	leave
    3528:	ca 06 00             	retf   0x6
    352b:	01 30                	add    WORD PTR [bx+si],si
    352d:	00 00                	add    BYTE PTR [bx+si],al
    352f:	69 36 c3 35 c8 0a    	imul   si,WORD PTR ds:0x35c3,0xac8
    3535:	00 00                	add    BYTE PTR [bx+si],al
    3537:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    353a:	06                   	push   es
    353b:	57                   	push   di
    353c:	9a ff 7e ed 35       	call   0x35ed:0x7eff
    3541:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3544:	26 80 bd 52 01 00    	cmp    BYTE PTR es:[di+0x152],0x0
    354a:	74 03                	je     0x354f
    354c:	e9 30 01             	jmp    0x367f
    354f:	26 80 bd 79 02 00    	cmp    BYTE PTR es:[di+0x279],0x0
    3555:	75 03                	jne    0x355a
    3557:	e9 25 01             	jmp    0x367f
    355a:	26 c4 bd 5d 01       	les    di,DWORD PTR es:[di+0x15d]
    355f:	26 80 7d 11 00       	cmp    BYTE PTR es:[di+0x11],0x0
    3564:	75 03                	jne    0x3569
    3566:	e9 16 01             	jmp    0x367f
    3569:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    356c:	06                   	push   es
    356d:	57                   	push   di
    356e:	9a fa 64 ff ff       	call   0xffff:0x64fa
    3573:	08 c0                	or     al,al
    3575:	75 03                	jne    0x357a
    3577:	e9 05 01             	jmp    0x367f
    357a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    357d:	26 fe 85 57 01       	inc    BYTE PTR es:[di+0x157]
    3582:	b8 2d 35             	mov    ax,0x352d
    3585:	0e                   	push   cs
    3586:	50                   	push   ax
    3587:	55                   	push   bp
    3588:	ff 36 58 18          	push   WORD PTR ds:0x1858
    358c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3590:	26 ff 75 36          	push   WORD PTR es:[di+0x36]
    3594:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    3598:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    359d:	06                   	push   es
    359e:	57                   	push   di
    359f:	9a 99 20 b6 35       	call   0x35b6:0x2099
    35a4:	bf 2b 35             	mov    di,0x352b
    35a7:	0e                   	push   cs
    35a8:	57                   	push   di
    35a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35ac:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    35b1:	06                   	push   es
    35b2:	57                   	push   di
    35b3:	9a 03 20 ff ff       	call   0xffff:0x2003
    35b8:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    35bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35be:	06                   	push   es
    35bf:	57                   	push   di
    35c0:	9a 19 19 0f 36       	call   0x360f:0x1919
    35c5:	48                   	dec    ax
    35c6:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    35c9:	31 c0                	xor    ax,ax
    35cb:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    35ce:	7f 54                	jg     0x3624
    35d0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    35d3:	eb 03                	jmp    0x35d8
    35d5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    35d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35db:	26 8a 85 56 01       	mov    al,BYTE PTR es:[di+0x156]
    35e0:	30 e4                	xor    ah,ah
    35e2:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    35e5:	99                   	cwd
    35e6:	52                   	push   dx
    35e7:	50                   	push   ax
    35e8:	06                   	push   es
    35e9:	57                   	push   di
    35ea:	9a 30 6e 1a 37       	call   0x371a:0x6e30
    35ef:	8b d8                	mov    bx,ax
    35f1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    35f4:	99                   	cwd
    35f5:	b9 02 00             	mov    cx,0x2
    35f8:	f7 f9                	idiv   cx
    35fa:	03 c3                	add    ax,bx
    35fc:	2d 03 00             	sub    ax,0x3
    35ff:	99                   	cwd
    3600:	f7 7e fc             	idiv   WORD PTR [bp-0x4]
    3603:	50                   	push   ax
    3604:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3607:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    360a:	06                   	push   es
    360b:	57                   	push   di
    360c:	9a 33 19 ff ff       	call   0xffff:0x1933
    3611:	89 c7                	mov    di,ax
    3613:	8e c2                	mov    es,dx
    3615:	06                   	push   es
    3616:	57                   	push   di
    3617:	9a 0d 6f ff ff       	call   0xffff:0x6f0d
    361c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    361f:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    3622:	75 b1                	jne    0x35d5
    3624:	ff 76 08             	push   WORD PTR [bp+0x8]
    3627:	ff 76 06             	push   WORD PTR [bp+0x6]
    362a:	9a a8 17 ff ff       	call   0xffff:0x17a8
    362f:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3632:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3635:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3638:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    363b:	74 20                	je     0x365d
    363d:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    3640:	26 8b 85 06 01       	mov    ax,WORD PTR es:[di+0x106]
    3645:	26 0b 85 08 01       	or     ax,WORD PTR es:[di+0x108]
    364a:	74 11                	je     0x365d
    364c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    364f:	26 c4 bd 06 01       	les    di,DWORD PTR es:[di+0x106]
    3654:	06                   	push   es
    3655:	57                   	push   di
    3656:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3659:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    365d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3661:	83 c4 06             	add    sp,0x6
    3664:	b8 72 36             	mov    ax,0x3672
    3667:	0e                   	push   cs
    3668:	50                   	push   ax
    3669:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    366c:	26 fe 8d 57 01       	dec    BYTE PTR es:[di+0x157]
    3671:	cb                   	retf
    3672:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3675:	06                   	push   es
    3676:	57                   	push   di
    3677:	26 c4 3d             	les    di,DWORD PTR es:[di]
    367a:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    367f:	c9                   	leave
    3680:	ca 04 00             	retf   0x4
    3683:	55                   	push   bp
    3684:	89 e5                	mov    bp,sp
    3686:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3689:	06                   	push   es
    368a:	57                   	push   di
    368b:	9a f4 4f ff ff       	call   0xffff:0x4ff4
    3690:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3693:	06                   	push   es
    3694:	57                   	push   di
    3695:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3698:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    369d:	c9                   	leave
    369e:	ca 04 00             	retf   0x4
    36a1:	c8 04 00 00          	enter  0x4,0x0
    36a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    36a8:	26 8b 85 53 01       	mov    ax,WORD PTR es:[di+0x153]
    36ad:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    36b0:	75 03                	jne    0x36b5
    36b2:	e9 9f 00             	jmp    0x3754
    36b5:	31 c0                	xor    ax,ax
    36b7:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    36ba:	f6 46 0a 20          	test   BYTE PTR [bp+0xa],0x20
    36be:	74 09                	je     0x36c9
    36c0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36c3:	0d 05 00             	or     ax,0x5
    36c6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    36c9:	f6 46 0a 40          	test   BYTE PTR [bp+0xa],0x40
    36cd:	74 09                	je     0x36d8
    36cf:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36d2:	0d 0a 00             	or     ax,0xa
    36d5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    36d8:	f6 46 0a 10          	test   BYTE PTR [bp+0xa],0x10
    36dc:	74 09                	je     0x36e7
    36de:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    36e1:	0d 80 02             	or     ax,0x280
    36e4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    36e7:	f6 46 0a 80          	test   BYTE PTR [bp+0xa],0x80
    36eb:	74 04                	je     0x36f1
    36ed:	80 4e ff 08          	or     BYTE PTR [bp-0x1],0x8
    36f1:	f6 46 0b 01          	test   BYTE PTR [bp+0xb],0x1
    36f5:	74 04                	je     0x36fb
    36f7:	80 4e ff 10          	or     BYTE PTR [bp-0x1],0x10
    36fb:	f6 46 0a 01          	test   BYTE PTR [bp+0xa],0x1
    36ff:	74 04                	je     0x3705
    3701:	80 4e ff 04          	or     BYTE PTR [bp-0x1],0x4
    3705:	f6 46 0a 02          	test   BYTE PTR [bp+0xa],0x2
    3709:	74 04                	je     0x370f
    370b:	80 4e ff 20          	or     BYTE PTR [bp-0x1],0x20
    370f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3712:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3715:	06                   	push   es
    3716:	57                   	push   di
    3717:	9a 7d 73 ff ff       	call   0xffff:0x737d
    371c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    371f:	26 8b 85 53 01       	mov    ax,WORD PTR es:[di+0x153]
    3724:	23 46 0a             	and    ax,WORD PTR [bp+0xa]
    3727:	f7 d0                	not    ax
    3729:	8b d0                	mov    dx,ax
    372b:	26 8b 85 53 01       	mov    ax,WORD PTR es:[di+0x153]
    3730:	0b 46 0a             	or     ax,WORD PTR [bp+0xa]
    3733:	23 c2                	and    ax,dx
    3735:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3738:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    373b:	26 89 85 53 01       	mov    WORD PTR es:[di+0x153],ax
    3740:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3743:	25 6f 03             	and    ax,0x36f
    3746:	09 c0                	or     ax,ax
    3748:	74 0a                	je     0x3754
    374a:	06                   	push   es
    374b:	57                   	push   di
    374c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    374f:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    3754:	c9                   	leave
    3755:	ca 06 00             	retf   0x6
    3758:	55                   	push   bp
    3759:	89 e5                	mov    bp,sp
    375b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    375e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3761:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3764:	26 c4 bd 45 01       	les    di,DWORD PTR es:[di+0x145]
    3769:	06                   	push   es
    376a:	57                   	push   di
    376b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    376e:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    3772:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3775:	06                   	push   es
    3776:	57                   	push   di
    3777:	26 c4 3d             	les    di,DWORD PTR es:[di]
    377a:	26 ff 9d 90 00       	call   DWORD PTR es:[di+0x90]
    377f:	c9                   	leave
    3780:	ca                   	.byte 0xca
    3781:	08                   	.byte 0x8
