; ================================================================
; seg31_CODE  (11864 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	1f                   	pop    ds
       1:	00 ca                	add    dl,cl
       3:	00 00                	add    BYTE PTR [bx+si],al
       5:	00 00                	add    BYTE PTR [bx+si],al
       7:	00 aa 00 9e          	add    BYTE PTR [bp+si-0x6200],ch
       b:	00 f8                	add    al,bh
       d:	00 c1                	add    cl,al
       f:	05 dd 00             	add    ax,0xdd
      12:	fa                   	cli
      13:	45                   	inc    bp
      14:	88 00                	mov    BYTE PTR [bx+si],al
      16:	9a 1f 08 01 cb       	call   0xcb01:0x81f
      1b:	1f                   	pop    ds
      1c:	18 00                	sbb    BYTE PTR [bx+si],al
      1e:	fc                   	cld
      1f:	2e 68 00 cd          	cs push 0xcd00
      23:	11 2c                	adc    WORD PTR [si],bp
      25:	00 3a                	add    BYTE PTR [bp+si],bh
      27:	27                   	daa
      28:	30 00                	xor    BYTE PTR [bx+si],al
      2a:	fa                   	cli
      2b:	10 e0                	adc    al,ah
      2d:	02 d6                	add    dl,dh
      2f:	14 38                	adc    al,0x38
      31:	00 d6                	add    dh,dl
      33:	0f                   	movmskps eax,(bad)
      34:	50                   	push   ax
      35:	00 32                	add    BYTE PTR [bp+si],dh
      37:	16                   	push   ss
      38:	60                   	pusha
      39:	00 ec                	add    ah,ch
      3b:	30 98 00 51          	xor    BYTE PTR [bx+si+0x5100],bl
      3f:	1b 10                	sbb    dx,WORD PTR [bx+si]
      41:	00 38                	add    BYTE PTR [bx+si],bh
      43:	50                   	push   ax
      44:	4c                   	dec    sp
      45:	00 63 31             	add    BYTE PTR [bp+di+0x31],ah
      48:	20 00                	and    BYTE PTR [bx+si],al
      4a:	21 50 24             	and    WORD PTR [bx+si+0x24],dx
      4d:	00 7d 0a             	add    BYTE PTR [di+0xa],bh
      50:	70 00                	jo     0x52
      52:	d9 62 58             	fldenv [bp+si+0x58]
      55:	00 06 63 5c          	add    BYTE PTR ds:0x5c63,al
      59:	00 8f 60 94          	add    BYTE PTR [bx-0x6ba0],cl
      5d:	00 3a                	add    BYTE PTR [bp+si],bh
      5f:	1c 40                	sbb    al,0x40
      61:	00 46 44             	add    BYTE PTR [bp+0x44],al
      64:	48                   	dec    ax
      65:	00 08                	add    BYTE PTR [bx+si],cl
      67:	61                   	popa
      68:	6c                   	ins    BYTE PTR es:[di],dx
      69:	00 5c 61             	add    BYTE PTR [si+0x61],bl
      6c:	9c                   	pushf
      6d:	00 70 0c             	add    BYTE PTR [bx+si+0xc],dh
      70:	b8 00 3a             	mov    ax,0x3a00
      73:	61                   	popa
      74:	28 00                	sub    BYTE PTR [bx+si],al
      76:	72 3f                	jb     0xb7
      78:	7c 00                	jl     0x7a
      7a:	29 3b                	sub    WORD PTR [bp+di],di
      7c:	80 00 17             	add    BYTE PTR [bx+si],0x17
      7f:	3e 84 00             	test   BYTE PTR ds:[bx+si],al
      82:	88 3c                	mov    BYTE PTR [si],bh
      84:	14 00                	adc    al,0x0
      86:	ed                   	in     ax,dx
      87:	3e 8c 00             	mov    WORD PTR ds:[bx+si],es
      8a:	77 3e                	ja     0xca
      8c:	90                   	nop
      8d:	00 c2                	add    dl,al
      8f:	35 54 00             	xor    ax,0x54
      92:	1c 48                	sbb    al,0x48
      94:	3c 00                	cmp    al,0x0
      96:	ae                   	scas   al,BYTE PTR es:[di]
      97:	5f                   	pop    di
      98:	64 00 35             	add    BYTE PTR fs:[di],dh
      9b:	62 74 00             	bound  si,DWORD PTR [si+0x0]
      9e:	0b 54 53             	or     dx,WORD PTR [si+0x53]
      a1:	70 69                	jo     0x10c
      a3:	6e                   	outs   dx,BYTE PTR ds:[si]
      a4:	42                   	inc    dx
      a5:	75 74                	jne    0x11b
      a7:	74 6f                	je     0x118
      a9:	6e                   	outs   dx,BYTE PTR ds:[si]
      aa:	05 00 05             	add    ax,0x500
      ad:	00 07                	add    BYTE PTR [bx],al
      af:	00 08                	add    BYTE PTR [bx+si],cl
      b1:	00 87 00 f1          	add    BYTE PTR [bx-0xf00],al
      b5:	ff ae 0c bc          	jmp    DWORD PTR [bp-0x43f4]
      b9:	00 25                	add    BYTE PTR [di],ah
      bb:	0d c0 00             	or     ax,0xc0
      be:	59                   	pop    cx
      bf:	0d c4 00             	or     ax,0xc4
      c2:	c0 0f c8             	ror    BYTE PTR [bx],0xc8
      c5:	00 8d 0d d9          	add    BYTE PTR [di-0x26f3],cl
      c9:	00 07                	add    BYTE PTR [bx],al
      cb:	0b 54 53             	or     dx,WORD PTR [si+0x53]
      ce:	70 69                	jo     0x139
      d0:	6e                   	outs   dx,BYTE PTR ds:[si]
      d1:	42                   	inc    dx
      d2:	75 74                	jne    0x148
      d4:	74 6f                	je     0x145
      d6:	6e                   	outs   dx,BYTE PTR ds:[si]
      d7:	22 00                	and    al,BYTE PTR [bx+si]
      d9:	2a 01                	sub    al,BYTE PTR [bx+di]
      db:	d7                   	xlat   BYTE PTR ds:[bx]
      dc:	07                   	pop    es
      dd:	ea 00 1f 00 04       	jmp    0x400:0x1f00
      e2:	53                   	push   bx
      e3:	70 69                	jo     0x14e
      e5:	6e                   	outs   dx,BYTE PTR ds:[si]
      e6:	16                   	push   ss
      e7:	00 e2                	add    dl,ah
      e9:	00 f2                	add    dl,dh
      eb:	00 2d                	add    BYTE PTR [di],ch
      ed:	00 ff                	add    bh,bh
      ef:	ff 72 16             	push   WORD PTR [bp+si+0x16]
      f2:	10 01                	adc    BYTE PTR [bx+di],al
      f4:	01 00                	add    WORD PTR [bx+si],ax
      f6:	00 00                	add    BYTE PTR [bx+si],al
      f8:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
      fc:	00 00                	add    BYTE PTR [bx+si],al
      fe:	09 00                	or     WORD PTR [bx+si],ax
     100:	05 41 6c             	add    ax,0x6c41
     103:	69 67 6e 07 23       	imul   sp,WORD PTR [bx+0x6e],0x2307
     108:	8c 01                	mov    WORD PTR [bx+di],es
     10a:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     10b:	00 ff                	add    bh,bh
     10d:	ff 22                	jmp    WORD PTR [bp+si]
     10f:	63 14                	arpl   WORD PTR [si],dx
     111:	01 54 63             	add    WORD PTR [si+0x63],dx
     114:	48                   	dec    ax
     115:	01 00                	add    WORD PTR [bx+si],ax
     117:	80 00 00             	add    BYTE PTR [bx+si],0x0
     11a:	00 80 0a 00          	add    BYTE PTR [bx+si+0xa],al
     11e:	05 43 74             	add    ax,0x7443
     121:	6c                   	ins    BYTE PTR es:[di],dx
     122:	33 44 8f             	xor    ax,WORD PTR [si-0x71]
     125:	08 a0 02 ce          	or     BYTE PTR [bx+si-0x31fe],ah
     129:	10 2e 01 f1          	adc    BYTE PTR ds:0xf101,ch
     12d:	10 a4 02 01          	adc    BYTE PTR [si+0x102],ah
     131:	00 00                	add    BYTE PTR [bx+si],al
     133:	00 00                	add    BYTE PTR [bx+si],al
     135:	80 00 00             	add    BYTE PTR [bx+si],0x0
     138:	00 80 0b 00          	add    BYTE PTR [bx+si+0xb],al
     13c:	09 44 6f             	or     WORD PTR [si+0x6f],ax
     13f:	77 6e                	ja     0x1af
     141:	47                   	inc    di
     142:	6c                   	ins    BYTE PTR es:[di],dx
     143:	79 70                	jns    0x1b5
     145:	68 64 00             	push   0x64
     148:	6b 01 3e             	imul   ax,WORD PTR [bx+di],0x3e
     14b:	00 ff                	add    bh,bh
     14d:	ff                   	(bad)
     14e:	3e 00 ff             	ds add bh,bh
     151:	ff 01                	inc    WORD PTR [bx+di]
     153:	00 00                	add    BYTE PTR [bx+si],al
     155:	00 00                	add    BYTE PTR [bx+si],al
     157:	80 f4 ff             	xor    ah,0xff
     15a:	ff                   	(bad)
     15b:	ff 0c                	dec    WORD PTR [si]
     15d:	00 0a                	add    BYTE PTR [bp+si],cl
     15f:	44                   	inc    sp
     160:	72 61                	jb     0x1c3
     162:	67 43                	addr32 inc bx
     164:	75 72                	jne    0x1d8
     166:	73 6f                	jae    0x1d7
     168:	72 25                	jb     0x18f
     16a:	01 94 01 2e          	add    WORD PTR [si+0x2e01],dx
     16e:	00 ff                	add    bh,bh
     170:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     174:	ff 01                	inc    WORD PTR [bx+di]
     176:	00 00                	add    BYTE PTR [bx+si],al
     178:	00 00                	add    BYTE PTR [bx+si],al
     17a:	80 00 00             	add    BYTE PTR [bx+si],0x0
     17d:	00 00                	add    BYTE PTR [bx+si],al
     17f:	0d 00 08             	or     ax,0x800
     182:	44                   	inc    sp
     183:	72 61                	jb     0x1e6
     185:	67 4d                	addr32 dec bp
     187:	6f                   	outs   dx,WORD PTR ds:[si]
     188:	64 65 07             	fs gs pop es
     18b:	23 d1                	and    dx,cx
     18d:	01 2a                	add    WORD PTR [bp+si],bp
     18f:	00 ff                	add    bh,bh
     191:	ff                   	(bad)
     192:	b8 1c ac             	mov    ax,0xac1c
     195:	01 01                	add    WORD PTR [bx+di],ax
     197:	00 00                	add    BYTE PTR [bx+si],al
     199:	00 00                	add    BYTE PTR [bx+si],al
     19b:	80 01 00             	add    BYTE PTR [bx+di],0x0
     19e:	00 00                	add    BYTE PTR [bx+si],al
     1a0:	0e                   	push   cs
     1a1:	00 07                	add    BYTE PTR [bx],al
     1a3:	45                   	inc    bp
     1a4:	6e                   	outs   dx,BYTE PTR ds:[si]
     1a5:	61                   	popa
     1a6:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     1a9:	64 d7                	xlat   BYTE PTR fs:[bx]
     1ab:	07                   	pop    es
     1ac:	d9 01                	fld    DWORD PTR [bx+di]
     1ae:	e4 00                	in     al,0x0
     1b0:	ff                   	(bad)
     1b1:	ff e4                	jmp    sp
     1b3:	00 ff                	add    bh,bh
     1b5:	ff 01                	inc    WORD PTR [bx+di]
     1b7:	00 00                	add    BYTE PTR [bx+si],al
     1b9:	00 00                	add    BYTE PTR [bx+si],al
     1bb:	80 00 00             	add    BYTE PTR [bx+si],0x0
     1be:	00 80 0f 00          	add    BYTE PTR [bx+si+0xf],al
     1c2:	0c 46                	or     al,0x46
     1c4:	6f                   	outs   dx,WORD PTR ds:[si]
     1c5:	63 75 73             	arpl   WORD PTR [di+0x73],si
     1c8:	43                   	inc    bx
     1c9:	6f                   	outs   dx,WORD PTR ds:[si]
     1ca:	6e                   	outs   dx,BYTE PTR ds:[si]
     1cb:	74 72                	je     0x23f
     1cd:	6f                   	outs   dx,WORD PTR ds:[si]
     1ce:	6c                   	ins    BYTE PTR es:[di],dx
     1cf:	07                   	pop    es
     1d0:	23 f5                	and    si,bp
     1d2:	01 a6 00 ff          	add    WORD PTR [bp-0x100],sp
     1d6:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     1d9:	fd                   	std
     1da:	01 01                	add    WORD PTR [bx+di],ax
     1dc:	00 00                	add    BYTE PTR [bx+si],al
     1de:	00 00                	add    BYTE PTR [bx+si],al
     1e0:	80 01 00             	add    BYTE PTR [bx+di],0x0
     1e3:	00 00                	add    BYTE PTR [bx+si],al
     1e5:	10 00                	adc    BYTE PTR [bx+si],al
     1e7:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     1ea:	72 65                	jb     0x251
     1ec:	6e                   	outs   dx,BYTE PTR ds:[si]
     1ed:	74 43                	je     0x232
     1ef:	74 6c                	je     0x25d
     1f1:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     1f4:	23 3e 02 49          	and    di,WORD PTR ds:0x4902
     1f8:	00 ff                	add    bh,bh
     1fa:	ff a1 1e 46          	jmp    WORD PTR [bx+di+0x461e]
     1fe:	02 01                	add    al,BYTE PTR [bx+di]
     200:	00 00                	add    BYTE PTR [bx+si],al
     202:	00 00                	add    BYTE PTR [bx+si],al
     204:	80 01 00             	add    BYTE PTR [bx+di],0x0
     207:	00 00                	add    BYTE PTR [bx+si],al
     209:	11 00                	adc    WORD PTR [bx+si],ax
     20b:	0e                   	push   cs
     20c:	50                   	push   ax
     20d:	61                   	popa
     20e:	72 65                	jb     0x275
     210:	6e                   	outs   dx,BYTE PTR ds:[si]
     211:	74 53                	je     0x266
     213:	68 6f 77             	push   0x776f
     216:	48                   	dec    ax
     217:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     21c:	06                   	push   es
     21d:	07                   	pop    es
     21e:	40                   	inc    ax
     21f:	00 ff                	add    bh,bh
     221:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     224:	ff                   	(bad)
     225:	ff 01                	inc    WORD PTR [bx+di]
     227:	00 00                	add    BYTE PTR [bx+si],al
     229:	00 00                	add    BYTE PTR [bx+si],al
     22b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     22e:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
     232:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     235:	70 75                	jo     0x2ac
     237:	70 4d                	jo     0x286
     239:	65 6e                	outs   dx,BYTE PTR gs:[si]
     23b:	75 07                	jne    0x244
     23d:	23 80 02 48          	and    ax,WORD PTR [bx+si+0x4802]
     241:	00 ff                	add    bh,bh
     243:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     246:	4a                   	dec    dx
     247:	02 23                	add    ah,BYTE PTR [bp+di]
     249:	1e                   	push   ds
     24a:	5f                   	pop    di
     24b:	02 00                	add    al,BYTE PTR [bx+si]
     24d:	80 00 00             	add    BYTE PTR [bx+si],0x0
     250:	00 80 13 00          	add    BYTE PTR [bx+si+0x13],al
     254:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     257:	6f                   	outs   dx,WORD PTR ds:[si]
     258:	77 48                	ja     0x2a2
     25a:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     25f:	63 02                	arpl   WORD PTR [bp+si],ax
     261:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     262:	63 67 02             	arpl   WORD PTR [bx+0x2],sp
     265:	60                   	pusha
     266:	64 88 02             	mov    BYTE PTR fs:[bp+si],al
     269:	01 00                	add    WORD PTR [bx+si],ax
     26b:	00 00                	add    BYTE PTR [bx+si],al
     26d:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     271:	ff                   	(bad)
     272:	ff 14                	call   WORD PTR [si]
     274:	00 08                	add    BYTE PTR [bx+si],cl
     276:	54                   	push   sp
     277:	61                   	popa
     278:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     27b:	64 65 72 07          	fs gs jb 0x286
     27f:	23 c0                	and    ax,ax
     281:	02 a4 00 ff          	add    ah,BYTE PTR [si-0x100]
     285:	ff 88 64 c8          	dec    WORD PTR [bx+si-0x379c]
     289:	02 01                	add    al,BYTE PTR [bx+di]
     28b:	00 00                	add    BYTE PTR [bx+si],al
     28d:	00 00                	add    BYTE PTR [bx+si],al
     28f:	80 00 00             	add    BYTE PTR [bx+si],0x0
     292:	00 00                	add    BYTE PTR [bx+si],al
     294:	15 00 07             	adc    ax,0x700
     297:	54                   	push   sp
     298:	61                   	popa
     299:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     29c:	6f                   	outs   dx,WORD PTR ds:[si]
     29d:	70 8f                	jo     0x22e
     29f:	08 0b                	or     BYTE PTR [bp+di],cl
     2a1:	05 3a 10             	add    ax,0x103a
     2a4:	a8 02                	test   al,0x2
     2a6:	5d                   	pop    bp
     2a7:	10 69 04             	adc    BYTE PTR [bx+di+0x4],ch
     2aa:	01 00                	add    WORD PTR [bx+si],ax
     2ac:	00 00                	add    BYTE PTR [bx+si],al
     2ae:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     2b2:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     2b6:	07                   	pop    es
     2b7:	55                   	push   bp
     2b8:	70 47                	jo     0x301
     2ba:	6c                   	ins    BYTE PTR es:[di],dx
     2bb:	79 70                	jns    0x32d
     2bd:	68 07 23             	push   0x2307
     2c0:	e5 03                	in     ax,0x3
     2c2:	29 00                	sub    WORD PTR [bx+si],ax
     2c4:	ff                   	(bad)
     2c5:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     2c8:	04 03                	add    al,0x3
     2ca:	01 00                	add    WORD PTR [bx+si],ax
     2cc:	00 00                	add    BYTE PTR [bx+si],al
     2ce:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     2d2:	00 00                	add    BYTE PTR [bx+si],al
     2d4:	17                   	pop    ss
     2d5:	00 07                	add    BYTE PTR [bx],al
     2d7:	56                   	push   si
     2d8:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     2dd:	65 71 00             	gs jno 0x2e0
     2e0:	6c                   	ins    BYTE PTR es:[di],dx
     2e1:	03 f0                	add    si,ax
     2e3:	00 ff                	add    bh,bh
     2e5:	ff f0                	push   ax
     2e7:	00 ff                	add    bh,bh
     2e9:	ff 01                	inc    WORD PTR [bx+di]
     2eb:	00 00                	add    BYTE PTR [bx+si],al
     2ed:	00 00                	add    BYTE PTR [bx+si],al
     2ef:	80 00 00             	add    BYTE PTR [bx+si],0x0
     2f2:	00 80 18 00          	add    BYTE PTR [bx+si+0x18],al
     2f6:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     2f9:	44                   	inc    sp
     2fa:	6f                   	outs   dx,WORD PTR ds:[si]
     2fb:	77 6e                	ja     0x36b
     2fd:	43                   	inc    bx
     2fe:	6c                   	ins    BYTE PTR es:[di],dx
     2ff:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     304:	27                   	daa
     305:	03 62 00             	add    sp,WORD PTR [bp+si+0x0]
     308:	ff                   	(bad)
     309:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     30c:	ff                   	(bad)
     30d:	ff 01                	inc    WORD PTR [bx+di]
     30f:	00 00                	add    BYTE PTR [bx+si],al
     311:	00 00                	add    BYTE PTR [bx+si],al
     313:	80 00 00             	add    BYTE PTR [bx+si],0x0
     316:	00 80 19 00          	add    BYTE PTR [bx+si+0x19],al
     31a:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     31d:	44                   	inc    sp
     31e:	72 61                	jb     0x381
     320:	67 44                	addr32 inc sp
     322:	72 6f                	jb     0x393
     324:	70 80                	jo     0x2a6
     326:	02 4a 03             	add    cl,BYTE PTR [bp+si+0x3]
     329:	6a 00                	push   0x0
     32b:	ff                   	(bad)
     32c:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     32f:	ff                   	(bad)
     330:	ff 01                	inc    WORD PTR [bx+di]
     332:	00 00                	add    BYTE PTR [bx+si],al
     334:	00 00                	add    BYTE PTR [bx+si],al
     336:	80 00 00             	add    BYTE PTR [bx+si],0x0
     339:	00 80 1a 00          	add    BYTE PTR [bx+si+0x1a],al
     33d:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     340:	44                   	inc    sp
     341:	72 61                	jb     0x3a4
     343:	67 4f                	addr32 dec di
     345:	76 65                	jbe    0x3ac
     347:	72 32                	jb     0x37b
     349:	03 41 04             	add    ax,WORD PTR [bx+di+0x4]
     34c:	72 00                	jb     0x34e
     34e:	ff                   	(bad)
     34f:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     352:	ff                   	(bad)
     353:	ff 01                	inc    WORD PTR [bx+di]
     355:	00 00                	add    BYTE PTR [bx+si],al
     357:	00 00                	add    BYTE PTR [bx+si],al
     359:	80 00 00             	add    BYTE PTR [bx+si],0x0
     35c:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     360:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     363:	45                   	inc    bp
     364:	6e                   	outs   dx,BYTE PTR ds:[si]
     365:	64 44                	fs inc sp
     367:	72 61                	jb     0x3ca
     369:	67 71 00             	addr32 jno 0x36c
     36c:	8c 03                	mov    WORD PTR [bp+di],es
     36e:	c8 00 ff ff          	enter  0xff00,0xff
     372:	c8 00 ff ff          	enter  0xff00,0xff
     376:	01 00                	add    WORD PTR [bx+si],ax
     378:	00 00                	add    BYTE PTR [bx+si],al
     37a:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     37e:	00 80 1c 00          	add    BYTE PTR [bx+si+0x1c],al
     382:	07                   	pop    es
     383:	4f                   	dec    di
     384:	6e                   	outs   dx,BYTE PTR ds:[si]
     385:	45                   	inc    bp
     386:	6e                   	outs   dx,BYTE PTR ds:[si]
     387:	74 65                	je     0x3ee
     389:	72 71                	jb     0x3fc
     38b:	00 ab 03 d0          	add    BYTE PTR [bp+di-0x2ffd],ch
     38f:	00 ff                	add    bh,bh
     391:	ff d0                	call   ax
     393:	00 ff                	add    bh,bh
     395:	ff 01                	inc    WORD PTR [bx+di]
     397:	00 00                	add    BYTE PTR [bx+si],al
     399:	00 00                	add    BYTE PTR [bx+si],al
     39b:	80 00 00             	add    BYTE PTR [bx+si],0x0
     39e:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
     3a2:	06                   	push   es
     3a3:	4f                   	dec    di
     3a4:	6e                   	outs   dx,BYTE PTR ds:[si]
     3a5:	45                   	inc    bp
     3a6:	78 69                	js     0x411
     3a8:	74 71                	je     0x41b
     3aa:	00 fd                	add    ch,bh
     3ac:	03 e8                	add    bp,ax
     3ae:	00 ff                	add    bh,bh
     3b0:	ff                   	jmp    (bad)
     3b1:	e8 00 ff             	call   0x2b4
     3b4:	ff 01                	inc    WORD PTR [bx+di]
     3b6:	00 00                	add    BYTE PTR [bx+si],al
     3b8:	00 00                	add    BYTE PTR [bx+si],al
     3ba:	80 00 00             	add    BYTE PTR [bx+si],0x0
     3bd:	00 80 1e 00          	add    BYTE PTR [bx+si+0x1e],al
     3c1:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     3c4:	55                   	push   bp
     3c5:	70 43                	jo     0x40a
     3c7:	6c                   	ins    BYTE PTR es:[di],dx
     3c8:	69 63 6b a9 04       	imul   sp,WORD PTR [bp+di+0x6b],0x4a9
     3cd:	00 00                	add    BYTE PTR [bx+si],al
     3cf:	00 00                	add    BYTE PTR [bx+si],al
     3d1:	7d 04                	jge    0x3d7
     3d3:	73 04                	jae    0x3d9
     3d5:	01 01                	add    WORD PTR [bx+di],ax
     3d7:	86 0a                	xchg   BYTE PTR [bp+si],cl
     3d9:	ba 04 fa             	mov    dx,0xfa04
     3dc:	45                   	inc    bp
     3dd:	51                   	push   cx
     3de:	04 9a                	add    al,0x9a
     3e0:	1f                   	pop    ds
     3e1:	c7 04 cb 1f          	mov    WORD PTR [si],0x1fcb
     3e5:	e1 03                	loope  0x3ea
     3e7:	ae                   	scas   al,BYTE PTR es:[di]
     3e8:	12 8f 04 cd          	adc    cl,BYTE PTR [bx-0x32fc]
     3ec:	11 f5                	adc    bp,si
     3ee:	03 3a                	add    di,WORD PTR [bp+si]
     3f0:	27                   	daa
     3f1:	f9                   	stc
     3f2:	03 fa                	add    di,dx
     3f4:	10 e9                	adc    cl,ch
     3f6:	07                   	pop    es
     3f7:	d6                   	(bad)
     3f8:	14 01                	adc    al,0x1
     3fa:	04 f4                	add    al,0xf4
     3fc:	4f                   	dec    di
     3fd:	0d 04 32             	or     ax,0x3204
     400:	16                   	push   ss
     401:	29 04                	sub    WORD PTR [si],ax
     403:	ec                   	in     al,dx
     404:	30 61 04             	xor    BYTE PTR [bx+di+0x4],ah
     407:	51                   	push   cx
     408:	1b 13                	sbb    dx,WORD PTR [bp+di]
     40a:	05 38 50             	add    ax,0x5038
     40d:	15 04 63             	adc    ax,0x6304
     410:	31 31                	xor    WORD PTR [bx+di],si
     412:	04 21                	add    al,0x21
     414:	50                   	push   ax
     415:	ed                   	in     ax,dx
     416:	03 64 11             	add    sp,WORD PTR [si+0x11]
     419:	e9 03 d9             	jmp    0xdd1f
     41c:	62 21                	bound  sp,DWORD PTR [bx+di]
     41e:	04 06                	add    al,0x6
     420:	63 25                	arpl   WORD PTR [di],sp
     422:	04 8f                	add    al,0x8f
     424:	60                   	pusha
     425:	5d                   	pop    bp
     426:	04 3a                	add    al,0x3a
     428:	1c 09                	sbb    al,0x9
     42a:	04 46                	add    al,0x46
     42c:	44                   	inc    sp
     42d:	11 04                	adc    WORD PTR [si],ax
     42f:	08 61 35             	or     BYTE PTR [bx+di+0x35],ah
     432:	04 5c                	add    al,0x5c
     434:	61                   	popa
     435:	39 04                	cmp    WORD PTR [si],ax
     437:	62 5c 65             	bound  bx,DWORD PTR [si+0x65]
     43a:	04 3a                	add    al,0x3a
     43c:	61                   	popa
     43d:	f1                   	int1
     43e:	03 72 3f             	add    si,WORD PTR [bp+si+0x3f]
     441:	49                   	dec    cx
     442:	04 0a                	add    al,0xa
     444:	14 4d                	adc    al,0x4d
     446:	04 17                	add    al,0x17
     448:	3e dd 03             	fld    QWORD PTR ds:[bp+di]
     44b:	41                   	inc    cx
     44c:	14 19                	adc    al,0x19
     44e:	04 ed                	add    al,0xed
     450:	3e 55                	ds push bp
     452:	04 77                	add    al,0x77
     454:	3e 59                	ds pop cx
     456:	04 c2                	add    al,0xc2
     458:	35 1d 04             	xor    ax,0x41d
     45b:	1c 48                	sbb    al,0x48
     45d:	05 04 ae             	add    ax,0xae04
     460:	5f                   	pop    di
     461:	2d 04 35             	sub    ax,0x3504
     464:	62 3d                	bound  di,DWORD PTR [di]
     466:	04 8e                	add    al,0x8e
     468:	13 6d 04             	adc    bp,WORD PTR [di+0x4]
     46b:	fe                   	(bad)
     46c:	15 71 04             	adc    ax,0x471
     46f:	39 16 45 04          	cmp    WORD PTR ds:0x445,dx
     473:	09 54 53             	or     WORD PTR [si+0x53],dx
     476:	70 69                	jo     0x4e1
     478:	6e                   	outs   dx,BYTE PTR ds:[si]
     479:	45                   	inc    bp
     47a:	64 69 74 07 00 05    	imul   si,WORD PTR fs:[si+0x7],0x500
     480:	00 1a                	add    BYTE PTR [bp+si],bl
     482:	0f 1b 0f             	bndstx (bad),bnd1
     485:	02 03                	add    al,BYTE PTR [bp+di]
     487:	00 03                	add    BYTE PTR [bp+di],al
     489:	f1                   	int1
     48a:	ff                   	jmp    (bad)
     48b:	ef                   	out    dx,ax
     48c:	ff e6                	jmp    si
     48e:	14 93                	adc    al,0x93
     490:	04 49                	add    al,0x49
     492:	18 97 04 d0          	sbb    BYTE PTR [bx-0x2ffc],dl
     496:	16                   	push   ss
     497:	9b                   	fwait
     498:	04 74                	add    al,0x74
     49a:	16                   	push   ss
     49b:	9f                   	lahf
     49c:	04 a2                	add    al,0xa2
     49e:	16                   	push   ss
     49f:	a3 04 d9             	mov    ds:0xd904,ax
     4a2:	12 a7 04 2d          	adc    ah,BYTE PTR [bx+0x2d04]
     4a6:	13 b6 04 07          	adc    si,WORD PTR [bp+0x704]
     4aa:	09 54 53             	or     WORD PTR [si+0x53],dx
     4ad:	70 69                	jo     0x518
     4af:	6e                   	outs   dx,BYTE PTR ds:[si]
     4b0:	45                   	inc    bp
     4b1:	64 69 74 eb 03 af    	imul   si,WORD PTR fs:[si-0x15],0xaf03
     4b7:	07                   	pop    es
     4b8:	2e 0b f2             	cs or  si,dx
     4bb:	04 2f                	add    al,0x2f
     4bd:	00 04                	add    BYTE PTR [si],al
     4bf:	53                   	push   bx
     4c0:	70 69                	jo     0x52b
     4c2:	6e                   	outs   dx,BYTE PTR ds:[si]
     4c3:	26 00 07             	add    BYTE PTR es:[bx],al
     4c6:	23 ea                	and    bp,dx
     4c8:	04 de                	add    al,0xde
     4ca:	00 ff                	add    bh,bh
     4cc:	ff                   	call   (bad)
     4cd:	de 00                	fiadd  WORD PTR [bx+si]
     4cf:	ff                   	(bad)
     4d0:	ff 01                	inc    WORD PTR [bx+di]
     4d2:	00 00                	add    BYTE PTR [bx+si],al
     4d4:	00 00                	add    BYTE PTR [bx+si],al
     4d6:	80 01 00             	add    BYTE PTR [bx+di],0x0
     4d9:	00 00                	add    BYTE PTR [bx+si],al
     4db:	0a 00                	or     al,BYTE PTR [bx+si]
     4dd:	0a 41 75             	or     al,BYTE PTR [bx+di+0x75]
     4e0:	74 6f                	je     0x551
     4e2:	53                   	push   bx
     4e3:	65 6c                	gs ins BYTE PTR es:[di],dx
     4e5:	65 63 74 07          	arpl   WORD PTR gs:[si+0x7],si
     4e9:	23 29                	and    bp,WORD PTR [bx+di]
     4eb:	05 dd 00             	add    ax,0xdd
     4ee:	ff                   	(bad)
     4ef:	ff 9c 47 18          	call   DWORD PTR [si+0x1847]
     4f3:	06                   	push   es
     4f4:	01 00                	add    WORD PTR [bx+si],ax
     4f6:	00 00                	add    BYTE PTR [bx+si],al
     4f8:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     4fc:	00 00                	add    BYTE PTR [bx+si],al
     4fe:	0b 00                	or     ax,WORD PTR [bx+si]
     500:	08 41 75             	or     BYTE PTR [bx+di+0x75],al
     503:	74 6f                	je     0x574
     505:	53                   	push   bx
     506:	69 7a 65 02 00       	imul   di,WORD PTR [bp+si+0x65],0x2
     50b:	d1 05                	rol    WORD PTR [di],1
     50d:	38 00                	cmp    BYTE PTR [bx+si],al
     50f:	ff                   	(bad)
     510:	ff d5                	call   bp
     512:	1e                   	push   ds
     513:	17                   	pop    ss
     514:	05 17 1f             	add    ax,0x1f17
     517:	31 05                	xor    WORD PTR [di],ax
     519:	00 80 fa ff          	add    BYTE PTR [bx+si-0x6],al
     51d:	ff                   	(bad)
     51e:	ff 0c                	dec    WORD PTR [si]
     520:	00 05                	add    BYTE PTR [di],al
     522:	43                   	inc    bx
     523:	6f                   	outs   dx,WORD PTR ds:[si]
     524:	6c                   	ins    BYTE PTR es:[di],dx
     525:	6f                   	outs   dx,WORD PTR ds:[si]
     526:	72 07                	jb     0x52f
     528:	23 8b 05 a5          	and    cx,WORD PTR [bp+di-0x5afb]
     52c:	00 ff                	add    bh,bh
     52e:	ff 22                	jmp    WORD PTR [bp+si]
     530:	63 35                	arpl   WORD PTR [di],si
     532:	05 54 63             	add    ax,0x6354
     535:	47                   	inc    di
     536:	05 00 80             	add    ax,0x8000
     539:	00 00                	add    BYTE PTR [bx+si],al
     53b:	00 80 0d 00          	add    BYTE PTR [bx+si+0xd],al
     53f:	05 43 74             	add    ax,0x7443
     542:	6c                   	ins    BYTE PTR es:[di],dx
     543:	33 44 64             	xor    ax,WORD PTR [si+0x64]
     546:	00 6a 05             	add    BYTE PTR [bp+si+0x5],ch
     549:	3e 00 ff             	ds add bh,bh
     54c:	ff                   	(bad)
     54d:	3e 00 ff             	ds add bh,bh
     550:	ff 01                	inc    WORD PTR [bx+di]
     552:	00 00                	add    BYTE PTR [bx+si],al
     554:	00 00                	add    BYTE PTR [bx+si],al
     556:	80 f4 ff             	xor    ah,0xff
     559:	ff                   	(bad)
     55a:	ff 0e 00 0a          	dec    WORD PTR ds:0xa00
     55e:	44                   	inc    sp
     55f:	72 61                	jb     0x5c2
     561:	67 43                	addr32 inc bx
     563:	75 72                	jne    0x5d7
     565:	73 6f                	jae    0x5d6
     567:	72 25                	jb     0x58e
     569:	01 b9 05 2e          	add    WORD PTR [bx+di+0x2e05],di
     56d:	00 ff                	add    bh,bh
     56f:	ff 2e 00 ff          	jmp    DWORD PTR ds:0xff00
     573:	ff 01                	inc    WORD PTR [bx+di]
     575:	00 00                	add    BYTE PTR [bx+si],al
     577:	00 00                	add    BYTE PTR [bx+si],al
     579:	80 00 00             	add    BYTE PTR [bx+si],0x0
     57c:	00 00                	add    BYTE PTR [bx+si],al
     57e:	0f 00 08             	str    WORD PTR [bx+si]
     581:	44                   	inc    sp
     582:	72 61                	jb     0x5e5
     584:	67 4d                	addr32 dec bp
     586:	6f                   	outs   dx,WORD PTR ds:[si]
     587:	64 65 07             	fs gs pop es
     58a:	23 b1 05 00          	and    si,WORD PTR [bx+di+0x5]
     58e:	01 ff                	add    di,di
     590:	ff 00                	inc    WORD PTR [bx+si]
     592:	01 ff                	add    di,di
     594:	ff 01                	inc    WORD PTR [bx+di]
     596:	00 00                	add    BYTE PTR [bx+si],al
     598:	00 00                	add    BYTE PTR [bx+si],al
     59a:	80 01 00             	add    BYTE PTR [bx+di],0x0
     59d:	00 00                	add    BYTE PTR [bx+si],al
     59f:	10 00                	adc    BYTE PTR [bx+si],al
     5a1:	0d 45 64             	or     ax,0x6445
     5a4:	69 74 6f 72 45       	imul   si,WORD PTR [si+0x6f],0x4572
     5a9:	6e                   	outs   dx,BYTE PTR ds:[si]
     5aa:	61                   	popa
     5ab:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5ae:	64 07                	fs pop es
     5b0:	23 ee                	and    bp,si
     5b2:	05 2a 00             	add    ax,0x2a
     5b5:	ff                   	(bad)
     5b6:	ff                   	(bad)
     5b7:	b8 1c d9             	mov    ax,0xd91c
     5ba:	05 01 00             	add    ax,0x1
     5bd:	00 00                	add    BYTE PTR [bx+si],al
     5bf:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     5c3:	00 00                	add    BYTE PTR [bx+si],al
     5c5:	11 00                	adc    WORD PTR [bx+si],ax
     5c7:	07                   	pop    es
     5c8:	45                   	inc    bp
     5c9:	6e                   	outs   dx,BYTE PTR ds:[si]
     5ca:	61                   	popa
     5cb:	62 6c 65             	bound  bp,DWORD PTR [si+0x65]
     5ce:	64 22 03             	and    al,BYTE PTR fs:[bp+di]
     5d1:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     5d2:	10 34                	adc    BYTE PTR [si],dh
     5d4:	00 ff                	add    bh,bh
     5d6:	ff                   	jmp    (bad)
     5d7:	eb 1d                	jmp    0x5f6
     5d9:	dd 05                	fld    QWORD PTR [di]
     5db:	08 1e 7c 06          	or     BYTE PTR ds:0x67c,bl
     5df:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     5e3:	00 80 12 00          	add    BYTE PTR [bx+si+0x12],al
     5e7:	04 46                	add    al,0x46
     5e9:	6f                   	outs   dx,WORD PTR ds:[si]
     5ea:	6e                   	outs   dx,BYTE PTR ds:[si]
     5eb:	74 f5                	je     0x5e2
     5ed:	22 10                	and    dl,BYTE PTR [bx+si]
     5ef:	06                   	push   es
     5f0:	f8                   	clc
     5f1:	00 ff                	add    bh,bh
     5f3:	ff                   	(bad)
     5f4:	f8                   	clc
     5f5:	00 ff                	add    bh,bh
     5f7:	ff 01                	inc    WORD PTR [bx+di]
     5f9:	00 00                	add    BYTE PTR [bx+si],al
     5fb:	00 00                	add    BYTE PTR [bx+si],al
     5fd:	80 01 00             	add    BYTE PTR [bx+di],0x0
     600:	00 00                	add    BYTE PTR [bx+si],al
     602:	13 00                	adc    ax,WORD PTR [bx+si]
     604:	09 49 6e             	or     WORD PTR [bx+di+0x6e],cx
     607:	63 72 65             	arpl   WORD PTR [bp+si+0x65],si
     60a:	6d                   	ins    WORD PTR es:[di],dx
     60b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     60d:	74 d4                	je     0x5e3
     60f:	22 32                	and    dh,BYTE PTR [bp+si]
     611:	06                   	push   es
     612:	d8 00                	fadd   DWORD PTR [bx+si]
     614:	ff                   	(bad)
     615:	ff 32                	push   WORD PTR [bp+si]
     617:	48                   	dec    ax
     618:	30 07                	xor    BYTE PTR [bx],al
     61a:	01 00                	add    WORD PTR [bx+si],ax
     61c:	00 00                	add    BYTE PTR [bx+si],al
     61e:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     622:	00 00                	add    BYTE PTR [bx+si],al
     624:	14 00                	adc    al,0x0
     626:	09 4d 61             	or     WORD PTR [di+0x61],cx
     629:	78 4c                	js     0x677
     62b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     62d:	67 74 68             	addr32 je 0x698
     630:	f5                   	cmc
     631:	22 53 06             	and    dl,BYTE PTR [bp+di+0x6]
     634:	f0 00 ff             	lock add bh,bh
     637:	ff f0                	push   ax
     639:	00 ff                	add    bh,bh
     63b:	ff 01                	inc    WORD PTR [bx+di]
     63d:	00 00                	add    BYTE PTR [bx+si],al
     63f:	00 00                	add    BYTE PTR [bx+si],al
     641:	80 00 00             	add    BYTE PTR [bx+si],0x0
     644:	00 80 15 00          	add    BYTE PTR [bx+si+0x15],al
     648:	08 4d 61             	or     BYTE PTR [di+0x61],cl
     64b:	78 56                	js     0x6a3
     64d:	61                   	popa
     64e:	6c                   	ins    BYTE PTR es:[di],dx
     64f:	75 65                	jne    0x6b6
     651:	f5                   	cmc
     652:	22 74 06             	and    dh,BYTE PTR [si+0x6]
     655:	ec                   	in     al,dx
     656:	00 ff                	add    bh,bh
     658:	ff                   	jmp    (bad)
     659:	ec                   	in     al,dx
     65a:	00 ff                	add    bh,bh
     65c:	ff 01                	inc    WORD PTR [bx+di]
     65e:	00 00                	add    BYTE PTR [bx+si],al
     660:	00 00                	add    BYTE PTR [bx+si],al
     662:	80 00 00             	add    BYTE PTR [bx+si],0x0
     665:	00 80 16 00          	add    BYTE PTR [bx+si+0x16],al
     669:	08 4d 69             	or     BYTE PTR [di+0x69],cl
     66c:	6e                   	outs   dx,BYTE PTR ds:[si]
     66d:	56                   	push   si
     66e:	61                   	popa
     66f:	6c                   	ins    BYTE PTR es:[di],dx
     670:	75 65                	jne    0x6d7
     672:	07                   	pop    es
     673:	23 98 06 2c          	and    bx,WORD PTR [bx+si+0x2c06]
     677:	00 ff                	add    bh,bh
     679:	ff 32                	push   WORD PTR [bp+si]
     67b:	1f                   	pop    ds
     67c:	a0 06 01             	mov    al,ds:0x106
     67f:	00 00                	add    BYTE PTR [bx+si],al
     681:	00 00                	add    BYTE PTR [bx+si],al
     683:	80 00 00             	add    BYTE PTR [bx+si],0x0
     686:	00 00                	add    BYTE PTR [bx+si],al
     688:	17                   	pop    ss
     689:	00 0b                	add    BYTE PTR [bp+di],cl
     68b:	50                   	push   ax
     68c:	61                   	popa
     68d:	72 65                	jb     0x6f4
     68f:	6e                   	outs   dx,BYTE PTR ds:[si]
     690:	74 43                	je     0x6d5
     692:	6f                   	outs   dx,WORD PTR ds:[si]
     693:	6c                   	ins    BYTE PTR es:[di],dx
     694:	6f                   	outs   dx,WORD PTR ds:[si]
     695:	72 07                	jb     0x69e
     697:	23 bc 06 a6          	and    di,WORD PTR [si-0x59fa]
     69b:	00 ff                	add    bh,bh
     69d:	ff 70 63             	push   WORD PTR [bx+si+0x63]
     6a0:	c4 06 01 00          	les    ax,DWORD PTR ds:0x1
     6a4:	00 00                	add    BYTE PTR [bx+si],al
     6a6:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     6aa:	00 00                	add    BYTE PTR [bx+si],al
     6ac:	18 00                	sbb    BYTE PTR [bx+si],al
     6ae:	0b 50 61             	or     dx,WORD PTR [bx+si+0x61]
     6b1:	72 65                	jb     0x718
     6b3:	6e                   	outs   dx,BYTE PTR ds:[si]
     6b4:	74 43                	je     0x6f9
     6b6:	74 6c                	je     0x724
     6b8:	33 44 07             	xor    ax,WORD PTR [si+0x7]
     6bb:	23 df                	and    bx,di
     6bd:	06                   	push   es
     6be:	2b 00                	sub    ax,WORD PTR [bx+si]
     6c0:	ff                   	(bad)
     6c1:	ff                   	(bad)
     6c2:	3e 1e                	ds push ds
     6c4:	e7 06                	out    0x6,ax
     6c6:	01 00                	add    WORD PTR [bx+si],ax
     6c8:	00 00                	add    BYTE PTR [bx+si],al
     6ca:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     6ce:	00 00                	add    BYTE PTR [bx+si],al
     6d0:	19 00                	sbb    WORD PTR [bx+si],ax
     6d2:	0a 50 61             	or     dl,BYTE PTR [bx+si+0x61]
     6d5:	72 65                	jb     0x73c
     6d7:	6e                   	outs   dx,BYTE PTR ds:[si]
     6d8:	74 46                	je     0x720
     6da:	6f                   	outs   dx,WORD PTR ds:[si]
     6db:	6e                   	outs   dx,BYTE PTR ds:[si]
     6dc:	74 07                	je     0x6e5
     6de:	23 28                	and    bp,WORD PTR [bx+si]
     6e0:	07                   	pop    es
     6e1:	49                   	dec    cx
     6e2:	00 ff                	add    bh,bh
     6e4:	ff a1 1e 51          	jmp    WORD PTR [bx+di+0x511e]
     6e8:	07                   	pop    es
     6e9:	01 00                	add    WORD PTR [bx+si],ax
     6eb:	00 00                	add    BYTE PTR [bx+si],al
     6ed:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     6f1:	00 00                	add    BYTE PTR [bx+si],al
     6f3:	1a 00                	sbb    al,BYTE PTR [bx+si]
     6f5:	0e                   	push   cs
     6f6:	50                   	push   ax
     6f7:	61                   	popa
     6f8:	72 65                	jb     0x75f
     6fa:	6e                   	outs   dx,BYTE PTR ds:[si]
     6fb:	74 53                	je     0x750
     6fd:	68 6f 77             	push   0x776f
     700:	48                   	dec    ax
     701:	69 6e 74 0d 04       	imul   bp,WORD PTR [bp+0x74],0x40d
     706:	ff                   	(bad)
     707:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     70a:	ff                   	(bad)
     70b:	ff 40 00             	inc    WORD PTR [bx+si+0x0]
     70e:	ff                   	(bad)
     70f:	ff 01                	inc    WORD PTR [bx+di]
     711:	00 00                	add    BYTE PTR [bx+si],al
     713:	00 00                	add    BYTE PTR [bx+si],al
     715:	80 00 00             	add    BYTE PTR [bx+si],0x0
     718:	00 80 1b 00          	add    BYTE PTR [bx+si+0x1b],al
     71c:	09 50 6f             	or     WORD PTR [bx+si+0x6f],dx
     71f:	70 75                	jo     0x796
     721:	70 4d                	jo     0x770
     723:	65 6e                	outs   dx,BYTE PTR gs:[si]
     725:	75 07                	jne    0x72e
     727:	23 49 07             	and    cx,WORD PTR [bx+di+0x7]
     72a:	dc 00                	fadd   QWORD PTR [bx+si]
     72c:	ff                   	(bad)
     72d:	ff                   	(bad)
     72e:	79 49                	jns    0x779
     730:	86 11                	xchg   BYTE PTR [bx+di],dl
     732:	01 00                	add    WORD PTR [bx+si],ax
     734:	00 00                	add    BYTE PTR [bx+si],al
     736:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     73a:	00 00                	add    BYTE PTR [bx+si],al
     73c:	1c 00                	sbb    al,0x0
     73e:	08 52 65             	or     BYTE PTR [bp+si+0x65],dl
     741:	61                   	popa
     742:	64 4f                	fs dec di
     744:	6e                   	outs   dx,BYTE PTR ds:[si]
     745:	6c                   	ins    BYTE PTR es:[di],dx
     746:	79 07                	jns    0x74f
     748:	23 8b 07 48          	and    cx,WORD PTR [bp+di+0x4807]
     74c:	00 ff                	add    bh,bh
     74e:	ff 72 1e             	push   WORD PTR [bp+si+0x1e]
     751:	55                   	push   bp
     752:	07                   	pop    es
     753:	23 1e 6a 07          	and    bx,WORD PTR ds:0x76a
     757:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     75b:	00 80 1d 00          	add    BYTE PTR [bx+si+0x1d],al
     75f:	08 53 68             	or     BYTE PTR [bp+di+0x68],dl
     762:	6f                   	outs   dx,WORD PTR ds:[si]
     763:	77 48                	ja     0x7ad
     765:	69 6e 74 52 01       	imul   bp,WORD PTR [bp+0x74],0x152
     76a:	6e                   	outs   dx,BYTE PTR ds:[si]
     76b:	07                   	pop    es
     76c:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
     76d:	63 72 07             	arpl   WORD PTR [bp+si+0x7],si
     770:	60                   	pusha
     771:	64 93                	fs xchg bx,ax
     773:	07                   	pop    es
     774:	01 00                	add    WORD PTR [bx+si],ax
     776:	00 00                	add    BYTE PTR [bx+si],al
     778:	00 80 ff ff          	add    BYTE PTR [bx+si-0x1],al
     77c:	ff                   	(bad)
     77d:	ff 1e 00 08          	call   DWORD PTR ds:0x800
     781:	54                   	push   sp
     782:	61                   	popa
     783:	62 4f 72             	bound  cx,DWORD PTR [bx+0x72]
     786:	64 65 72 07          	fs gs jb 0x791
     78a:	23 ab 07 a4          	and    bp,WORD PTR [bp+di-0x5bf9]
     78e:	00 ff                	add    bh,bh
     790:	ff 88 64 d1          	dec    WORD PTR [bx+si-0x2e9c]
     794:	07                   	pop    es
     795:	01 00                	add    WORD PTR [bx+si],ax
     797:	00 00                	add    BYTE PTR [bx+si],al
     799:	00 80 01 00          	add    BYTE PTR [bx+si+0x1],al
     79d:	00 00                	add    BYTE PTR [bx+si],al
     79f:	09 00                	or     WORD PTR [bx+si],ax
     7a1:	07                   	pop    es
     7a2:	54                   	push   sp
     7a3:	61                   	popa
     7a4:	62 53 74             	bound  dx,DWORD PTR [bp+di+0x74]
     7a7:	6f                   	outs   dx,WORD PTR ds:[si]
     7a8:	70 f5                	jo     0x79f
     7aa:	22 c9                	and    cl,cl
     7ac:	07                   	pop    es
     7ad:	33 17                	xor    dx,WORD PTR [bx]
     7af:	b3 07                	mov    bl,0x7
     7b1:	8b 17                	mov    dx,WORD PTR [bx]
     7b3:	37                   	aaa
     7b4:	0a 01                	or     al,BYTE PTR [bx+di]
     7b6:	00 00                	add    BYTE PTR [bx+si],al
     7b8:	00 00                	add    BYTE PTR [bx+si],al
     7ba:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7bd:	00 80 1f 00          	add    BYTE PTR [bx+si+0x1f],al
     7c1:	05 56 61             	add    ax,0x6156
     7c4:	6c                   	ins    BYTE PTR es:[di],dx
     7c5:	75 65                	jne    0x82c
     7c7:	07                   	pop    es
     7c8:	23 db                	and    bx,bx
     7ca:	09 29                	or     WORD PTR [bx+di],bp
     7cc:	00 ff                	add    bh,bh
     7ce:	ff 77 1c             	push   WORD PTR [bx+0x1c]
     7d1:	4d                   	dec    bp
     7d2:	08 01                	or     BYTE PTR [bx+di],al
     7d4:	00 00                	add    BYTE PTR [bx+si],al
     7d6:	00 00                	add    BYTE PTR [bx+si],al
     7d8:	80 01 00             	add    BYTE PTR [bx+di],0x0
     7db:	00 00                	add    BYTE PTR [bx+si],al
     7dd:	20 00                	and    BYTE PTR [bx+si],al
     7df:	07                   	pop    es
     7e0:	56                   	push   si
     7e1:	69 73 69 62 6c       	imul   si,WORD PTR [bp+di+0x69],0x6c62
     7e6:	65 71 00             	gs jno 0x7e9
     7e9:	0a 08                	or     cl,BYTE PTR [bx+si]
     7eb:	e4 00                	in     al,0x0
     7ed:	ff                   	(bad)
     7ee:	ff e4                	jmp    sp
     7f0:	00 ff                	add    bh,bh
     7f2:	ff 01                	inc    WORD PTR [bx+di]
     7f4:	00 00                	add    BYTE PTR [bx+si],al
     7f6:	00 00                	add    BYTE PTR [bx+si],al
     7f8:	80 00 00             	add    BYTE PTR [bx+si],0x0
     7fb:	00 80 21 00          	add    BYTE PTR [bx+si+0x21],al
     7ff:	08 4f 6e             	or     BYTE PTR [bx+0x6e],cl
     802:	43                   	inc    bx
     803:	68 61 6e             	push   0x6e61
     806:	67 65 71 00          	addr32 gs jno 0x80a
     80a:	2a 08                	sub    cl,BYTE PTR [bx+si]
     80c:	7a 00                	jp     0x80e
     80e:	ff                   	(bad)
     80f:	ff                   	(bad)
     810:	7a 00                	jp     0x812
     812:	ff                   	(bad)
     813:	ff 01                	inc    WORD PTR [bx+di]
     815:	00 00                	add    BYTE PTR [bx+si],al
     817:	00 00                	add    BYTE PTR [bx+si],al
     819:	80 00 00             	add    BYTE PTR [bx+si],0x0
     81c:	00 80 22 00          	add    BYTE PTR [bx+si+0x22],al
     820:	07                   	pop    es
     821:	4f                   	dec    di
     822:	6e                   	outs   dx,BYTE PTR ds:[si]
     823:	43                   	inc    bx
     824:	6c                   	ins    BYTE PTR es:[di],dx
     825:	69 63 6b 71 00       	imul   sp,WORD PTR [bp+di+0x6b],0x71
     82a:	b5 08                	mov    ch,0x8
     82c:	82 00 ff             	add    BYTE PTR [bx+si],0xff
     82f:	ff 82 00 ff          	inc    WORD PTR [bp+si-0x100]
     833:	ff 01                	inc    WORD PTR [bx+di]
     835:	00 00                	add    BYTE PTR [bx+si],al
     837:	00 00                	add    BYTE PTR [bx+si],al
     839:	80 00 00             	add    BYTE PTR [bx+si],0x0
     83c:	00 80 23 00          	add    BYTE PTR [bx+si+0x23],al
     840:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     843:	44                   	inc    sp
     844:	62 6c 43             	bound  bp,DWORD PTR [si+0x43]
     847:	6c                   	ins    BYTE PTR es:[di],dx
     848:	69 63 6b ea 02       	imul   sp,WORD PTR [bp+di+0x6b],0x2ea
     84d:	70 08                	jo     0x857
     84f:	62 00                	bound  ax,DWORD PTR [bx+si]
     851:	ff                   	(bad)
     852:	ff 62 00             	jmp    WORD PTR [bp+si+0x0]
     855:	ff                   	(bad)
     856:	ff 01                	inc    WORD PTR [bx+di]
     858:	00 00                	add    BYTE PTR [bx+si],al
     85a:	00 00                	add    BYTE PTR [bx+si],al
     85c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     85f:	00 80 24 00          	add    BYTE PTR [bx+si+0x24],al
     863:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     866:	44                   	inc    sp
     867:	72 61                	jb     0x8ca
     869:	67 44                	addr32 inc sp
     86b:	72 6f                	jb     0x8dc
     86d:	70 80                	jo     0x7ef
     86f:	02 93 08 6a          	add    dl,BYTE PTR [bp+di+0x6a08]
     873:	00 ff                	add    bh,bh
     875:	ff 6a 00             	jmp    DWORD PTR [bp+si+0x0]
     878:	ff                   	(bad)
     879:	ff 01                	inc    WORD PTR [bx+di]
     87b:	00 00                	add    BYTE PTR [bx+si],al
     87d:	00 00                	add    BYTE PTR [bx+si],al
     87f:	80 00 00             	add    BYTE PTR [bx+si],0x0
     882:	00 80 25 00          	add    BYTE PTR [bx+si+0x25],al
     886:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     889:	44                   	inc    sp
     88a:	72 61                	jb     0x8ed
     88c:	67 4f                	addr32 dec di
     88e:	76 65                	jbe    0x8f5
     890:	72 32                	jb     0x8c4
     892:	03 f4                	add    si,sp
     894:	08 72 00             	or     BYTE PTR [bp+si+0x0],dh
     897:	ff                   	(bad)
     898:	ff 72 00             	push   WORD PTR [bp+si+0x0]
     89b:	ff                   	(bad)
     89c:	ff 01                	inc    WORD PTR [bx+di]
     89e:	00 00                	add    BYTE PTR [bx+si],al
     8a0:	00 00                	add    BYTE PTR [bx+si],al
     8a2:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8a5:	00 80 26 00          	add    BYTE PTR [bx+si+0x26],al
     8a9:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     8ac:	45                   	inc    bp
     8ad:	6e                   	outs   dx,BYTE PTR ds:[si]
     8ae:	64 44                	fs inc sp
     8b0:	72 61                	jb     0x913
     8b2:	67 71 00             	addr32 jno 0x8b5
     8b5:	d5 08                	aad    0x8
     8b7:	c8 00 ff ff          	enter  0xff00,0xff
     8bb:	c8 00 ff ff          	enter  0xff00,0xff
     8bf:	01 00                	add    WORD PTR [bx+si],ax
     8c1:	00 00                	add    BYTE PTR [bx+si],al
     8c3:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     8c7:	00 80 27 00          	add    BYTE PTR [bx+si+0x27],al
     8cb:	07                   	pop    es
     8cc:	4f                   	dec    di
     8cd:	6e                   	outs   dx,BYTE PTR ds:[si]
     8ce:	45                   	inc    bp
     8cf:	6e                   	outs   dx,BYTE PTR ds:[si]
     8d0:	74 65                	je     0x937
     8d2:	72 71                	jb     0x945
     8d4:	00 f3                	add    bl,dh
     8d6:	09 d0                	or     ax,dx
     8d8:	00 ff                	add    bh,bh
     8da:	ff d0                	call   ax
     8dc:	00 ff                	add    bh,bh
     8de:	ff 01                	inc    WORD PTR [bx+di]
     8e0:	00 00                	add    BYTE PTR [bx+si],al
     8e2:	00 00                	add    BYTE PTR [bx+si],al
     8e4:	80 00 00             	add    BYTE PTR [bx+si],0x0
     8e7:	00 80 28 00          	add    BYTE PTR [bx+si+0x28],al
     8eb:	06                   	push   es
     8ec:	4f                   	dec    di
     8ed:	6e                   	outs   dx,BYTE PTR ds:[si]
     8ee:	45                   	inc    bp
     8ef:	78 69                	js     0x95a
     8f1:	74 1a                	je     0x90d
     8f3:	02 16 09 b0          	add    dl,BYTE PTR ds:0xb009
     8f7:	00 ff                	add    bh,bh
     8f9:	ff b0 00 ff          	push   WORD PTR [bx+si-0x100]
     8fd:	ff 01                	inc    WORD PTR [bx+di]
     8ff:	00 00                	add    BYTE PTR [bx+si],al
     901:	00 00                	add    BYTE PTR [bx+si],al
     903:	80 00 00             	add    BYTE PTR [bx+si],0x0
     906:	00 80 29 00          	add    BYTE PTR [bx+si+0x29],al
     90a:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     90d:	4b                   	dec    bx
     90e:	65 79 44             	gs jns 0x955
     911:	6f                   	outs   dx,WORD PTR ds:[si]
     912:	77 6e                	ja     0x982
     914:	54                   	push   sp
     915:	02 39                	add    bh,BYTE PTR [bx+di]
     917:	09 b8 00 ff          	or     WORD PTR [bx+si-0x100],di
     91b:	ff                   	(bad)
     91c:	b8 00 ff             	mov    ax,0xff00
     91f:	ff 01                	inc    WORD PTR [bx+di]
     921:	00 00                	add    BYTE PTR [bx+si],al
     923:	00 00                	add    BYTE PTR [bx+si],al
     925:	80 00 00             	add    BYTE PTR [bx+si],0x0
     928:	00 80 2a 00          	add    BYTE PTR [bx+si+0x2a],al
     92c:	0a 4f 6e             	or     cl,BYTE PTR [bx+0x6e]
     92f:	4b                   	dec    bx
     930:	65 79 50             	gs jns 0x983
     933:	72 65                	jb     0x99a
     935:	73 73                	jae    0x9aa
     937:	1a 02                	sbb    al,BYTE PTR [bp+si]
     939:	59                   	pop    cx
     93a:	09 c0                	or     ax,ax
     93c:	00 ff                	add    bh,bh
     93e:	ff c0                	inc    ax
     940:	00 ff                	add    bh,bh
     942:	ff 01                	inc    WORD PTR [bx+di]
     944:	00 00                	add    BYTE PTR [bx+si],al
     946:	00 00                	add    BYTE PTR [bx+si],al
     948:	80 00 00             	add    BYTE PTR [bx+si],0x0
     94b:	00 80 2b 00          	add    BYTE PTR [bx+si+0x2b],al
     94f:	07                   	pop    es
     950:	4f                   	dec    di
     951:	6e                   	outs   dx,BYTE PTR ds:[si]
     952:	4b                   	dec    bx
     953:	65 79 55             	gs jns 0x9ab
     956:	70 71                	jo     0x9c9
     958:	01 7d 09             	add    WORD PTR [di+0x9],di
     95b:	4a                   	dec    dx
     95c:	00 ff                	add    bh,bh
     95e:	ff 4a 00             	dec    WORD PTR [bp+si+0x0]
     961:	ff                   	(bad)
     962:	ff 01                	inc    WORD PTR [bx+di]
     964:	00 00                	add    BYTE PTR [bx+si],al
     966:	00 00                	add    BYTE PTR [bx+si],al
     968:	80 00 00             	add    BYTE PTR [bx+si],0x0
     96b:	00 80 2c 00          	add    BYTE PTR [bx+si+0x2c],al
     96f:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     972:	4d                   	dec    bp
     973:	6f                   	outs   dx,WORD PTR ds:[si]
     974:	75 73                	jne    0x9e9
     976:	65 44                	gs inc sp
     978:	6f                   	outs   dx,WORD PTR ds:[si]
     979:	77 6e                	ja     0x9e9
     97b:	ce                   	into
     97c:	01 a1 09 52          	add    WORD PTR [bx+di+0x5209],sp
     980:	00 ff                	add    bh,bh
     982:	ff 52 00             	call   WORD PTR [bp+si+0x0]
     985:	ff                   	(bad)
     986:	ff 01                	inc    WORD PTR [bx+di]
     988:	00 00                	add    BYTE PTR [bx+si],al
     98a:	00 00                	add    BYTE PTR [bx+si],al
     98c:	80 00 00             	add    BYTE PTR [bx+si],0x0
     98f:	00 80 2d 00          	add    BYTE PTR [bx+si+0x2d],al
     993:	0b 4f 6e             	or     cx,WORD PTR [bx+0x6e]
     996:	4d                   	dec    bp
     997:	6f                   	outs   dx,WORD PTR ds:[si]
     998:	75 73                	jne    0xa0d
     99a:	65 4d                	gs dec bp
     99c:	6f                   	outs   dx,WORD PTR ds:[si]
     99d:	76 65                	jbe    0xa04
     99f:	71 01                	jno    0x9a2
     9a1:	d3 09                	ror    WORD PTR [bx+di],cl
     9a3:	5a                   	pop    dx
     9a4:	00 ff                	add    bh,bh
     9a6:	ff 5a 00             	call   DWORD PTR [bp+si+0x0]
     9a9:	ff                   	(bad)
     9aa:	ff 01                	inc    WORD PTR [bx+di]
     9ac:	00 00                	add    BYTE PTR [bx+si],al
     9ae:	00 00                	add    BYTE PTR [bx+si],al
     9b0:	80 00 00             	add    BYTE PTR [bx+si],0x0
     9b3:	00 80 2e 00          	add    BYTE PTR [bx+si+0x2e],al
     9b7:	09 4f 6e             	or     WORD PTR [bx+0x6e],cx
     9ba:	4d                   	dec    bp
     9bb:	6f                   	outs   dx,WORD PTR ds:[si]
     9bc:	75 73                	jne    0xa31
     9be:	65 55                	gs push bp
     9c0:	70 59                	jo     0xa1b
     9c2:	0a 00                	or     al,BYTE PTR [bx+si]
     9c4:	00 00                	add    BYTE PTR [bx+si],al
     9c6:	00 4b 0a             	add    BYTE PTR [bp+di+0xa],cl
     9c9:	39 0a                	cmp    WORD PTR [bp+si],cx
     9cb:	a2 00 bb             	mov    ds:0xbb00,al
     9ce:	00 72 0a             	add    BYTE PTR [bp+si+0xa],dh
     9d1:	10 26 e7 09          	adc    BYTE PTR ds:0x9e7,ah
     9d5:	9a 1f 8c 0a cb       	call   0xcb0a:0x8c1f
     9da:	1f                   	pop    ds
     9db:	d7                   	xlat   BYTE PTR ds:[bx]
     9dc:	09 79 18             	or     WORD PTR [bx+di+0x18],di
     9df:	53                   	push   bx
     9e0:	0a cd                	or     cl,ch
     9e2:	11 eb                	adc    bx,bp
     9e4:	09 3a                	or     WORD PTR [bp+si],di
     9e6:	27                   	daa
     9e7:	13 0a                	adc    cx,WORD PTR [bp+si]
     9e9:	fa                   	cli
     9ea:	10 e2                	adc    dl,ah
     9ec:	0f d6                	(bad)
     9ee:	14 f7                	adc    al,0xf7
     9f0:	09 f4                	or     sp,si
     9f2:	4f                   	dec    di
     9f3:	03 0a                	add    cx,WORD PTR [bp+si]
     9f5:	32 16 fb 09          	xor    dl,BYTE PTR ds:0x9fb
     9f9:	98                   	cbw
     9fa:	15 1f 0a             	adc    ax,0xa1f
     9fd:	51                   	push   cx
     9fe:	1b 23                	sbb    sp,WORD PTR [bp+di]
     a00:	0a 38                	or     bh,BYTE PTR [bx+si]
     a02:	50                   	push   ax
     a03:	07                   	pop    es
     a04:	0a 1a                	or     bl,BYTE PTR [bp+si]
     a06:	50                   	push   ax
     a07:	0b 0a                	or     cx,WORD PTR [bp+si]
     a09:	21 50 e3             	and    WORD PTR [bx+si-0x1d],dx
     a0c:	09 27                	or     WORD PTR [bx],sp
     a0e:	1f                   	pop    ds
     a0f:	cf                   	iret
     a10:	09 3f                	or     WORD PTR [bx],di
     a12:	19 17                	sbb    WORD PTR [bx],dx
     a14:	0a 78 18             	or     bh,BYTE PTR [bx+si+0x18]
     a17:	1b 0a                	sbb    cx,WORD PTR [bp+si]
     a19:	02 21                	add    ah,BYTE PTR [bx+di]
     a1b:	ef                   	out    dx,ax
     a1c:	09 3a                	or     WORD PTR [bp+si],di
     a1e:	1c ff                	sbb    al,0xff
     a20:	09 15                	or     WORD PTR [di],dx
     a22:	25 27 0a             	and    ax,0xa27
     a25:	37                   	aaa
     a26:	22 2b                	and    ch,BYTE PTR [bp+di]
     a28:	0a df                	or     bl,bh
     a2a:	22 2f                	and    ch,BYTE PTR [bx]
     a2c:	0a f8                	or     bh,al
     a2e:	16                   	push   ss
     a2f:	33 0a                	xor    cx,WORD PTR [bp+si]
     a31:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     a32:	22 9f 0a fe          	and    bl,BYTE PTR [bx-0x1f6]
     a36:	19 df                	sbb    di,bx
     a38:	09 11                	or     WORD PTR [bx+di],dx
     a3a:	54                   	push   sp
     a3b:	54                   	push   sp
     a3c:	69 6d 65 72 53       	imul   bp,WORD PTR [di+0x65],0x5372
     a41:	70 65                	jo     0xaa8
     a43:	65 64 42             	gs fs inc dx
     a46:	75 74                	jne    0xabc
     a48:	74 6f                	je     0xab9
     a4a:	6e                   	outs   dx,BYTE PTR ds:[si]
     a4b:	02 00                	add    al,BYTE PTR [bx+si]
     a4d:	fa                   	cli
     a4e:	ff                   	(bad)
     a4f:	f8                   	clc
     a50:	ff b3 18 57          	push   WORD PTR [bp+di+0x5718]
     a54:	0a 4b 19             	or     cl,BYTE PTR [bp+di+0x19]
     a57:	6e                   	outs   dx,BYTE PTR ds:[si]
     a58:	0a 07                	or     al,BYTE PTR [bx]
     a5a:	11 54 54             	adc    WORD PTR [si+0x54],dx
     a5d:	69 6d 65 72 53       	imul   bp,WORD PTR [di+0x65],0x5372
     a62:	70 65                	jo     0xac9
     a64:	65 64 42             	gs fs inc dx
     a67:	75 74                	jne    0xadd
     a69:	74 6f                	je     0xada
     a6b:	6e                   	outs   dx,BYTE PTR ds:[si]
     a6c:	e1 09                	loope  0xa77
     a6e:	b7 0a                	mov    bh,0xa
     a70:	6a 01                	push   0x1
     a72:	51                   	push   cx
     a73:	0b 1c                	or     bx,WORD PTR [si]
     a75:	00 04                	add    BYTE PTR [si],al
     a77:	53                   	push   bx
     a78:	70 69                	jo     0xae3
     a7a:	6e                   	outs   dx,BYTE PTR ds:[si]
     a7b:	00 00                	add    BYTE PTR [bx+si],al
     a7d:	55                   	push   bp
     a7e:	89 e5                	mov    bp,sp
     a80:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     a84:	74 08                	je     0xa8e
     a86:	83 ec 08             	sub    sp,0x8
     a89:	9a e2 1f bf 0d       	call   0xdbf:0x1fe2
     a8e:	ff 76 0e             	push   WORD PTR [bp+0xe]
     a91:	ff 76 0c             	push   WORD PTR [bp+0xc]
     a94:	31 c0                	xor    ax,ax
     a96:	50                   	push   ax
     a97:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     a9a:	06                   	push   es
     a9b:	57                   	push   di
     a9c:	9a 61 2e fd 0a       	call   0xafd:0x2e61
     aa1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aa4:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
     aa8:	25 de ff             	and    ax,0xffde
     aab:	0d 50 00             	or     ax,0x50
     aae:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
     ab2:	06                   	push   es
     ab3:	57                   	push   di
     ab4:	9a 39 0b cb 0a       	call   0xacb:0xb39
     ab9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     abc:	26 89 85 d8 00       	mov    WORD PTR es:[di+0xd8],ax
     ac1:	26 89 95 da 00       	mov    WORD PTR es:[di+0xda],dx
     ac6:	06                   	push   es
     ac7:	57                   	push   di
     ac8:	9a 39 0b e3 0a       	call   0xae3:0xb39
     acd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ad0:	26 89 85 dc 00       	mov    WORD PTR es:[di+0xdc],ax
     ad5:	26 89 95 de 00       	mov    WORD PTR es:[di+0xde],dx
     ada:	6a 00                	push   0x0
     adc:	6a 00                	push   0x0
     ade:	06                   	push   es
     adf:	57                   	push   di
     ae0:	9a 5d 10 f1 0a       	call   0xaf1:0x105d
     ae5:	6a 00                	push   0x0
     ae7:	6a 00                	push   0x0
     ae9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     aec:	06                   	push   es
     aed:	57                   	push   di
     aee:	9a f1 10 4a 0b       	call   0xb4a:0x10f1
     af3:	6a 14                	push   0x14
     af5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     af8:	06                   	push   es
     af9:	57                   	push   di
     afa:	9a bf 17 09 0b       	call   0xb09:0x17bf
     aff:	6a 19                	push   0x19
     b01:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b04:	06                   	push   es
     b05:	57                   	push   di
     b06:	9a e1 17 a0 0b       	call   0xba0:0x17e1
     b0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b0e:	26 8b 85 d8 00       	mov    ax,WORD PTR es:[di+0xd8]
     b13:	26 8b 95 da 00       	mov    dx,WORD PTR es:[di+0xda]
     b18:	26 89 85 e0 00       	mov    WORD PTR es:[di+0xe0],ax
     b1d:	26 89 95 e2 00       	mov    WORD PTR es:[di+0xe2],dx
     b22:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     b26:	74 07                	je     0xb2f
     b28:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     b2c:	83 c4 06             	add    sp,0x6
     b2f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     b32:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     b35:	c9                   	leave
     b36:	ca 0a 00             	retf   0xa
     b39:	c8 04 00 00          	enter  0x4,0x0
     b3d:	ff 76 08             	push   WORD PTR [bp+0x8]
     b40:	ff 76 06             	push   WORD PTR [bp+0x6]
     b43:	b0 01                	mov    al,0x1
     b45:	50                   	push   ax
     b46:	b8 e1 09             	mov    ax,0x9e1
     b49:	ba 62 0b             	mov    dx,0xb62
     b4c:	52                   	push   dx
     b4d:	50                   	push   ax
     b4e:	9a 27 1f c1 0b       	call   0xbc1:0x1f27
     b53:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b56:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     b59:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b5c:	06                   	push   es
     b5d:	57                   	push   di
     b5e:	b8 be 0e             	mov    ax,0xebe
     b61:	ba 81 0b             	mov    dx,0xb81
     b64:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     b67:	26 89 45 7a          	mov    WORD PTR es:[di+0x7a],ax
     b6b:	26 89 55 7c          	mov    WORD PTR es:[di+0x7c],dx
     b6f:	26 8f 45 7e          	pop    WORD PTR es:[di+0x7e]
     b73:	26 8f 85 80 00       	pop    WORD PTR es:[di+0x80]
     b78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     b7b:	06                   	push   es
     b7c:	57                   	push   di
     b7d:	b8 0b 0e             	mov    ax,0xe0b
     b80:	ba 92 0c             	mov    dx,0xc92
     b83:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     b86:	26 89 45 4a          	mov    WORD PTR es:[di+0x4a],ax
     b8a:	26 89 55 4c          	mov    WORD PTR es:[di+0x4c],dx
     b8e:	26 8f 45 4e          	pop    WORD PTR es:[di+0x4e]
     b92:	26 8f 45 50          	pop    WORD PTR es:[di+0x50]
     b96:	6a 01                	push   0x1
     b98:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     b9b:	06                   	push   es
     b9c:	57                   	push   di
     b9d:	9a 77 1c ac 0b       	call   0xbac:0x1c77
     ba2:	6a 01                	push   0x1
     ba4:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     ba7:	06                   	push   es
     ba8:	57                   	push   di
     ba9:	9a b8 1c a8 0c       	call   0xca8:0x1cb8
     bae:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     bb1:	26 c6 85 a1 00 02    	mov    BYTE PTR es:[di+0xa1],0x2
     bb7:	6a 01                	push   0x1
     bb9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     bbc:	06                   	push   es
     bbd:	57                   	push   di
     bbe:	9a bf 23 4b 10       	call   0x104b:0x23bf
     bc3:	ff 76 08             	push   WORD PTR [bp+0x8]
     bc6:	ff 76 06             	push   WORD PTR [bp+0x6]
     bc9:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     bcc:	06                   	push   es
     bcd:	57                   	push   di
     bce:	26 c4 3d             	les    di,DWORD PTR es:[di]
     bd1:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
     bd5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     bd8:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     bdb:	c9                   	leave
     bdc:	ca 04 00             	retf   0x4
     bdf:	c8 02 00 00          	enter  0x2,0x0
     be3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     be6:	26 8b 85 d8 00       	mov    ax,WORD PTR es:[di+0xd8]
     beb:	26 0b 85 da 00       	or     ax,WORD PTR es:[di+0xda]
     bf0:	74 07                	je     0xbf9
     bf2:	26 f6 45 18 01       	test   BYTE PTR es:[di+0x18],0x1
     bf7:	74 02                	je     0xbfb
     bf9:	eb 71                	jmp    0xc6c
     bfb:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     bfe:	26 83 3d 0f          	cmp    WORD PTR es:[di],0xf
     c02:	7d 05                	jge    0xc09
     c04:	26 c7 05 0f 00       	mov    WORD PTR es:[di],0xf
     c09:	6a 00                	push   0x0
     c0b:	6a 00                	push   0x0
     c0d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     c10:	26 ff 35             	push   WORD PTR es:[di]
     c13:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     c16:	26 8b 05             	mov    ax,WORD PTR es:[di]
     c19:	99                   	cwd
     c1a:	b9 02 00             	mov    cx,0x2
     c1d:	f7 f9                	idiv   cx
     c1f:	50                   	push   ax
     c20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c23:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     c28:	06                   	push   es
     c29:	57                   	push   di
     c2a:	26 c4 3d             	les    di,DWORD PTR es:[di]
     c2d:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
     c31:	6a 00                	push   0x0
     c33:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c36:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     c3b:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
     c3f:	48                   	dec    ax
     c40:	50                   	push   ax
     c41:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     c44:	26 ff 35             	push   WORD PTR es:[di]
     c47:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     c4a:	26 8b 05             	mov    ax,WORD PTR es:[di]
     c4d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c50:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     c55:	26 2b 45 24          	sub    ax,WORD PTR es:[di+0x24]
     c59:	40                   	inc    ax
     c5a:	50                   	push   ax
     c5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c5e:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
     c63:	06                   	push   es
     c64:	57                   	push   di
     c65:	26 c4 3d             	les    di,DWORD PTR es:[di]
     c68:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
     c6c:	c9                   	leave
     c6d:	ca 0c 00             	retf   0xc
     c70:	c8 04 00 00          	enter  0x4,0x0
     c74:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     c77:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     c7a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     c7d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     c80:	8d 7e fe             	lea    di,[bp-0x2]
     c83:	16                   	push   ss
     c84:	57                   	push   di
     c85:	8d 7e fc             	lea    di,[bp-0x4]
     c88:	16                   	push   ss
     c89:	57                   	push   di
     c8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c8d:	06                   	push   es
     c8e:	57                   	push   di
     c8f:	9a df 0b e5 0c       	call   0xce5:0xbdf
     c94:	ff 76 10             	push   WORD PTR [bp+0x10]
     c97:	ff 76 0e             	push   WORD PTR [bp+0xe]
     c9a:	ff 76 fe             	push   WORD PTR [bp-0x2]
     c9d:	ff 76 fc             	push   WORD PTR [bp-0x4]
     ca0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ca3:	06                   	push   es
     ca4:	57                   	push   di
     ca5:	9a 62 5c c0 0c       	call   0xcc0:0x5c62
     caa:	c9                   	leave
     cab:	ca 0c 00             	retf   0xc
     cae:	c8 04 00 00          	enter  0x4,0x0
     cb2:	ff 76 0c             	push   WORD PTR [bp+0xc]
     cb5:	ff 76 0a             	push   WORD PTR [bp+0xa]
     cb8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cbb:	06                   	push   es
     cbc:	57                   	push   di
     cbd:	9a a8 4d 12 0d       	call   0xd12:0x4da8
     cc2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cc5:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
     cc9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     ccc:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
     cd0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     cd3:	8d 7e fe             	lea    di,[bp-0x2]
     cd6:	16                   	push   ss
     cd7:	57                   	push   di
     cd8:	8d 7e fc             	lea    di,[bp-0x4]
     cdb:	16                   	push   ss
     cdc:	57                   	push   di
     cdd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ce0:	06                   	push   es
     ce1:	57                   	push   di
     ce2:	9a df 0b ad 0d       	call   0xdad:0xbdf
     ce7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     cea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ced:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
     cf1:	75 09                	jne    0xcfc
     cf3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     cf6:	26 3b 45 24          	cmp    ax,WORD PTR es:[di+0x24]
     cfa:	74 18                	je     0xd14
     cfc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cff:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
     d03:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
     d07:	ff 76 fe             	push   WORD PTR [bp-0x2]
     d0a:	ff 76 fc             	push   WORD PTR [bp-0x4]
     d0d:	06                   	push   es
     d0e:	57                   	push   di
     d0f:	9a 62 5c 50 0e       	call   0xe50:0x5c62
     d14:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     d17:	31 c0                	xor    ax,ax
     d19:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     d1d:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
     d21:	c9                   	leave
     d22:	ca 08 00             	retf   0x8
     d25:	55                   	push   bp
     d26:	89 e5                	mov    bp,sp
     d28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d2b:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     d30:	26 8a 85 a1 00       	mov    al,BYTE PTR es:[di+0xa1]
     d35:	0c 01                	or     al,0x1
     d37:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d3a:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     d3f:	26 88 85 a1 00       	mov    BYTE PTR es:[di+0xa1],al
     d44:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d47:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     d4c:	06                   	push   es
     d4d:	57                   	push   di
     d4e:	26 c4 3d             	les    di,DWORD PTR es:[di]
     d51:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
     d55:	c9                   	leave
     d56:	ca 08 00             	retf   0x8
     d59:	55                   	push   bp
     d5a:	89 e5                	mov    bp,sp
     d5c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d5f:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     d64:	26 8a 85 a1 00       	mov    al,BYTE PTR es:[di+0xa1]
     d69:	24 fe                	and    al,0xfe
     d6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d6e:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     d73:	26 88 85 a1 00       	mov    BYTE PTR es:[di+0xa1],al
     d78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d7b:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     d80:	06                   	push   es
     d81:	57                   	push   di
     d82:	26 c4 3d             	les    di,DWORD PTR es:[di]
     d85:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
     d89:	c9                   	leave
     d8a:	ca 08 00             	retf   0x8
     d8d:	55                   	push   bp
     d8e:	89 e5                	mov    bp,sp
     d90:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     d93:	26 8b 05             	mov    ax,WORD PTR es:[di]
     d96:	3d 26 00             	cmp    ax,0x26
     d99:	75 28                	jne    0xdc3
     d9b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d9e:	26 ff b5 da 00       	push   WORD PTR es:[di+0xda]
     da3:	26 ff b5 d8 00       	push   WORD PTR es:[di+0xd8]
     da8:	06                   	push   es
     da9:	57                   	push   di
     daa:	9a 1d 0f da 0d       	call   0xdda:0xf1d
     daf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     db2:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
     db7:	06                   	push   es
     db8:	57                   	push   di
     db9:	b8 fe ff             	mov    ax,0xfffe
     dbc:	9a 6a 20 ec 0d       	call   0xdec:0x206a
     dc1:	eb 44                	jmp    0xe07
     dc3:	3d 28 00             	cmp    ax,0x28
     dc6:	75 28                	jne    0xdf0
     dc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dcb:	26 ff b5 de 00       	push   WORD PTR es:[di+0xde]
     dd0:	26 ff b5 dc 00       	push   WORD PTR es:[di+0xdc]
     dd5:	06                   	push   es
     dd6:	57                   	push   di
     dd7:	9a 1d 0f 25 0e       	call   0xe25:0xf1d
     ddc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ddf:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
     de4:	06                   	push   es
     de5:	57                   	push   di
     de6:	b8 fe ff             	mov    ax,0xfffe
     de9:	9a 6a 20 05 0e       	call   0xe05:0x206a
     dee:	eb 17                	jmp    0xe07
     df0:	3d 20 00             	cmp    ax,0x20
     df3:	75 12                	jne    0xe07
     df5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     df8:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     dfd:	06                   	push   es
     dfe:	57                   	push   di
     dff:	b8 fe ff             	mov    ax,0xfffe
     e02:	9a 6a 20 73 11       	call   0x1173:0x206a
     e07:	c9                   	leave
     e08:	ca 0a 00             	retf   0xa
     e0b:	55                   	push   bp
     e0c:	89 e5                	mov    bp,sp
     e0e:	80 7e 10 00          	cmp    BYTE PTR [bp+0x10],0x0
     e12:	74 03                	je     0xe17
     e14:	e9 a3 00             	jmp    0xeba
     e17:	ff 76 14             	push   WORD PTR [bp+0x14]
     e1a:	ff 76 12             	push   WORD PTR [bp+0x12]
     e1d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e20:	06                   	push   es
     e21:	57                   	push   di
     e22:	9a 1d 0f 07 10       	call   0x1007:0xf1d
     e27:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e2a:	26 8b 85 e4 00       	mov    ax,WORD PTR es:[di+0xe4]
     e2f:	26 0b 85 e6 00       	or     ax,WORD PTR es:[di+0xe6]
     e34:	74 4d                	je     0xe83
     e36:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
     e3b:	26 80 bd a4 00 00    	cmp    BYTE PTR es:[di+0xa4],0x0
     e41:	74 40                	je     0xe83
     e43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e46:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
     e4b:	06                   	push   es
     e4c:	57                   	push   di
     e4d:	9a c4 61 63 0e       	call   0xe63:0x61c4
     e52:	08 c0                	or     al,al
     e54:	74 2d                	je     0xe83
     e56:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e59:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
     e5e:	06                   	push   es
     e5f:	57                   	push   di
     e60:	9a b9 62 93 0e       	call   0xe93:0x62b9
     e65:	50                   	push   ax
     e66:	9a 97 0e 00 00       	call   0x0:0xe97
     e6b:	5a                   	pop    dx
     e6c:	3b c2                	cmp    ax,dx
     e6e:	74 13                	je     0xe83
     e70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e73:	26 c4 bd e4 00       	les    di,DWORD PTR es:[di+0xe4]
     e78:	06                   	push   es
     e79:	57                   	push   di
     e7a:	26 c4 3d             	les    di,DWORD PTR es:[di]
     e7d:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
     e81:	eb 37                	jmp    0xeba
     e83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e86:	26 80 bd a4 00 00    	cmp    BYTE PTR es:[di+0xa4],0x0
     e8c:	74 2c                	je     0xeba
     e8e:	06                   	push   es
     e8f:	57                   	push   di
     e90:	9a b9 62 a8 0e       	call   0xea8:0x62b9
     e95:	50                   	push   ax
     e96:	9a 8b 0f 00 00       	call   0x0:0xf8b
     e9b:	5a                   	pop    dx
     e9c:	3b c2                	cmp    ax,dx
     e9e:	74 1a                	je     0xeba
     ea0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ea3:	06                   	push   es
     ea4:	57                   	push   di
     ea5:	9a c4 61 33 0f       	call   0xf33:0x61c4
     eaa:	08 c0                	or     al,al
     eac:	74 0c                	je     0xeba
     eae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eb1:	06                   	push   es
     eb2:	57                   	push   di
     eb3:	26 c4 3d             	les    di,DWORD PTR es:[di]
     eb6:	26 ff 5d 78          	call   DWORD PTR es:[di+0x78]
     eba:	c9                   	leave
     ebb:	ca 10 00             	retf   0x10
     ebe:	55                   	push   bp
     ebf:	89 e5                	mov    bp,sp
     ec1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     ec4:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
     ec7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eca:	26 3b 95 da 00       	cmp    dx,WORD PTR es:[di+0xda]
     ecf:	75 27                	jne    0xef8
     ed1:	26 3b 85 d8 00       	cmp    ax,WORD PTR es:[di+0xd8]
     ed6:	75 20                	jne    0xef8
     ed8:	26 8b 85 ea 00       	mov    ax,WORD PTR es:[di+0xea]
     edd:	09 c0                	or     ax,ax
     edf:	74 15                	je     0xef6
     ee1:	ff 76 08             	push   WORD PTR [bp+0x8]
     ee4:	ff 76 06             	push   WORD PTR [bp+0x6]
     ee7:	26 ff b5 ee 00       	push   WORD PTR es:[di+0xee]
     eec:	26 ff b5 ec 00       	push   WORD PTR es:[di+0xec]
     ef1:	26 ff 9d e8 00       	call   DWORD PTR es:[di+0xe8]
     ef6:	eb 21                	jmp    0xf19
     ef8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     efb:	26 8b 85 f2 00       	mov    ax,WORD PTR es:[di+0xf2]
     f00:	09 c0                	or     ax,ax
     f02:	74 15                	je     0xf19
     f04:	ff 76 08             	push   WORD PTR [bp+0x8]
     f07:	ff 76 06             	push   WORD PTR [bp+0x6]
     f0a:	26 ff b5 f6 00       	push   WORD PTR es:[di+0xf6]
     f0f:	26 ff b5 f4 00       	push   WORD PTR es:[di+0xf4]
     f14:	26 ff 9d f0 00       	call   DWORD PTR es:[di+0xf0]
     f19:	c9                   	leave
     f1a:	ca 08 00             	retf   0x8
     f1d:	55                   	push   bp
     f1e:	89 e5                	mov    bp,sp
     f20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f23:	26 80 bd a4 00 00    	cmp    BYTE PTR es:[di+0xa4],0x0
     f29:	75 03                	jne    0xf2e
     f2b:	e9 8e 00             	jmp    0xfbc
     f2e:	06                   	push   es
     f2f:	57                   	push   di
     f30:	9a c4 61 87 0f       	call   0xf87:0x61c4
     f35:	08 c0                	or     al,al
     f37:	75 03                	jne    0xf3c
     f39:	e9 80 00             	jmp    0xfbc
     f3c:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     f3f:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
     f42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f45:	26 3b 95 e2 00       	cmp    dx,WORD PTR es:[di+0xe2]
     f4a:	75 07                	jne    0xf53
     f4c:	26 3b 85 e0 00       	cmp    ax,WORD PTR es:[di+0xe0]
     f51:	74 69                	je     0xfbc
     f53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f56:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     f5b:	26 8a 85 a1 00       	mov    al,BYTE PTR es:[di+0xa1]
     f60:	24 fe                	and    al,0xfe
     f62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f65:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     f6a:	26 88 85 a1 00       	mov    BYTE PTR es:[di+0xa1],al
     f6f:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     f72:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
     f75:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f78:	26 89 85 e0 00       	mov    WORD PTR es:[di+0xe0],ax
     f7d:	26 89 95 e2 00       	mov    WORD PTR es:[di+0xe2],dx
     f82:	06                   	push   es
     f83:	57                   	push   di
     f84:	9a b9 62 34 10       	call   0x1034:0x62b9
     f89:	50                   	push   ax
     f8a:	9a ff ff 00 00       	call   0x0:0xffff
     f8f:	5a                   	pop    dx
     f90:	3b c2                	cmp    ax,dx
     f92:	75 28                	jne    0xfbc
     f94:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f97:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     f9c:	26 8a 85 a1 00       	mov    al,BYTE PTR es:[di+0xa1]
     fa1:	0c 01                	or     al,0x1
     fa3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fa6:	26 c4 bd e0 00       	les    di,DWORD PTR es:[di+0xe0]
     fab:	26 88 85 a1 00       	mov    BYTE PTR es:[di+0xa1],al
     fb0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fb3:	06                   	push   es
     fb4:	57                   	push   di
     fb5:	26 c4 3d             	les    di,DWORD PTR es:[di]
     fb8:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
     fbc:	c9                   	leave
     fbd:	ca 08 00             	retf   0x8
     fc0:	55                   	push   bp
     fc1:	89 e5                	mov    bp,sp
     fc3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     fc6:	26 c7 45 08 01 00    	mov    WORD PTR es:[di+0x8],0x1
     fcc:	26 c7 45 0a 00 00    	mov    WORD PTR es:[di+0xa],0x0
     fd2:	c9                   	leave
     fd3:	ca 08 00             	retf   0x8
     fd6:	c8 04 00 00          	enter  0x4,0x0
     fda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fdd:	06                   	push   es
     fde:	57                   	push   di
     fdf:	9a f4 4f 2e 1a       	call   0x1a2e:0x4ff4
     fe4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fe7:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
     feb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     fee:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
     ff2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ff5:	8d 7e fe             	lea    di,[bp-0x2]
     ff8:	16                   	push   ss
     ff9:	57                   	push   di
     ffa:	8d 7e fc             	lea    di,[bp-0x4]
     ffd:	16                   	push   ss
     ffe:	57                   	push   di
     fff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1002:	06                   	push   es
    1003:	57                   	push   di
    1004:	9a df 0b 95 11       	call   0x1195:0xbdf
    1009:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    100c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    100f:	26 3b 45 22          	cmp    ax,WORD PTR es:[di+0x22]
    1013:	75 09                	jne    0x101e
    1015:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1018:	26 3b 45 24          	cmp    ax,WORD PTR es:[di+0x24]
    101c:	74 18                	je     0x1036
    101e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1021:	26 ff 75 1e          	push   WORD PTR es:[di+0x1e]
    1025:	26 ff 75 20          	push   WORD PTR es:[di+0x20]
    1029:	ff 76 fe             	push   WORD PTR [bp-0x2]
    102c:	ff 76 fc             	push   WORD PTR [bp-0x4]
    102f:	06                   	push   es
    1030:	57                   	push   di
    1031:	9a 62 5c b7 11       	call   0x11b7:0x5c62
    1036:	c9                   	leave
    1037:	ca 04 00             	retf   0x4
    103a:	c8 04 00 00          	enter  0x4,0x0
    103e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1041:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1046:	06                   	push   es
    1047:	57                   	push   di
    1048:	9a 59 23 7b 10       	call   0x107b:0x2359
    104d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1050:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1053:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1056:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1059:	c9                   	leave
    105a:	ca 04 00             	retf   0x4
    105d:	55                   	push   bp
    105e:	89 e5                	mov    bp,sp
    1060:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1063:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1066:	74 17                	je     0x107f
    1068:	ff 76 0c             	push   WORD PTR [bp+0xc]
    106b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    106e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1071:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1076:	06                   	push   es
    1077:	57                   	push   di
    1078:	9a 7d 23 9b 10       	call   0x109b:0x237d
    107d:	eb 4b                	jmp    0x10ca
    107f:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    1083:	bf ca 0b             	mov    di,0xbca
    1086:	1e                   	push   ds
    1087:	57                   	push   di
    1088:	9a 1d 11 00 00       	call   0x0:0x111d
    108d:	50                   	push   ax
    108e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1091:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    1096:	06                   	push   es
    1097:	57                   	push   di
    1098:	9a 59 23 b7 10       	call   0x10b7:0x2359
    109d:	89 c7                	mov    di,ax
    109f:	8e c2                	mov    es,dx
    10a1:	06                   	push   es
    10a2:	57                   	push   di
    10a3:	9a 04 61 3a 11       	call   0x113a:0x6104
    10a8:	6a 01                	push   0x1
    10aa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10ad:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    10b2:	06                   	push   es
    10b3:	57                   	push   di
    10b4:	9a bf 23 df 10       	call   0x10df:0x23bf
    10b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10bc:	26 c4 bd d8 00       	les    di,DWORD PTR es:[di+0xd8]
    10c1:	06                   	push   es
    10c2:	57                   	push   di
    10c3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    10c6:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    10ca:	c9                   	leave
    10cb:	ca 08 00             	retf   0x8
    10ce:	c8 04 00 00          	enter  0x4,0x0
    10d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10d5:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    10da:	06                   	push   es
    10db:	57                   	push   di
    10dc:	9a 59 23 0f 11       	call   0x110f:0x2359
    10e1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    10e4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    10e7:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    10ea:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    10ed:	c9                   	leave
    10ee:	ca 04 00             	retf   0x4
    10f1:	55                   	push   bp
    10f2:	89 e5                	mov    bp,sp
    10f4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10f7:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    10fa:	74 17                	je     0x1113
    10fc:	ff 76 0c             	push   WORD PTR [bp+0xc]
    10ff:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1102:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1105:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    110a:	06                   	push   es
    110b:	57                   	push   di
    110c:	9a 7d 23 2f 11       	call   0x112f:0x237d
    1111:	eb 4b                	jmp    0x115e
    1113:	ff 36 8c 18          	push   WORD PTR ds:0x188c
    1117:	bf d2 0b             	mov    di,0xbd2
    111a:	1e                   	push   ds
    111b:	57                   	push   di
    111c:	9a ff ff 00 00       	call   0x0:0xffff
    1121:	50                   	push   ax
    1122:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1125:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    112a:	06                   	push   es
    112b:	57                   	push   di
    112c:	9a 59 23 4b 11       	call   0x114b:0x2359
    1131:	89 c7                	mov    di,ax
    1133:	8e c2                	mov    es,dx
    1135:	06                   	push   es
    1136:	57                   	push   di
    1137:	9a 04 61 97 15       	call   0x1597:0x6104
    113c:	6a 01                	push   0x1
    113e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1141:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    1146:	06                   	push   es
    1147:	57                   	push   di
    1148:	9a bf 23 a2 18       	call   0x18a2:0x23bf
    114d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1150:	26 c4 bd dc 00       	les    di,DWORD PTR es:[di+0xdc]
    1155:	06                   	push   es
    1156:	57                   	push   di
    1157:	26 c4 3d             	les    di,DWORD PTR es:[di]
    115a:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    115e:	c9                   	leave
    115f:	ca 08 00             	retf   0x8
    1162:	01 30                	add    WORD PTR [bx+si],si
    1164:	55                   	push   bp
    1165:	89 e5                	mov    bp,sp
    1167:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    116b:	74 08                	je     0x1175
    116d:	83 ec 08             	sub    sp,0x8
    1170:	9a e2 1f d3 12       	call   0x12d3:0x1fe2
    1175:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1178:	ff 76 0c             	push   WORD PTR [bp+0xc]
    117b:	31 c0                	xor    ax,ax
    117d:	50                   	push   ax
    117e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1181:	06                   	push   es
    1182:	57                   	push   di
    1183:	9a 09 47 1a 14       	call   0x141a:0x4709
    1188:	ff 76 08             	push   WORD PTR [bp+0x8]
    118b:	ff 76 06             	push   WORD PTR [bp+0x6]
    118e:	b0 01                	mov    al,0x1
    1190:	50                   	push   ax
    1191:	b8 22 00             	mov    ax,0x22
    1194:	ba 9c 11             	mov    dx,0x119c
    1197:	52                   	push   dx
    1198:	50                   	push   ax
    1199:	9a 7d 0a 57 14       	call   0x1457:0xa7d
    119e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11a1:	26 89 85 fc 00       	mov    WORD PTR es:[di+0xfc],ax
    11a6:	26 89 95 fe 00       	mov    WORD PTR es:[di+0xfe],dx
    11ab:	6a 0f                	push   0xf
    11ad:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    11b2:	06                   	push   es
    11b3:	57                   	push   di
    11b4:	9a bf 17 c8 11       	call   0x11c8:0x17bf
    11b9:	6a 11                	push   0x11
    11bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11be:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    11c3:	06                   	push   es
    11c4:	57                   	push   di
    11c5:	9a e1 17 d9 11       	call   0x11d9:0x17e1
    11ca:	6a 01                	push   0x1
    11cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11cf:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    11d4:	06                   	push   es
    11d5:	57                   	push   di
    11d6:	9a 77 1c 73 12       	call   0x1273:0x1c77
    11db:	ff 76 08             	push   WORD PTR [bp+0x8]
    11de:	ff 76 06             	push   WORD PTR [bp+0x6]
    11e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11e4:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    11e9:	06                   	push   es
    11ea:	57                   	push   di
    11eb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    11ee:	26 ff 5d 3c          	call   DWORD PTR es:[di+0x3c]
    11f2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    11f5:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    11f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11fb:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    1200:	26 89 85 e4 00       	mov    WORD PTR es:[di+0xe4],ax
    1205:	26 89 95 e6 00       	mov    WORD PTR es:[di+0xe6],dx
    120a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    120d:	06                   	push   es
    120e:	57                   	push   di
    120f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1212:	26 8b 85 80 00       	mov    ax,WORD PTR es:[di+0x80]
    1217:	26 8b 95 82 00       	mov    dx,WORD PTR es:[di+0x82]
    121c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    121f:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    1224:	26 89 85 e8 00       	mov    WORD PTR es:[di+0xe8],ax
    1229:	26 89 95 ea 00       	mov    WORD PTR es:[di+0xea],dx
    122e:	26 8f 85 ec 00       	pop    WORD PTR es:[di+0xec]
    1233:	26 8f 85 ee 00       	pop    WORD PTR es:[di+0xee]
    1238:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    123b:	06                   	push   es
    123c:	57                   	push   di
    123d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1240:	26 8b 85 84 00       	mov    ax,WORD PTR es:[di+0x84]
    1245:	26 8b 95 86 00       	mov    dx,WORD PTR es:[di+0x86]
    124a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    124d:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    1252:	26 89 85 f0 00       	mov    WORD PTR es:[di+0xf0],ax
    1257:	26 89 95 f2 00       	mov    WORD PTR es:[di+0xf2],dx
    125c:	26 8f 85 f4 00       	pop    WORD PTR es:[di+0xf4]
    1261:	26 8f 85 f6 00       	pop    WORD PTR es:[di+0xf6]
    1266:	bf 62 11             	mov    di,0x1162
    1269:	0e                   	push   cs
    126a:	57                   	push   di
    126b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    126e:	06                   	push   es
    126f:	57                   	push   di
    1270:	9a 8c 1d c8 12       	call   0x12c8:0x1d8c
    1275:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1278:	26 8b 45 26          	mov    ax,WORD PTR es:[di+0x26]
    127c:	25 df ff             	and    ax,0xffdf
    127f:	26 89 45 26          	mov    WORD PTR es:[di+0x26],ax
    1283:	26 c7 85 f8 00 01 00 	mov    WORD PTR es:[di+0xf8],0x1
    128a:	26 c7 85 fa 00 00 00 	mov    WORD PTR es:[di+0xfa],0x0
    1291:	26 c6 85 00 01 01    	mov    BYTE PTR es:[di+0x100],0x1
    1297:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    129b:	74 07                	je     0x12a4
    129d:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    12a1:	83 c4 06             	add    sp,0x6
    12a4:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    12a7:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    12aa:	c9                   	leave
    12ab:	ca 0a 00             	retf   0xa
    12ae:	55                   	push   bp
    12af:	89 e5                	mov    bp,sp
    12b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12b4:	31 c0                	xor    ax,ax
    12b6:	26 89 85 fc 00       	mov    WORD PTR es:[di+0xfc],ax
    12bb:	26 89 85 fe 00       	mov    WORD PTR es:[di+0xfe],ax
    12c0:	31 c0                	xor    ax,ax
    12c2:	50                   	push   ax
    12c3:	06                   	push   es
    12c4:	57                   	push   di
    12c5:	9a fc 2e 27 13       	call   0x1327:0x2efc
    12ca:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    12ce:	74 05                	je     0x12d5
    12d0:	9a 0f 20 9d 13       	call   0x139d:0x200f
    12d5:	c9                   	leave
    12d6:	ca 06 00             	retf   0x6
    12d9:	55                   	push   bp
    12da:	89 e5                	mov    bp,sp
    12dc:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    12df:	26 83 3d 26          	cmp    WORD PTR es:[di],0x26
    12e3:	75 15                	jne    0x12fa
    12e5:	ff 76 08             	push   WORD PTR [bp+0x8]
    12e8:	ff 76 06             	push   WORD PTR [bp+0x6]
    12eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    12ee:	06                   	push   es
    12ef:	57                   	push   di
    12f0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    12f3:	26 ff 9d 80 00       	call   DWORD PTR es:[di+0x80]
    12f8:	eb 1c                	jmp    0x1316
    12fa:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    12fd:	26 83 3d 28          	cmp    WORD PTR es:[di],0x28
    1301:	75 13                	jne    0x1316
    1303:	ff 76 08             	push   WORD PTR [bp+0x8]
    1306:	ff 76 06             	push   WORD PTR [bp+0x6]
    1309:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    130c:	06                   	push   es
    130d:	57                   	push   di
    130e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1311:	26 ff 9d 84 00       	call   DWORD PTR es:[di+0x84]
    1316:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    1319:	06                   	push   es
    131a:	57                   	push   di
    131b:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    131e:	50                   	push   ax
    131f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1322:	06                   	push   es
    1323:	57                   	push   di
    1324:	9a 6a 4f 68 13       	call   0x1368:0x4f6a
    1329:	c9                   	leave
    132a:	ca 0a 00             	retf   0xa
    132d:	55                   	push   bp
    132e:	89 e5                	mov    bp,sp
    1330:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1333:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1336:	50                   	push   ax
    1337:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    133a:	06                   	push   es
    133b:	57                   	push   di
    133c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    133f:	26 ff 5d 7c          	call   DWORD PTR es:[di+0x7c]
    1343:	08 c0                	or     al,al
    1345:	75 0e                	jne    0x1355
    1347:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    134a:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    134e:	6a 00                	push   0x0
    1350:	9a 0f 16 00 00       	call   0x0:0x160f
    1355:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1358:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    135c:	74 0c                	je     0x136a
    135e:	06                   	push   es
    135f:	57                   	push   di
    1360:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1363:	06                   	push   es
    1364:	57                   	push   di
    1365:	9a 1f 52 69 14       	call   0x1469:0x521f
    136a:	c9                   	leave
    136b:	ca 08 00             	retf   0x8
    136e:	00 00                	add    BYTE PTR [bx+si],al
    1370:	00 00                	add    BYTE PTR [bx+si],al
    1372:	00 28                	add    BYTE PTR [bx+si],ch
    1374:	ff 03                	inc    WORD PTR [bp+di]
	...
    138e:	c8 22 00 00          	enter  0x22,0x0
    1392:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    1395:	b4 01                	mov    ah,0x1
    1397:	ba 20 00             	mov    dx,0x20
    139a:	9a 99 1a b0 13       	call   0x13b0:0x1a99
    139f:	52                   	push   dx
    13a0:	50                   	push   ax
    13a1:	8d 7e de             	lea    di,[bp-0x22]
    13a4:	16                   	push   ss
    13a5:	57                   	push   di
    13a6:	bf 6e 13             	mov    di,0x136e
    13a9:	0e                   	push   cs
    13aa:	57                   	push   di
    13ab:	6a 20                	push   0x20
    13ad:	9a e4 19 b9 13       	call   0x13b9:0x19e4
    13b2:	a0 63 2c             	mov    al,ds:0x2c63
    13b5:	50                   	push   ax
    13b6:	9a 24 1a 7f 17       	call   0x177f:0x1a24
    13bb:	83 c4 04             	add    sp,0x4
    13be:	59                   	pop    cx
    13bf:	5b                   	pop    bx
    13c0:	8b fb                	mov    di,bx
    13c2:	84 4b de             	test   BYTE PTR [bp+di-0x22],cl
    13c5:	75 10                	jne    0x13d7
    13c7:	80 7e 0a 20          	cmp    BYTE PTR [bp+0xa],0x20
    13cb:	73 06                	jae    0x13d3
    13cd:	80 7e 0a 0d          	cmp    BYTE PTR [bp+0xa],0xd
    13d1:	75 04                	jne    0x13d7
    13d3:	b0 00                	mov    al,0x0
    13d5:	eb 02                	jmp    0x13d9
    13d7:	b0 01                	mov    al,0x1
    13d9:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    13dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13df:	26 80 bd 00 01 00    	cmp    BYTE PTR es:[di+0x100],0x0
    13e5:	75 1c                	jne    0x1403
    13e7:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    13eb:	74 16                	je     0x1403
    13ed:	80 7e 0a 20          	cmp    BYTE PTR [bp+0xa],0x20
    13f1:	73 0c                	jae    0x13ff
    13f3:	80 7e 0a 08          	cmp    BYTE PTR [bp+0xa],0x8
    13f7:	74 06                	je     0x13ff
    13f9:	80 7e 0a 2e          	cmp    BYTE PTR [bp+0xa],0x2e
    13fd:	75 04                	jne    0x1403
    13ff:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1403:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1406:	c9                   	leave
    1407:	ca 06 00             	retf   0x6
    140a:	55                   	push   bp
    140b:	89 e5                	mov    bp,sp
    140d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1410:	06                   	push   es
    1411:	57                   	push   di
    1412:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1415:	06                   	push   es
    1416:	57                   	push   di
    1417:	9a 5f 4a 4d 14       	call   0x144d:0x4a5f
    141c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    141f:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    1423:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    1427:	0d 04 00             	or     ax,0x4
    142a:	81 ca 00 00          	or     dx,0x0
    142e:	0d 00 00             	or     ax,0x0
    1431:	81 ca 00 02          	or     dx,0x200
    1435:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    1439:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    143d:	c9                   	leave
    143e:	ca 08 00             	retf   0x8
    1441:	c8 08 00 00          	enter  0x8,0x0
    1445:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1448:	06                   	push   es
    1449:	57                   	push   di
    144a:	9a 62 4b 63 18       	call   0x1863:0x4b62
    144f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1452:	06                   	push   es
    1453:	57                   	push   di
    1454:	9a 5d 14 02 15       	call   0x1502:0x145d
    1459:	c9                   	leave
    145a:	ca 04 00             	retf   0x4
    145d:	c8 08 00 00          	enter  0x8,0x0
    1461:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1464:	06                   	push   es
    1465:	57                   	push   di
    1466:	9a b9 62 83 14       	call   0x1483:0x62b9
    146b:	50                   	push   ax
    146c:	68 02 04             	push   0x402
    146f:	6a 00                	push   0x0
    1471:	8d 7e f8             	lea    di,[bp-0x8]
    1474:	16                   	push   ss
    1475:	57                   	push   di
    1476:	9a c4 14 00 00       	call   0x0:0x14c4
    147b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    147e:	06                   	push   es
    147f:	57                   	push   di
    1480:	9a f4 18 91 14       	call   0x1491:0x18f4
    1485:	40                   	inc    ax
    1486:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1489:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    148c:	06                   	push   es
    148d:	57                   	push   di
    148e:	9a a9 18 b6 14       	call   0x14b6:0x18a9
    1493:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1496:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    149b:	26 2b 45 22          	sub    ax,WORD PTR es:[di+0x22]
    149f:	48                   	dec    ax
    14a0:	48                   	dec    ax
    14a1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    14a4:	31 c0                	xor    ax,ax
    14a6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    14a9:	31 c0                	xor    ax,ax
    14ab:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    14ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14b1:	06                   	push   es
    14b2:	57                   	push   di
    14b3:	9a b9 62 d0 14       	call   0x14d0:0x62b9
    14b8:	50                   	push   ax
    14b9:	68 04 04             	push   0x404
    14bc:	6a 00                	push   0x0
    14be:	8d 7e f8             	lea    di,[bp-0x8]
    14c1:	16                   	push   ss
    14c2:	57                   	push   di
    14c3:	9a de 14 00 00       	call   0x0:0x14de
    14c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14cb:	06                   	push   es
    14cc:	57                   	push   di
    14cd:	9a b9 62 f8 14       	call   0x14f8:0x62b9
    14d2:	50                   	push   ax
    14d3:	68 02 04             	push   0x402
    14d6:	6a 00                	push   0x0
    14d8:	8d 7e f8             	lea    di,[bp-0x8]
    14db:	16                   	push   ss
    14dc:	57                   	push   di
    14dd:	9a ff ff 00 00       	call   0x0:0xffff
    14e2:	c9                   	leave
    14e3:	ca 04 00             	retf   0x4
    14e6:	c8 0a 00 00          	enter  0xa,0x0
    14ea:	ff 76 0c             	push   WORD PTR [bp+0xc]
    14ed:	ff 76 0a             	push   WORD PTR [bp+0xa]
    14f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14f3:	06                   	push   es
    14f4:	57                   	push   di
    14f5:	9a a8 4d 1b 15       	call   0x151b:0x4da8
    14fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14fd:	06                   	push   es
    14fe:	57                   	push   di
    14ff:	9a 6d 15 67 15       	call   0x1567:0x156d
    1504:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1507:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    150a:	26 8b 45 24          	mov    ax,WORD PTR es:[di+0x24]
    150e:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1511:	7d 0c                	jge    0x151f
    1513:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1516:	06                   	push   es
    1517:	57                   	push   di
    1518:	9a e1 17 e1 16       	call   0x16e1:0x17e1
    151d:	eb 4a                	jmp    0x1569
    151f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1522:	26 8b 85 fc 00       	mov    ax,WORD PTR es:[di+0xfc]
    1527:	26 0b 85 fe 00       	or     ax,WORD PTR es:[di+0xfe]
    152c:	74 3b                	je     0x1569
    152e:	26 8b 45 22          	mov    ax,WORD PTR es:[di+0x22]
    1532:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    1537:	26 2b 45 22          	sub    ax,WORD PTR es:[di+0x22]
    153b:	50                   	push   ax
    153c:	6a 00                	push   0x0
    153e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1541:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    1546:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    154a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    154d:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1551:	26 c4 bd fc 00       	les    di,DWORD PTR es:[di+0xfc]
    1556:	06                   	push   es
    1557:	57                   	push   di
    1558:	26 c4 3d             	les    di,DWORD PTR es:[di]
    155b:	26 ff 5d 4c          	call   DWORD PTR es:[di+0x4c]
    155f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1562:	06                   	push   es
    1563:	57                   	push   di
    1564:	9a 5d 14 1d 16       	call   0x161d:0x145d
    1569:	c9                   	leave
    156a:	ca 08 00             	retf   0x8
    156d:	c8 48 00 00          	enter  0x48,0x0
    1571:	6a 00                	push   0x0
    1573:	9a ff ff 00 00       	call   0x0:0xffff
    1578:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    157b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    157e:	8d 7e d8             	lea    di,[bp-0x28]
    1581:	16                   	push   ss
    1582:	57                   	push   di
    1583:	9a ab 15 00 00       	call   0x0:0x15ab
    1588:	ff 76 fc             	push   WORD PTR [bp-0x4]
    158b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    158e:	26 c4 7d 34          	les    di,DWORD PTR es:[di+0x34]
    1592:	06                   	push   es
    1593:	57                   	push   di
    1594:	9a 16 10 70 1a       	call   0x1a70:0x1016
    1599:	50                   	push   ax
    159a:	9a b6 15 00 00       	call   0x0:0x15b6
    159f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    15a2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    15a5:	8d 7e b8             	lea    di,[bp-0x48]
    15a8:	16                   	push   ss
    15a9:	57                   	push   di
    15aa:	9a 2d 1c 00 00       	call   0x0:0x1c2d
    15af:	ff 76 fc             	push   WORD PTR [bp-0x4]
    15b2:	ff 76 fa             	push   WORD PTR [bp-0x6]
    15b5:	9a ff ff 00 00       	call   0x0:0xffff
    15ba:	6a 00                	push   0x0
    15bc:	ff 76 fc             	push   WORD PTR [bp-0x4]
    15bf:	9a ff ff 00 00       	call   0x0:0xffff
    15c4:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    15c7:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    15ca:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    15cd:	3b 46 b8             	cmp    ax,WORD PTR [bp-0x48]
    15d0:	7e 06                	jle    0x15d8
    15d2:	8b 46 b8             	mov    ax,WORD PTR [bp-0x48]
    15d5:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    15d8:	6a 06                	push   0x6
    15da:	9a ff ff 00 00       	call   0x0:0xffff
    15df:	c1 e0 02             	shl    ax,0x2
    15e2:	8b d8                	mov    bx,ax
    15e4:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    15e7:	99                   	cwd
    15e8:	b9 04 00             	mov    cx,0x4
    15eb:	f7 f9                	idiv   cx
    15ed:	03 46 b8             	add    ax,WORD PTR [bp-0x48]
    15f0:	03 c3                	add    ax,bx
    15f2:	40                   	inc    ax
    15f3:	40                   	inc    ax
    15f4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    15f7:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    15fa:	c9                   	leave
    15fb:	ca 04 00             	retf   0x4
    15fe:	55                   	push   bp
    15ff:	89 e5                	mov    bp,sp
    1601:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1604:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    160a:	74 09                	je     0x1615
    160c:	6a 00                	push   0x0
    160e:	9a 4a 16 00 00       	call   0x0:0x164a
    1613:	eb 20                	jmp    0x1635
    1615:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1618:	06                   	push   es
    1619:	57                   	push   di
    161a:	9a 33 17 33 16       	call   0x1633:0x1733
    161f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1622:	26 03 85 f8 00       	add    ax,WORD PTR es:[di+0xf8]
    1627:	26 13 95 fa 00       	adc    dx,WORD PTR es:[di+0xfa]
    162c:	52                   	push   dx
    162d:	50                   	push   ax
    162e:	06                   	push   es
    162f:	57                   	push   di
    1630:	9a 8b 17 58 16       	call   0x1658:0x178b
    1635:	c9                   	leave
    1636:	ca 08 00             	retf   0x8
    1639:	55                   	push   bp
    163a:	89 e5                	mov    bp,sp
    163c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    163f:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    1645:	74 09                	je     0x1650
    1647:	6a 00                	push   0x0
    1649:	9a ff ff 00 00       	call   0x0:0xffff
    164e:	eb 20                	jmp    0x1670
    1650:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1653:	06                   	push   es
    1654:	57                   	push   di
    1655:	9a 33 17 6e 16       	call   0x166e:0x1733
    165a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    165d:	26 2b 85 f8 00       	sub    ax,WORD PTR es:[di+0xf8]
    1662:	26 1b 95 fa 00       	sbb    dx,WORD PTR es:[di+0xfa]
    1667:	52                   	push   dx
    1668:	50                   	push   ax
    1669:	06                   	push   es
    166a:	57                   	push   di
    166b:	9a 8b 17 eb 16       	call   0x16eb:0x178b
    1670:	c9                   	leave
    1671:	ca 08 00             	retf   0x8
    1674:	55                   	push   bp
    1675:	89 e5                	mov    bp,sp
    1677:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    167a:	26 80 bd 00 01 00    	cmp    BYTE PTR es:[di+0x100],0x0
    1680:	74 08                	je     0x168a
    1682:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    1688:	74 02                	je     0x168c
    168a:	eb 12                	jmp    0x169e
    168c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    168f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1692:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1695:	06                   	push   es
    1696:	57                   	push   di
    1697:	26 c4 3d             	les    di,DWORD PTR es:[di]
    169a:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    169e:	c9                   	leave
    169f:	ca 08 00             	retf   0x8
    16a2:	55                   	push   bp
    16a3:	89 e5                	mov    bp,sp
    16a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16a8:	26 80 bd 00 01 00    	cmp    BYTE PTR es:[di+0x100],0x0
    16ae:	74 08                	je     0x16b8
    16b0:	26 80 bd dc 00 00    	cmp    BYTE PTR es:[di+0xdc],0x0
    16b6:	74 02                	je     0x16ba
    16b8:	eb 12                	jmp    0x16cc
    16ba:	ff 76 0c             	push   WORD PTR [bp+0xc]
    16bd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    16c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16c3:	06                   	push   es
    16c4:	57                   	push   di
    16c5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16c8:	26 ff 5d f0          	call   DWORD PTR es:[di-0x10]
    16cc:	c9                   	leave
    16cd:	ca 08 00             	retf   0x8
    16d0:	55                   	push   bp
    16d1:	89 e5                	mov    bp,sp
    16d3:	ff 76 0c             	push   WORD PTR [bp+0xc]
    16d6:	ff 76 0a             	push   WORD PTR [bp+0xa]
    16d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16dc:	06                   	push   es
    16dd:	57                   	push   di
    16de:	9a d2 55 53 17       	call   0x1753:0x55d2
    16e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16e6:	06                   	push   es
    16e7:	57                   	push   di
    16e8:	9a 33 17 f7 16       	call   0x16f7:0x1733
    16ed:	52                   	push   dx
    16ee:	50                   	push   ax
    16ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16f2:	06                   	push   es
    16f3:	57                   	push   di
    16f4:	9a 33 17 03 17       	call   0x1703:0x1733
    16f9:	52                   	push   dx
    16fa:	50                   	push   ax
    16fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16fe:	06                   	push   es
    16ff:	57                   	push   di
    1700:	9a ba 17 17 17       	call   0x1717:0x17ba
    1705:	59                   	pop    cx
    1706:	5b                   	pop    bx
    1707:	3b d3                	cmp    dx,bx
    1709:	75 04                	jne    0x170f
    170b:	3b c1                	cmp    ax,cx
    170d:	74 16                	je     0x1725
    170f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1712:	06                   	push   es
    1713:	57                   	push   di
    1714:	9a 33 17 23 17       	call   0x1723:0x1733
    1719:	52                   	push   dx
    171a:	50                   	push   ax
    171b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    171e:	06                   	push   es
    171f:	57                   	push   di
    1720:	9a 8b 17 31 17       	call   0x1731:0x178b
    1725:	c9                   	leave
    1726:	ca 08 00             	retf   0x8
    1729:	01 00                	add    WORD PTR [bx+si],ax
    172b:	00 00                	add    BYTE PTR [bx+si],al
    172d:	00 00                	add    BYTE PTR [bx+si],al
    172f:	69 17 a3 17          	imul   dx,WORD PTR [bx],0x17a3
    1733:	c8 04 01 00          	enter  0x104,0x0
    1737:	b8 29 17             	mov    ax,0x1729
    173a:	0e                   	push   cs
    173b:	50                   	push   ax
    173c:	55                   	push   bp
    173d:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1741:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1745:	8d be fc fe          	lea    di,[bp-0x104]
    1749:	16                   	push   ss
    174a:	57                   	push   di
    174b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    174e:	06                   	push   es
    174f:	57                   	push   di
    1750:	9a 53 1d b4 17       	call   0x17b4:0x1d53
    1755:	9a da 08 aa 17       	call   0x17aa:0x8da
    175a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    175d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1760:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1764:	83 c4 06             	add    sp,0x6
    1767:	eb 18                	jmp    0x1781
    1769:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    176c:	26 8b 85 ec 00       	mov    ax,WORD PTR es:[di+0xec]
    1771:	26 8b 95 ee 00       	mov    dx,WORD PTR es:[di+0xee]
    1776:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1779:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    177c:	9a 34 14 95 18       	call   0x1895:0x1434
    1781:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1784:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1787:	c9                   	leave
    1788:	ca 04 00             	retf   0x4
    178b:	c8 00 01 00          	enter  0x100,0x0
    178f:	8d be 00 ff          	lea    di,[bp-0x100]
    1793:	16                   	push   ss
    1794:	57                   	push   di
    1795:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1798:	ff 76 0a             	push   WORD PTR [bp+0xa]
    179b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    179e:	06                   	push   es
    179f:	57                   	push   di
    17a0:	9a ba 17 11 19       	call   0x1911:0x17ba
    17a5:	52                   	push   dx
    17a6:	50                   	push   ax
    17a7:	9a a9 08 9f 1a       	call   0x1a9f:0x8a9
    17ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17af:	06                   	push   es
    17b0:	57                   	push   di
    17b1:	9a 8c 1d b5 19       	call   0x19b5:0x1d8c
    17b6:	c9                   	leave
    17b7:	ca 08 00             	retf   0x8
    17ba:	c8 04 00 00          	enter  0x4,0x0
    17be:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    17c1:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    17c4:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    17c7:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    17ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17cd:	26 8b 85 f0 00       	mov    ax,WORD PTR es:[di+0xf0]
    17d2:	26 8b 95 f2 00       	mov    dx,WORD PTR es:[di+0xf2]
    17d7:	26 3b 95 ee 00       	cmp    dx,WORD PTR es:[di+0xee]
    17dc:	75 07                	jne    0x17e5
    17de:	26 3b 85 ec 00       	cmp    ax,WORD PTR es:[di+0xec]
    17e3:	74 5a                	je     0x183f
    17e5:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    17e8:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    17eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17ee:	26 3b 95 ee 00       	cmp    dx,WORD PTR es:[di+0xee]
    17f3:	7c 09                	jl     0x17fe
    17f5:	7f 1c                	jg     0x1813
    17f7:	26 3b 85 ec 00       	cmp    ax,WORD PTR es:[di+0xec]
    17fc:	73 15                	jae    0x1813
    17fe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1801:	26 8b 85 ec 00       	mov    ax,WORD PTR es:[di+0xec]
    1806:	26 8b 95 ee 00       	mov    dx,WORD PTR es:[di+0xee]
    180b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    180e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1811:	eb 2c                	jmp    0x183f
    1813:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1816:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    1819:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    181c:	26 3b 95 f2 00       	cmp    dx,WORD PTR es:[di+0xf2]
    1821:	7f 09                	jg     0x182c
    1823:	7c 1a                	jl     0x183f
    1825:	26 3b 85 f0 00       	cmp    ax,WORD PTR es:[di+0xf0]
    182a:	76 13                	jbe    0x183f
    182c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    182f:	26 8b 85 f0 00       	mov    ax,WORD PTR es:[di+0xf0]
    1834:	26 8b 95 f2 00       	mov    dx,WORD PTR es:[di+0xf2]
    1839:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    183c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    183f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1842:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1845:	c9                   	leave
    1846:	ca 08 00             	retf   0x8
    1849:	55                   	push   bp
    184a:	89 e5                	mov    bp,sp
    184c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    184f:	26 80 bd de 00 00    	cmp    BYTE PTR es:[di+0xde],0x0
    1855:	74 0e                	je     0x1865
    1857:	26 f6 45 28 01       	test   BYTE PTR es:[di+0x28],0x1
    185c:	75 07                	jne    0x1865
    185e:	06                   	push   es
    185f:	57                   	push   di
    1860:	9a 3f 4a 73 18       	call   0x1873:0x4a3f
    1865:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1868:	ff 76 0a             	push   WORD PTR [bp+0xa]
    186b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    186e:	06                   	push   es
    186f:	57                   	push   di
    1870:	9a 3e 4d ff ff       	call   0xffff:0x4d3e
    1875:	c9                   	leave
    1876:	ca 08 00             	retf   0x8
    1879:	55                   	push   bp
    187a:	89 e5                	mov    bp,sp
    187c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    187f:	26 8b 85 9d 00       	mov    ax,WORD PTR es:[di+0x9d]
    1884:	26 0b 85 9f 00       	or     ax,WORD PTR es:[di+0x9f]
    1889:	74 0c                	je     0x1897
    188b:	26 c4 bd 9d 00       	les    di,DWORD PTR es:[di+0x9d]
    1890:	06                   	push   es
    1891:	57                   	push   di
    1892:	9a 7f 1f ad 18       	call   0x18ad:0x1f7f
    1897:	31 c0                	xor    ax,ax
    1899:	50                   	push   ax
    189a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    189d:	06                   	push   es
    189e:	57                   	push   di
    189f:	9a e0 1f cc 18       	call   0x18cc:0x1fe0
    18a4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    18a8:	74 05                	je     0x18af
    18aa:	9a 0f 20 d4 19       	call   0x19d4:0x200f
    18af:	c9                   	leave
    18b0:	ca 06 00             	retf   0x6
    18b3:	55                   	push   bp
    18b4:	89 e5                	mov    bp,sp
    18b6:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    18b9:	50                   	push   ax
    18ba:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    18bd:	50                   	push   ax
    18be:	ff 76 0c             	push   WORD PTR [bp+0xc]
    18c1:	ff 76 0a             	push   WORD PTR [bp+0xa]
    18c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18c7:	06                   	push   es
    18c8:	57                   	push   di
    18c9:	9a 72 21 64 19       	call   0x1964:0x2172
    18ce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18d1:	26 f6 85 a1 00 02    	test   BYTE PTR es:[di+0xa1],0x2
    18d7:	74 6e                	je     0x1947
    18d9:	26 8b 85 9d 00       	mov    ax,WORD PTR es:[di+0x9d]
    18de:	26 0b 85 9f 00       	or     ax,WORD PTR es:[di+0x9f]
    18e3:	75 23                	jne    0x1908
    18e5:	ff 76 08             	push   WORD PTR [bp+0x8]
    18e8:	ff 76 06             	push   WORD PTR [bp+0x6]
    18eb:	b0 01                	mov    al,0x1
    18ed:	50                   	push   ax
    18ee:	b8 8b 0b             	mov    ax,0xb8b
    18f1:	ba f9 18             	mov    dx,0x18f9
    18f4:	52                   	push   dx
    18f5:	50                   	push   ax
    18f6:	9a be 25 22 19       	call   0x1922:0x25be
    18fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18fe:	26 89 85 9d 00       	mov    WORD PTR es:[di+0x9d],ax
    1903:	26 89 95 9f 00       	mov    WORD PTR es:[di+0x9f],dx
    1908:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    190b:	06                   	push   es
    190c:	57                   	push   di
    190d:	bf 91 19             	mov    di,0x1991
    1910:	b8 8f 19             	mov    ax,0x198f
    1913:	50                   	push   ax
    1914:	57                   	push   di
    1915:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1918:	26 c4 bd 9d 00       	les    di,DWORD PTR es:[di+0x9d]
    191d:	06                   	push   es
    191e:	57                   	push   di
    191f:	9a 8b 27 34 19       	call   0x1934:0x278b
    1924:	68 90 01             	push   0x190
    1927:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    192a:	26 c4 bd 9d 00       	les    di,DWORD PTR es:[di+0x9d]
    192f:	06                   	push   es
    1930:	57                   	push   di
    1931:	9a 6a 27 45 19       	call   0x1945:0x276a
    1936:	6a 01                	push   0x1
    1938:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    193b:	26 c4 bd 9d 00       	les    di,DWORD PTR es:[di+0x9d]
    1940:	06                   	push   es
    1941:	57                   	push   di
    1942:	9a 49 27 81 19       	call   0x1981:0x2749
    1947:	c9                   	leave
    1948:	ca 0c 00             	retf   0xc
    194b:	55                   	push   bp
    194c:	89 e5                	mov    bp,sp
    194e:	8a 46 10             	mov    al,BYTE PTR [bp+0x10]
    1951:	50                   	push   ax
    1952:	8a 46 0e             	mov    al,BYTE PTR [bp+0xe]
    1955:	50                   	push   ax
    1956:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1959:	ff 76 0a             	push   WORD PTR [bp+0xa]
    195c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    195f:	06                   	push   es
    1960:	57                   	push   di
    1961:	9a 57 22 0a 1a       	call   0x1a0a:0x2257
    1966:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1969:	26 8b 85 9d 00       	mov    ax,WORD PTR es:[di+0x9d]
    196e:	26 0b 85 9f 00       	or     ax,WORD PTR es:[di+0x9f]
    1973:	74 0e                	je     0x1983
    1975:	6a 00                	push   0x0
    1977:	26 c4 bd 9d 00       	les    di,DWORD PTR es:[di+0x9d]
    197c:	06                   	push   es
    197d:	57                   	push   di
    197e:	9a 49 27 a3 19       	call   0x19a3:0x2749
    1983:	c9                   	leave
    1984:	ca 0c 00             	retf   0xc
    1987:	01 00                	add    WORD PTR [bx+si],ax
    1989:	00 00                	add    BYTE PTR [bx+si],al
    198b:	00 00                	add    BYTE PTR [bx+si],al
    198d:	df 19                	fistp  WORD PTR [bx+di]
    198f:	c8 1a 55 89          	enter  0x551a,0x89
    1993:	e5 6a                	in     ax,0x6a
    1995:	64 c4 7e 06          	les    di,DWORD PTR fs:[bp+0x6]
    1999:	26 c4 bd 9d 00       	les    di,DWORD PTR es:[di+0x9d]
    199e:	06                   	push   es
    199f:	57                   	push   di
    19a0:	9a 6a 27 ee 19       	call   0x19ee:0x276a
    19a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19a8:	26 80 bd 9c 00 02    	cmp    BYTE PTR es:[di+0x9c],0x2
    19ae:	75 4a                	jne    0x19fa
    19b0:	06                   	push   es
    19b1:	57                   	push   di
    19b2:	9a 90 1f ff ff       	call   0xffff:0x1f90
    19b7:	08 c0                	or     al,al
    19b9:	74 3f                	je     0x19fa
    19bb:	b8 87 19             	mov    ax,0x1987
    19be:	0e                   	push   cs
    19bf:	50                   	push   ax
    19c0:	55                   	push   bp
    19c1:	ff 36 58 18          	push   WORD PTR ds:0x1858
    19c5:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    19c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19cc:	06                   	push   es
    19cd:	57                   	push   di
    19ce:	b8 fe ff             	mov    ax,0xfffe
    19d1:	9a 6a 20 f3 19       	call   0x19f3:0x206a
    19d6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    19da:	83 c4 06             	add    sp,0x6
    19dd:	eb 1b                	jmp    0x19fa
    19df:	6a 00                	push   0x0
    19e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19e4:	26 c4 bd 9d 00       	les    di,DWORD PTR es:[di+0x9d]
    19e9:	06                   	push   es
    19ea:	57                   	push   di
    19eb:	9a 49 27 ff ff       	call   0xffff:0x2749
    19f0:	ea 85 13 f8 19       	jmp    0x19f8:0x1385
    19f5:	9a 34 14 3a 1a       	call   0x1a3a:0x1434
    19fa:	c9                   	leave
    19fb:	ca 08 00             	retf   0x8
    19fe:	c8 10 00 00          	enter  0x10,0x0
    1a02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a05:	06                   	push   es
    1a06:	57                   	push   di
    1a07:	9a 2c 20 ff ff       	call   0xffff:0x202c
    1a0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a0f:	26 f6 85 a1 00 01    	test   BYTE PTR es:[di+0xa1],0x1
    1a15:	74 66                	je     0x1a7d
    1a17:	8d 7e f0             	lea    di,[bp-0x10]
    1a1a:	16                   	push   ss
    1a1b:	57                   	push   di
    1a1c:	6a 00                	push   0x0
    1a1e:	6a 00                	push   0x0
    1a20:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a23:	26 ff 75 22          	push   WORD PTR es:[di+0x22]
    1a27:	26 ff 75 24          	push   WORD PTR es:[di+0x24]
    1a2b:	9a ae 06 fb 21       	call   0x21fb:0x6ae
    1a30:	8d 7e f8             	lea    di,[bp-0x8]
    1a33:	16                   	push   ss
    1a34:	57                   	push   di
    1a35:	6a 08                	push   0x8
    1a37:	9a 1b 16 9b 1a       	call   0x1a9b:0x161b
    1a3c:	8d 7e f8             	lea    di,[bp-0x8]
    1a3f:	16                   	push   ss
    1a40:	57                   	push   di
    1a41:	6a fd                	push   0xfffd
    1a43:	6a fd                	push   0xfffd
    1a45:	9a ff ff 00 00       	call   0x0:0xffff
    1a4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a4d:	26 80 bd 9c 00 02    	cmp    BYTE PTR es:[di+0x9c],0x2
    1a53:	75 0e                	jne    0x1a63
    1a55:	8d 7e f8             	lea    di,[bp-0x8]
    1a58:	16                   	push   ss
    1a59:	57                   	push   di
    1a5a:	6a 01                	push   0x1
    1a5c:	6a 01                	push   0x1
    1a5e:	9a ff ff 00 00       	call   0x0:0xffff
    1a63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a66:	26 c4 bd 8a 00       	les    di,DWORD PTR es:[di+0x8a]
    1a6b:	06                   	push   es
    1a6c:	57                   	push   di
    1a6d:	9a d2 21 24 1c       	call   0x1c24:0x21d2
    1a72:	50                   	push   ax
    1a73:	8d 7e f8             	lea    di,[bp-0x8]
    1a76:	16                   	push   ss
    1a77:	57                   	push   di
    1a78:	9a ff ff 00 00       	call   0x0:0xffff
    1a7d:	c9                   	leave
    1a7e:	ca 04 00             	retf   0x4
	...
    1a89:	a1 1a 0c             	mov    ax,ds:0xc1a
    1a8c:	00 2e 00 70          	add    BYTE PTR ds:0x7000,ch
    1a90:	1b 64 20             	sbb    sp,WORD PTR [si+0x20]
    1a93:	c4 1a                	les    bx,DWORD PTR [bp+si]
    1a95:	9a 1f 93 1a cb       	call   0xcb1a:0x931f
    1a9a:	1f                   	pop    ds
    1a9b:	97                   	xchg   di,ax
    1a9c:	1a c4                	sbb    al,ah
    1a9e:	29 8f 1a 08          	sub    WORD PTR [bx+0x81a],cx
    1aa2:	45                   	inc    bp
    1aa3:	50                   	push   ax
    1aa4:	72 69                	jb     0x1b0f
    1aa6:	6e                   	outs   dx,BYTE PTR ds:[si]
    1aa7:	74 65                	je     0x1b0e
    1aa9:	72 00                	jb     0x1aab
    1aab:	00 00                	add    BYTE PTR [bx+si],al
    1aad:	00 00                	add    BYTE PTR [bx+si],al
    1aaf:	00 00                	add    BYTE PTR [bx+si],al
    1ab1:	00 ca                	add    dl,cl
    1ab3:	1a 25                	sbb    ah,BYTE PTR [di]
    1ab5:	00 2c                	add    BYTE PTR [si],ch
    1ab7:	1f                   	pop    ds
    1ab8:	87 1b                	xchg   WORD PTR [bp+di],bx
    1aba:	64 20 b8 1a 9a       	and    BYTE PTR fs:[bx+si-0x65e6],bh
    1abf:	1f                   	pop    ds
    1ac0:	bc 1a cb             	mov    sp,0xcb1a
    1ac3:	1f                   	pop    ds
    1ac4:	c0 1a ac             	rcr    BYTE PTR [bp+si],0xac
    1ac7:	23 79 1b             	and    di,WORD PTR [bx+di+0x1b]
    1aca:	08 54 50             	or     BYTE PTR [si+0x50],dl
    1acd:	72 69                	jb     0x1b38
    1acf:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ad0:	74 65                	je     0x1b37
    1ad2:	72 c8                	jb     0x1a9c
    1ad4:	08 00                	or     BYTE PTR [bx+si],al
    1ad6:	00 c4                	add    ah,al
    1ad8:	7e 04                	jle    0x1ade
    1ada:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1add:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    1ae1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1ae4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1ae7:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1aea:	26 0b 45 02          	or     ax,WORD PTR es:[di+0x2]
    1aee:	75 02                	jne    0x1af2
    1af0:	eb 64                	jmp    0x1b56
    1af2:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1af5:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1af8:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    1afc:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1aff:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1b02:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1b05:	26 80 3d 20          	cmp    BYTE PTR es:[di],0x20
    1b09:	75 05                	jne    0x1b10
    1b0b:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    1b0e:	eb f2                	jmp    0x1b02
    1b10:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1b13:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    1b16:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1b19:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1b1c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1b1f:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1b23:	74 0e                	je     0x1b33
    1b25:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1b28:	26 80 3d 2c          	cmp    BYTE PTR es:[di],0x2c
    1b2c:	74 05                	je     0x1b33
    1b2e:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    1b31:	eb e9                	jmp    0x1b1c
    1b33:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1b36:	26 80 3d 2c          	cmp    BYTE PTR es:[di],0x2c
    1b3a:	75 0a                	jne    0x1b46
    1b3c:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1b3f:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    1b43:	ff 46 f8             	inc    WORD PTR [bp-0x8]
    1b46:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1b49:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    1b4c:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1b4f:	26 89 05             	mov    WORD PTR es:[di],ax
    1b52:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    1b56:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1b59:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1b5c:	c9                   	leave
    1b5d:	c2 04 00             	ret    0x4
    1b60:	c8 00 01 00          	enter  0x100,0x0
    1b64:	8d be 00 ff          	lea    di,[bp-0x100]
    1b68:	16                   	push   ss
    1b69:	57                   	push   di
    1b6a:	ff 76 04             	push   WORD PTR [bp+0x4]
    1b6d:	9a 2b 09 80 1b       	call   0x1b80:0x92b
    1b72:	b0 01                	mov    al,0x1
    1b74:	50                   	push   ax
    1b75:	b8 a1 1a             	mov    ax,0x1aa1
    1b78:	ba 06 1c             	mov    dx,0x1c06
    1b7b:	52                   	push   dx
    1b7c:	50                   	push   ax
    1b7d:	9a e6 28 e5 20       	call   0x20e5:0x28e6
    1b82:	52                   	push   dx
    1b83:	50                   	push   ax
    1b84:	9a 99 13 85 1e       	call   0x1e85:0x1399
    1b89:	c9                   	leave
    1b8a:	c2 02 00             	ret    0x2
    1b8d:	8c d0                	mov    ax,ss
    1b8f:	90                   	nop
    1b90:	45                   	inc    bp
    1b91:	55                   	push   bp
    1b92:	89 e5                	mov    bp,sp
    1b94:	1e                   	push   ds
    1b95:	8e d8                	mov    ds,ax
    1b97:	83 ec 02             	sub    sp,0x2
    1b9a:	56                   	push   si
    1b9b:	57                   	push   di
    1b9c:	c4 3e 2a 2c          	les    di,DWORD PTR ds:0x2c2a
    1ba0:	06                   	push   es
    1ba1:	57                   	push   di
    1ba2:	9a 03 73 ff ff       	call   0xffff:0x7303
    1ba7:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1bab:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    1bb0:	b0 00                	mov    al,0x0
    1bb2:	75 01                	jne    0x1bb5
    1bb4:	40                   	inc    ax
    1bb5:	98                   	cbw
    1bb6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1bb9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1bbc:	5f                   	pop    di
    1bbd:	5e                   	pop    si
    1bbe:	8d 66 fe             	lea    sp,[bp-0x2]
    1bc1:	1f                   	pop    ds
    1bc2:	5d                   	pop    bp
    1bc3:	4d                   	dec    bp
    1bc4:	ca 04 00             	retf   0x4
    1bc7:	c8 04 00 00          	enter  0x4,0x0
    1bcb:	31 c0                	xor    ax,ax
    1bcd:	8b 56 04             	mov    dx,WORD PTR [bp+0x4]
    1bd0:	52                   	push   dx
    1bd1:	50                   	push   ax
    1bd2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1bd5:	9a ff ff 00 00       	call   0x0:0xffff
    1bda:	09 c0                	or     ax,ax
    1bdc:	b0 00                	mov    al,0x0
    1bde:	75 01                	jne    0x1be1
    1be0:	40                   	inc    ax
    1be1:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    1be4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    1be7:	c9                   	leave
    1be8:	c2 02 00             	ret    0x2
    1beb:	c8 04 00 00          	enter  0x4,0x0
    1bef:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1bf2:	31 c0                	xor    ax,ax
    1bf4:	26 89 05             	mov    WORD PTR es:[di],ax
    1bf7:	31 c0                	xor    ax,ax
    1bf9:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    1bfd:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1c01:	06                   	push   es
    1c02:	57                   	push   di
    1c03:	9a 9a 26 19 1c       	call   0x1c19:0x269a
    1c08:	c9                   	leave
    1c09:	c2 04 00             	ret    0x4
    1c0c:	c8 22 00 00          	enter  0x22,0x0
    1c10:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1c14:	06                   	push   es
    1c15:	57                   	push   di
    1c16:	9a 04 2a c5 1c       	call   0x1cc5:0x2a04
    1c1b:	89 c7                	mov    di,ax
    1c1d:	8e c2                	mov    es,dx
    1c1f:	06                   	push   es
    1c20:	57                   	push   di
    1c21:	9a d2 21 e8 1c       	call   0x1ce8:0x21d2
    1c26:	50                   	push   ax
    1c27:	8d 7e de             	lea    di,[bp-0x22]
    1c2a:	16                   	push   ss
    1c2b:	57                   	push   di
    1c2c:	9a 14 1e 00 00       	call   0x0:0x1e14
    1c31:	8b 46 de             	mov    ax,WORD PTR [bp-0x22]
    1c34:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1c37:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c3a:	c9                   	leave
    1c3b:	c2 02 00             	ret    0x2
    1c3e:	c8 04 00 00          	enter  0x4,0x0
    1c42:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1c45:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    1c48:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    1c4b:	31 c0                	xor    ax,ax
    1c4d:	26 89 05             	mov    WORD PTR es:[di],ax
    1c50:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    1c55:	75 0d                	jne    0x1c64
    1c57:	55                   	push   bp
    1c58:	e8 b1 ff             	call   0x1c0c
    1c5b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1c5e:	26 01 45 02          	add    WORD PTR es:[di+0x2],ax
    1c62:	eb 0b                	jmp    0x1c6f
    1c64:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1c67:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1c6b:	26 01 45 02          	add    WORD PTR es:[di+0x2],ax
    1c6f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1c72:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1c76:	d1 e0                	shl    ax,1
    1c78:	31 d2                	xor    dx,dx
    1c7a:	8b c8                	mov    cx,ax
    1c7c:	8b da                	mov    bx,dx
    1c7e:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1c82:	99                   	cwd
    1c83:	2b c1                	sub    ax,cx
    1c85:	1b d3                	sbb    dx,bx
    1c87:	8b c8                	mov    cx,ax
    1c89:	8b da                	mov    bx,dx
    1c8b:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
    1c8f:	99                   	cwd
    1c90:	3b d3                	cmp    dx,bx
    1c92:	7f 06                	jg     0x1c9a
    1c94:	7c 0c                	jl     0x1ca2
    1c96:	3b c1                	cmp    ax,cx
    1c98:	76 08                	jbe    0x1ca2
    1c9a:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    1c9d:	06                   	push   es
    1c9e:	57                   	push   di
    1c9f:	e8 49 ff             	call   0x1beb
    1ca2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1ca5:	31 c0                	xor    ax,ax
    1ca7:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    1cab:	c9                   	leave
    1cac:	c2 04 00             	ret    0x4
    1caf:	c8 0e 00 00          	enter  0xe,0x0
    1cb3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1cb6:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1cb9:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1cbc:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1cc0:	06                   	push   es
    1cc1:	57                   	push   di
    1cc2:	9a 04 2a 00 1e       	call   0x1e00:0x2a04
    1cc7:	89 c7                	mov    di,ax
    1cc9:	8e c2                	mov    es,dx
    1ccb:	89 7e f2             	mov    WORD PTR [bp-0xe],di
    1cce:	8c 46 f4             	mov    WORD PTR [bp-0xc],es
    1cd1:	83 7e 04 00          	cmp    WORD PTR [bp+0x4],0x0
    1cd5:	7f 03                	jg     0x1cda
    1cd7:	e9 ce 00             	jmp    0x1da8
    1cda:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    1cdd:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1ce0:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1ce3:	06                   	push   es
    1ce4:	57                   	push   di
    1ce5:	9a d2 21 1e 1d       	call   0x1d1e:0x21d2
    1cea:	50                   	push   ax
    1ceb:	ff 76 08             	push   WORD PTR [bp+0x8]
    1cee:	ff 76 06             	push   WORD PTR [bp+0x6]
    1cf1:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1cf4:	8d 7e fc             	lea    di,[bp-0x4]
    1cf7:	16                   	push   ss
    1cf8:	57                   	push   di
    1cf9:	9a 30 1d 00 00       	call   0x0:0x1d30
    1cfe:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    1d02:	7e 32                	jle    0x1d36
    1d04:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1d07:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1d0a:	26 03 05             	add    ax,WORD PTR es:[di]
    1d0d:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    1d11:	7e 23                	jle    0x1d36
    1d13:	ff 4e fa             	dec    WORD PTR [bp-0x6]
    1d16:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1d19:	06                   	push   es
    1d1a:	57                   	push   di
    1d1b:	9a d2 21 65 1d       	call   0x1d65:0x21d2
    1d20:	50                   	push   ax
    1d21:	ff 76 08             	push   WORD PTR [bp+0x8]
    1d24:	ff 76 06             	push   WORD PTR [bp+0x6]
    1d27:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1d2a:	8d 7e fc             	lea    di,[bp-0x4]
    1d2d:	16                   	push   ss
    1d2e:	57                   	push   di
    1d2f:	9a ff ff 00 00       	call   0x0:0xffff
    1d34:	eb c8                	jmp    0x1cfe
    1d36:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1d39:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1d3d:	31 d2                	xor    dx,dx
    1d3f:	8b c8                	mov    cx,ax
    1d41:	8b da                	mov    bx,dx
    1d43:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d46:	99                   	cwd
    1d47:	3b d3                	cmp    dx,bx
    1d49:	7f 06                	jg     0x1d51
    1d4b:	7c 10                	jl     0x1d5d
    1d4d:	3b c1                	cmp    ax,cx
    1d4f:	76 0c                	jbe    0x1d5d
    1d51:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1d54:	40                   	inc    ax
    1d55:	40                   	inc    ax
    1d56:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1d59:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    1d5d:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    1d60:	06                   	push   es
    1d61:	57                   	push   di
    1d62:	9a d2 21 0b 1e       	call   0x1e0b:0x21d2
    1d67:	50                   	push   ax
    1d68:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1d6b:	26 ff 35             	push   WORD PTR es:[di]
    1d6e:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    1d72:	ff 76 08             	push   WORD PTR [bp+0x8]
    1d75:	ff 76 06             	push   WORD PTR [bp+0x6]
    1d78:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1d7b:	9a ff ff 00 00       	call   0x0:0xffff
    1d80:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1d83:	29 46 04             	sub    WORD PTR [bp+0x4],ax
    1d86:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1d89:	01 46 06             	add    WORD PTR [bp+0x6],ax
    1d8c:	83 7e 04 00          	cmp    WORD PTR [bp+0x4],0x0
    1d90:	7e 0a                	jle    0x1d9c
    1d92:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1d95:	06                   	push   es
    1d96:	57                   	push   di
    1d97:	e8 a4 fe             	call   0x1c3e
    1d9a:	eb 09                	jmp    0x1da5
    1d9c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1d9f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    1da2:	26 01 05             	add    WORD PTR es:[di],ax
    1da5:	e9 29 ff             	jmp    0x1cd1
    1da8:	c9                   	leave
    1da9:	c2 0a 00             	ret    0xa
    1dac:	55                   	push   bp
    1dad:	89 e5                	mov    bp,sp
    1daf:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1db2:	36 83 7d fe 00       	cmp    WORD PTR ss:[di-0x2],0x0
    1db7:	74 1b                	je     0x1dd4
    1db9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1dbc:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    1dc0:	06                   	push   es
    1dc1:	57                   	push   di
    1dc2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1dc5:	36 ff 75 08          	push   WORD PTR ss:[di+0x8]
    1dc9:	36 ff 75 06          	push   WORD PTR ss:[di+0x6]
    1dcd:	36 ff 75 fe          	push   WORD PTR ss:[di-0x2]
    1dd1:	e8 db fe             	call   0x1caf
    1dd4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    1dd7:	36 8b 45 fe          	mov    ax,WORD PTR ss:[di-0x2]
    1ddb:	40                   	inc    ax
    1ddc:	36 01 45 06          	add    WORD PTR ss:[di+0x6],ax
    1de0:	36 8b 45 fe          	mov    ax,WORD PTR ss:[di-0x2]
    1de4:	40                   	inc    ax
    1de5:	36 29 45 04          	sub    WORD PTR ss:[di+0x4],ax
    1de9:	31 c0                	xor    ax,ax
    1deb:	36 89 45 fe          	mov    WORD PTR ss:[di-0x2],ax
    1def:	c9                   	leave
    1df0:	c2 02 00             	ret    0x2
    1df3:	c8 22 00 00          	enter  0x22,0x0
    1df7:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1dfb:	06                   	push   es
    1dfc:	57                   	push   di
    1dfd:	9a 04 2a 70 1f       	call   0x1f70:0x2a04
    1e02:	89 c7                	mov    di,ax
    1e04:	8e c2                	mov    es,dx
    1e06:	06                   	push   es
    1e07:	57                   	push   di
    1e08:	9a d2 21 07 22       	call   0x2207:0x21d2
    1e0d:	50                   	push   ax
    1e0e:	8d 7e de             	lea    di,[bp-0x22]
    1e11:	16                   	push   ss
    1e12:	57                   	push   di
    1e13:	9a ff ff 00 00       	call   0x0:0xffff
    1e18:	8b 46 e8             	mov    ax,WORD PTR [bp-0x18]
    1e1b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e1e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e21:	c9                   	leave
    1e22:	c2 02 00             	ret    0x2
    1e25:	c8 08 00 00          	enter  0x8,0x0
    1e29:	31 c0                	xor    ax,ax
    1e2b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1e2e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e31:	89 7e f8             	mov    WORD PTR [bp-0x8],di
    1e34:	8c 46 fa             	mov    WORD PTR [bp-0x6],es
    1e37:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e3a:	3b 46 04             	cmp    ax,WORD PTR [bp+0x4]
    1e3d:	7c 03                	jl     0x1e42
    1e3f:	e9 a9 00             	jmp    0x1eeb
    1e42:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e45:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e48:	03 f8                	add    di,ax
    1e4a:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1e4d:	3c 09                	cmp    al,0x9
    1e4f:	75 66                	jne    0x1eb7
    1e51:	55                   	push   bp
    1e52:	e8 57 ff             	call   0x1dac
    1e55:	55                   	push   bp
    1e56:	e8 9a ff             	call   0x1df3
    1e59:	c1 e0 03             	shl    ax,0x3
    1e5c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1e5f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1e62:	31 d2                	xor    dx,dx
    1e64:	52                   	push   dx
    1e65:	50                   	push   ax
    1e66:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1e69:	31 d2                	xor    dx,dx
    1e6b:	8b c8                	mov    cx,ax
    1e6d:	8b da                	mov    bx,dx
    1e6f:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1e72:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1e75:	99                   	cwd
    1e76:	03 c1                	add    ax,cx
    1e78:	13 d3                	adc    dx,bx
    1e7a:	05 01 00             	add    ax,0x1
    1e7d:	83 d2 00             	adc    dx,0x0
    1e80:	59                   	pop    cx
    1e81:	5b                   	pop    bx
    1e82:	9a 70 16 a9 20       	call   0x20a9:0x1670
    1e87:	89 c8                	mov    ax,cx
    1e89:	89 da                	mov    dx,bx
    1e8b:	8b c8                	mov    cx,ax
    1e8d:	8b da                	mov    bx,dx
    1e8f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1e92:	31 d2                	xor    dx,dx
    1e94:	2b c1                	sub    ax,cx
    1e96:	1b d3                	sbb    dx,bx
    1e98:	05 01 00             	add    ax,0x1
    1e9b:	83 d2 00             	adc    dx,0x0
    1e9e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    1ea1:	26 01 05             	add    WORD PTR es:[di],ax
    1ea4:	26 8b 05             	mov    ax,WORD PTR es:[di]
    1ea7:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    1eab:	7e 08                	jle    0x1eb5
    1ead:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1eb0:	06                   	push   es
    1eb1:	57                   	push   di
    1eb2:	e8 89 fd             	call   0x1c3e
    1eb5:	eb 31                	jmp    0x1ee8
    1eb7:	3c 0d                	cmp    al,0xd
    1eb9:	75 06                	jne    0x1ec1
    1ebb:	55                   	push   bp
    1ebc:	e8 ed fe             	call   0x1dac
    1ebf:	eb 27                	jmp    0x1ee8
    1ec1:	3c 0a                	cmp    al,0xa
    1ec3:	75 0e                	jne    0x1ed3
    1ec5:	55                   	push   bp
    1ec6:	e8 e3 fe             	call   0x1dac
    1ec9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1ecc:	06                   	push   es
    1ecd:	57                   	push   di
    1ece:	e8 6d fd             	call   0x1c3e
    1ed1:	eb 15                	jmp    0x1ee8
    1ed3:	3c 0c                	cmp    al,0xc
    1ed5:	75 0e                	jne    0x1ee5
    1ed7:	55                   	push   bp
    1ed8:	e8 d1 fe             	call   0x1dac
    1edb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1ede:	06                   	push   es
    1edf:	57                   	push   di
    1ee0:	e8 08 fd             	call   0x1beb
    1ee3:	eb 03                	jmp    0x1ee8
    1ee5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1ee8:	e9 4c ff             	jmp    0x1e37
    1eeb:	55                   	push   bp
    1eec:	e8 bd fe             	call   0x1dac
    1eef:	c9                   	leave
    1ef0:	c2 0a 00             	ret    0xa
    1ef3:	c8 06 00 00          	enter  0x6,0x0
    1ef7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1efa:	31 c0                	xor    ax,ax
    1efc:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    1f00:	31 c0                	xor    ax,ax
    1f02:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    1f06:	31 c0                	xor    ax,ax
    1f08:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f0b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f0e:	c9                   	leave
    1f0f:	ca 04 00             	retf   0x4
    1f12:	c8 06 00 00          	enter  0x6,0x0
    1f16:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f19:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    1f1c:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    1f1f:	81 c7 20 00          	add    di,0x20
    1f23:	06                   	push   es
    1f24:	57                   	push   di
    1f25:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1f28:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    1f2c:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    1f30:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    1f34:	e8 ee fe             	call   0x1e25
    1f37:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1f3a:	31 c0                	xor    ax,ax
    1f3c:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    1f40:	31 c0                	xor    ax,ax
    1f42:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f45:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f48:	c9                   	leave
    1f49:	ca 04 00             	retf   0x4
    1f4c:	c8 02 00 00          	enter  0x2,0x0
    1f50:	31 c0                	xor    ax,ax
    1f52:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f55:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f58:	c9                   	leave
    1f59:	ca 04 00             	retf   0x4
    1f5c:	c8 06 00 00          	enter  0x6,0x0
    1f60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f63:	81 c7 20 00          	add    di,0x20
    1f67:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    1f6b:	06                   	push   es
    1f6c:	57                   	push   di
    1f6d:	9a 55 26 a4 1f       	call   0x1fa4:0x2655
    1f72:	31 c0                	xor    ax,ax
    1f74:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1f77:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1f7a:	c9                   	leave
    1f7b:	ca 04 00             	retf   0x4
    1f7e:	c8 0a 00 00          	enter  0xa,0x0
    1f82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f85:	89 7e fa             	mov    WORD PTR [bp-0x6],di
    1f88:	8c 46 fc             	mov    WORD PTR [bp-0x4],es
    1f8b:	81 c7 20 00          	add    di,0x20
    1f8f:	89 7e f6             	mov    WORD PTR [bp-0xa],di
    1f92:	8c 46 f8             	mov    WORD PTR [bp-0x8],es
    1f95:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1f98:	26 81 7d 02 b1 d7    	cmp    WORD PTR es:[di+0x2],0xd7b1
    1f9e:	75 2c                	jne    0x1fcc
    1fa0:	b8 f3 1e             	mov    ax,0x1ef3
    1fa3:	ba b2 1f             	mov    dx,0x1fb2
    1fa6:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    1faa:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    1fae:	b8 4c 1f             	mov    ax,0x1f4c
    1fb1:	ba c0 1f             	mov    dx,0x1fc0
    1fb4:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    1fb8:	26 89 55 1a          	mov    WORD PTR es:[di+0x1a],dx
    1fbc:	b8 4c 1f             	mov    ax,0x1f4c
    1fbf:	ba d9 1f             	mov    dx,0x1fd9
    1fc2:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    1fc6:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    1fca:	eb 76                	jmp    0x2042
    1fcc:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1fcf:	26 c7 45 02 b2 d7    	mov    WORD PTR es:[di+0x2],0xd7b2
    1fd5:	b8 12 1f             	mov    ax,0x1f12
    1fd8:	ba e7 1f             	mov    dx,0x1fe7
    1fdb:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    1fdf:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    1fe3:	b8 12 1f             	mov    ax,0x1f12
    1fe6:	ba f5 1f             	mov    dx,0x1ff5
    1fe9:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    1fed:	26 89 55 1a          	mov    WORD PTR es:[di+0x1a],dx
    1ff1:	b8 5c 1f             	mov    ax,0x1f5c
    1ff4:	ba 08 20             	mov    dx,0x2008
    1ff7:	26 89 45 1c          	mov    WORD PTR es:[di+0x1c],ax
    1ffb:	26 89 55 1e          	mov    WORD PTR es:[di+0x1e],dx
    1fff:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2003:	06                   	push   es
    2004:	57                   	push   di
    2005:	9a a8 25 21 20       	call   0x2021:0x25a8
    200a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    200d:	31 c0                	xor    ax,ax
    200f:	26 89 05             	mov    WORD PTR es:[di],ax
    2012:	31 c0                	xor    ax,ax
    2014:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    2018:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    201c:	06                   	push   es
    201d:	57                   	push   di
    201e:	9a 9a 2a 33 20       	call   0x2033:0x2a9a
    2023:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2026:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    202a:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    202e:	06                   	push   es
    202f:	57                   	push   di
    2030:	9a 72 2a 81 20       	call   0x2081:0x2a72
    2035:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    2038:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    203c:	31 c0                	xor    ax,ax
    203e:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2042:	31 c0                	xor    ax,ax
    2044:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2047:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    204a:	c9                   	leave
    204b:	ca 04 00             	retf   0x4
    204e:	c8 08 00 00          	enter  0x8,0x0
    2052:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2055:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2058:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    205b:	81 c7 20 00          	add    di,0x20
    205f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2062:	26 c7 45 02 b0 d7    	mov    WORD PTR es:[di+0x2],0xd7b0
    2068:	26 c7 45 04 80 00    	mov    WORD PTR es:[di+0x4],0x80
    206e:	26 8d 85 80 00       	lea    ax,es:[di+0x80]
    2073:	8c c2                	mov    dx,es
    2075:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2079:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    207d:	b8 7e 1f             	mov    ax,0x1f7e
    2080:	ba ad 20             	mov    dx,0x20ad
    2083:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    2087:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    208b:	c9                   	leave
    208c:	ca 04 00             	retf   0x4
	...
    2097:	af                   	scas   ax,WORD PTR es:[di]
    2098:	20 10                	and    BYTE PTR [bx+si],dl
    209a:	00 2c                	add    BYTE PTR [si],ch
    209c:	1f                   	pop    ds
    209d:	cd 20                	int    0x20
    209f:	64 20 9d 20 9a       	and    BYTE PTR fs:[di-0x65e0],bl
    20a4:	1f                   	pop    ds
    20a5:	a1 20 cb             	mov    ax,ds:0xcb20
    20a8:	1f                   	pop    ds
    20a9:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
    20aa:	20 35                	and    BYTE PTR [di],dh
    20ac:	21 0f                	and    WORD PTR [bx],cx
    20ae:	22 0e 54 50          	and    cl,BYTE PTR ds:0x5054
    20b2:	72 69                	jb     0x211d
    20b4:	6e                   	outs   dx,BYTE PTR ds:[si]
    20b5:	74 65                	je     0x211c
    20b7:	72 44                	jb     0x20fd
    20b9:	65 76 69             	gs jbe 0x2125
    20bc:	63 65 55             	arpl   WORD PTR [di+0x55],sp
    20bf:	89 e5                	mov    bp,sp
    20c1:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    20c5:	74 08                	je     0x20cf
    20c7:	83 ec 08             	sub    sp,0x8
    20ca:	9a e2 1f da 20       	call   0x20da:0x1fe2
    20cf:	31 c0                	xor    ax,ax
    20d1:	50                   	push   ax
    20d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20d5:	06                   	push   es
    20d6:	57                   	push   di
    20d7:	9a 50 1f 71 21       	call   0x2171:0x1f50
    20dc:	ff 76 16             	push   WORD PTR [bp+0x16]
    20df:	ff 76 14             	push   WORD PTR [bp+0x14]
    20e2:	9a d6 0e fb 20       	call   0x20fb:0xed6
    20e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20ea:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    20ee:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    20f2:	ff 76 12             	push   WORD PTR [bp+0x12]
    20f5:	ff 76 10             	push   WORD PTR [bp+0x10]
    20f8:	9a d6 0e 11 21       	call   0x2111:0xed6
    20fd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2100:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2104:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    2108:	ff 76 0e             	push   WORD PTR [bp+0xe]
    210b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    210e:	9a d6 0e 46 21       	call   0x2146:0xed6
    2113:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2116:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    211a:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    211e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2122:	74 07                	je     0x212b
    2124:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2128:	83 c4 06             	add    sp,0x6
    212b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    212e:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2131:	c9                   	leave
    2132:	ca 12 00             	retf   0x12
    2135:	55                   	push   bp
    2136:	89 e5                	mov    bp,sp
    2138:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    213b:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    213f:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2143:	9a 23 0f 56 21       	call   0x2156:0xf23
    2148:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    214b:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    214f:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    2153:	9a 23 0f 66 21       	call   0x2166:0xf23
    2158:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    215b:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    215f:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    2163:	9a 23 0f 8f 21       	call   0x218f:0xf23
    2168:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    216c:	74 05                	je     0x2173
    216e:	9a 0f 20 f3 21       	call   0x21f3:0x200f
    2173:	c9                   	leave
    2174:	ca 06 00             	retf   0x6
    2177:	c8 02 00 00          	enter  0x2,0x0
    217b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    217e:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2182:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2186:	ff 76 14             	push   WORD PTR [bp+0x14]
    2189:	ff 76 12             	push   WORD PTR [bp+0x12]
    218c:	9a b2 0d a9 21       	call   0x21a9:0xdb2
    2191:	09 c0                	or     ax,ax
    2193:	75 34                	jne    0x21c9
    2195:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2198:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    219c:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    21a0:	ff 76 10             	push   WORD PTR [bp+0x10]
    21a3:	ff 76 0e             	push   WORD PTR [bp+0xe]
    21a6:	9a b2 0d c3 21       	call   0x21c3:0xdb2
    21ab:	09 c0                	or     ax,ax
    21ad:	75 1a                	jne    0x21c9
    21af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21b2:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    21b6:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    21ba:	ff 76 0c             	push   WORD PTR [bp+0xc]
    21bd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    21c0:	9a b2 0d 06 26       	call   0x2606:0xdb2
    21c5:	09 c0                	or     ax,ax
    21c7:	74 04                	je     0x21cd
    21c9:	b0 00                	mov    al,0x0
    21cb:	eb 02                	jmp    0x21cf
    21cd:	b0 01                	mov    al,0x1
    21cf:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    21d2:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    21d5:	c9                   	leave
    21d6:	ca 10 00             	retf   0x10
    21d9:	65 22 4f 22          	and    cl,BYTE PTR gs:[bx+0x22]
    21dd:	20 22                	and    BYTE PTR [bp+si],ah
    21df:	00 00                	add    BYTE PTR [bx+si],al
    21e1:	11 22                	adc    WORD PTR [bp+si],sp
    21e3:	2f                   	das
    21e4:	00 60 05             	add    BYTE PTR [bx+si+0x5],ah
    21e7:	7b 22                	jnp    0x220b
    21e9:	64 20 99 22 9a       	and    BYTE PTR fs:[bx+di-0x65de],bl
    21ee:	1f                   	pop    ds
    21ef:	eb 21                	jmp    0x2212
    21f1:	cb                   	retf
    21f2:	1f                   	pop    ds
    21f3:	ef                   	out    dx,ax
    21f4:	21 b7 18 e7          	and    WORD PTR [bx-0x18e8],si
    21f8:	21 cd                	and    bp,cx
    21fa:	11 ff                	adc    di,di
    21fc:	21 e4                	and    sp,sp
    21fe:	11 03                	adc    WORD PTR [bp+di],ax
    2200:	22 fa                	and    bh,dl
    2202:	10 1c                	adc    BYTE PTR [si],bl
    2204:	2b 7f 23             	sub    di,WORD PTR [bx+0x23]
    2207:	f7 21                	mul    WORD PTR [bx+di]
    2209:	06                   	push   es
    220a:	23 24                	and    sp,WORD PTR [si]
    220c:	22 d0                	and    dl,al
    220e:	22 0b                	and    cl,BYTE PTR [bp+di]
    2210:	22 0e 54 50          	and    cl,BYTE PTR ds:0x5054
    2214:	72 69                	jb     0x227f
    2216:	6e                   	outs   dx,BYTE PTR ds:[si]
    2217:	74 65                	je     0x227e
    2219:	72 43                	jb     0x225e
    221b:	61                   	popa
    221c:	6e                   	outs   dx,BYTE PTR ds:[si]
    221d:	76 61                	jbe    0x2280
    221f:	73 03                	jae    0x2224
    2221:	00 d0                	add    al,dl
    2223:	22 35                	and    dh,BYTE PTR [di]
    2225:	22 0c                	and    cl,BYTE PTR [si]
    2227:	43                   	inc    bx
    2228:	72 65                	jb     0x228f
    222a:	61                   	popa
    222b:	74 65                	je     0x2292
    222d:	48                   	dec    ax
    222e:	61                   	popa
    222f:	6e                   	outs   dx,BYTE PTR ds:[si]
    2230:	64 6c                	fs ins BYTE PTR es:[di],dx
    2232:	65 06                	gs push es
    2234:	23 42 22             	and    ax,WORD PTR [bp+si+0x22]
    2237:	08 43 68             	or     BYTE PTR [bp+di+0x68],al
    223a:	61                   	popa
    223b:	6e                   	outs   dx,BYTE PTR ds:[si]
    223c:	67 69 6e 67 27 23    	imul   bp,WORD PTR [esi+0x67],0x2327
    2242:	63 22                	arpl   WORD PTR [bp+si],sp
    2244:	0a 55 70             	or     dl,BYTE PTR [di+0x70]
    2247:	64 61                	fs popa
    2249:	74 65                	je     0x22b0
    224b:	46                   	inc    si
    224c:	6f                   	outs   dx,WORD PTR ds:[si]
    224d:	6e                   	outs   dx,BYTE PTR ds:[si]
    224e:	74 01                	je     0x2251
    2250:	00 5f 22             	add    BYTE PTR [bx+0x22],bl
    2253:	2b 00                	sub    ax,WORD PTR [bx+si]
    2255:	00 00                	add    BYTE PTR [bx+si],al
    2257:	07                   	pop    es
    2258:	50                   	push   ax
    2259:	72 69                	jb     0x22c4
    225b:	6e                   	outs   dx,BYTE PTR ds:[si]
    225c:	74 65                	je     0x22c3
    225e:	72 01                	jb     0x2261
    2260:	00 ca                	add    dl,cl
    2262:	1a 77 22             	sbb    dh,BYTE PTR [bx+0x22]
    2265:	07                   	pop    es
    2266:	0e                   	push   cs
    2267:	54                   	push   sp
    2268:	50                   	push   ax
    2269:	72 69                	jb     0x22d4
    226b:	6e                   	outs   dx,BYTE PTR ds:[si]
    226c:	74 65                	je     0x22d3
    226e:	72 43                	jb     0x22b3
    2270:	61                   	popa
    2271:	6e                   	outs   dx,BYTE PTR ds:[si]
    2272:	76 61                	jbe    0x22d5
    2274:	73 f9                	jae    0x226f
    2276:	21 e1                	and    cx,sp
    2278:	22 80 05 a6          	and    al,BYTE PTR [bx+si-0x59fb]
    227c:	22 04                	and    al,BYTE PTR [si]
    227e:	00 08                	add    BYTE PTR [bx+si],cl
    2280:	50                   	push   ax
    2281:	72 69                	jb     0x22ec
    2283:	6e                   	outs   dx,BYTE PTR ds:[si]
    2284:	74 65                	je     0x22eb
    2286:	72 73                	jb     0x22fb
    2288:	00 00                	add    BYTE PTR [bx+si],al
    228a:	55                   	push   bp
    228b:	89 e5                	mov    bp,sp
    228d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2291:	74 08                	je     0x229b
    2293:	83 ec 08             	sub    sp,0x8
    2296:	9a e2 1f 7d 23       	call   0x237d:0x1fe2
    229b:	31 c0                	xor    ax,ax
    229d:	50                   	push   ax
    229e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22a1:	06                   	push   es
    22a2:	57                   	push   di
    22a3:	9a b8 17 00 23       	call   0x2300:0x17b8
    22a8:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    22ab:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    22ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22b1:	26 89 45 2b          	mov    WORD PTR es:[di+0x2b],ax
    22b5:	26 89 55 2d          	mov    WORD PTR es:[di+0x2d],dx
    22b9:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    22bd:	74 07                	je     0x22c6
    22bf:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    22c3:	83 c4 06             	add    sp,0x6
    22c6:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    22c9:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    22cc:	c9                   	leave
    22cd:	ca 0a 00             	retf   0xa
    22d0:	55                   	push   bp
    22d1:	89 e5                	mov    bp,sp
    22d3:	6a 01                	push   0x1
    22d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22d8:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    22dc:	06                   	push   es
    22dd:	57                   	push   di
    22de:	9a 1d 24 eb 22       	call   0x22eb:0x241d
    22e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22e6:	06                   	push   es
    22e7:	57                   	push   di
    22e8:	9a 27 23 17 23       	call   0x2317:0x2327
    22ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22f0:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    22f4:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    22f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22fb:	06                   	push   es
    22fc:	57                   	push   di
    22fd:	9a 5d 22 21 23       	call   0x2321:0x225d
    2302:	c9                   	leave
    2303:	ca 04 00             	retf   0x4
    2306:	55                   	push   bp
    2307:	89 e5                	mov    bp,sp
    2309:	6a 01                	push   0x1
    230b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    230e:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    2312:	06                   	push   es
    2313:	57                   	push   di
    2314:	9a 66 25 be 23       	call   0x23be:0x2566
    2319:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    231c:	06                   	push   es
    231d:	57                   	push   di
    231e:	9a 5b 23 37 23       	call   0x2337:0x235b
    2323:	c9                   	leave
    2324:	ca 04 00             	retf   0x4
    2327:	c8 22 00 00          	enter  0x22,0x0
    232b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    232e:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2332:	06                   	push   es
    2333:	57                   	push   di
    2334:	9a cc 11 68 23       	call   0x2368:0x11cc
    2339:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    233c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    233f:	26 c4 7d 2b          	les    di,DWORD PTR es:[di+0x2b]
    2343:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    2347:	6a 5a                	push   0x5a
    2349:	9a 8c 2a 00 00       	call   0x0:0x2a8c
    234e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2351:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2355:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    2359:	ff 76 de             	push   WORD PTR [bp-0x22]
    235c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    235f:	26 c4 7d 07          	les    di,DWORD PTR es:[di+0x7]
    2363:	06                   	push   es
    2364:	57                   	push   di
    2365:	9a f5 11 5e 24       	call   0x245e:0x11f5
    236a:	c9                   	leave
    236b:	ca 04 00             	retf   0x4
    236e:	55                   	push   bp
    236f:	89 e5                	mov    bp,sp
    2371:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2375:	74 08                	je     0x237f
    2377:	83 ec 08             	sub    sp,0x8
    237a:	9a e2 1f 8a 23       	call   0x238a:0x1fe2
    237f:	31 c0                	xor    ax,ax
    2381:	50                   	push   ax
    2382:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2385:	06                   	push   es
    2386:	57                   	push   di
    2387:	9a 50 1f ec 23       	call   0x23ec:0x1f50
    238c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    238f:	26 c7 45 12 ff ff    	mov    WORD PTR es:[di+0x12],0xffff
    2395:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2399:	74 07                	je     0x23a2
    239b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    239f:	83 c4 06             	add    sp,0x6
    23a2:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    23a5:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    23a8:	c9                   	leave
    23a9:	ca 06 00             	retf   0x6
    23ac:	55                   	push   bp
    23ad:	89 e5                	mov    bp,sp
    23af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b2:	26 80 7d 18 00       	cmp    BYTE PTR es:[di+0x18],0x0
    23b7:	74 07                	je     0x23c0
    23b9:	06                   	push   es
    23ba:	57                   	push   di
    23bb:	9a 55 26 ca 23       	call   0x23ca:0x2655
    23c0:	6a 00                	push   0x0
    23c2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23c5:	06                   	push   es
    23c6:	57                   	push   di
    23c7:	9a 1d 24 d4 23       	call   0x23d4:0x241d
    23cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23cf:	06                   	push   es
    23d0:	57                   	push   di
    23d1:	9a 87 2d de 23       	call   0x23de:0x2d87
    23d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23d9:	06                   	push   es
    23da:	57                   	push   di
    23db:	9a fd 2d 46 24       	call   0x2446:0x2dfd
    23e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e3:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    23e7:	06                   	push   es
    23e8:	57                   	push   di
    23e9:	9a 7f 1f 0c 24       	call   0x240c:0x1f7f
    23ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23f1:	26 83 7d 23 00       	cmp    WORD PTR es:[di+0x23],0x0
    23f6:	74 09                	je     0x2401
    23f8:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    23fc:	9a c7 27 00 00       	call   0x0:0x27c7
    2401:	31 c0                	xor    ax,ax
    2403:	50                   	push   ax
    2404:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2407:	06                   	push   es
    2408:	57                   	push   di
    2409:	9a 66 1f 17 24       	call   0x2417:0x1f66
    240e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2412:	74 05                	je     0x2419
    2414:	9a 0f 20 44 2b       	call   0x2b44:0x200f
    2419:	c9                   	leave
    241a:	ca 06 00             	retf   0x6
    241d:	c8 08 00 00          	enter  0x8,0x0
    2421:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    2424:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2427:	26 3a 45 1a          	cmp    al,BYTE PTR es:[di+0x1a]
    242b:	75 03                	jne    0x2430
    242d:	e9 32 01             	jmp    0x2562
    2430:	31 c0                	xor    ax,ax
    2432:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2435:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2438:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    243b:	3c 00                	cmp    al,0x0
    243d:	75 38                	jne    0x2477
    243f:	6a 00                	push   0x0
    2441:	06                   	push   es
    2442:	57                   	push   di
    2443:	9a 66 25 e4 24       	call   0x24e4:0x2566
    2448:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    244b:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    244f:	09 c0                	or     ax,ax
    2451:	74 0d                	je     0x2460
    2453:	6a 00                	push   0x0
    2455:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2459:	06                   	push   es
    245a:	57                   	push   di
    245b:	9a 5d 22 b4 24       	call   0x24b4:0x225d
    2460:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2463:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    2467:	9a c5 24 00 00       	call   0x0:0x24c5
    246c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    246f:	31 c0                	xor    ax,ax
    2471:	26 89 45 1b          	mov    WORD PTR es:[di+0x1b],ax
    2475:	eb 5e                	jmp    0x24d5
    2477:	3c 01                	cmp    al,0x1
    2479:	75 1d                	jne    0x2498
    247b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    247e:	26 80 7d 1a 02       	cmp    BYTE PTR es:[di+0x1a],0x2
    2483:	74 0e                	je     0x2493
    2485:	b8 ff ff             	mov    ax,0xffff
    2488:	ba ff ff             	mov    dx,0xffff
    248b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    248e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2491:	eb 03                	jmp    0x2496
    2493:	e9 cc 00             	jmp    0x2562
    2496:	eb 3d                	jmp    0x24d5
    2498:	3c 02                	cmp    al,0x2
    249a:	75 39                	jne    0x24d5
    249c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    249f:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    24a3:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    24a7:	74 0d                	je     0x24b6
    24a9:	6a 00                	push   0x0
    24ab:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    24af:	06                   	push   es
    24b0:	57                   	push   di
    24b1:	9a 5d 22 56 25       	call   0x2556:0x225d
    24b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24b9:	26 83 7d 1b 00       	cmp    WORD PTR es:[di+0x1b],0x0
    24be:	74 09                	je     0x24c9
    24c0:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    24c4:	9a ff ff 00 00       	call   0x0:0xffff
    24c9:	b8 ff ff             	mov    ax,0xffff
    24cc:	ba ff ff             	mov    dx,0xffff
    24cf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    24d2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    24d5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    24d8:	09 c0                	or     ax,ax
    24da:	74 7c                	je     0x2558
    24dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24df:	06                   	push   es
    24e0:	57                   	push   di
    24e1:	9a c2 2a ef 24       	call   0x24ef:0x2ac2
    24e6:	50                   	push   ax
    24e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    24ea:	06                   	push   es
    24eb:	57                   	push   di
    24ec:	9a 01 2b 9a 25       	call   0x259a:0x2b01
    24f1:	89 c7                	mov    di,ax
    24f3:	8e c2                	mov    es,dx
    24f5:	06                   	push   es
    24f6:	57                   	push   di
    24f7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    24fa:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    24fe:	89 c7                	mov    di,ax
    2500:	8e c2                	mov    es,dx
    2502:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2506:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    250a:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    250e:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    2512:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    2516:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    251a:	31 c0                	xor    ax,ax
    251c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    251f:	26 8b 55 1d          	mov    dx,WORD PTR es:[di+0x1d]
    2523:	52                   	push   dx
    2524:	50                   	push   ax
    2525:	ff 5e fc             	call   DWORD PTR [bp-0x4]
    2528:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    252b:	26 89 45 1b          	mov    WORD PTR es:[di+0x1b],ax
    252f:	26 83 7d 1b 00       	cmp    WORD PTR es:[di+0x1b],0x0
    2534:	75 06                	jne    0x253c
    2536:	68 36 f0             	push   0xf036
    2539:	e8 24 f6             	call   0x1b60
    253c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    253f:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2543:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    2547:	74 0f                	je     0x2558
    2549:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    254d:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2551:	06                   	push   es
    2552:	57                   	push   di
    2553:	9a 5d 22 d7 25       	call   0x25d7:0x225d
    2558:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    255b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    255e:	26 88 45 1a          	mov    BYTE PTR es:[di+0x1a],al
    2562:	c9                   	leave
    2563:	ca 06 00             	retf   0x6
    2566:	55                   	push   bp
    2567:	89 e5                	mov    bp,sp
    2569:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    256c:	26 8a 45 18          	mov    al,BYTE PTR es:[di+0x18]
    2570:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    2573:	74 14                	je     0x2589
    2575:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2579:	74 08                	je     0x2583
    257b:	68 33 f0             	push   0xf033
    257e:	e8 df f5             	call   0x1b60
    2581:	eb 06                	jmp    0x2589
    2583:	68 34 f0             	push   0xf034
    2586:	e8 d7 f5             	call   0x1b60
    2589:	c9                   	leave
    258a:	ca 06 00             	retf   0x6
    258d:	55                   	push   bp
    258e:	89 e5                	mov    bp,sp
    2590:	6a 01                	push   0x1
    2592:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2595:	06                   	push   es
    2596:	57                   	push   di
    2597:	9a 66 25 b6 25       	call   0x25b6:0x2566
    259c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    259f:	26 c6 45 19 01       	mov    BYTE PTR es:[di+0x19],0x1
    25a4:	c9                   	leave
    25a5:	ca 04 00             	retf   0x4
    25a8:	c8 2a 01 00          	enter  0x12a,0x0
    25ac:	6a 00                	push   0x0
    25ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25b1:	06                   	push   es
    25b2:	57                   	push   di
    25b3:	9a 66 25 c2 25       	call   0x25c2:0x2566
    25b8:	6a 02                	push   0x2
    25ba:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25bd:	06                   	push   es
    25be:	57                   	push   di
    25bf:	9a 1d 24 cc 25       	call   0x25cc:0x241d
    25c4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25c7:	06                   	push   es
    25c8:	57                   	push   di
    25c9:	9a 04 2a ff 25       	call   0x25ff:0x2a04
    25ce:	89 c7                	mov    di,ax
    25d0:	8e c2                	mov    es,dx
    25d2:	06                   	push   es
    25d3:	57                   	push   di
    25d4:	9a 65 1e d8 26       	call   0x26d8:0x1e65
    25d9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25dc:	26 c6 45 18 01       	mov    BYTE PTR es:[di+0x18],0x1
    25e1:	26 c6 45 19 00       	mov    BYTE PTR es:[di+0x19],0x0
    25e6:	26 c7 45 0c 01 00    	mov    WORD PTR es:[di+0xc],0x1
    25ec:	8d 7e e0             	lea    di,[bp-0x20]
    25ef:	16                   	push   ss
    25f0:	57                   	push   di
    25f1:	8d be d6 fe          	lea    di,[bp-0x12a]
    25f5:	16                   	push   ss
    25f6:	57                   	push   di
    25f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    25fa:	06                   	push   es
    25fb:	57                   	push   di
    25fc:	9a f0 2c 2b 26       	call   0x262b:0x2cf0
    2601:	6a 1f                	push   0x1f
    2603:	9a 6a 0d 2c 27       	call   0x272c:0xd6a
    2608:	c7 46 d6 0a 00       	mov    WORD PTR [bp-0x2a],0xa
    260d:	8d 46 e0             	lea    ax,[bp-0x20]
    2610:	8c d2                	mov    dx,ss
    2612:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
    2615:	89 56 da             	mov    WORD PTR [bp-0x26],dx
    2618:	31 c0                	xor    ax,ax
    261a:	89 46 dc             	mov    WORD PTR [bp-0x24],ax
    261d:	89 46 de             	mov    WORD PTR [bp-0x22],ax
    2620:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2623:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    2627:	bf 8d 1b             	mov    di,0x1b8d
    262a:	b8 62 26             	mov    ax,0x2662
    262d:	50                   	push   ax
    262e:	57                   	push   di
    262f:	9a ff ff 00 00       	call   0x0:0xffff
    2634:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2637:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    263b:	8d 7e d6             	lea    di,[bp-0x2a]
    263e:	16                   	push   ss
    263f:	57                   	push   di
    2640:	9a ff ff 00 00       	call   0x0:0xffff
    2645:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2648:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    264c:	9a bd 26 00 00       	call   0x0:0x26bd
    2651:	c9                   	leave
    2652:	ca 04 00             	retf   0x4
    2655:	55                   	push   bp
    2656:	89 e5                	mov    bp,sp
    2658:	6a 01                	push   0x1
    265a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    265d:	06                   	push   es
    265e:	57                   	push   di
    265f:	9a 66 25 a7 26       	call   0x26a7:0x2566
    2664:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2667:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    266b:	9a b1 26 00 00       	call   0x0:0x26b1
    2670:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2673:	26 80 7d 19 00       	cmp    BYTE PTR es:[di+0x19],0x0
    2678:	75 09                	jne    0x2683
    267a:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    267e:	9a ff ff 00 00       	call   0x0:0xffff
    2683:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2686:	26 c6 45 18 00       	mov    BYTE PTR es:[di+0x18],0x0
    268b:	26 c6 45 19 00       	mov    BYTE PTR es:[di+0x19],0x0
    2690:	31 c0                	xor    ax,ax
    2692:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2696:	c9                   	leave
    2697:	ca 04 00             	retf   0x4
    269a:	55                   	push   bp
    269b:	89 e5                	mov    bp,sp
    269d:	6a 01                	push   0x1
    269f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26a2:	06                   	push   es
    26a3:	57                   	push   di
    26a4:	9a 66 25 cd 26       	call   0x26cd:0x2566
    26a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26ac:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    26b0:	9a ff ff 00 00       	call   0x0:0xffff
    26b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26b8:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    26bc:	9a ff ff 00 00       	call   0x0:0xffff
    26c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26c4:	26 ff 45 0c          	inc    WORD PTR es:[di+0xc]
    26c8:	06                   	push   es
    26c9:	57                   	push   di
    26ca:	9a 04 2a f7 26       	call   0x26f7:0x2a04
    26cf:	89 c7                	mov    di,ax
    26d1:	8e c2                	mov    es,dx
    26d3:	06                   	push   es
    26d4:	57                   	push   di
    26d5:	9a 65 1e ff ff       	call   0xffff:0x1e65
    26da:	c9                   	leave
    26db:	ca 04 00             	retf   0x4
    26de:	c8 04 00 00          	enter  0x4,0x0
    26e2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26e5:	26 8b 45 1d          	mov    ax,WORD PTR es:[di+0x1d]
    26e9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    26ec:	26 89 05             	mov    WORD PTR es:[di],ax
    26ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26f2:	06                   	push   es
    26f3:	57                   	push   di
    26f4:	9a c2 2a 02 27       	call   0x2702:0x2ac2
    26f9:	50                   	push   ax
    26fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26fd:	06                   	push   es
    26fe:	57                   	push   di
    26ff:	9a 01 2b 75 27       	call   0x2775:0x2b01
    2704:	89 c7                	mov    di,ax
    2706:	8e c2                	mov    es,dx
    2708:	06                   	push   es
    2709:	57                   	push   di
    270a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    270d:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    2711:	89 c7                	mov    di,ax
    2713:	8e c2                	mov    es,dx
    2715:	89 7e fc             	mov    WORD PTR [bp-0x4],di
    2718:	8c 46 fe             	mov    WORD PTR [bp-0x2],es
    271b:	ff 76 18             	push   WORD PTR [bp+0x18]
    271e:	ff 76 16             	push   WORD PTR [bp+0x16]
    2721:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    2725:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    2729:	9a df 0c 42 27       	call   0x2742:0xcdf
    272e:	ff 76 14             	push   WORD PTR [bp+0x14]
    2731:	ff 76 12             	push   WORD PTR [bp+0x12]
    2734:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2737:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    273b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    273f:	9a df 0c 58 27       	call   0x2758:0xcdf
    2744:	ff 76 10             	push   WORD PTR [bp+0x10]
    2747:	ff 76 0e             	push   WORD PTR [bp+0xe]
    274a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    274d:	26 ff 75 0e          	push   WORD PTR es:[di+0xe]
    2751:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    2755:	9a df 0c b5 28       	call   0x28b5:0xcdf
    275a:	c9                   	leave
    275b:	ca 14 00             	retf   0x14
    275e:	08 25                	or     BYTE PTR [di],ah
    2760:	73 20                	jae    0x2782
    2762:	6f                   	outs   dx,WORD PTR ds:[si]
    2763:	6e                   	outs   dx,BYTE PTR ds:[si]
    2764:	20 25                	and    BYTE PTR [di],ah
    2766:	73 c8                	jae    0x2730
    2768:	58                   	pop    ax
    2769:	02 00                	add    al,BYTE PTR [bx+si]
    276b:	6a 00                	push   0x0
    276d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2770:	06                   	push   es
    2771:	57                   	push   di
    2772:	9a 66 25 ac 27       	call   0x27ac:0x2566
    2777:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    277a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    277d:	26 3b 45 1d          	cmp    ax,WORD PTR es:[di+0x1d]
    2781:	74 21                	je     0x27a4
    2783:	26 ff 75 1d          	push   WORD PTR es:[di+0x1d]
    2787:	e8 3d f4             	call   0x1bc7
    278a:	08 c0                	or     al,al
    278c:	74 0c                	je     0x279a
    278e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2791:	26 ff 75 1d          	push   WORD PTR es:[di+0x1d]
    2795:	9a f3 29 00 00       	call   0x0:0x29f3
    279a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    279d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a0:	26 89 45 1d          	mov    WORD PTR es:[di+0x1d],ax
    27a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a7:	06                   	push   es
    27a8:	57                   	push   di
    27a9:	9a fd 2d de 27       	call   0x27de:0x2dfd
    27ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27b1:	31 c0                	xor    ax,ax
    27b3:	26 89 45 1f          	mov    WORD PTR es:[di+0x1f],ax
    27b7:	26 89 45 21          	mov    WORD PTR es:[di+0x21],ax
    27bb:	26 83 7d 23 00       	cmp    WORD PTR es:[di+0x23],0x0
    27c0:	74 12                	je     0x27d4
    27c2:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    27c6:	9a ff ff 00 00       	call   0x0:0xffff
    27cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27ce:	31 c0                	xor    ax,ax
    27d0:	26 89 45 23          	mov    WORD PTR es:[di+0x23],ax
    27d4:	6a 00                	push   0x0
    27d6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27d9:	06                   	push   es
    27da:	57                   	push   di
    27db:	9a 1d 24 ed 27       	call   0x27ed:0x241d
    27e0:	c7 46 fc ff ff       	mov    WORD PTR [bp-0x4],0xffff
    27e5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e8:	06                   	push   es
    27e9:	57                   	push   di
    27ea:	9a 01 2b 2e 28       	call   0x282e:0x2b01
    27ef:	89 c7                	mov    di,ax
    27f1:	8e c2                	mov    es,dx
    27f3:	06                   	push   es
    27f4:	57                   	push   di
    27f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    27f8:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    27fc:	48                   	dec    ax
    27fd:	89 86 b6 fe          	mov    WORD PTR [bp-0x14a],ax
    2801:	31 c0                	xor    ax,ax
    2803:	3b 86 b6 fe          	cmp    ax,WORD PTR [bp-0x14a]
    2807:	7f 54                	jg     0x285d
    2809:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    280c:	eb 03                	jmp    0x2811
    280e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2811:	ff 76 12             	push   WORD PTR [bp+0x12]
    2814:	ff 76 10             	push   WORD PTR [bp+0x10]
    2817:	ff 76 16             	push   WORD PTR [bp+0x16]
    281a:	ff 76 14             	push   WORD PTR [bp+0x14]
    281d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2820:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2823:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2826:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2829:	06                   	push   es
    282a:	57                   	push   di
    282b:	9a 01 2b 46 28       	call   0x2846:0x2b01
    2830:	89 c7                	mov    di,ax
    2832:	8e c2                	mov    es,dx
    2834:	06                   	push   es
    2835:	57                   	push   di
    2836:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2839:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    283d:	89 c7                	mov    di,ax
    283f:	8e c2                	mov    es,dx
    2841:	06                   	push   es
    2842:	57                   	push   di
    2843:	9a 77 21 d0 28       	call   0x28d0:0x2177
    2848:	08 c0                	or     al,al
    284a:	74 08                	je     0x2854
    284c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    284f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2852:	eb 09                	jmp    0x285d
    2854:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2857:	3b 86 b6 fe          	cmp    ax,WORD PTR [bp-0x14a]
    285b:	75 b1                	jne    0x280e
    285d:	83 7e fc ff          	cmp    WORD PTR [bp-0x4],0xffff
    2861:	74 03                	je     0x2866
    2863:	e9 85 00             	jmp    0x28eb
    2866:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2869:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    286d:	06                   	push   es
    286e:	57                   	push   di
    286f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2872:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2876:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2879:	8d be a8 fd          	lea    di,[bp-0x258]
    287d:	16                   	push   ss
    287e:	57                   	push   di
    287f:	bf 5e 27             	mov    di,0x275e
    2882:	0e                   	push   cs
    2883:	57                   	push   di
    2884:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
    2887:	8b 56 16             	mov    dx,WORD PTR [bp+0x16]
    288a:	89 86 a8 fe          	mov    WORD PTR [bp-0x158],ax
    288e:	89 96 aa fe          	mov    WORD PTR [bp-0x156],dx
    2892:	c6 86 ac fe 06       	mov    BYTE PTR [bp-0x154],0x6
    2897:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    289a:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    289d:	89 86 b0 fe          	mov    WORD PTR [bp-0x150],ax
    28a1:	89 96 b2 fe          	mov    WORD PTR [bp-0x14e],dx
    28a5:	c6 86 b4 fe 06       	mov    BYTE PTR [bp-0x14c],0x6
    28aa:	8d be a8 fe          	lea    di,[bp-0x158]
    28ae:	16                   	push   ss
    28af:	57                   	push   di
    28b0:	6a 01                	push   0x1
    28b2:	9a 34 10 04 29       	call   0x2904:0x1034
    28b7:	ff 76 12             	push   WORD PTR [bp+0x12]
    28ba:	ff 76 10             	push   WORD PTR [bp+0x10]
    28bd:	ff 76 16             	push   WORD PTR [bp+0x16]
    28c0:	ff 76 14             	push   WORD PTR [bp+0x14]
    28c3:	ff 76 0e             	push   WORD PTR [bp+0xe]
    28c6:	ff 76 0c             	push   WORD PTR [bp+0xc]
    28c9:	b0 01                	mov    al,0x1
    28cb:	50                   	push   ax
    28cc:	b8 af 20             	mov    ax,0x20af
    28cf:	ba d7 28             	mov    dx,0x28d7
    28d2:	52                   	push   dx
    28d3:	50                   	push   ax
    28d4:	9a be 20 22 2a       	call   0x2a22:0x20be
    28d9:	52                   	push   dx
    28da:	50                   	push   ax
    28db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28de:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    28e2:	06                   	push   es
    28e3:	57                   	push   di
    28e4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    28e7:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    28eb:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    28ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28f1:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    28f5:	8d be b8 fe          	lea    di,[bp-0x148]
    28f9:	16                   	push   ss
    28fa:	57                   	push   di
    28fb:	ff 76 12             	push   WORD PTR [bp+0x12]
    28fe:	ff 76 10             	push   WORD PTR [bp+0x10]
    2901:	9a df 0c 10 29       	call   0x2910:0xcdf
    2906:	52                   	push   dx
    2907:	50                   	push   ax
    2908:	bf d2 16             	mov    di,0x16d2
    290b:	1e                   	push   ds
    290c:	57                   	push   di
    290d:	9a 8f 0d 27 2c       	call   0x2c27:0xd8f
    2912:	8d be b8 fe          	lea    di,[bp-0x148]
    2916:	16                   	push   ss
    2917:	57                   	push   di
    2918:	9a ff ff 00 00       	call   0x0:0xffff
    291d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2920:	26 89 45 23          	mov    WORD PTR es:[di+0x23],ax
    2924:	26 83 7d 23 10       	cmp    WORD PTR es:[di+0x23],0x10
    2929:	77 06                	ja     0x2931
    292b:	31 c0                	xor    ax,ax
    292d:	26 89 45 23          	mov    WORD PTR es:[di+0x23],ax
    2931:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2934:	26 83 7d 23 00       	cmp    WORD PTR es:[di+0x23],0x0
    2939:	75 03                	jne    0x293e
    293b:	e9 c2 00             	jmp    0x2a00
    293e:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    2942:	bf d7 16             	mov    di,0x16d7
    2945:	1e                   	push   ds
    2946:	57                   	push   di
    2947:	9a ff ff 00 00       	call   0x0:0xffff
    294c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    294f:	26 89 45 1f          	mov    WORD PTR es:[di+0x1f],ax
    2953:	26 89 55 21          	mov    WORD PTR es:[di+0x21],dx
    2957:	26 8b 45 21          	mov    ax,WORD PTR es:[di+0x21]
    295b:	09 c0                	or     ax,ax
    295d:	75 03                	jne    0x2962
    295f:	e9 9e 00             	jmp    0x2a00
    2962:	26 83 7d 1d 00       	cmp    WORD PTR es:[di+0x1d],0x0
    2967:	74 03                	je     0x296c
    2969:	e9 94 00             	jmp    0x2a00
    296c:	a1 9a 18             	mov    ax,ds:0x189a
    296f:	0d 40 00             	or     ax,0x40
    2972:	50                   	push   ax
    2973:	6a 00                	push   0x0
    2975:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    2979:	8d 7e bc             	lea    di,[bp-0x44]
    297c:	16                   	push   ss
    297d:	57                   	push   di
    297e:	ff 76 16             	push   WORD PTR [bp+0x16]
    2981:	ff 76 14             	push   WORD PTR [bp+0x14]
    2984:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2987:	ff 76 0c             	push   WORD PTR [bp+0xc]
    298a:	8d 7e bc             	lea    di,[bp-0x44]
    298d:	16                   	push   ss
    298e:	57                   	push   di
    298f:	6a 00                	push   0x0
    2991:	6a 00                	push   0x0
    2993:	6a 00                	push   0x0
    2995:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2998:	26 ff 5d 1f          	call   DWORD PTR es:[di+0x1f]
    299c:	99                   	cwd
    299d:	52                   	push   dx
    299e:	50                   	push   ax
    299f:	9a ff ff 00 00       	call   0x0:0xffff
    29a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a7:	26 89 45 1d          	mov    WORD PTR es:[di+0x1d],ax
    29ab:	26 83 7d 1d 00       	cmp    WORD PTR es:[di+0x1d],0x0
    29b0:	74 4e                	je     0x2a00
    29b2:	31 c0                	xor    ax,ax
    29b4:	26 8b 55 1d          	mov    dx,WORD PTR es:[di+0x1d]
    29b8:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
    29bb:	89 56 ba             	mov    WORD PTR [bp-0x46],dx
    29be:	6a 00                	push   0x0
    29c0:	26 ff 75 23          	push   WORD PTR es:[di+0x23]
    29c4:	c4 7e b8             	les    di,DWORD PTR [bp-0x48]
    29c7:	06                   	push   es
    29c8:	57                   	push   di
    29c9:	ff 76 16             	push   WORD PTR [bp+0x16]
    29cc:	ff 76 14             	push   WORD PTR [bp+0x14]
    29cf:	ff 76 0e             	push   WORD PTR [bp+0xe]
    29d2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    29d5:	c4 7e b8             	les    di,DWORD PTR [bp-0x48]
    29d8:	06                   	push   es
    29d9:	57                   	push   di
    29da:	6a 00                	push   0x0
    29dc:	6a 00                	push   0x0
    29de:	6a 02                	push   0x2
    29e0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29e3:	26 ff 5d 1f          	call   DWORD PTR es:[di+0x1f]
    29e7:	09 c0                	or     ax,ax
    29e9:	7d 15                	jge    0x2a00
    29eb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29ee:	26 ff 75 1d          	push   WORD PTR es:[di+0x1d]
    29f2:	9a ff ff 00 00       	call   0x0:0xffff
    29f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29fa:	31 c0                	xor    ax,ax
    29fc:	26 89 45 1d          	mov    WORD PTR es:[di+0x1d],ax
    2a00:	c9                   	leave
    2a01:	ca 12 00             	retf   0x12
    2a04:	c8 04 00 00          	enter  0x4,0x0
    2a08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a0b:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2a0f:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    2a13:	75 21                	jne    0x2a36
    2a15:	ff 76 08             	push   WORD PTR [bp+0x8]
    2a18:	ff 76 06             	push   WORD PTR [bp+0x6]
    2a1b:	b0 01                	mov    al,0x1
    2a1d:	50                   	push   ax
    2a1e:	b8 f9 21             	mov    ax,0x21f9
    2a21:	ba 29 2a             	mov    dx,0x2a29
    2a24:	52                   	push   dx
    2a25:	50                   	push   ax
    2a26:	9a 8a 22 5f 2a       	call   0x2a5f:0x228a
    2a2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a2e:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2a32:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    2a36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a39:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    2a3d:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
    2a41:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a44:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2a47:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2a4a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2a4d:	c9                   	leave
    2a4e:	ca 04 00             	retf   0x4
    2a51:	c8 02 00 00          	enter  0x2,0x0
    2a55:	6a 01                	push   0x1
    2a57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a5a:	06                   	push   es
    2a5b:	57                   	push   di
    2a5c:	9a 1d 24 80 2a       	call   0x2a80:0x241d
    2a61:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a64:	26 8b 45 1b          	mov    ax,WORD PTR es:[di+0x1b]
    2a68:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a6b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a6e:	c9                   	leave
    2a6f:	ca 04 00             	retf   0x4
    2a72:	c8 02 00 00          	enter  0x2,0x0
    2a76:	6a 01                	push   0x1
    2a78:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a7b:	06                   	push   es
    2a7c:	57                   	push   di
    2a7d:	9a 1d 24 a8 2a       	call   0x2aa8:0x241d
    2a82:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a85:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    2a89:	6a 0a                	push   0xa
    2a8b:	9a b4 2a 00 00       	call   0x0:0x2ab4
    2a90:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a93:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2a96:	c9                   	leave
    2a97:	ca 04 00             	retf   0x4
    2a9a:	c8 02 00 00          	enter  0x2,0x0
    2a9e:	6a 01                	push   0x1
    2aa0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aa3:	06                   	push   es
    2aa4:	57                   	push   di
    2aa5:	9a 1d 24 d5 2a       	call   0x2ad5:0x241d
    2aaa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2aad:	26 ff 75 1b          	push   WORD PTR es:[di+0x1b]
    2ab1:	6a 08                	push   0x8
    2ab3:	9a ff ff 00 00       	call   0x0:0xffff
    2ab8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2abb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2abe:	c9                   	leave
    2abf:	ca 04 00             	retf   0x4
    2ac2:	c8 02 00 00          	enter  0x2,0x0
    2ac6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ac9:	26 83 7d 12 ff       	cmp    WORD PTR es:[di+0x12],0xffff
    2ace:	75 07                	jne    0x2ad7
    2ad0:	06                   	push   es
    2ad1:	57                   	push   di
    2ad2:	9a 2f 2d f5 2a       	call   0x2af5:0x2d2f
    2ad7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ada:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    2ade:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2ae1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2ae4:	c9                   	leave
    2ae5:	ca 04 00             	retf   0x4
    2ae8:	08 25                	or     BYTE PTR [di],ah
    2aea:	73 20                	jae    0x2b0c
    2aec:	6f                   	outs   dx,WORD PTR ds:[si]
    2aed:	6e                   	outs   dx,BYTE PTR ds:[si]
    2aee:	20 25                	and    BYTE PTR [di],ah
    2af0:	73 00                	jae    0x2af2
    2af2:	00 97 2c ff          	add    BYTE PTR [bx-0xd4],dl
    2af6:	2a 01                	sub    al,BYTE PTR [bx+di]
    2af8:	00 00                	add    BYTE PTR [bx+si],al
    2afa:	00 00                	add    BYTE PTR [bx+si],al
    2afc:	00 af 2c 48          	add    BYTE PTR [bx+0x482c],ch
    2b00:	2c c8                	sub    al,0xc8
    2b02:	c8 01 00 c4          	enter  0x1,0xc4
    2b06:	7e 06                	jle    0x2b0e
    2b08:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    2b0c:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    2b10:	74 03                	je     0x2b15
    2b12:	e9 bf 01             	jmp    0x2cd4
    2b15:	b0 01                	mov    al,0x1
    2b17:	50                   	push   ax
    2b18:	b8 c9 03             	mov    ax,0x3c9
    2b1b:	ba 23 2b             	mov    dx,0x2b23
    2b1e:	52                   	push   dx
    2b1f:	50                   	push   ax
    2b20:	9a 08 1d ff ff       	call   0xffff:0x1d08
    2b25:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b28:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    2b2c:	26 89 55 10          	mov    WORD PTR es:[di+0x10],dx
    2b30:	b8 f7 2a             	mov    ax,0x2af7
    2b33:	0e                   	push   cs
    2b34:	50                   	push   ax
    2b35:	55                   	push   bp
    2b36:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2b3a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2b3e:	68 00 10             	push   0x1000
    2b41:	9a 82 01 a3 2c       	call   0x2ca3:0x182
    2b46:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2b49:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2b4c:	b8 f1 2a             	mov    ax,0x2af1
    2b4f:	0e                   	push   cs
    2b50:	50                   	push   ax
    2b51:	55                   	push   bp
    2b52:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2b56:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2b5a:	bf e6 16             	mov    di,0x16e6
    2b5d:	1e                   	push   ds
    2b5e:	57                   	push   di
    2b5f:	6a 00                	push   0x0
    2b61:	6a 00                	push   0x0
    2b63:	bf ed 16             	mov    di,0x16ed
    2b66:	1e                   	push   ds
    2b67:	57                   	push   di
    2b68:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2b6b:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2b6e:	68 00 10             	push   0x1000
    2b71:	9a ab 2b 00 00       	call   0x0:0x2bab
    2b76:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2b79:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    2b7c:	89 86 50 ff          	mov    WORD PTR [bp-0xb0],ax
    2b80:	89 96 52 ff          	mov    WORD PTR [bp-0xae],dx
    2b84:	c4 be 50 ff          	les    di,DWORD PTR [bp-0xb0]
    2b88:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2b8c:	75 03                	jne    0x2b91
    2b8e:	e9 fa 00             	jmp    0x2c8b
    2b91:	bf e6 16             	mov    di,0x16e6
    2b94:	1e                   	push   ds
    2b95:	57                   	push   di
    2b96:	ff b6 52 ff          	push   WORD PTR [bp-0xae]
    2b9a:	ff b6 50 ff          	push   WORD PTR [bp-0xb0]
    2b9e:	bf ed 16             	mov    di,0x16ed
    2ba1:	1e                   	push   ds
    2ba2:	57                   	push   di
    2ba3:	8d 7e a4             	lea    di,[bp-0x5c]
    2ba6:	16                   	push   ss
    2ba7:	57                   	push   di
    2ba8:	6a 50                	push   0x50
    2baa:	9a 4a 2d 00 00       	call   0x0:0x2d4a
    2baf:	8d 46 a4             	lea    ax,[bp-0x5c]
    2bb2:	8c d2                	mov    dx,ss
    2bb4:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    2bb7:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    2bba:	8d 7e f4             	lea    di,[bp-0xc]
    2bbd:	16                   	push   ss
    2bbe:	57                   	push   di
    2bbf:	e8 11 ef             	call   0x1ad3
    2bc2:	89 86 4c ff          	mov    WORD PTR [bp-0xb4],ax
    2bc6:	89 96 4e ff          	mov    WORD PTR [bp-0xb2],dx
    2bca:	8d 7e f4             	lea    di,[bp-0xc]
    2bcd:	16                   	push   ss
    2bce:	57                   	push   di
    2bcf:	e8 01 ef             	call   0x1ad3
    2bd2:	89 86 48 ff          	mov    WORD PTR [bp-0xb8],ax
    2bd6:	89 96 4a ff          	mov    WORD PTR [bp-0xb6],dx
    2bda:	c4 be 48 ff          	les    di,DWORD PTR [bp-0xb8]
    2bde:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    2be2:	75 03                	jne    0x2be7
    2be4:	e9 8f 00             	jmp    0x2c76
    2be7:	8d be 38 fe          	lea    di,[bp-0x1c8]
    2beb:	16                   	push   ss
    2bec:	57                   	push   di
    2bed:	bf e8 2a             	mov    di,0x2ae8
    2bf0:	0e                   	push   cs
    2bf1:	57                   	push   di
    2bf2:	8b 86 50 ff          	mov    ax,WORD PTR [bp-0xb0]
    2bf6:	8b 96 52 ff          	mov    dx,WORD PTR [bp-0xae]
    2bfa:	89 86 38 ff          	mov    WORD PTR [bp-0xc8],ax
    2bfe:	89 96 3a ff          	mov    WORD PTR [bp-0xc6],dx
    2c02:	c6 86 3c ff 06       	mov    BYTE PTR [bp-0xc4],0x6
    2c07:	8b 86 48 ff          	mov    ax,WORD PTR [bp-0xb8]
    2c0b:	8b 96 4a ff          	mov    dx,WORD PTR [bp-0xb6]
    2c0f:	89 86 40 ff          	mov    WORD PTR [bp-0xc0],ax
    2c13:	89 96 42 ff          	mov    WORD PTR [bp-0xbe],dx
    2c17:	c6 86 44 ff 06       	mov    BYTE PTR [bp-0xbc],0x6
    2c1c:	8d be 38 ff          	lea    di,[bp-0xc8]
    2c20:	16                   	push   ss
    2c21:	57                   	push   di
    2c22:	6a 01                	push   0x1
    2c24:	9a 34 10 81 2c       	call   0x2c81:0x1034
    2c29:	ff b6 4e ff          	push   WORD PTR [bp-0xb2]
    2c2d:	ff b6 4c ff          	push   WORD PTR [bp-0xb4]
    2c31:	ff b6 52 ff          	push   WORD PTR [bp-0xae]
    2c35:	ff b6 50 ff          	push   WORD PTR [bp-0xb0]
    2c39:	ff b6 4a ff          	push   WORD PTR [bp-0xb6]
    2c3d:	ff b6 48 ff          	push   WORD PTR [bp-0xb8]
    2c41:	b0 01                	mov    al,0x1
    2c43:	50                   	push   ax
    2c44:	b8 af 20             	mov    ax,0x20af
    2c47:	ba 4f 2c             	mov    dx,0x2c4f
    2c4a:	52                   	push   dx
    2c4b:	50                   	push   ax
    2c4c:	9a be 20 81 2d       	call   0x2d81:0x20be
    2c51:	52                   	push   dx
    2c52:	50                   	push   ax
    2c53:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c56:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    2c5a:	06                   	push   es
    2c5b:	57                   	push   di
    2c5c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2c5f:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    2c63:	8d 7e f4             	lea    di,[bp-0xc]
    2c66:	16                   	push   ss
    2c67:	57                   	push   di
    2c68:	e8 68 ee             	call   0x1ad3
    2c6b:	89 86 48 ff          	mov    WORD PTR [bp-0xb8],ax
    2c6f:	89 96 4a ff          	mov    WORD PTR [bp-0xb6],dx
    2c73:	e9 64 ff             	jmp    0x2bda
    2c76:	ff b6 52 ff          	push   WORD PTR [bp-0xae]
    2c7a:	ff b6 50 ff          	push   WORD PTR [bp-0xb0]
    2c7e:	9a 8c 0c 08 2d       	call   0x2d08:0xc8c
    2c83:	40                   	inc    ax
    2c84:	01 86 50 ff          	add    WORD PTR [bp-0xb0],ax
    2c88:	e9 f9 fe             	jmp    0x2b84
    2c8b:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2c8f:	83 c4 06             	add    sp,0x6
    2c92:	b8 a6 2c             	mov    ax,0x2ca6
    2c95:	0e                   	push   cs
    2c96:	50                   	push   ax
    2c97:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2c9a:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2c9d:	68 00 10             	push   0x1000
    2ca0:	9a 9c 01 bb 2c       	call   0x2cbb:0x19c
    2ca5:	cb                   	retf
    2ca6:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2caa:	83 c4 06             	add    sp,0x6
    2cad:	eb 25                	jmp    0x2cd4
    2caf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cb2:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    2cb6:	06                   	push   es
    2cb7:	57                   	push   di
    2cb8:	9a 7f 1f cd 2c       	call   0x2ccd:0x1f7f
    2cbd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cc0:	31 c0                	xor    ax,ax
    2cc2:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    2cc6:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    2cca:	ea 85 13 d2 2c       	jmp    0x2cd2:0x1385
    2ccf:	9a 34 14 29 2d       	call   0x2d29:0x1434
    2cd4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2cd7:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    2cdb:	26 8b 55 10          	mov    dx,WORD PTR es:[di+0x10]
    2cdf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2ce2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2ce5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2ce8:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2ceb:	c9                   	leave
    2cec:	ca 04 00             	retf   0x4
    2cef:	00 55 89             	add    BYTE PTR [di-0x77],dl
    2cf2:	e5 c4                	in     ax,0xc4
    2cf4:	7e 06                	jle    0x2cfc
    2cf6:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    2cfa:	26 0b 45 16          	or     ax,WORD PTR es:[di+0x16]
    2cfe:	75 15                	jne    0x2d15
    2d00:	bf ef 2c             	mov    di,0x2cef
    2d03:	0e                   	push   cs
    2d04:	57                   	push   di
    2d05:	9a d7 05 54 2e       	call   0x2e54:0x5d7
    2d0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d0d:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    2d11:	26 89 55 16          	mov    WORD PTR es:[di+0x16],dx
    2d15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d18:	26 c4 7d 14          	les    di,DWORD PTR es:[di+0x14]
    2d1c:	06                   	push   es
    2d1d:	57                   	push   di
    2d1e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2d21:	06                   	push   es
    2d22:	57                   	push   di
    2d23:	68 ff 00             	push   0xff
    2d26:	9a e7 17 d4 2d       	call   0x2dd4:0x17e7
    2d2b:	c9                   	leave
    2d2c:	ca 04 00             	retf   0x4
    2d2f:	c8 64 00 00          	enter  0x64,0x0
    2d33:	bf ee 16             	mov    di,0x16ee
    2d36:	1e                   	push   ds
    2d37:	57                   	push   di
    2d38:	bf f6 16             	mov    di,0x16f6
    2d3b:	1e                   	push   ds
    2d3c:	57                   	push   di
    2d3d:	bf f5 16             	mov    di,0x16f5
    2d40:	1e                   	push   ds
    2d41:	57                   	push   di
    2d42:	8d 7e ac             	lea    di,[bp-0x54]
    2d45:	16                   	push   ss
    2d46:	57                   	push   di
    2d47:	6a 4f                	push   0x4f
    2d49:	9a ff ff 00 00       	call   0x0:0xffff
    2d4e:	8d 46 ac             	lea    ax,[bp-0x54]
    2d51:	8c d2                	mov    dx,ss
    2d53:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
    2d56:	89 56 aa             	mov    WORD PTR [bp-0x56],dx
    2d59:	8d 7e a8             	lea    di,[bp-0x58]
    2d5c:	16                   	push   ss
    2d5d:	57                   	push   di
    2d5e:	e8 72 ed             	call   0x1ad3
    2d61:	52                   	push   dx
    2d62:	50                   	push   ax
    2d63:	8d 7e a8             	lea    di,[bp-0x58]
    2d66:	16                   	push   ss
    2d67:	57                   	push   di
    2d68:	e8 68 ed             	call   0x1ad3
    2d6b:	52                   	push   dx
    2d6c:	50                   	push   ax
    2d6d:	8d 7e a8             	lea    di,[bp-0x58]
    2d70:	16                   	push   ss
    2d71:	57                   	push   di
    2d72:	e8 5e ed             	call   0x1ad3
    2d75:	52                   	push   dx
    2d76:	50                   	push   ax
    2d77:	6a 00                	push   0x0
    2d79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d7c:	06                   	push   es
    2d7d:	57                   	push   di
    2d7e:	9a 67 27 39 2e       	call   0x2e39:0x2767
    2d83:	c9                   	leave
    2d84:	ca 04 00             	retf   0x4
    2d87:	c8 04 00 00          	enter  0x4,0x0
    2d8b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d8e:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    2d92:	26 0b 45 10          	or     ax,WORD PTR es:[di+0x10]
    2d96:	74 61                	je     0x2df9
    2d98:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    2d9c:	06                   	push   es
    2d9d:	57                   	push   di
    2d9e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2da1:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    2da5:	48                   	dec    ax
    2da6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2da9:	31 c0                	xor    ax,ax
    2dab:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2dae:	7f 2e                	jg     0x2dde
    2db0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2db3:	eb 03                	jmp    0x2db8
    2db5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2db8:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2dbb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dbe:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    2dc2:	06                   	push   es
    2dc3:	57                   	push   di
    2dc4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2dc7:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    2dcb:	89 c7                	mov    di,ax
    2dcd:	8e c2                	mov    es,dx
    2dcf:	06                   	push   es
    2dd0:	57                   	push   di
    2dd1:	9a 7f 1f ea 2d       	call   0x2dea:0x1f7f
    2dd6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2dd9:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2ddc:	75 d7                	jne    0x2db5
    2dde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2de1:	26 c4 7d 0e          	les    di,DWORD PTR es:[di+0xe]
    2de5:	06                   	push   es
    2de6:	57                   	push   di
    2de7:	9a 7f 1f 0c 2e       	call   0x2e0c:0x1f7f
    2dec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2def:	31 c0                	xor    ax,ax
    2df1:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    2df5:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    2df9:	c9                   	leave
    2dfa:	ca 04 00             	retf   0x4
    2dfd:	55                   	push   bp
    2dfe:	89 e5                	mov    bp,sp
    2e00:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e03:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    2e07:	06                   	push   es
    2e08:	57                   	push   di
    2e09:	9a 7f 1f 2b 2e       	call   0x2e2b:0x1f7f
    2e0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e11:	31 c0                	xor    ax,ax
    2e13:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2e17:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    2e1b:	c9                   	leave
    2e1c:	ca 04 00             	retf   0x4
    2e1f:	55                   	push   bp
    2e20:	89 e5                	mov    bp,sp
    2e22:	c4 3e 54 2c          	les    di,DWORD PTR ds:0x2c54
    2e26:	06                   	push   es
    2e27:	57                   	push   di
    2e28:	9a 7f 1f ff ff       	call   0xffff:0x1f7f
    2e2d:	c9                   	leave
    2e2e:	cb                   	retf
    2e2f:	55                   	push   bp
    2e30:	89 e5                	mov    bp,sp
    2e32:	b0 01                	mov    al,0x1
    2e34:	50                   	push   ax
    2e35:	b8 ca 1a             	mov    ax,0x1aca
    2e38:	ba 40 2e             	mov    dx,0x2e40
    2e3b:	52                   	push   dx
    2e3c:	50                   	push   ax
    2e3d:	9a 6e 23 4d 2e       	call   0x2e4d:0x236e
    2e42:	a3 54 2c             	mov    ds:0x2c54,ax
    2e45:	89 16 56 2c          	mov    WORD PTR ds:0x2c56,dx
    2e49:	bf 1f 2e             	mov    di,0x2e1f
    2e4c:	b8 ff ff             	mov    ax,0xffff
    2e4f:	50                   	push   ax
    2e50:	57                   	push   di
    2e51:	9a 74 05 ff ff       	call   0xffff:0x574
    2e56:	c9                   	leave
    2e57:	cb                   	retf
