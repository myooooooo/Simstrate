; seg02_CODE - Simstra1.dll (module de licence) - x86 16 bits

Disassembly of section .data:

00000000 <.data>:
       0:	02 00                	add    al,BYTE PTR [bx+si]
	...
       a:	22 00                	and    al,BYTE PTR [bx+si]
       c:	0c 00                	or     al,0x0
       e:	ff                   	(bad)
       f:	ff 00                	inc    WORD PTR [bx+si]
      11:	00 ff                	add    bh,bh
      13:	ff 00                	inc    WORD PTR [bx+si]
      15:	00 ff                	add    bh,bh
      17:	ff 00                	inc    WORD PTR [bx+si]
      19:	00 ff                	add    bh,bh
      1b:	ff 00                	inc    WORD PTR [bx+si]
      1d:	00 ff                	add    bh,bh
      1f:	ff 00                	inc    WORD PTR [bx+si]
      21:	00 09                	add    BYTE PTR [bx+di],cl
      23:	45                   	inc    bp
      24:	78 63                	js     0x89
      26:	65 70 74             	gs jo  0x9d
      29:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
      2e:	00 00                	add    BYTE PTR [bx+si],al
      30:	00 00                	add    BYTE PTR [bx+si],al
      32:	00 00                	add    BYTE PTR [bx+si],al
      34:	4c                   	dec    sp
      35:	00 0c                	add    BYTE PTR [si],cl
      37:	00 ff                	add    bh,bh
      39:	ff 00                	inc    WORD PTR [bx+si]
      3b:	00 ff                	add    bh,bh
      3d:	ff 00                	inc    WORD PTR [bx+si]
      3f:	00 ff                	add    bh,bh
      41:	ff 00                	inc    WORD PTR [bx+si]
      43:	00 ff                	add    bh,bh
      45:	ff 00                	inc    WORD PTR [bx+si]
      47:	00 ff                	add    bh,bh
      49:	ff 00                	inc    WORD PTR [bx+si]
      4b:	00 0c                	add    BYTE PTR [si],cl
      4d:	45                   	inc    bp
      4e:	4f                   	dec    di
      4f:	75 74                	jne    0xc5
      51:	4f                   	dec    di
      52:	66 4d                	dec    ebp
      54:	65 6d                	gs ins WORD PTR es:[di],dx
      56:	6f                   	outs   dx,WORD PTR ds:[si]
      57:	72 79                	jb     0xd2
	...
      61:	79 00                	jns    0x63
      63:	0e                   	push   cs
      64:	00 ff                	add    bh,bh
      66:	ff 00                	inc    WORD PTR [bx+si]
      68:	00 ff                	add    bh,bh
      6a:	ff 00                	inc    WORD PTR [bx+si]
      6c:	00 ff                	add    bh,bh
      6e:	ff 00                	inc    WORD PTR [bx+si]
      70:	00 ff                	add    bh,bh
      72:	ff 00                	inc    WORD PTR [bx+si]
      74:	00 ff                	add    bh,bh
      76:	ff 00                	inc    WORD PTR [bx+si]
      78:	00 0b                	add    BYTE PTR [bp+di],cl
      7a:	45                   	inc    bp
      7b:	49                   	dec    cx
      7c:	6e                   	outs   dx,BYTE PTR ds:[si]
      7d:	4f                   	dec    di
      7e:	75 74                	jne    0xf4
      80:	45                   	inc    bp
      81:	72 72                	jb     0xf5
      83:	6f                   	outs   dx,WORD PTR ds:[si]
      84:	72 00                	jb     0x86
      86:	00 00                	add    BYTE PTR [bx+si],al
      88:	00 00                	add    BYTE PTR [bx+si],al
      8a:	00 00                	add    BYTE PTR [bx+si],al
      8c:	00 a5 00 0c          	add    BYTE PTR [di+0xc00],ah
      90:	00 ff                	add    bh,bh
      92:	ff 00                	inc    WORD PTR [bx+si]
      94:	00 ff                	add    bh,bh
      96:	ff 00                	inc    WORD PTR [bx+si]
      98:	00 ff                	add    bh,bh
      9a:	ff 00                	inc    WORD PTR [bx+si]
      9c:	00 ff                	add    bh,bh
      9e:	ff 00                	inc    WORD PTR [bx+si]
      a0:	00 ff                	add    bh,bh
      a2:	ff 00                	inc    WORD PTR [bx+si]
      a4:	00 09                	add    BYTE PTR [bx+di],cl
      a6:	45                   	inc    bp
      a7:	49                   	dec    cx
      a8:	6e                   	outs   dx,BYTE PTR ds:[si]
      a9:	74 45                	je     0xf0
      ab:	72 72                	jb     0x11f
      ad:	6f                   	outs   dx,WORD PTR ds:[si]
      ae:	72 00                	jb     0xb0
      b0:	00 00                	add    BYTE PTR [bx+si],al
      b2:	00 00                	add    BYTE PTR [bx+si],al
      b4:	00 00                	add    BYTE PTR [bx+si],al
      b6:	00 cf                	add    bh,cl
      b8:	00 0c                	add    BYTE PTR [si],cl
      ba:	00 ff                	add    bh,bh
      bc:	ff 00                	inc    WORD PTR [bx+si]
      be:	00 ff                	add    bh,bh
      c0:	ff 00                	inc    WORD PTR [bx+si]
      c2:	00 ff                	add    bh,bh
      c4:	ff 00                	inc    WORD PTR [bx+si]
      c6:	00 ff                	add    bh,bh
      c8:	ff 00                	inc    WORD PTR [bx+si]
      ca:	00 ff                	add    bh,bh
      cc:	ff 00                	inc    WORD PTR [bx+si]
      ce:	00 0a                	add    BYTE PTR [bp+si],cl
      d0:	45                   	inc    bp
      d1:	44                   	inc    sp
      d2:	69 76 42 79 5a       	imul   si,WORD PTR [bp+0x42],0x5a79
      d7:	65 72 6f             	gs jb  0x149
	...
      e2:	fa                   	cli
      e3:	00 0c                	add    BYTE PTR [si],cl
      e5:	00 ff                	add    bh,bh
      e7:	ff 00                	inc    WORD PTR [bx+si]
      e9:	00 ff                	add    bh,bh
      eb:	ff 00                	inc    WORD PTR [bx+si]
      ed:	00 ff                	add    bh,bh
      ef:	ff 00                	inc    WORD PTR [bx+si]
      f1:	00 ff                	add    bh,bh
      f3:	ff 00                	inc    WORD PTR [bx+si]
      f5:	00 ff                	add    bh,bh
      f7:	ff 00                	inc    WORD PTR [bx+si]
      f9:	00 0b                	add    BYTE PTR [bp+di],cl
      fb:	45                   	inc    bp
      fc:	52                   	push   dx
      fd:	61                   	popa
      fe:	6e                   	outs   dx,BYTE PTR ds:[si]
      ff:	67 65 45             	addr32 gs inc bp
     102:	72 72                	jb     0x176
     104:	6f                   	outs   dx,WORD PTR ds:[si]
     105:	72 00                	jb     0x107
     107:	00 00                	add    BYTE PTR [bx+si],al
     109:	00 00                	add    BYTE PTR [bx+si],al
     10b:	00 00                	add    BYTE PTR [bx+si],al
     10d:	00 26 01 0c          	add    BYTE PTR ds:0xc01,ah
     111:	00 ff                	add    bh,bh
     113:	ff 00                	inc    WORD PTR [bx+si]
     115:	00 ff                	add    bh,bh
     117:	ff 00                	inc    WORD PTR [bx+si]
     119:	00 ff                	add    bh,bh
     11b:	ff 00                	inc    WORD PTR [bx+si]
     11d:	00 ff                	add    bh,bh
     11f:	ff 00                	inc    WORD PTR [bx+si]
     121:	00 ff                	add    bh,bh
     123:	ff 00                	inc    WORD PTR [bx+si]
     125:	00 0c                	add    BYTE PTR [si],cl
     127:	45                   	inc    bp
     128:	49                   	dec    cx
     129:	6e                   	outs   dx,BYTE PTR ds:[si]
     12a:	74 4f                	je     0x17b
     12c:	76 65                	jbe    0x193
     12e:	72 66                	jb     0x196
     130:	6c                   	ins    BYTE PTR es:[di],dx
     131:	6f                   	outs   dx,WORD PTR ds:[si]
     132:	77 00                	ja     0x134
     134:	00 00                	add    BYTE PTR [bx+si],al
     136:	00 00                	add    BYTE PTR [bx+si],al
     138:	00 00                	add    BYTE PTR [bx+si],al
     13a:	00 53 01             	add    BYTE PTR [bp+di+0x1],dl
     13d:	0c 00                	or     al,0x0
     13f:	ff                   	(bad)
     140:	ff 00                	inc    WORD PTR [bx+si]
     142:	00 ff                	add    bh,bh
     144:	ff 00                	inc    WORD PTR [bx+si]
     146:	00 ff                	add    bh,bh
     148:	ff 00                	inc    WORD PTR [bx+si]
     14a:	00 ff                	add    bh,bh
     14c:	ff 00                	inc    WORD PTR [bx+si]
     14e:	00 ff                	add    bh,bh
     150:	ff 00                	inc    WORD PTR [bx+si]
     152:	00 0a                	add    BYTE PTR [bp+si],cl
     154:	45                   	inc    bp
     155:	4d                   	dec    bp
     156:	61                   	popa
     157:	74 68                	je     0x1c1
     159:	45                   	inc    bp
     15a:	72 72                	jb     0x1ce
     15c:	6f                   	outs   dx,WORD PTR ds:[si]
     15d:	72 00                	jb     0x15f
     15f:	00 00                	add    BYTE PTR [bx+si],al
     161:	00 00                	add    BYTE PTR [bx+si],al
     163:	00 00                	add    BYTE PTR [bx+si],al
     165:	00 7e 01             	add    BYTE PTR [bp+0x1],bh
     168:	0c 00                	or     al,0x0
     16a:	ff                   	(bad)
     16b:	ff 00                	inc    WORD PTR [bx+si]
     16d:	00 ff                	add    bh,bh
     16f:	ff 00                	inc    WORD PTR [bx+si]
     171:	00 ff                	add    bh,bh
     173:	ff 00                	inc    WORD PTR [bx+si]
     175:	00 ff                	add    bh,bh
     177:	ff 00                	inc    WORD PTR [bx+si]
     179:	00 ff                	add    bh,bh
     17b:	ff 00                	inc    WORD PTR [bx+si]
     17d:	00 0a                	add    BYTE PTR [bp+si],cl
     17f:	45                   	inc    bp
     180:	49                   	dec    cx
     181:	6e                   	outs   dx,BYTE PTR ds:[si]
     182:	76 61                	jbe    0x1e5
     184:	6c                   	ins    BYTE PTR es:[di],dx
     185:	69 64 4f 70 00       	imul   sp,WORD PTR [si+0x4f],0x70
     18a:	00 00                	add    BYTE PTR [bx+si],al
     18c:	00 00                	add    BYTE PTR [bx+si],al
     18e:	00 00                	add    BYTE PTR [bx+si],al
     190:	00 a9 01 0c          	add    BYTE PTR [bx+di+0xc01],ch
     194:	00 ff                	add    bh,bh
     196:	ff 00                	inc    WORD PTR [bx+si]
     198:	00 ff                	add    bh,bh
     19a:	ff 00                	inc    WORD PTR [bx+si]
     19c:	00 ff                	add    bh,bh
     19e:	ff 00                	inc    WORD PTR [bx+si]
     1a0:	00 ff                	add    bh,bh
     1a2:	ff 00                	inc    WORD PTR [bx+si]
     1a4:	00 ff                	add    bh,bh
     1a6:	ff 00                	inc    WORD PTR [bx+si]
     1a8:	00 0b                	add    BYTE PTR [bp+di],cl
     1aa:	45                   	inc    bp
     1ab:	5a                   	pop    dx
     1ac:	65 72 6f             	gs jb  0x21e
     1af:	44                   	inc    sp
     1b0:	69 76 69 64 65       	imul   si,WORD PTR [bp+0x69],0x6564
	...
     1bd:	d5 01                	aad    0x1
     1bf:	0c 00                	or     al,0x0
     1c1:	ff                   	(bad)
     1c2:	ff 00                	inc    WORD PTR [bx+si]
     1c4:	00 ff                	add    bh,bh
     1c6:	ff 00                	inc    WORD PTR [bx+si]
     1c8:	00 ff                	add    bh,bh
     1ca:	ff 00                	inc    WORD PTR [bx+si]
     1cc:	00 ff                	add    bh,bh
     1ce:	ff 00                	inc    WORD PTR [bx+si]
     1d0:	00 ff                	add    bh,bh
     1d2:	ff 00                	inc    WORD PTR [bx+si]
     1d4:	00 09                	add    BYTE PTR [bx+di],cl
     1d6:	45                   	inc    bp
     1d7:	4f                   	dec    di
     1d8:	76 65                	jbe    0x23f
     1da:	72 66                	jb     0x242
     1dc:	6c                   	ins    BYTE PTR es:[di],dx
     1dd:	6f                   	outs   dx,WORD PTR ds:[si]
     1de:	77 00                	ja     0x1e0
     1e0:	00 00                	add    BYTE PTR [bx+si],al
     1e2:	00 00                	add    BYTE PTR [bx+si],al
     1e4:	00 00                	add    BYTE PTR [bx+si],al
     1e6:	00 ff                	add    bh,bh
     1e8:	01 0c                	add    WORD PTR [si],cx
     1ea:	00 ff                	add    bh,bh
     1ec:	ff 00                	inc    WORD PTR [bx+si]
     1ee:	00 ff                	add    bh,bh
     1f0:	ff 00                	inc    WORD PTR [bx+si]
     1f2:	00 ff                	add    bh,bh
     1f4:	ff 00                	inc    WORD PTR [bx+si]
     1f6:	00 ff                	add    bh,bh
     1f8:	ff 00                	inc    WORD PTR [bx+si]
     1fa:	00 ff                	add    bh,bh
     1fc:	ff 00                	inc    WORD PTR [bx+si]
     1fe:	00 0a                	add    BYTE PTR [bp+si],cl
     200:	45                   	inc    bp
     201:	55                   	push   bp
     202:	6e                   	outs   dx,BYTE PTR ds:[si]
     203:	64 65 72 66          	fs gs jb 0x26d
     207:	6c                   	ins    BYTE PTR es:[di],dx
     208:	6f                   	outs   dx,WORD PTR ds:[si]
     209:	77 00                	ja     0x20b
     20b:	00 00                	add    BYTE PTR [bx+si],al
     20d:	00 00                	add    BYTE PTR [bx+si],al
     20f:	00 00                	add    BYTE PTR [bx+si],al
     211:	00 2a                	add    BYTE PTR [bp+si],ch
     213:	02 0c                	add    cl,BYTE PTR [si]
     215:	00 ff                	add    bh,bh
     217:	ff 00                	inc    WORD PTR [bx+si]
     219:	00 ff                	add    bh,bh
     21b:	ff 00                	inc    WORD PTR [bx+si]
     21d:	00 ff                	add    bh,bh
     21f:	ff 00                	inc    WORD PTR [bx+si]
     221:	00 ff                	add    bh,bh
     223:	ff 00                	inc    WORD PTR [bx+si]
     225:	00 ff                	add    bh,bh
     227:	ff 00                	inc    WORD PTR [bx+si]
     229:	00 0f                	add    BYTE PTR [bx],cl
     22b:	45                   	inc    bp
     22c:	49                   	dec    cx
     22d:	6e                   	outs   dx,BYTE PTR ds:[si]
     22e:	76 61                	jbe    0x291
     230:	6c                   	ins    BYTE PTR es:[di],dx
     231:	69 64 50 6f 69       	imul   sp,WORD PTR [si+0x50],0x696f
     236:	6e                   	outs   dx,BYTE PTR ds:[si]
     237:	74 65                	je     0x29e
     239:	72 00                	jb     0x23b
     23b:	00 00                	add    BYTE PTR [bx+si],al
     23d:	00 00                	add    BYTE PTR [bx+si],al
     23f:	00 00                	add    BYTE PTR [bx+si],al
     241:	00 5a 02             	add    BYTE PTR [bp+si+0x2],bl
     244:	0c 00                	or     al,0x0
     246:	ff                   	(bad)
     247:	ff 00                	inc    WORD PTR [bx+si]
     249:	00 ff                	add    bh,bh
     24b:	ff 00                	inc    WORD PTR [bx+si]
     24d:	00 ff                	add    bh,bh
     24f:	ff 00                	inc    WORD PTR [bx+si]
     251:	00 ff                	add    bh,bh
     253:	ff 00                	inc    WORD PTR [bx+si]
     255:	00 ff                	add    bh,bh
     257:	ff 00                	inc    WORD PTR [bx+si]
     259:	00 0c                	add    BYTE PTR [si],cl
     25b:	45                   	inc    bp
     25c:	49                   	dec    cx
     25d:	6e                   	outs   dx,BYTE PTR ds:[si]
     25e:	76 61                	jbe    0x2c1
     260:	6c                   	ins    BYTE PTR es:[di],dx
     261:	69 64 43 61 73       	imul   sp,WORD PTR [si+0x43],0x7361
     266:	74 00                	je     0x268
     268:	00 00                	add    BYTE PTR [bx+si],al
     26a:	00 00                	add    BYTE PTR [bx+si],al
     26c:	00 00                	add    BYTE PTR [bx+si],al
     26e:	00 87 02 0c          	add    BYTE PTR [bx+0xc02],al
     272:	00 ff                	add    bh,bh
     274:	ff 00                	inc    WORD PTR [bx+si]
     276:	00 ff                	add    bh,bh
     278:	ff 00                	inc    WORD PTR [bx+si]
     27a:	00 ff                	add    bh,bh
     27c:	ff 00                	inc    WORD PTR [bx+si]
     27e:	00 ff                	add    bh,bh
     280:	ff 00                	inc    WORD PTR [bx+si]
     282:	00 ff                	add    bh,bh
     284:	ff 00                	inc    WORD PTR [bx+si]
     286:	00 0d                	add    BYTE PTR [di],cl
     288:	45                   	inc    bp
     289:	43                   	inc    bx
     28a:	6f                   	outs   dx,WORD PTR ds:[si]
     28b:	6e                   	outs   dx,BYTE PTR ds:[si]
     28c:	76 65                	jbe    0x2f3
     28e:	72 74                	jb     0x304
     290:	45                   	inc    bp
     291:	72 72                	jb     0x305
     293:	6f                   	outs   dx,WORD PTR ds:[si]
     294:	72 00                	jb     0x296
     296:	00 00                	add    BYTE PTR [bx+si],al
     298:	00 00                	add    BYTE PTR [bx+si],al
     29a:	00 00                	add    BYTE PTR [bx+si],al
     29c:	00 b5 02 0c          	add    BYTE PTR [di+0xc02],dh
     2a0:	00 ff                	add    bh,bh
     2a2:	ff 00                	inc    WORD PTR [bx+si]
     2a4:	00 ff                	add    bh,bh
     2a6:	ff 00                	inc    WORD PTR [bx+si]
     2a8:	00 ff                	add    bh,bh
     2aa:	ff 00                	inc    WORD PTR [bx+si]
     2ac:	00 ff                	add    bh,bh
     2ae:	ff 00                	inc    WORD PTR [bx+si]
     2b0:	00 ff                	add    bh,bh
     2b2:	ff 00                	inc    WORD PTR [bx+si]
     2b4:	00 13                	add    BYTE PTR [bp+di],dl
     2b6:	45                   	inc    bp
     2b7:	50                   	push   ax
     2b8:	72 6f                	jb     0x329
     2ba:	63 65 73             	arpl   WORD PTR [di+0x73],sp
     2bd:	73 6f                	jae    0x32e
     2bf:	72 45                	jb     0x306
     2c1:	78 63                	js     0x326
     2c3:	65 70 74             	gs jo  0x33a
     2c6:	69 6f 6e 00 00       	imul   bp,WORD PTR [bx+0x6e],0x0
     2cb:	00 00                	add    BYTE PTR [bx+si],al
     2cd:	00 00                	add    BYTE PTR [bx+si],al
     2cf:	00 00                	add    BYTE PTR [bx+si],al
     2d1:	e9 02 0c             	jmp    0xed6
     2d4:	00 ff                	add    bh,bh
     2d6:	ff 00                	inc    WORD PTR [bx+si]
     2d8:	00 ff                	add    bh,bh
     2da:	ff 00                	inc    WORD PTR [bx+si]
     2dc:	00 ff                	add    bh,bh
     2de:	ff 00                	inc    WORD PTR [bx+si]
     2e0:	00 ff                	add    bh,bh
     2e2:	ff 00                	inc    WORD PTR [bx+si]
     2e4:	00 ff                	add    bh,bh
     2e6:	ff 00                	inc    WORD PTR [bx+si]
     2e8:	00 06 45 46          	add    BYTE PTR ds:0x4645,al
     2ec:	61                   	popa
     2ed:	75 6c                	jne    0x35b
     2ef:	74 00                	je     0x2f1
     2f1:	00 00                	add    BYTE PTR [bx+si],al
     2f3:	00 00                	add    BYTE PTR [bx+si],al
     2f5:	00 00                	add    BYTE PTR [bx+si],al
     2f7:	00 10                	add    BYTE PTR [bx+si],dl
     2f9:	03 0c                	add    cx,WORD PTR [si]
     2fb:	00 ff                	add    bh,bh
     2fd:	ff 00                	inc    WORD PTR [bx+si]
     2ff:	00 ff                	add    bh,bh
     301:	ff 00                	inc    WORD PTR [bx+si]
     303:	00 ff                	add    bh,bh
     305:	ff 00                	inc    WORD PTR [bx+si]
     307:	00 ff                	add    bh,bh
     309:	ff 00                	inc    WORD PTR [bx+si]
     30b:	00 ff                	add    bh,bh
     30d:	ff 00                	inc    WORD PTR [bx+si]
     30f:	00 08                	add    BYTE PTR [bx+si],cl
     311:	45                   	inc    bp
     312:	47                   	inc    di
     313:	50                   	push   ax
     314:	46                   	inc    si
     315:	61                   	popa
     316:	75 6c                	jne    0x384
     318:	74 00                	je     0x31a
     31a:	00 00                	add    BYTE PTR [bx+si],al
     31c:	00 00                	add    BYTE PTR [bx+si],al
     31e:	00 00                	add    BYTE PTR [bx+si],al
     320:	00 39                	add    BYTE PTR [bx+di],bh
     322:	03 0c                	add    cx,WORD PTR [si]
     324:	00 ff                	add    bh,bh
     326:	ff 00                	inc    WORD PTR [bx+si]
     328:	00 ff                	add    bh,bh
     32a:	ff 00                	inc    WORD PTR [bx+si]
     32c:	00 ff                	add    bh,bh
     32e:	ff 00                	inc    WORD PTR [bx+si]
     330:	00 ff                	add    bh,bh
     332:	ff 00                	inc    WORD PTR [bx+si]
     334:	00 ff                	add    bh,bh
     336:	ff 00                	inc    WORD PTR [bx+si]
     338:	00 0b                	add    BYTE PTR [bp+di],cl
     33a:	45                   	inc    bp
     33b:	53                   	push   bx
     33c:	74 61                	je     0x39f
     33e:	63 6b 46             	arpl   WORD PTR [bp+di+0x46],bp
     341:	61                   	popa
     342:	75 6c                	jne    0x3b0
     344:	74 00                	je     0x346
     346:	00 00                	add    BYTE PTR [bx+si],al
     348:	00 00                	add    BYTE PTR [bx+si],al
     34a:	00 00                	add    BYTE PTR [bx+si],al
     34c:	00 65 03             	add    BYTE PTR [di+0x3],ah
     34f:	0c 00                	or     al,0x0
     351:	ff                   	(bad)
     352:	ff 00                	inc    WORD PTR [bx+si]
     354:	00 ff                	add    bh,bh
     356:	ff 00                	inc    WORD PTR [bx+si]
     358:	00 ff                	add    bh,bh
     35a:	ff 00                	inc    WORD PTR [bx+si]
     35c:	00 ff                	add    bh,bh
     35e:	ff 00                	inc    WORD PTR [bx+si]
     360:	00 ff                	add    bh,bh
     362:	ff 00                	inc    WORD PTR [bx+si]
     364:	00 0a                	add    BYTE PTR [bp+si],cl
     366:	45                   	inc    bp
     367:	50                   	push   ax
     368:	61                   	popa
     369:	67 65 46             	addr32 gs inc si
     36c:	61                   	popa
     36d:	75 6c                	jne    0x3db
     36f:	74 00                	je     0x371
     371:	00 00                	add    BYTE PTR [bx+si],al
     373:	00 00                	add    BYTE PTR [bx+si],al
     375:	00 00                	add    BYTE PTR [bx+si],al
     377:	00 90 03 0c          	add    BYTE PTR [bx+si+0xc03],dl
     37b:	00 ff                	add    bh,bh
     37d:	ff 00                	inc    WORD PTR [bx+si]
     37f:	00 ff                	add    bh,bh
     381:	ff 00                	inc    WORD PTR [bx+si]
     383:	00 ff                	add    bh,bh
     385:	ff 00                	inc    WORD PTR [bx+si]
     387:	00 ff                	add    bh,bh
     389:	ff 00                	inc    WORD PTR [bx+si]
     38b:	00 ff                	add    bh,bh
     38d:	ff 00                	inc    WORD PTR [bx+si]
     38f:	00 0e 45 49          	add    BYTE PTR ds:0x4945,cl
     393:	6e                   	outs   dx,BYTE PTR ds:[si]
     394:	76 61                	jbe    0x3f7
     396:	6c                   	ins    BYTE PTR es:[di],dx
     397:	69 64 4f 70 43       	imul   sp,WORD PTR [si+0x4f],0x4370
     39c:	6f                   	outs   dx,WORD PTR ds:[si]
     39d:	64 65 00 00          	fs add BYTE PTR gs:[bx+si],al
     3a1:	00 00                	add    BYTE PTR [bx+si],al
     3a3:	00 00                	add    BYTE PTR [bx+si],al
     3a5:	00 00                	add    BYTE PTR [bx+si],al
     3a7:	bf 03 0c             	mov    di,0xc03
     3aa:	00 ff                	add    bh,bh
     3ac:	ff 00                	inc    WORD PTR [bx+si]
     3ae:	00 ff                	add    bh,bh
     3b0:	ff 00                	inc    WORD PTR [bx+si]
     3b2:	00 ff                	add    bh,bh
     3b4:	ff 00                	inc    WORD PTR [bx+si]
     3b6:	00 ff                	add    bh,bh
     3b8:	ff 00                	inc    WORD PTR [bx+si]
     3ba:	00 ff                	add    bh,bh
     3bc:	ff 00                	inc    WORD PTR [bx+si]
     3be:	00 0b                	add    BYTE PTR [bp+di],cl
     3c0:	45                   	inc    bp
     3c1:	42                   	inc    dx
     3c2:	72 65                	jb     0x429
     3c4:	61                   	popa
     3c5:	6b 70 6f 69          	imul   si,WORD PTR [bx+si+0x6f],0x69
     3c9:	6e                   	outs   dx,BYTE PTR ds:[si]
     3ca:	74 00                	je     0x3cc
     3cc:	00 00                	add    BYTE PTR [bx+si],al
     3ce:	00 00                	add    BYTE PTR [bx+si],al
     3d0:	00 00                	add    BYTE PTR [bx+si],al
     3d2:	00 eb                	add    bl,ch
     3d4:	03 0c                	add    cx,WORD PTR [si]
     3d6:	00 ff                	add    bh,bh
     3d8:	ff 00                	inc    WORD PTR [bx+si]
     3da:	00 ff                	add    bh,bh
     3dc:	ff 00                	inc    WORD PTR [bx+si]
     3de:	00 ff                	add    bh,bh
     3e0:	ff 00                	inc    WORD PTR [bx+si]
     3e2:	00 ff                	add    bh,bh
     3e4:	ff 00                	inc    WORD PTR [bx+si]
     3e6:	00 ff                	add    bh,bh
     3e8:	ff 00                	inc    WORD PTR [bx+si]
     3ea:	00 0b                	add    BYTE PTR [bp+di],cl
     3ec:	45                   	inc    bp
     3ed:	53                   	push   bx
     3ee:	69 6e 67 6c 65       	imul   bp,WORD PTR [bp+0x67],0x656c
     3f3:	53                   	push   bx
     3f4:	74 65                	je     0x45b
     3f6:	70 55                	jo     0x44d
     3f8:	89 e5                	mov    bp,sp
     3fa:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     3fd:	06                   	push   es
     3fe:	57                   	push   di
     3ff:	b0 01                	mov    al,0x1
     401:	50                   	push   ax
     402:	b8 87 02             	mov    ax,0x287
     405:	ba ff ff             	mov    dx,0xffff
     408:	52                   	push   dx
     409:	50                   	push   ax
     40a:	9a ff ff 00 00       	call   0x0:0xffff
     40f:	52                   	push   dx
     410:	50                   	push   ax
     411:	9a ff ff 00 00       	call   0x0:0xffff
     416:	c9                   	leave
     417:	c2 04 00             	ret    0x4
     41a:	c8 04 00 00          	enter  0x4,0x0
     41e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     421:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
     425:	75 0f                	jne    0x436
     427:	a1 dc 09             	mov    ax,ds:0x9dc
     42a:	8b 16 de 09          	mov    dx,WORD PTR ds:0x9de
     42e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     431:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     434:	eb 27                	jmp    0x45d
     436:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     439:	26 8a 05             	mov    al,BYTE PTR es:[di]
     43c:	30 e4                	xor    ah,ah
     43e:	40                   	inc    ax
     43f:	50                   	push   ax
     440:	9a ff ff 00 00       	call   0x0:0xffff
     445:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     448:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     44b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     44e:	06                   	push   es
     44f:	57                   	push   di
     450:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     453:	06                   	push   es
     454:	57                   	push   di
     455:	68 ff 00             	push   0xff
     458:	9a ff ff 00 00       	call   0x0:0xffff
     45d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     460:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     463:	c9                   	leave
     464:	ca 04 00             	retf   0x4
     467:	55                   	push   bp
     468:	89 e5                	mov    bp,sp
     46a:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     46d:	0b 46 08             	or     ax,WORD PTR [bp+0x8]
     470:	74 1e                	je     0x490
     472:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     475:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
     479:	74 15                	je     0x490
     47b:	ff 76 08             	push   WORD PTR [bp+0x8]
     47e:	ff 76 06             	push   WORD PTR [bp+0x6]
     481:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     484:	26 8a 05             	mov    al,BYTE PTR es:[di]
     487:	30 e4                	xor    ah,ah
     489:	40                   	inc    ax
     48a:	50                   	push   ax
     48b:	9a ff ff 00 00       	call   0x0:0xffff
     490:	c9                   	leave
     491:	ca 04 00             	retf   0x4
     494:	55                   	push   bp
     495:	89 e5                	mov    bp,sp
     497:	ff 36 16 0b          	push   WORD PTR ds:0xb16
     49b:	ff 76 06             	push   WORD PTR [bp+0x6]
     49e:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     4a1:	81 c7 01 00          	add    di,0x1
     4a5:	06                   	push   es
     4a6:	57                   	push   di
     4a7:	68 fe 00             	push   0xfe
     4aa:	9a ff ff 00 00       	call   0x0:0xffff
     4af:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     4b2:	26 88 05             	mov    BYTE PTR es:[di],al
     4b5:	c9                   	leave
     4b6:	ca 02 00             	retf   0x2
     4b9:	c8 00 01 00          	enter  0x100,0x0
     4bd:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     4c0:	06                   	push   es
     4c1:	57                   	push   di
     4c2:	68 ff 00             	push   0xff
     4c5:	8d be 00 ff          	lea    di,[bp-0x100]
     4c9:	16                   	push   ss
     4ca:	57                   	push   di
     4cb:	ff 76 0c             	push   WORD PTR [bp+0xc]
     4ce:	9a ff ff 00 00       	call   0x0:0xffff
     4d3:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     4d6:	06                   	push   es
     4d7:	57                   	push   di
     4d8:	ff 76 06             	push   WORD PTR [bp+0x6]
     4db:	9a ff ff 00 00       	call   0x0:0xffff
     4e0:	c9                   	leave
     4e1:	ca 08 00             	retf   0x8
     4e4:	55                   	push   bp
     4e5:	89 e5                	mov    bp,sp
     4e7:	fc                   	cld
     4e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     4eb:	b9 ff ff             	mov    cx,0xffff
     4ee:	30 c0                	xor    al,al
     4f0:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     4f2:	b8 fe ff             	mov    ax,0xfffe
     4f5:	29 c8                	sub    ax,cx
     4f7:	c9                   	leave
     4f8:	ca 04 00             	retf   0x4
     4fb:	55                   	push   bp
     4fc:	89 e5                	mov    bp,sp
     4fe:	1e                   	push   ds
     4ff:	fc                   	cld
     500:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
     503:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     506:	89 f8                	mov    ax,di
     508:	8c c2                	mov    dx,es
     50a:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
     50d:	39 fe                	cmp    si,di
     50f:	73 07                	jae    0x518
     511:	fd                   	std
     512:	01 ce                	add    si,cx
     514:	01 cf                	add    di,cx
     516:	4e                   	dec    si
     517:	4f                   	dec    di
     518:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     51a:	fc                   	cld
     51b:	1f                   	pop    ds
     51c:	c9                   	leave
     51d:	ca 0a 00             	retf   0xa
     520:	55                   	push   bp
     521:	89 e5                	mov    bp,sp
     523:	1e                   	push   ds
     524:	fc                   	cld
     525:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     528:	b9 ff ff             	mov    cx,0xffff
     52b:	30 c0                	xor    al,al
     52d:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     52f:	f7 d1                	not    cx
     531:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     534:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     537:	89 f8                	mov    ax,di
     539:	8c c2                	mov    dx,es
     53b:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     53d:	1f                   	pop    ds
     53e:	c9                   	leave
     53f:	ca 08 00             	retf   0x8
     542:	55                   	push   bp
     543:	89 e5                	mov    bp,sp
     545:	1e                   	push   ds
     546:	fc                   	cld
     547:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     54a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     54d:	89 fb                	mov    bx,di
     54f:	8c c2                	mov    dx,es
     551:	ac                   	lods   al,BYTE PTR ds:[si]
     552:	30 e4                	xor    ah,ah
     554:	91                   	xchg   cx,ax
     555:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     557:	30 c0                	xor    al,al
     559:	aa                   	stos   BYTE PTR es:[di],al
     55a:	93                   	xchg   bx,ax
     55b:	1f                   	pop    ds
     55c:	c9                   	leave
     55d:	ca 08 00             	retf   0x8
     560:	55                   	push   bp
     561:	89 e5                	mov    bp,sp
     563:	fc                   	cld
     564:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     567:	b9 ff ff             	mov    cx,0xffff
     56a:	30 c0                	xor    al,al
     56c:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     56e:	f7 d1                	not    cx
     570:	fd                   	std
     571:	4f                   	dec    di
     572:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     575:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     577:	b8 00 00             	mov    ax,0x0
     57a:	99                   	cwd
     57b:	75 05                	jne    0x582
     57d:	89 f8                	mov    ax,di
     57f:	8c c2                	mov    dx,es
     581:	40                   	inc    ax
     582:	fc                   	cld
     583:	c9                   	leave
     584:	ca 06 00             	retf   0x6
     587:	55                   	push   bp
     588:	89 e5                	mov    bp,sp
     58a:	1e                   	push   ds
     58b:	fc                   	cld
     58c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     58f:	b9 00 01             	mov    cx,0x100
     592:	30 c0                	xor    al,al
     594:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     596:	f6 d1                	not    cl
     598:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
     59b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     59e:	88 c8                	mov    al,cl
     5a0:	aa                   	stos   BYTE PTR es:[di],al
     5a1:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     5a3:	1f                   	pop    ds
     5a4:	c9                   	leave
     5a5:	ca 04 00             	retf   0x4
     5a8:	c8 28 01 00          	enter  0x128,0x0
     5ac:	83 7e 04 1f          	cmp    WORD PTR [bp+0x4],0x1f
     5b0:	76 05                	jbe    0x5b7
     5b2:	c7 46 04 1f 00       	mov    WORD PTR [bp+0x4],0x1f
     5b7:	8d 7e e0             	lea    di,[bp-0x20]
     5ba:	16                   	push   ss
     5bb:	57                   	push   di
     5bc:	ff 76 08             	push   WORD PTR [bp+0x8]
     5bf:	ff 76 06             	push   WORD PTR [bp+0x6]
     5c2:	ff 76 04             	push   WORD PTR [bp+0x4]
     5c5:	9a ff ff 00 00       	call   0x0:0xffff
     5ca:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
     5cd:	c6 43 e0 00          	mov    BYTE PTR [bp+di-0x20],0x0
     5d1:	8d be d8 fe          	lea    di,[bp-0x128]
     5d5:	16                   	push   ss
     5d6:	57                   	push   di
     5d7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     5da:	99                   	cwd
     5db:	05 a5 ff             	add    ax,0xffa5
     5de:	83 d2 00             	adc    dx,0x0
     5e1:	50                   	push   ax
     5e2:	8d 46 e0             	lea    ax,[bp-0x20]
     5e5:	8c d2                	mov    dx,ss
     5e7:	89 46 d8             	mov    WORD PTR [bp-0x28],ax
     5ea:	89 56 da             	mov    WORD PTR [bp-0x26],dx
     5ed:	c6 46 dc 06          	mov    BYTE PTR [bp-0x24],0x6
     5f1:	8d 7e d8             	lea    di,[bp-0x28]
     5f4:	16                   	push   ss
     5f5:	57                   	push   di
     5f6:	6a 00                	push   0x0
     5f8:	9a ff ff 00 00       	call   0x0:0xffff
     5fd:	e8 f7 fd             	call   0x3f7
     600:	c9                   	leave
     601:	c2 08 00             	ret    0x8
     604:	c8 04 00 00          	enter  0x4,0x0
     608:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     60b:	06                   	push   es
     60c:	57                   	push   di
     60d:	6a ff                	push   0xffff
     60f:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     612:	06                   	push   es
     613:	57                   	push   di
     614:	ff 76 0e             	push   WORD PTR [bp+0xe]
     617:	ff 76 0c             	push   WORD PTR [bp+0xc]
     61a:	9a ff ff 00 00       	call   0x0:0xffff
     61f:	50                   	push   ax
     620:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     623:	06                   	push   es
     624:	57                   	push   di
     625:	ff 76 06             	push   WORD PTR [bp+0x6]
     628:	9a ff ff 00 00       	call   0x0:0xffff
     62d:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     630:	03 f8                	add    di,ax
     632:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
     636:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
     639:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
     63c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     63f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     642:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     645:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     648:	c9                   	leave
     649:	ca 0e 00             	retf   0xe
     64c:	55                   	push   bp
     64d:	89 e5                	mov    bp,sp
     64f:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     652:	81 c7 01 00          	add    di,0x1
     656:	06                   	push   es
     657:	57                   	push   di
     658:	68 ff 00             	push   0xff
     65b:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     65e:	81 c7 01 00          	add    di,0x1
     662:	06                   	push   es
     663:	57                   	push   di
     664:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     667:	26 8a 05             	mov    al,BYTE PTR es:[di]
     66a:	30 e4                	xor    ah,ah
     66c:	50                   	push   ax
     66d:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     670:	06                   	push   es
     671:	57                   	push   di
     672:	ff 76 06             	push   WORD PTR [bp+0x6]
     675:	9a ff ff 00 00       	call   0x0:0xffff
     67a:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
     67d:	26 88 05             	mov    BYTE PTR es:[di],al
     680:	c9                   	leave
     681:	ca 0a 00             	retf   0xa
     684:	55                   	push   bp
     685:	89 e5                	mov    bp,sp
     687:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
     68a:	81 c7 01 00          	add    di,0x1
     68e:	06                   	push   es
     68f:	57                   	push   di
     690:	ff 76 10             	push   WORD PTR [bp+0x10]
     693:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     696:	81 c7 01 00          	add    di,0x1
     69a:	06                   	push   es
     69b:	57                   	push   di
     69c:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     69f:	26 8a 05             	mov    al,BYTE PTR es:[di]
     6a2:	30 e4                	xor    ah,ah
     6a4:	50                   	push   ax
     6a5:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     6a8:	06                   	push   es
     6a9:	57                   	push   di
     6aa:	ff 76 06             	push   WORD PTR [bp+0x6]
     6ad:	9a ff ff 00 00       	call   0x0:0xffff
     6b2:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
     6b5:	26 88 05             	mov    BYTE PTR es:[di],al
     6b8:	c9                   	leave
     6b9:	ca 10 00             	retf   0x10
     6bc:	c8 00 01 00          	enter  0x100,0x0
     6c0:	ff 76 10             	push   WORD PTR [bp+0x10]
     6c3:	ff 76 0e             	push   WORD PTR [bp+0xe]
     6c6:	ff 76 0c             	push   WORD PTR [bp+0xc]
     6c9:	ff 76 0a             	push   WORD PTR [bp+0xa]
     6cc:	8d be 00 ff          	lea    di,[bp-0x100]
     6d0:	16                   	push   ss
     6d1:	57                   	push   di
     6d2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     6d5:	06                   	push   es
     6d6:	57                   	push   di
     6d7:	9a ff ff 00 00       	call   0x0:0xffff
     6dc:	52                   	push   dx
     6dd:	50                   	push   ax
     6de:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
     6e1:	81 c7 01 00          	add    di,0x1
     6e5:	06                   	push   es
     6e6:	57                   	push   di
     6e7:	68 ff 00             	push   0xff
     6ea:	9a ff ff 00 00       	call   0x0:0xffff
     6ef:	c4 7e 12             	les    di,DWORD PTR [bp+0x12]
     6f2:	26 88 05             	mov    BYTE PTR es:[di],al
     6f5:	c9                   	leave
     6f6:	ca 0c 00             	retf   0xc
     6f9:	c8 06 00 00          	enter  0x6,0x0
     6fd:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     700:	88 46 fc             	mov    BYTE PTR [bp-0x4],al
     703:	c6 46 fd 00          	mov    BYTE PTR [bp-0x3],0x0
     707:	ff 76 0e             	push   WORD PTR [bp+0xe]
     70a:	ff 76 0c             	push   WORD PTR [bp+0xc]
     70d:	ff 76 0a             	push   WORD PTR [bp+0xa]
     710:	ff 76 08             	push   WORD PTR [bp+0x8]
     713:	8d 7e fc             	lea    di,[bp-0x4]
     716:	16                   	push   ss
     717:	57                   	push   di
     718:	8d 7e fa             	lea    di,[bp-0x6]
     71b:	16                   	push   ss
     71c:	57                   	push   di
     71d:	6a 02                	push   0x2
     71f:	9a ff ff 00 00       	call   0x0:0xffff
     724:	09 c0                	or     ax,ax
     726:	74 08                	je     0x730
     728:	8a 46 fa             	mov    al,BYTE PTR [bp-0x6]
     72b:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     72e:	eb 06                	jmp    0x736
     730:	8a 46 06             	mov    al,BYTE PTR [bp+0x6]
     733:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
     736:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
     739:	c9                   	leave
     73a:	ca 0a 00             	retf   0xa
     73d:	c8 02 01 00          	enter  0x102,0x0
     741:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
     746:	eb 03                	jmp    0x74b
     748:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     74b:	8d be fe fe          	lea    di,[bp-0x102]
     74f:	16                   	push   ss
     750:	57                   	push   di
     751:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     754:	99                   	cwd
     755:	05 bf ff             	add    ax,0xffbf
     758:	83 d2 00             	adc    dx,0x0
     75b:	50                   	push   ax
     75c:	9a ff ff 00 00       	call   0x0:0xffff
     761:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
     764:	c1 e7 03             	shl    di,0x3
     767:	81 c7 f6 0b          	add    di,0xbf6
     76b:	1e                   	push   ds
     76c:	57                   	push   di
     76d:	6a 07                	push   0x7
     76f:	9a ff ff 00 00       	call   0x0:0xffff
     774:	8d be fe fe          	lea    di,[bp-0x102]
     778:	16                   	push   ss
     779:	57                   	push   di
     77a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     77d:	99                   	cwd
     77e:	05 cf ff             	add    ax,0xffcf
     781:	83 d2 00             	adc    dx,0x0
     784:	50                   	push   ax
     785:	9a ff ff 00 00       	call   0x0:0xffff
     78a:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
     78d:	c1 e7 04             	shl    di,0x4
     790:	81 c7 4e 0c          	add    di,0xc4e
     794:	1e                   	push   ds
     795:	57                   	push   di
     796:	6a 0f                	push   0xf
     798:	9a ff ff 00 00       	call   0x0:0xffff
     79d:	83 7e fe 0c          	cmp    WORD PTR [bp-0x2],0xc
     7a1:	75 a5                	jne    0x748
     7a3:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
     7a8:	eb 03                	jmp    0x7ad
     7aa:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     7ad:	8d be fe fe          	lea    di,[bp-0x102]
     7b1:	16                   	push   ss
     7b2:	57                   	push   di
     7b3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     7b6:	99                   	cwd
     7b7:	05 df ff             	add    ax,0xffdf
     7ba:	83 d2 00             	adc    dx,0x0
     7bd:	50                   	push   ax
     7be:	9a ff ff 00 00       	call   0x0:0xffff
     7c3:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
     7c6:	c1 e7 03             	shl    di,0x3
     7c9:	81 c7 16 0d          	add    di,0xd16
     7cd:	1e                   	push   ds
     7ce:	57                   	push   di
     7cf:	6a 07                	push   0x7
     7d1:	9a ff ff 00 00       	call   0x0:0xffff
     7d6:	8d be fe fe          	lea    di,[bp-0x102]
     7da:	16                   	push   ss
     7db:	57                   	push   di
     7dc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     7df:	99                   	cwd
     7e0:	05 e6 ff             	add    ax,0xffe6
     7e3:	83 d2 00             	adc    dx,0x0
     7e6:	50                   	push   ax
     7e7:	9a ff ff 00 00       	call   0x0:0xffff
     7ec:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
     7ef:	c1 e7 04             	shl    di,0x4
     7f2:	81 c7 46 0d          	add    di,0xd46
     7f6:	1e                   	push   ds
     7f7:	57                   	push   di
     7f8:	6a 0f                	push   0xf
     7fa:	9a ff ff 00 00       	call   0x0:0xffff
     7ff:	83 7e fe 07          	cmp    WORD PTR [bp-0x2],0x7
     803:	75 a5                	jne    0x7aa
     805:	c9                   	leave
     806:	c3                   	ret
     807:	00 06 6d 2f          	add    BYTE PTR ds:0x2f6d,al
     80b:	64 2f                	fs das
     80d:	79 79                	jns    0x888
     80f:	0c 6d                	or     al,0x6d
     811:	6d                   	ins    WORD PTR es:[di],dx
     812:	6d                   	ins    WORD PTR es:[di],dx
     813:	6d                   	ins    WORD PTR es:[di],dx
     814:	20 64 2c             	and    BYTE PTR [si+0x2c],ah
     817:	20 79 79             	and    BYTE PTR [bx+di+0x79],bh
     81a:	79 79                	jns    0x895
     81c:	02 61 6d             	add    ah,BYTE PTR [bx+di+0x6d]
     81f:	02 70 6d             	add    dh,BYTE PTR [bx+si+0x6d]
     822:	01 68 02             	add    WORD PTR [bx+si+0x2],bp
     825:	68 68 05             	push   0x568
     828:	20 41 4d             	and    BYTE PTR [bx+di+0x4d],al
     82b:	50                   	push   ax
     82c:	4d                   	dec    bp
     82d:	03 3a                	add    di,WORD PTR [bp+si]
     82f:	6d                   	ins    WORD PTR es:[di],dx
     830:	6d                   	ins    WORD PTR es:[di],dx
     831:	06                   	push   es
     832:	3a 6d 6d             	cmp    ch,BYTE PTR [di+0x6d]
     835:	3a 73 73             	cmp    dh,BYTE PTR [bp+di+0x73]
     838:	c8 10 01 00          	enter  0x110,0x0
     83c:	8d be f0 fe          	lea    di,[bp-0x110]
     840:	16                   	push   ss
     841:	57                   	push   di
     842:	bf e0 09             	mov    di,0x9e0
     845:	1e                   	push   ds
     846:	57                   	push   di
     847:	bf e5 09             	mov    di,0x9e5
     84a:	1e                   	push   ds
     84b:	57                   	push   di
     84c:	bf 07 08             	mov    di,0x807
     84f:	0e                   	push   cs
     850:	57                   	push   di
     851:	9a ff ff 00 00       	call   0x0:0xffff
     856:	bf 7e 0b             	mov    di,0xb7e
     859:	1e                   	push   ds
     85a:	57                   	push   di
     85b:	6a 07                	push   0x7
     85d:	9a ff ff 00 00       	call   0x0:0xffff
     862:	bf e0 09             	mov    di,0x9e0
     865:	1e                   	push   ds
     866:	57                   	push   di
     867:	bf ef 09             	mov    di,0x9ef
     86a:	1e                   	push   ds
     86b:	57                   	push   di
     86c:	6a 00                	push   0x0
     86e:	9a ff ff 00 00       	call   0x0:0xffff
     873:	a2 86 0b             	mov    ds:0xb86,al
     876:	bf e0 09             	mov    di,0x9e0
     879:	1e                   	push   ds
     87a:	57                   	push   di
     87b:	bf f9 09             	mov    di,0x9f9
     87e:	1e                   	push   ds
     87f:	57                   	push   di
     880:	6a 00                	push   0x0
     882:	9a ff ff 00 00       	call   0x0:0xffff
     887:	a2 87 0b             	mov    ds:0xb87,al
     88a:	bf e0 09             	mov    di,0x9e0
     88d:	1e                   	push   ds
     88e:	57                   	push   di
     88f:	bf 02 0a             	mov    di,0xa02
     892:	1e                   	push   ds
     893:	57                   	push   di
     894:	6a 2c                	push   0x2c
     896:	9a ff ff 00 00       	call   0x0:0xffff
     89b:	a2 88 0b             	mov    ds:0xb88,al
     89e:	bf e0 09             	mov    di,0x9e0
     8a1:	1e                   	push   ds
     8a2:	57                   	push   di
     8a3:	bf 0c 0a             	mov    di,0xa0c
     8a6:	1e                   	push   ds
     8a7:	57                   	push   di
     8a8:	6a 2e                	push   0x2e
     8aa:	9a ff ff 00 00       	call   0x0:0xffff
     8af:	a2 89 0b             	mov    ds:0xb89,al
     8b2:	bf e0 09             	mov    di,0x9e0
     8b5:	1e                   	push   ds
     8b6:	57                   	push   di
     8b7:	bf 15 0a             	mov    di,0xa15
     8ba:	1e                   	push   ds
     8bb:	57                   	push   di
     8bc:	6a 02                	push   0x2
     8be:	9a ff ff 00 00       	call   0x0:0xffff
     8c3:	a2 8a 0b             	mov    ds:0xb8a,al
     8c6:	bf e0 09             	mov    di,0x9e0
     8c9:	1e                   	push   ds
     8ca:	57                   	push   di
     8cb:	bf 21 0a             	mov    di,0xa21
     8ce:	1e                   	push   ds
     8cf:	57                   	push   di
     8d0:	6a 2f                	push   0x2f
     8d2:	9a ff ff 00 00       	call   0x0:0xffff
     8d7:	a2 8b 0b             	mov    ds:0xb8b,al
     8da:	8d be f0 fe          	lea    di,[bp-0x110]
     8de:	16                   	push   ss
     8df:	57                   	push   di
     8e0:	bf e0 09             	mov    di,0x9e0
     8e3:	1e                   	push   ds
     8e4:	57                   	push   di
     8e5:	bf 27 0a             	mov    di,0xa27
     8e8:	1e                   	push   ds
     8e9:	57                   	push   di
     8ea:	bf 08 08             	mov    di,0x808
     8ed:	0e                   	push   cs
     8ee:	57                   	push   di
     8ef:	9a ff ff 00 00       	call   0x0:0xffff
     8f4:	bf 8c 0b             	mov    di,0xb8c
     8f7:	1e                   	push   ds
     8f8:	57                   	push   di
     8f9:	6a 0f                	push   0xf
     8fb:	9a ff ff 00 00       	call   0x0:0xffff
     900:	8d be f0 fe          	lea    di,[bp-0x110]
     904:	16                   	push   ss
     905:	57                   	push   di
     906:	bf e0 09             	mov    di,0x9e0
     909:	1e                   	push   ds
     90a:	57                   	push   di
     90b:	bf 32 0a             	mov    di,0xa32
     90e:	1e                   	push   ds
     90f:	57                   	push   di
     910:	bf 0f 08             	mov    di,0x80f
     913:	0e                   	push   cs
     914:	57                   	push   di
     915:	9a ff ff 00 00       	call   0x0:0xffff
     91a:	bf 9c 0b             	mov    di,0xb9c
     91d:	1e                   	push   ds
     91e:	57                   	push   di
     91f:	6a 1f                	push   0x1f
     921:	9a ff ff 00 00       	call   0x0:0xffff
     926:	bf e0 09             	mov    di,0x9e0
     929:	1e                   	push   ds
     92a:	57                   	push   di
     92b:	bf 3c 0a             	mov    di,0xa3c
     92e:	1e                   	push   ds
     92f:	57                   	push   di
     930:	6a 3a                	push   0x3a
     932:	9a ff ff 00 00       	call   0x0:0xffff
     937:	a2 bc 0b             	mov    ds:0xbbc,al
     93a:	8d be f0 fe          	lea    di,[bp-0x110]
     93e:	16                   	push   ss
     93f:	57                   	push   di
     940:	bf e0 09             	mov    di,0x9e0
     943:	1e                   	push   ds
     944:	57                   	push   di
     945:	bf 42 0a             	mov    di,0xa42
     948:	1e                   	push   ds
     949:	57                   	push   di
     94a:	bf 1c 08             	mov    di,0x81c
     94d:	0e                   	push   cs
     94e:	57                   	push   di
     94f:	9a ff ff 00 00       	call   0x0:0xffff
     954:	bf be 0b             	mov    di,0xbbe
     957:	1e                   	push   ds
     958:	57                   	push   di
     959:	6a 07                	push   0x7
     95b:	9a ff ff 00 00       	call   0x0:0xffff
     960:	8d be f0 fe          	lea    di,[bp-0x110]
     964:	16                   	push   ss
     965:	57                   	push   di
     966:	bf e0 09             	mov    di,0x9e0
     969:	1e                   	push   ds
     96a:	57                   	push   di
     96b:	bf 48 0a             	mov    di,0xa48
     96e:	1e                   	push   ds
     96f:	57                   	push   di
     970:	bf 1f 08             	mov    di,0x81f
     973:	0e                   	push   cs
     974:	57                   	push   di
     975:	9a ff ff 00 00       	call   0x0:0xffff
     97a:	bf c6 0b             	mov    di,0xbc6
     97d:	1e                   	push   ds
     97e:	57                   	push   di
     97f:	6a 07                	push   0x7
     981:	9a ff ff 00 00       	call   0x0:0xffff
     986:	bf e0 09             	mov    di,0x9e0
     989:	1e                   	push   ds
     98a:	57                   	push   di
     98b:	bf 4e 0a             	mov    di,0xa4e
     98e:	1e                   	push   ds
     98f:	57                   	push   di
     990:	6a 00                	push   0x0
     992:	9a ff ff 00 00       	call   0x0:0xffff
     997:	09 c0                	or     ax,ax
     999:	75 13                	jne    0x9ae
     99b:	bf 22 08             	mov    di,0x822
     99e:	0e                   	push   cs
     99f:	57                   	push   di
     9a0:	8d 7e f8             	lea    di,[bp-0x8]
     9a3:	16                   	push   ss
     9a4:	57                   	push   di
     9a5:	6a 07                	push   0x7
     9a7:	9a ff ff 00 00       	call   0x0:0xffff
     9ac:	eb 11                	jmp    0x9bf
     9ae:	bf 24 08             	mov    di,0x824
     9b1:	0e                   	push   cs
     9b2:	57                   	push   di
     9b3:	8d 7e f8             	lea    di,[bp-0x8]
     9b6:	16                   	push   ss
     9b7:	57                   	push   di
     9b8:	6a 07                	push   0x7
     9ba:	9a ff ff 00 00       	call   0x0:0xffff
     9bf:	bf e0 09             	mov    di,0x9e0
     9c2:	1e                   	push   ds
     9c3:	57                   	push   di
     9c4:	bf 56 0a             	mov    di,0xa56
     9c7:	1e                   	push   ds
     9c8:	57                   	push   di
     9c9:	6a 00                	push   0x0
     9cb:	9a ff ff 00 00       	call   0x0:0xffff
     9d0:	09 c0                	or     ax,ax
     9d2:	75 13                	jne    0x9e7
     9d4:	bf 27 08             	mov    di,0x827
     9d7:	0e                   	push   cs
     9d8:	57                   	push   di
     9d9:	8d 7e f0             	lea    di,[bp-0x10]
     9dc:	16                   	push   ss
     9dd:	57                   	push   di
     9de:	6a 07                	push   0x7
     9e0:	9a ff ff 00 00       	call   0x0:0xffff
     9e5:	eb 04                	jmp    0x9eb
     9e7:	c6 46 f0 00          	mov    BYTE PTR [bp-0x10],0x0
     9eb:	8d be f0 fe          	lea    di,[bp-0x110]
     9ef:	16                   	push   ss
     9f0:	57                   	push   di
     9f1:	8d 7e f8             	lea    di,[bp-0x8]
     9f4:	16                   	push   ss
     9f5:	57                   	push   di
     9f6:	9a ff ff 00 00       	call   0x0:0xffff
     9fb:	bf 2d 08             	mov    di,0x82d
     9fe:	0e                   	push   cs
     9ff:	57                   	push   di
     a00:	9a ff ff 00 00       	call   0x0:0xffff
     a05:	8d 7e f0             	lea    di,[bp-0x10]
     a08:	16                   	push   ss
     a09:	57                   	push   di
     a0a:	9a ff ff 00 00       	call   0x0:0xffff
     a0f:	bf ce 0b             	mov    di,0xbce
     a12:	1e                   	push   ds
     a13:	57                   	push   di
     a14:	6a 0f                	push   0xf
     a16:	9a ff ff 00 00       	call   0x0:0xffff
     a1b:	8d be f0 fe          	lea    di,[bp-0x110]
     a1f:	16                   	push   ss
     a20:	57                   	push   di
     a21:	8d 7e f8             	lea    di,[bp-0x8]
     a24:	16                   	push   ss
     a25:	57                   	push   di
     a26:	9a ff ff 00 00       	call   0x0:0xffff
     a2b:	bf 31 08             	mov    di,0x831
     a2e:	0e                   	push   cs
     a2f:	57                   	push   di
     a30:	9a ff ff 00 00       	call   0x0:0xffff
     a35:	8d 7e f0             	lea    di,[bp-0x10]
     a38:	16                   	push   ss
     a39:	57                   	push   di
     a3a:	9a ff ff 00 00       	call   0x0:0xffff
     a3f:	bf de 0b             	mov    di,0xbde
     a42:	1e                   	push   ds
     a43:	57                   	push   di
     a44:	6a 1f                	push   0x1f
     a46:	9a ff ff 00 00       	call   0x0:0xffff
     a4b:	c9                   	leave
     a4c:	cb                   	retf
     a4d:	55                   	push   bp
     a4e:	89 e5                	mov    bp,sp
     a50:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
     a53:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
     a56:	89 d1                	mov    cx,dx
     a58:	09 c1                	or     cx,ax
     a5a:	74 0d                	je     0xa69
     a5c:	81 fa ff ff          	cmp    dx,0xffff
     a60:	74 07                	je     0xa69
     a62:	8e c2                	mov    es,dx
     a64:	26 8b 16 00 00       	mov    dx,WORD PTR es:0x0
     a69:	c9                   	leave
     a6a:	c2 04 00             	ret    0x4
     a6d:	c8 38 02 00          	enter  0x238,0x0
     a71:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     a74:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
     a78:	c7 46 dc 24 00       	mov    WORD PTR [bp-0x24],0x24
     a7d:	c7 46 de 00 00       	mov    WORD PTR [bp-0x22],0x0
     a82:	8d 7e dc             	lea    di,[bp-0x24]
     a85:	16                   	push   ss
     a86:	57                   	push   di
     a87:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     a8a:	26 ff 35             	push   WORD PTR es:[di]
     a8d:	9a ff ff 00 00       	call   0x0:0xffff
     a92:	09 c0                	or     ax,ax
     a94:	74 5b                	je     0xaf1
     a96:	c7 86 c8 fe 14 01    	mov    WORD PTR [bp-0x138],0x114
     a9c:	c7 86 ca fe 00 00    	mov    WORD PTR [bp-0x136],0x0
     aa2:	8d be c8 fe          	lea    di,[bp-0x138]
     aa6:	16                   	push   ss
     aa7:	57                   	push   di
     aa8:	ff 76 f2             	push   WORD PTR [bp-0xe]
     aab:	9a ff ff 00 00       	call   0x0:0xffff
     ab0:	09 c0                	or     ax,ax
     ab2:	74 3d                	je     0xaf1
     ab4:	8d be c8 fd          	lea    di,[bp-0x238]
     ab8:	16                   	push   ss
     ab9:	57                   	push   di
     aba:	8d be da fe          	lea    di,[bp-0x126]
     abe:	16                   	push   ss
     abf:	57                   	push   di
     ac0:	6a 5c                	push   0x5c
     ac2:	9a ff ff 00 00       	call   0x0:0xffff
     ac7:	05 01 00             	add    ax,0x1
     aca:	52                   	push   dx
     acb:	50                   	push   ax
     acc:	9a ff ff 00 00       	call   0x0:0xffff
     ad1:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     ad4:	06                   	push   es
     ad5:	57                   	push   di
     ad6:	6a 4f                	push   0x4f
     ad8:	9a ff ff 00 00       	call   0x0:0xffff
     add:	8a 46 f4             	mov    al,BYTE PTR [bp-0xc]
     ae0:	3c 01                	cmp    al,0x1
     ae2:	72 0d                	jb     0xaf1
     ae4:	3c 03                	cmp    al,0x3
     ae6:	77 09                	ja     0xaf1
     ae8:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     aeb:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     aee:	26 89 05             	mov    WORD PTR es:[di],ax
     af1:	c9                   	leave
     af2:	c2 08 00             	ret    0x8
     af5:	c8 9e 02 00          	enter  0x29e,0x0
     af9:	8d be 62 fd          	lea    di,[bp-0x29e]
     afd:	16                   	push   ss
     afe:	57                   	push   di
     aff:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     b02:	26 c4 3d             	les    di,DWORD PTR es:[di]
     b05:	06                   	push   es
     b06:	57                   	push   di
     b07:	9a ff ff 00 00       	call   0x0:0xffff
     b0c:	8d 7e c8             	lea    di,[bp-0x38]
     b0f:	16                   	push   ss
     b10:	57                   	push   di
     b11:	6a 1f                	push   0x1f
     b13:	9a ff ff 00 00       	call   0x0:0xffff
     b18:	a1 16 0b             	mov    ax,ds:0xb16
     b1b:	89 86 62 fe          	mov    WORD PTR [bp-0x19e],ax
     b1f:	c7 86 64 fe 24 00    	mov    WORD PTR [bp-0x19c],0x24
     b25:	c7 86 66 fe 00 00    	mov    WORD PTR [bp-0x19a],0x0
     b2b:	8d be 64 fe          	lea    di,[bp-0x19c]
     b2f:	16                   	push   ss
     b30:	57                   	push   di
     b31:	ff 76 08             	push   WORD PTR [bp+0x8]
     b34:	9a ff ff 00 00       	call   0x0:0xffff
     b39:	09 c0                	or     ax,ax
     b3b:	74 1d                	je     0xb5a
     b3d:	8b 86 7a fe          	mov    ax,WORD PTR [bp-0x186]
     b41:	89 86 62 fe          	mov    WORD PTR [bp-0x19e],ax
     b45:	8a 86 7c fe          	mov    al,BYTE PTR [bp-0x184]
     b49:	3c 01                	cmp    al,0x1
     b4b:	72 0b                	jb     0xb58
     b4d:	3c 03                	cmp    al,0x3
     b4f:	77 07                	ja     0xb58
     b51:	8b 86 7e fe          	mov    ax,WORD PTR [bp-0x182]
     b55:	89 46 08             	mov    WORD PTR [bp+0x8],ax
     b58:	eb 0f                	jmp    0xb69
     b5a:	ff 76 08             	push   WORD PTR [bp+0x8]
     b5d:	ff 76 06             	push   WORD PTR [bp+0x6]
     b60:	e8 ea fe             	call   0xa4d
     b63:	89 46 06             	mov    WORD PTR [bp+0x6],ax
     b66:	89 56 08             	mov    WORD PTR [bp+0x8],dx
     b69:	ff b6 62 fe          	push   WORD PTR [bp-0x19e]
     b6d:	8d be 88 fe          	lea    di,[bp-0x178]
     b71:	16                   	push   ss
     b72:	57                   	push   di
     b73:	68 00 01             	push   0x100
     b76:	9a ff ff 00 00       	call   0x0:0xffff
     b7b:	8d 7e e8             	lea    di,[bp-0x18]
     b7e:	16                   	push   ss
     b7f:	57                   	push   di
     b80:	8d be 88 fe          	lea    di,[bp-0x178]
     b84:	16                   	push   ss
     b85:	57                   	push   di
     b86:	6a 5c                	push   0x5c
     b88:	9a ff ff 00 00       	call   0x0:0xffff
     b8d:	05 01 00             	add    ax,0x1
     b90:	52                   	push   dx
     b91:	50                   	push   ax
     b92:	9a ff ff 00 00       	call   0x0:0xffff
     b97:	a1 dc 09             	mov    ax,ds:0x9dc
     b9a:	8b 16 de 09          	mov    dx,WORD PTR ds:0x9de
     b9e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     ba1:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     ba4:	b8 5c 0a             	mov    ax,0xa5c
     ba7:	8c da                	mov    dx,ds
     ba9:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     bac:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     baf:	ff 76 0c             	push   WORD PTR [bp+0xc]
     bb2:	ff 76 0a             	push   WORD PTR [bp+0xa]
     bb5:	bf 22 00             	mov    di,0x22
     bb8:	b8 ff ff             	mov    ax,0xffff
     bbb:	50                   	push   ax
     bbc:	57                   	push   di
     bbd:	9a ff ff 00 00       	call   0x0:0xffff
     bc2:	08 c0                	or     al,al
     bc4:	74 38                	je     0xbfe
     bc6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     bc9:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
     bcd:	26 8b 55 06          	mov    dx,WORD PTR es:[di+0x6]
     bd1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     bd4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     bd7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     bda:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
     bde:	74 1e                	je     0xbfe
     be0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     be3:	26 8a 05             	mov    al,BYTE PTR es:[di]
     be6:	30 e4                	xor    ah,ah
     be8:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     beb:	03 f8                	add    di,ax
     bed:	26 80 3d 2e          	cmp    BYTE PTR es:[di],0x2e
     bf1:	74 0b                	je     0xbfe
     bf3:	b8 5d 0a             	mov    ax,0xa5d
     bf6:	8c da                	mov    dx,ds
     bf8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     bfb:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     bfe:	ff 36 16 0b          	push   WORD PTR ds:0xb16
     c02:	6a a3                	push   0xffa3
     c04:	8d 7e 88             	lea    di,[bp-0x78]
     c07:	16                   	push   ss
     c08:	57                   	push   di
     c09:	6a 40                	push   0x40
     c0b:	9a ff ff 00 00       	call   0x0:0xffff
     c10:	8d be 88 fe          	lea    di,[bp-0x178]
     c14:	16                   	push   ss
     c15:	57                   	push   di
     c16:	8d 7e 88             	lea    di,[bp-0x78]
     c19:	16                   	push   ss
     c1a:	57                   	push   di
     c1b:	8d 46 c8             	lea    ax,[bp-0x38]
     c1e:	8c d2                	mov    dx,ss
     c20:	89 86 3a fe          	mov    WORD PTR [bp-0x1c6],ax
     c24:	89 96 3c fe          	mov    WORD PTR [bp-0x1c4],dx
     c28:	c6 86 3e fe 04       	mov    BYTE PTR [bp-0x1c2],0x4
     c2d:	8d 46 e8             	lea    ax,[bp-0x18]
     c30:	8c d2                	mov    dx,ss
     c32:	89 86 42 fe          	mov    WORD PTR [bp-0x1be],ax
     c36:	89 96 44 fe          	mov    WORD PTR [bp-0x1bc],dx
     c3a:	c6 86 46 fe 06       	mov    BYTE PTR [bp-0x1ba],0x6
     c3f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     c42:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     c45:	89 86 4a fe          	mov    WORD PTR [bp-0x1b6],ax
     c49:	89 96 4c fe          	mov    WORD PTR [bp-0x1b4],dx
     c4d:	c6 86 4e fe 05       	mov    BYTE PTR [bp-0x1b2],0x5
     c52:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     c55:	89 f8                	mov    ax,di
     c57:	8c c2                	mov    dx,es
     c59:	89 86 52 fe          	mov    WORD PTR [bp-0x1ae],ax
     c5d:	89 96 54 fe          	mov    WORD PTR [bp-0x1ac],dx
     c61:	c6 86 56 fe 04       	mov    BYTE PTR [bp-0x1aa],0x4
     c66:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
     c69:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
     c6c:	89 86 5a fe          	mov    WORD PTR [bp-0x1a6],ax
     c70:	89 96 5c fe          	mov    WORD PTR [bp-0x1a4],dx
     c74:	c6 86 5e fe 06       	mov    BYTE PTR [bp-0x1a2],0x6
     c79:	8d be 3a fe          	lea    di,[bp-0x1c6]
     c7d:	16                   	push   ss
     c7e:	57                   	push   di
     c7f:	6a 04                	push   0x4
     c81:	9a ff ff 00 00       	call   0x0:0xffff
     c86:	ff 36 16 0b          	push   WORD PTR ds:0xb16
     c8a:	6a a4                	push   0xffa4
     c8c:	8d 7e 88             	lea    di,[bp-0x78]
     c8f:	16                   	push   ss
     c90:	57                   	push   di
     c91:	6a 40                	push   0x40
     c93:	9a ff ff 00 00       	call   0x0:0xffff
     c98:	6a 00                	push   0x0
     c9a:	8d be 88 fe          	lea    di,[bp-0x178]
     c9e:	16                   	push   ss
     c9f:	57                   	push   di
     ca0:	8d 7e 88             	lea    di,[bp-0x78]
     ca3:	16                   	push   ss
     ca4:	57                   	push   di
     ca5:	68 10 10             	push   0x1010
     ca8:	9a ff ff 00 00       	call   0x0:0xffff
     cad:	c9                   	leave
     cae:	ca 08 00             	retf   0x8
     cb1:	55                   	push   bp
     cb2:	89 e5                	mov    bp,sp
     cb4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     cb8:	74 08                	je     0xcc2
     cba:	83 ec 08             	sub    sp,0x8
     cbd:	9a ff ff 00 00       	call   0x0:0xffff
     cc2:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
     cc5:	06                   	push   es
     cc6:	57                   	push   di
     cc7:	9a ff ff 00 00       	call   0x0:0xffff
     ccc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ccf:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     cd3:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     cd7:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     cdb:	74 07                	je     0xce4
     cdd:	8f 06 e2 0a          	pop    WORD PTR ds:0xae2
     ce1:	83 c4 06             	add    sp,0x6
     ce4:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     ce7:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     cea:	c9                   	leave
     ceb:	ca 0a 00             	retf   0xa
     cee:	c8 00 01 00          	enter  0x100,0x0
     cf2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     cf6:	74 08                	je     0xd00
     cf8:	83 ec 08             	sub    sp,0x8
     cfb:	9a ff ff 00 00       	call   0x0:0xffff
     d00:	8d be 00 ff          	lea    di,[bp-0x100]
     d04:	16                   	push   ss
     d05:	57                   	push   di
     d06:	ff 76 0c             	push   WORD PTR [bp+0xc]
     d09:	9a ff ff 00 00       	call   0x0:0xffff
     d0e:	9a ff ff 00 00       	call   0x0:0xffff
     d13:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d16:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     d1a:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     d1e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     d22:	74 07                	je     0xd2b
     d24:	8f 06 e2 0a          	pop    WORD PTR ds:0xae2
     d28:	83 c4 06             	add    sp,0x6
     d2b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     d2e:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     d31:	c9                   	leave
     d32:	ca 08 00             	retf   0x8
     d35:	c8 00 02 00          	enter  0x200,0x0
     d39:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     d3d:	74 08                	je     0xd47
     d3f:	83 ec 08             	sub    sp,0x8
     d42:	9a ff ff 00 00       	call   0x0:0xffff
     d47:	8d be 00 fe          	lea    di,[bp-0x200]
     d4b:	16                   	push   ss
     d4c:	57                   	push   di
     d4d:	8d be 00 ff          	lea    di,[bp-0x100]
     d51:	16                   	push   ss
     d52:	57                   	push   di
     d53:	ff 76 12             	push   WORD PTR [bp+0x12]
     d56:	9a ff ff 00 00       	call   0x0:0xffff
     d5b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     d5e:	06                   	push   es
     d5f:	57                   	push   di
     d60:	ff 76 0c             	push   WORD PTR [bp+0xc]
     d63:	9a ff ff 00 00       	call   0x0:0xffff
     d68:	9a ff ff 00 00       	call   0x0:0xffff
     d6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d70:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     d74:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     d78:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     d7c:	74 07                	je     0xd85
     d7e:	8f 06 e2 0a          	pop    WORD PTR ds:0xae2
     d82:	83 c4 06             	add    sp,0x6
     d85:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     d88:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     d8b:	c9                   	leave
     d8c:	ca 0e 00             	retf   0xe
     d8f:	55                   	push   bp
     d90:	89 e5                	mov    bp,sp
     d92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d95:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
     d99:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     d9d:	9a ff ff 00 00       	call   0x0:0xffff
     da2:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     da6:	74 05                	je     0xdad
     da8:	9a ff ff 00 00       	call   0x0:0xffff
     dad:	c9                   	leave
     dae:	ca 06 00             	retf   0x6
     db1:	55                   	push   bp
     db2:	89 e5                	mov    bp,sp
     db4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     db8:	74 05                	je     0xdbf
     dba:	9a ff ff 00 00       	call   0x0:0xffff
     dbf:	c9                   	leave
     dc0:	ca 06 00             	retf   0x6
     dc3:	55                   	push   bp
     dc4:	89 e5                	mov    bp,sp
     dc6:	c9                   	leave
     dc7:	ca 04 00             	retf   0x4
     dca:	c8 0e 00 00          	enter  0xe,0x0
     dce:	31 c0                	xor    ax,ax
     dd0:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     dd3:	83 7e fa 07          	cmp    WORD PTR [bp-0x6],0x7
     dd7:	7f 15                	jg     0xdee
     dd9:	8b 7e fa             	mov    di,WORD PTR [bp-0x6]
     ddc:	c1 e7 02             	shl    di,0x2
     ddf:	8b 85 60 0a          	mov    ax,WORD PTR [di+0xa60]
     de3:	3b 06 02 0b          	cmp    ax,WORD PTR ds:0xb02
     de7:	74 05                	je     0xdee
     de9:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     dec:	eb e5                	jmp    0xdd3
     dee:	83 7e fa 07          	cmp    WORD PTR [bp-0x6],0x7
     df2:	7f 22                	jg     0xe16
     df4:	8b 7e fa             	mov    di,WORD PTR [bp-0x6]
     df7:	c1 e7 02             	shl    di,0x2
     dfa:	ff b5 62 0a          	push   WORD PTR [di+0xa62]
     dfe:	b0 01                	mov    al,0x1
     e00:	50                   	push   ax
     e01:	b8 79 00             	mov    ax,0x79
     e04:	ba ff ff             	mov    dx,0xffff
     e07:	52                   	push   dx
     e08:	50                   	push   ax
     e09:	9a ff ff 00 00       	call   0x0:0xffff
     e0e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     e11:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     e14:	eb 2d                	jmp    0xe43
     e16:	6a 88                	push   0xff88
     e18:	a1 02 0b             	mov    ax,ds:0xb02
     e1b:	99                   	cwd
     e1c:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
     e1f:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
     e22:	c6 46 f6 00          	mov    BYTE PTR [bp-0xa],0x0
     e26:	8d 7e f2             	lea    di,[bp-0xe]
     e29:	16                   	push   ss
     e2a:	57                   	push   di
     e2b:	6a 00                	push   0x0
     e2d:	b0 01                	mov    al,0x1
     e2f:	50                   	push   ax
     e30:	b8 79 00             	mov    ax,0x79
     e33:	ba ff ff             	mov    dx,0xffff
     e36:	52                   	push   dx
     e37:	50                   	push   ax
     e38:	9a ff ff 00 00       	call   0x0:0xffff
     e3d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     e40:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     e43:	a1 02 0b             	mov    ax,ds:0xb02
     e46:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     e49:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
     e4d:	31 c0                	xor    ax,ax
     e4f:	a3 02 0b             	mov    ds:0xb02,ax
     e52:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     e55:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     e58:	c9                   	leave
     e59:	c3                   	ret
     e5a:	c8 74 01 00          	enter  0x174,0x0
     e5e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     e61:	3d 01 00             	cmp    ax,0x1
     e64:	75 10                	jne    0xe76
     e66:	a1 c6 0d             	mov    ax,ds:0xdc6
     e69:	8b 16 c8 0d          	mov    dx,WORD PTR ds:0xdc8
     e6d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     e70:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     e73:	e9 5a 01             	jmp    0xfd0
     e76:	3d 02 00             	cmp    ax,0x2
     e79:	74 0a                	je     0xe85
     e7b:	3d 04 00             	cmp    ax,0x4
     e7e:	7c 30                	jl     0xeb0
     e80:	3d 0a 00             	cmp    ax,0xa
     e83:	7f 2b                	jg     0xeb0
     e85:	8b 7e 0a             	mov    di,WORD PTR [bp+0xa]
     e88:	d1 e7                	shl    di,1
     e8a:	8b f7                	mov    si,di
     e8c:	d1 e7                	shl    di,1
     e8e:	01 f7                	add    di,si
     e90:	81 c7 7c 0a          	add    di,0xa7c
     e94:	1e                   	push   ds
     e95:	07                   	pop    es
     e96:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     e9a:	b0 01                	mov    al,0x1
     e9c:	50                   	push   ax
     e9d:	26 c4 3d             	les    di,DWORD PTR es:[di]
     ea0:	06                   	push   es
     ea1:	57                   	push   di
     ea2:	9a ff ff 00 00       	call   0x0:0xffff
     ea7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     eaa:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     ead:	e9 20 01             	jmp    0xfd0
     eb0:	3d 03 00             	cmp    ax,0x3
     eb3:	74 10                	je     0xec5
     eb5:	3d 0b 00             	cmp    ax,0xb
     eb8:	7d 03                	jge    0xebd
     eba:	e9 0a 01             	jmp    0xfc7
     ebd:	3d 10 00             	cmp    ax,0x10
     ec0:	7e 03                	jle    0xec5
     ec2:	e9 02 01             	jmp    0xfc7
     ec5:	8b 7e 0a             	mov    di,WORD PTR [bp+0xa]
     ec8:	d1 e7                	shl    di,1
     eca:	8b f7                	mov    si,di
     ecc:	d1 e7                	shl    di,1
     ece:	01 f7                	add    di,si
     ed0:	81 c7 7c 0a          	add    di,0xa7c
     ed4:	1e                   	push   ds
     ed5:	07                   	pop    es
     ed6:	89 7e a4             	mov    WORD PTR [bp-0x5c],di
     ed9:	8c 46 a6             	mov    WORD PTR [bp-0x5a],es
     edc:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     edf:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     ee2:	89 46 a8             	mov    WORD PTR [bp-0x58],ax
     ee5:	89 56 aa             	mov    WORD PTR [bp-0x56],dx
     ee8:	8d 7e ac             	lea    di,[bp-0x54]
     eeb:	16                   	push   ss
     eec:	57                   	push   di
     eed:	8d 7e aa             	lea    di,[bp-0x56]
     ef0:	16                   	push   ss
     ef1:	57                   	push   di
     ef2:	e8 78 fb             	call   0xa6d
     ef5:	80 7e ac 00          	cmp    BYTE PTR [bp-0x54],0x0
     ef9:	74 6f                	je     0xf6a
     efb:	6a a1                	push   0xffa1
     efd:	8d be a4 fe          	lea    di,[bp-0x15c]
     f01:	16                   	push   ss
     f02:	57                   	push   di
     f03:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
     f06:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     f0a:	9a ff ff 00 00       	call   0x0:0xffff
     f0f:	83 c4 04             	add    sp,0x4
     f12:	8d 86 a4 fe          	lea    ax,[bp-0x15c]
     f16:	8c d2                	mov    dx,ss
     f18:	89 86 8c fe          	mov    WORD PTR [bp-0x174],ax
     f1c:	89 96 8e fe          	mov    WORD PTR [bp-0x172],dx
     f20:	c6 86 90 fe 04       	mov    BYTE PTR [bp-0x170],0x4
     f25:	8d 46 ac             	lea    ax,[bp-0x54]
     f28:	8c d2                	mov    dx,ss
     f2a:	89 86 94 fe          	mov    WORD PTR [bp-0x16c],ax
     f2e:	89 96 96 fe          	mov    WORD PTR [bp-0x16a],dx
     f32:	c6 86 98 fe 04       	mov    BYTE PTR [bp-0x168],0x4
     f37:	8b 46 a8             	mov    ax,WORD PTR [bp-0x58]
     f3a:	8b 56 aa             	mov    dx,WORD PTR [bp-0x56]
     f3d:	89 86 9c fe          	mov    WORD PTR [bp-0x164],ax
     f41:	89 96 9e fe          	mov    WORD PTR [bp-0x162],dx
     f45:	c6 86 a0 fe 05       	mov    BYTE PTR [bp-0x160],0x5
     f4a:	8d be 8c fe          	lea    di,[bp-0x174]
     f4e:	16                   	push   ss
     f4f:	57                   	push   di
     f50:	6a 02                	push   0x2
     f52:	b0 01                	mov    al,0x1
     f54:	50                   	push   ax
     f55:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
     f58:	26 c4 3d             	les    di,DWORD PTR es:[di]
     f5b:	06                   	push   es
     f5c:	57                   	push   di
     f5d:	9a ff ff 00 00       	call   0x0:0xffff
     f62:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f65:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     f68:	eb 5b                	jmp    0xfc5
     f6a:	6a a2                	push   0xffa2
     f6c:	8d be a4 fe          	lea    di,[bp-0x15c]
     f70:	16                   	push   ss
     f71:	57                   	push   di
     f72:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
     f75:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
     f79:	9a ff ff 00 00       	call   0x0:0xffff
     f7e:	83 c4 04             	add    sp,0x4
     f81:	8d 86 a4 fe          	lea    ax,[bp-0x15c]
     f85:	8c d2                	mov    dx,ss
     f87:	89 86 94 fe          	mov    WORD PTR [bp-0x16c],ax
     f8b:	89 96 96 fe          	mov    WORD PTR [bp-0x16a],dx
     f8f:	c6 86 98 fe 04       	mov    BYTE PTR [bp-0x168],0x4
     f94:	8b 46 a8             	mov    ax,WORD PTR [bp-0x58]
     f97:	8b 56 aa             	mov    dx,WORD PTR [bp-0x56]
     f9a:	89 86 9c fe          	mov    WORD PTR [bp-0x164],ax
     f9e:	89 96 9e fe          	mov    WORD PTR [bp-0x162],dx
     fa2:	c6 86 a0 fe 05       	mov    BYTE PTR [bp-0x160],0x5
     fa7:	8d be 94 fe          	lea    di,[bp-0x16c]
     fab:	16                   	push   ss
     fac:	57                   	push   di
     fad:	6a 01                	push   0x1
     faf:	b0 01                	mov    al,0x1
     fb1:	50                   	push   ax
     fb2:	c4 7e a4             	les    di,DWORD PTR [bp-0x5c]
     fb5:	26 c4 3d             	les    di,DWORD PTR es:[di]
     fb8:	06                   	push   es
     fb9:	57                   	push   di
     fba:	9a ff ff 00 00       	call   0x0:0xffff
     fbf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     fc2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     fc5:	eb 09                	jmp    0xfd0
     fc7:	e8 00 fe             	call   0xdca
     fca:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     fcd:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     fd0:	ff 76 fe             	push   WORD PTR [bp-0x2]
     fd3:	ff 76 fc             	push   WORD PTR [bp-0x4]
     fd6:	ff 76 08             	push   WORD PTR [bp+0x8]
     fd9:	ff 76 06             	push   WORD PTR [bp+0x6]
     fdc:	ea ff ff 00 00       	jmp    0x0:0xffff
     fe1:	c9                   	leave
     fe2:	ca 06 00             	retf   0x6
     fe5:	55                   	push   bp
     fe6:	89 e5                	mov    bp,sp
     fe8:	ff 76 0c             	push   WORD PTR [bp+0xc]
     feb:	ff 76 0a             	push   WORD PTR [bp+0xa]
     fee:	ff 76 08             	push   WORD PTR [bp+0x8]
     ff1:	ff 76 06             	push   WORD PTR [bp+0x6]
     ff4:	9a ff ff 00 00       	call   0x0:0xffff
     ff9:	b8 01 00             	mov    ax,0x1
     ffc:	9a ff ff 00 00       	call   0x0:0xffff
    1001:	c9                   	leave
    1002:	ca 08 00             	retf   0x8
    1005:	03 0b                	add    cx,WORD PTR [bp+di]
    1007:	00 0c                	add    BYTE PTR [si],cl
    1009:	00 00                	add    BYTE PTR [bx+si],al
    100b:	0d 00 00             	or     ax,0x0
    100e:	00 00                	add    BYTE PTR [bx+si],al
    1010:	00 0e 0f 10          	add    BYTE PTR ds:0x100f,cl
    1014:	c3                   	ret
    1015:	55                   	push   bp
    1016:	89 e5                	mov    bp,sp
    1018:	60                   	pusha
    1019:	06                   	push   es
    101a:	1e                   	push   ds
    101b:	8e d8                	mov    ds,ax
    101d:	f7 46 08 00 80       	test   WORD PTR [bp+0x8],0x8000
    1022:	75 77                	jne    0x109b
    1024:	9a ff ff 00 00       	call   0x0:0xffff
    1029:	09 c0                	or     ax,ax
    102b:	74 6a                	je     0x1097
    102d:	3b 06 80 0a          	cmp    ax,WORD PTR ds:0xa80
    1031:	75 64                	jne    0x1097
    1033:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    1036:	3d 0f 00             	cmp    ax,0xf
    1039:	73 60                	jae    0x109b
    103b:	80 3e d8 09 00       	cmp    BYTE PTR ds:0x9d8,0x0
    1040:	75 0a                	jne    0x104c
    1042:	3d 01 00             	cmp    ax,0x1
    1045:	74 54                	je     0x109b
    1047:	3d 03 00             	cmp    ax,0x3
    104a:	74 4f                	je     0x109b
    104c:	bb 05 10             	mov    bx,0x1005
    104f:	2e d7                	xlat   BYTE PTR cs:[bx]
    1051:	09 c0                	or     ax,ax
    1053:	74 42                	je     0x1097
    1055:	50                   	push   ax
    1056:	a1 d4 09             	mov    ax,ds:0x9d4
    1059:	0b 06 d6 09          	or     ax,WORD PTR ds:0x9d6
    105d:	58                   	pop    ax
    105e:	74 17                	je     0x1077
    1060:	ff 76 08             	push   WORD PTR [bp+0x8]
    1063:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1066:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1069:	ff 1e d4 09          	call   DWORD PTR ds:0x9d4
    106d:	08 c0                	or     al,al
    106f:	74 31                	je     0x10a2
    1071:	fe c8                	dec    al
    1073:	74 38                	je     0x10ad
    1075:	eb 24                	jmp    0x109b
    1077:	83 3e 86 0a 00       	cmp    WORD PTR ds:0xa86,0x0
    107c:	75 24                	jne    0x10a2
    107e:	ff 06 86 0a          	inc    WORD PTR ds:0xa86
    1082:	87 46 10             	xchg   WORD PTR [bp+0x10],ax
    1085:	ff 46 0c             	inc    WORD PTR [bp+0xc]
    1088:	89 ec                	mov    sp,bp
    108a:	5d                   	pop    bp
    108b:	83 c4 06             	add    sp,0x6
    108e:	ff 0e 86 0a          	dec    WORD PTR ds:0xa86
    1092:	ea ff ff 00 00       	jmp    0x0:0xffff
    1097:	ff 0e 86 0a          	dec    WORD PTR ds:0xa86
    109b:	1f                   	pop    ds
    109c:	07                   	pop    es
    109d:	61                   	popa
    109e:	89 ec                	mov    sp,bp
    10a0:	5d                   	pop    bp
    10a1:	cb                   	retf
    10a2:	ff 36 80 0a          	push   WORD PTR ds:0xa80
    10a6:	6a 01                	push   0x1
    10a8:	9a ff ff 00 00       	call   0x0:0xffff
    10ad:	1f                   	pop    ds
    10ae:	07                   	pop    es
    10af:	61                   	popa
    10b0:	89 ec                	mov    sp,bp
    10b2:	5d                   	pop    bp
    10b3:	83 c4 0a             	add    sp,0xa
    10b6:	cf                   	iret
    10b7:	cb                   	retf
    10b8:	55                   	push   bp
    10b9:	89 e5                	mov    bp,sp
    10bb:	c4 3e 24 00          	les    di,DWORD PTR ds:0x24
    10bf:	8c c0                	mov    ax,es
    10c1:	09 f8                	or     ax,di
    10c3:	74 07                	je     0x10cc
    10c5:	8a 46 04             	mov    al,BYTE PTR [bp+0x4]
    10c8:	26 88 45 2e          	mov    BYTE PTR es:[di+0x2e],al
    10cc:	c9                   	leave
    10cd:	c2 02 00             	ret    0x2
    10d0:	55                   	push   bp
    10d1:	89 e5                	mov    bp,sp
    10d3:	83 3e 00 0b 00       	cmp    WORD PTR ds:0xb00,0x0
    10d8:	74 6d                	je     0x1147
    10da:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    10de:	74 37                	je     0x1117
    10e0:	a1 82 0a             	mov    ax,ds:0xa82
    10e3:	0b 06 84 0a          	or     ax,WORD PTR ds:0xa84
    10e7:	75 2e                	jne    0x1117
    10e9:	bf 15 10             	mov    di,0x1015
    10ec:	b8 ff ff             	mov    ax,0xffff
    10ef:	50                   	push   ax
    10f0:	57                   	push   di
    10f1:	ff 36 16 0b          	push   WORD PTR ds:0xb16
    10f5:	9a ff ff 00 00       	call   0x0:0xffff
    10fa:	a3 82 0a             	mov    ds:0xa82,ax
    10fd:	89 16 84 0a          	mov    WORD PTR ds:0xa84,dx
    1101:	6a 00                	push   0x0
    1103:	ff 36 84 0a          	push   WORD PTR ds:0xa84
    1107:	ff 36 82 0a          	push   WORD PTR ds:0xa82
    110b:	9a ff ff 00 00       	call   0x0:0xffff
    1110:	6a 01                	push   0x1
    1112:	e8 a3 ff             	call   0x10b8
    1115:	eb 30                	jmp    0x1147
    1117:	80 7e 06 00          	cmp    BYTE PTR [bp+0x6],0x0
    111b:	75 2a                	jne    0x1147
    111d:	a1 82 0a             	mov    ax,ds:0xa82
    1120:	0b 06 84 0a          	or     ax,WORD PTR ds:0xa84
    1124:	74 21                	je     0x1147
    1126:	6a 00                	push   0x0
    1128:	e8 8d ff             	call   0x10b8
    112b:	6a 00                	push   0x0
    112d:	9a ff ff 00 00       	call   0x0:0xffff
    1132:	ff 36 84 0a          	push   WORD PTR ds:0xa84
    1136:	ff 36 82 0a          	push   WORD PTR ds:0xa82
    113a:	9a ff ff 00 00       	call   0x0:0xffff
    113f:	31 c0                	xor    ax,ax
    1141:	a3 82 0a             	mov    ds:0xa82,ax
    1144:	a3 84 0a             	mov    ds:0xa84,ax
    1147:	c9                   	leave
    1148:	ca 02 00             	retf   0x2
    114b:	55                   	push   bp
    114c:	89 e5                	mov    bp,sp
    114e:	6a 00                	push   0x0
    1150:	9a ff ff 00 00       	call   0x0:0xffff
    1155:	a1 ca 0d             	mov    ax,ds:0xdca
    1158:	8b 16 cc 0d          	mov    dx,WORD PTR ds:0xdcc
    115c:	a3 f6 0a             	mov    ds:0xaf6,ax
    115f:	89 16 f8 0a          	mov    WORD PTR ds:0xaf8,dx
    1163:	c9                   	leave
    1164:	cb                   	retf
    1165:	55                   	push   bp
    1166:	89 e5                	mov    bp,sp
    1168:	9a ff ff 00 00       	call   0x0:0xffff
    116d:	a3 80 0a             	mov    ds:0xa80,ax
    1170:	6a 87                	push   0xff87
    1172:	b0 01                	mov    al,0x1
    1174:	50                   	push   ax
    1175:	b8 4c 00             	mov    ax,0x4c
    1178:	ba ff ff             	mov    dx,0xffff
    117b:	52                   	push   dx
    117c:	50                   	push   ax
    117d:	9a ff ff 00 00       	call   0x0:0xffff
    1182:	a3 c6 0d             	mov    ds:0xdc6,ax
    1185:	89 16 c8 0d          	mov    WORD PTR ds:0xdc8,dx
    1189:	b8 5a 0e             	mov    ax,0xe5a
    118c:	ba ff ff             	mov    dx,0xffff
    118f:	a3 ea 0a             	mov    ds:0xaea,ax
    1192:	89 16 ec 0a          	mov    WORD PTR ds:0xaec,dx
    1196:	b8 e5 0f             	mov    ax,0xfe5
    1199:	ba ff ff             	mov    dx,0xffff
    119c:	a3 e6 0a             	mov    ds:0xae6,ax
    119f:	89 16 e8 0a          	mov    WORD PTR ds:0xae8,dx
    11a3:	b8 22 00             	mov    ax,0x22
    11a6:	ba ff ff             	mov    dx,0xffff
    11a9:	a3 ee 0a             	mov    ds:0xaee,ax
    11ac:	89 16 f0 0a          	mov    WORD PTR ds:0xaf0,dx
    11b0:	a1 f6 0a             	mov    ax,ds:0xaf6
    11b3:	8b 16 f8 0a          	mov    dx,WORD PTR ds:0xaf8
    11b7:	a3 ca 0d             	mov    ds:0xdca,ax
    11ba:	89 16 cc 0d          	mov    WORD PTR ds:0xdcc,dx
    11be:	b8 4b 11             	mov    ax,0x114b
    11c1:	ba ff ff             	mov    dx,0xffff
    11c4:	a3 f6 0a             	mov    ds:0xaf6,ax
    11c7:	89 16 f8 0a          	mov    WORD PTR ds:0xaf8,dx
    11cb:	6a 01                	push   0x1
    11cd:	9a ff ff 00 00       	call   0x0:0xffff
    11d2:	c9                   	leave
    11d3:	c3                   	ret
    11d4:	55                   	push   bp
    11d5:	89 e5                	mov    bp,sp
    11d7:	e8 8b ff             	call   0x1165
    11da:	e8 60 f5             	call   0x73d
    11dd:	9a ff ff 00 00       	call   0x0:0xffff
    11e2:	c9                   	leave
    11e3:	cb                   	retf
    11e4:	55                   	push   bp
    11e5:	8b ec                	mov    bp,sp
    11e7:	83 ec 34             	sub    sp,0x34
    11ea:	8c 5e fe             	mov    WORD PTR [bp-0x2],ds
    11ed:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    11f0:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
    11f3:	c5 76 0e             	lds    si,DWORD PTR [bp+0xe]
    11f6:	8b 4e 0c             	mov    cx,WORD PTR [bp+0xc]
    11f9:	c7 46 fc 00 00       	mov    WORD PTR [bp-0x4],0x0
    11fe:	fc                   	cld
    11ff:	0b d2                	or     dx,dx
    1201:	74 0c                	je     0x120f
    1203:	e3 0a                	jcxz   0x120f
    1205:	ac                   	lods   al,BYTE PTR ds:[si]
    1206:	49                   	dec    cx
    1207:	3c 25                	cmp    al,0x25
    1209:	74 12                	je     0x121d
    120b:	aa                   	stos   BYTE PTR es:[di],al
    120c:	4a                   	dec    dx
    120d:	75 f4                	jne    0x1203
    120f:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    1212:	8b c7                	mov    ax,di
    1214:	2b 46 14             	sub    ax,WORD PTR [bp+0x14]
    1217:	8b e5                	mov    sp,bp
    1219:	5d                   	pop    bp
    121a:	ca 12 00             	retf   0x12
    121d:	e3 f0                	jcxz   0x120f
    121f:	ac                   	lods   al,BYTE PTR ds:[si]
    1220:	49                   	dec    cx
    1221:	3c 25                	cmp    al,0x25
    1223:	74 e6                	je     0x120b
    1225:	8d 5c fe             	lea    bx,[si-0x2]
    1228:	89 5e f4             	mov    WORD PTR [bp-0xc],bx
    122b:	88 46 f6             	mov    BYTE PTR [bp-0xa],al
    122e:	3c 2d                	cmp    al,0x2d
    1230:	75 04                	jne    0x1236
    1232:	e3 db                	jcxz   0x120f
    1234:	ac                   	lods   al,BYTE PTR ds:[si]
    1235:	49                   	dec    cx
    1236:	e8 60 00             	call   0x1299
    1239:	3c 3a                	cmp    al,0x3a
    123b:	75 05                	jne    0x1242
    123d:	89 5e fc             	mov    WORD PTR [bp-0x4],bx
    1240:	eb db                	jmp    0x121d
    1242:	89 5e fa             	mov    WORD PTR [bp-0x6],bx
    1245:	bb ff ff             	mov    bx,0xffff
    1248:	3c 2e                	cmp    al,0x2e
    124a:	75 07                	jne    0x1253
    124c:	e3 c1                	jcxz   0x120f
    124e:	ac                   	lods   al,BYTE PTR ds:[si]
    124f:	49                   	dec    cx
    1250:	e8 46 00             	call   0x1299
    1253:	89 5e f8             	mov    WORD PTR [bp-0x8],bx
    1256:	89 76 0e             	mov    WORD PTR [bp+0xe],si
    1259:	51                   	push   cx
    125a:	52                   	push   dx
    125b:	e8 8c 00             	call   0x12ea
    125e:	5a                   	pop    dx
    125f:	8b 5e fa             	mov    bx,WORD PTR [bp-0x6]
    1262:	2b d9                	sub    bx,cx
    1264:	73 02                	jae    0x1268
    1266:	33 db                	xor    bx,bx
    1268:	80 7e f6 2d          	cmp    BYTE PTR [bp-0xa],0x2d
    126c:	75 0a                	jne    0x1278
    126e:	2b d1                	sub    dx,cx
    1270:	73 04                	jae    0x1276
    1272:	03 ca                	add    cx,dx
    1274:	33 d2                	xor    dx,dx
    1276:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1278:	87 d9                	xchg   cx,bx
    127a:	2b d1                	sub    dx,cx
    127c:	73 04                	jae    0x1282
    127e:	03 ca                	add    cx,dx
    1280:	33 d2                	xor    dx,dx
    1282:	b0 20                	mov    al,0x20
    1284:	f3 aa                	rep stos BYTE PTR es:[di],al
    1286:	87 d9                	xchg   cx,bx
    1288:	2b d1                	sub    dx,cx
    128a:	73 04                	jae    0x1290
    128c:	03 ca                	add    cx,dx
    128e:	33 d2                	xor    dx,dx
    1290:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    1292:	59                   	pop    cx
    1293:	c5 76 0e             	lds    si,DWORD PTR [bp+0xe]
    1296:	e9 66 ff             	jmp    0x11ff
    1299:	33 db                	xor    bx,bx
    129b:	3c 2a                	cmp    al,0x2a
    129d:	74 20                	je     0x12bf
    129f:	3c 30                	cmp    al,0x30
    12a1:	72 42                	jb     0x12e5
    12a3:	3c 39                	cmp    al,0x39
    12a5:	77 3e                	ja     0x12e5
    12a7:	2c 30                	sub    al,0x30
    12a9:	32 e4                	xor    ah,ah
    12ab:	50                   	push   ax
    12ac:	d1 e3                	shl    bx,1
    12ae:	8b c3                	mov    ax,bx
    12b0:	d1 e3                	shl    bx,1
    12b2:	d1 e3                	shl    bx,1
    12b4:	03 d8                	add    bx,ax
    12b6:	58                   	pop    ax
    12b7:	03 d8                	add    bx,ax
    12b9:	e3 2b                	jcxz   0x12e6
    12bb:	ac                   	lods   al,BYTE PTR ds:[si]
    12bc:	49                   	dec    cx
    12bd:	eb e0                	jmp    0x129f
    12bf:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    12c2:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
    12c5:	77 1a                	ja     0x12e1
    12c7:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    12ca:	d1 e0                	shl    ax,1
    12cc:	d1 e0                	shl    ax,1
    12ce:	d1 e0                	shl    ax,1
    12d0:	1e                   	push   ds
    12d1:	56                   	push   si
    12d2:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
    12d5:	03 f0                	add    si,ax
    12d7:	80 7c 04 00          	cmp    BYTE PTR [si+0x4],0x0
    12db:	75 02                	jne    0x12df
    12dd:	8b 1c                	mov    bx,WORD PTR [si]
    12df:	5e                   	pop    si
    12e0:	1f                   	pop    ds
    12e1:	e3 03                	jcxz   0x12e6
    12e3:	ac                   	lods   al,BYTE PTR ds:[si]
    12e4:	49                   	dec    cx
    12e5:	c3                   	ret
    12e6:	58                   	pop    ax
    12e7:	e9 25 ff             	jmp    0x120f
    12ea:	24 df                	and    al,0xdf
    12ec:	8a c8                	mov    cl,al
    12ee:	b8 01 00             	mov    ax,0x1
    12f1:	8b 5e fc             	mov    bx,WORD PTR [bp-0x4]
    12f4:	3b 5e 06             	cmp    bx,WORD PTR [bp+0x6]
    12f7:	77 33                	ja     0x132c
    12f9:	ff 46 fc             	inc    WORD PTR [bp-0x4]
    12fc:	d1 e3                	shl    bx,1
    12fe:	d1 e3                	shl    bx,1
    1300:	d1 e3                	shl    bx,1
    1302:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
    1305:	03 f3                	add    si,bx
    1307:	8b 04                	mov    ax,WORD PTR [si]
    1309:	8b 54 02             	mov    dx,WORD PTR [si+0x2]
    130c:	8a 5c 04             	mov    bl,BYTE PTR [si+0x4]
    130f:	32 ff                	xor    bh,bh
    1311:	d1 e3                	shl    bx,1
    1313:	2e ff a7 18 13       	jmp    WORD PTR cs:[bx+0x1318]
    1318:	40                   	inc    ax
    1319:	13 2a                	adc    bp,WORD PTR [bp+si]
    131b:	13 ae 13 16          	adc    bp,WORD PTR [bp+0x1613]
    131f:	14 b7                	adc    al,0xb7
    1321:	13 f4                	adc    si,sp
    1323:	13 d2                	adc    dx,dx
    1325:	13 2a                	adc    bp,WORD PTR [bp+si]
    1327:	13 2a                	adc    bp,WORD PTR [bp+si]
    1329:	13 33                	adc    si,WORD PTR [bp+di]
    132b:	c0 8e 5e fe 50       	ror    BYTE PTR [bp-0x1a2],0x50
    1330:	ff 76 10             	push   WORD PTR [bp+0x10]
    1333:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1336:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    1339:	2b 46 f4             	sub    ax,WORD PTR [bp-0xc]
    133c:	50                   	push   ax
    133d:	e8 68 f2             	call   0x5a8
    1340:	80 f9 44             	cmp    cl,0x44
    1343:	74 0f                	je     0x1354
    1345:	80 f9 55             	cmp    cl,0x55
    1348:	74 1f                	je     0x1369
    134a:	80 f9 58             	cmp    cl,0x58
    134d:	75 db                	jne    0x132a
    134f:	b9 10 00             	mov    cx,0x10
    1352:	eb 18                	jmp    0x136c
    1354:	0b d2                	or     dx,dx
    1356:	79 11                	jns    0x1369
    1358:	f7 da                	neg    dx
    135a:	f7 d8                	neg    ax
    135c:	83 da 00             	sbb    dx,0x0
    135f:	e8 07 00             	call   0x1369
    1362:	b0 2d                	mov    al,0x2d
    1364:	41                   	inc    cx
    1365:	4e                   	dec    si
    1366:	88 04                	mov    BYTE PTR [si],al
    1368:	c3                   	ret
    1369:	b9 0a 00             	mov    cx,0xa
    136c:	8d 76 dc             	lea    si,[bp-0x24]
    136f:	8c d3                	mov    bx,ss
    1371:	8e db                	mov    ds,bx
    1373:	8b da                	mov    bx,dx
    1375:	33 d2                	xor    dx,dx
    1377:	93                   	xchg   bx,ax
    1378:	f7 f1                	div    cx
    137a:	93                   	xchg   bx,ax
    137b:	f7 f1                	div    cx
    137d:	80 c2 30             	add    dl,0x30
    1380:	80 fa 3a             	cmp    dl,0x3a
    1383:	72 03                	jb     0x1388
    1385:	80 c2 07             	add    dl,0x7
    1388:	4e                   	dec    si
    1389:	88 14                	mov    BYTE PTR [si],dl
    138b:	8b d0                	mov    dx,ax
    138d:	0b d3                	or     dx,bx
    138f:	75 e4                	jne    0x1375
    1391:	8d 4e dc             	lea    cx,[bp-0x24]
    1394:	2b ce                	sub    cx,si
    1396:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    1399:	83 fa 10             	cmp    dx,0x10
    139c:	72 01                	jb     0x139f
    139e:	c3                   	ret
    139f:	2b d1                	sub    dx,cx
    13a1:	76 0a                	jbe    0x13ad
    13a3:	03 ca                	add    cx,dx
    13a5:	b0 30                	mov    al,0x30
    13a7:	4e                   	dec    si
    13a8:	88 04                	mov    BYTE PTR [si],al
    13aa:	4a                   	dec    dx
    13ab:	75 fa                	jne    0x13a7
    13ad:	c3                   	ret
    13ae:	80 f9 53             	cmp    cl,0x53
    13b1:	75 1c                	jne    0x13cf
    13b3:	b9 01 00             	mov    cx,0x1
    13b6:	c3                   	ret
    13b7:	80 f9 53             	cmp    cl,0x53
    13ba:	75 13                	jne    0x13cf
    13bc:	8b f0                	mov    si,ax
    13be:	8e da                	mov    ds,dx
    13c0:	ac                   	lods   al,BYTE PTR ds:[si]
    13c1:	8a c8                	mov    cl,al
    13c3:	32 ed                	xor    ch,ch
    13c5:	3b 4e f8             	cmp    cx,WORD PTR [bp-0x8]
    13c8:	77 01                	ja     0x13cb
    13ca:	c3                   	ret
    13cb:	8b 4e f8             	mov    cx,WORD PTR [bp-0x8]
    13ce:	c3                   	ret
    13cf:	e9 58 ff             	jmp    0x132a
    13d2:	80 f9 53             	cmp    cl,0x53
    13d5:	75 f8                	jne    0x13cf
    13d7:	8b f0                	mov    si,ax
    13d9:	8e da                	mov    ds,dx
    13db:	06                   	push   es
    13dc:	57                   	push   di
    13dd:	8b f8                	mov    di,ax
    13df:	8e c2                	mov    es,dx
    13e1:	32 c0                	xor    al,al
    13e3:	8b 4e f8             	mov    cx,WORD PTR [bp-0x8]
    13e6:	e3 05                	jcxz   0x13ed
    13e8:	f2 ae                	repnz scas al,BYTE PTR es:[di]
    13ea:	75 01                	jne    0x13ed
    13ec:	4f                   	dec    di
    13ed:	8b cf                	mov    cx,di
    13ef:	2b ce                	sub    cx,si
    13f1:	5f                   	pop    di
    13f2:	07                   	pop    es
    13f3:	c3                   	ret
    13f4:	80 f9 50             	cmp    cl,0x50
    13f7:	75 d6                	jne    0x13cf
    13f9:	c7 46 f8 08 00       	mov    WORD PTR [bp-0x8],0x8
    13fe:	b9 10 00             	mov    cx,0x10
    1401:	e8 68 ff             	call   0x136c
    1404:	41                   	inc    cx
    1405:	4e                   	dec    si
    1406:	8b 44 01             	mov    ax,WORD PTR [si+0x1]
    1409:	89 04                	mov    WORD PTR [si],ax
    140b:	8b 44 03             	mov    ax,WORD PTR [si+0x3]
    140e:	89 44 02             	mov    WORD PTR [si+0x2],ax
    1411:	c6 44 04 3a          	mov    BYTE PTR [si+0x4],0x3a
    1415:	c3                   	ret
    1416:	8b f0                	mov    si,ax
    1418:	8e da                	mov    ds,dx
    141a:	b3 00                	mov    bl,0x0
    141c:	80 f9 47             	cmp    cl,0x47
    141f:	74 39                	je     0x145a
    1421:	b3 01                	mov    bl,0x1
    1423:	80 f9 45             	cmp    cl,0x45
    1426:	74 32                	je     0x145a
    1428:	b3 02                	mov    bl,0x2
    142a:	80 f9 46             	cmp    cl,0x46
    142d:	74 0e                	je     0x143d
    142f:	b3 03                	mov    bl,0x3
    1431:	80 f9 4e             	cmp    cl,0x4e
    1434:	74 07                	je     0x143d
    1436:	80 f9 4d             	cmp    cl,0x4d
    1439:	75 94                	jne    0x13cf
    143b:	b3 04                	mov    bl,0x4
    143d:	b8 12 00             	mov    ax,0x12
    1440:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    1443:	3b d0                	cmp    dx,ax
    1445:	76 21                	jbe    0x1468
    1447:	ba 02 00             	mov    dx,0x2
    144a:	80 f9 4d             	cmp    cl,0x4d
    144d:	75 19                	jne    0x1468
    144f:	1e                   	push   ds
    1450:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    1453:	8a 16 8a 0b          	mov    dl,BYTE PTR ds:0xb8a
    1457:	1f                   	pop    ds
    1458:	eb 0e                	jmp    0x1468
    145a:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    145d:	ba 03 00             	mov    dx,0x3
    1460:	3d 12 00             	cmp    ax,0x12
    1463:	76 03                	jbe    0x1468
    1465:	b8 0f 00             	mov    ax,0xf
    1468:	06                   	push   es
    1469:	57                   	push   di
    146a:	8d 7e cc             	lea    di,[bp-0x34]
    146d:	16                   	push   ss
    146e:	57                   	push   di
    146f:	ff 74 08             	push   WORD PTR [si+0x8]
    1472:	ff 74 06             	push   WORD PTR [si+0x6]
    1475:	ff 74 04             	push   WORD PTR [si+0x4]
    1478:	ff 74 02             	push   WORD PTR [si+0x2]
    147b:	ff 34                	push   WORD PTR [si]
    147d:	53                   	push   bx
    147e:	50                   	push   ax
    147f:	52                   	push   dx
    1480:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    1483:	9a ff ff 00 00       	call   0x0:0xffff
    1488:	8b c8                	mov    cx,ax
    148a:	8d 76 cc             	lea    si,[bp-0x34]
    148d:	16                   	push   ss
    148e:	1f                   	pop    ds
    148f:	5f                   	pop    di
    1490:	07                   	pop    es
    1491:	c3                   	ret
    1492:	0a 00                	or     al,BYTE PTR [bx+si]
    1494:	01 00                	add    WORD PTR [bx+si],ax
    1496:	00 00                	add    BYTE PTR [bx+si],al
    1498:	0a 00                	or     al,BYTE PTR [bx+si]
    149a:	00 00                	add    BYTE PTR [bx+si],al
    149c:	64 00 00             	add    BYTE PTR fs:[bx+si],al
    149f:	00 e8                	add    al,ch
    14a1:	03 00                	add    ax,WORD PTR [bx+si]
    14a3:	00 10                	add    BYTE PTR [bx+si],dl
    14a5:	27                   	daa
    14a6:	00 00                	add    BYTE PTR [bx+si],al
    14a8:	a0 86 01             	mov    al,ds:0x186
    14ab:	00 40 42             	add    BYTE PTR [bx+si+0x42],al
    14ae:	0f 00 80 96 98       	sldt   WORD PTR [bx+si-0x676a]
    14b3:	00 00                	add    BYTE PTR [bx+si],al
    14b5:	00 00                	add    BYTE PTR [bx+si],al
    14b7:	00 00                	add    BYTE PTR [bx+si],al
    14b9:	20 bc be 19          	and    BYTE PTR [si+0x19be],bh
    14bd:	40                   	inc    ax
    14be:	00 00                	add    BYTE PTR [bx+si],al
    14c0:	00 04                	add    BYTE PTR [si],al
    14c2:	bf c9 1b             	mov    di,0x1bc9
    14c5:	8e 34                	mov    ?,WORD PTR [si]
    14c7:	40                   	inc    ax
    14c8:	9e                   	sahf
    14c9:	b5 70                	mov    ch,0x70
    14cb:	2b a8 ad c5          	sub    bp,WORD PTR [bx+si-0x3a53]
    14cf:	9d                   	popf
    14d0:	69 40 d5 a6 cf       	imul   ax,WORD PTR [bx+si-0x2b],0xcfa6
    14d5:	ff 49 1f             	dec    WORD PTR [bx+di+0x1f]
    14d8:	78 c2                	js     0x149c
    14da:	d3 40 e0             	rol    WORD PTR [bx+si-0x20],cl
    14dd:	8c e9                	mov    cx,gs
    14df:	80 c9 47             	or     cl,0x47
    14e2:	ba 93 a8             	mov    dx,0xa893
    14e5:	41                   	inc    cx
    14e6:	8e de                	mov    ds,si
    14e8:	f9                   	stc
    14e9:	9d                   	popf
    14ea:	fb                   	sti
    14eb:	eb 7e                	jmp    0x156b
    14ed:	aa                   	stos   BYTE PTR es:[di],al
    14ee:	51                   	push   cx
    14ef:	43                   	inc    bx
    14f0:	c7                   	(bad)
    14f1:	91                   	xchg   cx,ax
    14f2:	0e                   	push   cs
    14f3:	a6                   	cmps   BYTE PTR ds:[si],BYTE PTR es:[di]
    14f4:	ae                   	scas   al,BYTE PTR es:[di]
    14f5:	a0 19 e3             	mov    al,ds:0xe319
    14f8:	a3 46 17             	mov    ds:0x1746,ax
    14fb:	0c 75                	or     al,0x75
    14fd:	81 86 75 76 c9 48    	add    WORD PTR [bp+0x7675],0x48c9
    1503:	4d                   	dec    bp
    1504:	e5 5d                	in     ax,0x5d
    1506:	3d c5 5d             	cmp    ax,0x5dc5
    1509:	3b 8b 9e 92          	cmp    cx,WORD PTR [bp+di-0x6d62]
    150d:	5a                   	pop    dx
    150e:	9b                   	fwait
    150f:	97                   	xchg   di,ax
    1510:	20 8a 02 52          	and    BYTE PTR [bp+si+0x5202],cl
    1514:	60                   	pusha
    1515:	c4 25                	les    sp,DWORD PTR [di]
    1517:	75 00                	jne    0x1519
    1519:	00 40 76             	add    BYTE PTR [bx+si+0x76],al
    151c:	3a 6b 0b             	cmp    ch,BYTE PTR [bp+di+0xb]
    151f:	de 3a                	fidivr WORD PTR [bp+si]
    1521:	40                   	inc    ax
    1522:	00 00                	add    BYTE PTR [bx+si],al
    1524:	00 00                	add    BYTE PTR [bx+si],al
    1526:	00 00                	add    BYTE PTR [bx+si],al
    1528:	00 80 ff 7f          	add    BYTE PTR [bx+si+0x7fff],al
    152c:	3f                   	aas
    152d:	13 4e 41             	adc    cx,WORD PTR [bp+0x41]
    1530:	4e                   	dec    si
    1531:	49                   	dec    cx
    1532:	4e                   	dec    si
    1533:	46                   	inc    si
    1534:	55                   	push   bp
    1535:	8b ec                	mov    bp,sp
    1537:	83 ec 1c             	sub    sp,0x1c
    153a:	8c 5e fe             	mov    WORD PTR [bp-0x2],ds
    153d:	a1 86 0b             	mov    ax,ds:0xb86
    1540:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1543:	a1 88 0b             	mov    ax,ds:0xb88
    1546:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1549:	83 7e 08 02          	cmp    WORD PTR [bp+0x8],0x2
    154d:	7d 05                	jge    0x1554
    154f:	c7 46 08 02 00       	mov    WORD PTR [bp+0x8],0x2
    1554:	83 7e 08 12          	cmp    WORD PTR [bp+0x8],0x12
    1558:	7e 05                	jle    0x155f
    155a:	c7 46 08 12 00       	mov    WORD PTR [bp+0x8],0x12
    155f:	8d 46 e4             	lea    ax,[bp-0x1c]
    1562:	16                   	push   ss
    1563:	50                   	push   ax
    1564:	ff 76 14             	push   WORD PTR [bp+0x14]
    1567:	ff 76 12             	push   WORD PTR [bp+0x12]
    156a:	ff 76 10             	push   WORD PTR [bp+0x10]
    156d:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1570:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1573:	ff 76 08             	push   WORD PTR [bp+0x8]
    1576:	b8 0f 27             	mov    ax,0x270f
    1579:	80 7e 0a 02          	cmp    BYTE PTR [bp+0xa],0x2
    157d:	72 03                	jb     0x1582
    157f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1582:	50                   	push   ax
    1583:	0e                   	push   cs
    1584:	e8 d7 04             	call   0x1a5e
    1587:	1e                   	push   ds
    1588:	c4 7e 16             	les    di,DWORD PTR [bp+0x16]
    158b:	fc                   	cld
    158c:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    158f:	2d ff 7f             	sub    ax,0x7fff
    1592:	3d 02 00             	cmp    ax,0x2
    1595:	73 12                	jae    0x15a9
    1597:	be 2e 15             	mov    si,0x152e
    159a:	0e                   	push   cs
    159b:	1f                   	pop    ds
    159c:	03 f0                	add    si,ax
    159e:	03 f0                	add    si,ax
    15a0:	03 f0                	add    si,ax
    15a2:	b9 03 00             	mov    cx,0x3
    15a5:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    15a7:	eb 25                	jmp    0x15ce
    15a9:	8d 76 e7             	lea    si,[bp-0x19]
    15ac:	16                   	push   ss
    15ad:	1f                   	pop    ds
    15ae:	8a 5e 0a             	mov    bl,BYTE PTR [bp+0xa]
    15b1:	80 fb 01             	cmp    bl,0x1
    15b4:	74 0f                	je     0x15c5
    15b6:	80 fb 04             	cmp    bl,0x4
    15b9:	77 08                	ja     0x15c3
    15bb:	8b 46 e4             	mov    ax,WORD PTR [bp-0x1c]
    15be:	3b 46 08             	cmp    ax,WORD PTR [bp+0x8]
    15c1:	7e 02                	jle    0x15c5
    15c3:	b3 00                	mov    bl,0x0
    15c5:	32 ff                	xor    bh,bh
    15c7:	03 db                	add    bx,bx
    15c9:	2e ff 97 dc 15       	call   WORD PTR cs:[bx+0x15dc]
    15ce:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    15d1:	8b c7                	mov    ax,di
    15d3:	2b 46 16             	sub    ax,WORD PTR [bp+0x16]
    15d6:	8b e5                	mov    sp,bp
    15d8:	5d                   	pop    bp
    15d9:	ca 14 00             	retf   0x14
    15dc:	f9                   	stc
    15dd:	15 52 16             	adc    ax,0x1652
    15e0:	bf 16 bf             	mov    di,0xbf16
    15e3:	16                   	push   ss
    15e4:	18 17                	sbb    BYTE PTR [bx],dl
    15e6:	ac                   	lods   al,BYTE PTR ds:[si]
    15e7:	0a c0                	or     al,al
    15e9:	75 03                	jne    0x15ee
    15eb:	b0 30                	mov    al,0x30
    15ed:	4e                   	dec    si
    15ee:	c3                   	ret
    15ef:	80 7e e6 00          	cmp    BYTE PTR [bp-0x1a],0x0
    15f3:	74 03                	je     0x15f8
    15f5:	b0 2d                	mov    al,0x2d
    15f7:	aa                   	stos   BYTE PTR es:[di],al
    15f8:	c3                   	ret
    15f9:	e8 f3 ff             	call   0x15ef
    15fc:	8b 4e e4             	mov    cx,WORD PTR [bp-0x1c]
    15ff:	33 d2                	xor    dx,dx
    1601:	3b 4e 08             	cmp    cx,WORD PTR [bp+0x8]
    1604:	7f 1d                	jg     0x1623
    1606:	83 f9 fd             	cmp    cx,0xfffd
    1609:	7c 18                	jl     0x1623
    160b:	0b c9                	or     cx,cx
    160d:	7f 18                	jg     0x1627
    160f:	b0 30                	mov    al,0x30
    1611:	aa                   	stos   BYTE PTR es:[di],al
    1612:	80 3c 00             	cmp    BYTE PTR [si],0x0
    1615:	74 3a                	je     0x1651
    1617:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    161a:	aa                   	stos   BYTE PTR es:[di],al
    161b:	f7 d9                	neg    cx
    161d:	b0 30                	mov    al,0x30
    161f:	f3 aa                	rep stos BYTE PTR es:[di],al
    1621:	eb 17                	jmp    0x163a
    1623:	b9 01 00             	mov    cx,0x1
    1626:	42                   	inc    dx
    1627:	ac                   	lods   al,BYTE PTR ds:[si]
    1628:	0a c0                	or     al,al
    162a:	74 16                	je     0x1642
    162c:	aa                   	stos   BYTE PTR es:[di],al
    162d:	e2 f8                	loop   0x1627
    162f:	ac                   	lods   al,BYTE PTR ds:[si]
    1630:	0a c0                	or     al,al
    1632:	74 12                	je     0x1646
    1634:	8a e0                	mov    ah,al
    1636:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    1639:	ab                   	stos   WORD PTR es:[di],ax
    163a:	ac                   	lods   al,BYTE PTR ds:[si]
    163b:	0a c0                	or     al,al
    163d:	74 07                	je     0x1646
    163f:	aa                   	stos   BYTE PTR es:[di],al
    1640:	eb f8                	jmp    0x163a
    1642:	b0 30                	mov    al,0x30
    1644:	f3 aa                	rep stos BYTE PTR es:[di],al
    1646:	0b d2                	or     dx,dx
    1648:	74 07                	je     0x1651
    164a:	32 e4                	xor    ah,ah
    164c:	33 c9                	xor    cx,cx
    164e:	eb 22                	jmp    0x1672
    1650:	90                   	nop
    1651:	c3                   	ret
    1652:	e8 9a ff             	call   0x15ef
    1655:	e8 8e ff             	call   0x15e6
    1658:	8a 66 fb             	mov    ah,BYTE PTR [bp-0x5]
    165b:	ab                   	stos   WORD PTR es:[di],ax
    165c:	8b 4e 08             	mov    cx,WORD PTR [bp+0x8]
    165f:	49                   	dec    cx
    1660:	e8 83 ff             	call   0x15e6
    1663:	aa                   	stos   BYTE PTR es:[di],al
    1664:	e2 fa                	loop   0x1660
    1666:	b4 2b                	mov    ah,0x2b
    1668:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
    166b:	83 f9 04             	cmp    cx,0x4
    166e:	72 02                	jb     0x1672
    1670:	33 c9                	xor    cx,cx
    1672:	b0 45                	mov    al,0x45
    1674:	8a 5e e7             	mov    bl,BYTE PTR [bp-0x19]
    1677:	8b 56 e4             	mov    dx,WORD PTR [bp-0x1c]
    167a:	4a                   	dec    dx
    167b:	aa                   	stos   BYTE PTR es:[di],al
    167c:	0a db                	or     bl,bl
    167e:	75 04                	jne    0x1684
    1680:	33 d2                	xor    dx,dx
    1682:	eb 0a                	jmp    0x168e
    1684:	0b d2                	or     dx,dx
    1686:	7d 06                	jge    0x168e
    1688:	b0 2d                	mov    al,0x2d
    168a:	f7 da                	neg    dx
    168c:	eb 06                	jmp    0x1694
    168e:	0a e4                	or     ah,ah
    1690:	74 03                	je     0x1695
    1692:	8a c4                	mov    al,ah
    1694:	aa                   	stos   BYTE PTR es:[di],al
    1695:	92                   	xchg   dx,ax
    1696:	83 ec 04             	sub    sp,0x4
    1699:	8b dc                	mov    bx,sp
    169b:	33 d2                	xor    dx,dx
    169d:	2e f7 36 92 14       	div    WORD PTR cs:0x1492
    16a2:	80 c2 30             	add    dl,0x30
    16a5:	36 88 17             	mov    BYTE PTR ss:[bx],dl
    16a8:	43                   	inc    bx
    16a9:	49                   	dec    cx
    16aa:	0b c0                	or     ax,ax
    16ac:	75 ed                	jne    0x169b
    16ae:	0b c9                	or     cx,cx
    16b0:	7f e9                	jg     0x169b
    16b2:	4b                   	dec    bx
    16b3:	36 8a 07             	mov    al,BYTE PTR ss:[bx]
    16b6:	aa                   	stos   BYTE PTR es:[di],al
    16b7:	3b dc                	cmp    bx,sp
    16b9:	75 f7                	jne    0x16b2
    16bb:	83 c4 04             	add    sp,0x4
    16be:	c3                   	ret
    16bf:	e8 2d ff             	call   0x15ef
    16c2:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    16c5:	83 fa 12             	cmp    dx,0x12
    16c8:	72 03                	jb     0x16cd
    16ca:	ba 12 00             	mov    dx,0x12
    16cd:	8b 4e e4             	mov    cx,WORD PTR [bp-0x1c]
    16d0:	0b c9                	or     cx,cx
    16d2:	7f 05                	jg     0x16d9
    16d4:	b0 30                	mov    al,0x30
    16d6:	aa                   	stos   BYTE PTR es:[di],al
    16d7:	eb 24                	jmp    0x16fd
    16d9:	33 db                	xor    bx,bx
    16db:	80 7e 0a 02          	cmp    BYTE PTR [bp+0xa],0x2
    16df:	74 0a                	je     0x16eb
    16e1:	8b c1                	mov    ax,cx
    16e3:	48                   	dec    ax
    16e4:	b3 03                	mov    bl,0x3
    16e6:	f6 f3                	div    bl
    16e8:	8a dc                	mov    bl,ah
    16ea:	43                   	inc    bx
    16eb:	e8 f8 fe             	call   0x15e6
    16ee:	aa                   	stos   BYTE PTR es:[di],al
    16ef:	49                   	dec    cx
    16f0:	74 0b                	je     0x16fd
    16f2:	4b                   	dec    bx
    16f3:	75 f6                	jne    0x16eb
    16f5:	8a 46 fa             	mov    al,BYTE PTR [bp-0x6]
    16f8:	aa                   	stos   BYTE PTR es:[di],al
    16f9:	b3 03                	mov    bl,0x3
    16fb:	eb ee                	jmp    0x16eb
    16fd:	0b d2                	or     dx,dx
    16ff:	74 16                	je     0x1717
    1701:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    1704:	aa                   	stos   BYTE PTR es:[di],al
    1705:	e3 09                	jcxz   0x1710
    1707:	b0 30                	mov    al,0x30
    1709:	aa                   	stos   BYTE PTR es:[di],al
    170a:	4a                   	dec    dx
    170b:	74 0a                	je     0x1717
    170d:	41                   	inc    cx
    170e:	75 f9                	jne    0x1709
    1710:	e8 d3 fe             	call   0x15e6
    1713:	aa                   	stos   BYTE PTR es:[di],al
    1714:	4a                   	dec    dx
    1715:	75 f9                	jne    0x1710
    1717:	c3                   	ret
    1718:	8a 5e fc             	mov    bl,BYTE PTR [bp-0x4]
    171b:	b9 03 00             	mov    cx,0x3
    171e:	80 7e e6 00          	cmp    BYTE PTR [bp-0x1a],0x0
    1722:	74 06                	je     0x172a
    1724:	8a 5e fd             	mov    bl,BYTE PTR [bp-0x3]
    1727:	b9 0a 04             	mov    cx,0x40a
    172a:	3a d9                	cmp    bl,cl
    172c:	76 02                	jbe    0x1730
    172e:	8a d9                	mov    bl,cl
    1730:	02 dd                	add    bl,ch
    1732:	32 ff                	xor    bh,bh
    1734:	d1 e3                	shl    bx,1
    1736:	d1 e3                	shl    bx,1
    1738:	b9 04 00             	mov    cx,0x4
    173b:	2e 8a 87 71 17       	mov    al,BYTE PTR cs:[bx+0x1771]
    1740:	3c 40                	cmp    al,0x40
    1742:	74 1a                	je     0x175e
    1744:	51                   	push   cx
    1745:	53                   	push   bx
    1746:	3c 24                	cmp    al,0x24
    1748:	74 07                	je     0x1751
    174a:	3c 2a                	cmp    al,0x2a
    174c:	74 08                	je     0x1756
    174e:	aa                   	stos   BYTE PTR es:[di],al
    174f:	eb 08                	jmp    0x1759
    1751:	e8 0b 00             	call   0x175f
    1754:	eb 03                	jmp    0x1759
    1756:	e8 69 ff             	call   0x16c2
    1759:	5b                   	pop    bx
    175a:	59                   	pop    cx
    175b:	43                   	inc    bx
    175c:	e2 dd                	loop   0x173b
    175e:	c3                   	ret
    175f:	1e                   	push   ds
    1760:	56                   	push   si
    1761:	8e 5e fe             	mov    ds,WORD PTR [bp-0x2]
    1764:	be 7e 0b             	mov    si,0xb7e
    1767:	ac                   	lods   al,BYTE PTR ds:[si]
    1768:	8a c8                	mov    cl,al
    176a:	32 ed                	xor    ch,ch
    176c:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    176e:	5e                   	pop    si
    176f:	1f                   	pop    ds
    1770:	c3                   	ret
    1771:	24 2a                	and    al,0x2a
    1773:	40                   	inc    ax
    1774:	40                   	inc    ax
    1775:	2a 24                	sub    ah,BYTE PTR [si]
    1777:	40                   	inc    ax
    1778:	40                   	inc    ax
    1779:	24 20                	and    al,0x20
    177b:	2a 40 2a             	sub    al,BYTE PTR [bx+si+0x2a]
    177e:	20 24                	and    BYTE PTR [si],ah
    1780:	40                   	inc    ax
    1781:	28 24                	sub    BYTE PTR [si],ah
    1783:	2a 29                	sub    ch,BYTE PTR [bx+di]
    1785:	2d 24 2a             	sub    ax,0x2a24
    1788:	40                   	inc    ax
    1789:	24 2d                	and    al,0x2d
    178b:	2a 40 24             	sub    al,BYTE PTR [bx+si+0x24]
    178e:	2a 2d                	sub    ch,BYTE PTR [di]
    1790:	40                   	inc    ax
    1791:	28 2a                	sub    BYTE PTR [bp+si],ch
    1793:	24 29                	and    al,0x29
    1795:	2d 2a 24             	sub    ax,0x242a
    1798:	40                   	inc    ax
    1799:	2a 2d                	sub    ch,BYTE PTR [di]
    179b:	24 40                	and    al,0x40
    179d:	2a 24                	sub    ah,BYTE PTR [si]
    179f:	2d 40 2d             	sub    ax,0x2d40
    17a2:	2a 20                	sub    ah,BYTE PTR [bx+si]
    17a4:	24 2d                	and    al,0x2d
    17a6:	24 20                	and    al,0x20
    17a8:	2a 24                	sub    ah,BYTE PTR [si]
    17aa:	20 2a                	and    BYTE PTR [bp+si],ch
    17ac:	2d 55 8b             	sub    ax,0x8b55
    17af:	ec                   	in     al,dx
    17b0:	83 ec 28             	sub    sp,0x28
    17b3:	fc                   	cld
    17b4:	a1 88 0b             	mov    ax,ds:0xb88
    17b7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    17ba:	b9 02 00             	mov    cx,0x2
    17bd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    17c0:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    17c3:	0b 46 0e             	or     ax,WORD PTR [bp+0xe]
    17c6:	0b 46 10             	or     ax,WORD PTR [bp+0x10]
    17c9:	0b 46 12             	or     ax,WORD PTR [bp+0x12]
    17cc:	74 06                	je     0x17d4
    17ce:	8b 4e 12             	mov    cx,WORD PTR [bp+0x12]
    17d1:	c1 e9 0f             	shr    cx,0xf
    17d4:	e8 8e 00             	call   0x1865
    17d7:	74 4c                	je     0x1825
    17d9:	89 76 fa             	mov    WORD PTR [bp-0x6],si
    17dc:	e8 c3 00             	call   0x18a2
    17df:	8d 46 d8             	lea    ax,[bp-0x28]
    17e2:	16                   	push   ss
    17e3:	50                   	push   ax
    17e4:	ff 76 12             	push   WORD PTR [bp+0x12]
    17e7:	ff 76 10             	push   WORD PTR [bp+0x10]
    17ea:	ff 76 0e             	push   WORD PTR [bp+0xe]
    17ed:	ff 76 0c             	push   WORD PTR [bp+0xc]
    17f0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    17f3:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    17f6:	ba 0f 27             	mov    dx,0x270f
    17f9:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    17fd:	75 08                	jne    0x1807
    17ff:	2b 46 f6             	sub    ax,WORD PTR [bp-0xa]
    1802:	8b d0                	mov    dx,ax
    1804:	b8 12 00             	mov    ax,0x12
    1807:	50                   	push   ax
    1808:	52                   	push   dx
    1809:	0e                   	push   cs
    180a:	e8 51 02             	call   0x1a5e
    180d:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    1810:	3d 00 80             	cmp    ax,0x8000
    1813:	74 10                	je     0x1825
    1815:	3d ff 7f             	cmp    ax,0x7fff
    1818:	74 0b                	je     0x1825
    181a:	3d 12 00             	cmp    ax,0x12
    181d:	7e 27                	jle    0x1846
    181f:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    1823:	75 21                	jne    0x1846
    1825:	ff 76 16             	push   WORD PTR [bp+0x16]
    1828:	ff 76 14             	push   WORD PTR [bp+0x14]
    182b:	ff 76 12             	push   WORD PTR [bp+0x12]
    182e:	ff 76 10             	push   WORD PTR [bp+0x10]
    1831:	ff 76 0e             	push   WORD PTR [bp+0xe]
    1834:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1837:	ff 76 0a             	push   WORD PTR [bp+0xa]
    183a:	6a 00                	push   0x0
    183c:	6a 0f                	push   0xf
    183e:	6a 00                	push   0x0
    1840:	0e                   	push   cs
    1841:	e8 f0 fc             	call   0x1534
    1844:	eb 19                	jmp    0x185f
    1846:	80 7e db 00          	cmp    BYTE PTR [bp-0x25],0x0
    184a:	75 10                	jne    0x185c
    184c:	b9 02 00             	mov    cx,0x2
    184f:	e8 13 00             	call   0x1865
    1852:	74 d1                	je     0x1825
    1854:	3b 76 fa             	cmp    si,WORD PTR [bp-0x6]
    1857:	74 03                	je     0x185c
    1859:	e8 46 00             	call   0x18a2
    185c:	e8 ea 00             	call   0x1949
    185f:	8b e5                	mov    sp,bp
    1861:	5d                   	pop    bp
    1862:	ca 12 00             	retf   0x12
    1865:	1e                   	push   ds
    1866:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    1869:	e3 1d                	jcxz   0x1888
    186b:	ac                   	lods   al,BYTE PTR ds:[si]
    186c:	3c 27                	cmp    al,0x27
    186e:	74 25                	je     0x1895
    1870:	3c 22                	cmp    al,0x22
    1872:	74 21                	je     0x1895
    1874:	0a c0                	or     al,al
    1876:	74 10                	je     0x1888
    1878:	3c 3b                	cmp    al,0x3b
    187a:	75 ef                	jne    0x186b
    187c:	e2 ed                	loop   0x186b
    187e:	8a 04                	mov    al,BYTE PTR [si]
    1880:	0a c0                	or     al,al
    1882:	74 04                	je     0x1888
    1884:	3c 3b                	cmp    al,0x3b
    1886:	75 0b                	jne    0x1893
    1888:	8b 76 06             	mov    si,WORD PTR [bp+0x6]
    188b:	8a 04                	mov    al,BYTE PTR [si]
    188d:	0a c0                	or     al,al
    188f:	74 02                	je     0x1893
    1891:	3c 3b                	cmp    al,0x3b
    1893:	1f                   	pop    ds
    1894:	c3                   	ret
    1895:	8a e0                	mov    ah,al
    1897:	ac                   	lods   al,BYTE PTR ds:[si]
    1898:	3a c4                	cmp    al,ah
    189a:	74 cf                	je     0x186b
    189c:	0a c0                	or     al,al
    189e:	75 f7                	jne    0x1897
    18a0:	eb e6                	jmp    0x1888
    18a2:	1e                   	push   ds
    18a3:	8e 5e 08             	mov    ds,WORD PTR [bp+0x8]
    18a6:	89 76 fa             	mov    WORD PTR [bp-0x6],si
    18a9:	bb ff 7f             	mov    bx,0x7fff
    18ac:	33 c9                	xor    cx,cx
    18ae:	33 d2                	xor    dx,dx
    18b0:	c7 46 f6 ff ff       	mov    WORD PTR [bp-0xa],0xffff
    18b5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    18b8:	ac                   	lods   al,BYTE PTR ds:[si]
    18b9:	3c 23                	cmp    al,0x23
    18bb:	74 26                	je     0x18e3
    18bd:	3c 30                	cmp    al,0x30
    18bf:	74 25                	je     0x18e6
    18c1:	3c 2e                	cmp    al,0x2e
    18c3:	74 2c                	je     0x18f1
    18c5:	3c 2c                	cmp    al,0x2c
    18c7:	74 33                	je     0x18fc
    18c9:	3c 27                	cmp    al,0x27
    18cb:	74 35                	je     0x1902
    18cd:	3c 22                	cmp    al,0x22
    18cf:	74 31                	je     0x1902
    18d1:	3c 45                	cmp    al,0x45
    18d3:	74 3a                	je     0x190f
    18d5:	3c 65                	cmp    al,0x65
    18d7:	74 36                	je     0x190f
    18d9:	3c 3b                	cmp    al,0x3b
    18db:	74 46                	je     0x1923
    18dd:	0a c0                	or     al,al
    18df:	75 d7                	jne    0x18b8
    18e1:	eb 40                	jmp    0x1923
    18e3:	42                   	inc    dx
    18e4:	eb d2                	jmp    0x18b8
    18e6:	3b d3                	cmp    dx,bx
    18e8:	7d 02                	jge    0x18ec
    18ea:	8b da                	mov    bx,dx
    18ec:	42                   	inc    dx
    18ed:	8b ca                	mov    cx,dx
    18ef:	eb c7                	jmp    0x18b8
    18f1:	83 7e f6 ff          	cmp    WORD PTR [bp-0xa],0xffff
    18f5:	75 c1                	jne    0x18b8
    18f7:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    18fa:	eb bc                	jmp    0x18b8
    18fc:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1900:	eb b6                	jmp    0x18b8
    1902:	8a e0                	mov    ah,al
    1904:	ac                   	lods   al,BYTE PTR ds:[si]
    1905:	3a c4                	cmp    al,ah
    1907:	74 af                	je     0x18b8
    1909:	0a c0                	or     al,al
    190b:	75 f7                	jne    0x1904
    190d:	eb 14                	jmp    0x1923
    190f:	ac                   	lods   al,BYTE PTR ds:[si]
    1910:	3c 2d                	cmp    al,0x2d
    1912:	74 04                	je     0x1918
    1914:	3c 2b                	cmp    al,0x2b
    1916:	75 a1                	jne    0x18b9
    1918:	c6 46 fe 01          	mov    BYTE PTR [bp-0x2],0x1
    191c:	ac                   	lods   al,BYTE PTR ds:[si]
    191d:	3c 30                	cmp    al,0x30
    191f:	74 fb                	je     0x191c
    1921:	eb 96                	jmp    0x18b9
    1923:	1f                   	pop    ds
    1924:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    1927:	83 7e f6 ff          	cmp    WORD PTR [bp-0xa],0xffff
    192b:	75 03                	jne    0x1930
    192d:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    1930:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1933:	2b c1                	sub    ax,cx
    1935:	7e 02                	jle    0x1939
    1937:	33 c0                	xor    ax,ax
    1939:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    193c:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    193f:	2b c3                	sub    ax,bx
    1941:	7d 02                	jge    0x1945
    1943:	33 c0                	xor    ax,ax
    1945:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1948:	c3                   	ret
    1949:	1e                   	push   ds
    194a:	80 7e fe 00          	cmp    BYTE PTR [bp-0x2],0x0
    194e:	74 07                	je     0x1957
    1950:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1953:	33 d2                	xor    dx,dx
    1955:	eb 11                	jmp    0x1968
    1957:	8b 46 d8             	mov    ax,WORD PTR [bp-0x28]
    195a:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    195d:	7f 03                	jg     0x1962
    195f:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1962:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    1965:	2b 56 f6             	sub    dx,WORD PTR [bp-0xa]
    1968:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    196b:	89 56 ee             	mov    WORD PTR [bp-0x12],dx
    196e:	8e 5e 08             	mov    ds,WORD PTR [bp+0x8]
    1971:	8b 76 fa             	mov    si,WORD PTR [bp-0x6]
    1974:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    1977:	8d 5e db             	lea    bx,[bp-0x25]
    197a:	80 7e da 00          	cmp    BYTE PTR [bp-0x26],0x0
    197e:	74 08                	je     0x1988
    1980:	3b 76 06             	cmp    si,WORD PTR [bp+0x6]
    1983:	75 03                	jne    0x1988
    1985:	b0 2d                	mov    al,0x2d
    1987:	aa                   	stos   BYTE PTR es:[di],al
    1988:	ac                   	lods   al,BYTE PTR ds:[si]
    1989:	3c 23                	cmp    al,0x23
    198b:	74 27                	je     0x19b4
    198d:	3c 30                	cmp    al,0x30
    198f:	74 23                	je     0x19b4
    1991:	3c 2e                	cmp    al,0x2e
    1993:	74 f3                	je     0x1988
    1995:	3c 2c                	cmp    al,0x2c
    1997:	74 ef                	je     0x1988
    1999:	3c 27                	cmp    al,0x27
    199b:	74 1c                	je     0x19b9
    199d:	3c 22                	cmp    al,0x22
    199f:	74 18                	je     0x19b9
    19a1:	3c 45                	cmp    al,0x45
    19a3:	74 22                	je     0x19c7
    19a5:	3c 65                	cmp    al,0x65
    19a7:	74 1e                	je     0x19c7
    19a9:	3c 3b                	cmp    al,0x3b
    19ab:	74 4a                	je     0x19f7
    19ad:	0a c0                	or     al,al
    19af:	74 46                	je     0x19f7
    19b1:	aa                   	stos   BYTE PTR es:[di],al
    19b2:	eb d4                	jmp    0x1988
    19b4:	e8 47 00             	call   0x19fe
    19b7:	eb cf                	jmp    0x1988
    19b9:	8a e0                	mov    ah,al
    19bb:	ac                   	lods   al,BYTE PTR ds:[si]
    19bc:	3a c4                	cmp    al,ah
    19be:	74 c8                	je     0x1988
    19c0:	0a c0                	or     al,al
    19c2:	74 33                	je     0x19f7
    19c4:	aa                   	stos   BYTE PTR es:[di],al
    19c5:	eb f4                	jmp    0x19bb
    19c7:	8a 24                	mov    ah,BYTE PTR [si]
    19c9:	80 fc 2b             	cmp    ah,0x2b
    19cc:	74 07                	je     0x19d5
    19ce:	80 fc 2d             	cmp    ah,0x2d
    19d1:	75 de                	jne    0x19b1
    19d3:	32 e4                	xor    ah,ah
    19d5:	b9 ff ff             	mov    cx,0xffff
    19d8:	41                   	inc    cx
    19d9:	46                   	inc    si
    19da:	80 3c 30             	cmp    BYTE PTR [si],0x30
    19dd:	74 f9                	je     0x19d8
    19df:	83 f9 04             	cmp    cx,0x4
    19e2:	72 03                	jb     0x19e7
    19e4:	b9 04 00             	mov    cx,0x4
    19e7:	53                   	push   bx
    19e8:	8a 5e db             	mov    bl,BYTE PTR [bp-0x25]
    19eb:	8b 56 d8             	mov    dx,WORD PTR [bp-0x28]
    19ee:	2b 56 f6             	sub    dx,WORD PTR [bp-0xa]
    19f1:	e8 87 fc             	call   0x167b
    19f4:	5b                   	pop    bx
    19f5:	eb 91                	jmp    0x1988
    19f7:	1f                   	pop    ds
    19f8:	8b c7                	mov    ax,di
    19fa:	2b 46 14             	sub    ax,WORD PTR [bp+0x14]
    19fd:	c3                   	ret
    19fe:	83 7e ee 00          	cmp    WORD PTR [bp-0x12],0x0
    1a02:	74 19                	je     0x1a1d
    1a04:	7c 0a                	jl     0x1a10
    1a06:	e8 14 00             	call   0x1a1d
    1a09:	ff 4e ee             	dec    WORD PTR [bp-0x12]
    1a0c:	75 f8                	jne    0x1a06
    1a0e:	eb 0d                	jmp    0x1a1d
    1a10:	ff 46 ee             	inc    WORD PTR [bp-0x12]
    1a13:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1a16:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1a19:	7e 13                	jle    0x1a2e
    1a1b:	eb 3d                	jmp    0x1a5a
    1a1d:	36 8a 07             	mov    al,BYTE PTR ss:[bx]
    1a20:	43                   	inc    bx
    1a21:	0a c0                	or     al,al
    1a23:	75 0b                	jne    0x1a30
    1a25:	4b                   	dec    bx
    1a26:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1a29:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1a2c:	7e 2c                	jle    0x1a5a
    1a2e:	b0 30                	mov    al,0x30
    1a30:	83 7e f0 00          	cmp    WORD PTR [bp-0x10],0x0
    1a34:	75 08                	jne    0x1a3e
    1a36:	8a e0                	mov    ah,al
    1a38:	8a 46 fd             	mov    al,BYTE PTR [bp-0x3]
    1a3b:	ab                   	stos   WORD PTR es:[di],ax
    1a3c:	eb 1c                	jmp    0x1a5a
    1a3e:	aa                   	stos   BYTE PTR es:[di],al
    1a3f:	80 7e ff 00          	cmp    BYTE PTR [bp-0x1],0x0
    1a43:	74 15                	je     0x1a5a
    1a45:	8b 46 f0             	mov    ax,WORD PTR [bp-0x10]
    1a48:	3d 01 00             	cmp    ax,0x1
    1a4b:	7e 0d                	jle    0x1a5a
    1a4d:	b2 03                	mov    dl,0x3
    1a4f:	f6 f2                	div    dl
    1a51:	80 fc 01             	cmp    ah,0x1
    1a54:	75 04                	jne    0x1a5a
    1a56:	8a 46 fc             	mov    al,BYTE PTR [bp-0x4]
    1a59:	aa                   	stos   BYTE PTR es:[di],al
    1a5a:	ff 4e f0             	dec    WORD PTR [bp-0x10]
    1a5d:	c3                   	ret
    1a5e:	55                   	push   bp
    1a5f:	8b ec                	mov    bp,sp
    1a61:	83 ec 12             	sub    sp,0x12
    1a64:	9b d9 7e fe          	fstcw  WORD PTR [bp-0x2]
    1a68:	9b 2e d9 2e 2c 15    	fldcw  WORD PTR cs:0x152c
    1a6e:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    1a71:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    1a74:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1a77:	8b d0                	mov    dx,ax
    1a79:	25 ff 7f             	and    ax,0x7fff
    1a7c:	74 0d                	je     0x1a8b
    1a7e:	3d ff 7f             	cmp    ax,0x7fff
    1a81:	75 12                	jne    0x1a95
    1a83:	81 7e 10 00 80       	cmp    WORD PTR [bp+0x10],0x8000
    1a88:	74 03                	je     0x1a8d
    1a8a:	40                   	inc    ax
    1a8b:	33 d2                	xor    dx,dx
    1a8d:	26 c6 45 03 00       	mov    BYTE PTR es:[di+0x3],0x0
    1a92:	e9 cc 00             	jmp    0x1b61
    1a95:	89 46 12             	mov    WORD PTR [bp+0x12],ax
    1a98:	9b db 6e 0a          	fld    TBYTE PTR [bp+0xa]
    1a9c:	2d ff 3f             	sub    ax,0x3fff
    1a9f:	ba 10 4d             	mov    dx,0x4d10
    1aa2:	f7 ea                	imul   dx
    1aa4:	42                   	inc    dx
    1aa5:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    1aa8:	b8 12 00             	mov    ax,0x12
    1aab:	2b c2                	sub    ax,dx
    1aad:	e8 b9 01             	call   0x1c69
    1ab0:	9b d9 fc             	frndint
    1ab3:	9b 2e db 2e 18 15    	fld    TBYTE PTR cs:0x1518
    1ab9:	9b d8 d9             	fcomp  st(1)
    1abc:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
    1ac0:	90                   	nop
    1ac1:	9b                   	fwait
    1ac2:	f7 46 fc 00 41       	test   WORD PTR [bp-0x4],0x4100
    1ac7:	74 09                	je     0x1ad2
    1ac9:	9b 2e da 36 98 14    	fidiv  DWORD PTR cs:0x1498
    1acf:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    1ad2:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    1ad5:	83 c7 03             	add    di,0x3
    1ad8:	2e 80 3e e5 1a cd    	cmp    BYTE PTR cs:0x1ae5,0xcd
    1ade:	75 05                	jne    0x1ae5
    1ae0:	e8 ee 01             	call   0x1cd1
    1ae3:	eb 1f                	jmp    0x1b04
    1ae5:	9b df 76 ee          	fbstp  TBYTE PTR [bp-0x12]
    1ae9:	b1 04                	mov    cl,0x4
    1aeb:	be 09 00             	mov    si,0x9
    1aee:	90                   	nop
    1aef:	9b                   	fwait
    1af0:	8a 42 ed             	mov    al,BYTE PTR [bp+si-0x13]
    1af3:	8a e0                	mov    ah,al
    1af5:	d2 e8                	shr    al,cl
    1af7:	80 e4 0f             	and    ah,0xf
    1afa:	05 30 30             	add    ax,0x3030
    1afd:	ab                   	stos   WORD PTR es:[di],ax
    1afe:	4e                   	dec    si
    1aff:	75 ef                	jne    0x1af0
    1b01:	32 c0                	xor    al,al
    1b03:	aa                   	stos   BYTE PTR es:[di],al
    1b04:	c4 7e 14             	les    di,DWORD PTR [bp+0x14]
    1b07:	8b 5e 06             	mov    bx,WORD PTR [bp+0x6]
    1b0a:	03 5e fa             	add    bx,WORD PTR [bp-0x6]
    1b0d:	79 05                	jns    0x1b14
    1b0f:	33 c0                	xor    ax,ax
    1b11:	e9 77 ff             	jmp    0x1a8b
    1b14:	3b 5e 08             	cmp    bx,WORD PTR [bp+0x8]
    1b17:	72 03                	jb     0x1b1c
    1b19:	8b 5e 08             	mov    bx,WORD PTR [bp+0x8]
    1b1c:	83 fb 12             	cmp    bx,0x12
    1b1f:	73 28                	jae    0x1b49
    1b21:	26 80 79 03 35       	cmp    BYTE PTR es:[bx+di+0x3],0x35
    1b26:	72 24                	jb     0x1b4c
    1b28:	26 c6 41 03 00       	mov    BYTE PTR es:[bx+di+0x3],0x0
    1b2d:	4b                   	dec    bx
    1b2e:	78 0d                	js     0x1b3d
    1b30:	26 fe 41 03          	inc    BYTE PTR es:[bx+di+0x3]
    1b34:	26 80 79 03 39       	cmp    BYTE PTR es:[bx+di+0x3],0x39
    1b39:	77 ed                	ja     0x1b28
    1b3b:	eb 1e                	jmp    0x1b5b
    1b3d:	26 c7 45 03 31 00    	mov    WORD PTR es:[di+0x3],0x31
    1b43:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    1b46:	eb 13                	jmp    0x1b5b
    1b48:	90                   	nop
    1b49:	bb 12 00             	mov    bx,0x12
    1b4c:	26 c6 41 03 00       	mov    BYTE PTR es:[bx+di+0x3],0x0
    1b51:	4b                   	dec    bx
    1b52:	78 bb                	js     0x1b0f
    1b54:	26 80 79 03 30       	cmp    BYTE PTR es:[bx+di+0x3],0x30
    1b59:	74 f1                	je     0x1b4c
    1b5b:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1b5e:	8b 56 f8             	mov    dx,WORD PTR [bp-0x8]
    1b61:	26 89 05             	mov    WORD PTR es:[di],ax
    1b64:	33 c0                	xor    ax,ax
    1b66:	03 d2                	add    dx,dx
    1b68:	13 c0                	adc    ax,ax
    1b6a:	26 88 45 02          	mov    BYTE PTR es:[di+0x2],al
    1b6e:	9b db e2             	fclex
    1b71:	9b d9 6e fe          	fldcw  WORD PTR [bp-0x2]
    1b75:	90                   	nop
    1b76:	9b                   	fwait
    1b77:	8b e5                	mov    sp,bp
    1b79:	5d                   	pop    bp
    1b7a:	ca 12 00             	retf   0x12
    1b7d:	55                   	push   bp
    1b7e:	8b ec                	mov    bp,sp
    1b80:	83 ec 10             	sub    sp,0x10
    1b83:	9b d9 7e fe          	fstcw  WORD PTR [bp-0x2]
    1b87:	9b db e2             	fclex
    1b8a:	9b 2e d9 2e 2c 15    	fldcw  WORD PTR cs:0x152c
    1b90:	9b d9 ee             	fldz
    1b93:	1e                   	push   ds
    1b94:	8a 0e 89 0b          	mov    cl,BYTE PTR ds:0xb89
    1b98:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    1b9b:	fc                   	cld
    1b9c:	e8 77 00             	call   0x1c16
    1b9f:	8a 04                	mov    al,BYTE PTR [si]
    1ba1:	88 46 fa             	mov    BYTE PTR [bp-0x6],al
    1ba4:	3c 2b                	cmp    al,0x2b
    1ba6:	74 04                	je     0x1bac
    1ba8:	3c 2d                	cmp    al,0x2d
    1baa:	75 01                	jne    0x1bad
    1bac:	46                   	inc    si
    1bad:	8b d6                	mov    dx,si
    1baf:	e8 6b 00             	call   0x1c1d
    1bb2:	33 db                	xor    bx,bx
    1bb4:	3a 0c                	cmp    cl,BYTE PTR [si]
    1bb6:	75 06                	jne    0x1bbe
    1bb8:	46                   	inc    si
    1bb9:	e8 61 00             	call   0x1c1d
    1bbc:	f7 db                	neg    bx
    1bbe:	3b f2                	cmp    si,dx
    1bc0:	74 33                	je     0x1bf5
    1bc2:	8a 04                	mov    al,BYTE PTR [si]
    1bc4:	24 df                	and    al,0xdf
    1bc6:	3c 45                	cmp    al,0x45
    1bc8:	75 08                	jne    0x1bd2
    1bca:	46                   	inc    si
    1bcb:	53                   	push   bx
    1bcc:	e8 6a 00             	call   0x1c39
    1bcf:	5b                   	pop    bx
    1bd0:	03 d8                	add    bx,ax
    1bd2:	e8 41 00             	call   0x1c16
    1bd5:	80 3c 00             	cmp    BYTE PTR [si],0x0
    1bd8:	75 1b                	jne    0x1bf5
    1bda:	8b c3                	mov    ax,bx
    1bdc:	e8 8a 00             	call   0x1c69
    1bdf:	80 7e fa 2d          	cmp    BYTE PTR [bp-0x6],0x2d
    1be3:	75 03                	jne    0x1be8
    1be5:	9b d9 e0             	fchs
    1be8:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
    1bec:	90                   	nop
    1bed:	9b                   	fwait
    1bee:	f7 46 fc 09 00       	test   WORD PTR [bp-0x4],0x9
    1bf3:	74 08                	je     0x1bfd
    1bf5:	9b db 7e f0          	fstp   TBYTE PTR [bp-0x10]
    1bf9:	33 c0                	xor    ax,ax
    1bfb:	eb 09                	jmp    0x1c06
    1bfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c00:	9b 26 db 3d          	fstp   TBYTE PTR es:[di]
    1c04:	b0 01                	mov    al,0x1
    1c06:	1f                   	pop    ds
    1c07:	9b db e2             	fclex
    1c0a:	9b d9 6e fe          	fldcw  WORD PTR [bp-0x2]
    1c0e:	90                   	nop
    1c0f:	9b                   	fwait
    1c10:	8b e5                	mov    sp,bp
    1c12:	5d                   	pop    bp
    1c13:	ca 08 00             	retf   0x8
    1c16:	ac                   	lods   al,BYTE PTR ds:[si]
    1c17:	3c 20                	cmp    al,0x20
    1c19:	74 fb                	je     0x1c16
    1c1b:	4e                   	dec    si
    1c1c:	c3                   	ret
    1c1d:	33 db                	xor    bx,bx
    1c1f:	ac                   	lods   al,BYTE PTR ds:[si]
    1c20:	2c 3a                	sub    al,0x3a
    1c22:	04 0a                	add    al,0xa
    1c24:	73 11                	jae    0x1c37
    1c26:	9b 2e da 0e 98 14    	fimul  DWORD PTR cs:0x1498
    1c2c:	98                   	cbw
    1c2d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c30:	9b de 46 fc          	fiadd  WORD PTR [bp-0x4]
    1c34:	43                   	inc    bx
    1c35:	eb e8                	jmp    0x1c1f
    1c37:	4e                   	dec    si
    1c38:	c3                   	ret
    1c39:	33 c0                	xor    ax,ax
    1c3b:	8a 1c                	mov    bl,BYTE PTR [si]
    1c3d:	80 fb 2b             	cmp    bl,0x2b
    1c40:	74 05                	je     0x1c47
    1c42:	80 fb 2d             	cmp    bl,0x2d
    1c45:	75 01                	jne    0x1c48
    1c47:	46                   	inc    si
    1c48:	8a 0c                	mov    cl,BYTE PTR [si]
    1c4a:	80 e9 3a             	sub    cl,0x3a
    1c4d:	80 c1 0a             	add    cl,0xa
    1c50:	73 0f                	jae    0x1c61
    1c52:	ba 0a 00             	mov    dx,0xa
    1c55:	f7 e2                	mul    dx
    1c57:	32 ed                	xor    ch,ch
    1c59:	03 c1                	add    ax,cx
    1c5b:	46                   	inc    si
    1c5c:	3d f4 01             	cmp    ax,0x1f4
    1c5f:	72 e7                	jb     0x1c48
    1c61:	80 fb 2d             	cmp    bl,0x2d
    1c64:	75 02                	jne    0x1c68
    1c66:	f7 d8                	neg    ax
    1c68:	c3                   	ret
    1c69:	3d 00 10             	cmp    ax,0x1000
    1c6c:	7e 0c                	jle    0x1c7a
    1c6e:	9b 2e db 2e 0e 15    	fld    TBYTE PTR cs:0x150e
    1c74:	9b de c9             	fmulp  st(1),st
    1c77:	2d 00 10             	sub    ax,0x1000
    1c7a:	3d 00 f0             	cmp    ax,0xf000
    1c7d:	7d 0e                	jge    0x1c8d
    1c7f:	9b 2e db 2e 0e 15    	fld    TBYTE PTR cs:0x150e
    1c85:	9a ff ff 00 00       	call   0x0:0xffff
    1c8a:	05 00 10             	add    ax,0x1000
    1c8d:	8b d8                	mov    bx,ax
    1c8f:	0b c0                	or     ax,ax
    1c91:	74 3d                	je     0x1cd0
    1c93:	79 02                	jns    0x1c97
    1c95:	f7 d8                	neg    ax
    1c97:	8b f0                	mov    si,ax
    1c99:	83 e6 07             	and    si,0x7
    1c9c:	d1 e6                	shl    si,1
    1c9e:	d1 e6                	shl    si,1
    1ca0:	9b 2e db 84 94 14    	fild   DWORD PTR cs:[si+0x1494]
    1ca6:	d1 e8                	shr    ax,1
    1ca8:	d1 e8                	shr    ax,1
    1caa:	d1 e8                	shr    ax,1
    1cac:	be b4 14             	mov    si,0x14b4
    1caf:	eb 0e                	jmp    0x1cbf
    1cb1:	d1 e8                	shr    ax,1
    1cb3:	73 07                	jae    0x1cbc
    1cb5:	9b 2e db 2c          	fld    TBYTE PTR cs:[si]
    1cb9:	9b de c9             	fmulp  st(1),st
    1cbc:	83 c6 0a             	add    si,0xa
    1cbf:	0b c0                	or     ax,ax
    1cc1:	75 ee                	jne    0x1cb1
    1cc3:	0b db                	or     bx,bx
    1cc5:	78 04                	js     0x1ccb
    1cc7:	9b de c9             	fmulp  st(1),st
    1cca:	c3                   	ret
    1ccb:	9a ff ff 00 00       	call   0x0:0xffff
    1cd0:	c3                   	ret
    1cd1:	26 c6 45 12 00       	mov    BYTE PTR es:[di+0x12],0x0
    1cd6:	83 c7 10             	add    di,0x10
    1cd9:	fd                   	std
    1cda:	83 ec 08             	sub    sp,0x8
    1cdd:	8b f4                	mov    si,sp
    1cdf:	9b 36 df 3c          	fistp  QWORD PTR ss:[si]
    1ce3:	90                   	nop
    1ce4:	9b                   	fwait
    1ce5:	5b                   	pop    bx
    1ce6:	59                   	pop    cx
    1ce7:	58                   	pop    ax
    1ce8:	5a                   	pop    dx
    1ce9:	be 10 27             	mov    si,0x2710
    1cec:	f7 f6                	div    si
    1cee:	91                   	xchg   cx,ax
    1cef:	f7 f6                	div    si
    1cf1:	93                   	xchg   bx,ax
    1cf2:	f7 f6                	div    si
    1cf4:	e8 2a 00             	call   0x1d21
    1cf7:	33 d2                	xor    dx,dx
    1cf9:	91                   	xchg   cx,ax
    1cfa:	f7 f6                	div    si
    1cfc:	93                   	xchg   bx,ax
    1cfd:	f7 f6                	div    si
    1cff:	91                   	xchg   cx,ax
    1d00:	f7 f6                	div    si
    1d02:	e8 1c 00             	call   0x1d21
    1d05:	8b d3                	mov    dx,bx
    1d07:	91                   	xchg   cx,ax
    1d08:	f7 f6                	div    si
    1d0a:	91                   	xchg   cx,ax
    1d0b:	f7 f6                	div    si
    1d0d:	e8 11 00             	call   0x1d21
    1d10:	8b d1                	mov    dx,cx
    1d12:	f7 f6                	div    si
    1d14:	e8 0a 00             	call   0x1d21
    1d17:	d4 0a                	aam    0xa
    1d19:	86 c4                	xchg   ah,al
    1d1b:	05 30 30             	add    ax,0x3030
    1d1e:	ab                   	stos   WORD PTR es:[di],ax
    1d1f:	fc                   	cld
    1d20:	c3                   	ret
    1d21:	50                   	push   ax
    1d22:	b0 64                	mov    al,0x64
    1d24:	92                   	xchg   dx,ax
    1d25:	f6 f2                	div    dl
    1d27:	8a d4                	mov    dl,ah
    1d29:	d4 0a                	aam    0xa
    1d2b:	05 30 30             	add    ax,0x3030
    1d2e:	86 c4                	xchg   ah,al
    1d30:	92                   	xchg   dx,ax
    1d31:	d4 0a                	aam    0xa
    1d33:	05 30 30             	add    ax,0x3030
    1d36:	86 c4                	xchg   ah,al
    1d38:	ab                   	stos   WORD PTR es:[di],ax
    1d39:	92                   	xchg   dx,ax
    1d3a:	ab                   	stos   WORD PTR es:[di],ax
    1d3b:	58                   	pop    ax
    1d3c:	c3                   	ret
    1d3d:	89 26 ce 0d          	mov    WORD PTR ds:0xdce,sp
    1d41:	89 2e d0 0d          	mov    WORD PTR ds:0xdd0,bp
    1d45:	89 3e 16 0b          	mov    WORD PTR ds:0xb16,di
    1d49:	89 36 1a 0b          	mov    WORD PTR ds:0xb1a,si
    1d4d:	8c 06 1c 0b          	mov    WORD PTR ds:0xb1c,es
    1d51:	e3 0e                	jcxz   0x1d61
    1d53:	33 c0                	xor    ax,ax
    1d55:	1e                   	push   ds
    1d56:	50                   	push   ax
    1d57:	51                   	push   cx
    1d58:	9a ff ff 00 00       	call   0x0:0xffff
    1d5d:	0b c0                	or     ax,ax
    1d5f:	74 2e                	je     0x1d8f
    1d61:	9a ff ff 00 00       	call   0x0:0xffff
    1d66:	33 d2                	xor    dx,dx
    1d68:	a8 c0                	test   al,0xc0
    1d6a:	75 06                	jne    0x1d72
    1d6c:	42                   	inc    dx
    1d6d:	a8 02                	test   al,0x2
    1d6f:	75 01                	jne    0x1d72
    1d71:	42                   	inc    dx
    1d72:	88 16 12 0b          	mov    BYTE PTR ds:0xb12,dl
    1d76:	c7 06 24 0b 02 20    	mov    WORD PTR ds:0xb24,0x2002
    1d7c:	c7 06 08 0b ff ff    	mov    WORD PTR ds:0xb08,0xffff
    1d82:	c7 06 fa 0a 01 00    	mov    WORD PTR ds:0xafa,0x1
    1d88:	c7 06 28 0b 8f 1d    	mov    WORD PTR ds:0xb28,0x1d8f
    1d8e:	cb                   	retf
    1d8f:	c7 06 fa 0a 00 00    	mov    WORD PTR ds:0xafa,0x0
    1d95:	8b 26 ce 0d          	mov    sp,WORD PTR ds:0xdce
    1d99:	8b 2e d0 0d          	mov    bp,WORD PTR ds:0xdd0
    1d9d:	58                   	pop    ax
    1d9e:	58                   	pop    ax
    1d9f:	c7 06 28 0b 00 00    	mov    WORD PTR ds:0xb28,0x0
    1da5:	a1 fa 0a             	mov    ax,ds:0xafa
    1da8:	8b 3e 16 0b          	mov    di,WORD PTR ds:0xb16
    1dac:	cb                   	retf
    1dad:	8c d8                	mov    ax,ds
    1daf:	90                   	nop
    1db0:	45                   	inc    bp
    1db1:	55                   	push   bp
    1db2:	8b ec                	mov    bp,sp
    1db4:	1e                   	push   ds
    1db5:	56                   	push   si
    1db6:	57                   	push   di
    1db7:	8e d8                	mov    ds,ax
    1db9:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1dbc:	a3 fa 0a             	mov    ds:0xafa,ax
    1dbf:	e8 bf 00             	call   0x1e81
    1dc2:	b8 01 00             	mov    ax,0x1
    1dc5:	5f                   	pop    di
    1dc6:	5e                   	pop    si
    1dc7:	1f                   	pop    ds
    1dc8:	5d                   	pop    bp
    1dc9:	4d                   	dec    bp
    1dca:	ca 02 00             	retf   0x2
    1dcd:	59                   	pop    cx
    1dce:	5b                   	pop    bx
    1dcf:	8b 16 ea 0a          	mov    dx,WORD PTR ds:0xaea
    1dd3:	0b 16 ec 0a          	or     dx,WORD PTR ds:0xaec
    1dd7:	74 07                	je     0x1de0
    1dd9:	50                   	push   ax
    1dda:	53                   	push   bx
    1ddb:	51                   	push   cx
    1ddc:	ff 1e ea 0a          	call   DWORD PTR ds:0xaea
    1de0:	8b f8                	mov    di,ax
    1de2:	a1 02 0b             	mov    ax,ds:0xb02
    1de5:	0b ff                	or     di,di
    1de7:	74 1b                	je     0x1e04
    1de9:	2e 8a 85 f1 1d       	mov    al,BYTE PTR cs:[di+0x1df1]
    1dee:	32 e4                	xor    ah,ah
    1df0:	eb 12                	jmp    0x1e04
    1df2:	cb                   	retf
    1df3:	cc                   	int3
    1df4:	c8 c9 d7 cf          	enter  0xd7c9,0xcf
    1df8:	c8 cd ce db          	enter  0xcecd,0xdb
    1dfc:	59                   	pop    cx
    1dfd:	5b                   	pop    bx
    1dfe:	eb 04                	jmp    0x1e04
    1e00:	33 c9                	xor    cx,cx
    1e02:	33 db                	xor    bx,bx
    1e04:	a3 fa 0a             	mov    ds:0xafa,ax
    1e07:	8b c1                	mov    ax,cx
    1e09:	0b c3                	or     ax,bx
    1e0b:	74 0c                	je     0x1e19
    1e0d:	83 fb ff             	cmp    bx,0xffff
    1e10:	74 07                	je     0x1e19
    1e12:	8e c3                	mov    es,bx
    1e14:	26 8b 1e 00 00       	mov    bx,WORD PTR es:0x0
    1e19:	89 0e fc 0a          	mov    WORD PTR ds:0xafc,cx
    1e1d:	89 1e fe 0a          	mov    WORD PTR ds:0xafe,bx
    1e21:	83 3e 28 0b 00       	cmp    WORD PTR ds:0xb28,0x0
    1e26:	75 07                	jne    0x1e2f
    1e28:	83 3e 00 0b 00       	cmp    WORD PTR ds:0xb00,0x0
    1e2d:	74 03                	je     0x1e32
    1e2f:	e8 4f 00             	call   0x1e81
    1e32:	a1 fc 0a             	mov    ax,ds:0xafc
    1e35:	0b 06 fe 0a          	or     ax,WORD PTR ds:0xafe
    1e39:	74 36                	je     0x1e71
    1e3b:	b9 0a 00             	mov    cx,0xa
    1e3e:	a0 fa 0a             	mov    al,ds:0xafa
    1e41:	32 e4                	xor    ah,ah
    1e43:	bb 3b 0b             	mov    bx,0xb3b
    1e46:	e8 56 00             	call   0x1e9f
    1e49:	b9 10 00             	mov    cx,0x10
    1e4c:	a1 fe 0a             	mov    ax,ds:0xafe
    1e4f:	bb 43 0b             	mov    bx,0xb43
    1e52:	e8 4a 00             	call   0x1e9f
    1e55:	a1 fc 0a             	mov    ax,ds:0xafc
    1e58:	bb 48 0b             	mov    bx,0xb48
    1e5b:	e8 41 00             	call   0x1e9f
    1e5e:	33 c0                	xor    ax,ax
    1e60:	50                   	push   ax
    1e61:	bb 2a 0b             	mov    bx,0xb2a
    1e64:	1e                   	push   ds
    1e65:	53                   	push   bx
    1e66:	50                   	push   ax
    1e67:	50                   	push   ax
    1e68:	b8 10 10             	mov    ax,0x1010
    1e6b:	50                   	push   ax
    1e6c:	9a ff ff 00 00       	call   0x0:0xffff
    1e71:	a1 28 0b             	mov    ax,ds:0xb28
    1e74:	0b c0                	or     ax,ax
    1e76:	74 02                	je     0x1e7a
    1e78:	ff e0                	jmp    ax
    1e7a:	a0 fa 0a             	mov    al,ds:0xafa
    1e7d:	b4 4c                	mov    ah,0x4c
    1e7f:	cd 21                	int    0x21
    1e81:	c4 1e f6 0a          	les    bx,DWORD PTR ds:0xaf6
    1e85:	8c c0                	mov    ax,es
    1e87:	0b c3                	or     ax,bx
    1e89:	74 13                	je     0x1e9e
    1e8b:	33 c0                	xor    ax,ax
    1e8d:	a3 f6 0a             	mov    ds:0xaf6,ax
    1e90:	a3 f8 0a             	mov    ds:0xaf8,ax
    1e93:	a3 02 0b             	mov    ds:0xb02,ax
    1e96:	b8 81 1e             	mov    ax,0x1e81
    1e99:	0e                   	push   cs
    1e9a:	50                   	push   ax
    1e9b:	06                   	push   es
    1e9c:	53                   	push   bx
    1e9d:	cb                   	retf
    1e9e:	c3                   	ret
    1e9f:	33 d2                	xor    dx,dx
    1ea1:	f7 f1                	div    cx
    1ea3:	80 c2 30             	add    dl,0x30
    1ea6:	80 fa 3a             	cmp    dl,0x3a
    1ea9:	72 03                	jb     0x1eae
    1eab:	80 c2 07             	add    dl,0x7
    1eae:	4b                   	dec    bx
    1eaf:	88 17                	mov    BYTE PTR [bx],dl
    1eb1:	0b c0                	or     ax,ax
    1eb3:	75 ea                	jne    0x1e9f
    1eb5:	c3                   	ret
    1eb6:	42                   	inc    dx
    1eb7:	6f                   	outs   dx,WORD PTR ds:[si]
    1eb8:	72 6c                	jb     0x1f26
    1eba:	61                   	popa
    1ebb:	6e                   	outs   dx,BYTE PTR ds:[si]
    1ebc:	64 20 44 65          	and    BYTE PTR fs:[si+0x65],al
    1ec0:	6c                   	ins    BYTE PTR es:[di],dx
    1ec1:	70 68                	jo     0x1f2b
    1ec3:	69 0d 0a 50          	imul   cx,WORD PTR [di],0x500a
    1ec7:	6f                   	outs   dx,WORD PTR ds:[si]
    1ec8:	72 74                	jb     0x1f3e
    1eca:	69 6f 6e 73 20       	imul   bp,WORD PTR [bx+0x6e],0x2073
    1ecf:	43                   	inc    bx
    1ed0:	6f                   	outs   dx,WORD PTR ds:[si]
    1ed1:	70 79                	jo     0x1f4c
    1ed3:	72 69                	jb     0x1f3e
    1ed5:	67 68 74 20          	addr32 push 0x2074
    1ed9:	28 63 29             	sub    BYTE PTR [bp+di+0x29],ah
    1edc:	20 31                	and    BYTE PTR [bx+di],dh
    1ede:	39 38                	cmp    WORD PTR [bx+si],di
    1ee0:	33 2c                	xor    bp,WORD PTR [si]
    1ee2:	39 35                	cmp    WORD PTR [di],si
    1ee4:	20 42 6f             	and    BYTE PTR [bp+si+0x6f],al
    1ee7:	72 6c                	jb     0x1f55
    1ee9:	61                   	popa
    1eea:	6e                   	outs   dx,BYTE PTR ds:[si]
    1eeb:	64 0d 0a 00          	fs or  ax,0xa
    1eef:	45                   	inc    bp
    1ef0:	55                   	push   bp
    1ef1:	8b ec                	mov    bp,sp
    1ef3:	1e                   	push   ds
    1ef4:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1ef7:	e8 92 00             	call   0x1f8c
    1efa:	8b e5                	mov    sp,bp
    1efc:	5d                   	pop    bp
    1efd:	4d                   	dec    bp
    1efe:	72 03                	jb     0x1f03
    1f00:	ca 02 00             	retf   0x2
    1f03:	b8 01 00             	mov    ax,0x1
    1f06:	e9 c4 fe             	jmp    0x1dcd
    1f09:	45                   	inc    bp
    1f0a:	55                   	push   bp
    1f0b:	8b ec                	mov    bp,sp
    1f0d:	1e                   	push   ds
    1f0e:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1f11:	8b 4e 08             	mov    cx,WORD PTR [bp+0x8]
    1f14:	8b 5e 0a             	mov    bx,WORD PTR [bp+0xa]
    1f17:	e8 8f 01             	call   0x20a9
    1f1a:	8b e5                	mov    sp,bp
    1f1c:	5d                   	pop    bp
    1f1d:	4d                   	dec    bp
    1f1e:	72 03                	jb     0x1f23
    1f20:	ca 06 00             	retf   0x6
    1f23:	b8 02 00             	mov    ax,0x2
    1f26:	e9 a4 fe             	jmp    0x1dcd
    1f29:	45                   	inc    bp
    1f2a:	55                   	push   bp
    1f2b:	8b ec                	mov    bp,sp
    1f2d:	1e                   	push   ds
    1f2e:	b8 00 10             	mov    ax,0x1000
    1f31:	50                   	push   ax
    1f32:	9a ff ff 00 00       	call   0x0:0xffff
    1f37:	8b 0e 1e 0b          	mov    cx,WORD PTR ds:0xb1e
    1f3b:	e3 15                	jcxz   0x1f52
    1f3d:	8e c1                	mov    es,cx
    1f3f:	26 03 06 08 00       	add    ax,WORD PTR es:0x8
    1f44:	83 d2 00             	adc    dx,0x0
    1f47:	26 8b 0e 0a 00       	mov    cx,WORD PTR es:0xa
    1f4c:	3b 0e 1e 0b          	cmp    cx,WORD PTR ds:0xb1e
    1f50:	75 eb                	jne    0x1f3d
    1f52:	8b e5                	mov    sp,bp
    1f54:	5d                   	pop    bp
    1f55:	4d                   	dec    bp
    1f56:	cb                   	retf
    1f57:	45                   	inc    bp
    1f58:	55                   	push   bp
    1f59:	8b ec                	mov    bp,sp
    1f5b:	1e                   	push   ds
    1f5c:	33 c0                	xor    ax,ax
    1f5e:	50                   	push   ax
    1f5f:	50                   	push   ax
    1f60:	9a ff ff 00 00       	call   0x0:0xffff
    1f65:	0b d2                	or     dx,dx
    1f67:	75 1e                	jne    0x1f87
    1f69:	8b 0e 1e 0b          	mov    cx,WORD PTR ds:0xb1e
    1f6d:	e3 18                	jcxz   0x1f87
    1f6f:	8e c1                	mov    es,cx
    1f71:	26 3b 06 08 00       	cmp    ax,WORD PTR es:0x8
    1f76:	73 04                	jae    0x1f7c
    1f78:	26 a1 08 00          	mov    ax,es:0x8
    1f7c:	26 8b 0e 0a 00       	mov    cx,WORD PTR es:0xa
    1f81:	3b 0e 1e 0b          	cmp    cx,WORD PTR ds:0xb1e
    1f85:	75 e8                	jne    0x1f6f
    1f87:	8b e5                	mov    sp,bp
    1f89:	5d                   	pop    bp
    1f8a:	4d                   	dec    bp
    1f8b:	cb                   	retf
    1f8c:	0b c0                	or     ax,ax
    1f8e:	74 60                	je     0x1ff0
    1f90:	a3 d2 0d             	mov    ds:0xdd2,ax
    1f93:	8b 1e 0a 0b          	mov    bx,WORD PTR ds:0xb0a
    1f97:	0b 1e 0c 0b          	or     bx,WORD PTR ds:0xb0c
    1f9b:	74 06                	je     0x1fa3
    1f9d:	50                   	push   ax
    1f9e:	ff 1e 0a 0b          	call   DWORD PTR ds:0xb0a
    1fa2:	58                   	pop    ax
    1fa3:	3b 06 20 0b          	cmp    ax,WORD PTR ds:0xb20
    1fa7:	72 1f                	jb     0x1fc8
    1fa9:	e8 48 00             	call   0x1ff4
    1fac:	73 45                	jae    0x1ff3
    1fae:	83 3e 20 0b 00       	cmp    WORD PTR ds:0xb20,0x0
    1fb3:	74 20                	je     0x1fd5
    1fb5:	a1 d2 0d             	mov    ax,ds:0xdd2
    1fb8:	8b 1e 22 0b          	mov    bx,WORD PTR ds:0xb22
    1fbc:	83 eb 0c             	sub    bx,0xc
    1fbf:	3b c3                	cmp    ax,bx
    1fc1:	77 12                	ja     0x1fd5
    1fc3:	e8 48 00             	call   0x200e
    1fc6:	eb 0b                	jmp    0x1fd3
    1fc8:	e8 43 00             	call   0x200e
    1fcb:	73 26                	jae    0x1ff3
    1fcd:	a1 d2 0d             	mov    ax,ds:0xdd2
    1fd0:	e8 21 00             	call   0x1ff4
    1fd3:	73 1e                	jae    0x1ff3
    1fd5:	a1 0e 0b             	mov    ax,ds:0xb0e
    1fd8:	0b 06 10 0b          	or     ax,WORD PTR ds:0xb10
    1fdc:	74 08                	je     0x1fe6
    1fde:	ff 36 d2 0d          	push   WORD PTR ds:0xdd2
    1fe2:	ff 1e 0e 0b          	call   DWORD PTR ds:0xb0e
    1fe6:	3d 01 00             	cmp    ax,0x1
    1fe9:	a1 d2 0d             	mov    ax,ds:0xdd2
    1fec:	77 b5                	ja     0x1fa3
    1fee:	72 03                	jb     0x1ff3
    1ff0:	33 c0                	xor    ax,ax
    1ff2:	99                   	cwd
    1ff3:	c3                   	ret
    1ff4:	ff 36 24 0b          	push   WORD PTR ds:0xb24
    1ff8:	33 d2                	xor    dx,dx
    1ffa:	52                   	push   dx
    1ffb:	50                   	push   ax
    1ffc:	9a ff ff 00 00       	call   0x0:0xffff
    2001:	3d 01 00             	cmp    ax,0x1
    2004:	72 07                	jb     0x200d
    2006:	50                   	push   ax
    2007:	9a ff ff 00 00       	call   0x0:0xffff
    200c:	f8                   	clc
    200d:	c3                   	ret
    200e:	05 03 00             	add    ax,0x3
    2011:	24 fc                	and    al,0xfc
    2013:	8b 0e 1e 0b          	mov    cx,WORD PTR ds:0xb1e
    2017:	e3 12                	jcxz   0x202b
    2019:	8e c1                	mov    es,cx
    201b:	e8 5a 00             	call   0x2078
    201e:	73 13                	jae    0x2033
    2020:	26 8b 0e 0a 00       	mov    cx,WORD PTR es:0xa
    2025:	3b 0e 1e 0b          	cmp    cx,WORD PTR ds:0xb1e
    2029:	75 ee                	jne    0x2019
    202b:	e8 0e 00             	call   0x203c
    202e:	72 0b                	jb     0x203b
    2030:	e8 45 00             	call   0x2078
    2033:	8c 06 1e 0b          	mov    WORD PTR ds:0xb1e,es
    2037:	8b c3                	mov    ax,bx
    2039:	8c c2                	mov    dx,es
    203b:	c3                   	ret
    203c:	50                   	push   ax
    203d:	a1 22 0b             	mov    ax,ds:0xb22
    2040:	e8 b1 ff             	call   0x1ff4
    2043:	72 31                	jb     0x2076
    2045:	8e c2                	mov    es,dx
    2047:	33 ff                	xor    di,di
    2049:	fc                   	cld
    204a:	b8 54 50             	mov    ax,0x5054
    204d:	ab                   	stos   WORD PTR es:[di],ax
    204e:	33 c0                	xor    ax,ax
    2050:	ab                   	stos   WORD PTR es:[di],ax
    2051:	b8 0c 00             	mov    ax,0xc
    2054:	ab                   	stos   WORD PTR es:[di],ax
    2055:	33 c0                	xor    ax,ax
    2057:	ab                   	stos   WORD PTR es:[di],ax
    2058:	a1 22 0b             	mov    ax,ds:0xb22
    205b:	2d 0c 00             	sub    ax,0xc
    205e:	ab                   	stos   WORD PTR es:[di],ax
    205f:	50                   	push   ax
    2060:	8c c0                	mov    ax,es
    2062:	8b 0e 1e 0b          	mov    cx,WORD PTR ds:0xb1e
    2066:	e3 08                	jcxz   0x2070
    2068:	1e                   	push   ds
    2069:	8e d9                	mov    ds,cx
    206b:	87 06 0a 00          	xchg   WORD PTR ds:0xa,ax
    206f:	1f                   	pop    ds
    2070:	ab                   	stos   WORD PTR es:[di],ax
    2071:	33 c0                	xor    ax,ax
    2073:	ab                   	stos   WORD PTR es:[di],ax
    2074:	58                   	pop    ax
    2075:	ab                   	stos   WORD PTR es:[di],ax
    2076:	58                   	pop    ax
    2077:	c3                   	ret
    2078:	bb 04 00             	mov    bx,0x4
    207b:	8b f3                	mov    si,bx
    207d:	26 8b 1f             	mov    bx,WORD PTR es:[bx]
    2080:	83 fb 01             	cmp    bx,0x1
    2083:	72 23                	jb     0x20a8
    2085:	26 8b 57 02          	mov    dx,WORD PTR es:[bx+0x2]
    2089:	2b d0                	sub    dx,ax
    208b:	72 ee                	jb     0x207b
    208d:	26 8b 0f             	mov    cx,WORD PTR es:[bx]
    2090:	74 0d                	je     0x209f
    2092:	8b fb                	mov    di,bx
    2094:	03 f8                	add    di,ax
    2096:	26 89 0d             	mov    WORD PTR es:[di],cx
    2099:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    209d:	8b cf                	mov    cx,di
    209f:	26 89 0c             	mov    WORD PTR es:[si],cx
    20a2:	26 29 06 08 00       	sub    WORD PTR es:0x8,ax
    20a7:	f8                   	clc
    20a8:	c3                   	ret
    20a9:	0b c0                	or     ax,ax
    20ab:	74 79                	je     0x2126
    20ad:	e3 7b                	jcxz   0x212a
    20af:	05 03 00             	add    ax,0x3
    20b2:	24 fc                	and    al,0xfc
    20b4:	8e c3                	mov    es,bx
    20b6:	8b d9                	mov    bx,cx
    20b8:	26 81 3e 00 00 54 50 	cmp    WORD PTR es:0x0,0x5054
    20bf:	75 67                	jne    0x2128
    20c1:	f6 c3 03             	test   bl,0x3
    20c4:	75 62                	jne    0x2128
    20c6:	8b 0e 0a 0b          	mov    cx,WORD PTR ds:0xb0a
    20ca:	0b 0e 0c 0b          	or     cx,WORD PTR ds:0xb0c
    20ce:	74 0a                	je     0x20da
    20d0:	50                   	push   ax
    20d1:	06                   	push   es
    20d2:	53                   	push   bx
    20d3:	ff 1e 0a 0b          	call   DWORD PTR ds:0xb0a
    20d7:	5b                   	pop    bx
    20d8:	07                   	pop    es
    20d9:	58                   	pop    ax
    20da:	be 04 00             	mov    si,0x4
    20dd:	8b fe                	mov    di,si
    20df:	26 8b 34             	mov    si,WORD PTR es:[si]
    20e2:	0b f6                	or     si,si
    20e4:	74 06                	je     0x20ec
    20e6:	3b de                	cmp    bx,si
    20e8:	77 f3                	ja     0x20dd
    20ea:	74 3c                	je     0x2128
    20ec:	26 89 37             	mov    WORD PTR es:[bx],si
    20ef:	26 89 47 02          	mov    WORD PTR es:[bx+0x2],ax
    20f3:	26 03 06 08 00       	add    ax,WORD PTR es:0x8
    20f8:	26 a3 08 00          	mov    es:0x8,ax
    20fc:	05 0c 00             	add    ax,0xc
    20ff:	3b 06 22 0b          	cmp    ax,WORD PTR ds:0xb22
    2103:	74 43                	je     0x2148
    2105:	e8 05 00             	call   0x210d
    2108:	26 89 1d             	mov    WORD PTR es:[di],bx
    210b:	8b df                	mov    bx,di
    210d:	8b f3                	mov    si,bx
    210f:	26 03 77 02          	add    si,WORD PTR es:[bx+0x2]
    2113:	26 3b 37             	cmp    si,WORD PTR es:[bx]
    2116:	75 0e                	jne    0x2126
    2118:	26 8b 04             	mov    ax,WORD PTR es:[si]
    211b:	26 89 07             	mov    WORD PTR es:[bx],ax
    211e:	26 8b 44 02          	mov    ax,WORD PTR es:[si+0x2]
    2122:	26 01 47 02          	add    WORD PTR es:[bx+0x2],ax
    2126:	f8                   	clc
    2127:	c3                   	ret
    2128:	f9                   	stc
    2129:	c3                   	ret
    212a:	8c d8                	mov    ax,ds
    212c:	3b c3                	cmp    ax,bx
    212e:	74 f8                	je     0x2128
    2130:	53                   	push   bx
    2131:	9a ff ff 00 00       	call   0x0:0xffff
    2136:	0b c0                	or     ax,ax
    2138:	74 ee                	je     0x2128
    213a:	50                   	push   ax
    213b:	50                   	push   ax
    213c:	9a ff ff 00 00       	call   0x0:0xffff
    2141:	9a ff ff 00 00       	call   0x0:0xffff
    2146:	f8                   	clc
    2147:	c3                   	ret
    2148:	33 c0                	xor    ax,ax
    214a:	8c c3                	mov    bx,es
    214c:	26 8b 16 0a 00       	mov    dx,WORD PTR es:0xa
    2151:	3b da                	cmp    bx,dx
    2153:	74 14                	je     0x2169
    2155:	a1 1e 0b             	mov    ax,ds:0xb1e
    2158:	8e c0                	mov    es,ax
    215a:	26 a1 0a 00          	mov    ax,es:0xa
    215e:	3b c3                	cmp    ax,bx
    2160:	75 f6                	jne    0x2158
    2162:	26 89 16 0a 00       	mov    WORD PTR es:0xa,dx
    2167:	8c c0                	mov    ax,es
    2169:	a3 1e 0b             	mov    ds:0xb1e,ax
    216c:	eb bc                	jmp    0x212a
    216e:	33 c0                	xor    ax,ax
    2170:	87 06 02 0b          	xchg   WORD PTR ds:0xb02,ax
    2174:	cb                   	retf
    2175:	83 3e 02 0b 00       	cmp    WORD PTR ds:0xb02,0x0
    217a:	75 01                	jne    0x217d
    217c:	cb                   	retf
    217d:	b8 00 00             	mov    ax,0x0
    2180:	e9 4a fc             	jmp    0x1dcd
    2183:	8b f4                	mov    si,sp
    2185:	36 8e 44 02          	mov    es,WORD PTR ss:[si+0x2]
    2189:	26 3b 55 02          	cmp    dx,WORD PTR es:[di+0x2]
    218d:	7f 07                	jg     0x2196
    218f:	7c 14                	jl     0x21a5
    2191:	26 3b 05             	cmp    ax,WORD PTR es:[di]
    2194:	72 0f                	jb     0x21a5
    2196:	26 3b 55 06          	cmp    dx,WORD PTR es:[di+0x6]
    219a:	7c 08                	jl     0x21a4
    219c:	7f 07                	jg     0x21a5
    219e:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    21a2:	77 01                	ja     0x21a5
    21a4:	cb                   	retf
    21a5:	b8 04 00             	mov    ax,0x4
    21a8:	e9 22 fc             	jmp    0x1dcd
    21ab:	b8 05 00             	mov    ax,0x5
    21ae:	e9 1c fc             	jmp    0x1dcd
    21b1:	05 00 04             	add    ax,0x400
    21b4:	72 19                	jb     0x21cf
    21b6:	2b c4                	sub    ax,sp
    21b8:	73 15                	jae    0x21cf
    21ba:	f7 d8                	neg    ax
    21bc:	36 3b 06 0a 00       	cmp    ax,WORD PTR ss:0xa
    21c1:	72 0c                	jb     0x21cf
    21c3:	36 3b 06 0c 00       	cmp    ax,WORD PTR ss:0xc
    21c8:	73 04                	jae    0x21ce
    21ca:	36 a3 0c 00          	mov    ss:0xc,ax
    21ce:	cb                   	retf
    21cf:	b8 ca 00             	mov    ax,0xca
    21d2:	e9 27 fc             	jmp    0x1dfc
    21d5:	c6 06 26 0b 01       	mov    BYTE PTR ds:0xb26,0x1
    21da:	2e 80 3e 1c 22 cd    	cmp    BYTE PTR cs:0x221c,0xcd
    21e0:	74 3d                	je     0x221f
    21e2:	55                   	push   bp
    21e3:	8b ec                	mov    bp,sp
    21e5:	83 ec 0a             	sub    sp,0xa
    21e8:	50                   	push   ax
    21e9:	db 7e f6             	fstp   TBYTE PTR [bp-0xa]
    21ec:	dd 06 66 0b          	fld    QWORD PTR ds:0xb66
    21f0:	9b dc 36 6e 0b       	fdiv   QWORD PTR ds:0xb6e
    21f5:	9b dc 0e 6e 0b       	fmul   QWORD PTR ds:0xb6e
    21fa:	9b dc 2e 66 0b       	fsubr  QWORD PTR ds:0xb66
    21ff:	9b dc 1e 76 0b       	fcomp  QWORD PTR ds:0xb76
    2204:	9b 9b df e0          	fstsw  ax
    2208:	9b                   	fwait
    2209:	25 00 01             	and    ax,0x100
    220c:	c1 e8 07             	shr    ax,0x7
    220f:	48                   	dec    ax
    2210:	a2 26 0b             	mov    ds:0xb26,al
    2213:	db 6e f6             	fld    TBYTE PTR [bp-0xa]
    2216:	58                   	pop    ax
    2217:	8b e5                	mov    sp,bp
    2219:	5d                   	pop    bp
    221a:	eb 03                	jmp    0x221f
    221c:	9b d9 c9             	fxch   st(1)
    221f:	80 3e 26 0b 00       	cmp    BYTE PTR ds:0xb26,0x0
    2224:	7e 04                	jle    0x222a
    2226:	9b de f9             	fdivp  st(1),st
    2229:	cb                   	retf
    222a:	74 a9                	je     0x21d5
    222c:	55                   	push   bp
    222d:	8b ec                	mov    bp,sp
    222f:	83 ec 14             	sub    sp,0x14
    2232:	50                   	push   ax
    2233:	db 7e ec             	fstp   TBYTE PTR [bp-0x14]
    2236:	db 7e f6             	fstp   TBYTE PTR [bp-0xa]
    2239:	db 6e f6             	fld    TBYTE PTR [bp-0xa]
    223c:	db 6e ec             	fld    TBYTE PTR [bp-0x14]
    223f:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    2242:	03 c0                	add    ax,ax
    2244:	73 51                	jae    0x2297
    2246:	35 00 0e             	xor    ax,0xe00
    2249:	a9 00 0e             	test   ax,0xe00
    224c:	74 07                	je     0x2255
    224e:	de f9                	fdivp  st(1),st
    2250:	58                   	pop    ax
    2251:	8b e5                	mov    sp,bp
    2253:	5d                   	pop    bp
    2254:	cb                   	retf
    2255:	c1 e8 0c             	shr    ax,0xc
    2258:	53                   	push   bx
    2259:	8b d8                	mov    bx,ax
    225b:	80 bf 4a 0b 00       	cmp    BYTE PTR [bx+0xb4a],0x0
    2260:	5b                   	pop    bx
    2261:	74 eb                	je     0x224e
    2263:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    2266:	25 ff 7f             	and    ax,0x7fff
    2269:	74 e3                	je     0x224e
    226b:	3d ff 7f             	cmp    ax,0x7fff
    226e:	74 de                	je     0x224e
    2270:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2273:	25 ff 7f             	and    ax,0x7fff
    2276:	3d 01 00             	cmp    ax,0x1
    2279:	74 0e                	je     0x2289
    227b:	d8 0e 5a 0b          	fmul   DWORD PTR ds:0xb5a
    227f:	d9 c9                	fxch   st(1)
    2281:	d8 0e 5a 0b          	fmul   DWORD PTR ds:0xb5a
    2285:	d9 c9                	fxch   st(1)
    2287:	eb c5                	jmp    0x224e
    2289:	d8 0e 5e 0b          	fmul   DWORD PTR ds:0xb5e
    228d:	d9 c9                	fxch   st(1)
    228f:	d8 0e 5e 0b          	fmul   DWORD PTR ds:0xb5e
    2293:	d9 c9                	fxch   st(1)
    2295:	eb b7                	jmp    0x224e
    2297:	8b 46 ec             	mov    ax,WORD PTR [bp-0x14]
    229a:	0b 46 ee             	or     ax,WORD PTR [bp-0x12]
    229d:	0b 46 f0             	or     ax,WORD PTR [bp-0x10]
    22a0:	0b 46 f2             	or     ax,WORD PTR [bp-0xe]
    22a3:	74 a9                	je     0x224e
    22a5:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    22a8:	25 ff 7f             	and    ax,0x7fff
    22ab:	75 a1                	jne    0x224e
    22ad:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    22b0:	25 ff 7f             	and    ax,0x7fff
    22b3:	74 0e                	je     0x22c3
    22b5:	3d ff 7f             	cmp    ax,0x7fff
    22b8:	74 94                	je     0x224e
    22ba:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    22bd:	03 c0                	add    ax,ax
    22bf:	73 8d                	jae    0x224e
    22c1:	eb 07                	jmp    0x22ca
    22c3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    22c6:	03 c0                	add    ax,ax
    22c8:	72 84                	jb     0x224e
    22ca:	d9 c9                	fxch   st(1)
    22cc:	dd d8                	fstp   st(0)
    22ce:	d9 c0                	fld    st(0)
    22d0:	d8 0e 62 0b          	fmul   DWORD PTR ds:0xb62
    22d4:	db 7e ec             	fstp   TBYTE PTR [bp-0x14]
    22d7:	db 6e f6             	fld    TBYTE PTR [bp-0xa]
    22da:	d9 c9                	fxch   st(1)
    22dc:	9b                   	fwait
    22dd:	e9 5f ff             	jmp    0x223f
    22e0:	cb                   	retf
    22e1:	3f                   	aas
    22e2:	1f                   	pop    ds
    22e3:	0a c0                	or     al,al
    22e5:	74 22                	je     0x2309
    22e7:	32 c9                	xor    cl,cl
    22e9:	8a ec                	mov    ch,ah
    22eb:	8a e6                	mov    ah,dh
    22ed:	80 e4 80             	and    ah,0x80
    22f0:	05 7e 3f             	add    ax,0x3f7e
    22f3:	80 ce 80             	or     dh,0x80
    22f6:	50                   	push   ax
    22f7:	52                   	push   dx
    22f8:	53                   	push   bx
    22f9:	51                   	push   cx
    22fa:	33 c9                	xor    cx,cx
    22fc:	51                   	push   cx
    22fd:	8b dc                	mov    bx,sp
    22ff:	9b 36 db 2f          	fld    TBYTE PTR ss:[bx]
    2303:	90                   	nop
    2304:	9b                   	fwait
    2305:	83 c4 0a             	add    sp,0xa
    2308:	cb                   	retf
    2309:	9b d9 ee             	fldz
    230c:	cb                   	retf
    230d:	83 ec 0a             	sub    sp,0xa
    2310:	8b dc                	mov    bx,sp
    2312:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    2316:	90                   	nop
    2317:	9b                   	fwait
    2318:	83 c4 02             	add    sp,0x2
    231b:	59                   	pop    cx
    231c:	5b                   	pop    bx
    231d:	5a                   	pop    dx
    231e:	58                   	pop    ax
    231f:	8b f8                	mov    di,ax
    2321:	25 ff 7f             	and    ax,0x7fff
    2324:	2d 7e 3f             	sub    ax,0x3f7e
    2327:	76 1a                	jbe    0x2343
    2329:	0a e4                	or     ah,ah
    232b:	75 21                	jne    0x234e
    232d:	8a e5                	mov    ah,ch
    232f:	d0 e1                	shl    cl,1
    2331:	80 d4 00             	adc    ah,0x0
    2334:	83 d3 00             	adc    bx,0x0
    2337:	83 d2 00             	adc    dx,0x0
    233a:	72 0e                	jb     0x234a
    233c:	d1 e2                	shl    dx,1
    233e:	d1 e7                	shl    di,1
    2340:	d1 da                	rcr    dx,1
    2342:	cb                   	retf
    2343:	33 c0                	xor    ax,ax
    2345:	33 db                	xor    bx,bx
    2347:	33 d2                	xor    dx,dx
    2349:	cb                   	retf
    234a:	fe c0                	inc    al
    234c:	75 ee                	jne    0x233c
    234e:	b8 08 00             	mov    ax,0x8
    2351:	e9 79 fa             	jmp    0x1dcd
    2354:	9b d9 3e d8 0d       	fstcw  WORD PTR ds:0xdd8
    2359:	9b 2e d9 2e e1 22    	fldcw  WORD PTR cs:0x22e1
    235f:	9b db 1e d4 0d       	fistp  DWORD PTR ds:0xdd4
    2364:	90                   	nop
    2365:	9b 9b d9 2e d8 0d    	fldcw  WORD PTR ds:0xdd8
    236b:	90                   	nop
    236c:	9b                   	fwait
    236d:	a1 d4 0d             	mov    ax,ds:0xdd4
    2370:	8b 16 d6 0d          	mov    dx,WORD PTR ds:0xdd6
    2374:	cb                   	retf
    2375:	9b d9 fc             	frndint
    2378:	9b db 1e d4 0d       	fistp  DWORD PTR ds:0xdd4
    237d:	90                   	nop
    237e:	9b                   	fwait
    237f:	a1 d4 0d             	mov    ax,ds:0xdd4
    2382:	8b 16 d6 0d          	mov    dx,WORD PTR ds:0xdd6
    2386:	cb                   	retf
    2387:	9b d9 3e d8 0d       	fstcw  WORD PTR ds:0xdd8
    238c:	9b 2e d9 2e e1 22    	fldcw  WORD PTR cs:0x22e1
    2392:	9b d9 fc             	frndint
    2395:	90                   	nop
    2396:	9b 9b d9 2e d8 0d    	fldcw  WORD PTR ds:0xdd8
    239c:	cb                   	retf
    239d:	9b d9 3e d8 0d       	fstcw  WORD PTR ds:0xdd8
    23a2:	9b 2e d9 2e e1 22    	fldcw  WORD PTR cs:0x22e1
    23a8:	9b d9 c0             	fld    st(0)
    23ab:	9b d9 fc             	frndint
    23ae:	9b de e9             	fsubp  st(1),st
    23b1:	90                   	nop
    23b2:	9b 9b d9 2e d8 0d    	fldcw  WORD PTR ds:0xdd8
    23b8:	cb                   	retf
    23b9:	9b d9 fa             	fsqrt
    23bc:	cb                   	retf
    23bd:	e8 43 00             	call   0x2403
    23c0:	cb                   	retf
    23c1:	e8 43 00             	call   0x2407
    23c4:	cb                   	retf
    23c5:	e8 38 01             	call   0x2500
    23c8:	cb                   	retf
    23c9:	e8 a7 01             	call   0x2573
    23cc:	cb                   	retf
    23cd:	e8 1d 02             	call   0x25ed
    23d0:	cb                   	retf
    23d1:	35 c2 68             	xor    ax,0x68c2
    23d4:	21 a2 da 0f          	and    WORD PTR [bp+si+0xfda],sp
    23d8:	c9                   	leave
    23d9:	fe                   	(bad)
    23da:	3f                   	aas
    23db:	35 c2 68             	xor    ax,0x68c2
    23de:	21 a2 da 0f          	and    WORD PTR [bp+si+0xfda],sp
    23e2:	c9                   	leave
    23e3:	ff                   	(bad)
    23e4:	3f                   	aas
    23e5:	00 42 c0             	add    BYTE PTR [bp+si-0x40],al
    23e8:	ff 00                	inc    WORD PTR [bx+si]
    23ea:	48                   	dec    ax
    23eb:	c0 ff 00             	sar    bh,0x0
    23ee:	4a                   	dec    dx
    23ef:	c0 ff 00             	sar    bh,0x0
    23f2:	00 00                	add    BYTE PTR [bx+si],al
    23f4:	3f                   	aas
    23f5:	85 64 de             	test   WORD PTR [si-0x22],sp
    23f8:	f9                   	stc
    23f9:	33 f3                	xor    si,bx
    23fb:	04 b5                	add    al,0xb5
    23fd:	ff                   	(bad)
    23fe:	3f                   	aas
    23ff:	00 00                	add    BYTE PTR [bx+si],al
    2401:	80 7f b1 00          	cmp    BYTE PTR [bx-0x4f],0x0
    2405:	eb 06                	jmp    0x240d
    2407:	b1 02                	mov    cl,0x2
    2409:	eb 02                	jmp    0x240d
    240b:	b1 04                	mov    cl,0x4
    240d:	9b d9 e5             	fxam
    2410:	55                   	push   bp
    2411:	8b ec                	mov    bp,sp
    2413:	8d 66 fe             	lea    sp,[bp-0x2]
    2416:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    241a:	9b                   	fwait
    241b:	8a 66 ff             	mov    ah,BYTE PTR [bp-0x1]
    241e:	9e                   	sahf
    241f:	72 0f                	jb     0x2430
    2421:	75 2e                	jne    0x2451
    2423:	80 f9 02             	cmp    cl,0x2
    2426:	75 06                	jne    0x242e
    2428:	9b dd d8             	fstp   st(0)
    242b:	9b d9 e8             	fld1
    242e:	eb 1e                	jmp    0x244e
    2430:	74 0e                	je     0x2440
    2432:	7b 0c                	jnp    0x2440
    2434:	9b dd d8             	fstp   st(0)
    2437:	9b 2e d9 06 e5 23    	fld    DWORD PTR cs:0x23e5
    243d:	9b d9 e4             	ftst
    2440:	eb 0c                	jmp    0x244e
    2442:	9b de d9             	fcompp
    2445:	9b 2e d9 06 e5 23    	fld    DWORD PTR cs:0x23e5
    244b:	9b d9 e4             	ftst
    244e:	e9 ab 00             	jmp    0x24fc
    2451:	9b d9 e1             	fabs
    2454:	9b 2e db 2e d1 23    	fld    TBYTE PTR cs:0x23d1
    245a:	9b d9 e5             	fxam
    245d:	9b d9 c9             	fxch   st(1)
    2460:	9b d9 f8             	fprem
    2463:	b5 02                	mov    ch,0x2
    2465:	22 ec                	and    ch,ah
    2467:	d0 ed                	shr    ch,1
    2469:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    246d:	9b                   	fwait
    246e:	8a 66 ff             	mov    ah,BYTE PTR [bp-0x1]
    2471:	9e                   	sahf
    2472:	7a ce                	jp     0x2442
    2474:	b0 03                	mov    al,0x3
    2476:	22 c4                	and    al,ah
    2478:	d0 e4                	shl    ah,1
    247a:	d0 e4                	shl    ah,1
    247c:	d0 d0                	rcl    al,1
    247e:	04 fc                	add    al,0xfc
    2480:	d0 d0                	rcl    al,1
    2482:	80 f9 02             	cmp    cl,0x2
    2485:	75 04                	jne    0x248b
    2487:	02 c1                	add    al,cl
    2489:	b5 00                	mov    ch,0x0
    248b:	24 07                	and    al,0x7
    248d:	a8 01                	test   al,0x1
    248f:	74 05                	je     0x2496
    2491:	9b de e9             	fsubp  st(1),st
    2494:	eb 03                	jmp    0x2499
    2496:	9b dd d9             	fstp   st(1)
    2499:	9b d9 f2             	fptan
    249c:	80 f9 04             	cmp    cl,0x4
    249f:	74 29                	je     0x24ca
    24a1:	a8 03                	test   al,0x3
    24a3:	7a 03                	jp     0x24a8
    24a5:	9b d9 c9             	fxch   st(1)
    24a8:	9b d9 c1             	fld    st(1)
    24ab:	9b d8 c8             	fmul   st,st(0)
    24ae:	9b d9 c9             	fxch   st(1)
    24b1:	9b d8 c8             	fmul   st,st(0)
    24b4:	9b de c1             	faddp  st(1),st
    24b7:	9b d9 fa             	fsqrt
    24ba:	d0 e8                	shr    al,1
    24bc:	d0 e8                	shr    al,1
    24be:	32 c5                	xor    al,ch
    24c0:	74 03                	je     0x24c5
    24c2:	9b d9 e0             	fchs
    24c5:	9b de f9             	fdivp  st(1),st
    24c8:	eb 32                	jmp    0x24fc
    24ca:	8a e0                	mov    ah,al
    24cc:	d0 ec                	shr    ah,1
    24ce:	80 e4 01             	and    ah,0x1
    24d1:	32 e5                	xor    ah,ch
    24d3:	74 03                	je     0x24d8
    24d5:	9b d9 e0             	fchs
    24d8:	a8 03                	test   al,0x3
    24da:	7a 1d                	jp     0x24f9
    24dc:	9b d9 c9             	fxch   st(1)
    24df:	9b d9 e4             	ftst
    24e2:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    24e6:	90                   	nop
    24e7:	9b                   	fwait
    24e8:	f6 46 ff 40          	test   BYTE PTR [bp-0x1],0x40
    24ec:	74 0b                	je     0x24f9
    24ee:	9b de d9             	fcompp
    24f1:	9b 2e d9 06 ff 23    	fld    DWORD PTR cs:0x23ff
    24f7:	eb 03                	jmp    0x24fc
    24f9:	9b de f9             	fdivp  st(1),st
    24fc:	8b e5                	mov    sp,bp
    24fe:	5d                   	pop    bp
    24ff:	c3                   	ret
    2500:	9b d9 e5             	fxam
    2503:	55                   	push   bp
    2504:	8b ec                	mov    bp,sp
    2506:	8d 66 fe             	lea    sp,[bp-0x2]
    2509:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    250d:	9b                   	fwait
    250e:	8a 66 ff             	mov    ah,BYTE PTR [bp-0x1]
    2511:	9e                   	sahf
    2512:	91                   	xchg   cx,ax
    2513:	72 04                	jb     0x2519
    2515:	75 1c                	jne    0x2533
    2517:	eb 4c                	jmp    0x2565
    2519:	74 4a                	je     0x2565
    251b:	7b 48                	jnp    0x2565
    251d:	9b dd d8             	fstp   st(0)
    2520:	9b 2e db 2e db 23    	fld    TBYTE PTR cs:0x23db
    2526:	eb 35                	jmp    0x255d
    2528:	9b de d9             	fcompp
    252b:	9b 2e db 2e d1 23    	fld    TBYTE PTR cs:0x23d1
    2531:	eb 2a                	jmp    0x255d
    2533:	9b d9 e1             	fabs
    2536:	9b d9 e8             	fld1
    2539:	9b d8 d1             	fcom   st(1)
    253c:	9b dd 7e fe          	fstsw  WORD PTR [bp-0x2]
    2540:	9b                   	fwait
    2541:	8a 66 ff             	mov    ah,BYTE PTR [bp-0x1]
    2544:	9e                   	sahf
    2545:	74 e1                	je     0x2528
    2547:	73 03                	jae    0x254c
    2549:	9b d9 c9             	fxch   st(1)
    254c:	9b d9 f3             	fpatan
    254f:	73 0c                	jae    0x255d
    2551:	9b 2e db 2e db 23    	fld    TBYTE PTR cs:0x23db
    2557:	9b de e9             	fsubp  st(1),st
    255a:	80 f5 02             	xor    ch,0x2
    255d:	f6 c5 02             	test   ch,0x2
    2560:	74 03                	je     0x2565
    2562:	9b d9 e0             	fchs
    2565:	8b e5                	mov    sp,bp
    2567:	5d                   	pop    bp
    2568:	c3                   	ret
    2569:	9b d9 e8             	fld1
    256c:	eb 08                	jmp    0x2576
    256e:	9b d9 ec             	fldlg2
    2571:	eb 03                	jmp    0x2576
    2573:	9b d9 ed             	fldln2
    2576:	9b d9 c9             	fxch   st(1)
    2579:	55                   	push   bp
    257a:	8b ec                	mov    bp,sp
    257c:	9b d9 e5             	fxam
    257f:	8d 66 f6             	lea    sp,[bp-0xa]
    2582:	9b dd 7e f6          	fstsw  WORD PTR [bp-0xa]
    2586:	9b                   	fwait
    2587:	8a 66 f7             	mov    ah,BYTE PTR [bp-0x9]
    258a:	9e                   	sahf
    258b:	72 0c                	jb     0x2599
    258d:	74 05                	je     0x2594
    258f:	f6 c4 02             	test   ah,0x2
    2592:	74 22                	je     0x25b6
    2594:	9b dd d8             	fstp   st(0)
    2597:	eb 0f                	jmp    0x25a8
    2599:	74 16                	je     0x25b1
    259b:	9b dd d9             	fstp   st(1)
    259e:	7b 11                	jnp    0x25b1
    25a0:	9b dd d9             	fstp   st(1)
    25a3:	f6 c4 02             	test   ah,0x2
    25a6:	74 33                	je     0x25db
    25a8:	9b dd d8             	fstp   st(0)
    25ab:	9b 2e d9 06 e9 23    	fld    DWORD PTR cs:0x23e9
    25b1:	9b d9 e4             	ftst
    25b4:	eb 25                	jmp    0x25db
    25b6:	9b d9 c0             	fld    st(0)
    25b9:	9b db 7e f6          	fstp   TBYTE PTR [bp-0xa]
    25bd:	90                   	nop
    25be:	9b                   	fwait
    25bf:	81 7e fe ff 3f       	cmp    WORD PTR [bp-0x2],0x3fff
    25c4:	75 12                	jne    0x25d8
    25c6:	81 7e fc 00 80       	cmp    WORD PTR [bp-0x4],0x8000
    25cb:	75 0b                	jne    0x25d8
    25cd:	9b d9 e8             	fld1
    25d0:	9b de e9             	fsubp  st(1),st
    25d3:	9b d9 f9             	fyl2xp1
    25d6:	eb 03                	jmp    0x25db
    25d8:	9b d9 f1             	fyl2x
    25db:	8b e5                	mov    sp,bp
    25dd:	5d                   	pop    bp
    25de:	c3                   	ret
    25df:	2b c9                	sub    cx,cx
    25e1:	eb 12                	jmp    0x25f5
    25e3:	9b d9 e9             	fldl2t
    25e6:	b1 01                	mov    cl,0x1
    25e8:	9b d9 c9             	fxch   st(1)
    25eb:	eb 08                	jmp    0x25f5
    25ed:	9b d9 ea             	fldl2e
    25f0:	b1 01                	mov    cl,0x1
    25f2:	9b d9 c9             	fxch   st(1)
    25f5:	9b d9 e5             	fxam
    25f8:	55                   	push   bp
    25f9:	8b ec                	mov    bp,sp
    25fb:	8d 66 fc             	lea    sp,[bp-0x4]
    25fe:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
    2602:	e3 03                	jcxz   0x2607
    2604:	9b d9 c9             	fxch   st(1)
    2607:	9b                   	fwait
    2608:	8a 66 fd             	mov    ah,BYTE PTR [bp-0x3]
    260b:	9e                   	sahf
    260c:	93                   	xchg   bx,ax
    260d:	72 10                	jb     0x261f
    260f:	75 29                	jne    0x263a
    2611:	9b dd d8             	fstp   st(0)
    2614:	e3 03                	jcxz   0x2619
    2616:	9b dd d8             	fstp   st(0)
    2619:	9b d9 e8             	fld1
    261c:	e9 a8 00             	jmp    0x26c7
    261f:	e3 03                	jcxz   0x2624
    2621:	9b dd d8             	fstp   st(0)
    2624:	74 0e                	je     0x2634
    2626:	7b 0c                	jnp    0x2634
    2628:	9b dd d8             	fstp   st(0)
    262b:	9b 2e d9 06 ff 23    	fld    DWORD PTR cs:0x23ff
    2631:	e9 88 00             	jmp    0x26bc
    2634:	9b d9 e4             	ftst
    2637:	e9 8d 00             	jmp    0x26c7
    263a:	e3 03                	jcxz   0x263f
    263c:	9b de c9             	fmulp  st(1),st
    263f:	9b d9 e1             	fabs
    2642:	9b 2e d8 16 f1 23    	fcom   DWORD PTR cs:0x23f1
    2648:	9b dd 7e fc          	fstsw  WORD PTR [bp-0x4]
    264c:	9b                   	fwait
    264d:	f6 46 fd 41          	test   BYTE PTR [bp-0x3],0x41
    2651:	74 0b                	je     0x265e
    2653:	9b d9 f0             	f2xm1
    2656:	9b d9 e8             	fld1
    2659:	9b de c1             	faddp  st(1),st
    265c:	eb 5e                	jmp    0x26bc
    265e:	9b d9 e8             	fld1
    2661:	9b d9 c1             	fld    st(1)
    2664:	9b d9 7e fc          	fstcw  WORD PTR [bp-0x4]
    2668:	9b d9 fd             	fscale
    266b:	80 4e fd 0f          	or     BYTE PTR [bp-0x3],0xf
    266f:	90                   	nop
    2670:	9b 9b d9 6e fc       	fldcw  WORD PTR [bp-0x4]
    2675:	9b d9 fc             	frndint
    2678:	80 66 fd f3          	and    BYTE PTR [bp-0x3],0xf3
    267c:	90                   	nop
    267d:	9b 9b d9 6e fc       	fldcw  WORD PTR [bp-0x4]
    2682:	9b df 56 fe          	fist   WORD PTR [bp-0x2]
    2686:	9b d9 c9             	fxch   st(1)
    2689:	9b d9 e0             	fchs
    268c:	9b d9 c9             	fxch   st(1)
    268f:	9b d9 fd             	fscale
    2692:	9b dd d9             	fstp   st(1)
    2695:	9b de e9             	fsubp  st(1),st
    2698:	9b d9 f0             	f2xm1
    269b:	9b d9 e8             	fld1
    269e:	9b de c1             	faddp  st(1),st
    26a1:	d1 6e fe             	shr    WORD PTR [bp-0x2],1
    26a4:	73 09                	jae    0x26af
    26a6:	9b 2e db 2e f5 23    	fld    TBYTE PTR cs:0x23f5
    26ac:	9b de c9             	fmulp  st(1),st
    26af:	9b df 46 fe          	fild   WORD PTR [bp-0x2]
    26b3:	9b d9 c9             	fxch   st(1)
    26b6:	9b d9 fd             	fscale
    26b9:	9b dd d9             	fstp   st(1)
    26bc:	f6 c7 02             	test   bh,0x2
    26bf:	74 06                	je     0x26c7
    26c1:	9b d9 e8             	fld1
    26c4:	9b de f1             	fdivrp st(1),st
    26c7:	8b e5                	mov    sp,bp
    26c9:	5d                   	pop    bp
    26ca:	c3                   	ret
    26cb:	8b 2e e2 0a          	mov    bp,WORD PTR ds:0xae2
    26cf:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    26d2:	a3 e2 0a             	mov    ds:0xae2,ax
    26d5:	8b 26 e4 0a          	mov    sp,WORD PTR ds:0xae4
    26d9:	8f 06 e4 0a          	pop    WORD PTR ds:0xae4
    26dd:	eb 03                	jmp    0x26e2
    26df:	e8 0a 01             	call   0x27ec
    26e2:	1e                   	push   ds
    26e3:	8b 2e e2 0a          	mov    bp,WORD PTR ds:0xae2
    26e7:	eb 3a                	jmp    0x2723
    26e9:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    26ec:	26 8b 0d             	mov    cx,WORD PTR es:[di]
    26ef:	e3 4d                	jcxz   0x273e
    26f1:	47                   	inc    di
    26f2:	47                   	inc    di
    26f3:	26 8b 05             	mov    ax,WORD PTR es:[di]
    26f6:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    26fa:	8b d8                	mov    bx,ax
    26fc:	0b da                	or     bx,dx
    26fe:	74 51                	je     0x2751
    2700:	8b f4                	mov    si,sp
    2702:	36 c5 74 06          	lds    si,DWORD PTR ss:[si+0x6]
    2706:	c5 34                	lds    si,DWORD PTR [si]
    2708:	3b f0                	cmp    si,ax
    270a:	75 06                	jne    0x2712
    270c:	8c db                	mov    bx,ds
    270e:	3b da                	cmp    bx,dx
    2710:	74 3f                	je     0x2751
    2712:	c5 74 ec             	lds    si,DWORD PTR [si-0x14]
    2715:	8c db                	mov    bx,ds
    2717:	0b de                	or     bx,si
    2719:	75 ed                	jne    0x2708
    271b:	83 c7 08             	add    di,0x8
    271e:	e2 d3                	loop   0x26f3
    2720:	8b 6e 00             	mov    bp,WORD PTR [bp+0x0]
    2723:	0b ed                	or     bp,bp
    2725:	75 c2                	jne    0x26e9
    2727:	1f                   	pop    ds
    2728:	a1 e6 0a             	mov    ax,ds:0xae6
    272b:	0b 06 e8 0a          	or     ax,WORD PTR ds:0xae8
    272f:	74 07                	je     0x2738
    2731:	e8 b1 01             	call   0x28e5
    2734:	ff 1e e6 0a          	call   DWORD PTR ds:0xae6
    2738:	b8 d9 00             	mov    ax,0xd9
    273b:	e9 be f6             	jmp    0x1dfc
    273e:	1f                   	pop    ds
    273f:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    2742:	a3 e2 0a             	mov    ds:0xae2,ax
    2745:	8b 6e 02             	mov    bp,WORD PTR [bp+0x2]
    2748:	e8 0f 01             	call   0x285a
    274b:	26 ff 5d 02          	call   DWORD PTR es:[di+0x2]
    274f:	eb 91                	jmp    0x26e2
    2751:	1f                   	pop    ds
    2752:	59                   	pop    cx
    2753:	5b                   	pop    bx
    2754:	58                   	pop    ax
    2755:	5a                   	pop    dx
    2756:	8b e5                	mov    sp,bp
    2758:	89 2e e2 0a          	mov    WORD PTR ds:0xae2,bp
    275c:	c7 46 04 90 27       	mov    WORD PTR [bp+0x4],0x2790
    2761:	8c 4e 06             	mov    WORD PTR [bp+0x6],cs
    2764:	8b 6e 02             	mov    bp,WORD PTR [bp+0x2]
    2767:	52                   	push   dx
    2768:	50                   	push   ax
    2769:	53                   	push   bx
    276a:	51                   	push   cx
    276b:	ff 36 e4 0a          	push   WORD PTR ds:0xae4
    276f:	89 26 e4 0a          	mov    WORD PTR ds:0xae4,sp
    2773:	e8 0f 01             	call   0x2885
    2776:	26 ff 6d 04          	jmp    DWORD PTR es:[di+0x4]
    277a:	e8 39 01             	call   0x28b6
    277d:	55                   	push   bp
    277e:	0e                   	push   cs
    277f:	e8 14 00             	call   0x2796
    2782:	8b 2e e2 0a          	mov    bp,WORD PTR ds:0xae2
    2786:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    2789:	a3 e2 0a             	mov    ds:0xae2,ax
    278c:	5d                   	pop    bp
    278d:	ca 12 00             	retf   0x12
    2790:	00 00                	add    BYTE PTR [bx+si],al
    2792:	ff                   	(bad)
    2793:	ff 00                	inc    WORD PTR [bx+si]
    2795:	00 8b 2e e4          	add    BYTE PTR [bp+di-0x1bd2],cl
    2799:	0a b0 01 50          	or     dh,BYTE PTR [bx+si+0x5001]
    279d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27a0:	06                   	push   es
    27a1:	57                   	push   di
    27a2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    27a5:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    27a9:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    27ac:	a3 e4 0a             	mov    ds:0xae4,ax
    27af:	cb                   	retf
    27b0:	8b dc                	mov    bx,sp
    27b2:	36 8b 47 04          	mov    ax,WORD PTR ss:[bx+0x4]
    27b6:	a3 e2 0a             	mov    ds:0xae2,ax
    27b9:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    27bd:	26 83 3d 00          	cmp    WORD PTR es:[di],0x0
    27c1:	75 24                	jne    0x27e7
    27c3:	83 3e ea 0d 00       	cmp    WORD PTR ds:0xdea,0x0
    27c8:	74 19                	je     0x27e3
    27ca:	c7 06 ee 0d 03 00    	mov    WORD PTR ds:0xdee,0x3
    27d0:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    27d4:	8f 06 f0 0d          	pop    WORD PTR ds:0xdf0
    27d8:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    27dc:	8f 06 f2 0d          	pop    WORD PTR ds:0xdf2
    27e0:	e8 07 00             	call   0x27ea
    27e3:	26 ff 5d 02          	call   DWORD PTR es:[di+0x2]
    27e7:	ca 08 00             	retf   0x8
    27ea:	90                   	nop
    27eb:	c3                   	ret
    27ec:	83 3e ea 0d 00       	cmp    WORD PTR ds:0xdea,0x0
    27f1:	74 66                	je     0x2859
    27f3:	8b dc                	mov    bx,sp
    27f5:	be 06 00             	mov    si,0x6
    27f8:	e8 15 01             	call   0x2910
    27fb:	75 5c                	jne    0x2859
    27fd:	55                   	push   bp
    27fe:	8b ec                	mov    bp,sp
    2800:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    2803:	a3 f0 0d             	mov    ds:0xdf0,ax
    2806:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2809:	a3 f2 0d             	mov    ds:0xdf2,ax
    280c:	33 c0                	xor    ax,ax
    280e:	a3 f8 0d             	mov    ds:0xdf8,ax
    2811:	a3 00 0e             	mov    ds:0xe00,ax
    2814:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2817:	8c c0                	mov    ax,es
    2819:	0b c7                	or     ax,di
    281b:	74 3c                	je     0x2859
    281d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2820:	26 8b 7d e8          	mov    di,WORD PTR es:[di-0x18]
    2824:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2827:	47                   	inc    di
    2828:	a2 f8 0d             	mov    ds:0xdf8,al
    282b:	89 3e fc 0d          	mov    WORD PTR ds:0xdfc,di
    282f:	8c 06 fe 0d          	mov    WORD PTR ds:0xdfe,es
    2833:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    2836:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    283a:	8c c0                	mov    ax,es
    283c:	0b c7                	or     ax,di
    283e:	74 0f                	je     0x284f
    2840:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2843:	47                   	inc    di
    2844:	a2 00 0e             	mov    ds:0xe00,al
    2847:	89 3e 04 0e          	mov    WORD PTR ds:0xe04,di
    284b:	8c 06 06 0e          	mov    WORD PTR ds:0xe06,es
    284f:	c7 06 ee 0d 01 00    	mov    WORD PTR ds:0xdee,0x1
    2855:	5d                   	pop    bp
    2856:	e8 91 ff             	call   0x27ea
    2859:	c3                   	ret
    285a:	83 3e ea 0d 00       	cmp    WORD PTR ds:0xdea,0x0
    285f:	74 23                	je     0x2884
    2861:	8b dc                	mov    bx,sp
    2863:	be 06 00             	mov    si,0x6
    2866:	e8 a7 00             	call   0x2910
    2869:	75 19                	jne    0x2884
    286b:	c7 06 ee 0d 03 00    	mov    WORD PTR ds:0xdee,0x3
    2871:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2875:	8f 06 f0 0d          	pop    WORD PTR ds:0xdf0
    2879:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    287d:	8f 06 f2 0d          	pop    WORD PTR ds:0xdf2
    2881:	e8 66 ff             	call   0x27ea
    2884:	c3                   	ret
    2885:	83 3e ea 0d 00       	cmp    WORD PTR ds:0xdea,0x0
    288a:	74 29                	je     0x28b5
    288c:	8b 1e e4 0a          	mov    bx,WORD PTR ds:0xae4
    2890:	be 06 00             	mov    si,0x6
    2893:	52                   	push   dx
    2894:	50                   	push   ax
    2895:	e8 78 00             	call   0x2910
    2898:	58                   	pop    ax
    2899:	5a                   	pop    dx
    289a:	75 19                	jne    0x28b5
    289c:	c7 06 ee 0d 02 00    	mov    WORD PTR ds:0xdee,0x2
    28a2:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    28a6:	8f 06 f0 0d          	pop    WORD PTR ds:0xdf0
    28aa:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    28ae:	8f 06 f2 0d          	pop    WORD PTR ds:0xdf2
    28b2:	e8 35 ff             	call   0x27ea
    28b5:	c3                   	ret
    28b6:	83 3e ea 0d 00       	cmp    WORD PTR ds:0xdea,0x0
    28bb:	74 27                	je     0x28e4
    28bd:	8b 1e e4 0a          	mov    bx,WORD PTR ds:0xae4
    28c1:	be 06 00             	mov    si,0x6
    28c4:	e8 49 00             	call   0x2910
    28c7:	75 1b                	jne    0x28e4
    28c9:	c7 06 ee 0d 05 00    	mov    WORD PTR ds:0xdee,0x5
    28cf:	5b                   	pop    bx
    28d0:	8f 06 f0 0d          	pop    WORD PTR ds:0xdf0
    28d4:	8f 06 f2 0d          	pop    WORD PTR ds:0xdf2
    28d8:	ff 36 f2 0d          	push   WORD PTR ds:0xdf2
    28dc:	ff 36 f0 0d          	push   WORD PTR ds:0xdf0
    28e0:	53                   	push   bx
    28e1:	e8 06 ff             	call   0x27ea
    28e4:	c3                   	ret
    28e5:	83 3e ea 0d 00       	cmp    WORD PTR ds:0xdea,0x0
    28ea:	74 23                	je     0x290f
    28ec:	8b dc                	mov    bx,sp
    28ee:	be 06 00             	mov    si,0x6
    28f1:	e8 1c 00             	call   0x2910
    28f4:	75 19                	jne    0x290f
    28f6:	c7 06 ee 0d 04 00    	mov    WORD PTR ds:0xdee,0x4
    28fc:	ff 36 e6 0a          	push   WORD PTR ds:0xae6
    2900:	8f 06 f0 0d          	pop    WORD PTR ds:0xdf0
    2904:	ff 36 e8 0a          	push   WORD PTR ds:0xae8
    2908:	8f 06 f2 0d          	pop    WORD PTR ds:0xdf2
    290c:	e8 db fe             	call   0x27ea
    290f:	c3                   	ret
    2910:	36 8b 00             	mov    ax,WORD PTR ss:[bx+si]
    2913:	36 0b 40 02          	or     ax,WORD PTR ss:[bx+si+0x2]
    2917:	74 13                	je     0x292c
    2919:	06                   	push   es
    291a:	57                   	push   di
    291b:	36 c4 38             	les    di,DWORD PTR ss:[bx+si]
    291e:	8b 0e ee 0a          	mov    cx,WORD PTR ds:0xaee
    2922:	8b 1e f0 0a          	mov    bx,WORD PTR ds:0xaf0
    2926:	e8 f7 09             	call   0x3320
    2929:	5f                   	pop    di
    292a:	07                   	pop    es
    292b:	c3                   	ret
    292c:	83 cb 01             	or     bx,0x1
    292f:	c3                   	ret
    2930:	c7 06 24 00 da 0d    	mov    WORD PTR ds:0x24,0xdda
    2936:	8c 1e 26 00          	mov    WORD PTR ds:0x26,ds
    293a:	c7 06 e6 0d ea 27    	mov    WORD PTR ds:0xde6,0x27ea
    2940:	8c 0e e8 0d          	mov    WORD PTR ds:0xde8,cs
    2944:	c7 06 0c 0e 7a 27    	mov    WORD PTR ds:0xe0c,0x277a
    294a:	8c 0e 0e 0e          	mov    WORD PTR ds:0xe0e,cs
    294e:	a1 f2 0a             	mov    ax,ds:0xaf2
    2951:	0b 06 f4 0a          	or     ax,WORD PTR ds:0xaf4
    2955:	74 09                	je     0x2960
    2957:	b8 da 0d             	mov    ax,0xdda
    295a:	8c da                	mov    dx,ds
    295c:	ff 1e f2 0a          	call   DWORD PTR ds:0xaf2
    2960:	c3                   	ret
    2961:	8b dc                	mov    bx,sp
    2963:	8c da                	mov    dx,ds
    2965:	36 c5 77 0a          	lds    si,DWORD PTR ss:[bx+0xa]
    2969:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    296d:	36 8b 4f 04          	mov    cx,WORD PTR ss:[bx+0x4]
    2971:	fc                   	cld
    2972:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2974:	8e da                	mov    ds,dx
    2976:	ca 0a 00             	retf   0xa
    2979:	fc                   	cld
    297a:	8b dc                	mov    bx,sp
    297c:	8c da                	mov    dx,ds
    297e:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    2982:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    2986:	ac                   	lods   al,BYTE PTR ds:[si]
    2987:	aa                   	stos   BYTE PTR es:[di],al
    2988:	8a c8                	mov    cl,al
    298a:	32 ed                	xor    ch,ch
    298c:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    298e:	8e da                	mov    ds,dx
    2990:	ca 04 00             	retf   0x4
    2993:	fc                   	cld
    2994:	8b dc                	mov    bx,sp
    2996:	8c da                	mov    dx,ds
    2998:	36 c5 77 0a          	lds    si,DWORD PTR ss:[bx+0xa]
    299c:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    29a0:	36 8b 4f 04          	mov    cx,WORD PTR ss:[bx+0x4]
    29a4:	ac                   	lods   al,BYTE PTR ds:[si]
    29a5:	3a c1                	cmp    al,cl
    29a7:	76 02                	jbe    0x29ab
    29a9:	8a c1                	mov    al,cl
    29ab:	aa                   	stos   BYTE PTR es:[di],al
    29ac:	8a c8                	mov    cl,al
    29ae:	32 ed                	xor    ch,ch
    29b0:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    29b2:	8e da                	mov    ds,dx
    29b4:	ca 0a 00             	retf   0xa
    29b7:	fc                   	cld
    29b8:	8b dc                	mov    bx,sp
    29ba:	8c da                	mov    dx,ds
    29bc:	36 c4 7f 0c          	les    di,DWORD PTR ss:[bx+0xc]
    29c0:	36 c5 77 08          	lds    si,DWORD PTR ss:[bx+0x8]
    29c4:	8a 04                	mov    al,BYTE PTR [si]
    29c6:	32 e4                	xor    ah,ah
    29c8:	36 8b 4f 06          	mov    cx,WORD PTR ss:[bx+0x6]
    29cc:	0b c9                	or     cx,cx
    29ce:	7f 03                	jg     0x29d3
    29d0:	b9 01 00             	mov    cx,0x1
    29d3:	03 f1                	add    si,cx
    29d5:	2b c1                	sub    ax,cx
    29d7:	72 13                	jb     0x29ec
    29d9:	40                   	inc    ax
    29da:	36 8b 4f 04          	mov    cx,WORD PTR ss:[bx+0x4]
    29de:	0b c9                	or     cx,cx
    29e0:	7d 02                	jge    0x29e4
    29e2:	33 c9                	xor    cx,cx
    29e4:	3b c1                	cmp    ax,cx
    29e6:	76 06                	jbe    0x29ee
    29e8:	8b c1                	mov    ax,cx
    29ea:	eb 02                	jmp    0x29ee
    29ec:	33 c0                	xor    ax,ax
    29ee:	aa                   	stos   BYTE PTR es:[di],al
    29ef:	8b c8                	mov    cx,ax
    29f1:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    29f3:	8e da                	mov    ds,dx
    29f5:	ca 08 00             	retf   0x8
    29f8:	fc                   	cld
    29f9:	8b dc                	mov    bx,sp
    29fb:	8c da                	mov    dx,ds
    29fd:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    2a01:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    2a05:	26 8a 0d             	mov    cl,BYTE PTR es:[di]
    2a08:	32 ed                	xor    ch,ch
    2a0a:	ac                   	lods   al,BYTE PTR ds:[si]
    2a0b:	26 00 05             	add    BYTE PTR es:[di],al
    2a0e:	73 08                	jae    0x2a18
    2a10:	26 c6 05 ff          	mov    BYTE PTR es:[di],0xff
    2a14:	8a c1                	mov    al,cl
    2a16:	f6 d0                	not    al
    2a18:	03 f9                	add    di,cx
    2a1a:	47                   	inc    di
    2a1b:	8a c8                	mov    cl,al
    2a1d:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2a1f:	8e da                	mov    ds,dx
    2a21:	ca 04 00             	retf   0x4
    2a24:	55                   	push   bp
    2a25:	8b ec                	mov    bp,sp
    2a27:	1e                   	push   ds
    2a28:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    2a2b:	fc                   	cld
    2a2c:	ac                   	lods   al,BYTE PTR ds:[si]
    2a2d:	0a c0                	or     al,al
    2a2f:	74 2c                	je     0x2a5d
    2a31:	8a d0                	mov    dl,al
    2a33:	32 f6                	xor    dh,dh
    2a35:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a38:	26 8a 0d             	mov    cl,BYTE PTR es:[di]
    2a3b:	32 ed                	xor    ch,ch
    2a3d:	2b ca                	sub    cx,dx
    2a3f:	72 1c                	jb     0x2a5d
    2a41:	41                   	inc    cx
    2a42:	47                   	inc    di
    2a43:	ac                   	lods   al,BYTE PTR ds:[si]
    2a44:	f2 ae                	repnz scas al,BYTE PTR es:[di]
    2a46:	75 15                	jne    0x2a5d
    2a48:	8b c7                	mov    ax,di
    2a4a:	8b d9                	mov    bx,cx
    2a4c:	8b ca                	mov    cx,dx
    2a4e:	49                   	dec    cx
    2a4f:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
    2a51:	74 0e                	je     0x2a61
    2a53:	8b f8                	mov    di,ax
    2a55:	8b cb                	mov    cx,bx
    2a57:	8b 76 0a             	mov    si,WORD PTR [bp+0xa]
    2a5a:	46                   	inc    si
    2a5b:	eb e6                	jmp    0x2a43
    2a5d:	33 c0                	xor    ax,ax
    2a5f:	eb 04                	jmp    0x2a65
    2a61:	48                   	dec    ax
    2a62:	2b 46 06             	sub    ax,WORD PTR [bp+0x6]
    2a65:	1f                   	pop    ds
    2a66:	5d                   	pop    bp
    2a67:	ca 08 00             	retf   0x8
    2a6a:	fc                   	cld
    2a6b:	8b dc                	mov    bx,sp
    2a6d:	8c da                	mov    dx,ds
    2a6f:	36 c5 77 08          	lds    si,DWORD PTR ss:[bx+0x8]
    2a73:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    2a77:	ac                   	lods   al,BYTE PTR ds:[si]
    2a78:	26 8a 25             	mov    ah,BYTE PTR es:[di]
    2a7b:	47                   	inc    di
    2a7c:	8a c8                	mov    cl,al
    2a7e:	3a cc                	cmp    cl,ah
    2a80:	76 02                	jbe    0x2a84
    2a82:	8a cc                	mov    cl,ah
    2a84:	0a c9                	or     cl,cl
    2a86:	74 06                	je     0x2a8e
    2a88:	32 ed                	xor    ch,ch
    2a8a:	f3 a6                	repz cmps BYTE PTR ds:[si],BYTE PTR es:[di]
    2a8c:	75 02                	jne    0x2a90
    2a8e:	3a c4                	cmp    al,ah
    2a90:	8e da                	mov    ds,dx
    2a92:	ca 08 00             	retf   0x8
    2a95:	fc                   	cld
    2a96:	8b dc                	mov    bx,sp
    2a98:	36 c4 7f 06          	les    di,DWORD PTR ss:[bx+0x6]
    2a9c:	b0 01                	mov    al,0x1
    2a9e:	aa                   	stos   BYTE PTR es:[di],al
    2a9f:	36 8a 47 04          	mov    al,BYTE PTR ss:[bx+0x4]
    2aa3:	aa                   	stos   BYTE PTR es:[di],al
    2aa4:	ca 02 00             	retf   0x2
    2aa7:	fc                   	cld
    2aa8:	8b dc                	mov    bx,sp
    2aaa:	8c da                	mov    dx,ds
    2aac:	36 c4 7f 0a          	les    di,DWORD PTR ss:[bx+0xa]
    2ab0:	36 c5 77 06          	lds    si,DWORD PTR ss:[bx+0x6]
    2ab4:	36 8b 47 04          	mov    ax,WORD PTR ss:[bx+0x4]
    2ab8:	aa                   	stos   BYTE PTR es:[di],al
    2ab9:	8b c8                	mov    cx,ax
    2abb:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    2abd:	8e da                	mov    ds,dx
    2abf:	ca 06 00             	retf   0x6
    2ac2:	55                   	push   bp
    2ac3:	8b ec                	mov    bp,sp
    2ac5:	81 ec 00 02          	sub    sp,0x200
    2ac9:	83 7e 06 01          	cmp    WORD PTR [bp+0x6],0x1
    2acd:	7d 05                	jge    0x2ad4
    2acf:	c7 46 06 01 00       	mov    WORD PTR [bp+0x6],0x1
    2ad4:	8d be 00 ff          	lea    di,[bp-0x100]
    2ad8:	16                   	push   ss
    2ad9:	57                   	push   di
    2ada:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2add:	06                   	push   es
    2ade:	57                   	push   di
    2adf:	b8 01 00             	mov    ax,0x1
    2ae2:	50                   	push   ax
    2ae3:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2ae6:	48                   	dec    ax
    2ae7:	50                   	push   ax
    2ae8:	0e                   	push   cs
    2ae9:	e8 cb fe             	call   0x29b7
    2aec:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2aef:	06                   	push   es
    2af0:	57                   	push   di
    2af1:	0e                   	push   cs
    2af2:	e8 03 ff             	call   0x29f8
    2af5:	8d be 00 fe          	lea    di,[bp-0x200]
    2af9:	16                   	push   ss
    2afa:	57                   	push   di
    2afb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2afe:	06                   	push   es
    2aff:	57                   	push   di
    2b00:	ff 76 06             	push   WORD PTR [bp+0x6]
    2b03:	b8 ff 00             	mov    ax,0xff
    2b06:	50                   	push   ax
    2b07:	0e                   	push   cs
    2b08:	e8 ac fe             	call   0x29b7
    2b0b:	0e                   	push   cs
    2b0c:	e8 e9 fe             	call   0x29f8
    2b0f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b12:	06                   	push   es
    2b13:	57                   	push   di
    2b14:	ff 76 08             	push   WORD PTR [bp+0x8]
    2b17:	0e                   	push   cs
    2b18:	e8 78 fe             	call   0x2993
    2b1b:	8b e5                	mov    sp,bp
    2b1d:	5d                   	pop    bp
    2b1e:	ca 0c 00             	retf   0xc
    2b21:	55                   	push   bp
    2b22:	8b ec                	mov    bp,sp
    2b24:	81 ec 00 02          	sub    sp,0x200
    2b28:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
    2b2c:	7e 5c                	jle    0x2b8a
    2b2e:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    2b32:	7e 56                	jle    0x2b8a
    2b34:	81 7e 08 ff 00       	cmp    WORD PTR [bp+0x8],0xff
    2b39:	7f 4f                	jg     0x2b8a
    2b3b:	81 7e 06 ff 00       	cmp    WORD PTR [bp+0x6],0xff
    2b40:	7e 05                	jle    0x2b47
    2b42:	c7 46 06 ff 00       	mov    WORD PTR [bp+0x6],0xff
    2b47:	8d be 00 ff          	lea    di,[bp-0x100]
    2b4b:	16                   	push   ss
    2b4c:	57                   	push   di
    2b4d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b50:	06                   	push   es
    2b51:	57                   	push   di
    2b52:	b8 01 00             	mov    ax,0x1
    2b55:	50                   	push   ax
    2b56:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    2b59:	48                   	dec    ax
    2b5a:	50                   	push   ax
    2b5b:	0e                   	push   cs
    2b5c:	e8 58 fe             	call   0x29b7
    2b5f:	8d be 00 fe          	lea    di,[bp-0x200]
    2b63:	16                   	push   ss
    2b64:	57                   	push   di
    2b65:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b68:	06                   	push   es
    2b69:	57                   	push   di
    2b6a:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    2b6d:	03 46 06             	add    ax,WORD PTR [bp+0x6]
    2b70:	50                   	push   ax
    2b71:	b8 ff 00             	mov    ax,0xff
    2b74:	50                   	push   ax
    2b75:	0e                   	push   cs
    2b76:	e8 3e fe             	call   0x29b7
    2b79:	0e                   	push   cs
    2b7a:	e8 7b fe             	call   0x29f8
    2b7d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2b80:	06                   	push   es
    2b81:	57                   	push   di
    2b82:	b8 ff 00             	mov    ax,0xff
    2b85:	50                   	push   ax
    2b86:	0e                   	push   cs
    2b87:	e8 09 fe             	call   0x2993
    2b8a:	8b e5                	mov    sp,bp
    2b8c:	5d                   	pop    bp
    2b8d:	ca 08 00             	retf   0x8
    2b90:	81 f7 00 80          	xor    di,0x8000
    2b94:	0a c9                	or     cl,cl
    2b96:	74 7b                	je     0x2c13
    2b98:	0a c0                	or     al,al
    2b9a:	74 78                	je     0x2c14
    2b9c:	3a c1                	cmp    al,cl
    2b9e:	76 05                	jbe    0x2ba5
    2ba0:	91                   	xchg   cx,ax
    2ba1:	87 de                	xchg   si,bx
    2ba3:	87 d7                	xchg   di,dx
    2ba5:	2a c1                	sub    al,cl
    2ba7:	f6 d8                	neg    al
    2ba9:	3c 29                	cmp    al,0x29
    2bab:	73 67                	jae    0x2c14
    2bad:	86 c1                	xchg   cl,al
    2baf:	55                   	push   bp
    2bb0:	50                   	push   ax
    2bb1:	8a e6                	mov    ah,dh
    2bb3:	80 e4 80             	and    ah,0x80
    2bb6:	8b e8                	mov    bp,ax
    2bb8:	33 c7                	xor    ax,di
    2bba:	58                   	pop    ax
    2bbb:	9c                   	pushf
    2bbc:	b0 00                	mov    al,0x0
    2bbe:	80 ce 80             	or     dh,0x80
    2bc1:	81 cf 00 80          	or     di,0x8000
    2bc5:	80 f9 08             	cmp    cl,0x8
    2bc8:	72 11                	jb     0x2bdb
    2bca:	8a c4                	mov    al,ah
    2bcc:	8a e3                	mov    ah,bl
    2bce:	8a df                	mov    bl,bh
    2bd0:	8a fa                	mov    bh,dl
    2bd2:	8a d6                	mov    dl,dh
    2bd4:	32 f6                	xor    dh,dh
    2bd6:	80 e9 08             	sub    cl,0x8
    2bd9:	eb ea                	jmp    0x2bc5
    2bdb:	0a c9                	or     cl,cl
    2bdd:	74 0a                	je     0x2be9
    2bdf:	d1 ea                	shr    dx,1
    2be1:	d1 db                	rcr    bx,1
    2be3:	d1 d8                	rcr    ax,1
    2be5:	fe c9                	dec    cl
    2be7:	75 f6                	jne    0x2bdf
    2be9:	9d                   	popf
    2bea:	78 37                	js     0x2c23
    2bec:	03 c1                	add    ax,cx
    2bee:	13 de                	adc    bx,si
    2bf0:	13 d7                	adc    dx,di
    2bf2:	8b cd                	mov    cx,bp
    2bf4:	5d                   	pop    bp
    2bf5:	73 0a                	jae    0x2c01
    2bf7:	d1 da                	rcr    dx,1
    2bf9:	d1 db                	rcr    bx,1
    2bfb:	d1 d8                	rcr    ax,1
    2bfd:	fe c1                	inc    cl
    2bff:	74 20                	je     0x2c21
    2c01:	05 80 00             	add    ax,0x80
    2c04:	83 d3 00             	adc    bx,0x0
    2c07:	83 d2 00             	adc    dx,0x0
    2c0a:	72 0f                	jb     0x2c1b
    2c0c:	8a c1                	mov    al,cl
    2c0e:	80 e6 7f             	and    dh,0x7f
    2c11:	0a f5                	or     dh,ch
    2c13:	c3                   	ret
    2c14:	8b c1                	mov    ax,cx
    2c16:	8b de                	mov    bx,si
    2c18:	8b d7                	mov    dx,di
    2c1a:	c3                   	ret
    2c1b:	d1 da                	rcr    dx,1
    2c1d:	fe c1                	inc    cl
    2c1f:	75 eb                	jne    0x2c0c
    2c21:	f9                   	stc
    2c22:	c3                   	ret
    2c23:	2b c1                	sub    ax,cx
    2c25:	1b de                	sbb    bx,si
    2c27:	1b d7                	sbb    dx,di
    2c29:	8b cd                	mov    cx,bp
    2c2b:	5d                   	pop    bp
    2c2c:	73 10                	jae    0x2c3e
    2c2e:	f7 d2                	not    dx
    2c30:	f7 d3                	not    bx
    2c32:	f7 d8                	neg    ax
    2c34:	f5                   	cmc
    2c35:	83 d3 00             	adc    bx,0x0
    2c38:	83 d2 00             	adc    dx,0x0
    2c3b:	80 f5 80             	xor    ch,0x80
    2c3e:	8b fa                	mov    di,dx
    2c40:	0b fb                	or     di,bx
    2c42:	0b f8                	or     di,ax
    2c44:	74 cd                	je     0x2c13
    2c46:	0a f6                	or     dh,dh
    2c48:	78 b7                	js     0x2c01
    2c4a:	d1 e0                	shl    ax,1
    2c4c:	d1 d3                	rcl    bx,1
    2c4e:	d1 d2                	rcl    dx,1
    2c50:	fe c9                	dec    cl
    2c52:	75 f2                	jne    0x2c46
    2c54:	e9 fc 00             	jmp    0x2d53
    2c57:	0a c0                	or     al,al
    2c59:	74 f9                	je     0x2c54
    2c5b:	0a c9                	or     cl,cl
    2c5d:	74 f5                	je     0x2c54
    2c5f:	55                   	push   bp
    2c60:	8b ea                	mov    bp,dx
    2c62:	33 d7                	xor    dx,di
    2c64:	81 e2 00 80          	and    dx,0x8000
    2c68:	86 d0                	xchg   al,dl
    2c6a:	02 d1                	add    dl,cl
    2c6c:	12 f0                	adc    dh,al
    2c6e:	8a c8                	mov    cl,al
    2c70:	81 cd 00 80          	or     bp,0x8000
    2c74:	81 cf 00 80          	or     di,0x8000
    2c78:	52                   	push   dx
    2c79:	0a e4                	or     ah,ah
    2c7b:	75 04                	jne    0x2c81
    2c7d:	0b db                	or     bx,bx
    2c7f:	74 0d                	je     0x2c8e
    2c81:	0a ed                	or     ch,ch
    2c83:	75 26                	jne    0x2cab
    2c85:	0b f6                	or     si,si
    2c87:	75 22                	jne    0x2cab
    2c89:	91                   	xchg   cx,ax
    2c8a:	87 de                	xchg   si,bx
    2c8c:	87 ef                	xchg   di,bp
    2c8e:	8b c1                	mov    ax,cx
    2c90:	f7 e5                	mul    bp
    2c92:	8b da                	mov    bx,dx
    2c94:	8b c6                	mov    ax,si
    2c96:	f7 e5                	mul    bp
    2c98:	03 d8                	add    bx,ax
    2c9a:	83 d2 00             	adc    dx,0x0
    2c9d:	8b ca                	mov    cx,dx
    2c9f:	8b c7                	mov    ax,di
    2ca1:	f7 e5                	mul    bp
    2ca3:	03 c1                	add    ax,cx
    2ca5:	83 d2 00             	adc    dx,0x0
    2ca8:	eb 7c                	jmp    0x2d26
    2caa:	90                   	nop
    2cab:	57                   	push   di
    2cac:	56                   	push   si
    2cad:	51                   	push   cx
    2cae:	55                   	push   bp
    2caf:	53                   	push   bx
    2cb0:	50                   	push   ax
    2cb1:	8b ec                	mov    bp,sp
    2cb3:	33 c9                	xor    cx,cx
    2cb5:	8a 46 01             	mov    al,BYTE PTR [bp+0x1]
    2cb8:	f6 66 07             	mul    BYTE PTR [bp+0x7]
    2cbb:	8b f0                	mov    si,ax
    2cbd:	8b f9                	mov    di,cx
    2cbf:	8b d9                	mov    bx,cx
    2cc1:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    2cc4:	f7 66 08             	mul    WORD PTR [bp+0x8]
    2cc7:	03 f0                	add    si,ax
    2cc9:	13 fa                	adc    di,dx
    2ccb:	13 d9                	adc    bx,cx
    2ccd:	8b 46 02             	mov    ax,WORD PTR [bp+0x2]
    2cd0:	f7 66 06             	mul    WORD PTR [bp+0x6]
    2cd3:	03 f0                	add    si,ax
    2cd5:	13 fa                	adc    di,dx
    2cd7:	13 d9                	adc    bx,cx
    2cd9:	8b f1                	mov    si,cx
    2cdb:	8b 46 00             	mov    ax,WORD PTR [bp+0x0]
    2cde:	f7 66 0a             	mul    WORD PTR [bp+0xa]
    2ce1:	03 f8                	add    di,ax
    2ce3:	13 da                	adc    bx,dx
    2ce5:	13 f1                	adc    si,cx
    2ce7:	8b 46 02             	mov    ax,WORD PTR [bp+0x2]
    2cea:	f7 66 08             	mul    WORD PTR [bp+0x8]
    2ced:	03 f8                	add    di,ax
    2cef:	13 da                	adc    bx,dx
    2cf1:	13 f1                	adc    si,cx
    2cf3:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    2cf6:	f7 66 06             	mul    WORD PTR [bp+0x6]
    2cf9:	03 f8                	add    di,ax
    2cfb:	13 da                	adc    bx,dx
    2cfd:	13 f1                	adc    si,cx
    2cff:	8b f9                	mov    di,cx
    2d01:	8b 46 02             	mov    ax,WORD PTR [bp+0x2]
    2d04:	f7 66 0a             	mul    WORD PTR [bp+0xa]
    2d07:	03 d8                	add    bx,ax
    2d09:	13 f2                	adc    si,dx
    2d0b:	13 f9                	adc    di,cx
    2d0d:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    2d10:	f7 66 08             	mul    WORD PTR [bp+0x8]
    2d13:	03 d8                	add    bx,ax
    2d15:	13 f2                	adc    si,dx
    2d17:	13 f9                	adc    di,cx
    2d19:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    2d1c:	f7 66 0a             	mul    WORD PTR [bp+0xa]
    2d1f:	03 c6                	add    ax,si
    2d21:	13 d7                	adc    dx,di
    2d23:	83 c4 0c             	add    sp,0xc
    2d26:	93                   	xchg   bx,ax
    2d27:	59                   	pop    cx
    2d28:	5d                   	pop    bp
    2d29:	0a f6                	or     dh,dh
    2d2b:	78 07                	js     0x2d34
    2d2d:	d1 e0                	shl    ax,1
    2d2f:	d1 d3                	rcl    bx,1
    2d31:	d1 d2                	rcl    dx,1
    2d33:	49                   	dec    cx
    2d34:	81 e9 81 80          	sub    cx,0x8081
    2d38:	05 80 00             	add    ax,0x80
    2d3b:	83 d3 00             	adc    bx,0x0
    2d3e:	83 d2 00             	adc    dx,0x0
    2d41:	73 03                	jae    0x2d46
    2d43:	d1 da                	rcr    dx,1
    2d45:	41                   	inc    cx
    2d46:	f6 c5 40             	test   ch,0x40
    2d49:	75 08                	jne    0x2d53
    2d4b:	41                   	inc    cx
    2d4c:	8a c1                	mov    al,cl
    2d4e:	32 f5                	xor    dh,ch
    2d50:	d0 ed                	shr    ch,1
    2d52:	c3                   	ret
    2d53:	33 c0                	xor    ax,ax
    2d55:	8b d8                	mov    bx,ax
    2d57:	8b d0                	mov    dx,ax
    2d59:	c3                   	ret
    2d5a:	0a c0                	or     al,al
    2d5c:	74 f5                	je     0x2d53
    2d5e:	55                   	push   bp
    2d5f:	8b ea                	mov    bp,dx
    2d61:	33 d7                	xor    dx,di
    2d63:	81 cf 00 80          	or     di,0x8000
    2d67:	81 cd 00 80          	or     bp,0x8000
    2d6b:	81 e2 00 80          	and    dx,0x8000
    2d6f:	86 c2                	xchg   dl,al
    2d71:	2a d1                	sub    dl,cl
    2d73:	1a f0                	sbb    dh,al
    2d75:	52                   	push   dx
    2d76:	b0 02                	mov    al,0x2
    2d78:	ba 01 00             	mov    dx,0x1
    2d7b:	3b ef                	cmp    bp,di
    2d7d:	75 06                	jne    0x2d85
    2d7f:	3b de                	cmp    bx,si
    2d81:	75 02                	jne    0x2d85
    2d83:	3a e5                	cmp    ah,ch
    2d85:	72 06                	jb     0x2d8d
    2d87:	2a e5                	sub    ah,ch
    2d89:	1b de                	sbb    bx,si
    2d8b:	1b ef                	sbb    bp,di
    2d8d:	d1 d2                	rcl    dx,1
    2d8f:	72 11                	jb     0x2da2
    2d91:	d0 e4                	shl    ah,1
    2d93:	d1 d3                	rcl    bx,1
    2d95:	d1 d5                	rcl    bp,1
    2d97:	73 e2                	jae    0x2d7b
    2d99:	2a e5                	sub    ah,ch
    2d9b:	1b de                	sbb    bx,si
    2d9d:	1b ef                	sbb    bp,di
    2d9f:	f8                   	clc
    2da0:	eb eb                	jmp    0x2d8d
    2da2:	fe c8                	dec    al
    2da4:	78 0a                	js     0x2db0
    2da6:	52                   	push   dx
    2da7:	ba 01 00             	mov    dx,0x1
    2daa:	75 e5                	jne    0x2d91
    2dac:	b2 40                	mov    dl,0x40
    2dae:	eb e1                	jmp    0x2d91
    2db0:	8b c2                	mov    ax,dx
    2db2:	b1 06                	mov    cl,0x6
    2db4:	d3 e0                	shl    ax,cl
    2db6:	5b                   	pop    bx
    2db7:	5a                   	pop    dx
    2db8:	59                   	pop    cx
    2db9:	5d                   	pop    bp
    2dba:	f7 d0                	not    ax
    2dbc:	f7 d3                	not    bx
    2dbe:	83 f2 ff             	xor    dx,0xffff
    2dc1:	78 07                	js     0x2dca
    2dc3:	d1 d0                	rcl    ax,1
    2dc5:	d1 d3                	rcl    bx,1
    2dc7:	d1 d2                	rcl    dx,1
    2dc9:	49                   	dec    cx
    2dca:	81 c1 80 80          	add    cx,0x8080
    2dce:	e9 67 ff             	jmp    0x2d38
    2dd1:	52                   	push   dx
    2dd2:	33 d7                	xor    dx,di
    2dd4:	5a                   	pop    dx
    2dd5:	79 05                	jns    0x2ddc
    2dd7:	52                   	push   dx
    2dd8:	d1 d2                	rcl    dx,1
    2dda:	5a                   	pop    dx
    2ddb:	c3                   	ret
    2ddc:	f6 c6 80             	test   dh,0x80
    2ddf:	74 07                	je     0x2de8
    2de1:	e8 04 00             	call   0x2de8
    2de4:	74 14                	je     0x2dfa
    2de6:	f5                   	cmc
    2de7:	c3                   	ret
    2de8:	3a c1                	cmp    al,cl
    2dea:	75 0e                	jne    0x2dfa
    2dec:	0a c0                	or     al,al
    2dee:	74 0a                	je     0x2dfa
    2df0:	3b d7                	cmp    dx,di
    2df2:	75 06                	jne    0x2dfa
    2df4:	3b de                	cmp    bx,si
    2df6:	75 02                	jne    0x2dfa
    2df8:	3a e5                	cmp    ah,ch
    2dfa:	c3                   	ret
    2dfb:	8b d8                	mov    bx,ax
    2dfd:	0b da                	or     bx,dx
    2dff:	74 35                	je     0x2e36
    2e01:	8a ee                	mov    ch,dh
    2e03:	0b d2                	or     dx,dx
    2e05:	79 07                	jns    0x2e0e
    2e07:	f7 da                	neg    dx
    2e09:	f7 d8                	neg    ax
    2e0b:	83 da 00             	sbb    dx,0x0
    2e0e:	8b d8                	mov    bx,ax
    2e10:	b8 a0 00             	mov    ax,0xa0
    2e13:	0b d2                	or     dx,dx
    2e15:	75 0c                	jne    0x2e23
    2e17:	87 d3                	xchg   bx,dx
    2e19:	b0 90                	mov    al,0x90
    2e1b:	0a f6                	or     dh,dh
    2e1d:	75 04                	jne    0x2e23
    2e1f:	86 f2                	xchg   dl,dh
    2e21:	b0 88                	mov    al,0x88
    2e23:	0b d2                	or     dx,dx
    2e25:	78 08                	js     0x2e2f
    2e27:	fe c8                	dec    al
    2e29:	03 db                	add    bx,bx
    2e2b:	13 d2                	adc    dx,dx
    2e2d:	79 f8                	jns    0x2e27
    2e2f:	0a ed                	or     ch,ch
    2e31:	78 03                	js     0x2e36
    2e33:	80 e6 7f             	and    dh,0x7f
    2e36:	c3                   	ret
    2e37:	93                   	xchg   bx,ax
    2e38:	b1 a0                	mov    cl,0xa0
    2e3a:	2a cb                	sub    cl,bl
    2e3c:	72 5b                	jb     0x2e99
    2e3e:	8a de                	mov    bl,dh
    2e40:	80 ce 80             	or     dh,0x80
    2e43:	80 f9 20             	cmp    cl,0x20
    2e46:	73 52                	jae    0x2e9a
    2e48:	80 f9 10             	cmp    cl,0x10
    2e4b:	72 09                	jb     0x2e56
    2e4d:	8a fc                	mov    bh,ah
    2e4f:	8b c2                	mov    ax,dx
    2e51:	33 d2                	xor    dx,dx
    2e53:	80 e9 10             	sub    cl,0x10
    2e56:	80 f9 08             	cmp    cl,0x8
    2e59:	72 0d                	jb     0x2e68
    2e5b:	8a f8                	mov    bh,al
    2e5d:	8a c4                	mov    al,ah
    2e5f:	8a e2                	mov    ah,dl
    2e61:	8a d6                	mov    dl,dh
    2e63:	32 f6                	xor    dh,dh
    2e65:	80 e9 08             	sub    cl,0x8
    2e68:	0a c9                	or     cl,cl
    2e6a:	74 0a                	je     0x2e76
    2e6c:	d1 ea                	shr    dx,1
    2e6e:	d1 d8                	rcr    ax,1
    2e70:	d0 df                	rcr    bh,1
    2e72:	fe c9                	dec    cl
    2e74:	75 f6                	jne    0x2e6c
    2e76:	0a ed                	or     ch,ch
    2e78:	74 0a                	je     0x2e84
    2e7a:	02 ff                	add    bh,bh
    2e7c:	15 00 00             	adc    ax,0x0
    2e7f:	83 d2 00             	adc    dx,0x0
    2e82:	72 15                	jb     0x2e99
    2e84:	8b c8                	mov    cx,ax
    2e86:	0b ca                	or     cx,dx
    2e88:	74 0f                	je     0x2e99
    2e8a:	0a db                	or     bl,bl
    2e8c:	79 07                	jns    0x2e95
    2e8e:	f7 da                	neg    dx
    2e90:	f7 d8                	neg    ax
    2e92:	83 da 00             	sbb    dx,0x0
    2e95:	32 de                	xor    bl,dh
    2e97:	02 db                	add    bl,bl
    2e99:	c3                   	ret
    2e9a:	8a fe                	mov    bh,dh
    2e9c:	b8 00 00             	mov    ax,0x0
    2e9f:	ba 00 00             	mov    dx,0x0
    2ea2:	74 d2                	je     0x2e76
    2ea4:	c3                   	ret
    2ea5:	e8 ec fc             	call   0x2b94
    2ea8:	72 3b                	jb     0x2ee5
    2eaa:	cb                   	retf
    2eab:	e8 e2 fc             	call   0x2b90
    2eae:	72 35                	jb     0x2ee5
    2eb0:	cb                   	retf
    2eb1:	8b c8                	mov    cx,ax
    2eb3:	8b f3                	mov    si,bx
    2eb5:	8b fa                	mov    di,dx
    2eb7:	e8 9d fd             	call   0x2c57
    2eba:	72 29                	jb     0x2ee5
    2ebc:	cb                   	retf
    2ebd:	0a c9                	or     cl,cl
    2ebf:	74 2a                	je     0x2eeb
    2ec1:	e8 96 fe             	call   0x2d5a
    2ec4:	72 1f                	jb     0x2ee5
    2ec6:	cb                   	retf
    2ec7:	e8 07 ff             	call   0x2dd1
    2eca:	cb                   	retf
    2ecb:	e8 2d ff             	call   0x2dfb
    2ece:	cb                   	retf
    2ecf:	b5 00                	mov    ch,0x0
    2ed1:	e8 63 ff             	call   0x2e37
    2ed4:	72 09                	jb     0x2edf
    2ed6:	cb                   	retf
    2ed7:	b5 01                	mov    ch,0x1
    2ed9:	e8 5b ff             	call   0x2e37
    2edc:	72 01                	jb     0x2edf
    2ede:	cb                   	retf
    2edf:	b8 06 00             	mov    ax,0x6
    2ee2:	e9 e8 ee             	jmp    0x1dcd
    2ee5:	b8 08 00             	mov    ax,0x8
    2ee8:	e9 e2 ee             	jmp    0x1dcd
    2eeb:	b8 07 00             	mov    ax,0x7
    2eee:	e9 dc ee             	jmp    0x1dcd
    2ef1:	e8 5a 00             	call   0x2f4e
    2ef4:	8b dc                	mov    bx,sp
    2ef6:	8b ca                	mov    cx,dx
    2ef8:	36 f7 67 04          	mul    WORD PTR ss:[bx+0x4]
    2efc:	8b c1                	mov    ax,cx
    2efe:	8b ca                	mov    cx,dx
    2f00:	36 f7 67 04          	mul    WORD PTR ss:[bx+0x4]
    2f04:	03 c1                	add    ax,cx
    2f06:	83 d2 00             	adc    dx,0x0
    2f09:	8b c2                	mov    ax,dx
    2f0b:	ca 02 00             	retf   0x2
    2f0e:	e8 3d 00             	call   0x2f4e
    2f11:	93                   	xchg   bx,ax
    2f12:	b8 80 00             	mov    ax,0x80
    2f15:	b9 20 00             	mov    cx,0x20
    2f18:	f6 c6 80             	test   dh,0x80
    2f1b:	75 0a                	jne    0x2f27
    2f1d:	d1 e3                	shl    bx,1
    2f1f:	d1 d2                	rcl    dx,1
    2f21:	fe c8                	dec    al
    2f23:	e2 f3                	loop   0x2f18
    2f25:	32 c0                	xor    al,al
    2f27:	80 e6 7f             	and    dh,0x7f
    2f2a:	cb                   	retf
    2f2b:	e8 20 00             	call   0x2f4e
    2f2e:	9b 2e df 06 4c 2f    	fild   WORD PTR cs:0x2f4c
    2f34:	9b db 06 04 0b       	fild   DWORD PTR ds:0xb04
    2f39:	9b 2e d8 06 48 2f    	fadd   DWORD PTR cs:0x2f48
    2f3f:	9b d9 fd             	fscale
    2f42:	9b dd d9             	fstp   st(1)
    2f45:	90                   	nop
    2f46:	9b                   	fwait
    2f47:	cb                   	retf
    2f48:	00 00                	add    BYTE PTR [bx+si],al
    2f4a:	00 4f e0             	add    BYTE PTR [bx-0x20],cl
    2f4d:	ff a1 04 0b          	jmp    WORD PTR [bx+di+0xb04]
    2f51:	8b 1e 06 0b          	mov    bx,WORD PTR ds:0xb06
    2f55:	8b c8                	mov    cx,ax
    2f57:	2e f7 26 84 2f       	mul    WORD PTR cs:0x2f84
    2f5c:	d1 e1                	shl    cx,1
    2f5e:	d1 e1                	shl    cx,1
    2f60:	d1 e1                	shl    cx,1
    2f62:	02 e9                	add    ch,cl
    2f64:	03 d1                	add    dx,cx
    2f66:	03 d3                	add    dx,bx
    2f68:	d1 e3                	shl    bx,1
    2f6a:	d1 e3                	shl    bx,1
    2f6c:	03 d3                	add    dx,bx
    2f6e:	02 f3                	add    dh,bl
    2f70:	b1 05                	mov    cl,0x5
    2f72:	d3 e3                	shl    bx,cl
    2f74:	02 f3                	add    dh,bl
    2f76:	05 01 00             	add    ax,0x1
    2f79:	83 d2 00             	adc    dx,0x0
    2f7c:	a3 04 0b             	mov    ds:0xb04,ax
    2f7f:	89 16 06 0b          	mov    WORD PTR ds:0xb06,dx
    2f83:	c3                   	ret
    2f84:	05 84 b4             	add    ax,0xb484
    2f87:	2c cd                	sub    al,0xcd
    2f89:	21 89 0e 04          	and    WORD PTR [bx+di+0x40e],cx
    2f8d:	0b 89 16 06          	or     cx,WORD PTR [bx+di+0x616]
    2f91:	0b cb                	or     cx,bx
    2f93:	bb 2f 00             	mov    bx,0x2f
    2f96:	00 00                	add    BYTE PTR [bx+si],al
    2f98:	00 00                	add    BYTE PTR [bx+si],al
    2f9a:	00 b3 2f 04          	add    BYTE PTR [bp+di+0x42f],dh
    2f9e:	00 00                	add    BYTE PTR [bx+si],al
    2fa0:	00 00                	add    BYTE PTR [bx+si],al
    2fa2:	00 ff                	add    bh,bh
    2fa4:	ff 00                	inc    WORD PTR [bx+si]
    2fa6:	00 ff                	add    bh,bh
    2fa8:	ff 00                	inc    WORD PTR [bx+si]
    2faa:	00 ff                	add    bh,bh
    2fac:	ff 00                	inc    WORD PTR [bx+si]
    2fae:	00 ff                	add    bh,bh
    2fb0:	ff 00                	inc    WORD PTR [bx+si]
    2fb2:	00 07                	add    BYTE PTR [bx],al
    2fb4:	54                   	push   sp
    2fb5:	4f                   	dec    di
    2fb6:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
    2fb9:	63 74 07             	arpl   WORD PTR [si+0x7],si
    2fbc:	07                   	pop    es
    2fbd:	54                   	push   sp
    2fbe:	4f                   	dec    di
    2fbf:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
    2fc2:	63 74 ff             	arpl   WORD PTR [si-0x1],si
    2fc5:	ff 00                	inc    WORD PTR [bx+si]
    2fc7:	00 00                	add    BYTE PTR [bx+si],al
    2fc9:	00 00                	add    BYTE PTR [bx+si],al
    2fcb:	00 00                	add    BYTE PTR [bx+si],al
    2fcd:	00 06 53 79          	add    BYTE PTR ds:0x7953,al
    2fd1:	73 74                	jae    0x3047
    2fd3:	65 6d                	gs ins WORD PTR es:[di],dx
    2fd5:	00 00                	add    BYTE PTR [bx+si],al
    2fd7:	8b dc                	mov    bx,sp
    2fd9:	36 80 7f 08 00       	cmp    BYTE PTR ss:[bx+0x8],0x0
    2fde:	74 0a                	je     0x2fea
    2fe0:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    2fe4:	06                   	push   es
    2fe5:	57                   	push   di
    2fe6:	26 ff 5d f4          	call   DWORD PTR es:[di-0xc]
    2fea:	ca 06 00             	retf   0x6
    2fed:	8b dc                	mov    bx,sp
    2fef:	36 80 7f 08 00       	cmp    BYTE PTR ss:[bx+0x8],0x0
    2ff4:	74 0d                	je     0x3003
    2ff6:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    2ffa:	06                   	push   es
    2ffb:	57                   	push   di
    2ffc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2fff:	26 ff 5d f8          	call   DWORD PTR es:[di-0x8]
    3003:	ca 06 00             	retf   0x6
    3006:	8b dc                	mov    bx,sp
    3008:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    300c:	8c c0                	mov    ax,es
    300e:	0b c7                	or     ax,di
    3010:	74 0c                	je     0x301e
    3012:	b0 01                	mov    al,0x1
    3014:	50                   	push   ax
    3015:	06                   	push   es
    3016:	57                   	push   di
    3017:	26 c4 3d             	les    di,DWORD PTR es:[di]
    301a:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    301e:	ca 04 00             	retf   0x4
    3021:	55                   	push   bp
    3022:	8b ec                	mov    bp,sp
    3024:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3027:	26 8b 45 ea          	mov    ax,WORD PTR es:[di-0x16]
    302b:	50                   	push   ax
    302c:	e8 5d ef             	call   0x1f8c
    302f:	59                   	pop    cx
    3030:	8b d8                	mov    bx,ax
    3032:	8b f8                	mov    di,ax
    3034:	8e c2                	mov    es,dx
    3036:	fc                   	cld
    3037:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    303a:	ab                   	stos   WORD PTR es:[di],ax
    303b:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    303e:	ab                   	stos   WORD PTR es:[di],ax
    303f:	33 c0                	xor    ax,ax
    3041:	83 e9 04             	sub    cx,0x4
    3044:	d1 e9                	shr    cx,1
    3046:	f3 ab                	rep stos WORD PTR es:[di],ax
    3048:	13 c8                	adc    cx,ax
    304a:	f3 aa                	rep stos BYTE PTR es:[di],al
    304c:	8b c3                	mov    ax,bx
    304e:	5d                   	pop    bp
    304f:	ca 04 00             	retf   0x4
    3052:	8b dc                	mov    bx,sp
    3054:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    3058:	8b cf                	mov    cx,di
    305a:	8c c3                	mov    bx,es
    305c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    305f:	26 8b 45 ea          	mov    ax,WORD PTR es:[di-0x16]
    3063:	e8 43 f0             	call   0x20a9
    3066:	ca 04 00             	retf   0x4
    3069:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    306c:	06                   	push   es
    306d:	57                   	push   di
    306e:	26 ff 5d f4          	call   DWORD PTR es:[di-0xc]
    3072:	89 46 06             	mov    WORD PTR [bp+0x6],ax
    3075:	89 56 08             	mov    WORD PTR [bp+0x8],dx
    3078:	8b dc                	mov    bx,sp
    307a:	83 c3 04             	add    bx,0x4
    307d:	36 c7 47 04 a3 30    	mov    WORD PTR ss:[bx+0x4],0x30a3
    3083:	36 8c 4f 06          	mov    WORD PTR ss:[bx+0x6],cs
    3087:	36 89 6f 02          	mov    WORD PTR ss:[bx+0x2],bp
    308b:	a1 e2 0a             	mov    ax,ds:0xae2
    308e:	36 89 07             	mov    WORD PTR ss:[bx],ax
    3091:	89 1e e2 0a          	mov    WORD PTR ds:0xae2,bx
    3095:	cb                   	retf
    3096:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3099:	06                   	push   es
    309a:	57                   	push   di
    309b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    309e:	26 ff 5d f8          	call   DWORD PTR es:[di-0x8]
    30a2:	cb                   	retf
    30a3:	01 00                	add    WORD PTR [bx+si],ax
    30a5:	00 00                	add    BYTE PTR [bx+si],al
    30a7:	00 00                	add    BYTE PTR [bx+si],al
    30a9:	ff                   	(bad)
    30aa:	ff 00                	inc    WORD PTR [bx+si]
    30ac:	00 b0 01 50          	add    BYTE PTR [bx+si+0x5001],dh
    30b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30b3:	06                   	push   es
    30b4:	57                   	push   di
    30b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30b8:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    30bc:	e9 0c f6             	jmp    0x26cb
    30bf:	8b dc                	mov    bx,sp
    30c1:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    30c5:	26 8b 05             	mov    ax,WORD PTR es:[di]
    30c8:	0b c0                	or     ax,ax
    30ca:	7e 11                	jle    0x30dd
    30cc:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    30d0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30d3:	e8 36 00             	call   0x310c
    30d6:	74 03                	je     0x30db
    30d8:	26 ff 2d             	jmp    DWORD PTR es:[di]
    30db:	8b dc                	mov    bx,sp
    30dd:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    30e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30e4:	26 ff 6d f0          	jmp    DWORD PTR es:[di-0x10]
    30e8:	ca 08 00             	retf   0x8
    30eb:	b8 d2 00             	mov    ax,0xd2
    30ee:	e9 0b ed             	jmp    0x1dfc
    30f1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30f4:	e8 15 00             	call   0x310c
    30f7:	74 f2                	je     0x30eb
    30f9:	26 ff 2d             	jmp    DWORD PTR es:[di]
    30fc:	26 c4 3d             	les    di,DWORD PTR es:[di]
    30ff:	e8 0a 00             	call   0x310c
    3102:	74 e7                	je     0x30eb
    3104:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3107:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    310b:	cb                   	retf
    310c:	8b df                	mov    bx,di
    310e:	fc                   	cld
    310f:	26 8b 7f e6          	mov    di,WORD PTR es:[bx-0x1a]
    3113:	0b ff                	or     di,di
    3115:	74 0b                	je     0x3122
    3117:	26 8b 0d             	mov    cx,WORD PTR es:[di]
    311a:	8b d1                	mov    dx,cx
    311c:	47                   	inc    di
    311d:	47                   	inc    di
    311e:	f2 af                	repnz scas ax,WORD PTR es:[di]
    3120:	74 0b                	je     0x312d
    3122:	26 c4 5f ec          	les    bx,DWORD PTR es:[bx-0x14]
    3126:	8c c1                	mov    cx,es
    3128:	0b cb                	or     cx,bx
    312a:	75 e3                	jne    0x310f
    312c:	c3                   	ret
    312d:	4a                   	dec    dx
    312e:	d1 e2                	shl    dx,1
    3130:	2b d1                	sub    dx,cx
    3132:	d1 e2                	shl    dx,1
    3134:	03 fa                	add    di,dx
    3136:	c3                   	ret
    3137:	8b dc                	mov    bx,sp
    3139:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    313d:	26 8b 4d ea          	mov    cx,WORD PTR es:[di-0x16]
    3141:	8b c7                	mov    ax,di
    3143:	8c c2                	mov    dx,es
    3145:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    3149:	8b df                	mov    bx,di
    314b:	fc                   	cld
    314c:	ab                   	stos   WORD PTR es:[di],ax
    314d:	8b c2                	mov    ax,dx
    314f:	ab                   	stos   WORD PTR es:[di],ax
    3150:	33 c0                	xor    ax,ax
    3152:	83 e9 04             	sub    cx,0x4
    3155:	d1 e9                	shr    cx,1
    3157:	f3 ab                	rep stos WORD PTR es:[di],ax
    3159:	13 c8                	adc    cx,ax
    315b:	f3 aa                	rep stos BYTE PTR es:[di],al
    315d:	8b c3                	mov    ax,bx
    315f:	8c c2                	mov    dx,es
    3161:	ca 08 00             	retf   0x8
    3164:	8b dc                	mov    bx,sp
    3166:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    316a:	26 8b 05             	mov    ax,WORD PTR es:[di]
    316d:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    3171:	ca 04 00             	retf   0x4
    3174:	8b dc                	mov    bx,sp
    3176:	1e                   	push   ds
    3177:	fc                   	cld
    3178:	36 c5 77 04          	lds    si,DWORD PTR ss:[bx+0x4]
    317c:	8b 74 e8             	mov    si,WORD PTR [si-0x18]
    317f:	36 c4 7f 08          	les    di,DWORD PTR ss:[bx+0x8]
    3183:	ac                   	lods   al,BYTE PTR ds:[si]
    3184:	aa                   	stos   BYTE PTR es:[di],al
    3185:	8a c8                	mov    cl,al
    3187:	32 ed                	xor    ch,ch
    3189:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    318b:	1f                   	pop    ds
    318c:	ca 04 00             	retf   0x4
    318f:	8b dc                	mov    bx,sp
    3191:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    3195:	26 8b 45 ec          	mov    ax,WORD PTR es:[di-0x14]
    3199:	26 8b 55 ee          	mov    dx,WORD PTR es:[di-0x12]
    319d:	ca 04 00             	retf   0x4
    31a0:	8b dc                	mov    bx,sp
    31a2:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    31a6:	26 8b 45 ea          	mov    ax,WORD PTR es:[di-0x16]
    31aa:	ca 04 00             	retf   0x4
    31ad:	8b dc                	mov    bx,sp
    31af:	36 c4 7f 04          	les    di,DWORD PTR ss:[bx+0x4]
    31b3:	26 8b 45 e0          	mov    ax,WORD PTR es:[di-0x20]
    31b7:	8b d0                	mov    dx,ax
    31b9:	0b c0                	or     ax,ax
    31bb:	74 02                	je     0x31bf
    31bd:	8c c2                	mov    dx,es
    31bf:	ca 04 00             	retf   0x4
    31c2:	55                   	push   bp
    31c3:	8b ec                	mov    bp,sp
    31c5:	1e                   	push   ds
    31c6:	fc                   	cld
    31c7:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    31ca:	8a 24                	mov    ah,BYTE PTR [si]
    31cc:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    31cf:	33 db                	xor    bx,bx
    31d1:	8b 7c e4             	mov    di,WORD PTR [si-0x1c]
    31d4:	0b ff                	or     di,di
    31d6:	74 11                	je     0x31e9
    31d8:	8b 15                	mov    dx,WORD PTR [di]
    31da:	47                   	inc    di
    31db:	47                   	inc    di
    31dc:	8a 5d 04             	mov    bl,BYTE PTR [di+0x4]
    31df:	3a dc                	cmp    bl,ah
    31e1:	74 14                	je     0x31f7
    31e3:	8d 79 05             	lea    di,[bx+di+0x5]
    31e6:	4a                   	dec    dx
    31e7:	75 f3                	jne    0x31dc
    31e9:	c5 74 ec             	lds    si,DWORD PTR [si-0x14]
    31ec:	8c d9                	mov    cx,ds
    31ee:	0b ce                	or     cx,si
    31f0:	75 df                	jne    0x31d1
    31f2:	33 c0                	xor    ax,ax
    31f4:	99                   	cwd
    31f5:	eb 15                	jmp    0x320c
    31f7:	57                   	push   di
    31f8:	56                   	push   si
    31f9:	8d 75 05             	lea    si,[di+0x5]
    31fc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    31ff:	47                   	inc    di
    3200:	e8 b3 00             	call   0x32b6
    3203:	5e                   	pop    si
    3204:	5f                   	pop    di
    3205:	75 dc                	jne    0x31e3
    3207:	8b 05                	mov    ax,WORD PTR [di]
    3209:	8b 55 02             	mov    dx,WORD PTR [di+0x2]
    320c:	1f                   	pop    ds
    320d:	5d                   	pop    bp
    320e:	ca 08 00             	retf   0x8
    3211:	55                   	push   bp
    3212:	8b ec                	mov    bp,sp
    3214:	1e                   	push   ds
    3215:	fc                   	cld
    3216:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    3219:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    321c:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    321f:	33 db                	xor    bx,bx
    3221:	8b 7c e4             	mov    di,WORD PTR [si-0x1c]
    3224:	0b ff                	or     di,di
    3226:	74 10                	je     0x3238
    3228:	8b 0d                	mov    cx,WORD PTR [di]
    322a:	47                   	inc    di
    322b:	47                   	inc    di
    322c:	3b 05                	cmp    ax,WORD PTR [di]
    322e:	74 19                	je     0x3249
    3230:	8a 5d 04             	mov    bl,BYTE PTR [di+0x4]
    3233:	8d 79 05             	lea    di,[bx+di+0x5]
    3236:	e2 f4                	loop   0x322c
    3238:	c5 74 ec             	lds    si,DWORD PTR [si-0x14]
    323b:	8c d9                	mov    cx,ds
    323d:	0b ce                	or     cx,si
    323f:	75 e0                	jne    0x3221
    3241:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3244:	32 c0                	xor    al,al
    3246:	aa                   	stos   BYTE PTR es:[di],al
    3247:	eb 13                	jmp    0x325c
    3249:	3b 55 02             	cmp    dx,WORD PTR [di+0x2]
    324c:	75 e2                	jne    0x3230
    324e:	8d 75 04             	lea    si,[di+0x4]
    3251:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3254:	ac                   	lods   al,BYTE PTR ds:[si]
    3255:	aa                   	stos   BYTE PTR es:[di],al
    3256:	8a c8                	mov    cl,al
    3258:	32 ed                	xor    ch,ch
    325a:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    325c:	1f                   	pop    ds
    325d:	5d                   	pop    bp
    325e:	ca 08 00             	retf   0x8
    3261:	55                   	push   bp
    3262:	8b ec                	mov    bp,sp
    3264:	1e                   	push   ds
    3265:	fc                   	cld
    3266:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    3269:	8a 24                	mov    ah,BYTE PTR [si]
    326b:	c5 76 06             	lds    si,DWORD PTR [bp+0x6]
    326e:	c5 34                	lds    si,DWORD PTR [si]
    3270:	33 db                	xor    bx,bx
    3272:	8b 7c e2             	mov    di,WORD PTR [si-0x1e]
    3275:	0b ff                	or     di,di
    3277:	74 12                	je     0x328b
    3279:	8b 15                	mov    dx,WORD PTR [di]
    327b:	83 c7 04             	add    di,0x4
    327e:	8a 5d 04             	mov    bl,BYTE PTR [di+0x4]
    3281:	3a dc                	cmp    bl,ah
    3283:	74 14                	je     0x3299
    3285:	8d 79 05             	lea    di,[bx+di+0x5]
    3288:	4a                   	dec    dx
    3289:	75 f3                	jne    0x327e
    328b:	c5 74 ec             	lds    si,DWORD PTR [si-0x14]
    328e:	8c d9                	mov    cx,ds
    3290:	0b ce                	or     cx,si
    3292:	75 de                	jne    0x3272
    3294:	33 c0                	xor    ax,ax
    3296:	99                   	cwd
    3297:	eb 18                	jmp    0x32b1
    3299:	57                   	push   di
    329a:	56                   	push   si
    329b:	8d 75 05             	lea    si,[di+0x5]
    329e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    32a1:	47                   	inc    di
    32a2:	e8 11 00             	call   0x32b6
    32a5:	5e                   	pop    si
    32a6:	5f                   	pop    di
    32a7:	75 dc                	jne    0x3285
    32a9:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    32ac:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    32af:	03 05                	add    ax,WORD PTR [di]
    32b1:	1f                   	pop    ds
    32b2:	5d                   	pop    bp
    32b3:	ca 08 00             	retf   0x8
    32b6:	8a cc                	mov    cl,ah
    32b8:	32 ed                	xor    ch,ch
    32ba:	ac                   	lods   al,BYTE PTR ds:[si]
    32bb:	26 32 05             	xor    al,BYTE PTR es:[di]
    32be:	47                   	inc    di
    32bf:	24 df                	and    al,0xdf
    32c1:	e1 f7                	loope  0x32ba
    32c3:	c3                   	ret
    32c4:	55                   	push   bp
    32c5:	8b ec                	mov    bp,sp
    32c7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    32ca:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
    32cd:	8b 5e 0c             	mov    bx,WORD PTR [bp+0xc]
    32d0:	33 c0                	xor    ax,ax
    32d2:	e8 4e 00             	call   0x3323
    32d5:	75 01                	jne    0x32d8
    32d7:	40                   	inc    ax
    32d8:	5d                   	pop    bp
    32d9:	ca 08 00             	retf   0x8
    32dc:	55                   	push   bp
    32dd:	8b ec                	mov    bp,sp
    32df:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    32e2:	8c c0                	mov    ax,es
    32e4:	0b c7                	or     ax,di
    32e6:	74 0e                	je     0x32f6
    32e8:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
    32eb:	8b 5e 08             	mov    bx,WORD PTR [bp+0x8]
    32ee:	33 c0                	xor    ax,ax
    32f0:	e8 2d 00             	call   0x3320
    32f3:	75 01                	jne    0x32f6
    32f5:	40                   	inc    ax
    32f6:	5d                   	pop    bp
    32f7:	ca 08 00             	retf   0x8
    32fa:	55                   	push   bp
    32fb:	8b ec                	mov    bp,sp
    32fd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3300:	8b c7                	mov    ax,di
    3302:	8c c2                	mov    dx,es
    3304:	8b f0                	mov    si,ax
    3306:	0b f2                	or     si,dx
    3308:	74 0b                	je     0x3315
    330a:	8b 4e 06             	mov    cx,WORD PTR [bp+0x6]
    330d:	8b 5e 08             	mov    bx,WORD PTR [bp+0x8]
    3310:	e8 0d 00             	call   0x3320
    3313:	75 04                	jne    0x3319
    3315:	5d                   	pop    bp
    3316:	ca 08 00             	retf   0x8
    3319:	5d                   	pop    bp
    331a:	b8 0a 00             	mov    ax,0xa
    331d:	e9 ad ea             	jmp    0x1dcd
    3320:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3323:	3b f9                	cmp    di,cx
    3325:	75 06                	jne    0x332d
    3327:	8c c6                	mov    si,es
    3329:	3b f3                	cmp    si,bx
    332b:	74 0b                	je     0x3338
    332d:	26 c4 7d ec          	les    di,DWORD PTR es:[di-0x14]
    3331:	8c c6                	mov    si,es
    3333:	0b f7                	or     si,di
    3335:	75 ec                	jne    0x3323
    3337:	4e                   	dec    si
    3338:	c3                   	ret
