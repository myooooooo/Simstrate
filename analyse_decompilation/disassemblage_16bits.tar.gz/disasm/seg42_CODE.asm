; ================================================================
; seg42_CODE  (21421 octets) - Simstrat (FR).EXE
; desassemblage x86 16 bits (i8086), syntaxe Intel
; ================================================================

Disassembly of section .data:

00000000 <.data>:
       0:	2a 00                	sub    al,BYTE PTR [bx+si]
       2:	03 0a                	add    cx,WORD PTR [bp+si]
       4:	54                   	push   sp
       5:	41                   	inc    cx
       6:	6c                   	ins    BYTE PTR es:[di],dx
       7:	69 67 6e 6d 65       	imul   sp,WORD PTR [bx+0x6e],0x656d
       c:	6e                   	outs   dx,BYTE PTR ds:[si]
       d:	74 00                	je     0xf
       f:	00 00                	add    BYTE PTR [bx+si],al
      11:	00 00                	add    BYTE PTR [bx+si],al
      13:	02 00                	add    al,BYTE PTR [bx+si]
      15:	00 00                	add    BYTE PTR [bx+si],al
      17:	02 00                	add    al,BYTE PTR [bx+si]
      19:	58                   	pop    ax
      1a:	00 0d                	add    BYTE PTR [di],cl
      1c:	74 61                	je     0x7f
      1e:	4c                   	dec    sp
      1f:	65 66 74 4a          	gs data32 je 0x6d
      23:	75 73                	jne    0x98
      25:	74 69                	je     0x90
      27:	66 79 0e             	data32 jns 0x38
      2a:	74 61                	je     0x8d
      2c:	52                   	push   dx
      2d:	69 67 68 74 4a       	imul   sp,WORD PTR [bx+0x68],0x4a74
      32:	75 73                	jne    0xa7
      34:	74 69                	je     0x9f
      36:	66 79 08             	data32 jns 0x41
      39:	74 61                	je     0x9c
      3b:	43                   	inc    bx
      3c:	65 6e                	outs   dx,BYTE PTR gs:[si]
      3e:	74 65                	je     0xa5
      40:	72 03                	jb     0x45
      42:	0a 54 4c             	or     dl,BYTE PTR [si+0x4c]
      45:	65 66 74 52          	gs data32 je 0x9b
      49:	69 67 68 74 00       	imul   sp,WORD PTR [bx+0x68],0x74
      4e:	00 00                	add    BYTE PTR [bx+si],al
      50:	00 00                	add    BYTE PTR [bx+si],al
      52:	01 00                	add    WORD PTR [bx+si],ax
      54:	00 00                	add    BYTE PTR [bx+si],al
      56:	02 00                	add    al,BYTE PTR [bx+si]
      58:	cc                   	int3
      59:	00 01                	add    BYTE PTR [bx+di],al
      5b:	0c 54                	or     al,0x54
      5d:	48                   	dec    ax
      5e:	65 6c                	gs ins BYTE PTR es:[di],dx
      60:	70 43                	jo     0xa5
      62:	6f                   	outs   dx,WORD PTR ds:[si]
      63:	6e                   	outs   dx,BYTE PTR ds:[si]
      64:	74 65                	je     0xcb
      66:	78 74                	js     0xdc
      68:	04 01                	add    al,0x1
      6a:	00 00                	add    BYTE PTR [bx+si],al
      6c:	80 ff ff             	cmp    bh,0xff
      6f:	ff                   	(bad)
      70:	7f 08                	jg     0x7a
      72:	0c 54                	or     al,0x54
      74:	4e                   	dec    si
      75:	6f                   	outs   dx,WORD PTR ds:[si]
      76:	74 69                	je     0xe1
      78:	66 79 45             	data32 jns 0xc0
      7b:	76 65                	jbe    0xe2
      7d:	6e                   	outs   dx,BYTE PTR ds:[si]
      7e:	74 00                	je     0x80
      80:	01 00                	add    WORD PTR [bx+si],ax
      82:	06                   	push   es
      83:	53                   	push   bx
      84:	65 6e                	outs   dx,BYTE PTR gs:[si]
      86:	64 65 72 07          	fs gs jb 0x91
      8a:	54                   	push   sp
      8b:	4f                   	dec    di
      8c:	62 6a 65             	bound  bp,DWORD PTR [bp+si+0x65]
      8f:	63 74 00             	arpl   WORD PTR [si+0x0],si
      92:	00 00                	add    BYTE PTR [bx+si],al
      94:	00 00                	add    BYTE PTR [bx+si],al
      96:	00 00                	add    BYTE PTR [bx+si],al
      98:	00 b1 00 0c          	add    BYTE PTR [bx+di+0xc00],dh
      9c:	00 2e 00 dc          	add    BYTE PTR ds:0xdc00,ch
      a0:	00 64 20             	add    BYTE PTR [si+0x20],ah
      a3:	d8 00                	fadd   DWORD PTR [bx+si]
      a5:	9a 1f a3 00 cb       	call   0xcb00:0xa31f
      aa:	1f                   	pop    ds
      ab:	a7                   	cmps   WORD PTR ds:[si],WORD PTR es:[di]
      ac:	00 c4                	add    ah,al
      ae:	29 9f 00 0c          	sub    WORD PTR [bx+0xc00],bx
      b2:	45                   	inc    bp
      b3:	53                   	push   bx
      b4:	74 72                	je     0x128
      b6:	65 61                	gs popa
      b8:	6d                   	ins    WORD PTR es:[di],dx
      b9:	45                   	inc    bp
      ba:	72 72                	jb     0x12e
      bc:	6f                   	outs   dx,WORD PTR ds:[si]
      bd:	72 00                	jb     0xbf
      bf:	00 00                	add    BYTE PTR [bx+si],al
      c1:	00 00                	add    BYTE PTR [bx+si],al
      c3:	00 00                	add    BYTE PTR [bx+si],al
      c5:	00 de                	add    dh,bl
      c7:	00 0c                	add    BYTE PTR [si],cl
      c9:	00 b1 00 fa          	add    BYTE PTR [bx+di-0x600],dh
      cd:	00 64 20             	add    BYTE PTR [si+0x20],ah
      d0:	06                   	push   es
      d1:	01 9a 1f d0          	add    WORD PTR [bp+si-0x2fe1],bx
      d5:	00 cb                	add    bl,cl
      d7:	1f                   	pop    ds
      d8:	d4 00                	aam    0x0
      da:	c4 29                	les    bp,DWORD PTR [bx+di]
      dc:	0a 01                	or     al,BYTE PTR [bx+di]
      de:	0d 45 46             	or     ax,0x4645
      e1:	43                   	inc    bx
      e2:	72 65                	jb     0x149
      e4:	61                   	popa
      e5:	74 65                	je     0x14c
      e7:	45                   	inc    bp
      e8:	72 72                	jb     0x15c
      ea:	6f                   	outs   dx,WORD PTR ds:[si]
      eb:	72 00                	jb     0xed
      ed:	00 00                	add    BYTE PTR [bx+si],al
      ef:	00 00                	add    BYTE PTR [bx+si],al
      f1:	00 00                	add    BYTE PTR [bx+si],al
      f3:	00 0c                	add    BYTE PTR [si],cl
      f5:	01 0c                	add    WORD PTR [si],cx
      f7:	00 b1 00 26          	add    BYTE PTR [bx+di+0x2600],dh
      fb:	01 64 20             	add    WORD PTR [si+0x20],sp
      fe:	32 01                	xor    al,BYTE PTR [bx+di]
     100:	9a 1f fe 00 cb       	call   0xcb00:0xfe1f
     105:	1f                   	pop    ds
     106:	02 01                	add    al,BYTE PTR [bx+di]
     108:	c4 29                	les    bp,DWORD PTR [bx+di]
     10a:	36 01 0b             	add    WORD PTR ss:[bp+di],cx
     10d:	45                   	inc    bp
     10e:	46                   	inc    si
     10f:	4f                   	dec    di
     110:	70 65                	jo     0x177
     112:	6e                   	outs   dx,BYTE PTR ds:[si]
     113:	45                   	inc    bp
     114:	72 72                	jb     0x188
     116:	6f                   	outs   dx,WORD PTR ds:[si]
     117:	72 00                	jb     0x119
     119:	00 00                	add    BYTE PTR [bx+si],al
     11b:	00 00                	add    BYTE PTR [bx+si],al
     11d:	00 00                	add    BYTE PTR [bx+si],al
     11f:	00 38                	add    BYTE PTR [bx+si],bh
     121:	01 0c                	add    WORD PTR [si],cx
     123:	00 b1 00 52          	add    BYTE PTR [bx+di+0x5200],dh
     127:	01 64 20             	add    WORD PTR [si+0x20],sp
     12a:	5e                   	pop    si
     12b:	01 9a 1f 2a          	add    WORD PTR [bp+si+0x2a1f],bx
     12f:	01 cb                	add    bx,cx
     131:	1f                   	pop    ds
     132:	2e 01 c4             	cs add sp,ax
     135:	29 62 01             	sub    WORD PTR [bp+si+0x1],sp
     138:	0b 45 46             	or     ax,WORD PTR [di+0x46]
     13b:	69 6c 65 72 45       	imul   bp,WORD PTR [si+0x65],0x4572
     140:	72 72                	jb     0x1b4
     142:	6f                   	outs   dx,WORD PTR ds:[si]
     143:	72 00                	jb     0x145
     145:	00 00                	add    BYTE PTR [bx+si],al
     147:	00 00                	add    BYTE PTR [bx+si],al
     149:	00 00                	add    BYTE PTR [bx+si],al
     14b:	00 64 01             	add    BYTE PTR [si+0x1],ah
     14e:	0c 00                	or     al,0x0
     150:	38 01                	cmp    BYTE PTR [bx+di],al
     152:	7d 01                	jge    0x155
     154:	64 20 89 01 9a       	and    BYTE PTR fs:[bx+di-0x65ff],cl
     159:	1f                   	pop    ds
     15a:	56                   	push   si
     15b:	01 cb                	add    bx,cx
     15d:	1f                   	pop    ds
     15e:	5a                   	pop    dx
     15f:	01 c4                	add    sp,ax
     161:	29 8d 01 0a          	sub    WORD PTR [di+0xa01],cx
     165:	45                   	inc    bp
     166:	52                   	push   dx
     167:	65 61                	gs popa
     169:	64 45                	fs inc bp
     16b:	72 72                	jb     0x1df
     16d:	6f                   	outs   dx,WORD PTR ds:[si]
     16e:	72 00                	jb     0x170
     170:	00 00                	add    BYTE PTR [bx+si],al
     172:	00 00                	add    BYTE PTR [bx+si],al
     174:	00 00                	add    BYTE PTR [bx+si],al
     176:	00 8f 01 0c          	add    BYTE PTR [bx+0xc01],cl
     17a:	00 38                	add    BYTE PTR [bx+si],bh
     17c:	01 a9 01 64          	add    WORD PTR [bx+di+0x6401],bp
     180:	20 b5 01 9a          	and    BYTE PTR [di-0x65ff],dh
     184:	1f                   	pop    ds
     185:	81 01 cb 1f          	add    WORD PTR [bx+di],0x1fcb
     189:	85 01                	test   WORD PTR [bx+di],ax
     18b:	c4 29                	les    bp,DWORD PTR [bx+di]
     18d:	b9 01 0b             	mov    cx,0xb01
     190:	45                   	inc    bp
     191:	57                   	push   di
     192:	72 69                	jb     0x1fd
     194:	74 65                	je     0x1fb
     196:	45                   	inc    bp
     197:	72 72                	jb     0x20b
     199:	6f                   	outs   dx,WORD PTR ds:[si]
     19a:	72 00                	jb     0x19c
     19c:	00 00                	add    BYTE PTR [bx+si],al
     19e:	00 00                	add    BYTE PTR [bx+si],al
     1a0:	00 00                	add    BYTE PTR [bx+si],al
     1a2:	00 bb 01 0c          	add    BYTE PTR [bp+di+0xc01],bh
     1a6:	00 38                	add    BYTE PTR [bx+si],bh
     1a8:	01 a5 02 64          	add    WORD PTR [di+0x6402],sp
     1ac:	20 e4                	and    ah,ah
     1ae:	01 9a 1f ad          	add    WORD PTR [bp+si-0x52e1],bx
     1b2:	01 cb                	add    bx,cx
     1b4:	1f                   	pop    ds
     1b5:	b1 01                	mov    cl,0x1
     1b7:	c4 29                	les    bp,DWORD PTR [bx+di]
     1b9:	e8 01 0e             	call   0xfbd
     1bc:	45                   	inc    bp
     1bd:	43                   	inc    bx
     1be:	6c                   	ins    BYTE PTR es:[di],dx
     1bf:	61                   	popa
     1c0:	73 73                	jae    0x235
     1c2:	4e                   	dec    si
     1c3:	6f                   	outs   dx,WORD PTR ds:[si]
     1c4:	74 46                	je     0x20c
     1c6:	6f                   	outs   dx,WORD PTR ds:[si]
     1c7:	75 6e                	jne    0x237
     1c9:	64 00 00             	add    BYTE PTR fs:[bx+si],al
     1cc:	00 00                	add    BYTE PTR [bx+si],al
     1ce:	00 00                	add    BYTE PTR [bx+si],al
     1d0:	00 00                	add    BYTE PTR [bx+si],al
     1d2:	ea 01 0c 00 2e       	jmp    0x2e00:0xc01
     1d7:	00 15                	add    BYTE PTR [di],dl
     1d9:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     1dc:	11 02                	adc    WORD PTR [bp+si],ax
     1de:	9a 1f dc 01 cb       	call   0xcb01:0xdc1f
     1e3:	1f                   	pop    ds
     1e4:	e0 01                	loopne 0x1e7
     1e6:	c4 29                	les    bp,DWORD PTR [bx+di]
     1e8:	d8 01                	fadd   DWORD PTR [bx+di]
     1ea:	0c 45                	or     al,0x45
     1ec:	52                   	push   dx
     1ed:	65 73 4e             	gs jae 0x23e
     1f0:	6f                   	outs   dx,WORD PTR ds:[si]
     1f1:	74 46                	je     0x239
     1f3:	6f                   	outs   dx,WORD PTR ds:[si]
     1f4:	75 6e                	jne    0x264
     1f6:	64 00 00             	add    BYTE PTR fs:[bx+si],al
     1f9:	00 00                	add    BYTE PTR [bx+si],al
     1fb:	00 00                	add    BYTE PTR [bx+si],al
     1fd:	00 00                	add    BYTE PTR [bx+si],al
     1ff:	17                   	pop    ss
     200:	02 0c                	add    cl,BYTE PTR [si]
     202:	00 2e 00 40          	add    BYTE PTR ds:0x4000,ch
     206:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     209:	3c 02                	cmp    al,0x2
     20b:	9a 1f 09 02 cb       	call   0xcb02:0x91f
     210:	1f                   	pop    ds
     211:	0d 02 c4             	or     ax,0xc402
     214:	29 05                	sub    WORD PTR [di],ax
     216:	02 0a                	add    cl,BYTE PTR [bp+si]
     218:	45                   	inc    bp
     219:	4c                   	dec    sp
     21a:	69 73 74 45 72       	imul   si,WORD PTR [bp+di+0x74],0x7245
     21f:	72 6f                	jb     0x290
     221:	72 00                	jb     0x223
     223:	00 00                	add    BYTE PTR [bx+si],al
     225:	00 00                	add    BYTE PTR [bx+si],al
     227:	00 00                	add    BYTE PTR [bx+si],al
     229:	00 42 02             	add    BYTE PTR [bp+si+0x2],al
     22c:	0c 00                	or     al,0x0
     22e:	2e 00 71 02          	add    BYTE PTR cs:[bx+di+0x2],dh
     232:	64 20 6d 02          	and    BYTE PTR fs:[di+0x2],ch
     236:	9a 1f 34 02 cb       	call   0xcb02:0x341f
     23b:	1f                   	pop    ds
     23c:	38 02                	cmp    BYTE PTR [bp+si],al
     23e:	c4 29                	les    bp,DWORD PTR [bx+di]
     240:	30 02                	xor    BYTE PTR [bp+si],al
     242:	10 45 53             	adc    BYTE PTR [di+0x53],al
     245:	74 72                	je     0x2b9
     247:	69 6e 67 4c 69       	imul   bp,WORD PTR [bp+0x67],0x694c
     24c:	73 74                	jae    0x2c2
     24e:	45                   	inc    bp
     24f:	72 72                	jb     0x2c3
     251:	6f                   	outs   dx,WORD PTR ds:[si]
     252:	72 00                	jb     0x254
     254:	00 00                	add    BYTE PTR [bx+si],al
     256:	00 00                	add    BYTE PTR [bx+si],al
     258:	00 00                	add    BYTE PTR [bx+si],al
     25a:	00 73 02             	add    BYTE PTR [bp+di+0x2],dh
     25d:	0c 00                	or     al,0x0
     25f:	2e 00 1e 07 64       	add    BYTE PTR cs:0x6407,bl
     264:	20 9d 02 9a          	and    BYTE PTR [di-0x65fe],bl
     268:	1f                   	pop    ds
     269:	65 02 cb             	gs add cl,bl
     26c:	1f                   	pop    ds
     26d:	69 02 c4 29          	imul   ax,WORD PTR [bp+si],0x29c4
     271:	61                   	popa
     272:	02 0f                	add    cl,BYTE PTR [bx]
     274:	45                   	inc    bp
     275:	43                   	inc    bx
     276:	6f                   	outs   dx,WORD PTR ds:[si]
     277:	6d                   	ins    WORD PTR es:[di],dx
     278:	70 6f                	jo     0x2e9
     27a:	6e                   	outs   dx,BYTE PTR ds:[si]
     27b:	65 6e                	outs   dx,BYTE PTR gs:[si]
     27d:	74 45                	je     0x2c4
     27f:	72 72                	jb     0x2f3
     281:	6f                   	outs   dx,WORD PTR ds:[si]
     282:	72 00                	jb     0x284
     284:	00 00                	add    BYTE PTR [bx+si],al
     286:	00 00                	add    BYTE PTR [bx+si],al
     288:	00 00                	add    BYTE PTR [bx+si],al
     28a:	00 ab 02 0c          	add    BYTE PTR [bp+di+0xc02],ch
     28e:	00 2c                	add    BYTE PTR [si],ch
     290:	1f                   	pop    ds
     291:	cf                   	iret
     292:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     295:	91                   	xchg   cx,ax
     296:	02 9a 1f 95          	add    bl,BYTE PTR [bp+si-0x6ae1]
     29a:	02 cb                	add    cl,bl
     29c:	1f                   	pop    ds
     29d:	99                   	cwd
     29e:	02 0f                	add    cl,BYTE PTR [bx]
     2a0:	0c d3                	or     al,0xd3
     2a2:	02 fb                	add    bh,bl
     2a4:	0c a9                	or     al,0xa9
     2a6:	02 17                	add    dl,BYTE PTR [bx]
     2a8:	0e                   	push   cs
     2a9:	a1 02 05             	mov    ax,ds:0x502
     2ac:	54                   	push   sp
     2ad:	4c                   	dec    sp
     2ae:	69 73 74 e9 02       	imul   si,WORD PTR [bp+di+0x74],0x2e9
     2b3:	00 00                	add    BYTE PTR [bx+si],al
     2b5:	00 00                	add    BYTE PTR [bx+si],al
     2b7:	00 00                	add    BYTE PTR [bx+si],al
     2b9:	dd 02                	fld    QWORD PTR [bp+si]
     2bb:	04 00                	add    al,0x0
     2bd:	2c 1f                	sub    al,0x1f
     2bf:	fc                   	cld
     2c0:	02 64 20             	add    ah,BYTE PTR [si+0x20]
     2c3:	bf 02 9a             	mov    di,0x9a02
     2c6:	1f                   	pop    ds
     2c7:	c3                   	ret
     2c8:	02 cb                	add    cl,bl
     2ca:	1f                   	pop    ds
     2cb:	c7 02 66 1f          	mov    WORD PTR [bp+si],0x1f66
     2cf:	cb                   	retf
     2d0:	02 cd                	add    cl,ch
     2d2:	11 d7                	adc    di,dx
     2d4:	02 e4                	add    ah,ah
     2d6:	11 db                	adc    bx,bx
     2d8:	02 fa                	add    bh,dl
     2da:	10 f8                	adc    al,bh
     2dc:	02 0b                	add    cl,BYTE PTR [bp+di]
     2de:	54                   	push   sp
     2df:	50                   	push   ax
     2e0:	65 72 73             	gs jb  0x356
     2e3:	69 73 74 65 6e       	imul   si,WORD PTR [bp+di+0x74],0x6e65
     2e8:	74 07                	je     0x2f1
     2ea:	0b 54 50             	or     dx,WORD PTR [si+0x50]
     2ed:	65 72 73             	gs jb  0x363
     2f0:	69 73 74 65 6e       	imul   si,WORD PTR [bp+di+0x74],0x6e65
     2f5:	74 d1                	je     0x2c8
     2f7:	02 30                	add    dh,BYTE PTR [bx+si]
     2f9:	03 34                	add    si,WORD PTR [si]
     2fb:	1f                   	pop    ds
     2fc:	38 03                	cmp    BYTE PTR [bp+di],al
     2fe:	00 00                	add    BYTE PTR [bx+si],al
     300:	07                   	pop    es
     301:	43                   	inc    bx
     302:	6c                   	ins    BYTE PTR es:[di],dx
     303:	61                   	popa
     304:	73 73                	jae    0x379
     306:	65 73 00             	gs jae 0x309
     309:	00 8b 03 00          	add    BYTE PTR [bp+di+0x3],cl
     30d:	00 00                	add    BYTE PTR [bx+si],al
     30f:	00 00                	add    BYTE PTR [bx+si],al
     311:	00 82 03 06          	add    BYTE PTR [bp+si+0x603],al
     315:	00 d1                	add    cl,dl
     317:	02 97 03 64          	add    dl,BYTE PTR [bx+0x6403]
     31b:	20 c3                	and    bl,al
     31d:	03 9a 1f 1c          	add    bx,WORD PTR [bp+si+0x1c1f]
     321:	03 cb                	add    cx,bx
     323:	1f                   	pop    ds
     324:	20 03                	and    BYTE PTR [bp+di],al
     326:	66 1f                	popd   ds
     328:	24 03                	and    al,0x3
     32a:	cd 11                	int    0x11
     32c:	18 03                	sbb    BYTE PTR [bp+di],al
     32e:	f0 13 40 03          	lock adc ax,WORD PTR [bx+si+0x3]
     332:	48                   	dec    ax
     333:	13 64 03             	adc    sp,WORD PTR [si+0x3]
     336:	64 20 3c             	and    BYTE PTR fs:[si],bh
     339:	03 64 20             	add    sp,WORD PTR [si+0x20]
     33c:	5c                   	pop    sp
     33d:	03 03                	add    ax,WORD PTR [bp+di]
     33f:	15 44 03             	adc    ax,0x344
     342:	94                   	xchg   sp,ax
     343:	19 48 03             	sbb    WORD PTR [bx+si+0x3],cx
     346:	d8 19                	fcomp  DWORD PTR [bx+di]
     348:	4c                   	dec    sp
     349:	03 35                	add    si,WORD PTR [di]
     34b:	1c 50                	sbb    al,0x50
     34d:	03 4a 12             	add    cx,WORD PTR [bp+si+0x12]
     350:	54                   	push   sp
     351:	03 78 12             	add    di,WORD PTR [bx+si+0x12]
     354:	58                   	pop    ax
     355:	03 b2 12 34          	add    si,WORD PTR [bp+si+0x3412]
     359:	03 64 20             	add    sp,WORD PTR [si+0x20]
     35c:	60                   	pusha
     35d:	03 64 20             	add    sp,WORD PTR [si+0x20]
     360:	70 03                	jo     0x365
     362:	55                   	push   bp
     363:	14 68                	adc    al,0x68
     365:	03 13                	add    dx,WORD PTR [bp+di]
     367:	16                   	push   ss
     368:	6c                   	ins    BYTE PTR es:[di],dx
     369:	03 e0                	add    sp,ax
     36b:	16                   	push   ss
     36c:	74 03                	je     0x371
     36e:	64 20 28             	and    BYTE PTR fs:[bx+si],ch
     371:	03 78 17             	add    di,WORD PTR [bx+si+0x17]
     374:	78 03                	js     0x379
     376:	24 19                	and    al,0x19
     378:	7c 03                	jl     0x37d
     37a:	39 1a                	cmp    WORD PTR [bp+si],bx
     37c:	80 03 ac             	add    BYTE PTR [bp+di],0xac
     37f:	1b 2c                	sbb    bp,WORD PTR [si]
     381:	03 08                	add    cx,WORD PTR [bx+si]
     383:	54                   	push   sp
     384:	53                   	push   bx
     385:	74 72                	je     0x3f9
     387:	69 6e 67 73 07       	imul   bp,WORD PTR [bp+0x67],0x773
     38c:	08 54 53             	or     BYTE PTR [si+0x53],dl
     38f:	74 72                	je     0x403
     391:	69 6e 67 73 2a       	imul   bp,WORD PTR [bp+0x67],0x2a73
     396:	03 9b 03 e9          	add    bx,WORD PTR [bp+di-0x16fd]
     39a:	02 23                	add    ah,BYTE PTR [bp+di]
     39c:	04 00                	add    al,0x0
     39e:	00 07                	add    BYTE PTR [bx],al
     3a0:	43                   	inc    bx
     3a1:	6c                   	ins    BYTE PTR es:[di],dx
     3a2:	61                   	popa
     3a3:	73 73                	jae    0x418
     3a5:	65 73 00             	gs jae 0x3a8
     3a8:	00 3d                	add    BYTE PTR [di],bh
     3aa:	04 00                	add    al,0x0
     3ac:	00 00                	add    BYTE PTR [bx+si],al
     3ae:	00 00                	add    BYTE PTR [bx+si],al
     3b0:	00 31                	add    BYTE PTR [bx+di],dh
     3b2:	04 1c                	add    al,0x1c
     3b4:	00 2a                	add    BYTE PTR [bp+si],ch
     3b6:	03 4c 04             	add    cx,WORD PTR [si+0x4]
     3b9:	64 20 80 04 9a       	and    BYTE PTR fs:[bx+si-0x65fc],al
     3be:	1f                   	pop    ds
     3bf:	bb 03 cb             	mov    bx,0xcb03
     3c2:	1f                   	pop    ds
     3c3:	bf 03 4b             	mov    di,0x4b03
     3c6:	1d ef 03             	sbb    ax,0x3ef
     3c9:	cd 11                	int    0x11
     3cb:	b7 03                	mov    bh,0x3
     3cd:	f0 13 f3             	lock adc si,bx
     3d0:	03 48 13             	add    cx,WORD PTR [bx+si+0x13]
     3d3:	07                   	pop    es
     3d4:	04 15                	add    al,0x15
     3d6:	20 db                	and    bl,bl
     3d8:	03 44 20             	add    ax,WORD PTR [si+0x20]
     3db:	df 03                	fild   WORD PTR [bp+di]
     3dd:	5d                   	pop    bp
     3de:	20 e3                	and    bl,ah
     3e0:	03 30                	add    si,WORD PTR [bx+si]
     3e2:	21 e7                	and    di,sp
     3e4:	03 a9 21 eb          	add    bp,WORD PTR [bx+di-0x14df]
     3e8:	03 0a                	add    cx,WORD PTR [bp+si]
     3ea:	23 c7                	and    ax,di
     3ec:	03 a5 1d fb          	add    sp,WORD PTR [di-0x4e3]
     3f0:	03 78 12             	add    di,WORD PTR [bx+si+0x12]
     3f3:	f7 03 b2 12          	test   WORD PTR [bp+di],0x12b2
     3f7:	d3 03                	rol    WORD PTR [bp+di],cl
     3f9:	94                   	xchg   sp,ax
     3fa:	1e                   	push   ds
     3fb:	ff 03                	inc    WORD PTR [bp+di]
     3fd:	00 1f                	add    BYTE PTR [bx],bl
     3ff:	03 04                	add    ax,WORD PTR [si]
     401:	48                   	dec    ax
     402:	1f                   	pop    ds
     403:	2b 04                	sub    ax,WORD PTR [si]
     405:	13 16 13 04          	adc    dx,WORD PTR ds:0x413
     409:	8d 20                	lea    sp,[bx+si]
     40b:	0f 04                	(bad)
     40d:	d5 20                	aad    0x20
     40f:	2f                   	das
     410:	04 78                	add    al,0x78
     412:	17                   	pop    ss
     413:	17                   	pop    ss
     414:	04 24                	add    al,0x24
     416:	19 1b                	sbb    WORD PTR [bp+di],bx
     418:	04 39                	add    al,0x39
     41a:	1a 1f                	sbb    bl,BYTE PTR [bx]
     41c:	04 ac                	add    al,0xac
     41e:	1b cb                	sbb    cx,bx
     420:	03 3e 1e 27          	add    di,WORD PTR ds:0x271e
     424:	04 69                	add    al,0x69
     426:	1e                   	push   ds
     427:	d7                   	xlat   BYTE PTR ds:[bx]
     428:	03 7b 1f             	add    di,WORD PTR [bp+di+0x1f]
     42b:	0b 04                	or     ax,WORD PTR [si]
     42d:	31 23                	xor    WORD PTR [bp+di],sp
     42f:	cf                   	iret
     430:	03 0b                	add    cx,WORD PTR [bp+di]
     432:	54                   	push   sp
     433:	53                   	push   bx
     434:	74 72                	je     0x4a8
     436:	69 6e 67 4c 69       	imul   bp,WORD PTR [bp+0x67],0x694c
     43b:	73 74                	jae    0x4b1
     43d:	07                   	pop    es
     43e:	0b 54 53             	or     dx,WORD PTR [si+0x53]
     441:	74 72                	je     0x4b5
     443:	69 6e 67 4c 69       	imul   bp,WORD PTR [bp+0x67],0x694c
     448:	73 74                	jae    0x4be
     44a:	c9                   	leave
     44b:	03 50 04             	add    dx,WORD PTR [bx+si+0x4]
     44e:	8b 03                	mov    ax,WORD PTR [bp+di]
     450:	b4 04                	mov    ah,0x4
     452:	00 00                	add    BYTE PTR [bx+si],al
     454:	07                   	pop    es
     455:	43                   	inc    bx
     456:	6c                   	ins    BYTE PTR es:[di],dx
     457:	61                   	popa
     458:	73 73                	jae    0x4cd
     45a:	65 73 00             	gs jae 0x45d
	...
     465:	00 8a 04 04          	add    BYTE PTR [bp+si+0x404],cl
     469:	00 2c                	add    BYTE PTR [si],ch
     46b:	1f                   	pop    ds
     46c:	b0 04                	mov    al,0x4
     46e:	64 20 6c 04          	and    BYTE PTR fs:[si+0x4],ch
     472:	9a 1f 70 04 cb       	call   0xcb04:0x701f
     477:	1f                   	pop    ds
     478:	74 04                	je     0x47e
     47a:	66 1f                	popd   ds
     47c:	78 04                	js     0x482
     47e:	64 20 84 04 64       	and    BYTE PTR fs:[si+0x6404],al
     483:	20 88 04 64          	and    BYTE PTR [bx+si+0x6404],cl
     487:	20 7c 04             	and    BYTE PTR [si+0x4],bh
     48a:	07                   	pop    es
     48b:	54                   	push   sp
     48c:	53                   	push   bx
     48d:	74 72                	je     0x501
     48f:	65 61                	gs popa
     491:	6d                   	ins    WORD PTR es:[di],dx
	...
     49a:	be 04 06             	mov    si,0x604
     49d:	00 7e 04             	add    BYTE PTR [bp+0x4],bh
     4a0:	ea 04 64 20 e6       	jmp    0xe620:0x6404
     4a5:	04 9a                	add    al,0x9a
     4a7:	1f                   	pop    ds
     4a8:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
     4a9:	04 cb                	add    al,0xcb
     4ab:	1f                   	pop    ds
     4ac:	a8 04                	test   al,0x4
     4ae:	66 1f                	popd   ds
     4b0:	ac                   	lods   al,BYTE PTR ds:[si]
     4b1:	04 55                	add    al,0x55
     4b3:	26 b8 04 94          	es mov ax,0x9404
     4b7:	26 bc 04 d3          	es mov sp,0xd304
     4bb:	26 a0 04 0d          	mov    al,es:0xd04
     4bf:	54                   	push   sp
     4c0:	48                   	dec    ax
     4c1:	61                   	popa
     4c2:	6e                   	outs   dx,BYTE PTR ds:[si]
     4c3:	64 6c                	fs ins BYTE PTR es:[di],dx
     4c5:	65 53                	gs push bx
     4c7:	74 72                	je     0x53b
     4c9:	65 61                	gs popa
     4cb:	6d                   	ins    WORD PTR es:[di],dx
	...
     4d4:	f8                   	clc
     4d5:	04 06                	add    al,0x6
     4d7:	00 b2 04 22          	add    BYTE PTR [bp+si+0x2204],dh
     4db:	05 64 20             	add    ax,0x2064
     4de:	1e                   	push   ds
     4df:	05 9a 1f             	add    ax,0x1f9a
     4e2:	de 04                	fiadd  WORD PTR [si]
     4e4:	cb                   	retf
     4e5:	1f                   	pop    ds
     4e6:	e2 04                	loop   0x4ec
     4e8:	da 27                	fisub  DWORD PTR [bx]
     4ea:	ee                   	out    dx,al
     4eb:	04 55                	add    al,0x55
     4ed:	26 f2 04 94          	es repnz add al,0x94
     4f1:	26 f6 04 d3          	test   BYTE PTR es:[si],0xd3
     4f5:	26 da 04             	fiadd  DWORD PTR es:[si]
     4f8:	0b 54 46             	or     dx,WORD PTR [si+0x46]
     4fb:	69 6c 65 53 74       	imul   bp,WORD PTR [si+0x65],0x7453
     500:	72 65                	jb     0x567
     502:	61                   	popa
     503:	6d                   	ins    WORD PTR es:[di],dx
	...
     50c:	30 05                	xor    BYTE PTR [di],al
     50e:	14 00                	adc    al,0x0
     510:	7e 04                	jle    0x516
     512:	5c                   	pop    sp
     513:	05 64 20             	add    ax,0x2064
     516:	60                   	pusha
     517:	05 9a 1f             	add    ax,0x1f9a
     51a:	16                   	push   ss
     51b:	05 cb 1f             	add    ax,0x1fcb
     51e:	1a 05                	sbb    al,BYTE PTR [di]
     520:	1a 28                	sbb    ch,BYTE PTR [bx+si]
     522:	26 05 43 28          	es add ax,0x2843
     526:	2a 05                	sub    al,BYTE PTR [di]
     528:	06                   	push   es
     529:	29 2e 05 19          	sub    WORD PTR ds:0x1905,bp
     52d:	2a 12                	sub    dl,BYTE PTR [bp+si]
     52f:	05 0d 54             	add    ax,0x540d
     532:	4d                   	dec    bp
     533:	65 6d                	gs ins WORD PTR es:[di],dx
     535:	6f                   	outs   dx,WORD PTR ds:[si]
     536:	72 79                	jb     0x5b1
     538:	53                   	push   bx
     539:	74 72                	je     0x5ad
     53b:	65 61                	gs popa
     53d:	6d                   	ins    WORD PTR es:[di],dx
	...
     546:	66 05 16 00 2c 1f    	add    eax,0x1f2c0016
     54c:	87 05                	xchg   WORD PTR [di],ax
     54e:	64 20 4c 05          	and    BYTE PTR fs:[si+0x5],cl
     552:	9a 1f 50 05 cb       	call   0xcb05:0x501f
     557:	1f                   	pop    ds
     558:	54                   	push   sp
     559:	05 15 2c             	add    ax,0x2c15
     55c:	97                   	xchg   di,ax
     55d:	05 64 20             	add    ax,0x2064
     560:	64 05 64 20          	fs add ax,0x2064
     564:	58                   	pop    ax
     565:	05 06 54             	add    ax,0x5406
     568:	46                   	inc    si
     569:	69 6c 65 72 00       	imul   bp,WORD PTR [si+0x65],0x72
     56e:	00 00                	add    BYTE PTR [bx+si],al
     570:	00 00                	add    BYTE PTR [bx+si],al
     572:	00 00                	add    BYTE PTR [bx+si],al
     574:	00 a1 05 80          	add    BYTE PTR [bx+di-0x7ffb],ah
     578:	00 5e 05             	add    BYTE PTR [bp+0x5],bl
     57b:	e0 05                	loopne 0x582
     57d:	64 20 d4             	fs and ah,dl
     580:	05 9a 1f             	add    ax,0x1f9a
     583:	7f 05                	jg     0x58a
     585:	cb                   	retf
     586:	1f                   	pop    ds
     587:	83 05 38             	add    WORD PTR [di],0x38
     58a:	2d 8f 05             	sub    ax,0x58f
     58d:	9b                   	fwait
     58e:	2d 93 05             	sub    ax,0x593
     591:	d6                   	(bad)
     592:	2d 7b 05             	sub    ax,0x57b
     595:	db 2e 9b 05          	fld    TBYTE PTR ds:0x59b
     599:	14 2f                	adc    al,0x2f
     59b:	9f                   	lahf
     59c:	05 fd 41             	add    ax,0x41fd
     59f:	8b 05                	mov    ax,WORD PTR [di]
     5a1:	07                   	pop    es
     5a2:	54                   	push   sp
     5a3:	52                   	push   dx
     5a4:	65 61                	gs popa
     5a6:	64 65 72 05          	fs gs jb 0x5af
     5aa:	0e                   	push   cs
     5ab:	54                   	push   sp
     5ac:	43                   	inc    bx
     5ad:	6f                   	outs   dx,WORD PTR ds:[si]
     5ae:	6d                   	ins    WORD PTR es:[di],dx
     5af:	70 6f                	jo     0x620
     5b1:	6e                   	outs   dx,BYTE PTR ds:[si]
     5b2:	65 6e                	outs   dx,BYTE PTR gs:[si]
     5b4:	74 4e                	je     0x604
     5b6:	61                   	popa
     5b7:	6d                   	ins    WORD PTR es:[di],dx
     5b8:	65 3f                	gs aas
     5ba:	15 06 00             	adc    ax,0x6
     5bd:	00 00                	add    BYTE PTR [bx+si],al
     5bf:	00 00                	add    BYTE PTR [bx+si],al
     5c1:	00 0a                	add    BYTE PTR [bp+si],cl
     5c3:	06                   	push   es
     5c4:	1a 00                	sbb    al,BYTE PTR [bx+si]
     5c6:	d1 02                	rol    WORD PTR [bp+si],1
     5c8:	23 06 64 20          	and    ax,WORD PTR ds:0x2064
     5cc:	54                   	push   sp
     5cd:	06                   	push   es
     5ce:	9a 1f cc 05 cb       	call   0xcb05:0xcc1f
     5d3:	1f                   	pop    ds
     5d4:	d0 05                	rol    BYTE PTR [di],1
     5d6:	2b 4c dc             	sub    cx,WORD PTR [si-0x24]
     5d9:	05 cd 11             	add    ax,0x11cd
     5dc:	e4 05                	in     al,0x5
     5de:	6e                   	outs   dx,BYTE PTR ds:[si]
     5df:	4f                   	dec    di
     5e0:	e8 05 fa             	call   0xffe8
     5e3:	10 c8                	adc    al,cl
     5e5:	05 e5 4f             	add    ax,0x4fe5
     5e8:	ec                   	in     al,dx
     5e9:	05 f4 4f             	add    ax,0x4ff4
     5ec:	f0 05 05 4f          	lock add ax,0x4f05
     5f0:	f4                   	hlt
     5f1:	05 03 50             	add    ax,0x5003
     5f4:	f8                   	clc
     5f5:	05 46 51             	add    ax,0x5146
     5f8:	fc                   	cld
     5f9:	05 38 50             	add    ax,0x5038
     5fc:	00 06 1a 50          	add    BYTE PTR ds:0x501a,al
     600:	04 06                	add    al,0x6
     602:	21 50 08             	and    WORD PTR [bx+si+0x8],dx
     605:	06                   	push   es
     606:	d9 4b d8             	(bad)  [bp+di-0x28]
     609:	05 0a 54             	add    ax,0x540a
     60c:	43                   	inc    bx
     60d:	6f                   	outs   dx,WORD PTR ds:[si]
     60e:	6d                   	ins    WORD PTR es:[di],dx
     60f:	70 6f                	jo     0x680
     611:	6e                   	outs   dx,BYTE PTR ds:[si]
     612:	65 6e                	outs   dx,BYTE PTR gs:[si]
     614:	74 07                	je     0x61d
     616:	0a 54 43             	or     dl,BYTE PTR [si+0x43]
     619:	6f                   	outs   dx,WORD PTR ds:[si]
     61a:	6d                   	ins    WORD PTR es:[di],dx
     61b:	70 6f                	jo     0x68c
     61d:	6e                   	outs   dx,BYTE PTR ds:[si]
     61e:	65 6e                	outs   dx,BYTE PTR gs:[si]
     620:	74 da                	je     0x5fc
     622:	05 27 06             	add    ax,0x627
     625:	e9 02 37             	jmp    0x3d2a
     628:	06                   	push   es
     629:	02 00                	add    al,BYTE PTR [bx+si]
     62b:	07                   	pop    es
     62c:	43                   	inc    bx
     62d:	6c                   	ins    BYTE PTR es:[di],dx
     62e:	61                   	popa
     62f:	73 73                	jae    0x6a4
     631:	65 73 02             	gs jae 0x636
     634:	00 a9 05 3b          	add    BYTE PTR [bx+di+0x3b05],ch
     638:	06                   	push   es
     639:	2a 51 27             	sub    dl,BYTE PTR [bx+di+0x27]
     63c:	07                   	pop    es
     63d:	1c 00                	sbb    al,0x0
     63f:	fe                   	(bad)
     640:	ff 00                	inc    WORD PTR [bx+si]
     642:	00 00                	add    BYTE PTR [bx+si],al
     644:	00 00                	add    BYTE PTR [bx+si],al
     646:	80 00 00             	add    BYTE PTR [bx+si],0x0
     649:	00 80 00 00          	add    BYTE PTR [bx+si+0x0],al
     64d:	04 4e                	add    al,0x4e
     64f:	61                   	popa
     650:	6d                   	ins    WORD PTR es:[di],dx
     651:	65 f5                	gs cmc
     653:	22 35                	and    dh,BYTE PTR [di]
     655:	07                   	pop    es
     656:	0c 00                	or     al,0x0
     658:	ff                   	(bad)
     659:	ff 0c                	dec    WORD PTR [si]
     65b:	00 ff                	add    bh,bh
     65d:	ff 01                	inc    WORD PTR [bx+di]
     65f:	00 00                	add    BYTE PTR [bx+si],al
     661:	00 00                	add    BYTE PTR [bx+si],al
     663:	80 00 00             	add    BYTE PTR [bx+si],0x0
     666:	00 00                	add    BYTE PTR [bx+si],al
     668:	01 00                	add    WORD PTR [bx+si],ax
     66a:	03 54 61             	add    dx,WORD PTR [si+0x61]
     66d:	67 c8 04 00 00       	addr32 enter 0x4,0x0
     672:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     675:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     678:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     67b:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     67e:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     681:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     684:	c9                   	leave
     685:	ca 04 00             	retf   0x4
     688:	c8 04 00 00          	enter  0x4,0x0
     68c:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     68f:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     692:	26 89 05             	mov    WORD PTR es:[di],ax
     695:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     698:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
     69c:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
     69f:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     6a3:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     6a6:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
     6aa:	c9                   	leave
     6ab:	ca 08 00             	retf   0x8
     6ae:	c8 04 00 00          	enter  0x4,0x0
     6b2:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
     6b5:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     6b8:	26 89 05             	mov    WORD PTR es:[di],ax
     6bb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     6be:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
     6c2:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     6c5:	03 46 08             	add    ax,WORD PTR [bp+0x8]
     6c8:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     6cc:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     6cf:	03 46 06             	add    ax,WORD PTR [bp+0x6]
     6d2:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
     6d6:	c9                   	leave
     6d7:	ca 08 00             	retf   0x8
     6da:	55                   	push   bp
     6db:	89 e5                	mov    bp,sp
     6dd:	31 c0                	xor    ax,ax
     6df:	31 d2                	xor    dx,dx
     6e1:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     6e4:	26 8b 7d e2          	mov    di,WORD PTR es:[di-0x1e]
     6e8:	09 ff                	or     di,di
     6ea:	74 06                	je     0x6f2
     6ec:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
     6f0:	8c c2                	mov    dx,es
     6f2:	c9                   	leave
     6f3:	c2 04 00             	ret    0x4
     6f6:	c8 08 01 00          	enter  0x108,0x0
     6fa:	8d be f8 fe          	lea    di,[bp-0x108]
     6fe:	16                   	push   ss
     6ff:	57                   	push   di
     700:	68 07 f0             	push   0xf007
     703:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     706:	89 f8                	mov    ax,di
     708:	8c c2                	mov    dx,es
     70a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     70d:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
     710:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
     714:	8d 7e f8             	lea    di,[bp-0x8]
     717:	16                   	push   ss
     718:	57                   	push   di
     719:	6a 00                	push   0x0
     71b:	9a 50 09 2e 07       	call   0x72e:0x950
     720:	b0 01                	mov    al,0x1
     722:	50                   	push   ax
     723:	b8 bb 01             	mov    ax,0x1bb
     726:	ba 66 07             	mov    dx,0x766
     729:	52                   	push   dx
     72a:	50                   	push   ax
     72b:	9a e6 28 86 07       	call   0x786:0x28e6
     730:	52                   	push   dx
     731:	50                   	push   ax
     732:	9a 99 13 7c 07       	call   0x77c:0x1399
     737:	c9                   	leave
     738:	c2 04 00             	ret    0x4
     73b:	c8 08 01 00          	enter  0x108,0x0
     73f:	c4 3e 02 17          	les    di,DWORD PTR ds:0x1702
     743:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     747:	48                   	dec    ax
     748:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     74b:	31 c0                	xor    ax,ax
     74d:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     750:	7f 44                	jg     0x796
     752:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     755:	eb 03                	jmp    0x75a
     757:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     75a:	ff 76 fa             	push   WORD PTR [bp-0x6]
     75d:	c4 3e 02 17          	les    di,DWORD PTR ds:0x1702
     761:	06                   	push   es
     762:	57                   	push   di
     763:	9a d0 0d e7 07       	call   0x7e7:0xdd0
     768:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     76b:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     76e:	8d be f8 fe          	lea    di,[bp-0x108]
     772:	16                   	push   ss
     773:	57                   	push   di
     774:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     777:	06                   	push   es
     778:	57                   	push   di
     779:	9a ed 20 15 08       	call   0x815:0x20ed
     77e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     781:	06                   	push   es
     782:	57                   	push   di
     783:	9a 30 07 74 08       	call   0x874:0x730
     788:	09 c0                	or     ax,ax
     78a:	75 02                	jne    0x78e
     78c:	eb 43                	jmp    0x7d1
     78e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     791:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
     794:	75 c1                	jne    0x757
     796:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     799:	06                   	push   es
     79a:	57                   	push   di
     79b:	c4 3e 06 17          	les    di,DWORD PTR ds:0x1706
     79f:	06                   	push   es
     7a0:	57                   	push   di
     7a1:	26 c4 3d             	les    di,DWORD PTR es:[di]
     7a4:	26 ff 5d 40          	call   DWORD PTR es:[di+0x40]
     7a8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     7ab:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
     7af:	7c 18                	jl     0x7c9
     7b1:	ff 76 fa             	push   WORD PTR [bp-0x6]
     7b4:	c4 3e 06 17          	les    di,DWORD PTR ds:0x1706
     7b8:	06                   	push   es
     7b9:	57                   	push   di
     7ba:	26 c4 3d             	les    di,DWORD PTR es:[di]
     7bd:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
     7c1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     7c4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     7c7:	eb 08                	jmp    0x7d1
     7c9:	31 c0                	xor    ax,ax
     7cb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     7ce:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     7d1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     7d4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     7d7:	c9                   	leave
     7d8:	ca 04 00             	retf   0x4
     7db:	c8 04 00 00          	enter  0x4,0x0
     7df:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7e2:	06                   	push   es
     7e3:	57                   	push   di
     7e4:	9a 3b 07 8c 08       	call   0x88c:0x73b
     7e9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     7ec:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     7ef:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     7f2:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
     7f5:	75 08                	jne    0x7ff
     7f7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     7fa:	06                   	push   es
     7fb:	57                   	push   di
     7fc:	e8 f7 fe             	call   0x6f6
     7ff:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     802:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     805:	c9                   	leave
     806:	ca 04 00             	retf   0x4
     809:	c8 0c 01 00          	enter  0x10c,0x0
     80d:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     810:	06                   	push   es
     811:	57                   	push   di
     812:	9a dd 20 6a 08       	call   0x86a:0x20dd
     817:	52                   	push   dx
     818:	50                   	push   ax
     819:	e8 be fe             	call   0x6da
     81c:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
     81f:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
     822:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
     825:	0b 46 f8             	or     ax,WORD PTR [bp-0x8]
     828:	74 5a                	je     0x884
     82a:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     82d:	26 8b 05             	mov    ax,WORD PTR es:[di]
     830:	48                   	dec    ax
     831:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     834:	31 c0                	xor    ax,ax
     836:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     839:	7f 49                	jg     0x884
     83b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     83e:	eb 03                	jmp    0x843
     840:	ff 46 fa             	inc    WORD PTR [bp-0x6]
     843:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     846:	c1 e0 02             	shl    ax,0x2
     849:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
     84c:	03 f8                	add    di,ax
     84e:	26 8b 45 02          	mov    ax,WORD PTR es:[di+0x2]
     852:	26 8b 55 04          	mov    dx,WORD PTR es:[di+0x4]
     856:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     859:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     85c:	8d be f4 fe          	lea    di,[bp-0x10c]
     860:	16                   	push   ss
     861:	57                   	push   di
     862:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
     865:	06                   	push   es
     866:	57                   	push   di
     867:	9a ed 20 c9 08       	call   0x8c9:0x20ed
     86c:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     86f:	06                   	push   es
     870:	57                   	push   di
     871:	9a 30 07 07 09       	call   0x907:0x730
     876:	09 c0                	or     ax,ax
     878:	75 02                	jne    0x87c
     87a:	eb 18                	jmp    0x894
     87c:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
     87f:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
     882:	75 bc                	jne    0x840
     884:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
     887:	06                   	push   es
     888:	57                   	push   di
     889:	9a db 07 b1 08       	call   0x8b1:0x7db
     88e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     891:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     894:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     897:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     89a:	c9                   	leave
     89b:	c2 08 00             	ret    0x8
     89e:	c8 48 01 00          	enter  0x148,0x0
     8a2:	ff 76 08             	push   WORD PTR [bp+0x8]
     8a5:	ff 76 06             	push   WORD PTR [bp+0x6]
     8a8:	c4 3e 02 17          	les    di,DWORD PTR ds:0x1702
     8ac:	06                   	push   es
     8ad:	57                   	push   di
     8ae:	9a 58 0e df 08       	call   0x8df:0xe58
     8b3:	3d ff ff             	cmp    ax,0xffff
     8b6:	74 03                	je     0x8bb
     8b8:	e9 9b 00             	jmp    0x956
     8bb:	8d be c0 fe          	lea    di,[bp-0x140]
     8bf:	16                   	push   ss
     8c0:	57                   	push   di
     8c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     8c4:	06                   	push   es
     8c5:	57                   	push   di
     8c6:	9a ed 20 d5 08       	call   0x8d5:0x20ed
     8cb:	8d 7e c0             	lea    di,[bp-0x40]
     8ce:	16                   	push   ss
     8cf:	57                   	push   di
     8d0:	6a 3f                	push   0x3f
     8d2:	9a e7 17 1e 09       	call   0x91e:0x17e7
     8d7:	8d 7e c0             	lea    di,[bp-0x40]
     8da:	16                   	push   ss
     8db:	57                   	push   di
     8dc:	9a 3b 07 10 09       	call   0x910:0x73b
     8e1:	09 d0                	or     ax,dx
     8e3:	74 3b                	je     0x920
     8e5:	8d be b8 fe          	lea    di,[bp-0x148]
     8e9:	16                   	push   ss
     8ea:	57                   	push   di
     8eb:	68 11 f0             	push   0xf011
     8ee:	8d 46 c0             	lea    ax,[bp-0x40]
     8f1:	8c d2                	mov    dx,ss
     8f3:	89 46 b8             	mov    WORD PTR [bp-0x48],ax
     8f6:	89 56 ba             	mov    WORD PTR [bp-0x46],dx
     8f9:	c6 46 bc 04          	mov    BYTE PTR [bp-0x44],0x4
     8fd:	8d 7e b8             	lea    di,[bp-0x48]
     900:	16                   	push   ss
     901:	57                   	push   di
     902:	6a 00                	push   0x0
     904:	9a 50 09 17 09       	call   0x917:0x950
     909:	b0 01                	mov    al,0x1
     90b:	50                   	push   ax
     90c:	b8 38 01             	mov    ax,0x138
     90f:	ba 2f 09             	mov    dx,0x92f
     912:	52                   	push   dx
     913:	50                   	push   ax
     914:	9a e6 28 8b 0a       	call   0xa8b:0x28e6
     919:	52                   	push   dx
     91a:	50                   	push   ax
     91b:	9a 99 13 4b 09       	call   0x94b:0x1399
     920:	ff 76 08             	push   WORD PTR [bp+0x8]
     923:	ff 76 06             	push   WORD PTR [bp+0x6]
     926:	c4 3e 02 17          	les    di,DWORD PTR ds:0x1702
     92a:	06                   	push   es
     92b:	57                   	push   di
     92c:	9a 2b 0c 35 09       	call   0x935:0xc2b
     931:	b8 d1 02             	mov    ax,0x2d1
     934:	ba a9 09             	mov    dx,0x9a9
     937:	3b 56 08             	cmp    dx,WORD PTR [bp+0x8]
     93a:	75 07                	jne    0x943
     93c:	3b 46 06             	cmp    ax,WORD PTR [bp+0x6]
     93f:	75 02                	jne    0x943
     941:	eb 13                	jmp    0x956
     943:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     946:	06                   	push   es
     947:	57                   	push   di
     948:	9a 08 21 d5 09       	call   0x9d5:0x2108
     94d:	89 46 06             	mov    WORD PTR [bp+0x6],ax
     950:	89 56 08             	mov    WORD PTR [bp+0x8],dx
     953:	e9 4c ff             	jmp    0x8a2
     956:	c9                   	leave
     957:	ca 04 00             	retf   0x4
     95a:	c8 04 00 00          	enter  0x4,0x0
     95e:	8c d3                	mov    bx,ss
     960:	8e c3                	mov    es,bx
     962:	8c db                	mov    bx,ds
     964:	fc                   	cld
     965:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     968:	40                   	inc    ax
     969:	c1 e0 02             	shl    ax,0x2
     96c:	89 c1                	mov    cx,ax
     96e:	29 cc                	sub    sp,cx
     970:	89 e7                	mov    di,sp
     972:	c5 76 08             	lds    si,DWORD PTR [bp+0x8]
     975:	89 7e 08             	mov    WORD PTR [bp+0x8],di
     978:	8c 46 0a             	mov    WORD PTR [bp+0xa],es
     97b:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
     97d:	8e db                	mov    ds,bx
     97f:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     982:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     985:	31 c0                	xor    ax,ax
     987:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     98a:	7f 27                	jg     0x9b3
     98c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     98f:	eb 03                	jmp    0x994
     991:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     994:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     997:	c1 e0 02             	shl    ax,0x2
     99a:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
     99d:	03 f8                	add    di,ax
     99f:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
     9a3:	26 ff 35             	push   WORD PTR es:[di]
     9a6:	9a 9e 08 52 0a       	call   0xa52:0x89e
     9ab:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     9ae:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
     9b1:	75 de                	jne    0x991
     9b3:	c9                   	leave
     9b4:	ca 06 00             	retf   0x6
	...
     9bf:	d7                   	xlat   BYTE PTR ds:[bx]
     9c0:	09 10                	or     WORD PTR [bx+si],dx
     9c2:	00 2c                	add    BYTE PTR [si],ch
     9c4:	1f                   	pop    ds
     9c5:	f0 09 64 20          	lock or WORD PTR [si+0x20],sp
     9c9:	c5 09                	lds    cx,DWORD PTR [bx+di]
     9cb:	9a 1f c9 09 cb       	call   0xcb09:0xc91f
     9d0:	1f                   	pop    ds
     9d1:	cd 09                	int    0x9
     9d3:	66 1f                	popd   ds
     9d5:	d1 09                	ror    WORD PTR [bx+di],1
     9d7:	09 54 49             	or     WORD PTR [si+0x49],dx
     9da:	6e                   	outs   dx,BYTE PTR ds:[si]
     9db:	74 43                	je     0xa20
     9dd:	6f                   	outs   dx,WORD PTR ds:[si]
     9de:	6e                   	outs   dx,BYTE PTR ds:[si]
     9df:	73 74                	jae    0xa55
     9e1:	55                   	push   bp
     9e2:	89 e5                	mov    bp,sp
     9e4:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     9e8:	74 08                	je     0x9f2
     9ea:	83 ec 08             	sub    sp,0x8
     9ed:	9a e2 1f e3 0a       	call   0xae3:0x1fe2
     9f2:	8b 46 14             	mov    ax,WORD PTR [bp+0x14]
     9f5:	8b 56 16             	mov    dx,WORD PTR [bp+0x16]
     9f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     9fb:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
     9ff:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
     a03:	8b 46 10             	mov    ax,WORD PTR [bp+0x10]
     a06:	8b 56 12             	mov    dx,WORD PTR [bp+0x12]
     a09:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
     a0d:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
     a11:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     a14:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
     a17:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
     a1b:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
     a1f:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     a23:	74 07                	je     0xa2c
     a25:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     a29:	83 c4 06             	add    sp,0x6
     a2c:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     a2f:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     a32:	c9                   	leave
     a33:	ca 12 00             	retf   0x12
     a36:	55                   	push   bp
     a37:	89 e5                	mov    bp,sp
     a39:	ff 76 10             	push   WORD PTR [bp+0x10]
     a3c:	ff 76 0e             	push   WORD PTR [bp+0xe]
     a3f:	ff 76 0c             	push   WORD PTR [bp+0xc]
     a42:	ff 76 0a             	push   WORD PTR [bp+0xa]
     a45:	ff 76 08             	push   WORD PTR [bp+0x8]
     a48:	ff 76 06             	push   WORD PTR [bp+0x6]
     a4b:	b0 01                	mov    al,0x1
     a4d:	50                   	push   ax
     a4e:	b8 d7 09             	mov    ax,0x9d7
     a51:	ba 59 0a             	mov    dx,0xa59
     a54:	52                   	push   dx
     a55:	50                   	push   ax
     a56:	9a e1 09 66 0a       	call   0xa66:0x9e1
     a5b:	52                   	push   dx
     a5c:	50                   	push   ax
     a5d:	c4 3e 0a 17          	les    di,DWORD PTR ds:0x170a
     a61:	06                   	push   es
     a62:	57                   	push   di
     a63:	9a 2b 0c 70 0a       	call   0xa70:0xc2b
     a68:	c9                   	leave
     a69:	ca 0c 00             	retf   0xc
     a6c:	00 00                	add    BYTE PTR [bx+si],al
     a6e:	8e 0b                	mov    cs,WORD PTR [bp+di]
     a70:	76 0a                	jbe    0xa7c
     a72:	00 00                	add    BYTE PTR [bx+si],al
     a74:	a5                   	movs   WORD PTR es:[di],WORD PTR ds:[si]
     a75:	0b d5                	or     dx,bp
     a77:	0a c8                	or     cl,al
     a79:	54                   	push   sp
     a7a:	01 00                	add    WORD PTR [bx+si],ax
     a7c:	8d 7e b4             	lea    di,[bp-0x4c]
     a7f:	16                   	push   ss
     a80:	57                   	push   di
     a81:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     a84:	06                   	push   es
     a85:	57                   	push   di
     a86:	6a 3f                	push   0x3f
     a88:	9a 6a 0d cc 0a       	call   0xacc:0xd6a
     a8d:	ff 36 8c 18          	push   WORD PTR ds:0x188c
     a91:	8d 7e b4             	lea    di,[bp-0x4c]
     a94:	16                   	push   ss
     a95:	57                   	push   di
     a96:	6a 00                	push   0x0
     a98:	6a 0a                	push   0xa
     a9a:	9a ff ff 00 00       	call   0x0:0xffff
     a9f:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
     aa2:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
     aa6:	75 3d                	jne    0xae5
     aa8:	8d be ac fe          	lea    di,[bp-0x154]
     aac:	16                   	push   ss
     aad:	57                   	push   di
     aae:	68 09 f0             	push   0xf009
     ab1:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     ab4:	89 f8                	mov    ax,di
     ab6:	8c c2                	mov    dx,es
     ab8:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
     abb:	89 56 ae             	mov    WORD PTR [bp-0x52],dx
     abe:	c6 46 b0 04          	mov    BYTE PTR [bp-0x50],0x4
     ac2:	8d 7e ac             	lea    di,[bp-0x54]
     ac5:	16                   	push   ss
     ac6:	57                   	push   di
     ac7:	6a 00                	push   0x0
     ac9:	9a 50 09 dc 0a       	call   0xadc:0x950
     ace:	b0 01                	mov    al,0x1
     ad0:	50                   	push   ax
     ad1:	b8 ea 01             	mov    ax,0x1ea
     ad4:	ba 27 0b             	mov    dx,0xb27
     ad7:	52                   	push   dx
     ad8:	50                   	push   ax
     ad9:	9a e6 28 1e 0b       	call   0xb1e:0x28e6
     ade:	52                   	push   dx
     adf:	50                   	push   ax
     ae0:	9a 99 13 35 0b       	call   0xb35:0x1399
     ae5:	ff 36 8c 18          	push   WORD PTR ds:0x188c
     ae9:	ff 76 fa             	push   WORD PTR [bp-0x6]
     aec:	9a ff ff 00 00       	call   0x0:0xffff
     af1:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
     af4:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
     af8:	75 3d                	jne    0xb37
     afa:	8d be ac fe          	lea    di,[bp-0x154]
     afe:	16                   	push   ss
     aff:	57                   	push   di
     b00:	68 09 f0             	push   0xf009
     b03:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
     b06:	89 f8                	mov    ax,di
     b08:	8c c2                	mov    dx,es
     b0a:	89 46 ac             	mov    WORD PTR [bp-0x54],ax
     b0d:	89 56 ae             	mov    WORD PTR [bp-0x52],dx
     b10:	c6 46 b0 04          	mov    BYTE PTR [bp-0x50],0x4
     b14:	8d 7e ac             	lea    di,[bp-0x54]
     b17:	16                   	push   ss
     b18:	57                   	push   di
     b19:	6a 00                	push   0x0
     b1b:	9a 50 09 2e 0b       	call   0xb2e:0x950
     b20:	b0 01                	mov    al,0x1
     b22:	50                   	push   ax
     b23:	b8 ea 01             	mov    ax,0x1ea
     b26:	ba 4f 0b             	mov    dx,0xb4f
     b29:	52                   	push   dx
     b2a:	50                   	push   ax
     b2b:	9a e6 28 f2 0b       	call   0xbf2:0x28e6
     b30:	52                   	push   dx
     b31:	50                   	push   ax
     b32:	9a 99 13 96 0b       	call   0xb96:0x1399
     b37:	b8 72 0a             	mov    ax,0xa72
     b3a:	0e                   	push   cs
     b3b:	50                   	push   ax
     b3c:	55                   	push   bp
     b3d:	ff 36 58 18          	push   WORD PTR ds:0x1858
     b41:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     b45:	ff 76 f8             	push   WORD PTR [bp-0x8]
     b48:	b0 01                	mov    al,0x1
     b4a:	50                   	push   ax
     b4b:	b8 b2 04             	mov    ax,0x4b2
     b4e:	ba 56 0b             	mov    dx,0xb56
     b51:	52                   	push   dx
     b52:	50                   	push   ax
     b53:	9a 23 26 7a 0b       	call   0xb7a:0x2623
     b58:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
     b5b:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
     b5e:	b8 6c 0a             	mov    ax,0xa6c
     b61:	0e                   	push   cs
     b62:	50                   	push   ax
     b63:	55                   	push   bp
     b64:	ff 36 58 18          	push   WORD PTR ds:0x1858
     b68:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
     b6c:	ff 76 08             	push   WORD PTR [bp+0x8]
     b6f:	ff 76 06             	push   WORD PTR [bp+0x6]
     b72:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     b75:	06                   	push   es
     b76:	57                   	push   di
     b77:	9a bb 25 fb 0b       	call   0xbfb:0x25bb
     b7c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     b7f:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     b82:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     b86:	83 c4 06             	add    sp,0x6
     b89:	b8 99 0b             	mov    ax,0xb99
     b8c:	0e                   	push   cs
     b8d:	50                   	push   ax
     b8e:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
     b91:	06                   	push   es
     b92:	57                   	push   di
     b93:	9a 7f 1f 09 0c       	call   0xc09:0x1f7f
     b98:	cb                   	retf
     b99:	8f 06 58 18          	pop    WORD PTR ds:0x1858
     b9d:	83 c4 06             	add    sp,0x6
     ba0:	b8 ae 0b             	mov    ax,0xbae
     ba3:	0e                   	push   cs
     ba4:	50                   	push   ax
     ba5:	ff 76 f8             	push   WORD PTR [bp-0x8]
     ba8:	9a ec 27 00 00       	call   0x0:0x27ec
     bad:	cb                   	retf
     bae:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     bb1:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     bb4:	c9                   	leave
     bb5:	ca 08 00             	retf   0x8
     bb8:	55                   	push   bp
     bb9:	89 e5                	mov    bp,sp
     bbb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     bbe:	89 f9                	mov    cx,di
     bc0:	2b 4e 0a             	sub    cx,WORD PTR [bp+0xa]
     bc3:	83 e9 01             	sub    cx,0x1
     bc6:	76 10                	jbe    0xbd8
     bc8:	4f                   	dec    di
     bc9:	b0 0a                	mov    al,0xa
     bcb:	fd                   	std
     bcc:	f2 ae                	repnz scas al,BYTE PTR es:[di]
     bce:	fc                   	cld
     bcf:	75 07                	jne    0xbd8
     bd1:	8d 45 02             	lea    ax,[di+0x2]
     bd4:	8c c2                	mov    dx,es
     bd6:	eb 06                	jmp    0xbde
     bd8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     bdb:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
     bde:	c9                   	leave
     bdf:	ca 08 00             	retf   0x8
     be2:	c8 00 01 00          	enter  0x100,0x0
     be6:	8d be 00 ff          	lea    di,[bp-0x100]
     bea:	16                   	push   ss
     beb:	57                   	push   di
     bec:	ff 76 04             	push   WORD PTR [bp+0x4]
     bef:	9a 2b 09 02 0c       	call   0xc02:0x92b
     bf4:	b0 01                	mov    al,0x1
     bf6:	50                   	push   ax
     bf7:	b8 17 02             	mov    ax,0x217
     bfa:	ba 1a 0c             	mov    dx,0xc1a
     bfd:	52                   	push   dx
     bfe:	50                   	push   ax
     bff:	9a e6 28 b9 11       	call   0x11b9:0x28e6
     c04:	52                   	push   dx
     c05:	50                   	push   ax
     c06:	9a 99 13 25 0c       	call   0xc25:0x1399
     c0b:	c9                   	leave
     c0c:	c2 02 00             	ret    0x2
     c0f:	55                   	push   bp
     c10:	89 e5                	mov    bp,sp
     c12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c15:	06                   	push   es
     c16:	57                   	push   di
     c17:	9a 75 0c 82 0c       	call   0xc82:0xc75
     c1c:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
     c20:	74 05                	je     0xc27
     c22:	9a 0f 20 f5 0c       	call   0xcf5:0x200f
     c27:	c9                   	leave
     c28:	ca 06 00             	retf   0x6
     c2b:	c8 02 00 00          	enter  0x2,0x0
     c2f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c32:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     c36:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     c39:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     c3c:	26 3b 45 0a          	cmp    ax,WORD PTR es:[di+0xa]
     c40:	75 09                	jne    0xc4b
     c42:	06                   	push   es
     c43:	57                   	push   di
     c44:	26 c4 3d             	les    di,DWORD PTR es:[di]
     c47:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
     c4b:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
     c4e:	8b 5e 0c             	mov    bx,WORD PTR [bp+0xc]
     c51:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     c54:	c1 e0 02             	shl    ax,0x2
     c57:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c5a:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     c5e:	03 f8                	add    di,ax
     c60:	26 89 0d             	mov    WORD PTR es:[di],cx
     c63:	26 89 5d 02          	mov    WORD PTR es:[di+0x2],bx
     c67:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c6a:	26 ff 45 08          	inc    WORD PTR es:[di+0x8]
     c6e:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     c71:	c9                   	leave
     c72:	ca 08 00             	retf   0x8
     c75:	55                   	push   bp
     c76:	89 e5                	mov    bp,sp
     c78:	6a 00                	push   0x0
     c7a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c7d:	06                   	push   es
     c7e:	57                   	push   di
     c7f:	9a 8b 10 8e 0c       	call   0xc8e:0x108b
     c84:	6a 00                	push   0x0
     c86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     c89:	06                   	push   es
     c8a:	57                   	push   di
     c8b:	9a d8 0f 52 0e       	call   0xe52:0xfd8
     c90:	c9                   	leave
     c91:	ca 04 00             	retf   0x4
     c94:	55                   	push   bp
     c95:	89 e5                	mov    bp,sp
     c97:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
     c9b:	7c 0c                	jl     0xca9
     c9d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     ca0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ca3:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     ca7:	7c 0b                	jl     0xcb4
     ca9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cac:	06                   	push   es
     cad:	57                   	push   di
     cae:	26 c4 3d             	les    di,DWORD PTR es:[di]
     cb1:	26 ff 1d             	call   DWORD PTR es:[di]
     cb4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cb7:	26 ff 4d 08          	dec    WORD PTR es:[di+0x8]
     cbb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     cbe:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     cc2:	7d 33                	jge    0xcf7
     cc4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     cc7:	40                   	inc    ax
     cc8:	c1 e0 02             	shl    ax,0x2
     ccb:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     ccf:	03 f8                	add    di,ax
     cd1:	06                   	push   es
     cd2:	57                   	push   di
     cd3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     cd6:	c1 e0 02             	shl    ax,0x2
     cd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     cdc:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     ce0:	03 f8                	add    di,ax
     ce2:	06                   	push   es
     ce3:	57                   	push   di
     ce4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ce7:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     ceb:	2b 46 0a             	sub    ax,WORD PTR [bp+0xa]
     cee:	c1 e0 02             	shl    ax,0x2
     cf1:	50                   	push   ax
     cf2:	9a c1 1e 1a 0f       	call   0xf1a:0x1ec1
     cf7:	c9                   	leave
     cf8:	ca 06 00             	retf   0x6
     cfb:	55                   	push   bp
     cfc:	89 e5                	mov    bp,sp
     cfe:	68 0b f0             	push   0xf00b
     d01:	e8 de fe             	call   0xbe2
     d04:	c9                   	leave
     d05:	ca 04 00             	retf   0x4
     d08:	c8 04 00 00          	enter  0x4,0x0
     d0c:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
     d10:	7c 1b                	jl     0xd2d
     d12:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     d15:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d18:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     d1c:	7d 0f                	jge    0xd2d
     d1e:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
     d22:	7c 09                	jl     0xd2d
     d24:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     d27:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     d2b:	7c 0b                	jl     0xd38
     d2d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d30:	06                   	push   es
     d31:	57                   	push   di
     d32:	26 c4 3d             	les    di,DWORD PTR es:[di]
     d35:	26 ff 1d             	call   DWORD PTR es:[di]
     d38:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     d3b:	c1 e0 02             	shl    ax,0x2
     d3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d41:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     d45:	03 f8                	add    di,ax
     d47:	26 8b 05             	mov    ax,WORD PTR es:[di]
     d4a:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     d4e:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     d51:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     d54:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     d57:	c1 e0 02             	shl    ax,0x2
     d5a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d5d:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     d61:	03 f8                	add    di,ax
     d63:	26 8b 0d             	mov    cx,WORD PTR es:[di]
     d66:	26 8b 5d 02          	mov    bx,WORD PTR es:[di+0x2]
     d6a:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
     d6d:	c1 e0 02             	shl    ax,0x2
     d70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d73:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     d77:	03 f8                	add    di,ax
     d79:	26 89 0d             	mov    WORD PTR es:[di],cx
     d7c:	26 89 5d 02          	mov    WORD PTR es:[di+0x2],bx
     d80:	8b 4e fc             	mov    cx,WORD PTR [bp-0x4]
     d83:	8b 5e fe             	mov    bx,WORD PTR [bp-0x2]
     d86:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     d89:	c1 e0 02             	shl    ax,0x2
     d8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     d8f:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     d93:	03 f8                	add    di,ax
     d95:	26 89 0d             	mov    WORD PTR es:[di],cx
     d98:	26 89 5d 02          	mov    WORD PTR es:[di+0x2],bx
     d9c:	c9                   	leave
     d9d:	ca 08 00             	retf   0x8
     da0:	c8 04 00 00          	enter  0x4,0x0
     da4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     da7:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     dab:	26 3b 45 0a          	cmp    ax,WORD PTR es:[di+0xa]
     daf:	75 09                	jne    0xdba
     db1:	06                   	push   es
     db2:	57                   	push   di
     db3:	26 c4 3d             	les    di,DWORD PTR es:[di]
     db6:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
     dba:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
     dbd:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
     dc0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     dc3:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     dc6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     dc9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     dcc:	c9                   	leave
     dcd:	ca 04 00             	retf   0x4
     dd0:	c8 04 00 00          	enter  0x4,0x0
     dd4:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
     dd8:	7c 0c                	jl     0xde6
     dda:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     ddd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     de0:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     de4:	7c 0b                	jl     0xdf1
     de6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     de9:	06                   	push   es
     dea:	57                   	push   di
     deb:	26 c4 3d             	les    di,DWORD PTR es:[di]
     dee:	26 ff 1d             	call   DWORD PTR es:[di]
     df1:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     df4:	c1 e0 02             	shl    ax,0x2
     df7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     dfa:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     dfe:	03 f8                	add    di,ax
     e00:	26 8b 05             	mov    ax,WORD PTR es:[di]
     e03:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     e07:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     e0a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     e0d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     e10:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     e13:	c9                   	leave
     e14:	ca 06 00             	retf   0x6
     e17:	c8 02 00 00          	enter  0x2,0x0
     e1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e1e:	26 83 7d 0a 08       	cmp    WORD PTR es:[di+0xa],0x8
     e23:	7e 07                	jle    0xe2c
     e25:	c7 46 fe 10 00       	mov    WORD PTR [bp-0x2],0x10
     e2a:	eb 16                	jmp    0xe42
     e2c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e2f:	26 83 7d 0a 04       	cmp    WORD PTR es:[di+0xa],0x4
     e34:	7e 07                	jle    0xe3d
     e36:	c7 46 fe 08 00       	mov    WORD PTR [bp-0x2],0x8
     e3b:	eb 05                	jmp    0xe42
     e3d:	c7 46 fe 04 00       	mov    WORD PTR [bp-0x2],0x4
     e42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e45:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
     e49:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
     e4c:	50                   	push   ax
     e4d:	06                   	push   es
     e4e:	57                   	push   di
     e4f:	9a d8 0f 55 0f       	call   0xf55:0xfd8
     e54:	c9                   	leave
     e55:	ca 04 00             	retf   0x4
     e58:	c8 02 00 00          	enter  0x2,0x0
     e5c:	31 c0                	xor    ax,ax
     e5e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     e61:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     e64:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e67:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     e6b:	7d 22                	jge    0xe8f
     e6d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     e70:	c1 e0 02             	shl    ax,0x2
     e73:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     e77:	03 f8                	add    di,ax
     e79:	26 8b 05             	mov    ax,WORD PTR es:[di]
     e7c:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
     e80:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
     e83:	75 05                	jne    0xe8a
     e85:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
     e88:	74 05                	je     0xe8f
     e8a:	ff 46 fe             	inc    WORD PTR [bp-0x2]
     e8d:	eb d2                	jmp    0xe61
     e8f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     e92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     e95:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     e99:	75 05                	jne    0xea0
     e9b:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
     ea0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     ea3:	c9                   	leave
     ea4:	ca 08 00             	retf   0x8
     ea7:	55                   	push   bp
     ea8:	89 e5                	mov    bp,sp
     eaa:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
     eae:	7c 0c                	jl     0xebc
     eb0:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     eb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eb6:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     eba:	7e 0b                	jle    0xec7
     ebc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ebf:	06                   	push   es
     ec0:	57                   	push   di
     ec1:	26 c4 3d             	les    di,DWORD PTR es:[di]
     ec4:	26 ff 1d             	call   DWORD PTR es:[di]
     ec7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     eca:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     ece:	26 3b 45 0a          	cmp    ax,WORD PTR es:[di+0xa]
     ed2:	75 09                	jne    0xedd
     ed4:	06                   	push   es
     ed5:	57                   	push   di
     ed6:	26 c4 3d             	les    di,DWORD PTR es:[di]
     ed9:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
     edd:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     ee0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ee3:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     ee7:	7d 33                	jge    0xf1c
     ee9:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     eec:	c1 e0 02             	shl    ax,0x2
     eef:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     ef3:	03 f8                	add    di,ax
     ef5:	06                   	push   es
     ef6:	57                   	push   di
     ef7:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     efa:	40                   	inc    ax
     efb:	c1 e0 02             	shl    ax,0x2
     efe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f01:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     f05:	03 f8                	add    di,ax
     f07:	06                   	push   es
     f08:	57                   	push   di
     f09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f0c:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     f10:	2b 46 0e             	sub    ax,WORD PTR [bp+0xe]
     f13:	c1 e0 02             	shl    ax,0x2
     f16:	50                   	push   ax
     f17:	9a c1 1e 23 10       	call   0x1023:0x1ec1
     f1c:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
     f1f:	8b 5e 0c             	mov    bx,WORD PTR [bp+0xc]
     f22:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     f25:	c1 e0 02             	shl    ax,0x2
     f28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f2b:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     f2f:	03 f8                	add    di,ax
     f31:	26 89 0d             	mov    WORD PTR es:[di],cx
     f34:	26 89 5d 02          	mov    WORD PTR es:[di+0x2],bx
     f38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f3b:	26 ff 45 08          	inc    WORD PTR es:[di+0x8]
     f3f:	c9                   	leave
     f40:	ca 0a 00             	retf   0xa
     f43:	c8 04 00 00          	enter  0x4,0x0
     f47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f4a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
     f4e:	48                   	dec    ax
     f4f:	50                   	push   ax
     f50:	06                   	push   es
     f51:	57                   	push   di
     f52:	9a d0 0d b9 0f       	call   0xfb9:0xdd0
     f57:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
     f5a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
     f5d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
     f60:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
     f63:	c9                   	leave
     f64:	ca 04 00             	retf   0x4
     f67:	55                   	push   bp
     f68:	89 e5                	mov    bp,sp
     f6a:	83 7e 0e 00          	cmp    WORD PTR [bp+0xe],0x0
     f6e:	7c 0c                	jl     0xf7c
     f70:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     f73:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f76:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     f7a:	7c 0b                	jl     0xf87
     f7c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f7f:	06                   	push   es
     f80:	57                   	push   di
     f81:	26 c4 3d             	les    di,DWORD PTR es:[di]
     f84:	26 ff 1d             	call   DWORD PTR es:[di]
     f87:	8b 4e 0a             	mov    cx,WORD PTR [bp+0xa]
     f8a:	8b 5e 0c             	mov    bx,WORD PTR [bp+0xc]
     f8d:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
     f90:	c1 e0 02             	shl    ax,0x2
     f93:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     f96:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
     f9a:	03 f8                	add    di,ax
     f9c:	26 89 0d             	mov    WORD PTR es:[di],cx
     f9f:	26 89 5d 02          	mov    WORD PTR es:[di+0x2],bx
     fa3:	c9                   	leave
     fa4:	ca 0a 00             	retf   0xa
     fa7:	c8 02 00 00          	enter  0x2,0x0
     fab:	ff 76 0c             	push   WORD PTR [bp+0xc]
     fae:	ff 76 0a             	push   WORD PTR [bp+0xa]
     fb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fb4:	06                   	push   es
     fb5:	57                   	push   di
     fb6:	9a 58 0e cf 0f       	call   0xfcf:0xe58
     fbb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
     fbe:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
     fc2:	74 0d                	je     0xfd1
     fc4:	ff 76 fe             	push   WORD PTR [bp-0x2]
     fc7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fca:	06                   	push   es
     fcb:	57                   	push   di
     fcc:	9a 94 0c ba 10       	call   0x10ba:0xc94
     fd1:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
     fd4:	c9                   	leave
     fd5:	ca 08 00             	retf   0x8
     fd8:	c8 04 00 00          	enter  0x4,0x0
     fdc:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     fdf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     fe2:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
     fe6:	7c 07                	jl     0xfef
     fe8:	81 7e 0a fc 3f       	cmp    WORD PTR [bp+0xa],0x3ffc
     fed:	7e 0b                	jle    0xffa
     fef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
     ff2:	06                   	push   es
     ff3:	57                   	push   di
     ff4:	26 c4 3d             	les    di,DWORD PTR es:[di]
     ff7:	26 ff 1d             	call   DWORD PTR es:[di]
     ffa:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
     ffd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1000:	26 3b 45 0a          	cmp    ax,WORD PTR es:[di+0xa]
    1004:	75 03                	jne    0x1009
    1006:	e9 7e 00             	jmp    0x1087
    1009:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    100d:	75 0a                	jne    0x1019
    100f:	31 c0                	xor    ax,ax
    1011:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1014:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1017:	eb 37                	jmp    0x1050
    1019:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    101c:	c1 e0 02             	shl    ax,0x2
    101f:	50                   	push   ax
    1020:	9a 82 01 4e 10       	call   0x104e:0x182
    1025:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1028:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    102b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    102e:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    1033:	74 1b                	je     0x1050
    1035:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    1039:	06                   	push   es
    103a:	57                   	push   di
    103b:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    103e:	06                   	push   es
    103f:	57                   	push   di
    1040:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1043:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1047:	c1 e0 02             	shl    ax,0x2
    104a:	50                   	push   ax
    104b:	9a c1 1e 6d 10       	call   0x106d:0x1ec1
    1050:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1053:	26 83 7d 0a 00       	cmp    WORD PTR es:[di+0xa],0x0
    1058:	74 15                	je     0x106f
    105a:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    105e:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    1062:	26 8b 45 0a          	mov    ax,WORD PTR es:[di+0xa]
    1066:	c1 e0 02             	shl    ax,0x2
    1069:	50                   	push   ax
    106a:	9a 9c 01 ea 10       	call   0x10ea:0x19c
    106f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1072:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1075:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1078:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    107c:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    1080:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1083:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    1087:	c9                   	leave
    1088:	ca 06 00             	retf   0x6
    108b:	55                   	push   bp
    108c:	89 e5                	mov    bp,sp
    108e:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    1092:	7c 07                	jl     0x109b
    1094:	81 7e 0a fc 3f       	cmp    WORD PTR [bp+0xa],0x3ffc
    1099:	7e 0b                	jle    0x10a6
    109b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    109e:	06                   	push   es
    109f:	57                   	push   di
    10a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    10a3:	26 ff 1d             	call   DWORD PTR es:[di]
    10a6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10ac:	26 3b 45 0a          	cmp    ax,WORD PTR es:[di+0xa]
    10b0:	7e 0a                	jle    0x10bc
    10b2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    10b5:	06                   	push   es
    10b6:	57                   	push   di
    10b7:	9a d8 0f 24 11       	call   0x1124:0xfd8
    10bc:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10c2:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    10c6:	7e 24                	jle    0x10ec
    10c8:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    10cc:	c1 e0 02             	shl    ax,0x2
    10cf:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    10d3:	03 f8                	add    di,ax
    10d5:	06                   	push   es
    10d6:	57                   	push   di
    10d7:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10da:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10dd:	26 2b 45 08          	sub    ax,WORD PTR es:[di+0x8]
    10e1:	c1 e0 02             	shl    ax,0x2
    10e4:	50                   	push   ax
    10e5:	6a 00                	push   0x0
    10e7:	9a e5 1e 4b 11       	call   0x114b:0x1ee5
    10ec:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    10ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    10f2:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    10f6:	c9                   	leave
    10f7:	ca 06 00             	retf   0x6
    10fa:	55                   	push   bp
    10fb:	89 e5                	mov    bp,sp
    10fd:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1100:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1103:	74 13                	je     0x1118
    1105:	ff 76 08             	push   WORD PTR [bp+0x8]
    1108:	ff 76 06             	push   WORD PTR [bp+0x6]
    110b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    110e:	06                   	push   es
    110f:	57                   	push   di
    1110:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1113:	26 ff 1d             	call   DWORD PTR es:[di]
    1116:	eb 0e                	jmp    0x1126
    1118:	6a 00                	push   0x0
    111a:	6a 00                	push   0x0
    111c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    111f:	06                   	push   es
    1120:	57                   	push   di
    1121:	9a 2e 11 de 11       	call   0x11de:0x112e
    1126:	c9                   	leave
    1127:	ca 08 00             	retf   0x8
    112a:	03 6e 69             	add    bp,WORD PTR [bp+0x69]
    112d:	6c                   	ins    BYTE PTR es:[di],dx
    112e:	c8 30 01 00          	enter  0x130,0x0
    1132:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1135:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    1138:	74 21                	je     0x115b
    113a:	8d be e0 fe          	lea    di,[bp-0x120]
    113e:	16                   	push   ss
    113f:	57                   	push   di
    1140:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1143:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1146:	06                   	push   es
    1147:	57                   	push   di
    1148:	9a ed 20 57 11       	call   0x1157:0x20ed
    114d:	8d 7e e0             	lea    di,[bp-0x20]
    1150:	16                   	push   ss
    1151:	57                   	push   di
    1152:	6a 1f                	push   0x1f
    1154:	9a e7 17 6a 11       	call   0x116a:0x17e7
    1159:	eb 11                	jmp    0x116c
    115b:	bf 2a 11             	mov    di,0x112a
    115e:	0e                   	push   cs
    115f:	57                   	push   di
    1160:	8d 7e e0             	lea    di,[bp-0x20]
    1163:	16                   	push   ss
    1164:	57                   	push   di
    1165:	6a 1f                	push   0x1f
    1167:	9a e7 17 92 11       	call   0x1192:0x17e7
    116c:	68 00 f0             	push   0xf000
    116f:	8d 46 e0             	lea    ax,[bp-0x20]
    1172:	8c d2                	mov    dx,ss
    1174:	89 86 d0 fe          	mov    WORD PTR [bp-0x130],ax
    1178:	89 96 d2 fe          	mov    WORD PTR [bp-0x12e],dx
    117c:	c6 86 d4 fe 04       	mov    BYTE PTR [bp-0x12c],0x4
    1181:	8d be e0 fe          	lea    di,[bp-0x120]
    1185:	16                   	push   ss
    1186:	57                   	push   di
    1187:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    118a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    118d:	06                   	push   es
    118e:	57                   	push   di
    118f:	9a ed 20 c7 11       	call   0x11c7:0x20ed
    1194:	83 c4 04             	add    sp,0x4
    1197:	8d 86 e0 fe          	lea    ax,[bp-0x120]
    119b:	8c d2                	mov    dx,ss
    119d:	89 86 d8 fe          	mov    WORD PTR [bp-0x128],ax
    11a1:	89 96 da fe          	mov    WORD PTR [bp-0x126],dx
    11a5:	c6 86 dc fe 04       	mov    BYTE PTR [bp-0x124],0x4
    11aa:	8d be d0 fe          	lea    di,[bp-0x130]
    11ae:	16                   	push   ss
    11af:	57                   	push   di
    11b0:	6a 01                	push   0x1
    11b2:	b0 01                	mov    al,0x1
    11b4:	50                   	push   ax
    11b5:	b8 ba 02             	mov    ax,0x2ba
    11b8:	ba c0 11             	mov    dx,0x11c0
    11bb:	52                   	push   dx
    11bc:	50                   	push   ax
    11bd:	9a 6a 29 c5 15       	call   0x15c5:0x296a
    11c2:	52                   	push   dx
    11c3:	50                   	push   ax
    11c4:	9a 99 13 5c 13       	call   0x135c:0x1399
    11c9:	c9                   	leave
    11ca:	ca 08 00             	retf   0x8
    11cd:	55                   	push   bp
    11ce:	89 e5                	mov    bp,sp
    11d0:	ff 76 08             	push   WORD PTR [bp+0x8]
    11d3:	ff 76 06             	push   WORD PTR [bp+0x6]
    11d6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    11d9:	06                   	push   es
    11da:	57                   	push   di
    11db:	9a 2e 11 b0 12       	call   0x12b0:0x112e
    11e0:	c9                   	leave
    11e1:	ca 08 00             	retf   0x8
    11e4:	55                   	push   bp
    11e5:	89 e5                	mov    bp,sp
    11e7:	c9                   	leave
    11e8:	ca 08 00             	retf   0x8
    11eb:	55                   	push   bp
    11ec:	89 e5                	mov    bp,sp
    11ee:	1e                   	push   ds
    11ef:	c5 76 0a             	lds    si,DWORD PTR [bp+0xa]
    11f2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    11f5:	31 db                	xor    bx,bx
    11f7:	fc                   	cld
    11f8:	ac                   	lods   al,BYTE PTR ds:[si]
    11f9:	3c 20                	cmp    al,0x20
    11fb:	72 0c                	jb     0x1209
    11fd:	81 fb ff 00          	cmp    bx,0xff
    1201:	74 f5                	je     0x11f8
    1203:	43                   	inc    bx
    1204:	26 88 01             	mov    BYTE PTR es:[bx+di],al
    1207:	eb ef                	jmp    0x11f8
    1209:	08 c0                	or     al,al
    120b:	74 11                	je     0x121e
    120d:	3c 1a                	cmp    al,0x1a
    120f:	74 0d                	je     0x121e
    1211:	3c 0a                	cmp    al,0xa
    1213:	74 0a                	je     0x121f
    1215:	3c 0d                	cmp    al,0xd
    1217:	75 e4                	jne    0x11fd
    1219:	ac                   	lods   al,BYTE PTR ds:[si]
    121a:	3c 0a                	cmp    al,0xa
    121c:	74 01                	je     0x121f
    121e:	4e                   	dec    si
    121f:	26 88 1d             	mov    BYTE PTR es:[di],bl
    1222:	89 f0                	mov    ax,si
    1224:	8c da                	mov    dx,ds
    1226:	1f                   	pop    ds
    1227:	c9                   	leave
    1228:	c2 0a 00             	ret    0xa
    122b:	55                   	push   bp
    122c:	89 e5                	mov    bp,sp
    122e:	1e                   	push   ds
    122f:	c5 76 04             	lds    si,DWORD PTR [bp+0x4]
    1232:	c4 7e 08             	les    di,DWORD PTR [bp+0x8]
    1235:	fc                   	cld
    1236:	ac                   	lods   al,BYTE PTR ds:[si]
    1237:	88 c1                	mov    cl,al
    1239:	30 ed                	xor    ch,ch
    123b:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    123d:	b8 0d 0a             	mov    ax,0xa0d
    1240:	ab                   	stos   WORD PTR es:[di],ax
    1241:	89 f8                	mov    ax,di
    1243:	8c c2                	mov    dx,es
    1245:	1f                   	pop    ds
    1246:	c9                   	leave
    1247:	c2 08 00             	ret    0x8
    124a:	c8 02 00 00          	enter  0x2,0x0
    124e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1251:	06                   	push   es
    1252:	57                   	push   di
    1253:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1256:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    125a:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    125d:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1260:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1263:	06                   	push   es
    1264:	57                   	push   di
    1265:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1268:	06                   	push   es
    1269:	57                   	push   di
    126a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    126d:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1271:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1274:	c9                   	leave
    1275:	ca 08 00             	retf   0x8
    1278:	c8 02 00 00          	enter  0x2,0x0
    127c:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    127f:	06                   	push   es
    1280:	57                   	push   di
    1281:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1284:	06                   	push   es
    1285:	57                   	push   di
    1286:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1289:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    128d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1290:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1293:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1296:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1299:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    129c:	06                   	push   es
    129d:	57                   	push   di
    129e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    12a1:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    12a5:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    12a8:	c9                   	leave
    12a9:	ca 0c 00             	retf   0xc
    12ac:	00 00                	add    BYTE PTR [bx+si],al
    12ae:	33 13                	xor    dx,WORD PTR [bp+di]
    12b0:	be 12 c8             	mov    si,0xc812
    12b3:	04 01                	add    al,0x1
    12b5:	00 c4                	add    ah,al
    12b7:	7e 06                	jle    0x12bf
    12b9:	06                   	push   es
    12ba:	57                   	push   di
    12bb:	9a c5 13 3b 13       	call   0x133b:0x13c5
    12c0:	b8 ac 12             	mov    ax,0x12ac
    12c3:	0e                   	push   cs
    12c4:	50                   	push   ax
    12c5:	55                   	push   bp
    12c6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    12ca:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    12ce:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    12d1:	06                   	push   es
    12d2:	57                   	push   di
    12d3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    12d6:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    12da:	48                   	dec    ax
    12db:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    12de:	31 c0                	xor    ax,ax
    12e0:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    12e3:	7f 42                	jg     0x1327
    12e5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    12e8:	eb 03                	jmp    0x12ed
    12ea:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    12ed:	8d be fc fe          	lea    di,[bp-0x104]
    12f1:	16                   	push   ss
    12f2:	57                   	push   di
    12f3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    12f6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    12f9:	06                   	push   es
    12fa:	57                   	push   di
    12fb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    12fe:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1302:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1305:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1308:	06                   	push   es
    1309:	57                   	push   di
    130a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    130d:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    1311:	52                   	push   dx
    1312:	50                   	push   ax
    1313:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1316:	06                   	push   es
    1317:	57                   	push   di
    1318:	26 c4 3d             	les    di,DWORD PTR es:[di]
    131b:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    131f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1322:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1325:	75 c3                	jne    0x12ea
    1327:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    132b:	83 c4 06             	add    sp,0x6
    132e:	b8 3e 13             	mov    ax,0x133e
    1331:	0e                   	push   cs
    1332:	50                   	push   ax
    1333:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1336:	06                   	push   es
    1337:	57                   	push   di
    1338:	9a 35 14 46 13       	call   0x1346:0x1435
    133d:	cb                   	retf
    133e:	c9                   	leave
    133f:	ca 08 00             	retf   0x8
    1342:	00 00                	add    BYTE PTR [bx+si],al
    1344:	a4                   	movs   BYTE PTR es:[di],BYTE PTR ds:[si]
    1345:	13 55 13             	adc    dx,WORD PTR [di+0x13]
    1348:	55                   	push   bp
    1349:	89 e5                	mov    bp,sp
    134b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    134e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1351:	bf 2a 03             	mov    di,0x32a
    1354:	b8 6a 13             	mov    ax,0x136a
    1357:	50                   	push   ax
    1358:	57                   	push   di
    1359:	9a 55 22 7a 14       	call   0x147a:0x2255
    135e:	08 c0                	or     al,al
    1360:	74 4f                	je     0x13b1
    1362:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1365:	06                   	push   es
    1366:	57                   	push   di
    1367:	9a c5 13 ac 13       	call   0x13ac:0x13c5
    136c:	b8 42 13             	mov    ax,0x1342
    136f:	0e                   	push   cs
    1370:	50                   	push   ax
    1371:	55                   	push   bp
    1372:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1376:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    137a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    137d:	06                   	push   es
    137e:	57                   	push   di
    137f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1382:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    1386:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1389:	ff 76 0a             	push   WORD PTR [bp+0xa]
    138c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    138f:	06                   	push   es
    1390:	57                   	push   di
    1391:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1394:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    1398:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    139c:	83 c4 06             	add    sp,0x6
    139f:	b8 af 13             	mov    ax,0x13af
    13a2:	0e                   	push   cs
    13a3:	50                   	push   ax
    13a4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13a7:	06                   	push   es
    13a8:	57                   	push   di
    13a9:	9a 35 14 bf 13       	call   0x13bf:0x1435
    13ae:	cb                   	retf
    13af:	eb 10                	jmp    0x13c1
    13b1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    13b4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    13b7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13ba:	06                   	push   es
    13bb:	57                   	push   di
    13bc:	9a fa 10 01 14       	call   0x1401:0x10fa
    13c1:	c9                   	leave
    13c2:	ca 08 00             	retf   0x8
    13c5:	55                   	push   bp
    13c6:	89 e5                	mov    bp,sp
    13c8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13cb:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    13d0:	75 0b                	jne    0x13dd
    13d2:	6a 01                	push   0x1
    13d4:	06                   	push   es
    13d5:	57                   	push   di
    13d6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    13d9:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    13dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13e0:	26 ff 45 04          	inc    WORD PTR es:[di+0x4]
    13e4:	c9                   	leave
    13e5:	ca 04 00             	retf   0x4
    13e8:	07                   	pop    es
    13e9:	53                   	push   bx
    13ea:	74 72                	je     0x145e
    13ec:	69 6e 67 73 55       	imul   bp,WORD PTR [bp+0x67],0x5573
    13f1:	89 e5                	mov    bp,sp
    13f3:	bf e8 13             	mov    di,0x13e8
    13f6:	0e                   	push   cs
    13f7:	57                   	push   di
    13f8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    13fb:	06                   	push   es
    13fc:	57                   	push   di
    13fd:	bf df 19             	mov    di,0x19df
    1400:	b8 0e 14             	mov    ax,0x140e
    1403:	50                   	push   ax
    1404:	57                   	push   di
    1405:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1408:	06                   	push   es
    1409:	57                   	push   di
    140a:	bf 3c 1c             	mov    di,0x1c3c
    140d:	b8 2e 15             	mov    ax,0x152e
    1410:	50                   	push   ax
    1411:	57                   	push   di
    1412:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1415:	06                   	push   es
    1416:	57                   	push   di
    1417:	26 c4 3d             	les    di,DWORD PTR es:[di]
    141a:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    141e:	09 c0                	or     ax,ax
    1420:	b0 00                	mov    al,0x0
    1422:	7e 01                	jle    0x1425
    1424:	40                   	inc    ax
    1425:	50                   	push   ax
    1426:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1429:	06                   	push   es
    142a:	57                   	push   di
    142b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    142e:	26 ff 1d             	call   DWORD PTR es:[di]
    1431:	c9                   	leave
    1432:	ca 08 00             	retf   0x8
    1435:	55                   	push   bp
    1436:	89 e5                	mov    bp,sp
    1438:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    143b:	26 ff 4d 04          	dec    WORD PTR es:[di+0x4]
    143f:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    1444:	75 0b                	jne    0x1451
    1446:	6a 00                	push   0x0
    1448:	06                   	push   es
    1449:	57                   	push   di
    144a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    144d:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    1451:	c9                   	leave
    1452:	ca 04 00             	retf   0x4
    1455:	c8 04 02 00          	enter  0x204,0x0
    1459:	8d be fc fd          	lea    di,[bp-0x204]
    145d:	16                   	push   ss
    145e:	57                   	push   di
    145f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1462:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1465:	06                   	push   es
    1466:	57                   	push   di
    1467:	26 c4 3d             	les    di,DWORD PTR es:[di]
    146a:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    146e:	8d be fc fe          	lea    di,[bp-0x104]
    1472:	16                   	push   ss
    1473:	57                   	push   di
    1474:	68 ff 00             	push   0xff
    1477:	9a e7 17 8a 15       	call   0x158a:0x17e7
    147c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    147f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1482:	06                   	push   es
    1483:	57                   	push   di
    1484:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1487:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    148b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    148e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1491:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1494:	8d be fc fd          	lea    di,[bp-0x204]
    1498:	16                   	push   ss
    1499:	57                   	push   di
    149a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    149d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14a0:	06                   	push   es
    14a1:	57                   	push   di
    14a2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14a5:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    14a9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14ac:	06                   	push   es
    14ad:	57                   	push   di
    14ae:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14b1:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    14b5:	ff 76 0c             	push   WORD PTR [bp+0xc]
    14b8:	ff 76 0a             	push   WORD PTR [bp+0xa]
    14bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14be:	06                   	push   es
    14bf:	57                   	push   di
    14c0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14c3:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    14c7:	52                   	push   dx
    14c8:	50                   	push   ax
    14c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14cc:	06                   	push   es
    14cd:	57                   	push   di
    14ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14d1:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    14d5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    14d8:	8d be fc fe          	lea    di,[bp-0x104]
    14dc:	16                   	push   ss
    14dd:	57                   	push   di
    14de:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14e1:	06                   	push   es
    14e2:	57                   	push   di
    14e3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14e6:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    14ea:	ff 76 0a             	push   WORD PTR [bp+0xa]
    14ed:	ff 76 fe             	push   WORD PTR [bp-0x2]
    14f0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    14f3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    14f6:	06                   	push   es
    14f7:	57                   	push   di
    14f8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    14fb:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    14ff:	c9                   	leave
    1500:	ca 08 00             	retf   0x8
    1503:	c8 04 00 00          	enter  0x4,0x0
    1507:	31 c0                	xor    ax,ax
    1509:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    150c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    150f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1512:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1515:	c9                   	leave
    1516:	ca 06 00             	retf   0x6
    1519:	55                   	push   bp
    151a:	89 e5                	mov    bp,sp
    151c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    151f:	06                   	push   es
    1520:	57                   	push   di
    1521:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1524:	06                   	push   es
    1525:	57                   	push   di
    1526:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1529:	06                   	push   es
    152a:	57                   	push   di
    152b:	9a 41 15 70 17       	call   0x1770:0x1541
    1530:	09 c0                	or     ax,ax
    1532:	7d 07                	jge    0x153b
    1534:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1537:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    153b:	c9                   	leave
    153c:	ca 08 00             	retf   0x8
    153f:	01 3d                	add    WORD PTR [di],di
    1541:	c8 06 03 00          	enter  0x306,0x0
    1545:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1548:	06                   	push   es
    1549:	57                   	push   di
    154a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    154d:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1551:	48                   	dec    ax
    1552:	89 86 fa fe          	mov    WORD PTR [bp-0x106],ax
    1556:	31 c0                	xor    ax,ax
    1558:	3b 86 fa fe          	cmp    ax,WORD PTR [bp-0x106]
    155c:	7e 03                	jle    0x1561
    155e:	e9 a6 00             	jmp    0x1607
    1561:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1564:	eb 03                	jmp    0x1569
    1566:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1569:	8d be fa fd          	lea    di,[bp-0x206]
    156d:	16                   	push   ss
    156e:	57                   	push   di
    156f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1572:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1575:	06                   	push   es
    1576:	57                   	push   di
    1577:	26 c4 3d             	les    di,DWORD PTR es:[di]
    157a:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    157e:	8d be fc fe          	lea    di,[bp-0x104]
    1582:	16                   	push   ss
    1583:	57                   	push   di
    1584:	68 ff 00             	push   0xff
    1587:	9a e7 17 9a 15       	call   0x159a:0x17e7
    158c:	bf 3f 15             	mov    di,0x153f
    158f:	0e                   	push   cs
    1590:	57                   	push   di
    1591:	8d be fc fe          	lea    di,[bp-0x104]
    1595:	16                   	push   ss
    1596:	57                   	push   di
    1597:	9a 78 18 bb 15       	call   0x15bb:0x1878
    159c:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    159f:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    15a3:	74 56                	je     0x15fb
    15a5:	8d be fa fd          	lea    di,[bp-0x206]
    15a9:	16                   	push   ss
    15aa:	57                   	push   di
    15ab:	8d be fc fe          	lea    di,[bp-0x104]
    15af:	16                   	push   ss
    15b0:	57                   	push   di
    15b1:	6a 01                	push   0x1
    15b3:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    15b6:	48                   	dec    ax
    15b7:	50                   	push   ax
    15b8:	9a 0b 18 ea 15       	call   0x15ea:0x180b
    15bd:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    15c0:	06                   	push   es
    15c1:	57                   	push   di
    15c2:	9a 30 07 79 16       	call   0x1679:0x730
    15c7:	09 c0                	or     ax,ax
    15c9:	75 30                	jne    0x15fb
    15cb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    15ce:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    15d1:	74 26                	je     0x15f9
    15d3:	8d be fa fc          	lea    di,[bp-0x306]
    15d7:	16                   	push   ss
    15d8:	57                   	push   di
    15d9:	8d be fc fe          	lea    di,[bp-0x104]
    15dd:	16                   	push   ss
    15de:	57                   	push   di
    15df:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    15e2:	40                   	inc    ax
    15e3:	50                   	push   ax
    15e4:	68 ff 00             	push   0xff
    15e7:	9a 0b 18 f7 15       	call   0x15f7:0x180b
    15ec:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    15ef:	06                   	push   es
    15f0:	57                   	push   di
    15f1:	68 ff 00             	push   0xff
    15f4:	9a e7 17 9a 17       	call   0x179a:0x17e7
    15f9:	eb 11                	jmp    0x160c
    15fb:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    15fe:	3b 86 fa fe          	cmp    ax,WORD PTR [bp-0x106]
    1602:	74 03                	je     0x1607
    1604:	e9 5f ff             	jmp    0x1566
    1607:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    160c:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    160f:	c9                   	leave
    1610:	ca 0c 00             	retf   0xc
    1613:	c8 14 01 00          	enter  0x114,0x0
    1617:	c7 46 fa 01 00       	mov    WORD PTR [bp-0x6],0x1
    161c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    161f:	06                   	push   es
    1620:	57                   	push   di
    1621:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1624:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1628:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    162b:	31 c0                	xor    ax,ax
    162d:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1630:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1633:	3b 46 f6             	cmp    ax,WORD PTR [bp-0xa]
    1636:	7d 3b                	jge    0x1673
    1638:	8d be ee fe          	lea    di,[bp-0x112]
    163c:	16                   	push   ss
    163d:	57                   	push   di
    163e:	ff 76 f4             	push   WORD PTR [bp-0xc]
    1641:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1644:	06                   	push   es
    1645:	57                   	push   di
    1646:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1649:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    164d:	83 c4 04             	add    sp,0x4
    1650:	8a 86 ee fe          	mov    al,BYTE PTR [bp-0x112]
    1654:	30 e4                	xor    ah,ah
    1656:	40                   	inc    ax
    1657:	40                   	inc    ax
    1658:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    165b:	b8 f0 ff             	mov    ax,0xfff0
    165e:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    1661:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    1664:	73 02                	jae    0x1668
    1666:	eb 0b                	jmp    0x1673
    1668:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    166b:	01 46 fa             	add    WORD PTR [bp-0x6],ax
    166e:	ff 46 f4             	inc    WORD PTR [bp-0xc]
    1671:	eb bd                	jmp    0x1630
    1673:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1676:	9a 8f 0e 20 17       	call   0x1720:0xe8f
    167b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    167e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1681:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1684:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1687:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    168a:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    168d:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    1690:	48                   	dec    ax
    1691:	89 46 ec             	mov    WORD PTR [bp-0x14],ax
    1694:	31 c0                	xor    ax,ax
    1696:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    1699:	7f 34                	jg     0x16cf
    169b:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    169e:	eb 03                	jmp    0x16a3
    16a0:	ff 46 f2             	inc    WORD PTR [bp-0xe]
    16a3:	ff 76 f0             	push   WORD PTR [bp-0x10]
    16a6:	ff 76 ee             	push   WORD PTR [bp-0x12]
    16a9:	8d be ec fe          	lea    di,[bp-0x114]
    16ad:	16                   	push   ss
    16ae:	57                   	push   di
    16af:	ff 76 f2             	push   WORD PTR [bp-0xe]
    16b2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16b5:	06                   	push   es
    16b6:	57                   	push   di
    16b7:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16ba:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    16be:	e8 6a fb             	call   0x122b
    16c1:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    16c4:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    16c7:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    16ca:	3b 46 ec             	cmp    ax,WORD PTR [bp-0x14]
    16cd:	75 d1                	jne    0x16a0
    16cf:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    16d2:	26 c6 05 00          	mov    BYTE PTR es:[di],0x0
    16d6:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    16d9:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    16dc:	c9                   	leave
    16dd:	ca 04 00             	retf   0x4
    16e0:	c8 04 01 00          	enter  0x104,0x0
    16e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    16e7:	06                   	push   es
    16e8:	57                   	push   di
    16e9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    16ec:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    16f0:	48                   	dec    ax
    16f1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    16f4:	31 c0                	xor    ax,ax
    16f6:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    16f9:	7f 35                	jg     0x1730
    16fb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    16fe:	eb 03                	jmp    0x1703
    1700:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1703:	8d be fc fe          	lea    di,[bp-0x104]
    1707:	16                   	push   ss
    1708:	57                   	push   di
    1709:	ff 76 fe             	push   WORD PTR [bp-0x2]
    170c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    170f:	06                   	push   es
    1710:	57                   	push   di
    1711:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1714:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1718:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    171b:	06                   	push   es
    171c:	57                   	push   di
    171d:	9a 30 07 75 18       	call   0x1875:0x730
    1722:	09 c0                	or     ax,ax
    1724:	75 02                	jne    0x1728
    1726:	eb 0d                	jmp    0x1735
    1728:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    172b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    172e:	75 d0                	jne    0x1700
    1730:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    1735:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1738:	c9                   	leave
    1739:	ca 08 00             	retf   0x8
    173c:	55                   	push   bp
    173d:	89 e5                	mov    bp,sp
    173f:	ff 76 12             	push   WORD PTR [bp+0x12]
    1742:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1745:	06                   	push   es
    1746:	57                   	push   di
    1747:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    174a:	06                   	push   es
    174b:	57                   	push   di
    174c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    174f:	26 ff 5d 44          	call   DWORD PTR es:[di+0x44]
    1753:	ff 76 12             	push   WORD PTR [bp+0x12]
    1756:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1759:	ff 76 0a             	push   WORD PTR [bp+0xa]
    175c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    175f:	06                   	push   es
    1760:	57                   	push   di
    1761:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1764:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    1768:	c9                   	leave
    1769:	ca 0e 00             	retf   0xe
    176c:	00 00                	add    BYTE PTR [bx+si],al
    176e:	fa                   	cli
    176f:	18 76 17             	sbb    BYTE PTR [bp+0x17],dh
    1772:	00 00                	add    BYTE PTR [bx+si],al
    1774:	15 19 84             	adc    ax,0x8419
    1777:	17                   	pop    ss
    1778:	c8 12 02 00          	enter  0x212,0x0
    177c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    177f:	06                   	push   es
    1780:	57                   	push   di
    1781:	9a c5 13 51 18       	call   0x1851:0x13c5
    1786:	b8 72 17             	mov    ax,0x1772
    1789:	0e                   	push   cs
    178a:	50                   	push   ax
    178b:	55                   	push   bp
    178c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1790:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1794:	68 00 10             	push   0x1000
    1797:	9a 82 01 f6 17       	call   0x17f6:0x182
    179c:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    179f:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    17a2:	b8 6c 17             	mov    ax,0x176c
    17a5:	0e                   	push   cs
    17a6:	50                   	push   ax
    17a7:	55                   	push   bp
    17a8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    17ac:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    17b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    17b3:	06                   	push   es
    17b4:	57                   	push   di
    17b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    17b8:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    17bc:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    17bf:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    17c2:	05 00 10             	add    ax,0x1000
    17c5:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    17c8:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    17cb:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    17ce:	8b 56 f4             	mov    dx,WORD PTR [bp-0xc]
    17d1:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    17d4:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    17d7:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    17da:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    17dd:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    17e0:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    17e4:	74 12                	je     0x17f8
    17e6:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    17e9:	06                   	push   es
    17ea:	57                   	push   di
    17eb:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    17ee:	06                   	push   es
    17ef:	57                   	push   di
    17f0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    17f3:	9a c1 1e 8c 18       	call   0x188c:0x1ec1
    17f8:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    17fb:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    17fe:	03 46 fe             	add    ax,WORD PTR [bp-0x2]
    1801:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    1804:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    1807:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    180a:	06                   	push   es
    180b:	57                   	push   di
    180c:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    180f:	2b 46 ee             	sub    ax,WORD PTR [bp-0x12]
    1812:	31 d2                	xor    dx,dx
    1814:	52                   	push   dx
    1815:	50                   	push   ax
    1816:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1819:	06                   	push   es
    181a:	57                   	push   di
    181b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    181e:	26 ff 1d             	call   DWORD PTR es:[di]
    1821:	8b c8                	mov    cx,ax
    1823:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    1826:	8b 56 f0             	mov    dx,WORD PTR [bp-0x10]
    1829:	03 c1                	add    ax,cx
    182b:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    182e:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    1831:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    1834:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    1837:	73 09                	jae    0x1842
    1839:	c4 7e ee             	les    di,DWORD PTR [bp-0x12]
    183c:	26 c6 05 1a          	mov    BYTE PTR es:[di],0x1a
    1840:	eb 4c                	jmp    0x188e
    1842:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1845:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1848:	ff 76 f0             	push   WORD PTR [bp-0x10]
    184b:	ff 76 ee             	push   WORD PTR [bp-0x12]
    184e:	9a b8 0b 7e 18       	call   0x187e:0xbb8
    1853:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    1856:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    1859:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    185c:	8b 56 f0             	mov    dx,WORD PTR [bp-0x10]
    185f:	3b 56 fc             	cmp    dx,WORD PTR [bp-0x4]
    1862:	75 2a                	jne    0x188e
    1864:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1867:	75 25                	jne    0x188e
    1869:	8d be ee fd          	lea    di,[bp-0x212]
    186d:	16                   	push   ss
    186e:	57                   	push   di
    186f:	68 13 f0             	push   0xf013
    1872:	9a 2b 09 85 18       	call   0x1885:0x92b
    1877:	b0 01                	mov    al,0x1
    1879:	50                   	push   ax
    187a:	b8 b1 00             	mov    ax,0xb1
    187d:	ba 1d 19             	mov    dx,0x191d
    1880:	52                   	push   dx
    1881:	50                   	push   ax
    1882:	9a e6 28 ce 1f       	call   0x1fce:0x28e6
    1887:	52                   	push   dx
    1888:	50                   	push   ax
    1889:	9a 99 13 06 19       	call   0x1906:0x1399
    188e:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1891:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    1894:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1897:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    189a:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    189d:	3b 46 ee             	cmp    ax,WORD PTR [bp-0x12]
    18a0:	73 35                	jae    0x18d7
    18a2:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    18a5:	26 80 3d 1a          	cmp    BYTE PTR es:[di],0x1a
    18a9:	74 2c                	je     0x18d7
    18ab:	ff 76 f8             	push   WORD PTR [bp-0x8]
    18ae:	ff 76 f6             	push   WORD PTR [bp-0xa]
    18b1:	8d be ee fe          	lea    di,[bp-0x112]
    18b5:	16                   	push   ss
    18b6:	57                   	push   di
    18b7:	68 ff 00             	push   0xff
    18ba:	e8 2e f9             	call   0x11eb
    18bd:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    18c0:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    18c3:	8d be ee fe          	lea    di,[bp-0x112]
    18c7:	16                   	push   ss
    18c8:	57                   	push   di
    18c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    18cc:	06                   	push   es
    18cd:	57                   	push   di
    18ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    18d1:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    18d5:	eb c3                	jmp    0x189a
    18d7:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    18da:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    18dd:	72 03                	jb     0x18e2
    18df:	e9 f5 fe             	jmp    0x17d7
    18e2:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    18e5:	26 80 3d 1a          	cmp    BYTE PTR es:[di],0x1a
    18e9:	74 03                	je     0x18ee
    18eb:	e9 e9 fe             	jmp    0x17d7
    18ee:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    18f2:	83 c4 06             	add    sp,0x6
    18f5:	b8 09 19             	mov    ax,0x1909
    18f8:	0e                   	push   cs
    18f9:	50                   	push   ax
    18fa:	ff 76 fc             	push   WORD PTR [bp-0x4]
    18fd:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1900:	68 00 10             	push   0x1000
    1903:	9a 9c 01 51 19       	call   0x1951:0x19c
    1908:	cb                   	retf
    1909:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    190d:	83 c4 06             	add    sp,0x6
    1910:	b8 20 19             	mov    ax,0x1920
    1913:	0e                   	push   cs
    1914:	50                   	push   ax
    1915:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1918:	06                   	push   es
    1919:	57                   	push   di
    191a:	9a 35 14 8e 19       	call   0x198e:0x1435
    191f:	cb                   	retf
    1920:	c9                   	leave
    1921:	ca 08 00             	retf   0x8
    1924:	c8 04 02 00          	enter  0x204,0x0
    1928:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    192b:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    192e:	74 60                	je     0x1990
    1930:	8d be fc fd          	lea    di,[bp-0x204]
    1934:	16                   	push   ss
    1935:	57                   	push   di
    1936:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1939:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    193c:	06                   	push   es
    193d:	57                   	push   di
    193e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1941:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1945:	8d be fc fe          	lea    di,[bp-0x104]
    1949:	16                   	push   ss
    194a:	57                   	push   di
    194b:	68 ff 00             	push   0xff
    194e:	9a e7 17 43 1a       	call   0x1a43:0x17e7
    1953:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1956:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1959:	06                   	push   es
    195a:	57                   	push   di
    195b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    195e:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    1962:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1965:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1968:	ff 76 0c             	push   WORD PTR [bp+0xc]
    196b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    196e:	06                   	push   es
    196f:	57                   	push   di
    1970:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1973:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1977:	ff 76 0a             	push   WORD PTR [bp+0xa]
    197a:	8d be fc fe          	lea    di,[bp-0x104]
    197e:	16                   	push   ss
    197f:	57                   	push   di
    1980:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1983:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1986:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1989:	06                   	push   es
    198a:	57                   	push   di
    198b:	9a 3c 17 d2 19       	call   0x19d2:0x173c
    1990:	c9                   	leave
    1991:	ca 08 00             	retf   0x8
    1994:	c8 04 00 00          	enter  0x4,0x0
    1998:	ff 76 0e             	push   WORD PTR [bp+0xe]
    199b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    199e:	06                   	push   es
    199f:	57                   	push   di
    19a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    19a3:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    19a7:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    19aa:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    19ad:	ff 76 0e             	push   WORD PTR [bp+0xe]
    19b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19b3:	06                   	push   es
    19b4:	57                   	push   di
    19b5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    19b8:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    19bc:	ff 76 0e             	push   WORD PTR [bp+0xe]
    19bf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19c2:	06                   	push   es
    19c3:	57                   	push   di
    19c4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    19c7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    19ca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19cd:	06                   	push   es
    19ce:	57                   	push   di
    19cf:	9a 3c 17 eb 19       	call   0x19eb:0x173c
    19d4:	c9                   	leave
    19d5:	ca 0a 00             	retf   0xa
    19d8:	55                   	push   bp
    19d9:	89 e5                	mov    bp,sp
    19db:	c9                   	leave
    19dc:	ca 0a 00             	retf   0xa
    19df:	c8 00 01 00          	enter  0x100,0x0
    19e3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19e6:	06                   	push   es
    19e7:	57                   	push   di
    19e8:	9a 84 36 01 1a       	call   0x1a01:0x3684
    19ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    19f0:	06                   	push   es
    19f1:	57                   	push   di
    19f2:	26 c4 3d             	les    di,DWORD PTR es:[di]
    19f5:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    19f9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    19fc:	06                   	push   es
    19fd:	57                   	push   di
    19fe:	9a b5 2e 15 1a       	call   0x1a15:0x2eb5
    1a03:	08 c0                	or     al,al
    1a05:	75 1e                	jne    0x1a25
    1a07:	8d be 00 ff          	lea    di,[bp-0x100]
    1a0b:	16                   	push   ss
    1a0c:	57                   	push   di
    1a0d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a10:	06                   	push   es
    1a11:	57                   	push   di
    1a12:	9a 74 3f 2d 1a       	call   0x1a2d:0x3f74
    1a17:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a1a:	06                   	push   es
    1a1b:	57                   	push   di
    1a1c:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a1f:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1a23:	eb d4                	jmp    0x19f9
    1a25:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1a28:	06                   	push   es
    1a29:	57                   	push   di
    1a2a:	9a 97 36 37 1a       	call   0x1a37:0x3697
    1a2f:	c9                   	leave
    1a30:	ca 08 00             	retf   0x8
    1a33:	00 00                	add    BYTE PTR [bx+si],al
    1a35:	05 1b a6             	add    ax,0xa61b
    1a38:	1a c8                	sbb    cl,al
    1a3a:	0c 01                	or     al,0x1
    1a3c:	00 68 00             	add    BYTE PTR [bx+si+0x0],ch
    1a3f:	10 9a 82 01          	adc    BYTE PTR [bp+si+0x182],bl
    1a43:	11 1b                	adc    WORD PTR [bp+di],bx
    1a45:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1a48:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    1a4b:	b8 33 1a             	mov    ax,0x1a33
    1a4e:	0e                   	push   cs
    1a4f:	50                   	push   ax
    1a50:	55                   	push   bp
    1a51:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1a55:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1a59:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1a5c:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    1a5f:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1a62:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    1a65:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1a68:	06                   	push   es
    1a69:	57                   	push   di
    1a6a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1a6d:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1a71:	48                   	dec    ax
    1a72:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    1a75:	31 c0                	xor    ax,ax
    1a77:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1a7a:	7f 64                	jg     0x1ae0
    1a7c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1a7f:	eb 03                	jmp    0x1a84
    1a81:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1a84:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1a87:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    1a8a:	3d 00 0f             	cmp    ax,0xf00
    1a8d:	72 25                	jb     0x1ab4
    1a8f:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1a92:	06                   	push   es
    1a93:	57                   	push   di
    1a94:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1a97:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    1a9a:	31 d2                	xor    dx,dx
    1a9c:	52                   	push   dx
    1a9d:	50                   	push   ax
    1a9e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1aa1:	06                   	push   es
    1aa2:	57                   	push   di
    1aa3:	9a 66 24 f7 1a       	call   0x1af7:0x2466
    1aa8:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    1aab:	8b 56 fc             	mov    dx,WORD PTR [bp-0x4]
    1aae:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1ab1:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    1ab4:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1ab7:	ff 76 f6             	push   WORD PTR [bp-0xa]
    1aba:	8d be f4 fe          	lea    di,[bp-0x10c]
    1abe:	16                   	push   ss
    1abf:	57                   	push   di
    1ac0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ac3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ac6:	06                   	push   es
    1ac7:	57                   	push   di
    1ac8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1acb:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1acf:	e8 59 f7             	call   0x122b
    1ad2:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1ad5:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    1ad8:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1adb:	3b 46 f4             	cmp    ax,WORD PTR [bp-0xc]
    1ade:	75 a1                	jne    0x1a81
    1ae0:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    1ae3:	06                   	push   es
    1ae4:	57                   	push   di
    1ae5:	8b 46 f6             	mov    ax,WORD PTR [bp-0xa]
    1ae8:	2b 46 fa             	sub    ax,WORD PTR [bp-0x6]
    1aeb:	31 d2                	xor    dx,dx
    1aed:	52                   	push   dx
    1aee:	50                   	push   ax
    1aef:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1af2:	06                   	push   es
    1af3:	57                   	push   di
    1af4:	9a 66 24 30 1b       	call   0x1b30:0x2466
    1af9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1afd:	83 c4 06             	add    sp,0x6
    1b00:	b8 14 1b             	mov    ax,0x1b14
    1b03:	0e                   	push   cs
    1b04:	50                   	push   ax
    1b05:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1b08:	ff 76 fa             	push   WORD PTR [bp-0x6]
    1b0b:	68 00 10             	push   0x1000
    1b0e:	9a 9c 01 69 1b       	call   0x1b69:0x19c
    1b13:	cb                   	retf
    1b14:	c9                   	leave
    1b15:	ca 08 00             	retf   0x8
    1b18:	00 01                	add    BYTE PTR [bx+di],al
    1b1a:	3d c8 02             	cmp    ax,0x2c8
    1b1d:	01 00                	add    WORD PTR [bx+si],ax
    1b1f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1b22:	06                   	push   es
    1b23:	57                   	push   di
    1b24:	6a 00                	push   0x0
    1b26:	6a 00                	push   0x0
    1b28:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b2b:	06                   	push   es
    1b2c:	57                   	push   di
    1b2d:	9a 41 15 aa 1b       	call   0x1baa:0x1541
    1b32:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b35:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b38:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    1b3c:	74 4f                	je     0x1b8d
    1b3e:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    1b42:	7d 14                	jge    0x1b58
    1b44:	bf 18 1b             	mov    di,0x1b18
    1b47:	0e                   	push   cs
    1b48:	57                   	push   di
    1b49:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b4c:	06                   	push   es
    1b4d:	57                   	push   di
    1b4e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b51:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1b55:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1b58:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b5b:	8d be fe fe          	lea    di,[bp-0x102]
    1b5f:	16                   	push   ss
    1b60:	57                   	push   di
    1b61:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1b64:	06                   	push   es
    1b65:	57                   	push   di
    1b66:	9a cd 17 73 1b       	call   0x1b73:0x17cd
    1b6b:	bf 19 1b             	mov    di,0x1b19
    1b6e:	0e                   	push   cs
    1b6f:	57                   	push   di
    1b70:	9a 4c 18 7d 1b       	call   0x1b7d:0x184c
    1b75:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1b78:	06                   	push   es
    1b79:	57                   	push   di
    1b7a:	9a 4c 18 b1 1c       	call   0x1cb1:0x184c
    1b7f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b82:	06                   	push   es
    1b83:	57                   	push   di
    1b84:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b87:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    1b8b:	eb 15                	jmp    0x1ba2
    1b8d:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    1b91:	7c 0f                	jl     0x1ba2
    1b93:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1b96:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1b99:	06                   	push   es
    1b9a:	57                   	push   di
    1b9b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1b9e:	26 ff 5d 34          	call   DWORD PTR es:[di+0x34]
    1ba2:	c9                   	leave
    1ba3:	ca 0c 00             	retf   0xc
    1ba6:	00 00                	add    BYTE PTR [bx+si],al
    1ba8:	26 1c b8             	es sbb al,0xb8
    1bab:	1b c8                	sbb    cx,ax
    1bad:	04 01                	add    al,0x1
    1baf:	00 c4                	add    ah,al
    1bb1:	7e 06                	jle    0x1bb9
    1bb3:	06                   	push   es
    1bb4:	57                   	push   di
    1bb5:	9a c5 13 2e 1c       	call   0x1c2e:0x13c5
    1bba:	b8 a6 1b             	mov    ax,0x1ba6
    1bbd:	0e                   	push   cs
    1bbe:	50                   	push   ax
    1bbf:	55                   	push   bp
    1bc0:	ff 36 58 18          	push   WORD PTR ds:0x1858
    1bc4:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    1bc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1bcb:	06                   	push   es
    1bcc:	57                   	push   di
    1bcd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1bd0:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    1bd4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    1bd7:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    1bda:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1bdd:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1be0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1be3:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1be6:	3c 00                	cmp    al,0x0
    1be8:	74 30                	je     0x1c1a
    1bea:	3c 1a                	cmp    al,0x1a
    1bec:	74 2c                	je     0x1c1a
    1bee:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1bf1:	ff 76 fc             	push   WORD PTR [bp-0x4]
    1bf4:	8d be fc fe          	lea    di,[bp-0x104]
    1bf8:	16                   	push   ss
    1bf9:	57                   	push   di
    1bfa:	68 ff 00             	push   0xff
    1bfd:	e8 eb f5             	call   0x11eb
    1c00:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c03:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1c06:	8d be fc fe          	lea    di,[bp-0x104]
    1c0a:	16                   	push   ss
    1c0b:	57                   	push   di
    1c0c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c0f:	06                   	push   es
    1c10:	57                   	push   di
    1c11:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c14:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    1c18:	eb c6                	jmp    0x1be0
    1c1a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1c1e:	83 c4 06             	add    sp,0x6
    1c21:	b8 31 1c             	mov    ax,0x1c31
    1c24:	0e                   	push   cs
    1c25:	50                   	push   ax
    1c26:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c29:	06                   	push   es
    1c2a:	57                   	push   di
    1c2b:	9a 35 14 48 1c       	call   0x1c48:0x1435
    1c30:	cb                   	retf
    1c31:	c9                   	leave
    1c32:	ca 08 00             	retf   0x8
    1c35:	55                   	push   bp
    1c36:	89 e5                	mov    bp,sp
    1c38:	c9                   	leave
    1c39:	ca 06 00             	retf   0x6
    1c3c:	c8 04 01 00          	enter  0x104,0x0
    1c40:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c43:	06                   	push   es
    1c44:	57                   	push   di
    1c45:	9a 6d 45 86 1c       	call   0x1c86:0x456d
    1c4a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c4d:	06                   	push   es
    1c4e:	57                   	push   di
    1c4f:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c52:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1c56:	48                   	dec    ax
    1c57:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1c5a:	31 c0                	xor    ax,ax
    1c5c:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1c5f:	7f 2f                	jg     0x1c90
    1c61:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1c64:	eb 03                	jmp    0x1c69
    1c66:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1c69:	8d be fc fe          	lea    di,[bp-0x104]
    1c6d:	16                   	push   ss
    1c6e:	57                   	push   di
    1c6f:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1c72:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1c75:	06                   	push   es
    1c76:	57                   	push   di
    1c77:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1c7a:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1c7e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c81:	06                   	push   es
    1c82:	57                   	push   di
    1c83:	9a 9d 4b 98 1c       	call   0x1c98:0x4b9d
    1c88:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1c8b:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1c8e:	75 d6                	jne    0x1c66
    1c90:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1c93:	06                   	push   es
    1c94:	57                   	push   di
    1c95:	9a 80 45 20 1d       	call   0x1d20:0x4580
    1c9a:	c9                   	leave
    1c9b:	ca 08 00             	retf   0x8
    1c9e:	c8 04 00 00          	enter  0x4,0x0
    1ca2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1ca5:	26 8a 05             	mov    al,BYTE PTR es:[di]
    1ca8:	30 e4                	xor    ah,ah
    1caa:	05 05 00             	add    ax,0x5
    1cad:	50                   	push   ax
    1cae:	9a 82 01 dd 1c       	call   0x1cdd:0x182
    1cb3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1cb6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    1cb9:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1cbc:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1cbf:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1cc2:	26 89 05             	mov    WORD PTR es:[di],ax
    1cc5:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    1cc9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1ccc:	06                   	push   es
    1ccd:	57                   	push   di
    1cce:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    1cd1:	81 c7 04 00          	add    di,0x4
    1cd5:	06                   	push   es
    1cd6:	57                   	push   di
    1cd7:	68 ff 00             	push   0xff
    1cda:	9a e7 17 02 1d       	call   0x1d02:0x17e7
    1cdf:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1ce2:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    1ce5:	c9                   	leave
    1ce6:	ca 08 00             	retf   0x8
    1ce9:	55                   	push   bp
    1cea:	89 e5                	mov    bp,sp
    1cec:	ff 76 08             	push   WORD PTR [bp+0x8]
    1cef:	ff 76 06             	push   WORD PTR [bp+0x6]
    1cf2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1cf5:	26 8a 45 04          	mov    al,BYTE PTR es:[di+0x4]
    1cf9:	30 e4                	xor    ah,ah
    1cfb:	05 05 00             	add    ax,0x5
    1cfe:	50                   	push   ax
    1cff:	9a 9c 01 17 1d       	call   0x1d17:0x19c
    1d04:	c9                   	leave
    1d05:	ca 04 00             	retf   0x4
    1d08:	55                   	push   bp
    1d09:	89 e5                	mov    bp,sp
    1d0b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1d0f:	74 08                	je     0x1d19
    1d11:	83 ec 08             	sub    sp,0x8
    1d14:	9a e2 1f 27 1d       	call   0x1d27:0x1fe2
    1d19:	b0 01                	mov    al,0x1
    1d1b:	50                   	push   ax
    1d1c:	b8 a3 02             	mov    ax,0x2a3
    1d1f:	ba 0e 1e             	mov    dx,0x1e0e
    1d22:	52                   	push   dx
    1d23:	50                   	push   ax
    1d24:	9a 50 1f 94 1d       	call   0x1d94:0x1f50
    1d29:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d2c:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    1d30:	26 89 55 08          	mov    WORD PTR es:[di+0x8],dx
    1d34:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1d38:	74 07                	je     0x1d41
    1d3a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    1d3e:	83 c4 06             	add    sp,0x6
    1d41:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    1d44:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    1d47:	c9                   	leave
    1d48:	ca 06 00             	retf   0x6
    1d4b:	55                   	push   bp
    1d4c:	89 e5                	mov    bp,sp
    1d4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d51:	31 c0                	xor    ax,ax
    1d53:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    1d57:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    1d5b:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    1d5f:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    1d63:	31 c0                	xor    ax,ax
    1d65:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    1d69:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    1d6d:	26 89 45 18          	mov    WORD PTR es:[di+0x18],ax
    1d71:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    1d75:	26 8b 45 06          	mov    ax,WORD PTR es:[di+0x6]
    1d79:	26 0b 45 08          	or     ax,WORD PTR es:[di+0x8]
    1d7d:	74 17                	je     0x1d96
    1d7f:	06                   	push   es
    1d80:	57                   	push   di
    1d81:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1d84:	26 ff 5d 30          	call   DWORD PTR es:[di+0x30]
    1d88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1d8b:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1d8f:	06                   	push   es
    1d90:	57                   	push   di
    1d91:	9a 7f 1f 9f 1d       	call   0x1d9f:0x1f7f
    1d96:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    1d9a:	74 05                	je     0x1da1
    1d9c:	9a 0f 20 3e 20       	call   0x203e:0x200f
    1da1:	c9                   	leave
    1da2:	ca 06 00             	retf   0x6
    1da5:	c8 02 00 00          	enter  0x2,0x0
    1da9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dac:	26 80 7d 0a 00       	cmp    BYTE PTR es:[di+0xa],0x0
    1db1:	75 0d                	jne    0x1dc0
    1db3:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1db7:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1dbb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1dbe:	eb 33                	jmp    0x1df3
    1dc0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1dc3:	06                   	push   es
    1dc4:	57                   	push   di
    1dc5:	8d 7e fe             	lea    di,[bp-0x2]
    1dc8:	16                   	push   ss
    1dc9:	57                   	push   di
    1dca:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1dcd:	06                   	push   es
    1dce:	57                   	push   di
    1dcf:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1dd2:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    1dd6:	08 c0                	or     al,al
    1dd8:	74 19                	je     0x1df3
    1dda:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ddd:	26 8a 45 0b          	mov    al,BYTE PTR es:[di+0xb]
    1de1:	3c 00                	cmp    al,0x0
    1de3:	75 04                	jne    0x1de9
    1de5:	eb 50                	jmp    0x1e37
    1de7:	eb 0a                	jmp    0x1df3
    1de9:	3c 02                	cmp    al,0x2
    1deb:	75 06                	jne    0x1df3
    1ded:	68 0d f0             	push   0xf00d
    1df0:	e8 ef ed             	call   0xbe2
    1df3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1df6:	06                   	push   es
    1df7:	57                   	push   di
    1df8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1dfb:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    1dff:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1e02:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    1e05:	06                   	push   es
    1e06:	57                   	push   di
    1e07:	6a 00                	push   0x0
    1e09:	6a 00                	push   0x0
    1e0b:	9a 9e 1c 1e 1e       	call   0x1e1e:0x1c9e
    1e10:	52                   	push   dx
    1e11:	50                   	push   ax
    1e12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e15:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1e19:	06                   	push   es
    1e1a:	57                   	push   di
    1e1b:	9a a0 0d 29 1e       	call   0x1e29:0xda0
    1e20:	89 c7                	mov    di,ax
    1e22:	8e c2                	mov    es,dx
    1e24:	06                   	push   es
    1e25:	57                   	push   di
    1e26:	9a a7 0e d1 1e       	call   0x1ed1:0xea7
    1e2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e2e:	06                   	push   es
    1e2f:	57                   	push   di
    1e30:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1e33:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    1e37:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1e3a:	c9                   	leave
    1e3b:	ca 08 00             	retf   0x8
    1e3e:	55                   	push   bp
    1e3f:	89 e5                	mov    bp,sp
    1e41:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e44:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    1e49:	75 1a                	jne    0x1e65
    1e4b:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    1e4f:	09 c0                	or     ax,ax
    1e51:	74 12                	je     0x1e65
    1e53:	ff 76 08             	push   WORD PTR [bp+0x8]
    1e56:	ff 76 06             	push   WORD PTR [bp+0x6]
    1e59:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    1e5d:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    1e61:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    1e65:	c9                   	leave
    1e66:	ca 04 00             	retf   0x4
    1e69:	55                   	push   bp
    1e6a:	89 e5                	mov    bp,sp
    1e6c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e6f:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    1e74:	75 1a                	jne    0x1e90
    1e76:	26 8b 45 16          	mov    ax,WORD PTR es:[di+0x16]
    1e7a:	09 c0                	or     ax,ax
    1e7c:	74 12                	je     0x1e90
    1e7e:	ff 76 08             	push   WORD PTR [bp+0x8]
    1e81:	ff 76 06             	push   WORD PTR [bp+0x6]
    1e84:	26 ff 75 1a          	push   WORD PTR es:[di+0x1a]
    1e88:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    1e8c:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    1e90:	c9                   	leave
    1e91:	ca 04 00             	retf   0x4
    1e94:	c8 04 00 00          	enter  0x4,0x0
    1e98:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1e9b:	06                   	push   es
    1e9c:	57                   	push   di
    1e9d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ea0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    1ea4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ea7:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1eab:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    1eaf:	48                   	dec    ax
    1eb0:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1eb3:	31 c0                	xor    ax,ax
    1eb5:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1eb8:	7f 28                	jg     0x1ee2
    1eba:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    1ebd:	eb 03                	jmp    0x1ec2
    1ebf:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    1ec2:	ff 76 fe             	push   WORD PTR [bp-0x2]
    1ec5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ec8:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1ecc:	06                   	push   es
    1ecd:	57                   	push   di
    1ece:	9a d0 0d d8 1e       	call   0x1ed8:0xdd0
    1ed3:	52                   	push   dx
    1ed4:	50                   	push   ax
    1ed5:	9a e9 1c ee 1e       	call   0x1eee:0x1ce9
    1eda:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    1edd:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    1ee0:	75 dd                	jne    0x1ebf
    1ee2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ee5:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1ee9:	06                   	push   es
    1eea:	57                   	push   di
    1eeb:	9a 75 0c 1e 1f       	call   0x1f1e:0xc75
    1ef0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ef3:	06                   	push   es
    1ef4:	57                   	push   di
    1ef5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1ef8:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    1efc:	c9                   	leave
    1efd:	ca 04 00             	retf   0x4
    1f00:	55                   	push   bp
    1f01:	89 e5                	mov    bp,sp
    1f03:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f06:	06                   	push   es
    1f07:	57                   	push   di
    1f08:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f0b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    1f0f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f12:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f15:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1f19:	06                   	push   es
    1f1a:	57                   	push   di
    1f1b:	9a d0 0d 25 1f       	call   0x1f25:0xdd0
    1f20:	52                   	push   dx
    1f21:	50                   	push   ax
    1f22:	9a e9 1c 36 1f       	call   0x1f36:0x1ce9
    1f27:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f2d:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1f31:	06                   	push   es
    1f32:	57                   	push   di
    1f33:	9a 94 0c 69 1f       	call   0x1f69:0xc94
    1f38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f3b:	06                   	push   es
    1f3c:	57                   	push   di
    1f3d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f40:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    1f44:	c9                   	leave
    1f45:	ca 06 00             	retf   0x6
    1f48:	55                   	push   bp
    1f49:	89 e5                	mov    bp,sp
    1f4b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f4e:	06                   	push   es
    1f4f:	57                   	push   di
    1f50:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f53:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    1f57:	ff 76 0c             	push   WORD PTR [bp+0xc]
    1f5a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    1f5d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f60:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1f64:	06                   	push   es
    1f65:	57                   	push   di
    1f66:	9a 08 0d ba 1f       	call   0x1fba:0xd08
    1f6b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f6e:	06                   	push   es
    1f6f:	57                   	push   di
    1f70:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f73:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    1f77:	c9                   	leave
    1f78:	ca 08 00             	retf   0x8
    1f7b:	c8 0a 00 00          	enter  0xa,0x0
    1f7f:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    1f83:	31 c0                	xor    ax,ax
    1f85:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1f88:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1f8b:	06                   	push   es
    1f8c:	57                   	push   di
    1f8d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    1f90:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    1f94:	48                   	dec    ax
    1f95:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1f98:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1f9b:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    1f9e:	7f 65                	jg     0x2005
    1fa0:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    1fa3:	03 46 fa             	add    ax,WORD PTR [bp-0x6]
    1fa6:	d1 e8                	shr    ax,1
    1fa8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    1fab:	ff 76 f8             	push   WORD PTR [bp-0x8]
    1fae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1fb1:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    1fb5:	06                   	push   es
    1fb6:	57                   	push   di
    1fb7:	9a d0 0d 27 20       	call   0x2027:0xdd0
    1fbc:	89 c7                	mov    di,ax
    1fbe:	8e c2                	mov    es,dx
    1fc0:	81 c7 04 00          	add    di,0x4
    1fc4:	06                   	push   es
    1fc5:	57                   	push   di
    1fc6:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    1fc9:	06                   	push   es
    1fca:	57                   	push   di
    1fcb:	9a ed 07 40 22       	call   0x2240:0x7ed
    1fd0:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    1fd3:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    1fd7:	7d 09                	jge    0x1fe2
    1fd9:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1fdc:	40                   	inc    ax
    1fdd:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    1fe0:	eb 21                	jmp    0x2003
    1fe2:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    1fe5:	48                   	dec    ax
    1fe6:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    1fe9:	83 7e f6 00          	cmp    WORD PTR [bp-0xa],0x0
    1fed:	75 14                	jne    0x2003
    1fef:	c6 46 ff 01          	mov    BYTE PTR [bp-0x1],0x1
    1ff3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    1ff6:	26 80 7d 0b 01       	cmp    BYTE PTR es:[di+0xb],0x1
    1ffb:	74 06                	je     0x2003
    1ffd:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2000:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2003:	eb 93                	jmp    0x1f98
    2005:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2008:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    200b:	26 89 05             	mov    WORD PTR es:[di],ax
    200e:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2011:	c9                   	leave
    2012:	ca 0c 00             	retf   0xc
    2015:	55                   	push   bp
    2016:	89 e5                	mov    bp,sp
    2018:	ff 76 0a             	push   WORD PTR [bp+0xa]
    201b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    201e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    2022:	06                   	push   es
    2023:	57                   	push   di
    2024:	9a d0 0d 70 20       	call   0x2070:0xdd0
    2029:	89 c7                	mov    di,ax
    202b:	8e c2                	mov    es,dx
    202d:	81 c7 04 00          	add    di,0x4
    2031:	06                   	push   es
    2032:	57                   	push   di
    2033:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    2036:	06                   	push   es
    2037:	57                   	push   di
    2038:	68 ff 00             	push   0xff
    203b:	9a e7 17 60 24       	call   0x2460:0x17e7
    2040:	c9                   	leave
    2041:	ca 06 00             	retf   0x6
    2044:	c8 02 00 00          	enter  0x2,0x0
    2048:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    204b:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    204f:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2053:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2056:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2059:	c9                   	leave
    205a:	ca 04 00             	retf   0x4
    205d:	c8 04 00 00          	enter  0x4,0x0
    2061:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2064:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2067:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    206b:	06                   	push   es
    206c:	57                   	push   di
    206d:	9a d0 0d a8 20       	call   0x20a8:0xdd0
    2072:	89 c7                	mov    di,ax
    2074:	8e c2                	mov    es,dx
    2076:	26 8b 05             	mov    ax,WORD PTR es:[di]
    2079:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    207d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2080:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2083:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2086:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2089:	c9                   	leave
    208a:	ca 06 00             	retf   0x6
    208d:	c8 02 00 00          	enter  0x2,0x0
    2091:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2094:	26 80 7d 0a 00       	cmp    BYTE PTR es:[di+0xa],0x0
    2099:	75 14                	jne    0x20af
    209b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    209e:	06                   	push   es
    209f:	57                   	push   di
    20a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20a3:	06                   	push   es
    20a4:	57                   	push   di
    20a5:	9a e0 16 03 21       	call   0x2103:0x16e0
    20aa:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    20ad:	eb 1f                	jmp    0x20ce
    20af:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    20b2:	06                   	push   es
    20b3:	57                   	push   di
    20b4:	8d 7e fe             	lea    di,[bp-0x2]
    20b7:	16                   	push   ss
    20b8:	57                   	push   di
    20b9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20bc:	06                   	push   es
    20bd:	57                   	push   di
    20be:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20c1:	26 ff 5d 60          	call   DWORD PTR es:[di+0x60]
    20c5:	08 c0                	or     al,al
    20c7:	75 05                	jne    0x20ce
    20c9:	c7 46 fe ff ff       	mov    WORD PTR [bp-0x2],0xffff
    20ce:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    20d1:	c9                   	leave
    20d2:	ca 08 00             	retf   0x8
    20d5:	55                   	push   bp
    20d6:	89 e5                	mov    bp,sp
    20d8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20db:	06                   	push   es
    20dc:	57                   	push   di
    20dd:	26 c4 3d             	les    di,DWORD PTR es:[di]
    20e0:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    20e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    20e7:	26 80 7d 0a 00       	cmp    BYTE PTR es:[di+0xa],0x0
    20ec:	74 06                	je     0x20f4
    20ee:	68 0c f0             	push   0xf00c
    20f1:	e8 ee ea             	call   0xbe2
    20f4:	ff 76 0e             	push   WORD PTR [bp+0xe]
    20f7:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    20fa:	06                   	push   es
    20fb:	57                   	push   di
    20fc:	6a 00                	push   0x0
    20fe:	6a 00                	push   0x0
    2100:	9a 9e 1c 13 21       	call   0x2113:0x1c9e
    2105:	52                   	push   dx
    2106:	50                   	push   ax
    2107:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    210a:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    210e:	06                   	push   es
    210f:	57                   	push   di
    2110:	9a a0 0d 1e 21       	call   0x211e:0xda0
    2115:	89 c7                	mov    di,ax
    2117:	8e c2                	mov    es,dx
    2119:	06                   	push   es
    211a:	57                   	push   di
    211b:	9a a7 0e 5f 21       	call   0x215f:0xea7
    2120:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2123:	06                   	push   es
    2124:	57                   	push   di
    2125:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2128:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    212c:	c9                   	leave
    212d:	ca 0a 00             	retf   0xa
    2130:	c8 04 00 00          	enter  0x4,0x0
    2134:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2137:	06                   	push   es
    2138:	57                   	push   di
    2139:	26 c4 3d             	les    di,DWORD PTR es:[di]
    213c:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2140:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2143:	26 80 7d 0a 00       	cmp    BYTE PTR es:[di+0xa],0x0
    2148:	74 06                	je     0x2150
    214a:	68 0c f0             	push   0xf00c
    214d:	e8 92 ea             	call   0xbe2
    2150:	ff 76 0e             	push   WORD PTR [bp+0xe]
    2153:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2156:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    215a:	06                   	push   es
    215b:	57                   	push   di
    215c:	9a d0 0d 7c 21       	call   0x217c:0xdd0
    2161:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2164:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2167:	ff 76 0e             	push   WORD PTR [bp+0xe]
    216a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    216d:	06                   	push   es
    216e:	57                   	push   di
    216f:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2172:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2176:	26 ff 35             	push   WORD PTR es:[di]
    2179:	9a 9e 1c 8c 21       	call   0x218c:0x1c9e
    217e:	52                   	push   dx
    217f:	50                   	push   ax
    2180:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2183:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    2187:	06                   	push   es
    2188:	57                   	push   di
    2189:	9a 67 0f 97 21       	call   0x2197:0xf67
    218e:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2191:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2194:	9a e9 1c cd 21       	call   0x21cd:0x1ce9
    2199:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    219c:	06                   	push   es
    219d:	57                   	push   di
    219e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21a1:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    21a5:	c9                   	leave
    21a6:	ca 0a 00             	retf   0xa
    21a9:	55                   	push   bp
    21aa:	89 e5                	mov    bp,sp
    21ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21af:	06                   	push   es
    21b0:	57                   	push   di
    21b1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21b4:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    21b8:	ff 76 0c             	push   WORD PTR [bp+0xc]
    21bb:	ff 76 0a             	push   WORD PTR [bp+0xa]
    21be:	ff 76 0e             	push   WORD PTR [bp+0xe]
    21c1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21c4:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    21c8:	06                   	push   es
    21c9:	57                   	push   di
    21ca:	9a d0 0d 11 22       	call   0x2211:0xdd0
    21cf:	89 c7                	mov    di,ax
    21d1:	8e c2                	mov    es,dx
    21d3:	58                   	pop    ax
    21d4:	5a                   	pop    dx
    21d5:	26 89 05             	mov    WORD PTR es:[di],ax
    21d8:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    21dc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    21df:	06                   	push   es
    21e0:	57                   	push   di
    21e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    21e4:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    21e8:	c9                   	leave
    21e9:	ca 0a 00             	retf   0xa
    21ec:	c8 08 00 00          	enter  0x8,0x0
    21f0:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    21f3:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    21f6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    21f9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    21fc:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    21ff:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    2202:	d1 e8                	shr    ax,1
    2204:	50                   	push   ax
    2205:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2208:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    220c:	06                   	push   es
    220d:	57                   	push   di
    220e:	9a d0 0d 28 22       	call   0x2228:0xdd0
    2213:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2216:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2219:	ff 76 fe             	push   WORD PTR [bp-0x2]
    221c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    221f:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    2223:	06                   	push   es
    2224:	57                   	push   di
    2225:	9a d0 0d 5a 22       	call   0x225a:0xdd0
    222a:	89 c7                	mov    di,ax
    222c:	8e c2                	mov    es,dx
    222e:	81 c7 04 00          	add    di,0x4
    2232:	06                   	push   es
    2233:	57                   	push   di
    2234:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2237:	81 c7 04 00          	add    di,0x4
    223b:	06                   	push   es
    223c:	57                   	push   di
    223d:	9a ed 07 72 22       	call   0x2272:0x7ed
    2242:	09 c0                	or     ax,ax
    2244:	7d 05                	jge    0x224b
    2246:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2249:	eb ce                	jmp    0x2219
    224b:	ff 76 fc             	push   WORD PTR [bp-0x4]
    224e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2251:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    2255:	06                   	push   es
    2256:	57                   	push   di
    2257:	9a d0 0d 97 22       	call   0x2297:0xdd0
    225c:	89 c7                	mov    di,ax
    225e:	8e c2                	mov    es,dx
    2260:	81 c7 04 00          	add    di,0x4
    2264:	06                   	push   es
    2265:	57                   	push   di
    2266:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2269:	81 c7 04 00          	add    di,0x4
    226d:	06                   	push   es
    226e:	57                   	push   di
    226f:	9a ed 07 49 24       	call   0x2449:0x7ed
    2274:	09 c0                	or     ax,ax
    2276:	7e 05                	jle    0x227d
    2278:	ff 4e fc             	dec    WORD PTR [bp-0x4]
    227b:	eb ce                	jmp    0x224b
    227d:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2280:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2283:	7f 1a                	jg     0x229f
    2285:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2288:	ff 76 fc             	push   WORD PTR [bp-0x4]
    228b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    228e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    2292:	06                   	push   es
    2293:	57                   	push   di
    2294:	9a 08 0d c0 22       	call   0x22c0:0xd08
    2299:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    229c:	ff 4e fc             	dec    WORD PTR [bp-0x4]
    229f:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    22a2:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    22a5:	7f 03                	jg     0x22aa
    22a7:	e9 6f ff             	jmp    0x2219
    22aa:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    22ad:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    22b0:	7d 10                	jge    0x22c2
    22b2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    22b5:	ff 76 fc             	push   WORD PTR [bp-0x4]
    22b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22bb:	06                   	push   es
    22bc:	57                   	push   di
    22bd:	9a ec 21 d8 22       	call   0x22d8:0x21ec
    22c2:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    22c5:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    22c8:	7d 10                	jge    0x22da
    22ca:	ff 76 fe             	push   WORD PTR [bp-0x2]
    22cd:	ff 76 0a             	push   WORD PTR [bp+0xa]
    22d0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22d3:	06                   	push   es
    22d4:	57                   	push   di
    22d5:	9a ec 21 6c 23       	call   0x236c:0x21ec
    22da:	c9                   	leave
    22db:	ca 08 00             	retf   0x8
    22de:	55                   	push   bp
    22df:	89 e5                	mov    bp,sp
    22e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    22e4:	26 8a 45 0a          	mov    al,BYTE PTR es:[di+0xa]
    22e8:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    22eb:	74 19                	je     0x2306
    22ed:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    22f1:	74 09                	je     0x22fc
    22f3:	06                   	push   es
    22f4:	57                   	push   di
    22f5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    22f8:	26 ff 5d 64          	call   DWORD PTR es:[di+0x64]
    22fc:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    22ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2302:	26 88 45 0a          	mov    BYTE PTR es:[di+0xa],al
    2306:	c9                   	leave
    2307:	ca 06 00             	retf   0x6
    230a:	55                   	push   bp
    230b:	89 e5                	mov    bp,sp
    230d:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2311:	74 0e                	je     0x2321
    2313:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2316:	06                   	push   es
    2317:	57                   	push   di
    2318:	26 c4 3d             	les    di,DWORD PTR es:[di]
    231b:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    231f:	eb 0c                	jmp    0x232d
    2321:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2324:	06                   	push   es
    2325:	57                   	push   di
    2326:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2329:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    232d:	c9                   	leave
    232e:	ca 06 00             	retf   0x6
    2331:	55                   	push   bp
    2332:	89 e5                	mov    bp,sp
    2334:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2337:	26 80 7d 0a 00       	cmp    BYTE PTR es:[di+0xa],0x0
    233c:	75 3c                	jne    0x237a
    233e:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    2342:	26 83 7d 08 01       	cmp    WORD PTR es:[di+0x8],0x1
    2347:	7e 31                	jle    0x237a
    2349:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    234c:	06                   	push   es
    234d:	57                   	push   di
    234e:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2351:	26 ff 5d 5c          	call   DWORD PTR es:[di+0x5c]
    2355:	6a 00                	push   0x0
    2357:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    235a:	26 c4 7d 06          	les    di,DWORD PTR es:[di+0x6]
    235e:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2362:	48                   	dec    ax
    2363:	50                   	push   ax
    2364:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2367:	06                   	push   es
    2368:	57                   	push   di
    2369:	9a ec 21 52 24       	call   0x2452:0x21ec
    236e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2371:	06                   	push   es
    2372:	57                   	push   di
    2373:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2376:	26 ff 5d 58          	call   DWORD PTR es:[di+0x58]
    237a:	c9                   	leave
    237b:	ca 04 00             	retf   0x4
    237e:	c8 04 00 00          	enter  0x4,0x0
    2382:	6a 00                	push   0x0
    2384:	6a 00                	push   0x0
    2386:	6a 01                	push   0x1
    2388:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    238b:	06                   	push   es
    238c:	57                   	push   di
    238d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2390:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2394:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2397:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    239a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    239d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    23a0:	c9                   	leave
    23a1:	ca 04 00             	retf   0x4
    23a4:	55                   	push   bp
    23a5:	89 e5                	mov    bp,sp
    23a7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    23aa:	ff 76 0a             	push   WORD PTR [bp+0xa]
    23ad:	6a 00                	push   0x0
    23af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23b2:	06                   	push   es
    23b3:	57                   	push   di
    23b4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23b7:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    23bb:	c9                   	leave
    23bc:	ca 08 00             	retf   0x8
    23bf:	c8 08 00 00          	enter  0x8,0x0
    23c3:	6a 00                	push   0x0
    23c5:	6a 00                	push   0x0
    23c7:	6a 01                	push   0x1
    23c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23cc:	06                   	push   es
    23cd:	57                   	push   di
    23ce:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23d1:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    23d5:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    23d8:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    23db:	6a 00                	push   0x0
    23dd:	6a 00                	push   0x0
    23df:	6a 02                	push   0x2
    23e1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23e4:	06                   	push   es
    23e5:	57                   	push   di
    23e6:	26 c4 3d             	les    di,DWORD PTR es:[di]
    23e9:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    23ed:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    23f0:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    23f3:	ff 76 fa             	push   WORD PTR [bp-0x6]
    23f6:	ff 76 f8             	push   WORD PTR [bp-0x8]
    23f9:	6a 00                	push   0x0
    23fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    23fe:	06                   	push   es
    23ff:	57                   	push   di
    2400:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2403:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2407:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    240a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    240d:	c9                   	leave
    240e:	ca 04 00             	retf   0x4
    2411:	c8 00 01 00          	enter  0x100,0x0
    2415:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2418:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    241b:	74 45                	je     0x2462
    241d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2420:	06                   	push   es
    2421:	57                   	push   di
    2422:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2425:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2428:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    242b:	06                   	push   es
    242c:	57                   	push   di
    242d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2430:	26 ff 1d             	call   DWORD PTR es:[di]
    2433:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    2436:	75 05                	jne    0x243d
    2438:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    243b:	74 25                	je     0x2462
    243d:	8d be 00 ff          	lea    di,[bp-0x100]
    2441:	16                   	push   ss
    2442:	57                   	push   di
    2443:	68 03 f0             	push   0xf003
    2446:	9a 2b 09 59 24       	call   0x2459:0x92b
    244b:	b0 01                	mov    al,0x1
    244d:	50                   	push   ax
    244e:	b8 64 01             	mov    ax,0x164
    2451:	ba a8 24             	mov    dx,0x24a8
    2454:	52                   	push   dx
    2455:	50                   	push   ax
    2456:	9a e6 28 9f 24       	call   0x249f:0x28e6
    245b:	52                   	push   dx
    245c:	50                   	push   ax
    245d:	9a 99 13 b6 24       	call   0x24b6:0x1399
    2462:	c9                   	leave
    2463:	ca 0c 00             	retf   0xc
    2466:	c8 00 01 00          	enter  0x100,0x0
    246a:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    246d:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    2470:	74 46                	je     0x24b8
    2472:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2475:	06                   	push   es
    2476:	57                   	push   di
    2477:	ff 76 0c             	push   WORD PTR [bp+0xc]
    247a:	ff 76 0a             	push   WORD PTR [bp+0xa]
    247d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2480:	06                   	push   es
    2481:	57                   	push   di
    2482:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2485:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    2489:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    248c:	75 05                	jne    0x2493
    248e:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    2491:	74 25                	je     0x24b8
    2493:	8d be 00 ff          	lea    di,[bp-0x100]
    2497:	16                   	push   ss
    2498:	57                   	push   di
    2499:	68 04 f0             	push   0xf004
    249c:	9a 2b 09 af 24       	call   0x24af:0x92b
    24a1:	b0 01                	mov    al,0x1
    24a3:	50                   	push   ax
    24a4:	b8 8f 01             	mov    ax,0x18f
    24a7:	ba c0 24             	mov    dx,0x24c0
    24aa:	52                   	push   dx
    24ab:	50                   	push   ax
    24ac:	9a e6 28 1c 27       	call   0x271c:0x28e6
    24b1:	52                   	push   dx
    24b2:	50                   	push   ax
    24b3:	9a 99 13 1a 25       	call   0x251a:0x1399
    24b8:	c9                   	leave
    24b9:	ca 0c 00             	retf   0xc
    24bc:	00 00                	add    BYTE PTR [bx+si],al
    24be:	9c                   	pushf
    24bf:	25 da 24             	and    ax,0x24da
    24c2:	c8 0c 00 00          	enter  0xc,0x0
    24c6:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    24c9:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    24cc:	75 1e                	jne    0x24ec
    24ce:	6a 00                	push   0x0
    24d0:	6a 00                	push   0x0
    24d2:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    24d5:	06                   	push   es
    24d6:	57                   	push   di
    24d7:	9a a4 23 e4 24       	call   0x24e4:0x23a4
    24dc:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    24df:	06                   	push   es
    24e0:	57                   	push   di
    24e1:	9a bf 23 6b 25       	call   0x256b:0x23bf
    24e6:	89 46 0a             	mov    WORD PTR [bp+0xa],ax
    24e9:	89 56 0c             	mov    WORD PTR [bp+0xc],dx
    24ec:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    24ef:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    24f2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    24f5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    24f8:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    24fc:	7f 09                	jg     0x2507
    24fe:	7c 0e                	jl     0x250e
    2500:	81 7e 0a 00 f0       	cmp    WORD PTR [bp+0xa],0xf000
    2505:	76 07                	jbe    0x250e
    2507:	c7 46 fa 00 f0       	mov    WORD PTR [bp-0x6],0xf000
    250c:	eb 06                	jmp    0x2514
    250e:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2511:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    2514:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2517:	9a 82 01 a8 25       	call   0x25a8:0x182
    251c:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    251f:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    2522:	b8 bc 24             	mov    ax,0x24bc
    2525:	0e                   	push   cs
    2526:	50                   	push   ax
    2527:	55                   	push   bp
    2528:	ff 36 58 18          	push   WORD PTR ds:0x1858
    252c:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2530:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2533:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    2536:	74 58                	je     0x2590
    2538:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    253b:	31 d2                	xor    dx,dx
    253d:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    2540:	7c 07                	jl     0x2549
    2542:	7f 0d                	jg     0x2551
    2544:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    2547:	73 08                	jae    0x2551
    2549:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    254c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    254f:	eb 06                	jmp    0x2557
    2551:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2554:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2557:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    255a:	06                   	push   es
    255b:	57                   	push   di
    255c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    255f:	31 d2                	xor    dx,dx
    2561:	52                   	push   dx
    2562:	50                   	push   ax
    2563:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2566:	06                   	push   es
    2567:	57                   	push   di
    2568:	9a 11 24 81 25       	call   0x2581:0x2411
    256d:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    2570:	06                   	push   es
    2571:	57                   	push   di
    2572:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2575:	31 d2                	xor    dx,dx
    2577:	52                   	push   dx
    2578:	50                   	push   ax
    2579:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    257c:	06                   	push   es
    257d:	57                   	push   di
    257e:	9a 66 24 b9 25       	call   0x25b9:0x2466
    2583:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2586:	31 d2                	xor    dx,dx
    2588:	29 46 0a             	sub    WORD PTR [bp+0xa],ax
    258b:	19 56 0c             	sbb    WORD PTR [bp+0xc],dx
    258e:	eb a0                	jmp    0x2530
    2590:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2594:	83 c4 06             	add    sp,0x6
    2597:	b8 ab 25             	mov    ax,0x25ab
    259a:	0e                   	push   cs
    259b:	50                   	push   ax
    259c:	ff 76 f6             	push   WORD PTR [bp-0xa]
    259f:	ff 76 f4             	push   WORD PTR [bp-0xc]
    25a2:	ff 76 fa             	push   WORD PTR [bp-0x6]
    25a5:	9a 9c 01 16 26       	call   0x2616:0x19c
    25aa:	cb                   	retf
    25ab:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    25ae:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    25b1:	c9                   	leave
    25b2:	ca 0c 00             	retf   0xc
    25b5:	00 00                	add    BYTE PTR [bx+si],al
    25b7:	0e                   	push   cs
    25b8:	26 cf                	es iret
    25ba:	25 c8 08             	and    ax,0x8c8
    25bd:	00 00                	add    BYTE PTR [bx+si],al
    25bf:	ff 76 08             	push   WORD PTR [bp+0x8]
    25c2:	ff 76 06             	push   WORD PTR [bp+0x6]
    25c5:	68 00 10             	push   0x1000
    25c8:	b0 01                	mov    al,0x1
    25ca:	50                   	push   ax
    25cb:	b8 8d 05             	mov    ax,0x58d
    25ce:	ba d6 25             	mov    dx,0x25d6
    25d1:	52                   	push   dx
    25d2:	50                   	push   ax
    25d3:	9a c2 2b fa 25       	call   0x25fa:0x2bc2
    25d8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    25db:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    25de:	b8 b5 25             	mov    ax,0x25b5
    25e1:	0e                   	push   cs
    25e2:	50                   	push   ax
    25e3:	55                   	push   bp
    25e4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    25e8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    25ec:	ff 76 0c             	push   WORD PTR [bp+0xc]
    25ef:	ff 76 0a             	push   WORD PTR [bp+0xa]
    25f2:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    25f5:	06                   	push   es
    25f6:	57                   	push   di
    25f7:	9a 6d 3c 59 27       	call   0x2759:0x3c6d
    25fc:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    25ff:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2602:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2606:	83 c4 06             	add    sp,0x6
    2609:	b8 19 26             	mov    ax,0x2619
    260c:	0e                   	push   cs
    260d:	50                   	push   ax
    260e:	c4 7e f8             	les    di,DWORD PTR [bp-0x8]
    2611:	06                   	push   es
    2612:	57                   	push   di
    2613:	9a 7f 1f 32 26       	call   0x2632:0x1f7f
    2618:	cb                   	retf
    2619:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    261c:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    261f:	c9                   	leave
    2620:	ca 08 00             	retf   0x8
    2623:	55                   	push   bp
    2624:	89 e5                	mov    bp,sp
    2626:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    262a:	74 08                	je     0x2634
    262c:	83 ec 08             	sub    sp,0x8
    262f:	9a e2 1f 0c 27       	call   0x270c:0x1fe2
    2634:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2637:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    263a:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    263e:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2642:	74 07                	je     0x264b
    2644:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2648:	83 c4 06             	add    sp,0x6
    264b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    264e:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2651:	c9                   	leave
    2652:	ca 08 00             	retf   0x8
    2655:	c8 04 00 00          	enter  0x4,0x0
    2659:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    265c:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2660:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2663:	06                   	push   es
    2664:	57                   	push   di
    2665:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2668:	ff 76 0a             	push   WORD PTR [bp+0xa]
    266b:	9a ff ff 00 00       	call   0x0:0xffff
    2670:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2673:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2676:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    267a:	75 0e                	jne    0x268a
    267c:	83 7e fc ff          	cmp    WORD PTR [bp-0x4],0xffff
    2680:	75 08                	jne    0x268a
    2682:	31 c0                	xor    ax,ax
    2684:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2687:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    268a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    268d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2690:	c9                   	leave
    2691:	ca 0c 00             	retf   0xc
    2694:	c8 04 00 00          	enter  0x4,0x0
    2698:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    269b:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    269f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    26a2:	06                   	push   es
    26a3:	57                   	push   di
    26a4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    26a7:	ff 76 0a             	push   WORD PTR [bp+0xa]
    26aa:	9a ff ff 00 00       	call   0x0:0xffff
    26af:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26b2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    26b5:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    26b9:	75 0e                	jne    0x26c9
    26bb:	83 7e fc ff          	cmp    WORD PTR [bp-0x4],0xffff
    26bf:	75 08                	jne    0x26c9
    26c1:	31 c0                	xor    ax,ax
    26c3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26c6:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    26c9:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    26cc:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    26cf:	c9                   	leave
    26d0:	ca 0c 00             	retf   0xc
    26d3:	c8 04 00 00          	enter  0x4,0x0
    26d7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    26da:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    26de:	ff 76 0e             	push   WORD PTR [bp+0xe]
    26e1:	ff 76 0c             	push   WORD PTR [bp+0xc]
    26e4:	ff 76 0a             	push   WORD PTR [bp+0xa]
    26e7:	9a ff ff 00 00       	call   0x0:0xffff
    26ec:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    26ef:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    26f2:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    26f5:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    26f8:	c9                   	leave
    26f9:	ca 0a 00             	retf   0xa
    26fc:	c8 08 01 00          	enter  0x108,0x0
    2700:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2704:	74 08                	je     0x270e
    2706:	83 ec 08             	sub    sp,0x8
    2709:	9a e2 1f 67 27       	call   0x2767:0x1fe2
    270e:	83 7e 0c ff          	cmp    WORD PTR [bp+0xc],0xffff
    2712:	75 57                	jne    0x276b
    2714:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2717:	06                   	push   es
    2718:	57                   	push   di
    2719:	9a c9 09 50 27       	call   0x2750:0x9c9
    271e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2721:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2725:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    272a:	7d 3d                	jge    0x2769
    272c:	8d be f8 fe          	lea    di,[bp-0x108]
    2730:	16                   	push   ss
    2731:	57                   	push   di
    2732:	68 01 f0             	push   0xf001
    2735:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2738:	89 f8                	mov    ax,di
    273a:	8c c2                	mov    dx,es
    273c:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    273f:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    2742:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    2746:	8d 7e f8             	lea    di,[bp-0x8]
    2749:	16                   	push   ss
    274a:	57                   	push   di
    274b:	6a 00                	push   0x0
    274d:	9a 50 09 60 27       	call   0x2760:0x950
    2752:	b0 01                	mov    al,0x1
    2754:	50                   	push   ax
    2755:	b8 de 00             	mov    ax,0xde
    2758:	ba b3 27             	mov    dx,0x27b3
    275b:	52                   	push   dx
    275c:	50                   	push   ax
    275d:	9a e6 28 76 27       	call   0x2776:0x28e6
    2762:	52                   	push   dx
    2763:	50                   	push   ax
    2764:	9a 99 13 c1 27       	call   0x27c1:0x1399
    2769:	eb 58                	jmp    0x27c3
    276b:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    276e:	06                   	push   es
    276f:	57                   	push   di
    2770:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2773:	9a a1 09 aa 27       	call   0x27aa:0x9a1
    2778:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    277b:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    277f:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    2784:	7d 3d                	jge    0x27c3
    2786:	8d be f8 fe          	lea    di,[bp-0x108]
    278a:	16                   	push   ss
    278b:	57                   	push   di
    278c:	68 02 f0             	push   0xf002
    278f:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2792:	89 f8                	mov    ax,di
    2794:	8c c2                	mov    dx,es
    2796:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    2799:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    279c:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    27a0:	8d 7e f8             	lea    di,[bp-0x8]
    27a3:	16                   	push   ss
    27a4:	57                   	push   di
    27a5:	6a 00                	push   0x0
    27a7:	9a 50 09 ba 27       	call   0x27ba:0x950
    27ac:	b0 01                	mov    al,0x1
    27ae:	50                   	push   ax
    27af:	b8 0c 01             	mov    ax,0x10c
    27b2:	ba 25 28             	mov    dx,0x2825
    27b5:	52                   	push   dx
    27b6:	50                   	push   ax
    27b7:	9a e6 28 83 2b       	call   0x2b83:0x28e6
    27bc:	52                   	push   dx
    27bd:	50                   	push   ax
    27be:	9a 99 13 f9 27       	call   0x27f9:0x1399
    27c3:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    27c7:	74 07                	je     0x27d0
    27c9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    27cd:	83 c4 06             	add    sp,0x6
    27d0:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    27d3:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    27d6:	c9                   	leave
    27d7:	ca 0c 00             	retf   0xc
    27da:	55                   	push   bp
    27db:	89 e5                	mov    bp,sp
    27dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    27e0:	26 83 7d 04 00       	cmp    WORD PTR es:[di+0x4],0x0
    27e5:	7c 09                	jl     0x27f0
    27e7:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    27eb:	9a ff ff 00 00       	call   0x0:0xffff
    27f0:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    27f4:	74 05                	je     0x27fb
    27f6:	9a 0f 20 32 28       	call   0x2832:0x200f
    27fb:	c9                   	leave
    27fc:	ca 06 00             	retf   0x6
    27ff:	55                   	push   bp
    2800:	89 e5                	mov    bp,sp
    2802:	8b 46 04             	mov    ax,WORD PTR [bp+0x4]
    2805:	8b 56 06             	mov    dx,WORD PTR [bp+0x6]
    2808:	03 46 08             	add    ax,WORD PTR [bp+0x8]
    280b:	83 d2 00             	adc    dx,0x0
    280e:	b9 ff ff             	mov    cx,0xffff
    2811:	d3 e2                	shl    dx,cl
    2813:	03 56 0a             	add    dx,WORD PTR [bp+0xa]
    2816:	c9                   	leave
    2817:	c2 08 00             	ret    0x8
    281a:	55                   	push   bp
    281b:	89 e5                	mov    bp,sp
    281d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2820:	06                   	push   es
    2821:	57                   	push   di
    2822:	9a 89 2a ad 29       	call   0x29ad:0x2a89
    2827:	31 c0                	xor    ax,ax
    2829:	50                   	push   ax
    282a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    282d:	06                   	push   es
    282e:	57                   	push   di
    282f:	9a 66 1f 3d 28       	call   0x283d:0x1f66
    2834:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2838:	74 05                	je     0x283f
    283a:	9a 0f 20 9a 2b       	call   0x2b9a:0x200f
    283f:	c9                   	leave
    2840:	ca 06 00             	retf   0x6
    2843:	c8 04 00 00          	enter  0x4,0x0
    2847:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    284a:	26 83 7d 12 00       	cmp    WORD PTR es:[di+0x12],0x0
    284f:	7f 0f                	jg     0x2860
    2851:	7d 03                	jge    0x2856
    2853:	e9 9e 00             	jmp    0x28f4
    2856:	26 83 7d 10 00       	cmp    WORD PTR es:[di+0x10],0x0
    285b:	73 03                	jae    0x2860
    285d:	e9 94 00             	jmp    0x28f4
    2860:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    2864:	7f 0e                	jg     0x2874
    2866:	7d 03                	jge    0x286b
    2868:	e9 89 00             	jmp    0x28f4
    286b:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    286f:	73 03                	jae    0x2874
    2871:	e9 80 00             	jmp    0x28f4
    2874:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2877:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    287b:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    287f:	26 2b 45 10          	sub    ax,WORD PTR es:[di+0x10]
    2883:	26 1b 55 12          	sbb    dx,WORD PTR es:[di+0x12]
    2887:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    288a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    288d:	83 7e fe 00          	cmp    WORD PTR [bp-0x2],0x0
    2891:	7f 08                	jg     0x289b
    2893:	7c 5f                	jl     0x28f4
    2895:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    2899:	76 59                	jbe    0x28f4
    289b:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    289e:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    28a1:	3b 56 0c             	cmp    dx,WORD PTR [bp+0xc]
    28a4:	7f 07                	jg     0x28ad
    28a6:	7c 11                	jl     0x28b9
    28a8:	3b 46 0a             	cmp    ax,WORD PTR [bp+0xa]
    28ab:	76 0c                	jbe    0x28b9
    28ad:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    28b0:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    28b3:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    28b6:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    28b9:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    28bc:	06                   	push   es
    28bd:	57                   	push   di
    28be:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28c1:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    28c5:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    28c9:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    28cd:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    28d1:	e8 2b ff             	call   0x27ff
    28d4:	52                   	push   dx
    28d5:	50                   	push   ax
    28d6:	ff 76 fe             	push   WORD PTR [bp-0x2]
    28d9:	ff 76 fc             	push   WORD PTR [bp-0x4]
    28dc:	9a e4 29 00 00       	call   0x0:0x29e4
    28e1:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    28e4:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    28e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    28ea:	26 01 45 10          	add    WORD PTR es:[di+0x10],ax
    28ee:	26 11 55 12          	adc    WORD PTR es:[di+0x12],dx
    28f2:	eb 08                	jmp    0x28fc
    28f4:	31 c0                	xor    ax,ax
    28f6:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    28f9:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    28fc:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    28ff:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2902:	c9                   	leave
    2903:	ca 0c 00             	retf   0xc
    2906:	c8 08 00 00          	enter  0x8,0x0
    290a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    290d:	26 83 7d 12 00       	cmp    WORD PTR es:[di+0x12],0x0
    2912:	7f 0f                	jg     0x2923
    2914:	7d 03                	jge    0x2919
    2916:	e9 ee 00             	jmp    0x2a07
    2919:	26 83 7d 10 00       	cmp    WORD PTR es:[di+0x10],0x0
    291e:	73 03                	jae    0x2923
    2920:	e9 e4 00             	jmp    0x2a07
    2923:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    2927:	7f 0e                	jg     0x2937
    2929:	7d 03                	jge    0x292e
    292b:	e9 d9 00             	jmp    0x2a07
    292e:	83 7e 0a 00          	cmp    WORD PTR [bp+0xa],0x0
    2932:	73 03                	jae    0x2937
    2934:	e9 d0 00             	jmp    0x2a07
    2937:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    293a:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    293e:	26 8b 55 12          	mov    dx,WORD PTR es:[di+0x12]
    2942:	03 46 0a             	add    ax,WORD PTR [bp+0xa]
    2945:	13 56 0c             	adc    dx,WORD PTR [bp+0xc]
    2948:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    294b:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    294e:	83 7e fa 00          	cmp    WORD PTR [bp-0x6],0x0
    2952:	7f 0e                	jg     0x2962
    2954:	7d 03                	jge    0x2959
    2956:	e9 ae 00             	jmp    0x2a07
    2959:	83 7e f8 00          	cmp    WORD PTR [bp-0x8],0x0
    295d:	77 03                	ja     0x2962
    295f:	e9 a5 00             	jmp    0x2a07
    2962:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2965:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    2968:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    296b:	26 3b 55 0a          	cmp    dx,WORD PTR es:[di+0xa]
    296f:	7f 08                	jg     0x2979
    2971:	7c 4d                	jl     0x29c0
    2973:	26 3b 45 08          	cmp    ax,WORD PTR es:[di+0x8]
    2977:	76 47                	jbe    0x29c0
    2979:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    297c:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    297f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2982:	26 3b 55 0e          	cmp    dx,WORD PTR es:[di+0xe]
    2986:	7f 08                	jg     0x2990
    2988:	7c 25                	jl     0x29af
    298a:	26 3b 45 0c          	cmp    ax,WORD PTR es:[di+0xc]
    298e:	76 1f                	jbe    0x29af
    2990:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    2993:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    2996:	05 ff 1f             	add    ax,0x1fff
    2999:	83 d2 00             	adc    dx,0x0
    299c:	25 00 e0             	and    ax,0xe000
    299f:	81 e2 ff ff          	and    dx,0xffff
    29a3:	52                   	push   dx
    29a4:	50                   	push   ax
    29a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29a8:	06                   	push   es
    29a9:	57                   	push   di
    29aa:	9a e7 2a 98 2a       	call   0x2a98:0x2ae7
    29af:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    29b2:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    29b5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29b8:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    29bc:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    29c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29c3:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    29c7:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    29cb:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    29cf:	26 ff 75 10          	push   WORD PTR es:[di+0x10]
    29d3:	e8 29 fe             	call   0x27ff
    29d6:	52                   	push   dx
    29d7:	50                   	push   ax
    29d8:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    29db:	06                   	push   es
    29dc:	57                   	push   di
    29dd:	ff 76 0c             	push   WORD PTR [bp+0xc]
    29e0:	ff 76 0a             	push   WORD PTR [bp+0xa]
    29e3:	9a ff ff 00 00       	call   0x0:0xffff
    29e8:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    29eb:	8b 56 fa             	mov    dx,WORD PTR [bp-0x6]
    29ee:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    29f1:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    29f5:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    29f9:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    29fc:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    29ff:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a02:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2a05:	eb 08                	jmp    0x2a0f
    2a07:	31 c0                	xor    ax,ax
    2a09:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a0c:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2a0f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2a12:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2a15:	c9                   	leave
    2a16:	ca 0c 00             	retf   0xc
    2a19:	c8 04 00 00          	enter  0x4,0x0
    2a1d:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2a20:	3d 00 00             	cmp    ax,0x0
    2a23:	75 13                	jne    0x2a38
    2a25:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2a28:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    2a2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a2e:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    2a32:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    2a36:	eb 36                	jmp    0x2a6e
    2a38:	3d 01 00             	cmp    ax,0x1
    2a3b:	75 13                	jne    0x2a50
    2a3d:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2a40:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    2a43:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a46:	26 01 45 10          	add    WORD PTR es:[di+0x10],ax
    2a4a:	26 11 55 12          	adc    WORD PTR es:[di+0x12],dx
    2a4e:	eb 1e                	jmp    0x2a6e
    2a50:	3d 02 00             	cmp    ax,0x2
    2a53:	75 19                	jne    0x2a6e
    2a55:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a58:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2a5c:	26 8b 55 0a          	mov    dx,WORD PTR es:[di+0xa]
    2a60:	03 46 0c             	add    ax,WORD PTR [bp+0xc]
    2a63:	13 56 0e             	adc    dx,WORD PTR [bp+0xe]
    2a66:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    2a6a:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    2a6e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a71:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    2a75:	26 8b 55 12          	mov    dx,WORD PTR es:[di+0x12]
    2a79:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2a7c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2a7f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2a82:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2a85:	c9                   	leave
    2a86:	ca 0a 00             	retf   0xa
    2a89:	55                   	push   bp
    2a8a:	89 e5                	mov    bp,sp
    2a8c:	6a 00                	push   0x0
    2a8e:	6a 00                	push   0x0
    2a90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a93:	06                   	push   es
    2a94:	57                   	push   di
    2a95:	9a e7 2a c0 2a       	call   0x2ac0:0x2ae7
    2a9a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2a9d:	31 c0                	xor    ax,ax
    2a9f:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2aa3:	26 89 45 0a          	mov    WORD PTR es:[di+0xa],ax
    2aa7:	31 c0                	xor    ax,ax
    2aa9:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    2aad:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    2ab1:	c9                   	leave
    2ab2:	ca 04 00             	retf   0x4
    2ab5:	55                   	push   bp
    2ab6:	89 e5                	mov    bp,sp
    2ab8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2abb:	06                   	push   es
    2abc:	57                   	push   di
    2abd:	9a 89 2a d0 2a       	call   0x2ad0:0x2a89
    2ac2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2ac5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2ac8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2acb:	06                   	push   es
    2acc:	57                   	push   di
    2acd:	9a e7 2a 8c 2b       	call   0x2b8c:0x2ae7
    2ad2:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2ad5:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2ad8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2adb:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2adf:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    2ae3:	c9                   	leave
    2ae4:	ca 08 00             	retf   0x8
    2ae7:	c8 04 01 00          	enter  0x104,0x0
    2aeb:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2aee:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2af1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2af4:	26 3b 55 0e          	cmp    dx,WORD PTR es:[di+0xe]
    2af8:	75 09                	jne    0x2b03
    2afa:	26 3b 45 0c          	cmp    ax,WORD PTR es:[di+0xc]
    2afe:	75 03                	jne    0x2b03
    2b00:	e9 bb 00             	jmp    0x2bbe
    2b03:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2b06:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    2b09:	75 20                	jne    0x2b2b
    2b0b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b0e:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2b12:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2b16:	9a 30 3f 45 2b       	call   0x2b45:0x3f30
    2b1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b1e:	31 c0                	xor    ax,ax
    2b20:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2b24:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    2b28:	e9 82 00             	jmp    0x2bad
    2b2b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b2e:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    2b32:	26 0b 45 0e          	or     ax,WORD PTR es:[di+0xe]
    2b36:	75 17                	jne    0x2b4f
    2b38:	ff 36 9a 18          	push   WORD PTR ds:0x189a
    2b3c:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b3f:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b42:	9a dd 3e 67 2b       	call   0x2b67:0x3edd
    2b47:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2b4a:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2b4d:	eb 20                	jmp    0x2b6f
    2b4f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2b52:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2b56:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2b5a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2b5d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2b60:	ff 36 9a 18          	push   WORD PTR ds:0x189a
    2b64:	9a ff 3e ff ff       	call   0xffff:0x3eff
    2b69:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2b6c:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2b6f:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2b72:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    2b75:	75 25                	jne    0x2b9c
    2b77:	8d be fc fe          	lea    di,[bp-0x104]
    2b7b:	16                   	push   ss
    2b7c:	57                   	push   di
    2b7d:	68 05 f0             	push   0xf005
    2b80:	9a 2b 09 93 2b       	call   0x2b93:0x92b
    2b85:	b0 01                	mov    al,0x1
    2b87:	50                   	push   ax
    2b88:	b8 b1 00             	mov    ax,0xb1
    2b8b:	ba cf 2c             	mov    dx,0x2ccf
    2b8e:	52                   	push   dx
    2b8f:	50                   	push   ax
    2b90:	9a e6 28 d6 2c       	call   0x2cd6:0x28e6
    2b95:	52                   	push   dx
    2b96:	50                   	push   ax
    2b97:	9a 99 13 d1 2b       	call   0x2bd1:0x1399
    2b9c:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2b9f:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2ba2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ba5:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2ba9:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    2bad:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    2bb0:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    2bb3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bb6:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2bba:	26 89 55 0e          	mov    WORD PTR es:[di+0xe],dx
    2bbe:	c9                   	leave
    2bbf:	ca 08 00             	retf   0x8
    2bc2:	55                   	push   bp
    2bc3:	89 e5                	mov    bp,sp
    2bc5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2bc9:	74 08                	je     0x2bd3
    2bcb:	83 ec 08             	sub    sp,0x8
    2bce:	9a e2 1f ea 2b       	call   0x2bea:0x1fe2
    2bd3:	8b 46 0e             	mov    ax,WORD PTR [bp+0xe]
    2bd6:	8b 56 10             	mov    dx,WORD PTR [bp+0x10]
    2bd9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bdc:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2be0:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    2be4:	ff 76 0c             	push   WORD PTR [bp+0xc]
    2be7:	9a 82 01 34 2c       	call   0x2c34:0x182
    2bec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2bef:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    2bf3:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    2bf7:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2bfa:	26 89 45 0c          	mov    WORD PTR es:[di+0xc],ax
    2bfe:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2c02:	74 07                	je     0x2c0b
    2c04:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2c08:	83 c4 06             	add    sp,0x6
    2c0b:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    2c0e:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    2c11:	c9                   	leave
    2c12:	ca 0c 00             	retf   0xc
    2c15:	55                   	push   bp
    2c16:	89 e5                	mov    bp,sp
    2c18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2c1b:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2c1f:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
    2c23:	74 11                	je     0x2c36
    2c25:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    2c29:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    2c2d:	26 ff 75 0c          	push   WORD PTR es:[di+0xc]
    2c31:	9a 9c 01 3f 2c       	call   0x2c3f:0x19c
    2c36:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2c3a:	74 05                	je     0x2c41
    2c3c:	9a 0f 20 58 2c       	call   0x2c58:0x200f
    2c41:	c9                   	leave
    2c42:	ca 06 00             	retf   0x6
    2c45:	c8 04 00 00          	enter  0x4,0x0
    2c49:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2c4c:	26 8a 05             	mov    al,BYTE PTR es:[di]
    2c4f:	30 e4                	xor    ah,ah
    2c51:	05 09 00             	add    ax,0x9
    2c54:	50                   	push   ax
    2c55:	9a 82 01 95 2c       	call   0x2c95:0x182
    2c5a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2c5d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2c60:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    2c63:	8b 56 0e             	mov    dx,WORD PTR [bp+0xe]
    2c66:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c69:	26 89 05             	mov    WORD PTR es:[di],ax
    2c6c:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    2c70:	8b 46 08             	mov    ax,WORD PTR [bp+0x8]
    2c73:	8b 56 0a             	mov    dx,WORD PTR [bp+0xa]
    2c76:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c79:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    2c7d:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    2c81:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2c84:	06                   	push   es
    2c85:	57                   	push   di
    2c86:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2c89:	81 c7 08 00          	add    di,0x8
    2c8d:	06                   	push   es
    2c8e:	57                   	push   di
    2c8f:	68 ff 00             	push   0xff
    2c92:	9a e7 17 ba 2c       	call   0x2cba:0x17e7
    2c97:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2c9a:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2c9d:	c9                   	leave
    2c9e:	c2 0c 00             	ret    0xc
    2ca1:	55                   	push   bp
    2ca2:	89 e5                	mov    bp,sp
    2ca4:	ff 76 06             	push   WORD PTR [bp+0x6]
    2ca7:	ff 76 04             	push   WORD PTR [bp+0x4]
    2caa:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2cad:	26 8a 45 08          	mov    al,BYTE PTR es:[di+0x8]
    2cb1:	30 e4                	xor    ah,ah
    2cb3:	05 09 00             	add    ax,0x9
    2cb6:	50                   	push   ax
    2cb7:	9a 9c 01 dd 2c       	call   0x2cdd:0x19c
    2cbc:	c9                   	leave
    2cbd:	c2 04 00             	ret    0x4
    2cc0:	55                   	push   bp
    2cc1:	89 e5                	mov    bp,sp
    2cc3:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2cc6:	06                   	push   es
    2cc7:	57                   	push   di
    2cc8:	b0 01                	mov    al,0x1
    2cca:	50                   	push   ax
    2ccb:	b8 64 01             	mov    ax,0x164
    2cce:	ba 63 2d             	mov    dx,0x2d63
    2cd1:	52                   	push   dx
    2cd2:	50                   	push   ax
    2cd3:	9a e6 28 f3 2c       	call   0x2cf3:0x28e6
    2cd8:	52                   	push   dx
    2cd9:	50                   	push   ax
    2cda:	9a 99 13 6e 2d       	call   0x2d6e:0x1399
    2cdf:	c9                   	leave
    2ce0:	c2 04 00             	ret    0x4
    2ce3:	c8 00 01 00          	enter  0x100,0x0
    2ce7:	8d be 00 ff          	lea    di,[bp-0x100]
    2ceb:	16                   	push   ss
    2cec:	57                   	push   di
    2ced:	68 14 f0             	push   0xf014
    2cf0:	9a 2b 09 0a 2d       	call   0x2d0a:0x92b
    2cf5:	e8 c8 ff             	call   0x2cc0
    2cf8:	c9                   	leave
    2cf9:	c3                   	ret
    2cfa:	c8 00 01 00          	enter  0x100,0x0
    2cfe:	8d be 00 ff          	lea    di,[bp-0x100]
    2d02:	16                   	push   ss
    2d03:	57                   	push   di
    2d04:	68 16 f0             	push   0xf016
    2d07:	9a 2b 09 af 2d       	call   0x2daf:0x92b
    2d0c:	e8 b1 ff             	call   0x2cc0
    2d0f:	c9                   	leave
    2d10:	c3                   	ret
    2d11:	c8 02 00 00          	enter  0x2,0x0
    2d15:	ff 76 0a             	push   WORD PTR [bp+0xa]
    2d18:	ff 76 08             	push   WORD PTR [bp+0x8]
    2d1b:	c4 7e 04             	les    di,DWORD PTR [bp+0x4]
    2d1e:	06                   	push   es
    2d1f:	57                   	push   di
    2d20:	9a bf 2c 00 30       	call   0x3000:0x2cbf
    2d25:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2d28:	83 7e fe ff          	cmp    WORD PTR [bp-0x2],0xffff
    2d2c:	75 03                	jne    0x2d31
    2d2e:	e8 b2 ff             	call   0x2ce3
    2d31:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    2d34:	c9                   	leave
    2d35:	c2 08 00             	ret    0x8
    2d38:	55                   	push   bp
    2d39:	89 e5                	mov    bp,sp
    2d3b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d3e:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    2d42:	26 2b 45 10          	sub    ax,WORD PTR es:[di+0x10]
    2d46:	99                   	cwd
    2d47:	52                   	push   dx
    2d48:	50                   	push   ax
    2d49:	6a 01                	push   0x1
    2d4b:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2d4f:	06                   	push   es
    2d50:	57                   	push   di
    2d51:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2d54:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    2d58:	31 c0                	xor    ax,ax
    2d5a:	50                   	push   ax
    2d5b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d5e:	06                   	push   es
    2d5f:	57                   	push   di
    2d60:	9a 15 2c 7f 2d       	call   0x2d7f:0x2c15
    2d65:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    2d69:	74 05                	je     0x2d70
    2d6b:	9a 0f 20 29 2e       	call   0x2e29:0x200f
    2d70:	c9                   	leave
    2d71:	ca 06 00             	retf   0x6
    2d74:	55                   	push   bp
    2d75:	89 e5                	mov    bp,sp
    2d77:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d7a:	06                   	push   es
    2d7b:	57                   	push   di
    2d7c:	9a b9 3f 92 2d       	call   0x2d92:0x3fb9
    2d81:	3a 46 0a             	cmp    al,BYTE PTR [bp+0xa]
    2d84:	74 11                	je     0x2d97
    2d86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2d89:	26 ff 4d 0e          	dec    WORD PTR es:[di+0xe]
    2d8d:	06                   	push   es
    2d8e:	57                   	push   di
    2d8f:	9a e3 40 d4 2d       	call   0x2dd4:0x40e3
    2d94:	e8 4c ff             	call   0x2ce3
    2d97:	c9                   	leave
    2d98:	ca 06 00             	retf   0x6
    2d9b:	55                   	push   bp
    2d9c:	89 e5                	mov    bp,sp
    2d9e:	c4 7e 1c             	les    di,DWORD PTR [bp+0x1c]
    2da1:	06                   	push   es
    2da2:	57                   	push   di
    2da3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2da6:	81 c7 40 00          	add    di,0x40
    2daa:	06                   	push   es
    2dab:	57                   	push   di
    2dac:	9a 30 07 eb 2d       	call   0x2deb:0x730
    2db1:	09 c0                	or     ax,ax
    2db3:	75 17                	jne    0x2dcc
    2db5:	ff 76 08             	push   WORD PTR [bp+0x8]
    2db8:	ff 76 06             	push   WORD PTR [bp+0x6]
    2dbb:	ff 76 1a             	push   WORD PTR [bp+0x1a]
    2dbe:	ff 76 18             	push   WORD PTR [bp+0x18]
    2dc1:	ff 5e 14             	call   DWORD PTR [bp+0x14]
    2dc4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2dc7:	26 c6 45 40 00       	mov    BYTE PTR es:[di+0x40],0x0
    2dcc:	c9                   	leave
    2dcd:	ca 1a 00             	retf   0x1a
    2dd0:	00 00                	add    BYTE PTR [bx+si],al
    2dd2:	9e                   	sahf
    2dd3:	2e fc                	cs cld
    2dd5:	2d c8 08             	sub    ax,0x8c8
    2dd8:	00 00                	add    BYTE PTR [bx+si],al
    2dda:	c4 7e 1c             	les    di,DWORD PTR [bp+0x1c]
    2ddd:	06                   	push   es
    2dde:	57                   	push   di
    2ddf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2de2:	81 c7 40 00          	add    di,0x40
    2de6:	06                   	push   es
    2de7:	57                   	push   di
    2de8:	9a 30 07 6d 31       	call   0x316d:0x730
    2ded:	09 c0                	or     ax,ax
    2def:	74 03                	je     0x2df4
    2df1:	e9 bd 00             	jmp    0x2eb1
    2df4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2df7:	06                   	push   es
    2df8:	57                   	push   di
    2df9:	9a b9 3f 0e 2e       	call   0x2e0e:0x3fb9
    2dfe:	3c 0a                	cmp    al,0xa
    2e00:	74 19                	je     0x2e1b
    2e02:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e05:	26 ff 4d 0e          	dec    WORD PTR es:[di+0xe]
    2e09:	06                   	push   es
    2e0a:	57                   	push   di
    2e0b:	9a e3 40 22 2e       	call   0x2e22:0x40e3
    2e10:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e13:	26 c6 45 3e 01       	mov    BYTE PTR es:[di+0x3e],0x1
    2e18:	e8 c8 fe             	call   0x2ce3
    2e1b:	b0 01                	mov    al,0x1
    2e1d:	50                   	push   ax
    2e1e:	b8 24 05             	mov    ax,0x524
    2e21:	ba 50 2e             	mov    dx,0x2e50
    2e24:	52                   	push   dx
    2e25:	50                   	push   ax
    2e26:	9a 50 1f a6 2e       	call   0x2ea6:0x1f50
    2e2b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2e2e:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2e31:	b8 d0 2d             	mov    ax,0x2dd0
    2e34:	0e                   	push   cs
    2e35:	50                   	push   ax
    2e36:	55                   	push   bp
    2e37:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2e3b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2e3f:	8d 7e f8             	lea    di,[bp-0x8]
    2e42:	16                   	push   ss
    2e43:	57                   	push   di
    2e44:	6a 00                	push   0x0
    2e46:	6a 04                	push   0x4
    2e48:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e4b:	06                   	push   es
    2e4c:	57                   	push   di
    2e4d:	9a c1 30 60 2e       	call   0x2e60:0x30c1
    2e52:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e55:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2e58:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e5b:	06                   	push   es
    2e5c:	57                   	push   di
    2e5d:	9a b5 2a 79 2e       	call   0x2e79:0x2ab5
    2e62:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2e65:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    2e69:	06                   	push   es
    2e6a:	57                   	push   di
    2e6b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    2e6e:	ff 76 f8             	push   WORD PTR [bp-0x8]
    2e71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e74:	06                   	push   es
    2e75:	57                   	push   di
    2e76:	9a c1 30 c1 2e       	call   0x2ec1:0x30c1
    2e7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2e7e:	26 c6 45 3e 01       	mov    BYTE PTR es:[di+0x3e],0x1
    2e83:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2e86:	ff 76 fc             	push   WORD PTR [bp-0x4]
    2e89:	ff 76 1a             	push   WORD PTR [bp+0x1a]
    2e8c:	ff 76 18             	push   WORD PTR [bp+0x18]
    2e8f:	ff 5e 14             	call   DWORD PTR [bp+0x14]
    2e92:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    2e96:	83 c4 06             	add    sp,0x6
    2e99:	b8 a9 2e             	mov    ax,0x2ea9
    2e9c:	0e                   	push   cs
    2e9d:	50                   	push   ax
    2e9e:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    2ea1:	06                   	push   es
    2ea2:	57                   	push   di
    2ea3:	9a 7f 1f 28 2f       	call   0x2f28:0x1f7f
    2ea8:	cb                   	retf
    2ea9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2eac:	26 c6 45 40 00       	mov    BYTE PTR es:[di+0x40],0x0
    2eb1:	c9                   	leave
    2eb2:	ca 1a 00             	retf   0x1a
    2eb5:	c8 02 00 00          	enter  0x2,0x0
    2eb9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ebc:	06                   	push   es
    2ebd:	57                   	push   di
    2ebe:	9a b9 3f 84 2f       	call   0x2f84:0x3fb9
    2ec3:	08 c0                	or     al,al
    2ec5:	b0 00                	mov    al,0x0
    2ec7:	75 01                	jne    0x2eca
    2ec9:	40                   	inc    ax
    2eca:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    2ecd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ed0:	26 ff 4d 0e          	dec    WORD PTR es:[di+0xe]
    2ed4:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2ed7:	c9                   	leave
    2ed8:	ca 04 00             	retf   0x4
    2edb:	c8 02 00 00          	enter  0x2,0x0
    2edf:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    2ee3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ee6:	26 8b 45 38          	mov    ax,WORD PTR es:[di+0x38]
    2eea:	09 c0                	or     ax,ax
    2eec:	74 1f                	je     0x2f0d
    2eee:	ff 76 08             	push   WORD PTR [bp+0x8]
    2ef1:	ff 76 06             	push   WORD PTR [bp+0x6]
    2ef4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2ef7:	06                   	push   es
    2ef8:	57                   	push   di
    2ef9:	8d 7e ff             	lea    di,[bp-0x1]
    2efc:	16                   	push   ss
    2efd:	57                   	push   di
    2efe:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f01:	26 ff 75 3c          	push   WORD PTR es:[di+0x3c]
    2f05:	26 ff 75 3a          	push   WORD PTR es:[di+0x3a]
    2f09:	26 ff 5d 36          	call   DWORD PTR es:[di+0x36]
    2f0d:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    2f10:	c9                   	leave
    2f11:	ca 08 00             	retf   0x8
    2f14:	c8 06 00 00          	enter  0x6,0x0
    2f18:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2f1b:	06                   	push   es
    2f1c:	57                   	push   di
    2f1d:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    2f20:	26 c4 3d             	les    di,DWORD PTR es:[di]
    2f23:	06                   	push   es
    2f24:	57                   	push   di
    2f25:	9a 3b 21 7b 30       	call   0x307b:0x213b
    2f2a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2f2d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    2f30:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f33:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    2f36:	b0 00                	mov    al,0x0
    2f38:	75 01                	jne    0x2f3b
    2f3a:	40                   	inc    ax
    2f3b:	88 46 fb             	mov    BYTE PTR [bp-0x5],al
    2f3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f41:	26 8b 45 28          	mov    ax,WORD PTR es:[di+0x28]
    2f45:	09 c0                	or     ax,ax
    2f47:	74 24                	je     0x2f6d
    2f49:	ff 76 08             	push   WORD PTR [bp+0x8]
    2f4c:	ff 76 06             	push   WORD PTR [bp+0x6]
    2f4f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    2f52:	06                   	push   es
    2f53:	57                   	push   di
    2f54:	8d 7e fc             	lea    di,[bp-0x4]
    2f57:	16                   	push   ss
    2f58:	57                   	push   di
    2f59:	8d 7e fb             	lea    di,[bp-0x5]
    2f5c:	16                   	push   ss
    2f5d:	57                   	push   di
    2f5e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f61:	26 ff 75 2c          	push   WORD PTR es:[di+0x2c]
    2f65:	26 ff 75 2a          	push   WORD PTR es:[di+0x2a]
    2f69:	26 ff 5d 26          	call   DWORD PTR es:[di+0x26]
    2f6d:	80 7e fb 00          	cmp    BYTE PTR [bp-0x5],0x0
    2f71:	74 03                	je     0x2f76
    2f73:	e8 6d fd             	call   0x2ce3
    2f76:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    2f79:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    2f7c:	c9                   	leave
    2f7d:	ca 0c 00             	retf   0xc
    2f80:	00 00                	add    BYTE PTR [bx+si],al
    2f82:	16                   	push   ss
    2f83:	30 d2                	xor    dl,dl
    2f85:	2f                   	das
    2f86:	c8 08 00 00          	enter  0x8,0x0
    2f8a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2f8d:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    2f91:	26 0b 45 20          	or     ax,WORD PTR es:[di+0x20]
    2f95:	75 03                	jne    0x2f9a
    2f97:	e9 87 00             	jmp    0x3021
    2f9a:	b8 80 2f             	mov    ax,0x2f80
    2f9d:	0e                   	push   cs
    2f9e:	50                   	push   ax
    2f9f:	55                   	push   bp
    2fa0:	ff 36 58 18          	push   WORD PTR ds:0x1858
    2fa4:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    2fa8:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    2fac:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    2fb0:	48                   	dec    ax
    2fb1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    2fb4:	31 c0                	xor    ax,ax
    2fb6:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    2fb9:	7f 4f                	jg     0x300a
    2fbb:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    2fbe:	eb 03                	jmp    0x2fc3
    2fc0:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    2fc3:	ff 76 fe             	push   WORD PTR [bp-0x2]
    2fc6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2fc9:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    2fcd:	06                   	push   es
    2fce:	57                   	push   di
    2fcf:	9a d0 0d f9 2f       	call   0x2ff9:0xdd0
    2fd4:	89 c7                	mov    di,ax
    2fd6:	8e c2                	mov    es,dx
    2fd8:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    2fdc:	26 ff 35             	push   WORD PTR es:[di]
    2fdf:	26 ff 75 06          	push   WORD PTR es:[di+0x6]
    2fe3:	26 ff 75 04          	push   WORD PTR es:[di+0x4]
    2fe7:	81 c7 08 00          	add    di,0x8
    2feb:	06                   	push   es
    2fec:	57                   	push   di
    2fed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    2ff0:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    2ff4:	06                   	push   es
    2ff5:	57                   	push   di
    2ff6:	9a ab 50 1e 30       	call   0x301e:0x50ab
    2ffb:	52                   	push   dx
    2ffc:	50                   	push   ax
    2ffd:	9a c2 2e 6c 38       	call   0x386c:0x2ec2
    3002:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3005:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3008:	75 b6                	jne    0x2fc0
    300a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    300e:	83 c4 06             	add    sp,0x6
    3011:	b8 21 30             	mov    ax,0x3021
    3014:	0e                   	push   cs
    3015:	50                   	push   ax
    3016:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3019:	06                   	push   es
    301a:	57                   	push   di
    301b:	9a 25 30 60 30       	call   0x3060:0x3025
    3020:	cb                   	retf
    3021:	c9                   	leave
    3022:	ca 04 00             	retf   0x4
    3025:	c8 04 00 00          	enter  0x4,0x0
    3029:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    302c:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    3030:	26 0b 45 20          	or     ax,WORD PTR es:[di+0x20]
    3034:	74 54                	je     0x308a
    3036:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    303a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    303e:	48                   	dec    ax
    303f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3042:	31 c0                	xor    ax,ax
    3044:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    3047:	7f 26                	jg     0x306f
    3049:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    304c:	eb 03                	jmp    0x3051
    304e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3051:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3054:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3057:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    305b:	06                   	push   es
    305c:	57                   	push   di
    305d:	9a d0 0d 9a 30       	call   0x309a:0xdd0
    3062:	52                   	push   dx
    3063:	50                   	push   ax
    3064:	e8 3a fc             	call   0x2ca1
    3067:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    306a:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    306d:	75 df                	jne    0x304e
    306f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3072:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    3076:	06                   	push   es
    3077:	57                   	push   di
    3078:	9a 7f 1f 84 31       	call   0x3184:0x1f7f
    307d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3080:	31 c0                	xor    ax,ax
    3082:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    3086:	26 89 45 20          	mov    WORD PTR es:[di+0x20],ax
    308a:	c9                   	leave
    308b:	ca 04 00             	retf   0x4
    308e:	c8 02 00 00          	enter  0x2,0x0
    3092:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3095:	06                   	push   es
    3096:	57                   	push   di
    3097:	9a b9 3f b8 30       	call   0x30b8:0x3fb9
    309c:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    309f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30a2:	26 ff 4d 0e          	dec    WORD PTR es:[di+0xe]
    30a6:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    30a9:	c9                   	leave
    30aa:	ca 04 00             	retf   0x4
    30ad:	55                   	push   bp
    30ae:	89 e5                	mov    bp,sp
    30b0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30b3:	06                   	push   es
    30b4:	57                   	push   di
    30b5:	9a e3 40 e0 30       	call   0x30e0:0x40e3
    30ba:	e8 3d fc             	call   0x2cfa
    30bd:	c9                   	leave
    30be:	ca 04 00             	retf   0x4
    30c1:	55                   	push   bp
    30c2:	89 e5                	mov    bp,sp
    30c4:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    30c7:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    30ca:	eb 59                	jmp    0x3125
    30cc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30cf:	26 8b 4d 10          	mov    cx,WORD PTR es:[di+0x10]
    30d3:	26 2b 4d 0e          	sub    cx,WORD PTR es:[di+0xe]
    30d7:	77 12                	ja     0x30eb
    30d9:	52                   	push   dx
    30da:	50                   	push   ax
    30db:	06                   	push   es
    30dc:	57                   	push   di
    30dd:	9a 2f 31 76 31       	call   0x3176:0x312f
    30e2:	58                   	pop    ax
    30e3:	5a                   	pop    dx
    30e4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    30e7:	26 8b 4d 10          	mov    cx,WORD PTR es:[di+0x10]
    30eb:	09 d2                	or     dx,dx
    30ed:	75 06                	jne    0x30f5
    30ef:	39 c1                	cmp    cx,ax
    30f1:	72 02                	jb     0x30f5
    30f3:	89 c1                	mov    cx,ax
    30f5:	8b 5e 0e             	mov    bx,WORD PTR [bp+0xe]
    30f8:	f7 db                	neg    bx
    30fa:	74 06                	je     0x3102
    30fc:	39 d9                	cmp    cx,bx
    30fe:	72 02                	jb     0x3102
    3100:	89 d9                	mov    cx,bx
    3102:	1e                   	push   ds
    3103:	29 c8                	sub    ax,cx
    3105:	83 da 00             	sbb    dx,0x0
    3108:	26 c5 75 08          	lds    si,DWORD PTR es:[di+0x8]
    310c:	26 03 75 0e          	add    si,WORD PTR es:[di+0xe]
    3110:	26 01 4d 0e          	add    WORD PTR es:[di+0xe],cx
    3114:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    3117:	01 4e 0e             	add    WORD PTR [bp+0xe],cx
    311a:	73 05                	jae    0x3121
    311c:	81 46 10 a3 42       	add    WORD PTR [bp+0x10],0x42a3
    3121:	fc                   	cld
    3122:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    3124:	1f                   	pop    ds
    3125:	89 c1                	mov    cx,ax
    3127:	09 d1                	or     cx,dx
    3129:	75 a1                	jne    0x30cc
    312b:	c9                   	leave
    312c:	ca 0c 00             	retf   0xc
    312f:	c8 00 01 00          	enter  0x100,0x0
    3133:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3136:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    313a:	06                   	push   es
    313b:	57                   	push   di
    313c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    313f:	26 8b 45 0c          	mov    ax,WORD PTR es:[di+0xc]
    3143:	31 d2                	xor    dx,dx
    3145:	52                   	push   dx
    3146:	50                   	push   ax
    3147:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    314b:	06                   	push   es
    314c:	57                   	push   di
    314d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3150:	26 ff 1d             	call   DWORD PTR es:[di]
    3153:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3156:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    315a:	26 83 7d 10 00       	cmp    WORD PTR es:[di+0x10],0x0
    315f:	75 25                	jne    0x3186
    3161:	8d be 00 ff          	lea    di,[bp-0x100]
    3165:	16                   	push   ss
    3166:	57                   	push   di
    3167:	68 03 f0             	push   0xf003
    316a:	9a 2b 09 7d 31       	call   0x317d:0x92b
    316f:	b0 01                	mov    al,0x1
    3171:	50                   	push   ax
    3172:	b8 64 01             	mov    ax,0x164
    3175:	ba 9f 31             	mov    dx,0x319f
    3178:	52                   	push   dx
    3179:	50                   	push   ax
    317a:	9a e6 28 16 32       	call   0x3216:0x28e6
    317f:	52                   	push   dx
    3180:	50                   	push   ax
    3181:	9a 99 13 c7 32       	call   0x32c7:0x1399
    3186:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3189:	31 c0                	xor    ax,ax
    318b:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    318f:	c9                   	leave
    3190:	ca 04 00             	retf   0x4
    3193:	c8 02 00 00          	enter  0x2,0x0
    3197:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    319a:	06                   	push   es
    319b:	57                   	push   di
    319c:	9a b9 3f c0 31       	call   0x31c0:0x3fb9
    31a1:	3c 09                	cmp    al,0x9
    31a3:	b0 00                	mov    al,0x0
    31a5:	75 01                	jne    0x31a8
    31a7:	40                   	inc    ax
    31a8:	88 46 ff             	mov    BYTE PTR [bp-0x1],al
    31ab:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    31ae:	c9                   	leave
    31af:	ca 04 00             	retf   0x4
    31b2:	c8 02 01 00          	enter  0x102,0x0
    31b6:	6a 06                	push   0x6
    31b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31bb:	06                   	push   es
    31bc:	57                   	push   di
    31bd:	9a 74 2d d3 31       	call   0x31d3:0x2d74
    31c2:	8d 7e ff             	lea    di,[bp-0x1]
    31c5:	16                   	push   ss
    31c6:	57                   	push   di
    31c7:	6a 00                	push   0x0
    31c9:	6a 01                	push   0x1
    31cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31ce:	06                   	push   es
    31cf:	57                   	push   di
    31d0:	9a c1 30 f0 31       	call   0x31f0:0x30c1
    31d5:	80 7e ff 01          	cmp    BYTE PTR [bp-0x1],0x1
    31d9:	74 1d                	je     0x31f8
    31db:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31de:	26 ff 4d 0e          	dec    WORD PTR es:[di+0xe]
    31e2:	8d be fe fe          	lea    di,[bp-0x102]
    31e6:	16                   	push   ss
    31e7:	57                   	push   di
    31e8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    31eb:	06                   	push   es
    31ec:	57                   	push   di
    31ed:	9a 3b 3f 09 32       	call   0x3209:0x3f3b
    31f2:	83 c4 04             	add    sp,0x4
    31f5:	e8 eb fa             	call   0x2ce3
    31f8:	8d 7e ff             	lea    di,[bp-0x1]
    31fb:	16                   	push   ss
    31fc:	57                   	push   di
    31fd:	6a 00                	push   0x0
    31ff:	6a 01                	push   0x1
    3201:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3204:	06                   	push   es
    3205:	57                   	push   di
    3206:	9a c1 30 1a 32       	call   0x321a:0x30c1
    320b:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    320e:	c9                   	leave
    320f:	ca 04 00             	retf   0x4
    3212:	01 00                	add    WORD PTR [bx+si],ax
    3214:	2e 00 ae 32 7d       	add    BYTE PTR cs:[bp+0x7d32],ch
    3219:	32 5a 32             	xor    bl,BYTE PTR [bp+si+0x32]
    321c:	c8 04 01 00          	enter  0x104,0x0
    3220:	b8 12 32             	mov    ax,0x3212
    3223:	0e                   	push   cs
    3224:	50                   	push   ax
    3225:	55                   	push   bp
    3226:	ff 36 58 18          	push   WORD PTR ds:0x1858
    322a:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    322e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3231:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3235:	26 ff 75 18          	push   WORD PTR es:[di+0x18]
    3239:	26 ff 75 16          	push   WORD PTR es:[di+0x16]
    323d:	b0 01                	mov    al,0x1
    323f:	50                   	push   ax
    3240:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    3244:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    3248:	8d be 00 ff          	lea    di,[bp-0x100]
    324c:	16                   	push   ss
    324d:	57                   	push   di
    324e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3251:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3255:	06                   	push   es
    3256:	57                   	push   di
    3257:	9a 3b 3f 91 32       	call   0x3291:0x3f3b
    325c:	e8 aa d5             	call   0x809
    325f:	89 c7                	mov    di,ax
    3261:	8e c2                	mov    es,dx
    3263:	06                   	push   es
    3264:	57                   	push   di
    3265:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    3269:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    326c:	36 89 45 fc          	mov    WORD PTR ss:[di-0x4],ax
    3270:	36 89 55 fe          	mov    WORD PTR ss:[di-0x2],dx
    3274:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3278:	83 c4 06             	add    sp,0x6
    327b:	eb 51                	jmp    0x32ce
    327d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3280:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3283:	6a 00                	push   0x0
    3285:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3288:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    328c:	06                   	push   es
    328d:	57                   	push   di
    328e:	9a 7f 41 da 32       	call   0x32da:0x417f
    3293:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3296:	31 c0                	xor    ax,ax
    3298:	36 89 45 fc          	mov    WORD PTR ss:[di-0x4],ax
    329c:	36 89 45 fe          	mov    WORD PTR ss:[di-0x2],ax
    32a0:	8d be fc fe          	lea    di,[bp-0x104]
    32a4:	16                   	push   ss
    32a5:	57                   	push   di
    32a6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    32a9:	06                   	push   es
    32aa:	57                   	push   di
    32ab:	9a e6 29 d6 32       	call   0x32d6:0x29e6
    32b0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    32b3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    32b7:	06                   	push   es
    32b8:	57                   	push   di
    32b9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    32bc:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    32c0:	08 c0                	or     al,al
    32c2:	75 05                	jne    0x32c9
    32c4:	ea 85 13 cc 32       	jmp    0x32cc:0x1385
    32c9:	9a 34 14 0c 33       	call   0x330c:0x1434
    32ce:	c9                   	leave
    32cf:	c2 02 00             	ret    0x2
    32d2:	01 00                	add    WORD PTR [bx+si],ax
    32d4:	2e 00 78 33          	add    BYTE PTR cs:[bx+si+0x33],bh
    32d8:	39 33                	cmp    WORD PTR [bp+di],si
    32da:	00 33                	add    BYTE PTR [bp+di],dh
    32dc:	c8 44 01 00          	enter  0x144,0x0
    32e0:	b8 d2 32             	mov    ax,0x32d2
    32e3:	0e                   	push   cs
    32e4:	50                   	push   ax
    32e5:	55                   	push   bp
    32e6:	ff 36 58 18          	push   WORD PTR ds:0x1858
    32ea:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    32ee:	8d be c0 fe          	lea    di,[bp-0x140]
    32f2:	16                   	push   ss
    32f3:	57                   	push   di
    32f4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    32f7:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    32fb:	06                   	push   es
    32fc:	57                   	push   di
    32fd:	9a 3b 3f 4d 33       	call   0x334d:0x3f3b
    3302:	8d 7e c0             	lea    di,[bp-0x40]
    3305:	16                   	push   ss
    3306:	57                   	push   di
    3307:	6a 3f                	push   0x3f
    3309:	9a e7 17 5b 33       	call   0x335b:0x17e7
    330e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3311:	36 ff 75 fe          	push   WORD PTR ss:[di-0x2]
    3315:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    3319:	8d 7e c0             	lea    di,[bp-0x40]
    331c:	16                   	push   ss
    331d:	57                   	push   di
    331e:	6a 3f                	push   0x3f
    3320:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3323:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3327:	06                   	push   es
    3328:	57                   	push   di
    3329:	26 c4 3d             	les    di,DWORD PTR es:[di]
    332c:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3330:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3334:	83 c4 06             	add    sp,0x6
    3337:	eb 5f                	jmp    0x3398
    3339:	89 46 bc             	mov    WORD PTR [bp-0x44],ax
    333c:	89 56 be             	mov    WORD PTR [bp-0x42],dx
    333f:	6a 00                	push   0x0
    3341:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3344:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3348:	06                   	push   es
    3349:	57                   	push   di
    334a:	9a 7f 41 a4 33       	call   0x33a4:0x417f
    334f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3352:	36 c4 7d fc          	les    di,DWORD PTR ss:[di-0x4]
    3356:	06                   	push   es
    3357:	57                   	push   di
    3358:	9a 7f 1f 91 33       	call   0x3391:0x1f7f
    335d:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3360:	31 c0                	xor    ax,ax
    3362:	36 89 45 fc          	mov    WORD PTR ss:[di-0x4],ax
    3366:	36 89 45 fe          	mov    WORD PTR ss:[di-0x2],ax
    336a:	8d be bc fe          	lea    di,[bp-0x144]
    336e:	16                   	push   ss
    336f:	57                   	push   di
    3370:	c4 7e bc             	les    di,DWORD PTR [bp-0x44]
    3373:	06                   	push   es
    3374:	57                   	push   di
    3375:	9a e6 29 37 37       	call   0x3737:0x29e6
    337a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    337d:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    3381:	06                   	push   es
    3382:	57                   	push   di
    3383:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3386:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    338a:	08 c0                	or     al,al
    338c:	75 05                	jne    0x3393
    338e:	ea 85 13 96 33       	jmp    0x3396:0x1385
    3393:	9a 34 14 19 34       	call   0x3419:0x1434
    3398:	c9                   	leave
    3399:	c2 02 00             	ret    0x2
    339c:	01 00                	add    WORD PTR [bx+si],ax
    339e:	00 00                	add    BYTE PTR [bx+si],al
    33a0:	00 00                	add    BYTE PTR [bx+si],al
    33a2:	11 34                	adc    WORD PTR [si],si
    33a4:	06                   	push   es
    33a5:	34 c8                	xor    al,0xc8
    33a7:	04 00                	add    al,0x0
    33a9:	00 55 e8             	add    BYTE PTR [di-0x18],dl
    33ac:	6e                   	outs   dx,BYTE PTR ds:[si]
    33ad:	fe 8b 46 fc          	dec    BYTE PTR [bp+di-0x3ba]
    33b1:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    33b4:	75 02                	jne    0x33b8
    33b6:	eb 6d                	jmp    0x3425
    33b8:	b8 9c 33             	mov    ax,0x339c
    33bb:	0e                   	push   cs
    33bc:	50                   	push   ax
    33bd:	55                   	push   bp
    33be:	ff 36 58 18          	push   WORD PTR ds:0x1858
    33c2:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    33c6:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33c9:	26 80 4d 18 01       	or     BYTE PTR es:[di+0x18],0x1
    33ce:	55                   	push   bp
    33cf:	e8 0a ff             	call   0x32dc
    33d2:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33d5:	26 80 4d 18 02       	or     BYTE PTR es:[di+0x18],0x2
    33da:	ff 76 08             	push   WORD PTR [bp+0x8]
    33dd:	ff 76 06             	push   WORD PTR [bp+0x6]
    33e0:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33e3:	06                   	push   es
    33e4:	57                   	push   di
    33e5:	26 c4 3d             	les    di,DWORD PTR es:[di]
    33e8:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    33ec:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    33ef:	26 80 65 18 fd       	and    BYTE PTR es:[di+0x18],0xfd
    33f4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    33f7:	ff 76 fc             	push   WORD PTR [bp-0x4]
    33fa:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    33fd:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3401:	06                   	push   es
    3402:	57                   	push   di
    3403:	9a 2b 0c 33 34       	call   0x3433:0xc2b
    3408:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    340c:	83 c4 06             	add    sp,0x6
    340f:	eb 14                	jmp    0x3425
    3411:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3414:	06                   	push   es
    3415:	57                   	push   di
    3416:	9a 7f 1f 1e 34       	call   0x341e:0x1f7f
    341b:	ea 85 13 23 34       	jmp    0x3423:0x1385
    3420:	9a 34 14 54 34       	call   0x3454:0x1434
    3425:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3428:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    342b:	c9                   	leave
    342c:	ca 04 00             	retf   0x4
    342f:	00 00                	add    BYTE PTR [bx+si],al
    3431:	92                   	xchg   dx,ax
    3432:	34 4d                	xor    al,0x4d
    3434:	34 c8                	xor    al,0xc8
    3436:	04 00                	add    al,0x0
    3438:	00 c4                	add    ah,al
    343a:	7e 06                	jle    0x3442
    343c:	26 8b 45 1e          	mov    ax,WORD PTR es:[di+0x1e]
    3440:	26 0b 45 20          	or     ax,WORD PTR es:[di+0x20]
    3444:	75 59                	jne    0x349f
    3446:	b0 01                	mov    al,0x1
    3448:	50                   	push   ax
    3449:	b8 a3 02             	mov    ax,0x2a3
    344c:	ba 7a 34             	mov    dx,0x347a
    344f:	52                   	push   dx
    3450:	50                   	push   ax
    3451:	9a 50 1f eb 35       	call   0x35eb:0x1f50
    3456:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3459:	26 89 45 1e          	mov    WORD PTR es:[di+0x1e],ax
    345d:	26 89 55 20          	mov    WORD PTR es:[di+0x20],dx
    3461:	b8 2f 34             	mov    ax,0x342f
    3464:	0e                   	push   cs
    3465:	50                   	push   ax
    3466:	55                   	push   bp
    3467:	ff 36 58 18          	push   WORD PTR ds:0x1858
    346b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    346f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3472:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3475:	06                   	push   es
    3476:	57                   	push   di
    3477:	9a b9 34 84 34       	call   0x3484:0x34b9
    347c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    347f:	06                   	push   es
    3480:	57                   	push   di
    3481:	9a 86 2f 9a 34       	call   0x349a:0x2f86
    3486:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    348a:	83 c4 06             	add    sp,0x6
    348d:	b8 9d 34             	mov    ax,0x349d
    3490:	0e                   	push   cs
    3491:	50                   	push   ax
    3492:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3495:	06                   	push   es
    3496:	57                   	push   di
    3497:	9a 25 30 ad 34       	call   0x34ad:0x3025
    349c:	cb                   	retf
    349d:	eb 10                	jmp    0x34af
    349f:	ff 76 0c             	push   WORD PTR [bp+0xc]
    34a2:	ff 76 0a             	push   WORD PTR [bp+0xa]
    34a5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34a8:	06                   	push   es
    34a9:	57                   	push   di
    34aa:	9a b9 34 b7 34       	call   0x34b7:0x34b9
    34af:	c9                   	leave
    34b0:	ca 08 00             	retf   0x8
    34b3:	00 00                	add    BYTE PTR [bx+si],al
    34b5:	44                   	inc    sp
    34b6:	35 c5 34             	xor    ax,0x34c5
    34b9:	c8 04 00 00          	enter  0x4,0x0
    34bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34c0:	06                   	push   es
    34c1:	57                   	push   di
    34c2:	9a b5 2e d9 34       	call   0x34d9:0x2eb5
    34c7:	08 c0                	or     al,al
    34c9:	75 12                	jne    0x34dd
    34cb:	ff 76 0c             	push   WORD PTR [bp+0xc]
    34ce:	ff 76 0a             	push   WORD PTR [bp+0xa]
    34d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34d4:	06                   	push   es
    34d5:	57                   	push   di
    34d6:	9a 9e 37 e5 34       	call   0x34e5:0x379e
    34db:	eb e0                	jmp    0x34bd
    34dd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34e0:	06                   	push   es
    34e1:	57                   	push   di
    34e2:	9a 97 36 1c 35       	call   0x351c:0x3697
    34e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    34ea:	26 8b 45 1a          	mov    ax,WORD PTR es:[di+0x1a]
    34ee:	26 8b 55 1c          	mov    dx,WORD PTR es:[di+0x1c]
    34f2:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    34f5:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    34f8:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    34fb:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    34fe:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    3502:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    3506:	b8 b3 34             	mov    ax,0x34b3
    3509:	0e                   	push   cs
    350a:	50                   	push   ax
    350b:	55                   	push   bp
    350c:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3510:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3514:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3517:	06                   	push   es
    3518:	57                   	push   di
    3519:	9a b5 2e 2a 35       	call   0x352a:0x2eb5
    351e:	08 c0                	or     al,al
    3520:	75 0c                	jne    0x352e
    3522:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3525:	06                   	push   es
    3526:	57                   	push   di
    3527:	9a a6 33 36 35       	call   0x3536:0x33a6
    352c:	eb e6                	jmp    0x3514
    352e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3531:	06                   	push   es
    3532:	57                   	push   di
    3533:	9a 97 36 68 35       	call   0x3568:0x3697
    3538:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    353c:	83 c4 06             	add    sp,0x6
    353f:	b8 56 35             	mov    ax,0x3556
    3542:	0e                   	push   cs
    3543:	50                   	push   ax
    3544:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3547:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    354a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    354d:	26 89 45 1a          	mov    WORD PTR es:[di+0x1a],ax
    3551:	26 89 55 1c          	mov    WORD PTR es:[di+0x1c],dx
    3555:	cb                   	retf
    3556:	c9                   	leave
    3557:	ca 08 00             	retf   0x8
    355a:	c8 0a 00 00          	enter  0xa,0x0
    355e:	6a 05                	push   0x5
    3560:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3563:	06                   	push   es
    3564:	57                   	push   di
    3565:	9a 74 2d 7b 35       	call   0x357b:0x2d74
    356a:	8d 7e f6             	lea    di,[bp-0xa]
    356d:	16                   	push   ss
    356e:	57                   	push   di
    356f:	6a 00                	push   0x0
    3571:	6a 0a                	push   0xa
    3573:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3576:	06                   	push   es
    3577:	57                   	push   di
    3578:	9a c1 30 9d 35       	call   0x359d:0x30c1
    357d:	9b db 6e f6          	fld    TBYTE PTR [bp-0xa]
    3581:	90                   	nop
    3582:	9b                   	fwait
    3583:	c9                   	leave
    3584:	ca 04 00             	retf   0x4
    3587:	05 46 61             	add    ax,0x6146
    358a:	6c                   	ins    BYTE PTR es:[di],dx
    358b:	73 65                	jae    0x35f2
    358d:	04 54                	add    al,0x54
    358f:	72 75                	jb     0x3606
    3591:	65 55                	gs push bp
    3593:	89 e5                	mov    bp,sp
    3595:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3598:	06                   	push   es
    3599:	57                   	push   di
    359a:	9a b9 3f b4 35       	call   0x35b4:0x3fb9
    359f:	3c 07                	cmp    al,0x7
    35a1:	75 34                	jne    0x35d7
    35a3:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    35a6:	06                   	push   es
    35a7:	57                   	push   di
    35a8:	6a 00                	push   0x0
    35aa:	6a 01                	push   0x1
    35ac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35af:	06                   	push   es
    35b0:	57                   	push   di
    35b1:	9a c1 30 d3 35       	call   0x35d3:0x30c1
    35b6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    35b9:	81 c7 01 00          	add    di,0x1
    35bd:	06                   	push   es
    35be:	57                   	push   di
    35bf:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    35c2:	26 8a 05             	mov    al,BYTE PTR es:[di]
    35c5:	30 e4                	xor    ah,ah
    35c7:	31 d2                	xor    dx,dx
    35c9:	52                   	push   dx
    35ca:	50                   	push   ax
    35cb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    35ce:	06                   	push   es
    35cf:	57                   	push   di
    35d0:	9a c1 30 15 36       	call   0x3615:0x30c1
    35d5:	eb 2e                	jmp    0x3605
    35d7:	3c 08                	cmp    al,0x8
    35d9:	75 14                	jne    0x35ef
    35db:	bf 87 35             	mov    di,0x3587
    35de:	0e                   	push   cs
    35df:	57                   	push   di
    35e0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    35e3:	06                   	push   es
    35e4:	57                   	push   di
    35e5:	68 ff 00             	push   0xff
    35e8:	9a e7 17 03 36       	call   0x3603:0x17e7
    35ed:	eb 16                	jmp    0x3605
    35ef:	3c 09                	cmp    al,0x9
    35f1:	75 12                	jne    0x3605
    35f3:	bf 8d 35             	mov    di,0x358d
    35f6:	0e                   	push   cs
    35f7:	57                   	push   di
    35f8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    35fb:	06                   	push   es
    35fc:	57                   	push   di
    35fd:	68 ff 00             	push   0xff
    3600:	9a e7 17 cc 36       	call   0x36cc:0x17e7
    3605:	c9                   	leave
    3606:	ca 04 00             	retf   0x4
    3609:	c8 08 00 00          	enter  0x8,0x0
    360d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3610:	06                   	push   es
    3611:	57                   	push   di
    3612:	9a b9 3f 2c 36       	call   0x362c:0x3fb9
    3617:	3c 02                	cmp    al,0x2
    3619:	75 20                	jne    0x363b
    361b:	8d 7e fb             	lea    di,[bp-0x5]
    361e:	16                   	push   ss
    361f:	57                   	push   di
    3620:	6a 00                	push   0x0
    3622:	6a 01                	push   0x1
    3624:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3627:	06                   	push   es
    3628:	57                   	push   di
    3629:	9a c1 30 50 36       	call   0x3650:0x30c1
    362e:	8a 46 fb             	mov    al,BYTE PTR [bp-0x5]
    3631:	98                   	cbw
    3632:	99                   	cwd
    3633:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3636:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3639:	eb 3f                	jmp    0x367a
    363b:	3c 03                	cmp    al,0x3
    363d:	75 1f                	jne    0x365e
    363f:	8d 7e f8             	lea    di,[bp-0x8]
    3642:	16                   	push   ss
    3643:	57                   	push   di
    3644:	6a 00                	push   0x0
    3646:	6a 02                	push   0x2
    3648:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    364b:	06                   	push   es
    364c:	57                   	push   di
    364d:	9a c1 30 73 36       	call   0x3673:0x30c1
    3652:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    3655:	99                   	cwd
    3656:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3659:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    365c:	eb 1c                	jmp    0x367a
    365e:	3c 04                	cmp    al,0x4
    3660:	75 15                	jne    0x3677
    3662:	8d 7e fc             	lea    di,[bp-0x4]
    3665:	16                   	push   ss
    3666:	57                   	push   di
    3667:	6a 00                	push   0x0
    3669:	6a 04                	push   0x4
    366b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    366e:	06                   	push   es
    366f:	57                   	push   di
    3670:	9a c1 30 91 36       	call   0x3691:0x30c1
    3675:	eb 03                	jmp    0x367a
    3677:	e8 69 f6             	call   0x2ce3
    367a:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    367d:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3680:	c9                   	leave
    3681:	ca 04 00             	retf   0x4
    3684:	55                   	push   bp
    3685:	89 e5                	mov    bp,sp
    3687:	6a 01                	push   0x1
    3689:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    368c:	06                   	push   es
    368d:	57                   	push   di
    368e:	9a 74 2d a4 36       	call   0x36a4:0x2d74
    3693:	c9                   	leave
    3694:	ca 04 00             	retf   0x4
    3697:	55                   	push   bp
    3698:	89 e5                	mov    bp,sp
    369a:	6a 00                	push   0x0
    369c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    369f:	06                   	push   es
    36a0:	57                   	push   di
    36a1:	9a 74 2d c0 36       	call   0x36c0:0x2d74
    36a6:	c9                   	leave
    36a7:	ca 04 00             	retf   0x4
    36aa:	c8 58 02 00          	enter  0x258,0x0
    36ae:	8d be c0 fe          	lea    di,[bp-0x140]
    36b2:	16                   	push   ss
    36b3:	57                   	push   di
    36b4:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    36b7:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    36bb:	06                   	push   es
    36bc:	57                   	push   di
    36bd:	9a 2a 51 73 37       	call   0x3773:0x512a
    36c2:	8d 7e c0             	lea    di,[bp-0x40]
    36c5:	16                   	push   ss
    36c6:	57                   	push   di
    36c7:	6a 3f                	push   0x3f
    36c9:	9a e7 17 e9 36       	call   0x36e9:0x17e7
    36ce:	80 7e c0 00          	cmp    BYTE PTR [bp-0x40],0x0
    36d2:	75 23                	jne    0x36f7
    36d4:	8d be c0 fe          	lea    di,[bp-0x140]
    36d8:	16                   	push   ss
    36d9:	57                   	push   di
    36da:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    36dd:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    36e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    36e4:	06                   	push   es
    36e5:	57                   	push   di
    36e6:	9a ed 20 f5 36       	call   0x36f5:0x20ed
    36eb:	8d 7e c0             	lea    di,[bp-0x40]
    36ee:	16                   	push   ss
    36ef:	57                   	push   di
    36f0:	6a 3f                	push   0x3f
    36f2:	9a e7 17 cc 37       	call   0x37cc:0x17e7
    36f7:	8d be a8 fd          	lea    di,[bp-0x258]
    36fb:	16                   	push   ss
    36fc:	57                   	push   di
    36fd:	68 18 f0             	push   0xf018
    3700:	8d 46 c0             	lea    ax,[bp-0x40]
    3703:	8c d2                	mov    dx,ss
    3705:	89 86 a8 fe          	mov    WORD PTR [bp-0x158],ax
    3709:	89 96 aa fe          	mov    WORD PTR [bp-0x156],dx
    370d:	c6 86 ac fe 04       	mov    BYTE PTR [bp-0x154],0x4
    3712:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    3715:	36 8d 85 ee fe       	lea    ax,ss:[di-0x112]
    371a:	8c d2                	mov    dx,ss
    371c:	89 86 b0 fe          	mov    WORD PTR [bp-0x150],ax
    3720:	89 96 b2 fe          	mov    WORD PTR [bp-0x14e],dx
    3724:	c6 86 b4 fe 04       	mov    BYTE PTR [bp-0x14c],0x4
    3729:	8d be c0 fe          	lea    di,[bp-0x140]
    372d:	16                   	push   ss
    372e:	57                   	push   di
    372f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3732:	06                   	push   es
    3733:	57                   	push   di
    3734:	9a e6 29 5a 37       	call   0x375a:0x29e6
    3739:	83 c4 04             	add    sp,0x4
    373c:	8d 86 c0 fe          	lea    ax,[bp-0x140]
    3740:	8c d2                	mov    dx,ss
    3742:	89 86 b8 fe          	mov    WORD PTR [bp-0x148],ax
    3746:	89 96 ba fe          	mov    WORD PTR [bp-0x146],dx
    374a:	c6 86 bc fe 04       	mov    BYTE PTR [bp-0x144],0x4
    374f:	8d be a8 fe          	lea    di,[bp-0x158]
    3753:	16                   	push   ss
    3754:	57                   	push   di
    3755:	6a 02                	push   0x2
    3757:	9a 50 09 81 37       	call   0x3781:0x950
    375c:	e8 61 f5             	call   0x2cc0
    375f:	c9                   	leave
    3760:	c2 06 00             	ret    0x6
    3763:	c8 00 01 00          	enter  0x100,0x0
    3767:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    376a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    376e:	06                   	push   es
    376f:	57                   	push   di
    3770:	9a e3 40 92 37       	call   0x3792:0x40e3
    3775:	8d be 00 ff          	lea    di,[bp-0x100]
    3779:	16                   	push   ss
    377a:	57                   	push   di
    377b:	68 15 f0             	push   0xf015
    377e:	9a 2b 09 8e 37       	call   0x378e:0x92b
    3783:	e8 3a f5             	call   0x2cc0
    3786:	c9                   	leave
    3787:	c2 02 00             	ret    0x2
    378a:	01 00                	add    WORD PTR [bx+si],ax
    378c:	2e 00 98 37 5a       	add    BYTE PTR cs:[bx+si+0x5a37],bl
    3791:	39 9c 37 01          	cmp    WORD PTR [si+0x137],bx
    3795:	00 2e 00 9d          	add    BYTE PTR ds:0x9d00,ch
    3799:	39 7c 39             	cmp    WORD PTR [si+0x39],di
    379c:	be 37 c8             	mov    si,0xc837
    379f:	16                   	push   ss
    37a0:	02 00                	add    al,BYTE PTR [bx+si]
    37a2:	b8 94 37             	mov    ax,0x3794
    37a5:	0e                   	push   cs
    37a6:	50                   	push   ax
    37a7:	55                   	push   bp
    37a8:	ff 36 58 18          	push   WORD PTR ds:0x1858
    37ac:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    37b0:	8d be ee fd          	lea    di,[bp-0x212]
    37b4:	16                   	push   ss
    37b5:	57                   	push   di
    37b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37b9:	06                   	push   es
    37ba:	57                   	push   di
    37bb:	9a 3b 3f 84 38       	call   0x3884:0x3f3b
    37c0:	8d be ee fe          	lea    di,[bp-0x112]
    37c4:	16                   	push   ss
    37c5:	57                   	push   di
    37c6:	68 ff 00             	push   0xff
    37c9:	9a e7 17 34 38       	call   0x3834:0x17e7
    37ce:	b8 8a 37             	mov    ax,0x378a
    37d1:	0e                   	push   cs
    37d2:	50                   	push   ax
    37d3:	55                   	push   bp
    37d4:	ff 36 58 18          	push   WORD PTR ds:0x1858
    37d8:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    37dc:	c7 46 fe 01 00       	mov    WORD PTR [bp-0x2],0x1
    37e1:	8a 86 ee fe          	mov    al,BYTE PTR [bp-0x112]
    37e5:	30 e4                	xor    ah,ah
    37e7:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    37ea:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    37ed:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    37f0:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    37f3:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    37f6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    37f9:	26 c6 45 3e 01       	mov    BYTE PTR es:[di+0x3e],0x1
    37fe:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3801:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3804:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3807:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    380a:	7f 0f                	jg     0x381b
    380c:	8b 7e fe             	mov    di,WORD PTR [bp-0x2]
    380f:	80 bb ee fe 2e       	cmp    BYTE PTR [bp+di-0x112],0x2e
    3814:	74 05                	je     0x381b
    3816:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    3819:	eb e9                	jmp    0x3804
    381b:	8d be ee fd          	lea    di,[bp-0x212]
    381f:	16                   	push   ss
    3820:	57                   	push   di
    3821:	8d be ee fe          	lea    di,[bp-0x112]
    3825:	16                   	push   ss
    3826:	57                   	push   di
    3827:	ff 76 fc             	push   WORD PTR [bp-0x4]
    382a:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    382d:	2b 46 fc             	sub    ax,WORD PTR [bp-0x4]
    3830:	50                   	push   ax
    3831:	9a 0b 18 44 38       	call   0x3844:0x180b
    3836:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3839:	81 c7 40 00          	add    di,0x40
    383d:	06                   	push   es
    383e:	57                   	push   di
    383f:	6a 3f                	push   0x3f
    3841:	9a e7 17 5c 38       	call   0x385c:0x17e7
    3846:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3849:	3b 46 fa             	cmp    ax,WORD PTR [bp-0x6]
    384c:	7e 03                	jle    0x3851
    384e:	e9 8d 00             	jmp    0x38de
    3851:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3854:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3857:	06                   	push   es
    3858:	57                   	push   di
    3859:	9a 26 21 c2 38       	call   0x38c2:0x2126
    385e:	52                   	push   dx
    385f:	50                   	push   ax
    3860:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3863:	81 c7 40 00          	add    di,0x40
    3867:	06                   	push   es
    3868:	57                   	push   di
    3869:	9a 13 2d a9 38       	call   0x38a9:0x2d13
    386e:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    3871:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    3874:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3877:	0b 46 f4             	or     ax,WORD PTR [bp-0xc]
    387a:	75 0a                	jne    0x3886
    387c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    387f:	06                   	push   es
    3880:	57                   	push   di
    3881:	9a ad 30 bb 38       	call   0x38bb:0x30ad
    3886:	31 c0                	xor    ax,ax
    3888:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    388b:	89 46 f0             	mov    WORD PTR [bp-0x10],ax
    388e:	c4 7e f2             	les    di,DWORD PTR [bp-0xe]
    3891:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3894:	26 80 3d 07          	cmp    BYTE PTR es:[di],0x7
    3898:	75 17                	jne    0x38b1
    389a:	ff 76 f8             	push   WORD PTR [bp-0x8]
    389d:	ff 76 f6             	push   WORD PTR [bp-0xa]
    38a0:	ff 76 f4             	push   WORD PTR [bp-0xc]
    38a3:	ff 76 f2             	push   WORD PTR [bp-0xe]
    38a6:	9a 32 2e f9 38       	call   0x38f9:0x2e32
    38ab:	89 46 ee             	mov    WORD PTR [bp-0x12],ax
    38ae:	89 56 f0             	mov    WORD PTR [bp-0x10],dx
    38b1:	ff 76 f0             	push   WORD PTR [bp-0x10]
    38b4:	ff 76 ee             	push   WORD PTR [bp-0x12]
    38b7:	bf d1 02             	mov    di,0x2d1
    38ba:	b8 1d 39             	mov    ax,0x391d
    38bd:	50                   	push   ax
    38be:	57                   	push   di
    38bf:	9a 55 22 e9 38       	call   0x38e9:0x2255
    38c4:	08 c0                	or     al,al
    38c6:	75 04                	jne    0x38cc
    38c8:	55                   	push   bp
    38c9:	e8 97 fe             	call   0x3763
    38cc:	8b 46 ee             	mov    ax,WORD PTR [bp-0x12]
    38cf:	8b 56 f0             	mov    dx,WORD PTR [bp-0x10]
    38d2:	89 46 f6             	mov    WORD PTR [bp-0xa],ax
    38d5:	89 56 f8             	mov    WORD PTR [bp-0x8],dx
    38d8:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    38db:	e9 20 ff             	jmp    0x37fe
    38de:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    38e1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    38e4:	06                   	push   es
    38e5:	57                   	push   di
    38e6:	9a 26 21 71 39       	call   0x3971:0x2126
    38eb:	52                   	push   dx
    38ec:	50                   	push   ax
    38ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    38f0:	81 c7 40 00          	add    di,0x40
    38f4:	06                   	push   es
    38f5:	57                   	push   di
    38f6:	9a 13 2d 37 3a       	call   0x3a37:0x2d13
    38fb:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    38fe:	89 56 f4             	mov    WORD PTR [bp-0xc],dx
    3901:	8b 46 f2             	mov    ax,WORD PTR [bp-0xe]
    3904:	0b 46 f4             	or     ax,WORD PTR [bp-0xc]
    3907:	74 18                	je     0x3921
    3909:	ff 76 f8             	push   WORD PTR [bp-0x8]
    390c:	ff 76 f6             	push   WORD PTR [bp-0xa]
    390f:	ff 76 f4             	push   WORD PTR [bp-0xc]
    3912:	ff 76 f2             	push   WORD PTR [bp-0xe]
    3915:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3918:	06                   	push   es
    3919:	57                   	push   di
    391a:	9a 68 3a 4f 39       	call   0x394f:0x3a68
    391f:	eb 30                	jmp    0x3951
    3921:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3924:	26 c6 45 3e 00       	mov    BYTE PTR es:[di+0x3e],0x0
    3929:	ff 76 08             	push   WORD PTR [bp+0x8]
    392c:	ff 76 06             	push   WORD PTR [bp+0x6]
    392f:	c4 7e f6             	les    di,DWORD PTR [bp-0xa]
    3932:	06                   	push   es
    3933:	57                   	push   di
    3934:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3937:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    393b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    393e:	26 c6 45 3e 01       	mov    BYTE PTR es:[di+0x3e],0x1
    3943:	26 80 7d 40 00       	cmp    BYTE PTR es:[di+0x40],0x0
    3948:	74 07                	je     0x3951
    394a:	06                   	push   es
    394b:	57                   	push   di
    394c:	9a ad 30 e8 39       	call   0x39e8:0x30ad
    3951:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3955:	83 c4 06             	add    sp,0x6
    3958:	eb 19                	jmp    0x3973
    395a:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    395e:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    3962:	ff b6 ec fe          	push   WORD PTR [bp-0x114]
    3966:	ff b6 ea fe          	push   WORD PTR [bp-0x116]
    396a:	55                   	push   bp
    396b:	e8 3c fd             	call   0x36aa
    396e:	9a 34 14 b2 39       	call   0x39b2:0x1434
    3973:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3977:	83 c4 06             	add    sp,0x6
    397a:	eb 3d                	jmp    0x39b9
    397c:	89 86 ea fe          	mov    WORD PTR [bp-0x116],ax
    3980:	89 96 ec fe          	mov    WORD PTR [bp-0x114],dx
    3984:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3987:	26 80 7d 3e 00       	cmp    BYTE PTR es:[di+0x3e],0x0
    398c:	74 21                	je     0x39af
    398e:	8d be ea fd          	lea    di,[bp-0x216]
    3992:	16                   	push   ss
    3993:	57                   	push   di
    3994:	c4 be ea fe          	les    di,DWORD PTR [bp-0x116]
    3998:	06                   	push   es
    3999:	57                   	push   di
    399a:	9a e6 29 4f 3a       	call   0x3a4f:0x29e6
    399f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    39a2:	06                   	push   es
    39a3:	57                   	push   di
    39a4:	26 c4 3d             	les    di,DWORD PTR es:[di]
    39a7:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    39ab:	08 c0                	or     al,al
    39ad:	75 05                	jne    0x39b4
    39af:	ea 85 13 b7 39       	jmp    0x39b7:0x1385
    39b4:	9a 34 14 34 3d       	call   0x3d34:0x1434
    39b9:	c9                   	leave
    39ba:	ca 08 00             	retf   0x8
    39bd:	c8 06 01 00          	enter  0x106,0x0
    39c1:	c4 3e 0a 17          	les    di,DWORD PTR ds:0x170a
    39c5:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    39c9:	48                   	dec    ax
    39ca:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    39cd:	31 c0                	xor    ax,ax
    39cf:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    39d2:	7f 6f                	jg     0x3a43
    39d4:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    39d7:	eb 03                	jmp    0x39dc
    39d9:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    39dc:	ff 76 fe             	push   WORD PTR [bp-0x2]
    39df:	c4 3e 0a 17          	les    di,DWORD PTR ds:0x170a
    39e3:	06                   	push   es
    39e4:	57                   	push   di
    39e5:	9a d0 0d bb 3a       	call   0x3abb:0xdd0
    39ea:	89 c7                	mov    di,ax
    39ec:	8e c2                	mov    es,dx
    39ee:	89 7e f4             	mov    WORD PTR [bp-0xc],di
    39f1:	8c 46 f6             	mov    WORD PTR [bp-0xa],es
    39f4:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    39f7:	26 8b 05             	mov    ax,WORD PTR es:[di]
    39fa:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    39fe:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a01:	26 3b 55 06          	cmp    dx,WORD PTR es:[di+0x6]
    3a05:	75 34                	jne    0x3a3b
    3a07:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    3a0b:	75 2e                	jne    0x3a3b
    3a0d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3a10:	06                   	push   es
    3a11:	57                   	push   di
    3a12:	8d 7e fa             	lea    di,[bp-0x6]
    3a15:	16                   	push   ss
    3a16:	57                   	push   di
    3a17:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    3a1a:	26 ff 5d 08          	call   DWORD PTR es:[di+0x8]
    3a1e:	08 c0                	or     al,al
    3a20:	74 19                	je     0x3a3b
    3a22:	ff 76 10             	push   WORD PTR [bp+0x10]
    3a25:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3a28:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3a2b:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3a2e:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3a31:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3a34:	9a c2 2e fe 3a       	call   0x3afe:0x2ec2
    3a39:	eb 19                	jmp    0x3a54
    3a3b:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3a3e:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3a41:	75 96                	jne    0x39d9
    3a43:	8d be fa fe          	lea    di,[bp-0x106]
    3a47:	16                   	push   ss
    3a48:	57                   	push   di
    3a49:	68 14 f0             	push   0xf014
    3a4c:	9a 2b 09 85 3a       	call   0x3a85:0x92b
    3a51:	e8 6c f2             	call   0x2cc0
    3a54:	c9                   	leave
    3a55:	c2 0e 00             	ret    0xe
    3a58:	b3 3a                	mov    bl,0x3a
    3a5a:	03 3b                	add    di,WORD PTR [bp+di]
    3a5c:	27                   	daa
    3a5d:	3b 57 3b             	cmp    dx,WORD PTR [bx+0x3b]
    3a60:	80 3b a4             	cmp    BYTE PTR [bp+di],0xa4
    3a63:	3b cc                	cmp    cx,sp
    3a65:	3b fd                	cmp    di,bp
    3a67:	3b c8                	cmp    cx,ax
    3a69:	0c 01                	or     al,0x1
    3a6b:	00 c4                	add    ah,al
    3a6d:	7e 0a                	jle    0x3a79
    3a6f:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3a73:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
    3a77:	75 11                	jne    0x3a8a
    3a79:	8d be f4 fe          	lea    di,[bp-0x10c]
    3a7d:	16                   	push   ss
    3a7e:	57                   	push   di
    3a7f:	68 17 f0             	push   0xf017
    3a82:	9a 2b 09 32 3f       	call   0x3f32:0x92b
    3a87:	e8 36 f2             	call   0x2cc0
    3a8a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3a8d:	26 8b 05             	mov    ax,WORD PTR es:[di]
    3a90:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    3a94:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3a97:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3a9a:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3a9d:	26 8a 05             	mov    al,BYTE PTR es:[di]
    3aa0:	2c 01                	sub    al,0x1
    3aa2:	3c 07                	cmp    al,0x7
    3aa4:	76 03                	jbe    0x3aa9
    3aa6:	e9 b0 01             	jmp    0x3c59
    3aa9:	98                   	cbw
    3aaa:	89 c3                	mov    bx,ax
    3aac:	d1 e3                	shl    bx,1
    3aae:	2e ff a7 58 3a       	jmp    WORD PTR cs:[bx+0x3a58]
    3ab3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ab6:	06                   	push   es
    3ab7:	57                   	push   di
    3ab8:	9a 8e 30 db 3a       	call   0x3adb:0x308e
    3abd:	3c 07                	cmp    al,0x7
    3abf:	75 22                	jne    0x3ae3
    3ac1:	ff 76 10             	push   WORD PTR [bp+0x10]
    3ac4:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3ac7:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3aca:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3acd:	8d be f4 fe          	lea    di,[bp-0x10c]
    3ad1:	16                   	push   ss
    3ad2:	57                   	push   di
    3ad3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ad6:	06                   	push   es
    3ad7:	57                   	push   di
    3ad8:	9a 92 35 f7 3a       	call   0x3af7:0x3592
    3add:	55                   	push   bp
    3ade:	e8 dc fe             	call   0x39bd
    3ae1:	eb 1d                	jmp    0x3b00
    3ae3:	ff 76 10             	push   WORD PTR [bp+0x10]
    3ae6:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3ae9:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3aec:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3aef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3af2:	06                   	push   es
    3af3:	57                   	push   di
    3af4:	9a 09 36 17 3b       	call   0x3b17:0x3609
    3af9:	52                   	push   dx
    3afa:	50                   	push   ax
    3afb:	9a c2 2e 22 3b       	call   0x3b22:0x2ec2
    3b00:	e9 56 01             	jmp    0x3c59
    3b03:	ff 76 10             	push   WORD PTR [bp+0x10]
    3b06:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3b09:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b0c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b0f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b12:	06                   	push   es
    3b13:	57                   	push   di
    3b14:	9a b2 31 47 3b       	call   0x3b47:0x31b2
    3b19:	30 e4                	xor    ah,ah
    3b1b:	31 d2                	xor    dx,dx
    3b1d:	52                   	push   dx
    3b1e:	50                   	push   ax
    3b1f:	9a c2 2e 52 3b       	call   0x3b52:0x2ec2
    3b24:	e9 32 01             	jmp    0x3c59
    3b27:	ff 76 10             	push   WORD PTR [bp+0x10]
    3b2a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3b2d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b30:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b33:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3b36:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3b39:	8d be f4 fe          	lea    di,[bp-0x10c]
    3b3d:	16                   	push   ss
    3b3e:	57                   	push   di
    3b3f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b42:	06                   	push   es
    3b43:	57                   	push   di
    3b44:	9a 92 35 6b 3b       	call   0x3b6b:0x3592
    3b49:	e8 c5 f1             	call   0x2d11
    3b4c:	99                   	cwd
    3b4d:	52                   	push   dx
    3b4e:	50                   	push   ax
    3b4f:	9a c2 2e 7b 3b       	call   0x3b7b:0x2ec2
    3b54:	e9 02 01             	jmp    0x3c59
    3b57:	ff 76 10             	push   WORD PTR [bp+0x10]
    3b5a:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3b5d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b60:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b66:	06                   	push   es
    3b67:	57                   	push   di
    3b68:	9a 5a 35 9a 3b       	call   0x3b9a:0x355a
    3b6d:	83 ec 0a             	sub    sp,0xa
    3b70:	89 e3                	mov    bx,sp
    3b72:	9b 36 db 3f          	fstp   TBYTE PTR ss:[bx]
    3b76:	90                   	nop
    3b77:	9b                   	fwait
    3b78:	9a 83 30 9f 3b       	call   0x3b9f:0x3083
    3b7d:	e9 d9 00             	jmp    0x3c59
    3b80:	ff 76 10             	push   WORD PTR [bp+0x10]
    3b83:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3b86:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3b89:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3b8c:	8d be f4 fe          	lea    di,[bp-0x10c]
    3b90:	16                   	push   ss
    3b91:	57                   	push   di
    3b92:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3b95:	06                   	push   es
    3b96:	57                   	push   di
    3b97:	9a 74 3f be 3b       	call   0x3bbe:0x3f74
    3b9c:	9a 9c 2f c7 3b       	call   0x3bc7:0x2f9c
    3ba1:	e9 b5 00             	jmp    0x3c59
    3ba4:	ff 76 10             	push   WORD PTR [bp+0x10]
    3ba7:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3baa:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3bad:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3bb0:	ff 76 fe             	push   WORD PTR [bp-0x2]
    3bb3:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3bb6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bb9:	06                   	push   es
    3bba:	57                   	push   di
    3bbb:	9a 51 3e e6 3b       	call   0x3be6:0x3e51
    3bc0:	31 d2                	xor    dx,dx
    3bc2:	52                   	push   dx
    3bc3:	50                   	push   ax
    3bc4:	9a c2 2e 57 3c       	call   0x3c57:0x2ec2
    3bc9:	e9 8d 00             	jmp    0x3c59
    3bcc:	ff 76 10             	push   WORD PTR [bp+0x10]
    3bcf:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3bd2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3bd5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3bd8:	8d be f4 fe          	lea    di,[bp-0x10c]
    3bdc:	16                   	push   ss
    3bdd:	57                   	push   di
    3bde:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3be1:	06                   	push   es
    3be2:	57                   	push   di
    3be3:	9a 92 35 f9 3b       	call   0x3bf9:0x3592
    3be8:	e8 5a f0             	call   0x2c45
    3beb:	52                   	push   dx
    3bec:	50                   	push   ax
    3bed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3bf0:	26 c4 7d 1e          	les    di,DWORD PTR es:[di+0x1e]
    3bf4:	06                   	push   es
    3bf5:	57                   	push   di
    3bf6:	9a 2b 0c 16 3c       	call   0x3c16:0xc2b
    3bfb:	eb 5c                	jmp    0x3c59
    3bfd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c00:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    3c04:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    3c08:	8d be f4 fe          	lea    di,[bp-0x10c]
    3c0c:	16                   	push   ss
    3c0d:	57                   	push   di
    3c0e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c11:	06                   	push   es
    3c12:	57                   	push   di
    3c13:	9a 92 35 61 3c       	call   0x3c61:0x3592
    3c18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c1b:	06                   	push   es
    3c1c:	57                   	push   di
    3c1d:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3c20:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    3c24:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    3c27:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    3c2a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c2d:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    3c31:	26 8b 55 14          	mov    dx,WORD PTR es:[di+0x14]
    3c35:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3c38:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    3c3b:	8b 46 f4             	mov    ax,WORD PTR [bp-0xc]
    3c3e:	0b 46 f6             	or     ax,WORD PTR [bp-0xa]
    3c41:	74 16                	je     0x3c59
    3c43:	ff 76 10             	push   WORD PTR [bp+0x10]
    3c46:	ff 76 0e             	push   WORD PTR [bp+0xe]
    3c49:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3c4c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3c4f:	8d 7e f4             	lea    di,[bp-0xc]
    3c52:	16                   	push   ss
    3c53:	57                   	push   di
    3c54:	9a 7b 31 7d 3e       	call   0x3e7d:0x317b
    3c59:	c9                   	leave
    3c5a:	ca 0c 00             	retf   0xc
    3c5d:	00 00                	add    BYTE PTR [bx+si],al
    3c5f:	fc                   	cld
    3c60:	3d 6b 3c             	cmp    ax,0x3c6b
    3c63:	01 00                	add    WORD PTR [bx+si],ax
    3c65:	00 00                	add    BYTE PTR [bx+si],al
    3c67:	00 00                	add    BYTE PTR [bx+si],al
    3c69:	21 3e 79 3c          	and    WORD PTR ds:0x3c79,di
    3c6d:	c8 06 01 00          	enter  0x106,0x0
    3c71:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3c74:	06                   	push   es
    3c75:	57                   	push   di
    3c76:	9a fd 3e ae 3c       	call   0x3cae:0x3efd
    3c7b:	b8 63 3c             	mov    ax,0x3c63
    3c7e:	0e                   	push   cs
    3c7f:	50                   	push   ax
    3c80:	55                   	push   bp
    3c81:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3c85:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3c89:	31 c0                	xor    ax,ax
    3c8b:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3c8e:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3c91:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3c94:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3c97:	75 4a                	jne    0x3ce3
    3c99:	6a 00                	push   0x0
    3c9b:	6a 00                	push   0x0
    3c9d:	b0 01                	mov    al,0x1
    3c9f:	50                   	push   ax
    3ca0:	8d be fa fe          	lea    di,[bp-0x106]
    3ca4:	16                   	push   ss
    3ca5:	57                   	push   di
    3ca6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ca9:	06                   	push   es
    3caa:	57                   	push   di
    3cab:	9a 3b 3f b3 3c       	call   0x3cb3:0x3f3b
    3cb0:	9a db 07 d3 3c       	call   0x3cd3:0x7db
    3cb5:	89 c7                	mov    di,ax
    3cb7:	8e c2                	mov    es,dx
    3cb9:	06                   	push   es
    3cba:	57                   	push   di
    3cbb:	26 ff 5d 2c          	call   DWORD PTR es:[di+0x2c]
    3cbf:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3cc2:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3cc5:	8d be fa fe          	lea    di,[bp-0x106]
    3cc9:	16                   	push   ss
    3cca:	57                   	push   di
    3ccb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cce:	06                   	push   es
    3ccf:	57                   	push   di
    3cd0:	9a 3b 3f fd 3c       	call   0x3cfd:0x3f3b
    3cd5:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3cd8:	06                   	push   es
    3cd9:	57                   	push   di
    3cda:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3cdd:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    3ce1:	eb 32                	jmp    0x3d15
    3ce3:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3ce6:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    3ce9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    3cec:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    3cef:	8d be fa fe          	lea    di,[bp-0x106]
    3cf3:	16                   	push   ss
    3cf4:	57                   	push   di
    3cf5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3cf8:	06                   	push   es
    3cf9:	57                   	push   di
    3cfa:	9a 3b 3f 10 3d       	call   0x3d10:0x3f3b
    3cff:	83 c4 04             	add    sp,0x4
    3d02:	8d be fa fe          	lea    di,[bp-0x106]
    3d06:	16                   	push   ss
    3d07:	57                   	push   di
    3d08:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d0b:	06                   	push   es
    3d0c:	57                   	push   di
    3d0d:	9a 3b 3f 2d 3d       	call   0x3d2d:0x3f3b
    3d12:	83 c4 04             	add    sp,0x4
    3d15:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3d18:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3d1b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d1e:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    3d22:	26 89 55 14          	mov    WORD PTR es:[di+0x14],dx
    3d26:	b0 01                	mov    al,0x1
    3d28:	50                   	push   ax
    3d29:	b8 a3 02             	mov    ax,0x2a3
    3d2c:	ba 60 3d             	mov    dx,0x3d60
    3d2f:	52                   	push   dx
    3d30:	50                   	push   ax
    3d31:	9a 50 1f 08 3e       	call   0x3e08:0x1f50
    3d36:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d39:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    3d3d:	26 89 55 24          	mov    WORD PTR es:[di+0x24],dx
    3d41:	b8 5d 3c             	mov    ax,0x3c5d
    3d44:	0e                   	push   cs
    3d45:	50                   	push   ax
    3d46:	55                   	push   bp
    3d47:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3d4b:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3d4f:	26 ff 75 14          	push   WORD PTR es:[di+0x14]
    3d53:	26 ff 75 12          	push   WORD PTR es:[di+0x12]
    3d57:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3d5b:	06                   	push   es
    3d5c:	57                   	push   di
    3d5d:	9a 2b 0c d9 3d       	call   0x3dd9:0xc2b
    3d62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d65:	26 8b 45 12          	mov    ax,WORD PTR es:[di+0x12]
    3d69:	26 8b 55 14          	mov    dx,WORD PTR es:[di+0x14]
    3d6d:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    3d71:	26 89 55 18          	mov    WORD PTR es:[di+0x18],dx
    3d75:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    3d79:	26 80 4d 18 01       	or     BYTE PTR es:[di+0x18],0x1
    3d7e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d81:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    3d85:	26 80 4d 18 02       	or     BYTE PTR es:[di+0x18],0x2
    3d8a:	ff 76 08             	push   WORD PTR [bp+0x8]
    3d8d:	ff 76 06             	push   WORD PTR [bp+0x6]
    3d90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3d93:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    3d97:	06                   	push   es
    3d98:	57                   	push   di
    3d99:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3d9c:	26 ff 5d 18          	call   DWORD PTR es:[di+0x18]
    3da0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3da3:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    3da7:	26 80 65 18 fd       	and    BYTE PTR es:[di+0x18],0xfd
    3dac:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3daf:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3db3:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    3db7:	48                   	dec    ax
    3db8:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    3dbb:	31 c0                	xor    ax,ax
    3dbd:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3dc0:	7f 2e                	jg     0x3df0
    3dc2:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3dc5:	eb 03                	jmp    0x3dca
    3dc7:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    3dca:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3dcd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dd0:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3dd4:	06                   	push   es
    3dd5:	57                   	push   di
    3dd6:	9a d0 0d 4f 3e       	call   0x3e4f:0xdd0
    3ddb:	89 c7                	mov    di,ax
    3ddd:	8e c2                	mov    es,dx
    3ddf:	06                   	push   es
    3de0:	57                   	push   di
    3de1:	26 c4 3d             	les    di,DWORD PTR es:[di]
    3de4:	26 ff 5d 10          	call   DWORD PTR es:[di+0x10]
    3de8:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    3deb:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    3dee:	75 d7                	jne    0x3dc7
    3df0:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3df4:	83 c4 06             	add    sp,0x6
    3df7:	b8 18 3e             	mov    ax,0x3e18
    3dfa:	0e                   	push   cs
    3dfb:	50                   	push   ax
    3dfc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3dff:	26 c4 7d 22          	les    di,DWORD PTR es:[di+0x22]
    3e03:	06                   	push   es
    3e04:	57                   	push   di
    3e05:	9a 7f 1f 31 3e       	call   0x3e31:0x1f7f
    3e0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e0d:	31 c0                	xor    ax,ax
    3e0f:	26 89 45 22          	mov    WORD PTR es:[di+0x22],ax
    3e13:	26 89 45 24          	mov    WORD PTR es:[di+0x24],ax
    3e17:	cb                   	retf
    3e18:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3e1c:	83 c4 06             	add    sp,0x6
    3e1f:	eb 1c                	jmp    0x3e3d
    3e21:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    3e24:	0b 46 0c             	or     ax,WORD PTR [bp+0xc]
    3e27:	75 0a                	jne    0x3e33
    3e29:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    3e2c:	06                   	push   es
    3e2d:	57                   	push   di
    3e2e:	9a 7f 1f 36 3e       	call   0x3e36:0x1f7f
    3e33:	ea 85 13 3b 3e       	jmp    0x3e3b:0x1385
    3e38:	9a 34 14 b0 3e       	call   0x3eb0:0x1434
    3e3d:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3e40:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3e43:	c9                   	leave
    3e44:	ca 08 00             	retf   0x8
    3e47:	01 00                	add    WORD PTR [bx+si],ax
    3e49:	00 00                	add    BYTE PTR [bx+si],al
    3e4b:	00 00                	add    BYTE PTR [bx+si],al
    3e4d:	e2 3e                	loop   0x3e8d
    3e4f:	6b 3e c8 46 01       	imul   di,WORD PTR ds:0x46c8,0x1
    3e54:	00 b8 47 3e          	add    BYTE PTR [bx+si+0x3e47],bh
    3e58:	0e                   	push   cs
    3e59:	50                   	push   ax
    3e5a:	55                   	push   bp
    3e5b:	ff 36 58 18          	push   WORD PTR ds:0x1858
    3e5f:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    3e63:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e66:	06                   	push   es
    3e67:	57                   	push   di
    3e68:	9a b9 3f a4 3e       	call   0x3ea4:0x3fb9
    3e6d:	3c 0b                	cmp    al,0xb
    3e6f:	74 03                	je     0x3e74
    3e71:	e8 6f ee             	call   0x2ce3
    3e74:	ff 76 0c             	push   WORD PTR [bp+0xc]
    3e77:	ff 76 0a             	push   WORD PTR [bp+0xa]
    3e7a:	9a 7e 2c af 45       	call   0x45af:0x2c7e
    3e7f:	89 c7                	mov    di,ax
    3e81:	8e c2                	mov    es,dx
    3e83:	26 8b 45 01          	mov    ax,WORD PTR es:[di+0x1]
    3e87:	26 8b 55 03          	mov    dx,WORD PTR es:[di+0x3]
    3e8b:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    3e8e:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    3e91:	31 c0                	xor    ax,ax
    3e93:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    3e96:	8d be ba fe          	lea    di,[bp-0x146]
    3e9a:	16                   	push   ss
    3e9b:	57                   	push   di
    3e9c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3e9f:	06                   	push   es
    3ea0:	57                   	push   di
    3ea1:	9a 3b 3f ea 3e       	call   0x3eea:0x3f3b
    3ea6:	8d 7e ba             	lea    di,[bp-0x46]
    3ea9:	16                   	push   ss
    3eaa:	57                   	push   di
    3eab:	6a 3f                	push   0x3f
    3ead:	9a e7 17 ef 3e       	call   0x3eef:0x17e7
    3eb2:	80 7e ba 00          	cmp    BYTE PTR [bp-0x46],0x0
    3eb6:	75 02                	jne    0x3eba
    3eb8:	eb 1f                	jmp    0x3ed9
    3eba:	ff 76 fc             	push   WORD PTR [bp-0x4]
    3ebd:	ff 76 fa             	push   WORD PTR [bp-0x6]
    3ec0:	8d 7e ba             	lea    di,[bp-0x46]
    3ec3:	16                   	push   ss
    3ec4:	57                   	push   di
    3ec5:	e8 49 ee             	call   0x2d11
    3ec8:	8a c8                	mov    cl,al
    3eca:	80 f9 10             	cmp    cl,0x10
    3ecd:	73 08                	jae    0x3ed7
    3ecf:	b8 01 00             	mov    ax,0x1
    3ed2:	d3 c0                	rol    ax,cl
    3ed4:	09 46 fe             	or     WORD PTR [bp-0x2],ax
    3ed7:	eb bd                	jmp    0x3e96
    3ed9:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    3edd:	83 c4 06             	add    sp,0x6
    3ee0:	eb 14                	jmp    0x3ef6
    3ee2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3ee5:	06                   	push   es
    3ee6:	57                   	push   di
    3ee7:	9a d7 3f 12 3f       	call   0x3f12:0x3fd7
    3eec:	ea 85 13 f4 3e       	jmp    0x3ef4:0x1385
    3ef1:	9a 34 14 1a 43       	call   0x431a:0x1434
    3ef6:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    3ef9:	c9                   	leave
    3efa:	ca 08 00             	retf   0x8
    3efd:	c8 04 01 00          	enter  0x104,0x0
    3f01:	8d 7e fc             	lea    di,[bp-0x4]
    3f04:	16                   	push   ss
    3f05:	57                   	push   di
    3f06:	6a 00                	push   0x0
    3f08:	6a 04                	push   0x4
    3f0a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f0d:	06                   	push   es
    3f0e:	57                   	push   di
    3f0f:	9a c1 30 4f 3f       	call   0x3f4f:0x30c1
    3f14:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    3f17:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    3f1a:	3b 16 00 17          	cmp    dx,WORD PTR ds:0x1700
    3f1e:	75 06                	jne    0x3f26
    3f20:	3b 06 fe 16          	cmp    ax,WORD PTR ds:0x16fe
    3f24:	74 11                	je     0x3f37
    3f26:	8d be fc fe          	lea    di,[bp-0x104]
    3f2a:	16                   	push   ss
    3f2b:	57                   	push   di
    3f2c:	68 08 f0             	push   0xf008
    3f2f:	9a 2b 09 6e 4c       	call   0x4c6e:0x92b
    3f34:	e8 89 ed             	call   0x2cc0
    3f37:	c9                   	leave
    3f38:	ca 04 00             	retf   0x4
    3f3b:	55                   	push   bp
    3f3c:	89 e5                	mov    bp,sp
    3f3e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f41:	06                   	push   es
    3f42:	57                   	push   di
    3f43:	6a 00                	push   0x0
    3f45:	6a 01                	push   0x1
    3f47:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f4a:	06                   	push   es
    3f4b:	57                   	push   di
    3f4c:	9a c1 30 6e 3f       	call   0x3f6e:0x30c1
    3f51:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f54:	81 c7 01 00          	add    di,0x1
    3f58:	06                   	push   es
    3f59:	57                   	push   di
    3f5a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f5d:	26 8a 05             	mov    al,BYTE PTR es:[di]
    3f60:	30 e4                	xor    ah,ah
    3f62:	31 d2                	xor    dx,dx
    3f64:	52                   	push   dx
    3f65:	50                   	push   ax
    3f66:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f69:	06                   	push   es
    3f6a:	57                   	push   di
    3f6b:	9a c1 30 81 3f       	call   0x3f81:0x30c1
    3f70:	c9                   	leave
    3f71:	ca 04 00             	retf   0x4
    3f74:	55                   	push   bp
    3f75:	89 e5                	mov    bp,sp
    3f77:	6a 06                	push   0x6
    3f79:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f7c:	06                   	push   es
    3f7d:	57                   	push   di
    3f7e:	9a 74 2d 94 3f       	call   0x3f94:0x2d74
    3f83:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f86:	06                   	push   es
    3f87:	57                   	push   di
    3f88:	6a 00                	push   0x0
    3f8a:	6a 01                	push   0x1
    3f8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3f8f:	06                   	push   es
    3f90:	57                   	push   di
    3f91:	9a c1 30 b3 3f       	call   0x3fb3:0x30c1
    3f96:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3f99:	81 c7 01 00          	add    di,0x1
    3f9d:	06                   	push   es
    3f9e:	57                   	push   di
    3f9f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    3fa2:	26 8a 05             	mov    al,BYTE PTR es:[di]
    3fa5:	30 e4                	xor    ah,ah
    3fa7:	31 d2                	xor    dx,dx
    3fa9:	52                   	push   dx
    3faa:	50                   	push   ax
    3fab:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fae:	06                   	push   es
    3faf:	57                   	push   di
    3fb0:	9a c1 30 ce 3f       	call   0x3fce:0x30c1
    3fb5:	c9                   	leave
    3fb6:	ca 04 00             	retf   0x4
    3fb9:	c8 02 00 00          	enter  0x2,0x0
    3fbd:	8d 7e ff             	lea    di,[bp-0x1]
    3fc0:	16                   	push   ss
    3fc1:	57                   	push   di
    3fc2:	6a 00                	push   0x0
    3fc4:	6a 01                	push   0x1
    3fc6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fc9:	06                   	push   es
    3fca:	57                   	push   di
    3fcb:	9a c1 30 e9 3f       	call   0x3fe9:0x30c1
    3fd0:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    3fd3:	c9                   	leave
    3fd4:	ca 04 00             	retf   0x4
    3fd7:	c8 00 01 00          	enter  0x100,0x0
    3fdb:	8d be 00 ff          	lea    di,[bp-0x100]
    3fdf:	16                   	push   ss
    3fe0:	57                   	push   di
    3fe1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    3fe4:	06                   	push   es
    3fe5:	57                   	push   di
    3fe6:	9a 3b 3f 0a 40       	call   0x400a:0x3f3b
    3feb:	83 c4 04             	add    sp,0x4
    3fee:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    3ff3:	74 02                	je     0x3ff7
    3ff5:	eb e4                	jmp    0x3fdb
    3ff7:	c9                   	leave
    3ff8:	ca 04 00             	retf   0x4
    3ffb:	55                   	push   bp
    3ffc:	89 e5                	mov    bp,sp
    3ffe:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4001:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4005:	06                   	push   es
    4006:	57                   	push   di
    4007:	9a b5 2e 1c 40       	call   0x401c:0x2eb5
    400c:	08 c0                	or     al,al
    400e:	75 10                	jne    0x4020
    4010:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4013:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4017:	06                   	push   es
    4018:	57                   	push   di
    4019:	9a e3 40 2c 40       	call   0x402c:0x40e3
    401e:	eb de                	jmp    0x3ffe
    4020:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4023:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4027:	06                   	push   es
    4028:	57                   	push   di
    4029:	9a 97 36 6a 40       	call   0x406a:0x3697
    402e:	c9                   	leave
    402f:	c2 02 00             	ret    0x2
    4032:	c8 00 01 00          	enter  0x100,0x0
    4036:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    403a:	7f 08                	jg     0x4044
    403c:	7c 5d                	jl     0x409b
    403e:	83 7e 06 00          	cmp    WORD PTR [bp+0x6],0x0
    4042:	76 57                	jbe    0x409b
    4044:	83 7e 08 00          	cmp    WORD PTR [bp+0x8],0x0
    4048:	7f 09                	jg     0x4053
    404a:	7c 2b                	jl     0x4077
    404c:	81 7e 06 00 01       	cmp    WORD PTR [bp+0x6],0x100
    4051:	76 24                	jbe    0x4077
    4053:	8d be 00 ff          	lea    di,[bp-0x100]
    4057:	16                   	push   ss
    4058:	57                   	push   di
    4059:	6a 00                	push   0x0
    405b:	68 00 01             	push   0x100
    405e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4061:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4065:	06                   	push   es
    4066:	57                   	push   di
    4067:	9a c1 30 8f 40       	call   0x408f:0x30c1
    406c:	81 6e 06 00 01       	sub    WORD PTR [bp+0x6],0x100
    4071:	83 5e 08 00          	sbb    WORD PTR [bp+0x8],0x0
    4075:	eb 22                	jmp    0x4099
    4077:	8d be 00 ff          	lea    di,[bp-0x100]
    407b:	16                   	push   ss
    407c:	57                   	push   di
    407d:	ff 76 08             	push   WORD PTR [bp+0x8]
    4080:	ff 76 06             	push   WORD PTR [bp+0x6]
    4083:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4086:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    408a:	06                   	push   es
    408b:	57                   	push   di
    408c:	9a c1 30 b8 40       	call   0x40b8:0x30c1
    4091:	31 c0                	xor    ax,ax
    4093:	89 46 06             	mov    WORD PTR [bp+0x6],ax
    4096:	89 46 08             	mov    WORD PTR [bp+0x8],ax
    4099:	eb 9b                	jmp    0x4036
    409b:	c9                   	leave
    409c:	c2 06 00             	ret    0x6
    409f:	c8 04 00 00          	enter  0x4,0x0
    40a3:	8d 7e fc             	lea    di,[bp-0x4]
    40a6:	16                   	push   ss
    40a7:	57                   	push   di
    40a8:	6a 00                	push   0x0
    40aa:	6a 04                	push   0x4
    40ac:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    40af:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    40b3:	06                   	push   es
    40b4:	57                   	push   di
    40b5:	9a c1 30 ef 40       	call   0x40ef:0x30c1
    40ba:	ff 76 fe             	push   WORD PTR [bp-0x2]
    40bd:	ff 76 fc             	push   WORD PTR [bp-0x4]
    40c0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    40c3:	57                   	push   di
    40c4:	e8 6b ff             	call   0x4032
    40c7:	c9                   	leave
    40c8:	c2 02 00             	ret    0x2
    40cb:	ff 40 01             	inc    WORD PTR [bx+si+0x1]
    40ce:	41                   	inc    cx
    40cf:	07                   	pop    es
    40d0:	41                   	inc    cx
    40d1:	11 41 1b             	adc    WORD PTR [bx+di+0x1b],ax
    40d4:	41                   	inc    cx
    40d5:	25 41 2f             	and    ax,0x2f41
    40d8:	41                   	inc    cx
    40d9:	2f                   	das
    40da:	41                   	inc    cx
    40db:	44                   	inc    sp
    40dc:	41                   	inc    cx
    40dd:	44                   	inc    sp
    40de:	41                   	inc    cx
    40df:	46                   	inc    si
    40e0:	41                   	inc    cx
    40e1:	4c                   	dec    sp
    40e2:	41                   	inc    cx
    40e3:	c8 00 01 00          	enter  0x100,0x0
    40e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    40ea:	06                   	push   es
    40eb:	57                   	push   di
    40ec:	9a b9 3f 3d 41       	call   0x413d:0x3fb9
    40f1:	3c 0b                	cmp    al,0xb
    40f3:	77 61                	ja     0x4156
    40f5:	98                   	cbw
    40f6:	89 c3                	mov    bx,ax
    40f8:	d1 e3                	shl    bx,1
    40fa:	2e ff a7 cb 40       	jmp    WORD PTR cs:[bx+0x40cb]
    40ff:	eb 55                	jmp    0x4156
    4101:	55                   	push   bp
    4102:	e8 f6 fe             	call   0x3ffb
    4105:	eb 4f                	jmp    0x4156
    4107:	6a 00                	push   0x0
    4109:	6a 01                	push   0x1
    410b:	55                   	push   bp
    410c:	e8 23 ff             	call   0x4032
    410f:	eb 45                	jmp    0x4156
    4111:	6a 00                	push   0x0
    4113:	6a 02                	push   0x2
    4115:	55                   	push   bp
    4116:	e8 19 ff             	call   0x4032
    4119:	eb 3b                	jmp    0x4156
    411b:	6a 00                	push   0x0
    411d:	6a 04                	push   0x4
    411f:	55                   	push   bp
    4120:	e8 0f ff             	call   0x4032
    4123:	eb 31                	jmp    0x4156
    4125:	6a 00                	push   0x0
    4127:	6a 0a                	push   0xa
    4129:	55                   	push   bp
    412a:	e8 05 ff             	call   0x4032
    412d:	eb 27                	jmp    0x4156
    412f:	8d be 00 ff          	lea    di,[bp-0x100]
    4133:	16                   	push   ss
    4134:	57                   	push   di
    4135:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4138:	06                   	push   es
    4139:	57                   	push   di
    413a:	9a 3b 3f 54 41       	call   0x4154:0x3f3b
    413f:	83 c4 04             	add    sp,0x4
    4142:	eb 12                	jmp    0x4156
    4144:	eb 10                	jmp    0x4156
    4146:	55                   	push   bp
    4147:	e8 55 ff             	call   0x409f
    414a:	eb 0a                	jmp    0x4156
    414c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    414f:	06                   	push   es
    4150:	57                   	push   di
    4151:	9a d7 3f 6c 41       	call   0x416c:0x3fd7
    4156:	c9                   	leave
    4157:	ca 04 00             	retf   0x4
    415a:	c8 00 01 00          	enter  0x100,0x0
    415e:	8d be 00 ff          	lea    di,[bp-0x100]
    4162:	16                   	push   ss
    4163:	57                   	push   di
    4164:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4167:	06                   	push   es
    4168:	57                   	push   di
    4169:	9a 3b 3f 79 41       	call   0x4179:0x3f3b
    416e:	83 c4 04             	add    sp,0x4
    4171:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4174:	06                   	push   es
    4175:	57                   	push   di
    4176:	9a e3 40 97 41       	call   0x4197:0x40e3
    417b:	c9                   	leave
    417c:	ca 04 00             	retf   0x4
    417f:	c8 00 01 00          	enter  0x100,0x0
    4183:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4187:	74 13                	je     0x419c
    4189:	8d be 00 ff          	lea    di,[bp-0x100]
    418d:	16                   	push   ss
    418e:	57                   	push   di
    418f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4192:	06                   	push   es
    4193:	57                   	push   di
    4194:	9a 3b 3f aa 41       	call   0x41aa:0x3f3b
    4199:	83 c4 04             	add    sp,0x4
    419c:	8d be 00 ff          	lea    di,[bp-0x100]
    41a0:	16                   	push   ss
    41a1:	57                   	push   di
    41a2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41a5:	06                   	push   es
    41a6:	57                   	push   di
    41a7:	9a 3b 3f b7 41       	call   0x41b7:0x3f3b
    41ac:	83 c4 04             	add    sp,0x4
    41af:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41b2:	06                   	push   es
    41b3:	57                   	push   di
    41b4:	9a b5 2e c5 41       	call   0x41c5:0x2eb5
    41b9:	08 c0                	or     al,al
    41bb:	75 0c                	jne    0x41c9
    41bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41c0:	06                   	push   es
    41c1:	57                   	push   di
    41c2:	9a 5a 41 d1 41       	call   0x41d1:0x415a
    41c7:	eb e6                	jmp    0x41af
    41c9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41cc:	06                   	push   es
    41cd:	57                   	push   di
    41ce:	9a 97 36 db 41       	call   0x41db:0x3697
    41d3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41d6:	06                   	push   es
    41d7:	57                   	push   di
    41d8:	9a b5 2e eb 41       	call   0x41eb:0x2eb5
    41dd:	08 c0                	or     al,al
    41df:	75 0e                	jne    0x41ef
    41e1:	6a 01                	push   0x1
    41e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41e6:	06                   	push   es
    41e7:	57                   	push   di
    41e8:	9a 7f 41 f7 41       	call   0x41f7:0x417f
    41ed:	eb e4                	jmp    0x41d3
    41ef:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    41f2:	06                   	push   es
    41f3:	57                   	push   di
    41f4:	9a 97 36 62 42       	call   0x4262:0x3697
    41f9:	c9                   	leave
    41fa:	ca 06 00             	retf   0x6
    41fd:	55                   	push   bp
    41fe:	89 e5                	mov    bp,sp
    4200:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4203:	26 8b 45 30          	mov    ax,WORD PTR es:[di+0x30]
    4207:	09 c0                	or     ax,ax
    4209:	74 23                	je     0x422e
    420b:	ff 76 08             	push   WORD PTR [bp+0x8]
    420e:	ff 76 06             	push   WORD PTR [bp+0x6]
    4211:	ff 76 12             	push   WORD PTR [bp+0x12]
    4214:	ff 76 10             	push   WORD PTR [bp+0x10]
    4217:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    421a:	06                   	push   es
    421b:	57                   	push   di
    421c:	ff 76 0a             	push   WORD PTR [bp+0xa]
    421f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4222:	26 ff 75 34          	push   WORD PTR es:[di+0x34]
    4226:	26 ff 75 32          	push   WORD PTR es:[di+0x32]
    422a:	26 ff 5d 2e          	call   DWORD PTR es:[di+0x2e]
    422e:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4231:	06                   	push   es
    4232:	57                   	push   di
    4233:	c4 7e 10             	les    di,DWORD PTR [bp+0x10]
    4236:	06                   	push   es
    4237:	57                   	push   di
    4238:	26 c4 3d             	les    di,DWORD PTR es:[di]
    423b:	26 ff 5d 1c          	call   DWORD PTR es:[di+0x1c]
    423f:	c9                   	leave
    4240:	ca 0e 00             	retf   0xe
    4243:	55                   	push   bp
    4244:	89 e5                	mov    bp,sp
    4246:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4249:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    424c:	eb 5b                	jmp    0x42a9
    424e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4251:	26 8b 4d 0c          	mov    cx,WORD PTR es:[di+0xc]
    4255:	26 2b 4d 0e          	sub    cx,WORD PTR es:[di+0xe]
    4259:	77 12                	ja     0x426d
    425b:	52                   	push   dx
    425c:	50                   	push   ax
    425d:	06                   	push   es
    425e:	57                   	push   di
    425f:	9a b3 42 d3 42       	call   0x42d3:0x42b3
    4264:	58                   	pop    ax
    4265:	5a                   	pop    dx
    4266:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4269:	26 8b 4d 0c          	mov    cx,WORD PTR es:[di+0xc]
    426d:	09 d2                	or     dx,dx
    426f:	75 06                	jne    0x4277
    4271:	39 c1                	cmp    cx,ax
    4273:	72 02                	jb     0x4277
    4275:	89 c1                	mov    cx,ax
    4277:	8b 5e 0e             	mov    bx,WORD PTR [bp+0xe]
    427a:	f7 db                	neg    bx
    427c:	74 06                	je     0x4284
    427e:	39 d9                	cmp    cx,bx
    4280:	72 02                	jb     0x4284
    4282:	89 d9                	mov    cx,bx
    4284:	1e                   	push   ds
    4285:	29 c8                	sub    ax,cx
    4287:	83 da 00             	sbb    dx,0x0
    428a:	26 8b 5d 0e          	mov    bx,WORD PTR es:[di+0xe]
    428e:	26 01 4d 0e          	add    WORD PTR es:[di+0xe],cx
    4292:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    4296:	01 df                	add    di,bx
    4298:	c5 76 0e             	lds    si,DWORD PTR [bp+0xe]
    429b:	01 4e 0e             	add    WORD PTR [bp+0xe],cx
    429e:	73 05                	jae    0x42a5
    42a0:	81 46 10 ff ff       	add    WORD PTR [bp+0x10],0xffff
    42a5:	fc                   	cld
    42a6:	f3 a4                	rep movs BYTE PTR es:[di],BYTE PTR ds:[si]
    42a8:	1f                   	pop    ds
    42a9:	89 c1                	mov    cx,ax
    42ab:	09 d1                	or     cx,dx
    42ad:	75 9f                	jne    0x424e
    42af:	c9                   	leave
    42b0:	ca 0c 00             	retf   0xc
    42b3:	55                   	push   bp
    42b4:	89 e5                	mov    bp,sp
    42b6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42b9:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    42bd:	06                   	push   es
    42be:	57                   	push   di
    42bf:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42c2:	26 8b 45 0e          	mov    ax,WORD PTR es:[di+0xe]
    42c6:	31 d2                	xor    dx,dx
    42c8:	52                   	push   dx
    42c9:	50                   	push   ax
    42ca:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    42ce:	06                   	push   es
    42cf:	57                   	push   di
    42d0:	9a 66 24 f5 42       	call   0x42f5:0x2466
    42d5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42d8:	31 c0                	xor    ax,ax
    42da:	26 89 45 0e          	mov    WORD PTR es:[di+0xe],ax
    42de:	c9                   	leave
    42df:	ca 04 00             	retf   0x4
    42e2:	55                   	push   bp
    42e3:	89 e5                	mov    bp,sp
    42e5:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    42e9:	74 0e                	je     0x42f9
    42eb:	6a 09                	push   0x9
    42ed:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42f0:	06                   	push   es
    42f1:	57                   	push   di
    42f2:	9a bf 4b 03 43       	call   0x4303:0x4bbf
    42f7:	eb 0c                	jmp    0x4305
    42f9:	6a 08                	push   0x8
    42fb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    42fe:	06                   	push   es
    42ff:	57                   	push   di
    4300:	9a bf 4b 24 43       	call   0x4324:0x4bbf
    4305:	c9                   	leave
    4306:	ca 06 00             	retf   0x6
    4309:	c8 00 01 00          	enter  0x100,0x0
    430d:	8d be 00 ff          	lea    di,[bp-0x100]
    4311:	16                   	push   ss
    4312:	57                   	push   di
    4313:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    4316:	50                   	push   ax
    4317:	9a e9 18 68 43       	call   0x4368:0x18e9
    431c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    431f:	06                   	push   es
    4320:	57                   	push   di
    4321:	9a 9d 4b 72 43       	call   0x4372:0x4b9d
    4326:	c9                   	leave
    4327:	ca 06 00             	retf   0x6
    432a:	55                   	push   bp
    432b:	89 e5                	mov    bp,sp
    432d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4330:	26 80 4d 18 04       	or     BYTE PTR es:[di+0x18],0x4
    4335:	ff 76 08             	push   WORD PTR [bp+0x8]
    4338:	ff 76 06             	push   WORD PTR [bp+0x6]
    433b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    433e:	06                   	push   es
    433f:	57                   	push   di
    4340:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4343:	26 ff 5d 28          	call   DWORD PTR es:[di+0x28]
    4347:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    434a:	26 80 65 18 fb       	and    BYTE PTR es:[di+0x18],0xfb
    434f:	c9                   	leave
    4350:	ca 08 00             	retf   0x8
    4353:	c8 06 01 00          	enter  0x106,0x0
    4357:	8d be fa fe          	lea    di,[bp-0x106]
    435b:	16                   	push   ss
    435c:	57                   	push   di
    435d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4360:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4363:	06                   	push   es
    4364:	57                   	push   di
    4365:	9a ed 20 7b 44       	call   0x447b:0x20ed
    436a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    436d:	06                   	push   es
    436e:	57                   	push   di
    436f:	9a 7e 4b 82 43       	call   0x4382:0x4b7e
    4374:	8d be fa fe          	lea    di,[bp-0x106]
    4378:	16                   	push   ss
    4379:	57                   	push   di
    437a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    437d:	06                   	push   es
    437e:	57                   	push   di
    437f:	9a 2a 51 8c 43       	call   0x438c:0x512a
    4384:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4387:	06                   	push   es
    4388:	57                   	push   di
    4389:	9a 7e 4b 9c 43       	call   0x439c:0x4b7e
    438e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4391:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4394:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4397:	06                   	push   es
    4398:	57                   	push   di
    4399:	9a 99 45 a6 43       	call   0x43a6:0x4599
    439e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43a1:	06                   	push   es
    43a2:	57                   	push   di
    43a3:	9a 80 45 d8 43       	call   0x43d8:0x4580
    43a8:	ff 76 08             	push   WORD PTR [bp+0x8]
    43ab:	ff 76 06             	push   WORD PTR [bp+0x6]
    43ae:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    43b1:	06                   	push   es
    43b2:	57                   	push   di
    43b3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    43b6:	26 ff 5d 24          	call   DWORD PTR es:[di+0x24]
    43ba:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    43bd:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    43c0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43c3:	26 3b 55 14          	cmp    dx,WORD PTR es:[di+0x14]
    43c7:	75 63                	jne    0x442c
    43c9:	26 3b 45 12          	cmp    ax,WORD PTR es:[di+0x12]
    43cd:	75 5d                	jne    0x442c
    43cf:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    43d3:	06                   	push   es
    43d4:	57                   	push   di
    43d5:	9a 7d 52 fc 43       	call   0x43fc:0x527d
    43da:	48                   	dec    ax
    43db:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    43de:	31 c0                	xor    ax,ax
    43e0:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    43e3:	7f 47                	jg     0x442c
    43e5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    43e8:	eb 03                	jmp    0x43ed
    43ea:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    43ed:	ff 76 fe             	push   WORD PTR [bp-0x2]
    43f0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    43f3:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    43f7:	06                   	push   es
    43f8:	57                   	push   di
    43f9:	9a 46 52 22 44       	call   0x4422:0x5246
    43fe:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4401:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    4404:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    4407:	06                   	push   es
    4408:	57                   	push   di
    4409:	26 c4 3d             	les    di,DWORD PTR es:[di]
    440c:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    4410:	08 c0                	or     al,al
    4412:	75 10                	jne    0x4424
    4414:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4417:	ff 76 fa             	push   WORD PTR [bp-0x6]
    441a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    441d:	06                   	push   es
    441e:	57                   	push   di
    441f:	9a 2a 43 34 44       	call   0x4434:0x432a
    4424:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4427:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    442a:	75 be                	jne    0x43ea
    442c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    442f:	06                   	push   es
    4430:	57                   	push   di
    4431:	9a 80 45 47 44       	call   0x4447:0x4580
    4436:	c9                   	leave
    4437:	ca 08 00             	retf   0x8
    443a:	55                   	push   bp
    443b:	89 e5                	mov    bp,sp
    443d:	6a 05                	push   0x5
    443f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4442:	06                   	push   es
    4443:	57                   	push   di
    4444:	9a bf 4b 5a 44       	call   0x445a:0x4bbf
    4449:	8d 7e 0a             	lea    di,[bp+0xa]
    444c:	16                   	push   ss
    444d:	57                   	push   di
    444e:	6a 00                	push   0x0
    4450:	6a 0a                	push   0xa
    4452:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4455:	06                   	push   es
    4456:	57                   	push   di
    4457:	9a 43 42 89 44       	call   0x4489:0x4243
    445c:	c9                   	leave
    445d:	ca 0e 00             	retf   0xe
    4460:	05 46 61             	add    ax,0x6146
    4463:	6c                   	ins    BYTE PTR es:[di],dx
    4464:	73 65                	jae    0x44cb
    4466:	04 54                	add    al,0x54
    4468:	72 75                	jb     0x44df
    446a:	65 55                	gs push bp
    446c:	89 e5                	mov    bp,sp
    446e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4471:	06                   	push   es
    4472:	57                   	push   di
    4473:	bf 60 44             	mov    di,0x4460
    4476:	0e                   	push   cs
    4477:	57                   	push   di
    4478:	9a be 18 9a 44       	call   0x449a:0x18be
    447d:	75 0e                	jne    0x448d
    447f:	6a 08                	push   0x8
    4481:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4484:	06                   	push   es
    4485:	57                   	push   di
    4486:	9a bf 4b a8 44       	call   0x44a8:0x4bbf
    448b:	eb 3a                	jmp    0x44c7
    448d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4490:	06                   	push   es
    4491:	57                   	push   di
    4492:	bf 66 44             	mov    di,0x4466
    4495:	0e                   	push   cs
    4496:	57                   	push   di
    4497:	9a be 18 a8 45       	call   0x45a8:0x18be
    449c:	75 0e                	jne    0x44ac
    449e:	6a 09                	push   0x9
    44a0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44a3:	06                   	push   es
    44a4:	57                   	push   di
    44a5:	9a bf 4b b6 44       	call   0x44b6:0x4bbf
    44aa:	eb 1b                	jmp    0x44c7
    44ac:	6a 07                	push   0x7
    44ae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44b1:	06                   	push   es
    44b2:	57                   	push   di
    44b3:	9a bf 4b c5 44       	call   0x44c5:0x4bbf
    44b8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    44bb:	06                   	push   es
    44bc:	57                   	push   di
    44bd:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44c0:	06                   	push   es
    44c1:	57                   	push   di
    44c2:	9a 7e 4b f4 44       	call   0x44f4:0x4b7e
    44c7:	c9                   	leave
    44c8:	ca 08 00             	retf   0x8
    44cb:	55                   	push   bp
    44cc:	89 e5                	mov    bp,sp
    44ce:	83 7e 0c ff          	cmp    WORD PTR [bp+0xc],0xffff
    44d2:	7f 08                	jg     0x44dc
    44d4:	7c 35                	jl     0x450b
    44d6:	83 7e 0a 80          	cmp    WORD PTR [bp+0xa],0xff80
    44da:	72 2f                	jb     0x450b
    44dc:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    44e0:	7c 08                	jl     0x44ea
    44e2:	7f 27                	jg     0x450b
    44e4:	83 7e 0a 7f          	cmp    WORD PTR [bp+0xa],0x7f
    44e8:	77 21                	ja     0x450b
    44ea:	6a 02                	push   0x2
    44ec:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    44ef:	06                   	push   es
    44f0:	57                   	push   di
    44f1:	9a bf 4b 07 45       	call   0x4507:0x4bbf
    44f6:	8d 7e 0a             	lea    di,[bp+0xa]
    44f9:	16                   	push   ss
    44fa:	57                   	push   di
    44fb:	6a 00                	push   0x0
    44fd:	6a 01                	push   0x1
    44ff:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4502:	06                   	push   es
    4503:	57                   	push   di
    4504:	9a 43 42 33 45       	call   0x4533:0x4243
    4509:	eb 5e                	jmp    0x4569
    450b:	83 7e 0c ff          	cmp    WORD PTR [bp+0xc],0xffff
    450f:	7f 09                	jg     0x451a
    4511:	7c 37                	jl     0x454a
    4513:	81 7e 0a 00 80       	cmp    WORD PTR [bp+0xa],0x8000
    4518:	72 30                	jb     0x454a
    451a:	83 7e 0c 00          	cmp    WORD PTR [bp+0xc],0x0
    451e:	7c 09                	jl     0x4529
    4520:	7f 28                	jg     0x454a
    4522:	81 7e 0a ff 7f       	cmp    WORD PTR [bp+0xa],0x7fff
    4527:	77 21                	ja     0x454a
    4529:	6a 03                	push   0x3
    452b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    452e:	06                   	push   es
    452f:	57                   	push   di
    4530:	9a bf 4b 46 45       	call   0x4546:0x4bbf
    4535:	8d 7e 0a             	lea    di,[bp+0xa]
    4538:	16                   	push   ss
    4539:	57                   	push   di
    453a:	6a 00                	push   0x0
    453c:	6a 02                	push   0x2
    453e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4541:	06                   	push   es
    4542:	57                   	push   di
    4543:	9a 43 42 54 45       	call   0x4554:0x4243
    4548:	eb 1f                	jmp    0x4569
    454a:	6a 04                	push   0x4
    454c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    454f:	06                   	push   es
    4550:	57                   	push   di
    4551:	9a bf 4b 67 45       	call   0x4567:0x4bbf
    4556:	8d 7e 0a             	lea    di,[bp+0xa]
    4559:	16                   	push   ss
    455a:	57                   	push   di
    455b:	6a 00                	push   0x0
    455d:	6a 04                	push   0x4
    455f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4562:	06                   	push   es
    4563:	57                   	push   di
    4564:	9a 43 42 7a 45       	call   0x457a:0x4243
    4569:	c9                   	leave
    456a:	ca 08 00             	retf   0x8
    456d:	55                   	push   bp
    456e:	89 e5                	mov    bp,sp
    4570:	6a 01                	push   0x1
    4572:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4575:	06                   	push   es
    4576:	57                   	push   di
    4577:	9a bf 4b 8d 45       	call   0x458d:0x4bbf
    457c:	c9                   	leave
    457d:	ca 04 00             	retf   0x4
    4580:	55                   	push   bp
    4581:	89 e5                	mov    bp,sp
    4583:	6a 00                	push   0x0
    4585:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4588:	06                   	push   es
    4589:	57                   	push   di
    458a:	9a bf 4b 97 45       	call   0x4597:0x4bbf
    458f:	c9                   	leave
    4590:	ca 04 00             	retf   0x4
    4593:	00 00                	add    BYTE PTR [bx+si],al
    4595:	6c                   	ins    BYTE PTR es:[di],dx
    4596:	46                   	inc    si
    4597:	56                   	push   si
    4598:	46                   	inc    si
    4599:	c8 0e 00 00          	enter  0xe,0x0
    459d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    45a0:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45a3:	06                   	push   es
    45a4:	57                   	push   di
    45a5:	9a 26 21 cf 45       	call   0x45cf:0x2126
    45aa:	52                   	push   dx
    45ab:	50                   	push   ax
    45ac:	9a 7e 2c fd 45       	call   0x45fd:0x2c7e
    45b1:	89 c7                	mov    di,ax
    45b3:	8e c2                	mov    es,dx
    45b5:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    45b9:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    45bc:	83 7e fc 00          	cmp    WORD PTR [bp-0x4],0x0
    45c0:	7f 03                	jg     0x45c5
    45c2:	e9 ba 00             	jmp    0x467f
    45c5:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    45c8:	c1 e0 02             	shl    ax,0x2
    45cb:	50                   	push   ax
    45cc:	9a 82 01 f0 45       	call   0x45f0:0x182
    45d1:	89 46 f4             	mov    WORD PTR [bp-0xc],ax
    45d4:	89 56 f6             	mov    WORD PTR [bp-0xa],dx
    45d7:	b8 93 45             	mov    ax,0x4593
    45da:	0e                   	push   cs
    45db:	50                   	push   ax
    45dc:	55                   	push   bp
    45dd:	ff 36 58 18          	push   WORD PTR ds:0x1858
    45e1:	89 26 58 18          	mov    WORD PTR ds:0x1858,sp
    45e5:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    45e8:	26 c4 3d             	les    di,DWORD PTR es:[di]
    45eb:	06                   	push   es
    45ec:	57                   	push   di
    45ed:	9a 26 21 7c 46       	call   0x467c:0x2126
    45f2:	52                   	push   dx
    45f3:	50                   	push   ax
    45f4:	ff 76 f6             	push   WORD PTR [bp-0xa]
    45f7:	ff 76 f4             	push   WORD PTR [bp-0xc]
    45fa:	9a 81 2d 3c 46       	call   0x463c:0x2d81
    45ff:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4602:	48                   	dec    ax
    4603:	89 46 f2             	mov    WORD PTR [bp-0xe],ax
    4606:	31 c0                	xor    ax,ax
    4608:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    460b:	7f 53                	jg     0x4660
    460d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4610:	eb 03                	jmp    0x4615
    4612:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4615:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4618:	c1 e0 02             	shl    ax,0x2
    461b:	c4 7e f4             	les    di,DWORD PTR [bp-0xc]
    461e:	03 f8                	add    di,ax
    4620:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4623:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    4627:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    462a:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    462d:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4630:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4633:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4636:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4639:	9a e7 2d ca 46       	call   0x46ca:0x2de7
    463e:	08 c0                	or     al,al
    4640:	74 16                	je     0x4658
    4642:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4645:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4648:	ff 76 fa             	push   WORD PTR [bp-0x6]
    464b:	ff 76 f8             	push   WORD PTR [bp-0x8]
    464e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4651:	06                   	push   es
    4652:	57                   	push   di
    4653:	9a f7 4a b1 46       	call   0x46b1:0x4af7
    4658:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    465b:	3b 46 f2             	cmp    ax,WORD PTR [bp-0xe]
    465e:	75 b2                	jne    0x4612
    4660:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4664:	83 c4 06             	add    sp,0x6
    4667:	b8 7f 46             	mov    ax,0x467f
    466a:	0e                   	push   cs
    466b:	50                   	push   ax
    466c:	ff 76 f6             	push   WORD PTR [bp-0xa]
    466f:	ff 76 f4             	push   WORD PTR [bp-0xc]
    4672:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4675:	c1 e0 02             	shl    ax,0x2
    4678:	50                   	push   ax
    4679:	9a 9c 01 3c 49       	call   0x493c:0x19c
    467e:	cb                   	retf
    467f:	ff 76 08             	push   WORD PTR [bp+0x8]
    4682:	ff 76 06             	push   WORD PTR [bp+0x6]
    4685:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4688:	06                   	push   es
    4689:	57                   	push   di
    468a:	26 c4 3d             	les    di,DWORD PTR es:[di]
    468d:	26 ff 5d 04          	call   DWORD PTR es:[di+0x4]
    4691:	c9                   	leave
    4692:	ca 08 00             	retf   0x8
    4695:	55                   	push   bp
    4696:	89 e5                	mov    bp,sp
    4698:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    469b:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    469f:	81 c7 18 00          	add    di,0x18
    46a3:	06                   	push   es
    46a4:	57                   	push   di
    46a5:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    46a8:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    46ac:	06                   	push   es
    46ad:	57                   	push   di
    46ae:	9a 4e 4b ec 46       	call   0x46ec:0x4b4e
    46b3:	c9                   	leave
    46b4:	c2 02 00             	ret    0x2
    46b7:	00 c8                	add    al,cl
    46b9:	06                   	push   es
    46ba:	00 00                	add    BYTE PTR [bx+si],al
    46bc:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    46bf:	36 ff 75 fe          	push   WORD PTR ss:[di-0x2]
    46c3:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    46c7:	9a 7e 2c 16 47       	call   0x4716:0x2c7e
    46cc:	89 c7                	mov    di,ax
    46ce:	8e c2                	mov    es,dx
    46d0:	26 8b 45 01          	mov    ax,WORD PTR es:[di+0x1]
    46d4:	26 8b 55 03          	mov    dx,WORD PTR es:[di+0x3]
    46d8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    46db:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    46de:	6a 0b                	push   0xb
    46e0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    46e3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    46e7:	06                   	push   es
    46e8:	57                   	push   di
    46e9:	9a bf 4b 2a 47       	call   0x472a:0x4bbf
    46ee:	31 c0                	xor    ax,ax
    46f0:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    46f3:	eb 03                	jmp    0x46f8
    46f5:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    46f8:	8a 4e fe             	mov    cl,BYTE PTR [bp-0x2]
    46fb:	80 f9 10             	cmp    cl,0x10
    46fe:	73 2c                	jae    0x472c
    4700:	b8 01 00             	mov    ax,0x1
    4703:	d3 c0                	rol    ax,cl
    4705:	85 46 06             	test   WORD PTR [bp+0x6],ax
    4708:	74 22                	je     0x472c
    470a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    470d:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4710:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4713:	9a 93 2c fd 47       	call   0x47fd:0x2c93
    4718:	89 c7                	mov    di,ax
    471a:	8e c2                	mov    es,dx
    471c:	06                   	push   es
    471d:	57                   	push   di
    471e:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4721:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4725:	06                   	push   es
    4726:	57                   	push   di
    4727:	9a 7e 4b 43 47       	call   0x4743:0x4b7e
    472c:	83 7e fe 0f          	cmp    WORD PTR [bp-0x2],0xf
    4730:	75 c3                	jne    0x46f5
    4732:	bf b7 46             	mov    di,0x46b7
    4735:	0e                   	push   cs
    4736:	57                   	push   di
    4737:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    473a:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    473e:	06                   	push   es
    473f:	57                   	push   di
    4740:	9a 7e 4b 74 47       	call   0x4774:0x4b7e
    4745:	c9                   	leave
    4746:	c2 04 00             	ret    0x4
    4749:	c8 4a 00 00          	enter  0x4a,0x0
    474d:	c4 3e 0a 17          	les    di,DWORD PTR ds:0x170a
    4751:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4755:	48                   	dec    ax
    4756:	89 46 ba             	mov    WORD PTR [bp-0x46],ax
    4759:	31 c0                	xor    ax,ax
    475b:	3b 46 ba             	cmp    ax,WORD PTR [bp-0x46]
    475e:	7f 6b                	jg     0x47cb
    4760:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4763:	eb 03                	jmp    0x4768
    4765:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4768:	ff 76 fe             	push   WORD PTR [bp-0x2]
    476b:	c4 3e 0a 17          	les    di,DWORD PTR ds:0x170a
    476f:	06                   	push   es
    4770:	57                   	push   di
    4771:	9a d0 0d bb 47       	call   0x47bb:0xdd0
    4776:	89 c7                	mov    di,ax
    4778:	8e c2                	mov    es,dx
    477a:	89 7e b6             	mov    WORD PTR [bp-0x4a],di
    477d:	8c 46 b8             	mov    WORD PTR [bp-0x48],es
    4780:	8b 46 0a             	mov    ax,WORD PTR [bp+0xa]
    4783:	8b 56 0c             	mov    dx,WORD PTR [bp+0xc]
    4786:	26 3b 55 06          	cmp    dx,WORD PTR es:[di+0x6]
    478a:	75 37                	jne    0x47c3
    478c:	26 3b 45 04          	cmp    ax,WORD PTR es:[di+0x4]
    4790:	75 31                	jne    0x47c3
    4792:	ff 76 08             	push   WORD PTR [bp+0x8]
    4795:	ff 76 06             	push   WORD PTR [bp+0x6]
    4798:	8d 7e bc             	lea    di,[bp-0x44]
    479b:	16                   	push   ss
    479c:	57                   	push   di
    479d:	6a 40                	push   0x40
    479f:	c4 7e b6             	les    di,DWORD PTR [bp-0x4a]
    47a2:	26 ff 5d 0c          	call   DWORD PTR es:[di+0xc]
    47a6:	08 c0                	or     al,al
    47a8:	74 17                	je     0x47c1
    47aa:	8d 7e bc             	lea    di,[bp-0x44]
    47ad:	16                   	push   ss
    47ae:	57                   	push   di
    47af:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    47b2:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    47b6:	06                   	push   es
    47b7:	57                   	push   di
    47b8:	9a 6b 44 dd 47       	call   0x47dd:0x446b
    47bd:	eb 20                	jmp    0x47df
    47bf:	eb 02                	jmp    0x47c3
    47c1:	eb 08                	jmp    0x47cb
    47c3:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    47c6:	3b 46 ba             	cmp    ax,WORD PTR [bp-0x46]
    47c9:	75 9a                	jne    0x4765
    47cb:	ff 76 08             	push   WORD PTR [bp+0x8]
    47ce:	ff 76 06             	push   WORD PTR [bp+0x6]
    47d1:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    47d4:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    47d8:	06                   	push   es
    47d9:	57                   	push   di
    47da:	9a cb 44 67 48       	call   0x4867:0x44cb
    47df:	c9                   	leave
    47e0:	c2 0a 00             	ret    0xa
    47e3:	c8 04 00 00          	enter  0x4,0x0
    47e7:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    47ea:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    47ee:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    47f2:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    47f6:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    47fa:	9a 32 2e 90 48       	call   0x4890:0x2e32
    47ff:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4802:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4805:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4808:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    480b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    480e:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    4812:	26 3b 55 14          	cmp    dx,WORD PTR es:[di+0x14]
    4816:	75 09                	jne    0x4821
    4818:	26 3b 45 12          	cmp    ax,WORD PTR es:[di+0x12]
    481c:	75 03                	jne    0x4821
    481e:	e9 85 00             	jmp    0x48a6
    4821:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4824:	57                   	push   di
    4825:	e8 6d fe             	call   0x4695
    4828:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    482b:	36 c4 7d fc          	les    di,DWORD PTR ss:[di-0x4]
    482f:	26 8a 05             	mov    al,BYTE PTR es:[di]
    4832:	3c 01                	cmp    al,0x1
    4834:	75 1d                	jne    0x4853
    4836:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4839:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    483d:	26 ff 75 02          	push   WORD PTR es:[di+0x2]
    4841:	26 ff 35             	push   WORD PTR es:[di]
    4844:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4847:	ff 76 fc             	push   WORD PTR [bp-0x4]
    484a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    484d:	57                   	push   di
    484e:	e8 f8 fe             	call   0x4749
    4851:	eb 53                	jmp    0x48a6
    4853:	3c 02                	cmp    al,0x2
    4855:	75 14                	jne    0x486b
    4857:	8a 46 fc             	mov    al,BYTE PTR [bp-0x4]
    485a:	50                   	push   ax
    485b:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    485e:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4862:	06                   	push   es
    4863:	57                   	push   di
    4864:	9a 09 43 a4 48       	call   0x48a4:0x4309
    4869:	eb 3b                	jmp    0x48a6
    486b:	3c 06                	cmp    al,0x6
    486d:	75 0c                	jne    0x487b
    486f:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4872:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4875:	57                   	push   di
    4876:	e8 3f fe             	call   0x46b8
    4879:	eb 2b                	jmp    0x48a6
    487b:	3c 03                	cmp    al,0x3
    487d:	75 27                	jne    0x48a6
    487f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4882:	36 ff 75 fe          	push   WORD PTR ss:[di-0x2]
    4886:	36 ff 75 fc          	push   WORD PTR ss:[di-0x4]
    488a:	ff 76 fc             	push   WORD PTR [bp-0x4]
    488d:	9a 93 2c c8 48       	call   0x48c8:0x2c93
    4892:	89 c7                	mov    di,ax
    4894:	8e c2                	mov    es,dx
    4896:	06                   	push   es
    4897:	57                   	push   di
    4898:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    489b:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    489f:	06                   	push   es
    48a0:	57                   	push   di
    48a1:	9a 6b 44 08 49       	call   0x4908:0x446b
    48a6:	c9                   	leave
    48a7:	c2 02 00             	ret    0x2
    48aa:	00 00                	add    BYTE PTR [bx+si],al
    48ac:	00 00                	add    BYTE PTR [bx+si],al
    48ae:	c8 0c 00 00          	enter  0xc,0x0
    48b2:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    48b5:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    48b9:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    48bd:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    48c1:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    48c5:	9a 0b 30 2e 49       	call   0x492e:0x300b
    48ca:	9b db 7e f6          	fstp   TBYTE PTR [bp-0xa]
    48ce:	90                   	nop
    48cf:	9b 9b db 6e f6       	fld    TBYTE PTR [bp-0xa]
    48d4:	9b 2e d8 1e aa 48    	fcomp  DWORD PTR cs:0x48aa
    48da:	9b dd 7e f4          	fstsw  WORD PTR [bp-0xc]
    48de:	90                   	nop
    48df:	9b                   	fwait
    48e0:	8a 66 f5             	mov    ah,BYTE PTR [bp-0xb]
    48e3:	9e                   	sahf
    48e4:	74 24                	je     0x490a
    48e6:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    48e9:	57                   	push   di
    48ea:	e8 a8 fd             	call   0x4695
    48ed:	ff 76 fe             	push   WORD PTR [bp-0x2]
    48f0:	ff 76 fc             	push   WORD PTR [bp-0x4]
    48f3:	ff 76 fa             	push   WORD PTR [bp-0x6]
    48f6:	ff 76 f8             	push   WORD PTR [bp-0x8]
    48f9:	ff 76 f6             	push   WORD PTR [bp-0xa]
    48fc:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    48ff:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4903:	06                   	push   es
    4904:	57                   	push   di
    4905:	9a 3a 44 5e 49       	call   0x495e:0x443a
    490a:	c9                   	leave
    490b:	c2 02 00             	ret    0x2
    490e:	c8 00 02 00          	enter  0x200,0x0
    4912:	8d be 00 fe          	lea    di,[bp-0x200]
    4916:	16                   	push   ss
    4917:	57                   	push   di
    4918:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    491b:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    491f:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    4923:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    4927:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    492b:	9a 42 2f 80 49       	call   0x4980:0x2f42
    4930:	8d be 00 ff          	lea    di,[bp-0x100]
    4934:	16                   	push   ss
    4935:	57                   	push   di
    4936:	68 ff 00             	push   0xff
    4939:	9a e7 17 99 49       	call   0x4999:0x17e7
    493e:	80 be 00 ff 00       	cmp    BYTE PTR [bp-0x100],0x0
    4943:	74 1b                	je     0x4960
    4945:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4948:	57                   	push   di
    4949:	e8 49 fd             	call   0x4695
    494c:	8d be 00 ff          	lea    di,[bp-0x100]
    4950:	16                   	push   ss
    4951:	57                   	push   di
    4952:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4955:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4959:	06                   	push   es
    495a:	57                   	push   di
    495b:	9a 9d 4b 92 49       	call   0x4992:0x4b9d
    4960:	c9                   	leave
    4961:	c2 02 00             	ret    0x2
    4964:	01 2e c8 06          	add    WORD PTR ds:0x6c8,bp
    4968:	01 00                	add    WORD PTR [bx+si],ax
    496a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    496d:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    4971:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    4975:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    4979:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    497d:	9a 32 2e 7e 4a       	call   0x4a7e:0x2e32
    4982:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    4985:	89 56 fc             	mov    WORD PTR [bp-0x4],dx
    4988:	ff 76 fc             	push   WORD PTR [bp-0x4]
    498b:	ff 76 fa             	push   WORD PTR [bp-0x6]
    498e:	bf d1 02             	mov    di,0x2d1
    4991:	b8 ac 49             	mov    ax,0x49ac
    4994:	50                   	push   ax
    4995:	57                   	push   di
    4996:	9a 55 22 b3 49       	call   0x49b3:0x2255
    499b:	08 c0                	or     al,al
    499d:	75 03                	jne    0x49a2
    499f:	e9 b9 00             	jmp    0x4a5b
    49a2:	ff 76 fc             	push   WORD PTR [bp-0x4]
    49a5:	ff 76 fa             	push   WORD PTR [bp-0x6]
    49a8:	bf da 05             	mov    di,0x5da
    49ab:	b8 ce 49             	mov    ax,0x49ce
    49ae:	50                   	push   ax
    49af:	57                   	push   di
    49b0:	9a 55 22 06 4a       	call   0x4a06:0x2255
    49b5:	08 c0                	or     al,al
    49b7:	74 27                	je     0x49e0
    49b9:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    49bc:	57                   	push   di
    49bd:	e8 d5 fc             	call   0x4695
    49c0:	8d be fa fe          	lea    di,[bp-0x106]
    49c4:	16                   	push   ss
    49c5:	57                   	push   di
    49c6:	c4 7e fa             	les    di,DWORD PTR [bp-0x6]
    49c9:	06                   	push   es
    49ca:	57                   	push   di
    49cb:	9a 2a 51 dc 49       	call   0x49dc:0x512a
    49d0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    49d3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    49d7:	06                   	push   es
    49d8:	57                   	push   di
    49d9:	9a 6b 44 4b 4a       	call   0x4a4b:0x446b
    49de:	eb 7b                	jmp    0x4a5b
    49e0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    49e3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    49e7:	26 8a 45 16          	mov    al,BYTE PTR es:[di+0x16]
    49eb:	30 e4                	xor    ah,ah
    49ed:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    49f0:	8d be fa fe          	lea    di,[bp-0x106]
    49f4:	16                   	push   ss
    49f5:	57                   	push   di
    49f6:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    49f9:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    49fd:	81 c7 16 00          	add    di,0x16
    4a01:	06                   	push   es
    4a02:	57                   	push   di
    4a03:	9a cd 17 18 4a       	call   0x4a18:0x17cd
    4a08:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a0b:	36 c4 7d 0a          	les    di,DWORD PTR ss:[di+0xa]
    4a0f:	81 c7 18 00          	add    di,0x18
    4a13:	06                   	push   es
    4a14:	57                   	push   di
    4a15:	9a 4c 18 22 4a       	call   0x4a22:0x184c
    4a1a:	bf 64 49             	mov    di,0x4964
    4a1d:	0e                   	push   cs
    4a1e:	57                   	push   di
    4a1f:	9a 4c 18 37 4a       	call   0x4a37:0x184c
    4a24:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a27:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4a2b:	81 c7 16 00          	add    di,0x16
    4a2f:	06                   	push   es
    4a30:	57                   	push   di
    4a31:	68 ff 00             	push   0xff
    4a34:	9a e7 17 8a 4a       	call   0x4a8a:0x17e7
    4a39:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4a3c:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4a3f:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a42:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4a46:	06                   	push   es
    4a47:	57                   	push   di
    4a48:	9a 99 45 e1 4a       	call   0x4ae1:0x4599
    4a4d:	8a 46 fe             	mov    al,BYTE PTR [bp-0x2]
    4a50:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a53:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4a57:	26 88 45 16          	mov    BYTE PTR es:[di+0x16],al
    4a5b:	c9                   	leave
    4a5c:	c2 02 00             	ret    0x2
    4a5f:	c8 08 01 00          	enter  0x108,0x0
    4a63:	8d 7e f0             	lea    di,[bp-0x10]
    4a66:	16                   	push   ss
    4a67:	57                   	push   di
    4a68:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a6b:	36 ff 75 10          	push   WORD PTR ss:[di+0x10]
    4a6f:	36 ff 75 0e          	push   WORD PTR ss:[di+0xe]
    4a73:	36 ff 75 0c          	push   WORD PTR ss:[di+0xc]
    4a77:	36 ff 75 0a          	push   WORD PTR ss:[di+0xa]
    4a7b:	9a 1b 31 ff ff       	call   0xffff:0x311b
    4a80:	8d 7e f8             	lea    di,[bp-0x8]
    4a83:	16                   	push   ss
    4a84:	57                   	push   di
    4a85:	6a 08                	push   0x8
    4a87:	9a 1b 16 d3 4a       	call   0x4ad3:0x161b
    4a8c:	8b 46 f8             	mov    ax,WORD PTR [bp-0x8]
    4a8f:	0b 46 fa             	or     ax,WORD PTR [bp-0x6]
    4a92:	74 4f                	je     0x4ae3
    4a94:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    4a97:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    4a9a:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4a9d:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4aa1:	26 3b 55 14          	cmp    dx,WORD PTR es:[di+0x14]
    4aa5:	75 3c                	jne    0x4ae3
    4aa7:	26 3b 45 12          	cmp    ax,WORD PTR es:[di+0x12]
    4aab:	75 36                	jne    0x4ae3
    4aad:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4ab0:	57                   	push   di
    4ab1:	e8 e1 fb             	call   0x4695
    4ab4:	8d be f8 fe          	lea    di,[bp-0x108]
    4ab8:	16                   	push   ss
    4ab9:	57                   	push   di
    4aba:	ff 76 fa             	push   WORD PTR [bp-0x6]
    4abd:	ff 76 f8             	push   WORD PTR [bp-0x8]
    4ac0:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4ac3:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4ac7:	26 c4 7d 12          	les    di,DWORD PTR es:[di+0x12]
    4acb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4ace:	06                   	push   es
    4acf:	57                   	push   di
    4ad0:	9a 8a 21 64 4b       	call   0x4b64:0x218a
    4ad5:	8b 7e 04             	mov    di,WORD PTR [bp+0x4]
    4ad8:	36 c4 7d 06          	les    di,DWORD PTR ss:[di+0x6]
    4adc:	06                   	push   es
    4add:	57                   	push   di
    4ade:	9a 6b 44 78 4b       	call   0x4b78:0x446b
    4ae3:	c9                   	leave
    4ae4:	c2 02 00             	ret    0x2
    4ae7:	2e 4b                	cs dec bx
    4ae9:	2e 4b                	cs dec bx
    4aeb:	2e 4b                	cs dec bx
    4aed:	34 4b                	xor    al,0x4b
    4aef:	3a 4b 2e             	cmp    cl,BYTE PTR [bp+di+0x2e]
    4af2:	4b                   	dec    bx
    4af3:	40                   	inc    ax
    4af4:	4b                   	dec    bx
    4af5:	46                   	inc    si
    4af6:	4b                   	dec    bx
    4af7:	c8 04 00 00          	enter  0x4,0x0
    4afb:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4afe:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4b02:	26 0b 45 0a          	or     ax,WORD PTR es:[di+0xa]
    4b06:	74 42                	je     0x4b4a
    4b08:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4b0b:	26 8b 05             	mov    ax,WORD PTR es:[di]
    4b0e:	26 8b 55 02          	mov    dx,WORD PTR es:[di+0x2]
    4b12:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4b15:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4b18:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4b1b:	26 8a 05             	mov    al,BYTE PTR es:[di]
    4b1e:	2c 01                	sub    al,0x1
    4b20:	3c 07                	cmp    al,0x7
    4b22:	77 26                	ja     0x4b4a
    4b24:	98                   	cbw
    4b25:	89 c3                	mov    bx,ax
    4b27:	d1 e3                	shl    bx,1
    4b29:	2e ff a7 e7 4a       	jmp    WORD PTR cs:[bx+0x4ae7]
    4b2e:	55                   	push   bp
    4b2f:	e8 b1 fc             	call   0x47e3
    4b32:	eb 16                	jmp    0x4b4a
    4b34:	55                   	push   bp
    4b35:	e8 76 fd             	call   0x48ae
    4b38:	eb 10                	jmp    0x4b4a
    4b3a:	55                   	push   bp
    4b3b:	e8 d0 fd             	call   0x490e
    4b3e:	eb 0a                	jmp    0x4b4a
    4b40:	55                   	push   bp
    4b41:	e8 22 fe             	call   0x4966
    4b44:	eb 04                	jmp    0x4b4a
    4b46:	55                   	push   bp
    4b47:	e8 15 ff             	call   0x4a5f
    4b4a:	c9                   	leave
    4b4b:	ca 0c 00             	retf   0xc
    4b4e:	c8 00 01 00          	enter  0x100,0x0
    4b52:	8d be 00 ff          	lea    di,[bp-0x100]
    4b56:	16                   	push   ss
    4b57:	57                   	push   di
    4b58:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b5b:	81 c7 16 00          	add    di,0x16
    4b5f:	06                   	push   es
    4b60:	57                   	push   di
    4b61:	9a cd 17 6e 4b       	call   0x4b6e:0x17cd
    4b66:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4b69:	06                   	push   es
    4b6a:	57                   	push   di
    4b6b:	9a 4c 18 e8 4b       	call   0x4be8:0x184c
    4b70:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b73:	06                   	push   es
    4b74:	57                   	push   di
    4b75:	9a 7e 4b 97 4b       	call   0x4b97:0x4b7e
    4b7a:	c9                   	leave
    4b7b:	ca 08 00             	retf   0x8
    4b7e:	55                   	push   bp
    4b7f:	89 e5                	mov    bp,sp
    4b81:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4b84:	06                   	push   es
    4b85:	57                   	push   di
    4b86:	26 8a 05             	mov    al,BYTE PTR es:[di]
    4b89:	30 e4                	xor    ah,ah
    4b8b:	40                   	inc    ax
    4b8c:	99                   	cwd
    4b8d:	52                   	push   dx
    4b8e:	50                   	push   ax
    4b8f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4b92:	06                   	push   es
    4b93:	57                   	push   di
    4b94:	9a 43 42 aa 4b       	call   0x4baa:0x4243
    4b99:	c9                   	leave
    4b9a:	ca 08 00             	retf   0x8
    4b9d:	55                   	push   bp
    4b9e:	89 e5                	mov    bp,sp
    4ba0:	6a 06                	push   0x6
    4ba2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ba5:	06                   	push   es
    4ba6:	57                   	push   di
    4ba7:	9a bf 4b b9 4b       	call   0x4bb9:0x4bbf
    4bac:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4baf:	06                   	push   es
    4bb0:	57                   	push   di
    4bb1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bb4:	06                   	push   es
    4bb5:	57                   	push   di
    4bb6:	9a 7e 4b d3 4b       	call   0x4bd3:0x4b7e
    4bbb:	c9                   	leave
    4bbc:	ca 08 00             	retf   0x8
    4bbf:	55                   	push   bp
    4bc0:	89 e5                	mov    bp,sp
    4bc2:	8d 7e 0a             	lea    di,[bp+0xa]
    4bc5:	16                   	push   ss
    4bc6:	57                   	push   di
    4bc7:	6a 00                	push   0x0
    4bc9:	6a 01                	push   0x1
    4bcb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bce:	06                   	push   es
    4bcf:	57                   	push   di
    4bd0:	9a 43 42 12 4c       	call   0x4c12:0x4243
    4bd5:	c9                   	leave
    4bd6:	ca 06 00             	retf   0x6
    4bd9:	55                   	push   bp
    4bda:	89 e5                	mov    bp,sp
    4bdc:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4be0:	74 08                	je     0x4bea
    4be2:	83 ec 08             	sub    sp,0x8
    4be5:	9a e2 1f 79 4c       	call   0x4c79:0x1fe2
    4bea:	a1 16 17             	mov    ax,ds:0x1716
    4bed:	8b 16 18 17          	mov    dx,WORD PTR ds:0x1718
    4bf1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4bf4:	26 89 45 08          	mov    WORD PTR es:[di+0x8],ax
    4bf8:	26 89 55 0a          	mov    WORD PTR es:[di+0xa],dx
    4bfc:	8b 46 0c             	mov    ax,WORD PTR [bp+0xc]
    4bff:	0b 46 0e             	or     ax,WORD PTR [bp+0xe]
    4c02:	74 10                	je     0x4c14
    4c04:	ff 76 08             	push   WORD PTR [bp+0x8]
    4c07:	ff 76 06             	push   WORD PTR [bp+0x6]
    4c0a:	c4 7e 0c             	les    di,DWORD PTR [bp+0xc]
    4c0d:	06                   	push   es
    4c0e:	57                   	push   di
    4c0f:	9a 8d 4d 36 4c       	call   0x4c36:0x4d8d
    4c14:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4c18:	74 07                	je     0x4c21
    4c1a:	8f 06 58 18          	pop    WORD PTR ds:0x1858
    4c1e:	83 c4 06             	add    sp,0x6
    4c21:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4c24:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4c27:	c9                   	leave
    4c28:	ca 0a 00             	retf   0xa
    4c2b:	55                   	push   bp
    4c2c:	89 e5                	mov    bp,sp
    4c2e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c31:	06                   	push   es
    4c32:	57                   	push   di
    4c33:	9a a5 4e 40 4c       	call   0x4c40:0x4ea5
    4c38:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c3b:	06                   	push   es
    4c3c:	57                   	push   di
    4c3d:	9a 5e 4e 5e 4c       	call   0x4c5e:0x4e5e
    4c42:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c45:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    4c49:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    4c4d:	74 11                	je     0x4c60
    4c4f:	ff 76 08             	push   WORD PTR [bp+0x8]
    4c52:	ff 76 06             	push   WORD PTR [bp+0x6]
    4c55:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    4c59:	06                   	push   es
    4c5a:	57                   	push   di
    4c5b:	9a fb 4d 8a 4c       	call   0x4c8a:0x4dfb
    4c60:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c63:	26 ff 75 0a          	push   WORD PTR es:[di+0xa]
    4c67:	26 ff 75 08          	push   WORD PTR es:[di+0x8]
    4c6b:	9a 24 06 51 50       	call   0x5051:0x624
    4c70:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    4c74:	74 05                	je     0x4c7b
    4c76:	9a 0f 20 05 4d       	call   0x4d05:0x200f
    4c7b:	c9                   	leave
    4c7c:	ca 06 00             	retf   0x6
    4c7f:	55                   	push   bp
    4c80:	89 e5                	mov    bp,sp
    4c82:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c85:	06                   	push   es
    4c86:	57                   	push   di
    4c87:	9a 09 36 a2 4c       	call   0x4ca2:0x3609
    4c8c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4c8f:	26 89 45 14          	mov    WORD PTR es:[di+0x14],ax
    4c93:	c9                   	leave
    4c94:	ca 08 00             	retf   0x8
    4c97:	55                   	push   bp
    4c98:	89 e5                	mov    bp,sp
    4c9a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4c9d:	06                   	push   es
    4c9e:	57                   	push   di
    4c9f:	9a 09 36 c5 4c       	call   0x4cc5:0x3609
    4ca4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ca7:	26 89 45 16          	mov    WORD PTR es:[di+0x16],ax
    4cab:	c9                   	leave
    4cac:	ca 08 00             	retf   0x8
    4caf:	55                   	push   bp
    4cb0:	89 e5                	mov    bp,sp
    4cb2:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cb5:	26 8b 45 14          	mov    ax,WORD PTR es:[di+0x14]
    4cb9:	31 d2                	xor    dx,dx
    4cbb:	52                   	push   dx
    4cbc:	50                   	push   ax
    4cbd:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4cc0:	06                   	push   es
    4cc1:	57                   	push   di
    4cc2:	9a cb 44 e1 4c       	call   0x4ce1:0x44cb
    4cc7:	c9                   	leave
    4cc8:	ca 08 00             	retf   0x8
    4ccb:	55                   	push   bp
    4ccc:	89 e5                	mov    bp,sp
    4cce:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4cd1:	26 8b 45 16          	mov    ax,WORD PTR es:[di+0x16]
    4cd5:	31 d2                	xor    dx,dx
    4cd7:	52                   	push   dx
    4cd8:	50                   	push   ax
    4cd9:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4cdc:	06                   	push   es
    4cdd:	57                   	push   di
    4cde:	9a cb 44 fe 4c       	call   0x4cfe:0x44cb
    4ce3:	c9                   	leave
    4ce4:	ca 08 00             	retf   0x8
    4ce7:	55                   	push   bp
    4ce8:	89 e5                	mov    bp,sp
    4cea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ced:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    4cf1:	26 0b 45 12          	or     ax,WORD PTR es:[di+0x12]
    4cf5:	75 1b                	jne    0x4d12
    4cf7:	b0 01                	mov    al,0x1
    4cf9:	50                   	push   ax
    4cfa:	b8 a3 02             	mov    ax,0x2a3
    4cfd:	ba 24 4d             	mov    dx,0x4d24
    4d00:	52                   	push   dx
    4d01:	50                   	push   ax
    4d02:	9a 50 1f 79 4d       	call   0x4d79:0x1f50
    4d07:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d0a:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    4d0e:	26 89 55 12          	mov    WORD PTR es:[di+0x12],dx
    4d12:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d15:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d18:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d1b:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4d1f:	06                   	push   es
    4d20:	57                   	push   di
    4d21:	9a 2b 0c 5d 4d       	call   0x4d5d:0xc2b
    4d26:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    4d29:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    4d2c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d2f:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    4d33:	26 89 55 06          	mov    WORD PTR es:[di+0x6],dx
    4d37:	c9                   	leave
    4d38:	ca 08 00             	retf   0x8
    4d3b:	55                   	push   bp
    4d3c:	89 e5                	mov    bp,sp
    4d3e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d41:	31 c0                	xor    ax,ax
    4d43:	26 89 45 04          	mov    WORD PTR es:[di+0x4],ax
    4d47:	26 89 45 06          	mov    WORD PTR es:[di+0x6],ax
    4d4b:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4d4e:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d51:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d54:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4d58:	06                   	push   es
    4d59:	57                   	push   di
    4d5a:	9a a7 0f be 4d       	call   0x4dbe:0xfa7
    4d5f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d62:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4d66:	26 83 7d 08 00       	cmp    WORD PTR es:[di+0x8],0x0
    4d6b:	75 1b                	jne    0x4d88
    4d6d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d70:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4d74:	06                   	push   es
    4d75:	57                   	push   di
    4d76:	9a 7f 1f a5 50       	call   0x50a5:0x1f7f
    4d7b:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4d7e:	31 c0                	xor    ax,ax
    4d80:	26 89 45 10          	mov    WORD PTR es:[di+0x10],ax
    4d84:	26 89 45 12          	mov    WORD PTR es:[di+0x12],ax
    4d88:	c9                   	leave
    4d89:	ca 08 00             	retf   0x8
    4d8c:	00 55 89             	add    BYTE PTR [di-0x77],dl
    4d8f:	e5 ff                	in     ax,0xff
    4d91:	76 0c                	jbe    0x4d9f
    4d93:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4d96:	bf 8c 4d             	mov    di,0x4d8c
    4d99:	0e                   	push   cs
    4d9a:	57                   	push   di
    4d9b:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4d9e:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    4da2:	06                   	push   es
    4da3:	57                   	push   di
    4da4:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4da7:	06                   	push   es
    4da8:	57                   	push   di
    4da9:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4dac:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    4db0:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4db3:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4db6:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4db9:	06                   	push   es
    4dba:	57                   	push   di
    4dbb:	9a e7 4c ca 4d       	call   0x4dca:0x4ce7
    4dc0:	6a 01                	push   0x1
    4dc2:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4dc5:	06                   	push   es
    4dc6:	57                   	push   di
    4dc7:	9a 08 53 e0 4d       	call   0x4de0:0x5308
    4dcc:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4dcf:	26 f6 45 18 10       	test   BYTE PTR es:[di+0x18],0x10
    4dd4:	74 0c                	je     0x4de2
    4dd6:	6a 01                	push   0x1
    4dd8:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4ddb:	06                   	push   es
    4ddc:	57                   	push   di
    4ddd:	9a a7 52 1c 4e       	call   0x4e1c:0x52a7
    4de2:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4de5:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4de8:	6a 00                	push   0x0
    4dea:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ded:	06                   	push   es
    4dee:	57                   	push   di
    4def:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4df2:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    4df6:	c9                   	leave
    4df7:	ca 08 00             	retf   0x8
    4dfa:	00 55 89             	add    BYTE PTR [di-0x77],dl
    4dfd:	e5 ff                	in     ax,0xff
    4dff:	76 0c                	jbe    0x4e0d
    4e01:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4e04:	6a 01                	push   0x1
    4e06:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e09:	06                   	push   es
    4e0a:	57                   	push   di
    4e0b:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e0e:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    4e12:	6a 00                	push   0x0
    4e14:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4e17:	06                   	push   es
    4e18:	57                   	push   di
    4e19:	9a 08 53 2c 4e       	call   0x4e2c:0x5308
    4e1e:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4e21:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4e24:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e27:	06                   	push   es
    4e28:	57                   	push   di
    4e29:	9a 3b 4d 38 4e       	call   0x4e38:0x4d3b
    4e2e:	6a 00                	push   0x0
    4e30:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4e33:	06                   	push   es
    4e34:	57                   	push   di
    4e35:	9a a7 52 78 4e       	call   0x4e78:0x52a7
    4e3a:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4e3d:	ff 76 0a             	push   WORD PTR [bp+0xa]
    4e40:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4e43:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    4e47:	06                   	push   es
    4e48:	57                   	push   di
    4e49:	bf fa 4d             	mov    di,0x4dfa
    4e4c:	0e                   	push   cs
    4e4d:	57                   	push   di
    4e4e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e51:	06                   	push   es
    4e52:	57                   	push   di
    4e53:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e56:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    4e5a:	c9                   	leave
    4e5b:	ca 08 00             	retf   0x8
    4e5e:	c8 04 00 00          	enter  0x4,0x0
    4e62:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e65:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    4e69:	26 0b 45 12          	or     ax,WORD PTR es:[di+0x12]
    4e6d:	74 32                	je     0x4ea1
    4e6f:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4e73:	06                   	push   es
    4e74:	57                   	push   di
    4e75:	9a 43 0f 8e 4e       	call   0x4e8e:0xf43
    4e7a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4e7d:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    4e80:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4e83:	ff 76 fc             	push   WORD PTR [bp-0x4]
    4e86:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4e89:	06                   	push   es
    4e8a:	57                   	push   di
    4e8b:	9a 3b 4d ec 4e       	call   0x4eec:0x4d3b
    4e90:	b0 01                	mov    al,0x1
    4e92:	50                   	push   ax
    4e93:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    4e96:	06                   	push   es
    4e97:	57                   	push   di
    4e98:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4e9b:	26 ff 5d fc          	call   DWORD PTR es:[di-0x4]
    4e9f:	eb c1                	jmp    0x4e62
    4ea1:	c9                   	leave
    4ea2:	ca 04 00             	retf   0x4
    4ea5:	c8 04 00 00          	enter  0x4,0x0
    4ea9:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4eac:	26 f6 45 18 08       	test   BYTE PTR es:[di+0x18],0x8
    4eb1:	75 4e                	jne    0x4f01
    4eb3:	26 80 4d 18 08       	or     BYTE PTR es:[di+0x18],0x8
    4eb8:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    4ebc:	26 0b 45 12          	or     ax,WORD PTR es:[di+0x12]
    4ec0:	74 3f                	je     0x4f01
    4ec2:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4ec6:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4eca:	48                   	dec    ax
    4ecb:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4ece:	31 c0                	xor    ax,ax
    4ed0:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    4ed3:	7f 2c                	jg     0x4f01
    4ed5:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4ed8:	eb 03                	jmp    0x4edd
    4eda:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4edd:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4ee0:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ee3:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4ee7:	06                   	push   es
    4ee8:	57                   	push   di
    4ee9:	9a d0 0d f7 4e       	call   0x4ef7:0xdd0
    4eee:	89 c7                	mov    di,ax
    4ef0:	8e c2                	mov    es,dx
    4ef2:	06                   	push   es
    4ef3:	57                   	push   di
    4ef4:	9a a5 4e 4a 4f       	call   0x4f4a:0x4ea5
    4ef9:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4efc:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    4eff:	75 d9                	jne    0x4eda
    4f01:	c9                   	leave
    4f02:	ca 04 00             	retf   0x4
    4f05:	c8 04 00 00          	enter  0x4,0x0
    4f09:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f0c:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    4f10:	26 0b 45 12          	or     ax,WORD PTR es:[di+0x12]
    4f14:	74 4b                	je     0x4f61
    4f16:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4f1a:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    4f1e:	48                   	dec    ax
    4f1f:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    4f22:	31 c0                	xor    ax,ax
    4f24:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    4f27:	7f 38                	jg     0x4f61
    4f29:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    4f2c:	eb 03                	jmp    0x4f31
    4f2e:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    4f31:	ff 76 0e             	push   WORD PTR [bp+0xe]
    4f34:	ff 76 0c             	push   WORD PTR [bp+0xc]
    4f37:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    4f3a:	50                   	push   ax
    4f3b:	ff 76 fe             	push   WORD PTR [bp-0x2]
    4f3e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f41:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    4f45:	06                   	push   es
    4f46:	57                   	push   di
    4f47:	9a d0 0d 7f 4f       	call   0x4f7f:0xdd0
    4f4c:	89 c7                	mov    di,ax
    4f4e:	8e c2                	mov    es,dx
    4f50:	06                   	push   es
    4f51:	57                   	push   di
    4f52:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4f55:	26 ff 5d 14          	call   DWORD PTR es:[di+0x14]
    4f59:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    4f5c:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    4f5f:	75 cd                	jne    0x4f2e
    4f61:	c9                   	leave
    4f62:	ca 0a 00             	retf   0xa
    4f65:	04 4c                	add    al,0x4c
    4f67:	65 66 74 03          	gs data32 je 0x4f6e
    4f6b:	54                   	push   sp
    4f6c:	6f                   	outs   dx,WORD PTR ds:[si]
    4f6d:	70 55                	jo     0x4fc4
    4f6f:	89 e5                	mov    bp,sp
    4f71:	bf 65 4f             	mov    di,0x4f65
    4f74:	0e                   	push   cs
    4f75:	57                   	push   di
    4f76:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f79:	06                   	push   es
    4f7a:	57                   	push   di
    4f7b:	bf 7f 4c             	mov    di,0x4c7f
    4f7e:	b8 8c 4f             	mov    ax,0x4f8c
    4f81:	50                   	push   ax
    4f82:	57                   	push   di
    4f83:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f86:	06                   	push   es
    4f87:	57                   	push   di
    4f88:	bf af 4c             	mov    di,0x4caf
    4f8b:	b8 b7 4f             	mov    ax,0x4fb7
    4f8e:	50                   	push   ax
    4f8f:	57                   	push   di
    4f90:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4f93:	26 83 7d 14 00       	cmp    WORD PTR es:[di+0x14],0x0
    4f98:	b0 00                	mov    al,0x0
    4f9a:	74 01                	je     0x4f9d
    4f9c:	40                   	inc    ax
    4f9d:	50                   	push   ax
    4f9e:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4fa1:	06                   	push   es
    4fa2:	57                   	push   di
    4fa3:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fa6:	26 ff 1d             	call   DWORD PTR es:[di]
    4fa9:	bf 6a 4f             	mov    di,0x4f6a
    4fac:	0e                   	push   cs
    4fad:	57                   	push   di
    4fae:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fb1:	06                   	push   es
    4fb2:	57                   	push   di
    4fb3:	bf 97 4c             	mov    di,0x4c97
    4fb6:	b8 c4 4f             	mov    ax,0x4fc4
    4fb9:	50                   	push   ax
    4fba:	57                   	push   di
    4fbb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fbe:	06                   	push   es
    4fbf:	57                   	push   di
    4fc0:	bf cb 4c             	mov    di,0x4ccb
    4fc3:	b8 14 50             	mov    ax,0x5014
    4fc6:	50                   	push   ax
    4fc7:	57                   	push   di
    4fc8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4fcb:	26 83 7d 16 00       	cmp    WORD PTR es:[di+0x16],0x0
    4fd0:	b0 00                	mov    al,0x0
    4fd2:	74 01                	je     0x4fd5
    4fd4:	40                   	inc    ax
    4fd5:	50                   	push   ax
    4fd6:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    4fd9:	06                   	push   es
    4fda:	57                   	push   di
    4fdb:	26 c4 3d             	les    di,DWORD PTR es:[di]
    4fde:	26 ff 1d             	call   DWORD PTR es:[di]
    4fe1:	c9                   	leave
    4fe2:	ca 08 00             	retf   0x8
    4fe5:	c8 02 00 00          	enter  0x2,0x0
    4fe9:	c6 46 ff 00          	mov    BYTE PTR [bp-0x1],0x0
    4fed:	8a 46 ff             	mov    al,BYTE PTR [bp-0x1]
    4ff0:	c9                   	leave
    4ff1:	ca 04 00             	retf   0x4
    4ff4:	55                   	push   bp
    4ff5:	89 e5                	mov    bp,sp
    4ff7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    4ffa:	26 80 65 18 fe       	and    BYTE PTR es:[di+0x18],0xfe
    4fff:	c9                   	leave
    5000:	ca 04 00             	retf   0x4
    5003:	55                   	push   bp
    5004:	89 e5                	mov    bp,sp
    5006:	ff 76 08             	push   WORD PTR [bp+0x8]
    5009:	ff 76 06             	push   WORD PTR [bp+0x6]
    500c:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    500f:	06                   	push   es
    5010:	57                   	push   di
    5011:	9a 35 34 32 50       	call   0x5032:0x3435
    5016:	c9                   	leave
    5017:	ca 08 00             	retf   0x8
    501a:	55                   	push   bp
    501b:	89 e5                	mov    bp,sp
    501d:	c9                   	leave
    501e:	ca 08 00             	retf   0x8
    5021:	55                   	push   bp
    5022:	89 e5                	mov    bp,sp
    5024:	ff 76 08             	push   WORD PTR [bp+0x8]
    5027:	ff 76 06             	push   WORD PTR [bp+0x6]
    502a:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    502d:	06                   	push   es
    502e:	57                   	push   di
    502f:	9a 53 43 64 50       	call   0x5064:0x4353
    5034:	c9                   	leave
    5035:	ca 08 00             	retf   0x8
    5038:	c8 08 01 00          	enter  0x108,0x0
    503c:	8b 46 12             	mov    ax,WORD PTR [bp+0x12]
    503f:	0b 46 14             	or     ax,WORD PTR [bp+0x14]
    5042:	74 63                	je     0x50a7
    5044:	c4 7e 0e             	les    di,DWORD PTR [bp+0xe]
    5047:	06                   	push   es
    5048:	57                   	push   di
    5049:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    504c:	06                   	push   es
    504d:	57                   	push   di
    504e:	9a 30 07 8e 50       	call   0x508e:0x730
    5053:	09 c0                	or     ax,ax
    5055:	74 50                	je     0x50a7
    5057:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    505a:	06                   	push   es
    505b:	57                   	push   di
    505c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    505f:	06                   	push   es
    5060:	57                   	push   di
    5061:	9a ab 50 97 50       	call   0x5097:0x50ab
    5066:	09 d0                	or     ax,dx
    5068:	74 3d                	je     0x50a7
    506a:	8d be f8 fe          	lea    di,[bp-0x108]
    506e:	16                   	push   ss
    506f:	57                   	push   di
    5070:	68 0f f0             	push   0xf00f
    5073:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5076:	89 f8                	mov    ax,di
    5078:	8c c2                	mov    dx,es
    507a:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    507d:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    5080:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    5084:	8d 7e f8             	lea    di,[bp-0x8]
    5087:	16                   	push   ss
    5088:	57                   	push   di
    5089:	6a 00                	push   0x0
    508b:	9a 50 09 9e 50       	call   0x509e:0x950
    5090:	b0 01                	mov    al,0x1
    5092:	50                   	push   ax
    5093:	b8 73 02             	mov    ax,0x273
    5096:	ba ef 50             	mov    dx,0x50ef
    5099:	52                   	push   dx
    509a:	50                   	push   ax
    509b:	9a e6 28 08 51       	call   0x5108:0x28e6
    50a0:	52                   	push   dx
    50a1:	50                   	push   ax
    50a2:	9a 99 13 40 51       	call   0x5140:0x1399
    50a7:	c9                   	leave
    50a8:	ca 10 00             	retf   0x10
    50ab:	c8 08 00 00          	enter  0x8,0x0
    50af:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    50b2:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    50b6:	74 60                	je     0x5118
    50b8:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50bb:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    50bf:	26 0b 45 12          	or     ax,WORD PTR es:[di+0x12]
    50c3:	74 53                	je     0x5118
    50c5:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    50c9:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    50cd:	48                   	dec    ax
    50ce:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    50d1:	31 c0                	xor    ax,ax
    50d3:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    50d6:	7f 40                	jg     0x5118
    50d8:	89 46 fa             	mov    WORD PTR [bp-0x6],ax
    50db:	eb 03                	jmp    0x50e0
    50dd:	ff 46 fa             	inc    WORD PTR [bp-0x6]
    50e0:	ff 76 fa             	push   WORD PTR [bp-0x6]
    50e3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    50e6:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    50ea:	06                   	push   es
    50eb:	57                   	push   di
    50ec:	9a d0 0d a3 51       	call   0x51a3:0xdd0
    50f1:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    50f4:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    50f7:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    50fa:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    50fe:	06                   	push   es
    50ff:	57                   	push   di
    5100:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5103:	06                   	push   es
    5104:	57                   	push   di
    5105:	9a 30 07 70 51       	call   0x5170:0x730
    510a:	09 c0                	or     ax,ax
    510c:	75 02                	jne    0x5110
    510e:	eb 10                	jmp    0x5120
    5110:	8b 46 fa             	mov    ax,WORD PTR [bp-0x6]
    5113:	3b 46 f8             	cmp    ax,WORD PTR [bp-0x8]
    5116:	75 c5                	jne    0x50dd
    5118:	31 c0                	xor    ax,ax
    511a:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    511d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5120:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5123:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5126:	c9                   	leave
    5127:	ca 08 00             	retf   0x8
    512a:	55                   	push   bp
    512b:	89 e5                	mov    bp,sp
    512d:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5130:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    5134:	06                   	push   es
    5135:	57                   	push   di
    5136:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5139:	06                   	push   es
    513a:	57                   	push   di
    513b:	6a 3f                	push   0x3f
    513d:	9a e7 17 5b 51       	call   0x515b:0x17e7
    5142:	c9                   	leave
    5143:	ca 04 00             	retf   0x4
    5146:	c8 08 01 00          	enter  0x108,0x0
    514a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    514d:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    5151:	06                   	push   es
    5152:	57                   	push   di
    5153:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5156:	06                   	push   es
    5157:	57                   	push   di
    5158:	9a be 18 b1 51       	call   0x51b1:0x18be
    515d:	75 03                	jne    0x5162
    515f:	e9 c6 00             	jmp    0x5228
    5162:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5165:	26 80 3d 00          	cmp    BYTE PTR es:[di],0x0
    5169:	74 48                	je     0x51b3
    516b:	06                   	push   es
    516c:	57                   	push   di
    516d:	9a 24 08 9a 51       	call   0x519a:0x824
    5172:	08 c0                	or     al,al
    5174:	75 3d                	jne    0x51b3
    5176:	8d be f8 fe          	lea    di,[bp-0x108]
    517a:	16                   	push   ss
    517b:	57                   	push   di
    517c:	68 10 f0             	push   0xf010
    517f:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5182:	89 f8                	mov    ax,di
    5184:	8c c2                	mov    dx,es
    5186:	89 46 f8             	mov    WORD PTR [bp-0x8],ax
    5189:	89 56 fa             	mov    WORD PTR [bp-0x6],dx
    518c:	c6 46 fc 04          	mov    BYTE PTR [bp-0x4],0x4
    5190:	8d 7e f8             	lea    di,[bp-0x8]
    5193:	16                   	push   ss
    5194:	57                   	push   di
    5195:	6a 00                	push   0x0
    5197:	9a 50 09 aa 51       	call   0x51aa:0x950
    519c:	b0 01                	mov    al,0x1
    519e:	50                   	push   ax
    519f:	b8 73 02             	mov    ax,0x273
    51a2:	ba 0b 52             	mov    dx,0x520b
    51a5:	52                   	push   dx
    51a6:	50                   	push   ax
    51a7:	9a e6 28 40 52       	call   0x5240:0x28e6
    51ac:	52                   	push   dx
    51ad:	50                   	push   ax
    51ae:	9a 99 13 2b 53       	call   0x532b:0x1399
    51b3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51b6:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    51ba:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    51be:	74 23                	je     0x51e3
    51c0:	ff 76 08             	push   WORD PTR [bp+0x8]
    51c3:	ff 76 06             	push   WORD PTR [bp+0x6]
    51c6:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    51ca:	06                   	push   es
    51cb:	57                   	push   di
    51cc:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    51cf:	06                   	push   es
    51d0:	57                   	push   di
    51d1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51d4:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    51d8:	06                   	push   es
    51d9:	57                   	push   di
    51da:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51dd:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    51e1:	eb 1e                	jmp    0x5201
    51e3:	6a 00                	push   0x0
    51e5:	6a 00                	push   0x0
    51e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51ea:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    51ee:	06                   	push   es
    51ef:	57                   	push   di
    51f0:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    51f3:	06                   	push   es
    51f4:	57                   	push   di
    51f5:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    51f8:	06                   	push   es
    51f9:	57                   	push   di
    51fa:	26 c4 3d             	les    di,DWORD PTR es:[di]
    51fd:	26 ff 5d 20          	call   DWORD PTR es:[di+0x20]
    5201:	6a 00                	push   0x0
    5203:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5206:	06                   	push   es
    5207:	57                   	push   di
    5208:	9a 08 53 1a 52       	call   0x521a:0x5308
    520d:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    5210:	06                   	push   es
    5211:	57                   	push   di
    5212:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5215:	06                   	push   es
    5216:	57                   	push   di
    5217:	9a 2c 52 26 52       	call   0x5226:0x522c
    521c:	6a 01                	push   0x1
    521e:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5221:	06                   	push   es
    5222:	57                   	push   di
    5223:	9a 08 53 63 52       	call   0x5263:0x5308
    5228:	c9                   	leave
    5229:	ca 08 00             	retf   0x8
    522c:	55                   	push   bp
    522d:	89 e5                	mov    bp,sp
    522f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5232:	81 c7 08 00          	add    di,0x8
    5236:	06                   	push   es
    5237:	57                   	push   di
    5238:	c4 7e 0a             	les    di,DWORD PTR [bp+0xa]
    523b:	06                   	push   es
    523c:	57                   	push   di
    523d:	9a 51 06 ff ff       	call   0xffff:0x651
    5242:	c9                   	leave
    5243:	ca 08 00             	retf   0x8
    5246:	c8 04 00 00          	enter  0x4,0x0
    524a:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    524d:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    5251:	26 0b 45 12          	or     ax,WORD PTR es:[di+0x12]
    5255:	74 16                	je     0x526d
    5257:	ff 76 0a             	push   WORD PTR [bp+0xa]
    525a:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    525e:	06                   	push   es
    525f:	57                   	push   di
    5260:	9a d0 0d cb 52       	call   0x52cb:0xdd0
    5265:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5268:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    526b:	eb 06                	jmp    0x5273
    526d:	68 0b f0             	push   0xf00b
    5270:	e8 6f b9             	call   0xbe2
    5273:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5276:	8b 56 fe             	mov    dx,WORD PTR [bp-0x2]
    5279:	c9                   	leave
    527a:	ca 06 00             	retf   0x6
    527d:	c8 02 00 00          	enter  0x2,0x0
    5281:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5284:	26 8b 45 10          	mov    ax,WORD PTR es:[di+0x10]
    5288:	26 0b 45 12          	or     ax,WORD PTR es:[di+0x12]
    528c:	74 0d                	je     0x529b
    528e:	26 c4 7d 10          	les    di,DWORD PTR es:[di+0x10]
    5292:	26 8b 45 08          	mov    ax,WORD PTR es:[di+0x8]
    5296:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    5299:	eb 05                	jmp    0x52a0
    529b:	31 c0                	xor    ax,ax
    529d:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    52a0:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    52a3:	c9                   	leave
    52a4:	ca 04 00             	retf   0x4
    52a7:	c8 04 00 00          	enter  0x4,0x0
    52ab:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    52af:	74 0a                	je     0x52bb
    52b1:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52b4:	26 80 4d 18 10       	or     BYTE PTR es:[di+0x18],0x10
    52b9:	eb 08                	jmp    0x52c3
    52bb:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52be:	26 80 65 18 ef       	and    BYTE PTR es:[di+0x18],0xef
    52c3:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52c6:	06                   	push   es
    52c7:	57                   	push   di
    52c8:	9a 7d 52 ef 52       	call   0x52ef:0x527d
    52cd:	48                   	dec    ax
    52ce:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    52d1:	31 c0                	xor    ax,ax
    52d3:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    52d6:	7f 2c                	jg     0x5304
    52d8:	89 46 fe             	mov    WORD PTR [bp-0x2],ax
    52db:	eb 03                	jmp    0x52e0
    52dd:	ff 46 fe             	inc    WORD PTR [bp-0x2]
    52e0:	8a 46 0a             	mov    al,BYTE PTR [bp+0xa]
    52e3:	50                   	push   ax
    52e4:	ff 76 fe             	push   WORD PTR [bp-0x2]
    52e7:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    52ea:	06                   	push   es
    52eb:	57                   	push   di
    52ec:	9a 46 52 fa 52       	call   0x52fa:0x5246
    52f1:	89 c7                	mov    di,ax
    52f3:	8e c2                	mov    es,dx
    52f5:	06                   	push   es
    52f6:	57                   	push   di
    52f7:	9a a7 52 6d 53       	call   0x536d:0x52a7
    52fc:	8b 46 fe             	mov    ax,WORD PTR [bp-0x2]
    52ff:	3b 46 fc             	cmp    ax,WORD PTR [bp-0x4]
    5302:	75 d9                	jne    0x52dd
    5304:	c9                   	leave
    5305:	ca 06 00             	retf   0x6
    5308:	c8 04 00 00          	enter  0x4,0x0
    530c:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    530f:	26 8b 45 04          	mov    ax,WORD PTR es:[di+0x4]
    5313:	26 0b 45 06          	or     ax,WORD PTR es:[di+0x6]
    5317:	74 46                	je     0x535f
    5319:	26 c4 7d 08          	les    di,DWORD PTR es:[di+0x8]
    531d:	06                   	push   es
    531e:	57                   	push   di
    531f:	c4 7e 06             	les    di,DWORD PTR [bp+0x6]
    5322:	26 c4 7d 04          	les    di,DWORD PTR es:[di+0x4]
    5326:	06                   	push   es
    5327:	57                   	push   di
    5328:	9a da 21 74 53       	call   0x5374:0x21da
    532d:	89 46 fc             	mov    WORD PTR [bp-0x4],ax
    5330:	89 56 fe             	mov    WORD PTR [bp-0x2],dx
    5333:	8b 46 fc             	mov    ax,WORD PTR [bp-0x4]
    5336:	0b 46 fe             	or     ax,WORD PTR [bp-0x2]
    5339:	74 24                	je     0x535f
    533b:	80 7e 0a 00          	cmp    BYTE PTR [bp+0xa],0x0
    533f:	74 12                	je     0x5353
    5341:	8b 46 06             	mov    ax,WORD PTR [bp+0x6]
    5344:	8b 56 08             	mov    dx,WORD PTR [bp+0x8]
    5347:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    534a:	26 89 05             	mov    WORD PTR es:[di],ax
    534d:	26 89 55 02          	mov    WORD PTR es:[di+0x2],dx
    5351:	eb 0c                	jmp    0x535f
    5353:	c4 7e fc             	les    di,DWORD PTR [bp-0x4]
    5356:	31 c0                	xor    ax,ax
    5358:	26 89 05             	mov    WORD PTR es:[di],ax
    535b:	26 89 45 02          	mov    WORD PTR es:[di+0x2],ax
    535f:	c9                   	leave
    5360:	ca 06 00             	retf   0x6
    5363:	55                   	push   bp
    5364:	89 e5                	mov    bp,sp
    5366:	b0 01                	mov    al,0x1
    5368:	50                   	push   ax
    5369:	b8 a3 02             	mov    ax,0x2a3
    536c:	ba 84 53             	mov    dx,0x5384
    536f:	52                   	push   dx
    5370:	50                   	push   ax
    5371:	9a 50 1f a2 53       	call   0x53a2:0x1f50
    5376:	a3 02 17             	mov    ds:0x1702,ax
    5379:	89 16 04 17          	mov    WORD PTR ds:0x1704,dx
    537d:	b0 01                	mov    al,0x1
    537f:	50                   	push   ax
    5380:	b8 c9 03             	mov    ax,0x3c9
    5383:	ba 8b 53             	mov    dx,0x538b
    5386:	52                   	push   dx
    5387:	50                   	push   ax
    5388:	9a 08 1d 9b 53       	call   0x539b:0x1d08
    538d:	a3 06 17             	mov    ds:0x1706,ax
    5390:	89 16 08 17          	mov    WORD PTR ds:0x1708,dx
    5394:	b0 01                	mov    al,0x1
    5396:	50                   	push   ax
    5397:	b8 a3 02             	mov    ax,0x2a3
    539a:	ba ff ff             	mov    dx,0xffff
    539d:	52                   	push   dx
    539e:	50                   	push   ax
    539f:	9a 50 1f ff ff       	call   0xffff:0x1f50
    53a4:	a3 0a 17             	mov    ds:0x170a,ax
    53a7:	89 16 0c 17          	mov    WORD PTR ds:0x170c,dx
    53ab:	c9                   	leave
    53ac:	cb                   	retf
